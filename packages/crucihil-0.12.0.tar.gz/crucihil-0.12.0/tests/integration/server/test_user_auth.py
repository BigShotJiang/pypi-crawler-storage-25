"""User auth + org management integration tests.

Tests cover:
  - POST /api/v1/setup (bootstrap)
  - POST /api/v1/auth/login (email + password, rate limiting)
  - GET  /api/v1/auth/invite/{token} (validate invite)
  - POST /api/v1/auth/invite/accept  (accept invite, set password)
  - POST /api/v1/orgs/{slug}/invites (send invite, admin only)
  - GET  /api/v1/orgs/{slug}/users   (list members, admin only)
  - DELETE /api/v1/orgs/{slug}/users/{id} (remove member, admin only)
"""

from __future__ import annotations

import time

import pytest

from crucihil.server.api.v1.auth import _reset_rate_limiter
from crucihil.server.models.org import OrgRow
from crucihil.server.models.user import UserRow
from crucihil.server.services.auth import generate_invite_token, hash_invite_token


# ── Helpers ────────────────────────────────────────────────────────────────────


def _setup(client, org_name="Acme", email="founder@acme.io", password="securePass1"):
    return client.post(
        "/api/v1/setup",
        json={"org_name": org_name, "admin_email": email, "admin_password": password},
    )


def _login(client, email, password):
    return client.post("/api/v1/auth/login", json={"email": email, "password": password})


def _auth(token):
    return {"Authorization": f"Bearer {token}"}


# ── POST /setup ───────────────────────────────────────────────────────────────


def test_setup_creates_org_and_admin(client, db_session):
    resp = _setup(client)
    assert resp.status_code == 201
    data = resp.json()
    assert "access_token" in data
    assert data["org_slug"] == "acme"

    org = db_session.query(OrgRow).filter_by(slug="acme").first()
    assert org is not None
    user = db_session.query(UserRow).filter_by(email="founder@acme.io").first()
    assert user is not None
    assert user.role == "admin"
    assert user.password_hash is not None


def test_setup_jwt_is_user_type(client):
    from crucihil.server.services.auth import decode_jwt
    resp = _setup(client)
    payload = decode_jwt(resp.json()["access_token"])
    assert payload["type"] == "user"
    assert payload["role"] == "admin"


def test_setup_slug_derived_from_org_name(client):
    resp = _setup(client, org_name="My Cool Org")
    assert resp.json()["org_slug"] == "my-cool-org"


def test_setup_rejects_second_call(client):
    _setup(client)
    resp = _setup(client, email="second@acme.io")
    assert resp.status_code == 409


def test_setup_requires_min_password_length(client):
    resp = _setup(client, password="short")
    assert resp.status_code == 422


# ── POST /auth/login ──────────────────────────────────────────────────────────


def test_login_success(client, admin_user):
    resp = _login(client, "admin@test.example", "password123")
    assert resp.status_code == 200
    assert "access_token" in resp.json()


def test_login_returns_user_jwt(client, admin_user):
    from crucihil.server.services.auth import decode_jwt
    resp = _login(client, "admin@test.example", "password123")
    payload = decode_jwt(resp.json()["access_token"])
    assert payload["type"] == "user"
    assert payload["role"] == "admin"
    assert payload["org_id"] == admin_user.org_id


def test_login_wrong_password_returns_401(client, admin_user):
    resp = _login(client, "admin@test.example", "wrongpassword")
    assert resp.status_code == 401


def test_login_unknown_email_returns_401(client):
    resp = _login(client, "nobody@nowhere.io", "password123")
    assert resp.status_code == 401


def test_login_unknown_vs_wrong_password_same_error(client, admin_user):
    r1 = _login(client, "nobody@nowhere.io", "password123")
    r2 = _login(client, "admin@test.example", "wrongpassword")
    assert r1.json()["detail"] == r2.json()["detail"]


def test_login_rate_limited(client, admin_user):
    _reset_rate_limiter()
    for _ in range(5):
        _login(client, "admin@test.example", "wrong")
    resp = _login(client, "admin@test.example", "password123")
    assert resp.status_code == 429
    _reset_rate_limiter()


def test_login_email_case_insensitive(client, admin_user):
    resp = _login(client, "ADMIN@TEST.EXAMPLE", "password123")
    assert resp.status_code == 200


# ── GET /auth/invite/{token} ──────────────────────────────────────────────────


def _seed_invite(db_session, org, email="invitee@test.example", role="member", expired=False):
    from crucihil.server.services.auth import generate_invite_token, hash_invite_token
    raw = generate_invite_token()
    ttl = -1 if expired else 72 * 3600
    user = UserRow(
        org_id=org.id,
        email=email,
        password_hash=None,
        role=role,
        invite_token_hash=hash_invite_token(raw),
        invite_token_expires_at=time.time() + ttl,
        joined_at=None,
        created_at=time.time(),
    )
    db_session.add(user)
    db_session.commit()
    return raw, user


def test_invite_validate_returns_email_and_org(client, db_session, org):
    raw, _ = _seed_invite(db_session, org)
    resp = client.get(f"/api/v1/auth/invite/{raw}")
    assert resp.status_code == 200
    data = resp.json()
    assert data["email"] == "invitee@test.example"
    assert data["org_name"] == "Test Org"


def test_invite_validate_expired_returns_404(client, db_session, org):
    raw, _ = _seed_invite(db_session, org, email="expired@test.example", expired=True)
    resp = client.get(f"/api/v1/auth/invite/{raw}")
    assert resp.status_code == 404


def test_invite_validate_unknown_token_returns_404(client):
    resp = client.get("/api/v1/auth/invite/totallybogustoken")
    assert resp.status_code == 404


# ── POST /auth/invite/accept ──────────────────────────────────────────────────


def test_invite_accept_sets_password_returns_jwt(client, db_session, org):
    raw, user = _seed_invite(db_session, org, email="newuser@test.example")
    resp = client.post("/api/v1/auth/invite/accept", json={"token": raw, "password": "newpassword1"})
    assert resp.status_code == 200
    assert "access_token" in resp.json()

    db_session.refresh(user)
    assert user.password_hash is not None
    assert user.invite_token_hash is None
    assert user.joined_at is not None


def test_invite_accept_token_is_single_use(client, db_session, org):
    raw, _ = _seed_invite(db_session, org, email="once@test.example")
    client.post("/api/v1/auth/invite/accept", json={"token": raw, "password": "password123"})
    resp = client.post("/api/v1/auth/invite/accept", json={"token": raw, "password": "password123"})
    assert resp.status_code == 404


def test_invite_accept_wrong_token_returns_404(client):
    resp = client.post("/api/v1/auth/invite/accept", json={"token": "bogus", "password": "password123"})
    assert resp.status_code == 404


def test_invite_accept_password_too_short_returns_422(client, db_session, org):
    raw, _ = _seed_invite(db_session, org, email="short@test.example")
    resp = client.post("/api/v1/auth/invite/accept", json={"token": raw, "password": "short"})
    assert resp.status_code == 422


# ── POST /orgs/{slug}/invites ─────────────────────────────────────────────────


def test_admin_can_invite_member(client, org, admin_user_headers, db_session):
    resp = client.post(
        "/api/v1/orgs/test-org/invites",
        json={"email": "newbie@test.example", "role": "member"},
        headers=admin_user_headers,
    )
    assert resp.status_code == 201
    user = db_session.query(UserRow).filter_by(email="newbie@test.example").first()
    assert user is not None
    assert user.invite_token_hash is not None


def test_member_cannot_invite(client, member_user_headers):
    resp = client.post(
        "/api/v1/orgs/test-org/invites",
        json={"email": "x@y.com", "role": "member"},
        headers=member_user_headers,
    )
    assert resp.status_code == 403


def test_invite_duplicate_email_returns_409(client, org, admin_user, admin_user_headers):
    resp = client.post(
        "/api/v1/orgs/test-org/invites",
        json={"email": admin_user.email, "role": "member"},
        headers=admin_user_headers,
    )
    assert resp.status_code == 409


def test_rig_token_cannot_invite(client, auth_headers):
    resp = client.post(
        "/api/v1/orgs/test-org/invites",
        json={"email": "x@y.com", "role": "member"},
        headers=auth_headers,
    )
    assert resp.status_code == 401


# ── GET /orgs/{slug}/users ────────────────────────────────────────────────────


def test_admin_can_list_users(client, org, admin_user, member_user, admin_user_headers):
    resp = client.get("/api/v1/orgs/test-org/users", headers=admin_user_headers)
    assert resp.status_code == 200
    emails = [u["email"] for u in resp.json()]
    assert "admin@test.example" in emails
    assert "member@test.example" in emails


def test_member_cannot_list_users(client, org, member_user_headers):
    resp = client.get("/api/v1/orgs/test-org/users", headers=member_user_headers)
    assert resp.status_code == 403


# ── DELETE /orgs/{slug}/users/{id} ───────────────────────────────────────────


def test_admin_can_remove_member(client, org, admin_user_headers, member_user, db_session):
    user_id = member_user.id  # capture before expire_all clears the identity map
    resp = client.delete(
        f"/api/v1/orgs/test-org/users/{user_id}",
        headers=admin_user_headers,
    )
    assert resp.status_code == 204
    db_session.expire_all()
    assert db_session.get(UserRow, user_id) is None


def test_admin_cannot_remove_self(client, org, admin_user, admin_user_headers):
    resp = client.delete(
        f"/api/v1/orgs/test-org/users/{admin_user.id}",
        headers=admin_user_headers,
    )
    assert resp.status_code == 409


def test_remove_nonexistent_user_returns_404(client, org, admin_user_headers):
    resp = client.delete("/api/v1/orgs/test-org/users/doesnotexist", headers=admin_user_headers)
    assert resp.status_code == 404


# ── POST /auth/forgot-password ───────────────────────────────────────────────


def _seed_reset_token(db_session, user, expired=False):
    from crucihil.server.services.auth import generate_password_reset_token, hash_password_reset_token
    raw = generate_password_reset_token()
    ttl = -1 if expired else 3600
    user.password_reset_token_hash = hash_password_reset_token(raw)
    user.password_reset_token_expires_at = time.time() + ttl
    db_session.commit()
    return raw


def test_forgot_password_always_returns_200(client):
    resp = client.post("/api/v1/auth/forgot-password", json={"email": "nobody@nowhere.io"})
    assert resp.status_code == 200
    assert "reset link" in resp.json()["message"].lower()


def test_forgot_password_returns_200_for_valid_user(client, admin_user):
    resp = client.post("/api/v1/auth/forgot-password", json={"email": admin_user.email})
    assert resp.status_code == 200


def test_forgot_password_sets_token_on_valid_user(client, admin_user, db_session):
    client.post("/api/v1/auth/forgot-password", json={"email": admin_user.email})
    db_session.refresh(admin_user)
    assert admin_user.password_reset_token_hash is not None
    assert admin_user.password_reset_token_expires_at is not None


def test_forgot_password_unknown_email_does_not_set_token(client, admin_user, db_session):
    client.post("/api/v1/auth/forgot-password", json={"email": "nobody@nowhere.io"})
    db_session.refresh(admin_user)
    assert admin_user.password_reset_token_hash is None


def test_forgot_password_rate_limited(client, admin_user):
    from crucihil.server.api.v1.auth import _reset_reset_rate_limiter
    _reset_reset_rate_limiter()
    for _ in range(5):
        client.post("/api/v1/auth/forgot-password", json={"email": admin_user.email})
    resp = client.post("/api/v1/auth/forgot-password", json={"email": admin_user.email})
    assert resp.status_code == 429
    _reset_reset_rate_limiter()


# ── GET /auth/password-reset/{token} ─────────────────────────────────────────


def test_validate_reset_token_returns_email(client, admin_user, db_session):
    raw = _seed_reset_token(db_session, admin_user)
    resp = client.get(f"/api/v1/auth/password-reset/{raw}")
    assert resp.status_code == 200
    assert resp.json()["email"] == admin_user.email


def test_validate_reset_token_expired_returns_404(client, admin_user, db_session):
    raw = _seed_reset_token(db_session, admin_user, expired=True)
    resp = client.get(f"/api/v1/auth/password-reset/{raw}")
    assert resp.status_code == 404


def test_validate_reset_token_unknown_returns_404(client):
    resp = client.get("/api/v1/auth/password-reset/totallybogustoken")
    assert resp.status_code == 404


# ── POST /auth/reset-password ─────────────────────────────────────────────────


def test_reset_password_success(client, admin_user, db_session):
    raw = _seed_reset_token(db_session, admin_user)
    resp = client.post("/api/v1/auth/reset-password", json={"token": raw, "password": "newpassword1"})
    assert resp.status_code == 200
    assert "access_token" in resp.json()


def test_reset_password_clears_token(client, admin_user, db_session):
    raw = _seed_reset_token(db_session, admin_user)
    client.post("/api/v1/auth/reset-password", json={"token": raw, "password": "newpassword1"})
    db_session.refresh(admin_user)
    assert admin_user.password_reset_token_hash is None
    assert admin_user.password_reset_token_expires_at is None


def test_reset_password_token_is_single_use(client, admin_user, db_session):
    raw = _seed_reset_token(db_session, admin_user)
    client.post("/api/v1/auth/reset-password", json={"token": raw, "password": "newpassword1"})
    resp = client.post("/api/v1/auth/reset-password", json={"token": raw, "password": "another123"})
    assert resp.status_code == 404


def test_reset_password_new_password_works_for_login(client, admin_user, db_session):
    raw = _seed_reset_token(db_session, admin_user)
    client.post("/api/v1/auth/reset-password", json={"token": raw, "password": "brandnew99"})
    resp = _login(client, admin_user.email, "brandnew99")
    assert resp.status_code == 200


def test_reset_password_wrong_token_returns_404(client):
    resp = client.post("/api/v1/auth/reset-password", json={"token": "bogus", "password": "password123"})
    assert resp.status_code == 404


def test_reset_password_too_short_returns_422(client, admin_user, db_session):
    raw = _seed_reset_token(db_session, admin_user)
    resp = client.post("/api/v1/auth/reset-password", json={"token": raw, "password": "short"})
    assert resp.status_code == 422


def test_reset_password_returns_user_jwt(client, admin_user, db_session):
    from crucihil.server.services.auth import decode_jwt
    raw = _seed_reset_token(db_session, admin_user)
    resp = client.post("/api/v1/auth/reset-password", json={"token": raw, "password": "newpassword1"})
    payload = decode_jwt(resp.json()["access_token"])
    assert payload["type"] == "user"
    assert payload["sub"] == admin_user.id
