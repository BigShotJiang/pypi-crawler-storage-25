"""Integration tests: /api/v1/runs endpoints."""

import time
import uuid

import pytest

from crucihil.server.models.run import TestRunRow


def _seed_run(db_session, rig_id: str, status: str = "pass") -> str:
    run_id = str(uuid.uuid4())
    run = TestRunRow(
        id=run_id,
        rig_id=rig_id,
        suite_name="engine_suite",
        started_at=time.time(),
        completed_at=time.time() + 5.0,
        status=status,
        total=2,
        passed=2 if status == "pass" else 1,
        failed=0 if status == "pass" else 1,
    )
    db_session.add(run)
    db_session.commit()
    return run_id


def test_list_runs_empty(client, registered_rig, auth_headers):
    resp = client.get("/api/v1/runs", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.json() == []


def test_list_runs_with_data(client, registered_rig, db_session, auth_headers):
    rig, _ = registered_rig
    _seed_run(db_session, rig.id)
    resp = client.get("/api/v1/runs", headers=auth_headers)
    assert resp.status_code == 200
    assert len(resp.json()) == 1


def test_get_run_ok(client, registered_rig, db_session, auth_headers):
    rig, _ = registered_rig
    run_id = _seed_run(db_session, rig.id)
    resp = client.get(f"/api/v1/runs/{run_id}", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.json()["id"] == run_id


def test_get_run_not_found(client, registered_rig, auth_headers):
    resp = client.get("/api/v1/runs/no-such-run", headers=auth_headers)
    assert resp.status_code == 404


def test_cancel_run(client, registered_rig, db_session, auth_headers):
    rig, _ = registered_rig
    run_id = _seed_run(db_session, rig.id, status="running")
    resp = client.post(f"/api/v1/runs/{run_id}/cancel", headers=auth_headers)
    assert resp.status_code == 202
    detail = client.get(f"/api/v1/runs/{run_id}", headers=auth_headers).json()
    assert detail["status"] == "cancelled"


def test_cancel_run_already_terminal(client, registered_rig, db_session, auth_headers):
    rig, _ = registered_rig
    run_id = _seed_run(db_session, rig.id, status="pass")
    resp = client.post(f"/api/v1/runs/{run_id}/cancel", headers=auth_headers)
    assert resp.status_code == 409


def test_filter_runs_by_status(client, registered_rig, db_session, auth_headers):
    rig, _ = registered_rig
    _seed_run(db_session, rig.id, status="pass")
    _seed_run(db_session, rig.id, status="fail")
    resp = client.get("/api/v1/runs?status=fail", headers=auth_headers)
    runs = resp.json()
    assert all(r["status"] == "fail" for r in runs)
    assert len(runs) == 1


# ── report endpoints ──────────────────────────────────────────────────────────

def _seed_run_with_results(db_session, rig_id: str):
    """Seed a run plus two results so reports have data."""
    import json as _json
    from crucihil.server.models.result import TestResultRow

    run_id = _seed_run(db_session, rig_id, status="pass")
    now = time.time()
    for i, (tid, st) in enumerate([("test_start", "passed"), ("test_stop", "failed")]):
        row = TestResultRow(
            test_id=tid,
            run_id=run_id,
            suite_name="engine_suite",
            status=st,
            duration=1.5,
            started_at=now + i,
            completed_at=now + i + 1.5,
            errors=_json.dumps(["assertion failed"] if st == "failed" else []),
            logs=_json.dumps(["log line"]),
            signals=_json.dumps({}),
            extra_meta=_json.dumps({"tags": ["smoke"], "priority": "high"}),
        )
        db_session.add(row)
    db_session.commit()
    return run_id


def test_report_xml_ok(client, registered_rig, db_session, auth_headers):
    rig, _ = registered_rig
    run_id = _seed_run_with_results(db_session, rig.id)
    resp = client.get(f"/api/v1/runs/{run_id}/report.xml", headers=auth_headers)
    assert resp.status_code == 200
    assert "application/xml" in resp.headers["content-type"]
    assert b"<testsuite" in resp.content
    assert b"test_start" in resp.content
    assert b"test_stop" in resp.content


def test_report_xml_has_failure_element(client, registered_rig, db_session, auth_headers):
    rig, _ = registered_rig
    run_id = _seed_run_with_results(db_session, rig.id)
    resp = client.get(f"/api/v1/runs/{run_id}/report.xml", headers=auth_headers)
    assert b"<failure" in resp.content
    assert b"assertion failed" in resp.content


def test_report_xml_content_disposition(client, registered_rig, db_session, auth_headers):
    rig, _ = registered_rig
    run_id = _seed_run_with_results(db_session, rig.id)
    resp = client.get(f"/api/v1/runs/{run_id}/report.xml", headers=auth_headers)
    assert "attachment" in resp.headers.get("content-disposition", "")
    assert ".xml" in resp.headers.get("content-disposition", "")


def test_report_xml_not_found(client, registered_rig, auth_headers):
    resp = client.get("/api/v1/runs/no-such-run/report.xml", headers=auth_headers)
    assert resp.status_code == 404


def test_report_html_ok(client, registered_rig, db_session, auth_headers):
    rig, _ = registered_rig
    run_id = _seed_run_with_results(db_session, rig.id)
    resp = client.get(f"/api/v1/runs/{run_id}/report.html", headers=auth_headers)
    assert resp.status_code == 200
    assert "text/html" in resp.headers["content-type"]
    assert b"engine_suite" in resp.content
    assert b"test_start" in resp.content


def test_report_html_shows_tags(client, registered_rig, db_session, auth_headers):
    rig, _ = registered_rig
    run_id = _seed_run_with_results(db_session, rig.id)
    resp = client.get(f"/api/v1/runs/{run_id}/report.html", headers=auth_headers)
    assert b"smoke" in resp.content


def test_report_html_not_found(client, registered_rig, auth_headers):
    resp = client.get("/api/v1/runs/no-such-run/report.html", headers=auth_headers)
    assert resp.status_code == 404
