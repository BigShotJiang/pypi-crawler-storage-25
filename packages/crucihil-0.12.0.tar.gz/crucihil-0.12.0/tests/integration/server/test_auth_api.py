"""Integration tests: POST /api/v1/auth/token."""

import time

import pytest

from crucihil.server.models.rig import RigRow
from crucihil.server.services.auth import generate_api_key, hash_api_key


def test_token_valid_key(client, registered_rig):
    _, raw_key = registered_rig
    resp = client.post("/api/v1/auth/token", json={"api_key": raw_key})
    assert resp.status_code == 200
    data = resp.json()
    assert data["token_type"] == "bearer"
    assert len(data["access_token"]) > 20
    assert data["expires_in"] > 0


def test_token_wrong_key(client, registered_rig):
    resp = client.post("/api/v1/auth/token", json={"api_key": "crucihil-rig-wrongkey"})
    assert resp.status_code == 401


def test_token_empty_key(client):
    resp = client.post("/api/v1/auth/token", json={"api_key": ""})
    assert resp.status_code == 401
