import { useEffect } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { getWsViewerUrl } from '../lib/api'
import { isTerminal, type ResultSummary, type RunStatus, type TestStatus } from '../types/api'

interface WsResultPayload {
  test_id: string
  suite_name: string
  status: string
  duration: number
  started_at: number
  completed_at: number
  error_message?: string | null
}

interface WsMessage {
  type: string
  run_id?: string
  result?: WsResultPayload
}

export function useRunStream(runId: string, runStatus: RunStatus | undefined) {
  const queryClient = useQueryClient()

  useEffect(() => {
    if (!runId || isTerminal(runStatus)) return

    const token = localStorage.getItem('crucihil_jwt')
    if (!token) return

    const url = `${getWsViewerUrl(runId)}&token=${encodeURIComponent(token)}`
    let ws: WebSocket

    try {
      ws = new WebSocket(url)
    } catch {
      return
    }

    ws.onmessage = (event: MessageEvent<string>) => {
      let msg: WsMessage
      try {
        msg = JSON.parse(event.data) as WsMessage
      } catch {
        return
      }

      if (msg.type !== 'result' || msg.run_id !== runId || !msg.result) return

      const incoming = msg.result
      queryClient.setQueryData<ResultSummary[]>(
        ['results', runId],
        (prev) => {
          const existing = prev ?? []
          if (existing.some((r) => r.test_id === incoming.test_id)) {
            return existing
          }
          const next: ResultSummary = {
            id: -(existing.length + 1), // negative temp ID; real ID set on next poll
            test_id: incoming.test_id,
            run_id: runId,
            suite_name: incoming.suite_name,
            status: incoming.status as TestStatus,
            duration: incoming.duration,
            started_at: incoming.started_at,
            completed_at: incoming.completed_at,
            error_message: incoming.error_message ?? null,
            tags: [],
            suite_types: [],
            priority: null,
          }
          return [...existing, next]
        },
      )
    }

    ws.onerror = () => {
      // Silently ignore — agent may not be connected yet. Polling is fallback.
    }

    return () => {
      ws.close()
    }
  }, [runId, runStatus, queryClient])
}
