import { useQuery } from '@tanstack/react-query'
import { Link, useNavigate } from 'react-router-dom'
import { format, differenceInSeconds, startOfDay } from 'date-fns'
import { Server } from 'lucide-react'
import api from '../lib/api'
import type { RigDetail, RunSummary } from '../types/api'
import { RigOnlineIndicator } from '../components/RigOnlineIndicator'
import { StatusBadge } from '../components/StatusBadge'
import { Skeleton } from '../components/Skeleton'
import { EmptyState, ErrorDisplay } from '../components/PageStates'

function PassBar({ passed, total }: { passed: number; total: number }) {
  if (total === 0) return <div className="bar-track" />
  const pct = (passed / total) * 100
  const color = pct >= 90 ? 'bg-pass' : pct >= 60 ? 'bg-warn' : 'bg-fail'
  return (
    <div className="bar-track">
      <div className={`h-full ${color} rounded-sm transition-all duration-700`} style={{ width: `${pct}%` }} />
    </div>
  )
}

// Grafana-style Stat panel: large mono value + small label, optional color accent bar
function StatCard({
  label,
  value,
  sub,
  valueColor,
}: {
  label: string
  value: string | number
  sub?: string
  valueColor?: string
}) {
  return (
    <div className="card-base flex flex-col overflow-hidden">
      <div className="panel-header">
        <span className="panel-title">{label}</span>
      </div>
      <div className="px-4 py-5 flex-1 flex flex-col justify-center">
        <p className={`stat-value ${valueColor ?? 'text-white'}`}>{value}</p>
        {sub && <p className="stat-label mt-1.5">{sub}</p>}
      </div>
    </div>
  )
}

export function DashboardPage() {
  const navigate = useNavigate()

  const { data: rigs, isLoading: rigsLoading, error: rigsError } = useQuery<RigDetail[]>({
    queryKey: ['rigs'],
    queryFn: () => api.get<RigDetail[]>('/api/v1/rigs').then((r) => r.data),
    refetchInterval: 15_000,
  })

  const { data: runs, isLoading: runsLoading, error: runsError } = useQuery<RunSummary[]>({
    queryKey: ['runs', { limit: 20 }],
    queryFn: () => api.get<RunSummary[]>('/api/v1/runs?limit=20').then((r) => r.data),
    refetchInterval: 10_000,
  })

  const rigById = Object.fromEntries((rigs ?? []).map((r) => [r.id, r]))

  // Computed stats
  const onlineCount = (rigs ?? []).filter(
    (r) => r.last_seen_at !== null && differenceInSeconds(new Date(), new Date(r.last_seen_at * 1000)) <= 90
  ).length
  const todayStart = startOfDay(new Date()).getTime() / 1000
  const runsToday = (runs ?? []).filter((r) => r.started_at >= todayStart).length
  const activeRuns = (runs ?? []).filter((r) => r.status === 'running' || r.status === 'queued').length
  const completedRuns = (runs ?? []).filter((r) => r.total > 0 && (r.status === 'passed' || r.status === 'failed'))
  const passRate = completedRuns.length > 0
    ? Math.round(completedRuns.reduce((acc, r) => acc + r.passed / r.total, 0) / completedRuns.length * 100)
    : null

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-sm text-muted mt-1">Overview of your HiL testing infrastructure</p>
      </div>

      {/* Stat panels — Grafana style */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard
          label="Rigs online"
          value={rigsLoading ? '…' : `${onlineCount} / ${rigs?.length ?? 0}`}
          valueColor={onlineCount > 0 ? 'text-pass' : 'text-muted'}
        />
        <StatCard
          label="Runs today"
          value={runsLoading ? '…' : runsToday}
          sub={activeRuns > 0 ? `${activeRuns} active` : undefined}
          valueColor={activeRuns > 0 ? 'text-accent-light' : 'text-white'}
        />
        <StatCard
          label="Pass rate"
          value={passRate !== null ? `${passRate}%` : '—'}
          sub="last 20 runs"
          valueColor={passRate === null ? 'text-muted' : passRate >= 80 ? 'text-pass' : passRate >= 60 ? 'text-warn' : 'text-fail'}
        />
        <StatCard
          label="Active runs"
          value={runsLoading ? '…' : activeRuns}
          valueColor={activeRuns > 0 ? 'text-accent-light' : 'text-muted'}
        />
      </div>

      {/* Rigs */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="panel-title text-muted">Rigs</h2>
          <Link to="/rigs" className="text-xs text-accent-light hover:text-accent-light/70 transition-colors">
            View all
          </Link>
        </div>

        {rigsError ? (
          <ErrorDisplay message="Failed to load rigs." />
        ) : rigsLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-28" />)}
          </div>
        ) : !rigs?.length ? (
          <EmptyState
            icon={<Server size={22} />}
            message="No rigs registered yet."
            sub="Run ./setup.sh to register your first rig."
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {rigs.map((rig) => (
              <Link key={rig.id} to={`/rigs/${rig.id}`}>
                <div className="card-base card-hover cursor-pointer h-full flex flex-col overflow-hidden">
                  <div className="panel-header">
                    <div className="flex items-center gap-2">
                      <Server size={13} className="text-muted flex-shrink-0" />
                      <span className="font-medium text-xs text-white truncate">{rig.name}</span>
                    </div>
                    {rig.version && (
                      <span className="text-xs text-subtle font-mono flex-shrink-0">v{rig.version}</span>
                    )}
                  </div>
                  <div className="px-4 py-3">
                    <RigOnlineIndicator lastSeenAt={rig.last_seen_at} />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* Recent runs */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="panel-title text-muted">Recent Runs</h2>
          <Link to="/runs" className="text-xs text-accent-light hover:text-accent-light/70 transition-colors">
            View all
          </Link>
        </div>

        {runsError ? (
          <ErrorDisplay message="Failed to load runs." />
        ) : runsLoading ? (
          <Skeleton className="h-48" />
        ) : !runs?.length ? (
          <EmptyState message="No test runs yet." sub="Trigger a run via the CLI or MCP." />
        ) : (
          <div className="card-base overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[rgba(204,204,220,0.09)]">
                  <th className="text-left px-4 py-2.5 text-xs text-muted font-medium tracking-wide uppercase">Suite</th>
                  <th className="text-left px-4 py-2.5 text-xs text-muted font-medium tracking-wide uppercase hidden sm:table-cell">Rig</th>
                  <th className="text-left px-4 py-2.5 text-xs text-muted font-medium tracking-wide uppercase">Status</th>
                  <th className="text-left px-4 py-2.5 text-xs text-muted font-medium tracking-wide uppercase hidden md:table-cell">Started</th>
                  <th className="px-4 py-2.5 text-xs text-muted font-medium tracking-wide uppercase text-right hidden lg:table-cell">Pass</th>
                </tr>
              </thead>
              <tbody>
                {runs.map((run, i) => (
                  <tr
                    key={run.id}
                    className={`hover:bg-white/[0.03] cursor-pointer transition-colors ${i < runs.length - 1 ? 'border-b border-[rgba(204,204,220,0.06)]' : ''}`}
                    onClick={() => void navigate(`/runs/${run.id}`)}
                  >
                    <td className="px-4 py-2.5">
                      <span className="text-sm text-white truncate block max-w-[180px] font-mono">{run.suite_name}</span>
                    </td>
                    <td className="px-4 py-2.5 hidden sm:table-cell">
                      <span className="text-xs text-muted font-mono">{rigById[run.rig_id]?.name ?? run.rig_id.slice(0, 8) + '…'}</span>
                    </td>
                    <td className="px-4 py-2.5">
                      <StatusBadge status={run.status} />
                    </td>
                    <td className="px-4 py-2.5 hidden md:table-cell">
                      <span className="text-xs text-muted font-mono">{format(new Date(run.started_at * 1000), 'MMM d, HH:mm')}</span>
                    </td>
                    <td className="px-4 py-2.5 hidden lg:table-cell">
                      {run.total > 0 ? (
                        <div className="flex items-center gap-2 justify-end">
                          <div className="w-20">
                            <PassBar passed={run.passed} total={run.total} />
                          </div>
                          <span className="text-xs text-muted font-mono w-9 text-right flex-shrink-0">
                            {Math.round((run.passed / run.total) * 100)}%
                          </span>
                        </div>
                      ) : (
                        <span className="text-xs text-subtle text-right block">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  )
}
