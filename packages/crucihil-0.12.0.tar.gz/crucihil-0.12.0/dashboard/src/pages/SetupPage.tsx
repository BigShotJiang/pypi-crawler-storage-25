import { useState, type FormEvent } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { AlertCircle, Eye, EyeOff, Zap, ArrowRight, Building2 } from 'lucide-react'
import axios from 'axios'
import { useAuth } from '../hooks/useAuth'
import api from '../lib/api'

interface SetupResponse {
  access_token: string
  token_type: string
  org_slug: string
}

export function SetupPage() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [orgName, setOrgName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (password !== confirm) {
      setError('Passwords do not match.')
      return
    }
    setLoading(true)
    setError(null)
    try {
      const res = await api.post<SetupResponse>('/api/v1/setup', {
        org_name: orgName.trim(),
        admin_email: email.trim().toLowerCase(),
        admin_password: password,
      })
      login(res.data.access_token)
      void navigate('/', { replace: true })
    } catch (err) {
      if (axios.isAxiosError(err) && err.response?.status === 409) {
        // Platform already initialised — redirect to login.
        void navigate('/login')
        return
      }
      const detail =
        axios.isAxiosError(err) && typeof err.response?.data?.detail === 'string'
          ? err.response.data.detail
          : 'Setup failed. Check the details and try again.'
      setError(detail)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-base flex flex-col items-center justify-center px-6 py-12">
      <div className="w-full max-w-sm animate-slide-up">
        {/* Logo */}
        <div className="flex items-center gap-2.5 mb-10">
          <div className="w-7 h-7 rounded bg-accent/20 border border-accent/40 flex items-center justify-center">
            <Zap size={14} className="text-accent-light" />
          </div>
          <span className="font-bold text-base tracking-tight text-white">CruciHiL</span>
        </div>

        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-3">
            <Building2 size={15} className="text-accent-light" />
            <span className="text-xs text-accent-light font-medium">First-time setup</span>
          </div>
          <h2 className="text-2xl font-bold text-white mb-1.5">Create your organization</h2>
          <p className="text-sm text-muted">
            This creates the first admin account. You can invite teammates from the
            Settings page afterwards.
          </p>
        </div>

        <form onSubmit={(e) => { void handleSubmit(e) }} className="space-y-4">
          {/* Org name */}
          <div>
            <label className="block text-sm font-medium text-white/80 mb-2">
              Organization name
            </label>
            <input
              type="text"
              value={orgName}
              onChange={(e) => setOrgName(e.target.value)}
              placeholder="Acme Robotics"
              required
              minLength={2}
              maxLength={256}
              autoFocus
              autoComplete="organization"
              className="w-full bg-card border border-[rgba(204,204,220,0.12)] rounded px-4 py-2.5 text-sm text-white placeholder:text-subtle focus:outline-none focus:ring-1 focus:ring-accent/60 focus:border-accent/60 transition-all"
            />
          </div>

          {/* Admin email */}
          <div>
            <label className="block text-sm font-medium text-white/80 mb-2">
              Admin email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@company.com"
              required
              autoComplete="email"
              className="w-full bg-card border border-[rgba(204,204,220,0.12)] rounded px-4 py-2.5 text-sm text-white placeholder:text-subtle focus:outline-none focus:ring-1 focus:ring-accent/60 focus:border-accent/60 transition-all"
            />
          </div>

          {/* Password */}
          <div>
            <label className="block text-sm font-medium text-white/80 mb-2">
              Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 8 characters"
                required
                minLength={8}
                maxLength={128}
                autoComplete="new-password"
                className="w-full bg-card border border-[rgba(204,204,220,0.12)] rounded px-4 py-2.5 text-sm text-white placeholder:text-subtle focus:outline-none focus:ring-1 focus:ring-accent/60 focus:border-accent/60 transition-all pr-10"
              />
              <button
                type="button"
                tabIndex={-1}
                onClick={() => setShowPassword((v) => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-white transition-colors"
              >
                {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
          </div>

          {/* Confirm password */}
          <div>
            <label className="block text-sm font-medium text-white/80 mb-2">
              Confirm password
            </label>
            <input
              type={showPassword ? 'text' : 'password'}
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              placeholder="Repeat your password"
              required
              autoComplete="new-password"
              className="w-full bg-card border border-[rgba(204,204,220,0.12)] rounded px-4 py-2.5 text-sm text-white placeholder:text-subtle focus:outline-none focus:ring-1 focus:ring-accent/60 focus:border-accent/60 transition-all"
            />
          </div>

          {error && (
            <div className="flex items-start gap-2 text-xs text-fail bg-fail/[0.08] border border-fail/20 rounded-lg px-3 py-2.5">
              <AlertCircle size={13} className="flex-shrink-0 mt-0.5" />
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading || !orgName.trim() || !email.trim() || !password || !confirm}
            className="w-full flex items-center justify-center gap-2 bg-accent hover:bg-accent-dim disabled:opacity-40 disabled:cursor-not-allowed text-white rounded py-2.5 text-sm font-medium transition-colors"
          >
            {loading ? (
              <>
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Creating organization…
              </>
            ) : (
              <>
                Create organization
                <ArrowRight size={15} />
              </>
            )}
          </button>
        </form>

        <p className="text-xs text-muted text-center mt-6">
          Already have an account?{' '}
          <Link to="/login" className="text-accent-light hover:underline">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  )
}
