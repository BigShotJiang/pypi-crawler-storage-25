import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { ChevronLeft, Server, Trash2, Play } from 'lucide-react'
import { useState } from 'react'
import { format } from 'date-fns'
import api from '../lib/api'
import type { RigDetail, RunSummary } from '../types/api'
import { RigOnlineIndicator } from '../components/RigOnlineIndicator'
import { StatusBadge } from '../components/StatusBadge'
import { Skeleton, SkeletonRows } from '../components/Skeleton'
import { EmptyState, ErrorDisplay } from '../components/PageStates'
import { useAuth } from '../hooks/useAuth'
import { RunSuiteModal } from './RunsPage'

export function RigDetailPage() {
  const { rigId } = useParams<{ rigId: string }>()
  const navigate = useNavigate()
  const { role } = useAuth()
  const qc = useQueryClient()
  const [showRunModal, setShowRunModal] = useState(false)

  const { data: rigs, isLoading: rigsLoading } = useQuery<RigDetail[]>({
    queryKey: ['rigs'],
    queryFn: () => api.get<RigDetail[]>('/api/v1/rigs').then((r) => r.data),
    refetchInterval: 15_000,
  })

  const rig = rigId ? rigs?.find((r) => r.id === rigId) : undefined

  const deleteMutation = useMutation({
    mutationFn: () => api.delete(`/api/v1/rigs/${rig?.name}`),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['rigs'] })
      void navigate('/rigs')
    },
  })

  function handleDelete() {
    if (!rig) return
    if (window.confirm(`Delete rig "${rig.name}"? This cannot be undone. Stop the agent first.`)) {
      deleteMutation.mutate()
    }
  }

  const { data: runs, isLoading: runsLoading, error: runsError } = useQuery<RunSummary[]>({
    queryKey: ['runs', { rigName: rig?.name }],
    queryFn: () =>
      api.get<RunSummary[]>(`/api/v1/runs?rig_name=${encodeURIComponent(rig?.name ?? '')}&limit=25`).then((r) => r.data),
    enabled: !!rig,
    refetchInterval: 10_000,
  })

  if (rigsLoading) {
    return (
      <div className="space-y-5 max-w-3xl animate-fade-in">
        <Skeleton className="h-9 w-56" />
        <Skeleton className="h-48" />
      </div>
    )
  }

  if (!rig) {
    return (
      <div className="space-y-4 animate-fade-in">
        <button
          onClick={() => void navigate('/rigs')}
          className="flex items-center gap-1 text-muted hover:text-white text-sm transition-colors"
        >
          <ChevronLeft size={16} /> Back to rigs
        </button>
        <p className="text-muted">Rig not found.</p>
      </div>
    )
  }

  const completedRuns = (runs ?? []).filter((r) => r.total > 0 && (r.status === 'passed' || r.status === 'failed'))
  const overallPassRate = completedRuns.length > 0
    ? Math.round(completedRuns.reduce((acc, r) => acc + r.passed / r.total, 0) / completedRuns.length * 100)
    : null

  return (
    <div className="space-y-6 max-w-3xl animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-2.5">
        <Link to="/rigs" className="text-muted hover:text-white transition-colors flex-shrink-0">
          <ChevronLeft size={18} />
        </Link>
        <div className="w-9 h-9 rounded-xl bg-white/[0.05] border border-white/[0.07] flex items-center justify-center flex-shrink-0">
          <Server size={16} className="text-muted" />
        </div>
        <div className="min-w-0">
          <h1 className="text-xl font-bold text-white">{rig.name}</h1>
        </div>
        <div className="ml-2">
          <RigOnlineIndicator lastSeenAt={rig.last_seen_at} />
        </div>
        {role === 'admin' && (
          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={() => setShowRunModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-accent hover:bg-accent/80 text-white rounded-lg transition-colors"
            >
              <Play size={11} />
              Run Suite
            </button>
            <button
              onClick={handleDelete}
              disabled={deleteMutation.isPending}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-fail border border-fail/20 rounded hover:bg-fail/[0.08] transition-all disabled:opacity-40"
              title="Delete rig"
            >
              <Trash2 size={12} />
              Delete rig
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Details card */}
        <div className="md:col-span-2 card-base p-5">
          <h2 className="text-xs font-semibold text-muted uppercase tracking-widest mb-4">Details</h2>
          <dl className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-3 text-sm">
            <dt className="text-muted self-center">ID</dt>
            <dd className="font-mono text-xs text-muted/80 truncate">{rig.id}</dd>

            {rig.version && (
              <>
                <dt className="text-muted">Agent</dt>
                <dd className="font-mono text-xs">v{rig.version}</dd>
              </>
            )}

            <dt className="text-muted">Last seen</dt>
            <dd className="text-sm">
              {rig.last_seen_at
                ? format(new Date(rig.last_seen_at * 1000), 'MMM d, HH:mm:ss')
                : <span className="text-muted">—</span>}
            </dd>

            <dt className="text-muted">Registered</dt>
            <dd>{format(new Date(rig.created_at * 1000), 'MMM d, yyyy')}</dd>
          </dl>

          {Object.keys(rig.extra_meta).length > 0 && (
            <div className="mt-5 pt-4 border-t border-white/[0.06]">
              <p className="text-xs text-muted uppercase tracking-widest mb-2.5">Config</p>
              <pre className="bg-base rounded-lg p-3 text-xs text-muted/80 font-mono overflow-auto max-h-40 border border-white/[0.05]">
                {JSON.stringify(rig.extra_meta, null, 2)}
              </pre>
            </div>
          )}
        </div>

        {/* Stats card */}
        <div className="card-base p-5 flex flex-col gap-4">
          <h2 className="text-xs font-semibold text-muted uppercase tracking-widest">Stats</h2>
          <div>
            <p className="text-3xl font-bold text-white">{(runs ?? []).length}</p>
            <p className="text-xs text-muted mt-1">Total runs</p>
          </div>
          {overallPassRate !== null && (
            <div>
              <p className={`text-3xl font-bold ${overallPassRate >= 80 ? 'text-pass' : overallPassRate >= 60 ? 'text-warn' : 'text-fail'}`}>
                {overallPassRate}%
              </p>
              <p className="text-xs text-muted mt-1">Pass rate</p>
            </div>
          )}
        </div>
      </div>

      {/* Runs */}
      <section>
        <h2 className="text-sm font-semibold text-white mb-3">Recent Runs</h2>
        {runsError ? (
          <ErrorDisplay message="Failed to load runs." />
        ) : runsLoading ? (
          <SkeletonRows count={4} />
        ) : !runs?.length ? (
          <EmptyState message="No runs for this rig yet." />
        ) : (
          <div className="card-base overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/[0.06]">
                  <th className="text-left px-4 py-3 text-xs text-muted font-medium">Suite</th>
                  <th className="text-left px-4 py-3 text-xs text-muted font-medium">Status</th>
                  <th className="text-left px-4 py-3 text-xs text-muted font-medium hidden sm:table-cell">Started</th>
                  <th className="text-right px-4 py-3 text-xs text-muted font-medium">Pass rate</th>
                </tr>
              </thead>
              <tbody>
                {runs.map((run, i) => (
                  <tr
                    key={run.id}
                    className={`hover:bg-white/[0.02] cursor-pointer transition-colors ${i < runs.length - 1 ? 'border-b border-white/[0.04]' : ''}`}
                    onClick={() => void navigate(`/runs/${run.id}`)}
                  >
                    <td className="px-4 py-3 font-medium text-white truncate max-w-[200px]">{run.suite_name}</td>
                    <td className="px-4 py-3"><StatusBadge status={run.status} /></td>
                    <td className="px-4 py-3 text-muted text-xs hidden sm:table-cell">
                      {format(new Date(run.started_at * 1000), 'MMM d, HH:mm')}
                    </td>
                    <td className="px-4 py-3 text-right text-muted text-xs">
                      {run.total > 0 ? `${run.passed}/${run.total} (${Math.round((run.passed / run.total) * 100)}%)` : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {showRunModal && rigs && (
        <RunSuiteModal
          rigs={rigs}
          defaultRigName={rig.name}
          onClose={() => setShowRunModal(false)}
        />
      )}
    </div>
  )
}
