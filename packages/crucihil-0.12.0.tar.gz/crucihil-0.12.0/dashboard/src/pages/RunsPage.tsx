import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { useState, type FormEvent } from 'react'
import { format } from 'date-fns'
import { Filter, Play, X, AlertCircle } from 'lucide-react'
import api from '../lib/api'
import type { RigDetail, RunSummary, RunStatus } from '../types/api'
import { StatusBadge } from '../components/StatusBadge'
import { Skeleton } from '../components/Skeleton'
import { EmptyState, ErrorDisplay } from '../components/PageStates'
import { useAuth } from '../hooks/useAuth'

const STATUS_OPTIONS: Array<{ value: RunStatus | ''; label: string }> = [
  { value: '', label: 'All statuses' },
  { value: 'queued', label: 'Queued' },
  { value: 'running', label: 'Running' },
  { value: 'passed', label: 'Passed' },
  { value: 'failed', label: 'Failed' },
  { value: 'cancelled', label: 'Cancelled' },
  { value: 'error', label: 'Error' },
]

function MiniPassBar({ passed, failed, blocked, skipped, total }: {
  passed: number; failed: number; blocked: number; skipped: number; total: number
}) {
  if (total === 0) return <span className="text-xs text-muted">—</span>
  const segments = [
    { count: passed, color: 'bg-pass' },
    { count: failed, color: 'bg-fail' },
    { count: blocked, color: 'bg-warn' },
    { count: skipped, color: 'bg-muted/40' },
  ].filter((s) => s.count > 0)
  const pct = Math.round((passed / total) * 100)
  return (
    <div className="flex items-center gap-2 justify-end">
      <div className="w-16 h-1.5 bg-white/[0.06] rounded-full overflow-hidden flex gap-px flex-shrink-0">
        {segments.map(({ count, color }) => (
          <div key={color} className={`h-full ${color}`} style={{ width: `${(count / total) * 100}%` }} />
        ))}
      </div>
      <span className="text-xs text-muted w-9 text-right">{pct}%</span>
    </div>
  )
}

const selectCls = 'bg-surface border border-white/[0.08] rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-accent/40 focus:border-accent/30 transition-all appearance-none cursor-pointer'

// ── Run Suite Modal ────────────────────────────────────────────────────────────

interface CreateRunResponse {
  run_id: string
  agent_notified: boolean
}

export function RunSuiteModal({
  rigs,
  defaultRigName,
  onClose,
}: {
  rigs: RigDetail[]
  defaultRigName?: string
  onClose: () => void
}) {
  const navigate = useNavigate()
  const qc = useQueryClient()
  const [rigName, setRigName] = useState(defaultRigName ?? rigs[0]?.name ?? '')
  const [suitePath, setSuitePath] = useState('')
  const [tags, setTags] = useState('')
  const [error, setError] = useState<string | null>(null)

  const createMutation = useMutation({
    mutationFn: () =>
      api
        .post<CreateRunResponse>('/api/v1/runs', {
          rig_name: rigName,
          suite_path: suitePath.trim(),
          tags: tags
            .split(',')
            .map((t) => t.trim())
            .filter(Boolean),
          triggered_by: 'dashboard',
        })
        .then((r) => r.data),
    onSuccess: (data) => {
      void qc.invalidateQueries({ queryKey: ['runs'] })
      void navigate(`/runs/${data.run_id}`)
    },
    onError: (err: unknown) => {
      const detail =
        (err as { response?: { data?: { detail?: string } } })?.response?.data
          ?.detail ?? 'Failed to create run.'
      setError(detail)
    },
  })

  function handleSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    createMutation.mutate()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-md card-base p-6 space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold text-white">Run Suite</h2>
          <button onClick={onClose} className="text-muted hover:text-white transition-colors">
            <X size={16} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs text-muted font-medium">Rig</label>
            <select
              value={rigName}
              onChange={(e) => setRigName(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/[0.08] text-white text-sm focus:outline-none focus:border-accent/50 transition-colors appearance-none cursor-pointer"
              required
            >
              {rigs.map((r) => (
                <option key={r.id} value={r.name}>
                  {r.name}
                  {r.connected ? ' ●' : ' ○'}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs text-muted font-medium">Suite path</label>
            <input
              type="text"
              value={suitePath}
              onChange={(e) => setSuitePath(e.target.value)}
              placeholder="tests/suites/engine_startup.yaml"
              required
              autoFocus={!defaultRigName}
              className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/[0.08] text-white text-sm placeholder:text-muted/50 focus:outline-none focus:border-accent/50 transition-colors font-mono"
            />
            <p className="text-xs text-muted/60">
              Path on the rig's filesystem, relative to the agent working directory.
            </p>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs text-muted font-medium">
              Tags <span className="text-muted/50 font-normal">(optional, comma-separated)</span>
            </label>
            <input
              type="text"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="smoke, engine, fast"
              className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/[0.08] text-white text-sm placeholder:text-muted/50 focus:outline-none focus:border-accent/50 transition-colors"
            />
          </div>

          {error && (
            <div className="flex items-start gap-2 text-xs text-fail bg-fail/[0.08] border border-fail/20 rounded-lg px-3 py-2.5">
              <AlertCircle size={13} className="flex-shrink-0 mt-0.5" />
              {error}
            </div>
          )}

          {createMutation.isSuccess && !createMutation.data.agent_notified && (
            <p className="text-xs text-warn">
              Run queued — agent is offline. It will start when the agent reconnects.
            </p>
          )}

          <div className="flex gap-2 justify-end pt-1">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-xs text-muted hover:text-white border border-white/[0.08] rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!rigName || !suitePath.trim() || createMutation.isPending}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-accent hover:bg-accent/80 text-white rounded-lg transition-colors disabled:opacity-50"
            >
              <Play size={11} />
              {createMutation.isPending ? 'Starting…' : 'Run suite'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export function RunsPage() {
  const navigate = useNavigate()
  const { role } = useAuth()
  const [rigFilter, setRigFilter] = useState('')
  const [statusFilter, setStatusFilter] = useState<RunStatus | ''>('')
  const [showRunModal, setShowRunModal] = useState(false)

  const { data: rigs } = useQuery<RigDetail[]>({
    queryKey: ['rigs'],
    queryFn: () => api.get<RigDetail[]>('/api/v1/rigs').then((r) => r.data),
    refetchInterval: 30_000,
  })

  const params = new URLSearchParams({ limit: '100' })
  if (rigFilter) params.set('rig_name', rigFilter)
  if (statusFilter) params.set('status', statusFilter)

  const activeRunsExist = !statusFilter || statusFilter === 'running' || statusFilter === 'queued'

  const { data: runs, isLoading, error } = useQuery<RunSummary[]>({
    queryKey: ['runs', { rig: rigFilter, status: statusFilter }],
    queryFn: () => api.get<RunSummary[]>(`/api/v1/runs?${params.toString()}`).then((r) => r.data),
    refetchInterval: activeRunsExist ? 5_000 : false,
  })

  const rigById = Object.fromEntries((rigs ?? []).map((r) => [r.id, r]))

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Runs</h1>
          <p className="text-sm text-muted mt-1">All test suite executions across your rigs</p>
        </div>
        {role === 'admin' && (rigs ?? []).length > 0 && (
          <button
            onClick={() => setShowRunModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium bg-accent hover:bg-accent/80 text-white rounded-lg transition-colors flex-shrink-0"
          >
            <Play size={13} />
            Run Suite
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2.5 flex-wrap">
        <Filter size={14} className="text-muted flex-shrink-0" />
        <select value={rigFilter} onChange={(e) => setRigFilter(e.target.value)} className={selectCls}>
          <option value="">All rigs</option>
          {(rigs ?? []).map((r) => (
            <option key={r.id} value={r.name}>{r.name}</option>
          ))}
        </select>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as RunStatus | '')} className={selectCls}>
          {STATUS_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        {(rigFilter || statusFilter) && (
          <button
            onClick={() => { setRigFilter(''); setStatusFilter('') }}
            className="text-xs text-muted hover:text-white transition-colors px-2 py-1.5 rounded hover:bg-white/[0.05]"
          >
            Clear filters
          </button>
        )}
      </div>

      {error ? (
        <ErrorDisplay message="Failed to load runs." />
      ) : isLoading ? (
        <Skeleton className="h-64" />
      ) : !runs?.length ? (
        <EmptyState message="No runs match the current filters." />
      ) : (
        <div className="card-base overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/[0.06]">
                <th className="text-left px-4 py-3 text-xs text-muted font-medium">Suite</th>
                <th className="text-left px-4 py-3 text-xs text-muted font-medium hidden sm:table-cell">Rig</th>
                <th className="text-left px-4 py-3 text-xs text-muted font-medium">Status</th>
                <th className="text-left px-4 py-3 text-xs text-muted font-medium hidden md:table-cell">Started</th>
                <th className="text-right px-4 py-3 text-xs text-muted font-medium hidden lg:table-cell">Results</th>
              </tr>
            </thead>
            <tbody>
              {runs.map((run, i) => (
                <tr
                  key={run.id}
                  className={`hover:bg-white/[0.02] cursor-pointer transition-colors ${i < runs.length - 1 ? 'border-b border-white/[0.04]' : ''}`}
                  onClick={() => void navigate(`/runs/${run.id}`)}
                >
                  <td className="px-4 py-3">
                    <span className="font-medium text-white truncate block max-w-[200px]">{run.suite_name}</span>
                    {run.triggered_by && (
                      <span className="text-xs text-muted/60 mt-0.5 block">{run.triggered_by}</span>
                    )}
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell">
                    <span className="text-xs text-muted">{rigById[run.rig_id]?.name ?? run.rig_id.slice(0, 8) + '…'}</span>
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={run.status} />
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    <span className="text-xs text-muted">{format(new Date(run.started_at * 1000), 'MMM d, HH:mm')}</span>
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    <MiniPassBar
                      passed={run.passed}
                      failed={run.failed}
                      blocked={run.blocked}
                      skipped={run.skipped}
                      total={run.total}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="px-4 py-2.5 border-t border-white/[0.04] flex items-center justify-end">
            <span className="text-xs text-muted/60">{runs.length} run{runs.length !== 1 ? 's' : ''}</span>
          </div>
        </div>
      )}

      {showRunModal && (
        <RunSuiteModal
          rigs={rigs ?? []}
          onClose={() => setShowRunModal(false)}
        />
      )}
    </div>
  )
}
