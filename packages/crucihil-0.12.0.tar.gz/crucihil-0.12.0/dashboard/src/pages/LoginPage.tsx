import { useState, useEffect, type FormEvent } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { AlertCircle, Zap, Shield, Cpu, GitBranch, ArrowRight, Eye, EyeOff } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import api from '../lib/api'

interface TokenResponse {
  access_token: string
  token_type: string
}

const FEATURES = [
  {
    icon: Cpu,
    title: 'Python-first testing',
    desc: 'Write tests in minutes. Run against simulation before hardware exists.',
  },
  {
    icon: GitBranch,
    title: 'Simulation-to-hardware parity',
    desc: 'Same test file. Swap a TOML config to switch from virtual to real hardware.',
  },
  {
    icon: Shield,
    title: 'CI/CD native',
    desc: 'Runs headless. Produces JUnit XML. Integrates with GitHub Actions.',
  },
]

export function LoginPage() {
  const { isAuthenticated, login } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showPassword, setShowPassword] = useState(false)

  const sessionExpired =
    sessionStorage.getItem('crucihil_session_expired') === '1'

  useEffect(() => {
    sessionStorage.removeItem('crucihil_session_expired')
    if (isAuthenticated) {
      void navigate('/', { replace: true })
    }
  }, [isAuthenticated, navigate])

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setLoading(true)
    setError(null)
    try {
      const res = await api.post<TokenResponse>('/api/v1/auth/login', {
        email: email.trim().toLowerCase(),
        password,
      })
      login(res.data.access_token)
    } catch {
      setError('Invalid email or password.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-base flex">
      {/* Left panel — branding */}
      <div className="hidden lg:flex lg:w-[52%] relative flex-col justify-between p-12 bg-surface border-r border-[rgba(204,204,220,0.09)] overflow-hidden">
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(255,255,255,0.5) 2px, rgba(255,255,255,0.5) 3px)', backgroundSize: '100% 3px' }} />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-accent/6 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-16">
            <div className="w-8 h-8 rounded bg-accent/20 border border-accent/40 flex items-center justify-center">
              <Zap size={16} className="text-accent-light" />
            </div>
            <span className="font-bold text-lg tracking-tight text-white">CruciHiL</span>
          </div>

          <h1 className="text-4xl font-bold text-white leading-tight mb-4">
            Hardware-in-the-Loop<br />
            <span className="text-accent-light">testing platform</span>
          </h1>
          <p className="text-muted text-base leading-relaxed mb-12 max-w-sm">
            Catch firmware regressions before they reach the field.
            Write a test in Python. Run it against simulation or real hardware — zero changes.
          </p>

          <div className="space-y-5">
            {FEATURES.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="flex gap-4">
                <div className="w-8 h-8 rounded bg-white/[0.04] border border-[rgba(204,204,220,0.09)] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Icon size={15} className="text-accent-light" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white mb-0.5">{title}</p>
                  <p className="text-xs text-muted leading-relaxed">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative z-10">
          <p className="text-xs text-muted/50">crucihil.io · Hardware-in-the-Loop Testing</p>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
        <div className="flex items-center gap-2.5 mb-10 lg:hidden">
          <div className="w-7 h-7 rounded bg-accent/20 border border-accent/40 flex items-center justify-center">
            <Zap size={14} className="text-accent-light" />
          </div>
          <span className="font-bold text-base tracking-tight text-white">CruciHiL</span>
        </div>

        <div className="w-full max-w-sm animate-slide-up">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white mb-1.5">Sign in</h2>
            <p className="text-sm text-muted">Enter your email and password to continue</p>
          </div>

          {sessionExpired && (
            <div className="mb-5 flex items-center gap-2.5 text-sm text-warn bg-warn/[0.08] border border-warn/20 rounded px-4 py-3">
              <AlertCircle size={15} className="flex-shrink-0" />
              Session expired — please sign in again.
            </div>
          )}

          <form onSubmit={(e) => { void handleSubmit(e) }} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-white/80 mb-2">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@company.com"
                required
                autoFocus
                autoComplete="email"
                className="w-full bg-card border border-[rgba(204,204,220,0.12)] rounded px-4 py-2.5 text-sm text-white placeholder:text-subtle focus:outline-none focus:ring-1 focus:ring-accent/60 focus:border-accent/60 transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-white/80 mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  autoComplete="current-password"
                  className="w-full bg-card border border-[rgba(204,204,220,0.12)] rounded px-4 py-2.5 text-sm text-white placeholder:text-subtle focus:outline-none focus:ring-1 focus:ring-accent/60 focus:border-accent/60 transition-all pr-10"
                />
                <button
                  type="button"
                  tabIndex={-1}
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-white transition-colors"
                >
                  {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {error && (
              <div className="flex items-start gap-2 text-xs text-fail bg-fail/[0.08] border border-fail/20 rounded-lg px-3 py-2.5">
                <AlertCircle size={13} className="flex-shrink-0 mt-0.5" />
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading || !email.trim() || !password}
              className="w-full flex items-center justify-center gap-2 bg-accent hover:bg-accent-dim disabled:opacity-40 disabled:cursor-not-allowed text-white rounded py-2.5 text-sm font-medium transition-colors"
            >
              {loading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Signing in…
                </>
              ) : (
                <>
                  Sign in
                  <ArrowRight size={15} />
                </>
              )}
            </button>
          </form>

          <div className="mt-6 space-y-2 text-center">
            <p className="text-xs text-muted">
              <Link to="/forgot-password" className="text-accent-light hover:underline">
                Forgot your password?
              </Link>
            </p>
            <p className="text-xs text-muted">
              First time here?{' '}
              <Link to="/setup" className="text-accent-light hover:underline">
                Set up your organization
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
