import { useState, useEffect, type FormEvent } from 'react'
import { useNavigate, useSearchParams, Link } from 'react-router-dom'
import { AlertCircle, Zap, CheckCircle, ArrowRight, Eye, EyeOff } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import api from '../lib/api'
import axios from 'axios'

interface TokenResponse {
  access_token: string
  token_type: string
}

interface PasswordResetInfo {
  email: string
}

export function ResetPasswordPage() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const token = searchParams.get('token') ?? ''

  const [email, setEmail] = useState<string | null>(null)
  const [tokenValid, setTokenValid] = useState<boolean | null>(null)
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [done, setDone] = useState(false)

  useEffect(() => {
    if (!token) {
      setTokenValid(false)
      return
    }
    api
      .get<PasswordResetInfo>(`/api/v1/auth/password-reset/${token}`)
      .then((res) => {
        setEmail(res.data.email)
        setTokenValid(true)
      })
      .catch(() => setTokenValid(false))
  }, [token])

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (password !== confirm) {
      setError('Passwords do not match.')
      return
    }
    setLoading(true)
    setError(null)
    try {
      const res = await api.post<TokenResponse>('/api/v1/auth/reset-password', {
        token,
        password,
      })
      login(res.data.access_token)
      setDone(true)
      setTimeout(() => void navigate('/', { replace: true }), 1500)
    } catch (err) {
      if (axios.isAxiosError(err) && err.response?.status === 404) {
        setTokenValid(false)
        return
      }
      const detail =
        axios.isAxiosError(err) && typeof err.response?.data?.detail === 'string'
          ? err.response.data.detail
          : 'Reset failed. Try requesting a new link.'
      setError(detail)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-base flex flex-col items-center justify-center px-6 py-12">
      <div className="w-full max-w-sm animate-slide-up">
        <div className="flex items-center gap-2.5 mb-10">
          <div className="w-7 h-7 rounded bg-accent/20 border border-accent/40 flex items-center justify-center">
            <Zap size={14} className="text-accent-light" />
          </div>
          <span className="font-bold text-base tracking-tight text-white">CruciHiL</span>
        </div>

        {tokenValid === null && (
          <div className="text-center text-muted text-sm">Validating link…</div>
        )}

        {tokenValid === false && (
          <div className="text-center">
            <div className="w-12 h-12 rounded-full bg-fail/10 border border-fail/20 flex items-center justify-center mx-auto mb-4">
              <AlertCircle size={22} className="text-fail" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Link expired</h2>
            <p className="text-sm text-muted mb-6">
              This reset link is invalid or has expired. Request a new one.
            </p>
            <Link
              to="/forgot-password"
              className="inline-flex items-center gap-1.5 text-sm text-accent-light hover:underline"
            >
              Request a new link
              <ArrowRight size={13} />
            </Link>
          </div>
        )}

        {tokenValid === true && !done && (
          <>
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-1.5">Set new password</h2>
              {email && (
                <p className="text-sm text-muted">
                  Resetting password for <span className="text-white">{email}</span>
                </p>
              )}
            </div>

            <form onSubmit={(e) => { void handleSubmit(e) }} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-white/80 mb-2">
                  New password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    minLength={8}
                    autoFocus
                    autoComplete="new-password"
                    className="w-full bg-card border border-[rgba(204,204,220,0.12)] rounded px-4 py-2.5 text-sm text-white placeholder:text-subtle focus:outline-none focus:ring-1 focus:ring-accent/60 focus:border-accent/60 transition-all pr-10"
                  />
                  <button
                    type="button"
                    tabIndex={-1}
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-white transition-colors"
                  >
                    {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-white/80 mb-2">
                  Confirm password
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  placeholder="••••••••"
                  required
                  autoComplete="new-password"
                  className="w-full bg-card border border-[rgba(204,204,220,0.12)] rounded px-4 py-2.5 text-sm text-white placeholder:text-subtle focus:outline-none focus:ring-1 focus:ring-accent/60 focus:border-accent/60 transition-all"
                />
              </div>

              {error && (
                <div className="flex items-start gap-2 text-xs text-fail bg-fail/[0.08] border border-fail/20 rounded-lg px-3 py-2.5">
                  <AlertCircle size={13} className="flex-shrink-0 mt-0.5" />
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading || !password || !confirm}
                className="w-full flex items-center justify-center gap-2 bg-accent hover:bg-accent-dim disabled:opacity-40 disabled:cursor-not-allowed text-white rounded py-2.5 text-sm font-medium transition-colors"
              >
                {loading ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Saving…
                  </>
                ) : (
                  <>
                    Set new password
                    <ArrowRight size={15} />
                  </>
                )}
              </button>
            </form>
          </>
        )}

        {done && (
          <div className="text-center">
            <div className="w-12 h-12 rounded-full bg-pass/10 border border-pass/20 flex items-center justify-center mx-auto mb-4">
              <CheckCircle size={22} className="text-pass" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Password updated</h2>
            <p className="text-sm text-muted">Redirecting you to the dashboard…</p>
          </div>
        )}
      </div>
    </div>
  )
}
