import { useState, useEffect, type FormEvent } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { AlertCircle, Eye, EyeOff, Zap, ArrowRight, CheckCircle } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import api from '../lib/api'

interface InviteInfo {
  email: string
  org_name: string
}

interface TokenResponse {
  access_token: string
  token_type: string
}

export function AcceptInvitePage() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const token = params.get('token') ?? ''

  const [info, setInfo] = useState<InviteInfo | null>(null)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [submitError, setSubmitError] = useState<string | null>(null)

  useEffect(() => {
    if (!token) {
      setLoadError('Missing invite token.')
      return
    }
    api
      .get<InviteInfo>(`/api/v1/auth/invite/${token}`)
      .then((r) => setInfo(r.data))
      .catch(() => setLoadError('This invite link is invalid or has expired.'))
  }, [token])

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (password !== confirm) {
      setSubmitError('Passwords do not match.')
      return
    }
    if (password.length < 8) {
      setSubmitError('Password must be at least 8 characters.')
      return
    }
    setSubmitting(true)
    setSubmitError(null)
    try {
      const res = await api.post<TokenResponse>('/api/v1/auth/invite/accept', {
        token,
        password,
      })
      login(res.data.access_token)
      void navigate('/', { replace: true })
    } catch {
      setSubmitError('Failed to accept invite. The link may have expired.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-base flex flex-col items-center justify-center px-6 py-12">
      <div className="w-full max-w-sm animate-slide-up">
        <div className="flex items-center gap-2.5 mb-10">
          <div className="w-7 h-7 rounded bg-accent/20 border border-accent/40 flex items-center justify-center">
            <Zap size={14} className="text-accent-light" />
          </div>
          <span className="font-bold text-base tracking-tight text-white">CruciHiL</span>
        </div>

        {loadError ? (
          <div className="card-base p-6 text-center space-y-3">
            <AlertCircle size={32} className="text-fail mx-auto" />
            <p className="text-sm text-white font-medium">Invite not found</p>
            <p className="text-xs text-muted">{loadError}</p>
          </div>
        ) : !info ? (
          <div className="flex items-center gap-2 text-muted text-sm">
            <span className="w-4 h-4 border-2 border-white/20 border-t-white/60 rounded-full animate-spin" />
            Validating invite…
          </div>
        ) : (
          <>
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle size={16} className="text-pass" />
                <span className="text-xs text-pass font-medium">Invite valid</span>
              </div>
              <h2 className="text-2xl font-bold text-white mb-1.5">
                Join {info.org_name}
              </h2>
              <p className="text-sm text-muted">
                You've been invited as <span className="text-white font-medium">{info.email}</span>.
                Set a password to activate your account.
              </p>
            </div>

            <form onSubmit={(e) => { void handleSubmit(e) }} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-white/80 mb-2">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPass ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="At least 8 characters"
                    required
                    minLength={8}
                    autoFocus
                    autoComplete="new-password"
                    className="w-full bg-card border border-[rgba(204,204,220,0.12)] rounded px-4 py-2.5 text-sm text-white placeholder:text-subtle focus:outline-none focus:ring-1 focus:ring-accent/60 focus:border-accent/60 transition-all pr-10"
                  />
                  <button
                    type="button"
                    tabIndex={-1}
                    onClick={() => setShowPass((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-white transition-colors"
                  >
                    {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-white/80 mb-2">
                  Confirm password
                </label>
                <input
                  type={showPass ? 'text' : 'password'}
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  placeholder="Repeat your password"
                  required
                  autoComplete="new-password"
                  className="w-full bg-card border border-[rgba(204,204,220,0.12)] rounded px-4 py-2.5 text-sm text-white placeholder:text-subtle focus:outline-none focus:ring-1 focus:ring-accent/60 focus:border-accent/60 transition-all"
                />
              </div>

              {submitError && (
                <div className="flex items-start gap-2 text-xs text-fail bg-fail/[0.08] border border-fail/20 rounded-lg px-3 py-2.5">
                  <AlertCircle size={13} className="flex-shrink-0 mt-0.5" />
                  {submitError}
                </div>
              )}

              <button
                type="submit"
                disabled={submitting || !password || !confirm}
                className="w-full flex items-center justify-center gap-2 bg-accent hover:bg-accent-dim disabled:opacity-40 disabled:cursor-not-allowed text-white rounded py-2.5 text-sm font-medium transition-colors"
              >
                {submitting ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Activating account…
                  </>
                ) : (
                  <>
                    Activate account
                    <ArrowRight size={15} />
                  </>
                )}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  )
}
