import { useState, useMemo } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useParams, Link } from 'react-router-dom'
import {
  ChevronLeft, StopCircle, ChevronDown, ChevronRight,
  Clock, AlertCircle, Download, FileCode, LayoutList, Code2, ScrollText,
} from 'lucide-react'
import { format } from 'date-fns'
import api from '../lib/api'
import type { RunSummary, ResultSummary, ResultDetail, TestStatus } from '../types/api'
import { isTerminal } from '../types/api'
import { StatusBadge } from '../components/StatusBadge'
import { Skeleton, SkeletonRows } from '../components/Skeleton'
import { ErrorDisplay } from '../components/PageStates'
import { useRunStream } from '../hooks/useRunStream'
import { useAuth } from '../hooks/useAuth'

// ── SegmentedBar ──────────────────────────────────────────────────────────────

function SegmentedBar({ passed, failed, blocked, skipped, total }: {
  passed: number; failed: number; blocked: number; skipped: number; total: number
}) {
  if (total === 0) return <div className="h-2 bg-white/[0.06] rounded-full" />
  const segments = [
    { count: passed, color: 'bg-pass' },
    { count: failed, color: 'bg-fail' },
    { count: blocked, color: 'bg-warn' },
    { count: skipped, color: 'bg-muted/40' },
  ].filter((s) => s.count > 0)

  return (
    <div className="h-2 bg-white/[0.06] rounded-full overflow-hidden flex gap-px">
      {segments.map(({ count, color }) => (
        <div
          key={color}
          className={`h-full ${color} transition-all duration-700`}
          style={{ width: `${(count / total) * 100}%` }}
        />
      ))}
    </div>
  )
}

// ── ResultRow ─────────────────────────────────────────────────────────────────

type DetailTab = 'error' | 'source' | 'logs'

function DetailPanel({ detail }: { detail: ResultDetail }) {
  const hasError = !!detail.error_message
  const hasSource = !!detail.extra_meta?.source_code
  const hasLogs = detail.logs.length > 0
  const params = detail.extra_meta?.params
  const hasParams = params && Object.keys(params).length > 0

  const defaultTab: DetailTab = hasError ? 'error' : hasSource ? 'source' : 'logs'
  const [tab, setTab] = useState<DetailTab>(defaultTab)

  const tabs: { id: DetailTab; label: string; icon: React.ReactNode; show: boolean }[] = [
    { id: 'error', label: 'Failure', icon: <AlertCircle size={11} />, show: hasError },
    { id: 'source', label: 'Source', icon: <Code2 size={11} />, show: hasSource },
    { id: 'logs', label: 'Logs', icon: <ScrollText size={11} />, show: hasLogs },
  ]
  const visibleTabs = tabs.filter((t) => t.show)

  return (
    <div className="space-y-3">
      {/* meta badges */}
      <div className="flex flex-wrap gap-1.5 items-center">
        {detail.extra_meta?.module && (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-white/[0.06] text-muted">
            {detail.extra_meta.module}.{detail.extra_meta.function}
          </span>
        )}
        {detail.priority && (
          <span className="px-2 py-0.5 rounded text-[10px] bg-white/[0.06] text-muted">
            priority: {detail.priority}
          </span>
        )}
        {detail.extra_meta?.requirements?.map((r: string) => (
          <span key={r} className="px-2 py-0.5 rounded text-[10px] bg-white/[0.06] text-muted">{r}</span>
        ))}
        {detail.extra_meta?.ticket && (
          <span className="px-2 py-0.5 rounded text-[10px] bg-white/[0.06] text-muted">
            ticket: {detail.extra_meta.ticket as string}
          </span>
        )}
      </div>

      {/* params */}
      {hasParams && (
        <div className="text-[10px] text-muted font-mono bg-white/[0.03] rounded px-3 py-2">
          <span className="text-white/40 mr-2">params</span>
          {Object.entries(params as Record<string, unknown>).map(([k, v]) => (
            <span key={k} className="mr-3">
              <span className="text-accent-light">{k}</span>
              <span className="text-white/40">=</span>
              <span className="text-white/70">{JSON.stringify(v)}</span>
            </span>
          ))}
        </div>
      )}

      {/* tab switcher */}
      {visibleTabs.length > 1 && (
        <div className="flex gap-1">
          {visibleTabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                tab === t.id
                  ? 'bg-white/[0.10] text-white'
                  : 'text-muted hover:text-white'
              }`}
            >
              {t.icon}{t.label}
            </button>
          ))}
        </div>
      )}

      {/* tab content */}
      {tab === 'error' && hasError && (
        <div className="flex items-start gap-2.5">
          <AlertCircle size={13} className="text-fail flex-shrink-0 mt-0.5" />
          <pre className="text-xs text-fail/80 font-mono whitespace-pre-wrap break-all leading-relaxed">
            {detail.error_message}
          </pre>
        </div>
      )}

      {tab === 'source' && hasSource && (
        <div className="relative group">
          <div className="absolute top-2 right-2 text-[10px] text-muted font-mono opacity-0 group-hover:opacity-100 transition-opacity">
            {detail.extra_meta.module}.{detail.extra_meta.function}
          </div>
          <pre className="text-xs text-white/75 font-mono whitespace-pre overflow-x-auto leading-relaxed bg-white/[0.03] rounded-lg px-4 py-3 border border-white/[0.06]">
            {detail.extra_meta.source_code as string}
          </pre>
        </div>
      )}

      {tab === 'logs' && hasLogs && (
        <pre className="text-xs text-muted font-mono whitespace-pre-wrap leading-relaxed bg-white/[0.03] rounded-lg px-4 py-3 border border-white/[0.06] max-h-48 overflow-y-auto">
          {detail.logs.join('\n')}
        </pre>
      )}
    </div>
  )
}

function ResultRow({ result }: { result: ResultSummary }) {
  const [open, setOpen] = useState(false)
  const tags = result.tags ?? []

  const { data: detail, isLoading: detailLoading } = useQuery<ResultDetail>({
    queryKey: ['result-detail', result.id],
    queryFn: () => api.get<ResultDetail>(`/api/v1/results/${result.id}`).then((r) => r.data),
    enabled: open,
    staleTime: 120_000,
  })

  return (
    <>
      <tr
        className="border-b border-white/[0.04] transition-colors cursor-pointer hover:bg-white/[0.02]"
        onClick={() => setOpen((v) => !v)}
      >
        <td className="px-4 py-3">
          <div className="flex items-center gap-2">
            {open
              ? <ChevronDown size={13} className="text-muted flex-shrink-0" />
              : <ChevronRight size={13} className="text-muted flex-shrink-0" />
            }
            <div className="min-w-0">
              <span className="font-mono text-xs text-white/90">{result.test_id}</span>
              {tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-1">
                  {tags.map((t) => (
                    <span key={t} className="px-1.5 py-0.5 rounded text-[10px] bg-white/[0.06] text-muted leading-none">{t}</span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </td>
        <td className="px-4 py-3">
          <StatusBadge status={result.status} />
        </td>
        <td className="px-4 py-3 text-right">
          <span className="text-xs text-muted font-mono">
            {result.duration != null ? `${result.duration.toFixed(2)}s` : '—'}
          </span>
        </td>
        <td className="px-4 py-3 text-right hidden md:table-cell">
          <span className="text-xs text-muted" title={format(new Date(result.completed_at * 1000), 'PPpp')}>
            {format(new Date(result.completed_at * 1000), 'HH:mm:ss')}
          </span>
        </td>
      </tr>
      {open && (
        <tr className="border-b border-white/[0.04] bg-white/[0.01]">
          <td colSpan={4} className="px-4 py-4 pl-14">
            {detailLoading || !detail ? (
              <div className="space-y-2">
                <Skeleton className="h-4 w-48" />
                <Skeleton className="h-24 w-full" />
              </div>
            ) : (
              <DetailPanel detail={detail} />
            )}
          </td>
        </tr>
      )}
    </>
  )
}

// ── FilterBar ─────────────────────────────────────────────────────────────────

type StatusFilter = TestStatus | 'all'

const STATUS_OPTIONS: { value: StatusFilter; label: string }[] = [
  { value: 'all', label: 'All' },
  { value: 'pass', label: 'Passed' },
  { value: 'fail', label: 'Failed' },
  { value: 'blocked', label: 'Blocked' },
  { value: 'skip', label: 'Skipped' },
  { value: 'error', label: 'Errored' },
]

function FilterChip({
  label, count, active, onClick,
}: { label: string; count?: number; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`px-2.5 py-1 rounded-full text-xs font-medium transition-colors ${
        active
          ? 'bg-accent text-white'
          : 'bg-white/[0.06] text-muted hover:bg-white/[0.10] hover:text-white'
      }`}
    >
      {label}{count != null ? ` (${count})` : ''}
    </button>
  )
}

// ── HtmlViewer ────────────────────────────────────────────────────────────────

function HtmlViewer({ runId }: { runId: string }) {
  const { data: htmlContent, isLoading } = useQuery<string>({
    queryKey: ['run-report-html', runId],
    queryFn: () => api.get<string>(`/api/v1/runs/${runId}/report.html`).then((r) => r.data),
    staleTime: 60_000,
  })

  if (isLoading) return <SkeletonRows count={8} />
  if (!htmlContent) return <p className="text-sm text-muted text-center py-10">Report unavailable.</p>

  return (
    <iframe
      className="w-full rounded-xl border border-white/[0.06]"
      style={{ height: '70vh', background: '#0f172a' }}
      srcDoc={htmlContent}
      sandbox="allow-same-origin"
      title="HTML Report"
    />
  )
}

// ── Download helper ───────────────────────────────────────────────────────────

async function downloadReport(runId: string, format: 'xml' | 'html') {
  const resp = await api.get(`/api/v1/runs/${runId}/report.${format}`, {
    responseType: 'blob',
  })
  const url = URL.createObjectURL(resp.data as Blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `report_${runId.slice(0, 8)}.${format}`
  a.click()
  URL.revokeObjectURL(url)
}

// ── RunDetailPage ─────────────────────────────────────────────────────────────

type ViewTab = 'results' | 'html'

export function RunDetailPage() {
  const { runId } = useParams<{ runId: string }>()
  const qc = useQueryClient()
  const { role } = useAuth()
  const id = runId ?? ''

  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all')
  const [activeTags, setActiveTags] = useState<Set<string>>(new Set())
  const [activeSuiteTypes, setActiveSuiteTypes] = useState<Set<string>>(new Set())
  const [activeTab, setActiveTab] = useState<ViewTab>('results')

  const { data: run, isLoading: runLoading, error: runError } = useQuery<RunSummary>({
    queryKey: ['runs', id],
    queryFn: () => api.get<RunSummary>(`/api/v1/runs/${id}`).then((r) => r.data),
    enabled: !!id,
    refetchInterval: (query) => {
      const s = (query.state.data as RunSummary | undefined)?.status
      return isTerminal(s) ? false : 5_000
    },
  })

  const { data: results, isLoading: resultsLoading } = useQuery<ResultSummary[]>({
    queryKey: ['results', id],
    queryFn: () =>
      api.get<ResultSummary[]>(`/api/v1/results?run_id=${id}&limit=500`).then((r) => r.data),
    enabled: !!id,
  })

  useRunStream(id, run?.status)

  const cancelMutation = useMutation({
    mutationFn: () => api.post(`/api/v1/runs/${id}/cancel`).then((r) => r.data),
    onSuccess: () => { void qc.invalidateQueries({ queryKey: ['runs', id] }) },
  })

  const allResults = results ?? []

  // Derive available tags/suite_types from results
  const allTags = useMemo(() => {
    const s = new Set<string>()
    allResults.forEach((r) => (r.tags ?? []).forEach((t) => s.add(t)))
    return [...s].sort()
  }, [allResults])

  const allSuiteTypes = useMemo(() => {
    const s = new Set<string>()
    allResults.forEach((r) => (r.suite_types ?? []).forEach((t) => s.add(t)))
    return [...s].sort()
  }, [allResults])

  // Status counts (pre-filter)
  const statusCounts = useMemo(() => {
    const m: Record<string, number> = {}
    allResults.forEach((r) => { m[r.status] = (m[r.status] ?? 0) + 1 })
    return m
  }, [allResults])

  // Filtered results
  const filteredResults = useMemo(() => {
    return allResults.filter((r) => {
      if (statusFilter !== 'all' && r.status !== statusFilter) return false
      if (activeTags.size > 0 && !([...(r.tags ?? [])].some((t) => activeTags.has(t)))) return false
      if (activeSuiteTypes.size > 0 && !([...(r.suite_types ?? [])].some((t) => activeSuiteTypes.has(t)))) return false
      return true
    })
  }, [allResults, statusFilter, activeTags, activeSuiteTypes])

  function toggleTag(tag: string) {
    setActiveTags((prev) => {
      const next = new Set(prev)
      next.has(tag) ? next.delete(tag) : next.add(tag)
      return next
    })
  }

  function toggleSuiteType(st: string) {
    setActiveSuiteTypes((prev) => {
      const next = new Set(prev)
      next.has(st) ? next.delete(st) : next.add(st)
      return next
    })
  }

  if (!id) return <p className="text-muted">Invalid run ID.</p>
  if (runError) return <ErrorDisplay message="Failed to load run." />

  if (runLoading || !run) {
    return (
      <div className="space-y-5 max-w-4xl animate-fade-in">
        <Skeleton className="h-9 w-72" />
        <Skeleton className="h-40" />
        <SkeletonRows count={6} />
      </div>
    )
  }

  const progressPct = run.total > 0 ? Math.round((run.passed / run.total) * 100) : 0
  const isLive = !isTerminal(run.status)
  const duration = run.completed_at
    ? `${((run.completed_at - run.started_at)).toFixed(1)}s`
    : isLive
    ? `${((Date.now() / 1000 - run.started_at)).toFixed(0)}s elapsed`
    : '—'

  return (
    <div className="space-y-6 max-w-4xl animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-2.5 min-w-0">
          <Link to="/runs" className="text-muted hover:text-white transition-colors mt-1 flex-shrink-0">
            <ChevronLeft size={18} />
          </Link>
          <div className="min-w-0">
            <h1 className="text-xl font-bold text-white truncate">{run.suite_name}</h1>
            <div className="flex items-center gap-3 mt-1 flex-wrap">
              <span className="flex items-center gap-1.5 text-xs text-muted">
                <Clock size={11} />
                {format(new Date(run.started_at * 1000), "MMM d, yyyy 'at' HH:mm:ss")}
              </span>
              {run.triggered_by && (
                <span className="text-xs text-muted/60">· {run.triggered_by}</span>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2.5 flex-shrink-0 flex-wrap justify-end">
          <StatusBadge status={run.status} />
          {/* Download buttons */}
          <button
            onClick={() => void downloadReport(id, 'xml')}
            title="Download JUnit XML"
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-muted border border-white/[0.08] rounded-lg hover:bg-white/[0.06] hover:text-white transition-colors"
          >
            <Download size={11} />
            XML
          </button>
          <button
            onClick={() => void downloadReport(id, 'html')}
            title="Download HTML Report"
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-muted border border-white/[0.08] rounded-lg hover:bg-white/[0.06] hover:text-white transition-colors"
          >
            <Download size={11} />
            HTML
          </button>
          {role === 'admin' && run.status === 'running' && (
            <button
              onClick={() => cancelMutation.mutate()}
              disabled={cancelMutation.isPending}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-fail border border-fail/25 rounded-lg hover:bg-fail/10 transition-colors disabled:opacity-50"
            >
              <StopCircle size={12} />
              Cancel
            </button>
          )}
        </div>
      </div>

      {/* Summary card */}
      <section className="card-base p-5 shadow-inset-top">
        <div className="grid grid-cols-5 gap-2 mb-5">
          {[
            { label: 'Total', value: run.total, color: 'text-white' },
            { label: 'Passed', value: run.passed, color: 'text-pass' },
            { label: 'Failed', value: run.failed, color: 'text-fail' },
            { label: 'Blocked', value: run.blocked, color: 'text-warn' },
            { label: 'Skipped', value: run.skipped, color: 'text-muted' },
          ].map(({ label, value, color }) => (
            <div key={label} className="text-center py-1">
              <p className={`text-2xl font-bold ${color} leading-none`}>{value}</p>
              <p className="text-xs text-muted mt-1">{label}</p>
            </div>
          ))}
        </div>

        <SegmentedBar
          passed={run.passed}
          failed={run.failed}
          blocked={run.blocked}
          skipped={run.skipped}
          total={run.total}
        />

        <div className="flex items-center justify-between mt-2.5">
          <div className="flex items-center gap-4">
            {run.passed > 0 && <span className="flex items-center gap-1.5 text-xs text-muted"><span className="w-2 h-2 rounded-sm bg-pass" />{run.passed} passed</span>}
            {run.failed > 0 && <span className="flex items-center gap-1.5 text-xs text-muted"><span className="w-2 h-2 rounded-sm bg-fail" />{run.failed} failed</span>}
            {run.blocked > 0 && <span className="flex items-center gap-1.5 text-xs text-muted"><span className="w-2 h-2 rounded-sm bg-warn" />{run.blocked} blocked</span>}
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs text-muted">{duration}</span>
            <span className="text-xs font-semibold text-white">{progressPct}% pass rate</span>
          </div>
        </div>
      </section>

      {/* Results section */}
      <section>
        {/* Tab bar */}
        <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
          <div className="flex items-center gap-1 bg-white/[0.04] rounded-lg p-1">
            <button
              onClick={() => setActiveTab('results')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeTab === 'results' ? 'bg-white/[0.10] text-white' : 'text-muted hover:text-white'
              }`}
            >
              <LayoutList size={12} />
              Results Table
              {isLive && (
                <span className="ml-1 inline-flex items-center gap-1 text-[10px] text-accent-light">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                  live
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('html')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                activeTab === 'html' ? 'bg-white/[0.10] text-white' : 'text-muted hover:text-white'
              }`}
            >
              <FileCode size={12} />
              HTML Report
            </button>
          </div>
          {activeTab === 'results' && allResults.length > 0 && (
            <span className="text-xs text-muted">
              {filteredResults.length === allResults.length
                ? `${allResults.length} test${allResults.length !== 1 ? 's' : ''}`
                : `${filteredResults.length} of ${allResults.length}`}
            </span>
          )}
        </div>

        {activeTab === 'html' ? (
          <HtmlViewer runId={id} />
        ) : (
          <>
            {/* Filter bar — only show when there are results */}
            {allResults.length > 0 && (
              <div className="space-y-2 mb-3">
                {/* Status filter */}
                <div className="flex flex-wrap gap-1.5">
                  {STATUS_OPTIONS.filter((o) => o.value === 'all' || (statusCounts[o.value] ?? 0) > 0).map((opt) => (
                    <FilterChip
                      key={opt.value}
                      label={opt.label}
                      count={opt.value !== 'all' ? (statusCounts[opt.value] ?? 0) : undefined}
                      active={statusFilter === opt.value}
                      onClick={() => setStatusFilter(opt.value)}
                    />
                  ))}
                </div>
                {/* Tag filter */}
                {allTags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 items-center">
                    <span className="text-[10px] text-muted uppercase tracking-wide mr-1">Tags</span>
                    {allTags.map((t) => (
                      <FilterChip
                        key={t}
                        label={t}
                        active={activeTags.has(t)}
                        onClick={() => toggleTag(t)}
                      />
                    ))}
                  </div>
                )}
                {/* Suite type filter */}
                {allSuiteTypes.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 items-center">
                    <span className="text-[10px] text-muted uppercase tracking-wide mr-1">Type</span>
                    {allSuiteTypes.map((t) => (
                      <FilterChip
                        key={t}
                        label={t}
                        active={activeSuiteTypes.has(t)}
                        onClick={() => toggleSuiteType(t)}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Results table */}
            {resultsLoading ? (
              <SkeletonRows count={6} />
            ) : filteredResults.length === 0 ? (
              <div className="text-sm text-muted text-center py-10 card-base">
                {allResults.length === 0
                  ? isTerminal(run.status)
                    ? 'No results recorded.'
                    : 'Waiting for first result…'
                  : 'No results match the current filters.'}
              </div>
            ) : (
              <div className="card-base overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/[0.06]">
                      <th className="text-left px-4 py-3 text-xs text-muted font-medium">Test</th>
                      <th className="text-left px-4 py-3 text-xs text-muted font-medium">Status</th>
                      <th className="text-right px-4 py-3 text-xs text-muted font-medium">Duration</th>
                      <th className="text-right px-4 py-3 text-xs text-muted font-medium hidden md:table-cell">Completed</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredResults.map((r) => (
                      <ResultRow key={r.test_id} result={r} />
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
      </section>
    </div>
  )
}
