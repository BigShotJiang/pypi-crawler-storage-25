import { useState, useCallback, type FormEvent } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '../hooks/useAuth'
import { Eye, EyeOff, LogOut, ShieldCheck, Clock, Users, UserPlus, Trash2, Copy, Check } from 'lucide-react'
import { format } from 'date-fns'
import api from '../lib/api'
import type { UserSummary } from '../types/api'

function decodeJwt(token: string): { sub?: string; rig_id?: string; exp?: number; type?: string } {
  try {
    const parts = token.split('.')
    if (parts.length !== 3) return {}
    return JSON.parse(atob(parts[1])) as { sub?: string; rig_id?: string; exp?: number; type?: string }
  } catch {
    return {}
  }
}

// ── Team tab (admin user only) ─────────────────────────────────────────────────

function TeamSection({ orgSlug }: { orgSlug: string }) {
  const qc = useQueryClient()
  const [inviteEmail, setInviteEmail] = useState('')
  const [inviteRole, setInviteRole] = useState<'member' | 'admin'>('member')
  const [inviteSuccess, setInviteSuccess] = useState<string | null>(null)
  const [inviteError, setInviteError] = useState<string | null>(null)

  const { data: users, isLoading } = useQuery({
    queryKey: ['org-users', orgSlug],
    queryFn: () =>
      api.get<UserSummary[]>(`/api/v1/orgs/${orgSlug}/users`).then((r) => r.data),
  })

  const removeMutation = useMutation({
    mutationFn: (userId: string) =>
      api.delete(`/api/v1/orgs/${orgSlug}/users/${userId}`),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ['org-users', orgSlug] }),
  })

  const inviteMutation = useMutation({
    mutationFn: ({ email, role }: { email: string; role: string }) =>
      api.post(`/api/v1/orgs/${orgSlug}/invites`, { email, role }),
    onSuccess: (_, vars) => {
      setInviteSuccess(`Invite sent to ${vars.email}.`)
      setInviteEmail('')
      setInviteError(null)
    },
    onError: () => {
      setInviteError('Could not send invite. The email may already exist.')
      setInviteSuccess(null)
    },
  })

  function handleInvite(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setInviteSuccess(null)
    setInviteError(null)
    inviteMutation.mutate({ email: inviteEmail.trim().toLowerCase(), role: inviteRole })
  }

  function handleRemove(user: UserSummary) {
    if (window.confirm(`Remove ${user.email}? They will lose access immediately.`)) {
      removeMutation.mutate(user.id)
    }
  }

  return (
    <section className="card-base p-5 space-y-5">
      <div className="flex items-center gap-2.5">
        <Users size={15} className="text-accent-light" />
        <h2 className="text-sm font-semibold text-white">Team</h2>
      </div>

      {/* Member list */}
      {isLoading ? (
        <p className="text-xs text-muted">Loading members…</p>
      ) : (
        <div className="divide-y divide-white/[0.05]">
          {(users ?? []).map((u) => (
            <div key={u.id} className="flex items-center justify-between py-2.5 gap-3">
              <div className="min-w-0">
                <p className="text-sm text-white truncate">{u.email}</p>
                <p className="text-xs text-muted">
                  {u.role === 'admin' ? 'Admin' : 'Member'}
                  {u.joined_at ? ` · joined ${format(new Date(u.joined_at * 1000), 'MMM d, yyyy')}` : ' · invite pending'}
                </p>
              </div>
              <button
                onClick={() => handleRemove(u)}
                disabled={removeMutation.isPending}
                className="text-muted hover:text-fail transition-colors flex-shrink-0 p-1 disabled:opacity-40"
                title="Remove member"
              >
                <Trash2 size={13} />
              </button>
            </div>
          ))}
          {(users ?? []).length === 0 && (
            <p className="text-xs text-muted py-2">No members yet.</p>
          )}
        </div>
      )}

      {/* Invite form */}
      <div className="pt-3 border-t border-white/[0.06] space-y-3">
        <div className="flex items-center gap-2">
          <UserPlus size={13} className="text-muted" />
          <p className="text-xs font-medium text-white/70 uppercase tracking-widest">Invite member</p>
        </div>
        <form onSubmit={handleInvite} className="space-y-2.5">
          <input
            type="email"
            value={inviteEmail}
            onChange={(e) => setInviteEmail(e.target.value)}
            placeholder="colleague@company.com"
            required
            className="w-full bg-base border border-[rgba(204,204,220,0.09)] rounded px-3 py-2 text-sm text-white placeholder:text-subtle focus:outline-none focus:ring-1 focus:ring-accent/60 focus:border-accent/60 transition-all"
          />
          <div className="flex gap-2">
            <select
              value={inviteRole}
              onChange={(e) => setInviteRole(e.target.value as 'member' | 'admin')}
              className="bg-base border border-[rgba(204,204,220,0.09)] rounded px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-accent/60"
            >
              <option value="member">Member</option>
              <option value="admin">Admin</option>
            </select>
            <button
              type="submit"
              disabled={inviteMutation.isPending || !inviteEmail.trim()}
              className="flex-1 flex items-center justify-center gap-1.5 bg-accent/10 hover:bg-accent/20 border border-accent/30 disabled:opacity-40 disabled:cursor-not-allowed text-accent-light rounded px-3 py-2 text-sm font-medium transition-colors"
            >
              {inviteMutation.isPending ? 'Sending…' : 'Send invite'}
            </button>
          </div>
          {inviteSuccess && <p className="text-xs text-pass">{inviteSuccess}</p>}
          {inviteError && <p className="text-xs text-fail">{inviteError}</p>}
        </form>
      </div>
    </section>
  )
}

// ── Main ───────────────────────────────────────────────────────────────────────

export function SettingsPage() {
  const { token, logout, role, tokenType, orgSlug } = useAuth()
  const [showToken, setShowToken] = useState(false)
  const [copied, setCopied] = useState(false)

  const handleCopy = useCallback(() => {
    if (!token) return
    void navigator.clipboard.writeText(token).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }, [token])

  if (!token) return null

  const payload = decodeJwt(token)
  const masked = `${token.slice(0, 18)}…${token.slice(-6)}`
  const expiresAt = payload.exp ? new Date(payload.exp * 1000) : null
  const isExpiringSoon = expiresAt ? expiresAt.getTime() - Date.now() < 5 * 60 * 1000 : false

  return (
    <div className="space-y-6 max-w-xl animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-white">Settings</h1>
        <p className="text-sm text-muted mt-1">Session and account details</p>
      </div>

      {/* Session card */}
      <section className="card-base p-5 space-y-5">
        <div className="flex items-center gap-2.5">
          <ShieldCheck size={15} className="text-accent-light" />
          <h2 className="text-sm font-semibold text-white">Session</h2>
        </div>

        <dl className="space-y-3">
          {payload.sub && (
            <div className="flex items-center justify-between">
              <dt className="text-xs text-muted">
                {tokenType === 'user' ? 'User ID' : 'Authenticated rig'}
              </dt>
              <dd className="text-sm font-medium text-white font-mono text-xs">
                {tokenType === 'user' ? `${payload.sub.slice(0, 8)}…` : payload.sub}
              </dd>
            </div>
          )}
          {tokenType && (
            <div className="flex items-center justify-between">
              <dt className="text-xs text-muted">Access type</dt>
              <dd className="text-xs text-white capitalize">{tokenType} · {role ?? 'unknown'}</dd>
            </div>
          )}
          {expiresAt && (
            <div className="flex items-center justify-between">
              <dt className="flex items-center gap-1.5 text-xs text-muted">
                <Clock size={11} />
                Session expires
              </dt>
              <dd className={`text-xs ${isExpiringSoon ? 'text-warn' : 'text-muted'}`}>
                {format(expiresAt, "MMM d 'at' HH:mm")}
                {isExpiringSoon && ' · expiring soon'}
              </dd>
            </div>
          )}
        </dl>

        <div className="pt-1 border-t border-white/[0.06]">
          <p className="text-xs text-muted/70 uppercase tracking-widest mb-2.5">JWT Token</p>
          <div className="flex items-center gap-2 bg-base border border-white/[0.06] rounded-lg px-3 py-2.5">
            <code className="text-xs text-muted/80 flex-1 font-mono truncate">
              {showToken ? token : masked}
            </code>
            <button
              onClick={() => setShowToken((v) => !v)}
              className="text-muted hover:text-white transition-colors flex-shrink-0 p-0.5"
              title={showToken ? 'Hide token' : 'Show token'}
            >
              {showToken ? <EyeOff size={13} /> : <Eye size={13} />}
            </button>
            <button
              onClick={handleCopy}
              className="text-muted hover:text-white transition-colors flex-shrink-0 p-0.5"
              title="Copy token"
            >
              {copied ? <Check size={13} className="text-pass" /> : <Copy size={13} />}
            </button>
          </div>
          <p className="text-xs text-muted/50 mt-1.5">
            Tokens expire after 1 hour. Log in again to refresh.
          </p>
        </div>
      </section>

      {/* Team card — admin user only */}
      {tokenType === 'user' && role === 'admin' && orgSlug && (
        <TeamSection orgSlug={orgSlug} />
      )}

      {/* Account card */}
      <section className="card-base p-5">
        <h2 className="text-sm font-semibold text-white mb-4">Account</h2>
        <button
          onClick={logout}
          className="flex items-center gap-2 px-4 py-2 text-sm text-fail border border-fail/20 rounded-lg hover:bg-fail/[0.08] transition-all"
        >
          <LogOut size={14} />
          Log out
        </button>
      </section>
    </div>
  )
}
