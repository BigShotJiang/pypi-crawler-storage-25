import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { Server, ChevronRight, Plus, X, Copy, Check } from 'lucide-react'
import { format } from 'date-fns'
import api from '../lib/api'
import type { RigDetail, RigRegisterResponse } from '../types/api'
import { useAuth } from '../hooks/useAuth'
import { RigOnlineIndicator } from '../components/RigOnlineIndicator'
import { Skeleton } from '../components/Skeleton'
import { EmptyState, ErrorDisplay } from '../components/PageStates'

// ── Register Rig Modal ─────────────────────────────────────────────────────────

type ModalState =
  | { phase: 'idle' }
  | { phase: 'registering' }
  | { phase: 'key_shown'; rigName: string; apiKey: string }

function RegisterRigModal({ onClose }: { onClose: () => void }) {
  const qc = useQueryClient()
  const [name, setName] = useState('')
  const [copied, setCopied] = useState(false)
  const [modal, setModal] = useState<ModalState>({ phase: 'registering' })

  const registerMutation = useMutation({
    mutationFn: (rigName: string) =>
      api.post<RigRegisterResponse>('/api/v1/rigs', { name: rigName }).then((r) => r.data),
    onSuccess: (data) => {
      void qc.invalidateQueries({ queryKey: ['rigs'] })
      setModal({ phase: 'key_shown', rigName: data.rig.name, apiKey: data.api_key })
    },
  })

  const handleCopy = () => {
    if (modal.phase !== 'key_shown') return
    void navigator.clipboard.writeText(modal.apiKey)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={modal.phase !== 'key_shown' ? onClose : undefined} />

      {/* Panel */}
      <div className="relative z-10 w-full max-w-md card-base p-6 space-y-5">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold text-white">
            {modal.phase === 'key_shown' ? 'Rig Registered' : 'Register a Rig'}
          </h2>
          {modal.phase !== 'key_shown' && (
            <button onClick={onClose} className="text-muted hover:text-white transition-colors">
              <X size={16} />
            </button>
          )}
        </div>

        {modal.phase === 'registering' && (
          <>
            <div className="space-y-2">
              <label className="text-xs text-muted font-medium">Rig name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && name.trim()) registerMutation.mutate(name.trim())
                }}
                placeholder="my-bench-001"
                className="w-full px-3 py-2 rounded-lg bg-white/[0.04] border border-white/[0.08] text-white text-sm placeholder:text-muted/50 focus:outline-none focus:border-accent/50 transition-colors"
                autoFocus
              />
            </div>

            {registerMutation.isError && (
              <p className="text-xs text-fail">
                {(registerMutation.error as { response?: { data?: { detail?: string } } })?.response?.data?.detail ?? 'Registration failed — check the name and try again.'}
              </p>
            )}

            <div className="flex gap-2 justify-end pt-1">
              <button
                onClick={onClose}
                className="px-3 py-1.5 text-xs text-muted hover:text-white border border-white/[0.08] rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => name.trim() && registerMutation.mutate(name.trim())}
                disabled={!name.trim() || registerMutation.isPending}
                className="px-3 py-1.5 text-xs font-medium bg-accent hover:bg-accent/80 text-white rounded-lg transition-colors disabled:opacity-50"
              >
                {registerMutation.isPending ? 'Registering…' : 'Register'}
              </button>
            </div>
          </>
        )}

        {modal.phase === 'key_shown' && (
          <>
            <div className="flex items-center gap-2 text-xs text-pass">
              <Check size={14} />
              <span><span className="font-semibold text-white">{modal.rigName}</span> registered successfully</span>
            </div>

            <div className="space-y-2">
              <p className="text-xs text-muted font-medium">API Key — copy it now, it won't be shown again</p>
              <div className="flex items-center gap-2 p-3 rounded-lg bg-white/[0.04] border border-white/[0.08]">
                <code className="flex-1 text-xs font-mono text-white/80 break-all">{modal.apiKey}</code>
                <button
                  onClick={handleCopy}
                  className="flex-shrink-0 text-muted hover:text-white transition-colors"
                  title="Copy to clipboard"
                >
                  {copied ? <Check size={14} className="text-pass" /> : <Copy size={14} />}
                </button>
              </div>
              <p className="text-xs text-muted/70">
                Add to your rig TOML: <code className="text-white/60 font-mono">api_key = &quot;{modal.apiKey.slice(0, 20)}…&quot;</code>
              </p>
            </div>

            <button
              onClick={onClose}
              className="w-full px-3 py-2 text-xs font-medium bg-accent hover:bg-accent/80 text-white rounded-lg transition-colors"
            >
              Done — I've saved the key
            </button>
          </>
        )}
      </div>
    </div>
  )
}

// ── RigsPage ───────────────────────────────────────────────────────────────────

export function RigsPage() {
  const { role } = useAuth()
  const [showModal, setShowModal] = useState(false)

  const { data: rigs, isLoading, error } = useQuery<RigDetail[]>({
    queryKey: ['rigs'],
    queryFn: () => api.get<RigDetail[]>('/api/v1/rigs').then((r) => r.data),
    refetchInterval: 15_000,
  })

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Rigs</h1>
          <p className="text-sm text-muted mt-1">Hardware rigs registered to this control plane</p>
        </div>
        {role === 'admin' && (
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-accent hover:bg-accent/80 text-white rounded-lg transition-colors"
          >
            <Plus size={13} />
            Register Rig
          </button>
        )}
      </div>

      {error ? (
        <ErrorDisplay message="Failed to load rigs." />
      ) : isLoading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-36" />)}
        </div>
      ) : !rigs?.length ? (
        <EmptyState
          icon={<Server size={24} />}
          message="No rigs registered yet."
          sub={role === 'admin' ? 'Click "Register Rig" above to add one.' : 'Ask an admin to register a rig.'}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {rigs.map((rig) => (
            <Link key={rig.id} to={`/rigs/${rig.id}`}>
              <div className="card-base card-hover p-5 cursor-pointer h-full flex flex-col gap-4">
                {/* Top row */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white/[0.04] border border-white/[0.07] flex items-center justify-center flex-shrink-0">
                      <Server size={17} className="text-muted" />
                    </div>
                    <div>
                      <p className="font-semibold text-white">{rig.name}</p>
                      {rig.version && (
                        <p className="text-xs text-muted/70 mt-0.5 font-mono">agent v{rig.version}</p>
                      )}
                    </div>
                  </div>
                  <ChevronRight size={16} className="text-muted/40 mt-1" />
                </div>

                {/* Metadata */}
                <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs border-t border-white/[0.05] pt-3">
                  <span className="text-muted">Status</span>
                  <span className="flex justify-end"><RigOnlineIndicator lastSeenAt={rig.last_seen_at} /></span>

                  <span className="text-muted">Registered</span>
                  <span className="text-white/70 text-right">{format(new Date(rig.created_at * 1000), 'MMM d, yyyy')}</span>

                  <span className="text-muted">ID</span>
                  <span className="font-mono text-muted/60 text-right truncate">{rig.id.slice(0, 12)}…</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}

      {showModal && <RegisterRigModal onClose={() => setShowModal(false)} />}
    </div>
  )
}
