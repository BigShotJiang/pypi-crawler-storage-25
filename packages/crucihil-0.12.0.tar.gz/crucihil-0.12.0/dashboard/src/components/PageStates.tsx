import type { ReactNode } from 'react'
import { AlertCircle, Inbox } from 'lucide-react'

export function EmptyState({
  icon,
  message,
  sub,
}: {
  icon?: ReactNode
  message: string
  sub?: string
}) {
  return (
    <div className="flex flex-col items-center justify-center h-40 gap-3 border border-white/[0.06] rounded-xl bg-white/[0.01]">
      <span className="text-muted/50">{icon ?? <Inbox size={24} />}</span>
      <div className="text-center">
        <p className="text-sm text-muted">{message}</p>
        {sub && <p className="text-xs text-muted/60 mt-1">{sub}</p>}
      </div>
    </div>
  )
}

export function ErrorDisplay({ message }: { message: string }) {
  return (
    <div className="flex items-start gap-3 text-fail bg-fail/[0.06] border border-fail/20 rounded-xl px-4 py-3.5">
      <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
      <p className="text-sm">{message}</p>
    </div>
  )
}
