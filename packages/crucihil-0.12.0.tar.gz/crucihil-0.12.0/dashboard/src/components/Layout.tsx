import { NavLink, Outlet } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import {
  LayoutDashboard,
  Server,
  PlayCircle,
  Settings,
  LogOut,
  Zap,
} from 'lucide-react'

const NAV_ITEMS = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/rigs', label: 'Rigs', icon: Server, end: false },
  { to: '/runs', label: 'Runs', icon: PlayCircle, end: false },
  { to: '/settings', label: 'Settings', icon: Settings, end: false },
]

export function Layout() {
  const { logout } = useAuth()

  return (
    <div className="flex h-screen overflow-hidden bg-base text-white">
      {/* ── Sidebar ── */}
      <aside className="w-52 flex-shrink-0 flex flex-col bg-surface border-r border-[rgba(204,204,220,0.09)]">
        {/* Logo */}
        <div className="px-4 h-11 flex items-center gap-2.5 border-b border-[rgba(204,204,220,0.09)]">
          <div className="w-6 h-6 rounded flex items-center justify-center bg-accent/20 border border-accent/40 flex-shrink-0">
            <Zap size={13} className="text-accent-light" />
          </div>
          <span className="font-bold tracking-tight text-sm text-white">CruciHiL</span>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-3 px-2 space-y-px">
          {NAV_ITEMS.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `relative group flex items-center gap-2.5 px-3 py-2 rounded text-sm transition-all duration-100 ${
                  isActive
                    ? 'bg-white/[0.07] text-white font-medium'
                    : 'text-muted hover:text-white hover:bg-white/[0.04]'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  {isActive && <span className="nav-active-bar" />}
                  <Icon
                    size={15}
                    className={`flex-shrink-0 transition-colors ${
                      isActive ? 'text-accent-light' : 'text-subtle group-hover:text-muted'
                    }`}
                  />
                  {label}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        {/* Footer */}
        <div className="px-2 py-3 border-t border-[rgba(204,204,220,0.09)]">
          <button
            onClick={logout}
            className="group flex items-center gap-2.5 px-3 py-2 w-full rounded text-sm text-muted hover:text-white hover:bg-white/[0.04] transition-all duration-100"
          >
            <LogOut size={15} className="text-subtle group-hover:text-fail transition-colors" />
            Log out
          </button>
          <p className="text-[10px] text-subtle/50 px-3 pt-1 font-mono select-none">
            {__GIT_HASH__}
          </p>
        </div>
      </aside>

      {/* ── Main content ── */}
      <main className="flex-1 overflow-y-auto bg-base">
        <div className="max-w-7xl mx-auto px-6 py-5">
          <Outlet />
        </div>
      </main>
    </div>
  )
}
