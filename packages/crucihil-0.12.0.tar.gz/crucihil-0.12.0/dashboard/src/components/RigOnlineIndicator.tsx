import { differenceInSeconds, formatDistanceToNowStrict } from 'date-fns'

const ONLINE_THRESHOLD_S = 90

export function RigOnlineIndicator({ lastSeenAt }: { lastSeenAt: number | null }) {
  if (lastSeenAt === null) {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs text-muted">
        <span className="w-2 h-2 rounded-full bg-muted/40 flex-shrink-0" />
        Never seen
      </span>
    )
  }

  const date = new Date(lastSeenAt * 1000)
  const secondsAgo = differenceInSeconds(new Date(), date)
  const online = secondsAgo <= ONLINE_THRESHOLD_S

  return (
    <span className={`inline-flex items-center gap-1.5 text-xs ${online ? 'text-pass' : 'text-muted'}`}>
      <span className="relative flex-shrink-0 w-2 h-2">
        {online && (
          <span className="absolute inset-0 rounded-full bg-pass/40 animate-ping" />
        )}
        <span className={`relative block w-2 h-2 rounded-full ${online ? 'bg-pass' : 'bg-muted/40'}`} />
      </span>
      {online ? 'Online' : formatDistanceToNowStrict(date, { addSuffix: true })}
    </span>
  )
}
