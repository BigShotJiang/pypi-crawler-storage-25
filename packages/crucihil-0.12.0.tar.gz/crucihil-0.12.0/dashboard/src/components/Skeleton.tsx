export function Skeleton({ className = '' }: { className?: string }) {
  return (
    <div
      className={`rounded-lg bg-gradient-to-r from-white/[0.04] via-white/[0.07] to-white/[0.04] bg-[length:200%_100%] animate-shimmer ${className}`}
    />
  )
}

export function SkeletonRows({ count = 4 }: { count?: number }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: count }).map((_, i) => (
        <Skeleton
          key={i}
          className={`h-12 ${i === count - 1 ? 'w-4/5' : 'w-full'}`}
        />
      ))}
    </div>
  )
}

export function SkeletonText({ width = 'w-32', height = 'h-4' }: { width?: string; height?: string }) {
  return <Skeleton className={`${width} ${height} rounded`} />
}
