import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  SkipForward,
  Clock,
  Loader2,
  Ban,
  AlertCircle,
} from 'lucide-react'
import type { RunStatus, TestStatus } from '../types/api'

type AnyStatus = TestStatus | RunStatus

interface StyleConfig {
  color: string      // tailwind text color
  bg: string         // tailwind bg for the badge
  bar: string        // left accent bar color
  icon: React.ElementType
}

const STYLES: Record<AnyStatus, StyleConfig> = {
  pass:      { color: 'text-pass',        bg: 'bg-pass/10',          bar: 'bg-pass',        icon: CheckCircle2 },
  passed:    { color: 'text-pass',        bg: 'bg-pass/10',          bar: 'bg-pass',        icon: CheckCircle2 },
  fail:      { color: 'text-fail',        bg: 'bg-fail/10',          bar: 'bg-fail',        icon: XCircle },
  failed:    { color: 'text-fail',        bg: 'bg-fail/10',          bar: 'bg-fail',        icon: XCircle },
  error:     { color: 'text-fail',        bg: 'bg-fail/10',          bar: 'bg-fail',        icon: AlertCircle },
  blocked:   { color: 'text-warn',        bg: 'bg-warn/10',          bar: 'bg-warn',        icon: AlertTriangle },
  skip:      { color: 'text-muted',       bg: 'bg-white/[0.05]',     bar: 'bg-subtle',      icon: SkipForward },
  queued:    { color: 'text-info',        bg: 'bg-info/10',          bar: 'bg-info',        icon: Clock },
  running:   { color: 'text-accent-light',bg: 'bg-accent/10',        bar: 'bg-accent',      icon: Loader2 },
  cancelled: { color: 'text-muted',       bg: 'bg-white/[0.05]',     bar: 'bg-subtle',      icon: Ban },
}

export function StatusBadge({ status }: { status: AnyStatus }) {
  const cfg = STYLES[status] ?? { color: 'text-muted', bg: 'bg-white/[0.05]', bar: 'bg-subtle', icon: AlertCircle }
  const Icon = cfg.icon
  const isSpinning = status === 'running'

  return (
    <span
      className={`inline-flex items-center gap-1.5 pl-0 pr-2.5 py-0.5 text-xs font-medium rounded-sm overflow-hidden ${cfg.bg} ${cfg.color}`}
    >
      {/* Grafana-style left color bar */}
      <span className={`w-[3px] self-stretch flex-shrink-0 ${cfg.bar}`} />
      <Icon
        size={11}
        className={`flex-shrink-0 ml-1.5 ${isSpinning ? 'animate-spin' : ''}`}
      />
      {status}
    </span>
  )
}

export function StatusDot({ status }: { status: AnyStatus }) {
  const cfg = STYLES[status] ?? { color: 'text-muted', bg: 'bg-white/[0.05]', bar: 'bg-subtle', icon: AlertCircle }
  const isRunning = status === 'running'
  return (
    <span
      className={`w-2 h-2 rounded-full flex-shrink-0 ${cfg.bar} ${isRunning ? 'animate-pulse' : ''}`}
    />
  )
}
