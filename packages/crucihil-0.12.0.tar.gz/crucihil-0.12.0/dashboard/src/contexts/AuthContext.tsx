import {
  createContext,
  useCallback,
  useMemo,
  useState,
  type ReactNode,
} from 'react'

interface JwtPayload {
  sub?: string
  org_id?: string
  org_slug?: string
  role?: string
  type?: string
  exp?: number
  rig_id?: string
}

interface AuthContextValue {
  token: string | null
  isAuthenticated: boolean
  role: 'admin' | 'member' | 'viewer' | null
  tokenType: 'user' | 'rig' | 'viewer' | null
  orgId: string | null
  orgSlug: string | null
  login: (token: string) => void
  logout: () => void
}

export const AuthContext = createContext<AuthContextValue>({
  token: null,
  isAuthenticated: false,
  role: null,
  tokenType: null,
  orgId: null,
  orgSlug: null,
  login: () => {},
  logout: () => {},
})

function parsePayload(token: string): JwtPayload | null {
  try {
    const parts = token.split('.')
    if (parts.length !== 3) return null
    return JSON.parse(atob(parts[1])) as JwtPayload
  } catch {
    return null
  }
}

function isExpired(token: string): boolean {
  const p = parsePayload(token)
  return !p || (typeof p.exp === 'number' && p.exp * 1000 < Date.now())
}

function extractRole(p: JwtPayload): 'admin' | 'member' | 'viewer' | null {
  if (p.role === 'admin') return 'admin'
  if (p.role === 'member') return 'member'
  if (p.role === 'viewer') return 'viewer'
  return null
}

function extractTokenType(p: JwtPayload): 'user' | 'rig' | 'viewer' | null {
  if (p.type === 'user') return 'user'
  if (p.type === 'rig') return 'rig'
  if (p.type === 'viewer') return 'viewer'
  return null
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(
    () => localStorage.getItem('crucihil_jwt'),
  )

  const login = useCallback((t: string) => {
    localStorage.setItem('crucihil_jwt', t)
    setToken(t)
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem('crucihil_jwt')
    setToken(null)
  }, [])

  const value = useMemo(() => {
    const active = token !== null && !isExpired(token)
    const payload = active && token ? parsePayload(token) : null
    return {
      token,
      isAuthenticated: active,
      role: payload ? extractRole(payload) : null,
      tokenType: payload ? extractTokenType(payload) : null,
      orgId: payload?.org_id ?? null,
      orgSlug: payload?.org_slug ?? null,
      login,
      logout,
    }
  }, [token, login, logout])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
