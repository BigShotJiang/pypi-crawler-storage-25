export interface RigDetail {
  id: string
  name: string
  role: string
  connected: boolean
  last_seen_at: number | null
  version: string | null
  created_at: number
  extra_meta: Record<string, unknown>
}

export interface UserSummary {
  id: string
  email: string
  role: 'admin' | 'member'
  joined_at: number | null
  created_at: number
}

export interface RigRegisterResponse {
  rig: RigDetail
  api_key: string
}

export type RunStatus =
  | 'queued'
  | 'running'
  | 'passed'
  | 'failed'
  | 'cancelled'
  | 'error'

export type TestStatus = 'pass' | 'fail' | 'blocked' | 'skip' | 'error'

export interface RunSummary {
  id: string
  rig_id: string
  suite_name: string
  started_at: number
  completed_at: number | null
  status: RunStatus
  total: number
  passed: number
  failed: number
  blocked: number
  errored: number
  skipped: number
  triggered_by: string | null
}

export interface ResultSummary {
  id: number
  test_id: string
  run_id: string
  suite_name: string
  status: TestStatus
  duration: number
  started_at: number
  completed_at: number
  error_message: string | null
  tags: string[]
  suite_types: string[]
  priority: string | null
}

export interface ResultDetail extends ResultSummary {
  errors: string[]
  logs: string[]
  signals: Record<string, unknown>
  extra_meta: {
    source_code?: string
    module?: string
    function?: string
    params?: Record<string, unknown>
    requirements?: string[]
    ticket?: string
    hw_variants?: string[]
    [key: string]: unknown
  }
}

export const TERMINAL_STATUSES: RunStatus[] = [
  'passed',
  'failed',
  'cancelled',
  'error',
]

export function isTerminal(status: RunStatus | undefined): boolean {
  return status !== undefined && TERMINAL_STATUSES.includes(status)
}
