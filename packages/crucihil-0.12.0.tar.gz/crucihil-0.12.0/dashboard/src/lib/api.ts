import axios from 'axios'

const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'

const api = axios.create({ baseURL: BASE_URL })

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('crucihil_jwt')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

let _redirecting = false

api.interceptors.response.use(
  (res) => res,
  (error: unknown) => {
    const status =
      axios.isAxiosError(error) ? error.response?.status : undefined
    if (status === 401 && !_redirecting) {
      _redirecting = true
      localStorage.removeItem('crucihil_jwt')
      sessionStorage.setItem('crucihil_session_expired', '1')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  },
)

export function getWsViewerUrl(runId: string): string {
  const wsBase = BASE_URL.replace(/^http/, 'ws')
  return `${wsBase}/ws/viewer?run_id=${encodeURIComponent(runId)}`
}

export default api
