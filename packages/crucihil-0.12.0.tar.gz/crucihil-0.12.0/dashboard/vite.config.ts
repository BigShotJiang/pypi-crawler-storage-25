import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { execSync } from 'child_process'
import path from 'path'

const gitHash = (() => {
  // Allow injection from Docker / CI (container has no .git directory).
  if (process.env.VITE_GIT_HASH) return process.env.VITE_GIT_HASH
  try {
    // Run git from the repo root in case vite was started from a subdirectory.
    const cwd = path.resolve(__dirname, '..')
    return execSync('git rev-parse --short HEAD', { cwd }).toString().trim()
  } catch {
    return 'dev'
  }
})()

export default defineConfig({
  plugins: [react()],
  define: {
    __GIT_HASH__: JSON.stringify(gitHash),
  },
})
