import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'ui-monospace', 'monospace'],
      },
      colors: {
        // Dark canvas hierarchy
        base:        '#0c0c16',   // canvas — outermost background
        surface:     '#111120',   // sidebar, navbar
        card:        '#18182a',   // panel background
        'card-hover':'#1e1e32',   // panel hover
        // Indigo/violet accent — matches landing page
        accent:      '#6366f1',
        'accent-light': '#818cf8',
        'accent-dim':   '#4f52c4',
        // Status
        pass:        '#10b981',
        'pass-dim':  '#059669',
        fail:        '#f2495c',
        'fail-dim':  '#c73649',
        warn:        '#f59e0b',
        'warn-dim':  '#d97706',
        info:        '#6dc3f7',
        // Text
        muted:       '#8888a8',
        subtle:      '#4a4a68',
        // Borders
        'border-subtle': 'rgba(204,204,220,0.09)',
        'border-strong': 'rgba(204,204,220,0.18)',
      },
      borderRadius: {
        DEFAULT: '2px',
        sm: '2px',
        md: '4px',
        lg: '4px',
        xl: '6px',
        '2xl': '6px',
        full: '9999px',
      },
      boxShadow: {
        card:       '0 1px 3px rgba(0,0,0,0.4), 0 0 0 1px rgba(204,204,220,0.09)',
        'card-hover':'0 1px 6px rgba(0,0,0,0.5), 0 0 0 1px rgba(99,102,241,0.3)',
        glow:       '0 0 20px rgba(99,102,241,0.2)',
        'glow-sm':  '0 0 10px rgba(99,102,241,0.12)',
        'inset-top':'inset 0 1px 0 rgba(204,204,220,0.06)',
        panel:      '0 4px 10px rgba(0,0,0,0.4)',
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
      },
      keyframes: {
        'fade-in': {
          '0%':   { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'slide-up': {
          '0%':   { opacity: '0', transform: 'translateY(6px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '0%':   { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        'pulse-dot': {
          '0%, 100%': { opacity: '1', transform: 'scale(1)' },
          '50%':      { opacity: '0.5', transform: 'scale(0.85)' },
        },
      },
      animation: {
        'fade-in':  'fade-in 0.2s ease-out',
        'slide-up': 'slide-up 0.25s ease-out',
        shimmer:    'shimmer 2s linear infinite',
        'pulse-dot':'pulse-dot 2s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}

export default config
