#!/usr/bin/env bash
# dev.sh — CruciHiL local development server
#
# Starts backend (db + server + mcp) via Docker Compose, then runs the
# React dashboard dev server natively (Vite HMR, no Docker volume lag).
#
# Usage:
#   ./dev.sh                              Backend + dashboard
#   ./dev.sh --agent                      Also start the Docker virtual rig agent
#   ./dev.sh --rig rigs/my_rig.toml      Register + start a native agent for a TOML
#                                         (--rig can be repeated for multiple rigs)
#   ./dev.sh --backend                    Backend only (no dashboard)
#   ./dev.sh --dashboard                  Dashboard only (backend must already be running)
#   ./dev.sh --status                     Show container health + rig connectivity
#   ./dev.sh --stop                       Stop all containers + kill native agents
#
# On Ctrl-C: native agent processes are killed, containers are stopped.

set -euo pipefail

# ── Colors ─────────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; DIM='\033[2m'; NC='\033[0m'

step() { echo -e "\n${BOLD}${BLUE}▸${NC}${BOLD} $*${NC}"; }
ok()   { echo -e "  ${GREEN}✓${NC} $*"; }
info() { echo -e "  ${CYAN}·${NC} $*"; }
warn() { echo -e "  ${YELLOW}⚠${NC} $*"; }
die()  { echo -e "\n  ${RED}✗ Error:${NC} $*\n" >&2; exit 1; }

command_exists() { command -v "$1" >/dev/null 2>&1; }

# ── Detect docker compose ──────────────────────────────────────────────────────
detect_compose() {
  if docker compose version >/dev/null 2>&1; then
    echo "docker compose"
  elif command_exists docker-compose; then
    echo "docker-compose"
  else
    die "Neither 'docker compose' (v2) nor 'docker-compose' (v1) found."
  fi
}

# ── HTTP helpers ───────────────────────────────────────────────────────────────
http_get() {
  if command_exists curl; then
    curl -sf "$1" 2>/dev/null
  else
    wget -qO- "$1" 2>/dev/null
  fi
}

http_get_auth() {
  local url="$1" auth_header="$2"
  if command_exists curl; then
    curl -sf -H "Authorization: $auth_header" "$url" 2>/dev/null
  else
    wget -qO- --header="Authorization: $auth_header" "$url" 2>/dev/null
  fi
}

http_post_json() {
  local url="$1" data="$2" auth_header="${3:-}"
  if command_exists curl; then
    if [[ -n "$auth_header" ]]; then
      curl -sf -X POST "$url" \
        -H 'Content-Type: application/json' \
        -H "Authorization: $auth_header" \
        -d "$data" 2>/dev/null
    else
      curl -sf -X POST "$url" -H 'Content-Type: application/json' -d "$data" 2>/dev/null
    fi
  else
    if [[ -n "$auth_header" ]]; then
      wget -qO- --method=POST \
        --header='Content-Type: application/json' \
        --header="Authorization: $auth_header" \
        --body-data="$data" "$url" 2>/dev/null
    else
      wget -qO- --method=POST \
        --header='Content-Type: application/json' \
        --body-data="$data" "$url" 2>/dev/null
    fi
  fi
}

extract_json_field() {
  local json="$1" field="$2"
  echo "$json" | python3 -c \
    "import sys, json; d=json.load(sys.stdin); print(d.get('$field',''))" 2>/dev/null
}

update_env_var() {
  local key="$1" value="$2"
  if grep -q "^${key}=" .env 2>/dev/null; then
    sed -i "s|^${key}=.*|${key}=${value}|" .env
  else
    echo "${key}=${value}" >> .env
  fi
}

# ── Rig helpers ────────────────────────────────────────────────────────────────

# Convert a rig name to its .env key: "my-rig_01" → "CRUCIHIL_RIG_KEY_MY_RIG_01"
_rig_env_key() {
  echo "CRUCIHIL_RIG_KEY_$(echo "$1" | tr '[:lower:]' '[:upper:]' | tr '-' '_')"
}

# Parse the rig name out of a TOML file
_toml_rig_name() {
  # Use venv Python if available (has tomllib on 3.11+); fall back to system python3.
  local py="python3"
  [[ -x "$SCRIPT_DIR/.venv/bin/python3" ]] && py="$SCRIPT_DIR/.venv/bin/python3"
  "$py" -c "
import sys
try:
    import tomllib
except ImportError:
    import tomli as tomllib
with open(sys.argv[1], 'rb') as f:
    d = tomllib.load(f)
print(d['rig']['name'])
" "$1" 2>/dev/null
}

# Register a rig (or load its key from .env), returns the raw API key via stdout.
# If the rig is already registered on the server but the key is not in .env
# (e.g. a previous script run crashed before saving), this function will
# delete the stale registration using the default-rig admin JWT and re-register.
_register_or_load_rig_key() {
  # All status output goes to stderr so the caller can capture just the API key via $().
  local toml_path="$1"

  local rig_name
  rig_name=$(_toml_rig_name "$toml_path") \
    || { warn "Could not parse rig name from $toml_path" >&2; return 1; }

  local env_key
  env_key=$(_rig_env_key "$rig_name")

  # Re-source .env to pick up any previously saved key
  set -a; source .env; set +a
  local api_key="${!env_key:-}"

  if [[ -n "$api_key" ]]; then
    ok "Rig '${rig_name}' key loaded from .env" >&2
    echo "$api_key"
    return 0
  fi

  local reg_token="${REGISTRATION_TOKEN:-}"
  [[ -n "$reg_token" ]] \
    || { warn "REGISTRATION_TOKEN not set — run ./setup.sh first" >&2; return 1; }

  info "Registering rig '${rig_name}' with the control plane..." >&2
  local resp
  resp=$(http_post_json \
    "http://localhost:8000/api/v1/rigs" \
    "{\"name\":\"${rig_name}\"}" \
    "Authorization: Bearer ${reg_token}") || true

  api_key=$(extract_json_field "$resp" "api_key" 2>/dev/null) || true

  if [[ -z "$api_key" ]]; then
    # Likely 409 — rig already registered but key was lost.
    # Delete via the default-rig admin JWT and re-register.
    warn "Rig '${rig_name}' already registered but key not in .env — re-registering..." >&2

    local main_key="${CRUCIHIL_API_KEY:-}"
    if [[ -z "$main_key" ]]; then
      warn "Cannot re-register: CRUCIHIL_API_KEY not set (run ./setup.sh first)" >&2
      return 1
    fi

    local token_resp admin_token
    token_resp=$(http_post_json "http://localhost:8000/api/v1/auth/token" \
      "{\"api_key\":\"${main_key}\"}") || true
    admin_token=$(extract_json_field "$token_resp" "access_token" 2>/dev/null) || true

    if [[ -n "$admin_token" ]]; then
      if command_exists curl; then
        curl -sf -X DELETE "http://localhost:8000/api/v1/rigs/${rig_name}" \
          -H "Authorization: Bearer ${admin_token}" >/dev/null 2>&1 || true
      else
        wget -q --method=DELETE \
          --header="Authorization: Bearer ${admin_token}" \
          "http://localhost:8000/api/v1/rigs/${rig_name}" >/dev/null 2>&1 || true
      fi
      info "Old '${rig_name}' registration removed — re-registering..." >&2
    fi

    resp=$(http_post_json \
      "http://localhost:8000/api/v1/rigs" \
      "{\"name\":\"${rig_name}\"}" \
      "Authorization: Bearer ${reg_token}") || true
    api_key=$(extract_json_field "$resp" "api_key" 2>/dev/null) || true
  fi

  if [[ -z "$api_key" ]]; then
    warn "Registration failed for '${rig_name}' — check server logs" >&2
    return 1
  fi

  update_env_var "$env_key" "$api_key"
  ok "Rig '${rig_name}' registered → key saved as ${env_key} in .env" >&2
  echo "$api_key"
}

# ── Status ─────────────────────────────────────────────────────────────────────
_show_rig_status() {
  local server_url="${1:-http://localhost:8000}"

  # Re-source .env for API key
  [[ -f .env ]] && { set -a; source .env; set +a; }
  local api_key="${CRUCIHIL_API_KEY:-}"

  if [[ -z "$api_key" ]]; then
    warn "CRUCIHIL_API_KEY not set — cannot check rig connectivity"
    return
  fi

  local token_json
  token_json=$(http_post_json "${server_url}/api/v1/auth/token" \
    "{\"api_key\":\"${api_key}\"}") 2>/dev/null || true

  local token
  token=$(extract_json_field "$token_json" "access_token" 2>/dev/null) || true

  if [[ -z "$token" ]]; then
    warn "Could not obtain auth token — is the server running at ${server_url}?"
    return
  fi

  local rigs_json
  rigs_json=$(http_get_auth "${server_url}/api/v1/rigs" "Bearer ${token}") || true

  if [[ -z "$rigs_json" ]]; then
    warn "Could not fetch rig list"
    return
  fi

  echo "$rigs_json" | python3 -c "
import sys, json, time
rigs = json.load(sys.stdin)
if not rigs:
    print('  No rigs registered yet.')
    sys.exit(0)
for r in rigs:
    connected = r.get('connected', False)
    icon  = '\033[0;32m●\033[0m' if connected else '\033[2m○\033[0m'
    state = 'online ' if connected else 'offline'
    last  = r.get('last_seen_at')
    age   = ''
    if last:
        secs = int(time.time() - last)
        if secs < 60:
            age = f'{secs}s ago'
        elif secs < 3600:
            age = f'{secs//60}m ago'
        else:
            age = f'{secs//3600}h ago'
    ver = r.get('version') or ''
    print(f'  {icon}  {r[\"name\"]:30}  {state}  {age:12}  {ver}')
"
}

# ── Parse args ─────────────────────────────────────────────────────────────────
BACKEND=true
DASHBOARD=true
DOCKER_AGENT=false
LOCAL_RIGS=()   # paths to TOML files for native agents

while [[ $# -gt 0 ]]; do
  case "$1" in
    --backend)   DASHBOARD=false; shift ;;
    --dashboard) BACKEND=false; shift   ;;
    --agent)     DOCKER_AGENT=true; shift ;;
    --rig)
      [[ $# -ge 2 ]] || die "--rig requires a path argument"
      LOCAL_RIGS+=("$2"); shift 2 ;;
    --rig=*)     LOCAL_RIGS+=("${1#--rig=}"); shift ;;
    --status)
      DC=$(detect_compose)
      step "Container status"
      $DC ps
      step "Rig connectivity"
      _show_rig_status
      exit 0
      ;;
    --stop)
      DC=$(detect_compose)
      step "Stopping all services"
      $DC --profile agent stop agent db server mcp 2>/dev/null \
        || $DC stop db server mcp 2>/dev/null \
        || true
      rm -f .native_agent_*.run 2>/dev/null || true
      if [[ -f .native_agent_pids ]]; then
        while IFS= read -r pid; do
          kill -- "-$pid" 2>/dev/null || kill "$pid" 2>/dev/null || true
        done < .native_agent_pids
        rm -f .native_agent_pids
        ok "Native agent processes stopped"
      fi
      ok "Done"
      exit 0
      ;;
    --help|-h) sed -n '2,20p' "$0" | sed 's/^# \?//'; exit 0 ;;
    *) die "Unknown option: $1  (try --help)" ;;
  esac
done

DC=$(detect_compose)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export GIT_HASH
GIT_HASH=$(git -C "$SCRIPT_DIR" rev-parse --short HEAD 2>/dev/null || echo "dev")

echo ""
echo -e "${BOLD}${BLUE}  CruciHiL${NC} — Development Server"
echo -e "  ${DIM}Backend via Docker · Dashboard via Vite HMR${NC}"
echo ""

# ── Native agent PID tracking (for cleanup) ────────────────────────────────────
NATIVE_AGENT_PIDS=()
rm -f .native_agent_pids  # clear stale PIDs from previous run

_cleanup() {
  echo ""
  # Kill native agent processes and remove sentinel files so restart loops stop
  local pids=("${NATIVE_AGENT_PIDS[@]:-}")
  if [[ ${#pids[@]} -gt 0 ]]; then
    step "Stopping native agents"
    rm -f .native_agent_*.run 2>/dev/null || true  # stop restart loops
    for pid in "${pids[@]}"; do
      # Kill the whole process group so the crucihil child is also terminated
      kill -- "-$pid" 2>/dev/null || kill "$pid" 2>/dev/null || true
    done
    rm -f .native_agent_pids
  fi
  # Stop backend containers
  if [[ "$BACKEND" == true ]]; then
    step "Stopping backend containers"
    if [[ "$DOCKER_AGENT" == true ]]; then
      $DC --profile agent stop agent db server mcp 2>/dev/null || true
    else
      $DC stop db server mcp 2>/dev/null || true
    fi
    ok "Backend stopped"
  fi
}
trap _cleanup EXIT INT TERM

# ── Backend ────────────────────────────────────────────────────────────────────
if [[ "$BACKEND" == true ]]; then
  step "Starting backend services"

  if [[ ! -f "$SCRIPT_DIR/.env" ]]; then
    if [[ -f "$SCRIPT_DIR/.env.example" ]]; then
      cp "$SCRIPT_DIR/.env.example" "$SCRIPT_DIR/.env"
      warn ".env not found — created from .env.example. Run ./setup.sh for full bootstrap."
    else
      die ".env not found. Run ./setup.sh first."
    fi
  fi

  $DC up -d db server mcp
  ok "Backend containers started (db + server + mcp)"

  # Wait for server health
  info "Waiting for server at http://localhost:8000 ..."
  ATTEMPTS=0
  until http_get "http://localhost:8000/openapi.json" >/dev/null; do
    ATTEMPTS=$((ATTEMPTS + 1))
    [[ $ATTEMPTS -lt 30 ]] || { echo ""; die "Server not responding after 90s.\nCheck: $DC logs server"; }
    printf "."
    sleep 3
  done
  echo ""
  ok "Server is healthy → http://localhost:8000/docs"
  ok "MCP server        → http://localhost:8001/sse"

  # ── Docker virtual agent ────────────────────────────────────────────────────
  if [[ "$DOCKER_AGENT" == true ]]; then
    set -a; source "$SCRIPT_DIR/.env"; set +a
    if [[ -z "${CRUCIHIL_API_KEY:-}" ]]; then
      warn "--agent requested but CRUCIHIL_API_KEY is not set in .env"
      warn "Run ./setup.sh first to register a rig and populate CRUCIHIL_API_KEY"
    else
      if $DC --profile agent up -d --force-recreate agent; then
        ok "Docker virtual agent started (rigs/virtual.toml)"
      else
        warn "Docker agent failed to start — check: $DC logs agent"
        warn "Continuing without Docker virtual agent."
      fi
    fi
  fi

  # ── Native agents from --rig flags ──────────────────────────────────────────
  if [[ ${#LOCAL_RIGS[@]} -gt 0 ]]; then
    step "Starting native rig agents"
    set -a; source "$SCRIPT_DIR/.env"; set +a

    for toml_path in "${LOCAL_RIGS[@]}"; do
      [[ -f "$toml_path" ]] || { warn "TOML not found: $toml_path — skipping"; continue; }

      # Register or load key for this rig
      rig_api_key=$(_register_or_load_rig_key "$toml_path") || continue

      # Re-source .env after registration (key may have been written)
      set -a; source "$SCRIPT_DIR/.env"; set +a

      rig_name=$(_toml_rig_name "$toml_path")

      # Resolve crucihil CLI — prefer project venv so dev.sh works without
      # manually activating the venv first.
      CRUCIHIL_BIN=""
      if [[ -x "$SCRIPT_DIR/.venv/bin/crucihil" ]]; then
        CRUCIHIL_BIN="$SCRIPT_DIR/.venv/bin/crucihil"
      elif command_exists crucihil; then
        CRUCIHIL_BIN="crucihil"
      else
        warn "crucihil CLI not found — install with: pip install -e ."
        continue
      fi

      # Start native agent in a restart-on-exit loop (mirrors Docker restart: unless-stopped).
      # The loop checks a sentinel file; cleanup removes it to stop restarting.
      sentinel=".native_agent_${rig_name}.run"
      touch "$sentinel"
      (
        while [[ -f "$sentinel" ]]; do
          CRUCIHIL_API_KEY="$rig_api_key" \
          CRUCIHIL_BASE_URL="http://localhost:8000" \
            "$CRUCIHIL_BIN" agent --rig "$toml_path" 2>&1 \
            | sed "s/^/[${rig_name}] /" || true
          [[ -f "$sentinel" ]] || break
          echo "[${rig_name}] Agent exited — restarting in 5s..."
          sleep 5
        done
      ) &
      pid=$!
      NATIVE_AGENT_PIDS+=("$pid")
      echo "$pid" >> .native_agent_pids
      ok "Native agent started (PID $pid, auto-restart) — ${toml_path} → http://localhost:8000"
    done
  fi
fi

# ── Dashboard ─────────────────────────────────────────────────────────────────
if [[ "$DASHBOARD" == true ]]; then
  DASH_DIR="$SCRIPT_DIR/dashboard"
  [[ -d "$DASH_DIR" ]] || die "dashboard/ directory not found at $DASH_DIR"
  command_exists node || die "Node.js not found. Install from https://nodejs.org"
  command_exists npm  || die "npm not found. Install from https://nodejs.org"

  step "Setting up dashboard"
  if [[ ! -d "$DASH_DIR/node_modules" ]]; then
    info "Installing npm dependencies..."
    (cd "$DASH_DIR" && npm install --silent)
    ok "Dependencies installed"
  fi

  # ── Summary ──────────────────────────────────────────────────────────────────
  echo ""
  echo -e "${BOLD}${GREEN}  Ready!${NC}"
  echo ""
  echo -e "  ${BOLD}Dashboard  :${NC}  http://localhost:5173"
  echo -e "  ${BOLD}API        :${NC}  http://localhost:8000"
  echo -e "  ${BOLD}API docs   :${NC}  http://localhost:8000/docs"
  echo -e "  ${BOLD}MCP SSE    :${NC}  http://localhost:8001/sse"
  if [[ "$DOCKER_AGENT" == true ]]; then
    echo -e "  ${BOLD}Virtual rig:${NC}  Docker agent connected (rigs/virtual.toml)"
  fi
  if [[ ${#LOCAL_RIGS[@]} -gt 0 ]]; then
    for toml_path in "${LOCAL_RIGS[@]}"; do
      rig_name=$(_toml_rig_name "$toml_path" 2>/dev/null || echo "$toml_path")
      echo -e "  ${BOLD}Native rig :${NC}  ${rig_name} (${toml_path})"
    done
  fi
  echo ""
  echo -e "  ${DIM}Press Ctrl-C to stop everything.${NC}"
  echo ""

  # Brief delay so agents can connect before we start polling
  sleep 1

  # Show rig connectivity right away
  if [[ "$BACKEND" == true ]] && { [[ "$DOCKER_AGENT" == true ]] || [[ ${#LOCAL_RIGS[@]} -gt 0 ]]; }; then
    info "Waiting a moment for agents to connect..."
    sleep 3
    echo ""
    step "Rig connectivity"
    _show_rig_status
    echo ""
  fi

  _git_hash=$(git -C "$SCRIPT_DIR" rev-parse --short HEAD 2>/dev/null || echo "dev")
  (cd "$DASH_DIR" && VITE_API_BASE_URL=http://localhost:8000 VITE_GIT_HASH="$_git_hash" npm run dev -- --host 0.0.0.0)

elif [[ "$BACKEND" == true ]]; then
  echo ""
  echo -e "${BOLD}${GREEN}  Backend running.${NC}"
  echo -e "  ${BOLD}API      :${NC}  http://localhost:8000"
  echo -e "  ${BOLD}API docs :${NC}  http://localhost:8000/docs"
  echo -e "  ${BOLD}MCP SSE  :${NC}  http://localhost:8001/sse"
  echo ""
  echo -e "  ${DIM}Rig status:   ./dev.sh --status${NC}"
  echo -e "  ${DIM}Dashboard:    ./dev.sh --dashboard${NC}"
  echo -e "  ${DIM}Stop:         ./dev.sh --stop${NC}"
  echo ""

  # If native agents were started, wait so we don't exit and kill them
  if [[ ${#NATIVE_AGENT_PIDS[@]} -gt 0 ]]; then
    echo -e "  ${DIM}Native agents running. Press Ctrl-C to stop.${NC}"
    echo ""
    # Wait for any child to exit, then print status
    sleep 3
    step "Rig connectivity"
    _show_rig_status
    echo ""
    wait
  fi
fi
