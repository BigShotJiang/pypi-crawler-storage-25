import re
import json
import ast

def repair_json_string(raw: str) -> str:
    """Пытается починить битый JSON от LLM. Возвращает строку, готовую к json.loads."""
    s = raw.strip()
    # 1. Срезаем markdown-обёртки
    s = re.sub(r'^```(?:json)?\s*', '', s, flags=re.IGNORECASE)
    s = re.sub(r'\s*```$', '', s)

    # 2. Если уже валидный — возвращаем сразу
    try:
        json.loads(s)
        return s
    except json.JSONDecodeError:
        pass

    # 3. Убираем trailing commas перед } или ]
    s = re.sub(r',\s*([}\]])', r'\1', s)

    # 4. Фиксим одинарные кавычки через безопасный парсер Python
    try:
        parsed = ast.literal_eval(s)
        return json.dumps(parsed, ensure_ascii=False)
    except (ValueError, SyntaxError):
        pass

    # 5. Грубый фикс: пропущенные запятые между строками
    s = re.sub(r'"\s*"', '", "', s)
    s = re.sub(r'([}\]])\s*([{"\[])', r'\1, \2', s)

    return s