import json
from jsonschema import validate, ValidationError
from .repair import repair_json_string

def validate_and_fix(json_str: str, schema: dict) -> dict:
    """Принимает сырой ответ LLM, чинит, валидирует по схеме."""
    fixed_str = repair_json_string(json_str)
    
    try:
        data = json.loads(fixed_str)
        validate(instance=data, schema=schema)
        return data
    except json.JSONDecodeError as e:
        raise ValueError(f"❌ Критическая ошибка парсинга: {e}")
    except ValidationError as e:
        raise ValueError(f"❌ Схема не пройдена: {e.message}")

if __name__ == "__main__":
    SCHEMA = {
        "type": "object",
        "properties": {
            "answer": {"type": "string"},
            "confidence": {"type": "number", "minimum": 0, "maximum": 1}
        },
        "required": ["answer", "confidence"]
    }

    # Тест 1: Чистый JSON
    TEST1 = '{"answer": "ОК", "confidence": 0.95}'
    # Тест 2: Markdown + одинарные кавычки + trailing comma (типичный LLM-мусор)
    TEST2 = '```json\n{"answer": \'Починено\', "confidence": 0.87,}\n```'

    for i, t in enumerate([TEST1, TEST2], 1):
        try:
            res = validate_and_fix(t, SCHEMA)
            print(f"✅ Тест {i} пройден: {res}")
        except Exception as err:
            print(f"⛔ Тест {i} провален: {err}")