import os, sys, datetime, base64, platform, hashlib, uuid
try:
    import winreg
except ImportError:
    winreg = None
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

# 🔑 Твой публичный ключ (встроен автоматически)
PUBLIC_KEY_B64 = "O+ztX/zvAftfzunL7iBkNsOSUR39Khp3TFRhzR/8h88="

def _get_machine_id() -> str:
    sys_name = platform.system()
    raw = ""
    if sys_name == "Windows" and winreg:
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
                raw = winreg.QueryValueEx(key, "MachineGuid")[0]
        except Exception:
            raw = str(uuid.getnode())
    elif sys_name == "Darwin":
        import subprocess
        try:
            raw = subprocess.check_output(["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"]).decode().split('"IOPlatformUUID" = "')[1].split('"')[0]
        except Exception:
            raw = platform.node()
    else:
        try:
            raw = open("/etc/machine-id", encoding="utf-8").read().strip()
        except Exception:
            raw = platform.node()
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]

def check_license() -> dict:
    """Проверяет license.dat. Возвращает статус и тариф."""
    mid = _get_machine_id()
    
    candidates = [
        os.path.join(os.getcwd(), "license.dat"),
        os.path.join(os.path.expanduser("~"), ".llm_schema_lock_license.dat")
    ]
    
    for path in candidates:
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = f.read().strip()
            # ИСПРАВЛЕНИЕ: делим только по первому разделителю "|"
            sig_b64, payload = raw.split("|", 1)
            m_id, tier, expiry_str = payload.split("|")
            
            if m_id != mid:
                continue
            
            expiry_date = datetime.datetime.strptime(expiry_str, "%Y-%m-%d")
            if datetime.datetime.now() > expiry_date:
                continue
            
            public_key = Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64))
            public_key.verify(base64.b64decode(sig_b64), payload.encode())
            
            return {"status": "valid", "tier": "pro", "expires": expiry_str, "machine_id": mid}
        except Exception:
            continue
            
    return {"status": "free", "tier": "open", "expires": None, "machine_id": mid}