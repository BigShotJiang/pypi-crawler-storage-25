# Tests for colacloud-cli
