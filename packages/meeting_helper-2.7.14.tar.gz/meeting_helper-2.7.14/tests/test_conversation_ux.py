"""Tests for the round-2 UX changes in ConversationThread / ConversationView.

Covers:
- Merged-turn length cap (no more wall-of-text bubbles).
- Autoscroll follow-state stays armed during content growth (only user-
  initiated scroll-up disarms it).
- scroll_to_bottom debounce: concurrent calls coalesce.
"""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest


def test_merged_turn_capped_at_max_chars():
    """Long monologues split into multiple bubbles instead of one
    growing wall-of-text. A 90-second speaker who'd previously be one
    bubble now becomes 2-3 readable groups."""
    from meeting_helper.flet_gui.components.conversation import ConversationThread

    thread = ConversationThread()

    # First sentence: new turn.
    turn1, extended1 = thread.append_or_extend_transcript("self", "First piece.")
    assert extended1 is False

    # Add sentences until just under the cap. They merge into turn1.
    chunk = "another piece of speech " * 5  # ~120 chars
    for _ in range(2):
        turn, extended = thread.append_or_extend_transcript("self", chunk)
        assert extended is True
        assert turn is turn1

    # Now turn1.text is well past 200 chars. Adding more should still merge
    # while under MAX_MERGED_TURN_CHARS (400).
    if len(turn1.text) < ConversationThread.MAX_MERGED_TURN_CHARS:
        turn, extended = thread.append_or_extend_transcript("self", chunk)
    # Once merged_text exceeds the cap, the next sentence MUST start a
    # fresh turn — even though same speaker, even though within burst window.
    while len(turn1.text) < ConversationThread.MAX_MERGED_TURN_CHARS:
        turn1.text += " filler"
    next_turn, extended = thread.append_or_extend_transcript("self", "Next bubble starts here.")
    assert extended is False
    assert next_turn is not turn1


def test_self_bubble_has_width_cap_via_flex_so_long_text_wraps():
    """SELF turns are right-aligned in a Row with [spacer expand=1, bubble
    expand=4] so the bubble caps at ~80% of the conversation width.

    Without an expand ratio (earlier draft used expand=False) the bubble
    grew to fit its content unbounded, so a long sentence overflowed the
    right edge — visible symptom: text cut off mid-word ("string typ...")
    on the user's screen.
    """
    import flet as ft
    from meeting_helper.flet_gui.components.conversation import (
        ConversationThread, ConversationView, Turn,
    )

    view = ConversationView(ConversationThread())
    long_text = (
        "the method was log event attribute no bank string for no bank string "
        "for target it accept the it don't accept the string types unless they "
        "matched a small whitelist."
    )
    turn = Turn(role="self", text=long_text)

    wrapped, body, _ = view._build_turn(turn)
    # Outer wrapper must be a Row (right-align mechanism).
    assert isinstance(wrapped, ft.Row)
    # Bubble (the second element) must have a flex value > 1 so it has
    # a bounded width — guarantees wrap.
    bubble = wrapped.controls[1]
    assert getattr(bubble, "expand", None) and bubble.expand >= 2, \
        f"SELF bubble must have flex >=2 so text wraps; got expand={getattr(bubble,'expand',None)!r}"


def test_other_speaker_still_starts_fresh_turn():
    """Burst-merge only applies within the same speaker. A different
    speaker always opens a new bubble, regardless of length."""
    from meeting_helper.flet_gui.components.conversation import ConversationThread

    thread = ConversationThread()
    thread.append_or_extend_transcript("self", "Hello")
    other_turn, extended = thread.append_or_extend_transcript("other", "Hi back")
    assert extended is False
    assert other_turn.role == "other"


# ---------------------------------------------------------------------------
# Autoscroll follow-state
# ---------------------------------------------------------------------------

def _make_view():
    from meeting_helper.flet_gui.components.conversation import (
        ConversationThread, ConversationView,
    )
    return ConversationView(ConversationThread())


def test_follow_state_stays_armed_when_content_grows_without_user_scroll():
    """Critical: when AI streaming pushes the bottom past the threshold
    between an autoscroll dispatch and its landing, the follow state must
    NOT flip off. Old behavior was a ping-pong that stranded the user
    mid-chat. New behavior gates on negative scroll_delta (user scroll-up)."""
    view = _make_view()
    view._set_following(True)

    # Simulate an event that COULD look like "user scrolled away" but is
    # really just content growth (no user delta).
    fake_event = SimpleNamespace(
        max_scroll_extent=1000.0,
        pixels=800.0,  # 200 px from bottom — well past the 60 px threshold
        scroll_delta=0,  # NOT user-initiated
    )
    view._handle_scroll(fake_event)
    assert view.is_following() is True


def test_follow_state_disarms_on_user_scroll_up():
    """Real user scroll-up (negative delta) does disarm follow."""
    view = _make_view()
    view._set_following(True)

    fake_event = SimpleNamespace(
        max_scroll_extent=1000.0,
        pixels=200.0,  # well above the bottom
        scroll_delta=-150,  # user scrolled up
    )
    view._handle_scroll(fake_event)
    assert view.is_following() is False


def test_follow_state_rearms_when_user_scrolls_back_to_bottom():
    """When a user scrolls back near the bottom, follow re-arms even
    without an explicit user gesture (passive landing at bottom counts)."""
    view = _make_view()
    view._set_following(False)

    fake_event = SimpleNamespace(
        max_scroll_extent=1000.0,
        pixels=970.0,  # within 60px of bottom
        scroll_delta=0,
    )
    view._handle_scroll(fake_event)
    assert view.is_following() is True


# ---------------------------------------------------------------------------
# scroll_to_bottom debounce
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_scroll_to_bottom_coalesces_concurrent_calls():
    """During chunk-burst + transcript-burst the GUI used to fire 10-20
    scroll_to IPC calls per second. Debounce: only one in flight at a time."""
    view = _make_view()
    # Mock the underlying ListView.scroll_to as an awaitable that
    # records call count.
    view._list = MagicMock()
    call_count = {"n": 0}

    async def fake_scroll_to(**kwargs):
        call_count["n"] += 1
        # Simulate ~one paint frame of latency.
        await asyncio.sleep(0.01)

    view._list.scroll_to = fake_scroll_to

    # Fire 5 concurrent calls — only one should land.
    await asyncio.gather(*[view.scroll_to_bottom() for _ in range(5)])
    assert call_count["n"] == 1
    # After completion, _scroll_pending must be cleared so subsequent
    # calls work.
    assert view._scroll_pending is False
    await view.scroll_to_bottom()
    assert call_count["n"] == 2
