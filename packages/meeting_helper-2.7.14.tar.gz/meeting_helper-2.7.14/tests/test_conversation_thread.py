"""Unit tests for ConversationThread — pure-Python data model."""

import time

from meeting_helper.flet_gui.components.conversation import (
    ConversationThread,
    Turn,
)


def test_append_records_turn():
    t = ConversationThread()
    turn = t.append("you", "hello")
    assert turn.role == "you"
    assert turn.text == "hello"
    assert turn.cards == []
    assert t.turns == [turn]


def test_append_attaches_cards():
    t = ConversationThread()
    cards = [{"id": "ENGT-1", "title": "x"}]
    turn = t.append("ai", "answer", cards=cards)
    assert turn.cards == cards


def test_clear_empties_turns():
    t = ConversationThread()
    t.append("you", "a")
    t.append("ai", "b")
    t.clear()
    assert t.turns == []


def test_max_turns_evicts_oldest():
    t = ConversationThread()
    for i in range(t.MAX_TURNS + 5):
        t.append("self", f"sentence {i}")
    assert len(t.turns) == t.MAX_TURNS
    # oldest (sentence 0..4) should have been evicted
    assert t.turns[0].text == "sentence 5"
    assert t.turns[-1].text == f"sentence {t.MAX_TURNS + 4}"


def test_streaming_chunks_accumulate_into_one_turn():
    t = ConversationThread()
    t.begin_streaming("ai")
    t.append_chunk("Hel")
    t.append_chunk("lo, ")
    t.append_chunk("world")
    t.end_streaming()
    assert len(t.turns) == 1
    assert t.turns[0].role == "ai"
    assert t.turns[0].text == "Hello, world"


def test_streaming_chunk_without_open_turn_opens_ai_turn():
    t = ConversationThread()
    t.append_chunk("orphan")
    assert len(t.turns) == 1
    assert t.turns[0].role == "ai"
    assert t.turns[0].text == "orphan"


def test_end_streaming_attaches_cards_to_in_flight_turn():
    t = ConversationThread()
    t.begin_streaming("ai")
    t.append_chunk("answer")
    cards = [{"id": "ENGT-2", "title": "y"}]
    t.end_streaming(cards=cards)
    assert t.turns[0].cards == cards


def test_multiple_streaming_sessions_produce_separate_turns():
    t = ConversationThread()
    t.begin_streaming("ai")
    t.append_chunk("first")
    t.end_streaming()
    t.begin_streaming("brief")
    t.append_chunk("second")
    t.end_streaming()
    assert len(t.turns) == 2
    assert [(x.role, x.text) for x in t.turns] == [
        ("ai", "first"),
        ("brief", "second"),
    ]


def test_clear_during_streaming_drops_in_flight_turn():
    t = ConversationThread()
    t.begin_streaming("ai")
    t.append_chunk("xyz")
    t.clear()
    assert t.turns == []
    # subsequent chunk opens a fresh ai turn rather than appending to the cleared one
    t.append_chunk("new")
    assert len(t.turns) == 1
    assert t.turns[0].text == "new"


def test_turn_has_timestamp():
    t = ConversationThread()
    turn = t.append("you", "hi")
    assert isinstance(turn.ts, float)
    assert turn.ts > 0


def test_transcript_extends_same_speaker_within_window():
    t = ConversationThread()
    turn1, extended1 = t.append_or_extend_transcript("self", "Hello.")
    assert extended1 is False
    assert len(t.turns) == 1
    turn2, extended2 = t.append_or_extend_transcript("self", "Still talking.")
    assert extended2 is True
    assert turn2 is turn1
    assert len(t.turns) == 1
    assert t.turns[0].text == "Hello. Still talking."


def test_transcript_speaker_change_creates_new_turn():
    t = ConversationThread()
    t.append_or_extend_transcript("self", "I said this.")
    turn, extended = t.append_or_extend_transcript("other", "And then they said this.")
    assert extended is False
    assert len(t.turns) == 2
    assert [(x.role, x.text) for x in t.turns] == [
        ("self", "I said this."),
        ("other", "And then they said this."),
    ]


def test_transcript_old_burst_creates_new_turn():
    t = ConversationThread()
    turn1, _ = t.append_or_extend_transcript("self", "Earlier.")
    # Simulate a long quiet gap by mutating the previous turn's timestamp
    turn1.ts = time.time() - (t.SPEAKER_BURST_WINDOW_SEC + 5)
    turn2, extended = t.append_or_extend_transcript("self", "Picked up again.")
    assert extended is False
    assert turn2 is not turn1
    assert len(t.turns) == 2


def test_transcript_blank_text_is_no_op():
    t = ConversationThread()
    _turn, extended = t.append_or_extend_transcript("self", "   ")
    assert extended is False
    assert t.turns == []


def test_transcript_does_not_extend_across_non_transcript_turn():
    t = ConversationThread()
    t.append_or_extend_transcript("self", "First sentence.")
    t.append("ai", "Some answer.")
    turn, extended = t.append_or_extend_transcript("self", "Follow-up after AI.")
    # Last turn is `ai`, not `self` — so extension shouldn't happen
    assert extended is False
    assert len(t.turns) == 3


# ---------------------------------------------------------------------------
# Time-to-first-token (latency badge) data model
# ---------------------------------------------------------------------------

def test_turn_first_token_ms_defaults_none():
    assert Turn(role="ai", text="").first_token_ms is None


def test_set_streaming_latency_stamps_in_flight_turn():
    t = ConversationThread()
    turn = t.begin_streaming("ai")
    returned = t.set_streaming_latency(420)
    assert returned is turn
    assert turn.first_token_ms == 420


def test_set_streaming_latency_noop_without_open_streaming_turn():
    t = ConversationThread()
    # Nothing streaming yet.
    assert t.set_streaming_latency(100) is None
    # And after the stream has ended.
    t.begin_streaming("ai")
    t.end_streaming()
    assert t.set_streaming_latency(100) is None


def test_format_latency_rendering():
    from meeting_helper.flet_gui.components.conversation import _format_latency
    assert _format_latency(0) == "⚡ 0 ms"
    assert _format_latency(420) == "⚡ 420 ms"
    assert _format_latency(999) == "⚡ 999 ms"
    assert _format_latency(1000) == "⚡ 1.0s"
    assert _format_latency(1840) == "⚡ 1.8s"
