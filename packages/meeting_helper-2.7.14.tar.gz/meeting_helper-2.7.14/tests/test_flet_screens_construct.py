"""Construct every Flet screen against the installed Flet version.

Catches the entire class of "GUI not opening" bugs (kwarg renames, control
removals, signature changes) at test time instead of at the user's first
launch. Each screen is built with a MagicMock page + config; we don't
exercise behavior, only the import + __init__ path.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def fake_page():
    page = MagicMock()
    page.run_thread = MagicMock()
    page.run_task = MagicMock()
    page.update = MagicMock()
    page.open = MagicMock()
    return page


@pytest.fixture
def fake_config():
    cfg = MagicMock()
    cfg.port = 7891
    cfg.local_todo_configured = True
    cfg.provider_configured = True
    cfg.recordings_dir = MagicMock()
    return cfg


def test_copilot_screen_constructs(fake_page, fake_config):
    from meeting_helper.flet_gui.screens.copilot import CopilotScreen

    CopilotScreen(fake_page, fake_config)


def test_copilot_screen_constructs_simple_mode(fake_page):
    """Copilot must construct cleanly when no AI provider or MCP is configured."""
    from meeting_helper.flet_gui.screens.copilot import CopilotScreen
    cfg = MagicMock()
    cfg.port = 7891
    cfg.local_todo_configured = False
    cfg.provider_configured = False
    cfg.recordings_dir = MagicMock()
    screen = CopilotScreen(fake_page, cfg)
    # In simple mode, the AI controls should be hidden after readiness applies
    screen._provider_configured = False
    screen._local_todo_configured = False
    screen._apply_readiness_visibility()
    assert screen._query_input.visible is False
    assert screen._send_btn.visible is False
    assert screen._extract_btn.visible is False
    assert screen._brief_btn.visible is False
    assert screen._tasks_pane.visible is False
    assert screen._right_tab_strip.visible is False


def test_library_screen_constructs(fake_page, fake_config, tmp_path):
    fake_config.recordings_dir = tmp_path
    fake_config.kb_artifacts = []
    fake_config.is_kb = lambda fn: False
    fake_config.is_favorite = lambda fn: False
    from meeting_helper.flet_gui.screens.library import LibraryScreen

    LibraryScreen(fake_page, fake_config)


def test_library_screen_on_workspace_changed_updates_recordings_dir(
    fake_page, fake_config, tmp_path
):
    """LibraryScreen must refresh _recordings_dir when workspace changes."""
    from meeting_helper.flet_gui.screens.library import LibraryScreen

    workspace_a = tmp_path / "ws_a"
    workspace_a.mkdir()
    (workspace_a / "2026-05-01_120000.mp3").write_bytes(b"\x00")

    workspace_b = tmp_path / "ws_b"
    workspace_b.mkdir()
    (workspace_b / "2026-05-08_120000.mp3").write_bytes(b"\x00")
    (workspace_b / "2026-05-09_120000.mp3").write_bytes(b"\x00")

    fake_config.recordings_dir = workspace_a
    fake_config.kb_artifacts = []
    fake_config.is_kb = lambda fn: False
    fake_config.is_favorite = lambda fn: False
    screen = LibraryScreen(fake_page, fake_config)
    screen.did_mount()
    assert len(screen._items) == 1, "should see workspace_a's 1 mp3"

    # Pretend the user switched workspaces — get_config now returns workspace_b.
    new_cfg = MagicMock()
    new_cfg.recordings_dir = workspace_b
    new_cfg.kb_artifacts = []
    new_cfg.is_kb = lambda fn: False
    new_cfg.is_favorite = lambda fn: False
    with patch("meeting_helper.config.get_config", return_value=new_cfg):
        screen.on_workspace_changed()

    assert screen._recordings_dir == workspace_b
    assert len(screen._items) == 2, f"should see workspace_b's 2 mp3s, got {len(screen._items)}"


def test_library_screen_renders_lazily(fake_page, fake_config, tmp_path):
    """A large recordings folder must not materialise every row up front.

    The list paints a bounded first page and streams the rest in on scroll —
    rendering hundreds of rows eagerly is what made the tab slow to open.
    """
    from meeting_helper.flet_gui.screens import library as lib
    from meeting_helper.flet_gui.screens.library import LibraryScreen

    total = lib._INITIAL_ROW_COUNT * 2 + 7
    for i in range(total):
        (tmp_path / f"2026-05-08_{120000 + i:06d}_M.mp3").write_bytes(b"\x00")

    fake_config.recordings_dir = tmp_path
    fake_config.kb_artifacts = []
    fake_config.is_kb = lambda fn: False
    fake_config.is_favorite = lambda fn: False

    screen = LibraryScreen(fake_page, fake_config)
    screen.did_mount()
    assert len(screen._items) == total
    assert len(screen._list_view.controls) == lib._INITIAL_ROW_COUNT
    assert screen._rendered_count == lib._INITIAL_ROW_COUNT

    # Scrolling near the bottom appends the next batch.
    evt = MagicMock(pixels=10_000.0, max_scroll_extent=10_050.0)
    screen._on_list_scroll(evt)
    assert screen._rendered_count == lib._INITIAL_ROW_COUNT + lib._ROW_BATCH

    # Keep scrolling until the list is fully rendered, then it stops growing.
    for _ in range(5):
        screen._on_list_scroll(evt)
    assert screen._rendered_count == total
    assert len(screen._list_view.controls) == total

    # A second did_mount with an unchanged folder must not rebuild anything.
    rows_before = list(screen._list_view.controls)
    screen.did_mount()
    assert screen._list_view.controls == rows_before
    assert screen._rendered_count == total


def test_settings_screen_constructs(fake_page, fake_config):
    from meeting_helper.flet_gui.screens.settings import SettingsScreen

    SettingsScreen(fake_page, fake_config)


def test_workspace_screen_constructs(fake_page, fake_config):
    from meeting_helper.flet_gui.screens.workspace import WorkspaceScreen

    WorkspaceScreen(fake_page, fake_config)
