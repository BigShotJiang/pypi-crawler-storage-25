"""CLI package for augint-opencodex."""
