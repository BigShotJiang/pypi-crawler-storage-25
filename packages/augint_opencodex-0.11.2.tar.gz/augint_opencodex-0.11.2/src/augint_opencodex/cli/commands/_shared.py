from __future__ import annotations

from pathlib import Path

import click

from augint_opencodex.connectivity import (
    DEFAULT_OLLAMA_API_URL,
    DEFAULT_OPENAI_COMPAT_URL,
    check_local_provider,
)
from augint_opencodex.sync_engine import ProjectReport


def display_path(path: Path | None, base: Path | None = None) -> str:
    if path is None:
        return "<missing>"
    if base is None:
        return path.as_posix()
    try:
        return path.relative_to(base).as_posix()
    except ValueError:
        return path.as_posix()


def warn_if_local_llm_unreachable(report: ProjectReport) -> None:
    local_provider = report.policy.opencode_local_provider
    if local_provider is None:
        return

    result = check_local_provider(local_provider.base_url)
    if not result.reachable:
        click.echo(
            f"Warning: local LLM at {result.checked_url} is not reachable"
            + (f" ({result.error})" if result.error else "")
            + "."
        )
        click.echo(f"  Ollama API:         {DEFAULT_OLLAMA_API_URL}")
        click.echo(f"  OpenAI-compatible:  {DEFAULT_OPENAI_COMPAT_URL}")
        click.echo("  Start the server:   ollama serve")
