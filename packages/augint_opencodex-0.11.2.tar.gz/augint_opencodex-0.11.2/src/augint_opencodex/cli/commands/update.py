from __future__ import annotations

from pathlib import Path
from typing import Literal

import click

from augint_opencodex.constants import DEFAULT_MANIFEST_FILE
from augint_opencodex.sync_engine import ProjectReport, update_project

from ._shared import display_path, warn_if_local_llm_unreachable


@click.command(name="update")
@click.option(
    "--project-root",
    type=click.Path(file_okay=False, path_type=Path),
    default=Path("."),
    show_default=True,
    help="Repository root to update.",
)
@click.option(
    "--manifest",
    type=click.Path(dir_okay=False, path_type=Path),
    help="Explicit manifest path. Defaults to PROJECT_ROOT/.ai-opencodex.json.",
)
@click.option("--dry-run", is_flag=True, help="Preview changes without writing files.")
@click.option("--check", is_flag=True, help="Exit non-zero when managed files are out of date.")
def update_command(
    project_root: Path,
    manifest: Path | None,
    dry_run: bool,
    check: bool,
) -> None:
    """Merge rendered project files into the repository."""

    if dry_run and check:
        raise click.ClickException("`--dry-run` and `--check` cannot be used together.")

    mode: Literal["write", "dry-run", "check"] = (
        "check" if check else "dry-run" if dry_run else "write"
    )
    manifest_path = (manifest or (project_root / DEFAULT_MANIFEST_FILE)).resolve()
    if not manifest_path.exists():
        raise click.ClickException(
            f"Manifest not found: {manifest_path}. Run `ai-opencodex init` to initialize it."
        )

    report = update_project(project_root, manifest_path=manifest_path, mode=mode)
    _print_report(report)
    warn_if_local_llm_unreachable(report)

    if check and report.needs_changes:
        raise click.ClickException("Managed files are out of date. Run `ai-opencodex update`.")


def _print_report(report: ProjectReport) -> None:
    root = report.policy.project_root
    click.echo(f"Project root: {root}")
    click.echo(f"Manifest: {report.policy.manifest_path}")
    click.echo(f"Profile: {report.policy.profile_name}")

    if report.changed_files:
        verb = {
            "write": "wrote",
            "dry-run": "would write",
            "check": "needs update",
        }[report.mode]
        for path in report.changed_files:
            click.echo(f"{verb}: {display_path(path)}")
    else:
        click.echo("Managed files are already up to date.")

    if report.stale_files:
        verb = {
            "write": "removed",
            "dry-run": "would remove",
            "check": "needs removal",
        }[report.mode]
        for path in report.stale_files:
            click.echo(f"{verb}: {display_path(path)}")

    if report.unchanged_files:
        click.echo(f"unchanged: {len(report.unchanged_files)} file(s)")

    exclude_update = report.exclude_update
    if not exclude_update.available:
        click.echo("git exclude: skipped (no .git/info directory found)")
    elif exclude_update.updated:
        click.echo(f"git exclude: updated {display_path(exclude_update.path, root)}")
    elif exclude_update.needs_update:
        click.echo(f"git exclude: would update {display_path(exclude_update.path, root)}")
    else:
        click.echo("git exclude: already current")
