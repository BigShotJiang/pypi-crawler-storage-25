from __future__ import annotations

from pathlib import Path
from typing import Literal

import click

from augint_opencodex.constants import DEFAULT_MANIFEST_FILE, SCHEMA_URL
from augint_opencodex.profiles import PROFILE_DEFINITIONS
from augint_opencodex.sync_engine import ProjectReport, init_project
from augint_opencodex.template_loader import render_template

from ._shared import display_path, warn_if_local_llm_unreachable

_PROFILE_CHOICES = sorted(PROFILE_DEFINITIONS)
_DEFAULT_PROFILE = "augint"


@click.command(name="init")
@click.option(
    "--project-root",
    type=click.Path(file_okay=False, path_type=Path),
    default=Path("."),
    show_default=True,
    help="Repository root to initialize.",
)
@click.option(
    "--manifest",
    type=click.Path(dir_okay=False, path_type=Path),
    help="Explicit manifest path. Defaults to PROJECT_ROOT/.ai-opencodex.json.",
)
@click.option("--dry-run", is_flag=True, help="Preview missing files without writing them.")
@click.option(
    "--profile",
    type=click.Choice(_PROFILE_CHOICES),
    help="Profile to use when creating a missing manifest. Skips the interactive prompt.",
)
def init_command(
    project_root: Path,
    manifest: Path | None,
    dry_run: bool,
    profile: str | None,
) -> None:
    """Create a manifest and any missing managed files."""

    mode: Literal["write", "dry-run"] = "dry-run" if dry_run else "write"
    manifest_path = _ensure_manifest(project_root, manifest, mode=mode, profile=profile)

    report = init_project(project_root, manifest_path=manifest_path, mode=mode)
    _print_report(report)
    warn_if_local_llm_unreachable(report)


def _ensure_manifest(
    project_root: Path,
    manifest: Path | None,
    *,
    mode: Literal["write", "dry-run"],
    profile: str | None,
) -> Path:
    manifest_path = (manifest or (project_root / DEFAULT_MANIFEST_FILE)).resolve()
    if manifest_path.exists():
        click.echo(f"warning: manifest already exists, skipping create: {manifest_path}")
        return manifest_path

    chosen_profile = profile or _prompt_for_profile(manifest_path)
    manifest_text = render_template(
        "manifest.json.tpl",
        schema_uri=SCHEMA_URL,
        profile=chosen_profile,
    )

    if mode == "dry-run":
        click.echo(f"would create manifest: {manifest_path} (profile: {chosen_profile})")
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(manifest_text, encoding="utf-8")

        def _cleanup_manifest() -> None:
            if manifest_path.exists():
                manifest_path.unlink()

        click.get_current_context().call_on_close(_cleanup_manifest)
        return manifest_path

    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(manifest_text, encoding="utf-8")
    click.echo(f"created manifest: {manifest_path} (profile: {chosen_profile})")
    return manifest_path


def _prompt_for_profile(manifest_path: Path) -> str:
    click.echo(f"No manifest found at {manifest_path}.")
    click.echo(f"Creating a new `{DEFAULT_MANIFEST_FILE.as_posix()}` for this repository.")
    try:
        answer: str = click.prompt(
            "Profile",
            type=click.Choice(_PROFILE_CHOICES),
            default=_DEFAULT_PROFILE,
            show_choices=True,
        )
        return answer
    except click.Abort as exc:
        raise click.ClickException(
            f"Manifest not found: {manifest_path}. "
            "Pass `--profile augint|gov` to create one non-interactively."
        ) from exc


def _print_report(report: ProjectReport) -> None:
    root = report.policy.project_root
    click.echo(f"Project root: {root}")
    click.echo(f"Manifest: {report.policy.manifest_path}")
    click.echo(f"Profile: {report.policy.profile_name}")

    for path in report.changed_files:
        verb = "would create" if report.mode == "dry-run" else "created"
        click.echo(f"{verb}: {display_path(path)}")

    for path in report.skipped_files:
        click.echo(f"warning: exists, skipped: {display_path(path)}")

    if not report.changed_files:
        click.echo("No missing managed files needed creation.")

    exclude_update = report.exclude_update
    if not exclude_update.available:
        click.echo("git exclude: skipped (no .git/info directory found)")
    elif exclude_update.updated:
        click.echo(f"git exclude: updated {display_path(exclude_update.path, root)}")
    elif exclude_update.needs_update:
        click.echo(f"git exclude: would update {display_path(exclude_update.path, root)}")
    else:
        click.echo("git exclude: already current")
