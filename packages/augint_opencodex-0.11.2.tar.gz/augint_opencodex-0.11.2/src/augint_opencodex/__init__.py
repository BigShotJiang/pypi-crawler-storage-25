"""augint-opencodex package."""

__version__ = "0.11.2"
