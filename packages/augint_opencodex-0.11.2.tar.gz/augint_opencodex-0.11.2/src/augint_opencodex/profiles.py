from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

from augint_opencodex.manifest import LocalProvider, Manifest, ModelEntry, PiModelEntry


@dataclass(frozen=True)
class ProfileDefinition:
    """Resolved defaults for a named profile before manifest overrides."""

    name: str
    summary: str
    instruction_bullets: tuple[str, ...]
    blocked_paths: tuple[str, ...]
    ask_patterns: tuple[str, ...]
    deny_patterns: tuple[str, ...]
    approval_policy: str = "on-request"
    sandbox_mode: str = "workspace-write"
    web_search: str = "live"


@dataclass(frozen=True)
class ResolvedPolicy:
    """Effective policy after layering baseline, profile, and manifest settings."""

    project_root: Path
    manifest_path: Path
    profile_name: str
    profile_summary: str
    references: tuple[str, ...]
    blocked_paths: tuple[str, ...]
    ask_patterns: tuple[str, ...]
    deny_patterns: tuple[str, ...]
    no_emojis: bool
    no_ai_mentions: bool
    org_python_library: bool
    opencode_enabled: bool
    opencode_default_model: str | None
    opencode_small_model: str | None
    opencode_local_provider: LocalProvider | None
    opencode_models: tuple[ModelEntry, ...]
    opencode_bedrock_enabled: bool
    opencode_bedrock_models: tuple[str, ...]
    opencode_extras: tuple[str, ...]
    codex_provider: str
    codex_model: str | None
    codex_approval_policy: str
    codex_sandbox_mode: str
    codex_web_search: str
    pi_enabled: bool
    pi_default_model: str | None
    pi_models: tuple[PiModelEntry, ...]
    pi_thinking: bool
    pi_telemetry: bool
    pi_extensions: tuple[str, ...]
    instruction_bullets: tuple[str, ...]


BASELINE_INSTRUCTION_BULLETS = (
    "Use `.ai-opencodex.json` as the tracked source of truth for local agent configuration.",
    "Use `.ai-opencodex.md` as the generated repo instruction file.",
    "Avoid a root `AGENTS.md` in the repository root because it shadows fallback instruction filenames for Codex discovery.",
    "Treat `.codex/config.toml`, `opencode.json`, `.pi/`, and `.agents/skills/` as generated local artifacts.",
    "Re-run `ai-opencodex update` after manifest changes instead of editing generated files by hand.",
    "Pi, Codex, and OpenCode all read AGENTS.md natively; `.ai-opencodex.md` is the unified instruction source.",
)


PROFILE_DEFINITIONS: dict[str, ProfileDefinition] = {
    "augint": ProfileDefinition(
        name="augint",
        summary="Standard Augmenting Integrations work profile with live web access and local agent guidance.",
        instruction_bullets=(
            "Prefer practical, minimal changes that preserve the existing repository's patterns.",
            "Treat shell guardrails as real approval prompts for risky operational commands.",
        ),
        blocked_paths=(
            "**/secrets/**",
            "**/*.pem",
            "**/terraform.tfstate*",
        ),
        ask_patterns=(
            "aws *",
            "terraform *",
            "kubectl *",
            "git push *",
        ),
        deny_patterns=(),
    ),
    "gov": ProfileDefinition(
        name="gov",
        summary="Stricter overlay for compliance-sensitive repositories with broader defaults and more conservative command handling.",
        instruction_bullets=(
            "Use the same working model as `augint`, but be more conservative with compliance-sensitive changes.",
            "Escalate or slow down when commands or outputs could affect regulated systems or sensitive data.",
        ),
        blocked_paths=(
            "**/secrets/**",
            "**/*.pem",
            "**/*.key",
            "**/*.p12",
            "**/terraform.tfstate*",
            "**/.aws/**",
        ),
        ask_patterns=(
            "aws *",
            "terraform *",
            "kubectl *",
            "git push *",
            "az *",
            "gcloud *",
            "gh secret *",
        ),
        deny_patterns=(
            "aws iam create*",
            "aws iam put*",
            "terraform destroy *",
        ),
    ),
}


def resolve_policy(manifest: Manifest, project_root: Path, manifest_path: Path) -> ResolvedPolicy:
    """Merge baseline policy, profile defaults, and manifest settings."""

    profile = PROFILE_DEFINITIONS[manifest.profile]
    codex = manifest.codex
    opencode = manifest.opencode
    pi = manifest.pi
    return ResolvedPolicy(
        project_root=project_root.resolve(),
        manifest_path=manifest_path.resolve(),
        profile_name=profile.name,
        profile_summary=profile.summary,
        references=_dedupe(manifest.references),
        blocked_paths=_dedupe(profile.blocked_paths + tuple(manifest.blocked_paths)),
        ask_patterns=_dedupe(profile.ask_patterns + tuple(manifest.shell_guardrails.ask)),
        deny_patterns=_dedupe(profile.deny_patterns + tuple(manifest.shell_guardrails.deny)),
        no_emojis=manifest.content_policy.no_emojis,
        no_ai_mentions=manifest.content_policy.no_ai_mentions,
        org_python_library=manifest.patterns.org_python_library,
        opencode_enabled=opencode.enabled,
        opencode_default_model=opencode.default_model,
        opencode_small_model=opencode.small_model,
        opencode_local_provider=opencode.local_provider,
        opencode_models=tuple(opencode.models),
        opencode_bedrock_enabled=opencode.bedrock.enabled,
        opencode_bedrock_models=tuple(opencode.bedrock.models),
        opencode_extras=_dedupe(opencode.extras),
        codex_provider=codex.provider,
        codex_model=codex.model,
        codex_approval_policy=codex.approval_policy or profile.approval_policy,
        codex_sandbox_mode=codex.sandbox_mode or profile.sandbox_mode,
        codex_web_search=codex.web_search or profile.web_search,
        pi_enabled=pi.enabled,
        pi_default_model=pi.default_model,
        pi_models=tuple(pi.models),
        pi_thinking=pi.thinking,
        pi_telemetry=pi.telemetry,
        pi_extensions=tuple(pi.extensions),
        instruction_bullets=BASELINE_INSTRUCTION_BULLETS + profile.instruction_bullets,
    )


def _dedupe(values: Sequence[str]) -> tuple[str, ...]:
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        if value not in seen:
            ordered.append(value)
            seen.add(value)
    return tuple(ordered)
