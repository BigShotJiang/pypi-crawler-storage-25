---
name: augint-workflow
description: Use this skill when working in an Augmenting Integrations repository managed by ai-opencodex.
metadata:
  short-description: Augint workflow conventions for pi coding agent
---

# Augint Workflow

Use this skill when working in a repository managed by ai-opencodex.

## Conventions

- Use `.ai-opencodex.json` as the tracked source of truth for local agent configuration.
- Use `.ai-opencodex.md` as the generated repo-local instructions file (read it first).
- Treat `.codex/config.toml`, `opencode.json`, `.pi/`, and `.agents/skills/` as generated artifacts.
- Re-run `ai-opencodex update` after manifest changes instead of editing generated files.
- Follow Conventional Commit discipline and semantic-release-compatible versioning.
- Prefer practical, minimal changes that preserve the existing repository patterns.
