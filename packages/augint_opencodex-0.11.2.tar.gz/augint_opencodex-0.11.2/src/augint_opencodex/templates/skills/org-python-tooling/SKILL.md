---
name: org-python-tooling
description: Use this skill when working in a repository that follows the organizational Python library or tool standard.
metadata:
  short-description: Organizational Python tooling standard
---

# Org Python Tooling Standard

Use this skill when working in a repository that follows the organizational Python library or tool standard.

## Standard

- Use `uv` for dependency management, locking, testing, and builds.
- Keep a `src/` package layout and expose entry points through `[project.scripts]`.
- Preserve `ruff`, `mypy`, `pytest`, coverage thresholds, and `pre-commit`.
- Maintain Conventional Commit discipline and semantic-release-compatible versioning.
- Keep security and compliance checks in CI, including dependency and license scanning.
- Prefer a stable Makefile task surface over ad hoc project-specific commands.
