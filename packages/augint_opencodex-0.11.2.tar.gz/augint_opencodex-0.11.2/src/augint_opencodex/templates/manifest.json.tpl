{
  "$$schema": "$schema_uri",
  "version": 1,
  "profile": "$profile",
  "references": [],
  "blocked_paths": [],
  "content_policy": {
    "no_emojis": true,
    "no_ai_mentions": true
  },
  "shell_guardrails": {
    "ask": [],
    "deny": []
  },
  "patterns": {
    "org_python_library": false
  },
  "opencode": {
    "enabled": true,
    "default_model": null,
    "local_provider": {
      "kind": "openai-compatible",
      "name": "ollama",
      "base_url": "http://host.docker.internal:11434/v1"
    },
    "models": [],
    "bedrock": {
      "enabled": false,
      "models": []
    }
  },
  "codex": {
    "provider": "openai",
    "model": null,
    "approval_policy": null,
    "sandbox_mode": null,
    "web_search": null
  }
}
