"""Template assets for generated project files."""
