from __future__ import annotations

from pathlib import Path
from string import Template

_TEMPLATE_ROOT = Path(__file__).resolve().parent / "templates"


def load_template(relative_path: str) -> str:
    """Load a text template bundled with the package."""

    return (_TEMPLATE_ROOT / relative_path).read_text(encoding="utf-8")


def render_template(relative_path: str, /, **context: str) -> str:
    """Render a bundled text template with string substitutions."""

    return Template(load_template(relative_path)).safe_substitute(context)
