import numpy as np

from .._core.validate import ensure_mask, ensure_ndarray


def is_mask(mask: object) -> bool:
    try:
        to_mask(mask)
    except (TypeError, ValueError):
        return False

    return True


def to_mask(mask: object) -> np.ndarray:
    mask = ensure_mask(mask, name="Mask input")

    if mask.dtype == np.bool_:
        return mask.astype(np.uint8)

    unique_values = set(np.unique(mask).tolist())
    if unique_values <= {0, 1}:
        return mask.astype(np.uint8)

    if unique_values <= {0, 255}:
        return (mask > 0).astype(np.uint8)

    raise ValueError(
        "Mask input must contain only binary values represented as "
        "bool, {0, 1}, or {0, 255}.",
    )


def get_coords(
    mask: np.ndarray,
    transpose: bool = False,
) -> np.ndarray:
    mask = to_mask(mask)
    coords = np.argwhere(mask > 0)

    if transpose:
        return coords.T

    return coords


def get_box_from_coords(
    coords: np.ndarray,
) -> tuple[int, int, int, int] | None:
    coords = ensure_ndarray(coords, name="coords")

    if coords.size == 0:
        return None

    if coords.ndim != 2:
        raise ValueError("coords must have shape (N, 2) or (2, N).")

    if coords.shape[1] == 2:
        h_coords = coords[:, 0]
        w_coords = coords[:, 1]
    elif coords.shape[0] == 2:
        h_coords = coords[0, :]
        w_coords = coords[1, :]
    else:
        raise ValueError("coords must have shape (N, 2) or (2, N).")

    hmin = int(np.min(h_coords))
    hmax = int(np.max(h_coords)) + 1
    wmin = int(np.min(w_coords))
    wmax = int(np.max(w_coords)) + 1
    return (wmin, hmin, wmax, hmax)


def get_box_from_mask(
    mask: np.ndarray,
) -> tuple[int, int, int, int] | None:
    mask = to_mask(mask)
    return get_box_from_coords(get_coords(mask))


def to_roi_box(
    mask: np.ndarray,
) -> dict[str, object] | None:
    mask = to_mask(mask)
    bbox = get_box_from_mask(mask)
    if bbox is None:
        return None

    wmin, hmin, wmax, hmax = bbox
    roi = mask[hmin:hmax, wmin:wmax].copy()
    return {"roi": roi, "box": bbox}


def get_roi_size(mask: np.ndarray) -> int:
    mask = to_mask(mask)
    return int(np.count_nonzero(mask))


def get_box_size(bbox: tuple[int, int, int, int] | None) -> int:
    if bbox is None:
        return 0

    wmin, hmin, wmax, hmax = bbox
    if wmin >= wmax or hmin >= hmax:
        raise ValueError("bbox must satisfy wmin < wmax and hmin < hmax.")
    return (wmax - wmin) * (hmax - hmin)


def get_centroid(
    mask: np.ndarray,
) -> tuple[float, float] | None:
    mask = to_mask(mask)
    coords = get_coords(mask)

    if coords.shape[0] == 0:
        return None

    center_h = float(np.mean(coords[:, 0]))
    center_w = float(np.mean(coords[:, 1]))
    return (center_h, center_w)
