from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_keycloak.audit.logger import KcAuditLogger
from mcp_eregistrations_keycloak.keycloak_client import KeycloakAdminClient

ROLLBACK_ENDPOINTS: dict[str, tuple[str | None, str | None, str | None]] = {
    # (delete_endpoint, update_endpoint, create_endpoint)
    "realm": (
        "/realms/{realm}",
        "/realms/{realm}",
        "/realms",
    ),
    "user": (
        "/realms/{realm}/users/{id}",
        "/realms/{realm}/users/{id}",
        "/realms/{realm}/users",
    ),
    "role": (
        "/realms/{realm}/roles/{name}",
        "/realms/{realm}/roles/{name}",
        "/realms/{realm}/roles",
    ),
    "theme": (
        None,
        "/realms/{realm}",
        None,
    ),
    "user_profile": (
        None,
        "/realms/{realm}/users/profile",
        None,
    ),
    "client_mapper": (
        "/realms/{realm}/clients/{client_id}/protocol-mappers/models/{id}",
        None,
        "/realms/{realm}/clients/{client_id}/protocol-mappers/models",
    ),
}


async def execute_rollback(
    client: KeycloakAdminClient,
    audit_logger: KcAuditLogger,
    audit_id: str,
) -> dict[str, Any]:
    """Execute a rollback for a given audit entry."""
    entries = await audit_logger.list_entries(limit=1000)
    entry = next((e for e in entries if e["id"] == audit_id), None)
    if not entry:
        raise ToolError(f"Audit entry '{audit_id}' not found.")

    if entry["status"] != "success":
        raise ToolError(
            f"Cannot rollback entry with status '{entry['status']}'. "
            f"Only 'success' entries can be rolled back."
        )
    if entry.get("rolled_back_at"):
        raise ToolError(f"Entry '{audit_id}' has already been rolled back.")

    state = await audit_logger.get_rollback_state(audit_id)
    if not state:
        raise ToolError(
            f"No rollback state found for entry '{audit_id}'. "
            f"This operation did not capture previous state."
        )

    object_type = entry["object_type"]
    operation = entry["operation_type"]
    previous = state["previous_state"]
    params = entry.get("params", {})

    endpoints = ROLLBACK_ENDPOINTS.get(object_type)
    if not endpoints:
        raise ToolError(f"Rollback not supported for object type '{object_type}'.")

    delete_ep, update_ep, create_ep = endpoints

    if operation == "create" and delete_ep:
        # Reverse a create → delete
        object_id = state.get("object_id") or params.get("id")
        path = delete_ep.format(**{**params, "id": object_id})
        await client.delete(path)
    elif operation == "update" and update_ep:
        # Reverse an update → PUT previous state
        path = update_ep.format(**params)
        await client.put(path, data=previous)
    elif operation == "delete" and create_ep:
        # Reverse a delete → POST to recreate
        path = create_ep.format(**params)
        await client.post(path, data=previous)
    else:
        raise ToolError(
            f"Cannot rollback '{operation}' on '{object_type}': no endpoint configured."
        )

    await audit_logger.mark_rolled_back(audit_id)
    return {
        "audit_id": audit_id,
        "operation": operation,
        "object_type": object_type,
        "status": "rolled_back",
    }
