from typing import Dict, Type

from guardianhub.models.base import SovereignModel

MODEL_REGISTRY: Dict[str, Type[SovereignModel]] = {}

def register_model(model: Type[SovereignModel]):
    """
    Register a Pydantic model so it can be dynamically loaded across microservices.
    """
    MODEL_REGISTRY[model.__name__] = model
    return model

def get_model(name: str) -> Type[SovereignModel]:
    try:
        return MODEL_REGISTRY[name]
    except KeyError:
        raise ValueError(f"Model '{name}' not found in registry")
