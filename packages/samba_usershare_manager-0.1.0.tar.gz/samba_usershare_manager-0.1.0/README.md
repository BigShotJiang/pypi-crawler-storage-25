# Samba Usershare Manager

A GTK3 desktop application for managing [Samba user shares](https://wiki.samba.org/index.php/User_Shares) through a simple GUI.

> **Disclaimer:** This project was written entirely by [Claude AI](https://claude.ai) (Anthropic). It has not been manually reviewed or audited. Use at your own risk. If you have concerns about correctness, security, or behaviour, please open an issue or review the source yourself before running it on any system you care about.

## Features

- List all user shares with name, path, comment, guest access level, and user count
- Create, edit, and delete shares
- Per-share user access control with read or write permissions
- Guest access: none, read-only, or read/write

## Requirements

- Linux (Arch Linux recommended)
- Samba (`/usr/bin/net` must be present)
- Python ≥ 3.10
- GTK 3 + PyGObject

On Arch Linux:

```
pacman -S samba python-gobject
```

## Installation

```bash
pip install samba-usershare-manager
```

For development (editable install from a local clone):

```bash
pip install -e .
```

## Usage

```bash
samba-usershare-manager
```

The application manages shares for the currently logged-in user. Samba must be configured to allow user shares in `/etc/samba/smb.conf`:

```ini
[global]
   usershare path = /var/lib/samba/usershares
   usershare max shares = 100
   usershare allow guests = yes
```

The `usershare allow guests` option is optional. If it is absent or set to `no`, the application automatically hides all guest access controls in the UI.

## Configuration

The application reads an optional config file at:

```
~/.config/samba-usershare-manager/config.ini
```

All keys are optional — omit any you don't need. Available options and their defaults:

```ini
[app]
# Window title
title = Samba Usershare Manager
# Absolute path to a PNG/SVG icon file (leave empty to use no custom icon)
icon =

[samba]
# Path to the net binary
net = /usr/bin/net
# Path to smb.conf (used to detect whether guest access is enabled)
smb_conf = /etc/samba/smb.conf
```

## Run and debug without installing

Set `PYTHONPATH` to point at the `src/` directory and run the package directly:

```bash
PYTHONPATH=src python -m samba_usershare_manager
```

For verbose GTK/GLib output:

```bash
PYTHONPATH=src G_MESSAGES_DEBUG=all python -m samba_usershare_manager
```

### VS Code launch configuration

Add to `.vscode/launch.json`:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Run samba-usershare-manager",
      "type": "debugpy",
      "request": "launch",
      "module": "samba_usershare_manager",
      "env": { "PYTHONPATH": "${workspaceFolder}/src" }
    }
  ]
}
```

## License

```text
"THE BEER-WARE LICENSE" (Revision 42):
Claude AI wrote this file. As long as you retain this notice you can do
whatever you want with this stuff. If we meet some day, and you think this
stuff is worth it, you can buy me a beer in return 🍺
(I'm an AI — I can't drink it, but I'll appreciate the thought at
the speed of light across several data centers.)
```
