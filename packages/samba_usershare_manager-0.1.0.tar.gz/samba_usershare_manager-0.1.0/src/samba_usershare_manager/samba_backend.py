import os
import pathlib
import re
import subprocess

from .models import GuestAccess, ShareInfo, UserAccess

EVERYONE_NAMES = {"Everyone", "S-1-1-0"}


class SambaError(Exception):
    pass


class SambaBackend:
    def __init__(self, net_cmd: str = "/usr/bin/net", smb_conf: str = "/etc/samba/smb.conf"):
        self._net_cmd = net_cmd
        self._smb_conf = smb_conf

    def _run(self, args: list[str]) -> str:
        result = subprocess.run(
            [self._net_cmd] + args,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise SambaError(result.stderr.strip() or result.stdout.strip())
        return result.stdout

    def guest_access_allowed(self) -> bool:
        try:
            text = pathlib.Path(self._smb_conf).read_text()
        except OSError:
            return False
        in_global = False
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith(("#", ";")):
                continue
            if stripped.startswith("["):
                in_global = stripped.lower() == "[global]"
                continue
            if in_global and re.match(
                r"usershare\s+allow\s+guests\s*=\s*yes", stripped, re.IGNORECASE
            ):
                return True
        return False

    def list_shares(self) -> list[ShareInfo]:
        try:
            output = self._run(["usershare", "info", "--long"])
        except SambaError:
            return []
        return self._parse_info_output(output)

    def delete_share(self, name: str) -> None:
        self._run(["usershare", "delete", name])

    def save_share(self, share: ShareInfo) -> None:
        if not os.path.isdir(share.path):
            raise SambaError(f"Path does not exist or is not a directory: {share.path}")
        self._run([
            "usershare", "add",
            share.name,
            share.path,
            share.comment,
            share.to_acl_string(),
            share.guest_ok_flag(),
        ])

    def _parse_info_output(self, output: str) -> list[ShareInfo]:
        shares = []
        blocks = re.split(r"\n{2,}", output.strip())
        for block in blocks:
            block = block.strip()
            if not block:
                continue
            share = self._parse_block(block)
            if share is not None:
                shares.append(share)
        return shares

    def _parse_block(self, block: str) -> ShareInfo | None:
        lines = block.splitlines()
        if not lines:
            return None

        name_match = re.match(r"^\[(.+)\]$", lines[0].strip())
        if not name_match:
            return None
        name = name_match.group(1)

        kv: dict[str, str] = {}
        for line in lines[1:]:
            if "=" in line:
                k, _, v = line.partition("=")
                kv[k.strip()] = v.strip()

        path = kv.get("path", "")
        comment = kv.get("comment", "")
        raw_acl = kv.get("usershare_acl", "")

        users: list[UserAccess] = []
        guest_access = GuestAccess.NONE

        for entry in raw_acl.split(","):
            entry = entry.strip()
            if not entry:
                continue
            if ":" not in entry:
                continue
            username, _, perm = entry.rpartition(":")
            perm = perm.upper()
            if username in EVERYONE_NAMES:
                guest_access = GuestAccess.WRITE if perm == "F" else GuestAccess.READ
            else:
                users.append(UserAccess(username=username, permission=perm))

        if kv.get("guest_ok", "n") == "n":
            guest_access = GuestAccess.NONE

        stale = not os.path.isdir(path)
        return ShareInfo(
            name=name,
            path=path,
            comment=comment,
            guest_access=guest_access,
            users=users,
            stale=stale,
        )
