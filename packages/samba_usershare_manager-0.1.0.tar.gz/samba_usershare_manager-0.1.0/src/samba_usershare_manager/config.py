import configparser
import os
import pathlib

_CONFIG_DIR = pathlib.Path(
    os.environ.get("XDG_CONFIG_HOME", pathlib.Path.home() / ".config")
) / "samba-usershare-manager"

CONFIG_PATH = _CONFIG_DIR / "config.ini"

_DEFAULTS: dict[str, dict[str, str]] = {
    "app": {
        "title": "Samba Usershare Manager",
        "icon": "",
    },
    "samba": {
        "net": "/usr/bin/net",
        "smb_conf": "/etc/samba/smb.conf",
    },
}


class AppConfig:
    def __init__(self):
        self._cp = configparser.ConfigParser()
        for section, values in _DEFAULTS.items():
            self._cp[section] = values
        self._cp.read(CONFIG_PATH)

    @property
    def title(self) -> str:
        return self._cp.get("app", "title")

    @property
    def icon(self) -> str:
        return self._cp.get("app", "icon")

    @property
    def net_cmd(self) -> str:
        return self._cp.get("samba", "net")

    @property
    def smb_conf(self) -> str:
        return self._cp.get("samba", "smb_conf")
