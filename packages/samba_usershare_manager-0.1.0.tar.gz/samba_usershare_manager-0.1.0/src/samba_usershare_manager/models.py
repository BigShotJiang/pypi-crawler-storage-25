import enum
from dataclasses import dataclass, field


class GuestAccess(enum.Enum):
    NONE = "none"
    READ = "read"
    WRITE = "write"


@dataclass
class UserAccess:
    username: str
    permission: str  # "R" or "F"


@dataclass
class ShareInfo:
    name: str
    path: str
    comment: str
    guest_access: GuestAccess
    users: list[UserAccess] = field(default_factory=list)
    stale: bool = False

    @property
    def user_count(self) -> int:
        return len(self.users)

    def to_acl_string(self) -> str:
        parts = []
        if self.guest_access == GuestAccess.READ:
            parts.append("Everyone:R")
        elif self.guest_access == GuestAccess.WRITE:
            parts.append("Everyone:F")
        parts.extend(f"{u.username}:{u.permission}" for u in self.users)
        return ",".join(parts)

    def guest_ok_flag(self) -> str:
        return "guest_ok=y" if self.guest_access != GuestAccess.NONE else "guest_ok=n"
