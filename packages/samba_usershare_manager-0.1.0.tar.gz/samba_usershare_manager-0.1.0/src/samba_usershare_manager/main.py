import sys

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

from .config import AppConfig
from .samba_backend import SambaBackend
from .main_window import MainWindow


class Application(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="org.example.SambaUsershareManager")
        self._config = AppConfig()
        self._backend = SambaBackend(
            net_cmd=self._config.net_cmd,
            smb_conf=self._config.smb_conf,
        )

    def do_activate(self):
        guest_allowed = self._backend.guest_access_allowed()
        window = MainWindow(
            self,
            self._backend,
            guest_allowed,
            title=self._config.title,
            icon=self._config.icon,
        )
        window.show_all()
        window.refresh()


def main():
    app = Application()
    sys.exit(app.run(sys.argv))


if __name__ == "__main__":
    main()
