import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

from .models import GuestAccess, ShareInfo, UserAccess
from .samba_backend import SambaBackend, SambaError

_GUEST_OPTIONS = [
    ("No guest access", GuestAccess.NONE),
    ("Read only", GuestAccess.READ),
    ("Read & Write", GuestAccess.WRITE),
]


class AddUserDialog(Gtk.Dialog):
    def __init__(self, parent):
        super().__init__(title="Add User", transient_for=parent, modal=True)
        self.set_default_size(300, -1)
        self.add_button("Cancel", Gtk.ResponseType.CANCEL)
        self.add_button("OK", Gtk.ResponseType.OK)
        self.set_default_response(Gtk.ResponseType.OK)
        self._build_content()

    def _build_content(self):
        box = self.get_content_area()
        box.set_spacing(8)
        box.set_margin_top(12)
        box.set_margin_bottom(12)
        box.set_margin_start(12)
        box.set_margin_end(12)

        grid = Gtk.Grid(column_spacing=8, row_spacing=8)
        box.add(grid)

        grid.attach(Gtk.Label(label="Username:", xalign=1), 0, 0, 1, 1)
        self._username_entry = Gtk.Entry()
        self._username_entry.set_activates_default(True)
        grid.attach(self._username_entry, 1, 0, 1, 1)

        grid.attach(Gtk.Label(label="Permission:", xalign=1), 0, 1, 1, 1)
        perm_box = Gtk.Box(spacing=12)
        self._radio_read = Gtk.RadioButton(label="Read")
        self._radio_write = Gtk.RadioButton(group=self._radio_read, label="Write")
        perm_box.pack_start(self._radio_read, False, False, 0)
        perm_box.pack_start(self._radio_write, False, False, 0)
        grid.attach(perm_box, 1, 1, 1, 1)

        box.show_all()

    def get_user_access(self) -> UserAccess | None:
        username = self._username_entry.get_text().strip()
        if not username:
            return None
        perm = "F" if self._radio_write.get_active() else "R"
        return UserAccess(username=username, permission=perm)


class DetailWindow(Gtk.Dialog):
    def __init__(self, parent, backend: SambaBackend, share: ShareInfo | None, guest_allowed: bool = True):
        title = "New Share" if share is None else f"Share: {share.name}"
        super().__init__(title=title, transient_for=parent, modal=True)
        self.set_default_size(500, 450)
        self._backend = backend
        self._parent_win = parent
        self._guest_allowed = guest_allowed
        self._guest_combo: Gtk.ComboBoxText | None = None
        self._original_name = share.name if share else None
        self._users: list[UserAccess] = list(share.users) if share else []

        self.add_button("Cancel", Gtk.ResponseType.CANCEL)
        ok_btn = self.add_button("OK", Gtk.ResponseType.OK)
        ok_btn.get_style_context().add_class("suggested-action")
        self.set_default_response(Gtk.ResponseType.OK)

        self._build_content(share)
        self.connect("response", self._on_response)

    def _build_content(self, share: ShareInfo | None):
        area = self.get_content_area()
        area.set_spacing(0)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        vbox.set_margin_top(12)
        vbox.set_margin_bottom(12)
        vbox.set_margin_start(12)
        vbox.set_margin_end(12)
        area.add(vbox)

        grid = Gtk.Grid(column_spacing=8, row_spacing=8)
        vbox.pack_start(grid, False, False, 0)

        def label(text):
            lbl = Gtk.Label(label=text, xalign=1)
            lbl.set_width_chars(10)
            return lbl

        grid.attach(label("Name:"), 0, 0, 1, 1)
        self._name_entry = Gtk.Entry()
        if share:
            self._name_entry.set_text(share.name)
        self._name_entry.set_hexpand(True)
        grid.attach(self._name_entry, 1, 0, 2, 1)

        grid.attach(label("Path:"), 0, 1, 1, 1)
        self._path_entry = Gtk.Entry()
        if share:
            self._path_entry.set_text(share.path)
        self._path_entry.set_hexpand(True)
        grid.attach(self._path_entry, 1, 1, 1, 1)

        browse_btn = Gtk.Button(label="Browse…")
        browse_btn.connect("clicked", self._on_browse_clicked)
        grid.attach(browse_btn, 2, 1, 1, 1)

        grid.attach(label("Comment:"), 0, 2, 1, 1)
        self._comment_entry = Gtk.Entry()
        if share:
            self._comment_entry.set_text(share.comment)
        self._comment_entry.set_hexpand(True)
        grid.attach(self._comment_entry, 1, 2, 2, 1)

        if self._guest_allowed:
            grid.attach(label("Guest:"), 0, 3, 1, 1)
            self._guest_combo = Gtk.ComboBoxText()
            for text, _ in _GUEST_OPTIONS:
                self._guest_combo.append_text(text)
            active = 0
            if share:
                for i, (_, val) in enumerate(_GUEST_OPTIONS):
                    if val == share.guest_access:
                        active = i
                        break
            self._guest_combo.set_active(active)
            grid.attach(self._guest_combo, 1, 3, 2, 1)

        vbox.pack_start(Gtk.Separator(), False, False, 4)

        user_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        user_header.pack_start(Gtk.Label(label="Users with access:", xalign=0), True, True, 0)
        add_btn = Gtk.Button(label="Add User")
        add_btn.connect("clicked", self._on_add_user_clicked)
        user_header.pack_end(add_btn, False, False, 0)
        vbox.pack_start(user_header, False, False, 0)

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sw.set_min_content_height(120)
        self._user_listbox = Gtk.ListBox()
        self._user_listbox.set_selection_mode(Gtk.SelectionMode.NONE)
        sw.add(self._user_listbox)
        vbox.pack_start(sw, True, True, 0)

        self._populate_user_list()
        area.show_all()

    def _populate_user_list(self):
        for row in self._user_listbox.get_children():
            self._user_listbox.remove(row)
        for ua in self._users:
            row = self._make_user_row(ua)
            self._user_listbox.add(row)
        self._user_listbox.show_all()

    def _make_user_row(self, ua: UserAccess) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        hbox.set_margin_top(4)
        hbox.set_margin_bottom(4)
        hbox.set_margin_start(8)
        hbox.set_margin_end(8)

        name_lbl = Gtk.Label(label=ua.username, xalign=0)
        name_lbl.set_hexpand(True)
        hbox.pack_start(name_lbl, True, True, 0)

        perm_label = "Write" if ua.permission == "F" else "Read"
        perm_lbl = Gtk.Label(label=perm_label)
        hbox.pack_start(perm_lbl, False, False, 0)

        del_btn = Gtk.Button(label="Remove")
        del_btn.connect("clicked", lambda _btn, u=ua: self._remove_user(u))
        hbox.pack_start(del_btn, False, False, 0)

        row.add(hbox)
        return row

    def _remove_user(self, ua: UserAccess):
        self._users = [u for u in self._users if u is not ua]
        self._populate_user_list()

    def _on_browse_clicked(self, btn):
        dialog = Gtk.FileChooserDialog(
            title="Select Folder",
            transient_for=self,
            action=Gtk.FileChooserAction.SELECT_FOLDER,
        )
        dialog.add_buttons(
            "Cancel", Gtk.ResponseType.CANCEL,
            "Select", Gtk.ResponseType.OK,
        )
        if dialog.run() == Gtk.ResponseType.OK:
            self._path_entry.set_text(dialog.get_filename())
        dialog.destroy()

    def _on_add_user_clicked(self, btn):
        add_dialog = AddUserDialog(self)
        response = add_dialog.run()
        if response == Gtk.ResponseType.OK:
            ua = add_dialog.get_user_access()
            if ua:
                self._users.append(ua)
                self._populate_user_list()
        add_dialog.destroy()

    def _on_response(self, dialog, response_id):
        if response_id != Gtk.ResponseType.OK:
            return
        share = self._collect_share()
        error = self._validate(share)
        if error:
            self._show_error(error)
            dialog.stop_emission_by_name("response")
            return
        try:
            self._backend.save_share(share)
        except SambaError as e:
            self._show_error(str(e))
            dialog.stop_emission_by_name("response")
            return
        self._parent_win.refresh()

    def _collect_share(self) -> ShareInfo:
        if self._guest_combo is not None:
            guest_idx = self._guest_combo.get_active()
            guest_access = _GUEST_OPTIONS[guest_idx][1] if guest_idx >= 0 else GuestAccess.NONE
        else:
            guest_access = GuestAccess.NONE
        return ShareInfo(
            name=self._name_entry.get_text().strip(),
            path=self._path_entry.get_text().strip(),
            comment=self._comment_entry.get_text().strip(),
            guest_access=guest_access,
            users=list(self._users),
        )

    def _validate(self, share: ShareInfo) -> str | None:
        if not share.name:
            return "Share name cannot be empty."
        if not share.path:
            return "Path cannot be empty."
        return None

    def _show_error(self, msg: str):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.CLOSE,
            text="Error",
        )
        dialog.format_secondary_text(msg)
        dialog.run()
        dialog.destroy()
