import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gdk, Gtk

from .models import ShareInfo
from .samba_backend import SambaBackend, SambaError

COL_NAME = 0
COL_PATH = 1
COL_COMMENT = 2
COL_GUEST = 3
COL_USERS = 4
COL_OBJ = 5

_GUEST_LABELS = {
    "none": "No",
    "read": "Read",
    "write": "Read/Write",
}


class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, app, backend: SambaBackend, guest_allowed: bool = True,
                 title: str = "Samba Usershare Manager", icon: str = ""):
        super().__init__(application=app, title=title)
        self._backend = backend
        self._guest_allowed = guest_allowed
        self._col_detail = None
        self._col_delete = None
        if icon:
            try:
                self.set_icon_from_file(icon)
            except Exception:
                pass
        self.set_default_size(800, 400)
        self._build_ui()

    def _build_ui(self):
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(vbox)

        toolbar_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        toolbar_box.set_margin_top(6)
        toolbar_box.set_margin_bottom(6)
        toolbar_box.set_margin_start(6)
        toolbar_box.set_margin_end(6)

        new_btn = Gtk.Button(label="New Share")
        new_btn.connect("clicked", self._on_new_clicked)
        toolbar_box.pack_start(new_btn, False, False, 0)
        vbox.pack_start(toolbar_box, False, False, 0)

        vbox.pack_start(Gtk.Separator(), False, False, 0)

        self._store = Gtk.ListStore(str, str, str, str, str, object)
        tv = Gtk.TreeView(model=self._store)
        tv.set_headers_visible(True)
        tv.connect("button-press-event", self._on_treeview_button_press)
        self._tv = tv

        for col_idx, title in [
            (COL_NAME, "Name"),
            (COL_PATH, "Path"),
            (COL_COMMENT, "Comment"),
            (COL_GUEST, "Guest"),
            (COL_USERS, "Users"),
        ]:
            renderer = Gtk.CellRendererText()
            if col_idx == COL_PATH:
                renderer.set_property("ellipsize", 3)  # PANGO_ELLIPSIZE_END
            col = Gtk.TreeViewColumn(title, renderer, text=col_idx)
            col.set_resizable(True)
            if col_idx == COL_PATH:
                col.set_expand(True)
            if col_idx == COL_GUEST:
                col.set_visible(self._guest_allowed)
            tv.append_column(col)

        detail_renderer = Gtk.CellRendererPixbuf()
        self._col_detail = Gtk.TreeViewColumn("", detail_renderer)
        self._col_detail.set_cell_data_func(detail_renderer, self._render_icon, "document-edit-symbolic")
        tv.append_column(self._col_detail)

        delete_renderer = Gtk.CellRendererPixbuf()
        self._col_delete = Gtk.TreeViewColumn("", delete_renderer)
        self._col_delete.set_cell_data_func(delete_renderer, self._render_icon, "user-trash-symbolic")
        tv.append_column(self._col_delete)

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw.add(tv)
        vbox.pack_start(sw, True, True, 0)

    def _render_icon(self, col, renderer, model, iter_, icon_name):
        icon_theme = Gtk.IconTheme.get_default()
        pixbuf = icon_theme.load_icon(icon_name, 16, Gtk.IconLookupFlags.FORCE_SYMBOLIC)
        renderer.set_property("pixbuf", pixbuf)

    def refresh(self):
        self._store.clear()
        try:
            shares = self._backend.list_shares()
        except SambaError as e:
            self._show_error("Could not load shares", str(e))
            return
        for share in shares:
            guest_label = _GUEST_LABELS.get(share.guest_access.value, "No")
            if share.stale:
                guest_label = f"[stale] {share.path}"
            self._store.append([
                share.name,
                share.path,
                share.comment,
                guest_label,
                str(share.user_count),
                share,
            ])

    def _on_new_clicked(self, btn):
        self._open_detail(None)

    def _on_treeview_button_press(self, tv, event):
        if event.type != Gdk.EventType.BUTTON_PRESS or event.button != 1:
            return False
        result = tv.get_path_at_pos(int(event.x), int(event.y))
        if result is None:
            return False
        path, column, _cx, _cy = result
        if column is not self._col_detail and column is not self._col_delete:
            return False
        iter_ = self._store.get_iter(path)
        share: ShareInfo = self._store.get_value(iter_, COL_OBJ)
        if column is self._col_detail:
            self._open_detail(share)
        else:
            self._confirm_delete(share)
        return True

    def _open_detail(self, share: ShareInfo | None):
        from .detail_window import DetailWindow
        dialog = DetailWindow(self, self._backend, share, self._guest_allowed)
        dialog.run()
        dialog.destroy()

    def _confirm_delete(self, share: ShareInfo):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.OK_CANCEL,
            text=f'Delete share "{share.name}"?',
        )
        dialog.format_secondary_text("This action cannot be undone.")
        response = dialog.run()
        dialog.destroy()
        if response != Gtk.ResponseType.OK:
            return
        try:
            self._backend.delete_share(share.name)
        except SambaError as e:
            self._show_error("Could not delete share", str(e))
            return
        self.refresh()

    def _show_error(self, title: str, detail: str):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.CLOSE,
            text=title,
        )
        dialog.format_secondary_text(detail)
        dialog.run()
        dialog.destroy()
