from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal, NotRequired, TypedDict

EventKind = Literal[
    "text",
    "tool.read",
    "tool.write",
    "tool.edit",
    "tool.exec",
    "skill",
    "error",
    "other",
]


class TextPayload(TypedDict):
    text: str


class _ToolPayload(TypedDict):
    tool: str


class ToolReadPayload(_ToolPayload):
    path: str
    content: str


class ToolWritePayload(_ToolPayload):
    path: str
    content: str


class ToolEditPayload(_ToolPayload):
    path: str
    old_text: str
    new_text: str


class ToolExecPayload(_ToolPayload):
    command: str
    description: str
    output: str
    exit_code: int


class SkillPayload(TypedDict):
    name: str
    dir: str
    content: str
    title: str


class ErrorPayload(TypedDict):
    error: str
    raw_line: str


class OtherPayload(TypedDict):
    type: str
    reason: str
    tool: NotRequired[str]


EventPayload = (
    TextPayload
    | ToolReadPayload
    | ToolWritePayload
    | ToolEditPayload
    | ToolExecPayload
    | SkillPayload
    | ErrorPayload
    | OtherPayload
)


@dataclass(frozen=True, slots=True)
class AgentEvent(object):
    """统一后的 Agent 事件."""

    kind: EventKind
    payload: EventPayload
    raw: Mapping[str, Any] | None = None
