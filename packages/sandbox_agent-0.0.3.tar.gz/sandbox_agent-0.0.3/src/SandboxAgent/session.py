import subprocess
import warnings
from collections.abc import Callable
from typing import IO

from .events import AgentEvent
from .protocols import AgentDriver


class ChatSession(object):
    def __init__(
        self,
        process: subprocess.Popen[str],
        *,
        driver: AgentDriver,
        stderr_file: IO[str],
        timeout: int,
        on_close: Callable[["ChatSession"], None] | None = None,
    ):
        if process.stdout is None:
            raise RuntimeError("Chat command stdout is not available.")

        self._process = process
        self._stdout = process.stdout
        self._driver = driver
        self._stderr_file = stderr_file
        self._timeout = timeout
        self._on_close = on_close

        self._raw_history: list[str] = []
        self._event_history: list[AgentEvent] = []
        self._finished = False
        self._closed = False
        self._returncode_checked = False

    def __del__(self) -> None:
        if not self._closed:
            warnings.warn(
                f"ChatSession was garbage collected without being wait()'d or close()'d. "
                f"Call session.wait() after use.",
                ResourceWarning,
                stacklevel=1,
            )
            self.close()

    def __iter__(self) -> "ChatSession":
        return self

    def __len__(self) -> int:
        return len(self._event_history)

    def __next__(self) -> str:
        if self._finished:
            raise StopIteration

        line = self._stdout.readline()
        if line == "":
            self._finished = True
            raise StopIteration

        self._append_line(line)
        return line

    def _append_line(self, line: str) -> None:
        self._raw_history.append(line)
        event = self._driver.parse_event(line)
        if event is not None:
            self._event_history.append(event)

    def _drain_stdout(self) -> None:
        if self._finished or self._stdout.closed:
            return

        for line in self._stdout:
            self._append_line(line)
        self._finished = True

    def _check_returncode(self) -> None:
        if self._returncode_checked:
            return

        returncode = self._process.returncode
        if returncode is None:
            raise RuntimeError("Chat command is still running.")

        self._returncode_checked = True
        if returncode in (124, 137):
            raise TimeoutError(f"Chat command timed out after {self._timeout} seconds")

        if returncode != 0:
            self._stderr_file.seek(0)
            raise subprocess.CalledProcessError(
                returncode=returncode,
                cmd=self._process.args,
                stderr=self._stderr_file.read(),
            )

    def _finalize(self) -> None:
        if self._closed:
            return

        if not self._stdout.closed:
            self._stdout.close()
        self._stderr_file.close()
        self._closed = True
        if self._on_close is not None:
            callback = self._on_close
            self._on_close = None
            try:
                callback(self)
            except Exception:
                pass

    def wait(self) -> "ChatSession":
        if self._closed:
            return self

        try:
            self._drain_stdout()
            self._process.wait()
            self._check_returncode()
            self._finished = True
            return self
        finally:
            self._finalize()

    def close(self) -> None:
        if self._closed:
            return

        try:
            if self._process.poll() is None:
                try:
                    self._process.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    self._process.kill()
                    self._process.wait()
            self._finished = True
        finally:
            self._finalize()

    @property
    def lines(self) -> tuple[str, ...]:
        return tuple(self._raw_history)

    @property
    def events(self) -> tuple[AgentEvent, ...]:
        return tuple(self._event_history)

    @property
    def last_text(self) -> str | None:
        for event in reversed(self._event_history):
            if event.kind == "text":
                return event.payload["text"]  # type: ignore[return-value]
        return None

    @property
    def last_event(self) -> AgentEvent | None:
        if not self._event_history:
            return None
        return self._event_history[-1]

    @property
    def full_text(self) -> str:
        return "".join(
            event.payload["text"]  # type: ignore[index]
            for event in self._event_history
            if event.kind == "text"
        )

    @property
    def finished(self) -> bool:
        return self._finished

    @property
    def closed(self) -> bool:
        return self._closed
