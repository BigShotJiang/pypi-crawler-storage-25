import base64


def shell_write_file(content: str | bytes, path: str) -> str:
    """构造 shell 命令片段, 通过 base64 编码将 content 安全写入指定路径.

    返回可直接嵌入 sh -c 的命令字符串片段, 不含 sh -c 前缀.

    Args:
        content: 要写入的文件内容.
        path: 容器内的目标文件路径.

    Returns:
        shell 命令片段, 如 "echo 'xxx' | base64 -d > /path/to/file".
    """
    if isinstance(content, str):
        content = content.encode("utf-8")
    encoded = base64.b64encode(content).decode("ascii")
    return f"echo '{encoded}' | base64 -d > {path}"
