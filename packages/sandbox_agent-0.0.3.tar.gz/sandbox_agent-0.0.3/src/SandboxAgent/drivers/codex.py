from collections.abc import Mapping, Sequence

from ..events import AgentEvent


class CodexDriver:
    """Codex 协议驱动."""

    name = "codex"
    skills_path = "/root/.config/codex/skills"
    agents_path = "/root/.codex/AGENTS.md"

    def __init__(
        self,
        *,
        base_url: str | None = None,
        auth_token: str | None = None,
    ) -> None:
        self.base_url = base_url
        self.auth_token = auth_token
        self.env: Mapping[str, str] | None = None

    def build_setup_command(self) -> Sequence[str]:
        raise NotImplementedError("CodexDriver.build_setup_command() not implemented yet.")

    def build_chat_command(
        self,
        prompt: str,
        *,
        model: str | None = None,
        resume: bool = True,
    ) -> Sequence[str]:
        raise NotImplementedError("CodexDriver.build_chat_command() not implemented yet.")

    def parse_event(self, line: str) -> AgentEvent | None:
        raise NotImplementedError("CodexDriver.parse_event() not implemented yet.")
