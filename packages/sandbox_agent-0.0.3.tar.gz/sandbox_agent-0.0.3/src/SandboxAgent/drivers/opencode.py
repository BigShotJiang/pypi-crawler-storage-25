import os
import json
from collections.abc import Mapping, Sequence

from ..events import AgentEvent
from ..utils import shell_write_file


class OpenCodeDriver:
    """OpenCode 协议驱动."""

    name = "opencode"
    skills_path = "/root/.config/opencode/skills"
    agents_path = "/root/.config/opencode/AGENTS.md"
    auth_file_path = "/root/.local/share/opencode/auth.json"

    def __init__(self, *, provider: str, api_key: str) -> None:
        self.provider = provider
        self.api_key = api_key
        self.env: Mapping[str, str] | None = None

    def build_setup_command(self) -> Sequence[str]:
        auth = {self.provider: {"type": "api", "key": self.api_key}}
        content = json.dumps(auth, ensure_ascii=False)
        auth_dir = os.path.dirname(self.auth_file_path)
        write_cmd = shell_write_file(content, self.auth_file_path)
        return (
            "sh", "-c",
            f"mkdir -p {auth_dir} {self.skills_path} && {write_cmd}",
        )

    def build_chat_command(
        self,
        prompt: str,
        *,
        model: str | None = None,
        resume: bool = True,
    ) -> Sequence[str]:
        command: list[str] = ["opencode", "run"]
        if resume:
            command.append("--continue")
        command.extend(["--format", "json"])
        if model:
            command.extend(["--model", model])
        command.append(prompt)
        return tuple(command)

    def _parse_event_tool(
        self,
        part: dict[str, object],
    ) -> AgentEvent:
        tool = str(part.get("tool", "")).strip()
        state = part.get("state")
        if not isinstance(state, dict):
            state = {}
        tool_input = state.get("input")
        if not isinstance(tool_input, dict):
            tool_input = {}
        metadata = state.get("metadata")
        if not isinstance(metadata, dict):
            metadata = {}
        tool_output = str(state.get("output", ""))

        match tool:
            case "skill":
                name = str(tool_input.get("name", "")).strip()
                skill_dir = str(metadata.get("dir", "")).strip()
                title = str(state.get("title", "")).strip()
                payload = {"name": name, "dir": skill_dir, "content": tool_output, "title": title}
                return AgentEvent(kind="skill", payload=payload, raw=None)
            case "read":
                path = str(tool_input.get("filePath", "")).strip()
                payload = {"tool": "read", "path": path, "content": tool_output}
                return AgentEvent(kind="tool.read", payload=payload, raw=None)
            case "write":
                path = str(tool_input.get("filePath", "")).strip()
                content = str(tool_input.get("content", ""))
                payload = {"tool": "write", "path": path, "content": content}
                return AgentEvent(kind="tool.write", payload=payload, raw=None)
            case "edit":
                path = str(tool_input.get("filePath", "")).strip()
                old_text = str(tool_input.get("oldString", ""))
                new_text = str(tool_input.get("newString", ""))
                payload = {"tool": "edit", "path": path, "old_text": old_text, "new_text": new_text}
                return AgentEvent(kind="tool.edit", payload=payload, raw=None)
            case "bash":
                c = str(tool_input.get("command", "")).strip()
                d = str(tool_input.get("description", "")).strip()
                o = tool_output.strip()
                try:
                    e = int(metadata.get("exit", 0))
                except (ValueError, TypeError):
                    e = -1
                payload = {"tool": "bash", "command": c, "description": d, "output": o, "exit_code": e}
                return AgentEvent(kind="tool.exec", payload=payload, raw=None)
            case _:
                payload = {"type": f"tool.{tool}", "reason": f"unsupported_tool: {tool}."}
                return AgentEvent(kind="other", payload=payload, raw=None)

    def _parse_event(self, line: str) -> AgentEvent | None:
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            return None

        if not isinstance(data, dict):
            return None

        event_type = str(data.get("type", "")).strip()
        part = data.get("part")
        if not isinstance(part, dict):
            part = {}

        match event_type:
            case "text":
                text = str(part.get("text", ""))
                if not text:
                    return None
                return AgentEvent(kind="text", payload={"text": text}, raw=data)
            case "tool_use":
                event = self._parse_event_tool(part)
                return AgentEvent(kind=event.kind, payload=event.payload, raw=data)
            case "step_start" | "step_finish":
                # 生命周期事件不携带有用信息，直接丢弃
                return None
            case _:
                payload = {"type": event_type, "reason": "unsupported_event_type"}
                return AgentEvent(kind="other", payload=payload, raw=data)

    def parse_event(self, line: str) -> AgentEvent | None:
        try:
            return self._parse_event(line)
        except Exception as exc:
            payload = {"error": f"{type(exc).__name__}: {exc}", "raw_line": line}
            return AgentEvent(kind="error", payload=payload, raw=None)
