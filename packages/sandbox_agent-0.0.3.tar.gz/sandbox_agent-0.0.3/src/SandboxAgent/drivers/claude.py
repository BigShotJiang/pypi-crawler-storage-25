from collections.abc import Mapping, Sequence

from ..events import AgentEvent


class ClaudeCodeDriver:
    """Claude Code 协议驱动."""

    name = "claude-code"
    skills_path = "/root/.claude/skills"
    agents_path = "/root/.claude/CLAUDE.md"

    def __init__(
        self,
        *,
        base_url: str | None = None,
        auth_token: str | None = None,
    ) -> None:
        # 过滤合法的环境变量
        self.env: Mapping[str, str] | None = {
            k: v for k, v in {
                "ANTHROPIC_BASE_URL": base_url,
                "ANTHROPIC_AUTH_TOKEN": auth_token,
            }.items() if v
        } or None

    def build_setup_command(self) -> Sequence[str]:
        return ()

    def build_chat_command(
        self,
        prompt: str,
        *,
        model: str | None = None,
        resume: bool = True,
    ) -> Sequence[str]:
        raise NotImplementedError("ClaudeCodeDriver.build_chat_command() not implemented yet.")

    def parse_event(self, line: str) -> AgentEvent | None:
        raise NotImplementedError("ClaudeCodeDriver.parse_event() not implemented yet.")
