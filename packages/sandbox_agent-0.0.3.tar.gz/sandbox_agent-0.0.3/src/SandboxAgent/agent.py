import os
import tempfile
import subprocess
import uuid
from contextlib import ExitStack
from collections.abc import Mapping, Sequence
from typing import Any

from .protocols import AgentDriver
from .session import ChatSession

SANDBOX_AGENT_IMAGE_NAME: str = "test"
SANDBOX_AGENT_MAX_CONTAINERS: int = 20


class SafeAgent(object):
    _RESOURCE_PREFIX = "safe-agent"

    def __init__(
        self,
        driver: AgentDriver,
        image: str = SANDBOX_AGENT_IMAGE_NAME,
        *,
        model: str | None = None,
        resume: bool = True,
    ):
        self.image: str = image
        self.name: str = f"{self._RESOURCE_PREFIX}_{uuid.uuid4()}"
        self._driver = driver
        self._model = model
        self._resume = resume
        self._entered = False
        self._sessions: set[ChatSession] = set()

    def __enter__(self) -> "SafeAgent":
        if self._entered:
            raise RuntimeError("SafeAgent is already entered.")

        with ExitStack() as stack:
            self._entered = True
            stack.callback(lambda: setattr(self, "_entered", False))

            self._check_capacity()

            self._start_container()
            stack.callback(self._stop_container)

            self._setup()

            stack.pop_all()

        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        try:
            self._close_sessions()
            self._stop_container()
        finally:
            self._entered = False
            self._sessions.clear()

    def _check_capacity(self) -> None:
        """检查当前运行中的同前缀容器数量是否超出上限."""
        proc = self._popen_cmd(
            ["docker", "ps", "-q", "--filter", f"name={self._RESOURCE_PREFIX}"],
        )
        stdout, stderr = proc.communicate(timeout=10)
        if proc.returncode != 0:
            detail = (stderr or "").strip()
            raise RuntimeError(
                f"Failed to query running containers"
                + (f": {detail}" if detail else "")
            )
        count = len(stdout.strip().splitlines()) if stdout.strip() else 0
        limit = int(os.environ.get("SANDBOX_AGENT_MAX_CONTAINERS", SANDBOX_AGENT_MAX_CONTAINERS))
        if count >= limit:
            raise RuntimeError(
                f"Running container count ({count}) reached limit ({limit})."
            )

    def _setup(self) -> None:
        skills_path = self._get_skills_path()
        agents_path = self._get_agents_path()
        # 1. 运行初始化命令
        setup_cmd = self._driver.build_setup_command()
        if setup_cmd:
            self._exec_container_cmd(list(setup_cmd))
        # 2. 确保 skills 目录和规则文件父目录存在
        self._run_cmd(
            ["docker", "exec", self.name, "mkdir", "-p", skills_path, os.path.dirname(agents_path)],
            error_msg=(
                "Failed to prepare agent directories: "
                f"{skills_path}, {os.path.dirname(agents_path)}."
            ),
        )
        return

    def _start_container(self) -> None:
        cmd = [
            "docker", "run", "--rm", "-d",
            "--name", self.name,
            "--memory", "1g",
            "--cpus", "1.0",
            self.image,
            "sleep", "3600",
        ]
        self._run_cmd(cmd, error_msg=f"Failed to start container {self.name}")

    def _stop_container(self) -> None:
        """清理容器. 这是信任根, 总是信任这个函数能够正确清理容器"""
        self._run_cmd(
            ["docker", "rm", "-f", self.name],
            error_msg=f"Failed to stop container {self.name}",
        )

    def _discard_session(self, session: ChatSession) -> None:
        self._sessions.discard(session)

    def _close_sessions(self) -> None:
        for session in tuple(self._sessions):
            session.close()

    def _run_cmd(
        self,
        cmd: list[str],
        *,
        error_msg: str = "",
        timeout: int = 30,
    ) -> int:
        try:
            result = subprocess.run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired as exc:
            message = error_msg or f"Command timed out after {timeout} seconds"
            stderr = (exc.stderr or "").strip() if isinstance(exc.stderr, str) else ""
            if stderr:
                message = f"{message}: {stderr}"
            raise RuntimeError(message) from exc

        if result.returncode != 0:
            stderr = (result.stderr or "").strip()
            message = error_msg or f"Command failed with exit code {result.returncode}"
            if stderr:
                message = f"{message}: {stderr}"
            raise RuntimeError(message)
        return result.returncode

    def _popen_cmd(
        self,
        cmd: list[str],
        *,
        stderr: Any = None,
    ) -> subprocess.Popen[str]:
        return subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=stderr,
            text=True,
            bufsize=1,
        )

    def _build_docker_exec_cmd(
        self,
        cmd: Sequence[str],
        *,
        env: Mapping[str, str] | None = None,
    ) -> list[str]:
        if not self._entered:
            raise RuntimeError("SafeAgent must be called inside a with block.")

        docker_cmd = ["docker", "exec"]
        if env:
            for key, value in env.items():
                docker_cmd.extend(["-e", f"{key}={value}"])
        docker_cmd.append(self.name)
        docker_cmd.extend(cmd)
        return docker_cmd

    def _exec_container_cmd(
        self,
        cmd: Sequence[str],
        *,
        error_msg: str = "",
        env: Mapping[str, str] | None = None,
    ) -> int:
        return self._run_cmd(
            self._build_docker_exec_cmd(cmd, env=env),
            error_msg=error_msg,
        )

    def _popen_container_cmd(
        self,
        cmd: Sequence[str],
        *,
        stderr: Any = None,
        env: Mapping[str, str] | None = None,
    ) -> subprocess.Popen[str]:
        return self._popen_cmd(
            self._build_docker_exec_cmd(cmd, env=env),
            stderr=stderr,
        )

    def _copy_l2c_container(self, src: str, dst: str) -> None:
        self._run_cmd(
            ["docker", "cp", src, f"{self.name}:{dst}"],
            error_msg=f"Failed to copy file {src} to {self.name}:{dst}.",
        )

    def _get_skills_path(self) -> str:
        path = getattr(self._driver, "skills_path", "")
        if not isinstance(path, str) or not path or not os.path.isabs(path):
            raise RuntimeError(f"Driver {self._driver.name} has invalid skills_path: {path!r}")
        return path

    def _get_agents_path(self) -> str:
        path = getattr(self._driver, "agents_path", "")
        if not isinstance(path, str) or not path or not os.path.isabs(path):
            raise RuntimeError(f"Driver {self._driver.name} has invalid agents_path: {path!r}")
        return path

    def _write_container(self, content: str | bytes, path: str) -> None:
        if isinstance(content, str):
            content = content.encode("UTF-8")
        if not isinstance(content, bytes):
            raise TypeError("content must be str or bytes")

        self._exec_container_cmd(["mkdir", "-p", os.path.dirname(path)])

        with tempfile.TemporaryDirectory(prefix=self._RESOURCE_PREFIX) as tmp_dir:
            tmp_path = os.path.join(tmp_dir, "upload")
            with open(tmp_path, "wb") as file_obj:
                file_obj.write(content)
            self._copy_l2c_container(tmp_path, path)

    def add_skill(self, name: str, path: str) -> None:
        skill_path: str = ""
        if name != str(name).strip():
            raise RuntimeError("Invalid Skill Name.")
        if not os.path.exists(f"{path}/SKILL.md"):
            raise RuntimeError(
                f"Invalid Skill Dir Path. Please ensure `{path}/SKILL.md` exists."
            )

        skill_path = os.path.realpath(path)
        self._copy_l2c_container(skill_path, os.path.join(self._get_skills_path(), name))

    def install_rules(self, content: str | bytes) -> None:
        """安装全局 AGENTS.md 规则文件."""
        if not content:
            raise ValueError("content must be a non-empty str or bytes.")
        self._write_container(content, self._get_agents_path())

    def chat(self, prompt: str, *, timeout: int = 300) -> ChatSession:
        if not isinstance(prompt, str) or not prompt:
            raise ValueError("prompt must be a non-empty string.")

        cmd = ["timeout", "-k", "5s", f"{timeout}s"]
        cmd += self._driver.build_chat_command(
            prompt,
            model=self._model,
            resume=self._resume,
        )

        stderr_file = tempfile.TemporaryFile(mode="w+", encoding="utf-8")
        try:
            process = self._popen_container_cmd(cmd, stderr=stderr_file, env=self._driver.env)
            session = ChatSession(
                process,
                driver=self._driver,
                stderr_file=stderr_file,
                timeout=timeout,
                on_close=self._discard_session,
            )
        except Exception:
            stderr_file.close()
            raise

        self._sessions.add(session)
        return session
