# Sandbox Agent
---

### 通过 JSON Stream 调用 Agent
```bash
# codex
codex exec resume --last --json "我刚刚问你啥了"

# claude code
claude --continue --verbose --print --output-format "stream-json" "我刚刚问你啥了"

# opencode
opencode run --continue --format json --model "opencode/qwen3.6-plus-free" "我刚刚问你啥了"
```

### 配置系统
```
# codex
1. 全局配置文件
    - /root/.codex/config.toml
2. 身份认证文件
    - /root/.codex/auth.json
3. Skills 目录
    - /home/.agents/skills/<name>/SKILL.md
4. AGENTS 文件
    - /root/.codex/AGENTS.md

# claude code
1. 全局配置文件
    - /root/.claude/settings.json
2. 身份认证系统使用环境变量, 主要是下面的两个环境变量:
    - ANTHROPIC_BASE_URL
    - ANTHROPIC_AUTH_TOKEN
3. Skills 目录
    - /root/.claude/skills/<name>/SKILL.md
4. AGENTS 文件
    - /root/.claude/CLAUDE.md

# opencode
1. 全局配置文件
    - /root/.config/opencode/opencode.json
2. 身份认证文件
    - /root/.local/share/opencode/auth.json
3. Skills 目录
    - /root/.config/opencode/skills/<name>/SKILL.md
4. AGENTS 文件
    - /root/.config/opencode/AGENTS.md
```
