# Opencode Safe Runner
---


> https://opencode.ai/docs/skills
> https://github.com/anthropics/skills/blob/main/template/SKILL.md



### Opencode

1. 获取最近的 Session ID
    - `opencode session list | grep ses_ | awk '{print $1}' | head -1`
2. 删除指定的 Session ID
    - `opencode delete <sessionID>`


## 构建与发布

```bash
uv sync --all-extras
uv build
uv publish
```
