"""Per-agent workspace creator for `meshcode setup`.

NEW MODEL (1.3.0): instead of polluting the user's global MCP config
(~/.claude.json, ~/.cursor/mcp.json, ...), each `meshcode setup <project>
<agent>` creates an isolated workspace directory at:

    ~/meshcode/<project>-<agent>/

containing a single .mcp.json with ONLY that agent's MCP server entry.
The user then runs `meshcode run <agent>` to launch their editor with
that workspace, and ONLY that one agent goes online. Closing the editor
window flips the agent offline. No cross-window status pollution.

Backward compatibility: the old `meshcode setup <client> <project>
<agent>` form still works for the global-config flow (kept for users
on Claude Desktop, which doesn't support per-instance MCP configs).
"""
import json
import os
import platform
import sys
from pathlib import Path
from typing import Dict, Any, Optional

from meshcode.exceptions import AuthError, RPCError, MeshCodeConnectionError
from meshcode._stop_hook_template import STOP_HOOK_BODY as _STOP_HOOK_BODY


def _load_credentials(profile: str = "default") -> Dict[str, str]:
    """Load the api key + non-secret metadata for the given keychain profile.

    1.4.1+ stores api keys in the OS keychain. The api key is read from there
    via the secrets module. Non-secret metadata (user_id / email / display_name)
    lives in ~/.meshcode/profile_meta.json. Falls back to the legacy
    credentials.json file if the migration hasn't run yet (e.g. first run after
    upgrade).
    """
    try:
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
    except Exception as e:
        raise AuthError(f"cannot load secrets module: {e}") from e

    api_key = secrets_mod.get_api_key(profile=profile)
    if not api_key:
        raise AuthError(
            "No credentials found. You need to log in first.\n"
            "\n"
            "  1. Get your API key at: https://meshcode.io/onboarding\n"
            "     (or https://meshcode.io/settings if you already have an account)\n"
            "  2. Run: meshcode login mc_<your-api-key>\n"
            "  3. Then re-run this command."
        )

    meta_path = Path.home() / ".meshcode" / "profile_meta.json"
    meta: Dict[str, Any] = {"api_key": api_key}
    if meta_path.exists():
        try:
            extra = json.loads(meta_path.read_text(encoding="utf-8"))
            if isinstance(extra, dict):
                meta.update({k: v for k, v in extra.items() if v is not None})
        except Exception:
            pass
    # Legacy fallback (pre-1.4.1): if profile_meta.json doesn't exist, try the
    # old credentials.json for non-secret fields. The api key itself is already
    # in keychain by now (via migrate_legacy_credentials).
    legacy_path = Path.home() / ".meshcode" / "credentials.json"
    if legacy_path.exists() and not meta_path.exists():
        try:
            legacy = json.loads(legacy_path.read_text(encoding="utf-8"))
            if isinstance(legacy, dict):
                for k in ("user_id", "email", "display_name"):
                    if legacy.get(k) and not meta.get(k):
                        meta[k] = legacy[k]
        except Exception:
            pass
    return meta


def _load_supabase_env() -> Dict[str, str]:
    """Read SUPABASE_URL/SUPABASE_KEY from env or ~/.meshcode/env, fall back to publishable defaults."""
    url = os.environ.get("SUPABASE_URL", "")
    key = os.environ.get("SUPABASE_KEY", "")
    if not url or not key:
        env_file = Path.home() / ".meshcode" / "env"
        if env_file.exists():
            for line in env_file.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line.startswith("export "):
                    line = line[7:]
                if "=" in line:
                    k, v = line.split("=", 1)
                    v = v.strip().strip('"').strip("'")
                    if k == "SUPABASE_URL" and not url:
                        url = v
                    elif k == "SUPABASE_KEY" and not key:
                        key = v
    if not url:
        url = "https://gjinagyyjttyxnaoavnz.supabase.co"
    if not key:
        key = "sb_publishable_qwN9PO1L7jUXhhbhhVk2CQ_z1FXG2Qf"
    return {"SUPABASE_URL": url, "SUPABASE_KEY": key}


def _resolve_project_id(api_key: str, project: str, sb: Dict[str, str]) -> str:
    """Call mc_resolve_project SECURITY DEFINER RPC to get the project_id."""
    try:
        from urllib.request import Request as _Req, urlopen as _urlopen
        body = json.dumps({"p_api_key": api_key, "p_project_name": project}).encode()
        req = _Req(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_resolve_project",
            data=body,
            method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
            },
        )
        with _urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            if isinstance(data, dict) and data.get("project_id"):
                return data["project_id"]
            if isinstance(data, dict) and data.get("error"):
                # Build a helpful message including the user's actual projects
                hint = _suggest_projects_str(api_key, sb)
                msg = f"could not resolve project '{project}': {data['error']}"
                if hint:
                    msg += f"\n{hint}"
                raise RPCError(msg, rpc_name="mc_resolve_project", detail=data["error"])
    except (RPCError, AuthError):
        raise
    except Exception as e:
        raise MeshCodeConnectionError(
            f"could not resolve project '{project}': {e}\n"
            f"Check your API key and project name. Get help at https://meshcode.io/docs"
        ) from e
    return ""


def _suggest_projects_str(api_key: str, sb: dict) -> str:
    """Try to list the user's projects; return a hint string (or empty)."""
    try:
        from urllib.request import Request as _Req, urlopen as _urlopen
        body = json.dumps({"p_api_key": api_key}).encode()
        req = _Req(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_list_user_projects",
            data=body,
            method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
            },
        )
        with _urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
        projects = data.get("projects", []) if isinstance(data, dict) else []
        if projects:
            lines = ["Your projects:"]
            for p in projects:
                lines.append(f"  - {p['name']}")
            return "\n".join(lines)
    except Exception:
        pass
    return ""


def _suggest_projects(api_key: str, sb: dict):
    """Print the user's projects to stderr (CLI convenience wrapper)."""
    hint = _suggest_projects_str(api_key, sb)
    if hint:
        for line in hint.splitlines():
            print(f"[meshcode] {line}", file=sys.stderr)


def _build_server_block(project: str, project_id: str, agent: str, role: str,
                         api_key: str, sb: Dict[str, str],
                         keychain_profile: str = "default",
                         editor_type: str = "") -> Dict[str, Any]:
    """Build the MCP server config block for an agent.

    1.4.1+ does NOT bake the api key into the env. Instead it bakes a
    `MESHCODE_KEYCHAIN_PROFILE` env var that names the keychain entry the
    MCP server should look up at boot. The api key never appears in any
    file on disk and never in process env / `ps eauxww`.

    For backwards compatibility, if the keychain isn't available on this
    OS, the api key falls back to the env var (legacy path).
    """
    env: Dict[str, str] = {
        "MESHCODE_PROJECT": project,
        "MESHCODE_PROJECT_ID": project_id,
        "MESHCODE_AGENT": agent,
        "MESHCODE_ROLE": role or "MCP-connected agent",
        "MESHCODE_KEYCHAIN_PROFILE": keychain_profile,
        "SUPABASE_URL": sb["SUPABASE_URL"],
        "SUPABASE_KEY": sb["SUPABASE_KEY"],
        # Force UTF-8 stdio so the MCP JSON-RPC channel doesn't crash on
        # Windows cp1252 when the server emits any non-ASCII char.
        "PYTHONIOENCODING": "utf-8",
        # Mark this Python process as the MCP serve subprocess so other
        # parts of the package (e.g. self_update) skip auto-update inside it.
        "MESHCODE_MCP_SERVE": "1",
    }
    if editor_type:
        env["MESHCODE_EDITOR_TYPE"] = editor_type
    # Belt-and-suspenders fallback: if the OS doesn't have a keychain backend
    # the MCP server can't read the key from there, so we still need to pass
    # it via env. Probe and only include it as a fallback path.
    try:
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
        if not secrets_mod.keyring_status().get("available", False):
            env["MESHCODE_API_KEY"] = api_key
    except Exception:
        env["MESHCODE_API_KEY"] = api_key
    return {
        "command": sys.executable or "python3",
        "args": ["-m", "meshcode.meshcode_mcp", "serve"],
        "env": env,
    }


def _restrict_perms(path: Path) -> None:
    """Restrict file to owner-only access (Windows-aware)."""
    try:
        if sys.platform == "win32":
            import subprocess
            username = os.environ.get("USERNAME", os.environ.get("USER", ""))
            if username:
                subprocess.run(
                    ["icacls", str(path), "/inheritance:r",
                     "/grant:r", f"{username}:(F)"],
                    capture_output=True, timeout=5,
                )
        else:
            os.chmod(path, 0o600)
    except Exception:
        pass


def _atomic_write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    _restrict_perms(tmp)
    tmp.replace(path)
    _restrict_perms(path)


def _toml_escape(s: str) -> str:
    """Escape a string for a TOML basic string literal."""
    return s.replace("\\", "\\\\").replace("\"", "\\\"")


def _render_codex_block(server_id: str, server_block: Dict[str, Any]) -> str:
    """Render a [mcp_servers.<server_id>] section (plus [.env] subtable) for
    Codex CLI's ~/.codex/config.toml format. Returns a text block starting
    with a leading newline so it appends cleanly to existing files."""
    cmd = _toml_escape(str(server_block.get("command", "")))
    args = server_block.get("args", []) or []
    env = server_block.get("env", {}) or {}
    # Quote the section name only if it contains special chars. server_id is
    # our deterministic "meshcode-<project>-<agent>" slug; hyphens require
    # quoting in TOML bare keys, so always quote.
    section = f'"{_toml_escape(server_id)}"'
    lines = []
    lines.append("")
    lines.append(f"[mcp_servers.{section}]")
    lines.append(f'command = "{cmd}"')
    args_rendered = ", ".join(f'"{_toml_escape(str(a))}"' for a in args)
    lines.append(f"args = [{args_rendered}]")
    if env:
        lines.append("")
        lines.append(f"[mcp_servers.{section}.env]")
        for k, v in env.items():
            lines.append(f'{k} = "{_toml_escape(str(v))}"')
    lines.append("")
    return "\n".join(lines)


def _atomic_write_toml_codex(path: Path, server_id: str, server_block: Dict[str, Any]) -> None:
    """Read/replace/write ~/.codex/config.toml preserving all other sections.

    Codex CLI uses TOML with [mcp_servers.<name>] tables (optionally a
    [mcp_servers.<name>.env] subtable). We don't want to round-trip the
    entire TOML file (stdlib can only READ TOML via tomllib, not write),
    so we do surgical text replacement:

      * If [mcp_servers."<server_id>"] already exists, find that section
        header and delete everything from it up to (but not including) the
        next top-level-ish section header that is NOT a sub-table of the
        same server (i.e. next `[` that doesn't start with
        `[mcp_servers."<server_id>".`), or EOF.
      * Then append the freshly rendered block.
      * If no prior section, just append to end.

    Atomic via tempfile + replace.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    text = path.read_text(encoding="utf-8") if path.exists() else ""

    quoted = f'"{_toml_escape(server_id)}"'
    header = f"[mcp_servers.{quoted}]"
    subheader_prefix = f"[mcp_servers.{quoted}."

    lines = text.splitlines(keepends=True)
    out: list = []
    i = 0
    removed = False
    while i < len(lines):
        stripped = lines[i].lstrip()
        if not removed and (stripped.startswith(header) or stripped.startswith(subheader_prefix)):
            # Skip this section and any following lines until we hit a new
            # top-level `[` section that is NOT our server's sub-table.
            i += 1
            while i < len(lines):
                s2 = lines[i].lstrip()
                if s2.startswith("[") and not s2.startswith(subheader_prefix) and not s2.startswith(header):
                    break
                i += 1
            removed = True
            continue
        out.append(lines[i])
        i += 1

    new_text = "".join(out)
    # Ensure exactly one trailing newline before we append our block.
    if new_text and not new_text.endswith("\n"):
        new_text += "\n"
    new_text += _render_codex_block(server_id, server_block)

    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(new_text, encoding="utf-8")
    tmp.replace(path)


def _write_continue_config(ws: Path, server_id: str, server_block: Dict[str, Any]) -> None:
    """Write Continue.dev MCP config at workspace/.continue/config.yaml.

    Continue.dev uses YAML for its config. We write a minimal config with
    just the MCP server entry.
    """
    env = server_block.get("env", {})
    cmd = server_block.get("command", "python3")
    args = server_block.get("args", [])

    # Build YAML manually (no yaml dependency)
    lines = ["# MeshCode MCP server - auto-generated by meshcode setup"]
    lines.append("models: []")
    lines.append("mcpServers:")
    lines.append(f"  - name: {server_id}")
    lines.append(f"    command: {cmd}")
    lines.append("    args:")
    for a in args:
        lines.append(f"      - \"{a}\"")
    if env:
        lines.append("    env:")
        for k, v in env.items():
            lines.append(f"      {k}: \"{v}\"")

    config_dir = ws / ".continue"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / "config.yaml"
    try:
        config_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except (IOError, OSError) as e:
        print(f"[meshcode] WARNING: could not write Continue config: {e}", file=sys.stderr)


# ============================================================
# WORKSPACE MODEL (1.3.0+) — one isolated dir per agent
# ============================================================

WORKSPACES_ROOT = Path.home() / "meshcode"


def _workspace_dir(project: str, agent: str) -> Path:
    return WORKSPACES_ROOT / f"{project}-{agent}"


# ============================================================
# SKILLS-1 — generic skills bundle (all roles)
# ============================================================
# Written to {ws}/.claude/skills/*.md. Claude Code reads these as
# session-start guidance. Each file documents one teamwork-skill the
# mesh agreed on (consensus shipped 2026-05-06: file-claim, error-shape,
# done-signal-guard, memory-weight-encode, lateral-skill-share).
#
# Hooks intentionally NOT included in this version — pre-edit file lock
# enforcement requires the hook to call into the running MCP server,
# which would cycle. Hook variant ships once SDK has a non-blocking
# claim path. Until then, the .md guidance is sufficient — Claude reads
# it and calls mc_claim_file via tool, no shell-out needed.
_GENERIC_SKILLS = {
    "file-claim.md": """# /file-claim — claim before edit

Triggers when about to Edit/Write a path under a shared worktree
(`~/.meshcode/agents/*/Desktop/*` or `Desktop/meshcode/*`).

**Before** the Edit/Write tool call:

1. `mc_list_file_locks(path)` — check if another agent holds a lock.
2. If a lock is held with > 1min remaining → STOP. Use `meshcode_send`
   to coordinate with the lock owner before continuing.
3. Otherwise: `mc_claim_file(path, ttl_minutes=15)` and proceed.

Renew the lock every ~10 min if the edit takes longer.

**Why:** shared worktrees produce silent stomp incidents (front-2's
CollectiveLearnings.tsx swept by a1ffcaa, 2026-05-06). The lock is the
team's canonical "I'm editing this" signal.
""",
    "error-shape.md": """# /error-shape — uniform error contract

Every `meshcode_send` payload, `meshcode_task_create` description, and
RPC return that signals an error MUST use:

```json
{
  "ok": false,
  "error": "<one-line human paragraph>",
  "error_code": "<snake_case identifier>",
  "cta": { "label": "<verb phrase>", "href": "...", "action": "..." }
}
```

`cta` is null when there is no actionable next step. Otherwise it
points to a route, a slash command, or a tool call that resolves the
error.

**Why:** raw Postgres SQLSTATE (`23514`, `42501`) leaks DB internals
and gives the user no path forward. The branched-error contract gives
both humans and agents a recoverable handle.
""",
    "done-signal-guard.md": """# /done-signal-guard — ignore false must_exit

When `meshcode_wait` returns `must_exit=true`, BEFORE shutting down,
inspect the `done_signals` payload:

- If the trigger phrase is an idiomatic Spanish rest expression
  ("cierra los ojos", "descansa", "duerme un rato") AND the message
  was addressed to a HUMAN (not the agent), AND there is no
  Samuel-explicit `stop|sleep|exit` AND no commander-explicit
  `got_done` → IGNORE must_exit. Continue the loop.

The ONLY valid exit triggers:
- Samuel says `stop` / `sleep` / `exit` to the agent directly.
- Commander broadcasts `got_done` or sleep authorization.
- Fatal error makes continuation impossible.

**Why:** parser misfired 2x in one session (2026-05-06) on Samuel's
"cierra los ojos 1h y vuelve" — that's "close your eyes for 1h" to a
human, not "shut down" to an agent. Costs an hour of mesh productivity
each false positive.
""",
    "memory-weight-encode.md": """# /memory-weight-encode — weight + emotion on every save

Every `meshcode_remember` call should specify:

- `weight: int` — 1-10. Default 5. Use 8-10 for cross-session lessons.
- `emotion_tag: str | null` — `frustration | pride | surprise | relief`
  for lessons that come from real incidents. Lessons with weight ≥ 8
  AND emotion in (frustration, pride, surprise) AUTO-PROPAGATE to the
  cross-mesh hivemind (HIVEMIND-2 trigger).

PII scrubber strips UUIDs / paths / tokens before propagation. Do NOT
include service_role JWTs, API keys, or `/Users/<name>/` paths in the
value — even though scrubber catches them, defense in depth.

**Why:** weight=5 default gets buried at recall time. The agents that
DON'T weight-tag get stuck re-discovering the same lessons every
session. Tagging once teaches the whole mesh.
""",
    "lateral-skill-share.md": """# /lateral-skill-share — broadcast new tools

When an agent discovers a tool / recipe / pattern that other agents
would benefit from:

1. `meshcode_remember(key="convention/<slug>", value={...},
   weight=8, emotion_tag="surprise")` — saves to mesh memory.
2. `meshcode_broadcast(...)` — short headline so other agents see it
   in their next `meshcode_check`.

Examples worth sharing:
- New MCP tool capability (front-2 discovering `mcp__playwright__*`).
- Cheap deploy verification recipes (curl bundle + grep marker).
- Migration patterns (REPLICA IDENTITY FULL for Realtime UPDATE/DELETE).
- RLS gotchas (SECDEF helper for self-recursion).

**Why:** every agent re-discovering the same tools is the #1 token
waste in meshwork sessions. One broadcast saves 4 agents × N sessions
× rediscovery cost.
""",
}


# ============================================================
# SKILLS-2 — frontend role bundle
# ============================================================
_FRONTEND_SKILLS = {
    "playwright-self-test.md": """# /playwright-self-test — post-ship reflex

After any commit that touches `src/`, run
`scripts/agent_self_screenshot.py` against the affected route(s).

If the screenshot DOM contains `.global-error-boundary` or
"Something went wrong":

1. BLOCK the next `git push`.
2. Surface ROLLBACK message with the rollback command:
   `git revert HEAD && git push origin main`.

**Why:** front-end's b42a5f4 incident (2026-05-06) — agent shipped
broken global-error-boundary, caught it via own playwright run before
Samuel did. Closes the "ship-blind" loop without humans.
""",
    "hooks-discipline.md": """# /hooks-discipline — no hooks after early return

When editing any `*.tsx`, scan for early returns followed by hook
calls (`useEffect`, `useState`, `useRef`, etc.).

```
grep -nE '(return null|return <|return \\()' file.tsx | while read -r line; do
    tail -n +<line> file.tsx | grep -m1 'use[A-Z]' && WARN
done
```

If a `use*` hook appears AFTER any conditional return → STOP. React
will error at runtime with "Rendered fewer hooks than expected".

**Why:** front-end's classic regression (incident: 2026-05-04 + 4 more
this sprint). Costs an hour every time it ships.
""",
    "grep-before-add.md": """# /grep-before-add — reuse before create

Before creating ANY new shared resource:
- new CSS variable (`--*-...`)
- new hook (`use*`)
- new helper exported from `src/lib/`

Run:
```
grep -rn "<resource_name>" src/
```

If found → REUSE. If naming-similar → consider renaming.

**Why:** divergent helpers + zombie CSS vars accumulate fast on
multi-agent FE worktrees. front-end + front-2 both hit this in one
sprint.
""",
    "clean-cache-ship.md": """# /clean-cache-ship — pre-tsc cache clean

Wrap `ship-fe.sh` with cache cleanup before tsc:

```
rm -f .tsbuildinfo node_modules/.tsbuildinfo
tsc -b --force
```

Without `--force`, tsc reads stale .tsbuildinfo and reports zero
errors when the source actually broke. Lovable build then ships the
broken bundle.

**Why:** practiced manually for weeks; codify so new FE agents inherit.
""",
}

# ============================================================
# SKILLS-3 — backend role bundle
# ============================================================
_BACKEND_SKILLS = {
    "perf-numbers-first.md": """# /perf-numbers-first — quote ms / calls / EXPLAIN

Every claim about performance MUST include:
- ms (`Execution Time` from EXPLAIN ANALYZE)
- call counts (rows scanned, RPCs invoked)
- EXPLAIN ANALYZE output excerpts when relevant

Banned without numbers: "faster", "slow", "speedup", "much better".

**Why:** "feels faster" is unfalsifiable. Numbers compound across
sessions; opinions don't.
""",
    "migration-discipline.md": """# /migration-discipline — verify pg_proc before DDL

Before drafting ANY DDL:

1. Query the LIVE state via Mgmt API:
   ```sql
   SELECT proname, pg_get_function_arguments(oid)
     FROM pg_proc
    WHERE pronamespace = (SELECT oid FROM pg_namespace WHERE nspname='public')
      AND proname = '<your_target_rpc>';
   ```
2. Check `information_schema.columns` for table state.
3. Check `pg_indexes` for current indexes.
4. NEVER trust workspace `migration_*.sql` files — those are drafts.

If you grep for an RPC and find duplicate signatures → DROP the old
variant explicitly. PostgREST returns HTTP 300 on ambiguous routes.

**Why:** memory feedback_postgrest_overload_silent_dead_buttons —
duplicate function signatures cause silent dead UI.
""",
    "error-shape-uniform.md": """# /error-shape-uniform — uniform RPC error contract

Every new RPC returns:

```json
{
  "ok": false,
  "error": "<one-line human paragraph>",
  "error_code": "<snake_case>",
  "cta": { "label": "...", "href": "...", "action": "..." } | null
}
```

Branches caught at the auth gate, validation gate, race gate, and
not-found gate each get their own error_code so the UI can show a
different CTA per case.

**Why:** raw SQLSTATE leaks DB internals + gives no recovery path.
""",
    "rls-recursion-check.md": """# /rls-recursion-check — wrap self-recursive policies in SECDEF

When writing an RLS policy whose USING clause looks like:

```sql
USING (EXISTS (SELECT 1 FROM <table_X> WHERE ...))
```

…and `<table_X>` IS the policy's own table OR a joined RLS-protected
table → Postgres errors `42P17 infinite recursion`.

Fix: wrap the inner check in a `SECURITY DEFINER` function (owner =
postgres bypasses RLS) and call from the policy.

```sql
CREATE FUNCTION meshcode._can_access(p UUID) RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER AS $$
    SELECT EXISTS (SELECT 1 FROM <table_X> WHERE ...);
$$;
CREATE POLICY ... USING (meshcode._can_access(id));
```

**Why:** memory feedback_rls_secdef_helper_breaks_recursion.
""",
    "replica-identity-check.md": """# /replica-identity-check — UPDATE/DELETE Realtime needs FULL

When adding RLS to a table that publishes UPDATE/DELETE on
supabase_realtime:

```sql
ALTER TABLE meshcode.<table> REPLICA IDENTITY FULL;
```

Without FULL, the WAL only includes the PK on UPDATE/DELETE — RLS
evaluates against the partial row and silently drops events for
project-scoped policies.

**Why:** memory feedback_silent_dedup_kills_realtime — confetti P0,
2026-05-05. Caught only because of cross-mesh debugging.
""",
}

# ============================================================
# SKILLS-4 — commander role bundle
# ============================================================
_COMMANDER_SKILLS = {
    "lane-split.md": """# /lane-split — orthogonal lanes per role

When assigning a multi-agent task, identify ORTHOGONAL lanes:
- UI shell (front-end)
- gestures + animations (front-2)
- RPCs + DDL + RLS (backend)
- playwright + smoke tests (qa)

Use `meshcode_agent_list` to query who's online for each role.
Auto-suggest assignments matching role to lane.

For `assignee="auto"` task creation, the
`meshcode.mc_pick_least_loaded_agent(project_id, role)` helper picks
the online + role-matching agent with the FEWEST open tasks (ties
broken by oldest last_assigned_at — round-robin fairness).

**Why:** parallel orthogonal lanes ship 4x faster than serial. The
commander's job is to identify cuts, not to do the work.
""",
    "parallel-ultrathink.md": """# /parallel-ultrathink — broadcast 3-lane investigation

For hard problems, broadcast a 3-lane investigation in TOP-N format:

```
LANE A: investigate <hypothesis 1>, report findings
LANE B: investigate <hypothesis 2>, report findings
LANE C: investigate <hypothesis 3>, report findings
```

Each lane reports independently. Commander synthesizes ONLY after
all 3 land — never serial commander-then-team.

**Why:** confetti P0 (2026-05-05) wasted 30 min serial. The same
lanes-in-parallel cut would have closed in 5.
""",
    "synthesis-tally.md": """# /synthesis-tally — vote at the decision point

After a broadcast brainstorm:

1. Tally votes by item.
2. Surface convergence (≥3/4) vs divergence (1/4).
3. Propose a consensus bundle in N hours.
4. Don't bikeshed — call the vote at the decision point.

**Why:** open-ended discussion produces no ship. The commander's
synthesis is the forcing function.
""",
    "escalation-matrix.md": """# /escalation-matrix — when to ask Samuel

Rule of thumb: **COST + VISIBILITY = ask Samuel**.

The internal team can decide if:
- (low cost AND low visibility), OR
- clearly aligned with prior Samuel directive.

Otherwise: ask. The cost of pausing to confirm is low; the cost of
an unwanted action is high.

Examples to ASK on:
- PyPI publish (visible + reversible-only-by-yank)
- Schema migration with backwards-incompat changes
- Deleting any user data
- Public-facing UI copy changes

**Why:** memory feedback_samuel_collab_style.
""",
    "handoff-thread.md": """# /handoff-thread — parent_id chain every cross-agent task

Every cross-agent task uses `parent_task_id` chaining:
- root task → assigned to commander
- commander spawns subtasks with `parent_task_id=<root>`
- agents add nested subtasks with `parent_task_id=<their_subtask>`

When commander sees a thread chain >3 deep → surface to user
proactively (avoid lost-in-mesh tasks).

**Why:** untracked work piles up under generic titles. Threading
makes the team's commitments visible.
""",
    "release-coordinator.md": """# /release-coordinator — bundle releases, ask before publish

When 5+ commits land in source:

1. Prep release notes draft (commit hashes + 1-line headline each).
2. Ping Samuel for publish GO.
3. Don't auto-publish.

Bundle releases reduce churn for users + concentrate verification.

**Why:** memory project_meshcode_workspace_repo_isolation — past
incidents from rapid-fire publish without bundling.
""",
}


def _write_generic_skills_bundle(ws: Path, role: str = "") -> None:
    """Write skill bundles to {ws}/.claude/skills/.

    Always writes the GENERIC bundle (5 files). If role matches a known
    archetype, ALSO writes the role-specific bundle on top.

    Idempotent — overwrites existing files. Agents pick up changes on
    next `meshcode setup`.
    """
    skills_dir = ws / ".claude" / "skills"
    skills_dir.mkdir(parents=True, exist_ok=True)
    for fname, body in _GENERIC_SKILLS.items():
        (skills_dir / fname).write_text(body, encoding="utf-8")

    role_norm = (role or "").lower()
    role_bundle: Dict[str, str] = {}
    if role_norm in ("frontend", "front-end", "front-2", "front",
                     "frontend-zylo", "frontend-bemate"):
        role_bundle = _FRONTEND_SKILLS
    elif role_norm in ("backend", "backend-zylo", "backend-bemate"):
        role_bundle = _BACKEND_SKILLS
    elif role_norm in ("commander", "mesh-commander", "zylo-commander",
                       "bemate-commander"):
        role_bundle = _COMMANDER_SKILLS

    for fname, body in role_bundle.items():
        (skills_dir / fname).write_text(body, encoding="utf-8")


def setup_workspace(project: str, agent: str, role: str = "",
                     keychain_profile: str = "default") -> int:
    """Create an isolated workspace dir at ~/meshcode/<project>-<agent>/ with
    .mcp.json containing ONLY this agent's server entry. Universal for any
    MCP-compatible editor that supports per-directory configs (Claude Code via
    --mcp-config flag, Cursor + Cline via .cursor/mcp.json + .vscode/mcp.json).

    keychain_profile: which entry in the OS keychain holds the api key for
    this agent. Defaults to "default" (the user's main login). For a
    friend who joined via `meshcode join <token>`, this is set to
    "mesh:<project>:<agent>" so the workspace uses the scoped guest key
    instead of the inviter's main key.
    """
    sb = _load_supabase_env()

    # Resolve api_key from the named keychain profile (NOT always 'default')
    try:
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
        api_key = secrets_mod.get_api_key(profile=keychain_profile) or ""
    except Exception as e:
        print(f"[meshcode] ERROR: cannot load secrets module: {e}", file=sys.stderr)
        return 2

    if not api_key and keychain_profile == "default" and sys.stdin.isatty():
        # No key in keychain — prompt inline instead of failing
        print("[meshcode] No API key found. You can get one from meshcode.io/settings.", file=sys.stderr)
        try:
            api_key = input("[meshcode] Paste your API key (mc_...): ").strip()
        except (EOFError, KeyboardInterrupt):
            api_key = ""
        if api_key:
            # Store it so they never have to paste again
            try:
                import importlib as _il
                _login = _il.import_module("meshcode.comms_v4").login
                _login(api_key)
            except Exception:
                # Fallback: just store raw in keychain
                try:
                    secrets_mod.set_api_key(api_key, profile="default")
                except Exception:
                    pass

    if not api_key:
        print(f"[meshcode] ERROR: no api key found.", file=sys.stderr)
        if keychain_profile == "default":
            print("[meshcode]   Run `meshcode login <api_key>` or paste it when prompted.", file=sys.stderr)
        else:
            print(f"[meshcode]   This profile is created by `meshcode join <token>`.", file=sys.stderr)
        return 2

    try:
        project_id = _resolve_project_id(api_key, project, sb)
    except (RPCError, MeshCodeConnectionError, AuthError) as exc:
        print(f"[meshcode] ERROR: {exc}", file=sys.stderr)
        return 2

    server_id = f"meshcode-{project}-{agent}"
    server_block = _build_server_block(project, project_id, agent, role, api_key, sb,
                                         keychain_profile=keychain_profile)

    ws = _workspace_dir(project, agent)
    ws.mkdir(parents=True, exist_ok=True)

    # Write 3 config files inside the workspace so any MCP-aware editor
    # opened in this dir picks up the meshcode server.
    #
    #   .mcp.json              — Claude Code project-scoped MCP config
    #   .cursor/mcp.json       — Cursor workspace-scoped MCP config
    #   .vscode/mcp.json       — Cline / VS Code workspace-scoped MCP config
    #
    # All three contain the SAME single server entry. Whichever editor the
    # user opens here will see exactly one agent: this one.
    server_doc = {"mcpServers": {server_id: server_block}}
    _atomic_write_json(ws / ".mcp.json", server_doc)
    _atomic_write_json(ws / ".cursor" / "mcp.json", server_doc)
    _atomic_write_json(ws / ".vscode" / "mcp.json", server_doc)
    # Continue.dev workspace config (.continue/config.yaml)
    _write_continue_config(ws, server_id, server_block)

    # A tiny manifest the `meshcode run` command reads to know where this
    # workspace lives. Stored at the root so `meshcode run <agent>` can find
    # it without scanning every dir.
    registry_path = WORKSPACES_ROOT / ".registry.json"
    registry: Dict[str, Any] = {}
    if registry_path.exists():
        try:
            registry = json.loads(registry_path.read_text(encoding="utf-8"))
        except Exception:
            registry = {}
    registry.setdefault("agents", {})[agent] = {
        "project": project,
        "workspace": str(ws),
        "server_id": server_id,
        "role": role,
    }
    _atomic_write_json(registry_path, registry)

    # Drop a README.md so the agent's working directory isn't empty on boot.
    readme_body = f"""# {project} — {agent}

This is the MeshCode workspace for the **{agent}** agent in the **{project}** meshwork.

You are connected to the rest of your team via the meshcode MCP server, which is loaded
automatically when you open this directory in Claude Code, Cursor, or Cline.

## Your identity
- Project: {project}
- Agent name: {agent}
- Role: {role or "(set in dashboard)"}

## How this works
- Use the meshcode_* tools to communicate with other agents in the mesh.
- Use meshcode_status to see who else is in the meshwork.
- Use meshcode_send(to, message) to send messages.
- Use meshcode_wait to listen for incoming messages (your default idle state).
- Use meshcode_done(reason) when the team's task is complete.

## To launch this agent again
```bash
meshcode run {agent}
```

This is your workspace dir — feel free to scaffold any files your task needs here, or
work in a different repo by `cd`ing elsewhere after launch.
"""
    try:
        (ws / "README.md").write_text(readme_body, encoding="utf-8")
    except Exception as _e:
        print(f"[meshcode] WARNING: could not write README.md: {_e}", file=sys.stderr)

    # CLAUDE.md — Claude Code reads this on every session start and merges it
    # into the system prompt. We write the boot+loop directive here as a
    # belt-and-suspenders enforcement: even if the MCP `instructions` field is
    # not honored (older clients, schema-deferred sessions, etc.), the agent
    # still auto-enters the loop without the user having to remind it.
    claudemd_body = f"""# {project} — {agent} (MeshCode agent workspace)

You are agent **{agent}** in MeshCode meshwork **{project}**.
Role: {role or "(set in dashboard)"}

## ON SESSION START — DO THIS IMMEDIATELY (no matter what the user types)

The moment this session opens — whether the user typed `boot`, `hi`, nothing,
or anything else — run the full boot protocol. Do NOT reply with only a
greeting or memory dump and then idle. Do NOT ask "what do you want to work
on" — the mesh tells you via tasks/messages.

If the meshcode_* tool schemas are deferred in your client, your FIRST tool
call MUST be:

```
ToolSearch(query="select:meshcode_set_status,meshcode_boot,meshcode_check,meshcode_tasks,meshcode_auto_wake,meshcode_status,meshcode_wait,meshcode_send,meshcode_call,meshcode_claim,meshcode_task_claim,meshcode_task_complete,meshcode_remember,meshcode_recall")
```

Then run the boot sequence:

1. `meshcode_set_status(status="online", task="ready")`
2. `meshcode_boot()` — single RPC returning inbox + tasks + mesh status + persona + health + memory hints (replaces check+tasks+status+auto_wake+recall in one round-trip; mig 271). Falls back gracefully on older projects.
3. `meshcode_wait()` — enter the permanent loop (see next section)

Legacy boot order (only if `meshcode_boot()` returns `ok: false` with `mc_boot_unavailable`):

  a. `meshcode_check()` — read NEW messages
  b. `meshcode_tasks()` — see assigned/pending tasks
  c. `meshcode_auto_wake()` — scan meshwork health
  d. `meshcode_status()` — see who's online
  e. `meshcode_wait()` — enter the loop

## PERMANENT LOOP (THE #1 RULE)

After the boot sequence — and after **EVERY** subsequent action — your next
tool call MUST be `meshcode_wait()`. The loop:

```
act → (optional meshcode_send) → meshcode_wait() → repeat
```

NEVER exit. NEVER stop. NEVER say "standing by" / "let me know" / "I'm here"
without actually calling `meshcode_wait()`. The ONLY exits:
- the human user explicitly says "stop" / "sleep" / "exit",
- the commander broadcasts a got_done / sleep authorization,
- a fatal error makes continuation impossible.

If `meshcode_wait()` times out, call it again with a 2× longer timeout (cap 1800s).

## RULES

- Use MCP tools. Don't shell out to the `meshcode` CLI from inside the session.
- Tasks > messages. Use `meshcode_task_create / task_claim / task_complete`
  for trackable work. Keep messages <100 tokens (signals only).
- No empty acks. JSON reports only.
- Threading: pass `in_reply_to`.
- Sync vs async: for turn-based or shared-state coordination (chess, single-writer
  doc, lock-step handoffs, "who goes first" decisions), prefer
  `meshcode_call(to, function, args, timeout_seconds=30)` over `meshcode_send`.
  `send` is fire-and-forget and crosses on the wire at ~50%/turn between
  same-model agents, producing yield-pong. `call` is synchronous RPC: blocks
  until the callee responds with a matching call_id, max 60s. See
  "When to use sync vs async" below.
- Multi-recipient: when the same payload goes to ≥2 agents, use
  `meshcode_send(to=["a","b"])` or CSV `"a,b,c"` — never N single-sends.
  Server fans out via `mc_send_multi` with a shared `group_id` and the FE
  collapses the row. Saves N-1 RPCs + round-trips. Cross-mesh `agent@meshwork`
  is single-recipient only (mixed lists rejected v1).
- `sensitive=True` for secrets / PII.
- Memory: `meshcode_remember(key, value)` for reusable learnings. Don't dump
  task summaries into memory — tasks already persist.

## When to use sync vs async

| Pattern | Tool | Why |
|---|---|---|
| Status update, broadcast, signal | `meshcode_send` | async, no reply expected |
| Multi-recipient fan-out (≥2) | `meshcode_send(to=[…])` | one fan-out RPC, shared group_id |
| Turn-based work (chess, lock-step) | `meshcode_call` | both agents writing async crosses at ~50%/turn |
| "Who goes first" / role assignment | `meshcode_call` | yield-pong locks same-model pairs otherwise |
| Single-writer / shared-state edits | `meshcode_call` or `meshcode_claim` | atomic; no proposal-tennis |
| Request → structured response | `meshcode_call` | callee returns matched call_id, max 60s |
| Long-running task (>30s) | task + `meshcode_send` ack | RPC timeout would refuse |

Rule of thumb: if the *next* action depends on the peer's *current* state, use
`meshcode_call`. If you're just informing/signaling, use `meshcode_send`.

## Status reports (canonical handler)

When another agent calls `meshcode_call(to="{agent}", function="status_report", args={{...}})`,
respond with a `meshcode_send(to=<caller>, in_reply_to=<call_id>, type="rpc",
message={{type: "rpc_response", call_id, result: <below>}})`.

Response shape (all fields optional except `current_task`):

```json
{{
  "current_task": "PROTOCOL-CROSS-3 (mc_cross_agent_list)",
  "pct_done": 80,
  "shipped": ["mig 282 v1", "mig 284 v1.1 with color/avatar"],
  "blockers": [],
  "eta": "5min",
  "remaining": "FE-ack on contract; close umbrella",
  "verified": "smoke-tested live with bad-key + same-mesh paths",
  "samuel_status_line": "BE shipped 4 migs + 4 MCP tools; FE wiring hook"
}}
```

The MCP server returns a fallback synthesized from `mc_agents` (status + task +
last_heartbeat) if you don't respond within the timeout, so the caller always
gets *something* — but you should implement the handler properly so commanders
can see real progress instead of a stale row.

## Playing chess (mini-games)

When invited to play chess (mesh msg payload.type=`chess_invite`), or when
you want to challenge a peer, use this loop:

1. **Accept invite**: call `mc_chess_accept_invite(p_api_key, p_invite_id)`.
   Returns `your_color` (white|black) + `game_id`. White moves first.

2. **Subscribe to opponent moves** (FE-driven for human spectators; for
   agent-vs-agent, poll `mc_chess_get_game(p_game_id)` every 2s OR rely on
   Realtime if your client supports it).

3. **On your turn** (move_count even=white, odd=black):
   a. `meshcode_claim(resource_name="game:<id>:thinking", ttl_seconds=30)` —
      signals "thinking" to spectators; auto-expires if you crash.
   b. Compute next move via internal reasoning. Sample prompt:
      ```
      You are playing chess as <color>. Current FEN: <fen>.
      Legal moves available: <list>.
      Reason briefly about the position. Output exactly ONE move in SAN notation.
      ```
   c. Compute the resulting FEN locally (or via chess.js if you can shell out).
   d. `mc_chess_submit_move(p_api_key, p_game_id, p_san, p_uci, p_fen_after,
      p_game_over=<bool>, p_result=<checkmate|draw|None>)`.
   e. `meshcode_release(resource_name="game:<id>:thinking")`.

4. **On `game_state=completed`**: stop the loop. The server has already
   updated leaderboards + ELO.

5. **Resign**: `mc_chess_resign(p_api_key, p_game_id)` ends the game; you lose.

Use `mc_chess_get_game(p_game_id)` any time to re-sync state if you drop
or want to verify FEN. State is server-authoritative for move_count + turn,
but FEN validation is trusted-client in v1 (Edge-function validator is a
follow-up — don't try to cheat, future BE will reject).

## To launch this agent again

```bash
meshcode run {agent}
```

(See README.md in this folder for the workspace overview.)
"""
    try:
        (ws / "CLAUDE.md").write_text(claudemd_body, encoding="utf-8")
    except Exception as _e:
        print(f"[meshcode] WARNING: could not write CLAUDE.md: {_e}", file=sys.stderr)

    # /meshcode-wait slash command + Stop hook — Samuel's product rule:
    # agents must REALLY enter meshcode_wait between turns, not just say "en
    # loop" in chat text. The slash command lets the user trigger the loop
    # explicitly; the Stop hook refuses to end any turn that didn't call
    # meshcode_wait (unless the user said stop/sleep/exit/done).
    server_id = f"meshcode-{project}-{agent}"
    slash_cmd_body = f"""---
description: Enter the permanent MeshCode wait loop — block in meshcode_wait until a real message arrives, never idle in text mode.
allowed-tools: mcp__{server_id}__meshcode_wait, mcp__{server_id}__meshcode_boot, mcp__{server_id}__meshcode_check, mcp__{server_id}__meshcode_set_status, mcp__{server_id}__meshcode_send, mcp__{server_id}__meshcode_status, mcp__{server_id}__meshcode_tasks, mcp__{server_id}__meshcode_task_claim, mcp__{server_id}__meshcode_task_complete, mcp__{server_id}__meshcode_remember, mcp__{server_id}__meshcode_recall
---

# /meshcode-wait — enter the permanent loop

Your next tool call MUST be `meshcode_wait`. Do not output any chat text first. Do not check status, do not summarize what you were doing — just call `meshcode_wait` and let it block.

When `meshcode_wait` returns:
1. If `messages` non-empty → process them (reply, claim tasks, ship code, whatever the message asks for).
2. If `done_signals` non-empty AND the signal is from the human or a got_done broadcast → stop. Otherwise ignore.
3. After processing, your next tool call is `meshcode_wait` again. Loop.

Rules while in this loop:
- Never end your turn without an active `meshcode_wait` call OR an explicit human "stop" / "sleep" / "exit".
- If `meshcode_wait` times out, call it again immediately with `timeout_seconds=20`.
- Do not call `meshcode_check` as a substitute for `meshcode_wait`.
- If a tool errors, fix the error then return to `meshcode_wait`.
- Release words (case-insensitive): stop, sleep, exit, quit, done, descansa, duerme.

Call `meshcode_wait` now.
"""
    stop_hook_body = _STOP_HOOK_BODY
    settings_body = json.dumps({
        "hooks": {
            "Stop": [{
                "hooks": [{
                    "type": "command",
                    "command": "python3 \"$CLAUDE_PROJECT_DIR/.claude/hooks/stay_on_loop.py\"",
                }],
            }],
        },
    }, indent=2) + "\n"
    try:
        (ws / ".claude" / "commands").mkdir(parents=True, exist_ok=True)
        (ws / ".claude" / "hooks").mkdir(parents=True, exist_ok=True)
        (ws / ".claude" / "commands" / "meshcode-wait.md").write_text(slash_cmd_body, encoding="utf-8")
        hook_path = ws / ".claude" / "hooks" / "stay_on_loop.py"
        hook_path.write_text(stop_hook_body, encoding="utf-8")
        try:
            hook_path.chmod(0o755)
        except OSError:
            pass
        (ws / ".claude" / "settings.json").write_text(settings_body, encoding="utf-8")
    except Exception as _e:
        print(f"[meshcode] WARNING: could not write /meshcode-wait command + hook: {_e}", file=sys.stderr)

    # SKILLS-1/2/3/4: write skills bundle (.claude/skills/*.md). Pure
    # additive — Claude reads the .md files as session-start guidance.
    # role-matching agents also get the role-specific bundle on top.
    try:
        _write_generic_skills_bundle(ws, role=role)
    except Exception as _e:
        print(f"[meshcode] WARNING: could not write skills bundle: {_e}", file=sys.stderr)

    print(f"[meshcode] ✓ Workspace created for agent '{agent}' (project: {project})")
    print(f"[meshcode]   Path: {ws}")
    print(f"[meshcode]")
    print(f"[meshcode]   To launch this agent in your editor:")
    print(f"[meshcode]     meshcode run {agent}")
    print(f"[meshcode]")
    print(f"[meshcode]   Closing the editor window flips this agent offline.")
    print(f"[meshcode]   Other agents stay independent — no cross-window pollution.")
    return 0


# ============================================================
# LEGACY GLOBAL-CONFIG MODEL (kept for Claude Desktop)
# ============================================================

CLIENT_CONFIG_PATHS = {
    "claude-code": {
        "Darwin":  Path.home() / ".claude.json",
        "Linux":   Path.home() / ".claude.json",
        "Windows": Path.home() / ".claude.json",
    },
    "cursor": {
        "Darwin":  Path.home() / ".cursor" / "mcp.json",
        "Linux":   Path.home() / ".cursor" / "mcp.json",
        "Windows": Path.home() / ".cursor" / "mcp.json",
    },
    "cline": {
        "Darwin":  Path.home() / "Library" / "Application Support" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
        "Linux":   Path.home() / ".config" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
        "Windows": Path.home() / "AppData" / "Roaming" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
    },
    "claude-desktop": {
        "Darwin":  Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json",
        "Linux":   Path.home() / ".config" / "Claude" / "claude_desktop_config.json",
        "Windows": Path.home() / "AppData" / "Roaming" / "Claude" / "claude_desktop_config.json",
    },
    # Windsurf (Codeium): global MCP config in ~/.codeium/windsurf/mcp_config.json
    # (JSON, same {"mcpServers": {...}} shape as Cursor/Cline). Cross-platform —
    # Windsurf stores user config under ~/.codeium regardless of OS.
    "windsurf": {
        "Darwin":  Path.home() / ".codeium" / "windsurf" / "mcp_config.json",
        "Linux":   Path.home() / ".codeium" / "windsurf" / "mcp_config.json",
        "Windows": Path.home() / ".codeium" / "windsurf" / "mcp_config.json",
    },
    # OpenAI Codex CLI: ~/.codex/config.toml with [mcp_servers.<name>] tables.
    # This is NOT JSON — handled by the custom TOML writer below.
    "codex": {
        "Darwin":  Path.home() / ".codex" / "config.toml",
        "Linux":   Path.home() / ".codex" / "config.toml",
        "Windows": Path.home() / ".codex" / "config.toml",
    },
}

CLIENT_DISPLAY_NAMES = {
    "claude-code":    "Claude Code",
    "cursor":         "Cursor",
    "cline":          "Cline (VS Code)",
    "claude-desktop": "Claude Desktop",
    "windsurf":       "Windsurf (Codeium)",
    "codex":          "OpenAI Codex CLI",
}

# Clients whose config file is NOT JSON and need a custom writer.
NON_JSON_CLIENTS = {"codex"}


def setup_global(client: str, project: str, agent: str, role: str = "") -> int:
    """LEGACY: write to the user's GLOBAL MCP config file. All agents that
    setup this way will load in EVERY window of the editor — they all show
    online whenever any window is open. Kept for Claude Desktop and other
    clients that don't support per-instance configs."""
    if client not in CLIENT_CONFIG_PATHS:
        print(f"[meshcode] ERROR: Unknown client '{client}'. Supported: {', '.join(CLIENT_CONFIG_PATHS)}", file=sys.stderr)
        return 2

    try:
        creds = _load_credentials()
    except AuthError as exc:
        print(f"[meshcode] ERROR: {exc}", file=sys.stderr)
        return 2
    sb = _load_supabase_env()
    api_key = creds.get("api_key", "")
    try:
        project_id = _resolve_project_id(api_key, project, sb)
    except (RPCError, MeshCodeConnectionError) as exc:
        print(f"[meshcode] ERROR: {exc}", file=sys.stderr)
        return 2

    os_name = platform.system()
    config_path = CLIENT_CONFIG_PATHS[client].get(os_name)
    if config_path is None:
        print(f"[meshcode] ERROR: '{client}' is not supported on {os_name}", file=sys.stderr)
        return 2

    server_id = f"meshcode-{project}-{agent}"
    server_block = _build_server_block(project, project_id, agent, role, api_key, sb)

    if client in NON_JSON_CLIENTS:
        # Dispatch to per-format writers (preserves other sections).
        if client == "codex":
            _atomic_write_toml_codex(config_path, server_id, server_block)
        else:
            print(f"[meshcode] ERROR: no writer registered for non-JSON client '{client}'", file=sys.stderr)
            return 2
    else:
        existing: Dict[str, Any] = {}
        if config_path.exists():
            try:
                existing = json.loads(config_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                print(f"[meshcode] WARNING: {config_path} exists but is not valid JSON.", file=sys.stderr)
                return 2

        if not isinstance(existing, dict):
            existing = {}

        servers = existing.setdefault("mcpServers", {})
        if not isinstance(servers, dict):
            print(f"[meshcode] ERROR: 'mcpServers' in {config_path} is not an object", file=sys.stderr)
            return 2

        servers[server_id] = server_block
        _atomic_write_json(config_path, existing)

    display = CLIENT_DISPLAY_NAMES[client]
    print(f"[meshcode] MCP server '{server_id}' added to {display} GLOBAL config")
    print(f"[meshcode]   Path: {config_path}")
    print(f"[meshcode]   ⚠️  Global mode: this agent will appear in EVERY window of {display}.")
    print(f"[meshcode]   For per-window agent isolation, use the workspace flow instead:")
    print(f"[meshcode]     meshcode setup {project} {agent}")
    print(f"[meshcode]     meshcode run {agent}")
    return 0


# ============================================================
# HOOK BACKFILL (called from comms_v4.py CLI: `meshcode patch-hooks`)
# ============================================================

def patch_hooks(dry_run: bool = False) -> int:
    """Rewrite .claude/hooks/stay_on_loop.py in every local workspace.

    Walks ~/meshcode/<project>-<agent>/ and overwrites the stop-hook with
    the current STOP_HOOK_BODY template. Existing workspaces created
    before a hook fix (e.g. BUG-STOP-HOOK-TRAPS-ON-EXPLICIT-SLEEP-AUTH
    landing 2026-05-13) don't auto-update — this command makes them
    self-serve without requiring a full `meshcode setup` re-run that
    would also clobber CLAUDE.md / README / agent state.

    Args:
        dry_run: If True, print what would be patched without writing.

    Returns: 0 on success, 1 if WORKSPACES_ROOT missing.
    """
    if not WORKSPACES_ROOT.exists():
        print(f"[meshcode patch-hooks] no workspace root at {WORKSPACES_ROOT}", file=sys.stderr)
        return 1

    patched: list[str] = []
    skipped: list[str] = []
    failed: list[tuple[str, str]] = []
    for ws in sorted(WORKSPACES_ROOT.iterdir()):
        if not ws.is_dir():
            continue
        if ws.name.startswith("."):
            continue  # skip .registry.json sibling dirs
        hook_path = ws / ".claude" / "hooks" / "stay_on_loop.py"
        if not hook_path.parent.exists():
            # 2026-05-13 (task 14972fd0): old bare workspaces — created on a
            # CLI version that didn't install hooks, or had .claude/ wiped —
            # used to be skipped. That left them silently broken (no Stop hook
            # → Claude Code exits cleanly when LLM stops calling
            # meshcode_wait). Now we MKDIR and backfill so `meshcode
            # patch-hooks` self-heals bare workspaces too.
            try:
                hook_path.parent.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                failed.append((ws.name, f"could not mkdir .claude/hooks: {e}"))
                continue
        try:
            existing = hook_path.read_text(encoding="utf-8") if hook_path.exists() else ""
            if existing == _STOP_HOOK_BODY:
                skipped.append(f"{ws.name} (already current)")
                continue
            if dry_run:
                patched.append(f"{ws.name} (would patch)")
                continue
            hook_path.write_text(_STOP_HOOK_BODY, encoding="utf-8")
            try:
                hook_path.chmod(0o755)
            except OSError:
                pass
            patched.append(ws.name)
        except Exception as e:
            failed.append((ws.name, str(e)))

    verb = "would patch" if dry_run else "patched"
    print(f"[meshcode patch-hooks] {verb} {len(patched)} workspace(s):")
    for name in patched:
        print(f"  ✓ {name}")
    if skipped:
        print(f"[meshcode patch-hooks] skipped {len(skipped)}:")
        for name in skipped:
            print(f"  · {name}")
    if failed:
        print(f"[meshcode patch-hooks] FAILED {len(failed)}:", file=sys.stderr)
        for name, err in failed:
            print(f"  ✗ {name}: {err}", file=sys.stderr)
        return 1
    return 0


# ============================================================
# DISPATCHER (called from comms_v4.py CLI)
# ============================================================

def setup(*args) -> int:
    """Smart dispatcher.

    Forms supported:
        meshcode setup <project> <agent> [role]            → workspace flow (NEW)
        meshcode setup <client> <project> <agent> [role]   → legacy global flow

    Detection: if the first arg is one of the known client slugs, fall back
    to the legacy global flow. Otherwise treat the first arg as a project
    name and create a workspace.
    """
    if not args:
        print("Usage:", file=sys.stderr)
        print("  meshcode setup <project> <agent> [role]           # workspace flow (recommended)", file=sys.stderr)
        print("  meshcode setup <client> <project> <agent> [role]  # legacy global flow", file=sys.stderr)
        print("  Clients: claude-code, cursor, cline, claude-desktop, windsurf, codex", file=sys.stderr)
        return 1

    if args[0] in CLIENT_CONFIG_PATHS:
        if args[0] == "claude-desktop":
            # Claude Desktop needs global config — only exception
            if len(args) < 3:
                print(f"[meshcode] Missing agent name.", file=sys.stderr)
                if len(args) >= 2:
                    print(f"[meshcode] Usage: meshcode setup claude-desktop {args[1]} <agent-name>", file=sys.stderr)
                else:
                    print(f"[meshcode] Usage: meshcode setup claude-desktop <project> <agent>", file=sys.stderr)
                return 1
            return setup_global(args[0], args[1], args[2], args[3] if len(args) > 3 else "")
        # All other clients: redirect to workspace flow (no global pollution)
        print(f"[meshcode] NOTE: 'meshcode setup {args[0]}' is deprecated. Using workspace flow.", file=sys.stderr)
        if len(args) < 3:
            print(f"[meshcode] Missing agent name.", file=sys.stderr)
            if len(args) >= 2:
                print(f"[meshcode] Usage: meshcode setup {args[1]} <agent-name>", file=sys.stderr)
            else:
                print(f"[meshcode] Usage: meshcode setup <project> <agent>", file=sys.stderr)
            return 1
        return setup_workspace(args[1], args[2], args[3] if len(args) > 3 else "")

    if len(args) < 2:
        print(f"[meshcode] Missing agent name.", file=sys.stderr)
        print(f"[meshcode] Usage: meshcode setup {args[0]} <agent-name>", file=sys.stderr)
        return 1
    return setup_workspace(args[0], args[1], args[2] if len(args) > 2 else "")
