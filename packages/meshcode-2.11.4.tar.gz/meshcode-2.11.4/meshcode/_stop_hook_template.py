"""Stop hook template — single source of truth for stay_on_loop.py.

Extracted from setup_clients.py 2026-05-13 to enable `meshcode patch-hooks`
to rewrite existing workspaces with the latest hook logic (BUG-STOP-HOOK-
TRAPS-ON-EXPLICIT-SLEEP-AUTH, task 60565831). Single source means future
hook fixes only edit this file; setup_workspace + patch-hooks both read it.
"""

STOP_HOOK_BODY = '''#!/usr/bin/env python3
"""Stop hook: refuse to end the agent's turn unless one of:
(a) the last user message contains a release keyword,
(b) the last assistant turn already called meshcode_wait,
(c) the most recent meshcode_wait tool_result authorized exit
    (must_exit=True OR done_signals non-empty OR a sammybenu mesh
    message contains a release keyword in payload.text), or
(d) the MCP server itself is unreachable (errored wait results, or
    ToolSearch found no meshcode_wait — agent has no way to call it).

Samuel directive 2026-04-30 — agents kept saying "en loop" without actually
entering meshcode_wait, so the loop only existed in chat text. This hook
forces the agent to make a real meshcode_wait tool call before its turn
can stop.

Bug-fix 2026-05-05 (condition c): mesh broadcasts and direct sleep-
authorization done_signals were getting blocked — the agent set
status=sleeping then ended the turn, but neither (a) nor (b) matched, so
the hook trapped the agent in an infinite block-loop. Now any explicit
must_exit=True or non-empty done_signals from the latest wait result
releases the agent.

Bug-fix 2026-05-08 (condition d, PROTO-MCP-UNREACHABLE-RELEASE, task
d2bdc974): when the MCP server drops mid-session, stay_on_loop kept
demanding meshcode_wait but the tool was de-registered → agent printed
"Type stop." infinitely until the human typed stop/sleep/exit/done.
Now we probe the transcript for evidence the tool is unreachable
(errored tool_result OR ToolSearch miss) and release with mcp_unreachable.

Bug-fix 2026-05-08b (condition d extended, mesh-commander launch fail):
the prior detection only matched if the agent (a) called meshcode_wait
and got an error or (b) ran ToolSearch select:meshcode_wait and got
"no matching deferred tools found". Failed when the agent observed MCP
absence via system-reminder before ever attempting either tool — Samuel
reported commander trapped in this exact path. Two new release paths:
  (1) latest <system-reminder> deferred-tool listing enumerates mcp__
      entries but ZERO meshcode_* entries → MCP not registered.
  (2) latest user-typed message names MCP failure ("mcp server fail",
      "mcp no esta conectado", "mcp no esta cargado", "mcp not
      connected") → human-confirmed unreachable.
"""
import json
import sys
from pathlib import Path

RELEASE_WORDS = (
    "stop", "sleep", "exit", "quit", "done",
    "duerme", "descansa", "dormir", "quedate dormido", "se acab",
    "got_done",
)

# Known human-user handles. Used as a back-compat fallback when the server
# hasn't stamped `sender_role="human_user"` on the message payload. Keep
# tight — these names get release-keyword power in mesh broadcasts.
# Server-side fix is to populate sender_role; this set is the safety net.
_KNOWN_HUMAN_HANDLES = frozenset({
    "sammybenu", "samuel", "sam",
})

WAIT_TOOL_SUFFIX = "meshcode_wait"

# Tail-window for the unreachable probe. 40 records covers the typical
# boot + first few wait cycles without scanning the entire transcript.
_UNREACHABLE_LOOKBACK = 40

# Substrings in tool_result text that indicate MCP-side death. Matched
# case-insensitively. Keep the list tight — false positives here
# release the loop early.
_MCP_DEAD_MARKERS = (
    "no such tool",
    "connection closed",
    "no matching deferred tools found",
    "mcp server",
    "mcp error",
)

# Substrings in a system-reminder that indicate a deferred-tool listing
# is being shown to the agent. Used to find the latest tool-availability
# snapshot in the transcript.
_DEFERRED_LISTING_MARKERS = (
    "the following deferred tools are now available",
    "deferred tools are now available via toolsearch",
)

# Substrings in a user-typed message indicating the human observed MCP
# failure. All matched case-insensitively; presence of any → release.
# Kept tight: each phrase explicitly names MCP + a failure verb so we
# don't false-positive on casual mentions.
_USER_MCP_FAIL_PHRASES = (
    "mcp server fail",
    "mcp server failed",
    "mcp no esta conectado",
    "mcp no está conectado",
    "mcp no esta cargado",
    "mcp no está cargado",
    "mcp not connected",
    "mcp failed at launch",
    "mcp unreachable",
    "meshcode mcp not",
    "el mcp de meshcode no",
)


def _rec_role_content(rec):
    """Extract (role, content) from a Claude Code transcript record.

    Claude Code wraps user/assistant payloads in `rec["message"]` since the
    schema migration; older parsers that read top-level `rec["role"]` /
    `rec["content"]` MISS every record and silently never fire. Normalize
    here so every helper sees the canonical shape. Falls back to top-level
    keys for forward compat with hypothetical older transcripts.
    """
    if not isinstance(rec, dict):
        return None, None
    msg = rec.get("message")
    if isinstance(msg, dict):
        return msg.get("role"), msg.get("content")
    return rec.get("role"), rec.get("content")


def _last_user_message(transcript_path):
    try:
        last = ""
        with transcript_path.open() as f:
            for line in f:
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                role, content = _rec_role_content(rec)
                if role == "user":
                    if isinstance(content, str):
                        last = content
                    elif isinstance(content, list):
                        # Skip tool_result-only user turns; we want the human's text.
                        text_parts = [
                            p.get("text", "")
                            for p in content
                            if isinstance(p, dict) and p.get("type") == "text"
                        ]
                        if text_parts:
                            last = " ".join(text_parts)
        return last
    except (OSError, FileNotFoundError):
        return ""


def _last_assistant_turn_called_wait(transcript_path):
    try:
        records = []
        with transcript_path.open() as f:
            for line in f:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        last_assistant_blocks = []
        for rec in reversed(records):
            role, content = _rec_role_content(rec)
            if role == "user":
                if last_assistant_blocks:
                    break
                continue
            if role == "assistant":
                if isinstance(content, list):
                    last_assistant_blocks.extend(content)
                elif isinstance(content, dict):
                    last_assistant_blocks.append(content)
        for block in last_assistant_blocks:
            if not isinstance(block, dict):
                continue
            if block.get("type") == "tool_use":
                name = str(block.get("name", ""))
                if name.endswith(WAIT_TOOL_SUFFIX):
                    return True
        return False
    except (OSError, FileNotFoundError):
        return False


def _latest_wait_result_authorizes_exit(transcript_path):
    """Walk transcript backwards. Find the most recent meshcode_wait
    tool_use → match its tool_result by tool_use_id → if the parsed
    result has must_exit=True or non-empty done_signals, return True.
    """
    try:
        records = []
        with transcript_path.open() as f:
            for line in f:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue

        wait_use_ids = set()
        for rec in records:
            role, content = _rec_role_content(rec)
            if role != "assistant":
                continue
            blocks = content if isinstance(content, list) else [content] if isinstance(content, dict) else []
            for block in blocks:
                if not isinstance(block, dict):
                    continue
                if block.get("type") == "tool_use" and str(block.get("name", "")).endswith(WAIT_TOOL_SUFFIX):
                    use_id = block.get("id")
                    if use_id:
                        wait_use_ids.add(use_id)

        if not wait_use_ids:
            return False

        for rec in reversed(records):
            role, content = _rec_role_content(rec)
            if role != "user":
                continue
            blocks = content if isinstance(content, list) else [content] if isinstance(content, dict) else []
            for block in blocks:
                if not isinstance(block, dict):
                    continue
                if block.get("type") != "tool_result":
                    continue
                if block.get("tool_use_id") not in wait_use_ids:
                    continue
                inner = block.get("content")
                text = ""
                if isinstance(inner, str):
                    text = inner
                elif isinstance(inner, list):
                    text = " ".join(
                        p.get("text", "") for p in inner
                        if isinstance(p, dict) and p.get("type") == "text"
                    )
                if not text:
                    continue
                try:
                    parsed = json.loads(text)
                except json.JSONDecodeError:
                    continue
                payload = parsed.get("result", parsed) if isinstance(parsed, dict) else parsed
                if not isinstance(payload, dict):
                    continue
                if payload.get("must_exit") is True:
                    return True
                signals = payload.get("done_signals")
                if isinstance(signals, list) and signals:
                    return True
                # Condition (e) — 2026-05-08, extended 2026-05-13: a mesh
                # broadcast / message from a HUMAN USER containing a release
                # keyword counts as a sleep authorization. Without this branch,
                # `meshcode_broadcast("pueden exit y dormir")` leaves the agent
                # trapped because the keyword never entered the Claude Code
                # transcript as user-typed text.
                #
                # 2026-05-13 (BUG-STOP-HOOK-TRAPS-ON-EXPLICIT-SLEEP-AUTH,
                # task 60565831): widened beyond the hardcoded "sammybenu"
                # check. wren@justforfun was trapped because Samuel's mesh
                # handle in justforfun isn't "sammybenu". New scoping:
                #   (1) sender_role == "human_user" (server-stamped, forward-compat)
                #   (2) sender name in known-human handle set (back-compat)
                # Both are scoped to release keywords only — same threat
                # surface as before, broader cover for new meshes.
                msgs = payload.get("messages") or []
                if isinstance(msgs, list):
                    for m in msgs:
                        if not isinstance(m, dict):
                            continue
                        sender = m.get("from", "")
                        m_payload = m.get("payload") or {}
                        sender_role = None
                        if isinstance(m_payload, dict):
                            sender_role = m_payload.get("sender_role") or m_payload.get("from_role")
                        is_human = (
                            sender_role == "human_user"
                            or sender in _KNOWN_HUMAN_HANDLES
                        )
                        if not is_human:
                            continue
                        m_text = ""
                        if isinstance(m_payload, dict):
                            m_text = str(m_payload.get("text", "")).lower()
                        elif isinstance(m_payload, str):
                            m_text = m_payload.lower()
                        if any(word in m_text for word in RELEASE_WORDS):
                            return True
                return False
        return False
    except (OSError, FileNotFoundError):
        return False


def _mcp_unreachable_recently(transcript_path, lookback_records=_UNREACHABLE_LOOKBACK):
    """Detect that MCP `meshcode_wait` is currently unreachable.

    Without this signal, a dead MCP traps the agent: the stop hook keeps
    demanding meshcode_wait while the tool itself has been de-registered
    by the runtime, and the agent has no way to satisfy it short of the
    user typing a release keyword. Lived through 2026-05-07 by backend
    after first wait dropped stdio.

    Three classifications, all → release:
      1. registered+errored — recent meshcode_wait tool_result has
         is_error=True OR contains an _MCP_DEAD_MARKERS substring.
      2. unregistered — agent ran ToolSearch select:meshcode_wait and
         got "no matching deferred tools found".
      3. (current implementation) any of the above wins; we do NOT
         require a count threshold because a single tool-down event
         is high-signal: meshcode_wait should never legitimately fail
         except via must_exit/done_signals which are handled in (c).
    """
    try:
        records = []
        with transcript_path.open() as f:
            for line in f:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        tail = records[-lookback_records:] if lookback_records else records
        wait_tool_use_ids = set()
        toolsearch_wait_ids = set()
        for rec in tail:
            _, content = _rec_role_content(rec)
            blocks = content if isinstance(content, list) else [content] if isinstance(content, dict) else []
            for block in blocks:
                if not isinstance(block, dict):
                    continue
                btype = block.get("type")
                if btype == "tool_use":
                    name = str(block.get("name", ""))
                    use_id = block.get("id")
                    if name.endswith(WAIT_TOOL_SUFFIX) and use_id:
                        wait_tool_use_ids.add(use_id)
                    elif name.endswith("ToolSearch") or name == "ToolSearch":
                        query = ""
                        inp = block.get("input")
                        if isinstance(inp, dict):
                            query = str(inp.get("query", ""))
                        if "meshcode_wait" in query and use_id:
                            toolsearch_wait_ids.add(use_id)
                elif btype == "tool_result":
                    use_id = block.get("tool_use_id")
                    if not use_id:
                        continue
                    is_error = bool(block.get("is_error"))
                    raw_text = block.get("content")
                    if isinstance(raw_text, list):
                        raw_text = " ".join(
                            p.get("text", "")
                            for p in raw_text
                            if isinstance(p, dict)
                        )
                    text_lower = str(raw_text or "").lower()
                    if use_id in wait_tool_use_ids and (
                        is_error or any(m in text_lower for m in _MCP_DEAD_MARKERS)
                    ):
                        return True
                    if use_id in toolsearch_wait_ids and "no matching deferred tools found" in text_lower:
                        return True
        return False
    except (OSError, FileNotFoundError):
        return False


def _latest_deferred_listing_lacks_meshcode(transcript_path, lookback_records=_UNREACHABLE_LOOKBACK):
    """Detect "meshcode MCP never loaded this session" by inspecting the
    structured deferred-tools attachments Claude Code writes to the
    transcript jsonl. Records of the form:

        {"type": "attachment",
         "attachment": {"type": "deferred_tools_delta",
                        "addedNames": ["mcp__claude_ai_Gmail__...", ...]}}

    accumulate over the session — meshcode tools land as
    `mcp__meshcode-<server>__<tool>` once the server registers. If we
    walk every delta and find ZERO meshcode entries (but DID find OTHER
    mcp__ entries, confirming Claude Code is recording deltas at all),
    the meshcode MCP server is missing for this session → release.

    Replaces the previous text-marker scan ("the following deferred tools
    are now available") — Claude Code never writes that rendered text
    into the transcript; only the structured attachment. The old scan
    therefore never fired, trapping agents whose MCP server failed at
    boot in an infinite stay-on-loop. Confirmed via bob@justforfun
    cross-mesh repro (2026-05-14) + Samuel mesh-commander launch.
    """
    try:
        seen_other_mcp = False
        seen_meshcode = False
        record_count = 0
        with transcript_path.open() as f:
            for line in f:
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                record_count += 1
                att = rec.get("attachment") if isinstance(rec, dict) else None
                if not isinstance(att, dict):
                    continue
                if att.get("type") != "deferred_tools_delta":
                    continue
                names = att.get("addedNames") or []
                if not isinstance(names, list):
                    continue
                for n in names:
                    if not isinstance(n, str):
                        continue
                    # meshcode tools are namespaced under their server name:
                    # `mcp__meshcode-<server>__<tool>`. Substring check covers
                    # all variants (self-improve, justforfun, mesh-dev, etc.).
                    if "meshcode-" in n and "__meshcode_" in n:
                        seen_meshcode = True
                    elif n.startswith("mcp__"):
                        seen_other_mcp = True
        # Release only when we have evidence Claude Code IS recording deltas
        # (other mcp__ tools present) but no meshcode_* entries appeared.
        # Without the seen_other_mcp guard we'd false-positive on transcripts
        # that simply haven't reached any deferred-tools delta yet.
        return bool(seen_other_mcp and not seen_meshcode)
    except (OSError, FileNotFoundError):
        return False


def _user_explicitly_reports_mcp_failure(transcript_path, lookback_records=_UNREACHABLE_LOOKBACK):
    """Scan recent user-typed text for explicit MCP-failure reports.
    Distinct from `_last_user_message`: that helper checks for release
    KEYWORDS (stop/sleep/etc.); this one checks for human-narrated MCP
    breakage so the agent can release even when the human didn't think
    to type a release keyword.
    """
    try:
        records = []
        with transcript_path.open() as f:
            for line in f:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        tail = records[-lookback_records:] if lookback_records else records
        for rec in reversed(tail):
            role, content = _rec_role_content(rec)
            if role != "user":
                continue
            text = ""
            if isinstance(content, str):
                text = content
            elif isinstance(content, list):
                parts = []
                for p in content:
                    if isinstance(p, dict) and p.get("type") == "text":
                        parts.append(str(p.get("text", "")))
                text = " ".join(parts)
            if not text:
                continue
            lower = text.lower()
            if any(p in lower for p in _USER_MCP_FAIL_PHRASES):
                return True
        return False
    except (OSError, FileNotFoundError):
        return False


def main():
    raw = sys.stdin.read()
    try:
        payload = json.loads(raw) if raw else {}
    except json.JSONDecodeError:
        payload = {}

    transcript = payload.get("transcript_path") or payload.get("transcriptPath")
    transcript_path = Path(transcript) if transcript else None

    last_user = _last_user_message(transcript_path).lower() if transcript_path else ""
    if any(word in last_user for word in RELEASE_WORDS):
        sys.exit(0)

    if transcript_path and _last_assistant_turn_called_wait(transcript_path):
        sys.exit(0)

    if transcript_path and _latest_wait_result_authorizes_exit(transcript_path):
        sys.exit(0)

    if transcript_path and _mcp_unreachable_recently(transcript_path):
        # PROTO-MCP-UNREACHABLE-RELEASE: log the reason to stderr so
        # session traces can show why the loop released without a user
        # release keyword. Released without printing a block decision.
        try:
            sys.stderr.write("[stay_on_loop] release: mcp_unreachable\\n")
            sys.stderr.flush()
        except Exception:
            pass
        sys.exit(0)

    if transcript_path and _latest_deferred_listing_lacks_meshcode(transcript_path):
        try:
            sys.stderr.write("[stay_on_loop] release: mcp_not_registered (deferred listing has no meshcode_*)\\n")
            sys.stderr.flush()
        except Exception:
            pass
        sys.exit(0)

    if transcript_path and _user_explicitly_reports_mcp_failure(transcript_path):
        try:
            sys.stderr.write("[stay_on_loop] release: user_reported_mcp_failure\\n")
            sys.stderr.flush()
        except Exception:
            pass
        sys.exit(0)

    print(
        json.dumps(
            {
                "decision": "block",
                "reason": (
                    "Stay-on-loop: you ended your turn without calling "
                    "meshcode_wait. Per Samuel's standing rule, every turn "
                    "ends with an active meshcode_wait. Call meshcode_wait "
                    "now (timeout_seconds=20). Do not reply with text — "
                    "just make the tool call. The only way out is the user "
                    "typing stop / sleep / exit / done, a sleep "
                    "authorization (must_exit / done_signals) from the "
                    "mesh, or MCP becoming unreachable (auto-released)."
                ),
            }
        )
    )
    sys.exit(0)


if __name__ == "__main__":
    main()
'''
