"""`meshcode run <agent>` — universal agent launcher.

Looks up the agent's workspace dir (created by `meshcode setup`) in the
registry at ~/meshcode/.registry.json, auto-detects the user's MCP-aware
editor, and launches it pointing at that workspace's isolated .mcp.json
so ONLY this one agent loads in the new window.

Editor detection order (first match wins):
    1. $MESHCODE_EDITOR env var (explicit override: claude / cursor / code)
    2. claude (Claude Code) — uses --mcp-config flag for per-instance config
    3. cursor — opens Cursor in the workspace dir (reads .cursor/mcp.json)
    4. code (VS Code, used by Cline) — opens VS Code in the workspace dir
       (Cline reads .vscode/mcp.json)

The workspace dir contains all three config files (.mcp.json,
.cursor/mcp.json, .vscode/mcp.json) so any of these editors works
identically. Closing the editor window kills the MCP subprocess and
the agent flips to offline.
"""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional, Tuple

from .preferences import resolve_permission_mode
from . import self_update

WORKSPACES_ROOT = Path.home() / "meshcode"
REGISTRY_PATH = WORKSPACES_ROOT / ".registry.json"


def _fetch_or_generate_art(agent: str, project: str) -> tuple:
    """Fetch ASCII art + role + profile color + mascot config from server.
    Returns (ascii_art, role_description, profile_color, mascot_config)."""
    from .ascii_art import generate_art
    try:
        from .setup_clients import _load_supabase_env
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
    except Exception:
        return generate_art(agent), agent, None, None

    profile = os.environ.get("MESHCODE_KEYCHAIN_PROFILE") or "default"
    api_key = secrets_mod.get_api_key(profile=profile)
    if not api_key:
        return generate_art(agent), agent, None, None

    sb = _load_supabase_env()
    profile_color = None
    mascot_config = None
    try:
        from urllib.request import Request, urlopen
        import urllib.parse
        # Step 1: resolve project_id via RPC (bypasses RLS on mc_projects)
        resolve_body = json.dumps({"p_api_key": api_key, "p_project_name": project})
        proj_req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_resolve_project",
            data=resolve_body.encode(),
            method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
                "Content-Profile": "meshcode",
            },
        )
        with urlopen(proj_req, timeout=5) as resp:
            proj_data = json.loads(resp.read().decode())
        if not proj_data or not proj_data.get("project_id"):
            return generate_art(agent), agent, None, None
        project_id = proj_data["project_id"]
        # Step 2: fetch existing art + role via mc_get_agents RPC
        data = None
        try:
            rpc_body = json.dumps({
                "p_api_key": api_key,
                "p_project_id": project_id,
                "p_agent_name": agent,
                "p_select": ["ascii_art", "role", "id"],
            })
            rpc_req = Request(
                f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_get_agents",
                data=rpc_body.encode(),
                method="POST",
                headers={
                    "apikey": sb["SUPABASE_KEY"],
                    "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                    "Content-Type": "application/json",
                    "Content-Profile": "meshcode",
                },
            )
            with urlopen(rpc_req, timeout=5) as resp:
                rpc_result = json.loads(resp.read().decode())
            if isinstance(rpc_result, dict) and rpc_result.get("ok"):
                data = rpc_result.get("agents") or []
        except Exception:
            pass  # fall through to legacy direct REST call

        # Legacy fallback: direct REST call to mc_agents table
        if data is None:
            try:
                req = Request(
                    f"{sb['SUPABASE_URL']}/rest/v1/mc_agents?select=ascii_art,role,id&name=eq.{urllib.parse.quote(agent)}&project_id=eq.{project_id}",
                    headers={
                        "apikey": sb["SUPABASE_KEY"],
                        "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                        "Accept-Profile": "meshcode",
                    },
                )
                with urlopen(req, timeout=5) as resp:
                    data = json.loads(resp.read().decode())
            except Exception:
                data = []

        if data:
            agent_id = data[0].get("id")
            # Step 3: fetch profile color
            if agent_id:
                try:
                    prof_req = Request(
                        f"{sb['SUPABASE_URL']}/rest/v1/mc_agent_profiles?select=color,mascot_config&agent_id=eq.{agent_id}",
                        headers={
                            "apikey": sb["SUPABASE_KEY"],
                            "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                            "Accept-Profile": "meshcode",
                        },
                    )
                    with urlopen(prof_req, timeout=5) as resp:
                        prof_data = json.loads(resp.read().decode())
                    if prof_data:
                        if prof_data[0].get("color"):
                            profile_color = prof_data[0]["color"]
                        if prof_data[0].get("mascot_config"):
                            mascot_config = prof_data[0]["mascot_config"]
                except Exception:
                    pass
            if data[0].get("ascii_art"):
                return data[0]["ascii_art"], data[0].get("role") or agent, profile_color, mascot_config
    except Exception:
        pass

    # Generate and store
    art = generate_art(agent)
    try:
        body = json.dumps({"p_project_name": project, "p_agent_name": agent, "p_ascii_art": art})
        req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_store_agent_art",
            data=body.encode(),
            method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
                "Content-Profile": "meshcode",
            },
        )
        urlopen(req, timeout=5)
    except Exception:
        pass
    return art, agent, profile_color, mascot_config


def _fetch_agent_stats(agent: str, project: str) -> dict:
    """Fetch basic agent stats for achievement badges. Non-critical."""
    try:
        from .setup_clients import _load_supabase_env
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
    except Exception:
        return {}
    profile = os.environ.get("MESHCODE_KEYCHAIN_PROFILE") or "default"
    api_key = secrets_mod.get_api_key(profile=profile)
    if not api_key:
        return {}
    sb = _load_supabase_env()
    try:
        from urllib.request import Request, urlopen
        import urllib.parse
        body = json.dumps({
            "p_api_key": api_key,
            "p_project_name": project,
            "p_agent_name": agent,
        }).encode()
        req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_agent_stats_for_banner",
            data=body, method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
                "Content-Profile": "meshcode",
            },
        )
        with urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def _check_agent_ownership(agent: str, project: str) -> Optional[str]:
    """Pre-flight check: verify caller owns this agent before launching editor.

    Returns an error message string if blocked, None if OK.
    """
    try:
        from .setup_clients import _load_supabase_env
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
    except Exception:
        return "cannot load auth modules; re-install meshcode"

    # Try scoped profile first (from invite join), then default
    scoped_profile = f"mesh:{project}:{agent}"
    api_key = secrets_mod.get_api_key(profile=scoped_profile)
    if not api_key:
        profile = os.environ.get("MESHCODE_KEYCHAIN_PROFILE") or "default"
        api_key = secrets_mod.get_api_key(profile=profile)
    if not api_key:
        return "not logged in — run `meshcode login <api_key>` first"

    sb = _load_supabase_env()
    try:
        from urllib.request import Request, urlopen
        body = json.dumps({
            "p_api_key": api_key,
            "p_project_name": project,
            "p_agent_name": agent,
        }).encode()
        req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_check_agent_ownership",
            data=body,
            method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
            },
        )
        with urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
    except Exception as e:
        return f"could not verify meshwork access ({e}); refusing to launch"

    if isinstance(data, dict) and data.get("error"):
        return data["error"]
    if not isinstance(data, dict) or not data.get("ok"):
        return "ownership check returned unexpected response; refusing to launch"
    return None


def _resolve_user_projects_for_agent(agent: str) -> Optional[list]:
    """Ask the server which meshworks owned by the current user have this agent.

    Returns list of dicts [{project_name, project_id, role}], or None on auth/network error.
    Always scoped to the authenticated user (RPC enforces owner_id = caller user).
    """
    try:
        from .setup_clients import _load_supabase_env
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
    except Exception:
        return None

    profile = os.environ.get("MESHCODE_KEYCHAIN_PROFILE") or "default"
    api_key = secrets_mod.get_api_key(profile=profile)
    if not api_key:
        return None

    sb = _load_supabase_env()
    try:
        from urllib.request import Request, urlopen
        body = json.dumps({"p_api_key": api_key, "p_agent_name": agent}).encode()
        req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_resolve_agent_projects",
            data=body,
            method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
            },
        )
        with urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
    except Exception:
        return None

    if not isinstance(data, dict) or data.get("error"):
        return []
    projects = data.get("projects") or []
    return projects if isinstance(projects, list) else []


def _try_auto_setup(agent: str, project: str) -> Optional[Tuple[Path, str]]:
    """If agent exists on the server but has no local workspace, auto-create it.

    Caller MUST pass an explicit project — this function never auto-picks one.
    Returns (workspace_path, project_name) on success, None on failure.
    """
    if not project:
        return None

    try:
        from .setup_clients import setup_workspace
    except Exception:
        return None

    projects = _resolve_user_projects_for_agent(agent)
    if not projects:
        return None

    # Filter to the explicitly requested project. Never silently auto-pick.
    match = [p for p in projects if p.get("project_name") == project]
    if not match:
        return None

    resolved_project = match[0]["project_name"]
    role = match[0].get("role", "")

    print(f"[meshcode] Workspace recreated automatically for agent '{agent}' (project: {resolved_project})")
    rc = setup_workspace(resolved_project, agent, role)
    if rc != 0:
        return None

    ws = WORKSPACES_ROOT / f"{resolved_project}-{agent}"
    if ws.exists():
        return ws, resolved_project
    return None


def _load_registry() -> dict:
    if not REGISTRY_PATH.exists():
        return {}
    try:
        return json.loads(REGISTRY_PATH.read_text())
    except Exception:
        return {}


def _find_agent_workspace(agent: str, project: str, quiet: bool = False) -> Optional[Tuple[Path, str]]:
    """Look up the agent's workspace for an EXPLICIT project. Returns (path, project) or None.

    Caller MUST pass project — this function never auto-picks across meshworks.
    When quiet=True, suppresses error messages (used before auto-setup fallback).
    """
    if not project:
        return None

    reg = _load_registry()
    agents = reg.get("agents", {})

    info = agents.get(agent)
    if info and info.get("project") == project:
        ws = Path(info["workspace"])
        if ws.exists():
            return ws, project
        # Registry points at a missing dir — caller will try auto-setup
        return None

    if info and info.get("project") != project and not quiet:
        print(f"[meshcode] NOTE: registry has agent '{agent}' under project '{info.get('project')}', not '{project}'", file=sys.stderr)

    # Filesystem fallback: ~/meshcode/<project>-<agent>
    ws = WORKSPACES_ROOT / f"{project}-{agent}"
    if ws.exists():
        return ws, project

    return None


def _list_local_projects_for_agent(agent: str) -> list:
    """Return project names whose local workspace dir matches <project>-<agent>."""
    if not WORKSPACES_ROOT.exists():
        return []
    out = []
    for p in WORKSPACES_ROOT.iterdir():
        if p.is_dir() and p.name.endswith(f"-{agent}"):
            proj = p.name.rsplit(f"-{agent}", 1)[0]
            if proj:
                out.append(proj)
    return out


STABLE_CLAUDE_VERSION = "2.1.104"  # Known-good version: ESC does NOT kill MCP


def _get_claude_version(editor_cmd: str) -> Optional[str]:
    """Get the installed Claude Code version. Returns None on failure."""
    try:
        use_shell = sys.platform == "win32" and editor_cmd.lower().endswith((".cmd", ".bat"))
        r = subprocess.run(
            [editor_cmd, "--version"],
            capture_output=True, text=True, timeout=10,
            shell=use_shell,
        )
        # Output is typically just the version string, e.g. "2.1.104"
        version = r.stdout.strip().split('\n')[0].strip()
        if version:
            return version
    except Exception:
        pass
    return None


def _fetch_global_claude_version() -> Optional[str]:
    """Fetch the admin-pinned Claude Code version from mc_global_config.

    Uses the user's API key to authenticate the RPC call. Returns None
    on any failure (no network, no key, etc.) — caller falls back to
    local preferences or installed version.
    """
    try:
        from .secrets import get_api_key
        api_key = get_api_key()
        if not api_key:
            return None
        from .setup_clients import _load_supabase_env
        env = _load_supabase_env()
        url = env.get("SUPABASE_URL", "")
        anon_key = env.get("SUPABASE_KEY", "")
        if not url or not anon_key:
            return None
        from urllib.request import Request, urlopen
        import json as _json
        req = Request(
            f"{url}/rest/v1/rpc/mc_get_global_config",
            data=_json.dumps({"p_key": "claude_code_version"}).encode(),
            headers={
                "Content-Type": "application/json",
                "apikey": anon_key,
                "Authorization": f"Bearer {anon_key}",
            },
        )
        with urlopen(req, timeout=5) as resp:
            raw = _json.loads(resp.read())
            # RPC returns the JSONB value directly — could be a string or object
            if isinstance(raw, str) and raw not in ("latest", ""):
                return raw
    except Exception:
        pass
    return None


def _resolve_pinned_claude(editor_cmd: str) -> str:
    """Check if a specific Claude Code version is pinned and resolve the command.

    Version pin sources (first wins):
      1. MESHCODE_CLAUDE_VERSION env var (per-launch override)
      2. mc_global_config 'claude_version' from DB (admin-controlled)
      3. claude_version in ~/.meshcode/preferences.json (local fallback)
      4. No pin — use whatever is installed

    If a pin is set and the installed version doesn't match, uses npx to
    run the exact pinned version.
    """
    from .preferences import load_prefs

    pinned = os.environ.get("MESHCODE_CLAUDE_VERSION", "").strip()
    if not pinned:
        # Check global admin config from DB
        global_ver = _fetch_global_claude_version()
        if global_ver:
            pinned = global_ver
            print(f"[meshcode] Global admin pin: Claude Code v{pinned}", file=sys.stderr)
    if not pinned:
        pinned = load_prefs().get("claude_version", "")

    # "latest" or "none" means skip pinning — use whatever is installed
    if pinned and pinned.lower() in ("latest", "none", "skip"):
        print(f"[meshcode] Version pin disabled ({pinned}) — using installed version", file=sys.stderr)
        return editor_cmd

    if not pinned:
        # Default pin: v2.1.104 is the last Claude Code version where ESC
        # doesn't kill the MCP server. Newer versions send CancelledError
        # that cascades through the event loop. This default is overridden
        # by any of the 3 pin sources above (set to "latest" to disable).
        # Remove this default once Anthropic fixes the ESC bug upstream.
        pinned = "2.1.104"
        print(f"[meshcode] Default ESC-safe pin: Claude Code v{pinned}", file=sys.stderr)

    current = _get_claude_version(editor_cmd)
    if current == pinned:
        print(f"[meshcode] Claude Code version {current} matches pin ✓", file=sys.stderr)
        return editor_cmd

    print(f"[meshcode] Version pin: {pinned} (installed: {current or 'unknown'})", file=sys.stderr)
    print(f"[meshcode] Using npx to run pinned version...", file=sys.stderr)

    # Use npx to run the exact pinned version. npx will download it if needed.
    # We set an env var so the launch path knows to prepend npx args.
    os.environ["_MESHCODE_NPX_CLAUDE_VERSION"] = pinned
    return editor_cmd  # Still return the editor — launch path handles npx


def _claude_supports_bypass(editor_cmd: str) -> bool:
    """Check if the Claude Code binary supports --dangerously-skip-permissions.

    Runs ``claude --help`` and looks for the flag. Returns False on any
    error (timeout, not found, old version) so the caller can degrade
    gracefully instead of crashing.

    On Windows, .cmd/.bat wrappers need shell=True to execute correctly —
    without it the subprocess silently fails and bypass never activates.
    """
    try:
        use_shell = sys.platform == "win32" and editor_cmd.lower().endswith((".cmd", ".bat"))
        print(f"[meshcode] bypass-detect: checking '{editor_cmd}' (shell={use_shell})", file=sys.stderr)
        r = subprocess.run(
            [editor_cmd, "--help"],
            capture_output=True, text=True, timeout=10,
            shell=use_shell,
        )
        found = "--dangerously-skip-permissions" in r.stdout
        if found:
            print(f"[meshcode] bypass-detect: ✓ flag found — bypass mode available", file=sys.stderr)
        else:
            stdout_len = len(r.stdout)
            stderr_preview = (r.stderr or "")[:200]
            print(f"[meshcode] bypass-detect: ✗ flag NOT found in --help output ({stdout_len} chars, exit={r.returncode})", file=sys.stderr)
            if stderr_preview:
                print(f"[meshcode] bypass-detect: stderr: {stderr_preview}", file=sys.stderr)
        return found
    except subprocess.TimeoutExpired:
        print(f"[meshcode] bypass-detect: ✗ '{editor_cmd} --help' timed out after 10s", file=sys.stderr)
        return False
    except FileNotFoundError:
        print(f"[meshcode] bypass-detect: ✗ '{editor_cmd}' not found in PATH", file=sys.stderr)
        return False
    except Exception as e:
        print(f"[meshcode] bypass-detect: ✗ unexpected error: {e}", file=sys.stderr)
        return False


def _detect_editor() -> Optional[str]:
    """Pick the user's preferred MCP-aware editor."""
    override = os.environ.get("MESHCODE_EDITOR", "").strip().lower()
    if override:
        resolved = shutil.which(override)
        if resolved:
            # On Windows, return resolved path to preserve .cmd/.bat extension
            return resolved if sys.platform == "win32" else override
        print(f"[meshcode] WARNING: MESHCODE_EDITOR='{override}' not found in PATH", file=sys.stderr)

    # Detection order: most likely to be installed + best per-workspace MCP
    # support first. codex is last because its MCP config is GLOBAL only —
    # launching it doesn't take a workspace-scoped .mcp.json, so it should
    # only be picked if nothing else is available.
    # On Windows, return the fully-resolved path so .cmd/.bat extension is
    # preserved — needed for shell=True detection in bypass and launch paths.
    for cmd in ("claude", "cursor", "code", "windsurf", "codex"):
        resolved = shutil.which(cmd)
        if resolved:
            return resolved if sys.platform == "win32" else cmd

    # Windows fallback: check common install locations not in PATH
    if sys.platform == "win32":
        appdata = os.environ.get("APPDATA", "")
        localappdata = os.environ.get("LOCALAPPDATA", "")
        win_candidates = [
            os.path.join(appdata, "npm", "claude.cmd"),
            os.path.join(appdata, "npm", "claude"),
            os.path.join(localappdata, "Programs", "claude", "claude.exe"),
            os.path.join(localappdata, "Programs", "cursor", "Cursor.exe"),
            os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "Claude", "claude.exe"),
            os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "nodejs", "claude.cmd"),
        ]
        for c in win_candidates:
            if c and os.path.isfile(c):
                return c
        # Last resort: ask npm where its global bin is
        try:
            npm_bin = subprocess.check_output(["npm", "root", "-g"], text=True, timeout=5).strip()
            # npm root -g returns node_modules dir, bin is one level up
            npm_bin_dir = os.path.dirname(npm_bin)
            for name in ("claude.cmd", "claude.ps1", "claude", "claude.exe"):
                p = os.path.join(npm_bin_dir, name)
                if os.path.isfile(p):
                    return p
        except Exception:
            pass

    return None


def _preflight_heartbeat(agent: str, project: str) -> None:
    """Send a heartbeat + set status before the editor launches.

    On Windows without bypass mode, Claude Code may delay spawning the
    MCP server until the user approves the first tool call. During that
    gap the agent shows as 'offline' in the dashboard. This direct RPC
    call ensures the agent appears online immediately.

    Best-effort: any failure is logged and swallowed — it must never
    block or crash the launch.
    """
    try:
        from .setup_clients import _load_supabase_env
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
        from urllib.request import Request, urlopen

        profile = os.environ.get("MESHCODE_KEYCHAIN_PROFILE") or "default"
        api_key = secrets_mod.get_api_key(profile=profile)
        if not api_key:
            return

        sb = _load_supabase_env()
        headers = {
            "apikey": sb["SUPABASE_KEY"],
            "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
            "Content-Type": "application/json",
            "Content-Profile": "meshcode",
        }

        # Resolve project_id
        resolve_body = json.dumps({"p_api_key": api_key, "p_project_name": project})
        req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_resolve_project",
            data=resolve_body.encode(), method="POST", headers=headers,
        )
        with urlopen(req, timeout=5) as resp:
            proj_data = json.loads(resp.read().decode())
        project_id = proj_data.get("project_id") if proj_data else None
        if not project_id:
            return

        # Send heartbeat
        hb_body = json.dumps({"p_project_id": project_id, "p_agent_name": agent})
        hb_req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_heartbeat",
            data=hb_body.encode(), method="POST", headers=headers,
        )
        with urlopen(hb_req, timeout=5) as resp:
            resp.read()

        # Set status to 'online'
        status_body = json.dumps({
            "p_api_key": api_key,
            "p_project_id": project_id,
            "p_agent_name": agent,
            "p_status": "online",
            "p_task": "launching editor",
        })
        status_req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_agent_set_status_by_api_key",
            data=status_body.encode(), method="POST", headers=headers,
        )
        with urlopen(status_req, timeout=5) as resp:
            resp.read()

        print(f"[meshcode]   Pre-flight heartbeat sent — agent visible in dashboard")
    except Exception as e:
        print(f"[meshcode]   Pre-flight heartbeat skipped: {e}", file=sys.stderr)


def run(agent: str, project: Optional[str] = None, editor_override: Optional[str] = None, permission_override: Optional[str] = None) -> int:
    """Launch the user's editor with ONLY the named agent's MCP server loaded."""
    # Non-blocking self-update check (consumes prior result, may spawn bg pip)
    try:
        self_update.check_and_maybe_update()
    except Exception:
        pass

    # Detect: are we already inside a Claude Code session? os.execvp(claude)
    # from inside an existing claude won't work — claude needs a fresh
    # interactive terminal it owns. Refuse with a clear message.
    if os.environ.get("CLAUDECODE") == "1" or os.environ.get("CLAUDE_CODE_SESSION"):
        print("[meshcode] ERROR: meshcode run cannot bootstrap a new agent from inside an", file=sys.stderr)
        print("[meshcode]        existing Claude Code session.", file=sys.stderr)
        print("[meshcode]        Open a fresh Terminal / iTerm window and run the command there.", file=sys.stderr)
        print(f"[meshcode]        (or copy this exact line into a new terminal: meshcode run {agent})", file=sys.stderr)
        return 2

    # ── Require explicit meshwork ────────────────────────────────────
    # Agent names are not globally unique (e.g. "commander" exists in many
    # meshworks). Without an explicit meshwork, we cannot safely pick one
    # — even if only one is visible locally, another could exist on the
    # server. Force the user to disambiguate and authenticate against a
    # specific meshwork they own.
    if not project:
        print(f"[meshcode] ERROR: specify which meshwork '{agent}' belongs to.", file=sys.stderr)
        local_projects = _list_local_projects_for_agent(agent)
        server_projects = _resolve_user_projects_for_agent(agent) or []
        candidates = set(local_projects) | {p.get("project_name") for p in server_projects if p.get("project_name")}
        if candidates:
            print(f"[meshcode] '{agent}' is available in these meshworks of yours:", file=sys.stderr)
            for name in sorted(candidates):
                print(f"[meshcode]   meshcode run {name}/{agent}", file=sys.stderr)
        else:
            print(f"[meshcode] No meshworks of yours contain agent '{agent}'.", file=sys.stderr)
            print(f"[meshcode] Create one first:  meshcode setup <meshwork> {agent}", file=sys.stderr)
        print(f"[meshcode] Usage: meshcode run <meshwork>/{agent}   (or --project <meshwork>)", file=sys.stderr)
        return 2

    found = _find_agent_workspace(agent, project, quiet=True)
    if not found:
        # Auto-setup: if agent exists on the server under THIS meshwork, recreate workspace
        found = _try_auto_setup(agent, project)
        if not found:
            print(f"[meshcode] ERROR: agent '{agent}' not found in meshwork '{project}' for your account.", file=sys.stderr)
            print(f"[meshcode]        Run `meshcode setup {project} {agent}` first,", file=sys.stderr)
            print(f"[meshcode]        or check the meshwork name at https://meshcode.io", file=sys.stderr)
            return 2
    ws, resolved_project = found

    # ── Validate .mcp.json exists (required for MCP connection) ─────
    # If .mcp.json is missing the editor launches but the agent never
    # connects to the mesh — no error shown. Real incident: front-end
    # agent had .mcp.json renamed to .mcp.json.bak by unknown cause.
    mcp_json_path = ws / ".mcp.json"
    mcp_json_bak = ws / ".mcp.json.bak"
    if not mcp_json_path.exists():
        # Try restoring from .bak first (cheapest fix)
        if mcp_json_bak.exists():
            try:
                mcp_json_bak.rename(mcp_json_path)
                print(f"[meshcode] Restored .mcp.json from backup (.mcp.json.bak)", file=sys.stderr)
            except Exception as e:
                print(f"[meshcode] WARNING: .mcp.json.bak exists but restore failed: {e}", file=sys.stderr)

    if not mcp_json_path.exists():
        # Regenerate via setup_workspace (has all data it needs from server)
        print(f"[meshcode] .mcp.json missing from workspace — regenerating...", file=sys.stderr)
        try:
            from .setup_clients import setup_workspace
            rc = setup_workspace(resolved_project, agent)
            if rc == 0 and mcp_json_path.exists():
                print(f"[meshcode] .mcp.json regenerated successfully.", file=sys.stderr)
            else:
                print(f"[meshcode] ERROR: could not regenerate .mcp.json.", file=sys.stderr)
                print(f"[meshcode]        Run `meshcode setup {resolved_project} {agent}` manually.", file=sys.stderr)
                return 2
        except Exception as e:
            print(f"[meshcode] ERROR: .mcp.json missing and regeneration failed: {e}", file=sys.stderr)
            print(f"[meshcode]        Run `meshcode setup {resolved_project} {agent}` to fix.", file=sys.stderr)
            return 2

    # ── Validate stop hook exists (required for wait-loop integrity) ─
    # If the workspace was created on an old CLI that didn't install hooks
    # (or someone wiped .claude/), Claude Code has nothing blocking turn-end
    # → the LLM stops calling meshcode_wait → process exits to shell. Looks
    # like "agent dropped the loop". Ian-2026-05-13 task 14972fd0.
    hook_path = ws / ".claude" / "hooks" / "stay_on_loop.py"
    if not hook_path.exists():
        print(f"[meshcode] stop hook missing from workspace — regenerating...", file=sys.stderr)
        try:
            from .setup_clients import setup_workspace
            rc = setup_workspace(resolved_project, agent)
            if rc == 0 and hook_path.exists():
                print(f"[meshcode] stop hook regenerated successfully.", file=sys.stderr)
            else:
                # Non-fatal: launching without the hook is degraded but better
                # than refusing to launch entirely.
                print(f"[meshcode] WARNING: could not regenerate stop hook.", file=sys.stderr)
                print(f"[meshcode]          Agent may exit the wait loop prematurely.", file=sys.stderr)
                print(f"[meshcode]          Run `meshcode setup {resolved_project} {agent}` manually to fix.", file=sys.stderr)
        except Exception as e:
            print(f"[meshcode] WARNING: stop hook missing and regeneration failed: {e}", file=sys.stderr)
            print(f"[meshcode]          Run `meshcode setup {resolved_project} {agent}` to fix.", file=sys.stderr)

    # ── Ownership pre-check ──────────────────────────────────────────
    # Before launching the editor, verify the caller owns this agent.
    # This prevents hijacking another user's agent in shared meshworks.
    ownership_err = _check_agent_ownership(agent, resolved_project)
    if ownership_err:
        print(f"[meshcode] ERROR: {ownership_err}", file=sys.stderr)
        return 2
    server_id = f"meshcode-{resolved_project}-{agent}"

    editor = editor_override or _detect_editor()
    if not editor:
        print("[meshcode] ERROR: 'claude' not found in PATH", file=sys.stderr)
        print(f"[meshcode]        Workspace is ready at: {ws}", file=sys.stderr)
        print("[meshcode]        Install Claude Code: npm install -g @anthropic-ai/claude-code@2.1.104", file=sys.stderr)
        if sys.platform == "win32":
            print("[meshcode]        Then verify: where claude", file=sys.stderr)
            print("[meshcode]        If 'where' finds it, open a NEW terminal and try again.", file=sys.stderr)
            print("[meshcode]        Or set: set MESHCODE_EDITOR=<full path to claude.cmd>", file=sys.stderr)
            try:
                npm_root = subprocess.check_output(["npm", "root", "-g"], text=True, timeout=5).strip()
                print(f"[meshcode]        npm global root: {npm_root}", file=sys.stderr)
            except Exception:
                print("[meshcode]        (npm not found — install Node.js first)", file=sys.stderr)
        else:
            print("[meshcode]        Then verify: which claude", file=sys.stderr)
        return 2

    # ── Welcome banner with unique ASCII art + personality ──────────
    try:
        from .ascii_art import generate_art, render_welcome
        cli_version = ""
        try:
            from . import __version__ as cli_version
        except ImportError:
            try:
                from meshcode import __version__ as cli_version
            except ImportError:
                # Last resort: read __version__ directly from __init__.py
                try:
                    _init_path = Path(__file__).resolve().parent / "__init__.py"
                    for _line in _init_path.read_text(encoding="utf-8").splitlines():
                        if _line.startswith("__version__"):
                            cli_version = _line.split("=", 1)[1].strip().strip('"').strip("'")
                            break
                except Exception:
                    pass
        ascii_art, agent_role, profile_color, mascot_cfg = _fetch_or_generate_art(agent, resolved_project)
        _leader_haystack = (agent + ' ' + agent_role).lower()
        _LEADER_KW = ('commander', 'lead', 'orchestrat', 'coordinator', 'coordinat',
                       'coordinad', 'jefe', 'líder', 'lider', 'director', 'manager',
                       'chief', 'captain', 'boss', 'head agent')
        is_cmd = any(k in _leader_haystack for k in _LEADER_KW)
        agent_stats = _fetch_agent_stats(agent, resolved_project)
        print(render_welcome(
            agent, resolved_project, ascii_art, cli_version,
            is_commander=is_cmd, role=agent_role, stats=agent_stats,
            profile_color=profile_color,
            mascot_config=mascot_cfg,
        ), file=sys.stderr, flush=True)
    except Exception as _banner_err:
        import traceback as _tb
        print(f"[meshcode] WARN: banner failed: {_banner_err}", file=sys.stderr)
        _tb.print_exc(file=sys.stderr)

    print(f"[meshcode] Launching {editor} for agent '{agent}' (project: {resolved_project})")
    print(f"[meshcode]   Workspace: {ws}")
    print(f"[meshcode]   MCP server: {server_id}")
    print(f"[meshcode]   Closing the editor will flip this agent offline.")
    print()

    # On Windows, editor is the fully-resolved path (e.g. 'c:\...\claude.cmd')
    # so we compare against the stem (filename without extension).
    editor_stem = Path(editor).stem.lower() if sys.platform == "win32" else editor

    # Set editor type so MCP server can report it to the dashboard
    os.environ["MESHCODE_EDITOR_TYPE"] = editor_stem

    if editor_stem == "claude":
        # Claude Code: run from inside the workspace and let Claude Code
        # auto-discover .mcp.json as a PROJECT-scoped MCP. We used to pass
        # --mcp-config + --strict-mcp-config here, but that categorises the
        # server as a "Built-in" (session-injected) MCP, and Built-in MCPs
        # are killed by Claude Code when the user presses ESC — a bug/quirk
        # that caused our agents to die on every cancellation. Project-
        # scoped MCPs (loaded from ./.mcp.json at cwd) live in the "Local
        # MCP" bucket and survive ESC. Verified with a minimal FastMCP
        # repro side-by-side: Built-in dies, Local survives, same SDK code.
        # Check for version pin before building launch command
        effective_editor = _resolve_pinned_claude(editor)
        pinned_version = os.environ.get("_MESHCODE_NPX_CLAUDE_VERSION", "")

        mode = resolve_permission_mode(permission_override)
        print(f"[meshcode]   Editor resolved: {editor}", file=sys.stderr)
        print(f"[meshcode]   Permission mode resolved: {mode}", file=sys.stderr)

        if pinned_version:
            # Use npx to run the exact pinned version
            cmd = ["npx", f"@anthropic-ai/claude-code@{pinned_version}"]
            print(f"[meshcode]   Using pinned version via npx: {pinned_version}")
        else:
            cmd = [effective_editor]

        if mode == "bypass":
            bypass_check_cmd = effective_editor if not pinned_version else "claude"
            if pinned_version or _claude_supports_bypass(bypass_check_cmd):
                cmd.append("--dangerously-skip-permissions")
                print(f"[meshcode]   Permission mode: bypass (autonomous loop, no prompts)")
            else:
                print(f"[meshcode]   Permission mode: bypass requested but --dangerously-skip-permissions")
                print(f"[meshcode]   not supported by this Claude Code version. Agent will prompt for tools.")
                print(f"[meshcode]   Upgrade Claude Code: npm install -g @anthropic-ai/claude-code@2.1.104")
        else:
            print(f"[meshcode]   Permission mode: safe (Claude will prompt for every tool call)")
            print(f"[meshcode]   Tip: change with `meshcode prefs permission-mode bypass`")
        # Boot prompt: triggers the SESSION START sequence from MCP
        # instructions so the agent auto-initializes (set_status, check
        # messages, claim tasks, greet peers) without waiting for user input.
        # Uses -- to separate options from the positional prompt argument.
        cmd.extend(["--", "boot"])
        if not os.path.isdir(ws):
            print(f"[meshcode] WARNING: workspace dir does not exist: {ws}", file=sys.stderr)
        try:
            os.chdir(ws)
        except Exception as e:
            print(f"[meshcode] WARNING: chdir to workspace failed: {e}", file=sys.stderr)
    elif editor_stem == "cursor":
        # Cursor reads .cursor/mcp.json from the workspace cwd.
        cmd = [editor, str(ws)]
    elif editor_stem == "code":
        # VS Code (Cline reads .vscode/mcp.json from workspace cwd).
        cmd = [editor, str(ws)]
    elif editor_stem == "windsurf":
        # Windsurf (Codeium fork of VS Code) — reads workspace cwd the same
        # way VS Code does; global MCP config at ~/.codeium/windsurf/mcp_config.json.
        cmd = [editor, str(ws)]
    elif editor_stem == "codex":
        # Codex CLI reads ~/.codex/config.toml globally. There's no per-
        # workspace flag, so launching is just `codex` with cwd set to the
        # workspace dir so any file ops the agent does land there.
        if not os.path.isdir(ws):
            print(f"[meshcode] WARNING: workspace dir does not exist: {ws}", file=sys.stderr)
        try:
            os.chdir(ws)
        except Exception as e:
            print(f"[meshcode] WARNING: chdir to workspace failed: {e}", file=sys.stderr)
        cmd = [editor]
    else:
        cmd = [editor, str(ws)]

    # If stdin is not a tty (e.g. heredoc from `meshcode scan <<'ART'`),
    # replace it with /dev/null so the editor can't seek back and re-read
    # the heredoc content.  We intentionally do NOT reopen /dev/tty here:
    # Claude Code (and other TUI editors) open /dev/tty themselves for raw
    # keyboard input when they detect stdin is not a terminal.  Giving them
    # a dup'd /dev/tty as fd 0 tricks them into a different code-path that
    # breaks interactive input.
    if not sys.stdin.isatty():
        try:
            null_fd = os.open(os.devnull, os.O_RDONLY)
            os.dup2(null_fd, 0)
            os.close(null_fd)
        except OSError:
            pass  # No devnull (unlikely) — let the editor handle it

    # Pre-flight heartbeat: mark the agent as online BEFORE the editor
    # subprocess spawns. On Windows without bypass mode, Claude Code may
    # delay starting the MCP server until the user interacts — leaving the
    # agent stuck as 'offline' in the dashboard. This direct RPC call
    # ensures immediate visibility regardless of MCP spawn timing.
    _preflight_heartbeat(agent, resolved_project)

    # Flush all output before exec replaces this process — execvp does NOT
    # flush Python file buffers, so any buffered stdout (e.g. the banner)
    # would be silently lost.
    sys.stdout.flush()
    sys.stderr.flush()

    # Effective cwd for the editor — log it for debugging (especially
    # Windows where shell=True + os.chdir may not propagate).
    effective_cwd = os.getcwd()
    print(f"[meshcode]   Effective cwd: {effective_cwd}")

    try:
        if sys.platform == "win32":
            # Windows: no execvp, use subprocess and wait.
            # .cmd/.bat files need shell=True for proper argument passing —
            # without it, flags like --dangerously-skip-permissions can be
            # mangled by Windows' CreateProcess argument splitting.
            # Explicit cwd=str(ws) ensures the child process starts in the
            # workspace even if os.chdir() didn't stick (shell=True can
            # reset cwd via cmd.exe).
            import subprocess as _sp
            # .cmd/.bat files need shell=True. Also check if the resolved
            # path of cmd[0] is a .cmd (e.g., "npx" resolves to "npx.cmd").
            cmd0 = cmd[0].lower()
            use_shell = cmd0.endswith((".cmd", ".bat"))
            if not use_shell:
                resolved_cmd0 = shutil.which(cmd[0])
                if resolved_cmd0 and resolved_cmd0.lower().endswith((".cmd", ".bat")):
                    use_shell = True
            if use_shell:
                print(f"[meshcode]   (Windows: launching via shell for .cmd wrapper)")
            launch_cwd = str(ws) if os.path.isdir(ws) else None
            result = _sp.run(cmd, shell=use_shell, cwd=launch_cwd)
            sys.exit(result.returncode)
        else:
            # Unix: replace this process with the editor
            os.execvp(cmd[0], cmd)
    except FileNotFoundError:
        print(f"[meshcode] ERROR: '{editor}' not found in PATH", file=sys.stderr)
        return 127
    except Exception as e:
        print(f"[meshcode] ERROR launching {editor}: {e}", file=sys.stderr)
        return 1
