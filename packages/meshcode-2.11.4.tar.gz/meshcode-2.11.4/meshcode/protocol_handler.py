"""LAUNCH-1 — meshcode launch-batch / launch-url / install-protocol.

Three CLI subcommands that complement LAUNCH-3 (backend) for the
"launch all my agents from the dashboard" UX.

  meshcode launch-batch <agent_names...>      → spawn terminals
  meshcode launch-url meshcode://...          → parse + dispatch
  meshcode install-protocol                   → register meshcode:// scheme

Safety: launch-url requires a valid session token from
mc_session_launch_token (5min, single-use, hash-stored). The OS scheme
handler ALWAYS goes through launch-url, so a malicious web link can't
spawn terminals without a valid token.
"""
from __future__ import annotations

import json
import os
import platform
import shlex
import shutil
import subprocess
import sys
import urllib.parse
from pathlib import Path
from typing import Iterable, Optional


# ============================================================
# Per-OS terminal spawn
# ============================================================
def _detect_macos_terminal() -> str:
    """Return 'iterm', 'terminal', or 'terminal' as fallback."""
    out = subprocess.run(
        ["defaults", "read", "com.apple.LaunchServices/com.apple.launchservices.secure",
         "LSHandlers"],
        capture_output=True, text=True
    )
    if "iterm" in (out.stdout or "").lower():
        return "iterm"
    if shutil.which("/Applications/iTerm.app/Contents/MacOS/iTerm2"):
        return "iterm"
    return "terminal"


def _spawn_terminal_macos(cmd: str) -> tuple[bool, str]:
    """Spawn `cmd` in a new Terminal/iTerm window (detached)."""
    term = _detect_macos_terminal()
    # AppleScript escaping: backslash + double-quote
    safe = cmd.replace("\\", "\\\\").replace('"', '\\"')
    if term == "iterm":
        script = (
            'tell application "iTerm"\n'
            '  create window with default profile\n'
            f'  tell current session of current window to write text "{safe}"\n'
            'end tell\n'
        )
    else:
        script = f'tell application "Terminal" to do script "{safe}"\n'
    r = subprocess.run(["osascript", "-e", script],
                       capture_output=True, text=True)
    if r.returncode != 0:
        return False, (r.stderr or "osascript failed").strip()
    return True, term


def _spawn_terminal_linux(cmd: str) -> tuple[bool, str]:
    """Spawn `cmd` in a new gnome-terminal/konsole/xterm (detached)."""
    candidates = [
        ("gnome-terminal", ["gnome-terminal", "--", "bash", "-lc", cmd]),
        ("konsole",        ["konsole", "-e", "bash", "-lc", cmd]),
        ("xterm",          ["xterm", "-e", f"bash -lc {shlex.quote(cmd)}"]),
        ("xfce4-terminal", ["xfce4-terminal", "-e", f"bash -lc {shlex.quote(cmd)}"]),
    ]
    for name, argv in candidates:
        if shutil.which(name):
            try:
                subprocess.Popen(argv, start_new_session=True)
                return True, name
            except Exception as e:
                return False, f"{name}: {e}"
    return False, "no terminal emulator found (tried gnome-terminal/konsole/xterm/xfce4)"


def _spawn_terminal_windows(cmd: str) -> tuple[bool, str]:
    """Spawn `cmd` in Windows Terminal (preferred) or cmd.exe."""
    if shutil.which("wt.exe"):
        try:
            # `wt -w 0 nt` opens a new tab in existing window
            subprocess.Popen(["wt.exe", "-w", "0", "nt", "cmd", "/k", cmd])
            return True, "wt"
        except Exception as e:
            return False, f"wt.exe: {e}"
    try:
        subprocess.Popen(["cmd.exe", "/c", "start", "cmd", "/k", cmd])
        return True, "cmd"
    except Exception as e:
        return False, f"cmd.exe: {e}"


def _spawn_terminal(cmd: str) -> tuple[bool, str]:
    p = platform.system()
    if p == "Darwin":
        return _spawn_terminal_macos(cmd)
    if p == "Linux":
        return _spawn_terminal_linux(cmd)
    if p == "Windows":
        return _spawn_terminal_windows(cmd)
    return False, f"unsupported platform: {p}"


# ============================================================
# launch-batch
# ============================================================
def cmd_launch_batch(agent_names: Iterable[str]) -> int:
    """meshcode launch-batch <agent_names...> — spawn one terminal each.

    Returns 0 on full success, 1 if any agent failed to launch (still
    prints JSON summary to stdout).
    """
    names = [n.strip() for n in agent_names if n and n.strip()]
    if not names:
        print(json.dumps({"ok": False, "error": "no agent names supplied",
                          "error_code": "invalid_input"}))
        return 1

    launched: list[str] = []
    skipped: list[dict] = []

    # Resolve `meshcode` binary path (CLI wrapper installed by pip).
    mc_bin = shutil.which("meshcode") or "meshcode"

    for name in names:
        cmd = f"{shlex.quote(mc_bin)} run {shlex.quote(name)}"
        ok, info = _spawn_terminal(cmd)
        if ok:
            launched.append(name)
        else:
            skipped.append({"agent": name, "reason": info})

    out = {
        "ok": len(skipped) == 0,
        "launched": len(launched),
        "agents": launched,
        "skipped": skipped,
    }
    print(json.dumps(out))
    return 0 if not skipped else 1


# ============================================================
# launch-url — parse meshcode:// + validate session token
# ============================================================
def _validate_token(token: str, user_id: str) -> tuple[bool, Optional[str]]:
    """Call mc_validate_launch_token via Supabase. Returns (valid, reason)."""
    try:
        from meshcode.comms_v4 import sb_rpc  # type: ignore
    except Exception:
        try:
            sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            from comms_v4 import sb_rpc  # type: ignore
        except Exception as e:
            return False, f"sb_rpc import failed: {e}"

    try:
        r = sb_rpc("mc_validate_launch_token", {
            "p_token": token,
            "p_user_id": user_id,
            "p_consume": True,
        })
        if not isinstance(r, dict):
            return False, "unexpected response shape"
        if not r.get("ok"):
            return False, r.get("error") or "rpc not ok"
        return bool(r.get("valid")), r.get("reason") or None
    except Exception as e:
        return False, f"rpc failed: {e}"


def cmd_launch_url(url: str) -> int:
    """meshcode launch-url meshcode://launch?agents=a,b&token=...&user=...

    Parses the URL, validates the session token (LAUNCH-3 backend),
    then delegates to launch-batch.
    """
    try:
        parsed = urllib.parse.urlparse(url)
    except Exception as e:
        print(json.dumps({"ok": False, "error": f"bad url: {e}",
                          "error_code": "invalid_url"}))
        return 1

    if parsed.scheme != "meshcode":
        print(json.dumps({"ok": False, "error": "scheme must be meshcode://",
                          "error_code": "invalid_url"}))
        return 1

    action = parsed.netloc or parsed.path.lstrip("/")
    if action != "launch":
        print(json.dumps({"ok": False, "error": f"unknown action: {action!r}",
                          "error_code": "invalid_action"}))
        return 1

    qs = urllib.parse.parse_qs(parsed.query)
    agents_raw = qs.get("agents", [""])[0]
    token      = qs.get("token", [""])[0]
    user_id    = qs.get("user", [""])[0]

    if not token or not user_id:
        print(json.dumps({"ok": False, "error": "token + user query params required",
                          "error_code": "csrf_missing_token"}))
        return 1

    valid, reason = _validate_token(token, user_id)
    if not valid:
        print(json.dumps({"ok": False, "error": "invalid or expired session token",
                          "error_code": "csrf_invalid_token", "reason": reason}))
        return 1

    agents = [a for a in agents_raw.split(",") if a.strip()]
    if not agents:
        print(json.dumps({"ok": False, "error": "no agents in url",
                          "error_code": "invalid_input"}))
        return 1

    return cmd_launch_batch(agents)


# ============================================================
# install-protocol — register meshcode:// scheme handler
# ============================================================
_MAC_INFO_PLIST = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleIdentifier</key>
    <string>io.meshcode.protocol-handler</string>
    <key>CFBundleName</key>
    <string>MeshCode Protocol</string>
    <key>CFBundleExecutable</key>
    <string>meshcode-handler.sh</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleURLTypes</key>
    <array>
        <dict>
            <key>CFBundleURLName</key>
            <string>meshcode</string>
            <key>CFBundleURLSchemes</key>
            <array>
                <string>meshcode</string>
            </array>
        </dict>
    </array>
</dict>
</plist>
"""


def _install_macos() -> tuple[bool, str]:
    """Create a tiny .app bundle that calls `meshcode launch-url $1`."""
    app_dir = Path.home() / "Applications" / "MeshCodeProtocol.app"
    contents = app_dir / "Contents"
    macos    = contents / "MacOS"
    try:
        macos.mkdir(parents=True, exist_ok=True)
        (contents / "Info.plist").write_text(_MAC_INFO_PLIST, encoding="utf-8")
        mc_bin = shutil.which("meshcode") or "meshcode"
        handler = macos / "meshcode-handler.sh"
        handler.write_text(
            "#!/usr/bin/env bash\n"
            f"exec {shlex.quote(mc_bin)} launch-url \"$1\"\n",
            encoding="utf-8"
        )
        handler.chmod(0o755)
        # Register with Launch Services
        subprocess.run(
            ["/System/Library/Frameworks/CoreServices.framework/Frameworks/"
             "LaunchServices.framework/Support/lsregister", "-f", str(app_dir)],
            check=False
        )
        return True, str(app_dir)
    except Exception as e:
        return False, f"install_macos failed: {e}"


def _install_linux() -> tuple[bool, str]:
    """Write XDG .desktop file with MimeType=x-scheme-handler/meshcode."""
    desktop_dir = Path.home() / ".local" / "share" / "applications"
    try:
        desktop_dir.mkdir(parents=True, exist_ok=True)
        mc_bin = shutil.which("meshcode") or "meshcode"
        body = (
            "[Desktop Entry]\n"
            "Type=Application\n"
            "Name=MeshCode Protocol Handler\n"
            f"Exec={mc_bin} launch-url %u\n"
            "NoDisplay=true\n"
            "Terminal=false\n"
            "MimeType=x-scheme-handler/meshcode;\n"
        )
        target = desktop_dir / "meshcode-protocol.desktop"
        target.write_text(body, encoding="utf-8")
        # Register
        subprocess.run(["xdg-mime", "default", "meshcode-protocol.desktop",
                        "x-scheme-handler/meshcode"], check=False)
        subprocess.run(["update-desktop-database", str(desktop_dir)], check=False)
        return True, str(target)
    except Exception as e:
        return False, f"install_linux failed: {e}"


def _install_windows() -> tuple[bool, str]:
    """Write registry keys under HKCU\\Software\\Classes\\meshcode."""
    try:
        import winreg  # type: ignore
    except Exception as e:
        return False, f"winreg unavailable: {e}"

    mc_bin = shutil.which("meshcode") or "meshcode"
    cmd = f'"{mc_bin}" launch-url "%1"'
    try:
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\meshcode") as k:
            winreg.SetValueEx(k, None, 0, winreg.REG_SZ, "URL:MeshCode Protocol")
            winreg.SetValueEx(k, "URL Protocol", 0, winreg.REG_SZ, "")
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\meshcode\shell\open\command") as k:
            winreg.SetValueEx(k, None, 0, winreg.REG_SZ, cmd)
        return True, r"HKCU\Software\Classes\meshcode"
    except Exception as e:
        return False, f"install_windows failed: {e}"


def cmd_install_protocol() -> int:
    """meshcode install-protocol — register the meshcode:// URL scheme."""
    p = platform.system()
    if p == "Darwin":
        ok, info = _install_macos()
    elif p == "Linux":
        ok, info = _install_linux()
    elif p == "Windows":
        ok, info = _install_windows()
    else:
        print(json.dumps({"ok": False, "error": f"unsupported platform: {p}",
                          "error_code": "unsupported_os"}))
        return 1

    out = {"ok": ok, "platform": p, "info": info}
    print(json.dumps(out))
    return 0 if ok else 1


# ============================================================
# main dispatch — invoked from comms_v4.py
# ============================================================
def main(argv: list[str]) -> int:
    if not argv:
        print("usage: meshcode launch-batch <agent_names...>", file=sys.stderr)
        print("       meshcode launch-url <meshcode://...>",  file=sys.stderr)
        print("       meshcode install-protocol",             file=sys.stderr)
        return 2
    sub = argv[0]
    rest = argv[1:]
    if sub == "launch-batch":
        return cmd_launch_batch(rest)
    if sub == "launch-url":
        if not rest:
            print(json.dumps({"ok": False, "error": "url required",
                              "error_code": "invalid_input"}))
            return 1
        return cmd_launch_url(rest[0])
    if sub == "install-protocol":
        return cmd_install_protocol()
    print(f"unknown subcommand: {sub}", file=sys.stderr)
    return 2
