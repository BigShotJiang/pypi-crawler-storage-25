#!/usr/bin/env python3
"""Pre-commit secret scanner.

Born from SECURITY-INCIDENT-2026-05-13-PAT-LEAK (task 76934fc3): a
Supabase Management API PAT was hardcoded into race_rate_harness.py and
committed before pre-publish scan caught it. The leak vector is now a
literal git hook, not just developer discipline (memory
feedback_no_hardcoded_secrets — second leak family in 5 weeks).

What it does: scans the diff of staged files for known secret patterns.
On match, prints the offending lines + file + pattern name and exits 1
(blocking the commit). On clean run, exits 0.

Install as a git pre-commit hook:
    cp meshcode/scripts/check_secrets.py .git/hooks/pre-commit
    chmod +x .git/hooks/pre-commit
or invoke from an existing pre-commit chain:
    python3 meshcode/scripts/check_secrets.py --staged
"""

import argparse
import re
import subprocess
import sys
from typing import List, Tuple

# (name, regex). Keep tight — false positives erode trust.
# Each pattern targets a specific issuer; generic "api_key=" left out
# because human authors paste valid placeholders for examples.
SECRET_PATTERNS: List[Tuple[str, re.Pattern]] = [
    ("Supabase Mgmt API PAT (sbp_)", re.compile(r"\bsbp_[A-Za-z0-9]{40,}\b")),
    ("Supabase legacy service_role JWT (eyJ...)", re.compile(r"\beyJ[A-Za-z0-9_=\-]{60,}\.[A-Za-z0-9_=\-]{20,}\.[A-Za-z0-9_=\-]{20,}\b")),
    ("Supabase secret key (sb_secret_)", re.compile(r"\bsb_secret_[A-Za-z0-9_]{30,}\b")),
    ("PyPI token (pypi-Ag*)", re.compile(r"\bpypi-AgE[A-Za-z0-9_\-]{30,}\b")),
    ("GitHub PAT (ghp_)", re.compile(r"\bghp_[A-Za-z0-9]{36,}\b")),
    ("GitHub fine-grained PAT (github_pat_)", re.compile(r"\bgithub_pat_[A-Za-z0-9_]{40,}\b")),
    ("GitLab PAT (glpat-)", re.compile(r"\bglpat-[A-Za-z0-9_\-]{20,}\b")),
    ("Postgres conn string w/ password", re.compile(r"postgres(ql)?://[^:/\s]+:[^@/\s]{4,}@")),
    ("AWS access key id", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("Anthropic API key (sk-ant-)", re.compile(r"\bsk-ant-[A-Za-z0-9_\-]{40,}\b")),
    ("OpenAI API key (sk-)", re.compile(r"\bsk-[A-Za-z0-9]{40,}\b")),
]

# Files we never scan (false-positive minefield or own this file).
EXEMPT_PATHS = {
    "meshcode/scripts/check_secrets.py",  # self
}

EXEMPT_SUFFIXES = (".md.example", ".lock")


def _staged_files() -> List[str]:
    """Files staged for commit (git diff --cached --name-only)."""
    try:
        out = subprocess.check_output(
            ["git", "diff", "--cached", "--name-only", "--diff-filter=ACM"],
            text=True,
        )
        return [line.strip() for line in out.splitlines() if line.strip()]
    except subprocess.CalledProcessError:
        return []


def _staged_blob(path: str) -> str:
    """Content of staged blob (what's about to commit), not the worktree."""
    try:
        return subprocess.check_output(
            ["git", "show", f":{path}"],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        return ""


def scan_text(content: str, label: str) -> List[Tuple[str, str, int, str]]:
    """Return list of (label, pattern_name, line_no, snippet) for each hit."""
    hits = []
    for i, line in enumerate(content.splitlines(), start=1):
        for name, pattern in SECRET_PATTERNS:
            if pattern.search(line):
                snippet = line.strip()[:120]
                hits.append((label, name, i, snippet))
    return hits


def main() -> int:
    parser = argparse.ArgumentParser(description="Pre-commit secret scanner")
    parser.add_argument(
        "--staged", action="store_true",
        help="Scan staged files (default git pre-commit hook mode)",
    )
    parser.add_argument(
        "files", nargs="*", help="Specific files to scan (overrides --staged)",
    )
    args = parser.parse_args()

    if args.files:
        targets = args.files
        reader = lambda p: open(p, encoding="utf-8", errors="replace").read()
    else:
        targets = _staged_files()
        reader = _staged_blob

    all_hits = []
    for path in targets:
        if path in EXEMPT_PATHS or any(path.endswith(s) for s in EXEMPT_SUFFIXES):
            continue
        try:
            content = reader(path)
        except Exception:
            continue
        hits = scan_text(content, path)
        all_hits.extend(hits)

    if not all_hits:
        return 0

    print("\n🚨 SECRET DETECTED — commit blocked", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    for path, name, lineno, snippet in all_hits:
        print(f"  {path}:{lineno}", file=sys.stderr)
        print(f"    [{name}]", file=sys.stderr)
        print(f"    {snippet}", file=sys.stderr)
        print("", file=sys.stderr)
    print("=" * 60, file=sys.stderr)
    print("Remove the secret(s), use os.environ.get(...) or a config file, then re-stage.", file=sys.stderr)
    print("If this is a FALSE POSITIVE, edit meshcode/scripts/check_secrets.py EXEMPT_PATHS or tighten the pattern.", file=sys.stderr)
    print("DO NOT bypass with --no-verify.", file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())
