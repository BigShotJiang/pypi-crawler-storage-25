#!/usr/bin/env python3
"""MVP race-rate harness for same-model agent coordination patterns.

Proposal 22cf1577 (scope Option B per commander msg 2a1b9f72-ec2d, 2026-05-13):
single chess color-assignment scenario, 10 iterations each of three patterns
(send-async, call-sync, claim), aggregate per-pattern metrics.

Validates bob+wren@justforfun's "~50%/turn cross-rate" finding using our
own measurement. Not a full simulation of two Claude instances — instead,
exercises the underlying protocol primitives (mc_send_message, mc_claim)
and measures their concurrency semantics directly.

Run: python3 meshcode/scripts/race_rate_harness.py [--n 10]

Output: prints aggregate per-pattern and exits. No FE, no DB schema change.
"""

import argparse
import json
import os
import sys
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List, Tuple

import urllib.request

SUPABASE_URL = "https://gjinagyyjttyxnaoavnz.supabase.co"
SUPABASE_KEY = "sb_publishable_0qf0U1GURopPIxLR8Vu7eQ_5grflPP4"

PROJECT_NAME = "meshcode-self-improve"


def _rpc(name: str, params: Dict) -> Dict:
    """Synchronous PostgREST RPC call."""
    body = json.dumps(params).encode()
    req = urllib.request.Request(
        f"{SUPABASE_URL}/rest/v1/rpc/{name}",
        data=body,
        method="POST",
        headers={
            "apikey": SUPABASE_KEY,
            "Authorization": f"Bearer {SUPABASE_KEY}",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode() or "null")
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}: {e.read().decode()[:200]}"}
    except Exception as e:
        return {"error": str(e)}


def _project_id() -> str:
    # Hardcoded for meshcode-self-improve (avoids needing an api key for resolution).
    return "c7d7f880-684b-4b48-adbf-5247200d987e"


def _mgmt_sql(sql: str) -> Dict:
    """Direct SQL via Mgmt API (postgres role, bypasses RLS).

    Reads Supabase Management API PAT from SUPABASE_MGMT_PAT env var.
    Never bakes a token into source — memory feedback_no_hardcoded_secrets
    (MeshCode 1.0.0/1.1.0 yanked over service_role JWT leak).
    """
    pat = os.environ.get("SUPABASE_MGMT_PAT", "").strip()
    if not pat:
        return {"error": "SUPABASE_MGMT_PAT env var not set — harness requires Mgmt API access for setup/teardown"}
    body = json.dumps({"query": sql}).encode()
    req = urllib.request.Request(
        "https://api.supabase.com/v1/projects/gjinagyyjttyxnaoavnz/database/query",
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {pat}",
            "Content-Type": "application/json",
            "User-Agent": "race-rate-harness/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode() or "null")
    except urllib.error.HTTPError as e:
        return {"error": f"HTTP {e.code}: {e.read().decode()[:200]}"}
    except Exception as e:
        return {"error": str(e)}


def _setup_test_agents(suffix: str) -> Tuple[str, str, str]:
    """Mint two test agents in this mesh + a shared api_key.

    Returns (agent_A_id, agent_B_id, api_key_plaintext). The api_key is
    raw text (would normally be hashed in storage); for the harness we
    bypass the secret-key path by using direct SQL via Mgmt API.
    """
    # Insert agents
    rows = _mgmt_sql(f"""
        INSERT INTO meshcode.mc_agents (project_id, name, role, agent_type)
        VALUES
          ('{_project_id()}', 'race-harness-A-{suffix}', 'harness-A', 'ai'),
          ('{_project_id()}', 'race-harness-B-{suffix}', 'harness-B', 'ai')
        RETURNING id, name
    """)
    if not isinstance(rows, list) or len(rows) < 2:
        raise RuntimeError(f"agent insert failed: {rows}")
    a_id = next(r["id"] for r in rows if r["name"].endswith("-A-" + suffix))
    b_id = next(r["id"] for r in rows if r["name"].endswith("-B-" + suffix))
    return a_id, b_id, suffix


def _teardown_test_agents(suffix: str) -> None:
    _mgmt_sql(f"""
        DELETE FROM meshcode.mc_messages WHERE from_agent LIKE 'race-harness-%-{suffix}' OR to_agent LIKE 'race-harness-%-{suffix}';
        DELETE FROM meshcode.mc_resource_claims WHERE resource_name LIKE 'race-harness-%-{suffix}%';
        DELETE FROM meshcode.mc_agents WHERE name LIKE 'race-harness-%-{suffix}';
    """)


# ==========================================================================
# PATTERN 1: send-async — both agents try to claim "white" via meshcode_send
# Race: messages cross on the wire ~50% per bob+wren report. Resolve by
# "first message timestamp wins"; if both sent before either read, it's a
# cross requiring retry.
# ==========================================================================
def pattern_send(suffix: str, iter_id: int) -> Dict:
    """Both agents send a "i_want_white" message at near-zero offset.

    Measure: how many crosses (both sent before either read the other's).
    """
    start = time.monotonic()
    deadline = start + 5.0  # 5s cap
    a_send_t = None
    b_send_t = None

    def agent_send(agent_name: str, resource: str) -> float:
        result = _mgmt_sql(f"""
            INSERT INTO meshcode.mc_messages (project_id, from_agent, to_agent, payload)
            VALUES ('{_project_id()}', '{agent_name}', 'race-harness-{"B" if agent_name.endswith("-A-" + suffix) else "A"}-{suffix}',
                    '{{"want": "{resource}", "iter": {iter_id}}}'::jsonb)
            RETURNING extract(epoch from now())::float AS ts
        """)
        if isinstance(result, list) and result:
            return float(result[0]["ts"])
        return 0.0

    # Fire both in parallel
    with ThreadPoolExecutor(max_workers=2) as pool:
        fut_a = pool.submit(agent_send, f"race-harness-A-{suffix}", "white")
        fut_b = pool.submit(agent_send, f"race-harness-B-{suffix}", "white")
        a_send_t = fut_a.result(timeout=5)
        b_send_t = fut_b.result(timeout=5)

    elapsed_ms = (time.monotonic() - start) * 1000
    # Crossed if abs(diff) < 200ms (rough threshold for "neither read first")
    crossed = abs(a_send_t - b_send_t) < 0.200 if (a_send_t and b_send_t) else False
    return {
        "iter": iter_id,
        "pattern": "send",
        "elapsed_ms": round(elapsed_ms, 2),
        "crossed": crossed,
        "both_claimed_white": True,  # by construction
        "canonical_winner": None,    # send can't resolve atomically
        "needs_external_arbitration": True,
    }


# ==========================================================================
# PATTERN 2: call-sync — agent A sends a synchronous RPC asking "can I be white?"
# Since one side initiates and waits, no cross is possible. Measure: latency
# only. (Our PostgREST setup doesn't run a real callee, so this is modeled.)
# ==========================================================================
def pattern_call(suffix: str, iter_id: int) -> Dict:
    """Modeled: one agent initiates, one responds. No cross by design."""
    start = time.monotonic()
    # Synthetic RPC round-trip via a single INSERT (the protocol guarantee
    # we want to measure is "no cross", not real Claude response latency).
    _mgmt_sql(f"""
        INSERT INTO meshcode.mc_messages (project_id, from_agent, to_agent, payload, type)
        VALUES ('{_project_id()}', 'race-harness-A-{suffix}', 'race-harness-B-{suffix}',
                '{{"call": "want_white?", "iter": {iter_id}}}'::jsonb, 'rpc')
    """)
    elapsed_ms = (time.monotonic() - start) * 1000
    return {
        "iter": iter_id,
        "pattern": "call",
        "elapsed_ms": round(elapsed_ms, 2),
        "crossed": False,            # sync RPC structurally can't cross
        "both_claimed_white": False,
        "canonical_winner": "A",     # by construction (A initiates)
        "needs_external_arbitration": False,
    }


# ==========================================================================
# PATTERN 3: claim — both agents race mc_claim atomically. PostgreSQL serializes.
# ==========================================================================
def pattern_claim(suffix: str, iter_id: int, a_userid: str, b_userid: str) -> Dict:
    """Both agents call mc_claim concurrently. Exactly one wins.

    Uses direct SQL (bypass api key) since mc_claim resolves caller via
    _mc_api_key_row; harness uses postgres role to simulate two callers.
    """
    resource = f"race-harness-white-{suffix}-{iter_id}"
    start = time.monotonic()
    # Direct INSERT...ON CONFLICT mirror of mc_claim semantics

    def claim_attempt(user_id: str, agent_name: str) -> Tuple[bool, float]:
        result = _mgmt_sql(f"""
            INSERT INTO meshcode.mc_resource_claims (
                scope_meshwork_id, resource_name, claimed_by_user_id,
                claimed_by_agent, ttl_expires_at, claimed_at
            )
            VALUES ('{_project_id()}', '{resource}', '{user_id}',
                    '{agent_name}', now() + interval '60s', now())
            ON CONFLICT (scope_meshwork_id, resource_name) DO UPDATE
              SET claimed_by_user_id = EXCLUDED.claimed_by_user_id,
                  ttl_expires_at = EXCLUDED.ttl_expires_at
              WHERE meshcode.mc_resource_claims.ttl_expires_at <= now()
            RETURNING claimed_by_user_id, extract(epoch from claimed_at)::float AS ts
        """)
        if isinstance(result, list) and result:
            return (str(result[0]["claimed_by_user_id"]) == user_id, float(result[0]["ts"]))
        return (False, 0.0)

    with ThreadPoolExecutor(max_workers=2) as pool:
        fut_a = pool.submit(claim_attempt, a_userid, f"race-harness-A-{suffix}")
        fut_b = pool.submit(claim_attempt, b_userid, f"race-harness-B-{suffix}")
        a_won, _ = fut_a.result(timeout=5)
        b_won, _ = fut_b.result(timeout=5)

    elapsed_ms = (time.monotonic() - start) * 1000
    return {
        "iter": iter_id,
        "pattern": "claim",
        "elapsed_ms": round(elapsed_ms, 2),
        "crossed": False,            # atomic, exactly-one-winner guarantee
        "both_claimed_white": (a_won and b_won),  # MUST be false
        "canonical_winner": "A" if a_won else ("B" if b_won else None),
        "needs_external_arbitration": False,
        "atomicity_violated": (a_won and b_won),
    }


def _summarize(label: str, runs: List[Dict]) -> Dict:
    n = len(runs)
    crossed = sum(1 for r in runs if r.get("crossed"))
    arbitration_needed = sum(1 for r in runs if r.get("needs_external_arbitration"))
    elapsed = [r["elapsed_ms"] for r in runs]
    return {
        "pattern": label,
        "n": n,
        "cross_rate": round(crossed / n, 3) if n else 0.0,
        "arbitration_rate": round(arbitration_needed / n, 3) if n else 0.0,
        "elapsed_ms_min": min(elapsed) if elapsed else 0,
        "elapsed_ms_max": max(elapsed) if elapsed else 0,
        "elapsed_ms_mean": round(sum(elapsed) / n, 2) if n else 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Race-rate harness MVP")
    parser.add_argument("--n", type=int, default=10, help="iterations per pattern")
    args = parser.parse_args()

    suffix = uuid.uuid4().hex[:8]
    print(f"[harness] suffix={suffix} n={args.n}")

    a_id, b_id, _ = _setup_test_agents(suffix)
    # For mc_claim we need two distinct mc_users.id; the harness uses the
    # same project's owner OR two distinct user-rows. Look up two real users.
    users = _mgmt_sql("SELECT id FROM meshcode.mc_users LIMIT 2")
    if not isinstance(users, list) or len(users) < 2:
        print(f"[harness] couldn't fetch 2 users: {users}")
        _teardown_test_agents(suffix)
        return 1
    a_uid = users[0]["id"]
    b_uid = users[1]["id"]

    try:
        send_runs = [pattern_send(suffix, i) for i in range(args.n)]
        call_runs = [pattern_call(suffix, i) for i in range(args.n)]
        claim_runs = [pattern_claim(suffix, i, a_uid, b_uid) for i in range(args.n)]
    finally:
        _teardown_test_agents(suffix)

    summary = [
        _summarize("send-async", send_runs),
        _summarize("call-sync", call_runs),
        _summarize("claim", claim_runs),
    ]
    # Sanity check: claim should never violate atomicity
    atomicity_violations = sum(1 for r in claim_runs if r.get("atomicity_violated"))

    print("\n=== Race-rate harness results ===")
    print(json.dumps({"summary": summary, "atomicity_violations": atomicity_violations}, indent=2))
    print("\nInterpretation:")
    print(f"  send-async cross_rate: {summary[0]['cross_rate']*100:.1f}% (bob+wren reported ~50%)")
    print(f"  call-sync cross_rate:  {summary[1]['cross_rate']*100:.1f}% (structural 0% expected)")
    print(f"  claim cross_rate:      {summary[2]['cross_rate']*100:.1f}% (atomic, 0% required)")
    print(f"  atomicity_violations:  {atomicity_violations} (MUST be 0)")
    return 0 if atomicity_violations == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
