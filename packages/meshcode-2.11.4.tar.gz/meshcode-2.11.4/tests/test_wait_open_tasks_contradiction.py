"""Test PROTO-WAIT-OPEN-TASKS-CONTRADICTION (task 88eb5492).

The previous PRODUCT RULE 1 in meshcode_wait refused to enter the loop
when the agent had any assigned-or-claimed open task — but
stay_on_loop.py also DEMANDS the agent end every turn with
meshcode_wait. Result: trapped agent, "Type stop." spam until human
typed a release keyword.

This test asserts the fixed contract:
  1. Open tasks NEVER refuse wait by default.
  2. Legacy refuse-on-tasks behavior remains opt-in via
     MESHCODE_WAIT_BLOCKS_ON_TASKS=1 env flag (back-compat).
  3. The fallback timeout path still surfaces pending_tasks as a hint
     so the agent sees them in the next tick.
  4. Unread MESSAGES still block (PRODUCT RULE 2 unchanged).

Static-analysis only — server.py has heavy module-level side effects
that make full import infeasible without a live Supabase. Instead we
parse the AST + assert the change shape.
"""

from __future__ import annotations

import ast
import re
import unittest
from pathlib import Path


SERVER_PY = Path(__file__).resolve().parent.parent / "meshcode" / "meshcode_mcp" / "server.py"


class TestWaitContradictionFix(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.source = SERVER_PY.read_text()

    def test_legacy_refuse_path_is_env_gated(self):
        # The old unconditional refuse is gone; the path is now gated on
        # MESHCODE_WAIT_BLOCKS_ON_TASKS env flag (default off).
        idx_env = self.source.find('MESHCODE_WAIT_BLOCKS_ON_TASKS')
        self.assertGreater(idx_env, 0,
                           "expected MESHCODE_WAIT_BLOCKS_ON_TASKS env "
                           "guard for legacy back-compat")
        # The refuse string still exists but only inside the env-gated branch.
        idx_refuse = self.source.find("Cannot enter wait")
        # Either the literal is gone or it lives downstream of the env check.
        if idx_refuse > 0:
            self.assertGreater(idx_refuse, idx_env,
                               "if the refuse message still exists, it must "
                               "appear AFTER the env-flag check")

    def test_proto_marker_present_in_wait(self):
        # Documenting the change in code so future readers find the
        # task ID. We grep for the explicit marker.
        self.assertIn("PROTO-WAIT-OPEN-TASKS-CONTRADICTION", self.source,
                      "wait() body must reference the task id so a "
                      "future reader can git-blame to context")
        self.assertIn("88eb5492", self.source,
                      "wait() body must reference the task UUID prefix")

    def test_pending_tasks_hint_path_unchanged(self):
        # Existing hint surface in the timeout path must remain — that's
        # how the agent now sees open tasks without being blocked.
        idx = self.source.find('out["pending_tasks"] = pending_tasks')
        self.assertGreater(idx, 0,
                           "fallback timeout path must still surface "
                           "pending_tasks as a hint so the agent sees "
                           "open work in the next tick")

    def test_messages_still_block_wait(self):
        # PRODUCT RULE 2 — unread messages still drained / blocking.
        # Look for the count_pending check inside meshcode_wait.
        wait_def_idx = self.source.find("async def meshcode_wait")
        self.assertGreater(wait_def_idx, 0)
        # 6000 chars covers the function body comfortably.
        wait_body = self.source[wait_def_idx:wait_def_idx + 6000]
        self.assertIn("count_pending", wait_body,
                      "messages-block-wait path must still call count_pending")
        self.assertIn("read_inbox", wait_body,
                      "messages-block-wait path must still drain via read_inbox")


if __name__ == "__main__":
    unittest.main()
