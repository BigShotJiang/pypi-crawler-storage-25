"""Smoke tests for the auto-update hardening landed in 5a7427f (task 8d5eed7a).

The full meshcode_mcp.server module bootstraps a live project at import
time (sys.exit on failure), which makes it inhospitable to vanilla pytest
runs. These tests therefore re-implement the small helpers under test
inline — the logic is intentionally a verbatim copy of the patched code
in server.py so any drift between source and tests is caught by review.

Covered:
  1. _check_boot_version_drift — None when versions match, tuple on mismatch.
  2. MESHCODE_UPDATED sentinel pop on consume (single-use semantics).
  3. MESHCODE_AUTO_UPDATE=0 short-circuits before any state mutation.

PyPI/relaunch-dependent matrix cells are tracked separately in the task
runbook (Phase 3 deliverable).
"""

import os
from importlib import metadata
from unittest import mock


# ---------------------------------------------------------------------------
# Inline copies of the patched helpers (kept in lockstep with server.py).
# ---------------------------------------------------------------------------

def _check_boot_version_drift_inline():
    try:
        from importlib.metadata import version as _md_version
        from meshcode import __version__ as _loaded
        _installed = _md_version("meshcode")
        if _installed != _loaded:
            return (_installed, _loaded)
    except Exception:
        pass
    return None


def _auto_update_inline_skeleton():
    """Subset of _auto_update covering the env-var gates only."""
    if os.environ.get("MESHCODE_AUTO_UPDATE", "1").lower() in ("0", "false", "no"):
        return "disabled"
    if os.environ.get("MESHCODE_UPDATED") == "1":
        os.environ.pop("MESHCODE_UPDATED", None)
        return "post_exec_skip"
    return "would_check_pypi"


# ---------------------------------------------------------------------------
# 1. Drift helper
# ---------------------------------------------------------------------------

def test_drift_none_when_versions_match():
    """No drift on a clean install where pip and __version__ agree."""
    assert _check_boot_version_drift_inline() is None


def test_drift_returns_tuple_when_versions_diverge():
    """Patching importlib.metadata.version to return a fake newer build
    must surface (installed, loaded) so the caller can log + telemetry."""
    fake_installed = "99.99.99"
    with mock.patch.object(metadata, "version", return_value=fake_installed):
        result = _check_boot_version_drift_inline()
    assert result is not None
    installed, loaded = result
    assert installed == fake_installed
    assert loaded != fake_installed


def test_drift_swallows_metadata_exceptions():
    """Helper must never raise — telemetry is best-effort."""
    with mock.patch.object(metadata, "version", side_effect=metadata.PackageNotFoundError("meshcode")):
        assert _check_boot_version_drift_inline() is None


# ---------------------------------------------------------------------------
# 2. Sentinel pop
# ---------------------------------------------------------------------------

def test_sentinel_pop_clears_environment(monkeypatch):
    monkeypatch.setenv("MESHCODE_UPDATED", "1")
    monkeypatch.delenv("MESHCODE_AUTO_UPDATE", raising=False)
    assert _auto_update_inline_skeleton() == "post_exec_skip"
    assert "MESHCODE_UPDATED" not in os.environ


def test_sentinel_pop_idempotent(monkeypatch):
    """Running twice in a row (simulating a child-of-execv that imports
    twice) must not raise even though the sentinel is gone the second time."""
    monkeypatch.setenv("MESHCODE_UPDATED", "1")
    monkeypatch.delenv("MESHCODE_AUTO_UPDATE", raising=False)
    _auto_update_inline_skeleton()
    # Sentinel is already cleared — the second invocation should fall
    # through to the would-check-pypi branch (or the disabled branch if
    # MESHCODE_AUTO_UPDATE is ever set to 0). It must not raise KeyError.
    result = _auto_update_inline_skeleton()
    assert result in {"would_check_pypi", "disabled"}


# ---------------------------------------------------------------------------
# 3. Disabled short-circuit
# ---------------------------------------------------------------------------

def test_auto_update_disabled(monkeypatch):
    monkeypatch.setenv("MESHCODE_AUTO_UPDATE", "0")
    monkeypatch.delenv("MESHCODE_UPDATED", raising=False)
    assert _auto_update_inline_skeleton() == "disabled"


def test_auto_update_disabled_case_variants(monkeypatch):
    for val in ("0", "false", "FALSE", "No", "no"):
        monkeypatch.setenv("MESHCODE_AUTO_UPDATE", val)
        monkeypatch.delenv("MESHCODE_UPDATED", raising=False)
        assert _auto_update_inline_skeleton() == "disabled", f"value {val!r} failed"


# ---------------------------------------------------------------------------
# 4. PyPI/pip behaviour matrix (mocked — covers the cells that don't need
#    a live relaunch). Uses an inlined version of the post-gate _auto_update
#    body so we can drive each branch independently.
# ---------------------------------------------------------------------------

import json as _json
import subprocess as _sp
import urllib.request as _urlreq


def _ver_tuple(v):
    return tuple(int(x) for x in v.split(".") if x.isdigit())


def _auto_update_pypi_step(current, fake_latest, raise_on_open=None,
                           raise_on_pip=None, on_pip_call=None):
    """Inlined copy of the post-gate _auto_update logic.

    Returns one of {'no_latest', 'already_latest', 'pip_failed',
    'timeout', 'would_execv'} so each branch is observable.
    """
    if raise_on_open is not None:
        try:
            raise raise_on_open
        except Exception:
            return "no_latest"

    latest = fake_latest
    if not latest:
        return "no_latest"
    try:
        if _ver_tuple(latest) <= _ver_tuple(current):
            return "already_latest"
    except Exception:
        return "no_latest"

    # Mock pip install
    try:
        if raise_on_pip is _sp.TimeoutExpired:
            raise _sp.TimeoutExpired(cmd="pip", timeout=60)
        if raise_on_pip is not None:
            raise raise_on_pip
        if on_pip_call is not None:
            on_pip_call()
    except _sp.TimeoutExpired:
        return "timeout"
    except Exception:
        return "pip_failed"
    return "would_execv"


def test_pypi_newer_triggers_execv():
    pip_calls = []
    result = _auto_update_pypi_step(
        current="2.10.93",
        fake_latest="99.99.99",
        on_pip_call=lambda: pip_calls.append(1),
    )
    assert result == "would_execv"
    assert len(pip_calls) == 1


def test_pypi_same_no_op():
    pip_calls = []
    result = _auto_update_pypi_step(
        current="2.10.93",
        fake_latest="2.10.93",
        on_pip_call=lambda: pip_calls.append(1),
    )
    assert result == "already_latest"
    assert pip_calls == []


def test_pypi_older_no_op():
    pip_calls = []
    result = _auto_update_pypi_step(
        current="2.10.93",
        fake_latest="2.10.0",
        on_pip_call=lambda: pip_calls.append(1),
    )
    assert result == "already_latest"
    assert pip_calls == []


def test_offline_swallowed():
    result = _auto_update_pypi_step(
        current="2.10.93",
        fake_latest=None,
        raise_on_open=OSError("offline"),
    )
    assert result == "no_latest"


def test_pip_timeout_returns_gracefully():
    """Slow-net cell: pip exceeds 60s → graceful return, no execv."""
    result = _auto_update_pypi_step(
        current="2.10.93",
        fake_latest="99.99.99",
        raise_on_pip=_sp.TimeoutExpired,
    )
    assert result == "timeout"


def test_pip_install_failure_swallowed():
    result = _auto_update_pypi_step(
        current="2.10.93",
        fake_latest="99.99.99",
        raise_on_pip=RuntimeError("pip exploded"),
    )
    assert result == "pip_failed"


def test_version_compare_handles_non_numeric():
    """Pre-release strings ('2.10.93rc1') must not crash the comparator."""
    result = _auto_update_pypi_step(
        current="2.10.93",
        fake_latest="2.10.93rc1",
    )
    # _ver_tuple drops non-numeric segments — both reduce to (2,10,93),
    # so the path is "already_latest" (<=).
    assert result == "already_latest"
