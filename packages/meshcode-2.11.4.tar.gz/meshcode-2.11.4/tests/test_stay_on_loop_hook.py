"""Tests for the stop-hook MCP-unreachable release path.

Covers PROTO-MCP-UNREACHABLE-RELEASE (task d2bdc974). The hook lives at
.claude/hooks/stay_on_loop.py and is the gatekeeper that refuses to end
an agent's turn unless the agent called meshcode_wait or the user typed
a release keyword. When MCP itself drops (server crash / stdio close),
the agent has no way to call meshcode_wait — the hook used to keep
blocking forever, surfacing as "Type stop. Type stop." spam.

This test asserts the three branches of _mcp_unreachable_recently:
  1. registered+ok        — recent meshcode_wait tool_use with non-error
                            tool_result. Hook should NOT release on this
                            ground (the agent is fine).
  2. registered+errored   — recent meshcode_wait tool_use with is_error
                            or a known MCP-dead marker. Hook SHOULD
                            release.
  3. unregistered         — agent tried ToolSearch select:meshcode_wait
                            and got "no matching deferred tools found".
                            Hook SHOULD release.

Also covers main() end-to-end: feeds a transcript_path payload via stdin
and asserts decision==block vs sys.exit(0).
"""

from __future__ import annotations

import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from typing import Any, Dict, List


HOOK_PATH = Path(__file__).resolve().parent.parent / ".claude" / "hooks" / "stay_on_loop.py"


def _write_transcript(records: List[Dict[str, Any]], path: Path) -> None:
    with path.open("w", encoding="utf-8") as f:
        for rec in records:
            f.write(json.dumps(rec) + "\n")


def _wait_tool_use(use_id: str = "tu_1", suffix: str = "meshcode_wait") -> Dict[str, Any]:
    return {
        "role": "assistant",
        "content": [
            {"type": "tool_use", "id": use_id,
             "name": f"mcp__meshcode-test-tester__{suffix}",
             "input": {}},
        ],
    }


def _tool_result(use_id: str, *, is_error: bool = False, text: str = "") -> Dict[str, Any]:
    return {
        "role": "user",
        "content": [
            {"type": "tool_result", "tool_use_id": use_id,
             "is_error": is_error,
             "content": [{"type": "text", "text": text}]},
        ],
    }


def _toolsearch_wait_use(use_id: str = "ts_1") -> Dict[str, Any]:
    return {
        "role": "assistant",
        "content": [
            {"type": "tool_use", "id": use_id, "name": "ToolSearch",
             "input": {"query": "select:mcp__meshcode-test-tester__meshcode_wait"}},
        ],
    }


def _user_text(text: str) -> Dict[str, Any]:
    return {"role": "user", "content": text}


def _import_hook():
    """Import the hook module under a stable name for direct unit tests."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("stay_on_loop_hook", HOOK_PATH)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


# ─── Direct unit tests of _mcp_unreachable_recently ────────────────────────────

class TestMcpUnreachableDetector(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.hook = _import_hook()

    def _scenario(self, records):
        with tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False) as f:
            _write_transcript(records, Path(f.name))
            return Path(f.name)

    def test_branch_registered_ok_no_release(self):
        # Branch 1: meshcode_wait was called, returned successfully.
        # Hook should NOT classify as unreachable.
        path = self._scenario([
            _user_text("hi"),
            _wait_tool_use("tu_ok"),
            _tool_result("tu_ok", is_error=False,
                         text='{"got_message": false, "messages": []}'),
        ])
        try:
            self.assertFalse(self.hook._mcp_unreachable_recently(path),
                             "ok wait should not flag as unreachable")
        finally:
            path.unlink(missing_ok=True)

    def test_branch_registered_errored_releases(self):
        # Branch 2: meshcode_wait tool_result is_error=True OR contains
        # MCP-dead marker. Hook SHOULD classify as unreachable.
        path = self._scenario([
            _user_text("boot"),
            _wait_tool_use("tu_err"),
            _tool_result("tu_err", is_error=True, text="MCP server connection closed"),
        ])
        try:
            self.assertTrue(self.hook._mcp_unreachable_recently(path),
                            "is_error=True wait result must classify as unreachable")
        finally:
            path.unlink(missing_ok=True)

    def test_branch_registered_errored_via_marker(self):
        # Branch 2b: tool_result not flagged is_error but body contains
        # a known dead marker (mcp error / no such tool / connection closed).
        path = self._scenario([
            _user_text("boot"),
            _wait_tool_use("tu_marker"),
            _tool_result("tu_marker", is_error=False,
                         text="Error: No such tool available"),
        ])
        try:
            self.assertTrue(self.hook._mcp_unreachable_recently(path),
                            "MCP-dead marker text in tool_result must classify as unreachable")
        finally:
            path.unlink(missing_ok=True)

    def test_branch_unregistered_via_toolsearch_miss(self):
        # Branch 3: agent attempted ToolSearch select:meshcode_wait and
        # got "no matching deferred tools found". The MCP server is down
        # entirely. Hook SHOULD classify as unreachable.
        path = self._scenario([
            _user_text("boot"),
            _toolsearch_wait_use("ts_miss"),
            _tool_result("ts_miss", is_error=False,
                         text="No matching deferred tools found"),
        ])
        try:
            self.assertTrue(self.hook._mcp_unreachable_recently(path),
                            "ToolSearch miss for meshcode_wait must classify as unreachable")
        finally:
            path.unlink(missing_ok=True)

    def test_no_recent_activity_returns_false(self):
        # Sanity: empty / unrelated transcript = not unreachable. Hook
        # falls through to the standard "demand meshcode_wait" path.
        path = self._scenario([
            _user_text("hi"),
            {"role": "assistant", "content": [{"type": "text", "text": "hello"}]},
        ])
        try:
            self.assertFalse(self.hook._mcp_unreachable_recently(path),
                             "no wait/toolsearch activity => not unreachable")
        finally:
            path.unlink(missing_ok=True)


# ─── End-to-end main() via subprocess + stdin payload ──────────────────────────

class TestStopHookMain(unittest.TestCase):
    """Drive main() exactly like Claude Code does: stdin = payload JSON,
    decision = stdout JSON ({"decision": "block", ...}) or empty + exit 0."""

    def _run_hook(self, payload: dict) -> tuple[int, str]:
        proc = subprocess.run(
            [sys.executable, str(HOOK_PATH)],
            input=json.dumps(payload).encode("utf-8"),
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=10,
        )
        return proc.returncode, proc.stdout.decode("utf-8")

    def _scenario_path(self, records):
        f = tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False)
        _write_transcript(records, Path(f.name))
        f.close()
        return f.name

    def test_release_when_user_says_stop(self):
        path = self._scenario_path([_user_text("stop")])
        try:
            rc, out = self._run_hook({"transcript_path": path})
            self.assertEqual(rc, 0)
            self.assertEqual(out.strip(), "",
                             "release keyword path must not emit a block decision")
        finally:
            os.unlink(path)

    def test_release_when_mcp_unreachable(self):
        # The release-because-MCP-is-dead path: errored wait result.
        path = self._scenario_path([
            _user_text("boot"),
            _wait_tool_use("tu_err"),
            _tool_result("tu_err", is_error=True, text="connection closed"),
        ])
        try:
            rc, out = self._run_hook({"transcript_path": path})
            self.assertEqual(rc, 0)
            self.assertEqual(out.strip(), "",
                             "MCP-unreachable path must release without blocking")
        finally:
            os.unlink(path)

    def test_block_when_neither_release_nor_unreachable(self):
        # Healthy session, agent ended turn without meshcode_wait — hook
        # SHOULD emit a block decision so the agent is forced to retry.
        path = self._scenario_path([
            _user_text("hello"),
            {"role": "assistant", "content": [{"type": "text", "text": "hi back"}]},
        ])
        try:
            rc, out = self._run_hook({"transcript_path": path})
            self.assertEqual(rc, 0,
                             "hook always exits 0 — decision is in stdout")
            payload = json.loads(out)
            self.assertEqual(payload.get("decision"), "block")
            self.assertIn("meshcode_wait", payload.get("reason", ""))
        finally:
            os.unlink(path)

    def test_release_when_last_assistant_called_wait(self):
        path = self._scenario_path([
            _user_text("hi"),
            _wait_tool_use("tu_active"),
        ])
        try:
            rc, out = self._run_hook({"transcript_path": path})
            self.assertEqual(rc, 0)
            self.assertEqual(out.strip(), "",
                             "last turn called wait => release without blocking")
        finally:
            os.unlink(path)

    def test_release_when_wait_result_has_must_exit(self):
        # Condition (c) from the merged hook: a meshcode_wait that
        # returned must_exit=True must release the loop. Locks in the
        # 2026-05-05 sleep-authorization fix alongside the unreachable
        # detection so neither regresses the other.
        path = self._scenario_path([
            _user_text("hi"),
            _wait_tool_use("tu_must_exit"),
            _tool_result("tu_must_exit", is_error=False,
                         text=json.dumps({"must_exit": True,
                                          "reason": "got_done"})),
            {"role": "assistant",
             "content": [{"type": "text", "text": "going to sleep"}]},
        ])
        try:
            rc, out = self._run_hook({"transcript_path": path})
            self.assertEqual(rc, 0)
            self.assertEqual(out.strip(), "",
                             "must_exit=True from wait result must release "
                             "without blocking")
        finally:
            os.unlink(path)

    def test_release_when_wait_result_has_done_signals(self):
        path = self._scenario_path([
            _user_text("hi"),
            _wait_tool_use("tu_signals"),
            _tool_result("tu_signals", is_error=False,
                         text=json.dumps({
                             "messages": [],
                             "done_signals": [{"from": "mesh-commander",
                                               "kind": "got_done"}],
                         })),
            {"role": "assistant",
             "content": [{"type": "text", "text": "ack got_done"}]},
        ])
        try:
            rc, out = self._run_hook({"transcript_path": path})
            self.assertEqual(rc, 0)
            self.assertEqual(out.strip(), "",
                             "non-empty done_signals from wait result must "
                             "release without blocking")
        finally:
            os.unlink(path)


if __name__ == "__main__":
    unittest.main()
