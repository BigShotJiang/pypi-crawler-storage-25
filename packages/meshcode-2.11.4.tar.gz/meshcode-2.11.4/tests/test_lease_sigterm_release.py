"""Test PROTO-LEASE-SIGTERM-RELEASE — synchronous + opt-in SIGTERM lease release.

Covers:
- AST presence: helpers defined, env-flag opt-in, lifespan finally calls
  _release_lease_synchronous.
- Functional: _release_lease_synchronous returns within budget, idempotent,
  falls back to direct call when threading breaks.
- Subprocess: spawn meshcode MCP pointed at a stub Supabase, send SIGTERM,
  assert /rpc/mc_release_agent_lease is hit within 500ms when
  MESHCODE_GRACEFUL_SIGTERM=1, AND that without the env var the SIG_IGN
  cancellation-safety behavior is preserved (no early exit).

Why tests cover both layers: the task RCA (project_mesh_commander_mcp_failed_at_launch
#2) is "SIGKILL leaves DB lease orphaned causing 6-8s relaunch hang." The
SIGTERM handler closes the graceful-exit gap without breaking the SIG_IGN
ESC-cancellation safety from feedback_phantom_mcp_orphan_race / 2.10.92.
"""

from __future__ import annotations

import ast
import http.server
import json
import os
import re
import signal
import socket
import subprocess
import sys
import threading
import time
import unittest
from pathlib import Path
from typing import List, Tuple


ROOT = Path(__file__).resolve().parent.parent
SERVER_PY = ROOT / "meshcode" / "meshcode_mcp" / "server.py"


# ─── Layer 1: AST presence ──────────────────────────────────────────────────────

class TestLeaseSigtermAST(unittest.TestCase):
    """Static checks that the new helpers + wire-ups are present in server.py."""

    @classmethod
    def setUpClass(cls):
        cls.source = SERVER_PY.read_text()
        cls.tree = ast.parse(cls.source)

    def _funcs(self):
        return {
            n.name: n
            for n in ast.walk(self.tree)
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
        }

    def test_release_lease_synchronous_defined(self):
        funcs = self._funcs()
        self.assertIn("_release_lease_synchronous", funcs,
                      "expected _release_lease_synchronous helper")
        # Must accept timeout_s and return bool semantics (uses Event.wait)
        body_src = ast.get_source_segment(self.source, funcs["_release_lease_synchronous"])
        assert body_src is not None
        self.assertIn("timeout_s", body_src)
        self.assertIn(".wait(", body_src,
                      "must await the worker thread via Event.wait(timeout=...)")

    def test_shutdown_signal_handler_defined(self):
        funcs = self._funcs()
        self.assertIn("_shutdown_signal_handler", funcs)
        body_src = ast.get_source_segment(self.source, funcs["_shutdown_signal_handler"]) or ""
        self.assertIn("MESHCODE_UPDATING", body_src,
                      "handler must skip release during auto-update re-exec")
        self.assertIn("os._exit(0)", body_src,
                      "handler must terminate via os._exit, not sys.exit (signal-safe)")
        self.assertIn("_release_lease_synchronous", body_src)

    def test_install_handlers_is_opt_in(self):
        funcs = self._funcs()
        self.assertIn("_install_shutdown_signal_handlers", funcs)
        body_src = ast.get_source_segment(self.source, funcs["_install_shutdown_signal_handlers"]) or ""
        self.assertIn("MESHCODE_GRACEFUL_SIGTERM", body_src,
                      "registration must be gated on env flag (preserves SIG_IGN default)")
        self.assertIn("SIGTERM", body_src)

    def test_lifespan_finally_calls_synchronous_release(self):
        # The synchronous release must appear inside the lifespan finally,
        # AFTER the daemon-thread bg_cleanup spawn (so the in-flight
        # memory-write thread is at least kicked off before the
        # lease-release deadline). Use rfind to skip the earlier call
        # site inside _shutdown_signal_handler.
        idx_thread = self.source.find("Thread(target=_bg_cleanup")
        idx_sync_last = self.source.rfind("_release_lease_synchronous(timeout_s=")
        self.assertGreater(idx_thread, 0, "expected _bg_cleanup daemon spawn in lifespan")
        self.assertGreater(idx_sync_last, idx_thread,
                           "expected synchronous release AFTER daemon spawn so memory writes "
                           "still get queued before the lease-release deadline")

    def test_install_handlers_called_from_lifespan_startup(self):
        # The opt-in registration should fire AT lifespan start so the
        # agent identity (PROJECT_ID, AGENT_NAME, _INSTANCE_ID) is loaded.
        idx_install = self.source.find("_install_shutdown_signal_handlers()")
        idx_lifespan_started_log = self.source.find('lifespan started — Realtime')
        self.assertGreater(idx_install, 0, "expected install call in lifespan startup")
        self.assertGreater(idx_lifespan_started_log, idx_install,
                           "install must precede the 'lifespan started' log so handlers "
                           "are registered before tools are accepted")


# ─── Layer 2: Functional tests via mocked module ───────────────────────────────

class _StubBackend:
    """Stub for backend.py's sb_rpc — records calls + simulates latency."""

    def __init__(self, latency_s: float = 0.0):
        self.latency_s = latency_s
        self.calls: List[Tuple[str, dict]] = []
        self._lock = threading.Lock()

    def sb_rpc(self, fn_name, params, **_kw):
        if self.latency_s:
            time.sleep(self.latency_s)
        with self._lock:
            self.calls.append((fn_name, params))
        return {"ok": True}


class TestReleaseLeaseSynchronous(unittest.TestCase):
    """Direct functional tests of _release_lease_synchronous via stubbed module."""

    @classmethod
    def setUpClass(cls):
        # Build a thin module that mirrors server.py's helper, since
        # importing server.py requires a live Supabase. Re-implementing
        # _release_lease_synchronous would defeat the test, so instead
        # we exec ONLY the relevant block from server.py in a fresh
        # namespace with stubbed dependencies. This keeps the test
        # honest: the real helper text is what runs.
        src = SERVER_PY.read_text()
        # Pull out the _release_lease_synchronous + _shutdown_signal_handler
        # block (between markers) plus the global guard.
        match = re.search(
            r"_SHUTDOWN_LEASE_RELEASED = False\s*\n\n"
            r"def _release_lease_synchronous\(.*?\n"
            r"(?=def _install_shutdown_signal_handlers)",
            src,
            re.DOTALL,
        )
        assert match, "could not extract _release_lease_synchronous block"
        block = "_SHUTDOWN_LEASE_RELEASED = False\n\n" + match.group(0)
        cls._block = block

    def _fresh_namespace(self, latency_s: float = 0.0):
        backend = _StubBackend(latency_s=latency_s)
        ns: dict = {
            "_threading": threading,
            "_release_lease": lambda: backend.sb_rpc("mc_release_agent_lease", {}),
            "be": backend,
        }
        exec(compile(self._block, "<extracted>", "exec"), ns)
        return ns, backend

    def test_completes_fast_path_within_budget(self):
        ns, backend = self._fresh_namespace(latency_s=0.05)
        t0 = time.monotonic()
        ok = ns["_release_lease_synchronous"](timeout_s=1.0)
        elapsed = time.monotonic() - t0
        self.assertTrue(ok, "should return True when worker finished within budget")
        self.assertLess(elapsed, 1.0)
        self.assertEqual(len(backend.calls), 1)
        self.assertEqual(backend.calls[0][0], "mc_release_agent_lease")

    def test_idempotent_only_calls_once(self):
        ns, backend = self._fresh_namespace(latency_s=0.0)
        ns["_release_lease_synchronous"](timeout_s=0.5)
        ns["_release_lease_synchronous"](timeout_s=0.5)
        self.assertEqual(len(backend.calls), 1,
                         "second invocation must short-circuit (idempotent guard)")

    def test_returns_false_on_timeout(self):
        ns, backend = self._fresh_namespace(latency_s=2.0)
        t0 = time.monotonic()
        ok = ns["_release_lease_synchronous"](timeout_s=0.3)
        elapsed = time.monotonic() - t0
        self.assertFalse(ok, "should return False when worker exceeds budget")
        # We did not wait the full 2.0s; we abandoned at ~0.3s.
        self.assertLess(elapsed, 1.0,
                        "must abandon at timeout, not wait for worker to finish")


# ─── Layer 3: subprocess + signal + stub Supabase ──────────────────────────────

class _StubSupabaseHandler(http.server.BaseHTTPRequestHandler):
    received: list = []  # class-level so the harness can read it

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length) if length else b""
        try:
            payload = json.loads(body.decode("utf-8")) if body else {}
        except Exception:
            payload = {"_raw": body[:200].decode("utf-8", errors="replace")}
        self.__class__.received.append((self.path, payload, time.monotonic()))
        # Always 200 OK with empty array — keeps meshcode boot-checks happy.
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(b"{}")

    def log_message(self, *_a, **_kw):  # silence noisy stderr
        pass


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@unittest.skipUnless(
    os.environ.get("MESHCODE_RUN_SIGTERM_INTEGRATION") == "1",
    "Subprocess+signal integration disabled by default. Set "
    "MESHCODE_RUN_SIGTERM_INTEGRATION=1 to run (CI-only).",
)
class TestSigtermSubprocess(unittest.TestCase):
    """End-to-end: spawn server pointing at a stub Supabase, send SIGTERM,
    assert mc_release_agent_lease was hit within 500ms when the opt-in env
    flag is set, AND that without it the dying process does not call the
    release endpoint (because SIG_IGN keeps the process alive).
    """

    def _spawn_with_stub(self, *, opt_in: bool):
        port = _free_port()
        _StubSupabaseHandler.received = []
        server = http.server.ThreadingHTTPServer(("127.0.0.1", port), _StubSupabaseHandler)
        t = threading.Thread(target=server.serve_forever, daemon=True)
        t.start()

        env = os.environ.copy()
        env.update({
            "SUPABASE_URL": f"http://127.0.0.1:{port}",
            "SUPABASE_KEY": "stub",
            "MESHCODE_PROJECT": "test-mesh",
            "MESHCODE_AGENT": "tester",
            "MESHCODE_DISABLE_LIFESPAN": "0",
        })
        if opt_in:
            env["MESHCODE_GRACEFUL_SIGTERM"] = "1"
        else:
            env.pop("MESHCODE_GRACEFUL_SIGTERM", None)

        proc = subprocess.Popen(
            [sys.executable, "-m", "meshcode.meshcode_mcp"],
            env=env, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        # Give it a moment to boot / register handlers
        time.sleep(2.0)
        return proc, server

    def test_optin_release_within_500ms(self):
        proc, server = self._spawn_with_stub(opt_in=True)
        try:
            t0 = time.monotonic()
            proc.send_signal(signal.SIGTERM)
            proc.wait(timeout=3.0)
            elapsed_ms = (time.monotonic() - t0) * 1000
            release_calls = [
                r for r in _StubSupabaseHandler.received
                if "mc_release_agent_lease" in r[0]
            ]
            self.assertGreaterEqual(len(release_calls), 1,
                                    "expected mc_release_agent_lease hit on SIGTERM")
            self.assertLess(elapsed_ms, 500,
                            f"release+exit took {elapsed_ms:.0f}ms (>500ms budget)")
        finally:
            try: proc.kill()
            except Exception: pass
            server.shutdown()

    def test_no_optin_keeps_sigign_safety(self):
        proc, server = self._spawn_with_stub(opt_in=False)
        try:
            proc.send_signal(signal.SIGTERM)
            # Without opt-in, SIG_IGN should keep us alive — give it 1.5s
            # to NOT die.
            time.sleep(1.5)
            self.assertIsNone(proc.poll(),
                              "without MESHCODE_GRACEFUL_SIGTERM, SIGTERM must be "
                              "ignored to preserve ESC-cancellation safety")
        finally:
            try: proc.kill()
            except Exception: pass
            server.shutdown()


if __name__ == "__main__":
    unittest.main()
