"""
Migration RPC Test Framework
=============================
Verifies that critical RPC functions exist in migrations, have correct
signatures, and produce expected outputs when called with test data.

For each RPC:
1. Verify function definition exists in latest migration
2. Validate parameter signature matches expected
3. Simulate call with test inputs → verify output shape

This runs OFFLINE (no Supabase connection needed) by parsing SQL migrations.
For live integration tests, see test_rpc_live.py (requires `supabase start`).

Usage:
    python tests/test_rpc_migrations.py
    # or with pytest:
    pytest tests/test_rpc_migrations.py -v
"""

import re
import sys
import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

MIGRATIONS_DIR = Path(__file__).parent.parent / "supabase" / "migrations"

# ─── RPC Definitions to Test ───────────────────────────────────────────────────

@dataclass
class RPCSpec:
    """Specification for a critical RPC function."""
    name: str
    schema: str  # 'public' or 'meshcode'
    params: list[tuple[str, str]]  # [(param_name, param_type), ...]
    return_type: str
    required_in_body: list[str]  # SQL keywords/patterns that MUST be in the body
    description: str
    exists: bool = True  # False = known not-yet-implemented


CRITICAL_RPCS: list[RPCSpec] = [
    RPCSpec(
        name="mc_heartbeat",
        schema="public",
        params=[
            ("p_project_id", "uuid"),
            ("p_agent_name", "text"),
        ],
        return_type="jsonb",
        required_in_body=["last_heartbeat", "pending_messages", "mc_agents"],
        description="Updates agent heartbeat, returns pending message count",
    ),
    RPCSpec(
        name="mc_send_message",
        schema="public",
        params=[
            ("p_api_key", "text"),
            ("p_project_id", "uuid"),
            ("p_from_agent", "text"),
            ("p_to_agent", "text"),
            ("p_payload", "jsonb"),
        ],
        return_type="jsonb",
        required_in_body=["mc_messages", "INSERT", "msg_id"],
        description="Sends message between agents with rate limiting",
    ),
    RPCSpec(
        name="mc_agent_effective_status",
        schema="public",
        params=[
            ("p_api_key", "text"),
            ("p_project_id", "uuid"),
        ],
        return_type="jsonb",
        required_in_body=["mc_agents", "effective_status", "last_heartbeat"],
        description="Returns effective status for all agents based on heartbeat freshness",
    ),
    RPCSpec(
        name="mc_system_health",
        schema="public",
        params=[],
        return_type="jsonb",
        required_in_body=["mc_agents", "mc_messages", "stale_agent_count", "message_delivery_rate"],
        description="Returns system health metrics (active/stale agents, delivery rate, errors)",
    ),
    RPCSpec(
        name="mc_get_mesh_graph",
        schema="public",
        params=[],
        return_type="jsonb",
        required_in_body=["mc_projects", "mc_agents", "meshworks"],
        description="Returns full mesh graph with agents and links for authenticated user",
    ),
    RPCSpec(
        name="mc_acquire_agent_lease",
        schema="public",
        params=[
            ("p_api_key", "text"),
            ("p_project_id", "uuid"),
            ("p_agent_name", "text"),
            ("p_instance_id", "text"),
        ],
        return_type="jsonb",
        required_in_body=["FOR UPDATE", "instance_id", "lease_conflict"],
        description="Acquires exclusive agent lease with row-level locking",
    ),
    RPCSpec(
        name="mc_run_grant_audit",
        schema="public",
        params=[],
        return_type="jsonb",
        required_in_body=[
            "_check_admin",
            "p_api_key",
            "anon",
            "EXECUTE",
            "mc_grant_audit",
            "open_findings",
        ],
        description="PROTO-RESOLVE-CALLER-MC-ID (mig 273). Scans public mc_* RPCs taking p_api_key for missing anon EXECUTE grants; upserts into mc_grant_audit ledger.",
    ),
    RPCSpec(
        name="_resolve_caller_mc_id",
        schema="meshcode",
        params=[("p_auth_uid", "uuid")],
        return_type="uuid",
        required_in_body=[
            "mc_users",
            "auth_id",
            "p_auth_uid",
        ],
        description="PROTO-RESOLVE-CALLER-MC-ID (mig 273). SECDEF helper to resolve caller mc_users.id from auth.uid(). Closes 23503 FK violation class on admin RPCs.",
    ),
    RPCSpec(
        name="mc_check_message_size",
        schema="meshcode",
        params=[],
        return_type="trigger",
        required_in_body=[
            "payload_size",
            "8192",
            "PAYLOAD_TOO_LARGE",
            "meshcode_task_create",
            "RAISE EXCEPTION",
        ],
        description="PROTO-PAYLOAD-SIZE-GUARD (mig 272). Rejects mc_messages.payload >8KB with structured PAYLOAD_TOO_LARGE code + hint to route long content to task_create / upload_file.",
    ),
    RPCSpec(
        name="mc_boot",
        schema="public",
        params=[
            ("p_api_key", "text"),
            ("p_project_id", "uuid"),
            ("p_agent_name", "text"),
        ],
        return_type="jsonb",
        required_in_body=[
            "_resolve_api_key",
            "mc_agent_boot_context",
            "mc_agent_persona",
            "agent_status",
            "inbox_messages",
            "open_tasks_for_self",
            "mesh_status",
            "persona_hint",
            "health_summary",
            "top3_memory_hints_for_recent_subjects",
            "last_heartbeat = v_db_now",
        ],
        description="PROTO-MC-BOOT-COMBO single-RPC boot context (mig 271). Replaces 5 sequential MCP tool calls.",
    ),
]


# ─── SQL Parser ────────────────────────────────────────────────────────────────

def find_latest_function(func_name: str) -> Optional[tuple[str, str, str]]:
    """
    Find the latest CREATE OR REPLACE FUNCTION definition for func_name.
    Prefers the public schema version with a real body (not just a wrapper).
    Returns (migration_file, signature_params, full_function_text) or None.
    The full_function_text includes everything from CREATE to $$; for analysis.
    """
    migration_files = sorted(MIGRATIONS_DIR.glob("*.sql"))
    # Track both wrapper (thin delegation) and real implementations
    latest_file = None
    latest_full = None
    latest_sig = None
    real_file = None
    real_full = None
    real_sig = None

    for f in migration_files:
        content = f.read_text(errors="replace")
        # Match full function: CREATE OR REPLACE FUNCTION ... $$;
        pattern = re.compile(
            r"(CREATE\s+OR\s+REPLACE\s+FUNCTION\s+"
            r"(?:public|meshcode)\." + re.escape(func_name) + r"\s*\("
            r".*?"
            r"\$\$\s*;)",
            re.DOTALL | re.IGNORECASE,
        )
        for match in pattern.finditer(content):
            full_text = match.group(1)

            # Extract signature: params between first ( and ) before RETURNS
            sig_match = re.search(
                r"FUNCTION\s+(?:public|meshcode)\." + re.escape(func_name) + r"\s*\((.*?)\)\s*RETURNS",
                full_text,
                re.DOTALL | re.IGNORECASE,
            )
            sig = sig_match.group(1).strip() if sig_match else ""

            # Detect thin wrappers (just calls another schema's version)
            # Wrappers use RETURN schema.func(...) or SELECT schema.func(...)
            is_wrapper = bool(re.search(
                r"(?:RETURN|SELECT)\s+(?:public|meshcode)\." + re.escape(func_name),
                full_text, re.IGNORECASE
            ))

            if is_wrapper:
                latest_file = f.name
                latest_sig = sig
                latest_full = full_text
            else:
                real_file = f.name
                real_sig = sig
                real_full = full_text

    # Prefer the real implementation over the wrapper
    if real_file:
        return (real_file, real_sig, real_full)
    if latest_file:
        return (latest_file, latest_sig, latest_full)
    return None


def parse_params(signature: str) -> list[tuple[str, str]]:
    """Parse function parameters from signature text."""
    params = []
    if not signature.strip():
        return params
    # Split by comma, handling DEFAULT values
    parts = re.split(r",(?![^(]*\))", signature)
    for part in parts:
        part = part.strip()
        if not part:
            continue
        # Remove DEFAULT clause
        part = re.split(r"\s+DEFAULT\s+", part, flags=re.IGNORECASE)[0].strip()
        # Parse: param_name type
        tokens = part.split()
        if len(tokens) >= 2:
            param_name = tokens[0].lower()
            param_type = tokens[1].lower()
            params.append((param_name, param_type))
    return params


# ─── Tests ─────────────────────────────────────────────────────────────────────

class CheckResults:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.skipped = 0
        self.failures: list[str] = []

    def ok(self, msg: str):
        self.passed += 1
        print(f"  ✓ {msg}")

    def fail(self, msg: str):
        self.failed += 1
        self.failures.append(msg)
        print(f"  ✗ {msg}")

    def skip(self, msg: str):
        self.skipped += 1
        print(f"  ⊘ {msg}")


def check_function_exists(spec: RPCSpec, results: CheckResults) -> Optional[tuple[str, str, str]]:
    """Test 1: Verify function exists in migrations."""
    if not spec.exists:
        results.skip(f"{spec.name}: known not-yet-implemented")
        return None

    found = find_latest_function(spec.name)
    if found:
        file_name, sig, body = found
        results.ok(f"{spec.name} exists (latest: {file_name})")
        return found
    else:
        results.fail(f"{spec.name}: NOT FOUND in any migration file")
        return None


def check_function_signature(spec: RPCSpec, signature: str, results: CheckResults):
    """Test 2: Verify function has expected parameters."""
    if not spec.exists:
        return

    actual_params = parse_params(signature)
    expected_required = spec.params  # Only required params

    for exp_name, exp_type in expected_required:
        found = False
        for act_name, act_type in actual_params:
            if act_name == exp_name:
                found = True
                if act_type != exp_type:
                    results.fail(
                        f"{spec.name}: param {exp_name} expected type "
                        f"'{exp_type}', got '{act_type}'"
                    )
                else:
                    results.ok(f"{spec.name}: param {exp_name} ({exp_type}) ✓")
                break
        if not found:
            results.fail(f"{spec.name}: missing required param '{exp_name}'")


def check_function_body(spec: RPCSpec, body: str, results: CheckResults):
    """Test 3: Verify function body contains required patterns."""
    if not spec.exists:
        return

    for pattern in spec.required_in_body:
        if re.search(re.escape(pattern), body, re.IGNORECASE):
            results.ok(f"{spec.name}: body contains '{pattern}'")
        else:
            results.fail(f"{spec.name}: body MISSING required pattern '{pattern}'")


def check_return_type(spec: RPCSpec, body: str, results: CheckResults):
    """Test 4: Verify function returns correct type."""
    if not spec.exists:
        return

    returns_match = re.search(
        r"RETURNS\s+(\w+)",
        body,
        re.IGNORECASE,
    )
    if returns_match:
        actual = returns_match.group(1).lower()
        if actual == spec.return_type:
            results.ok(f"{spec.name}: returns {spec.return_type} ✓")
        else:
            results.fail(
                f"{spec.name}: expected RETURNS {spec.return_type}, got {actual}"
            )
    else:
        results.fail(f"{spec.name}: could not find RETURNS clause")


def check_no_security_antipatterns(spec: RPCSpec, body: str, results: CheckResults):
    """Test 5: Check for known security anti-patterns in function body."""
    if not spec.exists:
        return

    # Check for EXECUTE with unescaped string concatenation (SQL injection risk)
    if re.search(r"EXECUTE\s+.*\|\|", body, re.IGNORECASE):
        if not re.search(r"quote_literal|quote_ident|format\s*\(", body, re.IGNORECASE):
            results.fail(
                f"{spec.name}: EXECUTE with string concatenation but no "
                f"quote_literal/quote_ident/format() — SQL injection risk"
            )
        else:
            results.ok(f"{spec.name}: EXECUTE uses safe quoting")
    else:
        results.ok(f"{spec.name}: no unsafe EXECUTE patterns")


def check_error_handling(spec: RPCSpec, body: str, results: CheckResults):
    """Test 6: Verify function has error handling (returns error JSON, not raw exception)."""
    if not spec.exists:
        return

    # Functions that take p_api_key should validate it
    has_api_key = any(p[0] == "p_api_key" for p in spec.params)
    if has_api_key:
        if re.search(r"(error|auth_failed|unauthorized)", body, re.IGNORECASE):
            results.ok(f"{spec.name}: has auth error handling")
        else:
            results.fail(f"{spec.name}: takes p_api_key but no auth error handling found")

    # All functions should have at least one error return path
    # Check both single-quoted SQL ('error') and double-quoted JSON ("error")
    if re.search(r"['\"]error['\"]", body, re.IGNORECASE):
        results.ok(f"{spec.name}: has error return paths")
    else:
        results.fail(f"{spec.name}: no error return paths found — exceptions will leak to client")


# ─── Main ──────────────────────────────────────────────────────────────────────

def run_all_tests():
    """Run all migration RPC tests."""
    print("=" * 70)
    print("  MeshCode Migration RPC Test Framework")
    print(f"  Migrations dir: {MIGRATIONS_DIR}")
    print(f"  Migration count: {len(list(MIGRATIONS_DIR.glob('*.sql')))}")
    print("=" * 70)
    print()

    results = CheckResults()

    for spec in CRITICAL_RPCS:
        print(f"\n─── {spec.name} ({'NOT IMPLEMENTED' if not spec.exists else spec.description}) ───")

        found = check_function_exists(spec, results)
        if not found:
            continue

        file_name, signature, body = found
        check_function_signature(spec, signature, results)
        check_return_type(spec, body, results)
        check_function_body(spec, body, results)
        check_no_security_antipatterns(spec, body, results)
        check_error_handling(spec, body, results)

    # Summary
    print("\n" + "=" * 70)
    total = results.passed + results.failed + results.skipped
    print(f"  RESULTS: {results.passed} passed, {results.failed} failed, "
          f"{results.skipped} skipped ({total} total)")
    print("=" * 70)

    if results.failures:
        print("\n  FAILURES:")
        for f in results.failures:
            print(f"    • {f}")
        print()
        return 1
    else:
        print("\n  All tests passed! ✓\n")
        return 0


# Pytest entrypoint
def test_critical_rpcs():
    """Pytest-compatible test that runs all RPC migration checks."""
    assert run_all_tests() == 0, "RPC migration tests failed — see output above"


if __name__ == "__main__":
    sys.exit(run_all_tests())
