"""Per-agent workspace creator for `meshcode setup`.

NEW MODEL (1.3.0): instead of polluting the user's global MCP config
(~/.claude.json, ~/.cursor/mcp.json, ...), each `meshcode setup <project>
<agent>` creates an isolated workspace directory at:

    ~/meshcode/<project>-<agent>/

containing a single .mcp.json with ONLY that agent's MCP server entry.
The user then runs `meshcode run <agent>` to launch their editor with
that workspace, and ONLY that one agent goes online. Closing the editor
window flips the agent offline. No cross-window status pollution.

Backward compatibility: the old `meshcode setup <client> <project>
<agent>` form still works for the global-config flow (kept for users
on Claude Desktop, which doesn't support per-instance MCP configs).
"""
import json
import os
import platform
import sys
from pathlib import Path
from typing import Dict, Any, Optional

from meshcode.exceptions import AuthError, RPCError, MeshCodeConnectionError


def _load_credentials(profile: str = "default") -> Dict[str, str]:
    """Load the api key + non-secret metadata for the given keychain profile.

    1.4.1+ stores api keys in the OS keychain. The api key is read from there
    via the secrets module. Non-secret metadata (user_id / email / display_name)
    lives in ~/.meshcode/profile_meta.json. Falls back to the legacy
    credentials.json file if the migration hasn't run yet (e.g. first run after
    upgrade).
    """
    try:
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
    except Exception as e:
        raise AuthError(f"cannot load secrets module: {e}") from e

    api_key = secrets_mod.get_api_key(profile=profile)
    if not api_key:
        raise AuthError(
            "No credentials found. You need to log in first.\n"
            "\n"
            "  1. Get your API key at: https://meshcode.io/onboarding\n"
            "     (or https://meshcode.io/settings if you already have an account)\n"
            "  2. Run: meshcode login mc_<your-api-key>\n"
            "  3. Then re-run this command."
        )

    meta_path = Path.home() / ".meshcode" / "profile_meta.json"
    meta: Dict[str, Any] = {"api_key": api_key}
    if meta_path.exists():
        try:
            extra = json.loads(meta_path.read_text(encoding="utf-8"))
            if isinstance(extra, dict):
                meta.update({k: v for k, v in extra.items() if v is not None})
        except Exception:
            pass
    # Legacy fallback (pre-1.4.1): if profile_meta.json doesn't exist, try the
    # old credentials.json for non-secret fields. The api key itself is already
    # in keychain by now (via migrate_legacy_credentials).
    legacy_path = Path.home() / ".meshcode" / "credentials.json"
    if legacy_path.exists() and not meta_path.exists():
        try:
            legacy = json.loads(legacy_path.read_text(encoding="utf-8"))
            if isinstance(legacy, dict):
                for k in ("user_id", "email", "display_name"):
                    if legacy.get(k) and not meta.get(k):
                        meta[k] = legacy[k]
        except Exception:
            pass
    return meta


def _load_supabase_env() -> Dict[str, str]:
    """Read SUPABASE_URL/SUPABASE_KEY from env or ~/.meshcode/env, fall back to publishable defaults."""
    url = os.environ.get("SUPABASE_URL", "")
    key = os.environ.get("SUPABASE_KEY", "")
    if not url or not key:
        env_file = Path.home() / ".meshcode" / "env"
        if env_file.exists():
            for line in env_file.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line.startswith("export "):
                    line = line[7:]
                if "=" in line:
                    k, v = line.split("=", 1)
                    v = v.strip().strip('"').strip("'")
                    if k == "SUPABASE_URL" and not url:
                        url = v
                    elif k == "SUPABASE_KEY" and not key:
                        key = v
    if not url:
        url = "https://gjinagyyjttyxnaoavnz.supabase.co"
    if not key:
        key = "sb_publishable_qwN9PO1L7jUXhhbhhVk2CQ_z1FXG2Qf"
    return {"SUPABASE_URL": url, "SUPABASE_KEY": key}


def _resolve_project_id(api_key: str, project: str, sb: Dict[str, str]) -> str:
    """Call mc_resolve_project SECURITY DEFINER RPC to get the project_id."""
    try:
        from urllib.request import Request as _Req, urlopen as _urlopen
        body = json.dumps({"p_api_key": api_key, "p_project_name": project}).encode()
        req = _Req(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_resolve_project",
            data=body,
            method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
            },
        )
        with _urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            if isinstance(data, dict) and data.get("project_id"):
                return data["project_id"]
            if isinstance(data, dict) and data.get("error"):
                # Build a helpful message including the user's actual projects
                hint = _suggest_projects_str(api_key, sb)
                msg = f"could not resolve project '{project}': {data['error']}"
                if hint:
                    msg += f"\n{hint}"
                raise RPCError(msg, rpc_name="mc_resolve_project", detail=data["error"])
    except (RPCError, AuthError):
        raise
    except Exception as e:
        raise MeshCodeConnectionError(
            f"could not resolve project '{project}': {e}\n"
            f"Check your API key and project name. Get help at https://meshcode.io/docs"
        ) from e
    return ""


def _suggest_projects_str(api_key: str, sb: dict) -> str:
    """Try to list the user's projects; return a hint string (or empty)."""
    try:
        from urllib.request import Request as _Req, urlopen as _urlopen
        body = json.dumps({"p_api_key": api_key}).encode()
        req = _Req(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_list_user_projects",
            data=body,
            method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
            },
        )
        with _urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
        projects = data.get("projects", []) if isinstance(data, dict) else []
        if projects:
            lines = ["Your projects:"]
            for p in projects:
                lines.append(f"  - {p['name']}")
            return "\n".join(lines)
    except Exception:
        pass
    return ""


def _suggest_projects(api_key: str, sb: dict):
    """Print the user's projects to stderr (CLI convenience wrapper)."""
    hint = _suggest_projects_str(api_key, sb)
    if hint:
        for line in hint.splitlines():
            print(f"[meshcode] {line}", file=sys.stderr)


def _build_server_block(project: str, project_id: str, agent: str, role: str,
                         api_key: str, sb: Dict[str, str],
                         keychain_profile: str = "default",
                         editor_type: str = "") -> Dict[str, Any]:
    """Build the MCP server config block for an agent.

    1.4.1+ does NOT bake the api key into the env. Instead it bakes a
    `MESHCODE_KEYCHAIN_PROFILE` env var that names the keychain entry the
    MCP server should look up at boot. The api key never appears in any
    file on disk and never in process env / `ps eauxww`.

    For backwards compatibility, if the keychain isn't available on this
    OS, the api key falls back to the env var (legacy path).
    """
    env: Dict[str, str] = {
        "MESHCODE_PROJECT": project,
        "MESHCODE_PROJECT_ID": project_id,
        "MESHCODE_AGENT": agent,
        "MESHCODE_ROLE": role or "MCP-connected agent",
        "MESHCODE_KEYCHAIN_PROFILE": keychain_profile,
        "SUPABASE_URL": sb["SUPABASE_URL"],
        "SUPABASE_KEY": sb["SUPABASE_KEY"],
        # Force UTF-8 stdio so the MCP JSON-RPC channel doesn't crash on
        # Windows cp1252 when the server emits any non-ASCII char.
        "PYTHONIOENCODING": "utf-8",
        # Mark this Python process as the MCP serve subprocess so other
        # parts of the package (e.g. self_update) skip auto-update inside it.
        "MESHCODE_MCP_SERVE": "1",
    }
    if editor_type:
        env["MESHCODE_EDITOR_TYPE"] = editor_type
    # Belt-and-suspenders fallback: if the OS doesn't have a keychain backend
    # the MCP server can't read the key from there, so we still need to pass
    # it via env. Probe and only include it as a fallback path.
    try:
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
        if not secrets_mod.keyring_status().get("available", False):
            env["MESHCODE_API_KEY"] = api_key
    except Exception:
        env["MESHCODE_API_KEY"] = api_key
    return {
        "command": sys.executable or "python3",
        "args": ["-m", "meshcode.meshcode_mcp", "serve"],
        "env": env,
    }


def _restrict_perms(path: Path) -> None:
    """Restrict file to owner-only access (Windows-aware)."""
    try:
        if sys.platform == "win32":
            import subprocess
            username = os.environ.get("USERNAME", os.environ.get("USER", ""))
            if username:
                subprocess.run(
                    ["icacls", str(path), "/inheritance:r",
                     "/grant:r", f"{username}:(F)"],
                    capture_output=True, timeout=5,
                )
        else:
            os.chmod(path, 0o600)
    except Exception:
        pass


def _atomic_write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    _restrict_perms(tmp)
    tmp.replace(path)
    _restrict_perms(path)


def _toml_escape(s: str) -> str:
    """Escape a string for a TOML basic string literal."""
    return s.replace("\\", "\\\\").replace("\"", "\\\"")


def _render_codex_block(server_id: str, server_block: Dict[str, Any]) -> str:
    """Render a [mcp_servers.<server_id>] section (plus [.env] subtable) for
    Codex CLI's ~/.codex/config.toml format. Returns a text block starting
    with a leading newline so it appends cleanly to existing files."""
    cmd = _toml_escape(str(server_block.get("command", "")))
    args = server_block.get("args", []) or []
    env = server_block.get("env", {}) or {}
    # Quote the section name only if it contains special chars. server_id is
    # our deterministic "meshcode-<project>-<agent>" slug; hyphens require
    # quoting in TOML bare keys, so always quote.
    section = f'"{_toml_escape(server_id)}"'
    lines = []
    lines.append("")
    lines.append(f"[mcp_servers.{section}]")
    lines.append(f'command = "{cmd}"')
    args_rendered = ", ".join(f'"{_toml_escape(str(a))}"' for a in args)
    lines.append(f"args = [{args_rendered}]")
    if env:
        lines.append("")
        lines.append(f"[mcp_servers.{section}.env]")
        for k, v in env.items():
            lines.append(f'{k} = "{_toml_escape(str(v))}"')
    lines.append("")
    return "\n".join(lines)


def _atomic_write_toml_codex(path: Path, server_id: str, server_block: Dict[str, Any]) -> None:
    """Read/replace/write ~/.codex/config.toml preserving all other sections.

    Codex CLI uses TOML with [mcp_servers.<name>] tables (optionally a
    [mcp_servers.<name>.env] subtable). We don't want to round-trip the
    entire TOML file (stdlib can only READ TOML via tomllib, not write),
    so we do surgical text replacement:

      * If [mcp_servers."<server_id>"] already exists, find that section
        header and delete everything from it up to (but not including) the
        next top-level-ish section header that is NOT a sub-table of the
        same server (i.e. next `[` that doesn't start with
        `[mcp_servers."<server_id>".`), or EOF.
      * Then append the freshly rendered block.
      * If no prior section, just append to end.

    Atomic via tempfile + replace.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    text = path.read_text(encoding="utf-8") if path.exists() else ""

    quoted = f'"{_toml_escape(server_id)}"'
    header = f"[mcp_servers.{quoted}]"
    subheader_prefix = f"[mcp_servers.{quoted}."

    lines = text.splitlines(keepends=True)
    out: list = []
    i = 0
    removed = False
    while i < len(lines):
        stripped = lines[i].lstrip()
        if not removed and (stripped.startswith(header) or stripped.startswith(subheader_prefix)):
            # Skip this section and any following lines until we hit a new
            # top-level `[` section that is NOT our server's sub-table.
            i += 1
            while i < len(lines):
                s2 = lines[i].lstrip()
                if s2.startswith("[") and not s2.startswith(subheader_prefix) and not s2.startswith(header):
                    break
                i += 1
            removed = True
            continue
        out.append(lines[i])
        i += 1

    new_text = "".join(out)
    # Ensure exactly one trailing newline before we append our block.
    if new_text and not new_text.endswith("\n"):
        new_text += "\n"
    new_text += _render_codex_block(server_id, server_block)

    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(new_text, encoding="utf-8")
    tmp.replace(path)


def _write_continue_config(ws: Path, server_id: str, server_block: Dict[str, Any]) -> None:
    """Write Continue.dev MCP config at workspace/.continue/config.yaml.

    Continue.dev uses YAML for its config. We write a minimal config with
    just the MCP server entry.
    """
    env = server_block.get("env", {})
    cmd = server_block.get("command", "python3")
    args = server_block.get("args", [])

    # Build YAML manually (no yaml dependency)
    lines = ["# MeshCode MCP server - auto-generated by meshcode setup"]
    lines.append("models: []")
    lines.append("mcpServers:")
    lines.append(f"  - name: {server_id}")
    lines.append(f"    command: {cmd}")
    lines.append("    args:")
    for a in args:
        lines.append(f"      - \"{a}\"")
    if env:
        lines.append("    env:")
        for k, v in env.items():
            lines.append(f"      {k}: \"{v}\"")

    config_dir = ws / ".continue"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / "config.yaml"
    try:
        config_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except (IOError, OSError) as e:
        print(f"[meshcode] WARNING: could not write Continue config: {e}", file=sys.stderr)


# ============================================================
# WORKSPACE MODEL (1.3.0+) — one isolated dir per agent
# ============================================================

WORKSPACES_ROOT = Path.home() / "meshcode"


def _workspace_dir(project: str, agent: str) -> Path:
    return WORKSPACES_ROOT / f"{project}-{agent}"


def setup_workspace(project: str, agent: str, role: str = "",
                     keychain_profile: str = "default") -> int:
    """Create an isolated workspace dir at ~/meshcode/<project>-<agent>/ with
    .mcp.json containing ONLY this agent's server entry. Universal for any
    MCP-compatible editor that supports per-directory configs (Claude Code via
    --mcp-config flag, Cursor + Cline via .cursor/mcp.json + .vscode/mcp.json).

    keychain_profile: which entry in the OS keychain holds the api key for
    this agent. Defaults to "default" (the user's main login). For a
    friend who joined via `meshcode join <token>`, this is set to
    "mesh:<project>:<agent>" so the workspace uses the scoped guest key
    instead of the inviter's main key.
    """
    sb = _load_supabase_env()

    # Resolve api_key from the named keychain profile (NOT always 'default')
    try:
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
        api_key = secrets_mod.get_api_key(profile=keychain_profile) or ""
    except Exception as e:
        print(f"[meshcode] ERROR: cannot load secrets module: {e}", file=sys.stderr)
        return 2

    if not api_key and keychain_profile == "default" and sys.stdin.isatty():
        # No key in keychain — prompt inline instead of failing
        print("[meshcode] No API key found. You can get one from meshcode.io/settings.", file=sys.stderr)
        try:
            api_key = input("[meshcode] Paste your API key (mc_...): ").strip()
        except (EOFError, KeyboardInterrupt):
            api_key = ""
        if api_key:
            # Store it so they never have to paste again
            try:
                import importlib as _il
                _login = _il.import_module("meshcode.comms_v4").login
                _login(api_key)
            except Exception:
                # Fallback: just store raw in keychain
                try:
                    secrets_mod.set_api_key(api_key, profile="default")
                except Exception:
                    pass

    if not api_key:
        print(f"[meshcode] ERROR: no api key found.", file=sys.stderr)
        if keychain_profile == "default":
            print("[meshcode]   Run `meshcode login <api_key>` or paste it when prompted.", file=sys.stderr)
        else:
            print(f"[meshcode]   This profile is created by `meshcode join <token>`.", file=sys.stderr)
        return 2

    try:
        project_id = _resolve_project_id(api_key, project, sb)
    except (RPCError, MeshCodeConnectionError, AuthError) as exc:
        print(f"[meshcode] ERROR: {exc}", file=sys.stderr)
        return 2

    server_id = f"meshcode-{project}-{agent}"
    server_block = _build_server_block(project, project_id, agent, role, api_key, sb,
                                         keychain_profile=keychain_profile)

    ws = _workspace_dir(project, agent)
    ws.mkdir(parents=True, exist_ok=True)

    # Write 3 config files inside the workspace so any MCP-aware editor
    # opened in this dir picks up the meshcode server.
    #
    #   .mcp.json              — Claude Code project-scoped MCP config
    #   .cursor/mcp.json       — Cursor workspace-scoped MCP config
    #   .vscode/mcp.json       — Cline / VS Code workspace-scoped MCP config
    #
    # All three contain the SAME single server entry. Whichever editor the
    # user opens here will see exactly one agent: this one.
    server_doc = {"mcpServers": {server_id: server_block}}
    _atomic_write_json(ws / ".mcp.json", server_doc)
    _atomic_write_json(ws / ".cursor" / "mcp.json", server_doc)
    _atomic_write_json(ws / ".vscode" / "mcp.json", server_doc)
    # Continue.dev workspace config (.continue/config.yaml)
    _write_continue_config(ws, server_id, server_block)

    # A tiny manifest the `meshcode run` command reads to know where this
    # workspace lives. Stored at the root so `meshcode run <agent>` can find
    # it without scanning every dir.
    registry_path = WORKSPACES_ROOT / ".registry.json"
    registry: Dict[str, Any] = {}
    if registry_path.exists():
        try:
            registry = json.loads(registry_path.read_text(encoding="utf-8"))
        except Exception:
            registry = {}
    registry.setdefault("agents", {})[agent] = {
        "project": project,
        "workspace": str(ws),
        "server_id": server_id,
        "role": role,
    }
    _atomic_write_json(registry_path, registry)

    # Drop a README.md so the agent's working directory isn't empty on boot.
    readme_body = f"""# {project} — {agent}

This is the MeshCode workspace for the **{agent}** agent in the **{project}** meshwork.

You are connected to the rest of your team via the meshcode MCP server, which is loaded
automatically when you open this directory in Claude Code, Cursor, or Cline.

## Your identity
- Project: {project}
- Agent name: {agent}
- Role: {role or "(set in dashboard)"}

## How this works
- Use the meshcode_* tools to communicate with other agents in the mesh.
- Use meshcode_status to see who else is in the meshwork.
- Use meshcode_send(to, message) to send messages.
- Use meshcode_wait to listen for incoming messages (your default idle state).
- Use meshcode_done(reason) when the team's task is complete.

## To launch this agent again
```bash
meshcode run {agent}
```

This is your workspace dir — feel free to scaffold any files your task needs here, or
work in a different repo by `cd`ing elsewhere after launch.
"""
    try:
        (ws / "README.md").write_text(readme_body, encoding="utf-8")
    except Exception as _e:
        print(f"[meshcode] WARNING: could not write README.md: {_e}", file=sys.stderr)

    # CLAUDE.md — Claude Code reads this on every session start and merges it
    # into the system prompt. We write the boot+loop directive here as a
    # belt-and-suspenders enforcement: even if the MCP `instructions` field is
    # not honored (older clients, schema-deferred sessions, etc.), the agent
    # still auto-enters the loop without the user having to remind it.
    claudemd_body = f"""# {project} — {agent} (MeshCode agent workspace)

You are agent **{agent}** in MeshCode meshwork **{project}**.
Role: {role or "(set in dashboard)"}

## ON SESSION START — DO THIS IMMEDIATELY (no matter what the user types)

The moment this session opens — whether the user typed `boot`, `hi`, nothing,
or anything else — run the full boot protocol. Do NOT reply with only a
greeting or memory dump and then idle. Do NOT ask "what do you want to work
on" — the mesh tells you via tasks/messages.

If the meshcode_* tool schemas are deferred in your client, your FIRST tool
call MUST be:

```
ToolSearch(query="select:meshcode_set_status,meshcode_check,meshcode_tasks,meshcode_auto_wake,meshcode_status,meshcode_wait,meshcode_send,meshcode_task_claim,meshcode_task_complete,meshcode_remember,meshcode_recall")
```

Then run the boot sequence:

1. `meshcode_set_status(status="online", task="ready")`
2. `meshcode_check()` — read NEW messages (last_seen auto-restored from mesh memory)
3. `meshcode_tasks()` — see assigned/pending tasks; claim any unclaimed for this agent
4. `meshcode_auto_wake()` — scan meshwork health, surface issues
5. `meshcode_status()` — see who's online
6. `meshcode_wait()` — enter the permanent loop (see next section)

## PERMANENT LOOP (THE #1 RULE)

After the boot sequence — and after **EVERY** subsequent action — your next
tool call MUST be `meshcode_wait()`. The loop:

```
act → (optional meshcode_send) → meshcode_wait() → repeat
```

NEVER exit. NEVER stop. NEVER say "standing by" / "let me know" / "I'm here"
without actually calling `meshcode_wait()`. The ONLY exits:
- the human user explicitly says "stop" / "sleep" / "exit",
- the commander broadcasts a got_done / sleep authorization,
- a fatal error makes continuation impossible.

If `meshcode_wait()` times out, call it again with a 2× longer timeout (cap 1800s).

## RULES

- Use MCP tools. Don't shell out to the `meshcode` CLI from inside the session.
- Tasks > messages. Use `meshcode_task_create / task_claim / task_complete`
  for trackable work. Keep messages <100 tokens (signals only).
- No empty acks. JSON reports only.
- Threading: pass `in_reply_to`.
- `sensitive=True` for secrets / PII.
- Memory: `meshcode_remember(key, value)` for reusable learnings. Don't dump
  task summaries into memory — tasks already persist.

## To launch this agent again

```bash
meshcode run {agent}
```

(See README.md in this folder for the workspace overview.)
"""
    try:
        (ws / "CLAUDE.md").write_text(claudemd_body, encoding="utf-8")
    except Exception as _e:
        print(f"[meshcode] WARNING: could not write CLAUDE.md: {_e}", file=sys.stderr)

    # /meshcode-wait slash command + Stop hook — Samuel's product rule:
    # agents must REALLY enter meshcode_wait between turns, not just say "en
    # loop" in chat text. The slash command lets the user trigger the loop
    # explicitly; the Stop hook refuses to end any turn that didn't call
    # meshcode_wait (unless the user said stop/sleep/exit/done).
    server_id = f"meshcode-{project}-{agent}"
    slash_cmd_body = f"""---
description: Enter the permanent MeshCode wait loop — block in meshcode_wait until a real message arrives, never idle in text mode.
allowed-tools: mcp__{server_id}__meshcode_wait, mcp__{server_id}__meshcode_check, mcp__{server_id}__meshcode_set_status, mcp__{server_id}__meshcode_send, mcp__{server_id}__meshcode_status, mcp__{server_id}__meshcode_tasks, mcp__{server_id}__meshcode_task_claim, mcp__{server_id}__meshcode_task_complete, mcp__{server_id}__meshcode_remember, mcp__{server_id}__meshcode_recall
---

# /meshcode-wait — enter the permanent loop

Your next tool call MUST be `meshcode_wait`. Do not output any chat text first. Do not check status, do not summarize what you were doing — just call `meshcode_wait` and let it block.

When `meshcode_wait` returns:
1. If `messages` non-empty → process them (reply, claim tasks, ship code, whatever the message asks for).
2. If `done_signals` non-empty AND the signal is from the human or a got_done broadcast → stop. Otherwise ignore.
3. After processing, your next tool call is `meshcode_wait` again. Loop.

Rules while in this loop:
- Never end your turn without an active `meshcode_wait` call OR an explicit human "stop" / "sleep" / "exit".
- If `meshcode_wait` times out, call it again immediately with `timeout_seconds=20`.
- Do not call `meshcode_check` as a substitute for `meshcode_wait`.
- If a tool errors, fix the error then return to `meshcode_wait`.
- Release words (case-insensitive): stop, sleep, exit, quit, done, descansa, duerme.

Call `meshcode_wait` now.
"""
    stop_hook_body = '''#!/usr/bin/env python3
"""Stop hook: refuse to end the agent's turn unless either
(a) the last user message contains a release keyword, or
(b) the last assistant turn already called meshcode_wait.
"""
import json
import sys
from pathlib import Path

RELEASE_WORDS = (
    "stop", "sleep", "exit", "quit", "done",
    "duerme", "descansa", "quedate dormido", "se acab",
    "got_done",
)
WAIT_TOOL_SUFFIX = "meshcode_wait"


def _last_user_message(transcript_path):
    try:
        last = ""
        with transcript_path.open() as f:
            for line in f:
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if rec.get("role") == "user":
                    content = rec.get("content")
                    if isinstance(content, str):
                        last = content
                    elif isinstance(content, list):
                        last = " ".join(
                            p.get("text", "")
                            for p in content
                            if isinstance(p, dict) and p.get("type") == "text"
                        )
        return last
    except (OSError, FileNotFoundError):
        return ""


def _last_assistant_turn_called_wait(transcript_path):
    try:
        records = []
        with transcript_path.open() as f:
            for line in f:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        last_assistant_blocks = []
        for rec in reversed(records):
            if rec.get("role") == "user":
                if last_assistant_blocks:
                    break
                continue
            if rec.get("role") == "assistant":
                content = rec.get("content")
                if isinstance(content, list):
                    last_assistant_blocks.extend(content)
                elif isinstance(content, dict):
                    last_assistant_blocks.append(content)
        for block in last_assistant_blocks:
            if not isinstance(block, dict):
                continue
            if block.get("type") == "tool_use":
                name = str(block.get("name", ""))
                if name.endswith(WAIT_TOOL_SUFFIX):
                    return True
        return False
    except (OSError, FileNotFoundError):
        return False


def main():
    raw = sys.stdin.read()
    try:
        payload = json.loads(raw) if raw else {}
    except json.JSONDecodeError:
        payload = {}
    transcript = payload.get("transcript_path") or payload.get("transcriptPath")
    transcript_path = Path(transcript) if transcript else None
    last_user = _last_user_message(transcript_path).lower() if transcript_path else ""
    if any(word in last_user for word in RELEASE_WORDS):
        sys.exit(0)
    if transcript_path and _last_assistant_turn_called_wait(transcript_path):
        sys.exit(0)
    print(json.dumps({
        "decision": "block",
        "reason": (
            "Stay-on-loop: you ended your turn without calling meshcode_wait. "
            "Per Samuel's standing rule, every turn ends with an active "
            "meshcode_wait. Call meshcode_wait now (timeout_seconds=20). "
            "Do not reply with text \\u2014 just make the tool call. The "
            "only way out is the user typing stop / sleep / exit / done."
        ),
    }))
    sys.exit(0)


if __name__ == "__main__":
    main()
'''
    settings_body = json.dumps({
        "hooks": {
            "Stop": [{
                "hooks": [{
                    "type": "command",
                    "command": "python3 \"$CLAUDE_PROJECT_DIR/.claude/hooks/stay_on_loop.py\"",
                }],
            }],
        },
    }, indent=2) + "\n"
    try:
        (ws / ".claude" / "commands").mkdir(parents=True, exist_ok=True)
        (ws / ".claude" / "hooks").mkdir(parents=True, exist_ok=True)
        (ws / ".claude" / "commands" / "meshcode-wait.md").write_text(slash_cmd_body, encoding="utf-8")
        hook_path = ws / ".claude" / "hooks" / "stay_on_loop.py"
        hook_path.write_text(stop_hook_body, encoding="utf-8")
        try:
            hook_path.chmod(0o755)
        except OSError:
            pass
        (ws / ".claude" / "settings.json").write_text(settings_body, encoding="utf-8")
    except Exception as _e:
        print(f"[meshcode] WARNING: could not write /meshcode-wait command + hook: {_e}", file=sys.stderr)

    print(f"[meshcode] ✓ Workspace created for agent '{agent}' (project: {project})")
    print(f"[meshcode]   Path: {ws}")
    print(f"[meshcode]")
    print(f"[meshcode]   To launch this agent in your editor:")
    print(f"[meshcode]     meshcode run {agent}")
    print(f"[meshcode]")
    print(f"[meshcode]   Closing the editor window flips this agent offline.")
    print(f"[meshcode]   Other agents stay independent — no cross-window pollution.")
    return 0


# ============================================================
# LEGACY GLOBAL-CONFIG MODEL (kept for Claude Desktop)
# ============================================================

CLIENT_CONFIG_PATHS = {
    "claude-code": {
        "Darwin":  Path.home() / ".claude.json",
        "Linux":   Path.home() / ".claude.json",
        "Windows": Path.home() / ".claude.json",
    },
    "cursor": {
        "Darwin":  Path.home() / ".cursor" / "mcp.json",
        "Linux":   Path.home() / ".cursor" / "mcp.json",
        "Windows": Path.home() / ".cursor" / "mcp.json",
    },
    "cline": {
        "Darwin":  Path.home() / "Library" / "Application Support" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
        "Linux":   Path.home() / ".config" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
        "Windows": Path.home() / "AppData" / "Roaming" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
    },
    "claude-desktop": {
        "Darwin":  Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json",
        "Linux":   Path.home() / ".config" / "Claude" / "claude_desktop_config.json",
        "Windows": Path.home() / "AppData" / "Roaming" / "Claude" / "claude_desktop_config.json",
    },
    # Windsurf (Codeium): global MCP config in ~/.codeium/windsurf/mcp_config.json
    # (JSON, same {"mcpServers": {...}} shape as Cursor/Cline). Cross-platform —
    # Windsurf stores user config under ~/.codeium regardless of OS.
    "windsurf": {
        "Darwin":  Path.home() / ".codeium" / "windsurf" / "mcp_config.json",
        "Linux":   Path.home() / ".codeium" / "windsurf" / "mcp_config.json",
        "Windows": Path.home() / ".codeium" / "windsurf" / "mcp_config.json",
    },
    # OpenAI Codex CLI: ~/.codex/config.toml with [mcp_servers.<name>] tables.
    # This is NOT JSON — handled by the custom TOML writer below.
    "codex": {
        "Darwin":  Path.home() / ".codex" / "config.toml",
        "Linux":   Path.home() / ".codex" / "config.toml",
        "Windows": Path.home() / ".codex" / "config.toml",
    },
}

CLIENT_DISPLAY_NAMES = {
    "claude-code":    "Claude Code",
    "cursor":         "Cursor",
    "cline":          "Cline (VS Code)",
    "claude-desktop": "Claude Desktop",
    "windsurf":       "Windsurf (Codeium)",
    "codex":          "OpenAI Codex CLI",
}

# Clients whose config file is NOT JSON and need a custom writer.
NON_JSON_CLIENTS = {"codex"}


def setup_global(client: str, project: str, agent: str, role: str = "") -> int:
    """LEGACY: write to the user's GLOBAL MCP config file. All agents that
    setup this way will load in EVERY window of the editor — they all show
    online whenever any window is open. Kept for Claude Desktop and other
    clients that don't support per-instance configs."""
    if client not in CLIENT_CONFIG_PATHS:
        print(f"[meshcode] ERROR: Unknown client '{client}'. Supported: {', '.join(CLIENT_CONFIG_PATHS)}", file=sys.stderr)
        return 2

    try:
        creds = _load_credentials()
    except AuthError as exc:
        print(f"[meshcode] ERROR: {exc}", file=sys.stderr)
        return 2
    sb = _load_supabase_env()
    api_key = creds.get("api_key", "")
    try:
        project_id = _resolve_project_id(api_key, project, sb)
    except (RPCError, MeshCodeConnectionError) as exc:
        print(f"[meshcode] ERROR: {exc}", file=sys.stderr)
        return 2

    os_name = platform.system()
    config_path = CLIENT_CONFIG_PATHS[client].get(os_name)
    if config_path is None:
        print(f"[meshcode] ERROR: '{client}' is not supported on {os_name}", file=sys.stderr)
        return 2

    server_id = f"meshcode-{project}-{agent}"
    server_block = _build_server_block(project, project_id, agent, role, api_key, sb)

    if client in NON_JSON_CLIENTS:
        # Dispatch to per-format writers (preserves other sections).
        if client == "codex":
            _atomic_write_toml_codex(config_path, server_id, server_block)
        else:
            print(f"[meshcode] ERROR: no writer registered for non-JSON client '{client}'", file=sys.stderr)
            return 2
    else:
        existing: Dict[str, Any] = {}
        if config_path.exists():
            try:
                existing = json.loads(config_path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                print(f"[meshcode] WARNING: {config_path} exists but is not valid JSON.", file=sys.stderr)
                return 2

        if not isinstance(existing, dict):
            existing = {}

        servers = existing.setdefault("mcpServers", {})
        if not isinstance(servers, dict):
            print(f"[meshcode] ERROR: 'mcpServers' in {config_path} is not an object", file=sys.stderr)
            return 2

        servers[server_id] = server_block
        _atomic_write_json(config_path, existing)

    display = CLIENT_DISPLAY_NAMES[client]
    print(f"[meshcode] MCP server '{server_id}' added to {display} GLOBAL config")
    print(f"[meshcode]   Path: {config_path}")
    print(f"[meshcode]   ⚠️  Global mode: this agent will appear in EVERY window of {display}.")
    print(f"[meshcode]   For per-window agent isolation, use the workspace flow instead:")
    print(f"[meshcode]     meshcode setup {project} {agent}")
    print(f"[meshcode]     meshcode run {agent}")
    return 0


# ============================================================
# DISPATCHER (called from comms_v4.py CLI)
# ============================================================

def setup(*args) -> int:
    """Smart dispatcher.

    Forms supported:
        meshcode setup <project> <agent> [role]            → workspace flow (NEW)
        meshcode setup <client> <project> <agent> [role]   → legacy global flow

    Detection: if the first arg is one of the known client slugs, fall back
    to the legacy global flow. Otherwise treat the first arg as a project
    name and create a workspace.
    """
    if not args:
        print("Usage:", file=sys.stderr)
        print("  meshcode setup <project> <agent> [role]           # workspace flow (recommended)", file=sys.stderr)
        print("  meshcode setup <client> <project> <agent> [role]  # legacy global flow", file=sys.stderr)
        print("  Clients: claude-code, cursor, cline, claude-desktop, windsurf, codex", file=sys.stderr)
        return 1

    if args[0] in CLIENT_CONFIG_PATHS:
        if args[0] == "claude-desktop":
            # Claude Desktop needs global config — only exception
            if len(args) < 3:
                print(f"[meshcode] Missing agent name.", file=sys.stderr)
                if len(args) >= 2:
                    print(f"[meshcode] Usage: meshcode setup claude-desktop {args[1]} <agent-name>", file=sys.stderr)
                else:
                    print(f"[meshcode] Usage: meshcode setup claude-desktop <project> <agent>", file=sys.stderr)
                return 1
            return setup_global(args[0], args[1], args[2], args[3] if len(args) > 3 else "")
        # All other clients: redirect to workspace flow (no global pollution)
        print(f"[meshcode] NOTE: 'meshcode setup {args[0]}' is deprecated. Using workspace flow.", file=sys.stderr)
        if len(args) < 3:
            print(f"[meshcode] Missing agent name.", file=sys.stderr)
            if len(args) >= 2:
                print(f"[meshcode] Usage: meshcode setup {args[1]} <agent-name>", file=sys.stderr)
            else:
                print(f"[meshcode] Usage: meshcode setup <project> <agent>", file=sys.stderr)
            return 1
        return setup_workspace(args[1], args[2], args[3] if len(args) > 3 else "")

    if len(args) < 2:
        print(f"[meshcode] Missing agent name.", file=sys.stderr)
        print(f"[meshcode] Usage: meshcode setup {args[0]} <agent-name>", file=sys.stderr)
        return 1
    return setup_workspace(args[0], args[1], args[2] if len(args) > 2 else "")
