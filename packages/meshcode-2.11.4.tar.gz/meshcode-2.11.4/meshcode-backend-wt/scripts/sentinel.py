#!/usr/bin/env python3
"""
MeshCode Sentinel — Self-Monitoring Agent
==========================================
Calls mc_system_health every 60s and alerts when the system is degraded.
Uses the meshcode SDK so it dogfoods the same infrastructure it monitors.

Alerts:
  - delivery_rate < 95% (messages getting lost)
  - stale_agents > 5 (agents may be dead but displayed as alive)
  - failed_rpcs > 0 (backend errors)
  - agent "working" for >10min (dead but looks alive)

Usage:
    python scripts/sentinel.py                    # Run once (cron-friendly)
    python scripts/sentinel.py --loop             # Run continuously (every 60s)
    python scripts/sentinel.py --loop --interval 30  # Custom interval

Requires:
    MESHCODE_API_KEY env var or meshcode login
"""

import argparse
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

# Add meshcode to path
sys.path.insert(0, str(Path(__file__).parent.parent))

os.environ.setdefault("SUPABASE_URL", "https://gjinagyyjttyxnaoavnz.supabase.co")


def get_api_key():
    key = os.environ.get("MESHCODE_API_KEY")
    if key:
        return key
    try:
        import keyring
        key = keyring.get_password("meshcode", "default")
    except Exception:
        pass
    return key


# ── Thresholds ─────────────────────────────────────────────────────────

THRESHOLDS = {
    "delivery_rate_warning": 0.95,     # < 95% = warning
    "delivery_rate_critical": 0.80,    # < 80% = critical
    "stale_agents_warning": 5,         # > 5 stale agents = warning
    "failed_rpcs_warning": 1,          # any failed RPCs = warning
    "failed_rpcs_critical": 50,        # > 50 = critical
    "working_too_long_seconds": 600,   # 10 minutes
}


# ── Alert levels ───────────────────────────────────────────────────────

class Alert:
    def __init__(self, level: str, metric: str, message: str, value=None):
        self.level = level  # "warning" or "critical"
        self.metric = metric
        self.message = message
        self.value = value
        self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self):
        return {
            "level": self.level,
            "metric": self.metric,
            "message": self.message,
            "value": self.value,
            "timestamp": self.timestamp,
        }

    def __str__(self):
        icon = "!!" if self.level == "critical" else "!"
        return f"  [{icon}] {self.metric}: {self.message}"


# ── Health check ───────────────────────────────────────────────────────

def check_health(api_key: str, project_id: str = None) -> list[Alert]:
    """Run mc_system_health and derive alerts."""
    from meshcode.meshcode_mcp import backend as be

    alerts = []

    # 1. System health
    try:
        health = be.sb_rpc("mc_system_health", {})
    except Exception as e:
        return [Alert("critical", "db_connectivity", f"Cannot reach Supabase: {e}")]

    if not isinstance(health, dict) or not health.get("ok"):
        return [Alert("critical", "system_health", f"mc_system_health failed: {health}")]

    # Check delivery rate
    rate = health.get("message_delivery_rate", 1.0)
    if rate < THRESHOLDS["delivery_rate_critical"]:
        alerts.append(Alert("critical", "delivery_rate",
                            f"Message delivery at {rate*100:.1f}% (< 80%)", rate))
    elif rate < THRESHOLDS["delivery_rate_warning"]:
        alerts.append(Alert("warning", "delivery_rate",
                            f"Message delivery at {rate*100:.1f}% (< 95%)", rate))

    # Check stale agents
    stale = health.get("stale_agent_count", 0)
    if stale > THRESHOLDS["stale_agents_warning"]:
        alerts.append(Alert("warning", "stale_agents",
                            f"{stale} stale agents (> {THRESHOLDS['stale_agents_warning']})", stale))

    # Check failed RPCs
    failed = health.get("failed_rpc_count_1h", 0)
    if failed > THRESHOLDS["failed_rpcs_critical"]:
        alerts.append(Alert("critical", "failed_rpcs",
                            f"{failed} failed RPCs in last hour (> 50)", failed))
    elif failed > THRESHOLDS["failed_rpcs_warning"]:
        alerts.append(Alert("warning", "failed_rpcs",
                            f"{failed} failed RPCs in last hour", failed))

    # 2. Check for stuck agents (if project_id provided)
    if api_key and project_id:
        try:
            eff = be.sb_rpc("mc_agent_effective_status", {
                "p_api_key": api_key,
                "p_project_id": project_id,
            })
            if isinstance(eff, dict) and eff.get("ok"):
                for agent in eff.get("agents", []):
                    stored = agent.get("stored_status")
                    effective = agent.get("effective_status")
                    secs = agent.get("seconds_since_heartbeat", 0)

                    # Agent says "working" but hasn't heartbeated in 10+ min
                    if (stored == "working" and secs
                            and secs > THRESHOLDS["working_too_long_seconds"]):
                        alerts.append(Alert("warning", "stuck_agent",
                                            f"Agent '{agent['name']}' says 'working' but "
                                            f"no heartbeat for {secs}s",
                                            {"agent": agent["name"], "seconds": secs}))
        except Exception:
            pass  # effective_status check is optional

    return alerts


def print_report(health_data: dict, alerts: list[Alert]):
    """Print a human-readable health report."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    print(f"\n  MeshCode Sentinel — {now}")
    print(f"  {'=' * 50}")

    if health_data:
        print(f"  Active agents: {health_data.get('active_agent_count', '?')}")
        print(f"  Stale agents:  {health_data.get('stale_agent_count', '?')}")
        print(f"  Messages (1h): {health_data.get('total_messages_1h', '?')}")
        rate = health_data.get('message_delivery_rate', 0)
        print(f"  Delivery rate: {rate*100:.1f}%")
        print(f"  Failed RPCs:   {health_data.get('failed_rpc_count_1h', '?')}")
        print(f"  FE errors:     {health_data.get('frontend_errors_1h', '?')}")

    if not alerts:
        print(f"\n  Status: HEALTHY")
    else:
        criticals = [a for a in alerts if a.level == "critical"]
        warnings = [a for a in alerts if a.level == "warning"]

        if criticals:
            print(f"\n  Status: CRITICAL ({len(criticals)} critical, {len(warnings)} warning)")
        else:
            print(f"\n  Status: DEGRADED ({len(warnings)} warning)")

        for alert in alerts:
            print(str(alert))

    print()


def run_once(api_key: str, project_id: str = None, quiet: bool = False) -> int:
    """Run one health check. Returns 0 if healthy, 1 if alerts, 2 if critical."""
    from meshcode.meshcode_mcp import backend as be

    # Get health data for report
    try:
        health_data = be.sb_rpc("mc_system_health", {})
        if not isinstance(health_data, dict):
            health_data = {}
    except Exception:
        health_data = {}

    alerts = check_health(api_key, project_id)

    if not quiet:
        print_report(health_data, alerts)

    if any(a.level == "critical" for a in alerts):
        return 2
    if alerts:
        return 1
    return 0


def run_loop(api_key: str, project_id: str = None, interval: int = 60):
    """Run health checks in a loop."""
    print(f"  Sentinel starting — checking every {interval}s")
    print(f"  Press Ctrl+C to stop\n")

    consecutive_healthy = 0
    while True:
        try:
            exit_code = run_once(api_key, project_id)
            if exit_code == 0:
                consecutive_healthy += 1
                if consecutive_healthy % 10 == 0:
                    print(f"  [{consecutive_healthy} consecutive healthy checks]")
            else:
                consecutive_healthy = 0
        except KeyboardInterrupt:
            print("\n  Sentinel stopped.")
            return
        except Exception as e:
            print(f"  [ERROR] Health check failed: {e}")

        try:
            time.sleep(interval)
        except KeyboardInterrupt:
            print("\n  Sentinel stopped.")
            return


def main():
    parser = argparse.ArgumentParser(description="MeshCode Sentinel — Self-Monitoring Agent")
    parser.add_argument("--loop", action="store_true", help="Run continuously")
    parser.add_argument("--interval", type=int, default=60, help="Check interval in seconds (default 60)")
    parser.add_argument("--project", help="Project ID for per-agent monitoring")
    parser.add_argument("--quiet", action="store_true", help="Only print alerts")
    args = parser.parse_args()

    api_key = get_api_key()
    if not api_key:
        print("  [ERROR] No API key found. Run 'meshcode login' first.")
        sys.exit(1)

    if args.loop:
        run_loop(api_key, args.project, args.interval)
    else:
        exit_code = run_once(api_key, args.project, args.quiet)
        sys.exit(exit_code)


if __name__ == "__main__":
    main()
