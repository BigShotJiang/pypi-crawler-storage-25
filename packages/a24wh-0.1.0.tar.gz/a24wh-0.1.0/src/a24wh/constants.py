"""Library constants and defaults."""

__version__ = "0.1.0"

LOGGER_NAME = "a24wh"
LOG_FORMAT = "%(asctime)s | %(name)s | %(levelname)s | %(message)s"

DEFAULT_WEBHOOK_ENV_VAR = "A24WH_DEFAULT_WEBHOOK_URL"
AUTO_CONFIGURE_LOGGING_ENV_VAR = "A24WH_AUTO_CONFIGURE_LOGGING"

LOG_LEVEL_ENV_VAR = "A24WH_LOG_LEVEL"
LOG_TO_CONSOLE_ENV_VAR = "A24WH_LOG_TO_CONSOLE"
LOG_TO_FILE_ENV_VAR = "A24WH_LOG_TO_FILE"
LOG_FILE_ENV_VAR = "A24WH_LOG_FILE"

TIMEOUT_ENV_VAR = "A24WH_TIMEOUT"
RETRY_COUNT_ENV_VAR = "A24WH_RETRY_COUNT"
RETRY_DELAY_ENV_VAR = "A24WH_RETRY_DELAY"
REQUEST_DELAY_ENV_VAR = "A24WH_REQUEST_DELAY"

DEFAULT_TIMEOUT = 60
DEFAULT_RETRY_COUNT = 3
DEFAULT_RETRY_DELAY = 1.0
DEFAULT_REQUEST_DELAY = 1.0
DEFAULT_BATCH_SIZE = 50
DEFAULT_PAGE_SIZE = 50
DEFAULT_LOG_LEVEL = "INFO"
DEFAULT_LOG_FILE = "a24wh.log"

RETRY_STATUSES = (429, 500, 502, 503, 504)
MAX_LOG_BODY_LENGTH = 1000
DEFAULT_JSON_FILE_TITLE = "a24wh_request24"

ERROR_TYPE_CONFIGURATION = "configuration_error"
ERROR_TYPE_INVALID_JSON = "invalid_json"
ERROR_TYPE_BITRIX = "bitrix_error"
ERROR_TYPE_HTTP = "http_error"
ERROR_TYPE_TIMEOUT = "timeout_error"
ERROR_TYPE_TRANSPORT = "transport_error"
ERROR_TYPE_UNEXPECTED = "unexpected_error"
ERROR_TYPE_BATCH = "batch_error"
ERROR_TYPE_BATCH_PARSE = "batch_parse_error"

ERROR_CODE_MISSING_METHOD = "missing_method"
ERROR_CODE_MISSING_WEBHOOK_URL = "missing_webhook_url"
ERROR_CODE_INVALID_WEBHOOK_OR_METHOD = "invalid_webhook_or_method"
ERROR_CODE_INVALID_JSON = "invalid_json"
ERROR_CODE_TIMEOUT = "timeout"
ERROR_CODE_UNKNOWN = "unknown_error"
ERROR_CODE_EMPTY_COMMANDS = "empty_commands"
ERROR_CODE_TOO_MANY_COMMANDS = "too_many_commands"
ERROR_CODE_EMPTY_PARAMS_LIST = "empty_params_list"
ERROR_CODE_INVALID_PARAMS_ITEM = "invalid_params_item"
ERROR_CODE_BATCH_STEP = "batch_step_error"
ERROR_CODE_ITEMS_NOT_FOUND = "items_not_found"

ERR_MISSING_METHOD = "Bitrix24 method is required."
ERR_MISSING_WEBHOOK_URL = (
    "Bitrix24 webhook URL is not configured. "
    "Pass webhook_url explicitly or set the default webhook environment variable."
)
ERR_INVALID_WEBHOOK_OR_METHOD = "Failed to build the Bitrix24 method URL."
ERR_INVALID_JSON = "Bitrix24 returned a non-JSON response."
ERR_BITRIX_API = "Bitrix24 returned an API error."
ERR_HTTP_STATUS = "Bitrix24 returned HTTP {status_code}."
ERR_TIMEOUT = "Bitrix24 request timed out."
ERR_TRANSPORT = "Bitrix24 transport error during request."
ERR_UNEXPECTED = "Unexpected error during Bitrix24 request."
ERR_UNKNOWN = "Bitrix24 request failed for an unknown reason."
ERR_EMPTY_COMMANDS = "Batch commands must be a non-empty dict."
ERR_TOO_MANY_COMMANDS = "Bitrix24 batch supports up to 50 commands per request."
ERR_EMPTY_PARAMS_LIST = "params_list must be a non-empty list of dicts."
ERR_INVALID_PARAMS_ITEM = "Each item in params_list must be a dict."
ERR_BATCH_STEP = "Bitrix24 batch returned step-level errors."
ERR_BATCH_ITEMS_NOT_FOUND = "Unable to detect list items in batch response."
ERR_SAVE_JSON_INVALID_DATA = "response_data must be a dict."

LOG_REQUEST_SKIPPED_MISSING_METHOD = "Request skipped: missing method."
LOG_REQUEST_SKIPPED_REASON = "Request skipped: method=%s reason=%s"
LOG_REQUEST_STARTED = "Bitrix24 request started: method=%s portal=%s attempt=%s timeout=%s payload=%s"
LOG_REQUEST_COMPLETED = "Bitrix24 request completed: method=%s portal=%s"
LOG_INVALID_JSON = "Bitrix24 returned invalid JSON: method=%s portal=%s"
LOG_API_ERROR = "Bitrix24 API error: method=%s portal=%s error=%s"
LOG_HTTP_ERROR = "Bitrix24 HTTP error: method=%s portal=%s status=%s attempt=%s payload=%s"
LOG_TIMEOUT = "Bitrix24 timeout: method=%s portal=%s attempt=%s"
LOG_TRANSPORT_ERROR = "Bitrix24 transport error: method=%s portal=%s attempt=%s error=%s"
LOG_UNEXPECTED_ERROR = "Unexpected Bitrix24 request error: method=%s portal=%s attempt=%s"
LOG_BATCH_REQUEST_STARTED = "Bitrix24 batch request started: portal=%s commands=%s"
LOG_BATCH_BY_PARAMS_STEP_ERRORS = "Bitrix24 batch by params returned step errors: method=%s portal=%s errors=%s"
LOG_BATCH_LIST_STEP_ERRORS = "Bitrix24 batch list returned step errors: method=%s portal=%s errors=%s"
LOG_BATCH_LIST_ITEMS_NOT_FOUND = "Bitrix24 batch list could not detect list items: method=%s portal=%s step=%s"
