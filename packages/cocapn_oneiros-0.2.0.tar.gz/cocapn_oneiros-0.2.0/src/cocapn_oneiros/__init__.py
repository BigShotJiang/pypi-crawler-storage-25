"""cocapn-oneiros — Dream-state agent orchestration.""" 
__version__ = "0.2.0"
