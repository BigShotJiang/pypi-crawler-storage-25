from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="coolingcube",
    version="0.1.1",
    author="Cooling Cube",
    author_email="CoolingCubeInfo@proton.me",
    description="GPU cluster tail latency optimizer for DDP training and inference",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://coolingcube.cc",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.20",
    ],
    entry_points={
        "console_scripts": [
            "coolingcube=coolingcube.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: System :: Distributed Computing",
    ],
    keywords="gpu ddp training inference tail-latency optimization multi-gpu",
)
