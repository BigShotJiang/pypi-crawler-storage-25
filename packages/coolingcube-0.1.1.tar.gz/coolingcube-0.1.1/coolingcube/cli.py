#!/usr/bin/env python3
"""
coolingcube CLI — GPU cluster tail latency optimizer

Usage:
    coolingcube --logs timing.json
    coolingcube --workers '{"0": 12000, "1": 11800, "2": 15500}'
    coolingcube --pytorch  # auto-collect from active DDP process
"""

import argparse
import json
import sys
from coolingcube.client import optimize


def parse_logs(path: str) -> dict:
    """
    Parse a timing log file. Supports two formats:

    Format A — flat dict (simplest):
        {"0": 12345, "1": 11800, "2": 13000}

    Format B — list of step dicts (DDP training logs):
        [{"rank": 0, "total_iter_time": 0.186}, ...]
        or
        {"timing_logs": [{"step": 0, "worker": 0, "time_ms": 123.4}]}
    """
    with open(path) as f:
        data = json.load(f)

    # Format A — already a flat dict
    if isinstance(data, dict) and all(
        isinstance(v, (int, float)) for v in data.values()
    ):
        return data

    # Format B — list of worker dicts with total_iter_time
    if isinstance(data, list) and "total_iter_time" in data[0]:
        return {
            str(w["rank"]): w["total_iter_time"] * 1e6
            for w in data
        }

    # Format C — list of worker dicts with step_time
    if isinstance(data, list) and "step_time" in data[0]:
        return {
            str(w["rank"]): w["step_time"] * 1e6
            for w in data
        }

    # Format D — nested: {"workers": [...]}
    if isinstance(data, dict) and "workers" in data:
        workers = data["workers"]
        key = "total_iter_time" if "total_iter_time" in workers[0] else "step_time"
        return {
            str(w["rank"]): w[key] * 1e6
            for w in workers
        }

    # Format E — timing_logs list
    if isinstance(data, dict) and "timing_logs" in data:
        logs = data["timing_logs"]
        # average per worker across steps
        totals = {}
        counts = {}
        for entry in logs:
            w = str(entry.get("worker", entry.get("rank", 0)))
            t = entry.get("time_ms", entry.get("time_us", 0))
            if "time_ms" in entry:
                t *= 1000  # ms -> us
            totals[w] = totals.get(w, 0) + t
            counts[w] = counts.get(w, 0) + 1
        return {w: totals[w] / counts[w] for w in totals}

    raise ValueError(
        "Unrecognized log format. Expected a flat dict of worker->time_us, "
        "or a list/dict with total_iter_time or step_time fields."
    )


def print_result(result: dict):
    gain_pct = result["gain_pct"]
    gain_us  = result["gain_us"]
    baseline = result["baseline_tail_us"]
    best     = result["best_tail_us"]
    schedule = result["best_schedule"]
    calls    = result["oracle_calls"]
    dur      = result["duration_ms"]

    print()
    print("── Cooling Cube ─────────────────────────────")
    print(f"  baseline tail   {baseline:>10.1f} µs")
    print(f"  optimized tail  {best:>10.1f} µs")
    print(f"  gain            {gain_us:>10.1f} µs  ({gain_pct:.3f}%)")
    print(f"  oracle calls    {calls:>10}")
    print(f"  optimizer time  {dur:>10.1f} ms")
    print()

    delayed = {w: d for w, d in schedule.items() if float(d) > 0}
    if delayed:
        print("  schedule (non-zero delays):")
        for w, d in sorted(delayed.items(), key=lambda x: -float(x[1])):
            print(f"    worker {w:>4}  +{d} µs")
    else:
        print("  schedule: no delays applied (already optimal)")
    print("─────────────────────────────────────────────")
    print()


def main():
    parser = argparse.ArgumentParser(
        description="Cooling Cube — GPU cluster tail latency optimizer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  coolingcube --logs timing.json
  coolingcube --workers '{"0": 12000, "1": 11800, "2": 15500, "3": 12500}'
  coolingcube --logs my_run.json --json

Log file formats accepted:
  {"0": 12345, "1": 11800}                         flat dict (µs)
  [{"rank": 0, "total_iter_time": 0.186}, ...]     DDP worker list
  {"workers": [{"rank": 0, "step_time": 0.17}]}    nested workers
        """,
    )
    parser.add_argument("--logs", "-l", type=str,
                        help="Path to timing log file (JSON)")
    parser.add_argument("--workers", "-w", type=str,
                        help='Inline worker times as JSON string: \'{"0": 12000, "1": 11800}\'')
    parser.add_argument("--json", action="store_true",
                        help="Output raw JSON result instead of formatted text")

    args = parser.parse_args()

    if not args.logs and not args.workers:
        parser.print_help()
        sys.exit(1)

    if args.logs:
        try:
            worker_times = parse_logs(args.logs)
        except Exception as e:
            print(f"Error reading log file: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        try:
            worker_times = json.loads(args.workers)
        except json.JSONDecodeError as e:
            print(f"Invalid JSON: {e}", file=sys.stderr)
            sys.exit(1)

    print(f"Optimizing {len(worker_times)} workers...", file=sys.stderr)

    try:
        result = optimize(worker_times)
    except Exception as e:
        print(f"API error: {e}", file=sys.stderr)
        sys.exit(1)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print_result(result)


if __name__ == "__main__":
    main()
