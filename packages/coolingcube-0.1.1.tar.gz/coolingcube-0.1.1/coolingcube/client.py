import requests
import json

API_URL = "https://nff-scheduler.onrender.com/optimize"
API_KEY = "nff_477e84fa614bba3ac1803766fac381b42951256e29c7620f"


def optimize(worker_times: dict) -> dict:
    """
    Submit per-worker timing data to the Cooling Cube optimizer.

    Args:
        worker_times: dict mapping worker rank (str or int) to
                      wall time in microseconds (float)

    Returns:
        dict with keys:
            gain_pct       - projected gain as percentage
            gain_us        - projected gain in microseconds
            best_schedule  - dict of worker -> delay offset in us
            oracle_calls   - number of oracle calls used
            duration_ms    - optimizer runtime in ms

    Example:
        from coolingcube import optimize
        result = optimize({"0": 12000, "1": 11800, "2": 15500, "3": 12500})
        print(result)
    """
    worker_times = {str(k): float(v) for k, v in worker_times.items()}
    n_workers = len(worker_times)

    payload = {
        "n_workers": n_workers,
        "worker_times": worker_times,
    }

    resp = requests.post(
        API_URL,
        json=payload,
        headers={
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json",
        },
        timeout=60,
    )
    resp.raise_for_status()
    data = resp.json()

    return {
        "gain_pct":      data.get("gain_pct", 0),
        "gain_us":       data.get("gain_us", 0),
        "best_schedule": data.get("best_schedule", {}),
        "oracle_calls":  data.get("oracle_calls", 0),
        "duration_ms":   data.get("duration_ms", 0),
        "baseline_tail_us": data.get("baseline_tail_us", 0),
        "best_tail_us":     data.get("best_tail_us", 0),
    }
