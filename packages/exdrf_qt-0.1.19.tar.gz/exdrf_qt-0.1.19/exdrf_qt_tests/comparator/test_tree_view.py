from typing import cast

from PyQt5.QtCore import QItemSelectionModel, QModelIndex
from PyQt5.QtWidgets import QApplication

from exdrf_qt.comparator.widgets.tree import ComparatorTreeView


def _find_row_by_label(
    view: ComparatorTreeView, parent: QModelIndex, label: str
) -> int:
    model = view.model()
    assert model is not None
    rows = model.rowCount(parent)
    for r in range(rows):
        idx = model.index(r, 0, parent)
        if model.data(idx) == label:
            return r
    return -1


def test_expand_and_copy_yaml(manager_factory, qt_app: QApplication):
    mgr = manager_factory()
    view = ComparatorTreeView(manager=mgr)

    # Expand only branches with differences
    view.expand_diff_branches()
    model = view.model()
    assert model is not None
    root = QModelIndex()

    # "Group" has a nested_missing difference -> its index should be expanded
    grp_row = _find_row_by_label(view, root, "Group")
    assert grp_row >= 0
    grp_idx = model.index(grp_row, 0, root)
    assert view.isExpanded(grp_idx) is True

    # Copy ALL
    view.copy_all_as_yaml()
    clipboard = QApplication.clipboard()
    assert clipboard is not None
    text_all = clipboard.text()
    assert "type: parent" in text_all
    assert "label: Group" in text_all
    assert "label: Nested Missing" in text_all

    # Select only "Group" and copy selection
    sel = view.selectionModel()
    assert sel is not None
    sel.select(
        grp_idx,
        cast(
            QItemSelectionModel.SelectionFlags,
            QItemSelectionModel.SelectionFlag.Select
            | QItemSelectionModel.SelectionFlag.Rows
            | QItemSelectionModel.SelectionFlag.Current,
        ),
    )
    view.copy_selection_as_yaml()
    clipboard = QApplication.clipboard()
    assert clipboard is not None
    text_sel = clipboard.text()
    assert "label: Group" in text_sel
    # Root-only fields should not appear in the group-only export
    assert "label: Partial Field" not in text_sel


def test_merge_mode_columns_and_payload(manager_factory, qt_app):
    """With merge_enabled, view has Method/Result columns and payload works."""
    mgr = manager_factory()
    view = ComparatorTreeView(manager=mgr, merge_enabled=True)
    model = view.model()
    assert model is not None

    assert model.columnCount() == 1 + len(mgr.sources) + 2
    payload = view.get_merged_payload()
    assert isinstance(payload, dict)
    assert "k_equal" in payload
    assert payload["k_equal"] == "SAME"
