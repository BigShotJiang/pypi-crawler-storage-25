import logging
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    Generic,
    List,
    Optional,
    TypeVar,
)

from attrs import define, field
from exdrf.api import ExField
from exdrf.filter import FieldFilter
from PyQt5.QtCore import QSize, Qt
from PyQt5.QtGui import QBrush, QColor, QFont
from sqlalchemy import inspect
from sqlalchemy.orm.collections import InstrumentedList, InstrumentedSet
from sqlalchemy.sql.operators import or_, regexp_match_op
from unidecode import unidecode

from exdrf_qt.context_use import QtUseContext
from exdrf_qt.models.fi_op import filter_op_registry

if TYPE_CHECKING:
    from PyQt5.QtWidgets import QWidget  # noqa: F401
    from sqlalchemy.orm.session import Session

    from exdrf_qt.comparator.logic.merge import (
        LeafMergeState,
        MergeContext,
        MergeMethodOption,
    )
    from exdrf_qt.comparator.logic.nodes import LeafNode
    from exdrf_qt.context import QtContext  # noqa: F401
    from exdrf_qt.models.model import QtModel  # noqa: F401
    from exdrf_qt.models.selector import Selector

DBM = TypeVar("DBM")
logger = logging.getLogger(__name__)
VERBOSE = 1
ROLE_MAP = {
    "DisplayRole": Qt.ItemDataRole.DisplayRole,
    "DecorationRole": Qt.ItemDataRole.DecorationRole,
    "EditRole": Qt.ItemDataRole.EditRole,
    "ToolTipRole": Qt.ItemDataRole.ToolTipRole,
    "StatusTipRole": Qt.ItemDataRole.StatusTipRole,
    "WhatsThisRole": Qt.ItemDataRole.WhatsThisRole,
    "FontRole": Qt.ItemDataRole.FontRole,
    "TextAlignmentRole": Qt.ItemDataRole.TextAlignmentRole,
    "BackgroundRole": Qt.ItemDataRole.BackgroundRole,
    "ForegroundRole": Qt.ItemDataRole.ForegroundRole,
    "CheckStateRole": Qt.ItemDataRole.CheckStateRole,
    "AccessibleTextRole": Qt.ItemDataRole.AccessibleTextRole,
    "AccessibleDescriptionRole": Qt.ItemDataRole.AccessibleDescriptionRole,
    "SizeHintRole": Qt.ItemDataRole.SizeHintRole,
    "InitialSortOrderRole": Qt.ItemDataRole.InitialSortOrderRole,
    "UserRole": Qt.ItemDataRole.UserRole,
}

NO_EDITOR_VALUE = object()

regular_font = QFont("Arial", 10, QFont.Normal)
italic_font = QFont("Arial", 10, QFont.Normal)
italic_font.setItalic(True)
small_font = QFont("Arial", 8, QFont.Normal)
dark_grey = QBrush(QColor(50, 50, 50))
light_grey = QBrush(QColor(200, 200, 200))


@define(slots=False)
class QtField(ExField, QtUseContext, Generic[DBM]):
    """Base class for fields (columns) inside a model.

    Attributes:
        ctx: The context object.
        resource: The model that this field belongs to.
        preferred_width: The preferred width of the field in pixels.
    """

    ctx: "QtContext" = field(default=None)
    resource: "QtModel" = field(default=None)  # type: ignore[assignment]
    preferred_width: int = field(default=100)

    def is_editable(self) -> bool:
        """Return whether the field can be edited inline.

        Returns:
            True if the field is editable, False otherwise.
        """
        return (
            self.visible
            and not self.read_only
            and not self.is_derived
            and (not self.primary or self._primary_is_editable())
        )

    def _primary_is_editable(self) -> bool:
        """Return whether a primary key field should be editable.

        Primary keys are editable only when they are not database-allocated.
        Composite primary keys are treated as editable by default (e.g., join
        tables).

        Returns:
            True if the primary key can be edited, False otherwise.
        """
        try:
            if self.resource is None:
                return False
            if len(self.resource.primary_key_fields) > 1:
                return True
            mapper = inspect(self.resource.db_model)
            prop = mapper.get_property(self.name)
            if not hasattr(prop, "columns") or not prop.columns:
                return True
            column = prop.columns[0]
            if getattr(column, "identity", None) is not None:
                return False
            if column.server_default is not None:
                return False
            if getattr(column, "autoincrement", False):
                return False
            return True
        except Exception:
            logger.log(
                VERBOSE,
                "Failed to determine PK editability for %s.%s",
                getattr(self.resource, "name", "?"),
                self.name,
                exc_info=True,
            )
            return False

    def values(self, record: DBM) -> Dict[Qt.ItemDataRole, Any]:
        """Return the values for this field.

        Args:
            record: The database record.

        Returns:
            A dictionary that maps the role to the data.
        """
        raise NotImplementedError()

    def create_editor(self, parent: "QWidget") -> Optional["QWidget"]:
        """Create an editor widget for inline editing.

        Args:
            parent: The parent widget for the editor.

        Returns:
            The editor widget or None if the field is not editable inline.
        """
        return None

    def configure_editor(
        self,
        editor: "QWidget",
        commit_cb: Callable[["QWidget"], None],
    ) -> None:
        """Attach signals to the editor for inline editing.

        Args:
            editor: The editor widget to configure.
            commit_cb: Callback to commit and close the editor.
        """
        return None

    def set_editor_data(self, editor: "QWidget", value: Any) -> None:
        """Populate the editor with the current value.

        Args:
            editor: The editor widget.
            value: The current value for the field.
        """
        if hasattr(editor, "change_field_value"):
            editor.change_field_value(value)  # type: ignore[attr-defined]

    def editor_value(self, editor: "QWidget") -> Any:
        """Extract the value from the editor.

        Args:
            editor: The editor widget.

        Returns:
            The editor value or NO_EDITOR_VALUE if it is invalid.
        """
        if hasattr(editor, "validate_control"):
            result = editor.validate_control()  # type: ignore[attr-defined]
            if hasattr(result, "is_valid") and not result.is_valid:
                return NO_EDITOR_VALUE

        if hasattr(editor, "field_value"):
            return editor.field_value  # type: ignore[attr-defined]

        if hasattr(editor, "text"):
            return editor.text()  # type: ignore[attr-defined]

        return NO_EDITOR_VALUE

    def apply_edit_value(
        self, db_item: DBM, value: Any, session: "Session"
    ) -> None:
        """Apply the edited value to the database item.

        Args:
            db_item: The database item to update.
            value: The edited value to apply.
            session: The SQLAlchemy session used for updates.
        """
        existing = getattr(db_item, self.name)
        if isinstance(existing, InstrumentedList):
            if value is None:
                value = []
            elif not isinstance(value, list):
                value = list(value)
        elif isinstance(existing, InstrumentedSet):
            if value is None:
                value = set()
            elif not isinstance(value, set):
                value = set(value)

        setattr(db_item, self.name, value)

    def apply_sorting(self, ascending: bool) -> Any:
        """Compute the sorting by this field.

        The default implementation is suitable for fields that map to columns.
        Reimplement this method if you want something else.

        Args:
            ascending: True if the sorting should be ascending, False otherwise.

        Returns:
            The SQLAlchemy sorting expression for this field. If you want the
            result to be ignored, return None.
        """
        column = getattr(self.resource.db_model, self.name)
        return column.asc() if ascending else column.desc()

    def apply_sub_filter(
        self, item: "FieldFilter", selector: "Selector", path: List[str]
    ) -> Any:
        """Compute the filtering by this field."""
        raise NotImplementedError()

    def apply_filter(
        self,
        item: "FieldFilter",
        selector: "Selector",
        no_dia: Optional[str] = None,
    ) -> Any:
        """Compute the filtering by this field.

        The default implementation is suitable for fields that map to columns.
        Reimplement this method if you want something else.

        Args:
            item: The filter item.
            selector: The selector context (not used in default implementation).

        Returns:
            The SQLAlchemy filtering expression for this field. If you want the
            result to be ignored, return None.
        """
        from exdrf.constants import FIELD_TYPE_STRING

        column = getattr(self.resource.db_model, self.name)

        # SQLite doesn't support the flags parameter for regexp_match_op.
        # Instead, we need to embed the flags inline in the pattern using
        # Python's inline flag syntax: (?im) for case-insensitive and
        # multi-line matching.
        if (
            selector.dialect == "sqlite"
            and item.op == "regex"
            and isinstance(item.vl, str)
        ):
            # Prepend inline flags to the pattern for SQLite.
            pattern = f"(?im){item.vl}".replace("(?im)(?im)", "(?im)")
            return regexp_match_op(column, pattern, flags=None)

        if self.type_name == FIELD_TYPE_STRING and no_dia:
            ua_column = getattr(self.resource.db_model, no_dia)
            return or_(
                filter_op_registry[item.op].predicate(
                    column,
                    item.vl,
                ),
                filter_op_registry[item.op].predicate(
                    ua_column,
                    unidecode(item.vl),
                ),
            )
        else:
            return filter_op_registry[item.op].predicate(
                column,
                item.vl,
            )

    def blob_values(self, value: bytes) -> Dict[Qt.ItemDataRole, Any]:
        """Return the values for a blob field.

        Args:
            value: The blob value.

        Returns:
            A dictionary that maps the role to the data.
        """
        return {
            Qt.ItemDataRole.EditRole: value,
            Qt.ItemDataRole.DisplayRole: "BLOB",
            Qt.ItemDataRole.ToolTipRole: "BLOB",
        }

    def not_implemented_values(self, value: Any) -> Dict[Qt.ItemDataRole, Any]:
        """Return the values for a field that is not implemented.

        Args:
            value: The value that is not implemented.

        Returns:
            A dictionary that maps the role to the data.
        """
        return {
            Qt.ItemDataRole.EditRole: value,
            Qt.ItemDataRole.DisplayRole: "NOT IMPLEMENTED",
            Qt.ItemDataRole.ToolTipRole: "NOT IMPLEMENTED",
        }

    def expand_value(self, value: Any, **kwargs) -> Dict[Qt.ItemDataRole, Any]:
        """Common way of dealing with values.

        In your `values()` method you will usually provide this method with the
        value of the field in the model and it will expand it with appropriate
        values for the various roles.

        Following cases are handled:

        - If the value is None, the display role is set to a translated NULL
            label with italic font and grey foreground.

        Args:
            value: The raw value to set.
            **kwargs: Optional role overrides. Keys should be role names from
                ROLE_MAP (e.g., "DisplayRole", "FontRole").

        Returns:
            A dictionary that maps Qt.ItemDataRole to the appropriate data
            values for all roles.
        """
        result = {
            Qt.ItemDataRole.DisplayRole: value,
            Qt.ItemDataRole.DecorationRole: None,
            Qt.ItemDataRole.EditRole: value,
            Qt.ItemDataRole.ToolTipRole: value,
            Qt.ItemDataRole.StatusTipRole: value,
            Qt.ItemDataRole.WhatsThisRole: None,
            Qt.ItemDataRole.FontRole: regular_font,
            Qt.ItemDataRole.TextAlignmentRole: (
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
            ),
            Qt.ItemDataRole.BackgroundRole: None,
            Qt.ItemDataRole.ForegroundRole: None,
            Qt.ItemDataRole.CheckStateRole: None,
            Qt.ItemDataRole.AccessibleTextRole: value,
            Qt.ItemDataRole.AccessibleDescriptionRole: value,
            Qt.ItemDataRole.SizeHintRole: QSize(self.preferred_width, 24),
        }

        # Handle the case where the value is None.
        if value is None:
            label = self.t("cmn.null", "NULL")
            description = self.t("cmn.null_tip", "The value is not set")
            result[Qt.ItemDataRole.FontRole] = italic_font
            result[Qt.ItemDataRole.ForegroundRole] = light_grey
            result[Qt.ItemDataRole.AccessibleTextRole] = label
            result[Qt.ItemDataRole.DisplayRole] = label
            result[Qt.ItemDataRole.ToolTipRole] = description
            result[Qt.ItemDataRole.StatusTipRole] = description
            result[Qt.ItemDataRole.TextAlignmentRole] = (
                Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter
            )
            result[Qt.ItemDataRole.SizeHintRole] = QSize(24, 24)

        # Allow overrides by the user.
        for k in kwargs:
            result[ROLE_MAP[k]] = kwargs[k]

        return result

    # Comparator/merge extension hooks (used by cmp widgets and adapters).
    # ---------------------------------------------------------------------

    def cmp_extract_value(self, record: DBM) -> Any:
        """Extract value from record for comparison.

        Override for custom display or serialization in the comparator.

        Args:
            record: The database record.

        Returns:
            Value to use in the comparator tree for this field.
        """
        return getattr(record, self.name, None)

    def cmp_normalize_value(self, value: Any) -> Any:
        """Normalize a value for display or comparison in the comparator.

        Override for types that need formatting (e.g. dates, FKs as labels).

        Args:
            value: Raw value from the record or merge result.

        Returns:
            Normalized value for display/comparison.
        """
        return value

    def cmp_available_methods(
        self,
        manager: Any,
        leaf: "LeafNode",
    ) -> Optional[List["MergeMethodOption"]]:
        """Return merge method options for this field, or None for strategy default.

        Args:
            manager: The comparator manager.
            leaf: The leaf node (key/label identify the property).

        Returns:
            List of method options, or None to use manager strategy default.
        """
        return None

    def cmp_create_manual_editor(
        self,
        parent: Any,
        context: "MergeContext",
        state: "LeafMergeState",
        current_value: Any,
    ) -> Optional[Any]:
        """Create a custom editor for the merge result cell, or None for default.

        Args:
            parent: Parent Qt widget for the editor.
            context: Merge context for the leaf.
            state: Current merge state.
            current_value: Current value to show in the editor.

        Returns:
            Editor widget, or None to use default (e.g. line edit).
        """
        return None

    def cmp_apply_resolved_value(self, value: Any) -> Any:
        """Transform resolved merge value before applying to record/serialization.

        Override for relation fields that need to resolve IDs to records.

        Args:
            value: Resolved value from the merge strategy.

        Returns:
            Value to apply (e.g. ID, record, or list of same).
        """
        return value

    def save_value_to(
        self, record: DBM, value: Any, session: "Session"
    ) -> None:
        """Set in the database record the value of the edit role."""
        setattr(record, self.name, value)
