from typing import TYPE_CHECKING, Optional

from PyQt5.QtCore import pyqtProperty  # type: ignore

from exdrf_qt.field_ed.base_number import NumberBase
from exdrf_qt.field_ed.choices_mixin import EditorWithChoices

if TYPE_CHECKING:
    from exdrf.field import ExField


class DrfRealEditor(NumberBase[float], EditorWithChoices):
    """Editor for real numbers."""

    decimals: int

    def __init__(self, decimals: int = 2, **kwargs) -> None:
        super().__init__(**kwargs)
        self.decimals = decimals

    def validate(self, text: str) -> Optional[float]:
        """Validates the text and returns the number if valid."""
        if len(text) == 0:
            return None
        try:
            return float(text)
        except ValueError:
            return None

    def stringify(self, value: float) -> str:
        """Converts the number to a string."""
        return f"{value:.{self.decimals}f}" if value is not None else ""

    def create_ex_field(self) -> "ExField":
        from exdrf.field_types.float_field import FloatField

        return FloatField(
            name=self.name,
            description=self.description or "",
            nullable=self.nullable,
            min=self.min,
            max=self.max,
            precision=self.decimals,
            scale=self.scale,
            unit=self.unit,
            unit_symbol=self.unit_symbol,
        )

    def getPrecision(self) -> int:
        """Get the precision of the field.

        This is a support function for implementing the precision property.
        """
        return self.decimals

    def setPrecision(self, value: int) -> None:
        """Set the name of the field in the database record.

        This is a support function for implementing the precision property.
        """
        self.decimals = value

    precision = pyqtProperty(int, fget=getPrecision, fset=setPrecision)


if __name__ == "__main__":
    from PyQt5.QtWidgets import QApplication, QVBoxLayout, QWidget

    from exdrf_qt.context import QtContext as LocalContext

    # Create the main window
    app = QApplication([])
    main_window = QWidget()
    main_window.setWindowTitle("DrfBoolEditor Example")

    ctx = LocalContext(c_string="sqlite:///:memory:")

    # Create a layout and add three DrfBlobEditor controls
    layout = QVBoxLayout()
    editor1 = DrfRealEditor(
        ctx=ctx, nullable=True, description="Nullable real number"
    )
    editor1.change_field_value(None)

    editor2 = DrfRealEditor(
        ctx=ctx,
        nullable=False,
        description="Non-nullable real number",
        decimals=3,
    )
    editor2.change_field_value(None)

    editor3 = DrfRealEditor(
        ctx=ctx,
        prefix="Prefix ",
        suffix=" Suffix",
        minimum=0,
        maximum=100,
        nullable=True,
        decimals=4,
        step=0.001,
    )
    editor3.change_field_value(12)

    layout.addWidget(editor1)
    layout.addWidget(editor2)
    layout.addWidget(editor3)

    main_window.setLayout(layout)
    main_window.show()
    app.exec_()
