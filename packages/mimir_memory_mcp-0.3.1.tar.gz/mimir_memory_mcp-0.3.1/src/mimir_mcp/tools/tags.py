"""Tag management tools: suggest and list tags."""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from mimir_mcp import queries
from mimir_mcp.db import Database, get_db


def suggest_tags_impl(db: Database, query: str) -> list[dict]:
    """Suggest tags matching a prefix/LIKE pattern on ID or aliases.

    Matches tag IDs and aliases (JSON array in tags.aliases column).
    """
    return queries.tags_suggest(db, query)


def list_tags_impl(db: Database, *, categories: list[str] | None = None) -> list[dict]:
    """List all tags, optionally filtered by category."""
    return queries.tags_list(db, categories=categories)


def register(mcp):
    """Register tag MCP tools."""

    @mcp.tool
    def suggest_tags(
        query: Annotated[
            str,
            Field(
                description="Tag name prefix to search for. Matches against tag IDs and aliases (e.g., 'pri' matches 'priority', 'private')."
            ),
        ],
    ) -> list[dict]:
        """Autocomplete tags by prefix. Matches tag names and aliases. Use before adding tags to find existing ones and avoid duplicates."""
        return suggest_tags_impl(get_db(), query)

    @mcp.tool
    def list_tags(
        categories: Annotated[
            list[str] | None,
            Field(
                default=None,
                description="Filter to tags in these category IDs. None (default) returns all tags across all categories.",
            ),
        ],
    ) -> list[dict]:
        """List all available tags, optionally filtered by category."""
        return list_tags_impl(get_db(), categories=categories)
