"""Context management tools: set_context, refresh_context."""

from __future__ import annotations

from typing import Annotated

from pydantic import Field

from mimir_mcp import queries
from mimir_mcp.auth import get_current_scopes, get_current_user
from mimir_mcp.db import Database, get_db


def build_boot_summary(db: Database, user_id: str, scopes: list[str]) -> dict:
    """Build the boot-level summary (projects, tasks, reminders, ideas, global_facts)."""
    items = queries.items_top_level_active(db, scopes, exclude_types=("fact", "reminder"))
    projects = []
    tasks = []
    ideas = []
    for item in items:
        item_dict = dict(item)
        item_type = item_dict["type"]
        if item_type == "project":
            projects.append(item_dict)
        elif item_type == "task":
            tasks.append(item_dict)
        elif item_type == "idea":
            ideas.append(item_dict)

    reminders_raw = queries.items_reminders_upcoming(db, scopes)
    reminders = [dict(r) for r in reminders_raw]

    facts_raw = queries.items_facts_by_scope(db, scopes)
    global_facts = group_facts_by_tag(facts_raw)

    return {
        "projects": projects,
        "tasks": tasks,
        "ideas": ideas,
        "reminders": reminders,
        "global_facts": global_facts,
    }


def group_facts_by_tag(facts_raw) -> dict[str, list[dict]]:
    """Group facts by their tags. Untagged facts go under 'untagged'."""
    global_facts: dict[str, list[dict]] = {}
    for fact in facts_raw:
        fact_dict = dict(fact)
        tags_str = fact_dict.get("tags")
        if tags_str:
            for tag in tags_str.split(","):
                tag = tag.strip()
                if tag:
                    global_facts.setdefault(tag, []).append(fact_dict)
        else:
            global_facts.setdefault("untagged", []).append(fact_dict)
    return global_facts


def build_focused_view(db: Database, item_id: int, scopes: list[str]) -> dict:
    """Build the focused view for a specific item: detail + children + global facts."""
    item_row = queries.items_get_by_id(db, item_id)
    item_detail = dict(item_row)

    # Children grouped by type
    children_raw = queries.items_get_children(db, item_id, scopes)
    children: dict[str, list[dict]] = {}
    for child in children_raw:
        child_dict = dict(child)
        child_type = child_dict["type"]
        children.setdefault(child_type, []).append(child_dict)

    # Global facts
    facts_raw = queries.items_facts_by_scope(db, scopes)
    global_facts = group_facts_by_tag(facts_raw)

    return {
        "item": item_detail,
        "children": children,
        "global_facts": global_facts,
    }


def set_context_impl(
    db: Database, user_id: str, scopes: list[str], *, item_id: int | None = None
) -> dict:
    """Focus on a specific item or clear focus back to boot-level view.

    With item_id: validates scope access, updates session, returns item detail + children + facts.
    Without item_id (None): clears focus, returns boot-level summary.
    Both include tags_in_use per scope for consistent tagging.
    """
    session = queries.sessions_get_active(db, user_id)
    if not session:
        return {"error": "No active session found."}

    session_id = session["id"]

    if item_id is not None:
        # Validate item exists
        item_row = queries.items_get_by_id(db, item_id)
        if not item_row:
            return {"error": f"Item {item_id} not found."}

        # Validate item is in one of user's scopes
        if item_row["scope"] not in scopes:
            return {"error": f"Item {item_id} is not in your accessible scopes."}

        # Update session context
        queries.sessions_update_context(db, session_id, item_id)
        db.commit()

        result = build_focused_view(db, item_id, scopes)
    else:
        # Clear context
        queries.sessions_update_context(db, session_id, None)
        db.commit()

        result = build_boot_summary(db, user_id, scopes)

    # Include tags in use for the relevant scopes
    result["tags_in_use"] = queries.tags_in_use(db, scopes)
    return result


def refresh_context_impl(db: Database, user_id: str, scopes: list[str]) -> dict:
    """Refresh the current context view.

    If focused on an item, returns focused view. Otherwise returns boot summary.
    Always includes scopes, session activity, shared activity, and tags_in_use.
    """
    session = queries.sessions_get_active(db, user_id)
    if not session:
        return {"error": "No active session found."}

    session_id = session["id"]
    active_context_id = session["active_context_id"]

    # Build base result depending on focus state
    if active_context_id is not None:
        result = build_focused_view(db, active_context_id, scopes)
    else:
        result = build_boot_summary(db, user_id, scopes)

    # Add scopes
    all_user_scopes = queries.scopes_for_user(db, user_id)
    scope_list = []
    for s in all_user_scopes:
        if s["id"] in scopes:
            scope_list.append(
                {
                    "id": s["id"],
                    "name": s["name"],
                    "description": s["description"],
                    "members": s["member_ids"],
                }
            )
    result["scopes"] = scope_list

    # Add session activity
    activity_raw = queries.items_session_activity(db, session_id)
    result["session_activity"] = [dict(a) for a in activity_raw]

    # Add shared activity
    shared_activity_raw = queries.activity_get_shared(db, user_id, scopes)
    result["recent_shared_activity"] = [dict(a) for a in shared_activity_raw]

    # Add tags in use
    result["tags_in_use"] = queries.tags_in_use(db, scopes)

    db.commit()

    return result


def register(mcp):
    """Register context MCP tools."""

    @mcp.tool(name="set_context")
    def set_context_tool(
        item_id: Annotated[
            int | None,
            Field(
                default=None,
                description="Item to focus on — returns its full detail, children, and relevant facts. Pass None to clear focus and return to the top-level overview.",
            ),
        ],
    ) -> dict:
        """Focus on a specific item or return to the top-level overview. With item_id: returns that item's full detail, its children (summaries), and facts. With item_id=None: clears focus and returns the top-level summary (projects, tasks, ideas, reminders, facts). Both include tags_in_use — existing tags per scope for consistent naming. Does NOT reload session or shared activity — use refresh_context for that."""
        return set_context_impl(get_db(), get_current_user(), get_current_scopes(), item_id=item_id)

    @mcp.tool(name="refresh_context")
    def refresh_context_tool() -> dict:
        """Reload your full current state without changing focus. Returns everything set_context shows, plus scopes with members, changes made during this session, recent changes by other users, and tags_in_use per scope. Use when your conversation context has been compressed and you need to rebuild working memory. Unlike start_session, does not create a new session."""
        return refresh_context_impl(get_db(), get_current_user(), get_current_scopes())
