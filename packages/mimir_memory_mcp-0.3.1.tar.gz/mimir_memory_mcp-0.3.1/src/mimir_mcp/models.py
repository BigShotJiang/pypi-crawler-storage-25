from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, Field


# --- Input models ---


class ItemInput(BaseModel):
    scope: Annotated[
        str,
        Field(
            description="Scope this item belongs to (e.g., 'jimmy', 'household'). Must be a scope you have access to."
        ),
    ]
    type: Annotated[
        Literal["task", "project", "fact", "reminder", "note", "idea"],
        Field(
            description="Determines behavior and lifecycle. Tasks/projects track work and have status flow (not_started -> in_progress -> completed). Facts store persistent knowledge (support expiration via valid_until). Reminders are time-triggered alerts. Notes capture freeform context. Ideas are lightweight proposals."
        ),
    ]
    summary: Annotated[
        str,
        Field(
            description="Short, self-contained headline (1-2 sentences). Must be fully understandable without the detail field. Shown in session summaries and search results. Good: 'Alex is allergic to shellfish'. Bad: 'allergy info'."
        ),
    ]
    detail: Annotated[
        str | None,
        Field(
            default=None,
            description="Extended description, background, or specifications that don't fit in summary. Loaded on demand — not shown in search results or session summaries. Can be multi-paragraph. Omit or pass None if summary is sufficient.",
        ),
    ]
    parent_id: Annotated[
        int | None,
        Field(
            default=None,
            description="Nest under this item. Parent must be a project, task, or idea in the same scope. Omit or pass None for a top-level item.",
        ),
    ]
    tags: Annotated[
        list[str] | None,
        Field(
            default=None,
            description="Tags to attach (freeform strings). Omit or pass None for no tags.",
        ),
    ]
    priority: Annotated[
        Literal["urgent", "high", "normal", "low"] | None,
        Field(
            default=None,
            description="Affects sort order in listings — items are sorted by priority then position. Omit or pass None to leave unset.",
        ),
    ]
    status: Annotated[
        str | None,
        Field(
            default=None,
            description="Override the type-specific default status. Defaults by type: task='not_started', project/fact/reminder/note/idea='active'. Other valid values: 'in_progress', 'completed', 'archived'. Use when an item is already in progress or completed.",
        ),
    ]
    due_date: Annotated[
        str | None,
        Field(
            default=None,
            description="When this item is due (ISO 8601 date or datetime, e.g., '2025-06-15' or '2025-06-15T14:00:00'). Omit or pass None if no deadline.",
        ),
    ]
    valid_until: Annotated[
        str | None,
        Field(
            default=None,
            description="Expiration date (ISO 8601, e.g., '2025-06-15'). Only enforced for fact-type items — expired facts are automatically excluded from queries. Silently stored but has no effect on other item types. Omit or pass None for no expiration.",
        ),
    ]
    position: Annotated[
        float | None,
        Field(
            default=None,
            description="Sort position among siblings under the same parent. Lower values appear first. Use decimal values to insert between existing items (e.g., 1.5 between positions 1 and 2). Omit to leave unpositioned.",
        ),
    ]
    source: Annotated[
        Literal["learned", "user_stated", "documented"] | None,
        Field(
            default=None,
            description="Origin of a fact — 'learned' = inferred by the system, 'user_stated' = told directly by the user, 'documented' = sourced from a document or reference. Only meaningful for type='fact'. Silently stored but ignored for other types.",
        ),
    ]
    metadata: Annotated[
        dict | None,
        Field(
            default=None,
            description="Arbitrary key-value JSON data for integrations or custom workflows (e.g., {'url': '...', 'priority_score': 42}). Stored as-is. Not indexed for search — use tags for filterable categorization.",
        ),
    ]


class ReorderEntry(BaseModel):
    item_id: Annotated[int, Field(description="ID of the item to reposition.")]
    position: Annotated[
        float,
        Field(
            description="New sort position. Lower values appear first. Use decimals to insert between existing positions (e.g., 1.5 between 1 and 2)."
        ),
    ]


# --- Output models ---


class ScopeOutput(BaseModel):
    id: str
    name: str
    description: str | None = None
    members: list[dict] | None = None


class ItemSummary(BaseModel):
    id: int
    type: str
    scope: str
    status: str
    priority: str | None = None
    summary: str
    tags: list[str] = []
    due_date: str | None = None
    position: float | None = None


class ItemDetail(ItemSummary):
    detail: str | None = None
    source: str | None = None
    valid_until: str | None = None
    metadata: dict | None = None
    created_by: str | None = None
    updated_by: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class HistoryEntry(BaseModel):
    event: str
    content: (
        str  # JSON structured diff, e.g. [{"field": "priority", "old": "normal", "new": "high"}]
    )
    actor: str | None = None
    session_id: int | None = None
    correlation_id: str | None = None
    created_at: str | None = None


class SharedActivityEntry(BaseModel):
    item_id: int
    summary: str
    event: str
    actor: str
    created_at: str


class SessionBootResponse(BaseModel):
    user: dict
    scopes: list[ScopeOutput]
    last_session: dict | None = None
    stale_sessions: int = 0
    projects: list[ItemSummary] = []
    tasks: list[ItemSummary] = []
    reminders: list[ItemSummary] = []
    ideas: list[ItemSummary] = []
    global_facts: dict[str, list[dict]] = {}
    recent_shared_activity: list[SharedActivityEntry] = []
