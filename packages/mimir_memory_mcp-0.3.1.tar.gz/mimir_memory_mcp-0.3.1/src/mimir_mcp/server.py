"""FastMCP server entry point with authentication middleware."""

import os
import sys
from pathlib import Path

from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from fastmcp.server.dependencies import get_http_headers
from fastmcp.server.middleware import Middleware, MiddlewareContext

from starlette.requests import Request
from starlette.responses import JSONResponse

from mimir_mcp.auth import resolve_user, set_auth_context
from mimir_mcp.db import Database, get_db, init_db
from mimir_mcp.tools import register_all_tools

MIMIR_API_VERSION = "1"


def _authenticate(db: Database, api_key: str | None):
    """Shared auth for MCP middleware and REST. Returns (user_id, scopes, is_admin) or None."""
    if not api_key:
        return None
    return resolve_user(db, api_key)


def _execute_seed_sql(db: Database, path: Path) -> None:
    """Execute a seed SQL file with foreign keys enabled."""
    sql = "PRAGMA foreign_keys = ON;\n" + path.read_text()
    db.conn.executescript(sql)
    db.commit()


class AuthMiddleware(Middleware):
    """Extract API key from HTTP headers and set auth context on every tool call."""

    async def on_call_tool(self, context: MiddlewareContext, call_next):
        headers = get_http_headers() or {}
        api_key = headers.get("x-api-key")

        result = _authenticate(get_db(), api_key)
        if result is None:
            raise ToolError("Missing x-api-key header" if not api_key else "Invalid API key")

        user_id, scopes, admin = result
        set_auth_context(user_id, scopes, is_admin=admin)
        return await call_next(context)


def auto_seed(db: Database, seed_file: str | None = None) -> None:
    """Apply seed file if the database has no users yet. Idempotent."""
    if seed_file is None:
        seed_file = os.environ.get("MIMIR_SEED_FILE")
    if not seed_file:
        return

    path = Path(seed_file)
    if not path.exists():
        return

    row = db.fetchone("SELECT COUNT(*) as n FROM users")
    if row and row["n"] > 0:
        return

    _execute_seed_sql(db, path)
    print(f"Seed data loaded from {seed_file}")


def create_server(db_path: str | None = None) -> FastMCP:
    """Create and configure the FastMCP server instance."""
    if db_path is None:
        db_path = os.environ.get("MIMIR_DB_PATH", "/data/mimir.db")

    db = init_db(db_path)
    auto_seed(db)

    mcp = FastMCP(
        name="Mimir",
        instructions=(
            "Mimir is a structured memory server for AI assistants. All data is "
            "scoped to the authenticated user.\n\n"
            "Items are the core unit of memory. Each item has a type (task, project, "
            "fact, reminder, note, idea), belongs to a scope, and has a summary "
            "(short headline) and optional detail (extended description). Items can "
            "form trees: projects, tasks, and ideas can have children; facts, notes, "
            "and reminders cannot.\n\n"
            "Scopes are access groups. Each user has a personal scope plus any "
            "shared scopes (e.g., 'household'). You only see items in scopes you "
            "belong to.\n\n"
            "Session lifecycle -- follow this order:\n"
            "1. Call start_session once at conversation start. Returns your full context.\n"
            "2. Call save_session periodically during long conversations to preserve "
            "your position in shared activity.\n"
            "3. Call end_session when the conversation ends. Pass any new facts "
            "learned as learnings.\n\n"
            "Context focus:\n"
            "- Use set_context to drill into a specific item (shows its detail and "
            "children) or clear focus to return to the top-level overview.\n"
            "- Use refresh_context to reload the current view with fresh data when "
            "your conversation context has been compressed.\n\n"
            "Finding items:\n"
            "- search_items: keyword search with stemming. Use when you have words to find.\n"
            "- list_items: filtered browse by type, status, scope, parent. Use when "
            "you want to browse structure.\n"
            "- get_facts: retrieve facts by tag or parent item. Use for targeted fact lookup.\n\n"
            "Tags are freeform strings — no predefined taxonomy. start_session, "
            "set_context, and refresh_context return tags_in_use per scope. "
            "Use these to maintain consistent tagging when creating new items."
        ),
    )
    mcp.add_middleware(AuthMiddleware())
    register_all_tools(mcp)

    # ── REST API (for Claude Code hooks) ────────────────────────────────────
    from mimir_mcp.tools.session import checkpoint_session_impl, end_session_impl
    from mimir_mcp.tools.search import search_items_impl as search_items
    from mimir_mcp.tools.items import add_items_impl as add_items

    _version_headers = {"X-Mimir-API-Version": MIMIR_API_VERSION}

    def _api_response(data, status_code=200):
        """JSON response with API version header."""
        return JSONResponse(data, status_code=status_code, headers=_version_headers)

    def _rest_auth(request: Request):
        """Validate API key from request headers."""
        api_key = request.headers.get("x-api-key")
        result = _authenticate(db, api_key)
        if result is None:
            msg = "Missing x-api-key" if not api_key else "Invalid API key"
            return None, JSONResponse({"error": msg}, status_code=401)
        user_id, scopes, admin = result
        set_auth_context(user_id, scopes, is_admin=admin)
        return (user_id, scopes), None

    @mcp.custom_route("/health", methods=["GET"])
    async def health(request: Request) -> JSONResponse:
        try:
            db.fetchone("SELECT 1")
            return _api_response({"status": "ok"})
        except Exception as e:
            return _api_response({"status": "error", "detail": str(e)}, status_code=503)

    @mcp.custom_route("/api/session/checkpoint", methods=["POST"])
    async def rest_checkpoint(request: Request) -> JSONResponse:
        auth, err = _rest_auth(request)
        if err:
            return err
        user_id, _ = auth
        result = checkpoint_session_impl(db, user_id)
        return _api_response(result)

    @mcp.custom_route("/api/session/close", methods=["POST"])
    async def rest_close(request: Request) -> JSONResponse:
        auth, err = _rest_auth(request)
        if err:
            return err
        user_id, _ = auth
        result = end_session_impl(db, user_id, learnings=None)
        return _api_response(result)

    @mcp.custom_route("/api/items", methods=["POST"])
    async def rest_create_item(request: Request) -> JSONResponse:
        auth, err = _rest_auth(request)
        if err:
            return err
        user_id, scopes = auth
        body = await request.json()
        result = add_items(db, user_id, scopes, [body])
        return _api_response(result[0] if result else {"error": "No item created"})

    @mcp.custom_route("/api/search", methods=["GET"])
    async def rest_search(request: Request) -> JSONResponse:
        auth, err = _rest_auth(request)
        if err:
            return err
        user_id, scopes = auth
        query = request.query_params.get("q", "")
        result = search_items(db, user_id, scopes, query)
        return _api_response(result)

    return mcp


def run_seed(db_path: str, seed_file: str) -> None:
    """Load a SQL seed file into the database."""
    path = Path(seed_file)
    if not path.exists():
        raise FileNotFoundError(f"Seed file not found: {seed_file}")

    db = Database(db_path)
    db.run_migrations()
    _execute_seed_sql(db, path)
    db.close()
    print(f"Seed data loaded from {seed_file}")


def main():
    """Entry point: run server or seed database."""
    if len(sys.argv) >= 2 and sys.argv[1] == "seed":
        if len(sys.argv) < 4 or sys.argv[2] != "--file":
            print("Usage: mimir-mcp seed --file <path>")
            sys.exit(1)
        db_path = os.environ.get("MIMIR_DB_PATH", "/data/mimir.db")
        run_seed(db_path, sys.argv[3])
    else:
        port = int(os.environ.get("MIMIR_PORT", "8100"))
        server = create_server()
        server.run(transport="sse", host="0.0.0.0", port=port)


if __name__ == "__main__":
    main()
