from mimir_mcp.tools.session import (
    boot_session_impl,
    end_session_impl as end_session,
    checkpoint_session_impl,
)


def test_boot_creates_session(seed_data):
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert result["user"]["name"] == "Jimmy"
    assert len(result["scopes"]) >= 2
    assert result["stale_sessions"] == 0
    session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    assert session is not None


def test_boot_returns_scopes(seed_data):
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    scope_ids = [s["id"] for s in result["scopes"]]
    assert "jimmy" in scope_ids
    assert "household" in scope_ids
    assert "alex" not in scope_ids


def test_boot_auto_closes_stale_sessions(seed_data):
    seed_data.execute("INSERT INTO sessions (user_id) VALUES (?)", ("jimmy",))
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert result["stale_sessions"] == 1
    stale = seed_data.fetchall(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NOT NULL"
    )
    assert len(stale) == 1


def test_boot_does_not_close_other_users_sessions(seed_data):
    seed_data.execute("INSERT INTO sessions (user_id) VALUES (?)", ("alex",))
    seed_data.commit()
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    alex_open = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'alex' AND ended_at IS NULL"
    )
    assert alex_open is not None


def test_boot_returns_last_session_summary(seed_data):
    seed_data.execute(
        "INSERT INTO sessions (user_id, ended_at, summary) VALUES (?, datetime('now'), ?)",
        ("jimmy", "Worked on groceries"),
    )
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert result["last_session"]["summary"] == "Worked on groceries"


def test_boot_returns_items_by_type(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Buy groceries", "jimmy", "jimmy"),
    )
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("jimmy", "project", "in_progress", "Provider Ops", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["tasks"]) == 1
    assert result["tasks"][0]["summary"] == "Buy groceries"
    assert len(result["projects"]) == 1


def test_boot_excludes_completed_items(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("jimmy", "task", "completed", "Done task", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["tasks"]) == 0


def test_boot_returns_global_facts(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "fact", "active", "Alex is allergic to shellfish", "jimmy", "jimmy"),
    )
    fact_id = seed_data.fetchone("SELECT last_insert_rowid() as id")["id"]
    seed_data.execute("INSERT INTO item_tags VALUES (?, ?)", (fact_id, "health"))
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert "health" in result["global_facts"]


def test_end_session(seed_data):
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    result = end_session(seed_data, "jimmy", learnings=["Jaya Grocer has best fish"])
    assert "summary" in result
    session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NOT NULL"
    )
    assert session is not None
    fact = seed_data.fetchone("SELECT * FROM items WHERE type = 'fact' AND source = 'learned'")
    assert fact is not None
    assert "Jaya Grocer" in fact["summary"]


def test_checkpoint(seed_data):
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    result = checkpoint_session_impl(seed_data, "jimmy")
    assert "confirmation" in result


# --- C8: Activity cursor advancement tests ---


def test_boot_does_not_advance_cursor(seed_data):
    """Cursor stays at 0 after boot — events resurface if session crashes."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Shared task", "alex", "alex"),
    )
    seed_data.commit()
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    cursor = seed_data.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = 'jimmy'"
    )
    assert cursor["last_seen_history_id"] == 0


def test_checkpoint_advances_cursor(seed_data):
    """Cursor advances at checkpoint."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Shared task", "alex", "alex"),
    )
    seed_data.commit()
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    checkpoint_session_impl(seed_data, "jimmy")
    cursor = seed_data.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = 'jimmy'"
    )
    assert cursor["last_seen_history_id"] > 0


def test_end_session_advances_cursor(seed_data):
    """Cursor advances at session end."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Shared task", "alex", "alex"),
    )
    seed_data.commit()
    boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    end_session(seed_data, "jimmy")
    cursor = seed_data.fetchone(
        "SELECT last_seen_history_id FROM activity_cursor WHERE user_id = 'jimmy'"
    )
    assert cursor["last_seen_history_id"] > 0


def test_stale_session_auto_closed_on_boot(seed_data):
    """If session ends without checkpoint/end, events reappear on next boot."""
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "task", "not_started", "Shared task by alex", "alex", "alex"),
    )
    seed_data.commit()
    # First boot — sees the event but cursor not advanced
    boot1 = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(boot1["recent_shared_activity"]) > 0
    # Simulate crash: no checkpoint or end_session
    # Second boot — should still see the event
    boot2 = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(boot2["recent_shared_activity"]) > 0


# --- C9: Reminder boot filtering tests ---


def test_boot_includes_reminders_due_within_7_days(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, due_date, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, datetime('now', '+3 days'), ?, ?)",
        ("household", "reminder", "active", "Dentist appointment", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["reminders"]) == 1


def test_boot_excludes_reminders_due_beyond_7_days(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, due_date, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, datetime('now', '+14 days'), ?, ?)",
        ("household", "reminder", "active", "Far future reminder", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["reminders"]) == 0


def test_boot_excludes_reminders_without_due_date(seed_data):
    seed_data.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("household", "reminder", "active", "Undated reminder", "jimmy", "jimmy"),
    )
    seed_data.commit()
    result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    assert len(result["reminders"]) == 0


def test_concurrent_boot_no_interference(seed_data):
    """Two users booting sessions simultaneously don't interfere."""
    result_jimmy = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
    result_alex = boot_session_impl(seed_data, "alex", ["alex", "household"])
    assert result_jimmy["user"]["id"] == "jimmy"
    assert result_alex["user"]["id"] == "alex"
    jimmy_session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    alex_session = seed_data.fetchone(
        "SELECT * FROM sessions WHERE user_id = 'alex' AND ended_at IS NULL"
    )
    assert jimmy_session is not None
    assert alex_session is not None
    assert jimmy_session["id"] != alex_session["id"]
