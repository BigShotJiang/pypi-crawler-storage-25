"""Tests for search & discovery tools."""

from mimir_mcp.tools.session import boot_session_impl
from mimir_mcp.tools.items import add_items_impl as add_items
from mimir_mcp.tools.search import (
    search_items_impl as search_items,
    list_items_impl as list_items,
    get_facts_impl as get_facts,
)


# --- Helpers ---


def _boot_jimmy(db):
    """Boot a session for jimmy and return session_id."""
    boot_session_impl(db, "jimmy", ["jimmy", "household"])
    session = db.fetchone("SELECT id FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL")
    return session["id"]


def _boot_alex(db):
    """Boot a session for alex and return session_id."""
    boot_session_impl(db, "alex", ["alex", "household"])
    session = db.fetchone("SELECT id FROM sessions WHERE user_id = 'alex' AND ended_at IS NULL")
    return session["id"]


def _seed_searchable_items(db, session_id):
    """Create a variety of items for search testing."""
    items = add_items(
        db,
        "jimmy",
        ["jimmy", "household"],
        [
            {
                "scope": "jimmy",
                "type": "task",
                "summary": "Buy groceries from the market",
                "priority": "high",
                "tags": ["shopping"],
            },
            {
                "scope": "jimmy",
                "type": "task",
                "summary": "Schedule dentist appointment",
                "priority": "normal",
                "tags": ["health"],
            },
            {
                "scope": "household",
                "type": "task",
                "summary": "Fix kitchen sink",
                "priority": "urgent",
            },
            {
                "scope": "jimmy",
                "type": "project",
                "summary": "Financial planning review",
                "priority": "high",
                "tags": ["finance"],
            },
            {
                "scope": "jimmy",
                "type": "fact",
                "summary": "Jimmy prefers morning workouts",
                "tags": ["health"],
            },
            {
                "scope": "jimmy",
                "type": "idea",
                "summary": "Start a grocery delivery service",
                "priority": "low",
            },
        ],
        session_id=session_id,
    )
    return items


# ============================================================
# search_items tests (FTS5)
# ============================================================


class TestSearchItems:
    def test_search_fts_basic(self, seed_data):
        """Free text search returns ranked results."""
        session_id = _boot_jimmy(seed_data)
        _seed_searchable_items(seed_data, session_id)

        results = search_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            query="grocery",
        )

        assert len(results) >= 1
        summaries = [r["summary"] for r in results]
        assert any("grocer" in s.lower() for s in summaries)

    def test_search_with_type_filter(self, seed_data):
        """Filter by item type narrows results."""
        session_id = _boot_jimmy(seed_data)
        _seed_searchable_items(seed_data, session_id)

        # Search for "groceries" but only tasks
        results = search_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            query="groceries",
            type="task",
        )

        assert len(results) >= 1
        for r in results:
            assert r["type"] == "task"

        # Search for "grocery" but only ideas — FTS matches "grocery" in
        # "Start a grocery delivery service"
        results_ideas = search_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            query="grocery",
            type="idea",
        )

        assert len(results_ideas) >= 1
        for r in results_ideas:
            assert r["type"] == "idea"

    def test_search_with_status_filter(self, seed_data):
        """Filter by status works correctly."""
        session_id = _boot_jimmy(seed_data)
        items = _seed_searchable_items(seed_data, session_id)

        # Complete one item, then search for it by status
        from mimir_mcp.tools.items import complete_items_impl as complete_items

        task_id = items[0]["id"]  # "Buy groceries from the market"
        complete_items(seed_data, "jimmy", ["jimmy", "household"], [task_id], session_id=session_id)

        # Default search excludes completed
        results = search_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            query="groceries",
        )
        result_ids = [r["id"] for r in results]
        assert task_id not in result_ids

        # Explicit status=completed finds it
        results_completed = search_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            query="groceries",
            status="completed",
        )
        result_ids = [r["id"] for r in results_completed]
        assert task_id in result_ids

    def test_search_scope_enforcement(self, seed_data):
        """Only returns items in user's scopes."""
        session_id = _boot_jimmy(seed_data)
        _seed_searchable_items(seed_data, session_id)

        # Alex can see household but not jimmy scope
        _boot_alex(seed_data)
        results = search_items(
            seed_data,
            "alex",
            ["alex", "household"],
            query="kitchen",
        )

        # Should find "Fix kitchen sink" (household scope)
        assert len(results) >= 1
        for r in results:
            assert r["scope"] in ["alex", "household"]

        # Should NOT find jimmy-scoped items
        results_grocery = search_items(
            seed_data,
            "alex",
            ["alex", "household"],
            query="grocery",
        )
        for r in results_grocery:
            assert r["scope"] != "jimmy"

    def test_search_porter_stemming(self, seed_data):
        """Porter stemming matches word variations."""
        session_id = _boot_jimmy(seed_data)
        add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "fact", "summary": "House has 3 bedrooms"}],
            session_id=session_id,
        )

        results = search_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            query="bedroom",
        )
        assert len(results) == 1
        assert "bedrooms" in results[0]["summary"]


# ============================================================
# list_items tests
# ============================================================


class TestListItems:
    def test_list_items_basic(self, seed_data):
        """Returns items sorted by priority then position."""
        session_id = _boot_jimmy(seed_data)
        _seed_searchable_items(seed_data, session_id)

        results = list_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
        )

        assert len(results) >= 1
        # Check that results are returned as dicts
        for r in results:
            assert "summary" in r
            assert "type" in r
            assert "priority" in r

    def test_list_items_top_level_only(self, seed_data):
        """parent_id=None filters correctly (returns only top-level items)."""
        session_id = _boot_jimmy(seed_data)
        # Create parent
        parent = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Parent Project"}],
            session_id=session_id,
        )
        parent_id = parent[0]["id"]

        # Create child
        add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Child Task", "parent_id": parent_id}],
            session_id=session_id,
        )

        # Default list (parent_id=None) should only include top-level
        results = list_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
        )

        summaries = [r["summary"] for r in results]
        assert "Parent Project" in summaries
        assert "Child Task" not in summaries

    def test_list_items_children(self, seed_data):
        """parent_id shows children of that parent."""
        session_id = _boot_jimmy(seed_data)
        # Create parent and children
        parent = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Parent Project"}],
            session_id=session_id,
        )
        parent_id = parent[0]["id"]

        add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [
                {"scope": "jimmy", "type": "task", "summary": "Child A", "parent_id": parent_id},
                {"scope": "jimmy", "type": "task", "summary": "Child B", "parent_id": parent_id},
            ],
            session_id=session_id,
        )

        results = list_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            parent_id=parent_id,
        )

        assert len(results) == 2
        summaries = [r["summary"] for r in results]
        assert "Child A" in summaries
        assert "Child B" in summaries

    def test_list_items_type_filter(self, seed_data):
        """Type filter narrows results."""
        session_id = _boot_jimmy(seed_data)
        _seed_searchable_items(seed_data, session_id)

        results = list_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            type="task",
        )

        for r in results:
            assert r["type"] == "task"

    def test_list_items_status_filter(self, seed_data):
        """Status filter narrows results."""
        session_id = _boot_jimmy(seed_data)
        items = _seed_searchable_items(seed_data, session_id)

        # Complete one item
        from mimir_mcp.tools.items import complete_items_impl as complete_items

        task_id = items[0]["id"]
        complete_items(seed_data, "jimmy", ["jimmy", "household"], [task_id], session_id=session_id)

        # List only completed
        results = list_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            status="completed",
        )
        result_ids = [r["id"] for r in results]
        assert task_id in result_ids

    def test_list_items_scope_filter(self, seed_data):
        """Scope filter narrows results to a specific scope."""
        session_id = _boot_jimmy(seed_data)
        _seed_searchable_items(seed_data, session_id)

        results = list_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            scope="household",
        )

        for r in results:
            assert r["scope"] == "household"

    def test_list_items_includes_child_counts(self, seed_data):
        """Top-level items include child_count and completed_count."""
        session_id = _boot_jimmy(seed_data)
        from mimir_mcp.tools.items import complete_items_impl as complete_items

        # Create project with 3 children
        project = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Stats Project"}],
            session_id=session_id,
        )
        project_id = project[0]["id"]

        children = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [
                {"scope": "jimmy", "type": "task", "summary": "Task 1", "parent_id": project_id},
                {"scope": "jimmy", "type": "task", "summary": "Task 2", "parent_id": project_id},
                {"scope": "jimmy", "type": "task", "summary": "Task 3", "parent_id": project_id},
            ],
            session_id=session_id,
        )

        # Complete one child
        complete_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [children[0]["id"]],
            session_id=session_id,
        )

        results = list_items(seed_data, "jimmy", ["jimmy", "household"])
        project_result = next(r for r in results if r["summary"] == "Stats Project")

        assert project_result["child_count"] == 3
        assert project_result["completed_count"] == 1

    def test_list_items_leaf_has_zero_counts(self, seed_data):
        """Items with no children have child_count=0 and completed_count=0."""
        session_id = _boot_jimmy(seed_data)
        add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Leaf Task"}],
            session_id=session_id,
        )

        results = list_items(seed_data, "jimmy", ["jimmy", "household"])
        leaf = next(r for r in results if r["summary"] == "Leaf Task")

        assert leaf["child_count"] == 0
        assert leaf["completed_count"] == 0

    def test_list_items_deleted_children_excluded_from_count(self, seed_data):
        """Deleted children are not counted in child_count."""
        session_id = _boot_jimmy(seed_data)
        from mimir_mcp.tools.items import delete_items_impl as delete_items

        project = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Deletion Project"}],
            session_id=session_id,
        )
        project_id = project[0]["id"]

        children = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [
                {"scope": "jimmy", "type": "task", "summary": "Keep", "parent_id": project_id},
                {"scope": "jimmy", "type": "task", "summary": "Delete Me", "parent_id": project_id},
            ],
            session_id=session_id,
        )

        delete_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [children[1]["id"]],
            is_admin=True,
            session_id=session_id,
        )

        results = list_items(seed_data, "jimmy", ["jimmy", "household"])
        project_result = next(r for r in results if r["summary"] == "Deletion Project")

        assert project_result["child_count"] == 1
        assert project_result["completed_count"] == 0

    def test_list_items_scope_enforcement(self, seed_data):
        """Only returns items in user's scopes."""
        session_id = _boot_jimmy(seed_data)
        _seed_searchable_items(seed_data, session_id)

        _boot_alex(seed_data)
        results = list_items(
            seed_data,
            "alex",
            ["alex", "household"],
        )

        for r in results:
            assert r["scope"] in ["alex", "household"]


# ============================================================
# get_facts tests
# ============================================================


class TestGetFacts:
    def test_get_facts_by_tags(self, seed_data):
        """OR logic for tag filtering - any matching tag returns the fact."""
        session_id = _boot_jimmy(seed_data)
        _seed_searchable_items(seed_data, session_id)

        # Search for health-tagged facts
        results = get_facts(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            tags=["health"],
        )

        assert len(results) >= 1
        for r in results:
            assert r["type"] == "fact"

    def test_get_facts_by_tags_or_logic(self, seed_data):
        """Multiple tags use OR logic."""
        session_id = _boot_jimmy(seed_data)
        db = seed_data
        db.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", ("health",))
        db.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", ("diet",))
        db.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", ("finance",))
        db.commit()

        add_items(
            db,
            "jimmy",
            ["jimmy", "household"],
            [
                {
                    "scope": "jimmy",
                    "type": "fact",
                    "summary": "Fact tagged health",
                    "tags": ["health"],
                },
                {"scope": "jimmy", "type": "fact", "summary": "Fact tagged diet", "tags": ["diet"]},
                {
                    "scope": "jimmy",
                    "type": "fact",
                    "summary": "Fact tagged finance",
                    "tags": ["finance"],
                },
            ],
            session_id=session_id,
        )

        results = get_facts(
            db,
            "jimmy",
            ["jimmy", "household"],
            tags=["health", "diet"],
        )

        summaries = [r["summary"] for r in results]
        assert "Fact tagged health" in summaries
        assert "Fact tagged diet" in summaries
        # Finance should NOT be included
        assert "Fact tagged finance" not in summaries

    def test_get_facts_by_item_ids(self, seed_data):
        """Facts related to specific items (children of those items)."""
        session_id = _boot_jimmy(seed_data)
        # Create a project
        project = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "My Project"}],
            session_id=session_id,
        )
        project_id = project[0]["id"]

        # Add fact as child of project
        add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [
                {
                    "scope": "jimmy",
                    "type": "fact",
                    "summary": "Project-related fact",
                    "parent_id": project_id,
                }
            ],
            session_id=session_id,
        )

        results = get_facts(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_ids=[project_id],
        )

        assert len(results) >= 1
        summaries = [r["summary"] for r in results]
        assert "Project-related fact" in summaries

    def test_get_facts_summary_vs_detail(self, seed_data):
        """Level parameter controls detail: summary = summary only, detail = includes detail."""
        session_id = _boot_jimmy(seed_data)
        seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", ("health",))
        seed_data.commit()
        add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [
                {
                    "scope": "jimmy",
                    "type": "fact",
                    "summary": "Summary fact",
                    "detail": "Detailed explanation of this fact",
                    "tags": ["health"],
                }
            ],
            session_id=session_id,
        )

        # L1: should NOT include detail
        results_l1 = get_facts(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            tags=["health"],
            level="summary",
        )

        assert len(results_l1) >= 1
        for r in results_l1:
            assert "detail" not in r

        # L2: should include detail
        results_l2 = get_facts(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            tags=["health"],
            level="detail",
        )

        assert len(results_l2) >= 1
        found = False
        for r in results_l2:
            assert "detail" in r
            if r["summary"] == "Summary fact":
                assert r["detail"] == "Detailed explanation of this fact"
                found = True
        assert found

    def test_get_facts_include_children(self, seed_data):
        """include_children=True includes facts that are children of given items."""
        session_id = _boot_jimmy(seed_data)
        # Create a project with child facts
        project = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Parent Project"}],
            session_id=session_id,
        )
        project_id = project[0]["id"]

        add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [
                {
                    "scope": "jimmy",
                    "type": "fact",
                    "summary": "Child fact one",
                    "parent_id": project_id,
                },
                {
                    "scope": "jimmy",
                    "type": "fact",
                    "summary": "Child fact two",
                    "parent_id": project_id,
                },
            ],
            session_id=session_id,
        )

        results = get_facts(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_ids=[project_id],
            include_children=True,
        )

        summaries = [r["summary"] for r in results]
        assert "Child fact one" in summaries
        assert "Child fact two" in summaries

    def test_get_facts_include_children_deep(self, seed_data):
        """Facts nested under grandchildren are returned when include_children=True."""
        session_id = _boot_jimmy(seed_data)
        # Create project -> task -> fact hierarchy
        project = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "project", "summary": "Parent project"}],
            session_id=session_id,
        )
        project_id = project[0]["id"]
        task = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "task", "summary": "Child task", "parent_id": project_id}],
            session_id=session_id,
        )
        task_id = task[0]["id"]
        fact = add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [{"scope": "jimmy", "type": "fact", "summary": "Deep fact", "parent_id": task_id}],
            session_id=session_id,
        )
        fact_id = fact[0]["id"]

        # Without include_children — only direct children facts
        results = get_facts(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_ids=[project_id],
        )
        assert not any(f["id"] == fact_id for f in results)

        # With include_children — finds descendant facts
        results = get_facts(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            item_ids=[project_id],
            include_children=True,
        )
        assert any(f["id"] == fact_id for f in results)

    def test_get_facts_scope_enforcement(self, seed_data):
        """Only returns facts in user's scopes."""
        session_id = _boot_jimmy(seed_data)
        seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", ("private_tag",))
        seed_data.commit()

        add_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            [
                {
                    "scope": "jimmy",
                    "type": "fact",
                    "summary": "Jimmy private fact",
                    "tags": ["private_tag"],
                }
            ],
            session_id=session_id,
        )

        # Alex cannot see jimmy-scoped facts
        _boot_alex(seed_data)
        results = get_facts(
            seed_data,
            "alex",
            ["alex", "household"],
            tags=["private_tag"],
        )

        for r in results:
            assert r["scope"] != "jimmy"


# ============================================================
# Lazy expiry tests
# ============================================================


class TestLazyExpiry:
    def test_lazy_fact_expiry(self, seed_data):
        """Facts past valid_until are lazily marked expired on read."""
        seed_data.execute(
            "INSERT INTO items (scope, type, status, summary, valid_until, created_by, updated_by) "
            "VALUES (?, ?, ?, ?, datetime('now', '-1 day'), ?, ?)",
            ("household", "fact", "active", "Expired fact", "jimmy", "jimmy"),
        )
        seed_data.commit()
        results = search_items(seed_data, "jimmy", ["jimmy", "household"], query="Expired")
        assert len(results) == 0  # expired facts excluded from default search
        results = search_items(
            seed_data, "jimmy", ["jimmy", "household"], query="Expired", status="expired"
        )
        assert len(results) == 1
        assert results[0]["status"] == "expired"
        # Verify DB was updated
        item = seed_data.fetchone("SELECT status FROM items WHERE summary = 'Expired fact'")
        assert item["status"] == "expired"

    def test_expired_facts_excluded_from_boot(self, seed_data):
        """Boot query excludes facts past valid_until."""
        seed_data.execute(
            "INSERT INTO items (scope, type, status, summary, valid_until, created_by, updated_by) "
            "VALUES (?, ?, ?, ?, datetime('now', '-1 day'), ?, ?)",
            ("household", "fact", "active", "Old expired fact", "jimmy", "jimmy"),
        )
        seed_data.commit()
        result = boot_session_impl(seed_data, "jimmy", ["jimmy", "household"])
        all_fact_summaries = []
        for facts in result["global_facts"].values():
            all_fact_summaries.extend(f["summary"] for f in facts)
        assert "Old expired fact" not in all_fact_summaries

    def test_lazy_expiry_in_get_facts(self, seed_data):
        """get_facts also lazily expires facts past valid_until."""
        _boot_jimmy(seed_data)
        seed_data.execute("INSERT OR IGNORE INTO tags (id) VALUES (?)", ("expiry_test",))
        seed_data.commit()

        # Insert a fact with expired valid_until directly
        seed_data.execute(
            "INSERT INTO items (scope, type, status, summary, valid_until, created_by, updated_by) "
            "VALUES (?, ?, ?, ?, datetime('now', '-1 day'), ?, ?)",
            ("jimmy", "fact", "active", "Expired via get_facts", "jimmy", "jimmy"),
        )
        expired_id = seed_data.execute("SELECT last_insert_rowid()").fetchone()[0]
        seed_data.execute(
            "INSERT INTO item_tags (item_id, tag_id) VALUES (?, ?)",
            (expired_id, "expiry_test"),
        )
        seed_data.commit()

        # get_facts should lazily expire it and exclude from results
        results = get_facts(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            tags=["expiry_test"],
        )

        # Should be excluded (expired)
        result_ids = [r["id"] for r in results]
        assert expired_id not in result_ids

        # DB should now show expired
        item = seed_data.fetchone("SELECT status FROM items WHERE id = ?", (expired_id,))
        assert item["status"] == "expired"

    def test_lazy_expiry_updates_db(self, seed_data):
        """Lazy expiry actually persists the status change to the database."""
        _boot_jimmy(seed_data)
        # Insert an item with expired valid_until
        seed_data.execute(
            "INSERT INTO items (scope, type, status, summary, valid_until, created_by, updated_by) "
            "VALUES (?, ?, ?, ?, datetime('now', '-2 days'), ?, ?)",
            ("jimmy", "fact", "active", "Should be expired", "jimmy", "jimmy"),
        )
        seed_data.commit()

        # First search triggers lazy expiry
        search_items(seed_data, "jimmy", ["jimmy", "household"], query="Should be expired")

        # Verify DB updated
        row = seed_data.fetchone("SELECT status FROM items WHERE summary = 'Should be expired'")
        assert row["status"] == "expired"

    def test_search_expired_with_explicit_filter(self, seed_data):
        """When status='expired' is explicitly requested, find expired facts."""
        _boot_jimmy(seed_data)
        # Insert expired fact
        seed_data.execute(
            "INSERT INTO items (scope, type, status, summary, valid_until, created_by, updated_by) "
            "VALUES (?, ?, ?, ?, datetime('now', '-1 day'), ?, ?)",
            ("jimmy", "fact", "active", "Find me when expired", "jimmy", "jimmy"),
        )
        seed_data.commit()

        # First, trigger lazy expiry with a default search
        search_items(seed_data, "jimmy", ["jimmy", "household"], query="Find me when expired")

        # Now explicitly search for expired
        results = search_items(
            seed_data,
            "jimmy",
            ["jimmy", "household"],
            query="Find me when expired",
            status="expired",
        )
        assert len(results) == 1
        assert results[0]["status"] == "expired"
