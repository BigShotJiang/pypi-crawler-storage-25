from mimir_mcp.tools.session import boot_session_impl
from mimir_mcp.tools.context import (
    set_context_impl as set_context,
    refresh_context_impl as refresh_context,
)


# --- Helpers ---


def _create_project(db, scope, summary, *, created_by="jimmy", detail=None):
    """Insert a project item and return its id."""
    db.execute(
        "INSERT INTO items (scope, type, status, summary, detail, created_by, updated_by) "
        "VALUES (?, 'project', 'in_progress', ?, ?, ?, ?)",
        (scope, summary, detail, created_by, created_by),
    )
    db.commit()
    return db.fetchone("SELECT last_insert_rowid() as id")["id"]


def _create_child(db, parent_id, scope, item_type, summary, *, created_by="jimmy"):
    """Insert a child item under a parent and return its id."""
    db.execute(
        "INSERT INTO items (parent_id, scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, ?, ?, 'not_started', ?, ?, ?)",
        (parent_id, scope, item_type, summary, created_by, created_by),
    )
    db.commit()
    return db.fetchone("SELECT last_insert_rowid() as id")["id"]


def _create_fact(db, scope, summary, *, tag=None, created_by="jimmy"):
    """Insert a fact item and optionally tag it. Returns item id."""
    db.execute(
        "INSERT INTO items (scope, type, status, summary, created_by, updated_by) "
        "VALUES (?, 'fact', 'active', ?, ?, ?)",
        (scope, summary, created_by, created_by),
    )
    db.commit()
    fact_id = db.fetchone("SELECT last_insert_rowid() as id")["id"]
    if tag:
        db.execute("INSERT INTO item_tags VALUES (?, ?)", (fact_id, tag))
        db.commit()
    return fact_id


# --- Tests ---


def test_set_context_focuses_item(seed_data):
    """set_context stores active_context_id on session & returns item L2 detail + children."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(
        seed_data, "jimmy", "Provider Ops", detail="Full project details here"
    )
    _create_child(seed_data, proj_id, "jimmy", "task", "Set up DNS")

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    # Session should have active_context_id set
    session = seed_data.fetchone(
        "SELECT active_context_id FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    assert session["active_context_id"] == proj_id

    # Result should contain item detail with detail
    assert result["item"]["id"] == proj_id
    assert result["item"]["detail"] == "Full project details here"

    # Children should be present
    all_children = []
    for children_of_type in result["children"].values():
        all_children.extend(children_of_type)
    assert len(all_children) >= 1


def test_set_context_returns_children_grouped_by_type(seed_data):
    """Children come back grouped by type (tasks, notes, etc.)."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "Multi-child Project")
    _create_child(seed_data, proj_id, "jimmy", "task", "Task A")
    _create_child(seed_data, proj_id, "jimmy", "task", "Task B")
    _create_child(seed_data, proj_id, "jimmy", "note", "Note about project")

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    assert "task" in result["children"]
    assert "note" in result["children"]
    assert len(result["children"]["task"]) == 2
    assert len(result["children"]["note"]) == 1


def test_set_context_returns_global_facts(seed_data):
    """Global facts still included when focused on an item."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "Some project")
    _create_fact(seed_data, "household", "Alex is allergic to shellfish", tag="health")

    result = set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    assert "global_facts" in result
    assert "health" in result["global_facts"]
    assert len(result["global_facts"]["health"]) >= 1


def test_clear_context(seed_data):
    """set_context(None) clears active_context_id and returns boot-level summary."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    # First focus on a project
    proj_id = _create_project(seed_data, "jimmy", "Focused project")
    set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    # Now clear
    result = set_context(seed_data, "jimmy", scopes, item_id=None)

    # active_context_id should be NULL
    session = seed_data.fetchone(
        "SELECT active_context_id FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    assert session["active_context_id"] is None

    # Result should look like boot summary (has projects/tasks/etc.)
    assert "projects" in result
    assert "tasks" in result
    assert "reminders" in result
    assert "ideas" in result


def test_refresh_context_restores_focus(seed_data):
    """After set_context(), refresh returns the same focused item."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    proj_id = _create_project(seed_data, "jimmy", "Refresh target", detail="Detail text")
    _create_child(seed_data, proj_id, "jimmy", "task", "Child task")
    set_context(seed_data, "jimmy", scopes, item_id=proj_id)

    result = refresh_context(seed_data, "jimmy", scopes)

    assert result["item"]["id"] == proj_id
    assert result["item"]["detail"] == "Detail text"
    assert "children" in result


def test_refresh_context_with_no_focus(seed_data):
    """Without active focus, refresh returns boot summary."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    _create_project(seed_data, "jimmy", "Visible project")

    result = refresh_context(seed_data, "jimmy", scopes)

    assert "projects" in result
    assert "tasks" in result
    assert "reminders" in result
    assert "ideas" in result


def test_refresh_context_returns_session_activity(seed_data):
    """Items created/updated during this session are included."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    # Get the session_id
    session = seed_data.fetchone(
        "SELECT id FROM sessions WHERE user_id = 'jimmy' AND ended_at IS NULL"
    )
    session_id = session["id"]

    # Create an item and record history tied to this session
    proj_id = _create_project(seed_data, "jimmy", "Session project")
    seed_data.execute(
        "INSERT INTO item_history (item_id, event, content, actor, session_id) "
        "VALUES (?, 'created', 'Created during session', 'jimmy', ?)",
        (proj_id, session_id),
    )
    seed_data.commit()

    result = refresh_context(seed_data, "jimmy", scopes)

    assert "session_activity" in result
    assert len(result["session_activity"]) >= 1
    assert any(a["item_id"] == proj_id for a in result["session_activity"])


def test_refresh_context_returns_scopes(seed_data):
    """Scopes are included in the refresh response."""
    scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", scopes)

    result = refresh_context(seed_data, "jimmy", scopes)

    assert "scopes" in result
    scope_ids = [s["id"] for s in result["scopes"]]
    assert "jimmy" in scope_ids
    assert "household" in scope_ids


def test_scope_enforcement(seed_data):
    """Can't set_context on an item outside user's scopes."""
    # Boot jimmy's session with only jimmy's scopes (not alex)
    jimmy_scopes = ["jimmy", "household"]
    boot_session_impl(seed_data, "jimmy", jimmy_scopes)

    # Create an item in alex's personal scope (alex creates it)
    alex_item_id = _create_project(seed_data, "alex", "Alex private project", created_by="alex")

    # Jimmy tries to focus on alex's item — should fail
    result = set_context(seed_data, "jimmy", jimmy_scopes, item_id=alex_item_id)

    assert "error" in result
