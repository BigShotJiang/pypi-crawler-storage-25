"""Tests for gendoruwo core."""
