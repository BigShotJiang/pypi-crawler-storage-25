<p align="center">
  <img src="https://img.freepik.com/vektor-premium/desain-vektor-klipart-monyet-yang-lucu-dan-menawan_1275990-8521.jpg" alt="GENDORUWO Logo" width="128"/>
</p>

# GENDORUWO 👻
**Generate Document Running Workflow**

GENDORUWO is a lightweight document text extraction framework built in Python.

## Features

- 📄 **PDF Text Extraction**: Extract text content from PDF documents
- 📝 **DOCX Text Extraction**: Extract text from Word documents
- 📊 **XLSX Text Extraction**: Extract text from Excel spreadsheets
- 📎 **Multi-format Support**: Extensible architecture for adding more document formats
- ⚡ **Workflow-based**: Define extraction workflows via YAML configuration

## Installation
```bash
pip install gendoruwo
```

## Quick Start

### CLI Usage

```bash
# Extract text from a single document
gendoruwo extract document.pdf

# Run a workflow
gendoruwo run workflow.yaml

# Validate a workflow file
gendoruwo validate workflow.yaml

# Initialize a sample workflow
gendoruwo init
```

### Python API

```python
from gendoruwo import Gendoruwo

gd = Gendoruwo()

# Extract text from a document
text = gd.extract("document.pdf")
print(text)
```

## Workflow YAML Format

```yaml
name: "Extract Contracts"
input:
  paths:
    - "docs/contract1.pdf"
    - "docs/contract2.docx"
  recursive: true
output:
  directory: "extracted/"
  format: "text"  # text | markdown | json
options:
  encoding: "utf-8"
```

## Development

```bash
# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest

# Run linting
flake8 src/ tests/

# Run tox
tox
```

## License

MIT License - see [LICENSE](LICENSE) for details.
