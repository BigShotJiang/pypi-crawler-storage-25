#!/usr/bin/env python

"""The setup script for gendoruwo."""

from os import path
from setuptools import setup, find_packages
import versioneer

here = path.abspath(path.dirname(__file__))

# Get the long description from the README file
with open(path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

install_requires = [
    "Click>=7.0",
]

extras_require = {
    "dev": [
        "pytest",
        "pytest-mock",
        "pytest-cov",
        "tox",
        "flake8",
        "flake8-import-order",
        "flake8-print",
        "flake8-builtins",
        "pep8-naming",
        "pre-commit",
        "rope",
    ]
}

setup(
    name="gendoruwo",
    version=versioneer.get_version(),
    cmdclass=versioneer.get_cmdclass(),
    description="Generate Document Running Workflow (GENDORUWO): a document extraction framework",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://gitlab.com/alkode.id/gendoruwo",
    author="Singgih",
    author_email="singgih@alkode.id",
    license="MIT",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.8",
    install_requires=install_requires,
    extras_require=extras_require,
    entry_points={
        "console_scripts": [
            "gendoruwo=gendoruwo.cli:main",
        ]
    },
    include_package_data=True,
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
        "Topic :: Text Processing :: General",
    ]
)
