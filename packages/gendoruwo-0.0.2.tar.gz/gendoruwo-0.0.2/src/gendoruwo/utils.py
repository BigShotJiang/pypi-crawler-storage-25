"""Utilities script for gendoruwo."""
