"""Console script for gendoruwo."""

import sys

import click

from gendoruwo import __version__


@click.command()
@click.option('--version', 'version', flag_value='version', default=False, help="show current version")
def main(version):
    """Console script for gendoruwo."""
    if version == 'version':
        click.echo('version: '+__version__)  # noqa
    else:
        click.echo("Replace this message by putting your code into gendoruwo.cli.main")
    return 0


if __name__ == "__main__":
    sys.exit(main())  # pragma: no cover
