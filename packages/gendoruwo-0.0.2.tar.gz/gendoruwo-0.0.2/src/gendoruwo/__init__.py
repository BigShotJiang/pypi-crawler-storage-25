"""Top-level package for gendoruwo."""

from . import _version
__version__ = _version.get_versions()['version']
