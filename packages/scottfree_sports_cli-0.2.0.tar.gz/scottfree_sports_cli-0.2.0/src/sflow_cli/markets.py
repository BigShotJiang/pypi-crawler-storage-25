"""Prediction market clients — Kalshi and Polymarket (sync + async)."""

from __future__ import annotations

import asyncio
import time

import httpx

from sflow_cli.exceptions import raise_for_status

_RETRYABLE = {502, 503, 504}
_MAX_RETRIES = 2
_TIMEOUT = 30.0

KALSHI_SPORTS = {
    "nba": "NBA_GAME",
    "nfl": "NFL_GAME",
    "mlb": "MLB_GAME",
    "nhl": "NHL_GAME",  # In development on Kalshi — may have limited markets
    "ncaab": "NCAAB",
    "ncaaf": "NCAAF",
}

_KALSHI_BASE = "https://api.elections.kalshi.com/trade-api/v2"
_GAMMA_BASE = "https://gamma-api.polymarket.com"
_CLOB_BASE = "https://clob.polymarket.com"


class KalshiClient:
    """Sync + async HTTP client for the Kalshi prediction market API (public, no auth)."""

    def __init__(self, base_url: str = _KALSHI_BASE):
        self.base_url = base_url.rstrip("/")
        self._sync_client: httpx.Client | None = None
        self._async_client: httpx.AsyncClient | None = None

    # ── lifecycle ────────────────────────────────────────────────────

    def _get_sync_client(self) -> httpx.Client:
        if self._sync_client is None or self._sync_client.is_closed:
            self._sync_client = httpx.Client(timeout=_TIMEOUT)
        return self._sync_client

    async def _get_async_client(self) -> httpx.AsyncClient:
        if self._async_client is None or self._async_client.is_closed:
            self._async_client = httpx.AsyncClient(timeout=_TIMEOUT)
        return self._async_client

    def close(self) -> None:
        if self._sync_client and not self._sync_client.is_closed:
            self._sync_client.close()

    async def aclose(self) -> None:
        if self._async_client and not self._async_client.is_closed:
            await self._async_client.close()

    # ── helpers ──────────────────────────────────────────────────────

    def _handle_response(self, resp: httpx.Response) -> dict | list:
        if resp.status_code >= 400:
            detail = ""
            try:
                body = resp.json()
                detail = body.get("detail", body.get("message", str(body)))
            except Exception:
                detail = resp.text or f"HTTP {resp.status_code}"
            raise_for_status(resp.status_code, detail)
        return resp.json()

    def _get(self, path: str, params: dict | None = None) -> dict | list:
        retries = 0
        while True:
            try:
                client = self._get_sync_client()
                resp = client.get(f"{self.base_url}{path}", params=params)
                if resp.status_code not in _RETRYABLE or retries >= _MAX_RETRIES:
                    return self._handle_response(resp)
                retries += 1
                time.sleep(2**retries)
            except httpx.ConnectError:
                if retries >= _MAX_RETRIES:
                    raise
                retries += 1
                time.sleep(2**retries)

    async def _aget(self, path: str, params: dict | None = None) -> dict | list:
        retries = 0
        while True:
            try:
                client = await self._get_async_client()
                resp = await client.get(f"{self.base_url}{path}", params=params)
                if resp.status_code not in _RETRYABLE or retries >= _MAX_RETRIES:
                    return self._handle_response(resp)
                retries += 1
                await asyncio.sleep(2**retries)
            except httpx.ConnectError:
                if retries >= _MAX_RETRIES:
                    raise
                retries += 1
                await asyncio.sleep(2**retries)

    # ── sync endpoints ───────────────────────────────────────────────

    def get_markets(self, sport: str, limit: int = 100) -> dict:
        params = {"series_ticker": KALSHI_SPORTS[sport], "status": "open", "limit": limit}
        return self._get("/markets", params=params)

    def get_orderbook(self, ticker: str, depth: int = 5) -> dict:
        return self._get(f"/markets/{ticker}/orderbook", params={"depth": depth})

    def get_events(self, sport: str, limit: int = 100) -> dict:
        params = {"series_ticker": KALSHI_SPORTS[sport], "limit": limit}
        return self._get("/events", params=params)

    # ── async endpoints ──────────────────────────────────────────────

    async def aget_markets(self, sport: str, limit: int = 100) -> dict:
        params = {"series_ticker": KALSHI_SPORTS[sport], "status": "open", "limit": limit}
        return await self._aget("/markets", params=params)

    async def aget_orderbook(self, ticker: str, depth: int = 5) -> dict:
        return await self._aget(f"/markets/{ticker}/orderbook", params={"depth": depth})

    async def aget_events(self, sport: str, limit: int = 100) -> dict:
        params = {"series_ticker": KALSHI_SPORTS[sport], "limit": limit}
        return await self._aget("/events", params=params)


POLYMARKET_SPORT_TAGS = {
    "nba": 745,
    "nfl": 450,
    "mlb": 100381,
    "nhl": 899,
    "ncaab": 100149,
    "ncaaf": 100351,
}


class PolymarketClient:
    """Sync + async HTTP client for the Polymarket prediction market API (public, no auth)."""

    def __init__(self, gamma_url: str = _GAMMA_BASE, clob_url: str = _CLOB_BASE):
        self.gamma_url = gamma_url.rstrip("/")
        self.clob_url = clob_url.rstrip("/")
        self._sync_client: httpx.Client | None = None
        self._async_client: httpx.AsyncClient | None = None

    # ── lifecycle ────────────────────────────────────────────────────

    def _get_sync_client(self) -> httpx.Client:
        if self._sync_client is None or self._sync_client.is_closed:
            self._sync_client = httpx.Client(timeout=_TIMEOUT)
        return self._sync_client

    async def _get_async_client(self) -> httpx.AsyncClient:
        if self._async_client is None or self._async_client.is_closed:
            self._async_client = httpx.AsyncClient(timeout=_TIMEOUT)
        return self._async_client

    def close(self) -> None:
        if self._sync_client and not self._sync_client.is_closed:
            self._sync_client.close()

    async def aclose(self) -> None:
        if self._async_client and not self._async_client.is_closed:
            await self._async_client.close()

    # ── helpers ──────────────────────────────────────────────────────

    def _handle_response(self, resp: httpx.Response) -> dict | list:
        if resp.status_code >= 400:
            detail = ""
            try:
                body = resp.json()
                detail = body.get("detail", body.get("message", str(body)))
            except Exception:
                detail = resp.text or f"HTTP {resp.status_code}"
            raise_for_status(resp.status_code, detail)
        return resp.json()

    def _get(self, base_url: str, path: str, params: dict | None = None) -> dict | list:
        retries = 0
        while True:
            try:
                client = self._get_sync_client()
                resp = client.get(f"{base_url}{path}", params=params)
                if resp.status_code not in _RETRYABLE or retries >= _MAX_RETRIES:
                    return self._handle_response(resp)
                retries += 1
                time.sleep(2**retries)
            except httpx.ConnectError:
                if retries >= _MAX_RETRIES:
                    raise
                retries += 1
                time.sleep(2**retries)

    def _get_text(self, base_url: str, path: str, params: dict | None = None) -> str:
        retries = 0
        while True:
            try:
                client = self._get_sync_client()
                resp = client.get(f"{base_url}{path}", params=params)
                if resp.status_code not in _RETRYABLE or retries >= _MAX_RETRIES:
                    if resp.status_code >= 400:
                        detail = resp.text or f"HTTP {resp.status_code}"
                        raise_for_status(resp.status_code, detail)
                    return resp.text
                retries += 1
                time.sleep(2**retries)
            except httpx.ConnectError:
                if retries >= _MAX_RETRIES:
                    raise
                retries += 1
                time.sleep(2**retries)

    async def _aget(self, base_url: str, path: str, params: dict | None = None) -> dict | list:
        retries = 0
        while True:
            try:
                client = await self._get_async_client()
                resp = await client.get(f"{base_url}{path}", params=params)
                if resp.status_code not in _RETRYABLE or retries >= _MAX_RETRIES:
                    return self._handle_response(resp)
                retries += 1
                await asyncio.sleep(2**retries)
            except httpx.ConnectError:
                if retries >= _MAX_RETRIES:
                    raise
                retries += 1
                await asyncio.sleep(2**retries)

    async def _aget_text(self, base_url: str, path: str, params: dict | None = None) -> str:
        retries = 0
        while True:
            try:
                client = await self._get_async_client()
                resp = await client.get(f"{base_url}{path}", params=params)
                if resp.status_code not in _RETRYABLE or retries >= _MAX_RETRIES:
                    if resp.status_code >= 400:
                        detail = resp.text or f"HTTP {resp.status_code}"
                        raise_for_status(resp.status_code, detail)
                    return resp.text
                retries += 1
                await asyncio.sleep(2**retries)
            except httpx.ConnectError:
                if retries >= _MAX_RETRIES:
                    raise
                retries += 1
                await asyncio.sleep(2**retries)

    # ── sync endpoints ───────────────────────────────────────────────

    def get_sports(self) -> dict:
        return self._get(self.gamma_url, "/sports")

    def get_events(self, sport: str, limit: int = 50) -> dict | list:
        tag_id = POLYMARKET_SPORT_TAGS[sport.lower()]
        params = {"tag_id": tag_id, "active": "true", "closed": "false", "limit": limit}
        return self._get(self.gamma_url, "/events", params=params)

    def get_orderbook(self, token_id: str) -> dict:
        return self._get(self.clob_url, "/book", params={"token_id": token_id})

    def get_midpoint(self, token_id: str) -> str:
        return self._get_text(self.clob_url, "/midpoint", params={"token_id": token_id})

    # ── async endpoints ──────────────────────────────────────────────

    async def aget_sports(self) -> dict:
        return await self._aget(self.gamma_url, "/sports")

    async def aget_events(self, sport: str, limit: int = 50) -> dict | list:
        tag_id = POLYMARKET_SPORT_TAGS[sport.lower()]
        params = {"tag_id": tag_id, "active": "true", "closed": "false", "limit": limit}
        return await self._aget(self.gamma_url, "/events", params=params)

    async def aget_orderbook(self, token_id: str) -> dict:
        return await self._aget(self.clob_url, "/book", params={"token_id": token_id})

    async def aget_midpoint(self, token_id: str) -> str:
        return await self._aget_text(self.clob_url, "/midpoint", params={"token_id": token_id})
