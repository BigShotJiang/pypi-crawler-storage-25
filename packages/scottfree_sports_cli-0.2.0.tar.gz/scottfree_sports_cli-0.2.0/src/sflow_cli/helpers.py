"""Shared helpers for CLI commands."""

from __future__ import annotations

import os
from pathlib import Path

from sflow_cli.client import SflowClient
from sflow_cli.config import SflowConfig


def get_client_from_env(env: str = "default") -> SflowClient:
    """Create a SflowClient from config profile and env var overrides.

    Used by all CLI commands to avoid duplicating client construction logic.
    """
    config_dir = os.environ.get("SFS_CONFIG_DIR")
    config = SflowConfig(config_dir=Path(config_dir)) if config_dir else SflowConfig()
    api_key, api_url = config.resolve(env=env)
    return SflowClient(api_key, api_url)
