"""BallDontLie live sports data client (sync + async)."""

from __future__ import annotations

import asyncio
import time

import httpx

from sflow_cli.exceptions import raise_for_status

_RETRYABLE = {502, 503, 504}
_MAX_RETRIES = 2
_TIMEOUT = 30.0

_BDL_BASE = "https://api.balldontlie.io/v1"

BALLDONTLIE_SPORTS = {
    "nba": "nba",
    "nfl": "nfl",
    "mlb": "mlb",
    "nhl": "nhl",
}


class BallDontLieClient:
    """Sync + async HTTP client for the BallDontLie sports data API (requires API key)."""

    def __init__(self, api_key: str, base_url: str = _BDL_BASE):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self._sync_client: httpx.Client | None = None
        self._async_client: httpx.AsyncClient | None = None

    # ── lifecycle ────────────────────────────────────────────────────

    def _get_sync_client(self) -> httpx.Client:
        if self._sync_client is None or self._sync_client.is_closed:
            self._sync_client = httpx.Client(
                timeout=_TIMEOUT,
                headers={"Authorization": f"Bearer {self.api_key}"},
            )
        return self._sync_client

    async def _get_async_client(self) -> httpx.AsyncClient:
        if self._async_client is None or self._async_client.is_closed:
            self._async_client = httpx.AsyncClient(
                timeout=_TIMEOUT,
                headers={"Authorization": f"Bearer {self.api_key}"},
            )
        return self._async_client

    def close(self) -> None:
        if self._sync_client and not self._sync_client.is_closed:
            self._sync_client.close()

    async def aclose(self) -> None:
        if self._async_client and not self._async_client.is_closed:
            await self._async_client.close()

    # ── helpers ──────────────────────────────────────────────────────

    def _handle_response(self, resp: httpx.Response) -> dict | list:
        if resp.status_code >= 400:
            detail = ""
            try:
                body = resp.json()
                detail = body.get("detail", body.get("message", str(body)))
            except Exception:
                detail = resp.text or f"HTTP {resp.status_code}"
            raise_for_status(resp.status_code, detail)
        return resp.json()

    def _get(self, path: str, params: dict | None = None) -> dict | list:
        retries = 0
        while True:
            try:
                client = self._get_sync_client()
                resp = client.get(f"{self.base_url}{path}", params=params)
                if resp.status_code not in _RETRYABLE or retries >= _MAX_RETRIES:
                    return self._handle_response(resp)
                retries += 1
                time.sleep(2**retries)
            except httpx.ConnectError:
                if retries >= _MAX_RETRIES:
                    raise
                retries += 1
                time.sleep(2**retries)

    async def _aget(self, path: str, params: dict | None = None) -> dict | list:
        retries = 0
        while True:
            try:
                client = await self._get_async_client()
                resp = await client.get(f"{self.base_url}{path}", params=params)
                if resp.status_code not in _RETRYABLE or retries >= _MAX_RETRIES:
                    return self._handle_response(resp)
                retries += 1
                await asyncio.sleep(2**retries)
            except httpx.ConnectError:
                if retries >= _MAX_RETRIES:
                    raise
                retries += 1
                await asyncio.sleep(2**retries)

    # ── sync endpoints ───────────────────────────────────────────────

    def get_games(self, sport: str, date: str | None = None) -> dict:
        """GET /{sport}/games with optional ?dates[]={date} param (YYYY-MM-DD)."""
        params: dict | None = None
        if date is not None:
            params = {"dates[]": date}
        return self._get(f"/{BALLDONTLIE_SPORTS[sport]}/games", params=params)

    def get_injuries(self, sport: str) -> dict:
        """GET /{sport}/injuries."""
        return self._get(f"/{BALLDONTLIE_SPORTS[sport]}/injuries")

    def get_teams(self, sport: str) -> dict:
        """GET /{sport}/teams."""
        return self._get(f"/{BALLDONTLIE_SPORTS[sport]}/teams")

    def get_team_stats(self, sport: str, team_id: int, season: int | None = None) -> dict:
        """GET /{sport}/season_averages?team_ids[]={team_id} with optional &season={season}."""
        params: dict = {"team_ids[]": team_id}
        if season is not None:
            params["season"] = season
        return self._get(f"/{BALLDONTLIE_SPORTS[sport]}/season_averages", params=params)

    def get_players(
        self,
        sport: str,
        team_id: int | None = None,
        search: str | None = None,
        cursor: int | None = None,
        per_page: int = 25,
    ) -> dict:
        """GET /{sport}/players — current rosters (free tier).

        Filters: optional team_id to limit to one franchise, optional search
        to match first/last name substring. Paginated via cursor (max 100 per
        page per BALLDONTLIE API).
        """
        params: dict = {"per_page": per_page}
        if team_id is not None:
            params["team_ids[]"] = team_id
        if search:
            params["search"] = search
        if cursor is not None:
            params["cursor"] = cursor
        return self._get(f"/{BALLDONTLIE_SPORTS[sport]}/players", params=params)

    # ── async endpoints ──────────────────────────────────────────────

    async def aget_games(self, sport: str, date: str | None = None) -> dict:
        """Async GET /{sport}/games with optional ?dates[]={date} param (YYYY-MM-DD)."""
        params: dict | None = None
        if date is not None:
            params = {"dates[]": date}
        return await self._aget(f"/{BALLDONTLIE_SPORTS[sport]}/games", params=params)

    async def aget_injuries(self, sport: str) -> dict:
        """Async GET /{sport}/injuries."""
        return await self._aget(f"/{BALLDONTLIE_SPORTS[sport]}/injuries")

    async def aget_teams(self, sport: str) -> dict:
        """Async GET /{sport}/teams."""
        return await self._aget(f"/{BALLDONTLIE_SPORTS[sport]}/teams")

    async def aget_team_stats(self, sport: str, team_id: int, season: int | None = None) -> dict:
        """Async GET /{sport}/season_averages?team_ids[]={team_id}."""
        params: dict = {"team_ids[]": team_id}
        if season is not None:
            params["season"] = season
        return await self._aget(f"/{BALLDONTLIE_SPORTS[sport]}/season_averages", params=params)

    async def aget_players(
        self,
        sport: str,
        team_id: int | None = None,
        search: str | None = None,
        cursor: int | None = None,
        per_page: int = 25,
    ) -> dict:
        """Async GET /{sport}/players — current rosters (free tier)."""
        params: dict = {"per_page": per_page}
        if team_id is not None:
            params["team_ids[]"] = team_id
        if search:
            params["search"] = search
        if cursor is not None:
            params["cursor"] = cursor
        return await self._aget(f"/{BALLDONTLIE_SPORTS[sport]}/players", params=params)
