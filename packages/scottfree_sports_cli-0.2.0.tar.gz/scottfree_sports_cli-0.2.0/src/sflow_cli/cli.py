"""Scottfree Sports CLI — Typer app entry point."""

from __future__ import annotations

import typer

from sflow_cli import __version__
from sflow_cli.commands import (
    account,
    admin,
    analysis,
    config_cmd,
    consensus_cmd,
    markets,
    odds,
    predictions,
    results,
    scores,
    summary,
    weather_cmd,
)

app = typer.Typer(
    name="sfs",
    help="Scottfree Sports predictions CLI.",
    rich_markup_mode="rich",
    no_args_is_help=True,
)


def version_callback(value: bool) -> None:
    if value:
        typer.echo(f"sfs {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False, "--version", callback=version_callback, is_eager=True, help="Show version."
    ),
) -> None:
    """Scottfree Sports predictions CLI."""


app.add_typer(config_cmd.app, name="config")
app.add_typer(predictions.app, name="predictions")
app.add_typer(results.app, name="results")
app.add_typer(summary.app, name="summary")
app.add_typer(odds.app, name="odds")
app.add_typer(analysis.app, name="analysis")
app.add_typer(account.app, name="account")
app.add_typer(admin.app, name="admin")
app.add_typer(markets.app, name="markets")
app.add_typer(weather_cmd.app, name="weather")
app.add_typer(scores.app, name="scores")
app.add_typer(consensus_cmd.app, name="consensus")
