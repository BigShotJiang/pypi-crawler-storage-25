"""Open-Meteo weather client with venue coordinates lookup (sync + async)."""

from __future__ import annotations

import asyncio
import time

import httpx

from sflow_cli.exceptions import raise_for_status

_RETRYABLE = {502, 503, 504}
_MAX_RETRIES = 2
_TIMEOUT = 30.0

_OPEN_METEO_BASE = "https://api.open-meteo.com/v1/forecast"

# Venue lookup: sport → team_key → (latitude, longitude, venue_name, is_outdoor)
# Only sports where weather is relevant (NFL, MLB). Indoor-only leagues omitted.
VENUES: dict[str, dict[str, tuple[float, float, str, bool]]] = {
    "nfl": {
        "bills": (42.7738, -78.7870, "Highmark Stadium", True),
        "bears": (41.8623, -87.6167, "Soldier Field", True),
        "bengals": (39.0954, -84.5160, "Paycor Stadium", True),
        "browns": (41.5061, -81.6995, "Cleveland Browns Stadium", True),
        "broncos": (39.7439, -105.0201, "Empower Field", True),
        "panthers": (35.2258, -80.8528, "Bank of America Stadium", True),
        "chiefs": (39.0489, -94.4839, "GEHA Field", True),
        "packers": (44.5013, -88.0622, "Lambeau Field", True),
        "jaguars": (30.3239, -81.6373, "EverBank Stadium", True),
        "dolphins": (25.9580, -80.2389, "Hard Rock Stadium", True),
        "eagles": (39.9008, -75.1675, "Lincoln Financial Field", True),
        "steelers": (40.4468, -80.0158, "Acrisure Stadium", True),
        "niners": (37.4033, -121.9694, "Levi's Stadium", True),
        "seahawks": (47.5952, -122.3316, "Lumen Field", True),
        "buccaneers": (27.9759, -82.5033, "Raymond James Stadium", True),
        "titans": (36.1665, -86.7713, "Nissan Stadium", True),
        "commanders": (38.9076, -76.8645, "Northwest Stadium", True),
        "jets": (40.8128, -74.0742, "MetLife Stadium", True),
        "giants": (40.8128, -74.0742, "MetLife Stadium", True),
        "patriots": (42.0909, -71.2643, "Gillette Stadium", True),
        "chargers": (33.9535, -118.3390, "SoFi Stadium", False),  # Indoor
        "rams": (33.9535, -118.3390, "SoFi Stadium", False),  # Indoor
        "ravens": (39.2780, -76.6227, "M&T Bank Stadium", True),
        "saints": (29.9511, -90.0812, "Caesars Superdome", False),  # Indoor
        "falcons": (33.7554, -84.4010, "Mercedes-Benz Stadium", False),  # Indoor
        "cowboys": (32.7473, -97.0945, "AT&T Stadium", False),  # Indoor
        "texans": (29.6847, -95.4107, "NRG Stadium", False),  # Indoor
        "cardinals": (33.5276, -112.2626, "State Farm Stadium", False),  # Indoor
        "colts": (39.7601, -86.1639, "Lucas Oil Stadium", False),  # Indoor
        "lions": (42.3400, -83.0456, "Ford Field", False),  # Indoor
        "vikings": (44.9736, -93.2575, "U.S. Bank Stadium", False),  # Indoor
    },
    "mlb": {
        "yankees": (40.8296, -73.9262, "Yankee Stadium", True),
        "mets": (40.7571, -73.8458, "Citi Field", True),
        "red_sox": (42.3467, -71.0972, "Fenway Park", True),
        "cubs": (41.9484, -87.6553, "Wrigley Field", True),
        "white_sox": (41.8300, -87.6339, "Guaranteed Rate Field", True),
        "dodgers": (34.0739, -118.2400, "Dodger Stadium", True),
        "giants_sf": (37.7786, -122.3893, "Oracle Park", True),
        "padres": (32.7076, -117.1570, "Petco Park", True),
        "angels": (33.8003, -117.8827, "Angel Stadium", True),
        "athletics": (37.7516, -122.2005, "Oakland Coliseum", True),
        "braves": (33.8907, -84.4677, "Truist Park", True),
        "nationals": (38.8730, -77.0074, "Nationals Park", True),
        "phillies": (39.9061, -75.1665, "Citizens Bank Park", True),
        "orioles": (39.2838, -76.6217, "Camden Yards", True),
        "pirates": (40.4469, -80.0057, "PNC Park", True),
        "reds": (39.0974, -84.5069, "Great American Ball Park", True),
        "indians": (41.4962, -81.6852, "Progressive Field", True),
        "tigers": (42.3390, -83.0485, "Comerica Park", True),
        "twins": (44.9818, -93.2775, "Target Field", True),
        "royals": (39.0517, -94.4803, "Kauffman Stadium", True),
        "cardinals_stl": (38.6226, -90.1928, "Busch Stadium", True),
        "brewers": (43.0280, -87.9712, "American Family Field", False),  # Retractable
        "rockies": (39.7559, -104.9942, "Coors Field", True),
        "astros": (29.7572, -95.3555, "Minute Maid Park", False),  # Retractable
        "rangers": (32.7512, -97.0832, "Globe Life Field", False),  # Indoor
        "mariners": (47.5914, -122.3325, "T-Mobile Park", False),  # Retractable
        "rays": (27.7682, -82.6534, "Tropicana Field", False),  # Indoor
        "blue_jays": (43.6414, -79.3894, "Rogers Centre", False),  # Indoor
        "diamondbacks": (33.4455, -112.0667, "Chase Field", False),  # Retractable
        "marlins": (25.7781, -80.2196, "LoanDepot Park", False),  # Retractable
    },
}


def get_outdoor_venues(sport: str) -> dict[str, tuple[float, float, str]]:
    """Return only outdoor venues for a sport: {team_key: (lat, lon, name)}.

    Args:
        sport: Sport key (e.g. "nfl", "mlb"). Unknown sports return an empty dict.

    Returns:
        Mapping of team_key to (latitude, longitude, venue_name) for outdoor-only venues.
    """
    sport_venues = VENUES.get(sport, {})
    return {
        team: (lat, lon, name)
        for team, (lat, lon, name, is_outdoor) in sport_venues.items()
        if is_outdoor
    }


class WeatherClient:
    """Sync + async HTTP client for the Open-Meteo weather API (public, no auth)."""

    def __init__(self, base_url: str = _OPEN_METEO_BASE):
        self.base_url = base_url.rstrip("/")
        self._sync_client: httpx.Client | None = None
        self._async_client: httpx.AsyncClient | None = None

    # ── lifecycle ────────────────────────────────────────────────────

    def _get_sync_client(self) -> httpx.Client:
        if self._sync_client is None or self._sync_client.is_closed:
            self._sync_client = httpx.Client(timeout=_TIMEOUT)
        return self._sync_client

    async def _get_async_client(self) -> httpx.AsyncClient:
        if self._async_client is None or self._async_client.is_closed:
            self._async_client = httpx.AsyncClient(timeout=_TIMEOUT)
        return self._async_client

    def close(self) -> None:
        if self._sync_client and not self._sync_client.is_closed:
            self._sync_client.close()

    async def aclose(self) -> None:
        if self._async_client and not self._async_client.is_closed:
            await self._async_client.close()

    # ── helpers ──────────────────────────────────────────────────────

    def _handle_response(self, resp: httpx.Response) -> dict:
        if resp.status_code >= 400:
            detail = ""
            try:
                body = resp.json()
                detail = body.get("detail", body.get("reason", str(body)))
            except Exception:
                detail = resp.text or f"HTTP {resp.status_code}"
            raise_for_status(resp.status_code, detail)
        return resp.json()

    def _get(self, params: dict | None = None) -> dict:
        retries = 0
        while True:
            try:
                client = self._get_sync_client()
                resp = client.get(self.base_url, params=params)
                if resp.status_code not in _RETRYABLE or retries >= _MAX_RETRIES:
                    return self._handle_response(resp)
                retries += 1
                time.sleep(2**retries)
            except httpx.ConnectError:
                if retries >= _MAX_RETRIES:
                    raise
                retries += 1
                time.sleep(2**retries)

    async def _aget(self, params: dict | None = None) -> dict:
        retries = 0
        while True:
            try:
                client = await self._get_async_client()
                resp = await client.get(self.base_url, params=params)
                if resp.status_code not in _RETRYABLE or retries >= _MAX_RETRIES:
                    return self._handle_response(resp)
                retries += 1
                await asyncio.sleep(2**retries)
            except httpx.ConnectError:
                if retries >= _MAX_RETRIES:
                    raise
                retries += 1
                await asyncio.sleep(2**retries)

    # ── sync endpoints ───────────────────────────────────────────────

    def get_weather(self, latitude: float, longitude: float) -> dict:
        """Fetch current weather conditions for a coordinate pair.

        Args:
            latitude: Latitude in decimal degrees.
            longitude: Longitude in decimal degrees.

        Returns:
            Open-Meteo forecast response dict.
        """
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "current": "temperature_2m,precipitation,wind_speed_10m,weather_code",
        }
        return self._get(params=params)

    def get_game_weather(self, sport: str, venues: list[str]) -> list[dict]:
        """Fetch weather for each venue (team key) in the given sport.

        Unknown team keys are silently skipped. Uses the full VENUES dict, so
        indoor venues can be looked up but callers may filter via get_outdoor_venues().

        Args:
            sport: Sport key (e.g. "nfl", "mlb").
            venues: List of team keys to look up (e.g. ["bills", "chiefs"]).

        Returns:
            List of dicts, each containing:
                - "venue": team key string
                - "latitude": float
                - "longitude": float
                - "weather": Open-Meteo response dict
        """
        sport_venues = VENUES.get(sport, {})
        results = []
        for team_key in venues:
            if team_key not in sport_venues:
                continue
            lat, lon, name, _ = sport_venues[team_key]
            weather = self.get_weather(lat, lon)
            results.append(
                {
                    "venue": team_key,
                    "latitude": lat,
                    "longitude": lon,
                    "weather": weather,
                }
            )
        return results

    # ── async endpoints ──────────────────────────────────────────────

    async def aget_weather(self, latitude: float, longitude: float) -> dict:
        """Async variant of get_weather."""
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "current": "temperature_2m,precipitation,wind_speed_10m,weather_code",
        }
        return await self._aget(params=params)

    async def aget_game_weather(self, sport: str, venues: list[str]) -> list[dict]:
        """Async variant of get_game_weather."""
        sport_venues = VENUES.get(sport, {})
        results = []
        for team_key in venues:
            if team_key not in sport_venues:
                continue
            lat, lon, name, _ = sport_venues[team_key]
            weather = await self.aget_weather(lat, lon)
            results.append(
                {
                    "venue": team_key,
                    "latitude": lat,
                    "longitude": lon,
                    "weather": weather,
                }
            )
        return results
