"""Covers.com public betting consensus scraper (sync + async)."""

from __future__ import annotations

import asyncio
import re
import time

import httpx

_RETRYABLE = {502, 503, 504}
_MAX_RETRIES = 2
_TIMEOUT = 30.0

_COVERS_BASE = "https://contests.covers.com/consensus"

COVERS_SPORTS = {
    "nba": "nba",
    "nfl": "nfl",
    "mlb": "mlb",
    "nhl": "nhl",
    "ncaab": "ncaab",
    "ncaaf": "ncaaf",
}

# Regex patterns for parsing Covers.com top consensus HTML.
# Page: /topconsensus/{sport}/overall
# Structure: table rows with team blocks and high/low percentage spans.
_RE_TEAM_BLOCK = re.compile(
    r'alt="([^"]*?)(?:\s+Picks)?"',
    re.IGNORECASE,
)
_RE_HIGH_PCT = re.compile(
    r'consensusTable--high[^>]*><span>(\d+)%</span>',
    re.IGNORECASE,
)
_RE_LOW_PCT = re.compile(
    r'consensusTable--low[^>]*><span>(\d+)%</span>',
    re.IGNORECASE,
)
_RE_TAG_STRIP = re.compile(r"<[^>]+>")


def _clean(text: str) -> str:
    """Strip HTML tags and extra whitespace from a string."""
    return _RE_TAG_STRIP.sub("", text).strip()


class CoversClient:
    """Sync + async HTTP scraper for Covers.com public betting consensus.

    No authentication required. Returns empty lists rather than raising on
    HTTP errors or parse failures — designed for graceful degradation when the
    site structure changes or is temporarily unavailable.
    """

    def __init__(self, base_url: str = _COVERS_BASE):
        self.base_url = base_url.rstrip("/")
        self._sync_client: httpx.Client | None = None
        self._async_client: httpx.AsyncClient | None = None

    # ── lifecycle ────────────────────────────────────────────────────

    def _get_sync_client(self) -> httpx.Client:
        if self._sync_client is None or self._sync_client.is_closed:
            self._sync_client = httpx.Client(timeout=_TIMEOUT)
        return self._sync_client

    async def _get_async_client(self) -> httpx.AsyncClient:
        if self._async_client is None or self._async_client.is_closed:
            self._async_client = httpx.AsyncClient(timeout=_TIMEOUT)
        return self._async_client

    def close(self) -> None:
        if self._sync_client and not self._sync_client.is_closed:
            self._sync_client.close()

    async def aclose(self) -> None:
        if self._async_client and not self._async_client.is_closed:
            await self._async_client.close()

    # ── HTML fetch helpers ────────────────────────────────────────────

    def _get_html(self, path: str) -> str:
        """Fetch HTML from path, returning empty string on any error."""
        retries = 0
        while True:
            try:
                client = self._get_sync_client()
                resp = client.get(f"{self.base_url}{path}")
                if resp.status_code in _RETRYABLE and retries < _MAX_RETRIES:
                    retries += 1
                    time.sleep(2**retries)
                    continue
                if resp.status_code >= 400:
                    return ""
                return resp.text
            except Exception:
                if retries >= _MAX_RETRIES:
                    return ""
                retries += 1
                time.sleep(2**retries)

    async def _aget_html(self, path: str) -> str:
        """Async variant of _get_html."""
        retries = 0
        while True:
            try:
                client = await self._get_async_client()
                resp = await client.get(f"{self.base_url}{path}")
                if resp.status_code in _RETRYABLE and retries < _MAX_RETRIES:
                    retries += 1
                    await asyncio.sleep(2**retries)
                    continue
                if resp.status_code >= 400:
                    return ""
                return resp.text
            except Exception:
                if retries >= _MAX_RETRIES:
                    return ""
                retries += 1
                await asyncio.sleep(2**retries)

    # ── parser ────────────────────────────────────────────────────────

    def _parse_consensus_html(self, html: str) -> list[dict]:
        """Parse Covers top consensus HTML into a list of pick dicts.

        The page at /topconsensus/{sport}/overall has table rows with:
        - Two team blocks (alt="Team Name Picks")
        - consensusTable--high span with the favored team's %
        - consensusTable--low span with the underdog's %

        Returns an empty list if the HTML is empty or unparseable. Never raises.
        """
        if not html:
            return []
        try:
            results = []
            # Split by matchupColumn cells — each contains one game
            sections = html.split("matchupColumn")
            for section in sections[1:]:  # skip before first match
                # Find team names from alt attributes
                teams = _RE_TEAM_BLOCK.findall(section)
                if len(teams) < 2:
                    continue

                team1 = teams[0].strip()
                team2 = teams[1].strip()
                matchup = f"{team1} vs {team2}"

                # Find high and low percentages
                high_m = _RE_HIGH_PCT.search(section)
                low_m = _RE_LOW_PCT.search(section)
                if not high_m or not low_m:
                    continue

                high_pct = float(high_m.group(1))
                float(low_m.group(1))  # validate low_pct is numeric

                # Determine which team is the consensus pick
                # High % comes first in the HTML = team1 is favored
                high_pos = high_m.start()
                low_pos = low_m.start()
                if high_pos < low_pos:
                    consensus_pick = team1
                    public_pct = high_pct
                else:
                    consensus_pick = team2
                    public_pct = high_pct

                results.append(
                    {
                        "matchup": matchup,
                        "consensus_pick": consensus_pick,
                        "public_pct": public_pct,
                        "expert_pick": None,
                        "expert_pct": None,
                    }
                )
            return results
        except Exception:
            return []

    # ── sync endpoints ────────────────────────────────────────────────

    def get_consensus(self, sport: str) -> list[dict]:
        """Fetch public betting consensus for a sport.

        Args:
            sport: Sport key — one of "nba", "nfl", "mlb", "nhl", "ncaab", "ncaaf".
                   Unknown sports return an empty list.

        Returns:
            List of consensus pick dicts, or [] on any error.
        """
        if sport not in COVERS_SPORTS:
            return []
        sport_path = COVERS_SPORTS[sport]
        html = self._get_html(f"/topconsensus/{sport_path}/overall")
        return self._parse_consensus_html(html)

    # ── async endpoints ───────────────────────────────────────────────

    async def aget_consensus(self, sport: str) -> list[dict]:
        """Async variant of get_consensus."""
        if sport not in COVERS_SPORTS:
            return []
        sport_path = COVERS_SPORTS[sport]
        html = await self._aget_html(f"/topconsensus/{sport_path}/overall")
        return self._parse_consensus_html(html)
