"""FastMCP server exposing Scottfree Sports API as tools for AI assistants."""

from __future__ import annotations

from fastmcp import FastMCP

from sflow_cli.client import SflowClient
from sflow_cli.helpers import get_client_from_env

mcp = FastMCP("scottfree-sports")


def _get_client() -> SflowClient:
    return get_client_from_env()


@mcp.tool()
async def get_predictions(sport: str, model_type: str) -> dict:
    """Get ML predictions for today's games.

    Args:
        sport: Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)
        model_type: Model type (over_under, won_on_spread, won_on_points)
    """
    client = _get_client()
    return await client.aget_predictions(sport, model_type)


@mcp.tool()
async def get_results(sport: str, model_type: str, limit: int = 100) -> dict:
    """Get historical prediction results.

    Args:
        sport: Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)
        model_type: Model type (over_under, won_on_spread, won_on_points)
        limit: Maximum number of results (default 100)
    """
    client = _get_client()
    return await client.aget_results(sport, model_type, limit=limit)


@mcp.tool()
async def get_summary(sport: str, model_type: str) -> dict:
    """Get model performance metrics and trending data.

    Args:
        sport: Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)
        model_type: Model type (over_under, won_on_spread, won_on_points)
    """
    client = _get_client()
    return await client.aget_summary(sport, model_type)


@mcp.tool()
async def get_odds(sport: str) -> dict:
    """Get current betting odds for a sport.

    Args:
        sport: Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)
    """
    client = _get_client()
    return await client.aget_odds(sport)


@mcp.tool()
async def get_ai_analysis(sport: str, model_type: str) -> dict:
    """Get AI-powered game analysis with betting recommendations (premium tier only).

    Args:
        sport: Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)
        model_type: Model type (over_under, won_on_spread, won_on_points)
    """
    client = _get_client()
    return await client.aget_ai_analysis(sport, model_type)


@mcp.tool()
async def get_sports() -> dict:
    """List all available sports and model types."""
    client = _get_client()
    return await client.aget_sports()


@mcp.tool()
async def get_account_info() -> dict:
    """Get current account details including tier and subscription status."""
    client = _get_client()
    return await client.aget_account_info()


@mcp.tool()
async def get_usage() -> dict:
    """Get API usage statistics for the current billing period."""
    client = _get_client()
    return await client.aget_usage()


@mcp.tool()
async def clear_cache() -> dict:
    """Clear all cached prediction data (admin only)."""
    client = _get_client()
    return await client.aclear_cache()


@mcp.tool()
async def invalidate_cache(file_path: str | None = None, pattern: str | None = None) -> dict:
    """Invalidate specific cache entries (admin only).

    Args:
        file_path: Specific file path to invalidate (e.g., "NBA/nba_over_predictions.csv")
        pattern: Glob pattern to match (e.g., "NBA/*")
    """
    client = _get_client()
    return await client.ainvalidate_cache(file_path=file_path, pattern=pattern)


@mcp.tool()
async def get_kalshi_markets(sport: str) -> dict:
    """Get Kalshi prediction market prices for a sport.

    Args:
        sport: Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)
    """
    from sflow_cli.markets import KalshiClient

    client = KalshiClient()
    try:
        return await client.aget_markets(sport)
    finally:
        await client.aclose()


@mcp.tool()
async def get_polymarket_odds(sport: str) -> dict:
    """Get Polymarket prediction market odds for a sport.

    Args:
        sport: Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)
    """
    from sflow_cli.markets import PolymarketClient

    client = PolymarketClient()
    try:
        return await client.aget_events(sport)
    finally:
        await client.aclose()


@mcp.tool()
async def compare_market_odds(sport: str, model_type: str = "won_on_spread") -> dict:
    """Compare prediction market odds with ML model predictions.

    Args:
        sport: Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)
        model_type: Model type (over_under, won_on_spread, won_on_points)
    """
    from sflow_cli.markets import KalshiClient, PolymarketClient

    sflow = _get_client()
    kalshi = KalshiClient()
    poly = PolymarketClient()
    try:
        predictions = await sflow.aget_predictions(sport, model_type)
        kalshi_data = await kalshi.aget_markets(sport)
        poly_data = await poly.aget_events(sport)
        return {
            "predictions": predictions,
            "kalshi": kalshi_data,
            "polymarket": poly_data,
        }
    finally:
        await kalshi.aclose()
        await poly.aclose()


@mcp.tool()
async def get_game_weather(sport: str) -> list:
    """Get weather at outdoor game venues for a sport.

    Args:
        sport: Sport code (nfl, mlb, ncaaf — outdoor sports only)
    """
    from sflow_cli.weather import WeatherClient, get_outdoor_venues

    venues = get_outdoor_venues(sport)
    if not venues:
        return []
    client = WeatherClient()
    try:
        return await client.aget_game_weather(sport, list(venues.keys()))
    finally:
        await client.aclose()


@mcp.tool()
async def get_live_scores(sport: str, date: str | None = None) -> dict:
    """Get live game scores.

    Args:
        sport: Sport code (nba, nfl, mlb, nhl)
        date: Optional date (YYYY-MM-DD), defaults to today
    """
    from sflow_cli.config import SflowConfig
    from sflow_cli.live_data import BallDontLieClient

    config = SflowConfig()
    bdl_key = config.resolve_balldontlie()
    if not bdl_key:
        return {"error": "BALLDONTLIE API key not configured"}
    client = BallDontLieClient(bdl_key)
    try:
        return await client.aget_games(sport, date=date)
    finally:
        await client.aclose()


@mcp.tool()
async def get_injuries(sport: str) -> dict:
    """Get current injury reports.

    Args:
        sport: Sport code (nba, nfl, mlb, nhl)
    """
    from sflow_cli.config import SflowConfig
    from sflow_cli.live_data import BallDontLieClient

    config = SflowConfig()
    bdl_key = config.resolve_balldontlie()
    if not bdl_key:
        return {"error": "BALLDONTLIE API key not configured"}
    client = BallDontLieClient(bdl_key)
    try:
        return await client.aget_injuries(sport)
    finally:
        await client.aclose()


@mcp.tool()
async def get_players(
    sport: str,
    team_id: int | None = None,
    search: str | None = None,
    per_page: int = 25,
) -> dict:
    """List current players (rosters) for a sport.

    Args:
        sport: Sport code (nba, nfl, mlb, nhl)
        team_id: Optional BALLDONTLIE team id to filter to one franchise
        search: Optional first/last name substring filter
        per_page: Page size, max 100 (default 25)
    """
    from sflow_cli.config import SflowConfig
    from sflow_cli.live_data import BallDontLieClient

    config = SflowConfig()
    bdl_key = config.resolve_balldontlie()
    if not bdl_key:
        return {"error": "BALLDONTLIE API key not configured"}
    client = BallDontLieClient(bdl_key)
    try:
        return await client.aget_players(
            sport,
            team_id=team_id,
            search=search,
            per_page=per_page,
        )
    finally:
        await client.aclose()


@mcp.tool()
async def get_betting_consensus(sport: str) -> list:
    """Get public betting consensus from Covers.com.

    Args:
        sport: Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)
    """
    from sflow_cli.consensus import CoversClient

    client = CoversClient()
    try:
        return await client.aget_consensus(sport)
    finally:
        await client.aclose()


def main() -> None:
    """Entry point for sfs-mcp command."""
    mcp.run()


if __name__ == "__main__":
    main()
