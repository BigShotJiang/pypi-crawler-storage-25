"""Typed API exceptions mapped to HTTP status codes."""


class SflowAPIError(Exception):
    """Base exception for Scottfree Sports API errors."""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class AuthError(SflowAPIError):
    """401 Unauthorized — invalid or missing API key."""


class ForbiddenError(SflowAPIError):
    """403 Forbidden — tier limitation."""


class NotFoundError(SflowAPIError):
    """404 Not Found — resource not available."""


class RateLimitError(SflowAPIError):
    """429 Too Many Requests — rate limit exceeded."""


class ServerError(SflowAPIError):
    """500/502/503 — server-side error."""


_STATUS_MAP = {
    401: AuthError,
    403: ForbiddenError,
    404: NotFoundError,
    429: RateLimitError,
}


def raise_for_status(status_code: int, detail: str) -> None:
    """Raise the appropriate exception for non-2xx status codes."""
    if 200 <= status_code < 300:
        return
    exc_class = _STATUS_MAP.get(status_code, ServerError if status_code >= 500 else SflowAPIError)
    raise exc_class(status_code, detail)
