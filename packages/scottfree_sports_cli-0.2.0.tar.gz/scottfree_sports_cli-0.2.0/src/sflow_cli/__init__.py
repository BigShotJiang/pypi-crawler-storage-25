"""Scottfree Sports CLI and MCP server for Scottfree Analytics."""

__version__ = "0.1.0"
