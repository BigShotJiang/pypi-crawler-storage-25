"""ScottfreeSportsClient — sync + async HTTP client for the Scottfree Analytics API."""

from __future__ import annotations

import asyncio
import time

import httpx

from sflow_cli.exceptions import raise_for_status

_RETRYABLE = {502, 503, 504}
_MAX_RETRIES = 2
_TIMEOUT = 30.0


class SflowClient:
    """Shared HTTP client for Scottfree Sports API (sync + async)."""

    API_PREFIX = "/api/v1"

    def __init__(self, api_key: str, api_url: str):
        self.api_key = api_key
        self.base_url = f"{api_url.rstrip('/')}{self.API_PREFIX}"
        self._headers = {"X-API-Key": api_key}
        self._sync_client: httpx.Client | None = None
        self._async_client: httpx.AsyncClient | None = None

    def _get_sync_client(self) -> httpx.Client:
        if self._sync_client is None or self._sync_client.is_closed:
            self._sync_client = httpx.Client(timeout=_TIMEOUT, headers=self._headers)
        return self._sync_client

    async def _get_async_client(self) -> httpx.AsyncClient:
        if self._async_client is None or self._async_client.is_closed:
            self._async_client = httpx.AsyncClient(timeout=_TIMEOUT, headers=self._headers)
        return self._async_client

    def close(self) -> None:
        if self._sync_client and not self._sync_client.is_closed:
            self._sync_client.close()

    async def aclose(self) -> None:
        if self._async_client and not self._async_client.is_closed:
            await self._async_client.close()

    # ── helpers ──────────────────────────────────────────────────────

    def _handle_response(self, resp: httpx.Response) -> dict | list:
        if resp.status_code >= 400:
            detail = ""
            try:
                body = resp.json()
                detail = body.get("detail", body.get("message", str(body)))
            except Exception:
                detail = resp.text or f"HTTP {resp.status_code}"
            raise_for_status(resp.status_code, detail)
        return resp.json()

    # ── sync methods (CLI) ───────────────────────────────────────────

    def _get(self, path: str, params: dict | None = None) -> dict | list:
        retries = 0
        while True:
            try:
                client = self._get_sync_client()
                resp = client.get(f"{self.base_url}{path}", params=params)
                if resp.status_code not in _RETRYABLE or retries >= _MAX_RETRIES:
                    return self._handle_response(resp)
                retries += 1
                time.sleep(2**retries)
            except httpx.ConnectError:
                if retries >= _MAX_RETRIES:
                    raise
                retries += 1
                time.sleep(2**retries)

    def _post(self, path: str, json: dict | None = None, params: dict | None = None) -> dict:
        client = self._get_sync_client()
        resp = client.post(f"{self.base_url}{path}", json=json, params=params)
        return self._handle_response(resp)

    def _delete(self, path: str) -> dict:
        client = self._get_sync_client()
        resp = client.delete(f"{self.base_url}{path}")
        return self._handle_response(resp)

    def _patch(self, path: str, json: dict | None = None) -> dict:
        client = self._get_sync_client()
        resp = client.patch(f"{self.base_url}{path}", json=json)
        return self._handle_response(resp)

    # ── data endpoints ───────────────────────────────────────────────

    def get_predictions(self, sport: str, model_type: str) -> dict:
        return self._get(f"/predictions/{sport}/{model_type}")

    def get_results(self, sport: str, model_type: str, limit: int = 100) -> dict:
        return self._get(f"/results/{sport}/{model_type}", params={"limit": limit})

    def get_summary(self, sport: str, model_type: str) -> dict:
        return self._get(f"/summary/{sport}/{model_type}")

    def get_odds(self, sport: str) -> dict:
        return self._get(f"/odds/{sport}")

    def get_ai_analysis(self, sport: str, model_type: str) -> dict:
        return self._get(f"/ai-analysis/{sport}/{model_type}")

    def get_sports(self) -> dict:
        return self._get("/sports")

    # ── account endpoints ────────────────────────────────────────────

    def get_account_info(self) -> dict:
        return self._get("/customers/me")

    def get_usage(self) -> dict:
        return self._get("/customers/me/usage")

    def get_api_keys(self) -> dict | list:
        return self._get("/customers/me/api-keys")

    def create_api_key(self, name: str | None = None) -> dict:
        body = {"name": name} if name else {}
        return self._post("/customers/me/api-keys", json=body)

    def revoke_api_key(self, api_key: str) -> dict:
        return self._delete(f"/customers/me/api-keys/{api_key}")

    def rename_api_key(self, api_key: str, name: str) -> dict:
        return self._patch(
            "/customers/me/api-keys/rename",
            json={"api_key_to_rename": api_key, "new_name": name},
        )

    # ── admin endpoints ──────────────────────────────────────────────

    def clear_cache(self) -> dict:
        return self._post("/admin/cache/clear")

    def invalidate_cache(self, file_path: str | None = None, pattern: str | None = None) -> dict:
        params = {}
        if file_path:
            params["file_path"] = file_path
        if pattern:
            params["pattern"] = pattern
        return self._post("/admin/cache/invalidate", params=params)

    def get_cache_stats(self) -> dict:
        return self._get("/admin/cache/stats")

    # ── async methods (MCP server) ───────────────────────────────────

    async def _aget(self, path: str, params: dict | None = None) -> dict | list:
        retries = 0
        while True:
            try:
                client = await self._get_async_client()
                resp = await client.get(f"{self.base_url}{path}", params=params)
                if resp.status_code not in _RETRYABLE or retries >= _MAX_RETRIES:
                    return self._handle_response(resp)
                retries += 1
                await asyncio.sleep(2**retries)
            except httpx.ConnectError:
                if retries >= _MAX_RETRIES:
                    raise
                retries += 1
                await asyncio.sleep(2**retries)

    async def _apost(self, path: str, json: dict | None = None, params: dict | None = None) -> dict:
        client = await self._get_async_client()
        resp = await client.post(f"{self.base_url}{path}", json=json, params=params)
        return self._handle_response(resp)

    async def aget_predictions(self, sport: str, model_type: str) -> dict:
        return await self._aget(f"/predictions/{sport}/{model_type}")

    async def aget_results(self, sport: str, model_type: str, limit: int = 100) -> dict:
        return await self._aget(f"/results/{sport}/{model_type}", params={"limit": limit})

    async def aget_summary(self, sport: str, model_type: str) -> dict:
        return await self._aget(f"/summary/{sport}/{model_type}")

    async def aget_odds(self, sport: str) -> dict:
        return await self._aget(f"/odds/{sport}")

    async def aget_ai_analysis(self, sport: str, model_type: str) -> dict:
        return await self._aget(f"/ai-analysis/{sport}/{model_type}")

    async def aget_sports(self) -> dict:
        return await self._aget("/sports")

    async def aget_account_info(self) -> dict:
        return await self._aget("/customers/me")

    async def aget_usage(self) -> dict:
        return await self._aget("/customers/me/usage")

    async def aget_api_keys(self) -> dict | list:
        return await self._aget("/customers/me/api-keys")

    async def aclear_cache(self) -> dict:
        return await self._apost("/admin/cache/clear")

    async def ainvalidate_cache(
        self, file_path: str | None = None, pattern: str | None = None
    ) -> dict:
        params = {}
        if file_path:
            params["file_path"] = file_path
        if pattern:
            params["pattern"] = pattern
        return await self._apost("/admin/cache/invalidate", params=params)

    async def aget_cache_stats(self) -> dict:
        return await self._aget("/admin/cache/stats")
