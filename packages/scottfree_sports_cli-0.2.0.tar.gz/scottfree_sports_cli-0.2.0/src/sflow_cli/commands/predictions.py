"""sfs predictions get/list-sports commands."""

from __future__ import annotations

import typer
from rich.table import Table

from sflow_cli.exceptions import SflowAPIError
from sflow_cli.formatters import (
    console,
    error_console,
    format_csv,
    format_json,
    format_predictions_table,
    resolve_model_type,
)
from sflow_cli.helpers import get_client_from_env

app = typer.Typer(help="Get game predictions.")


@app.command()
def get(
    sport: str = typer.Argument(help="Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)"),
    model_type: str = typer.Argument(help="Model type (spread, moneyline/ml, over_under/ou)"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json, csv"),
    no_color: bool = typer.Option(False, "--no-color", help="Disable Rich formatting"),
) -> None:
    """Get predictions for a sport and model type."""
    if no_color:
        from rich.console import Console as _C

        import sflow_cli.formatters as fmt

        fmt.console = _C(no_color=True)

    resolved_type = resolve_model_type(model_type)
    client = get_client_from_env(env)
    try:
        data = client.get_predictions(sport.lower(), resolved_type)
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    if output == "json":
        typer.echo(format_json(data))
    elif output == "csv":
        games = data.get("games", [])
        if games:
            flat = []
            for g in games:
                row = {
                    "away_team": g.get("away_team"),
                    "home_team": g.get("home_team"),
                }
                row.update(g.get("predictions", {}))
                flat.append(row)
            typer.echo(format_csv(flat))
    else:
        format_predictions_table(data)


@app.command("list-sports")
def list_sports(
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
) -> None:
    """List available sports and model types."""
    client = get_client_from_env(env)
    try:
        data = client.get_sports()
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    table = Table(title="Available Sports")
    table.add_column("Code", style="cyan")
    table.add_column("Name")
    for sport in data.get("sports", []):
        table.add_row(sport["code"], sport["name"])
    console.print(table)

    table = Table(title="Model Types")
    table.add_column("Code", style="cyan")
    table.add_column("Name")
    for mt in data.get("model_types", []):
        table.add_row(mt["code"], mt["name"])
    console.print(table)
