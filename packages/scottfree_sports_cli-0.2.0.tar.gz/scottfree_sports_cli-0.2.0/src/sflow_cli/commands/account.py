"""sfs account info/usage/keys/create-key/revoke-key/rename-key commands."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from sflow_cli.exceptions import SflowAPIError
from sflow_cli.formatters import error_console, format_json
from sflow_cli.helpers import get_client_from_env

app = typer.Typer(help="Manage your account.")
console = Console()


@app.command()
def info(
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """Show account information."""
    client = get_client_from_env(env)
    try:
        data = client.get_account_info()
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    if output == "json":
        typer.echo(format_json(data))
        return

    table = Table(title="Account Info")
    table.add_column("Field", style="cyan")
    table.add_column("Value")
    for key, value in data.items():
        table.add_row(key, str(value))
    console.print(table)


@app.command()
def usage(
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """Show API usage statistics."""
    client = get_client_from_env(env)
    try:
        data = client.get_usage()
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    if output == "json":
        typer.echo(format_json(data))
        return

    table = Table(title="API Usage")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", justify="right")
    for key, value in data.items():
        table.add_row(key.replace("_", " ").title(), str(value))
    console.print(table)


@app.command()
def keys(
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """List your API keys."""
    client = get_client_from_env(env)
    try:
        data = client.get_api_keys()
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    if output == "json":
        typer.echo(format_json(data))
        return

    keys_list = data if isinstance(data, list) else data.get("api_keys", [])
    table = Table(title="API Keys")
    table.add_column("Name", style="cyan")
    table.add_column("Key")
    table.add_column("Active", justify="center")
    for key in keys_list:
        active = "[green]Yes[/green]" if key.get("is_active", True) else "[red]No[/red]"
        table.add_row(key.get("name", "-"), key.get("api_key", "-"), active)
    console.print(table)


@app.command("create-key")
def create_key(
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Key name"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
) -> None:
    """Create a new API key."""
    client = get_client_from_env(env)
    try:
        data = client.create_api_key(name=name)
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    console.print(f"[green]API key created:[/green] {data.get('api_key', 'unknown')}")
    if data.get("warning"):
        console.print(f"[yellow]{data['warning']}[/yellow]")


@app.command("revoke-key")
def revoke_key(
    api_key: str = typer.Argument(help="API key to revoke"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
) -> None:
    """Revoke an API key."""
    client = get_client_from_env(env)
    try:
        data = client.revoke_api_key(api_key)
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    console.print(f"[green]{data.get('message', 'Key revoked')}[/green]")


@app.command("rename-key")
def rename_key(
    api_key: str = typer.Argument(help="API key to rename"),
    name: str = typer.Option(..., "--name", "-n", help="New name"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
) -> None:
    """Rename an API key."""
    client = get_client_from_env(env)
    try:
        data = client.rename_api_key(api_key, name)
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    console.print(f"[green]{data.get('message', 'Key renamed')}[/green]")
