"""sfs config set/show/profiles commands."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from sflow_cli.config import SflowConfig, _keyring_available

app = typer.Typer(help="Manage API configuration and profiles.")
console = Console()


def _get_config() -> SflowConfig:
    config_dir = os.environ.get("SFS_CONFIG_DIR")
    if config_dir:
        return SflowConfig(config_dir=Path(config_dir))
    return SflowConfig()


@app.command()
def set(
    api_key: Optional[str] = typer.Option(None, "--api-key", help="API key"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    balldontlie_api_key: Optional[str] = typer.Option(
        None, "--balldontlie-api-key", help="BallDontLie API key"
    ),
    use_keyring: bool = typer.Option(
        False, "--use-keyring", help="Store API keys in system keyring (macOS Keychain)"
    ),
    env: str = typer.Option("default", "--env", "-e", help="Profile name"),
) -> None:
    """Set configuration values for a profile."""
    if use_keyring and not _keyring_available():
        console.print(
            "[yellow]Keyring not available. Install keyring package or check backend.[/yellow]"
        )
        console.print("Falling back to config file storage.")
        use_keyring = False

    config = _get_config()
    config.set_profile(
        env,
        api_key=api_key,
        api_url=api_url,
        balldontlie_api_key=balldontlie_api_key,
        use_keyring=use_keyring,
    )
    storage = "system keyring + config file" if use_keyring else "config file"
    console.print(f"[green]Config saved to profile '[bold]{env}[/bold]' ({storage}).[/green]")


@app.command()
def show(
    env: str = typer.Option("default", "--env", "-e", help="Profile to show"),
) -> None:
    """Show current configuration."""
    config = _get_config()
    profile = config.get_profile(env)
    if not profile:
        console.print(f"[yellow]No profile '{env}' found.[/yellow]")
        return
    table = Table(title=f"Profile: {env}")
    table.add_column("Key", style="cyan")
    table.add_column("Value")
    for key, value in profile.items():
        display_value = value
        if value == "keyring:":
            display_value = "(stored in system keyring)"
        elif key.endswith("api_key") and value and len(str(value)) > 10:
            display_value = str(value)[:15] + "***"
        table.add_row(key, str(display_value))
    console.print(table)


@app.command()
def profiles() -> None:
    """List all configured profiles."""
    config = _get_config()
    profile_names = config.list_profiles()
    if not profile_names:
        console.print("[yellow]No profiles configured.[/yellow]")
        console.print("Run: [bold]sfs config set --api-key YOUR_KEY[/bold]")
        return
    table = Table(title="Profiles")
    table.add_column("Name", style="cyan")
    table.add_column("API URL")
    for name in profile_names:
        p = config.get_profile(name) or {}
        table.add_row(name, p.get("api_url", "(default)"))
    console.print(table)
