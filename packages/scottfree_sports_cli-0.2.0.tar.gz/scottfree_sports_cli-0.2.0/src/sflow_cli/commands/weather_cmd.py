"""sfs weather command."""

from __future__ import annotations

import typer

from sflow_cli.formatters import (
    error_console,
    format_csv,
    format_json,
    format_weather_table,
)
from sflow_cli.weather import WeatherClient, get_outdoor_venues

app = typer.Typer(help="Game-day weather for outdoor venues.")


@app.command()
def get(
    sport: str = typer.Argument(help="Sport code (nfl, mlb)"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    output: str = typer.Option("table", "--output", "-o", help="Output: table, json, csv"),
) -> None:
    """Get weather at outdoor game venues."""
    venues = get_outdoor_venues(sport.lower())
    if not venues:
        error_console.print(
            f"[red]No outdoor venues found for sport '{sport}'.[/red]\n"
            "Weather is available for: nfl, mlb"
        )
        raise typer.Exit(1)

    client = WeatherClient()
    try:
        data = client.get_game_weather(sport.lower(), list(venues.keys()))
    except Exception as e:
        error_console.print(f"[red]Weather API error: {e}[/red]")
        raise typer.Exit(1)
    finally:
        client.close()

    if output == "json":
        typer.echo(format_json(data))
    elif output == "csv":
        flat = []
        for entry in data:
            weather = entry.get("weather", {})
            current = weather.get("current", weather)
            flat.append(
                {
                    "venue": entry.get("venue", ""),
                    "temperature_2m": current.get("temperature_2m", ""),
                    "wind_speed_10m": current.get("wind_speed_10m", ""),
                    "precipitation": current.get("precipitation", ""),
                    "weather_code": current.get("weather_code", ""),
                }
            )
        typer.echo(format_csv(flat))
    else:
        format_weather_table(data)
