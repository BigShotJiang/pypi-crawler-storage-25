"""sfs scores and injuries commands."""

from __future__ import annotations

from pathlib import Path

import typer

from sflow_cli.config import SflowConfig
from sflow_cli.exceptions import SflowAPIError
from sflow_cli.formatters import (
    error_console,
    format_csv,
    format_injuries_table,
    format_json,
    format_players_table,
    format_scores_table,
)
from sflow_cli.live_data import BallDontLieClient

app = typer.Typer(help="Live scores and injury reports.")


def _get_bdl_client(env: str) -> BallDontLieClient:
    """Resolve BallDontLie API key and return a client."""
    import os

    config_dir = os.environ.get("SFS_CONFIG_DIR")
    config = SflowConfig(config_dir=Path(config_dir)) if config_dir else SflowConfig()
    bdl_key = config.resolve_balldontlie(env=env)
    if not bdl_key:
        error_console.print(
            "[red]BALLDONTLIE API key not configured.[/red]\n"
            "Run: [bold]sfs config set --balldontlie-api-key YOUR_KEY[/bold]"
        )
        raise typer.Exit(1)
    return BallDontLieClient(bdl_key)


@app.command("scores")
def get_scores(
    sport: str = typer.Argument(help="Sport code (nba, nfl, mlb, nhl)"),
    date: str = typer.Option(None, "--date", "-d", help="Date (YYYY-MM-DD), defaults to today"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    output: str = typer.Option("table", "--output", "-o", help="Output: table, json, csv"),
) -> None:
    """Get live game scores."""
    client = _get_bdl_client(env)
    try:
        data = client.get_games(sport.lower(), date=date)
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)
    finally:
        client.close()

    games = data.get("data", data.get("games", []))
    if output == "json":
        typer.echo(format_json(games))
    elif output == "csv":
        typer.echo(format_csv(games))
    else:
        format_scores_table(games)


@app.command("injuries")
def get_injuries(
    sport: str = typer.Argument(help="Sport code (nba, nfl, mlb, nhl)"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    output: str = typer.Option("table", "--output", "-o", help="Output: table, json, csv"),
) -> None:
    """Get current injury reports."""
    client = _get_bdl_client(env)
    try:
        data = client.get_injuries(sport.lower())
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)
    finally:
        client.close()

    injuries = data.get("data", data.get("injuries", []))
    if output == "json":
        typer.echo(format_json(injuries))
    elif output == "csv":
        typer.echo(format_csv(injuries))
    else:
        format_injuries_table(injuries)


@app.command("players")
def get_players(
    sport: str = typer.Argument(help="Sport code (nba, nfl, mlb, nhl)"),
    team_id: int = typer.Option(
        None, "--team-id", "-t", help="Filter to one team by BALLDONTLIE team id"
    ),
    search: str = typer.Option(None, "--search", "-s", help="Match first/last name substring"),
    per_page: int = typer.Option(25, "--per-page", "-n", help="Page size (max 100)"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    output: str = typer.Option("table", "--output", "-o", help="Output: table, json, csv"),
) -> None:
    """List current players (rosters) — BALLDONTLIE free-tier endpoint."""
    client = _get_bdl_client(env)
    try:
        data = client.get_players(
            sport.lower(),
            team_id=team_id,
            search=search,
            per_page=per_page,
        )
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)
    finally:
        client.close()

    players = data.get("data", data.get("players", []))
    if output == "json":
        typer.echo(format_json(players))
    elif output == "csv":
        typer.echo(format_csv(players))
    else:
        format_players_table(players)
