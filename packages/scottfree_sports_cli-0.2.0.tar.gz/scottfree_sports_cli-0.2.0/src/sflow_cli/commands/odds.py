"""sfs odds get command."""

from __future__ import annotations

import typer
from rich.table import Table

from sflow_cli.exceptions import SflowAPIError
from sflow_cli.formatters import console, error_console
from sflow_cli.helpers import get_client_from_env

app = typer.Typer(help="Get current betting odds.")


@app.command()
def get(
    sport: str = typer.Argument(help="Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
) -> None:
    """Get current betting odds for a sport."""
    client = get_client_from_env(env)
    try:
        data = client.get_odds(sport.lower())
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    table = Table(title=f"Odds: {sport.upper()}")
    table.add_column("Away Team", style="cyan")
    table.add_column("Home Team", style="cyan")
    table.add_column("Spread")
    table.add_column("Over/Under")
    table.add_column("Moneyline")
    for game in data.get("games", []):
        table.add_row(
            str(game.get("away_team", "")),
            str(game.get("home_team", "")),
            str(game.get("home_point_spread", "")),
            str(game.get("over_under", "")),
            str(game.get("moneyline", "")),
        )
    console.print(table)
