"""sfs analysis get command."""

from __future__ import annotations

import typer
from rich.table import Table

from sflow_cli.exceptions import SflowAPIError
from sflow_cli.formatters import console, error_console, resolve_model_type
from sflow_cli.helpers import get_client_from_env

app = typer.Typer(help="Get AI-powered game analysis.")


@app.command()
def get(
    sport: str = typer.Argument(help="Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)"),
    model_type: str = typer.Argument(help="Model type (spread, moneyline/ml, over_under/ou)"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
) -> None:
    """Get AI-powered analysis for a sport and model type."""
    resolved_type = resolve_model_type(model_type)
    client = get_client_from_env(env)
    try:
        data = client.get_ai_analysis(sport.lower(), resolved_type)
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    table = Table(title=f"Analysis: {sport.upper()} - {resolved_type}")
    table.add_column("Away Team", style="cyan")
    table.add_column("Home Team", style="cyan")
    table.add_column("Recommendation", style="yellow")
    table.add_column("Risk Level")
    table.add_column("Narrative")
    for analysis in data.get("analyses", []):
        ai = analysis.get("ai_analysis", {})
        table.add_row(
            str(analysis.get("away_team", "")),
            str(analysis.get("home_team", "")),
            str(analysis.get("recommendation", "")),
            str(analysis.get("risk_level", "")),
            str(ai.get("narrative", ""))[:50],
        )
    console.print(table)
