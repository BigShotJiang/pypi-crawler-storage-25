"""sfs summary get command."""

from __future__ import annotations

import typer
from rich.table import Table

from sflow_cli.exceptions import SflowAPIError
from sflow_cli.formatters import console, error_console, resolve_model_type
from sflow_cli.helpers import get_client_from_env

app = typer.Typer(help="Get model performance summaries.")


@app.command()
def get(
    sport: str = typer.Argument(help="Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)"),
    model_type: str = typer.Argument(help="Model type (spread, moneyline/ml, over_under/ou)"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
) -> None:
    """Get model performance summary for a sport and model type."""
    resolved_type = resolve_model_type(model_type)
    client = get_client_from_env(env)
    try:
        data = client.get_summary(sport.lower(), resolved_type)
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    table = Table(title=f"Summary: {sport.upper()} - {resolved_type}")
    table.add_column("Model", style="cyan")
    table.add_column("Win %")
    table.add_column("ATS %")
    table.add_column("Total Games")
    for summary in data.get("summaries", []):
        table.add_row(
            str(summary.get("model", "")),
            str(summary.get("win %", "")),
            str(summary.get("ats %", "")),
            str(summary.get("total_games", "")),
        )
    console.print(table)
