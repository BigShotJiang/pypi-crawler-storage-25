"""sfs markets commands — prediction market odds from Kalshi and Polymarket."""

from __future__ import annotations

import typer

from sflow_cli.exceptions import SflowAPIError
from sflow_cli.formatters import (
    error_console,
    format_comparison_table,
    format_csv,
    format_json,
    format_kalshi_table,
    format_polymarket_table,
)
from sflow_cli.helpers import get_client_from_env
from sflow_cli.markets import KalshiClient, PolymarketClient

app = typer.Typer(help="Prediction market odds.")


@app.command()
def kalshi(
    sport: str = typer.Argument(help="Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    output: str = typer.Option("table", "--output", "-o", help="Output: table, json, csv"),
) -> None:
    """Get Kalshi prediction market odds."""
    client = KalshiClient()
    try:
        data = client.get_markets(sport.lower())
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)
    finally:
        client.close()

    markets = data.get("markets", [])
    if output == "json":
        typer.echo(format_json(markets))
    elif output == "csv":
        typer.echo(format_csv(markets))
    else:
        format_kalshi_table(markets)


@app.command()
def polymarket(
    sport: str = typer.Argument(help="Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    output: str = typer.Option("table", "--output", "-o", help="Output: table, json, csv"),
) -> None:
    """Get Polymarket prediction market odds."""
    client = PolymarketClient()
    try:
        data = client.get_events(sport.lower())
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)
    finally:
        client.close()

    events = data if isinstance(data, list) else data.get("events", [data])
    if output == "json":
        typer.echo(format_json(events))
    elif output == "csv":
        flat = []
        for ev in events:
            for m in ev.get("markets", [ev]):
                flat.append(
                    {
                        "event": ev.get("title", ""),
                        "question": m.get("question", m.get("title", "")),
                        "yes_price": m.get("yes_price", ""),
                        "no_price": m.get("no_price", ""),
                        "volume_24h": m.get("volume_24h", m.get("volume", "")),
                    }
                )
        typer.echo(format_csv(flat))
    else:
        format_polymarket_table(events)


@app.command()
def compare(
    sport: str = typer.Argument(help="Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    output: str = typer.Option("table", "--output", "-o", help="Output: table, json, csv"),
) -> None:
    """Compare prediction market odds with ML model predictions."""
    # Fetch predictions from our API
    api_client = get_client_from_env(env)
    try:
        predictions = api_client.get_predictions(sport.lower(), "won_on_spread")
    except SflowAPIError as e:
        error_console.print(f"[red]API error: {e}[/red]")
        raise typer.Exit(1)

    # Fetch Kalshi data
    kalshi_client = KalshiClient()
    try:
        kalshi_data = kalshi_client.get_markets(sport.lower())
        kalshi_markets = kalshi_data.get("markets", [])
    except Exception:
        kalshi_markets = []
    finally:
        kalshi_client.close()

    # Fetch Polymarket data
    poly_client = PolymarketClient()
    try:
        poly_data = poly_client.get_events(sport.lower())
        poly_events = poly_data if isinstance(poly_data, list) else poly_data.get("events", [])
    except Exception:
        poly_events = []
    finally:
        poly_client.close()

    if output == "json":
        typer.echo(
            format_json(
                {
                    "predictions": predictions,
                    "kalshi": kalshi_markets,
                    "polymarket": poly_events,
                }
            )
        )
    else:
        format_comparison_table(predictions, kalshi_markets, poly_events)
