"""sfs consensus command."""

from __future__ import annotations

import typer

from sflow_cli.consensus import CoversClient
from sflow_cli.formatters import (
    console,
    error_console,
    format_consensus_table,
    format_csv,
    format_json,
)

app = typer.Typer(help="Public betting consensus.")


@app.command()
def get(
    sport: str = typer.Argument(help="Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    output: str = typer.Option("table", "--output", "-o", help="Output: table, json, csv"),
) -> None:
    """Get public betting consensus from Covers.com."""
    client = CoversClient()
    try:
        data = client.get_consensus(sport.lower())
    except Exception as e:
        error_console.print(f"[red]Consensus fetch error: {e}[/red]")
        raise typer.Exit(1)
    finally:
        client.close()

    if not data:
        console.print(f"[yellow]No consensus data available for {sport.upper()}.[/yellow]")
        return

    if output == "json":
        typer.echo(format_json(data))
    elif output == "csv":
        typer.echo(format_csv(data))
    else:
        format_consensus_table(data)
