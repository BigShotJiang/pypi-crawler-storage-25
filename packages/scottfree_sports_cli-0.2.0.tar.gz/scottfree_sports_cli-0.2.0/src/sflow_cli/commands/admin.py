"""sfs admin cache-clear/cache-invalidate/cache-stats commands (Scottfree admin only)."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from sflow_cli.exceptions import SflowAPIError
from sflow_cli.formatters import error_console, format_json
from sflow_cli.helpers import get_client_from_env

app = typer.Typer(help="Admin operations (Scottfree admin only).")
console = Console()


@app.command("cache-clear")
def cache_clear(
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
) -> None:
    """Clear all cached data."""
    client = get_client_from_env(env)
    try:
        data = client.clear_cache()
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    console.print(f"[green]{data.get('message', 'Cache cleared')}[/green]")


@app.command("cache-invalidate")
def cache_invalidate(
    file_path: Optional[str] = typer.Option(None, "--file-path", help="Specific file path"),
    pattern: Optional[str] = typer.Option(None, "--pattern", help="Glob pattern"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
) -> None:
    """Invalidate specific cache entries."""
    client = get_client_from_env(env)
    try:
        data = client.invalidate_cache(file_path=file_path, pattern=pattern)
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    console.print(f"[green]{data.get('message', 'Cache invalidated')}[/green]")


@app.command("cache-stats")
def cache_stats(
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table, json"),
) -> None:
    """Show cache performance statistics."""
    client = get_client_from_env(env)
    try:
        data = client.get_cache_stats()
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    if output == "json":
        typer.echo(format_json(data))
        return

    stats = data.get("cache_stats", data)
    table = Table(title="Cache Statistics")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", justify="right")
    for key, value in stats.items():
        table.add_row(key.replace("_", " ").title(), str(value))
    console.print(table)
