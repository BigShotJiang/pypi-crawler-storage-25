"""sfs results get command."""

from __future__ import annotations

import typer
from rich.table import Table

from sflow_cli.exceptions import SflowAPIError
from sflow_cli.formatters import console, error_console, resolve_model_type
from sflow_cli.helpers import get_client_from_env

app = typer.Typer(help="Get historical prediction results.")


@app.command()
def get(
    sport: str = typer.Argument(help="Sport code (nba, nfl, mlb, nhl, ncaab, ncaaf)"),
    model_type: str = typer.Argument(help="Model type (spread, moneyline/ml, over_under/ou)"),
    env: str = typer.Option("default", "--env", "-e", help="Config profile"),
    limit: int = typer.Option(100, "--limit", "-l", help="Maximum results to fetch"),
) -> None:
    """Get historical prediction results for a sport and model type."""
    resolved_type = resolve_model_type(model_type)
    client = get_client_from_env(env)
    try:
        data = client.get_results(sport.lower(), resolved_type, limit=limit)
    except SflowAPIError as e:
        error_console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    table = Table(title=f"Results: {sport.upper()} - {resolved_type}")
    table.add_column("Date", style="cyan")
    table.add_column("Away Team")
    table.add_column("Home Team")
    table.add_column("Result", style="yellow")
    for result in data.get("results", []):
        table.add_row(
            str(result.get("date", "")),
            str(result.get("away_team", "")),
            str(result.get("home_team", "")),
            str(result.get("result", "")),
        )
    console.print(table)
