"""Rich table rendering and output formatting."""

from __future__ import annotations

import csv
import io
import json

from rich.console import Console
from rich.table import Table

console = Console()
error_console = Console(stderr=True)

# ── model type shorthands ────────────────────────────────────────────

_MODEL_TYPE_MAP = {
    "spread": "won_on_spread",
    "moneyline": "won_on_points",
    "ml": "won_on_points",
    "over_under": "over_under",
    "ou": "over_under",
}


def resolve_model_type(value: str) -> str:
    """Resolve a shorthand model type to its API enum value."""
    return _MODEL_TYPE_MAP.get(value, value)


# ── probability coloring ─────────────────────────────────────────────


def probability_style(prob: float) -> str:
    """Return a Rich style string based on probability thresholds."""
    if prob >= 0.68:
        return "bold green"
    elif prob > 0.50:
        return "green"
    elif prob >= 0.32:
        return "red"
    else:
        return "bold red"


# ── table formatters ─────────────────────────────────────────────────

MODEL_COLUMNS = ["IMPLIED", "AI", "BLEND", "CATB", "RF", "LGB", "LOGR", "XGB", "XT"]


def format_predictions_table(data: dict) -> None:
    """Render predictions as a Rich table to the console."""
    sport = data.get("sport", "").upper()
    model_type = data.get("model_type", "")
    games = data.get("games", [])

    title = f"{sport} {model_type.replace('_', ' ').title()} Predictions"
    if data.get("predictions_date"):
        title += f" ({data['predictions_date'][:10]})"

    table = Table(title=title, show_lines=False)
    table.add_column("Matchup", style="cyan")
    table.add_column("Line", justify="right")
    for model in MODEL_COLUMNS:
        table.add_column(model, justify="right")

    for game in games:
        away = game.get("away_team", "?")
        home = game.get("home_team", "?")
        preds = game.get("predictions", {})

        # Build matchup string with spread/line info
        line_str = ""
        if "home_point_spread" in game:
            line_str = str(game["home_point_spread"])
        elif "over_under" in game:
            line_str = str(game["over_under"])
        elif "home_money_line" in game:
            line_str = str(game["home_money_line"])

        matchup = f"{away} @ {home}"

        row = [matchup, line_str]
        for model in MODEL_COLUMNS:
            prob = preds.get(model)
            if prob is not None:
                style = probability_style(prob)
                row.append(f"[{style}]{prob:.1%}[/{style}]")
            else:
                row.append("-")
        table.add_row(*row)

    console.print(table)


def format_results_table(data: dict) -> None:
    """Render results as a Rich table."""
    sport = data.get("sport", "").upper()
    results = data.get("results", [])

    table = Table(title=f"{sport} Results", show_lines=False)
    if results:
        for key in results[0]:
            table.add_column(key)
        for row in results:
            table.add_row(*[str(v) for v in row.values()])

    console.print(table)


def format_summary_table(data: dict) -> None:
    """Render summary as a Rich table."""
    sport = data.get("sport", "").upper()
    summaries = data.get("summaries", [])

    table = Table(title=f"{sport} Model Summary", show_lines=False)
    if summaries:
        for key in summaries[0]:
            justify = "right" if key != "model" else "left"
            table.add_column(key, justify=justify)
        for row in summaries:
            table.add_row(*[str(v) for v in row.values()])

    console.print(table)


def format_generic_table(data: list[dict], title: str = "") -> None:
    """Render a list of dicts as a Rich table."""
    table = Table(title=title, show_lines=False)
    if data:
        for key in data[0]:
            table.add_column(key)
        for row in data:
            table.add_row(*[str(v) for v in row.values()])
    console.print(table)


# ── output format helpers ────────────────────────────────────────────


def format_json(data: dict | list) -> str:
    """Return pretty-printed JSON string."""
    return json.dumps(data, indent=2, default=str)


def format_csv(data: list[dict]) -> str:
    """Return CSV string from a list of dicts."""
    if not data:
        return ""
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=data[0].keys())
    writer.writeheader()
    writer.writerows(data)
    return output.getvalue()


# ── domain-specific table formatters ────────────────────────────────

_WEATHER_CODES: dict[int, str] = {
    0: "Clear",
    1: "Partly Cloudy",
    2: "Partly Cloudy",
    3: "Partly Cloudy",
    45: "Foggy",
    48: "Foggy",
    51: "Drizzle",
    53: "Drizzle",
    55: "Drizzle",
    61: "Rain",
    63: "Rain",
    65: "Rain",
    71: "Snow",
    73: "Snow",
    75: "Snow",
    80: "Showers",
    81: "Showers",
    82: "Showers",
    95: "Thunderstorm",
    96: "Thunderstorm",
    99: "Thunderstorm",
}


def format_kalshi_table(markets: list[dict]) -> None:
    """Render Kalshi prediction market data as a Rich table."""
    table = Table(title="Kalshi Prediction Markets", show_lines=False)
    table.add_column("Ticker", style="cyan")
    table.add_column("Event")
    table.add_column("YES Price", justify="right")
    table.add_column("NO Price", justify="right")
    table.add_column("Volume 24h", justify="right")
    table.add_column("Open Interest", justify="right")

    for m in markets:
        yes_price = m.get("yes_price", 0)
        no_price = m.get("no_price", 0)
        yes_pct = yes_price * 100 if isinstance(yes_price, float) and yes_price <= 1 else yes_price
        no_pct = no_price * 100 if isinstance(no_price, float) and no_price <= 1 else no_price
        yes_prob = yes_pct / 100 if yes_pct else 0
        no_prob = no_pct / 100 if no_pct else 0

        yes_style = probability_style(yes_prob)
        no_style = probability_style(no_prob)

        table.add_row(
            str(m.get("ticker", "")),
            str(m.get("title", m.get("event_ticker", ""))),
            f"[{yes_style}]${yes_price:.2f} ({yes_pct:.0f}%)[/{yes_style}]" if yes_price else "-",
            f"[{no_style}]${no_price:.2f} ({no_pct:.0f}%)[/{no_style}]" if no_price else "-",
            str(m.get("volume_24h", m.get("volume", "-"))),
            str(m.get("open_interest", "-")),
        )
    console.print(table)


def format_polymarket_table(events: list[dict]) -> None:
    """Render Polymarket events and odds as a Rich table."""
    table = Table(title="Polymarket Prediction Markets", show_lines=False)
    table.add_column("Event")
    table.add_column("Question")
    table.add_column("YES Price", justify="right")
    table.add_column("NO Price", justify="right")
    table.add_column("Volume 24h", justify="right")

    for event in events:
        event_title = event.get("title", "")
        for market in event.get("markets", [event]):
            question = market.get("question", market.get("groupItemTitle", market.get("title", "")))

            # outcomePrices may be a JSON string '["0.55","0.45"]' or a list
            raw_prices = market.get("outcomePrices", [0, 0])
            if isinstance(raw_prices, str):
                try:
                    raw_prices = json.loads(raw_prices)
                except (json.JSONDecodeError, ValueError):
                    raw_prices = [0, 0]

            # outcomes may also be a JSON string '["Yes","No"]'
            raw_outcomes = market.get("outcomes", ["Yes", "No"])
            if isinstance(raw_outcomes, str):
                try:
                    raw_outcomes = json.loads(raw_outcomes)
                except (json.JSONDecodeError, ValueError):
                    raw_outcomes = ["Yes", "No"]

            yes_price = raw_prices[0] if len(raw_prices) > 0 else 0
            no_price = raw_prices[1] if len(raw_prices) > 1 else 0

            try:
                yes_f = float(yes_price)
                no_f = float(no_price)
            except (ValueError, TypeError):
                yes_f, no_f = 0.0, 0.0

            yes_pct = yes_f * 100 if yes_f <= 1 else yes_f
            no_pct = no_f * 100 if no_f <= 1 else no_f
            yes_prob = yes_pct / 100 if yes_pct else 0
            no_prob = no_pct / 100 if no_pct else 0

            yes_style = probability_style(yes_prob)
            no_style = probability_style(no_prob)

            yes_label = raw_outcomes[0] if len(raw_outcomes) > 0 else "YES"
            no_label = raw_outcomes[1] if len(raw_outcomes) > 1 else "NO"

            table.add_row(
                event_title,
                question,
                f"[{yes_style}]{yes_label} ${yes_f:.2f} ({yes_pct:.0f}%)[/{yes_style}]"
                if yes_f
                else "-",
                f"[{no_style}]{no_label} ${no_f:.2f} ({no_pct:.0f}%)[/{no_style}]"
                if no_f
                else "-",
                str(market.get("volume24hr", market.get("volume", "-"))),
            )
    console.print(table)


def format_comparison_table(predictions: dict, kalshi: list[dict], polymarket: list[dict]) -> None:
    """Render side-by-side comparison of ML predictions vs prediction markets."""
    table = Table(title="ML Predictions vs Prediction Markets", show_lines=False)
    table.add_column("Matchup", style="cyan")
    table.add_column("Spread", justify="right")
    table.add_column("IMPLIED", justify="right")
    table.add_column("BLEND", justify="right")
    table.add_column("Kalshi", justify="right")
    table.add_column("Polymarket", justify="right")

    games = predictions.get("games", [])
    for game in games:
        away = game.get("away_team", "?")
        home = game.get("home_team", "?")
        matchup = f"{away} @ {home}"
        preds = game.get("predictions", {})

        spread = str(game.get("home_point_spread", ""))

        implied = preds.get("IMPLIED")
        blend = preds.get("BLEND")

        implied_str = "-"
        if implied is not None:
            s = probability_style(implied)
            implied_str = f"[{s}]{implied:.1%}[/{s}]"

        blend_str = "-"
        if blend is not None:
            s = probability_style(blend)
            blend_str = f"[{s}]{blend:.1%}[/{s}]"

        # Match Kalshi data by looking for matching tickers/events
        kalshi_str = "-"
        for km in kalshi:
            title = str(km.get("title", km.get("event_ticker", ""))).lower()
            if home.lower() in title or away.lower() in title:
                yes = km.get("yes_price", 0)
                prob = float(yes) if yes else 0
                s = probability_style(prob)
                kalshi_str = f"[{s}]{prob:.1%}[/{s}]"
                break

        # Match Polymarket data
        poly_str = "-"
        for pe in polymarket:
            title = str(pe.get("title", "")).lower()
            if home.lower() in title or away.lower() in title:
                markets = pe.get("markets", [pe])
                if markets:
                    yes = markets[0].get("yes_price", markets[0].get("outcomePrices", [0])[0])
                    try:
                        prob = float(yes)
                    except (ValueError, TypeError):
                        prob = 0
                    s = probability_style(prob)
                    poly_str = f"[{s}]{prob:.1%}[/{s}]"
                break

        table.add_row(matchup, spread, implied_str, blend_str, kalshi_str, poly_str)

    console.print(table)


def format_weather_table(weather_data: list[dict]) -> None:
    """Render weather data for outdoor venues."""
    table = Table(title="Game-Day Weather", show_lines=False)
    table.add_column("Venue", style="cyan")
    table.add_column("Temp (\u00b0F)", justify="right")
    table.add_column("Wind (mph)", justify="right")
    table.add_column("Precip (mm)", justify="right")
    table.add_column("Conditions")

    for entry in weather_data:
        venue = str(entry.get("venue", ""))
        weather = entry.get("weather", {})
        current = weather.get("current", weather)

        temp_c = current.get("temperature_2m", 0)
        temp_f = temp_c * 9 / 5 + 32 if temp_c else 0

        wind_kmh = current.get("wind_speed_10m", 0)
        wind_mph = wind_kmh * 0.621371 if wind_kmh else 0

        precip = current.get("precipitation", 0)
        weather_code = current.get("weather_code", 0)
        conditions = _WEATHER_CODES.get(weather_code, "Unknown")

        table.add_row(
            venue,
            f"{temp_f:.0f}",
            f"{wind_mph:.1f}",
            f"{precip:.1f}",
            conditions,
        )
    console.print(table)


def format_scores_table(games: list[dict]) -> None:
    """Render live game scores."""
    table = Table(title="Live Scores", show_lines=False)
    table.add_column("Away Team", style="cyan")
    table.add_column("Score", justify="right")
    table.add_column("Home Team", style="cyan")
    table.add_column("Score", justify="right")
    table.add_column("Status/Period")

    for game in games:
        status = str(game.get("status", ""))
        status_style = "green" if status.lower() == "final" else "yellow"

        away_score = str(game.get("away_score", game.get("visitor_team_score", "-")))
        home_score = str(game.get("home_score", game.get("home_team_score", "-")))

        table.add_row(
            str(game.get("away_team", game.get("visitor_team", ""))),
            away_score,
            str(game.get("home_team", "")),
            home_score,
            f"[{status_style}]{status}[/{status_style}]",
        )
    console.print(table)


def format_injuries_table(injuries: list[dict]) -> None:
    """Render injury report."""
    table = Table(title="Injury Report", show_lines=False)
    table.add_column("Player", style="cyan")
    table.add_column("Team")
    table.add_column("Status")
    table.add_column("Description")

    _status_colors = {
        "out": "red",
        "questionable": "yellow",
        "probable": "green",
        "doubtful": "red",
        "day-to-day": "yellow",
    }

    for inj in injuries:
        status = str(inj.get("status", ""))
        color = _status_colors.get(status.lower(), "white")

        table.add_row(
            str(inj.get("player", inj.get("name", ""))),
            str(inj.get("team", "")),
            f"[{color}]{status}[/{color}]",
            str(inj.get("description", inj.get("comment", ""))),
        )
    console.print(table)


def format_players_table(players: list[dict]) -> None:
    """Render a roster-style table from BALLDONTLIE /players responses."""
    table = Table(title="Players", show_lines=False)
    table.add_column("Name", style="cyan")
    table.add_column("Team")
    table.add_column("Position")
    table.add_column("Jersey", justify="right")
    table.add_column("Ht/Wt")
    table.add_column("Country")

    for p in players:
        first = str(p.get("first_name", ""))
        last = str(p.get("last_name", ""))
        name = f"{first} {last}".strip() or str(p.get("name", ""))

        team = p.get("team") or {}
        team_name = str(team.get("full_name") or team.get("name") or team.get("abbreviation") or "")

        position = str(p.get("position") or p.get("primary_position") or "")
        jersey = str(p.get("jersey_number") or p.get("jersey") or "")

        height = str(p.get("height") or "")
        weight = str(p.get("weight") or "")
        ht_wt = f"{height}/{weight}" if height or weight else ""

        country = str(p.get("country") or "")

        table.add_row(name, team_name, position, jersey, ht_wt, country)
    console.print(table)


def format_consensus_table(consensus: list[dict]) -> None:
    """Render public betting consensus."""
    table = Table(title="Public Betting Consensus", show_lines=False)
    table.add_column("Matchup", style="cyan")
    table.add_column("Consensus Pick")
    table.add_column("Public %", justify="right")
    table.add_column("Expert Pick")
    table.add_column("Expert %", justify="right")

    for row in consensus:
        public_pct = row.get("public_pct", 0)
        pct_style = "bold" if public_pct > 65 else ("" if public_pct > 55 else "dim")

        expert_pct = row.get("expert_pct")
        expert_pct_str = f"{expert_pct:.0f}%" if expert_pct is not None else "-"

        table.add_row(
            str(row.get("matchup", "")),
            str(row.get("consensus_pick", "")),
            f"[{pct_style}]{public_pct:.0f}%[/{pct_style}]" if pct_style else f"{public_pct:.0f}%",
            str(row.get("expert_pick", "") or "-"),
            expert_pct_str,
        )
    console.print(table)
