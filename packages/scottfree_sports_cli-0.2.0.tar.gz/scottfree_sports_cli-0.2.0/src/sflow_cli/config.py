"""Config management for ~/.sfs/config.toml with optional keyring support."""

from __future__ import annotations

import logging
import os
import stat
import sys
from pathlib import Path

import tomli_w

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib

logger = logging.getLogger(__name__)

DEFAULT_API_URL = "https://sports-api.scottfreellc.com"
_KEYRING_SERVICE = "scottfree-sports-cli"


def _keyring_available() -> bool:
    """Check if the keyring package is installed and functional."""
    try:
        import keyring

        # Verify a backend is available (not the fail backend)
        backend = keyring.get_keyring()
        return "fail" not in type(backend).__name__.lower()
    except Exception:
        return False


def _keyring_set(key_name: str, value: str) -> bool:
    """Store a secret in the system keyring. Returns True on success."""
    try:
        import keyring

        keyring.set_password(_KEYRING_SERVICE, key_name, value)
        return True
    except Exception as e:
        logger.debug(f"Keyring store failed for {key_name}: {e}")
        return False


def _keyring_get(key_name: str) -> str | None:
    """Retrieve a secret from the system keyring. Returns None if not found."""
    try:
        import keyring

        return keyring.get_password(_KEYRING_SERVICE, key_name)
    except Exception:
        return None


def _keyring_delete(key_name: str) -> bool:
    """Delete a secret from the system keyring. Returns True on success."""
    try:
        import keyring

        keyring.delete_password(_KEYRING_SERVICE, key_name)
        return True
    except Exception:
        return False


class SflowConfig:
    """Read/write ~/.sfs/config.toml with optional keyring and env var overrides.

    Resolution order for API keys:
    1. Environment variables (SFS_API_KEY, etc.) — highest priority
    2. System keyring (macOS Keychain, etc.) — if keyring is available
    3. TOML config file (~/.sfs/config.toml) — lowest priority

    The TOML file is always restricted to owner-only access (chmod 600).
    """

    def __init__(self, config_dir: Path | None = None):
        self.config_dir = config_dir or Path.home() / ".sfs"
        self.config_path = self.config_dir / "config.toml"

    def _load(self) -> dict:
        if not self.config_path.exists():
            return {}
        with open(self.config_path, "rb") as f:
            return tomllib.load(f)

    def _save(self, data: dict) -> None:
        self.config_dir.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, "wb") as f:
            tomli_w.dump(data, f)
        # Restrict config file to owner read/write only
        self.config_path.chmod(stat.S_IRUSR | stat.S_IWUSR)

    def set_profile(
        self,
        name: str,
        api_key: str | None = None,
        api_url: str | None = None,
        balldontlie_api_key: str | None = None,
        use_keyring: bool = False,
    ) -> None:
        """Create or update a config profile.

        If use_keyring=True and the keyring package is available, API keys are
        stored in the system keyring (macOS Keychain, etc.) instead of the TOML
        file. The TOML file stores a sentinel value "keyring:" to indicate that
        the actual key is in the keyring.
        """
        data = self._load()
        if name not in data:
            data[name] = {}
        if api_key is not None:
            if use_keyring and _keyring_available():
                _keyring_set(f"{name}.api_key", api_key)
                data[name]["api_key"] = "keyring:"
            else:
                data[name]["api_key"] = api_key
        if api_url is not None:
            data[name]["api_url"] = api_url
        if balldontlie_api_key is not None:
            if use_keyring and _keyring_available():
                _keyring_set(f"{name}.balldontlie_api_key", balldontlie_api_key)
                data[name]["balldontlie_api_key"] = "keyring:"
            else:
                data[name]["balldontlie_api_key"] = balldontlie_api_key
        self._save(data)

    def get_profile(self, name: str) -> dict | None:
        """Get a profile by name, or None if it doesn't exist."""
        data = self._load()
        return data.get(name)

    def list_profiles(self) -> list[str]:
        """List all profile names."""
        return list(self._load().keys())

    def _resolve_key(self, profile_name: str, key_name: str) -> str | None:
        """Resolve a key from profile, checking keyring if sentinel is present."""
        profile = self.get_profile(profile_name) or {}
        value = profile.get(key_name)
        if value == "keyring:":
            return _keyring_get(f"{profile_name}.{key_name}")
        return value

    def resolve(self, env: str = "default") -> tuple[str, str]:
        """Resolve API key and URL from env vars, keyring, profile, or defaults.

        Resolution order:
        1. SFS_API_KEY / SFS_API_URL env vars (highest priority)
        2. System keyring (if TOML has "keyring:" sentinel)
        3. TOML config file profile (lowest priority)

        Returns (api_key, api_url). Exits if no API key is found.
        """
        env_key = os.environ.get("SFS_API_KEY")
        env_url = os.environ.get("SFS_API_URL")

        api_key = env_key or self._resolve_key(env, "api_key")
        profile = self.get_profile(env) or {}
        api_url = env_url or profile.get("api_url") or DEFAULT_API_URL

        if not api_key:
            from rich.console import Console

            Console(stderr=True).print(
                "[red]No API key configured.[/red]\n"
                "Run: [bold]sfs config set --api-key YOUR_KEY[/bold]\n"
                "Or set: [bold]SFS_API_KEY=YOUR_KEY[/bold]"
            )
            sys.exit(1)

        return api_key, api_url

    def resolve_balldontlie(self, env: str = "default") -> str | None:
        """Resolve BallDontLie API key from env var, keyring, profile, or return None.

        Resolution order:
        1. SFS_BALLDONTLIE_API_KEY env var (highest priority)
        2. System keyring (if TOML has "keyring:" sentinel)
        3. TOML config file profile (lowest priority)

        Returns the API key string, or None if not configured.
        """
        env_key = os.environ.get("SFS_BALLDONTLIE_API_KEY")
        if env_key:
            return env_key
        return self._resolve_key(env, "balldontlie_api_key")
