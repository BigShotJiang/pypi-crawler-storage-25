"""Tests for sfs scores and injuries CLI commands."""

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from sflow_cli.cli import app

runner = CliRunner()

GAMES_RESPONSE = {
    "data": [
        {
            "home_team": "Celtics",
            "away_team": "Lakers",
            "home_team_score": 112,
            "visitor_team_score": 105,
            "status": "Final",
        },
        {
            "home_team": "Knicks",
            "away_team": "Heat",
            "home_team_score": 98,
            "visitor_team_score": 101,
            "status": "Q3",
        },
    ]
}

INJURIES_RESPONSE = {
    "data": [
        {
            "player": "LeBron James",
            "team": "Lakers",
            "status": "Questionable",
            "description": "Left ankle soreness",
        },
        {
            "player": "Jaylen Brown",
            "team": "Celtics",
            "status": "Out",
            "description": "Hamstring strain",
        },
        {
            "player": "Jalen Brunson",
            "team": "Knicks",
            "status": "Probable",
            "description": "Knee contusion",
        },
    ]
}

PLAYERS_RESPONSE = {
    "data": [
        {
            "id": 237,
            "first_name": "Aaron",
            "last_name": "Judge",
            "position": "OF",
            "jersey_number": "99",
            "height": "6-7",
            "weight": "282",
            "country": "USA",
            "team": {"full_name": "New York Yankees"},
        },
        {
            "id": 545,
            "first_name": "Shohei",
            "last_name": "Ohtani",
            "position": "DH/P",
            "jersey_number": "17",
            "height": "6-4",
            "weight": "210",
            "country": "Japan",
            "team": {"full_name": "Los Angeles Dodgers"},
        },
    ]
}


class TestScores:
    @patch("sflow_cli.commands.scores.BallDontLieClient")
    @patch("sflow_cli.commands.scores.SflowConfig")
    def test_scores_table_output(self, mock_config_cls, mock_bdl_cls, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_BALLDONTLIE_API_KEY", "test_bdl_key")

        mock_config = MagicMock()
        mock_config.resolve_balldontlie.return_value = "test_bdl_key"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.get_games.return_value = GAMES_RESPONSE
        mock_bdl_cls.return_value = mock_client

        result = runner.invoke(app, ["scores", "scores", "nba"])
        assert result.exit_code == 0
        assert "Celtics" in result.stdout or "scores" in result.stdout.lower()

    @patch("sflow_cli.commands.scores.BallDontLieClient")
    @patch("sflow_cli.commands.scores.SflowConfig")
    def test_scores_json_output(self, mock_config_cls, mock_bdl_cls, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_BALLDONTLIE_API_KEY", "test_bdl_key")

        mock_config = MagicMock()
        mock_config.resolve_balldontlie.return_value = "test_bdl_key"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.get_games.return_value = GAMES_RESPONSE
        mock_bdl_cls.return_value = mock_client

        result = runner.invoke(app, ["scores", "scores", "nba", "-o", "json"])
        assert result.exit_code == 0
        assert '"home_team"' in result.stdout

    @patch("sflow_cli.commands.scores.BallDontLieClient")
    @patch("sflow_cli.commands.scores.SflowConfig")
    def test_scores_with_date(self, mock_config_cls, mock_bdl_cls, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_BALLDONTLIE_API_KEY", "test_bdl_key")

        mock_config = MagicMock()
        mock_config.resolve_balldontlie.return_value = "test_bdl_key"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.get_games.return_value = GAMES_RESPONSE
        mock_bdl_cls.return_value = mock_client

        result = runner.invoke(app, ["scores", "scores", "nba", "--date", "2026-03-29"])
        assert result.exit_code == 0
        mock_client.get_games.assert_called_once_with("nba", date="2026-03-29")


class TestInjuries:
    @patch("sflow_cli.commands.scores.BallDontLieClient")
    @patch("sflow_cli.commands.scores.SflowConfig")
    def test_injuries_table_output(self, mock_config_cls, mock_bdl_cls, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_BALLDONTLIE_API_KEY", "test_bdl_key")

        mock_config = MagicMock()
        mock_config.resolve_balldontlie.return_value = "test_bdl_key"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.get_injuries.return_value = INJURIES_RESPONSE
        mock_bdl_cls.return_value = mock_client

        result = runner.invoke(app, ["scores", "injuries", "nba"])
        assert result.exit_code == 0
        assert "LeBron" in result.stdout or "injury" in result.stdout.lower()

    @patch("sflow_cli.commands.scores.BallDontLieClient")
    @patch("sflow_cli.commands.scores.SflowConfig")
    def test_injuries_json_output(self, mock_config_cls, mock_bdl_cls, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_BALLDONTLIE_API_KEY", "test_bdl_key")

        mock_config = MagicMock()
        mock_config.resolve_balldontlie.return_value = "test_bdl_key"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.get_injuries.return_value = INJURIES_RESPONSE
        mock_bdl_cls.return_value = mock_client

        result = runner.invoke(app, ["scores", "injuries", "nba", "-o", "json"])
        assert result.exit_code == 0
        assert '"player"' in result.stdout

    @patch("sflow_cli.commands.scores.SflowConfig")
    def test_no_api_key_exits(self, mock_config_cls, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        # Ensure env var is not set
        monkeypatch.delenv("SFS_BALLDONTLIE_API_KEY", raising=False)

        mock_config = MagicMock()
        mock_config.resolve_balldontlie.return_value = None
        mock_config_cls.return_value = mock_config

        result = runner.invoke(app, ["scores", "scores", "nba"])
        assert result.exit_code == 1


class TestPlayers:
    @patch("sflow_cli.commands.scores.BallDontLieClient")
    @patch("sflow_cli.commands.scores.SflowConfig")
    def test_players_table_output(self, mock_config_cls, mock_bdl_cls, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_BALLDONTLIE_API_KEY", "test_bdl_key")

        mock_config = MagicMock()
        mock_config.resolve_balldontlie.return_value = "test_bdl_key"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.get_players.return_value = PLAYERS_RESPONSE
        mock_bdl_cls.return_value = mock_client

        result = runner.invoke(app, ["scores", "players", "mlb"])
        assert result.exit_code == 0
        assert "Judge" in result.stdout or "Ohtani" in result.stdout

    @patch("sflow_cli.commands.scores.BallDontLieClient")
    @patch("sflow_cli.commands.scores.SflowConfig")
    def test_players_json_output(self, mock_config_cls, mock_bdl_cls, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_BALLDONTLIE_API_KEY", "test_bdl_key")

        mock_config = MagicMock()
        mock_config.resolve_balldontlie.return_value = "test_bdl_key"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.get_players.return_value = PLAYERS_RESPONSE
        mock_bdl_cls.return_value = mock_client

        result = runner.invoke(app, ["scores", "players", "mlb", "-o", "json"])
        assert result.exit_code == 0
        assert '"first_name"' in result.stdout

    @patch("sflow_cli.commands.scores.BallDontLieClient")
    @patch("sflow_cli.commands.scores.SflowConfig")
    def test_players_with_filters(self, mock_config_cls, mock_bdl_cls, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_BALLDONTLIE_API_KEY", "test_bdl_key")

        mock_config = MagicMock()
        mock_config.resolve_balldontlie.return_value = "test_bdl_key"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.get_players.return_value = PLAYERS_RESPONSE
        mock_bdl_cls.return_value = mock_client

        result = runner.invoke(
            app,
            [
                "scores", "players", "nba",
                "--team-id", "14",
                "--search", "james",
                "--per-page", "50",
            ],
        )
        assert result.exit_code == 0
        mock_client.get_players.assert_called_once_with(
            "nba", team_id=14, search="james", per_page=50
        )
