from typer.testing import CliRunner

from sflow_cli.cli import app

runner = CliRunner()


class TestConfigSet:
    def test_set_api_key(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        result = runner.invoke(app, ["config", "set", "--api-key", "sk_test_123"])
        assert result.exit_code == 0
        assert "saved" in result.stdout.lower() or "set" in result.stdout.lower()

    def test_set_with_env_flag(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        result = runner.invoke(app, ["config", "set", "--api-key", "sk_local", "--env", "local"])
        assert result.exit_code == 0


class TestConfigShow:
    def test_show_empty_config(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        result = runner.invoke(app, ["config", "show"])
        assert result.exit_code == 0

    def test_show_with_data(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        runner.invoke(app, ["config", "set", "--api-key", "sk_test_123"])
        result = runner.invoke(app, ["config", "show"])
        assert "sk_test" in result.stdout or "***" in result.stdout


class TestConfigProfiles:
    def test_list_profiles(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        runner.invoke(app, ["config", "set", "--api-key", "sk_1", "--env", "prod"])
        runner.invoke(app, ["config", "set", "--api-key", "sk_2", "--env", "local"])
        result = runner.invoke(app, ["config", "profiles"])
        assert result.exit_code == 0
        assert "prod" in result.stdout
        assert "local" in result.stdout


class TestVersion:
    def test_version_flag(self):
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.stdout
