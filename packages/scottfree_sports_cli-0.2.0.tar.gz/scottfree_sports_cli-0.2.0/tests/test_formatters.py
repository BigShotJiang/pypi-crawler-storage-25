import csv
import io
import json

from sflow_cli.formatters import (
    format_csv,
    format_json,
    format_predictions_table,
    probability_style,
    resolve_model_type,
)  # noqa: F401 - format_predictions_table used in TestFormatPredictionsTable


class TestProbabilityStyle:
    def test_high_is_dark_green(self):
        assert "green" in probability_style(0.72)

    def test_above_50_is_green(self):
        assert "green" in probability_style(0.55)

    def test_below_50_is_red(self):
        assert "red" in probability_style(0.45)

    def test_very_low_is_dark_red(self):
        assert "red" in probability_style(0.28)


class TestResolveModelType:
    def test_spread_shorthand(self):
        assert resolve_model_type("spread") == "won_on_spread"

    def test_moneyline_shorthand(self):
        assert resolve_model_type("moneyline") == "won_on_points"

    def test_ml_shorthand(self):
        assert resolve_model_type("ml") == "won_on_points"

    def test_ou_shorthand(self):
        assert resolve_model_type("ou") == "over_under"

    def test_full_value_passes_through(self):
        assert resolve_model_type("won_on_spread") == "won_on_spread"
        assert resolve_model_type("over_under") == "over_under"


class TestFormatJson:
    def test_returns_valid_json(self):
        data = {"sport": "nba", "games": []}
        output = format_json(data)
        parsed = json.loads(output)
        assert parsed["sport"] == "nba"


class TestFormatPredictionsTable:
    def test_does_not_raise_on_valid_data(self, capsys):
        data = {
            "sport": "nba",
            "model_type": "won_on_spread",
            "predictions_date": "2026-03-21T00:00:00Z",
            "games": [
                {
                    "home_team": "rockets",
                    "away_team": "heat",
                    "home_point_spread": -2.0,
                    "predictions": {"IMPLIED": 0.50, "BLEND": 0.55, "CATB": 0.45},
                }
            ],
        }
        format_predictions_table(data)  # Should not raise
        captured = capsys.readouterr()
        assert "rockets" in captured.out.lower() or "heat" in captured.out.lower()


class TestFormatCsv:
    def test_returns_csv_with_headers(self):
        data = [
            {"name": "Lakers", "wins": 30},
            {"name": "Warriors", "wins": 25},
        ]
        output = format_csv(data)
        reader = csv.DictReader(io.StringIO(output))
        rows = list(reader)
        assert len(rows) == 2
        assert rows[0]["name"] == "Lakers"
