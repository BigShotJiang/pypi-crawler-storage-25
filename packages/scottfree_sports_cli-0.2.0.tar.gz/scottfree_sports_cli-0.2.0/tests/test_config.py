import pytest

from sflow_cli.config import SflowConfig


@pytest.fixture
def config_dir(tmp_path):
    """Use a temp directory instead of ~/.sfs."""
    return tmp_path


@pytest.fixture
def config(config_dir):
    return SflowConfig(config_dir=config_dir)


class TestConfigSetAndLoad:
    def test_set_creates_config_file(self, config, config_dir):
        config.set_profile("default", api_key="sk_test_123", api_url="http://localhost:8009")
        assert (config_dir / "config.toml").exists()

    def test_load_returns_saved_values(self, config):
        config.set_profile("default", api_key="sk_test_123", api_url="http://localhost:8009")
        profile = config.get_profile("default")
        assert profile["api_key"] == "sk_test_123"
        assert profile["api_url"] == "http://localhost:8009"

    def test_multiple_profiles(self, config):
        config.set_profile("default", api_key="sk_prod", api_url="https://api.example.com")
        config.set_profile("local", api_key="sk_local", api_url="http://localhost:8009")
        assert config.get_profile("default")["api_key"] == "sk_prod"
        assert config.get_profile("local")["api_key"] == "sk_local"

    def test_list_profiles(self, config):
        config.set_profile("default", api_key="sk_1")
        config.set_profile("staging", api_key="sk_2")
        profiles = config.list_profiles()
        assert "default" in profiles
        assert "staging" in profiles

    def test_missing_profile_returns_none(self, config):
        assert config.get_profile("nonexistent") is None


class TestConfigResolution:
    def test_env_vars_override_config_file(self, config, monkeypatch):
        config.set_profile("default", api_key="sk_file", api_url="http://file.com")
        monkeypatch.setenv("SFS_API_KEY", "sk_env")
        monkeypatch.setenv("SFS_API_URL", "http://env.com")
        api_key, api_url = config.resolve(env="default")
        assert api_key == "sk_env"
        assert api_url == "http://env.com"

    def test_profile_flag_selects_profile(self, config):
        config.set_profile("default", api_key="sk_default")
        config.set_profile("local", api_key="sk_local", api_url="http://localhost:8009")
        api_key, api_url = config.resolve(env="local")
        assert api_key == "sk_local"
        assert api_url == "http://localhost:8009"

    def test_default_profile_used_when_no_env(self, config, monkeypatch):
        monkeypatch.delenv("SFS_API_KEY", raising=False)
        monkeypatch.delenv("SFS_API_URL", raising=False)
        config.set_profile("default", api_key="sk_default", api_url="http://default.com")
        api_key, api_url = config.resolve()
        assert api_key == "sk_default"
        assert api_url == "http://default.com"

    def test_resolve_raises_when_no_config(self, config, monkeypatch):
        monkeypatch.delenv("SFS_API_KEY", raising=False)
        monkeypatch.delenv("SFS_API_URL", raising=False)
        with pytest.raises(SystemExit):
            config.resolve()


class TestConfigUpdate:
    def test_set_updates_existing_profile(self, config):
        config.set_profile("default", api_key="sk_old", api_url="http://old.com")
        config.set_profile("default", api_key="sk_new")
        profile = config.get_profile("default")
        assert profile["api_key"] == "sk_new"
        assert profile["api_url"] == "http://old.com"  # preserved
