import httpx
import pytest
import respx

from sflow_cli.helpers import get_client_from_env
from sflow_cli.mcp_server import mcp


class TestMCPToolsRegistered:
    @pytest.mark.asyncio
    async def test_tools_are_registered(self):
        """Verify all expected tools exist on the FastMCP server."""
        tools = await mcp.list_tools()
        tool_names = [t.name for t in tools]
        expected = [
            "get_predictions",
            "get_results",
            "get_summary",
            "get_odds",
            "get_ai_analysis",
            "get_sports",
            "get_account_info",
            "get_usage",
            "clear_cache",
            "invalidate_cache",
            "get_kalshi_markets",
            "get_polymarket_odds",
            "compare_market_odds",
            "get_game_weather",
            "get_live_scores",
            "get_injuries",
            "get_players",
            "get_betting_consensus",
        ]
        for name in expected:
            assert name in tool_names, f"Tool '{name}' not registered"


class TestMCPToolExecution:
    @pytest.mark.asyncio
    async def test_get_predictions_tool(self, monkeypatch, tmp_path):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_API_KEY", "sk_test")
        monkeypatch.setenv("SFS_API_URL", "http://test:8009")
        response_data = {"sport": "nba", "games": []}
        with respx.mock:
            respx.get("http://test:8009/api/v1/predictions/nba/won_on_spread").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = get_client_from_env()
            result = await client.aget_predictions("nba", "won_on_spread")
            assert result["sport"] == "nba"

    @pytest.mark.asyncio
    async def test_get_sports_tool(self, monkeypatch, tmp_path):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_API_KEY", "sk_test")
        monkeypatch.setenv("SFS_API_URL", "http://test:8009")
        response_data = {"sports": [{"code": "nba"}]}
        with respx.mock:
            respx.get("http://test:8009/api/v1/sports").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = get_client_from_env()
            result = await client.aget_sports()
            assert len(result["sports"]) == 1
