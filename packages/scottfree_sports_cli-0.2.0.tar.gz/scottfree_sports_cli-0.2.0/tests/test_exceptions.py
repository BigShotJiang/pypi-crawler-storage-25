from sflow_cli.exceptions import (
    AuthError,
    ForbiddenError,
    NotFoundError,
    SflowAPIError,
    RateLimitError,
    ServerError,
    raise_for_status,
)


class TestExceptionHierarchy:
    def test_all_exceptions_inherit_from_base(self):
        for exc_class in [AuthError, ForbiddenError, NotFoundError, RateLimitError, ServerError]:
            assert issubclass(exc_class, SflowAPIError)

    def test_exception_stores_status_and_detail(self):
        err = AuthError(401, "Invalid API key")
        assert err.status_code == 401
        assert err.detail == "Invalid API key"
        assert "401" in str(err)
        assert "Invalid API key" in str(err)


class TestRaiseForStatus:
    def test_401_raises_auth_error(self):
        try:
            raise_for_status(401, "Invalid API key")
            assert False, "Should have raised"
        except AuthError as e:
            assert e.status_code == 401

    def test_403_raises_forbidden_error(self):
        try:
            raise_for_status(403, "Premium required")
            assert False, "Should have raised"
        except ForbiddenError as e:
            assert e.status_code == 403

    def test_404_raises_not_found_error(self):
        try:
            raise_for_status(404, "Not found")
            assert False, "Should have raised"
        except NotFoundError:
            pass

    def test_429_raises_rate_limit_error(self):
        try:
            raise_for_status(429, "Rate limited")
            assert False, "Should have raised"
        except RateLimitError:
            pass

    def test_500_raises_server_error(self):
        try:
            raise_for_status(500, "Internal error")
            assert False, "Should have raised"
        except ServerError:
            pass

    def test_502_raises_server_error(self):
        try:
            raise_for_status(502, "Bad gateway")
            assert False, "Should have raised"
        except ServerError:
            pass

    def test_200_does_not_raise(self):
        raise_for_status(200, "OK")  # Should not raise
