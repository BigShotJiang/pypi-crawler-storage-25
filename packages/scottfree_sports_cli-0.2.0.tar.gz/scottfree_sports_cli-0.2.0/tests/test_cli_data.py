import httpx
import respx
from typer.testing import CliRunner

from sflow_cli.cli import app

runner = CliRunner()


def _env(tmp_path):
    return {
        "SFS_CONFIG_DIR": str(tmp_path),
        "SFS_API_KEY": "sk_test",
        "SFS_API_URL": "http://test:8009",
    }


class TestResultsGet:
    def test_results_table(self, tmp_path, monkeypatch):
        for k, v in _env(tmp_path).items():
            monkeypatch.setenv(k, v)
        data = {"sport": "nba", "results": [{"date": "2026-03-20", "away_team": "Heat"}]}
        with respx.mock:
            respx.get("http://test:8009/api/v1/results/nba/won_on_spread").mock(
                return_value=httpx.Response(200, json=data)
            )
            result = runner.invoke(app, ["results", "get", "nba", "spread"])
            assert result.exit_code == 0

    def test_results_with_limit(self, tmp_path, monkeypatch):
        for k, v in _env(tmp_path).items():
            monkeypatch.setenv(k, v)
        data = {"sport": "nba", "results": []}
        with respx.mock:
            route = respx.get("http://test:8009/api/v1/results/nba/won_on_spread").mock(
                return_value=httpx.Response(200, json=data)
            )
            runner.invoke(app, ["results", "get", "nba", "spread", "--limit", "25"])
            assert route.calls[0].request.url.params["limit"] == "25"


class TestSummaryGet:
    def test_summary_table(self, tmp_path, monkeypatch):
        for k, v in _env(tmp_path).items():
            monkeypatch.setenv(k, v)
        data = {"sport": "nba", "summaries": [{"model": "BLEND", "win %": 55.0}]}
        with respx.mock:
            respx.get("http://test:8009/api/v1/summary/nba/won_on_spread").mock(
                return_value=httpx.Response(200, json=data)
            )
            result = runner.invoke(app, ["summary", "get", "nba", "spread"])
            assert result.exit_code == 0


class TestOddsGet:
    def test_odds_table(self, tmp_path, monkeypatch):
        for k, v in _env(tmp_path).items():
            monkeypatch.setenv(k, v)
        data = {"sport": "nba", "games": [{"home_team": "Lakers", "away_team": "Warriors"}]}
        with respx.mock:
            respx.get("http://test:8009/api/v1/odds/nba").mock(
                return_value=httpx.Response(200, json=data)
            )
            result = runner.invoke(app, ["odds", "get", "nba"])
            assert result.exit_code == 0


class TestAnalysisGet:
    def test_analysis_table(self, tmp_path, monkeypatch):
        for k, v in _env(tmp_path).items():
            monkeypatch.setenv(k, v)
        data = {
            "sport": "nba",
            "analyses": [
                {
                    "game_id": "test",
                    "away_team": "Heat",
                    "home_team": "Rockets",
                    "recommendation": "bet",
                    "risk_level": "medium",
                    "ai_analysis": {"narrative": "Test narrative", "key_insights": ["Insight 1"]},
                }
            ],
        }
        with respx.mock:
            respx.get("http://test:8009/api/v1/ai-analysis/nba/won_on_spread").mock(
                return_value=httpx.Response(200, json=data)
            )
            result = runner.invoke(app, ["analysis", "get", "nba", "spread"])
            assert result.exit_code == 0
