import pytest


@pytest.fixture
def api_key():
    return "sk_test_key_123"


@pytest.fixture
def api_url():
    return "http://localhost:8009"
