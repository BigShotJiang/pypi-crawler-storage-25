"""Tests for the Covers.com consensus scraping client."""

from unittest.mock import patch

import httpx
import respx

from sflow_cli.consensus import COVERS_SPORTS, CoversClient

_COVERS_BASE = "https://contests.covers.com/consensus"

# ---------------------------------------------------------------------------
# Sample HTML fixtures
# ---------------------------------------------------------------------------

# Representative HTML that matches the regex patterns in consensus.py.
# Includes two games with matchupColumn cells, team blocks, and high/low percentages.
# Expert data is not available on the top consensus page, so expert_pick/expert_pct are always None.
SAMPLE_CONSENSUS_HTML = """
<html>
<body>
  <table>
    <tr>
      <td class="covers-CoversConsensus-table--matchupColumn">
        <span class="covers-CoversConsensus-table--teamBlock">
          <img alt="Boston Celtics Picks" class="covers-CoversConsensus-mainLogo" src="">
        </span>
        <span class="covers-CoversConsensus-table--teamBlock2">
          <img alt="Charlotte Hornets Picks" class="covers-CoversConsensus-mainLogo" src="">
        </span>
        <span class="covers-CoversConsensus-consensusTable--high"><span>64%</span></span>
        <br />
        <span class="covers-CoversConsensus-consensusTable--low"><span>36%</span></span>
      </td>
    </tr>
    <tr>
      <td class="covers-CoversConsensus-table--matchupColumn">
        <span class="covers-CoversConsensus-table--teamBlock">
          <img alt="Los Angeles Lakers Picks" class="covers-CoversConsensus-mainLogo" src="">
        </span>
        <span class="covers-CoversConsensus-table--teamBlock2">
          <img alt="Denver Nuggets Picks" class="covers-CoversConsensus-mainLogo" src="">
        </span>
        <span class="covers-CoversConsensus-consensusTable--high"><span>72%</span></span>
        <br />
        <span class="covers-CoversConsensus-consensusTable--low"><span>28%</span></span>
      </td>
    </tr>
  </table>
</body>
</html>
"""

# HTML that has no consensus rows
EMPTY_CONSENSUS_HTML = """
<html><body><div class="covers-CoversConsensusMain"></div></body></html>
"""

# Completely malformed HTML
MALFORMED_HTML = "<<< not valid >>> html ??? %^&"


# ---------------------------------------------------------------------------
# Parsing tests (no network)
# ---------------------------------------------------------------------------


class TestCoversClientParsing:
    def test_parse_consensus_html_with_data(self):
        client = CoversClient()
        results = client._parse_consensus_html(SAMPLE_CONSENSUS_HTML)
        assert len(results) == 2

        first = results[0]
        assert first["matchup"] == "Boston Celtics vs Charlotte Hornets"
        assert first["consensus_pick"] == "Boston Celtics"
        assert first["public_pct"] == 64.0
        assert first["expert_pick"] is None
        assert first["expert_pct"] is None

        second = results[1]
        assert second["matchup"] == "Los Angeles Lakers vs Denver Nuggets"
        assert second["consensus_pick"] == "Los Angeles Lakers"
        assert second["public_pct"] == 72.0
        assert second["expert_pick"] is None
        assert second["expert_pct"] is None

    def test_parse_consensus_html_result_keys(self):
        client = CoversClient()
        results = client._parse_consensus_html(SAMPLE_CONSENSUS_HTML)
        assert len(results) > 0
        expected_keys = {"matchup", "consensus_pick", "public_pct", "expert_pick", "expert_pct"}
        for item in results:
            assert set(item.keys()) == expected_keys

    def test_parse_consensus_html_public_pct_is_float(self):
        client = CoversClient()
        results = client._parse_consensus_html(SAMPLE_CONSENSUS_HTML)
        for item in results:
            assert isinstance(item["public_pct"], float)

    def test_parse_consensus_html_empty_html(self):
        client = CoversClient()
        results = client._parse_consensus_html("")
        assert results == []

    def test_parse_consensus_html_empty_page(self):
        client = CoversClient()
        results = client._parse_consensus_html(EMPTY_CONSENSUS_HTML)
        assert results == []

    def test_parse_consensus_html_malformed(self):
        client = CoversClient()
        # Must not raise — returns empty list
        results = client._parse_consensus_html(MALFORMED_HTML)
        assert isinstance(results, list)

    def test_parse_consensus_html_none_equivalent(self):
        """Parser gracefully handles edge cases without raising."""
        client = CoversClient()
        # Single matchupColumn missing the percentage spans — should be skipped
        incomplete_html = """
        <td class="covers-CoversConsensus-table--matchupColumn">
          <span class="covers-CoversConsensus-table--teamBlock">
            <img alt="Team A Picks" class="covers-CoversConsensus-mainLogo" src="">
          </span>
          <span class="covers-CoversConsensus-table--teamBlock2">
            <img alt="Team B Picks" class="covers-CoversConsensus-mainLogo" src="">
          </span>
        </td>
        """
        results = client._parse_consensus_html(incomplete_html)
        assert results == []

    def test_parse_consensus_html_expert_pick_always_none(self):
        """Expert picks are always None on the top consensus page."""
        client = CoversClient()
        results = client._parse_consensus_html(SAMPLE_CONSENSUS_HTML)
        # All results should have expert_pick=None and expert_pct=None
        for item in results:
            assert item["expert_pick"] is None
            assert item["expert_pct"] is None


# ---------------------------------------------------------------------------
# Sync HTTP tests
# ---------------------------------------------------------------------------


class TestCoversClientSync:
    def test_get_consensus_returns_parsed_data(self):
        with respx.mock:
            respx.get(f"{_COVERS_BASE}/topconsensus/nba/overall").mock(
                return_value=httpx.Response(200, text=SAMPLE_CONSENSUS_HTML)
            )
            client = CoversClient()
            result = client.get_consensus("nba")
            assert isinstance(result, list)
            assert len(result) == 2
            assert result[0]["matchup"] == "Boston Celtics vs Charlotte Hornets"
            assert result[0]["consensus_pick"] == "Boston Celtics"
            assert result[0]["public_pct"] == 64.0

    def test_get_consensus_nfl(self):
        with respx.mock:
            respx.get(f"{_COVERS_BASE}/topconsensus/nfl/overall").mock(
                return_value=httpx.Response(200, text=SAMPLE_CONSENSUS_HTML)
            )
            client = CoversClient()
            result = client.get_consensus("nfl")
            assert isinstance(result, list)
            assert len(result) > 0

    def test_get_consensus_empty_page(self):
        with respx.mock:
            respx.get(f"{_COVERS_BASE}/topconsensus/nba/overall").mock(
                return_value=httpx.Response(200, text=EMPTY_CONSENSUS_HTML)
            )
            client = CoversClient()
            result = client.get_consensus("nba")
            assert result == []

    def test_get_consensus_404_returns_empty_list(self):
        with respx.mock:
            respx.get(f"{_COVERS_BASE}/topconsensus/nba/overall").mock(
                return_value=httpx.Response(404, text="Not found")
            )
            client = CoversClient()
            result = client.get_consensus("nba")
            assert result == []

    def test_get_consensus_500_returns_empty_list(self):
        with respx.mock:
            respx.get(f"{_COVERS_BASE}/topconsensus/nba/overall").mock(
                return_value=httpx.Response(500, text="Server error")
            )
            client = CoversClient()
            result = client.get_consensus("nba")
            assert result == []

    def test_get_consensus_unknown_sport_returns_empty_list(self):
        client = CoversClient()
        # No HTTP call should be made for an unknown sport
        result = client.get_consensus("cricket")
        assert result == []

    def test_get_consensus_result_shape(self):
        with respx.mock:
            respx.get(f"{_COVERS_BASE}/topconsensus/nba/overall").mock(
                return_value=httpx.Response(200, text=SAMPLE_CONSENSUS_HTML)
            )
            client = CoversClient()
            result = client.get_consensus("nba")
            for item in result:
                assert "matchup" in item
                assert "consensus_pick" in item
                assert "public_pct" in item
                assert "expert_pick" in item
                assert "expert_pct" in item

    def test_no_auth_headers_sent(self):
        with respx.mock:
            route = respx.get(f"{_COVERS_BASE}/topconsensus/nba/overall").mock(
                return_value=httpx.Response(200, text=SAMPLE_CONSENSUS_HTML)
            )
            client = CoversClient()
            client.get_consensus("nba")
            assert "X-API-Key" not in route.calls[0].request.headers
            assert "Authorization" not in route.calls[0].request.headers

    def test_custom_base_url(self):
        custom_base = "http://localhost:9999/consensus"
        with respx.mock:
            respx.get(f"{custom_base}/topconsensus/nba/overall").mock(
                return_value=httpx.Response(200, text=SAMPLE_CONSENSUS_HTML)
            )
            client = CoversClient(base_url=custom_base)
            result = client.get_consensus("nba")
            assert isinstance(result, list)
            assert len(result) > 0

    def test_all_sports_in_covers_sports_map(self):
        for sport in ("nba", "nfl", "mlb", "nhl", "ncaab", "ncaaf"):
            assert sport in COVERS_SPORTS

    @patch("sflow_cli.consensus.time.sleep")
    def test_retries_on_503_then_succeeds(self, mock_sleep):
        with respx.mock:
            route = respx.get(f"{_COVERS_BASE}/topconsensus/nba/overall").mock(
                side_effect=[
                    httpx.Response(503),
                    httpx.Response(200, text=SAMPLE_CONSENSUS_HTML),
                ]
            )
            client = CoversClient()
            result = client.get_consensus("nba")
            assert isinstance(result, list)
            assert len(result) > 0
            assert route.call_count == 2
            mock_sleep.assert_called_once()

    @patch("sflow_cli.consensus.time.sleep")
    def test_exhausted_retries_returns_empty_list(self, mock_sleep):
        with respx.mock:
            respx.get(f"{_COVERS_BASE}/topconsensus/nba/overall").mock(
                side_effect=[
                    httpx.Response(503),
                    httpx.Response(503),
                    httpx.Response(503),
                ]
            )
            client = CoversClient()
            result = client.get_consensus("nba")
            assert result == []


# ---------------------------------------------------------------------------
# Async HTTP tests
# ---------------------------------------------------------------------------


class TestCoversClientAsync:
    async def test_aget_consensus_returns_parsed_data(self):
        with respx.mock:
            respx.get(f"{_COVERS_BASE}/topconsensus/nba/overall").mock(
                return_value=httpx.Response(200, text=SAMPLE_CONSENSUS_HTML)
            )
            client = CoversClient()
            result = await client.aget_consensus("nba")
            assert isinstance(result, list)
            assert len(result) == 2
            assert result[0]["matchup"] == "Boston Celtics vs Charlotte Hornets"
            assert result[0]["consensus_pick"] == "Boston Celtics"
            assert result[0]["public_pct"] == 64.0

    async def test_aget_consensus_nfl(self):
        with respx.mock:
            respx.get(f"{_COVERS_BASE}/topconsensus/nfl/overall").mock(
                return_value=httpx.Response(200, text=SAMPLE_CONSENSUS_HTML)
            )
            client = CoversClient()
            result = await client.aget_consensus("nfl")
            assert isinstance(result, list)
            assert len(result) > 0

    async def test_aget_consensus_404_returns_empty_list(self):
        with respx.mock:
            respx.get(f"{_COVERS_BASE}/topconsensus/nba/overall").mock(
                return_value=httpx.Response(404, text="Not found")
            )
            client = CoversClient()
            result = await client.aget_consensus("nba")
            assert result == []

    async def test_aget_consensus_unknown_sport_returns_empty_list(self):
        client = CoversClient()
        result = await client.aget_consensus("soccer")
        assert result == []

    async def test_aget_consensus_result_shape(self):
        with respx.mock:
            respx.get(f"{_COVERS_BASE}/topconsensus/nba/overall").mock(
                return_value=httpx.Response(200, text=SAMPLE_CONSENSUS_HTML)
            )
            client = CoversClient()
            result = await client.aget_consensus("nba")
            for item in result:
                assert "matchup" in item
                assert "consensus_pick" in item
                assert "public_pct" in item
                assert "expert_pick" in item
                assert "expert_pct" in item

    @patch("sflow_cli.consensus.asyncio.sleep")
    async def test_async_retries_on_502(self, mock_sleep):
        with respx.mock:
            route = respx.get(f"{_COVERS_BASE}/topconsensus/nba/overall").mock(
                side_effect=[
                    httpx.Response(502),
                    httpx.Response(200, text=SAMPLE_CONSENSUS_HTML),
                ]
            )
            client = CoversClient()
            result = await client.aget_consensus("nba")
            assert isinstance(result, list)
            assert len(result) > 0
            assert route.call_count == 2
