"""Tests for BallDontLieClient (sync + async)."""

import httpx
import pytest
import respx

from sflow_cli.exceptions import AuthError
from sflow_cli.live_data import BallDontLieClient

_BDL_BASE = "https://api.balldontlie.io/v1"
_TEST_KEY = "bdl_test_api_key_123"


class TestBallDontLieClientSync:
    def test_get_games(self):
        response_data = {"data": [{"id": 1, "home_team": {"name": "Lakers"}}], "meta": {}}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/games").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            result = client.get_games("nba")
            assert result["data"][0]["home_team"]["name"] == "Lakers"
            assert "nba" in str(route.calls[0].request.url)

    def test_get_games_with_date(self):
        response_data = {"data": [], "meta": {}}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/games").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            client.get_games("nba", date="2026-03-29")
            assert route.calls[0].request.url.params["dates[]"] == "2026-03-29"

    def test_get_games_no_date_param_when_not_given(self):
        response_data = {"data": [], "meta": {}}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/games").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            client.get_games("nba")
            assert "dates[]" not in route.calls[0].request.url.params

    def test_get_injuries(self):
        response_data = {"data": [{"player": {"first_name": "LeBron"}, "status": "OUT"}]}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/injuries").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            result = client.get_injuries("nba")
            assert result["data"][0]["status"] == "OUT"
            assert "nba" in str(route.calls[0].request.url)

    def test_get_teams(self):
        response_data = {"data": [{"id": 14, "name": "Lakers", "city": "Los Angeles"}]}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/teams").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            result = client.get_teams("nba")
            assert result["data"][0]["name"] == "Lakers"
            assert "nba" in str(route.calls[0].request.url)

    def test_get_team_stats(self):
        response_data = {"data": [{"team_id": 14, "pts": 115.2, "reb": 44.1}]}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/season_averages").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            result = client.get_team_stats("nba", team_id=14)
            assert result["data"][0]["pts"] == 115.2
            assert route.calls[0].request.url.params["team_ids[]"] == "14"
            assert "season" not in route.calls[0].request.url.params

    def test_get_team_stats_with_season(self):
        response_data = {"data": [{"team_id": 14, "pts": 112.0}]}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/season_averages").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            client.get_team_stats("nba", team_id=14, season=2025)
            assert route.calls[0].request.url.params["team_ids[]"] == "14"
            assert route.calls[0].request.url.params["season"] == "2025"

    def test_auth_header_sent(self):
        response_data = {"data": [], "meta": {}}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/games").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            client.get_games("nba")
            assert route.calls[0].request.headers["authorization"] == f"Bearer {_TEST_KEY}"

    def test_error_handling_401(self):
        with respx.mock:
            respx.get(f"{_BDL_BASE}/nba/games").mock(
                return_value=httpx.Response(401, json={"message": "Unauthorized"})
            )
            client = BallDontLieClient(api_key="bad_key")
            with pytest.raises(AuthError) as exc_info:
                client.get_games("nba")
            assert exc_info.value.status_code == 401

    def test_get_games_nfl_sport_routing(self):
        response_data = {"data": [], "meta": {}}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nfl/games").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            client.get_games("nfl")
            assert "nfl" in str(route.calls[0].request.url)

    def test_get_games_mlb_sport_routing(self):
        response_data = {"data": [], "meta": {}}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/mlb/games").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            client.get_games("mlb")
            assert "mlb" in str(route.calls[0].request.url)

    def test_get_players_default_params(self):
        response_data = {
            "data": [
                {
                    "id": 1,
                    "first_name": "LeBron",
                    "last_name": "James",
                    "position": "F",
                    "team": {"full_name": "Los Angeles Lakers"},
                }
            ],
            "meta": {},
        }
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/players").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            result = client.get_players("nba")
            assert result["data"][0]["last_name"] == "James"
            assert route.calls[0].request.url.params["per_page"] == "25"
            assert "team_ids[]" not in route.calls[0].request.url.params
            assert "search" not in route.calls[0].request.url.params
            assert "cursor" not in route.calls[0].request.url.params

    def test_get_players_with_team_filter(self):
        response_data = {"data": [], "meta": {}}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/players").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            client.get_players("nba", team_id=14, per_page=100)
            assert route.calls[0].request.url.params["team_ids[]"] == "14"
            assert route.calls[0].request.url.params["per_page"] == "100"

    def test_get_players_with_search(self):
        response_data = {"data": [], "meta": {}}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/mlb/players").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            client.get_players("mlb", search="judge")
            assert route.calls[0].request.url.params["search"] == "judge"

    def test_get_players_with_cursor(self):
        response_data = {"data": [], "meta": {"next_cursor": 100}}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nfl/players").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            client.get_players("nfl", cursor=50)
            assert route.calls[0].request.url.params["cursor"] == "50"


class TestBallDontLieClientAsync:
    async def test_aget_games(self):
        response_data = {"data": [{"id": 99, "home_team": {"name": "Warriors"}}], "meta": {}}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/games").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            result = await client.aget_games("nba")
            assert result["data"][0]["home_team"]["name"] == "Warriors"
            assert "nba" in str(route.calls[0].request.url)

    async def test_aget_games_with_date(self):
        response_data = {"data": [], "meta": {}}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/games").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            await client.aget_games("nba", date="2026-03-29")
            assert route.calls[0].request.url.params["dates[]"] == "2026-03-29"

    async def test_aget_injuries(self):
        response_data = {"data": [{"player": {"first_name": "Stephen"}, "status": "QUESTIONABLE"}]}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/injuries").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            result = await client.aget_injuries("nba")
            assert result["data"][0]["status"] == "QUESTIONABLE"
            assert "nba/injuries" in str(route.calls[0].request.url)

    async def test_aget_auth_header_sent(self):
        response_data = {"data": [], "meta": {}}
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/nba/teams").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            await client.aget_teams("nba")
            assert route.calls[0].request.headers["authorization"] == f"Bearer {_TEST_KEY}"

    async def test_aget_players(self):
        response_data = {
            "data": [{"id": 237, "first_name": "Aaron", "last_name": "Judge"}],
            "meta": {},
        }
        with respx.mock:
            route = respx.get(f"{_BDL_BASE}/mlb/players").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = BallDontLieClient(api_key=_TEST_KEY)
            result = await client.aget_players("mlb", search="judge")
            assert result["data"][0]["last_name"] == "Judge"
            assert route.calls[0].request.url.params["search"] == "judge"
            assert route.calls[0].request.url.params["per_page"] == "25"
