from unittest.mock import patch

import httpx
import pytest
import respx

from sflow_cli.exceptions import SflowAPIError
from sflow_cli.markets import KalshiClient, PolymarketClient

_KALSHI_BASE = "https://api.elections.kalshi.com/trade-api/v2"
_GAMMA_BASE = "https://gamma-api.polymarket.com"
_CLOB_BASE = "https://clob.polymarket.com"


class TestKalshiClientSync:
    def test_get_markets(self):
        response_data = {"markets": [{"ticker": "NBA_GAME_2026-03-29_LAL_GSW"}], "cursor": ""}
        with respx.mock:
            route = respx.get(f"{_KALSHI_BASE}/markets").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = KalshiClient()
            result = client.get_markets("nba")
            assert result["markets"][0]["ticker"] == "NBA_GAME_2026-03-29_LAL_GSW"
            assert route.calls[0].request.url.params["series_ticker"] == "NBA_GAME"
            assert route.calls[0].request.url.params["status"] == "open"
            assert route.calls[0].request.url.params["limit"] == "100"

    def test_get_markets_custom_limit(self):
        response_data = {"markets": [], "cursor": ""}
        with respx.mock:
            route = respx.get(f"{_KALSHI_BASE}/markets").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = KalshiClient()
            client.get_markets("nfl", limit=25)
            assert route.calls[0].request.url.params["series_ticker"] == "NFL_GAME"
            assert route.calls[0].request.url.params["limit"] == "25"

    def test_get_markets_mlb(self):
        response_data = {"markets": [], "cursor": ""}
        with respx.mock:
            route = respx.get(f"{_KALSHI_BASE}/markets").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = KalshiClient()
            client.get_markets("mlb")
            assert route.calls[0].request.url.params["series_ticker"] == "MLB_GAME"

    def test_get_orderbook(self):
        response_data = {"orderbook": {"yes": [[65, 100]], "no": [[35, 200]]}}
        with respx.mock:
            route = respx.get(f"{_KALSHI_BASE}/markets/NBA_GAME_2026-03-29_LAL_GSW/orderbook").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = KalshiClient()
            result = client.get_orderbook("NBA_GAME_2026-03-29_LAL_GSW")
            assert "orderbook" in result
            assert route.calls[0].request.url.params["depth"] == "5"

    def test_get_orderbook_custom_depth(self):
        response_data = {"orderbook": {"yes": [], "no": []}}
        with respx.mock:
            route = respx.get(f"{_KALSHI_BASE}/markets/SOME_TICKER/orderbook").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = KalshiClient()
            client.get_orderbook("SOME_TICKER", depth=10)
            assert route.calls[0].request.url.params["depth"] == "10"

    def test_get_events(self):
        response_data = {"events": [{"event_ticker": "NBA_GAME_2026-03-29"}], "cursor": ""}
        with respx.mock:
            route = respx.get(f"{_KALSHI_BASE}/events").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = KalshiClient()
            result = client.get_events("nba")
            assert len(result["events"]) == 1
            assert route.calls[0].request.url.params["series_ticker"] == "NBA_GAME"
            assert route.calls[0].request.url.params["limit"] == "100"

    def test_get_events_ncaab(self):
        response_data = {"events": [], "cursor": ""}
        with respx.mock:
            route = respx.get(f"{_KALSHI_BASE}/events").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = KalshiClient()
            client.get_events("ncaab")
            assert route.calls[0].request.url.params["series_ticker"] == "NCAAB"

    def test_error_handling_500(self):
        with respx.mock:
            respx.get(f"{_KALSHI_BASE}/markets").mock(
                return_value=httpx.Response(500, json={"message": "Internal server error"})
            )
            client = KalshiClient()
            with pytest.raises(SflowAPIError) as exc_info:
                client.get_markets("nba")
            assert exc_info.value.status_code == 500

    def test_error_handling_404(self):
        with respx.mock:
            respx.get(f"{_KALSHI_BASE}/markets/UNKNOWN/orderbook").mock(
                return_value=httpx.Response(404, json={"message": "Market not found"})
            )
            client = KalshiClient()
            with pytest.raises(SflowAPIError) as exc_info:
                client.get_orderbook("UNKNOWN")
            assert exc_info.value.status_code == 404

    def test_no_auth_headers_sent(self):
        with respx.mock:
            route = respx.get(f"{_KALSHI_BASE}/markets").mock(
                return_value=httpx.Response(200, json={"markets": [], "cursor": ""})
            )
            client = KalshiClient()
            client.get_markets("nba")
            assert "X-API-Key" not in route.calls[0].request.headers
            assert "Authorization" not in route.calls[0].request.headers

    def test_sport_key_error_on_unknown_sport(self):
        client = KalshiClient()
        with pytest.raises(KeyError):
            # invalid sport is not in KALSHI_SPORTS — KeyError should propagate
            with respx.mock:
                client.get_markets("cricket")

    def test_custom_base_url(self):
        custom_base = "http://localhost:9999"
        response_data = {"markets": [], "cursor": ""}
        with respx.mock:
            respx.get(f"{custom_base}/markets").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = KalshiClient(base_url=custom_base)
            result = client.get_markets("nba")
            assert result == response_data


class TestKalshiClientAsync:
    async def test_aget_markets(self):
        response_data = {"markets": [{"ticker": "NBA_GAME_2026-03-29_LAL_GSW"}], "cursor": ""}
        with respx.mock:
            route = respx.get(f"{_KALSHI_BASE}/markets").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = KalshiClient()
            result = await client.aget_markets("nba")
            assert result["markets"][0]["ticker"] == "NBA_GAME_2026-03-29_LAL_GSW"
            assert route.calls[0].request.url.params["series_ticker"] == "NBA_GAME"

    async def test_aget_orderbook(self):
        response_data = {"orderbook": {"yes": [[65, 100]], "no": [[35, 200]]}}
        with respx.mock:
            route = respx.get(f"{_KALSHI_BASE}/markets/NBA_TICKER/orderbook").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = KalshiClient()
            result = await client.aget_orderbook("NBA_TICKER")
            assert "orderbook" in result
            assert route.calls[0].request.url.params["depth"] == "5"

    async def test_aget_events(self):
        response_data = {"events": [{"event_ticker": "NFL_GAME_2026-09-10"}], "cursor": ""}
        with respx.mock:
            route = respx.get(f"{_KALSHI_BASE}/events").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = KalshiClient()
            result = await client.aget_events("nfl")
            assert len(result["events"]) == 1
            assert route.calls[0].request.url.params["series_ticker"] == "NFL_GAME"


class TestPolymarketClientSync:
    def test_get_sports(self):
        response_data = {"sports": ["NBA", "NFL", "MLB"]}
        with respx.mock:
            respx.get(f"{_GAMMA_BASE}/sports").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = PolymarketClient()
            result = client.get_sports()
            assert "sports" in result
            assert "NBA" in result["sports"]

    def test_get_events(self):
        response_data = [{"id": "abc123", "title": "NBA game"}]
        with respx.mock:
            route = respx.get(f"{_GAMMA_BASE}/events").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = PolymarketClient()
            result = client.get_events("nba")
            assert len(result) == 1
            assert route.calls[0].request.url.params["tag_id"] == "745"
            assert route.calls[0].request.url.params["active"] == "true"
            assert route.calls[0].request.url.params["closed"] == "false"
            assert route.calls[0].request.url.params["limit"] == "50"

    def test_get_events_custom_limit(self):
        response_data = []
        with respx.mock:
            route = respx.get(f"{_GAMMA_BASE}/events").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = PolymarketClient()
            client.get_events("nfl", limit=20)
            assert route.calls[0].request.url.params["tag_id"] == "450"
            assert route.calls[0].request.url.params["limit"] == "20"

    def test_get_orderbook(self):
        response_data = {
            "market": "0xabc",
            "asset_id": "token123",
            "bids": [{"price": "0.65", "size": "100"}],
            "asks": [{"price": "0.66", "size": "200"}],
        }
        with respx.mock:
            route = respx.get(f"{_CLOB_BASE}/book").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = PolymarketClient()
            result = client.get_orderbook("token123")
            assert "bids" in result
            assert route.calls[0].request.url.params["token_id"] == "token123"

    def test_get_midpoint_returns_string(self):
        with respx.mock:
            respx.get(f"{_CLOB_BASE}/midpoint").mock(return_value=httpx.Response(200, text="0.55"))
            client = PolymarketClient()
            result = client.get_midpoint("token123")
            assert result == "0.55"
            assert isinstance(result, str)

    def test_get_midpoint_checks_token_id_param(self):
        with respx.mock:
            route = respx.get(f"{_CLOB_BASE}/midpoint").mock(
                return_value=httpx.Response(200, text="0.72")
            )
            client = PolymarketClient()
            client.get_midpoint("token_abc_xyz")
            assert route.calls[0].request.url.params["token_id"] == "token_abc_xyz"

    def test_get_events_uses_gamma_url(self):
        """Events endpoint goes to Gamma API, not CLOB API."""
        response_data = {"events": []}
        with respx.mock:
            gamma_route = respx.get(f"{_GAMMA_BASE}/events").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            # CLOB route should NOT be called
            clob_route = respx.get(f"{_CLOB_BASE}/events").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = PolymarketClient()
            client.get_events("NBA")
            assert gamma_route.called
            assert not clob_route.called

    def test_get_orderbook_uses_clob_url(self):
        """Orderbook endpoint goes to CLOB API, not Gamma API."""
        response_data = {"bids": [], "asks": []}
        with respx.mock:
            clob_route = respx.get(f"{_CLOB_BASE}/book").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            gamma_route = respx.get(f"{_GAMMA_BASE}/book").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = PolymarketClient()
            client.get_orderbook("token123")
            assert clob_route.called
            assert not gamma_route.called

    def test_error_handling_500(self):
        with respx.mock:
            respx.get(f"{_GAMMA_BASE}/sports").mock(
                return_value=httpx.Response(500, json={"detail": "Internal server error"})
            )
            client = PolymarketClient()
            with pytest.raises(SflowAPIError) as exc_info:
                client.get_sports()
            assert exc_info.value.status_code == 500

    def test_midpoint_error_handling(self):
        with respx.mock:
            respx.get(f"{_CLOB_BASE}/midpoint").mock(
                return_value=httpx.Response(404, text="Market not found")
            )
            client = PolymarketClient()
            with pytest.raises(SflowAPIError) as exc_info:
                client.get_midpoint("bad_token")
            assert exc_info.value.status_code == 404

    def test_no_auth_headers_sent(self):
        with respx.mock:
            route = respx.get(f"{_GAMMA_BASE}/sports").mock(
                return_value=httpx.Response(200, json={"sports": []})
            )
            client = PolymarketClient()
            client.get_sports()
            assert "X-API-Key" not in route.calls[0].request.headers
            assert "Authorization" not in route.calls[0].request.headers

    def test_custom_base_urls(self):
        custom_gamma = "http://localhost:7001"
        custom_clob = "http://localhost:7002"
        response_data = {"sports": ["NBA"]}
        with respx.mock:
            respx.get(f"{custom_gamma}/sports").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = PolymarketClient(gamma_url=custom_gamma, clob_url=custom_clob)
            result = client.get_sports()
            assert result["sports"] == ["NBA"]


class TestPolymarketClientAsync:
    async def test_aget_sports(self):
        response_data = {"sports": ["NBA", "NFL"]}
        with respx.mock:
            respx.get(f"{_GAMMA_BASE}/sports").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = PolymarketClient()
            result = await client.aget_sports()
            assert "sports" in result
            assert "NBA" in result["sports"]

    async def test_aget_events(self):
        response_data = [{"id": "xyz", "title": "NBA Finals"}]
        with respx.mock:
            route = respx.get(f"{_GAMMA_BASE}/events").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = PolymarketClient()
            result = await client.aget_events("nba")
            assert len(result) == 1
            assert route.calls[0].request.url.params["tag_id"] == "745"

    async def test_aget_orderbook(self):
        response_data = {"bids": [{"price": "0.65", "size": "100"}], "asks": []}
        with respx.mock:
            route = respx.get(f"{_CLOB_BASE}/book").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = PolymarketClient()
            result = await client.aget_orderbook("token_async")
            assert "bids" in result
            assert route.calls[0].request.url.params["token_id"] == "token_async"

    async def test_aget_midpoint_returns_string(self):
        with respx.mock:
            route = respx.get(f"{_CLOB_BASE}/midpoint").mock(
                return_value=httpx.Response(200, text="0.63")
            )
            client = PolymarketClient()
            result = await client.aget_midpoint("token_async")
            assert result == "0.63"
            assert isinstance(result, str)
            assert route.calls[0].request.url.params["token_id"] == "token_async"


class TestRetryBehavior:
    @patch("sflow_cli.markets.time.sleep")
    def test_kalshi_retries_on_503_then_succeeds(self, mock_sleep):
        response_data = {"markets": [], "cursor": ""}
        with respx.mock:
            route = respx.get(f"{_KALSHI_BASE}/markets").mock(
                side_effect=[
                    httpx.Response(503),
                    httpx.Response(200, json=response_data),
                ]
            )
            client = KalshiClient()
            result = client.get_markets("nba")
            assert result == response_data
            assert route.call_count == 2
            mock_sleep.assert_called_once()

    @patch("sflow_cli.markets.asyncio.sleep")
    async def test_kalshi_async_retries_on_502(self, mock_sleep):
        response_data = {"markets": [], "cursor": ""}
        with respx.mock:
            route = respx.get(f"{_KALSHI_BASE}/markets").mock(
                side_effect=[
                    httpx.Response(502),
                    httpx.Response(200, json=response_data),
                ]
            )
            client = KalshiClient()
            result = await client.aget_markets("nba")
            assert result == response_data
            assert route.call_count == 2
