import httpx
import respx
from typer.testing import CliRunner

from sflow_cli.cli import app

runner = CliRunner()

PREDICTIONS_RESPONSE = {
    "sport": "nba",
    "model_type": "won_on_spread",
    "predictions_date": "2026-03-21T00:00:00Z",
    "games": [
        {
            "date": "2026-03-21",
            "home_team": "rockets",
            "away_team": "heat",
            "home_point_spread": -2.0,
            "predictions": {
                "IMPLIED": 0.50,
                "AI": 0.48,
                "BLEND": 0.492,
                "CATB": 0.466,
                "RF": 0.511,
                "LGB": 0.558,
                "LOGR": 0.464,
                "XGB": 0.411,
                "XT": 0.542,
            },
        }
    ],
    "models_used": ["IMPLIED", "AI", "BLEND", "CATB", "RF", "LGB", "LOGR", "XGB", "XT"],
}

SPORTS_RESPONSE = {
    "sports": [
        {"code": "nba", "name": "National Basketball Association"},
        {"code": "nhl", "name": "National Hockey League"},
    ],
    "model_types": [
        {"code": "over_under", "name": "Over/Under"},
        {"code": "won_on_spread", "name": "Point Spread"},
    ],
}


class TestPredictionsGet:
    def test_predictions_table_output(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_API_KEY", "sk_test")
        monkeypatch.setenv("SFS_API_URL", "http://test:8009")
        with respx.mock:
            respx.get("http://test:8009/api/v1/predictions/nba/won_on_spread").mock(
                return_value=httpx.Response(200, json=PREDICTIONS_RESPONSE)
            )
            result = runner.invoke(app, ["predictions", "get", "nba", "spread"])
            assert result.exit_code == 0
            assert "rockets" in result.stdout.lower() or "heat" in result.stdout.lower()

    def test_predictions_json_output(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_API_KEY", "sk_test")
        monkeypatch.setenv("SFS_API_URL", "http://test:8009")
        with respx.mock:
            respx.get("http://test:8009/api/v1/predictions/nba/won_on_spread").mock(
                return_value=httpx.Response(200, json=PREDICTIONS_RESPONSE)
            )
            result = runner.invoke(app, ["predictions", "get", "nba", "spread", "-o", "json"])
            assert result.exit_code == 0
            assert '"sport"' in result.stdout

    def test_shorthand_spread_resolves(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_API_KEY", "sk_test")
        monkeypatch.setenv("SFS_API_URL", "http://test:8009")
        with respx.mock:
            route = respx.get("http://test:8009/api/v1/predictions/nba/won_on_spread").mock(
                return_value=httpx.Response(200, json=PREDICTIONS_RESPONSE)
            )
            runner.invoke(app, ["predictions", "get", "nba", "spread"])
            assert route.called


class TestListSports:
    def test_list_sports(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_API_KEY", "sk_test")
        monkeypatch.setenv("SFS_API_URL", "http://test:8009")
        with respx.mock:
            respx.get("http://test:8009/api/v1/sports").mock(
                return_value=httpx.Response(200, json=SPORTS_RESPONSE)
            )
            result = runner.invoke(app, ["predictions", "list-sports"])
            assert result.exit_code == 0
            assert "nba" in result.stdout.lower()
