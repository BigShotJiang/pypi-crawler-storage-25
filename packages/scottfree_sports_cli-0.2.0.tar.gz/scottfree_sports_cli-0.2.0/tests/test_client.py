import httpx
import pytest
import respx

from sflow_cli.client import SflowClient
from sflow_cli.exceptions import AuthError, ForbiddenError, NotFoundError, ServerError


class TestSflowClientSync:
    def test_get_predictions(self, api_key, api_url):
        response_data = {
            "sport": "nba",
            "model_type": "won_on_spread",
            "games": [{"home_team": "Lakers", "away_team": "Warriors"}],
        }
        with respx.mock:
            respx.get(f"{api_url}/api/v1/predictions/nba/won_on_spread").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = SflowClient(api_key, api_url)
            result = client.get_predictions("nba", "won_on_spread")
            assert result["sport"] == "nba"
            assert len(result["games"]) == 1

    def test_get_results_with_limit(self, api_key, api_url):
        response_data = {"sport": "nba", "results": []}
        with respx.mock:
            route = respx.get(f"{api_url}/api/v1/results/nba/won_on_spread").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = SflowClient(api_key, api_url)
            client.get_results("nba", "won_on_spread", limit=25)
            assert route.calls[0].request.url.params["limit"] == "25"

    def test_get_summary(self, api_key, api_url):
        response_data = {"sport": "nba", "summaries": []}
        with respx.mock:
            respx.get(f"{api_url}/api/v1/summary/nba/won_on_spread").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = SflowClient(api_key, api_url)
            result = client.get_summary("nba", "won_on_spread")
            assert result["sport"] == "nba"

    def test_get_odds(self, api_key, api_url):
        response_data = {"sport": "nba", "games": []}
        with respx.mock:
            respx.get(f"{api_url}/api/v1/odds/nba").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = SflowClient(api_key, api_url)
            result = client.get_odds("nba")
            assert result["sport"] == "nba"

    def test_get_ai_analysis(self, api_key, api_url):
        response_data = {"sport": "nba", "analyses": []}
        with respx.mock:
            respx.get(f"{api_url}/api/v1/ai-analysis/nba/won_on_spread").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = SflowClient(api_key, api_url)
            result = client.get_ai_analysis("nba", "won_on_spread")
            assert result["sport"] == "nba"

    def test_get_sports(self, api_key, api_url):
        response_data = {"sports": [], "model_types": []}
        with respx.mock:
            respx.get(f"{api_url}/api/v1/sports").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = SflowClient(api_key, api_url)
            result = client.get_sports()
            assert "sports" in result

    def test_auth_header_sent(self, api_key, api_url):
        with respx.mock:
            route = respx.get(f"{api_url}/api/v1/sports").mock(
                return_value=httpx.Response(200, json={})
            )
            client = SflowClient(api_key, api_url)
            client.get_sports()
            assert route.calls[0].request.headers["X-API-Key"] == api_key

    def test_401_raises_auth_error(self, api_key, api_url):
        with respx.mock:
            respx.get(f"{api_url}/api/v1/sports").mock(
                return_value=httpx.Response(401, json={"detail": "Invalid API key"})
            )
            client = SflowClient(api_key, api_url)
            with pytest.raises(AuthError):
                client.get_sports()

    def test_403_raises_forbidden_error(self, api_key, api_url):
        with respx.mock:
            respx.get(f"{api_url}/api/v1/ai-analysis/nba/won_on_spread").mock(
                return_value=httpx.Response(403, json={"detail": "Premium required"})
            )
            client = SflowClient(api_key, api_url)
            with pytest.raises(ForbiddenError):
                client.get_ai_analysis("nba", "won_on_spread")

    def test_404_raises_not_found_error(self, api_key, api_url):
        with respx.mock:
            respx.get(f"{api_url}/api/v1/predictions/nba/won_on_spread").mock(
                return_value=httpx.Response(404, json={"detail": "No predictions found"})
            )
            client = SflowClient(api_key, api_url)
            with pytest.raises(NotFoundError):
                client.get_predictions("nba", "won_on_spread")

    def test_500_raises_server_error(self, api_key, api_url):
        with respx.mock:
            respx.get(f"{api_url}/api/v1/sports").mock(
                return_value=httpx.Response(500, json={"detail": "Internal error"})
            )
            client = SflowClient(api_key, api_url)
            with pytest.raises(ServerError):
                client.get_sports()


class TestSflowClientAccountEndpoints:
    def test_get_account_info(self, api_key, api_url):
        response_data = {"email": "test@test.com", "tier": "premium"}
        with respx.mock:
            respx.get(f"{api_url}/api/v1/customers/me").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = SflowClient(api_key, api_url)
            result = client.get_account_info()
            assert result["email"] == "test@test.com"

    def test_get_usage(self, api_key, api_url):
        response_data = {"monthly_requests": 100, "monthly_limit": 50000}
        with respx.mock:
            respx.get(f"{api_url}/api/v1/customers/me/usage").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = SflowClient(api_key, api_url)
            result = client.get_usage()
            assert result["monthly_requests"] == 100

    def test_get_api_keys(self, api_key, api_url):
        response_data = [{"api_key": "sk_***", "name": "My Key"}]
        with respx.mock:
            respx.get(f"{api_url}/api/v1/customers/me/api-keys").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = SflowClient(api_key, api_url)
            result = client.get_api_keys()
            assert len(result) == 1

    def test_clear_cache(self, api_key, api_url):
        response_data = {"message": "Cache cleared"}
        with respx.mock:
            respx.post(f"{api_url}/api/v1/admin/cache/clear").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = SflowClient(api_key, api_url)
            result = client.clear_cache()
            assert "message" in result


class TestSflowClientAsync:
    @pytest.mark.asyncio
    async def test_aget_predictions(self, api_key, api_url):
        response_data = {"sport": "nba", "games": []}
        with respx.mock:
            respx.get(f"{api_url}/api/v1/predictions/nba/won_on_spread").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = SflowClient(api_key, api_url)
            result = await client.aget_predictions("nba", "won_on_spread")
            assert result["sport"] == "nba"

    @pytest.mark.asyncio
    async def test_aget_sports(self, api_key, api_url):
        response_data = {"sports": []}
        with respx.mock:
            respx.get(f"{api_url}/api/v1/sports").mock(
                return_value=httpx.Response(200, json=response_data)
            )
            client = SflowClient(api_key, api_url)
            result = await client.aget_sports()
            assert "sports" in result
