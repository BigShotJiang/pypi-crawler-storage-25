"""Tests for the Open-Meteo weather client and venue lookup utilities."""

from unittest.mock import patch

import httpx
import pytest
import respx

from sflow_cli.exceptions import SflowAPIError
from sflow_cli.weather import VENUES, WeatherClient, get_outdoor_venues

_OPEN_METEO_BASE = "https://api.open-meteo.com/v1/forecast"

_SAMPLE_WEATHER = {
    "latitude": 42.7738,
    "longitude": -78.787,
    "current": {
        "temperature_2m": 3.5,
        "precipitation": 0.0,
        "wind_speed_10m": 12.4,
        "weather_code": 3,
    },
}


class TestWeatherClient:
    def test_get_weather_sends_correct_params(self):
        with respx.mock:
            route = respx.get(_OPEN_METEO_BASE).mock(
                return_value=httpx.Response(200, json=_SAMPLE_WEATHER)
            )
            client = WeatherClient()
            result = client.get_weather(42.7738, -78.7870)
            assert result["current"]["temperature_2m"] == 3.5
            params = route.calls[0].request.url.params
            assert params["latitude"] == "42.7738"
            assert params["longitude"] == "-78.787"
            assert "temperature_2m" in params["current"]
            assert "precipitation" in params["current"]
            assert "wind_speed_10m" in params["current"]
            assert "weather_code" in params["current"]

    def test_get_weather_returns_dict(self):
        with respx.mock:
            respx.get(_OPEN_METEO_BASE).mock(return_value=httpx.Response(200, json=_SAMPLE_WEATHER))
            client = WeatherClient()
            result = client.get_weather(39.7439, -105.0201)
            assert isinstance(result, dict)
            assert "current" in result

    def test_get_game_weather_returns_list_with_venue_info(self):
        bills_weather = {**_SAMPLE_WEATHER, "latitude": 42.7738, "longitude": -78.787}
        chiefs_weather = {**_SAMPLE_WEATHER, "latitude": 39.0489, "longitude": -94.4839}
        with respx.mock:
            respx.get(_OPEN_METEO_BASE).mock(
                side_effect=[
                    httpx.Response(200, json=bills_weather),
                    httpx.Response(200, json=chiefs_weather),
                ]
            )
            client = WeatherClient()
            results = client.get_game_weather("nfl", ["bills", "chiefs"])
            assert len(results) == 2
            assert results[0]["venue"] == "bills"
            assert results[0]["latitude"] == 42.7738
            assert results[0]["longitude"] == -78.7870
            assert "weather" in results[0]
            assert results[1]["venue"] == "chiefs"
            assert results[1]["latitude"] == 39.0489

    def test_get_game_weather_result_keys(self):
        with respx.mock:
            respx.get(_OPEN_METEO_BASE).mock(return_value=httpx.Response(200, json=_SAMPLE_WEATHER))
            client = WeatherClient()
            results = client.get_game_weather("nfl", ["packers"])
            assert len(results) == 1
            item = results[0]
            assert set(item.keys()) == {"venue", "latitude", "longitude", "weather"}

    def test_unknown_venue_skipped(self):
        with respx.mock:
            respx.get(_OPEN_METEO_BASE).mock(return_value=httpx.Response(200, json=_SAMPLE_WEATHER))
            client = WeatherClient()
            results = client.get_game_weather("nfl", ["bills", "unknown_team_xyz"])
            # only the known venue is returned
            assert len(results) == 1
            assert results[0]["venue"] == "bills"

    def test_unknown_venue_only_returns_empty_list(self):
        with respx.mock:
            # no HTTP calls should be made when all venues are unknown
            respx.get(_OPEN_METEO_BASE).mock(return_value=httpx.Response(200, json=_SAMPLE_WEATHER))
            client = WeatherClient()
            results = client.get_game_weather("nfl", ["not_a_team", "also_not_a_team"])
            assert results == []

    def test_unknown_sport_returns_empty_list(self):
        with respx.mock:
            respx.get(_OPEN_METEO_BASE).mock(return_value=httpx.Response(200, json=_SAMPLE_WEATHER))
            client = WeatherClient()
            results = client.get_game_weather("cricket", ["some_team"])
            assert results == []

    def test_get_weather_error_handling_500(self):
        with respx.mock:
            respx.get(_OPEN_METEO_BASE).mock(
                return_value=httpx.Response(500, json={"reason": "Internal server error"})
            )
            client = WeatherClient()
            with pytest.raises(SflowAPIError) as exc_info:
                client.get_weather(42.0, -74.0)
            assert exc_info.value.status_code == 500

    def test_get_weather_error_handling_404(self):
        with respx.mock:
            respx.get(_OPEN_METEO_BASE).mock(
                return_value=httpx.Response(404, json={"reason": "Not found"})
            )
            client = WeatherClient()
            with pytest.raises(SflowAPIError) as exc_info:
                client.get_weather(0.0, 0.0)
            assert exc_info.value.status_code == 404

    def test_no_auth_headers_sent(self):
        with respx.mock:
            route = respx.get(_OPEN_METEO_BASE).mock(
                return_value=httpx.Response(200, json=_SAMPLE_WEATHER)
            )
            client = WeatherClient()
            client.get_weather(42.7738, -78.7870)
            assert "X-API-Key" not in route.calls[0].request.headers
            assert "Authorization" not in route.calls[0].request.headers

    def test_custom_base_url(self):
        custom_base = "http://localhost:9999/forecast"
        with respx.mock:
            respx.get(custom_base).mock(return_value=httpx.Response(200, json=_SAMPLE_WEATHER))
            client = WeatherClient(base_url=custom_base)
            result = client.get_weather(42.7738, -78.7870)
            assert "current" in result

    @patch("sflow_cli.weather.time.sleep")
    def test_retries_on_503_then_succeeds(self, mock_sleep):
        with respx.mock:
            route = respx.get(_OPEN_METEO_BASE).mock(
                side_effect=[
                    httpx.Response(503),
                    httpx.Response(200, json=_SAMPLE_WEATHER),
                ]
            )
            client = WeatherClient()
            result = client.get_weather(42.7738, -78.7870)
            assert "current" in result
            assert route.call_count == 2
            mock_sleep.assert_called_once()


class TestWeatherClientAsync:
    async def test_aget_weather(self):
        with respx.mock:
            route = respx.get(_OPEN_METEO_BASE).mock(
                return_value=httpx.Response(200, json=_SAMPLE_WEATHER)
            )
            client = WeatherClient()
            result = await client.aget_weather(42.7738, -78.7870)
            assert isinstance(result, dict)
            assert "current" in result
            params = route.calls[0].request.url.params
            assert params["latitude"] == "42.7738"
            assert "temperature_2m" in params["current"]

    async def test_aget_game_weather(self):
        with respx.mock:
            respx.get(_OPEN_METEO_BASE).mock(
                side_effect=[
                    httpx.Response(200, json=_SAMPLE_WEATHER),
                    httpx.Response(200, json=_SAMPLE_WEATHER),
                ]
            )
            client = WeatherClient()
            results = await client.aget_game_weather("nfl", ["bills", "packers"])
            assert len(results) == 2
            assert results[0]["venue"] == "bills"
            assert results[1]["venue"] == "packers"
            assert "weather" in results[0]

    async def test_aget_unknown_venue_skipped(self):
        with respx.mock:
            respx.get(_OPEN_METEO_BASE).mock(return_value=httpx.Response(200, json=_SAMPLE_WEATHER))
            client = WeatherClient()
            results = await client.aget_game_weather("nfl", ["seahawks", "no_such_team"])
            assert len(results) == 1
            assert results[0]["venue"] == "seahawks"

    @patch("sflow_cli.weather.asyncio.sleep")
    async def test_async_retries_on_502(self, mock_sleep):
        with respx.mock:
            route = respx.get(_OPEN_METEO_BASE).mock(
                side_effect=[
                    httpx.Response(502),
                    httpx.Response(200, json=_SAMPLE_WEATHER),
                ]
            )
            client = WeatherClient()
            result = await client.aget_weather(39.7439, -105.0201)
            assert "current" in result
            assert route.call_count == 2


class TestVenueLookup:
    def test_get_outdoor_venues_nfl(self):
        outdoor = get_outdoor_venues("nfl")
        # Should only contain True entries
        for team, coords in outdoor.items():
            assert len(coords) == 3, f"{team} tuple should be (lat, lon, name)"
            lat, lon, name = coords
            assert isinstance(lat, float)
            assert isinstance(lon, float)
            assert isinstance(name, str)
        # Verify specific outdoor teams are included
        assert "bills" in outdoor
        assert "packers" in outdoor
        assert "chiefs" in outdoor
        assert "seahawks" in outdoor
        assert "eagles" in outdoor

    def test_get_outdoor_venues_nfl_excludes_domes(self):
        outdoor = get_outdoor_venues("nfl")
        # All indoor/dome venues must be excluded
        assert "saints" not in outdoor  # Caesars Superdome
        assert "falcons" not in outdoor  # Mercedes-Benz Stadium
        assert "cowboys" not in outdoor  # AT&T Stadium
        assert "texans" not in outdoor  # NRG Stadium
        assert "cardinals" not in outdoor  # State Farm Stadium
        assert "colts" not in outdoor  # Lucas Oil Stadium
        assert "lions" not in outdoor  # Ford Field
        assert "vikings" not in outdoor  # U.S. Bank Stadium
        assert "chargers" not in outdoor  # SoFi Stadium
        assert "rams" not in outdoor  # SoFi Stadium

    def test_get_outdoor_venues_mlb(self):
        outdoor = get_outdoor_venues("mlb")
        # Classic outdoor parks present
        assert "yankees" in outdoor
        assert "red_sox" in outdoor
        assert "cubs" in outdoor
        assert "dodgers" in outdoor
        assert "rockies" in outdoor

    def test_get_outdoor_venues_mlb_excludes_indoor_and_retractable(self):
        outdoor = get_outdoor_venues("mlb")
        # Indoor and retractable domes excluded
        assert "rays" not in outdoor  # Tropicana Field — true dome
        assert "rangers" not in outdoor  # Globe Life Field — indoor
        assert "blue_jays" not in outdoor  # Rogers Centre — indoor
        assert "brewers" not in outdoor  # American Family Field — retractable
        assert "astros" not in outdoor  # Minute Maid Park — retractable
        assert "mariners" not in outdoor  # T-Mobile Park — retractable
        assert "diamondbacks" not in outdoor  # Chase Field — retractable
        assert "marlins" not in outdoor  # LoanDepot Park — retractable

    def test_get_outdoor_venues_returns_three_tuple(self):
        outdoor = get_outdoor_venues("nfl")
        lat, lon, name = outdoor["bills"]
        assert lat == 42.7738
        assert lon == -78.7870
        assert name == "Highmark Stadium"

    def test_unknown_sport_returns_empty_dict(self):
        result = get_outdoor_venues("cricket")
        assert result == {}

    def test_unknown_sport_does_not_raise(self):
        # get_outdoor_venues uses .get() so unknown sports return {} without error
        result = get_outdoor_venues("hockey")
        assert isinstance(result, dict)
        assert len(result) == 0

    def test_venues_dict_structure(self):
        # Verify the master VENUES dict has expected sports
        assert "nfl" in VENUES
        assert "mlb" in VENUES

    def test_venues_nfl_all_entries_have_four_tuple(self):
        for team, entry in VENUES["nfl"].items():
            assert len(entry) == 4, f"NFL {team} entry should be (lat, lon, name, is_outdoor)"
            lat, lon, name, is_outdoor = entry
            assert isinstance(lat, float)
            assert isinstance(lon, float)
            assert isinstance(name, str)
            assert isinstance(is_outdoor, bool)

    def test_venues_mlb_all_entries_have_four_tuple(self):
        for team, entry in VENUES["mlb"].items():
            assert len(entry) == 4, f"MLB {team} entry should be (lat, lon, name, is_outdoor)"
