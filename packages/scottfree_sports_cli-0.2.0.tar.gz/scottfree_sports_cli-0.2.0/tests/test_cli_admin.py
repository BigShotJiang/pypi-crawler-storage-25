import httpx
import respx
from typer.testing import CliRunner

from sflow_cli.cli import app

runner = CliRunner()


def _env(tmp_path):
    return {
        "SFS_CONFIG_DIR": str(tmp_path),
        "SFS_API_KEY": "sk_test",
        "SFS_API_URL": "http://test:8009",
    }


class TestAdminCacheClear:
    def test_cache_clear(self, tmp_path, monkeypatch):
        for k, v in _env(tmp_path).items():
            monkeypatch.setenv(k, v)
        data = {"message": "All cache cleared successfully"}
        with respx.mock:
            respx.post("http://test:8009/api/v1/admin/cache/clear").mock(
                return_value=httpx.Response(200, json=data)
            )
            result = runner.invoke(app, ["admin", "cache-clear"])
            assert result.exit_code == 0
            assert "cleared" in result.stdout.lower()


class TestAdminCacheInvalidate:
    def test_cache_invalidate_with_path(self, tmp_path, monkeypatch):
        for k, v in _env(tmp_path).items():
            monkeypatch.setenv(k, v)
        data = {"message": "Cache invalidated"}
        with respx.mock:
            respx.post("http://test:8009/api/v1/admin/cache/invalidate").mock(
                return_value=httpx.Response(200, json=data)
            )
            result = runner.invoke(
                app, ["admin", "cache-invalidate", "--file-path", "NBA/predictions.csv"]
            )
            assert result.exit_code == 0


class TestAdminCacheStats:
    def test_cache_stats(self, tmp_path, monkeypatch):
        for k, v in _env(tmp_path).items():
            monkeypatch.setenv(k, v)
        data = {"cache_stats": {"hits": 100, "misses": 20, "hit_rate": 83.3}}
        with respx.mock:
            respx.get("http://test:8009/api/v1/admin/cache/stats").mock(
                return_value=httpx.Response(200, json=data)
            )
            result = runner.invoke(app, ["admin", "cache-stats"])
            assert result.exit_code == 0
