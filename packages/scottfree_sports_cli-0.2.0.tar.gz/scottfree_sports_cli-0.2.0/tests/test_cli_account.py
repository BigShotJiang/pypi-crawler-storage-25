import httpx
import respx
from typer.testing import CliRunner

from sflow_cli.cli import app

runner = CliRunner()


def _env(tmp_path):
    return {
        "SFS_CONFIG_DIR": str(tmp_path),
        "SFS_API_KEY": "sk_test",
        "SFS_API_URL": "http://test:8009",
    }


class TestAccountInfo:
    def test_account_info(self, tmp_path, monkeypatch):
        for k, v in _env(tmp_path).items():
            monkeypatch.setenv(k, v)
        data = {"email": "test@test.com", "tier": "premium", "subscription_status": "active"}
        with respx.mock:
            respx.get("http://test:8009/api/v1/customers/me").mock(
                return_value=httpx.Response(200, json=data)
            )
            result = runner.invoke(app, ["account", "info"])
            assert result.exit_code == 0
            assert "test@test.com" in result.stdout


class TestAccountUsage:
    def test_account_usage(self, tmp_path, monkeypatch):
        for k, v in _env(tmp_path).items():
            monkeypatch.setenv(k, v)
        data = {"monthly_requests": 1250, "monthly_limit": 50000, "tier": "basic"}
        with respx.mock:
            respx.get("http://test:8009/api/v1/customers/me/usage").mock(
                return_value=httpx.Response(200, json=data)
            )
            result = runner.invoke(app, ["account", "usage"])
            assert result.exit_code == 0
            assert "1250" in result.stdout or "1,250" in result.stdout


class TestAccountKeys:
    def test_list_keys(self, tmp_path, monkeypatch):
        for k, v in _env(tmp_path).items():
            monkeypatch.setenv(k, v)
        data = [{"api_key": "sk_***masked***", "name": "Primary", "is_active": True}]
        with respx.mock:
            respx.get("http://test:8009/api/v1/customers/me/api-keys").mock(
                return_value=httpx.Response(200, json=data)
            )
            result = runner.invoke(app, ["account", "keys"])
            assert result.exit_code == 0
            assert "Primary" in result.stdout
