"""Tests for sflow markets CLI commands."""

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from sflow_cli.cli import app

runner = CliRunner()

KALSHI_MARKETS_RESPONSE = {
    "markets": [
        {
            "ticker": "NBA-GAME-LAL-BOS-2026-03-29",
            "title": "Lakers vs Celtics",
            "event_ticker": "NBA_GAME",
            "yes_price": 0.65,
            "no_price": 0.35,
            "volume_24h": 12500,
            "open_interest": 45000,
        },
        {
            "ticker": "NBA-GAME-MIA-NYK-2026-03-29",
            "title": "Heat vs Knicks",
            "event_ticker": "NBA_GAME",
            "yes_price": 0.48,
            "no_price": 0.52,
            "volume_24h": 8700,
            "open_interest": 31000,
        },
    ]
}

POLYMARKET_EVENTS_RESPONSE = [
    {
        "title": "Lakers vs Celtics",
        "markets": [
            {
                "question": "Will Lakers beat Celtics?",
                "yes_price": 0.60,
                "no_price": 0.40,
                "volume_24h": 25000,
            }
        ],
    }
]

PREDICTIONS_RESPONSE = {
    "sport": "nba",
    "model_type": "won_on_spread",
    "predictions_date": "2026-03-29T00:00:00Z",
    "games": [
        {
            "date": "2026-03-29",
            "home_team": "celtics",
            "away_team": "lakers",
            "home_point_spread": -3.5,
            "predictions": {
                "IMPLIED": 0.62,
                "BLEND": 0.58,
            },
        }
    ],
}


class TestMarketsKalshi:
    @patch("sflow_cli.commands.markets.KalshiClient")
    def test_kalshi_table_output(self, mock_cls, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        mock_client = MagicMock()
        mock_client.get_markets.return_value = KALSHI_MARKETS_RESPONSE
        mock_cls.return_value = mock_client

        result = runner.invoke(app, ["markets", "kalshi", "nba"])
        assert result.exit_code == 0
        assert "Lakers" in result.stdout or "kalshi" in result.stdout.lower()

    @patch("sflow_cli.commands.markets.KalshiClient")
    def test_kalshi_json_output(self, mock_cls, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        mock_client = MagicMock()
        mock_client.get_markets.return_value = KALSHI_MARKETS_RESPONSE
        mock_cls.return_value = mock_client

        result = runner.invoke(app, ["markets", "kalshi", "nba", "-o", "json"])
        assert result.exit_code == 0
        assert '"ticker"' in result.stdout


class TestMarketsPolymarket:
    @patch("sflow_cli.commands.markets.PolymarketClient")
    def test_polymarket_table_output(self, mock_cls, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        mock_client = MagicMock()
        mock_client.get_events.return_value = POLYMARKET_EVENTS_RESPONSE
        mock_cls.return_value = mock_client

        result = runner.invoke(app, ["markets", "polymarket", "nba"])
        assert result.exit_code == 0
        assert "Lakers" in result.stdout or "polymarket" in result.stdout.lower()

    @patch("sflow_cli.commands.markets.PolymarketClient")
    def test_polymarket_json_output(self, mock_cls, tmp_path, monkeypatch):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        mock_client = MagicMock()
        mock_client.get_events.return_value = POLYMARKET_EVENTS_RESPONSE
        mock_cls.return_value = mock_client

        result = runner.invoke(app, ["markets", "polymarket", "nba", "-o", "json"])
        assert result.exit_code == 0
        assert '"title"' in result.stdout


class TestMarketsCompare:
    @patch("sflow_cli.commands.markets.PolymarketClient")
    @patch("sflow_cli.commands.markets.KalshiClient")
    @patch("sflow_cli.commands.markets.get_client_from_env")
    def test_compare_table_output(
        self, mock_get_client, mock_kalshi_cls, mock_poly_cls, tmp_path, monkeypatch
    ):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_API_KEY", "sk_test")
        monkeypatch.setenv("SFS_API_URL", "http://test:8009")

        # Mock API client
        mock_api = MagicMock()
        mock_api.get_predictions.return_value = PREDICTIONS_RESPONSE
        mock_get_client.return_value = mock_api

        # Mock Kalshi
        mock_kalshi = MagicMock()
        mock_kalshi.get_markets.return_value = KALSHI_MARKETS_RESPONSE
        mock_kalshi_cls.return_value = mock_kalshi

        # Mock Polymarket
        mock_poly = MagicMock()
        mock_poly.get_events.return_value = POLYMARKET_EVENTS_RESPONSE
        mock_poly_cls.return_value = mock_poly

        result = runner.invoke(app, ["markets", "compare", "nba"])
        assert result.exit_code == 0

    @patch("sflow_cli.commands.markets.PolymarketClient")
    @patch("sflow_cli.commands.markets.KalshiClient")
    @patch("sflow_cli.commands.markets.get_client_from_env")
    def test_compare_json_output(
        self, mock_get_client, mock_kalshi_cls, mock_poly_cls, tmp_path, monkeypatch
    ):
        monkeypatch.setenv("SFS_CONFIG_DIR", str(tmp_path))
        monkeypatch.setenv("SFS_API_KEY", "sk_test")
        monkeypatch.setenv("SFS_API_URL", "http://test:8009")

        mock_api = MagicMock()
        mock_api.get_predictions.return_value = PREDICTIONS_RESPONSE
        mock_get_client.return_value = mock_api

        mock_kalshi = MagicMock()
        mock_kalshi.get_markets.return_value = KALSHI_MARKETS_RESPONSE
        mock_kalshi_cls.return_value = mock_kalshi

        mock_poly = MagicMock()
        mock_poly.get_events.return_value = POLYMARKET_EVENTS_RESPONSE
        mock_poly_cls.return_value = mock_poly

        result = runner.invoke(app, ["markets", "compare", "nba", "-o", "json"])
        assert result.exit_code == 0
        assert '"predictions"' in result.stdout
