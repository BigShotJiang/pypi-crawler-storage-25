"""Monorepo library package."""
