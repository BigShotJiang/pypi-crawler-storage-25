"""Heuristic analysis helpers."""
