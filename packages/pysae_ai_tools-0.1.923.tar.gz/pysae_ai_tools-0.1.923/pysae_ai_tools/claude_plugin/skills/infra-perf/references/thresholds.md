# Performance Thresholds

Thresholds for flagging issues in `/infra-perf` output. A metric exceeding **warning** gets a `!` marker. Exceeding **critical** gets a `!!` marker.

## Absolute thresholds

| Metric | Warning | Critical |
|--------|---------|----------|
| P99 latency | > 800ms | > 2s |
| P95 latency | > 500ms | > 1.5s |
| Error rate | > 1% | > 5% |
| CPU usage | > 80% | > 95% |
| RAM usage | > 85% | > 95% |
| Pod restarts (last 10m) | > 2 | > 5 |

## Relative thresholds (compare mode)

When comparing against a reference period, flag if delta exceeds:

| Metric | Warning | Critical |
|--------|---------|----------|
| P99 latency increase | > +100% | > +300% |
| Error rate increase | > +100% | > +500% |
| CPU increase | > +50% | > +100% |

## Output markers

- No marker: metric is healthy
- `!` (warning): metric exceeds warning threshold
- `!!` (critical): metric exceeds critical threshold
- Summary line at bottom listing all warnings/criticals with context
