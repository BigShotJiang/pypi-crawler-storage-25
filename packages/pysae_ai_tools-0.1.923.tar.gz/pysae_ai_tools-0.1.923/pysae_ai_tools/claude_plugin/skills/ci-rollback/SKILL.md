---
name: ci-rollback
description: >
  Rollback production to the previous working version.
  Use when the user says /ci-rollback, /rollback, 'rollback', 'rollback prod',
  'reviens en arrière', 'redeploy previous version', or wants to revert
  a production deployment.
argument-hint: "<optional: app name> <optional: target version e.g. v4.4.3>"
allowed-tools:
  - Bash
  - Skill
  - AskUserQuestion
  - mcp__kubernetes__kubectl_get
---

Rollback production to the previous working version by redeploying the last known good tag.

## Required tools

- `glab`
- `kubectl`

Run `pysae-ai-tools tools require <tools>` before starting; if it exits non-zero, abort and report the install command from stderr to the user.

## Step 1 — Resolve context and target app

```bash
CTX=$(pysae-ai-tools internal detect-context)
PROJECT_ID=$(echo "$CTX" | jq -r '.project_id // empty')
PROJECT_PATH=$(echo "$CTX" | jq -r '.project_path // empty')
```

Resolve the target application using [../references/pysae-projects.md](../references/pysae-projects.md). **Default**: `pysae/api`.

## Step 2 — Identify current and rollback versions

**Current version** — use `git_prod_version` from detect_context (Step 1):
```bash
CURRENT_TAG=$(echo "$CTX" | jq -r '.git_prod_version // empty')
```
If empty (no `prod` branch), fallback to kubectl:
```bash
IMAGE=$(kubectl get deployment prod-<K8S_DEPLOYMENT> -n prod \
  -o jsonpath='{.spec.template.spec.containers[0].image}')
CURRENT_TAG=$(echo "$IMAGE" | grep -oP '[^:]+$')
```

**Previous versions** — fetch recent tags with their dates:
```bash
glab api "projects/${PROJECT_ID}/repository/tags?per_page=10&order_by=version" \
  | jq -r '.[] | select(.name | test("^v?[0-9]+\\.[0-9]+\\.[0-9]+$")) | "\(.name) \(.commit.created_at)"'
```
Collect the 3 tags before the current version (skip non-semver tags).

## Step 3 — Confirm with the user

Use `AskUserQuestion` (local mode only, skip in CI). Show the current version and propose the 3 previous versions with their dates:

> Rollback `<app>` — version actuelle : `<CURRENT_VERSION>` (`<current_date>`)
>
> - **`<V-1>`** (`<date_v-1>`) ← recommandé
> - **`<V-2>`** (`<date_v-2>`)
> - **`<V-3>`** (`<date_v-3>`)
> - **`<CURRENT_VERSION>`** (`<current_date>`) — redéployer la version actuelle
> - **Autre version** — spécifier un tag différent
> - **Annuler**

If `$ARGUMENTS` already specifies a version, skip the choice and confirm directly.

## Step 4 — Deploy the rollback version

Delegate to `/ci-deploy` with arguments: `prod <ROLLBACK_VERSION>` (+ app name if not default).

`/ci-deploy` handles finding/creating the pipeline for that tag and choosing le job optimal : `redeploy` si `deploy_prod` a déjà réussi sur cette pipeline (cas typique d'un rollback puisque la version a déjà été déployée), sinon `deploy_prod` complet.

## Step 5 — Verify rollout

After deploy, verify all deployments are running the rollback version:
```bash
kubectl get deployments -n prod --no-headers | grep "^prod-<deployment-prefix>"
```

For each deployment, check the image tag matches `<ROLLBACK_VERSION>`. Alert if any deployment is still on the old version.

Report the result to the user:
> Rollback `<app>` : `<CURRENT_VERSION>` → `<ROLLBACK_VERSION>` — terminé
> - X/X déploiements sur la bonne version

$ARGUMENTS
