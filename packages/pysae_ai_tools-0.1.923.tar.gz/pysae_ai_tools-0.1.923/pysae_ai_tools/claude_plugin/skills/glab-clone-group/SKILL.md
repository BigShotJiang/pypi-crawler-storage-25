---
name: glab-clone-group
description: >
  Clone all GitLab repositories from the Pysae group and subgroups recursively,
  preserving the group/subgroup folder structure. Existing repos get their remote
  verified and are pulled. Archived and read-only repos are excluded by default.
  Use when the user says /glab-clone-group, 'clone tous les repos', 'clone all repos',
  'clone pysae', 'clone le groupe', 'sync repos', 'pull all repos', or wants to
  set up a fresh workspace with all Pysae repositories.
argument-hint: "[--base-dir DIR] [--protocol ssh|https] [--dry-run] [--include-archived] [--include-read-only] [--prune] [-y]"
allowed-tools:
  - Bash
  - Read
  - AskUserQuestion
---

Clone all repositories from the Pysae GitLab group and its subgroups, preserving the folder hierarchy.

## Required tools

- `glab`

Run `pysae-ai-tools tools require <tools>` before starting; if it exits non-zero, abort and report the install command from stderr to the user.

## Mode detection

```bash
CTX=$(pysae-ai-tools internal detect-context --local)
IS_CI=$(echo "$CTX" | jq -r '.is_ci')
```

In CI mode (`IS_CI == "true"`):
- **Never use `AskUserQuestion`** — all parameters must come from `$ARGUMENTS`
- If a required argument is missing, **fail with exit code 1**

## Behavior

For each project found in the group:

| Directory state | Action |
|---|---|
| Does not exist | `git clone` into `<base-dir>/<group>/<subgroup>/<project>` |
| Exists, is a git repo, remote matches | Fetch, switch to default branch if current tracks a deleted remote branch, stash local changes, `git pull --rebase`, restore stash |
| Exists, is a git repo, remote differs | Fix remote URL, fetch, switch to default branch if needed, then pull with rebase |
| Exists, is a git repo, no origin remote | Add origin remote, fetch, switch to default branch if needed, then pull with rebase |
| Exists, not a git repo | Skip with warning |

Archived repositories and projects where the user has no push rights (access level below Developer) are **excluded** by default. Use `--include-archived` or `--include-read-only` to include them.

With `--prune`, after syncing, the script detects local repos under `<base-dir>/<group>/` that no longer match any accessible remote project (deleted, archived, or permissions revoked) and deletes them after confirmation. Pass `-y` / `--yes` to skip the prompt.

## Workflow

### Step 1 — Run the clone script

```bash
pysae-ai-tools glab clone-group [OPTIONS]
```

#### Flag mapping

| User intent | Flag |
|---|---|
| Default base dir (`~/projects`) | *(no flag needed)* |
| Custom base dir | `--base-dir /path/to/dir` |
| Use HTTPS instead of SSH | `--protocol https` |
| Preview without cloning | `--dry-run` |
| Include archived repos | `--include-archived` |
| Include read-only repos (no push rights) | `--include-read-only` |
| Delete local repos no longer accessible | `--prune` |
| Auto-confirm prune deletions | `-y` / `--yes` |

### Step 2 — Present results

The script outputs:
- **stderr**: per-project progress with status symbols (`+` cloned, `=` pulled, `?` would clone, `~` would pull, `!` error)
- **stdout**: JSON summary with counts and project lists per status

Present a concise summary to the user:
- Total projects found
- How many were cloned vs pulled vs had errors
- Any remote URL fixes applied
- The base directory used

### Step 3 — Handle errors

If any projects failed:
1. For SSH errors, suggest switching to `--protocol https`
2. For rebase conflicts, the script automatically aborts the rebase and restores local changes — inform the user which repos need manual attention
