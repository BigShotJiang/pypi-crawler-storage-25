---
name: glab-issue-find
description: >
  Find a GitLab issue by IID, URL, author, assignee, or keywords.
  Use when the user says /glab-issue-find, 'trouve le ticket', 'cherche l issue',
  'quel ticket parle de', 'l issue de <assignee>', 'ticket sur le cache', or needs to locate a specific issue.
argument-hint: "<issue #IID or URL, author/assignee name, or search keywords>"
allowed-tools:
  - Bash
  - AskUserQuestion
  - Skill
---

Find a GitLab issue and return its details.

## Required tools

- `glab`

Run `pysae-ai-tools tools require <tools>` before starting; if it exits non-zero, abort and report the install command from stderr to the user.

## Step 1 — Resolve the issue

**If `$ARGUMENTS` contains a GitLab ref** (`#IID`, URL):
```bash
CTX=$(pysae-ai-tools internal detect-context $ARGUMENTS_REFS)
ISSUE_IID=$(echo "$CTX" | jq -r '.issue_iid // empty')
```
If `ISSUE_IID` is resolved, skip to Step 2.

**If `$ARGUMENTS` is natural language** (author, assignee, keywords):

First resolve context for the current project:
```bash
CTX=$(pysae-ai-tools internal detect-context --local)
PROJECT_PATH=$(echo "$CTX" | jq -r '.project_path // empty')
```

### Search by assignee/author

If the user mentions a person, delegate to `/glab-user-find` to resolve the GitLab username, then search:
```bash
glab issue list --assignee <resolved_username>
```

### Search by keywords

If the user describes the issue content:
```bash
glab issue list --search "<keywords>"
```

If multiple results, present the list and ask the user to pick one. If one match, use it.

## Step 2 — Display issue details

Once resolved, fetch full issue details via detect_context:
```bash
CTX=$(pysae-ai-tools internal detect-context "#${ISSUE_IID}")
```

Present: title, description (summary), labels, assignees, URL, linked MR and its source branch if available.

Then suggest available actions:
> Actions possibles :
> - `/code-implement #<IID>` — implémenter ce ticket
> - `/code-auto-pilot #<IID>` — implémentation autonome (implement + review + CI + deploy review)
> - `/glab-mr-checkout #<IID>` — checkout la branche associée (si une MR existe)

$ARGUMENTS
