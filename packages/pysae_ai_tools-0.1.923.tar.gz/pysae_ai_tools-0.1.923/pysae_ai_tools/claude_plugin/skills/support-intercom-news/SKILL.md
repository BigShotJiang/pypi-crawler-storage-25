---
name: support-intercom-news
description: "Produce an Intercom News (Actualités) announcement to communicate a shipped Pysae feature to clients. Generates a self-contained HTML file Patrick previews in a browser and copy-pastes into the Intercom News editor. Use when the user says /support-intercom-news, 'annonce', 'communique', 'actualité', 'news', 'on prévient les clients', or when a newly shipped feature needs to be communicated."
argument-hint: "[feature name, Patrick's brief, Notion link, or Slack message]"
allowed-tools:
  - Read
  - Write
  - Glob
  - Grep
  - Bash
  - AskUserQuestion
---

Créer des articles d'actualité (News) pour annoncer les nouvelles features Pysae aux clients via le module Actualités d'Intercom. Contrairement aux articles Help Center (opérationnels, mode d'emploi), les News sont **courtes, engageantes, benefit-focused** : on montre la valeur, pas le tuto.

**Prérequis** : MCP Notion pour récupérer specs/CRs, lecture code via clone local (`pysae-ai-tools code ensure-repo`).

Conventions HTML complètes : voir [../references/intercom-html-conventions.md](../references/intercom-html-conventions.md).
Repos Pysae : voir [../references/pysae-projects.md](../references/pysae-projects.md).

## Required tools

- `glab`

Run `pysae-ai-tools tools require <tools>` before starting; if it exits non-zero, abort and report the install command from stderr to the user.

## Quand utiliser

- Une feature vient d'être déployée en prod et doit être communiquée
- Patrick dit « annonce », « communique », « actualité », « news », « on prévient les clients »
- Créer de l'engouement autour d'une évolution produit

**Différent de `/support-intercom-article`** qui est pour le Help Center (mode d'emploi détaillé).

## Workflow

### Phase 1 — Comprendre la feature

Recherche **systématique** dans 3 sources. Ne jamais se baser uniquement sur le brief de Patrick.

1. **Brief de Patrick** : message, screenshots, lien Notion, message Slack de Lucas
2. **Notion via MCP** :
   - Chercher l'epic/spec de la feature : `notion-search` avec le nom
   - Lire les CR hebdo récents : « CR hebdomadaires » ou dates récentes
   - Lire les pages « Nouveautés produit » ou « Présentation nouveautés » de Lucas
   - Extraire : description fonctionnelle, motivation, cible, positionnement commercial
3. **Code local via clones** :
   ```bash
   pysae-ai-tools code ensure-repo pysae/op
   pysae-ai-tools code ensure-repo pysae/api
   pysae-ai-tools code ensure-repo pysae/pysae-common
   ```
   - MRs merged récentes : `glab mr list --repo pysae/op --merged --search "<feature>"`
   - Lire titres/descriptions des MRs pour comprendre ce qui a été implémenté
   - Lire les diffs si besoin pour comprendre les changements UI
4. **Synthèse** — répondre avant de rédiger :
   - **Quoi ?** — Qu'est-ce qui a changé concrètement ?
   - **Pour qui ?** — Tous les clients ou seulement certains (option payante, feature flag) ?
   - **Pourquoi ?** — Quel problème ça résout ? Quel gain ?
   - **Comment y accéder ?** — Où dans l'interface ?
   - **Avant/Après ?** — Qu'est-ce qui existait avant ? Qu'est-ce qui est différent ?

### Phase 2 — Structurer l'article

Structure type (adapter selon la feature) :

1. **Titre** — benefit-focused, < 60 caractères
   - Bon : « Le module Planning fait peau neuve »
   - Mauvais : « Nouvelle vue Séquences basée sur le block_id GTFS »
2. **Accroche** (2-3 phrases) — le problème/besoin → ce qui a changé
3. **Ce qui change** (bullets) — bénéfices concrets, langage utilisateur
4. **Star feature** (si applicable) — la nouveauté principale, plus de détails
5. **Comment y accéder** — 1-2 lignes, chemin dans l'interface
6. **Upsell** (si option payante) — encadré discret « Contactez-nous »
7. **CTA principal** — « Rendez-vous dans votre espace Op pour découvrir... »

### Phase 3 — Rédiger (fichier HTML copiable)

Produire un fichier **HTML** autonome que Patrick ouvre dans son navigateur et copie-colle dans l'éditeur Intercom News. Le formatage (gras, titres, listes) est préservé au copier-coller.

**Template HTML** — utiliser cette structure :

```html
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Article News Intercom — [NOM FEATURE]</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 680px;
            margin: 40px auto;
            padding: 20px;
            color: #1a1a1a;
            line-height: 1.6;
            background: #fff;
        }
        .instructions {
            background: #fff3cd;
            border: 1px solid #ffc107;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 32px;
            font-size: 14px;
        }
        .instructions h3 { margin-top: 0; color: #856404; }
        .section-label {
            background: #e8f4fd;
            border-left: 4px solid #0078d4;
            padding: 6px 12px;
            margin: 24px 0 8px 0;
            font-size: 13px;
            color: #0078d4;
            font-weight: 600;
        }
        h1.title { font-size: 28px; font-weight: 700; margin-bottom: 4px; }
        .article-content {
            border: 1px solid #e0e0e0;
            border-radius: 12px;
            padding: 32px;
            background: #fafafa;
        }
        .article-content h2 { font-size: 20px; font-weight: 700; margin-top: 28px; }
        .image-placeholder {
            background: #f0f0f0;
            border: 2px dashed #999;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            margin: 16px 0;
            color: #666;
            font-size: 14px;
        }
        .upsell-box {
            background: #f0f7ff;
            border-left: 4px solid #0078d4;
            padding: 16px;
            border-radius: 0 8px 8px 0;
            margin: 20px 0;
        }
        .screenshot-checklist { margin-top: 40px; padding-top: 20px; border-top: 2px solid #e0e0e0; }
        .screenshot-checklist table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .screenshot-checklist th, .screenshot-checklist td { border: 1px solid #ddd; padding: 8px 12px; text-align: left; }
        .screenshot-checklist th { background: #f5f5f5; }
    </style>
</head>
<body>

<div class="instructions">
    <h3>Mode d'emploi</h3>
    <ol>
        <li>Ouvre ce fichier dans ton navigateur (double-clic)</li>
        <li>Sélectionne tout le contenu dans le cadre gris (corps de l'article)</li>
        <li>Copie (<b>Ctrl+C</b>) et colle (<b>Ctrl+V</b>) dans l'éditeur News Intercom</li>
        <li>Remplace les zones en pointillés par tes screenshots</li>
    </ol>
    <p><b>Note :</b> Le titre se met dans le champ Titre d'Intercom, pas dans le corps.</p>
</div>

<div class="section-label">TITRE (champ « Title » d'Intercom News)</div>
<h1 class="title">[TITRE]</h1>

<div class="section-label">CORPS (sélectionner et copier le cadre ci-dessous)</div>
<div class="article-content">
    <!-- CONTENU ICI -->
</div>

<div class="screenshot-checklist">
    <h3>Checklist screenshots</h3>
    <table>
        <!-- CHECKLIST ICI -->
    </table>
</div>

</body>
</html>
```

**Emplacement du fichier** : dans le répertoire courant du dev, nom descriptif `article-news-[nom-feature].html` (ex : `article-news-planning.html`).

### Phase 4 — Review avec Patrick

1. Présenter l'article en décrivant le contenu et la structure
2. Dire à Patrick d'ouvrir le fichier HTML dans son navigateur pour prévisualiser
3. Lister les screenshots nécessaires avec descriptions précises
4. Itérer sur le contenu et le ton si nécessaire

### Phase 5 — Finaliser

1. Appliquer les corrections de Patrick dans le fichier HTML
2. Fournir la checklist finale des screenshots :
   - Description précise de ce que chaque screenshot doit montrer
   - **Toujours sur réseau démo** (jamais de données client)
   - Format recommandé : 900x504 px minimum pour la cover image
3. Suggestion de timing d'envoi : **mardi à jeudi, 10h-14h**

## Ton et style

| Règle | Détail |
|---|---|
| **Vouvoiement** | Toujours « vous » — jamais « tu » |
| **Ton** | Professionnel + chaleureux + enthousiaste. Fier sans être vendeur |
| **Longueur** | 200-300 mots max pour le corps. Concision maximale |
| **Pas de jargon technique** | Voir table de vocabulaire (intercom-html-conventions.md) |
| **Benefit-focused** | Toujours le bénéfice utilisateur, jamais la prouesse technique |
| **Accents français** | Toujours mettre les accents (é, è, ê, à, ç, ainsi que É, À, Ç) |

## Upsell (si feature payante)

Encadré discret en fin d'article :

```html
<div class="upsell-box">
    <p>La [feature] est disponible avec l'option <b>[Nom de l'option]</b>.<br>
    Vous ne l'avez pas encore ? <b>Contactez-nous</b> pour en savoir plus !</p>
</div>
```

**Jamais** mentionner de prix dans un article News.

## Erreurs à éviter

| Erreur | Correction |
|---|---|
| Oublier les accents | Toujours accentuer (évolué, dédiées, séquences...) |
| Jargon technique (`block_id`, GTFS, API) | Traduire en langage métier transport |
| Article trop long (> 300 mots) | Rester concis, chaque mot doit compter |
| Ton marketing agressif | Enthousiaste mais sincère, jamais sur-vendeur |
| Pas de recherche GitLab/Notion | Toujours croiser brief + Notion + code local |
| Screenshots avec données client | Toujours sur réseau démo |
| Mentionner des prix | Jamais de prix dans les News |
| Markdown dans le fichier | HTML uniquement |
| Pas de fichier HTML | Toujours produire un `.html` copiable |
| Oublier la checklist screenshots | Toujours terminer par la table des screenshots |
| Se baser uniquement sur le brief | Toujours croiser avec Notion + code local |

$ARGUMENTS
