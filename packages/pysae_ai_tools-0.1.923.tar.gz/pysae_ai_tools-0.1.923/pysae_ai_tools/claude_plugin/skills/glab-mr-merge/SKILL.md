---
name: glab-mr-merge
description: >
  Merge a GitLab merge request via glab CLI.
  Use when the user says /glab-mr-merge, 'merge cette MR', 'merge la MR',
  'fusionne la MR', 'merge !42', or wants to merge an approved MR.
argument-hint: "[optional: MR !IID — defaults to the MR for the current branch]"
allowed-tools:
  - Read
  - Bash
  - Skill
---

Merge a GitLab merge request using the `glab` CLI.

## Required tools

- `glab`

Run `pysae-ai-tools tools require <tools>` before starting; if it exits non-zero, abort and report the install command from stderr to the user.

## Mode detection

Detect the execution context using `detect_context` (pass `$ARGUMENTS` refs for automatic parsing of `!IID`, URLs):
```bash
CTX=$(pysae-ai-tools internal detect-context $ARGUMENTS_REFS)
IS_CI=$(echo "$CTX" | jq -r '.is_ci')
MR_IID=$(echo "$CTX" | jq -r '.mr_iid // empty')
ISSUE_IID=$(echo "$CTX" | jq -r '.issue_iid // empty')
```

Squash and source-branch removal are **not** controlled by this skill: GitLab applies the project-level defaults (`squash_option`, `remove_source_branch_after_merge`). Never pass `--squash` or `--remove-source-branch` on the glab CLI.

## Process

1. **Resolve MR IID** — use `MR_IID` from detect_context above (refs in `$ARGUMENTS` are parsed automatically).
   If `MR_IID` is empty, inform the user and stop.

2. **Inspect the MR state** before merging:
   ```bash
   glab mr view <MR_IID> --output json
   ```
   Check:
   - `state` is `opened` (not `merged`, `closed`, or `locked`)
   - `draft` is `false` — if `true`, mark the MR as ready and continue:
     ```bash
     glab mr update <MR_IID> --ready
     ```
     Never abort on draft state — always flip it and proceed.
   - `has_conflicts` is `false` — if `true`, invoke `/glab-mr-rebase !<MR_IID>`. The sub-skill rebases on the target branch, auto-resolves conflicts (with merge fallback if too divergent), and pushes. After it returns, re-run `glab mr view <MR_IID> --output json` and re-check `has_conflicts`. If still `true` (manual intervention required), report the blocker and stop — do not attempt the merge.
   - `detailed_merge_status` is `mergeable` — if anything else (e.g. `not_approved`, `discussions_not_resolved`, `ci_must_pass`), report the blocker and stop

   In CI mode, any remaining blocker (after auto-handling draft) → exit with non-zero status and report on stderr.

3. **Merge the MR**:
   ```bash
   glab mr merge <MR_IID> --yes
   ```
   Never pass `--auto-merge` — this skill performs an immediate merge; auto-merge is a different flow.

4. **Handle errors**:
   - **405 Method Not Allowed** — the MR is not in a mergeable state (conflicts, missing approvals, failing required pipeline). Re-run step 2 to surface the blocker and report it.
   - **401 / 403** — the caller lacks permission. Report and stop.
   - Any other failure — report `glab` stderr verbatim.

5. **Transition the linked issue** — if `ISSUE_IID` is set (the MR closes a source issue via `Closes #<IID>`), move it to the `To deploy` board column:
   ```bash
   pysae-ai-tools glab workflow-transition "$ISSUE_IID" "workflow::To deploy"
   ```
   If no linked issue is detected, skip silently. Never abort the skill on a transition failure — log the error and continue to the success report.

6. **Report success** — print the merge commit SHA and the MR URL. Mention the issue transition (`#<IID> → workflow::To deploy`) when it occurred.

$ARGUMENTS
