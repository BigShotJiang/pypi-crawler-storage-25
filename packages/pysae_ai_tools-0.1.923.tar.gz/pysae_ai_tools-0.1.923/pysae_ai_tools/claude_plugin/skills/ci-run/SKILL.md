---
name: ci-run
description: >
  Run a GitLab CI job (or chain of dependent jobs) on the current branch or MR pipeline.
  Use when the user says /ci-run, 'lance le deploy', 'run build',
  'lance la pipeline de deploiement', 'status CI', 'ou en est la CI',
  'relance la CI', 'pipeline', 'lance la pipeline', 'lance la CI',
  'run pipeline', 'run CI', 'CI status',
  'ouvre la pipeline', 'ouvre la CI', 'ouvre le job', 'open pipeline', 'open CI',
  or wants to trigger a specific CI job, check pipeline status, or open the pipeline/job in the browser.
argument-hint: "<job name or description, e.g. 'deploy', 'lance le build review'>"
allowed-tools:
  - Read
  - Glob
  - Grep
  - Bash
  - Skill
---

Run a specific GitLab CI job (and its dependencies) on the current branch or MR pipeline.

All heavy lifting is handled by `pysae-ai-tools ci run` — the script resolves pipelines, dependency chains, plays/retries jobs, waits for completion, and reports results as JSON.

## Required tools

- `glab`

Run `pysae-ai-tools tools require <tools>` before starting; if it exits non-zero, abort and report the install command from stderr to the user.

## Run a job

1. **Interpret `$ARGUMENTS`** to determine the target job name. If natural language (e.g. "lance le deploiement en review"), map it to the likely CI job name (e.g. `deploy_review`). Read `.gitlab-ci.yml` if needed to list available jobs.

2. **Run the job chain** — in **local mode**, run in background (`run_in_background: true`) so the user can continue working. In CI mode, run in foreground.
   ```bash
   pysae-ai-tools ci run run <job_name>
   ```
   The script automatically:
   - Finds the latest MR or branch pipeline (creates one if none exists)
   - Lists jobs and fuzzy-matches the target name
   - Parses `.gitlab-ci.yml` to resolve the `needs:` dependency chain
   - Plays/retries each dependency in order, skipping already-succeeded jobs
   - Waits for each job to complete before starting the next
   - Handles `created` → `manual` transition for manual jobs
   - Reports results as JSON with pipeline/job URLs and environment URL

   **Output** (JSON):
   ```json
   {
     "success": true,
     "pipeline_id": 123,
     "pipeline_url": "https://...",
     "target_job": {"id": 456, "name": "deploy_review", "status": "success", "url": "https://..."},
     "environment_url": "https://review-app.example.com",
     "jobs": [{"name": "build_docker", "status": "success", "action": "skipped"}, ...]
   }
   ```

3. **Report to the user** in French when the background command completes:
   - Pipeline link, target job link
   - Environment URL if available
   - If a job failed, delegate to `/ci-debug` for diagnosis

## Pipeline status

If the user asks for pipeline/CI status ("ou en est la pipeline", "status CI"):
```bash
pysae-ai-tools ci run status
```
Returns all jobs grouped by stage. Present as a readable table with the pipeline link.

## Retry full pipeline

```bash
pysae-ai-tools ci run retry
```

## New pipeline (reload templates)

When the user wants a fresh pipeline (re-fetches `include:` templates instead of using cached YAML):
```bash
pysae-ai-tools ci run create
```
Then use the new pipeline for subsequent job triggers.

## Wait for pipeline completion

Poll a pipeline until it reaches a terminal state (success, failed, canceled):
```bash
pysae-ai-tools ci run wait --pipeline-id <PIPELINE_ID>
```
Run in background in local mode. Prints progress to stderr, final JSON to stdout. Exits 1 on failure/timeout.

## Open pipeline/job in the browser

When the user says "ouvre la pipeline", "ouvre la CI", "ouvre le job", or "open pipeline":
1. Get the pipeline URL via `pysae-ai-tools ci run status` (the `pipeline_url` field in JSON output)
2. Open it in the browser:
   ```bash
   xdg-open <pipeline_url>
   ```
   On macOS use `open` instead. If a specific job URL is available, open that instead.

## List available jobs

```bash
pysae-ai-tools ci run jobs
```

## Rules

- **Run the dependency chain automatically** — once the target job is identified, no confirmation needed
- **French** for communication, English for commands
- If `glab` is not available or fails, inform the user and stop
- If the pipeline is too old or stale, suggest creating a new one first

$ARGUMENTS
