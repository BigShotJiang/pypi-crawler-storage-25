---
name: glab-mr-approve
description: >
  Approve a GitLab merge request via glab CLI.
  Use when the user says /glab-mr-approve, 'approve the MR', 'approve cette MR',
  or when delegated from /code-review after an APPROVED verdict.
argument-hint: "[optional: MR !IID — defaults to the MR for the current branch]"
allowed-tools:
  - Read
  - Bash
  - Skill
  - AskUserQuestion
---

Approve a GitLab merge request using the `glab` CLI.

## Required tools

- `glab`

Run `pysae-ai-tools tools require <tools>` before starting; if it exits non-zero, abort and report the install command from stderr to the user.

## Mode detection

Detect the execution context using `detect_context` (pass `$ARGUMENTS` refs for automatic parsing of `!IID`, URLs):
```bash
CTX=$(pysae-ai-tools internal detect-context $ARGUMENTS_REFS)
IS_CI=$(echo "$CTX" | jq -r '.is_ci')
MR_IID=$(echo "$CTX" | jq -r '.mr_iid // empty')
```

In CI mode (`IS_CI` is `true`):
- **Never approve the MR** — exit immediately without error. Approval must come from a human.
- **Never use `AskUserQuestion`**
- **Never invoke `/slack-ask-review`**

## Process

1. **Resolve MR IID** — use `MR_IID` from detect_context above (refs in `$ARGUMENTS` are parsed automatically).
   If `MR_IID` is empty, inform the user and stop.

2. **Confirm manual testing** — **skip this step entirely in CI mode** (proceed directly to step 3).

   In local mode, ask the user to confirm that the MR has been manually tested:
   > La MR !<MR_IID> est prête à être approuvée. As-tu testé manuellement les changements (en local ou sur l'environnement review) ?
   - If the user confirms → proceed to step 3
   - If the user says no or wants to test first:
     1. Invoke the `/ci-deploy-status` skill with `review` to check the review environment
     2. If verdict is `DEPLOYED` → display the review URL so the user can test
     3. If verdict is `NOT_DEPLOYED`, `NO_DEPLOY_JOB`, or `NO_PIPELINE` → invoke `/ci-deploy` with `review` to trigger the deployment, then display the URL once deployed
     4. If verdict is `DEPLOYING` → inform the user the deploy is in progress, provide the pipeline link
     5. If verdict is `DEPLOY_FAILED` or `DEPLOYED_UNHEALTHY` → report the issue, suggest `/ci-debug`
     6. After displaying the URL or deploying, **stop and wait** for the user to test and come back

3. **Approve the MR**:
   ```bash
   glab mr approve <MR_IID>
   ```

4. **Handle errors**:
   - If the approve command returns a **401 error** (unauthorized — e.g. the user is the MR author and cannot self-approve):
     - **Local mode**: fall back to the `/slack-ask-review` skill to request a manual review on Slack.
     - **CI mode**: log the 401 error to stderr and continue — **never invoke `/slack-ask-review` in CI**.
   - If `glab` is not available or any other GitLab command fails, report the error to the user.

$ARGUMENTS
