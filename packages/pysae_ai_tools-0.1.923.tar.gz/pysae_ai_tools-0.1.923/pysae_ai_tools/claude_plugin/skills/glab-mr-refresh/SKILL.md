---
name: glab-mr-refresh
description: >
  Rebase open merge requests on their target branch and restart pipelines.
  Use when the user says /glab-mr-refresh, /mr-refresh, 'rebase mes MR',
  'refresh mes MR', 'mets mes MR a jour', 'rebase toutes les MR',
  or needs to update stale MRs.
argument-hint: "[--author USERNAME] [--all] [--iid IID] to filter MRs"
allowed-tools:
  - Read
  - Edit
  - Glob
  - Grep
  - Bash
  - Skill
  - AskUserQuestion
---

Rebase open merge requests on their target branch and restart their pipelines.

## Required tools

- `glab`

Run `pysae-ai-tools tools require <tools>` before starting; if it exits non-zero, abort and report the install command from stderr to the user.

## Mode detection

Detect the execution context using `detect_context`:
```bash
CTX=$(pysae-ai-tools internal detect-context)
IS_CI=$(echo "$CTX" | jq -r '.is_ci')
MR_IID=$(echo "$CTX" | jq -r '.mr_iid // empty')
PROJECT_PATH=$(echo "$CTX" | jq -r '.project_path // empty')
```

In CI mode (`IS_CI` is `true`):
- **Never use `AskUserQuestion`** — resolve conflicts automatically without asking
- Use `MR_IID` to target the current MR if no `--iid` flag is given

## Step 1 : List open MRs

Use the bundled script to list MRs:
```bash
RESULT=$(pysae-ai-tools glab mr-refresh [--author USERNAME | --all])
```

### Filtering
- **Default** (`--me`): only MRs authored by the current user
- `--author <username>`: MRs by a specific author
- `--all`: all open MRs on the project
- `--iid <IID>`: single MR by IID (skip listing, go directly to Step 2)

Parse `$ARGUMENTS` to determine which flag to pass. If `$ARGUMENTS` contains `--all`, pass `--all`. If it contains `--author <name>`, pass `--author <name>`. Otherwise, use the default (current user).

Display the list to the user:
```
MRs ouvertes (auteur: <username>) :
- !42 feat/add-export (→ main) — "Add CSV export"
- !38 fix/login-bug (→ main) — "Fix login redirect" ⚠️ conflits
```

If there are no MRs, inform the user and stop.

## Step 2 : Rebase each MR

For each MR, in order:

### 2.1 — Delegate the rebase
Invoke `/glab-mr-rebase !<IID>`. The sub-skill handles checkout, fetch, rebase, automatic conflict resolution (with merge fallback if too divergent), and `--force-with-lease` push. Track its outcome:
- **Success** → continue to 2.2
- **Failure** (too many conflicts, push refused, etc.) → record the MR as failed and skip to the next MR. Do not restart its pipeline.

### 2.2 — Restart pipeline
Invoke the `/ci-run` skill with the `start` job (or the first manual job) on the MR pipeline. If no pipeline exists after push, GitLab will create one automatically — wait a few seconds then check.

If the first job in the pipeline is manual, play it.

### 2.3 — Report progress
After each MR, print one line. Reuse the strategy label from `/glab-mr-rebase` and append the pipeline status:
```
✓ !42 feat/add-export — rebase sans conflit, pipeline relancée
✓ !38 fix/login-bug — rebase, conflits résolus, pipeline relancée
✓ !27 refactor/auth — merge fallback, conflits résolus, pipeline relancée
✗ !35 chore/big-bang — échec, intervention manuelle requise
```

## Step 3 : Summary

Print a final summary:
```
Refresh termine :
- 2/3 MRs rebasees et pipelines relancees
- 1 MR avec conflits non resolus (!35)
```

## Gotchas

- **MR en draft** — les traiter comme les autres, elles ont aussi besoin d'être à jour.
- **Pipeline déjà en cours** — si une pipeline tourne déjà après le push, ne pas en relancer une nouvelle.
- **Stacked MRs** — si une MR cible une branche qui est elle-même une source d'une autre MR (stacking), traiter d'abord la MR la plus proche de main, puis remonter la chaîne.

## Rules

- **Language**: messages en français, commandes git/glab en anglais
- **Delegate the rebase to `/glab-mr-rebase`** — ne pas dupliquer la logique de checkout/rebase/conflits/push
- **Delegate pipeline restart to `/ci-run`** — ne pas dupliquer la logique de relance de pipeline

$ARGUMENTS
