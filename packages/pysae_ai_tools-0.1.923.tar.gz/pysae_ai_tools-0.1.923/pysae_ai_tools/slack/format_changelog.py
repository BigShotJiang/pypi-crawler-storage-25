"""Format a CHANGELOG release section as Slack mrkdwn.

Pipeline (matching the legacy ``.send-slack-tag-content`` shell job):

* drop everything before the first ``## [tag] date`` header — this strips the
  redundant tag subject line emitted by ``git tag -a -m TAG -m SECTION``;
* bold the version: ``## [vX.Y.Z] date`` → ``*vX.Y.Z* date``, and linkify the
  version to ``project_url/-/tags/vX.Y.Z`` when ``project_url`` is provided;
* replace markdown bullets ``* `` with Unicode bullets ``• `` (Slack mrkdwn
  does not render markdown bullets in plain ``text`` payloads);
* linkify ``(#NN)`` issue refs as ``(<project_url/-/issues/NN|#NN>)``
  when ``project_url`` is provided.

Inputs that are not CHANGELOG sections (e.g. ``main (abc1234)`` fallbacks)
pass through unchanged — no header means no transformation kicks in.
"""

import re
import sys
from typing import Annotated

import typer

_HEADER_RE = re.compile(r"^## \[([^\]]+)\] (.*)$", re.MULTILINE)
_BULLET_RE = re.compile(r"^\* ", re.MULTILINE)
_ISSUE_REF_RE = re.compile(r"\(#(\d+)\)")
_FIRST_HEADER_RE = re.compile(r"^## \[", re.MULTILINE)


def format_changelog(text: str, project_url: str = "") -> str:
    """Convert a CHANGELOG section to Slack mrkdwn. See module docstring."""
    if not text:
        return text
    header_match = _FIRST_HEADER_RE.search(text)
    if header_match:
        text = text[header_match.start() :]
    if project_url:
        text = _HEADER_RE.sub(
            lambda m: f"*<{project_url}/-/tags/{m.group(1)}|{m.group(1)}>* {m.group(2)}",
            text,
        )
        text = _ISSUE_REF_RE.sub(
            lambda m: f"(<{project_url}/-/issues/{m.group(1)}|#{m.group(1)}>)",
            text,
        )
    else:
        text = _HEADER_RE.sub(r"*\1* \2", text)
    text = _BULLET_RE.sub("• ", text)
    return text


def main(
    project_url: Annotated[
        str,
        typer.Option(
            "--project-url",
            envvar="CI_PROJECT_URL",
            help="GitLab project URL used to build issue links",
        ),
    ] = "",
) -> None:
    """Read a CHANGELOG section from stdin, emit Slack mrkdwn on stdout."""
    sys.stdout.write(format_changelog(sys.stdin.read(), project_url))
