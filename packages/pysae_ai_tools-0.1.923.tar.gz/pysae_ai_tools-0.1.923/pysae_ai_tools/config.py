"""User configuration for pysae-ai-tools.

Paths follow OS conventions via ``platformdirs``:

- Config:   Linux ``~/.config/pysae-ai-tools/`` ;
            macOS ``~/Library/Application Support/pysae-ai-tools/`` ;
            Windows ``~/AppData/Local/pysae-ai-tools/``
- Cache:    Linux ``~/.cache/pysae-ai-tools/`` ;
            macOS ``~/Library/Caches/pysae-ai-tools/`` ;
            Windows ``~/AppData/Local/pysae-ai-tools/Cache/``
- Data:     Linux ``~/.local/share/pysae-ai-tools/`` ;
            macOS ``~/Library/Application Support/pysae-ai-tools/`` ;
            Windows ``~/AppData/Local/pysae-ai-tools/``

Read/write goes through ``tomlkit`` which preserves comments and formatting.
The config file is created with default values on first access. Existing
files are auto-migrated: any expected key missing from the file is appended
with its comment block on the next read. Unknown keys are ignored.
"""

from collections.abc import Callable, Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import tomlkit
from platformdirs import user_cache_path, user_config_path, user_data_path
from tomlkit import TOMLDocument, comment, document, item, nl
from tomlkit.exceptions import TOMLKitError

_APP_NAME = "pysae-ai-tools"

CONFIG_DIR = user_config_path(_APP_NAME)
CONFIG_FILE = CONFIG_DIR / "config.toml"
CACHE_DIR = user_cache_path(_APP_NAME)
DATA_DIR = user_data_path(_APP_NAME)


_DefaultValue = bool | int | float | str | list[str] | None


@dataclass(frozen=True)
class _ExpectedKey:
    name: str
    comment: str  # multi-line, no leading "# "
    default: _DefaultValue  # value used when the key is missing; None = absent-by-design


_EXPECTED: tuple[_ExpectedKey, ...] = (
    _ExpectedKey(
        name="auto_update",
        comment=(
            "Automatically install updates when a newer version is detected.\n"
            "When false, a notification is shown instead and you update manually\n"
            "with `pysae-ai-tools self-update`."
        ),
        default=True,
    ),
    _ExpectedKey(
        name="git_clone_dir",
        comment=(
            "Base directory where Pysae projects are cloned by\n"
            "`pysae-ai-tools code ensure-repo` and the support-* skills.\n"
            "Empty string = ask interactively on first use, fall back to the\n"
            "OS-standard data dir when running non-interactively.\n"
            "The PYSAE_AI_TOOLS_GIT_CLONE_DIR env var, when set, takes precedence."
        ),
        default="",
    ),
    _ExpectedKey(
        name="chrome_mcp_auto_connect",
        comment=(
            "Préférence MCP Chrome : true branche le MCP sur la session Chrome\n"
            "ouverte (--autoConnect) ; false (défaut) lance une session Chrome\n"
            "isolée à chaque appel. Prérequis 'true' : Chrome 144+ avec remote\n"
            "debugging activé — ouvre chrome://inspect/#remote-debugging et\n"
            "coche « Allow remote debugging for this browser instance »."
        ),
        default=False,
    ),
    _ExpectedKey(
        name="tools_to_install",
        comment=(
            "List of tools selected for `pysae-ai-tools tools install`.\n"
            "Set interactively the first time you run the command, or with the\n"
            "--configure flag. Tools not in this list are skipped (but still\n"
            "detected if already installed manually)."
        ),
        # Default left absent so first-run can prompt the user.
        default=None,
    ),
    _ExpectedKey(
        name="tools_known_at_save",
        comment=(
            "List of tools that existed when `tools_to_install` was last saved.\n"
            "Used to distinguish 'tool was explicitly deselected last time' from\n"
            "'tool didn't exist yet': a tool currently in TOOLS but absent from\n"
            "this list is treated as new and falls back to its default_selected\n"
            "value rather than being silently unchecked."
        ),
        default=None,
    ),
)


@dataclass(frozen=True)
class Config:
    auto_update: bool = True
    git_clone_dir: str = ""
    chrome_mcp_auto_connect: bool = False


# ---------------------------------------------------------------------------
# Configurable parameters — interactive prompts in `tools configure`
# ---------------------------------------------------------------------------

ParamKind = Literal["bool", "string", "path"]
ParamValue = bool | str


@dataclass(frozen=True)
class ConfigParam:
    """A user-facing configuration parameter prompted in ``tools configure``.

    The phase-2 step of ``tools configure`` walks ``CONFIG_PARAMS`` and asks
    one question per relevant entry, pre-filling the current value as
    default. Stored alongside the rest of the user config in
    ``config.toml`` — never in env-cache, never in env vars.

    ``relevant_when_tool``: when set, the parameter is only surfaced if the
    matching tool is part of the user's selected install set. ``None`` means
    "always relevant".
    """

    name: str
    kind: ParamKind
    default_factory: Callable[[], ParamValue]
    description: str
    prompt: str
    relevant_when_tool: str | None = None


CONFIG_PARAMS: tuple[ConfigParam, ...] = (
    ConfigParam(
        name="git_clone_dir",
        kind="path",
        # Empty string = "use OS default" — preserved for back-compat with
        # callers that special-case that sentinel. The interactive prompt
        # resolves it to ``os_default_clone_dir()`` for display.
        default_factory=lambda: "",
        description="Répertoire racine où sont clonés les projets Pysae",
        prompt="📂 Où veux-tu cloner les projets Pysae ?",
    ),
    ConfigParam(
        name="chrome_mcp_auto_connect",
        kind="bool",
        default_factory=lambda: False,
        description="Brancher le MCP Chrome sur la session Chrome ouverte (--autoConnect)",
        prompt=(
            "🔌 Préférence MCP Chrome : auto-connect à la session Chrome ouverte ?\n"
            "   true  = se branche sur la session existante via --autoConnect\n"
            "   false = lance une session Chrome isolée à chaque appel\n"
            "   Prérequis 'true' : Chrome 144+ avec remote debugging activé "
            "(chrome://inspect/#remote-debugging)."
        ),
        relevant_when_tool="chrome-mcp",
    ),
)


def iter_params(*, tools_selected: set[str] | None = None) -> Iterator[ConfigParam]:
    """Yield params relevant to ``tools_selected`` (or all when ``None``)."""
    for p in CONFIG_PARAMS:
        if p.relevant_when_tool is None:
            yield p
            continue
        if tools_selected is None or p.relevant_when_tool in tools_selected:
            yield p


def get_param_spec(name: str) -> ConfigParam:
    spec = next((p for p in CONFIG_PARAMS if p.name == name), None)
    if spec is None:
        raise KeyError(f"unknown config parameter: {name}")
    return spec


def get_param(name: str, path: Path | None = None) -> ParamValue:
    """Return the persisted value for ``name`` (or its default when absent)."""
    spec = get_param_spec(name)
    doc = _load_doc(path)
    raw = doc.get(name)
    if raw is None:
        return spec.default_factory()
    if spec.kind == "bool":
        return bool(raw)
    return str(raw)


def set_param(name: str, value: ParamValue, path: Path | None = None) -> None:
    """Persist ``value`` for parameter ``name`` to ``config.toml``."""
    spec = get_param_spec(name)
    if spec.kind == "bool":
        coerced: ParamValue = bool(value)
    else:
        coerced = str(value)
    doc = _load_doc(path)
    _upsert_key(doc, name, coerced)
    _save_doc(doc, path)


def os_default_clone_dir() -> Path:
    """Return the OS-standard data directory for cloned Pysae projects.

    Linux:   ~/.local/share/pysae-ai-tools/projects
    macOS:   ~/Library/Application Support/pysae-ai-tools/projects
    Windows: ~/AppData/Local/pysae-ai-tools/projects
    """
    return user_data_path(_APP_NAME) / "projects"


def _new_default_doc() -> TOMLDocument:
    doc = document()
    doc.add(comment("Pysae AI tools — user configuration"))
    doc.add(comment(""))
    doc.add(comment("This file is created automatically on first run. Missing keys are"))
    doc.add(comment("auto-appended on subsequent reads. Edit freely; unknown keys are"))
    doc.add(comment("ignored and missing keys fall back to defaults."))
    for entry in _EXPECTED:
        if entry.default is None:
            continue  # absent-by-design (e.g. tools_to_install)
        doc.add(nl())
        for line in entry.comment.splitlines():
            doc.add(comment(line))
        doc.add(entry.name, item(entry.default))
    return doc


def _load_doc(path: Path | None = None) -> TOMLDocument:
    """Read the config file as a tomlkit Document, creating defaults on first access.

    Returns a fresh default Document when the file is missing or unreadable.
    Auto-appends any expected key (with default value) that is missing from
    an existing file.
    """
    target = path if path is not None else CONFIG_FILE
    try:
        if path is None:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            doc = _new_default_doc()
            target.write_text(tomlkit.dumps(doc), encoding="utf-8")
            return doc
        try:
            doc = tomlkit.parse(target.read_text(encoding="utf-8"))
        except TOMLKitError:
            return _new_default_doc()

        appended = False
        for entry in _EXPECTED:
            if entry.default is None:
                continue
            if entry.name in doc:
                continue
            doc.add(nl())
            for line in entry.comment.splitlines():
                doc.add(comment(line))
            doc.add(entry.name, item(entry.default))
            appended = True
        if appended:
            try:
                target.write_text(tomlkit.dumps(doc), encoding="utf-8")
            except OSError:
                pass
        return doc
    except OSError:
        return _new_default_doc()


def _save_doc(doc: TOMLDocument, path: Path | None = None) -> None:
    target = path if path is not None else CONFIG_FILE
    try:
        if path is None:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        target.write_text(tomlkit.dumps(doc), encoding="utf-8")
    except OSError:
        pass


def load_config(path: Path | None = None) -> Config:
    """Load the user config, creating the default file or migrating it if needed."""
    doc = _load_doc(path)
    return Config(
        auto_update=bool(doc.get("auto_update", True)),
        git_clone_dir=str(doc.get("git_clone_dir", "") or ""),
        chrome_mcp_auto_connect=bool(doc.get("chrome_mcp_auto_connect", False)),
    )


def set_git_clone_dir(value: str, path: Path | None = None) -> None:
    """Persist a new value for ``git_clone_dir`` to the config file."""
    doc = _load_doc(path)
    doc["git_clone_dir"] = value
    _save_doc(doc, path)


def get_tools_to_install(path: Path | None = None) -> list[str] | None:
    """Return the persisted tool selection, or ``None`` when the key is absent.

    The absence sentinel is what lets the install command know it should
    prompt on first run. An empty list means "configured to install nothing".
    """
    doc = _load_doc(path)
    value = doc.get("tools_to_install")
    if value is None:
        return None
    if not isinstance(value, list):
        return None
    return [str(v) for v in value]


def set_tools_to_install(
    value: list[str],
    *,
    known: list[str] | None = None,
    path: Path | None = None,
) -> None:
    """Persist the selected tool list and the snapshot of currently-known tools.

    ``known`` records every tool that was visible to the user at this save
    time (typically every entry in ``TOOLS``). On a future configure run,
    a tool present in ``TOOLS`` but absent from ``tools_known_at_save``
    can be detected as new and fall back to its ``default_selected`` value
    instead of being silently treated as deselected.
    """
    doc = _load_doc(path)
    _upsert_key(doc, "tools_to_install", list(value))
    if known is not None:
        _upsert_key(doc, "tools_known_at_save", list(known))
    _save_doc(doc, path)


def _upsert_key(doc: TOMLDocument, key: str, value: bool | int | float | str | list[str]) -> None:
    if key in doc:
        doc[key] = value
        return
    spec = next(e for e in _EXPECTED if e.name == key)
    doc.add(nl())
    for line in spec.comment.splitlines():
        doc.add(comment(line))
    doc.add(key, item(value))


def get_tools_known_at_save(path: Path | None = None) -> list[str] | None:
    """Return the tools known at the last configure save, or ``None`` when absent.

    ``None`` means the user hasn't configured yet (or has only ever saved
    under the legacy schema that didn't include this key) — callers should
    treat that as "no known set, every tool is potentially new".
    """
    doc = _load_doc(path)
    value = doc.get("tools_known_at_save")
    if value is None or not isinstance(value, list):
        return None
    return [str(v) for v in value]
