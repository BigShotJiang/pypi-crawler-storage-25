"""Parse GitLab CI YAML to extract effective ``needs:`` per job.

Handles ``extends:`` chains and tolerates GitLab-specific tags (``!reference``)
that PyYAML's default loader rejects.
"""

import sys
from typing import Any

import yaml

# Top-level keys that are not jobs.
RESERVED_TOP_LEVEL = {
    "stages",
    "variables",
    "default",
    "include",
    "workflow",
    "image",
    "services",
    "cache",
    "before_script",
    "after_script",
    "spec",
}


class _GitLabLoader(yaml.SafeLoader):
    """SafeLoader that tolerates GitLab CI's custom tags."""


def _construct_passthrough(loader: yaml.Loader, node: yaml.Node) -> Any:
    """Construct any node as plain Python data, ignoring the tag."""
    if isinstance(node, yaml.ScalarNode):
        return loader.construct_scalar(node)
    if isinstance(node, yaml.SequenceNode):
        return loader.construct_sequence(node, deep=True)
    if isinstance(node, yaml.MappingNode):
        return loader.construct_mapping(node, deep=True)
    return None


_GitLabLoader.add_constructor("!reference", _construct_passthrough)
# Catch-all for any other GitLab-specific tag (e.g. ``!flatten``) so we don't crash.
# PyYAML accepts ``None`` as a sentinel for unknown tags; the stubs lag behind.
_GitLabLoader.add_constructor(None, _construct_passthrough)  # type: ignore[arg-type]


def parse_yaml(content: str) -> dict[str, Any]:
    """Parse a GitLab YAML document. Returns ``{}`` on failure."""
    if not content:
        return {}
    try:
        data = yaml.load(content, Loader=_GitLabLoader)
    except yaml.YAMLError as exc:
        print(f"YAML parse error: {exc}", file=sys.stderr)
        return {}
    return data if isinstance(data, dict) else {}


def merge_jobs(documents: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """Merge multiple parsed YAML docs into a single jobs map.

    Documents are merged in order; later ones override earlier ones (matches
    GitLab's ``include:`` semantics where the local config overrides templates).
    Reserved top-level keys are excluded. Hidden templates (``.foo``) are kept
    so that ``extends:`` resolution can follow them.
    """
    jobs: dict[str, dict[str, Any]] = {}
    for doc in documents:
        if not isinstance(doc, dict):
            continue
        for name, body in doc.items():
            if not isinstance(name, str) or name in RESERVED_TOP_LEVEL:
                continue
            if not isinstance(body, dict):
                continue
            jobs[name] = body
    return jobs


def _normalize_needs(needs: Any) -> list[str]:
    """Convert a ``needs:`` directive (any GitLab form) into a list of job names.

    Cross-project / cross-pipeline ``needs:`` (which carry ``project:`` or
    ``pipeline:`` keys) are dropped because the referenced job lives in a
    different pipeline and cannot be triggered locally.
    """
    if needs is None:
        return []
    if isinstance(needs, str):
        return [needs]
    if not isinstance(needs, list):
        return []

    out: list[str] = []
    for item in needs:
        if isinstance(item, str):
            out.append(item)
        elif isinstance(item, dict):
            if "project" in item or "pipeline" in item:
                continue
            job = item.get("job")
            if isinstance(job, str):
                out.append(job)
    return out


def effective_needs(name: str, jobs: dict[str, dict[str, Any]]) -> list[str]:
    """Return the effective ``needs:`` list for a job, following ``extends:``.

    Returns an empty list when the job has no ``needs:`` (directly or
    through any ``extends:`` parent).
    """
    resolved = _resolve_needs(name, jobs, set())
    return resolved if resolved is not None else []


def _resolve_needs(name: str, jobs: dict[str, dict[str, Any]], visited: set[str]) -> list[str] | None:
    if name in visited or name not in jobs:
        return None
    visited.add(name)
    job = jobs[name]

    if "needs" in job:
        return _normalize_needs(job["needs"])

    extends = job.get("extends")
    parents: list[str] = []
    if isinstance(extends, str):
        parents = [extends]
    elif isinstance(extends, list):
        parents = [p for p in extends if isinstance(p, str)]

    for parent in parents:
        inherited = _resolve_needs(parent, jobs, visited)
        if inherited is not None:
            return inherited
    return None


def parse_includes(content: str) -> list[dict[str, Any]]:
    """Extract the ``include:`` block of a GitLab YAML as a normalized list.

    Supported entry forms:
        - string ``"path/to/file.yml"`` → ``{"local": ...}``
        - mapping with ``project`` + ``file`` + optional ``ref``
        - mapping with ``local`` (path inside the current repo)
        - mapping with ``remote`` (HTTP URL — recorded but not fetched here)
        - mapping with ``template`` (GitLab-managed templates — recorded only)
    """
    data = parse_yaml(content)
    raw = data.get("include")
    if raw is None:
        return []
    if isinstance(raw, (str, dict)):
        raw = [raw]
    if not isinstance(raw, list):
        return []

    out: list[dict[str, Any]] = []
    for entry in raw:
        if isinstance(entry, str):
            out.append({"local": entry})
        elif isinstance(entry, dict):
            out.append(dict(entry))
    return out
