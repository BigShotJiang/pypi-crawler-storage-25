"""Scan a skill directory and produce a structured report for review.

Used by the ``clawd-skill-review`` skill — replaces the previous shell
script under ``claude_plugin/skills/clawd-skill-review/scripts/``.
"""

import re
import sys
from pathlib import Path
from typing import Annotated

import typer

# Patterns flagged as potential hardcoded values worth turning into config.
_HARDCODED_PATTERN = re.compile(r"[A-Z][A-Z0-9]{6,}|C[0-9A-Z]{10}|https?://[^ ]+")


def main(
    skill_dir: Annotated[Path, typer.Argument(help="Path to the skill directory to scan")],
) -> None:
    """Scan a skill directory and print a structured report on stdout."""
    if not skill_dir.is_dir():
        print(f"ERROR: {skill_dir} is not a directory", file=sys.stderr)
        raise typer.Exit(code=1)

    skill_name = skill_dir.name
    skill_md = skill_dir / "SKILL.md"

    print(f"=== SKILL: {skill_name} ===\n")

    # --- File inventory ---
    print("## File inventory")
    files = sorted(p for p in skill_dir.rglob("*") if p.is_file())
    for f in files:
        rel = f.relative_to(skill_dir)
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
            lines = text.count("\n") + (1 if text and not text.endswith("\n") else 0)
        except OSError:
            lines = 0
        try:
            size = f.stat().st_size
        except OSError:
            size = 0
        print(f"  {rel}  ({lines} lines, {size}B)")
    print()

    # --- Structure signals ---
    print("## Structure signals")

    # Scripts present? (excluding self)
    self_path = Path(__file__).resolve()
    script_count = sum(1 for f in files if f.suffix in {".sh", ".py", ".js", ".ts"} and f.resolve() != self_path)
    print(f"  scripts: {script_count}")

    references_dir = skill_dir / "references"
    if references_dir.is_dir():
        ref_files = [p for p in references_dir.rglob("*") if p.is_file()]
        if ref_files:
            print(f"  references/: {len(ref_files)} files")
        else:
            print("  references/: EMPTY (directory exists but contains no files)")
    else:
        print("  references/: absent")

    assets_dir = skill_dir / "assets"
    if assets_dir.is_dir():
        asset_files = [p for p in assets_dir.rglob("*") if p.is_file()]
        print(f"  assets/: {len(asset_files)} files")
    else:
        print("  assets/: absent")

    print(f"  config.json: {'present' if (skill_dir / 'config.json').is_file() else 'absent'}")
    print()

    # --- SKILL.md analysis ---
    if not skill_md.is_file():
        print("  WARNING: No SKILL.md found!")
        return

    md_text = skill_md.read_text(encoding="utf-8", errors="replace")
    md_lines = md_text.splitlines()
    print("## SKILL.md metrics")
    print(f"  total_lines: {len(md_lines)}")

    # Frontmatter description (between first and second --- delimiter)
    description_present = _has_description_field(md_lines)
    print(f"  description_field: {'present' if description_present else 'MISSING'}")

    # Section detection
    print()
    print("## Sections detected")
    for idx, line in enumerate(md_lines, start=1):
        if line.startswith("## "):
            print(f"  {idx}:{line}")

    print()
    print("## Content signals")

    md_lower = md_text.lower()
    has_gotchas_section = any(line.startswith("## Gotchas") for line in md_lines)
    print(f"  has_gotchas_section: {'yes' if has_gotchas_section else 'no'}")
    print(f"  gotchas_mentions: {md_lower.count('gotcha')}")
    print(f"  example_mentions: {md_lower.count('example')}")
    hook_mentions = md_lower.count("hook") + md_lower.count("pretooluse") + md_lower.count("posttooluse")
    print(f"  hook_mentions: {hook_mentions}")

    # Skill references like /skill-name
    skill_refs = len(re.findall(r"/[a-z][-a-z]+", md_text))
    print(f"  skill_references: {skill_refs}")

    memory_pattern = re.compile(r"CLAUDE_PLUGIN_DATA|\.log|\.jsonl|history|persist", re.IGNORECASE)
    print(f"  memory_mentions: {len(memory_pattern.findall(md_text))}")

    dual_pattern = re.compile(r"CI.*mode|headless|local.*mode|interactive.*mode", re.IGNORECASE)
    print(f"  dual_mode_mentions: {len(dual_pattern.findall(md_text))}")

    # Hardcoded value scan — SKILL.md + every .md under references/
    scan_targets: list[Path] = [skill_md]
    if references_dir.is_dir():
        scan_targets.extend(sorted(references_dir.rglob("*.md")))

    total = 0
    for ref_file in scan_targets:
        if not ref_file.is_file():
            continue
        text = ref_file.read_text(encoding="utf-8", errors="replace")
        count = sum(1 for _ in _HARDCODED_PATTERN.finditer(text))
        if count > 0:
            rel = ref_file.relative_to(skill_dir)
            print(f"  hardcoded_in {rel}: {count}")
        total += count
    print(f"  potential_hardcoded_values_total: {total}")

    print(f"\n=== END {skill_name} ===")


def _has_description_field(md_lines: list[str]) -> bool:
    """True if the YAML frontmatter contains a ``description:`` line."""
    if not md_lines or md_lines[0].strip() != "---":
        return False
    for line in md_lines[1:]:
        if line.strip() == "---":
            return False
        if line.startswith("description:"):
            return True
    return False


if __name__ == "__main__":
    typer.run(main)
