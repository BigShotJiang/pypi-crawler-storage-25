"""Self-update pysae-ai-tools.

Two modes:
- **Git clone** (editable install): ``git pull`` + re-run ``install.sh``
- **PyPI install** (via uv): ``uv tool upgrade pysae-ai-tools``
"""

import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Annotated

import typer

import pysae_ai_tools

PACKAGE = "pysae-ai-tools"


def _repo_root() -> Path | None:
    """Return the repo root if running from a git checkout, else None."""
    pkg_dir = Path(pysae_ai_tools.__file__).resolve().parent
    candidate = pkg_dir.parent
    if (candidate / ".git").exists() and (candidate / "install.sh").exists():
        return candidate
    return None


def _run(cmd: list[str], cwd: Path | None = None) -> int:
    print(f"$ {' '.join(cmd)}", file=sys.stderr)
    return subprocess.run(cmd, cwd=cwd).returncode


def _update_from_git(repo: Path, no_pull: bool, rebase: bool) -> None:
    """Update from git clone: pull + reinstall."""
    if not no_pull:
        pull_args = ["git", "-C", str(repo), "pull"]
        pull_args.append("--rebase" if rebase else "--ff-only")
        if _run(pull_args) != 0:
            print("FAILED: git pull failed. Resolve manually and retry.", file=sys.stderr)
            sys.exit(1)

    is_windows = os.name == "nt"
    ps1 = repo / "install.ps1"
    sh = repo / "install.sh"

    if is_windows and ps1.exists():
        rc = _run(["powershell", "-ExecutionPolicy", "Bypass", "-File", str(ps1)])
    elif sh.exists():
        rc = _run(["bash", str(sh)])
    else:
        print(f"FAILED: no installer found in {repo}", file=sys.stderr)
        sys.exit(1)

    if rc != 0:
        print("FAILED: installer exited with errors.", file=sys.stderr)
        sys.exit(rc)


def _schedule_windows_deferred_upgrade() -> bool:
    """Spawn a detached cmd that finishes the upgrade after we exit.

    On Windows the running ``pysae-ai-tools.exe`` shim is locked, so
    ``uv tool upgrade`` succeeds at updating the venv but fails to copy
    the new shim onto the old one (os error 32). The bat polls for our
    PID, then re-runs the upgrade, the plugin install, and shell
    completion using the freshly-copied shim.
    """
    if os.name != "nt":
        return False

    pid = os.getpid()
    work_dir = tempfile.mkdtemp(prefix="pysae-update-")
    bat = os.path.join(work_dir, "update.cmd")
    log = os.path.join(work_dir, "update.log")

    # Cap the polling loop so a wedged parent never leaves an orphan
    # cmd spinning forever.
    max_polls = 60

    lines = [
        "@echo off",
        # UTF-8 codepage so paths with accented characters (e.g. RémiAlvergnat)
        # are interpreted correctly by cmd.
        "chcp 65001 >nul",
        "setlocal enabledelayedexpansion",
        "set /a tries=0",
        "timeout /t 3 /nobreak >nul",
        ":wait",
        f'tasklist /FI "PID eq {pid}" 2>nul | find "{pid}" >nul',
        "if errorlevel 1 goto :run",
        "set /a tries+=1",
        f"if !tries! geq {max_polls} goto :run",
        "timeout /t 1 /nobreak >nul",
        "goto wait",
        ":run",
        "timeout /t 1 /nobreak >nul",
        f'uv tool upgrade {PACKAGE} >> "{log}" 2>&1',
        f'pysae-ai-tools tools install claude-plugin >> "{log}" 2>&1',
        f'pysae-ai-tools install-completion >> "{log}" 2>&1',
    ]
    script = "\r\n".join(lines) + "\r\n"
    with open(bat, "w", encoding="utf-8", newline="") as f:
        f.write(script)

    # CREATE_NO_WINDOW gives the cmd a hidden console; child commands
    # invoked from inside the bat (tasklist, find, uv …) inherit that
    # hidden console instead of getting a fresh visible one each time.
    # DETACHED_PROCESS would *strip* the console entirely, and Windows
    # then has to spawn a new visible console for every console-app
    # subcommand — the polling loop alone would flash dozens of cmd
    # windows. CREATE_NEW_PROCESS_GROUP keeps the child alive across a
    # Ctrl-C in the parent shell. stdio is rerouted to DEVNULL so the
    # child can't latch onto the parent's handles.
    # Hard-coded constants (rather than ``subprocess.CREATE_NO_WINDOW``)
    # so type-checking on non-Windows hosts doesn't flag missing attrs.
    create_no_window = 0x08000000
    create_new_process_group = 0x00000200
    try:
        subprocess.Popen(
            ["cmd", "/c", bat],
            creationflags=create_no_window | create_new_process_group,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
        )
    except OSError as exc:
        print(f"Failed to schedule deferred upgrade: {exc}", file=sys.stderr)
        return False

    print(f"Log: {log}", file=sys.stderr)
    return True


def _is_windows_lock_error(stdout: str, stderr: str) -> bool:
    """True when uv's failure is the running-shim file lock (locale-agnostic).

    uv surfaces the underlying ``io::Error`` whose ``Display`` impl ends with
    ``(os error 32)`` — Windows ``ERROR_SHARING_VIOLATION``. The
    accompanying message (``The process cannot access the file because…`` /
    ``Le processus ne peut pas accéder au fichier…``) is locale-translated
    by Windows, so we anchor on the numeric code only.
    """
    return "os error 32" in (stdout + stderr).lower()


def _uv_upgrade_actually_upgraded(stdout: str, stderr: str) -> bool:
    """Did ``uv tool upgrade`` actually move the package to a newer version?

    uv prints ``Updated <package> v<old> -> v<new>`` on a real upgrade and
    ``Nothing to upgrade`` (or similar) when the package was already at the
    latest. We only need the plugin reinstall + completion refresh in the
    real-upgrade case.
    """
    combined = f"{stdout}\n{stderr}".lower()
    return f"updated {PACKAGE}" in combined


def _print_upgrade_summary_only(stdout: str, stderr: str) -> None:
    """Print only uv's "Updated <pkg> v<old> -> v<new>" / "Downloaded …"
    progress lines, dropping the noisy "error: Failed to upgrade …
    Caused by: …" trailer that follows when uv hit the running-shim
    file lock on Windows. The deferred update we schedule next will
    finish the job, so the error is misleading.
    """
    skip_markers = ("error:", "  Caused by:")
    for line in stdout.splitlines():
        sys.stdout.write(line + "\n")
    for line in stderr.splitlines():
        if line.startswith(skip_markers):
            continue
        sys.stderr.write(line + "\n")


def _update_from_pypi() -> None:
    """Update from PyPI via uv tool upgrade."""
    print("Updating from PyPI...", file=sys.stderr)

    cmd = ["uv", "tool", "upgrade", PACKAGE]
    print(f"$ {' '.join(cmd)}", file=sys.stderr)
    result = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8")

    if result.returncode != 0:
        # Windows file-lock case: the venv was upgraded but uv couldn't
        # overwrite the running shim. Hide uv's misleading "error: Failed
        # to upgrade" trailer (the deferred re-run we schedule next will
        # finish the job) and surface our own clean status message.
        if os.name == "nt" and _is_windows_lock_error(result.stdout, result.stderr):
            if _schedule_windows_deferred_upgrade():
                _print_upgrade_summary_only(result.stdout, result.stderr)
                print(
                    "\nThe upgrade will finish a few seconds after this process exits "
                    "(uv can't overwrite the running shim — deferring).",
                    file=sys.stderr,
                )
                print(
                    "Wait ~10s before running pysae-ai-tools again.",
                    file=sys.stderr,
                )
                return
        # All other failures: surface uv's full output verbatim.
        sys.stdout.write(result.stdout)
        sys.stderr.write(result.stderr)
        print("FAILED: uv tool upgrade failed.", file=sys.stderr)
        sys.exit(result.returncode)

    # Successful upgrade — show uv's full output.
    sys.stdout.write(result.stdout)
    sys.stderr.write(result.stderr)

    # Skills + plugin manifest live inside the package, so when uv tool
    # upgrade was a no-op nothing on disk changed — no point re-running
    # the plugin install or the completion refresh.
    if not _uv_upgrade_actually_upgraded(result.stdout, result.stderr):
        print("Already at the latest version — skipping plugin reinstall.", file=sys.stderr)
        return

    # Reinstall Claude Code plugin with the new version
    print("Updating Claude Code plugin...", file=sys.stderr)
    _run(["pysae-ai-tools", "tools", "install", "claude-plugin"])

    # Update shell completion
    from .install_completion import install_completion

    install_completion()


def main(
    no_pull: Annotated[bool, typer.Option("--no-pull", help="Skip git pull (only re-run installer)")] = False,
    rebase: Annotated[bool, typer.Option("--rebase", help="Use 'git pull --rebase' instead of '--ff-only'")] = False,
) -> None:
    """Update pysae-ai-tools to the latest version."""
    # Inherited by every child process we spawn (uv, tools install claude-plugin,
    # install_completion). Suppresses the version-check banner during the
    # update — otherwise the still-cached "Update available" message gets
    # re-printed by sub-invocations before the cache is cleared.
    os.environ["PYSAE_SKIP_VERSION_CHECK"] = "1"

    repo = _repo_root()

    if repo:
        print(f"Git checkout detected at {repo}", file=sys.stderr)
        _update_from_git(repo, no_pull, rebase)
    else:
        _update_from_pypi()

    print("\npysae-ai-tools is up to date.", file=sys.stderr)
