"""Install or update AWS CLI v2."""

import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

import httpx
import typer

from .common import binary, platform
from .common.base import BinaryTool, InstallReport
from .common.download import download, extract


class AwsCliTool(BinaryTool):
    name = "aws-cli"
    binary_name = "aws"
    cli_help = "Install/update the AWS CLI and configure SSO profiles"
    winget_package = "Amazon.AWSCLI"
    brew_package = "awscli"

    def fetch_latest_version(self) -> str:
        r = httpx.get("https://api.github.com/repos/aws/aws-cli/tags?per_page=1", timeout=5.0, follow_redirects=True)
        r.raise_for_status()
        data = r.json()
        if isinstance(data, list) and data:
            name = data[0].get("name", "")
            return str(name) if isinstance(name, str) else ""
        return ""

    def check_auth(self) -> dict[str, Any] | None:
        if not binary.which(self.binary_name):
            return {"auth_ok": False, "auth_message": "aws not installed", "profiles": []}
        try:
            r = subprocess.run(
                [self.binary_name, "sts", "get-caller-identity"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                check=False,
                timeout=10,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            return {"auth_ok": False, "auth_message": f"sts get-caller-identity failed: {exc}", "profiles": []}
        try:
            profiles_r = subprocess.run(
                [self.binary_name, "configure", "list-profiles"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                check=False,
                timeout=5,
            )
            profiles = [line.strip() for line in profiles_r.stdout.splitlines() if line.strip()]
        except (OSError, subprocess.TimeoutExpired):
            profiles = []
        return {
            "auth_ok": r.returncode == 0,
            "auth_message": (r.stdout + r.stderr).strip(),
            "profiles": profiles,
        }

    def _finalize(self, path: str) -> InstallReport:
        if sys.platform != "win32":
            shutil.which(self.binary_name)
        installed_v = binary.get_version(self.binary_name, version_arg="--version")
        return InstallReport(version=installed_v, path=path)

    def install_linux(self, plat: platform.Platform) -> InstallReport:
        with tempfile.TemporaryDirectory(prefix="pysae-aws-") as tmp_dir:
            tmp = Path(tmp_dir)
            arch_token = "x86_64" if plat.arch.value == "x86_64" else "aarch64"
            url = f"https://awscli.amazonaws.com/awscli-exe-linux-{arch_token}.zip"
            archive = tmp / "awscliv2.zip"
            try:
                download(url, archive)
                extract(archive, tmp / "awscli")
            except Exception as exc:  # noqa: BLE001
                return InstallReport(error=f"download/extract failed: {exc}")
            installer = tmp / "awscli" / "aws" / "install"
            installer.chmod(0o755)
            r = subprocess.run(
                ["sudo", str(installer), "--update"], capture_output=True, text=True, encoding="utf-8", check=False
            )
            if r.returncode != 0:
                r = subprocess.run(
                    ["sudo", str(installer)], capture_output=True, text=True, encoding="utf-8", check=False
                )
            if r.returncode != 0:
                return InstallReport(error=r.stderr.strip() or r.stdout.strip())
        return self._finalize(binary.which(self.binary_name) or "/usr/local/bin/aws")

    def install_macos(self, plat: platform.Platform) -> InstallReport:
        with tempfile.TemporaryDirectory(prefix="pysae-aws-") as tmp_dir:
            pkg = Path(tmp_dir) / "AWSCLIV2.pkg"
            try:
                download("https://awscli.amazonaws.com/AWSCLIV2.pkg", pkg)
            except Exception as exc:  # noqa: BLE001
                return InstallReport(error=f"download failed: {exc}")
            r = subprocess.run(
                ["sudo", "installer", "-pkg", str(pkg), "-target", "/"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                check=False,
            )
            if r.returncode != 0:
                return InstallReport(error=r.stderr.strip() or r.stdout.strip())
        return self._finalize(binary.which(self.binary_name) or "/usr/local/bin/aws")

    def install_windows(self, plat: platform.Platform) -> InstallReport:
        with tempfile.TemporaryDirectory(prefix="pysae-aws-") as tmp_dir:
            msi = Path(tmp_dir) / "AWSCLIV2.msi"
            try:
                download("https://awscli.amazonaws.com/AWSCLIV2.msi", msi)
            except Exception as exc:  # noqa: BLE001
                return InstallReport(error=f"download failed: {exc}")
            r = subprocess.run(
                ["msiexec", "/i", str(msi), "/qn", "/norestart"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                check=False,
            )
            if r.returncode != 0:
                return InstallReport(error=f"msiexec exited {r.returncode}: {r.stderr.strip() or r.stdout.strip()}")
            default = Path(os.environ.get("ProgramFiles", r"C:\\Program Files")) / "Amazon" / "AWSCLIV2" / "aws.exe"
        return self._finalize(binary.which(self.binary_name) or str(default))

    def extract_identity(self, state: dict[str, Any]) -> list[tuple[str, str | None]]:
        lines: list[tuple[str, str | None]] = []
        msg = str(state.get("auth_message", ""))
        m = re.search(r'"Arn":\s*"arn:aws:iam::(\d+):user/([^"]+)"', msg)
        if m:
            lines.append((f"{m.group(2)} (account {m.group(1)})", typer.colors.BRIGHT_BLACK))
        for p in state.get("profiles", []):
            lines.append((f"  profile: {p}", typer.colors.BRIGHT_BLACK))
        return lines


_tool = AwsCliTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()

if __name__ == "__main__":
    cli()
