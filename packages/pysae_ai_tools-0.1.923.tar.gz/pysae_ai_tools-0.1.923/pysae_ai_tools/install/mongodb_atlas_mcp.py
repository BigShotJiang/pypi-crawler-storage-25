"""Install the MongoDB Atlas MCP servers (dev + prod).

Atlas API keys are fetched from AWS Secrets Manager: ``ai-tools/<env>/secrets``,
under the keys ``mongodb-atlas-public-key`` and ``mongodb-atlas-private-key``
(the same secret holds other ai-tools credentials such as Datadog and ArgoCD
tokens — keeps the per-env secret count low).
"""

import json
import os
import subprocess
from typing import Any

import typer

from .common import binary, mcp
from .common.base import BaseTool, InstallReport, ToolState

DEV_NAME = "mongodb-atlas-mcp-dev"
PROD_NAME = "mongodb-atlas-mcp-prod"


def fetch_keys(env: str) -> tuple[str, str]:
    """Fetch ``(public_key, private_key)`` from AWS Secrets Manager for ``env``.

    Reads the ``ai-tools/<env>/secrets`` secret and extracts the
    ``mongodb-atlas-public-key`` / ``mongodb-atlas-private-key`` fields
    (sharing one secret with other ai-tools credentials).
    """
    if not binary.which("aws"):
        raise RuntimeError("aws CLI not installed (run /install-aws-cli first)")
    secret_id = f"ai-tools/{env}/secrets"
    r = subprocess.run(
        [
            "aws",
            "secretsmanager",
            "get-secret-value",
            "--secret-id",
            secret_id,
            "--query",
            "SecretString",
            "--output",
            "text",
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
        timeout=15,
    )
    if r.returncode != 0:
        raise RuntimeError(f"failed to read {secret_id}: {r.stderr.strip() or r.stdout.strip()}")
    try:
        data = json.loads(r.stdout.strip())
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"{secret_id}: invalid JSON ({exc})") from exc
    pub = data.get("mongodb-atlas-public-key", "")
    priv = data.get("mongodb-atlas-private-key", "")
    if not pub or not priv:
        raise RuntimeError(
            f"{secret_id}: missing mongodb-atlas-public-key / mongodb-atlas-private-key fields",
        )
    return pub, priv


def _build(public_key: str, private_key: str) -> dict[str, Any]:
    return {
        "command": "npx",
        "args": ["mcp-mongodb-atlas"],
        "env": {"ATLAS_PUBLIC_KEY": public_key, "ATLAS_PRIVATE_KEY": private_key},
    }


def _status_for(name: str) -> dict[str, object]:
    server = mcp.get_server(name)
    if server is None:
        return {"name": name, "configured": False, "has_public_key": False, "has_private_key": False}
    env = server.get("env", {}) if isinstance(server.get("env", {}), dict) else {}
    return {
        "name": name,
        "configured": True,
        "has_public_key": bool(env.get("ATLAS_PUBLIC_KEY")),
        "has_private_key": bool(env.get("ATLAS_PRIVATE_KEY")),
    }


class MongodbAtlasMcpTool(BaseTool):
    name = "mongodb-atlas-mcp"
    cli_help = "Install/configure the MongoDB Atlas MCP servers"

    def get_state(self) -> ToolState:
        dev = _status_for(DEV_NAME)
        prod = _status_for(PROD_NAME)
        needs = not (
            dev.get("configured")
            and dev.get("has_public_key")
            and dev.get("has_private_key")
            and prod.get("configured")
            and prod.get("has_public_key")
            and prod.get("has_private_key")
        )
        return ToolState(
            needs_install=needs,
            extra={DEV_NAME: dev, PROD_NAME: prod},
        )

    def do_install(self) -> InstallReport:
        try:
            if os.environ.get("ATLAS_DEV_PUBLIC_KEY") and os.environ.get("ATLAS_PROD_PUBLIC_KEY"):
                dev_pub = os.environ["ATLAS_DEV_PUBLIC_KEY"]
                dev_priv = os.environ["ATLAS_DEV_PRIVATE_KEY"]
                prod_pub = os.environ["ATLAS_PROD_PUBLIC_KEY"]
                prod_priv = os.environ["ATLAS_PROD_PRIVATE_KEY"]
            else:
                dev_pub, dev_priv = fetch_keys("dev")
                prod_pub, prod_priv = fetch_keys("prod")
        except (KeyError, RuntimeError) as exc:
            msg = str(exc) if isinstance(exc, RuntimeError) else f"missing env var: {exc}"
            return InstallReport(error=msg)

        dev_changed = mcp.upsert_server(DEV_NAME, _build(dev_pub, dev_priv))
        prod_changed = mcp.upsert_server(PROD_NAME, _build(prod_pub, prod_priv))
        return InstallReport(
            extra={DEV_NAME: {"changed": dev_changed}, PROD_NAME: {"changed": prod_changed}},
        )

    def format_check(self, state: ToolState) -> None:
        d = state.to_dict()
        for name in (DEV_NAME, PROD_NAME):
            s = d.get(name, {})
            if isinstance(s, dict):
                has_keys = s.get("has_public_key") and s.get("has_private_key")
                label = "OK" if has_keys else "missing keys"
                typer.echo(f"{name}: {'configured' if s.get('configured') else 'missing'} ({label})")

    def format_install(self, report: InstallReport) -> None:
        if report.error:
            typer.echo(f"FAILED: {report.error}", err=True)
            return
        for name in (DEV_NAME, PROD_NAME):
            info = report.extra.get(name, {})
            changed = info.get("changed", False) if isinstance(info, dict) else False
            typer.echo(f"{name}: {'updated' if changed else 'unchanged'}")


_tool = MongodbAtlasMcpTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()

if __name__ == "__main__":
    cli()
