"""Install or update Poetry via ``uv tool install``.

Poetry is the package manager for Pysae's Python projects. We install it via
``uv tool`` (matches the project convention — see CLAUDE.md) so it lives in
its own isolated venv and shows up on PATH through uv's bin shim.
"""

import httpx

from .common.base import UvTool


class PoetryTool(UvTool):
    name = "poetry"
    binary_name = "poetry"
    pip_package = "poetry"
    cli_help = "Install/update Poetry via uv tool"

    def fetch_latest_version(self) -> str:
        r = httpx.get("https://pypi.org/pypi/poetry/json", timeout=5.0, follow_redirects=True)
        r.raise_for_status()
        v = r.json().get("info", {}).get("version", "")
        return str(v) if v else ""


_tool = PoetryTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()


if __name__ == "__main__":
    cli()
