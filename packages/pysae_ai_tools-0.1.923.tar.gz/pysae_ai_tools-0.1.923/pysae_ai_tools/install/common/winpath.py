"""Windows PATH utilities shared by tool detection and install steps.

The Windows user-scope PATH lives in the registry at
``HKCU\\Environment\\Path``. winget (and a handful of installers) extend
it when registering a new package — but the running Python process keeps
its inherited PATH until a new shell is launched, so ``shutil.which`` and
``binary.status`` can't see the freshly installed binary mid-run.

This module exposes:

- :func:`refresh_process_path_from_user_registry` — merge new registry
  entries into ``os.environ["PATH"]`` so the current run sees binaries a
  prior install just dropped on the user's PATH.
- :func:`ensure_in_user_path` — append an entry to the registry's user
  PATH if missing (used when a tool needs to be findable across all
  shells, including cmd.exe which has no profile init mechanism).

Both helpers are no-ops on non-Windows platforms.
"""

import os
import sys

_REFRESHED = False


def refresh_process_path_from_user_registry(*, force: bool = False) -> None:
    """Merge the user-scope PATH from the registry into ``os.environ['PATH']``.

    Best-effort: any error (no winreg, key missing, value not a string,
    etc.) is swallowed silently — callers fall back to whatever PATH the
    process already had. Cached after the first call so repeat invocations
    on the same process are free; pass ``force=True`` to bypass the cache
    immediately after a winget install added a new entry.
    """
    global _REFRESHED
    if sys.platform != "win32":
        _REFRESHED = True
        return
    if _REFRESHED and not force:
        return
    try:
        import winreg
    except ImportError:
        _REFRESHED = True
        return
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
            user_path, _ = winreg.QueryValueEx(key, "Path")
    except OSError:
        _REFRESHED = True
        return
    if not isinstance(user_path, str) or not user_path:
        _REFRESHED = True
        return
    user_path = os.path.expandvars(user_path)
    current = os.environ.get("PATH", "")
    seen = {p.rstrip("\\/") for p in current.split(os.pathsep) if p}
    additions: list[str] = []
    for raw in user_path.split(os.pathsep):
        entry = raw.strip().strip('"')
        if not entry:
            continue
        if entry.rstrip("\\/") in seen:
            continue
        seen.add(entry.rstrip("\\/"))
        additions.append(entry)
    if additions:
        os.environ["PATH"] = os.pathsep.join(additions + ([current] if current else []))
    _REFRESHED = True


def ensure_in_user_path(entry: str) -> bool:
    """Append ``entry`` to the user-scope registry PATH if missing.

    Used when a tool needs to be findable across every shell, not just
    those that source a profile script — cmd.exe and bare GUI launchers
    have no init hook, so a registry-level PATH entry is the only
    mechanism that reaches them.

    Idempotent: if ``entry`` (case-insensitive, ignoring trailing slash)
    is already present, the registry is left alone. Returns True when a
    write actually happened.

    Best-effort: returns False on non-Windows, missing winreg module, or
    any registry error — callers fall back to whatever shell init they
    already wired.
    """
    if sys.platform != "win32" or not entry:
        return False
    try:
        import winreg
    except ImportError:
        return False
    canon = entry.rstrip("\\/").lower()
    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            "Environment",
            0,
            winreg.KEY_READ | winreg.KEY_WRITE,
        ) as key:
            try:
                user_path, value_type = winreg.QueryValueEx(key, "Path")
            except FileNotFoundError:
                user_path, value_type = "", winreg.REG_EXPAND_SZ
            if not isinstance(user_path, str):
                user_path = ""
            existing = [part.strip().strip('"') for part in user_path.split(os.pathsep) if part.strip()]
            if any(p.rstrip("\\/").lower() == canon for p in existing):
                return False
            new_path = os.pathsep.join([*existing, entry])
            # Preserve REG_EXPAND_SZ so values like %APPDATA% stay expandable;
            # default to it when the key is being created from scratch.
            target_type = value_type if value_type == winreg.REG_EXPAND_SZ else winreg.REG_EXPAND_SZ
            winreg.SetValueEx(key, "Path", 0, target_type, new_path)
    except OSError:
        return False
    return True
