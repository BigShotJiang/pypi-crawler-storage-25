"""Install the Chrome DevTools MCP server in ~/.claude.json."""

from typing import Any

from ..config import load_config
from .common.base import McpTool, ToolState
from .common.mcp_cli import status_dict


class ChromeMcpTool(McpTool):
    name = "chrome-mcp"
    server_name = "chrome-devtools"
    cli_help = "Install/configure the Chrome DevTools MCP server"

    def build_config(self) -> dict[str, Any]:
        # Package name is ``chrome-devtools-mcp`` on npm — no @anthropic-ai
        # scope (the scoped name is reserved but unpublished, npm 404).
        args: list[str] = ["chrome-devtools-mcp@latest"]
        # Source of truth: ``chrome_mcp_auto_connect`` in config.toml,
        # answered via the parameter prompt phase of ``tools configure``.
        if load_config().chrome_mcp_auto_connect:
            args.append("--autoConnect")
        return {"command": "npx", "args": args}

    def get_state(self) -> ToolState:
        """Detect drift between the on-disk MCP config and the desired one.

        The base ``McpTool.get_state`` only checks server presence — once
        the entry exists, ``needs_install`` flips to False and re-running
        ``tools install`` becomes a no-op. That hides drift when the user
        toggles ``chrome_mcp_auto_connect`` in ``config.toml`` after the
        initial install. Compare the saved args with what ``build_config``
        would emit and flag ``needs_update`` when they differ.
        """
        from .common import mcp

        status = status_dict(self.server_name)
        existing = mcp.get_server(self.server_name)
        desired = self.build_config()
        installed = status.get("configured", False)
        config_drift = installed and existing is not None and existing != desired
        return ToolState(
            needs_install=not installed,
            needs_update=config_drift,
            extra=status,
        )


_tool = ChromeMcpTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()

if __name__ == "__main__":
    cli()
