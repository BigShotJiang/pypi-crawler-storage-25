"""Install or update jq from GitHub releases."""

from .common import binary, github, platform
from .common.base import BinaryTool, InstallReport

GITHUB_REPO = "jqlang/jq"


class JqTool(BinaryTool):
    name = "jq"
    binary_name = "jq"
    cli_help = "Install/update jq (command-line JSON processor)"
    winget_package = "jqlang.jq"
    brew_package = "jq"

    def fetch_latest_version(self) -> str:
        # jq tags look like "jq-1.7.1" — strip the prefix so the version
        # comparison in BinaryTool.get_state() works against `jq --version`
        # which prints "jq-1.7.1".
        tag = github.latest_release(GITHUB_REPO)
        return tag.removeprefix("jq-")

    def _install_from_github(self, plat: platform.Platform) -> InstallReport:
        try:
            version = self.fetch_latest_version()
        except Exception as exc:  # noqa: BLE001
            return InstallReport(error=f"could not fetch latest version: {exc}")

        arch = "amd64" if plat.arch.value == "x86_64" else plat.arch.value
        if plat.is_linux:
            asset = f"jq-linux-{arch}"
        elif plat.is_macos:
            asset = f"jq-macos-{arch}"
        elif plat.is_windows:
            asset = f"jq-windows-{arch}.exe"
        else:
            return InstallReport(error=f"unsupported OS: {plat.os}")

        url = f"https://github.com/{GITHUB_REPO}/releases/download/jq-{version}/{asset}"

        from .common.download import download_and_install_binary

        try:
            path = download_and_install_binary(url, self.binary_name)
        except Exception as exc:  # noqa: BLE001
            return InstallReport(error=f"download/install failed: {exc}")
        installed_v = binary.get_version(self.binary_name, version_arg=self.version_arg)
        return InstallReport(version=installed_v or version, path=str(path))

    def install_linux(self, plat: platform.Platform) -> InstallReport:
        return self._install_from_github(plat)

    def install_macos(self, plat: platform.Platform) -> InstallReport:
        return self._install_from_github(plat)

    def install_windows(self, plat: platform.Platform) -> InstallReport:
        return self._install_from_github(plat)


_tool = JqTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()


if __name__ == "__main__":
    cli()
