"""
MasharikiWeather Models Package.
"""
