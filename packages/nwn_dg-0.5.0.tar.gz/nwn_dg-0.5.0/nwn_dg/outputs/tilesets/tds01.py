from ... import constants as C


def noop():
    pass


# Center, N, E, S, W for an orientation of 0
# Tile orientations are:
#     0 = Normal orientation
#     1 = 90 degrees counterclockwise
#     2 = 180 degrees counterclockwise
#     3 = 270 degrees counterclockwise
#
# Tile 110 is water, useful for debugging
# The two -1 are errors. The first one happens from time to time,
# but nothing is visible on the are map.
# The second does not seem to happen.
K_PATTERNS = {
    "W": {"Tile_ID": [5]},
    # Corridor
    "CCWWW": {"Tile_ID": [43, 144]},  # Deadend
    "CWWCC": {"Tile_ID": [39, 127]},  # Angle
    "CCWCC": {"Tile_ID": [41, 130]},  # T-junction
    "CCWCW": {"Tile_ID": [155, 156, 152, 129]},  # Straight
    "CCCCC": {"Tile_ID": [42]},  # Cross
    # ---
    # Corridor next to rooms
    "CRWCW": {"Tile_ID": [128]},
    "CRWRW": {"Tile_ID": [152]},
    "CRWWW": {
        "Tile_ID": [-1],
    },  # Transition, not on a primary cell. Happens, but nothing is noticeabl Happens, but nothing is noticeable
    # ---
    # Rooms
    "RWWRR": {"Tile_ID": [115]},
    "RRWRR": {"Tile_ID": [149]},
    "RRRRR": {"Tile_ID": [4]},  # Center tile
    # ---
    # Rooms + Corridor exits
    "RCWRR": {"Tile_ID": [124]},  # Top-Right corridor to the north
    "RRCCR": {"Tile_ID": [21]},  # Bottom-Right corridors
    "RRWCR": {"Tile_ID": [125]},  # Bottom-Right corridor to the south
    "RRCRR": {"Tile_ID": [-1]},  # Does not seem to happen
}

K_TRANSITIONS = {
    C.TransitionType.STAIRS_UP: {"Tile_ID": [72]},
    C.TransitionType.STAIRS_DOWN: {"Tile_ID": [71]},
}

K_TILE_ORIENTATIONS = {
    # fmt: off
    0:   { "Tile_Orientation": 0},
    4:   { "Tile_Orientation": 0},
    5:   { "Tile_Orientation": 0},
    21:   { "Tile_Orientation": 0},
    39:   { "Tile_Orientation": 0},
    41:   { "Tile_Orientation": 0},
    42:   { "Tile_Orientation": 0},
    43:   { "Tile_Orientation": 0},
    71:   { "Tile_Orientation": 0},
    72:   { "Tile_Orientation": 0},
    113:   { "Tile_Orientation": 0},
    114:   { "Tile_Orientation": 0},
    115:   { "Tile_Orientation": 0},
    125:   { "Tile_Orientation": 0},
    124:   { "Tile_Orientation": 0},
    117:   { "Tile_Orientation": 0},
    128:   { "Tile_Orientation": 0},
    127:  { "Tile_Orientation": 0},
    129:   { "Tile_Orientation": 0},
    130:   { "Tile_Orientation": 0},
    110:   { "Tile_Orientation": 0},
    144:   { "Tile_Orientation": 0},
    151:   { "Tile_Orientation": 0},
    152:   { "Tile_Orientation": 0},
    155:   { "Tile_Orientation": 0},
    149:   { "Tile_Orientation": 0},
    156:   { "Tile_Orientation": 0},
    # fmt: on
}
