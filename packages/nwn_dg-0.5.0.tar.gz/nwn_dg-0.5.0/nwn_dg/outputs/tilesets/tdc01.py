from ... import constants as C


def noop():
    pass


# Center, N, E, S, W for an orientation of 0
# Tile orientations are:
#     0 = Normal orientation
#     1 = 90 degrees counterclockwise
#     2 = 180 degrees counterclockwise
#     3 = 270 degrees counterclockwise
#
# The two -1 are errors. The first one happens from time to time,
# but nothing is visible on the are map.
# The second does not seem to happen.
K_PATTERNS = {
    "W": {"Tile_ID": [5]},
    # Corridor
    "CCWWW": {"Tile_ID": [41, 119]},  # Deadend
    "CWWCC": {"Tile_ID": [127]},  # Angle
    "CCWCC": {"Tile_ID": [130]},  # T-junction
    "CCWCW": {"Tile_ID": [118]},  # Straight
    "CCCCC": {"Tile_ID": [40]},  # Cross
    # ---
    # Corridor next to rooms
    "CRWCW": {"Tile_ID": [129]},
    "CRWRW": {"Tile_ID": [118]},
    "CRWWW": {"Tile_ID": [-1]},  # Transition, not on a primary cell
    # ---
    # Rooms
    "RWWRR": {"Tile_ID": [0]},
    "RRWRR": {"Tile_ID": [117]},
    "RRRRR": {"Tile_ID": [101]},
    # ---
    # Rooms + Corridor exits
    "RCWRR": {"Tile_ID": [125]},  # Top-Right corridor to the north
    "RRCCR": {"Tile_ID": [19]},  # Bottom-Right corridors
    "RRWCR": {"Tile_ID": [126]},  # Bottom-Right corridor to the south
    "RRCRR": {"Tile_ID": [-1]},  #
}

K_TRANSITIONS = {
    C.TransitionType.STAIRS_UP: {"Tile_ID": [70]},
}

K_TILE_ORIENTATIONS = {
    # fmt: off
      0: { "Tile_Orientation": 2},
      4: { "Tile_Orientation": 2},
      5: { "Tile_Orientation": 1},
     18: { "Tile_Orientation": 3},
     19: { "Tile_Orientation": 0},
     21: { "Tile_Orientation": 1},
     30: { "Tile_Orientation": 3},
     38: { "Tile_Orientation": 1},
     65: { "Tile_Orientation": 2},
     40: { "Tile_Orientation": 3},
     41: { "Tile_Orientation": 2},
     70: { "Tile_Orientation": 0},
     71: { "Tile_Orientation": 2},
    101: { "Tile_Orientation": 3},
    102: { "Tile_Orientation": 0},
    109: { "Tile_Orientation": 3},
    114: { "Tile_Orientation": 3},
    115: { "Tile_Orientation": 3},
    116: { "Tile_Orientation": 3},
    117: { "Tile_Orientation": 3},
    118: { "Tile_Orientation": 0},
    119: { "Tile_Orientation": 1},
    125: { "Tile_Orientation": 3},
    126: { "Tile_Orientation": 3},
    127: { "Tile_Orientation": 1},
    129: { "Tile_Orientation": 3},
    130: { "Tile_Orientation": 2},
    # fmt: on
}
