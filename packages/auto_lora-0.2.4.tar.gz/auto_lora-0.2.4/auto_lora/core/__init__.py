"""Core configuration and business logic."""
