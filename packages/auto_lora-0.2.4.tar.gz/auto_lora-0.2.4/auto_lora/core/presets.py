"""Preset configurations for common fine-tuning scenarios.

Each preset provides recommended hyperparameter search spaces and training
defaults optimized for specific use cases (chatbot, coding, summarization, etc.).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from auto_lora.core.config import GoalType, SearchSpaceConfig


@dataclass
class PresetConfig:
    """A training preset with recommended settings."""

    name: str
    description: str
    goal_type: GoalType
    # Recommended training defaults
    epochs: int = 3
    learning_rate: float = 2e-4
    batch_size: int = 4
    max_seq_length: int = 512
    warmup_ratio: float = 0.03
    # Recommended LoRA defaults
    rank: int = 16
    alpha: int = 32
    dropout: float = 0.05
    target_modules: list[str] = field(
        default_factory=lambda: ["q_proj", "v_proj"]
    )
    # Search space overrides
    search_space: SearchSpaceConfig = field(default_factory=SearchSpaceConfig)


# ─── Preset Definitions ──────────────────────────────────────────────────────

CHATBOT_PRESET = PresetConfig(
    name="chatbot",
    description="Optimized for conversational datasets. Focuses on natural dialogue flow.",
    goal_type=GoalType.CHATBOT,
    epochs=3,
    learning_rate=2e-4,
    batch_size=4,
    max_seq_length=1024,
    warmup_ratio=0.05,
    rank=16,
    alpha=32,
    dropout=0.05,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
    search_space=SearchSpaceConfig(
        rank_choices=[8, 16, 32, 64],
        alpha_multipliers=[1, 2],
        dropout_range=(0.0, 0.1),
        learning_rate_range=(5e-5, 3e-4),
        batch_size_choices=[2, 4, 8],
        epochs_range=(2, 4),
    ),
)

CODING_PRESET = PresetConfig(
    name="coding",
    description="Lower learning rate, code-specific tokenization. For code generation tasks.",
    goal_type=GoalType.CODING,
    epochs=3,
    learning_rate=1e-4,
    batch_size=2,
    max_seq_length=2048,
    warmup_ratio=0.03,
    rank=32,
    alpha=64,
    dropout=0.05,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    search_space=SearchSpaceConfig(
        rank_choices=[16, 32, 64],
        alpha_multipliers=[1, 2],
        dropout_range=(0.0, 0.1),
        learning_rate_range=(1e-5, 2e-4),
        batch_size_choices=[1, 2, 4],
        epochs_range=(2, 5),
    ),
)

SUMMARIZER_PRESET = PresetConfig(
    name="summarizer",
    description="Long context tuning for text summarization tasks.",
    goal_type=GoalType.SUMMARIZER,
    epochs=3,
    learning_rate=2e-4,
    batch_size=2,
    max_seq_length=2048,
    warmup_ratio=0.05,
    rank=16,
    alpha=32,
    dropout=0.05,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
    search_space=SearchSpaceConfig(
        rank_choices=[8, 16, 32],
        alpha_multipliers=[1, 2],
        dropout_range=(0.0, 0.1),
        learning_rate_range=(5e-5, 3e-4),
        batch_size_choices=[1, 2, 4],
        epochs_range=(2, 4),
    ),
)

QA_PRESET = PresetConfig(
    name="qa",
    description="Fact-oriented retrieval style. Optimized for question-answering datasets.",
    goal_type=GoalType.QA,
    epochs=3,
    learning_rate=2e-4,
    batch_size=4,
    max_seq_length=512,
    warmup_ratio=0.03,
    rank=8,
    alpha=16,
    dropout=0.05,
    target_modules=["q_proj", "v_proj"],
    search_space=SearchSpaceConfig(
        rank_choices=[4, 8, 16, 32],
        alpha_multipliers=[1, 2],
        dropout_range=(0.0, 0.1),
        learning_rate_range=(1e-5, 5e-4),
        batch_size_choices=[2, 4, 8],
        epochs_range=(1, 4),
    ),
)

DOMAIN_PRESET = PresetConfig(
    name="domain",
    description="For domain-specific content: legal, medical, finance, enterprise docs.",
    goal_type=GoalType.DOMAIN,
    epochs=4,
    learning_rate=1e-4,
    batch_size=4,
    max_seq_length=1024,
    warmup_ratio=0.05,
    rank=32,
    alpha=64,
    dropout=0.1,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    search_space=SearchSpaceConfig(
        rank_choices=[16, 32, 64],
        alpha_multipliers=[1, 2],
        dropout_range=(0.0, 0.15),
        learning_rate_range=(1e-5, 3e-4),
        batch_size_choices=[2, 4],
        epochs_range=(3, 5),
    ),
)

# ─── Preset Registry ─────────────────────────────────────────────────────────

PRESETS: dict[str, PresetConfig] = {
    "chatbot": CHATBOT_PRESET,
    "coding": CODING_PRESET,
    "summarizer": SUMMARIZER_PRESET,
    "qa": QA_PRESET,
    "domain": DOMAIN_PRESET,
}


def get_preset(name: str) -> PresetConfig:
    """Get a preset configuration by name.

    Args:
        name: Preset name (chatbot, coding, summarizer, qa, domain).

    Returns:
        The preset configuration.

    Raises:
        ValueError: If preset name is not recognized.
    """
    name = name.lower().strip()
    if name not in PRESETS:
        available = ", ".join(PRESETS.keys())
        raise ValueError(f"Unknown preset '{name}'. Available presets: {available}")
    return PRESETS[name]


def list_presets() -> list[dict[str, str]]:
    """List all available presets with descriptions.

    Returns:
        List of dicts with 'name' and 'description' keys.
    """
    return [
        {"name": p.name, "description": p.description}
        for p in PRESETS.values()
    ]
