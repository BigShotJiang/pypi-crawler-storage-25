"""Global constants for Auto-LoRA."""

from pathlib import Path
from auto_lora import __version__

# Application
APP_NAME = "auto_lora"
APP_VERSION = __version__
DB_FILENAME = "auto_lora.db"
CONFIG_FILENAME = "auto_lora_config.yaml"

# Default directories (relative to project root)
DEFAULT_OUTPUT_DIR = "outputs"
DEFAULT_LOG_DIR = "logs"
DEFAULT_DATASET_DIR = "datasets"
DEFAULT_CONFIG_DIR = "configs"

# Training defaults
DEFAULT_MAX_TRIALS = 10
DEFAULT_MAX_HOURS = 4.0
DEFAULT_SEED = 42
DEFAULT_VAL_SPLIT = 0.1
DEFAULT_MAX_SEQ_LENGTH = 512

# LoRA defaults
DEFAULT_LORA_RANK = 16
DEFAULT_LORA_ALPHA = 32
DEFAULT_LORA_DROPOUT = 0.05
DEFAULT_TARGET_MODULES = ["q_proj", "v_proj"]

# Hardware thresholds (in GB)
VRAM_THRESHOLD_QLORA = 12.0  # Below this, recommend QLoRA
VRAM_THRESHOLD_MIN = 4.0  # Minimum VRAM for any training
MIN_FREE_DISK_GB = 10.0  # Minimum free disk space

# Scoring weights for trial comparison
SCORE_WEIGHT_VAL_LOSS = 0.50
SCORE_WEIGHT_RUNTIME = 0.20
SCORE_WEIGHT_MEMORY = 0.15
SCORE_WEIGHT_BENCHMARK = 0.15

# Supported model architectures and their typical target modules
MODEL_TARGET_MODULES: dict[str, list[str]] = {
    "llama": ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    "mistral": ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    "phi": ["q_proj", "k_proj", "v_proj", "dense", "fc1", "fc2"],
    "gpt2": ["c_attn", "c_proj", "c_fc"],
    "falcon": ["query_key_value", "dense", "dense_h_to_4h", "dense_4h_to_h"],
    "gemma": ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    "qwen": ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
}

# Dataset format detection patterns
ALPACA_REQUIRED_KEYS = {"instruction", "output"}
ALPACA_OPTIONAL_KEYS = {"input", "system"}
CONVERSATIONAL_REQUIRED_KEYS = {"messages"}
INSTRUCTION_REQUIRED_KEYS = {"instruction", "response"}

# Benchmark default prompts
DEFAULT_BENCHMARK_PROMPTS = [
    "Explain the concept of machine learning in simple terms.",
    "Write a short summary of the following text: {input}",
    "What are the main differences between Python and JavaScript?",
    "How would you handle a customer complaint about a delayed order?",
    "Translate the following sentence to formal English: {input}",
]

# File extensions
SUPPORTED_DATASET_EXTENSIONS = {".json", ".jsonl", ".csv", ".txt"}

# Logging
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
MAX_LOG_FILE_SIZE = 10 * 1024 * 1024  # 10 MB
LOG_BACKUP_COUNT = 5

# Report templates directory
TEMPLATES_DIR = Path(__file__).parent.parent / "reports" / "templates"
