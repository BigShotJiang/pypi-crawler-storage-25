"""Configuration dataclasses for Auto-LoRA.

Defines all configuration structures used throughout the application:
- TrainingConfig: Top-level training job configuration
- LoRAConfig: LoRA/QLoRA adapter parameters
- HardwareProfile: Detected system hardware capabilities
- SearchSpaceConfig: Hyperparameter search ranges for Optuna
- RunConfig: Complete configuration for a single training run
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional


class GoalType(str, Enum):
    """Supported fine-tuning goal types."""

    CHATBOT = "chatbot"
    CODING = "coding"
    SUMMARIZER = "summarizer"
    QA = "qa"
    DOMAIN = "domain"
    GENERAL = "general"


class QuantizationType(str, Enum):
    """Model quantization options."""

    NONE = "none"
    INT8 = "8bit"
    INT4 = "4bit"


class TrainingStrategy(str, Enum):
    """Training strategy based on hardware capabilities."""

    LORA = "lora"
    QLORA = "qlora"
    CPU = "cpu"


class DatasetFormat(str, Enum):
    """Supported dataset file formats."""

    JSON = "json"
    JSONL = "jsonl"
    CSV = "csv"
    TXT = "txt"
    ALPACA = "alpaca"
    CONVERSATIONAL = "conversational"


@dataclass
class HardwareProfile:
    """Detected hardware capabilities of the system."""

    gpu_name: str = "None"
    gpu_count: int = 0
    vram_gb: float = 0.0
    cpu_cores: int = 1
    ram_gb: float = 0.0
    cuda_available: bool = False
    cuda_version: str = ""
    torch_version: str = ""
    storage_free_gb: float = 0.0

    @property
    def has_gpu(self) -> bool:
        """Check if a GPU is available."""
        return self.cuda_available and self.gpu_count > 0

    def recommended_strategy(self) -> TrainingStrategy:
        """Recommend training strategy based on available hardware."""
        if not self.has_gpu:
            return TrainingStrategy.CPU
        if self.vram_gb < 12.0:
            return TrainingStrategy.QLORA
        return TrainingStrategy.LORA


@dataclass
class LoRAConfig:
    """LoRA adapter configuration parameters."""

    rank: int = 16
    alpha: int = 32
    dropout: float = 0.05
    target_modules: list[str] = field(
        default_factory=lambda: ["q_proj", "v_proj"]
    )
    bias: str = "none"
    task_type: str = "CAUSAL_LM"
    quantization: QuantizationType = QuantizationType.NONE

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "rank": self.rank,
            "alpha": self.alpha,
            "dropout": self.dropout,
            "target_modules": self.target_modules,
            "bias": self.bias,
            "task_type": self.task_type,
            "quantization": self.quantization.value,
        }

    @classmethod
    def from_dict(cls, data: dict) -> LoRAConfig:
        """Create from dictionary."""
        if "quantization" in data:
            data["quantization"] = QuantizationType(data["quantization"])
        return cls(**data)


@dataclass
class TrainingConfig:
    """Top-level training job configuration."""

    # Model
    model_name: str = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
    # Dataset
    dataset_path: str = ""
    dataset_format: Optional[DatasetFormat] = None  # Auto-detect if None
    # Goal
    goal_type: GoalType = GoalType.GENERAL
    preset: Optional[str] = None
    # Tuning
    max_trials: int = 10
    max_hours: float = 4.0
    # Hardware constraints
    target_vram: Optional[float] = None  # GB; None = use all available
    strategy: Optional[TrainingStrategy] = None  # None = auto-detect
    # Training params (used when not tuning)
    epochs: int = 3
    batch_size: int = 4
    learning_rate: float = 2e-4
    warmup_ratio: float = 0.03
    gradient_accumulation_steps: int = 4
    max_seq_length: int = 512
    fp16: bool = True
    bf16: bool = False
    # Output
    output_dir: str = "outputs"
    logging_steps: int = 10
    save_steps: int = 100
    eval_steps: int = 50
    # Validation
    val_split: float = 0.1
    # Tracking
    use_wandb: bool = False
    wandb_project: str = "auto_lora"
    # Misc
    seed: int = 42
    verbose: bool = False
    json_output: bool = False

    def to_dict(self) -> dict:
        """Convert to serializable dictionary."""
        result = {}
        for k, v in self.__dict__.items():
            if isinstance(v, Enum):
                result[k] = v.value
            elif isinstance(v, Path):
                result[k] = str(v)
            else:
                result[k] = v
        return result


@dataclass
class SearchSpaceConfig:
    """Hyperparameter search space ranges for Optuna."""

    # LoRA params
    rank_choices: list[int] = field(default_factory=lambda: [4, 8, 16, 32, 64])
    alpha_multipliers: list[int] = field(default_factory=lambda: [1, 2])
    dropout_range: tuple[float, float] = (0.0, 0.15)
    # Training params
    learning_rate_range: tuple[float, float] = (1e-5, 5e-4)
    batch_size_choices: list[int] = field(default_factory=lambda: [1, 2, 4, 8])
    epochs_range: tuple[int, int] = (1, 5)
    warmup_ratio_range: tuple[float, float] = (0.0, 0.1)
    # Target modules options
    target_module_options: list[list[str]] = field(
        default_factory=lambda: [
            ["q_proj", "v_proj"],
            ["q_proj", "k_proj", "v_proj"],
            ["q_proj", "k_proj", "v_proj", "o_proj"],
            ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        ]
    )


@dataclass
class DatasetReport:
    """Quality report for an analyzed dataset."""

    total_rows: int = 0
    duplicate_count: int = 0
    null_count: int = 0
    malformed_count: int = 0
    avg_token_length: float = 0.0
    min_token_length: int = 0
    max_token_length: int = 0
    median_token_length: float = 0.0
    token_length_std: float = 0.0
    quality_score: float = 0.0  # 0.0 to 1.0
    warnings: list[str] = field(default_factory=list)
    format_detected: Optional[DatasetFormat] = None
    columns: list[str] = field(default_factory=list)

    @property
    def is_healthy(self) -> bool:
        """Check if dataset passes basic quality checks."""
        return self.quality_score >= 0.5 and self.malformed_count == 0


@dataclass
class TrialResult:
    """Result of a single hyperparameter trial."""

    trial_number: int
    lora_config: dict  # LoRA hyperparameters used
    training_args: dict  # Training arguments used
    train_loss: float = 0.0
    val_loss: float = 0.0
    perplexity: float = 0.0
    runtime_seconds: float = 0.0
    peak_memory_gb: float = 0.0
    tokens_per_second: float = 0.0
    score: float = 0.0
    status: str = "pending"  # pending, running, completed, failed, pruned
    error_message: str = ""
    adapter_path: str = ""


@dataclass
class TuningResult:
    """Result of the complete tuning process."""

    best_trial: Optional[TrialResult] = None
    all_trials: list[TrialResult] = field(default_factory=list)
    total_runtime_seconds: float = 0.0
    run_id: str = ""

    @property
    def completed_trials(self) -> list[TrialResult]:
        """Return only successfully completed trials."""
        return [t for t in self.all_trials if t.status == "completed"]

    @property
    def success_rate(self) -> float:
        """Fraction of trials that completed successfully."""
        if not self.all_trials:
            return 0.0
        return len(self.completed_trials) / len(self.all_trials)
