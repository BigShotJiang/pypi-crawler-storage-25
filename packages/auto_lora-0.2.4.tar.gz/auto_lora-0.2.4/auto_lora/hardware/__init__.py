"""Hardware detection and analysis."""
