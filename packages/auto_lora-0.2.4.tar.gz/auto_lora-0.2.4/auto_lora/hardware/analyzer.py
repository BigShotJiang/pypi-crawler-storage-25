"""Hardware detection and analysis module.

Detects system hardware capabilities including:
- GPU model, count, and VRAM
- CUDA availability and version
- CPU cores and RAM
- Available disk space

Uses this information to recommend training strategies (LoRA vs QLoRA vs CPU).
"""

from __future__ import annotations

import platform
import subprocess
from pathlib import Path

import psutil

from auto_lora.core.config import HardwareProfile, TrainingStrategy
from auto_lora.core.constants import VRAM_THRESHOLD_MIN, VRAM_THRESHOLD_QLORA
from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


def detect_hardware() -> HardwareProfile:
    """Detect system hardware capabilities.

    Probes GPU (via PyTorch CUDA), CPU, RAM, and disk space
    to build a complete hardware profile.

    Returns:
        HardwareProfile with detected capabilities.
    """
    profile = HardwareProfile()

    # CPU and RAM
    profile.cpu_cores = psutil.cpu_count(logical=True) or 1
    profile.ram_gb = psutil.virtual_memory().total / (1024**3)

    # Disk space
    try:
        profile.storage_free_gb = psutil.disk_usage("/").free / (1024**3)
    except Exception:
        profile.storage_free_gb = 0.0

    # PyTorch and CUDA
    try:
        import torch

        profile.torch_version = torch.__version__
        profile.cuda_available = torch.cuda.is_available()

        if profile.cuda_available:
            profile.cuda_version = torch.version.cuda or ""
            profile.gpu_count = torch.cuda.device_count()

            if profile.gpu_count > 0:
                profile.gpu_name = torch.cuda.get_device_name(0)
                # Get VRAM using torch
                vram_bytes = torch.cuda.get_device_properties(0).total_memory
                profile.vram_gb = vram_bytes / (1024**3)
    except ImportError:
        logger.warning("PyTorch not installed — GPU detection unavailable")
    except Exception as e:
        logger.warning(f"GPU detection error: {e}")

    # Try pynvml for more accurate VRAM info
    if profile.cuda_available:
        try:
            import pynvml

            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            mem_info = pynvml.nvmlDeviceGetMemoryInfo(handle)
            profile.vram_gb = mem_info.total / (1024**3)
            pynvml.nvmlShutdown()
        except Exception:
            pass  # Fall back to torch-detected VRAM

    logger.info(f"Hardware detected: {profile.gpu_name} | {profile.vram_gb:.1f}GB VRAM | "
                f"{profile.cpu_cores} CPU cores | {profile.ram_gb:.1f}GB RAM")

    return profile


def recommend_strategy(profile: HardwareProfile) -> TrainingStrategy:
    """Recommend a training strategy based on hardware.

    Decision logic:
    - No GPU → CPU (warning: very slow)
    - GPU with < 12GB VRAM → QLoRA (4-bit quantization)
    - GPU with >= 12GB VRAM → LoRA (full precision adapters)

    Args:
        profile: Detected hardware profile.

    Returns:
        Recommended TrainingStrategy.
    """
    strategy = profile.recommended_strategy()
    logger.info(f"Recommended strategy: {strategy.value}")
    return strategy


def estimate_memory(
    model_name: str,
    rank: int = 16,
    quantization: str = "none",
) -> dict[str, float]:
    """Estimate VRAM requirements for a given configuration.

    Provides rough estimates based on model size and LoRA parameters.
    These are approximations — actual usage varies.

    Args:
        model_name: HuggingFace model name/path.
        rank: LoRA rank.
        quantization: "none", "8bit", or "4bit".

    Returns:
        Dict with estimated VRAM in GB for different components.
    """
    # Rough model size estimation based on common model names
    model_sizes_gb: dict[str, float] = {
        "tiny": 0.5,
        "small": 1.0,
        "1b": 2.0,
        "1.1b": 2.2,
        "3b": 6.0,
        "7b": 14.0,
        "8b": 16.0,
        "13b": 26.0,
        "70b": 140.0,
    }

    # Try to detect model size from name
    model_lower = model_name.lower()
    base_size_gb = 2.0  # Default estimate

    for key, size in model_sizes_gb.items():
        if key in model_lower:
            base_size_gb = size
            break

    # Apply quantization reduction
    if quantization == "4bit":
        model_mem = base_size_gb * 0.25  # ~4x reduction
    elif quantization == "8bit":
        model_mem = base_size_gb * 0.5  # ~2x reduction
    else:
        model_mem = base_size_gb

    # LoRA adapter overhead (relatively small)
    lora_mem = rank * 0.01  # Rough estimate

    # Training overhead (optimizer states, gradients, activations)
    training_overhead = model_mem * 0.3

    total = model_mem + lora_mem + training_overhead

    return {
        "model_gb": round(model_mem, 2),
        "lora_adapter_gb": round(lora_mem, 2),
        "training_overhead_gb": round(training_overhead, 2),
        "total_estimated_gb": round(total, 2),
    }


def check_system_health() -> list[dict[str, str]]:
    """Run system health checks for the 'doctor' command.

    Checks:
    - Python version
    - CUDA availability
    - GPU VRAM
    - Disk space
    - Key dependencies
    - Write permissions

    Returns:
        List of check results, each with 'name', 'status' (pass/warn/fail),
        and 'message' keys.
    """
    checks: list[dict[str, str]] = []

    # Python version
    py_version = platform.python_version()
    py_major, py_minor = int(py_version.split(".")[0]), int(py_version.split(".")[1])
    if py_major >= 3 and py_minor >= 10:
        checks.append({"name": "Python Version", "status": "pass", "message": f"Python {py_version}"})
    else:
        checks.append({"name": "Python Version", "status": "fail", "message": f"Python {py_version} (need >= 3.10)"})

    # CUDA
    try:
        import torch

        if torch.cuda.is_available():
            gpu_name = torch.cuda.get_device_name(0)
            vram = torch.cuda.get_device_properties(0).total_memory / (1024**3)
            checks.append({"name": "CUDA", "status": "pass", "message": f"CUDA {torch.version.cuda}"})
            checks.append({"name": "GPU", "status": "pass", "message": f"{gpu_name} ({vram:.1f}GB VRAM)"})

            if vram < VRAM_THRESHOLD_MIN:
                checks.append({"name": "VRAM", "status": "warn",
                               "message": f"{vram:.1f}GB is very low — training may be slow"})
            elif vram < VRAM_THRESHOLD_QLORA:
                checks.append({"name": "VRAM", "status": "warn",
                               "message": f"{vram:.1f}GB — will use QLoRA for memory efficiency"})
            else:
                checks.append({"name": "VRAM", "status": "pass", "message": f"{vram:.1f}GB — sufficient for LoRA"})
        else:
            checks.append({"name": "CUDA", "status": "warn", "message": "Not available — CPU-only mode"})
    except ImportError:
        checks.append({"name": "PyTorch", "status": "fail", "message": "Not installed"})

    # Key dependencies
    deps = [
        ("transformers", "transformers"),
        ("peft", "peft"),
        ("datasets", "datasets"),
        ("accelerate", "accelerate"),
        ("bitsandbytes", "bitsandbytes"),
        ("optuna", "optuna"),
        ("rich", "rich"),
        ("unsloth", "unsloth"),
        ("xformers", "xformers"),
    ]
    for name, module in deps:
        try:
            __import__(module)
            checks.append({"name": name, "status": "pass", "message": "Installed"})
        except ImportError:
            checks.append({"name": name, "status": "fail", "message": "Not installed"})

    # Disk space
    free_gb = psutil.disk_usage(".").free / (1024**3)
    if free_gb >= 20:
        checks.append({"name": "Disk Space", "status": "pass", "message": f"{free_gb:.1f}GB free"})
    elif free_gb >= 10:
        checks.append({"name": "Disk Space", "status": "warn", "message": f"{free_gb:.1f}GB free (low)"})
    else:
        checks.append({"name": "Disk Space", "status": "fail", "message": f"{free_gb:.1f}GB free (critical)"})

    # RAM
    ram_gb = psutil.virtual_memory().total / (1024**3)
    if ram_gb >= 16:
        checks.append({"name": "RAM", "status": "pass", "message": f"{ram_gb:.1f}GB"})
    elif ram_gb >= 8:
        checks.append({"name": "RAM", "status": "warn", "message": f"{ram_gb:.1f}GB (may be tight)"})
    else:
        checks.append({"name": "RAM", "status": "fail", "message": f"{ram_gb:.1f}GB (insufficient)"})

    # Write permissions
    try:
        test_path = Path("outputs/.write_test")
        test_path.parent.mkdir(parents=True, exist_ok=True)
        test_path.write_text("test")
        test_path.unlink()
        checks.append({"name": "Write Access", "status": "pass", "message": "OK"})
    except Exception as e:
        checks.append({"name": "Write Access", "status": "fail", "message": str(e)})

    return checks
