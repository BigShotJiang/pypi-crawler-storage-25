"""init command — Initialize project structure."""

from __future__ import annotations

from pathlib import Path

import typer

from auto_lora.core.constants import CONFIG_FILENAME, DB_FILENAME
from auto_lora.db.store import RunStore
from auto_lora.utils.display import console, print_header, print_success, print_info
from auto_lora.utils.fs import create_project_structure


def init_command(
    directory: str = typer.Argument(".", help="Project directory to initialize."),
) -> None:
    """Initialize Auto-LoRA project structure.

    Creates the necessary folders, config file, and database.
    """
    print_header("Auto-LoRA", "Initializing project")

    root = Path(directory).resolve()
    root.mkdir(parents=True, exist_ok=True)

    # Create directory structure
    dirs = create_project_structure(root)
    for name, path in dirs.items():
        print_success(f"Created {name}/ → {path}")

    # Create default config
    config_path = root / "configs" / CONFIG_FILENAME
    if not config_path.exists():
        config_path.write_text(_default_config())
        print_success(f"Created config → {config_path}")
    else:
        print_info(f"Config already exists → {config_path}")

    # Initialize database
    db_path = root / DB_FILENAME
    RunStore(db_path)
    print_success(f"Database ready → {db_path}")

    console.print()
    print_success("[bold]Project initialized successfully![/bold]")
    console.print()
    print_info("Next steps:")
    print_info("  1. Place your dataset in datasets/")
    print_info("  2. Run: auto-lora doctor")
    print_info("  3. Run: auto-lora train --model <model> --data <dataset>")
    console.print()


def _default_config() -> str:
    """Generate default YAML config content."""
    return """# Auto-LoRA Configuration
# See: auto-lora train --help for all options

# Model settings
model_name: "TinyLlama/TinyLlama-1.1B-Chat-v1.0"

# Training settings
max_trials: 10
max_hours: 4.0
epochs: 3
batch_size: 4
learning_rate: 0.0002
max_seq_length: 512

# LoRA defaults
lora_rank: 16
lora_alpha: 32
lora_dropout: 0.05

# Output
output_dir: "outputs"
seed: 42

# Optional integrations
# use_wandb: false
# wandb_project: "auto_lora"
"""
