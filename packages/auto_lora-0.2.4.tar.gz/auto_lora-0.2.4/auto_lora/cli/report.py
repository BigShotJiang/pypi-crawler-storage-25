"""report command — Generate HTML report for a run."""

from __future__ import annotations

import webbrowser
from pathlib import Path

import typer

from auto_lora.core.constants import DB_FILENAME
from auto_lora.db.store import RunStore
from auto_lora.reports.charts import generate_charts
from auto_lora.reports.exporter import export_csv, export_summary_json
from auto_lora.reports.html_report import generate_html_report
from rich.table import Table
from auto_lora.utils.display import (
    console,
    print_error,
    print_header,
    print_info,
    print_success,
)


def report_command(
    run: str = typer.Option(..., "--run", "-r", help="Run ID to generate report for."),
    open_browser: bool = typer.Option(True, "--open/--no-open", help="Open report in browser."),
) -> None:
    """Generate an HTML metrics report for a training run.

    Creates charts, CSV logs, and a self-contained HTML dashboard.
    """
    print_header("Auto-LoRA", "Report Generation")
    console.print()

    store = RunStore(DB_FILENAME)
    run_data = store.get_run(run)

    if not run_data:
        print_error(f"Run not found: {run}")
        raise typer.Exit(1)

    run_dir = Path(run_data.get("output_path", f"outputs/{run}"))
    if not run_dir.exists():
        print_error(f"Run output directory not found: {run_dir}")
        raise typer.Exit(1)

    trials = store.get_trials(run)
    artifacts = store.get_artifacts(run)

    # Generate charts
    charts_dir = run_dir / "charts"
    charts_dir.mkdir(exist_ok=True)
    chart_paths = generate_charts(trials, str(charts_dir))
    print_success(f"Generated {len(chart_paths)} chart(s)")

    # Export CSV
    csv_path = run_dir / "trials.csv"
    export_csv(trials, str(csv_path))
    print_success(f"Exported CSV → {csv_path}")

    # Export summary JSON
    summary_path = run_dir / "summary.json"
    export_summary_json(run_data, trials, str(summary_path))
    print_success(f"Exported summary → {summary_path}")

    # Generate HTML report
    html_path = run_dir / "metrics.html"
    generate_html_report(
        run_data=run_data,
        trials=trials,
        chart_paths=chart_paths,
        output_path=str(html_path),
    )
    print_success(f"Generated report → {html_path}")

    # Display Terminal Summary
    console.print()
    table = Table(title=f"Trial Leaderboard — {run}", title_style="bold cyan")
    table.add_column("#", justify="right", style="dim")
    table.add_column("Rank", justify="right")
    table.add_column("Alpha", justify="right")
    table.add_column("LR", justify="right")
    table.add_column("BS", justify="right")
    table.add_column("Val Loss", justify="right", style="green")
    table.add_column("Score", justify="right", style="bold yellow")
    table.add_column("Status", justify="left")

    # Show top 10 trials
    completed = [t for t in trials if t.get("status") == "completed"]
    for t in completed[:10]:
        table.add_row(
            str(t.get("trial_number")),
            str(t.get("rank")),
            str(t.get("alpha")),
            f"{t.get('learning_rate', 0):.2e}",
            str(t.get("batch_size")),
            f"{t.get('val_loss', 0):.4f}",
            f"{t.get('score', 0):.4f}",
            "[green]success[/green]"
        )
    
    console.print(table)

    # Record artifacts
    for path in [str(html_path), str(csv_path), str(summary_path)]:
        store.add_artifact(run, "report", path, "Generated report")

    console.print()
    print_success("[bold]Report generated successfully![/bold]")
    print_info(f"View: {html_path}")
    console.print()

    if open_browser:
        try:
            webbrowser.open(f"file://{html_path.resolve()}")
        except Exception:
            pass
