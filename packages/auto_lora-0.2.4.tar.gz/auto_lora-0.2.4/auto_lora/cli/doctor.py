"""doctor command — System health check."""

from __future__ import annotations

from auto_lora.hardware.analyzer import check_system_health
from auto_lora.utils.display import (
    console,
    print_error,
    print_header,
    print_success,
    print_warning,
)


def doctor_command() -> None:
    """Run system health checks.

    Verifies Python version, CUDA, GPU, disk space, dependencies,
    and write permissions.
    """
    print_header("Auto-LoRA", "System Health Check")
    console.print()

    checks = check_system_health()

    passed = 0
    warnings = 0
    failed = 0

    for check in checks:
        name = check["name"]
        status = check["status"]
        message = check["message"]

        if status == "pass":
            print_success(f"{name}: {message}")
            passed += 1
        elif status == "warn":
            print_warning(f"{name}: {message}")
            warnings += 1
        else:
            print_error(f"{name}: {message}")
            failed += 1

    console.print()
    console.print(
        f"  Results: [green]{passed} passed[/green], "
        f"[yellow]{warnings} warnings[/yellow], "
        f"[red]{failed} failed[/red]"
    )
    console.print()

    if failed > 0:
        console.print("  [bold red]⚠ Some checks failed. Please fix before training.[/bold red]")
    elif warnings > 0:
        console.print("  [bold yellow]System ready with warnings.[/bold yellow]")
    else:
        console.print("  [bold green]✓ All checks passed. System ready![/bold green]")

    console.print()
