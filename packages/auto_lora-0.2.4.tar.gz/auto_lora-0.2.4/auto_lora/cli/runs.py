"""runs commands — List and inspect training runs."""

from __future__ import annotations

import json
from typing import Optional

import typer

from auto_lora.core.constants import DB_FILENAME
from auto_lora.db.store import RunStore
from auto_lora.utils.display import (
    console,
    print_error,
    print_header,
    print_info,
    print_key_value,
    print_table,
)


def list_runs_command(
    limit: int = typer.Option(20, "--limit", "-n", help="Number of runs to show."),
) -> None:
    """List all training runs."""
    print_header("Auto-LoRA", "Training Runs")
    console.print()

    store = RunStore(DB_FILENAME)
    runs = store.list_runs(limit=limit)

    if not runs:
        print_info("No runs found. Start one with: auto-lora train")
        return

    columns = [
        {"name": "Run ID", "style": "cyan"},
        {"name": "Model", "style": ""},
        {"name": "Status", "style": ""},
        {"name": "Trials", "justify": "right"},
        {"name": "Best Score", "justify": "right"},
        {"name": "Runtime", "justify": "right"},
        {"name": "Created", "style": "dim"},
    ]

    rows = []
    for run in runs:
        status = run["status"]
        status_styled = {
            "completed": "✓ done",
            "running": "⟳ running",
            "failed": "✗ failed",
            "pending": "… pending",
        }.get(status, status)

        trials = f"{run.get('completed_trials', 0)}/{run.get('total_trials', 0)}"
        best_score = f"{run['best_score']:.4f}" if run.get("best_score") else "—"
        runtime = f"{run.get('total_runtime_seconds', 0):.0f}s"
        created = run.get("created_at", "")[:19]

        rows.append([run["id"], run["model_name"], status_styled, trials, best_score, runtime, created])

    print_table("Training Runs", columns, rows)
    console.print()


def show_run_command(
    run_id: str = typer.Argument(..., help="Run ID to show details for."),
) -> None:
    """Show detailed information about a training run."""
    print_header("Auto-LoRA", f"Run Details: {run_id}")
    console.print()

    store = RunStore(DB_FILENAME)
    run = store.get_run(run_id)

    if not run:
        print_error(f"Run not found: {run_id}")
        raise typer.Exit(1)

    # Run info
    print_key_value("Run ID", run["id"])
    print_key_value("Model", run["model_name"])
    print_key_value("Dataset", run["dataset_path"])
    print_key_value("Strategy", run.get("strategy", "—"))
    print_key_value("Preset", run.get("preset", "—") or "—")
    print_key_value("Status", run["status"])
    print_key_value("Created", run.get("created_at", "")[:19])
    print_key_value("Runtime", f"{run.get('total_runtime_seconds', 0):.0f}s")
    print_key_value("Output", run.get("output_path", "—"))
    console.print()

    # Trials
    trials = store.get_trials(run_id)
    if trials:
        columns = [
            {"name": "#", "justify": "right", "style": "dim"},
            {"name": "Rank", "justify": "right"},
            {"name": "Alpha", "justify": "right"},
            {"name": "LR", "justify": "right"},
            {"name": "BS", "justify": "right"},
            {"name": "Epochs", "justify": "right"},
            {"name": "Val Loss", "justify": "right"},
            {"name": "Score", "justify": "right", "style": "cyan"},
            {"name": "Memory", "justify": "right"},
            {"name": "Time", "justify": "right"},
            {"name": "Status"},
        ]

        rows = []
        for t in trials:
            lr = f"{t.get('learning_rate', 0):.2e}" if t.get("learning_rate") else "—"
            val_loss = f"{t['val_loss']:.4f}" if t.get("val_loss") else "—"
            score = f"{t['score']:.4f}" if t.get("score") else "—"
            mem = f"{t.get('peak_memory_gb', 0):.1f}GB" if t.get("peak_memory_gb") else "—"
            time_s = f"{t.get('runtime_seconds', 0):.0f}s" if t.get("runtime_seconds") else "—"

            rows.append([
                str(t["trial_number"]),
                str(t.get("rank", "—")),
                str(t.get("alpha", "—")),
                lr,
                str(t.get("batch_size", "—")),
                str(t.get("epochs", "—")),
                val_loss,
                score,
                mem,
                time_s,
                t.get("status", "—"),
            ])

        print_table("Trial Leaderboard", columns, rows, show_lines=True)

    # Artifacts
    artifacts = store.get_artifacts(run_id)
    if artifacts:
        console.print()
        console.print("  [bold]Artifacts:[/bold]")
        for a in artifacts:
            print_info(f"  [{a['artifact_type']}] {a['file_path']}")

    console.print()
