"""Main CLI application for Auto-LoRA (Click version).

Registers all commands and provides the main entry point.
Using Click directly to avoid Typer compatibility issues in this environment.
"""

from __future__ import annotations

import click
from rich.console import Console

from auto_lora import __version__

console = Console()

@click.group()
@click.version_option(__version__, "-v", "--version", message="auto_lora v%(version)s")
def cli():
    """🚀 Auto-LoRA — Automated Hyperparameter Optimization for LLM Fine-Tuning"""
    pass

@cli.group()
def runs():
    """Manage training runs — list, show, compare."""
    pass

# Import command functions
from auto_lora.cli.init_cmd import init_command
from auto_lora.cli.doctor import doctor_command
from auto_lora.cli.train import train_command
from auto_lora.cli.runs import list_runs_command, show_run_command
from auto_lora.cli.export_cmd import export_command
from auto_lora.cli.report import report_command
from auto_lora.cli.benchmark import benchmark_command

# Register commands
@cli.command(name="init")
@click.argument("directory", default=".")
def init_cli(directory):
    """Initialize Auto-LoRA project structure."""
    init_command(directory)

@cli.command(name="doctor")
def doctor_cli():
    """Run system health checks."""
    doctor_command()

@cli.command(name="train")
@click.option("--model", "-m", required=True, help="HuggingFace model name or local path.")
@click.option("--data", "-d", required=True, help="Path to dataset file.")
@click.option("--preset", "-p", help="Training preset.")
@click.option("--max-trials", "-t", default=10, help="Maximum number of tuning trials.")
@click.option("--max-hours", default=4.0, help="Maximum runtime in hours.")
@click.option("--epochs", "-e", default=3, help="Training epochs.")
@click.option("--batch-size", "-b", default=4, help="Batch size.")
@click.option("--lr", "learning_rate", default=2e-4, help="Learning rate.")
@click.option("--max-seq-length", default=512, help="Maximum sequence length.")
@click.option("--target-vram", type=float, help="Target VRAM limit in GB.")
@click.option("--output-dir", "-o", default="outputs", help="Output directory.")
@click.option("--seed", default=42, help="Random seed.")
@click.option("--wandb", "use_wandb", is_flag=True, help="Enable W&B tracking.")
@click.option("--max-samples", "-n", type=int, help="Maximum number of samples to load.")
@click.option("--unsloth/--no-unsloth", "use_unsloth", default=True, help="Use Unsloth optimization (if available).")
@click.option("--verbose", is_flag=True, help="Enable verbose output.")
def train_cli(**kwargs):
    """🚀 Train a LoRA adapter with automatic hyperparameter optimization."""
    train_command(**kwargs)

@cli.command(name="export")
@click.option("--run", "-r", required=True, help="Run ID to export.")
@click.option("--output", "-o", default="./export", help="Export destination.")
@click.option("--push-to-hub", help="Push to HuggingFace Hub.")
def export_cli(**kwargs):
    """Export the best adapter from a completed training run."""
    export_command(**kwargs)

@cli.command(name="report")
@click.option("--run", "-r", required=True, help="Run ID to generate report for.")
@click.option("--open/--no-open", "open_browser", default=True, help="Open report in browser.")
def report_cli(**kwargs):
    """Generate an HTML metrics report for a training run."""
    report_command(**kwargs)

@cli.command(name="benchmark")
@click.option("--run", "-r", required=True, help="Run ID to benchmark.")
@click.option("--prompts", "prompts_file", help="Custom prompts file.")
@click.option("--references", "references_file", help="Ground truth references file.")
@click.option("--max-tokens", type=int, default=256, help="Max tokens to generate per prompt.")
def benchmark_cli(**kwargs):
    """📊 Run scientific benchmark evaluation on a trained adapter."""
    benchmark_command(**kwargs)

@runs.command(name="list")
@click.option("--limit", "-n", default=20, help="Number of runs to show.")
def list_runs_cli(limit):
    """List all training runs."""
    list_runs_command(limit)

@runs.command(name="show")
@click.argument("run_id")
def show_run_cli(run_id):
    """Show detailed information about a training run."""
    show_run_command(run_id)

def main():
    cli()

if __name__ == "__main__":
    main()
