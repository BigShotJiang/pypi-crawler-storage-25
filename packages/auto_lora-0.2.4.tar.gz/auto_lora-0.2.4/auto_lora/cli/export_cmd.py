"""export command — Export trained adapter."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import typer

from auto_lora.core.constants import DB_FILENAME
from auto_lora.db.store import RunStore
from auto_lora.utils.display import (
    console,
    print_error,
    print_header,
    print_info,
    print_success,
)


def export_command(
    run: str = typer.Option(..., "--run", "-r", help="Run ID to export."),
    output: str = typer.Option("./export", "--output", "-o", help="Export destination."),
    push_to_hub: str = typer.Option("", "--push-to-hub", help="Push to HuggingFace Hub (e.g., username/adapter-name)."),
) -> None:
    """Export the best adapter from a completed training run.

    Packages the adapter files, config, and summary for distribution.
    Optionally pushes to HuggingFace Hub.
    """
    print_header("Auto-LoRA", "Export Adapter")
    console.print()

    store = RunStore(DB_FILENAME)
    run_data = store.get_run(run)

    if not run_data:
        print_error(f"Run not found: {run}")
        raise typer.Exit(1)

    if run_data["status"] != "completed":
        print_error(f"Run is not completed (status: {run_data['status']})")
        raise typer.Exit(1)

    # Find best trial adapter path
    best_trial = store.get_best_trial(run)
    if not best_trial or not best_trial.get("adapter_path"):
        print_error("No adapter found for this run")
        raise typer.Exit(1)

    adapter_src = Path(best_trial["adapter_path"])
    if not adapter_src.exists():
        print_error(f"Adapter directory not found: {adapter_src}")
        raise typer.Exit(1)

    # Copy to export destination
    export_dir = Path(output)
    export_dir.mkdir(parents=True, exist_ok=True)

    # Copy adapter files
    adapter_dest = export_dir / "adapter"
    if adapter_dest.exists():
        shutil.rmtree(adapter_dest)
    shutil.copytree(adapter_src, adapter_dest)
    print_success(f"Adapter copied → {adapter_dest}")

    # Copy summary and config if they exist
    run_dir = Path(run_data.get("output_path", ""))
    for filename in ("summary.json", "best_config.json"):
        src = run_dir / filename
        if src.exists():
            shutil.copy2(src, export_dir / filename)
            print_success(f"Copied {filename}")

    # Create a README
    readme_content = f"""# LoRA Adapter — {run_data['model_name']}

Trained with Auto-LoRA.

## Details
- **Base Model**: {run_data['model_name']}
- **Run ID**: {run}
- **Strategy**: {run_data.get('strategy', 'lora')}
- **Best Score**: {run_data.get('best_score', 'N/A')}

## Usage
```python
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

model = AutoModelForCausalLM.from_pretrained("{run_data['model_name']}")
model = PeftModel.from_pretrained(model, "./adapter")
tokenizer = AutoTokenizer.from_pretrained("./adapter")
```
"""
    (export_dir / "README.md").write_text(readme_content)
    print_success("Created README.md")

    # Push to HuggingFace Hub
    if push_to_hub:
        try:
            from huggingface_hub import HfApi
            api = HfApi()
            api.upload_folder(
                folder_path=str(adapter_dest),
                repo_id=push_to_hub,
                repo_type="model",
                commit_message=f"Upload LoRA adapter from run {run}",
            )
            print_success(f"Pushed to HuggingFace Hub: {push_to_hub}")
        except ImportError:
            print_error("huggingface_hub not installed. Run: pip install huggingface_hub")
        except Exception as e:
            print_error(f"Failed to push to Hub: {e}")

    console.print()
    print_success(f"[bold]Export complete → {export_dir}[/bold]")
    console.print()
