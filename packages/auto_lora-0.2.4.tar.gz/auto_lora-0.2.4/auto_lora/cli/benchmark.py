"""benchmark command — Evaluate trained adapter."""

from __future__ import annotations

import json
from pathlib import Path

import typer

from auto_lora.core.constants import DB_FILENAME
from auto_lora.db.store import RunStore
from auto_lora.metrics.benchmark import run_benchmark
from auto_lora.utils.display import (
    console,
    print_error,
    print_header,
    print_info,
    print_success,
    print_table,
)


def benchmark_command(
    run: str,
    prompts_file: str = "",
    references_file: str = "",
    max_tokens: int = 256,
) -> None:
    """Run benchmark evaluation on a trained adapter.

    Generates responses to test prompts and scores quality.
    """
    print_header("Auto-LoRA", "Benchmark Evaluation")
    console.print()

    store = RunStore(DB_FILENAME)
    run_data = store.get_run(run)

    if not run_data:
        print_error(f"Run not found: {run}")
        raise typer.Exit(1)

    # Find adapter path
    best_trial = store.get_best_trial(run)
    if not best_trial or not best_trial.get("adapter_path"):
        print_error("No adapter found for this run")
        raise typer.Exit(1)

    adapter_path = best_trial["adapter_path"]
    model_name = run_data["model_name"]

    # Load custom prompts if provided
    prompts = None
    if prompts_file:
        prompts_path = Path(prompts_file)
        if prompts_path.exists():
            prompts = [l.strip() for l in prompts_path.read_text().splitlines() if l.strip()]
            print_info(f"Loaded {len(prompts)} custom prompts")
        else:
            print_error(f"Prompts file not found: {prompts_file}")
            raise typer.Exit(1)

    # Load references if provided
    references = None
    if references_file:
        ref_path = Path(references_file)
        if ref_path.exists():
            references = [l.strip() for l in ref_path.read_text().splitlines() if l.strip()]
            print_info(f"Loaded {len(references)} ground truth references")
        else:
            print_error(f"References file not found: {references_file}")
            raise typer.Exit(1)

    print_info(f"Model: {model_name}")
    print_info(f"Adapter: {adapter_path}")
    print_info("Running benchmark...")
    console.print()

    result = run_benchmark(
        adapter_path=adapter_path,
        model_name=model_name,
        prompts=prompts,
        references=references,
        max_new_tokens=max_tokens,
    )

    # Display results
    columns = [
        {"name": "#", "justify": "right", "style": "dim"},
        {"name": "Prompt", "width": 40},
        {"name": "Qual. Score", "justify": "center"},
        {"name": "ROUGE-L", "justify": "center", "style": "green"},
        {"name": "BLEU", "justify": "center", "style": "blue"},
        {"name": "Semantic", "justify": "center", "style": "magenta"},
        {"name": "Length", "justify": "right", "style": "dim"},
    ]

    rows = []
    details = result.to_dict().get("details", [])
    for i, (prompt, response, score) in enumerate(
        zip(result.prompts, result.responses, result.scores)
    ):
        m = details[i] if i < len(details) else {}
        rouge_display = f"{m.get('rouge_l', 0.0):.2f}" if result.references else "—"
        bleu_display = f"{m.get('bleu', 0.0):.2f}" if result.references else "—"
        sem_display = f"{m.get('semantic_sim', 0.0):.2f}" if result.references else "—"
            
        rows.append([
            str(i + 1),
            prompt[:40] + ("..." if len(prompt) > 40 else ""),
            f"{score:.2f}",
            rouge_display,
            bleu_display,
            sem_display,
            str(len(response)),
        ])

    print_table("Benchmark Results", columns, rows, show_lines=True)

    console.print()
    from rich.panel import Panel
    from rich.columns import Columns
    
    perf_stats = (
        f"[bold blue]Inference Performance[/]\n"
        f"Throughput: [yellow]{result.avg_tps:.2f} tokens/s[/]\n"
        f"Avg Latency: [yellow]{result.avg_generation_time:.2f}s[/]\n"
        f"Peak VRAM: [yellow]{result.peak_vram_gb:.2f} GB[/]"
    )
    
    nlp_stats = (
        f"[bold green]Scientific NLP Metrics[/]\n"
        f"Concept Quality: [white]{result.avg_score:.2f}/1.00[/]\n"
        f"ROUGE-L (Overlap): [bold green]{result.avg_rouge_l:.2f}[/]\n"
        f"BLEU (Precision): [bold blue]{result.avg_bleu:.2f}[/bold blue]\n"
        f"Semantic (Meaning): [bold magenta]{result.avg_semantic_sim:.2f}[/bold magenta]\n"
        f"Samples: [white]{len(result.prompts)}[/]"
    )

    console.print(Columns([Panel(perf_stats), Panel(nlp_stats)]))

    # Save results in multiple formats
    run_dir = Path(run_data.get("output_path", f"outputs/{run}"))
    if run_dir.exists():
        # 1. JSON (for system)
        json_path = run_dir / "benchmark.json"
        json_path.write_text(json.dumps(result.to_dict(), indent=2))
        store.add_artifact(run, "benchmark_json", str(json_path), "Scientific results (JSON)")

        # 2. CSV (for Spreadsheet Analysis)
        import pandas as pd
        df = pd.DataFrame(result.to_dict()["details"])
        csv_path = run_dir / "benchmark.csv"
        df.to_csv(csv_path, index=False)
        store.add_artifact(run, "benchmark_csv", str(csv_path), "Scientific results (CSV)")

        # 3. Markdown (for Documentation/Reports)
        md_path = run_dir / "benchmark.md"
        with open(md_path, "w") as f:
            f.write(f"# Scientific Benchmark Report: {run}\n\n")
            f.write(f"**Model:** {model_name}\n\n")
            f.write(f"| # | Metric | Value |\n")
            f.write(f"|---|---|---|\n")
            f.write(f"| 1 | ROUGE-L (Overlap) | {result.avg_rouge_l:.2f} |\n")
            f.write(f"| 2 | BLEU (Precision) | {result.avg_bleu:.2f} |\n")
            f.write(f"| 3 | Semantic Sim (Meaning) | {result.avg_semantic_sim:.2f} |\n")
            f.write(f"| 4 | Throughput (TPS) | {result.avg_tps:.2f} |\n")
            f.write(f"| 5 | Peak VRAM | {result.peak_vram_gb:.2f} GB |\n\n")
            f.write("## Per-Sample Details\n\n")
            f.write(df.to_markdown(index=False))
        
        store.add_artifact(run, "benchmark_md", str(md_path), "Scientific results (Markdown)")
        
        print_success(f"Scientific results saved in JSON, CSV, and Markdown formats → {run_dir}")

    console.print()
