"""Auto-LoRA: Automated Hyperparameter Optimization for Efficient LLM Fine-Tuning."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("auto-lora")
except PackageNotFoundError:
    # Fallback for editable/local execution before installation.
    __version__ = "0.2.1"

__app_name__ = "auto_lora"
