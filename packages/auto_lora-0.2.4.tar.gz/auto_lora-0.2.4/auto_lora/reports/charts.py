"""Chart generation for reports.

Creates professional, clean scientific graphics for training analysis.
Focuses on real-world utility and clarity over visual flair.
"""

from __future__ import annotations

from pathlib import Path
import pandas as pd
import numpy as np

from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


def generate_charts(trials: list[dict], output_dir: str) -> list[str]:
    """Generate all charts for a set of trials.

    Args:
        trials: List of trial dicts from the database.
        output_dir: Directory to save chart images.

    Returns:
        List of chart file paths.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import seaborn as sns

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    completed = [t for t in trials if t.get("status") == "completed"]
    if not completed:
        logger.warning("No completed trials — skipping chart generation")
        return []

    df = pd.DataFrame(completed)
    
    # Calculate additional analysis metrics
    if "rank" in df.columns and "alpha" in df.columns:
        df["alpha_rank_ratio"] = df["alpha"] / df["rank"]
    
    if "runtime_seconds" in df.columns and len(df) > 0:
        # Assuming sample count is constant for the run, we just show relative speed
        df["speed_idx"] = 1000 / df["runtime_seconds"]

    chart_paths = []

    # Clean, Professional Scientific Theme
    sns.set_theme(style="whitegrid")
    plt.rcParams.update({
        "figure.facecolor": "white",
        "axes.facecolor": "#f8f9fa",
        "axes.edgecolor": "#dee2e6",
        "axes.labelcolor": "#212529",
        "xtick.color": "#495057",
        "ytick.color": "#495057",
        "grid.color": "#e9ecef",
        "text.color": "#212529",
        "font.size": 10,
        "axes.titlesize": 12,
        "axes.titleweight": "bold",
    })

    # 1. Parameter Importance (Correlation)
    try:
        path = _plot_parameter_importance(df, output_path)
        chart_paths.append(path)
    except Exception as e:
        logger.warning(f"Failed to generate importance chart: {e}")

    # 2. Alpha/Rank Scaling Analysis
    try:
        path = _plot_lora_scaling(df, output_path)
        chart_paths.append(path)
    except Exception as e:
        logger.warning(f"Failed to generate scaling chart: {e}")

    # 3. Throughput Analysis (Memory vs Speed)
    try:
        path = _plot_efficiency_frontier(df, output_path)
        chart_paths.append(path)
    except Exception as e:
        logger.warning(f"Failed to generate efficiency chart: {e}")

    # 4. Hyperparameter Distribution (Joint Plot)
    try:
        path = _plot_hp_distribution(df, output_path)
        chart_paths.append(path)
    except Exception as e:
        logger.warning(f"Failed to generate distribution chart: {e}")

    # 5. Traditional Optimization Trace
    try:
        path = _plot_optimization_trace(df, output_path)
        chart_paths.append(path)
    except Exception as e:
        logger.warning(f"Failed to generate trace chart: {e}")

    logger.info(f"Generated {len(chart_paths)} analysis charts")
    return chart_paths


def _plot_parameter_importance(df: pd.DataFrame, output_dir: Path) -> str:
    """Show which hyperparameters correlate strongest with the score."""
    import matplotlib.pyplot as plt
    import seaborn as sns

    fig, ax = plt.subplots(figsize=(8, 5))
    
    cols = ["rank", "alpha", "learning_rate", "batch_size", "epochs"]
    available_cols = [c for c in cols if c in df.columns]
    
    # Calculate absolute correlation with score
    corrs = df[available_cols].apply(lambda x: x.corr(df["score"])).abs().sort_values(ascending=False)
    
    sns.barplot(x=corrs.values, y=corrs.index, palette="viridis", ax=ax)
    
    ax.set_xlabel("Relative Importance (Absolute Correlation)")
    ax.set_title("Hyperparameter Sensitivity Analysis")
    
    path = str(output_dir / "hp_importance.png")
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)
    return path


def _plot_lora_scaling(df: pd.DataFrame, output_dir: Path) -> str:
    """Analyze the impact of Alpha/Rank ratio on performance."""
    import matplotlib.pyplot as plt
    import seaborn as sns

    fig, ax = plt.subplots(figsize=(8, 6))
    
    sns.scatterplot(data=df, x="alpha_rank_ratio", y="score", hue="rank", 
                    size="alpha", sizes=(50, 200), palette="deep", alpha=0.7, ax=ax)
    
    ax.set_xlabel("Scaling Ratio (Alpha / Rank)")
    ax.set_ylabel("Trial Score")
    ax.set_title("LoRA Scaling Factor Analysis")
    ax.legend(title="Rank", bbox_to_anchor=(1.05, 1), loc='upper left')
    
    path = str(output_dir / "lora_scaling.png")
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)
    return path


def _plot_efficiency_frontier(df: pd.DataFrame, output_dir: Path) -> str:
    """Compare training speed vs memory usage to find the efficiency frontier."""
    import matplotlib.pyplot as plt
    import seaborn as sns

    fig, ax = plt.subplots(figsize=(8, 6))
    
    sns.scatterplot(data=df, x="peak_memory_gb", y="runtime_seconds", 
                    hue="batch_size", palette="Set1", s=100, ax=ax)
    
    ax.set_xlabel("Peak VRAM Usage (GB)")
    ax.set_ylabel("Total Runtime (seconds)")
    ax.set_title("Hardware Efficiency Profile")
    
    path = str(output_dir / "efficiency_frontier.png")
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)
    return path


def _plot_hp_distribution(df: pd.DataFrame, output_dir: Path) -> str:
    """Show the distribution of LR vs Rank across the search space."""
    import matplotlib.pyplot as plt
    import seaborn as sns

    g = sns.JointGrid(data=df, x="learning_rate", y="rank", marginal_ticks=True)
    g.plot_joint(sns.scatterplot, s=100, alpha=.5, color="#4e79a7")
    g.plot_marginals(sns.histplot, kde=True, color="#4e79a7")
    
    g.ax_joint.set_xscale("log")
    g.fig.suptitle("Hyperparameter Search Distribution", y=1.02, fontweight="bold")
    
    path = str(output_dir / "search_distribution.png")
    g.fig.savefig(path, dpi=120)
    plt.close(g.fig)
    return path


def _plot_optimization_trace(df: pd.DataFrame, output_dir: Path) -> str:
    """Standard optimization trace with validation loss confidence interval."""
    import matplotlib.pyplot as plt
    import seaborn as sns

    fig, ax = plt.subplots(figsize=(10, 5))
    
    sns.lineplot(data=df, x="trial_number", y="val_loss", marker="o", color="#e15759", linewidth=2, ax=ax)
    
    ax.set_xlabel("Trial Sequence")
    ax.set_ylabel("Validation Loss")
    ax.set_title("Training Convergence Trace")
    
    path = str(output_dir / "optimization_trace.png")
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)
    return path
