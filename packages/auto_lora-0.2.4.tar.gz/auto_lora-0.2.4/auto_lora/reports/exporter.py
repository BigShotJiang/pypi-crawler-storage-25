"""Data export utilities for reports.

Exports trial data as CSV and JSON for external analysis.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


def export_csv(trials: list[dict], output_path: str) -> str:
    """Export trial results as CSV.

    Args:
        trials: List of trial dicts.
        output_path: Output CSV file path.

    Returns:
        Path to generated CSV file.
    """
    if not trials:
        logger.warning("No trials to export")
        return output_path

    # Define columns
    columns = [
        "trial_number", "rank", "alpha", "dropout", "learning_rate",
        "batch_size", "epochs", "warmup_ratio", "train_loss", "val_loss",
        "perplexity", "runtime_seconds", "peak_memory_gb",
        "tokens_per_second", "score", "status",
    ]

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for trial in trials:
            writer.writerow(trial)

    logger.info(f"Exported {len(trials)} trials to CSV: {output_path}")
    return output_path


def export_summary_json(
    run_data: dict[str, Any],
    trials: list[dict],
    output_path: str,
) -> str:
    """Export full run summary as JSON.

    Args:
        run_data: Run metadata.
        trials: List of trial dicts.
        output_path: Output JSON file path.

    Returns:
        Path to generated JSON file.
    """
    completed = [t for t in trials if t.get("status") == "completed"]
    best = completed[0] if completed else None

    summary = {
        "run_id": run_data.get("id"),
        "model_name": run_data.get("model_name"),
        "dataset_path": run_data.get("dataset_path"),
        "strategy": run_data.get("strategy"),
        "preset": run_data.get("preset"),
        "status": run_data.get("status"),
        "total_trials": len(trials),
        "completed_trials": len(completed),
        "total_runtime_seconds": run_data.get("total_runtime_seconds", 0),
        "created_at": run_data.get("created_at"),
        "completed_at": run_data.get("completed_at"),
        "best_trial": {
            "trial_number": best.get("trial_number"),
            "rank": best.get("rank"),
            "alpha": best.get("alpha"),
            "learning_rate": best.get("learning_rate"),
            "batch_size": best.get("batch_size"),
            "epochs": best.get("epochs"),
            "val_loss": best.get("val_loss"),
            "score": best.get("score"),
            "peak_memory_gb": best.get("peak_memory_gb"),
            "adapter_path": best.get("adapter_path"),
        } if best else None,
        "all_trials": [
            {
                "trial_number": t.get("trial_number"),
                "rank": t.get("rank"),
                "alpha": t.get("alpha"),
                "learning_rate": t.get("learning_rate"),
                "val_loss": t.get("val_loss"),
                "score": t.get("score"),
                "status": t.get("status"),
            }
            for t in trials
        ],
    }

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")

    logger.info(f"Exported summary JSON: {output_path}")
    return output_path
