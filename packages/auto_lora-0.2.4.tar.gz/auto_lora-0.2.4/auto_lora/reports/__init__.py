"""Report generation: HTML, charts, CSV/JSON export."""
