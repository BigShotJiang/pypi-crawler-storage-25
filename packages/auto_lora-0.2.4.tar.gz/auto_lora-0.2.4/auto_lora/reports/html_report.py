"""HTML report generator.

Creates a professional, clean metrics dashboard with a light, 
readable "scientific report" aesthetic.
"""

from __future__ import annotations

import base64
from pathlib import Path
from typing import Any

from auto_lora import __version__
from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


def generate_html_report(
    run_data: dict[str, Any],
    trials: list[dict],
    chart_paths: list[str] | None = None,
    output_path: str = "metrics.html",
) -> str:
    """Generate a clean, professional HTML report.

    Args:
        run_data: Run metadata dict.
        trials: List of trial dicts.
        chart_paths: Paths to chart images to embed.
        output_path: Output HTML file path.

    Returns:
        Path to generated HTML file.
    """
    # Embed chart images as base64
    chart_images = []
    for chart_path in (chart_paths or []):
        path = Path(chart_path)
        if path.exists():
            with open(path, "rb") as f:
                b64 = base64.b64encode(f.read()).decode()
            chart_images.append({
                "name": path.stem.replace("_", " ").title(),
                "data": f"data:image/png;base64,{b64}",
            })

    # Build HTML
    html = _build_html(run_data, trials, chart_images)

    # Write file
    Path(output_path).write_text(html, encoding="utf-8")
    logger.info(f"HTML report generated: {output_path}")
    return output_path


def _build_html(
    run: dict, trials: list[dict], charts: list[dict]
) -> str:
    """Build the HTML string."""
    completed = [t for t in trials if t.get("status") == "completed"]
    best = completed[0] if completed else None

    # Trial rows
    trial_rows = ""
    for t in trials:
        status_class = {
            "completed": "status-completed",
            "failed": "status-failed",
            "pruned": "status-pruned",
        }.get(t.get("status", ""), "")

        lr = f"{t.get('learning_rate', 0):.2e}" if t.get("learning_rate") else "—"
        val_loss = f"{t['val_loss']:.4f}" if t.get("val_loss") else "—"
        score = f"{t['score']:.4f}" if t.get("score") else "—"
        mem = f"{t.get('peak_memory_gb', 0):.2f} GB" if t.get("peak_memory_gb") else "—"
        time_s = f"{t.get('runtime_seconds', 0):.0f}s" if t.get("runtime_seconds") else "—"

        is_best = " class='best-row'" if best and t.get("trial_number") == best.get("trial_number") else ""

        trial_rows += f"""
        <tr{is_best}>
            <td>{t.get('trial_number', '—')}</td>
            <td>{t.get('rank', '—')}</td>
            <td>{t.get('alpha', '—')}</td>
            <td><code>{lr}</code></td>
            <td>{t.get('batch_size', '—')}</td>
            <td>{t.get('epochs', '—')}</td>
            <td>{val_loss}</td>
            <td><strong>{score}</strong></td>
            <td>{mem}</td>
            <td>{time_s}</td>
            <td><span class='status-pill {status_class}'>{t.get('status', '—')}</span></td>
        </tr>"""

    # Chart images
    chart_html = ""
    for chart in charts:
        chart_html += f"""
        <div class="chart-container">
            <h3 class="chart-title">{chart['name']}</h3>
            <img src="{chart['data']}" alt="{chart['name']}">
        </div>"""

    best_config_html = ""
    if best:
        best_config_html = f"""
        <section class="summary-section">
            <h2 class="section-title">🏆 Best Configuration</h2>
            <div class="summary-grid">
                <div class="summary-card">
                    <span class="label">Top Trial</span>
                    <span class="value">#{best.get('trial_number')}</span>
                </div>
                <div class="summary-card">
                    <span class="label">Best Score</span>
                    <span class="value accent">{best.get('score', 0):.4f}</span>
                </div>
                <div class="summary-card">
                    <span class="label">Min Val Loss</span>
                    <span class="value">{best.get('val_loss', 0):.4f}</span>
                </div>
                <div class="summary-card">
                    <span class="label">Optimized Config</span>
                    <span class="value-small">Rank: {best.get('rank')} | Alpha: {best.get('alpha')} | LR: {best.get('learning_rate', 0):.1e}</span>
                </div>
            </div>
        </section>"""

    best_score_str = f"{run.get('best_score'):.4f}" if run.get('best_score') is not None else "—"
    runtime_str = f"{run.get('total_runtime_seconds', 0):.0f}s" if run.get('total_runtime_seconds') else "—"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Training Report — {run.get('id', 'unknown')}</title>
    <style>
        :root {{
            --bg: #ffffff;
            --text: #1a1a1a;
            --text-muted: #666666;
            --border: #e1e4e8;
            --accent: #0366d6;
            --success: #28a745;
            --error: #d73a49;
            --warning: #f9c513;
            --card-bg: #f6f8fa;
        }}
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; color: var(--text); background: var(--bg); line-height: 1.5; padding: 40px 20px; }}
        .wrapper {{ max-width: 1000px; margin: 0 auto; }}
        
        header {{ margin-bottom: 40px; border-bottom: 1px solid var(--border); padding-bottom: 20px; }}
        h1 {{ font-size: 28px; font-weight: 600; margin-bottom: 8px; }}
        .meta {{ color: var(--text-muted); font-size: 14px; }}
        
        .section-title {{ font-size: 20px; font-weight: 600; margin-bottom: 20px; color: var(--text); display: flex; align-items: center; gap: 10px; }}
        section {{ margin-bottom: 60px; }}
        
        .summary-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; }}
        .summary-card {{ background: var(--card-bg); padding: 20px; border-radius: 6px; border: 1px solid var(--border); }}
        .summary-card .label {{ display: block; font-size: 12px; color: var(--text-muted); text-transform: uppercase; font-weight: 600; margin-bottom: 4px; }}
        .summary-card .value {{ display: block; font-size: 24px; font-weight: 600; }}
        .summary-card .value-small {{ display: block; font-size: 14px; font-weight: 500; margin-top: 4px; }}
        .accent {{ color: var(--accent); }}
        
        table {{ width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 14px; }}
        th {{ text-align: left; padding: 12px; border-bottom: 2px solid var(--border); color: var(--text-muted); font-weight: 600; }}
        td {{ padding: 12px; border-bottom: 1px solid var(--border); }}
        tr:hover {{ background: #fafbfc; }}
        .best-row {{ background: #f1f8ff !important; }}
        
        .status-pill {{ padding: 2px 8px; border-radius: 12px; font-size: 12px; font-weight: 500; text-transform: capitalize; }}
        .status-completed {{ background: #dcffe4; color: #155724; }}
        .status-failed {{ background: #ffdce0; color: #721c24; }}
        .status-pruned {{ background: #fff5d1; color: #856404; }}
        
        .charts-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }}
        .chart-container {{ background: white; border: 1px solid var(--border); padding: 15px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }}
        .chart-title {{ font-size: 14px; margin-bottom: 10px; color: var(--text-muted); text-align: center; }}
        .chart-container img {{ width: 100%; height: auto; }}
        
        footer {{ margin-top: 80px; text-align: center; color: var(--text-muted); font-size: 12px; border-top: 1px solid var(--border); padding-top: 20px; }}
        
        code {{ background: #f3f4f4; padding: 2px 4px; border-radius: 4px; font-family: ui-monospace, SFMono-Regular, SF Mono, Menlo, Consolas, Liberation Mono, monospace; }}
        
        @media (max-width: 768px) {{
            .charts-grid {{ grid-template-columns: 1fr; }}
            .summary-grid {{ grid-template-columns: 1fr 1fr; }}
        }}
    </style>
</head>
<body>
    <div class="wrapper">
        <header>
            <h1>Fine-Tuning Performance Report</h1>
            <div class="meta">
                <span>Run ID: <strong>{run.get('id')}</strong></span> • 
                <span>Model: {run.get('model_name')}</span> • 
                <span>Runtime: {runtime_str}</span>
            </div>
        </header>

        {best_config_html}

        <section>
            <h2 class="section-title">📈 Analytical Visualizations</h2>
            <div class="charts-grid">
                {chart_html}
            </div>
        </section>

        <section>
            <h2 class="section-title">📋 Trial Leaderboard</h2>
            <table>
                <thead>
                    <tr>
                        <th>Trial</th><th>Rank</th><th>Alpha</th><th>LR</th><th>Batch</th><th>Epochs</th><th>Val Loss</th><th>Score</th><th>VRAM</th><th>Time</th><th>Status</th>
                    </tr>
                </thead>
                <tbody>{trial_rows}</tbody>
            </table>
        </section>

        <footer>
            Generated by Auto-LoRA Analysis Engine v{__version__}
        </footer>
    </div>
</body>
</html>"""
