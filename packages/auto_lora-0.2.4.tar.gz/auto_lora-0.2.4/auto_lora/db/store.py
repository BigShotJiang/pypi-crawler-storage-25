"""SQLite data store for run and trial metadata.

Zero-config database using Python's built-in sqlite3.
All data stored in a single file: auto_lora.db
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from auto_lora.core.constants import DB_FILENAME
from auto_lora.db.models import ALL_CREATE_STATEMENTS
from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


class RunStore:
    """SQLite-based store for training runs and trials."""

    def __init__(self, db_path: Optional[str | Path] = None):
        """Initialize the store.

        Args:
            db_path: Path to SQLite database file. Defaults to ./auto_lora.db
        """
        self.db_path = str(db_path or DB_FILENAME)
        self._init_db()

    def _init_db(self) -> None:
        """Create tables if they don't exist."""
        with self._connect() as conn:
            for stmt in ALL_CREATE_STATEMENTS:
                conn.execute(stmt)
            conn.commit()
        logger.debug(f"Database initialized: {self.db_path}")

    def _connect(self) -> sqlite3.Connection:
        """Create a database connection."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _now(self) -> str:
        """Get current timestamp as ISO string."""
        return datetime.now().isoformat()

    # ─── Run Operations ──────────────────────────────────────────

    def create_run(
        self,
        run_id: str,
        model_name: str,
        dataset_path: str,
        goal_type: str = "general",
        preset: Optional[str] = None,
        strategy: str = "lora",
        max_trials: int = 10,
        config: Optional[dict] = None,
        output_path: str = "",
    ) -> str:
        """Create a new training run record.

        Returns:
            The run_id.
        """
        now = self._now()
        config_json = json.dumps(config) if config else None

        with self._connect() as conn:
            conn.execute(
                """INSERT INTO runs 
                   (id, model_name, dataset_path, goal_type, preset, strategy,
                    max_trials, status, config_json, output_path, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, 'running', ?, ?, ?, ?)""",
                (run_id, model_name, dataset_path, goal_type, preset,
                 strategy, max_trials, config_json, output_path, now, now),
            )
            conn.commit()

        logger.info(f"Created run: {run_id}")
        return run_id

    def update_run(self, run_id: str, **kwargs: Any) -> None:
        """Update run fields."""
        kwargs["updated_at"] = self._now()
        set_clause = ", ".join(f"{k} = ?" for k in kwargs)
        values = list(kwargs.values()) + [run_id]

        with self._connect() as conn:
            conn.execute(
                f"UPDATE runs SET {set_clause} WHERE id = ?",
                values,
            )
            conn.commit()

    def complete_run(
        self,
        run_id: str,
        best_trial_id: Optional[int] = None,
        best_score: Optional[float] = None,
        total_runtime: float = 0.0,
    ) -> None:
        """Mark a run as completed."""
        self.update_run(
            run_id,
            status="completed",
            best_trial_id=best_trial_id,
            best_score=best_score,
            total_runtime_seconds=total_runtime,
            completed_at=self._now(),
        )
        logger.info(f"Completed run: {run_id}")

    def fail_run(self, run_id: str, error: str = "") -> None:
        """Mark a run as failed."""
        self.update_run(run_id, status="failed", completed_at=self._now())
        logger.error(f"Failed run: {run_id} — {error}")

    def get_run(self, run_id: str) -> Optional[dict]:
        """Get a single run by ID."""
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM runs WHERE id = ?", (run_id,)).fetchone()
        return dict(row) if row else None

    def list_runs(self, limit: int = 50) -> list[dict]:
        """List all runs, newest first."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM runs ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]

    def delete_run(self, run_id: str) -> bool:
        """Delete a run and its trials/artifacts."""
        with self._connect() as conn:
            conn.execute("DELETE FROM artifacts WHERE run_id = ?", (run_id,))
            conn.execute("DELETE FROM trials WHERE run_id = ?", (run_id,))
            result = conn.execute("DELETE FROM runs WHERE id = ?", (run_id,))
            conn.commit()
        return result.rowcount > 0

    # ─── Trial Operations ────────────────────────────────────────

    def add_trial(
        self,
        run_id: str,
        trial_number: int,
        lora_config: dict,
        training_args: Optional[dict] = None,
    ) -> int:
        """Add a trial record. Returns the trial row ID."""
        now = self._now()
        config_json = json.dumps({
            "lora": lora_config,
            "training": training_args or {},
        })

        with self._connect() as conn:
            cursor = conn.execute(
                """INSERT INTO trials
                   (run_id, trial_number, rank, alpha, dropout, learning_rate,
                    batch_size, epochs, warmup_ratio, target_modules,
                    status, config_json, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'running', ?, ?)""",
                (
                    run_id, trial_number,
                    lora_config.get("rank"), lora_config.get("alpha"),
                    lora_config.get("dropout"), lora_config.get("learning_rate"),
                    lora_config.get("batch_size"), lora_config.get("epochs"),
                    lora_config.get("warmup_ratio"),
                    json.dumps(lora_config.get("target_modules", [])),
                    config_json, now,
                ),
            )
            conn.commit()
            # Update run trial count
            conn.execute(
                "UPDATE runs SET total_trials = total_trials + 1, updated_at = ? WHERE id = ?",
                (now, run_id),
            )
            conn.commit()
        return cursor.lastrowid or 0

    def update_trial(self, trial_id: int, **kwargs: Any) -> None:
        """Update trial fields."""
        set_clause = ", ".join(f"{k} = ?" for k in kwargs)
        values = list(kwargs.values()) + [trial_id]

        with self._connect() as conn:
            conn.execute(f"UPDATE trials SET {set_clause} WHERE id = ?", values)
            conn.commit()

    def complete_trial(
        self,
        trial_id: int,
        run_id: str,
        train_loss: float,
        val_loss: float,
        perplexity: float,
        runtime_seconds: float,
        peak_memory_gb: float,
        tokens_per_second: float,
        score: float,
        adapter_path: str = "",
    ) -> None:
        """Mark a trial as completed with metrics."""
        self.update_trial(
            trial_id,
            train_loss=train_loss,
            val_loss=val_loss,
            perplexity=perplexity,
            runtime_seconds=runtime_seconds,
            peak_memory_gb=peak_memory_gb,
            tokens_per_second=tokens_per_second,
            score=score,
            status="completed",
            adapter_path=adapter_path,
        )
        # Update completed count
        now = self._now()
        with self._connect() as conn:
            conn.execute(
                "UPDATE runs SET completed_trials = completed_trials + 1, updated_at = ? WHERE id = ?",
                (now, run_id),
            )
            conn.commit()

    def fail_trial(self, trial_id: int, error: str = "") -> None:
        """Mark a trial as failed."""
        self.update_trial(trial_id, status="failed", error_message=error)

    def get_trials(self, run_id: str) -> list[dict]:
        """Get all trials for a run, ordered by score descending."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM trials WHERE run_id = ? ORDER BY score DESC",
                (run_id,),
            ).fetchall()
        return [dict(r) for r in rows]

    def get_best_trial(self, run_id: str) -> Optional[dict]:
        """Get the best trial (highest score) for a run."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM trials WHERE run_id = ? AND status = 'completed' ORDER BY score DESC LIMIT 1",
                (run_id,),
            ).fetchone()
        return dict(row) if row else None

    # ─── Artifact Operations ─────────────────────────────────────

    def add_artifact(
        self,
        run_id: str,
        artifact_type: str,
        file_path: str,
        description: str = "",
    ) -> int:
        """Record an artifact (adapter, report, chart, etc.)."""
        now = self._now()
        with self._connect() as conn:
            cursor = conn.execute(
                """INSERT INTO artifacts (run_id, artifact_type, file_path, description, created_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (run_id, artifact_type, file_path, description, now),
            )
            conn.commit()
        return cursor.lastrowid or 0

    def get_artifacts(self, run_id: str) -> list[dict]:
        """Get all artifacts for a run."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM artifacts WHERE run_id = ? ORDER BY created_at",
                (run_id,),
            ).fetchall()
        return [dict(r) for r in rows]
