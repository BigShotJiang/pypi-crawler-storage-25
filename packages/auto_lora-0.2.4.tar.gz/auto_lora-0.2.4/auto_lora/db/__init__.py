"""SQLite database layer for run/trial metadata."""
