"""SQLite database models for run/trial metadata.

Zero-configuration database — just a single file (auto_lora.db).
Uses Python's built-in sqlite3 module, no external ORM needed.
"""

from __future__ import annotations

# SQL statements for table creation
CREATE_RUNS_TABLE = """
CREATE TABLE IF NOT EXISTS runs (
    id TEXT PRIMARY KEY,
    model_name TEXT NOT NULL,
    dataset_path TEXT NOT NULL,
    goal_type TEXT DEFAULT 'general',
    preset TEXT,
    strategy TEXT DEFAULT 'lora',
    max_trials INTEGER DEFAULT 10,
    status TEXT DEFAULT 'pending',
    best_trial_id INTEGER,
    best_score REAL,
    total_trials INTEGER DEFAULT 0,
    completed_trials INTEGER DEFAULT 0,
    total_runtime_seconds REAL DEFAULT 0,
    config_json TEXT,
    output_path TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    completed_at TEXT
);
"""

CREATE_TRIALS_TABLE = """
CREATE TABLE IF NOT EXISTS trials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    trial_number INTEGER NOT NULL,
    rank INTEGER,
    alpha INTEGER,
    dropout REAL,
    learning_rate REAL,
    batch_size INTEGER,
    epochs INTEGER,
    warmup_ratio REAL,
    target_modules TEXT,
    train_loss REAL,
    val_loss REAL,
    perplexity REAL,
    runtime_seconds REAL,
    peak_memory_gb REAL,
    tokens_per_second REAL,
    score REAL,
    status TEXT DEFAULT 'pending',
    error_message TEXT,
    adapter_path TEXT,
    config_json TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (run_id) REFERENCES runs(id)
);
"""

CREATE_ARTIFACTS_TABLE = """
CREATE TABLE IF NOT EXISTS artifacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    artifact_type TEXT NOT NULL,
    file_path TEXT NOT NULL,
    description TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (run_id) REFERENCES runs(id)
);
"""

ALL_CREATE_STATEMENTS = [
    CREATE_RUNS_TABLE,
    CREATE_TRIALS_TABLE,
    CREATE_ARTIFACTS_TABLE,
]
