"""Custom HuggingFace Trainer callbacks.

- MetricsCollectorCallback: Collects per-step metrics for reporting
- OptunaPruningCallback: Reports intermediate values to Optuna for early stopping
"""

from __future__ import annotations

from typing import Any

from transformers import TrainerCallback, TrainerControl, TrainerState, TrainingArguments

from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


class MetricsCollectorCallback(TrainerCallback):
    """Collects training metrics at each logging step.

    Stores a history of metrics (loss, learning rate, etc.) that
    can be used for charts and reports after training.
    """

    def __init__(self) -> None:
        self.metrics_history: list[dict] = []
        self.current_epoch: float = 0.0

    def on_log(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        logs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Capture metrics at each log step."""
        if logs is None:
            return

        entry = {
            "step": state.global_step,
            "epoch": state.epoch or 0.0,
            "loss": logs.get("loss"),
            "eval_loss": logs.get("eval_loss"),
            "learning_rate": logs.get("learning_rate"),
            "grad_norm": logs.get("grad_norm"),
        }
        # Remove None values
        entry = {k: v for k, v in entry.items() if v is not None}
        self.metrics_history.append(entry)

    def on_epoch_end(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        **kwargs: Any,
    ) -> None:
        """Track epoch completion."""
        self.current_epoch = state.epoch or 0.0


class OptunaPruningCallback(TrainerCallback):
    """Reports intermediate training metrics to Optuna for trial pruning.

    If Optuna determines a trial is unpromising, it raises an exception
    that terminates training early, saving time and compute.
    """

    def __init__(self, trial: Any) -> None:
        """Initialize with an Optuna trial.

        Args:
            trial: optuna.trial.Trial instance.
        """
        self.trial = trial

    def on_evaluate(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        metrics: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Report eval loss to Optuna and check for pruning."""
        import optuna

        if metrics is None:
            return

        eval_loss = metrics.get("eval_loss")
        if eval_loss is None:
            return

        step = state.global_step

        # Report to Optuna
        self.trial.report(eval_loss, step)

        # Check if trial should be pruned
        if self.trial.should_prune():
            logger.info(f"Trial pruned at step {step} (eval_loss={eval_loss:.4f})")
            raise optuna.TrialPruned(f"Pruned at step {step}")
