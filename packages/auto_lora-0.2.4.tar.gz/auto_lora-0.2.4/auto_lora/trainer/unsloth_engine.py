"""Unsloth optimization engine.

Provides helper functions for loading models and applying adapters using
Unsloth's FastLanguageModel for significantly faster training and lower VRAM.
"""

from __future__ import annotations

from typing import Any, Optional
from auto_lora.core.config import LoRAConfig, TrainingStrategy
from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)

def is_unsloth_available() -> bool:
    """Check if unsloth library is installed and available."""
    try:
        import unsloth
        return True
    except ImportError:
        return False

def is_model_supported_by_unsloth(model_name: str) -> bool:
    """Check if the given model is in the list of Unsloth-supported architectures."""
    # List of common architectures supported by Unsloth
    supported_keywords = [
        "llama", "mistral", "gemma", "phi", "qwen", "stablelm", "yi"
    ]
    name_lower = model_name.lower()
    return any(kw in name_lower for kw in supported_keywords)

def load_unsloth_model(
    model_name: str,
    max_seq_length: int = 512,
    load_in_4bit: bool = True,
) -> tuple[Any, Any]:
    """Load a model using Unsloth's FastLanguageModel."""
    from unsloth import FastLanguageModel
    import torch

    logger.info(f"🚀 Loading model with Unsloth: {model_name}")
    
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name = model_name,
        max_seq_length = max_seq_length,
        dtype = None, # Auto-detect (float16/bfloat16)
        load_in_4bit = load_in_4bit,
        trust_remote_code = True,
    )
    
    return model, tokenizer

def apply_unsloth_lora(model: Any, lora_config: LoRAConfig) -> Any:
    """Apply LoRA using Unsloth's optimized get_peft_model."""
    from unsloth import FastLanguageModel
    
    logger.info("🎨 Applying Unsloth-optimized LoRA patches")
    
    model = FastLanguageModel.get_peft_model(
        model,
        r = lora_config.rank,
        target_modules = lora_config.target_modules,
        lora_alpha = lora_config.alpha,
        lora_dropout = lora_config.dropout,
        bias = lora_config.bias,
        use_gradient_checkpointing = "unsloth", # Optimized gradient checkpointing
        random_state = 3407,
        use_rslora = False,
        loftq_config = None,
    )
    
    return model
