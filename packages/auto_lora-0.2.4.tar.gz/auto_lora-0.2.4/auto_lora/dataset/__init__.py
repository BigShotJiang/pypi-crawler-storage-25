"""Dataset loading, validation, and formatting."""
