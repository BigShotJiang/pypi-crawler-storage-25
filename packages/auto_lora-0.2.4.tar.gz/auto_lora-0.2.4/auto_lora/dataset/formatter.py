"""Dataset formatting for training.

Converts raw dataset entries into the format expected by HuggingFace trainers:
- Applies chat templates for conversational models
- Creates instruction-response text formatting
- Handles train/validation splitting
"""

from __future__ import annotations
from typing import Optional
from auto_lora.core.config import DatasetFormat
from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)

# Default instruction template
INSTRUCTION_TEMPLATE = """### Instruction:
{instruction}

### Input:
{input}

### Response:
{output}"""

INSTRUCTION_NO_INPUT_TEMPLATE = """### Instruction:
{instruction}

### Response:
{output}"""


def format_for_training(
    data: list[dict],
    format: Optional[DatasetFormat] = None,
    max_seq_length: int = 512,
) -> list[dict]:
    """Format dataset entries for training.

    Converts various formats into a unified {'text': ...} format
    suitable for SFTTrainer.

    Args:
        data: Raw dataset entries.
        format: Dataset format. If None, auto-inferred.
        max_seq_length: Maximum sequence length (for reference only).

    Returns:
        List of dicts with 'text' key containing formatted training text.
    """
    if not data:
        return []

    if format is None:
        format = _infer_format(data)

    if format == DatasetFormat.ALPACA:
        formatted = _format_alpaca(data)
    elif format == DatasetFormat.CONVERSATIONAL:
        formatted = _format_conversational(data)
    elif format == DatasetFormat.TXT:
        formatted = data  # Already in {'text': ...} format
    else:
        formatted = _format_generic(data)

    logger.info(f"Formatted {len(formatted)} samples for training")
    return formatted


def _infer_format(data: list[dict]) -> DatasetFormat:
    """Infer format from data structure."""
    if not data:
        return DatasetFormat.JSON
    keys = set(data[0].keys())
    if "messages" in keys:
        return DatasetFormat.CONVERSATIONAL
    if "instruction" in keys:
        return DatasetFormat.ALPACA
    if keys == {"text"}:
        return DatasetFormat.TXT
    return DatasetFormat.JSON


def _format_alpaca(data: list[dict]) -> list[dict]:
    """Format Alpaca-style instruction data."""
    formatted = []
    for row in data:
        instruction = row.get("instruction", "")
        input_text = row.get("input", "")
        output = row.get("output", row.get("response", ""))

        if input_text and input_text.strip():
            text = INSTRUCTION_TEMPLATE.format(
                instruction=instruction, input=input_text, output=output
            )
        else:
            text = INSTRUCTION_NO_INPUT_TEMPLATE.format(
                instruction=instruction, output=output
            )
        formatted.append({"text": text})
    return formatted


def _format_conversational(data: list[dict]) -> list[dict]:
    """Format conversational (messages) data."""
    formatted = []
    for row in data:
        messages = row.get("messages", [])
        parts = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "system":
                parts.append(f"### System:\n{content}")
            elif role == "user":
                parts.append(f"### User:\n{content}")
            elif role == "assistant":
                parts.append(f"### Assistant:\n{content}")
        text = "\n\n".join(parts)
        formatted.append({"text": text})
    return formatted


def _format_generic(data: list[dict]) -> list[dict]:
    """Format generic key-value data by concatenating all string fields."""
    formatted = []
    for row in data:
        parts = []
        for key, value in row.items():
            if isinstance(value, str) and value.strip():
                parts.append(f"{key}: {value}")
        text = "\n".join(parts)
        if text.strip():
            formatted.append({"text": text})
    return formatted


def split_dataset(
    data: list[dict],
    val_ratio: float = 0.1,
    seed: int = 42,
) -> tuple[list[dict], list[dict]]:
    """Split dataset into training and validation sets.

    Args:
        data: Full dataset.
        val_ratio: Fraction of data for validation (0.0 to 0.5).
        seed: Random seed for reproducibility.

    Returns:
        Tuple of (train_data, val_data).
    """
    import random

    if val_ratio <= 0:
        return data, []
    if val_ratio >= 0.5:
        val_ratio = 0.5

    rng = random.Random(seed)
    indices = list(range(len(data)))
    rng.shuffle(indices)

    split_idx = max(1, int(len(data) * (1 - val_ratio)))
    train_indices = indices[:split_idx]
    val_indices = indices[split_idx:]

    train_data = [data[i] for i in train_indices]
    val_data = [data[i] for i in val_indices]

    logger.info(f"Split: {len(train_data)} train / {len(val_data)} val")
    return train_data, val_data
