"""Dataset validation and quality analysis."""

from __future__ import annotations
from collections import Counter
from typing import Optional
from auto_lora.core.config import DatasetFormat, DatasetReport
from auto_lora.dataset.loader import get_dataset_columns
from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


def validate_dataset(data: list[dict], format: Optional[DatasetFormat] = None) -> DatasetReport:
    """Validate a dataset and produce a quality report."""
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
    
    report = DatasetReport()
    if not data:
        report.warnings.append("Dataset is empty")
        report.quality_score = 0.0
        return report

    report.total_rows = len(data)
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]{task.description}"),
        BarColumn(bar_width=40),
        TaskProgressColumn(),
        transient=True,
    ) as progress:
        
        # We define 5 major checks for analysis
        task = progress.add_task("Analyzing dataset quality...", total=5)
        
        # 1. Structure Check
        report.columns = get_dataset_columns(data)
        report.format_detected = format or _infer_format(data)
        progress.update(task, advance=1, description="[blue]Checking structure...")
        
        # 2. Text field identification
        text_field = _get_text_field(data, report.format_detected)
        progress.update(task, advance=1, description="[blue]Identifying text fields...")
        
        # 3. Duplicate analysis
        report.duplicate_count = _count_duplicates(data, text_field)
        progress.update(task, advance=1, description="[blue]Searching for duplicates...")
        
        # 4. Content analysis (nulls & malformed)
        report.null_count = _count_nulls(data, text_field)
        report.malformed_count = _count_malformed(data, report.format_detected)
        progress.update(task, advance=1, description="[blue]Checking for null/malformed rows...")
        
        # 5. Token Statistics
        lengths = _text_lengths(data, text_field)
        if lengths:
            tokens = [l // 4 for l in lengths]
            report.avg_token_length = sum(tokens) / len(tokens)
            report.min_token_length = min(tokens)
            report.max_token_length = max(tokens)
            report.median_token_length = float(sorted(tokens)[len(tokens) // 2])
            mean = report.avg_token_length
            report.token_length_std = (sum((t - mean) ** 2 for t in tokens) / len(tokens)) ** 0.5
        progress.update(task, advance=1, description="[bold green]✓ Analysis complete")

    _generate_warnings(report)
    report.quality_score = _quality_score(report)
    logger.info(f"Validation: {report.total_rows} rows | quality={report.quality_score:.2f}")
    return report


def _infer_format(data: list[dict]) -> DatasetFormat:
    if not data:
        return DatasetFormat.JSON
    keys = set(data[0].keys())
    if "messages" in keys:
        return DatasetFormat.CONVERSATIONAL
    if "instruction" in keys and ("output" in keys or "response" in keys):
        return DatasetFormat.ALPACA
    if keys == {"text"}:
        return DatasetFormat.TXT
    return DatasetFormat.JSON


def _get_text_field(data: list[dict], fmt: Optional[DatasetFormat]) -> str:
    if not data:
        return "text"
    if fmt == DatasetFormat.ALPACA:
        return "instruction"
    if fmt == DatasetFormat.CONVERSATIONAL:
        return "messages"
    for f in ("text", "instruction", "input", "content", "question", "prompt"):
        if f in data[0]:
            return f
    for k, v in data[0].items():
        if isinstance(v, str):
            return k
    return list(data[0].keys())[0]


def _count_duplicates(data: list[dict], field: str) -> int:
    texts = [str(row.get(field, "")) for row in data]
    return sum(c - 1 for c in Counter(texts).values() if c > 1)


def _count_nulls(data: list[dict], field: str) -> int:
    count = 0
    for row in data:
        v = row.get(field)
        if v is None or (isinstance(v, str) and not v.strip()):
            count += 1
    return count


def _count_malformed(data: list[dict], fmt: Optional[DatasetFormat]) -> int:
    if fmt == DatasetFormat.ALPACA:
        req = {"instruction", "output"}
        return sum(1 for r in data if not req.issubset(r.keys()))
    if fmt == DatasetFormat.CONVERSATIONAL:
        return sum(1 for r in data if not isinstance(r.get("messages"), list) or len(r.get("messages", [])) < 2)
    return 0


def _text_lengths(data: list[dict], field: str) -> list[int]:
    lengths = []
    for row in data:
        v = row.get(field)
        if v is None:
            lengths.append(0)
        elif isinstance(v, str):
            lengths.append(len(v))
        elif isinstance(v, list):
            lengths.append(sum(len(m.get("content", "")) for m in v if isinstance(m, dict)))
        else:
            lengths.append(len(str(v)))
    return lengths


def _generate_warnings(report: DatasetReport) -> None:
    if report.total_rows < 10:
        report.warnings.append("Very small dataset (< 10 rows)")
    elif report.total_rows < 100:
        report.warnings.append("Small dataset — consider adding more data")
    if report.duplicate_count > 0:
        pct = (report.duplicate_count / report.total_rows) * 100
        report.warnings.append(f"{report.duplicate_count} duplicate(s) ({pct:.1f}%)")
    if report.null_count > 0:
        report.warnings.append(f"{report.null_count} null/empty value(s)")
    if report.malformed_count > 0:
        report.warnings.append(f"{report.malformed_count} malformed row(s)")
    if report.max_token_length > 4096:
        report.warnings.append(f"Some samples exceed 4096 tokens (max: {report.max_token_length})")
    if report.avg_token_length > 0 and report.token_length_std > report.avg_token_length:
        report.warnings.append("High variance in token lengths")


def _quality_score(report: DatasetReport) -> float:
    score = 1.0
    if report.total_rows == 0:
        return 0.0
    score -= min((report.duplicate_count / report.total_rows) * 2, 0.2)
    score -= min((report.null_count / report.total_rows) * 2, 0.2)
    if report.malformed_count > 0:
        score -= min((report.malformed_count / report.total_rows) * 3, 0.3)
    if report.total_rows < 10:
        score -= 0.15
    elif report.total_rows < 50:
        score -= 0.10
    elif report.total_rows < 100:
        score -= 0.05
    if report.avg_token_length > 0 and report.token_length_std > report.avg_token_length * 1.5:
        score -= 0.1
    return max(0.0, min(1.0, round(score, 2)))
