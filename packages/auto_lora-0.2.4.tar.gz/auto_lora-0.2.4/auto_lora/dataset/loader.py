"""Dataset loading module.

Supports loading datasets from various file formats:
- JSON (list of objects)
- JSONL (one JSON object per line)
- CSV (with header row)
- TXT (one sample per line)
- Alpaca format (instruction/input/output)
- Conversational format (messages array)

Auto-detects format when not specified.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Optional

from auto_lora.core.config import DatasetFormat
from auto_lora.core.constants import (
    ALPACA_REQUIRED_KEYS,
    CONVERSATIONAL_REQUIRED_KEYS,
    SUPPORTED_DATASET_EXTENSIONS,
)
from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


def detect_format(file_path: Path) -> DatasetFormat:
    """Auto-detect dataset format from file content.

    Args:
        file_path: Path to the dataset file.

    Returns:
        Detected DatasetFormat.

    Raises:
        ValueError: If format cannot be determined.
    """
    path = Path(file_path)
    ext = path.suffix.lower()

    if ext == ".csv":
        return DatasetFormat.CSV
    elif ext == ".txt":
        return DatasetFormat.TXT
    elif ext in (".json", ".jsonl"):
        # Read first few lines to detect sub-format
        with open(path, "r", encoding="utf-8") as f:
            first_line = f.readline().strip()

        # Try JSONL (one object per line)
        try:
            first_obj = json.loads(first_line)
            if isinstance(first_obj, dict):
                # Check if it's Alpaca format
                if ALPACA_REQUIRED_KEYS.issubset(first_obj.keys()):
                    return DatasetFormat.ALPACA
                # Check if it's conversational
                if CONVERSATIONAL_REQUIRED_KEYS.issubset(first_obj.keys()):
                    return DatasetFormat.CONVERSATIONAL
                # Check if first line is a standalone JSON object (JSONL)
                # Peek at second line to confirm
                with open(path, "r", encoding="utf-8") as f:
                    f.readline()
                    second_line = f.readline().strip()
                    if second_line:
                        try:
                            json.loads(second_line)
                            return DatasetFormat.JSONL
                        except json.JSONDecodeError:
                            pass
        except json.JSONDecodeError:
            pass

        # Try full JSON array
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict):
                if ALPACA_REQUIRED_KEYS.issubset(data[0].keys()):
                    return DatasetFormat.ALPACA
                if CONVERSATIONAL_REQUIRED_KEYS.issubset(data[0].keys()):
                    return DatasetFormat.CONVERSATIONAL
                return DatasetFormat.JSON
        except (json.JSONDecodeError, UnicodeDecodeError):
            pass

    raise ValueError(
        f"Cannot detect format for '{path.name}'. "
        f"Supported extensions: {SUPPORTED_DATASET_EXTENSIONS}"
    )


def load_dataset(
    file_path: str | Path,
    format: Optional[DatasetFormat] = None,
    max_samples: Optional[int] = None,
) -> list[dict]:
    """Load a dataset from a file.

    Args:
        file_path: Path to the dataset file.
        format: Dataset format. If None, auto-detected.

    Returns:
        List of dictionaries, one per data sample.

    Raises:
        FileNotFoundError: If the local file doesn't exist.
        ValueError: If the format is unsupported or file is malformed.
    """
    # 1. Try loading from HuggingFace Hub first if it's a string and doesn't look like a path
    dataset_name = str(file_path)
    if not Path(dataset_name).exists() and "/" in dataset_name and not dataset_name.endswith(tuple(SUPPORTED_DATASET_EXTENSIONS)):
        try:
            from datasets import load_dataset as hf_load_dataset
            from datasets.utils.logging import disable_progress_bar
            from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
            
            # Silence internal tqdm
            disable_progress_bar()
            
            hf_ds = hf_load_dataset(dataset_name, streaming=(max_samples is not None))
            split = "train" if "train" in hf_ds else list(hf_ds.keys())[0]

            if max_samples is None:
                # No user cap requested -> load full split with live progress.
                logger.info(f"Loading full HuggingFace split '{split}' from {dataset_name}")
                split_ds = hf_ds[split]
                total_rows = getattr(split_ds, "num_rows", None)

                with Progress(
                    SpinnerColumn(),
                    TextColumn("[bold blue]{task.description}"),
                    BarColumn(bar_width=40),
                    TaskProgressColumn(),
                    transient=False,
                ) as progress:
                    task = progress.add_task(
                        f"Loading full split '{split}'...",
                        total=total_rows,
                    )
                    data = []
                    for idx, item in enumerate(split_ds, 1):
                        data.append(item)
                        progress.update(task, completed=idx)
            else:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[bold blue]{task.description}"),
                    BarColumn(bar_width=40),
                    TaskProgressColumn(),
                    transient=False, # Keep it visible
                ) as progress:
                    # Step 1: Connect to Stream
                    load_task = progress.add_task(
                        f"Fetching {max_samples} samples from '{split}'...",
                        total=max_samples,
                    )
                    data = []
                    for i, item in enumerate(hf_ds[split].take(max_samples)):
                        data.append(item)
                        progress.update(load_task, completed=i + 1)
            
            logger.info(f"Successfully loaded {len(data)} samples dynamically.")
            return data
        except Exception as e:
            logger.warning(f"Could not load from Hub: {e}. Falling back to local file check.")

    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"Dataset file not found: {path}")

    if path.suffix.lower() not in SUPPORTED_DATASET_EXTENSIONS:
        raise ValueError(
            f"Unsupported file extension: {path.suffix}. "
            f"Supported: {SUPPORTED_DATASET_EXTENSIONS}"
        )

    # Auto-detect format if not specified
    if format is None:
        format = detect_format(path)
        logger.info(f"Auto-detected dataset format: {format.value}")

    # Load based on format
    if format == DatasetFormat.JSON:
        data = _load_json(path)
    elif format == DatasetFormat.JSONL:
        data = _load_jsonl(path)
    elif format == DatasetFormat.CSV:
        data = _load_csv(path)
    elif format == DatasetFormat.TXT:
        data = _load_txt(path)
    elif format in (DatasetFormat.ALPACA, DatasetFormat.CONVERSATIONAL):
        # These are JSON-based, try JSON array first, then JSONL
        try:
            data = _load_json(path)
        except (json.JSONDecodeError, ValueError):
            data = _load_jsonl(path)
    else:
        raise ValueError(f"Unsupported format: {format}")

    if max_samples and len(data) > max_samples:
        data = data[:max_samples]

    logger.info(f"Loaded {len(data)} samples from {path.name}")
    return data


def _load_json(path: Path) -> list[dict]:
    """Load a JSON array of objects."""
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    if isinstance(data, dict):
        # Some datasets wrap the array in a key like "data" or "examples"
        for key in ("data", "examples", "train", "samples", "rows"):
            if key in data and isinstance(data[key], list):
                return data[key]
        raise ValueError("JSON file is a dict but doesn't contain a recognized data key")

    if not isinstance(data, list):
        raise ValueError("JSON file must contain a list of objects")

    return data


def _load_jsonl(path: Path) -> list[dict]:
    """Load a JSONL file (one JSON object per line)."""
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    data.append(obj)
                else:
                    logger.warning(f"Line {line_num}: Expected dict, got {type(obj).__name__}")
            except json.JSONDecodeError as e:
                logger.warning(f"Line {line_num}: JSON parse error — {e}")
    return data


def _load_csv(path: Path) -> list[dict]:
    """Load a CSV file with header row."""
    data = []
    with open(path, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append(dict(row))
    return data


def _load_txt(path: Path) -> list[dict]:
    """Load a text file (one sample per line).

    Each line becomes an entry with a 'text' key.
    """
    data = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                data.append({"text": line})
    return data


def get_dataset_columns(data: list[dict]) -> list[str]:
    """Get the column names from the dataset.

    Args:
        data: Loaded dataset.

    Returns:
        Sorted list of unique column names.
    """
    if not data:
        return []
    # Collect all keys from all rows (some rows might have different keys)
    all_keys: set[str] = set()
    for row in data:
        all_keys.update(row.keys())
    return sorted(all_keys)
