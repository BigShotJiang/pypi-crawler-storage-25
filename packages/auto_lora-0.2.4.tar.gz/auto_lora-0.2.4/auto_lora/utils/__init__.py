"""Shared utilities: logging, display, filesystem."""
