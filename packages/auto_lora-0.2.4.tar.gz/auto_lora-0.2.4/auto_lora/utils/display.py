"""Rich console display helpers for terminal UI.

Provides convenient functions for displaying formatted output:
- Status panels and headers
- Data tables
- Progress bars
- Success/error/warning messages
- Hardware and dataset reports
"""

from __future__ import annotations

from typing import Any, Optional

from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)
from rich.table import Table
from rich.text import Text

# Global console instance
console = Console()


def print_header(title: str, subtitle: str = "") -> None:
    """Print a styled application header.

    Args:
        title: Main title text.
        subtitle: Optional subtitle text.
    """
    header_text = Text(title, style="bold cyan")
    if subtitle:
        header_text.append(f"\n{subtitle}", style="dim")
    console.print(
        Panel(
            header_text,
            border_style="bright_blue",
            padding=(1, 2),
        )
    )


def print_success(message: str) -> None:
    """Print a success message with green checkmark."""
    console.print(f"  [bold green]✓[/bold green] {message}")


def print_error(message: str) -> None:
    """Print an error message with red cross."""
    console.print(f"  [bold red]✗[/bold red] {message}")


def print_warning(message: str) -> None:
    """Print a warning message with yellow exclamation."""
    console.print(f"  [bold yellow]⚠[/bold yellow] {message}")


def print_info(message: str) -> None:
    """Print an info message with blue arrow."""
    console.print(f"  [bold blue]→[/bold blue] {message}")


def print_step(step: int, total: int, message: str) -> None:
    """Print a numbered step in a process.

    Args:
        step: Current step number.
        total: Total number of steps.
        message: Step description.
    """
    console.print(f"  [bold cyan][{step}/{total}][/bold cyan] {message}")


def print_key_value(key: str, value: Any, key_width: int = 20) -> None:
    """Print a key-value pair with aligned formatting.

    Args:
        key: The label.
        value: The value to display.
        key_width: Width for key column alignment.
    """
    console.print(f"  [dim]{key:<{key_width}}[/dim] {value}")


def create_table(
    title: str,
    columns: list[dict[str, Any]],
    rows: list[list[Any]],
    show_lines: bool = False,
) -> Table:
    """Create a Rich table with consistent styling.

    Args:
        title: Table title.
        columns: List of column definitions, each with 'name' and optional
                 'style', 'justify', 'width' keys.
        rows: List of row data (each row is a list of values).
        show_lines: Whether to show horizontal lines between rows.

    Returns:
        Configured Rich Table.
    """
    table = Table(
        title=title,
        title_style="bold",
        border_style="bright_blue",
        show_lines=show_lines,
        padding=(0, 1),
    )

    for col in columns:
        table.add_column(
            col["name"],
            style=col.get("style", ""),
            justify=col.get("justify", "left"),
            min_width=col.get("width", None),
        )

    for row in rows:
        table.add_row(*[str(v) for v in row])

    return table


def print_table(
    title: str,
    columns: list[dict[str, Any]],
    rows: list[list[Any]],
    show_lines: bool = False,
) -> None:
    """Create and print a Rich table.

    Args:
        title: Table title.
        columns: Column definitions.
        rows: Row data.
        show_lines: Show horizontal lines between rows.
    """
    table = create_table(title, columns, rows, show_lines)
    console.print(table)


def create_progress(description: str = "Training") -> Progress:
    """Create a Rich progress bar with consistent styling.

    Args:
        description: Progress bar description.

    Returns:
        Configured Rich Progress instance.
    """
    return Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]{task.description}"),
        BarColumn(bar_width=40),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        TimeRemainingColumn(),
        console=console,
    )


def print_hardware_report(profile: Any) -> None:
    """Print a formatted hardware profile report.

    Args:
        profile: HardwareProfile instance.
    """
    console.print()
    console.print(Panel("[bold]Hardware Profile[/bold]", border_style="cyan"))

    if profile.has_gpu:
        print_success(f"GPU: {profile.gpu_name} ({profile.gpu_count}x)")
        print_success(f"VRAM: {profile.vram_gb:.1f} GB")
        print_success(f"CUDA: {profile.cuda_version}")
    else:
        print_warning("No GPU detected — CPU-only mode")

    print_info(f"CPU Cores: {profile.cpu_cores}")
    print_info(f"RAM: {profile.ram_gb:.1f} GB")
    print_info(f"Free Disk: {profile.storage_free_gb:.1f} GB")
    print_info(f"PyTorch: {profile.torch_version}")
    print_info(f"Strategy: {profile.recommended_strategy().value.upper()}")
    console.print()


def print_dataset_report(report: Any) -> None:
    """Print a formatted dataset quality report.

    Args:
        report: DatasetReport instance.
    """
    console.print()
    console.print(Panel("[bold]Dataset Analysis[/bold]", border_style="cyan"))

    print_info(f"Total rows: {report.total_rows}")
    print_info(f"Format: {report.format_detected.value if report.format_detected else 'unknown'}")
    print_info(f"Columns: {', '.join(report.columns)}")
    print_info(f"Avg token length: {report.avg_token_length:.0f}")
    print_info(f"Token range: {report.min_token_length} - {report.max_token_length}")

    quality_color = "green" if report.quality_score >= 0.7 else "yellow" if report.quality_score >= 0.5 else "red"
    console.print(f"  [bold {quality_color}]Quality Score: {report.quality_score:.2f}[/bold {quality_color}]")

    if report.duplicate_count > 0:
        print_warning(f"Duplicates found: {report.duplicate_count}")
    if report.null_count > 0:
        print_warning(f"Null values found: {report.null_count}")
    if report.malformed_count > 0:
        print_error(f"Malformed rows: {report.malformed_count}")

    for warning in report.warnings:
        print_warning(warning)

    console.print()


def print_trial_summary(trial: Any) -> None:
    """Print a summary of a completed trial.

    Args:
        trial: TrialResult instance.
    """
    status_icon = "✓" if trial.status == "completed" else "✗" if trial.status == "failed" else "⏸"
    status_color = "green" if trial.status == "completed" else "red" if trial.status == "failed" else "yellow"

    console.print(
        f"  [{status_color}]{status_icon}[/{status_color}] "
        f"Trial {trial.trial_number:>3d} | "
        f"val_loss: {trial.val_loss:.4f} | "
        f"score: {trial.score:.4f} | "
        f"time: {trial.runtime_seconds:.0f}s | "
        f"mem: {trial.peak_memory_gb:.1f}GB"
    )


def print_final_summary(result: Any) -> None:
    """Print the final tuning result summary.

    Args:
        result: TuningResult instance.
    """
    console.print()
    console.print(
        Panel(
            "[bold green]✓ Tuning Complete[/bold green]",
            border_style="green",
        )
    )

    if result.best_trial:
        best = result.best_trial
        print_success(f"Best Trial: #{best.trial_number}")
        print_info(f"Validation Loss: {best.val_loss:.4f}")
        print_info(f"Perplexity: {best.perplexity:.2f}")
        print_info(f"Score: {best.score:.4f}")
        print_info(f"Runtime: {best.runtime_seconds:.0f}s")
        print_info(f"Peak Memory: {best.peak_memory_gb:.1f} GB")
        print_info(f"Adapter: {best.adapter_path}")

        # Print LoRA config
        console.print()
        console.print("  [bold]Best LoRA Configuration:[/bold]")
        for k, v in best.lora_config.items():
            print_key_value(f"  {k}", v)

    console.print()
    print_info(f"Completed: {len(result.completed_trials)}/{len(result.all_trials)} trials")
    print_info(f"Total time: {result.total_runtime_seconds:.0f}s")
    print_info(f"Run ID: {result.run_id}")
    console.print()
