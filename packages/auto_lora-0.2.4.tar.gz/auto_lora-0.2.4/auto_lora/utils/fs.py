"""Filesystem utilities for Auto-LoRA.

Provides helpers for:
- Creating output directory structures
- Safe file path generation
- Run ID generation
- Cleanup operations
"""

from __future__ import annotations

import shutil
import uuid
from datetime import datetime
from pathlib import Path

from auto_lora.core.constants import (
    DEFAULT_CONFIG_DIR,
    DEFAULT_DATASET_DIR,
    DEFAULT_LOG_DIR,
    DEFAULT_OUTPUT_DIR,
)


def generate_run_id() -> str:
    """Generate a unique run identifier.

    Format: run_YYYYMMDD_HHMMSS_XXXX where XXXX is a short UUID suffix.

    Returns:
        Unique run ID string.
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    short_uuid = uuid.uuid4().hex[:6]
    return f"run_{timestamp}_{short_uuid}"


def create_project_structure(root: Path) -> dict[str, Path]:
    """Create the standard project directory structure.

    Args:
        root: Project root directory.

    Returns:
        Dictionary mapping directory names to their paths.
    """
    dirs = {
        "outputs": root / DEFAULT_OUTPUT_DIR,
        "logs": root / DEFAULT_LOG_DIR,
        "datasets": root / DEFAULT_DATASET_DIR,
        "configs": root / DEFAULT_CONFIG_DIR,
    }

    for dir_path in dirs.values():
        dir_path.mkdir(parents=True, exist_ok=True)

    return dirs


def create_run_directory(output_dir: Path, run_id: str) -> dict[str, Path]:
    """Create the directory structure for a training run.

    Creates:
        outputs/<run_id>/
        ├── adapter/
        ├── checkpoints/
        ├── charts/
        ├── logs/
        └── (summary.json, metrics.html created later)

    Args:
        output_dir: Base output directory.
        run_id: Unique run identifier.

    Returns:
        Dictionary mapping subdirectory names to their paths.
    """
    run_dir = Path(output_dir) / run_id
    subdirs = {
        "root": run_dir,
        "adapter": run_dir / "adapter",
        "checkpoints": run_dir / "checkpoints",
        "charts": run_dir / "charts",
        "logs": run_dir / "logs",
    }

    for dir_path in subdirs.values():
        dir_path.mkdir(parents=True, exist_ok=True)

    return subdirs


def get_run_dir(output_dir: Path, run_id: str) -> Path:
    """Get the directory path for a specific run.

    Args:
        output_dir: Base output directory.
        run_id: Run identifier.

    Returns:
        Path to the run directory.

    Raises:
        FileNotFoundError: If the run directory doesn't exist.
    """
    run_dir = Path(output_dir) / run_id
    if not run_dir.exists():
        raise FileNotFoundError(f"Run directory not found: {run_dir}")
    return run_dir


def list_run_dirs(output_dir: Path) -> list[Path]:
    """List all run directories in the output directory.

    Args:
        output_dir: Base output directory.

    Returns:
        Sorted list of run directory paths (newest first).
    """
    output_path = Path(output_dir)
    if not output_path.exists():
        return []

    runs = [
        d for d in output_path.iterdir()
        if d.is_dir() and d.name.startswith("run_")
    ]
    return sorted(runs, key=lambda p: p.name, reverse=True)


def safe_filename(name: str) -> str:
    """Convert a string to a safe filename.

    Args:
        name: Original string.

    Returns:
        Sanitized filename string.
    """
    # Replace common problematic characters
    safe = name.replace("/", "_").replace("\\", "_").replace(" ", "_")
    safe = safe.replace(":", "_").replace(".", "_")
    # Remove any remaining non-alphanumeric characters except underscore and hyphen
    safe = "".join(c for c in safe if c.isalnum() or c in ("_", "-"))
    return safe.lower()


def cleanup_run(output_dir: Path, run_id: str) -> bool:
    """Delete all files for a specific run.

    Args:
        output_dir: Base output directory.
        run_id: Run identifier.

    Returns:
        True if cleanup was successful.
    """
    run_dir = Path(output_dir) / run_id
    if run_dir.exists():
        shutil.rmtree(run_dir)
        return True
    return False


def get_free_disk_space(path: Path) -> float:
    """Get free disk space in GB for the given path.

    Args:
        path: Path to check.

    Returns:
        Free disk space in GB.
    """
    usage = shutil.disk_usage(path)
    return usage.free / (1024**3)


def ensure_dir(path: Path) -> Path:
    """Ensure a directory exists, creating it if necessary.

    Args:
        path: Directory path to ensure.

    Returns:
        The path (for chaining).
    """
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path
