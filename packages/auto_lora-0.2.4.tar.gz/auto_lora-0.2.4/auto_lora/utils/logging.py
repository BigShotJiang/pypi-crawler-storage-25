"""Structured logging with file rotation and rich console output.

Provides a configured logger for each module with:
- Rich console handler for colorful terminal output
- Rotating file handler for persistent logs per run
- Structured log format with timestamps
"""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional

from rich.logging import RichHandler

from auto_lora.core.constants import (
    LOG_BACKUP_COUNT,
    LOG_DATE_FORMAT,
    LOG_FORMAT,
    MAX_LOG_FILE_SIZE,
)


_loggers: dict[str, logging.Logger] = {}


def get_logger(
    name: str,
    log_dir: Optional[Path] = None,
    level: int = logging.INFO,
    verbose: bool = False,
) -> logging.Logger:
    """Get or create a configured logger.

    Args:
        name: Logger name (typically module name).
        log_dir: Directory for log files. If None, only console output.
        level: Logging level.
        verbose: If True, set level to DEBUG.

    Returns:
        Configured logger instance.
    """
    if name in _loggers:
        return _loggers[name]

    logger = logging.getLogger(name)
    effective_level = logging.DEBUG if verbose else level
    logger.setLevel(effective_level)
    logger.propagate = False

    # Rich console handler — beautiful terminal output
    if not any(isinstance(h, RichHandler) for h in logger.handlers):
        console_handler = RichHandler(
            level=effective_level,
            show_time=True,
            show_path=False,
            markup=True,
            rich_tracebacks=True,
        )
        console_handler.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(console_handler)

    # Rotating file handler — persistent logs
    if log_dir is not None:
        log_dir = Path(log_dir)
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / f"{name.replace('.', '_')}.log"

        if not any(isinstance(h, RotatingFileHandler) for h in logger.handlers):
            file_handler = RotatingFileHandler(
                log_file,
                maxBytes=MAX_LOG_FILE_SIZE,
                backupCount=LOG_BACKUP_COUNT,
                encoding="utf-8",
            )
            file_handler.setLevel(logging.DEBUG)  # Always log everything to file
            file_handler.setFormatter(
                logging.Formatter(LOG_FORMAT, datefmt=LOG_DATE_FORMAT)
            )
            logger.addHandler(file_handler)

    _loggers[name] = logger
    return logger


def setup_run_logging(run_id: str, log_dir: Path, verbose: bool = False) -> logging.Logger:
    """Set up logging for a specific training run.

    Creates a run-specific log directory and returns a logger configured
    to write to both console and a run-specific log file.

    Args:
        run_id: Unique run identifier.
        log_dir: Base log directory.
        verbose: Enable debug-level logging.

    Returns:
        Logger configured for the run.
    """
    run_log_dir = Path(log_dir) / run_id
    run_log_dir.mkdir(parents=True, exist_ok=True)
    return get_logger(
        f"auto_lora.run.{run_id}",
        log_dir=run_log_dir,
        verbose=verbose,
    )
