"""Tuning engine orchestrator.

Creates and manages an Optuna study to find optimal hyperparameters.
Coordinates the entire tuning lifecycle:
1. Create study with pruner
2. Run optimization trials
3. Collect results
4. Return best configuration
"""

from __future__ import annotations

import time
from typing import Optional

import optuna

from auto_lora.core.config import (
    HardwareProfile,
    SearchSpaceConfig,
    TrainingStrategy,
    TrialResult,
    TuningResult,
)
from auto_lora.tuner.objective import create_objective
from auto_lora.tuner.search_space import build_search_space
from auto_lora.utils.display import print_trial_summary
from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


def run_tuning(
    model_name: str,
    train_data: list[dict],
    val_data: list[dict],
    run_id: str,
    output_dir: str,
    hardware: Optional[HardwareProfile] = None,
    strategy: TrainingStrategy = TrainingStrategy.LORA,
    preset_space: Optional[SearchSpaceConfig] = None,
    max_trials: int = 10,
    max_hours: float = 4.0,
    max_seq_length: int = 512,
    seed: int = 42,
    report_to: str = "none",
    use_unsloth: bool = True,
) -> TuningResult:
    """Run the complete hyperparameter tuning process.

    Args:
        model_name: Base model name.
        train_data: Training data.
        val_data: Validation data.
        run_id: Unique run identifier.
        output_dir: Output directory for this run.
        hardware: Hardware profile for search space constraints.
        strategy: Training strategy.
        preset_space: Optional preset search space.
        max_trials: Maximum number of trials.
        max_hours: Maximum runtime in hours.
        max_seq_length: Maximum sequence length.
        seed: Random seed.
        report_to: Reporting backend.

    Returns:
        TuningResult with best trial and all results.
    """
    start_time = time.time()
    all_trial_results: list[TrialResult] = []

    # 1. Build search space
    search_space = build_search_space(
        hardware=hardware,
        dataset_rows=len(train_data),
        model_name=model_name,
        preset_space=preset_space,
    )

    # 2. Callback for collecting results
    def on_trial_complete(trial_result: TrialResult) -> None:
        all_trial_results.append(trial_result)
        print_trial_summary(trial_result)

    # 3. Create objective
    objective = create_objective(
        model_name=model_name,
        train_data=train_data,
        val_data=val_data,
        search_space=search_space,
        strategy=strategy,
        output_base_dir=output_dir,
        run_id=run_id,
        max_seq_length=max_seq_length,
        seed=seed,
        report_to=report_to,
        on_trial_complete=on_trial_complete,
        use_unsloth=use_unsloth,
    )

    # 4. Create Optuna study
    # Suppress Optuna's verbose output
    optuna.logging.set_verbosity(optuna.logging.WARNING)

    study = optuna.create_study(
        study_name=run_id,
        direction="minimize",  # Minimize val_loss
        pruner=optuna.pruners.MedianPruner(
            n_startup_trials=2,
            n_warmup_steps=10,
        ),
        sampler=optuna.samplers.TPESampler(seed=seed),
    )

    # 5. Run optimization
    timeout_seconds = max_hours * 3600

    logger.info(
        f"Starting tuning: max_trials={max_trials}, "
        f"max_hours={max_hours}, strategy={strategy.value}"
    )

    try:
        study.optimize(
            objective,
            n_trials=max_trials,
            timeout=timeout_seconds,
            show_progress_bar=False,
            catch=(Exception,),  # Don't let single trial crash entire study
        )
    except KeyboardInterrupt:
        logger.warning("Tuning interrupted by user")

    # 6. Build result
    total_runtime = time.time() - start_time

    # Find best trial from our collected results
    completed = [t for t in all_trial_results if t.status == "completed"]
    best_trial = None
    if completed:
        best_trial = max(completed, key=lambda t: t.score)

    result = TuningResult(
        best_trial=best_trial,
        all_trials=all_trial_results,
        total_runtime_seconds=total_runtime,
        run_id=run_id,
    )

    logger.info(
        f"Tuning complete: {len(completed)}/{len(all_trial_results)} trials succeeded, "
        f"total time: {total_runtime:.0f}s"
    )

    if best_trial:
        logger.info(
            f"Best trial #{best_trial.trial_number}: "
            f"val_loss={best_trial.val_loss:.4f}, score={best_trial.score:.4f}"
        )

    return result
