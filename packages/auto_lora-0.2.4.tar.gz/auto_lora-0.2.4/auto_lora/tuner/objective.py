"""Optuna objective function for hyperparameter tuning.

Defines the objective that Optuna optimizes: for each trial, it suggests
hyperparameters, runs training, and returns a score for Optuna to minimize/maximize.
"""

from __future__ import annotations

from typing import Any, Callable

from auto_lora.core.config import (
    LoRAConfig,
    SearchSpaceConfig,
    TrainingStrategy,
    TrialResult,
)
from auto_lora.metrics.scorer import compute_score
from auto_lora.trainer.lora_trainer import train_lora
from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


def create_objective(
    model_name: str,
    train_data: list[dict],
    val_data: list[dict],
    search_space: SearchSpaceConfig,
    strategy: TrainingStrategy,
    output_base_dir: str,
    run_id: str,
    max_seq_length: int = 512,
    seed: int = 42,
    report_to: str = "none",
    on_trial_complete: Callable[[TrialResult], None] | None = None,
    use_unsloth: bool = True,
) -> Callable:
    """Create an Optuna objective function.

    Returns a callable that Optuna will call for each trial. The function:
    1. Samples hyperparameters from the search space
    2. Runs LoRA training with those params
    3. Returns the validation loss (for Optuna to minimize)

    Args:
        model_name: Base model name.
        train_data: Training data.
        val_data: Validation data.
        search_space: Hyperparameter search ranges.
        strategy: Training strategy (lora/qlora/cpu).
        output_base_dir: Base directory for trial outputs.
        run_id: Run identifier.
        max_seq_length: Max sequence length.
        seed: Random seed.
        report_to: Reporting backend.
        on_trial_complete: Callback when a trial finishes.

    Returns:
        Optuna objective callable.
    """

    def objective(trial: Any) -> float:
        """Optuna objective: suggest params → train → return val_loss."""
        trial_number = trial.number

        # 1. Suggest hyperparameters
        rank = trial.suggest_categorical("rank", search_space.rank_choices)
        alpha_mult = trial.suggest_categorical("alpha_multiplier", search_space.alpha_multipliers)
        alpha = rank * alpha_mult

        dropout = trial.suggest_float(
            "dropout",
            search_space.dropout_range[0],
            search_space.dropout_range[1],
        )

        learning_rate = trial.suggest_float(
            "learning_rate",
            search_space.learning_rate_range[0],
            search_space.learning_rate_range[1],
            log=True,
        )

        batch_size = trial.suggest_categorical("batch_size", search_space.batch_size_choices)

        epochs = trial.suggest_int(
            "epochs",
            search_space.epochs_range[0],
            search_space.epochs_range[1],
        )

        warmup_ratio = trial.suggest_float(
            "warmup_ratio",
            search_space.warmup_ratio_range[0],
            search_space.warmup_ratio_range[1],
        )

        # Target modules
        if len(search_space.target_module_options) > 1:
            module_idx = trial.suggest_int(
                "target_modules_idx", 0, len(search_space.target_module_options) - 1
            )
        else:
            module_idx = 0
        target_modules = search_space.target_module_options[module_idx]

        # 2. Build LoRA config
        lora_config = LoRAConfig(
            rank=rank,
            alpha=alpha,
            dropout=dropout,
            target_modules=target_modules,
        )

        # 3. Set up trial output directory
        trial_output_dir = f"{output_base_dir}/trial_{trial_number:03d}"

        logger.info(
            f"Trial {trial_number}: rank={rank}, alpha={alpha}, "
            f"lr={learning_rate:.2e}, bs={batch_size}, epochs={epochs}"
        )

        # 4. Train
        result = train_lora(
            model_name=model_name,
            train_data=train_data,
            val_data=val_data,
            lora_config=lora_config,
            output_dir=trial_output_dir,
            strategy=strategy,
            epochs=epochs,
            batch_size=batch_size,
            learning_rate=learning_rate,
            warmup_ratio=warmup_ratio,
            max_seq_length=max_seq_length,
            seed=seed,
            report_to=report_to,
            optuna_trial=trial,
            use_unsloth=use_unsloth,
        )

        # 5. Build trial result
        score = compute_score(
            val_loss=result.val_loss,
            runtime_seconds=result.runtime_seconds,
            peak_memory_gb=result.peak_memory_gb,
        )

        trial_result = TrialResult(
            trial_number=trial_number,
            lora_config={
                "rank": rank,
                "alpha": alpha,
                "dropout": dropout,
                "learning_rate": learning_rate,
                "batch_size": batch_size,
                "epochs": epochs,
                "warmup_ratio": warmup_ratio,
                "target_modules": target_modules,
            },
            training_args={},
            train_loss=result.train_loss,
            val_loss=result.val_loss,
            perplexity=result.perplexity,
            runtime_seconds=result.runtime_seconds,
            peak_memory_gb=result.peak_memory_gb,
            tokens_per_second=result.tokens_per_second,
            score=score,
            status="completed" if result.success else "failed",
            error_message=result.error,
            adapter_path=result.adapter_path,
        )

        # 6. Callback
        if on_trial_complete:
            on_trial_complete(trial_result)

        # If training failed, return a very high loss
        if not result.success:
            logger.warning(f"Trial {trial_number} failed: {result.error}")
            return float("inf")

        logger.info(
            f"Trial {trial_number} complete: "
            f"val_loss={result.val_loss:.4f}, score={score:.4f}"
        )

        # Return val_loss for Optuna to minimize
        return result.val_loss

    return objective
