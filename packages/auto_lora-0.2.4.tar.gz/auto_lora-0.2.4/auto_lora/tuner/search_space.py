"""Hyperparameter search space builder.

Generates Optuna-compatible parameter ranges based on:
- Hardware capabilities (VRAM constraints)
- Dataset characteristics
- Preset configurations
"""

from __future__ import annotations

from auto_lora.core.config import HardwareProfile, SearchSpaceConfig
from auto_lora.core.constants import MODEL_TARGET_MODULES
from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


def build_search_space(
    hardware: HardwareProfile | None = None,
    dataset_rows: int = 0,
    model_name: str = "",
    preset_space: SearchSpaceConfig | None = None,
) -> SearchSpaceConfig:
    """Build a hardware-aware hyperparameter search space.

    Adjusts parameter ranges based on available VRAM and dataset size
    to avoid OOM errors and wasted trials.

    Args:
        hardware: Detected hardware profile.
        dataset_rows: Number of dataset rows.
        model_name: Model name (for target module detection).
        preset_space: Optional preset search space to start from.

    Returns:
        Configured SearchSpaceConfig.
    """
    space = preset_space or SearchSpaceConfig()

    # Hardware-aware adjustments
    if hardware and hardware.has_gpu:
        vram = hardware.vram_gb

        if vram < 8:
            # Very limited VRAM
            space.rank_choices = [r for r in space.rank_choices if r <= 16]
            space.batch_size_choices = [1, 2]
            space.target_module_options = space.target_module_options[:2]
            logger.info(f"Constrained search space for {vram:.0f}GB VRAM")

        elif vram < 12:
            # Moderate VRAM
            space.rank_choices = [r for r in space.rank_choices if r <= 32]
            space.batch_size_choices = [b for b in space.batch_size_choices if b <= 4]
            space.target_module_options = space.target_module_options[:3]

        elif vram < 24:
            # Good VRAM
            space.rank_choices = [r for r in space.rank_choices if r <= 64]

        # else: keep all options for high VRAM

    elif hardware and not hardware.has_gpu:
        # CPU-only: heavily constrained
        space.rank_choices = [4, 8]
        space.batch_size_choices = [1, 2]
        space.epochs_range = (1, 2)
        space.target_module_options = [["q_proj", "v_proj"]]
        logger.warning("CPU-only: heavily constrained search space")

    # Dataset size adjustments
    if dataset_rows > 0:
        if dataset_rows < 100:
            # Small dataset: fewer epochs to avoid overfitting, lower LR
            space.epochs_range = (1, 3)
            lr_min, lr_max = space.learning_rate_range
            space.learning_rate_range = (lr_min, min(lr_max, 3e-4))
        elif dataset_rows > 10000:
            # Large dataset: can use larger batch sizes
            if 16 not in space.batch_size_choices:
                space.batch_size_choices.append(16)

    # Model-specific target modules
    if model_name:
        model_lower = model_name.lower()
        for arch, modules in MODEL_TARGET_MODULES.items():
            if arch in model_lower:
                # Offer both minimal and full module sets
                space.target_module_options = [
                    modules[:2],   # minimal (q, v)
                    modules[:4],   # attention only
                    modules,       # all modules
                ]
                break

    # Ensure rank choices are not empty
    if not space.rank_choices:
        space.rank_choices = [4, 8]

    if not space.batch_size_choices:
        space.batch_size_choices = [1, 2]

    logger.info(
        f"Search space: ranks={space.rank_choices}, "
        f"batch_sizes={space.batch_size_choices}, "
        f"lr={space.learning_rate_range}, "
        f"epochs={space.epochs_range}"
    )

    return space
