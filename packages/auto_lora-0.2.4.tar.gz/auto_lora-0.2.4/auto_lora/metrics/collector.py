"""Metrics collection for training runs.

Aggregates training metrics from multiple sources into a unified format
for scoring, reporting, and comparison.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class RunMetrics:
    """Aggregated metrics for a training run/trial."""

    train_loss: float = 0.0
    val_loss: float = 0.0
    perplexity: float = 0.0
    runtime_seconds: float = 0.0
    peak_memory_gb: float = 0.0
    tokens_per_second: float = 0.0
    total_steps: int = 0
    total_samples: int = 0
    loss_history: list[float] = field(default_factory=list)
    eval_loss_history: list[float] = field(default_factory=list)
    lr_history: list[float] = field(default_factory=list)
    step_history: list[int] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to serializable dictionary."""
        return {
            "train_loss": self.train_loss,
            "val_loss": self.val_loss,
            "perplexity": self.perplexity,
            "runtime_seconds": self.runtime_seconds,
            "peak_memory_gb": self.peak_memory_gb,
            "tokens_per_second": self.tokens_per_second,
            "total_steps": self.total_steps,
            "total_samples": self.total_samples,
        }


class MetricsCollector:
    """Collects and aggregates training metrics."""

    def __init__(self) -> None:
        self.metrics = RunMetrics()

    def update_from_training_result(self, result: Any) -> None:
        """Update metrics from a TrainingResult object.

        Args:
            result: TrainingResult from lora_trainer.
        """
        self.metrics.train_loss = result.train_loss
        self.metrics.val_loss = result.val_loss
        self.metrics.perplexity = result.perplexity
        self.metrics.runtime_seconds = result.runtime_seconds
        self.metrics.peak_memory_gb = result.peak_memory_gb
        self.metrics.tokens_per_second = result.tokens_per_second

        # Extract history from metrics_history list
        for entry in result.metrics_history:
            if "step" in entry:
                self.metrics.step_history.append(entry["step"])
            if "loss" in entry:
                self.metrics.loss_history.append(entry["loss"])
            if "eval_loss" in entry:
                self.metrics.eval_loss_history.append(entry["eval_loss"])
            if "learning_rate" in entry:
                self.metrics.lr_history.append(entry["learning_rate"])

    def update_from_dict(self, data: dict) -> None:
        """Update metrics from a dictionary."""
        for key, value in data.items():
            if hasattr(self.metrics, key):
                setattr(self.metrics, key, value)

    def get_metrics(self) -> RunMetrics:
        """Get the collected metrics."""
        return self.metrics

    def get_summary(self) -> dict[str, Any]:
        """Get a summary dictionary of key metrics."""
        return self.metrics.to_dict()
