"""Benchmark evaluation for trained adapters.

Runs a set of test prompts through the fine-tuned model and
evaluates response quality (basic heuristics for MVP).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from auto_lora.core.constants import DEFAULT_BENCHMARK_PROMPTS
from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


@dataclass
class BenchmarkResult:
    """Result of benchmark evaluation with scientific metrics."""

    prompts: list[str] = field(default_factory=list)
    responses: list[str] = field(default_factory=list)
    references: list[str] = field(default_factory=list)
    scores: list[float] = field(default_factory=list)
    
    # Scientific Aggregates
    avg_score: float = 0.0
    avg_rouge_l: float = 0.0
    avg_bleu: float = 0.0
    avg_semantic_sim: float = 0.0
    avg_tps: float = 0.0
    peak_vram_gb: float = 0.0
    avg_response_length: float = 0.0
    avg_generation_time: float = 0.0

    def to_dict(self) -> dict:
        return {
            "avg_score": self.avg_score,
            "avg_rouge_l": self.avg_rouge_l,
            "avg_bleu": self.avg_bleu,
            "avg_semantic_sim": self.avg_semantic_sim,
            "avg_tps": self.avg_tps,
            "peak_vram_gb": self.peak_vram_gb,
            "avg_response_length": self.avg_response_length,
            "avg_generation_time": self.avg_generation_time,
            "num_prompts": len(self.prompts),
            "details": [
                {
                    "prompt": p, 
                    "response": r, 
                    "score": s, 
                    "reference": ref, 
                    **m
                }
                for p, r, s, ref, m in zip(
                    self.prompts, 
                    self.responses, 
                    self.scores, 
                    self.references or [""] * len(self.prompts),
                    self.get_per_sample_metrics()
                )
            ],
        }

    def get_per_sample_metrics(self) -> list[dict]:
        """Calculate detailed metrics for the details list."""
        if not self.references or not self.responses:
            return [{"rouge_l": 0.0, "bleu": 0.0, "semantic_sim": 0.0}] * len(self.prompts)
            
        from auto_lora.metrics.scientific import calculate_rouge_l, calculate_bleu, calculate_semantic_similarity
        
        metrics = []
        for resp, ref in zip(self.responses, self.references):
            if not ref:
                metrics.append({"rouge_l": 0.0, "bleu": 0.0, "semantic_sim": 0.0})
                continue
            
            metrics.append({
                "rouge_l": calculate_rouge_l(resp, ref),
                "bleu": calculate_bleu(resp, ref),
                "semantic_sim": calculate_semantic_similarity(resp, ref)
            })
        return metrics


def run_benchmark(
    model: Any = None,
    tokenizer: Any = None,
    adapter_path: str = "",
    model_name: str = "",
    prompts: list[str] | None = None,
    references: list[str] | None = None,
    max_new_tokens: int = 256,
) -> BenchmarkResult:
    """Run benchmark prompts and evaluate responses.

    Can either use an already-loaded model or load from adapter_path.

    Args:
        model: Pre-loaded model (optional).
        tokenizer: Pre-loaded tokenizer (optional).
        adapter_path: Path to saved adapter (used if model not provided).
        model_name: Base model name (needed if loading from adapter).
        prompts: Test prompts. Defaults to built-in prompts.
        max_new_tokens: Max tokens to generate per prompt.

    Returns:
        BenchmarkResult with scores and responses.
    """
    import time
    from auto_lora.metrics.scientific import calculate_rouge_l, get_peak_vram
    import json
    from pathlib import Path

    result = BenchmarkResult()
    
    # DYNAMIC DISCOVERY: If no prompts provided, try to extract from dataset
    if not prompts and adapter_path:
        logger.info("No prompts provided. Attempting universal hold-out extraction...")
        prompts, references = _extract_holdout_samples(adapter_path, num_samples=10)
    
    # Fallback only if extraction failed completely
    prompts = prompts or DEFAULT_BENCHMARK_PROMPTS[:10]
    result.prompts = prompts
    result.references = references or []

    # Load model if not provided
    if model is None and adapter_path:
        try:
            model, tokenizer = _load_adapter(adapter_path, model_name)
        except Exception as e:
            logger.error(f"Failed to load adapter for benchmark: {e}")
            return result

    if model is None or tokenizer is None:
        logger.warning("No model available for benchmarking")
        return result

    model.eval()
    
    total_tokens = 0
    total_rouge = 0.0

    for i, prompt in enumerate(prompts):
        try:
            start = time.time()
            # Track token count for TPS
            response, tokens_generated = _generate_with_count(model, tokenizer, prompt, max_new_tokens)
            gen_time = time.time() - start

            score = _score_response(prompt, response)
            
            # Calculate scientific metrics if reference exists
            if references and i < len(references) and references[i]:
                from auto_lora.metrics.scientific import calculate_rouge_l, calculate_bleu, calculate_semantic_similarity
                # These are now handled via get_per_sample_metrics, 
                # but we'll calculate them here for immediate feedback if needed.
                # Actually, let's keep it clean and use the aggregate after the loop.
                pass

            result.responses.append(response)
            result.scores.append(score)
            result.avg_generation_time += gen_time
            total_tokens += tokens_generated

            logger.debug(f"Benchmark: Score={score:.2f}, TPS={tokens_generated/gen_time:.1f}")

        except Exception as e:
            logger.warning(f"Benchmark prompt failed: {e}")
            result.responses.append("")
            result.scores.append(0.0)

    # Final Aggregates
    if result.scores:
        num = len(result.scores)
        result.avg_score = sum(result.scores) / num
        result.avg_response_length = sum(len(r) for r in result.responses) / num
        result.avg_generation_time /= num
        
        if result.avg_generation_time > 0:
            result.avg_tps = total_tokens / (result.avg_generation_time * num)
        
        # Calculate all scientific metrics
        total_rouge = 0.0
        total_bleu = 0.0
        total_sem_sim = 0.0
        
        m_list = result.get_per_sample_metrics()
        for m in m_list:
            total_rouge += m.get("rouge_l", 0.0)
            total_bleu += m.get("bleu", 0.0)
            total_sem_sim += m.get("semantic_sim", 0.0)
            
        result.avg_rouge_l = total_rouge / num
        result.avg_bleu = total_bleu / num
        result.avg_semantic_sim = total_sem_sim / num
            
        result.peak_vram_gb = get_peak_vram()

    logger.info(f"Benchmark complete: avg_score={result.avg_score:.2f}, TPS={result.avg_tps:.1f}")
    return result


def _generate_with_count(model: Any, tokenizer: Any, prompt: str, max_new_tokens: int) -> tuple[str, int]:
    """Generate a response and return the number of new tokens."""
    import torch

    inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=512)
    inputs = {k: v.to(model.device) for k, v in inputs.items()}

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            temperature=0.7,
            top_p=0.9,
            do_sample=True,
            pad_token_id=tokenizer.pad_token_id,
        )

    input_length = inputs["input_ids"].shape[1]
    new_tokens_count = outputs[0].shape[0] - input_length
    
    response = tokenizer.decode(outputs[0][input_length:], skip_special_tokens=True)
    return response.strip(), new_tokens_count


def _load_adapter(adapter_path: str, model_name: str = "") -> tuple[Any, Any]:
    """Load a PEFT adapter for inference."""
    from peft import PeftModel
    from transformers import AutoModelForCausalLM, AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(adapter_path)

    if not model_name:
        # Try to get base model name from adapter config
        import json
        from pathlib import Path
        config_path = Path(adapter_path) / "adapter_config.json"
        if config_path.exists():
            with open(config_path) as f:
                config = json.load(f)
            model_name = config.get("base_model_name_or_path", "")

    if not model_name:
        raise ValueError("Cannot determine base model — provide model_name")

    base_model = AutoModelForCausalLM.from_pretrained(
        model_name, device_map="auto", trust_remote_code=True
    )
    model = PeftModel.from_pretrained(base_model, adapter_path)

    return model, tokenizer


def _generate_with_count(model: Any, tokenizer: Any, prompt: str, max_new_tokens: int) -> tuple[str, int]:
    """Generate a response and return the number of new tokens."""
    import torch

    inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=512)
    inputs = {k: v.to(model.device) for k, v in inputs.items()}

    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            temperature=0.7,
            top_p=0.9,
            do_sample=True,
            pad_token_id=tokenizer.pad_token_id,
        )

    # Decode only the generated part
    input_length = inputs["input_ids"].shape[1]
    new_tokens_count = outputs[0].shape[0] - input_length
    response = tokenizer.decode(outputs[0][input_length:], skip_special_tokens=True)
    return response.strip(), new_tokens_count


def _extract_holdout_samples(adapter_path: str, num_samples: int = 10) -> tuple[list[str], list[str]]:
    """Universally detect and extract samples from any dataset structure."""
    from pathlib import Path
    import json
    import random
    
    adapter_dir = Path(adapter_path)
    run_dir = adapter_dir.parent.parent
    summary_path = run_dir / "summary.json"
    
    if not summary_path.exists():
        return [], []
        
    try:
        with open(summary_path) as f:
            summary = json.load(f)
        dataset_path = summary.get("dataset_path") or summary.get("config", {}).get("dataset_path")
        
        if not dataset_path or not Path(dataset_path).exists():
            return [], []
            
        # Load dataset (Handle both JSON and JSONL)
        data = []
        with open(dataset_path) as f:
            first_char = f.read(1)
            f.seek(0)
            if first_char == '[':
                data = json.load(f)
            else:
                for line in f:
                    if line.strip():
                        data.append(json.loads(line))
            
        if data:
            # Shuffle for dynamic variety
            random.seed(42) # Deterministic for repeatability, remove for pure randomness
            random.shuffle(data)
            
            samples = data[:min(num_samples, len(data))]
            prompts = []
            references = []
            
            # Universal Field Detection
            # Prioritized keys for prompts and references
            prompt_keys = ["instruction", "message_1", "question", "prompt", "input", "text"]
            ref_keys = ["output", "message_2", "answer", "target", "response", "label"]
            
            for s in samples:
                p, r = None, None
                
                # 1. Try known keys
                for pk in prompt_keys:
                    if s.get(pk):
                        p = s[pk]
                        break
                
                for rk in ref_keys:
                    if s.get(rk):
                        r = s[rk]
                        break
                
                # 2. Fallback: If still nothing, take the first two keys with strings
                if not p or not r:
                    strings = [v for v in s.values() if isinstance(v, str) and len(v) > 5]
                    if len(strings) >= 2:
                        p = p or strings[0]
                        r = r or strings[1]
                
                if p:
                    prompts.append(str(p))
                    references.append(str(r) if r else "")
            
            return prompts, references
    except Exception as e:
        logger.debug(f"Universal extraction failed: {e}")
        
    return [], []


def _score_response(prompt: str, response: str) -> float:
    """Score a response using basic heuristics (MVP).

    Checks:
    - Non-empty response
    - Reasonable length
    - Not just repeating the prompt
    - Contains actual words

    Returns:
        Score between 0.0 and 1.0.
    """
    if not response or not response.strip():
        return 0.0

    score = 0.0

    # Non-empty
    score += 0.2

    # Reasonable length (at least 20 chars, not too long)
    if 20 <= len(response) <= 2000:
        score += 0.3
    elif len(response) > 2000:
        score += 0.15
    elif len(response) > 5:
        score += 0.1

    # Not just repeating the prompt
    if prompt.strip().lower() not in response.lower():
        score += 0.2
    else:
        score += 0.05

    # Contains multiple words (not garbage)
    words = response.split()
    unique_words = set(w.lower() for w in words)
    if len(unique_words) > 5:
        score += 0.2
    elif len(unique_words) > 2:
        score += 0.1

    # Not too repetitive
    if len(words) > 0:
        repetition_ratio = len(unique_words) / len(words)
        if repetition_ratio > 0.3:
            score += 0.1

    return min(1.0, score)
