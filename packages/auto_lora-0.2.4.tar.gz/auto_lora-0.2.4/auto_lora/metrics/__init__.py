"""Metrics collection, scoring, and benchmarking."""
