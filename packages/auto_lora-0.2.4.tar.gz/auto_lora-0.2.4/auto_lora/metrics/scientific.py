"""Scientific metrics for journal-grade benchmarking.

Calculates NLP metrics (ROUGE, BLEU) and hardware performance (TPS, VRAM).
"""

import time
import torch
from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class ScientificMetrics:
    """Detailed metrics for publication-quality reports."""
    # Accuracy Metrics
    rouge_l: float = 0.0
    bleu: float = 0.0
    semantic_similarity: float = 0.0 # Placeholder for future embedding sim
    
    # Performance Metrics
    tokens_per_second: float = 0.0
    latency_ms: float = 0.0
    vram_peak_gb: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "rouge_l": self.rouge_l,
            "bleu": self.bleu,
            "tps": self.tokens_per_second,
            "latency": self.latency_ms,
            "vram_gb": self.vram_peak_gb
        }

def calculate_rouge_l(prediction: str, reference: str) -> float:
    """Calculate ROUGE-L score between prediction and reference."""
    if not prediction or not reference:
        return 0.0
    try:
        from rouge_score import rouge_scorer
        scorer = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=True)
        scores = scorer.score(reference, prediction)
        return scores['rougeL'].fmeasure
    except Exception:
        # Fallback to a simple LCS based calculation
        return _simple_lcs_score(prediction, reference)


def calculate_bleu(prediction: str, reference: str) -> float:
    """Calculate BLEU score for precision."""
    if not prediction or not reference:
        return 0.0
    try:
        import sacrebleu
        # sacrebleu expects a list of references
        score = sacrebleu.sentence_bleu(prediction, [reference])
        return score.score / 100.0  # Normalize to 0-1
    except Exception:
        return 0.0


_embedder = None

def calculate_semantic_similarity(prediction: str, reference: str) -> float:
    """Calculate semantic similarity using sentence embeddings."""
    if not prediction or not reference:
        return 0.0
    try:
        global _embedder
        from sentence_transformers import SentenceTransformer
        from sklearn.metrics.pairwise import cosine_similarity
        import numpy as np

        if _embedder is None:
            # Use a fast, lightweight model for CPU/laptop efficiency
            _embedder = SentenceTransformer('all-MiniLM-L6-v2')

        embeddings = _embedder.encode([prediction, reference])
        sim = cosine_similarity([embeddings[0]], [embeddings[1]])[0][0]
        return float(sim)
    except Exception:
        return 0.0

def _simple_lcs_score(s1: str, s2: str) -> float:
    """Lightweight Longest Common Subsequence score fallback."""
    m, n = len(s1), len(s2)
    if m == 0 or n == 0: return 0.0
    L = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m + 1):
        for j in range(n + 1):
            if i == 0 or j == 0: L[i][j] = 0
            elif s1[i-1] == s2[j-1]: L[i][j] = L[i-1][j-1] + 1
            else: L[i][j] = max(L[i-1][j], L[i][j-1])
    lcs = L[m][n]
    return (2.0 * lcs) / (m + n)

def get_peak_vram() -> float:
    """Get peak VRAM usage in GB."""
    if torch.cuda.is_available():
        return torch.cuda.max_memory_allocated() / (1024**3)
    return 0.0
