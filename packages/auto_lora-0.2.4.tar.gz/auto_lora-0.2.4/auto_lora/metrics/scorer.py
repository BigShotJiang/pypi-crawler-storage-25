"""Scoring formula for trial comparison.

Computes a weighted score from multiple metrics to rank trials
and select the best hyperparameter configuration.

Score weights (configurable):
- Validation loss: 50% (lower is better)
- Runtime: 20% (faster is better)
- Memory usage: 15% (lower is better)
- Benchmark quality: 15% (higher is better)
"""

from __future__ import annotations

from auto_lora.core.constants import (
    SCORE_WEIGHT_BENCHMARK,
    SCORE_WEIGHT_MEMORY,
    SCORE_WEIGHT_RUNTIME,
    SCORE_WEIGHT_VAL_LOSS,
)
from auto_lora.utils.logging import get_logger

logger = get_logger(__name__)


def compute_score(
    val_loss: float,
    runtime_seconds: float = 0.0,
    peak_memory_gb: float = 0.0,
    benchmark_score: float = 0.0,
    max_val_loss: float = 10.0,
    max_runtime: float = 3600.0,
    max_memory: float = 24.0,
) -> float:
    """Compute a composite score for a training trial.

    Higher score = better trial. Each component is normalized to [0, 1]
    and combined using configured weights.

    Args:
        val_loss: Validation loss (lower is better).
        runtime_seconds: Training runtime in seconds (lower is better).
        peak_memory_gb: Peak GPU memory in GB (lower is better).
        benchmark_score: Benchmark quality score 0-1 (higher is better).
        max_val_loss: Maximum expected val_loss for normalization.
        max_runtime: Maximum expected runtime for normalization.
        max_memory: Maximum expected memory for normalization.

    Returns:
        Composite score between 0.0 and 1.0 (higher is better).
    """
    # Normalize each metric to [0, 1] where 1 is best
    # Val loss: lower is better → invert
    loss_score = max(0.0, 1.0 - (val_loss / max_val_loss))

    # Runtime: lower is better → invert
    runtime_score = max(0.0, 1.0 - (runtime_seconds / max_runtime)) if max_runtime > 0 else 0.5

    # Memory: lower is better → invert
    memory_score = max(0.0, 1.0 - (peak_memory_gb / max_memory)) if max_memory > 0 else 0.5

    # Benchmark: already 0-1, higher is better
    bench_score = max(0.0, min(1.0, benchmark_score))

    # Weighted combination
    score = (
        SCORE_WEIGHT_VAL_LOSS * loss_score
        + SCORE_WEIGHT_RUNTIME * runtime_score
        + SCORE_WEIGHT_MEMORY * memory_score
        + SCORE_WEIGHT_BENCHMARK * bench_score
    )

    score = round(max(0.0, min(1.0, score)), 4)

    logger.debug(
        f"Score: {score:.4f} "
        f"(loss={loss_score:.3f}×{SCORE_WEIGHT_VAL_LOSS}, "
        f"runtime={runtime_score:.3f}×{SCORE_WEIGHT_RUNTIME}, "
        f"memory={memory_score:.3f}×{SCORE_WEIGHT_MEMORY}, "
        f"bench={bench_score:.3f}×{SCORE_WEIGHT_BENCHMARK})"
    )

    return score


def rank_trials(trials: list[dict]) -> list[dict]:
    """Rank trials by score, highest first.

    Args:
        trials: List of trial dicts with 'score' key.

    Returns:
        Sorted list with added 'rank' key.
    """
    sorted_trials = sorted(trials, key=lambda t: t.get("score", 0), reverse=True)
    for i, trial in enumerate(sorted_trials):
        trial["rank"] = i + 1
    return sorted_trials
