"""Allow running as: python -m auto_lora."""

from auto_lora.cli.app import cli

if __name__ == "__main__":
    cli()
