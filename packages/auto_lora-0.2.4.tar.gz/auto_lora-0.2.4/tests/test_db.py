"""Tests for SQLite database store."""

import pytest
from pathlib import Path
from auto_lora.db.store import RunStore


@pytest.fixture
def store(tmp_path):
    db_path = tmp_path / "test.db"
    return RunStore(db_path)


class TestRunStore:
    def test_create_run(self, store):
        run_id = store.create_run(
            run_id="test_run_001",
            model_name="test-model",
            dataset_path="/data/test.json",
        )
        assert run_id == "test_run_001"

    def test_get_run(self, store):
        store.create_run("run1", "model1", "/data.json")
        run = store.get_run("run1")
        assert run is not None
        assert run["model_name"] == "model1"
        assert run["status"] == "running"

    def test_get_nonexistent_run(self, store):
        assert store.get_run("nonexistent") is None

    def test_list_runs(self, store):
        store.create_run("run1", "model1", "/d1.json")
        store.create_run("run2", "model2", "/d2.json")
        runs = store.list_runs()
        assert len(runs) == 2

    def test_complete_run(self, store):
        store.create_run("run1", "model1", "/d.json")
        store.complete_run("run1", best_trial_id=1, best_score=0.95)
        run = store.get_run("run1")
        assert run["status"] == "completed"
        assert run["best_score"] == 0.95

    def test_fail_run(self, store):
        store.create_run("run1", "model1", "/d.json")
        store.fail_run("run1", "OOM error")
        run = store.get_run("run1")
        assert run["status"] == "failed"

    def test_delete_run(self, store):
        store.create_run("run1", "model1", "/d.json")
        assert store.delete_run("run1")
        assert store.get_run("run1") is None


class TestTrialStore:
    def test_add_trial(self, store):
        store.create_run("run1", "model1", "/d.json")
        tid = store.add_trial("run1", 0, {"rank": 16, "alpha": 32})
        assert tid > 0

    def test_complete_trial(self, store):
        store.create_run("run1", "model1", "/d.json")
        tid = store.add_trial("run1", 0, {"rank": 16, "alpha": 32})
        store.complete_trial(
            tid, "run1",
            train_loss=0.5, val_loss=0.6, perplexity=1.8,
            runtime_seconds=120, peak_memory_gb=4.5,
            tokens_per_second=100, score=0.8,
        )
        trials = store.get_trials("run1")
        assert len(trials) == 1
        assert trials[0]["status"] == "completed"
        assert trials[0]["score"] == 0.8

    def test_get_best_trial(self, store):
        store.create_run("run1", "model1", "/d.json")
        t1 = store.add_trial("run1", 0, {"rank": 8})
        t2 = store.add_trial("run1", 1, {"rank": 16})
        store.complete_trial(t1, "run1", 0.5, 0.6, 1.8, 100, 4, 100, 0.7)
        store.complete_trial(t2, "run1", 0.3, 0.4, 1.5, 120, 5, 90, 0.9)
        best = store.get_best_trial("run1")
        assert best is not None
        assert best["score"] == 0.9

    def test_fail_trial(self, store):
        store.create_run("run1", "model1", "/d.json")
        tid = store.add_trial("run1", 0, {"rank": 16})
        store.fail_trial(tid, "OOM")
        trials = store.get_trials("run1")
        assert trials[0]["status"] == "failed"


class TestArtifactStore:
    def test_add_artifact(self, store):
        store.create_run("run1", "model1", "/d.json")
        aid = store.add_artifact("run1", "adapter", "/out/adapter", "LoRA adapter")
        assert aid > 0

    def test_get_artifacts(self, store):
        store.create_run("run1", "model1", "/d.json")
        store.add_artifact("run1", "adapter", "/out/adapter")
        store.add_artifact("run1", "report", "/out/report.html")
        artifacts = store.get_artifacts("run1")
        assert len(artifacts) == 2
