"""Tests for tuner search space."""

import pytest
from auto_lora.core.config import HardwareProfile, SearchSpaceConfig
from auto_lora.tuner.search_space import build_search_space


class TestBuildSearchSpace:
    def test_default_space(self):
        space = build_search_space()
        assert isinstance(space, SearchSpaceConfig)
        assert len(space.rank_choices) > 0
        assert len(space.batch_size_choices) > 0

    def test_low_vram_constraints(self):
        hw = HardwareProfile(gpu_count=1, vram_gb=6.0, cuda_available=True)
        space = build_search_space(hardware=hw)
        assert max(space.rank_choices) <= 16
        assert max(space.batch_size_choices) <= 2

    def test_cpu_constraints(self):
        hw = HardwareProfile(cuda_available=False)
        space = build_search_space(hardware=hw)
        assert max(space.rank_choices) <= 8
        assert space.epochs_range[1] <= 2

    def test_high_vram_allows_large_ranks(self):
        hw = HardwareProfile(gpu_count=1, vram_gb=48.0, cuda_available=True)
        space = build_search_space(hardware=hw)
        assert 64 in space.rank_choices

    def test_small_dataset_limits_epochs(self):
        space = build_search_space(dataset_rows=50)
        assert space.epochs_range[1] <= 3

    def test_model_specific_modules(self):
        space = build_search_space(model_name="meta-llama/Llama-2-7b")
        assert any("q_proj" in modules for modules in space.target_module_options)
