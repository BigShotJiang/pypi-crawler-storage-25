"""Tests for hardware analyzer."""

import pytest
from auto_lora.core.config import HardwareProfile, TrainingStrategy
from auto_lora.hardware.analyzer import (
    check_system_health,
    detect_hardware,
    estimate_memory,
    recommend_strategy,
)


class TestHardwareProfile:
    def test_no_gpu(self):
        profile = HardwareProfile(gpu_count=0, cuda_available=False)
        assert not profile.has_gpu
        assert profile.recommended_strategy() == TrainingStrategy.CPU

    def test_low_vram_gpu(self):
        profile = HardwareProfile(
            gpu_name="RTX 3060", gpu_count=1, vram_gb=6.0, cuda_available=True
        )
        assert profile.has_gpu
        assert profile.recommended_strategy() == TrainingStrategy.QLORA

    def test_high_vram_gpu(self):
        profile = HardwareProfile(
            gpu_name="RTX 4090", gpu_count=1, vram_gb=24.0, cuda_available=True
        )
        assert profile.has_gpu
        assert profile.recommended_strategy() == TrainingStrategy.LORA


class TestDetectHardware:
    def test_detect_returns_profile(self):
        profile = detect_hardware()
        assert isinstance(profile, HardwareProfile)
        assert profile.cpu_cores > 0
        assert profile.ram_gb > 0


class TestRecommendStrategy:
    def test_cpu_only(self):
        profile = HardwareProfile(cuda_available=False)
        assert recommend_strategy(profile) == TrainingStrategy.CPU

    def test_low_vram(self):
        profile = HardwareProfile(gpu_count=1, vram_gb=8.0, cuda_available=True)
        assert recommend_strategy(profile) == TrainingStrategy.QLORA

    def test_sufficient_vram(self):
        profile = HardwareProfile(gpu_count=1, vram_gb=16.0, cuda_available=True)
        assert recommend_strategy(profile) == TrainingStrategy.LORA


class TestEstimateMemory:
    def test_estimate_returns_dict(self):
        result = estimate_memory("TinyLlama-1.1B", rank=16)
        assert "total_estimated_gb" in result
        assert result["total_estimated_gb"] > 0

    def test_qlora_uses_less_memory(self):
        full = estimate_memory("mistral-7b", rank=16, quantization="none")
        qlora = estimate_memory("mistral-7b", rank=16, quantization="4bit")
        assert qlora["total_estimated_gb"] < full["total_estimated_gb"]


class TestHealthCheck:
    def test_returns_list(self):
        checks = check_system_health()
        assert isinstance(checks, list)
        assert len(checks) > 0

    def test_each_check_has_required_keys(self):
        checks = check_system_health()
        for check in checks:
            assert "name" in check
            assert "status" in check
            assert "message" in check
