"""Tests for metrics scoring."""

import pytest
from auto_lora.metrics.scorer import compute_score, rank_trials


class TestComputeScore:
    def test_perfect_scores(self):
        score = compute_score(val_loss=0.0, runtime_seconds=0.0, peak_memory_gb=0.0, benchmark_score=1.0)
        assert score == 1.0

    def test_terrible_scores(self):
        score = compute_score(val_loss=10.0, runtime_seconds=3600.0, peak_memory_gb=24.0, benchmark_score=0.0)
        assert score == 0.0

    def test_lower_loss_higher_score(self):
        score_a = compute_score(val_loss=0.5, runtime_seconds=100, peak_memory_gb=4.0)
        score_b = compute_score(val_loss=2.0, runtime_seconds=100, peak_memory_gb=4.0)
        assert score_a > score_b

    def test_faster_is_better(self):
        score_a = compute_score(val_loss=1.0, runtime_seconds=100, peak_memory_gb=4.0)
        score_b = compute_score(val_loss=1.0, runtime_seconds=3000, peak_memory_gb=4.0)
        assert score_a > score_b

    def test_score_range(self):
        score = compute_score(val_loss=1.5, runtime_seconds=500, peak_memory_gb=8.0, benchmark_score=0.5)
        assert 0.0 <= score <= 1.0


class TestRankTrials:
    def test_ranking_order(self):
        trials = [
            {"trial_number": 1, "score": 0.5},
            {"trial_number": 2, "score": 0.8},
            {"trial_number": 3, "score": 0.3},
        ]
        ranked = rank_trials(trials)
        assert ranked[0]["trial_number"] == 2
        assert ranked[0]["rank"] == 1
        assert ranked[-1]["trial_number"] == 3
        assert ranked[-1]["rank"] == 3

    def test_empty_trials(self):
        assert rank_trials([]) == []
