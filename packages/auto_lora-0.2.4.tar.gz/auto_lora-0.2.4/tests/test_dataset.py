"""Tests for dataset loading and validation."""

import json
import tempfile
from pathlib import Path

import pytest

from auto_lora.core.config import DatasetFormat, DatasetReport
from auto_lora.dataset.loader import detect_format, load_dataset, get_dataset_columns
from auto_lora.dataset.validator import validate_dataset
from auto_lora.dataset.formatter import format_for_training, split_dataset


# ─── Fixtures ────────────────────────────────────────────────────


@pytest.fixture
def alpaca_data():
    return [
        {"instruction": "What is AI?", "input": "", "output": "AI is artificial intelligence."},
        {"instruction": "What is ML?", "input": "", "output": "ML is machine learning."},
        {"instruction": "What is DL?", "input": "", "output": "DL is deep learning."},
    ]


@pytest.fixture
def alpaca_file(alpaca_data, tmp_path):
    path = tmp_path / "test.json"
    path.write_text(json.dumps(alpaca_data))
    return path


@pytest.fixture
def csv_file(tmp_path):
    path = tmp_path / "test.csv"
    path.write_text("instruction,output\nWhat is AI?,AI is artificial intelligence.\nWhat is ML?,ML is machine learning.\n")
    return path


@pytest.fixture
def data_with_dupes():
    return [
        {"instruction": "Hello", "output": "Hi there"},
        {"instruction": "Hello", "output": "Hi there"},
        {"instruction": "World", "output": "Earth"},
    ]


@pytest.fixture
def data_with_nulls():
    return [
        {"instruction": "Hello", "output": "Hi"},
        {"instruction": "", "output": "Hi"},
        {"instruction": None, "output": "Hi"},
    ]


# ─── Loader Tests ────────────────────────────────────────────────


class TestLoadDataset:
    def test_load_json(self, alpaca_file):
        data = load_dataset(alpaca_file)
        assert len(data) == 3
        assert "instruction" in data[0]

    def test_load_csv(self, csv_file):
        data = load_dataset(csv_file)
        assert len(data) == 2
        assert "instruction" in data[0]

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            load_dataset("/nonexistent/file.json")

    def test_unsupported_extension(self, tmp_path):
        path = tmp_path / "test.xyz"
        path.write_text("data")
        with pytest.raises(ValueError):
            load_dataset(path)


class TestDetectFormat:
    def test_detect_alpaca(self, alpaca_file):
        fmt = detect_format(alpaca_file)
        assert fmt == DatasetFormat.ALPACA

    def test_detect_csv(self, csv_file):
        fmt = detect_format(csv_file)
        assert fmt == DatasetFormat.CSV


class TestGetColumns:
    def test_returns_sorted_keys(self, alpaca_data):
        cols = get_dataset_columns(alpaca_data)
        assert "instruction" in cols
        assert "output" in cols

    def test_empty_data(self):
        assert get_dataset_columns([]) == []


# ─── Validator Tests ─────────────────────────────────────────────


class TestValidateDataset:
    def test_valid_dataset(self, alpaca_data):
        report = validate_dataset(alpaca_data)
        assert report.total_rows == 3
        assert report.quality_score > 0
        assert report.duplicate_count == 0
        assert report.null_count == 0

    def test_empty_dataset(self):
        report = validate_dataset([])
        assert report.quality_score == 0.0
        assert "empty" in report.warnings[0].lower()

    def test_detects_duplicates(self, data_with_dupes):
        report = validate_dataset(data_with_dupes)
        assert report.duplicate_count == 1

    def test_detects_nulls(self, data_with_nulls):
        report = validate_dataset(data_with_nulls)
        assert report.null_count == 2

    def test_quality_score_range(self, alpaca_data):
        report = validate_dataset(alpaca_data)
        assert 0.0 <= report.quality_score <= 1.0


# ─── Formatter Tests ─────────────────────────────────────────────


class TestFormatForTraining:
    def test_formats_alpaca(self, alpaca_data):
        formatted = format_for_training(alpaca_data, DatasetFormat.ALPACA)
        assert len(formatted) == 3
        assert "text" in formatted[0]
        assert "Instruction" in formatted[0]["text"]

    def test_empty_data(self):
        assert format_for_training([]) == []


class TestSplitDataset:
    def test_split_ratio(self, alpaca_data):
        # With only 3 samples, at least 1 should be in val
        train, val = split_dataset(alpaca_data * 10, val_ratio=0.2)
        assert len(train) + len(val) == 30
        assert len(val) > 0

    def test_no_validation(self, alpaca_data):
        train, val = split_dataset(alpaca_data, val_ratio=0)
        assert len(train) == 3
        assert len(val) == 0

    def test_reproducible(self, alpaca_data):
        train1, _ = split_dataset(alpaca_data * 10, seed=42)
        train2, _ = split_dataset(alpaca_data * 10, seed=42)
        assert train1 == train2
