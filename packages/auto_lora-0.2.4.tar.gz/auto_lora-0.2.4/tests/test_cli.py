"""Tests for CLI commands (Click version)."""

import pytest
from click.testing import CliRunner
from auto_lora import __version__
from auto_lora.cli.app import cli

runner = CliRunner()


class TestCLI:
    def test_version(self):
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert f"v{__version__}" in result.output

    def test_help(self):
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "Auto-LoRA" in result.output

    def test_doctor(self):
        result = runner.invoke(cli, ["doctor"])
        assert result.exit_code == 0
        assert "Python" in result.output

    def test_init(self, tmp_path):
        # We need to change to the tmp_path because init creates files relative to CWD if not specified
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["init", "."])
            assert result.exit_code == 0
            assert Path("outputs").exists()
            assert Path("logs").exists()
            assert Path("datasets").exists()
            assert Path("configs").exists()
            assert Path("auto_lora.db").exists()

    def test_runs_list_empty(self, tmp_path):
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["runs", "list"])
            assert result.exit_code == 0

    def test_train_missing_args(self):
        result = runner.invoke(cli, ["train"])
        assert result.exit_code != 0
        assert "Missing option '--model'" in result.output

    def test_runs_show_not_found(self, tmp_path):
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["runs", "show", "nonexistent_run"])
            assert result.exit_code != 0
            assert "Run not found" in result.output

from pathlib import Path
