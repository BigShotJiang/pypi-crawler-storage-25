# tests/test_cli_grid.py
# -*- coding: utf-8 -*-
"""
eulerforge grid CLI 단위 테스트 (CPU, subprocess 불사용).

grid_search.main()을 직접 호출하여 테스트.
"""
from __future__ import annotations

import sys
from unittest.mock import patch, MagicMock

import pytest


def _write_valid_spec(tmp_path):
    """tmp_path에 유효한 grid spec YAML을 작성하고 경로 반환."""
    p = tmp_path / "grid.yml"
    p.write_text(
        "version: 1\n"
        "base_preset: configs/presets/qwen3.5_0.8b_dense_lora_sft.yml\n"
        "run:\n"
        "  output_root: outputs/grid\n"
        "  max_trials: 2\n"
        "  max_train_steps: 5\n"
        "  objective:\n"
        "    direction: minimize\n"
        "    metric: train/total_loss\n"
        "    step_agg: last\n"
        "search:\n"
        "  method: random\n"
        "  space:\n"
        "    - name: training.lr\n"
        "      type: float\n"
        "      low: 0.000001\n"
        "      high: 0.0001\n",
        encoding="utf-8",
    )
    return str(p)


def _write_invalid_spec(tmp_path):
    """tmp_path에 무효한 grid spec YAML을 작성하고 경로 반환."""
    p = tmp_path / "bad.yml"
    p.write_text("version: 2\nbase_preset: foo\n", encoding="utf-8")
    return str(p)


# ===========================================================================
# CLI 동작 테스트
# ===========================================================================

class TestGridCLI:
    def test_help(self):
        """--help → SystemExit(0)."""
        from eulerforge.cli.grid_search import main
        with pytest.raises(SystemExit) as exc_info:
            main(["--help"])
        assert exc_info.value.code == 0

    def test_missing_spec_arg(self):
        """spec 인수 없음 → SystemExit(2) (argparse error)."""
        from eulerforge.cli.grid_search import main
        with pytest.raises(SystemExit) as exc_info:
            main([])
        assert exc_info.value.code == 2

    def test_dry_run_valid_spec(self, tmp_path):
        """--dry-run + 유효 spec → exit 0, 검증 통과 메시지."""
        from eulerforge.cli.grid_search import main
        spec_path = _write_valid_spec(tmp_path)
        with pytest.raises(SystemExit) as exc_info:
            main([spec_path, "--dry-run"])
        assert exc_info.value.code == 0

    def test_dry_run_invalid_spec(self, tmp_path, capsys):
        """--dry-run + 무효 spec → exit 1 + 3-line 에러 출력."""
        from eulerforge.cli.grid_search import main
        spec_path = _write_invalid_spec(tmp_path)
        with pytest.raises(SystemExit) as exc_info:
            main([spec_path, "--dry-run"])
        assert exc_info.value.code == 1
        err = capsys.readouterr().err
        assert "Fix:" in err
        assert "See:" in err

    def test_no_optuna_error_message(self, tmp_path, capsys):
        """optuna 미설치 시 3-line 에러 메시지 출력 후 exit 1."""
        from eulerforge.cli.grid_search import main
        spec_path = _write_valid_spec(tmp_path)

        # optuna를 import 불가능하게 mock
        import builtins
        real_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name == "optuna":
                raise ImportError("mocked no optuna")
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=mock_import):
            with pytest.raises(SystemExit) as exc_info:
                main([spec_path])
        assert exc_info.value.code == 1
        err = capsys.readouterr().err
        assert "hpo" in err or "optuna" in err.lower()
        assert "Fix:" in err

    def test_nonexistent_spec_file(self, tmp_path, capsys):
        """존재하지 않는 spec 파일 → exit 1."""
        from eulerforge.cli.grid_search import main
        with pytest.raises(SystemExit) as exc_info:
            main([str(tmp_path / "nonexistent.yml")])
        assert exc_info.value.code == 1
