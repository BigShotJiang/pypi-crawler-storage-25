import pytest
import torch
import gc
from transformers import AutoModelForCausalLM

from eulerforge.cli.train import (
    _select_backbone_adapter,
    _apply_injection,
    run_training,
    _build_optimizer_for_trainable,
    _build_scheduler,
    DebugOptions
)
from eulerforge.phase_schedules import build_phase_schedule
from torch.utils.data import DataLoader
from eulerforge.utils.data import ProcessedSFTDataset, make_collate_fn

# ---------------------------------------------------------------------------
# 1. TEST MATRIX (all declarative phases, no legacy macros)
# ---------------------------------------------------------------------------

TARGET_MODELS = [
    ("qwen", "qwen3"),
    ("llama2", "llama"),
    ("llama3", "llama"),
    ("mixtral", "mixtral"),
]

# (strategy, phases_config, has_base_ffn_phase)
TARGET_STRATEGIES = [
    ("dense_lora", [
        {"step": 0, "trainable": ["lora", "attn_lora"]},
    ], False),
    ("mixture_lora", [
        {"step": 0, "trainable": ["router"]},
        {"step": 3, "trainable": ["lora", "attn_lora"]},
    ], False),
    ("moe_expert_lora", [
        {"step": 0, "trainable": ["router"]},
        {"step": 3, "trainable": ["lora", "attn_lora"]},
        {"step": 5, "trainable": ["lora", "attn_lora", "router", "base_ffn"],
         "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj", "w1", "w2", "w3"]},
    ], True),
    ("native_moe_expert_lora", [
        {"step": 0, "trainable": ["lora", "attn_lora"]},
    ], False),
]

TEST_CASES = []
for m_type, adapter in TARGET_MODELS:
    for strat, phases, expect_p3 in TARGET_STRATEGIES:
        TEST_CASES.append((m_type, adapter, strat, True, phases, expect_p3))


class MockTokenizer:
    pad_token_id = 0
    eos_token_id = 1
    def save_pretrained(self, path):
        pass


def _build_cfg_for_training(phases, max_steps=10):
    """Build a cfg dict for the training loop using declarative phases."""
    training = {
        "type": "sft",
        "max_steps": max_steps,
        "log_steps": 5,
        "save_steps": 20,
    }
    if phases:
        training["phases"] = phases
    return {"training": training}


@pytest.mark.parametrize(
    "model_type, adapter_name, strategy, attn_lora, phases, is_phase3_expected",
    TEST_CASES
)
def test_training_loop(
    model_type, adapter_name, strategy, attn_lora, phases, is_phase3_expected,
    real_model_factory, dummy_dataset_path, output_dir, target_device
):
    # Pre-check: skip incompatible combos
    is_native_moe_model = (model_type == "mixtral")
    is_dense_moe_strategy = strategy in ("mixture_lora", "moe_expert_lora")
    is_native_strategy = strategy == "native_moe_expert_lora"

    if is_native_moe_model and is_dense_moe_strategy:
        pytest.skip(f"Dense-to-MoE strategy '{strategy}' not for Native MoE '{model_type}'")
    if not is_native_moe_model and is_native_strategy:
        pytest.skip(f"Native MoE strategy '{strategy}' not for Dense model '{model_type}'")

    print(f"\n>>> [Test] Model={model_type} | Strategy={strategy} | Phases={len(phases)}")

    # 1. Real Model
    try:
        model, hub_id = real_model_factory(model_type)
    except Exception as e:
        pytest.skip(f"Model load failed: {e}")

    # 2. Injection Config
    injection_cfg = {
        "strategy": strategy,
        "lora_r": 8,
        "num_experts": 4,
        "top_k": 2,
        "attn_lora": {"enabled": attn_lora, "keywords": ["q_proj", "v_proj"]},
        "target_keywords": ["gate_proj", "up_proj", "down_proj", "w1", "w2", "w3"]
    }
    if strategy == "moe_expert_lora":
        injection_cfg["moe_start_layer"] = 0
        injection_cfg["moe_num_layers"] = 0

    # 3. Injection
    adapter = _select_backbone_adapter(adapter_name)
    try:
        _apply_injection(model, adapter, injection_cfg, verbose=False)
    except Exception as e:
        pytest.fail(f"Injection failed: {e}")

    # 4. Phase Schedule (declarative phases)
    cfg = _build_cfg_for_training(phases, max_steps=10)
    phase_schedule = build_phase_schedule(cfg)

    if phase_schedule:
        phase_schedule.maybe_step(model, 0)

    # 5. Dataset & Loader
    dataset = ProcessedSFTDataset(dummy_dataset_path)
    collate_fn = make_collate_fn(pad_token_id=0)
    train_loader = DataLoader(dataset, batch_size=1, collate_fn=collate_fn)

    # Safety: ensure at least some params trainable
    if not any(p.requires_grad for p in model.parameters()):
        model.get_input_embeddings().weight.requires_grad = True

    optimizer = _build_optimizer_for_trainable(model, lr=1e-4, weight_decay=0.01)
    scheduler_lr = _build_scheduler(optimizer, warmup_steps=2, max_steps=10)

    # 6. Run Training
    try:
        run_training(
            model=model,
            tokenizer=MockTokenizer(),
            train_loader=train_loader,
            val_loader=None,
            optimizer=optimizer,
            scheduler=scheduler_lr,
            device=torch.device(target_device),
            cfg=cfg,
            phase_schedule=phase_schedule,
            output_dir=output_dir,
            dbg=DebugOptions(enabled=False),
            adapter=adapter,
        )

        # 7. Verification
        if is_phase3_expected:
            base_unfrozen = False
            for n, p in model.named_parameters():
                if "lora" not in n and "router" not in n and \
                   any(k in n for k in ["gate", "up", "down", "w1", "w2", "w3"]) and \
                   p.requires_grad:
                    base_unfrozen = True
                    break
            assert base_unfrozen, f"[{model_type}+{strategy}] Phase 3: Base FFN params remain frozen."

        else:
            lora_found = False
            for n, p in model.named_parameters():
                if ("lora" in n or "lora_A" in n) and p.requires_grad:
                    lora_found = True
                    break
            assert lora_found, f"[{model_type}+{strategy}] No trainable LoRA params found."

        print(f">>> [PASS] {model_type} + {strategy}")

    except Exception as e:
        pytest.fail(f"Training loop failed for {model_type}: {e}")

    finally:
        del model, optimizer, scheduler_lr
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            gc.collect()


# ============================================================================
# Regression: max_train_steps 키가 max_steps 대체로 인식되는지 검증
# ============================================================================

class TestMaxTrainStepsAlias:
    """max_train_steps should be accepted as an alias for max_steps."""

    def test_max_train_steps_is_accepted(self):
        """training.max_train_steps가 max_steps와 동일하게 동작해야 함."""
        cfg_with_alias = _build_cfg_for_training(
            phases=[{"step": 0, "trainable": ["lora"]}],
            max_steps=10,
        )
        # max_steps 대신 max_train_steps 사용
        del cfg_with_alias["training"]["max_steps"]
        cfg_with_alias["training"]["max_train_steps"] = 7

        # _get_int는 run_training 내부 함수이므로 직접 호출 불가.
        # 대신 config 값이 프리셋과 일치하는지 검증.
        tr_cfg = cfg_with_alias["training"]
        # 재현: _get_int("max_steps", "max_train_steps", default=10000)
        result = None
        for k in ("max_steps", "max_train_steps"):
            v = tr_cfg.get(k, None)
            if v is not None:
                result = int(v)
                break
        if result is None:
            result = 10000

        assert result == 7, f"Expected 7, got {result}"

    def test_max_steps_takes_priority(self):
        """max_steps와 max_train_steps 둘 다 있으면 max_steps가 우선."""
        tr_cfg = {"max_steps": 100, "max_train_steps": 200}
        result = None
        for k in ("max_steps", "max_train_steps"):
            v = tr_cfg.get(k, None)
            if v is not None:
                result = int(v)
                break
        if result is None:
            result = 10000

        assert result == 100, f"max_steps should take priority, got {result}"

    def test_default_when_neither_specified(self):
        """둘 다 없으면 기본값 10000."""
        tr_cfg = {"type": "sft"}
        result = None
        for k in ("max_steps", "max_train_steps"):
            v = tr_cfg.get(k, None)
            if v is not None:
                result = int(v)
                break
        if result is None:
            result = 10000

        assert result == 10000
