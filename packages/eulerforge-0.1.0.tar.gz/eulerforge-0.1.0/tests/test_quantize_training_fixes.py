# tests/test_quantize_training_fixes.py
# -*- coding: utf-8 -*-
"""Tests for quantized training fixes:
1. LR scheduler continuity on phase transition (no warmup restart)
2. base_ffn LR multiplier scoping (only affects base_ffn params)
3. Proper bitsandbytes dequantization (int4 quant_state)
"""
from __future__ import annotations

import pytest
import torch
import torch.nn as nn

from eulerforge.cli.train import (
    _build_optimizer_for_trainable,
    _build_scheduler,
    _apply_base_ffn_lr_multiplier,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _TinyModel(nn.Module):
    """Minimal model with gate_proj (base_ffn) and lora_A (non-base_ffn)."""

    def __init__(self):
        super().__init__()
        self.gate_proj = nn.Linear(8, 8, bias=False)
        self.lora_A = nn.Linear(8, 4, bias=False)

    def forward(self, x):
        return self.gate_proj(x) + self.lora_A(x).sum()


def _make_trainable_model():
    model = _TinyModel()
    for p in model.parameters():
        p.requires_grad = True
    return model


# =========================================================================
# A) LR Scheduler Continuity
# =========================================================================

class TestLRSchedulerContinuity:
    """Scheduler rebuild with current_step preserves LR continuity."""

    def test_new_scheduler_starts_at_zero_lr(self):
        """Without current_step, scheduler starts LR from warmup (near zero)."""
        model = _make_trainable_model()
        opt = _build_optimizer_for_trainable(model, lr=2e-5, weight_decay=0.01)
        sched = _build_scheduler(opt, warmup_steps=100, max_steps=1000, current_step=0)
        # At step 0, cosine warmup starts near zero
        lr = opt.param_groups[0]["lr"]
        assert lr < 1e-6, f"Expected near-zero LR at step 0, got {lr}"

    def test_scheduler_fast_forward_preserves_lr(self):
        """With current_step=500, scheduler should give mid-training LR."""
        model = _make_trainable_model()
        opt = _build_optimizer_for_trainable(model, lr=2e-5, weight_decay=0.01)
        sched = _build_scheduler(opt, warmup_steps=100, max_steps=1000, current_step=500)
        lr = opt.param_groups[0]["lr"]
        # At step 500/1000 with 100 warmup, LR should be between 0 and 2e-5
        assert lr > 1e-6, f"LR too low at step 500: {lr}"
        assert lr <= 2e-5 + 1e-9, f"LR above base: {lr}"

    def test_scheduler_continuity_after_rebuild(self):
        """Rebuilt scheduler at step N gives same LR as original at step N."""
        model = _make_trainable_model()
        base_lr = 2e-5
        warmup = 50
        max_steps = 500
        target_step = 200

        # Original scheduler: step forward to target_step
        opt1 = _build_optimizer_for_trainable(model, lr=base_lr, weight_decay=0.01)
        sched1 = _build_scheduler(opt1, warmup_steps=warmup, max_steps=max_steps)
        for _ in range(target_step):
            sched1.step()
        lr_original = opt1.param_groups[0]["lr"]

        # Rebuilt scheduler with current_step
        opt2 = _build_optimizer_for_trainable(model, lr=base_lr, weight_decay=0.01)
        sched2 = _build_scheduler(opt2, warmup_steps=warmup, max_steps=max_steps,
                                  current_step=target_step)
        lr_rebuilt = opt2.param_groups[0]["lr"]

        assert abs(lr_original - lr_rebuilt) < 1e-7, (
            f"LR mismatch: original={lr_original}, rebuilt={lr_rebuilt}"
        )

    def test_scheduler_rebuild_no_warmup_dip(self):
        """Phase transition should NOT cause LR to dip back to near-zero."""
        model = _make_trainable_model()
        base_lr = 2e-5
        warmup = 50
        max_steps = 500
        transition_step = 200

        # Step to transition point
        opt = _build_optimizer_for_trainable(model, lr=base_lr, weight_decay=0.01)
        sched = _build_scheduler(opt, warmup_steps=warmup, max_steps=max_steps)
        for _ in range(transition_step):
            sched.step()
        lr_before = opt.param_groups[0]["lr"]

        # Simulate phase transition: rebuild optimizer + scheduler
        opt_new = _build_optimizer_for_trainable(model, lr=base_lr, weight_decay=0.01)
        sched_new = _build_scheduler(opt_new, warmup_steps=warmup, max_steps=max_steps,
                                     current_step=transition_step)
        lr_after = opt_new.param_groups[0]["lr"]

        # LR should be approximately the same (no dip)
        assert abs(lr_before - lr_after) < 1e-10, (
            f"LR dip on phase transition: before={lr_before}, after={lr_after}"
        )


# =========================================================================
# B) Base FFN LR Multiplier Scoping
# =========================================================================

class TestBaseFFNLRMultiplier:
    """_apply_base_ffn_lr_multiplier should only affect base_ffn params."""

    def test_multiplier_does_not_affect_non_ffn_params(self):
        """Non-base_ffn param groups should keep original LR."""
        model = _make_trainable_model()
        base_lr = 2e-5
        opt = _build_optimizer_for_trainable(model, lr=base_lr, weight_decay=0.01)

        _apply_base_ffn_lr_multiplier(opt, model, multiplier=0.5, base_lr=base_lr)

        # After split, non-base_ffn group (lora_A) should keep base_lr
        # and base_ffn group (gate_proj) should have base_lr * 0.5
        found_base_lr = False
        found_half_lr = False
        for pg in opt.param_groups:
            lr = pg["lr"]
            if abs(lr - base_lr) < 1e-10:
                found_base_lr = True
            if abs(lr - base_lr * 0.5) < 1e-10:
                found_half_lr = True

        assert found_base_lr, "Non-FFN params should keep base LR"
        assert found_half_lr, "FFN params should have multiplied LR"

    def test_multiplier_1_is_noop(self):
        """Multiplier=1.0 should not change anything."""
        model = _make_trainable_model()
        opt = _build_optimizer_for_trainable(model, lr=2e-5, weight_decay=0.01)
        n_groups_before = len(opt.param_groups)

        _apply_base_ffn_lr_multiplier(opt, model, multiplier=1.0, base_lr=2e-5)

        assert len(opt.param_groups) == n_groups_before
        assert opt.param_groups[0]["lr"] == 2e-5

    def test_multiplier_splits_param_groups(self):
        """First call should split flat param group into [non_ffn, ffn]."""
        model = _make_trainable_model()
        opt = _build_optimizer_for_trainable(model, lr=2e-5, weight_decay=0.01)
        assert len(opt.param_groups) == 1

        _apply_base_ffn_lr_multiplier(opt, model, multiplier=0.5, base_lr=2e-5)

        assert len(opt.param_groups) == 2, "Should split into 2 groups"

    def test_multiplier_split_is_idempotent(self):
        """Multiple calls should not create extra param groups."""
        model = _make_trainable_model()
        opt = _build_optimizer_for_trainable(model, lr=2e-5, weight_decay=0.01)

        _apply_base_ffn_lr_multiplier(opt, model, multiplier=0.5, base_lr=2e-5)
        n_groups = len(opt.param_groups)

        _apply_base_ffn_lr_multiplier(opt, model, multiplier=0.3, base_lr=2e-5)
        assert len(opt.param_groups) == n_groups, "Should not add more groups"


# =========================================================================
# C) Dequantize Param Data (proper bitsandbytes dequantization)
# =========================================================================

class TestDequantizeParamData:
    """_dequantize_param_data should use bnb dequantize_4bit when quant_state exists."""

    def test_float_param_passthrough(self):
        """Float params are returned as-is (cast to target dtype)."""
        from eulerforge.phase_schedules.groups import _dequantize_param_data

        p = nn.Parameter(torch.randn(4, 4, dtype=torch.float32))
        result = _dequantize_param_data(p, torch.bfloat16)
        assert result.dtype == torch.bfloat16
        # Values should be approximately the same
        assert torch.allclose(result.float(), p.data, atol=1e-2)

    def test_int8_param_cast(self):
        """int8 params without quant_state get numeric cast."""
        from eulerforge.phase_schedules.groups import _dequantize_param_data

        # Non-float params must have requires_grad=False
        p = nn.Parameter(torch.randint(-127, 127, (4, 4), dtype=torch.int8),
                         requires_grad=False)
        result = _dequantize_param_data(p, torch.bfloat16)
        assert result.dtype == torch.bfloat16
        # Values should be in [-127, 127] range
        assert result.max().item() <= 127.0
        assert result.min().item() >= -128.0

    def test_param_with_mock_quant_state(self):
        """Param with quant_state should attempt bnb dequantize_4bit."""
        from eulerforge.phase_schedules.groups import _dequantize_param_data

        # Create a param with a mock quant_state (non-float must have requires_grad=False)
        p = nn.Parameter(torch.randint(0, 255, (8,), dtype=torch.uint8),
                         requires_grad=False)
        p.quant_state = "mock_state"  # type: ignore

        # Should try bnb dequantize_4bit, fall back on failure
        # (since mock_state is not a real QuantState)
        result = _dequantize_param_data(p, torch.bfloat16)
        # Falls back to .to() cast
        assert result.dtype == torch.bfloat16

    def test_set_trainable_uses_proper_dequantize(self):
        """set_trainable_by_groups should call _dequantize_param_data for non-float params."""
        from unittest.mock import patch
        from eulerforge.phase_schedules.groups import set_trainable_by_groups

        # Create model with one int8 param tagged as base_ffn
        model = nn.Module()
        gate = nn.Linear(4, 4, bias=False)
        # Replace weight with int8 (requires_grad=False for non-float)
        gate.weight = nn.Parameter(
            torch.randint(-127, 127, (4, 4), dtype=torch.int8),
            requires_grad=False,
        )
        gate.weight._eulerforge_group = "base_ffn"  # type: ignore
        model.gate_proj = gate  # type: ignore

        with patch(
            "eulerforge.phase_schedules.groups._dequantize_param_data",
            wraps=lambda p, dt: p.data.to(dt),
        ) as mock_deq:
            count = set_trainable_by_groups(
                model,
                active_groups=["base_ffn"],
                mode="replace",
                dequantize_dtype=torch.bfloat16,
            )
            assert mock_deq.called, "_dequantize_param_data should be called"
            assert count == 1


# =========================================================================
# D) Phase Transition Integration
# =========================================================================

class TestPhaseTransitionLR:
    """Integration: phase transition + scheduler rebuild = LR continuity."""

    def test_phase_transition_lr_flow(self):
        """Simulate full phase transition and verify LR doesn't spike."""
        model = _make_trainable_model()
        base_lr = 2e-5
        warmup = 50
        max_steps = 500

        opt = _build_optimizer_for_trainable(model, lr=base_lr, weight_decay=0.01)
        sched = _build_scheduler(opt, warmup_steps=warmup, max_steps=max_steps)

        lr_history = []
        for step in range(300):
            sched.step()
            lr = opt.param_groups[0]["lr"]
            lr_history.append(lr)

            # Simulate phase transition at step 100
            if step == 100:
                lr_before = lr
                opt = _build_optimizer_for_trainable(model, lr=base_lr, weight_decay=0.01)
                sched = _build_scheduler(opt, warmup_steps=warmup, max_steps=max_steps,
                                         current_step=step)
                lr_after = opt.param_groups[0]["lr"]
                assert abs(lr_before - lr_after) < 1e-7, (
                    f"LR discontinuity at transition: {lr_before} → {lr_after}"
                )

        # Verify monotonic decrease after warmup (cosine decay)
        post_warmup = lr_history[warmup + 10:]
        for i in range(1, len(post_warmup)):
            if i == 100 - warmup - 10:
                continue  # skip transition point
            assert post_warmup[i] <= post_warmup[i - 1] + 1e-7, (
                f"LR increased at step {warmup + 10 + i}: "
                f"{post_warmup[i-1]} → {post_warmup[i]}"
            )


# =========================================================================
# E) Base FFN LR Multiplier + Scheduler Sync
# =========================================================================

class TestBaseFFNSplitSchedulerSync:
    """When _apply_base_ffn_lr_multiplier splits optimizer param_groups,
    the scheduler must be rebuilt to match the new group count.

    Bug: Phase 2 transition creates optimizer+scheduler with 1 param group.
    Then handoff's base_ffn_ramp calls _apply_base_ffn_lr_multiplier which
    splits into 2 groups. scheduler.step() crashes with:
      ValueError: zip() argument 2 is shorter than argument 1
    because scheduler.base_lrs has 1 entry but optimizer has 2 param_groups.
    """

    def test_scheduler_step_crashes_after_split_without_rebuild(self):
        """Reproduce: split optimizer then scheduler.step() → ValueError."""
        model = _make_trainable_model()
        base_lr = 2e-5
        opt = _build_optimizer_for_trainable(model, lr=base_lr, weight_decay=0.01)
        sched = _build_scheduler(opt, warmup_steps=10, max_steps=100, current_step=50)

        assert len(opt.param_groups) == 1

        # Split optimizer (simulates handoff base_ffn_ramp)
        _apply_base_ffn_lr_multiplier(opt, model, multiplier=2.0, base_lr=base_lr)
        assert len(opt.param_groups) == 2, "Split should create 2 groups"

        # scheduler.step() should crash without rebuild
        with pytest.raises(ValueError, match="shorter"):
            sched.step()

    def test_scheduler_works_after_split_with_rebuild(self):
        """After split, rebuilding scheduler should make step() work."""
        model = _make_trainable_model()
        base_lr = 2e-5
        opt = _build_optimizer_for_trainable(model, lr=base_lr, weight_decay=0.01)
        sched = _build_scheduler(opt, warmup_steps=10, max_steps=100, current_step=50)

        # Split
        _apply_base_ffn_lr_multiplier(opt, model, multiplier=2.0, base_lr=base_lr)

        # Rebuild scheduler to match new param_groups
        sched = _build_scheduler(opt, warmup_steps=10, max_steps=100, current_step=50)

        # Should not crash
        sched.step()
        sched.step()

        # Verify both groups have valid LRs
        for pg in opt.param_groups:
            assert pg["lr"] > 0

    def test_full_handoff_flow_no_crash(self):
        """Simulate the real training loop flow: phase transition → handoff ramp → scheduler.step()."""
        from eulerforge.cli.train import (
            _build_optimizer_for_trainable,
            _build_scheduler,
            _apply_base_ffn_lr_multiplier,
        )

        model = _make_trainable_model()
        base_lr = 1e-5
        warmup = 10
        max_steps = 200

        # Phase 2 transition: rebuild optimizer + scheduler
        opt = _build_optimizer_for_trainable(model, lr=base_lr, weight_decay=0.01)
        sched = _build_scheduler(opt, warmup_steps=warmup, max_steps=max_steps, current_step=50)

        # Handoff ramp: base_ffn_lr_multiplier > 1.0 → splits optimizer
        n_groups_before = len(opt.param_groups)
        _apply_base_ffn_lr_multiplier(opt, model, multiplier=1.5, base_lr=base_lr)
        if len(opt.param_groups) != n_groups_before:
            # Must rebuild scheduler after split
            sched = _build_scheduler(opt, warmup_steps=warmup, max_steps=max_steps,
                                     current_step=50)

        # Run 50 more steps without crash
        for _ in range(50):
            sched.step()

        # Verify LR values are reasonable
        for pg in opt.param_groups:
            assert 0 <= pg["lr"] <= base_lr * 2
