# tests/test_loader.py
# -*- coding: utf-8 -*-
"""
eulerforge.loader — 공용 모델 로더 유닛 테스트 (TDD RED→GREEN).

- TestClassifyPath: 경로 유형 판별 (4 tests)
- TestResolveCheckpointDir: run_dir → checkpoint 해석 (4 tests)
- TestLoadModelMock: load_model() mock 기반 (8 tests)
- TestLoadedModelAPI: LoadedModel/ModelMetadata 인터페이스 (3 tests)
- TestBenchClientUsesLoader: bench 회귀 방지 (2 tests)
"""
from __future__ import annotations

import json
import os
import sys
from unittest import mock

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))


# =========================================================================
# TestClassifyPath
# =========================================================================
class TestClassifyPath:
    """경로 유형 판별 테스트 (4 tests)."""

    def test_run_dir_detected(self, tmp_path):
        """resolved_config.json 존재 → 'run_dir'."""
        from eulerforge.loader import _classify_path

        run_dir = tmp_path / "run_20260311_120000"
        run_dir.mkdir()
        (run_dir / "resolved_config.json").write_text('{"backbone": "qwen3"}')
        (run_dir / "final").mkdir()
        assert _classify_path(str(run_dir)) == "run_dir"

    def test_checkpoint_dir_detected(self, tmp_path):
        """config.json 존재 (resolved_config 없음) → 'checkpoint_dir'."""
        from eulerforge.loader import _classify_path

        ckpt_dir = tmp_path / "final"
        ckpt_dir.mkdir()
        (ckpt_dir / "config.json").write_text('{"model_type": "qwen2"}')
        assert _classify_path(str(ckpt_dir)) == "checkpoint_dir"

    def test_hf_model_dir_detected(self, tmp_path):
        """config.json 존재 + lora_info 없음 → 'checkpoint_dir' (HF와 동일 취급)."""
        from eulerforge.loader import _classify_path

        hf_dir = tmp_path / "qwen3_model"
        hf_dir.mkdir()
        (hf_dir / "config.json").write_text('{"model_type": "qwen2"}')
        assert _classify_path(str(hf_dir)) == "checkpoint_dir"

    def test_invalid_dir_raises(self, tmp_path):
        """resolved_config.json도 config.json도 없음 → ValueError."""
        from eulerforge.loader import _classify_path

        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()
        with pytest.raises(ValueError, match="EulerForge 체크포인트를 식별할 수 없습니다"):
            _classify_path(str(empty_dir))


# =========================================================================
# TestResolveCheckpointDir
# =========================================================================
class TestResolveCheckpointDir:
    """run_dir → checkpoint 디렉토리 해석 테스트 (4 tests)."""

    def test_final_checkpoint(self, tmp_path):
        """checkpoint='final' → run_dir/final/."""
        from eulerforge.loader import _resolve_checkpoint_dir

        run_dir = tmp_path / "run"
        run_dir.mkdir()
        final_dir = run_dir / "final"
        final_dir.mkdir()
        (final_dir / "config.json").write_text("{}")
        result = _resolve_checkpoint_dir(str(run_dir), "final")
        assert result == str(final_dir)

    def test_best_checkpoint(self, tmp_path):
        """checkpoint='best' → run_dir/checkpoint-best/."""
        from eulerforge.loader import _resolve_checkpoint_dir

        run_dir = tmp_path / "run"
        run_dir.mkdir()
        best_dir = run_dir / "checkpoint-best"
        best_dir.mkdir()
        (best_dir / "config.json").write_text("{}")
        result = _resolve_checkpoint_dir(str(run_dir), "best")
        assert result == str(best_dir)

    def test_latest_checkpoint(self, tmp_path):
        """checkpoint='latest' → run_dir/checkpoint-latest/."""
        from eulerforge.loader import _resolve_checkpoint_dir

        run_dir = tmp_path / "run"
        run_dir.mkdir()
        latest_dir = run_dir / "checkpoint-latest"
        latest_dir.mkdir()
        (latest_dir / "config.json").write_text("{}")
        result = _resolve_checkpoint_dir(str(run_dir), "latest")
        assert result == str(latest_dir)

    def test_missing_checkpoint_raises(self, tmp_path):
        """존재하지 않는 checkpoint → ValueError."""
        from eulerforge.loader import _resolve_checkpoint_dir

        run_dir = tmp_path / "run"
        run_dir.mkdir()
        with pytest.raises(ValueError, match="체크포인트 디렉토리를 찾을 수 없습니다"):
            _resolve_checkpoint_dir(str(run_dir), "final")


# =========================================================================
# TestLoadedModelAPI
# =========================================================================
class TestLoadedModelAPI:
    """LoadedModel/ModelMetadata 인터페이스 테스트 (3 tests)."""

    def test_loaded_model_has_required_attrs(self):
        """LoadedModel은 model, tokenizer, metadata를 가져야 한다."""
        from eulerforge.loader import LoadedModel, ModelMetadata

        meta = ModelMetadata(
            strategy="dense_lora",
            backbone="qwen3",
            path_type="checkpoint_dir",
            checkpoint_dir="/fake/path",
            lora_config={"lora_r": 16, "lora_alpha": 32},
            structure_preserved=False,
        )
        result = LoadedModel(
            model=mock.MagicMock(),
            tokenizer=mock.MagicMock(),
            metadata=meta,
        )
        assert result.model is not None
        assert result.tokenizer is not None
        assert result.metadata.strategy == "dense_lora"

    def test_metadata_none_strategy(self):
        """LoRA 없는 HF 모델 → strategy='none'."""
        from eulerforge.loader import ModelMetadata

        meta = ModelMetadata(
            strategy="none",
            backbone="",
            path_type="checkpoint_dir",
            checkpoint_dir="/fake",
            lora_config=None,
            structure_preserved=False,
        )
        assert meta.strategy == "none"
        assert meta.lora_config is None

    def test_metadata_structure_preserved(self):
        """MoE 구조 보존 시 structure_preserved=True."""
        from eulerforge.loader import ModelMetadata

        meta = ModelMetadata(
            strategy="moe_expert_lora",
            backbone="gemma3",
            path_type="run_dir",
            checkpoint_dir="/fake/run/final",
            lora_config={"lora_r": 32, "lora_alpha": 64},
            structure_preserved=True,
        )
        assert meta.structure_preserved is True
        assert meta.backbone == "gemma3"


# =========================================================================
# TestLoadModelMock
# =========================================================================
class TestLoadModelMock:
    """load_model() mock 기반 테스트 (8 tests)."""

    def _make_run_dir(self, tmp_path, strategy="dense_lora", backbone="qwen3"):
        """테스트용 run_dir 생성 헬퍼."""
        run_dir = tmp_path / "run"
        run_dir.mkdir()
        resolved = {
            "backbone": backbone,
            "injection": {
                "strategy": strategy,
                "lora_r": 16,
                "lora_alpha": 32,
                "num_experts": 4,
                "top_k": 2,
                "start_layer": 0,
                "num_layers": 0,
            },
        }
        (run_dir / "resolved_config.json").write_text(json.dumps(resolved))

        final_dir = run_dir / "final"
        final_dir.mkdir()
        (final_dir / "config.json").write_text('{"model_type": "qwen2"}')
        (final_dir / "lora_info.json").write_text(json.dumps({
            "lora_r": 16, "lora_alpha": 32.0, "strategy": strategy,
        }))
        return str(run_dir)

    def _make_checkpoint_dir(self, tmp_path):
        """테스트용 checkpoint_dir 생성 헬퍼."""
        ckpt_dir = tmp_path / "ckpt"
        ckpt_dir.mkdir()
        (ckpt_dir / "config.json").write_text('{"model_type": "qwen2"}')
        return str(ckpt_dir)

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_load_from_run_dir(self, mock_load_ckpt, tmp_path):
        """run_dir에서 load_model → LoadedModel 반환."""
        import torch
        from eulerforge.loader import load_model

        run_dir = self._make_run_dir(tmp_path)

        mock_model = mock.MagicMock()
        mock_model.load_state_dict.return_value = ([], [])
        mock_model._tied_weights_keys = {}
        mock_model.to.return_value = mock_model
        mock_model.state_dict.return_value = {"model.w": torch.zeros(2)}

        mock_load_ckpt.return_value = (mock_model, mock.MagicMock())

        result = load_model(run_dir, device="cpu")
        assert result.metadata.path_type == "run_dir"
        assert result.metadata.strategy != "none"
        assert result.model is not None
        assert result.tokenizer is not None

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_load_from_checkpoint_dir(self, mock_load_ckpt, tmp_path):
        """checkpoint_dir에서 load_model → path_type='checkpoint_dir'."""
        from eulerforge.loader import load_model

        ckpt_dir = self._make_checkpoint_dir(tmp_path)

        mock_model = mock.MagicMock()
        mock_model.to.return_value = mock_model
        mock_load_ckpt.return_value = (mock_model, mock.MagicMock())

        result = load_model(ckpt_dir, device="cpu")
        assert result.metadata.path_type == "checkpoint_dir"

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_load_dense_lora_strategy(self, mock_load_ckpt, tmp_path):
        """dense_lora 전략 → strategy='dense_lora', structure_preserved=False."""
        import torch
        from eulerforge.loader import load_model

        run_dir = self._make_run_dir(tmp_path, strategy="dense_lora")

        mock_model = mock.MagicMock()
        mock_model.load_state_dict.return_value = ([], [])
        mock_model._tied_weights_keys = {}
        mock_model.to.return_value = mock_model
        mock_model.state_dict.return_value = {"model.w": torch.zeros(2)}

        mock_load_ckpt.return_value = (mock_model, mock.MagicMock())

        result = load_model(run_dir, device="cpu")
        assert result.metadata.strategy == "dense_lora"
        assert result.metadata.structure_preserved is False

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_load_ffn_moe_strategy(self, mock_load_ckpt, tmp_path):
        """moe_expert_lora 전략 → structure_preserved=True."""
        import torch
        from eulerforge.loader import load_model

        run_dir = self._make_run_dir(tmp_path, strategy="moe_expert_lora")

        mock_model = mock.MagicMock()
        mock_model.load_state_dict.return_value = ([], [])
        mock_model._tied_weights_keys = {}
        mock_model.to.return_value = mock_model
        mock_model.state_dict.return_value = {"model.w": torch.zeros(2)}

        mock_load_ckpt.return_value = (mock_model, mock.MagicMock())

        result = load_model(run_dir, device="cpu")
        assert result.metadata.strategy == "moe_expert_lora"
        assert result.metadata.structure_preserved is True

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_load_hf_dir_no_lora(self, mock_load_ckpt, tmp_path):
        """LoRA 없는 HF 디렉토리 → strategy='none'."""
        from eulerforge.loader import load_model

        ckpt_dir = self._make_checkpoint_dir(tmp_path)

        mock_model = mock.MagicMock()
        mock_model.to.return_value = mock_model
        mock_load_ckpt.return_value = (mock_model, mock.MagicMock())

        result = load_model(ckpt_dir, device="cpu")
        assert result.metadata.strategy == "none"
        assert result.metadata.structure_preserved is False

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_load_metadata_backbone(self, mock_load_ckpt, tmp_path):
        """resolved_config에서 backbone 추출."""
        import torch
        from eulerforge.loader import load_model

        run_dir = self._make_run_dir(tmp_path, backbone="gemma3")

        mock_model = mock.MagicMock()
        mock_model.load_state_dict.return_value = ([], [])
        mock_model._tied_weights_keys = {}
        mock_model.to.return_value = mock_model
        mock_model.state_dict.return_value = {"model.w": torch.zeros(2)}

        mock_load_ckpt.return_value = (mock_model, mock.MagicMock())

        result = load_model(run_dir, device="cpu")
        assert result.metadata.backbone == "gemma3"

    def test_load_invalid_path_raises(self, tmp_path):
        """존재하지 않는 경로 → ValueError."""
        from eulerforge.loader import load_model

        with pytest.raises(ValueError):
            load_model(str(tmp_path / "nonexistent"))

    def test_load_empty_dir_raises(self, tmp_path):
        """빈 디렉토리 → ValueError."""
        from eulerforge.loader import load_model

        empty = tmp_path / "empty"
        empty.mkdir()
        with pytest.raises(ValueError, match="식별할 수 없습니다"):
            load_model(str(empty))


# =========================================================================
# TestBenchClientUsesLoader
# =========================================================================
class TestBenchClientUsesLoader:
    """bench LocalHFClient가 공용 로더를 사용하는지 회귀 방지 (2 tests)."""

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_local_hf_client_uses_loader(self, mock_load_ckpt, tmp_path):
        """LocalHFClient가 내부적으로 load_model을 사용."""
        from eulerforge.utils.bench_client import LocalHFClient

        ckpt_dir = tmp_path / "model"
        ckpt_dir.mkdir()
        (ckpt_dir / "config.json").write_text('{"model_type": "qwen2"}')

        mock_model = mock.MagicMock()
        mock_model.device = "cpu"
        mock_model.to.return_value = mock_model
        mock_tok = mock.MagicMock()
        mock_load_ckpt.return_value = (mock_model, mock_tok)

        client = LocalHFClient(model_dir=str(ckpt_dir), device="cpu")
        assert client.model is not None
        assert client.tokenizer is not None

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_local_hf_client_chat_still_works(self, mock_load_ckpt, tmp_path):
        """리팩토링 후에도 chat() 인터페이스 유지."""
        import torch
        from eulerforge.utils.bench_client import LocalHFClient

        ckpt_dir = tmp_path / "model"
        ckpt_dir.mkdir()
        (ckpt_dir / "config.json").write_text('{"model_type": "qwen2"}')

        mock_model = mock.MagicMock()
        mock_model.device = "cpu"
        mock_model.to.return_value = mock_model
        mock_tok = mock.MagicMock()
        mock_tok.chat_template = "template"
        mock_tok.apply_chat_template.return_value = "Hello"
        input_ids = torch.zeros((1, 3), dtype=torch.long)
        mock_tok.return_value = {"input_ids": input_ids}
        mock_tok.decode.return_value = "Response"
        mock_tok.eos_token_id = 0
        mock_model.generate.return_value = torch.zeros((1, 5), dtype=torch.long)

        mock_load_ckpt.return_value = (mock_model, mock_tok)

        client = LocalHFClient(model_dir=str(ckpt_dir), device="cpu")
        result = client.chat([{"role": "user", "content": "Hi"}])
        assert isinstance(result, str)


# =========================================================================
# TestLoadPrecision
# =========================================================================
class TestLoadPrecision:
    """load_model의 load_precision 파라미터 테스트 (6 tests)."""

    def _make_checkpoint_dir(self, tmp_path):
        ckpt_dir = tmp_path / "ckpt"
        ckpt_dir.mkdir()
        (ckpt_dir / "config.json").write_text('{"model_type": "qwen2"}')
        return str(ckpt_dir)

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_load_precision_default_is_none(self, mock_load_ckpt, tmp_path):
        """load_precision 미지정 → _load_checkpoint에 load_precision=None 전달."""
        from eulerforge.loader import load_model

        ckpt_dir = self._make_checkpoint_dir(tmp_path)
        mock_load_ckpt.return_value = (mock.MagicMock(), mock.MagicMock())

        load_model(ckpt_dir, device="cpu")
        call_kwargs = mock_load_ckpt.call_args[1]
        assert call_kwargs.get("load_precision") is None

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_load_precision_bf16_passed(self, mock_load_ckpt, tmp_path):
        """load_precision='bf16' → _load_checkpoint에 전달."""
        from eulerforge.loader import load_model

        ckpt_dir = self._make_checkpoint_dir(tmp_path)
        mock_load_ckpt.return_value = (mock.MagicMock(), mock.MagicMock())

        load_model(ckpt_dir, device="cpu", load_precision="bf16")
        call_kwargs = mock_load_ckpt.call_args[1]
        assert call_kwargs["load_precision"] == "bf16"

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_load_precision_int4_passed(self, mock_load_ckpt, tmp_path):
        """load_precision='int4' → _load_checkpoint에 전달."""
        from eulerforge.loader import load_model

        ckpt_dir = self._make_checkpoint_dir(tmp_path)
        mock_load_ckpt.return_value = (mock.MagicMock(), mock.MagicMock())

        load_model(ckpt_dir, device="cpu", load_precision="int4")
        call_kwargs = mock_load_ckpt.call_args[1]
        assert call_kwargs["load_precision"] == "int4"

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_load_precision_int8_passed(self, mock_load_ckpt, tmp_path):
        """load_precision='int8' → _load_checkpoint에 전달."""
        from eulerforge.loader import load_model

        ckpt_dir = self._make_checkpoint_dir(tmp_path)
        mock_load_ckpt.return_value = (mock.MagicMock(), mock.MagicMock())

        load_model(ckpt_dir, device="cpu", load_precision="int8")
        call_kwargs = mock_load_ckpt.call_args[1]
        assert call_kwargs["load_precision"] == "int8"

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_load_precision_invalid_raises(self, mock_load_ckpt, tmp_path):
        """유효하지 않은 load_precision → ValueError."""
        from eulerforge.loader import load_model

        ckpt_dir = self._make_checkpoint_dir(tmp_path)
        with pytest.raises(ValueError, match="유효하지 않은 load_precision"):
            load_model(ckpt_dir, device="cpu", load_precision="int3")

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    def test_load_checkpoint_int4_uses_bnb_config(
        self, mock_model_cls, mock_tok_cls, tmp_path
    ):
        """int4 → BitsAndBytesConfig(load_in_4bit=True)로 from_pretrained 호출."""
        from eulerforge.loader import _load_checkpoint

        ckpt_dir = self._make_checkpoint_dir(tmp_path)
        mock_model = mock.MagicMock()
        mock_model.eval.return_value = mock_model
        mock_model_cls.from_pretrained.return_value = mock_model
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        _load_checkpoint(ckpt_dir, device="cpu", load_precision="int4")

        call_kwargs = mock_model_cls.from_pretrained.call_args[1]
        bnb_cfg = call_kwargs.get("quantization_config")
        assert bnb_cfg is not None
        assert bnb_cfg.load_in_4bit is True

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    def test_load_checkpoint_int8_uses_bnb_config(
        self, mock_model_cls, mock_tok_cls, tmp_path
    ):
        """int8 → BitsAndBytesConfig(load_in_8bit=True)로 from_pretrained 호출."""
        from eulerforge.loader import _load_checkpoint

        ckpt_dir = self._make_checkpoint_dir(tmp_path)
        mock_model = mock.MagicMock()
        mock_model.eval.return_value = mock_model
        mock_model_cls.from_pretrained.return_value = mock_model
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        _load_checkpoint(ckpt_dir, device="cpu", load_precision="int8")

        call_kwargs = mock_model_cls.from_pretrained.call_args[1]
        bnb_cfg = call_kwargs.get("quantization_config")
        assert bnb_cfg is not None
        assert bnb_cfg.load_in_8bit is True

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    def test_load_checkpoint_bf16_no_bnb(
        self, mock_model_cls, mock_tok_cls, tmp_path
    ):
        """bf16 → BitsAndBytesConfig 없이 torch_dtype=bfloat16."""
        from eulerforge.loader import _load_checkpoint

        ckpt_dir = self._make_checkpoint_dir(tmp_path)
        mock_model = mock.MagicMock()
        mock_model.eval.return_value = mock_model
        mock_model_cls.from_pretrained.return_value = mock_model
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        _load_checkpoint(ckpt_dir, device="cpu", load_precision="bf16")

        call_kwargs = mock_model_cls.from_pretrained.call_args[1]
        assert call_kwargs.get("quantization_config") is None

    @mock.patch("eulerforge.loader._load_checkpoint")
    def test_metadata_has_load_precision(self, mock_load_ckpt, tmp_path):
        """metadata.load_precision에 사용된 정밀도가 기록됨."""
        from eulerforge.loader import load_model

        ckpt_dir = self._make_checkpoint_dir(tmp_path)
        mock_load_ckpt.return_value = (mock.MagicMock(), mock.MagicMock())

        result = load_model(ckpt_dir, device="cpu", load_precision="int4")
        assert result.metadata.load_precision == "int4"
