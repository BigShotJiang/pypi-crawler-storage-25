# tests/test_tokenize.py
# -*- coding: utf-8 -*-
"""Unit tests for eulerforge.utils.tokenize — raw→processed conversion."""
from __future__ import annotations

import json
import os
import tempfile

import pytest

from eulerforge.utils.tokenize import (
    VALID_TASKS,
    tokenize_sft,
    tokenize_preference,
    tokenize_prompted_preference,
    preprocess_file,
)

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


# ---------------------------------------------------------------------------
# Shared tokenizer fixture (session-scoped for speed)
# ---------------------------------------------------------------------------
@pytest.fixture(scope="session")
def tokenizer():
    from transformers import AutoTokenizer

    tok = AutoTokenizer.from_pretrained("gpt2")
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    return tok


# =========================================================================
# A) SFT tokenization
# =========================================================================
class TestTokenizeSFT:
    """tokenize_sft: text-only and prompt/response modes."""

    def test_text_only_produces_required_keys(self, tokenizer):
        row = {"text": "Hello world, this is a test."}
        out = tokenize_sft(row, tokenizer, max_length=128)
        assert "input_ids" in out
        assert "attention_mask" in out
        assert "labels" in out

    def test_text_only_labels_equal_input_ids(self, tokenizer):
        """Full causal LM: labels should match input_ids."""
        row = {"text": "Hello world."}
        out = tokenize_sft(row, tokenizer, max_length=128)
        assert out["labels"] == out["input_ids"]

    def test_prompt_response_masks_prompt_labels(self, tokenizer):
        """Prompt portion should be masked with -100 in labels."""
        row = {"prompt": "What is ML?", "response": "ML is great."}
        out = tokenize_sft(row, tokenizer, max_length=128)
        # Some prefix of labels must be -100
        neg100_count = sum(1 for v in out["labels"] if v == -100)
        assert neg100_count > 0, "prompt tokens should be masked"

    def test_prompt_response_completion_labels_match(self, tokenizer):
        """After -100 prefix, labels should match corresponding input_ids."""
        row = {"prompt": "Q?", "response": "A."}
        out = tokenize_sft(row, tokenizer, max_length=128)
        ids = out["input_ids"]
        labels = out["labels"]
        # Find first non -100 position
        first_real = next(i for i, v in enumerate(labels) if v != -100)
        assert labels[first_real:] == ids[first_real:]

    def test_max_length_truncation(self, tokenizer):
        row = {"text": "word " * 500}
        out = tokenize_sft(row, tokenizer, max_length=32)
        assert len(out["input_ids"]) <= 32

    def test_empty_text_raises(self, tokenizer):
        row = {"text": ""}
        with pytest.raises(ValueError, match="(?i)empty"):
            tokenize_sft(row, tokenizer, max_length=128)

    def test_custom_column_name(self, tokenizer):
        row = {"content": "Hello world."}
        out = tokenize_sft(row, tokenizer, max_length=128, text_col="content")
        assert len(out["input_ids"]) > 0


# =========================================================================
# B) Preference tokenization (no prompt)
# =========================================================================
class TestTokenizePreference:
    """tokenize_preference: chosen/rejected without prompt."""

    def test_produces_all_required_keys(self, tokenizer):
        row = {"chosen": "Good answer.", "rejected": "Bad answer."}
        out = tokenize_preference(row, tokenizer, max_length=128)
        expected_keys = {
            "chosen_input_ids", "chosen_attention_mask", "chosen_labels",
            "rejected_input_ids", "rejected_attention_mask", "rejected_labels",
        }
        assert expected_keys.issubset(out.keys())

    def test_labels_are_full_sequence(self, tokenizer):
        """Without prompt, labels == input_ids (full causal)."""
        row = {"chosen": "Good.", "rejected": "Bad."}
        out = tokenize_preference(row, tokenizer, max_length=128)
        assert out["chosen_labels"] == out["chosen_input_ids"]
        assert out["rejected_labels"] == out["rejected_input_ids"]

    def test_max_length_truncation(self, tokenizer):
        row = {"chosen": "word " * 500, "rejected": "word " * 500}
        out = tokenize_preference(row, tokenizer, max_length=32)
        assert len(out["chosen_input_ids"]) <= 32
        assert len(out["rejected_input_ids"]) <= 32


# =========================================================================
# C) Prompted preference tokenization
# =========================================================================
class TestTokenizePromptedPreference:
    """tokenize_prompted_preference: prompt + chosen/rejected completions."""

    def test_produces_all_required_keys(self, tokenizer):
        row = {"prompt": "Q?", "chosen": "Good.", "rejected": "Bad."}
        out = tokenize_prompted_preference(row, tokenizer, max_length=128)
        expected_keys = {
            "prompt_input_ids", "prompt_attention_mask",
            "chosen_input_ids", "chosen_attention_mask", "chosen_labels",
            "rejected_input_ids", "rejected_attention_mask", "rejected_labels",
            "prompt_len",
        }
        assert expected_keys.issubset(out.keys())

    def test_chosen_labels_prompt_masked(self, tokenizer):
        """chosen_labels[:prompt_len] must all be -100."""
        row = {"prompt": "What is ML?", "chosen": "ML is great.", "rejected": "Bad."}
        out = tokenize_prompted_preference(row, tokenizer, max_length=128)
        plen = out["prompt_len"]
        assert plen > 0
        assert all(v == -100 for v in out["chosen_labels"][:plen]), \
            f"chosen_labels[:prompt_len] should be -100, got {out['chosen_labels'][:plen]}"

    def test_rejected_labels_prompt_masked(self, tokenizer):
        """rejected_labels[:prompt_len] must all be -100."""
        row = {"prompt": "What is ML?", "chosen": "Good.", "rejected": "Bad."}
        out = tokenize_prompted_preference(row, tokenizer, max_length=128)
        plen = out["prompt_len"]
        assert all(v == -100 for v in out["rejected_labels"][:plen])

    def test_completion_labels_not_masked(self, tokenizer):
        """After prompt_len, labels should NOT be -100."""
        row = {"prompt": "Q?", "chosen": "Answer is yes.", "rejected": "No."}
        out = tokenize_prompted_preference(row, tokenizer, max_length=128)
        plen = out["prompt_len"]
        chosen_completion = out["chosen_labels"][plen:]
        assert len(chosen_completion) > 0
        assert all(v != -100 for v in chosen_completion)

    def test_prompt_len_matches_encoding(self, tokenizer):
        """prompt_len should match the actual tokenized prompt length."""
        prompt = "What is machine learning?"
        row = {"prompt": prompt, "chosen": "Good answer.", "rejected": "Bad."}
        out = tokenize_prompted_preference(row, tokenizer, max_length=128)
        expected_len = len(tokenizer.encode(prompt, add_special_tokens=False))
        assert out["prompt_len"] == expected_len


# =========================================================================
# D) preprocess_file — file-level integration
# =========================================================================
class TestPreprocessFile:
    """preprocess_file: end-to-end raw JSONL → processed JSONL."""

    def test_sft_text_produces_valid_output(self, tokenizer, tmp_path):
        inp = os.path.join(FIXTURES, "raw_sft_text_tiny.jsonl")
        out = str(tmp_path / "out.jsonl")
        n = preprocess_file(inp, out, "sft", tokenizer, max_length=128)
        assert n == 4
        with open(out) as f:
            for line in f:
                row = json.loads(line)
                assert "input_ids" in row
                assert "labels" in row

    def test_preference_produces_dpo_format(self, tokenizer, tmp_path):
        inp = os.path.join(FIXTURES, "raw_preference_tiny.jsonl")
        out = str(tmp_path / "out.jsonl")
        n = preprocess_file(inp, out, "preference", tokenizer, max_length=128)
        assert n == 4
        with open(out) as f:
            row = json.loads(f.readline())
            assert "chosen_input_ids" in row
            assert "rejected_input_ids" in row

    def test_prompted_preference_prompt_masking(self, tokenizer, tmp_path):
        inp = os.path.join(FIXTURES, "raw_prompted_pref_tiny.jsonl")
        out = str(tmp_path / "out.jsonl")
        n = preprocess_file(inp, out, "prompted_preference", tokenizer, max_length=128)
        assert n == 4
        with open(out) as f:
            row = json.loads(f.readline())
            plen = row["prompt_len"]
            assert all(v == -100 for v in row["chosen_labels"][:plen])

    def test_empty_file_raises(self, tokenizer, tmp_path):
        inp = str(tmp_path / "empty.jsonl")
        with open(inp, "w") as f:
            pass
        out = str(tmp_path / "out.jsonl")
        with pytest.raises(ValueError, match="(?i)empty"):
            preprocess_file(inp, out, "sft", tokenizer, max_length=128)

    def test_invalid_task_raises(self, tokenizer, tmp_path):
        inp = os.path.join(FIXTURES, "raw_sft_text_tiny.jsonl")
        out = str(tmp_path / "out.jsonl")
        with pytest.raises(ValueError, match="(?i)task"):
            preprocess_file(inp, out, "grpo", tokenizer, max_length=128)

    def test_parallel_produces_same_output_as_sequential(self, tokenizer, tmp_path):
        """num_proc>1에서도 sequential과 동일한 결과를 생성한다."""
        inp = os.path.join(FIXTURES, "raw_sft_text_tiny.jsonl")
        out_seq = str(tmp_path / "seq.jsonl")
        out_par = str(tmp_path / "par.jsonl")

        n1 = preprocess_file(inp, out_seq, "sft", tokenizer, max_length=128, num_proc=1)
        n2 = preprocess_file(inp, out_par, "sft", tokenizer, max_length=128, num_proc=2)

        assert n1 == n2
        # JSON 파싱 후 비교 (formatting 차이 무시)
        with open(out_seq) as f1:
            rows1 = sorted(json.dumps(json.loads(l), sort_keys=True) for l in f1)
        with open(out_par) as f2:
            rows2 = sorted(json.dumps(json.loads(l), sort_keys=True) for l in f2)
        assert rows1 == rows2

    def test_parallel_writes_incrementally(self, tokenizer, tmp_path):
        """num_proc>1에서 output 파일이 map 완료 즉시 존재해야 한다.

        이전 구현은 ds.map() 후 별도 루프에서 파일 작성 → 지연.
        수정 후에는 map 중/직후에 파일이 생성되어야 한다.
        """
        inp = os.path.join(FIXTURES, "raw_sft_text_tiny.jsonl")
        out = str(tmp_path / "streaming.jsonl")

        n = preprocess_file(inp, out, "sft", tokenizer, max_length=128, num_proc=2)
        assert n > 0
        # 파일이 존재하고 내용이 있어야 함
        assert os.path.exists(out)
        with open(out) as f:
            lines = f.readlines()
        assert len(lines) == n

    def test_parallel_no_slow_row_iteration(self, tokenizer, tmp_path):
        """parallel 처리 시 HF Dataset의 느린 row-by-row iteration을 사용하지 않아야 한다.

        수정 후 _preprocess_parallel은 mapped.to_json() 또는 batch append 사용.
        소스코드에서 'for row in mapped' 패턴이 없어야 한다.
        """
        import inspect
        from eulerforge.utils.tokenize import _preprocess_parallel
        source = inspect.getsource(_preprocess_parallel)
        assert "for row in mapped" not in source, (
            "_preprocess_parallel should not iterate rows one by one. "
            "Use mapped.to_json() or batch append for fast writing."
        )


# =========================================================================
# EOS 토큰 보장 테스트
# =========================================================================
class TestEnsureEOS:
    """모든 tokenization 함수에서 시퀀스 끝에 EOS 토큰이 보장되는지 검증.

    EOS 없이 훈련하면 모델이 생성 중단을 학습하지 못해
    응답 뒤에 패턴이 무한 반복되는 현상이 발생한다.
    """

    def test_sft_text_ends_with_eos(self, tokenizer):
        """SFT text-only: 출력 input_ids가 eos_token_id로 끝남."""
        row = {"text": "Hello world."}
        result = tokenize_sft(row, tokenizer, max_length=512)
        assert result["input_ids"][-1] == tokenizer.eos_token_id

    def test_sft_prompt_response_ends_with_eos(self, tokenizer):
        """SFT prompt+response: input_ids가 eos_token_id로 끝남."""
        row = {"prompt": "Question: What is 2+2? Answer: ", "response": "4"}
        result = tokenize_sft(row, tokenizer, max_length=512)
        assert result["input_ids"][-1] == tokenizer.eos_token_id

    def test_sft_truncated_ends_with_eos(self, tokenizer):
        """SFT 잘림: max_length에서 잘려도 마지막은 EOS."""
        long_text = "word " * 1000
        result = tokenize_sft({"text": long_text}, tokenizer, max_length=20)
        assert len(result["input_ids"]) == 20
        assert result["input_ids"][-1] == tokenizer.eos_token_id

    def test_sft_labels_end_with_eos(self, tokenizer):
        """SFT labels도 EOS로 끝나야 모델이 EOS 생성을 학습."""
        row = {"text": "The answer is 42."}
        result = tokenize_sft(row, tokenizer, max_length=512)
        # labels 중 -100이 아닌 마지막 값이 eos여야 함
        non_masked = [l for l in result["labels"] if l != -100]
        assert non_masked[-1] == tokenizer.eos_token_id

    def test_preference_chosen_ends_with_eos(self, tokenizer):
        """preference chosen: EOS로 끝남."""
        row = {"chosen": "Good answer.", "rejected": "Bad answer."}
        result = tokenize_preference(row, tokenizer, max_length=512)
        assert result["chosen_input_ids"][-1] == tokenizer.eos_token_id
        assert result["rejected_input_ids"][-1] == tokenizer.eos_token_id

    def test_prompted_preference_ends_with_eos(self, tokenizer):
        """prompted_preference: chosen/rejected 모두 EOS로 끝남."""
        row = {"prompt": "Q: What? ", "chosen": "Right.", "rejected": "Wrong."}
        result = tokenize_prompted_preference(row, tokenizer, max_length=512)
        assert result["chosen_input_ids"][-1] == tokenizer.eos_token_id
        assert result["rejected_input_ids"][-1] == tokenizer.eos_token_id

    def test_eos_not_duplicated(self, tokenizer):
        """이미 EOS로 끝나는 텍스트에 EOS가 중복 추가되지 않음."""
        eos_text = "Hello" + tokenizer.eos_token
        result = tokenize_sft({"text": eos_text}, tokenizer, max_length=512)
        # 마지막 2개가 둘 다 eos이면 안 됨 (길이 1 이상이면)
        ids = result["input_ids"]
        if len(ids) >= 2:
            assert not (ids[-1] == tokenizer.eos_token_id and ids[-2] == tokenizer.eos_token_id)

    def test_ensure_eos_helper(self, tokenizer):
        """_ensure_eos 헬퍼 직접 테스트."""
        from eulerforge.utils.tokenize import _ensure_eos
        eos = tokenizer.eos_token_id

        # 짧은 시퀀스 → EOS 추가
        assert _ensure_eos([1, 2, 3], eos, 10)[-1] == eos
        assert len(_ensure_eos([1, 2, 3], eos, 10)) == 4

        # 정확히 max_length → 마지막 토큰 EOS로 교체
        assert _ensure_eos([1, 2, 3], eos, 3)[-1] == eos
        assert len(_ensure_eos([1, 2, 3], eos, 3)) == 3

        # 이미 EOS로 끝남 → 그대로
        assert _ensure_eos([1, 2, eos], eos, 10) == [1, 2, eos]

        # eos_id=None → 그대로
        assert _ensure_eos([1, 2, 3], None, 10) == [1, 2, 3]
