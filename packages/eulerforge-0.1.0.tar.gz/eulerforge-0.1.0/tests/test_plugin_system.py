# tests/test_plugin_system.py
# -*- coding: utf-8 -*-
"""
Plugin system 테스트.

pretrain 명령이 plugin 방식으로 등록/해제되는지 검증.
향후 다른 enterprise 명령도 동일한 패턴으로 plugin화할 수 있도록 범용 구조를 테스트한다.
"""
from __future__ import annotations

import sys
from unittest import mock

import pytest


class TestPluginDiscovery:
    """Plugin 발견 메커니즘 테스트."""

    def test_discover_plugins_returns_list(self):
        """discover_plugins()가 PluginSpec 리스트를 반환."""
        from eulerforge.plugins import discover_plugins
        plugins = discover_plugins()
        assert isinstance(plugins, list)

    def test_pretrain_plugin_discovered_when_present(self):
        """pretrain plugin 모듈이 존재하면 발견된다."""
        from eulerforge.plugins import discover_plugins
        plugins = discover_plugins()
        names = [p.command for p in plugins]
        assert "pretrain" in names

    def test_plugin_spec_has_required_fields(self):
        """PluginSpec에 command, help_key, main_fn 필드가 있어야 한다."""
        from eulerforge.plugins import discover_plugins
        plugins = discover_plugins()
        for p in plugins:
            assert hasattr(p, "command")
            assert hasattr(p, "help_key")
            assert hasattr(p, "main_fn")
            assert callable(p.main_fn)


class TestPluginAbsence:
    """Plugin 미존재 시 동작 테스트."""

    def test_missing_plugin_not_in_help(self):
        """plugin 모듈 import 실패 시 help에 해당 명령이 나타나지 않는다."""
        from eulerforge.plugins import discover_plugins

        # pretrain plugin import를 강제 실패시킴
        with mock.patch.dict(sys.modules, {"eulerforge.plugins.pretrain_plugin": None}):
            # 모듈 캐시 무효화를 위해 새로 discover
            plugins = discover_plugins()
            names = [p.command for p in plugins]
            assert "pretrain" not in names

    def test_missing_plugin_command_rejected(self):
        """plugin 미존재 시 eulerforge pretrain 실행하면 unknown command."""
        from eulerforge.cli.main import main

        with mock.patch.dict(sys.modules, {"eulerforge.plugins.pretrain_plugin": None}):
            with pytest.raises(SystemExit) as exc_info:
                main(argv=["pretrain", "--help"])
            assert exc_info.value.code != 0


class TestCoreCommandsUnaffected:
    """Core 명령이 plugin 시스템에 영향받지 않는지 검증."""

    @pytest.mark.parametrize("cmd", [
        "train", "convert", "preprocess", "bench", "eval", "grid", "export-hf"
    ])
    def test_core_command_in_help(self, cmd):
        """core 명령은 항상 help에 나타난다."""
        from eulerforge.cli.main import _CORE_COMMANDS
        core_names = [c[0] for c in _CORE_COMMANDS]
        assert cmd in core_names

    def test_train_help_works(self):
        """train --help는 plugin 시스템과 무관하게 동작."""
        from eulerforge.cli.main import main
        with pytest.raises(SystemExit) as exc_info:
            main(argv=["train", "--help"])
        assert exc_info.value.code == 0


class TestPluginPattern:
    """향후 enterprise plugin 확장 패턴 검증."""

    def test_plugin_module_naming_convention(self):
        """plugin 모듈은 eulerforge.plugins.{name}_plugin 형태."""
        from eulerforge.plugins import _PLUGIN_MODULES
        for mod_name in _PLUGIN_MODULES:
            assert mod_name.startswith("eulerforge.plugins.")
            assert mod_name.endswith("_plugin")
