# tests/test_grid_engine.py
# -*- coding: utf-8 -*-
"""
Grid Engine 단위 테스트 (CPU, mock 기반).

train.main()을 mock 처리하여 GPU 없이 실행.
Optuna 설치 필요: pip install eulerforge[hpo]
"""
from __future__ import annotations

import gc
import json
import os
from unittest.mock import MagicMock, patch

import pytest

optuna = pytest.importorskip("optuna", reason="optuna not installed (pip install eulerforge[hpo])")

from eulerforge.utils.grid_engine import (
    _create_study,
    _extract_metric,
    _build_grid_params,
    _sample_params,
    _build_summary,
    _save_summary,
    _run_trial,
)
from eulerforge.utils.metrics import MetricsCollector, TBWriter


# ---------------------------------------------------------------------------
# Helper — 최소 spec 빌더
# ---------------------------------------------------------------------------

def _make_spec(method="random", space=None, direction="minimize", step_agg="last"):
    if space is None:
        space = [
            {"name": "training.lr", "type": "float", "low": 1e-6, "high": 1e-4}
        ]
    return {
        "version": 1,
        "base_preset": "configs/presets/qwen3.5_0.8b_dense_lora_sft.yml",
        "run": {
            "output_root": "outputs/grid",
            "max_trials": 3,
            "max_train_steps": 10,
            "objective": {
                "direction": direction,
                "metric": "train/total_loss",
                "step_agg": step_agg,
            },
        },
        "search": {
            "method": method,
            "space": space,
            "sampler": {"seed": 42},
        },
    }


# ===========================================================================
# 1. _create_study — Optuna 샘플러 생성
# ===========================================================================

class TestCreateStudy:
    def test_sampler_random_created(self):
        """method:random → RandomSampler."""
        spec = _make_spec(method="random")
        study = _create_study(spec)
        assert isinstance(study.sampler, optuna.samplers.RandomSampler)
        assert study.direction == optuna.study.StudyDirection.MINIMIZE

    def test_sampler_bayes_created(self):
        """method:bayes → TPESampler."""
        spec = _make_spec(method="bayes")
        study = _create_study(spec)
        assert isinstance(study.sampler, optuna.samplers.TPESampler)

    def test_sampler_grid_created(self):
        """method:grid + categorical → GridSampler."""
        spec = _make_spec(
            method="grid",
            space=[
                {"name": "injection.lora_r", "type": "categorical", "choices": [8, 16]}
            ],
        )
        study = _create_study(spec)
        assert isinstance(study.sampler, optuna.samplers.GridSampler)

    def test_direction_maximize(self):
        """direction:maximize → study.direction = MAXIMIZE."""
        spec = _make_spec(direction="maximize")
        study = _create_study(spec)
        assert study.direction == optuna.study.StudyDirection.MAXIMIZE


# ===========================================================================
# 2. _extract_metric — metrics.jsonl 파싱
# ===========================================================================

class TestExtractMetric:
    def _write_jsonl(self, path, records):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            for r in records:
                f.write(json.dumps(r) + "\n")

    def test_step_agg_last(self, tmp_path):
        """step_agg:last → 마지막 값 반환."""
        path = str(tmp_path / "metrics.jsonl")
        self._write_jsonl(path, [
            {"step": 1, "train/total_loss": 3.0},
            {"step": 2, "train/total_loss": 2.0},
            {"step": 3, "train/total_loss": 1.5},
        ])
        objective = {"metric": "train/total_loss", "step_agg": "last"}
        assert _extract_metric(path, objective) == pytest.approx(1.5)

    def test_step_agg_min(self, tmp_path):
        """step_agg:min → 최솟값 반환."""
        path = str(tmp_path / "metrics.jsonl")
        self._write_jsonl(path, [
            {"step": 1, "train/total_loss": 3.0},
            {"step": 2, "train/total_loss": 1.0},
            {"step": 3, "train/total_loss": 2.0},
        ])
        objective = {"metric": "train/total_loss", "step_agg": "min"}
        assert _extract_metric(path, objective) == pytest.approx(1.0)

    def test_step_agg_mean(self, tmp_path):
        """step_agg:mean → 평균 반환."""
        path = str(tmp_path / "metrics.jsonl")
        self._write_jsonl(path, [
            {"step": 1, "train/total_loss": 2.0},
            {"step": 2, "train/total_loss": 4.0},
        ])
        objective = {"metric": "train/total_loss", "step_agg": "mean"}
        assert _extract_metric(path, objective) == pytest.approx(3.0)

    def test_metric_not_found_raises(self, tmp_path):
        """존재하지 않는 metric 키 → ValueError."""
        path = str(tmp_path / "metrics.jsonl")
        self._write_jsonl(path, [{"step": 1, "train/total_loss": 1.0}])
        with pytest.raises(ValueError, match="nonexistent/metric"):
            _extract_metric(path, {"metric": "nonexistent/metric", "step_agg": "last"})

    def test_nan_metric_value_returned_as_nan(self, tmp_path):
        """NaN 값이 metrics.jsonl에 있으면 NaN을 그대로 반환 (_run_trial에서 처리).

        Why: NaN은 훈련 불안정/발산의 정상적 신호. _extract_metric은 값을 충실히
        반환하고, trial-level에서 worst-value로 변환해야 Optuna가 study를 계속 진행함.
        """
        import math
        path = str(tmp_path / "metrics.jsonl")
        # JSON은 NaN을 기본 미지원 — metrics.py는 allow_nan=True로 직렬화
        with open(path, "w") as f:
            f.write('{"step": 1, "train/total_loss": NaN}\n')
        objective = {"metric": "train/total_loss", "step_agg": "last"}
        result = _extract_metric(path, objective)
        assert math.isnan(result), f"Expected NaN, got {result!r}"


# ===========================================================================
# _run_trial NaN handling
# ===========================================================================


class TestRunTrialNanHandling:
    """NaN metric이 나왔을 때 _run_trial이 graceful하게 처리하는지 검증.

    Why: Optuna는 objective value로 NaN을 거부하고 trial을 실패시키며
    (The value nan is not acceptable), 모든 trial이 NaN이면 study.best_trial이
    raise되어 grid 전체가 실패함. 훈련 스모크 테스트는 wiring 검증이 목적이므로
    NaN을 worst value로 변환하여 study를 완주시켜야 함.
    """

    def _write_nan_metrics(self, tmp_path):
        import os as _os
        trial_dir = tmp_path / "trial_0000"
        trial_dir.mkdir(parents=True, exist_ok=True)
        with open(trial_dir / "metrics.jsonl", "w") as f:
            f.write('{"step": 1, "train/total_loss": NaN}\n')
        return str(trial_dir)

    def test_nan_metric_minimize_returns_inf(self, tmp_path):
        """NaN + direction=minimize → +inf 반환."""
        trial_dir = self._write_nan_metrics(tmp_path)
        spec = _make_spec(direction="minimize")
        spec["run"]["output_root"] = str(tmp_path)
        trial = MagicMock()
        trial.number = 0
        trial.set_user_attr = MagicMock()

        with patch("eulerforge.utils.grid_engine._sample_params", return_value={}), \
             patch("eulerforge.utils.grid_engine._build_train_argv", return_value=[]), \
             patch("eulerforge.cli.train.main"):
            value = _run_trial(trial, spec, project_root=str(tmp_path))

        assert value == float("inf"), f"Expected +inf for NaN minimize, got {value!r}"
        trial.set_user_attr.assert_any_call("error", "NaN metric value")

    def test_nan_metric_maximize_returns_neg_inf(self, tmp_path):
        """NaN + direction=maximize → -inf 반환."""
        trial_dir = self._write_nan_metrics(tmp_path)
        spec = _make_spec(direction="maximize")
        spec["run"]["output_root"] = str(tmp_path)
        trial = MagicMock()
        trial.number = 0
        trial.set_user_attr = MagicMock()

        with patch("eulerforge.utils.grid_engine._sample_params", return_value={}), \
             patch("eulerforge.utils.grid_engine._build_train_argv", return_value=[]), \
             patch("eulerforge.cli.train.main"):
            value = _run_trial(trial, spec, project_root=str(tmp_path))

        assert value == float("-inf"), f"Expected -inf for NaN maximize, got {value!r}"
        trial.set_user_attr.assert_any_call("error", "NaN metric value")


# ===========================================================================
# 3. _build_grid_params
# ===========================================================================

class TestBuildGridParams:
    def test_categorical_space(self):
        """categorical choices → Optuna GridSampler용 dict."""
        space = [
            {"name": "injection.lora_r", "type": "categorical", "choices": [8, 16, 32]},
            {"name": "injection.lora_dropout", "type": "float", "choices": [0.0, 0.1]},
        ]
        result = _build_grid_params(space)
        assert result["injection.lora_r"] == [8, 16, 32]
        assert result["injection.lora_dropout"] == [0.0, 0.1]

    def test_int_with_choices(self):
        """type:int + choices → GridSampler용 dict."""
        space = [
            {"name": "injection.lora_r", "type": "int", "choices": [8, 16]}
        ]
        result = _build_grid_params(space)
        assert result["injection.lora_r"] == [8, 16]


# ===========================================================================
# 4. _sample_params
# ===========================================================================

class TestSampleParams:
    def _make_trial(self, study):
        trial = study.ask()
        return trial

    def test_float_suggests_float(self):
        """type:float + low/high → trial.suggest_float 호출."""
        space = [{"name": "training.lr", "type": "float", "low": 1e-6, "high": 1e-4}]
        study = optuna.create_study()
        trial = study.ask()
        params = _sample_params(trial, space)
        assert "training.lr" in params
        assert 1e-6 <= params["training.lr"] <= 1e-4

    def test_int_suggests_int(self):
        """type:int + low/high → trial.suggest_int 호출."""
        space = [{"name": "injection.lora_r", "type": "int", "low": 8, "high": 64}]
        study = optuna.create_study()
        trial = study.ask()
        params = _sample_params(trial, space)
        assert "injection.lora_r" in params
        assert isinstance(params["injection.lora_r"], int)
        assert 8 <= params["injection.lora_r"] <= 64

    def test_categorical_suggests_categorical(self):
        """type:categorical + choices → trial.suggest_categorical 호출."""
        space = [
            {"name": "injection.lora_r", "type": "categorical", "choices": [8, 16, 32]}
        ]
        study = optuna.create_study()
        trial = study.ask()
        params = _sample_params(trial, space)
        assert params["injection.lora_r"] in [8, 16, 32]


# ===========================================================================
# 5. _build_summary + _save_summary
# ===========================================================================

class TestBuildSummary:
    def _make_completed_study(self, n=3):
        """n개의 완료된 trial을 가진 study 생성."""
        study = optuna.create_study(direction="minimize")
        for i in range(n):
            trial = optuna.trial.create_trial(
                params={"training.lr": 1e-5 * (i + 1)},
                distributions={"training.lr": optuna.distributions.FloatDistribution(1e-6, 1e-4)},
                value=float(i + 1),
            )
            study.add_trial(trial)
        return study

    def test_summary_has_best_trial(self):
        """summary에 best_trial 키가 있다."""
        study = self._make_completed_study()
        spec = _make_spec()
        result = _build_summary(study, spec)
        assert "best_trial" in result
        assert "value" in result["best_trial"]
        assert result["best_trial"]["value"] == pytest.approx(1.0)

    def test_summary_has_all_trials(self):
        """summary에 all_trials 키가 있고 수가 맞다."""
        study = self._make_completed_study(n=3)
        spec = _make_spec()
        result = _build_summary(study, spec)
        assert "all_trials" in result
        assert len(result["all_trials"]) == 3

    def test_summary_trial_has_params(self):
        """all_trials 각 항목에 params 키가 있다."""
        study = self._make_completed_study(n=2)
        spec = _make_spec()
        result = _build_summary(study, spec)
        for t in result["all_trials"]:
            assert "params" in t
            assert "value" in t

    def test_summary_saved_to_json(self, tmp_path):
        """_save_summary가 summary.json을 생성한다."""
        study = self._make_completed_study(n=2)
        spec = _make_spec()
        spec["run"]["output_root"] = str(tmp_path)
        summary = _build_summary(study, spec)
        _save_summary(summary, spec)
        assert (tmp_path / "summary.json").exists()
        loaded = json.loads((tmp_path / "summary.json").read_text())
        assert "best_trial" in loaded

    def test_summary_saved_to_csv(self, tmp_path):
        """_save_summary가 summary.csv를 생성한다."""
        study = self._make_completed_study(n=2)
        spec = _make_spec()
        spec["run"]["output_root"] = str(tmp_path)
        summary = _build_summary(study, spec)
        _save_summary(summary, spec)
        assert (tmp_path / "summary.csv").exists()


# ===========================================================================
# 6. MetricsCollector JSONL 기록 (metrics.py)
# ===========================================================================

class TestMetricsJsonl:
    def _make_collector(self, tmp_path):
        tb = TBWriter(enabled=False, log_dir=str(tmp_path / "tb"))
        model = MagicMock()
        model.parameters.return_value = []
        jsonl = str(tmp_path / "metrics.jsonl")
        collector = MetricsCollector(
            level="minimal",
            tb_writer=tb,
            log_interval=1,
            jsonl_path=jsonl,
        )
        return collector, model, jsonl

    def test_metrics_jsonl_written_per_step(self, tmp_path):
        """log_step() 호출 시 metrics.jsonl에 기록된다."""
        collector, model, jsonl = self._make_collector(tmp_path)
        collector.log_step(
            step=1, main_loss=2.0, total_loss=2.1, aux_loss=None,
            lr=1e-5, metrics={}, model=model,
            tokens_seen=100, samples_seen=10,
        )
        assert os.path.exists(jsonl)
        lines = open(jsonl).readlines()
        assert len(lines) == 1
        record = json.loads(lines[0])
        assert record["step"] == 1
        assert "train/total_loss" in record

    def test_metrics_jsonl_appends(self, tmp_path):
        """여러 step 호출 시 여러 줄이 기록된다."""
        collector, model, jsonl = self._make_collector(tmp_path)
        for step in range(1, 4):
            collector.log_step(
                step=step, main_loss=float(step), total_loss=float(step),
                aux_loss=None, lr=1e-5, metrics={}, model=model,
                tokens_seen=step * 100, samples_seen=step * 10,
            )
        lines = open(jsonl).readlines()
        assert len(lines) == 3
        steps = [json.loads(l)["step"] for l in lines]
        assert steps == [1, 2, 3]

    def test_metrics_jsonl_none_no_file(self, tmp_path):
        """jsonl_path=None이면 파일이 생성되지 않는다."""
        tb = TBWriter(enabled=False, log_dir=str(tmp_path / "tb"))
        model = MagicMock()
        model.parameters.return_value = []
        collector = MetricsCollector(
            level="minimal", tb_writer=tb, log_interval=1, jsonl_path=None
        )
        collector.log_step(
            step=1, main_loss=1.0, total_loss=1.0, aux_loss=None,
            lr=1e-5, metrics={}, model=model,
            tokens_seen=10, samples_seen=1,
        )
        # 파일이 없어야 함
        assert not (tmp_path / "metrics.jsonl").exists()


# ===========================================================================
# bench_eval 관련 summary 테스트
# ===========================================================================

class TestBuildSummaryWithBench:
    """bench_eval 활성화 시 _build_summary 듀얼 기준 테스트."""

    def _make_study_with_bench_scores(self):
        """bench_score가 있는 mock Optuna study를 생성."""
        study = optuna.create_study(direction="minimize")

        # Trial 0: loss 좋음, bench 나쁨
        trial0 = study.ask()
        trial0.suggest_categorical("training.lr", [1e-5, 5e-5])
        trial0.set_user_attr("bench_score", 3.0)
        study.tell(trial0, 1.5)

        # Trial 1: loss 나쁨, bench 좋음
        trial1 = study.ask()
        trial1.suggest_categorical("training.lr", [1e-5, 5e-5])
        trial1.set_user_attr("bench_score", 8.0)
        study.tell(trial1, 2.0)

        # Trial 2: loss 중간, bench 중간
        trial2 = study.ask()
        trial2.suggest_categorical("training.lr", [1e-5, 5e-5])
        trial2.set_user_attr("bench_score", 5.0)
        study.tell(trial2, 1.8)

        return study

    def test_dual_best_separate(self):
        """loss 최적과 bench 최적이 다른 trial일 때 별도 보고."""
        study = self._make_study_with_bench_scores()
        spec = {
            "search": {"method": "random"},
            "run": {
                "objective": {"direction": "minimize", "metric": "loss", "step_agg": "last"},
                "bench_eval": {
                    "enabled": True,
                    "bench_preset": "configs/bench/test.yml",
                    "metric": "avg_score",
                },
            },
        }
        summary = _build_summary(study, spec)

        # loss 최적: trial 0 (1.5)
        assert summary["best_trial"]["number"] == 0
        assert summary["best_trial"]["value"] == 1.5

        # bench 최적: trial 1 (8.0)
        assert "best_by_bench" in summary
        assert summary["best_by_bench"]["number"] == 1
        assert summary["best_by_bench"]["bench_score"] == 8.0

    def test_all_trials_include_bench_score(self):
        """all_trials에 bench_score 포함."""
        study = self._make_study_with_bench_scores()
        spec = {
            "search": {"method": "random"},
            "run": {
                "objective": {"direction": "minimize", "metric": "loss", "step_agg": "last"},
                "bench_eval": {"enabled": True, "bench_preset": "x.yml"},
            },
        }
        summary = _build_summary(study, spec)
        for trial in summary["all_trials"]:
            assert "bench_score" in trial

    def test_no_bench_eval_no_best_by_bench(self):
        """bench_eval 비활성화 시 best_by_bench 없음."""
        study = optuna.create_study(direction="minimize")
        t = study.ask()
        t.suggest_categorical("lr", [1e-5])
        study.tell(t, 1.0)

        spec = {
            "search": {"method": "random"},
            "run": {"objective": {"direction": "minimize", "metric": "loss", "step_agg": "last"}},
        }
        summary = _build_summary(study, spec)
        assert "best_by_bench" not in summary

    def test_save_summary_csv_includes_bench_score(self, tmp_path):
        """CSV에 bench_score 컬럼 포함."""
        study = self._make_study_with_bench_scores()
        spec = {
            "search": {"method": "random"},
            "run": {
                "output_root": str(tmp_path),
                "objective": {"direction": "minimize", "metric": "loss", "step_agg": "last"},
                "bench_eval": {"enabled": True, "bench_preset": "x.yml"},
            },
        }
        summary = _build_summary(study, spec)
        _save_summary(summary, spec)

        import csv
        csv_path = tmp_path / "summary.csv"
        assert csv_path.exists()
        with open(csv_path) as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        assert "bench_score" in rows[0]
        assert float(rows[1]["bench_score"]) == 8.0
