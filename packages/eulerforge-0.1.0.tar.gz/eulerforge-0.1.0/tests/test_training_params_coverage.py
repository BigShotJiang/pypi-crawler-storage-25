# tests/test_training_params_coverage.py
# -*- coding: utf-8 -*-
"""
val_steps 버그 수정 + YAML 파라미터 적용 검증 단위 테스트.

Level 1: Config 파싱 검증 - YAML에 val_steps 등 파라미터가 존재하는지 확인
Level 2: 트리거 로직 시뮬레이션 - 순수 Python으로 val/log/save 트리거 로직 검증
Level 2+: lora_dropout, attn_lora.keywords, orpo_lambda 적용 검증 (CPU only)

모든 테스트: GPU 불필요.
"""
from __future__ import annotations

import pathlib
from typing import Dict, List, Optional, Tuple

import pytest
import torch
import torch.nn as nn
import yaml

from eulerforge.cli.train import _apply_injection, orpo_loss_fn
from eulerforge.adapters.backbones.qwen3 import Qwen3Adapter
from eulerforge.modules.lora import LoRALinear

_PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent
_PRESETS = _PROJECT_ROOT / "configs" / "presets"

PRESET_SFT = _PRESETS / "qwen3.5_0.8b_dense_lora_sft.yml"
PRESET_ORPO = _PRESETS / "qwen3.5_0.8b_dense_lora_orpo.yml"
ALL_PRESETS = list(_PRESETS.glob("*.yml"))


def _load_preset(path: pathlib.Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# ---------------------------------------------------------------------------
# Dummy model (minimal Qwen3-like structure for CPU testing)
# Note: duplicated from test_hyperparams_applied.py because tests/ has no
#       __init__.py, so cross-test imports are not available.
# ---------------------------------------------------------------------------

class _DummyMLP(nn.Module):
    def __init__(self, d: int = 32):
        super().__init__()
        self.gate_proj = nn.Linear(d, d, bias=False)
        self.up_proj = nn.Linear(d, d, bias=False)
        self.down_proj = nn.Linear(d, d, bias=False)


class _DummyAttn(nn.Module):
    def __init__(self, d: int = 32):
        super().__init__()
        self.q_proj = nn.Linear(d, d, bias=False)
        self.k_proj = nn.Linear(d, d, bias=False)
        self.v_proj = nn.Linear(d, d, bias=False)
        self.o_proj = nn.Linear(d, d, bias=False)


class _DummyBlock(nn.Module):
    def __init__(self, d: int = 32):
        super().__init__()
        self.self_attn = _DummyAttn(d)
        self.mlp = _DummyMLP(d)


class _DummyQwen3Model(nn.Module):
    """Qwen3Adapter.find_transformer_layers()가 model.model.layers를 찾을 수 있는 더미 모델."""

    def __init__(self, n_layers: int = 2, d: int = 32):
        super().__init__()
        self.model = nn.Module()
        self.model.layers = nn.ModuleList([_DummyBlock(d) for _ in range(n_layers)])
        self.config = type("C", (), {"hidden_size": d})()


# ---------------------------------------------------------------------------
# Simulation helpers: val/log/save trigger logic
# ---------------------------------------------------------------------------

def _simulate_triggers(
    max_steps: int,
    val_steps: int,
    save_steps: int,
    has_val_loader: bool,
    training_type: str,
) -> Tuple[List[int], List[int]]:
    """Simulate the FIXED val/save trigger logic from train.py.

    Returns (val_triggers, save_triggers).
    """
    val_triggers: List[int] = []
    save_triggers: List[int] = []
    for step in range(1, max_steps + 1):
        # Validation block (val_steps period)
        if has_val_loader and step % val_steps == 0:
            if training_type == "sft":
                val_triggers.append(step)
        # Checkpoint block (save_steps period)
        if step % save_steps == 0:
            save_triggers.append(step)
    return val_triggers, save_triggers


def _simulate_val_with_default(
    max_steps: int,
    save_steps: int,
    val_steps_cfg: Optional[int],
    has_val_loader: bool,
    training_type: str,
) -> List[int]:
    """Simulate _get_val_steps logic: default to save_steps when val_steps is None."""
    effective = val_steps_cfg if val_steps_cfg is not None else save_steps
    val_triggers: List[int] = []
    for step in range(1, max_steps + 1):
        if has_val_loader and step % effective == 0:
            if training_type == "sft":
                val_triggers.append(step)
    return val_triggers


def _simulate_log_triggers(max_steps: int, log_steps: int) -> List[int]:
    return [s for s in range(1, max_steps + 1) if s % log_steps == 0]


def _simulate_save_triggers(max_steps: int, save_steps: int) -> List[int]:
    return [s for s in range(1, max_steps + 1) if s % save_steps == 0]


# ============================================================================
# 1. TestConfigParsing — Level 1: YAML 파라미터 존재 확인
# ============================================================================

class TestConfigParsing:

    def test_val_steps_present_in_preset(self):
        """dense_lora_sft 프리셋에 val_steps가 존재해야 한다."""
        cfg = _load_preset(PRESET_SFT)
        assert "val_steps" in cfg["training"], "training.val_steps가 YAML에 없음"

    def test_val_steps_value_is_500(self):
        """dense_lora_sft의 val_steps == 500."""
        cfg = _load_preset(PRESET_SFT)
        assert int(cfg["training"]["val_steps"]) == 500

    def test_val_steps_less_than_save_steps(self):
        """val_steps < save_steps여야 한다 (독립 트리거가 의미 있음)."""
        cfg = _load_preset(PRESET_SFT)
        val_steps = int(cfg["training"]["val_steps"])
        save_steps = int(cfg["training"]["save_steps"])
        assert val_steps < save_steps, (
            f"val_steps({val_steps}) should be < save_steps({save_steps})"
        )

    def test_log_steps_present_in_preset(self):
        """dense_lora_sft 프리셋에 log_steps가 존재해야 한다."""
        cfg = _load_preset(PRESET_SFT)
        assert "log_steps" in cfg["training"], "training.log_steps가 YAML에 없음"

    def test_all_presets_have_val_steps(self):
        """모든 preset YAML에 val_steps가 정의되어 있어야 한다."""
        missing = []
        for p in ALL_PRESETS:
            cfg = _load_preset(p)
            if "val_steps" not in cfg.get("training", {}):
                missing.append(p.name)
        assert not missing, f"val_steps 없는 프리셋: {missing}"


# ============================================================================
# 2. TestValStepsLogic — Level 2: val_steps 트리거 로직 시뮬레이션
# ============================================================================

class TestValStepsLogic:

    def test_val_fires_at_val_steps_not_save_steps_only(self):
        """val_steps=10, save_steps=30 → val triggers at [10, 20, 30], not just [30]."""
        val_t, save_t = _simulate_triggers(
            max_steps=30, val_steps=10, save_steps=30,
            has_val_loader=True, training_type="sft",
        )
        assert val_t == [10, 20, 30], f"Expected [10,20,30], got {val_t}"
        assert 10 in val_t, "Step 10 should trigger validation (not only step 30)"
        assert 20 in val_t, "Step 20 should trigger validation"

    def test_val_fires_independently_of_save(self):
        """val=500, save=1000 → val fires at [500, 1000]; save fires at [1000] only."""
        val_t, save_t = _simulate_triggers(
            max_steps=1000, val_steps=500, save_steps=1000,
            has_val_loader=True, training_type="sft",
        )
        assert val_t == [500, 1000], f"Expected [500, 1000], got {val_t}"
        assert save_t == [1000], f"Expected [1000], got {save_t}"
        assert 500 in val_t, "Step 500 should trigger validation independently of save"

    def test_val_defaults_to_save_steps(self):
        """val_steps 미지정 시 save_steps와 동일한 주기로 검증 실행."""
        val_t = _simulate_val_with_default(
            max_steps=100, save_steps=50, val_steps_cfg=None,
            has_val_loader=True, training_type="sft",
        )
        _, save_t = _simulate_triggers(
            max_steps=100, val_steps=50, save_steps=50,
            has_val_loader=True, training_type="sft",
        )
        assert val_t == save_t, (
            f"When val_steps not set, triggers should match save_steps. "
            f"val={val_t}, save={save_t}"
        )

    def test_non_sft_no_validation_run(self):
        """DPO/ORPO/RM → val_triggers == [] (validation skipped for non-SFT)."""
        for training_type in ("dpo", "orpo", "rm"):
            val_t, _ = _simulate_triggers(
                max_steps=50, val_steps=10, save_steps=25,
                has_val_loader=True, training_type=training_type,
            )
            assert val_t == [], (
                f"{training_type}: validation should be skipped, got {val_t}"
            )

    def test_no_val_loader_no_validation(self):
        """val_loader 없음 → val_triggers == [] (검증 실행 안 됨)."""
        val_t, _ = _simulate_triggers(
            max_steps=50, val_steps=10, save_steps=25,
            has_val_loader=False, training_type="sft",
        )
        assert val_t == [], (
            f"Without val_loader, val_triggers should be empty, got {val_t}"
        )


# ============================================================================
# 3. TestLogStepsLogic — Level 2: log_steps 트리거 로직 시뮬레이션
# ============================================================================

class TestLogStepsLogic:

    def test_log_fires_every_log_steps(self):
        """log_steps=5, max=20 → [5, 10, 15, 20]."""
        triggers = _simulate_log_triggers(max_steps=20, log_steps=5)
        assert triggers == [5, 10, 15, 20]

    def test_log_default_100(self):
        """log_steps=100, max=200 → [100, 200]."""
        triggers = _simulate_log_triggers(max_steps=200, log_steps=100)
        assert triggers == [100, 200]

    def test_log_steps_1_fires_every_step(self):
        """log_steps=1 → every step triggers logging."""
        triggers = _simulate_log_triggers(max_steps=5, log_steps=1)
        assert triggers == [1, 2, 3, 4, 5]


# ============================================================================
# 4. TestSaveStepsLogic — Level 2: save_steps 트리거 로직 시뮬레이션
# ============================================================================

class TestSaveStepsLogic:

    def test_save_fires_at_save_steps(self):
        """save_steps=1000, max=3000 → [1000, 2000, 3000]."""
        triggers = _simulate_save_triggers(max_steps=3000, save_steps=1000)
        assert triggers == [1000, 2000, 3000]

    def test_save_custom_interval(self):
        """save_steps=7, max=21 → [7, 14, 21]."""
        triggers = _simulate_save_triggers(max_steps=21, save_steps=7)
        assert triggers == [7, 14, 21]


# ============================================================================
# 5. TestLoraDropout — lora_dropout 파라미터 적용 검증
# ============================================================================

class TestLoraDropout:

    def _make_injection_cfg(self, dropout: float) -> dict:
        return {
            "strategy": "dense_lora",
            "lora_r": 4,
            "lora_alpha": 8.0,
            "lora_dropout": dropout,
            "target_keywords": ["gate_proj", "up_proj", "down_proj"],
            "start_layer": 0,
            "num_layers": 0,
            "attn_lora": {"enabled": True, "keywords": ["q_proj", "v_proj"]},
        }

    def test_lora_dropout_applied_to_modules(self):
        """lora_dropout=0.15 → LoRALinear.lora_dropout_p == 0.15."""
        model = _DummyQwen3Model(n_layers=1, d=16)
        adapter = Qwen3Adapter()
        _apply_injection(model, adapter, self._make_injection_cfg(dropout=0.15), verbose=False)

        lora_modules = [m for m in model.modules() if isinstance(m, LoRALinear)]
        assert len(lora_modules) > 0, "No LoRALinear modules found"
        for m in lora_modules:
            assert m.lora_dropout_p == pytest.approx(0.15), (
                f"Expected lora_dropout_p=0.15, got {m.lora_dropout_p}"
            )

    def test_lora_dropout_zero_uses_identity(self):
        """lora_dropout=0.0 → m.dropout is nn.Identity."""
        model = _DummyQwen3Model(n_layers=1, d=16)
        adapter = Qwen3Adapter()
        _apply_injection(model, adapter, self._make_injection_cfg(dropout=0.0), verbose=False)

        lora_modules = [m for m in model.modules() if isinstance(m, LoRALinear)]
        assert len(lora_modules) > 0
        for m in lora_modules:
            assert isinstance(m.dropout, nn.Identity), (
                f"Expected nn.Identity for dropout=0.0, got {type(m.dropout)}"
            )

    def test_lora_dropout_nonzero_uses_dropout(self):
        """lora_dropout=0.15 → m.dropout is nn.Dropout(p=0.15)."""
        model = _DummyQwen3Model(n_layers=1, d=16)
        adapter = Qwen3Adapter()
        _apply_injection(model, adapter, self._make_injection_cfg(dropout=0.15), verbose=False)

        lora_modules = [m for m in model.modules() if isinstance(m, LoRALinear)]
        assert len(lora_modules) > 0
        for m in lora_modules:
            assert isinstance(m.dropout, nn.Dropout), (
                f"Expected nn.Dropout for dropout=0.15, got {type(m.dropout)}"
            )
            assert m.dropout.p == pytest.approx(0.15), (
                f"Expected dropout.p=0.15, got {m.dropout.p}"
            )


# ============================================================================
# 6. TestAttnLoraKeywords — attn_lora.keywords 정확 매칭 검증
# ============================================================================

class TestAttnLoraKeywords:

    def _make_injection_cfg(self, keywords: List[str]) -> dict:
        return {
            "strategy": "dense_lora",
            "lora_r": 4,
            "lora_alpha": 8.0,
            "lora_dropout": 0.0,
            "target_keywords": [],  # FFN 주입 없음 — attn_lora만 테스트
            "start_layer": 0,
            "num_layers": 0,
            "attn_lora": {"enabled": True, "keywords": keywords},
        }

    def test_qv_only_injected(self):
        """keywords=['q_proj','v_proj'] → q,v=LoRALinear; k,o=nn.Linear."""
        model = _DummyQwen3Model(n_layers=1, d=16)
        adapter = Qwen3Adapter()
        _apply_injection(
            model, adapter,
            self._make_injection_cfg(["q_proj", "v_proj"]),
            verbose=False,
        )
        for block in model.model.layers:
            attn = block.self_attn
            assert isinstance(attn.q_proj, LoRALinear), "q_proj should be LoRALinear"
            assert isinstance(attn.v_proj, LoRALinear), "v_proj should be LoRALinear"
            assert not isinstance(attn.k_proj, LoRALinear), "k_proj should remain nn.Linear"
            assert not isinstance(attn.o_proj, LoRALinear), "o_proj should remain nn.Linear"

    def test_all_attn_keywords(self):
        """keywords=['q_proj','k_proj','v_proj','o_proj'] → all LoRALinear."""
        model = _DummyQwen3Model(n_layers=1, d=16)
        adapter = Qwen3Adapter()
        _apply_injection(
            model, adapter,
            self._make_injection_cfg(["q_proj", "k_proj", "v_proj", "o_proj"]),
            verbose=False,
        )
        for block in model.model.layers:
            attn = block.self_attn
            for name in ("q_proj", "k_proj", "v_proj", "o_proj"):
                mod = getattr(attn, name)
                assert isinstance(mod, LoRALinear), f"self_attn.{name} should be LoRALinear"

    def test_empty_keywords_injects_nothing(self):
        """keywords=[] → 모든 attn 모듈 변경 없음 (nn.Linear 유지)."""
        model = _DummyQwen3Model(n_layers=1, d=16)
        adapter = Qwen3Adapter()
        _apply_injection(
            model, adapter,
            self._make_injection_cfg([]),
            verbose=False,
        )
        for block in model.model.layers:
            attn = block.self_attn
            for name in ("q_proj", "k_proj", "v_proj", "o_proj"):
                mod = getattr(attn, name)
                assert not isinstance(mod, LoRALinear), (
                    f"self_attn.{name} should remain nn.Linear with empty keywords"
                )

    def test_partial_keyword_matching(self):
        """keywords=['q_proj'] → q=LoRALinear, k/v/o=nn.Linear."""
        model = _DummyQwen3Model(n_layers=1, d=16)
        adapter = Qwen3Adapter()
        _apply_injection(
            model, adapter,
            self._make_injection_cfg(["q_proj"]),
            verbose=False,
        )
        for block in model.model.layers:
            attn = block.self_attn
            assert isinstance(attn.q_proj, LoRALinear), "q_proj should be LoRALinear"
            for name in ("k_proj", "v_proj", "o_proj"):
                mod = getattr(attn, name)
                assert not isinstance(mod, LoRALinear), (
                    f"self_attn.{name} should remain nn.Linear"
                )


# ============================================================================
# 7. TestOrpoLambdaApplied — orpo_lambda 파라미터 적용 검증
# ============================================================================

class TestOrpoLambdaApplied:

    def _make_fake_logps(self) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        chosen_logps = torch.tensor([-0.5])
        rejected_logps = torch.tensor([-1.5])
        sft_loss = torch.tensor(1.0)
        return chosen_logps, rejected_logps, sft_loss

    def test_lambda_scales_loss(self):
        """orpo_lambda=0.1 vs orpo_lambda=10.0 → 서로 다른 total loss."""
        chosen_logps, rejected_logps, sft_loss = self._make_fake_logps()
        loss_small, _ = orpo_loss_fn(chosen_logps, rejected_logps, sft_loss, orpo_lambda=0.1)
        loss_large, _ = orpo_loss_fn(chosen_logps, rejected_logps, sft_loss, orpo_lambda=10.0)

        small_val = loss_small.item()
        large_val = loss_large.item()
        assert abs(small_val - large_val) > 1e-3, (
            f"Different orpo_lambda should yield different losses: {small_val} vs {large_val}"
        )

    def test_lambda_from_orpo_preset(self):
        """ORPO 프리셋에 orpo_lambda > 0이 정의되어 있어야 한다."""
        cfg = _load_preset(PRESET_ORPO)
        orpo_lambda = float(cfg["training"].get("orpo_lambda", 0.0))
        assert orpo_lambda > 0.0, f"orpo_lambda should be > 0, got {orpo_lambda}"


# ============================================================================
# 6. TestMainTrainingCfgExtraction — main() 내 tr_cfg 추출 로직 검증
# ============================================================================

class TestMainTrainingCfgExtraction:
    """main()에서 tr_cfg = cfg.get('training', {}) 추출이 올바르게 동작하는지 검증.

    Bug fix: main()에서 tr_cfg가 정의되지 않아 NameError 발생했던 버그.
    이 테스트는 cfg → training_type / lr / max_steps 추출 로직을 시뮬레이션한다.
    """

    @staticmethod
    def _extract_main_params(cfg: dict) -> dict:
        """Simulate main()'s tr_cfg extraction logic (lines 2057-2133)."""
        tr_cfg = cfg.get("training", {})
        training_type = tr_cfg.get("type", "sft").lower()
        lr = float(tr_cfg.get("lr", 1e-5))
        weight_decay = float(tr_cfg.get("weight_decay", 0.01))
        max_steps = int(tr_cfg.get("max_steps") or tr_cfg.get("max_train_steps") or 10000)
        warmup_steps = int(tr_cfg.get("warmup_steps", 500))
        batch_size = int(tr_cfg.get("batch_size", 1))
        return {
            "training_type": training_type,
            "lr": lr,
            "weight_decay": weight_decay,
            "max_steps": max_steps,
            "warmup_steps": warmup_steps,
            "batch_size": batch_size,
        }

    def test_tr_cfg_with_training_section(self):
        """training 섹션이 있으면 그 안에서 type 등 추출."""
        cfg = {"training": {"type": "dpo", "lr": 5e-6, "max_train_steps": 3000}}
        params = self._extract_main_params(cfg)
        assert params["training_type"] == "dpo"
        assert params["lr"] == 5e-6
        assert params["max_steps"] == 3000

    def test_tr_cfg_without_training_section(self):
        """training 섹션이 없으면 기본값 사용 (NameError 발생하면 안 됨)."""
        cfg = {}
        params = self._extract_main_params(cfg)
        assert params["training_type"] == "sft"
        assert params["lr"] == 1e-5
        assert params["max_steps"] == 10000
        assert params["warmup_steps"] == 500
        assert params["batch_size"] == 1

    def test_tr_cfg_empty_training_section(self):
        """training: {} (빈 dict) → 기본값."""
        cfg = {"training": {}}
        params = self._extract_main_params(cfg)
        assert params["training_type"] == "sft"

    def test_tr_cfg_type_case_insensitive(self):
        """training.type은 대소문자 무관."""
        cfg = {"training": {"type": "DPO"}}
        params = self._extract_main_params(cfg)
        assert params["training_type"] == "dpo"

    def test_tr_cfg_max_steps_fallback(self):
        """max_steps → max_train_steps → 10000 fallback 순서."""
        # max_steps 우선
        cfg1 = {"training": {"max_steps": 500, "max_train_steps": 1000}}
        assert self._extract_main_params(cfg1)["max_steps"] == 500
        # max_train_steps fallback
        cfg2 = {"training": {"max_train_steps": 2000}}
        assert self._extract_main_params(cfg2)["max_steps"] == 2000
        # 둘 다 없으면 기본값
        cfg3 = {"training": {}}
        assert self._extract_main_params(cfg3)["max_steps"] == 10000

    @pytest.mark.parametrize("preset_path", ALL_PRESETS, ids=lambda p: p.name)
    def test_all_presets_have_extractable_training_type(self, preset_path):
        """모든 프리셋에서 training.type 추출이 가능해야 한다."""
        cfg = _load_preset(preset_path)
        params = self._extract_main_params(cfg)
        assert params["training_type"] in ("sft", "dpo", "orpo", "rm", "ppo"), (
            f"{preset_path.name}: unexpected training_type={params['training_type']}"
        )
