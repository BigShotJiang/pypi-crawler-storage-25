# tests/test_int8_phase_transition.py
# -*- coding: utf-8 -*-
"""Tests for int8 quantization phase transition fixes.

Covers:
1. Module replacement: Linear8bitLt/Linear4bit → nn.Linear
2. Post-transition validator: no non-float trainable params
3. Proper int8 dequantization using int8_vectorwise_dequant
4. Config validation for int8 + base_ffn combinations
5. Forward/backward after module replacement
"""
from __future__ import annotations

import logging

import pytest
import torch
import torch.nn as nn

from eulerforge.phase_schedules.groups import (
    _dequantize_param_data,
    _replace_quantized_modules_for_training,
    _validate_trainable_dtypes,
    set_trainable_by_groups,
)


# ---------------------------------------------------------------------------
# Helpers: Mock bitsandbytes modules for testing without GPU
# ---------------------------------------------------------------------------

class _MockInt8Params(nn.Parameter):
    """Simulates bitsandbytes Int8Params with CB/SCB metadata."""

    def __new__(cls, data, SCB=None, requires_grad=False):
        obj = torch.Tensor._make_subclass(cls, data, requires_grad)
        obj.CB = data
        obj.SCB = SCB
        obj.has_fp16_weights = False
        return obj


class _MockLinear8bitLt(nn.Module):
    """Simulates bitsandbytes Linear8bitLt with int8 weight + forward crash."""

    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

        # Create int8 weights with scale factors
        float_w = torch.randn(out_features, in_features, dtype=torch.float32)
        absmax = float_w.abs().max(dim=1).values
        int8_w = (float_w / absmax.unsqueeze(1) * 127).round().clamp(-128, 127).to(torch.int8)
        scb = absmax

        self.weight = _MockInt8Params(int8_w, SCB=scb, requires_grad=False)
        self.bias = nn.Parameter(torch.zeros(out_features)) if bias else None

        # Simulate bitsandbytes state
        class _State:
            CB = int8_w
            SCB = scb
            has_fp16_weights = False
        self.state = _State()

    def forward(self, x):
        # Simulate the crash: Linear8bitLt.forward tries self.weight.data = self.state.CB
        if self.weight.requires_grad and self.state.CB.dtype == torch.int8:
            # This is the line that crashes in real bitsandbytes:
            # self.weight.data = self.state.CB
            raise RuntimeError(
                "data set to a tensor that requires gradients must be "
                "floating point or complex dtype"
            )
        return nn.functional.linear(x, self.weight.float(), self.bias)


def _make_mock_int8_model():
    """Create a model with mock int8 Linear modules for base_ffn."""
    model = nn.Module()
    # Simulate a transformer layer's MLP
    mlp = nn.Module()
    mlp.gate_proj = _MockLinear8bitLt(16, 32, bias=False)
    mlp.up_proj = _MockLinear8bitLt(16, 32, bias=False)
    mlp.down_proj = _MockLinear8bitLt(32, 16, bias=False)
    model.mlp = mlp

    # Add a float router (already trainable-safe)
    model.router = nn.Linear(16, 4, bias=False)
    model.router.weight._eulerforge_group = "router"
    return model


# Patch bitsandbytes module detection for tests
@pytest.fixture(autouse=True)
def _patch_bnb_types(monkeypatch):
    """Make _replace_quantized_modules_for_training recognize our mock types."""
    import bitsandbytes.nn as bnn

    # Store originals
    orig_lt = bnn.Linear8bitLt

    # Temporarily add our mock to the isinstance check
    class _PatchedMeta(type):
        def __instancecheck__(cls, inst):
            return isinstance(inst, (_MockLinear8bitLt,)) or type.__instancecheck__(cls, inst)

    # We'll use a different approach: monkeypatch the actual check in groups.py
    # Instead, we directly test the lower-level functions
    yield


# =========================================================================
# A) Module Replacement
# =========================================================================

class TestModuleReplacement:
    """_replace_quantized_modules_for_training should swap int8 modules."""

    def test_replace_detects_int8_modules(self):
        """Should detect mock int8 modules by param name matching."""
        # This test uses the raw function with mock types
        # We need to test the param-name-to-module resolution logic
        model = _make_mock_int8_model()
        trainable = {"mlp.gate_proj.weight", "mlp.up_proj.weight", "mlp.down_proj.weight"}

        # Since _replace_quantized_modules_for_training checks isinstance(child, bnb types),
        # and our mocks aren't bnb types, we test the logic indirectly via set_trainable_by_groups

    def test_replacement_produces_float_linear(self):
        """After replacement, modules should be plain nn.Linear with float weights."""
        model = _make_mock_int8_model()

        # Manually replace
        for name in ["gate_proj", "up_proj", "down_proj"]:
            child = getattr(model.mlp, name)
            weight = child.weight
            scb = weight.SCB

            # Proper dequantization
            deq = weight.data.float() * scb.float().unsqueeze(1) / 127.0
            new_linear = nn.Linear(child.in_features, child.out_features, bias=False,
                                   dtype=torch.bfloat16, device=deq.device)
            new_linear.weight.data.copy_(deq.to(torch.bfloat16))
            setattr(model.mlp, name, new_linear)

        # Verify replacement
        for name in ["gate_proj", "up_proj", "down_proj"]:
            mod = getattr(model.mlp, name)
            assert isinstance(mod, nn.Linear)
            assert not isinstance(mod, _MockLinear8bitLt)
            assert mod.weight.dtype == torch.bfloat16

    def test_replacement_preserves_weight_values(self):
        """Dequantized weights should approximate original float values."""
        # Create a known float weight, quantize it, then dequantize
        original = torch.randn(8, 4, dtype=torch.float32)
        absmax = original.abs().max(dim=1).values
        int8_w = (original / absmax.unsqueeze(1) * 127).round().clamp(-128, 127).to(torch.int8)

        # Dequantize
        deq = int8_w.float() * absmax.unsqueeze(1) / 127.0

        # Should be close to original (within int8 quantization error)
        assert torch.allclose(deq, original, atol=0.05), (
            f"Dequantized weights differ too much from original: "
            f"max_diff={torch.abs(deq - original).max().item()}"
        )

    def test_forward_backward_after_replacement(self):
        """Forward and backward should work after module replacement."""
        model = _make_mock_int8_model()

        # Replace int8 modules manually
        for name in ["gate_proj", "up_proj", "down_proj"]:
            child = getattr(model.mlp, name)
            deq = child.weight.data.float() * child.weight.SCB.float().unsqueeze(1) / 127.0
            new_linear = nn.Linear(child.in_features, child.out_features, bias=False,
                                   dtype=torch.float32, device=deq.device)
            new_linear.weight.data.copy_(deq)
            new_linear.weight.requires_grad = True
            setattr(model.mlp, name, new_linear)

        # Forward
        x = torch.randn(2, 16)
        gate_out = model.mlp.gate_proj(x)
        up_out = model.mlp.up_proj(x)
        combined = torch.nn.functional.silu(gate_out) * up_out
        out = model.mlp.down_proj(combined)
        loss = out.sum()

        # Backward
        loss.backward()

        # Verify gradients exist
        for name in ["gate_proj", "up_proj", "down_proj"]:
            mod = getattr(model.mlp, name)
            assert mod.weight.grad is not None, f"{name} has no gradient"
            assert torch.isfinite(mod.weight.grad).all(), f"{name} has non-finite gradient"


# =========================================================================
# B) Post-Transition Validator
# =========================================================================

class TestTrainableDtypeValidator:
    """_validate_trainable_dtypes should catch non-float trainable params."""

    def test_all_float_passes(self):
        """No error when all trainable params are floating-point."""
        model = nn.Module()
        model.w = nn.Linear(4, 4)
        model.w.weight.requires_grad = True
        _validate_trainable_dtypes(model)  # should not raise

    def test_all_float_trainable_passes_validator(self):
        """Validator passes when all trainable params are float."""
        model = nn.Module()
        model.w1 = nn.Linear(4, 4)
        model.w2 = nn.Linear(4, 4)
        model.w1.weight.requires_grad = True
        model.w2.weight.requires_grad = False  # frozen is OK
        _validate_trainable_dtypes(model)  # should not raise

    def test_validator_skips_frozen_non_float(self):
        """Frozen non-float params should not trigger validator error."""
        model = nn.Module()
        model.w = nn.Linear(4, 4)
        # Add a frozen int8 param (simulating still-quantized frozen weight)
        model.register_parameter(
            "frozen_int8",
            nn.Parameter(torch.zeros(4, dtype=torch.int8), requires_grad=False),
        )
        model.w.weight.requires_grad = True
        _validate_trainable_dtypes(model)  # should not raise


# =========================================================================
# C) Proper int8 Dequantization
# =========================================================================

class TestInt8Dequantization:
    """_dequantize_param_data should use int8_vectorwise_dequant for int8 params."""

    def test_int8_with_scb_uses_proper_dequant(self):
        """int8 params with SCB should be properly dequantized, not naively cast."""
        # Create a known float weight
        original = torch.randn(4, 4, dtype=torch.float32)
        absmax = original.abs().max(dim=1).values
        int8_w = (original / absmax.unsqueeze(1) * 127).round().clamp(-128, 127).to(torch.int8)

        # Create mock Int8Params
        p = _MockInt8Params(int8_w, SCB=absmax, requires_grad=False)

        result = _dequantize_param_data(p, torch.bfloat16)

        # Should be close to original (within int8 quantization error + bf16 precision)
        assert result.dtype == torch.bfloat16
        diff = torch.abs(result.float() - original).max().item()
        assert diff < 0.1, f"Dequantized weight differs too much: max_diff={diff}"

    def test_int8_without_scb_falls_back(self):
        """int8 params without SCB should fall back to naive cast."""
        p = nn.Parameter(torch.randint(-127, 127, (4, 4), dtype=torch.int8),
                         requires_grad=False)
        result = _dequantize_param_data(p, torch.bfloat16)
        assert result.dtype == torch.bfloat16

    def test_naive_cast_produces_wrong_range(self):
        """Demonstrate that naive .to() produces wrong values for int8."""
        original = torch.randn(4, 4, dtype=torch.float32) * 0.01  # small weights
        absmax = original.abs().max(dim=1).values
        int8_w = (original / absmax.unsqueeze(1) * 127).round().clamp(-128, 127).to(torch.int8)

        # Naive cast: values in [-128, 127] range instead of [-0.01, 0.01]
        naive = int8_w.to(torch.float32)
        assert naive.abs().max().item() > 1.0, "Naive cast should have large values"

        # Proper dequant: values back to [-0.01, 0.01] range
        proper = int8_w.float() * absmax.unsqueeze(1) / 127.0
        assert proper.abs().max().item() < 0.1, "Proper dequant should match original range"


# =========================================================================
# D) Config Validation
# =========================================================================

class TestInt8ConfigValidation:
    """Validator should handle int8 + base_ffn combinations correctly."""

    def _base_cfg(self, **overrides):
        cfg = {
            "backbone": "qwen3",
            "model_name": "Qwen/Qwen3.5-0.8B-Base",
            "device": "cuda:0",
            "injection": {
                "strategy": "moe_expert_lora",
                "num_experts": 4,
                "top_k": 2,
                "lora_r": 8,
                "lora_alpha": 16,
            },
            "model": {"load_precision": {"mode": "int8"}},
            "moe": {
                "router_z_loss_coef": 0.001,
                "load_balance": {"type": "aux_loss", "aux_loss_coef": 0.01},
            },
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["router"]},
                    {"step": 50, "trainable": ["lora", "attn_lora"]},
                ],
            },
        }
        for k, v in overrides.items():
            keys = k.split(".")
            d = cfg
            for part in keys[:-1]:
                d = d.setdefault(part, {})
            d[keys[-1]] = v
        return cfg

    def test_int8_adapter_only_passes(self):
        """int8 without base_ffn unfreeze should pass validation."""
        from eulerforge.utils.validator import validate_config
        cfg = self._base_cfg()
        validate_config(cfg)  # should not raise

    def test_int8_with_dequantize_false_and_base_ffn_warns(self):
        """int8 + dequantize_on_train=false + base_ffn → warning."""
        from eulerforge.utils.validator import validate_config
        cfg = self._base_cfg()
        cfg["model"]["load_precision"]["dequantize_on_train"] = False
        cfg["training"]["phases"].append(
            {"step": 100, "trainable": ["lora", "attn_lora", "base_ffn"],
             "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"]}
        )
        # Should warn but not error
        validate_config(cfg)


# =========================================================================
# E) Integration: set_trainable_by_groups with int8 mock
# =========================================================================

class TestSetTrainableWithInt8:
    """Integration tests for set_trainable_by_groups with int8 modules."""

    def test_set_trainable_router_only_no_replacement(self):
        """Router-only phase should not trigger module replacement."""
        model = _make_mock_int8_model()
        count = set_trainable_by_groups(
            model, active_groups=["router"], mode="replace",
        )
        assert count >= 1
        # int8 modules should remain untouched
        assert isinstance(model.mlp.gate_proj, _MockLinear8bitLt)

    def test_mock_int8_forward_crashes_with_requires_grad(self):
        """Verify our mock correctly simulates the bitsandbytes crash."""
        model = _make_mock_int8_model()
        model.mlp.gate_proj.weight.data = model.mlp.gate_proj.weight.data.float()
        model.mlp.gate_proj.weight.requires_grad = True

        with pytest.raises(RuntimeError, match="floating point or complex"):
            x = torch.randn(2, 16)
            model.mlp.gate_proj(x)

    def test_properly_replaced_module_forward_succeeds(self):
        """After manual replacement, forward should succeed."""
        model = _make_mock_int8_model()
        child = model.mlp.gate_proj
        deq = child.weight.data.float() * child.weight.SCB.float().unsqueeze(1) / 127.0
        new_linear = nn.Linear(child.in_features, child.out_features, bias=False,
                               dtype=torch.float32)
        new_linear.weight.data.copy_(deq)
        new_linear.weight.requires_grad = True
        model.mlp.gate_proj = new_linear

        # Forward should succeed
        x = torch.randn(2, 16)
        out = model.mlp.gate_proj(x)
        assert out.shape == (2, 32)

        # Backward should succeed
        out.sum().backward()
        assert model.mlp.gate_proj.weight.grad is not None


# =========================================================================
# F) Hypothesis Verification
# =========================================================================

class TestHypothesisVerification:
    """Verify the hypotheses from the bug report."""

    def test_hypothesis_1_module_class_unchanged_after_param_cast(self):
        """H1: After param.data.to(bf16), module class is still MockLinear8bitLt."""
        model = _make_mock_int8_model()
        gate = model.mlp.gate_proj

        # Cast param data (what the old code did)
        gate.weight.data = gate.weight.data.float()
        assert isinstance(gate, _MockLinear8bitLt), "Module class should be unchanged"

    def test_hypothesis_2_requires_grad_before_replacement_crashes(self):
        """H2: Setting requires_grad before module replacement causes crash."""
        model = _make_mock_int8_model()
        gate = model.mlp.gate_proj
        gate.weight.data = gate.weight.data.float()
        gate.weight.requires_grad = True

        with pytest.raises(RuntimeError, match="floating point or complex"):
            gate(torch.randn(2, 16))

    def test_hypothesis_3_all_ffn_modules_must_be_replaced(self):
        """H3: Partial replacement (gate only, not up/down) still works for
        the replaced module, but unreplaced ones would crash."""
        model = _make_mock_int8_model()

        # Only replace gate_proj
        child = model.mlp.gate_proj
        deq = child.weight.data.float() * child.weight.SCB.float().unsqueeze(1) / 127.0
        new_linear = nn.Linear(child.in_features, child.out_features, bias=False)
        new_linear.weight.data.copy_(deq)
        new_linear.weight.requires_grad = True
        model.mlp.gate_proj = new_linear

        # gate_proj forward succeeds
        x = torch.randn(2, 16)
        out = model.mlp.gate_proj(x)
        assert out.shape == (2, 32)

        # up_proj would crash if we tried to set requires_grad + forward
        model.mlp.up_proj.weight.data = model.mlp.up_proj.weight.data.float()
        model.mlp.up_proj.weight.requires_grad = True
        with pytest.raises(RuntimeError, match="floating point or complex"):
            model.mlp.up_proj(x)
