# tests/test_cli_convert.py
# -*- coding: utf-8 -*-
"""CLI tests for `eulerforge convert` command."""
from __future__ import annotations

import json
import os
import subprocess
import sys

import pytest

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


def _run_convert(*args: str, timeout: int = 60) -> subprocess.CompletedProcess:
    """Run ``python -m eulerforge.cli.main convert`` with given args."""
    cmd = [sys.executable, "-m", "eulerforge.cli.main", "convert"] + list(args)
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


# =========================================================================
# A) Help
# =========================================================================
class TestConvertHelp:
    def test_help_exits_zero(self):
        result = _run_convert("--help")
        assert result.returncode == 0

    def test_help_shows_required_args(self):
        result = _run_convert("--help")
        out = result.stdout.lower()
        assert "--task" in out
        assert "--input" in out
        assert "--output" in out

    def test_help_shows_recipe(self):
        result = _run_convert("--help")
        assert "--recipe" in result.stdout.lower()


# =========================================================================
# B) Bad arguments
# =========================================================================
class TestConvertBadArgs:
    def test_missing_task_exits_nonzero(self):
        result = _run_convert("--input", "x.jsonl", "--output", "y.jsonl",
                              "--recipe", "sft_messages_v1")
        assert result.returncode != 0

    def test_nonexistent_input_exits_1(self):
        result = _run_convert(
            "--task", "sft",
            "--input", "/nonexistent_path_abc123.jsonl",
            "--output", "/tmp/test_convert_out.jsonl",
            "--recipe", "sft_messages_v1",
        )
        assert result.returncode == 1
        # 3-line error format
        lines = [l for l in result.stderr.strip().split("\n") if l.strip()]
        assert any("Convert:" in l for l in lines)
        assert any("Fix:" in l for l in lines)
        assert any("See:" in l for l in lines)

    def test_no_recipe_no_mapping_exits_1(self):
        inp = os.path.join(FIXTURES, "nested_sft_messages_tiny.jsonl")
        result = _run_convert(
            "--task", "sft",
            "--input", inp,
            "--output", "/tmp/test_convert_out.jsonl",
        )
        assert result.returncode == 1
        lines = [l for l in result.stderr.strip().split("\n") if l.strip()]
        assert any("Convert:" in l for l in lines)

    def test_output_exists_without_overwrite_exits_1(self, tmp_path):
        inp = os.path.join(FIXTURES, "nested_sft_messages_tiny.jsonl")
        out = str(tmp_path / "existing.jsonl")
        with open(out, "w") as f:
            f.write("{}\n")

        result = _run_convert(
            "--task", "sft",
            "--input", inp,
            "--output", out,
            "--recipe", "sft_messages_v1",
        )
        assert result.returncode == 1
        lines = [l for l in result.stderr.strip().split("\n") if l.strip()]
        assert any("Convert:" in l for l in lines)


# =========================================================================
# C) Recipe mode
# =========================================================================
class TestConvertRecipeMode:
    def test_sft_messages_v1(self, tmp_path):
        inp = os.path.join(FIXTURES, "nested_sft_messages_tiny.jsonl")
        out = str(tmp_path / "out.jsonl")
        result = _run_convert(
            "--task", "sft",
            "--input", inp,
            "--output", out,
            "--recipe", "sft_messages_v1",
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"
        with open(out) as f:
            rows = [json.loads(l) for l in f if l.strip()]
        assert len(rows) == 4
        assert all("prompt" in r and "response" in r for r in rows)

    def test_dpo_nested_v1(self, tmp_path):
        inp = os.path.join(FIXTURES, "nested_dpo_tiny_convert.jsonl")
        out = str(tmp_path / "out.jsonl")
        result = _run_convert(
            "--task", "prompted_preference",
            "--input", inp,
            "--output", out,
            "--recipe", "dpo_nested_v1",
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"
        with open(out) as f:
            rows = [json.loads(l) for l in f if l.strip()]
        assert len(rows) == 4
        assert all("prompt" in r and "chosen" in r and "rejected" in r
                    for r in rows)


# =========================================================================
# D) Mapping mode (updated: --map replaces --prompt-path etc.)
# =========================================================================
class TestConvertMappingMode:
    def test_dot_path_dpo(self, tmp_path):
        inp = os.path.join(FIXTURES, "nested_dpo_tiny_convert.jsonl")
        out = str(tmp_path / "out.jsonl")
        result = _run_convert(
            "--task", "prompted_preference",
            "--input", inp,
            "--output", out,
            "--map", "prompt=instruction.value",
            "--map", "chosen=chosen.value",
            "--map", "rejected=rejected.value",
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"
        with open(out) as f:
            rows = [json.loads(l) for l in f if l.strip()]
        assert len(rows) == 4
        assert all("prompt" in r and "chosen" in r and "rejected" in r
                    for r in rows)

    def test_messages_path_sft(self, tmp_path):
        inp = os.path.join(FIXTURES, "nested_sft_messages_tiny.jsonl")
        out = str(tmp_path / "out.jsonl")
        result = _run_convert(
            "--task", "sft",
            "--input", inp,
            "--output", out,
            "--recipe", "sft_messages",
            "--messages-expr", "json_record.messages",
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"
        with open(out) as f:
            rows = [json.loads(l) for l in f if l.strip()]
        assert len(rows) == 4
        assert all("prompt" in r and "response" in r for r in rows)


# =========================================================================
# D-2) --map mode (new)
# =========================================================================
class TestConvertMapMode:
    def test_map_sft_flat_fields(self, tmp_path):
        inp = os.path.join(FIXTURES, "flat_instruction_output_tiny.jsonl")
        out = str(tmp_path / "out.jsonl")
        result = _run_convert(
            "--task", "sft",
            "--input", inp,
            "--output", out,
            "--map", "prompt=instruction",
            "--map", "response=output",
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"
        with open(out) as f:
            rows = [json.loads(l) for l in f if l.strip()]
        assert len(rows) == 4
        assert all("prompt" in r and "response" in r for r in rows)

    def test_map_nested_dpo_flatten_dot(self, tmp_path):
        inp = os.path.join(FIXTURES, "nested_dpo_tiny_convert.jsonl")
        out = str(tmp_path / "out.jsonl")
        result = _run_convert(
            "--task", "prompted_preference",
            "--input", inp,
            "--output", out,
            "--map", "prompt=instruction.value",
            "--map", "chosen=chosen.value",
            "--map", "rejected=rejected.value",
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"
        with open(out) as f:
            rows = [json.loads(l) for l in f if l.strip()]
        assert len(rows) == 4
        assert all("prompt" in r and "chosen" in r and "rejected" in r for r in rows)

    def test_map_malformed_exits_1(self, tmp_path):
        inp = os.path.join(FIXTURES, "flat_instruction_output_tiny.jsonl")
        out = str(tmp_path / "out.jsonl")
        result = _run_convert(
            "--task", "sft",
            "--input", inp,
            "--output", out,
            "--map", "prompt_only_no_eq",
        )
        assert result.returncode == 1
        assert "Convert:" in result.stderr


# =========================================================================
# D-3) --validate mode (new)
# =========================================================================
class TestConvertValidateMode:
    def test_validate_only_valid_file(self):
        inp = os.path.join(FIXTURES, "raw_sft_prompt_response_tiny.jsonl")
        result = _run_convert(
            "--task", "sft",
            "--input", inp,
            "--validate",
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"

    def test_validate_only_invalid_file(self):
        # nested_sft_messages_tiny is NOT in raw sft format (has json_record.messages)
        inp = os.path.join(FIXTURES, "nested_sft_messages_tiny.jsonl")
        result = _run_convert(
            "--task", "sft",
            "--input", inp,
            "--validate",
        )
        assert result.returncode == 1


# =========================================================================
# E) Options
# =========================================================================
class TestConvertOptions:
    def test_overwrite_replaces_existing(self, tmp_path):
        inp = os.path.join(FIXTURES, "nested_sft_messages_tiny.jsonl")
        out = str(tmp_path / "existing.jsonl")
        with open(out, "w") as f:
            f.write("{}\n")

        result = _run_convert(
            "--task", "sft",
            "--input", inp,
            "--output", out,
            "--recipe", "sft_messages_v1",
            "--overwrite",
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"
        with open(out) as f:
            rows = [json.loads(l) for l in f if l.strip()]
        assert len(rows) == 4
