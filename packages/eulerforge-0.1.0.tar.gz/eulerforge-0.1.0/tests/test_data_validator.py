# tests/test_data_validator.py
# -*- coding: utf-8 -*-
"""Unit tests for data validation — processed/raw schema + config data section."""
from __future__ import annotations

import json
import os
import tempfile

import pytest

from eulerforge.utils.data_validator import (
    validate_processed_data,
    validate_raw_data,
)
from eulerforge.utils.validator import ConfigValidationError, validate_config


FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _write_jsonl(path: str, rows: list[dict]) -> str:
    with open(path, "w") as f:
        for row in rows:
            f.write(json.dumps(row) + "\n")
    return path


def _base_cfg(**overrides):
    """Minimal valid config."""
    cfg = {
        "backbone": "qwen3",
        "model_name": "Qwen/Qwen3.5-0.8B-Base",
        "injection": {"strategy": "dense_lora"},
        "training": {
            "phases": [{"step": 0, "trainable": ["lora"]}],
        },
    }
    for k, v in overrides.items():
        keys = k.split(".")
        d = cfg
        for part in keys[:-1]:
            d = d.setdefault(part, {})
        d[keys[-1]] = v
    return cfg


# =========================================================================
# A) Processed data validation
# =========================================================================
class TestProcessedDataValidation:
    """validate_processed_data — checks first N rows for required keys."""

    def test_sft_missing_input_ids(self, tmp_path):
        p = _write_jsonl(str(tmp_path / "bad.jsonl"), [{"labels": [1, 2, 3]}])
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_processed_data(p, "sft")
        e = exc_info.value
        assert e.category
        assert e.fix
        assert e.doc
        assert "input_ids" in str(e)

    def test_dpo_missing_chosen_input_ids(self, tmp_path):
        p = _write_jsonl(str(tmp_path / "bad.jsonl"), [
            {"rejected_input_ids": [1], "chosen_labels": [1], "rejected_labels": [1]}
        ])
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_processed_data(p, "dpo")
        assert "chosen_input_ids" in str(exc_info.value)

    def test_dpo_missing_rejected_labels(self, tmp_path):
        p = _write_jsonl(str(tmp_path / "bad.jsonl"), [
            {"chosen_input_ids": [1], "rejected_input_ids": [1], "chosen_labels": [1]}
        ])
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_processed_data(p, "dpo")
        assert "rejected_labels" in str(exc_info.value)

    def test_ppo_missing_input_ids(self, tmp_path):
        p = _write_jsonl(str(tmp_path / "bad.jsonl"), [{"attention_mask": [1]}])
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_processed_data(p, "ppo")
        assert "input_ids" in str(exc_info.value)

    def test_valid_sft_passes(self, tmp_path):
        p = _write_jsonl(str(tmp_path / "ok.jsonl"), [
            {"input_ids": [1, 2, 3], "attention_mask": [1, 1, 1], "labels": [1, 2, 3]}
        ])
        validate_processed_data(p, "sft")  # should not raise

    def test_checks_first_n_rows(self, tmp_path):
        """Row 0 is fine, row 1 is bad -> should catch it."""
        rows = [
            {"input_ids": [1, 2], "labels": [1, 2], "attention_mask": [1, 1]},
            {"labels": [1, 2]},  # missing input_ids
        ]
        p = _write_jsonl(str(tmp_path / "partial.jsonl"), rows)
        with pytest.raises(ConfigValidationError):
            validate_processed_data(p, "sft", n=5)

    def test_empty_file_raises(self, tmp_path):
        p = _write_jsonl(str(tmp_path / "empty.jsonl"), [])
        with pytest.raises(ConfigValidationError, match="(?i)empty"):
            validate_processed_data(p, "sft")


# =========================================================================
# B) Raw data validation
# =========================================================================
class TestRawDataValidation:
    """validate_raw_data — checks schema columns exist in first N rows."""

    def test_sft_text_col_missing(self, tmp_path):
        p = _write_jsonl(str(tmp_path / "bad.jsonl"), [{"content": "hello"}])
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_raw_data(p, "sft", {"text_col": "text"})
        assert "text" in str(exc_info.value)
        assert exc_info.value.fix

    def test_preference_chosen_col_missing(self, tmp_path):
        p = _write_jsonl(str(tmp_path / "bad.jsonl"), [{"rejected": "bad"}])
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_raw_data(p, "preference", {"chosen_col": "chosen"})
        assert "chosen" in str(exc_info.value)

    def test_prompted_pref_prompt_col_missing(self, tmp_path):
        p = _write_jsonl(str(tmp_path / "bad.jsonl"), [
            {"chosen": "good", "rejected": "bad"}
        ])
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_raw_data(p, "prompted_preference", {"prompt_col": "prompt"})
        assert "prompt" in str(exc_info.value)


# =========================================================================
# C) Config data section validation
# =========================================================================
class TestDataConfigValidation:
    """_validate_data_section in validate_config."""

    def test_unknown_format_raises(self):
        cfg = _base_cfg()
        cfg["data"] = {"format": "csv", "path": "/tmp/test.csv"}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        assert "format" in str(exc_info.value).lower()
        assert exc_info.value.fix

    def test_raw_format_missing_task_raises(self):
        cfg = _base_cfg()
        cfg["data"] = {"format": "raw", "path": "/tmp/test.jsonl"}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        assert "task" in str(exc_info.value).lower()

    def test_missing_path_raises(self):
        cfg = _base_cfg()
        cfg["data"] = {"format": "processed"}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        assert "path" in str(exc_info.value).lower()

    def test_valid_data_section_passes(self):
        cfg = _base_cfg()
        cfg["data"] = {
            "format": "processed",
            "path": "/tmp/test.jsonl",
        }
        validate_config(cfg)  # should not raise


# =========================================================================
# D) data.task vs training.type compatibility
# =========================================================================
class TestDataTaskTrainingTypeCompat:
    """Catch mismatch between data.task and training.type early."""

    def test_sft_task_with_dpo_type_raises(self):
        """data.task=sft + training.type=dpo → error."""
        cfg = _base_cfg(**{"training.type": "dpo"})
        cfg["data"] = {"format": "raw", "path": "/tmp/test.jsonl", "task": "sft"}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        err = str(exc_info.value)
        assert "task" in err.lower()
        assert "training.type" in err or "training type" in err.lower()
        assert exc_info.value.fix
        assert "training.type" in exc_info.value.fix

    def test_sft_task_with_orpo_type_raises(self):
        """data.task=sft + training.type=orpo → error."""
        cfg = _base_cfg(**{"training.type": "orpo", "training.orpo_lambda": 1.0})
        cfg["data"] = {"format": "raw", "path": "/tmp/test.jsonl", "task": "sft"}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        assert "task" in str(exc_info.value).lower()

    def test_sft_task_with_rm_type_raises(self):
        """data.task=sft + training.type=rm → error."""
        cfg = _base_cfg(**{"training.type": "rm"})
        cfg["data"] = {"format": "raw", "path": "/tmp/test.jsonl", "task": "sft"}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        assert "task" in str(exc_info.value).lower()

    def test_preference_task_with_sft_type_raises(self):
        """data.task=preference + training.type=sft → error."""
        cfg = _base_cfg(**{"training.type": "sft"})
        cfg["data"] = {"format": "raw", "path": "/tmp/test.jsonl", "task": "preference"}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        assert "task" in str(exc_info.value).lower()

    def test_prompted_preference_task_with_ppo_type_raises(self):
        """data.task=prompted_preference + training.type=ppo → error."""
        cfg = _base_cfg(**{
            "training.type": "ppo",
            "training.ppo.clip_range": 0.2,
            "training.ppo.kl_coef": 0.1,
            "training.ppo.epochs": 4,
            "training.reward_model.model_name": "path/to/rm",
        })
        cfg["data"] = {"format": "raw", "path": "/tmp/test.jsonl", "task": "prompted_preference"}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        assert "task" in str(exc_info.value).lower()

    def test_sft_task_with_sft_type_passes(self):
        """data.task=sft + training.type=sft → OK."""
        cfg = _base_cfg(**{"training.type": "sft"})
        cfg["data"] = {"format": "raw", "path": "/tmp/test.jsonl", "task": "sft"}
        validate_config(cfg)  # should not raise

    def test_sft_task_with_ppo_type_passes(self):
        """data.task=sft + training.type=ppo → OK."""
        cfg = _base_cfg(**{
            "training.type": "ppo",
            "training.ppo.clip_range": 0.2,
            "training.ppo.kl_coef": 0.1,
            "training.ppo.epochs": 4,
            "training.reward_model.model_name": "path/to/rm",
        })
        cfg["data"] = {"format": "raw", "path": "/tmp/test.jsonl", "task": "sft"}
        validate_config(cfg)  # should not raise

    def test_preference_task_with_dpo_type_passes(self):
        """data.task=preference + training.type=dpo → OK."""
        cfg = _base_cfg(**{"training.type": "dpo"})
        cfg["data"] = {"format": "raw", "path": "/tmp/test.jsonl", "task": "preference"}
        validate_config(cfg)  # should not raise

    def test_preference_task_with_orpo_type_passes(self):
        """data.task=preference + training.type=orpo → OK."""
        cfg = _base_cfg(**{"training.type": "orpo", "training.orpo_lambda": 1.0})
        cfg["data"] = {"format": "raw", "path": "/tmp/test.jsonl", "task": "preference"}
        validate_config(cfg)  # should not raise

    def test_prompted_preference_with_rm_type_passes(self):
        """data.task=prompted_preference + training.type=rm → OK."""
        cfg = _base_cfg(**{"training.type": "rm"})
        cfg["data"] = {"format": "raw", "path": "/tmp/test.jsonl", "task": "prompted_preference"}
        validate_config(cfg)  # should not raise

    def test_no_data_section_skips_check(self):
        """No data section → no mismatch check."""
        cfg = _base_cfg(**{"training.type": "dpo"})
        validate_config(cfg)  # should not raise

    def test_processed_format_skips_check(self):
        """data.format=processed → no task, so no mismatch check."""
        cfg = _base_cfg(**{"training.type": "dpo"})
        cfg["data"] = {"format": "processed", "path": "/tmp/test.jsonl"}
        validate_config(cfg)  # should not raise
