# tests/test_package_version.py
# -*- coding: utf-8 -*-
"""
eulerforge 패키지 __version__ 속성 검증.

Why: pip install -e . 또는 정식 설치 후 `eulerforge.__version__` 접근이
표준 Python 관행. pyproject.toml의 version을 직접 import 경로에 노출하여
사용자가 프로그래매틱하게 버전을 확인할 수 있어야 함.
"""
from __future__ import annotations

import re

import eulerforge


class TestPackageVersion:
    def test_version_attribute_exists(self):
        """eulerforge.__version__ 속성이 존재해야 한다."""
        assert hasattr(eulerforge, "__version__"), (
            "eulerforge.__version__ must be exposed (see eulerforge/__init__.py)"
        )

    def test_version_is_string(self):
        """__version__은 문자열이어야 한다."""
        assert isinstance(eulerforge.__version__, str)

    def test_version_semver_like(self):
        """__version__은 최소한 'MAJOR.MINOR' 형태의 semver-like 문자열이어야 한다.

        정확한 값은 pyproject.toml과 동기화되므로 여기서는 형식만 검증.
        """
        assert re.match(r"^\d+\.\d+(\.\d+)?([\.\-\+].*)?$", eulerforge.__version__), (
            f"Unexpected version format: {eulerforge.__version__!r}"
        )

    def test_version_matches_pyproject(self):
        """__version__이 pyproject.toml의 [project].version과 일치해야 한다.

        importlib.metadata는 설치된 distribution의 버전을 읽으므로, editable
        install(`pip install -e .`) 환경에서도 pyproject.toml의 값이 나와야 함.
        """
        import tomllib
        import pathlib

        pyproject_path = pathlib.Path(__file__).parent.parent / "pyproject.toml"
        with pyproject_path.open("rb") as f:
            pyproject = tomllib.load(f)

        expected = pyproject["project"]["version"]
        assert eulerforge.__version__ == expected, (
            f"__version__={eulerforge.__version__!r} != pyproject.toml version={expected!r}"
        )
