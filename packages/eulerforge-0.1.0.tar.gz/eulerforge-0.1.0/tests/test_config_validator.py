# tests/test_config_validator_advanced.py
import pytest
from eulerforge.utils.validator import validate_config, ConfigValidationError

# ============================================================================
# 1. 기본 구조 검증 (Missing Sections)
# ============================================================================
@pytest.mark.parametrize("missing_section", ["backbone", "injection", "training"])
def test_missing_top_level_sections(missing_section):
    """필수 섹션이 하나라도 빠지면 에러"""
    cfg = {
        "backbone": "qwen",
        "injection": {"strategy": "dense_lora"},
        "training": {}
    }
    del cfg[missing_section]
    
    with pytest.raises(ConfigValidationError, match=f"Missing required top-level section: '{missing_section}'"):
        validate_config(cfg)

# ============================================================================
# 2. 전략(Strategy) 이름 검증
# ============================================================================
def test_unknown_strategy():
    cfg = {
        "backbone": "qwen",
        "injection": {"strategy": "super_fancy_moe"}, # 없는 전략
        "training": {}
    }
    with pytest.raises(ConfigValidationError, match="Unknown strategy"):
        validate_config(cfg)


@pytest.mark.parametrize("old_name", ["plain_lora", "lora_moe", "ffn_moe_expert_lora"])
def test_old_strategy_names_are_rejected(old_name):
    """구 전략 이름(plain_lora, lora_moe, ffn_moe_expert_lora)은 더 이상 허용되지 않는다."""
    cfg = {
        "backbone": "qwen",
        "injection": {"strategy": old_name},
        "training": {}
    }
    with pytest.raises(ConfigValidationError, match="Unknown strategy"):
        validate_config(cfg)

def test_missing_strategy_key():
    cfg = {
        "backbone": "qwen",
        "injection": {"lora_r": 16}, # strategy 키 없음
        "training": {}
    }
    with pytest.raises(ConfigValidationError, match="injection.strategy is required"):
        validate_config(cfg)

# ============================================================================
# 3. 전략별 필수 파라미터 누락 검증
# ============================================================================
def test_native_moe_requires_target_keywords():
    """Native MoE는 target_keywords가 필수"""
    cfg = {
        "backbone": "mixtral",
        "injection": {
            "strategy": "native_moe_expert_lora",
            # target_keywords 없음
        },
        "training": {}
    }
    with pytest.raises(ConfigValidationError, match="requires 'target_keywords'"):
        validate_config(cfg)

def test_native_moe_deprecates_ffn_keywords():
    """구버전 키워드 ffn_keywords 사용 시 에러"""
    cfg = {
        "backbone": "mixtral",
        "injection": {
            "strategy": "native_moe_expert_lora",
            "ffn_keywords": ["w1", "w2"] # Wrong key
        },
        "training": {}
    }
    with pytest.raises(ConfigValidationError, match="Found deprecated 'ffn_keywords'"):
        validate_config(cfg)

@pytest.mark.parametrize("strategy", ["mixture_lora", "moe_expert_lora"])
@pytest.mark.parametrize("missing_key", ["num_experts", "top_k"])
def test_moe_construction_missing_params(strategy, missing_key):
    """MoE 생성 전략들은 num_experts와 top_k가 필수"""
    inj_cfg = {
        "strategy": strategy,
        "num_experts": 4,
        "top_k": 2
    }
    del inj_cfg[missing_key]
    
    cfg = {
        "backbone": "qwen",
        "injection": inj_cfg,
        "training": {}
    }
    with pytest.raises(ConfigValidationError, match=f"requires '{missing_key}'"):
        validate_config(cfg)

# ============================================================================
# 4. 논리적 오류 검증 (Logic Check)
# ============================================================================
def test_top_k_greater_than_experts():
    """Top-K가 전문가 수보다 크면 에러"""
    cfg = {
        "backbone": "qwen",
        "injection": {
            "strategy": "mixture_lora",
            "num_experts": 4,
            "top_k": 5  # Error!
        },
        "training": {}
    }
    with pytest.raises(ConfigValidationError, match="cannot be larger than num_experts"):
        validate_config(cfg)

def test_negative_lora_rank():
    """LoRA Rank가 음수면 에러"""
    cfg = {
        "backbone": "qwen",
        "injection": {
            "strategy": "dense_lora",
            "lora_r": -1 # Error!
        },
        "training": {}
    }
    with pytest.raises(ConfigValidationError, match="cannot be negative"):
        validate_config(cfg)

def test_invalid_type_params():
    """숫자가 들어와야 하는데 문자열 등이 들어온 경우"""
    cfg = {
        "backbone": "qwen",
        "injection": {
            "strategy": "mixture_lora",
            "num_experts": "four", # Error
            "top_k": 2
        },
        "training": {}
    }
    with pytest.raises(ConfigValidationError, match="must be integers"):
        validate_config(cfg)

# ============================================================================
# 5. 정상 케이스 (Sanity Check)
# ============================================================================
VALID_CASES = [
    # Case 1: Plain LoRA
    {
        "backbone": "qwen",
        "injection": {"strategy": "dense_lora", "lora_r": 16},
        "training": {}
    },
    # Case 2: Native MoE (Correct)
    {
        "backbone": "mixtral",
        "injection": {
            "strategy": "native_moe_expert_lora", 
            "target_keywords": ["w1", "w2"]
        },
        "training": {}
    },
    # Case 3: LoRA MoE (Correct Logic)
    {
        "backbone": "llama",
        "injection": {
            "strategy": "mixture_lora",
            "num_experts": 8,
            "top_k": 2
        },
        "training": {},
        "moe": {
            "router_z_loss_coef": 0.001,
            "load_balance": {"type": "aux_loss", "aux_loss_coef": 0.01},
        },
    }
]

@pytest.mark.parametrize("cfg", VALID_CASES)
def test_valid_configs_pass(cfg):
    """정상적인 Config는 에러 없이 통과해야 함"""
    try:
        validate_config(cfg)
    except ConfigValidationError as e:
        pytest.fail(f"Valid config raised ValidationError: {e}")


# ============================================================================
# 6. 3줄 에러 포맷 (Structured Error Format)
# ============================================================================
def test_structured_error_three_line_format():
    """category/fix/doc가 모두 있으면 3줄 포맷 출력"""
    err = ConfigValidationError(
        "orpo_lambda is required",
        category="Training Config",
        fix="Add 'orpo_lambda: 1.0' under training section",
        doc="docs/tutorials/06_orpo_training.md",
    )
    text = str(err)
    assert "Training Config: orpo_lambda is required" in text
    assert "Fix: Add 'orpo_lambda: 1.0' under training section" in text
    assert "See: docs/tutorials/06_orpo_training.md" in text


def test_structured_error_backward_compat():
    """category/fix/doc가 없으면 기존 단일 메시지 그대로"""
    err = ConfigValidationError("injection.strategy is required")
    assert str(err) == "injection.strategy is required"


def test_structured_error_partial_fields():
    """일부 필드만 있으면 단일 메시지 폴백"""
    err = ConfigValidationError("something wrong", category="X")
    assert str(err) == "something wrong"


# ============================================================================
# 7. training.type 검증
# ============================================================================
def test_unknown_training_type():
    """지원하지 않는 training.type은 에러"""
    cfg = {
        "backbone": "qwen",
        "injection": {"strategy": "dense_lora"},
        "training": {"type": "grpo"},
    }
    with pytest.raises(ConfigValidationError, match="Unknown training type 'grpo'"):
        validate_config(cfg)


@pytest.mark.parametrize("valid_type", ["sft", "dpo", "orpo", "rm", "ppo"])
def test_valid_training_types_pass(valid_type):
    """유효한 training.type은 통과"""
    cfg = {
        "backbone": "qwen",
        "injection": {"strategy": "dense_lora"},
        "training": {"type": valid_type},
    }
    # Should not raise for training.type validation
    # (may raise for type-specific params later, that's fine)
    try:
        validate_config(cfg)
    except ConfigValidationError as e:
        # training.type itself should pass; other errors are OK
        assert "Unknown training type" not in str(e)


def test_training_type_case_insensitive():
    """training.type은 대소문자 무관"""
    cfg = {
        "backbone": "qwen",
        "injection": {"strategy": "dense_lora"},
        "training": {"type": "SFT"},
    }
    try:
        validate_config(cfg)
    except ConfigValidationError as e:
        assert "Unknown training type" not in str(e)


def test_training_type_default_sft():
    """training.type 미지정 시 sft로 기본값"""
    cfg = {
        "backbone": "qwen",
        "injection": {"strategy": "dense_lora"},
        "training": {},
    }
    validate_config(cfg)  # should pass without error


# ============================================================================
# 8. ORPO 파라미터 검증
# ============================================================================
def test_orpo_requires_orpo_lambda():
    """ORPO에서 orpo_lambda 누락 시 에러"""
    cfg = {
        "backbone": "qwen",
        "injection": {"strategy": "dense_lora"},
        "training": {"type": "orpo"},  # orpo_lambda 없음
    }
    with pytest.raises(ConfigValidationError, match="orpo_lambda"):
        validate_config(cfg)


def test_orpo_lambda_must_be_positive():
    """orpo_lambda는 양수여야 함"""
    cfg = {
        "backbone": "qwen",
        "injection": {"strategy": "dense_lora"},
        "training": {"type": "orpo", "orpo_lambda": -1.0},
    }
    with pytest.raises(ConfigValidationError, match="orpo_lambda"):
        validate_config(cfg)


def test_orpo_valid_config():
    """유효한 ORPO 설정은 통과"""
    cfg = {
        "backbone": "qwen",
        "injection": {"strategy": "dense_lora"},
        "training": {"type": "orpo", "orpo_lambda": 1.0},
    }
    validate_config(cfg)


# ============================================================================
# 9. logging 섹션 검증 (Logging Config Validation)
# ============================================================================

class TestLoggingConfigValidation:
    """logging.metrics_level and logging.tensorboard validation."""

    _BASE_CFG = {
        "backbone": "qwen",
        "injection": {"strategy": "dense_lora"},
        "training": {},
    }

    def test_valid_minimal(self):
        """logging.metrics_level=minimal passes."""
        cfg = {**self._BASE_CFG, "logging": {"metrics_level": "minimal"}}
        validate_config(cfg)

    def test_valid_advanced(self):
        """logging.metrics_level=advanced passes."""
        cfg = {**self._BASE_CFG, "logging": {"metrics_level": "advanced"}}
        validate_config(cfg)

    def test_invalid_level(self):
        """logging.metrics_level=invalid raises ConfigValidationError."""
        cfg = {**self._BASE_CFG, "logging": {"metrics_level": "invalid"}}
        with pytest.raises(ConfigValidationError, match="Unknown metrics_level"):
            validate_config(cfg)

    def test_tensorboard_enabled(self):
        """logging.tensorboard.enabled=true passes."""
        cfg = {
            **self._BASE_CFG,
            "logging": {"tensorboard": {"enabled": True}},
        }
        validate_config(cfg)

    def test_tensorboard_bad_type(self):
        """logging.tensorboard.enabled='yes' (string) raises error."""
        cfg = {
            **self._BASE_CFG,
            "logging": {"tensorboard": {"enabled": "yes"}},
        }
        with pytest.raises(ConfigValidationError, match="tensorboard.enabled"):
            validate_config(cfg)