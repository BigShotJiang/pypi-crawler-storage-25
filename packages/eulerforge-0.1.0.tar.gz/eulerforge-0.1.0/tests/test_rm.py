# tests/test_rm.py
"""Reward Model (RM) 단위 테스트."""
import pytest
import torch
import torch.nn as nn
from unittest.mock import MagicMock

from eulerforge.cli.train import RewardHead, rm_loss_fn, run_training_step


class TestRewardHead:
    """RewardHead 단위 테스트."""

    def test_output_shape(self):
        """출력이 (B,) 형태여야 함"""
        head = RewardHead(hidden_size=64)
        hidden = torch.randn(3, 10, 64)
        mask = torch.ones(3, 10, dtype=torch.long)
        rewards = head(hidden, mask)
        assert rewards.shape == (3,)

    def test_uses_last_token(self):
        """패딩이 있을 때 마지막 실제 토큰을 사용"""
        head = RewardHead(hidden_size=4)
        # Batch of 2, seq_len 5
        hidden = torch.zeros(2, 5, 4)
        # Sequence 0: last real token at index 2, Sequence 1: at index 4
        hidden[0, 2, :] = 1.0  # This should be picked
        hidden[1, 4, :] = 2.0  # This should be picked
        mask = torch.tensor([
            [1, 1, 1, 0, 0],  # length 3
            [1, 1, 1, 1, 1],  # length 5
        ])
        rewards = head(hidden, mask)
        assert rewards.shape == (2,)
        # Verify different values (proving correct indexing)
        assert rewards[0].item() != rewards[1].item()

    def test_single_token(self):
        """길이 1인 시퀀스에서 동작"""
        head = RewardHead(hidden_size=8)
        hidden = torch.randn(1, 1, 8)
        mask = torch.ones(1, 1, dtype=torch.long)
        rewards = head(hidden, mask)
        assert rewards.shape == (1,)
        assert torch.isfinite(rewards).all()


class TestRmLossFn:
    """rm_loss_fn 단위 테스트."""

    def test_basic_finite_loss(self):
        """기본 입력에서 유한한 loss 반환"""
        r_chosen = torch.tensor([1.0, 0.5])
        r_rejected = torch.tensor([-0.5, -1.0])
        loss, metrics = rm_loss_fn(r_chosen, r_rejected)
        assert torch.isfinite(loss)
        assert "rm_loss" in metrics
        assert "accuracy" in metrics

    def test_chosen_higher_means_lower_loss(self):
        """chosen > rejected가 확실할수록 loss가 낮아야 함"""
        r_chosen_strong = torch.tensor([5.0, 5.0])
        r_rejected_strong = torch.tensor([-5.0, -5.0])
        loss_easy, _ = rm_loss_fn(r_chosen_strong, r_rejected_strong)

        r_chosen_close = torch.tensor([0.1, 0.1])
        r_rejected_close = torch.tensor([-0.1, -0.1])
        loss_hard, _ = rm_loss_fn(r_chosen_close, r_rejected_close)

        assert loss_easy < loss_hard

    def test_equal_rewards(self):
        """같은 보상일 때 loss = log(2)"""
        r = torch.tensor([1.0, 1.0])
        loss, metrics = rm_loss_fn(r, r)
        assert torch.isfinite(loss)
        assert abs(loss.item() - 0.6931) < 0.01  # log(2) ≈ 0.693

    def test_accuracy_metric(self):
        """accuracy가 올바르게 계산"""
        r_chosen = torch.tensor([2.0, 1.0, 0.5])
        r_rejected = torch.tensor([1.0, 2.0, -1.0])
        _, metrics = rm_loss_fn(r_chosen, r_rejected)
        # 2 of 3 pairs have chosen > rejected
        assert abs(metrics["accuracy"] - 2.0 / 3.0) < 0.01


class TestRmTrainingStep:
    """run_training_step(type="rm") 테스트."""

    def test_rm_step_requires_reward_head(self):
        """reward_head 없이 RM step하면 ValueError"""
        model = MagicMock()
        batch = {
            "input_ids": torch.randint(0, 100, (4, 32)),
            "attention_mask": torch.ones(4, 32, dtype=torch.long),
            "labels": torch.randint(0, 100, (4, 32)),
        }
        with pytest.raises(ValueError, match="reward_head"):
            run_training_step(batch, model, "rm", torch.device("cpu"), use_amp=False)

    def test_rm_step_returns_loss_and_metrics(self):
        """RM step이 loss와 metrics 반환"""
        B, L, V, H = 4, 32, 100, 64
        model = MagicMock()
        hidden = torch.randn(B, L, H)
        mock_output = MagicMock()
        mock_output.hidden_states = [hidden]  # list of layers
        model.return_value = mock_output

        reward_head = RewardHead(H)

        batch = {
            "input_ids": torch.randint(0, 100, (B, L)),
            "attention_mask": torch.ones(B, L, dtype=torch.long),
            "labels": torch.randint(0, 100, (B, L)),
        }
        loss, metrics = run_training_step(
            batch, model, "rm", torch.device("cpu"), use_amp=False,
            reward_head=reward_head,
        )
        assert torch.isfinite(loss)
        assert "rm_loss" in metrics
        assert "accuracy" in metrics
