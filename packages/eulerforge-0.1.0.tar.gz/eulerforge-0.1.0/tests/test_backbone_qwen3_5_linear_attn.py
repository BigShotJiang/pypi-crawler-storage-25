# tests/test_backbone_qwen3_5_linear_attn.py
# -*- coding: utf-8 -*-
"""
Qwen3.5 linear_attn (Qwen3_5GatedDeltaNet) 호환성 테스트.

Transformers 5.5에서 Qwen3.5는 linear attention (Qwen3_5GatedDeltaNet)을 사용한다.
모듈 구조가 기존 self_attn (q_proj, k_proj, v_proj, o_proj)에서
linear_attn (in_proj_qkv, in_proj_z, in_proj_b, in_proj_a, out_proj)로 변경됨.

Qwen3Adapter가 두 구조를 모두 인식하고, q_proj/v_proj 같은 표준 키워드를
linear_attn 모듈에서도 의미 있는 projection (in_proj_qkv, out_proj)으로
auto-fallback해야 한다.

또한 Qwen3.5 config는 vocab_size/hidden_size가 text_config 아래로 nested됨.
"""
from __future__ import annotations

import pytest
import torch
import torch.nn as nn


# ─────────────────────────────────────────────────────────────────────────────
# Mock Qwen3.5 linear_attn block (실 모델 로드 없이 구조만 재현)
# ─────────────────────────────────────────────────────────────────────────────


class _MockGatedDeltaNet(nn.Module):
    """Qwen3_5GatedDeltaNet 구조를 모방."""
    def __init__(self, hidden=64):
        super().__init__()
        self.act = nn.SiLU()
        self.conv1d = nn.Conv1d(hidden, hidden, 4)
        self.norm = nn.LayerNorm(hidden)
        self.out_proj = nn.Linear(hidden, hidden, bias=False)
        self.in_proj_qkv = nn.Linear(hidden, hidden * 3, bias=False)
        self.in_proj_z = nn.Linear(hidden, hidden, bias=False)
        self.in_proj_b = nn.Linear(hidden, hidden, bias=False)
        self.in_proj_a = nn.Linear(hidden, hidden, bias=False)


class _MockMLP(nn.Module):
    def __init__(self, hidden=64, intermediate=128):
        super().__init__()
        self.gate_proj = nn.Linear(hidden, intermediate, bias=False)
        self.up_proj = nn.Linear(hidden, intermediate, bias=False)
        self.down_proj = nn.Linear(intermediate, hidden, bias=False)
        self.act_fn = nn.SiLU()


class _MockQwen35Block(nn.Module):
    """Qwen3_5DecoderLayer 구조 모방: linear_attn (NOT self_attn) + mlp."""
    def __init__(self, hidden=64):
        super().__init__()
        self.linear_attn = _MockGatedDeltaNet(hidden)
        self.mlp = _MockMLP(hidden)
        self.input_layernorm = nn.LayerNorm(hidden)
        self.post_attention_layernorm = nn.LayerNorm(hidden)


class _MockStandardAttn(nn.Module):
    """전통적인 self_attn 구조 (Qwen3, Llama 등)."""
    def __init__(self, hidden=64):
        super().__init__()
        self.q_proj = nn.Linear(hidden, hidden, bias=False)
        self.k_proj = nn.Linear(hidden, hidden, bias=False)
        self.v_proj = nn.Linear(hidden, hidden, bias=False)
        self.o_proj = nn.Linear(hidden, hidden, bias=False)


class _MockStandardBlock(nn.Module):
    """전통적인 block: self_attn + mlp."""
    def __init__(self, hidden=64):
        super().__init__()
        self.self_attn = _MockStandardAttn(hidden)
        self.mlp = _MockMLP(hidden)
        self.input_layernorm = nn.LayerNorm(hidden)
        self.post_attention_layernorm = nn.LayerNorm(hidden)


# ─────────────────────────────────────────────────────────────────────────────
# Tests
# ─────────────────────────────────────────────────────────────────────────────


class TestQwen3AdapterStandardSelfAttn:
    """전통적인 self_attn 구조 (Qwen3 0.6B 등)는 그대로 동작해야 한다."""

    def test_standard_attn_q_v_proj_match(self):
        from eulerforge.adapters.backbones.qwen3 import Qwen3Adapter
        adapter = Qwen3Adapter()
        block = _MockStandardBlock()
        leaves = adapter.find_attention_leaf_modules(block, ["q_proj", "v_proj"])
        # q_proj + v_proj 2개 매칭
        assert len(leaves) == 2
        assert any("q_proj" in n for n in leaves)
        assert any("v_proj" in n for n in leaves)
        # 모두 self_attn 아래
        assert all("self_attn" in n for n in leaves)


class TestQwen3AdapterLinearAttnFallback:
    """Qwen3.5의 linear_attn 구조에서 표준 키워드 fallback 동작."""

    def test_linear_attn_q_v_proj_fallback_to_in_proj_qkv(self):
        """q/k/v_proj가 매칭되지 않을 때 in_proj_qkv로 fallback."""
        from eulerforge.adapters.backbones.qwen3 import Qwen3Adapter
        adapter = Qwen3Adapter()
        block = _MockQwen35Block()
        leaves = adapter.find_attention_leaf_modules(block, ["q_proj", "v_proj"])
        # in_proj_qkv가 q/k/v를 통합하므로 1개 (또는 in_proj_qkv + out_proj)
        assert len(leaves) >= 1, (
            f"Expected at least 1 leaf for Qwen3.5 linear_attn (in_proj_qkv), got {leaves}"
        )
        # in_proj_qkv가 포함되어야 함
        assert any("in_proj_qkv" in n for n in leaves), (
            f"linear_attn fallback should include in_proj_qkv. got: {leaves}"
        )

    def test_linear_attn_o_proj_fallback_to_out_proj(self):
        """o_proj 키워드는 linear_attn의 out_proj로 fallback."""
        from eulerforge.adapters.backbones.qwen3 import Qwen3Adapter
        adapter = Qwen3Adapter()
        block = _MockQwen35Block()
        leaves = adapter.find_attention_leaf_modules(block, ["o_proj"])
        assert any("out_proj" in n for n in leaves), (
            f"o_proj fallback should match linear_attn.out_proj. got: {leaves}"
        )

    def test_linear_attn_explicit_keywords_work(self):
        """사용자가 명시적으로 in_proj_qkv 키워드를 줘도 정상 동작."""
        from eulerforge.adapters.backbones.qwen3 import Qwen3Adapter
        adapter = Qwen3Adapter()
        block = _MockQwen35Block()
        leaves = adapter.find_attention_leaf_modules(block, ["in_proj_qkv", "out_proj"])
        assert any("in_proj_qkv" in n for n in leaves)
        assert any("out_proj" in n for n in leaves)


class TestConfigVocabSizeFallback:
    """Qwen3.5 config는 vocab_size가 text_config 아래로 nested됨."""

    def test_vocab_size_text_config_fallback(self):
        """top-level vocab_size 없으면 text_config.vocab_size를 사용."""
        # Mock config with text_config
        class _MockTextCfg:
            vocab_size = 248320
            hidden_size = 1024

        class _MockCfg:
            model_type = "qwen3_5"
            text_config = _MockTextCfg()

        class _MockModel:
            config = _MockCfg()

        # 검증 헬퍼: vocab_size 추출
        cfg = _MockModel().config
        vocab = getattr(cfg, "vocab_size", None)
        if vocab is None:
            text_cfg = getattr(cfg, "text_config", None)
            vocab = getattr(text_cfg, "vocab_size", None)
        assert vocab == 248320

    def test_hidden_size_text_config_fallback(self):
        """top-level hidden_size 없으면 text_config.hidden_size를 사용."""
        class _MockTextCfg:
            hidden_size = 1024

        class _MockCfg:
            text_config = _MockTextCfg()

        cfg = _MockCfg()
        hs = getattr(cfg, "hidden_size", None)
        if hs is None:
            text_cfg = getattr(cfg, "text_config", None)
            hs = getattr(text_cfg, "hidden_size", None)
        assert hs == 1024
