# tests/test_config_loader.py
import os
import pytest
import yaml
from eulerforge.utils.config import (
    load_yaml, 
    parse_kv_overrides, 
    resolve_config, 
    ResolvedConfig
)

@pytest.fixture
def sample_yaml_file(tmp_path):
    """임시 YAML 파일을 생성하는 Fixture"""
    data = {
        "model_name": "gpt2",
        "training": {
            "lr": 1e-4,
            "batch_size": 8,
            "optimizer": "adamw"
        },
        "injection": {
            "strategy": "dense_lora",
            "layers": [0, 2, 4]
        }
    }
    p = tmp_path / "test_config.yml"
    with open(p, "w") as f:
        yaml.dump(data, f)
    return str(p)

def test_load_yaml(sample_yaml_file):
    """YAML 파일 로딩 테스트"""
    data = load_yaml(sample_yaml_file)
    assert data["model_name"] == "gpt2"
    assert data["training"]["batch_size"] == 8
    assert isinstance(data["injection"]["layers"], list)

def test_parse_kv_overrides_types():
    """CLI 인자 파싱 및 타입 변환 테스트"""
    overrides = [
        "training.lr=2e-5",       # float (scientific notation)
        "training.batch_size=32", # int
        "use_flash_attn=true",    # bool
        "debug_mode=False",       # bool (case insensitive check usually handled)
        "name=test_run",          # string
        "misc.none_val=null"      # None
    ]
    
    parsed = parse_kv_overrides(overrides)
    
    assert parsed["training"]["lr"] == 2e-5
    assert isinstance(parsed["training"]["lr"], float)
    
    assert parsed["training"]["batch_size"] == 32
    assert isinstance(parsed["training"]["batch_size"], int)
    
    assert parsed["use_flash_attn"] is True
    # parse_kv_overrides 구현에 따라 'False' 문자열 처리가 다를 수 있음. 
    # 현재 구현상 'true'/'false'만 소문자로 처리한다면 아래와 같이 검증:
    if "debug_mode" in parsed:
        # 구현 로직에 따라 문자열 "False"로 남을 수도, bool False가 될 수도 있음.
        # eulerforge 구현 기준: 'true', 'false' (lower) 체크함.
        pass 

    assert parsed["name"] == "test_run"
    assert parsed["misc"]["none_val"] is None


def test_parse_kv_overrides_list_values():
    """리스트 값 파싱 — grid search space의 keywords 등 지원."""
    overrides = [
        "injection.attn_lora.keywords=[q_proj,v_proj]",
        "injection.target_keywords=[gate_proj,up_proj,down_proj]",
        "simple_list=[a,b,c]",
    ]
    parsed = parse_kv_overrides(overrides)

    assert parsed["injection"]["attn_lora"]["keywords"] == ["q_proj", "v_proj"]
    assert parsed["injection"]["target_keywords"] == ["gate_proj", "up_proj", "down_proj"]
    assert parsed["simple_list"] == ["a", "b", "c"]


def test_parse_kv_overrides_single_element_list():
    """단일 요소 리스트 파싱."""
    parsed = parse_kv_overrides(["keys=[q_proj]"])
    assert parsed["keys"] == ["q_proj"]


def test_parse_kv_overrides_empty_brackets_is_string():
    """빈 브라켓은 문자열 그대로."""
    parsed = parse_kv_overrides(["val=[]"])
    assert parsed["val"] == "[]"


class TestListIndexOverride:
    """--set training.phases.1.step=10 같은 list 인덱스 override 동작 검증.

    Regression: `set_by_path`가 list를 dict로 덮어써서 validator가 실패함.
    `training.phases must be a list of phase dicts` 에러가 나던 버그.
    """

    def test_list_index_override_preserves_list(self):
        """list 내 특정 인덱스 업데이트 후에도 list 구조 유지."""
        from eulerforge.utils.config import deep_merge

        base = {
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["router"]},
                    {"step": 1000, "trainable": ["router", "lora"]},
                ]
            }
        }
        # parse_kv_overrides가 만드는 형태
        override = {"training": {"phases": {"1": {"step": 10}}}}

        merged = deep_merge(base, override)
        assert isinstance(merged["training"]["phases"], list), \
            "phases must remain a list after list-index override"
        assert len(merged["training"]["phases"]) == 2
        assert merged["training"]["phases"][0] == {"step": 0, "trainable": ["router"]}
        assert merged["training"]["phases"][1]["step"] == 10
        # trainable 보존
        assert merged["training"]["phases"][1]["trainable"] == ["router", "lora"]

    def test_list_index_override_multiple_indices(self):
        """여러 인덱스 동시 업데이트."""
        from eulerforge.utils.config import deep_merge

        base = {
            "phases": [
                {"step": 0},
                {"step": 100},
                {"step": 200},
            ]
        }
        override = {"phases": {"0": {"step": 5}, "2": {"step": 500}}}

        merged = deep_merge(base, override)
        assert merged["phases"][0]["step"] == 5
        assert merged["phases"][1]["step"] == 100   # 미변경
        assert merged["phases"][2]["step"] == 500

    def test_list_index_via_parse_kv_overrides_and_resolve(self, tmp_path):
        """CLI 경로 전체: parse_kv_overrides → resolve_config."""
        import yaml
        from eulerforge.utils.config import parse_kv_overrides, resolve_config

        preset = {
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["router"]},
                    {"step": 1000, "trainable": ["router", "lora", "attn_lora"]},
                ],
                "max_train_steps": 10000,
            }
        }
        preset_path = tmp_path / "preset.yml"
        preset_path.write_text(yaml.safe_dump(preset))

        overrides = parse_kv_overrides([
            "training.phases.1.step=10",
            "training.max_train_steps=50",
        ])
        resolved = resolve_config(preset_path=str(preset_path), overrides=overrides)

        phases = resolved.config["training"]["phases"]
        assert isinstance(phases, list)
        assert len(phases) == 2
        assert phases[1]["step"] == 10
        assert phases[1]["trainable"] == ["router", "lora", "attn_lora"]
        assert resolved.config["training"]["max_train_steps"] == 50

    def test_list_index_out_of_range_raises(self):
        """범위 초과 인덱스는 명확한 에러."""
        from eulerforge.utils.config import deep_merge

        base = {"phases": [{"step": 0}]}
        override = {"phases": {"5": {"step": 999}}}
        with pytest.raises((ValueError, IndexError), match="(?i)range|index"):
            deep_merge(base, override)

    def test_full_dict_override_still_replaces_list(self):
        """numeric key가 아닌 dict로 override하면 list를 dict로 완전 교체 (기존 동작 유지)."""
        from eulerforge.utils.config import deep_merge

        base = {"phases": [{"step": 0}]}
        override = {"phases": [{"step": 100}, {"step": 200}]}  # 명시적 list

        merged = deep_merge(base, override)
        assert merged["phases"] == [{"step": 100}, {"step": 200}]

def test_resolve_config_merge(sample_yaml_file):
    """Preset + Override 병합 로직 테스트 (Deep Merge)"""
    
    # 상황: 기본 YAML이 있고, CLI로 일부 값만 바꾸려 함
    overrides_list = [
        "training.lr=5e-6",        # 값 변경
        "training.epochs=3",       # 새 키 추가
        "injection.strategy=mixture_lora" # 값 변경
    ]
    
    override_dict = parse_kv_overrides(overrides_list)
    
    # Resolve 실행
    resolved = resolve_config(
        preset_path=sample_yaml_file,
        overrides=override_dict
    )
    cfg = resolved.config
    
    # 1. 변경된 값 확인
    assert cfg["training"]["lr"] == 5e-6
    assert cfg["injection"]["strategy"] == "mixture_lora"
    
    # 2. 새로 추가된 값 확인
    assert cfg["training"]["epochs"] == 3
    
    # 3. 건드리지 않은 기존 값 유지 확인 (중요)
    assert cfg["training"]["batch_size"] == 8
    assert cfg["training"]["optimizer"] == "adamw"
    assert cfg["model_name"] == "gpt2"

def test_invalid_override_format():
    """잘못된 포맷의 Override 처리"""
    bad_input = ["training.lr"] # '=' 없음
    
    with pytest.raises(ValueError, match="expected key=value"):
        parse_kv_overrides(bad_input)

def test_empty_key_override():
    """키가 비어있는 경우"""
    bad_input = ["=value"]
    
    with pytest.raises(ValueError):
        parse_kv_overrides(bad_input)