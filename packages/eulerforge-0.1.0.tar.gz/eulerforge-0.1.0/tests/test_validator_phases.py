# tests/test_validator_phases.py
"""
Extensive tests for the config validator with the new phases schema.
Tests cover many invalid YAML patterns and common user mistakes.
"""
from __future__ import annotations

import pytest

from eulerforge.utils.validator import validate_config, ConfigValidationError


def _base_cfg(**overrides):
    """Build a minimal valid config, with overrides."""
    cfg = {
        "backbone": "qwen3",
        "model_name": "Qwen/Qwen3.5-0.8B-Base",
        "injection": {
            "strategy": "dense_lora",
            "lora_r": 16,
            "lora_alpha": 32,
        },
        "training": {
            "phases": [
                {"step": 0, "trainable": ["lora"]},
            ],
        },
    }
    for k, v in overrides.items():
        keys = k.split(".")
        d = cfg
        for part in keys[:-1]:
            d = d.setdefault(part, {})
        d[keys[-1]] = v
    return cfg


def _moe_cfg(**overrides):
    """Build a minimal valid MoE config."""
    cfg = {
        "backbone": "qwen3",
        "model_name": "Qwen/Qwen3.5-0.8B-Base",
        "injection": {
            "strategy": "mixture_lora",
            "lora_r": 16,
            "lora_alpha": 32,
            "num_experts": 4,
            "top_k": 2,
        },
        "training": {
            "phases": [
                {"step": 0, "trainable": ["router"]},
                {"step": 100, "trainable": ["lora"]},
            ],
        },
        "moe": {
            "router_z_loss_coef": 0.001,
            "load_balance": {"type": "aux_loss", "aux_loss_coef": 0.01},
        },
    }
    for k, v in overrides.items():
        keys = k.split(".")
        d = cfg
        for part in keys[:-1]:
            d = d.setdefault(part, {})
        d[keys[-1]] = v
    return cfg


# ===========================================================================
# Valid cases - should pass validation
# ===========================================================================

class TestValidConfigs:
    def test_minimal_dense_lora(self):
        validate_config(_base_cfg())

    def test_multi_phase_lora(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["lora"]},
            {"step": 100, "trainable": ["lora", "router"]},
        ]
        validate_config(cfg)

    def test_three_phase_progressive(self):
        cfg = _base_cfg()
        cfg["injection"]["strategy"] = "moe_expert_lora"
        cfg["injection"]["num_experts"] = 4
        cfg["injection"]["top_k"] = 2
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora"]},
            {"step": 500, "trainable": ["lora", "router", "base_ffn"],
             "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"]},
        ]
        cfg["moe"] = {
            "router_z_loss_coef": 0.001,
            "load_balance": {"type": "aux_loss", "aux_loss_coef": 0.01},
        }
        validate_config(cfg)

    def test_mixture_lora(self):
        validate_config(_moe_cfg())

    def test_native_moe(self):
        cfg = _base_cfg()
        cfg["injection"]["strategy"] = "native_moe_expert_lora"
        cfg["injection"]["target_keywords"] = ["w1", "w2", "w3"]
        validate_config(cfg)

    def test_with_phase_target_kwargs(self):
        cfg = _base_cfg()
        cfg["training"]["phase_target_kwargs"] = {
            "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"],
            "target_layers": [0, 1, 2],
        }
        validate_config(cfg)

    def test_legacy_phase_schedule_raises_error(self):
        """Legacy training.phase_schedule key must be rejected with a clear error."""
        cfg = _base_cfg()
        del cfg["training"]["phases"]
        cfg["training"]["phase_schedule"] = "lora_only"
        with pytest.raises(ConfigValidationError, match="phase_schedule.*removed|legacy.*phase_schedule"):
            validate_config(cfg)

    def test_legacy_phase1_steps_raises_error(self):
        """Legacy training.phase1_steps key must be rejected."""
        cfg = _base_cfg()
        cfg["training"]["phase1_steps"] = 500
        with pytest.raises(ConfigValidationError, match="phase1_steps.*removed|legacy.*phase1_steps"):
            validate_config(cfg)

    def test_legacy_phase_schedule_kwargs_raises_error(self):
        """Legacy training.phase_schedule_kwargs key must be rejected."""
        cfg = _base_cfg()
        cfg["training"]["phase_schedule_kwargs"] = {"phase1_mode": "router_only"}
        with pytest.raises(ConfigValidationError, match="phase_schedule_kwargs.*removed|legacy.*phase_schedule_kwargs"):
            validate_config(cfg)

    def test_legacy_keys_with_phases_also_raises(self):
        """Even when training.phases is present, legacy keys must be rejected."""
        cfg = _base_cfg()
        cfg["training"]["phase_schedule"] = "lora_only"
        with pytest.raises(ConfigValidationError, match="phase_schedule.*removed|legacy.*phase_schedule"):
            validate_config(cfg)

    def test_with_mode_add(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["lora"]},
            {"step": 100, "trainable": ["router"], "mode": "add"},
        ]
        validate_config(cfg)

    def test_attn_lora_group(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["lora", "attn_lora"]},
        ]
        validate_config(cfg)


# ===========================================================================
# Missing required sections
# ===========================================================================

class TestMissingSections:
    def test_missing_backbone(self):
        cfg = _base_cfg()
        del cfg["backbone"]
        with pytest.raises(ConfigValidationError, match="backbone"):
            validate_config(cfg)

    def test_missing_injection(self):
        cfg = _base_cfg()
        del cfg["injection"]
        with pytest.raises(ConfigValidationError, match="injection"):
            validate_config(cfg)

    def test_missing_training(self):
        cfg = _base_cfg()
        del cfg["training"]
        with pytest.raises(ConfigValidationError, match="training"):
            validate_config(cfg)


# ===========================================================================
# Phases schema validation errors
# ===========================================================================

class TestPhasesSchemaErrors:
    def test_phases_not_a_list(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = "lora_only"
        with pytest.raises(ConfigValidationError, match="must be a list"):
            validate_config(cfg)

    def test_phases_is_dict(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = {"step": 0, "trainable": ["lora"]}
        with pytest.raises(ConfigValidationError, match="must be a list"):
            validate_config(cfg)

    def test_phase_entry_not_dict(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = ["lora_only"]
        with pytest.raises(ConfigValidationError, match="must be a dict"):
            validate_config(cfg)

    def test_missing_step_key(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [{"trainable": ["lora"]}]
        with pytest.raises(ConfigValidationError, match="'step'"):
            validate_config(cfg)

    def test_missing_trainable_key(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [{"step": 0}]
        with pytest.raises(ConfigValidationError, match="'trainable'"):
            validate_config(cfg)

    def test_step_not_int(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [{"step": "abc", "trainable": ["lora"]}]
        with pytest.raises(ConfigValidationError, match="step.*integer"):
            validate_config(cfg)

    def test_step_is_float(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [{"step": 1.5, "trainable": ["lora"]}]
        with pytest.raises(ConfigValidationError, match="step.*integer"):
            validate_config(cfg)

    def test_step_negative(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [{"step": -1, "trainable": ["lora"]}]
        with pytest.raises(ConfigValidationError, match="step.*negative"):
            validate_config(cfg)

    def test_duplicate_steps(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["lora"]},
            {"step": 0, "trainable": ["router"]},
        ]
        with pytest.raises(ConfigValidationError, match="[Dd]uplicate"):
            validate_config(cfg)

    def test_non_monotonic_steps(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [
            {"step": 100, "trainable": ["lora"]},
            {"step": 50, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora", "router"]},
        ]
        with pytest.raises(ConfigValidationError, match="[Dd]uplicate|monotonic"):
            validate_config(cfg)

    def test_trainable_not_list(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [{"step": 0, "trainable": "lora"}]
        with pytest.raises(ConfigValidationError, match="trainable.*list"):
            validate_config(cfg)

    def test_trainable_empty_in_replace_mode(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [{"step": 0, "trainable": []}]
        with pytest.raises(ConfigValidationError, match="trainable.*empty"):
            validate_config(cfg)

    def test_unknown_group_name(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [{"step": 0, "trainable": ["supergroup"]}]
        with pytest.raises(ConfigValidationError, match="[Uu]nknown.*group"):
            validate_config(cfg)

    def test_invalid_mode(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["lora"], "mode": "delete"},
        ]
        with pytest.raises(ConfigValidationError, match="mode"):
            validate_config(cfg)


# ===========================================================================
# Phase target kwargs validation
# ===========================================================================

class TestPhaseTargetKwargsErrors:
    def test_base_ffn_keywords_not_list(self):
        cfg = _base_cfg()
        cfg["training"]["phase_target_kwargs"] = {
            "base_ffn_keywords": "gate_proj",
        }
        with pytest.raises(ConfigValidationError, match="base_ffn_keywords.*list"):
            validate_config(cfg)

    def test_target_layers_not_list(self):
        cfg = _base_cfg()
        cfg["training"]["phase_target_kwargs"] = {
            "target_layers": 5,
        }
        with pytest.raises(ConfigValidationError, match="target_layers.*list"):
            validate_config(cfg)

    def test_target_layers_not_ints(self):
        cfg = _base_cfg()
        cfg["training"]["phase_target_kwargs"] = {
            "target_layers": ["a", "b"],
        }
        with pytest.raises(ConfigValidationError, match="target_layers.*int"):
            validate_config(cfg)

    def test_base_ffn_keywords_not_strings(self):
        cfg = _base_cfg()
        cfg["training"]["phase_target_kwargs"] = {
            "base_ffn_keywords": [1, 2, 3],
        }
        with pytest.raises(ConfigValidationError, match="base_ffn_keywords.*str"):
            validate_config(cfg)


# ===========================================================================
# Common typos and misspellings
# ===========================================================================

class TestCommonTypos:
    def test_typo_trainables(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [{"step": 0, "trainables": ["lora"]}]
        with pytest.raises(ConfigValidationError, match="trainable"):
            validate_config(cfg)

    def test_typo_steps_instead_of_step(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [{"steps": 0, "trainable": ["lora"]}]
        with pytest.raises(ConfigValidationError, match="step"):
            validate_config(cfg)

    def test_typo_phase_instead_of_phases(self):
        """'phase' (singular) is not 'phases'."""
        cfg = _base_cfg()
        del cfg["training"]["phases"]
        cfg["training"]["phase"] = [{"step": 0, "trainable": ["lora"]}]
        # This should either warn or be handled - no phases found
        # So it should return None from builder (no error, just no schedule)
        validate_config(cfg)  # should pass (no phases, no legacy schedule)

    def test_typo_router_only_as_group(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [{"step": 0, "trainable": ["router_only"]}]
        with pytest.raises(ConfigValidationError, match="[Uu]nknown.*group.*router_only"):
            validate_config(cfg)

    def test_typo_lora_r_not_int(self):
        cfg = _base_cfg()
        cfg["injection"]["lora_r"] = "sixteen"
        with pytest.raises(ConfigValidationError, match="lora_r.*integer"):
            validate_config(cfg)


# ===========================================================================
# Strategy-specific phase conflicts
# ===========================================================================

class TestStrategyPhaseConflicts:
    def test_dense_lora_with_router_group_warns(self):
        """dense_lora strategy doesn't have router params; requesting router training is suspicious."""
        cfg = _base_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["router"]},
        ]
        # This should warn but not error (the model might still have router-named params)
        validate_config(cfg)  # passes (warning only)

    def test_dense_lora_with_base_ffn_warns(self):
        cfg = _base_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["base_ffn"],
             "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"]},
        ]
        validate_config(cfg)  # passes (warning only)


# ===========================================================================
# Injection strategy validation (existing + enhanced)
# ===========================================================================

class TestInjectionValidation:
    def test_missing_strategy(self):
        cfg = _base_cfg()
        del cfg["injection"]["strategy"]
        with pytest.raises(ConfigValidationError, match="strategy"):
            validate_config(cfg)

    def test_unknown_strategy(self):
        cfg = _base_cfg()
        cfg["injection"]["strategy"] = "magic_lora"
        with pytest.raises(ConfigValidationError, match="[Uu]nknown.*strategy"):
            validate_config(cfg)

    def test_moe_missing_num_experts(self):
        cfg = _base_cfg()
        cfg["injection"]["strategy"] = "mixture_lora"
        cfg["injection"]["top_k"] = 2
        with pytest.raises(ConfigValidationError, match="num_experts"):
            validate_config(cfg)

    def test_moe_missing_top_k(self):
        cfg = _base_cfg()
        cfg["injection"]["strategy"] = "mixture_lora"
        cfg["injection"]["num_experts"] = 4
        with pytest.raises(ConfigValidationError, match="top_k"):
            validate_config(cfg)

    def test_moe_top_k_exceeds_experts(self):
        cfg = _base_cfg()
        cfg["injection"]["strategy"] = "mixture_lora"
        cfg["injection"]["num_experts"] = 2
        cfg["injection"]["top_k"] = 5
        with pytest.raises(ConfigValidationError, match="top_k.*num_experts"):
            validate_config(cfg)

    def test_lora_r_negative(self):
        cfg = _base_cfg()
        cfg["injection"]["lora_r"] = -1
        with pytest.raises(ConfigValidationError, match="lora_r.*negative"):
            validate_config(cfg)

    def test_native_moe_missing_target_keywords(self):
        cfg = _base_cfg()
        cfg["injection"]["strategy"] = "native_moe_expert_lora"
        with pytest.raises(ConfigValidationError, match="target_keywords"):
            validate_config(cfg)
