# tests/test_pretrain.py
# -*- coding: utf-8 -*-
"""
eulerforge pretrain CLI 유닛 테스트.

테스트 범위:
- 설정 로드 + 검증
- 금지 키 (injection/moe/backbone) 거부
- --validate-only
- packed dataset 로직
- CLI argparse
"""
from __future__ import annotations

import json
import os

import pytest
import yaml

from eulerforge.cli.pretrain import (
    _load_preset,
    _apply_overrides,
    validate_pretrain_config,
    _load_packed_dataset,
    build_argparser,
    main as pretrain_main,
)


# =========================================================================
# Fixtures
# =========================================================================

def _make_pretrain_preset(tmp_path, **overrides):
    """최소 유효 pretrain 프리셋 생성."""
    # 가짜 model_dir 생성
    model_dir = tmp_path / "fake_model"
    model_dir.mkdir()
    (model_dir / "config.json").write_text('{"model_type": "test"}')

    # 가짜 데이터 생성
    data_path = tmp_path / "data.jsonl"
    with open(data_path, "w") as f:
        for i in range(10):
            f.write(json.dumps({"text": f"Sample text {i}. " * 20}) + "\n")

    cfg = {
        "model_dir": str(model_dir),
        "tokenizer": "gpt2",
        "data": {
            "path": str(data_path),
            "text_column": "text",
            "max_length": 64,
            "packing": True,
        },
        "training": {
            "max_steps": 5,
            "batch_size": 2,
            "lr": 1e-4,
        },
    }
    cfg.update(overrides)
    preset_path = tmp_path / "preset.yml"
    with open(preset_path, "w") as f:
        yaml.dump(cfg, f)
    return str(preset_path), cfg


# =========================================================================
# 설정 검증 테스트
# =========================================================================

class TestPretrainConfigValidation:
    """pretrain 설정 검증 테스트."""

    def test_valid_config_passes(self, tmp_path):
        """유효한 설정은 통과."""
        path, cfg = _make_pretrain_preset(tmp_path)
        validate_pretrain_config(cfg)  # should not raise

    def test_missing_model_dir_fails(self, tmp_path):
        """model_dir 누락 → 에러."""
        _, cfg = _make_pretrain_preset(tmp_path)
        del cfg["model_dir"]
        with pytest.raises(SystemExit):
            validate_pretrain_config(cfg)

    def test_missing_data_fails(self, tmp_path):
        """data 섹션 누락 → 에러."""
        _, cfg = _make_pretrain_preset(tmp_path)
        del cfg["data"]
        with pytest.raises(SystemExit):
            validate_pretrain_config(cfg)

    def test_missing_training_fails(self, tmp_path):
        """training 섹션 누락 → 에러."""
        _, cfg = _make_pretrain_preset(tmp_path)
        del cfg["training"]
        with pytest.raises(SystemExit):
            validate_pretrain_config(cfg)

    def test_injection_key_forbidden(self, tmp_path):
        """injection 키 → 에러 (pretrain에서 사용 불가)."""
        _, cfg = _make_pretrain_preset(tmp_path)
        cfg["injection"] = {"strategy": "dense_lora"}
        with pytest.raises(SystemExit):
            validate_pretrain_config(cfg)

    def test_moe_key_forbidden(self, tmp_path):
        """moe 키 → 에러."""
        _, cfg = _make_pretrain_preset(tmp_path)
        cfg["moe"] = {"router_z_loss_coef": 0.01}
        with pytest.raises(SystemExit):
            validate_pretrain_config(cfg)

    def test_backbone_key_forbidden(self, tmp_path):
        """backbone 키 → 에러."""
        _, cfg = _make_pretrain_preset(tmp_path)
        cfg["backbone"] = "qwen3"
        with pytest.raises(SystemExit):
            validate_pretrain_config(cfg)


# =========================================================================
# 오버라이드 테스트
# =========================================================================

class TestApplyOverrides:
    """--set 오버라이드 테스트."""

    def test_simple_override(self):
        cfg = {"training": {"lr": 1e-4}}
        result = _apply_overrides(cfg, ["training.lr=3e-4"])
        assert result["training"]["lr"] == 3e-4

    def test_new_key_override(self):
        cfg = {"training": {}}
        result = _apply_overrides(cfg, ["training.max_steps=100"])
        assert result["training"]["max_steps"] == 100

    def test_string_override(self):
        cfg = {}
        result = _apply_overrides(cfg, ["model_dir=/new/path"])
        assert result["model_dir"] == "/new/path"


# =========================================================================
# Packed dataset 테스트
# =========================================================================

class TestPackedDataset:
    """packed chunking 데이터셋 테스트."""

    def test_packed_creates_chunks(self, tmp_path):
        """packed=True → 텍스트 연결 후 고정 길이 분할."""
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained("gpt2")
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token

        data_path = tmp_path / "data.jsonl"
        with open(data_path, "w") as f:
            for _ in range(20):
                f.write(json.dumps({"text": "Hello world. " * 50}) + "\n")

        ds = _load_packed_dataset(str(data_path), "text", tok, max_length=32, packing=True)
        assert len(ds) > 0
        item = ds[0]
        assert item["input_ids"].shape[0] == 32
        assert item["labels"].shape[0] == 32

    def test_unpacked_creates_per_text(self, tmp_path):
        """packed=False → 개별 텍스트 토큰화."""
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained("gpt2")
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token

        data_path = tmp_path / "data.jsonl"
        with open(data_path, "w") as f:
            f.write(json.dumps({"text": "Short text."}) + "\n")
            f.write(json.dumps({"text": "Another short text."}) + "\n")

        ds = _load_packed_dataset(str(data_path), "text", tok, max_length=64, packing=False)
        assert len(ds) == 2
        assert ds[0]["input_ids"].shape[0] == 64


# =========================================================================
# CLI 테스트
# =========================================================================

class TestPretrainCLI:
    """pretrain CLI argparse + validate-only."""

    def test_argparser_help(self):
        """argparser가 정상 생성."""
        parser = build_argparser()
        assert parser is not None

    def test_validate_only(self, tmp_path, capsys):
        """--validate-only → 검증만 수행, 훈련 없음."""
        path, _ = _make_pretrain_preset(tmp_path)
        pretrain_main(argv=["--preset", path, "--validate-only"])
        captured = capsys.readouterr()
        assert "validation passed" in captured.out

    def test_validate_only_with_injection_fails(self, tmp_path):
        """--validate-only + injection → 에러."""
        _, cfg = _make_pretrain_preset(tmp_path)
        cfg["injection"] = {"strategy": "dense_lora"}
        path = tmp_path / "bad.yml"
        with open(path, "w") as f:
            yaml.dump(cfg, f)
        with pytest.raises(SystemExit):
            pretrain_main(argv=["--preset", str(path), "--validate-only"])

    def test_output_dir_override(self, tmp_path, capsys):
        """--output-dir 오버라이드."""
        path, _ = _make_pretrain_preset(tmp_path)
        out = str(tmp_path / "custom_out")
        pretrain_main(argv=["--preset", path, "--output-dir", out, "--validate-only"])
        captured = capsys.readouterr()
        assert "validation passed" in captured.out

    def test_set_override(self, tmp_path, capsys):
        """--set 오버라이드."""
        path, _ = _make_pretrain_preset(tmp_path)
        pretrain_main(argv=[
            "--preset", path,
            "--set", "training.max_steps=10",
            "--validate-only",
        ])
        captured = capsys.readouterr()
        assert "max_steps: 10" in captured.out

    def test_command_registered_as_plugin(self):
        """pretrain 명령이 plugin으로 등록."""
        from eulerforge.plugins import discover_plugins
        plugin_names = [p.command for p in discover_plugins()]
        assert "pretrain" in plugin_names


# =========================================================================
# Vocab 불일치 처리 테스트
# =========================================================================

class TestVocabMismatch:
    """토크나이저 vocab > 모델 vocab 시 embedding resize 검증."""

    def test_tokenizer_vocab_larger_than_model_resizes(self):
        """토크나이저 vocab(50257) > 모델 vocab(32000) → resize 발생."""
        import torch
        import torch.nn as nn

        # 간단한 mock 모델 (vocab=100 embedding)
        class TinyModel(nn.Module):
            def __init__(self, vocab_size):
                super().__init__()
                self.embed = nn.Embedding(vocab_size, 16)
                self.lm_head = nn.Linear(16, vocab_size, bias=False)
                self.config = type("C", (), {"vocab_size": vocab_size})()

            def resize_token_embeddings(self, new_size):
                self.embed = nn.Embedding(new_size, 16)
                self.lm_head = nn.Linear(16, new_size, bias=False)

        model = TinyModel(100)
        assert model.embed.num_embeddings == 100

        # resize 시뮬레이션
        tok_vocab = 200
        model_vocab = model.config.vocab_size
        if tok_vocab > model_vocab:
            model.resize_token_embeddings(tok_vocab)

        assert model.embed.num_embeddings == 200

    def test_token_ids_within_bounds_after_clipping(self):
        """토큰 ID가 vocab_size 내에 있어야 한다."""
        import torch

        vocab_size = 32000
        # GPT-2 토큰 ID 범위 (0-50256)가 32000을 초과
        token_ids = torch.tensor([0, 100, 31999, 50000])
        # resize 후에는 50000도 유효
        resized_vocab = 50257
        assert token_ids.max().item() < resized_vocab


class TestPositionIds:
    """position_ids 생성 및 contiguous 검증."""

    def test_position_ids_contiguous(self):
        """pretrain에서 생성하는 position_ids가 contiguous여야 한다."""
        import torch

        batch_size, seq_len = 2, 1024
        device = torch.device("cpu")
        input_ids = torch.randint(0, 100, (batch_size, seq_len))

        position_ids = (
            torch.arange(seq_len, device=device, dtype=torch.long)
            .unsqueeze(0)
            .expand_as(input_ids)
            .contiguous()
        )

        assert position_ids.is_contiguous()
        assert position_ids.shape == (batch_size, seq_len)
        assert position_ids[0, 0].item() == 0
        assert position_ids[0, seq_len - 1].item() == seq_len - 1
        # .view(-1) 호출이 에러 없어야 함 (non-contiguous면 에러)
        flat = position_ids.view(-1)
        assert flat.shape[0] == batch_size * seq_len

    def test_expand_without_contiguous_fails_view(self):
        """expand만 하고 contiguous 안 하면 view가 실패할 수 있다."""
        import torch

        seq_len = 1024
        ids = torch.arange(seq_len).unsqueeze(0).expand(2, -1)
        # expand는 non-contiguous — view가 실패할 수 있음
        assert not ids.is_contiguous()
        # reshape는 항상 동작 (내부적으로 copy)
        flat = ids.reshape(-1)
        assert flat.shape[0] == 2 * seq_len
