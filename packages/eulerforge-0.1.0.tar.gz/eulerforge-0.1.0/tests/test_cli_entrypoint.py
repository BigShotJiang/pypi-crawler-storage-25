# tests/test_cli_entrypoint.py
"""
TDD tests for the unified `eulerforge` CLI entrypoint.

Tests:
- `eulerforge --help` works and shows subcommands
- `eulerforge train --help` works
- `eulerforge bench --help` works
- `eulerforge eval --help` works (stub)
- `eulerforge grid --help` works (stub)
- `eulerforge convert --help` works
- `eulerforge train --validate-only` passes through correctly
- No `eulermoe` string in help output
"""
from __future__ import annotations

import subprocess
import sys

import pytest


def _run_eulerforge(*args: str, timeout: int = 30) -> subprocess.CompletedProcess:
    """Run `python -m eulerforge.cli.main` with given args."""
    cmd = [sys.executable, "-m", "eulerforge.cli.main"] + list(args)
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


class TestEulerforgeHelp:
    """eulerforge --help should show subcommands."""

    def test_help_exits_zero(self):
        result = _run_eulerforge("--help")
        assert result.returncode == 0, f"stderr: {result.stderr}"

    def test_help_shows_train_subcommand(self):
        result = _run_eulerforge("--help")
        assert "train" in result.stdout.lower()

    def test_help_shows_bench_subcommand(self):
        result = _run_eulerforge("--help")
        assert "bench" in result.stdout.lower()

    def test_help_shows_eval_subcommand(self):
        result = _run_eulerforge("--help")
        assert "eval" in result.stdout.lower()

    def test_help_shows_grid_subcommand(self):
        result = _run_eulerforge("--help")
        assert "grid" in result.stdout.lower()

    def test_help_shows_convert_subcommand(self):
        result = _run_eulerforge("--help")
        assert "convert" in result.stdout.lower()

    def test_help_no_eulermoe_string(self):
        """Help text must not contain legacy 'eulermoe' string."""
        result = _run_eulerforge("--help")
        combined = result.stdout + result.stderr
        assert "eulermoe" not in combined.lower(), \
            f"Legacy 'eulermoe' found in help output:\n{combined}"


class TestSubcommandHelp:
    """Each subcommand should have working --help."""

    def test_train_help(self):
        result = _run_eulerforge("train", "--help")
        assert result.returncode == 0
        assert "--preset" in result.stdout

    def test_bench_help(self):
        result = _run_eulerforge("bench", "--help")
        assert result.returncode == 0

    def test_eval_help(self):
        result = _run_eulerforge("eval", "--help")
        assert result.returncode == 0

    def test_grid_help(self):
        result = _run_eulerforge("grid", "--help")
        assert result.returncode == 0

    def test_convert_help(self):
        result = _run_eulerforge("convert", "--help")
        assert result.returncode == 0


class TestSubcommandNoEulerMoe:
    """No subcommand help should contain 'eulermoe'."""

    def test_train_no_eulermoe(self):
        result = _run_eulerforge("train", "--help")
        assert "eulermoe" not in (result.stdout + result.stderr).lower()

    def test_bench_no_eulermoe(self):
        result = _run_eulerforge("bench", "--help")
        assert "eulermoe" not in (result.stdout + result.stderr).lower()


class TestTrainMetricsOption:
    """train --help should show --metrics-level option."""

    def test_train_help_shows_metrics_level(self):
        result = _run_eulerforge("train", "--help")
        assert result.returncode == 0
        assert "--metrics-level" in result.stdout
