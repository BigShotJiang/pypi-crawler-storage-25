# tests/test_cli_preprocess.py
# -*- coding: utf-8 -*-
"""CLI tests for `eulerforge preprocess` command."""
from __future__ import annotations

import json
import os
import subprocess
import sys

import pytest


FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


def _run_preprocess(*args: str, timeout: int = 60) -> subprocess.CompletedProcess:
    """Run ``python -m eulerforge.cli.main preprocess`` with given args."""
    cmd = [sys.executable, "-m", "eulerforge.cli.main", "preprocess"] + list(args)
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


# =========================================================================
# A) Help
# =========================================================================
class TestPreprocessHelp:
    def test_help_exits_zero(self):
        result = _run_preprocess("--help")
        assert result.returncode == 0

    def test_help_shows_required_args(self):
        result = _run_preprocess("--help")
        out = result.stdout.lower()
        assert "--task" in out
        assert "--input" in out
        assert "--output" in out
        assert "--model-name" in out


# =========================================================================
# B) Bad arguments
# =========================================================================
class TestPreprocessBadArgs:
    def test_missing_task_exits_nonzero(self):
        result = _run_preprocess("--input", "x.jsonl", "--output", "y.jsonl",
                                 "--model-name", "gpt2")
        assert result.returncode != 0

    def test_invalid_task_exits_nonzero(self):
        result = _run_preprocess("--task", "grpo", "--input", "x.jsonl",
                                 "--output", "y.jsonl", "--model-name", "gpt2")
        assert result.returncode != 0

    def test_nonexistent_input_exits_1(self):
        result = _run_preprocess("--task", "sft",
                                 "--input", "/nonexistent_path_abc123.jsonl",
                                 "--output", "/tmp/out.jsonl",
                                 "--model-name", "gpt2")
        assert result.returncode != 0


# =========================================================================
# C) Actual runs (uses gpt2 tokenizer — small and fast)
# =========================================================================
class TestPreprocessRun:
    def test_sft_text_produces_output(self, tmp_path):
        inp = os.path.join(FIXTURES, "raw_sft_text_tiny.jsonl")
        out = str(tmp_path / "out.jsonl")
        result = _run_preprocess(
            "--task", "sft",
            "--input", inp,
            "--output", out,
            "--model-name", "gpt2",
            "--max-length", "64",
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"
        assert os.path.exists(out)
        with open(out) as f:
            row = json.loads(f.readline())
        assert "input_ids" in row
        assert "labels" in row

    def test_prompted_preference_masks_labels(self, tmp_path):
        inp = os.path.join(FIXTURES, "raw_prompted_pref_tiny.jsonl")
        out = str(tmp_path / "out.jsonl")
        result = _run_preprocess(
            "--task", "prompted_preference",
            "--input", inp,
            "--output", out,
            "--model-name", "gpt2",
            "--max-length", "64",
        )
        assert result.returncode == 0, f"stderr: {result.stderr}"
        with open(out) as f:
            row = json.loads(f.readline())
        plen = row["prompt_len"]
        assert plen > 0
        assert all(v == -100 for v in row["chosen_labels"][:plen])
