# tests/test_validator_lora_handoff.py
"""
Validation tests for training.lora_handoff config section.
Rules H1–H7 per docs/fixtures/specs/lora_handoff_spec.md.

Key restriction: lora_handoff is ONLY valid with injection.strategy=moe_expert_lora
and requires base_ffn in at least one training phase.
"""
from __future__ import annotations

import pytest

from eulerforge.utils.validator import validate_config, ConfigValidationError


def _base_cfg(**overrides):
    """Minimal valid config for moe_expert_lora with base_ffn phase."""
    cfg = {
        "backbone": "qwen3",
        "model_name": "Qwen/Qwen3.5-0.8B-Base",
        "injection": {
            "strategy": "moe_expert_lora",
            "lora_r": 16,
            "lora_alpha": 32,
            "num_experts": 4,
            "top_k": 2,
            "target_keywords": ["gate_proj", "up_proj", "down_proj"],
            "attn_lora": {"enabled": True, "keywords": ["q_proj", "v_proj"]},
        },
        "moe": {
            "router_z_loss_coef": 0.001,
            "load_balance": {"type": "aux_loss", "aux_loss_coef": 0.01},
        },
        "training": {
            "phases": [
                {"step": 0, "trainable": ["lora", "attn_lora"]},
                {"step": 5000, "trainable": ["lora", "attn_lora", "router", "base_ffn"],
                 "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"]},
            ],
            "max_train_steps": 10000,
        },
    }
    for k, v in overrides.items():
        keys = k.split(".")
        d = cfg
        for part in keys[:-1]:
            d = d.setdefault(part, {})
        d[keys[-1]] = v
    return cfg


def _handoff_cfg(handoff: dict, **overrides):
    """Build config with lora_handoff section."""
    cfg = _base_cfg(**overrides)
    cfg["training"]["lora_handoff"] = handoff
    return cfg


# ===========================================================================
# Valid cases
# ===========================================================================

class TestValidHandoffConfigs:
    def test_valid_full_config_passes(self):
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 5000,
                "duration_steps": 3000,
                "end_scale": 0.0,
                "curve": "cosine",
                "end_action": "freeze",
            },
            "attn_lora": {
                "start_step": 5000,
                "duration_steps": 3000,
                "end_scale": 0.0,
                "curve": "linear",
                "end_action": "freeze",
            },
            "base_ffn_ramp": {
                "start_step": 5000,
                "end_step": 8000,
                "start_multiplier": 1.0,
                "end_multiplier": 3.0,
            },
            "export": {
                "remove_adapters_if_zero_scale": True,
                "merge_adapters_on_export": False,
            },
        })
        validate_config(cfg)

    def test_valid_minimal_expert_only(self):
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 5000,
                "duration_steps": 3000,
            },
        })
        validate_config(cfg)

    def test_valid_attn_only(self):
        cfg = _handoff_cfg({
            "attn_lora": {
                "start_step": 5000,
                "duration_steps": 3000,
                "curve": "cosine",
            },
        })
        validate_config(cfg)

    def test_valid_partial_end_scale(self):
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 5000,
                "duration_steps": 3000,
                "end_scale": 0.3,
            },
        })
        validate_config(cfg)

    def test_valid_empty_handoff_passes(self):
        """Empty lora_handoff dict is valid (no-op)."""
        cfg = _handoff_cfg({})
        validate_config(cfg)


# ===========================================================================
# H1: lora_handoff must be dict
# ===========================================================================

class TestH1HandoffType:
    def test_h1_not_dict_raises(self):
        cfg = _base_cfg()
        cfg["training"]["lora_handoff"] = "invalid"
        with pytest.raises(ConfigValidationError, match="lora_handoff.*dict"):
            validate_config(cfg)

    def test_h1_list_raises(self):
        cfg = _base_cfg()
        cfg["training"]["lora_handoff"] = [1, 2, 3]
        with pytest.raises(ConfigValidationError, match="lora_handoff.*dict"):
            validate_config(cfg)


# ===========================================================================
# H2: Component schedule validity
# ===========================================================================

class TestH2ComponentSchedule:
    def test_h2_missing_start_step(self):
        cfg = _handoff_cfg({
            "expert_lora": {
                "duration_steps": 3000,
            },
        })
        with pytest.raises(ConfigValidationError, match="start_step"):
            validate_config(cfg)

    def test_h2_missing_duration_steps(self):
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 1000,
            },
        })
        with pytest.raises(ConfigValidationError, match="duration_steps"):
            validate_config(cfg)

    def test_h2_negative_start_step(self):
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": -1,
                "duration_steps": 1000,
            },
        })
        with pytest.raises(ConfigValidationError, match="start_step.*>= 0"):
            validate_config(cfg)

    def test_h2_zero_duration(self):
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 1000,
                "duration_steps": 0,
            },
        })
        with pytest.raises(ConfigValidationError, match="duration_steps.*> 0"):
            validate_config(cfg)

    def test_h2_invalid_curve(self):
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 1000,
                "duration_steps": 2000,
                "curve": "exponential",
            },
        })
        with pytest.raises(ConfigValidationError, match="curve"):
            validate_config(cfg)

    def test_h2_invalid_end_action(self):
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 1000,
                "duration_steps": 2000,
                "end_action": "remove",
            },
        })
        with pytest.raises(ConfigValidationError, match="end_action"):
            validate_config(cfg)

    def test_h2_end_scale_out_of_range_negative(self):
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 1000,
                "duration_steps": 2000,
                "end_scale": -0.1,
            },
        })
        with pytest.raises(ConfigValidationError, match="end_scale"):
            validate_config(cfg)

    def test_h2_end_scale_out_of_range_above_one(self):
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 1000,
                "duration_steps": 2000,
                "end_scale": 1.5,
            },
        })
        with pytest.raises(ConfigValidationError, match="end_scale"):
            validate_config(cfg)

    def test_h2_attn_lora_also_validated(self):
        """attn_lora schedule gets same validation as expert_lora."""
        cfg = _handoff_cfg({
            "attn_lora": {
                "start_step": 1000,
                "duration_steps": -5,
            },
        })
        with pytest.raises(ConfigValidationError, match="duration_steps.*> 0"):
            validate_config(cfg)

    def test_h2_component_not_dict_raises(self):
        cfg = _handoff_cfg({
            "expert_lora": "linear",
        })
        with pytest.raises(ConfigValidationError, match="expert_lora.*dict"):
            validate_config(cfg)


# ===========================================================================
# H3: base_ffn_ramp validity
# ===========================================================================

class TestH3BaseFfnRamp:
    def test_h3_end_step_le_start(self):
        cfg = _handoff_cfg({
            "base_ffn_ramp": {
                "start_step": 5000,
                "end_step": 3000,
            },
        })
        with pytest.raises(ConfigValidationError, match="end_step.*start_step"):
            validate_config(cfg)

    def test_h3_end_step_eq_start(self):
        cfg = _handoff_cfg({
            "base_ffn_ramp": {
                "start_step": 5000,
                "end_step": 5000,
            },
        })
        with pytest.raises(ConfigValidationError, match="end_step.*start_step"):
            validate_config(cfg)

    def test_h3_negative_multiplier(self):
        cfg = _handoff_cfg({
            "base_ffn_ramp": {
                "start_step": 1000,
                "end_step": 5000,
                "start_multiplier": -0.5,
            },
        })
        with pytest.raises(ConfigValidationError, match="multiplier.*> 0"):
            validate_config(cfg)

    def test_h3_zero_end_multiplier(self):
        cfg = _handoff_cfg({
            "base_ffn_ramp": {
                "start_step": 1000,
                "end_step": 5000,
                "end_multiplier": 0.0,
            },
        })
        with pytest.raises(ConfigValidationError, match="multiplier.*> 0"):
            validate_config(cfg)

    def test_h3_not_dict_raises(self):
        cfg = _handoff_cfg({
            "base_ffn_ramp": 42,
        })
        with pytest.raises(ConfigValidationError, match="base_ffn_ramp.*dict"):
            validate_config(cfg)

    def test_h3_missing_start_step(self):
        cfg = _handoff_cfg({
            "base_ffn_ramp": {
                "end_step": 5000,
            },
        })
        with pytest.raises(ConfigValidationError, match="start_step"):
            validate_config(cfg)

    def test_h3_missing_end_step(self):
        cfg = _handoff_cfg({
            "base_ffn_ramp": {
                "start_step": 1000,
            },
        })
        with pytest.raises(ConfigValidationError, match="end_step"):
            validate_config(cfg)


# ===========================================================================
# H4: export validity
# ===========================================================================

class TestH4Export:
    def test_h4_both_true_warns(self):
        """remove + merge both true → warning (not error)."""
        import warnings
        cfg = _handoff_cfg({
            "export": {
                "remove_adapters_if_zero_scale": True,
                "merge_adapters_on_export": True,
            },
        })
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            validate_config(cfg)
            handoff_warnings = [x for x in w if "merge" in str(x.message).lower() or "remove" in str(x.message).lower()]
            assert len(handoff_warnings) >= 1, f"Expected warning about both export flags, got: {[str(x.message) for x in w]}"

    def test_h4_not_dict_raises(self):
        cfg = _handoff_cfg({
            "export": True,
        })
        with pytest.raises(ConfigValidationError, match="export.*dict"):
            validate_config(cfg)


# ===========================================================================
# H6: Typo detection
# ===========================================================================

class TestH6TypoDetection:
    def test_h6_unknown_key_warns(self):
        """Unknown key in lora_handoff → warning."""
        import warnings
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 5000,
                "duration_steps": 3000,
            },
            "exprt_lora": {  # typo
                "start_step": 5000,
                "duration_steps": 3000,
            },
        })
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            validate_config(cfg)
            typo_warnings = [x for x in w if "exprt_lora" in str(x.message)]
            assert len(typo_warnings) >= 1, f"Expected typo warning for 'exprt_lora', got: {[str(x.message) for x in w]}"


# ===========================================================================
# H7: Strategy compatibility (ERROR — not warning)
# ===========================================================================

class TestH7StrategyCompatibility:
    """H7: lora_handoff requires strategy=moe_expert_lora.

    P1: strategy must be moe_expert_lora
    P2: base_ffn must be in at least one phase
    attn_lora schedule requires injection.attn_lora.enabled=true
    """

    def test_h7_dense_lora_raises(self):
        """P1: dense_lora + lora_handoff → ConfigValidationError."""
        cfg = {
            "backbone": "qwen3",
            "model_name": "Qwen/Qwen3.5-0.8B-Base",
            "injection": {
                "strategy": "dense_lora",
                "lora_r": 16,
                "lora_alpha": 32,
            },
            "training": {
                "phases": [{"step": 0, "trainable": ["lora"]}],
                "max_train_steps": 10000,
                "lora_handoff": {
                    "expert_lora": {
                        "start_step": 1000,
                        "duration_steps": 2000,
                    },
                },
            },
        }
        with pytest.raises(ConfigValidationError, match="moe_expert_lora"):
            validate_config(cfg)

    def test_h7_mixture_lora_raises(self):
        """P1: mixture_lora + lora_handoff → ConfigValidationError."""
        cfg = {
            "backbone": "qwen3",
            "model_name": "Qwen/Qwen3.5-0.8B-Base",
            "injection": {
                "strategy": "mixture_lora",
                "lora_r": 16,
                "lora_alpha": 32,
                "num_experts": 4,
                "top_k": 2,
            },
            "moe": {
                "router_z_loss_coef": 0.001,
                "load_balance": {"type": "aux_loss", "aux_loss_coef": 0.01},
            },
            "training": {
                "phases": [{"step": 0, "trainable": ["lora"]}],
                "max_train_steps": 10000,
                "lora_handoff": {
                    "expert_lora": {
                        "start_step": 1000,
                        "duration_steps": 2000,
                    },
                },
            },
        }
        with pytest.raises(ConfigValidationError, match="moe_expert_lora"):
            validate_config(cfg)

    def test_h7_no_base_ffn_in_phases_raises(self):
        """P2: moe_expert_lora but no base_ffn in any phase → error."""
        cfg = {
            "backbone": "qwen3",
            "model_name": "Qwen/Qwen3.5-0.8B-Base",
            "injection": {
                "strategy": "moe_expert_lora",
                "lora_r": 16,
                "lora_alpha": 32,
                "num_experts": 4,
                "top_k": 2,
                "target_keywords": ["gate_proj", "up_proj", "down_proj"],
            },
            "moe": {
                "router_z_loss_coef": 0.001,
                "load_balance": {"type": "aux_loss", "aux_loss_coef": 0.01},
            },
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["lora"]},
                    {"step": 5000, "trainable": ["lora", "router"]},
                ],
                "max_train_steps": 10000,
                "lora_handoff": {
                    "expert_lora": {
                        "start_step": 1000,
                        "duration_steps": 2000,
                    },
                },
            },
        }
        with pytest.raises(ConfigValidationError, match="base_ffn"):
            validate_config(cfg)

    def test_h7_attn_lora_without_enabled_raises(self):
        """attn_lora schedule without injection.attn_lora.enabled → error."""
        cfg = _base_cfg()
        cfg["injection"]["attn_lora"] = {"enabled": False}
        cfg["training"]["lora_handoff"] = {
            "attn_lora": {
                "start_step": 5000,
                "duration_steps": 3000,
            },
        }
        with pytest.raises(ConfigValidationError, match="attn_lora.*enabled"):
            validate_config(cfg)

    def test_h7_ffn_moe_with_base_ffn_passes(self):
        """Valid: moe_expert_lora + base_ffn in phases → no error."""
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 5000,
                "duration_steps": 3000,
            },
        })
        validate_config(cfg)  # should not raise

    def test_h7_empty_handoff_skips_p1_p2(self):
        """Empty lora_handoff dict skips P1/P2 checks (no-op)."""
        cfg = {
            "backbone": "qwen3",
            "model_name": "Qwen/Qwen3.5-0.8B-Base",
            "injection": {
                "strategy": "dense_lora",
                "lora_r": 16,
                "lora_alpha": 32,
            },
            "training": {
                "phases": [{"step": 0, "trainable": ["lora"]}],
                "max_train_steps": 10000,
                "lora_handoff": {},
            },
        }
        validate_config(cfg)  # empty handoff → no P1/P2 checks


# ===========================================================================
# H5: Time ordering and alignment validation
# ===========================================================================

class TestH5TimeOrdering:
    """H5: handoff timing must be consistent with phases and max_train_steps.

    H5a: fade exceeds max_train_steps → warning
    H5b: ramp.end_step > max_train_steps → warning
    H5c: fade start_step < base_ffn phase start_step → error
    H5d: fade start_step >= max_train_steps → error
    H5e: ramp ends before fade → warning
    H5f: ramp ends after fade → warning
    """

    # ── H5a: fade exceeds max_train_steps → warning ──

    def test_h5a_expert_fade_exceeds_max_steps_warns(self):
        """expert_lora fade ends after max_train_steps → warning."""
        import warnings
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 8000,
                "duration_steps": 5000,  # ends at 13000 > 10000
            },
        })
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            validate_config(cfg)
            msgs = [str(x.message) for x in w]
            assert any("max_train_steps" in m and "expert_lora" in m for m in msgs), \
                f"Expected warning about expert_lora exceeding max_train_steps, got: {msgs}"

    def test_h5a_attn_fade_exceeds_max_steps_warns(self):
        """attn_lora fade ends after max_train_steps → warning."""
        import warnings
        cfg = _handoff_cfg({
            "attn_lora": {
                "start_step": 9000,
                "duration_steps": 3000,  # ends at 12000 > 10000
            },
        })
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            validate_config(cfg)
            msgs = [str(x.message) for x in w]
            assert any("max_train_steps" in m and "attn_lora" in m for m in msgs), \
                f"Expected warning about attn_lora exceeding max_train_steps, got: {msgs}"

    def test_h5a_fade_within_max_steps_no_warn(self):
        """Fade ends before max_train_steps → no warning."""
        import warnings
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 5000,
                "duration_steps": 3000,  # ends at 8000 < 10000
            },
        })
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            validate_config(cfg)
            msgs = [str(x.message) for x in w]
            assert not any("max_train_steps" in m for m in msgs), \
                f"Unexpected max_train_steps warning: {msgs}"

    # ── H5b: ramp.end_step > max_train_steps → warning ──

    def test_h5b_ramp_exceeds_max_steps_warns(self):
        """base_ffn_ramp.end_step > max_train_steps → warning."""
        import warnings
        cfg = _handoff_cfg({
            "base_ffn_ramp": {
                "start_step": 5000,
                "end_step": 15000,  # > 10000
            },
        })
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            validate_config(cfg)
            msgs = [str(x.message) for x in w]
            assert any("max_train_steps" in m and "base_ffn_ramp" in m for m in msgs), \
                f"Expected warning about ramp exceeding max_train_steps, got: {msgs}"

    def test_h5b_ramp_within_max_steps_no_warn(self):
        """base_ffn_ramp.end_step <= max_train_steps → no warning."""
        import warnings
        cfg = _handoff_cfg({
            "base_ffn_ramp": {
                "start_step": 5000,
                "end_step": 8000,
            },
        })
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            validate_config(cfg)
            msgs = [str(x.message) for x in w]
            assert not any("max_train_steps" in m and "base_ffn_ramp" in m for m in msgs), \
                f"Unexpected ramp max_train_steps warning: {msgs}"

    # ── H5c: fade start_step < base_ffn phase start_step → error ──

    def test_h5c_fade_before_base_ffn_phase_raises(self):
        """expert_lora starts before base_ffn is trainable → error."""
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 3000,  # before base_ffn phase at 5000
                "duration_steps": 4000,
            },
        })
        with pytest.raises(ConfigValidationError, match="base_ffn.*phase"):
            validate_config(cfg)

    def test_h5c_fade_at_base_ffn_phase_passes(self):
        """expert_lora starts exactly at base_ffn phase → no error."""
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 5000,  # = base_ffn phase step
                "duration_steps": 3000,
            },
        })
        validate_config(cfg)  # should not raise

    def test_h5c_fade_after_base_ffn_phase_passes(self):
        """expert_lora starts after base_ffn phase → no error."""
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 6000,  # after base_ffn phase at 5000
                "duration_steps": 3000,
            },
        })
        validate_config(cfg)  # should not raise

    def test_h5c_attn_fade_before_base_ffn_phase_raises(self):
        """attn_lora starts before base_ffn phase → error."""
        cfg = _handoff_cfg({
            "attn_lora": {
                "start_step": 2000,  # before base_ffn phase at 5000
                "duration_steps": 3000,
            },
        })
        with pytest.raises(ConfigValidationError, match="base_ffn.*phase"):
            validate_config(cfg)

    # ── H5d: fade start_step >= max_train_steps → error ──

    def test_h5d_fade_start_at_max_steps_raises(self):
        """expert_lora.start_step == max_train_steps → error (never runs)."""
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 10000,  # = max_train_steps
                "duration_steps": 2000,
            },
        })
        with pytest.raises(ConfigValidationError, match="max_train_steps"):
            validate_config(cfg)

    def test_h5d_fade_start_beyond_max_steps_raises(self):
        """expert_lora.start_step > max_train_steps → error."""
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 15000,
                "duration_steps": 2000,
            },
        })
        with pytest.raises(ConfigValidationError, match="max_train_steps"):
            validate_config(cfg)

    def test_h5d_attn_fade_start_at_max_steps_raises(self):
        cfg = _handoff_cfg({
            "attn_lora": {
                "start_step": 10000,
                "duration_steps": 1000,
            },
        })
        with pytest.raises(ConfigValidationError, match="max_train_steps"):
            validate_config(cfg)

    def test_h5d_no_max_train_steps_skips_check(self):
        """If max_train_steps is not set, skip H5d check."""
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 50000,
                "duration_steps": 2000,
            },
        })
        del cfg["training"]["max_train_steps"]
        validate_config(cfg)  # should not raise

    # ── H5e: ramp ends before fade → warning ──

    def test_h5e_ramp_ends_before_fade_warns(self):
        """Ramp ends before expert_lora fade → warning (gap without LR compensation)."""
        import warnings
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 5000,
                "duration_steps": 4000,  # fade 5000~9000
            },
            "base_ffn_ramp": {
                "start_step": 5000,
                "end_step": 7000,  # ramp ends at 7000 < fade end 9000
            },
        })
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            validate_config(cfg)
            msgs = [str(x.message) for x in w]
            assert any("ramp" in m and "fade" in m.lower() or "ramp" in m.lower() and "earlier" in m.lower() or "ramp" in m.lower() and "before" in m.lower() for m in msgs), \
                f"Expected warning about ramp ending before fade, got: {msgs}"

    def test_h5e_ramp_aligned_with_fade_no_warn(self):
        """Ramp aligned with expert_lora fade → no warning."""
        import warnings
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 5000,
                "duration_steps": 4000,  # fade 5000~9000
            },
            "base_ffn_ramp": {
                "start_step": 5000,
                "end_step": 9000,  # perfectly aligned
            },
        })
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            validate_config(cfg)
            msgs = [str(x.message) for x in w]
            ramp_warns = [m for m in msgs if "ramp" in m.lower() and ("fade" in m.lower() or "earlier" in m.lower() or "later" in m.lower())]
            assert len(ramp_warns) == 0, f"Unexpected ramp alignment warning: {ramp_warns}"

    # ── H5f: ramp ends after fade → warning ──

    def test_h5f_ramp_ends_after_fade_warns(self):
        """Ramp ends after expert_lora fade → warning (unnecessary LR boost)."""
        import warnings
        cfg = _handoff_cfg({
            "expert_lora": {
                "start_step": 5000,
                "duration_steps": 3000,  # fade 5000~8000
            },
            "base_ffn_ramp": {
                "start_step": 5000,
                "end_step": 10000,  # ramp ends at 10000 > fade end 8000
            },
        })
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            validate_config(cfg)
            msgs = [str(x.message) for x in w]
            assert any("ramp" in m.lower() and ("fade" in m.lower() or "later" in m.lower() or "after" in m.lower()) for m in msgs), \
                f"Expected warning about ramp ending after fade, got: {msgs}"

    def test_h5f_ramp_without_expert_lora_no_alignment_warn(self):
        """If no expert_lora schedule, skip ramp alignment check."""
        import warnings
        cfg = _handoff_cfg({
            "base_ffn_ramp": {
                "start_step": 5000,
                "end_step": 9000,
            },
        })
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            validate_config(cfg)
            msgs = [str(x.message) for x in w]
            ramp_warns = [m for m in msgs if "ramp" in m.lower() and "fade" in m.lower()]
            assert len(ramp_warns) == 0, f"Unexpected alignment warning without expert_lora: {ramp_warns}"


class TestDPOHandoffWarning:
    """H8: DPO + Handoff 조합 시 경고 테스트."""

    def _handoff_cfg(self, training_type="sft", **extra_training):
        """유효한 handoff config 생성 (timing 정확)."""
        cfg = _base_cfg()
        cfg["training"]["type"] = training_type
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["lora"]},
            {"step": 2000, "trainable": ["lora", "router", "base_ffn"],
             "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"]},
        ]
        cfg["training"]["lora_handoff"] = {
            "expert_lora": {
                "start_step": 4000,
                "duration_steps": 4000,
                "end_scale": 0.0,
                "curve": "cosine",
                "end_action": "freeze",
            },
            "base_ffn_ramp": {
                "start_step": 4000,
                "end_step": 8000,
                "start_multiplier": 1.0,
                "end_multiplier": 3.0,
            },
        }
        cfg["training"].update(extra_training)
        return cfg

    def test_dpo_with_handoff_warns(self):
        """DPO + lora_handoff → 경고 발생."""
        import warnings as w_mod
        cfg = self._handoff_cfg(training_type="dpo", dpo_beta=0.1)
        with w_mod.catch_warnings(record=True) as caught:
            w_mod.simplefilter("always")
            validate_config(cfg)
            dpo_warns = [str(x.message) for x in caught if "DPO" in str(x.message) and "Handoff" in str(x.message)]
            assert len(dpo_warns) >= 1, "DPO + Handoff should warn"

    def test_sft_with_handoff_no_dpo_warning(self):
        """SFT + lora_handoff → DPO 경고 없음."""
        import warnings as w_mod
        cfg = self._handoff_cfg(training_type="sft")
        with w_mod.catch_warnings(record=True) as caught:
            w_mod.simplefilter("always")
            validate_config(cfg)
            dpo_warns = [str(x.message) for x in caught if "DPO" in str(x.message) and "Handoff" in str(x.message)]
            assert len(dpo_warns) == 0, f"SFT should not get DPO warning: {dpo_warns}"

    def test_orpo_with_handoff_no_dpo_warning(self):
        """ORPO + lora_handoff → DPO 경고 없음."""
        import warnings as w_mod
        cfg = self._handoff_cfg(training_type="orpo", orpo_lambda=0.5)
        with w_mod.catch_warnings(record=True) as caught:
            w_mod.simplefilter("always")
            validate_config(cfg)
            dpo_warns = [str(x.message) for x in caught if "DPO" in str(x.message) and "Handoff" in str(x.message)]
            assert len(dpo_warns) == 0, f"ORPO should not get DPO warning: {dpo_warns}"
