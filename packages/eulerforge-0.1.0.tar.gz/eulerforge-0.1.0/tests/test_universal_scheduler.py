# tests/test_universal_scheduler.py
"""
TDD tests for the UniversalPhaseScheduler, PhaseSpec, group resolver, and builder.
"""
from __future__ import annotations

import pytest
import torch
import torch.nn as nn

from eulerforge.phase_schedules.universal import PhaseSpec, UniversalPhaseScheduler
from eulerforge.phase_schedules.groups import (
    KNOWN_GROUPS,
    resolve_param_groups,
    set_trainable_by_groups,
    _extract_layer_index,
    _is_attn_path,
    _is_base_ffn_param,
)
from eulerforge.phase_schedules import build_phase_schedule


# ---------------------------------------------------------------------------
# Fixtures: minimal mock models with known parameter structure
# ---------------------------------------------------------------------------

class MockLoRALinear(nn.Module):
    """Simulates a LoRA-wrapped linear layer."""
    def __init__(self, in_f=8, out_f=8, r=4):
        super().__init__()
        self.base_layer = nn.Linear(in_f, out_f, bias=False)
        self.lora_a = nn.Parameter(torch.randn(r, in_f))
        self.lora_b = nn.Parameter(torch.randn(out_f, r))

    def forward(self, x):
        return self.base_layer(x) + (x @ self.lora_a.T) @ self.lora_b.T


class MockMixtureLoRALinear(nn.Module):
    """Simulates a MixtureLoRALinear with router + experts."""
    def __init__(self, in_f=8, out_f=8, num_experts=2, r=4):
        super().__init__()
        self.base_layer = nn.Linear(in_f, out_f, bias=False)
        self.router = nn.Linear(in_f, num_experts, bias=False)
        self.experts = nn.ModuleList([
            nn.ModuleDict({
                "loraA": nn.Linear(in_f, r, bias=False),
                "loraB": nn.Linear(r, out_f, bias=False),
            })
            for _ in range(num_experts)
        ])

    def forward(self, x):
        return self.base_layer(x)


class MockMoEFFN(nn.Module):
    """Simulates a MoE FFN with router + expert FFNs."""
    def __init__(self, hidden=8, num_experts=2):
        super().__init__()
        self.router = nn.Linear(hidden, num_experts, bias=False)
        self.experts = nn.ModuleList([
            nn.ModuleDict({
                "gate_proj": nn.Linear(hidden, hidden * 2, bias=False),
                "up_proj": nn.Linear(hidden, hidden * 2, bias=False),
                "down_proj": nn.Linear(hidden * 2, hidden, bias=False),
            })
            for _ in range(num_experts)
        ])

    def forward(self, x):
        return x


class MockTransformerBlock(nn.Module):
    """A mock transformer block with attention and FFN."""
    def __init__(self, hidden=8, r=4, use_moe=False, num_experts=2):
        super().__init__()
        # Attention projections with LoRA
        self.q_proj = MockLoRALinear(hidden, hidden, r)
        self.k_proj = MockLoRALinear(hidden, hidden, r)
        self.v_proj = MockLoRALinear(hidden, hidden, r)
        self.o_proj = MockLoRALinear(hidden, hidden, r)

        if use_moe:
            self.mlp = MockMoEFFN(hidden, num_experts)
        else:
            self.mlp = nn.ModuleDict({
                "gate_proj": MockLoRALinear(hidden, hidden * 2, r),
                "up_proj": MockLoRALinear(hidden, hidden * 2, r),
                "down_proj": MockLoRALinear(hidden * 2, hidden, r),
            })

    def forward(self, x):
        return x


class MockModel(nn.Module):
    """A mock model with named layers."""
    def __init__(self, num_layers=2, hidden=8, r=4, use_moe=False, num_experts=2):
        super().__init__()
        self.model = nn.Module()
        self.model.layers = nn.ModuleList([
            MockTransformerBlock(hidden, r, use_moe, num_experts)
            for _ in range(num_layers)
        ])

    def forward(self, x):
        return x


# ===========================================================================
# PhaseSpec tests
# ===========================================================================

class TestPhaseSpec:
    def test_basic_creation(self):
        ps = PhaseSpec(step=0, trainable=["lora"])
        assert ps.step == 0
        assert ps.trainable == ["lora"]
        assert ps.mode == "replace"

    def test_with_mode_add(self):
        ps = PhaseSpec(step=100, trainable=["router"], mode="add")
        assert ps.mode == "add"

    def test_with_kwargs(self):
        ps = PhaseSpec(
            step=500,
            trainable=["base_ffn"],
            base_ffn_keywords=["gate_proj", "up_proj"],
            target_layers=[0, 1],
        )
        assert ps.base_ffn_keywords == ["gate_proj", "up_proj"]
        assert ps.target_layers == [0, 1]

    def test_negative_step_raises(self):
        with pytest.raises(ValueError, match="step must be >= 0"):
            PhaseSpec(step=-1, trainable=["lora"])

    def test_trainable_not_list_raises(self):
        with pytest.raises(TypeError, match="trainable must be a list"):
            PhaseSpec(step=0, trainable="lora")  # type: ignore

    def test_invalid_mode_raises(self):
        with pytest.raises(ValueError, match="mode must be 'replace' or 'add'"):
            PhaseSpec(step=0, trainable=["lora"], mode="delete")

    def test_frozen(self):
        ps = PhaseSpec(step=0, trainable=["lora"])
        with pytest.raises(AttributeError):
            ps.step = 5  # type: ignore


# ===========================================================================
# UniversalPhaseScheduler tests
# ===========================================================================

class TestUniversalPhaseScheduler:
    def test_empty_phases_raises(self):
        with pytest.raises(ValueError, match="at least one phase"):
            UniversalPhaseScheduler(phases=[])

    def test_duplicate_steps_raises(self):
        with pytest.raises(ValueError, match="Duplicate phase step"):
            UniversalPhaseScheduler(phases=[
                PhaseSpec(step=0, trainable=["lora"]),
                PhaseSpec(step=0, trainable=["router"]),
            ])

    def test_sorts_phases(self):
        scheduler = UniversalPhaseScheduler(phases=[
            PhaseSpec(step=100, trainable=["router"]),
            PhaseSpec(step=0, trainable=["lora"]),
        ])
        assert scheduler.phases[0].step == 0
        assert scheduler.phases[1].step == 100

    def test_single_phase(self):
        model = MockModel(num_layers=1, use_moe=False)
        scheduler = UniversalPhaseScheduler(phases=[
            PhaseSpec(step=0, trainable=["lora"]),
        ])
        changed = scheduler.maybe_step(model, 0)
        assert changed is True
        assert scheduler.current_phase_idx == 0

        # Idempotent
        changed = scheduler.maybe_step(model, 0)
        assert changed is False

    def test_two_phase_transition(self):
        model = MockModel(num_layers=1, use_moe=False)
        scheduler = UniversalPhaseScheduler(phases=[
            PhaseSpec(step=0, trainable=["lora"]),
            PhaseSpec(step=10, trainable=["lora", "router"]),
        ])

        # Phase 0
        changed = scheduler.maybe_step(model, 0)
        assert changed is True
        assert scheduler.current_phase_idx == 0
        assert scheduler.get_active_groups() == ["lora"]

        # Still phase 0
        changed = scheduler.maybe_step(model, 5)
        assert changed is False
        assert scheduler.current_phase_idx == 0

        # Phase 1
        changed = scheduler.maybe_step(model, 10)
        assert changed is True
        assert scheduler.current_phase_idx == 1
        assert set(scheduler.get_active_groups()) == {"lora", "router"}

    def test_three_phase_progressive(self):
        model = MockModel(num_layers=2, use_moe=True, num_experts=2)
        scheduler = UniversalPhaseScheduler(phases=[
            PhaseSpec(step=0, trainable=["router"]),
            PhaseSpec(step=5, trainable=["lora"]),
            PhaseSpec(step=20, trainable=["lora", "router", "base_ffn"]),
        ])

        changed = scheduler.maybe_step(model, 0)
        assert changed is True
        assert scheduler.current_phase_idx == 0

        changed = scheduler.maybe_step(model, 5)
        assert changed is True
        assert scheduler.current_phase_idx == 1

        changed = scheduler.maybe_step(model, 20)
        assert changed is True
        assert scheduler.current_phase_idx == 2

    def test_skip_ahead_to_later_phase(self):
        """If step jumps past multiple phases, land on the correct one."""
        model = MockModel(num_layers=1, use_moe=False)
        scheduler = UniversalPhaseScheduler(phases=[
            PhaseSpec(step=0, trainable=["lora"]),
            PhaseSpec(step=10, trainable=["router"]),
            PhaseSpec(step=100, trainable=["lora", "router"]),
        ])

        # Jump directly to step 50 (should be in phase 1, step=10)
        changed = scheduler.maybe_step(model, 50)
        assert changed is True
        assert scheduler.current_phase_idx == 1

    def test_requires_grad_replace_mode(self):
        """In replace mode, all params should be frozen except active groups."""
        model = MockModel(num_layers=1, use_moe=False)

        scheduler = UniversalPhaseScheduler(phases=[
            PhaseSpec(step=0, trainable=["lora"]),
        ])
        scheduler.maybe_step(model, 0)

        # Check: some params should be trainable (LoRA), others frozen
        any_trainable = False
        all_frozen_base = True
        for name, param in model.named_parameters():
            if param.requires_grad:
                any_trainable = True
                ln = name.lower()
                # Only lora params should be trainable
                assert "lora" in ln, f"Non-lora param trainable: {name}"
            else:
                ln = name.lower()
                if "base_layer" in ln:
                    all_frozen_base = True

        assert any_trainable, "No params were made trainable"

    def test_phase_info(self):
        scheduler = UniversalPhaseScheduler(phases=[
            PhaseSpec(step=0, trainable=["lora"]),
            PhaseSpec(step=100, trainable=["router"]),
        ])
        model = MockModel(num_layers=1)
        scheduler.maybe_step(model, 0)

        info = scheduler.get_phase_info()
        assert info["phase_idx"] == 0
        assert info["num_phases"] == 2
        assert info["current_phase"]["trainable"] == ["lora"]

    def test_num_phases(self):
        scheduler = UniversalPhaseScheduler(phases=[
            PhaseSpec(step=0, trainable=["lora"]),
            PhaseSpec(step=10, trainable=["router"]),
            PhaseSpec(step=20, trainable=["lora", "router"]),
        ])
        assert scheduler.num_phases == 3



# ===========================================================================
# Group resolver tests
# ===========================================================================

class TestGroupResolver:
    def test_known_groups_exist(self):
        assert "lora" in KNOWN_GROUPS
        assert "router" in KNOWN_GROUPS
        assert "base_ffn" in KNOWN_GROUPS
        assert "attn_lora" in KNOWN_GROUPS

    def test_extract_layer_index(self):
        assert _extract_layer_index("model.layers.5.mlp.gate_proj.weight") == 5
        assert _extract_layer_index("model.layers.0.q_proj.lora_a") == 0
        assert _extract_layer_index("embedding.weight") is None
        assert _extract_layer_index("model.layers.abc.mlp") is None

    def test_is_attn_path(self):
        assert _is_attn_path("model.layers.0.q_proj.lora_a") is True
        assert _is_attn_path("model.layers.0.k_proj.weight") is True
        assert _is_attn_path("model.layers.0.mlp.gate_proj.weight") is False

    def test_resolve_lora_params(self):
        model = MockModel(num_layers=1, use_moe=False)
        groups = resolve_param_groups(model)

        assert len(groups["lora"]) > 0, "Should find LoRA params in FFN"
        # Attn LoRA should also be detected
        assert len(groups["attn_lora"]) > 0, "Should find attn LoRA params"

    def test_resolve_router_params_moe_model(self):
        model = MockModel(num_layers=1, use_moe=True, num_experts=2)
        groups = resolve_param_groups(model)
        assert len(groups["router"]) > 0, "Should find router params in MoE model"

    def test_resolve_base_ffn_params_moe_model(self):
        model = MockModel(num_layers=1, use_moe=True, num_experts=2)
        groups = resolve_param_groups(model)
        assert len(groups["base_ffn"]) > 0, "Should find base FFN params in MoE model"

    def test_set_trainable_replace_mode(self):
        model = MockModel(num_layers=1, use_moe=False)
        # Make all trainable first
        for p in model.parameters():
            p.requires_grad = True

        count = set_trainable_by_groups(model, ["lora"], mode="replace")
        assert count > 0

        # Verify only lora params are trainable
        for name, param in model.named_parameters():
            if param.requires_grad:
                ln = name.lower()
                assert "lora" in ln, f"Non-lora param should be frozen: {name}"

    def test_set_trainable_add_mode(self):
        model = MockModel(num_layers=1, use_moe=True)
        # Freeze all first
        for p in model.parameters():
            p.requires_grad = False

        # Set lora trainable in replace mode
        set_trainable_by_groups(model, ["lora"], mode="replace")
        lora_count = sum(1 for _, p in model.named_parameters() if p.requires_grad)

        # Now add router in add mode
        set_trainable_by_groups(model, ["router"], mode="add")
        total_count = sum(1 for _, p in model.named_parameters() if p.requires_grad)

        assert total_count >= lora_count, "Add mode should keep existing trainable + add new"

    def test_tag_based_resolution(self):
        """Tag-based resolution has highest priority."""
        model = nn.Sequential(nn.Linear(4, 4))
        # Tag a parameter
        for p in model.parameters():
            p._eulerforge_group = "router"

        groups = resolve_param_groups(model)
        assert len(groups["router"]) > 0


# ===========================================================================
# Builder tests (build_phase_schedule)
# ===========================================================================

class TestBuildPhaseSchedule:
    def test_new_declarative_phases(self):
        """New-style: training.phases list should compile into UniversalPhaseScheduler."""
        cfg = {
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["router"]},
                    {"step": 2000, "trainable": ["lora"]},
                    {"step": 8000, "trainable": ["lora", "router", "base_ffn"]},
                ],
            },
        }
        sched = build_phase_schedule(cfg)
        assert sched is not None
        assert isinstance(sched, UniversalPhaseScheduler)
        assert sched.num_phases == 3
        assert sched.phases[0].trainable == ["router"]
        assert sched.phases[1].trainable == ["lora"]
        assert set(sched.phases[2].trainable) == {"lora", "router", "base_ffn"}

    def test_new_phases_with_target_kwargs(self):
        cfg = {
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["lora"]},
                    {
                        "step": 100,
                        "trainable": ["base_ffn"],
                        "base_ffn_keywords": ["gate_proj", "up_proj"],
                        "target_layers": [0, 1],
                    },
                ],
            },
        }
        sched = build_phase_schedule(cfg)
        assert sched is not None
        assert sched.phases[1].base_ffn_keywords == ["gate_proj", "up_proj"]
        assert sched.phases[1].target_layers == [0, 1]

    def test_new_phases_with_mode(self):
        cfg = {
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["lora"]},
                    {"step": 100, "trainable": ["router"], "mode": "add"},
                ],
            },
        }
        sched = build_phase_schedule(cfg)
        assert sched.phases[1].mode == "add"

    def test_no_schedule_returns_none(self):
        cfg = {"training": {}}
        sched = build_phase_schedule(cfg)
        assert sched is None

    def test_no_phases_key_returns_none(self):
        cfg = {"training": {"lr": 1e-5}}
        sched = build_phase_schedule(cfg)
        assert sched is None

    def test_global_phase_target_kwargs(self):
        """phase_target_kwargs at training level should propagate to phases."""
        cfg = {
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["lora"]},
                    {"step": 100, "trainable": ["base_ffn"]},
                ],
                "phase_target_kwargs": {
                    "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"],
                    "target_layers": [8, 9, 10],
                },
            },
        }
        sched = build_phase_schedule(cfg)
        # The last phase with base_ffn should inherit global target kwargs
        assert sched.phases[1].base_ffn_keywords == ["gate_proj", "up_proj", "down_proj"]

