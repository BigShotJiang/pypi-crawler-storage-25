# tests/test_bench_local_model.py
# -*- coding: utf-8 -*-
"""
eulerforge bench — 로컬 모델 지원 유닛 테스트 (TDD RED→GREEN).

- TestResolveTargetModelDir: resolve_target_model_dir() 함수 (7 tests)
- TestBenchValidatorLocalModel: 새 validator 규칙 (11 tests)
- TestLocalHFClient: LocalHFClient mock 기반 (7 tests)
- TestBenchCLINewFlags: CLI 새 플래그 (8 tests)
- TestLoRAMerge: LoRA 체크포인트 병합 헬퍼 (8 tests)
- TestSequentialModelLoading: 순차 모델 로딩/언로드 (12 tests)
"""
from __future__ import annotations

import json
import os
import sys
from unittest import mock

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from eulerforge.cli.bench import (
    build_argparser,
    main,
    resolve_target_model_dir,
    validate_bench_config,
)
from eulerforge.utils.bench_client import (
    LocalHFClient,
    _find_lora_config,
    _find_resolved_config,
    _get_backbone_adapter,
    _reconstruct_moe_model,
    _reconstruct_mixture_lora_model,
    _merge_lora_state_dict,
    _merge_attention_lora_only,
    _load_state_dict_from_checkpoint,
    _dequantize_bnb_state_dict,
    _detect_moe_type,
    _merge_moe_expert_lora_state_dict,
    _merge_mixture_lora_state_dict,
    _normalize_merged_keys,
    _resize_embeddings_if_needed,
    _safe_torch_dtype,
)
from eulerforge.utils.validator import ConfigValidationError


# =========================================================================
# Fixtures
# =========================================================================
@pytest.fixture
def sft_jsonl(tmp_path):
    """SFT JSONL 임시 파일."""
    path = tmp_path / "sft.jsonl"
    items = [{"prompt": f"Q{i}", "response": f"A{i}"} for i in range(10)]
    with open(path, "w") as f:
        for item in items:
            f.write(json.dumps(item) + "\n")
    return str(path)


@pytest.fixture
def fake_model_dir(tmp_path):
    """config.json이 있는 가짜 HF 모델 디렉토리."""
    model_dir = tmp_path / "final"
    model_dir.mkdir()
    (model_dir / "config.json").write_text('{"model_type": "qwen2"}')
    return str(model_dir)


@pytest.fixture
def fake_output_dir(tmp_path):
    """학습 출력 루트 디렉토리 (final/ 포함)."""
    output_dir = tmp_path / "run_test"
    output_dir.mkdir()
    final_dir = output_dir / "final"
    final_dir.mkdir()
    (final_dir / "config.json").write_text('{"model_type": "qwen2"}')
    return str(output_dir)


@pytest.fixture
def valid_cfg_model(sft_jsonl):
    """기존 API 모델 방식 (model 필드)."""
    return {
        "bench": {
            "task": "sft",
            "data_path": sft_jsonl,
            "models": {
                "target": {
                    "provider": "ollama",
                    "model": "qwen3:0.6b",
                },
            },
        }
    }


@pytest.fixture
def valid_cfg_output_dir(sft_jsonl, fake_output_dir):
    """output_dir 방식 config."""
    return {
        "bench": {
            "task": "sft",
            "data_path": sft_jsonl,
            "models": {
                "target": {
                    "output_dir": fake_output_dir,
                    "checkpoint": "final",
                },
            },
        }
    }


@pytest.fixture
def valid_cfg_model_dir(sft_jsonl, fake_model_dir):
    """model_dir 방식 config."""
    return {
        "bench": {
            "task": "sft",
            "data_path": sft_jsonl,
            "models": {
                "target": {
                    "model_dir": fake_model_dir,
                },
            },
        }
    }


# =========================================================================
# TestResolveTargetModelDir
# =========================================================================
class TestResolveTargetModelDir:
    """resolve_target_model_dir() 함수 테스트 (7 tests)."""

    def test_resolves_final_dir(self, tmp_path):
        """checkpoint='final' → {output_dir}/final/ 반환."""
        final = tmp_path / "final"
        final.mkdir()
        result = resolve_target_model_dir(str(tmp_path), checkpoint="final")
        assert result == str(final)

    def test_resolves_checkpoint_best(self, tmp_path):
        """checkpoint='best' → {output_dir}/checkpoint-best/ 반환."""
        best = tmp_path / "checkpoint-best"
        best.mkdir()
        result = resolve_target_model_dir(str(tmp_path), checkpoint="best")
        assert result == str(best)

    def test_resolves_checkpoint_latest(self, tmp_path):
        """checkpoint='latest' → {output_dir}/checkpoint-latest/ 반환."""
        latest = tmp_path / "checkpoint-latest"
        latest.mkdir()
        result = resolve_target_model_dir(str(tmp_path), checkpoint="latest")
        assert result == str(latest)

    def test_resolves_newest_checkpoint_dir(self, tmp_path):
        """checkpoint='latest', checkpoint-latest 없을 때 → 최신 checkpoint-N/."""
        (tmp_path / "checkpoint-100").mkdir()
        (tmp_path / "checkpoint-200").mkdir()
        (tmp_path / "checkpoint-500").mkdir()
        result = resolve_target_model_dir(str(tmp_path), checkpoint="latest")
        assert result == str(tmp_path / "checkpoint-500")

    def test_raises_if_no_checkpoint_found_final(self, tmp_path):
        """checkpoint='final'이지만 final/ 없으면 에러."""
        with pytest.raises(ConfigValidationError, match="No checkpoint found"):
            resolve_target_model_dir(str(tmp_path), checkpoint="final")

    def test_raises_if_output_dir_not_exist(self, tmp_path):
        """output_dir 자체가 없으면 에러."""
        with pytest.raises(ConfigValidationError, match="output_dir not found"):
            resolve_target_model_dir(str(tmp_path / "nonexistent"), checkpoint="final")

    def test_default_checkpoint_is_final(self, tmp_path):
        """checkpoint 미지정 시 'final'이 기본값."""
        final = tmp_path / "final"
        final.mkdir()
        # checkpoint 기본값으로 호출
        result = resolve_target_model_dir(str(tmp_path))
        assert result == str(final)


# =========================================================================
# TestBenchValidatorLocalModel
# =========================================================================
class TestBenchValidatorLocalModel:
    """로컬 모델 관련 새 validator 규칙 테스트 (11 tests)."""

    def test_valid_model_api_still_works(self, valid_cfg_model):
        """기존 API 모델(model 필드) → 정상 통과."""
        validate_bench_config(valid_cfg_model)  # no raise

    def test_valid_output_dir(self, valid_cfg_output_dir):
        """output_dir만 있을 때 → 정상 통과."""
        validate_bench_config(valid_cfg_output_dir)  # no raise

    def test_valid_model_dir(self, valid_cfg_model_dir):
        """model_dir만 있을 때 → 정상 통과."""
        validate_bench_config(valid_cfg_model_dir)  # no raise

    def test_target_missing_all_raises(self, sft_jsonl):
        """model, output_dir, model_dir 모두 없음 → 에러."""
        cfg = {
            "bench": {
                "task": "sft",
                "data_path": sft_jsonl,
                "models": {"target": {}},
            }
        }
        with pytest.raises(ConfigValidationError, match="exactly one of"):
            validate_bench_config(cfg)

    def test_target_model_and_output_dir_mutual_exclusion(self, sft_jsonl, fake_output_dir):
        """model + output_dir 동시 설정 → 에러."""
        cfg = {
            "bench": {
                "task": "sft",
                "data_path": sft_jsonl,
                "models": {
                    "target": {
                        "model": "qwen3:0.6b",
                        "output_dir": fake_output_dir,
                    }
                },
            }
        }
        with pytest.raises(ConfigValidationError, match="exactly one of"):
            validate_bench_config(cfg)

    def test_target_model_dir_and_output_dir_mutual_exclusion(self, sft_jsonl, fake_output_dir, fake_model_dir):
        """model_dir + output_dir 동시 설정 → 에러."""
        cfg = {
            "bench": {
                "task": "sft",
                "data_path": sft_jsonl,
                "models": {
                    "target": {
                        "model_dir": fake_model_dir,
                        "output_dir": fake_output_dir,
                    }
                },
            }
        }
        with pytest.raises(ConfigValidationError, match="exactly one of"):
            validate_bench_config(cfg)

    def test_local_hf_provider_accepted(self, sft_jsonl, fake_model_dir):
        """provider='local_hf' + model_dir → 정상 통과."""
        cfg = {
            "bench": {
                "task": "sft",
                "data_path": sft_jsonl,
                "models": {
                    "target": {
                        "provider": "local_hf",
                        "model_dir": fake_model_dir,
                    }
                },
            }
        }
        validate_bench_config(cfg)  # no raise

    def test_api_model_with_wrong_local_provider_raises(self, sft_jsonl):
        """model 필드 + provider='local_hf' → 에러."""
        cfg = {
            "bench": {
                "task": "sft",
                "data_path": sft_jsonl,
                "models": {
                    "target": {
                        "model": "qwen3:0.6b",
                        "provider": "local_hf",
                    }
                },
            }
        }
        with pytest.raises(ConfigValidationError, match="Unknown provider"):
            validate_bench_config(cfg)

    def test_local_dir_with_api_provider_raises(self, sft_jsonl, fake_model_dir):
        """model_dir + provider='ollama' → 에러 (local_hf여야 함)."""
        cfg = {
            "bench": {
                "task": "sft",
                "data_path": sft_jsonl,
                "models": {
                    "target": {
                        "model_dir": fake_model_dir,
                        "provider": "ollama",
                    }
                },
            }
        }
        with pytest.raises(ConfigValidationError, match="provider must be 'local_hf'"):
            validate_bench_config(cfg)

    def test_invalid_checkpoint_value_raises(self, sft_jsonl, fake_output_dir):
        """checkpoint='unknown' → 에러."""
        cfg = {
            "bench": {
                "task": "sft",
                "data_path": sft_jsonl,
                "models": {
                    "target": {
                        "output_dir": fake_output_dir,
                        "checkpoint": "unknown",
                    }
                },
            }
        }
        with pytest.raises(ConfigValidationError, match="Unknown checkpoint"):
            validate_bench_config(cfg)

    def test_model_dir_nonexistent_raises(self, sft_jsonl, tmp_path):
        """model_dir가 존재하지 않으면 에러."""
        cfg = {
            "bench": {
                "task": "sft",
                "data_path": sft_jsonl,
                "models": {
                    "target": {
                        "model_dir": str(tmp_path / "nonexistent"),
                    }
                },
            }
        }
        with pytest.raises(ConfigValidationError, match="model_dir not found"):
            validate_bench_config(cfg)

    def test_valid_export_dir(self, sft_jsonl, tmp_path):
        """export_dir만 있을 때 → 정상 통과."""
        export_dir = tmp_path / "exported_model"
        export_dir.mkdir()
        (export_dir / "config.json").write_text('{"model_type": "qwen2"}')
        cfg = {
            "bench": {
                "task": "sft",
                "data_path": sft_jsonl,
                "models": {
                    "target": {
                        "export_dir": str(export_dir),
                    }
                },
            }
        }
        validate_bench_config(cfg)  # no raise

    def test_export_dir_nonexistent_raises(self, sft_jsonl, tmp_path):
        """export_dir가 존재하지 않으면 에러."""
        cfg = {
            "bench": {
                "task": "sft",
                "data_path": sft_jsonl,
                "models": {
                    "target": {
                        "export_dir": str(tmp_path / "nonexistent_export"),
                    }
                },
            }
        }
        with pytest.raises(ConfigValidationError, match="export_dir not found"):
            validate_bench_config(cfg)

    def test_export_dir_and_model_dir_mutual_exclusion(self, sft_jsonl, tmp_path, fake_model_dir):
        """export_dir + model_dir 동시 설정 → 에러."""
        export_dir = tmp_path / "exported"
        export_dir.mkdir()
        cfg = {
            "bench": {
                "task": "sft",
                "data_path": sft_jsonl,
                "models": {
                    "target": {
                        "export_dir": str(export_dir),
                        "model_dir": fake_model_dir,
                    }
                },
            }
        }
        with pytest.raises(ConfigValidationError, match="exactly one of"):
            validate_bench_config(cfg)


# =========================================================================
# TestLocalHFClient
# =========================================================================
class TestLocalHFClient:
    """LocalHFClient mock 기반 테스트 (7 tests)."""

    def _make_mock_model_dir(self, tmp_path):
        d = tmp_path / "fake_model"
        d.mkdir()
        (d / "config.json").write_text('{"model_type": "qwen2"}')
        return str(d)

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    def test_local_hf_client_init(self, mock_model_cls, mock_tok_cls, tmp_path):
        """LocalHFClient 초기화 시 from_pretrained 호출 확인."""
        model_dir = self._make_mock_model_dir(tmp_path)
        mock_model_cls.from_pretrained.return_value = mock.MagicMock()
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        client = LocalHFClient(model_dir=model_dir)

        mock_model_cls.from_pretrained.assert_called_once()
        mock_tok_cls.from_pretrained.assert_called_once_with(model_dir)

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    def test_local_hf_client_chat(self, mock_model_cls, mock_tok_cls, tmp_path):
        """chat() 호출 시 tokenizer + model.generate() 사용."""
        import torch
        model_dir = self._make_mock_model_dir(tmp_path)

        mock_model = mock.MagicMock()
        mock_model.device = "cpu"
        mock_tokenizer = mock.MagicMock()
        mock_model_cls.from_pretrained.return_value = mock_model
        mock_tok_cls.from_pretrained.return_value = mock_tokenizer

        # tokenizer mock 설정
        mock_tokenizer.apply_chat_template.return_value = "Hello"
        input_ids = torch.zeros((1, 3), dtype=torch.long)
        mock_tokenizer.return_value = {"input_ids": input_ids}
        mock_tokenizer.decode.return_value = "World"

        # model.generate mock
        output_ids = torch.zeros((1, 5), dtype=torch.long)
        mock_model.generate.return_value = output_ids

        client = LocalHFClient(model_dir=model_dir)
        result = client.chat([{"role": "user", "content": "Hello"}])

        assert isinstance(result, str)
        mock_tokenizer.apply_chat_template.assert_called_once()
        mock_model.generate.assert_called_once()

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    def test_from_config_with_model_dir(self, mock_model_cls, mock_tok_cls, tmp_path):
        """from_config: model_dir 필드 → LocalHFClient 생성."""
        model_dir = self._make_mock_model_dir(tmp_path)
        mock_model_cls.from_pretrained.return_value = mock.MagicMock()
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        client = LocalHFClient.from_config({"model_dir": model_dir})
        assert client.model_dir == model_dir

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    def test_from_config_with_output_dir(self, mock_model_cls, mock_tok_cls, tmp_path):
        """from_config: output_dir 필드 → LocalHFClient 생성 (이미 해석된 경로)."""
        model_dir = self._make_mock_model_dir(tmp_path)
        mock_model_cls.from_pretrained.return_value = mock.MagicMock()
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        # output_dir 필드는 이미 resolve된 model_dir로 전달됨
        client = LocalHFClient.from_config({"model_dir": model_dir, "device": "cpu"})
        assert client.model_dir == model_dir

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    def test_device_passed_to_from_pretrained(self, mock_model_cls, mock_tok_cls, tmp_path):
        """device 파라미터가 from_pretrained에 전달됨."""
        model_dir = self._make_mock_model_dir(tmp_path)
        mock_model_cls.from_pretrained.return_value = mock.MagicMock()
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        LocalHFClient(model_dir=model_dir, device="cpu")

        call_kwargs = mock_model_cls.from_pretrained.call_args[1]
        assert call_kwargs.get("device_map") == "cpu"

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    def test_chat_respects_max_new_tokens(self, mock_model_cls, mock_tok_cls, tmp_path):
        """generation_cfg.max_new_tokens가 generate에 전달됨."""
        import torch
        model_dir = self._make_mock_model_dir(tmp_path)

        mock_model = mock.MagicMock()
        mock_model.device = "cpu"
        mock_tokenizer = mock.MagicMock()
        mock_model_cls.from_pretrained.return_value = mock_model
        mock_tok_cls.from_pretrained.return_value = mock_tokenizer

        mock_tokenizer.apply_chat_template.return_value = "Q"
        input_ids = torch.zeros((1, 2), dtype=torch.long)
        mock_tokenizer.return_value = {"input_ids": input_ids}
        mock_tokenizer.decode.return_value = "A"
        output_ids = torch.zeros((1, 4), dtype=torch.long)
        mock_model.generate.return_value = output_ids

        client = LocalHFClient(model_dir=model_dir)
        client.chat(
            [{"role": "user", "content": "Q"}],
            generation_cfg={"max_new_tokens": 256},
        )

        gen_kwargs = mock_model.generate.call_args[1]
        assert gen_kwargs.get("max_new_tokens") == 256

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    def test_chat_fallback_no_chat_template(self, mock_model_cls, mock_tok_cls, tmp_path):
        """chat_template 없는 pretrained 모델 → 단순 텍스트 연결 fallback."""
        import torch
        model_dir = self._make_mock_model_dir(tmp_path)

        mock_model = mock.MagicMock()
        mock_model.device = "cpu"
        mock_tokenizer = mock.MagicMock()
        mock_tokenizer.chat_template = None  # pretrained 모델
        mock_model_cls.from_pretrained.return_value = mock_model
        mock_tok_cls.from_pretrained.return_value = mock_tokenizer

        input_ids = torch.zeros((1, 3), dtype=torch.long)
        mock_tokenizer.return_value = {"input_ids": input_ids}
        mock_tokenizer.decode.return_value = "답변"
        output_ids = torch.zeros((1, 5), dtype=torch.long)
        mock_model.generate.return_value = output_ids

        client = LocalHFClient(model_dir=model_dir)
        messages = [
            {"role": "system", "content": "시스템 프롬프트"},
            {"role": "user", "content": "질문"},
        ]
        result = client.chat(messages)

        assert isinstance(result, str)
        # apply_chat_template이 호출되지 않아야 함
        mock_tokenizer.apply_chat_template.assert_not_called()
        # tokenizer가 fallback 텍스트로 호출됨
        call_args = mock_tokenizer.call_args
        text_input = call_args[0][0] if call_args[0] else call_args[1].get("text", "")
        assert "[SYSTEM]" in text_input
        assert "[USER]" in text_input
        assert "[ASSISTANT]" in text_input

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    def test_local_hf_client_sets_eval_mode(self, mock_model_cls, mock_tok_cls, tmp_path):
        """LocalHFClient 초기화 후 모델이 eval 모드로 전환된다."""
        model_dir = self._make_mock_model_dir(tmp_path)
        mock_model = mock.MagicMock()
        mock_model_cls.from_pretrained.return_value = mock_model
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        LocalHFClient(model_dir=model_dir)
        mock_model.eval.assert_called()

    def test_local_hf_client_in_valid_providers(self):
        """'local_hf'가 _VALID_PROVIDERS에 포함됨."""
        from eulerforge.utils.bench_client import _VALID_PROVIDERS
        assert "local_hf" in _VALID_PROVIDERS


# =========================================================================
# TestBenchCLINewFlags
# =========================================================================
class TestBenchCLINewFlags:
    """CLI 새 플래그 테스트 (12 tests)."""

    def test_help_shows_target_output_dir(self, capsys):
        """--help 출력에 --target-output-dir 표시."""
        parser = build_argparser()
        with pytest.raises(SystemExit) as exc:
            parser.parse_args(["--help"])
        assert exc.value.code == 0
        out = capsys.readouterr().out
        assert "--target-output-dir" in out

    def test_help_shows_target_model_dir(self, capsys):
        """--help 출력에 --target-model-dir 표시."""
        parser = build_argparser()
        with pytest.raises(SystemExit) as exc:
            parser.parse_args(["--help"])
        assert exc.value.code == 0
        out = capsys.readouterr().out
        assert "--target-model-dir" in out

    def test_help_shows_checkpoint_flag(self, capsys):
        """--help 출력에 --checkpoint 표시."""
        parser = build_argparser()
        with pytest.raises(SystemExit) as exc:
            parser.parse_args(["--help"])
        assert exc.value.code == 0
        out = capsys.readouterr().out
        assert "--checkpoint" in out

    def test_parse_target_output_dir(self):
        """--target-output-dir 인수 파싱."""
        parser = build_argparser()
        args = parser.parse_args(["--preset", "spec.yml", "--target-output-dir", "outputs/run_abc"])
        assert args.target_output_dir == "outputs/run_abc"

    def test_parse_target_model_dir(self):
        """--target-model-dir 인수 파싱."""
        parser = build_argparser()
        args = parser.parse_args(["--preset", "spec.yml", "--target-model-dir", "outputs/run_abc/final"])
        assert args.target_model_dir == "outputs/run_abc/final"

    def test_parse_checkpoint_default(self):
        """--checkpoint 미지정 시 기본값 'final'."""
        parser = build_argparser()
        args = parser.parse_args(["--preset", "spec.yml"])
        assert args.checkpoint == "final"

    def test_parse_checkpoint_latest(self):
        """--checkpoint latest 파싱."""
        parser = build_argparser()
        args = parser.parse_args(["--preset", "spec.yml", "--checkpoint", "latest"])
        assert args.checkpoint == "latest"

    def test_help_shows_target_device(self, capsys):
        """--help 출력에 --target-device 표시."""
        parser = build_argparser()
        with pytest.raises(SystemExit) as exc:
            parser.parse_args(["--help"])
        assert exc.value.code == 0
        out = capsys.readouterr().out
        assert "--target-device" in out

    def test_parse_target_device(self):
        """--target-device 인수 파싱."""
        parser = build_argparser()
        args = parser.parse_args(["--preset", "spec.yml", "--target-device", "cuda:1"])
        assert args.target_device == "cuda:1"

    def test_parse_target_device_default_none(self):
        """--target-device 미지정 시 기본값 None."""
        parser = build_argparser()
        args = parser.parse_args(["--preset", "spec.yml"])
        assert args.target_device is None

    def test_target_device_overrides_yaml(self, fake_output_dir, tmp_path, capsys):
        """--target-device가 YAML의 device를 오버라이드."""
        import yaml
        yaml_path = tmp_path / "bench.yml"
        cfg = {
            "bench": {
                "task": "sft",
                "data_path": str(tmp_path / "data.jsonl"),
                "models": {"target": {"output_dir": fake_output_dir, "device": "auto"}},
            }
        }
        with open(tmp_path / "data.jsonl", "w") as f:
            for i in range(5):
                f.write(json.dumps({"prompt": f"Q{i}", "response": f"A{i}"}) + "\n")
        with open(yaml_path, "w") as f:
            yaml.dump(cfg, f)

        # --dry-run으로 실제 모델 로딩 없이 CLI 테스트
        main(["--preset", str(yaml_path), "--dry-run",
              "--target-device", "cuda:1"])
        out = capsys.readouterr().out
        assert "Dry-run" in out

    def test_target_output_dir_overrides_yaml(self, valid_cfg_output_dir, fake_output_dir, tmp_path, capsys):
        """--target-output-dir 가 YAML output_dir를 오버라이드."""
        import yaml
        yaml_path = tmp_path / "bench.yml"
        # YAML에 output_dir 없음 (target 비워둠)
        cfg = {
            "bench": {
                "task": "sft",
                "data_path": str(tmp_path / "data.jsonl"),
                "models": {"target": {"output_dir": fake_output_dir}},
            }
        }
        # 실제 data 파일 생성
        with open(tmp_path / "data.jsonl", "w") as f:
            for i in range(5):
                f.write(json.dumps({"prompt": f"Q{i}", "response": f"A{i}"}) + "\n")
        with open(yaml_path, "w") as f:
            yaml.dump(cfg, f)

        # --dry-run으로 실제 모델 로딩 없이 CLI 테스트
        main(["--preset", str(yaml_path), "--dry-run",
              "--target-output-dir", fake_output_dir,
              "--checkpoint", "final"])
        out = capsys.readouterr().out
        assert "Dry-run" in out


# =========================================================================
# TestLoRAMerge
# =========================================================================
class TestLoRAMerge:
    """LoRA 체크포인트 병합 헬퍼 테스트 (8 tests)."""

    def test_find_lora_config_from_lora_info_json(self, tmp_path):
        """model_dir/lora_info.json → {"lora_r", "lora_alpha"} 반환."""
        model_dir = tmp_path / "ckpt"
        model_dir.mkdir()
        (model_dir / "lora_info.json").write_text(
            json.dumps({"lora_r": 48, "lora_alpha": 96.0})
        )
        cfg = _find_lora_config(str(model_dir))
        assert cfg is not None
        assert cfg["lora_r"] == 48
        assert cfg["lora_alpha"] == 96.0

    def test_find_lora_config_from_resolved_config(self, tmp_path):
        """parent/resolved_config.json → LoRA 설정 추출."""
        parent = tmp_path / "run_abc"
        parent.mkdir()
        model_dir = parent / "final"
        model_dir.mkdir()
        resolved = {
            "injection": {
                "strategy": "dense_lora",
                "lora_r": 32,
                "lora_alpha": 64.0,
            }
        }
        (parent / "resolved_config.json").write_text(json.dumps(resolved))
        cfg = _find_lora_config(str(model_dir))
        assert cfg is not None
        assert cfg["lora_r"] == 32
        assert cfg["lora_alpha"] == 64.0

    def test_find_lora_config_lora_info_takes_priority(self, tmp_path):
        """lora_info.json이 있으면 resolved_config.json보다 우선."""
        parent = tmp_path / "run_abc"
        parent.mkdir()
        model_dir = parent / "final"
        model_dir.mkdir()
        # lora_info.json (r=16)
        (model_dir / "lora_info.json").write_text(
            json.dumps({"lora_r": 16, "lora_alpha": 32.0})
        )
        # resolved_config.json (r=64)
        (parent / "resolved_config.json").write_text(
            json.dumps({"injection": {"strategy": "dense_lora", "lora_r": 64, "lora_alpha": 128.0}})
        )
        cfg = _find_lora_config(str(model_dir))
        assert cfg["lora_r"] == 16  # lora_info.json 우선

    def test_find_lora_config_no_files_returns_none(self, tmp_path):
        """lora_info.json도 없고 resolved_config.json도 없으면 None."""
        model_dir = tmp_path / "plain_model"
        model_dir.mkdir()
        assert _find_lora_config(str(model_dir)) is None

    def test_find_lora_config_non_lora_strategy_returns_none(self, tmp_path):
        """strategy가 'lora'를 포함하지 않으면 None."""
        parent = tmp_path / "run_sft"
        parent.mkdir()
        model_dir = parent / "final"
        model_dir.mkdir()
        resolved = {
            "injection": {"strategy": "full_finetune", "lora_r": 0, "lora_alpha": 1.0}
        }
        (parent / "resolved_config.json").write_text(json.dumps(resolved))
        assert _find_lora_config(str(model_dir)) is None

    def test_merge_lora_state_dict_basic_formula(self):
        """기본 LoRA 병합: merged = base + (lora_B @ lora_A) * scaling."""
        import torch
        r, alpha = 2, 4.0
        scaling = alpha / r  # 2.0

        # 간단한 2×3 Linear (out=2, in=3, r=2)
        base_w = torch.ones(2, 3)          # base_layer.weight
        lora_a = torch.ones(r, 3) * 0.5   # lora_A: (r, in)
        lora_b = torch.ones(2, r) * 0.5   # lora_B: (out, r)

        sd = {
            "model.q_proj.base_layer.weight": base_w,
            "model.q_proj.lora_A": lora_a,
            "model.q_proj.lora_B": lora_b,
        }
        merged = _merge_lora_state_dict(sd, lora_r=r, lora_alpha=alpha)

        # delta = (lora_B @ lora_A) * 2.0 = (2×2 @ 2×3) * 2.0
        # lora_B @ lora_A = [[0.5,0.5],[0.5,0.5]] @ [[0.5,0.5,0.5],[0.5,0.5,0.5]]
        #                   = [[0.5,0.5,0.5],[0.5,0.5,0.5]]
        # delta = [[1.0,1.0,1.0],[1.0,1.0,1.0]]
        # merged = ones + delta = [[2.0,2.0,2.0],[2.0,2.0,2.0]]
        assert "model.q_proj.weight" in merged
        assert not any("base_layer" in k or "lora_A" in k or "lora_B" in k for k in merged)
        expected = torch.full((2, 3), 2.0)
        assert torch.allclose(merged["model.q_proj.weight"], expected)

    def test_merge_lora_state_dict_preserves_normal_keys(self):
        """LoRA가 아닌 일반 키는 그대로 유지."""
        import torch
        r, alpha = 4, 8.0
        sd = {
            "model.embed_tokens.weight": torch.eye(4),
            "model.norm.weight": torch.ones(4),
            "model.q_proj.base_layer.weight": torch.zeros(4, 4),
            "model.q_proj.lora_A": torch.zeros(r, 4),
            "model.q_proj.lora_B": torch.zeros(4, r),
        }
        merged = _merge_lora_state_dict(sd, lora_r=r, lora_alpha=alpha)

        assert "model.embed_tokens.weight" in merged
        assert "model.norm.weight" in merged
        assert "model.q_proj.weight" in merged
        assert len(merged) == 3

    def test_load_state_dict_from_checkpoint_returns_none_when_missing(self, tmp_path):
        """pytorch_model.bin도 model.safetensors도 없으면 None 반환."""
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()
        result = _load_state_dict_from_checkpoint(str(empty_dir))
        assert result is None

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    @mock.patch("eulerforge.loader.AutoConfig")
    @mock.patch("eulerforge.utils.bench_client._merge_lora_state_dict")
    @mock.patch("eulerforge.utils.bench_client._load_state_dict_from_checkpoint")
    @mock.patch("eulerforge.utils.bench_client._find_lora_config")
    def test_tie_weights_called_after_load_state_dict(
        self,
        mock_find_lora, mock_load_sd, mock_merge_sd,
        mock_config_cls, mock_model_cls, mock_tok_cls,
        tmp_path,
    ):
        """LoRA 병합 경로에서 load_state_dict 후 tie_weights()가 호출됨."""
        import torch

        model_dir = tmp_path / "fake_model"
        model_dir.mkdir()
        (model_dir / "config.json").write_text('{"model_type": "qwen2"}')
        mock_find_lora.return_value = {"lora_r": 8, "lora_alpha": 16.0}
        mock_load_sd.return_value = {"layer.lora_A": torch.zeros(4, 4)}
        mock_merge_sd.return_value = {"layer.weight": torch.zeros(4, 4)}

        mock_model = mock.MagicMock()
        mock_model.load_state_dict.return_value = ([], [])
        mock_model._tied_weights_keys = {}
        mock_model.to.return_value = mock_model
        mock_model_cls.from_config.return_value = mock_model
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        LocalHFClient(model_dir=str(model_dir), device="cpu")

        mock_model.tie_weights.assert_called_once()

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    @mock.patch("eulerforge.loader.AutoConfig")
    @mock.patch("eulerforge.utils.bench_client._merge_lora_state_dict")
    @mock.patch("eulerforge.utils.bench_client._load_state_dict_from_checkpoint")
    @mock.patch("eulerforge.utils.bench_client._find_lora_config")
    def test_lora_merge_no_warning_for_tied_keys(
        self,
        mock_find_lora, mock_load_sd, mock_merge_sd,
        mock_config_cls, mock_model_cls, mock_tok_cls,
        tmp_path, caplog,
    ):
        """lm_head.weight가 _tied_weights_keys에 있으면 WARNING이 아닌 DEBUG로 처리됨."""
        import logging
        import torch

        model_dir = tmp_path / "fake_model"
        model_dir.mkdir()
        (model_dir / "config.json").write_text('{"model_type": "qwen2"}')
        mock_find_lora.return_value = {"lora_r": 8, "lora_alpha": 16.0}
        mock_load_sd.return_value = {"layer.lora_A": torch.zeros(4, 4)}
        mock_merge_sd.return_value = {"layer.weight": torch.zeros(4, 4)}

        mock_model = mock.MagicMock()
        # load_state_dict이 tied key(lm_head.weight)를 missing으로 반환
        mock_model.load_state_dict.return_value = (["lm_head.weight"], [])
        mock_model._tied_weights_keys = {"lm_head.weight": "model.embed_tokens.weight"}
        mock_model.to.return_value = mock_model
        mock_model_cls.from_config.return_value = mock_model
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        with caplog.at_level(logging.DEBUG, logger="eulerforge.utils.bench_client"):
            LocalHFClient(model_dir=str(model_dir), device="cpu")

        warning_msgs = [
            r.message for r in caplog.records
            if r.levelno == logging.WARNING and "누락된 키" in str(r.message)
        ]
        assert not warning_msgs, f"tied key에 대해 불필요한 WARNING 발생: {warning_msgs}"


# =========================================================================
# TestMoEMerge
# =========================================================================
class TestMoEMerge:
    """MoE 체크포인트 병합 테스트 (12 tests)."""

    # ---- _detect_moe_type ----

    def test_detect_moe_type_moe_expert_lora(self):
        """mlp.experts.N.gate_proj 패턴 → 'moe_expert_lora'."""
        sd = {
            "model.layers.0.mlp.router.weight": None,
            "model.layers.0.mlp.experts.0.gate_proj.base_layer.weight": None,
            "model.layers.0.mlp.experts.0.gate_proj.lora_A": None,
        }
        assert _detect_moe_type(sd) == "moe_expert_lora"

    def test_detect_moe_type_mixture_lora(self):
        """gate_proj.experts.N.loraA 패턴 → 'mixture_lora'."""
        sd = {
            "model.layers.0.mlp.gate_proj.base_layer.weight": None,
            "model.layers.0.mlp.gate_proj.router.weight": None,
            "model.layers.0.mlp.gate_proj.experts.0.loraA": None,
        }
        assert _detect_moe_type(sd) == "mixture_lora"

    def test_detect_moe_type_dense_lora(self):
        """MoE 패턴 없으면 빈 문자열."""
        sd = {
            "model.layers.0.self_attn.q_proj.base_layer.weight": None,
            "model.layers.0.self_attn.q_proj.lora_A": None,
            "model.embed_tokens.weight": None,
        }
        assert _detect_moe_type(sd) == ""

    # ---- _merge_moe_expert_lora_state_dict ----

    def test_merge_ffn_moe_basic(self):
        """2 experts: LoRA 병합 후 평균 → 단일 FFN 가중치."""
        import torch
        r, alpha = 2, 4.0
        scaling = alpha / r  # 2.0

        # Expert 0: base=ones, lora_A=0.1*I, lora_B=0.1*I
        # Expert 1: base=ones, lora_A=0.3*I, lora_B=0.3*I
        base_0 = torch.ones(2, 2)
        a_0 = torch.eye(r) * 0.1
        b_0 = torch.eye(2) * 0.1

        base_1 = torch.ones(2, 2)
        a_1 = torch.eye(r) * 0.3
        b_1 = torch.eye(2) * 0.3

        sd = {
            "model.layers.0.mlp.router.weight": torch.randn(2, 2),
            "model.layers.0.mlp.router.bias": torch.randn(2),
            "model.layers.0.mlp.experts.0.gate_proj.base_layer.weight": base_0,
            "model.layers.0.mlp.experts.0.gate_proj.lora_A": a_0,
            "model.layers.0.mlp.experts.0.gate_proj.lora_B": b_0,
            "model.layers.0.mlp.experts.1.gate_proj.base_layer.weight": base_1,
            "model.layers.0.mlp.experts.1.gate_proj.lora_A": a_1,
            "model.layers.0.mlp.experts.1.gate_proj.lora_B": b_1,
            "model.norm.weight": torch.ones(2),
        }
        merged = _merge_moe_expert_lora_state_dict(sd, lora_r=r, lora_alpha=alpha)

        # Expert 0 merged: ones + (0.1I @ 0.1I)*2.0 = ones + 0.02*I
        # Expert 1 merged: ones + (0.3I @ 0.3I)*2.0 = ones + 0.18*I
        # Average: ones + (0.02+0.18)/2 * I = ones + 0.1*I
        assert "model.layers.0.mlp.gate_proj.weight" in merged
        expected = torch.ones(2, 2) + torch.eye(2) * 0.1
        assert torch.allclose(
            merged["model.layers.0.mlp.gate_proj.weight"], expected, atol=1e-5
        ), f"Got {merged['model.layers.0.mlp.gate_proj.weight']}"

    def test_merge_ffn_moe_drops_router(self):
        """병합 결과에 router 키가 없어야 한다."""
        import torch
        sd = {
            "model.layers.0.mlp.router.weight": torch.randn(2, 4),
            "model.layers.0.mlp.router.bias": torch.randn(2),
            "model.layers.0.mlp.experts.0.gate_proj.base_layer.weight": torch.ones(2, 4),
            "model.layers.0.mlp.experts.0.gate_proj.lora_A": torch.zeros(2, 4),
            "model.layers.0.mlp.experts.0.gate_proj.lora_B": torch.zeros(2, 2),
        }
        merged = _merge_moe_expert_lora_state_dict(sd, lora_r=2, lora_alpha=4.0)
        assert not any("router" in k for k in merged)

    def test_merge_ffn_moe_preserves_non_moe_keys(self):
        """embed_tokens, layernorm 등 비-MoE 키는 그대로 유지."""
        import torch
        sd = {
            "model.embed_tokens.weight": torch.eye(4),
            "model.layers.0.input_layernorm.weight": torch.ones(4),
            "model.layers.0.mlp.router.weight": torch.randn(2, 4),
            "model.layers.0.mlp.experts.0.gate_proj.base_layer.weight": torch.ones(2, 4),
            "model.layers.0.mlp.experts.0.gate_proj.lora_A": torch.zeros(2, 4),
            "model.layers.0.mlp.experts.0.gate_proj.lora_B": torch.zeros(2, 2),
        }
        merged = _merge_moe_expert_lora_state_dict(sd, lora_r=2, lora_alpha=4.0)
        assert "model.embed_tokens.weight" in merged
        assert "model.layers.0.input_layernorm.weight" in merged
        assert torch.equal(merged["model.embed_tokens.weight"], torch.eye(4))

    def test_merge_ffn_moe_handles_attn_lora(self):
        """어텐션 LoRA는 기존 방식으로 병합 (base + delta)."""
        import torch
        r, alpha = 2, 4.0
        scaling = alpha / r  # 2.0

        base_w = torch.ones(2, 2)
        a = torch.eye(r) * 0.5
        b = torch.eye(2) * 0.5

        sd = {
            "model.layers.0.self_attn.q_proj.base_layer.weight": base_w,
            "model.layers.0.self_attn.q_proj.lora_A": a,
            "model.layers.0.self_attn.q_proj.lora_B": b,
        }
        merged = _merge_moe_expert_lora_state_dict(sd, lora_r=r, lora_alpha=alpha)

        # merged = ones + (0.5I @ 0.5I) * 2.0 = ones + 0.5*I
        assert "model.layers.0.self_attn.q_proj.weight" in merged
        expected = torch.ones(2, 2) + torch.eye(2) * 0.5
        assert torch.allclose(
            merged["model.layers.0.self_attn.q_proj.weight"], expected, atol=1e-5
        )

    def test_merge_ffn_moe_no_unexpected_keys(self):
        """병합 결과에 base_layer, lora_A, lora_B, experts, router 키가 없어야 한다."""
        import torch
        sd = {
            "model.layers.0.mlp.router.weight": torch.randn(2, 2),
            "model.layers.0.mlp.experts.0.gate_proj.base_layer.weight": torch.ones(2, 2),
            "model.layers.0.mlp.experts.0.gate_proj.lora_A": torch.zeros(2, 2),
            "model.layers.0.mlp.experts.0.gate_proj.lora_B": torch.zeros(2, 2),
            "model.layers.0.self_attn.q_proj.base_layer.weight": torch.ones(2, 2),
            "model.layers.0.self_attn.q_proj.lora_A": torch.zeros(2, 2),
            "model.layers.0.self_attn.q_proj.lora_B": torch.zeros(2, 2),
            "model.embed_tokens.weight": torch.eye(2),
        }
        merged = _merge_moe_expert_lora_state_dict(sd, lora_r=2, lora_alpha=4.0)
        for k in merged:
            assert "base_layer" not in k, f"Unexpected base_layer key: {k}"
            assert "lora_A" not in k, f"Unexpected lora_A key: {k}"
            assert "lora_B" not in k, f"Unexpected lora_B key: {k}"
            assert "experts" not in k, f"Unexpected experts key: {k}"
            assert "router" not in k, f"Unexpected router key: {k}"

    # ---- _merge_mixture_lora_state_dict ----

    def test_merge_mixture_lora_basic(self):
        """mixture_lora: expert LoRA 평균 후 base에 합산."""
        import torch
        r, alpha = 2, 4.0
        scaling = alpha / r  # 2.0

        base_w = torch.ones(2, 2)
        # Expert 0: loraA=0.1*I, loraB=0.1*I → delta = 0.01*I * 2.0 = 0.02*I
        # Expert 1: loraA=0.3*I, loraB=0.3*I → delta = 0.09*I * 2.0 = 0.18*I
        # Average delta = (0.02+0.18)/2 * I = 0.1*I
        sd = {
            "model.layers.0.mlp.gate_proj.base_layer.weight": base_w,
            "model.layers.0.mlp.gate_proj.router.weight": torch.randn(2, 2),
            "model.layers.0.mlp.gate_proj.router.bias": torch.randn(2),
            "model.layers.0.mlp.gate_proj.experts.0.loraA": torch.eye(r) * 0.1,
            "model.layers.0.mlp.gate_proj.experts.0.loraB": torch.eye(2) * 0.1,
            "model.layers.0.mlp.gate_proj.experts.1.loraA": torch.eye(r) * 0.3,
            "model.layers.0.mlp.gate_proj.experts.1.loraB": torch.eye(2) * 0.3,
        }
        merged = _merge_mixture_lora_state_dict(sd, lora_r=r, lora_alpha=alpha)

        assert "model.layers.0.mlp.gate_proj.weight" in merged
        expected = torch.ones(2, 2) + torch.eye(2) * 0.1
        assert torch.allclose(
            merged["model.layers.0.mlp.gate_proj.weight"], expected, atol=1e-5
        )
        assert not any("router" in k or "experts" in k for k in merged)

    def test_merge_mixture_lora_no_or_true_bug(self):
        """mixture_lora: base_layer.weight 분류에서 or True 버그 없어야 함.

        Bug: `if condition and prefix in mlora_data or True:` → 항상 True
        Fix: `if condition and prefix in mlora_data:` — MixtureLoRA projection만 attn_base로
        """
        import torch
        r, alpha = 2, 4.0
        sd = {
            # FFN MixtureLoRA (should go to attn_base)
            "model.layers.0.mlp.gate_proj.base_layer.weight": torch.ones(2, 2),
            "model.layers.0.mlp.gate_proj.router.weight": torch.randn(2, 2),
            "model.layers.0.mlp.gate_proj.experts.0.loraA": torch.eye(r) * 0.1,
            "model.layers.0.mlp.gate_proj.experts.0.loraB": torch.eye(2) * 0.1,
            # Non-LoRA normal weight (should go to normal, NOT attn_base)
            "model.embed_tokens.weight": torch.randn(100, 64),
        }
        merged = _merge_mixture_lora_state_dict(sd, lora_r=r, lora_alpha=alpha)

        # embed_tokens.weight는 그대로 보존되어야 함 (MixtureLoRA merge 대상이 아님)
        assert "model.embed_tokens.weight" in merged

    def test_merge_mixture_lora_bias_no_duplicate(self):
        """mixture_lora: base_layer.bias가 중복 키 없이 .bias로만 변환.

        Bug: continue 누락 → .base_layer.bias와 .bias 둘 다 출력
        Fix: bias 처리 후 continue
        """
        import torch
        r, alpha = 2, 4.0
        sd = {
            "model.layers.0.self_attn.q_proj.base_layer.weight": torch.ones(4, 4),
            "model.layers.0.self_attn.q_proj.base_layer.bias": torch.ones(4) * 0.5,
            "model.layers.0.self_attn.q_proj.lora_A": torch.randn(r, 4),
            "model.layers.0.self_attn.q_proj.lora_B": torch.randn(4, r),
        }
        merged = _merge_mixture_lora_state_dict(sd, lora_r=r, lora_alpha=alpha)

        # .bias는 존재해야 함
        assert "model.layers.0.self_attn.q_proj.bias" in merged
        # .base_layer.bias는 존재하면 안 됨 (중복)
        assert "model.layers.0.self_attn.q_proj.base_layer.bias" not in merged

    def test_merge_lora_partial_warns(self):
        """lora_A만 있고 lora_B 없을 때 base weight만 사용 (silent drop 방지)."""
        import torch
        from eulerforge.utils.bench_client import _merge_lora_state_dict

        sd = {
            "model.layers.0.mlp.gate_proj.base_layer.weight": torch.ones(4, 4),
            "model.layers.0.mlp.gate_proj.lora_A": torch.randn(2, 4),
            # lora_B 누락!
        }
        merged = _merge_lora_state_dict(sd, lora_r=2, lora_alpha=4.0)
        # base weight만 반환 (LoRA delta 없이)
        assert "model.layers.0.mlp.gate_proj.weight" in merged
        torch.testing.assert_close(
            merged["model.layers.0.mlp.gate_proj.weight"],
            torch.ones(4, 4),
        )

    # ---- _find_lora_config with strategy ----

    def test_find_lora_config_includes_strategy(self, tmp_path):
        """lora_info.json에 strategy 포함 시 반환값에 strategy 포함."""
        model_dir = tmp_path / "ckpt"
        model_dir.mkdir()
        (model_dir / "lora_info.json").write_text(
            json.dumps({"lora_r": 48, "lora_alpha": 96.0, "strategy": "moe_expert_lora"})
        )
        cfg = _find_lora_config(str(model_dir))
        assert cfg is not None
        assert cfg.get("strategy") == "moe_expert_lora"

    def test_find_lora_config_resolved_includes_strategy(self, tmp_path):
        """resolved_config.json → strategy도 추출."""
        parent = tmp_path / "run"
        parent.mkdir()
        model_dir = parent / "final"
        model_dir.mkdir()
        resolved = {
            "injection": {
                "strategy": "mixture_lora",
                "lora_r": 48,
                "lora_alpha": 96.0,
            }
        }
        (parent / "resolved_config.json").write_text(json.dumps(resolved))
        cfg = _find_lora_config(str(model_dir))
        assert cfg is not None
        assert cfg.get("strategy") == "mixture_lora"

    # ---- LocalHFClient MoE branch ----

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.utils.bench_client._reconstruct_moe_model")
    @mock.patch("eulerforge.utils.bench_client._load_state_dict_from_checkpoint")
    @mock.patch("eulerforge.utils.bench_client._find_lora_config")
    def test_local_hf_client_uses_moe_reconstruct_for_ffn_moe(
        self,
        mock_find_lora, mock_load_sd, mock_reconstruct,
        mock_tok_cls,
        tmp_path,
    ):
        """moe_expert_lora + resolved_config → _reconstruct_moe_model 호출."""
        import torch

        # Parent dir with resolved_config.json
        run_dir = tmp_path / "run_test"
        run_dir.mkdir()
        model_dir = run_dir / "final"
        model_dir.mkdir()
        (model_dir / "config.json").write_text('{"model_type": "qwen2"}')
        resolved = {
            "backbone": "qwen3",
            "injection": {
                "strategy": "moe_expert_lora",
                "num_experts": 4, "top_k": 2,
                "start_layer": 0, "num_layers": 0,
                "lora_r": 48, "lora_alpha": 96.0,
            },
        }
        (run_dir / "resolved_config.json").write_text(json.dumps(resolved))

        mock_find_lora.return_value = {
            "lora_r": 48, "lora_alpha": 96.0, "strategy": "moe_expert_lora"
        }
        mock_load_sd.return_value = {
            "model.layers.0.mlp.experts.0.gate_proj.lora_A": torch.zeros(4, 4),
            "model.layers.0.mlp.experts.0.gate_proj.base_layer.weight": torch.zeros(4, 4),
        }
        mock_reconstruct.return_value = mock.MagicMock()
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        LocalHFClient(model_dir=str(model_dir), device="cpu")

        mock_reconstruct.assert_called_once()
        # _merge_moe_expert_lora_state_dict should NOT have been called

    # ---- Handoff: experts with plain weight (no LoRA wrapper) ----

    def test_detect_moe_type_handoff_plain_experts(self):
        """Handoff 후 plain expert 키 → 'moe_expert_lora' 감지."""
        sd = {
            "model.layers.19.mlp.router.weight": None,
            "model.layers.19.mlp.experts.0.gate_proj.weight": None,  # plain, no base_layer
            "model.layers.19.mlp.experts.1.gate_proj.weight": None,
        }
        assert _detect_moe_type(sd) == "moe_expert_lora"

    def test_merge_ffn_moe_handoff_plain_experts(self):
        """Handoff 후: expert 키가 plain .weight (base_layer 없음) → 정상 평균."""
        import torch
        sd = {
            "model.layers.0.mlp.router.weight": torch.randn(2, 2),
            "model.layers.0.mlp.router.bias": torch.randn(2),
            "model.layers.0.mlp.experts.0.gate_proj.weight": torch.ones(2, 2) * 1.0,
            "model.layers.0.mlp.experts.1.gate_proj.weight": torch.ones(2, 2) * 3.0,
            "model.norm.weight": torch.ones(2),
        }
        merged = _merge_moe_expert_lora_state_dict(sd, lora_r=2, lora_alpha=4.0)

        # Average of [1.0, 3.0] = 2.0
        assert "model.layers.0.mlp.gate_proj.weight" in merged
        expected = torch.ones(2, 2) * 2.0
        assert torch.allclose(
            merged["model.layers.0.mlp.gate_proj.weight"], expected, atol=1e-5
        )
        # No expert or router keys remain
        assert not any("experts" in k or "router" in k for k in merged)

    def test_merge_ffn_moe_handoff_mixed_lora_and_plain(self):
        """Handoff 부분 완료: expert는 plain, attn은 LoRA 래핑 → 둘 다 처리."""
        import torch
        r, alpha = 2, 4.0

        sd = {
            # Expert: plain weight (LoRA 제거됨)
            "model.layers.0.mlp.router.weight": torch.randn(2, 2),
            "model.layers.0.mlp.experts.0.gate_proj.weight": torch.ones(2, 2),
            "model.layers.0.mlp.experts.1.gate_proj.weight": torch.ones(2, 2) * 2.0,
            # Attention: LoRA still present
            "model.layers.0.self_attn.q_proj.base_layer.weight": torch.ones(2, 2),
            "model.layers.0.self_attn.q_proj.lora_A": torch.eye(r) * 0.5,
            "model.layers.0.self_attn.q_proj.lora_B": torch.eye(2) * 0.5,
        }
        merged = _merge_moe_expert_lora_state_dict(sd, lora_r=r, lora_alpha=alpha)

        # Expert average: (1.0 + 2.0) / 2 = 1.5
        assert "model.layers.0.mlp.gate_proj.weight" in merged
        assert torch.allclose(
            merged["model.layers.0.mlp.gate_proj.weight"],
            torch.ones(2, 2) * 1.5, atol=1e-5
        )
        # Attention LoRA merged: ones + (0.5I @ 0.5I) * 2.0 = ones + 0.5*I
        assert "model.layers.0.self_attn.q_proj.weight" in merged
        expected_attn = torch.ones(2, 2) + torch.eye(2) * 0.5
        assert torch.allclose(
            merged["model.layers.0.self_attn.q_proj.weight"], expected_attn, atol=1e-5
        )
        # No unexpected keys
        for k in merged:
            assert "base_layer" not in k
            assert "lora_A" not in k
            assert "experts" not in k
            assert "router" not in k

    def test_merge_ffn_moe_handoff_no_unexpected_keys(self):
        """Handoff 후 병합 결과에 experts, router, base_layer 키 없음."""
        import torch
        sd = {
            "model.layers.0.mlp.router.weight": torch.randn(2, 2),
            "model.layers.0.mlp.experts.0.gate_proj.weight": torch.ones(2, 2),
            "model.layers.0.mlp.experts.0.up_proj.weight": torch.ones(2, 2),
            "model.layers.0.mlp.experts.0.down_proj.weight": torch.ones(2, 2),
            "model.embed_tokens.weight": torch.eye(2),
        }
        merged = _merge_moe_expert_lora_state_dict(sd, lora_r=2, lora_alpha=4.0)
        for k in merged:
            assert "experts" not in k, f"Unexpected experts key: {k}"
            assert "router" not in k, f"Unexpected router key: {k}"

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.utils.bench_client._reconstruct_moe_model")
    @mock.patch("eulerforge.utils.bench_client._load_state_dict_from_checkpoint")
    @mock.patch("eulerforge.utils.bench_client._find_lora_config")
    def test_local_hf_client_handoff_no_lora_keys(
        self,
        mock_find_lora, mock_load_sd, mock_reconstruct,
        mock_tok_cls,
        tmp_path,
    ):
        """Handoff 완료 (LoRA 키 없음, expert 구조만) → MoE 재구성 경로 진입."""
        import torch

        run_dir = tmp_path / "run_test"
        run_dir.mkdir()
        model_dir = run_dir / "final"
        model_dir.mkdir()
        (model_dir / "config.json").write_text('{"model_type": "qwen2"}')
        resolved = {
            "backbone": "qwen3",
            "injection": {
                "strategy": "moe_expert_lora",
                "num_experts": 4, "top_k": 2,
                "start_layer": 0, "num_layers": 0,
            },
        }
        (run_dir / "resolved_config.json").write_text(json.dumps(resolved))

        mock_find_lora.return_value = {
            "lora_r": 48, "lora_alpha": 96.0, "strategy": "moe_expert_lora"
        }
        # No lora_A/lora_B keys, but has expert structure
        mock_load_sd.return_value = {
            "model.layers.0.mlp.experts.0.gate_proj.weight": torch.zeros(4, 4),
            "model.layers.0.mlp.experts.1.gate_proj.weight": torch.zeros(4, 4),
            "model.layers.0.mlp.router.weight": torch.zeros(2, 4),
        }
        mock_reconstruct.return_value = mock.MagicMock()
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        LocalHFClient(model_dir=str(model_dir), device="cpu")

        mock_reconstruct.assert_called_once()


# =========================================================================
# TestNormalizeMergedKeys
# =========================================================================
class TestNormalizeMergedKeys:
    """Qwen3.5/Gemma3 4B+ 등 키 접두사 정규화 테스트 (8 tests)."""

    def test_no_normalization_when_keys_overlap(self):
        """이미 키가 매칭되면 변경 없이 반환."""
        import torch

        merged_sd = {
            "model.layers.0.mlp.gate_proj.weight": torch.ones(2, 2),
            "model.embed_tokens.weight": torch.eye(4),
        }
        expected_keys = {"model.layers.0.mlp.gate_proj.weight", "model.embed_tokens.weight"}
        result = _normalize_merged_keys(merged_sd, expected_keys)
        assert result is merged_sd  # 동일 객체 반환

    def test_language_model_prefix_stripped(self):
        """model.language_model.X → model.X 정규화 (Qwen3.5)."""
        import torch

        merged_sd = {
            "model.language_model.embed_tokens.weight": torch.eye(4),
            "model.language_model.layers.0.mlp.gate_proj.weight": torch.ones(2, 2),
            "model.language_model.norm.weight": torch.ones(4),
        }
        expected_keys = {
            "model.embed_tokens.weight",
            "model.layers.0.mlp.gate_proj.weight",
            "model.norm.weight",
            "lm_head.weight",
        }
        result = _normalize_merged_keys(merged_sd, expected_keys)
        assert "model.embed_tokens.weight" in result
        assert "model.layers.0.mlp.gate_proj.weight" in result
        assert "model.norm.weight" in result
        # language_model 접두사가 남아있지 않아야 함
        assert not any("language_model" in k for k in result)

    def test_language_model_prefix_preserves_values(self):
        """정규화 후 텐서 값이 보존되어야 한다."""
        import torch

        val = torch.randn(3, 3)
        merged_sd = {"model.language_model.layers.0.weight": val}
        expected_keys = {"model.layers.0.weight"}
        result = _normalize_merged_keys(merged_sd, expected_keys)
        assert torch.equal(result["model.layers.0.weight"], val)

    def test_no_known_mapping_returns_original(self):
        """매칭되는 접두사 매핑이 없으면 원본 반환."""
        import torch

        merged_sd = {
            "completely.different.prefix.weight": torch.ones(2, 2),
        }
        expected_keys = {"model.layers.0.weight"}
        result = _normalize_merged_keys(merged_sd, expected_keys)
        assert result is merged_sd  # 원본 그대로

    def test_base_model_prefix_stripped(self):
        """base_model.model.X → model.X 정규화 (PEFT wrapper)."""
        import torch

        merged_sd = {
            "base_model.model.layers.0.weight": torch.ones(2, 2),
            "base_model.model.embed_tokens.weight": torch.eye(4),
        }
        expected_keys = {"model.layers.0.weight", "model.embed_tokens.weight"}
        result = _normalize_merged_keys(merged_sd, expected_keys)
        assert "model.layers.0.weight" in result
        assert "model.embed_tokens.weight" in result

    def test_gemma3_4b_compound_normalization(self):
        """Gemma 3 4B+ (ConditionalGeneration): 누적 매핑 — text + vision 키 모두 정규화.

        체크포인트: language_model.model.X → model.language_model.X (1차)
                  vision_tower.X → model.vision_tower.X (2차)
        """
        import torch

        merged_sd = {
            "language_model.model.layers.0.mlp.gate_proj.weight": torch.ones(2, 2),
            "language_model.model.embed_tokens.weight": torch.eye(4),
            "vision_tower.vision_model.encoder.layers.0.weight": torch.ones(3, 3),
        }
        expected_keys = {
            "model.language_model.layers.0.mlp.gate_proj.weight",
            "model.language_model.embed_tokens.weight",
            "model.vision_tower.vision_model.encoder.layers.0.weight",
        }
        result = _normalize_merged_keys(merged_sd, expected_keys)
        assert "model.language_model.layers.0.mlp.gate_proj.weight" in result
        assert "model.language_model.embed_tokens.weight" in result
        assert "model.vision_tower.vision_model.encoder.layers.0.weight" in result

    def test_model_prefix_not_applied_when_overlap(self):
        """이미 model. 접두사가 있으면 적용하지 않음."""
        import torch

        merged_sd = {
            "model.layers.0.weight": torch.ones(2, 2),
        }
        expected_keys = {"model.layers.0.weight"}
        result = _normalize_merged_keys(merged_sd, expected_keys)
        assert result is merged_sd  # 이미 매칭 → 원본 반환

    def test_normalize_called_in_local_hf_client(self):
        """LocalHFClient에서 load_state_dict 전에 _normalize_merged_keys 호출.

        mixture_lora + resolved_config 없음 → fallback 경로에서 _merge_mixture_lora_state_dict + _normalize 호출.
        """
        import torch

        with (
            mock.patch("eulerforge.loader.AutoTokenizer"),
            mock.patch("eulerforge.loader.AutoModelForCausalLM") as mock_model_cls,
            mock.patch("eulerforge.loader.AutoConfig"),
            mock.patch("eulerforge.utils.bench_client._merge_mixture_lora_state_dict") as mock_merge,
            mock.patch("eulerforge.utils.bench_client._load_state_dict_from_checkpoint") as mock_load_sd,
            mock.patch("eulerforge.utils.bench_client._find_lora_config") as mock_find_lora,
            mock.patch("eulerforge.utils.bench_client._find_resolved_config") as mock_find_resolved,
            mock.patch("eulerforge.utils.bench_client._normalize_merged_keys") as mock_normalize,
        ):
            import tempfile, os
            with tempfile.TemporaryDirectory() as td:
                model_dir = os.path.join(td, "fake_model")
                os.makedirs(model_dir)
                with open(os.path.join(model_dir, "config.json"), "w") as f:
                    f.write('{"model_type": "qwen3_5_text"}')

                mock_find_lora.return_value = {
                    "lora_r": 48, "lora_alpha": 96.0, "strategy": "mixture_lora"
                }
                mock_find_resolved.return_value = None  # No resolved_config → fallback
                mock_load_sd.return_value = {
                    "model.language_model.layers.0.mlp.gate_proj.experts.0.loraA": torch.zeros(4, 4),
                    "model.language_model.layers.0.mlp.gate_proj.base_layer.weight": torch.zeros(4, 4),
                }
                mock_merge.return_value = {
                    "model.language_model.layers.0.mlp.gate_proj.weight": torch.zeros(4, 4),
                }
                mock_normalize.return_value = {
                    "model.layers.0.mlp.gate_proj.weight": torch.zeros(4, 4),
                }

                mock_model = mock.MagicMock()
                mock_model.load_state_dict.return_value = ([], [])
                mock_model._tied_weights_keys = {}
                mock_model.to.return_value = mock_model
                mock_model.state_dict.return_value = {
                    "model.layers.0.mlp.gate_proj.weight": torch.zeros(4, 4),
                }
                mock_model_cls.from_config.return_value = mock_model

                LocalHFClient(model_dir=model_dir, device="cpu")

                mock_merge.assert_called_once()
                mock_normalize.assert_called_once()


# =========================================================================
# TestMoEReconstruction
# =========================================================================
class TestMoEReconstruction:
    """MoE 구조 보존 bench 로딩 테스트 (8 tests)."""

    # ---- _find_resolved_config ----

    def test_find_resolved_config_found(self, tmp_path):
        """parent dir에 resolved_config.json이 있으면 반환."""
        run_dir = tmp_path / "run"
        run_dir.mkdir()
        model_dir = run_dir / "final"
        model_dir.mkdir()
        cfg = {"backbone": "qwen3", "injection": {"strategy": "moe_expert_lora"}}
        (run_dir / "resolved_config.json").write_text(json.dumps(cfg))
        result = _find_resolved_config(str(model_dir))
        assert result is not None
        assert result["backbone"] == "qwen3"

    def test_find_resolved_config_missing(self, tmp_path):
        """resolved_config.json이 없으면 None."""
        model_dir = tmp_path / "final"
        model_dir.mkdir()
        assert _find_resolved_config(str(model_dir)) is None

    # ---- _get_backbone_adapter ----

    def test_get_backbone_adapter_qwen3(self):
        """qwen3 → Qwen3Adapter 인스턴스 반환."""
        from eulerforge.adapters.backbones.qwen3 import Qwen3Adapter
        adapter = _get_backbone_adapter("qwen3")
        assert isinstance(adapter, Qwen3Adapter)

    def test_get_backbone_adapter_llama(self):
        """llama → LlamaAdapter 인스턴스 반환."""
        from eulerforge.adapters.backbones.llama import LlamaAdapter
        adapter = _get_backbone_adapter("llama")
        assert isinstance(adapter, LlamaAdapter)

    def test_get_backbone_adapter_gemma3(self):
        """gemma3 → Gemma3Adapter 인스턴스 반환."""
        from eulerforge.adapters.backbones.gemma3 import Gemma3Adapter
        adapter = _get_backbone_adapter("gemma3")
        assert isinstance(adapter, Gemma3Adapter)

    def test_get_backbone_adapter_qwen2(self):
        """qwen2 → Qwen3Adapter (Qwen 계열 공유)."""
        from eulerforge.adapters.backbones.qwen3 import Qwen3Adapter
        adapter = _get_backbone_adapter("qwen2")
        assert isinstance(adapter, Qwen3Adapter)

    def test_get_backbone_adapter_qwen_variants(self):
        """qwen 계열 변형들 모두 Qwen3Adapter로 매핑."""
        from eulerforge.adapters.backbones.qwen3 import Qwen3Adapter
        for name in ["qwen2", "qwen2.5", "qwen3", "qwen3.5", "qwen"]:
            adapter = _get_backbone_adapter(name)
            assert isinstance(adapter, Qwen3Adapter), f"Failed for backbone='{name}'"

    def test_get_backbone_adapter_unknown_raises(self):
        """알 수 없는 backbone → ValueError."""
        with pytest.raises(ValueError, match="unsupported backbone"):
            _get_backbone_adapter("unknown_model")

    # ---- _reconstruct_moe_model ----

    def _setup_reconstruct_mocks(self, tmp_path):
        """_reconstruct_moe_model 테스트용 공통 mock 설정."""
        import torch

        model_dir = tmp_path / "fake"
        model_dir.mkdir()
        (model_dir / "config.json").write_text('{"model_type": "qwen2"}')

        resolved_cfg = {
            "backbone": "qwen3",
            "injection": {
                "strategy": "moe_expert_lora",
                "num_experts": 4, "top_k": 2,
                "start_layer": 0, "num_layers": 0,
            },
        }
        return str(model_dir), resolved_cfg

    @mock.patch("eulerforge.utils.bench_client._normalize_merged_keys")
    @mock.patch("eulerforge.utils.bench_client._merge_lora_state_dict")
    @mock.patch("eulerforge.utils.bench_client._get_backbone_adapter")
    @mock.patch("eulerforge.utils.bench_client.AutoModelForCausalLM")
    @mock.patch("eulerforge.utils.bench_client.AutoConfig")
    def test_reconstruct_moe_calls_replace_ffn(
        self,
        mock_config_cls, mock_model_cls, mock_adapter_fn,
        mock_merge_lora, mock_normalize,
        tmp_path,
    ):
        """MoE 재구성 시 replace_ffn_with_moe_inplace가 호출된다."""
        import torch
        import eulerforge.utils.bench_client as bench_mod

        model_dir, resolved_cfg = self._setup_reconstruct_mocks(tmp_path)

        mock_config = mock.MagicMock()
        mock_config.hidden_size = 128
        mock_config_cls.from_pretrained.return_value = mock_config

        mock_model = mock.MagicMock()
        mock_model.load_state_dict.return_value = ([], [])
        mock_model._tied_weights_keys = {}
        mock_model.to.return_value = mock_model
        mock_model_cls.from_config.return_value = mock_model

        mock_adapter_inst = mock.MagicMock()
        mock_adapter_inst.find_transformer_layers.return_value = [
            mock.MagicMock() for _ in range(24)
        ]
        mock_adapter_fn.return_value = mock_adapter_inst

        state_dict = {
            "model.layers.0.mlp.experts.0.gate_proj.weight": torch.zeros(4, 4),
            "model.layers.0.mlp.router.weight": torch.zeros(4, 128),
        }
        mock_normalize.side_effect = lambda sd, keys: sd

        mock_replace = mock.MagicMock(return_value=[0])
        with mock.patch.object(bench_mod, "replace_ffn_with_moe_inplace", mock_replace, create=True):
            _reconstruct_moe_model(
                model_dir=model_dir,
                resolved_cfg=resolved_cfg,
                state_dict=state_dict,
                lora_cfg=None,
                torch_dtype="auto",
                device="cpu",
            )

        mock_replace.assert_called_once()
        call_kwargs = mock_replace.call_args[1]
        assert call_kwargs["num_experts"] == 4
        assert call_kwargs["top_k"] == 2

    @mock.patch("eulerforge.utils.bench_client._normalize_merged_keys")
    @mock.patch("eulerforge.utils.bench_client._merge_lora_state_dict")
    @mock.patch("eulerforge.utils.bench_client._get_backbone_adapter")
    @mock.patch("eulerforge.utils.bench_client.AutoModelForCausalLM")
    @mock.patch("eulerforge.utils.bench_client.AutoConfig")
    def test_reconstruct_moe_merges_lora_when_present(
        self,
        mock_config_cls, mock_model_cls, mock_adapter_fn,
        mock_merge_lora, mock_normalize,
        tmp_path,
    ):
        """LoRA 키가 있으면 _merge_lora_state_dict 호출 (expert 구조 보존)."""
        import torch
        import eulerforge.utils.bench_client as bench_mod

        model_dir, resolved_cfg = self._setup_reconstruct_mocks(tmp_path)

        mock_config = mock.MagicMock()
        mock_config.hidden_size = 128
        mock_config_cls.from_pretrained.return_value = mock_config

        mock_model = mock.MagicMock()
        mock_model.load_state_dict.return_value = ([], [])
        mock_model._tied_weights_keys = {}
        mock_model.to.return_value = mock_model
        mock_model_cls.from_config.return_value = mock_model

        mock_adapter_inst = mock.MagicMock()
        mock_adapter_inst.find_transformer_layers.return_value = [
            mock.MagicMock() for _ in range(24)
        ]
        mock_adapter_fn.return_value = mock_adapter_inst

        state_dict = {
            "model.layers.0.mlp.experts.0.gate_proj.base_layer.weight": torch.zeros(4, 4),
            "model.layers.0.mlp.experts.0.gate_proj.lora_A": torch.zeros(2, 4),
            "model.layers.0.mlp.experts.0.gate_proj.lora_B": torch.zeros(4, 2),
        }
        mock_merge_lora.return_value = {
            "model.layers.0.mlp.experts.0.gate_proj.weight": torch.zeros(4, 4),
        }
        mock_normalize.side_effect = lambda sd, keys: sd
        lora_cfg = {"lora_r": 48, "lora_alpha": 96.0}

        mock_replace = mock.MagicMock(return_value=[0])
        with mock.patch.object(bench_mod, "replace_ffn_with_moe_inplace", mock_replace, create=True):
            _reconstruct_moe_model(
                model_dir=model_dir,
                resolved_cfg=resolved_cfg,
                state_dict=state_dict,
                lora_cfg=lora_cfg,
                torch_dtype="auto",
                device="cpu",
            )

        mock_merge_lora.assert_called_once_with(state_dict, 48, 96.0)

    @mock.patch("eulerforge.utils.bench_client._normalize_merged_keys")
    @mock.patch("eulerforge.utils.bench_client._merge_lora_state_dict")
    @mock.patch("eulerforge.utils.bench_client._get_backbone_adapter")
    @mock.patch("eulerforge.utils.bench_client.AutoModelForCausalLM")
    @mock.patch("eulerforge.utils.bench_client.AutoConfig")
    def test_reconstruct_moe_no_lora_merge_for_handoff(
        self,
        mock_config_cls, mock_model_cls, mock_adapter_fn,
        mock_merge_lora, mock_normalize,
        tmp_path,
    ):
        """Handoff 완료 (LoRA 없음) → _merge_lora_state_dict 호출 안 함."""
        import torch
        import eulerforge.utils.bench_client as bench_mod

        model_dir, resolved_cfg = self._setup_reconstruct_mocks(tmp_path)

        mock_config = mock.MagicMock()
        mock_config.hidden_size = 128
        mock_config_cls.from_pretrained.return_value = mock_config

        mock_model = mock.MagicMock()
        mock_model.load_state_dict.return_value = ([], [])
        mock_model._tied_weights_keys = {}
        mock_model.to.return_value = mock_model
        mock_model_cls.from_config.return_value = mock_model

        mock_adapter_inst = mock.MagicMock()
        mock_adapter_inst.find_transformer_layers.return_value = [
            mock.MagicMock() for _ in range(24)
        ]
        mock_adapter_fn.return_value = mock_adapter_inst

        state_dict = {
            "model.layers.0.mlp.experts.0.gate_proj.weight": torch.zeros(4, 4),
            "model.layers.0.mlp.router.weight": torch.zeros(4, 128),
        }
        mock_normalize.side_effect = lambda sd, keys: sd

        mock_replace = mock.MagicMock(return_value=[0])
        with mock.patch.object(bench_mod, "replace_ffn_with_moe_inplace", mock_replace, create=True):
            _reconstruct_moe_model(
                model_dir=model_dir,
                resolved_cfg=resolved_cfg,
                state_dict=state_dict,
                lora_cfg={"lora_r": 48, "lora_alpha": 96.0},
                torch_dtype="auto",
                device="cpu",
            )

        mock_merge_lora.assert_not_called()

    @mock.patch("eulerforge.utils.bench_client._normalize_merged_keys")
    @mock.patch("eulerforge.utils.bench_client._get_backbone_adapter")
    @mock.patch("eulerforge.utils.bench_client.AutoModelForCausalLM")
    @mock.patch("eulerforge.utils.bench_client.AutoConfig")
    def test_reconstruct_moe_sets_eval_mode(
        self,
        mock_config_cls, mock_model_cls, mock_adapter_fn,
        mock_normalize,
        tmp_path,
    ):
        """MoE 재구성 후 모델이 eval 모드로 전환된다 (Gemma3 4B+ token_type_ids 방지)."""
        import torch
        import eulerforge.utils.bench_client as bench_mod

        model_dir, resolved_cfg = self._setup_reconstruct_mocks(tmp_path)

        mock_config = mock.MagicMock()
        mock_config.hidden_size = 128
        mock_config_cls.from_pretrained.return_value = mock_config

        mock_model = mock.MagicMock()
        mock_model.load_state_dict.return_value = ([], [])
        mock_model._tied_weights_keys = {}
        mock_model.to.return_value = mock_model
        mock_model_cls.from_config.return_value = mock_model

        mock_adapter_inst = mock.MagicMock()
        mock_adapter_inst.find_transformer_layers.return_value = [
            mock.MagicMock() for _ in range(24)
        ]
        mock_adapter_fn.return_value = mock_adapter_inst

        state_dict = {
            "model.layers.0.mlp.router.weight": torch.zeros(4, 128),
        }
        mock_normalize.side_effect = lambda sd, keys: sd

        mock_replace = mock.MagicMock(return_value=[0])
        with mock.patch.object(bench_mod, "replace_ffn_with_moe_inplace", mock_replace, create=True):
            result = _reconstruct_moe_model(
                model_dir=model_dir,
                resolved_cfg=resolved_cfg,
                state_dict=state_dict,
                lora_cfg=None,
                torch_dtype="auto",
                device="cpu",
            )

        mock_model.eval.assert_called_once()


# =========================================================================
# TestMixtureLoRAReconstruction
# =========================================================================
class TestMixtureLoRAReconstruction:
    """MixtureLoRA(mixture_lora) 구조 보존 bench 로딩 테스트 (6 tests)."""

    # ---- _merge_attention_lora_only ----

    def test_merge_attention_lora_only_preserves_mixture_keys(self):
        """FFN MixtureLoRA 키는 보존, Attention LoRA만 병합."""
        import torch

        sd = {
            # FFN MixtureLoRA keys (should be preserved)
            "model.layers.0.mlp.gate_proj.base_layer.weight": torch.ones(4, 4),
            "model.layers.0.mlp.gate_proj.router.weight": torch.randn(2, 4),
            "model.layers.0.mlp.gate_proj.router.bias": torch.randn(2),
            "model.layers.0.mlp.gate_proj.experts.0.loraA": torch.randn(2, 4),
            "model.layers.0.mlp.gate_proj.experts.0.loraB": torch.randn(4, 2),
            "model.layers.0.mlp.gate_proj.experts.1.loraA": torch.randn(2, 4),
            "model.layers.0.mlp.gate_proj.experts.1.loraB": torch.randn(4, 2),
            # Attention LoRA keys (should be merged)
            "model.layers.0.self_attn.q_proj.base_layer.weight": torch.ones(4, 4),
            "model.layers.0.self_attn.q_proj.lora_A": torch.eye(2, 4) * 0.1,
            "model.layers.0.self_attn.q_proj.lora_B": torch.eye(4, 2) * 0.1,
            # Normal keys
            "model.embed_tokens.weight": torch.eye(4),
        }
        merged = _merge_attention_lora_only(sd, lora_r=2, lora_alpha=4.0)

        # MixtureLoRA keys preserved as-is
        assert "model.layers.0.mlp.gate_proj.base_layer.weight" in merged
        assert "model.layers.0.mlp.gate_proj.router.weight" in merged
        assert "model.layers.0.mlp.gate_proj.router.bias" in merged
        assert "model.layers.0.mlp.gate_proj.experts.0.loraA" in merged
        assert "model.layers.0.mlp.gate_proj.experts.0.loraB" in merged
        assert "model.layers.0.mlp.gate_proj.experts.1.loraA" in merged
        assert "model.layers.0.mlp.gate_proj.experts.1.loraB" in merged
        # Attention LoRA merged into weight
        assert "model.layers.0.self_attn.q_proj.weight" in merged
        assert "model.layers.0.self_attn.q_proj.base_layer.weight" not in merged
        assert "model.layers.0.self_attn.q_proj.lora_A" not in merged
        assert "model.layers.0.self_attn.q_proj.lora_B" not in merged
        # Normal keys preserved
        assert "model.embed_tokens.weight" in merged

        # Attention merge correctness: base + (B @ A) * scaling
        scaling = 4.0 / 2
        expected = torch.ones(4, 4) + (
            torch.eye(4, 2) * 0.1 @ (torch.eye(2, 4) * 0.1)
        ).float() * scaling
        assert torch.allclose(
            merged["model.layers.0.self_attn.q_proj.weight"], expected, atol=1e-5
        )

    def test_merge_attention_lora_only_no_attn_lora(self):
        """Attention LoRA가 없을 때 MixtureLoRA 키만 그대로 통과."""
        import torch

        sd = {
            "model.layers.0.mlp.gate_proj.base_layer.weight": torch.ones(4, 4),
            "model.layers.0.mlp.gate_proj.router.weight": torch.randn(2, 4),
            "model.layers.0.mlp.gate_proj.experts.0.loraA": torch.randn(2, 4),
            "model.layers.0.mlp.gate_proj.experts.0.loraB": torch.randn(4, 2),
            "model.embed_tokens.weight": torch.eye(4),
        }
        merged = _merge_attention_lora_only(sd, lora_r=2, lora_alpha=4.0)

        assert "model.layers.0.mlp.gate_proj.base_layer.weight" in merged
        assert "model.layers.0.mlp.gate_proj.router.weight" in merged
        assert "model.layers.0.mlp.gate_proj.experts.0.loraA" in merged
        assert "model.layers.0.mlp.gate_proj.experts.0.loraB" in merged
        assert "model.embed_tokens.weight" in merged
        assert len(merged) == 5

    # ---- _reconstruct_mixture_lora_model ----

    @mock.patch("eulerforge.utils.bench_client._normalize_merged_keys")
    @mock.patch("eulerforge.utils.bench_client._merge_attention_lora_only")
    @mock.patch("eulerforge.utils.bench_client._get_backbone_adapter")
    @mock.patch("eulerforge.utils.bench_client.AutoModelForCausalLM")
    @mock.patch("eulerforge.utils.bench_client.AutoConfig")
    def test_reconstruct_mixture_lora_calls_build(
        self,
        mock_config_cls, mock_model_cls, mock_adapter_fn,
        mock_merge_attn, mock_normalize,
        tmp_path,
    ):
        """MixtureLoRA 재구성 시 build_mixture_lora_for_ffn_layers가 호출된다."""
        import torch
        import eulerforge.utils.bench_client as bench_mod

        model_dir = tmp_path / "fake"
        model_dir.mkdir()
        (model_dir / "config.json").write_text('{"model_type": "qwen2"}')

        resolved_cfg = {
            "backbone": "qwen3",
            "injection": {
                "strategy": "mixture_lora",
                "num_experts": 4, "top_k": 2,
                "lora_r": 16, "lora_alpha": 32.0,
                "start_layer": 0, "num_layers": 0,
            },
        }

        mock_config = mock.MagicMock()
        mock_config_cls.from_pretrained.return_value = mock_config

        mock_model = mock.MagicMock()
        mock_model.load_state_dict.return_value = ([], [])
        mock_model._tied_weights_keys = {}
        mock_model.to.return_value = mock_model
        mock_model_cls.from_config.return_value = mock_model

        mock_adapter_inst = mock.MagicMock()
        mock_adapter_inst.find_transformer_layers.return_value = [
            mock.MagicMock() for _ in range(24)
        ]
        mock_adapter_fn.return_value = mock_adapter_inst

        state_dict = {
            "model.layers.0.mlp.gate_proj.base_layer.weight": torch.zeros(4, 4),
            "model.layers.0.mlp.gate_proj.experts.0.loraA": torch.zeros(2, 4),
        }
        mock_merge_attn.return_value = state_dict
        mock_normalize.side_effect = lambda sd, keys: sd

        mock_build = mock.MagicMock()
        with mock.patch.object(bench_mod, "build_mixture_lora_for_ffn_layers", mock_build, create=True):
            _reconstruct_mixture_lora_model(
                model_dir=str(model_dir),
                resolved_cfg=resolved_cfg,
                state_dict=state_dict,
                lora_cfg=None,
                torch_dtype="auto",
                device="cpu",
            )

        mock_build.assert_called_once()
        call_kwargs = mock_build.call_args[1]
        assert call_kwargs["num_experts"] == 4
        assert call_kwargs["top_k"] == 2
        assert call_kwargs["r"] == 16
        assert call_kwargs["alpha"] == 32.0

    @mock.patch("eulerforge.utils.bench_client._normalize_merged_keys")
    @mock.patch("eulerforge.utils.bench_client._merge_attention_lora_only")
    @mock.patch("eulerforge.utils.bench_client._get_backbone_adapter")
    @mock.patch("eulerforge.utils.bench_client.AutoModelForCausalLM")
    @mock.patch("eulerforge.utils.bench_client.AutoConfig")
    def test_reconstruct_mixture_lora_merges_attn_only(
        self,
        mock_config_cls, mock_model_cls, mock_adapter_fn,
        mock_merge_attn, mock_normalize,
        tmp_path,
    ):
        """Attention LoRA 키가 있으면 _merge_attention_lora_only 호출."""
        import torch
        import eulerforge.utils.bench_client as bench_mod

        model_dir = tmp_path / "fake"
        model_dir.mkdir()
        (model_dir / "config.json").write_text('{"model_type": "qwen2"}')

        resolved_cfg = {
            "backbone": "qwen3",
            "injection": {
                "strategy": "mixture_lora",
                "num_experts": 4, "top_k": 2,
                "lora_r": 16, "lora_alpha": 32.0,
                "start_layer": 0, "num_layers": 0,
            },
        }

        mock_config = mock.MagicMock()
        mock_config_cls.from_pretrained.return_value = mock_config

        mock_model = mock.MagicMock()
        mock_model.load_state_dict.return_value = ([], [])
        mock_model._tied_weights_keys = {}
        mock_model.to.return_value = mock_model
        mock_model_cls.from_config.return_value = mock_model

        mock_adapter_inst = mock.MagicMock()
        mock_adapter_inst.find_transformer_layers.return_value = [
            mock.MagicMock() for _ in range(24)
        ]
        mock_adapter_fn.return_value = mock_adapter_inst

        # State dict with BOTH MixtureLoRA and Attention LoRA
        state_dict = {
            "model.layers.0.mlp.gate_proj.base_layer.weight": torch.zeros(4, 4),
            "model.layers.0.mlp.gate_proj.experts.0.loraA": torch.zeros(2, 4),
            "model.layers.0.self_attn.q_proj.base_layer.weight": torch.zeros(4, 4),
            "model.layers.0.self_attn.q_proj.lora_A": torch.zeros(2, 4),
            "model.layers.0.self_attn.q_proj.lora_B": torch.zeros(4, 2),
        }
        mock_merge_attn.return_value = {
            "model.layers.0.mlp.gate_proj.base_layer.weight": torch.zeros(4, 4),
            "model.layers.0.mlp.gate_proj.experts.0.loraA": torch.zeros(2, 4),
            "model.layers.0.self_attn.q_proj.weight": torch.zeros(4, 4),
        }
        mock_normalize.side_effect = lambda sd, keys: sd

        lora_cfg = {"lora_r": 16, "lora_alpha": 32.0}

        mock_build = mock.MagicMock()
        with mock.patch.object(bench_mod, "build_mixture_lora_for_ffn_layers", mock_build, create=True):
            _reconstruct_mixture_lora_model(
                model_dir=str(model_dir),
                resolved_cfg=resolved_cfg,
                state_dict=state_dict,
                lora_cfg=lora_cfg,
                torch_dtype="auto",
                device="cpu",
            )

        mock_merge_attn.assert_called_once_with(state_dict, 16, 32.0)

    # ---- LocalHFClient mixture_lora branch ----

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.utils.bench_client._reconstruct_mixture_lora_model")
    @mock.patch("eulerforge.utils.bench_client._load_state_dict_from_checkpoint")
    @mock.patch("eulerforge.utils.bench_client._find_lora_config")
    def test_local_hf_client_uses_mixture_reconstruct(
        self,
        mock_find_lora, mock_load_sd, mock_reconstruct,
        mock_tok_cls,
        tmp_path,
    ):
        """mixture_lora + resolved_config → _reconstruct_mixture_lora_model 호출."""
        import torch

        run_dir = tmp_path / "run_test"
        run_dir.mkdir()
        model_dir = run_dir / "final"
        model_dir.mkdir()
        (model_dir / "config.json").write_text('{"model_type": "qwen2"}')
        (run_dir / "resolved_config.json").write_text(json.dumps({
            "backbone": "qwen3",
            "injection": {"strategy": "mixture_lora", "num_experts": 4, "top_k": 2},
        }))

        mock_find_lora.return_value = {
            "lora_r": 16, "lora_alpha": 32.0, "strategy": "mixture_lora",
        }
        mock_load_sd.return_value = {
            "model.layers.0.mlp.gate_proj.experts.0.loraA": torch.zeros(2, 4),
            "model.layers.0.mlp.gate_proj.base_layer.weight": torch.zeros(4, 4),
        }
        mock_reconstruct.return_value = mock.MagicMock()
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        client = LocalHFClient(model_dir=str(model_dir), device="cpu")

        mock_reconstruct.assert_called_once()
        call_kwargs = mock_reconstruct.call_args[1]
        assert call_kwargs["model_dir"] == str(model_dir)

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    @mock.patch("eulerforge.loader.AutoConfig")
    @mock.patch("eulerforge.utils.bench_client._merge_mixture_lora_state_dict")
    @mock.patch("eulerforge.utils.bench_client._find_resolved_config")
    @mock.patch("eulerforge.utils.bench_client._load_state_dict_from_checkpoint")
    @mock.patch("eulerforge.utils.bench_client._find_lora_config")
    def test_local_hf_client_mixture_lora_fallback_no_resolved_config(
        self,
        mock_find_lora, mock_load_sd, mock_find_resolved,
        mock_merge_mixture, mock_config_cls, mock_model_cls, mock_tok_cls,
        tmp_path,
    ):
        """mixture_lora + resolved_config 없음 → _merge_mixture_lora_state_dict fallback."""
        import torch

        model_dir = tmp_path / "final"
        model_dir.mkdir()
        (model_dir / "config.json").write_text('{"model_type": "qwen2"}')

        mock_find_lora.return_value = {
            "lora_r": 16, "lora_alpha": 32.0, "strategy": "mixture_lora",
        }
        mock_find_resolved.return_value = None  # No resolved_config
        mock_load_sd.return_value = {
            "model.layers.0.mlp.gate_proj.experts.0.loraA": torch.zeros(2, 4),
            "model.layers.0.mlp.gate_proj.base_layer.weight": torch.zeros(4, 4),
        }
        mock_merge_mixture.return_value = {
            "model.layers.0.mlp.gate_proj.weight": torch.zeros(4, 4),
        }

        mock_model = mock.MagicMock()
        mock_model.load_state_dict.return_value = ([], [])
        mock_model._tied_weights_keys = {}
        mock_model.to.return_value = mock_model
        mock_model.state_dict.return_value = {
            "model.layers.0.mlp.gate_proj.weight": torch.zeros(4, 4),
        }
        mock_model_cls.from_config.return_value = mock_model

        LocalHFClient(model_dir=str(model_dir), device="cpu")

        mock_merge_mixture.assert_called_once()


# ===========================================================================
# TestDequantizeBnbStateDict: bitsandbytes nf4 dequantize
# ===========================================================================

class TestDequantizeBnbStateDict:
    """_dequantize_bnb_state_dict()가 양자화된 텐서를 dequantize하는지 검증."""

    def test_no_quant_keys_returns_unchanged(self):
        """양자화 키가 없으면 state dict 그대로 반환."""
        import torch
        sd = {
            "layer.weight": torch.randn(4, 4),
            "layer.bias": torch.zeros(4),
        }
        result = _dequantize_bnb_state_dict(sd)
        assert set(result.keys()) == set(sd.keys())
        assert torch.equal(result["layer.weight"], sd["layer.weight"])

    def test_dequantize_removes_companion_keys(self):
        """양자화 companion 키(.absmax, .quant_map 등)가 결과에서 제거되는지 확인."""
        import json as _json
        import torch

        try:
            from bitsandbytes.functional import QuantState, quantize_4bit
        except ImportError:
            pytest.skip("bitsandbytes not installed")

        # 실제 nf4 양자화 수행
        original = torch.randn(64, 32, dtype=torch.bfloat16)
        packed, qs = quantize_4bit(
            original, quant_type="nf4", blocksize=64
        )

        # safetensors 저장 형식 시뮬레이션
        meta = {
            "shape": list(original.shape),
            "blocksize": qs.blocksize,
            "quant_type": "nf4",
            "dtype": "bfloat16",
        }
        if qs.nested:
            meta["nested_blocksize"] = qs.state2.blocksize if qs.state2 else 256
            meta["nested_dtype"] = "bfloat16"
        meta_bytes = _json.dumps(meta).encode()
        meta_tensor = torch.tensor(list(meta_bytes), dtype=torch.uint8)

        sd = {
            "layer.base_layer.weight": packed,
            "layer.base_layer.weight.absmax": qs.absmax,
            "layer.base_layer.weight.quant_map": qs.code,
            "layer.base_layer.weight.quant_state.bitsandbytes__nf4": meta_tensor,
            "layer.lora_A": torch.randn(8, 32),
            "layer.lora_B": torch.randn(64, 8),
        }
        if qs.nested and qs.state2 is not None:
            sd["layer.base_layer.weight.nested_absmax"] = qs.state2.absmax
            sd["layer.base_layer.weight.nested_quant_map"] = qs.state2.code

        result = _dequantize_bnb_state_dict(sd)

        # companion 키 제거 확인
        for k in result:
            assert ".absmax" not in k
            assert ".quant_map" not in k
            assert ".quant_state" not in k
            assert ".nested_" not in k

        # dequantized weight 확인
        assert "layer.base_layer.weight" in result
        deq = result["layer.base_layer.weight"]
        assert deq.shape == original.shape
        assert deq.dtype == torch.bfloat16

        # LoRA 키는 그대로 보존
        assert "layer.lora_A" in result
        assert "layer.lora_B" in result

    def test_dequantize_then_lora_merge_works(self):
        """dequantize → _merge_lora_state_dict 순서로 LoRA 병합 성공 확인."""
        import json as _json
        import torch

        try:
            from bitsandbytes.functional import quantize_4bit
        except ImportError:
            pytest.skip("bitsandbytes not installed")

        out_features, in_features = 64, 32
        lora_r = 8
        original = torch.randn(out_features, in_features, dtype=torch.bfloat16)
        packed, qs = quantize_4bit(original, quant_type="nf4", blocksize=64)

        meta = {
            "shape": list(original.shape),
            "blocksize": qs.blocksize,
            "quant_type": "nf4",
            "dtype": "bfloat16",
        }
        if qs.nested:
            meta["nested_blocksize"] = qs.state2.blocksize if qs.state2 else 256
            meta["nested_dtype"] = "bfloat16"
        meta_bytes = _json.dumps(meta).encode()
        meta_tensor = torch.tensor(list(meta_bytes), dtype=torch.uint8)

        sd = {
            "proj.base_layer.weight": packed,
            "proj.base_layer.weight.absmax": qs.absmax,
            "proj.base_layer.weight.quant_map": qs.code,
            "proj.base_layer.weight.quant_state.bitsandbytes__nf4": meta_tensor,
            "proj.lora_A": torch.randn(lora_r, in_features),
            "proj.lora_B": torch.randn(out_features, lora_r),
        }
        if qs.nested and qs.state2 is not None:
            sd["proj.base_layer.weight.nested_absmax"] = qs.state2.absmax
            sd["proj.base_layer.weight.nested_quant_map"] = qs.state2.code

        # dequantize → LoRA merge
        deq_sd = _dequantize_bnb_state_dict(sd)
        merged = _merge_lora_state_dict(deq_sd, lora_r=lora_r, lora_alpha=16.0)

        # 결과: proj.weight가 생성되고 shape이 맞아야 함
        assert "proj.weight" in merged
        assert merged["proj.weight"].shape == (out_features, in_features)
        # LoRA 키와 base_layer 키는 제거됨
        assert "proj.base_layer.weight" not in merged
        assert "proj.lora_A" not in merged
        assert "proj.lora_B" not in merged

    def test_dequantize_accuracy(self):
        """dequantize 결과가 원본과 합리적으로 가까운지 확인."""
        import json as _json
        import torch

        try:
            from bitsandbytes.functional import quantize_4bit
        except ImportError:
            pytest.skip("bitsandbytes not installed")

        original = torch.randn(128, 64, dtype=torch.bfloat16)
        packed, qs = quantize_4bit(original, quant_type="nf4", blocksize=64)

        meta = {
            "shape": list(original.shape),
            "blocksize": qs.blocksize,
            "quant_type": "nf4",
            "dtype": "bfloat16",
        }
        if qs.nested:
            meta["nested_blocksize"] = qs.state2.blocksize if qs.state2 else 256
            meta["nested_dtype"] = "bfloat16"
        meta_bytes = _json.dumps(meta).encode()
        meta_tensor = torch.tensor(list(meta_bytes), dtype=torch.uint8)

        sd = {"w": packed, "w.absmax": qs.absmax, "w.quant_map": qs.code,
              "w.quant_state.bitsandbytes__nf4": meta_tensor}
        if qs.nested and qs.state2 is not None:
            sd["w.nested_absmax"] = qs.state2.absmax
            sd["w.nested_quant_map"] = qs.state2.code

        result = _dequantize_bnb_state_dict(sd)
        deq = result["w"].float()
        orig_f = original.float()
        # nf4 양자화 오차: 보통 0.1~0.2 범위
        max_err = (deq - orig_f).abs().max().item()
        assert max_err < 1.0, f"Max dequantize error too large: {max_err}"

    def test_mixed_quant_and_normal_keys(self):
        """양자화 키와 일반 키가 혼재할 때 일반 키는 그대로 보존."""
        import json as _json
        import torch

        try:
            from bitsandbytes.functional import quantize_4bit
        except ImportError:
            pytest.skip("bitsandbytes not installed")

        original = torch.randn(32, 16, dtype=torch.bfloat16)
        packed, qs = quantize_4bit(original, quant_type="nf4", blocksize=64)

        meta = {
            "shape": list(original.shape),
            "blocksize": qs.blocksize, "quant_type": "nf4", "dtype": "bfloat16",
        }
        if qs.nested:
            meta["nested_blocksize"] = qs.state2.blocksize if qs.state2 else 256
            meta["nested_dtype"] = "bfloat16"
        meta_bytes = _json.dumps(meta).encode()
        meta_tensor = torch.tensor(list(meta_bytes), dtype=torch.uint8)

        normal_w = torch.randn(10, 10)
        sd = {
            "quant.weight": packed,
            "quant.weight.absmax": qs.absmax,
            "quant.weight.quant_map": qs.code,
            "quant.weight.quant_state.bitsandbytes__nf4": meta_tensor,
            "normal.weight": normal_w,
            "normal.bias": torch.zeros(10),
        }
        if qs.nested and qs.state2 is not None:
            sd["quant.weight.nested_absmax"] = qs.state2.absmax
            sd["quant.weight.nested_quant_map"] = qs.state2.code

        result = _dequantize_bnb_state_dict(sd)

        # 양자화 텐서 dequantized
        assert result["quant.weight"].shape == (32, 16)
        # 일반 텐서 그대로
        assert torch.equal(result["normal.weight"], normal_w)
        assert "normal.bias" in result

    def test_dequantize_double_quant(self):
        """double quantization (nested) 체크포인트도 정상 dequantize."""
        import json as _json
        import torch

        try:
            from bitsandbytes.functional import quantize_4bit
        except ImportError:
            pytest.skip("bitsandbytes not installed")

        original = torch.randn(64, 32, dtype=torch.bfloat16)
        packed, qs = quantize_4bit(
            original, quant_type="nf4", blocksize=64, compress_statistics=True
        )

        meta = {
            "shape": list(original.shape),
            "blocksize": qs.blocksize,
            "quant_type": "nf4",
            "dtype": "bfloat16",
        }
        # compress_statistics=True → nested/double quant
        if qs.state2 is not None:
            meta["nested_blocksize"] = qs.state2.blocksize
            meta["nested_dtype"] = "bfloat16"
            if qs.offset is not None:
                meta["nested_offset"] = float(qs.offset)

        meta_bytes = _json.dumps(meta).encode()
        meta_tensor = torch.tensor(list(meta_bytes), dtype=torch.uint8)

        sd = {
            "layer.weight": packed,
            "layer.weight.absmax": qs.absmax,
            "layer.weight.quant_map": qs.code,
            "layer.weight.quant_state.bitsandbytes__nf4": meta_tensor,
        }
        if qs.state2 is not None:
            sd["layer.weight.nested_absmax"] = qs.state2.absmax
            sd["layer.weight.nested_quant_map"] = qs.state2.code

        # 이전에는 QuantState(nested=True) 호출로 TypeError 발생했음
        result = _dequantize_bnb_state_dict(sd)

        assert "layer.weight" in result
        assert result["layer.weight"].shape == original.shape
        # companion 키 모두 제거
        assert not any(k.startswith("layer.weight.") for k in result)
        # 정확도 확인
        max_err = (result["layer.weight"].float() - original.float()).abs().max().item()
        assert max_err < 1.0, f"Double quant dequantize error too large: {max_err}"

    def test_already_dequantized_tensor_with_quant_state(self):
        """handoff 등으로 이미 dequantize된 bfloat16 텐서에 quant_state 키가
        남아있을 때, dequantize_4bit를 호출하지 않고 reshape만 수행."""
        import json as _json
        import torch

        shape = (64, 32)
        original = torch.randn(*shape, dtype=torch.bfloat16)
        # handoff 후 체크포인트: bfloat16이지만 (N, 1)로 저장 + quant_state 잔존
        flat = original.reshape(-1, 1)

        meta = {
            "shape": list(shape),
            "blocksize": 64,
            "quant_type": "nf4",
            "dtype": "bfloat16",
        }
        meta_bytes = _json.dumps(meta).encode()
        meta_tensor = torch.tensor(list(meta_bytes), dtype=torch.uint8)

        sd = {
            "layer.weight": flat,  # bfloat16, NOT uint8
            "layer.weight.absmax": torch.randn(32),  # 잔존 companion
            "layer.weight.quant_map": torch.randn(16),
            "layer.weight.quant_state.bitsandbytes__nf4": meta_tensor,
            "other.weight": torch.randn(10, 10),  # 일반 키
        }

        result = _dequantize_bnb_state_dict(sd)

        # reshape만 수행되어 원본과 동일해야 함
        assert result["layer.weight"].shape == shape
        assert torch.equal(result["layer.weight"], original)
        # companion 키 제거
        assert not any("absmax" in k for k in result)
        assert not any("quant_map" in k for k in result)
        assert not any("quant_state" in k for k in result)
        # 일반 키 보존
        assert "other.weight" in result

    def test_mixed_packed_and_already_dequantized(self):
        """uint8 nf4 packed + bfloat16 이미 dequantized가 혼재하는 체크포인트."""
        import json as _json
        import torch

        try:
            from bitsandbytes.functional import quantize_4bit
        except ImportError:
            pytest.skip("bitsandbytes not installed")

        # 1) 실제 nf4 packed tensor (attention 등 — uint8)
        attn_w = torch.randn(64, 32, dtype=torch.bfloat16)
        packed, qs = quantize_4bit(attn_w, quant_type="nf4", blocksize=64)
        meta_packed = {
            "shape": list(attn_w.shape),
            "blocksize": qs.blocksize,
            "quant_type": "nf4",
            "dtype": "bfloat16",
        }
        if qs.state2 is not None:
            meta_packed["nested_blocksize"] = qs.state2.blocksize
            meta_packed["nested_dtype"] = "bfloat16"
        meta_packed_t = torch.tensor(
            list(_json.dumps(meta_packed).encode()), dtype=torch.uint8
        )

        # 2) 이미 dequantized (handoff된 FFN — bfloat16)
        ffn_w = torch.randn(128, 64, dtype=torch.bfloat16)
        ffn_flat = ffn_w.reshape(-1, 1)
        meta_deq = {
            "shape": [128, 64],
            "blocksize": 64,
            "quant_type": "nf4",
            "dtype": "bfloat16",
        }
        meta_deq_t = torch.tensor(
            list(_json.dumps(meta_deq).encode()), dtype=torch.uint8
        )

        sd = {
            # packed (uint8)
            "attn.weight": packed,
            "attn.weight.absmax": qs.absmax,
            "attn.weight.quant_map": qs.code,
            "attn.weight.quant_state.bitsandbytes__nf4": meta_packed_t,
            # already dequantized (bfloat16)
            "ffn.weight": ffn_flat,
            "ffn.weight.absmax": torch.randn(128),
            "ffn.weight.quant_map": torch.randn(16),
            "ffn.weight.quant_state.bitsandbytes__nf4": meta_deq_t,
        }
        if qs.state2 is not None:
            sd["attn.weight.nested_absmax"] = qs.state2.absmax
            sd["attn.weight.nested_quant_map"] = qs.state2.code

        result = _dequantize_bnb_state_dict(sd)

        # packed → dequantized (shape 복원)
        assert result["attn.weight"].shape == (64, 32)
        assert result["attn.weight"].dtype == torch.bfloat16
        # already dequantized → reshape만
        assert result["ffn.weight"].shape == (128, 64)
        assert torch.equal(result["ffn.weight"], ffn_w)
        # companion 키 모두 제거
        assert not any(".absmax" in k or ".quant_state" in k for k in result)

    def test_bf16_cast_packed_nf4_dequantize(self):
        """nf4 packed uint8 데이터가 bf16으로 cast되어 저장된 경우,
        uint8로 복원 후 정상 dequantize."""
        import json as _json
        import torch

        try:
            from bitsandbytes.functional import quantize_4bit
        except ImportError:
            pytest.skip("bitsandbytes not installed")

        original = torch.randn(64, 32, dtype=torch.bfloat16)
        packed_uint8, qs = quantize_4bit(
            original, quant_type="nf4", blocksize=64
        )

        # 실제 체크포인트에서 발생하는 현상: uint8 packed → bf16 cast 저장
        packed_as_bf16 = packed_uint8.to(torch.bfloat16)
        assert packed_as_bf16.dtype == torch.bfloat16
        # numel은 packed 크기와 동일 (original numel의 절반)
        assert packed_as_bf16.numel() == original.numel() // 2

        meta = {
            "shape": list(original.shape),
            "blocksize": qs.blocksize,
            "quant_type": "nf4",
            "dtype": "bfloat16",
        }
        if qs.state2 is not None:
            meta["nested_blocksize"] = qs.state2.blocksize
            meta["nested_dtype"] = "bfloat16"
        meta_bytes = _json.dumps(meta).encode()
        meta_tensor = torch.tensor(list(meta_bytes), dtype=torch.uint8)

        sd = {
            "layer.weight": packed_as_bf16,
            "layer.weight.absmax": qs.absmax,
            "layer.weight.quant_map": qs.code,
            "layer.weight.quant_state.bitsandbytes__nf4": meta_tensor,
        }
        if qs.state2 is not None:
            sd["layer.weight.nested_absmax"] = qs.state2.absmax
            sd["layer.weight.nested_quant_map"] = qs.state2.code

        result = _dequantize_bnb_state_dict(sd)

        # dequantize 성공 — 원본 shape 복원
        assert result["layer.weight"].shape == original.shape
        assert result["layer.weight"].dtype == torch.bfloat16
        # companion 키 제거
        assert not any(k.startswith("layer.weight.") for k in result)
        # 정확도 (uint8→bf16→uint8 round-trip이므로 원래 dequantize와 동일)
        max_err = (result["layer.weight"].float() - original.float()).abs().max().item()
        assert max_err < 1.0


# =========================================================================
# TestDequantizeInt8StateDict
# =========================================================================
class TestDequantizeInt8StateDict:
    """int8 양자화 체크포인트의 SCB/weight_format 키를 dequantize하는지 검증.

    Bug: _dequantize_bnb_state_dict()가 int4 (nf4)만 처리하고 int8을 무시.
    int8 체크포인트에는 *.SCB (스케일), *.weight_format (메타) 키가 있으나
    이들이 dequantize되지 않아 load_state_dict에서 228개 unexpected keys 발생.
    """

    def test_int8_scb_keys_are_removed(self):
        """int8 companion 키(.SCB, .weight_format)가 결과에서 제거되는지 확인."""
        import torch

        # Real checkpoint pattern: module.weight (int8), module.SCB, module.weight_format
        original = torch.randn(64, 32, dtype=torch.bfloat16)
        absmax = original.abs().max(dim=1).values  # row-wise scale
        int8_w = (original / absmax.unsqueeze(1) * 127).round().clamp(-128, 127).to(torch.int8)

        sd = {
            "attn.in_proj.weight": int8_w,
            "attn.in_proj.SCB": absmax,
            "attn.in_proj.weight_format": torch.tensor(0, dtype=torch.uint8),
            "other.weight": torch.randn(16, 16, dtype=torch.bfloat16),
        }

        result = _dequantize_bnb_state_dict(sd)

        # SCB and weight_format keys must be removed
        assert "attn.in_proj.SCB" not in result, "SCB key should be removed"
        assert "attn.in_proj.weight_format" not in result, "weight_format key should be removed"
        # Non-quantized keys should be preserved
        assert "other.weight" in result

    def test_int8_weight_is_dequantized_to_float(self):
        """int8 weight가 float로 dequantize되는지 확인."""
        import torch

        original = torch.randn(64, 32, dtype=torch.bfloat16)
        absmax = original.abs().max(dim=1).values
        int8_w = (original / absmax.unsqueeze(1) * 127).round().clamp(-128, 127).to(torch.int8)

        sd = {
            "attn.in_proj.weight": int8_w,
            "attn.in_proj.SCB": absmax,
            "attn.in_proj.weight_format": torch.tensor(0, dtype=torch.uint8),
        }

        result = _dequantize_bnb_state_dict(sd)

        deq = result["attn.in_proj.weight"]
        assert deq.dtype != torch.int8, f"Weight should be dequantized, got {deq.dtype}"
        assert deq.shape == original.shape
        # Dequantized values should be close to original
        max_err = (deq.float() - original.float()).abs().max().item()
        assert max_err < 0.1, f"Dequantize error too large: {max_err}"

    def test_int8_mixed_with_nf4(self):
        """int8 + nf4 혼합 체크포인트에서 두 유형 모두 dequantize."""
        import json as _json
        import torch

        try:
            from bitsandbytes.functional import quantize_4bit
        except ImportError:
            pytest.skip("bitsandbytes not installed")

        # nf4 양자화된 텐서
        original_nf4 = torch.randn(64, 32, dtype=torch.bfloat16)
        packed, qs = quantize_4bit(original_nf4, quant_type="nf4", blocksize=64)

        meta = {
            "shape": list(original_nf4.shape),
            "blocksize": qs.blocksize,
            "quant_type": "nf4",
            "dtype": "bfloat16",
        }
        if qs.state2 is not None:
            meta["nested_blocksize"] = qs.state2.blocksize
            meta["nested_dtype"] = "bfloat16"
        meta_bytes = _json.dumps(meta).encode()
        meta_tensor = torch.tensor(list(meta_bytes), dtype=torch.uint8)

        # int8 양자화된 텐서 (sibling pattern: proj.weight + proj.SCB)
        original_int8 = torch.randn(32, 16, dtype=torch.bfloat16)
        absmax = original_int8.abs().max(dim=1).values
        int8_w = (original_int8 / absmax.unsqueeze(1) * 127).round().clamp(-128, 127).to(torch.int8)

        sd = {
            "nf4_layer.weight": packed,
            "nf4_layer.weight.absmax": qs.absmax,
            "nf4_layer.weight.quant_map": qs.code,
            "nf4_layer.weight.quant_state.bitsandbytes__nf4": meta_tensor,
            "int8_layer.proj.weight": int8_w,
            "int8_layer.proj.SCB": absmax,
            "int8_layer.proj.weight_format": torch.tensor(0, dtype=torch.uint8),
        }
        if qs.state2 is not None:
            sd["nf4_layer.weight.nested_absmax"] = qs.state2.absmax
            sd["nf4_layer.weight.nested_quant_map"] = qs.state2.code

        result = _dequantize_bnb_state_dict(sd)

        # Both types should be dequantized
        assert result["nf4_layer.weight"].dtype in (torch.bfloat16, torch.float32)
        assert result["int8_layer.proj.weight"].dtype != torch.int8
        # No companion keys
        assert not any(".SCB" in k for k in result)
        assert not any("weight_format" in k for k in result)
        assert not any(".absmax" in k for k in result)
        assert not any(".quant_state" in k for k in result)

    def test_int8_count_matches_real_checkpoint_pattern(self):
        """실제 체크포인트와 동일한 패턴: 여러 int8 레이어 + companion 키들."""
        import torch

        # 10 layers × 5 projections = 50 int8 weights, each with SCB + weight_format
        sd = {}
        for layer in range(10):
            for proj in ["in_proj_qkv", "in_proj_z", "in_proj_a", "in_proj_b", "out_proj"]:
                key = f"model.layers.{layer}.linear_attn.{proj}"
                w = torch.randint(-127, 127, (64, 32), dtype=torch.int8)
                scb = torch.randn(64, dtype=torch.float32).abs()
                sd[f"{key}.weight"] = w
                sd[f"{key}.SCB"] = scb
                sd[f"{key}.weight_format"] = torch.tensor(0, dtype=torch.uint8)

        total_before = len(sd)
        result = _dequantize_bnb_state_dict(sd)

        # All SCB and weight_format keys removed
        scb_count = sum(1 for k in result if ".SCB" in k)
        fmt_count = sum(1 for k in result if "weight_format" in k)
        assert scb_count == 0, f"Expected 0 SCB keys, got {scb_count}"
        assert fmt_count == 0, f"Expected 0 weight_format keys, got {fmt_count}"

        # Only weight keys remain (50 weights)
        assert len(result) == 50
        # All dequantized to float
        for k, v in result.items():
            assert v.dtype != torch.int8, f"{k} is still int8"


# =========================================================================
# TestResizeEmbeddings
# =========================================================================
class TestResizeEmbeddings:
    """토크나이저 vocab > 모델 임베딩 시 자동 resize 테스트 (6 tests)."""

    def test_resize_when_tokenizer_larger(self):
        """vocab_size > embed_size이면 resize_token_embeddings 호출."""
        model = mock.MagicMock()
        model.config.vocab_size = 151936
        tokenizer = mock.MagicMock()
        tokenizer.__len__ = mock.MagicMock(return_value=151944)

        _resize_embeddings_if_needed(model, tokenizer)
        model.resize_token_embeddings.assert_called_once_with(151944)

    def test_no_resize_when_equal(self):
        """vocab_size == len(tokenizer)이면 resize 안 함."""
        model = mock.MagicMock()
        model.config.vocab_size = 151936
        tokenizer = mock.MagicMock()
        tokenizer.__len__ = mock.MagicMock(return_value=151936)

        _resize_embeddings_if_needed(model, tokenizer)
        model.resize_token_embeddings.assert_not_called()

    def test_no_resize_when_tokenizer_smaller(self):
        """vocab_size > len(tokenizer)이면 resize 안 함."""
        model = mock.MagicMock()
        model.config.vocab_size = 151936
        tokenizer = mock.MagicMock()
        tokenizer.__len__ = mock.MagicMock(return_value=151900)

        _resize_embeddings_if_needed(model, tokenizer)
        model.resize_token_embeddings.assert_not_called()

    def test_resize_text_config_fallback(self):
        """Gemma3Config: vocab_size 없고 text_config.vocab_size 사용."""
        model = mock.MagicMock()
        # vocab_size 속성이 없도록 설정
        del model.config.vocab_size
        model.config.text_config.vocab_size = 262208
        tokenizer = mock.MagicMock()
        tokenizer.__len__ = mock.MagicMock(return_value=262210)

        _resize_embeddings_if_needed(model, tokenizer)
        model.resize_token_embeddings.assert_called_once_with(262210)

    def test_no_resize_text_config_when_equal(self):
        """text_config.vocab_size == len(tokenizer)이면 resize 안 함."""
        model = mock.MagicMock()
        del model.config.vocab_size
        model.config.text_config.vocab_size = 262208
        tokenizer = mock.MagicMock()
        tokenizer.__len__ = mock.MagicMock(return_value=262208)

        _resize_embeddings_if_needed(model, tokenizer)
        model.resize_token_embeddings.assert_not_called()

    def test_no_resize_no_vocab_size_anywhere(self):
        """vocab_size도 text_config도 없으면 조용히 return."""
        model = mock.MagicMock()
        del model.config.vocab_size
        del model.config.text_config
        tokenizer = mock.MagicMock()
        tokenizer.__len__ = mock.MagicMock(return_value=262208)

        _resize_embeddings_if_needed(model, tokenizer)
        model.resize_token_embeddings.assert_not_called()


# =========================================================================
# TestSafeTorchDtype
# =========================================================================
class TestSafeTorchDtype:
    """float16 → bfloat16 자동 변환 테스트 (4 tests)."""

    def test_float16_converts_to_bfloat16(self):
        """float16은 bfloat16으로 자동 변환."""
        import torch
        result = _safe_torch_dtype(torch.float16)
        assert result == torch.bfloat16

    def test_bfloat16_unchanged(self):
        """bfloat16은 그대로 유지."""
        import torch
        result = _safe_torch_dtype(torch.bfloat16)
        assert result == torch.bfloat16

    def test_float32_unchanged(self):
        """float32는 그대로 유지."""
        import torch
        result = _safe_torch_dtype(torch.float32)
        assert result == torch.float32

    def test_auto_string_unchanged(self):
        """'auto' 문자열은 그대로 유지."""
        result = _safe_torch_dtype("auto")
        assert result == "auto"


# =========================================================================
# TestSequentialModelLoading
# =========================================================================
class TestSequentialModelLoading:
    """순차 모델 로딩 테스트 (12 tests).

    규칙 S1-S8: 모델을 1개씩 로드하여 전체 데이터 처리 후 언로드.
    결과는 기존과 동일한 포맷으로 통합 출력.
    """

    # ---- S3: LocalHFClient.unload() ----

    @mock.patch("eulerforge.loader.AutoTokenizer")
    @mock.patch("eulerforge.loader.AutoModelForCausalLM")
    def test_local_hf_client_unload_clears_model(self, mock_model_cls, mock_tok_cls, tmp_path):
        """S3: unload() 호출 후 model과 tokenizer가 None."""
        model_dir = tmp_path / "fake_model"
        model_dir.mkdir()
        (model_dir / "config.json").write_text('{"model_type": "qwen2"}')
        mock_model_cls.from_pretrained.return_value = mock.MagicMock()
        mock_tok_cls.from_pretrained.return_value = mock.MagicMock()

        client = LocalHFClient(model_dir=str(model_dir))
        assert client.model is not None
        assert client.tokenizer is not None

        client.unload()

        assert client.model is None
        assert client.tokenizer is None

    # ---- S4: ChatClient.unload() / JudgeClient.unload() ----

    def test_chat_client_unload_noop(self):
        """S4: ChatClient.unload()는 no-op (에러 없이 완료)."""
        from eulerforge.utils.bench_client import ChatClient
        client = ChatClient(provider="ollama", model="test")
        client.unload()  # no-op, should not raise

    def test_judge_client_unload_noop(self):
        """S4: JudgeClient.unload()는 no-op."""
        from eulerforge.utils.bench_client import JudgeClient
        client = JudgeClient(provider="ollama", model="test")
        client.unload()  # no-op

    # ---- S1/S2: 순차 실행 흐름 ----

    def test_run_bench_sequential_target_only(self, tmp_path):
        """S1/S2: target-only 모드에서 순차 실행 (target → 결과 통합)."""
        from eulerforge.cli.bench import run_bench

        # 데이터 생성
        data_path = tmp_path / "sft.jsonl"
        items = [{"prompt": f"Q{i}", "response": f"A{i}"} for i in range(3)]
        with open(data_path, "w") as f:
            for item in items:
                f.write(json.dumps(item) + "\n")

        # target mock: chat 호출 순서 추적
        chat_calls = []
        unload_calls = []

        class MockTargetClient:
            def chat(self, messages, gen_cfg=None):
                chat_calls.append(messages[0]["content"])
                return f"target_answer_{len(chat_calls)}"
            def unload(self):
                unload_calls.append("target")

        cfg = {
            "bench": {
                "task": "sft",
                "data_path": str(data_path),
                "sample": {"k": 3, "seed": 42, "shuffle": False},
                "generation": {},
                "output": {"save_jsonl": True, "print_examples": False},
                "models": {
                    "target": {"model": "mock_model", "provider": "ollama"},
                },
            }
        }
        output_dir = str(tmp_path / "output")

        with mock.patch("eulerforge.cli.bench._create_client") as mock_create:
            mock_create.return_value = MockTargetClient()
            run_bench(cfg, output_dir)

        # 모든 데이터에 대해 target 호출됨
        assert len(chat_calls) == 3
        # unload 호출됨
        assert "target" in unload_calls
        # 결과 파일 존재
        assert os.path.isfile(os.path.join(output_dir, "bench_results.jsonl"))
        assert os.path.isfile(os.path.join(output_dir, "bench_summary.json"))

    def test_run_bench_sequential_with_baseline(self, tmp_path):
        """S1/S2: target + baseline 모드에서 순차 실행."""
        from eulerforge.cli.bench import run_bench

        data_path = tmp_path / "sft.jsonl"
        items = [{"prompt": f"Q{i}", "response": f"A{i}"} for i in range(2)]
        with open(data_path, "w") as f:
            for item in items:
                f.write(json.dumps(item) + "\n")

        call_order = []

        class MockClient:
            def __init__(self, name):
                self.name = name
            def chat(self, messages, gen_cfg=None):
                call_order.append(f"{self.name}_chat")
                return f"{self.name}_answer"
            def unload(self):
                call_order.append(f"{self.name}_unload")

        cfg = {
            "bench": {
                "task": "sft",
                "data_path": str(data_path),
                "sample": {"k": 2, "seed": 42, "shuffle": False},
                "generation": {},
                "output": {"save_jsonl": True, "print_examples": False},
                "models": {
                    "target": {"model": "target_m", "provider": "ollama"},
                    "baseline": {"enabled": True, "model": "baseline_m", "provider": "ollama"},
                },
            }
        }
        output_dir = str(tmp_path / "output")

        def create_side_effect(model_cfg, role):
            return MockClient(role)

        with mock.patch("eulerforge.cli.bench._create_client", side_effect=create_side_effect):
            run_bench(cfg, output_dir)

        # target 전체 → 언로드 → baseline 전체 → 언로드
        assert call_order == [
            "target_chat", "target_chat", "target_unload",
            "baseline_chat", "baseline_chat", "baseline_unload",
        ]

    def test_run_bench_sequential_with_judge_pointwise(self, tmp_path):
        """S1/S2/S7: target + judge(pointwise) 순차 실행."""
        from eulerforge.cli.bench import run_bench

        data_path = tmp_path / "sft.jsonl"
        items = [{"prompt": f"Q{i}", "response": f"A{i}"} for i in range(2)]
        with open(data_path, "w") as f:
            for item in items:
                f.write(json.dumps(item) + "\n")

        call_order = []

        class MockTargetClient:
            def chat(self, messages, gen_cfg=None):
                call_order.append("target_chat")
                return "target_answer"
            def unload(self):
                call_order.append("target_unload")

        class MockJudgeClient:
            def __init__(self):
                self.mode = "pointwise"
            def score_pointwise(self, prompt, response, gen_cfg=None):
                call_order.append("judge_score")
                return {"score": 8, "explanation": "good"}
            def unload(self):
                call_order.append("judge_unload")

        cfg = {
            "bench": {
                "task": "sft",
                "data_path": str(data_path),
                "sample": {"k": 2, "seed": 42, "shuffle": False},
                "generation": {},
                "output": {"save_jsonl": True, "print_examples": False},
                "models": {
                    "target": {"model": "target_m", "provider": "ollama"},
                    "judge": {"enabled": True, "model": "judge_m", "provider": "ollama", "mode": "pointwise"},
                },
            }
        }
        output_dir = str(tmp_path / "output")

        clients = {"target": MockTargetClient(), "judge": MockJudgeClient()}
        def create_side_effect(model_cfg, role):
            return clients[role]

        with mock.patch("eulerforge.cli.bench._create_client", side_effect=create_side_effect):
            run_bench(cfg, output_dir)

        # target 전체 → 언로드 → judge 전체 → 언로드
        assert call_order == [
            "target_chat", "target_chat", "target_unload",
            "judge_score", "judge_score", "judge_unload",
        ]

    def test_run_bench_sequential_pairwise_uses_both_responses(self, tmp_path):
        """S7: pairwise judge는 target + baseline 응답을 모두 참조."""
        from eulerforge.cli.bench import run_bench

        data_path = tmp_path / "sft.jsonl"
        items = [{"prompt": "Q0", "response": "A0"}]
        with open(data_path, "w") as f:
            for item in items:
                f.write(json.dumps(item) + "\n")

        pairwise_args = []

        class MockTargetClient:
            def chat(self, messages, gen_cfg=None):
                return "target_resp"
            def unload(self):
                pass

        class MockBaselineClient:
            def chat(self, messages, gen_cfg=None):
                return "baseline_resp"
            def unload(self):
                pass

        class MockJudgeClient:
            def __init__(self):
                self.mode = "pairwise"
            def score_pairwise(self, prompt, resp_a, resp_b, gen_cfg=None):
                pairwise_args.append((prompt, resp_a, resp_b))
                return {"winner": "A", "score_a": 9, "score_b": 6, "explanation": "better"}
            def unload(self):
                pass

        cfg = {
            "bench": {
                "task": "sft",
                "data_path": str(data_path),
                "sample": {"k": 1, "seed": 42, "shuffle": False},
                "generation": {},
                "output": {"save_jsonl": True, "print_examples": False},
                "models": {
                    "target": {"model": "t", "provider": "ollama"},
                    "baseline": {"enabled": True, "model": "b", "provider": "ollama"},
                    "judge": {"enabled": True, "model": "j", "provider": "ollama", "mode": "pairwise"},
                },
            }
        }
        output_dir = str(tmp_path / "output")

        roles = {"target": MockTargetClient(), "baseline": MockBaselineClient(), "judge": MockJudgeClient()}
        def create_side_effect(model_cfg, role):
            return roles[role]

        with mock.patch("eulerforge.cli.bench._create_client", side_effect=create_side_effect):
            run_bench(cfg, output_dir)

        # judge가 target_resp과 baseline_resp을 참조
        assert len(pairwise_args) == 1
        assert pairwise_args[0][1] == "target_resp"
        assert pairwise_args[0][2] == "baseline_resp"

    # ---- S5/S6: 결과 통합 + 출력 포맷 ----

    def test_run_bench_sequential_consolidates_results(self, tmp_path):
        """S5/S6: 순차 실행 후 결과가 기존과 동일한 entry 구조로 통합."""
        from eulerforge.cli.bench import run_bench

        data_path = tmp_path / "sft.jsonl"
        items = [{"prompt": "Q0", "response": "A0"}]
        with open(data_path, "w") as f:
            for item in items:
                f.write(json.dumps(item) + "\n")

        class MockTargetClient:
            def chat(self, messages, gen_cfg=None):
                return "target_answer"
            def unload(self):
                pass

        class MockBaselineClient:
            def chat(self, messages, gen_cfg=None):
                return "baseline_answer"
            def unload(self):
                pass

        class MockJudgeClient:
            def __init__(self):
                self.mode = "pointwise"
            def score_pointwise(self, prompt, response, gen_cfg=None):
                return {"score": 7, "explanation": "ok"}
            def unload(self):
                pass

        cfg = {
            "bench": {
                "task": "sft",
                "data_path": str(data_path),
                "sample": {"k": 1, "seed": 42, "shuffle": False},
                "generation": {},
                "output": {"save_jsonl": True, "print_examples": False},
                "models": {
                    "target": {"model": "t", "provider": "ollama"},
                    "baseline": {"enabled": True, "model": "b", "provider": "ollama"},
                    "judge": {"enabled": True, "model": "j", "provider": "ollama", "mode": "pointwise"},
                },
            }
        }
        output_dir = str(tmp_path / "output")

        roles = {"target": MockTargetClient(), "baseline": MockBaselineClient(), "judge": MockJudgeClient()}
        def create_side_effect(model_cfg, role):
            return roles[role]

        with mock.patch("eulerforge.cli.bench._create_client", side_effect=create_side_effect):
            run_bench(cfg, output_dir)

        # bench_results.jsonl 검증
        results_path = os.path.join(output_dir, "bench_results.jsonl")
        with open(results_path) as f:
            entries = [json.loads(line) for line in f]

        assert len(entries) == 1
        entry = entries[0]
        assert entry["target_response"] == "target_answer"
        assert entry["baseline_response"] == "baseline_answer"
        assert entry["judge_result"]["score"] == 7
        assert "prompt" in entry
        assert "id" in entry

    # ---- S8: dry-run ----

    def test_dry_run_skips_sequential_loading(self, tmp_path, capsys):
        """S8: dry-run은 모델 로딩 없이 샘플만 출력."""
        from eulerforge.cli.bench import run_bench

        data_path = tmp_path / "sft.jsonl"
        items = [{"prompt": f"Q{i}", "response": f"A{i}"} for i in range(3)]
        with open(data_path, "w") as f:
            for item in items:
                f.write(json.dumps(item) + "\n")

        cfg = {
            "bench": {
                "task": "sft",
                "data_path": str(data_path),
                "sample": {"k": 3, "seed": 42, "shuffle": False},
                "generation": {},
                "output": {"save_jsonl": True, "print_examples": False},
                "models": {
                    "target": {"model": "t", "provider": "ollama"},
                },
            }
        }
        output_dir = str(tmp_path / "output")

        # _create_client should never be called
        with mock.patch("eulerforge.cli.bench._create_client") as mock_create:
            run_bench(cfg, output_dir, dry_run=True)
            mock_create.assert_not_called()

        out = capsys.readouterr().out
        assert "Dry-run" in out

    # ---- 순차 실행 시 에러 처리 ----

    def test_run_bench_sequential_target_error_continues(self, tmp_path):
        """target 응답 실패 시 [ERROR] 기록 후 다음 샘플 계속."""
        from eulerforge.cli.bench import run_bench

        data_path = tmp_path / "sft.jsonl"
        items = [{"prompt": f"Q{i}", "response": f"A{i}"} for i in range(2)]
        with open(data_path, "w") as f:
            for item in items:
                f.write(json.dumps(item) + "\n")

        call_count = [0]

        class MockTargetClient:
            def chat(self, messages, gen_cfg=None):
                call_count[0] += 1
                if call_count[0] == 1:
                    raise RuntimeError("API timeout")
                return "ok"
            def unload(self):
                pass

        cfg = {
            "bench": {
                "task": "sft",
                "data_path": str(data_path),
                "sample": {"k": 2, "seed": 42, "shuffle": False},
                "generation": {},
                "output": {"save_jsonl": True, "print_examples": False},
                "models": {
                    "target": {"model": "t", "provider": "ollama"},
                },
            }
        }
        output_dir = str(tmp_path / "output")

        with mock.patch("eulerforge.cli.bench._create_client", return_value=MockTargetClient()):
            run_bench(cfg, output_dir)

        results_path = os.path.join(output_dir, "bench_results.jsonl")
        with open(results_path) as f:
            entries = [json.loads(line) for line in f]

        assert len(entries) == 2
        assert "[ERROR]" in entries[0]["target_response"]
        assert entries[1]["target_response"] == "ok"

    # ---- summary 검증 ----

    def test_run_bench_sequential_summary_correct(self, tmp_path):
        """순차 실행 후 summary에 avg_score, target_model 등 포함."""
        from eulerforge.cli.bench import run_bench

        data_path = tmp_path / "sft.jsonl"
        items = [{"prompt": f"Q{i}", "response": f"A{i}"} for i in range(2)]
        with open(data_path, "w") as f:
            for item in items:
                f.write(json.dumps(item) + "\n")

        class MockTargetClient:
            def chat(self, messages, gen_cfg=None):
                return "answer"
            def unload(self):
                pass

        class MockJudgeClient:
            def __init__(self):
                self.mode = "pointwise"
            def score_pointwise(self, prompt, response, gen_cfg=None):
                return {"score": 8, "explanation": "good"}
            def unload(self):
                pass

        cfg = {
            "bench": {
                "task": "sft",
                "data_path": str(data_path),
                "sample": {"k": 2, "seed": 42, "shuffle": False},
                "generation": {},
                "output": {"save_jsonl": True, "print_examples": False},
                "models": {
                    "target": {"model": "t_model", "provider": "ollama"},
                    "judge": {"enabled": True, "model": "j_model", "provider": "ollama", "mode": "pointwise"},
                },
            }
        }
        output_dir = str(tmp_path / "output")

        clients = {"target": MockTargetClient(), "judge": MockJudgeClient()}
        def create_side_effect(model_cfg, role):
            return clients[role]

        with mock.patch("eulerforge.cli.bench._create_client", side_effect=create_side_effect):
            run_bench(cfg, output_dir)

        summary_path = os.path.join(output_dir, "bench_summary.json")
        with open(summary_path) as f:
            summary = json.load(f)

        assert summary["total_samples"] == 2
        assert summary["avg_score"] == 8.0
        assert summary["target_model"] == "t_model"

    # ---- print_examples 통합 출력 검증 ----

    def test_run_bench_sequential_prints_consolidated(self, tmp_path, capsys):
        """S6: 순차 실행 후 통합 결과가 터미널에 출력."""
        from eulerforge.cli.bench import run_bench

        data_path = tmp_path / "sft.jsonl"
        items = [{"prompt": "Q0", "response": "A0"}]
        with open(data_path, "w") as f:
            for item in items:
                f.write(json.dumps(item) + "\n")

        class MockTargetClient:
            def chat(self, messages, gen_cfg=None):
                return "target_text"
            def unload(self):
                pass

        class MockBaselineClient:
            def chat(self, messages, gen_cfg=None):
                return "baseline_text"
            def unload(self):
                pass

        cfg = {
            "bench": {
                "task": "sft",
                "data_path": str(data_path),
                "sample": {"k": 1, "seed": 42, "shuffle": False},
                "generation": {},
                "output": {"save_jsonl": True, "print_examples": True, "print_max_chars": 1500},
                "models": {
                    "target": {"model": "t", "provider": "ollama"},
                    "baseline": {"enabled": True, "model": "b", "provider": "ollama"},
                },
            }
        }
        output_dir = str(tmp_path / "output")

        roles = {"target": MockTargetClient(), "baseline": MockBaselineClient()}
        def create_side_effect(model_cfg, role):
            return roles[role]

        with mock.patch("eulerforge.cli.bench._create_client", side_effect=create_side_effect):
            run_bench(cfg, output_dir)

        out = capsys.readouterr().out
        assert "target_text" in out
        assert "baseline_text" in out
