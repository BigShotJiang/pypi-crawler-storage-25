# tests/test_lora_handoff.py
"""
Unit tests for LoRA Handoff Scheduling.
Tests fade calculation, lora_scale application, end_action, and base_ffn ramp.
Per docs/fixtures/specs/lora_handoff_spec.md.
"""
from __future__ import annotations

import logging
import math
import pytest
import torch
import torch.nn as nn

from eulerforge.handoff.scheduler import (
    LoraHandoffScheduler,
    HandoffStepResult,
    compute_fade_pct,
    compute_lora_scale,
)
from eulerforge.modules.lora import LoRALinear
from eulerforge.modules.mixture_lora import MixtureLoRALinear


# ===========================================================================
# TestFadeCalculation
# ===========================================================================

class TestFadeCalculation:
    def test_linear_fade_midpoint(self):
        pct = compute_fade_pct(
            step=1500, start_step=1000, duration_steps=1000, curve="linear"
        )
        assert abs(pct - 50.0) < 1e-6

    def test_linear_fade_before_start(self):
        pct = compute_fade_pct(
            step=500, start_step=1000, duration_steps=1000, curve="linear"
        )
        assert pct == 0.0

    def test_linear_fade_after_end(self):
        pct = compute_fade_pct(
            step=3000, start_step=1000, duration_steps=1000, curve="linear"
        )
        assert pct == 100.0

    def test_cosine_fade_midpoint(self):
        pct = compute_fade_pct(
            step=1500, start_step=1000, duration_steps=1000, curve="cosine"
        )
        # cosine at progress=0.5: (1 - cos(π*0.5)) / 2 = (1 - 0) / 2 = 0.5
        assert abs(pct - 50.0) < 1e-6

    def test_cosine_fade_endpoints(self):
        pct_start = compute_fade_pct(
            step=1000, start_step=1000, duration_steps=1000, curve="cosine"
        )
        pct_end = compute_fade_pct(
            step=2000, start_step=1000, duration_steps=1000, curve="cosine"
        )
        assert abs(pct_start - 0.0) < 1e-6
        assert abs(pct_end - 100.0) < 1e-6

    def test_partial_end_scale(self):
        scale = compute_lora_scale(fade_pct=100.0, end_scale=0.3)
        assert abs(scale - 0.3) < 1e-6

    def test_full_fade_zero_scale(self):
        scale = compute_lora_scale(fade_pct=100.0, end_scale=0.0)
        assert abs(scale - 0.0) < 1e-6

    def test_no_fade_scale_one(self):
        scale = compute_lora_scale(fade_pct=0.0, end_scale=0.0)
        assert abs(scale - 1.0) < 1e-6

    def test_mid_fade_with_end_scale(self):
        # fade_pct=50, end_scale=0.2 → scale = 1.0 - 0.5 * (1.0 - 0.2) = 1.0 - 0.4 = 0.6
        scale = compute_lora_scale(fade_pct=50.0, end_scale=0.2)
        assert abs(scale - 0.6) < 1e-6


# ===========================================================================
# TestLoraScaleApplication
# ===========================================================================

class TestLoraScaleApplication:
    @pytest.fixture
    def lora_linear(self):
        base = nn.Linear(8, 4, bias=False)
        ll = LoRALinear(base, r=4, alpha=4.0)
        return ll

    @pytest.fixture
    def mixture_lora_linear(self):
        base = nn.Linear(8, 4, bias=False)
        ml = MixtureLoRALinear(base, num_experts=2, top_k=1, r=4, alpha=4.0, dropout=0.0)
        return ml

    def test_default_scale_is_one(self, lora_linear):
        assert lora_linear.lora_scale == 1.0

    def test_lora_linear_scale_applied(self, lora_linear):
        x = torch.randn(2, 8)
        # Full scale
        lora_linear.lora_scale = 1.0
        out_full = lora_linear(x)
        # Half scale
        lora_linear.lora_scale = 0.5
        out_half = lora_linear(x)
        # Zero scale = base only
        lora_linear.lora_scale = 0.0
        out_zero = lora_linear(x)

        base_out = lora_linear.base_layer(x)
        # out_zero should equal base_out
        assert torch.allclose(out_zero, base_out, atol=1e-5)
        # out_half should be between base and full
        lora_delta_full = out_full - base_out
        lora_delta_half = out_half - base_out
        # half should be ~0.5 * full delta
        assert torch.allclose(lora_delta_half, lora_delta_full * 0.5, atol=1e-5)

    def test_mixture_lora_default_scale(self, mixture_lora_linear):
        assert mixture_lora_linear.lora_scale == 1.0

    def test_mixture_lora_scale_applied(self, mixture_lora_linear):
        x = torch.randn(2, 8)
        mixture_lora_linear.lora_scale = 1.0
        out_full = mixture_lora_linear(x)

        mixture_lora_linear.lora_scale = 0.0
        out_zero = mixture_lora_linear(x)

        base_out = mixture_lora_linear.base_layer(x)
        assert torch.allclose(out_zero, base_out, atol=1e-5)

    def test_scale_zero_equals_base_only(self, lora_linear):
        x = torch.randn(3, 8)
        lora_linear.lora_scale = 0.0
        out = lora_linear(x)
        base_out = lora_linear.base_layer(x)
        assert torch.allclose(out, base_out, atol=1e-6)


# ===========================================================================
# TestEndAction
# ===========================================================================

class TestEndAction:
    def test_freeze_sets_requires_grad_false(self):
        """end_action=freeze should freeze LoRA params after fade completes."""
        base = nn.Linear(8, 4, bias=False)
        ll = LoRALinear(base, r=4, alpha=4.0)
        # Initially LoRA params are trainable
        assert ll.lora_A.requires_grad
        assert ll.lora_B.requires_grad

        scheduler = LoraHandoffScheduler({
            "expert_lora": {
                "start_step": 0,
                "duration_steps": 100,
                "end_scale": 0.0,
                "end_action": "freeze",
            },
        })

        # Build a simple model containing the LoRALinear
        model = nn.ModuleDict({"ffn": nn.ModuleDict({"gate_proj": ll})})

        # Step past the end
        result = scheduler.step(model, 200)
        assert result.expert_lora_frozen
        assert not ll.lora_A.requires_grad
        assert not ll.lora_B.requires_grad

    def test_keep_preserves_requires_grad(self):
        base = nn.Linear(8, 4, bias=False)
        ll = LoRALinear(base, r=4, alpha=4.0)
        ll.lora_A.requires_grad = True
        ll.lora_B.requires_grad = True

        scheduler = LoraHandoffScheduler({
            "expert_lora": {
                "start_step": 0,
                "duration_steps": 100,
                "end_scale": 0.0,
                "end_action": "keep",
            },
        })

        model = nn.ModuleDict({"ffn": nn.ModuleDict({"gate_proj": ll})})
        result = scheduler.step(model, 200)
        assert not result.expert_lora_frozen
        assert ll.lora_A.requires_grad
        assert ll.lora_B.requires_grad


# ===========================================================================
# TestBaseFfnRamp
# ===========================================================================

class TestBaseFfnRamp:
    def test_ramp_before_start(self):
        scheduler = LoraHandoffScheduler({
            "base_ffn_ramp": {
                "start_step": 1000,
                "end_step": 5000,
                "start_multiplier": 1.0,
                "end_multiplier": 3.0,
            },
        })
        mult = scheduler.get_base_ffn_lr_multiplier(500)
        assert abs(mult - 1.0) < 1e-6

    def test_ramp_midpoint(self):
        scheduler = LoraHandoffScheduler({
            "base_ffn_ramp": {
                "start_step": 1000,
                "end_step": 5000,
                "start_multiplier": 1.0,
                "end_multiplier": 3.0,
            },
        })
        mult = scheduler.get_base_ffn_lr_multiplier(3000)
        # progress = (3000-1000)/(5000-1000) = 0.5 → 1.0 + 0.5 * 2.0 = 2.0
        assert abs(mult - 2.0) < 1e-6

    def test_ramp_after_end(self):
        scheduler = LoraHandoffScheduler({
            "base_ffn_ramp": {
                "start_step": 1000,
                "end_step": 5000,
                "start_multiplier": 1.0,
                "end_multiplier": 3.0,
            },
        })
        mult = scheduler.get_base_ffn_lr_multiplier(6000)
        assert abs(mult - 3.0) < 1e-6

    def test_ramp_default_multipliers(self):
        """If no multipliers specified, defaults to 1.0."""
        scheduler = LoraHandoffScheduler({
            "base_ffn_ramp": {
                "start_step": 0,
                "end_step": 100,
            },
        })
        mult = scheduler.get_base_ffn_lr_multiplier(50)
        assert abs(mult - 1.0) < 1e-6

    def test_no_ramp_returns_one(self):
        """If no base_ffn_ramp section, multiplier is always 1.0."""
        scheduler = LoraHandoffScheduler({
            "expert_lora": {
                "start_step": 0,
                "duration_steps": 100,
            },
        })
        mult = scheduler.get_base_ffn_lr_multiplier(50)
        assert abs(mult - 1.0) < 1e-6


# ===========================================================================
# TestHandoffStepResult
# ===========================================================================

class TestHandoffStepResult:
    def test_needs_optimizer_rebuild_on_freeze(self):
        result = HandoffStepResult(
            expert_lora_scale=0.0,
            attn_lora_scale=None,
            expert_lora_frozen=True,
            attn_lora_frozen=False,
            base_ffn_lr_multiplier=1.0,
            needs_optimizer_rebuild=True,
        )
        assert result.needs_optimizer_rebuild

    def test_no_rebuild_without_freeze(self):
        result = HandoffStepResult(
            expert_lora_scale=0.5,
            attn_lora_scale=None,
            expert_lora_frozen=False,
            attn_lora_frozen=False,
            base_ffn_lr_multiplier=1.0,
            needs_optimizer_rebuild=False,
        )
        assert not result.needs_optimizer_rebuild


# ===========================================================================
# TestExportLogic
# ===========================================================================

class TestExportLogic:
    def test_remove_zero_scale_adapters(self):
        """LoRA modules with scale=0 should be removable."""
        from eulerforge.handoff.scheduler import remove_zero_scale_adapters

        base = nn.Linear(8, 4, bias=False)
        ll = LoRALinear(base, r=4, alpha=4.0)
        ll.lora_scale = 0.0

        model = nn.ModuleDict({"layer": nn.ModuleDict({"gate_proj": ll})})
        removed = remove_zero_scale_adapters(model)
        assert removed > 0
        # After removal, gate_proj should be a plain nn.Linear
        assert isinstance(model.layer.gate_proj, nn.Linear)
        assert not isinstance(model.layer.gate_proj, LoRALinear)

    def test_merge_adapters_on_export(self):
        """LoRA should be merged into base weights."""
        from eulerforge.handoff.scheduler import merge_adapters_into_base

        base = nn.Linear(8, 4, bias=False)
        ll = LoRALinear(base, r=4, alpha=4.0)
        # Set known LoRA weights
        nn.init.ones_(ll.lora_A)
        nn.init.ones_(ll.lora_B)

        x = torch.randn(2, 8)
        ll.lora_scale = 1.0
        expected_out = ll(x)

        model = nn.ModuleDict({"layer": nn.ModuleDict({"gate_proj": ll})})
        merged = merge_adapters_into_base(model)
        assert merged > 0

        # After merge, gate_proj should be plain nn.Linear with merged weights
        merged_layer = model.layer.gate_proj
        assert isinstance(merged_layer, nn.Linear)
        assert not isinstance(merged_layer, LoRALinear)

        actual_out = merged_layer(x)
        assert torch.allclose(actual_out, expected_out, atol=1e-4)

    def test_no_removal_when_scale_nonzero(self):
        """LoRA with non-zero scale should not be removed."""
        from eulerforge.handoff.scheduler import remove_zero_scale_adapters

        base = nn.Linear(8, 4, bias=False)
        ll = LoRALinear(base, r=4, alpha=4.0)
        ll.lora_scale = 0.5

        model = nn.ModuleDict({"layer": nn.ModuleDict({"gate_proj": ll})})
        removed = remove_zero_scale_adapters(model)
        assert removed == 0
        assert isinstance(model.layer.gate_proj, LoRALinear)


# ===========================================================================
# TestHandoffLogging
# ===========================================================================

class TestHandoffLogging:
    """Handoff milestone/periodic logging tests."""

    def _make_model_with_expert_lora(self):
        base = nn.Linear(8, 4, bias=False)
        ll = LoRALinear(base, r=4, alpha=4.0)
        return nn.ModuleDict({"ffn": nn.ModuleDict({"gate_proj": ll})})

    def _make_model_with_attn_lora(self):
        base = nn.Linear(8, 4, bias=False)
        ll = LoRALinear(base, r=4, alpha=4.0)
        return nn.ModuleDict({"attn": nn.ModuleDict({"q_proj": ll})})

    def _make_model_with_both(self):
        base_e = nn.Linear(8, 4, bias=False)
        ll_e = LoRALinear(base_e, r=4, alpha=4.0)
        base_a = nn.Linear(8, 4, bias=False)
        ll_a = LoRALinear(base_a, r=4, alpha=4.0)
        return nn.ModuleDict({
            "ffn": nn.ModuleDict({"gate_proj": ll_e}),
            "attn": nn.ModuleDict({"q_proj": ll_a}),
        })

    # ---- Milestone: fade start ----

    def test_expert_lora_fade_start_logged(self, caplog):
        """expert_lora fade 시작 시 '[Handoff] expert_lora fade 시작' 로그."""
        scheduler = LoraHandoffScheduler({
            "expert_lora": {
                "start_step": 100,
                "duration_steps": 200,
                "end_scale": 0.0,
                "curve": "cosine",
                "end_action": "freeze",
            },
        })
        model = self._make_model_with_expert_lora()

        with caplog.at_level(logging.INFO, logger="eulerforge.handoff.scheduler"):
            # Before start — no fade log
            scheduler.step(model, 50)
            assert not any("fade" in r.message and "expert_lora" in r.message for r in caplog.records)

            caplog.clear()
            # At start_step — fade start logged
            scheduler.step(model, 100)
            fade_start_msgs = [r for r in caplog.records if "expert_lora" in r.message and "fade" in r.message.lower() and ("시작" in r.message or "start" in r.message.lower())]
            assert len(fade_start_msgs) == 1

            caplog.clear()
            # Subsequent step — no duplicate start log
            scheduler.step(model, 101)
            fade_start_again = [r for r in caplog.records if "expert_lora" in r.message and ("시작" in r.message or "start" in r.message.lower())]
            assert len(fade_start_again) == 0

    def test_attn_lora_fade_start_logged(self, caplog):
        """attn_lora fade 시작 시 로그."""
        scheduler = LoraHandoffScheduler({
            "attn_lora": {
                "start_step": 200,
                "duration_steps": 100,
                "end_scale": 0.0,
                "curve": "linear",
                "end_action": "freeze",
            },
        })
        model = self._make_model_with_attn_lora()

        with caplog.at_level(logging.INFO, logger="eulerforge.handoff.scheduler"):
            scheduler.step(model, 200)
            fade_msgs = [r for r in caplog.records if "attn_lora" in r.message and ("시작" in r.message or "start" in r.message.lower())]
            assert len(fade_msgs) == 1

    # ---- Milestone: fade complete ----

    def test_expert_lora_fade_complete_logged(self, caplog):
        """expert_lora fade 완료 시 '[Handoff] expert_lora fade 완료' 로그."""
        scheduler = LoraHandoffScheduler({
            "expert_lora": {
                "start_step": 100,
                "duration_steps": 200,
                "end_scale": 0.0,
                "curve": "linear",
                "end_action": "keep",  # keep, not freeze (freeze has its own log)
            },
        })
        model = self._make_model_with_expert_lora()

        with caplog.at_level(logging.INFO, logger="eulerforge.handoff.scheduler"):
            scheduler.step(model, 100)  # start
            caplog.clear()
            scheduler.step(model, 300)  # complete
            complete_msgs = [r for r in caplog.records if "expert_lora" in r.message and ("완료" in r.message or "complete" in r.message.lower())]
            assert len(complete_msgs) == 1

    def test_fade_complete_logged_only_once(self, caplog):
        """fade 완료 로그는 한 번만 출력."""
        scheduler = LoraHandoffScheduler({
            "expert_lora": {
                "start_step": 0,
                "duration_steps": 100,
                "end_scale": 0.0,
                "curve": "linear",
                "end_action": "keep",
            },
        })
        model = self._make_model_with_expert_lora()

        with caplog.at_level(logging.INFO, logger="eulerforge.handoff.scheduler"):
            scheduler.step(model, 100)  # complete (first)
            scheduler.step(model, 101)  # should not repeat
            scheduler.step(model, 200)  # should not repeat
            complete_msgs = [r for r in caplog.records if "expert_lora" in r.message and ("완료" in r.message or "complete" in r.message.lower())]
            assert len(complete_msgs) == 1

    # ---- Milestone: base_ffn_ramp ----

    def test_base_ffn_ramp_start_logged(self, caplog):
        """base_ffn_ramp 시작 시 로그."""
        scheduler = LoraHandoffScheduler({
            "base_ffn_ramp": {
                "start_step": 500,
                "end_step": 1000,
                "start_multiplier": 1.0,
                "end_multiplier": 3.0,
            },
        })
        model = nn.ModuleDict({})  # ramp doesn't need LoRA modules

        with caplog.at_level(logging.INFO, logger="eulerforge.handoff.scheduler"):
            scheduler.step(model, 400)  # before ramp
            assert not any("base_ffn_ramp" in r.message for r in caplog.records)

            caplog.clear()
            scheduler.step(model, 500)  # ramp start
            ramp_msgs = [r for r in caplog.records if "base_ffn_ramp" in r.message and ("시작" in r.message or "start" in r.message.lower())]
            assert len(ramp_msgs) == 1

    def test_base_ffn_ramp_end_logged(self, caplog):
        """base_ffn_ramp 완료 시 로그."""
        scheduler = LoraHandoffScheduler({
            "base_ffn_ramp": {
                "start_step": 0,
                "end_step": 100,
                "start_multiplier": 1.0,
                "end_multiplier": 3.0,
            },
        })
        model = nn.ModuleDict({})

        with caplog.at_level(logging.INFO, logger="eulerforge.handoff.scheduler"):
            scheduler.step(model, 0)  # start
            caplog.clear()
            scheduler.step(model, 100)  # end
            end_msgs = [r for r in caplog.records if "base_ffn_ramp" in r.message and ("완료" in r.message or "complete" in r.message.lower())]
            assert len(end_msgs) == 1

    # ---- format_status ----

    def test_format_status_during_fade(self):
        """fade 진행 중 format_status()가 scale 정보를 포함."""
        scheduler = LoraHandoffScheduler({
            "expert_lora": {
                "start_step": 0,
                "duration_steps": 100,
                "end_scale": 0.0,
                "curve": "linear",
                "end_action": "freeze",
            },
        })
        model = self._make_model_with_expert_lora()
        scheduler.step(model, 50)
        status = scheduler.format_status(50)
        assert status is not None
        assert "expert_lora" in status
        # At step 50/100, scale should be ~0.5
        assert "0.50" in status or "0.5" in status

    def test_format_status_before_fade_returns_none(self):
        """fade 시작 전 format_status()는 None."""
        scheduler = LoraHandoffScheduler({
            "expert_lora": {
                "start_step": 1000,
                "duration_steps": 100,
                "end_scale": 0.0,
                "curve": "linear",
                "end_action": "freeze",
            },
        })
        status = scheduler.format_status(0)
        assert status is None

    def test_format_status_with_ramp(self):
        """base_ffn_ramp 진행 중 format_status()에 LR multiplier 포함."""
        scheduler = LoraHandoffScheduler({
            "expert_lora": {
                "start_step": 0,
                "duration_steps": 100,
                "end_scale": 0.0,
                "curve": "linear",
                "end_action": "freeze",
            },
            "base_ffn_ramp": {
                "start_step": 0,
                "end_step": 100,
                "start_multiplier": 1.0,
                "end_multiplier": 3.0,
            },
        })
        status = scheduler.format_status(50)
        assert status is not None
        assert "ramp" in status.lower() or "mult" in status.lower() or "lr" in status.lower()

    def test_format_status_both_components(self):
        """expert_lora + attn_lora 동시 fade 시 둘 다 표시."""
        scheduler = LoraHandoffScheduler({
            "expert_lora": {
                "start_step": 0,
                "duration_steps": 100,
                "end_scale": 0.0,
                "curve": "linear",
                "end_action": "freeze",
            },
            "attn_lora": {
                "start_step": 0,
                "duration_steps": 100,
                "end_scale": 0.0,
                "curve": "linear",
                "end_action": "freeze",
            },
        })
        status = scheduler.format_status(50)
        assert "expert_lora" in status
        assert "attn_lora" in status

    # ---- Init summary log ----

    def test_init_logs_schedule_summary(self, caplog):
        """LoraHandoffScheduler 생성 시 스케줄 요약 로그."""
        with caplog.at_level(logging.INFO, logger="eulerforge.handoff.scheduler"):
            LoraHandoffScheduler({
                "expert_lora": {
                    "start_step": 4000,
                    "duration_steps": 2000,
                    "end_scale": 0.0,
                    "curve": "cosine",
                    "end_action": "freeze",
                },
                "attn_lora": {
                    "start_step": 4000,
                    "duration_steps": 2000,
                    "end_scale": 0.0,
                    "curve": "linear",
                    "end_action": "freeze",
                },
                "base_ffn_ramp": {
                    "start_step": 2000,
                    "end_step": 4000,
                    "start_multiplier": 1.0,
                    "end_multiplier": 3.0,
                },
            })
            # Should log schedule summary with step ranges
            init_msgs = [r for r in caplog.records if "Handoff" in r.message]
            assert len(init_msgs) >= 1
            # Should mention expert_lora step range
            all_text = " ".join(r.message for r in init_msgs)
            assert "4000" in all_text
            assert "expert_lora" in all_text
