# tests/test_metrics.py
# -*- coding: utf-8 -*-
"""
TDD tests for eulerforge.utils.metrics.

Tests:
- MetricsCollector: 2-level metrics collection (minimal/advanced)
- TBWriter: TensorBoard wrapper with graceful fallback
- collect_moe_metrics: MoE module metric extraction
- compute_grad_norm: global L2 gradient norm
"""
from __future__ import annotations

import os
import tempfile
from unittest.mock import MagicMock, patch

import pytest
import torch
import torch.nn as nn

from eulerforge.utils.metrics import (
    MetricsCollector,
    TBWriter,
    collect_moe_metrics,
    compute_grad_norm,
    VALID_METRICS_LEVELS,
)


# ============================================================================
# Helpers / Mocks
# ============================================================================

def _make_simple_model() -> nn.Module:
    """A simple linear model with no MoE modules."""
    model = nn.Sequential(nn.Linear(8, 4), nn.ReLU(), nn.Linear(4, 2))
    return model


def _make_moe_model():
    """Create a model with a mock MoE module that has last_stats."""
    from dataclasses import dataclass

    model = nn.Sequential(nn.Linear(8, 4), nn.Linear(4, 2))

    # Attach a mock MoEFFN-like object as a submodule
    mock_moe = nn.Module()
    mock_moe.__class__.__name__ = "MoEFFN"

    # Simulate MoEStats-like last_stats
    @dataclass
    class FakeStats:
        token_frac: torch.Tensor
        importance: torch.Tensor
        gate_prob_entropy: torch.Tensor
        density: torch.Tensor

    mock_moe.last_stats = FakeStats(
        token_frac=torch.tensor([0.5, 0.3, 0.2]),
        importance=torch.tensor([0.4, 0.35, 0.25]),
        gate_prob_entropy=torch.tensor(1.05),
        density=torch.tensor(1.0),
    )
    mock_moe.last_aux_loss = torch.tensor(0.01)
    mock_moe.last_gate_logits = torch.tensor([[1.0, 2.0, 0.5]])

    model.add_module("moe_layer", mock_moe)
    return model


def _make_mixture_lora_model():
    """Create a model with a mock MixtureLoRALinear module."""
    from dataclasses import dataclass

    model = nn.Sequential(nn.Linear(8, 4))

    mock_ml = nn.Module()
    mock_ml.__class__.__name__ = "MixtureLoRALinear"

    @dataclass
    class FakeMLStats:
        token_frac: torch.Tensor
        token_frac_per_token: torch.Tensor
        gate_prob: torch.Tensor
        entropy: torch.Tensor
        density: torch.Tensor
        importance: torch.Tensor
        total_tokens: int

    mock_ml.last_stats = FakeMLStats(
        token_frac=torch.tensor([0.6, 0.4]),
        token_frac_per_token=torch.tensor([1.2, 0.8]),
        gate_prob=torch.tensor([0.55, 0.45]),
        entropy=torch.tensor(0.95),
        density=torch.tensor([1.0, 1.0]),
        importance=torch.tensor([0.52, 0.48]),
        total_tokens=100,
    )
    mock_ml.last_aux_loss = torch.tensor(0.005)

    model.add_module("mixture_lora_layer", mock_ml)
    return model


# ============================================================================
# 1. TestMetricsCollector
# ============================================================================

class TestMetricsCollector:

    def test_init_minimal_level(self):
        """MetricsCollector(level='minimal') creates successfully."""
        tb = TBWriter(enabled=False, log_dir="")
        mc = MetricsCollector(level="minimal", tb_writer=tb, log_interval=10)
        assert mc.level == "minimal"

    def test_init_advanced_level(self):
        """MetricsCollector(level='advanced') creates successfully."""
        tb = TBWriter(enabled=False, log_dir="")
        mc = MetricsCollector(level="advanced", tb_writer=tb, log_interval=10)
        assert mc.level == "advanced"

    def test_invalid_level_raises(self):
        """level='invalid' raises ValueError."""
        tb = TBWriter(enabled=False, log_dir="")
        with pytest.raises(ValueError, match="Unknown metrics_level"):
            MetricsCollector(level="invalid", tb_writer=tb, log_interval=10)

    def test_log_step_minimal(self):
        """log_step() at minimal level records step, loss, lr, grad_norm."""
        tb = TBWriter(enabled=False, log_dir="")
        mc = MetricsCollector(level="minimal", tb_writer=tb, log_interval=1)

        model = _make_simple_model()
        # Run a dummy forward/backward to get grads
        x = torch.randn(2, 8)
        loss = model(x).sum()
        loss.backward()

        result = mc.log_step(
            step=1,
            main_loss=0.5,
            total_loss=0.55,
            aux_loss=0.05,
            lr=1e-4,
            metrics={"main_loss": 0.5},
            model=model,
            tokens_seen=1024,
            samples_seen=16,
        )

        assert "train/main_loss" in result
        assert "train/total_loss" in result
        assert "train/learning_rate" in result
        assert "train/grad_norm" in result
        assert result["train/main_loss"] == pytest.approx(0.5)
        assert result["train/learning_rate"] == pytest.approx(1e-4)

    def test_log_step_records_throughput(self):
        """log_step records throughput based on tokens_seen."""
        tb = TBWriter(enabled=False, log_dir="")
        mc = MetricsCollector(level="minimal", tb_writer=tb, log_interval=1)
        model = _make_simple_model()

        mc.log_step(
            step=1, main_loss=0.5, total_loss=0.5, aux_loss=None,
            lr=1e-4, metrics={}, model=model,
            tokens_seen=1024, samples_seen=16,
        )
        assert "train/tokens_seen" in mc.get_history()[-1]
        assert "train/samples_seen" in mc.get_history()[-1]

    def test_log_step_minimal_skips_moe(self):
        """minimal level does NOT include moe/* metrics."""
        tb = TBWriter(enabled=False, log_dir="")
        mc = MetricsCollector(level="minimal", tb_writer=tb, log_interval=1)
        model = _make_moe_model()

        result = mc.log_step(
            step=1, main_loss=0.5, total_loss=0.55, aux_loss=0.05,
            lr=1e-4, metrics={}, model=model,
            tokens_seen=1024, samples_seen=16,
        )
        moe_keys = [k for k in result if k.startswith("moe/")]
        assert len(moe_keys) == 0, f"Minimal should skip MoE metrics, got: {moe_keys}"

    def test_log_step_advanced_includes_moe(self):
        """advanced level includes moe/* metrics when MoE modules present."""
        tb = TBWriter(enabled=False, log_dir="")
        mc = MetricsCollector(level="advanced", tb_writer=tb, log_interval=1)
        model = _make_moe_model()

        result = mc.log_step(
            step=1, main_loss=0.5, total_loss=0.55, aux_loss=0.05,
            lr=1e-4, metrics={}, model=model,
            tokens_seen=1024, samples_seen=16,
        )
        moe_keys = [k for k in result if k.startswith("moe/")]
        assert len(moe_keys) > 0, "Advanced should include MoE metrics"
        assert "moe/token_frac_std" in result
        assert "moe/entropy_mean" in result

    def test_get_history(self):
        """get_history returns all recorded step dicts."""
        tb = TBWriter(enabled=False, log_dir="")
        mc = MetricsCollector(level="minimal", tb_writer=tb, log_interval=1)
        model = _make_simple_model()

        for step in range(1, 4):
            mc.log_step(
                step=step, main_loss=0.5 - step * 0.1, total_loss=0.5,
                aux_loss=None, lr=1e-4, metrics={}, model=model,
                tokens_seen=step * 100, samples_seen=step * 10,
            )
        hist = mc.get_history()
        assert len(hist) == 3
        assert hist[0]["train/main_loss"] == pytest.approx(0.4)
        assert hist[2]["train/main_loss"] == pytest.approx(0.2)


# ============================================================================
# 2. TestTensorBoardWriter
# ============================================================================

def _has_tensorboard() -> bool:
    try:
        from torch.utils.tensorboard import SummaryWriter  # noqa: F401
        return True
    except (ImportError, ModuleNotFoundError):
        return False


_tb_installed = pytest.mark.skipif(
    not _has_tensorboard(), reason="tensorboard not installed"
)


class TestTensorBoardWriter:

    @_tb_installed
    def test_writer_creates_logdir(self):
        """enabled=True creates the log directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            log_dir = os.path.join(tmpdir, "tb_logs")
            writer = TBWriter(enabled=True, log_dir=log_dir)
            assert os.path.isdir(log_dir)
            writer.close()

    @_tb_installed
    def test_writer_logs_scalars(self):
        """After add_scalar, event file should exist in log_dir."""
        with tempfile.TemporaryDirectory() as tmpdir:
            log_dir = os.path.join(tmpdir, "tb_logs")
            writer = TBWriter(enabled=True, log_dir=log_dir)
            writer.add_scalar("train/loss", 0.5, 1)
            writer.close()
            # Check that at least one event file was created
            files = os.listdir(log_dir)
            event_files = [f for f in files if "events.out.tfevents" in f]
            assert len(event_files) > 0, f"Expected event file, got: {files}"

    def test_writer_disabled_noop(self):
        """enabled=False does not create files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            log_dir = os.path.join(tmpdir, "tb_noop")
            writer = TBWriter(enabled=False, log_dir=log_dir)
            writer.add_scalar("train/loss", 0.5, 1)
            writer.close()
            assert not os.path.exists(log_dir)

    def test_writer_graceful_no_tensorboard(self):
        """If tensorboard is not installed, should warn but not error."""
        with patch.dict("sys.modules", {"torch.utils.tensorboard": None}):
            with tempfile.TemporaryDirectory() as tmpdir:
                log_dir = os.path.join(tmpdir, "tb_noimport")
                # Should not raise, just log a warning
                writer = TBWriter(enabled=True, log_dir=log_dir)
                writer.add_scalar("train/loss", 0.5, 1)
                writer.close()

    def test_writer_close(self):
        """close() should not raise even when called multiple times."""
        writer = TBWriter(enabled=False, log_dir="")
        writer.close()
        writer.close()  # second call should be safe


# ============================================================================
# 3. TestCollectMoEMetrics
# ============================================================================

class TestCollectMoEMetrics:

    def test_collect_from_moe_ffn(self):
        """collect_moe_metrics extracts stats from MoEFFN modules."""
        model = _make_moe_model()
        result = collect_moe_metrics(model)
        assert "moe/num_moe_modules" in result
        assert result["moe/num_moe_modules"] >= 1

    def test_collect_from_mixture_lora(self):
        """collect_moe_metrics extracts stats from MixtureLoRALinear."""
        model = _make_mixture_lora_model()
        result = collect_moe_metrics(model)
        assert "moe/num_moe_modules" in result
        assert result["moe/num_moe_modules"] >= 1

    def test_collect_empty_model(self):
        """No MoE modules -> empty dict."""
        model = _make_simple_model()
        result = collect_moe_metrics(model)
        assert result == {}

    def test_metrics_include_expected_keys(self):
        """Collected metrics include expected standard keys."""
        model = _make_moe_model()
        result = collect_moe_metrics(model)
        expected_keys = [
            "moe/token_frac_mean",
            "moe/token_frac_std",
            "moe/token_frac_max",
            "moe/entropy_mean",
            "moe/importance_cv",
            "moe/aux_loss_total",
            "moe/num_moe_modules",
        ]
        for key in expected_keys:
            assert key in result, f"Missing key: {key}"


# ============================================================================
# 4. TestComputeGradNorm
# ============================================================================

class TestComputeGradNorm:

    def test_global_l2_norm(self):
        """compute_grad_norm returns correct L2 norm after backward."""
        model = nn.Linear(4, 2)
        x = torch.randn(3, 4)
        loss = model(x).sum()
        loss.backward()

        norm = compute_grad_norm(model)
        assert norm > 0.0

        # Verify against manual computation
        expected = 0.0
        for p in model.parameters():
            if p.grad is not None:
                expected += p.grad.data.norm(2).item() ** 2
        expected = expected ** 0.5
        assert norm == pytest.approx(expected, rel=1e-5)

    def test_no_grad_returns_zero(self):
        """No gradients -> returns 0.0."""
        model = nn.Linear(4, 2)
        norm = compute_grad_norm(model)
        assert norm == 0.0


# ============================================================================
# 5. TestStepCounterMetrics
# ============================================================================

class TestStepCounterMetrics:
    """Verify MetricsCollector records optimizer_step, micro_step, effective_batch."""

    def test_log_step_records_optimizer_step(self):
        """log_step records train/optimizer_step tag."""
        tb = TBWriter(enabled=False, log_dir="")
        mc = MetricsCollector(level="minimal", tb_writer=tb, log_interval=1)
        model = _make_simple_model()

        result = mc.log_step(
            step=10, main_loss=0.5, total_loss=0.5, aux_loss=None,
            lr=1e-4, metrics={}, model=model,
            tokens_seen=1024, samples_seen=16,
            optimizer_step=3, effective_batch=16,
        )
        assert "train/optimizer_step" in result
        assert result["train/optimizer_step"] == pytest.approx(3.0)

    def test_log_step_records_micro_step(self):
        """log_step records train/micro_step tag."""
        tb = TBWriter(enabled=False, log_dir="")
        mc = MetricsCollector(level="minimal", tb_writer=tb, log_interval=1)
        model = _make_simple_model()

        result = mc.log_step(
            step=10, main_loss=0.5, total_loss=0.5, aux_loss=None,
            lr=1e-4, metrics={}, model=model,
            tokens_seen=1024, samples_seen=16,
            optimizer_step=3, effective_batch=16,
        )
        assert "train/micro_step" in result
        assert result["train/micro_step"] == pytest.approx(10.0)

    def test_log_step_records_effective_batch(self):
        """log_step records train/effective_batch tag."""
        tb = TBWriter(enabled=False, log_dir="")
        mc = MetricsCollector(level="minimal", tb_writer=tb, log_interval=1)
        model = _make_simple_model()

        result = mc.log_step(
            step=10, main_loss=0.5, total_loss=0.5, aux_loss=None,
            lr=1e-4, metrics={}, model=model,
            tokens_seen=1024, samples_seen=16,
            optimizer_step=3, effective_batch=16,
        )
        assert "train/effective_batch" in result
        assert result["train/effective_batch"] == pytest.approx(16.0)

    def test_tb_writes_new_scalars(self):
        """TensorBoard mock receives add_scalar calls for 3 new tags."""
        tb = TBWriter(enabled=False, log_dir="")
        tb.add_scalar = MagicMock()  # mock the add_scalar method
        mc = MetricsCollector(level="minimal", tb_writer=tb, log_interval=1)
        model = _make_simple_model()

        mc.log_step(
            step=1, main_loss=0.5, total_loss=0.5, aux_loss=None,
            lr=1e-4, metrics={}, model=model,
            tokens_seen=1024, samples_seen=16,
            optimizer_step=1, effective_batch=16,
        )

        called_tags = [call.args[0] for call in tb.add_scalar.call_args_list]
        assert "train/optimizer_step" in called_tags
        assert "train/micro_step" in called_tags
        assert "train/effective_batch" in called_tags
