# tests/test_mixture_lora.py
"""
MixtureLoRALinear / LoRABranch 단위 테스트.

핵심 검증:
- LoRABranch의 lora_B 초기화가 전문가 대칭을 깨는지 (symmetry-breaking)
- Phase 0 (router-only) 훈련에서 expert 출력이 비영(非零)이어야 함
- 비영 expert 출력으로 인해 router gradient가 0이 아니어야 함
- _run_validation 후 model.train() 복원 검증
"""
from __future__ import annotations

from unittest.mock import MagicMock

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset

from eulerforge.modules.mixture_lora import LoRABranch, MixtureLoRALinear
from eulerforge.cli.train import _run_validation


class TestLoRABranchInit:
    """LoRABranch 초기화 시 expert symmetry-breaking 검증."""

    def test_lora_b_nonzero_init(self):
        """lora_B가 0이 아닌 작은 값으로 초기화되어야 한다.

        0-init이면 MoE router Phase 0에서 expert delta가 모두 0이 되어
        router 학습이 불가능하다.
        """
        branch = LoRABranch(
            in_features=64, out_features=64, r=8, alpha=16, dropout=0.0,
            device=torch.device("cpu"), dtype=torch.float32,
        )
        assert not torch.all(branch.loraB == 0), (
            "lora_B should NOT be all-zero; zero-init breaks MoE expert symmetry"
        )

    def test_lora_b_small_magnitude(self):
        """lora_B 초기값의 크기가 작아야 한다 (base 모델 출력을 크게 교란하지 않음)."""
        branch = LoRABranch(
            in_features=64, out_features=64, r=8, alpha=16, dropout=0.0,
            device=torch.device("cpu"), dtype=torch.float32,
        )
        std = branch.loraB.data.std().item()
        assert std < 0.1, f"lora_B std={std:.4f} too large; should be small for stable init"
        assert std > 1e-6, f"lora_B std={std:.6f} too small; effectively zero"

    def test_expert_output_nonzero(self):
        """LoRABranch forward 출력이 0이 아니어야 한다."""
        branch = LoRABranch(
            in_features=64, out_features=64, r=8, alpha=16, dropout=0.0,
            device=torch.device("cpu"), dtype=torch.float32,
        )
        x = torch.randn(4, 64)
        out = branch(x)
        assert not torch.allclose(out, torch.zeros_like(out)), (
            "LoRABranch output should be non-zero for router to receive gradients"
        )

    def test_different_experts_different_outputs(self):
        """서로 다른 LoRABranch 인스턴스가 다른 출력을 내야 한다 (대칭 깨짐 확인)."""
        branches = [
            LoRABranch(
                in_features=64, out_features=64, r=8, alpha=16, dropout=0.0,
                device=torch.device("cpu"), dtype=torch.float32,
            )
            for _ in range(4)
        ]
        x = torch.randn(4, 64)
        outputs = [b(x) for b in branches]
        # 4개 expert 출력이 모두 같으면 대칭이 깨지지 않은 것
        all_same = all(torch.allclose(outputs[0], o) for o in outputs[1:])
        assert not all_same, "Different expert branches should produce different outputs"


class TestMixtureLoRARouterGradient:
    """Phase 0에서 router가 의미 있는 gradient를 받는지 검증."""

    def test_router_gets_nonzero_gradient(self):
        """Expert delta가 비영이면 router에 gradient가 전파되어야 한다."""
        base = nn.Linear(64, 64)
        ml = MixtureLoRALinear(
            base_layer=base,
            num_experts=4,
            top_k=2,
            r=8,
            alpha=16,
            dropout=0.0,
            router_temperature=1.0,
        )
        # Phase 0 시뮬레이션: router만 trainable
        for p in ml.parameters():
            p.requires_grad = False
        for p in ml.router.parameters():
            p.requires_grad = True

        x = torch.randn(4, 8, 64)
        out = ml(x)
        loss = out.sum()
        loss.backward()

        router_grad = ml.router.weight.grad
        assert router_grad is not None, "Router should have gradient"
        assert not torch.all(router_grad == 0), (
            "Router gradient should be non-zero when experts produce non-zero outputs"
        )


class TestRunValidationRestoresTrainMode:
    """_run_validation 호출 후 model.train() 복원 검증."""

    def _make_tiny_model_and_loader(self):
        """검증용 작은 모델과 DataLoader 생성."""
        from transformers import AutoConfig, AutoModelForCausalLM

        config = AutoConfig.from_pretrained("Qwen/Qwen3.5-0.8B-Base", num_hidden_layers=1)
        # Qwen3.5 (transformers 5.5+)는 모든 text 관련 attr이 text_config에 nested됨.
        # AutoModelForCausalLM.from_config가 직접 config.X로 접근하므로,
        # text_config의 모든 속성을 top-level config에도 복사 (shim).
        if hasattr(config, "text_config"):
            text_cfg = config.text_config
            if hasattr(text_cfg, "num_hidden_layers"):
                text_cfg.num_hidden_layers = 1
            # text_config의 모든 public attr을 top-level에 복사 (이미 있으면 skip)
            for attr in dir(text_cfg):
                if attr.startswith("_") or callable(getattr(text_cfg, attr, None)):
                    continue
                if not hasattr(config, attr):
                    try:
                        setattr(config, attr, getattr(text_cfg, attr))
                    except (AttributeError, TypeError):
                        pass
        model = AutoModelForCausalLM.from_config(config)
        model.to(torch.float32)

        # 작은 fake 데이터
        input_ids = torch.randint(0, 100, (4, 16))
        attention_mask = torch.ones_like(input_ids)
        labels = input_ids.clone()
        ds = TensorDataset(input_ids, attention_mask, labels)

        def collate_fn(batch):
            ids, mask, lab = zip(*batch)
            return {
                "input_ids": torch.stack(ids),
                "attention_mask": torch.stack(mask),
                "labels": torch.stack(lab),
            }

        loader = DataLoader(ds, batch_size=2, collate_fn=collate_fn)
        return model, loader

    def test_model_restored_to_train_after_validation(self):
        """_run_validation 호출 후 model.training이 True여야 한다."""
        model, loader = self._make_tiny_model_and_loader()
        model.train()
        assert model.training is True

        _run_validation(model, loader, torch.device("cpu"), use_amp=False)

        assert model.training is True, (
            "model.train() must be restored after _run_validation(); "
            "otherwise subsequent training steps run in eval mode"
        )

    def test_submodules_restored_to_train(self):
        """하위 모듈(Dropout 등)도 train mode로 복원되어야 한다."""
        model, loader = self._make_tiny_model_and_loader()
        model.train()

        _run_validation(model, loader, torch.device("cpu"), use_amp=False)

        # Dropout 등 하위 모듈이 train mode인지 확인
        for name, m in model.named_modules():
            if isinstance(m, nn.Dropout):
                assert m.training is True, (
                    f"Dropout '{name}' should be in train mode after validation"
                )
                break  # 하나만 확인하면 충분
