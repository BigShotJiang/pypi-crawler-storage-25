# tests/test_train_data_integration.py
# -*- coding: utf-8 -*-
"""Tests for the data section in train config — _resolve_data_path."""
from __future__ import annotations

import json
import os
import tempfile

import pytest

from eulerforge.cli.train import _resolve_data_path, _build_cache_filename


FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


def _write_jsonl(path, rows):
    with open(path, "w") as f:
        for row in rows:
            f.write(json.dumps(row) + "\n")
    return path


# =========================================================================
# _resolve_data_path tests
# =========================================================================
class TestResolveDataPath:
    """Test _resolve_data_path: data section vs legacy processed_data_path."""

    def test_legacy_processed_data_path(self, tmp_path):
        """No data section -> uses processed_data_path."""
        p = str(tmp_path / "test.jsonl")
        _write_jsonl(p, [{"input_ids": [1, 2], "labels": [1, 2]}])
        cfg = {"processed_data_path": p}
        result = _resolve_data_path(cfg, None, "sft", str(tmp_path))
        assert result == p

    def test_legacy_training_nested(self, tmp_path):
        """processed_data_path under training section."""
        p = str(tmp_path / "test.jsonl")
        _write_jsonl(p, [{"input_ids": [1, 2], "labels": [1, 2]}])
        cfg = {"training": {"processed_data_path": p}}
        result = _resolve_data_path(cfg, None, "sft", str(tmp_path))
        assert result == p

    def test_data_format_processed(self, tmp_path):
        """data.format=processed -> returns data.path directly."""
        p = str(tmp_path / "test.jsonl")
        _write_jsonl(p, [{"input_ids": [1, 2], "labels": [1, 2]}])
        cfg = {"data": {"format": "processed", "path": p}}
        result = _resolve_data_path(cfg, None, "sft", str(tmp_path))
        assert result == p

    def test_data_format_raw_preprocesses(self, tmp_path):
        """data.format=raw -> preprocesses to cache and returns cache path."""
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained("gpt2")
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token

        raw_p = str(tmp_path / "raw.jsonl")
        _write_jsonl(raw_p, [
            {"text": "Hello world."},
            {"text": "Test data."},
        ])
        cache_dir = str(tmp_path / "cache")

        cfg = {
            "model_name": "gpt2",
            "data": {
                "format": "raw",
                "task": "sft",
                "path": raw_p,
                "cache_dir": cache_dir,
            },
        }
        result = _resolve_data_path(cfg, tok, "sft", str(tmp_path))
        assert result != raw_p
        assert os.path.exists(result)
        # Verify output has input_ids
        with open(result) as f:
            row = json.loads(f.readline())
        assert "input_ids" in row

    def test_data_section_overrides_legacy(self, tmp_path):
        """data section takes priority over processed_data_path."""
        p = str(tmp_path / "data.jsonl")
        _write_jsonl(p, [{"input_ids": [1, 2], "labels": [1, 2]}])
        cfg = {
            "processed_data_path": "/nonexistent.jsonl",
            "data": {"format": "processed", "path": p},
        }
        result = _resolve_data_path(cfg, None, "sft", str(tmp_path))
        assert result == p

    def test_raw_reuses_cache(self, tmp_path):
        """Second call with same params should reuse cached file."""
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained("gpt2")
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token

        raw_p = str(tmp_path / "raw.jsonl")
        _write_jsonl(raw_p, [{"text": "Hello."}])
        cache_dir = str(tmp_path / "cache")

        cfg = {
            "model_name": "gpt2",
            "data": {
                "format": "raw", "task": "sft",
                "path": raw_p, "cache_dir": cache_dir,
            },
        }
        result1 = _resolve_data_path(cfg, tok, "sft", str(tmp_path))
        mtime1 = os.path.getmtime(result1)
        result2 = _resolve_data_path(cfg, tok, "sft", str(tmp_path))
        assert result1 == result2
        assert os.path.getmtime(result2) == mtime1  # file not rewritten

    def test_no_data_no_legacy_raises(self, tmp_path):
        """No data section and no processed_data_path -> ValueError."""
        cfg = {}
        with pytest.raises(ValueError, match="(?i)processed_data_path"):
            _resolve_data_path(cfg, None, "sft", str(tmp_path))

    def test_default_cache_dir_is_outputs_cache(self, tmp_path, monkeypatch):
        """No data.cache_dir -> cache goes to outputs/.cache (shared across runs)."""
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained("gpt2")
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token

        raw_p = str(tmp_path / "raw.jsonl")
        _write_jsonl(raw_p, [{"text": "Hello."}])

        # Change cwd so outputs/.cache lands inside tmp_path
        monkeypatch.chdir(tmp_path)

        cfg = {"model_name": "gpt2", "data": {"format": "raw", "task": "sft", "path": raw_p}}

        result = _resolve_data_path(cfg, tok, "sft", str(tmp_path / "run_20260101_000000"))
        assert os.path.exists(result)
        # Must be under outputs/.cache, not run-specific dir
        assert os.path.join("outputs", ".cache") in result.replace("\\", "/") or \
               "outputs" + os.sep + ".cache" in result

    def test_cache_shared_across_different_run_dirs(self, tmp_path, monkeypatch):
        """Two calls with different output_dirs but same params share the same cache file."""
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained("gpt2")
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token

        raw_p = str(tmp_path / "raw.jsonl")
        _write_jsonl(raw_p, [{"text": "Hello."}])
        monkeypatch.chdir(tmp_path)

        cfg = {"model_name": "gpt2", "data": {"format": "raw", "task": "sft", "path": raw_p}}

        result1 = _resolve_data_path(cfg, tok, "sft", str(tmp_path / "run_20260101_000000"))
        mtime1 = os.path.getmtime(result1)

        result2 = _resolve_data_path(cfg, tok, "sft", str(tmp_path / "run_20260102_000000"))
        # Different run dirs, same cache file
        assert result1 == result2
        assert os.path.getmtime(result2) == mtime1  # not reprocessed


# =========================================================================
# _build_cache_filename tests — 사람이 읽을 수 있는 캐시 파일명 생성
# =========================================================================
class TestBuildCacheFilename:
    """Test _build_cache_filename: human-readable cache file naming."""

    def test_basic_sft(self):
        """dpo_10k_raw.jsonl + sft + Qwen/Qwen3.5-0.8B-Base + 512."""
        name = _build_cache_filename(
            raw_path="/data/dpo_10k_raw.jsonl",
            task="sft",
            model_name="Qwen/Qwen3.5-0.8B-Base",
            max_length=512,
        )
        assert name == "dpo_10k_raw_sft_qwen3.5-0.8b-base_len512.jsonl"

    def test_preference_task(self):
        """preference task naming."""
        name = _build_cache_filename(
            raw_path="data/shp_10k_raw.jsonl",
            task="preference",
            model_name="meta-llama/Llama-3.2-1B",
            max_length=256,
        )
        assert name == "shp_10k_raw_preference_llama-3.2-1b_len256.jsonl"

    def test_model_with_slash(self):
        """Model org/name → only name part, lowered."""
        name = _build_cache_filename(
            raw_path="sft_1k_raw.jsonl",
            task="sft",
            model_name="google/gemma-3-1b-pt",
            max_length=1024,
        )
        assert name == "sft_1k_raw_sft_gemma-3-1b-pt_len1024.jsonl"

    def test_model_without_slash(self):
        """Model name without org prefix."""
        name = _build_cache_filename(
            raw_path="raw.jsonl",
            task="sft",
            model_name="gpt2",
            max_length=512,
        )
        assert name == "raw_sft_gpt2_len512.jsonl"

    def test_empty_model_name(self):
        """Empty model_name → 'unknown'."""
        name = _build_cache_filename(
            raw_path="data.jsonl",
            task="sft",
            model_name="",
            max_length=512,
        )
        assert name == "data_sft_unknown_len512.jsonl"

    def test_prompted_preference(self):
        """prompted_preference task naming."""
        name = _build_cache_filename(
            raw_path="/abs/path/to/pref_data.jsonl",
            task="prompted_preference",
            model_name="Qwen/Qwen3-0.6B",
            max_length=384,
        )
        assert name == "pref_data_prompted_preference_qwen3-0.6b_len384.jsonl"

    def test_special_chars_in_model_cleaned(self):
        """Model name with unusual chars → sanitized."""
        name = _build_cache_filename(
            raw_path="raw.jsonl",
            task="sft",
            model_name="org/My Model (v2)",
            max_length=512,
        )
        # spaces → hyphens, parens removed, lowered
        assert name == "raw_sft_my-model-v2_len512.jsonl"

    def test_same_inputs_same_output(self):
        """Deterministic: same inputs → same filename."""
        name1 = _build_cache_filename("/a/b/raw.jsonl", "sft", "gpt2", 512)
        name2 = _build_cache_filename("/a/b/raw.jsonl", "sft", "gpt2", 512)
        assert name1 == name2

    def test_different_path_same_stem_same_output(self):
        """Different paths with same basename → same cache (design choice)."""
        name1 = _build_cache_filename("/dir_a/raw.jsonl", "sft", "gpt2", 512)
        name2 = _build_cache_filename("/dir_b/raw.jsonl", "sft", "gpt2", 512)
        assert name1 == name2  # basename-based, not full-path-based


class TestReadableCacheIntegration:
    """E2E: _resolve_data_path produces human-readable cache filenames."""

    def test_cache_filename_readable(self, tmp_path):
        """Cache file has human-readable name, not opaque hash."""
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained("gpt2")
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token

        raw_p = str(tmp_path / "sft_10k_raw.jsonl")
        _write_jsonl(raw_p, [{"text": "Hello world."}])
        cache_dir = str(tmp_path / "cache")

        cfg = {
            "model_name": "gpt2",
            "data": {
                "format": "raw",
                "task": "sft",
                "path": raw_p,
                "cache_dir": cache_dir,
                "max_length": 256,
            },
        }
        result = _resolve_data_path(cfg, tok, "sft", str(tmp_path))

        basename = os.path.basename(result)
        # Must contain the input file stem, task, and model name
        assert "sft_10k_raw" in basename, f"Input stem missing: {basename}"
        assert "_sft_" in basename, f"Task missing: {basename}"
        assert "gpt2" in basename, f"Model missing: {basename}"
        assert "len256" in basename, f"Length missing: {basename}"
        assert basename.endswith(".jsonl"), f"Extension wrong: {basename}"
        # Must NOT be opaque hash like processed_a1b2c3d4e5f6.jsonl
        assert not basename.startswith("processed_"), f"Old hash format: {basename}"

    def test_cache_reuse_with_readable_name(self, tmp_path):
        """Same params → same readable filename → cache hit."""
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained("gpt2")
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token

        raw_p = str(tmp_path / "dpo_1k_raw.jsonl")
        _write_jsonl(raw_p, [{"text": "Test."}])
        cache_dir = str(tmp_path / "cache")

        cfg = {
            "model_name": "gpt2",
            "data": {
                "format": "raw", "task": "sft",
                "path": raw_p, "cache_dir": cache_dir,
            },
        }
        result1 = _resolve_data_path(cfg, tok, "sft", str(tmp_path))
        mtime1 = os.path.getmtime(result1)

        result2 = _resolve_data_path(cfg, tok, "sft", str(tmp_path))
        assert result1 == result2
        assert os.path.getmtime(result2) == mtime1

    def test_checkpoint_path_resolves_base_model_for_cache_key(self, tmp_path):
        """체크포인트 경로가 model_name이면 base 모델 이름으로 캐시 키 생성.

        SFT→DPO 파이프라인에서 model_name이 './outputs/.../sft/final'일 때,
        캐시 파일명에 'final'이 아닌 실제 base 모델(예: qwen3-1.7b-base)이 포함되어야
        다른 base 모델의 캐시와 충돌하지 않음.
        """
        from transformers import AutoTokenizer

        tok = AutoTokenizer.from_pretrained("gpt2")
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token

        # EulerForge 체크포인트 구조 생성
        sft_dir = tmp_path / "sft_run"
        final_dir = sft_dir / "final"
        final_dir.mkdir(parents=True)
        (sft_dir / "resolved_config.json").write_text(json.dumps({
            "model_name": "Qwen/Qwen3-1.7B-Base",
        }))
        (final_dir / "lora_info.json").write_text(json.dumps({
            "lora_r": 48, "lora_alpha": 96.0, "strategy": "dense_lora",
        }))
        (final_dir / "config.json").write_text("{}")

        raw_p = str(tmp_path / "dpo_10k_raw.jsonl")
        _write_jsonl(raw_p, [{"prompt": "Hi", "chosen": "Good answer", "rejected": "Bad answer"}])
        cache_dir = str(tmp_path / "cache")

        cfg = {
            "model_name": str(final_dir),  # 체크포인트 경로
            "data": {
                "format": "raw", "task": "prompted_preference",
                "path": raw_p, "cache_dir": cache_dir, "max_length": 512,
            },
        }
        result = _resolve_data_path(cfg, tok, "dpo", str(tmp_path))
        basename = os.path.basename(result)

        # 캐시 파일명에 base 모델 이름이 포함되어야 함
        assert "qwen3-1.7b-base" in basename, (
            f"Cache key should use base model name, got: {basename}"
        )
        # 'final'이 모델 이름으로 사용되면 안 됨
        assert "_final_" not in basename, (
            f"Cache key should NOT use 'final' as model name, got: {basename}"
        )
