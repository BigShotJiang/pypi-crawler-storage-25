# tests/test_backbone_gemma3.py
"""
Gemma 3 BackboneAdapter 단위 테스트.

Gemma 3 1B와 4B+ 모델에서 BackboneAdapter가 정상 동작하는지 검증한다.
핵심 차이: 1B는 Gemma3ForCausalLM (text-only), 4B+는 Gemma3ForConditionalGeneration
(multimodal wrapper → language_model 안에 text backbone 존재).

TDD RED 단계: 이 테스트는 Gemma3Adapter 구현 전에 작성되었다.
"""
from __future__ import annotations

import pytest
import torch
import torch.nn as nn

from eulerforge.cli.train import _select_backbone_adapter, _needs_token_type_ids


# ---------------------------------------------------------------------------
# 7-1: Backbone adapter 단위 테스트
# ---------------------------------------------------------------------------

class TestGemma3AdapterSelection:
    """_select_backbone_adapter에서 gemma3 키가 Gemma3Adapter를 반환하는지 검증."""

    def test_gemma3_key_returns_gemma3_adapter(self):
        adapter = _select_backbone_adapter("gemma3")
        assert adapter.__class__.__name__ == "Gemma3Adapter"

    def test_gemma3_case_insensitive(self):
        adapter = _select_backbone_adapter("Gemma3")
        assert adapter.__class__.__name__ == "Gemma3Adapter"

    def test_gemma_without_version_does_not_match(self):
        """gemma (버전 없음)는 gemma3로 매핑되지 않는다. 별도 지원 없음."""
        adapter = _select_backbone_adapter("gemma")
        # gemma (no version) should NOT match gemma3 — falls back to base
        assert adapter.__class__.__name__ == "BackboneAdapter"

    def test_gemma2_does_not_match(self):
        """gemma2는 지원하지 않는다."""
        adapter = _select_backbone_adapter("gemma2")
        assert adapter.__class__.__name__ == "BackboneAdapter"


class TestGemma3AdapterStructure1B:
    """Gemma 3 1B (text-only, Gemma3ForCausalLM)에서 구조 탐색 검증."""

    @pytest.fixture(autouse=True)
    def setup_model(self, real_model_factory):
        try:
            self.model, self.hub_id = real_model_factory("gemma3_1b")
        except Exception:
            pytest.skip("Gemma 3 1B model load failed or unavailable")
        self.adapter = _select_backbone_adapter("gemma3")

    def test_adapter_is_gemma3(self):
        assert self.adapter.__class__.__name__ == "Gemma3Adapter"

    def test_find_transformer_layers_returns_blocks(self):
        """1B 모델에서 transformer layers를 0개가 아닌 실제 블록으로 찾는다."""
        layers = self.adapter.find_transformer_layers(self.model)
        assert isinstance(layers, (list, nn.ModuleList))
        assert len(layers) == 26, f"Gemma 3 1B has 26 layers, got {len(layers)}"

    def test_find_ffn_module(self):
        """대표 block에서 FFN(MLP) 모듈을 찾는다."""
        layers = self.adapter.find_transformer_layers(self.model)
        block = layers[0]
        ffn = self.adapter.find_ffn_module(block)
        assert isinstance(ffn, nn.Module)
        # Gemma 3 MLP has gate_proj, up_proj, down_proj
        assert hasattr(ffn, "gate_proj"), "FFN should have gate_proj"
        assert hasattr(ffn, "up_proj"), "FFN should have up_proj"
        assert hasattr(ffn, "down_proj"), "FFN should have down_proj"

    def test_find_ffn_attr_name(self):
        """FFN attr name은 'mlp'여야 한다."""
        layers = self.adapter.find_transformer_layers(self.model)
        block = layers[0]
        ffn_name = self.adapter.find_ffn_attr_name(block)
        assert ffn_name == "mlp"

    def test_find_attention_leaf_modules(self):
        """attention leaf modules를 q_proj, k_proj, v_proj, o_proj 키워드로 찾는다."""
        layers = self.adapter.find_transformer_layers(self.model)
        block = layers[0]
        keywords = ["q_proj", "k_proj", "v_proj", "o_proj"]
        leaves = self.adapter.find_attention_leaf_modules(block, keywords)
        assert len(leaves) == 4, f"Expected 4 attention leaves, got {len(leaves)}: {leaves}"
        for path in leaves:
            assert any(k in path for k in keywords), f"Path {path} does not match keywords"


class TestGemma3AdapterDefaults:
    """Gemma3Adapter의 default keywords가 Gemma 3 구조에 맞는지 검증."""

    def test_default_ffn_keywords(self):
        adapter = _select_backbone_adapter("gemma3")
        kw = adapter.default_ffn_keywords()
        assert "gate_proj" in kw
        assert "up_proj" in kw
        assert "down_proj" in kw

    def test_default_attn_keywords(self):
        adapter = _select_backbone_adapter("gemma3")
        kw = adapter.default_attn_keywords()
        assert "q_proj" in kw
        assert "v_proj" in kw


# ---------------------------------------------------------------------------
# _needs_token_type_ids 단위 테스트
# ---------------------------------------------------------------------------

class TestNeedsTokenTypeIds:
    """Gemma3 4B+ (Gemma3ForConditionalGeneration) 감지 로직 검증."""

    def test_plain_module_returns_false(self):
        """일반 nn.Module은 token_type_ids가 불필요."""
        model = nn.Linear(10, 10)
        assert _needs_token_type_ids(model) is False

    def test_gemma3_1b_returns_false(self, real_model_factory):
        """Gemma 3 1B (Gemma3ForCausalLM)는 token_type_ids가 불필요."""
        try:
            model, _ = real_model_factory("gemma3_1b")
        except Exception:
            pytest.skip("Gemma 3 1B model load failed")
        assert _needs_token_type_ids(model) is False

    def test_mock_conditional_generation_returns_true(self):
        """Gemma3ForConditionalGeneration 이름의 모델은 True를 반환."""
        # language_model + multi_modal_projector 속성 기반 감지
        class FakeInner(nn.Module):
            def __init__(self):
                super().__init__()
                self.language_model = nn.Linear(10, 10)
                self.multi_modal_projector = nn.Linear(10, 10)

        class FakeModel(nn.Module):
            def __init__(self):
                super().__init__()
                self.model = FakeInner()

        assert _needs_token_type_ids(FakeModel()) is True

    def test_class_name_detection(self):
        """class.__name__이 Gemma3ForConditionalGeneration이면 True."""
        class Gemma3ForConditionalGeneration(nn.Module):
            pass

        assert _needs_token_type_ids(Gemma3ForConditionalGeneration()) is True
