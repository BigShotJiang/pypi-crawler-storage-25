def test_imports():
    import eulerforge
    import eulerforge.adapters.backbones.base as base
    assert hasattr(base, "BackboneAdapter")
