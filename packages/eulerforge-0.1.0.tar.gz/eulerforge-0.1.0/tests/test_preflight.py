# tests/test_preflight.py
"""
TDD tests for Runtime Preflight Validator.

The preflight validator runs AFTER model load + injection, checking:
1. Group param counts: if a phase references a group, that group must have > 0 params
2. Aux loss collection: MoE modules actually produce aux_loss
3. target_layers bounds: layer indices don't exceed model depth
4. base_ffn matching: base_ffn_keywords actually match params

These are runtime checks that require an actual (mock) model.
"""
from __future__ import annotations

import pytest
import torch
import torch.nn as nn

from eulerforge.phase_schedules.groups import resolve_param_groups


# ===========================================================================
# Mock Models for Preflight Testing
# ===========================================================================

class SimpleMockModel(nn.Module):
    """Model with only base linear layers (no LoRA, no MoE)."""
    def __init__(self, num_layers=2, hidden=16):
        super().__init__()
        self.model = nn.Module()
        self.model.layers = nn.ModuleList()
        for _ in range(num_layers):
            layer = nn.Module()
            layer.mlp = nn.Module()
            layer.mlp.gate_proj = nn.Linear(hidden, hidden)
            layer.mlp.up_proj = nn.Linear(hidden, hidden)
            layer.mlp.down_proj = nn.Linear(hidden, hidden)
            self.model.layers.append(layer)

    def forward(self, x):
        return x


class LoRAMockModel(nn.Module):
    """Model with LoRA params (lora_a, lora_b) on FFN layers."""
    def __init__(self, num_layers=2, hidden=16, r=4):
        super().__init__()
        self.model = nn.Module()
        self.model.layers = nn.ModuleList()
        for _ in range(num_layers):
            layer = nn.Module()
            layer.mlp = nn.Module()
            for proj_name in ["gate_proj", "up_proj", "down_proj"]:
                proj = nn.Module()
                proj.base_layer = nn.Linear(hidden, hidden)
                proj.lora_a = nn.Parameter(torch.randn(r, hidden))
                proj.lora_b = nn.Parameter(torch.randn(hidden, r))
                setattr(layer.mlp, proj_name, proj)
            self.model.layers.append(layer)

    def forward(self, x):
        return x


class MoEMockModel(nn.Module):
    """Model with router + LoRA experts (simulating MoE injection)."""
    def __init__(self, num_layers=2, hidden=16, r=4, num_experts=2):
        super().__init__()
        self.model = nn.Module()
        self.model.layers = nn.ModuleList()
        for _ in range(num_layers):
            layer = nn.Module()
            mlp = nn.Module()
            mlp.router = nn.Linear(hidden, num_experts, bias=False)
            mlp.experts = nn.ModuleList()
            for _ in range(num_experts):
                expert = nn.Module()
                for proj_name in ["gate_proj", "up_proj", "down_proj"]:
                    proj = nn.Module()
                    proj.base_layer = nn.Linear(hidden, hidden)
                    proj.lora_a = nn.Parameter(torch.randn(r, hidden))
                    proj.lora_b = nn.Parameter(torch.randn(hidden, r))
                    setattr(expert, proj_name, proj)
                mlp.experts.append(expert)
            layer.mlp = mlp
            self.model.layers.append(layer)

    def forward(self, x):
        return x


# ===========================================================================
# Preflight: Group Param Counts
# ===========================================================================

class TestPreflightGroupCounts:
    """Preflight should detect when a phase references a group with 0 params."""

    def test_lora_group_exists_in_lora_model(self):
        model = LoRAMockModel(num_layers=2)
        groups = resolve_param_groups(model)
        assert len(groups["lora"]) > 0

    def test_router_group_exists_in_moe_model(self):
        model = MoEMockModel(num_layers=2)
        groups = resolve_param_groups(model)
        assert len(groups["router"]) > 0

    def test_lora_group_missing_in_plain_model(self):
        """SimpleMockModel has no LoRA params."""
        model = SimpleMockModel(num_layers=2)
        groups = resolve_param_groups(model)
        assert len(groups["lora"]) == 0

    def test_router_group_missing_in_lora_model(self):
        """LoRAMockModel has no router params."""
        model = LoRAMockModel(num_layers=2)
        groups = resolve_param_groups(model)
        assert len(groups["router"]) == 0

    def test_base_ffn_group_exists(self):
        model = MoEMockModel(num_layers=2)
        groups = resolve_param_groups(model)
        assert len(groups["base_ffn"]) > 0


# ===========================================================================
# Preflight: Preflight Validator Function
# ===========================================================================

class TestPreflightValidator:
    """Tests for the run_preflight_check function."""

    def test_moe_model_with_valid_phases(self):
        """MoE model with router+lora phases -> preflight passes."""
        from eulerforge.utils.preflight import run_preflight_check, PreflightError

        model = MoEMockModel(num_layers=2)
        phases_cfg = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora"]},
        ]
        # Should not raise
        report = run_preflight_check(
            model=model,
            phases=phases_cfg,
            injection_strategy="mixture_lora",
        )
        assert report.passed is True
        assert report.group_counts["lora"] > 0
        assert report.group_counts["router"] > 0

    def test_plain_model_with_router_phase_fails(self):
        """No router params but phase requires router -> preflight error."""
        from eulerforge.utils.preflight import run_preflight_check, PreflightError

        model = LoRAMockModel(num_layers=2)
        phases_cfg = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora"]},
        ]
        with pytest.raises(PreflightError, match="router.*0 parameters"):
            run_preflight_check(
                model=model,
                phases=phases_cfg,
                injection_strategy="mixture_lora",
            )

    def test_plain_model_with_lora_phase_fails(self):
        """No LoRA params but phase requires lora -> preflight error."""
        from eulerforge.utils.preflight import run_preflight_check, PreflightError

        model = SimpleMockModel(num_layers=2)
        phases_cfg = [
            {"step": 0, "trainable": ["lora"]},
        ]
        with pytest.raises(PreflightError, match="lora.*0 parameters"):
            run_preflight_check(
                model=model,
                phases=phases_cfg,
                injection_strategy="dense_lora",
            )

    def test_base_ffn_with_valid_keywords(self):
        """base_ffn with matching keywords -> OK."""
        from eulerforge.utils.preflight import run_preflight_check

        model = MoEMockModel(num_layers=2)
        phases_cfg = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora", "router", "base_ffn"]},
        ]
        report = run_preflight_check(
            model=model,
            phases=phases_cfg,
            injection_strategy="moe_expert_lora",
            base_ffn_keywords=["gate_proj", "up_proj", "down_proj"],
        )
        assert report.passed is True
        assert report.group_counts["base_ffn"] > 0

    def test_base_ffn_with_wrong_keywords_fails(self):
        """base_ffn_keywords that match nothing -> error."""
        from eulerforge.utils.preflight import run_preflight_check, PreflightError

        model = MoEMockModel(num_layers=2)
        phases_cfg = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora", "router", "base_ffn"]},
        ]
        with pytest.raises(PreflightError, match="base_ffn.*0 parameters"):
            run_preflight_check(
                model=model,
                phases=phases_cfg,
                injection_strategy="moe_expert_lora",
                base_ffn_keywords=["nonexistent_proj"],
            )

    def test_target_layers_out_of_bounds_fails(self):
        """target_layers exceeding model depth -> error."""
        from eulerforge.utils.preflight import run_preflight_check, PreflightError

        model = MoEMockModel(num_layers=2)  # layers 0, 1
        phases_cfg = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora", "router", "base_ffn"]},
        ]
        with pytest.raises(PreflightError, match="target_layers.*exceeds.*2"):
            run_preflight_check(
                model=model,
                phases=phases_cfg,
                injection_strategy="moe_expert_lora",
                base_ffn_keywords=["gate_proj"],
                target_layers=[0, 5],  # 5 exceeds 2 layers
                num_transformer_layers=2,
            )

    def test_preflight_report_contains_group_summary(self):
        """Report should include group param counts for diagnostics."""
        from eulerforge.utils.preflight import run_preflight_check

        model = MoEMockModel(num_layers=2)
        phases_cfg = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora"]},
        ]
        report = run_preflight_check(
            model=model,
            phases=phases_cfg,
            injection_strategy="mixture_lora",
        )
        assert "lora" in report.group_counts
        assert "router" in report.group_counts
        assert "base_ffn" in report.group_counts
        assert isinstance(report.group_counts["lora"], int)


# =========================================================================
# CLI --preflight 통합 테스트 (tr_cfg 바인딩 검증)
# =========================================================================
class TestPreflightCLI:
    """CLI --preflight 플래그가 UnboundLocalError 없이 실행되는지 검증."""

    def test_preflight_tr_cfg_resolved(self, tmp_path):
        """--preflight에서 tr_cfg가 올바르게 해석되어야 한다 (regression: UnboundLocalError)."""
        import yaml
        from eulerforge.cli.train import main as train_main

        # 최소 프리셋 생성
        preset = {
            "device": "cpu",
            "backbone": "qwen3",
            "model_name": "Qwen/Qwen3.5-0.8B-Base",
            "injection": {
                "strategy": "dense_lora",
                "lora_r": 8,
                "lora_alpha": 16,
                "target_keywords": ["gate_proj"],
                "start_layer": 0,
                "num_layers": 1,
            },
            "training": {
                "type": "sft",
                "phases": [{"step": 0, "trainable": ["lora"]}],
                "max_train_steps": 10,
                "batch_size": 1,
            },
        }
        preset_path = tmp_path / "preset.yml"
        with open(preset_path, "w") as f:
            yaml.dump(preset, f)

        # --preflight는 모델 다운로드가 필요하므로, argparse 단계까지만 검증
        # 실제 모델 로드 없이 tr_cfg 바인딩 문제가 발생하는지 확인
        # 여기서는 validate-only로 설정이 해석되는지만 확인
        try:
            train_main(argv=["--preset", str(preset_path), "--validate-only"])
        except SystemExit as e:
            # validate-only는 정상 종료 (exit 0)
            assert e.code == 0 or e.code is None


class TestPreflightExpectedValues:
    """preflight 결과가 전략별로 올바른 그룹 카운트를 반환하는지 검증."""

    def test_dense_lora_group_counts(self):
        """dense_lora: router=0, lora>0, base_ffn>0."""
        from eulerforge.utils.preflight import run_preflight_check

        model = LoRAMockModel(num_layers=2)
        phases = [{"step": 0, "trainable": ["lora"]}]
        report = run_preflight_check(
            model=model,
            phases=phases,
            injection_strategy="dense_lora",
        )
        assert report.passed is True
        assert report.group_counts["router"] == 0  # dense_lora에는 router 없음
        assert report.group_counts["lora"] > 0
        assert "base_ffn" in report.group_counts

    def test_dense_lora_no_aux_expected(self):
        """dense_lora에서는 router=0이 정상 (MoE가 아니므로)."""
        from eulerforge.utils.preflight import run_preflight_check

        model = LoRAMockModel(num_layers=2)
        phases = [{"step": 0, "trainable": ["lora"]}]
        report = run_preflight_check(
            model=model,
            phases=phases,
            injection_strategy="dense_lora",
        )
        assert report.passed is True
        assert report.group_counts.get("router", 0) == 0

    def test_moe_expert_lora_group_counts(self):
        """moe_expert_lora: router>0, lora>0, base_ffn>0."""
        from eulerforge.utils.preflight import run_preflight_check

        model = MoEMockModel(num_layers=2)
        phases = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora"]},
        ]
        report = run_preflight_check(
            model=model,
            phases=phases,
            injection_strategy="moe_expert_lora",
        )
        assert report.passed is True
        assert report.group_counts["router"] > 0
        assert report.group_counts["lora"] > 0

    def test_preflight_output_consistency(self):
        """print → logger.info 출력 일관성: 모든 preflight 메시지가 logger 사용."""
        import inspect
        from eulerforge.cli import train as train_module
        source = inspect.getsource(train_module.main)
        # preflight 블록 내 print() 호출이 없어야 함 (모두 logger로 전환됨)
        preflight_block = source[source.find("# E-2) Preflight"):source.find("# F) 데이터셋")]
        assert "print(" not in preflight_block, (
            "Preflight block should use logger.info, not print()"
        )
