# tests/test_moe_perf.py
# -*- coding: utf-8 -*-
"""
Tests for MoEFFN performance profiling and batched dispatch optimization.

Verifies:
- MoEPerf profiling data structure when enabled
- Profiling is off by default (no overhead)
- Batched dispatch produces correct output shape and values
- Expert token histogram sums correctly
- _try_log_moe_perf produces log output
- _enable_moe_perf toggles all MoEFFN modules
- Perf preset YAMLs are valid
"""
from __future__ import annotations

import logging
import pathlib

import pytest
import torch
import torch.nn as nn
import yaml

from eulerforge.modules.moe import MoEFFN


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _SimpleMLP(nn.Module):
    """Minimal FFN for testing."""
    def __init__(self, d: int = 32):
        super().__init__()
        self.gate_proj = nn.Linear(d, d * 2, bias=False)
        self.up_proj = nn.Linear(d, d * 2, bias=False)
        self.down_proj = nn.Linear(d * 2, d, bias=False)

    def forward(self, x):
        return self.down_proj(self.gate_proj(x) * self.up_proj(x))


def _make_moe(d: int = 32, num_experts: int = 4, top_k: int = 2) -> MoEFFN:
    return MoEFFN(_SimpleMLP(d), hidden_size=d, num_experts=num_experts, top_k=top_k)


_PRESETS_DIR = pathlib.Path(__file__).resolve().parent.parent / "configs" / "presets"
_PERF_PRESETS = list(_PRESETS_DIR.glob("*_perf.yml"))


# ===========================================================================
# A) Perf data structure
# ===========================================================================

class TestMoEPerfData:
    """MoEPerf profiling data when enabled."""

    def test_perf_disabled_by_default(self):
        moe = _make_moe()
        x = torch.randn(2, 8, 32)
        moe(x)
        assert moe.last_perf is None

    def test_perf_enabled_returns_dict(self):
        moe = _make_moe()
        moe.enable_perf(True)
        x = torch.randn(2, 8, 32)
        moe(x)
        perf = moe.last_perf
        assert perf is not None
        assert isinstance(perf, dict)

    def test_perf_keys_present(self):
        moe = _make_moe()
        moe.enable_perf(True)
        moe(torch.randn(2, 8, 32))
        perf = moe.last_perf
        required_keys = {
            "router_ms", "dispatch_ms", "experts_ms", "total_fwd_ms",
            "expert_token_hist", "nonempty_experts", "num_experts",
            "avg_tokens_per_expert", "total_tokens", "expert_times_ms",
        }
        assert required_keys.issubset(perf.keys()), f"Missing: {required_keys - perf.keys()}"

    def test_expert_token_hist_sum(self):
        """expert_token_hist sums to T * top_k."""
        moe = _make_moe(num_experts=4, top_k=2)
        moe.enable_perf(True)
        x = torch.randn(4, 16, 32)  # T = 64
        moe(x)
        hist = moe.last_perf["expert_token_hist"]
        assert sum(hist) == 64 * 2  # T * top_k

    def test_total_tokens_correct(self):
        moe = _make_moe()
        moe.enable_perf(True)
        moe(torch.randn(3, 10, 32))
        assert moe.last_perf["total_tokens"] == 30

    def test_nonempty_experts_range(self):
        moe = _make_moe(num_experts=4)
        moe.enable_perf(True)
        moe(torch.randn(2, 8, 32))
        ne = moe.last_perf["nonempty_experts"]
        assert 1 <= ne <= 4

    def test_expert_times_ms_length(self):
        moe = _make_moe(num_experts=4)
        moe.enable_perf(True)
        moe(torch.randn(2, 8, 32))
        assert len(moe.last_perf["expert_times_ms"]) == 4

    def test_perf_can_be_disabled(self):
        moe = _make_moe()
        moe.enable_perf(True)
        moe(torch.randn(2, 8, 32))
        assert moe.last_perf is not None
        moe.enable_perf(False)
        moe(torch.randn(2, 8, 32))
        assert moe.last_perf is None


# ===========================================================================
# B) Batched dispatch correctness
# ===========================================================================

class TestBatchedDispatchCorrectness:
    """Batched expert dispatch produces correct output."""

    def test_output_shape_3d(self):
        moe = _make_moe()
        x = torch.randn(2, 8, 32)
        y = moe(x)
        assert y.shape == (2, 8, 32)

    def test_output_shape_2d(self):
        moe = _make_moe()
        x = torch.randn(16, 32)
        y = moe(x)
        assert y.shape == (16, 32)

    def test_output_not_all_zeros(self):
        moe = _make_moe()
        x = torch.randn(2, 8, 32)
        y = moe(x)
        assert y.abs().sum() > 0

    def test_gradient_flows(self):
        moe = _make_moe()
        # Only router params are trainable by default (experts are copies)
        for p in moe.parameters():
            p.requires_grad = True
        x = torch.randn(2, 8, 32, requires_grad=True)
        y = moe(x)
        loss = y.sum()
        loss.backward()
        assert x.grad is not None
        assert x.grad.abs().sum() > 0

    def test_deterministic_with_seed(self):
        """Same input + same seed → same output."""
        torch.manual_seed(42)
        moe = _make_moe()
        x = torch.randn(2, 4, 32)
        y1 = moe(x)
        y2 = moe(x)
        # Same input should give same output (deterministic forward)
        assert torch.allclose(y1, y2, atol=1e-6)

    def test_small_batch_single_token(self):
        """Batch of 1 token should work."""
        moe = _make_moe()
        moe.enable_perf(True)
        x = torch.randn(1, 1, 32)
        y = moe(x)
        assert y.shape == (1, 1, 32)
        assert moe.last_perf["total_tokens"] == 1

    def test_top_k_1(self):
        """top_k=1 should work (each token goes to exactly 1 expert)."""
        moe = _make_moe(num_experts=4, top_k=1)
        moe.enable_perf(True)
        x = torch.randn(2, 8, 32)
        y = moe(x)
        assert y.shape == (2, 8, 32)
        assert sum(moe.last_perf["expert_token_hist"]) == 16  # T * 1


# ===========================================================================
# C) Train loop integration
# ===========================================================================

class TestMoePerfTrainIntegration:
    """_enable_moe_perf and _try_log_moe_perf work correctly."""

    def test_enable_moe_perf(self):
        from eulerforge.cli.train import _enable_moe_perf
        # Build a model with MoEFFN modules
        model = nn.Module()
        model.layer1 = _make_moe()
        model.layer2 = _make_moe()
        model.plain = nn.Linear(32, 32)  # not MoE

        count = _enable_moe_perf(model, True)
        assert count == 2
        assert model.layer1._perf_enabled is True
        assert model.layer2._perf_enabled is True

        count = _enable_moe_perf(model, False)
        assert count == 2
        assert model.layer1._perf_enabled is False

    def test_try_log_moe_perf_outputs_log(self, caplog):
        from eulerforge.cli.train import _try_log_moe_perf
        model = nn.Module()
        moe = _make_moe()
        moe.enable_perf(True)
        moe(torch.randn(2, 8, 32))
        model.moe = moe

        with caplog.at_level(logging.INFO):
            _try_log_moe_perf(model, step=10, log_steps=10)

        assert any("[MoEPerf]" in r.message for r in caplog.records)

    def test_try_log_moe_perf_skips_non_log_step(self, caplog):
        from eulerforge.cli.train import _try_log_moe_perf
        model = nn.Module()
        moe = _make_moe()
        moe.enable_perf(True)
        moe(torch.randn(2, 8, 32))
        model.moe = moe

        with caplog.at_level(logging.INFO):
            _try_log_moe_perf(model, step=7, log_steps=10)

        assert not any("[MoEPerf]" in r.message for r in caplog.records)


# ===========================================================================
# D) Perf presets validation
# ===========================================================================

class TestPerfPresets:
    """Perf preset YAMLs are valid and parseable."""

    @pytest.mark.parametrize("preset_path", _PERF_PRESETS, ids=lambda p: p.name)
    def test_preset_is_valid_yaml(self, preset_path):
        with open(preset_path) as f:
            cfg = yaml.safe_load(f)
        assert isinstance(cfg, dict)
        assert cfg["injection"]["strategy"] == "moe_expert_lora"
        assert cfg["training"]["batch_size"] == 2
        assert cfg["training"]["max_train_steps"] == 200

    @pytest.mark.parametrize("preset_path", _PERF_PRESETS, ids=lambda p: p.name)
    def test_preset_has_load_precision(self, preset_path):
        with open(preset_path) as f:
            cfg = yaml.safe_load(f)
        lp = cfg.get("model", {}).get("load_precision", {})
        mode = lp.get("mode", "bf16")
        assert mode in ("fp32", "fp16", "bf16", "int8", "int4")

    def test_three_perf_presets_exist(self):
        names = {p.name for p in _PERF_PRESETS}
        expected = {
            "qwen3.5_0.8b_moe_expert_lora_sft_bf16_perf.yml",
            "qwen3.5_0.8b_moe_expert_lora_sft_int8_perf.yml",
            "qwen3.5_0.8b_moe_expert_lora_sft_int4_perf.yml",
        }
        assert expected.issubset(names), f"Missing: {expected - names}"
