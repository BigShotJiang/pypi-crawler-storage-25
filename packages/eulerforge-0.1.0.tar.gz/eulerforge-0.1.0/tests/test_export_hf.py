# tests/test_export_hf.py
# -*- coding: utf-8 -*-
"""
eulerforge export-hf 유닛 테스트.

Spec: docs/fixtures/specs/export_hf_spec.md (29 tests)
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
from unittest.mock import MagicMock, patch

import pytest
import torch

# ─────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────

@pytest.fixture
def tmp_dir(tmp_path):
    return str(tmp_path)


def _make_run_dir(base, *, strategy="dense_lora", backbone="qwen3",
                  lora_r=8, lora_alpha=16.0, num_experts=4, top_k=2,
                  checkpoint="final", has_lora_keys=True,
                  has_moe_expert_keys=False, has_mixture_lora_keys=False,
                  handoff_done=False):
    """테스트용 run_dir 구조 생성."""
    run_dir = os.path.join(base, "run_test")
    os.makedirs(run_dir, exist_ok=True)

    # resolved_config.json
    resolved = {
        "backbone": backbone,
        "injection": {
            "strategy": strategy,
            "lora_r": lora_r,
            "lora_alpha": lora_alpha,
            "num_experts": num_experts,
            "top_k": top_k,
            "target_keywords": ["gate_proj", "up_proj", "down_proj"],
        },
        "model": {"name": "test/model"},
    }
    with open(os.path.join(run_dir, "resolved_config.json"), "w") as f:
        json.dump(resolved, f)

    # checkpoint sub-dir
    ckpt_dir = os.path.join(run_dir, checkpoint)
    os.makedirs(ckpt_dir, exist_ok=True)

    # config.json (HF model config)
    with open(os.path.join(ckpt_dir, "config.json"), "w") as f:
        json.dump({"model_type": "qwen3", "hidden_size": 64}, f)

    # lora_info.json
    lora_info = {
        "lora_r": lora_r,
        "lora_alpha": lora_alpha,
        "strategy": strategy,
    }
    with open(os.path.join(ckpt_dir, "lora_info.json"), "w") as f:
        json.dump(lora_info, f)

    # state dict
    sd = {}
    if has_lora_keys:
        # plain LoRA keys (attention)
        sd["model.layers.0.self_attn.q_proj.base_layer.weight"] = torch.randn(64, 64)
        sd["model.layers.0.self_attn.q_proj.lora_A"] = torch.randn(lora_r, 64)
        sd["model.layers.0.self_attn.q_proj.lora_B"] = torch.randn(64, lora_r)

    if has_moe_expert_keys:
        # moe_expert_lora keys
        for e in range(num_experts):
            for proj in ("gate_proj", "up_proj", "down_proj"):
                out_dim = 64 if proj == "down_proj" else 128
                in_dim = 64 if proj != "down_proj" else 128
                if handoff_done:
                    sd[f"model.layers.0.mlp.experts.{e}.{proj}.weight"] = torch.randn(out_dim, in_dim) + e * 0.1
                else:
                    sd[f"model.layers.0.mlp.experts.{e}.{proj}.base_layer.weight"] = torch.randn(out_dim, in_dim) + e * 0.1
                    sd[f"model.layers.0.mlp.experts.{e}.{proj}.lora_A"] = torch.randn(lora_r, in_dim)
                    sd[f"model.layers.0.mlp.experts.{e}.{proj}.lora_B"] = torch.randn(out_dim, lora_r)
        sd["model.layers.0.mlp.router.weight"] = torch.randn(num_experts, 64)
        sd["model.layers.0.mlp.router.bias"] = torch.randn(num_experts)

    if has_mixture_lora_keys:
        # mixture_lora keys (MixtureLoRALinear)
        for proj in ("gate_proj", "up_proj", "down_proj"):
            out_dim = 64 if proj == "down_proj" else 128
            in_dim = 64 if proj != "down_proj" else 128
            sd[f"model.layers.0.mlp.{proj}.base_layer.weight"] = torch.randn(out_dim, in_dim)
            sd[f"model.layers.0.mlp.{proj}.router.weight"] = torch.randn(num_experts, in_dim)
            sd[f"model.layers.0.mlp.{proj}.router.bias"] = torch.randn(num_experts)
            for e in range(num_experts):
                sd[f"model.layers.0.mlp.{proj}.experts.{e}.loraA"] = torch.randn(lora_r, in_dim)
                sd[f"model.layers.0.mlp.{proj}.experts.{e}.loraB"] = torch.randn(out_dim, lora_r)

    # normal keys
    sd["model.embed_tokens.weight"] = torch.randn(100, 64)
    sd["lm_head.weight"] = torch.randn(100, 64)

    torch.save(sd, os.path.join(ckpt_dir, "pytorch_model.bin"))

    # tokenizer files
    with open(os.path.join(ckpt_dir, "tokenizer_config.json"), "w") as f:
        json.dump({"model_type": "qwen3"}, f)

    return run_dir, ckpt_dir


def _make_checkpoint_dir(base, **kwargs):
    """테스트용 checkpoint_dir 직접 생성 (run_dir 없이)."""
    run_dir, ckpt_dir = _make_run_dir(base, **kwargs)
    return ckpt_dir


# ─────────────────────────────────────────────────
# TestExportPlanner
# ─────────────────────────────────────────────────

class TestExportPlanner:
    """E10-E14: Export planner 규칙."""

    def test_dense_lora_auto_selects_merged(self, tmp_dir):
        """E10: format=auto + dense_lora → merged."""
        from eulerforge.export.planner import plan_export

        run_dir, _ = _make_run_dir(tmp_dir, strategy="dense_lora", has_lora_keys=True)
        output = os.path.join(tmp_dir, "export_out")
        plan = plan_export(checkpoint=run_dir, output=output)
        assert plan.format == "merged"
        assert plan.strategy == "dense_lora"

    def test_mixture_lora_auto_selects_custom_moe(self, tmp_dir):
        """E11: format=auto + mixture_lora → custom_moe."""
        from eulerforge.export.planner import plan_export

        run_dir, _ = _make_run_dir(
            tmp_dir, strategy="mixture_lora",
            has_lora_keys=True, has_mixture_lora_keys=True,
        )
        output = os.path.join(tmp_dir, "export_out")
        plan = plan_export(checkpoint=run_dir, output=output)
        assert plan.format == "custom_moe"
        assert plan.strategy == "mixture_lora"

    def test_ffn_moe_auto_selects_custom_moe(self, tmp_dir):
        """E12: format=auto + moe_expert_lora → custom_moe."""
        from eulerforge.export.planner import plan_export

        run_dir, _ = _make_run_dir(
            tmp_dir, strategy="moe_expert_lora",
            has_lora_keys=True, has_moe_expert_keys=True,
        )
        output = os.path.join(tmp_dir, "export_out")
        plan = plan_export(checkpoint=run_dir, output=output)
        assert plan.format == "custom_moe"
        assert plan.strategy == "moe_expert_lora"

    def test_merged_format_for_moe_raises(self, tmp_dir):
        """E13: format=merged + MoE 전략 → ValueError."""
        from eulerforge.export.planner import plan_export

        run_dir, _ = _make_run_dir(
            tmp_dir, strategy="mixture_lora",
            has_lora_keys=True, has_mixture_lora_keys=True,
        )
        output = os.path.join(tmp_dir, "export_out")
        with pytest.raises(ValueError, match="구조.*파괴|merged.*MoE"):
            plan_export(checkpoint=run_dir, output=output, format="merged")

    def test_missing_resolved_config_for_moe_raises(self, tmp_dir):
        """E14: custom_moe + resolved_config 없음 → ValueError."""
        from eulerforge.export.planner import plan_export

        # checkpoint_dir만 생성 (resolved_config.json 없음)
        ckpt_dir = os.path.join(tmp_dir, "ckpt_only")
        os.makedirs(ckpt_dir)
        with open(os.path.join(ckpt_dir, "config.json"), "w") as f:
            json.dump({"model_type": "qwen3"}, f)
        # lora_info with MoE strategy but no resolved config available
        with open(os.path.join(ckpt_dir, "lora_info.json"), "w") as f:
            json.dump({"lora_r": 8, "lora_alpha": 16, "strategy": "mixture_lora"}, f)

        output = os.path.join(tmp_dir, "export_out")
        with pytest.raises(ValueError, match="resolved_config"):
            plan_export(checkpoint=ckpt_dir, output=output, format="custom_moe")

    def test_run_dir_resolves_checkpoint(self, tmp_dir):
        """E4: run_dir + select_checkpoint=best → checkpoint-best 해석."""
        from eulerforge.export.planner import plan_export

        run_dir, _ = _make_run_dir(tmp_dir, strategy="dense_lora",
                                    has_lora_keys=True, checkpoint="checkpoint-best")
        output = os.path.join(tmp_dir, "export_out")
        plan = plan_export(checkpoint=run_dir, output=output, select_checkpoint="best")
        assert plan.checkpoint_dir.endswith("checkpoint-best")

    def test_output_exists_raises(self, tmp_dir):
        """E2: output 디렉토리가 이미 존재하면 에러."""
        from eulerforge.export.planner import plan_export

        run_dir, _ = _make_run_dir(tmp_dir, strategy="dense_lora", has_lora_keys=True)
        output = os.path.join(tmp_dir, "existing_output")
        os.makedirs(output)  # 이미 존재

        with pytest.raises(ValueError, match="이미 존재|already exists"):
            plan_export(checkpoint=run_dir, output=output)


# ─────────────────────────────────────────────────
# TestMergedExport
# ─────────────────────────────────────────────────

class TestMergedExport:
    """E15-E17: Merged export 규칙."""

    def test_saves_model_and_tokenizer(self, tmp_dir):
        """E15, E17: 모델+토크나이저 저장."""
        from eulerforge.export.planner import ExportPlan
        from eulerforge.export.merged import export_merged

        run_dir, ckpt_dir = _make_run_dir(tmp_dir, strategy="dense_lora", has_lora_keys=True)
        output = os.path.join(tmp_dir, "merged_out")

        plan = ExportPlan(
            strategy="dense_lora",
            format="merged",
            checkpoint_dir=ckpt_dir,
            output_dir=output,
            resolved_cfg=None,
            lora_cfg={"lora_r": 8, "lora_alpha": 16.0},
            dtype="auto",
            safe_serialization=True,
            copy_tokenizer=True,
            backbone="qwen3",
        )

        mock_model = MagicMock()
        mock_model.config = MagicMock()
        mock_model.config.to_dict.return_value = {"model_type": "qwen3"}
        mock_tokenizer = MagicMock()

        with patch("eulerforge.export.merged.load_model") as mock_load:
            mock_load.return_value = MagicMock(
                model=mock_model, tokenizer=mock_tokenizer
            )
            result = export_merged(plan)

        assert result.format == "merged"
        mock_model.save_pretrained.assert_called_once()
        mock_tokenizer.save_pretrained.assert_called_once()

    def test_injects_export_metadata(self, tmp_dir):
        """E16: config.json에 eulerforge_export 메타데이터."""
        from eulerforge.export.planner import ExportPlan
        from eulerforge.export.merged import export_merged

        run_dir, ckpt_dir = _make_run_dir(tmp_dir, strategy="dense_lora", has_lora_keys=True)
        output = os.path.join(tmp_dir, "merged_meta_out")

        plan = ExportPlan(
            strategy="dense_lora",
            format="merged",
            checkpoint_dir=ckpt_dir,
            output_dir=output,
            resolved_cfg={"model": {"name": "test/model"}},
            lora_cfg={"lora_r": 8, "lora_alpha": 16.0},
            dtype="auto",
            safe_serialization=True,
            copy_tokenizer=True,
            backbone="qwen3",
        )

        mock_model = MagicMock()
        mock_model.config = MagicMock()
        mock_model.config.to_dict.return_value = {"model_type": "qwen3"}
        mock_tokenizer = MagicMock()

        with patch("eulerforge.export.merged.load_model") as mock_load:
            mock_load.return_value = MagicMock(
                model=mock_model, tokenizer=mock_tokenizer
            )
            result = export_merged(plan)

        # config.json에 eulerforge_export가 주입되었는지 확인
        config_path = os.path.join(output, "config.json")
        assert os.path.isfile(config_path)
        with open(config_path) as f:
            cfg = json.load(f)
        assert "eulerforge_export" in cfg
        assert cfg["eulerforge_export"]["training_type"] == "dense_lora"
        assert cfg["eulerforge_export"]["lora_merged"] is True

    def test_dtype_conversion(self, tmp_dir):
        """E7: dtype=bf16 export."""
        from eulerforge.export.planner import ExportPlan
        from eulerforge.export.merged import export_merged

        _, ckpt_dir = _make_run_dir(tmp_dir, strategy="dense_lora", has_lora_keys=True)
        output = os.path.join(tmp_dir, "dtype_out")

        plan = ExportPlan(
            strategy="dense_lora", format="merged", checkpoint_dir=ckpt_dir,
            output_dir=output, resolved_cfg=None,
            lora_cfg={"lora_r": 8, "lora_alpha": 16.0},
            dtype="bf16", safe_serialization=True, copy_tokenizer=True,
            backbone="qwen3",
        )

        mock_model = MagicMock()
        mock_model.config = MagicMock()
        mock_model.config.to_dict.return_value = {"model_type": "qwen3"}
        mock_tokenizer = MagicMock()

        with patch("eulerforge.export.merged.load_model") as mock_load:
            mock_load.return_value = MagicMock(
                model=mock_model, tokenizer=mock_tokenizer
            )
            result = export_merged(plan)

        # load_model이 dtype 인자를 받았는지
        call_kwargs = mock_load.call_args
        # dtype이 "bfloat16"으로 전달되는지 확인
        assert call_kwargs is not None

    def test_safe_serialization_flag(self, tmp_dir):
        """E8: safe_serialization=False."""
        from eulerforge.export.planner import ExportPlan
        from eulerforge.export.merged import export_merged

        _, ckpt_dir = _make_run_dir(tmp_dir, strategy="dense_lora", has_lora_keys=True)
        output = os.path.join(tmp_dir, "safe_out")

        plan = ExportPlan(
            strategy="dense_lora", format="merged", checkpoint_dir=ckpt_dir,
            output_dir=output, resolved_cfg=None,
            lora_cfg={"lora_r": 8, "lora_alpha": 16.0},
            dtype="auto", safe_serialization=False, copy_tokenizer=True,
            backbone="qwen3",
        )

        mock_model = MagicMock()
        mock_model.config = MagicMock()
        mock_model.config.to_dict.return_value = {"model_type": "qwen3"}

        with patch("eulerforge.export.merged.load_model") as mock_load:
            mock_load.return_value = MagicMock(
                model=mock_model, tokenizer=MagicMock()
            )
            export_merged(plan)

        save_call = mock_model.save_pretrained.call_args
        assert save_call is not None
        assert save_call.kwargs.get("safe_serialization") is False or \
               (len(save_call.args) > 1 and save_call.args[1] is False) or \
               save_call[1].get("safe_serialization") is False

    def test_no_copy_tokenizer(self, tmp_dir):
        """E9: copy_tokenizer=False → tokenizer 미저장."""
        from eulerforge.export.planner import ExportPlan
        from eulerforge.export.merged import export_merged

        _, ckpt_dir = _make_run_dir(tmp_dir, strategy="dense_lora", has_lora_keys=True)
        output = os.path.join(tmp_dir, "notok_out")

        plan = ExportPlan(
            strategy="dense_lora", format="merged", checkpoint_dir=ckpt_dir,
            output_dir=output, resolved_cfg=None,
            lora_cfg={"lora_r": 8, "lora_alpha": 16.0},
            dtype="auto", safe_serialization=True, copy_tokenizer=False,
            backbone="qwen3",
        )

        mock_model = MagicMock()
        mock_model.config = MagicMock()
        mock_model.config.to_dict.return_value = {"model_type": "qwen3"}
        mock_tokenizer = MagicMock()

        with patch("eulerforge.export.merged.load_model") as mock_load:
            mock_load.return_value = MagicMock(
                model=mock_model, tokenizer=mock_tokenizer
            )
            export_merged(plan)

        mock_tokenizer.save_pretrained.assert_not_called()


# ─────────────────────────────────────────────────
# TestPerExpertLoraMerge
# ─────────────────────────────────────────────────

class TestPerExpertLoraMerge:
    """E23-E25: Per-expert LoRA merge 규칙."""

    def test_merge_replaces_base_layer_with_weight(self):
        """E23: base_layer.weight + LoRA → weight."""
        from eulerforge.export.custom_moe import _merge_per_expert_lora

        r, alpha = 4, 8.0
        sd = {
            "model.layers.0.mlp.experts.0.gate_proj.base_layer.weight": torch.randn(128, 64),
            "model.layers.0.mlp.experts.0.gate_proj.lora_A": torch.randn(r, 64),
            "model.layers.0.mlp.experts.0.gate_proj.lora_B": torch.randn(128, r),
            "model.layers.0.mlp.router.weight": torch.randn(4, 64),
            "model.embed_tokens.weight": torch.randn(100, 64),
        }

        merged = _merge_per_expert_lora(sd, r, alpha)

        # base_layer.weight → weight
        assert "model.layers.0.mlp.experts.0.gate_proj.weight" in merged
        assert "model.layers.0.mlp.experts.0.gate_proj.base_layer.weight" not in merged
        # LoRA keys removed
        assert "model.layers.0.mlp.experts.0.gate_proj.lora_A" not in merged
        assert "model.layers.0.mlp.experts.0.gate_proj.lora_B" not in merged

    def test_merge_preserves_router_keys(self):
        """E24: router 키 보존."""
        from eulerforge.export.custom_moe import _merge_per_expert_lora

        sd = {
            "model.layers.0.mlp.experts.0.gate_proj.base_layer.weight": torch.randn(128, 64),
            "model.layers.0.mlp.experts.0.gate_proj.lora_A": torch.randn(4, 64),
            "model.layers.0.mlp.experts.0.gate_proj.lora_B": torch.randn(128, 4),
            "model.layers.0.mlp.router.weight": torch.randn(4, 64),
            "model.layers.0.mlp.router.bias": torch.randn(4),
        }

        merged = _merge_per_expert_lora(sd, 4, 8.0)
        assert "model.layers.0.mlp.router.weight" in merged
        assert "model.layers.0.mlp.router.bias" in merged

    def test_no_lora_keys_passthrough(self):
        """E25: LoRA 키 없으면 passthrough (handoff 완료)."""
        from eulerforge.export.custom_moe import _merge_per_expert_lora

        sd = {
            "model.layers.0.mlp.experts.0.gate_proj.weight": torch.randn(128, 64),
            "model.layers.0.mlp.experts.1.gate_proj.weight": torch.randn(128, 64),
            "model.layers.0.mlp.router.weight": torch.randn(4, 64),
        }

        merged = _merge_per_expert_lora(sd, 4, 8.0)
        # 그대로 유지
        assert "model.layers.0.mlp.experts.0.gate_proj.weight" in merged
        assert "model.layers.0.mlp.experts.1.gate_proj.weight" in merged


# ─────────────────────────────────────────────────
# TestCustomMoeExport
# ─────────────────────────────────────────────────

class TestCustomMoeExport:
    """E18-E22: Custom MoE export 규칙."""

    def test_ffn_moe_preserves_expert_count(self, tmp_dir):
        """E20: export 후 expert 수 보존."""
        from eulerforge.export.custom_moe import export_custom_moe
        from eulerforge.export.planner import ExportPlan

        run_dir, ckpt_dir = _make_run_dir(
            tmp_dir, strategy="moe_expert_lora",
            has_lora_keys=True, has_moe_expert_keys=True,
            num_experts=4,
        )
        output = os.path.join(tmp_dir, "moe_out")

        resolved = json.load(open(os.path.join(run_dir, "resolved_config.json")))
        plan = ExportPlan(
            strategy="moe_expert_lora", format="custom_moe",
            checkpoint_dir=ckpt_dir, output_dir=output,
            resolved_cfg=resolved,
            lora_cfg={"lora_r": 8, "lora_alpha": 16.0},
            dtype="auto", safe_serialization=True, copy_tokenizer=True,
            backbone="qwen3",
        )

        result = export_custom_moe(plan)

        # state dict에서 expert 수 확인
        assert os.path.isfile(os.path.join(output, "pytorch_model.bin")) or \
               os.path.isfile(os.path.join(output, "model.safetensors"))

        # Load and check expert keys
        if os.path.isfile(os.path.join(output, "pytorch_model.bin")):
            sd = torch.load(os.path.join(output, "pytorch_model.bin"), map_location="cpu", weights_only=True)
        else:
            from safetensors.torch import load_file
            sd = load_file(os.path.join(output, "model.safetensors"))

        expert_indices = set()
        for k in sd:
            import re
            m = re.search(r"\.experts\.(\d+)\.", k)
            if m:
                expert_indices.add(int(m.group(1)))
        assert len(expert_indices) == 4

    def test_ffn_moe_merges_per_expert_lora(self, tmp_dir):
        """E22: expert 내 LoRA 병합, expert 구조 유지."""
        from eulerforge.export.custom_moe import export_custom_moe
        from eulerforge.export.planner import ExportPlan

        run_dir, ckpt_dir = _make_run_dir(
            tmp_dir, strategy="moe_expert_lora",
            has_lora_keys=True, has_moe_expert_keys=True,
        )
        output = os.path.join(tmp_dir, "moe_lora_out")

        resolved = json.load(open(os.path.join(run_dir, "resolved_config.json")))
        plan = ExportPlan(
            strategy="moe_expert_lora", format="custom_moe",
            checkpoint_dir=ckpt_dir, output_dir=output,
            resolved_cfg=resolved,
            lora_cfg={"lora_r": 8, "lora_alpha": 16.0},
            dtype="auto", safe_serialization=True, copy_tokenizer=True,
            backbone="qwen3",
        )

        export_custom_moe(plan)

        if os.path.isfile(os.path.join(output, "pytorch_model.bin")):
            sd = torch.load(os.path.join(output, "pytorch_model.bin"), map_location="cpu", weights_only=True)
        else:
            from safetensors.torch import load_file
            sd = load_file(os.path.join(output, "model.safetensors"))

        # LoRA keys (lora_A, lora_B, base_layer.weight) should NOT exist
        for k in sd:
            assert "lora_A" not in k, f"lora_A found: {k}"
            assert "lora_B" not in k, f"lora_B found: {k}"
            assert "base_layer" not in k, f"base_layer found: {k}"

        # Expert weight keys SHOULD exist
        assert any("experts.0.gate_proj.weight" in k for k in sd)

    def test_ffn_moe_handoff_no_lora_exports_clean(self, tmp_dir):
        """E22: handoff 완료 체크포인트 — LoRA 없음 → 직접 저장."""
        from eulerforge.export.custom_moe import export_custom_moe
        from eulerforge.export.planner import ExportPlan

        run_dir, ckpt_dir = _make_run_dir(
            tmp_dir, strategy="moe_expert_lora",
            has_lora_keys=False, has_moe_expert_keys=True,
            handoff_done=True,
        )
        output = os.path.join(tmp_dir, "handoff_out")

        resolved = json.load(open(os.path.join(run_dir, "resolved_config.json")))
        plan = ExportPlan(
            strategy="moe_expert_lora", format="custom_moe",
            checkpoint_dir=ckpt_dir, output_dir=output,
            resolved_cfg=resolved,
            lora_cfg={"lora_r": 8, "lora_alpha": 16.0},
            dtype="auto", safe_serialization=True, copy_tokenizer=True,
            backbone="qwen3",
        )

        result = export_custom_moe(plan)
        assert result.format == "custom_moe"

    def test_mixture_lora_preserves_mixture_lora_keys(self, tmp_dir):
        """E21: mixture_lora — router + experts 키 보존."""
        from eulerforge.export.custom_moe import export_custom_moe
        from eulerforge.export.planner import ExportPlan

        run_dir, ckpt_dir = _make_run_dir(
            tmp_dir, strategy="mixture_lora",
            has_lora_keys=True, has_mixture_lora_keys=True,
        )
        output = os.path.join(tmp_dir, "mixture_out")

        resolved = json.load(open(os.path.join(run_dir, "resolved_config.json")))
        plan = ExportPlan(
            strategy="mixture_lora", format="custom_moe",
            checkpoint_dir=ckpt_dir, output_dir=output,
            resolved_cfg=resolved,
            lora_cfg={"lora_r": 8, "lora_alpha": 16.0},
            dtype="auto", safe_serialization=True, copy_tokenizer=True,
            backbone="qwen3",
        )

        export_custom_moe(plan)

        if os.path.isfile(os.path.join(output, "pytorch_model.bin")):
            sd = torch.load(os.path.join(output, "pytorch_model.bin"), map_location="cpu", weights_only=True)
        else:
            from safetensors.torch import load_file
            sd = load_file(os.path.join(output, "model.safetensors"))

        # MixtureLoRA router/expert keys should be preserved
        assert any(".router.weight" in k for k in sd)
        assert any(".experts." in k for k in sd)
        # base_layer.weight should be preserved for MixtureLoRA
        assert any(".base_layer.weight" in k for k in sd)

    def test_mixture_lora_merges_attention_lora_only(self, tmp_dir):
        """E21: attention LoRA만 병합."""
        from eulerforge.export.custom_moe import export_custom_moe
        from eulerforge.export.planner import ExportPlan

        run_dir, ckpt_dir = _make_run_dir(
            tmp_dir, strategy="mixture_lora",
            has_lora_keys=True, has_mixture_lora_keys=True,
        )
        output = os.path.join(tmp_dir, "attn_merge_out")

        resolved = json.load(open(os.path.join(run_dir, "resolved_config.json")))
        plan = ExportPlan(
            strategy="mixture_lora", format="custom_moe",
            checkpoint_dir=ckpt_dir, output_dir=output,
            resolved_cfg=resolved,
            lora_cfg={"lora_r": 8, "lora_alpha": 16.0},
            dtype="auto", safe_serialization=True, copy_tokenizer=True,
            backbone="qwen3",
        )

        export_custom_moe(plan)

        if os.path.isfile(os.path.join(output, "pytorch_model.bin")):
            sd = torch.load(os.path.join(output, "pytorch_model.bin"), map_location="cpu", weights_only=True)
        else:
            from safetensors.torch import load_file
            sd = load_file(os.path.join(output, "model.safetensors"))

        # Attention LoRA keys should be merged (no lora_A/lora_B for attn)
        attn_lora_keys = [k for k in sd if "self_attn" in k and ("lora_A" in k or "lora_B" in k)]
        assert len(attn_lora_keys) == 0, f"Attention LoRA not merged: {attn_lora_keys}"

        # Attention base_layer.weight should be merged to .weight
        attn_base_keys = [k for k in sd if "self_attn" in k and "base_layer" in k]
        assert len(attn_base_keys) == 0, f"Attention base_layer not merged: {attn_base_keys}"

    def test_config_json_has_auto_map(self, tmp_dir):
        """E19: config.json에 auto_map."""
        from eulerforge.export.custom_moe import export_custom_moe
        from eulerforge.export.planner import ExportPlan

        run_dir, ckpt_dir = _make_run_dir(
            tmp_dir, strategy="moe_expert_lora",
            has_lora_keys=True, has_moe_expert_keys=True,
        )
        output = os.path.join(tmp_dir, "automap_out")

        resolved = json.load(open(os.path.join(run_dir, "resolved_config.json")))
        plan = ExportPlan(
            strategy="moe_expert_lora", format="custom_moe",
            checkpoint_dir=ckpt_dir, output_dir=output,
            resolved_cfg=resolved,
            lora_cfg={"lora_r": 8, "lora_alpha": 16.0},
            dtype="auto", safe_serialization=True, copy_tokenizer=True,
            backbone="qwen3",
        )

        export_custom_moe(plan)

        config_path = os.path.join(output, "config.json")
        with open(config_path) as f:
            cfg = json.load(f)
        assert "auto_map" in cfg
        assert "AutoConfig" in cfg["auto_map"]
        assert "AutoModelForCausalLM" in cfg["auto_map"]

    def test_template_files_copied(self, tmp_dir):
        """E18: .py 템플릿 파일 존재."""
        from eulerforge.export.custom_moe import export_custom_moe
        from eulerforge.export.planner import ExportPlan

        run_dir, ckpt_dir = _make_run_dir(
            tmp_dir, strategy="moe_expert_lora",
            has_lora_keys=True, has_moe_expert_keys=True,
        )
        output = os.path.join(tmp_dir, "template_out")

        resolved = json.load(open(os.path.join(run_dir, "resolved_config.json")))
        plan = ExportPlan(
            strategy="moe_expert_lora", format="custom_moe",
            checkpoint_dir=ckpt_dir, output_dir=output,
            resolved_cfg=resolved,
            lora_cfg={"lora_r": 8, "lora_alpha": 16.0},
            dtype="auto", safe_serialization=True, copy_tokenizer=True,
            backbone="qwen3",
        )

        export_custom_moe(plan)

        assert os.path.isfile(os.path.join(output, "configuration_eulerforge_moe.py"))
        assert os.path.isfile(os.path.join(output, "modeling_eulerforge_moe.py"))

    def test_anti_averaging_guard(self, tmp_dir):
        """E20: expert weights 동일하면 에러."""
        from eulerforge.export.custom_moe import export_custom_moe
        from eulerforge.export.planner import ExportPlan

        # 모든 expert가 동일한 weights를 가지는 state dict 생성
        run_dir, ckpt_dir = _make_run_dir(
            tmp_dir, strategy="moe_expert_lora",
            has_lora_keys=False, has_moe_expert_keys=False,
            handoff_done=True,
        )

        # 직접 동일한 expert weights 생성
        sd = {
            "model.embed_tokens.weight": torch.randn(100, 64),
            "lm_head.weight": torch.randn(100, 64),
            "model.layers.0.mlp.router.weight": torch.randn(4, 64),
            "model.layers.0.mlp.router.bias": torch.randn(4),
        }
        identical_w = torch.randn(128, 64)
        for e in range(4):
            for proj in ("gate_proj", "up_proj", "down_proj"):
                out_dim = 64 if proj == "down_proj" else 128
                in_dim = 64 if proj != "down_proj" else 128
                if proj == "gate_proj":
                    sd[f"model.layers.0.mlp.experts.{e}.{proj}.weight"] = identical_w.clone()
                else:
                    sd[f"model.layers.0.mlp.experts.{e}.{proj}.weight"] = torch.randn(out_dim, in_dim) + e * 0.1

        torch.save(sd, os.path.join(ckpt_dir, "pytorch_model.bin"))

        output = os.path.join(tmp_dir, "anti_avg_out")
        resolved = json.load(open(os.path.join(run_dir, "resolved_config.json")))

        plan = ExportPlan(
            strategy="moe_expert_lora", format="custom_moe",
            checkpoint_dir=ckpt_dir, output_dir=output,
            resolved_cfg=resolved,
            lora_cfg={"lora_r": 8, "lora_alpha": 16.0},
            dtype="auto", safe_serialization=True, copy_tokenizer=True,
            backbone="qwen3",
        )

        with pytest.raises(ValueError, match="[Ii]dentical|averaging"):
            export_custom_moe(plan)


# ─────────────────────────────────────────────────
# TestExportHfCLI
# ─────────────────────────────────────────────────

class TestExportHfCLI:
    """E1-E9, E26: CLI 규칙."""

    def test_help_output(self):
        """E3, E7: --help 출력."""
        from eulerforge.cli.export_hf import build_argparser

        parser = build_argparser()
        # 파서가 예상 인자를 가지고 있는지 확인
        actions = {a.dest for a in parser._actions}
        assert "checkpoint" in actions
        assert "output" in actions
        assert "format" in actions
        assert "dtype" in actions

    def test_missing_checkpoint_error(self):
        """E1: --checkpoint 없으면 에러."""
        from eulerforge.cli.export_hf import build_argparser

        parser = build_argparser()
        with pytest.raises(SystemExit):
            parser.parse_args(["--output", "/tmp/out"])

    def test_missing_output_error(self):
        """E2: --output 없으면 에러."""
        from eulerforge.cli.export_hf import build_argparser

        parser = build_argparser()
        with pytest.raises(SystemExit):
            parser.parse_args(["--checkpoint", "/tmp/ckpt"])

    def test_dry_run_mode(self, tmp_dir):
        """E5: --dry-run 모드."""
        from eulerforge.cli.export_hf import main as export_main

        run_dir, _ = _make_run_dir(tmp_dir, strategy="dense_lora", has_lora_keys=True)
        output = os.path.join(tmp_dir, "dry_out")

        # dry-run should NOT create output dir
        export_main(argv=[
            "--checkpoint", run_dir,
            "--output", output,
            "--dry-run",
        ])

        assert not os.path.isdir(output)

    def test_validate_only_mode(self, tmp_dir):
        """E6: --validate-only 모드."""
        from eulerforge.cli.export_hf import main as export_main

        run_dir, _ = _make_run_dir(tmp_dir, strategy="dense_lora", has_lora_keys=True)
        output = os.path.join(tmp_dir, "validate_out")

        # validate-only should NOT create output dir
        export_main(argv=[
            "--checkpoint", run_dir,
            "--output", output,
            "--validate-only",
        ])

        assert not os.path.isdir(output)

    def test_command_registered_in_main(self):
        """E26: export-hf 명령이 main.py에 등록 (core 명령으로)."""
        from eulerforge.cli.main import _CORE_COMMANDS

        cmd_names = [cmd for cmd, _ in _CORE_COMMANDS]
        assert "export-hf" in cmd_names
