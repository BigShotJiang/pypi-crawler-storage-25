# tests/test_step_counter.py
# -*- coding: utf-8 -*-
"""
TDD tests for step counter semantics, tokens_seen/samples_seen redefinition,
and console log format.

All tests are CPU-only and do not invoke run_training_step.
"""
from __future__ import annotations

import torch
import pytest


# ============================================================================
# Helper: compute_batch_tokens (to be extracted or tested inline)
# ============================================================================

def _compute_batch_tokens(batch: dict) -> int:
    """Compute tokens_seen for a single batch using labels != -100 semantics."""
    if "labels" in batch:
        return int((batch["labels"] != -100).sum().item())
    return batch["input_ids"].numel()


def _compute_actual_samples(batch_size: int, training_type: str) -> int:
    """Compute actual sample count considering preference interleaving."""
    if training_type in ("dpo", "orpo", "rm"):
        return batch_size // 2
    return batch_size


# ============================================================================
# 1. TestTokensSeen
# ============================================================================

class TestTokensSeen:
    """tokens_seen should count labels != -100, not input_ids.numel()."""

    def test_tokens_seen_sft_labels_mask(self):
        """SFT: only count tokens where labels != -100 (prompt masked)."""
        # Simulate SFT batch: prompt tokens masked with -100, response tokens have real ids
        # batch_size=2, seq_len=8
        labels = torch.tensor([
            [-100, -100, -100, 101, 102, 103, -100, -100],  # 3 real tokens
            [-100, -100, 201, 202, 203, 204, 205, -100],    # 5 real tokens
        ])
        batch = {"input_ids": torch.randint(0, 1000, (2, 8)), "labels": labels}
        assert _compute_batch_tokens(batch) == 8  # 3 + 5

    def test_tokens_seen_preference_labels_mask(self):
        """DPO interleaved batch: count labels != -100 across chosen+rejected."""
        # Interleaved: [chosen_0, rejected_0, chosen_1, rejected_1]
        # batch_size=4 (2 pairs), seq_len=6
        labels = torch.tensor([
            [-100, -100, 101, 102, 103, -100],   # chosen_0: 3 real
            [-100, -100, -100, 201, 202, -100],   # rejected_0: 2 real
            [-100, 301, 302, 303, 304, -100],     # chosen_1: 4 real
            [-100, -100, 401, 402, -100, -100],   # rejected_1: 2 real
        ])
        batch = {"input_ids": torch.randint(0, 1000, (4, 6)), "labels": labels}
        assert _compute_batch_tokens(batch) == 11  # 3 + 2 + 4 + 2

    def test_tokens_seen_no_labels_fallback(self):
        """Without labels key, fallback to input_ids.numel()."""
        batch = {"input_ids": torch.randint(0, 1000, (2, 8))}
        assert _compute_batch_tokens(batch) == 16  # 2 * 8

    def test_tokens_seen_all_masked(self):
        """All labels == -100 → tokens_seen = 0."""
        labels = torch.full((2, 8), -100)
        batch = {"input_ids": torch.randint(0, 1000, (2, 8)), "labels": labels}
        assert _compute_batch_tokens(batch) == 0


# ============================================================================
# 2. TestSamplesSeen
# ============================================================================

class TestSamplesSeen:
    """samples_seen should account for preference interleaving."""

    def test_samples_seen_sft(self):
        """SFT: actual_samples == batch_size."""
        assert _compute_actual_samples(batch_size=4, training_type="sft") == 4

    def test_samples_seen_dpo(self):
        """DPO: actual_samples == batch_size // 2 (interleaved pairs)."""
        assert _compute_actual_samples(batch_size=4, training_type="dpo") == 2

    def test_samples_seen_orpo(self):
        """ORPO: actual_samples == batch_size // 2."""
        assert _compute_actual_samples(batch_size=4, training_type="orpo") == 2

    def test_samples_seen_rm(self):
        """RM: actual_samples == batch_size // 2."""
        assert _compute_actual_samples(batch_size=6, training_type="rm") == 3


# ============================================================================
# 3. TestOptimizerStepRelation
# ============================================================================

class TestOptimizerStepRelation:
    """Verify optimizer_step increments every grad_accum_steps micro-steps."""

    def test_optimizer_step_with_grad_accum(self):
        """grad_accum_steps=4: 4 micro-steps = 1 optimizer step."""
        grad_accum_steps = 4
        micro_step = 0
        optimizer_step = 0

        for _ in range(12):  # 12 micro-steps
            micro_step += 1
            if micro_step % grad_accum_steps == 0:
                optimizer_step += 1

        assert micro_step == 12
        assert optimizer_step == 3  # 12 / 4

    def test_optimizer_step_accum_1(self):
        """grad_accum_steps=1: every micro-step is an optimizer step."""
        grad_accum_steps = 1
        micro_step = 0
        optimizer_step = 0

        for _ in range(5):
            micro_step += 1
            if micro_step % grad_accum_steps == 0:
                optimizer_step += 1

        assert micro_step == 5
        assert optimizer_step == 5


# ============================================================================
# 4. TestLogFormat
# ============================================================================

class TestLogFormat:
    """Verify console log format contains required fields."""

    def test_start_log_format(self):
        """Training start log contains Steps (optimizer), Micro-steps, Effective batch."""
        training_type = "sft"
        max_steps = 1200
        grad_accum_steps = 4
        batch_size = 8
        effective_batch = batch_size * grad_accum_steps
        total_optimizer_steps = max_steps // grad_accum_steps

        log_msg = (
            f"[Train] Type: {training_type.upper()} | "
            f"Steps (optimizer): {total_optimizer_steps} | "
            f"Micro-steps: {max_steps} | "
            f"Batch: {batch_size} | Accum: {grad_accum_steps} | "
            f"Effective batch: {effective_batch}"
        )

        assert "Steps (optimizer): 300" in log_msg
        assert "Micro-steps: 1200" in log_msg
        assert "Effective batch: 32" in log_msg
        assert "Batch: 8" in log_msg
        assert "Accum: 4" in log_msg

    def test_periodic_log_format(self):
        """Periodic log contains Step {opt}/{total} (micro {m}/{M})."""
        optimizer_step = 10
        total_optimizer_steps = 300
        micro_step = 40
        max_steps = 1200
        phase_tag = "Phase0"

        log_part = (
            f"[{phase_tag}] Step {optimizer_step}/{total_optimizer_steps} "
            f"(micro {micro_step}/{max_steps})"
        )

        assert "Step 10/300" in log_part
        assert "(micro 40/1200)" in log_part


class TestStepCalculationSemantics:
    """max_train_steps가 micro-step 기준임을 검증."""

    def test_total_optimizer_steps_formula(self):
        """total_optimizer_steps = max_steps // grad_accum_steps."""
        max_steps = 1500
        grad_accum_steps = 8
        total_optimizer_steps = max_steps // grad_accum_steps
        assert total_optimizer_steps == 187  # 1500 // 8

    def test_effective_batch(self):
        """effective_batch = batch_size × grad_accum_steps."""
        batch_size = 2
        grad_accum_steps = 8
        effective_batch = batch_size * grad_accum_steps
        assert effective_batch == 16

    def test_micro_step_is_forward_count(self):
        """micro_step는 forward/backward 횟수, optimizer step은 가중치 업데이트 횟수."""
        max_steps = 1500  # micro steps
        grad_accum = 8
        # micro step 50 → optimizer step = 50 / 8 ≈ 6
        micro = 50
        opt_step = micro // grad_accum
        assert opt_step == 6

    def test_optimizer_step_resume_consistency(self):
        """Resume 후 optimizer_step이 micro_step과 일관되어야 함.

        checkpoint에서 micro_step=200 복원 시, optimizer_step도 함께 복원되어야
        로그의 Step N/M (micro K/M) 표시가 정확함.
        """
        micro_step_resumed = 200
        grad_accum = 1
        # 체크포인트에 optimizer_step이 없는 레거시 → 자동 계산
        optimizer_step_fallback = micro_step_resumed // grad_accum
        assert optimizer_step_fallback == 200

        # grad_accum=4일 때
        grad_accum = 4
        optimizer_step_fallback = micro_step_resumed // grad_accum
        assert optimizer_step_fallback == 50

    def test_optimizer_step_equals_micro_when_accum_1(self):
        """grad_accum=1이면 optimizer_step == micro_step (항상)."""
        grad_accum = 1
        for micro in [0, 100, 500, 999]:
            opt = micro // grad_accum
            assert opt == micro, f"micro={micro}: expected opt={micro}, got {opt}"

    def test_scheduler_uses_optimizer_steps_not_micro(self):
        """LR scheduler는 optimizer step 단위로 동작해야 한다.

        micro_steps=2500, grad_accum=4 → optimizer_steps=625.
        scheduler(num_training_steps=625)로 생성되어야 하며,
        625번째 step에서 LR이 거의 0에 도달해야 한다.

        Bug: max_steps(micro)를 그대로 전달하면 scheduler가 2500 step 중
        625번만 실행 → LR이 4.35e-6에서 멈춤 (peak 5e-6 대비 87%).
        """
        from eulerforge.cli.train import _build_scheduler

        lr = 5e-6
        warmup_steps = 50  # optimizer step 단위
        total_optimizer_steps = 625

        opt = torch.optim.AdamW(
            [torch.nn.Parameter(torch.randn(2, 2))], lr=lr
        )
        scheduler = _build_scheduler(
            opt, warmup_steps=warmup_steps, max_steps=total_optimizer_steps
        )

        # warmup 끝에서 peak LR
        for _ in range(warmup_steps):
            scheduler.step()
        assert abs(opt.param_groups[0]["lr"] - lr) < 1e-8, (
            f"After warmup, LR should be {lr}, got {opt.param_groups[0]['lr']}"
        )

        # 나머지 step 실행
        for _ in range(total_optimizer_steps - warmup_steps):
            scheduler.step()

        final_lr = opt.param_groups[0]["lr"]
        # cosine decay 끝에서 LR은 거의 0이어야 함
        assert final_lr < lr * 0.05, (
            f"After {total_optimizer_steps} scheduler steps, LR should be near 0, "
            f"got {final_lr:.2e} (peak={lr:.2e})"
        )

    def test_scheduler_warmup_in_optimizer_steps(self):
        """warmup_steps도 optimizer step 단위여야 한다.

        Config에 warmup_steps=100 (micro) + grad_accum=4이면,
        실제 scheduler warmup = 100 // 4 = 25 optimizer steps.
        """
        from eulerforge.cli.train import _build_scheduler

        lr = 1e-5
        # 25 optimizer steps로 warmup
        warmup_optimizer_steps = 25
        total_optimizer_steps = 100

        opt = torch.optim.AdamW(
            [torch.nn.Parameter(torch.randn(2, 2))], lr=lr
        )
        scheduler = _build_scheduler(
            opt, warmup_steps=warmup_optimizer_steps, max_steps=total_optimizer_steps
        )

        # warmup 중간 (step 12)에서 LR은 peak의 절반 근처
        for _ in range(12):
            scheduler.step()
        mid_lr = opt.param_groups[0]["lr"]
        assert 0.3 * lr < mid_lr < 0.7 * lr, (
            f"At warmup midpoint, LR should be ~50% of peak, got {mid_lr:.2e}"
        )

        # warmup 끝에서 peak
        for _ in range(13):
            scheduler.step()
        peak_lr = opt.param_groups[0]["lr"]
        assert abs(peak_lr - lr) < 1e-8

    def test_scheduler_resume_continues_lr_from_checkpoint(self):
        """Resume 시 scheduler가 checkpoint의 optimizer_step에서 이어서 시작해야 한다.

        Bug: main()에서 scheduler를 current_step=0으로 생성 → resume 후에도
        LR이 warmup부터 다시 시작됨. 수정 후에는 current_step=optimizer_step으로
        fast-forward되어 resume 지점의 LR을 즉시 사용해야 한다.
        """
        from eulerforge.cli.train import _build_scheduler

        lr = 2e-4
        warmup_steps = 25   # optimizer step 단위
        total_steps = 1250  # optimizer step 단위

        # 정상 훈련: step 0 → 500까지 진행
        opt_fresh = torch.optim.AdamW(
            [torch.nn.Parameter(torch.randn(2, 2))], lr=lr
        )
        sched_fresh = _build_scheduler(opt_fresh, warmup_steps=warmup_steps, max_steps=total_steps)
        for _ in range(500):
            sched_fresh.step()
        lr_at_500 = opt_fresh.param_groups[0]["lr"]

        # Resume: current_step=500에서 생성
        opt_resume = torch.optim.AdamW(
            [torch.nn.Parameter(torch.randn(2, 2))], lr=lr
        )
        sched_resume = _build_scheduler(
            opt_resume, warmup_steps=warmup_steps, max_steps=total_steps,
            current_step=500,
        )
        lr_at_resume = opt_resume.param_groups[0]["lr"]

        # Resume 직후 LR이 정상 훈련 500step과 동일해야 함
        assert abs(lr_at_resume - lr_at_500) < 1e-10, (
            f"Resume LR should match fresh training at step 500: "
            f"resume={lr_at_resume:.6e}, fresh={lr_at_500:.6e}"
        )

        # Resume 직후 LR이 warmup 초반이면 안 됨 (warmup 구간의 LR은 peak의 10% 이하)
        assert lr_at_resume > lr * 0.1, (
            f"Resume at step 500 (past warmup=25) should not be in warmup. "
            f"LR={lr_at_resume:.6e}, peak={lr:.6e}"
        )

    def test_eta_uses_remaining_steps_on_resume(self):
        """Resume 시 ETA는 남은 micro step 기준이어야 한다.

        Bug: elapsed/micro_step으로 계산 → resume 후 micro_step이 커서
        time_per_step이 실제보다 작게 계산됨.

        수정: elapsed / (micro_step - resume_start_step) * remaining으로 계산.
        """
        from eulerforge.cli.train import _compute_eta

        # 총 10000 steps, 4000에서 resume, 현재 4500 (500 steps 진행)
        # 300초 경과 → step당 0.6초 → 남은 5500 steps → ETA 3300초
        eta = _compute_eta(
            elapsed=300.0,
            current_step=4500,
            max_steps=10000,
            resume_step=4000,
        )
        # 남은 5500 steps × 0.6초 = 3300초
        assert abs(eta - 3300.0) < 1.0, f"Expected ETA ~3300s, got {eta:.1f}"

    def test_eta_first_step_after_resume_returns_na(self):
        """Resume 직후 (0 steps 진행) ETA는 0 또는 N/A."""
        from eulerforge.cli.train import _compute_eta

        eta = _compute_eta(
            elapsed=0.0,
            current_step=4000,
            max_steps=10000,
            resume_step=4000,
        )
        # 아직 진행된 step 없으므로 0
        assert eta == 0.0

    def test_config_warmup_and_max_steps_converted_to_optimizer_steps(self):
        """Config의 warmup_steps와 max_train_steps는 micro step 단위이므로,
        _build_scheduler에 전달할 때 grad_accum_steps로 나눠야 한다.

        이 테스트는 _convert_to_optimizer_steps 헬퍼가 올바르게 변환하는지 검증.
        """
        from eulerforge.cli.train import _convert_to_optimizer_steps

        # micro steps → optimizer steps
        assert _convert_to_optimizer_steps(2500, grad_accum_steps=4) == 625
        assert _convert_to_optimizer_steps(100, grad_accum_steps=4) == 25
        assert _convert_to_optimizer_steps(1000, grad_accum_steps=1) == 1000
        assert _convert_to_optimizer_steps(7, grad_accum_steps=4) == 1  # ceil(7/4) = 2, min 1

    def test_dpo_phase0_router_only_reward_zero_is_expected(self):
        """DPO Phase 0 (router only, LoRA freeze) → reward=0 정상.

        LoRA가 freeze되면 disable_adapter()와 enable_adapter()가 동일 출력 →
        log_prob_policy - log_prob_ref = 0 → reward=0, accuracy=0,
        loss=ln(2)≈0.6931.
        """
        import math
        expected_loss = math.log(2)  # ≈ 0.6931
        assert abs(expected_loss - 0.6931) < 0.001
