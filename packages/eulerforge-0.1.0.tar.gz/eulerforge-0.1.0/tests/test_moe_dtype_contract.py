# tests/test_moe_dtype_contract.py
# -*- coding: utf-8 -*-
"""
Tests for MoEFFN dtype contract at merge point.

Bug: index_add_() requires self and source to have same dtype.
When router softmax produces float32 weights and merge buffer y is bf16,
the multiplication y_e * weights promotes to float32 → index_add_ crashes.

Root cause scenarios:
1. Quantized model: base_ffn ref_param is int8 → router created as float32
   → softmax(float32 logits) → float32 weights → y_e(bf16) * weights(fp32) → fp32 source
2. CUDA autocast: softmax is promoted to float32 for numerical stability
   → same float32 weights flow
3. Expert dtype drift: quantized/dequantized linear output is float32

Verifies:
- MoEFFN forward succeeds when router is float32 but experts/buffer are bf16
- MoEFFN forward succeeds when expert output drifts to float32
- Output dtype matches input dtype (contract)
- Output shape is preserved
- Opt-in dtype debug logging works
"""
from __future__ import annotations

import logging
import os

import pytest
import torch
import torch.nn as nn

from eulerforge.modules.moe import MoEFFN


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _SimpleMLP(nn.Module):
    """Minimal FFN for dtype testing."""
    def __init__(self, d: int = 32):
        super().__init__()
        self.gate_proj = nn.Linear(d, d * 2, bias=False)
        self.up_proj = nn.Linear(d, d * 2, bias=False)
        self.down_proj = nn.Linear(d * 2, d, bias=False)

    def forward(self, x):
        return self.down_proj(self.gate_proj(x) * self.up_proj(x))


class _Float32DriftMLP(nn.Module):
    """MLP that always returns float32 output regardless of input dtype.

    Simulates the dtype drift that can happen with quantized layers,
    autocast edge cases, or bitsandbytes compute_dtype interactions.
    Uses raw matmul to avoid nn.Linear weight/input dtype mismatch.
    """
    def __init__(self, d: int = 32):
        super().__init__()
        self.w = nn.Parameter(torch.randn(d, d))

    def forward(self, x):
        # Always compute in float32 regardless of input/weight dtype
        return torch.mm(x.view(-1, x.size(-1)).float(), self.w.float()).view(*x.shape)


def _make_moe(d: int = 32, num_experts: int = 2, top_k: int = 2,
              dtype: torch.dtype = torch.bfloat16) -> MoEFFN:
    mlp = _SimpleMLP(d).to(dtype=dtype)
    moe = MoEFFN(mlp, hidden_size=d, num_experts=num_experts, top_k=top_k)
    return moe.to(dtype=dtype)


def _make_moe_float32_router(d: int = 32, num_experts: int = 2,
                              top_k: int = 2) -> MoEFFN:
    """Create MoEFFN with float32 router but bf16 experts.

    This simulates the scenario when:
    - base_ffn has quantized (int8) params → router gets float32 factory_kwargs
    - Or CUDA autocast promotes softmax to float32
    Result: router weights are float32 → softmax output float32 → topk_w float32
    """
    mlp = _SimpleMLP(d).to(dtype=torch.bfloat16)
    moe = MoEFFN(mlp, hidden_size=d, num_experts=num_experts, top_k=top_k)
    # Convert everything to bf16 first, then set router back to float32
    moe = moe.to(dtype=torch.bfloat16)
    moe.router = moe.router.float()
    return moe


def _make_moe_with_drift_experts(d: int = 32, num_experts: int = 2,
                                  top_k: int = 2) -> MoEFFN:
    """Create MoEFFN where experts always output float32 (simulating dtype drift)."""
    base_mlp = _Float32DriftMLP(d)
    moe = MoEFFN(base_mlp, hidden_size=d, num_experts=num_experts, top_k=top_k)
    return moe.to(dtype=torch.bfloat16)


# ===========================================================================
# A) Core dtype contract tests (RED → GREEN)
# ===========================================================================

class TestMoEDTypeContract:
    """MoEFFN merge point dtype contract."""

    def test_bf16_input_forward_succeeds(self):
        """bf16 input with all-bf16 model → forward must succeed."""
        moe = _make_moe(dtype=torch.bfloat16)
        x = torch.randn(2, 8, 32, dtype=torch.bfloat16)
        y = moe(x)
        assert y.shape == (2, 8, 32)

    def test_bf16_output_dtype_matches_input(self):
        """Output dtype must match input dtype (bf16 in → bf16 out)."""
        moe = _make_moe(dtype=torch.bfloat16)
        x = torch.randn(2, 8, 32, dtype=torch.bfloat16)
        y = moe(x)
        assert y.dtype == torch.bfloat16

    def test_fp16_input_forward_succeeds(self):
        """fp16 input → forward must succeed."""
        moe = _make_moe(dtype=torch.float16)
        x = torch.randn(2, 8, 32, dtype=torch.float16)
        y = moe(x)
        assert y.shape == (2, 8, 32)
        assert y.dtype == torch.float16

    def test_fp32_input_forward_succeeds(self):
        """fp32 input → forward should still work (no cast needed)."""
        moe = _make_moe(dtype=torch.float32)
        x = torch.randn(2, 8, 32, dtype=torch.float32)
        y = moe(x)
        assert y.shape == (2, 8, 32)
        assert y.dtype == torch.float32

    def test_float32_router_bf16_experts_forward_succeeds(self):
        """CRITICAL BUG REPRODUCTION: float32 router + bf16 experts/buffer.

        Router is float32 (quantized base or autocast) → softmax float32 →
        topk_w float32 → weights float32 → y_e(bf16) * weights(fp32) = fp32
        → index_add_(bf16 buffer, fp32 source) → RuntimeError.
        """
        moe = _make_moe_float32_router()
        x = torch.randn(2, 8, 32, dtype=torch.bfloat16)
        y = moe(x)  # Should NOT raise RuntimeError
        assert y.shape == (2, 8, 32)
        assert y.dtype == torch.bfloat16

    def test_float32_router_bf16_output_dtype(self):
        """With float32 router, output must still be bf16 (match input)."""
        moe = _make_moe_float32_router(num_experts=4, top_k=2)
        x = torch.randn(4, 16, 32, dtype=torch.bfloat16)
        y = moe(x)
        assert y.dtype == torch.bfloat16

    def test_expert_output_float32_drift_handled(self):
        """When expert output drifts to float32 but merge buffer is bf16,
        forward must still succeed."""
        moe = _make_moe_with_drift_experts()
        x = torch.randn(2, 8, 32, dtype=torch.bfloat16)
        y = moe(x)  # Should NOT raise RuntimeError
        assert y.shape == (2, 8, 32)
        assert y.dtype == torch.bfloat16

    def test_gradient_flows_with_bf16(self):
        """Gradient computation works with bf16 and dtype contract fix."""
        moe = _make_moe(dtype=torch.bfloat16)
        for p in moe.parameters():
            p.requires_grad = True
        x = torch.randn(2, 4, 32, dtype=torch.bfloat16, requires_grad=True)
        y = moe(x)
        loss = y.sum()
        loss.backward()
        assert x.grad is not None
        assert x.grad.dtype == torch.bfloat16

    def test_gradient_flows_with_float32_router(self):
        """Gradient computation works with float32 router + bf16 experts."""
        moe = _make_moe_float32_router()
        for p in moe.parameters():
            p.requires_grad = True
        x = torch.randn(2, 4, 32, dtype=torch.bfloat16, requires_grad=True)
        y = moe(x)
        loss = y.sum()
        loss.backward()
        assert x.grad is not None


# ===========================================================================
# B) Dtype debug instrumentation tests
# ===========================================================================

class TestMoEDTypeDebug:
    """Opt-in dtype debug logging via EULERFORGE_MOE_DTYPE_DEBUG."""

    def test_dtype_debug_off_by_default(self, caplog):
        """No [MoEDType] log when debug env is not set."""
        os.environ.pop("EULERFORGE_MOE_DTYPE_DEBUG", None)
        moe = _make_moe(dtype=torch.bfloat16)
        x = torch.randn(2, 4, 32, dtype=torch.bfloat16)
        with caplog.at_level(logging.DEBUG):
            moe(x)
        assert not any("[MoEDType]" in r.message for r in caplog.records)

    def test_dtype_debug_on_emits_log(self, caplog):
        """[MoEDType] log appears when EULERFORGE_MOE_DTYPE_DEBUG=1."""
        os.environ["EULERFORGE_MOE_DTYPE_DEBUG"] = "1"
        try:
            moe = _make_moe(dtype=torch.bfloat16)
            x = torch.randn(2, 4, 32, dtype=torch.bfloat16)
            with caplog.at_level(logging.DEBUG):
                moe(x)
            dtype_logs = [r for r in caplog.records if "[MoEDType]" in r.message]
            assert len(dtype_logs) > 0, "Expected at least one [MoEDType] log entry"
        finally:
            os.environ.pop("EULERFORGE_MOE_DTYPE_DEBUG", None)

    def test_dtype_debug_log_contains_key_fields(self, caplog):
        """Debug log contains hidden, router, weights, expert_out, buffer dtype info."""
        os.environ["EULERFORGE_MOE_DTYPE_DEBUG"] = "1"
        try:
            moe = _make_moe(dtype=torch.bfloat16)
            x = torch.randn(2, 4, 32, dtype=torch.bfloat16)
            with caplog.at_level(logging.DEBUG):
                moe(x)
            dtype_logs = [r.message for r in caplog.records if "[MoEDType]" in r.message]
            combined = " ".join(dtype_logs)
            for key in ("hidden=", "router_logits=", "topk_weights=", "y_buf="):
                assert key in combined, f"Missing key '{key}' in dtype debug log"
        finally:
            os.environ.pop("EULERFORGE_MOE_DTYPE_DEBUG", None)


# ===========================================================================
# C) Training flow regression tests
# ===========================================================================

class TestMoEDTypeTrainingFlow:
    """Training step regression: forward + backward with mixed dtypes."""

    def test_train_step_float32_router_bf16_experts(self):
        """Simulate a single train step with float32 router + bf16 experts.

        This is the exact scenario that triggered the original bug:
        non-quantized bf16 model under AMP → router softmax in float32.
        """
        moe = _make_moe_float32_router(d=32, num_experts=4, top_k=2)
        moe.train()
        for p in moe.parameters():
            p.requires_grad = True

        optimizer = torch.optim.AdamW(moe.parameters(), lr=1e-4)

        # 3 training steps
        for step in range(3):
            optimizer.zero_grad()
            x = torch.randn(2, 8, 32, dtype=torch.bfloat16)
            y = moe(x)
            loss = y.sum()
            loss.backward()
            optimizer.step()

            # Verify no crash and output contract
            assert y.dtype == torch.bfloat16
            assert y.shape == (2, 8, 32)
            assert torch.isfinite(loss).item()

    def test_train_step_expert_drift_bf16_buffer(self):
        """Train step with expert output float32 drift + bf16 buffer."""
        moe = _make_moe_with_drift_experts(d=32, num_experts=2, top_k=2)
        moe.train()
        for p in moe.parameters():
            p.requires_grad = True

        optimizer = torch.optim.AdamW(moe.parameters(), lr=1e-4)
        optimizer.zero_grad()
        x = torch.randn(2, 8, 32, dtype=torch.bfloat16)
        y = moe(x)
        loss = y.sum()
        loss.backward()
        optimizer.step()

        assert y.dtype == torch.bfloat16
        assert torch.isfinite(loss).item()

    def test_dtype_debug_does_not_crash_training(self, caplog):
        """Enabling dtype debug must not interfere with training."""
        os.environ["EULERFORGE_MOE_DTYPE_DEBUG"] = "1"
        try:
            moe = _make_moe_float32_router()
            moe.train()
            for p in moe.parameters():
                p.requires_grad = True

            optimizer = torch.optim.AdamW(moe.parameters(), lr=1e-4)
            optimizer.zero_grad()

            with caplog.at_level(logging.DEBUG):
                x = torch.randn(2, 4, 32, dtype=torch.bfloat16)
                y = moe(x)
                loss = y.sum()
                loss.backward()
                optimizer.step()

            assert torch.isfinite(loss).item()
            # Debug logs should have been emitted
            dtype_logs = [r for r in caplog.records if "[MoEDType]" in r.message]
            assert len(dtype_logs) > 0
        finally:
            os.environ.pop("EULERFORGE_MOE_DTYPE_DEBUG", None)
