# tests/test_orpo.py
"""ORPO (Odds Ratio Preference Optimization) 단위 테스트."""
import pytest
import torch
from unittest.mock import MagicMock, patch

from eulerforge.cli.train import orpo_loss_fn, run_training_step


class TestOrpoLossFn:
    """orpo_loss_fn 단위 테스트."""

    def test_basic_finite_loss(self):
        """기본 입력에서 유한한 loss 반환"""
        chosen_logps = torch.tensor([-1.0, -2.0])
        rejected_logps = torch.tensor([-3.0, -4.0])
        sft_loss = torch.tensor(2.0)
        loss, metrics = orpo_loss_fn(chosen_logps, rejected_logps, sft_loss, orpo_lambda=1.0)
        assert torch.isfinite(loss), f"Loss is not finite: {loss}"
        assert "orpo_loss" in metrics
        assert "sft_loss" in metrics

    def test_chosen_preferred_lower_loss(self):
        """chosen이 확실히 높을 때 ORPO loss가 낮아야 함"""
        # Strong preference: chosen >> rejected
        chosen_high = torch.tensor([-0.5, -0.5])
        rejected_low = torch.tensor([-5.0, -5.0])
        sft_loss = torch.tensor(1.0)
        loss_strong, _ = orpo_loss_fn(chosen_high, rejected_low, sft_loss, orpo_lambda=1.0)

        # Weak preference: chosen ≈ rejected
        chosen_mid = torch.tensor([-2.0, -2.0])
        rejected_mid = torch.tensor([-2.1, -2.1])
        loss_weak, _ = orpo_loss_fn(chosen_mid, rejected_mid, sft_loss, orpo_lambda=1.0)

        assert loss_strong < loss_weak, \
            f"Strong preference should have lower loss: {loss_strong} vs {loss_weak}"

    def test_lambda_scaling(self):
        """orpo_lambda가 클수록 ORPO 항의 비중이 커짐"""
        chosen = torch.tensor([-1.0, -2.0])
        rejected = torch.tensor([-3.0, -4.0])
        sft_loss = torch.tensor(2.0)

        _, metrics_low = orpo_loss_fn(chosen, rejected, sft_loss, orpo_lambda=0.1)
        _, metrics_high = orpo_loss_fn(chosen, rejected, sft_loss, orpo_lambda=10.0)

        # Total losses should differ due to lambda scaling
        assert metrics_low["orpo_loss"] == pytest.approx(metrics_high["orpo_loss"], abs=1e-5)

    def test_batch_size_one(self):
        """배치 크기 1에서도 동작"""
        chosen = torch.tensor([-1.0])
        rejected = torch.tensor([-2.0])
        sft_loss = torch.tensor(1.5)
        loss, metrics = orpo_loss_fn(chosen, rejected, sft_loss, orpo_lambda=1.0)
        assert torch.isfinite(loss)

    def test_equal_logps(self):
        """chosen == rejected일 때 ORPO loss가 유한"""
        chosen = torch.tensor([-2.0, -2.0])
        rejected = torch.tensor([-2.0, -2.0])
        sft_loss = torch.tensor(1.0)
        loss, metrics = orpo_loss_fn(chosen, rejected, sft_loss, orpo_lambda=1.0)
        assert torch.isfinite(loss)


class TestOrpoTrainingStep:
    """run_training_step(type="orpo") 테스트."""

    @pytest.fixture
    def mock_model(self):
        model = MagicMock()
        # SFT forward: returns loss + logits
        B, L, V = 4, 32, 100  # 4 = 2 pairs (chosen+rejected interleaved)
        logits = torch.randn(B, L, V)
        mock_output = MagicMock()
        mock_output.logits = logits
        mock_output.loss = torch.tensor(2.0, requires_grad=True)
        model.return_value = mock_output
        return model

    def test_orpo_step_returns_loss_and_metrics(self, mock_model):
        """ORPO step이 loss와 metrics 반환"""
        batch = {
            "input_ids": torch.randint(0, 100, (4, 32)),
            "attention_mask": torch.ones(4, 32, dtype=torch.long),
            "labels": torch.randint(0, 100, (4, 32)),
        }
        device = torch.device("cpu")
        loss, metrics = run_training_step(
            batch, mock_model, "orpo", device, use_amp=False,
            orpo_lambda=1.0,
        )
        assert torch.isfinite(loss)
        assert "orpo_loss" in metrics
        assert "sft_loss" in metrics


class TestOrpoChosenOnlySFT:
    """ORPO SFT loss가 chosen 샘플에만 적용되는지 검증."""

    def test_sft_loss_excludes_rejected(self):
        """SFT loss는 chosen(짝수 인덱스)만 사용해야 함.

        rejected를 SFT로 학습하면 나쁜 응답도 생성하도록 학습됨.
        ORPO 원논문: L_SFT는 chosen 응답에 대한 NLL만 사용.
        """
        # 수동으로 chosen-only 로직 검증
        B, L = 4, 16  # 4 samples = 2 pairs (chosen, rejected interleaved)
        targets = torch.randint(0, 50, (B, L))
        targets[1, :] = -100  # rejected pair 1의 labels를 모두 마스킹
        targets[3, :] = -100  # rejected pair 2의 labels를 모두 마스킹

        # chosen mask
        chosen_mask = torch.zeros(B, dtype=torch.bool)
        chosen_mask[0::2] = True  # index 0, 2 = chosen

        # chosen 샘플의 유효 토큰만 계산
        chosen_token_mask = (targets != -100) & chosen_mask.unsqueeze(-1).expand_as(targets)
        # chosen(0,2)만 True, rejected(1,3)은 모두 False
        assert chosen_token_mask[0].any()
        assert not chosen_token_mask[1].any()
        assert chosen_token_mask[2].any()
        assert not chosen_token_mask[3].any()

    def test_orpo_lambda_affects_balance(self):
        """orpo_lambda가 SFT와 ORPO의 균형을 제어."""
        chosen = torch.tensor([-1.0, -1.5])
        rejected = torch.tensor([-3.0, -2.5])
        sft_loss = torch.tensor(2.0)

        _, m_low = orpo_loss_fn(chosen, rejected, sft_loss, orpo_lambda=0.1)
        _, m_high = orpo_loss_fn(chosen, rejected, sft_loss, orpo_lambda=1.0)

        # orpo_lambda가 높을수록 total_loss에서 orpo 비중 증가
        # sft_loss는 동일하므로 total_loss 차이는 orpo 비중 차이
        assert m_high["total_loss"] > m_low["total_loss"]
