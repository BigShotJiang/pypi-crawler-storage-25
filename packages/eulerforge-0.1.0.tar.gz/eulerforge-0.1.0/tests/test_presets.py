import pytest
import os
import glob
import torch
import torch.nn as nn
from transformers import AutoConfig, AutoModelForCausalLM

from eulerforge.utils.config import resolve_config
from eulerforge.utils.validator import validate_config, ConfigValidationError
from eulerforge.cli.train import _select_backbone_adapter, _apply_injection, _count_trainable_params, _needs_token_type_ids
from eulerforge.phase_schedules import build_phase_schedule

# Verification modules
from eulerforge.modules.lora import LoRALinear
from eulerforge.modules.mixture_lora import MixtureLoRALinear
from eulerforge.modules.moe import MoEFFN

# ---------------------------------------------------------------------------
# 1. Preset file discovery
# ---------------------------------------------------------------------------
def get_preset_files():
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    preset_dir = os.path.join(root_dir, "configs", "presets")
    if not os.path.exists(preset_dir):
        return []
    files = glob.glob(os.path.join(preset_dir, "*.yml")) + glob.glob(os.path.join(preset_dir, "*.yaml"))
    return sorted(files)

PRESET_FILES = get_preset_files()


# ---------------------------------------------------------------------------
# 2. Preset validation test (unit - no model loading)
# ---------------------------------------------------------------------------
@pytest.mark.skipif(len(PRESET_FILES) == 0, reason="No presets")
@pytest.mark.parametrize("config_path", PRESET_FILES, ids=lambda p: os.path.basename(p))
def test_preset_validates(config_path):
    """Every preset YAML must load, validate, and compile a phase schedule."""
    resolved = resolve_config(preset_path=config_path)
    cfg = resolved.config

    # Must pass validation
    validate_config(cfg)

    # Must compile phase schedule (if phases are configured)
    sched = build_phase_schedule(cfg)
    training = cfg.get("training", {})
    phases = training.get("phases")

    if phases:
        assert sched is not None, f"Preset {os.path.basename(config_path)} has phases but builder returned None"


# ---------------------------------------------------------------------------
# 3. Full preset integration test (model loading, injection, phases)
# ---------------------------------------------------------------------------
def load_real_model_for_preset(model_name_or_path: str, backbone_type: str) -> AutoModelForCausalLM:
    target_device = "cuda:0" if torch.cuda.is_available() else "cpu"

    if model_name_or_path and "/" in model_name_or_path:
        hub_id = model_name_or_path
    else:
        backbone_lower = (backbone_type or "").lower()
        if "qwen" in backbone_lower:
            hub_id = "Qwen/Qwen2.5-0.5B"
        elif "llama" in backbone_lower:
            hub_id = "meta-llama/Llama-3.2-1B"
        elif "mixtral" in backbone_lower:
            pytest.skip("Skipping Mixtral preset test due to VRAM constraints.")
        else:
            hub_id = "gpt2"

    try:
        model = AutoModelForCausalLM.from_pretrained(
            hub_id,
            trust_remote_code=True,
            torch_dtype=torch.bfloat16,
            device_map=target_device
        )
    except Exception as e:
        pytest.fail(f"Model load failed ({hub_id}): {e}")

    return model


def verify_injection_correctness(model, adapter, injection_cfg):
    """Verify injected model structure matches config."""
    strategy = injection_cfg.get("strategy", "dense_lora")
    target_r = int(injection_cfg.get("lora_r", 16))
    target_experts = int(injection_cfg.get("num_experts", 4))
    target_topk = int(injection_cfg.get("top_k", 2))

    layers = list(adapter.find_transformer_layers(model))
    if not layers:
        return

    start_layer = int(injection_cfg.get("start_layer", 0))
    check_idx = start_layer
    if check_idx >= len(layers):
        check_idx = 0

    block = layers[check_idx]
    ffn_name = adapter.find_ffn_attr_name(block)
    ffn_module = getattr(block, ffn_name)

    if strategy == "moe_expert_lora":
        assert isinstance(ffn_module, MoEFFN), f"FFN should be MoEFFN, but got {type(ffn_module)}"
        assert ffn_module.num_experts == target_experts
        assert ffn_module.top_k == target_topk

        first_expert = ffn_module.experts[0]
        found_lora = False
        for m in first_expert.modules():
            if isinstance(m, LoRALinear):
                found_lora = True
                assert m.r == target_r
                break
        if target_r > 0:
            assert found_lora, "MoEFFN created but no LoRA found inside experts!"

    elif strategy == "mixture_lora":
        found_mixture = False
        for n, m in ffn_module.named_modules():
            if isinstance(m, MixtureLoRALinear):
                found_mixture = True
                assert m.num_experts == target_experts
                assert m.top_k == target_topk
                assert m.experts[0].r == target_r
                break
        assert found_mixture, "Strategy is mixture_lora but no MixtureLoRALinear found in FFN."

    elif strategy == "dense_lora":
        found_lora = False
        for n, m in ffn_module.named_modules():
            if isinstance(m, LoRALinear):
                found_lora = True
                assert m.r == target_r
                for p in m.base_layer.parameters():
                    assert not p.requires_grad, "Base layer inside LoRA should be frozen."
                break
        if injection_cfg.get("target_keywords"):
            assert found_lora, "Strategy is dense_lora but no LoRALinear found in FFN."


@pytest.mark.slow
@pytest.mark.skipif(len(PRESET_FILES) == 0, reason="No presets")
@pytest.mark.parametrize("config_path", PRESET_FILES, ids=lambda p: os.path.basename(p))
def test_preset_full_integration(config_path):
    """Full integration: load model, inject, apply phases, verify gradient flow."""
    resolved = resolve_config(preset_path=config_path)
    cfg = resolved.config

    backbone_name = cfg.get("backbone", "generic")
    model_name = cfg.get("modelname") or cfg.get("model_name")

    adapter = _select_backbone_adapter(backbone_name)
    assert adapter is not None

    # 1. Model Load
    model = load_real_model_for_preset(model_name, backbone_name)

    # 2. Injection
    injection_cfg = cfg.get("injection", {})
    try:
        _apply_injection(model, adapter, injection_cfg, verbose=False)
    except Exception as e:
        pytest.fail(f"Injection failed: {e}")

    # 3. Detailed Verification
    verify_injection_correctness(model, adapter, injection_cfg)

    # 4. Phase Schedule (new unified API)
    schedule = build_phase_schedule(cfg)
    if schedule is not None:
        schedule.maybe_step(model, 0)

    # 5. Trainable Check
    _, t_params = _count_trainable_params(model)

    if t_params == 0:
        pytest.fail("No trainable parameters found. Injection logic might have missed targets.")

    # 6. Gradient Flow
    model.train()
    target_device = model.device
    input_ids = torch.randint(0, 100, (1, 8)).to(target_device)
    labels = input_ids.clone()

    # Gemma 3 4B+ (multimodal wrapper)는 training 시 token_type_ids 필수
    extra_kwargs = {}
    if _needs_token_type_ids(model):
        extra_kwargs["token_type_ids"] = torch.zeros_like(input_ids)

    try:
        outputs = model(input_ids=input_ids, labels=labels, **extra_kwargs)
        loss = outputs.loss
        loss.backward()
    except Exception as e:
        pytest.fail(f"Forward/Backward failed: {e}")

    grads_found = sum(1 for p in model.parameters() if p.grad is not None)
    if grads_found == 0:
        pytest.fail("No gradients generated.")
