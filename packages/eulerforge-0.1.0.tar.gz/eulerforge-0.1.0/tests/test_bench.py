# tests/test_bench.py
# -*- coding: utf-8 -*-
"""
eulerforge bench 유닛 테스트.

- TestBenchSampler: 데이터 샘플링 (5 tests)
- TestChatClient: ChatClient HTTP 호출 (5 tests)
- TestJudgeClient: JudgeClient pointwise/pairwise (6 tests)
- TestBenchConfigValidation: 벤치 설정 검증 (5 tests)
- TestBenchCLI: CLI argparse + 서브커맨드 (4 tests)
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from unittest import mock

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from eulerforge.utils.bench_sampler import (
    extract_prompt,
    load_jsonl,
    sample_bench_data,
)
from eulerforge.utils.bench_client import (
    ChatClient,
    JudgeClient,
    _extract_json,
    _parse_pointwise,
    _parse_pairwise,
)
from eulerforge.cli.bench import (
    build_argparser,
    main,
    validate_bench_config,
)
from eulerforge.utils.validator import ConfigValidationError


# =========================================================================
# Fixtures
# =========================================================================
@pytest.fixture
def sft_jsonl(tmp_path):
    """SFT 형식의 임시 JSONL 파일 생성."""
    path = tmp_path / "sft_bench.jsonl"
    items = [
        {"prompt": f"Question {i}", "response": f"Answer {i}"}
        for i in range(20)
    ]
    with open(path, "w", encoding="utf-8") as f:
        for item in items:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")
    return str(path)


@pytest.fixture
def preference_jsonl(tmp_path):
    """Preference 형식의 임시 JSONL 파일 생성."""
    path = tmp_path / "pref_bench.jsonl"
    items = [
        {"prompt": f"Prompt {i}", "chosen": f"Good {i}", "rejected": f"Bad {i}"}
        for i in range(15)
    ]
    with open(path, "w", encoding="utf-8") as f:
        for item in items:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")
    return str(path)


@pytest.fixture
def valid_bench_cfg(sft_jsonl):
    """유효한 bench config dict."""
    return {
        "bench": {
            "task": "sft",
            "data_path": sft_jsonl,
            "sample": {"k": 5, "seed": 42, "shuffle": True},
            "generation": {"max_new_tokens": 64, "temperature": 0.7},
            "models": {
                "target": {
                    "provider": "ollama",
                    "model": "qwen3:0.6b",
                    "base_url": "http://localhost:11434/v1",
                },
                "baseline": {"enabled": False},
                "judge": {"enabled": False},
            },
            "output": {"out_dir": "outputs/bench", "save_jsonl": True},
        }
    }


def _mock_urlopen_response(content: str, *, native_ollama: bool = False):
    """urllib.request.urlopen mock 응답 생성.

    native_ollama=True: Ollama native /api/chat 형식
    native_ollama=False: OpenAI-compatible 형식
    """
    if native_ollama:
        resp_data = json.dumps({
            "message": {"role": "assistant", "content": content}
        }).encode("utf-8")
    else:
        resp_data = json.dumps({
            "choices": [{"message": {"content": content}}]
        }).encode("utf-8")
    mock_resp = mock.MagicMock()
    mock_resp.read.return_value = resp_data
    mock_resp.__enter__ = mock.MagicMock(return_value=mock_resp)
    mock_resp.__exit__ = mock.MagicMock(return_value=False)
    return mock_resp


# =========================================================================
# TestBenchSampler
# =========================================================================
class TestBenchSampler:
    """데이터 샘플링 유닛 테스트 (5 tests)."""

    def test_sample_k_items(self, sft_jsonl):
        """k=5 → 5개 반환."""
        samples = sample_bench_data(sft_jsonl, k=5, seed=42)
        assert len(samples) == 5

    def test_sample_with_seed_reproducible(self, sft_jsonl):
        """동일 시드 → 동일 결과."""
        s1 = sample_bench_data(sft_jsonl, k=5, seed=123)
        s2 = sample_bench_data(sft_jsonl, k=5, seed=123)
        assert s1 == s2

    def test_sample_different_seed_different_result(self, sft_jsonl):
        """다른 시드 → 다른 결과."""
        s1 = sample_bench_data(sft_jsonl, k=5, seed=42)
        s2 = sample_bench_data(sft_jsonl, k=5, seed=99)
        assert s1 != s2

    def test_sample_k_exceeds_data(self, sft_jsonl):
        """k > len(data) → 전체 반환."""
        samples = sample_bench_data(sft_jsonl, k=100, seed=42)
        assert len(samples) == 20  # sft_jsonl has 20 items

    def test_extract_prompt_sft(self):
        """sft task → prompt 키 추출."""
        item = {"prompt": "Hello world", "response": "Hi there"}
        assert extract_prompt(item, "sft") == "Hello world"

    def test_extract_prompt_fallback_instruction(self):
        """prompt 키 없을 때 instruction 키로 fallback."""
        item = {"instruction": "Do something", "output": "Done"}
        assert extract_prompt(item, "sft") == "Do something"

    def test_extract_prompt_fallback_input(self):
        """prompt, instruction 키 없을 때 input 키로 fallback."""
        item = {"input": "Some input", "output": "Output"}
        assert extract_prompt(item, "sft") == "Some input"

    def test_extract_prompt_empty(self):
        """어떤 키도 없으면 빈 문자열."""
        item = {"response": "Answer only"}
        assert extract_prompt(item, "sft") == ""

    def test_load_jsonl_empty_lines(self, tmp_path):
        """빈 줄이 있어도 정상 로딩."""
        path = tmp_path / "mixed.jsonl"
        with open(path, "w") as f:
            f.write('{"prompt": "a"}\n\n{"prompt": "b"}\n  \n')
        items = load_jsonl(str(path))
        assert len(items) == 2


# =========================================================================
# TestChatClient
# =========================================================================
class TestChatClient:
    """ChatClient HTTP 호출 테스트 (5 tests, mock HTTP)."""

    @mock.patch("eulerforge.utils.bench_client.urllib.request.urlopen")
    def test_chat_ollama_success(self, mock_urlopen):
        """ollama provider → native /api/chat 호출, 정상 응답."""
        mock_urlopen.return_value = _mock_urlopen_response(
            "Hello from Ollama!", native_ollama=True
        )
        client = ChatClient(provider="ollama", model="qwen3:0.6b",
                            base_url="http://localhost:11434/v1")
        result = client.chat([{"role": "user", "content": "Hi"}])
        assert result == "Hello from Ollama!"

    @mock.patch("eulerforge.utils.bench_client.urllib.request.urlopen")
    def test_chat_openai_success(self, mock_urlopen):
        """openai provider → 정상 응답."""
        mock_urlopen.return_value = _mock_urlopen_response("Hello from OpenAI!")
        client = ChatClient(provider="openai", model="gpt-4o",
                            base_url="https://api.openai.com/v1",
                            api_key="sk-test")
        result = client.chat([{"role": "user", "content": "Hi"}])
        assert result == "Hello from OpenAI!"

    def test_chat_invalid_provider(self):
        """잘못된 provider → ValueError."""
        with pytest.raises(ValueError, match="Unknown provider"):
            ChatClient(provider="invalid", model="test")

    @mock.patch("eulerforge.utils.bench_client.urllib.request.urlopen")
    def test_chat_sends_correct_payload(self, mock_urlopen):
        """Ollama: native API 페이로드 — model, messages, stream, think, options."""
        mock_urlopen.return_value = _mock_urlopen_response("ok", native_ollama=True)
        client = ChatClient(provider="ollama", model="test-model",
                            base_url="http://localhost:11434/v1")
        client.chat(
            [{"role": "user", "content": "test"}],
            generation_cfg={"temperature": 0.5, "max_new_tokens": 128},
        )
        call_args = mock_urlopen.call_args
        req = call_args[0][0]
        body = json.loads(req.data.decode("utf-8"))
        assert body["model"] == "test-model"
        assert body["stream"] is False
        assert body["think"] is False  # thinking 비활성화
        assert body["options"]["temperature"] == 0.5
        assert body["options"]["num_predict"] == 128
        assert len(body["messages"]) == 1
        # URL은 native /api/chat
        assert "/api/chat" in req.full_url

    @mock.patch("eulerforge.utils.bench_client.urllib.request.urlopen")
    def test_chat_connection_error(self, mock_urlopen):
        """연결 실패 → ConnectionError."""
        import urllib.error
        mock_urlopen.side_effect = urllib.error.URLError("Connection refused")
        client = ChatClient(provider="ollama", model="test",
                            base_url="http://localhost:99999/v1")
        with pytest.raises(ConnectionError, match="Failed to connect"):
            client.chat([{"role": "user", "content": "test"}])

    @mock.patch("eulerforge.utils.bench_client.urllib.request.urlopen")
    def test_from_config(self, mock_urlopen):
        """from_config 클래스메서드 동작."""
        mock_urlopen.return_value = _mock_urlopen_response("configured!", native_ollama=True)
        model_cfg = {
            "provider": "ollama",
            "model": "qwen3:0.6b",
            "base_url": "http://localhost:11434/v1",
        }
        client = ChatClient.from_config(model_cfg)
        assert client.model == "qwen3:0.6b"
        assert client.provider == "ollama"
        result = client.chat([{"role": "user", "content": "Hi"}])
        assert result == "configured!"


# =========================================================================
# TestJudgeClient
# =========================================================================
class TestJudgeClient:
    """JudgeClient pointwise/pairwise 테스트 (6 tests, mock HTTP)."""

    @mock.patch("eulerforge.utils.bench_client.urllib.request.urlopen")
    def test_pointwise_score_parse(self, mock_urlopen):
        """pointwise: JSON 응답에서 score + explanation 파싱."""
        judge_resp = json.dumps({"score": 8, "explanation": "Clear and helpful."})
        mock_urlopen.return_value = _mock_urlopen_response(judge_resp, native_ollama=True)
        judge = JudgeClient(provider="ollama", model="gemma3:12b",
                            base_url="http://localhost:11434/v1", mode="pointwise")
        result = judge.score_pointwise("What is AI?", "AI is artificial intelligence.")
        assert result["score"] == 8
        assert "Clear" in result["explanation"]

    @mock.patch("eulerforge.utils.bench_client.urllib.request.urlopen")
    def test_pointwise_invalid_response_graceful(self, mock_urlopen):
        """pointwise: 파싱 실패 시 graceful fallback (숫자 추출 or 기본값)."""
        mock_urlopen.return_value = _mock_urlopen_response(
            "I think this is about a 7 out of 10.", native_ollama=True
        )
        judge = JudgeClient(provider="ollama", model="test",
                            base_url="http://localhost:11434/v1", mode="pointwise")
        result = judge.score_pointwise("q", "a")
        assert "score" in result
        assert result.get("parse_error", False) is True
        assert result["score"] == 7  # 숫자 추출

    @mock.patch("eulerforge.utils.bench_client.urllib.request.urlopen")
    def test_pairwise_score_parse(self, mock_urlopen):
        """pairwise: winner + scores + explanation 파싱."""
        judge_resp = json.dumps({
            "winner": "A", "score_a": 9, "score_b": 6,
            "explanation": "Response A is more detailed."
        })
        mock_urlopen.return_value = _mock_urlopen_response(judge_resp, native_ollama=True)
        judge = JudgeClient(provider="ollama", model="test",
                            base_url="http://localhost:11434/v1",
                            mode="pairwise", mitigate_position_bias=False)
        result = judge.score_pairwise("q", "resp_a", "resp_b")
        assert result["winner"] == "A"
        assert result["score_a"] == 9
        assert result["score_b"] == 6

    @mock.patch("eulerforge.utils.bench_client.urllib.request.urlopen")
    def test_pairwise_with_bias_mitigation(self, mock_urlopen):
        """pairwise + bias mitigation → 2회 호출."""
        judge_resp = json.dumps({
            "winner": "A", "score_a": 8, "score_b": 6,
            "explanation": "A is better."
        })
        mock_urlopen.return_value = _mock_urlopen_response(judge_resp, native_ollama=True)
        judge = JudgeClient(provider="ollama", model="test",
                            base_url="http://localhost:11434/v1",
                            mode="pairwise", mitigate_position_bias=True)
        result = judge.score_pairwise("q", "resp_a", "resp_b")
        # bias mitigation → 2회 호출 (urlopen 2번)
        assert mock_urlopen.call_count == 2
        assert "rounds" in result
        assert len(result["rounds"]) == 2

    def test_judge_invalid_mode(self):
        """잘못된 judge mode → ValueError."""
        with pytest.raises(ValueError, match="Invalid judge mode"):
            JudgeClient(provider="ollama", model="test",
                        base_url="http://localhost:11434/v1", mode="invalid")

    def test_judge_prompt_format(self):
        """_parse_pointwise/_parse_pairwise 파싱 함수 직접 검증."""
        # pointwise
        raw_pw = '{"score": 9, "explanation": "Excellent response."}'
        result_pw = _parse_pointwise(raw_pw)
        assert result_pw["score"] == 9
        assert "Excellent" in result_pw["explanation"]

        # pairwise
        raw_pair = '{"winner": "B", "score_a": 5, "score_b": 8, "explanation": "B wins."}'
        result_pair = _parse_pairwise(raw_pair)
        assert result_pair["winner"] == "B"
        assert result_pair["score_b"] == 8

    def test_extract_json_code_block(self):
        """코드블록 안의 JSON 추출."""
        text = 'Here is my evaluation:\n```json\n{"score": 7, "explanation": "good"}\n```'
        result = _extract_json(text)
        assert result is not None
        assert result["score"] == 7

    def test_extract_json_inline(self):
        """인라인 JSON 추출."""
        text = 'I think the score is {"score": 6, "explanation": "decent"} overall.'
        result = _extract_json(text)
        assert result is not None
        assert result["score"] == 6


# =========================================================================
# TestBenchConfigValidation
# =========================================================================
class TestBenchConfigValidation:
    """Bench 설정 검증 테스트 (5 tests)."""

    def test_valid_sft_config(self, valid_bench_cfg):
        """유효 설정 통과."""
        validate_bench_config(valid_bench_cfg)  # Should not raise

    def test_missing_bench_section(self):
        """bench 섹션 누락 → 에러."""
        with pytest.raises(ConfigValidationError, match="Missing required section"):
            validate_bench_config({})

    def test_missing_task(self, valid_bench_cfg):
        """bench.task 누락 → 에러."""
        del valid_bench_cfg["bench"]["task"]
        with pytest.raises(ConfigValidationError, match="Missing bench.task"):
            validate_bench_config(valid_bench_cfg)

    def test_invalid_task(self, valid_bench_cfg):
        """bench.task=unknown → 에러."""
        valid_bench_cfg["bench"]["task"] = "unknown"
        with pytest.raises(ConfigValidationError, match="Unknown bench.task"):
            validate_bench_config(valid_bench_cfg)

    def test_invalid_provider(self, valid_bench_cfg):
        """target provider invalid → 에러."""
        valid_bench_cfg["bench"]["models"]["target"]["provider"] = "invalid"
        with pytest.raises(ConfigValidationError, match="Unknown provider"):
            validate_bench_config(valid_bench_cfg)

    def test_invalid_judge_mode(self, valid_bench_cfg):
        """judge.mode=invalid → 에러."""
        valid_bench_cfg["bench"]["models"]["judge"] = {
            "enabled": True,
            "provider": "ollama",
            "model": "test",
            "mode": "invalid",
        }
        with pytest.raises(ConfigValidationError, match="Unknown judge mode"):
            validate_bench_config(valid_bench_cfg)

    def test_missing_target_model(self, valid_bench_cfg):
        """target.model 누락 + output_dir/model_dir 없음 → 에러."""
        del valid_bench_cfg["bench"]["models"]["target"]["model"]
        with pytest.raises(ConfigValidationError, match="exactly one of"):
            validate_bench_config(valid_bench_cfg)

    def test_missing_data_path(self, valid_bench_cfg):
        """data_path 누락 → 에러."""
        del valid_bench_cfg["bench"]["data_path"]
        with pytest.raises(ConfigValidationError, match="Missing bench.data_path"):
            validate_bench_config(valid_bench_cfg)

    def test_negative_sample_k(self, valid_bench_cfg):
        """sample.k < 0 → 에러."""
        valid_bench_cfg["bench"]["sample"]["k"] = -1
        with pytest.raises(ConfigValidationError, match="non-negative integer"):
            validate_bench_config(valid_bench_cfg)

    def test_baseline_with_model_dir_valid(self, valid_bench_cfg):
        """baseline에 model_dir 지정 → local HF 모델로 유효."""
        valid_bench_cfg["bench"]["models"]["baseline"] = {
            "enabled": True,
            "model_dir": "Qwen/Qwen2.5-0.5B",
            "device": "cuda:0",
            "dtype": "float16",
        }
        validate_bench_config(valid_bench_cfg)  # Should not raise

    def test_baseline_with_model_dir_no_provider_needed(self, valid_bench_cfg):
        """baseline에 model_dir만 있으면 provider 불필요."""
        valid_bench_cfg["bench"]["models"]["baseline"] = {
            "enabled": True,
            "model_dir": "/path/to/local/model",
        }
        validate_bench_config(valid_bench_cfg)  # Should not raise

    def test_baseline_invalid_provider_still_errors(self, valid_bench_cfg):
        """baseline에 model_dir 없고 provider가 잘못되면 여전히 에러."""
        valid_bench_cfg["bench"]["models"]["baseline"] = {
            "enabled": True,
            "provider": "invalid_provider",
            "model": "test-model",
        }
        with pytest.raises(ConfigValidationError, match="Unknown provider"):
            validate_bench_config(valid_bench_cfg)

    def test_baseline_model_dir_with_hf_hub_name(self, valid_bench_cfg):
        """baseline에 HF hub 이름을 model_dir로 지정 (e.g. Qwen/Qwen2.5-0.5B)."""
        valid_bench_cfg["bench"]["models"]["baseline"] = {
            "enabled": True,
            "model_dir": "Qwen/Qwen2.5-0.5B",
            "device": "cuda:0",
            "dtype": "float16",
        }
        validate_bench_config(valid_bench_cfg)  # Should not raise


# =========================================================================
# TestBenchCLI
# =========================================================================
class TestBenchCLI:
    """CLI argparse + 서브커맨드 테스트 (4 tests)."""

    def test_help_shows_options(self, capsys):
        """--help 출력에 필수 옵션 표시."""
        parser = build_argparser()
        with pytest.raises(SystemExit) as exc_info:
            parser.parse_args(["--help"])
        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        assert "--preset" in captured.out
        assert "--set" in captured.out
        assert "--validate-only" in captured.out
        assert "--dry-run" in captured.out

    def test_validate_only(self, valid_bench_cfg, tmp_path, capsys):
        """--validate-only → 검증만 수행하고 정상 종료."""
        # bench YAML 작성
        yaml_path = tmp_path / "bench.yml"
        import yaml
        with open(yaml_path, "w") as f:
            yaml.dump(valid_bench_cfg, f)

        main(["--preset", str(yaml_path), "--validate-only"])
        captured = capsys.readouterr()
        assert "validation passed" in captured.out

    def test_dry_run(self, valid_bench_cfg, tmp_path, capsys):
        """--dry-run → 샘플만 출력 (HTTP 호출 없음)."""
        yaml_path = tmp_path / "bench.yml"
        import yaml
        with open(yaml_path, "w") as f:
            yaml.dump(valid_bench_cfg, f)

        main(["--preset", str(yaml_path), "--dry-run"])
        captured = capsys.readouterr()
        assert "Dry-run" in captured.out
        assert "samples extracted" in captured.out

    def test_set_override(self, valid_bench_cfg, tmp_path, capsys):
        """--set bench.sample.k=3 → k 오버라이드 적용."""
        yaml_path = tmp_path / "bench.yml"
        import yaml
        with open(yaml_path, "w") as f:
            yaml.dump(valid_bench_cfg, f)

        main(["--preset", str(yaml_path), "--dry-run",
              "--set", "bench.sample.k=3"])
        captured = capsys.readouterr()
        assert "Dry-run" in captured.out
        # k=3 → 3개 샘플만 추출 (인덱스 라인만 필터)
        lines = [l for l in captured.out.strip().split("\n") if l.strip().startswith("[") and not l.strip().startswith("[Dry")]
        assert len(lines) == 3

    def test_set_data_path_toplevel_hoisted_to_bench(self, valid_bench_cfg, tmp_path, capsys):
        """--set data_path=X → bench.data_path로 호이스팅되어 적용."""
        # 다른 데이터 파일 생성
        alt_data = tmp_path / "alt_data.jsonl"
        import json
        with open(alt_data, "w") as f:
            for _ in range(5):
                f.write(json.dumps({"prompt": "test", "response": "ok"}) + "\n")

        yaml_path = tmp_path / "bench.yml"
        import yaml
        with open(yaml_path, "w") as f:
            yaml.dump(valid_bench_cfg, f)

        # --set data_path=... (최상위) → bench.data_path로 호이스팅
        main(["--preset", str(yaml_path), "--dry-run",
              "--set", f"data_path={alt_data}",
              "--set", "bench.sample.k=2"])
        captured = capsys.readouterr()
        assert "Dry-run" in captured.out
        # alt_data 파일의 데이터가 사용되었는지 확인 (2개 샘플 추출)
        lines = [l for l in captured.out.strip().split("\n")
                 if l.strip().startswith("[") and not l.strip().startswith("[Dry")]
        assert len(lines) == 2

    def test_set_bench_data_path_still_works(self, valid_bench_cfg, tmp_path, capsys):
        """--set bench.data_path=X → 정상 경로로 직접 적용."""
        alt_data = tmp_path / "alt_data2.jsonl"
        import json
        with open(alt_data, "w") as f:
            for _ in range(3):
                f.write(json.dumps({"prompt": "test2", "response": "ok2"}) + "\n")

        yaml_path = tmp_path / "bench.yml"
        import yaml
        with open(yaml_path, "w") as f:
            yaml.dump(valid_bench_cfg, f)

        main(["--preset", str(yaml_path), "--dry-run",
              "--set", f"bench.data_path={alt_data}",
              "--set", "bench.sample.k=2"])
        captured = capsys.readouterr()
        assert "Dry-run" in captured.out


# =========================================================================
# _build_summary 테스트 — pointwise + baseline 시나리오
# =========================================================================
class TestBuildSummary:
    """_build_summary: target-only, pointwise+baseline, pairwise."""

    def _cfg(self, baseline_enabled=False):
        c = {
            "bench": {
                "task": "sft",
                "models": {
                    "target": {"model": "test-target"},
                    "baseline": {"enabled": baseline_enabled, "model": "test-baseline"},
                },
            }
        }
        return c

    def test_pointwise_target_only(self):
        """pointwise without baseline: avg_score from target scores."""
        from eulerforge.cli.bench import _build_summary
        results = [
            {"judge_result": {"score": 7}},
            {"judge_result": {"score": 5}},
            {"judge_result": {"score": 9}},
        ]
        summary = _build_summary(results, self._cfg(), "pointwise")
        assert summary["avg_score"] == 7.0
        assert summary["min_score"] == 5
        assert summary["max_score"] == 9
        assert "baseline_avg_score" not in summary

    def test_pointwise_with_baseline(self):
        """pointwise with baseline: both target and baseline scores."""
        from eulerforge.cli.bench import _build_summary
        results = [
            {"judge_result": {"target_score": 3, "baseline_score": 8, "score": 3}},
            {"judge_result": {"target_score": 5, "baseline_score": 6, "score": 5}},
        ]
        summary = _build_summary(results, self._cfg(baseline_enabled=True), "pointwise")
        assert summary["target_avg_score"] == 4.0
        assert summary["baseline_avg_score"] == 7.0
        # 하위호환: avg_score = target_avg_score
        assert summary["avg_score"] == 4.0

    def test_pairwise(self):
        """pairwise: wins/ties count."""
        from eulerforge.cli.bench import _build_summary
        results = [
            {"judge_result": {"winner": "A"}},
            {"judge_result": {"winner": "B"}},
            {"judge_result": {"winner": "tie"}},
        ]
        summary = _build_summary(results, self._cfg(baseline_enabled=True), "pairwise")
        assert summary["target_wins"] == 1
        assert summary["baseline_wins"] == 1
        assert summary["ties"] == 1

    def test_pointwise_baseline_scores_in_summary(self):
        """pointwise+baseline: min/max for baseline too."""
        from eulerforge.cli.bench import _build_summary
        results = [
            {"judge_result": {"target_score": 2, "baseline_score": 7, "score": 2}},
            {"judge_result": {"target_score": 4, "baseline_score": 9, "score": 4}},
            {"judge_result": {"target_score": 3, "baseline_score": 5, "score": 3}},
        ]
        summary = _build_summary(results, self._cfg(baseline_enabled=True), "pointwise")
        assert summary["baseline_min_score"] == 5
        assert summary["baseline_max_score"] == 9
        assert summary["target_min_score"] == 2
        assert summary["target_max_score"] == 4
