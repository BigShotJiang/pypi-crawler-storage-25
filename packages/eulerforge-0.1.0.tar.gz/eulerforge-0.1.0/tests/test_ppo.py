# tests/test_ppo.py
"""PPO (RLHF) 단위 테스트."""
import json

import pytest
import torch
import torch.nn as nn

from eulerforge.cli.train import compute_gae, ppo_clipped_loss, RewardHead
from eulerforge.utils.data import ProcessedPromptDataset
from eulerforge.utils.tokenize import tokenize_prompt_only, VALID_TASKS


class TestComputeGAE:
    """compute_gae 단위 테스트."""

    def test_basic_shape(self):
        """출력이 입력과 동일한 shape"""
        rewards = torch.tensor([0.0, 0.0, 1.0])
        values = torch.tensor([0.5, 0.6, 0.8])
        advantages = compute_gae(rewards, values, gamma=0.99, lam=0.95)
        assert advantages.shape == rewards.shape

    def test_single_step(self):
        """단일 스텝에서 advantage = reward - value"""
        rewards = torch.tensor([1.0])
        values = torch.tensor([0.5])
        advantages = compute_gae(rewards, values, gamma=0.99, lam=0.95)
        # For single step, advantage = reward - value (no future)
        expected = 1.0 - 0.5
        assert abs(advantages[0].item() - expected) < 0.01

    def test_zero_rewards(self):
        """보상이 모두 0이면 advantage가 음수 (values > 0인 경우)"""
        rewards = torch.zeros(5)
        values = torch.ones(5)
        advantages = compute_gae(rewards, values, gamma=0.99, lam=0.95)
        # Advantages should be negative since values > rewards
        assert (advantages <= 0).all()

    def test_discount_propagation(self):
        """마지막 스텝의 보상이 앞쪽으로 할인 전파"""
        rewards = torch.tensor([0.0, 0.0, 0.0, 10.0])
        values = torch.zeros(4)
        advantages = compute_gae(rewards, values, gamma=0.99, lam=0.95)
        # Last step should have highest advantage
        assert advantages[-1] > advantages[0]


class TestPPOClippedLoss:
    """ppo_clipped_loss 단위 테스트."""

    def test_basic_finite(self):
        """기본 입력에서 유한한 loss"""
        ratios = torch.tensor([1.0, 1.1, 0.9])
        advantages = torch.tensor([1.0, -0.5, 0.3])
        loss = ppo_clipped_loss(ratios, advantages, clip_range=0.2)
        assert torch.isfinite(loss)

    def test_clipping_effect(self):
        """클리핑 범위 밖의 ratio가 클리핑됨"""
        # Ratio far outside clip range
        ratios_extreme = torch.tensor([2.0, 0.1])
        advantages = torch.tensor([1.0, 1.0])
        loss_clipped = ppo_clipped_loss(ratios_extreme, advantages, clip_range=0.2)

        # Ratio within clip range
        ratios_normal = torch.tensor([1.1, 0.9])
        loss_normal = ppo_clipped_loss(ratios_normal, advantages, clip_range=0.2)

        # Both should be finite
        assert torch.isfinite(loss_clipped)
        assert torch.isfinite(loss_normal)

    def test_zero_advantages(self):
        """advantage가 0이면 loss도 0"""
        ratios = torch.tensor([1.5, 0.5])
        advantages = torch.zeros(2)
        loss = ppo_clipped_loss(ratios, advantages, clip_range=0.2)
        assert abs(loss.item()) < 1e-6

    def test_negative_loss_for_good_actions(self):
        """좋은 action (positive advantage)은 negative loss (최대화)"""
        ratios = torch.ones(3)  # ratio=1 means same as old policy
        advantages = torch.ones(3)  # positive = good
        loss = ppo_clipped_loss(ratios, advantages, clip_range=0.2)
        # PPO loss is negative of clipped surrogate objective
        assert loss < 0


class TestProcessedPromptDataset:
    """ProcessedPromptDataset 단위 테스트."""

    def test_load_and_length(self, tmp_path):
        """JSONL로부터 로드 및 길이 확인"""
        path = tmp_path / "prompts.jsonl"
        import json
        with open(path, "w") as f:
            for i in range(5):
                f.write(json.dumps({"input_ids": list(range(10)), "attention_mask": [1]*10}) + "\n")

        ds = ProcessedPromptDataset(str(path))
        assert len(ds) == 5

    def test_getitem_fields(self, tmp_path):
        """각 항목에 input_ids, attention_mask 포함"""
        path = tmp_path / "prompts.jsonl"
        import json
        with open(path, "w") as f:
            f.write(json.dumps({"input_ids": [1, 2, 3], "attention_mask": [1, 1, 1]}) + "\n")

        ds = ProcessedPromptDataset(str(path))
        item = ds[0]
        assert "input_ids" in item
        assert "attention_mask" in item
        assert torch.is_tensor(item["input_ids"])

    def test_no_labels(self, tmp_path):
        """프롬프트 데이터에는 labels가 없어야 함"""
        path = tmp_path / "prompts.jsonl"
        import json
        with open(path, "w") as f:
            f.write(json.dumps({"input_ids": [1, 2, 3], "attention_mask": [1, 1, 1]}) + "\n")

        ds = ProcessedPromptDataset(str(path))
        item = ds[0]
        assert "labels" not in item

    def test_collate_fn_works_without_labels(self, tmp_path):
        """make_collate_fn이 labels 없는 PPO 프롬프트 데이터에서 작동."""
        from eulerforge.utils.data import make_collate_fn
        import json

        path = tmp_path / "prompts.jsonl"
        with open(path, "w") as f:
            f.write(json.dumps({"input_ids": [1, 2, 3], "attention_mask": [1, 1, 1]}) + "\n")
            f.write(json.dumps({"input_ids": [4, 5], "attention_mask": [1, 1]}) + "\n")

        ds = ProcessedPromptDataset(str(path))
        collate = make_collate_fn(pad_token_id=0)

        # 이 호출이 KeyError 없이 성공해야 함
        batch = collate([ds[0], ds[1]])
        assert "input_ids" in batch
        assert "attention_mask" in batch
        # PPO 프롬프트에는 labels가 없으므로 반환에도 없어야 함
        assert "labels" not in batch

    def test_collate_fn_pads_prompt_correctly(self, tmp_path):
        """PPO 프롬프트 collate 시 길이가 다른 배치를 올바르게 패딩."""
        from eulerforge.utils.data import make_collate_fn
        import json

        path = tmp_path / "prompts.jsonl"
        with open(path, "w") as f:
            f.write(json.dumps({"input_ids": [10, 20, 30], "attention_mask": [1, 1, 1]}) + "\n")
            f.write(json.dumps({"input_ids": [40], "attention_mask": [1]}) + "\n")

        ds = ProcessedPromptDataset(str(path))
        collate = make_collate_fn(pad_token_id=99)
        batch = collate([ds[0], ds[1]])

        assert batch["input_ids"].shape == (2, 3)
        assert batch["attention_mask"].shape == (2, 3)
        # 두 번째 샘플은 pad_token_id=99로 패딩
        assert batch["input_ids"][1, 1].item() == 99
        assert batch["attention_mask"][1, 1].item() == 0


class TestPPOValidation:
    """PPO validator 테스트."""

    def test_ppo_missing_section(self):
        """PPO 설정에 ppo 섹션 없으면 에러"""
        from eulerforge.utils.validator import validate_config, ConfigValidationError
        cfg = {
            "backbone": "qwen",
            "injection": {"strategy": "dense_lora"},
            "training": {"type": "ppo"},
        }
        with pytest.raises(ConfigValidationError, match="ppo"):
            validate_config(cfg)

    def test_ppo_missing_reward_model(self):
        """PPO에 reward_model 섹션 없으면 에러"""
        from eulerforge.utils.validator import validate_config, ConfigValidationError
        cfg = {
            "backbone": "qwen",
            "injection": {"strategy": "dense_lora"},
            "training": {
                "type": "ppo",
                "ppo": {"clip_range": 0.2, "kl_coef": 0.1, "epochs": 4},
            },
        }
        with pytest.raises(ConfigValidationError, match="reward_model"):
            validate_config(cfg)

    def test_ppo_valid_config(self):
        """유효한 PPO 설정은 통과"""
        from eulerforge.utils.validator import validate_config
        cfg = {
            "backbone": "qwen",
            "injection": {"strategy": "dense_lora"},
            "training": {
                "type": "ppo",
                "ppo": {"clip_range": 0.2, "kl_coef": 0.1, "epochs": 4},
                "reward_model": {"model_name": "Qwen/Qwen3.5-0.8B-Base"},
            },
        }
        validate_config(cfg)

    def test_ppo_with_checkpoint_path(self):
        """reward_model에 checkpoint_path가 있어도 통과"""
        from eulerforge.utils.validator import validate_config
        cfg = {
            "backbone": "qwen",
            "injection": {"strategy": "dense_lora"},
            "training": {
                "type": "ppo",
                "ppo": {"clip_range": 0.2, "kl_coef": 0.1, "epochs": 4},
                "reward_model": {
                    "model_name": "Qwen/Qwen3.5-0.8B-Base",
                    "checkpoint_path": "/path/to/rm/final",
                },
            },
        }
        validate_config(cfg)

    def test_ppo_with_device(self):
        """reward_model에 device 설정이 있어도 통과"""
        from eulerforge.utils.validator import validate_config
        cfg = {
            "backbone": "qwen",
            "injection": {"strategy": "dense_lora"},
            "training": {
                "type": "ppo",
                "ppo": {"clip_range": 0.2, "kl_coef": 0.1, "epochs": 4},
                "reward_model": {
                    "model_name": "Qwen/Qwen3.5-0.8B-Base",
                    "device": "cuda:1",
                },
            },
        }
        validate_config(cfg)


class TestTokenizePromptOnly:
    """prompt_only 토크나이즈 함수 단위 테스트."""

    def test_prompt_only_in_valid_tasks(self):
        """prompt_only가 VALID_TASKS에 포함"""
        assert "prompt_only" in VALID_TASKS

    def test_basic_tokenization(self):
        """기본 프롬프트 토크나이즈"""
        class FakeTokenizer:
            def encode(self, text, add_special_tokens=False):
                return list(range(len(text.split())))
        row = {"prompt": "hello world test"}
        result = tokenize_prompt_only(row, FakeTokenizer())
        assert "input_ids" in result
        assert "attention_mask" in result
        assert "labels" not in result  # PPO는 labels 없음
        assert len(result["input_ids"]) == 3
        assert all(m == 1 for m in result["attention_mask"])

    def test_empty_prompt_raises(self):
        """빈 프롬프트는 에러"""
        class FakeTokenizer:
            def encode(self, text, add_special_tokens=False):
                return []
        with pytest.raises(ValueError, match="non-empty"):
            tokenize_prompt_only({"prompt": ""}, FakeTokenizer())

    def test_missing_prompt_col_raises(self):
        """prompt 컬럼 없으면 에러"""
        class FakeTokenizer:
            def encode(self, text, add_special_tokens=False):
                return [1, 2]
        with pytest.raises(ValueError, match="non-empty"):
            tokenize_prompt_only({}, FakeTokenizer())

    def test_max_length_truncation(self):
        """max_length에 따라 잘림"""
        class FakeTokenizer:
            def encode(self, text, add_special_tokens=False):
                return list(range(100))
        result = tokenize_prompt_only({"prompt": "x"}, FakeTokenizer(), max_length=10)
        assert len(result["input_ids"]) == 10

    def test_custom_prompt_col(self):
        """커스텀 prompt_col 지정"""
        class FakeTokenizer:
            def encode(self, text, add_special_tokens=False):
                return [1, 2, 3]
        result = tokenize_prompt_only(
            {"question": "hello"}, FakeTokenizer(), prompt_col="question"
        )
        assert len(result["input_ids"]) == 3


class TestRewardHeadSaveLoad:
    """RewardHead 저장/로드 테스트."""

    def test_save_and_load_roundtrip(self, tmp_path):
        """RewardHead 저장 후 로드하면 동일한 가중치"""
        head = RewardHead(hidden_size=32)
        save_path = tmp_path / "reward_head.pt"
        torch.save(head.state_dict(), save_path)

        head2 = RewardHead(hidden_size=32)
        head2.load_state_dict(torch.load(save_path, weights_only=True))

        # 가중치 동일 확인
        for (k1, v1), (k2, v2) in zip(head.state_dict().items(), head2.state_dict().items()):
            assert k1 == k2
            assert torch.equal(v1, v2)


class TestPPOLeftPadForGenerate:
    """PPO 생성 시 left-padding 변환 테스트."""

    def test_right_to_left_pad_basic(self):
        """right-padded → left-padded 변환 검증."""
        from eulerforge.cli.train import _right_to_left_pad

        # right-padded: [10, 20, PAD, PAD]
        input_ids = torch.tensor([[10, 20, 0, 0], [10, 20, 30, 0]])
        attn_mask = torch.tensor([[1, 1, 0, 0], [1, 1, 1, 0]])

        left_ids, left_mask = _right_to_left_pad(input_ids, attn_mask, pad_token_id=0)

        # 첫 번째: [PAD, PAD, 10, 20]
        assert left_ids[0].tolist() == [0, 0, 10, 20]
        assert left_mask[0].tolist() == [0, 0, 1, 1]

        # 두 번째: [PAD, 10, 20, 30]
        assert left_ids[1].tolist() == [0, 10, 20, 30]
        assert left_mask[1].tolist() == [0, 1, 1, 1]

    def test_right_to_left_pad_no_padding(self):
        """패딩 없는 경우 그대로 반환."""
        from eulerforge.cli.train import _right_to_left_pad

        input_ids = torch.tensor([[10, 20, 30]])
        attn_mask = torch.tensor([[1, 1, 1]])

        left_ids, left_mask = _right_to_left_pad(input_ids, attn_mask, pad_token_id=0)
        assert left_ids[0].tolist() == [10, 20, 30]
        assert left_mask[0].tolist() == [1, 1, 1]

    def test_right_to_left_pad_all_padding(self):
        """전체 패딩인 경우도 안전."""
        from eulerforge.cli.train import _right_to_left_pad

        input_ids = torch.tensor([[0, 0, 0]])
        attn_mask = torch.tensor([[0, 0, 0]])

        left_ids, left_mask = _right_to_left_pad(input_ids, attn_mask, pad_token_id=0)
        assert left_ids[0].tolist() == [0, 0, 0]
        assert left_mask[0].tolist() == [0, 0, 0]


class TestPPOGenerateGradCheckpoint:
    """PPO generate()에서 gradient checkpointing 비활성화 테스트."""

    def test_generate_disables_gradient_checkpointing(self):
        """generate() 전 gradient_checkpointing 비활성화, 후 복원 검증."""
        from eulerforge.cli.train import _safe_generate_for_ppo

        class FakeConfig:
            pad_token_id = 0
            eos_token_id = 0

        class FakeModel(nn.Module):
            def __init__(self):
                super().__init__()
                self.linear = nn.Linear(4, 4)
                self.config = FakeConfig()
                self._gc_was_disabled = False
                self._gc_enabled = True  # simulate gradient checkpointing on

            def gradient_checkpointing_disable(self):
                self._gc_was_disabled = True
                self._gc_enabled = False

            def gradient_checkpointing_enable(self, **kwargs):
                self._gc_enabled = True

            @property
            def is_gradient_checkpointing(self):
                return self._gc_enabled

            def generate(self, **kwargs):
                # 호출 시점에 gc가 꺼져 있어야 함
                assert not self._gc_enabled, "gradient checkpointing should be OFF during generate"
                B = kwargs["input_ids"].shape[0]
                seq_len = kwargs["input_ids"].shape[1] + 3
                return torch.ones(B, seq_len, dtype=torch.long)

        model = FakeModel()
        prompt_ids = torch.tensor([[1, 2, 3, 0]])
        prompt_mask = torch.tensor([[1, 1, 1, 0]])

        generated = _safe_generate_for_ppo(
            model, prompt_ids, prompt_mask, max_gen_len=3, temperature=1.0,
        )
        assert generated is not None
        # gc가 다시 켜져야 함
        assert model._gc_enabled, "gradient checkpointing should be restored after generate"

    def test_generate_without_grad_checkpointing(self):
        """gradient checkpointing 없는 모델에서도 정상 작동."""
        from eulerforge.cli.train import _safe_generate_for_ppo

        class FakeConfig:
            pad_token_id = 0
            eos_token_id = 0

        class FakeModel(nn.Module):
            def __init__(self):
                super().__init__()
                self.linear = nn.Linear(4, 4)
                self.config = FakeConfig()

            @property
            def is_gradient_checkpointing(self):
                return False

            def generate(self, **kwargs):
                B = kwargs["input_ids"].shape[0]
                seq_len = kwargs["input_ids"].shape[1] + 3
                return torch.ones(B, seq_len, dtype=torch.long)

        model = FakeModel()
        prompt_ids = torch.tensor([[1, 2, 3]])
        prompt_mask = torch.tensor([[1, 1, 1]])

        generated = _safe_generate_for_ppo(
            model, prompt_ids, prompt_mask, max_gen_len=3, temperature=1.0,
        )
        assert generated.shape[0] == 1


class TestPPODataValidator:
    """PPO 데이터 검증 테스트."""

    def test_ppo_processed_data_valid(self, tmp_path):
        """input_ids만 있는 PPO 데이터가 통과"""
        from eulerforge.utils.data_validator import validate_processed_data
        path = tmp_path / "ppo.jsonl"
        with open(path, "w") as f:
            for i in range(3):
                f.write(json.dumps({"input_ids": [1, 2, 3], "attention_mask": [1, 1, 1]}) + "\n")
        validate_processed_data(str(path), "ppo")

    def test_ppo_processed_data_missing_input_ids(self, tmp_path):
        """input_ids 없으면 에러"""
        from eulerforge.utils.data_validator import validate_processed_data
        from eulerforge.utils.validator import ConfigValidationError
        path = tmp_path / "bad_ppo.jsonl"
        with open(path, "w") as f:
            f.write(json.dumps({"attention_mask": [1, 1, 1]}) + "\n")
        with pytest.raises(ConfigValidationError):
            validate_processed_data(str(path), "ppo")
