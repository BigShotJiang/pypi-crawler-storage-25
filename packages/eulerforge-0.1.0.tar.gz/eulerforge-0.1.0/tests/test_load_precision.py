# tests/test_load_precision.py
# -*- coding: utf-8 -*-
"""Tests for model.load_precision YAML spec validation and dequantize policy."""
from __future__ import annotations

import logging

import pytest
import torch
import torch.nn as nn

from eulerforge.utils.validator import ConfigValidationError, validate_config


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _base_cfg(**overrides):
    """Minimal valid config."""
    cfg = {
        "backbone": "qwen3",
        "model_name": "Qwen/Qwen3.5-0.8B-Base",
        "device": "cuda:0",
        "injection": {"strategy": "dense_lora"},
        "training": {
            "phases": [{"step": 0, "trainable": ["lora"]}],
        },
    }
    for k, v in overrides.items():
        keys = k.split(".")
        d = cfg
        for part in keys[:-1]:
            d = d.setdefault(part, {})
        d[keys[-1]] = v
    return cfg


# =========================================================================
# A) Validator: valid configs should pass
# =========================================================================
class TestLoadPrecisionValid:
    """Valid model.load_precision configs should pass validation."""

    def test_no_model_section_passes(self):
        """No model section → default (bf16), no error."""
        cfg = _base_cfg()
        validate_config(cfg)  # should not raise

    def test_valid_bf16_mode(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {"mode": "bf16"}}
        validate_config(cfg)

    def test_valid_fp16_mode(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {"mode": "fp16"}}
        validate_config(cfg)

    def test_valid_fp32_mode(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {"mode": "fp32"}}
        validate_config(cfg)

    def test_valid_int8_minimal(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {"mode": "int8"}}
        validate_config(cfg)

    def test_valid_int4_full_config(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {
            "mode": "int4",
            "compute_dtype": "bf16",
            "quant_type": "nf4",
            "double_quant": True,
            "dequantize_on_train": True,
        }}
        validate_config(cfg)

    def test_valid_int4_fp4(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {
            "mode": "int4",
            "quant_type": "fp4",
        }}
        validate_config(cfg)

    def test_valid_int8_with_compute_dtype(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {
            "mode": "int8",
            "compute_dtype": "fp16",
        }}
        validate_config(cfg)


# =========================================================================
# B) Validator: invalid configs should raise ConfigValidationError
# =========================================================================
class TestLoadPrecisionInvalid:
    """Invalid model.load_precision configs should raise errors."""

    def test_invalid_mode(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {"mode": "q4"}}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        err = str(exc_info.value)
        assert "mode" in err.lower()
        assert exc_info.value.fix
        assert exc_info.value.doc

    def test_missing_mode(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {"compute_dtype": "bf16"}}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        assert "mode" in str(exc_info.value).lower()

    def test_invalid_compute_dtype(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {"mode": "int4", "compute_dtype": "int8"}}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        assert "compute_dtype" in str(exc_info.value).lower()

    def test_invalid_quant_type(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {"mode": "int4", "quant_type": "abc"}}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        assert "quant_type" in str(exc_info.value).lower()

    def test_double_quant_not_bool(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {"mode": "int4", "double_quant": "yes"}}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        assert "double_quant" in str(exc_info.value).lower()

    def test_dequantize_on_train_not_bool(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {"mode": "int4", "dequantize_on_train": "yes"}}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        assert "dequantize_on_train" in str(exc_info.value).lower()

    def test_load_precision_not_dict(self):
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": "int4"}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        assert "dict" in str(exc_info.value).lower() or "load_precision" in str(exc_info.value).lower()

    def test_int4_on_cpu_raises(self):
        cfg = _base_cfg()
        cfg["device"] = "cpu"
        cfg["model"] = {"load_precision": {"mode": "int4"}}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        err = str(exc_info.value)
        assert "cuda" in err.lower() or "cpu" in err.lower()

    def test_int8_on_cpu_raises(self):
        cfg = _base_cfg()
        cfg["device"] = "cpu"
        cfg["model"] = {"load_precision": {"mode": "int8"}}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        err = str(exc_info.value)
        assert "cuda" in err.lower() or "cpu" in err.lower()


# =========================================================================
# C) Validator: warnings
# =========================================================================
class TestLoadPrecisionWarnings:
    """Warnings for deprecated or risky configurations."""

    def test_legacy_quant_bits_warns(self, caplog):
        """training.quant_bits should trigger deprecation warning."""
        cfg = _base_cfg()
        cfg["training"]["quant_bits"] = 4
        with caplog.at_level(logging.WARNING):
            validate_config(cfg)
        assert any("quant_bits" in r.message.lower() or "deprecated" in r.message.lower()
                    for r in caplog.records)

    def test_int4_base_ffn_no_dequantize_warns(self, caplog):
        """int4 + base_ffn trainable + dequantize_on_train=false → warning."""
        cfg = _base_cfg()
        cfg["model"] = {"load_precision": {
            "mode": "int4",
            "dequantize_on_train": False,
        }}
        cfg["injection"]["strategy"] = "moe_expert_lora"
        cfg["injection"]["num_experts"] = 4
        cfg["injection"]["top_k"] = 2
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["lora", "router"]},
            {"step": 100, "trainable": ["lora", "router", "base_ffn"],
             "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"]},
        ]
        cfg["moe"] = {
            "router_z_loss_coef": 0.01,
            "load_balance": {"type": "aux_loss", "aux_loss_coef": 0.01},
        }
        with caplog.at_level(logging.WARNING):
            validate_config(cfg)
        assert any("dequantize" in r.message.lower() for r in caplog.records)


# =========================================================================
# D) resolve_load_precision helper
# =========================================================================
class TestResolveLoadPrecision:
    """Test the config resolution helper for load_precision."""

    def test_defaults_when_no_model_section(self):
        from eulerforge.utils.load_precision import resolve_load_precision
        cfg = {}
        result = resolve_load_precision(cfg)
        assert result["mode"] == "bf16"
        assert result["compute_dtype"] == "bf16"
        assert result["dequantize_on_train"] is True

    def test_int4_full(self):
        from eulerforge.utils.load_precision import resolve_load_precision
        cfg = {"model": {"load_precision": {
            "mode": "int4",
            "compute_dtype": "fp16",
            "quant_type": "fp4",
            "double_quant": False,
        }}}
        result = resolve_load_precision(cfg)
        assert result["mode"] == "int4"
        assert result["compute_dtype"] == "fp16"
        assert result["quant_type"] == "fp4"
        assert result["double_quant"] is False

    def test_int8_defaults(self):
        from eulerforge.utils.load_precision import resolve_load_precision
        cfg = {"model": {"load_precision": {"mode": "int8"}}}
        result = resolve_load_precision(cfg)
        assert result["mode"] == "int8"
        assert result["compute_dtype"] == "bf16"

    def test_legacy_quant_bits_conversion(self):
        from eulerforge.utils.load_precision import resolve_load_precision
        cfg = {"training": {"quant_bits": 4}}
        result = resolve_load_precision(cfg)
        assert result["mode"] == "int4"

    def test_legacy_quant_bits_16(self):
        from eulerforge.utils.load_precision import resolve_load_precision
        cfg = {"training": {"quant_bits": 16}}
        result = resolve_load_precision(cfg)
        assert result["mode"] == "bf16"

    def test_model_section_overrides_quant_bits(self):
        from eulerforge.utils.load_precision import resolve_load_precision
        cfg = {
            "training": {"quant_bits": 4},
            "model": {"load_precision": {"mode": "int8"}},
        }
        result = resolve_load_precision(cfg)
        assert result["mode"] == "int8"


# =========================================================================
# E) Dequantize policy (unit-level, no GPU required)
# =========================================================================
class TestDequantizePolicy:
    """Test dequantize_base_ffn_params helper."""

    def test_dequantize_converts_int_params_to_float(self):
        from eulerforge.utils.load_precision import dequantize_base_ffn_params
        # Simulate a quantized parameter (int8)
        linear = nn.Linear(4, 4, bias=False)
        linear.weight = nn.Parameter(
            torch.randint(0, 127, (4, 4), dtype=torch.int8),
            requires_grad=False,
        )
        count = dequantize_base_ffn_params(
            [("layer.weight", linear.weight)],
            target_dtype=torch.bfloat16,
        )
        assert count == 1
        assert linear.weight.dtype == torch.bfloat16

    def test_dequantize_sets_requires_grad(self):
        from eulerforge.utils.load_precision import dequantize_base_ffn_params
        linear = nn.Linear(4, 4, bias=False)
        linear.weight = nn.Parameter(
            torch.randint(0, 127, (4, 4), dtype=torch.int8),
            requires_grad=False,
        )
        dequantize_base_ffn_params(
            [("layer.weight", linear.weight)],
            target_dtype=torch.float32,
        )
        assert linear.weight.requires_grad is True

    def test_no_dequantize_for_float_params(self):
        from eulerforge.utils.load_precision import dequantize_base_ffn_params
        linear = nn.Linear(4, 4, bias=False)
        original_dtype = linear.weight.dtype
        count = dequantize_base_ffn_params(
            [("layer.weight", linear.weight)],
            target_dtype=torch.bfloat16,
        )
        assert count == 0  # already float, skip

    def test_dequantize_logs_count(self, caplog):
        from eulerforge.utils.load_precision import dequantize_base_ffn_params
        linear = nn.Linear(4, 4, bias=False)
        linear.weight = nn.Parameter(
            torch.randint(0, 127, (4, 4), dtype=torch.int8),
            requires_grad=False,
        )
        with caplog.at_level(logging.INFO):
            dequantize_base_ffn_params(
                [("layer.weight", linear.weight)],
                target_dtype=torch.bfloat16,
            )
        assert any("dequantiz" in r.message.lower() for r in caplog.records)


# =========================================================================
# F) Phase transition dequantize integration
#    Bug: set_trainable_by_groups() crashed with RuntimeError when trying
#    to set requires_grad=True on quantized (non-float) params. Now
#    dequantize_dtype is passed through the phase scheduler to auto-cast.
# =========================================================================
class TestPhaseTransitionDequantize:
    """Phase transition with quantized params must dequantize before requires_grad."""

    @staticmethod
    def _make_quantized_model():
        """Create a model with int8 'quantized' FFN params."""
        model = nn.Module()
        model.model = nn.Module()
        layer = nn.Module()
        mlp = nn.Module()
        # Simulate quantized FFN weights (int8)
        mlp.gate_proj = nn.Module()
        mlp.gate_proj.weight = nn.Parameter(
            torch.randint(0, 127, (16, 16), dtype=torch.int8),
            requires_grad=False,
        )
        mlp.up_proj = nn.Module()
        mlp.up_proj.weight = nn.Parameter(
            torch.randint(0, 127, (16, 16), dtype=torch.int8),
            requires_grad=False,
        )
        mlp.down_proj = nn.Module()
        mlp.down_proj.weight = nn.Parameter(
            torch.randint(0, 127, (16, 16), dtype=torch.int8),
            requires_grad=False,
        )
        # Floating-point attention LoRA params
        attn = nn.Module()
        attn.q_proj = nn.Module()
        attn.q_proj.lora_a = nn.Parameter(torch.randn(16, 4))
        attn.q_proj.lora_b = nn.Parameter(torch.randn(4, 16))
        # Router (floating point)
        mlp.router = nn.Module()
        mlp.router.weight = nn.Parameter(torch.randn(2, 16))

        layer.mlp = mlp
        layer.self_attn = attn
        model.model.layers = nn.ModuleList([layer])
        return model

    def test_set_trainable_crashes_without_dequantize_dtype(self):
        """Without dequantize_dtype, quantized params are skipped (not crash)."""
        from eulerforge.phase_schedules.groups import set_trainable_by_groups
        model = self._make_quantized_model()
        # Should NOT crash — skips quantized params with warning
        count = set_trainable_by_groups(
            model,
            active_groups=["base_ffn"],
            mode="replace",
            base_ffn_keywords=["gate_proj", "up_proj", "down_proj"],
        )
        # Quantized params are skipped, so count == 0
        assert count == 0

    def test_set_trainable_with_dequantize_dtype(self):
        """With dequantize_dtype, quantized params are cast and grad-enabled."""
        from eulerforge.phase_schedules.groups import set_trainable_by_groups
        model = self._make_quantized_model()
        count = set_trainable_by_groups(
            model,
            active_groups=["base_ffn"],
            mode="replace",
            base_ffn_keywords=["gate_proj", "up_proj", "down_proj"],
            dequantize_dtype=torch.bfloat16,
        )
        assert count == 3
        for name, p in model.named_parameters():
            if any(kw in name for kw in ("gate_proj", "up_proj", "down_proj")):
                assert p.dtype == torch.bfloat16, f"{name} not dequantized"
                assert p.requires_grad is True, f"{name} grad not enabled"

    def test_phase_scheduler_dequantize_on_transition(self):
        """UniversalPhaseScheduler with dequantize_dtype handles phase2 transition."""
        from eulerforge.phase_schedules.universal import PhaseSpec, UniversalPhaseScheduler
        model = self._make_quantized_model()
        sched = UniversalPhaseScheduler(
            phases=[
                PhaseSpec(step=0, trainable=["router"]),
                PhaseSpec(step=100, trainable=["attn_lora", "router"]),
                PhaseSpec(
                    step=200,
                    trainable=["attn_lora", "router", "base_ffn"],
                    base_ffn_keywords=["gate_proj", "up_proj", "down_proj"],
                ),
            ],
            dequantize_dtype=torch.bfloat16,
        )
        # Phase 0: router only
        sched.maybe_step(model, 0)
        for name, p in model.named_parameters():
            if "gate_proj" in name or "up_proj" in name or "down_proj" in name:
                assert p.requires_grad is False
                assert p.dtype == torch.int8

        # Phase 2: includes base_ffn — must dequantize, NOT crash
        changed = sched.maybe_step(model, 200)
        assert changed is True
        for name, p in model.named_parameters():
            if any(kw in name for kw in ("gate_proj", "up_proj", "down_proj")):
                assert p.dtype == torch.bfloat16, f"{name} not dequantized"
                assert p.requires_grad is True, f"{name} grad not enabled"

    def test_phase_scheduler_no_dequantize_dtype_skips_quantized(self):
        """Without dequantize_dtype, quantized params are skipped (logged warning)."""
        from eulerforge.phase_schedules.universal import PhaseSpec, UniversalPhaseScheduler
        model = self._make_quantized_model()
        sched = UniversalPhaseScheduler(
            phases=[
                PhaseSpec(step=0, trainable=["router"]),
                PhaseSpec(
                    step=100,
                    trainable=["base_ffn"],
                    base_ffn_keywords=["gate_proj", "up_proj", "down_proj"],
                ),
            ],
            # No dequantize_dtype
        )
        sched.maybe_step(model, 0)
        changed = sched.maybe_step(model, 100)
        assert changed is True
        # Quantized params skipped — no crash, no requires_grad
        for name, p in model.named_parameters():
            if any(kw in name for kw in ("gate_proj", "up_proj", "down_proj")):
                assert p.requires_grad is False
                assert p.dtype == torch.int8

    def test_build_phase_schedule_passes_dequantize_dtype(self):
        """build_phase_schedule forwards dequantize_dtype to scheduler."""
        from eulerforge.phase_schedules import build_phase_schedule
        cfg = {
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["router"]},
                    {"step": 500, "trainable": ["lora", "base_ffn"],
                     "base_ffn_keywords": ["gate_proj"]},
                ],
            },
        }
        sched = build_phase_schedule(cfg, dequantize_dtype=torch.float16)
        assert sched is not None
        assert sched._dequantize_dtype == torch.float16

    def test_build_phase_schedule_no_dequantize_dtype(self):
        """build_phase_schedule without dequantize_dtype sets None."""
        from eulerforge.phase_schedules import build_phase_schedule
        cfg = {
            "training": {
                "phases": [{"step": 0, "trainable": ["lora"]}],
            },
        }
        sched = build_phase_schedule(cfg)
        assert sched is not None
        assert sched._dequantize_dtype is None

    def test_float_params_unaffected_by_dequantize_dtype(self):
        """Float params are not affected by dequantize_dtype — just requires_grad."""
        from eulerforge.phase_schedules.groups import set_trainable_by_groups
        model = self._make_quantized_model()
        count = set_trainable_by_groups(
            model,
            active_groups=["router"],
            mode="replace",
            dequantize_dtype=torch.bfloat16,
        )
        # router.weight is already float — should be trainable without dtype change
        for name, p in model.named_parameters():
            if "router" in name and "weight" in name:
                assert p.requires_grad is True
                assert p.dtype == torch.float32  # unchanged

    def test_replace_mode_skips_requires_grad_false_for_quantized(self):
        """In replace mode, non-float params must not get requires_grad=False (which also crashes)."""
        from eulerforge.phase_schedules.groups import set_trainable_by_groups
        model = self._make_quantized_model()
        # This should NOT crash — quantized params skip requires_grad=False too
        count = set_trainable_by_groups(
            model,
            active_groups=["router"],
            mode="replace",
        )
        assert count >= 1
