# tests/test_backbone_gemma4.py
"""
Gemma 4 BackboneAdapter 단위 테스트.

Gemma 4 모델에서 BackboneAdapter가 정상 동작하는지 검증한다.
핵심: Gemma 4는 항상 multimodal wrapper (Gemma4ForConditionalGeneration)를 사용하며,
text backbone은 model.model.language_model.layers 경로에 있다.

MoE 변형(26B-A4B)에서는 각 DecoderLayer에 router + experts (fused 3D)가 추가된다.
dense 변형(31B)에서는 mlp만 존재한다.

TDD RED 단계: 이 테스트는 Gemma4Adapter 구현 전에 작성되었다.
"""
from __future__ import annotations

import pytest
import torch
import torch.nn as nn

from eulerforge.cli.train import _select_backbone_adapter, _needs_token_type_ids


# ---------------------------------------------------------------------------
# Mock Gemma 4 structures (실제 모델 로드 없이 구조만 재현)
# ---------------------------------------------------------------------------

class _FakeGemma4MLP(nn.Module):
    """Dense MLP: gate_proj, up_proj, down_proj."""
    def __init__(self, hidden=64, intermediate=128):
        super().__init__()
        self.gate_proj = nn.Linear(hidden, intermediate, bias=False)
        self.up_proj = nn.Linear(hidden, intermediate, bias=False)
        self.down_proj = nn.Linear(intermediate, hidden, bias=False)


class _FakeGemma4Attention(nn.Module):
    def __init__(self, hidden=64):
        super().__init__()
        self.q_proj = nn.Linear(hidden, hidden, bias=False)
        self.k_proj = nn.Linear(hidden, hidden, bias=False)
        self.v_proj = nn.Linear(hidden, hidden, bias=False)
        self.o_proj = nn.Linear(hidden, hidden, bias=False)


class _FakeGemma4Experts(nn.Module):
    """Fused 3D expert tensors (like Gemma4TextExperts)."""
    def __init__(self, num_experts=8, hidden=64, moe_intermediate=32):
        super().__init__()
        self.num_experts = num_experts
        self.gate_up_proj = nn.Parameter(
            torch.randn(num_experts, 2 * moe_intermediate, hidden)
        )
        self.down_proj = nn.Parameter(
            torch.randn(num_experts, hidden, moe_intermediate)
        )


class _FakeGemma4Router(nn.Module):
    def __init__(self, hidden=64, num_experts=8):
        super().__init__()
        self.proj = nn.Linear(hidden, num_experts, bias=False)
        self.scale = nn.Parameter(torch.ones(hidden))
        self.per_expert_scale = nn.Parameter(torch.ones(num_experts))


class _FakeGemma4DecoderLayer(nn.Module):
    """Dense variant: mlp + self_attn only."""
    def __init__(self, hidden=64, intermediate=128, enable_moe=False,
                 num_experts=8, moe_intermediate=32):
        super().__init__()
        self.self_attn = _FakeGemma4Attention(hidden)
        self.mlp = _FakeGemma4MLP(hidden, intermediate)
        self.input_layernorm = nn.LayerNorm(hidden)
        self.post_attention_layernorm = nn.LayerNorm(hidden)
        self.pre_feedforward_layernorm = nn.LayerNorm(hidden)
        self.post_feedforward_layernorm = nn.LayerNorm(hidden)

        self.enable_moe_block = enable_moe
        if enable_moe:
            self.router = _FakeGemma4Router(hidden, num_experts)
            self.experts = _FakeGemma4Experts(num_experts, hidden, moe_intermediate)


def _make_fake_gemma4_model(num_layers=4, enable_moe=False, num_experts=8):
    """Gemma4ForConditionalGeneration 구조를 모방하는 mock 모델 생성.

    Path: model.model.language_model.layers
    """
    class FakeTextModel(nn.Module):
        def __init__(self):
            super().__init__()
            self.layers = nn.ModuleList([
                _FakeGemma4DecoderLayer(
                    enable_moe=enable_moe, num_experts=num_experts
                )
                for _ in range(num_layers)
            ])
            self.norm = nn.LayerNorm(64)

    class FakeGemma4Model(nn.Module):
        def __init__(self):
            super().__init__()
            self.language_model = FakeTextModel()

    class FakeGemma4ForConditionalGeneration(nn.Module):
        def __init__(self):
            super().__init__()
            self.model = FakeGemma4Model()
            self.lm_head = nn.Linear(64, 1000, bias=False)

    return FakeGemma4ForConditionalGeneration()


# =========================================================================
# 1. Adapter Selection Tests
# =========================================================================

class TestGemma4AdapterSelection:
    """_select_backbone_adapter에서 gemma4 키가 Gemma4Adapter를 반환하는지 검증."""

    def test_gemma4_key_returns_gemma4_adapter(self):
        adapter = _select_backbone_adapter("gemma4")
        assert adapter.__class__.__name__ == "Gemma4Adapter"

    def test_gemma4_case_insensitive(self):
        adapter = _select_backbone_adapter("Gemma4")
        assert adapter.__class__.__name__ == "Gemma4Adapter"

    def test_gemma4_hyphenated(self):
        adapter = _select_backbone_adapter("gemma-4")
        assert adapter.__class__.__name__ == "Gemma4Adapter"

    def test_gemma4_underscore(self):
        adapter = _select_backbone_adapter("gemma_4")
        assert adapter.__class__.__name__ == "Gemma4Adapter"

    def test_gemma3_does_not_match_gemma4(self):
        """gemma3와 gemma4는 별개 어댑터."""
        adapter3 = _select_backbone_adapter("gemma3")
        adapter4 = _select_backbone_adapter("gemma4")
        assert adapter3.__class__.__name__ != adapter4.__class__.__name__

    def test_gemma_without_version_does_not_match_gemma4(self):
        """gemma (no version)는 gemma4로 매핑되지 않는다."""
        adapter = _select_backbone_adapter("gemma")
        assert adapter.__class__.__name__ != "Gemma4Adapter"


# =========================================================================
# 2. Dense Model Structure Tests
# =========================================================================

class TestGemma4AdapterDenseStructure:
    """Dense Gemma 4 (31B) 모델에서 구조 탐색 검증."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.model = _make_fake_gemma4_model(num_layers=4, enable_moe=False)
        self.adapter = _select_backbone_adapter("gemma4")

    def test_find_transformer_layers(self):
        layers = self.adapter.find_transformer_layers(self.model)
        assert isinstance(layers, (list, nn.ModuleList))
        assert len(layers) == 4

    def test_find_ffn_module(self):
        layers = self.adapter.find_transformer_layers(self.model)
        ffn = self.adapter.find_ffn_module(layers[0])
        assert isinstance(ffn, nn.Module)
        assert hasattr(ffn, "gate_proj")
        assert hasattr(ffn, "up_proj")
        assert hasattr(ffn, "down_proj")

    def test_find_ffn_attr_name(self):
        layers = self.adapter.find_transformer_layers(self.model)
        assert self.adapter.find_ffn_attr_name(layers[0]) == "mlp"

    def test_find_attention_leaf_modules(self):
        layers = self.adapter.find_transformer_layers(self.model)
        keywords = ["q_proj", "k_proj", "v_proj", "o_proj"]
        leaves = self.adapter.find_attention_leaf_modules(layers[0], keywords)
        assert len(leaves) == 4
        for path in leaves:
            assert any(k in path for k in keywords)

    def test_dense_no_native_experts(self):
        """Dense 모델에서 native expert group은 빈 리스트."""
        layers = self.adapter.find_transformer_layers(self.model)
        groups = self.adapter.find_native_expert_groups(layers[0])
        assert groups == []


# =========================================================================
# 3. MoE Model Structure Tests
# =========================================================================

class TestGemma4AdapterMoEStructure:
    """MoE Gemma 4 (26B-A4B) 모델에서 구조 탐색 검증."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.model = _make_fake_gemma4_model(
            num_layers=4, enable_moe=True, num_experts=8
        )
        self.adapter = _select_backbone_adapter("gemma4")

    def test_find_transformer_layers(self):
        layers = self.adapter.find_transformer_layers(self.model)
        assert len(layers) == 4

    def test_find_ffn_module_returns_dense_mlp(self):
        """MoE 모델에서도 dense MLP는 항상 존재한다."""
        layers = self.adapter.find_transformer_layers(self.model)
        ffn = self.adapter.find_ffn_module(layers[0])
        assert hasattr(ffn, "gate_proj")

    def test_find_native_expert_groups(self):
        """MoE 모델에서 native expert group을 찾는다."""
        layers = self.adapter.find_transformer_layers(self.model)
        groups = self.adapter.find_native_expert_groups(layers[0])
        assert len(groups) >= 1
        grp = groups[0]
        assert len(grp.experts) == 8
        assert grp.router is not None

    def test_native_experts_are_unfused_slices(self):
        """Fused 3D expert tensor가 개별 슬라이스로 분리되는지 검증."""
        layers = self.adapter.find_transformer_layers(self.model)
        groups = self.adapter.find_native_expert_groups(layers[0])
        grp = groups[0]
        for expert in grp.experts:
            assert isinstance(expert, nn.Module)

    def test_moe_layer_has_router_and_experts_attrs(self):
        """MoE block에 router, experts 속성이 있다."""
        layers = self.adapter.find_transformer_layers(self.model)
        block = layers[0]
        assert hasattr(block, "router")
        assert hasattr(block, "experts")

    def test_attention_still_works_in_moe_block(self):
        """MoE block에서도 attention leaf module 탐색이 정상 작동."""
        layers = self.adapter.find_transformer_layers(self.model)
        keywords = ["q_proj", "k_proj", "v_proj", "o_proj"]
        leaves = self.adapter.find_attention_leaf_modules(layers[0], keywords)
        assert len(leaves) == 4


# =========================================================================
# 4. Default Keywords Tests
# =========================================================================

class TestGemma4AdapterDefaults:
    """Gemma4Adapter의 default keywords 검증."""

    def test_default_ffn_keywords(self):
        adapter = _select_backbone_adapter("gemma4")
        kw = adapter.default_ffn_keywords()
        assert "gate_proj" in kw
        assert "up_proj" in kw
        assert "down_proj" in kw

    def test_default_attn_keywords(self):
        adapter = _select_backbone_adapter("gemma4")
        kw = adapter.default_attn_keywords()
        assert "q_proj" in kw
        assert "v_proj" in kw


# =========================================================================
# 5. bench_client adapter selection
# =========================================================================

class TestGemma4BenchAdapter:
    """bench_client._get_backbone_adapter에서 gemma4가 인식되는지 검증."""

    def test_gemma4_bench_adapter(self):
        from eulerforge.utils.bench_client import _get_backbone_adapter
        adapter = _get_backbone_adapter("gemma4")
        assert adapter.__class__.__name__ == "Gemma4Adapter"

    def test_gemma4_hyphenated_bench(self):
        from eulerforge.utils.bench_client import _get_backbone_adapter
        adapter = _get_backbone_adapter("gemma-4")
        assert adapter.__class__.__name__ == "Gemma4Adapter"

    def test_gemma4_model_name_bench(self):
        """실제 모델 이름에서 gemma4 감지."""
        from eulerforge.utils.bench_client import _get_backbone_adapter
        adapter = _get_backbone_adapter("gemma4-26b-a4b-it")
        assert adapter.__class__.__name__ == "Gemma4Adapter"


# =========================================================================
# 6. _needs_token_type_ids for Gemma 4
# =========================================================================

class TestGemma4NeedsTokenTypeIds:
    """Gemma4ForConditionalGeneration 감지 로직 검증."""

    def test_gemma4_class_name_detection(self):
        """class.__name__이 Gemma4ForConditionalGeneration이면 True."""
        class Gemma4ForConditionalGeneration(nn.Module):
            pass
        assert _needs_token_type_ids(Gemma4ForConditionalGeneration()) is True

    def test_gemma4_mock_multimodal_returns_true(self):
        """language_model + multi_modal_projector 속성 기반 감지."""
        class FakeInner(nn.Module):
            def __init__(self):
                super().__init__()
                self.language_model = nn.Linear(10, 10)
                self.multi_modal_projector = nn.Linear(10, 10)

        class FakeModel(nn.Module):
            def __init__(self):
                super().__init__()
                self.model = FakeInner()

        assert _needs_token_type_ids(FakeModel()) is True

    def test_plain_module_returns_false(self):
        model = nn.Linear(10, 10)
        assert _needs_token_type_ids(model) is False
