# tests/test_convert.py
# -*- coding: utf-8 -*-
"""Unit tests for eulerforge.utils.convert — JSONL format conversion."""
from __future__ import annotations

import json
import os
from typing import Dict

import pytest

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")


# =========================================================================
# A) _resolve_dot_path
# =========================================================================
class TestResolveDotPath:
    """Dot-path navigation into nested dicts."""

    def test_simple_key(self):
        from eulerforge.utils.convert import _resolve_dot_path

        row = {"prompt": "hello"}
        assert _resolve_dot_path(row, "prompt") == "hello"

    def test_nested_key(self):
        from eulerforge.utils.convert import _resolve_dot_path

        row = {"instruction": {"value": "What?"}}
        assert _resolve_dot_path(row, "instruction.value") == "What?"

    def test_deep_nesting(self):
        from eulerforge.utils.convert import _resolve_dot_path

        row = {"a": {"b": {"c": {"d": 42}}}}
        assert _resolve_dot_path(row, "a.b.c.d") == 42

    def test_missing_key_raises(self):
        from eulerforge.utils.convert import _resolve_dot_path

        row = {"x": 1}
        with pytest.raises(KeyError):
            _resolve_dot_path(row, "y")

    def test_non_dict_intermediate_raises(self):
        from eulerforge.utils.convert import _resolve_dot_path

        row = {"a": "string_not_dict"}
        with pytest.raises(KeyError):
            _resolve_dot_path(row, "a.b")


# =========================================================================
# B) validate_output_row
# =========================================================================
class TestValidateOutputRow:
    """Output row validation against task schema."""

    def test_valid_sft_prompt_response(self):
        from eulerforge.utils.convert import validate_output_row

        validate_output_row({"prompt": "q", "response": "a"}, "sft", 0)

    def test_valid_sft_text(self):
        from eulerforge.utils.convert import validate_output_row

        validate_output_row({"text": "hello world"}, "sft", 0)

    def test_valid_preference(self):
        from eulerforge.utils.convert import validate_output_row

        validate_output_row({"chosen": "a", "rejected": "b"}, "preference", 0)

    def test_valid_prompted_preference(self):
        from eulerforge.utils.convert import validate_output_row

        validate_output_row(
            {"prompt": "q", "chosen": "a", "rejected": "b"},
            "prompted_preference", 0,
        )

    def test_invalid_sft_missing_keys(self):
        from eulerforge.utils.convert import validate_output_row

        with pytest.raises(ValueError, match="row 0"):
            validate_output_row({"foo": "bar"}, "sft", 0)

    def test_unknown_task(self):
        from eulerforge.utils.convert import validate_output_row

        with pytest.raises(ValueError, match="Unknown task"):
            validate_output_row({"text": "x"}, "grpo", 0)


# =========================================================================
# C) Recipe functions
# =========================================================================
class TestRecipes:
    """Built-in recipe converter functions."""

    def test_sft_messages_v1_basic(self):
        from eulerforge.utils.convert import get_recipe

        fn, task = get_recipe("sft_messages_v1")
        assert task == "sft"
        row = {"json_record": {"messages": [
            {"role": "system", "content": "Be helpful."},
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": "Hello!"},
        ]}}
        out = fn(row)
        assert "prompt" in out
        assert "response" in out
        assert "Hello!" in out["response"]

    def test_sft_messages_v1_system_user_combined_in_prompt(self):
        from eulerforge.utils.convert import get_recipe

        fn, _ = get_recipe("sft_messages_v1")
        row = {"json_record": {"messages": [
            {"role": "system", "content": "System msg."},
            {"role": "user", "content": "User msg."},
            {"role": "assistant", "content": "Reply."},
        ]}}
        out = fn(row)
        assert "System msg." in out["prompt"]
        assert "User msg." in out["prompt"]

    def test_sft_messages_v1_no_system(self):
        from eulerforge.utils.convert import get_recipe

        fn, _ = get_recipe("sft_messages_v1")
        row = {"json_record": {"messages": [
            {"role": "user", "content": "Question?"},
            {"role": "assistant", "content": "Answer."},
        ]}}
        out = fn(row)
        assert "Question?" in out["prompt"]
        assert "Answer." in out["response"]

    def test_dpo_nested_v1_basic(self):
        from eulerforge.utils.convert import get_recipe

        fn, task = get_recipe("dpo_nested_v1")
        assert task == "prompted_preference"
        row = {
            "instruction": {"value": "What is AI?"},
            "chosen": {"value": "Good answer"},
            "rejected": {"value": "Bad answer"},
        }
        out = fn(row)
        assert out == {
            "prompt": "What is AI?",
            "chosen": "Good answer",
            "rejected": "Bad answer",
        }

    def test_dpo_nested_v1_missing_field_raises(self):
        from eulerforge.utils.convert import get_recipe

        fn, _ = get_recipe("dpo_nested_v1")
        row = {"instruction": {"value": "Hi"}}
        with pytest.raises(KeyError):
            fn(row)

    def test_passthrough_prompted_preference_v1(self):
        from eulerforge.utils.convert import get_recipe

        fn, task = get_recipe("passthrough_prompted_preference_v1")
        assert task == "prompted_preference"
        row = {"prompt": "q", "chosen": "a", "rejected": "b", "extra": "x"}
        out = fn(row)
        assert out == {"prompt": "q", "chosen": "a", "rejected": "b"}

    def test_passthrough_sft_prompt_response_v1(self):
        from eulerforge.utils.convert import get_recipe

        fn, task = get_recipe("passthrough_sft_prompt_response_v1")
        assert task == "sft"
        row = {"prompt": "q", "response": "a", "extra": "x"}
        out = fn(row)
        assert out == {"prompt": "q", "response": "a"}

    def test_passthrough_preference_v1(self):
        from eulerforge.utils.convert import get_recipe

        fn, task = get_recipe("passthrough_preference_v1")
        assert task == "preference"
        row = {"chosen": "a", "rejected": "b", "source": "test"}
        out = fn(row)
        assert out == {"chosen": "a", "rejected": "b"}


# =========================================================================
# D) build_converter_from_mapping
# =========================================================================
class TestBuildConverterFromMapping:
    """Dot-path mapping mode converter builder."""

    def test_sft_with_messages_path(self):
        from eulerforge.utils.convert import build_converter_from_mapping

        conv = build_converter_from_mapping(
            "sft", messages_path="json_record.messages",
        )
        row = {"json_record": {"messages": [
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": "Hello"},
        ]}}
        out = conv(row)
        assert "prompt" in out and "response" in out

    def test_prompted_preference_with_dot_paths(self):
        from eulerforge.utils.convert import build_converter_from_mapping

        conv = build_converter_from_mapping(
            "prompted_preference",
            prompt_path="instruction.value",
            chosen_path="chosen.value",
            rejected_path="rejected.value",
        )
        row = {
            "instruction": {"value": "Q?"},
            "chosen": {"value": "Good"},
            "rejected": {"value": "Bad"},
        }
        out = conv(row)
        assert out == {"prompt": "Q?", "chosen": "Good", "rejected": "Bad"}

    def test_custom_prompt_roles(self):
        from eulerforge.utils.convert import build_converter_from_mapping

        conv = build_converter_from_mapping(
            "sft",
            messages_path="msgs",
            messages_prompt_roles="human",
            messages_response_role="bot",
        )
        row = {"msgs": [
            {"role": "human", "content": "Hi"},
            {"role": "bot", "content": "Hello"},
        ]}
        out = conv(row)
        assert "Hi" in out["prompt"]
        assert "Hello" in out["response"]


# =========================================================================
# E) convert_file
# =========================================================================
class TestConvertFile:
    """File-level conversion."""

    def test_sequential_sft_messages(self, tmp_path):
        from eulerforge.utils.convert import convert_file, get_recipe

        inp = os.path.join(FIXTURES, "nested_sft_messages_tiny.jsonl")
        out = str(tmp_path / "out.jsonl")
        fn, task = get_recipe("sft_messages_v1")

        stats = convert_file(inp, out, "sft", fn)
        assert stats["total"] == 4
        assert stats["converted"] == 4
        assert stats["errors"] == 0

        with open(out) as f:
            rows = [json.loads(l) for l in f if l.strip()]
        assert len(rows) == 4
        assert all("prompt" in r and "response" in r for r in rows)

    def test_sequential_dpo_nested(self, tmp_path):
        from eulerforge.utils.convert import convert_file, get_recipe

        inp = os.path.join(FIXTURES, "nested_dpo_tiny_convert.jsonl")
        out = str(tmp_path / "out.jsonl")
        fn, task = get_recipe("dpo_nested_v1")

        stats = convert_file(inp, out, "prompted_preference", fn)
        assert stats["total"] == 4
        assert stats["converted"] == 4

        with open(out) as f:
            rows = [json.loads(l) for l in f if l.strip()]
        assert all("prompt" in r and "chosen" in r and "rejected" in r for r in rows)

    def test_max_rows_limits_output(self, tmp_path):
        from eulerforge.utils.convert import convert_file, get_recipe

        inp = os.path.join(FIXTURES, "nested_sft_messages_tiny.jsonl")
        out = str(tmp_path / "out.jsonl")
        fn, _ = get_recipe("sft_messages_v1")

        stats = convert_file(inp, out, "sft", fn, max_rows=2)
        assert stats["total"] == 2
        assert stats["converted"] == 2

    def test_empty_input_raises(self, tmp_path):
        from eulerforge.utils.convert import convert_file, get_recipe

        empty = str(tmp_path / "empty.jsonl")
        with open(empty, "w") as f:
            pass
        out = str(tmp_path / "out.jsonl")
        fn, _ = get_recipe("sft_messages_v1")

        with pytest.raises(ValueError, match="[Ee]mpty"):
            convert_file(empty, out, "sft", fn)

    def test_error_rows_counted(self, tmp_path):
        """A converter that raises on some rows should count errors."""
        from eulerforge.utils.convert import convert_file

        # Write input with one valid and one invalid row
        inp = str(tmp_path / "mixed.jsonl")
        with open(inp, "w") as f:
            f.write(json.dumps({"prompt": "q", "response": "a"}) + "\n")
            f.write(json.dumps({"bad_key": "no match"}) + "\n")

        out = str(tmp_path / "out.jsonl")

        def strict_converter(row):
            if "prompt" not in row:
                raise KeyError("missing prompt")
            return {"prompt": row["prompt"], "response": row["response"]}

        stats = convert_file(inp, out, "sft", strict_converter, validate=False)
        assert stats["errors"] == 1
        assert stats["converted"] == 1


# =========================================================================
# F) validate_file
# =========================================================================
class TestValidateFile:
    """Post-conversion validation."""

    def test_valid_file(self, tmp_path):
        from eulerforge.utils.convert import validate_file

        f = str(tmp_path / "valid.jsonl")
        with open(f, "w") as fp:
            for i in range(3):
                fp.write(json.dumps({"prompt": f"q{i}", "response": f"a{i}"}) + "\n")

        result = validate_file(f, "sft")
        assert result["valid"] == 3
        assert result["invalid"] == 0

    def test_invalid_rows_counted(self, tmp_path):
        from eulerforge.utils.convert import validate_file

        f = str(tmp_path / "mixed.jsonl")
        with open(f, "w") as fp:
            fp.write(json.dumps({"prompt": "q", "response": "a"}) + "\n")
            fp.write(json.dumps({"bad": "row"}) + "\n")

        result = validate_file(f, "sft")
        assert result["valid"] == 1
        assert result["invalid"] == 1


# =========================================================================
# G) Recipe registry
# =========================================================================
class TestRecipeRegistry:
    """Recipe lookup."""

    def test_known_recipe_returns(self):
        from eulerforge.utils.convert import get_recipe

        fn, task = get_recipe("sft_messages_v1")
        assert callable(fn)
        assert task in ("sft", "preference", "prompted_preference")

    def test_unknown_recipe_raises(self):
        from eulerforge.utils.convert import get_recipe

        with pytest.raises(ValueError, match="Unknown recipe"):
            get_recipe("nonexistent_recipe_xyz")


# =========================================================================
# H) flatten_dict
# =========================================================================
class TestFlattenDict:
    """flatten_dict() — nested dict to dot-key dict."""

    def test_flat_passthrough(self):
        from eulerforge.utils.convert import flatten_dict

        row = {"prompt": "q", "response": "a"}
        assert flatten_dict(row) == {"prompt": "q", "response": "a"}

    def test_flat_one_level(self):
        from eulerforge.utils.convert import flatten_dict

        row = {"a": {"b": 1}}
        assert flatten_dict(row) == {"a.b": 1}

    def test_flat_deep(self):
        from eulerforge.utils.convert import flatten_dict

        row = {"x": {"y": {"z": 99}}}
        assert flatten_dict(row) == {"x.y.z": 99}

    def test_flat_list_preserved(self):
        from eulerforge.utils.convert import flatten_dict

        row = {"a": {"b": [1, 2, 3]}}
        assert flatten_dict(row) == {"a.b": [1, 2, 3]}

    def test_flat_mixed(self):
        from eulerforge.utils.convert import flatten_dict

        row = {"top": "val", "nested": {"deep": 42}, "lst": [1, 2]}
        result = flatten_dict(row)
        assert result["top"] == "val"
        assert result["nested.deep"] == 42
        assert result["lst"] == [1, 2]

    def test_flat_empty(self):
        from eulerforge.utils.convert import flatten_dict

        assert flatten_dict({}) == {}


# =========================================================================
# I) resolve_expr
# =========================================================================
class TestResolveExpr:
    """resolve_expr() — expression resolution against flat row."""

    def test_simple_key(self):
        from eulerforge.utils.convert import resolve_expr

        flat = {"instruction": "Q?"}
        assert resolve_expr(flat, "instruction") == "Q?"

    def test_dot_key_flat(self):
        from eulerforge.utils.convert import resolve_expr

        # flat row already has the dot-key
        flat = {"instruction.value": "Deep Q?"}
        assert resolve_expr(flat, "instruction.value") == "Deep Q?"

    def test_list_join_default(self):
        from eulerforge.utils.convert import resolve_expr

        flat = {"parts": ["a", "b"]}
        assert resolve_expr(flat, "parts") == "a\nb"

    def test_list_join_custom_sep(self):
        from eulerforge.utils.convert import resolve_expr

        flat = {"parts": ["a", "b"]}
        assert resolve_expr(flat, "parts", join_sep=" ") == "a b"

    def test_missing_raises(self):
        from eulerforge.utils.convert import resolve_expr

        flat = {"x": 1}
        with pytest.raises(KeyError):
            resolve_expr(flat, "nonexistent")


# =========================================================================
# J) build_converter_from_map
# =========================================================================
class TestBuildConverterFromMap:
    """build_converter_from_map() — --map OUT_KEY=EXPR converter builder."""

    def test_sft_flat(self):
        from eulerforge.utils.convert import build_converter_from_map

        conv = build_converter_from_map("sft", ["prompt=instruction", "response=output"])
        row = {"instruction": "What is 2+2?", "output": "4", "source": "test"}
        out = conv(row)
        assert out == {"prompt": "What is 2+2?", "response": "4"}

    def test_nested_dot_path_flat(self):
        from eulerforge.utils.convert import build_converter_from_map

        conv = build_converter_from_map(
            "prompted_preference",
            ["prompt=instruction.value", "chosen=chosen.value", "rejected=rejected.value"],
        )
        row = {
            "instruction": {"value": "Q?"},
            "chosen": {"value": "Good"},
            "rejected": {"value": "Bad"},
        }
        out = conv(row)
        assert out == {"prompt": "Q?", "chosen": "Good", "rejected": "Bad"}

    def test_dpo_three_keys(self):
        from eulerforge.utils.convert import build_converter_from_map

        conv = build_converter_from_map(
            "prompted_preference",
            ["prompt=p", "chosen=c", "rejected=r"],
        )
        out = conv({"p": "P", "c": "C", "r": "R"})
        assert out == {"prompt": "P", "chosen": "C", "rejected": "R"}

    def test_flatten_none_nested(self):
        from eulerforge.utils.convert import build_converter_from_map

        # flatten_mode="none": dot-path fallback via _resolve_dot_path
        conv = build_converter_from_map(
            "sft",
            ["prompt=instruction.value"],
            flatten_mode="none",
        )
        row = {"instruction": {"value": "Deep Q?"}}
        out = conv(row)
        assert out["prompt"] == "Deep Q?"

    def test_strict_rejects_none(self):
        from eulerforge.utils.convert import build_converter_from_map

        conv = build_converter_from_map("sft", ["prompt=x"], strict=True)
        row = {"x": None}
        with pytest.raises(ValueError, match="strict"):
            conv(row)

    def test_strict_rejects_empty_str(self):
        from eulerforge.utils.convert import build_converter_from_map

        conv = build_converter_from_map("sft", ["prompt=x"], strict=True)
        with pytest.raises(ValueError, match="strict"):
            conv({"x": ""})

    def test_strict_rejects_empty_list(self):
        from eulerforge.utils.convert import build_converter_from_map

        conv = build_converter_from_map("sft", ["prompt=x"], strict=True)
        with pytest.raises(ValueError, match="strict"):
            conv({"x": []})

    def test_malformed_map_raises(self):
        from eulerforge.utils.convert import build_converter_from_map

        with pytest.raises(ValueError, match="OUT_KEY=EXPR"):
            build_converter_from_map("sft", ["prompt_only_no_eq"])


# =========================================================================
# K) New recipes
# =========================================================================
class TestNewRecipes:
    """New built-in recipe functions and get_recipe extensions."""

    def test_sft_instruction_output_basic(self):
        from eulerforge.utils.convert import get_recipe

        fn, task = get_recipe("sft_instruction_output")
        assert task == "sft"
        row = {"instruction": "What is 2+2?", "output": "4"}
        out = fn(row)
        assert out == {"prompt": "What is 2+2?", "response": "4"}

    def test_sft_instruction_output_missing_output_raises(self):
        from eulerforge.utils.convert import get_recipe

        fn, _ = get_recipe("sft_instruction_output")
        with pytest.raises(KeyError):
            fn({"instruction": "Q?"})

    def test_dpo_nested_value_basic(self):
        from eulerforge.utils.convert import get_recipe

        fn, task = get_recipe("dpo_nested_value")
        assert task == "prompted_preference"
        row = {
            "instruction": {"value": "Q?"},
            "chosen": {"value": "Good"},
            "rejected": {"value": "Bad"},
        }
        out = fn(row)
        assert out == {"prompt": "Q?", "chosen": "Good", "rejected": "Bad"}

    def test_sft_messages_factory_via_get_recipe(self):
        from eulerforge.utils.convert import get_recipe

        fn, task = get_recipe("sft_messages", messages_expr="messages")
        assert task == "sft"
        assert callable(fn)
        row = {"messages": [
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": "Hello"},
        ]}
        out = fn(row)
        assert "Hi" in out["prompt"]
        assert out["response"] == "Hello"
