# tests/test_mixtral_fused_expert.py
# -*- coding: utf-8 -*-
"""
Mixtral fused expert (MixtralExperts) 지원 테스트.

transformers 최신 버전에서 Mixtral expert는 개별 모듈이 아닌
3D fused tensor (num_experts, intermediate, hidden)로 구현됨.
이 테스트는 fused expert를 개별 expert로 unfuse하여 LoRA 래핑이
가능한지 검증한다.
"""
from __future__ import annotations

import pytest
import torch
import torch.nn as nn


class TestFusedExpertUnfuse:
    """fused expert → 개별 expert 변환 테스트."""

    def test_unfuse_returns_correct_count(self):
        """8개 expert가 있는 fused module → 8개 _FusedExpertSlice."""
        from eulerforge.adapters.backbones.mixtral import _unfuse_mixtral_experts

        # fused expert mock
        fused = nn.Module()
        fused.gate_up_proj = nn.Parameter(torch.randn(8, 64, 16))
        fused.down_proj = nn.Parameter(torch.randn(8, 16, 32))

        slices = _unfuse_mixtral_experts(fused)
        assert len(slices) == 8

    def test_each_slice_has_linear(self):
        """각 slice에 gate_up_proj, down_proj Linear가 있어야 한다."""
        from eulerforge.adapters.backbones.mixtral import _unfuse_mixtral_experts

        fused = nn.Module()
        fused.gate_up_proj = nn.Parameter(torch.randn(4, 32, 8))
        fused.down_proj = nn.Parameter(torch.randn(4, 8, 16))

        slices = _unfuse_mixtral_experts(fused)
        for s in slices:
            assert hasattr(s, "gate_up_proj")
            assert hasattr(s, "down_proj")
            assert isinstance(s.gate_up_proj, nn.Linear)
            assert isinstance(s.down_proj, nn.Linear)

    def test_slice_shapes_correct(self):
        """slice의 Linear 가중치 shape이 올바른지."""
        from eulerforge.adapters.backbones.mixtral import _unfuse_mixtral_experts

        fused = nn.Module()
        fused.gate_up_proj = nn.Parameter(torch.randn(4, 64, 16))  # (experts, out, in)
        fused.down_proj = nn.Parameter(torch.randn(4, 16, 32))

        slices = _unfuse_mixtral_experts(fused)
        # Linear.weight shape = (out_features, in_features)
        assert slices[0].gate_up_proj.weight.shape == (64, 16)
        assert slices[0].down_proj.weight.shape == (16, 32)

    def test_non_fused_returns_empty(self):
        """3D Parameter가 없으면 빈 ��스트."""
        from eulerforge.adapters.backbones.mixtral import _unfuse_mixtral_experts

        regular = nn.Module()
        regular.weight = nn.Parameter(torch.randn(16, 8))  # 2D → fused가 아님

        slices = _unfuse_mixtral_experts(regular)
        assert slices == []


class TestMixtralAdapterFusedExperts:
    """MixtralAdapter가 fused expert를 감���하는지 테스트."""

    def test_find_expert_groups_fused(self):
        """fused MixtralExperts에서 ExpertGroup이 반환되어야 한다."""
        from eulerforge.adapters.backbones.mixtral import MixtralAdapter

        adapter = MixtralAdapter()

        # fused MoE block mock
        block = nn.Module()
        block.self_attn = nn.Module()
        block.self_attn.q_proj = nn.Linear(8, 8)

        block.mlp = nn.Module()
        block.mlp.gate = nn.Linear(8, 4)  # router
        block.mlp.experts = nn.Module()
        block.mlp.experts.gate_up_proj = nn.Parameter(torch.randn(4, 32, 8))
        block.mlp.experts.down_proj = nn.Parameter(torch.randn(4, 8, 16))

        groups = adapter.find_native_expert_groups(block)
        assert len(groups) >= 1
        g = groups[0]
        assert len(g.experts) == 4
        assert g.router is not None

    def test_lora_wrapping_works_on_slices(self):
        """unfused expert slice에 LoRA가 적용 가능한지."""
        from eulerforge.adapters.backbones.mixtral import _unfuse_mixtral_experts
        from eulerforge.injection.native_moe_expert_lora import inject_lora_by_keywords_inplace

        fused = nn.Module()
        fused.gate_up_proj = nn.Parameter(torch.randn(2, 16, 8))
        fused.down_proj = nn.Parameter(torch.randn(2, 8, 16))

        slices = _unfuse_mixtral_experts(fused)
        assert len(slices) == 2

        # LoRA 래핑
        wrapped = inject_lora_by_keywords_inplace(
            slices[0],
            target_keywords=["gate_up_proj", "down_proj"],
            r=4,
            alpha=8,
            dropout=0.0,
        )
        assert wrapped > 0, "At least one Linear should be LoRA-wrapped"

        # LoRALinear인지 확인
        from eulerforge.modules.lora import LoRALinear
        assert isinstance(slices[0].gate_up_proj, LoRALinear)


class TestPresetValidation:
    """updated preset이 validate-only를 통과하는지."""

    def test_mixtral_preset_validates(self):
        """yujiepan/mixtral-8xtiny-random 프리셋 검증 통과."""
        from eulerforge.cli.train import main as train_main

        try:
            train_main(argv=[
                "--preset", "configs/presets/mixtral_native_expert_lora_sft.yml",
                "--validate-only",
            ])
        except SystemExit as e:
            assert e.code == 0 or e.code is None
