import pytest
import torch
import torch.nn as nn
from eulerforge.cli.train import _select_backbone_adapter, _apply_injection
from eulerforge.phase_schedules import build_phase_schedule, _derive_injection_layer_indices

# ---------------------------------------------------------------------------
# Helper: parameter status verification
# ---------------------------------------------------------------------------
def check_param_status(model, scope_name, expected_trainable: bool, description: str = ""):
    found_params = []
    failed_params = []

    for n, p in model.named_parameters():
        if scope_name in n:
            found_params.append(n)
            if p.requires_grad != expected_trainable:
                failed_params.append(n)

    if not found_params:
        print(f"    [Warn] Target params not found: '{scope_name}' ({description})")
        return False

    if failed_params:
        print(f"    [Fail] {description} - Expected {expected_trainable}, but got {not expected_trainable}")
        print(f"           Sample failures: {failed_params[:3]}")
        return False

    return True


# ---------------------------------------------------------------------------
# Test Cases Matrix (all declarative phases, no legacy macros)
# ---------------------------------------------------------------------------
EXTENDED_TEST_CASES = [
    # 1. Plain LoRA (Qwen) - single phase: lora + attn_lora
    dict(
        id="qwen_plain",
        model_type="qwen",
        strategy="dense_lora",
        phases=[
            {"step": 0, "trainable": ["lora", "attn_lora"]},
        ],
        check_phases=["phase0", "phase0_again"],
        lora_r=16, attn_lora=True,
        checks={
            "phase0": {"ffn_lora": True, "attn_lora": True, "base": False},
            "phase0_again": {"ffn_lora": True, "attn_lora": True, "base": False},
        }
    ),

    # 2. LoRA MoE (Llama) - two phases: router -> lora + attn_lora
    dict(
        id="llama_mixture_lora",
        model_type="llama3",
        strategy="mixture_lora",
        phases=[
            {"step": 0, "trainable": ["router"]},
            {"step": 5, "trainable": ["lora", "attn_lora"]},
        ],
        check_phases=["phase0", "phase1"],
        lora_r=16, num_experts=4, top_k=2, attn_lora=True,
        checks={
            "phase0": {"router": True, "ffn_lora": False, "base": False},
            "phase1": {"router": False, "ffn_lora": True, "base": False},
        }
    ),

    # 3. FFN MoE (Qwen) - three phases: router -> lora+attn_lora -> all+base_ffn
    dict(
        id="qwen_ffn_moe_default",
        model_type="qwen",
        strategy="moe_expert_lora",
        phases=[
            {"step": 0, "trainable": ["router"]},
            {"step": 5, "trainable": ["lora", "attn_lora"]},
            {"step": 100, "trainable": ["lora", "attn_lora", "router", "base_ffn"],
             "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"]},
        ],
        check_phases=["phase0", "phase1", "phase2"],
        lora_r=16, num_experts=4, top_k=2, attn_lora=True,
        checks={
            "phase0": {"router": True, "ffn_lora": False, "attn_lora": False, "base": False},
            "phase1": {"router": False, "ffn_lora": True, "attn_lora": True, "base": False},
            "phase2": {"base_unfreeze": True}
        }
    ),

    # 4. FFN MoE (Llama) - single phase: router + lora + attn_lora
    dict(
        id="llama_ffn_moe_custom",
        model_type="llama2",
        strategy="moe_expert_lora",
        phases=[
            {"step": 0, "trainable": ["router", "lora", "attn_lora"]},
        ],
        check_phases=["phase0"],
        lora_r=16, num_experts=4, top_k=2, attn_lora=True,
        checks={
            "phase0": {"router": True, "ffn_lora": True, "attn_lora": True, "base": False}
        }
    ),

    # 5. FFN MoE (Gemma 3) - three phases: router -> lora+attn_lora -> all+base_ffn
    dict(
        id="gemma3_ffn_moe",
        model_type="gemma3_1b",
        strategy="moe_expert_lora",
        phases=[
            {"step": 0, "trainable": ["router"]},
            {"step": 5, "trainable": ["lora", "attn_lora"]},
            {"step": 100, "trainable": ["lora", "attn_lora", "router", "base_ffn"],
             "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"]},
        ],
        check_phases=["phase0", "phase1", "phase2"],
        lora_r=16, num_experts=4, top_k=2, attn_lora=True,
        checks={
            "phase0": {"router": True, "ffn_lora": False, "attn_lora": False, "base": False},
            "phase1": {"router": False, "ffn_lora": True, "attn_lora": True, "base": False},
            "phase2": {"base_unfreeze": True}
        }
    ),

    # 6. Native MoE (Mixtral) - single phase: lora + attn_lora
    # NOTE: tiny-mixtral은 fused expert weights(3D Parameter)를 사용하므로
    # per-expert w1/w2/w3 nn.Linear가 없어 ffn_lora 인젝션이 불가능합니다.
    # 실제 Mixtral-7B에서는 per-expert Linear가 있어 정상 동작합니다.
    # 여기서는 attn_lora만 검증합니다.
    dict(
        id="mixtral_native",
        model_type="mixtral",
        strategy="native_moe_expert_lora",
        phases=[
            {"step": 0, "trainable": ["lora", "attn_lora"]},
        ],
        check_phases=["phase0"],
        lora_r=16, attn_lora=True,
        injection_extra={"target_keywords": ["w1", "w2", "w3"]},
        checks={
            "phase0": {"attn_lora": True, "base": False}
        }
    )
]

@pytest.mark.parametrize("case", EXTENDED_TEST_CASES, ids=lambda x: x["id"])
def test_phase_transitions_extended(case, real_model_factory):
    print(f"\n>>> [Extended Test] {case['id']} ({case['model_type']} + {case['strategy']})")

    # 1. Model Load
    model, _ = real_model_factory(case['model_type'])

    # Adapter selection
    if "qwen" in case['model_type']:
        adapter_key = "qwen3"
    elif "gemma3" in case['model_type']:
        adapter_key = "gemma3"
    elif "mixtral" in case['model_type']:
        adapter_key = "mixtral"
    else:
        adapter_key = "llama"
    adapter = _select_backbone_adapter(adapter_key)

    # 2. Injection Config
    inj_cfg = {
        "strategy": case["strategy"],
        "lora_r": case.get("lora_r", 16),
        "lora_alpha": 32,
        "lora_dropout": 0.05,
        "num_experts": case.get("num_experts", 4),
        "top_k": case.get("top_k", 2),
        "start_layer": 0,
        "num_layers": 0,
        "target_keywords": ["gate_proj", "up_proj", "down_proj", "w1", "w2"],
        "attn_lora": {
            "enabled": case.get("attn_lora", False),
            "keywords": ["q_proj", "v_proj"]
        }
    }
    if "injection_extra" in case:
        inj_cfg.update(case["injection_extra"])

    if case["strategy"] == "moe_expert_lora":
        inj_cfg["moe_start_layer"] = 0
        inj_cfg["moe_num_layers"] = 0

    try:
        _apply_injection(model, adapter, inj_cfg, verbose=False)
    except Exception as e:
        pytest.fail(f"Injection failed: {e}")

    # 3. Build scheduler via declarative phases
    cfg = {"training": {"phases": case["phases"]}}
    scheduler = build_phase_schedule(cfg)
    assert scheduler is not None

    # LoRA scope name
    lora_scope = "loraA" if case["strategy"] == "mixture_lora" else "lora_A"

    for phase_key in case["check_phases"]:
        expectations = case["checks"].get(phase_key, {})
        print(f"    [Check] {phase_key} ... Expects: {expectations}")

        # Map phase keys to steps
        if phase_key == "phase0":
            scheduler.maybe_step(model, 0)
        elif phase_key == "phase0_again":
            # Re-apply same phase
            scheduler.apply_phase(model, 0)
        elif phase_key == "phase1":
            scheduler.maybe_step(model, 5)
        elif phase_key == "phase2":
            step = case["phases"][2]["step"] if len(case["phases"]) > 2 else 100
            scheduler.maybe_step(model, step)

        # Verification
        if "router" in expectations:
            assert check_param_status(model, "router", expectations["router"], "Router"), \
                f"{phase_key} Router check failed"

        if "ffn_lora" in expectations:
            target_ffn_key = "w1" if "mixtral" in case["model_type"] else "gate_proj"
            ffn_lora_trainable = expectations["ffn_lora"]

            found_any = False
            for n, p in model.named_parameters():
                if target_ffn_key in n and lora_scope in n:
                    found_any = True
                    assert p.requires_grad == ffn_lora_trainable, \
                        f"{phase_key} FFN LoRA ({n}) expected {ffn_lora_trainable}, got {p.requires_grad}"

            if not found_any and ffn_lora_trainable:
                pytest.fail(f"{phase_key} FFN LoRA params not found (keyword: {target_ffn_key})")

        if "attn_lora" in expectations:
            attn_lora_trainable = expectations["attn_lora"]
            found_any = False
            for n, p in model.named_parameters():
                if "q_proj" in n and "lora_A" in n:
                    found_any = True
                    assert p.requires_grad == attn_lora_trainable, \
                        f"{phase_key} Attn LoRA ({n}) expected {attn_lora_trainable}, got {p.requires_grad}"

            if not found_any and attn_lora_trainable:
                print(f"    [Warn] Attn LoRA params not found for {phase_key}.")
                pytest.fail(f"{phase_key} Attn LoRA params not found.")

        if "base_unfreeze" in expectations and expectations["base_unfreeze"]:
            base_unfrozen_count = 0
            target_ffn_key = "w1" if "mixtral" in case["model_type"] else "gate_proj"

            for n, p in model.named_parameters():
                if target_ffn_key in n and "lora" not in n and "router" not in n:
                    if p.requires_grad:
                        base_unfrozen_count += 1

            assert base_unfrozen_count > 0, f"{phase_key} Base FFN weights should be unfrozen"

        if "base" in expectations and expectations["base"] is False:
            target_ffn_key = "w1" if "mixtral" in case["model_type"] else "gate_proj"
            for n, p in model.named_parameters():
                if target_ffn_key in n and "lora" not in n and "router" not in n:
                    assert not p.requires_grad, f"{phase_key} Base param {n} should be frozen"

    print(f"    [OK] All phase checks passed for {case['id']}.")


# ---------------------------------------------------------------------------
# Tests: _derive_injection_layer_indices
# ---------------------------------------------------------------------------
class TestDeriveInjectionLayerIndices:
    """injection config에서 target layer indices 추출 테스트."""

    def test_start_layer_and_num_layers(self):
        """start_layer=32, num_layers=2 → [32, 33]."""
        cfg = {"injection": {"start_layer": 32, "num_layers": 2}}
        assert _derive_injection_layer_indices(cfg) == [32, 33]

    def test_start_layer_only_no_num_layers(self):
        """num_layers 미지정 → None (전체 레이어, 스코핑 불필요)."""
        cfg = {"injection": {"start_layer": 10}}
        assert _derive_injection_layer_indices(cfg) is None

    def test_num_layers_zero(self):
        """num_layers=0 → None."""
        cfg = {"injection": {"start_layer": 5, "num_layers": 0}}
        assert _derive_injection_layer_indices(cfg) is None

    def test_explicit_layer_indices(self):
        """명시적 layer_indices → 그대로 반환."""
        cfg = {"injection": {"layer_indices": [3, 7, 11]}}
        assert _derive_injection_layer_indices(cfg) == [3, 7, 11]

    def test_no_injection_config(self):
        """injection 없음 → None."""
        cfg = {}
        assert _derive_injection_layer_indices(cfg) is None

    def test_default_start_layer(self):
        """start_layer 미지정 (기본 0), num_layers=3 → [0, 1, 2]."""
        cfg = {"injection": {"num_layers": 3}}
        assert _derive_injection_layer_indices(cfg) == [0, 1, 2]


# ---------------------------------------------------------------------------
# Tests: base_ffn target_layers auto-scoping
# ---------------------------------------------------------------------------
class TestBaseFFNAutoScoping:
    """base_ffn 그룹의 target_layers 자동 스코핑 테스트."""

    def test_auto_derive_when_base_ffn_active(self):
        """base_ffn 활성 + target_layers 미지정 → injection에서 자동 추출."""
        cfg = {
            "injection": {"start_layer": 32, "num_layers": 2},
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["router"]},
                    {"step": 100, "trainable": ["lora", "attn_lora", "router", "base_ffn"]},
                ],
                "phase_target_kwargs": {
                    "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"],
                },
            },
        }
        sched = build_phase_schedule(cfg)
        assert sched is not None
        # Phase 0: no base_ffn → target_layers should be None
        assert sched.phases[0].target_layers is None
        # Phase 1: base_ffn → target_layers auto-derived as [32, 33]
        assert sched.phases[1].target_layers == [32, 33]

    def test_explicit_target_layers_not_overridden(self):
        """명시적 target_layers → injection에서 자동 추출하지 않음."""
        cfg = {
            "injection": {"start_layer": 32, "num_layers": 2},
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["lora", "base_ffn"]},
                ],
                "phase_target_kwargs": {
                    "base_ffn_keywords": ["gate_proj"],
                    "target_layers": [10, 11, 12],
                },
            },
        }
        sched = build_phase_schedule(cfg)
        # 명시적 값 유지
        assert sched.phases[0].target_layers == [10, 11, 12]

    def test_no_auto_derive_when_no_base_ffn(self):
        """base_ffn 없는 phase → target_layers 자동 추출 안 함."""
        cfg = {
            "injection": {"start_layer": 32, "num_layers": 2},
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["router"]},
                    {"step": 100, "trainable": ["lora", "attn_lora"]},
                ],
            },
        }
        sched = build_phase_schedule(cfg)
        assert sched.phases[0].target_layers is None
        assert sched.phases[1].target_layers is None

    def test_layer_indices_from_injection_result(self):
        """injection.layer_indices가 명시되면 base_ffn target_layers로 사용.

        num_layers=0 + start_layer>0일 때, train.py main()이 실제 injection 결과의
        target_layer_indices를 cfg["injection"]["layer_indices"]에 기록한다.
        이 경우 _derive_injection_layer_indices가 layer_indices를 반환해야 한다.

        모든 injection strategy (dense_lora, moe_expert_lora, native_moe_expert_lora)에서
        동일한 메커니즘이 적용된다.
        """
        cfg = {
            "injection": {
                "start_layer": 38,
                "num_layers": 0,  # "from start to end"
                "layer_indices": [38, 39, 40, 41],  # injection 결과에서 주입
            },
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["router"]},
                    {"step": 100, "trainable": ["lora", "attn_lora", "router", "base_ffn"],
                     "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"]},
                ],
            },
        }
        sched = build_phase_schedule(cfg)
        assert sched is not None
        # Phase 0: no base_ffn → target_layers None
        assert sched.phases[0].target_layers is None
        # Phase 1: base_ffn → layer_indices [38,39,40,41] 사용
        assert sched.phases[1].target_layers == [38, 39, 40, 41]

    def test_layer_indices_priority_over_start_num(self):
        """layer_indices가 start_layer/num_layers보다 우선한다."""
        from eulerforge.phase_schedules import _derive_injection_layer_indices

        cfg = {
            "injection": {
                "start_layer": 0,
                "num_layers": 2,
                "layer_indices": [10, 11, 12],
            }
        }
        result = _derive_injection_layer_indices(cfg)
        assert result == [10, 11, 12]

    def test_without_layer_indices_num_layers_zero_returns_none(self):
        """layer_indices 없고 num_layers=0 → None (전체).

        train.py main()이 injection 결과를 layer_indices에 기록하지 않은 경우
        fallback으로 None이 반환된다.
        """
        from eulerforge.phase_schedules import _derive_injection_layer_indices

        cfg = {"injection": {"start_layer": 38, "num_layers": 0}}
        result = _derive_injection_layer_indices(cfg)
        assert result is None

    def test_dense_lora_start_layer_with_layer_indices(self):
        """dense_lora: start_layer=20, num_layers=0 + layer_indices → base_ffn 스코핑."""
        cfg = {
            "injection": {
                "strategy": "dense_lora",
                "start_layer": 20,
                "num_layers": 0,
                "layer_indices": [20, 21, 22, 23],
            },
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["lora", "base_ffn"],
                     "base_ffn_keywords": ["gate_proj"]},
                ],
            },
        }
        sched = build_phase_schedule(cfg)
        assert sched.phases[0].target_layers == [20, 21, 22, 23]

    def test_native_moe_expert_lora_start_layer_with_layer_indices(self):
        """native_moe_expert_lora도 동일하게 layer_indices로 스코핑."""
        cfg = {
            "injection": {
                "strategy": "native_moe_expert_lora",
                "start_layer": 10,
                "num_layers": 0,
                "layer_indices": [10, 11, 12, 13, 14, 15],
            },
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["lora", "attn_lora"]},
                    {"step": 100, "trainable": ["lora", "base_ffn"],
                     "base_ffn_keywords": ["gate_proj"]},
                ],
            },
        }
        sched = build_phase_schedule(cfg)
        assert sched.phases[0].target_layers is None  # no base_ffn
        assert sched.phases[1].target_layers == [10, 11, 12, 13, 14, 15]

    def test_no_auto_derive_when_num_layers_not_specified(self):
        """injection에 num_layers 미지정 → 전체 레이어 사용이므로 auto-derive 안 함."""
        cfg = {
            "injection": {"start_layer": 10},
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["lora", "base_ffn"]},
                ],
                "phase_target_kwargs": {
                    "base_ffn_keywords": ["gate_proj"],
                },
            },
        }
        sched = build_phase_schedule(cfg)
        assert sched.phases[0].target_layers is None

    def test_per_phase_target_layers_override(self):
        """per-phase target_layers가 injection보다 우선."""
        cfg = {
            "injection": {"start_layer": 32, "num_layers": 2},
            "training": {
                "phases": [
                    {"step": 0, "trainable": ["lora", "base_ffn"],
                     "target_layers": [5, 6]},
                ],
                "phase_target_kwargs": {
                    "base_ffn_keywords": ["gate_proj"],
                },
            },
        }
        sched = build_phase_schedule(cfg)
        assert sched.phases[0].target_layers == [5, 6]
