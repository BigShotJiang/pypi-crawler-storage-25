# tests/test_pipeline_checkpoint_loading.py
# -*- coding: utf-8 -*-
"""
파이프라인 체크포인트 로딩 테스트.

SFT → DPO 등 연속 훈련에서 eulerforge 체크포인트를 모델로 지정했을 때,
base 모델을 올바르게 해석하고 LoRA 어댑터 가중치를 로드하는지 검증.
"""
import json
import os
import tempfile

import pytest


# =========================================================================
# _detect_eulerforge_checkpoint() 탐지 테스트
# =========================================================================
class TestDetectEulerforgeCheckpoint:
    """model_name이 eulerforge LoRA 체크포인트인지 탐지."""

    def test_returns_none_for_hub_model_name(self):
        """HuggingFace 모델 이름(디렉토리가 아님)은 None 반환."""
        from eulerforge.cli.train import _detect_eulerforge_checkpoint
        result = _detect_eulerforge_checkpoint("Qwen/Qwen3.5-0.8B-Base")
        assert result is None

    def test_returns_none_for_plain_hf_dir(self, tmp_path):
        """lora_info.json 없는 일반 HF 디렉토리는 None 반환."""
        from eulerforge.cli.train import _detect_eulerforge_checkpoint
        (tmp_path / "config.json").write_text("{}")
        result = _detect_eulerforge_checkpoint(str(tmp_path))
        assert result is None

    def test_detects_lora_checkpoint_with_resolved_in_parent(self, tmp_path):
        """lora_info.json + 부모 resolved_config.json → base_model_name 반환."""
        from eulerforge.cli.train import _detect_eulerforge_checkpoint

        # 구조: run_dir/resolved_config.json, run_dir/final/lora_info.json
        run_dir = tmp_path / "sft_run"
        final_dir = run_dir / "final"
        final_dir.mkdir(parents=True)

        resolved = {
            "model_name": "Qwen/Qwen3.5-0.8B-Base",
            "backbone": "qwen3",
            "injection": {"strategy": "dense_lora", "lora_r": 48, "lora_alpha": 96},
        }
        (run_dir / "resolved_config.json").write_text(json.dumps(resolved))
        (final_dir / "lora_info.json").write_text(
            json.dumps({"lora_r": 48, "lora_alpha": 96.0, "strategy": "dense_lora"})
        )
        (final_dir / "config.json").write_text("{}")

        result = _detect_eulerforge_checkpoint(str(final_dir))
        assert result is not None
        assert result["base_model_name"] == "Qwen/Qwen3.5-0.8B-Base"
        assert result["checkpoint_dir"] == str(final_dir)
        assert result["strategy"] == "dense_lora"

    def test_detects_checkpoint_with_resolved_in_same_dir(self, tmp_path):
        """resolved_config.json이 같은 디렉토리에 있는 경우도 지원."""
        from eulerforge.cli.train import _detect_eulerforge_checkpoint

        # run_dir 자체가 체크포인트인 경우
        (tmp_path / "lora_info.json").write_text(
            json.dumps({"lora_r": 48, "lora_alpha": 96.0, "strategy": "dense_lora"})
        )
        (tmp_path / "resolved_config.json").write_text(
            json.dumps({"model_name": "meta-llama/Llama-3-8B"})
        )
        (tmp_path / "config.json").write_text("{}")

        result = _detect_eulerforge_checkpoint(str(tmp_path))
        assert result is not None
        assert result["base_model_name"] == "meta-llama/Llama-3-8B"

    def test_returns_none_when_no_resolved_config(self, tmp_path):
        """lora_info.json 있지만 resolved_config.json 없으면 None (fallback 불가)."""
        from eulerforge.cli.train import _detect_eulerforge_checkpoint

        (tmp_path / "lora_info.json").write_text(
            json.dumps({"lora_r": 48, "lora_alpha": 96.0, "strategy": "dense_lora"})
        )
        (tmp_path / "config.json").write_text("{}")

        result = _detect_eulerforge_checkpoint(str(tmp_path))
        assert result is None

    def test_returns_adapter_state_path_when_exists(self, tmp_path):
        """model.safetensors가 있으면 checkpoint_dir에 포함."""
        from eulerforge.cli.train import _detect_eulerforge_checkpoint

        run_dir = tmp_path / "sft_run"
        final_dir = run_dir / "final"
        final_dir.mkdir(parents=True)

        resolved = {"model_name": "Qwen/Qwen3.5-0.8B-Base"}
        (run_dir / "resolved_config.json").write_text(json.dumps(resolved))
        (final_dir / "lora_info.json").write_text(
            json.dumps({"lora_r": 48, "lora_alpha": 96.0, "strategy": "dense_lora"})
        )
        (final_dir / "config.json").write_text("{}")
        (final_dir / "model.safetensors").write_bytes(b"fake")

        result = _detect_eulerforge_checkpoint(str(final_dir))
        assert result is not None
        assert result["checkpoint_dir"] == str(final_dir)


# =========================================================================
# _load_lora_adapter_weights() 테스트
# =========================================================================
class TestLoadLoraAdapterWeights:
    """LoRA 어댑터 가중치 로딩 테스트."""

    def test_loads_matching_lora_keys(self, tmp_path):
        """체크포인트의 LoRA 키가 모델의 LoRA 키에 로드됨."""
        import torch
        from eulerforge.cli.train import _load_lora_adapter_weights

        # 간단한 모델 시뮬레이션: lora_A, lora_B 키가 있는 state_dict
        model_sd = {
            "layer.0.mlp.gate_proj.lora_A": torch.zeros(4, 8),
            "layer.0.mlp.gate_proj.lora_B": torch.zeros(8, 4),
            "layer.0.mlp.gate_proj.base_layer.weight": torch.ones(8, 8),
        }
        # 체크포인트에서 LoRA 가중치만 추출
        ckpt_sd = {
            "layer.0.mlp.gate_proj.lora_A": torch.randn(4, 8),
            "layer.0.mlp.gate_proj.lora_B": torch.randn(8, 4),
            "layer.0.mlp.gate_proj.base_layer.weight": torch.ones(8, 8),
        }

        # 모델 mock
        class FakeModel:
            def state_dict(self):
                return model_sd

            def load_state_dict(self, sd, strict=False):
                self._loaded = sd
                return type('Result', (), {'missing_keys': [], 'unexpected_keys': []})()

        model = FakeModel()
        loaded_count = _load_lora_adapter_weights(model, ckpt_sd)
        assert loaded_count > 0

    def test_skips_non_lora_keys(self, tmp_path):
        """base_layer.weight 등 non-LoRA 키는 건너뜀."""
        import torch
        from eulerforge.cli.train import _load_lora_adapter_weights

        ckpt_sd = {
            "layer.0.weight": torch.randn(8, 8),
        }

        class FakeModel:
            def state_dict(self):
                return {"layer.0.weight": torch.zeros(8, 8)}

            def load_state_dict(self, sd, strict=False):
                self._loaded = sd
                return type('Result', (), {'missing_keys': [], 'unexpected_keys': []})()

        model = FakeModel()
        loaded_count = _load_lora_adapter_weights(model, ckpt_sd)
        assert loaded_count == 0

    def test_prefix_mismatch_auto_mapping(self):
        """체크포인트 키 prefix가 다를 때 (language_model) 자동 매핑."""
        import torch
        from eulerforge.cli.train import _load_lora_adapter_weights

        # 모델: model.layers.0.mlp.gate_proj.lora_A (base 모델 + injection)
        model_sd = {
            "model.layers.0.mlp.gate_proj.lora_A": torch.zeros(4, 8),
            "model.layers.0.mlp.gate_proj.lora_B": torch.zeros(8, 4),
            "model.layers.0.mlp.gate_proj.base_layer.weight": torch.ones(8, 8),
        }
        # 체크포인트: model.language_model.layers.0.mlp.gate_proj.lora_A (SFT 저장)
        ckpt_sd = {
            "model.language_model.layers.0.mlp.gate_proj.lora_A": torch.randn(4, 8),
            "model.language_model.layers.0.mlp.gate_proj.lora_B": torch.randn(8, 4),
            "model.language_model.layers.0.mlp.gate_proj.base_layer.weight": torch.ones(8, 8),
        }

        class FakeModel:
            def state_dict(self):
                return model_sd

            def load_state_dict(self, sd, strict=False):
                self._loaded = sd
                return type('Result', (), {'missing_keys': [], 'unexpected_keys': []})()

        model = FakeModel()
        loaded_count = _load_lora_adapter_weights(model, ckpt_sd)
        assert loaded_count == 2  # lora_A + lora_B (not base_layer.weight)

    def test_prefix_mapping_multiple_layers(self):
        """여러 레이어에 걸친 prefix 매핑 검증."""
        import torch
        from eulerforge.cli.train import _load_lora_adapter_weights

        model_sd = {
            "model.layers.0.mlp.gate_proj.lora_A": torch.zeros(4, 8),
            "model.layers.0.mlp.gate_proj.lora_B": torch.zeros(8, 4),
            "model.layers.5.self_attn.q_proj.lora_A": torch.zeros(4, 8),
            "model.layers.5.self_attn.q_proj.lora_B": torch.zeros(8, 4),
        }
        ckpt_sd = {
            "model.language_model.layers.0.mlp.gate_proj.lora_A": torch.randn(4, 8),
            "model.language_model.layers.0.mlp.gate_proj.lora_B": torch.randn(8, 4),
            "model.language_model.layers.5.self_attn.q_proj.lora_A": torch.randn(4, 8),
            "model.language_model.layers.5.self_attn.q_proj.lora_B": torch.randn(8, 4),
        }

        class FakeModel:
            def state_dict(self):
                return model_sd

            def load_state_dict(self, sd, strict=False):
                self._loaded = sd
                return type('Result', (), {'missing_keys': [], 'unexpected_keys': []})()

        model = FakeModel()
        loaded_count = _load_lora_adapter_weights(model, ckpt_sd)
        assert loaded_count == 4


# =========================================================================
# 통합: 파이프라인 체크포인트 경로가 올바르게 base 모델로 해석됨
# =========================================================================
class TestPipelineCheckpointResolution:
    """파이프라인 연속 훈련에서 체크포인트 경로 해석 통합 테스트."""

    def test_dpo_preset_with_sft_checkpoint_resolves_base_model(self, tmp_path):
        """DPO preset에서 model_name이 SFT 체크포인트 → base model 해석됨."""
        from eulerforge.cli.train import _detect_eulerforge_checkpoint

        sft_dir = tmp_path / "sft"
        final_dir = sft_dir / "final"
        final_dir.mkdir(parents=True)

        resolved = {
            "model_name": "Qwen/Qwen3.5-0.8B-Base",
            "backbone": "qwen3",
            "injection": {
                "strategy": "dense_lora",
                "lora_r": 48,
                "lora_alpha": 96.0,
                "target_keywords": ["gate_proj", "up_proj", "down_proj"],
            },
        }
        (sft_dir / "resolved_config.json").write_text(json.dumps(resolved))
        (final_dir / "lora_info.json").write_text(
            json.dumps({"lora_r": 48, "lora_alpha": 96.0, "strategy": "dense_lora"})
        )
        (final_dir / "config.json").write_text("{}")
        (final_dir / "model.safetensors").write_bytes(b"fake")

        # 유저가 --set model_name=./outputs/pipeline/dense_lora/sft/final 로 지정
        result = _detect_eulerforge_checkpoint(str(final_dir))
        assert result is not None
        assert result["base_model_name"] == "Qwen/Qwen3.5-0.8B-Base"
        # 훈련 코드는 이 base_model_name으로 모델을 로드해야 함

    def test_checkpoint_injection_overrides_current_config(self, tmp_path):
        """SFT checkpoint (lora_r=48) → DPO config (lora_r=24) 파이프라인에서
        injection 설정이 checkpoint resolved_config에서 자동 override되어야 한다.

        이 테스트는 _override_injection_from_checkpoint() 헬퍼가
        checkpoint의 injection params를 현재 config에 병합하는지 검증한다.
        """
        from eulerforge.cli.train import _override_injection_from_checkpoint

        # 현재 DPO config (lora_r=24)
        current_cfg = {
            "injection": {
                "strategy": "dense_lora",
                "lora_r": 24,
                "lora_alpha": 48,
                "lora_dropout": 0.05,
                "target_keywords": ["up_proj", "down_proj"],
                "start_layer": 18,
                "num_layers": 6,
                "attn_lora": {"enabled": True, "keywords": ["q_proj", "v_proj"]},
            }
        }

        # SFT checkpoint resolved_config (lora_r=48)
        ckpt_info = {
            "resolved_config": {
                "injection": {
                    "strategy": "dense_lora",
                    "lora_r": 48,
                    "lora_alpha": 96,
                    "lora_dropout": 0.05,
                    "target_keywords": ["gate_proj", "up_proj", "down_proj"],
                    "start_layer": 12,
                    "num_layers": 12,
                    "attn_lora": {"enabled": True, "keywords": ["q_proj", "v_proj"]},
                }
            }
        }

        _override_injection_from_checkpoint(current_cfg, ckpt_info)

        inj = current_cfg["injection"]
        # injection params는 checkpoint에서 가져와야 함
        assert inj["lora_r"] == 48
        assert inj["lora_alpha"] == 96
        assert inj["target_keywords"] == ["gate_proj", "up_proj", "down_proj"]
        assert inj["start_layer"] == 12
        assert inj["num_layers"] == 12

    def test_checkpoint_injection_override_preserves_training_type(self, tmp_path):
        """override 후에도 training.type (dpo)은 변경되지 않아야 한다."""
        from eulerforge.cli.train import _override_injection_from_checkpoint

        current_cfg = {
            "injection": {
                "strategy": "dense_lora",
                "lora_r": 24,
                "lora_alpha": 48,
            },
            "training": {"type": "dpo", "dpo_beta": 0.1},
        }

        ckpt_info = {
            "resolved_config": {
                "injection": {
                    "strategy": "dense_lora",
                    "lora_r": 48,
                    "lora_alpha": 96,
                },
                "training": {"type": "sft"},
            }
        }

        _override_injection_from_checkpoint(current_cfg, ckpt_info)

        # injection은 override
        assert current_cfg["injection"]["lora_r"] == 48
        # training은 그대로 (DPO 유지)
        assert current_cfg["training"]["type"] == "dpo"
        assert current_cfg["training"]["dpo_beta"] == 0.1

    def test_checkpoint_injection_override_no_resolved_config(self, tmp_path):
        """resolved_config에 injection이 없으면 현재 config 유지."""
        from eulerforge.cli.train import _override_injection_from_checkpoint

        current_cfg = {
            "injection": {"strategy": "dense_lora", "lora_r": 24, "lora_alpha": 48}
        }
        ckpt_info = {"resolved_config": {"model_name": "some/model"}}

        _override_injection_from_checkpoint(current_cfg, ckpt_info)
        assert current_cfg["injection"]["lora_r"] == 24  # 변경 없음

    def test_checkpoint_injection_override_logs_warning(self, tmp_path, caplog):
        """lora_r이 다를 때 경고 로그가 출력되어야 한다."""
        import logging
        from eulerforge.cli.train import _override_injection_from_checkpoint

        current_cfg = {
            "injection": {"strategy": "dense_lora", "lora_r": 24, "lora_alpha": 48}
        }
        ckpt_info = {
            "resolved_config": {
                "injection": {"strategy": "dense_lora", "lora_r": 48, "lora_alpha": 96}
            }
        }

        with caplog.at_level(logging.WARNING):
            _override_injection_from_checkpoint(current_cfg, ckpt_info)

        assert any("lora_r" in msg.lower() or "override" in msg.lower()
                    for msg in caplog.messages)

    def test_moe_expert_lora_checkpoint_detected(self, tmp_path):
        """moe_expert_lora 전략 체크포인트도 올바르게 탐지."""
        from eulerforge.cli.train import _detect_eulerforge_checkpoint

        run_dir = tmp_path / "moe_sft"
        final_dir = run_dir / "final"
        final_dir.mkdir(parents=True)

        resolved = {
            "model_name": "Qwen/Qwen3.5-0.8B-Base",
            "injection": {"strategy": "moe_expert_lora", "lora_r": 16, "lora_alpha": 32},
        }
        (run_dir / "resolved_config.json").write_text(json.dumps(resolved))
        (final_dir / "lora_info.json").write_text(
            json.dumps({"lora_r": 16, "lora_alpha": 32.0, "strategy": "moe_expert_lora"})
        )
        (final_dir / "config.json").write_text("{}")

        result = _detect_eulerforge_checkpoint(str(final_dir))
        assert result is not None
        assert result["strategy"] == "moe_expert_lora"
        assert result["base_model_name"] == "Qwen/Qwen3.5-0.8B-Base"
