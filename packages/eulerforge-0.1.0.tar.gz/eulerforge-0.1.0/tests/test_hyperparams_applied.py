# tests/test_hyperparams_applied.py
"""
4-타입 하이퍼파라미터 적용 검증 단위 테스트.

YAML 프리셋의 설정값이 실제 런타임 객체(optimizer, scheduler, injector, phase schedule)에
올바르게 전달되는지 검증한다. GPU 불필요, 실제 모델 다운로드 불필요.
"""
from __future__ import annotations

import os
import pathlib

import pytest
import torch
import torch.nn as nn
import yaml

from eulerforge.cli.train import (
    _apply_injection,
    _build_optimizer_for_trainable,
    _build_scheduler,
)
from eulerforge.adapters.backbones.qwen3 import Qwen3Adapter
from eulerforge.adapters.backbones.mixtral import MixtralAdapter
from eulerforge.modules.lora import LoRALinear
from eulerforge.modules.moe import MoEFFN
from eulerforge.modules.mixture_lora import MixtureLoRALinear
from eulerforge.phase_schedules import build_phase_schedule

# ---------------------------------------------------------------------------
# 프리셋 경로
# ---------------------------------------------------------------------------
_PROJECT_ROOT = pathlib.Path(__file__).resolve().parent.parent
_PRESETS = _PROJECT_ROOT / "configs" / "presets"

PRESET_DENSE_LORA_SFT = _PRESETS / "qwen3.5_0.8b_dense_lora_sft.yml"
PRESET_MIXTURE_LORA_SFT = _PRESETS / "qwen3.5_0.8b_mixture_lora_sft.yml"
PRESET_MOE_EXPERT_DPO = _PRESETS / "qwen3.5_0.8b_moe_expert_lora_dpo.yml"
PRESET_NATIVE_MOE_SFT = _PRESETS / "mixtral_native_expert_lora_sft.yml"


# ---------------------------------------------------------------------------
# 헬퍼: YAML 로딩
# ---------------------------------------------------------------------------
def _load_preset(path: pathlib.Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# ---------------------------------------------------------------------------
# 더미 모델: Qwen3 계열 (dense_lora, mixture_lora, moe_expert_lora)
# ---------------------------------------------------------------------------
class _DummyMLP(nn.Module):
    def __init__(self, d: int = 32):
        super().__init__()
        self.gate_proj = nn.Linear(d, d, bias=False)
        self.up_proj = nn.Linear(d, d, bias=False)
        self.down_proj = nn.Linear(d, d, bias=False)


class _DummyAttn(nn.Module):
    def __init__(self, d: int = 32):
        super().__init__()
        self.q_proj = nn.Linear(d, d, bias=False)
        self.k_proj = nn.Linear(d, d, bias=False)
        self.v_proj = nn.Linear(d, d, bias=False)
        self.o_proj = nn.Linear(d, d, bias=False)


class _DummyBlock(nn.Module):
    def __init__(self, d: int = 32):
        super().__init__()
        self.self_attn = _DummyAttn(d)
        self.mlp = _DummyMLP(d)


class DummyQwen3Model(nn.Module):
    """Qwen3Adapter.find_transformer_layers()가 model.model.layers를 찾을 수 있는 더미 모델."""

    def __init__(self, n_layers: int = 2, d: int = 32):
        super().__init__()
        self.model = nn.Module()
        self.model.layers = nn.ModuleList([_DummyBlock(d) for _ in range(n_layers)])
        self.config = type("C", (), {"hidden_size": d})()


# ---------------------------------------------------------------------------
# 더미 모델: Mixtral 계열 (native_moe_expert_lora)
# ---------------------------------------------------------------------------
class _DummyMixtralExpert(nn.Module):
    def __init__(self, d: int = 32):
        super().__init__()
        self.w1 = nn.Linear(d, d, bias=False)
        self.w2 = nn.Linear(d, d, bias=False)
        self.w3 = nn.Linear(d, d, bias=False)


class _DummySparseMoE(nn.Module):
    def __init__(self, d: int = 32, n_experts: int = 8):
        super().__init__()
        self.gate = nn.Linear(d, n_experts, bias=False)
        self.experts = nn.ModuleList([_DummyMixtralExpert(d) for _ in range(n_experts)])


class _DummyMixtralBlock(nn.Module):
    def __init__(self, d: int = 32, n_experts: int = 8):
        super().__init__()
        self.self_attn = _DummyAttn(d)
        self.block_sparse_moe = _DummySparseMoE(d, n_experts)


class DummyMixtralModel(nn.Module):
    """MixtralAdapter가 model.model.layers + block_sparse_moe.experts/gate를 찾을 수 있는 더미 모델."""

    def __init__(self, n_layers: int = 2, d: int = 32, n_experts: int = 8):
        super().__init__()
        self.model = nn.Module()
        self.model.layers = nn.ModuleList(
            [_DummyMixtralBlock(d, n_experts) for _ in range(n_layers)]
        )
        self.config = type("C", (), {"hidden_size": d})()


# ---------------------------------------------------------------------------
# 헬퍼: 모델 내 특정 타입 모듈 수집
# ---------------------------------------------------------------------------
def _find_modules(model: nn.Module, cls: type) -> list:
    return [m for m in model.modules() if isinstance(m, cls)]


def _find_named_modules(model: nn.Module, cls: type) -> list:
    return [(n, m) for n, m in model.named_modules() if isinstance(m, cls)]


# ===========================================================================
# (A) Plain LoRA SFT
# ===========================================================================
class TestPlainLoraSFTHyperparams:
    """Qwen3 dense_lora SFT 프리셋 하이퍼파라미터 적용 검증."""

    @pytest.fixture(scope="class")
    def cfg(self):
        return _load_preset(PRESET_DENSE_LORA_SFT)

    @pytest.fixture(scope="class")
    def injected_model(self, cfg):
        model = DummyQwen3Model(n_layers=2, d=32)
        adapter = Qwen3Adapter()
        _apply_injection(model, adapter, cfg["injection"], verbose=False)
        return model

    @pytest.fixture(scope="class")
    def optimizer(self, injected_model, cfg):
        tr = cfg["training"]
        return _build_optimizer_for_trainable(
            injected_model, lr=float(tr["lr"]), weight_decay=float(tr["weight_decay"])
        )

    # --- optimizer ---
    def test_optimizer_lr(self, optimizer, cfg):
        expected = float(cfg["training"]["lr"])
        assert optimizer.defaults["lr"] == pytest.approx(expected)

    def test_optimizer_weight_decay(self, optimizer, cfg):
        expected = float(cfg["training"]["weight_decay"])
        assert optimizer.defaults["weight_decay"] == pytest.approx(expected)

    # --- scheduler ---
    def test_scheduler_warmup(self, optimizer, cfg):
        tr = cfg["training"]
        warmup = int(tr["warmup_steps"])
        max_steps = int(tr.get("max_steps", tr.get("max_train_steps", 10000)))
        scheduler = _build_scheduler(optimizer, warmup, max_steps)
        lr_at_0 = scheduler.get_last_lr()[0]
        for _ in range(warmup):
            scheduler.step()
        lr_at_warmup = scheduler.get_last_lr()[0]
        assert lr_at_warmup > lr_at_0

    def test_max_train_steps_applied(self, cfg):
        tr = cfg["training"]
        max_steps = int(tr.get("max_steps", tr.get("max_train_steps", 10000)))
        assert max_steps == 5000

    # --- grad clipping ---
    def test_max_grad_norm(self, cfg):
        expected = float(cfg["training"].get("max_grad_norm", 1.0))
        assert expected == pytest.approx(1.0)

    # --- injection ---
    def test_injection_lora_r_alpha(self, injected_model, cfg):
        inj = cfg["injection"]
        lora_modules = _find_modules(injected_model, LoRALinear)
        assert len(lora_modules) > 0
        for m in lora_modules:
            assert m.r == int(inj["lora_r"])
            assert m.lora_alpha == pytest.approx(float(inj["lora_alpha"]))

    def test_injection_target_keywords(self, injected_model):
        """gate_proj, up_proj, down_proj가 LoRALinear로 교체되었는지 확인."""
        for block in injected_model.model.layers:
            for name in ("gate_proj", "up_proj", "down_proj"):
                mod = getattr(block.mlp, name)
                assert isinstance(mod, LoRALinear), f"mlp.{name} should be LoRALinear"

    def test_injection_attn_lora(self, injected_model):
        """q_proj, v_proj가 LoRALinear로 교체되었는지 확인."""
        for block in injected_model.model.layers:
            for name in ("q_proj", "v_proj"):
                mod = getattr(block.self_attn, name)
                assert isinstance(mod, LoRALinear), f"self_attn.{name} should be LoRALinear"

    # --- phase schedule ---
    def test_phase_schedule_single(self, cfg):
        sched = build_phase_schedule(cfg)
        assert sched is not None
        assert len(sched.phases) == 1
        p0 = sched.phases[0]
        assert p0.step == 0
        assert "lora" in p0.trainable
        assert "attn_lora" in p0.trainable


# ===========================================================================
# (B) LoRA MoE SFT
# ===========================================================================
class TestLoraMoeSFTHyperparams:
    """Qwen3 mixture_lora SFT 프리셋 하이퍼파라미터 적용 검증."""

    @pytest.fixture(scope="class")
    def cfg(self):
        return _load_preset(PRESET_MIXTURE_LORA_SFT)

    @pytest.fixture(scope="class")
    def injected_model(self, cfg):
        model = DummyQwen3Model(n_layers=2, d=32)
        adapter = Qwen3Adapter()
        _apply_injection(model, adapter, cfg["injection"], verbose=False)
        return model

    @pytest.fixture(scope="class")
    def optimizer(self, injected_model, cfg):
        tr = cfg["training"]
        return _build_optimizer_for_trainable(
            injected_model, lr=float(tr["lr"]), weight_decay=float(tr["weight_decay"])
        )

    # --- optimizer ---
    def test_optimizer_lr(self, optimizer, cfg):
        expected = float(cfg["training"]["lr"])
        assert optimizer.defaults["lr"] == pytest.approx(expected)

    # --- scheduler ---
    def test_scheduler_params(self, optimizer, cfg):
        tr = cfg["training"]
        warmup = int(tr["warmup_steps"])
        max_steps = int(tr.get("max_steps", tr.get("max_train_steps", 10000)))
        scheduler = _build_scheduler(optimizer, warmup, max_steps)
        assert scheduler is not None
        assert max_steps == 10000

    # --- injection ---
    def test_injection_lora_r_alpha(self, injected_model, cfg):
        inj = cfg["injection"]
        # MixtureLoRALinear 내부에도 r, alpha가 있을 수 있지만
        # attn LoRA는 LoRALinear로 래핑됨
        lora_modules = _find_modules(injected_model, LoRALinear)
        assert len(lora_modules) > 0
        for m in lora_modules:
            assert m.r == int(inj["lora_r"])
            assert m.lora_alpha == pytest.approx(float(inj["lora_alpha"]))

    def test_injection_num_experts(self, injected_model, cfg):
        expected = int(cfg["injection"]["num_experts"])
        mixture_modules = _find_modules(injected_model, MixtureLoRALinear)
        assert len(mixture_modules) > 0
        for m in mixture_modules:
            assert m.num_experts == expected

    def test_injection_top_k(self, injected_model, cfg):
        expected = int(cfg["injection"]["top_k"])
        mixture_modules = _find_modules(injected_model, MixtureLoRALinear)
        for m in mixture_modules:
            assert m.top_k == expected

    def test_injection_target_keywords(self, injected_model):
        """gate_proj, up_proj, down_proj가 MixtureLoRALinear로 교체되었는지 확인."""
        for block in injected_model.model.layers:
            for name in ("gate_proj", "up_proj", "down_proj"):
                mod = getattr(block.mlp, name)
                assert isinstance(mod, MixtureLoRALinear), f"mlp.{name} should be MixtureLoRALinear"

    def test_injection_attn_lora(self, injected_model):
        """q_proj, v_proj가 LoRALinear로 교체되었는지 확인."""
        for block in injected_model.model.layers:
            for name in ("q_proj", "v_proj"):
                mod = getattr(block.self_attn, name)
                assert isinstance(mod, LoRALinear), f"self_attn.{name} should be LoRALinear"

    # --- phase schedule ---
    def test_phase_schedule_two_phases(self, cfg):
        sched = build_phase_schedule(cfg)
        assert sched is not None
        assert len(sched.phases) == 2

    def test_phase_0_router_only(self, cfg):
        sched = build_phase_schedule(cfg)
        p0 = sched.phases[0]
        assert p0.step == 0
        assert "router" in p0.trainable

    def test_phase_1_lora(self, cfg):
        sched = build_phase_schedule(cfg)
        p1 = sched.phases[1]
        assert p1.step == 2000
        assert "lora" in p1.trainable
        assert "attn_lora" in p1.trainable


# ===========================================================================
# (C) FFN MoE Expert LoRA DPO
# ===========================================================================
class TestFFNMoEExpertLoraDPOHyperparams:
    """Qwen3 moe_expert_lora DPO 프리셋 하이퍼파라미터 적용 검증."""

    @pytest.fixture(scope="class")
    def cfg(self):
        return _load_preset(PRESET_MOE_EXPERT_DPO)

    @pytest.fixture(scope="class")
    def injected_model(self, cfg):
        model = DummyQwen3Model(n_layers=2, d=32)
        adapter = Qwen3Adapter()
        _apply_injection(model, adapter, cfg["injection"], verbose=False)
        return model

    @pytest.fixture(scope="class")
    def optimizer(self, injected_model, cfg):
        tr = cfg["training"]
        return _build_optimizer_for_trainable(
            injected_model, lr=float(tr["lr"]), weight_decay=float(tr["weight_decay"])
        )

    # --- optimizer ---
    def test_optimizer_lr(self, optimizer, cfg):
        expected = float(cfg["training"]["lr"])
        assert optimizer.defaults["lr"] == pytest.approx(expected)

    def test_optimizer_weight_decay(self, optimizer, cfg):
        expected = float(cfg["training"]["weight_decay"])
        assert optimizer.defaults["weight_decay"] == pytest.approx(expected)

    # --- scheduler ---
    def test_scheduler_params(self, optimizer, cfg):
        tr = cfg["training"]
        warmup = int(tr["warmup_steps"])
        max_steps = int(tr.get("max_steps", tr.get("max_train_steps", 10000)))
        scheduler = _build_scheduler(optimizer, warmup, max_steps)
        assert scheduler is not None
        assert warmup == 100
        assert max_steps == 15000

    # --- DPO-specific ---
    def test_dpo_beta(self, cfg):
        expected = float(cfg["training"].get("dpo_beta", 0.1))
        assert expected == pytest.approx(0.1)

    def test_batch_size(self, cfg):
        expected = int(cfg["training"]["batch_size"])
        assert expected == 2

    def test_grad_accum_steps(self, cfg):
        expected = int(cfg["training"]["grad_accum_steps"])
        assert expected == 8

    # --- injection ---
    def test_injection_moe_ffn(self, injected_model):
        """MoEFFN 모듈이 생성되었는지 확인."""
        moe_modules = _find_modules(injected_model, MoEFFN)
        assert len(moe_modules) > 0

    def test_injection_num_experts(self, injected_model, cfg):
        expected = int(cfg["injection"]["num_experts"])
        moe_modules = _find_modules(injected_model, MoEFFN)
        for m in moe_modules:
            assert m.num_experts == expected

    def test_injection_lora_in_experts(self, injected_model):
        """MoEFFN의 expert FFN 내부에 LoRALinear가 존재하는지 확인."""
        moe_modules = _find_modules(injected_model, MoEFFN)
        for moe in moe_modules:
            lora_in_experts = _find_modules(moe, LoRALinear)
            assert len(lora_in_experts) > 0, "MoEFFN experts should contain LoRALinear"

    def test_injection_attn_lora(self, injected_model):
        """q_proj, v_proj가 LoRALinear로 교체되었는지 확인."""
        for block in injected_model.model.layers:
            for name in ("q_proj", "v_proj"):
                mod = getattr(block.self_attn, name)
                assert isinstance(mod, LoRALinear), f"self_attn.{name} should be LoRALinear"

    # --- phase schedule ---
    def test_phase_schedule_three_phases(self, cfg):
        sched = build_phase_schedule(cfg)
        assert sched is not None
        assert len(sched.phases) == 3

    def test_phase_2_base_ffn_keywords(self, cfg):
        sched = build_phase_schedule(cfg)
        p2 = sched.phases[2]
        assert p2.base_ffn_keywords is not None
        assert "gate_proj" in p2.base_ffn_keywords
        assert "up_proj" in p2.base_ffn_keywords
        assert "down_proj" in p2.base_ffn_keywords

    def test_phase_2_trainable_includes_base_ffn(self, cfg):
        sched = build_phase_schedule(cfg)
        p2 = sched.phases[2]
        assert "base_ffn" in p2.trainable


# ===========================================================================
# (D) Native MoE Expert LoRA SFT
# ===========================================================================
class TestNativeMoEExpertLoraSFTHyperparams:
    """Mixtral native_moe_expert_lora SFT 프리셋 하이퍼파라미터 적용 검증."""

    @pytest.fixture(scope="class")
    def cfg(self):
        return _load_preset(PRESET_NATIVE_MOE_SFT)

    @pytest.fixture(scope="class")
    def injected_model(self, cfg):
        model = DummyMixtralModel(n_layers=2, d=32, n_experts=8)
        adapter = MixtralAdapter()
        _apply_injection(model, adapter, cfg["injection"], verbose=False)
        return model

    @pytest.fixture(scope="class")
    def optimizer(self, injected_model, cfg):
        tr = cfg["training"]
        return _build_optimizer_for_trainable(
            injected_model, lr=float(tr["lr"]), weight_decay=float(tr["weight_decay"])
        )

    # --- optimizer ---
    def test_optimizer_lr(self, optimizer, cfg):
        expected = float(cfg["training"]["lr"])
        assert optimizer.defaults["lr"] == pytest.approx(expected)

    # --- scheduler ---
    def test_scheduler_params(self, optimizer, cfg):
        tr = cfg["training"]
        warmup = int(tr["warmup_steps"])
        max_steps = int(tr.get("max_steps", tr.get("max_train_steps", 10000)))
        scheduler = _build_scheduler(optimizer, warmup, max_steps)
        assert scheduler is not None
        assert warmup == 200
        assert max_steps == 5000

    # --- injection ---
    def test_injection_lora_r_alpha(self, injected_model, cfg):
        inj = cfg["injection"]
        lora_modules = _find_modules(injected_model, LoRALinear)
        assert len(lora_modules) > 0
        for m in lora_modules:
            assert m.r == int(inj["lora_r"])
            assert m.lora_alpha == pytest.approx(float(inj["lora_alpha"]))

    def test_injection_target_keywords(self, injected_model):
        """expert의 gate_up_proj/down_proj가 LoRA 래핑 대상인지 확인.

        fused MixtralExperts: _FusedExpertSlice 래퍼를 통해 LoRA 적용.
        unfused: 개별 expert.w1/w2/w3에 직접 LoRA 적용.
        """
        lora_modules = _find_modules(injected_model, LoRALinear)
        # attn_lora 외에 expert FFN LoRA도 있어야 함
        # (fused expert의 경우 _FusedExpertSlice 내부의 Linear가 LoRA 래핑됨)
        assert len(lora_modules) > 0, "No LoRALinear modules found after injection"

    def test_injection_attn_lora(self, injected_model):
        """q_proj, v_proj가 LoRALinear로 교체되었는지 확인."""
        for block in injected_model.model.layers:
            for name in ("q_proj", "v_proj"):
                mod = getattr(block.self_attn, name)
                assert isinstance(mod, LoRALinear), f"self_attn.{name} should be LoRALinear"

    def test_native_expert_structure_preserved(self, injected_model):
        """MoE 구조가 유지되는지 (MoEFFN으로 교체되지 않음)."""
        for block in injected_model.model.layers:
            # block_sparse_moe 또는 mlp에 MoE가 유지됨
            has_moe = hasattr(block, "block_sparse_moe") or hasattr(block, "mlp")
            assert has_moe

    def test_injection_has_expert_lora(self, injected_model):
        """인젝션 후 expert 관련 LoRALinear가 존재하는지 확인."""
        all_lora = _find_modules(injected_model, LoRALinear)
        # attn_lora (q_proj, v_proj) 외에 추가 LoRA가 있어야 함
        # (fused expert에서 unfuse된 slice 내부의 LoRA)
        assert len(all_lora) > 0, "Should have LoRALinear modules after injection"

    # --- phase schedule ---
    def test_phase_schedule_single(self, cfg):
        sched = build_phase_schedule(cfg)
        assert sched is not None
        assert len(sched.phases) == 1
        p0 = sched.phases[0]
        assert p0.step == 0
        assert "lora" in p0.trainable
        assert "attn_lora" in p0.trainable

    # --- grad clipping ---
    def test_max_grad_norm(self, cfg):
        expected = float(cfg["training"].get("max_grad_norm", 1.0))
        assert expected == pytest.approx(1.0)
