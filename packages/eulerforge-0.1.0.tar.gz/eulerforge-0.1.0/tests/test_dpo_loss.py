# tests/test_dpo_loss.py
"""
DPO 손실 함수 및 log probability 계산 단위 테스트.

핵심 검증:
- get_batch_logps: sum vs average 모드
- dpo_loss_fn: 표준 DPO 공식 검증
- DPO training step에서 average_log_prob=True 사용 확인
"""
import pytest
import torch
import torch.nn.functional as F

from eulerforge.cli.train import get_batch_logps, dpo_loss_fn


class TestGetBatchLogps:
    """get_batch_logps 단위 테스트."""

    def test_sum_logps_default(self):
        """기본 모드: sum log probability."""
        # (batch=2, seq=3, vocab=5)
        logits = torch.randn(2, 3, 5)
        labels = torch.tensor([[1, 2, 3], [0, 1, 2]])
        result = get_batch_logps(logits, labels, average_log_prob=False)
        assert result.shape == (2,)
        # sum logps는 보통 큰 음수
        assert (result < 0).all()

    def test_average_logps(self):
        """average_log_prob=True: 토큰당 평균."""
        logits = torch.randn(2, 3, 5)
        labels = torch.tensor([[1, 2, 3], [0, 1, 2]])

        sum_result = get_batch_logps(logits, labels, average_log_prob=False)
        avg_result = get_batch_logps(logits, labels, average_log_prob=True)

        # average = sum / count, count=3 (no masking)
        torch.testing.assert_close(avg_result, sum_result / 3.0)

    def test_masking_with_minus100(self):
        """labels=-100 위치는 마스킹되어야 한다."""
        logits = torch.randn(1, 4, 5)
        # 앞 2개만 유효, 뒤 2개는 마스킹
        labels = torch.tensor([[1, 2, -100, -100]])

        sum_result = get_batch_logps(logits, labels, average_log_prob=False)
        avg_result = get_batch_logps(logits, labels, average_log_prob=True)

        # average는 유효 토큰 수(2)로 나눠야 함
        torch.testing.assert_close(avg_result, sum_result / 2.0)

    def test_average_logps_magnitude_smaller_than_sum(self):
        """average logps는 sum보다 절대값이 항상 작다 (seq_len > 1)."""
        logits = torch.randn(4, 10, 100)  # seq_len=10
        labels = torch.randint(0, 100, (4, 10))

        sum_result = get_batch_logps(logits, labels, average_log_prob=False)
        avg_result = get_batch_logps(logits, labels, average_log_prob=True)

        assert (avg_result.abs() < sum_result.abs()).all()

    def test_different_length_sequences_sum_bias(self):
        """sum logps는 짧은 시퀀스에 편향된다 (DPO 불안정 원인)."""
        torch.manual_seed(42)
        logits = torch.randn(2, 8, 50)
        # 시퀀스 1: 길이 8 (전부 유효), 시퀀스 2: 길이 4 (나머지 마스킹)
        labels = torch.tensor([
            [1, 2, 3, 4, 5, 6, 7, 8],
            [1, 2, 3, 4, -100, -100, -100, -100],
        ])

        sum_result = get_batch_logps(logits, labels, average_log_prob=False)
        avg_result = get_batch_logps(logits, labels, average_log_prob=True)

        # sum: 긴 시퀀스가 더 큰 음수 (더 낮은 값)
        assert sum_result[0] < sum_result[1], "Sum biased toward shorter sequences"
        # average: 길이 무관하게 비교 가능한 크기
        # (절대값 차이가 sum보다 작아야 함)
        sum_diff = (sum_result[0] - sum_result[1]).abs()
        avg_diff = (avg_result[0] - avg_result[1]).abs()
        assert avg_diff < sum_diff


class TestDpoLossFn:
    """dpo_loss_fn 단위 테스트."""

    def test_perfect_preference_low_loss(self):
        """chosen > rejected이면 loss가 작아야 한다."""
        # policy가 chosen을 강하게 선호
        policy_chosen = torch.tensor([-1.0])
        policy_rejected = torch.tensor([-3.0])
        ref_chosen = torch.tensor([-1.5])
        ref_rejected = torch.tensor([-1.5])

        loss, c_rew, r_rew = dpo_loss_fn(
            policy_chosen, policy_rejected, ref_chosen, ref_rejected, beta=0.1
        )
        assert loss.item() < 0.7  # lower than random (~0.693)

    def test_wrong_preference_high_loss(self):
        """chosen < rejected이면 loss가 커야 한다."""
        policy_chosen = torch.tensor([-3.0])
        policy_rejected = torch.tensor([-1.0])
        ref_chosen = torch.tensor([-1.5])
        ref_rejected = torch.tensor([-1.5])

        loss, c_rew, r_rew = dpo_loss_fn(
            policy_chosen, policy_rejected, ref_chosen, ref_rejected, beta=0.1
        )
        assert loss.item() > 0.5  # high loss

    def test_reward_margin_sign(self):
        """chosen_reward > rejected_reward이면 margin이 양수."""
        policy_chosen = torch.tensor([-1.0])
        policy_rejected = torch.tensor([-2.0])
        ref_chosen = torch.tensor([-1.5])
        ref_rejected = torch.tensor([-1.5])

        _, c_rew, r_rew = dpo_loss_fn(
            policy_chosen, policy_rejected, ref_chosen, ref_rejected, beta=0.1
        )
        assert (c_rew - r_rew).item() > 0

    def test_beta_controls_kl_penalty(self):
        """beta가 클수록 동일한 logratio에서 loss가 달라진다."""
        pc = torch.tensor([-1.0])
        pr = torch.tensor([-2.0])
        rc = torch.tensor([-1.5])
        rr = torch.tensor([-1.5])

        loss_small_beta, _, _ = dpo_loss_fn(pc, pr, rc, rr, beta=0.01)
        loss_large_beta, _, _ = dpo_loss_fn(pc, pr, rc, rr, beta=1.0)

        # 큰 beta는 동일한 preference signal에 대해 더 낮은 loss (sigm oid 더 포화)
        assert loss_large_beta.item() < loss_small_beta.item()


class TestDpoReferenceModel:
    """DPO reference model이 SFT 모델이어야 하는지 검증.

    파이프라인 DPO (SFT→DPO)에서 disable_adapter_layers()를 사용하면
    reference = base model이 되어 SFT 효과가 사라진다.
    올바른 reference는 SFT 모델 (초기 LoRA 가중치 상태)이어야 한다.
    """

    def test_use_reference_lora_context_manager_exists(self):
        """_use_reference_lora context manager가 존재해야 한다."""
        from eulerforge.cli.train import _use_reference_lora
        assert callable(_use_reference_lora)

    def test_reference_restores_initial_lora_weights(self):
        """reference forward 후 현재 LoRA 가중치가 복원되어야 한다."""
        from eulerforge.cli.train import _use_reference_lora
        from eulerforge.modules.lora import LoRALinear

        # LoRA가 있는 간단한 모델
        base = torch.nn.Linear(4, 4, bias=False)
        lora = LoRALinear(base, r=2, alpha=4, dropout=0.0)

        # 초기 상태 저장 (SFT reference)
        ref_sd = {k: v.clone() for k, v in lora.state_dict().items()
                  if "lora_A" in k or "lora_B" in k}

        # 현재 상태 변경 (DPO 훈련 시뮬레이션)
        with torch.no_grad():
            for p in lora.parameters():
                if p.requires_grad:
                    p.add_(torch.randn_like(p) * 0.1)

        # 변경된 상태 저장
        current_sd = {k: v.clone() for k, v in lora.state_dict().items()
                      if "lora_A" in k or "lora_B" in k}

        # reference forward: 초기 LoRA 상태로 일시 복원
        model = torch.nn.Sequential(lora)
        with _use_reference_lora(model, ref_sd):
            # context 안에서는 reference (SFT) 상태
            for k, v in model.state_dict().items():
                if "lora_A" in k or "lora_B" in k:
                    ref_key = k
                    if ref_key in ref_sd:
                        torch.testing.assert_close(v, ref_sd[ref_key])

        # context 밖에서는 현재 (DPO 훈련 중) 상태 복원
        for k, v in model.state_dict().items():
            if "lora_A" in k or "lora_B" in k:
                if k in current_sd:
                    torch.testing.assert_close(v, current_sd[k])

    def test_ppo_also_uses_reference_lora(self):
        """PPO의 KL penalty reference도 SFT reference를 사용해야 한다.

        run_ppo_iteration()에도 ref_lora_sd 파라미터가 있어야 함.
        """
        import inspect
        from eulerforge.cli.train import run_ppo_iteration

        sig = inspect.signature(run_ppo_iteration)
        assert "ref_lora_sd" in sig.parameters, (
            "run_ppo_iteration must accept ref_lora_sd for pipeline PPO"
        )

    def test_reference_snapshot_captures_mixture_lora_params(self):
        """MixtureLoRA의 loraA/loraB도 reference snapshot에 포함되어야 한다.

        MixtureLoRALinear는 lora_A/lora_B가 아닌 loraA/loraB를 사용.
        """
        # Simulate model.named_parameters() with both patterns
        params = {
            "model.layers.0.mlp.lora_A": torch.randn(4, 8),
            "model.layers.0.mlp.lora_B": torch.randn(8, 4),
            "model.layers.1.mlp.loraA": torch.randn(4, 8),   # MixtureLoRA
            "model.layers.1.mlp.loraB": torch.randn(8, 4),   # MixtureLoRA
            "model.layers.0.mlp.base_layer.weight": torch.randn(8, 8),
        }

        # Filter logic from run_training
        lora_params = {
            k: v.clone() for k, v in params.items()
            if "lora_A" in k or "lora_B" in k or "loraA" in k or "loraB" in k
        }

        assert len(lora_params) == 4  # lora_A + lora_B + loraA + loraB
        assert "model.layers.1.mlp.loraA" in lora_params
        assert "model.layers.1.mlp.loraB" in lora_params

    def test_ref_snapshot_created_for_dpo_and_ppo(self):
        """reference snapshot은 DPO와 PPO 모두에서 생성되어야 한다.

        소스 코드에서 training_type in ("dpo", "ppo") 확인.
        """
        import inspect
        from eulerforge.cli.train import run_training

        source = inspect.getsource(run_training)
        # Reference state section should include both dpo and ppo
        assert 'training_type in ("dpo", "ppo")' in source, (
            "Reference LoRA snapshot must be created for both DPO and PPO"
        )

    def test_initial_dpo_loss_should_be_ln2(self):
        """파이프라인 DPO 시작 시 loss ≈ ln(2) = 0.693이어야 한다.

        π_θ = π_ref 일 때 (둘 다 SFT 모델), log_ratio = 0 → loss = ln(2).
        disable_adapter로 ref = base model이면 loss ≠ ln(2) (버그).
        """
        import math
        # DPO at initialization: policy = reference → loss = ln(2)
        policy_c = torch.tensor([-50.0])
        policy_r = torch.tensor([-55.0])
        ref_c = torch.tensor([-50.0])  # same as policy (ref = SFT model)
        ref_r = torch.tensor([-55.0])

        loss, _, _ = dpo_loss_fn(policy_c, policy_r, ref_c, ref_r, beta=0.1)
        assert abs(loss.item() - math.log(2)) < 0.01, (
            f"When ref=policy, DPO loss should be ln(2)={math.log(2):.4f}, "
            f"got {loss.item():.4f}"
        )


class TestDpoUsesSumLogProb:
    """DPO training step이 sum log probs (TRL 표준)를 사용하는지 검증."""

    def test_dpo_uses_sum_logps(self):
        """DPO sigmoid는 sum log probs를 사용해야 한다 (TRL 표준).

        average_log_prob=True를 사용하면 gradient가 ~1/seq_len으로 줄어
        reward_margin이 0.001-0.02 수준에 머물며 학습이 안 됨.
        TRL의 DPOTrainer는 loss_type='sigmoid'에서 average_log_prob=False(sum)을 사용.
        """
        import inspect
        from eulerforge.cli.train import run_training_step

        source = inspect.getsource(run_training_step)

        dpo_section_start = source.find("Type B: DPO")
        assert dpo_section_start != -1

        dpo_section = source[dpo_section_start:]
        orpo_start = dpo_section.find("Type C:")
        if orpo_start != -1:
            dpo_section = dpo_section[:orpo_start]

        assert "average_log_prob=False" in dpo_section, (
            "DPO section must use get_batch_logps with average_log_prob=False (sum). "
            "This matches TRL's standard sigmoid DPO. "
            "Average logps make gradients ~1/seq_len weaker."
        )

    def test_orpo_uses_average_logps(self):
        """ORPO는 average log probs를 사용해야 한다 (원 논문 기준)."""
        import inspect
        from eulerforge.cli.train import run_training_step

        source = inspect.getsource(run_training_step)

        orpo_start = source.find("Type C: ORPO")
        assert orpo_start != -1

        orpo_section = source[orpo_start:]
        # Type D (RM) 전까지
        rm_start = orpo_section.find("Type D:")
        if rm_start != -1:
            orpo_section = orpo_section[:rm_start]

        assert "average_log_prob=True" in orpo_section, (
            "ORPO must use average log probs per the original paper."
        )
