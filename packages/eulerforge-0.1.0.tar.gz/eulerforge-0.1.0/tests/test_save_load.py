import pytest
import torch
import os
from eulerforge.cli.train import _select_backbone_adapter, _apply_injection

# ---------------------------------------------------------------------------
# Test Matrix
# ---------------------------------------------------------------------------
SAVE_LOAD_CASES = [
    # Case 1: Qwen + FFN MoE (가장 복잡한 구조: Router + Expert LoRA + Base Freeze)
    dict(
        id="qwen_ffn_moe",
        model_type="qwen",
        strategy="moe_expert_lora",
        inj_kwargs={
            "lora_r": 8, "num_experts": 2, "top_k": 1,
            "target_keywords": ["gate_proj", "up_proj", "down_proj"],
            "attn_lora": {"enabled": True, "keywords": ["q_proj", "v_proj"]}
        }
    ),
    # Case 2: Llama + LoRA MoE (MixtureLoRA 구조)
    dict(
        id="llama_mixture_lora",
        model_type="llama3", 
        strategy="mixture_lora",
        inj_kwargs={
            "lora_r": 8, "num_experts": 4, "top_k": 2,
            "target_keywords": ["gate_proj", "up_proj", "down_proj"],
            "attn_lora": {"enabled": True, "keywords": ["q_proj", "v_proj"]}
        }
    ),
    # Case 3: Mixtral + Native MoE (이미 MoE인 구조 + Attn LoRA)
    dict(
        id="mixtral_native",
        model_type="mixtral",
        strategy="native_moe_expert_lora",
        inj_kwargs={
            "lora_r": 8,
            # Native MoE는 experts 수/top_k가 모델 고정이므로 config에서 안 받거나 무시됨
            "target_keywords": ["w1", "w2", "w3"],
            "attn_lora": {"enabled": True, "keywords": ["q_proj", "v_proj"]}
        }
    )
]

@pytest.mark.parametrize("case", SAVE_LOAD_CASES, ids=lambda x: x["id"])
def test_save_load_consistency(case, real_model_factory, tmp_path):
    print(f"\n>>> [Save/Load] Testing {case['id']} ({case['model_type']} + {case['strategy']})...")

    # -------------------------------------------------------
    # 1. 모델 로드 및 Mixtral 예외 처리
    # -------------------------------------------------------
    if case['model_type'] == "mixtral":
        try:
            # Factory 호출 (Mixtral 매핑 확인 필요, 없으면 mistral 호출 시도)
            model_src, _ = real_model_factory("mistral") 
            # 실제로는 conftest의 factory가 무엇을 리턴하느냐에 달림.
            # Qwen이 리턴되면 구조 불일치로 fail 가능성 있음. 
            # 하지만 앞선 테스트 통과했으므로 환경이 갖춰졌다고 가정.
        except Exception:
            pytest.skip("Mixtral model load failed or skipped.")
    else:
        model_src, _ = real_model_factory(case['model_type'])

    # Adapter 선택
    adapter_key = "qwen3" if "qwen" in case['model_type'] else ("mixtral" if "mixtral" in case['model_type'] else "llama")
    adapter = _select_backbone_adapter(adapter_key)

    # -------------------------------------------------------
    # 2. Injection (원본 모델)
    # -------------------------------------------------------
    inj_cfg = {
        "strategy": case["strategy"],
        "lora_r": case["inj_kwargs"].get("lora_r", 8),
        "lora_alpha": 16,
        "lora_dropout": 0.05,
        "num_experts": case["inj_kwargs"].get("num_experts", 2),
        "top_k": case["inj_kwargs"].get("top_k", 1),
        "target_keywords": case["inj_kwargs"]["target_keywords"],
        "attn_lora": case["inj_kwargs"].get("attn_lora", {}),
        "start_layer": 0, "num_layers": 0
    }
    # FFN MoE 전용
    if case["strategy"] == "moe_expert_lora":
        inj_cfg["moe_start_layer"] = 0
        inj_cfg["moe_num_layers"] = 0

    print("    [Info] Injecting Source Model...")
    _apply_injection(model_src, adapter, inj_cfg, verbose=False)

    # -------------------------------------------------------
    # 3. State Dict 저장
    # -------------------------------------------------------
    # 임의의 파라미터 값 변경 (제대로 로드되는지 확인하기 위해)
    # 예: 첫 번째 파라미터에 1.0 더하기
    with torch.no_grad():
        for p in model_src.parameters():
            if p.requires_grad:
                p.add_(1.0)
                break
    
    save_path = tmp_path / "model_ckpt.pt"
    torch.save(model_src.state_dict(), save_path)
    print(f"    [Info] Saved checkpoint to {save_path} ({os.path.getsize(save_path) / 1024 / 1024:.2f} MB)")

    # 메모리 해제 (GPU OOM 방지)
    src_device = model_src.device
    del model_src
    torch.cuda.empty_cache()

    # -------------------------------------------------------
    # 4. 새 모델 로드 및 Injection (타겟 모델)
    # -------------------------------------------------------
    print("    [Info] Creating Target Model (Fresh)...")
    if case['model_type'] == "mixtral":
        model_tgt, _ = real_model_factory("mistral")
    else:
        model_tgt, _ = real_model_factory(case['model_type'])
    
    # [중요] 저장된 모델과 똑같은 구조를 먼저 만들어야 로드가 가능함
    _apply_injection(model_tgt, adapter, inj_cfg, verbose=False)
    
    # -------------------------------------------------------
    # 5. Load State Dict (Strict=True)
    # -------------------------------------------------------
    print("    [Info] Loading State Dict...")
    try:
        # strict=True: 키가 하나라도 다르거나(missing), 남으면(unexpected) 에러 발생
        # 이것이 통과되면 구조가 완벽하게 일치한다는 뜻
        model_tgt.load_state_dict(torch.load(save_path, map_location=src_device), strict=True)
        print("    [Pass] Strict Load Successful!")
    except RuntimeError as e:
        pytest.fail(f"State dict mismatch: {e}")

    # -------------------------------------------------------
    # 6. 값 검증 (옵션)
    # -------------------------------------------------------
    # 아까 더한 1.0이 반영되었는지 확인 (초기화 값이 아님을 증명)
    # (여기서는 생략해도 strict load가 통과했으면 구조 검증은 완료됨)
    
    print(f"    [OK] Save/Load test passed for {case['id']}.")