# tests/test_grid_validator.py
# -*- coding: utf-8 -*-
"""
Grid Search YAML 검증기 단위 테스트.

docs/fixtures/specs/grid_search_spec.md의 규칙 1-21과 1:1 대응.
모두 CPU에서 실행 (GPU 불필요).
"""
from __future__ import annotations

import os
import textwrap

import pytest
import yaml

from eulerforge.utils.grid_validator import (
    GridSpecValidationError,
    validate_grid_spec,
    load_and_validate_grid_spec,
)


# ---------------------------------------------------------------------------
# 공통 helper — 최소 유효 spec 빌더
# ---------------------------------------------------------------------------

def _minimal_spec(
    method="random",
    space=None,
    direction="minimize",
    step_agg="last",
    data=None,
    max_trials=5,
    max_train_steps=10,
):
    """최소 필수 필드만 포함한 유효 spec dict."""
    if space is None:
        space = [
            {"name": "training.lr", "type": "float", "low": 1e-6, "high": 1e-4}
        ]
    spec = {
        "version": 1,
        "base_preset": "configs/presets/qwen3.5_0.8b_dense_lora_sft.yml",
        "run": {
            "output_root": "outputs/grid",
            "max_trials": max_trials,
            "max_train_steps": max_train_steps,
            "objective": {
                "direction": direction,
                "metric": "train/total_loss",
                "step_agg": step_agg,
            },
        },
        "search": {
            "method": method,
            "space": space,
        },
    }
    if data is not None:
        spec["run"]["data"] = data
    return spec


# ===========================================================================
# 1. 구조 레벨 검증
# ===========================================================================

class TestGridSpecStructure:
    def test_valid_minimal_spec(self):
        """최소 필수 필드 조합은 검증을 통과해야 한다."""
        validate_grid_spec(_minimal_spec())  # 예외 없음

    def test_missing_version(self):
        """version 없음 → GridSpecValidationError."""
        spec = _minimal_spec()
        del spec["version"]
        with pytest.raises(GridSpecValidationError, match="version"):
            validate_grid_spec(spec)

    def test_wrong_version(self):
        """version: 2 → GridSpecValidationError."""
        spec = _minimal_spec()
        spec["version"] = 2
        with pytest.raises(GridSpecValidationError, match="version"):
            validate_grid_spec(spec)

    def test_missing_base_preset(self):
        """base_preset 없음 → GridSpecValidationError."""
        spec = _minimal_spec()
        del spec["base_preset"]
        with pytest.raises(GridSpecValidationError, match="base_preset"):
            validate_grid_spec(spec)

    def test_missing_run_section(self):
        """run 섹션 없음 → GridSpecValidationError."""
        spec = _minimal_spec()
        del spec["run"]
        with pytest.raises(GridSpecValidationError, match="run"):
            validate_grid_spec(spec)


# ===========================================================================
# 2. run 섹션 검증
# ===========================================================================

class TestGridRunSection:
    def test_missing_output_root(self):
        """run.output_root 없음 → GridSpecValidationError."""
        spec = _minimal_spec()
        del spec["run"]["output_root"]
        with pytest.raises(GridSpecValidationError, match="output_root"):
            validate_grid_spec(spec)

    def test_max_trials_zero(self):
        """max_trials=0 → GridSpecValidationError."""
        spec = _minimal_spec(max_trials=0)
        with pytest.raises(GridSpecValidationError, match="max_trials"):
            validate_grid_spec(spec)

    def test_max_trials_negative(self):
        """max_trials=-1 → GridSpecValidationError."""
        spec = _minimal_spec(max_trials=-1)
        with pytest.raises(GridSpecValidationError, match="max_trials"):
            validate_grid_spec(spec)

    def test_max_train_steps_zero(self):
        """max_train_steps=0 → GridSpecValidationError."""
        spec = _minimal_spec(max_train_steps=0)
        with pytest.raises(GridSpecValidationError, match="max_train_steps"):
            validate_grid_spec(spec)

    def test_invalid_direction(self):
        """objective.direction='maximize_loss' → GridSpecValidationError."""
        spec = _minimal_spec(direction="maximize_loss")
        with pytest.raises(GridSpecValidationError, match="direction"):
            validate_grid_spec(spec)

    def test_valid_direction_maximize(self):
        """direction='maximize' → 통과."""
        validate_grid_spec(_minimal_spec(direction="maximize"))

    def test_invalid_step_agg(self):
        """objective.step_agg='first' → GridSpecValidationError."""
        spec = _minimal_spec(step_agg="first")
        with pytest.raises(GridSpecValidationError, match="step_agg"):
            validate_grid_spec(spec)

    def test_valid_step_agg_min(self):
        """step_agg='min' → 통과."""
        validate_grid_spec(_minimal_spec(step_agg="min"))

    def test_valid_step_agg_mean(self):
        """step_agg='mean' → 통과."""
        validate_grid_spec(_minimal_spec(step_agg="mean"))

    def test_missing_objective(self):
        """run.objective 없음 → GridSpecValidationError."""
        spec = _minimal_spec()
        del spec["run"]["objective"]
        with pytest.raises(GridSpecValidationError, match="objective"):
            validate_grid_spec(spec)

    def test_missing_objective_metric(self):
        """run.objective.metric 없음 → GridSpecValidationError."""
        spec = _minimal_spec()
        del spec["run"]["objective"]["metric"]
        with pytest.raises(GridSpecValidationError, match="metric"):
            validate_grid_spec(spec)


# ===========================================================================
# 3. search 섹션 검증
# ===========================================================================

class TestGridSearchSection:
    def test_missing_search_section(self):
        """search 섹션 없음 → GridSpecValidationError."""
        spec = _minimal_spec()
        del spec["search"]
        with pytest.raises(GridSpecValidationError, match="search"):
            validate_grid_spec(spec)

    def test_invalid_method(self):
        """method='pso' → GridSpecValidationError."""
        spec = _minimal_spec(method="pso")
        with pytest.raises(GridSpecValidationError, match="method"):
            validate_grid_spec(spec)

    def test_empty_space(self):
        """space: [] → GridSpecValidationError."""
        spec = _minimal_spec(space=[])
        with pytest.raises(GridSpecValidationError, match="space"):
            validate_grid_spec(spec)

    def test_missing_space(self):
        """space 키 없음 → GridSpecValidationError."""
        spec = _minimal_spec()
        del spec["search"]["space"]
        with pytest.raises(GridSpecValidationError, match="space"):
            validate_grid_spec(spec)

    def test_float_type_requires_low_high(self):
        """type:float, choices 없음, low/high 없음 → GridSpecValidationError."""
        spec = _minimal_spec(
            space=[{"name": "training.lr", "type": "float"}]
        )
        with pytest.raises(GridSpecValidationError):
            validate_grid_spec(spec)

    def test_categorical_requires_choices(self):
        """type:categorical, choices 없음 → GridSpecValidationError."""
        spec = _minimal_spec(
            space=[{"name": "injection.lora_r", "type": "categorical"}]
        )
        with pytest.raises(GridSpecValidationError, match="choices"):
            validate_grid_spec(spec)

    def test_categorical_empty_choices(self):
        """type:categorical, choices: [] → GridSpecValidationError."""
        spec = _minimal_spec(
            space=[{"name": "injection.lora_r", "type": "categorical", "choices": []}]
        )
        with pytest.raises(GridSpecValidationError, match="choices"):
            validate_grid_spec(spec)

    def test_space_item_missing_name(self):
        """space 항목에 name 없음 → GridSpecValidationError."""
        spec = _minimal_spec(
            space=[{"type": "float", "low": 1e-6, "high": 1e-4}]
        )
        with pytest.raises(GridSpecValidationError, match="name"):
            validate_grid_spec(spec)

    def test_space_item_missing_type(self):
        """space 항목에 type 없음 → GridSpecValidationError."""
        spec = _minimal_spec(
            space=[{"name": "training.lr", "low": 1e-6, "high": 1e-4}]
        )
        with pytest.raises(GridSpecValidationError, match="type"):
            validate_grid_spec(spec)

    def test_space_item_unknown_type(self):
        """type='continuous' → GridSpecValidationError."""
        spec = _minimal_spec(
            space=[{"name": "training.lr", "type": "continuous", "low": 1e-6, "high": 1e-4}]
        )
        with pytest.raises(GridSpecValidationError, match="type"):
            validate_grid_spec(spec)


# ===========================================================================
# 4. grid method 제약
# ===========================================================================

class TestGridMethodConstraints:
    def test_grid_method_rejects_float_continuous(self):
        """method:grid + type:float + low/high → GridSpecValidationError (규칙 19)."""
        spec = _minimal_spec(
            method="grid",
            space=[{"name": "training.lr", "type": "float", "low": 1e-6, "high": 1e-4}],
        )
        with pytest.raises(GridSpecValidationError, match="grid"):
            validate_grid_spec(spec)

    def test_grid_method_allows_categorical(self):
        """method:grid + type:categorical → 통과."""
        spec = _minimal_spec(
            method="grid",
            space=[
                {"name": "injection.lora_r", "type": "categorical", "choices": [8, 16, 32]}
            ],
        )
        validate_grid_spec(spec)  # 예외 없음

    def test_grid_method_allows_float_with_choices(self):
        """method:grid + type:float + choices → 통과 (연속 범위 아님)."""
        spec = _minimal_spec(
            method="grid",
            space=[
                {"name": "training.lr", "type": "float", "choices": [1e-5, 5e-5, 1e-4]}
            ],
        )
        validate_grid_spec(spec)  # 예외 없음

    def test_grid_method_rejects_int_continuous(self):
        """method:grid + type:int + low/high (step 없이) → GridSpecValidationError."""
        spec = _minimal_spec(
            method="grid",
            space=[{"name": "injection.lora_r", "type": "int", "low": 8, "high": 64}],
        )
        with pytest.raises(GridSpecValidationError, match="grid"):
            validate_grid_spec(spec)

    def test_grid_method_allows_int_with_choices(self):
        """method:grid + type:int + choices → 통과."""
        spec = _minimal_spec(
            method="grid",
            space=[
                {"name": "injection.lora_r", "type": "int", "choices": [8, 16, 32]}
            ],
        )
        validate_grid_spec(spec)  # 예외 없음

    def test_random_allows_float_continuous(self):
        """method:random + type:float + low/high → 통과."""
        spec = _minimal_spec(
            method="random",
            space=[{"name": "training.lr", "type": "float", "low": 1e-6, "high": 1e-4}],
        )
        validate_grid_spec(spec)  # 예외 없음

    def test_bayes_allows_float_continuous(self):
        """method:bayes + type:float + low/high → 통과."""
        spec = _minimal_spec(
            method="bayes",
            space=[{"name": "training.lr", "type": "float", "low": 1e-6, "high": 1e-4}],
        )
        validate_grid_spec(spec)  # 예외 없음

    def test_random_allows_int_continuous(self):
        """method:random + type:int + low/high → 통과."""
        spec = _minimal_spec(
            method="random",
            space=[{"name": "injection.lora_r", "type": "int", "low": 8, "high": 64}],
        )
        validate_grid_spec(spec)  # 예외 없음


# ===========================================================================
# 5. data 섹션 검증
# ===========================================================================

class TestGridDataSection:
    def test_raw_format_requires_task(self):
        """format:raw, task 없음 → GridSpecValidationError (규칙 20)."""
        spec = _minimal_spec(
            data={"format": "raw", "path": "data/sft.jsonl"}
        )
        with pytest.raises(GridSpecValidationError, match="task"):
            validate_grid_spec(spec)

    def test_raw_format_invalid_task(self):
        """format:raw, task='sft2' → GridSpecValidationError."""
        spec = _minimal_spec(
            data={"format": "raw", "path": "data/sft.jsonl", "task": "sft2"}
        )
        with pytest.raises(GridSpecValidationError, match="task"):
            validate_grid_spec(spec)

    def test_processed_format_no_task_needed(self):
        """format:processed → task 없어도 통과."""
        spec = _minimal_spec(
            data={"format": "processed", "path": "data/sft.jsonl"}
        )
        validate_grid_spec(spec)  # 예외 없음

    def test_data_section_optional(self):
        """data 섹션 없음 → 통과 (기본 동작)."""
        spec = _minimal_spec()
        assert "data" not in spec["run"]
        validate_grid_spec(spec)  # 예외 없음

    def test_data_missing_path(self):
        """data 섹션 있고 path 없음 → GridSpecValidationError (규칙 21)."""
        spec = _minimal_spec(
            data={"format": "processed"}
        )
        with pytest.raises(GridSpecValidationError, match="path"):
            validate_grid_spec(spec)

    def test_invalid_data_format(self):
        """format='binary' → GridSpecValidationError."""
        spec = _minimal_spec(
            data={"format": "binary", "path": "data/sft.jsonl"}
        )
        with pytest.raises(GridSpecValidationError, match="format"):
            validate_grid_spec(spec)


# ===========================================================================
# 6. 3-line 에러 포맷 검증
# ===========================================================================

class TestGridErrorFormat:
    def test_error_has_3_line_format(self):
        """GridSpecValidationError는 3-line 포맷 (Category: ... / Fix: ... / See: ...) 포함."""
        spec = _minimal_spec(method="pso")
        with pytest.raises(GridSpecValidationError) as exc_info:
            validate_grid_spec(spec)
        msg = str(exc_info.value)
        assert "\nFix:" in msg
        assert "\nSee:" in msg

    def test_error_attributes(self):
        """GridSpecValidationError는 category, fix, doc 속성을 가진다."""
        spec = _minimal_spec(method="pso")
        with pytest.raises(GridSpecValidationError) as exc_info:
            validate_grid_spec(spec)
        err = exc_info.value
        assert err.category != ""
        assert err.fix != ""
        assert err.doc != ""


# ===========================================================================
# 7. load_and_validate_grid_spec 통합 테스트
# ===========================================================================

class TestLoadAndValidate:
    def test_load_valid_yaml_file(self, tmp_path):
        """유효 YAML 파일을 읽어서 검증 통과."""
        spec_data = _minimal_spec()
        yaml_path = tmp_path / "grid.yml"
        yaml_path.write_text(
            "version: 1\n"
            "base_preset: configs/presets/qwen3.5_0.8b_dense_lora_sft.yml\n"
            "run:\n"
            "  output_root: outputs/grid\n"
            "  max_trials: 5\n"
            "  max_train_steps: 10\n"
            "  objective:\n"
            "    direction: minimize\n"
            "    metric: train/total_loss\n"
            "    step_agg: last\n"
            "search:\n"
            "  method: random\n"
            "  space:\n"
            "    - name: training.lr\n"
            "      type: float\n"
            "      low: 0.000001\n"
            "      high: 0.0001\n",
            encoding="utf-8",
        )
        result = load_and_validate_grid_spec(str(yaml_path))
        assert result["version"] == 1
        assert result["search"]["method"] == "random"

    def test_load_invalid_yaml_file_raises(self, tmp_path):
        """무효 YAML 파일 → GridSpecValidationError."""
        yaml_path = tmp_path / "bad.yml"
        yaml_path.write_text("version: 2\nbase_preset: foo\n", encoding="utf-8")
        with pytest.raises(GridSpecValidationError):
            load_and_validate_grid_spec(str(yaml_path))

    def test_nonexistent_file_raises(self, tmp_path):
        """존재하지 않는 파일 → FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            load_and_validate_grid_spec(str(tmp_path / "nonexistent.yml"))


# ===========================================================================
# bench_eval 검증 (규칙 22-25)
# ===========================================================================

class TestGridBenchEval:
    """run.bench_eval 섹션 검증 테스트."""

    def test_valid_bench_eval(self):
        """유효한 bench_eval 설정은 통과."""
        spec = _minimal_spec()
        spec["run"]["bench_eval"] = {
            "enabled": True,
            "bench_preset": "configs/bench/sft_judge.yml",
        }
        validate_grid_spec(spec)  # Should not raise

    def test_bench_eval_disabled_skips_validation(self):
        """bench_eval.enabled=false면 나머지 필드 검증 건너뜀."""
        spec = _minimal_spec()
        spec["run"]["bench_eval"] = {
            "enabled": False,
        }
        validate_grid_spec(spec)  # Should not raise

    def test_bench_eval_missing_bench_preset(self):
        """bench_eval.enabled=true + bench_preset 없음 → 에러."""
        spec = _minimal_spec()
        spec["run"]["bench_eval"] = {
            "enabled": True,
        }
        with pytest.raises(GridSpecValidationError, match="bench_preset"):
            validate_grid_spec(spec)

    def test_bench_eval_invalid_metric(self):
        """bench_eval.metric이 유효하지 않으면 에러."""
        spec = _minimal_spec()
        spec["run"]["bench_eval"] = {
            "enabled": True,
            "bench_preset": "configs/bench/sft_judge.yml",
            "metric": "invalid_metric",
        }
        with pytest.raises(GridSpecValidationError, match="metric"):
            validate_grid_spec(spec)

    def test_bench_eval_valid_metrics(self):
        """유효한 bench_eval metric들은 통과."""
        for metric in ["avg_score", "target_avg_score", "baseline_avg_score"]:
            spec = _minimal_spec()
            spec["run"]["bench_eval"] = {
                "enabled": True,
                "bench_preset": "configs/bench/sft_judge.yml",
                "metric": metric,
            }
            validate_grid_spec(spec)  # Should not raise

    def test_bench_eval_invalid_checkpoint(self):
        """bench_eval.checkpoint이 유효하지 않으면 에러."""
        spec = _minimal_spec()
        spec["run"]["bench_eval"] = {
            "enabled": True,
            "bench_preset": "configs/bench/sft_judge.yml",
            "checkpoint": "invalid",
        }
        with pytest.raises(GridSpecValidationError, match="checkpoint"):
            validate_grid_spec(spec)
