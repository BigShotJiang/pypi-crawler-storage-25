# tests/test_i18n.py
# -*- coding: utf-8 -*-
"""EulerForge i18n 모듈 테스트."""
from __future__ import annotations

import os

import pytest

from eulerforge.i18n import t, set_lang, get_lang, SUPPORTED_LANGS, DEFAULT_LANG


class TestSetGetLang:
    """언어 설정/조회 테스트."""

    def setup_method(self):
        set_lang(DEFAULT_LANG)

    def test_default_is_ko(self):
        assert get_lang() == "ko"

    def test_set_lang_en(self):
        set_lang("en")
        assert get_lang() == "en"

    def test_set_lang_zh(self):
        set_lang("zh")
        assert get_lang() == "zh"

    def test_set_lang_ja(self):
        set_lang("ja")
        assert get_lang() == "ja"

    def test_set_lang_es(self):
        set_lang("es")
        assert get_lang() == "es"

    def test_set_lang_invalid(self):
        with pytest.raises(ValueError, match="Unsupported language"):
            set_lang("fr")

    def test_supported_langs(self):
        assert SUPPORTED_LANGS == ("ko", "en", "zh", "ja", "es")


class TestTranslationFunction:
    """t() 번역 함수 테스트."""

    def setup_method(self):
        set_lang("ko")

    def test_ko_basic(self):
        result = t("loader.merging_lora", r=48, alpha=96.0)
        assert "LoRA 가중치 병합 중" in result
        assert "r=48" in result
        assert "alpha=96.0" in result

    def test_en_basic(self):
        set_lang("en")
        result = t("loader.merging_lora", r=48, alpha=96.0)
        assert "Merging LoRA weights" in result
        assert "r=48" in result

    def test_zh_basic(self):
        set_lang("zh")
        result = t("loader.merging_lora", r=48, alpha=96.0)
        assert "正在合并 LoRA 权重" in result

    def test_ja_basic(self):
        set_lang("ja")
        result = t("loader.merging_lora", r=48, alpha=96.0)
        assert "LoRA重み統合中" in result

    def test_es_basic(self):
        set_lang("es")
        result = t("loader.merging_lora", r=48, alpha=96.0)
        assert "Fusionando pesos LoRA" in result

    def test_unknown_key_returns_key(self):
        result = t("nonexistent.key")
        assert result == "nonexistent.key"

    def test_unknown_key_with_kwargs(self):
        result = t("nonexistent.{name}", name="test")
        assert result == "nonexistent.test"

    def test_fallback_to_ko_if_lang_missing(self):
        """카탈로그에 해당 언어가 없으면 ko → en → key 순서로 fallback."""
        # 임시로 ko만 있는 메시지를 검증하기 위해
        # validator.passed는 모든 언어가 있으므로, 직접 확인
        set_lang("ko")
        result = t("validator.passed")
        assert "검증" in result or "validation" in result.lower()

    def test_format_args_work(self):
        """format 인자가 올바르게 적용되는지."""
        set_lang("en")
        result = t("bench.sampling", path="data/test.jsonl", k=5, seed=42)
        assert "5" in result
        assert "data/test.jsonl" in result
        assert "42" in result

    def test_no_kwargs_no_error(self):
        """format 인자 없이도 에러 없이 동작."""
        result = t("loader.moe_preserve")
        assert "MoE" in result


class TestCliHelp:
    """CLI --help 국제화 테스트."""

    def setup_method(self):
        set_lang(DEFAULT_LANG)

    def test_help_ko_default(self):
        """기본 --help는 한국어."""
        assert "명령어:" in t("help.commands_header")
        assert "훈련 파이프라인" in t("help.cmd.train")

    def test_help_en(self):
        set_lang("en")
        assert "commands:" in t("help.commands_header")
        assert "Run training pipeline" in t("help.cmd.train")

    def test_help_zh(self):
        set_lang("zh")
        assert "命令:" in t("help.commands_header")

    def test_help_ja(self):
        set_lang("ja")
        assert "コマンド:" in t("help.commands_header")

    def test_help_es(self):
        set_lang("es")
        assert "comandos:" in t("help.commands_header")

    def test_help_all_commands_have_translations(self):
        """모든 서브커맨드 help 키가 5개 언어를 가지고 있어야 한다."""
        from eulerforge.i18n.messages import MESSAGES

        cmd_keys = [k for k in MESSAGES if k.startswith("help.cmd.")]
        assert len(cmd_keys) == 8  # train, convert, preprocess, bench, eval, grid, export_hf, pretrain
        for key in cmd_keys:
            for lang in SUPPORTED_LANGS:
                assert lang in MESSAGES[key], f"{key} missing {lang}"


class TestEnvVarLang:
    """EULERFORGE_LANG 환경변수 테스트."""

    def test_env_var_sets_lang(self, monkeypatch):
        monkeypatch.setenv("EULERFORGE_LANG", "en")
        # 모듈을 다시 로드해야 env var가 반영됨
        import importlib
        import eulerforge.i18n
        importlib.reload(eulerforge.i18n)
        from eulerforge.i18n import get_lang
        assert get_lang() == "en"
        # 정리: 기본값으로 복원
        importlib.reload(eulerforge.i18n)


class TestMessageCatalogCompleteness:
    """메시지 카탈로그 완전성 테스트."""

    def test_all_messages_have_all_langs(self):
        """모든 메시지가 5개 언어를 모두 가지고 있어야 한다."""
        from eulerforge.i18n.messages import MESSAGES

        for key, translations in MESSAGES.items():
            for lang in SUPPORTED_LANGS:
                assert lang in translations, (
                    f"Message '{key}' missing language '{lang}'"
                )

    def test_all_messages_non_empty(self):
        """모든 번역이 비어있지 않아야 한다."""
        from eulerforge.i18n.messages import MESSAGES

        for key, translations in MESSAGES.items():
            for lang, text in translations.items():
                assert text.strip(), (
                    f"Message '{key}' has empty translation for '{lang}'"
                )

    def test_message_count_minimum(self):
        """최소 메시지 수 (핵심 모듈 카버리지 확인)."""
        from eulerforge.i18n.messages import MESSAGES

        assert len(MESSAGES) >= 40, (
            f"Expected at least 40 messages, got {len(MESSAGES)}"
        )
