# tests/test_adapters.py
import pytest
import torch
import torch.nn as nn
from eulerforge.cli.train import _select_backbone_adapter

# 테스트할 모델과 기대되는 Adapter 매핑
# (model_type, adapter_key_name, expected_ffn_attr)
ADAPTER_TEST_CASES = [
    ("qwen", "qwen3", "mlp"),
    ("llama2", "llama", "mlp"),
    ("llama3", "llama", "mlp"),
    ("mistral", "llama", "mlp"),  # Mistral도 Llama 구조 사용
    ("gemma3_1b", "gemma3", "mlp"),  # Gemma 3 1B (text-only)
]

# [수정] create_tiny_model -> real_model_factory 로 변경
@pytest.mark.parametrize("model_type, adapter_key, expected_ffn_attr", ADAPTER_TEST_CASES)
def test_backbone_adapter_structure_detection(
    model_type, adapter_key, expected_ffn_attr, real_model_factory
):
    """
    각 모델 타입(Llama, Qwen 등)에 대해:
    1. Adapter가 올바르게 선택되는지
    2. Transformer Layer 리스트를 찾는지
    3. FFN(MLP) 모듈과 이름을 찾는지
    4. Attention Leaf 모듈(q_proj 등)을 찾는지
    검증합니다.
    """
    print(f"\n>>> [TestAdapter] Checking structure for: {model_type}")

    # 1. Real Model 로드 (Fixture 활용)
    # real_model_factory는 (model, hub_id) 튜플을 반환함
    try:
        model, _ = real_model_factory(model_type)
    except Exception:
        pytest.skip(f"Skipping adapter test for {model_type} (Model load failed or skipped).")

    assert isinstance(model, nn.Module)

    # 2. Adapter 선택 및 초기화 검증
    adapter = _select_backbone_adapter(adapter_key)
    assert adapter is not None
    print(f"    Adapter selected: {adapter.__class__.__name__}")

    # 3. Transformer Layers 탐색 검증
    layers = adapter.find_transformer_layers(model)
    assert isinstance(layers, (list, nn.ModuleList)), "Layers must be a list or ModuleList"
    assert len(layers) > 0, "Should find at least one layer"
    print(f"    [Pass] Found {len(layers)} layers.")

    # 4. Block 내부 구조 분석 (첫 번째 블록 기준)
    block = layers[0]

    # 4-1. FFN 모듈 이름(Attr Name) 검증
    # (이 기능은 MoE 변환 시 setattr을 하기 위해 필수적입니다)
    detected_ffn_name = adapter.find_ffn_attr_name(block)
    assert detected_ffn_name == expected_ffn_attr, \
        f"Expected FFN attr '{expected_ffn_attr}', got '{detected_ffn_name}'"
    
    # 4-2. FFN 모듈 객체 검증
    ffn_module = adapter.find_ffn_module(block)
    assert isinstance(ffn_module, nn.Module), "FFN must be an nn.Module"
    print(f"    [Pass] Found FFN: name='{detected_ffn_name}', type={type(ffn_module).__name__}")

    # 5. Attention Leaf Module 탐색 검증
    # 일반적인 LoRA 타겟 키워드들 (사용자 지정)
    target_keywords = ["q_proj", "k_proj", "v_proj", "o_proj"]

    leaf_modules = adapter.find_attention_leaf_modules(block, target_keywords)

    # Qwen/Llama/Mixtral 모두 최소한 q_proj, v_proj 등은 있어야 함
    assert len(leaf_modules) > 0, f"No attention leaves found with keywords {target_keywords}"

    # backbone-종속 acceptable 키워드:
    # - 표준 self_attn (Llama/Mixtral/Gemma3/Qwen3 표준): q_proj/k_proj/v_proj/o_proj
    # - Qwen3.5 linear_attn (Qwen3_5GatedDeltaNet): in_proj_qkv/out_proj 로 fallback
    acceptable_keywords = list(target_keywords) + ["in_proj_qkv", "out_proj"]
    for path in leaf_modules:
        assert any(k in path for k in acceptable_keywords), (
            f"Path {path} does not contain any of {acceptable_keywords}"
        )
    
    print(f"    [Pass] Found {len(leaf_modules)} attention leaves. Sample: {leaf_modules[:2]}")


def test_select_backbone_adapter_logic():
    """
    _select_backbone_adapter 함수의 분기 로직만 별도로 단위 테스트
    """
    # 1. Qwen
    adapter = _select_backbone_adapter("qwen")
    assert adapter.__class__.__name__ == "Qwen3Adapter"
    
    adapter = _select_backbone_adapter("Qwen/Qwen2.5")
    assert adapter.__class__.__name__ == "Qwen3Adapter"

    # 2. Llama
    adapter = _select_backbone_adapter("llama")
    assert adapter.__class__.__name__ == "LlamaAdapter"
    
    adapter = _select_backbone_adapter("meta-llama/Llama-2-7b")
    assert adapter.__class__.__name__ == "LlamaAdapter"

    # 3. Mixtral (모듈이 있다면)
    try:
        from eulerforge.adapters.backbones.mixtral import MixtralAdapter
        adapter = _select_backbone_adapter("mixtral")
        assert isinstance(adapter, MixtralAdapter)
    except ImportError:
        pass # Mixtral 모듈 구현 전이면 패스

    # 4. Gemma 3
    adapter = _select_backbone_adapter("gemma3")
    assert adapter.__class__.__name__ == "Gemma3Adapter"

    # gemma (no version) falls back to generic
    adapter = _select_backbone_adapter("gemma")
    assert adapter.__class__.__name__ == "BackboneAdapter"

    # 5. Unknown -> Base
    adapter = _select_backbone_adapter("unknown_model_type")
    assert adapter.__class__.__name__ == "BackboneAdapter"