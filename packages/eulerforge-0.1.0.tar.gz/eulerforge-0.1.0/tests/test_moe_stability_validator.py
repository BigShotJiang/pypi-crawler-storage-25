# tests/test_moe_stability_validator.py
"""
TDD tests for MoE Stability Validator.

These tests define the exact contract for MoE stability validation rules:
- (A) Router z-loss: required for MoE, range validation
- (B) Load balancing: required policy specification
- (C) Capacity factor: type/range validation
- (D) Router precision: float32 enforcement
- (E) base_ffn targeting strictness
- (F) Static cross-checks (strategy x phase consistency)

Tests are written FIRST, before implementation. Each test verifies both
that the error is raised AND that the error message is understandable.
"""
from __future__ import annotations

import pytest

from eulerforge.utils.validator import validate_config, ConfigValidationError


# ===========================================================================
# Helpers: build configs quickly
# ===========================================================================

def _moe_cfg(**overrides):
    """Minimal valid MoE config (mixture_lora strategy)."""
    cfg = {
        "backbone": "qwen3",
        "model_name": "Qwen/Qwen3.5-0.8B-Base",
        "injection": {
            "strategy": "mixture_lora",
            "lora_r": 16,
            "lora_alpha": 32,
            "num_experts": 4,
            "top_k": 2,
        },
        "training": {
            "phases": [
                {"step": 0, "trainable": ["router"]},
                {"step": 100, "trainable": ["lora"]},
            ],
        },
        "moe": {
            "router_z_loss_coef": 0.001,
            "load_balance": {
                "type": "aux_loss",
                "aux_loss_coef": 0.01,
            },
        },
    }
    # Apply overrides using dot-notation keys
    for k, v in overrides.items():
        keys = k.split(".")
        d = cfg
        for part in keys[:-1]:
            d = d.setdefault(part, {})
        d[keys[-1]] = v
    return cfg


def _ffn_moe_cfg(**overrides):
    """Minimal valid FFN MoE config (moe_expert_lora strategy)."""
    cfg = {
        "backbone": "qwen3",
        "model_name": "Qwen/Qwen3.5-0.8B-Base",
        "injection": {
            "strategy": "moe_expert_lora",
            "lora_r": 16,
            "lora_alpha": 32,
            "num_experts": 4,
            "top_k": 2,
        },
        "training": {
            "phases": [
                {"step": 0, "trainable": ["router"]},
                {"step": 100, "trainable": ["lora"]},
                {"step": 500, "trainable": ["lora", "router", "base_ffn"]},
            ],
            "phase_target_kwargs": {
                "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"],
            },
        },
        "moe": {
            "router_z_loss_coef": 0.001,
            "load_balance": {
                "type": "aux_loss",
                "aux_loss_coef": 0.01,
            },
        },
    }
    for k, v in overrides.items():
        keys = k.split(".")
        d = cfg
        for part in keys[:-1]:
            d = d.setdefault(part, {})
        d[keys[-1]] = v
    return cfg


def _dense_lora_cfg(**overrides):
    """Minimal valid dense_lora config (NO MoE)."""
    cfg = {
        "backbone": "qwen3",
        "model_name": "Qwen/Qwen3.5-0.8B-Base",
        "injection": {
            "strategy": "dense_lora",
            "lora_r": 16,
            "lora_alpha": 32,
        },
        "training": {
            "phases": [
                {"step": 0, "trainable": ["lora"]},
            ],
        },
    }
    for k, v in overrides.items():
        keys = k.split(".")
        d = cfg
        for part in keys[:-1]:
            d = d.setdefault(part, {})
        d[keys[-1]] = v
    return cfg


# ===========================================================================
# (0) Valid configs should PASS
# ===========================================================================

class TestMoEValidConfigs:
    """All of these should pass without error."""

    def test_minimal_mixture_lora_with_moe_section(self):
        validate_config(_moe_cfg())

    def test_moe_expert_lora_with_moe_section(self):
        validate_config(_ffn_moe_cfg())

    def test_dense_lora_no_moe_section(self):
        """dense_lora doesn't need moe section at all."""
        validate_config(_dense_lora_cfg())

    def test_aux_loss_free_load_balance(self):
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"] = {
            "type": "aux_loss_free",
            "bias_update_speed": 0.001,
        }
        validate_config(cfg)

    def test_load_balance_none_with_warning(self):
        """type=none should pass (with warning) not error."""
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"] = {"type": "none"}
        validate_config(cfg)

    def test_capacity_factor_valid(self):
        cfg = _moe_cfg()
        cfg["moe"]["capacity_factor_train"] = 1.25
        cfg["moe"]["capacity_factor_eval"] = 2.0
        validate_config(cfg)

    def test_router_dtype_float32(self):
        cfg = _moe_cfg()
        cfg["moe"]["router_dtype"] = "float32"
        validate_config(cfg)

    def test_z_loss_coef_zero_passes_with_warning(self):
        """z-loss = 0 should warn but not error."""
        cfg = _moe_cfg()
        cfg["moe"]["router_z_loss_coef"] = 0.0
        validate_config(cfg)


# ===========================================================================
# (A) Router z-loss validation
# ===========================================================================

class TestRouterZLoss:
    """Router z-loss is REQUIRED for MoE strategies."""

    def test_moe_missing_moe_section_entirely(self):
        """MoE strategy with no 'moe' section at all -> error."""
        cfg = _moe_cfg()
        del cfg["moe"]
        with pytest.raises(ConfigValidationError, match="requires.*moe.*section"):
            validate_config(cfg)

    def test_moe_missing_router_z_loss_coef(self):
        """MoE strategy with moe section but no router_z_loss_coef -> error."""
        cfg = _moe_cfg()
        del cfg["moe"]["router_z_loss_coef"]
        with pytest.raises(ConfigValidationError, match="router_z_loss_coef.*required"):
            validate_config(cfg)

    def test_z_loss_coef_negative(self):
        cfg = _moe_cfg()
        cfg["moe"]["router_z_loss_coef"] = -0.01
        with pytest.raises(ConfigValidationError, match="router_z_loss_coef.*>= 0"):
            validate_config(cfg)

    def test_z_loss_coef_not_a_number(self):
        cfg = _moe_cfg()
        cfg["moe"]["router_z_loss_coef"] = "high"
        with pytest.raises(ConfigValidationError, match="router_z_loss_coef.*numeric"):
            validate_config(cfg)

    def test_z_loss_coef_nan(self):
        cfg = _moe_cfg()
        cfg["moe"]["router_z_loss_coef"] = float("nan")
        with pytest.raises(ConfigValidationError, match="router_z_loss_coef.*finite"):
            validate_config(cfg)

    def test_z_loss_coef_inf(self):
        cfg = _moe_cfg()
        cfg["moe"]["router_z_loss_coef"] = float("inf")
        with pytest.raises(ConfigValidationError, match="router_z_loss_coef.*finite"):
            validate_config(cfg)

    def test_z_loss_coef_very_large_warns(self, caplog):
        """z-loss > 0.1 should produce a warning."""
        cfg = _moe_cfg()
        cfg["moe"]["router_z_loss_coef"] = 0.5
        import logging
        with caplog.at_level(logging.WARNING):
            validate_config(cfg)
        assert any("router_z_loss_coef" in r.message and "large" in r.message.lower()
                    for r in caplog.records)


# ===========================================================================
# (B) Load balancing validation
# ===========================================================================

class TestLoadBalancing:
    """Load balance policy must be explicitly specified for MoE."""

    def test_missing_load_balance_section(self):
        cfg = _moe_cfg()
        del cfg["moe"]["load_balance"]
        with pytest.raises(ConfigValidationError, match="load_balance.*required"):
            validate_config(cfg)

    def test_load_balance_missing_type(self):
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"] = {"aux_loss_coef": 0.01}
        with pytest.raises(ConfigValidationError, match="load_balance.type.*required"):
            validate_config(cfg)

    def test_load_balance_unknown_type(self):
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"] = {"type": "magic_balance"}
        with pytest.raises(ConfigValidationError, match="load_balance.type.*unknown"):
            validate_config(cfg)

    def test_aux_loss_type_missing_coef(self):
        """type=aux_loss requires aux_loss_coef."""
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"] = {"type": "aux_loss"}
        with pytest.raises(ConfigValidationError, match="aux_loss_coef.*required"):
            validate_config(cfg)

    def test_aux_loss_coef_negative(self):
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"]["aux_loss_coef"] = -1.0
        with pytest.raises(ConfigValidationError, match="aux_loss_coef.*>= 0"):
            validate_config(cfg)

    def test_aux_loss_coef_not_number(self):
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"]["aux_loss_coef"] = "auto"
        with pytest.raises(ConfigValidationError, match="aux_loss_coef.*numeric"):
            validate_config(cfg)

    def test_aux_loss_coef_nan(self):
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"]["aux_loss_coef"] = float("nan")
        with pytest.raises(ConfigValidationError, match="aux_loss_coef.*finite"):
            validate_config(cfg)

    def test_aux_loss_coef_zero_warns(self, caplog):
        """aux_loss_coef=0 with type=aux_loss is suspicious -> warn."""
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"]["aux_loss_coef"] = 0.0
        import logging
        with caplog.at_level(logging.WARNING):
            validate_config(cfg)
        assert any("aux_loss_coef" in r.message and "0" in r.message
                    for r in caplog.records)

    def test_aux_loss_free_missing_bias_update_speed(self):
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"] = {"type": "aux_loss_free"}
        with pytest.raises(ConfigValidationError, match="bias_update_speed.*required"):
            validate_config(cfg)

    def test_aux_loss_free_bias_update_speed_not_number(self):
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"] = {
            "type": "aux_loss_free",
            "bias_update_speed": "fast",
        }
        with pytest.raises(ConfigValidationError, match="bias_update_speed.*numeric"):
            validate_config(cfg)

    def test_load_balance_none_warns(self, caplog):
        """type=none should warn about routing collapse risk."""
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"] = {"type": "none"}
        import logging
        with caplog.at_level(logging.WARNING):
            validate_config(cfg)
        assert any("load_balance" in r.message and "none" in r.message.lower()
                    for r in caplog.records)


# ===========================================================================
# (C) Capacity factor validation
# ===========================================================================

class TestCapacityFactor:
    """Capacity factor validation (optional but strict if present)."""

    def test_capacity_factor_train_not_number(self):
        cfg = _moe_cfg()
        cfg["moe"]["capacity_factor_train"] = "auto"
        with pytest.raises(ConfigValidationError, match="capacity_factor_train.*numeric"):
            validate_config(cfg)

    def test_capacity_factor_train_zero(self):
        cfg = _moe_cfg()
        cfg["moe"]["capacity_factor_train"] = 0.0
        with pytest.raises(ConfigValidationError, match="capacity_factor_train.*> 0"):
            validate_config(cfg)

    def test_capacity_factor_train_negative(self):
        cfg = _moe_cfg()
        cfg["moe"]["capacity_factor_train"] = -1.0
        with pytest.raises(ConfigValidationError, match="capacity_factor_train.*> 0"):
            validate_config(cfg)

    def test_capacity_factor_eval_not_number(self):
        cfg = _moe_cfg()
        cfg["moe"]["capacity_factor_eval"] = True
        with pytest.raises(ConfigValidationError, match="capacity_factor_eval.*numeric"):
            validate_config(cfg)

    def test_capacity_factor_eval_zero(self):
        cfg = _moe_cfg()
        cfg["moe"]["capacity_factor_eval"] = 0.0
        with pytest.raises(ConfigValidationError, match="capacity_factor_eval.*> 0"):
            validate_config(cfg)

    def test_capacity_factor_eval_lt_train_warns(self, caplog):
        """eval < train is suspicious (ST-MoE uses eval CF > train CF)."""
        cfg = _moe_cfg()
        cfg["moe"]["capacity_factor_train"] = 2.0
        cfg["moe"]["capacity_factor_eval"] = 1.0
        import logging
        with caplog.at_level(logging.WARNING):
            validate_config(cfg)
        assert any("capacity_factor_eval" in r.message and "less" in r.message.lower()
                    for r in caplog.records)

    def test_capacity_factor_inf(self):
        cfg = _moe_cfg()
        cfg["moe"]["capacity_factor_train"] = float("inf")
        with pytest.raises(ConfigValidationError, match="capacity_factor_train.*finite"):
            validate_config(cfg)


# ===========================================================================
# (D) Router precision / dtype validation
# ===========================================================================

class TestRouterPrecision:
    """Router should default to float32 for numerical stability."""

    def test_router_dtype_bf16_warns(self, caplog):
        """bfloat16 router is risky for numerical stability."""
        cfg = _moe_cfg()
        cfg["moe"]["router_dtype"] = "bfloat16"
        import logging
        with caplog.at_level(logging.WARNING):
            validate_config(cfg)
        assert any("router_dtype" in r.message and "float32" in r.message
                    for r in caplog.records)

    def test_router_dtype_fp16_warns(self, caplog):
        cfg = _moe_cfg()
        cfg["moe"]["router_dtype"] = "float16"
        import logging
        with caplog.at_level(logging.WARNING):
            validate_config(cfg)
        assert any("router_dtype" in r.message and "float32" in r.message
                    for r in caplog.records)

    def test_router_dtype_invalid_errors(self):
        cfg = _moe_cfg()
        cfg["moe"]["router_dtype"] = "int8"
        with pytest.raises(ConfigValidationError, match="router_dtype.*invalid"):
            validate_config(cfg)


# ===========================================================================
# (E) base_ffn targeting strictness
# ===========================================================================

class TestBaseFfnTargeting:
    """base_ffn group requires explicit keywords when used in phases."""

    def test_base_ffn_in_phase_without_keywords_error(self):
        """base_ffn in trainable but no base_ffn_keywords anywhere -> error."""
        cfg = _moe_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora", "router", "base_ffn"]},
        ]
        # No phase_target_kwargs, no per-phase base_ffn_keywords
        with pytest.raises(ConfigValidationError, match="base_ffn.*base_ffn_keywords"):
            validate_config(cfg)

    def test_base_ffn_with_global_keywords_passes(self):
        """base_ffn with global phase_target_kwargs.base_ffn_keywords -> pass."""
        cfg = _moe_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora", "router", "base_ffn"]},
        ]
        cfg["training"]["phase_target_kwargs"] = {
            "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"],
        }
        validate_config(cfg)

    def test_base_ffn_with_per_phase_keywords_passes(self):
        """base_ffn with per-phase base_ffn_keywords -> pass."""
        cfg = _moe_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora", "router", "base_ffn"],
             "base_ffn_keywords": ["gate_proj", "up_proj", "down_proj"]},
        ]
        validate_config(cfg)

    def test_base_ffn_empty_keywords_error(self):
        """base_ffn_keywords present but empty -> error."""
        cfg = _moe_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora", "router", "base_ffn"],
             "base_ffn_keywords": []},
        ]
        with pytest.raises(ConfigValidationError, match="base_ffn_keywords.*empty"):
            validate_config(cfg)

    def test_base_ffn_overly_broad_keyword_warns(self, caplog):
        """Very short keyword like 'proj' could match too many params -> warn."""
        cfg = _moe_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora", "router", "base_ffn"],
             "base_ffn_keywords": ["proj"]},
        ]
        import logging
        with caplog.at_level(logging.WARNING):
            validate_config(cfg)
        assert any("base_ffn_keywords" in r.message and "broad" in r.message.lower()
                    for r in caplog.records)

    def test_target_layers_negative_error(self):
        """Negative target_layers should be caught."""
        cfg = _moe_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora", "router", "base_ffn"],
             "base_ffn_keywords": ["gate_proj"],
             "target_layers": [0, -1, 2]},
        ]
        with pytest.raises(ConfigValidationError, match="target_layers.*negative"):
            validate_config(cfg)

    def test_target_layers_duplicate_error(self):
        """Duplicate target_layers should error."""
        cfg = _moe_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["router"]},
            {"step": 100, "trainable": ["lora", "router", "base_ffn"],
             "base_ffn_keywords": ["gate_proj"],
             "target_layers": [2, 3, 2]},
        ]
        with pytest.raises(ConfigValidationError, match="target_layers.*duplicate"):
            validate_config(cfg)


# ===========================================================================
# (F) MoE-phase cross-checks (static)
# ===========================================================================

class TestMoEPhaseCrossChecks:
    """Cross-check between MoE injection and phase schedule."""

    def test_moe_no_router_in_any_phase_warns(self, caplog):
        """MoE injection but router never appears in any phase -> warn."""
        cfg = _moe_cfg()
        cfg["training"]["phases"] = [
            {"step": 0, "trainable": ["lora"]},
        ]
        import logging
        with caplog.at_level(logging.WARNING):
            validate_config(cfg)
        assert any("router" in r.message and "never" in r.message.lower()
                    for r in caplog.records)

    def test_dense_lora_with_moe_section_warns(self, caplog):
        """dense_lora doesn't need moe section; if present -> warn."""
        cfg = _dense_lora_cfg()
        cfg["moe"] = {
            "router_z_loss_coef": 0.001,
            "load_balance": {"type": "aux_loss", "aux_loss_coef": 0.01},
        }
        import logging
        with caplog.at_level(logging.WARNING):
            validate_config(cfg)
        assert any("moe" in r.message.lower() and "dense_lora" in r.message
                    for r in caplog.records)


# ===========================================================================
# (G) Common MoE config typos
# ===========================================================================

class TestMoETypos:
    """Catch common typos in MoE config."""

    def test_typo_zloss_instead_of_z_loss(self):
        cfg = _moe_cfg()
        del cfg["moe"]["router_z_loss_coef"]
        cfg["moe"]["router_zloss_coef"] = 0.001
        with pytest.raises(ConfigValidationError, match="router_z_loss_coef"):
            validate_config(cfg)

    def test_typo_aux_coef_instead_of_aux_loss_coef(self):
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"] = {
            "type": "aux_loss",
            "aux_coef": 0.01,
        }
        with pytest.raises(ConfigValidationError, match="aux_loss_coef"):
            validate_config(cfg)

    def test_typo_balance_type_instead_of_type(self):
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"] = {
            "balance_type": "aux_loss",
            "aux_loss_coef": 0.01,
        }
        with pytest.raises(ConfigValidationError, match="balance_type.*type"):
            validate_config(cfg)

    def test_moe_section_is_not_dict(self):
        cfg = _moe_cfg()
        cfg["moe"] = "enabled"
        with pytest.raises(ConfigValidationError, match="moe.*dict"):
            validate_config(cfg)

    def test_load_balance_is_not_dict(self):
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"] = "aux_loss"
        with pytest.raises(ConfigValidationError, match="load_balance.*dict"):
            validate_config(cfg)


# ===========================================================================
# (H) Non-MoE strategies should NOT require moe section
# ===========================================================================

# ===========================================================================
# (I) 3-line error format for MoE validator errors
# ===========================================================================

class TestMoEThreeLineErrorFormat:
    """MoE validator errors must use structured 3-line format (Category/Fix/See)."""

    def test_missing_moe_section_has_three_line_format(self):
        """Missing moe section error should have category, fix, doc."""
        cfg = _moe_cfg()
        del cfg["moe"]
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        e = exc_info.value
        assert e.category, "error must have category"
        assert e.fix, "error must have fix"
        assert e.doc, "error must have doc"
        assert "Fix:" in str(e)
        assert "See:" in str(e)

    def test_missing_router_z_loss_coef_has_three_line_format(self):
        cfg = _moe_cfg()
        del cfg["moe"]["router_z_loss_coef"]
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        e = exc_info.value
        assert e.category, "error must have category"
        assert e.fix, "error must have fix"
        assert e.doc, "error must have doc"
        assert "0.001" in e.fix, "fix should suggest recommended value"

    def test_missing_load_balance_has_three_line_format(self):
        cfg = _moe_cfg()
        del cfg["moe"]["load_balance"]
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        e = exc_info.value
        assert e.category, "error must have category"
        assert e.fix, "error must have fix"
        assert e.doc, "error must have doc"

    def test_missing_aux_loss_coef_has_three_line_format(self):
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"] = {"type": "aux_loss"}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        e = exc_info.value
        assert e.category, "error must have category"
        assert e.fix, "error must have fix"
        assert "0.01" in e.fix, "fix should suggest recommended value"
        assert e.doc, "error must have doc"

    def test_missing_bias_update_speed_has_three_line_format(self):
        cfg = _moe_cfg()
        cfg["moe"]["load_balance"] = {"type": "aux_loss_free"}
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        e = exc_info.value
        assert e.category, "error must have category"
        assert e.fix, "error must have fix"
        assert e.doc, "error must have doc"

    def test_invalid_router_dtype_has_three_line_format(self):
        cfg = _moe_cfg()
        cfg["moe"]["router_dtype"] = "int8"
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        e = exc_info.value
        assert e.category, "error must have category"
        assert e.fix, "error must have fix"
        assert "float32" in e.fix, "fix should suggest float32"
        assert e.doc, "error must have doc"

    def test_negative_z_loss_coef_has_three_line_format(self):
        cfg = _moe_cfg()
        cfg["moe"]["router_z_loss_coef"] = -0.01
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        e = exc_info.value
        assert e.category, "error must have category"
        assert e.fix, "error must have fix"
        assert e.doc, "error must have doc"

    def test_moe_error_doc_points_to_tutorial(self):
        """All MoE errors should point to the MoE stability tutorial."""
        cfg = _moe_cfg()
        del cfg["moe"]
        with pytest.raises(ConfigValidationError) as exc_info:
            validate_config(cfg)
        e = exc_info.value
        assert "moe_stability" in e.doc or "09_moe" in e.doc, \
            f"doc should reference MoE stability tutorial, got: {e.doc}"


class TestNonMoEStrategies:
    """Non-MoE strategies (dense_lora) should not be affected by moe rules."""

    def test_dense_lora_no_moe_section_passes(self):
        validate_config(_dense_lora_cfg())

    def test_native_moe_requires_moe_section(self):
        """native_moe_expert_lora also has routing -> needs moe section."""
        cfg = {
            "backbone": "mixtral",
            "model_name": "TitanML/tiny-mixtral",
            "injection": {
                "strategy": "native_moe_expert_lora",
                "lora_r": 16,
                "lora_alpha": 32,
                "target_keywords": ["w1", "w2", "w3"],
            },
            "training": {
                "phases": [{"step": 0, "trainable": ["lora"]}],
            },
        }
        # native_moe_expert_lora: router already exists in model, but we still
        # want users to think about stability. However, native MoE doesn't create
        # new routers, so moe section is NOT strictly required.
        # This should pass since native_moe doesn't inject new routers.
        validate_config(cfg)
