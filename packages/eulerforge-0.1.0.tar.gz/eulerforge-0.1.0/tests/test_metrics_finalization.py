# tests/test_metrics_finalization.py
# -*- coding: utf-8 -*-
"""
Metrics 파일 종료 시점 보장 테스트.

Regression: grid search에서 max_train_steps < log_steps이면 collector.log_step이
한 번도 호출되지 않아 metrics.jsonl이 생성되지 않고, grid가 `_extract_metric`에서
FileNotFoundError로 실패하는 버그.

수정: 훈련 루프 종료 시 마지막 log 이후 step이 있으면 항상 최소 1건을 기록한다.
"""
from __future__ import annotations

import inspect
import json
import os

import pytest

from eulerforge.utils.metrics import MetricsCollector, TBWriter


class TestMetricsFinalization:
    """훈련 종료 시 metrics.jsonl이 항상 생성되는지 검증."""

    def test_training_loop_has_finalize_metrics_marker(self):
        """run_training에 final metrics 기록 마커가 존재해야 한다.

        훈련 루프 종료 시 log_steps 주기와 무관하게 최소 1건의 metrics를 기록해야 함
        (grid search에서 max_train_steps < log_steps인 짧은 훈련 대응).

        마커: `# [FINALIZE_METRICS]` 주석 또는 `_write_final_metrics_record` 호출
        """
        from eulerforge.cli.train import run_training
        source = inspect.getsource(run_training)

        assert "[FINALIZE_METRICS]" in source, (
            "Expected finalization marker '# [FINALIZE_METRICS]' in run_training. "
            "Add a final collector.log_step after the main training loop so that "
            "metrics.jsonl is guaranteed to exist even when max_train_steps < log_steps."
        )

    def test_metrics_collector_creates_file_on_first_log(self, tmp_path):
        """MetricsCollector는 첫 log_step에서 jsonl 파일을 생성한다."""
        import torch.nn as nn

        jsonl_path = str(tmp_path / "metrics.jsonl")
        tb = TBWriter(enabled=False, log_dir=str(tmp_path / "tb"))
        collector = MetricsCollector(
            level="minimal",
            tb_writer=tb,
            log_interval=1,
            jsonl_path=jsonl_path,
        )

        # 한 번 호출하면 파일이 생성되어야 함
        model = nn.Linear(2, 2)
        collector.log_step(
            step=1,
            main_loss=0.5,
            total_loss=0.5,
            aux_loss=None,
            lr=1e-5,
            metrics={},
            model=model,
            tokens_seen=100,
            samples_seen=10,
            optimizer_step=1,
            effective_batch=8,
        )
        assert os.path.isfile(jsonl_path)
        with open(jsonl_path) as f:
            line = f.readline().strip()
            record = json.loads(line)
        assert record["step"] == 1
        assert "train/main_loss" in record
        assert record["train/main_loss"] == 0.5


class TestGridShortTrainingScenario:
    """grid search 짧은 훈련(log_steps > max_train_steps) 엔드투엔드 시뮬레이션."""

    def test_extract_metric_requires_jsonl(self, tmp_path):
        """metrics.jsonl 없으면 명확한 에러가 발생해야 한다."""
        from eulerforge.utils.grid_engine import _extract_metric

        missing_path = str(tmp_path / "metrics.jsonl")
        with pytest.raises(FileNotFoundError):
            _extract_metric(missing_path, {"direction": "minimize", "metric": "train/total_loss"})

    def test_extract_metric_reads_single_record(self, tmp_path):
        """metrics.jsonl에 1건만 있어도 정상 추출."""
        from eulerforge.utils.grid_engine import _extract_metric

        path = str(tmp_path / "metrics.jsonl")
        with open(path, "w") as f:
            f.write(json.dumps({"step": 20, "train/total_loss": 1.234, "train/main_loss": 1.234}) + "\n")

        val = _extract_metric(path, {"direction": "minimize", "metric": "train/total_loss"})
        assert val == pytest.approx(1.234)
