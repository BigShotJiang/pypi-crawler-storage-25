# eulerforge/loader.py
# -*- coding: utf-8 -*-
"""
EulerForge 공용 모델 로더.

훈련된 체크포인트(run_dir 또는 checkpoint_dir)를 자동 탐지하여
model + tokenizer + metadata를 반환한다.

사용 예:
    from eulerforge.loader import load_model

    result = load_model("outputs/run_20260311_163425")
    result.model        # nn.Module (eval 모드)
    result.tokenizer    # PreTrainedTokenizer
    result.metadata     # ModelMetadata
"""
from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from typing import Any, Dict, Optional

from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer

logger = logging.getLogger(__name__)

_VALID_LOAD_PRECISIONS = ("fp32", "fp16", "bf16", "int8", "int4")

_PRECISION_DTYPE_MAP = {
    "fp32": "float32",
    "fp16": "float16",
    "bf16": "bfloat16",
}


# =========================================================================
# 데이터 클래스
# =========================================================================
@dataclass
class ModelMetadata:
    """로드된 모델의 메타데이터."""

    strategy: str  # "dense_lora" | "moe_expert_lora" | "mixture_lora" | "none"
    backbone: str  # "qwen3" | "llama" | "gemma3" | ""
    path_type: str  # "run_dir" | "checkpoint_dir"
    checkpoint_dir: str  # 실제 체크포인트 디렉토리 경로
    lora_config: Optional[Dict[str, Any]]  # {"lora_r": int, "lora_alpha": float, ...}
    structure_preserved: bool  # MoE/MixtureLoRA 구조 보존 여부
    load_precision: Optional[str] = None  # "fp32"|"fp16"|"bf16"|"int8"|"int4"|None


@dataclass
class LoadedModel:
    """load_model() 반환 타입."""

    model: Any  # nn.Module
    tokenizer: Any  # PreTrainedTokenizer
    metadata: ModelMetadata


# =========================================================================
# 경로 분류
# =========================================================================
def _classify_path(path: str) -> str:
    """경로 유형 판별.

    Returns:
        "run_dir" — resolved_config.json 존재 (EulerForge 훈련 출력 디렉토리)
        "checkpoint_dir" — config.json 존재 (HF 체크포인트 또는 모델 디렉토리)

    Raises:
        ValueError: 어떤 유형으로도 식별할 수 없을 때
    """
    if not os.path.isdir(path):
        raise ValueError(
            f"EulerForge 체크포인트를 식별할 수 없습니다: "
            f"경로가 존재하지 않거나 디렉토리가 아닙니다: {path}\n"
            f"Fix: 유효한 run_dir 또는 checkpoint_dir 경로를 지정하세요.\n"
            f"See: docs/tutorials/11_bench.md"
        )

    # run_dir: resolved_config.json 존재
    if os.path.isfile(os.path.join(path, "resolved_config.json")):
        return "run_dir"

    # checkpoint_dir: config.json 존재
    if os.path.isfile(os.path.join(path, "config.json")):
        return "checkpoint_dir"

    raise ValueError(
        f"EulerForge 체크포인트를 식별할 수 없습니다: {path}\n"
        f"Fix: resolved_config.json 또는 config.json이 있는 디렉토리를 지정하세요.\n"
        f"See: docs/tutorials/11_bench.md"
    )


# =========================================================================
# 체크포인트 디렉토리 해석
# =========================================================================
_CHECKPOINT_MAP = {
    "final": "final",
    "best": "checkpoint-best",
    "latest": "checkpoint-latest",
}


def _resolve_checkpoint_dir(run_dir: str, checkpoint: str = "final") -> str:
    """run_dir 내에서 체크포인트 서브디렉토리 경로를 해석.

    Args:
        run_dir: EulerForge 훈련 출력 디렉토리
        checkpoint: "final" | "best" | "latest"

    Returns:
        체크포인트 디렉토리의 절대 경로

    Raises:
        ValueError: 해당 체크포인트 디렉토리가 존재하지 않을 때
    """
    subdir_name = _CHECKPOINT_MAP.get(checkpoint, checkpoint)
    ckpt_dir = os.path.join(run_dir, subdir_name)
    if os.path.isdir(ckpt_dir):
        return ckpt_dir

    raise ValueError(
        f"체크포인트 디렉토리를 찾을 수 없습니다: {ckpt_dir}\n"
        f"Fix: '{checkpoint}' 대신 존재하는 체크포인트를 지정하세요.\n"
        f"See: docs/tutorials/11_bench.md"
    )


# =========================================================================
# 양자화 헬퍼
# =========================================================================
def _make_bnb_config(precision: str):
    """BitsAndBytesConfig 생성.

    Args:
        precision: "int4" 또는 "int8"

    Returns:
        BitsAndBytesConfig 인스턴스
    """
    import torch
    from transformers import BitsAndBytesConfig

    if precision == "int4":
        return BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
        )
    elif precision == "int8":
        return BitsAndBytesConfig(
            load_in_8bit=True,
        )
    else:
        raise ValueError(f"_make_bnb_config: unsupported precision '{precision}'")


# =========================================================================
# 내부 로딩 함수
# =========================================================================
def _load_checkpoint(
    checkpoint_dir: str,
    *,
    device: str = "auto",
    dtype: str = "auto",
    lora_cfg: Optional[Dict] = None,
    resolved_cfg: Optional[Dict] = None,
    load_precision: Optional[str] = None,
    trust_remote_code: bool = False,
) -> tuple:
    """체크포인트 디렉토리에서 (model, tokenizer)를 로드.

    bench_client.py의 LocalHFClient.__init__ 로직을 재사용.

    Returns:
        (model, tokenizer) 튜플
    """
    import torch
    from eulerforge.i18n import t

    # RTX 5090 CUBLAS 워크어라운드
    if torch.cuda.is_available():
        torch.backends.cuda.preferred_blas_library("cublaslt")

    torch_dtype = getattr(torch, dtype) if dtype not in ("auto", None) else "auto"

    # bench_client의 기존 함수들을 재사용
    from eulerforge.utils.bench_client import (
        _dequantize_bnb_state_dict,
        _detect_moe_type,
        _find_lora_config,
        _load_state_dict_from_checkpoint,
        _merge_lora_state_dict,
        _normalize_merged_keys,
        _reconstruct_mixture_lora_model,
        _reconstruct_moe_model,
        _resize_embeddings_if_needed,
        _safe_torch_dtype,
    )

    # LoRA 체크포인트 탐지
    if lora_cfg is None:
        lora_cfg = _find_lora_config(checkpoint_dir)

    has_lora = False
    has_moe_experts = False
    state_dict = None

    if lora_cfg:
        state_dict = _load_state_dict_from_checkpoint(checkpoint_dir)
        if state_dict is not None:
            import re
            has_lora = any(
                "lora_A" in k or "lora_B" in k or "loraA" in k or "loraB" in k
                for k in state_dict
            )
            has_moe_experts = any(
                re.search(r"\.mlp\.experts\.\d+\.", k) for k in state_dict
            )

    needs_merge = (
        (has_lora or has_moe_experts)
        and lora_cfg is not None
        and state_dict is not None
    )

    if needs_merge:
        r = lora_cfg["lora_r"]
        alpha = lora_cfg["lora_alpha"]
        moe_type = lora_cfg.get("strategy", "") or ""
        if moe_type not in ("moe_expert_lora", "mixture_lora"):
            moe_type = _detect_moe_type(state_dict)

        if moe_type == "moe_expert_lora":
            if resolved_cfg:
                logger.info(t("loader.moe_preserve"))
                model = _reconstruct_moe_model(
                    model_dir=checkpoint_dir,
                    resolved_cfg=resolved_cfg,
                    state_dict=state_dict,
                    lora_cfg=lora_cfg,
                    torch_dtype=torch_dtype,
                    device=device,
                )
                tokenizer = AutoTokenizer.from_pretrained(checkpoint_dir)
                _resize_embeddings_if_needed(model, tokenizer)
                return (model, tokenizer)
            else:
                from eulerforge.utils.bench_client import (
                    _merge_moe_expert_lora_state_dict,
                )
                logger.warning(t("loader.no_resolved_config_fallback"))
                state_dict = _dequantize_bnb_state_dict(state_dict)
                merged_sd = _merge_moe_expert_lora_state_dict(
                    state_dict, r, alpha
                )

        elif moe_type == "mixture_lora":
            if resolved_cfg:
                logger.info(t("loader.mixture_lora_preserve"))
                model = _reconstruct_mixture_lora_model(
                    model_dir=checkpoint_dir,
                    resolved_cfg=resolved_cfg,
                    state_dict=state_dict,
                    lora_cfg=lora_cfg,
                    torch_dtype=torch_dtype,
                    device=device,
                )
                tokenizer = AutoTokenizer.from_pretrained(checkpoint_dir)
                _resize_embeddings_if_needed(model, tokenizer)
                return (model, tokenizer)
            else:
                from eulerforge.utils.bench_client import (
                    _merge_mixture_lora_state_dict,
                )
                logger.warning(t("loader.no_resolved_config_fallback"))
                state_dict = _dequantize_bnb_state_dict(state_dict)
                merged_sd = _merge_mixture_lora_state_dict(state_dict, r, alpha)

        else:
            logger.info(t("loader.merging_lora", r=r, alpha=alpha))
            state_dict = _dequantize_bnb_state_dict(state_dict)
            merged_sd = _merge_lora_state_dict(state_dict, r, alpha)

        config = AutoConfig.from_pretrained(checkpoint_dir)
        model = AutoModelForCausalLM.from_config(config)
        if torch_dtype != "auto":
            torch_dtype = _safe_torch_dtype(torch_dtype)
            model = model.to(torch_dtype)
        merged_sd = _normalize_merged_keys(
            merged_sd, set(model.state_dict().keys())
        )
        missing, unexpected = model.load_state_dict(merged_sd, strict=False)
        model.tie_weights()
        tied_keys = set(getattr(model, "_tied_weights_keys", {}).keys())
        true_missing = [k for k in missing if k not in tied_keys]
        if true_missing:
            logger.warning(
                t("loader.merge_missing_keys",
                  missing=len(true_missing), unexpected=0)
                + f" — {true_missing[:5]}"
            )
        if unexpected:
            logger.warning(t("loader.unexpected_keys", count=len(unexpected)))
        target_device = (
            "cuda" if device == "auto" and torch.cuda.is_available()
            else ("cpu" if device == "auto" else device)
        )
        model = model.to(target_device)
    else:
        # load_precision에 따라 dtype / quantization_config 결정
        effective_dtype = torch_dtype
        bnb_config = None
        if load_precision in ("int4", "int8"):
            bnb_config = _make_bnb_config(load_precision)
            effective_dtype = "auto"
        elif load_precision in _PRECISION_DTYPE_MAP:
            effective_dtype = getattr(torch, _PRECISION_DTYPE_MAP[load_precision])

        from_kwargs: Dict[str, Any] = {
            "device_map": device,
            "torch_dtype": effective_dtype,
        }
        if bnb_config is not None:
            from_kwargs["quantization_config"] = bnb_config
        if trust_remote_code:
            from_kwargs["trust_remote_code"] = True

        model = AutoModelForCausalLM.from_pretrained(
            checkpoint_dir,
            **from_kwargs,
        )

    tokenizer = AutoTokenizer.from_pretrained(checkpoint_dir)
    _resize_embeddings_if_needed(model, tokenizer)
    model.eval()
    return (model, tokenizer)


# =========================================================================
# 공용 API
# =========================================================================
def load_model(
    path: str,
    *,
    checkpoint: str = "final",
    device: str = "auto",
    dtype: str = "auto",
    load_precision: Optional[str] = None,
) -> LoadedModel:
    """EulerForge 체크포인트를 로드하여 LoadedModel을 반환.

    Args:
        path: run_dir 또는 checkpoint_dir 경로
        checkpoint: run_dir일 때 사용할 체크포인트 ("final" | "best" | "latest")
        device: "auto" | "cpu" | "cuda" | "cuda:0" 등
        dtype: "auto" | "float32" | "bfloat16" 등
        load_precision: 로드 정밀도. None(기본) | "fp32" | "fp16" | "bf16" | "int8" | "int4"

    Returns:
        LoadedModel(model, tokenizer, metadata)

    Raises:
        ValueError: 경로를 식별할 수 없거나 체크포인트가 없을 때
    """
    if load_precision is not None and load_precision not in _VALID_LOAD_PRECISIONS:
        raise ValueError(
            f"유효하지 않은 load_precision: '{load_precision}'\n"
            f"Fix: {', '.join(_VALID_LOAD_PRECISIONS)} 중 하나를 지정하세요.\n"
            f"See: docs/tutorials/15_loading_models.md"
        )

    if not os.path.exists(path):
        raise ValueError(
            f"EulerForge 체크포인트를 식별할 수 없습니다: "
            f"경로가 존재하지 않습니다: {path}\n"
            f"Fix: 유효한 run_dir 또는 checkpoint_dir 경로를 지정하세요.\n"
            f"See: docs/tutorials/11_bench.md"
        )

    path_type = _classify_path(path)

    # resolved_config.json 로드 (run_dir에서 직접, checkpoint_dir에서 parent)
    resolved_cfg = None
    lora_cfg = None
    backbone = ""
    strategy = "none"
    lora_config_out = None

    if path_type == "run_dir":
        # run_dir → resolved_config.json 직접 읽기
        rc_path = os.path.join(path, "resolved_config.json")
        if os.path.isfile(rc_path):
            try:
                with open(rc_path, "r", encoding="utf-8") as f:
                    resolved_cfg = json.load(f)
            except (json.JSONDecodeError, OSError):
                pass

        if resolved_cfg:
            backbone = resolved_cfg.get("backbone", "")
            injection = resolved_cfg.get("injection", {})
            strategy = injection.get("strategy", "none") or "none"
            lora_r = injection.get("lora_r", 0)
            lora_alpha = injection.get("lora_alpha", 1.0)
            if lora_r and "lora" in strategy.lower():
                lora_cfg = {
                    "lora_r": int(lora_r),
                    "lora_alpha": float(lora_alpha),
                    "strategy": strategy,
                }
                lora_config_out = {"lora_r": int(lora_r), "lora_alpha": float(lora_alpha)}

        checkpoint_dir = _resolve_checkpoint_dir(path, checkpoint)

    else:
        # checkpoint_dir → 직접 사용
        checkpoint_dir = path
        # parent에서 resolved_config.json 탐색
        parent = os.path.dirname(os.path.abspath(path))
        rc_path = os.path.join(parent, "resolved_config.json")
        if os.path.isfile(rc_path):
            try:
                with open(rc_path, "r", encoding="utf-8") as f:
                    resolved_cfg = json.load(f)
            except (json.JSONDecodeError, OSError):
                pass

        # lora_info.json 또는 resolved_config에서 LoRA 설정 탐색
        from eulerforge.utils.bench_client import _find_lora_config
        lora_cfg = _find_lora_config(checkpoint_dir)
        if lora_cfg:
            strategy = lora_cfg.get("strategy", "none") or "none"
            lora_config_out = {
                "lora_r": lora_cfg["lora_r"],
                "lora_alpha": lora_cfg["lora_alpha"],
            }

    # structure_preserved 판별
    structure_preserved = strategy in ("moe_expert_lora", "mixture_lora")

    # 모델 로드
    model, tokenizer = _load_checkpoint(
        checkpoint_dir,
        device=device,
        dtype=dtype,
        lora_cfg=lora_cfg,
        resolved_cfg=resolved_cfg,
        load_precision=load_precision,
    )

    metadata = ModelMetadata(
        strategy=strategy,
        backbone=backbone,
        path_type=path_type,
        checkpoint_dir=checkpoint_dir,
        lora_config=lora_config_out,
        structure_preserved=structure_preserved,
        load_precision=load_precision,
    )

    return LoadedModel(model=model, tokenizer=tokenizer, metadata=metadata)
