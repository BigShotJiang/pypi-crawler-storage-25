# -*- coding: utf-8 -*-
from importlib.metadata import PackageNotFoundError, version as _pkg_version

from eulerforge.loader import LoadedModel, ModelMetadata, load_model

try:
    __version__ = _pkg_version("eulerforge")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"

__all__ = ["load_model", "LoadedModel", "ModelMetadata", "__version__"]
