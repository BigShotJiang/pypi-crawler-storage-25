# -*- coding: utf-8 -*-
"""Self-contained HF model templates for EulerForge MoE export."""
