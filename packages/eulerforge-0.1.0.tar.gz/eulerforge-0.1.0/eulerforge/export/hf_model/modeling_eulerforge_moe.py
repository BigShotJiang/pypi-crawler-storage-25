# modeling_eulerforge_moe.py
# -*- coding: utf-8 -*-
"""
EulerForge MoE — HuggingFace PreTrainedModel.

이 파일은 eulerforge 의존성이 ZERO인 self-contained 파일입니다.
export 시 output 디렉토리에 복사되어 trust_remote_code=True로 로드됩니다.

지원 구조:
- moe_expert_lora: MoEFFN (N expert FFN + router)
- mixture_lora: MixtureLoRALinear (base + router + N LoRA expert branches)
"""
import os
import re
from typing import List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoConfig, AutoModelForCausalLM, PreTrainedModel

from .configuration_eulerforge_moe import EulerForgeMoEConfig


# ─────────────────────────────────────────────────
# MoEFFN Export (moe_expert_lora)
# ─────────────────────────────────────────────────

class MoEFFNExport(nn.Module):
    """MoE FFN — router + N expert FFN dispatch."""

    def __init__(self, experts: nn.ModuleList, router: nn.Linear,
                 hidden_size: int, top_k: int = 2):
        super().__init__()
        self.experts = experts
        self.router = router
        self.hidden_size = hidden_size
        self.num_experts = len(experts)
        self.top_k = top_k

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() == 3:
            B, S, H = x.shape
            t = x.reshape(B * S, H)
            reshape_back = (B, S, -1)
        else:
            t = x
            reshape_back = None

        logits = self.router(t)
        gate_prob = F.softmax(logits, dim=-1)
        topk_w, topk_idx = torch.topk(gate_prob, k=self.top_k, dim=-1)
        topk_w = topk_w / (topk_w.sum(dim=-1, keepdim=True) + 1e-9)

        T = t.size(0)
        out_dim = self.experts[0].gate_proj.out_features if hasattr(self.experts[0], 'gate_proj') else self.hidden_size
        y = torch.zeros((T, out_dim), device=t.device, dtype=t.dtype)

        for k_idx in range(self.top_k):
            idx_k = topk_idx[:, k_idx]
            w_k = topk_w[:, k_idx].unsqueeze(-1)
            for e in range(self.num_experts):
                mask = (idx_k == e)
                if not mask.any():
                    continue
                y[mask] += self.experts[e](t[mask]) * w_k[mask]

        if reshape_back is not None:
            y = y.reshape(*reshape_back)
        return y


# ─────────────────────────────────────────────────
# LoRA Branch Export (mixture_lora)
# ─────────────────────────────────────────────────

class LoRABranchExport(nn.Module):
    """loraA @ loraB * scaling."""

    def __init__(self, loraA: nn.Parameter, loraB: nn.Parameter,
                 r: int, alpha: float):
        super().__init__()
        self.loraA = loraA
        self.loraB = loraB
        self.scaling = alpha / r

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = F.linear(x, self.loraA)
        return F.linear(z, self.loraB) * self.scaling


class MixtureLoRALinearExport(nn.Module):
    """base + router + N LoRA experts dispatch."""

    def __init__(self, base_layer: nn.Linear, router: nn.Linear,
                 experts: nn.ModuleList, top_k: int = 2):
        super().__init__()
        self.base_layer = base_layer
        self.router = router
        self.experts = experts
        self.num_experts = len(experts)
        self.top_k = top_k

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        base_out = self.base_layer(x)

        if x.dim() == 3:
            B, S, H = x.shape
            t = x.reshape(B * S, H)
            reshape_back = (B, S, base_out.size(-1))
        else:
            t = x
            reshape_back = None

        logits = self.router(t)
        gate_prob = F.softmax(logits, dim=-1)
        topk_w, topk_idx = torch.topk(gate_prob, k=self.top_k, dim=-1)
        topk_w = topk_w / (topk_w.sum(dim=-1, keepdim=True) + 1e-9)

        T = t.size(0)
        delta = torch.zeros((T, base_out.size(-1)), device=t.device, dtype=base_out.dtype)

        for k_idx in range(self.top_k):
            idx_k = topk_idx[:, k_idx]
            w_k = topk_w[:, k_idx].unsqueeze(-1)
            for e in range(self.num_experts):
                mask = (idx_k == e)
                if not mask.any():
                    continue
                delta[mask] += self.experts[e](t[mask]) * w_k[mask]

        if reshape_back is not None:
            delta = delta.reshape(*reshape_back)
        return base_out + delta


# ─────────────────────────────────────────────────
# Main Model
# ─────────────────────────────────────────────────

class EulerForgeMoEForCausalLM(PreTrainedModel):
    """EulerForge MoE 모델 — HuggingFace 호환.

    trust_remote_code=True로 로드:
        model = AutoModelForCausalLM.from_pretrained(path, trust_remote_code=True)

    설계:
    - from_pretrained 시 base 모델을 먼저 로드하고,
      export된 state dict를 적용하는 2단계 로딩.
    - __init__에서 inner_model을 생성하지 않고,
      from_pretrained 클래스메서드에서 전체 로딩을 처리.
    """

    config_class = EulerForgeMoEConfig
    supports_gradient_checkpointing = False
    _tied_weights_keys = []

    def __init__(self, config: EulerForgeMoEConfig):
        super().__init__(config)
        if not hasattr(self, "all_tied_weights_keys"):
            self.all_tied_weights_keys = {}
        # inner_model은 from_pretrained에서 설정됨
        # __init__만 호출되는 경우 (from_config) None으로 시작
        self.inner_model = None

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path, *args, **kwargs):
        """Base 모델을 로드하고 export된 state dict를 적용."""
        # 1. config 로드
        config_path = os.path.join(pretrained_model_name_or_path, "config.json")
        config = EulerForgeMoEConfig.from_pretrained(pretrained_model_name_or_path)

        # 2. Base 모델 로드 (원본 HF 모델)
        base_model_name = config.base_model_name
        if not base_model_name:
            raise ValueError(
                "config.json에 base_model_name이 필요합니다.\n"
                "Fix: export 시 base_model_name이 포함되었는지 확인하세요.\n"
                "See: docs/tutorials/16_export_hf.md"
            )

        # kwargs에서 device_map, torch_dtype 등 추출
        device_map = kwargs.pop("device_map", None)
        torch_dtype = kwargs.pop("torch_dtype", None)
        trust_remote_code = kwargs.pop("trust_remote_code", True)

        inner_model = AutoModelForCausalLM.from_pretrained(
            base_model_name,
            device_map=device_map,
            torch_dtype=torch_dtype,
            trust_remote_code=True,
        )

        # 3. Export된 state dict 로드
        export_sd = None
        bin_path = os.path.join(pretrained_model_name_or_path, "pytorch_model.bin")
        safetensors_path = os.path.join(pretrained_model_name_or_path, "model.safetensors")

        if os.path.isfile(bin_path):
            export_sd = torch.load(bin_path, map_location="cpu", weights_only=True)
        elif os.path.isfile(safetensors_path):
            from safetensors.torch import load_file
            export_sd = load_file(safetensors_path)

        if export_sd is not None:
            # state dict 키 정규화: export 키 → inner_model 키 매핑
            inner_sd = inner_model.state_dict()
            inner_keys = set(inner_sd.keys())

            # 직접 매칭 시도
            matched = set(export_sd.keys()) & inner_keys
            unmatched_export = set(export_sd.keys()) - inner_keys

            if unmatched_export and matched == set():
                # 키 prefix 정규화 시도 (e.g., model.language_model.X → model.X)
                normalized = {}
                for k, v in export_sd.items():
                    new_key = k
                    # common prefix normalization patterns
                    if k.startswith("model.language_model."):
                        new_key = "model." + k[len("model.language_model."):]
                    normalized[new_key] = v
                export_sd = normalized

            # strict=False로 로드 (MoE 레이어가 변경된 상태이므로)
            missing, unexpected = inner_model.load_state_dict(export_sd, strict=False)
            # MoE/LoRA 키는 unexpected로 남을 수 있음 — 정상

        # 4. EulerForgeMoEForCausalLM 인스턴스 생성
        instance = cls.__new__(cls)
        PreTrainedModel.__init__(instance, config)
        if not hasattr(instance, "all_tied_weights_keys"):
            instance.all_tied_weights_keys = {}
        instance.inner_model = inner_model

        return instance

    @property
    def device(self):
        """inner_model의 device 반환."""
        if self.inner_model is not None:
            return self.inner_model.device
        return torch.device("cpu")

    def forward(self, **kwargs):
        if self.inner_model is not None:
            return self.inner_model(**kwargs)
        raise NotImplementedError("inner_model not initialized")

    def generate(self, *args, **kwargs):
        if self.inner_model is not None:
            return self.inner_model.generate(*args, **kwargs)
        raise NotImplementedError("inner_model not initialized")

    def prepare_inputs_for_generation(self, *args, **kwargs):
        if self.inner_model is not None:
            return self.inner_model.prepare_inputs_for_generation(*args, **kwargs)
        raise NotImplementedError("inner_model not initialized")
