# configuration_eulerforge_moe.py
# -*- coding: utf-8 -*-
"""
EulerForge MoE — HuggingFace PretrainedConfig.

이 파일은 eulerforge 의존성이 ZERO인 self-contained 파일입니다.
export 시 output 디렉토리에 복사되어 trust_remote_code=True로 로드됩니다.
"""
from transformers import PretrainedConfig


class EulerForgeMoEConfig(PretrainedConfig):
    """EulerForge MoE 모델 설정."""

    model_type = "eulerforge_moe"

    def __init__(
        self,
        base_model_type: str = "",
        training_type: str = "",
        num_experts: int = 4,
        top_k: int = 2,
        lora_r: int = 0,
        lora_alpha: float = 0.0,
        target_keywords: list = None,
        hidden_size: int = 0,
        layer_indices: list = None,
        export_format_version: str = "1.0",
        base_model_name: str = "",
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.base_model_type = base_model_type
        self.training_type = training_type
        self.num_experts = num_experts
        self.top_k = top_k
        self.lora_r = lora_r
        self.lora_alpha = lora_alpha
        self.target_keywords = target_keywords or []
        self.hidden_size = hidden_size
        self.layer_indices = layer_indices or []
        self.export_format_version = export_format_version
        self.base_model_name = base_model_name
