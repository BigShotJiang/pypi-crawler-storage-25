# eulerforge/export/planner.py
# -*- coding: utf-8 -*-
"""
Export planner — 체크포인트 분석 → ExportPlan 생성.

재사용:
- loader._classify_path(), _resolve_checkpoint_dir()
- bench_client._find_lora_config(), _find_resolved_config(), _detect_moe_type()
"""
from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


@dataclass
class ExportPlan:
    """Export 실행 계획."""

    strategy: str  # "dense_lora" | "mixture_lora" | "moe_expert_lora"
    format: str  # "merged" | "custom_moe"
    checkpoint_dir: str
    output_dir: str
    resolved_cfg: Optional[Dict[str, Any]]
    lora_cfg: Optional[Dict[str, Any]]
    dtype: str  # "auto" | "fp32" | "fp16" | "bf16"
    safe_serialization: bool
    copy_tokenizer: bool
    backbone: str
    skip_diversity_check: bool = False


@dataclass
class ExportResult:
    """Export 결과."""

    output_dir: str
    format: str
    strategy: str
    num_files: int


_FORMAT_AUTO_MAP = {
    "dense_lora": "merged",
    "mixture_lora": "custom_moe",
    "moe_expert_lora": "custom_moe",
}

_MOE_STRATEGIES = {"mixture_lora", "moe_expert_lora"}


def plan_export(
    checkpoint: str,
    output: str,
    *,
    format: str = "auto",
    select_checkpoint: str = "final",
    dtype: str = "auto",
    safe_serialization: bool = True,
    copy_tokenizer: bool = True,
) -> ExportPlan:
    """체크포인트를 분석하여 ExportPlan을 생성.

    Args:
        checkpoint: run_dir 또는 checkpoint_dir 경로
        output: export 출력 디렉토리
        format: "auto" | "merged" | "custom_moe"
        select_checkpoint: "final" | "best" | "latest"
        dtype: "auto" | "fp32" | "fp16" | "bf16"
        safe_serialization: safetensors 사용 여부
        copy_tokenizer: tokenizer 복사 여부

    Returns:
        ExportPlan

    Raises:
        ValueError: 경로, 설정 등의 유효성 검증 실패
    """
    # E2: output 이미 존재하면 에러
    if os.path.exists(output):
        raise ValueError(
            f"Export 출력 디렉토리가 이미 존재합니다: {output}\n"
            f"Fix: 새 경로를 지정하거나 기존 디렉토리를 삭제하세요.\n"
            f"See: docs/tutorials/16_export_hf.md"
        )

    # 경로 분류
    from eulerforge.loader import _classify_path, _resolve_checkpoint_dir

    path_type = _classify_path(checkpoint)

    resolved_cfg = None
    lora_cfg = None
    backbone = ""
    strategy = "dense_lora"

    if path_type == "run_dir":
        # resolved_config.json 로드
        rc_path = os.path.join(checkpoint, "resolved_config.json")
        if os.path.isfile(rc_path):
            with open(rc_path, "r", encoding="utf-8") as f:
                resolved_cfg = json.load(f)

        if resolved_cfg:
            backbone = resolved_cfg.get("backbone", "")
            injection = resolved_cfg.get("injection", {})
            strategy = injection.get("strategy", "dense_lora") or "dense_lora"
            lora_r = injection.get("lora_r", 0)
            lora_alpha = injection.get("lora_alpha", 1.0)
            if lora_r:
                lora_cfg = {
                    "lora_r": int(lora_r),
                    "lora_alpha": float(lora_alpha),
                    "strategy": strategy,
                }

        checkpoint_dir = _resolve_checkpoint_dir(checkpoint, select_checkpoint)

    else:
        # checkpoint_dir 직접 사용
        checkpoint_dir = checkpoint

        # resolved_config 탐색
        from eulerforge.utils.bench_client import _find_resolved_config

        resolved_cfg = _find_resolved_config(checkpoint_dir)

        # lora_info 탐색
        from eulerforge.utils.bench_client import _find_lora_config

        lora_cfg = _find_lora_config(checkpoint_dir)
        if lora_cfg:
            strategy = lora_cfg.get("strategy", "dense_lora") or "dense_lora"

        if resolved_cfg:
            backbone = resolved_cfg.get("backbone", "")
            injection = resolved_cfg.get("injection", {})
            if not strategy or strategy == "dense_lora":
                strategy = injection.get("strategy", strategy) or strategy

    # format 자동 결정
    if format == "auto":
        export_format = _FORMAT_AUTO_MAP.get(strategy, "merged")
    else:
        export_format = format

    # E13: merged + MoE → ValueError
    if export_format == "merged" and strategy in _MOE_STRATEGIES:
        raise ValueError(
            f"merged 포맷은 MoE 전략 '{strategy}'의 expert 구조를 파괴합니다.\n"
            f"Fix: --format auto 또는 --format custom_moe를 사용하세요.\n"
            f"See: docs/tutorials/16_export_hf.md"
        )

    # E14: custom_moe + resolved_config 없음 → ValueError
    if export_format == "custom_moe" and resolved_cfg is None:
        raise ValueError(
            f"custom_moe export에는 resolved_config.json이 필요합니다.\n"
            f"Fix: run_dir를 지정하거나 checkpoint의 parent에 resolved_config.json을 배치하세요.\n"
            f"See: docs/tutorials/16_export_hf.md"
        )

    return ExportPlan(
        strategy=strategy,
        format=export_format,
        checkpoint_dir=checkpoint_dir,
        output_dir=output,
        resolved_cfg=resolved_cfg,
        lora_cfg=lora_cfg,
        dtype=dtype,
        safe_serialization=safe_serialization,
        copy_tokenizer=copy_tokenizer,
        backbone=backbone,
    )
