# eulerforge/export/custom_moe.py
# -*- coding: utf-8 -*-
"""
MoE/MixtureLoRA → custom_moe HF export.

Expert 구조를 보존하면서 HuggingFace 호환 모델 디렉토리로 내보낸다.
trust_remote_code=True로 로드 가능한 self-contained 모델.
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
from collections import defaultdict
from typing import Any, Dict, Optional, Set

import torch

from eulerforge.export.planner import ExportPlan, ExportResult

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────
# Per-Expert LoRA Merge
# ─────────────────────────────────────────────────

def _merge_per_expert_lora(
    state_dict: Dict[str, Any],
    lora_r: int,
    lora_alpha: float,
) -> Dict[str, Any]:
    """moe_expert_lora 체크포인트의 per-expert LoRA를 병합.

    변환:
        *.experts.N.{proj}.base_layer.weight + lora_A/B → *.experts.N.{proj}.weight
        router 키 보존, expert 구조 보존.
        LoRA 키가 없는 경우 (handoff 완료) passthrough.
    """
    scaling = lora_alpha / lora_r

    expert_lora_pat = re.compile(
        r"^(.+\.experts\.\d+\.\w+_proj)\.(base_layer\.weight|lora_A|lora_B)$"
    )

    # LoRA 키 수집
    expert_bases: Dict[str, torch.Tensor] = {}
    expert_lora_a: Dict[str, torch.Tensor] = {}
    expert_lora_b: Dict[str, torch.Tensor] = {}
    normal: Dict[str, Any] = {}

    for k, v in state_dict.items():
        m = expert_lora_pat.match(k)
        if m:
            prefix, param_type = m.group(1), m.group(2)
            if param_type == "base_layer.weight":
                expert_bases[prefix] = v
            elif param_type == "lora_A":
                expert_lora_a[prefix] = v
            elif param_type == "lora_B":
                expert_lora_b[prefix] = v
        else:
            normal[k] = v

    # LoRA 키가 없으면 passthrough
    if not expert_bases and not expert_lora_a:
        return dict(state_dict)

    merged = dict(normal)

    for prefix, base_w in expert_bases.items():
        a = expert_lora_a.get(prefix)
        b = expert_lora_b.get(prefix)
        if a is not None and b is not None:
            orig_dtype = base_w.dtype
            delta = (b.float() @ a.float()) * scaling
            merged[f"{prefix}.weight"] = (base_w.float() + delta).to(orig_dtype)
        else:
            merged[f"{prefix}.weight"] = base_w

    return merged


# ─────────────────────────────────────────────────
# Anti-Averaging Guard
# ─────────────────────────────────────────────────

def _check_expert_diversity(state_dict: Dict[str, Any], num_experts: int) -> None:
    """Expert weights가 서로 다른지 검증.

    모든 expert의 gate_proj.weight가 동일하면 averaging이 발생한 것으로 판단.
    """
    # layer별로 expert gate_proj weights 수집
    expert_pat = re.compile(
        r"^(.+\.mlp)\.experts\.(\d+)\.gate_proj\.weight$"
    )

    layer_experts: Dict[str, Dict[int, torch.Tensor]] = defaultdict(dict)
    for k, v in state_dict.items():
        m = expert_pat.match(k)
        if m:
            layer_prefix = m.group(1)
            expert_idx = int(m.group(2))
            layer_experts[layer_prefix][expert_idx] = v

    for layer_prefix, experts in layer_experts.items():
        if len(experts) < 2:
            continue

        weights = list(experts.values())
        if all(torch.equal(weights[0], w) for w in weights[1:]):
            raise ValueError(
                f"Export: Expert weights are identical in {layer_prefix} — "
                f"averaging detected.\n"
                f"Fix: 체크포인트의 expert weights가 분화되었는지 확인하세요.\n"
                f"See: docs/tutorials/16_export_hf.md"
            )


# ─────────────────────────────────────────────────
# Template File Copy
# ─────────────────────────────────────────────────

def _copy_template_files(output_dir: str) -> None:
    """HF model 템플릿 파일을 output 디렉토리에 복사."""
    template_dir = os.path.join(
        os.path.dirname(__file__), "hf_model"
    )

    for fname in ("configuration_eulerforge_moe.py", "modeling_eulerforge_moe.py"):
        src = os.path.join(template_dir, fname)
        dst = os.path.join(output_dir, fname)
        shutil.copy2(src, dst)


# ─────────────────────────────────────────────────
# Config Generation
# ─────────────────────────────────────────────────

def _build_export_config(
    plan: ExportPlan,
    base_config: Dict[str, Any],
) -> Dict[str, Any]:
    """export config.json 생성."""
    injection = plan.resolved_cfg.get("injection", {}) if plan.resolved_cfg else {}

    config = dict(base_config)
    # custom_moe export에서는 quantization 정보 제거 (이미 dequantized weights)
    config.pop("quantization_config", None)
    config["model_type"] = "eulerforge_moe"
    config["auto_map"] = {
        "AutoConfig": "configuration_eulerforge_moe.EulerForgeMoEConfig",
        "AutoModelForCausalLM": "modeling_eulerforge_moe.EulerForgeMoEForCausalLM",
    }

    # base_model_name: from_pretrained에서 원본 모델 로드에 필요
    base_model_name = ""
    if plan.resolved_cfg:
        base_model_name = plan.resolved_cfg.get("model_name", "") or plan.resolved_cfg.get("model", {}).get("name", "")
    config["base_model_name"] = base_model_name

    config["eulerforge_export"] = {
        "training_type": plan.strategy,
        "base_model": base_model_name,
        "base_model_type": base_config.get("model_type", ""),
        "num_experts": injection.get("num_experts", 4),
        "top_k": injection.get("top_k", 2),
        "hidden_size": base_config.get("hidden_size", 0),
        "lora_r": plan.lora_cfg.get("lora_r", 0) if plan.lora_cfg else 0,
        "lora_alpha": plan.lora_cfg.get("lora_alpha", 0) if plan.lora_cfg else 0,
        "target_keywords": injection.get("target_keywords", []),
        "export_format_version": "1.0",
    }

    return config


# ─────────────────────────────────────────────────
# Main Export
# ─────────────────────────────────────────────────

def export_custom_moe(plan: ExportPlan) -> ExportResult:
    """MoE/MixtureLoRA 체크포인트를 custom_moe HF 모델로 export.

    moe_expert_lora:
    1. state dict 로드 + dequantize
    2. per-expert LoRA 병합 + attention LoRA 병합
    3. anti-averaging guard
    4. config + template 복사 + state dict 저장

    mixture_lora:
    1. state dict 로드 + dequantize
    2. attention LoRA만 병합, MixtureLoRA 보존
    3. config + template 복사 + state dict 저장
    """
    from eulerforge.utils.bench_client import (
        _dequantize_bnb_state_dict,
        _load_state_dict_from_checkpoint,
        _merge_attention_lora_only,
    )

    os.makedirs(plan.output_dir, exist_ok=True)

    # 1. State dict 로드
    from eulerforge.i18n import t
    logger.info(t("export.custom_moe_loading", path=plan.checkpoint_dir))
    state_dict = _load_state_dict_from_checkpoint(plan.checkpoint_dir)
    if state_dict is None:
        raise ValueError(
            f"체크포인트에서 state dict를 찾을 수 없습니다: {plan.checkpoint_dir}\n"
            f"Fix: pytorch_model.bin 또는 model.safetensors가 있는지 확인하세요.\n"
            f"See: docs/tutorials/16_export_hf.md"
        )

    # 2. Dequantize
    state_dict = _dequantize_bnb_state_dict(state_dict)

    # 3. 전략별 처리
    r = plan.lora_cfg["lora_r"] if plan.lora_cfg else 8
    alpha = plan.lora_cfg["lora_alpha"] if plan.lora_cfg else 16.0

    if plan.strategy == "moe_expert_lora":
        # Per-expert LoRA 병합
        state_dict = _merge_per_expert_lora(state_dict, r, alpha)

        # Attention LoRA도 병합
        # attention LoRA keys가 있는지 확인
        has_attn_lora = any(
            "self_attn" in k and ("lora_A" in k or "lora_B" in k)
            for k in state_dict
        )
        if has_attn_lora:
            # attention LoRA keys를 별도로 병합
            state_dict = _merge_attention_lora_for_moe(state_dict, r, alpha)

        # Anti-averaging guard
        if not plan.skip_diversity_check:
            injection = plan.resolved_cfg.get("injection", {}) if plan.resolved_cfg else {}
            num_experts = injection.get("num_experts", 4)
            _check_expert_diversity(state_dict, num_experts)
        else:
            logger.warning(t("export.skip_diversity_check"))

    elif plan.strategy == "mixture_lora":
        # Attention LoRA만 병합, MixtureLoRA 보존
        state_dict = _merge_attention_lora_only(state_dict, r, alpha)

    # 4. Base config 로드
    config_path = os.path.join(plan.checkpoint_dir, "config.json")
    base_config: Dict[str, Any] = {}
    if os.path.isfile(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            base_config = json.load(f)

    # 5. Export config 생성
    export_config = _build_export_config(plan, base_config)

    # 6. 파일 저장
    # config.json
    with open(os.path.join(plan.output_dir, "config.json"), "w", encoding="utf-8") as f:
        json.dump(export_config, f, indent=2, ensure_ascii=False)

    # state dict
    torch.save(state_dict, os.path.join(plan.output_dir, "pytorch_model.bin"))

    # template files
    _copy_template_files(plan.output_dir)

    # tokenizer
    if plan.copy_tokenizer:
        _copy_tokenizer_files(plan.checkpoint_dir, plan.output_dir)

    num_files = len([f for f in os.listdir(plan.output_dir) if os.path.isfile(
        os.path.join(plan.output_dir, f)
    )])

    return ExportResult(
        output_dir=plan.output_dir,
        format="custom_moe",
        strategy=plan.strategy,
        num_files=num_files,
    )


def _merge_attention_lora_for_moe(
    state_dict: Dict[str, Any],
    lora_r: int,
    lora_alpha: float,
) -> Dict[str, Any]:
    """moe_expert_lora에서 attention LoRA만 병합.

    MoE expert 키는 이미 _merge_per_expert_lora로 처리되었으므로
    attention base_layer + lora_A/B만 병합한다.
    """
    scaling = lora_alpha / lora_r
    merged: Dict[str, Any] = {}
    attn_bases: Dict[str, torch.Tensor] = {}
    attn_lora_a: Dict[str, torch.Tensor] = {}
    attn_lora_b: Dict[str, torch.Tensor] = {}

    for k, v in state_dict.items():
        if k.endswith(".base_layer.weight") and "self_attn" in k:
            prefix = k[: -len(".base_layer.weight")]
            attn_bases[prefix] = v
        elif k.endswith(".base_layer.bias") and "self_attn" in k:
            prefix = k[: -len(".base_layer.bias")]
            merged[f"{prefix}.bias"] = v
        elif k.endswith(".lora_A") and "self_attn" in k:
            prefix = k[: -len(".lora_A")]
            attn_lora_a[prefix] = v
        elif k.endswith(".lora_B") and "self_attn" in k:
            prefix = k[: -len(".lora_B")]
            attn_lora_b[prefix] = v
        else:
            merged[k] = v

    for prefix, base_w in attn_bases.items():
        a = attn_lora_a.get(prefix)
        b = attn_lora_b.get(prefix)
        if a is not None and b is not None:
            orig_dtype = base_w.dtype
            delta = (b.float() @ a.float()) * scaling
            merged[f"{prefix}.weight"] = (base_w.float() + delta).to(orig_dtype)
        else:
            merged[f"{prefix}.weight"] = base_w

    return merged


def _copy_tokenizer_files(src_dir: str, dst_dir: str) -> None:
    """토크나이저 관련 파일 복사."""
    tokenizer_files = [
        "tokenizer_config.json",
        "tokenizer.json",
        "tokenizer.model",
        "special_tokens_map.json",
        "added_tokens.json",
        "vocab.json",
        "merges.txt",
    ]
    for fname in tokenizer_files:
        src = os.path.join(src_dir, fname)
        if os.path.isfile(src):
            shutil.copy2(src, os.path.join(dst_dir, fname))
