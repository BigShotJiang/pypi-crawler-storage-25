# eulerforge/export/merged.py
# -*- coding: utf-8 -*-
"""
dense_lora → merged HF 모델 export.

LoRA 병합 후 표준 HF 모델로 저장한다.
"""
from __future__ import annotations

import json
import logging
import os
from typing import Any, Dict

from eulerforge.export.planner import ExportPlan, ExportResult
from eulerforge.loader import load_model

logger = logging.getLogger(__name__)

_DTYPE_MAP = {
    "fp32": "float32",
    "fp16": "float16",
    "bf16": "bfloat16",
}


def export_merged(plan: ExportPlan) -> ExportResult:
    """dense_lora 체크포인트를 merged HF 모델로 export.

    플로우:
    1. load_model()로 LoRA 병합된 모델 로드
    2. model.save_pretrained()
    3. tokenizer.save_pretrained() (옵션)
    4. config.json에 eulerforge_export 메타데이터 주입
    """
    os.makedirs(plan.output_dir, exist_ok=True)

    # dtype 변환
    hf_dtype = _DTYPE_MAP.get(plan.dtype, plan.dtype)
    if hf_dtype == "auto":
        hf_dtype = "auto"

    # 모델 로드 (LoRA 병합 포함)
    from eulerforge.i18n import t
    logger.info(t("export.merged_loading", path=plan.checkpoint_dir))
    result = load_model(
        plan.checkpoint_dir,
        device="cpu",
        dtype=hf_dtype,
    )

    model = result.model
    tokenizer = result.tokenizer

    # 모델 저장
    logger.info(t("export.merged_saving", path=plan.output_dir))
    model.save_pretrained(
        plan.output_dir,
        safe_serialization=plan.safe_serialization,
    )

    # tokenizer 저장
    if plan.copy_tokenizer:
        tokenizer.save_pretrained(plan.output_dir)

    # config.json에 eulerforge_export 메타데이터 주입
    config_path = os.path.join(plan.output_dir, "config.json")
    config_data: Dict[str, Any] = {}
    if os.path.isfile(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            config_data = json.load(f)
    else:
        config_data = model.config.to_dict()

    base_model = ""
    if plan.resolved_cfg:
        base_model = plan.resolved_cfg.get("model", {}).get("name", "")

    # merged export에서는 quantization 정보 제거 (이미 dequantized bf16 weights)
    config_data.pop("quantization_config", None)

    config_data["eulerforge_export"] = {
        "training_type": plan.strategy,
        "base_model": base_model,
        "lora_merged": True,
        "export_format_version": "1.0",
    }

    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config_data, f, indent=2, ensure_ascii=False)

    # 파일 수 세기
    num_files = len([f for f in os.listdir(plan.output_dir) if os.path.isfile(
        os.path.join(plan.output_dir, f)
    )])

    return ExportResult(
        output_dir=plan.output_dir,
        format="merged",
        strategy=plan.strategy,
        num_files=num_files,
    )
