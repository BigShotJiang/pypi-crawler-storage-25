# eulerforge/utils/preflight.py
# -*- coding: utf-8 -*-
"""
Runtime Preflight Validator.

Runs AFTER model load + injection to check:
1. Group param counts: if a phase references a group, that group must have > 0 params
2. target_layers bounds: layer indices don't exceed model depth
3. base_ffn matching: base_ffn_keywords actually match params

This catches config-model mismatches that cannot be detected by static YAML validation.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

import torch.nn as nn

from ..phase_schedules.groups import resolve_param_groups

logger = logging.getLogger(__name__)


class PreflightError(RuntimeError):
    """Raised when preflight check detects a fatal mismatch."""
    pass


@dataclass
class PreflightReport:
    """Report from a preflight check."""
    passed: bool
    group_counts: Dict[str, int] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


def run_preflight_check(
    model: nn.Module,
    phases: List[Dict[str, Any]],
    injection_strategy: str,
    *,
    base_ffn_keywords: Optional[Sequence[str]] = None,
    target_layers: Optional[Sequence[int]] = None,
    num_transformer_layers: Optional[int] = None,
) -> PreflightReport:
    """
    Run preflight validation after model load + injection.

    Checks:
    1. Every group referenced in phases has > 0 parameters in the model
    2. target_layers don't exceed actual model depth
    3. base_ffn_keywords actually match some parameters

    Args:
        model: Model after injection has been applied.
        phases: List of phase dicts from training.phases config.
        injection_strategy: The injection strategy name.
        base_ffn_keywords: Keywords for base FFN parameter matching.
        target_layers: Optional layer indices for base_ffn targeting.
        num_transformer_layers: Number of transformer layers in the model.

    Returns:
        PreflightReport with pass/fail status and diagnostics.

    Raises:
        PreflightError: On fatal mismatches.
    """
    report = PreflightReport(passed=True)

    # 1. Resolve parameter groups
    groups = resolve_param_groups(
        model,
        base_ffn_keywords=list(base_ffn_keywords) if base_ffn_keywords else None,
        target_layers=list(target_layers) if target_layers else None,
    )

    # Store group counts
    for group_name, params in groups.items():
        report.group_counts[group_name] = len(params)

    # 2. Check that every referenced group has > 0 params
    all_referenced_groups: set = set()
    for phase_entry in phases:
        if isinstance(phase_entry, dict):
            trainable = phase_entry.get("trainable", [])
            if isinstance(trainable, list):
                all_referenced_groups.update(trainable)

    for group_name in all_referenced_groups:
        count = report.group_counts.get(group_name, 0)
        if count == 0:
            msg = (
                f"Phase references group '{group_name}' but it has 0 parameters "
                f"in the model after injection (strategy='{injection_strategy}'). "
                f"This means the phase will have no trainable parameters for '{group_name}'. "
                f"Check that the injection strategy and config match."
            )
            report.errors.append(msg)
            report.passed = False
            raise PreflightError(msg)

    # 3. Check target_layers bounds
    if target_layers is not None and num_transformer_layers is not None:
        for layer_idx in target_layers:
            if layer_idx >= num_transformer_layers:
                msg = (
                    f"target_layers contains index {layer_idx} which exceeds "
                    f"the model's {num_transformer_layers} transformer layers "
                    f"(valid range: 0 to {num_transformer_layers - 1})."
                )
                report.errors.append(msg)
                report.passed = False
                raise PreflightError(msg)

    # 4. Log summary
    logger.info(
        "[Preflight] Group param counts: %s",
        {k: v for k, v in report.group_counts.items()},
    )

    if report.warnings:
        for w in report.warnings:
            logger.warning("[Preflight] %s", w)

    if report.passed:
        logger.info("[Preflight] All checks passed.")

    return report
