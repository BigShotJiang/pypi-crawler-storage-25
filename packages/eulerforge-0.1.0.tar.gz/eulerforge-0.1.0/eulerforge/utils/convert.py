# eulerforge/utils/convert.py
# -*- coding: utf-8 -*-
"""
Convert arbitrary JSONL to EulerForge standard raw JSONL.

Two modes:
- Recipe mode: built-in named converters (e.g. ``sft_messages_v1``)
- Mapping mode: dot-path field navigation (e.g. ``--prompt-path instruction.value``)

Standard raw formats:
- sft: ``{prompt, response}`` or ``{text}``
- preference: ``{chosen, rejected}``
- prompted_preference: ``{prompt, chosen, rejected}``
"""
from __future__ import annotations

import json
import logging
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

VALID_TASKS = ("sft", "preference", "prompted_preference")

_CONVERT_DOC = "docs/tutorials/00_data_preprocessing.md"

# ---------------------------------------------------------------------------
# A) Dot-path navigation
# ---------------------------------------------------------------------------

def _resolve_dot_path(row: dict, path: str) -> Any:
    """Navigate nested dicts via dot-separated path.

    ``_resolve_dot_path(row, "instruction.value")``
    is equivalent to ``row["instruction"]["value"]``.

    Raises :class:`KeyError` on missing or non-dict intermediate.
    """
    current = row
    for part in path.split("."):
        if not isinstance(current, dict):
            raise KeyError(
                f"Cannot navigate into non-dict at '{part}' in path '{path}'"
            )
        current = current[part]
    return current


# ---------------------------------------------------------------------------
# A-2) Dict flattening
# ---------------------------------------------------------------------------

def flatten_dict(row: dict, sep: str = ".") -> dict:
    """Flatten nested dict; arrays kept as-is (not exploded).

    ``{"a": {"b": 1}}``       → ``{"a.b": 1}``
    ``{"a": {"b": [1, 2]}}``  → ``{"a.b": [1, 2]}``  # list preserved
    """
    out: dict = {}

    def _r(current: Any, prefix: str) -> None:
        if isinstance(current, dict):
            for k, v in current.items():
                _r(v, f"{prefix}{sep}{k}" if prefix else k)
        else:
            out[prefix] = current

    _r(row, "")
    return out


def resolve_expr(flat_row: dict, expr: str, join_sep: str = "\n") -> Any:
    """Resolve expr against a flat row dict.

    1. Direct lookup in ``flat_row`` (preferred — works for both simple and
       pre-flattened dot keys like ``"instruction.value"``).
    2. Falls back to :func:`_resolve_dot_path` for nested dicts that were
       NOT flattened (``flatten_mode="none"``).
    3. If the resolved value is a ``list[str]`` it is joined with ``join_sep``.
    """
    if expr in flat_row:
        value = flat_row[expr]
    else:
        value = _resolve_dot_path(flat_row, expr)
    if isinstance(value, list) and all(isinstance(v, str) for v in value):
        return join_sep.join(value)
    return value


# ---------------------------------------------------------------------------
# B) Output row validation
# ---------------------------------------------------------------------------

_STANDARD_RAW_KEYS = {
    "sft": {"any_of": [["prompt", "response"], ["text"]]},
    "preference": {"all_of": ["chosen", "rejected"]},
    "prompted_preference": {"all_of": ["prompt", "chosen", "rejected"]},
}


def validate_output_row(row: dict, task: str, row_idx: int) -> None:
    """Validate a converted output row against the task schema.

    Raises :class:`ValueError` on invalid rows.
    """
    spec = _STANDARD_RAW_KEYS.get(task)
    if spec is None:
        raise ValueError(f"Unknown task '{task}'. Valid: {', '.join(VALID_TASKS)}")

    if "all_of" in spec:
        missing = [k for k in spec["all_of"] if k not in row]
        if missing:
            raise ValueError(
                f"row {row_idx}: missing keys {missing} for task '{task}'"
            )
    elif "any_of" in spec:
        for group in spec["any_of"]:
            if all(k in row for k in group):
                return
        options = " | ".join(str(g) for g in spec["any_of"])
        raise ValueError(
            f"row {row_idx}: need one of [{options}] for task '{task}'"
        )


# ---------------------------------------------------------------------------
# C) Recipe functions
# ---------------------------------------------------------------------------

def _recipe_sft_messages_v1(row: dict) -> dict:
    """Convert ``{json_record.messages: [{role, content}]}`` to ``{prompt, response}``.

    Prompt = concatenation of system + user messages.
    Response = last assistant message.
    """
    messages = _resolve_dot_path(row, "json_record.messages")

    prompt_parts: list[str] = []
    response = ""
    for msg in messages:
        role = msg["role"]
        content = msg["content"]
        if role in ("system", "user"):
            prompt_parts.append(content)
        elif role == "assistant":
            response = content

    return {"prompt": "\n".join(prompt_parts), "response": response}


def _recipe_dpo_nested_v1(row: dict) -> dict:
    """Convert ``{instruction.value, chosen.value, rejected.value}``
    to ``{prompt, chosen, rejected}``."""
    return {
        "prompt": _resolve_dot_path(row, "instruction.value"),
        "chosen": _resolve_dot_path(row, "chosen.value"),
        "rejected": _resolve_dot_path(row, "rejected.value"),
    }


def _recipe_passthrough_prompted_preference_v1(row: dict) -> dict:
    """Pass through ``{prompt, chosen, rejected}`` (strip extra keys)."""
    return {
        "prompt": row["prompt"],
        "chosen": row["chosen"],
        "rejected": row["rejected"],
    }


def _recipe_passthrough_sft_prompt_response_v1(row: dict) -> dict:
    """Pass through ``{prompt, response}`` (strip extra keys)."""
    return {"prompt": row["prompt"], "response": row["response"]}


def _recipe_passthrough_preference_v1(row: dict) -> dict:
    """Pass through ``{chosen, rejected}`` (strip extra keys)."""
    return {"chosen": row["chosen"], "rejected": row["rejected"]}


def _recipe_sft_instruction_output(row: dict) -> dict:
    """Convert ``{instruction, output}`` to ``{prompt, response}``."""
    return {"prompt": row["instruction"], "response": row["output"]}


def _recipe_dpo_nested_value(row: dict) -> dict:
    """Convert ``{instruction.value, chosen.value, rejected.value}``
    to ``{prompt, chosen, rejected}``."""
    return {
        "prompt": _resolve_dot_path(row, "instruction.value"),
        "chosen": _resolve_dot_path(row, "chosen.value"),
        "rejected": _resolve_dot_path(row, "rejected.value"),
    }


def _make_recipe_sft_messages(messages_expr: str) -> Callable[[dict], dict]:
    """Factory: build an sft_messages converter for the given messages dot-path."""
    def _convert(row: dict) -> dict:
        messages = _resolve_dot_path(row, messages_expr)
        prompt_parts: list[str] = []
        response = ""
        for msg in messages:
            if msg["role"] in ("system", "user"):
                prompt_parts.append(msg["content"])
            elif msg["role"] == "assistant":
                response = msg["content"]
        return {"prompt": "\n".join(prompt_parts), "response": response}
    return _convert


# ---------------------------------------------------------------------------
# D) Recipe registry
# ---------------------------------------------------------------------------

# name → (function, expected_task)
# NOTE: "sft_messages" uses None as a sentinel; get_recipe() handles it specially.
_RECIPES: Dict[str, Tuple[Optional[Callable], str]] = {
    "sft_messages_v1": (_recipe_sft_messages_v1, "sft"),
    "dpo_nested_v1": (_recipe_dpo_nested_v1, "prompted_preference"),
    "passthrough_prompted_preference_v1": (
        _recipe_passthrough_prompted_preference_v1,
        "prompted_preference",
    ),
    "passthrough_sft_prompt_response_v1": (
        _recipe_passthrough_sft_prompt_response_v1,
        "sft",
    ),
    "passthrough_preference_v1": (
        _recipe_passthrough_preference_v1,
        "preference",
    ),
    # New recipes
    "sft_instruction_output": (_recipe_sft_instruction_output, "sft"),
    "dpo_nested_value": (_recipe_dpo_nested_value, "prompted_preference"),
    "sft_messages": (None, "sft"),  # factory — requires messages_expr
}

VALID_RECIPES = tuple(_RECIPES.keys())


def get_recipe(name: str, *, messages_expr: Optional[str] = None) -> Tuple[Callable, str]:
    """Look up a built-in recipe by name.

    Returns ``(converter_fn, expected_task)``.
    ``"sft_messages"`` is a factory recipe that requires ``messages_expr``.
    Raises :class:`ValueError` for unknown recipes or missing ``messages_expr``.
    """
    if name not in _RECIPES:
        raise ValueError(
            f"Unknown recipe '{name}'. Valid recipes: {', '.join(VALID_RECIPES)}"
        )
    if name == "sft_messages":
        if not messages_expr:
            raise ValueError(
                "Recipe 'sft_messages' requires --messages-expr EXPR\n"
                "Fix: add e.g. --messages-expr 'json_record.messages'\n"
                f"See: {_CONVERT_DOC}"
            )
        return _make_recipe_sft_messages(messages_expr), "sft"
    fn, task = _RECIPES[name]
    return fn, task  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# E) Mapping mode converter builder
# ---------------------------------------------------------------------------

def _build_messages_converter(
    messages_path: str,
    prompt_roles: List[str],
    response_role: str,
) -> Callable[[dict], dict]:
    """Build a converter that extracts prompt/response from a messages array."""

    def _convert(row: dict) -> dict:
        messages = _resolve_dot_path(row, messages_path)
        prompt_parts: list[str] = []
        response = ""
        for msg in messages:
            role = msg["role"]
            content = msg["content"]
            if role in prompt_roles:
                prompt_parts.append(content)
            elif role == response_role:
                response = content
        return {"prompt": "\n".join(prompt_parts), "response": response}

    return _convert


def build_converter_from_mapping(
    task: str,
    *,
    prompt_path: Optional[str] = None,
    response_path: Optional[str] = None,
    chosen_path: Optional[str] = None,
    rejected_path: Optional[str] = None,
    messages_path: Optional[str] = None,
    messages_prompt_roles: Optional[str] = None,
    messages_response_role: Optional[str] = None,
) -> Callable[[dict], dict]:
    """Build a converter function from dot-path mappings.

    For SFT with messages: use ``messages_path``.
    For SFT with prompt/response: use ``prompt_path`` + ``response_path``.
    For preference: use ``chosen_path`` + ``rejected_path``.
    For prompted_preference: use ``prompt_path`` + ``chosen_path`` + ``rejected_path``.
    """
    # Messages-based SFT
    if messages_path is not None:
        prompt_roles = (messages_prompt_roles or "system,user").split(",")
        resp_role = messages_response_role or "assistant"
        return _build_messages_converter(messages_path, prompt_roles, resp_role)

    # Dot-path based extraction
    def _convert(row: dict) -> dict:
        out: dict = {}
        if task in ("sft",):
            if prompt_path:
                out["prompt"] = _resolve_dot_path(row, prompt_path)
            if response_path:
                out["response"] = _resolve_dot_path(row, response_path)
        if task in ("preference", "prompted_preference"):
            if prompt_path:
                out["prompt"] = _resolve_dot_path(row, prompt_path)
            if chosen_path:
                out["chosen"] = _resolve_dot_path(row, chosen_path)
            if rejected_path:
                out["rejected"] = _resolve_dot_path(row, rejected_path)
        return out

    return _convert


def build_converter_from_map(
    task: str,
    maps: List[str],
    *,
    flatten_mode: str = "dot",
    join_sep: str = "\n",
    strict: bool = False,
) -> Callable[[dict], dict]:
    """Build a converter from ``--map OUT_KEY=EXPR`` pairs.

    ``maps`` is a list of strings like ``["prompt=instruction", "response=output"]``.

    :param flatten_mode: ``"dot"`` (default) flattens nested dicts first;
        ``"none"`` uses :func:`_resolve_dot_path` directly.
    :param join_sep: separator for list-of-str values (default: newline).
    :param strict: if ``True``, raise :class:`ValueError` when a resolved
        value is ``None``, ``""``, or ``[]``.
    :raises ValueError: for malformed map entries or strict violations.
    """
    parsed: List[tuple] = []
    for m in maps:
        if "=" not in m:
            raise ValueError(
                f"Invalid --map '{m}': expected OUT_KEY=EXPR\n"
                f"Fix: use e.g. --map prompt=instruction\n"
                f"See: {_CONVERT_DOC}"
            )
        out_key, expr = m.split("=", 1)
        parsed.append((out_key.strip(), expr.strip()))

    def _convert(row: dict) -> dict:
        working = flatten_dict(row) if flatten_mode == "dot" else row
        out: dict = {}
        for out_key, expr in parsed:
            value = resolve_expr(working, expr, join_sep=join_sep)
            if strict and value in (None, "", []):
                raise ValueError(
                    f"--strict: value for '{expr}' is empty/None/[]\n"
                    f"Fix: check --map expression or input data\n"
                    f"See: {_CONVERT_DOC}"
                )
            out[out_key] = value
        return out

    return _convert


# ---------------------------------------------------------------------------
# F) File-level conversion
# ---------------------------------------------------------------------------

def convert_file(
    input_path: str,
    output_path: str,
    task: str,
    converter: Callable[[dict], dict],
    *,
    num_proc: int = 1,
    max_rows: Optional[int] = None,
    validate: bool = True,
) -> Dict[str, int]:
    """Convert a JSONL file using the given converter function.

    Returns ``{"total": N, "converted": M, "errors": E}``.
    """
    rows: List[dict] = []
    with open(input_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
                if max_rows is not None and len(rows) >= max_rows:
                    break

    if not rows:
        raise ValueError(f"Empty input file: {input_path}")

    if num_proc > 1:
        return _convert_parallel(
            rows, output_path, task, converter, num_proc, validate
        )

    # Sequential
    converted = 0
    errors = 0
    with open(output_path, "w", encoding="utf-8") as out:
        for i, row in enumerate(rows):
            try:
                result = converter(row)
                if validate:
                    validate_output_row(result, task, i)
                out.write(json.dumps(result, ensure_ascii=False) + "\n")
                converted += 1
            except Exception as exc:
                logger.warning(f"[Convert] row {i} error: {exc}")
                errors += 1

    return {"total": len(rows), "converted": converted, "errors": errors}


def _convert_parallel(
    rows: List[dict],
    output_path: str,
    task: str,
    converter: Callable[[dict], dict],
    num_proc: int,
    validate: bool,
) -> Dict[str, int]:
    """Parallel conversion using HuggingFace Datasets."""
    import os
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

    from datasets import Dataset

    ds = Dataset.from_list(rows)

    error_count = 0

    def _map_fn(examples):
        nonlocal error_count
        batch_size = len(next(iter(examples.values())))
        results: Dict[str, list] = {}
        keys: Optional[list] = None

        for i in range(batch_size):
            row = {k: examples[k][i] for k in examples}
            try:
                out = converter(row)
                if validate:
                    validate_output_row(out, task, i)
            except Exception:
                error_count += 1
                continue

            if keys is None:
                keys = list(out.keys())
                for k in keys:
                    results[k] = []
            for k in keys:
                results[k].append(out.get(k, ""))

        if keys is None:
            return {k: [] for k in ["__empty__"]}
        return results

    mapped = ds.map(
        _map_fn,
        batched=True,
        batch_size=100,
        num_proc=num_proc,
        remove_columns=ds.column_names,
    )

    # Write to JSONL
    converted = 0
    with open(output_path, "w", encoding="utf-8") as out:
        for row in mapped:
            if "__empty__" in row:
                continue
            out.write(json.dumps(row, ensure_ascii=False) + "\n")
            converted += 1

    return {"total": len(rows), "converted": converted, "errors": error_count}


def validate_file(
    path: str,
    task: str,
    n: Optional[int] = None,
) -> Dict[str, int]:
    """Validate rows of a JSONL file against the task schema.

    Returns ``{"valid": N, "invalid": M}``.
    """
    valid = 0
    invalid = 0
    with open(path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            line = line.strip()
            if not line:
                continue
            if n is not None and (valid + invalid) >= n:
                break
            try:
                row = json.loads(line)
                validate_output_row(row, task, i)
                valid += 1
            except (ValueError, KeyError):
                invalid += 1

    return {"valid": valid, "invalid": invalid}


def print_sample_flat(
    input_path: str,
    flatten_mode: str = "dot",
    n: int = 2,
) -> None:
    """Print the first ``n`` rows flattened — a field discovery tool.

    Useful for identifying the correct ``--map`` expressions before converting.
    """
    rows: list = []
    with open(input_path, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
                if len(rows) >= n:
                    break

    for i, row in enumerate(rows):
        flat = flatten_dict(row) if flatten_mode == "dot" else row
        print(f"\n--- row {i} flat keys ---")
        for k, v in flat.items():
            print(f"  {k!r:45s}  ({type(v).__name__})  {repr(v)[:60]}")
