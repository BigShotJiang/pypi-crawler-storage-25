# eulerforge/utils/grid_validator.py
# -*- coding: utf-8 -*-
"""
Grid Search YAML spec 검증기.

docs/fixtures/specs/grid_search_spec.md의 규칙 1-21과 1:1 대응.
"""
from __future__ import annotations

from typing import Any, Dict, List

from eulerforge.utils.config import load_yaml

_GRID_DOC = "docs/tutorials/12_grid_search.md"

_VALID_METHODS = ("grid", "random", "bayes")
_VALID_DIRECTIONS = ("minimize", "maximize")
_VALID_STEP_AGGS = ("last", "min", "mean")
_VALID_TYPES = ("float", "int", "categorical")
_VALID_DATA_FORMATS = ("raw", "processed")
_VALID_DATA_TASKS = ("sft", "preference", "prompted_preference")


# ---------------------------------------------------------------------------
# Exception
# ---------------------------------------------------------------------------

class GridSpecValidationError(ValueError):
    """Grid YAML spec 검증 실패.

    str()은 3-line 포맷:
        Category: <message>
        Fix: <fix>
        See: <doc>
    """

    def __init__(self, message: str, *, category: str = "", fix: str = "", doc: str = ""):
        self.category = category
        self.fix = fix
        self.doc = doc
        if category and fix and doc:
            full = f"{category}: {message}\nFix: {fix}\nSee: {doc}"
        else:
            full = message
        super().__init__(full)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_VALID_BENCH_METRICS = ("avg_score", "target_avg_score", "baseline_avg_score")
_VALID_CHECKPOINTS = ("final", "latest", "best")


def validate_grid_spec(spec: Dict[str, Any]) -> None:
    """Grid YAML dict 검증. 실패 시 GridSpecValidationError."""
    _validate_version(spec)
    _validate_base_preset(spec)
    _validate_run(spec)
    _validate_search(spec)
    _validate_bench_eval(spec)


def load_and_validate_grid_spec(path: str) -> Dict[str, Any]:
    """YAML 파일을 읽어 검증한 뒤 dict로 반환.

    Raises:
        FileNotFoundError: 파일이 없을 때
        GridSpecValidationError: 검증 실패 시
    """
    spec = load_yaml(path)  # FileNotFoundError propagates
    validate_grid_spec(spec)
    return spec


# ---------------------------------------------------------------------------
# 규칙 1-2: 최상위 필드
# ---------------------------------------------------------------------------

def _validate_version(spec: Dict[str, Any]) -> None:
    """규칙 1: version은 정수 1만 허용."""
    if "version" not in spec:
        raise GridSpecValidationError(
            "version 필드가 없습니다",
            category="Grid Spec",
            fix="version: 1 을 추가하세요",
            doc=_GRID_DOC,
        )
    if spec["version"] != 1:
        raise GridSpecValidationError(
            f"version은 1만 허용합니다 (got: {spec['version']})",
            category="Grid Spec",
            fix="version: 1 로 설정하세요",
            doc=_GRID_DOC,
        )


def _validate_base_preset(spec: Dict[str, Any]) -> None:
    """규칙 2: base_preset 필수."""
    if not spec.get("base_preset"):
        raise GridSpecValidationError(
            "base_preset이 없습니다",
            category="Grid Spec",
            fix="base_preset: configs/presets/qwen3.5_0.8b_dense_lora_sft.yml 를 추가하세요",
            doc=_GRID_DOC,
        )


# ---------------------------------------------------------------------------
# 규칙 3-10: run 섹션
# ---------------------------------------------------------------------------

def _validate_run(spec: Dict[str, Any]) -> None:
    """규칙 3: run 섹션 필수."""
    if "run" not in spec:
        raise GridSpecValidationError(
            "run 섹션이 없습니다",
            category="Grid Spec",
            fix="run: 섹션을 추가하세요 (output_root, max_trials, max_train_steps, objective 포함)",
            doc=_GRID_DOC,
        )
    run = spec["run"]
    if not isinstance(run, dict):
        raise GridSpecValidationError(
            "run 섹션은 dict여야 합니다",
            category="Grid Spec",
            fix="run: 섹션을 YAML 매핑으로 작성하세요",
            doc=_GRID_DOC,
        )

    # 규칙 4
    if not run.get("output_root"):
        raise GridSpecValidationError(
            "run.output_root가 없습니다",
            category="Grid Spec",
            fix="run.output_root: outputs/grid 를 추가하세요",
            doc=_GRID_DOC,
        )

    # 규칙 5
    _validate_positive_int(run, "max_trials", "Grid Spec")

    # 규칙 6
    _validate_positive_int(run, "max_train_steps", "Grid Spec")

    # 규칙 7-10: objective
    _validate_objective(run)

    # 규칙 20-21: data (선택)
    if "data" in run and run["data"] is not None:
        _validate_data(run["data"])


def _validate_positive_int(d: Dict[str, Any], key: str, category: str) -> None:
    """dict[key]가 양의 정수인지 확인."""
    if key not in d:
        raise GridSpecValidationError(
            f"run.{key}가 없습니다",
            category=category,
            fix=f"run.{key}: 1 이상의 정수를 추가하세요",
            doc=_GRID_DOC,
        )
    val = d[key]
    try:
        ival = int(val)
    except (TypeError, ValueError):
        raise GridSpecValidationError(
            f"run.{key}는 정수여야 합니다 (got: {val!r})",
            category=category,
            fix=f"run.{key}를 양의 정수로 설정하세요",
            doc=_GRID_DOC,
        )
    if ival < 1:
        raise GridSpecValidationError(
            f"run.{key}는 1 이상이어야 합니다 (got: {ival})",
            category=category,
            fix=f"run.{key}를 1 이상의 정수로 설정하세요",
            doc=_GRID_DOC,
        )


def _validate_objective(run: Dict[str, Any]) -> None:
    """규칙 7-10: run.objective 검증."""
    if "objective" not in run:
        raise GridSpecValidationError(
            "run.objective가 없습니다",
            category="Grid Spec",
            fix="run.objective: {direction: minimize, metric: train/total_loss, step_agg: last} 를 추가하세요",
            doc=_GRID_DOC,
        )
    obj = run["objective"]
    if not isinstance(obj, dict):
        raise GridSpecValidationError(
            "run.objective는 dict여야 합니다",
            category="Grid Spec",
            fix="run.objective를 YAML 매핑으로 작성하세요",
            doc=_GRID_DOC,
        )

    # 규칙 8: direction
    direction = obj.get("direction")
    if direction not in _VALID_DIRECTIONS:
        raise GridSpecValidationError(
            f"run.objective.direction은 {_VALID_DIRECTIONS} 중 하나여야 합니다 (got: {direction!r})",
            category="Grid Spec",
            fix="direction: minimize 또는 direction: maximize 로 설정하세요",
            doc=_GRID_DOC,
        )

    # 규칙 9: metric
    if not obj.get("metric"):
        raise GridSpecValidationError(
            "run.objective.metric이 없습니다",
            category="Grid Spec",
            fix="metric: train/total_loss 와 같이 metrics.jsonl에 기록되는 키를 지정하세요",
            doc=_GRID_DOC,
        )

    # 규칙 10: step_agg (기본값: last)
    step_agg = obj.get("step_agg", "last")
    if step_agg not in _VALID_STEP_AGGS:
        raise GridSpecValidationError(
            f"run.objective.step_agg은 {_VALID_STEP_AGGS} 중 하나여야 합니다 (got: {step_agg!r})",
            category="Grid Spec",
            fix="step_agg: last 또는 step_agg: min 또는 step_agg: mean 으로 설정하세요",
            doc=_GRID_DOC,
        )


def _validate_data(data: Dict[str, Any]) -> None:
    """규칙 20-21: run.data 섹션 검증."""
    if not isinstance(data, dict):
        raise GridSpecValidationError(
            "run.data는 dict여야 합니다",
            category="Grid Spec",
            fix="run.data를 YAML 매핑으로 작성하세요",
            doc=_GRID_DOC,
        )

    # 규칙 21: path 필수
    if not data.get("path"):
        raise GridSpecValidationError(
            "run.data.path가 없습니다",
            category="Grid Spec",
            fix="run.data.path: data/sft.jsonl 와 같이 데이터 파일 경로를 지정하세요",
            doc=_GRID_DOC,
        )

    fmt = data.get("format", "processed")
    if fmt not in _VALID_DATA_FORMATS:
        raise GridSpecValidationError(
            f"run.data.format은 {_VALID_DATA_FORMATS} 중 하나여야 합니다 (got: {fmt!r})",
            category="Grid Spec",
            fix="format: raw 또는 format: processed 로 설정하세요",
            doc=_GRID_DOC,
        )

    # 규칙 20: raw 포맷은 task 필수
    if fmt == "raw":
        task = data.get("task")
        if not task or task not in _VALID_DATA_TASKS:
            raise GridSpecValidationError(
                f"run.data.format=raw 일 때 task가 필수입니다. "
                f"유효한 값: {_VALID_DATA_TASKS} (got: {task!r})",
                category="Grid Spec",
                fix=f"run.data.task를 {', '.join(_VALID_DATA_TASKS)} 중 하나로 설정하세요",
                doc=_GRID_DOC,
            )


# ---------------------------------------------------------------------------
# 규칙 11-19: search 섹션
# ---------------------------------------------------------------------------

def _validate_search(spec: Dict[str, Any]) -> None:
    """규칙 11: search 섹션 필수."""
    if "search" not in spec:
        raise GridSpecValidationError(
            "search 섹션이 없습니다",
            category="Grid Spec",
            fix="search: 섹션을 추가하세요 (method, space 포함)",
            doc=_GRID_DOC,
        )
    search = spec["search"]
    if not isinstance(search, dict):
        raise GridSpecValidationError(
            "search 섹션은 dict여야 합니다",
            category="Grid Spec",
            fix="search: 섹션을 YAML 매핑으로 작성하세요",
            doc=_GRID_DOC,
        )

    # 규칙 12: method
    method = search.get("method")
    if method not in _VALID_METHODS:
        raise GridSpecValidationError(
            f"search.method는 {_VALID_METHODS} 중 하나여야 합니다 (got: {method!r})",
            category="Grid Spec",
            fix="method: grid 또는 method: random 또는 method: bayes 로 설정하세요",
            doc=_GRID_DOC,
        )

    # 규칙 13: space
    space = search.get("space")
    if space is None:
        raise GridSpecValidationError(
            "search.space가 없습니다",
            category="Grid Spec",
            fix="search.space: 아래에 탐색할 하이퍼파라미터 항목을 1개 이상 추가하세요",
            doc=_GRID_DOC,
        )
    if not isinstance(space, list) or len(space) == 0:
        raise GridSpecValidationError(
            "search.space는 1개 이상의 항목을 가진 리스트여야 합니다",
            category="Grid Spec",
            fix="search.space 아래에 탐색할 하이퍼파라미터 항목을 1개 이상 추가하세요",
            doc=_GRID_DOC,
        )

    for i, item in enumerate(space):
        _validate_space_item(item, i, method)


def _validate_space_item(item: Any, idx: int, method: str) -> None:
    """규칙 14-19: space 항목 하나 검증."""
    if not isinstance(item, dict):
        raise GridSpecValidationError(
            f"search.space[{idx}]는 dict여야 합니다 (got: {type(item).__name__})",
            category="Grid Spec",
            fix="각 space 항목을 name, type 등 키를 가진 YAML 매핑으로 작성하세요",
            doc=_GRID_DOC,
        )

    # 규칙 14: name
    name = item.get("name")
    if not name:
        raise GridSpecValidationError(
            f"search.space[{idx}].name이 없거나 비어있습니다",
            category="Grid Spec",
            fix="name: training.lr 와 같이 dot-path 형식으로 파라미터 이름을 지정하세요",
            doc=_GRID_DOC,
        )

    # 규칙 15: type
    ptype = item.get("type")
    if ptype not in _VALID_TYPES:
        raise GridSpecValidationError(
            f"search.space[{idx}].type은 {_VALID_TYPES} 중 하나여야 합니다 (got: {ptype!r})",
            category="Grid Spec",
            fix="type: float 또는 type: int 또는 type: categorical 로 설정하세요",
            doc=_GRID_DOC,
        )

    has_choices = "choices" in item and item["choices"] is not None
    has_low_high = "low" in item and "high" in item

    # 규칙 18: categorical → choices 필수, 비어있으면 안 됨
    if ptype == "categorical":
        if not has_choices:
            raise GridSpecValidationError(
                f"search.space[{idx}] (name={name!r}): type=categorical 이면 choices가 필수입니다",
                category="Grid Spec",
                fix="choices: [값1, 값2, 값3] 형태로 선택지를 지정하세요",
                doc=_GRID_DOC,
            )
        if not isinstance(item["choices"], list) or len(item["choices"]) == 0:
            raise GridSpecValidationError(
                f"search.space[{idx}] (name={name!r}): choices는 비어있으면 안 됩니다",
                category="Grid Spec",
                fix="choices 리스트에 1개 이상의 값을 추가하세요",
                doc=_GRID_DOC,
            )
        return  # categorical은 이하 체크 불필요

    # 규칙 16-17: float/int → low+high 또는 choices 중 하나 필수
    if not has_choices and not has_low_high:
        raise GridSpecValidationError(
            f"search.space[{idx}] (name={name!r}): type={ptype!r} 이면 "
            "low+high 또는 choices 중 하나가 필요합니다",
            category="Grid Spec",
            fix="low: 값 / high: 값 을 추가하거나 choices: [값1, 값2] 를 사용하세요",
            doc=_GRID_DOC,
        )

    # 규칙 19: method=grid + 연속 범위(float/int with low/high) → 오류
    if method == "grid" and has_low_high and not has_choices:
        raise GridSpecValidationError(
            f"search.space[{idx}] (name={name!r}): "
            f"method=grid 는 연속 범위(low/high)를 지원하지 않습니다 (type={ptype!r})",
            category="Grid Spec",
            fix=(
                "grid method에서는 choices: [값1, 값2, ...] 형태를 사용하세요. "
                "연속 탐색이 필요하면 method: random 또는 method: bayes 를 사용하세요"
            ),
            doc=_GRID_DOC,
        )


# ---------------------------------------------------------------------------
# bench_eval 검증 (규칙 22-25)
# ---------------------------------------------------------------------------

def _validate_bench_eval(spec: Dict[str, Any]) -> None:
    """run.bench_eval 섹션 검증."""
    run = spec.get("run", {})
    bench_eval = run.get("bench_eval")
    if bench_eval is None or not isinstance(bench_eval, dict):
        return
    if not bench_eval.get("enabled", False):
        return

    # 규칙 22: bench_preset 필수
    if not bench_eval.get("bench_preset"):
        raise GridSpecValidationError(
            "bench_eval.enabled=true이면 bench_preset이 필수입니다",
            category="Grid Spec",
            fix="run.bench_eval.bench_preset에 bench YAML 경로를 지정하세요",
            doc=_GRID_DOC,
        )

    # 규칙 23: metric 유효성 (기본값: avg_score)
    metric = bench_eval.get("metric", "avg_score")
    if metric not in _VALID_BENCH_METRICS:
        raise GridSpecValidationError(
            f"bench_eval.metric '{metric}'은 유효하지 않습니다",
            category="Grid Spec",
            fix=f"다음 중 하나를 사용하세요: {', '.join(_VALID_BENCH_METRICS)}",
            doc=_GRID_DOC,
        )

    # 규칙 24: checkpoint 유효성 (기본값: final)
    checkpoint = bench_eval.get("checkpoint", "final")
    if checkpoint not in _VALID_CHECKPOINTS:
        raise GridSpecValidationError(
            f"bench_eval.checkpoint '{checkpoint}'은 유효하지 않습니다",
            category="Grid Spec",
            fix=f"다음 중 하나를 사용하세요: {', '.join(_VALID_CHECKPOINTS)}",
            doc=_GRID_DOC,
        )
