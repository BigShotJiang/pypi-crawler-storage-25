# eulerforge/utils/validator.py
# -*- coding: utf-8 -*-
"""
Config schema validation for eulerforge.

Validates:
- Required top-level sections
- Injection strategy parameters
- training.phases declarative schema
- phase_target_kwargs types
- Common typos and misspellings
- Rejection of removed legacy keys (phase_schedule, phase1_steps, etc.)
- MoE stability rules (z-loss, load balance, capacity factor, router dtype)
- base_ffn targeting strictness
- MoE-phase cross-checks
"""
from __future__ import annotations

import math
import logging
from typing import Any, Dict, List, Set

logger = logging.getLogger(__name__)


class ConfigValidationError(ValueError):
    """Raised when config validation fails.

    When category, fix, and doc are all provided, str() produces a 3-line
    structured error message.  Otherwise falls back to a single-line message
    for backward compatibility.
    """

    def __init__(self, message: str, *, category: str = "", fix: str = "", doc: str = ""):
        self.category = category
        self.fix = fix
        self.doc = doc
        if category and fix and doc:
            full = f"{category}: {message}\nFix: {fix}\nSee: {doc}"
        else:
            full = message
        super().__init__(full)


# Known group names for phases
_KNOWN_GROUPS: Set[str] = {"lora", "router", "base_ffn", "attn_lora"}

# Known phase entry keys (for typo detection)
_KNOWN_PHASE_KEYS: Set[str] = {
    "step", "trainable", "mode", "base_ffn_keywords", "target_layers",
}

# Common typos -> correct key
_TYPO_SUGGESTIONS: Dict[str, str] = {
    "trainables": "trainable",
    "steps": "step",
    "train": "trainable",
    "groups": "trainable",
    "layers": "target_layers",
}

# Valid training types
_VALID_TRAINING_TYPES: List[str] = ["sft", "dpo", "orpo", "rm", "ppo"]

# Valid strategies (canonical names)
_VALID_STRATEGIES: List[str] = [
    "dense_lora",
    "mixture_lora",
    "moe_expert_lora",
    "native_moe_expert_lora",
]

# Strategies that create/use MoE routing (require moe section)
_MOE_STRATEGIES: Set[str] = {"mixture_lora", "moe_expert_lora"}

# Valid load balance types
_VALID_LB_TYPES: Set[str] = {"aux_loss", "aux_loss_free", "none"}

# Valid router dtypes
_VALID_ROUTER_DTYPES: Set[str] = {"float32", "float16", "bfloat16"}

# Doc path for MoE stability errors (3-line format)
_MOE_DOC = "docs/tutorials/09_moe_stability_and_validation.md"

# base_ffn_keywords that are suspiciously broad
_BROAD_FFN_KEYWORDS: Set[str] = {"proj", "linear", "weight", "layer", "mlp"}

# MoE section typo suggestions
_MOE_TYPO_SUGGESTIONS: Dict[str, str] = {
    "router_zloss_coef": "router_z_loss_coef",
    "router_z_loss": "router_z_loss_coef",
    "z_loss_coef": "router_z_loss_coef",
    "zloss": "router_z_loss_coef",
}

_LB_TYPO_SUGGESTIONS: Dict[str, str] = {
    "aux_coef": "aux_loss_coef",
    "aux_weight": "aux_loss_coef",
    "coef": "aux_loss_coef",
    "balance_type": "type",
    "lb_type": "type",
}


def validate_config(cfg: Dict[str, Any]) -> None:
    """
    Validate a resolved config dict.

    Raises ConfigValidationError with helpful messages on invalid configs.
    """
    # 1. Required top-level sections
    _validate_required_sections(cfg)

    # 2. Injection strategy
    _validate_injection(cfg["injection"])

    strategy = cfg["injection"].get("strategy", "")

    # 3. Training & phases
    _validate_training(cfg["training"], cfg["injection"])

    # 4. MoE stability rules (only for MoE strategies)
    _validate_moe_section(cfg, strategy)

    # 5. MoE-phase cross-checks
    _validate_moe_phase_cross_checks(cfg, strategy)

    # 6. Data section (optional)
    _validate_data_section(cfg)

    # 7. Logging section (optional)
    _validate_logging_section(cfg)

    # 8. LoRA handoff scheduling (optional)
    _validate_lora_handoff(cfg)

    # 9. Model load precision (optional)
    _validate_load_precision(cfg)

    logger.info("Config validation passed.")


def _validate_required_sections(cfg: Dict[str, Any]) -> None:
    required = ["backbone", "injection", "training"]
    for sec in required:
        if sec not in cfg:
            raise ConfigValidationError(
                f"Missing required top-level section: '{sec}'"
            )


def _validate_injection(inj: Dict[str, Any]) -> None:
    if not isinstance(inj, dict):
        raise ConfigValidationError("'injection' must be a dict.")

    strategy = inj.get("strategy")
    if not strategy:
        raise ConfigValidationError("injection.strategy is required.")

    if strategy not in _VALID_STRATEGIES:
        raise ConfigValidationError(
            f"Unknown strategy '{strategy}'. Supported: {_VALID_STRATEGIES}"
        )

    # Native MoE requires target_keywords
    if strategy == "native_moe_expert_lora":
        if not inj.get("target_keywords"):
            msg = "Strategy 'native_moe_expert_lora' requires 'target_keywords' list."
            if inj.get("ffn_keywords"):
                msg += " Found deprecated 'ffn_keywords', please rename to 'target_keywords'."
            raise ConfigValidationError(msg)

    # MoE strategies require num_experts and top_k
    if strategy in ("mixture_lora", "moe_expert_lora"):
        num_experts = inj.get("num_experts")
        top_k = inj.get("top_k")

        if not num_experts:
            raise ConfigValidationError(
                f"Strategy '{strategy}' requires 'num_experts'."
            )
        if not top_k:
            raise ConfigValidationError(
                f"Strategy '{strategy}' requires 'top_k'."
            )

        try:
            ne = int(num_experts)
            tk = int(top_k)
        except (ValueError, TypeError):
            raise ConfigValidationError(
                "num_experts and top_k must be integers."
            )

        if ne < 1:
            raise ConfigValidationError(f"num_experts must be >= 1, got {ne}")
        if tk < 1:
            raise ConfigValidationError(f"top_k must be >= 1, got {tk}")
        if tk > ne:
            raise ConfigValidationError(
                f"top_k ({tk}) cannot be larger than num_experts ({ne})."
            )

    # LoRA rank check
    r = inj.get("lora_r", 0)
    try:
        r_int = int(r)
    except (ValueError, TypeError):
        raise ConfigValidationError(f"lora_r must be an integer, got {r}")

    if r_int < 0:
        raise ConfigValidationError(f"lora_r cannot be negative, got {r_int}")

    if r_int == 0:
        logger.warning("[Validator] injection.lora_r is 0. LoRA layers will act as Identity.")


def _validate_training(training: Dict[str, Any], injection: Dict[str, Any]) -> None:
    if not isinstance(training, dict):
        raise ConfigValidationError("'training' must be a dict.")

    # Reject removed legacy keys with clear migration message
    _reject_legacy_training_keys(training)

    # Validate training type
    _validate_training_type(training)

    # Type-specific parameter validation
    tt = str(training.get("type", "sft")).lower()
    if tt == "orpo":
        _validate_orpo_params(training)
    elif tt == "ppo":
        _validate_ppo_params(training)

    phases = training.get("phases")

    # Validate phases if present
    if phases is not None:
        _validate_phases(phases, injection, training)

    # Validate phase_target_kwargs if present
    target_kwargs = training.get("phase_target_kwargs")
    if target_kwargs is not None:
        _validate_phase_target_kwargs(target_kwargs)


# Legacy config keys that have been removed
_REMOVED_TRAINING_KEYS: Dict[str, str] = {
    "phase_schedule": (
        "training.phase_schedule has been removed. "
        "Use training.phases (declarative list) instead. "
        "Example:\n"
        "  training:\n"
        "    phases:\n"
        "      - step: 0\n"
        "        trainable: [\"lora\"]\n"
        "      - step: 2000\n"
        "        trainable: [\"lora\", \"router\"]"
    ),
    "phase1_steps": (
        "training.phase1_steps has been removed. "
        "Define step transitions directly in training.phases. "
        "Example: {step: 2000, trainable: [\"lora\"]}"
    ),
    "phase_schedule_kwargs": (
        "training.phase_schedule_kwargs has been removed. "
        "All phase parameters (base_ffn_keywords, target_layers, mode) "
        "are now specified directly in each phase entry under training.phases."
    ),
}


def _reject_legacy_training_keys(training: Dict[str, Any]) -> None:
    """Reject removed legacy training config keys with clear migration messages."""
    for key, message in _REMOVED_TRAINING_KEYS.items():
        if key in training:
            raise ConfigValidationError(message)


def _validate_training_type(training: Dict[str, Any]) -> None:
    """Validate training.type against known types."""
    raw = training.get("type", "sft")
    tt = str(raw).lower()
    if tt not in _VALID_TRAINING_TYPES:
        raise ConfigValidationError(
            f"Unknown training type '{raw}'. Supported: {_VALID_TRAINING_TYPES}",
            category="Training Config",
            fix=f"Set training.type to one of: {', '.join(_VALID_TRAINING_TYPES)}",
            doc="docs/cli.md",
        )


def _validate_orpo_params(training: Dict[str, Any]) -> None:
    """Validate ORPO-specific parameters."""
    if "orpo_lambda" not in training:
        raise ConfigValidationError(
            "orpo_lambda is required for ORPO training",
            category="Training Config",
            fix="Add 'orpo_lambda: 1.0' under training section",
            doc="docs/tutorials/06_orpo_training.md",
        )
    lam = training["orpo_lambda"]
    try:
        lam_f = float(lam)
    except (ValueError, TypeError):
        raise ConfigValidationError(
            f"orpo_lambda must be a positive float, got {type(lam).__name__}",
            category="Training Config",
            fix="Set orpo_lambda to a positive float (e.g. 1.0)",
            doc="docs/tutorials/06_orpo_training.md",
        )
    if lam_f <= 0:
        raise ConfigValidationError(
            f"orpo_lambda must be positive, got {lam_f}",
            category="Training Config",
            fix="Set orpo_lambda to a positive float (e.g. 1.0)",
            doc="docs/tutorials/06_orpo_training.md",
        )


def _validate_ppo_params(training: Dict[str, Any]) -> None:
    """Validate PPO-specific parameters."""
    ppo = training.get("ppo")
    if ppo is None or not isinstance(ppo, dict):
        raise ConfigValidationError(
            "PPO training requires a 'ppo' section with clip_range, kl_coef, epochs",
            category="Training Config",
            fix="Add ppo: {clip_range: 0.2, kl_coef: 0.1, epochs: 4}",
            doc="docs/tutorials/08_ppo_training.md",
        )
    for key in ("clip_range", "kl_coef", "epochs"):
        if key not in ppo:
            raise ConfigValidationError(
                f"ppo.{key} is required for PPO training",
                category="Training Config",
                fix=f"Add '{key}' to the ppo section",
                doc="docs/tutorials/08_ppo_training.md",
            )
    rm = training.get("reward_model")
    if rm is None or not isinstance(rm, dict):
        raise ConfigValidationError(
            "PPO training requires a 'reward_model' section with model_name",
            category="Training Config",
            fix="Add reward_model: {model_name: 'path/to/model'}",
            doc="docs/tutorials/08_ppo_training.md",
        )
    if "model_name" not in rm:
        raise ConfigValidationError(
            "reward_model.model_name is required for PPO training",
            category="Training Config",
            fix="Add model_name to reward_model section",
            doc="docs/tutorials/08_ppo_training.md",
        )


def _validate_phases(
    phases: Any,
    injection: Dict[str, Any],
    training: Dict[str, Any],
) -> None:
    """Validate the training.phases list."""
    if not isinstance(phases, list):
        raise ConfigValidationError(
            "training.phases must be a list of phase dicts."
        )

    seen_steps: set = set()
    strategy = injection.get("strategy", "")

    # Collect global target kwargs for base_ffn checks
    global_kwargs = training.get("phase_target_kwargs", {}) or {}
    global_bfk = global_kwargs.get("base_ffn_keywords")

    for i, entry in enumerate(phases):
        if not isinstance(entry, dict):
            raise ConfigValidationError(
                f"Phase entry {i} must be a dict, got {type(entry).__name__}."
            )

        # Check for common typos in keys
        _check_phase_key_typos(entry, i)

        # Required keys
        if "step" not in entry:
            if "steps" in entry:
                raise ConfigValidationError(
                    f"Phase {i}: found 'steps' but expected 'step' (singular). "
                    "Did you mean 'step'?"
                )
            raise ConfigValidationError(
                f"Phase {i}: missing required key 'step'."
            )

        if "trainable" not in entry:
            if "trainables" in entry:
                raise ConfigValidationError(
                    f"Phase {i}: found 'trainables' but expected 'trainable' (singular). "
                    "Did you mean 'trainable'?"
                )
            raise ConfigValidationError(
                f"Phase {i}: missing required key 'trainable'."
            )

        # Validate step
        step = entry["step"]
        if isinstance(step, float) and step != int(step):
            raise ConfigValidationError(
                f"Phase {i}: step must be an integer, got float {step}."
            )
        try:
            step_int = int(step)
        except (ValueError, TypeError):
            raise ConfigValidationError(
                f"Phase {i}: step must be an integer, got {type(step).__name__} '{step}'."
            )

        if step_int < 0:
            raise ConfigValidationError(
                f"Phase {i}: step cannot be negative, got {step_int}."
            )

        if step_int in seen_steps:
            raise ConfigValidationError(
                f"Duplicate phase step: {step_int}."
            )
        seen_steps.add(step_int)

        # Validate trainable
        trainable = entry["trainable"]
        if not isinstance(trainable, list):
            raise ConfigValidationError(
                f"Phase {i}: trainable must be a list of group names, "
                f"got {type(trainable).__name__}."
            )

        if len(trainable) == 0:
            mode = entry.get("mode", "replace")
            if mode == "replace":
                raise ConfigValidationError(
                    f"Phase {i}: trainable list is empty in replace mode. "
                    "This would freeze all parameters."
                )

        for group in trainable:
            if group not in _KNOWN_GROUPS:
                raise ConfigValidationError(
                    f"Unknown group name '{group}' in phase {i}. "
                    f"Known groups: {sorted(_KNOWN_GROUPS)}."
                )

        # Validate mode
        mode = entry.get("mode", "replace")
        if mode not in ("replace", "add"):
            raise ConfigValidationError(
                f"Phase {i}: mode must be 'replace' or 'add', got '{mode}'."
            )

        # Strategy-specific warnings
        if strategy == "dense_lora" and "router" in trainable:
            logger.warning(
                "[Validator] Phase %d requests 'router' training with "
                "'dense_lora' strategy. dense_lora typically has no router params.",
                i,
            )
        if strategy == "dense_lora" and "base_ffn" in trainable:
            logger.warning(
                "[Validator] Phase %d requests 'base_ffn' training with "
                "'dense_lora' strategy.",
                i,
            )

        # --- base_ffn targeting strictness ---
        if "base_ffn" in trainable:
            _validate_base_ffn_targeting(entry, i, global_bfk)


def _validate_base_ffn_targeting(
    entry: Dict[str, Any],
    phase_idx: int,
    global_bfk: Any,
) -> None:
    """Validate base_ffn targeting: keywords must be specified and reasonable."""
    # Check for base_ffn_keywords at phase level or global level
    per_phase_bfk = entry.get("base_ffn_keywords")

    effective_bfk = per_phase_bfk if per_phase_bfk is not None else global_bfk

    if effective_bfk is None:
        raise ConfigValidationError(
            f"Phase {phase_idx}: 'base_ffn' is in trainable but no base_ffn_keywords "
            "specified (neither per-phase nor in phase_target_kwargs). "
            "You must specify which FFN weights to unfreeze."
        )

    if isinstance(effective_bfk, list) and len(effective_bfk) == 0:
        raise ConfigValidationError(
            f"Phase {phase_idx}: base_ffn_keywords is empty. "
            "Provide at least one keyword (e.g. 'gate_proj', 'up_proj', 'down_proj')."
        )

    # Warn about overly broad keywords
    if isinstance(effective_bfk, list):
        for kw in effective_bfk:
            if isinstance(kw, str) and kw.lower() in _BROAD_FFN_KEYWORDS:
                logger.warning(
                    "[Validator] Phase %d: base_ffn_keywords contains broad keyword '%s' "
                    "which may match too many parameters. "
                    "Consider using specific keywords like 'gate_proj', 'up_proj', 'down_proj'.",
                    phase_idx, kw,
                )

    # Validate per-phase target_layers
    per_phase_tl = entry.get("target_layers")
    if per_phase_tl is not None and isinstance(per_phase_tl, list):
        seen_layers: set = set()
        for layer in per_phase_tl:
            if isinstance(layer, int):
                if layer < 0:
                    raise ConfigValidationError(
                        f"Phase {phase_idx}: target_layers contains negative index {layer}."
                    )
                if layer in seen_layers:
                    raise ConfigValidationError(
                        f"Phase {phase_idx}: target_layers contains duplicate index {layer}."
                    )
                seen_layers.add(layer)


def _check_phase_key_typos(entry: Dict[str, Any], phase_idx: int) -> None:
    """Detect common typos in phase entry keys."""
    for key in entry:
        if key not in _KNOWN_PHASE_KEYS and key in _TYPO_SUGGESTIONS:
            correct = _TYPO_SUGGESTIONS[key]
            raise ConfigValidationError(
                f"Phase {phase_idx}: found '{key}' but expected '{correct}'. "
                f"Did you mean '{correct}'?"
            )


def _validate_phase_target_kwargs(kwargs: Any) -> None:
    """Validate training.phase_target_kwargs."""
    if not isinstance(kwargs, dict):
        raise ConfigValidationError(
            "training.phase_target_kwargs must be a dict."
        )

    # base_ffn_keywords must be list[str]
    bfk = kwargs.get("base_ffn_keywords")
    if bfk is not None:
        if not isinstance(bfk, list):
            raise ConfigValidationError(
                "phase_target_kwargs.base_ffn_keywords must be a list."
            )
        for item in bfk:
            if not isinstance(item, str):
                raise ConfigValidationError(
                    "phase_target_kwargs.base_ffn_keywords must contain str items, "
                    f"got {type(item).__name__}."
                )

    # target_layers must be list[int]
    tl = kwargs.get("target_layers")
    if tl is not None:
        if not isinstance(tl, list):
            raise ConfigValidationError(
                "phase_target_kwargs.target_layers must be a list."
            )
        for item in tl:
            if not isinstance(item, int):
                raise ConfigValidationError(
                    "phase_target_kwargs.target_layers must contain int items, "
                    f"got {type(item).__name__}."
                )


# ===========================================================================
# MoE Stability Validation
# ===========================================================================

def _is_moe_strategy(strategy: str) -> bool:
    """Check if the strategy creates/uses MoE routing."""
    return strategy in _MOE_STRATEGIES


def _validate_moe_section(cfg: Dict[str, Any], strategy: str) -> None:
    """
    Validate the 'moe' config section for MoE stability.

    For MoE strategies (mixture_lora, moe_expert_lora), the moe section
    is REQUIRED and must contain stability parameters.
    """
    moe = cfg.get("moe")

    if not _is_moe_strategy(strategy):
        # Non-MoE strategy: warn if moe section present (likely mistake)
        if moe is not None:
            logger.warning(
                "[Validator] 'moe' section found but strategy is '%s' "
                "(not a MoE strategy). The moe section will be ignored.",
                strategy,
            )
        return

    # MoE strategy: moe section is required
    if moe is None:
        raise ConfigValidationError(
            "MoE strategy requires 'moe' section with stability parameters "
            "(router_z_loss_coef, load_balance).",
            category="MoE Config",
            fix="Add 'moe:' section with router_z_loss_coef: 0.001 and load_balance: {type: aux_loss, aux_loss_coef: 0.01}",
            doc=_MOE_DOC,
        )

    if not isinstance(moe, dict):
        raise ConfigValidationError(
            "'moe' section must be a dict, got {}.".format(type(moe).__name__)
        )

    # Check for typos in moe section keys
    _check_moe_typos(moe)

    # (A) Router z-loss
    _validate_router_z_loss(moe)

    # (B) Load balancing
    _validate_load_balance(moe)

    # (C) Capacity factor (optional but strict if present)
    _validate_capacity_factor(moe)

    # (D) Router precision
    _validate_router_dtype(moe)


def _check_moe_typos(moe: Dict[str, Any]) -> None:
    """Detect common typos in moe section keys."""
    for key in moe:
        if key in _MOE_TYPO_SUGGESTIONS:
            correct = _MOE_TYPO_SUGGESTIONS[key]
            raise ConfigValidationError(
                f"Found '{key}' in moe section. Did you mean '{correct}'? "
                f"The correct key is 'router_z_loss_coef'."
            )


def _validate_finite_float(
    value: Any,
    field_name: str,
    *,
    must_be_positive: bool = False,
    must_be_non_negative: bool = False,
    error_meta: Dict[str, str] | None = None,
) -> float:
    """Validate and return a finite float value, raising ConfigValidationError on problems.

    Args:
        error_meta: Optional dict with 'category', 'fix', 'doc' for 3-line error format.
    """
    meta = error_meta or {}

    if isinstance(value, bool):
        raise ConfigValidationError(
            f"{field_name} must be numeric (float), got bool.",
            **meta,
        )
    try:
        f = float(value)
    except (ValueError, TypeError):
        raise ConfigValidationError(
            f"{field_name} must be numeric (float), got {type(value).__name__} '{value}'.",
            **meta,
        )

    if math.isnan(f):
        raise ConfigValidationError(
            f"{field_name} must be finite, got NaN.",
            **meta,
        )
    if math.isinf(f):
        raise ConfigValidationError(
            f"{field_name} must be finite, got Inf.",
            **meta,
        )

    if must_be_positive and f <= 0:
        raise ConfigValidationError(
            f"{field_name} must be > 0, got {f}.",
            **meta,
        )
    if must_be_non_negative and f < 0:
        raise ConfigValidationError(
            f"{field_name} must be >= 0, got {f}.",
            **meta,
        )

    return f


def _validate_router_z_loss(moe: Dict[str, Any]) -> None:
    """Validate router z-loss coefficient (required for MoE)."""
    if "router_z_loss_coef" not in moe:
        raise ConfigValidationError(
            "moe.router_z_loss_coef is required for MoE strategies. "
            "Router z-loss stabilizes router logits and prevents numerical overflow.",
            category="MoE Config",
            fix="Set moe.router_z_loss_coef: 0.001 (ST-MoE recommended)",
            doc=_MOE_DOC,
        )

    val = _validate_finite_float(
        moe["router_z_loss_coef"],
        "moe.router_z_loss_coef",
        must_be_non_negative=True,
        error_meta={"category": "MoE Config", "fix": "Set moe.router_z_loss_coef: 0.001 (non-negative float)", "doc": _MOE_DOC},
    )

    if val == 0.0:
        logger.warning(
            "[Validator] moe.router_z_loss_coef is 0. This disables router z-loss, "
            "which may cause training instability at scale. "
            "Recommended: 0.001 (ST-MoE)."
        )
    elif val > 0.1:
        logger.warning(
            "[Validator] moe.router_z_loss_coef=%.4f is unusually large "
            "(> 0.1). ST-MoE recommends 0.001. Very large z-loss coefficients "
            "may overly constrain router logits.",
            val,
        )


def _validate_load_balance(moe: Dict[str, Any]) -> None:
    """Validate load balancing configuration (required for MoE)."""
    lb = moe.get("load_balance")
    if lb is None:
        raise ConfigValidationError(
            "moe.load_balance is required for MoE strategies. "
            "Load balancing prevents routing collapse where only a few experts receive tokens.",
            category="MoE Config",
            fix="Add moe.load_balance: {type: aux_loss, aux_loss_coef: 0.01}",
            doc=_MOE_DOC,
        )

    if not isinstance(lb, dict):
        raise ConfigValidationError(
            "moe.load_balance must be a dict, "
            f"got {type(lb).__name__}.",
            category="MoE Config",
            fix="Set moe.load_balance: {type: aux_loss, aux_loss_coef: 0.01}",
            doc=_MOE_DOC,
        )

    # Check for typos
    for key in lb:
        if key in _LB_TYPO_SUGGESTIONS:
            correct = _LB_TYPO_SUGGESTIONS[key]
            raise ConfigValidationError(
                f"Found '{key}' in moe.load_balance. Did you mean '{correct}'? "
                f"The correct key is '{correct}'."
            )

    lb_type = lb.get("type")
    if lb_type is None:
        raise ConfigValidationError(
            "moe.load_balance.type is required. "
            f"Supported types: {sorted(_VALID_LB_TYPES)}",
            category="MoE Config",
            fix="Set moe.load_balance.type: aux_loss",
            doc=_MOE_DOC,
        )

    if lb_type not in _VALID_LB_TYPES:
        raise ConfigValidationError(
            f"moe.load_balance.type '{lb_type}' is unknown. "
            f"Supported: {sorted(_VALID_LB_TYPES)}",
            category="MoE Config",
            fix=f"Use one of: {', '.join(sorted(_VALID_LB_TYPES))}",
            doc=_MOE_DOC,
        )

    # Type-specific validation
    if lb_type == "aux_loss":
        _validate_lb_aux_loss(lb)
    elif lb_type == "aux_loss_free":
        _validate_lb_aux_loss_free(lb)
    elif lb_type == "none":
        logger.warning(
            "[Validator] moe.load_balance.type is 'none'. "
            "No load balancing is applied. This risks routing collapse "
            "where most tokens go to a few experts. "
            "Consider using 'aux_loss' with aux_loss_coef=0.01."
        )


def _validate_lb_aux_loss(lb: Dict[str, Any]) -> None:
    """Validate aux_loss load balance type."""
    if "aux_loss_coef" not in lb:
        raise ConfigValidationError(
            "moe.load_balance.aux_loss_coef is required when type='aux_loss'.",
            category="MoE Config",
            fix="Set moe.load_balance.aux_loss_coef: 0.01",
            doc=_MOE_DOC,
        )

    val = _validate_finite_float(
        lb["aux_loss_coef"],
        "moe.load_balance.aux_loss_coef",
        must_be_non_negative=True,
        error_meta={"category": "MoE Config", "fix": "Set moe.load_balance.aux_loss_coef: 0.01 (non-negative float)", "doc": _MOE_DOC},
    )

    if val == 0.0:
        logger.warning(
            "[Validator] moe.load_balance.aux_loss_coef is 0 with type='aux_loss'. "
            "This effectively disables load balancing (same as type='none')."
        )


def _validate_lb_aux_loss_free(lb: Dict[str, Any]) -> None:
    """Validate aux_loss_free load balance type (DeepSeek-V3 style)."""
    if "bias_update_speed" not in lb:
        raise ConfigValidationError(
            "moe.load_balance.bias_update_speed is required when type='aux_loss_free'. "
            "This parameter controls how fast expert biases adapt.",
            category="MoE Config",
            fix="Set moe.load_balance.bias_update_speed: 0.001",
            doc=_MOE_DOC,
        )

    _validate_finite_float(
        lb["bias_update_speed"],
        "moe.load_balance.bias_update_speed",
        error_meta={"category": "MoE Config", "fix": "Set moe.load_balance.bias_update_speed: 0.001 (numeric float)", "doc": _MOE_DOC},
    )


def _validate_capacity_factor(moe: Dict[str, Any]) -> None:
    """Validate capacity factor settings (optional but strict)."""
    cf_train = moe.get("capacity_factor_train")
    cf_eval = moe.get("capacity_factor_eval")

    _cf_meta = {"category": "MoE Config", "doc": _MOE_DOC}

    if cf_train is not None:
        cf_train_val = _validate_finite_float(
            cf_train,
            "moe.capacity_factor_train",
            must_be_positive=True,
            error_meta={**_cf_meta, "fix": "Set moe.capacity_factor_train: 1.25 (positive float)"},
        )
    else:
        cf_train_val = None

    if cf_eval is not None:
        cf_eval_val = _validate_finite_float(
            cf_eval,
            "moe.capacity_factor_eval",
            must_be_positive=True,
            error_meta={**_cf_meta, "fix": "Set moe.capacity_factor_eval: 2.0 (positive float)"},
        )
    else:
        cf_eval_val = None

    # Cross-check: eval should typically be >= train (ST-MoE uses train=1.25, eval=2.0)
    if cf_train_val is not None and cf_eval_val is not None:
        if cf_eval_val < cf_train_val:
            logger.warning(
                "[Validator] moe.capacity_factor_eval (%.2f) is less than "
                "capacity_factor_train (%.2f). ST-MoE recommends eval CF >= train CF "
                "(e.g., train=1.25, eval=2.0) to reduce token dropping at eval time.",
                cf_eval_val, cf_train_val,
            )


def _validate_router_dtype(moe: Dict[str, Any]) -> None:
    """Validate router compute dtype (float32 recommended)."""
    router_dtype = moe.get("router_dtype")
    if router_dtype is None:
        return  # Not specified, defaults to float32 in code

    if router_dtype not in _VALID_ROUTER_DTYPES:
        raise ConfigValidationError(
            f"moe.router_dtype '{router_dtype}' is invalid. "
            f"Supported: {sorted(_VALID_ROUTER_DTYPES)}.",
            category="MoE Config",
            fix="Set moe.router_dtype: float32 (recommended for numerical stability)",
            doc=_MOE_DOC,
        )

    if router_dtype in ("float16", "bfloat16"):
        logger.warning(
            "[Validator] moe.router_dtype='%s' may cause numerical instability "
            "in router softmax/exp computation. "
            "ST-MoE recommends float32 for router precision. "
            "Consider using 'float32' or relying on router z-loss for stability.",
            router_dtype,
        )


# ===========================================================================
# MoE-Phase Cross-Checks
# ===========================================================================

def _validate_moe_phase_cross_checks(cfg: Dict[str, Any], strategy: str) -> None:
    """Cross-check between MoE strategy and phase schedule."""
    if not _is_moe_strategy(strategy):
        return

    training = cfg.get("training", {})
    phases = training.get("phases")
    if phases is None or not isinstance(phases, list):
        return

    # Check: MoE strategy but router never appears in any phase
    all_groups: Set[str] = set()
    for entry in phases:
        if isinstance(entry, dict):
            trainable = entry.get("trainable", [])
            if isinstance(trainable, list):
                all_groups.update(trainable)

    if "router" not in all_groups:
        logger.warning(
            "[Validator] MoE strategy '%s' is used but 'router' never appears "
            "in any training phase. The router will remain frozen throughout training. "
            "This may prevent the MoE routing from adapting to your data.",
            strategy,
        )


# ===========================================================================
# Data section validation
# ===========================================================================

_DATA_DOC = "docs/tutorials/00_data_preprocessing.md"

_VALID_DATA_FORMATS = ("processed", "raw")
_VALID_DATA_TASKS = ("sft", "preference", "prompted_preference", "prompt_only")

# data.task → compatible training.type mapping
_TASK_COMPAT = {
    "sft": ("sft", "ppo"),
    "preference": ("dpo", "orpo", "rm"),
    "prompted_preference": ("dpo", "orpo", "rm"),
    "prompt_only": ("ppo",),
}


def _validate_task_type_compat(task: str, training_type: str) -> None:
    """Raise if data.task is incompatible with training.type."""
    compat = _TASK_COMPAT.get(task)
    if compat is None:
        return
    if training_type not in compat:
        raise ConfigValidationError(
            f"data.task='{task}' is incompatible with training.type='{training_type}'. "
            f"Task '{task}' produces data for {', '.join(compat)} training",
            category="Data Config",
            fix=f"Set --set training.type={compat[0]} or change data.task to match",
            doc=_DATA_DOC,
        )


def _validate_data_section(cfg: Dict[str, Any]) -> None:
    """Validate the optional ``data`` config section (static, no file I/O)."""
    data = cfg.get("data")
    if data is None:
        return  # data section is optional (backward compat)

    if not isinstance(data, dict):
        raise ConfigValidationError(
            "data section must be a dict",
            category="Data Config",
            fix="Provide data as a YAML mapping with format, path, etc.",
            doc=_DATA_DOC,
        )

    fmt = data.get("format", "processed")
    if fmt not in _VALID_DATA_FORMATS:
        raise ConfigValidationError(
            f"data.format must be 'processed' or 'raw', got '{fmt}'",
            category="Data Config",
            fix="Set data.format to 'processed' or 'raw'",
            doc=_DATA_DOC,
        )

    if not data.get("path"):
        raise ConfigValidationError(
            "data.path is required",
            category="Data Config",
            fix="Set data.path to the JSONL file path",
            doc=_DATA_DOC,
        )

    if fmt == "raw":
        task = data.get("task")
        if not task or task not in _VALID_DATA_TASKS:
            raise ConfigValidationError(
                f"data.task is required for raw format. "
                f"Valid tasks: {', '.join(_VALID_DATA_TASKS)}",
                category="Data Config",
                fix=f"Set data.task to one of: {', '.join(_VALID_DATA_TASKS)}",
                doc=_DATA_DOC,
            )

        # Cross-check: data.task must be compatible with training.type
        training_type = cfg.get("training", {}).get("type", "sft").lower()
        _validate_task_type_compat(task, training_type)


# -----------------------------------------------------------------------
# 7. Logging section validation
# -----------------------------------------------------------------------

_VALID_METRICS_LEVELS = ("minimal", "advanced")
_LOGGING_DOC = "docs/tutorials/10_metrics_monitoring.md"


def _validate_logging_section(cfg: Dict[str, Any]) -> None:
    """Validate the optional ``logging`` config section."""
    log_cfg = cfg.get("logging")
    if log_cfg is None:
        return

    if not isinstance(log_cfg, dict):
        raise ConfigValidationError(
            "logging section must be a dict",
            category="Logging Config",
            fix="Provide logging as a YAML mapping with metrics_level, tensorboard, etc.",
            doc=_LOGGING_DOC,
        )

    level = log_cfg.get("metrics_level", "minimal")
    if level not in _VALID_METRICS_LEVELS:
        raise ConfigValidationError(
            f"Unknown metrics_level '{level}'. Valid: {', '.join(_VALID_METRICS_LEVELS)}",
            category="Logging Config",
            fix="Set logging.metrics_level to 'minimal' or 'advanced'",
            doc=_LOGGING_DOC,
        )

    tb = log_cfg.get("tensorboard")
    if tb is not None:
        if not isinstance(tb, dict):
            raise ConfigValidationError(
                "logging.tensorboard must be a dict",
                category="Logging Config",
                fix="Provide tensorboard as a YAML mapping, e.g. tensorboard: {enabled: true}",
                doc=_LOGGING_DOC,
            )
        enabled = tb.get("enabled")
        if enabled is not None and not isinstance(enabled, bool):
            raise ConfigValidationError(
                f"logging.tensorboard.enabled must be a boolean, got {type(enabled).__name__}",
                category="Logging Config",
                fix="Set logging.tensorboard.enabled to true or false",
                doc=_LOGGING_DOC,
            )


# ===========================================================================
# 8. LoRA Handoff Scheduling Validation (H1–H7)
# ===========================================================================

_HANDOFF_DOC = "docs/fixtures/specs/lora_handoff_spec.md"
_KNOWN_HANDOFF_KEYS = {"expert_lora", "attn_lora", "base_ffn_ramp", "export"}
_VALID_CURVES = ("linear", "cosine")
_VALID_END_ACTIONS = ("keep", "freeze")


def _validate_lora_handoff(cfg: Dict[str, Any]) -> None:
    """Validate training.lora_handoff section (rules H1–H7)."""
    import warnings

    training = cfg.get("training", {})
    if not isinstance(training, dict):
        return

    handoff = training.get("lora_handoff")
    if handoff is None:
        return

    # H1: must be dict
    if not isinstance(handoff, dict):
        raise ConfigValidationError(
            "training.lora_handoff must be a dict",
            category="Handoff Config",
            fix="Provide lora_handoff as a YAML mapping",
            doc=_HANDOFF_DOC,
        )

    # H6: typo detection (unknown keys)
    for key in handoff:
        if key not in _KNOWN_HANDOFF_KEYS:
            warnings.warn(
                f"[Validator] Unknown key '{key}' in training.lora_handoff. "
                f"Known keys: {sorted(_KNOWN_HANDOFF_KEYS)}. Check for typos.",
                UserWarning,
                stacklevel=2,
            )

    # H2: component schedules (expert_lora, attn_lora)
    for comp_name in ("expert_lora", "attn_lora"):
        comp = handoff.get(comp_name)
        if comp is not None:
            _validate_handoff_component(comp, comp_name)

    # H3: base_ffn_ramp
    ramp = handoff.get("base_ffn_ramp")
    if ramp is not None:
        _validate_base_ffn_ramp(ramp)

    # H4: export
    export = handoff.get("export")
    if export is not None:
        _validate_handoff_export(export, warnings)

    # H5: time ordering and alignment checks
    _validate_handoff_timing(cfg, handoff, warnings)

    # H7: strategy compatibility (ERROR, not warning)
    # Only enforce P1/P2 if handoff has actual schedule content
    _has_schedule = any(handoff.get(k) is not None for k in ("expert_lora", "attn_lora", "base_ffn_ramp"))
    if _has_schedule:
        injection = cfg.get("injection", {})
        strategy = injection.get("strategy", "")

        # P1: strategy must be moe_expert_lora
        if strategy != "moe_expert_lora":
            raise ConfigValidationError(
                f"training.lora_handoff requires injection.strategy=moe_expert_lora, "
                f"got '{strategy}'",
                category="Handoff Config",
                fix="Use strategy: moe_expert_lora, or remove training.lora_handoff",
                doc=_HANDOFF_DOC,
            )

        # P2: base_ffn must appear in at least one phase
        phases = training.get("phases", [])
        has_base_ffn = False
        if isinstance(phases, list):
            for phase in phases:
                if isinstance(phase, dict):
                    trainable = phase.get("trainable", [])
                    if isinstance(trainable, list) and "base_ffn" in trainable:
                        has_base_ffn = True
                        break
        if not has_base_ffn:
            raise ConfigValidationError(
                "training.lora_handoff requires base_ffn in at least one training phase",
                category="Handoff Config",
                fix="Add base_ffn to trainable list in a later phase "
                    "(e.g. trainable: [\"lora\", \"router\", \"base_ffn\"])",
                doc=_HANDOFF_DOC,
            )

        # H8: DPO + Handoff 경고 — LoRA frozen 후 policy=reference → loss=0.6931
        tt = training.get("type", "sft").lower()
        if tt == "dpo":
            warnings.warn(
                "[Validator] DPO + LoRA Handoff: LoRA가 완전히 fade/freeze되면 "
                "policy와 reference가 동일해져 DPO loss=ln(2)≈0.6931, reward=0이 됩니다. "
                "DPO에서는 Handoff 사용을 권장하지 않습니다. SFT 또는 ORPO로 대체하세요.",
                UserWarning,
                stacklevel=2,
            )

        # attn_lora schedule requires injection.attn_lora.enabled
        if handoff.get("attn_lora") is not None:
            attn_cfg = injection.get("attn_lora", {})
            if isinstance(attn_cfg, dict) and not attn_cfg.get("enabled", False):
                raise ConfigValidationError(
                    "training.lora_handoff.attn_lora schedule is defined "
                    "but injection.attn_lora.enabled is false",
                    category="Handoff Config",
                    fix="Set injection.attn_lora.enabled: true, or remove "
                        "lora_handoff.attn_lora",
                    doc=_HANDOFF_DOC,
                )


def _validate_handoff_timing(cfg: Dict[str, Any], handoff: Dict, warnings_mod) -> None:
    """Validate handoff timing consistency (H5a–H5f)."""
    training = cfg.get("training", {})
    max_steps = training.get("max_train_steps")

    # Find base_ffn phase start step
    base_ffn_step = None
    phases = training.get("phases", [])
    if isinstance(phases, list):
        for phase in phases:
            if isinstance(phase, dict):
                trainable = phase.get("trainable", [])
                if isinstance(trainable, list) and "base_ffn" in trainable:
                    base_ffn_step = int(phase.get("step", 0))
                    break

    # Collect fade end steps for alignment checks
    expert_fade_end = None

    for comp_name in ("expert_lora", "attn_lora"):
        comp = handoff.get(comp_name)
        if comp is None or not isinstance(comp, dict):
            continue

        start = comp.get("start_step")
        dur = comp.get("duration_steps")
        if start is None or dur is None:
            continue
        try:
            start_int = int(start)
            dur_int = int(dur)
        except (ValueError, TypeError):
            continue

        fade_end = start_int + dur_int
        if comp_name == "expert_lora":
            expert_fade_end = fade_end

        # H5d: fade start_step >= max_train_steps → error (fade never runs)
        if max_steps is not None:
            try:
                max_int = int(max_steps)
            except (ValueError, TypeError):
                max_int = None
            if max_int is not None and start_int >= max_int:
                raise ConfigValidationError(
                    f"training.lora_handoff.{comp_name}.start_step ({start_int}) "
                    f">= max_train_steps ({max_int}). Fade will never execute",
                    category="Handoff Config",
                    fix=f"Set {comp_name}.start_step to a value < max_train_steps",
                    doc=_HANDOFF_DOC,
                )

        # H5a: fade exceeds max_train_steps → warning
        if max_steps is not None:
            try:
                max_int = int(max_steps)
            except (ValueError, TypeError):
                max_int = None
            if max_int is not None and fade_end > max_int:
                warnings_mod.warn(
                    f"[Validator] training.lora_handoff.{comp_name} fade ends at "
                    f"step {fade_end} which exceeds max_train_steps ({max_int}). "
                    f"Fade will not complete within training.",
                    UserWarning,
                    stacklevel=3,
                )

        # H5c: fade start_step < base_ffn phase start → error
        if base_ffn_step is not None and start_int < base_ffn_step:
            raise ConfigValidationError(
                f"training.lora_handoff.{comp_name}.start_step ({start_int}) is before "
                f"base_ffn phase start (step {base_ffn_step}). "
                f"Handoff fade must not begin before base_ffn is trainable",
                category="Handoff Config",
                fix=f"Set {comp_name}.start_step >= {base_ffn_step} "
                    f"(base_ffn phase start step)",
                doc=_HANDOFF_DOC,
            )

    # H5b: ramp.end_step > max_train_steps → warning
    ramp = handoff.get("base_ffn_ramp")
    if ramp is not None and isinstance(ramp, dict):
        ramp_end = ramp.get("end_step")
        if ramp_end is not None and max_steps is not None:
            try:
                ramp_end_int = int(ramp_end)
                max_int = int(max_steps)
            except (ValueError, TypeError):
                ramp_end_int = None
                max_int = None
            if ramp_end_int is not None and max_int is not None and ramp_end_int > max_int:
                warnings_mod.warn(
                    f"[Validator] training.lora_handoff.base_ffn_ramp.end_step "
                    f"({ramp_end_int}) exceeds max_train_steps ({max_int}). "
                    f"Ramp will not complete within training.",
                    UserWarning,
                    stacklevel=3,
                )

        # H5e/H5f: ramp alignment with expert_lora fade
        if expert_fade_end is not None and ramp_end is not None:
            try:
                ramp_end_int = int(ramp_end)
            except (ValueError, TypeError):
                ramp_end_int = None
            if ramp_end_int is not None:
                if ramp_end_int < expert_fade_end:
                    # H5e: ramp ends before fade → warning
                    warnings_mod.warn(
                        f"[Validator] base_ffn_ramp ends at step {ramp_end_int} "
                        f"but expert_lora fade ends at step {expert_fade_end}. "
                        f"Ramp ends earlier than fade — the fade tail "
                        f"(step {ramp_end_int}~{expert_fade_end}) has no LR "
                        f"compensation, risking a loss spike.",
                        UserWarning,
                        stacklevel=3,
                    )
                elif ramp_end_int > expert_fade_end:
                    # H5f: ramp ends after fade → warning
                    warnings_mod.warn(
                        f"[Validator] base_ffn_ramp ends at step {ramp_end_int} "
                        f"but expert_lora fade ends at step {expert_fade_end}. "
                        f"Ramp ends later than fade — LR boost continues after "
                        f"LoRA is already gone, risking instability.",
                        UserWarning,
                        stacklevel=3,
                    )


def _validate_handoff_component(comp: Any, name: str) -> None:
    """Validate a handoff component schedule (H2)."""
    if not isinstance(comp, dict):
        raise ConfigValidationError(
            f"training.lora_handoff.{name} must be a dict",
            category="Handoff Config",
            fix=f"Provide {name} as a YAML mapping with start_step, duration_steps",
            doc=_HANDOFF_DOC,
        )

    # Required: start_step
    if "start_step" not in comp:
        raise ConfigValidationError(
            f"training.lora_handoff.{name}.start_step is required",
            category="Handoff Config",
            fix=f"Add start_step to {name} (integer >= 0)",
            doc=_HANDOFF_DOC,
        )
    start = comp["start_step"]
    try:
        start_int = int(start)
    except (ValueError, TypeError):
        raise ConfigValidationError(
            f"training.lora_handoff.{name}.start_step must be an integer",
            category="Handoff Config",
            fix=f"Set {name}.start_step to an integer >= 0",
            doc=_HANDOFF_DOC,
        )
    if start_int < 0:
        raise ConfigValidationError(
            f"training.lora_handoff.{name}.start_step must be >= 0, got {start_int}",
            category="Handoff Config",
            fix=f"Set {name}.start_step to an integer >= 0",
            doc=_HANDOFF_DOC,
        )

    # Required: duration_steps
    if "duration_steps" not in comp:
        raise ConfigValidationError(
            f"training.lora_handoff.{name}.duration_steps is required",
            category="Handoff Config",
            fix=f"Add duration_steps to {name} (integer > 0)",
            doc=_HANDOFF_DOC,
        )
    dur = comp["duration_steps"]
    try:
        dur_int = int(dur)
    except (ValueError, TypeError):
        raise ConfigValidationError(
            f"training.lora_handoff.{name}.duration_steps must be an integer",
            category="Handoff Config",
            fix=f"Set {name}.duration_steps to an integer > 0",
            doc=_HANDOFF_DOC,
        )
    if dur_int <= 0:
        raise ConfigValidationError(
            f"training.lora_handoff.{name}.duration_steps must be > 0, got {dur_int}",
            category="Handoff Config",
            fix=f"Set {name}.duration_steps to an integer > 0",
            doc=_HANDOFF_DOC,
        )

    # Optional: end_scale (0 ≤ x ≤ 1)
    end_scale = comp.get("end_scale")
    if end_scale is not None:
        try:
            es = float(end_scale)
        except (ValueError, TypeError):
            raise ConfigValidationError(
                f"training.lora_handoff.{name}.end_scale must be a float",
                category="Handoff Config",
                fix=f"Set {name}.end_scale to a float in [0, 1]",
                doc=_HANDOFF_DOC,
            )
        if es < 0.0 or es > 1.0:
            raise ConfigValidationError(
                f"training.lora_handoff.{name}.end_scale must be in [0, 1], got {es}",
                category="Handoff Config",
                fix=f"Set {name}.end_scale to a float in [0, 1]",
                doc=_HANDOFF_DOC,
            )

    # Optional: curve
    curve = comp.get("curve")
    if curve is not None and curve not in _VALID_CURVES:
        raise ConfigValidationError(
            f"training.lora_handoff.{name}.curve must be one of {_VALID_CURVES}, got '{curve}'",
            category="Handoff Config",
            fix=f"Set {name}.curve to 'linear' or 'cosine'",
            doc=_HANDOFF_DOC,
        )

    # Optional: end_action
    end_action = comp.get("end_action")
    if end_action is not None and end_action not in _VALID_END_ACTIONS:
        raise ConfigValidationError(
            f"training.lora_handoff.{name}.end_action must be one of {_VALID_END_ACTIONS}, got '{end_action}'",
            category="Handoff Config",
            fix=f"Set {name}.end_action to 'keep' or 'freeze'",
            doc=_HANDOFF_DOC,
        )


def _validate_base_ffn_ramp(ramp: Any) -> None:
    """Validate base_ffn_ramp section (H3)."""
    if not isinstance(ramp, dict):
        raise ConfigValidationError(
            "training.lora_handoff.base_ffn_ramp must be a dict",
            category="Handoff Config",
            fix="Provide base_ffn_ramp as a YAML mapping with start_step, end_step",
            doc=_HANDOFF_DOC,
        )

    # Required: start_step
    if "start_step" not in ramp:
        raise ConfigValidationError(
            "training.lora_handoff.base_ffn_ramp.start_step is required",
            category="Handoff Config",
            fix="Add start_step to base_ffn_ramp (integer >= 0)",
            doc=_HANDOFF_DOC,
        )

    # Required: end_step
    if "end_step" not in ramp:
        raise ConfigValidationError(
            "training.lora_handoff.base_ffn_ramp.end_step is required",
            category="Handoff Config",
            fix="Add end_step to base_ffn_ramp (integer > start_step)",
            doc=_HANDOFF_DOC,
        )

    try:
        start = int(ramp["start_step"])
        end = int(ramp["end_step"])
    except (ValueError, TypeError):
        raise ConfigValidationError(
            "base_ffn_ramp start_step and end_step must be integers",
            category="Handoff Config",
            fix="Set start_step and end_step to integers",
            doc=_HANDOFF_DOC,
        )

    if end <= start:
        raise ConfigValidationError(
            f"base_ffn_ramp.end_step ({end}) must be > start_step ({start})",
            category="Handoff Config",
            fix="Set end_step to a value greater than start_step",
            doc=_HANDOFF_DOC,
        )

    # Optional multipliers (must be > 0)
    for key in ("start_multiplier", "end_multiplier"):
        val = ramp.get(key)
        if val is not None:
            try:
                f = float(val)
            except (ValueError, TypeError):
                raise ConfigValidationError(
                    f"base_ffn_ramp.{key} must be a float",
                    category="Handoff Config",
                    fix=f"Set {key} to a positive float",
                    doc=_HANDOFF_DOC,
                )
            if f <= 0:
                raise ConfigValidationError(
                    f"base_ffn_ramp.{key} (multiplier) must be > 0, got {f}",
                    category="Handoff Config",
                    fix=f"Set {key} to a positive float",
                    doc=_HANDOFF_DOC,
                )


def _validate_handoff_export(export: Any, warnings_mod) -> None:
    """Validate export section (H4)."""
    if not isinstance(export, dict):
        raise ConfigValidationError(
            "training.lora_handoff.export must be a dict",
            category="Handoff Config",
            fix="Provide export as a YAML mapping",
            doc=_HANDOFF_DOC,
        )

    remove = export.get("remove_adapters_if_zero_scale", False)
    merge = export.get("merge_adapters_on_export", False)
    if remove and merge:
        warnings_mod.warn(
            "[Validator] training.lora_handoff.export: both remove_adapters_if_zero_scale "
            "and merge_adapters_on_export are true. merge will run first, then remove "
            "will be a no-op since LoRA params are already replaced.",
            UserWarning,
            stacklevel=3,
        )


# -----------------------------------------------------------------------
# 9. Model load precision validation
# -----------------------------------------------------------------------

_LOAD_PRECISION_DOC = "docs/fixtures/specs/load_precision_spec.md"
_VALID_MODES = {"fp32", "fp16", "bf16", "int8", "int4"}
_VALID_COMPUTE_DTYPES = {"fp16", "bf16"}
_VALID_QUANT_TYPES = {"nf4", "fp4"}


def _validate_load_precision(cfg: Dict[str, Any]) -> None:
    """Validate the optional ``model.load_precision`` section."""
    # Legacy quant_bits deprecation warning
    quant_bits = cfg.get("training", {}).get("quant_bits")
    if quant_bits is not None:
        logger.warning(
            "[Deprecated] training.quant_bits is deprecated. "
            "Use model.load_precision.mode instead."
        )

    model_cfg = cfg.get("model")
    if model_cfg is None:
        return

    if not isinstance(model_cfg, dict):
        return

    lp = model_cfg.get("load_precision")
    if lp is None:
        return

    if not isinstance(lp, dict):
        raise ConfigValidationError(
            "model.load_precision must be a dict",
            category="Model Config",
            fix="Provide load_precision as a YAML mapping with mode, etc.",
            doc=_LOAD_PRECISION_DOC,
        )

    # LP-2: mode required and must be valid
    mode = lp.get("mode")
    if mode is None or mode not in _VALID_MODES:
        raise ConfigValidationError(
            f"model.load_precision.mode is required and must be one of "
            f"{', '.join(sorted(_VALID_MODES))}, got '{mode}'",
            category="Model Config",
            fix=f"Set mode to one of: {', '.join(sorted(_VALID_MODES))}",
            doc=_LOAD_PRECISION_DOC,
        )

    # LP-3: compute_dtype
    compute_dtype = lp.get("compute_dtype")
    if compute_dtype is not None and compute_dtype not in _VALID_COMPUTE_DTYPES:
        raise ConfigValidationError(
            f"model.load_precision.compute_dtype must be one of "
            f"{', '.join(sorted(_VALID_COMPUTE_DTYPES))}, got '{compute_dtype}'",
            category="Model Config",
            fix=f"Set compute_dtype to one of: {', '.join(sorted(_VALID_COMPUTE_DTYPES))}",
            doc=_LOAD_PRECISION_DOC,
        )

    # LP-4: quant_type
    quant_type = lp.get("quant_type")
    if quant_type is not None and quant_type not in _VALID_QUANT_TYPES:
        raise ConfigValidationError(
            f"model.load_precision.quant_type must be one of "
            f"{', '.join(sorted(_VALID_QUANT_TYPES))}, got '{quant_type}'",
            category="Model Config",
            fix=f"Set quant_type to one of: {', '.join(sorted(_VALID_QUANT_TYPES))}",
            doc=_LOAD_PRECISION_DOC,
        )

    # LP-5: double_quant must be bool
    double_quant = lp.get("double_quant")
    if double_quant is not None and not isinstance(double_quant, bool):
        raise ConfigValidationError(
            f"model.load_precision.double_quant must be a bool, got '{type(double_quant).__name__}'",
            category="Model Config",
            fix="Set double_quant to true or false",
            doc=_LOAD_PRECISION_DOC,
        )

    # LP-6: dequantize_on_train must be bool
    deq = lp.get("dequantize_on_train")
    if deq is not None and not isinstance(deq, bool):
        raise ConfigValidationError(
            f"model.load_precision.dequantize_on_train must be a bool, got '{type(deq).__name__}'",
            category="Model Config",
            fix="Set dequantize_on_train to true or false",
            doc=_LOAD_PRECISION_DOC,
        )

    # LP-8: int4/int8 requires CUDA
    if mode in ("int4", "int8"):
        device = str(cfg.get("device", "cuda:0")).lower()
        if "cuda" not in device:
            raise ConfigValidationError(
                f"model.load_precision.mode='{mode}' requires a CUDA device, "
                f"got device='{device}'",
                category="Model Config",
                fix="Set device to a CUDA device (e.g. cuda:0)",
                doc=_LOAD_PRECISION_DOC,
            )

    # LP-7: int4/int8 + base_ffn trainable + dequantize_on_train=false → warning
    if mode in ("int4", "int8") and deq is False:
        phases = cfg.get("training", {}).get("phases", [])
        has_base_ffn = any(
            "base_ffn" in (p.get("trainable") or [])
            for p in phases if isinstance(p, dict)
        )
        if has_base_ffn:
            logger.warning(
                "[Validator] model.load_precision.mode='%s' with "
                "dequantize_on_train=false and base_ffn in trainable phases. "
                "Training quantized base_ffn parameters may produce "
                "incorrect gradients. Consider enabling dequantize_on_train.",
                mode,
            )
