# eulerforge/utils/data_validator.py
# -*- coding: utf-8 -*-
"""
Runtime validation of data files (JSONL row schema).

These checks run AFTER config validation passes, reading actual file rows
to catch missing keys before the DataLoader worker encounters them.
"""
from __future__ import annotations

import json
import logging
from typing import Dict

from .validator import ConfigValidationError

logger = logging.getLogger(__name__)

_DATA_DOC = "docs/tutorials/00_data_preprocessing.md"

# Required keys by training type for processed data
_PROCESSED_KEYS = {
    "sft": ["input_ids"],
    "dpo": ["chosen_input_ids", "rejected_input_ids", "chosen_labels", "rejected_labels"],
    "orpo": ["chosen_input_ids", "rejected_input_ids", "chosen_labels", "rejected_labels"],
    "rm": ["chosen_input_ids", "rejected_input_ids", "chosen_labels", "rejected_labels"],
    "ppo": ["input_ids"],
}

# Required raw columns by task
_RAW_REQUIRED = {
    "sft": {
        "any_of": [["text_col"], ["prompt_col", "response_col"]],
    },
    "preference": {
        "all_of": ["chosen_col", "rejected_col"],
    },
    "prompted_preference": {
        "all_of": ["prompt_col", "chosen_col", "rejected_col"],
    },
}


def validate_processed_data(path: str, training_type: str, n: int = 5) -> None:
    """Check first *n* rows of processed JSONL for required keys.

    Raises :class:`ConfigValidationError` with 3-line format on missing keys.
    """
    required = _PROCESSED_KEYS.get(training_type, _PROCESSED_KEYS["sft"])

    rows = _read_first_n(path, n)
    if not rows:
        raise ConfigValidationError(
            f"Data file is empty: {path}",
            category="Data",
            fix="Provide a non-empty JSONL file, or run `eulerforge preprocess` first",
            doc=_DATA_DOC,
        )

    for i, row in enumerate(rows):
        for key in required:
            if key not in row:
                raise ConfigValidationError(
                    f"processed dataset row {i} missing '{key}'",
                    category="Data",
                    fix=f"Run `eulerforge preprocess ...` or set data.format=raw with schema mapping",
                    doc=_DATA_DOC,
                )


def validate_raw_data(
    path: str,
    task: str,
    schema: Dict[str, str],
    n: int = 5,
) -> None:
    """Check first *n* rows of raw JSONL for schema columns.

    Raises :class:`ConfigValidationError` with 3-line format on missing columns.
    """
    rows = _read_first_n(path, n)
    if not rows:
        raise ConfigValidationError(
            f"Data file is empty: {path}",
            category="Data",
            fix="Provide a non-empty raw JSONL file",
            doc=_DATA_DOC,
        )

    req = _RAW_REQUIRED.get(task)
    if req is None:
        return

    if "all_of" in req:
        _check_all_of(rows, req["all_of"], schema, task)
    elif "any_of" in req:
        _check_any_of(rows, req["any_of"], schema, task)


def _check_all_of(rows, col_refs, schema, task):
    """All listed schema refs must resolve to columns present in every row."""
    for col_ref in col_refs:
        actual_col = schema.get(col_ref, col_ref.replace("_col", ""))
        for i, row in enumerate(rows):
            if actual_col not in row:
                raise ConfigValidationError(
                    f"raw {task} data row {i} missing column '{actual_col}'",
                    category="Data",
                    fix=f"Ensure column '{actual_col}' exists or set data.schema.{col_ref}",
                    doc=_DATA_DOC,
                )


def _check_any_of(rows, groups, schema, task):
    """At least one group of columns must be fully present in every row."""
    for i, row in enumerate(rows):
        satisfied = False
        for group in groups:
            actual_cols = [schema.get(ref, ref.replace("_col", "")) for ref in group]
            if all(col in row for col in actual_cols):
                satisfied = True
                break
        if not satisfied:
            # Build a human-readable message
            options = []
            for group in groups:
                cols = [schema.get(ref, ref.replace("_col", "")) for ref in group]
                options.append(", ".join(f"'{c}'" for c in cols))
            raise ConfigValidationError(
                f"raw {task} data row {i} missing required columns. "
                f"Need one of: [{' | '.join(options)}]",
                category="Data",
                fix=f"Add the required columns or set data.schema mapping",
                doc=_DATA_DOC,
            )


def _read_first_n(path: str, n: int):
    """Read first *n* non-empty lines from a JSONL file."""
    rows = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    rows.append(json.loads(line))
                    if len(rows) >= n:
                        break
    except FileNotFoundError:
        raise ConfigValidationError(
            f"Data file not found: {path}",
            category="Data",
            fix="Check the file path in your config",
            doc=_DATA_DOC,
        )
    return rows
