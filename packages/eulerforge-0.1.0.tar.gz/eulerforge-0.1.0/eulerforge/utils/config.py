# -*- coding: utf-8 -*-
"""
eulerforge.utils.config

YAML preset 기반 실험 구성을 로드하고, CLI override를 안전하게 머지하는 유틸.

설계 목표
- YAML preset을 "기본 진실(source of truth)"로 두되, CLI에서 필요한 일부만 override 가능.
- override는 dot-path(예: training.lr=2e-5)도 지원해서 grid search / wrapper가 쓰기 편하게.
- 최종 resolved config를 그대로 JSON으로 저장할 수 있게(재현성) 구성.

주의
- yaml.safe_load만 사용 (임의 객체 실행 위험 최소화)
- 아직 스키마 검증(pydantic 등)은 넣지 않고, 1차로 "얕은 검증 + 머지"에 집중.
"""

from __future__ import annotations

import copy
import json
import os
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import yaml


JsonDict = Dict[str, Any]


# ---------------------------------------------------------------------
# IO
# ---------------------------------------------------------------------
def load_yaml(path: str) -> JsonDict:
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    with open(path, "r", encoding="utf-8") as f:
        obj = yaml.safe_load(f)
    if obj is None:
        return {}
    if not isinstance(obj, dict):
        raise ValueError(f"YAML root must be a mapping/dict: {path}")
    return obj


def save_json(path: str, obj: Any) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------
# Dict helpers (flatten / dotpath)
# ---------------------------------------------------------------------
def flatten_dict(d: Any, prefix: str = "") -> Dict[str, Any]:
    """
    Nested dict -> {"a.b.c": value} 형태로 flatten.
    (기존 grid search wrapper의 _flatten 패턴을 범용화) [file:1]
    """
    out: Dict[str, Any] = {}
    if isinstance(d, dict):
        for k, v in d.items():
            p = f"{prefix}.{k}" if prefix else str(k)
            out.update(flatten_dict(v, p))
    else:
        out[prefix] = d
    return out


def get_by_path(d: JsonDict, path: str, default: Any = None) -> Any:
    cur: Any = d
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return cur


def set_by_path(d: JsonDict, path: str, value: Any) -> None:
    """
    d["a"]["b"]["c"] = value 형태로 설정(중간 dict 자동 생성).
    """
    parts = path.split(".")
    cur: Any = d
    for p in parts[:-1]:
        if p not in cur or not isinstance(cur[p], dict):
            cur[p] = {}
        cur = cur[p]
    cur[parts[-1]] = value


def _is_numeric_key_dict(v: Any) -> bool:
    """Check if value is a dict with only numeric-string keys.

    CLI overrides like `training.phases.1.step=10` produce
    `{"phases": {"1": {"step": 10}}}` — the "1" key signals list index intent.
    """
    return (
        isinstance(v, dict)
        and len(v) > 0
        and all(isinstance(k, str) and k.isdigit() for k in v.keys())
    )


def _merge_list_with_index_dict(base_list: list, index_dict: dict) -> list:
    """Apply index-based overrides from a numeric-key dict to a list.

    Supports sparse updates: only the indices in `index_dict` are modified.
    `index_dict[str(i)]` value is deep-merged into `base_list[i]` if both are dicts,
    otherwise replaces the element.
    """
    out = copy.deepcopy(base_list)
    for idx_str, subv in index_dict.items():
        idx = int(idx_str)
        if idx < 0 or idx > len(out):
            raise ValueError(
                f"List index {idx} out of range (list length={len(out)}). "
                f"Use 0..{len(out) - 1} to update, or {len(out)} to append."
            )
        if idx == len(out):
            out.append(copy.deepcopy(subv))
        elif isinstance(out[idx], dict) and isinstance(subv, dict):
            out[idx] = deep_merge(out[idx], subv)
        else:
            out[idx] = copy.deepcopy(subv)
    return out


def deep_merge(base: JsonDict, override: JsonDict) -> JsonDict:
    """
    dict 병합:
    - 둘 다 dict면 재귀 병합
    - base가 list이고 override가 numeric-key dict이면 인덱스 기반 업데이트
      (CLI의 --set training.phases.1.step=10 같은 용법 지원)
    - 그 외: override가 base를 덮어씀
    """
    out = copy.deepcopy(base)
    for k, v in override.items():
        if k in out and isinstance(out[k], list) and _is_numeric_key_dict(v):
            # CLI --set list.N.field=value 경로: 인덱스 기반 sparse update
            out[k] = _merge_list_with_index_dict(out[k], v)
        elif k in out and isinstance(out[k], dict) and isinstance(v, dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


# ---------------------------------------------------------------------
# CLI override parsing
# ---------------------------------------------------------------------
def parse_kv_overrides(pairs: Sequence[str]) -> JsonDict:
    """
    ["a.b=1", "training.lr=2e-5", "flag=true"] 같은 입력을 dict로 변환.

    값 파싱 규칙(간단 버전)
    - "true/false" -> bool
    - "null/none" -> None
    - int/float 파싱 시도
    - 그 외 문자열 그대로
    """
    out: JsonDict = {}
    for s in pairs:
        if "=" not in s:
            raise ValueError(f"Invalid override (expected key=value): {s}")
        k, raw = s.split("=", 1)
        k = k.strip()
        raw = raw.strip()

        if not k:
            raise ValueError(f"Empty override key: {s}")

        v: Any
        low = raw.lower()
        if low in ("true", "false"):
            v = (low == "true")
        elif low in ("none", "null"):
            v = None
        elif raw.startswith("[") and raw.endswith("]") and len(raw) > 2:
            # 리스트 파싱: [a,b,c] → ["a", "b", "c"]
            inner = raw[1:-1]
            v = [item.strip() for item in inner.split(",") if item.strip()]
        else:
            # number parse
            try:
                if "." in raw or "e" in low:
                    v = float(raw)
                else:
                    v = int(raw)
            except Exception:
                v = raw

        set_by_path(out, k, v)
    return out


# ---------------------------------------------------------------------
# ResolvedConfig
# ---------------------------------------------------------------------
@dataclass(frozen=True)
class ResolvedConfig:
    preset_path: Optional[str]
    config: JsonDict

    def to_flat(self) -> Dict[str, Any]:
        return flatten_dict(self.config)

    def save_resolved(self, output_dir: str, filename: str = "resolved_config.json") -> str:
        path = os.path.join(output_dir, filename)
        save_json(path, self.config)
        return path


def resolve_config(
    preset_path: Optional[str] = None,
    preset_dict: Optional[JsonDict] = None,
    overrides: Optional[JsonDict] = None,
) -> ResolvedConfig:
    """
    preset + overrides를 병합해 최종 config를 만든다.

    - preset은 preset_path 또는 preset_dict 중 하나로 제공 가능
    - overrides는 nested dict 형태(이미 parse_kv_overrides 적용된 dict를 넣어도 됨)

    우선순위:
      preset < overrides
    """
    if preset_path is None and preset_dict is None:
        base = {}
    elif preset_dict is not None:
        if not isinstance(preset_dict, dict):
            raise ValueError("preset_dict must be a dict")
        base = copy.deepcopy(preset_dict)
    else:
        base = load_yaml(preset_path)  # type: ignore[arg-type]

    ov = overrides or {}
    if not isinstance(ov, dict):
        raise ValueError("overrides must be a dict")

    merged = deep_merge(base, ov)

    # 아주 얕은 sanity check: 최소 키들(선택적)
    # - backbone/model_name은 대부분 필요하지만, subcommand에 따라 없을 수도 있어 강제하지 않음.
    if "training" in merged and merged["training"] is not None and not isinstance(merged["training"], dict):
        raise ValueError("'training' must be a dict if present")
    if "injection" in merged and merged["injection"] is not None and not isinstance(merged["injection"], dict):
        raise ValueError("'injection' must be a dict if present")

    return ResolvedConfig(preset_path=preset_path, config=merged)
