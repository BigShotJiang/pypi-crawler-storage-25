# eulerforge/utils/bench_client.py
# -*- coding: utf-8 -*-
"""
Ollama/OpenAI 호환 Chat Completion 클라이언트 + 로컬 HF 모델 클라이언트.

클래스:
- ChatClient: Ollama/OpenAI/Gemini API 채팅 응답 생성
- JudgeClient: pointwise/pairwise 평가 (프롬프트 구성 + 점수 파싱)
- LocalHFClient: HuggingFace 로컬 모델 추론 (AutoModelForCausalLM)
"""
from __future__ import annotations

import json
import logging
import os
import re
import urllib.error
import urllib.request
from collections import defaultdict
from typing import Any, Dict, List, Optional

from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer

logger = logging.getLogger(__name__)

# -------------------------------------------------------------------------
# 상수
# -------------------------------------------------------------------------
_VALID_PROVIDERS = ("ollama", "openai", "gemini", "local_hf")
_DEFAULT_OLLAMA_URL = "http://localhost:11434/v1"


# -------------------------------------------------------------------------
# Judge 프롬프트 템플릿
# -------------------------------------------------------------------------
_POINTWISE_SYSTEM = (
    "You are an impartial evaluator. "
    "Score the following response on a scale of 1-10 based on helpfulness, "
    "accuracy, and clarity. "
    "Respond in JSON format: {\"score\": <int>, \"explanation\": \"<text>\"}"
)

_POINTWISE_USER = (
    "Prompt:\n{prompt}\n\n"
    "Response:\n{response}\n\n"
    "Evaluate the response above."
)

_PAIRWISE_SYSTEM = (
    "You are an impartial evaluator comparing two responses. "
    "Determine which response is better based on helpfulness, accuracy, and clarity. "
    "Respond in JSON format: "
    "{\"winner\": \"A\" or \"B\" or \"tie\", \"score_a\": <int 1-10>, "
    "\"score_b\": <int 1-10>, \"explanation\": \"<text>\"}"
)

_PAIRWISE_USER = (
    "Prompt:\n{prompt}\n\n"
    "Response A:\n{response_a}\n\n"
    "Response B:\n{response_b}\n\n"
    "Which response is better?"
)


# -------------------------------------------------------------------------
# ChatClient
# -------------------------------------------------------------------------
class ChatClient:
    """Ollama/OpenAI 호환 /v1/chat/completions 클라이언트."""

    def __init__(
        self,
        provider: str,
        model: str,
        base_url: str = _DEFAULT_OLLAMA_URL,
        api_key: str = "",
    ) -> None:
        if provider not in _VALID_PROVIDERS:
            raise ValueError(f"Unknown provider: {provider}. Valid: {_VALID_PROVIDERS}")
        self.provider = provider
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

    def chat(
        self,
        messages: List[Dict[str, str]],
        generation_cfg: Optional[Dict[str, Any]] = None,
    ) -> str:
        """메시지 리스트 → 응답 텍스트."""
        gen = generation_cfg or {}

        if self.provider == "ollama":
            return self._chat_ollama_native(messages, gen)

        return self._chat_openai_compat(messages, gen)

    def _chat_ollama_native(
        self,
        messages: List[Dict[str, str]],
        gen: Dict[str, Any],
    ) -> str:
        """Ollama native /api/chat 호출.

        thinking 모델(Qwen 3.5 등)은 /v1/chat/completions에서 content가 비어
        반환되는 문제가 있어, native API + think=false로 호출한다.
        """
        base = self.base_url.rstrip("/")
        # /v1 접미사가 있으면 제거 (native API는 /api/chat)
        if base.endswith("/v1"):
            base = base[:-3]
        url = f"{base}/api/chat"

        options: Dict[str, Any] = {}
        if "max_new_tokens" in gen:
            options["num_predict"] = gen["max_new_tokens"]
        if "temperature" in gen:
            options["temperature"] = gen["temperature"]
        if "top_p" in gen:
            options["top_p"] = gen["top_p"]
        if "stop" in gen and gen["stop"]:
            options["stop"] = gen["stop"]

        payload: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "think": False,  # thinking 모델의 thinking 비활성화
        }
        if options:
            payload["options"] = options

        headers = {"Content-Type": "application/json"}
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=body, headers=headers, method="POST")

        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.URLError as e:
            raise ConnectionError(
                f"Failed to connect to {url}: {e}"
            ) from e

        # Native API 응답: {"message": {"role": "assistant", "content": "..."}}
        msg = data.get("message", {})
        content = msg.get("content", "").strip()
        return content

    def _chat_openai_compat(
        self,
        messages: List[Dict[str, str]],
        gen: Dict[str, Any],
    ) -> str:
        """OpenAI-compatible /chat/completions 호출 (non-Ollama providers)."""
        payload: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "stream": False,
        }
        if "max_new_tokens" in gen:
            payload["max_tokens"] = gen["max_new_tokens"]
        if "temperature" in gen:
            payload["temperature"] = gen["temperature"]
        if "top_p" in gen:
            payload["top_p"] = gen["top_p"]
        if "stop" in gen and gen["stop"]:
            payload["stop"] = gen["stop"]

        url = f"{self.base_url.rstrip('/')}/chat/completions"
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=body, headers=headers, method="POST")

        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.URLError as e:
            raise ConnectionError(
                f"Failed to connect to {url}: {e}"
            ) from e

        choices = data.get("choices", [])
        if not choices:
            raise ValueError(f"Empty choices in response from {url}")
        return choices[0].get("message", {}).get("content", "").strip()

    def unload(self) -> None:
        """API 클라이언트는 GPU 리소스 없음 — no-op."""
        pass

    @classmethod
    def from_config(cls, model_cfg: Dict[str, Any]) -> "ChatClient":
        """bench YAML의 models.target/baseline 섹션에서 생성."""
        provider = model_cfg.get("provider", "ollama")
        model = model_cfg.get("model", "")
        base_url = model_cfg.get("base_url", _DEFAULT_OLLAMA_URL)
        api_key_env = model_cfg.get("api_key_env", "")
        api_key = os.environ.get(api_key_env, "") if api_key_env else ""
        return cls(provider=provider, model=model, base_url=base_url, api_key=api_key)


# -------------------------------------------------------------------------
# JudgeClient
# -------------------------------------------------------------------------
class JudgeClient(ChatClient):
    """Judge 모델용 확장. pointwise/pairwise 평가."""

    def __init__(
        self,
        provider: str,
        model: str,
        base_url: str = _DEFAULT_OLLAMA_URL,
        api_key: str = "",
        mode: str = "pointwise",
        mitigate_position_bias: bool = True,
    ) -> None:
        super().__init__(provider, model, base_url, api_key)
        if mode not in ("pointwise", "pairwise"):
            raise ValueError(f"Invalid judge mode: {mode}. Valid: pointwise, pairwise")
        self.mode = mode
        self.mitigate_position_bias = mitigate_position_bias

    def score_pointwise(
        self,
        prompt: str,
        response: str,
        generation_cfg: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """pointwise: 점수(1-10) + 해설 반환."""
        messages = [
            {"role": "system", "content": _POINTWISE_SYSTEM},
            {"role": "user", "content": _POINTWISE_USER.format(
                prompt=prompt, response=response
            )},
        ]
        raw = self.chat(messages, generation_cfg)
        return _parse_pointwise(raw)

    def score_pairwise(
        self,
        prompt: str,
        response_a: str,
        response_b: str,
        generation_cfg: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """pairwise: 승자(A/B/tie) + 점수 + 해설 반환."""
        # 1차: A=target, B=baseline
        messages_1 = [
            {"role": "system", "content": _PAIRWISE_SYSTEM},
            {"role": "user", "content": _PAIRWISE_USER.format(
                prompt=prompt, response_a=response_a, response_b=response_b
            )},
        ]
        raw_1 = self.chat(messages_1, generation_cfg)
        result_1 = _parse_pairwise(raw_1)

        if not self.mitigate_position_bias:
            return result_1

        # 2차: A=baseline, B=target (스왑)
        messages_2 = [
            {"role": "system", "content": _PAIRWISE_SYSTEM},
            {"role": "user", "content": _PAIRWISE_USER.format(
                prompt=prompt, response_a=response_b, response_b=response_a
            )},
        ]
        raw_2 = self.chat(messages_2, generation_cfg)
        result_2 = _parse_pairwise(raw_2)

        # 스왑된 결과를 원래 방향으로 복원
        winner_2 = result_2.get("winner", "tie")
        if winner_2 == "A":
            winner_2 = "B"
        elif winner_2 == "B":
            winner_2 = "A"

        # 합산: 두 라운드의 점수 평균
        score_a = (result_1.get("score_a", 5) + result_2.get("score_b", 5)) / 2
        score_b = (result_1.get("score_b", 5) + result_2.get("score_a", 5)) / 2

        # 최종 승자: 두 라운드 모두 같으면 확정, 다르면 tie
        if result_1.get("winner") == winner_2:
            final_winner = result_1["winner"]
        else:
            final_winner = "tie"

        return {
            "winner": final_winner,
            "score_a": round(score_a, 1),
            "score_b": round(score_b, 1),
            "explanation": f"Round 1: {result_1.get('explanation', '')} | "
                           f"Round 2 (swapped): {result_2.get('explanation', '')}",
            "rounds": [result_1, result_2],
        }

    @classmethod
    def from_config(cls, judge_cfg: Dict[str, Any]) -> "JudgeClient":
        """bench YAML의 models.judge 섹션에서 생성."""
        provider = judge_cfg.get("provider", "ollama")
        model = judge_cfg.get("model", "")
        base_url = judge_cfg.get("base_url", _DEFAULT_OLLAMA_URL)
        api_key_env = judge_cfg.get("api_key_env", "")
        api_key = os.environ.get(api_key_env, "") if api_key_env else ""
        mode = judge_cfg.get("mode", "pointwise")
        mitigate = judge_cfg.get("mitigate_position_bias", True)
        return cls(
            provider=provider, model=model, base_url=base_url,
            api_key=api_key, mode=mode, mitigate_position_bias=mitigate,
        )


# -------------------------------------------------------------------------
# LoRA 체크포인트 병합 헬퍼
# -------------------------------------------------------------------------

def _find_lora_config(model_dir: str) -> Optional[Dict]:
    """LoRA 설정 탐색: model_dir/lora_info.json → parent/resolved_config.json.

    Returns:
        {"lora_r": int, "lora_alpha": float} or None
    """
    # 1) 체크포인트에 직접 저장된 lora_info.json
    lora_info_path = os.path.join(model_dir, "lora_info.json")
    if os.path.isfile(lora_info_path):
        try:
            with open(lora_info_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass

    # 2) 상위 디렉토리의 resolved_config.json에서 추출
    parent = os.path.dirname(os.path.abspath(model_dir))
    resolved_cfg_path = os.path.join(parent, "resolved_config.json")
    if os.path.isfile(resolved_cfg_path):
        try:
            with open(resolved_cfg_path, "r", encoding="utf-8") as f:
                resolved = json.load(f)
            injection = resolved.get("injection", {})
            lora_r = injection.get("lora_r", 0)
            lora_alpha = injection.get("lora_alpha", 1.0)
            strategy = str(injection.get("strategy", ""))
            if lora_r and "lora" in strategy.lower():
                return {
                    "lora_r": int(lora_r),
                    "lora_alpha": float(lora_alpha),
                    "strategy": strategy,
                }
        except (json.JSONDecodeError, OSError, KeyError):
            pass

    return None


def _load_state_dict_from_checkpoint(model_dir: str) -> Optional[Dict]:
    """체크포인트 디렉토리에서 state dict 로드.

    pytorch_model.bin → model.safetensors 순서로 시도.
    """
    import torch

    bin_path = os.path.join(model_dir, "pytorch_model.bin")
    if os.path.isfile(bin_path):
        return torch.load(bin_path, map_location="cpu", weights_only=True)

    sf_path = os.path.join(model_dir, "model.safetensors")
    if os.path.isfile(sf_path):
        try:
            from safetensors.torch import load_file
            return load_file(sf_path, device="cpu")
        except ImportError:
            logger.warning(
                "[LocalHFClient] safetensors 미설치. model.safetensors를 로드할 수 없습니다."
            )

    return None


def _dequantize_bnb_state_dict(state_dict: Dict) -> Dict:
    """bitsandbytes 양자화 텐서(int4/nf4 및 int8)를 dequantize하여 full precision으로 변환.

    int4/nf4 양자화:
    - companion 키: {key}.absmax, {key}.quant_map, {key}.quant_state.bitsandbytes__nf4
    - packed 텐서 (N, 1)를 원래 shape (out, in)으로 복원

    int8 양자화:
    - companion 키: {key}.SCB (row-wise scale), {key}.weight_format (메타)
    - int8 weight를 SCB로 row-wise dequantize: float_weight = int8_data * (SCB / 127)
    """
    import json as _json
    import torch

    # 1a. int4/nf4 양자화된 base 키 수집
    quant_bases = set()
    for k in state_dict:
        if ".quant_state.bitsandbytes__" in k:
            base = k.split(".quant_state.")[0]
            quant_bases.add(base)

    # 1b. int8 양자화된 base 키 수집 (*.SCB companion)
    int8_bases = set()
    for k in state_dict:
        if k.endswith(".SCB"):
            base = k[:-4]  # strip ".SCB"
            # Verify the weight itself is int8
            weight_key = f"{base}.weight"
            if weight_key in state_dict and state_dict[weight_key].dtype == torch.int8:
                int8_bases.add(weight_key)

    if not quant_bases and not int8_bases:
        return state_dict

    try:
        from bitsandbytes.functional import QuantState, dequantize_4bit
    except ImportError:
        logger.warning(
            "[dequantize] bitsandbytes가 설치되지 않아 양자화 텐서를 "
            "dequantize할 수 없습니다."
        )
        return state_dict

    dtype_map = {
        "bfloat16": torch.bfloat16,
        "float16": torch.float16,
        "float32": torch.float32,
    }

    skip_keys: set = set()
    dequantized: Dict = {}

    for base in quant_bases:
        # 메타데이터 키 찾기
        meta_key = None
        for suffix in ("nf4", "fp4"):
            candidate = f"{base}.quant_state.bitsandbytes__{suffix}"
            if candidate in state_dict:
                meta_key = candidate
                break
        if meta_key is None:
            continue

        # 메타데이터 파싱 (JSON 바이트)
        meta_tensor = state_dict[meta_key]
        meta_bytes = bytes(meta_tensor.to(torch.uint8).tolist())
        meta = _json.loads(meta_bytes)

        shape = tuple(meta["shape"])
        blocksize = meta.get("blocksize", 64)
        quant_type = meta.get("quant_type", "nf4")
        dtype = dtype_map.get(meta.get("dtype", "bfloat16"), torch.bfloat16)

        packed_data = state_dict[base]
        expected_packed_numel = 1
        for s in shape:
            expected_packed_numel *= s
        expected_packed_numel //= 2  # nf4: 2 values per byte

        # dtype이 uint8이 아닌 경우 처리:
        # bitsandbytes가 nf4 packed uint8 데이터를 bf16으로 cast하여 저장하는
        # 경우가 있음 (handoff 훈련 등). 이때 numel이 packed 크기와 동일하면
        # uint8로 되돌려서 정상 dequantize. numel이 원본 shape과 동일하면
        # 이미 완전히 dequantize된 텐서 → reshape만 수행.
        if packed_data.dtype != torch.uint8:
            original_numel = 1
            for s in shape:
                original_numel *= s

            if packed_data.numel() == expected_packed_numel:
                # packed uint8이 bf16으로 cast된 경우 → uint8로 복원
                logger.debug(
                    f"[dequantize] {base}: dtype={packed_data.dtype}, "
                    f"numel={packed_data.numel()} == packed 크기 "
                    f"— uint8로 복원 후 dequantize"
                )
                packed_data = packed_data.to(torch.uint8).reshape(-1, 1)
            elif packed_data.numel() == original_numel:
                # 이미 완전히 dequantize된 텐서 → reshape만
                logger.debug(
                    f"[dequantize] {base}: dtype={packed_data.dtype}, "
                    f"numel={packed_data.numel()} == 원본 크기 "
                    f"— reshape만 수행"
                )
                dequantized[base] = packed_data.reshape(shape).to(dtype)
                for k in state_dict:
                    if k.startswith(f"{base}.") and k != base:
                        skip_keys.add(k)
                continue
            else:
                logger.warning(
                    f"[dequantize] {base}: 예상치 못한 numel "
                    f"({packed_data.numel()}), 건너뜀"
                )
                for k in state_dict:
                    if k.startswith(f"{base}.") and k != base:
                        skip_keys.add(k)
                continue

        absmax = state_dict.get(f"{base}.absmax")
        quant_map = state_dict.get(f"{base}.quant_map")

        # nested (double) quantization 처리
        nested = "nested_blocksize" in meta
        if nested:
            nested_absmax = state_dict.get(f"{base}.nested_absmax")
            nested_quant_map = state_dict.get(f"{base}.nested_quant_map")
            nested_blocksize = meta.get("nested_blocksize", 256)
            nested_dtype = dtype_map.get(
                meta.get("nested_dtype", "bfloat16"), torch.bfloat16
            )
            offset = None
            offset_val = meta.get("nested_offset")
            if offset_val is not None:
                offset = torch.tensor(float(offset_val))
            state2 = QuantState(
                absmax=nested_absmax,
                shape=tuple(absmax.shape) if absmax is not None else (),
                blocksize=nested_blocksize,
                code=nested_quant_map,
                dtype=nested_dtype,
                quant_type=quant_type,
            )
            qs = QuantState(
                absmax=absmax,
                shape=shape,
                blocksize=blocksize,
                code=quant_map,
                dtype=dtype,
                quant_type=quant_type,
                state2=state2,
                offset=offset,
            )
        else:
            qs = QuantState(
                absmax=absmax,
                shape=shape,
                blocksize=blocksize,
                code=quant_map,
                dtype=dtype,
                quant_type=quant_type,
            )

        deq = dequantize_4bit(packed_data, qs)
        dequantized[base] = deq.reshape(shape).to(dtype)

        # companion 키 제거 대상
        for k in state_dict:
            if k.startswith(f"{base}.") and k != base:
                skip_keys.add(k)

    # --- int8 dequantize ---
    int8_dequantized: Dict = {}
    int8_skip_keys: set = set()

    for weight_key in int8_bases:
        int8_w = state_dict[weight_key]
        # base path: e.g. "model.layers.0.linear_attn.in_proj_qkv"
        base_path = weight_key[:-len(".weight")]
        scb_key = f"{base_path}.SCB"
        fmt_key = f"{base_path}.weight_format"

        scb = state_dict.get(scb_key)
        if scb is not None:
            # Row-wise dequantize: float_weight = int8_data * (SCB / 127)
            deq_w = int8_w.float() * (scb.float().unsqueeze(1) / 127.0)
            int8_dequantized[weight_key] = deq_w.to(torch.bfloat16)
        else:
            # No SCB: naive cast fallback
            logger.warning(
                f"[dequantize] int8 weight {weight_key} has no SCB, "
                f"using naive float cast"
            )
            int8_dequantized[weight_key] = int8_w.float().to(torch.bfloat16)

        # Mark companion keys for removal
        if scb_key in state_dict:
            int8_skip_keys.add(scb_key)
        if fmt_key in state_dict:
            int8_skip_keys.add(fmt_key)

    # 결과 dict 조립
    all_skip = skip_keys | int8_skip_keys
    result = {}
    for k, v in state_dict.items():
        if k in quant_bases:
            result[k] = dequantized[k]
        elif k in int8_bases:
            result[k] = int8_dequantized[k]
        elif k not in all_skip:
            result[k] = v

    total_deq = len(quant_bases) + len(int8_bases)
    if total_deq > 0:
        parts = []
        if quant_bases:
            parts.append(f"{len(quant_bases)} int4/nf4")
        if int8_bases:
            parts.append(f"{len(int8_bases)} int8")
        from eulerforge.i18n import t as _t
        logger.info(
            _t("dequantize.completed", count=' + '.join(parts))
        )
    return result


def _merge_lora_state_dict(state_dict: Dict, lora_r: int, lora_alpha: float) -> Dict:
    """LoRA state dict를 일반 Linear 가중치로 병합.

    변환:
        prefix.base_layer.weight + (prefix.lora_B @ prefix.lora_A) * scaling
        → prefix.weight
    """
    scaling = lora_alpha / lora_r
    base_weights: Dict[str, Any] = {}
    lora_a: Dict[str, Any] = {}
    lora_b: Dict[str, Any] = {}
    normal: Dict[str, Any] = {}

    for k, v in state_dict.items():
        if k.endswith(".base_layer.weight"):
            prefix = k[: -len(".base_layer.weight")]
            base_weights[prefix] = v
        elif k.endswith(".base_layer.bias"):
            prefix = k[: -len(".base_layer.bias")]
            normal[f"{prefix}.bias"] = v
        elif k.endswith(".lora_A"):
            prefix = k[: -len(".lora_A")]
            lora_a[prefix] = v
        elif k.endswith(".lora_B"):
            prefix = k[: -len(".lora_B")]
            lora_b[prefix] = v
        else:
            normal[k] = v

    merged = dict(normal)
    for prefix, base_w in base_weights.items():
        a = lora_a.get(prefix)
        b = lora_b.get(prefix)
        if a is not None and b is not None:
            orig_dtype = base_w.dtype
            delta = (b.float() @ a.float()) * scaling
            merged[f"{prefix}.weight"] = (base_w.float() + delta).to(orig_dtype)
        else:
            merged[f"{prefix}.weight"] = base_w

    return merged


def _detect_moe_type(state_dict: Dict) -> str:
    """State dict에서 MoE 체크포인트 유형을 자동 감지.

    Returns:
        "moe_expert_lora" - MoEFFN 구조 (mlp.experts.N.proj.* — LoRA 래핑 또는 handoff 후 plain)
        "mixture_lora" - MixtureLoRALinear 구조 (proj.experts.N.loraA)
        "" - MoE 아님 (dense LoRA)
    """
    for k in state_dict:
        # moe_expert_lora: model.layers.X.mlp.experts.N.gate_proj.*
        if re.search(r"\.mlp\.experts\.\d+\.\w+_proj\.", k):
            return "moe_expert_lora"
        # mixture_lora: model.layers.X.mlp.gate_proj.experts.N.lora*
        if re.search(r"\.\w+_proj\.experts\.\d+\.lora", k):
            return "mixture_lora"
    return ""


def _merge_moe_expert_lora_state_dict(
    state_dict: Dict, lora_r: int, lora_alpha: float
) -> Dict:
    """FFN MoE Expert LoRA state dict → 표준 모델 state dict로 병합.

    과정:
    1. 각 expert 내에서 LoRA 병합: expert_base + (lora_B @ lora_A) * scaling
    2. 모든 expert를 평균하여 단일 FFN 가중치로 축소
    3. MoE router 키 제거
    4. 어텐션 LoRA는 기존 _merge_lora_state_dict와 동일하게 처리

    Handoff 호환:
    - LoRA Handoff + remove_adapters_if_zero_scale 후 expert 키는
      *.experts.N.proj.weight (base_layer 없음) 형태가 된다.
    - 이 경우에도 expert 평균 → 단일 FFN으로 정상 축소한다.
    """
    import torch

    scaling = lora_alpha / lora_r

    # Expert 키 패턴: *.mlp.experts.{E}.{proj}.{param_type}
    # 1) LoRA 래핑: base_layer.weight, lora_A, lora_B
    # 2) Handoff 후: 직접 weight (LoRA 제거됨)
    expert_lora_pat = re.compile(
        r"^(.+\.mlp)\.experts\.(\d+)\.(\w+_proj)\.(base_layer\.weight|lora_A|lora_B)$"
    )
    expert_plain_pat = re.compile(
        r"^(.+\.mlp)\.experts\.(\d+)\.(\w+_proj)\.(weight|bias)$"
    )
    router_pat = re.compile(r"^.+\.mlp\.router\.(weight|bias)$")

    # expert_data[mlp_prefix][proj_name][expert_idx] = {param_type: tensor}
    expert_data: Dict[str, Dict[str, Dict[int, Dict[str, Any]]]] = defaultdict(
        lambda: defaultdict(lambda: defaultdict(dict))
    )
    # 비-MoE LoRA (attention 등)
    attn_base: Dict[str, Any] = {}
    attn_lora_a: Dict[str, Any] = {}
    attn_lora_b: Dict[str, Any] = {}
    normal: Dict[str, Any] = {}

    for k, v in state_dict.items():
        m = expert_lora_pat.match(k)
        if m:
            mlp_prefix, expert_idx, proj_name, param_type = m.groups()
            expert_data[mlp_prefix][proj_name][int(expert_idx)][param_type] = v
            continue
        m2 = expert_plain_pat.match(k)
        if m2:
            mlp_prefix, expert_idx, proj_name, param_type = m2.groups()
            expert_data[mlp_prefix][proj_name][int(expert_idx)][param_type] = v
            continue
        if router_pat.match(k):
            continue  # router 키 제거
        if k.endswith(".base_layer.weight"):
            prefix = k[: -len(".base_layer.weight")]
            attn_base[prefix] = v
        elif k.endswith(".base_layer.bias"):
            prefix = k[: -len(".base_layer.bias")]
            normal[f"{prefix}.bias"] = v
        elif k.endswith(".lora_A"):
            prefix = k[: -len(".lora_A")]
            attn_lora_a[prefix] = v
        elif k.endswith(".lora_B"):
            prefix = k[: -len(".lora_B")]
            attn_lora_b[prefix] = v
        else:
            normal[k] = v

    merged = dict(normal)

    # 어텐션 LoRA 병합 (기존 로직과 동일)
    for prefix, base_w in attn_base.items():
        a = attn_lora_a.get(prefix)
        b = attn_lora_b.get(prefix)
        if a is not None and b is not None:
            orig_dtype = base_w.dtype
            delta = (b.float() @ a.float()) * scaling
            merged[f"{prefix}.weight"] = (base_w.float() + delta).to(orig_dtype)
        else:
            merged[f"{prefix}.weight"] = base_w

    # MoE expert 병합: LoRA merge → expert 평균
    for mlp_prefix, proj_dict in expert_data.items():
        for proj_name, experts in proj_dict.items():
            merged_experts = []
            orig_dtype = None
            for _idx in sorted(experts.keys()):
                params = experts[_idx]
                # base_layer.weight (LoRA 래핑) 또는 weight (handoff 후 plain)
                base_w = params.get("base_layer.weight")
                if base_w is None:
                    base_w = params.get("weight")
                if base_w is None:
                    continue
                if orig_dtype is None:
                    orig_dtype = base_w.dtype
                a = params.get("lora_A")
                b = params.get("lora_B")
                if a is not None and b is not None:
                    delta = (b.float() @ a.float()) * scaling
                    merged_experts.append(base_w.float() + delta)
                else:
                    merged_experts.append(base_w.float())

            if merged_experts:
                avg_weight = torch.stack(merged_experts).mean(dim=0)
                if orig_dtype is None:
                    orig_dtype = torch.float32
                standard_key = f"{mlp_prefix}.{proj_name}.weight"
                merged[standard_key] = avg_weight.to(orig_dtype)

    return merged


def _merge_mixture_lora_state_dict(
    state_dict: Dict, lora_r: int, lora_alpha: float
) -> Dict:
    """Mixture-of-LoRAs (mixture_lora) state dict → 표준 모델 state dict로 병합.

    과정:
    1. 각 projection의 expert LoRA 델타를 평균
    2. base + 평균 델타 → 단일 가중치
    3. projection별 router/experts 키 제거
    4. 어텐션 LoRA는 기존 방식으로 처리
    """
    import torch

    scaling = lora_alpha / lora_r

    # mixture_lora expert 패턴: *.{proj}.experts.{E}.loraA/loraB
    mlora_expert_pat = re.compile(
        r"^(.+\.\w+_proj)\.experts\.(\d+)\.(loraA|loraB)$"
    )
    # mixture_lora router 패턴: *.{proj}.router.{weight|bias}
    mlora_router_pat = re.compile(
        r"^.+\.\w+_proj\.router\.(weight|bias)$"
    )

    # mlora_data[proj_prefix][expert_idx] = {"loraA": tensor, "loraB": tensor}
    mlora_data: Dict[str, Dict[int, Dict[str, Any]]] = defaultdict(
        lambda: defaultdict(dict)
    )
    # base weights for mixture_lora projections
    mlora_base: Dict[str, Any] = {}
    # 비-MoE LoRA (attention 등)
    attn_base: Dict[str, Any] = {}
    attn_lora_a: Dict[str, Any] = {}
    attn_lora_b: Dict[str, Any] = {}
    normal: Dict[str, Any] = {}

    for k, v in state_dict.items():
        m = mlora_expert_pat.match(k)
        if m:
            proj_prefix, expert_idx, param_type = m.groups()
            mlora_data[proj_prefix][int(expert_idx)][param_type] = v
            continue
        if mlora_router_pat.match(k):
            continue  # router 키 제거
        if k.endswith(".base_layer.weight"):
            prefix = k[: -len(".base_layer.weight")]
            # MoE projection의 base인지 확인
            if re.search(r"\.\w+_proj$", prefix) and prefix in mlora_data:
                # MixtureLoRA FFN projection base
                attn_base[prefix] = v
            else:
                # Attention LoRA 또는 기타 LoRA의 base weight
                attn_base[prefix] = v
            continue
        if k.endswith(".base_layer.bias"):
            prefix = k[: -len(".base_layer.bias")]
            normal[f"{prefix}.bias"] = v
            continue
        elif k.endswith(".lora_A"):
            prefix = k[: -len(".lora_A")]
            attn_lora_a[prefix] = v
        elif k.endswith(".lora_B"):
            prefix = k[: -len(".lora_B")]
            attn_lora_b[prefix] = v
        else:
            normal[k] = v

    merged = dict(normal)

    # mixture_lora base weight와 expert delta 병합
    for proj_prefix, experts in mlora_data.items():
        base_w = attn_base.pop(proj_prefix, None)
        if base_w is None:
            continue
        orig_dtype = base_w.dtype

        deltas = []
        for _idx in sorted(experts.keys()):
            params = experts[_idx]
            a = params.get("loraA")
            b = params.get("loraB")
            if a is not None and b is not None:
                deltas.append((b.float() @ a.float()) * scaling)

        if deltas:
            avg_delta = torch.stack(deltas).mean(dim=0)
            merged[f"{proj_prefix}.weight"] = (base_w.float() + avg_delta).to(orig_dtype)
        else:
            merged[f"{proj_prefix}.weight"] = base_w

    # 남은 base weights (어텐션 LoRA)
    for prefix, base_w in attn_base.items():
        a = attn_lora_a.get(prefix)
        b = attn_lora_b.get(prefix)
        if a is not None and b is not None:
            orig_dtype = base_w.dtype
            delta = (b.float() @ a.float()) * scaling
            merged[f"{prefix}.weight"] = (base_w.float() + delta).to(orig_dtype)
        else:
            merged[f"{prefix}.weight"] = base_w

    return merged


def _merge_attention_lora_only(
    state_dict: Dict, lora_r: int, lora_alpha: float
) -> Dict:
    """MixtureLoRA 키는 보존하고 Attention LoRA만 병합.

    mixture_lora 구조 보존 모드용: FFN의 base_layer.weight, router, experts 키는
    그대로 유지하고, Attention의 base_layer.weight + lora_A/B만 weight로 병합.
    """
    import torch

    scaling = lora_alpha / lora_r

    # 1) MixtureLoRA projection 접두사 식별 (experts.N.loraA/B 키가 있는 projection)
    mixture_prefixes: set = set()
    for k in state_dict:
        m = re.match(r"^(.+\.\w+_proj)\.experts\.\d+\.lora[AB]$", k)
        if m:
            mixture_prefixes.add(m.group(1))

    merged: Dict = {}
    attn_base: Dict[str, Any] = {}
    attn_lora_a: Dict[str, Any] = {}
    attn_lora_b: Dict[str, Any] = {}

    for k, v in state_dict.items():
        # MixtureLoRA projection의 base_layer.weight → 그대로 유지
        if k.endswith(".base_layer.weight"):
            prefix = k[: -len(".base_layer.weight")]
            if prefix in mixture_prefixes:
                merged[k] = v
                continue
            # Attention LoRA base → 수집 (나중에 merge)
            attn_base[prefix] = v
            continue

        if k.endswith(".base_layer.bias"):
            prefix = k[: -len(".base_layer.bias")]
            if prefix in mixture_prefixes:
                merged[k] = v
            else:
                merged[f"{prefix}.bias"] = v
            continue

        # MixtureLoRA router/expert keys → 그대로 유지
        if re.match(r"^.+\.\w+_proj\.router\.(weight|bias)$", k):
            merged[k] = v
            continue
        if re.match(r"^.+\.\w+_proj\.experts\.\d+\.lora[AB]$", k):
            merged[k] = v
            continue

        # Attention LoRA A/B → 수집
        if k.endswith(".lora_A"):
            attn_lora_a[k[: -len(".lora_A")]] = v
            continue
        if k.endswith(".lora_B"):
            attn_lora_b[k[: -len(".lora_B")]] = v
            continue

        # Normal keys
        merged[k] = v

    # Attention LoRA merge
    for prefix, base_w in attn_base.items():
        a = attn_lora_a.get(prefix)
        b = attn_lora_b.get(prefix)
        if a is not None and b is not None:
            orig_dtype = base_w.dtype
            delta = (b.float() @ a.float()) * scaling
            merged[f"{prefix}.weight"] = (base_w.float() + delta).to(orig_dtype)
        else:
            merged[f"{prefix}.weight"] = base_w

    return merged


def _find_resolved_config(model_dir: str) -> Optional[Dict]:
    """체크포인트 parent 디렉토리에서 resolved_config.json 로드.

    Returns:
        전체 resolved config dict, 또는 None.
    """
    parent = os.path.dirname(os.path.abspath(model_dir))
    path = os.path.join(parent, "resolved_config.json")
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return None


def _get_backbone_adapter(backbone: str):
    """backbone 이름으로 적절한 BackboneAdapter 인스턴스를 반환."""
    backbone = (backbone or "").lower()
    # qwen 계열: qwen2, qwen3 등 모두 동일한 Qwen3Adapter 사용
    # (Qwen2/2.5/3/3.5는 모두 Llama-like 아키텍처로 어댑터가 호환됨)
    if "qwen" in backbone:
        from eulerforge.adapters.backbones.qwen3 import Qwen3Adapter
        return Qwen3Adapter()
    elif "llama" in backbone:
        from eulerforge.adapters.backbones.llama import LlamaAdapter
        return LlamaAdapter()
    elif "gemma4" in backbone or "gemma-4" in backbone or "gemma_4" in backbone:
        from eulerforge.adapters.backbones.gemma4 import Gemma4Adapter
        return Gemma4Adapter()
    elif "gemma3" in backbone or "gemma-3" in backbone or "gemma_3" in backbone:
        from eulerforge.adapters.backbones.gemma3 import Gemma3Adapter
        return Gemma3Adapter()
    elif "mixtral" in backbone:
        import importlib
        mod = importlib.import_module("eulerforge.adapters.backbones.mixtral")
        for obj in mod.__dict__.values():
            if isinstance(obj, type):
                from eulerforge.adapters.backbones.base import BackboneAdapter
                if issubclass(obj, BackboneAdapter) and obj is not BackboneAdapter:
                    return obj()
        raise ValueError(
            f"Bench: could not find Mixtral adapter.\n"
            f"Fix: check eulerforge.adapters.backbones.mixtral module.\n"
            f"See: docs/fixtures/specs/bench_local_model_spec.md"
        )
    else:
        raise ValueError(
            f"Bench: unsupported backbone '{backbone}' for MoE reconstruction.\n"
            f"Fix: ensure resolved_config.json contains a valid backbone field.\n"
            f"See: docs/fixtures/specs/bench_local_model_spec.md"
        )


def _reconstruct_moe_model(
    model_dir: str,
    resolved_cfg: Dict,
    state_dict: Dict,
    lora_cfg: Optional[Dict],
    torch_dtype,
    device: str,
):
    """MoE 구조를 보존하여 체크포인트를 로드.

    moe_expert_lora 체크포인트는 expert 구조(4개 FFN + router)를 그대로 유지한 채
    bench 추론에 사용해야 한다. Expert를 평균하여 dense FFN으로 축소하지 않는다.

    과정:
    1. HF config으로 기본 모델 생성 (표준 아키텍처)
    2. MoE injection 적용 (expert + router 구조 생성)
    3. LoRA 있으면 state_dict에서 병합 (expert 구조 보존)
    4. state_dict를 MoE 모델에 로드
    """
    import torch
    # lazy import → 모듈 attribute로 저장하여 테스트에서 mock 가능하게 함
    import eulerforge.utils.bench_client as _self_mod
    if not hasattr(_self_mod, "replace_ffn_with_moe_inplace"):
        from eulerforge.modules.moe import replace_ffn_with_moe_inplace as _fn
        _self_mod.replace_ffn_with_moe_inplace = _fn

    injection = resolved_cfg.get("injection", {})
    backbone = resolved_cfg.get("backbone", "")

    # 1. 기본 모델 생성
    config = AutoConfig.from_pretrained(model_dir)
    model = AutoModelForCausalLM.from_config(config)
    if torch_dtype != "auto":
        torch_dtype = _safe_torch_dtype(torch_dtype)
        model = model.to(torch_dtype)

    # 2. MoE injection 적용
    adapter = _get_backbone_adapter(backbone)

    num_experts = int(injection.get("num_experts", 4))
    top_k = int(injection.get("top_k", 2))
    start_layer = int(injection.get("start_layer", 0) or 0)
    num_layers_cfg = injection.get("num_layers", 0)
    num_layers = int(num_layers_cfg) if num_layers_cfg else 0

    total_layers = len(list(adapter.find_transformer_layers(model)))
    if num_layers <= 0:
        num_layers = max(1, total_layers - start_layer)

    layer_indices = list(range(
        start_layer, min(start_layer + num_layers, total_layers)
    ))
    hidden_size = getattr(config, "hidden_size", None)
    if hidden_size is None:
        text_cfg = getattr(config, "text_config", None)
        hidden_size = getattr(text_cfg, "hidden_size", 4096)

    _self_mod.replace_ffn_with_moe_inplace(
        model=model,
        adapter=adapter,
        layer_indices=layer_indices,
        hidden_size=hidden_size,
        num_experts=num_experts,
        top_k=top_k,
        aux_loss_coeff=0.0,
        verbose=False,
        track_routing=False,
    )

    logger.info(
        f"[LocalHFClient] MoE 구조 재구성 완료: {len(layer_indices)} layers, "
        f"{num_experts} experts, top_k={top_k}"
    )

    # 2.5. 양자화된 텐서 dequantize (int4/nf4 → float)
    # 체크포인트에 bitsandbytes nf4 packed 텐서가 있으면 full precision으로 복원
    state_dict = _dequantize_bnb_state_dict(state_dict)

    # 3. LoRA 병합 (expert 구조 보존)
    # _merge_lora_state_dict는 base_layer.weight + lora_A/B → weight 변환만 수행.
    # expert/router 키는 normal dict로 그대로 통과하므로 MoE 구조가 보존된다.
    has_lora = any("lora_A" in k or "lora_B" in k for k in state_dict)
    if has_lora and lora_cfg:
        r = lora_cfg["lora_r"]
        alpha = lora_cfg["lora_alpha"]
        logger.info(
            f"[LocalHFClient] MoE 구조 유지 + LoRA 병합 중 (r={r}, alpha={alpha})..."
        )
        state_dict = _merge_lora_state_dict(state_dict, r, alpha)
    else:
        logger.info(
            "[LocalHFClient] MoE 구조 그대로 로드 (Handoff 완료 체크포인트)..."
        )

    # 4. 키 정규화 및 로드
    state_dict = _normalize_merged_keys(state_dict, set(model.state_dict().keys()))
    missing, unexpected = model.load_state_dict(state_dict, strict=False)

    model.tie_weights()
    tied_keys = set(getattr(model, "_tied_weights_keys", {}).keys())
    true_missing = [k for k in missing if k not in tied_keys]
    if true_missing:
        logger.warning(
            f"[LocalHFClient] MoE 재구성 후 누락된 키 {len(true_missing)}개: "
            f"{true_missing[:5]}"
        )
    elif missing:
        logger.debug(
            f"[LocalHFClient] 누락된 키 {len(missing)}개는 weight tying으로 "
            f"자동 복원됨 (정상): {list(missing)}"
        )
    if unexpected:
        logger.warning(
            f"[LocalHFClient] MoE 재구성 후 예기치 않은 키: {len(unexpected)}"
        )

    target_device = (
        "cuda" if device == "auto" and torch.cuda.is_available()
        else ("cpu" if device == "auto" else device)
    )
    model = model.to(target_device)
    model.eval()
    return model


def _reconstruct_mixture_lora_model(
    model_dir: str,
    resolved_cfg: Dict,
    state_dict: Dict,
    lora_cfg: Optional[Dict],
    torch_dtype,
    device: str,
):
    """MixtureLoRA(mixture_lora) 구조를 보존하여 체크포인트를 로드.

    mixture_lora 체크포인트는 FFN Linear가 MixtureLoRALinear 구조
    (base + router + N LoRA experts)를 가진다.
    Expert를 평균하여 dense로 축소하지 않고, MixtureLoRALinear를 재구성하여
    routing 다양성을 보존한다.

    과정:
    1. HF config으로 기본 모델 생성 (표준 아키텍처)
    2. build_mixture_lora_for_ffn_layers()로 FFN에 MixtureLoRA injection
    3. Attention LoRA만 병합 (FFN MixtureLoRA 키는 보존)
    4. state_dict를 MixtureLoRA 모델에 로드
    """
    import torch

    # lazy import → 모듈 attribute로 저장하여 테스트에서 mock 가능하게 함
    import eulerforge.utils.bench_client as _self_mod
    if not hasattr(_self_mod, "build_mixture_lora_for_ffn_layers"):
        from eulerforge.modules.mixture_lora import (
            build_mixture_lora_for_ffn_layers as _fn,
        )
        _self_mod.build_mixture_lora_for_ffn_layers = _fn

    injection = resolved_cfg.get("injection", {})
    backbone = resolved_cfg.get("backbone", "")

    # 1. 기본 모델 생성
    config = AutoConfig.from_pretrained(model_dir)
    model = AutoModelForCausalLM.from_config(config)
    if torch_dtype != "auto":
        torch_dtype = _safe_torch_dtype(torch_dtype)
        model = model.to(torch_dtype)

    # 2. MixtureLoRA injection 적용
    adapter = _get_backbone_adapter(backbone)

    num_experts = int(injection.get("num_experts", 4))
    top_k = int(injection.get("top_k", 2))
    r = int(injection.get("lora_r", lora_cfg.get("lora_r", 16) if lora_cfg else 16))
    alpha = float(
        injection.get("lora_alpha", lora_cfg.get("lora_alpha", 32.0) if lora_cfg else 32.0)
    )
    dropout = float(injection.get("lora_dropout", 0.0))
    target_keywords = injection.get(
        "target_keywords", ["gate_proj", "up_proj", "down_proj"]
    )
    start_layer = int(injection.get("start_layer", 0) or 0)
    num_layers_cfg = injection.get("num_layers", 0)
    num_layers = int(num_layers_cfg) if num_layers_cfg else 0

    total_layers = len(list(adapter.find_transformer_layers(model)))
    if num_layers <= 0:
        num_layers = max(1, total_layers - start_layer)

    layer_indices = list(range(
        start_layer, min(start_layer + num_layers, total_layers)
    ))

    _self_mod.build_mixture_lora_for_ffn_layers(
        model=model,
        adapter=adapter,
        layer_indices=layer_indices,
        num_experts=num_experts,
        top_k=top_k,
        r=r,
        alpha=alpha,
        dropout=dropout,
        target_submodule_keywords=target_keywords,
        router_temperature=1.0,
        aux_loss_coeff=0.0,
        track_stats=False,
    )

    logger.info(
        f"[LocalHFClient] MixtureLoRA 구조 재구성 완료: {len(layer_indices)} layers, "
        f"{num_experts} experts, top_k={top_k}, r={r}"
    )

    # 2.5. 양자화된 텐서 dequantize
    state_dict = _dequantize_bnb_state_dict(state_dict)

    # 3. Attention LoRA만 병합 (FFN MixtureLoRA 키는 보존)
    has_attn_lora = any("lora_A" in k or "lora_B" in k for k in state_dict)
    if has_attn_lora and lora_cfg:
        lr = lora_cfg["lora_r"]
        la = lora_cfg["lora_alpha"]
        logger.info(
            f"[LocalHFClient] Attention LoRA 병합 중 (r={lr}, alpha={la}), "
            f"FFN MixtureLoRA 키는 보존..."
        )
        state_dict = _merge_attention_lora_only(state_dict, lr, la)
    else:
        logger.info(
            "[LocalHFClient] Attention LoRA 없음. MixtureLoRA 체크포인트 직접 로드..."
        )

    # 4. 키 정규화 및 로드
    state_dict = _normalize_merged_keys(state_dict, set(model.state_dict().keys()))
    missing, unexpected = model.load_state_dict(state_dict, strict=False)

    model.tie_weights()
    tied_keys = set(getattr(model, "_tied_weights_keys", {}).keys())
    true_missing = [k for k in missing if k not in tied_keys]
    if true_missing:
        logger.warning(
            f"[LocalHFClient] MixtureLoRA 재구성 후 누락된 키 {len(true_missing)}개: "
            f"{true_missing[:5]}"
        )
    elif missing:
        logger.debug(
            f"[LocalHFClient] 누락된 키 {len(missing)}개는 weight tying으로 "
            f"자동 복원됨 (정상): {list(missing)}"
        )
    if unexpected:
        logger.warning(
            f"[LocalHFClient] MixtureLoRA 재구성 후 예기치 않은 키: {len(unexpected)}"
        )

    target_device = (
        "cuda" if device == "auto" and torch.cuda.is_available()
        else ("cpu" if device == "auto" else device)
    )
    model = model.to(target_device)
    model.eval()
    return model


def _normalize_merged_keys(
    merged_sd: Dict, expected_keys: set
) -> Dict:
    """병합된 state dict의 키 접두사를 모델 기대 키에 맞게 정규화.

    Qwen3.5 등 일부 모델은 체크포인트에 'model.language_model.X' 형태로 저장되지만,
    AutoModelForCausalLM.from_config()는 'model.X' 형태의 키를 기대한다.
    이 함수는 알려진 접두사 매핑을 누적 적용하여 키를 정규화한다.

    누적 적용: 각 매핑은 아직 매칭되지 않은 키에만 적용된다.
    예) Gemma 3 4B+: language_model.model.X → model.language_model.X (1차),
        vision_tower.X → model.vision_tower.X (2차, "" → "model." 매핑).
    """
    merged_keys = set(merged_sd.keys())

    # 이미 겹치면 정규화 불필요
    if merged_keys & expected_keys:
        return merged_sd

    # 알려진 접두사 매핑 (가장 구체적인 것부터)
    _KNOWN_REMAPPINGS = [
        ("model.language_model.", "model."),              # Qwen3.5 계열
        ("base_model.model.", "model."),                   # PEFT wrapper
        ("language_model.model.", "model.language_model."),  # Gemma 3 4B+ text backbone
        ("", "model."),                                    # 일반 model. 접두사 추가
    ]

    # 누적 적용: 매칭 개선되면 적용하고 다음 매핑으로 진행
    current = dict(merged_sd)
    applied_any = False
    applied_msgs: list = []

    for old_prefix, new_prefix in _KNOWN_REMAPPINGS:
        new_current = {}
        changed = False
        for k, v in current.items():
            if k not in expected_keys and k.startswith(old_prefix):
                new_key = new_prefix + k[len(old_prefix):]
                new_current[new_key] = v
                changed = True
            else:
                new_current[k] = v
        if not changed:
            continue
        new_overlap = len(set(new_current.keys()) & expected_keys)
        old_overlap = len(set(current.keys()) & expected_keys)
        if new_overlap > old_overlap:
            current = new_current
            applied_any = True
            applied_msgs.append(
                f"'{old_prefix}' → '{new_prefix}' "
                f"({new_overlap}/{len(expected_keys)} 키 매칭)"
            )

    if applied_any:
        for msg in applied_msgs:
            from eulerforge.i18n import t
            logger.info(t("bench.key_prefix_normalized", msg=msg))
        return current

    return merged_sd


def _resize_embeddings_if_needed(model, tokenizer) -> None:
    """토크나이저 vocab이 모델 임베딩보다 크면 resize.

    from_config()로 생성한 모델은 config.vocab_size 크기의 임베딩을 갖는데,
    토크나이저에 추가 특수 토큰(예: <|im_start|>, <think>)이 있으면
    token ID가 임베딩 범위를 초과하여 CUDA device-side assert가 발생한다.
    """
    try:
        vocab_size = len(tokenizer)
        embed_size = getattr(model.config, "vocab_size", None)
        if embed_size is None:
            text_cfg = getattr(model.config, "text_config", None)
            embed_size = getattr(text_cfg, "vocab_size", None)
        if embed_size is None:
            return
        embed_size = int(embed_size)
    except (TypeError, ValueError):
        return
    if vocab_size > embed_size:
        logger.info(
            f"[LocalHFClient] 토크나이저 vocab({vocab_size}) > 모델 임베딩({embed_size}). "
            f"임베딩 resize 중..."
        )
        model.resize_token_embeddings(vocab_size)


def _safe_torch_dtype(torch_dtype):
    """float16 → bfloat16 자동 변환 (수치 안정성).

    from_config() 경로에서 float16을 사용하면 autoregressive 생성 시
    linear attention(Mamba 등)의 누적 상태가 float16 범위(max ~65504)를
    초과하여 NaN/Inf → 'CUDA error: device-side assert triggered' 발생.
    bfloat16은 동일 16-bit 메모리이지만 범위가 ~3.4e38으로 안전.
    """
    import torch

    if torch_dtype == torch.float16:
        from eulerforge.i18n import t
        logger.warning(t("bench_client.float16_warning"))
        return torch.bfloat16
    return torch_dtype


# -------------------------------------------------------------------------
# LocalHFClient
# -------------------------------------------------------------------------
class LocalHFClient:
    """HuggingFace 로컬 체크포인트 추론 클라이언트.

    AutoModelForCausalLM.from_pretrained() 로 모델을 로드하고
    chat() 인터페이스를 ChatClient와 동일하게 제공한다.
    """

    def __init__(
        self,
        model_dir: str,
        device: str = "auto",
        dtype: str = "auto",
        trust_remote_code: bool = False,
    ) -> None:
        from eulerforge.loader import _load_checkpoint

        self.model_dir = model_dir

        # LoRA / resolved config 탐지
        lora_cfg = _find_lora_config(model_dir)
        resolved_cfg = _find_resolved_config(model_dir)

        self.model, self.tokenizer = _load_checkpoint(
            model_dir,
            device=device,
            dtype=dtype,
            lora_cfg=lora_cfg,
            resolved_cfg=resolved_cfg,
            trust_remote_code=trust_remote_code,
        )

    def unload(self) -> None:
        """모델과 토크나이저를 메모리에서 해제."""
        import torch

        del self.model
        del self.tokenizer
        self.model = None
        self.tokenizer = None
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        logger.info("[Bench] LocalHFClient unloaded, GPU cache cleared")

    def chat(
        self,
        messages: List[Dict[str, str]],
        generation_cfg: Optional[Dict[str, Any]] = None,
    ) -> str:
        """messages 리스트 → 응답 텍스트 (ChatClient.chat()과 동일한 인터페이스)."""
        import torch

        gen = generation_cfg or {}
        max_new_tokens = gen.get("max_new_tokens", 512)
        temperature = gen.get("temperature", 1.0)
        do_sample = temperature > 0 and temperature != 1.0

        # Chat template 적용 → 토크나이즈
        # pretrained 모델(e.g. gemma-3-1b-pt)은 chat_template가 없으므로 fallback
        if getattr(self.tokenizer, "chat_template", None):
            text = self.tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
        else:
            # chat_template 없는 pretrained 모델 → 단순 텍스트 연결
            parts = []
            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                parts.append(f"[{role.upper()}]\n{content}")
            parts.append("[ASSISTANT]\n")
            text = "\n\n".join(parts)
        inputs = self.tokenizer(text, return_tensors="pt")
        inputs = {k: v.to(self.model.device) for k, v in inputs.items()}

        input_len = inputs["input_ids"].shape[1]

        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=temperature if do_sample else 1.0,
                do_sample=do_sample,
                pad_token_id=self.tokenizer.eos_token_id,
            )

        # 새로 생성된 토큰만 디코딩
        new_tokens = outputs[0][input_len:]
        return self.tokenizer.decode(new_tokens, skip_special_tokens=True).strip()

    @classmethod
    def from_config(cls, model_cfg: Dict[str, Any]) -> "LocalHFClient":
        """bench YAML의 models.target 섹션에서 생성.

        model_cfg에는 이미 resolve된 model_dir 또는 export_dir가 들어 있어야 한다.
        export_dir가 지정된 경우 trust_remote_code=True로 로드 (custom_moe 지원).
        """
        model_dir = model_cfg.get("model_dir") or model_cfg.get("export_dir", "")
        device = model_cfg.get("device", "auto")
        dtype = model_cfg.get("dtype", "auto")
        trust_remote_code = bool(model_cfg.get("export_dir"))
        return cls(model_dir=model_dir, device=device, dtype=dtype,
                   trust_remote_code=trust_remote_code)


# -------------------------------------------------------------------------
# 응답 파싱 헬퍼
# -------------------------------------------------------------------------
def _extract_json(text: str) -> Optional[Dict]:
    """텍스트에서 첫 번째 JSON 객체를 추출."""
    # 1) 전체가 JSON인 경우
    try:
        return json.loads(text)
    except (json.JSONDecodeError, ValueError):
        pass
    # 2) ```json ... ``` 코드블록
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except (json.JSONDecodeError, ValueError):
            pass
    # 3) 인라인 JSON
    m = re.search(r"\{[^{}]*\}", text)
    if m:
        try:
            return json.loads(m.group(0))
        except (json.JSONDecodeError, ValueError):
            pass
    return None


def _parse_pointwise(raw: str) -> Dict[str, Any]:
    """pointwise 응답 파싱. 실패 시 기본값 반환."""
    parsed = _extract_json(raw)
    if parsed and "score" in parsed:
        return {
            "score": int(parsed["score"]),
            "explanation": str(parsed.get("explanation", "")),
            "raw": raw,
        }
    # 파싱 실패 — 숫자라도 추출 시도
    m = re.search(r"\b(\d{1,2})\b", raw)
    score = int(m.group(1)) if m else 5
    return {"score": score, "explanation": raw, "raw": raw, "parse_error": True}


def _parse_pairwise(raw: str) -> Dict[str, Any]:
    """pairwise 응답 파싱. 실패 시 기본값 반환."""
    parsed = _extract_json(raw)
    if parsed and "winner" in parsed:
        winner = str(parsed["winner"]).upper()
        if winner not in ("A", "B", "TIE"):
            winner = "tie"
        else:
            winner = winner.lower() if winner == "TIE" else winner
        return {
            "winner": winner,
            "score_a": int(parsed.get("score_a", 5)),
            "score_b": int(parsed.get("score_b", 5)),
            "explanation": str(parsed.get("explanation", "")),
            "raw": raw,
        }
    return {"winner": "tie", "score_a": 5, "score_b": 5, "explanation": raw,
            "raw": raw, "parse_error": True}
