# -*- coding: utf-8 -*-
"""
eulerforge.utils.moe_loss

훈련 루프에서 main loss에 MoE 관련 auxiliary loss(로드밸런싱 등)를 합산하기 위한 유틸.

레거시 학습 코드에서는 model.modules()를 순회하며 MoEFFN.last_aux_loss를 모아
main loss에 가중합했다. [file:1]

여기서는 다음을 일반화한다:
- 어떤 모듈이든 last_aux_loss 텐서 속성을 가지고 있으면 수집 대상
- device/dtype을 main loss에 맞춰 안전하게 합산
"""


from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import torch
import torch.nn as nn


@dataclass
class AuxLossSummary:
    aux_loss: Optional[torch.Tensor]
    num_modules: int


def collect_aux_loss(
    model: nn.Module,
    *,
    loss_device: Optional[torch.device] = None,
    loss_dtype: Optional[torch.dtype] = None,
) -> AuxLossSummary:
    """
    model.modules()를 순회하며 module.last_aux_loss가 존재하고 Tensor이면 합산한다.

    반환:
      - aux_loss: 없으면 None, 있으면 Tensor
      - num_modules: aux loss를 제공한 모듈 수
    """
    total: Optional[torch.Tensor] = None
    count = 0

    for m in model.modules():
        aux = getattr(m, "last_aux_loss", None)
        if aux is None or not torch.is_tensor(aux):
            continue

        if loss_device is not None:
            aux = aux.to(loss_device)
        if loss_dtype is not None:
            aux = aux.to(loss_dtype)

        total = aux if total is None else (total + aux)
        count += 1

    return AuxLossSummary(aux_loss=total, num_modules=count)


def combine_main_and_aux_loss(
    main_loss: torch.Tensor,
    model: nn.Module,
    *,
    aux_weight: float = 0.0,
) -> Tuple[torch.Tensor, AuxLossSummary]:
    """
    main_loss + aux_weight * sum(last_aux_loss) 를 반환한다.

    - aux_weight == 0이면 main_loss 그대로 반환(단, summary는 반환)
    - aux loss 텐서는 main_loss의 device/dtype으로 변환 후 합산 [file:1]
    """
    summary = collect_aux_loss(
        model,
        loss_device=main_loss.device,
        loss_dtype=main_loss.dtype,
    )

    if summary.aux_loss is None or float(aux_weight) == 0.0:
        return main_loss, summary

    return main_loss + float(aux_weight) * summary.aux_loss, summary
