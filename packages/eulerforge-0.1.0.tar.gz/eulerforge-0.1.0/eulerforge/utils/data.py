# eulerforge/utils/data.py
import json
from typing import Dict, Any, List, Optional

import torch
from torch.utils.data import Dataset


class ProcessedSFTDataset(Dataset):
    """
    이미 토크나이징된 SFT jsonl을 로드.
    각 라인은 보통 다음 중 하나를 포함:
      - input_ids: [int...]
      - attention_mask: [int...] (없으면 1로 생성)
      - labels: [int...] (없으면 input_ids 복사)
    """
    def __init__(self, path: str):
        self.path = path
        self.samples: List[Dict[str, Any]] = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                obj = json.loads(line)
                self.samples.append(obj)

        if not self.samples:
            raise ValueError(f"Empty dataset: {path}")

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        ex = self.samples[idx]

        input_ids = ex.get("input_ids")
        if input_ids is None:
            raise KeyError("Each JSONL row must contain 'input_ids'")

        attention_mask = ex.get("attention_mask")
        if attention_mask is None:
            attention_mask = [1] * len(input_ids)

        labels = ex.get("labels")
        if labels is None:
            labels = input_ids

        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }


class ProcessedPromptDataset(Dataset):
    """
    PPO용 프롬프트 전용 데이터셋.
    각 라인은 input_ids와 attention_mask를 포함 (labels 없음).
    """
    def __init__(self, path: str):
        self.path = path
        self.samples: List[Dict[str, Any]] = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                obj = json.loads(line)
                self.samples.append(obj)

        if not self.samples:
            raise ValueError(f"Empty dataset: {path}")

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        ex = self.samples[idx]
        input_ids = ex.get("input_ids")
        if input_ids is None:
            raise KeyError("Each JSONL row must contain 'input_ids'")

        attention_mask = ex.get("attention_mask")
        if attention_mask is None:
            attention_mask = [1] * len(input_ids)

        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
        }


def make_collate_fn(pad_token_id: int):
    def collate(batch: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
        # 길이 맞춰 pad
        input_ids = [b["input_ids"] for b in batch]
        attention_mask = [b["attention_mask"] for b in batch]
        has_labels = "labels" in batch[0]

        max_len = max(x.size(0) for x in input_ids)

        def pad_1d(x: torch.Tensor, pad_value: int):
            if x.size(0) == max_len:
                return x
            return torch.cat([x, torch.full((max_len - x.size(0),), pad_value, dtype=x.dtype)], dim=0)

        input_ids = torch.stack([pad_1d(x, pad_token_id) for x in input_ids], dim=0)
        attention_mask = torch.stack([pad_1d(x, 0) for x in attention_mask], dim=0)

        result = {"input_ids": input_ids, "attention_mask": attention_mask}

        # labels는 pad 부분을 -100으로 마스킹 (HF CausalLM loss 표준)
        # PPO prompt-only 데이터에는 labels가 없으므로 건너뜀
        if has_labels:
            labels = [b["labels"] for b in batch]
            labels = torch.stack([pad_1d(x, -100) for x in labels], dim=0)
            result["labels"] = labels

        return result

    return collate
