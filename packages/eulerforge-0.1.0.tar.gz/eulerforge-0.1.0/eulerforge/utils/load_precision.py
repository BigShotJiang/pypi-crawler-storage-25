# eulerforge/utils/load_precision.py
# -*- coding: utf-8 -*-
"""
Model load precision resolution and dequantize helpers.

Handles:
- ``model.load_precision`` YAML spec → resolved dict
- Legacy ``training.quant_bits`` → auto-conversion
- Phase dequantize policy for trainable base_ffn under quantization
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Tuple

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)

_QUANT_BITS_MAP = {4: "int4", 8: "int8", 16: "bf16", 32: "fp32"}

# Default precision: bf16 (no quantization).
# quant_type/double_quant are int4-only; they exist here for completeness
# but are ignored when mode is bf16/fp16/fp32/int8.
_DEFAULTS = {
    "mode": "bf16",
    "compute_dtype": "bf16",
    "quant_type": "nf4",
    "double_quant": True,
    "dequantize_on_train": True,
}


def resolve_load_precision(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Resolve ``model.load_precision`` from config, with legacy fallback.

    Returns a normalized dict with all fields filled to defaults.
    """
    model_cfg = cfg.get("model") or {}
    lp = model_cfg.get("load_precision")

    # Legacy fallback: training.quant_bits
    if lp is None:
        quant_bits = (cfg.get("training") or {}).get("quant_bits")
        if quant_bits is not None:
            quant_bits = int(quant_bits)
            mode = _QUANT_BITS_MAP.get(quant_bits, "bf16")
            lp = {"mode": mode}
        else:
            lp = {}

    result = dict(_DEFAULTS)
    if isinstance(lp, dict):
        result.update({k: v for k, v in lp.items() if v is not None})

    return result


_DTYPE_MAP = {"fp32": torch.float32, "fp16": torch.float16, "bf16": torch.bfloat16}


def resolve_compute_dtype(compute_dtype_str: str) -> torch.dtype:
    """Convert compute_dtype string to torch.dtype."""
    return _DTYPE_MAP.get(compute_dtype_str, torch.bfloat16)


def dequantize_base_ffn_params(
    named_params: List[Tuple[str, nn.Parameter]],
    target_dtype: torch.dtype,
) -> int:
    """Dequantize (cast) non-float parameters to target_dtype and enable grad.

    Args:
        named_params: List of (name, param) tuples to potentially dequantize.
        target_dtype: Target floating-point dtype for dequantized params.

    Returns:
        Number of parameters actually dequantized.
    """
    count = 0
    for name, param in named_params:
        if not param.dtype.is_floating_point:
            # Use proper bitsandbytes dequantization for int4 (nf4/fp4)
            qs = getattr(param, "quant_state", None)
            if qs is not None:
                try:
                    from bitsandbytes.functional import dequantize_4bit
                    param.data = dequantize_4bit(param.data, qs).to(target_dtype)
                except (ImportError, Exception):
                    param.data = param.data.to(target_dtype)
            else:
                param.data = param.data.to(target_dtype)
            param.requires_grad = True
            count += 1

    if count > 0:
        logger.info(
            "[Phase] Dequantized %d base_ffn parameters to %s for training",
            count, target_dtype,
        )

    return count
