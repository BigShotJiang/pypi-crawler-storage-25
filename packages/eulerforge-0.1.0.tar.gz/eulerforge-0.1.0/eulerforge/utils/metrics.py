# eulerforge/utils/metrics.py
# -*- coding: utf-8 -*-
"""
2-level metrics collection with optional TensorBoard recording.

Levels:
- ``minimal``: step, main_loss, total_loss, aux_loss, lr, grad_norm,
  throughput, tokens/samples counts, training-type-specific metrics.
- ``advanced``: minimal **+** MoE routing stats (token_frac stats, entropy,
  importance_cv, aux_loss_total, router_logit_max, num_moe_modules).

TensorBoard integration uses ``torch.utils.tensorboard.SummaryWriter``.
If the ``tensorboard`` package is not installed, ``TBWriter`` degrades to
a no-op with a one-time warning.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)

VALID_METRICS_LEVELS = ("minimal", "advanced")


# ---------------------------------------------------------------------------
# A) Gradient norm
# ---------------------------------------------------------------------------

def compute_grad_norm(model: nn.Module) -> float:
    """Compute global L2 gradient norm across all parameters.

    Returns 0.0 when no parameter has a gradient.
    """
    total_norm_sq = 0.0
    for p in model.parameters():
        if p.grad is not None:
            total_norm_sq += p.grad.data.norm(2).item() ** 2
    return total_norm_sq ** 0.5


# ---------------------------------------------------------------------------
# B) MoE metrics collection
# ---------------------------------------------------------------------------

_MOE_CLASS_NAMES = {"MoEFFN", "MixtureLoRALinear"}


def collect_moe_metrics(
    model: nn.Module,
    max_experts: int = 16,
) -> Dict[str, float]:
    """Collect advanced routing metrics from MoE / MixtureLoRA modules.

    Traverses ``model.modules()`` looking for ``MoEFFN`` and
    ``MixtureLoRALinear`` by class name and reads their ``last_stats``
    attribute.

    Returns an empty dict when no MoE modules are found.

    Returned keys (when MoE present):
        moe/token_frac_mean, moe/token_frac_std, moe/token_frac_max,
        moe/entropy_mean, moe/importance_cv, moe/aux_loss_total,
        moe/router_logit_max (if available), moe/num_moe_modules
    """
    token_fracs: List[torch.Tensor] = []
    importances: List[torch.Tensor] = []
    entropies: List[float] = []
    aux_losses: List[float] = []
    router_logit_maxes: List[float] = []
    num_modules = 0

    for module in model.modules():
        cls_name = type(module).__name__
        if cls_name not in _MOE_CLASS_NAMES:
            continue

        stats = getattr(module, "last_stats", None)
        if stats is None:
            continue

        num_modules += 1

        # token_frac — common to both MoEStats and MixtureLoRAStats
        tf = getattr(stats, "token_frac", None)
        if tf is not None and isinstance(tf, torch.Tensor):
            token_fracs.append(tf.detach().float())

        # importance
        imp = getattr(stats, "importance", None)
        if imp is not None and isinstance(imp, torch.Tensor):
            importances.append(imp.detach().float())

        # entropy (scalar in MoEStats.gate_prob_entropy, scalar in MixtureLoRAStats.entropy)
        ent = getattr(stats, "gate_prob_entropy", None) or getattr(stats, "entropy", None)
        if ent is not None:
            val = ent.item() if isinstance(ent, torch.Tensor) else float(ent)
            entropies.append(val)

        # aux loss
        aux = getattr(module, "last_aux_loss", None)
        if aux is not None:
            val = aux.item() if isinstance(aux, torch.Tensor) else float(aux)
            aux_losses.append(val)

        # router logit max
        logits = getattr(module, "last_gate_logits", None)
        if logits is not None and isinstance(logits, torch.Tensor):
            router_logit_maxes.append(logits.detach().abs().max().item())

    if num_modules == 0:
        return {}

    result: Dict[str, float] = {"moe/num_moe_modules": float(num_modules)}

    # Aggregate token_frac stats
    if token_fracs:
        all_frac = torch.cat(token_fracs)
        result["moe/token_frac_mean"] = all_frac.mean().item()
        result["moe/token_frac_std"] = all_frac.std().item() if all_frac.numel() > 1 else 0.0
        result["moe/token_frac_max"] = all_frac.max().item()

    # Aggregate entropy
    if entropies:
        result["moe/entropy_mean"] = sum(entropies) / len(entropies)

    # Importance CV (coefficient of variation = std / mean)
    if importances:
        all_imp = torch.cat(importances)
        imp_mean = all_imp.mean().item()
        imp_std = all_imp.std().item() if all_imp.numel() > 1 else 0.0
        result["moe/importance_cv"] = imp_std / max(imp_mean, 1e-9)

    # Aux loss total
    if aux_losses:
        result["moe/aux_loss_total"] = sum(aux_losses)

    # Router logit max
    if router_logit_maxes:
        result["moe/router_logit_max"] = max(router_logit_maxes)

    return result


# ---------------------------------------------------------------------------
# C) TensorBoard thin wrapper
# ---------------------------------------------------------------------------

class TBWriter:
    """Thin wrapper around ``torch.utils.tensorboard.SummaryWriter``.

    When *enabled* is False, all methods are no-ops.
    When tensorboard is not installed, logs a one-time warning and degrades
    to no-op.
    """

    def __init__(self, enabled: bool, log_dir: str) -> None:
        self._enabled = enabled
        self._writer = None
        if not enabled:
            return
        try:
            from torch.utils.tensorboard import SummaryWriter
            os.makedirs(log_dir, exist_ok=True)
            self._writer = SummaryWriter(log_dir=log_dir)
        except (ImportError, ModuleNotFoundError):
            logger.warning(
                "[Metrics] tensorboard is not installed. "
                "TensorBoard logging disabled. Install with: pip install eulerforge[tb]"
            )
            self._enabled = False

    def add_scalar(self, tag: str, value: float, step: int) -> None:
        if self._writer is not None:
            self._writer.add_scalar(tag, value, step)

    def close(self) -> None:
        if self._writer is not None:
            self._writer.close()
            self._writer = None


# ---------------------------------------------------------------------------
# D) MetricsCollector
# ---------------------------------------------------------------------------

class MetricsCollector:
    """2-level metrics collection + optional TensorBoard logging.

    Parameters
    ----------
    level : str
        ``"minimal"`` or ``"advanced"``.
    tb_writer : TBWriter
        TensorBoard writer (can be disabled).
    log_interval : int
        TensorBoard records every *log_interval* steps.
    max_experts_log : int
        Cap for per-expert detail in advanced mode.
    """

    def __init__(
        self,
        level: str,
        tb_writer: TBWriter,
        log_interval: int = 50,
        max_experts_log: int = 16,
        jsonl_path: Optional[str] = None,
    ) -> None:
        if level not in VALID_METRICS_LEVELS:
            raise ValueError(
                f"Unknown metrics_level '{level}'. "
                f"Valid: {', '.join(VALID_METRICS_LEVELS)}"
            )
        self.level = level
        self._tb = tb_writer
        self._log_interval = max(log_interval, 1)
        self._max_experts_log = max_experts_log
        self._history: List[Dict[str, float]] = []
        self._jsonl_path = jsonl_path
        if jsonl_path:
            os.makedirs(os.path.dirname(jsonl_path) or ".", exist_ok=True)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def log_step(
        self,
        step: int,
        main_loss: float,
        total_loss: float,
        aux_loss: Optional[float],
        lr: float,
        metrics: Dict[str, float],
        model: nn.Module,
        tokens_seen: int,
        samples_seen: int,
        optimizer_step: int = 0,
        effective_batch: int = 0,
    ) -> Dict[str, float]:
        """Collect metrics for a training step.

        Returns the full dict of collected metrics.
        """
        record: Dict[str, float] = {}

        # --- minimal level ---
        record["train/main_loss"] = main_loss
        record["train/total_loss"] = total_loss
        if aux_loss is not None:
            record["train/aux_loss"] = aux_loss
        record["train/learning_rate"] = lr
        record["train/grad_norm"] = compute_grad_norm(model)
        record["train/tokens_seen"] = float(tokens_seen)
        record["train/samples_seen"] = float(samples_seen)
        record["train/optimizer_step"] = float(optimizer_step)
        record["train/micro_step"] = float(step)
        record["train/effective_batch"] = float(effective_batch)

        # Training-type-specific metrics (DPO, ORPO, RM, PPO)
        for key, value in metrics.items():
            tag = f"train/{key}"
            if tag not in record:
                record[tag] = value

        # --- advanced level ---
        if self.level == "advanced":
            moe_metrics = collect_moe_metrics(model, self._max_experts_log)
            record.update(moe_metrics)

        # Store in history
        self._history.append(record)

        # TensorBoard recording
        if step % self._log_interval == 0:
            for tag, value in record.items():
                self._tb.add_scalar(tag, value, step)

        # JSONL recording (every step, regardless of log_interval)
        if self._jsonl_path:
            import json as _json
            with open(self._jsonl_path, "a", encoding="utf-8") as _f:
                _f.write(_json.dumps({"step": step, **record}) + "\n")

        return record

    def get_history(self) -> List[Dict[str, float]]:
        """Return all recorded step dicts."""
        return list(self._history)

    def close(self) -> None:
        """Flush and close the TensorBoard writer."""
        self._tb.close()
