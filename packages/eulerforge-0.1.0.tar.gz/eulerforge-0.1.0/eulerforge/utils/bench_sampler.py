# eulerforge/utils/bench_sampler.py
# -*- coding: utf-8 -*-
"""
벤치마크 데이터 샘플링 유틸리티.

JSONL 파일에서 k개 샘플을 랜덤 추출(시드 고정 가능)하고,
task 타입에 따라 프롬프트를 추출한다.
"""
from __future__ import annotations

import json
import random
from typing import Any, Dict, List


def load_jsonl(data_path: str) -> List[Dict[str, Any]]:
    """JSONL 파일 전체 로딩."""
    items: List[Dict[str, Any]] = []
    with open(data_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                items.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return items


def sample_bench_data(
    data_path: str,
    k: int = 10,
    seed: int = 42,
    shuffle: bool = True,
) -> List[Dict[str, Any]]:
    """JSONL에서 k개 샘플 추출.

    Args:
        data_path: JSONL 파일 경로
        k: 추출할 샘플 수 (0이면 전체)
        seed: 랜덤 시드
        shuffle: 셔플 여부

    Returns:
        추출된 샘플 리스트
    """
    items = load_jsonl(data_path)
    if not items:
        return []

    if shuffle:
        rng = random.Random(seed)
        rng.shuffle(items)

    if k <= 0 or k >= len(items):
        return items
    return items[:k]


def extract_prompt(item: Dict[str, Any], task: str) -> str:
    """task에 따라 프롬프트를 추출.

    - sft: 'prompt' 키
    - preference: 'prompt' 키

    둘 다 'prompt' 키를 사용하지만, fallback으로 'instruction' → 'input' 순서로 시도.
    """
    prompt = item.get("prompt")
    if prompt:
        return str(prompt)
    # fallback
    prompt = item.get("instruction")
    if prompt:
        if isinstance(prompt, dict):
            return str(prompt.get("value", ""))
        return str(prompt)
    prompt = item.get("input")
    if prompt:
        return str(prompt)
    return ""
