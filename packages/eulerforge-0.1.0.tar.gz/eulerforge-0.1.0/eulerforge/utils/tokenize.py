# eulerforge/utils/tokenize.py
# -*- coding: utf-8 -*-
"""
Raw data tokenization for EulerForge.

Three task types:
- sft: {"text": "..."} or {"prompt": "...", "response": "..."}
- preference: {"chosen": "...", "rejected": "..."}
- prompted_preference: {"prompt": "...", "chosen": "...", "rejected": "..."}

Each function takes a single row dict + tokenizer + max_length,
returns a processed dict ready for ProcessedSFTDataset / ProcessedDPODataset.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

VALID_TASKS = ("sft", "preference", "prompted_preference", "prompt_only")


def _ensure_eos(ids: List[int], eos_token_id: Optional[int], max_length: int) -> List[int]:
    """시퀀스 끝에 EOS 토큰을 보장한다.

    - EOS ID가 None이면 그대로 반환.
    - 이미 EOS로 끝나면 그대로 반환.
    - 길이가 max_length 미만이면 EOS를 추가.
    - 길이가 max_length이면 마지막 토큰을 EOS로 교체 (truncation 시).
    """
    if eos_token_id is None or not ids:
        return ids
    if ids[-1] == eos_token_id:
        return ids
    if len(ids) < max_length:
        return ids + [eos_token_id]
    # truncated — 마지막 토큰을 EOS로 교체
    ids = list(ids)
    ids[-1] = eos_token_id
    return ids


# ---------------------------------------------------------------------------
# A-0) Prompt Only (PPO)
# ---------------------------------------------------------------------------
def tokenize_prompt_only(
    row: Dict[str, Any],
    tokenizer,
    max_length: int = 512,
    *,
    prompt_col: str = "prompt",
) -> Dict[str, Any]:
    """Tokenize a single prompt-only row for PPO.

    Returns input_ids and attention_mask only (no labels).
    """
    prompt_text = row.get(prompt_col)
    if prompt_text is None or not str(prompt_text).strip():
        raise ValueError(f"Row must contain non-empty '{prompt_col}' column.")

    ids = tokenizer.encode(str(prompt_text), add_special_tokens=False)[:max_length]
    return {
        "input_ids": ids,
        "attention_mask": [1] * len(ids),
    }


# ---------------------------------------------------------------------------
# A) SFT
# ---------------------------------------------------------------------------
def tokenize_sft(
    row: Dict[str, Any],
    tokenizer,
    max_length: int = 512,
    *,
    text_col: str = "text",
    prompt_col: str = "prompt",
    response_col: str = "response",
) -> Dict[str, Any]:
    """Tokenize a single SFT row.

    Two modes:
    1. *text_col* present  -> full causal LM (labels = input_ids)
    2. *prompt_col* + *response_col* present -> labels masked with -100 for prompt
    """
    has_text = text_col in row
    has_pr = prompt_col in row and response_col in row

    eos_id = getattr(tokenizer, "eos_token_id", None)

    if has_pr and row.get(prompt_col) and row.get(response_col):
        prompt_text = str(row[prompt_col])
        response_text = str(row[response_col])
        full_text = prompt_text + response_text

        prompt_ids = tokenizer.encode(prompt_text, add_special_tokens=False)
        full_ids = tokenizer.encode(full_text, add_special_tokens=False)[:max_length]
        full_ids = _ensure_eos(full_ids, eos_id, max_length)
        prompt_len = min(len(prompt_ids), len(full_ids))

        labels = [-100] * prompt_len + full_ids[prompt_len:]
        attention_mask = [1] * len(full_ids)

        return {
            "input_ids": full_ids,
            "attention_mask": attention_mask,
            "labels": labels,
        }

    if has_text:
        text = str(row[text_col])
        if not text.strip():
            raise ValueError(f"Empty text in column '{text_col}'. Row must have non-empty text.")

        ids = tokenizer.encode(text, add_special_tokens=False)[:max_length]
        ids = _ensure_eos(ids, eos_id, max_length)
        return {
            "input_ids": ids,
            "attention_mask": [1] * len(ids),
            "labels": list(ids),
        }

    raise ValueError(
        f"SFT row must contain '{text_col}' or both '{prompt_col}' and "
        f"'{response_col}'. Got keys: {list(row.keys())}"
    )


# ---------------------------------------------------------------------------
# B) Preference (no prompt)
# ---------------------------------------------------------------------------
def tokenize_preference(
    row: Dict[str, Any],
    tokenizer,
    max_length: int = 512,
    *,
    chosen_col: str = "chosen",
    rejected_col: str = "rejected",
) -> Dict[str, Any]:
    """Tokenize a preference pair (no prompt). Labels = full sequence."""
    chosen_text = str(row[chosen_col])
    rejected_text = str(row[rejected_col])

    eos_id = getattr(tokenizer, "eos_token_id", None)
    chosen_ids = tokenizer.encode(chosen_text, add_special_tokens=False)[:max_length]
    chosen_ids = _ensure_eos(chosen_ids, eos_id, max_length)
    rejected_ids = tokenizer.encode(rejected_text, add_special_tokens=False)[:max_length]
    rejected_ids = _ensure_eos(rejected_ids, eos_id, max_length)

    return {
        "chosen_input_ids": chosen_ids,
        "chosen_attention_mask": [1] * len(chosen_ids),
        "chosen_labels": list(chosen_ids),
        "rejected_input_ids": rejected_ids,
        "rejected_attention_mask": [1] * len(rejected_ids),
        "rejected_labels": list(rejected_ids),
    }


# ---------------------------------------------------------------------------
# C) Prompted preference (DPO with prompt)
# ---------------------------------------------------------------------------
def tokenize_prompted_preference(
    row: Dict[str, Any],
    tokenizer,
    max_length: int = 512,
    *,
    prompt_col: str = "prompt",
    chosen_col: str = "chosen",
    rejected_col: str = "rejected",
) -> Dict[str, Any]:
    """Tokenize a prompted preference triplet.

    chosen/rejected sequences are ``prompt + completion``.
    Labels: prompt tokens masked with -100, only completion tokens for loss.
    """
    prompt_text = str(row[prompt_col])
    chosen_text = str(row[chosen_col])
    rejected_text = str(row[rejected_col])

    eos_id = getattr(tokenizer, "eos_token_id", None)
    prompt_ids = tokenizer.encode(prompt_text, add_special_tokens=False)

    # chosen = prompt + chosen_completion
    chosen_full = prompt_text + chosen_text
    chosen_ids = tokenizer.encode(chosen_full, add_special_tokens=False)[:max_length]
    chosen_ids = _ensure_eos(chosen_ids, eos_id, max_length)
    prompt_len = min(len(prompt_ids), len(chosen_ids))
    chosen_labels = [-100] * prompt_len + chosen_ids[prompt_len:]

    # rejected = prompt + rejected_completion
    rejected_full = prompt_text + rejected_text
    rejected_ids = tokenizer.encode(rejected_full, add_special_tokens=False)[:max_length]
    rejected_ids = _ensure_eos(rejected_ids, eos_id, max_length)
    rejected_prompt_len = min(len(prompt_ids), len(rejected_ids))
    rejected_labels = [-100] * rejected_prompt_len + rejected_ids[rejected_prompt_len:]

    return {
        "prompt_input_ids": prompt_ids[:max_length],
        "prompt_attention_mask": [1] * min(len(prompt_ids), max_length),
        "chosen_input_ids": chosen_ids,
        "chosen_attention_mask": [1] * len(chosen_ids),
        "chosen_labels": chosen_labels,
        "rejected_input_ids": rejected_ids,
        "rejected_attention_mask": [1] * len(rejected_ids),
        "rejected_labels": rejected_labels,
        "prompt_len": prompt_len,
    }


# ---------------------------------------------------------------------------
# D) File-level preprocessing
# ---------------------------------------------------------------------------
def preprocess_file(
    input_path: str,
    output_path: str,
    task: str,
    tokenizer,
    max_length: int = 512,
    num_proc: int = 1,
    schema: Optional[Dict[str, str]] = None,
) -> int:
    """Preprocess an entire raw JSONL file to processed JSONL.

    Returns number of rows written.
    """
    if task not in VALID_TASKS:
        raise ValueError(
            f"Unknown task '{task}'. Valid tasks: {', '.join(VALID_TASKS)}"
        )

    schema = schema or {}

    # Read input
    rows: List[Dict[str, Any]] = []
    with open(input_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))

    if not rows:
        raise ValueError(f"Empty input file: {input_path}")

    # Choose tokenization function + kwargs based on schema
    if task == "sft":
        fn = tokenize_sft
        col_kwargs = {
            "text_col": schema.get("text_col", "text"),
            "prompt_col": schema.get("prompt_col", "prompt"),
            "response_col": schema.get("response_col", "response"),
        }
    elif task == "preference":
        fn = tokenize_preference
        col_kwargs = {
            "chosen_col": schema.get("chosen_col", "chosen"),
            "rejected_col": schema.get("rejected_col", "rejected"),
        }
    elif task == "prompt_only":
        fn = tokenize_prompt_only
        col_kwargs = {
            "prompt_col": schema.get("prompt_col", "prompt"),
        }
    else:  # prompted_preference
        fn = tokenize_prompted_preference
        col_kwargs = {
            "prompt_col": schema.get("prompt_col", "prompt"),
            "chosen_col": schema.get("chosen_col", "chosen"),
            "rejected_col": schema.get("rejected_col", "rejected"),
        }

    if num_proc > 1:
        return _preprocess_parallel(
            rows, output_path, task, fn, col_kwargs, tokenizer, max_length, num_proc,
        )

    # Sequential processing
    count = 0
    with open(output_path, "w", encoding="utf-8") as out:
        for row in rows:
            processed = fn(row, tokenizer, max_length, **col_kwargs)
            out.write(json.dumps(processed, ensure_ascii=False) + "\n")
            count += 1

    logger.info(f"[Preprocess] Wrote {count} rows to {output_path}")
    return count


def _preprocess_parallel(
    rows: List[Dict[str, Any]],
    output_path: str,
    task: str,
    fn,
    col_kwargs: Dict[str, str],
    tokenizer,
    max_length: int,
    num_proc: int,
) -> int:
    """Parallel preprocessing using HuggingFace Datasets."""
    import os
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

    from datasets import Dataset

    ds = Dataset.from_list(rows)

    def _map_fn(examples):
        results: Dict[str, list] = {}
        # Get the keys from a first pass
        keys: Optional[list] = None
        batch_size = len(next(iter(examples.values())))
        for i in range(batch_size):
            row = {k: examples[k][i] for k in examples}
            processed = fn(row, tokenizer, max_length, **col_kwargs)
            if keys is None:
                keys = list(processed.keys())
                for k in keys:
                    results[k] = []
            for k in keys:
                results[k].append(processed[k])
        return results

    mapped = ds.map(
        _map_fn,
        batched=True,
        batch_size=100,
        num_proc=num_proc,
        remove_columns=ds.column_names,
    )

    # Arrow-native JSONL export (fast, no row-by-row Python iteration)
    mapped.to_json(output_path)
    count = len(mapped)

    logger.info(f"[Preprocess] Wrote {count} rows to {output_path} (num_proc={num_proc})")
    return count
