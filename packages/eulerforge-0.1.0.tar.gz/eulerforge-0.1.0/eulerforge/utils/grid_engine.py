# eulerforge/utils/grid_engine.py
# -*- coding: utf-8 -*-
"""
Grid Search 실행 엔진 (Optuna 기반).

지원 method: grid (GridSampler), random (RandomSampler), bayes (TPESampler).
각 trial은 in-process로 eulerforge.cli.train.main()을 호출한다.
"""
from __future__ import annotations

import csv
import gc
import json
import logging
import math
import os
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_grid_search(spec: Dict[str, Any], project_root: str) -> Dict[str, Any]:
    """Grid/Random/Bayesian HPO를 실행하고 summary dict를 반환한다.

    Parameters
    ----------
    spec:
        load_and_validate_grid_spec()로 파싱된 dict.
    project_root:
        base_preset / output_root 등 상대 경로의 기준 디렉토리.

    Returns
    -------
    summary dict: best_trial + all_trials 포함.
    """
    try:
        import optuna
    except ImportError:
        raise ImportError(
            "Grid Search Config: optuna is not installed\n"
            "Fix: pip install eulerforge[hpo]\n"
            "See: docs/tutorials/12_grid_search.md"
        )

    optuna.logging.set_verbosity(optuna.logging.WARNING)

    study = _create_study(spec)
    n_trials = spec["run"]["max_trials"]

    def objective(trial):
        return _run_trial(trial, spec, project_root)

    study.optimize(objective, n_trials=n_trials)
    summary = _build_summary(study, spec)
    _save_summary(summary, spec)
    return summary


# ---------------------------------------------------------------------------
# Study 생성
# ---------------------------------------------------------------------------

def _create_study(spec: Dict[str, Any]):
    """spec에 따라 Optuna Study를 생성한다."""
    import optuna

    method = spec["search"]["method"]
    sampler_cfg = spec["search"].get("sampler") or {}
    seed = sampler_cfg.get("seed", 42)
    direction = spec["run"]["objective"]["direction"]

    if method == "grid":
        grid_params = _build_grid_params(spec["search"]["space"])
        sampler = optuna.samplers.GridSampler(grid_params)
    elif method == "random":
        sampler = optuna.samplers.RandomSampler(seed=seed)
    elif method == "bayes":
        sampler = optuna.samplers.TPESampler(seed=seed)
    else:
        raise ValueError(f"Unknown search method: {method!r}")

    return optuna.create_study(direction=direction, sampler=sampler)


def _build_grid_params(space: List[Dict[str, Any]]) -> Dict[str, List]:
    """GridSampler용 파라미터 dict를 구성한다.

    choices 키가 있는 항목만 포함 (grid는 이산 공간만 지원).
    """
    result: Dict[str, List] = {}
    for item in space:
        name = item["name"]
        if "choices" in item and item["choices"] is not None:
            result[name] = list(item["choices"])
    return result


# ---------------------------------------------------------------------------
# 파라미터 샘플링
# ---------------------------------------------------------------------------

def _sample_params(trial, space: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Optuna trial에서 space 정의에 따라 파라미터를 샘플링한다."""
    params: Dict[str, Any] = {}
    for item in space:
        name = item["name"]
        ptype = item["type"]
        has_choices = "choices" in item and item["choices"] is not None

        if ptype == "categorical" or has_choices:
            choices = item["choices"]
            params[name] = trial.suggest_categorical(name, choices)
        elif ptype == "float":
            log = bool(item.get("log", False))
            params[name] = trial.suggest_float(
                name, item["low"], item["high"], log=log
            )
        elif ptype == "int":
            step = item.get("step", 1)
            params[name] = trial.suggest_int(
                name, item["low"], item["high"], step=step
            )
    return params


# ---------------------------------------------------------------------------
# 단일 trial 실행
# ---------------------------------------------------------------------------

def _run_trial(trial, spec: Dict[str, Any], project_root: str) -> float:
    """단일 trial을 in-process로 실행하고 objective metric 값을 반환한다."""
    import torch

    overrides = _sample_params(trial, spec["search"]["space"])

    output_root = spec["run"]["output_root"]
    if not os.path.isabs(output_root):
        output_root = os.path.join(project_root, output_root)
    trial_dir = os.path.join(output_root, f"trial_{trial.number:04d}")

    argv = _build_train_argv(spec, overrides, trial_dir, project_root)
    logger.info(f"[Grid] Trial {trial.number}: {overrides}")

    success = True
    error_msg = ""
    try:
        from eulerforge.cli.train import main as train_main
        train_main(argv=argv)
    except SystemExit as e:
        code = e.code if e.code is not None else 0
        if int(code) != 0:
            error_msg = f"SystemExit(code={code})"
            logger.error(f"[FATAL] {error_msg}")
            logger.warning(f"[Grid] Trial {trial.number} failed (exit code {code})")
            success = False
    except Exception as e:
        error_msg = f"{type(e).__name__}: {e}"
        logger.error(f"[Grid] Trial {trial.number} exception: {error_msg}")
        success = False
    finally:
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        gc.collect()

    if not success:
        trial.set_user_attr("error", error_msg[:500])
        direction = spec["run"]["objective"]["direction"]
        return float("inf") if direction == "minimize" else float("-inf")

    metrics_path = os.path.join(trial_dir, "metrics.jsonl")
    loss_value = _extract_metric(metrics_path, spec["run"]["objective"])

    # NaN은 훈련 발산/불안정의 정상적 결과. Optuna는 NaN을 거부하므로
    # worst value로 변환하여 trial을 실패 처리하되 study는 계속 진행시킨다.
    if math.isnan(loss_value):
        trial.set_user_attr("error", "NaN metric value")
        logger.warning(
            f"[Grid] Trial {trial.number}: metric NaN — returning worst value "
            f"(direction={spec['run']['objective']['direction']})"
        )
        direction = spec["run"]["objective"]["direction"]
        return float("inf") if direction == "minimize" else float("-inf")

    # bench_eval: 훈련 후 bench 평가 (선택)
    bench_eval = spec["run"].get("bench_eval", {})
    if isinstance(bench_eval, dict) and bench_eval.get("enabled", False):
        bench_score = _run_bench_eval(trial_dir, bench_eval, spec, project_root)
        trial.set_user_attr("bench_score", bench_score)
        logger.info(f"[Grid] Trial {trial.number}: bench_score={bench_score:.4f}")

    return loss_value


def _build_train_argv(
    spec: Dict[str, Any],
    overrides: Dict[str, Any],
    trial_dir: str,
    project_root: str,
) -> List[str]:
    """trial 실행용 train CLI argv를 구성한다."""
    base_preset = spec["base_preset"]
    if not os.path.isabs(base_preset):
        base_preset = os.path.join(project_root, base_preset)

    argv = [
        "--preset", base_preset,
        "--output-dir", trial_dir,
        "--set", f"training.max_train_steps={spec['run']['max_train_steps']}",
    ]

    # data 오버라이드 (--set으로 config에 주입)
    data = spec["run"].get("data")
    if data:
        fmt = data.get("format", "processed")
        path = data["path"]
        if not os.path.isabs(path):
            path = os.path.join(project_root, path)
        if fmt == "raw":
            argv += [
                "--set", f"data.format=raw",
                "--set", f"data.path={path}",
                "--set", f"data.task={data['task']}",
            ]
            if data.get("max_length"):
                argv += ["--set", f"data.max_length={data['max_length']}"]
        else:
            argv += ["--set", f"processed_data_path={path}"]

    # 하이퍼파라미터 오버라이드 (dot-path)
    for dot_path, value in overrides.items():
        if isinstance(value, list):
            # 리스트 값: [a,b,c] 형식으로 직렬화
            list_str = "[" + ",".join(str(v) for v in value) + "]"
            argv += ["--set", f"{dot_path}={list_str}"]
        else:
            argv += ["--set", f"{dot_path}={value}"]

    return argv


# ---------------------------------------------------------------------------
# metrics.jsonl 파싱
# ---------------------------------------------------------------------------

def _extract_metric(metrics_path: str, objective: Dict[str, Any]) -> float:
    """metrics.jsonl에서 objective metric 값을 추출한다."""
    metric_key = objective["metric"]
    step_agg = objective.get("step_agg", "last")

    values: List[float] = []
    with open(metrics_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            record = json.loads(line)
            if metric_key in record:
                values.append(float(record[metric_key]))

    if not values:
        raise ValueError(
            f"Metric '{metric_key}' not found in {metrics_path}. "
            f"Available keys in last record: check metrics.jsonl"
        )

    if step_agg == "last":
        return values[-1]
    elif step_agg == "min":
        return min(values)
    elif step_agg == "mean":
        return sum(values) / len(values)
    else:
        raise ValueError(f"Unknown step_agg: {step_agg!r}")


# ---------------------------------------------------------------------------
# Bench 평가 (trial 별)
# ---------------------------------------------------------------------------

def _run_bench_eval(
    trial_dir: str,
    bench_eval: Dict[str, Any],
    spec: Dict[str, Any],
    project_root: str,
) -> float:
    """trial의 체크포인트에 대해 bench 평가를 실행하고 점수를 반환한다."""
    import torch

    bench_preset = bench_eval["bench_preset"]
    if not os.path.isabs(bench_preset):
        bench_preset = os.path.join(project_root, bench_preset)

    checkpoint = bench_eval.get("checkpoint", "final")
    metric = bench_eval.get("metric", "avg_score")

    # trial의 체크포인트 디렉토리 결정
    if checkpoint == "final":
        model_dir = os.path.join(trial_dir, "final")
    elif checkpoint == "latest":
        model_dir = os.path.join(trial_dir, "checkpoint-latest")
    elif checkpoint == "best":
        model_dir = os.path.join(trial_dir, "checkpoint-best")
    else:
        model_dir = os.path.join(trial_dir, "final")

    if not os.path.isdir(model_dir):
        logger.warning(f"[Grid] Bench eval: checkpoint dir not found: {model_dir}")
        return float("-inf")

    bench_out_dir = os.path.join(trial_dir, "bench_eval")

    try:
        from eulerforge.cli.bench import main as bench_main
        bench_argv = [
            "--preset", bench_preset,
            "--target-model-dir", model_dir,
            "--set", f"bench.output.out_dir={bench_out_dir}",
        ]
        bench_main(argv=bench_argv)
    except SystemExit as e:
        code = e.code if e.code is not None else 0
        if int(code) != 0:
            logger.warning(f"[Grid] Bench eval failed (exit={code})")
            return float("-inf")
    except Exception as e:
        logger.warning(f"[Grid] Bench eval exception: {e}")
        return float("-inf")
    finally:
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        gc.collect()

    # summary.json에서 bench 점수 추출
    summary_path = os.path.join(bench_out_dir, "summary.json")
    if not os.path.isfile(summary_path):
        logger.warning(f"[Grid] Bench eval: summary.json not found at {summary_path}")
        return float("-inf")

    with open(summary_path, "r", encoding="utf-8") as f:
        bench_summary = json.load(f)

    score = bench_summary.get(metric)
    if score is None:
        # fallback: target_avg_score → avg_score
        score = bench_summary.get("target_avg_score", bench_summary.get("avg_score"))
    if score is None:
        logger.warning(f"[Grid] Bench eval: metric '{metric}' not found in summary")
        return float("-inf")

    return float(score)


# ---------------------------------------------------------------------------
# Summary 생성 / 저장
# ---------------------------------------------------------------------------

def _build_summary(study, spec: Dict[str, Any]) -> Dict[str, Any]:
    """Optuna study에서 summary dict를 생성한다.

    bench_eval이 활성화되어 있으면 loss 기준 best와 bench 기준 best를 각각 보고한다.
    """
    best = study.best_trial
    best_by_loss = {
        "number": best.number,
        "value": best.value,
        "params": dict(best.params),
    }

    all_trials = []
    bench_eval_enabled = False
    bench_eval_cfg = spec["run"].get("bench_eval", {})
    if isinstance(bench_eval_cfg, dict) and bench_eval_cfg.get("enabled", False):
        bench_eval_enabled = True

    for t in study.trials:
        entry = {
            "number": t.number,
            "value": t.value,
            "params": dict(t.params),
            "state": t.state.name,
        }
        error = t.user_attrs.get("error")
        if error:
            entry["error"] = error
        bench_score = t.user_attrs.get("bench_score")
        if bench_score is not None:
            entry["bench_score"] = bench_score
        all_trials.append(entry)

    summary = {
        "best_trial": best_by_loss,
        "all_trials": all_trials,
        "method": spec["search"]["method"],
        "objective": spec["run"]["objective"],
    }

    # bench_eval 기준 best trial (bench_score가 가장 높은 trial)
    if bench_eval_enabled:
        bench_trials = [
            t for t in all_trials
            if "bench_score" in t and t["bench_score"] != float("-inf")
        ]
        if bench_trials:
            best_bench = max(bench_trials, key=lambda t: t["bench_score"])
            summary["best_by_bench"] = {
                "number": best_bench["number"],
                "bench_score": best_bench["bench_score"],
                "value": best_bench["value"],  # loss도 함께 표시
                "params": best_bench["params"],
            }
            summary["bench_eval"] = {
                "metric": bench_eval_cfg.get("metric", "avg_score"),
                "checkpoint": bench_eval_cfg.get("checkpoint", "final"),
                "bench_preset": bench_eval_cfg.get("bench_preset", ""),
            }

    return summary


def _save_summary(summary: Dict[str, Any], spec: Dict[str, Any]) -> None:
    """summary.json + summary.csv를 output_root에 저장한다."""
    output_root = spec["run"]["output_root"]
    os.makedirs(output_root, exist_ok=True)

    # JSON
    json_path = os.path.join(output_root, "summary.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    logger.info(f"[Grid] Summary saved to {json_path}")

    # CSV
    csv_path = os.path.join(output_root, "summary.csv")
    trials = summary.get("all_trials", [])
    if trials:
        # 컬럼: number, value, [bench_score], state, param_*
        param_keys = sorted(trials[0].get("params", {}).keys())
        has_bench = any("bench_score" in t for t in trials)
        fieldnames = ["number", "value"]
        if has_bench:
            fieldnames.append("bench_score")
        fieldnames += ["state"] + [f"param_{k}" for k in param_keys]
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for t in trials:
                row = {
                    "number": t["number"],
                    "value": t["value"],
                    "state": t.get("state", ""),
                }
                if has_bench:
                    row["bench_score"] = t.get("bench_score", "")
                for k in param_keys:
                    row[f"param_{k}"] = t.get("params", {}).get(k, "")
                writer.writerow(row)
    logger.info(f"[Grid] CSV summary saved to {csv_path}")
