# # -*- coding: utf-8 -*-
# """
# eulerforge.injection.native_moe_expert_lora


# C) Native MoE backbone + expert LoRA injection.


# - Mixtral 같은 "이미 native MoE"인 백본에서,
#   experts 내부 Linear들에 LoRA를 붙인다.
# - 구조를 먼저 만들어둔 뒤 체크포인트를 로드해야 LoRA weight가 매칭된다(재현성 원칙). [file:1]


# 이 모듈은:
# - BackboneAdapter.find_transformer_layers()
# - BackboneAdapter.find_native_expert_groups()
# 를 통해 expert 모듈을 찾고,
# - (프로젝트 내) LoRALinear 래퍼로 nn.Linear를 교체한다.
# """


# from __future__ import annotations

# import logging
# from dataclasses import dataclass
# from typing import List, Optional, Sequence

# import torch.nn as nn

# from ..adapters.backbones.base import BackboneAdapter, ExpertGroup
# from ..modules.lora import LoRALinear

# logger = logging.getLogger(__name__)


# # -------------------------
# # utils
# # -------------------------


# def _normalize_name(s: str) -> str:
#     return (s or "").replace("_", "").lower()


# def _parse_keywords(keywords: Sequence[str]) -> List[str]:
#     return [_normalize_name(k) for k in keywords if k and str(k).strip()]


# def inject_lora_by_keywords_inplace(
#     module: nn.Module,
#     target_keywords: Sequence[str],
#     r: int,
#     alpha: float,
#     dropout: float,
# ) -> int:
#     """
#     module 아래에서 nn.Linear leaf 중 이름에 keyword가 매칭되는 모듈을 LoRALinear로 교체한다.
#     반환: 교체된 Linear 수
#     """
#     norm_kws = _parse_keywords(target_keywords)
#     replaced = 0

#     for name, child in list(module.named_children()):
#         # 이미 LoRA가 적용된 경우 스킵(구현체가 LoRALinear일 때)
#         if isinstance(child, LoRALinear):
#             continue

#         if isinstance(child, nn.Linear):
#             n = _normalize_name(name)
#             if any(kw in n for kw in norm_kws):
#                 wrapped = LoRALinear(
#                     base_layer=child,
#                     r=int(r),
#                     alpha=float(alpha),
#                     dropout=float(dropout),
#                 )
#                 setattr(module, name, wrapped)
#                 replaced += 1
#                 continue

#         replaced += inject_lora_by_keywords_inplace(
#             child,
#             target_keywords=target_keywords,
#             r=r,
#             alpha=alpha,
#             dropout=dropout,
#         )

#     return replaced


# # -------------------------
# # results
# # -------------------------


# @dataclass
# class NativeMoEInjectionResult:
#     target_layer_indices: List[int]
#     num_expert_groups: int
#     num_experts_total: int
#     num_linears_wrapped: int


# # -------------------------
# # injector
# # -------------------------


# class NativeMoEExpertLoRAInjection:
#     """
#     Native MoE 백본에서 expert-level LoRA를 적용하는 주입기.

#     사용 흐름(중요)
#     1) dense/native 모델 로드
#     2) (필요하면) MoE 구조 변환(A/B), 혹은 native MoE면 그대로
#     3) 이 주입기로 experts 내부에 LoRA 모듈들을 "먼저" 만든다
#     4) 그 후 checkpoint state_dict를 로드해야 LoRA weight가 매칭된다. [file:1]
#     """

#     def apply_expert_lora(
#         self,
#         model: nn.Module,
#         adapter: BackboneAdapter,
#         target_layers: Optional[Sequence[int]],
#         r: int,
#         alpha: float,
#         dropout: float,
#         ffn_keywords: Sequence[str],
#         verbose: bool = True,
#     ) -> NativeMoEInjectionResult:
#         layers = list(adapter.find_transformer_layers(model))
#         num_layers = len(layers)

#         if target_layers is None:
#             layer_indices = list(range(num_layers))
#         else:
#             layer_indices = [int(i) for i in target_layers if 0 <= int(i) < num_layers]
#             layer_indices = sorted(set(layer_indices))

#         total_groups = 0
#         total_experts = 0
#         total_wrapped = 0

#         for li in layer_indices:
#             block = layers[li]
#             groups: List[ExpertGroup] = list(adapter.find_native_expert_groups(block))
#             if not groups:
#                 continue

#             for g in groups:
#                 total_groups += 1
#                 experts = list(g.experts) if g.experts is not None else []
#                 total_experts += len(experts)

#                 group_wrapped = 0
#                 for ex in experts:
#                     # expert FFN 내부 linear들을 키워드 기반으로 LoRA 래핑
#                     group_wrapped += inject_lora_by_keywords_inplace(
#                         ex,
#                         target_keywords=ffn_keywords,
#                         r=r,
#                         alpha=alpha,
#                         dropout=dropout,
#                     )

#                 total_wrapped += group_wrapped

#                 if verbose:
#                     logger.info(
#                         "[NativeMoE] layer=%d group=%s experts=%d wrapped_linears(group)=%d wrapped_linears(total)=%d keywords=%s r=%s alpha=%s dropout=%s",
#                         li,
#                         g.name or "unknown",
#                         len(experts),
#                         group_wrapped,
#                         total_wrapped,
#                         list(ffn_keywords),
#                         r,
#                         alpha,
#                         dropout,
#                     )

#         if verbose:
#             logger.info(
#                 "[NativeMoE] Done. target_layers=%s groups=%d experts=%d wrapped_linears=%d",
#                 layer_indices,
#                 total_groups,
#                 total_experts,
#                 total_wrapped,
#             )

#         return NativeMoEInjectionResult(
#             target_layer_indices=layer_indices,
#             num_expert_groups=total_groups,
#             num_experts_total=total_experts,
#             num_linears_wrapped=total_wrapped,
#         )

# -*- coding: utf-8 -*-
"""
eulerforge.injection.native_moe_expert_lora

C) Native MoE backbone + expert LoRA injection.

- Mixtral 같은 "이미 native MoE"인 백본에서,
  experts 내부 Linear들에 LoRA를 붙인다.
- 추가: Attention Layer (q_proj, v_proj 등)에도 LoRA를 붙일 수 있다.
- 구조를 먼저 만들어둔 뒤 체크포인트를 로드해야 LoRA weight가 매칭된다(재현성 원칙). [file:1]

이 모듈은:
- BackboneAdapter.find_transformer_layers()
- BackboneAdapter.find_native_expert_groups()
- BackboneAdapter.find_attention_leaf_modules()
를 통해 타겟 모듈을 찾고,
- (프로젝트 내) LoRALinear 래퍼로 nn.Linear를 교체한다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

import torch.nn as nn

from ..adapters.backbones.base import BackboneAdapter, ExpertGroup
from ..modules.lora import LoRALinear

logger = logging.getLogger(__name__)


# -------------------------
# utils
# -------------------------


def _normalize_name(s: str) -> str:
    return (s or "").replace("_", "").lower()


def _parse_keywords(keywords: Sequence[str]) -> List[str]:
    return [_normalize_name(k) for k in keywords if k and str(k).strip()]


def inject_lora_by_keywords_inplace(
    module: nn.Module,
    target_keywords: Sequence[str],
    r: int,
    alpha: float,
    dropout: float,
) -> int:
    """
    module 아래에서 nn.Linear leaf 중 이름에 keyword가 매칭되는 모듈을 LoRALinear로 교체한다.
    (주로 Expert 내부 탐색용)
    반환: 교체된 Linear 수
    """
    norm_kws = _parse_keywords(target_keywords)
    replaced = 0

    for name, child in list(module.named_children()):
        # 이미 LoRA가 적용된 경우 스킵
        if isinstance(child, LoRALinear):
            continue

        if isinstance(child, nn.Linear):
            n = _normalize_name(name)
            if any(kw in n for kw in norm_kws):
                wrapped = LoRALinear(
                    base_layer=child,
                    r=int(r),
                    alpha=float(alpha),
                    dropout=float(dropout),
                )
                setattr(module, name, wrapped)
                replaced += 1
                continue

        replaced += inject_lora_by_keywords_inplace(
            child,
            target_keywords=target_keywords,
            r=r,
            alpha=alpha,
            dropout=dropout,
        )

    return replaced


def _replace_module_by_path(
    root: nn.Module, path: str, r: int, alpha: float, dropout: float
) -> bool:
    """
    root 기준 상대 경로(path)에 있는 Linear를 LoRALinear로 교체한다.
    (주로 Attention 모듈 교체용)
    """
    parts = path.split(".")
    parent = root
    for p in parts[:-1]:
        if not hasattr(parent, p):
            return False
        parent = getattr(parent, p)

    target_name = parts[-1]
    if not hasattr(parent, target_name):
        return False

    target = getattr(parent, target_name)
    
    # 이미 래핑되었거나 Linear가 아니면 스킵
    if isinstance(target, LoRALinear):
        return False
    if not isinstance(target, nn.Linear):
        return False

    wrapped = LoRALinear(
        base_layer=target,
        r=int(r),
        alpha=float(alpha),
        dropout=float(dropout),
    )
    setattr(parent, target_name, wrapped)
    return True


# -------------------------
# results
# -------------------------


@dataclass
class NativeMoEInjectionResult:
    target_layer_indices: List[int]
    num_expert_groups: int
    num_experts_total: int
    num_linears_wrapped: int  # Expert FFN wrapped count
    num_attn_wrapped: int     # Attention wrapped count


# -------------------------
# injector
# -------------------------


class NativeMoEExpertLoRAInjection:
    """
    Native MoE 백본에서 expert-level LoRA (+ optional Attention LoRA)를 적용하는 주입기.

    사용 흐름(중요)
    1) dense/native 모델 로드
    2) (필요하면) MoE 구조 변환(A/B), 혹은 native MoE면 그대로
    3) 이 주입기로 experts 내부에 LoRA 모듈들을 "먼저" 만든다
    4) 그 후 checkpoint state_dict를 로드해야 LoRA weight가 매칭된다. [file:1]
    """

    def apply_expert_lora(
        self,
        model: nn.Module,
        adapter: BackboneAdapter,
        target_layers: Optional[Sequence[int]],
        r: int,
        alpha: float,
        dropout: float,
        ffn_keywords: Sequence[str],
        attn_lora_cfg: Optional[Dict[str, Any]] = None,
        verbose: bool = True,
    ) -> NativeMoEInjectionResult:
        layers = list(adapter.find_transformer_layers(model))
        num_layers = len(layers)

        if target_layers is None:
            layer_indices = list(range(num_layers))
        else:
            layer_indices = [int(i) for i in target_layers if 0 <= int(i) < num_layers]
            layer_indices = sorted(set(layer_indices))

        # Attn LoRA 설정 파싱
        attn_enabled = False
        attn_keywords = []
        if attn_lora_cfg:
            attn_enabled = bool(attn_lora_cfg.get("enabled", False))
            attn_keywords = attn_lora_cfg.get("keywords", [])

        total_groups = 0
        total_experts = 0
        total_ffn_wrapped = 0
        total_attn_wrapped = 0

        for li in layer_indices:
            block = layers[li]
            
            # 1. Native Expert LoRA Injection
            groups: List[ExpertGroup] = list(adapter.find_native_expert_groups(block))
            if groups:
                for g in groups:
                    total_groups += 1
                    experts = list(g.experts) if g.experts is not None else []
                    total_experts += len(experts)

                    group_wrapped = 0
                    for ex in experts:
                        # expert FFN 내부 linear들을 키워드 기반으로 LoRA 래핑
                        group_wrapped += inject_lora_by_keywords_inplace(
                            ex,
                            target_keywords=ffn_keywords,
                            r=r,
                            alpha=alpha,
                            dropout=dropout,
                        )
                    total_ffn_wrapped += group_wrapped

            # 2. Attention LoRA Injection
            layer_attn_wrapped = 0
            if attn_enabled and attn_keywords:
                # Adapter를 통해 타겟 Attention 모듈 경로(예: self_attn.q_proj) 획득
                leaf_paths = adapter.find_attention_leaf_modules(block, attn_keywords)
                for path in leaf_paths:
                    success = _replace_module_by_path(block, path, r, alpha, dropout)
                    if success:
                        layer_attn_wrapped += 1
                total_attn_wrapped += layer_attn_wrapped

            if verbose:
                logger.info(
                    "[NativeMoE] layer=%d groups=%d experts=%d ffn_wrapped=%d attn_wrapped=%d",
                    li,
                    len(groups),
                    sum(len(g.experts or []) for g in groups),
                    sum(
                        inject_lora_by_keywords_inplace(ex, ffn_keywords, r, alpha, dropout) 
                        for g in groups for ex in (g.experts or [])
                    ) if False else 0, # Logging logic simplified above, actual count is cumulative
                    layer_attn_wrapped,
                )

        if verbose:
            logger.info(
                "[NativeMoE] Done. target_layers=%s groups=%d experts=%d ffn_wrapped=%d attn_wrapped=%d",
                layer_indices,
                total_groups,
                total_experts,
                total_ffn_wrapped,
                total_attn_wrapped,
            )

        return NativeMoEInjectionResult(
            target_layer_indices=layer_indices,
            num_expert_groups=total_groups,
            num_experts_total=total_experts,
            num_linears_wrapped=total_ffn_wrapped,
            num_attn_wrapped=total_attn_wrapped,
        )