# eulerforge/injection/dense_moe_expert_lora.py
# -*- coding: utf-8 -*-
"""
eulerforge.injection.dense_moe_expert_lora

Dense 백본(Qwen 등)에 MoE를 "만들어서" 붙이고, LoRA까지 주입하는 인젝터.

지원 모드
A) moe_expert_lora:
   - 선택한 Transformer layer의 FFN을 MoEFFN(FFN 복제 + router)으로 교체
   - 각 expert FFN 내부 Linear들에 LoRA 삽입

B) ffn_mixture_lora:
   - FFN은 그대로 유지
   - FFN의 Linear들을 Mixture-of-LoRAs(라우팅 + 여러 LoRA)로 치환

공통 기능:
- attn_lora: Attention Layer (q_proj, k_proj 등)에 일반 LoRA 적용 가능 (옵션)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

import torch.nn as nn

from ..adapters.backbones.base import BackboneAdapter
from ..modules.lora import LoRALinear
from ..modules.mixture_lora import build_mixture_lora_for_ffn_layers, MixtureLoRALinear
from ..modules.moe import MoEFFN, replace_ffn_with_moe_inplace

logger = logging.getLogger(__name__)


# -------------------------
# utils
# -------------------------


def _parse_layer_indices(
    num_layers: int,
    explicit_indices: Optional[Sequence[int]] = None,
    start_layer: int = 0,
    num_moe_layers: int = 0,
    stride: int = 1,
) -> List[int]:
    if explicit_indices is not None:
        idxs = [int(i) for i in explicit_indices]
    else:
        if num_moe_layers <= 0:
            # num_moe_layers가 0 이하이면 start_layer부터 끝까지로 간주
            num_selected = num_layers - start_layer
        else:
            num_selected = num_moe_layers
            
        idxs = list(range(int(start_layer), int(start_layer) + int(num_selected) * int(stride), int(stride)))

    idxs = [i for i in idxs if 0 <= i < num_layers]
    if not idxs:
        # 경고만 하고 빈 리스트 반환 (Attention LoRA만 할 수도 있으므로)
        # raise ValueError("No valid target layer indices selected.") 대신 빈 리스트 반환이 유연함
        return []
    return sorted(set(idxs))


def _normalize_name(s: str) -> str:
    # "gate_proj" / "gateproj" 둘 다 매칭되게
    return (s or "").replace("_", "").lower()


def _inject_lora_by_keywords_inplace(
    module: nn.Module,
    target_keywords: Sequence[str],
    r: int,
    alpha: float,
    dropout: float,
    *,
    skip_if_wrapped: bool = True,
    exclude_types: tuple = (),
) -> int:
    """
    module 하위 트리를 순회하면서, 이름(name)에 target_keywords가 매칭되는 nn.Linear를
    LoRALinear로 교체한다.

    반환: 교체된 Linear 개수

    주의:
    - 이미 LoRALinear인 경우는 기본적으로 스킵한다(skip_if_wrapped=True).
    - exclude_types에 해당하는 모듈 내부는 탐색/교체하지 않는다.
    """
    kws = [_normalize_name(k) for k in target_keywords if k and str(k).strip()]
    if not kws:
        return 0

    replaced = 0

    # named_children()을 리스트로 변환하여 순회 중 수정에 안전하게 함
    for child_name, child in list(module.named_children()):
        # 제외할 타입 패스 (예: MoEFFN 내부, MixtureLoRA 등)
        if exclude_types and isinstance(child, exclude_types):
            continue

        # 이미 LoRA면 중복 방지
        if isinstance(child, (LoRALinear, MixtureLoRALinear)):
            if skip_if_wrapped:
                continue
            continue

        # leaf Linear면 교체 여부 판단
        if isinstance(child, nn.Linear):
            n = _normalize_name(child_name)
            if any(kw in n for kw in kws):
                setattr(
                    module,
                    child_name,
                    LoRALinear(
                        base_layer=child,
                        r=int(r),
                        alpha=float(alpha),
                        dropout=float(dropout),
                    ),
                )
                replaced += 1
                continue

        # 재귀
        replaced += _inject_lora_by_keywords_inplace(
            child,
            target_keywords=target_keywords,
            r=int(r),
            alpha=float(alpha),
            dropout=float(dropout),
            skip_if_wrapped=skip_if_wrapped,
            exclude_types=exclude_types,
        )

    return replaced


def _apply_lora_to_moe_experts(
    model: nn.Module,
    adapter: BackboneAdapter,
    layer_indices: Sequence[int],
    target_keywords: Sequence[str],
    r: int,
    alpha: float,
    dropout: float,
    *,
    verbose: bool = False,
) -> int:
    """
    이미 MoEFFN으로 교체된 layer들에 대해,
    MoEFFN.experts[*] (복제된 FFN) 내부의 Linear들을 keyword 매칭으로 LoRALinear로 감싼다.

    반환: 생성/교체된 LoRALinear(=원래 nn.Linear를 감싼 수) 총합
    """
    if r <= 0:
        return 0

    if not target_keywords or not any(str(k).strip() for k in target_keywords):
        # raise ValueError 대신 0 반환이 더 안전할 수 있음 (FFN LoRA 안하고 Attn LoRA만 할 수도 있으니)
        return 0

    layers = list(adapter.find_transformer_layers(model))
    total_replaced = 0

    for li in layer_indices:
        li_int = int(li)
        if li_int < 0 or li_int >= len(layers):
            continue # Skip invalid index

        block = layers[li_int]
        ffn_name = adapter.find_ffn_attr_name(block)
        ffn = getattr(block, ffn_name, None)
        
        # MoEFFN인지 확인 (아니면 스킵)
        if ffn is None or not isinstance(ffn, MoEFFN):
            continue

        if not hasattr(ffn, "experts") or not isinstance(ffn.experts, nn.ModuleList):
            continue

        layer_replaced = 0
        for e, expert_ffn in enumerate(ffn.experts):
            n = _inject_lora_by_keywords_inplace(
                expert_ffn,
                target_keywords=target_keywords,
                r=int(r),
                alpha=float(alpha),
                dropout=float(dropout),
                skip_if_wrapped=True,
            )
            layer_replaced += int(n)

            if verbose and n > 0:
                # 너무 시끄러우면 debug 레벨로 내리거나 첫 expert만 출력
                if e == 0: 
                    logger.info(
                        "[DenseMoE] LoRA injected: layer=%d expert=0..%d keywords=%s",
                        li_int, len(ffn.experts)-1, list(target_keywords),
                    )

        total_replaced += layer_replaced

    return int(total_replaced)


# -------------------------
# results
# -------------------------


@dataclass
class DenseMoEInjectionResult:
    mode: str
    target_layer_indices: List[int]
    num_experts: int
    top_k: int
    num_ffn_replaced: int
    num_lora_modules_created: int
    num_attn_modules_created: int


# -------------------------
# main injector
# -------------------------


class DenseMoEExpertLoRAInjection:
    """
    Dense 백본에 대해:
    - FFN MoE(FFN 복제) + expert LoRA
    - Mixture-of-LoRAs
    을 구성하는 인젝터.
    + Attention LoRA 옵션 지원.
    """

    MODE_MOE_EXPERT_LORA = "moe_expert_lora"
    MODE_FFN_MIXTURE_LORA = "ffn_mixture_lora"

    def apply(
        self,
        model: nn.Module,
        adapter: BackboneAdapter,
        mode: str,
        # Config params
        injection_cfg: Dict[str, Any],
        # MoE placement
        moe_layer_indices: Optional[Sequence[int]] = None,
        moe_start_layer: int = 0,
        moe_num_layers: int = 0,
        moe_layer_stride: int = 1,
        # MoE shape
        num_experts: int = 4,
        top_k: int = 2,
        # LoRA config (FFN expert용)
        lora_r: int = 16,
        lora_alpha: float = 32.0,
        lora_dropout: float = 0.05,
        ffn_target_keywords: Sequence[str] = ("w1", "w2", "gate_proj", "up_proj", "down_proj"),
        aux_loss_coeff: float = 0.0,
        verbose: bool = True,
        # hidden size is needed by MoEFFN router
        hidden_size: Optional[int] = None,
        # Attn LoRA config (옵션)
        attn_lora_cfg: Optional[Dict[str, Any]] = None,
    ) -> DenseMoEInjectionResult:
        if mode not in (self.MODE_MOE_EXPERT_LORA, self.MODE_FFN_MIXTURE_LORA):
            raise ValueError(f"Unknown mode: {mode}")

        layers = list(adapter.find_transformer_layers(model))
        num_layers = len(layers)
        
        # FFN MoE 타겟 레이어 선정
        target_indices = _parse_layer_indices(
            num_layers=num_layers,
            explicit_indices=moe_layer_indices,
            start_layer=moe_start_layer,
            num_moe_layers=moe_num_layers,
            stride=moe_layer_stride,
        )
        # [디버깅 포인트]
        # target_indices가 비어있지 않은지 확인
        if verbose:
            logger.info(f"[DenseMoE] Target indices for MoE: {target_indices}")

        # MoEFFN router input size
        if hidden_size is None:
            cfg = getattr(model, "config", None)
            hs = getattr(cfg, "hidden_size", None)
            # Gemma 3 4B+ (multimodal wrapper)는 top-level config에 hidden_size가 없고
            # text_config.hidden_size에 있다.
            if hs is None and cfg is not None:
                text_cfg = getattr(cfg, "text_config", None)
                hs = getattr(text_cfg, "hidden_size", None)
            if hs is None:
                if verbose:
                    logger.warning("hidden_size not found in config, using 4096 as fallback.")
                hidden_size = 4096
            else:
                hidden_size = int(hs)

        num_ffn_replaced = 0
        num_lora_created = 0

        # ---------------------------------------------------------
        # 1. FFN 변환 (MoE or MixtureLoRA)
        # ---------------------------------------------------------
        if mode == self.MODE_MOE_EXPERT_LORA:
            if verbose:
                logger.info(
                    "[DenseMoE] Building FFN-MoE (FFN clone, native) on layers=%s num_experts=%d top_k=%d",
                    target_indices, num_experts, top_k
                )

            # 1) FFN -> MoEFFN 교체
            built_indices = replace_ffn_with_moe_inplace(
                model=model,
                adapter=adapter,
                layer_indices=target_indices,
                hidden_size=int(hidden_size),
                num_experts=int(num_experts),
                top_k=int(top_k),
                aux_loss_coeff=float(aux_loss_coeff),
                verbose=bool(verbose),
            )
            target_indices = list(built_indices) # 실제로 바뀐 인덱스로 업데이트
            num_ffn_replaced = len(target_indices)

            # 2) 각 expert FFN 내부 Linear들에 LoRA 주입
            if lora_r > 0:
                if verbose:
                    logger.info(
                        "[DenseMoE] Applying expert-level LoRA (native) to MoE layers. r=%d alpha=%s",
                        lora_r, lora_alpha
                    )
                num_lora_created = _apply_lora_to_moe_experts(
                    model=model,
                    adapter=adapter,
                    layer_indices=target_indices,
                    target_keywords=ffn_target_keywords,
                    r=int(lora_r),
                    alpha=float(lora_alpha),
                    dropout=float(lora_dropout),
                    verbose=bool(verbose),
                )
            else:
                num_lora_created = 0
                if verbose:
                    logger.info("[DenseMoE] LoRA disabled (r <= 0).")

        else:
            # ffn_mixture_lora (Mixture-of-LoRAs)
            if verbose:
                logger.info(
                    "[DenseMoE] Building Mixture-of-LoRAs (native) on layers=%s num_experts=%d top_k=%d r=%d",
                    target_indices, num_experts, top_k, lora_r
                )

            _, built_indices, wrapped_linears = build_mixture_lora_for_ffn_layers(
                model=model,
                adapter=adapter,
                layer_indices=target_indices,
                num_experts=int(num_experts),
                top_k=int(top_k),
                r=int(lora_r),
                alpha=float(lora_alpha),
                dropout=float(lora_dropout),
                target_submodule_keywords=list(ffn_target_keywords) if ffn_target_keywords else (
                    "w1", "w2", "gate_proj", "up_proj", "down_proj"
                ),
                router_temperature=1.0,
                aux_loss_coeff=float(aux_loss_coeff),
            )

            target_indices = list(built_indices)
            num_ffn_replaced = 0
            num_lora_created = int(wrapped_linears)

            if verbose:
                logger.info(
                    "[DenseMoE] ffn_mixture_lora done. layers=%s wrapped_linears=%d num_experts=%d top_k=%d",
                    target_indices, wrapped_linears, num_experts, top_k
                )

        # ---------------------------------------------------------
        # 2. Attention LoRA Injection (공통)
        # ---------------------------------------------------------
        num_attn_created = 0
        if attn_lora_cfg and attn_lora_cfg.get("enabled", False):
            attn_keywords_user = attn_lora_cfg.get("keywords", ["q_proj", "k_proj", "v_proj", "o_proj"])

            # FFN과 동일한 layer_indices에 적용 (일관성 유지)
            attn_targets = target_indices
            if not attn_targets and moe_num_layers <= 0:
                 pass

            if verbose:
                logger.info(f"[DenseMoE] Applying Attention LoRA... Keywords={attn_keywords_user} Layers={attn_targets}")

            for li in attn_targets:
                li_int = int(li)
                if li_int < 0 or li_int >= len(layers):
                    continue

                block = layers[li_int]

                # Backbone-specific 키워드 변환 (Qwen3.5 linear_attn fallback 등)
                attn_keywords = adapter.translate_attn_keywords(block, attn_keywords_user)

                n = _inject_lora_by_keywords_inplace(
                    block,
                    target_keywords=attn_keywords,
                    r=int(lora_r), # Attn도 같은 rank 사용 (필요시 config 분리 가능)
                    alpha=float(lora_alpha),
                    dropout=float(lora_dropout),
                    skip_if_wrapped=True,
                    exclude_types=(MoEFFN, MixtureLoRALinear),
                )
                num_attn_created += int(n)

            if verbose:
                logger.info(f"[DenseMoE] Attention LoRA Injection complete. Replaced {num_attn_created} linear modules.")

        return DenseMoEInjectionResult(
            mode=mode,
            target_layer_indices=target_indices,
            num_experts=int(num_experts),
            top_k=int(top_k),
            num_ffn_replaced=int(num_ffn_replaced),
            num_lora_modules_created=int(num_lora_created),
            num_attn_modules_created=int(num_attn_created),
        )