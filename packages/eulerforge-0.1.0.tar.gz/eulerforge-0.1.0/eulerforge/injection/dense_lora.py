# eulerforge/injection/dense_lora.py
# -*- coding: utf-8 -*-
"""
eulerforge.injection.dense_lora

Dense 백본에 대해 "LoRA만" 또는 "LoRA로 MoE를 흉내" 내는 인젝터.

지원 모드
1) dense_lora:
   - 특정 keyword(qproj/kproj/... 또는 w1/w2/...)에 매칭되는 nn.Linear들을 LoRALinear로 교체.
   - 즉, 일반 LoRA.

2) mixture_lora (Mixture-of-LoRAs):
   - FFN은 그대로 두고, FFN 내부 Linear들을 Mixture-of-LoRAs로 치환하여
     "여러 LoRA adapter"를 라우팅(top-k)으로 섞는다.

3) moe_expert_lora:
   - FFN을 복제하여 MoEFFN(experts + router)을 만든 뒤,
   - 각 expert FFN 내부 Linear에 LoRA를 삽입한다. (별도 모듈에서 처리)

주의
- Attention LoRA (attn_lora) 기능이 추가되어, FFN 변환과 별개로 Attention Layer에도 LoRA를 적용할 수 있습니다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

import torch.nn as nn

from ..adapters.backbones.base import BackboneAdapter
from ..modules.lora import LoRALinear
from ..modules.mixture_lora import MixtureLoRALinear, build_mixture_lora_for_ffn_layers

logger = logging.getLogger(__name__)


# -------------------------
# utils
# -------------------------


def _normalize_name(s: str) -> str:
    return (s or "").replace("_", "").lower()


def _parse_keywords(keywords: Sequence[str]) -> List[str]:
    return [_normalize_name(k) for k in keywords if k and str(k).strip()]


def inject_lora_inplace(
    module: nn.Module,
    target_keywords: Sequence[str],
    r: int,
    alpha: float,
    dropout: float,
    exclude_types: tuple = (),
) -> int:
    """
    하위 모듈을 순회하면서 이름에 keyword가 매칭되는 nn.Linear를 LoRALinear로 교체한다.
    이미 LoRA/MixtureLoRA로 교체된 모듈이나 exclude_types에 해당하는 모듈은 건너뛴다.
    
    반환: 교체된 Linear 수
    """
    norm_kws = _parse_keywords(target_keywords)
    replaced = 0

    # named_children()을 리스트로 변환하여 순회 중 수정에 안전하게 함
    for name, child in list(module.named_children()):
        # 이미 변환된 모듈은 패스
        if isinstance(child, (LoRALinear, MixtureLoRALinear)):
            continue
        
        # 제외할 타입 패스 (예: MoEFFN 내부 등)
        if exclude_types and isinstance(child, exclude_types):
            continue

        if isinstance(child, nn.Linear):
            n = _normalize_name(name)
            if any(kw in n for kw in norm_kws):
                setattr(
                    module,
                    name,
                    LoRALinear(base_layer=child, r=int(r), alpha=float(alpha), dropout=float(dropout)),
                )
                replaced += 1
                continue
        
        # 재귀 호출
        replaced += inject_lora_inplace(child, target_keywords, r, alpha, dropout, exclude_types)

    return replaced


def _parse_layer_indices(
    num_layers: int,
    explicit_indices: Optional[Sequence[int]],
    start_layer: int,
    num_selected: int,
    stride: int,
) -> List[int]:
    if explicit_indices is not None:
        idxs = [int(i) for i in explicit_indices]
    else:
        if num_selected <= 0:
            # num_selected가 0 이하이면 start_layer부터 끝까지
            num_selected = num_layers - start_layer
        idxs = list(range(int(start_layer), int(start_layer) + int(num_selected) * int(stride), int(stride)))

    idxs = [i for i in idxs if 0 <= i < num_layers]
    if not idxs:
        # 경고만 하고 빈 리스트 반환 (Attention LoRA만 할 수도 있으므로)
        return []
    return sorted(set(idxs))


# -------------------------
# results
# -------------------------


@dataclass
class DenseLoRAInjectionResult:
    mode: str
    target_layer_indices: List[int]
    num_linears_wrapped: int  # FFN Wrapped count
    num_attn_wrapped: int     # Attn Wrapped count
    # for mixture_lora / moe_expert_lora
    num_experts: int
    top_k: int


# -------------------------
# injector
# -------------------------
class DenseLoRAInjection:
    """
    Dense 모델에 대해:
    - dense_lora: Dense FFN/Linear에 단일 LoRA를 삽입
    - mixture_lora:   FFN Linear들을 Mixture-of-LoRAs로 치환

    + 옵션으로 Attention Layer (q_proj, k_proj, ...)에 LoRA 적용 (attn_lora)
    """

    MODE_DENSE_LORA = "dense_lora"
    MODE_MIXTURE_LORA = "mixture_lora"

    def apply(
        self,
        model: nn.Module,
        adapter: BackboneAdapter,
        mode: str,
        # targeting
        layer_indices: Optional[Sequence[int]] = None,
        start_layer: int = 0,
        num_layers: int = 0,
        stride: int = 1,
        # lora (common for FFN & Attn if explicit config not overrides)
        r: int = 16,
        alpha: float = 32.0,
        dropout: float = 0.05,
        target_keywords: Sequence[str] = ("w1", "w2", "gate_proj", "up_proj", "down_proj"),
        # mixture_lora specific
        num_experts: int = 4,
        top_k: int = 2,
        # attn_lora config
        attn_lora_cfg: Optional[Dict[str, Any]] = None,
        # kept for backward-compat but not used here
        hidden_size: Optional[int] = None,
        verbose: bool = True,
    ) -> DenseLoRAInjectionResult:
        if mode not in (self.MODE_DENSE_LORA, self.MODE_MIXTURE_LORA):
            raise ValueError(f"Unknown mode: {mode}")

        # [DEBUG] Check attn_lora_cfg reception
        if verbose:
            logger.info(f"[DenseLoRA] Received attn_lora_cfg: {attn_lora_cfg}")

        layers = list(adapter.find_transformer_layers(model))
        total_layers = len(layers)
        
        selected = _parse_layer_indices(
            num_layers=total_layers,
            explicit_indices=layer_indices,
            start_layer=start_layer,
            num_selected=num_layers,
            stride=stride,
        )

        ffn_wrapped = 0
        attn_wrapped = 0

        # ---------------------------------------------------------
        # 1. FFN Injection
        # ---------------------------------------------------------
        if mode == self.MODE_DENSE_LORA:
            if selected:
                for li in selected:
                    block = layers[int(li)]
                    ffn_wrapped += inject_lora_inplace(
                        block,
                        target_keywords=target_keywords,
                        r=int(r),
                        alpha=float(alpha),
                        dropout=float(dropout),
                    )
                if verbose:
                    logger.info(
                        "[DenseLoRA] dense_lora FFN done. layers=%s wrapped_linears=%d r=%d alpha=%s dropout=%s keywords=%s",
                        selected, ffn_wrapped, r, alpha, dropout, list(target_keywords)
                    )

        elif mode == self.MODE_MIXTURE_LORA:
            if selected:
                if verbose:
                    logger.info(
                        "[DenseLoRA] Building mixture_lora (Mixture-of-LoRAs, native). layers=%s num_experts=%d top_k=%d r=%d",
                        selected, num_experts, top_k, r
                    )

                _, built_indices, wrapped_linears = build_mixture_lora_for_ffn_layers(
                    model=model,
                    adapter=adapter,
                    layer_indices=selected,
                    num_experts=int(num_experts),
                    top_k=int(top_k),
                    r=int(r),
                    alpha=float(alpha),
                    dropout=float(dropout),
                    target_submodule_keywords=list(target_keywords) if target_keywords else (
                        "w1", "w2", "gate_proj", "up_proj", "down_proj"
                    ),
                    router_temperature=1.0,
                    aux_loss_coeff=0.0,  # 필요시 학습 루프에서 MixtureLoRALinear.last_aux_loss를 합산
                )
                ffn_wrapped = wrapped_linears
                
                if verbose:
                    logger.info(
                        "[DenseLoRA] mixture_lora done. layers=%s wrapped_linears=%d num_experts=%d top_k=%d",
                        built_indices, ffn_wrapped, num_experts, top_k
                    )

        # ---------------------------------------------------------
        # 2. Attention LoRA Injection
        # ---------------------------------------------------------
        if attn_lora_cfg and attn_lora_cfg.get("enabled", False):
            attn_keywords_user = attn_lora_cfg.get("keywords", ["q_proj", "k_proj", "v_proj", "o_proj"])

            # FFN과 동일한 layer_indices에 적용 (일관성 유지)
            attn_targets = selected

            if verbose:
                logger.info(f"[DenseLoRA] Applying Attention LoRA... Keywords={attn_keywords_user} Layers={attn_targets}")

            for li in attn_targets:
                block = layers[int(li)]
                # Backbone-specific 키워드 변환 (예: Qwen3.5 linear_attn fallback).
                # 기본은 키워드 그대로 반환. Qwen3Adapter는 q/k/v/o_proj를
                # in_proj_qkv/out_proj로 자동 변환.
                attn_keywords = adapter.translate_attn_keywords(block, attn_keywords_user)
                # MixtureLoRALinear는 이미 위에서 변환되었으므로 exclude_types에 포함하여 중복 방지
                attn_wrapped += inject_lora_inplace(
                    block,
                    target_keywords=attn_keywords,
                    r=int(r),
                    alpha=float(alpha),
                    dropout=float(dropout),
                    exclude_types=(MixtureLoRALinear,)
                )

            if verbose:
                logger.info(f"[DenseLoRA] Attention LoRA done. wrapped_linears={attn_wrapped}")

        return DenseLoRAInjectionResult(
            mode=mode,
            target_layer_indices=selected,
            num_linears_wrapped=int(ffn_wrapped),
            num_attn_wrapped=int(attn_wrapped),
            num_experts=int(num_experts) if mode == self.MODE_MIXTURE_LORA else 0,
            top_k=int(top_k) if mode == self.MODE_MIXTURE_LORA else 0,
        )