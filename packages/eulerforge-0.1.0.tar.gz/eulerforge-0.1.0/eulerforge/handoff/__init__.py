# eulerforge/handoff/__init__.py
"""LoRA Handoff Scheduling — gradual LoRA fade for knowledge transfer."""
