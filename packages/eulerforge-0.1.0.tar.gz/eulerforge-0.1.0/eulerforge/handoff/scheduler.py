# eulerforge/handoff/scheduler.py
# -*- coding: utf-8 -*-
"""
LoRA Handoff Scheduler.

Gradually reduces LoRA delta influence (scale 1.0 → end_scale) over a
configurable step range, independently for expert_lora and attn_lora.

See docs/fixtures/specs/lora_handoff_spec.md for the full specification.
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import torch.nn as nn

logger = logging.getLogger(__name__)

# Attention path keywords (matches groups.py _ATTN_KEYWORDS)
_ATTN_KEYWORDS = ("q_proj", "k_proj", "v_proj", "o_proj")


# ---------------------------------------------------------------------------
# Pure math helpers
# ---------------------------------------------------------------------------

def compute_fade_pct(
    step: int,
    start_step: int,
    duration_steps: int,
    curve: str = "linear",
) -> float:
    """Compute fade percentage [0, 100] for a given step."""
    if step < start_step:
        return 0.0
    if step >= start_step + duration_steps:
        return 100.0
    progress = (step - start_step) / float(duration_steps)
    if curve == "cosine":
        return (1.0 - math.cos(math.pi * progress)) / 2.0 * 100.0
    # linear (default)
    return progress * 100.0


def compute_lora_scale(fade_pct: float, end_scale: float = 0.0) -> float:
    """Convert fade_pct [0,100] to lora_scale [end_scale, 1.0]."""
    return 1.0 - (fade_pct / 100.0) * (1.0 - end_scale)


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class HandoffStepResult:
    expert_lora_scale: Optional[float]
    attn_lora_scale: Optional[float]
    expert_lora_frozen: bool
    attn_lora_frozen: bool
    base_ffn_lr_multiplier: float
    needs_optimizer_rebuild: bool


# ---------------------------------------------------------------------------
# Module discovery
# ---------------------------------------------------------------------------

def _is_attn_path(name: str) -> bool:
    ln = name.lower()
    return any(kw in ln for kw in _ATTN_KEYWORDS)


def _find_lora_modules(model: nn.Module, group: str) -> List[nn.Module]:
    """Find LoRALinear or MixtureLoRALinear modules matching the group.

    group='expert_lora' → non-attention LoRA modules
    group='attn_lora'   → attention LoRA modules
    """
    from eulerforge.modules.lora import LoRALinear
    from eulerforge.modules.mixture_lora import MixtureLoRALinear

    results = []
    for name, mod in model.named_modules():
        if isinstance(mod, (LoRALinear, MixtureLoRALinear)):
            is_attn = _is_attn_path(name)
            if group == "attn_lora" and is_attn:
                results.append(mod)
            elif group == "expert_lora" and not is_attn:
                results.append(mod)
    return results


# ---------------------------------------------------------------------------
# Export helpers
# ---------------------------------------------------------------------------

def remove_zero_scale_adapters(model: nn.Module) -> int:
    """Replace LoRALinear modules with scale=0 by their base_layer.

    Returns the number of modules removed.
    """
    from eulerforge.modules.lora import LoRALinear
    from eulerforge.modules.mixture_lora import MixtureLoRALinear

    removed = 0
    for parent_name, parent_mod in list(model.named_modules()):
        for child_name, child_mod in list(parent_mod.named_children()):
            if isinstance(child_mod, LoRALinear) and getattr(child_mod, "lora_scale", 1.0) == 0.0:
                setattr(parent_mod, child_name, child_mod.base_layer)
                removed += 1
            elif isinstance(child_mod, MixtureLoRALinear) and getattr(child_mod, "lora_scale", 1.0) == 0.0:
                setattr(parent_mod, child_name, child_mod.base_layer)
                removed += 1
    return removed


def merge_adapters_into_base(model: nn.Module) -> int:
    """Merge LoRA deltas into base weights and replace with plain Linear.

    Returns the number of modules merged.
    """
    import torch
    from eulerforge.modules.lora import LoRALinear

    merged = 0
    for parent_name, parent_mod in list(model.named_modules()):
        for child_name, child_mod in list(parent_mod.named_children()):
            if isinstance(child_mod, LoRALinear) and child_mod.r > 0:
                # Compute merged weight: W' = W + scaling * lora_scale * (B @ A)
                with torch.no_grad():
                    scale = getattr(child_mod, "lora_scale", 1.0)
                    delta = child_mod.lora_B @ child_mod.lora_A  # (out, r) @ (r, in) = (out, in)
                    merged_weight = child_mod.base_layer.weight.data + delta * child_mod.scaling * scale

                new_linear = nn.Linear(
                    child_mod.in_features,
                    child_mod.out_features,
                    bias=child_mod.base_layer.bias is not None,
                    device=merged_weight.device,
                    dtype=merged_weight.dtype,
                )
                new_linear.weight.data.copy_(merged_weight)
                if child_mod.base_layer.bias is not None:
                    new_linear.bias.data.copy_(child_mod.base_layer.bias.data)
                setattr(parent_mod, child_name, new_linear)
                merged += 1
    return merged


# ---------------------------------------------------------------------------
# Main scheduler
# ---------------------------------------------------------------------------

class LoraHandoffScheduler:
    """Schedules gradual LoRA fade and base_ffn LR ramp during training."""

    def __init__(self, handoff_cfg: Dict[str, Any]) -> None:
        self._cfg = handoff_cfg
        self._expert_cfg = handoff_cfg.get("expert_lora")
        self._attn_cfg = handoff_cfg.get("attn_lora")
        self._ramp_cfg = handoff_cfg.get("base_ffn_ramp")
        self._export_cfg = handoff_cfg.get("export", {})

        # Track whether freeze has already been applied (one-shot)
        self._expert_frozen = False
        self._attn_frozen = False

        # Milestone tracking (one-shot logging)
        self._expert_fade_started = False
        self._expert_fade_completed = False
        self._attn_fade_started = False
        self._attn_fade_completed = False
        self._ramp_started = False
        self._ramp_ended = False

        # Log init summary
        self._log_init_summary()

    def _log_init_summary(self) -> None:
        """Log handoff schedule summary at initialization."""
        parts = []
        if self._expert_cfg:
            start = self._expert_cfg["start_step"]
            dur = self._expert_cfg["duration_steps"]
            curve = self._expert_cfg.get("curve", "linear")
            end_scale = self._expert_cfg.get("end_scale", 0.0)
            end_action = self._expert_cfg.get("end_action", "keep")
            parts.append(
                f"expert_lora(step {start}→{start + dur}, "
                f"curve={curve}, end_scale={end_scale}, end_action={end_action})"
            )
        if self._attn_cfg:
            start = self._attn_cfg["start_step"]
            dur = self._attn_cfg["duration_steps"]
            curve = self._attn_cfg.get("curve", "linear")
            end_scale = self._attn_cfg.get("end_scale", 0.0)
            end_action = self._attn_cfg.get("end_action", "keep")
            parts.append(
                f"attn_lora(step {start}→{start + dur}, "
                f"curve={curve}, end_scale={end_scale}, end_action={end_action})"
            )
        if self._ramp_cfg:
            start = self._ramp_cfg.get("start_step", 0)
            end = self._ramp_cfg.get("end_step", 0)
            sm = self._ramp_cfg.get("start_multiplier", 1.0)
            em = self._ramp_cfg.get("end_multiplier", 1.0)
            parts.append(f"base_ffn_ramp(step {start}→{end}, LR ×{sm}→×{em})")
        if parts:
            logger.info("[Handoff] Schedule: %s", ", ".join(parts))

    def _compute_schedule(
        self, cfg: Optional[Dict], step: int
    ) -> tuple:
        """Returns (lora_scale, fade_complete, should_freeze_now)."""
        if cfg is None:
            return None, False, False

        start = int(cfg["start_step"])
        dur = int(cfg["duration_steps"])
        end_scale = float(cfg.get("end_scale", 0.0))
        curve = str(cfg.get("curve", "linear"))
        end_action = str(cfg.get("end_action", "keep"))

        fade_pct = compute_fade_pct(step, start, dur, curve)
        scale = compute_lora_scale(fade_pct, end_scale)
        fade_complete = (step >= start + dur)
        should_freeze = fade_complete and end_action == "freeze"

        return scale, fade_complete, should_freeze

    def step(self, model: nn.Module, micro_step: int) -> HandoffStepResult:
        """Apply handoff schedule at this step. Returns result with actions taken."""
        expert_scale, expert_done, expert_freeze = self._compute_schedule(
            self._expert_cfg, micro_step
        )
        attn_scale, attn_done, attn_freeze = self._compute_schedule(
            self._attn_cfg, micro_step
        )

        # Milestone: fade start (one-shot, at start_step)
        if self._expert_cfg and not self._expert_fade_started:
            if micro_step >= int(self._expert_cfg["start_step"]):
                self._expert_fade_started = True
                cfg = self._expert_cfg
                logger.info(
                    "[Handoff] expert_lora fade 시작 at step %d "
                    "(curve=%s, end_scale=%.2f, duration=%d steps)",
                    micro_step, cfg.get("curve", "linear"),
                    cfg.get("end_scale", 0.0), cfg["duration_steps"],
                )
        if self._attn_cfg and not self._attn_fade_started:
            if micro_step >= int(self._attn_cfg["start_step"]):
                self._attn_fade_started = True
                cfg = self._attn_cfg
                logger.info(
                    "[Handoff] attn_lora fade 시작 at step %d "
                    "(curve=%s, end_scale=%.2f, duration=%d steps)",
                    micro_step, cfg.get("curve", "linear"),
                    cfg.get("end_scale", 0.0), cfg["duration_steps"],
                )

        # Milestone: fade complete (one-shot)
        if expert_done and not self._expert_fade_completed:
            self._expert_fade_completed = True
            logger.info(
                "[Handoff] expert_lora fade 완료 at step %d (scale=%.4f)",
                micro_step, expert_scale or 0.0,
            )
        if attn_done and not self._attn_fade_completed:
            self._attn_fade_completed = True
            logger.info(
                "[Handoff] attn_lora fade 완료 at step %d (scale=%.4f)",
                micro_step, attn_scale or 0.0,
            )

        # Milestone: base_ffn_ramp (one-shot)
        if self._ramp_cfg is not None:
            ramp_start = int(self._ramp_cfg.get("start_step", 0))
            ramp_end = int(self._ramp_cfg.get("end_step", ramp_start + 1))
            if micro_step >= ramp_start and not self._ramp_started:
                self._ramp_started = True
                logger.info(
                    "[Handoff] base_ffn_ramp 시작 at step %d (LR ×%.1f→×%.1f)",
                    micro_step,
                    self._ramp_cfg.get("start_multiplier", 1.0),
                    self._ramp_cfg.get("end_multiplier", 1.0),
                )
            if micro_step >= ramp_end and not self._ramp_ended:
                self._ramp_ended = True
                logger.info(
                    "[Handoff] base_ffn_ramp 완료 at step %d (LR ×%.1f)",
                    micro_step, self._ramp_cfg.get("end_multiplier", 1.0),
                )

        # Apply scales
        if expert_scale is not None:
            for mod in _find_lora_modules(model, "expert_lora"):
                mod.lora_scale = expert_scale

        if attn_scale is not None:
            for mod in _find_lora_modules(model, "attn_lora"):
                mod.lora_scale = attn_scale

        # Apply freeze (one-shot)
        expert_frozen_now = False
        if expert_freeze and not self._expert_frozen:
            for mod in _find_lora_modules(model, "expert_lora"):
                for p in mod.parameters():
                    if "lora" in getattr(p, "_name", "") or True:
                        # Freeze LoRA params (lora_A, lora_B, loraA, loraB)
                        pass
                self._freeze_lora_params(mod)
            self._expert_frozen = True
            expert_frozen_now = True
            logger.info("[Handoff] expert_lora frozen at step %d (scale=%.4f)", micro_step, expert_scale or 0.0)

        attn_frozen_now = False
        if attn_freeze and not self._attn_frozen:
            for mod in _find_lora_modules(model, "attn_lora"):
                self._freeze_lora_params(mod)
            self._attn_frozen = True
            attn_frozen_now = True
            logger.info("[Handoff] attn_lora frozen at step %d (scale=%.4f)", micro_step, attn_scale or 0.0)

        lr_mult = self.get_base_ffn_lr_multiplier(micro_step)

        return HandoffStepResult(
            expert_lora_scale=expert_scale,
            attn_lora_scale=attn_scale,
            expert_lora_frozen=expert_frozen_now,
            attn_lora_frozen=attn_frozen_now,
            base_ffn_lr_multiplier=lr_mult,
            needs_optimizer_rebuild=expert_frozen_now or attn_frozen_now,
        )

    @staticmethod
    def _freeze_lora_params(mod: nn.Module) -> None:
        """Freeze only LoRA-related parameters in a module."""
        from eulerforge.modules.lora import LoRALinear
        from eulerforge.modules.mixture_lora import MixtureLoRALinear, LoRABranch

        if isinstance(mod, LoRALinear):
            if mod.lora_A is not None:
                mod.lora_A.requires_grad = False
            if mod.lora_B is not None:
                mod.lora_B.requires_grad = False
        elif isinstance(mod, MixtureLoRALinear):
            for expert in mod.experts:
                if isinstance(expert, LoRABranch):
                    expert.loraA.requires_grad = False
                    expert.loraB.requires_grad = False

    def format_status(self, micro_step: int) -> Optional[str]:
        """Format handoff status for periodic log output.

        Returns None if no handoff activity is active at this step.
        """
        parts = []
        if self._expert_cfg:
            scale, done, _ = self._compute_schedule(self._expert_cfg, micro_step)
            if scale is not None and (scale < 1.0 or done):
                label = "frozen" if self._expert_frozen else f"{scale:.2f}"
                parts.append(f"expert_lora={label}")
        if self._attn_cfg:
            scale, done, _ = self._compute_schedule(self._attn_cfg, micro_step)
            if scale is not None and (scale < 1.0 or done):
                label = "frozen" if self._attn_frozen else f"{scale:.2f}"
                parts.append(f"attn_lora={label}")
        if self._ramp_cfg:
            mult = self.get_base_ffn_lr_multiplier(micro_step)
            if mult != 1.0 or self._ramp_started:
                parts.append(f"ffn_lr_mult={mult:.2f}")
        if not parts:
            return None
        return "Handoff[" + ", ".join(parts) + "]"

    def get_base_ffn_lr_multiplier(self, micro_step: int) -> float:
        """Compute LR multiplier for base_ffn param group."""
        if self._ramp_cfg is None:
            return 1.0

        start = int(self._ramp_cfg.get("start_step", 0))
        end = int(self._ramp_cfg.get("end_step", start + 1))
        start_mult = float(self._ramp_cfg.get("start_multiplier", 1.0))
        end_mult = float(self._ramp_cfg.get("end_multiplier", 1.0))

        if micro_step < start:
            return start_mult
        if micro_step >= end:
            return end_mult

        progress = (micro_step - start) / float(end - start)
        return start_mult + progress * (end_mult - start_mult)
