# eulerforge/modules/lora.py
# -*- coding: utf-8 -*-
"""
eulerforge.modules.lora

단일 Linear 레이어를 감싸는 LoRA 래퍼 모듈.

특징
- base_layer(nn.Linear)를 그대로 보관하고, 그 weight는 freeze.
- lora_A, lora_B 두 개의 저랭크 파라미터만 학습.
- scaling = alpha / r 규칙 사용.
- dropout은 입력에만 적용 (LoRA branch에만).
- [NEW] disable_adapter() 컨텍스트 매니저 지원 (DPO Ref 모델용).

이 모듈은:
- FFN expert 내부 LoRA (MoE FFN)
- Mixture-of-LoRAs 내부 expert LoRA
- Attention q/k/v/o LoRA
등에서 공통으로 사용된다. [file:1]
"""

from __future__ import annotations

from typing import Optional
import math  # noqa: E402

import torch
import torch.nn as nn
import torch.nn.functional as F

# [NEW] 어댑터 제어용 Mixin 임포트
from .utils import AdapterLayerMixin


class LoRALinear(nn.Module, AdapterLayerMixin):
    """
    LoRA wrapper for nn.Linear.

    Args:
        base_layer: wrapped nn.Linear
        r: rank (0이면 no-op처럼 동작)
        alpha: scaling factor (effective scaling = alpha / r)
        dropout: LoRA branch dropout prob
    """

    def __init__(
        self,
        base_layer: nn.Linear,
        r: int = 0,
        alpha: float = 1.0,
        dropout: float = 0.0,
    ) -> None:
        nn.Module.__init__(self)
        AdapterLayerMixin.__init__(self)

        if not isinstance(base_layer, nn.Linear):
            # bitsandbytes Linear 등은 nn.Linear를 상속받지 않을 수도 있으나, 
            # 일반적인 구조에서는 덕 타이핑 혹은 Base class 체크가 필요할 수 있음.
            # 일단 여기서는 엄격한 체크보다는 속성 접근 시도를 가정하거나 기존 로직 유지.
            # (Quantized Linear도 보통 .weight 속성을 가짐)
            pass 

        self.base_layer = base_layer
        self.in_features = base_layer.in_features
        self.out_features = base_layer.out_features

        self.r = int(r)
        self.lora_alpha = float(alpha)
        self.lora_dropout_p = float(dropout)

        self.scaling = 0.0 if self.r <= 0 else self.lora_alpha / float(self.r)
        self.lora_scale: float = 1.0  # Handoff scheduler sets this to fade LoRA

        # 원래 weight/bias는 기본적으로 freeze
        for p in self.base_layer.parameters():
            p.requires_grad = False

        # [FIX] 베이스 레이어의 device와 dtype 추출 및 퀀타이제이션 대응
        base_weight = self.base_layer.weight
        
        target_device = base_weight.device
        # 퀀타이제이션 타입(int8, nf4 등)은 학습 가능한 파라미터(LoRA)로 사용할 수 없음.
        # 따라서 실수형이 아니면 float32로 폴백.
        if base_weight.dtype.is_floating_point:
            target_dtype = base_weight.dtype
        else:
            target_dtype = torch.float32
            
        factory_kwargs = {"device": target_device, "dtype": target_dtype}

        if self.r > 0:
            # LoRA parameters: A (in -> r), B (r -> out)
            # [FIX] factory_kwargs 적용 (BF16 또는 Float32)
            self.lora_A = nn.Parameter(torch.zeros(self.r, self.in_features, **factory_kwargs))
            self.lora_B = nn.Parameter(torch.zeros(self.out_features, self.r, **factory_kwargs))
            
            # 초기화 (dtype 유지)
            nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
            nn.init.zeros_(self.lora_B)
        else:
            self.register_parameter("lora_A", None)
            self.register_parameter("lora_B", None)

        self.dropout = nn.Dropout(self.lora_dropout_p) if self.lora_dropout_p > 0.0 else nn.Identity()

    def _lora_forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.r <= 0 or self.lora_A is None or self.lora_B is None:
            return torch.zeros_like(self.base_layer(x), device=x.device, dtype=x.dtype)

        # (batch, *, in) -> (batch, *, r) -> (batch, *, out)
        x_d = self.dropout(x)
        # F.linear: y = x @ A^T
        lora_intermediate = F.linear(x_d, self.lora_A)          # shape: (..., r)
        lora_out = F.linear(lora_intermediate, self.lora_B)     # shape: (..., out)
        return lora_out * self.scaling

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # [NEW] 어댑터가 비활성화된 경우 Base Layer 출력만 반환
        if self.is_adapter_disabled():
            return self.base_layer(x)

        base_out = self.base_layer(x)
        if self.r <= 0:
            return base_out
        return base_out + self._lora_forward(x) * self.lora_scale

    def extra_repr(self) -> str:
        return (
            f"in_features={self.in_features}, out_features={self.out_features}, "
            f"r={self.r}, alpha={self.lora_alpha}, dropout={self.lora_dropout_p}, "
            f"scaling={self.scaling}"
        )