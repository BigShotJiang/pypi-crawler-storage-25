# -*- coding: utf-8 -*-
"""
eulerforge.modules.moe

FFN 복제 기반 MoE (Mixture-of-Experts) 구현.

목표
- Dense FFN을 여러 expert로 복제한 뒤, token마다 top-k expert를 선택해 합산한다.
- 학습 시 load-balancing aux loss(간단 버전)를 제공한다.
- 라우팅 통계(last_*)를 저장해 로깅에 활용할 수 있게 한다.

주의
- 이 모듈은 "FFN을 감싸는 MoEFFN"에 집중한다.
- Attention MoE 등은 여기 범위 밖.
"""

from __future__ import annotations

import copy
import os
from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

import logging
logger = logging.getLogger(__name__)

# Opt-in dtype debug flag (환경변수 EULERFORGE_MOE_DTYPE_DEBUG=1 로 활성화)
_MOE_DTYPE_DEBUG = os.environ.get("EULERFORGE_MOE_DTYPE_DEBUG", "") == "1"


@dataclass
class MoEStats:
    # token_frac: 각 expert가 top-k로 선택된 토큰 비율 (합은 top_k)
    token_frac: torch.Tensor  # [E]
    # importance: 각 expert로 할당된 gate prob 합 비율 (합은 1)
    importance: torch.Tensor  # [E]
    # gate_prob_entropy: 토큰별 softmax 분포 엔트로피의 평균
    gate_prob_entropy: torch.Tensor  # scalar
    # density: 선택된 expert 비중(희소성/죽은 expert 감지용)
    density: torch.Tensor  # scalar


def _entropy_from_probs(p: torch.Tensor, eps: float = 1e-9) -> torch.Tensor:
    # p: (..., E)
    p = p.clamp_min(eps)
    return -(p * p.log()).sum(dim=-1)


class MoEFFN(nn.Module):
    """
    FFN wrapper for MoE.

    Args:
        base_ffn: Dense FFN module (예: Qwen block의 mlp)
        hidden_size: router 입력 차원
        num_experts: expert 개수
        top_k: token당 선택 expert 수
        router_bias: router linear bias 사용 여부
        router_temperature: softmax 온도 (1.0 기본)
        aux_loss_coeff: load-balancing aux loss 계수(계산만; 최종 loss에 곱하는 건 외부에서)
        track_routing: 디버그/로깅을 위한 라우팅 텐서 저장 여부
        track_routing_logits: gate logits(softmax 전)까지 저장할지 여부(메모리/로그 비용 증가)
        routing_logit_dtype: logits 저장 dtype (예: torch.float16/torch.float32). None이면 원 dtype 유지.
    """

    def __init__(
        self,
        base_ffn: nn.Module,
        hidden_size: int,
        num_experts: int,
        top_k: int = 2,
        router_bias: bool = True,
        router_temperature: float = 1.0,
        aux_loss_coeff: float = 0.0,
        track_routing: bool = True,
        track_routing_logits: bool = False,
        routing_logit_dtype: Optional[torch.dtype] = torch.float16,
    ) -> None:
        super().__init__()
        if num_experts <= 0:
            raise ValueError("num_experts must be > 0")
        if top_k <= 0 or top_k > num_experts:
            raise ValueError("top_k must be in [1, num_experts]")

        self.hidden_size = int(hidden_size)
        self.num_experts = int(num_experts)
        self.top_k = int(top_k)

        # [FIX] base_ffn에서 파라미터 하나를 꺼내 dtype/device 확인
        # 퀀타이제이션(int8/nf4)된 경우 dtype이 정수형일 수 있으므로 체크
        ref_param = next(base_ffn.parameters(), None)
        factory_kwargs = {}
        if ref_param is not None:
            # 1. Device는 그대로 따라감
            target_device = ref_param.device
            
            # 2. Dtype은 Floating Point인 경우만 계승, 퀀타이제이션(Int)인 경우 Float32로 강제
            if ref_param.dtype.is_floating_point:
                target_dtype = ref_param.dtype
            else:
                target_dtype = torch.float32
                
            factory_kwargs = {"device": target_device, "dtype": target_dtype}

        # [FIX] Router에 factory_kwargs 적용 (이제 안전한 float 타입 사용)
        self.router = nn.Linear(self.hidden_size, self.num_experts, bias=router_bias, **factory_kwargs)
        self.router_temperature = float(router_temperature)

        # experts: base_ffn을 deep copy (내부 weight가 int8이어도 복제는 문제없음)
        self.experts = nn.ModuleList([copy.deepcopy(base_ffn) for _ in range(self.num_experts)])

        # aux loss
        self.aux_loss_coeff = float(aux_loss_coeff)
        self.last_aux_loss: Optional[torch.Tensor] = None

        # stats (structured)
        self.last_stats: Optional[MoEStats] = None
        self.layer_index: Optional[int] = None  # 외부에서 찍어두면 디버깅 편함

        # routing dump controls
        self.track_routing = bool(track_routing)
        self.track_routing_logits = bool(track_routing_logits)
        self.routing_logit_dtype = routing_logit_dtype

        # routing raw tensors (optional, for deep debug)
        self.last_topk_idx: Optional[torch.Tensor] = None  # (T,K) long
        self.last_topk_w: Optional[torch.Tensor] = None    # (T,K) float
        self.last_gate_prob: Optional[torch.Tensor] = None  # (T,E) float (can be large)
        self.last_gate_logits: Optional[torch.Tensor] = None  # (T,E) float (optional)
        self.last_entropy_tok: Optional[torch.Tensor] = None  # (T,) float

        # perf profiling (disabled by default, enable via enable_perf())
        self._perf_enabled: bool = False
        self.last_perf: Optional[dict] = None

        # legacy fields to match train.py try_log_moe_routing_stats()
        self.lasttokenfrac: Optional[torch.Tensor] = None
        self.lastgateprob: Optional[torch.Tensor] = None
        self.lastentropy: Optional[torch.Tensor] = None
        self.lastdensity: Optional[torch.Tensor] = None
        self.lastimportance: Optional[torch.Tensor] = None
        self.totaltokens: int = 0
            
    def _route(
        self, x: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Returns:
            topk_idx:  (T, K)
            topk_w:    (T, K)  (top-k weights, normalized over K)
            gate_prob: (T, E)  (softmax over all experts)
            entropy:   (T,)
            logits:    (T, E)  (softmax 전; temperature 반영 후)
        """
        # x: (B, S, H) or (T, H)
        if x.dim() == 3:
            t = x.reshape(-1, x.size(-1))
        elif x.dim() == 2:
            t = x
        else:
            raise ValueError(f"Unexpected x shape: {x.shape}")

        # Cast input to router weight dtype if mismatched (e.g., bf16 input + fp32 router).
        # This can happen when base_ffn ref_param was quantized (int8) → router created as fp32.
        # On CUDA autocast handles this implicitly, but explicit cast is safer.
        router_input = t if t.dtype == self.router.weight.dtype else t.to(self.router.weight.dtype)
        logits = self.router(router_input)  # (T, E)
        if self.router_temperature != 1.0:
            logits = logits / self.router_temperature

        gate_prob = F.softmax(logits, dim=-1)  # (T, E)
        entropy = _entropy_from_probs(gate_prob)  # (T,)

        topk_w, topk_idx = torch.topk(gate_prob, k=self.top_k, dim=-1)  # (T, K)
        # top-k 내부에서 다시 normalize (Switch/TopK MoE에서 흔한 패턴)
        topk_w = topk_w / (topk_w.sum(dim=-1, keepdim=True) + 1e-9)

        return topk_idx, topk_w, gate_prob, entropy, logits

    def _compute_aux_loss(
        self,
        topk_idx: torch.Tensor,
        gate_prob: torch.Tensor,
    ) -> torch.Tensor:
        """
        간단한 load-balancing aux loss.
        - fraction(선택 비율)과 importance(게이트 확률 합) 둘 다 균등하게 만들도록 유도.

        반환은 "스칼라 텐서"이며, 외부에서 main loss에 가중치로 더해 사용한다.
        """
        # topk_idx: (T, K), gate_prob: (T, E)
        T, K = topk_idx.shape
        E = gate_prob.shape[-1]

        # token selection count per expert
        onehot = torch.zeros((T, K, E), device=topk_idx.device, dtype=gate_prob.dtype)
        onehot.scatter_(dim=-1, index=topk_idx.unsqueeze(-1), value=1.0)
        sel_count = onehot.sum(dim=(0, 1))  # (E,)
        frac = sel_count / (float(T * K) + 1e-9)  # (E,)

        # importance = sum gate prob per expert
        imp = gate_prob.sum(dim=0)  # (E,)
        imp = imp / (imp.sum() + 1e-9)

        # target uniform
        u = torch.full_like(frac, 1.0 / float(E))

        loss_frac = ((frac - u) ** 2).mean()
        loss_imp = ((imp - u) ** 2).mean()
        return loss_frac + loss_imp

    def _sync_legacy_fields(
        self,
        stats: Optional[MoEStats],
        gate_prob: Optional[torch.Tensor],
        totaltokens: int,
    ) -> None:
        """
        train.py의 try_log_moe_routing_stats()가 MixtureLoRALinear에 대해 기대하는
        레거시 필드명(lasttokenfrac/lastgateprob/lastentropy/lastdensity/lastimportance/totaltokens)을
        MoEFFN에서도 채워준다.
        """
        self.totaltokens = int(totaltokens)

        if stats is None:
            self.lasttokenfrac = None
            self.lastgateprob = None
            self.lastentropy = None
            self.lastdensity = None
            self.lastimportance = None
            return

        self.lasttokenfrac = stats.token_frac
        self.lastimportance = stats.importance
        self.lastentropy = stats.gate_prob_entropy
        self.lastdensity = stats.density

        # MixtureLoRALinear는 gateprob를 "E차원 평균 확률"로 요약해서 들고 있음.
        # MoEFFN도 동일하게 mean(dim=0)으로 맞춰준다.
        if gate_prob is not None and torch.is_tensor(gate_prob):
            self.lastgateprob = gate_prob.detach().float().mean(dim=0)
        else:
            self.lastgateprob = None

    def _update_stats(
        self,
        topk_idx: torch.Tensor,
        gate_prob: torch.Tensor,
        entropy: torch.Tensor,
    ) -> None:
        # topk_idx: (T, K)
        T, K = topk_idx.shape
        E = gate_prob.shape[-1]

        counts = torch.zeros((E,), device=topk_idx.device, dtype=torch.float32)
        counts.scatter_add_(
            dim=0,
            index=topk_idx.reshape(-1),
            src=torch.ones((T * K,), device=topk_idx.device, dtype=torch.float32),
        )
        token_frac = counts / (float(T) + 1e-9)  # "토큰당 선택 횟수" 비율 (합은 K)

        importance = gate_prob.sum(dim=0).detach()
        importance = importance / (importance.sum() + 1e-9)

        gate_prob_entropy = entropy.mean().detach()
        density = (counts > 0).float().mean().detach()  # 선택된 expert 비중(희소성 감)

        self.last_stats = MoEStats(
            token_frac=token_frac.detach(),
            importance=importance.detach(),
            gate_prob_entropy=gate_prob_entropy,
            density=density,
        )

        # legacy 동기화는 forward에서 gate_prob와 totaltokens까지 알 때 처리

    def enable_perf(self, enabled: bool = True) -> None:
        """Enable/disable per-forward performance profiling."""
        self._perf_enabled = bool(enabled)

    def _maybe_detach_cast(self, x: torch.Tensor, dtype: Optional[torch.dtype]) -> torch.Tensor:
        y = x.detach()
        if dtype is not None:
            y = y.to(dtype=dtype)
        return y

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: (B, S, H) -> out: (B, S, H) (일반적으로 FFN output shape을 그대로 따라감)

        Batched expert dispatch:
        - 모든 top-k 슬롯의 (token_idx, expert_idx, weight)를 한번에 플래트닝
        - expert별 토큰을 contiguous하게 모아 한 번의 forward로 실행
        - Python for-loop은 expert 수(E)만큼만 발생 (기존: top_k × E)
        """
        if x.dim() == 3:
            B, S, H = x.shape
            t = x.reshape(B * S, H)
            reshape_back = (B, S, self.hidden_size)
        elif x.dim() == 2:
            t = x
            H = x.size(-1)
            reshape_back = None
        else:
            raise ValueError(f"Unexpected x shape: {x.shape}")

        if H != self.hidden_size:
            raise ValueError(f"Router hidden_size mismatch: got {H}, expected {self.hidden_size}")

        perf = self._perf_enabled
        if perf:
            torch.cuda.synchronize() if t.is_cuda else None
            import time
            _t0 = time.perf_counter()

        topk_idx, topk_w, gate_prob, entropy, logits = self._route(t)
        T = t.size(0)

        # ── dtype debug instrumentation ──
        _dtype_debug = _MOE_DTYPE_DEBUG or os.environ.get("EULERFORGE_MOE_DTYPE_DEBUG", "") == "1"
        if _dtype_debug:
            logger.debug(
                "[MoEDType] hidden=%s router_logits=%s topk_weights=%s y_buf=%s "
                "layer=%s",
                t.dtype, logits.dtype, topk_w.dtype, t.dtype,
                self.layer_index,
            )

        if perf:
            torch.cuda.synchronize() if t.is_cuda else None
            _t_route = time.perf_counter()

        # routing raw 저장(필요시)
        if self.track_routing:
            self.last_topk_idx = topk_idx.detach()
            self.last_topk_w = topk_w.detach()
            self.last_gate_prob = gate_prob.detach()
            self.last_entropy_tok = entropy.detach()
            if self.track_routing_logits:
                self.last_gate_logits = self._maybe_detach_cast(logits, self.routing_logit_dtype)
            else:
                self.last_gate_logits = None
        else:
            self.last_topk_idx = None
            self.last_topk_w = None
            self.last_gate_prob = None
            self.last_entropy_tok = None
            self.last_gate_logits = None

        # aux loss/stat
        if self.aux_loss_coeff != 0.0:
            self.last_aux_loss = self._compute_aux_loss(topk_idx, gate_prob) * self.aux_loss_coeff
        else:
            self.last_aux_loss = None

        self._update_stats(topk_idx, gate_prob, entropy)
        self._sync_legacy_fields(self.last_stats, gate_prob, totaltokens=T)

        # ── Batched expert dispatch ──
        # Flatten all top-k assignments: (T*K,) expert ids, token indices, weights
        flat_expert = topk_idx.reshape(-1)       # (T*K,)
        flat_weight = topk_w.reshape(-1)         # (T*K,)
        # token index for each slot: [0,1,...,T-1, 0,1,...,T-1, ...]
        flat_tok_idx = torch.arange(T, device=t.device).unsqueeze(1).expand(T, self.top_k).reshape(-1)

        # Sort by expert for contiguous batching
        sorted_order = flat_expert.argsort(stable=True)
        sorted_expert = flat_expert[sorted_order]
        sorted_tok_idx = flat_tok_idx[sorted_order]
        sorted_weight = flat_weight[sorted_order]

        if perf:
            torch.cuda.synchronize() if t.is_cuda else None
            _t_dispatch = time.perf_counter()

        # Find boundaries per expert via bincount
        expert_counts = torch.bincount(sorted_expert, minlength=self.num_experts)

        y = torch.zeros((T, self.hidden_size), device=t.device, dtype=t.dtype)

        offset = 0
        expert_token_hist = []
        if perf:
            _expert_times = []

        for e in range(self.num_experts):
            n_e = int(expert_counts[e].item())
            expert_token_hist.append(n_e)
            if n_e == 0:
                if perf:
                    _expert_times.append(0.0)
                continue

            if perf:
                torch.cuda.synchronize() if t.is_cuda else None
                _te0 = time.perf_counter()

            # Gather contiguous token batch for this expert
            tok_indices = sorted_tok_idx[offset:offset + n_e]
            weights = sorted_weight[offset:offset + n_e].unsqueeze(-1)  # (n_e, 1)

            x_e = t[tok_indices]           # (n_e, H) - contiguous gather
            y_e = self.experts[e](x_e)     # (n_e, H) - single batched forward

            # ── dtype contract: cast source to match merge buffer ──
            # Router softmax may produce float32 weights (autocast or quantized router).
            # Expert output may also be float32 (quantized linear, compute_dtype drift).
            # index_add_ requires self and source to have identical dtype.
            source = (y_e * weights).to(y.dtype)

            if _dtype_debug:
                logger.debug(
                    "[MoEDType] expert=%d expert_out=%s weights=%s source=%s y_buf=%s",
                    e, y_e.dtype, weights.dtype, source.dtype, y.dtype,
                )

            # scatter-add weighted output back
            y.index_add_(0, tok_indices, source)

            offset += n_e

            if perf:
                torch.cuda.synchronize() if t.is_cuda else None
                _expert_times.append(time.perf_counter() - _te0)

        if perf:
            torch.cuda.synchronize() if t.is_cuda else None
            _t_experts_done = time.perf_counter()

        # ── Perf logging ──
        if perf:
            nonempty = sum(1 for c in expert_token_hist if c > 0)
            avg_tok = sum(expert_token_hist) / max(nonempty, 1)
            self.last_perf = {
                "router_ms": (_t_route - _t0) * 1000,
                "dispatch_ms": (_t_dispatch - _t_route) * 1000,
                "experts_ms": (_t_experts_done - _t_dispatch) * 1000,
                "expert_times_ms": [round(et * 1000, 3) for et in _expert_times],
                "total_fwd_ms": (_t_experts_done - _t0) * 1000,
                "expert_token_hist": expert_token_hist,
                "nonempty_experts": nonempty,
                "num_experts": self.num_experts,
                "avg_tokens_per_expert": round(avg_tok, 1),
                "total_tokens": T,
            }
        else:
            self.last_perf = None

        if reshape_back is not None:
            return y.reshape(*reshape_back)
        return y


def find_transformer_layers_fallback(model: nn.Module) -> List[nn.Module]:
    """
    (이식 전 임시) transformers 계열 모델에서 "blocks/layers"를 찾는 best-effort.
    EulerForge의 BackboneAdapter로 완전히 대체되는 게 정석이다.
    """
    for attr in ("model", "transformer"):
        if hasattr(model, attr):
            model = getattr(model, attr)
            break

    for name in ("layers", "h", "blocks"):
        if hasattr(model, name):
            obj = getattr(model, name)
            if isinstance(obj, (nn.ModuleList, list, tuple)):
                return list(obj)
    raise RuntimeError(
        "Could not find transformer layers. Use BackboneAdapter.find_transformer_layers()."
    )


def replace_ffn_with_moe_inplace(
    model: nn.Module,
    adapter,  # BackboneAdapter (타입 순환/의존 회피로 여기선 명시 import 생략)
    layer_indices: Sequence[int],
    hidden_size: int,
    num_experts: int,
    top_k: int,
    aux_loss_coeff: float = 0.0,
    verbose: bool = False,
    track_routing: bool = True,
    track_routing_logits: bool = False,
    routing_logit_dtype: Optional[torch.dtype] = torch.float16,
) -> List[int]:
    """
    선택한 layer들의 FFN을 MoEFFN으로 교체한다.
    - FFN 속성명은 backbone adapter가 제공해야 한다.
    """
    layers = list(adapter.find_transformer_layers(model))
    applied: List[int] = []

    for li in layer_indices:
        block = layers[int(li)]
        ffn_name = adapter.find_ffn_attr_name(block)

        base_ffn = getattr(block, ffn_name)
        if isinstance(base_ffn, MoEFFN):
            # 이미 교체된 상태면 skip
            continue

        moe = MoEFFN(
            base_ffn=base_ffn,
            hidden_size=int(hidden_size),
            num_experts=int(num_experts),
            top_k=int(top_k),
            aux_loss_coeff=float(aux_loss_coeff),
            track_routing=bool(track_routing),
            track_routing_logits=bool(track_routing_logits),
            routing_logit_dtype=routing_logit_dtype,
        )
        moe.layer_index = int(li)
        setattr(block, ffn_name, moe)
        applied.append(int(li))

        if verbose:
            logger.info(
                "[moe] Replaced layer %d FFN '%s' with MoEFFN(E=%d, top_k=%d).",
                li,
                ffn_name,
                num_experts,
                top_k,
            )

    return applied
