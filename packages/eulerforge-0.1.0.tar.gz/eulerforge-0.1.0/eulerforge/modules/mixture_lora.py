# eulerforge/modules/mixture_lora.py
# -*- coding: utf-8 -*-
"""
eulerforge.modules.mixture_lora

Mixture-of-LoRAs(=LoRA-MoE) 구현:
- FFN 내부 nn.Linear를 MixtureLoRALinear로 치환
- token마다 router가 top-k개의 LoRA branch를 선택/가중합하여 delta를 더한다.
- [NEW] disable_adapter() 컨텍스트 매니저 지원.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple, Dict, Any

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..adapters.backbones.base import BackboneAdapter
from .utils import AdapterLayerMixin  # [NEW] Mixin 임포트


# -------------------------
# LoRA branch
# -------------------------

class LoRABranch(nn.Module):
    """
    A single LoRA branch for a base Linear:
      delta(x) = (x @ A^T) @ B^T * (alpha/r)
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        r: int,
        alpha: float,
        dropout: float,
        *,
        device: torch.device,
        dtype: torch.dtype,
    ) -> None:
        super().__init__()
        if r <= 0:
            raise ValueError("r must be > 0 for LoRABranch")

        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.r = int(r)
        self.alpha = float(alpha)
        self.scaling = self.alpha / float(self.r)
        self.dropout = nn.Dropout(p=float(dropout)) if dropout and dropout > 0 else nn.Identity()

        # base와 동일 dtype/device로 생성
        self.loraA = nn.Parameter(torch.empty(self.r, self.in_features, device=device, dtype=dtype))
        self.loraB = nn.Parameter(torch.empty(self.out_features, self.r, device=device, dtype=dtype))

        nn.init.kaiming_uniform_(self.loraA, a=5 ** 0.5)
        # MoE expert symmetry-breaking: lora_B를 작은 랜덤 값으로 초기화.
        # zero-init이면 모든 expert 출력이 0이 되어 Phase 0(router-only)에서
        # router가 gradient를 받을 수 없고, 검증 loss가 변하지 않는다.
        nn.init.normal_(self.loraB, std=0.01)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x_d = self.dropout(x)
        z = F.linear(x_d, self.loraA)
        out = F.linear(z, self.loraB) * self.scaling
        return out


# -------------------------
# Mixture-of-LoRAs Linear
# -------------------------

@dataclass
class MixtureLoRAStats:
    # (E,) 합=1 (slot 기준 점유율; counts/(T*K))
    token_frac: torch.Tensor
    # (E,) 합=K (token당 top-k 선택 “횟수” 의미; counts/T)
    token_frac_per_token: torch.Tensor
    # (E,) gate_prob 평균
    gate_prob: torch.Tensor
    # scalar 평균 entropy
    entropy: torch.Tensor
    # (E,) hard 선택률(=token_frac_per_token)로 제공
    density: torch.Tensor
    # (E,) 합=1 (gate_prob sum 정규화)
    importance: torch.Tensor
    total_tokens: int


class MixtureLoRALinear(nn.Module, AdapterLayerMixin):
    """
    Base Linear + router + E LoRA branches.
      y = base(x) + sum_{k in topK} w_k * lora_{expert_k}(x)
    """

    def __init__(
        self,
        base_layer: nn.Linear,
        num_experts: int,
        top_k: int,
        r: int,
        alpha: float,
        dropout: float,
        router_bias: bool = True,
        router_temperature: float = 1.0,
        aux_loss_coeff: float = 0.0,
        track_stats: bool = True,
    ) -> None:
        nn.Module.__init__(self)
        AdapterLayerMixin.__init__(self)  # [NEW] Mixin 초기화

        if not isinstance(base_layer, nn.Linear):
            raise TypeError("base_layer must be nn.Linear")
        if num_experts <= 0:
            raise ValueError("num_experts must be > 0")
        if top_k <= 0 or top_k > num_experts:
            raise ValueError("top_k must be in [1, num_experts]")
        if r <= 0:
            raise ValueError("r must be > 0 for MixtureLoRALinear")

        self.base_layer = base_layer
        self.in_features = int(base_layer.in_features)
        self.out_features = int(base_layer.out_features)

        self.num_experts = int(num_experts)
        self.top_k = int(top_k)
        self.router_temperature = float(router_temperature)
        self.lora_scale: float = 1.0  # Handoff scheduler sets this to fade LoRA

        base_device = self.base_layer.weight.device
        base_dtype = self.base_layer.weight.dtype
        # Quantized base (int8/nf4) cannot be used for trainable params;
        # fall back to float32 for router and LoRA experts.
        if not base_dtype.is_floating_point:
            base_dtype = torch.float32

        self.router = nn.Linear(
            self.in_features,
            self.num_experts,
            bias=router_bias,
            device=base_device,
            dtype=base_dtype,
        )

        self.experts = nn.ModuleList(
            [
                LoRABranch(
                    self.in_features,
                    self.out_features,
                    r=int(r),
                    alpha=float(alpha),
                    dropout=float(dropout),
                    device=base_device,
                    dtype=base_dtype,
                )
                for _ in range(self.num_experts)
            ]
        )

        self.aux_loss_coeff = float(aux_loss_coeff)
        self.track_stats = bool(track_stats)

        # 외부 combine_main_and_aux_loss / train.py 로깅에서 참조
        self.last_aux_loss: Optional[torch.Tensor] = None
        self.last_stats: Optional[MixtureLoRAStats] = None

        # ---- train.py 로거 호환 필드(있으면 바로 찍히게) ----
        self.last_token_frac: Optional[torch.Tensor] = None
        self.last_token_frac_per_token: Optional[torch.Tensor] = None
        self.last_gate_prob: Optional[torch.Tensor] = None
        self.last_entropy: Optional[torch.Tensor] = None
        self.last_density: Optional[torch.Tensor] = None
        self.last_importance: Optional[torch.Tensor] = None
        self.total_tokens: int = 0

        # 스케줄/인젝터가 layer index 등을 넣고 싶을 때(선택)
        self.debug_meta: Dict[str, Any] = {}

        self.layer_index: Optional[int] = None

    def extra_repr(self) -> str:
        return f"in={self.in_features}, out={self.out_features}, E={self.num_experts}, top_k={self.top_k}"

    def debug_trainable_summary(self) -> Dict[str, Any]:
        """
        Phase 스위치 디버깅용:
        - router / experts / base_layer의 trainable 파라미터 수를 분리해서 반환
        """
        def _count(m: nn.Module) -> Tuple[int, int]:
            t = 0
            n = 0
            for p in m.parameters():
                if p.requires_grad:
                    t += 1
                    n += p.numel()
            return t, n

        rt = _count(self.router)
        et = _count(self.experts)
        bt = _count(self.base_layer)

        return {
            "router_trainable_tensors": rt[0],
            "router_trainable_params": rt[1],
            "experts_trainable_tensors": et[0],
            "experts_trainable_params": et[1],
            "base_trainable_tensors": bt[0],
            "base_trainable_params": bt[1],
        }

    def _entropy(self, p: torch.Tensor, eps: float = 1e-9) -> torch.Tensor:
        p = p.clamp_min(eps)
        return -(p * p.log()).sum(dim=-1)

    def _compute_aux_loss(self, topk_idx: torch.Tensor, gate_prob: torch.Tensor) -> torch.Tensor:
        """
        load-balancing loss (간단형)
        """
        T, K = topk_idx.shape
        E = gate_prob.shape[-1]

        onehot = torch.zeros((T, K, E), device=topk_idx.device, dtype=gate_prob.dtype)
        onehot.scatter_(dim=-1, index=topk_idx.unsqueeze(-1), value=1.0)
        sel = onehot.sum(dim=(0, 1))  # (E,)

        frac = sel / (float(T * K) + 1e-9)  # 합=1
        imp = gate_prob.sum(dim=0)
        imp = imp / (imp.sum() + 1e-9)

        u = torch.full_like(frac, 1.0 / float(E))
        return ((frac - u) ** 2).mean() + ((imp - u) ** 2).mean()

    def _build_stats(self, topk_idx: torch.Tensor, gate_prob: torch.Tensor, entropy_tok: torch.Tensor) -> MixtureLoRAStats:
        T, K = topk_idx.shape
        E = self.num_experts

        counts = torch.zeros((E,), device=topk_idx.device, dtype=torch.float32)
        counts.scatter_add_(
            dim=0,
            index=topk_idx.reshape(-1),
            src=torch.ones((T * K,), device=topk_idx.device, dtype=torch.float32),
        )

        token_frac = counts / (float(T * K) + 1e-9)         # 합=1
        token_frac_per_token = counts / (float(T) + 1e-9)   # 합=K

        gate_prob_mean = gate_prob.detach().float().mean(dim=0)  # (E,)
        entropy_mean = entropy_tok.detach().float().mean()       # scalar

        density = token_frac_per_token.detach().clone()

        importance = gate_prob.detach().float().sum(dim=0)
        importance = importance / (importance.sum() + 1e-9)

        return MixtureLoRAStats(
            token_frac=token_frac.detach(),
            token_frac_per_token=token_frac_per_token.detach(),
            gate_prob=gate_prob_mean.detach(),
            entropy=entropy_mean.detach(),
            density=density.detach(),
            importance=importance.detach(),
            total_tokens=int(T),
        )

    def _sync_legacy_stat_fields(self, stats: MixtureLoRAStats) -> None:
        """
        train.py의 getattr 기반 로깅이 바로 먹도록, 예전 스타일 필드도 같이 세팅.
        """
        self.last_stats = stats
        self.last_token_frac = stats.token_frac
        self.last_token_frac_per_token = stats.token_frac_per_token
        self.last_gate_prob = stats.gate_prob
        self.last_entropy = stats.entropy
        self.last_density = stats.density
        self.last_importance = stats.importance
        self.total_tokens = stats.total_tokens

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # [NEW] 어댑터가 비활성화된 경우 Base Layer 출력만 반환
        if self.is_adapter_disabled():
            return self.base_layer(x)

        base_out = self.base_layer(x)

        if x.dim() == 3:
            B, S, H = x.shape
            t = x.reshape(B * S, H)
            reshape_back = (B, S, self.out_features)
        elif x.dim() == 2:
            t = x
            reshape_back = None
        else:
            raise ValueError(f"Unexpected x shape: {x.shape}")

        logits = self.router(t)
        if self.router_temperature != 1.0:
            logits = logits / self.router_temperature

        gate_prob = F.softmax(logits, dim=-1)     # (T,E)
        entropy_tok = self._entropy(gate_prob)   # (T,)

        topk_w, topk_idx = torch.topk(gate_prob, k=self.top_k, dim=-1)  # (T,K)
        topk_w = topk_w / (topk_w.sum(dim=-1, keepdim=True) + 1e-9)

        # aux loss 저장
        if self.aux_loss_coeff != 0.0:
            self.last_aux_loss = self._compute_aux_loss(topk_idx, gate_prob) * self.aux_loss_coeff
        else:
            self.last_aux_loss = None

        # stats 저장(+legacy 필드 동기화)
        if self.track_stats:
            stats = self._build_stats(topk_idx, gate_prob, entropy_tok)
            self._sync_legacy_stat_fields(stats)
        else:
            self.last_stats = None
            self.last_token_frac = None
            self.last_token_frac_per_token = None
            self.last_gate_prob = None
            self.last_entropy = None
            self.last_density = None
            self.last_importance = None
            self.total_tokens = 0

        # delta 계산(명확 구현)
        T = t.size(0)
        delta = torch.zeros((T, self.out_features), device=t.device, dtype=base_out.dtype)

        for k in range(self.top_k):
            idx_k = topk_idx[:, k]              # (T,)
            w_k = topk_w[:, k].unsqueeze(-1)    # (T,1)

            for e in range(self.num_experts):
                mask = (idx_k == e)
                if not mask.any():
                    continue
                d = self.experts[e](t[mask])    # (N_e, out)
                delta[mask] += d * w_k[mask]

        if reshape_back is not None:
            delta = delta.reshape(*reshape_back)
        return base_out + delta * self.lora_scale


# -------------------------
# builder / injector helpers
# -------------------------

def _normalize_name(s: str) -> str:
    return (s or "").replace("_", "").lower()

def _should_wrap(child_name: str, target_keywords: Sequence[str]) -> bool:
    n = _normalize_name(child_name)
    kws = [_normalize_name(k) for k in target_keywords if k and str(k).strip()]
    return any(k in n for k in kws)

def replace_linears_with_mixture_lora_inplace(
    module: nn.Module,
    target_keywords: Sequence[str],
    num_experts: int,
    top_k: int,
    r: int,
    alpha: float,
    dropout: float,
    router_temperature: float = 1.0,
    aux_loss_coeff: float = 0.0,
    track_stats: bool = True,
    layer_index: Optional[int] = None,  
) -> int:
    replaced = 0
    for name, child in list(module.named_children()):
        if isinstance(child, MixtureLoRALinear):
            continue

        if isinstance(child, nn.Linear) and _should_wrap(name, target_keywords):
            wrapped = MixtureLoRALinear(
                base_layer=child,
                num_experts=int(num_experts),
                top_k=int(top_k),
                r=int(r),
                alpha=float(alpha),
                dropout=float(dropout),
                router_temperature=float(router_temperature),
                aux_loss_coeff=float(aux_loss_coeff),
                track_stats=bool(track_stats),
            )
            wrapped.layer_index = int(layer_index) if layer_index is not None else None
            wrapped.debug_meta["layer_index"] = wrapped.layer_index
            setattr(module, name, wrapped)

            replaced += 1
            continue

        replaced += replace_linears_with_mixture_lora_inplace(
            child,
            target_keywords=target_keywords,
            num_experts=num_experts,
            top_k=top_k,
            r=r,
            alpha=alpha,
            dropout=dropout,
            router_temperature=router_temperature,
            aux_loss_coeff=aux_loss_coeff,
            track_stats=track_stats,
            layer_index=layer_index,  
        )
    return replaced

def build_mixture_lora_for_ffn_layers(
    model: nn.Module,
    adapter: BackboneAdapter,
    layer_indices: Sequence[int],
    num_experts: int,
    top_k: int,
    r: int,
    alpha: float,
    dropout: float,
    target_submodule_keywords: Sequence[str] = ("w1", "w2", "gate_proj", "up_proj", "down_proj"),
    router_temperature: float = 1.0,
    aux_loss_coeff: float = 0.0,
    track_stats: bool = True,
) -> Tuple[nn.Module, List[int], int]:
    layers = list(adapter.find_transformer_layers(model))
    wrapped_total = 0
    applied: List[int] = []

    for li in layer_indices:
        block = layers[int(li)]
        ffn_name = adapter.find_ffn_attr_name(block)
        ffn = getattr(block, ffn_name)

        wrapped_here = replace_linears_with_mixture_lora_inplace(
            ffn,
            target_keywords=target_submodule_keywords,
            num_experts=num_experts,
            top_k=top_k,
            r=r,
            alpha=alpha,
            dropout=dropout,
            router_temperature=router_temperature,
            aux_loss_coeff=aux_loss_coeff,
            track_stats=track_stats,
            layer_index=int(li),
        )
        if wrapped_here > 0:
            applied.append(int(li))
            wrapped_total += int(wrapped_here)

    return model, applied, wrapped_total