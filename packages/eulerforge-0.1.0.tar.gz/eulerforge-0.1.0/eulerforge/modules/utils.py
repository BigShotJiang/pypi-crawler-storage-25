# eulerforge/modules/utils.py
# -*- coding: utf-8 -*-
from __future__ import annotations
import contextlib

class AdapterLayerMixin:
    """
    어댑터(LoRA, MixtureLoRA 등)를 일시적으로 비활성화(disable)하는 기능을 제공하는 Mixin.
    DPO Reference Model 추론 시 메모리 절약을 위해 사용됩니다.
    """
    def __init__(self):
        self._adapter_disabled: bool = False

    @contextlib.contextmanager
    def disable_adapter(self):
        """
        Context manager to temporarily disable the adapter inference.
        Example:
            with layer.disable_adapter():
                y = layer(x) # Base model output only
        """
        previous = self._adapter_disabled
        try:
            self._adapter_disabled = True
            yield
        finally:
            self._adapter_disabled = previous

    def is_adapter_disabled(self) -> bool:
        return self._adapter_disabled