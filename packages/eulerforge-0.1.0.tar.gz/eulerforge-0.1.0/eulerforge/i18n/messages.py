# eulerforge/i18n/messages.py
# -*- coding: utf-8 -*-
"""
EulerForge 국제화 메시지 카탈로그.

모든 user-facing 출력 문자열의 다국어 번역을 포함한다.
키 형식: "{module}.{message_id}"

지원 언어: ko (기본), en, zh, ja, es
"""
from __future__ import annotations

# ─────────────────────────────────────────────────────────────────────────
# 메시지 카탈로그
# ─────────────────────────────────────────────────────────────────────────
# 각 키: {모듈}.{메시지ID}
# 각 값: {언어코드: 번역문자열} dict
# format 인자는 {중괄호} 사용 (Python str.format 호환)
# ─────────────────────────────────────────────────────────────────────────

MESSAGES: dict[str, dict[str, str]] = {

    # ====================================================================
    # Loader
    # ====================================================================
    "loader.moe_preserve": {
        "ko": "[Loader] FFN MoE Expert LoRA — MoE 구조 보존 모드",
        "en": "[Loader] FFN MoE Expert LoRA — MoE structure preserve mode",
        "zh": "[Loader] FFN MoE Expert LoRA — MoE 结构保留模式",
        "ja": "[Loader] FFN MoE Expert LoRA — MoE構造保存モード",
        "es": "[Loader] FFN MoE Expert LoRA — modo preservación de estructura MoE",
    },
    "loader.no_resolved_config_fallback": {
        "ko": "[Loader] resolved_config.json 없음 — fallback",
        "en": "[Loader] resolved_config.json not found — falling back",
        "zh": "[Loader] resolved_config.json 未找到 — 回退",
        "ja": "[Loader] resolved_config.json が見つかりません — フォールバック",
        "es": "[Loader] resolved_config.json no encontrado — modo alternativo",
    },
    "loader.mixture_lora_preserve": {
        "ko": "[Loader] Mixture-of-LoRAs — MixtureLoRA 구조 보존 모드",
        "en": "[Loader] Mixture-of-LoRAs — MixtureLoRA structure preserve mode",
        "zh": "[Loader] Mixture-of-LoRAs — MixtureLoRA 结构保留模式",
        "ja": "[Loader] Mixture-of-LoRAs — MixtureLoRA構造保存モード",
        "es": "[Loader] Mixture-of-LoRAs — modo preservación de estructura MixtureLoRA",
    },
    "loader.merging_lora": {
        "ko": "[Loader] LoRA 가중치 병합 중 (r={r}, alpha={alpha})...",
        "en": "[Loader] Merging LoRA weights (r={r}, alpha={alpha})...",
        "zh": "[Loader] 正在合并 LoRA 权重 (r={r}, alpha={alpha})...",
        "ja": "[Loader] LoRA重み統合中 (r={r}, alpha={alpha})...",
        "es": "[Loader] Fusionando pesos LoRA (r={r}, alpha={alpha})...",
    },
    "loader.unexpected_keys": {
        "ko": "[Loader] 병합 후 예기치 않은 키: {count}",
        "en": "[Loader] Unexpected keys after merge: {count}",
        "zh": "[Loader] 合并后出现意外键: {count}",
        "ja": "[Loader] 統合後の予期しないキー: {count}",
        "es": "[Loader] Claves inesperadas después de la fusión: {count}",
    },
    "loader.merge_missing_keys": {
        "ko": "[Loader] 병합 후 누락 키 {missing}개, 예기치 않은 키 {unexpected}개",
        "en": "[Loader] After merge: {missing} missing keys, {unexpected} unexpected keys",
        "zh": "[Loader] 合并后: {missing} 个缺失键, {unexpected} 个意外键",
        "ja": "[Loader] 統合後: 欠落キー {missing}、予期しないキー {unexpected}",
        "es": "[Loader] Después de la fusión: {missing} claves faltantes, {unexpected} claves inesperadas",
    },

    # ====================================================================
    # Export
    # ====================================================================
    "export.merged_loading": {
        "ko": "[Export] merged: 모델 로드 중... {path}",
        "en": "[Export] merged: loading model... {path}",
        "zh": "[Export] merged: 正在加载模型... {path}",
        "ja": "[Export] merged: モデル読み込み中... {path}",
        "es": "[Export] merged: cargando modelo... {path}",
    },
    "export.merged_saving": {
        "ko": "[Export] merged: 모델 저장 중... {path}",
        "en": "[Export] merged: saving model... {path}",
        "zh": "[Export] merged: 正在保存模型... {path}",
        "ja": "[Export] merged: モデル保存中... {path}",
        "es": "[Export] merged: guardando modelo... {path}",
    },
    "export.custom_moe_loading": {
        "ko": "[Export] custom_moe: state dict 로드 중... {path}",
        "en": "[Export] custom_moe: loading state dict... {path}",
        "zh": "[Export] custom_moe: 正在加载 state dict... {path}",
        "ja": "[Export] custom_moe: state dict読み込み中... {path}",
        "es": "[Export] custom_moe: cargando state dict... {path}",
    },
    "export.skip_diversity_check": {
        "ko": "[Export] skip_diversity_check=True: expert diversity guard 건너뜀",
        "en": "[Export] skip_diversity_check=True: skipping expert diversity guard",
        "zh": "[Export] skip_diversity_check=True: 跳过专家多样性检查",
        "ja": "[Export] skip_diversity_check=True: エキスパート多様性チェックをスキップ",
        "es": "[Export] skip_diversity_check=True: omitiendo verificación de diversidad de expertos",
    },

    # ====================================================================
    # Bench
    # ====================================================================
    "bench.sampling": {
        "ko": "[Bench] {path}에서 {k}개 항목 샘플링 (seed={seed})",
        "en": "[Bench] Sampling {k} items from {path} (seed={seed})",
        "zh": "[Bench] 从 {path} 采样 {k} 个项目 (seed={seed})",
        "ja": "[Bench] {path}から{k}件サンプリング (seed={seed})",
        "es": "[Bench] Muestreando {k} elementos de {path} (seed={seed})",
    },
    "bench.sampled": {
        "ko": "[Bench] {count}개 항목 샘플링 완료",
        "en": "[Bench] Sampled {count} items",
        "zh": "[Bench] 采样完成 {count} 个项目",
        "ja": "[Bench] {count}件サンプリング完了",
        "es": "[Bench] {count} elementos muestreados",
    },
    "bench.pairwise_fallback": {
        "ko": "[Bench] Pairwise에는 baseline이 필요합니다. pointwise로 전환합니다.",
        "en": "[Bench] Pairwise requires baseline. Falling back to pointwise.",
        "zh": "[Bench] Pairwise 需要 baseline。回退到 pointwise。",
        "ja": "[Bench] Pairwiseにはbaselineが必要です。pointwiseに切り替えます。",
        "es": "[Bench] Pairwise requiere baseline. Cambiando a pointwise.",
    },
    "bench.phase1_loading": {
        "ko": "[Bench] Phase 1/3: target 모델 로드 중...",
        "en": "[Bench] Phase 1/3: Loading target model...",
        "zh": "[Bench] Phase 1/3: 正在加载目标模型...",
        "ja": "[Bench] Phase 1/3: ターゲットモデル読み込み中...",
        "es": "[Bench] Phase 1/3: Cargando modelo objetivo...",
    },
    "bench.target_local": {
        "ko": "[Bench] Target (local_hf): {path}",
        "en": "[Bench] Target (local_hf): {path}",
        "zh": "[Bench] Target (local_hf): {path}",
        "ja": "[Bench] Target (local_hf): {path}",
        "es": "[Bench] Target (local_hf): {path}",
    },
    "bench.target_api": {
        "ko": "[Bench] Target: {model} ({provider})",
        "en": "[Bench] Target: {model} ({provider})",
        "zh": "[Bench] Target: {model} ({provider})",
        "ja": "[Bench] Target: {model} ({provider})",
        "es": "[Bench] Target: {model} ({provider})",
    },
    "bench.phase1_generating": {
        "ko": "[Phase1 Target] [{current}/{total}] 응답 생성 중...",
        "en": "[Phase1 Target] [{current}/{total}] Generating response...",
        "zh": "[Phase1 Target] [{current}/{total}] 正在生成响应...",
        "ja": "[Phase1 Target] [{current}/{total}] 応答生成中...",
        "es": "[Phase1 Target] [{current}/{total}] Generando respuesta...",
    },
    "bench.target_failed": {
        "ko": "[Bench] Target 응답 생성 실패: {error}",
        "en": "[Bench] Target generation failed: {error}",
        "zh": "[Bench] Target 响应生成失败: {error}",
        "ja": "[Bench] Target応答生成失敗: {error}",
        "es": "[Bench] Generación de respuesta target falló: {error}",
    },
    "bench.phase1_complete": {
        "ko": "[Bench] Phase 1 완료: target 언로드됨",
        "en": "[Bench] Phase 1 complete: target unloaded",
        "zh": "[Bench] Phase 1 完成: target 已卸载",
        "ja": "[Bench] Phase 1 完了: targetアンロード済み",
        "es": "[Bench] Phase 1 completa: target descargado",
    },
    "bench.phase2_loading": {
        "ko": "[Bench] Phase 2/3: baseline 모델 로드 중...",
        "en": "[Bench] Phase 2/3: Loading baseline model...",
        "zh": "[Bench] Phase 2/3: 正在加载 baseline 模型...",
        "ja": "[Bench] Phase 2/3: baselineモデル読み込み中...",
        "es": "[Bench] Phase 2/3: Cargando modelo baseline...",
    },
    "bench.baseline_model": {
        "ko": "[Bench] Baseline: {model}",
        "en": "[Bench] Baseline: {model}",
        "zh": "[Bench] Baseline: {model}",
        "ja": "[Bench] Baseline: {model}",
        "es": "[Bench] Baseline: {model}",
    },
    "bench.phase2_generating": {
        "ko": "[Phase2 Baseline] [{current}/{total}] 응답 생성 중...",
        "en": "[Phase2 Baseline] [{current}/{total}] Generating response...",
        "zh": "[Phase2 Baseline] [{current}/{total}] 正在生成响应...",
        "ja": "[Phase2 Baseline] [{current}/{total}] 応答生成中...",
        "es": "[Phase2 Baseline] [{current}/{total}] Generando respuesta...",
    },
    "bench.baseline_empty": {
        "ko": "[Bench] Baseline이 빈 응답을 반환했습니다 (sample {idx})",
        "en": "[Bench] Baseline returned empty response for sample {idx}",
        "zh": "[Bench] Baseline 返回了空响应 (sample {idx})",
        "ja": "[Bench] Baselineが空の応答を返しました (sample {idx})",
        "es": "[Bench] Baseline devolvió respuesta vacía para sample {idx}",
    },
    "bench.baseline_failed": {
        "ko": "[Bench] Baseline 응답 생성 실패: {error}",
        "en": "[Bench] Baseline generation failed: {error}",
        "zh": "[Bench] Baseline 响应生成失败: {error}",
        "ja": "[Bench] Baseline応答生成失敗: {error}",
        "es": "[Bench] Generación de respuesta baseline falló: {error}",
    },
    "bench.phase2_complete": {
        "ko": "[Bench] Phase 2 완료: baseline 언로드됨",
        "en": "[Bench] Phase 2 complete: baseline unloaded",
        "zh": "[Bench] Phase 2 完成: baseline 已卸载",
        "ja": "[Bench] Phase 2 完了: baselineアンロード済み",
        "es": "[Bench] Phase 2 completa: baseline descargado",
    },
    "bench.phase3_loading": {
        "ko": "[Bench] Phase 3/3: judge 모델 로드 중...",
        "en": "[Bench] Phase 3/3: Loading judge model...",
        "zh": "[Bench] Phase 3/3: 正在加载 judge 模型...",
        "ja": "[Bench] Phase 3/3: judgeモデル読み込み中...",
        "es": "[Bench] Phase 3/3: Cargando modelo judge...",
    },
    "bench.judge_model": {
        "ko": "[Bench] Judge: {model} (mode={mode})",
        "en": "[Bench] Judge: {model} (mode={mode})",
        "zh": "[Bench] Judge: {model} (mode={mode})",
        "ja": "[Bench] Judge: {model} (mode={mode})",
        "es": "[Bench] Judge: {model} (mode={mode})",
    },
    "bench.phase3_evaluating": {
        "ko": "[Phase3 Judge] [{current}/{total}] 평가 중 ({mode})...",
        "en": "[Phase3 Judge] [{current}/{total}] Evaluating ({mode})...",
        "zh": "[Phase3 Judge] [{current}/{total}] 正在评估 ({mode})...",
        "ja": "[Phase3 Judge] [{current}/{total}] 評価中 ({mode})...",
        "es": "[Phase3 Judge] [{current}/{total}] Evaluando ({mode})...",
    },
    "bench.judge_failed": {
        "ko": "[Bench] Judge 평가 실패: {error}",
        "en": "[Bench] Judge evaluation failed: {error}",
        "zh": "[Bench] Judge 评估失败: {error}",
        "ja": "[Bench] Judge評価失敗: {error}",
        "es": "[Bench] Evaluación del judge falló: {error}",
    },
    "bench.phase3_complete": {
        "ko": "[Bench] Phase 3 완료: judge 언로드됨",
        "en": "[Bench] Phase 3 complete: judge unloaded",
        "zh": "[Bench] Phase 3 完成: judge 已卸载",
        "ja": "[Bench] Phase 3 完了: judgeアンロード済み",
        "es": "[Bench] Phase 3 completa: judge descargado",
    },
    "bench.results_saved": {
        "ko": "[Bench] 결과 저장: {path}",
        "en": "[Bench] Results saved to {path}",
        "zh": "[Bench] 结果已保存到 {path}",
        "ja": "[Bench] 結果を保存しました: {path}",
        "es": "[Bench] Resultados guardados en {path}",
    },
    "bench.summary_saved": {
        "ko": "[Bench] 요약 저장: {path}",
        "en": "[Bench] Summary saved to {path}",
        "zh": "[Bench] 摘要已保存到 {path}",
        "ja": "[Bench] サマリーを保存しました: {path}",
        "es": "[Bench] Resumen guardado en {path}",
    },
    "bench.output_dir": {
        "ko": "[Bench] 출력 디렉토리: {path}",
        "en": "[Bench] Output dir: {path}",
        "zh": "[Bench] 输出目录: {path}",
        "ja": "[Bench] 出力ディレクトリ: {path}",
        "es": "[Bench] Directorio de salida: {path}",
    },
    "bench.resolved_model_dir": {
        "ko": "[Bench] 모델 디렉토리 해석 완료: {path}",
        "en": "[Bench] Resolved model_dir: {path}",
        "zh": "[Bench] 已解析模型目录: {path}",
        "ja": "[Bench] モデルディレクトリ解決済み: {path}",
        "es": "[Bench] Directorio del modelo resuelto: {path}",
    },
    "bench.local_hf_unloaded": {
        "ko": "[Bench] LocalHFClient 언로드 완료, GPU 캐시 클리어됨",
        "en": "[Bench] LocalHFClient unloaded, GPU cache cleared",
        "zh": "[Bench] LocalHFClient 已卸载, GPU 缓存已清除",
        "ja": "[Bench] LocalHFClientアンロード完了、GPUキャッシュクリア済み",
        "es": "[Bench] LocalHFClient descargado, caché GPU limpiada",
    },
    "bench.key_prefix_normalized": {
        "ko": "[LocalHFClient] 키 접두사 정규화: {msg}",
        "en": "[LocalHFClient] Key prefix normalized: {msg}",
        "zh": "[LocalHFClient] 键前缀已规范化: {msg}",
        "ja": "[LocalHFClient] キー接頭辞を正規化: {msg}",
        "es": "[LocalHFClient] Prefijo de clave normalizado: {msg}",
    },

    # ====================================================================
    # Data / Preprocessing
    # ====================================================================
    "data.using_cache": {
        "ko": "[Data] 캐시된 전처리 데이터 사용: {path}",
        "en": "[Data] Using cached preprocessed data: {path}",
        "zh": "[Data] 使用缓存的预处理数据: {path}",
        "ja": "[Data] キャッシュされた前処理データを使用: {path}",
        "es": "[Data] Usando datos preprocesados en caché: {path}",
    },
    "data.preprocessing": {
        "ko": "[Data] raw 데이터 전처리 중: {input} -> {output}",
        "en": "[Data] Preprocessing raw data: {input} -> {output}",
        "zh": "[Data] 正在预处理原始数据: {input} -> {output}",
        "ja": "[Data] rawデータ前処理中: {input} -> {output}",
        "es": "[Data] Preprocesando datos raw: {input} -> {output}",
    },
    "data.loading_sft": {
        "ko": "[Data] SFT 데이터셋 로드 중: {path}",
        "en": "[Data] Loading SFT dataset from {path}",
        "zh": "[Data] 正在加载 SFT 数据集: {path}",
        "ja": "[Data] SFTデータセット読み込み中: {path}",
        "es": "[Data] Cargando dataset SFT desde {path}",
    },
    "data.loading_dpo": {
        "ko": "[Data] {type} 데이터셋 (DPO 형식) 로드 중: {path}",
        "en": "[Data] Loading {type} dataset (DPO format) from {path}",
        "zh": "[Data] 正在加载 {type} 数据集 (DPO 格式): {path}",
        "ja": "[Data] {type}データセット (DPO形式) 読み込み中: {path}",
        "es": "[Data] Cargando dataset {type} (formato DPO) desde {path}",
    },
    "data.loading_ppo": {
        "ko": "[Data] PPO 프롬프트 데이터셋 로드 중: {path}",
        "en": "[Data] Loading PPO prompt dataset from {path}",
        "zh": "[Data] 正在加载 PPO 提示数据集: {path}",
        "ja": "[Data] PPOプロンプトデータセット読み込み中: {path}",
        "es": "[Data] Cargando dataset de prompts PPO desde {path}",
    },
    "preprocess.wrote_rows": {
        "ko": "[Preprocess] {count}개 행을 {path}에 저장했습니다",
        "en": "[Preprocess] Wrote {count} rows to {path}",
        "zh": "[Preprocess] 已将 {count} 行写入 {path}",
        "ja": "[Preprocess] {count}行を{path}に書き込みました",
        "es": "[Preprocess] {count} filas escritas en {path}",
    },
    "preprocess.wrote_rows_parallel": {
        "ko": "[Preprocess] {count}개 행을 {path}에 저장했습니다 (num_proc={num_proc})",
        "en": "[Preprocess] Wrote {count} rows to {path} (num_proc={num_proc})",
        "zh": "[Preprocess] 已将 {count} 行写入 {path} (num_proc={num_proc})",
        "ja": "[Preprocess] {count}行を{path}に書き込みました (num_proc={num_proc})",
        "es": "[Preprocess] {count} filas escritas en {path} (num_proc={num_proc})",
    },

    # ====================================================================
    # Dequantize
    # ====================================================================
    "dequantize.completed": {
        "ko": "[dequantize] {count}개 int4/nf4 양자화 텐서를 dequantize 완료",
        "en": "[dequantize] Dequantized {count} int4/nf4 quantized tensors",
        "zh": "[dequantize] 已反量化 {count} 个 int4/nf4 量化张量",
        "ja": "[dequantize] {count}個のint4/nf4量子化テンソルをdequantize完了",
        "es": "[dequantize] {count} tensores cuantizados int4/nf4 dequantizados",
    },

    # ====================================================================
    # Train
    # ====================================================================
    "train.starting": {
        "ko": "[Train] 훈련 파이프라인 시작...",
        "en": "[Train] Starting training pipeline...",
        "zh": "[Train] 正在启动训练管线...",
        "ja": "[Train] トレーニングパイプライン開始...",
        "es": "[Train] Iniciando pipeline de entrenamiento...",
    },
    "train.device": {
        "ko": "[Train] Device: {device}",
        "en": "[Train] Device: {device}",
        "zh": "[Train] Device: {device}",
        "ja": "[Train] Device: {device}",
        "es": "[Train] Device: {device}",
    },
    "train.backbone": {
        "ko": "[Train] BackboneAdapter: {name}",
        "en": "[Train] BackboneAdapter: {name}",
        "zh": "[Train] BackboneAdapter: {name}",
        "ja": "[Train] BackboneAdapter: {name}",
        "es": "[Train] BackboneAdapter: {name}",
    },
    "train.loading_model": {
        "ko": "[Train] 모델 로드 중: {name}",
        "en": "[Train] Loading model: {name}",
        "zh": "[Train] 正在加载模型: {name}",
        "ja": "[Train] モデル読み込み中: {name}",
        "es": "[Train] Cargando modelo: {name}",
    },
    "train.loading_precision": {
        "ko": "[Train] {mode} 정밀도로 모델 로드 중.",
        "en": "[Train] Loading model in {mode} precision.",
        "zh": "[Train] 以 {mode} 精度加载模型。",
        "ja": "[Train] {mode}精度でモデル読み込み中。",
        "es": "[Train] Cargando modelo en precisión {mode}.",
    },
    "train.kbit_prepared": {
        "ko": "[Train] k-bit 훈련 준비 완료 (peft helper 적용됨).",
        "en": "[Train] Model prepared for k-bit training (peft helper applied).",
        "zh": "[Train] 模型已准备好 k-bit 训练（已应用 peft helper）。",
        "ja": "[Train] k-bitトレーニング準備完了（peftヘルパー適用済み）。",
        "es": "[Train] Modelo preparado para entrenamiento k-bit (helper peft aplicado).",
    },
    "train.applying_injection": {
        "ko": "[Train] 인젝션 전략 적용 중: {strategy}",
        "en": "[Train] Applying injection strategy: {strategy}",
        "zh": "[Train] 正在应用注入策略: {strategy}",
        "ja": "[Train] インジェクション戦略適用中: {strategy}",
        "es": "[Train] Aplicando estrategia de inyección: {strategy}",
    },
    "train.injection_result": {
        "ko": "[Train] 인젝션 결과: {result}",
        "en": "[Train] Injection result: {result}",
        "zh": "[Train] 注入结果: {result}",
        "ja": "[Train] インジェクション結果: {result}",
        "es": "[Train] Resultado de inyección: {result}",
    },
    "train.no_phase_schedule": {
        "ko": "[Train] 페이즈 스케줄이 설정되지 않았습니다.",
        "en": "[Train] No phase schedule configured.",
        "zh": "[Train] 未配置阶段调度。",
        "ja": "[Train] フェーズスケジュールが設定されていません。",
        "es": "[Train] Sin programación de fases configurada.",
    },
    "train.done": {
        "ko": "[Train] 훈련 완료. 최종 step={step}",
        "en": "[Train] Training done. Final step={step}",
        "zh": "[Train] 训练完成。最终步骤={step}",
        "ja": "[Train] トレーニング完了。最終step={step}",
        "es": "[Train] Entrenamiento completado. Paso final={step}",
    },
    "train.saving_final": {
        "ko": "[Train] 최종 모델 저장 중: {path}...",
        "en": "[Train] Saving FINAL model to {path}...",
        "zh": "[Train] 正在保存最终模型到 {path}...",
        "ja": "[Train] 最終モデルを{path}に保存中...",
        "es": "[Train] Guardando modelo FINAL en {path}...",
    },
    "train.final_saved": {
        "ko": "[Train] 최종 모델 저장 완료.",
        "en": "[Train] Final model saved successfully.",
        "zh": "[Train] 最终模型保存成功。",
        "ja": "[Train] 最終モデル保存完了。",
        "es": "[Train] Modelo final guardado exitosamente.",
    },
    "train.final_save_failed": {
        "ko": "[Train] 최종 모델 저장 실패: {error}",
        "en": "[Train] Failed to save final model: {error}",
        "zh": "[Train] 保存最终模型失败: {error}",
        "ja": "[Train] 最終モデル保存失敗: {error}",
        "es": "[Train] Error al guardar modelo final: {error}",
    },
    "train.pipeline_complete": {
        "ko": "[Train] 훈련 파이프라인 완료.",
        "en": "[Train] Training pipeline complete.",
        "zh": "[Train] 训练管线完成。",
        "ja": "[Train] トレーニングパイプライン完了。",
        "es": "[Train] Pipeline de entrenamiento completado.",
    },
    "train.validation_step": {
        "ko": "[Validation] Step {step} | val_loss={loss:.6f}",
        "en": "[Validation] Step {step} | val_loss={loss:.6f}",
        "zh": "[Validation] Step {step} | val_loss={loss:.6f}",
        "ja": "[Validation] Step {step} | val_loss={loss:.6f}",
        "es": "[Validation] Step {step} | val_loss={loss:.6f}",
    },
    "train.skipping_validation": {
        "ko": "[Validation] non-SFT에서는 검증을 건너뜁니다.",
        "en": "[Validation] Skipping validation for non-SFT.",
        "zh": "[Validation] 非SFT跳过验证。",
        "ja": "[Validation] non-SFTの検証をスキップ。",
        "es": "[Validation] Omitiendo validación para non-SFT.",
    },
    "train.checkpoint_triggered": {
        "ko": "[Checkpoint] Step {step}에서 체크포인트 트리거됨.",
        "en": "[Checkpoint] Triggered at step {step}.",
        "zh": "[Checkpoint] 在步骤 {step} 触发。",
        "ja": "[Checkpoint] Step {step}でトリガー。",
        "es": "[Checkpoint] Activado en paso {step}.",
    },
    "train.checkpoint_saved": {
        "ko": "[Checkpoint] latest를 {path}에 저장했습니다",
        "en": "[Checkpoint] Saved latest to {path}",
        "zh": "[Checkpoint] 已将 latest 保存到 {path}",
        "ja": "[Checkpoint] latestを{path}に保存しました",
        "es": "[Checkpoint] Guardado latest en {path}",
    },
    "train.reward_head_saved": {
        "ko": "[Train] RewardHead를 final/reward_head.pt에 저장했습니다",
        "en": "[Train] RewardHead saved to final/reward_head.pt",
        "zh": "[Train] RewardHead 已保存到 final/reward_head.pt",
        "ja": "[Train] RewardHeadをfinal/reward_head.ptに保存しました",
        "es": "[Train] RewardHead guardado en final/reward_head.pt",
    },
    "train.detected_checkpoint": {
        "ko": "[Train] EulerForge 체크포인트 감지 (strategy={strategy}). Base 모델 로딩: {base_model}",
        "en": "[Train] Detected EulerForge checkpoint (strategy={strategy}). Loading base model: {base_model}",
        "zh": "[Train] 检测到 EulerForge 检查点 (strategy={strategy})。加载基础模型: {base_model}",
        "ja": "[Train] EulerForgeチェックポイント検出 (strategy={strategy})。ベースモデルをロード: {base_model}",
        "es": "[Train] Checkpoint de EulerForge detectado (strategy={strategy}). Cargando modelo base: {base_model}",
    },
    "train.loaded_adapter_sd": {
        "ko": "[Train] 어댑터 state_dict 로드: {path} ({count}개 키)",
        "en": "[Train] Loaded adapter state_dict from: {path} ({count} keys)",
        "zh": "[Train] 已加载适配器 state_dict: {path} ({count} 个键)",
        "ja": "[Train] アダプターstate_dictをロード: {path} ({count}キー)",
        "es": "[Train] state_dict del adaptador cargado desde: {path} ({count} claves)",
    },
    "train.loaded_adapter_params": {
        "ko": "[Train] 이전 체크포인트에서 LoRA 어댑터 파라미터 {count}개 로드 완료",
        "en": "[Train] Loaded {count} LoRA adapter parameters from previous checkpoint",
        "zh": "[Train] 从先前检查点加载了 {count} 个 LoRA 适配器参数",
        "ja": "[Train] 前のチェックポイントから {count} 個のLoRAアダプターパラメータをロード",
        "es": "[Train] {count} parámetros del adaptador LoRA cargados del checkpoint anterior",
    },
    "train.pipeline_override": {
        "ko": "[Train] 파이프라인 체크포인트 override — 이전 체크포인트의 injection 설정:\n  {details}",
        "en": "[Train] Pipeline checkpoint override — injection params from previous checkpoint:\n  {details}",
        "zh": "[Train] 管道检查点覆盖 — 来自先前检查点的注入设置:\n  {details}",
        "ja": "[Train] パイプラインチェックポイントオーバーライド — 前のチェックポイントのinjection設定:\n  {details}",
        "es": "[Train] Override del checkpoint de pipeline — parámetros de inyección del checkpoint anterior:\n  {details}",
    },
    "train.resume_found": {
        "ko": "[Resume] 체크포인트 발견. micro_step={micro_step}, optimizer_step={optimizer_step}, best_val_loss={best_val_loss}에서 재개",
        "en": "[Resume] Found existing checkpoint-latest. Resuming micro_step={micro_step}, optimizer_step={optimizer_step}, best_val_loss={best_val_loss}",
        "zh": "[Resume] 发现检查点。从 micro_step={micro_step}, optimizer_step={optimizer_step}, best_val_loss={best_val_loss} 恢复",
        "ja": "[Resume] チェックポイント発見。micro_step={micro_step}, optimizer_step={optimizer_step}, best_val_loss={best_val_loss} から再開",
        "es": "[Resume] Checkpoint encontrado. Reanudando desde micro_step={micro_step}, optimizer_step={optimizer_step}, best_val_loss={best_val_loss}",
    },
    "train.resume_lr_restored": {
        "ko": "[Resume] LR 스케줄러를 optimizer_step={optimizer_step}으로 복원, LR={lr}",
        "en": "[Resume] LR scheduler fast-forwarded to optimizer_step={optimizer_step}, LR={lr}",
        "zh": "[Resume] LR调度器快进到 optimizer_step={optimizer_step}, LR={lr}",
        "ja": "[Resume] LRスケジューラをoptimizer_step={optimizer_step}に復元、LR={lr}",
        "es": "[Resume] Scheduler LR avanzado a optimizer_step={optimizer_step}, LR={lr}",
    },
    "train.resume_failed": {
        "ko": "[Resume] 체크포인트 로드 실패: {error}",
        "en": "[Resume] Failed to load info from checkpoint: {error}",
        "zh": "[Resume] 加载检查点信息失败: {error}",
        "ja": "[Resume] チェックポイントの読み込みに失敗: {error}",
        "es": "[Resume] Error al cargar información del checkpoint: {error}",
    },
    "train.type_info": {
        "ko": "[Train] 타입: {type} | max_train_steps(micro)={max_steps} | optimizer_steps={opt_steps} (= {max_steps} micro / {accum} accum) | batch={batch} × accum={accum} = effective {effective}",
        "en": "[Train] Type: {type} | max_train_steps(micro)={max_steps} | optimizer_steps={opt_steps} (= {max_steps} micro / {accum} accum) | batch={batch} × accum={accum} = effective {effective}",
        "zh": "[Train] 类型: {type} | max_train_steps(micro)={max_steps} | optimizer_steps={opt_steps} (= {max_steps} micro / {accum} accum) | batch={batch} × accum={accum} = effective {effective}",
        "ja": "[Train] タイプ: {type} | max_train_steps(micro)={max_steps} | optimizer_steps={opt_steps} (= {max_steps} micro / {accum} accum) | batch={batch} × accum={accum} = effective {effective}",
        "es": "[Train] Tipo: {type} | max_train_steps(micro)={max_steps} | optimizer_steps={opt_steps} (= {max_steps} micro / {accum} accum) | batch={batch} × accum={accum} = effective {effective}",
    },
    "train.dpo_beta": {
        "ko": "[Train] DPO Beta: {beta}",
        "en": "[Train] DPO Beta: {beta}",
        "zh": "[Train] DPO Beta: {beta}",
        "ja": "[Train] DPO Beta: {beta}",
        "es": "[Train] DPO Beta: {beta}",
    },
    "train.phase_scheduler_info": {
        "ko": "[Train] PhaseScheduler: {count}개 페이즈, steps={steps}",
        "en": "[Train] PhaseScheduler: {count} phases, steps={steps}",
        "zh": "[Train] PhaseScheduler: {count} 个阶段, steps={steps}",
        "ja": "[Train] PhaseScheduler: {count}フェーズ, steps={steps}",
        "es": "[Train] PhaseScheduler: {count} fases, steps={steps}",
    },
    "train.cached_data": {
        "ko": "[Data] 캐시된 전처리 데이터 사용: {path}",
        "en": "[Data] Using cached preprocessed data: {path}",
        "zh": "[Data] 使用缓存的预处理数据: {path}",
        "ja": "[Data] キャッシュされた前処理データを使用: {path}",
        "es": "[Data] Usando datos preprocesados en caché: {path}",
    },

    # ====================================================================
    # Grid Search
    # ====================================================================
    "grid.trial_params": {
        "ko": "[Grid] Trial {number}: {params}",
        "en": "[Grid] Trial {number}: {params}",
        "zh": "[Grid] Trial {number}: {params}",
        "ja": "[Grid] Trial {number}: {params}",
        "es": "[Grid] Trial {number}: {params}",
    },
    "grid.trial_failed": {
        "ko": "[Grid] Trial {number} 실패 (exit code {code})",
        "en": "[Grid] Trial {number} failed (exit code {code})",
        "zh": "[Grid] Trial {number} 失败 (退出代码 {code})",
        "ja": "[Grid] Trial {number} 失敗 (exit code {code})",
        "es": "[Grid] Trial {number} falló (código de salida {code})",
    },
    "grid.summary_saved": {
        "ko": "[Grid] 요약 저장: {path}",
        "en": "[Grid] Summary saved to {path}",
        "zh": "[Grid] 摘要已保存到 {path}",
        "ja": "[Grid] サマリーを保存しました: {path}",
        "es": "[Grid] Resumen guardado en {path}",
    },
    "grid.csv_saved": {
        "ko": "[Grid] CSV 요약 저장: {path}",
        "en": "[Grid] CSV summary saved to {path}",
        "zh": "[Grid] CSV 摘要已保存到 {path}",
        "ja": "[Grid] CSVサマリーを保存しました: {path}",
        "es": "[Grid] Resumen CSV guardado en {path}",
    },

    # ====================================================================
    # Validator
    # ====================================================================
    "validator.passed": {
        "ko": "설정 검증을 통과했습니다.",
        "en": "Config validation passed.",
        "zh": "配置验证通过。",
        "ja": "設定検証をパスしました。",
        "es": "Validación de configuración aprobada.",
    },

    # ====================================================================
    # Preflight
    # ====================================================================
    "preflight.running": {
        "ko": "[Preflight] 프리플라이트 검증 실행 중...",
        "en": "[Preflight] Running preflight validation...",
        "zh": "[Preflight] 正在运行预检验证...",
        "ja": "[Preflight] プリフライト検証実行中...",
        "es": "[Preflight] Ejecutando validación previa...",
    },
    "preflight.all_passed": {
        "ko": "[Preflight] 모든 검사를 통과했습니다.",
        "en": "[Preflight] All checks passed.",
        "zh": "[Preflight] 所有检查通过。",
        "ja": "[Preflight] すべてのチェックをパスしました。",
        "es": "[Preflight] Todas las verificaciones aprobadas.",
    },

    # ====================================================================
    # CLI main
    # ====================================================================
    "cli.unknown_command": {
        "ko": "eulerforge: 알 수 없는 명령어 '{command}'",
        "en": "eulerforge: unknown command '{command}'",
        "zh": "eulerforge: 未知命令 '{command}'",
        "ja": "eulerforge: 不明なコマンド '{command}'",
        "es": "eulerforge: comando desconocido '{command}'",
    },
    "cli.run_help": {
        "ko": "'eulerforge --help'로 사용 가능한 명령어를 확인하세요.",
        "en": "Run 'eulerforge --help' for available commands.",
        "zh": "运行 'eulerforge --help' 查看可用命令。",
        "ja": "'eulerforge --help' で利用可能なコマンドを確認してください。",
        "es": "Ejecute 'eulerforge --help' para ver los comandos disponibles.",
    },

    # ====================================================================
    # LocalHFClient (bench_client.py)
    # ====================================================================
    "bench_client.float16_warning": {
        "ko": "[LocalHFClient] float16은 autoregressive 생성 시 수치 불안정을 유발할 수 있습니다. bfloat16으로 자동 변환합니다.",
        "en": "[LocalHFClient] float16 may cause numerical instability in autoregressive generation. Auto-converting to bfloat16.",
        "zh": "[LocalHFClient] float16 可能导致自回归生成中的数值不稳定。自动转换为 bfloat16。",
        "ja": "[LocalHFClient] float16はautoregressive生成で数値不安定を引き起こす可能性があります。bfloat16に自動変換します。",
        "es": "[LocalHFClient] float16 puede causar inestabilidad numérica en generación autoregresiva. Convirtiendo automáticamente a bfloat16.",
    },

    # ====================================================================
    # CLI Help — eulerforge --help
    # ====================================================================
    "help.usage": {
        "ko": "사용법: eulerforge [--lang LANG] <명령어> [옵션]",
        "en": "usage: eulerforge [--lang LANG] <command> [options]",
        "zh": "用法: eulerforge [--lang LANG] <命令> [选项]",
        "ja": "使用法: eulerforge [--lang LANG] <コマンド> [オプション]",
        "es": "uso: eulerforge [--lang LANG] <comando> [opciones]",
    },
    "help.description": {
        "ko": "EulerForge — MoE+LoRA 파인튜닝 도구",
        "en": "EulerForge — MoE+LoRA fine-tuning toolkit",
        "zh": "EulerForge — MoE+LoRA 微调工具包",
        "ja": "EulerForge — MoE+LoRAファインチューニングツールキット",
        "es": "EulerForge — kit de herramientas de ajuste fino MoE+LoRA",
    },
    "help.commands_header": {
        "ko": "명령어:",
        "en": "commands:",
        "zh": "命令:",
        "ja": "コマンド:",
        "es": "comandos:",
    },
    "help.global_options": {
        "ko": "글로벌 옵션:",
        "en": "global options:",
        "zh": "全局选项:",
        "ja": "グローバルオプション:",
        "es": "opciones globales:",
    },
    "help.lang_option": {
        "ko": "출력 언어 설정 (ko/en/zh/ja/es, 기본: ko)",
        "en": "Set output language (ko/en/zh/ja/es, default: ko)",
        "zh": "设置输出语言 (ko/en/zh/ja/es, 默认: ko)",
        "ja": "出力言語を設定 (ko/en/zh/ja/es, デフォルト: ko)",
        "es": "Establecer idioma de salida (ko/en/zh/ja/es, predeterminado: ko)",
    },
    "help.run_command_help": {
        "ko": "'eulerforge <명령어> --help'로 명령어별 옵션을 확인하세요.",
        "en": "Run 'eulerforge <command> --help' for command-specific options.",
        "zh": "运行 'eulerforge <命令> --help' 查看命令选项。",
        "ja": "'eulerforge <コマンド> --help' でコマンド別オプションを確認してください。",
        "es": "Ejecute 'eulerforge <comando> --help' para opciones específicas del comando.",
    },
    # 서브커맨드 설명
    "help.cmd.train": {
        "ko": "훈련 파이프라인 실행",
        "en": "Run training pipeline",
        "zh": "运行训练管线",
        "ja": "トレーニングパイプライン実行",
        "es": "Ejecutar pipeline de entrenamiento",
    },
    "help.cmd.convert": {
        "ko": "임의 JSONL을 표준 raw JSONL로 변환",
        "en": "Convert arbitrary JSONL to standard raw JSONL",
        "zh": "将任意 JSONL 转换为标准 raw JSONL",
        "ja": "任意のJSONLを標準raw JSONLに変換",
        "es": "Convertir JSONL arbitrario a JSONL raw estándar",
    },
    "help.cmd.preprocess": {
        "ko": "raw 데이터를 토큰화된 JSONL로 전처리",
        "en": "Preprocess raw data to tokenized JSONL",
        "zh": "将原始数据预处理为分词后的 JSONL",
        "ja": "rawデータをトークン化されたJSONLに前処理",
        "es": "Preprocesar datos raw a JSONL tokenizado",
    },
    "help.cmd.bench": {
        "ko": "추론 벤치마크 실행",
        "en": "Run inference benchmark",
        "zh": "运行推理基准测试",
        "ja": "推論ベンチマーク実行",
        "es": "Ejecutar benchmark de inferencia",
    },
    "help.cmd.eval": {
        "ko": "퍼플렉시티 평가 (스텁)",
        "en": "Evaluate perplexity (stub)",
        "zh": "评估困惑度 (存根)",
        "ja": "パープレキシティ評価 (スタブ)",
        "es": "Evaluar perplejidad (stub)",
    },
    "help.cmd.grid": {
        "ko": "하이퍼파라미터 서치 (grid / random / bayesian)",
        "en": "Hyperparameter search (grid / random / bayesian)",
        "zh": "超参数搜索 (grid / random / bayesian)",
        "ja": "ハイパーパラメータサーチ (grid / random / bayesian)",
        "es": "Búsqueda de hiperparámetros (grid / random / bayesian)",
    },
    "help.cmd.export_hf": {
        "ko": "체크포인트를 HuggingFace 포맷으로 내보내기",
        "en": "Export checkpoint to HuggingFace format",
        "zh": "将检查点导出为 HuggingFace 格式",
        "ja": "チェックポイントをHuggingFace形式にエクスポート",
        "es": "Exportar checkpoint a formato HuggingFace",
    },
    "help.cmd.pretrain": {
        "ko": "조립된 모델 스크래치 사전훈련 (EulerStack 등)",
        "en": "Scratch pretraining for assembled models (EulerStack, etc.)",
        "zh": "组装模型从头预训练 (EulerStack 等)",
        "ja": "組み立てモデルのスクラッチ事前学習 (EulerStack等)",
        "es": "Preentrenamiento desde cero para modelos ensamblados (EulerStack, etc.)",
    },

    # ====================================================================
    # CLI Help — train subcommand
    # ====================================================================
    "help.train.description": {
        "ko": "EulerForge — 훈련 파이프라인 (프리셋 + 오버라이드)",
        "en": "EulerForge — training pipeline (preset + overrides)",
        "zh": "EulerForge — 训练管线 (预设 + 覆盖)",
        "ja": "EulerForge — トレーニングパイプライン (プリセット + オーバーライド)",
        "es": "EulerForge — pipeline de entrenamiento (preset + overrides)",
    },
    "help.train.preset": {
        "ko": "YAML 프리셋 경로 (configs/presets/*.yml)",
        "en": "YAML preset path (configs/presets/*.yml).",
        "zh": "YAML 预设路径 (configs/presets/*.yml)",
        "ja": "YAMLプリセットパス (configs/presets/*.yml)",
        "es": "Ruta del preset YAML (configs/presets/*.yml)",
    },
    "help.train.set": {
        "ko": "설정 dot-path key=value 오버라이드",
        "en": "Override config dot-path key=value.",
        "zh": "覆盖配置 dot-path key=value",
        "ja": "設定 dot-path key=value オーバーライド",
        "es": "Sobrescribir configuración dot-path key=value",
    },
    "help.train.output_dir": {
        "ko": "출력 디렉토리",
        "en": "Output dir.",
        "zh": "输出目录",
        "ja": "出力ディレクトリ",
        "es": "Directorio de salida",
    },
    "help.train.validate_only": {
        "ko": "설정 검증만 수행, 훈련하지 않음",
        "en": "Only resolve and save config; do not train.",
        "zh": "仅验证并保存配置；不训练",
        "ja": "設定の解決と保存のみ。トレーニングは行わない。",
        "es": "Solo resolver y guardar configuración; no entrenar.",
    },
    "help.train.preflight": {
        "ko": "모델 로드 + 인젝션 + 1-step dummy forward (훈련 없음)",
        "en": "Load model + injection + 1-step dummy forward (no training).",
        "zh": "加载模型 + 注入 + 1步虚拟前向（不训练）",
        "ja": "モデルロード + インジェクション + 1ステップダミーforward（トレーニングなし）",
        "es": "Cargar modelo + inyección + 1-paso forward dummy (sin entrenamiento).",
    },
    "help.train.debug": {
        "ko": "상세 디버그 로깅 활성화",
        "en": "Enable very verbose debug logging.",
        "zh": "启用详细调试日志",
        "ja": "詳細デバッグロギング有効化",
        "es": "Activar registro de depuración detallado.",
    },
    "help.train.run_name": {
        "ko": "선택적 실행 이름 접미사",
        "en": "Optional run name suffix.",
        "zh": "可选的运行名称后缀",
        "ja": "オプションの実行名サフィックス",
        "es": "Sufijo de nombre de ejecución opcional.",
    },
    "help.train.print_config": {
        "ko": "해석된 설정 JSON 출력",
        "en": "Print resolved config JSON.",
        "zh": "打印解析后的配置 JSON",
        "ja": "解決済み設定JSONを出力",
        "es": "Imprimir JSON de configuración resuelta.",
    },
    "help.train.metrics_level": {
        "ko": "메트릭 수준: minimal (기본) 또는 advanced (+ MoE 라우팅 통계)",
        "en": "Metrics level: minimal (default) or advanced (+ MoE routing stats).",
        "zh": "指标级别: minimal (默认) 或 advanced (+ MoE 路由统计)",
        "ja": "メトリクスレベル: minimal (デフォルト) または advanced (+ MoEルーティング統計)",
        "es": "Nivel de métricas: minimal (predeterminado) o advanced (+ stats de enrutamiento MoE).",
    },
    "help.train.debug_every": {
        "ko": "N 스텝마다 디버그 로그 출력",
        "en": "Debug logs every N steps.",
        "zh": "每 N 步输出调试日志",
        "ja": "Nステップごとにデバッグログ出力",
        "es": "Registros de depuración cada N pasos.",
    },
    "help.train.debug_max_modules": {
        "ko": "디버그 섹션당 최대 모듈 출력 수",
        "en": "Max modules to print per debug section.",
        "zh": "每个调试部分打印的最大模块数",
        "ja": "デバッグセクションごとの最大モジュール出力数",
        "es": "Máximo de módulos a imprimir por sección de depuración.",
    },
    "help.train.debug_topk_grad": {
        "ko": "상위 K개 gradient norm 출력",
        "en": "Top-K grad norms to print.",
        "zh": "打印 Top-K 梯度范数",
        "ja": "Top-K勾配ノルム出力",
        "es": "Top-K normas de gradiente a imprimir.",
    },
    "help.train.debug_attn": {
        "ko": "어텐션 프로젝션 요약도 출력",
        "en": "Also print attention projection summaries.",
        "zh": "同时打印注意力投影摘要",
        "ja": "アテンションプロジェクション要約も出力",
        "es": "También imprimir resúmenes de proyección de atención.",
    },
    "help.train.debug_trainable_names": {
        "ko": "학습 가능 파라미터 이름 출력 (상위 일부만 표시)",
        "en": "Dump trainable parameter names (truncated).",
        "zh": "输出可训练参数名称（仅显示部分）",
        "ja": "学習可能パラメータ名を出力（一部のみ表示）",
        "es": "Mostrar nombres de parámetros entrenables (parcial).",
    },

    # bench 추가 옵션
    "help.bench.output_dir": {
        "ko": "벤치 결과 출력 디렉토리 (bench.output.out_dir 오버라이드)",
        "en": "Output directory for bench results (overrides bench.output.out_dir)",
        "zh": "基准测试结果输出目录（覆盖 bench.output.out_dir）",
        "ja": "ベンチ結果出力ディレクトリ（bench.output.out_dirをオーバーライド）",
        "es": "Directorio de salida para resultados bench (sobrescribe bench.output.out_dir)",
    },
    "help.bench.target_output_dir": {
        "ko": "target 로컬 모델: 학습 출력 루트 디렉토리",
        "en": "Override bench.models.target.output_dir (training run root dir)",
        "zh": "目标本地模型：训练输出根目录",
        "ja": "ターゲットローカルモデル：学習出力ルートディレクトリ",
        "es": "Modelo local target: directorio raíz de salida de entrenamiento",
    },
    "help.bench.checkpoint": {
        "ko": "체크포인트 유형: final (기본) | latest | best",
        "en": "Checkpoint type: final (default) | latest | best",
        "zh": "检查点类型: final (默认) | latest | best",
        "ja": "チェックポイントタイプ: final (デフォルト) | latest | best",
        "es": "Tipo de checkpoint: final (predeterminado) | latest | best",
    },
    "help.bench.target_model_dir": {
        "ko": "target 로컬 모델: HF save_pretrained 디렉토리 직접 지정",
        "en": "Override target model dir (HF save_pretrained path)",
        "zh": "目标本地模型：直接指定 HF save_pretrained 目录",
        "ja": "ターゲットモデルディレクトリ直接指定（HF save_pretrained パス）",
        "es": "Directorio del modelo target (ruta HF save_pretrained)",
    },
    "help.bench.target_device": {
        "ko": "target 로컬 모델 device 오버라이드 (예: cuda:0, cpu). 기본: auto",
        "en": "Target local model device override (e.g., cuda:0, cpu). Default: auto",
        "zh": "目标本地模型设备覆盖 (如 cuda:0, cpu). 默认: auto",
        "ja": "ターゲットローカルモデルdeviceオーバーライド（例: cuda:0, cpu）。デフォルト: auto",
        "es": "Override de device del modelo local target (ej: cuda:0, cpu). Default: auto",
    },

    # export-hf 옵션
    "help.export.checkpoint": {
        "ko": "run_dir 또는 checkpoint_dir 경로",
        "en": "Path to run_dir or checkpoint_dir",
        "zh": "run_dir 或 checkpoint_dir 路径",
        "ja": "run_dirまたはcheckpoint_dirパス",
        "es": "Ruta a run_dir o checkpoint_dir",
    },
    "help.export.output": {
        "ko": "HF 포맷 출력 디렉토리",
        "en": "Output directory for HF format",
        "zh": "HF 格式输出目录",
        "ja": "HF形式出力ディレクトリ",
        "es": "Directorio de salida en formato HF",
    },

    # preprocess 옵션
    "help.preprocess.task": {
        "ko": "작업 유형: sft, preference, prompted_preference",
        "en": "Task type: sft, preference, prompted_preference",
        "zh": "任务类型: sft, preference, prompted_preference",
        "ja": "タスクタイプ: sft, preference, prompted_preference",
        "es": "Tipo de tarea: sft, preference, prompted_preference",
    },
    "help.preprocess.input": {
        "ko": "입력 raw JSONL 경로",
        "en": "Input raw JSONL path",
        "zh": "输入原始 JSONL 路径",
        "ja": "入力raw JSONLパス",
        "es": "Ruta del JSONL raw de entrada",
    },
    "help.preprocess.output": {
        "ko": "출력 processed JSONL 경로",
        "en": "Output processed JSONL path",
        "zh": "输出处理后的 JSONL 路径",
        "ja": "出力processed JSONLパス",
        "es": "Ruta del JSONL procesado de salida",
    },
    "help.preprocess.model_name": {
        "ko": "HuggingFace 모델/토크나이저 이름 (예: Qwen/Qwen3.5-0.8B-Base)",
        "en": "HuggingFace model/tokenizer name (e.g. Qwen/Qwen3.5-0.8B-Base)",
        "zh": "HuggingFace 模型/分词器名称 (例如 Qwen/Qwen3.5-0.8B-Base)",
        "ja": "HuggingFaceモデル/トークナイザー名 (例: Qwen/Qwen3.5-0.8B-Base)",
        "es": "Nombre del modelo/tokenizer HuggingFace (ej: Qwen/Qwen3.5-0.8B-Base)",
    },
    "help.preprocess.max_length": {
        "ko": "최대 시퀀스 길이 (기본: 512)",
        "en": "Max sequence length (default: 512)",
        "zh": "最大序列长度 (默认: 512)",
        "ja": "最大シーケンス長 (デフォルト: 512)",
        "es": "Longitud máxima de secuencia (predeterminado: 512)",
    },

    # ====================================================================
    # CLI Help — bench subcommand
    # ====================================================================
    "help.bench.description": {
        "ko": "EulerForge — 추론 벤치마크 (API 또는 로컬 HF 모델)",
        "en": "EulerForge — inference benchmark (API or local HF model)",
        "zh": "EulerForge — 推理基准测试 (API 或本地 HF 模型)",
        "ja": "EulerForge — 推論ベンチマーク (API またはローカル HF モデル)",
        "es": "EulerForge — benchmark de inferencia (API o modelo HF local)",
    },
    "help.bench.preset": {
        "ko": "벤치 YAML 스펙 파일 경로",
        "en": "Path to bench YAML spec file",
        "zh": "基准测试 YAML 规范文件路径",
        "ja": "ベンチYAMLスペックファイルパス",
        "es": "Ruta al archivo YAML de especificación bench",
    },
    "help.bench.set": {
        "ko": "설정 오버라이드 (예: --set bench.sample.k=5)",
        "en": "Override config keys (e.g., --set bench.sample.k=5)",
        "zh": "覆盖配置键 (例如 --set bench.sample.k=5)",
        "ja": "設定オーバーライド (例: --set bench.sample.k=5)",
        "es": "Sobrescribir claves de config (ej: --set bench.sample.k=5)",
    },
    "help.bench.validate_only": {
        "ko": "설정 검증 후 종료",
        "en": "Validate config and exit",
        "zh": "验证配置后退出",
        "ja": "設定検証後終了",
        "es": "Validar configuración y salir",
    },
    "help.bench.dry_run": {
        "ko": "데이터 샘플링만 수행 (모델 호출 없음)",
        "en": "Sample data and show prompts without calling models",
        "zh": "仅采样数据和显示提示（不调用模型）",
        "ja": "データサンプリングのみ（モデル呼び出しなし）",
        "es": "Muestrear datos y mostrar prompts sin llamar modelos",
    },

    # ====================================================================
    # CLI Help — preprocess subcommand
    # ====================================================================
    "help.preprocess.description": {
        "ko": "EulerForge — raw JSONL을 토큰화된 포맷으로 전처리",
        "en": "EulerForge — preprocess raw JSONL to tokenized format",
        "zh": "EulerForge — 将原始 JSONL 预处理为分词格式",
        "ja": "EulerForge — rawJSONLをトークン化形式に前処理",
        "es": "EulerForge — preprocesar JSONL raw a formato tokenizado",
    },

    # ====================================================================
    # CLI Help — export-hf subcommand
    # ====================================================================
    "help.export.description": {
        "ko": "EulerForge — HuggingFace 포맷으로 체크포인트 내보내기",
        "en": "EulerForge — export checkpoint to HuggingFace format",
        "zh": "EulerForge — 将检查点导出为 HuggingFace 格式",
        "ja": "EulerForge — チェックポイントをHuggingFace形式にエクスポート",
        "es": "EulerForge — exportar checkpoint a formato HuggingFace",
    },

    # ====================================================================
    # CLI Help — grid subcommand
    # ====================================================================
    "help.grid.description": {
        "ko": "EulerForge — 하이퍼파라미터 서치 (Optuna 기반)",
        "en": "EulerForge — hyperparameter search (Optuna-based)",
        "zh": "EulerForge — 超参数搜索（基于 Optuna）",
        "ja": "EulerForge — ハイパーパラメータサーチ（Optuna基盤）",
        "es": "EulerForge — búsqueda de hiperparámetros (basada en Optuna)",
    },
    "help.grid.spec": {
        "ko": "Grid search YAML 스펙 파일 경로",
        "en": "Grid search YAML spec file path",
        "zh": "Grid search YAML 规范文件路径",
        "ja": "Grid search YAMLスペックファイルパス",
        "es": "Ruta del archivo YAML de especificación grid search",
    },
    "help.grid.dry_run": {
        "ko": "스펙 검증만 수행, 실제 학습 없음",
        "en": "Validate spec only; do not run training",
        "zh": "仅验证规范；不运行训练",
        "ja": "スペック検証のみ。実際のトレーニングなし。",
        "es": "Solo validar especificación; no ejecutar entrenamiento",
    },
    "help.grid.project_root": {
        "ko": "상대 경로 기준 디렉토리 (기본: 현재 디렉토리)",
        "en": "Base directory for relative paths (default: current directory)",
        "zh": "相对路径基准目录（默认: 当前目录）",
        "ja": "相対パスの基準ディレクトリ（デフォルト: 現在のディレクトリ）",
        "es": "Directorio base para rutas relativas (predeterminado: directorio actual)",
    },

    # ====================================================================
    # CLI Help — eval subcommand
    # ====================================================================
    "help.eval.description": {
        "ko": "EulerForge — 퍼플렉시티 평가 (스텁, 미구현)",
        "en": "EulerForge — evaluate perplexity (stub)",
        "zh": "EulerForge — 评估困惑度 (存根)",
        "ja": "EulerForge — パープレキシティ評価 (スタブ)",
        "es": "EulerForge — evaluar perplejidad (stub)",
    },
    "help.eval.stub_message": {
        "ko": "[EulerForge] Eval 스텁 — 아직 구현되지 않았습니다",
        "en": "[EulerForge] Eval stub — not yet implemented",
        "zh": "[EulerForge] Eval 存根 — 尚未实现",
        "ja": "[EulerForge] Evalスタブ — 未実装",
        "es": "[EulerForge] Eval stub — aún no implementado",
    },

    # ====================================================================
    # CLI Help — convert subcommand
    # ====================================================================
    "help.convert.description": {
        "ko": "EulerForge — 임의 JSONL을 표준 raw JSONL로 변환",
        "en": "EulerForge — convert arbitrary JSONL to standard raw JSONL",
        "zh": "EulerForge — 将任意 JSONL 转换为标准 raw JSONL",
        "ja": "EulerForge — 任意のJSONLを標準raw JSONLに変換",
        "es": "EulerForge — convertir JSONL arbitrario a JSONL raw estándar",
    },
    "help.convert.task": {
        "ko": "대상 작업: sft, preference, prompted_preference",
        "en": "Target task: sft, preference, prompted_preference",
        "zh": "目标任务: sft, preference, prompted_preference",
        "ja": "対象タスク: sft, preference, prompted_preference",
        "es": "Tarea objetivo: sft, preference, prompted_preference",
    },
    "help.convert.input": {
        "ko": "입력 JSONL 경로",
        "en": "Input JSONL path",
        "zh": "输入 JSONL 路径",
        "ja": "入力JSONLパス",
        "es": "Ruta del JSONL de entrada",
    },
    "help.convert.output": {
        "ko": "출력 표준 raw JSONL 경로 (--validate / --print-sample-flat에는 불필요)",
        "en": "Output standard raw JSONL path (not required for --validate / --print-sample-flat)",
        "zh": "输出标准 raw JSONL 路径 (--validate / --print-sample-flat 不需要)",
        "ja": "出力標準raw JSONLパス (--validate / --print-sample-flat には不要)",
        "es": "Ruta del JSONL raw de salida (no requerido para --validate / --print-sample-flat)",
    },
    "help.convert.recipe": {
        "ko": "내장 레시피 이름 (예: sft_messages_v1, sft_instruction_output)",
        "en": "Built-in recipe name (e.g. sft_messages_v1, sft_instruction_output)",
        "zh": "内置配方名称 (例如 sft_messages_v1, sft_instruction_output)",
        "ja": "組み込みレシピ名 (例: sft_messages_v1, sft_instruction_output)",
        "es": "Nombre de receta incorporada (ej: sft_messages_v1, sft_instruction_output)",
    },
    "help.convert.messages_expr": {
        "ko": "messages 배열의 dot-path (--recipe sft_messages에 필요)",
        "en": "Dot-path to messages array (required for --recipe sft_messages)",
        "zh": "messages 数组的 dot-path (--recipe sft_messages 需要)",
        "ja": "messages配列のdot-path (--recipe sft_messagesに必要)",
        "es": "Dot-path al array de messages (requerido para --recipe sft_messages)",
    },
    "help.convert.map": {
        "ko": "출력 키를 필드 표현식에 매핑 (반복 가능). 예: --map prompt=instruction --map response=output",
        "en": "Map output key to field expression (repeatable). e.g. --map prompt=instruction --map response=output",
        "zh": "将输出键映射到字段表达式（可重复）。例如 --map prompt=instruction --map response=output",
        "ja": "出力キーをフィールド式にマッピング（繰り返し可能）。例: --map prompt=instruction --map response=output",
        "es": "Mapear clave de salida a expresión de campo (repetible). ej: --map prompt=instruction --map response=output",
    },
    "help.convert.flatten": {
        "ko": "평탄화 모드: 'dot' (기본) 중첩 dict를 dot-key로 평탄화; 'none' dot-path 탐색만",
        "en": "Flatten mode: 'dot' (default) flattens nested dicts to dot-keys; 'none' uses dot-path navigation only",
        "zh": "展平模式: 'dot' (默认) 将嵌套 dict 展平为 dot-key; 'none' 仅使用 dot-path 导航",
        "ja": "フラット化モード: 'dot' (デフォルト) ネストされたdictをdot-keyにフラット化; 'none' dot-pathナビゲーションのみ",
        "es": "Modo de aplanamiento: 'dot' (predeterminado) aplana dicts anidados a dot-keys; 'none' solo navegación dot-path",
    },
    "help.convert.join_sep": {
        "ko": "list[str] 값의 구분자 (기본: 줄바꿈)",
        "en": "Separator for list[str] values (default: newline)",
        "zh": "list[str] 值的分隔符 (默认: 换行符)",
        "ja": "list[str]値のセパレータ (デフォルト: 改行)",
        "es": "Separador para valores list[str] (predeterminado: nueva línea)",
    },
    "help.convert.strict": {
        "ko": "값이 None/빈 문자열/빈 리스트이면 에러 발생",
        "en": "Error if a resolved value is None/empty/[]",
        "zh": "如果解析值为 None/空字符串/空列表则报错",
        "ja": "解決された値がNone/空文字列/空リストならエラー",
        "es": "Error si un valor resuelto es None/vacío/[]",
    },
    "help.convert.num_proc": {
        "ko": "병렬 워커 수 (기본: 1)",
        "en": "Number of parallel workers (default: 1)",
        "zh": "并行工作器数量 (默认: 1)",
        "ja": "並列ワーカー数 (デフォルト: 1)",
        "es": "Número de workers paralelos (predeterminado: 1)",
    },
    "help.convert.overwrite": {
        "ko": "출력 파일이 존재하면 덮어쓰기",
        "en": "Overwrite output if it exists",
        "zh": "如果输出文件存在则覆盖",
        "ja": "出力ファイルが存在する場合上書き",
        "es": "Sobrescribir salida si existe",
    },
    "help.convert.max_rows": {
        "ko": "변환할 최대 행 수 (샘플링용)",
        "en": "Maximum rows to convert (for sampling)",
        "zh": "最大转换行数（用于采样）",
        "ja": "変換する最大行数（サンプリング用）",
        "es": "Máximo de filas a convertir (para muestreo)",
    },
    "help.convert.validate": {
        "ko": "검증 전용 모드: 입력 파일 스키마 검사, 변환 없음",
        "en": "Validate-only mode: check input file schema, no conversion",
        "zh": "仅验证模式: 检查输入文件架构，不转换",
        "ja": "検証専用モード: 入力ファイルスキーマチェック、変換なし",
        "es": "Modo solo validación: verificar esquema del archivo de entrada, sin conversión",
    },
    "help.convert.print_sample": {
        "ko": "첫 1-2행을 평탄화하여 필드 탐색용으로 출력 후 종료",
        "en": "Print first 1-2 rows flattened for field discovery, then exit",
        "zh": "打印前 1-2 行展平结果用于字段发现，然后退出",
        "ja": "フィールド探索用に最初の1-2行をフラット化して出力後終了",
        "es": "Imprimir primeras 1-2 filas aplanadas para descubrimiento de campos, luego salir",
    },

    # export-hf 추가 옵션
    "help.export.format": {
        "ko": "export 포맷 (기본: auto)",
        "en": "Export format (default: auto)",
        "zh": "导出格式 (默认: auto)",
        "ja": "エクスポート形式 (デフォルト: auto)",
        "es": "Formato de exportación (predeterminado: auto)",
    },
    "help.export.select_checkpoint": {
        "ko": "run_dir일 때 체크포인트 선택 (기본: final)",
        "en": "Checkpoint selection for run_dir (default: final)",
        "zh": "run_dir 时检查点选择 (默认: final)",
        "ja": "run_dir時のチェックポイント選択 (デフォルト: final)",
        "es": "Selección de checkpoint para run_dir (predeterminado: final)",
    },
    "help.export.dtype": {
        "ko": "export dtype (기본: auto)",
        "en": "Export dtype (default: auto)",
        "zh": "导出 dtype (默认: auto)",
        "ja": "エクスポートdtype (デフォルト: auto)",
        "es": "dtype de exportación (predeterminado: auto)",
    },
    "help.export.safe_serialization": {
        "ko": "safetensors 사용 여부 (기본: True)",
        "en": "Use safetensors (default: True)",
        "zh": "是否使用 safetensors (默认: True)",
        "ja": "safetensors使用 (デフォルト: True)",
        "es": "Usar safetensors (predeterminado: True)",
    },
    "help.export.copy_tokenizer": {
        "ko": "tokenizer 복사 여부 (기본: True)",
        "en": "Copy tokenizer (default: True)",
        "zh": "是否复制 tokenizer (默认: True)",
        "ja": "tokenizerコピー (デフォルト: True)",
        "es": "Copiar tokenizer (predeterminado: True)",
    },
    "help.export.dry_run": {
        "ko": "계획만 출력, 실제 export 없음",
        "en": "Print plan only, no actual export",
        "zh": "仅输出计划，不实际导出",
        "ja": "計画のみ出力、実際のエクスポートなし",
        "es": "Solo imprimir plan, sin exportación real",
    },
    "help.export.validate_only": {
        "ko": "검증만 수행",
        "en": "Validate only",
        "zh": "仅验证",
        "ja": "検証のみ",
        "es": "Solo validar",
    },
    "help.export.skip_diversity": {
        "ko": "Expert diversity check 건너뛰기 (경량 훈련 시)",
        "en": "Skip expert diversity check (for lightweight training)",
        "zh": "跳过专家多样性检查（轻量训练时）",
        "ja": "エキスパート多様性チェックをスキップ（軽量トレーニング時）",
        "es": "Omitir verificación de diversidad de expertos (para entrenamiento ligero)",
    },

    # preprocess 추가 옵션
    "help.preprocess.num_proc": {
        "ko": "병렬 워커 수 (기본: CPU 코어의 절반)",
        "en": "Number of parallel workers (default: half of CPU cores)",
        "zh": "并行工作器数量 (默认: CPU 核心数的一半)",
        "ja": "並列ワーカー数 (デフォルト: CPUコア数の半分)",
        "es": "Número de workers paralelos (predeterminado: mitad de núcleos CPU)",
    },

    # ====================================================================
    # CLI Help — pretrain subcommand
    # ====================================================================
    "help.pretrain.description": {
        "ko": "EulerForge — 조립된 모델 스크래치 사전훈련",
        "en": "EulerForge — scratch pretraining for assembled models",
        "zh": "EulerForge — 组装模型从头预训练",
        "ja": "EulerForge — 組み立てモデルのスクラッチ事前学習",
        "es": "EulerForge — preentrenamiento desde cero para modelos ensamblados",
    },
    "help.pretrain.preset": {
        "ko": "pretrain YAML 프리셋 경로",
        "en": "Pretrain YAML preset path",
        "zh": "预训练 YAML 预设路径",
        "ja": "pretrain YAMLプリセットパス",
        "es": "Ruta del preset YAML de preentrenamiento",
    },
    "help.pretrain.set": {
        "ko": "설정 오버라이드 (예: --set training.lr=1e-4)",
        "en": "Override config (e.g., --set training.lr=1e-4)",
        "zh": "覆盖配置 (例如 --set training.lr=1e-4)",
        "ja": "設定オーバーライド (例: --set training.lr=1e-4)",
        "es": "Sobrescribir config (ej: --set training.lr=1e-4)",
    },
    "help.pretrain.output_dir": {
        "ko": "출력 디렉토리 (기본: outputs/pretrain_YYYYMMDD_HHMMSS)",
        "en": "Output directory (default: outputs/pretrain_YYYYMMDD_HHMMSS)",
        "zh": "输出目录 (默认: outputs/pretrain_YYYYMMDD_HHMMSS)",
        "ja": "出力ディレクトリ (デフォルト: outputs/pretrain_YYYYMMDD_HHMMSS)",
        "es": "Directorio de salida (predeterminado: outputs/pretrain_YYYYMMDD_HHMMSS)",
    },
    "help.pretrain.validate_only": {
        "ko": "설정 검증만 수행, 훈련하지 않음",
        "en": "Validate config only; do not train",
        "zh": "仅验证配置；不训练",
        "ja": "設定検証のみ。トレーニングは行わない。",
        "es": "Solo validar configuración; no entrenar",
    },
}
