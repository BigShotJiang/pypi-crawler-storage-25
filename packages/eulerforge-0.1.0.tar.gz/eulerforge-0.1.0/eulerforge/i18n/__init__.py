# eulerforge/i18n/__init__.py
# -*- coding: utf-8 -*-
"""
EulerForge 국제화(i18n) 모듈.

사용법:
    from eulerforge.i18n import t, set_lang, get_lang

    set_lang("en")  # 또는 EULERFORGE_LANG=en 환경변수
    logger.info(t("loader.merging_lora", r=48, alpha=96.0))

지원 언어: ko (기본), en, zh, ja, es
"""
from __future__ import annotations

import os
from typing import Any

# 지원 언어 목록
SUPPORTED_LANGS = ("ko", "en", "zh", "ja", "es")
DEFAULT_LANG = "ko"

# 현재 언어 상태 (모듈 레벨 싱글턴)
_current_lang: str = os.environ.get("EULERFORGE_LANG", DEFAULT_LANG)


def set_lang(lang: str) -> None:
    """출력 언어를 설정한다."""
    global _current_lang
    if lang not in SUPPORTED_LANGS:
        raise ValueError(
            f"Unsupported language: {lang!r}. "
            f"Supported: {', '.join(SUPPORTED_LANGS)}"
        )
    _current_lang = lang


def get_lang() -> str:
    """현재 설정된 출력 언어를 반환한다."""
    return _current_lang


def t(key: str, **kwargs: Any) -> str:
    """메시지 키를 현재 언어로 번역하여 반환한다.

    Parameters
    ----------
    key : str
        메시지 키 (예: "loader.merging_lora")
    **kwargs :
        format 인자 (예: r=48, alpha=96.0)

    Returns
    -------
    str
        번역된 메시지. 키가 없으면 키 자체를 반환.
    """
    from .messages import MESSAGES

    msg_dict = MESSAGES.get(key)
    if msg_dict is None:
        # 키가 없으면 키 자체 반환 (fallback)
        return key.format(**kwargs) if kwargs else key

    # 현재 언어 → 한국어 fallback → 영어 fallback → 키 자체
    template = (
        msg_dict.get(_current_lang)
        or msg_dict.get("ko")
        or msg_dict.get("en")
        or key
    )

    try:
        return template.format(**kwargs) if kwargs else template
    except (KeyError, IndexError):
        return template
