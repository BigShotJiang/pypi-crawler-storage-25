# eulerforge/phase_schedules/universal.py
"""
Universal Phase Scheduler: a single, data-driven, declarative scheduler.

Phases are defined as a sorted list of PhaseSpec entries. At each training
step, the scheduler checks whether a phase transition should occur and
adjusts requires_grad flags accordingly.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

import torch.nn as nn

from .groups import KNOWN_GROUPS, set_trainable_by_groups

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PhaseSpec:
    """Specification for a single training phase."""
    step: int
    trainable: List[str]
    mode: str = "replace"  # "replace" or "add"
    # Optional targeting kwargs
    base_ffn_keywords: Optional[List[str]] = None
    target_layers: Optional[List[int]] = None

    def __post_init__(self):
        if self.step < 0:
            raise ValueError(f"PhaseSpec step must be >= 0, got {self.step}")
        if not isinstance(self.trainable, (list, tuple)):
            raise TypeError(f"PhaseSpec trainable must be a list, got {type(self.trainable).__name__}")
        if self.mode not in ("replace", "add"):
            raise ValueError(f"PhaseSpec mode must be 'replace' or 'add', got '{self.mode}'")


class UniversalPhaseScheduler:
    """
    Universal phase scheduler that controls parameter training based on
    step-driven phase transitions.

    Usage:
        scheduler = UniversalPhaseScheduler(phases=[...])
        scheduler.apply_phase(model, 0)  # initial setup
        ...
        if scheduler.maybe_step(model, step):
            # phase changed, rebuild optimizer
    """

    def __init__(
        self,
        phases: Sequence[PhaseSpec],
        dequantize_dtype: Optional["torch.dtype"] = None,
    ) -> None:
        if not phases:
            raise ValueError("UniversalPhaseScheduler requires at least one phase.")

        # Sort phases by step and validate monotonicity
        sorted_phases = sorted(phases, key=lambda p: p.step)

        # Validate: no duplicate steps
        seen_steps = set()
        for p in sorted_phases:
            if p.step in seen_steps:
                raise ValueError(f"Duplicate phase step: {p.step}")
            seen_steps.add(p.step)

        self._phases: List[PhaseSpec] = sorted_phases
        self._current_phase_idx: int = -1  # not yet initialized
        self._last_applied_step: int = -1
        self._dequantize_dtype = dequantize_dtype

    @property
    def phases(self) -> List[PhaseSpec]:
        return list(self._phases)

    @property
    def current_phase_idx(self) -> int:
        return self._current_phase_idx

    @property
    def current_phase(self) -> Optional[PhaseSpec]:
        if 0 <= self._current_phase_idx < len(self._phases):
            return self._phases[self._current_phase_idx]
        return None

    @property
    def num_phases(self) -> int:
        return len(self._phases)

    def _find_phase_for_step(self, step: int) -> int:
        """Find the index of the phase that should be active at a given step."""
        idx = -1
        for i, phase in enumerate(self._phases):
            if step >= phase.step:
                idx = i
            else:
                break
        return idx

    def apply_phase(self, model: nn.Module, step: int) -> bool:
        """
        Apply the appropriate phase for the given step.
        Returns True if a phase change occurred.
        """
        target_idx = self._find_phase_for_step(step)
        if target_idx < 0:
            return False

        if target_idx == self._current_phase_idx:
            return False

        phase = self._phases[target_idx]
        old_idx = self._current_phase_idx
        self._current_phase_idx = target_idx

        count = set_trainable_by_groups(
            model,
            active_groups=phase.trainable,
            mode=phase.mode,
            base_ffn_keywords=phase.base_ffn_keywords,
            target_layers=phase.target_layers,
            dequantize_dtype=self._dequantize_dtype,
        )

        logger.info(
            "Phase transition: phase %d -> %d (step=%d, trainable_groups=%s, "
            "mode=%s, trainable_params=%d)",
            old_idx, target_idx, step, phase.trainable, phase.mode, count,
        )

        return True

    def maybe_step(self, model: nn.Module, step: int) -> bool:
        """
        Check if a phase transition should occur and apply it.

        This is the primary API called from the training loop.
        Returns True if a phase change occurred (caller should rebuild optimizer).
        Idempotent: calling with the same step repeatedly returns False after first.
        """
        if step == self._last_applied_step and self._current_phase_idx >= 0:
            return False

        self._last_applied_step = step
        return self.apply_phase(model, step)

    def get_active_groups(self) -> List[str]:
        """Get the currently active training groups."""
        if self.current_phase is None:
            return []
        return list(self.current_phase.trainable)

    def get_phase_info(self) -> Dict[str, Any]:
        """Get current phase information for logging."""
        return {
            "phase_idx": self._current_phase_idx,
            "num_phases": len(self._phases),
            "current_phase": {
                "step": self.current_phase.step if self.current_phase else None,
                "trainable": self.current_phase.trainable if self.current_phase else [],
                "mode": self.current_phase.mode if self.current_phase else None,
            },
        }

