# eulerforge/phase_schedules/__init__.py
"""
Phase schedule builder.

Compiles training.phases declarative list into UniversalPhaseScheduler.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from .universal import PhaseSpec, UniversalPhaseScheduler

logger = logging.getLogger(__name__)


def build_phase_schedule(
    cfg: Dict[str, Any],
    dequantize_dtype: Optional["torch.dtype"] = None,
) -> Optional[UniversalPhaseScheduler]:
    """
    Build a UniversalPhaseScheduler from config.

    Reads cfg["training"]["phases"] and compiles into a scheduler.
    Returns None if no phases are configured.

    Args:
        cfg: Full training config.
        dequantize_dtype: If set (for int4/int8 quantized models), quantized
            params are auto-cast to this dtype when they become trainable
            during phase transitions.
    """
    training = cfg.get("training", {})
    if not isinstance(training, dict):
        return None

    phases_raw = training.get("phases")
    if phases_raw is None or not isinstance(phases_raw, list):
        return None

    # injection config에서 target layer indices 추출 (base_ffn 자동 스코핑용)
    injection_layer_indices = _derive_injection_layer_indices(cfg)

    return _compile_declarative_phases(
        phases_raw, training, dequantize_dtype,
        injection_layer_indices=injection_layer_indices,
    )


def _derive_injection_layer_indices(
    cfg: Dict[str, Any],
) -> Optional[List[int]]:
    """injection.start_layer/num_layers에서 target layer indices를 추출.

    base_ffn이 활성화된 phase에서 명시적 target_layers가 없을 때,
    injection 범위로 자동 스코핑하기 위해 사용한다.
    """
    injection = cfg.get("injection", {})
    if not isinstance(injection, dict):
        return None

    # 명시적 layer_indices가 있으면 그대로 사용
    explicit = injection.get("layer_indices")
    if explicit is not None:
        try:
            return [int(x) for x in explicit]
        except (TypeError, ValueError):
            return None

    start_layer = int(injection.get("start_layer", 0) or 0)
    num_layers_cfg = injection.get("num_layers")
    try:
        num_layers = int(num_layers_cfg) if num_layers_cfg is not None else 0
    except (TypeError, ValueError):
        num_layers = 0

    if num_layers <= 0:
        # num_layers 미지정 → 전체 레이어 사용이므로 스코핑 불필요
        return None

    return list(range(start_layer, start_layer + num_layers))


def _compile_declarative_phases(
    phases_raw: List[Dict[str, Any]],
    training: Dict[str, Any],
    dequantize_dtype: Optional["torch.dtype"] = None,
    injection_layer_indices: Optional[List[int]] = None,
) -> UniversalPhaseScheduler:
    """Compile raw phase dicts into PhaseSpec list and create scheduler."""
    # Get global target kwargs
    global_kwargs = training.get("phase_target_kwargs", {}) or {}

    specs: List[PhaseSpec] = []
    for entry in phases_raw:
        if not isinstance(entry, dict):
            raise ValueError(f"Each phase entry must be a dict, got {type(entry).__name__}")

        step = entry.get("step")
        trainable = entry.get("trainable")
        mode = entry.get("mode", "replace")

        # Per-phase target kwargs override global
        base_ffn_keywords = entry.get("base_ffn_keywords") or global_kwargs.get("base_ffn_keywords")
        target_layers = entry.get("target_layers") or global_kwargs.get("target_layers")

        # base_ffn이 활성 그룹이고 target_layers가 명시되지 않았으면,
        # injection config의 layer indices로 자동 스코핑한다.
        if (
            target_layers is None
            and injection_layer_indices is not None
            and isinstance(trainable, list)
            and "base_ffn" in trainable
        ):
            target_layers = injection_layer_indices
            logger.info(
                "[PhaseScheduler] base_ffn target_layers auto-derived from "
                "injection config: %s (step=%s)",
                target_layers, step,
            )

        # Ensure types
        if base_ffn_keywords is not None:
            base_ffn_keywords = list(base_ffn_keywords)
        if target_layers is not None:
            target_layers = [int(x) for x in target_layers]

        specs.append(PhaseSpec(
            step=int(step),
            trainable=list(trainable),
            mode=str(mode),
            base_ffn_keywords=base_ffn_keywords,
            target_layers=target_layers,
        ))

    return UniversalPhaseScheduler(phases=specs, dequantize_dtype=dequantize_dtype)
