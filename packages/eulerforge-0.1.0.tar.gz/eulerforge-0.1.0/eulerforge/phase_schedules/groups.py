# eulerforge/phase_schedules/groups.py
"""
Group resolver: determines which parameter group(s) a named parameter belongs to.

Priority order:
1. Tag-based: check param._eulerforge_group or module._eulerforge_group attribute
2. Type-based: isinstance checks for LoRALinear, MixtureLoRALinear, MoEFFN router, etc.
3. Name keyword fallback: pattern matching on parameter names (with warning)
"""
from __future__ import annotations

import logging
import re
from typing import Dict, FrozenSet, List, Optional, Sequence, Set

import torch.nn as nn

logger = logging.getLogger(__name__)

# Canonical group names
KNOWN_GROUPS: FrozenSet[str] = frozenset({
    "lora",
    "router",
    "base_ffn",
    "attn_lora",
})

# Default name-based patterns for fallback resolution
_LORA_NAME_PATTERNS = (
    re.compile(r"\.lora_[ab]$", re.IGNORECASE),
    re.compile(r"\.lora[ab]$", re.IGNORECASE),
    re.compile(r"\.lora_[ab]\.", re.IGNORECASE),
    re.compile(r"\.lora[ab]\.", re.IGNORECASE),
)

_ROUTER_NAME_PATTERNS = (
    re.compile(r"\.router\.(weight|bias)$", re.IGNORECASE),
    re.compile(r"\.router$", re.IGNORECASE),
)

_ATTN_KEYWORDS = ("q_proj", "k_proj", "v_proj", "o_proj")

_FFN_BASE_KEYWORDS = ("gate_proj", "up_proj", "down_proj", "w1", "w2", "w3")


def _has_tag(obj, group: str) -> bool:
    """Check if an object (param or module) has a _eulerforge_group tag."""
    tag = getattr(obj, "_eulerforge_group", None)
    if tag is None:
        return False
    if isinstance(tag, str):
        return tag == group
    if isinstance(tag, (set, frozenset, list, tuple)):
        return group in tag
    return False


def resolve_param_groups(
    model: nn.Module,
    *,
    base_ffn_keywords: Optional[Sequence[str]] = None,
    target_layers: Optional[Sequence[int]] = None,
) -> Dict[str, List[str]]:
    """
    Resolve all parameters into groups.

    Returns a dict mapping group_name -> list of parameter names.
    A parameter may appear in multiple groups.
    """
    if base_ffn_keywords is None:
        base_ffn_keywords = list(_FFN_BASE_KEYWORDS)

    groups: Dict[str, List[str]] = {g: [] for g in KNOWN_GROUPS}
    _name_fallback_used = False

    # Build a module lookup for type-based checks
    module_for_param: Dict[str, nn.Module] = {}
    for mod_name, mod in model.named_modules():
        for pname, _ in mod.named_parameters(recurse=False):
            full_name = f"{mod_name}.{pname}" if mod_name else pname
            module_for_param[full_name] = mod

    for name, param in model.named_parameters():
        param_groups = _resolve_single_param(
            name, param, module_for_param.get(name),
            base_ffn_keywords=base_ffn_keywords,
            target_layers=target_layers,
        )
        for g in param_groups:
            groups[g].append(name)

    return groups


def _resolve_single_param(
    name: str,
    param: nn.Parameter,
    parent_module: Optional[nn.Module],
    *,
    base_ffn_keywords: Sequence[str],
    target_layers: Optional[Sequence[int]],
) -> Set[str]:
    """Resolve groups for a single parameter."""
    result: Set[str] = set()

    # 1) Tag-based (highest priority)
    for group in KNOWN_GROUPS:
        if _has_tag(param, group):
            result.add(group)
        if parent_module is not None and _has_tag(parent_module, group):
            result.add(group)
    if result:
        return result

    # 2) Type-based
    if parent_module is not None:
        type_groups = _resolve_by_type(name, parent_module, base_ffn_keywords, target_layers)
        if type_groups:
            return type_groups

    # 3) Name-based fallback
    return _resolve_by_name(name, base_ffn_keywords, target_layers)


def _resolve_by_type(
    name: str,
    parent_module: nn.Module,
    base_ffn_keywords: Sequence[str],
    target_layers: Optional[Sequence[int]],
) -> Set[str]:
    """Type-based group resolution using isinstance checks."""
    result: Set[str] = set()
    cls_name = type(parent_module).__name__

    # LoRA modules
    if cls_name == "LoRALinear":
        ln = name.lower()
        if "lora_a" in ln or "lora_b" in ln or "loraa" in ln or "lorab" in ln:
            # Check if it's an attention LoRA
            if _is_attn_path(name):
                result.add("attn_lora")
            else:
                result.add("lora")
        return result

    # MixtureLoRALinear
    if cls_name == "MixtureLoRALinear":
        ln = name.lower()
        if ".router." in ln or name.endswith(".router"):
            result.add("router")
        elif "lora" in ln:
            if _is_attn_path(name):
                result.add("attn_lora")
            else:
                result.add("lora")
        return result

    # MoEFFN router
    if cls_name == "MoEFFN":
        ln = name.lower()
        if ".router." in ln or name.endswith(".router"):
            result.add("router")
        return result

    return result


def _resolve_by_name(
    name: str,
    base_ffn_keywords: Sequence[str],
    target_layers: Optional[Sequence[int]],
) -> Set[str]:
    """Name-based fallback group resolution."""
    result: Set[str] = set()
    ln = name.lower()

    # LoRA detection
    for pat in _LORA_NAME_PATTERNS:
        if pat.search(ln):
            if _is_attn_path(name):
                result.add("attn_lora")
            else:
                result.add("lora")
            return result

    # Also catch "lora" in name with _a/_b suffix patterns
    if "lora" in ln and ("_a" in ln or "_b" in ln or "loraa" in ln or "lorab" in ln):
        if _is_attn_path(name):
            result.add("attn_lora")
        else:
            result.add("lora")
        return result

    # Router detection
    for pat in _ROUTER_NAME_PATTERNS:
        if pat.search(ln):
            result.add("router")
            return result
    if ".router." in ln and (ln.endswith(".weight") or ln.endswith(".bias")):
        result.add("router")
        return result

    # Base FFN detection
    if _is_base_ffn_param(name, base_ffn_keywords, target_layers):
        result.add("base_ffn")
        return result

    return result


def _is_attn_path(name: str) -> bool:
    """Check if a parameter path belongs to an attention module."""
    ln = name.lower()
    return any(kw in ln for kw in _ATTN_KEYWORDS)


def _is_base_ffn_param(
    name: str,
    base_ffn_keywords: Sequence[str],
    target_layers: Optional[Sequence[int]],
) -> bool:
    """Check if a parameter is a base FFN weight (not LoRA, not router)."""
    ln = name.lower()

    # Must not be LoRA
    if "lora" in ln:
        return False
    # Must not be router
    if "router" in ln or "routing" in ln:
        return False

    # Must match one of the FFN keywords
    if not any(kw.lower() in ln for kw in base_ffn_keywords):
        return False

    # Must be a weight or bias
    if not (ln.endswith(".weight") or ln.endswith(".bias")):
        return False

    # Optional layer filtering
    if target_layers is not None:
        layer_idx = _extract_layer_index(name)
        if layer_idx is None:
            return False
        if layer_idx not in set(target_layers):
            return False

    return True


def _extract_layer_index(name: str) -> Optional[int]:
    """Extract transformer layer index from parameter name."""
    parts = name.split(".")
    for i, p in enumerate(parts):
        if p == "layers" and (i + 1) < len(parts):
            try:
                return int(parts[i + 1])
            except ValueError:
                return None
    return None


def _dequantize_param_data(
    param: nn.Parameter,
    target_dtype: "torch.dtype",
) -> "torch.Tensor":
    """Properly dequantize a bitsandbytes quantized parameter.

    For int4 (nf4/fp4) params, uses ``bitsandbytes.functional.dequantize_4bit``
    with the param's ``quant_state`` to recover the original weight values.

    For int8 params with SCB (scale) metadata, uses
    ``bitsandbytes.functional.int8_vectorwise_dequant(CB, SCB)`` for proper
    row-wise dequantization.

    Falls back to numeric cast for unknown quantized dtypes.
    """
    import torch

    # 4-bit: Params4bit stores quant_state with absmax, code book, etc.
    qs = getattr(param, "quant_state", None)
    if qs is not None:
        try:
            from bitsandbytes.functional import dequantize_4bit
            return dequantize_4bit(param.data, qs).to(target_dtype)
        except (ImportError, Exception) as exc:
            logger.warning(
                "bitsandbytes dequantize_4bit failed (%s), falling back to cast", exc
            )

    # 8-bit: Int8Params stores CB (int8 data) and SCB (row-wise scale factors).
    if param.data.dtype == torch.int8:
        scb = getattr(param, "SCB", None)
        if scb is not None:
            try:
                from bitsandbytes.functional import int8_vectorwise_dequant
                return int8_vectorwise_dequant(param.data, scb).to(target_dtype)
            except (ImportError, Exception) as exc:
                logger.warning(
                    "bitsandbytes int8_vectorwise_dequant failed (%s), "
                    "falling back to cast", exc,
                )

    # Fallback: numeric cast (approximate for int8 without SCB).
    return param.data.to(target_dtype)


def _replace_quantized_modules_for_training(
    model: nn.Module,
    trainable_names: set,
    target_dtype: "torch.dtype",
) -> int:
    """Replace bitsandbytes quantized Linear modules with plain nn.Linear.

    When base_ffn params become trainable in a quantized model, casting
    ``param.data`` alone is insufficient — the module class (``Linear8bitLt``
    or ``Linear4bit``) still runs its quantized forward path, which crashes
    because it tries to reassign int8/uint8 data to a ``requires_grad=True``
    parameter (``self.weight.data = self.state.CB``).

    This function replaces the entire module with a plain ``nn.Linear`` using
    properly dequantized float weights, so the forward path no longer invokes
    bitsandbytes internals.

    Args:
        model: The model to modify in-place.
        trainable_names: Set of parameter names that will become trainable.
        target_dtype: Target floating-point dtype for dequantized weights.

    Returns:
        Number of modules replaced.
    """
    import torch

    try:
        import bitsandbytes as bnb
        _BNB_LINEAR_TYPES = (bnb.nn.Linear8bitLt, bnb.nn.Linear4bit)
    except ImportError:
        return 0

    # Build map: param_name → (parent_module, child_attr_name, child_module)
    replace_targets: dict = {}
    for name in trainable_names:
        # name is like "model.layers.0.mlp.gate_proj.weight"
        # We need the module path: "model.layers.0.mlp.gate_proj"
        parts = name.rsplit(".", 1)
        if len(parts) < 2:
            continue
        module_path = parts[0]  # e.g. "model.layers.0.mlp.gate_proj"
        if module_path in replace_targets:
            continue  # Already scheduled for replacement

        # Navigate to the module
        try:
            child = model
            for attr in module_path.split("."):
                child = getattr(child, attr)
        except AttributeError:
            continue

        if not isinstance(child, _BNB_LINEAR_TYPES):
            continue

        # Find the parent module and child attribute name
        parent_path_parts = module_path.rsplit(".", 1)
        if len(parent_path_parts) == 2:
            parent_path, child_name = parent_path_parts
            parent = model
            for attr in parent_path.split("."):
                parent = getattr(parent, attr)
        else:
            parent = model
            child_name = module_path

        replace_targets[module_path] = (parent, child_name, child)

    replaced = 0
    for module_path, (parent, child_name, child) in replace_targets.items():
        old_cls = child.__class__.__name__
        weight = child.weight

        # Dequantize the weight properly
        if isinstance(child, bnb.nn.Linear8bitLt):
            if weight.data.dtype == torch.int8:
                scb = getattr(weight, "SCB", None)
                if scb is None and hasattr(child, "state"):
                    scb = getattr(child.state, "SCB", None)
                if scb is not None:
                    try:
                        from bitsandbytes.functional import int8_vectorwise_dequant
                        deq_weight = int8_vectorwise_dequant(
                            weight.data, scb,
                        ).to(target_dtype)
                    except Exception as exc:
                        logger.warning(
                            "int8 dequant failed for %s (%s), using naive cast",
                            module_path, exc,
                        )
                        deq_weight = weight.data.float().to(target_dtype)
                else:
                    logger.warning(
                        "No SCB found for int8 module %s, using naive cast",
                        module_path,
                    )
                    deq_weight = weight.data.float().to(target_dtype)
            else:
                # Weight is already floating-point (has_fp16_weights mode)
                deq_weight = weight.data.to(target_dtype)

        elif isinstance(child, bnb.nn.Linear4bit):
            qs = getattr(weight, "quant_state", None)
            if qs is not None:
                try:
                    from bitsandbytes.functional import dequantize_4bit
                    deq_weight = dequantize_4bit(weight.data, qs).to(target_dtype)
                except Exception as exc:
                    logger.warning(
                        "int4 dequant failed for %s (%s), using naive cast",
                        module_path, exc,
                    )
                    deq_weight = weight.data.float().to(target_dtype)
            else:
                deq_weight = weight.data.float().to(target_dtype)
        else:
            continue

        # Create replacement nn.Linear
        new_linear = nn.Linear(
            child.in_features,
            child.out_features,
            bias=child.bias is not None,
            device=deq_weight.device,
            dtype=target_dtype,
        )
        new_linear.weight.data.copy_(deq_weight)
        if child.bias is not None:
            new_linear.bias.data.copy_(child.bias.data.to(target_dtype))

        setattr(parent, child_name, new_linear)
        replaced += 1
        logger.info(
            "[Phase] Replaced %s (%s → nn.Linear, dtype=%s) for training",
            module_path, old_cls, target_dtype,
        )

    if replaced > 0:
        logger.info(
            "[Phase] Replaced %d quantized modules with %s nn.Linear "
            "before enabling grad",
            replaced, target_dtype,
        )

    return replaced


def _validate_trainable_dtypes(model: nn.Module) -> None:
    """Validate all trainable params have floating-point dtype.

    Raises RuntimeError with a clear message if any trainable parameter
    has non-floating dtype (e.g. int8 leftover from incomplete dequantization).
    This catches the issue early, before a deep stack trace from bitsandbytes.
    """
    bad = []
    for name, param in model.named_parameters():
        if param.requires_grad and not param.dtype.is_floating_point:
            # Find the module class for better diagnostics
            mod_path = name.rsplit(".", 1)[0] if "." in name else ""
            try:
                mod = model
                for attr in mod_path.split("."):
                    mod = getattr(mod, attr)
                cls_name = mod.__class__.__name__
            except Exception:
                cls_name = "?"
            bad.append(f"  {name}  dtype={param.dtype}  module={cls_name}")

    if bad:
        details = "\n".join(bad[:10])
        n = len(bad)
        raise RuntimeError(
            f"Phase Transition Error: {n} trainable parameter(s) have non-floating "
            f"dtype after dequantization.\n"
            f"This means the quantized module was not properly replaced.\n"
            f"Parameters:\n{details}\n"
            f"Fix: Ensure dequantize_on_train=true and the quantization mode supports "
            f"module replacement (int4/int8).\n"
            f"See: docs/fixtures/specs/load_precision_spec.md"
        )


def set_trainable_by_groups(
    model: nn.Module,
    active_groups: Sequence[str],
    *,
    mode: str = "replace",
    base_ffn_keywords: Optional[Sequence[str]] = None,
    target_layers: Optional[Sequence[int]] = None,
    dequantize_dtype: Optional["torch.dtype"] = None,
) -> int:
    """
    Set requires_grad based on group membership.

    Args:
        model: The model to modify.
        active_groups: List of group names to make trainable.
        mode: "replace" freezes all first then unfreezes groups;
              "add" only unfreezes groups without freezing.
        base_ffn_keywords: Keywords for base FFN detection.
        target_layers: Optional layer indices to restrict base_ffn targeting.
        dequantize_dtype: If set, quantized (non-float) params are cast to this
            dtype before setting requires_grad=True. Required for int4/int8
            quantized models where base_ffn becomes trainable.

    Returns:
        Number of parameters set to trainable.
    """
    import torch

    if base_ffn_keywords is None:
        base_ffn_keywords = list(_FFN_BASE_KEYWORDS)

    active_set = set(active_groups)

    if mode == "replace":
        for p in model.parameters():
            if p.dtype.is_floating_point:
                p.requires_grad = False

    resolved = resolve_param_groups(
        model,
        base_ffn_keywords=base_ffn_keywords,
        target_layers=target_layers,
    )

    trainable_names: Set[str] = set()
    for group in active_set:
        if group in resolved:
            trainable_names.update(resolved[group])

    # --- Step 1: Replace quantized modules (int8/int4) with nn.Linear ---
    # This MUST happen before setting requires_grad, because bitsandbytes
    # Linear8bitLt.forward() crashes when weight.requires_grad=True:
    #   self.weight.data = self.state.CB  # int8 → RuntimeError
    replaced_count = 0
    if dequantize_dtype is not None:
        replaced_count = _replace_quantized_modules_for_training(
            model, trainable_names, dequantize_dtype,
        )

    # --- Step 2: Set requires_grad on trainable params ---
    # After module replacement, re-resolve param names (module swap changes refs)
    if replaced_count > 0:
        resolved = resolve_param_groups(
            model,
            base_ffn_keywords=base_ffn_keywords,
            target_layers=target_layers,
        )
        trainable_names = set()
        for group in active_set:
            if group in resolved:
                trainable_names.update(resolved[group])

    count = 0
    dequant_count = 0
    for name, param in model.named_parameters():
        if name in trainable_names:
            if not param.dtype.is_floating_point:
                if dequantize_dtype is not None:
                    param.data = _dequantize_param_data(param, dequantize_dtype)
                    dequant_count += 1
                else:
                    logger.warning(
                        "Skipping quantized param %s (dtype=%s): "
                        "cannot set requires_grad without dequantize_dtype",
                        name, param.dtype,
                    )
                    continue
            param.requires_grad = True
            count += 1

    if dequant_count > 0:
        logger.info(
            "[Phase] Dequantized %d params to %s before enabling grad",
            dequant_count, dequantize_dtype,
        )

    # Debug: log weight statistics after dequantization
    import os
    if os.environ.get("EULERFORGE_TRAIN_DEBUG", "") == "1":
        for name, param in model.named_parameters():
            if name in trainable_names and param.requires_grad:
                logger.debug(
                    "[DequantDebug] %s dtype=%s mean=%.4f std=%.4f min=%.4f max=%.4f",
                    name, param.dtype,
                    param.data.float().mean().item(),
                    param.data.float().std().item(),
                    param.data.float().min().item(),
                    param.data.float().max().item(),
                )

    # --- Step 3: Post-transition safety check ---
    _validate_trainable_dtypes(model)

    return count
