# -*- coding: utf-8 -*-
"""
eulerforge.adapters.backbones.base

BackboneAdapter 인터페이스(계약) 정의.

목표
- 훈련 루프(train loop)는 백본과 무관하게 1개로 유지한다.
- 백본별 차이는 "어디에 무엇이 있는가" (layers/ffn/attn/native moe experts)를 찾는 규칙뿐이다.
- 따라서 아래 인터페이스만 구현하면 injection/phase/train 코드가 재사용 가능하다.

핵심 요구(기존 코드에서 얻은 교훈)
- 구조를 먼저 주입한 다음(state_dict load 전에) weight를 로드해야 매칭이 된다. [file:1]
- 그러려면 모델 내부 submodule을 안정적으로 찾는 계층(adapter)이 필요하다. [file:1]
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import torch.nn as nn


@dataclass(frozen=True)
class ExpertGroup:
    """
    Native MoE 탐색 결과를 표준화한 컨테이너.

    - experts: 전문가 FFN 모듈들의 리스트 (각 expert는 nn.Module로 취급)
    - router: (선택) 해당 expert group을 게이팅하는 router 모듈
    - name: (선택) 디버깅/로깅용 식별자
    """
    experts: Sequence[nn.Module]
    router: Optional[nn.Module] = None
    name: Optional[str] = None


class BackboneAdapter:
    """
    백본별 구조 탐색 규칙을 캡슐화하는 인터페이스.

    구현 클래스는 최소 아래 메서드를 제공해야 한다:
    - find_transformer_layers(model) -> Sequence[nn.Module]
    - find_ffn_module(block) -> nn.Module
    - find_attention_leaf_modules(block, keywords) -> List[str]  (block 기준 상대 경로)
    - find_native_expert_groups(block) -> List[ExpertGroup]  (native MoE일 때만)

    설계 의도
- InjectionStrategy(A/B/C)는 "주입"에 집중하고,
  "어디에 주입할지"는 adapter가 제공한다.
    """

    # 사람이 지정할 때 쓰는 이름(예: qwen, mixtral, gpt_oss)
    name: str = "base"

    # -------------------------
    # 필수: transformer blocks
    # -------------------------
    def find_transformer_layers(self, model: nn.Module) -> Sequence[nn.Module]:
        """
        모델에서 transformer block 리스트를 찾아 반환.

        예: Qwen 계열은 model.model.layers, 일부는 model.transformer.h 등 [file:1]
        """
        raise NotImplementedError

    # -------------------------
    # 필수: FFN(mlp) 위치
    # -------------------------
    def find_ffn_module(self, block: nn.Module) -> nn.Module:
        """
        한 block 안에서 FFN 모듈을 반환.

        기존 코드에서는 후보 이름(mlp/ffn/feed_forward/...)로 탐색했다. [file:1]
        """
        raise NotImplementedError

    # -------------------------
    # 선택: attention LoRA 키워드 변환 (backbone-specific compatibility shim)
    # -------------------------
    def translate_attn_keywords(
        self, block: nn.Module, keywords: Sequence[str]
    ) -> List[str]:
        """Block 구조에 맞게 attention LoRA 키워드를 변환.

        기본 구현은 키워드를 그대로 반환한다. 일부 backbone (예: Qwen3.5의
        linear_attn / GatedDeltaNet)에서는 표준 키워드(q_proj, v_proj 등)가
        실제 모듈명과 다르므로, 해당 어댑터가 이 메서드를 override하여
        키워드를 자동 변환한다.

        호출처는 dense_lora.py (attn LoRA 주입)에서 inject_lora_inplace 호출 전에
        키워드를 변환하기 위해 사용한다.
        """
        return list(keywords)

    # -------------------------
    # 필수: attention LoRA 타겟
    # -------------------------
    def find_attention_leaf_modules(
        self, block: nn.Module, keywords: Sequence[str]
    ) -> List[str]:
        """
        Attention LoRA를 적용할 leaf 모듈의 '이름 리스트'를 반환.

        반환값은 block 기준 상대 경로 문자열이어야 한다.
        예: "self_attn.q_proj", "self_attn.k_proj" 등.

        주의:
        - leaf만 반환하는 것을 권장(자식 모듈이 있으면 LoRA 래핑 충돌 가능). [file:1]
        """
        names: List[str] = []
        for n, m in block.named_modules():
            if not any(k in n for k in keywords):
                continue
            if len(list(m.children())) != 0:
                continue
            names.append(n)
        return names

    # -------------------------
    # 선택: native MoE experts
    # -------------------------
    def find_native_expert_groups(self, block: nn.Module) -> List[ExpertGroup]:
        """
        Native MoE 백본(Mixtral, gpt-oss 등)인 경우 block에서 expert 그룹을 찾아 반환.

        - Dense 백본이면 빈 리스트 반환.
        - 여러 expert group이 있을 수 있으므로 List로 반환.

        이 메서드가 C) Native MoE + expert LoRA 전략의 핵심이다. [file:1]
        """
        return []

    # -------------------------
    # 기본 키워드(백본별 override 권장)
    # -------------------------
    def default_ffn_keywords(self) -> Sequence[str]:
        """
        FFN 쪽 LoRA 타겟 키워드 기본값.
        기존 코드의 Qwen/LLaMA 스타일 키워드들을 넓게 포함한다. [file:1]
        """
        return [
            "w1", "w2", "w3",
            "gate_proj", "up_proj", "down_proj",
            "dense_h_to_4h", "dense_4h_to_h",
        ]

    def default_attn_keywords(self) -> Sequence[str]:
        """
        Attention 쪽 LoRA 타겟 키워드 기본값. [file:1]
        """
        return ["q_proj", "k_proj", "v_proj", "o_proj"]

    # -------------------------
    # 유틸: 계층 인덱스 선택
    # -------------------------
    def parse_layer_indices(
        self,
        num_layers: int,
        explicit_indices: Optional[Sequence[int]] = None,
        start_layer: int = 0,
        num_target_layers: int = 0,
        stride: int = 1,
    ) -> List[int]:
        """
        MoE/LoRA를 적용할 layer index 리스트를 계산.

        - explicit_indices가 있으면 그대로 사용
        - 없으면 start_layer부터 stride 간격으로 num_target_layers개 선택
        """
        if explicit_indices is not None:
            indices = [int(i) for i in explicit_indices]
        else:
            if num_target_layers <= 0:
                return list(range(num_layers))
            indices = list(range(start_layer, start_layer + num_target_layers * stride, stride))

        indices = [i for i in indices if 0 <= i < num_layers]
        if not indices:
            raise ValueError("No valid layer indices selected.")
        return sorted(set(indices))

    # -------------------------
    # 유틸: "모듈 경로"로 가져오기
    # -------------------------
    def get_submodule_by_path(self, root: nn.Module, path: str) -> nn.Module:
        """
        root에서 'a.b.c' 형태의 경로로 submodule을 찾아 반환.
        injection 쪽에서 adapter가 돌려준 leaf 경로를 실제 모듈로 resolve할 때 사용.
        """
        cur: nn.Module = root
        for part in path.split("."):
            if not hasattr(cur, part):
                raise AttributeError(f"Module path not found: '{path}' at '{part}'")
            cur = getattr(cur, part)
            if not isinstance(cur, nn.Module):
                raise TypeError(f"Resolved object is not nn.Module: path='{path}'")
        return cur
