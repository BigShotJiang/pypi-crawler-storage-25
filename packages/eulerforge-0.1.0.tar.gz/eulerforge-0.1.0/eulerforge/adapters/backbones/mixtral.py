# -*- coding: utf-8 -*-
"""
eulerforge.adapters.backbones.mixtral

Mixtral backbone adapter.

목표
- Transformers/HF Mixtral 계열 모델에서
  - transformer layers
  - FFN(mlp) 모듈
  - attention projection leaf modules
  - native MoE experts(+router) 그룹
  을 안정적으로 찾는 규칙을 제공한다.

주의
- Mixtral 구현은 버전/포크에 따라 내부 attribute 명이 달라질 수 있어
  여러 후보를 순차 탐색하는 방식으로 작성한다. [file:1]
"""

from __future__ import annotations

from typing import List, Optional, Sequence

import torch.nn as nn

from .base import BackboneAdapter, ExpertGroup


class _FusedExpertSlice(nn.Module):
    """Fused 3D expert tensor에서 단일 expert를 분리한 래퍼.

    MixtralExperts의 gate_up_proj: (num_experts, intermediate, hidden)에서
    단일 expert의 가중치를 nn.Linear로 노출하여 LoRA 래핑을 가능하게 한다.
    """

    def __init__(self, fused_module: nn.Module, expert_idx: int):
        super().__init__()
        # _fused를 일반 attribute로 저장 (nn.Module 자식으로 등록 안 함 → 순환 참조 방지)
        object.__setattr__(self, "_fused_ref", fused_module)
        self._idx = expert_idx

        # fused의 3D Parameters에서 해당 expert slice를 nn.Linear로 변환
        for pname in ("gate_up_proj", "down_proj", "w1", "w2", "w3",
                       "gate_proj", "up_proj"):
            fused_param = getattr(self._fused_ref, pname, None)
            if fused_param is not None and isinstance(fused_param, nn.Parameter):
                if fused_param.dim() == 3 and fused_param.shape[0] > expert_idx:
                    # (num_experts, out, in) → single expert (out, in)
                    slice_data = fused_param.data[expert_idx].clone()
                    out_f, in_f = slice_data.shape
                    linear = nn.Linear(in_f, out_f, bias=False)
                    linear.weight = nn.Parameter(slice_data)
                    setattr(self, pname, linear)

    def forward(self, x):
        # fallback — 직접 forward는 LoRA 래핑 후에는 사용되지 않음
        raise NotImplementedError(
            "_FusedExpertSlice.forward is not meant to be called directly. "
            "Use the parent fused module's forward instead."
        )


def _unfuse_mixtral_experts(fused_experts: nn.Module, register: bool = True) -> list:
    """Fused MixtralExperts를 개별 _FusedExpertSlice 리스트로 변환.

    Args:
        fused_experts: fused 3D Parameter를 가진 모듈 (MixtralExperts 등)
        register: True이면 slice들을 fused_experts의 _lora_slices ModuleList에 등록.
            이렇게 해야 model.named_parameters()에 LoRA 파라미터가 노출됨.

    Returns:
        개별 expert 모듈 리스트. fused가 아니면 빈 리스트.
    """
    # fused expert는 3D Parameter를 가짐
    has_3d = False
    num_experts = 0
    for pname in ("gate_up_proj", "down_proj", "w1", "w2", "w3"):
        p = getattr(fused_experts, pname, None)
        if p is not None and isinstance(p, nn.Parameter) and p.dim() == 3:
            has_3d = True
            num_experts = p.shape[0]
            break

    if not has_3d or num_experts == 0:
        return []

    slices = [_FusedExpertSlice(fused_experts, i) for i in range(num_experts)]

    # 모델 module tree에 등록 — model.named_parameters()에 LoRA params 노출
    if register:
        fused_experts._lora_slices = nn.ModuleList(slices)

    return slices


class MixtralAdapter(BackboneAdapter):
    name = "mixtral"

    # -------------------------
    # transformer blocks
    # -------------------------
    def find_transformer_layers(self, model: nn.Module) -> Sequence[nn.Module]:
        """
        HF 계열에서 흔한 경로를 순차 탐색:
        - model.model.layers (LLaMA/Qwen 스타일)
        - model.transformer.h (GPT-NeoX 스타일)
        - model.transformer.layers
        """
        # most common: AutoModelForCausalLM -> .model -> .layers
        if hasattr(model, "model") and hasattr(model.model, "layers"):
            layers = getattr(model.model, "layers")
            if isinstance(layers, (list, nn.ModuleList)) and len(layers) > 0:
                return layers

        # alternate: .transformer.h
        if hasattr(model, "transformer") and hasattr(model.transformer, "h"):
            layers = getattr(model.transformer, "h")
            if isinstance(layers, (list, nn.ModuleList)) and len(layers) > 0:
                return layers

        # alternate: .transformer.layers
        if hasattr(model, "transformer") and hasattr(model.transformer, "layers"):
            layers = getattr(model.transformer, "layers")
            if isinstance(layers, (list, nn.ModuleList)) and len(layers) > 0:
                return layers

        raise RuntimeError("MixtralAdapter: cannot find transformer layers (unknown model layout).")

    # -------------------------
    # FFN / MLP module
    # -------------------------
    def find_ffn_module(self, block: nn.Module) -> nn.Module:
        """
        Mixtral block에서 FFN 역할을 하는 모듈을 반환.
        """

        for cand in ("block_sparse_moe", "mlp", "ffn", "feed_forward", "feedforward", "moe", "sparse_moe"):
            if hasattr(block, cand):
                m = getattr(block, cand)
                if isinstance(m, nn.Module):
                    return m
        raise RuntimeError("MixtralAdapter: FFN/MLP module not found in the transformer block.")
    

    # -------------------------
    # Attention leaf targets
    # -------------------------
    # def find_attention_leaf_modules(
    #     self, block: nn.Module, keywords: Sequence[str]
    # ) -> List[str]:
    #     """
    #     base 구현을 그대로 쓰되, mixtral block에서 attention sub-tree를 우선 탐색하고,
    #     실패하면 block 전체에서 leaf 탐색한다.
    #     """
    #     attn = None
    #     attn_name = "self_attn" # default

    #     # 1. Attention Module 찾기 (Attribute 이름 우선 탐색)
    #     for cand in ("self_attn", "selfattn", "attn", "attention"):
    #         if hasattr(block, cand):
    #             m = getattr(block, cand)
    #             if isinstance(m, nn.Module):
    #                 attn = m
    #                 attn_name = cand
    #                 break
        
    #     # 2. 못 찾았을 경우 Fallback: 자식 모듈 이름으로 탐색
    #     # (일부 변형 모델이나 래핑된 모델 대응)
    #     if attn is None:
    #         for n, m in block.named_children():
    #             if "attn" in n.lower() or "attention" in n.lower():
    #                 attn = m
    #                 attn_name = n
    #                 break

    #     if attn is not None:
    #         names: List[str] = []
    #         for n, m in attn.named_modules():
    #             # Leaf Module(자식이 없는 최하단)만 대상
    #             if len(list(m.children())) > 0:
    #                 continue
                
    #             # 키워드 매칭 (예: q_proj, v_proj)
    #             if not any(k in n for k in keywords):
    #                 continue
                
    #             # 경로 생성: "{parent_name}.{sub_name}"
    #             # n이 빈 문자열일 경우(attn 모듈 자체)를 대비
    #             full_path = f"{attn_name}.{n}" if n else attn_name
    #             names.append(full_path)
            
    #         # 중복 제거 및 정렬 후 반환
    #         if names:
    #             return sorted(list(set(names)))

    #     # 3. 그래도 없으면 기본 로직 (block 전체 스캔)
    #     return super().find_attention_leaf_modules(block, keywords)

    # -------------------------
    # Attention leaf targets
    # -------------------------
    def find_attention_leaf_modules(
        self, block: nn.Module, keywords: Sequence[str]
    ) -> List[str]:
        attn = None
        attn_name = "self_attn" # default

        # 1. Attention Module 찾기
        for cand in ("self_attn", "selfattn", "attn", "attention"):
            if hasattr(block, cand):
                m = getattr(block, cand)
                if isinstance(m, nn.Module):
                    attn = m
                    attn_name = cand
                    break
        
        if attn is None:
            # Fallback: 자식 이름으로 탐색
            for n, m in block.named_children():
                if "attn" in n.lower():
                    attn = m
                    attn_name = n
                    break

        if attn is not None:
            names: List[str] = []
            for n, m in attn.named_modules():
                # Leaf만 대상
                if len(list(m.children())) > 0:
                    continue
                
                # 키워드 매칭
                if not any(k in n for k in keywords):
                    continue
                
                # 경로 생성 (attn_name.sub_name)
                full_path = f"{attn_name}.{n}" if n else attn_name
                names.append(full_path)
            
            if names:
                return sorted(set(names))

        # 그래도 없으면 기본 로직 (block 전체 스캔)
        return super().find_attention_leaf_modules(block, keywords)
    
    # -------------------------
    # Native MoE experts
    # -------------------------
    def find_native_expert_groups(self, block: nn.Module) -> List[ExpertGroup]:
        """
        Mixtral의 sparse MoE는 보통 block.mlp 내부에 존재한다.

        목표는 "expert 모듈 리스트 + (가능하면) router 모듈"을 찾아 ExpertGroup으로 반환하는 것.
        - experts 컨테이너는 구현에 따라 ModuleList일 수도, 단순 list일 수도 있다.
        - router/ gate는 보통 gate/router 라는 이름을 가진 Linear/Module로 존재한다.

        반환:
          - native MoE를 못 찾으면 [] (dense처럼 취급)
        """
        ffn = None
        try:
            ffn = self.find_ffn_module(block)
        except Exception:
            ffn = None

        if ffn is None:
            return []

        groups: List[ExpertGroup] = []

        # 1) ffn 자체에 experts가 있는 케이스
        grp = self._try_build_expert_group_from_container(ffn, prefix="ffn")
        if grp is not None:
            groups.append(grp)
            return groups

        # 2) ffn 하위 모듈들을 스캔: experts/router 후보를 찾는다
        for name, sub in ffn.named_modules():
            grp2 = self._try_build_expert_group_from_container(sub, prefix=name)
            if grp2 is not None:
                groups.append(grp2)

        # 3) 그래도 없으면 block 전체에서 한번 더 스캔(보수적 fallback)
        if not groups:
            for name, sub in block.named_modules():
                grp3 = self._try_build_expert_group_from_container(sub, prefix=f"block.{name}")
                if grp3 is not None:
                    groups.append(grp3)

        # 중복 제거(같은 experts 객체를 여러 경로로 잡은 경우)
        uniq: List[ExpertGroup] = []
        seen_ids = set()
        for g in groups:
            ex_id = id(g.experts)
            if ex_id in seen_ids:
                continue
            seen_ids.add(ex_id)
            uniq.append(g)

        return uniq

    def _try_build_expert_group_from_container(
        self, container: nn.Module, prefix: str
    ) -> Optional[ExpertGroup]:
        """
        container에서 experts/router 후보를 찾아 ExpertGroup을 만들 수 있으면 반환, 아니면 None.
        """
        # experts 후보 attribute 이름들
        expert_attr_candidates = ("experts", "expert", "ffn_experts", "mlp_experts")
        experts_obj = None
        for a in expert_attr_candidates:
            if hasattr(container, a):
                experts_obj = getattr(container, a)
                break

        # experts_obj가 없으면, named_children 중 이름이 experts로 끝나는 것도 시도
        if experts_obj is None:
            for n, ch in container.named_children():
                if n.lower().endswith("experts"):
                    experts_obj = ch
                    break

        experts: Optional[Sequence[nn.Module]] = None

        # ModuleList / list / tuple
        if isinstance(experts_obj, nn.ModuleList):
            experts = list(experts_obj)
        elif isinstance(experts_obj, (list, tuple)) and all(isinstance(x, nn.Module) for x in experts_obj):
            experts = list(experts_obj)
        elif isinstance(experts_obj, nn.Module):
            # 어떤 구현은 experts를 하나의 모듈로 감싸고 내부에 ModuleList를 둘 수 있다
            # 그 경우 1-depth 더 내려가본다
            if hasattr(experts_obj, "__iter__"):
                try:
                    # 일부 nn.Module은 iterable이 아닐 수 있으므로 안전하게 시도
                    it = list(experts_obj)  # type: ignore[arg-type]
                    if it and all(isinstance(x, nn.Module) for x in it):
                        experts = it
                except Exception:
                    experts = None
            if experts is None:
                # named_children 중 modulelist를 찾는다
                for _, ch in experts_obj.named_children():
                    if isinstance(ch, nn.ModuleList) and len(ch) > 0:
                        experts = list(ch)
                        break

        # fused expert 감지: experts_obj가 nn.Module이고 3D Parameter가 있으면 unfuse
        if experts is None and isinstance(experts_obj, nn.Module):
            unfused = _unfuse_mixtral_experts(experts_obj)
            if unfused:
                experts = unfused

        if experts is None or len(experts) == 0:
            return None

        # router 후보: gate/router
        router = None
        for cand in ("router", "gate", "gating", "router_linear", "gate_linear"):
            if hasattr(container, cand) and isinstance(getattr(container, cand), nn.Module):
                router = getattr(container, cand)
                break

        # router를 container에서 못 찾으면, 전문가 컨테이너 주변에서도 탐색
        if router is None:
            for n, ch in container.named_modules():
                ln = n.lower()
                if ln.endswith("router") or ln.endswith("gate") or "router" in ln or "gate" in ln:
                    if isinstance(ch, nn.Module) and len(list(ch.parameters(recurse=True))) > 0:
                        router = ch
                        break

        return ExpertGroup(
            experts=experts,
            router=router,
            name=f"mixtral:{prefix}",
        )


    def find_ffn_attr_name(self, block: nn.Module) -> str:
        """
        MoE 인젝터 등을 위해 block 내 FFN 속성명을 반환.
        Mixtral은 보통 block_sparse_moe 라는 이름을 씁니다.
        """
        # 1) Standard Mixtral (HF)
        if hasattr(block, "block_sparse_moe"):
            return "block_sparse_moe"
            
        # 2) Common aliases
        for name in ("mlp", "ffn", "feed_forward", "moe", "sparse_moe"):
            if hasattr(block, name):
                return name
        
        # 3) Fallback search
        for name, child in block.named_children():
            # 보통 MoE 모듈은 experts 리스트를 가짐
            if hasattr(child, "experts") or name.lower().endswith("moe"):
                return name
                
        raise RuntimeError(f"MixtralAdapter: FFN/MoE attribute name not found in block {block.__class__.__name__}")
    
    def default_ffn_keywords(self) -> Sequence[str]:
        """
        Mixtral Expert FFN 키워드.
        최신 HF transformers의 fused MixtralExperts는 gate_up_proj, down_proj를 사용.
        이전 버전은 w1, w2, w3.
        """
        return ["gate_up_proj", "down_proj", "w1", "w2", "w3"]