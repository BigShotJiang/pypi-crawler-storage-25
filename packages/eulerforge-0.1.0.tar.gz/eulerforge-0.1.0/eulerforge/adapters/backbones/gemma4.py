# eulerforge/adapters/backbones/gemma4.py
"""
Gemma 4 BackboneAdapter.

Gemma 4 텍스트 파인튜닝을 위한 구조 탐색 어댑터.
Dense (31B) 및 MoE (26B-A4B, 128 experts) 두 가지 변형을 모두 지원한다.

HuggingFace 모델 구조:
  Gemma4ForConditionalGeneration (항상 multimodal wrapper)
    → model (Gemma4Model) → language_model (Gemma4TextModel) → layers (ModuleList)

  각 Gemma4TextDecoderLayer:
    - self_attn (q/k/v/o_proj)
    - mlp (gate_proj/up_proj/down_proj)  ← dense FFN, 항상 존재
    - [MoE only] router (Gemma4TextRouter) + experts (Gemma4TextExperts, fused 3D)

  MoE variant에서는 dense mlp와 router+experts가 동시에 존재한다.
  experts는 fused 3D tensor: gate_up_proj (num_experts, 2*intermediate, hidden),
  down_proj (num_experts, hidden, intermediate).

멀티모달 전체 학습은 지원 범위가 아님 — text backbone만 탐색한다.
"""

from __future__ import annotations

from typing import List, Sequence

import torch.nn as nn

from .base import BackboneAdapter, ExpertGroup


class _FusedExpertSlice(nn.Module):
    """Fused 3D expert tensor에서 단일 expert를 분리한 래퍼.

    Gemma4TextExperts의 gate_up_proj: (num_experts, 2*intermediate, hidden)에서
    단일 expert의 가중치를 nn.Linear로 노출하여 LoRA 래핑을 가능하게 한다.
    """

    def __init__(self, fused_module: nn.Module, expert_idx: int):
        super().__init__()
        object.__setattr__(self, "_fused_ref", fused_module)
        self._idx = expert_idx

        for pname in ("gate_up_proj", "down_proj"):
            fused_param = getattr(self._fused_ref, pname, None)
            if fused_param is not None and isinstance(fused_param, nn.Parameter):
                if fused_param.dim() == 3 and fused_param.shape[0] > expert_idx:
                    slice_data = fused_param.data[expert_idx].clone()
                    out_f, in_f = slice_data.shape
                    linear = nn.Linear(in_f, out_f, bias=False)
                    linear.weight = nn.Parameter(slice_data)
                    setattr(self, pname, linear)

    def forward(self, x):
        raise NotImplementedError(
            "_FusedExpertSlice.forward is not meant to be called directly."
        )


def _unfuse_gemma4_experts(fused_experts: nn.Module, register: bool = True) -> list:
    """Fused Gemma4TextExperts를 개별 _FusedExpertSlice 리스트로 변환."""
    has_3d = False
    num_experts = 0
    for pname in ("gate_up_proj", "down_proj"):
        p = getattr(fused_experts, pname, None)
        if p is not None and isinstance(p, nn.Parameter) and p.dim() == 3:
            has_3d = True
            num_experts = p.shape[0]
            break

    if not has_3d or num_experts == 0:
        return []

    slices = [_FusedExpertSlice(fused_experts, i) for i in range(num_experts)]

    if register:
        fused_experts._lora_slices = nn.ModuleList(slices)

    return slices


class Gemma4Adapter(BackboneAdapter):
    """Gemma 4 계열 text fine-tuning 어댑터 (dense + MoE)."""

    name = "gemma4"

    # -------------------------
    # 1. Transformer Blocks 찾기
    # -------------------------
    def find_transformer_layers(self, model: nn.Module) -> Sequence[nn.Module]:
        """
        Gemma 4 text backbone의 transformer layers를 찾는다.

        Gemma 4는 항상 multimodal wrapper:
          model.model.language_model.layers

        탐색 순서:
        1. model.model.language_model.layers (표준 경로)
        2. PEFT wrapper 해제 후 재시도
        """
        roots = [model]
        if hasattr(model, "base_model") and isinstance(
            getattr(model, "base_model"), nn.Module
        ):
            roots.append(model.base_model)

        for root in roots:
            inner = getattr(root, "model", None)
            if inner is not None:
                # Path 1: root.model.language_model.layers (multimodal wrapper)
                lm = getattr(inner, "language_model", None)
                if lm is not None:
                    layers = getattr(lm, "layers", None)
                    if isinstance(layers, (list, nn.ModuleList)) and len(layers) > 0:
                        return list(layers)

                # Path 2: root.model.layers (혹시 text-only CausalLM 형태일 경우)
                layers = getattr(inner, "layers", None)
                if isinstance(layers, (list, nn.ModuleList)) and len(layers) > 0:
                    return list(layers)

        raise RuntimeError(
            "Gemma4Adapter: cannot locate transformer layers.\n"
            "Fix: Gemma 4 text backbone은 model.model.language_model.layers에 있어야 합니다.\n"
            "See: docs/architectures/overview.md"
        )

    # -------------------------
    # 2. FFN (MLP) 모듈 찾기
    # -------------------------
    def find_ffn_module(self, block: nn.Module) -> nn.Module:
        """Gemma 4 block 내부의 dense FFN(MLP) 모듈을 반환한다."""
        if hasattr(block, "mlp") and isinstance(block.mlp, nn.Module):
            return block.mlp

        for name, child in block.named_children():
            if name.lower() in ("mlp", "feed_forward", "ffn"):
                return child

        raise RuntimeError(
            f"Gemma4Adapter: FFN module not found in block {block.__class__.__name__}.\n"
            "Fix: Gemma 4 DecoderLayer는 'mlp' 속성을 가져야 합니다.\n"
            "See: docs/architectures/overview.md"
        )

    def find_ffn_attr_name(self, block: nn.Module) -> str:
        """FFN 모듈의 속성 이름(string)을 반환한다."""
        if hasattr(block, "mlp") and isinstance(block.mlp, nn.Module):
            return "mlp"

        for name, child in block.named_children():
            if name.lower() in ("mlp", "feed_forward", "ffn"):
                return name

        raise RuntimeError(
            f"Gemma4Adapter: FFN attr name not found in block {block.__class__.__name__}"
        )

    # -------------------------
    # 3. Attention Leaf Modules 찾기
    # -------------------------
    def find_attention_leaf_modules(
        self, block: nn.Module, keywords: Sequence[str]
    ) -> List[str]:
        """Attention 모듈 내 projection layer 경로를 반환한다."""
        attn_module = None
        attn_name = "self_attn"

        if hasattr(block, "self_attn"):
            attn_module = block.self_attn
        else:
            for name, child in block.named_children():
                if "attn" in name.lower():
                    attn_module = child
                    attn_name = name
                    break

        if attn_module is None:
            return []

        leaf_names: List[str] = []
        for n, m in attn_module.named_modules():
            if not any(k in n for k in keywords):
                continue
            if len(list(m.children())) != 0:
                continue
            full_path = f"{attn_name}.{n}" if n else attn_name
            leaf_names.append(full_path)

        return sorted(list(set(leaf_names)))

    # -------------------------
    # 4. Native MoE Experts (Gemma 4 MoE variant)
    # -------------------------
    def find_native_expert_groups(self, block: nn.Module) -> List[ExpertGroup]:
        """Gemma 4 MoE variant에서 native expert group을 찾아 반환한다.

        Gemma 4 MoE DecoderLayer:
          - block.experts: Gemma4TextExperts (fused 3D tensors)
          - block.router: Gemma4TextRouter

        Dense variant에서는 빈 리스트를 반환한다.
        """
        enable_moe = getattr(block, "enable_moe_block", False)
        if not enable_moe:
            return []

        experts_module = getattr(block, "experts", None)
        router_module = getattr(block, "router", None)

        if experts_module is None:
            return []

        # Unfuse 3D expert tensors into individual slices for LoRA wrapping
        expert_slices = _unfuse_gemma4_experts(experts_module)

        if not expert_slices:
            # Not fused — try ModuleList-style experts
            expert_list = getattr(experts_module, "experts", None)
            if isinstance(expert_list, (list, nn.ModuleList)):
                expert_slices = list(expert_list)

        if not expert_slices:
            return []

        return [
            ExpertGroup(
                experts=expert_slices,
                router=router_module,
                name="gemma4_moe",
            )
        ]

    # -------------------------
    # 5. Default Keywords
    # -------------------------
    def default_ffn_keywords(self) -> Sequence[str]:
        return ["gate_proj", "up_proj", "down_proj"]

    def default_attn_keywords(self) -> Sequence[str]:
        return ["q_proj", "k_proj", "v_proj", "o_proj"]
