# eulerforge/adapters/backbones/qwen3.py
from __future__ import annotations

from typing import Iterable, List, Sequence
import torch.nn as nn

from .base import BackboneAdapter


def _is_module_list(x) -> bool:
    return isinstance(x, (nn.ModuleList, list, tuple))


def _get_attr_chain(obj, chain: Sequence[str]):
    cur = obj
    for name in chain:
        if not hasattr(cur, name):
            return None
        cur = getattr(cur, name)
    return cur



class Qwen3Adapter(BackboneAdapter):
    """
    Qwen3 계열(그리고 유사한 decoder-only CausalLM)에서 transformer block 리스트를 찾는 어댑터.

    목표:
      - model 구조가 조금씩 달라도 레이어 리스트를 robust 하게 찾아서
        injection 코드(dense_lora.py)가 순회 가능하게 만든다.

    주로 찾는 경로들:
      - model.model.layers (LLaMA/Qwen 계열에서 흔함)
      - model.transformer.h (GPT-2 계열)
      - model.gpt_neox.layers (GPT-NeoX 계열)
      - model.layers (일부 구현)
      - model.base_model.model.layers (PEFT/래핑 케이스)
    """

    name = "qwen3"

    def find_transformer_layers(self, model: nn.Module) -> Iterable[nn.Module]:
        # 0) PEFT/Wrapper 류에서 base_model/model로 한 번 벗겨보기 (있으면)
        candidates: List[nn.Module] = [model]
        for attr in ("base_model", "model"):
            if hasattr(model, attr) and isinstance(getattr(model, attr), nn.Module):
                candidates.append(getattr(model, attr))

        # 1) 흔한 경로들을 우선 탐색 (Qwen/LLaMA류)
        #    - Qwen/Qwen3.5-0.8B-Base는 보통 model.model.layers 형태가 기대됨.
        common_paths = [
            ("model", "layers"),           # model.model.layers
            ("transformer", "h"),          # GPT-2 style
            ("gpt_neox", "layers"),        # GPT-NeoX style
            ("layers",),                   # fallback
        ]

        for root in candidates:
            for path in common_paths:
                obj = _get_attr_chain(root, path)
                if obj is not None and _is_module_list(obj) and len(obj) > 0:
                    # list/tuple이면 그대로 반환, ModuleList면 iterable
                    return list(obj)

        # 2) 마지막 수단: 모듈 트리를 훑어서 "layers"라고 부르는 ModuleList를 찾기
        #    (너무 공격적이면 위험하지만, 여기서는 qwen3 adapter 목적상 유용)
        for name, mod in model.named_modules():
            # 예: "...model.layers" 같은 이름을 선호
            if name.endswith(".layers") or name in ("layers", "model.layers"):
                if isinstance(mod, nn.ModuleList) and len(mod) > 0:
                    return list(mod)

        raise ValueError(
            "Qwen3Adapter: cannot locate transformer layers. "
            "Tried model.model.layers / model.transformer.h / model.gpt_neox.layers / model.layers."
        )
        

    def find_ffn_attr_name(self, block: nn.Module) -> str:
        """
        Transformer block에서 FFN(=MLP) 모듈이 들어있는 attribute name을 반환.

        Mixture LoRA/Expert LoRA 주입 코드가 block에서 FFN을 가져오기 위해 사용한다. [file:23]
        """
        # 1) 가장 흔한 후보들 (Qwen/LLaMA/GPT류 변형 커버)
        candidates = (
            "mlp",
            "ffn",
            "feed_forward",
            "forward_layer",
            "Mlp",  # 일부 구현체에서 대문자/클래스명 비슷하게 쓰는 경우 대비
        )
        for name in candidates:
            if hasattr(block, name):
                mod = getattr(block, name)
                if isinstance(mod, nn.Module):
                    return name

        # 2) 일부 구현은 block 안에 "decoder_mlp" 같은 이름을 쓰기도 해서, 키워드 기반 탐색
        keyword_hits = []
        for name, child in block.named_children():
            if not isinstance(child, nn.Module):
                continue
            lname = name.lower()
            if ("mlp" in lname) or ("ffn" in lname) or ("feed" in lname):
                keyword_hits.append(name)

        if len(keyword_hits) == 1:
            return keyword_hits[0]
        if len(keyword_hits) > 1:
            # 너무 여러 개면 가장 짧은/대표적인 이름을 우선 (예: "mlp" 선호)
            keyword_hits.sort(key=lambda s: (s.lower() != "mlp", len(s)))
            return keyword_hits[0]

        # 3) 최후의 수단: named_modules에서 leaf 가까운 "mlp/ffn" 모듈 찾기
        #    (block.<attr> 로 접근 가능해야 하므로 1-depth child 이름만 대상으로 삼음)
        for name, child in block.named_children():
            if isinstance(child, nn.Module):
                lname = name.lower()
                if ("mlp" in lname) or ("ffn" in lname) or ("feed" in lname):
                    return name

        raise AttributeError(
            f"{self.__class__.__name__}: cannot find FFN module attribute in block "
            f"({block.__class__.__name__}). Tried common names: {candidates}"
        )

    def find_ffn_module(self, block: nn.Module) -> nn.Module:
            """
            Block 내부의 FFN(MLP) 모듈 객체를 반환합니다.
            """
            # 이미 구현된 attr_name 찾기 로직을 재사용
            ffn_name = self.find_ffn_attr_name(block)
            return getattr(block, ffn_name)

    # ─────────────────────────────────────────────────────────────────
    # Attention leaf 탐색 — Qwen3.5 linear_attn 호환성 fallback
    # ─────────────────────────────────────────────────────────────────
    # Qwen3.5 (transformers 5.5+)는 self_attn 대신 linear_attn (Qwen3_5GatedDeltaNet)
    # 사용. 모듈 이름이 q_proj/k_proj/v_proj/o_proj가 아닌
    # in_proj_qkv/in_proj_z/in_proj_b/in_proj_a/out_proj로 변경됨.
    #
    # 사용자가 표준 키워드(q_proj, v_proj, o_proj)를 지정하면 해당하는
    # linear_attn projection (in_proj_qkv, out_proj)으로 자동 fallback한다.
    _STANDARD_TO_LINEAR_ATTN: dict = {
        "q_proj": "in_proj_qkv",
        "k_proj": "in_proj_qkv",
        "v_proj": "in_proj_qkv",
        "o_proj": "out_proj",
    }

    def translate_attn_keywords(
        self, block: nn.Module, keywords: Sequence[str]
    ) -> List[str]:
        """Block 구조에 맞게 attention LoRA 키워드를 변환.

        Qwen3.5 linear_attn (GatedDeltaNet)에서는 q_proj/k_proj/v_proj/o_proj가 없고
        in_proj_qkv/out_proj 등을 사용하므로, 표준 키워드를 자동 변환한다.
        다른 backbone에서는 키워드를 그대로 반환.
        """
        # linear_attn (Qwen3.5)이면 표준 키워드 → linear_attn 키워드로 변환
        if hasattr(block, "linear_attn") and not hasattr(block, "self_attn"):
            mapped: List[str] = []
            for kw in keywords:
                target = self._STANDARD_TO_LINEAR_ATTN.get(kw, kw)
                if target not in mapped:
                    mapped.append(target)
            return mapped
        # 표준 self_attn이면 키워드 그대로
        return list(keywords)

    def find_attention_leaf_modules(
        self, block: nn.Module, keywords: Sequence[str]
    ) -> List[str]:
        """Attention leaf 모듈 경로를 반환.

        1) 표준 self_attn이 있으면 base 구현 사용 (q/k/v/o_proj 매칭)
        2) self_attn이 없고 linear_attn이 있으면 (Qwen3.5 GatedDeltaNet),
           표준 키워드를 in_proj_qkv/out_proj로 자동 변환하여 매칭
        """
        # 1차: 표준 base 구현
        names = super().find_attention_leaf_modules(block, keywords)
        if names:
            return names

        # 2차: Qwen3.5 linear_attn fallback
        if hasattr(block, "linear_attn"):
            translated = self.translate_attn_keywords(block, keywords)
            # 변환된 키워드 + 원본 키워드 둘 다 시도
            all_keywords = list(translated) + [kw for kw in keywords if kw not in translated]
            return super().find_attention_leaf_modules(block, all_keywords)

        return names
