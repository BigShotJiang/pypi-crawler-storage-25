# eulerforge/adapters/backbones/gemma3.py
"""
Gemma 3 BackboneAdapter.

Gemma 3 (1B, 4B, 12B, 27B) 텍스트 파인튜닝을 위한 구조 탐색 어댑터.
Gemma 3 only — Gemma 1/2는 지원 대상이 아니다.

HuggingFace 모델 구조:
  - 1B (text-only): Gemma3ForCausalLM
    → model.model (Gemma3TextModel) → .layers (ModuleList)
  - 4B+ (multimodal wrapper): Gemma3ForConditionalGeneration
    → model.model (Gemma3Model) → .language_model (Gemma3TextModel) → .layers
  두 경우 모두 block 구조는 동일:
    Gemma3DecoderLayer → self_attn (q/k/v/o_proj) + mlp (gate/up/down_proj)

멀티모달 전체 학습 지원 범위가 아님 — text backbone만 탐색한다.
"""

from __future__ import annotations

from typing import List, Sequence

import torch.nn as nn

from .base import BackboneAdapter


class Gemma3Adapter(BackboneAdapter):
    """Gemma 3 계열 text fine-tuning 어댑터."""

    name = "gemma3"

    # -------------------------
    # 1. Transformer Blocks 찾기
    # -------------------------
    def find_transformer_layers(self, model: nn.Module) -> Sequence[nn.Module]:
        """
        Gemma 3 text backbone의 transformer layers를 찾는다.

        1B (text-only):  model.model.layers
        4B+ (multimodal): model.model.language_model.layers

        탐색 순서:
        1. model.model.layers (1B, text-only)
        2. model.model.language_model.layers (4B+, multimodal wrapper)
        3. PEFT wrapper 해제 후 재시도
        """
        roots = [model]
        # PEFT wrapper 해제
        if hasattr(model, "base_model") and isinstance(
            getattr(model, "base_model"), nn.Module
        ):
            roots.append(model.base_model)

        for root in roots:
            # Path 1: root.model.layers (text-only, 1B)
            inner = getattr(root, "model", None)
            if inner is not None:
                layers = getattr(inner, "layers", None)
                if isinstance(layers, (list, nn.ModuleList)) and len(layers) > 0:
                    return list(layers)

                # Path 2: root.model.language_model.layers (multimodal wrapper, 4B+)
                lm = getattr(inner, "language_model", None)
                if lm is not None:
                    layers = getattr(lm, "layers", None)
                    if isinstance(layers, (list, nn.ModuleList)) and len(layers) > 0:
                        return list(layers)

        raise RuntimeError(
            "Gemma3Adapter: cannot locate transformer layers.\n"
            "Fix: Gemma 3 text backbone은 model.model.layers (1B) 또는 "
            "model.model.language_model.layers (4B+)에 있어야 합니다.\n"
            "See: docs/architectures/overview.md"
        )

    # -------------------------
    # 2. FFN (MLP) 모듈 찾기
    # -------------------------
    def find_ffn_module(self, block: nn.Module) -> nn.Module:
        """Gemma 3 block 내부의 FFN(MLP) 모듈을 반환한다."""
        if hasattr(block, "mlp") and isinstance(block.mlp, nn.Module):
            return block.mlp

        # Fallback
        for name, child in block.named_children():
            if name.lower() in ("mlp", "feed_forward", "ffn"):
                return child

        raise RuntimeError(
            f"Gemma3Adapter: FFN module not found in block {block.__class__.__name__}.\n"
            "Fix: Gemma 3 DecoderLayer는 'mlp' 속성을 가져야 합니다.\n"
            "See: docs/architectures/overview.md"
        )

    def find_ffn_attr_name(self, block: nn.Module) -> str:
        """FFN 모듈의 속성 이름(string)을 반환한다. MoE 교체 시 setattr에 사용."""
        if hasattr(block, "mlp") and isinstance(block.mlp, nn.Module):
            return "mlp"

        for name, child in block.named_children():
            if name.lower() in ("mlp", "feed_forward", "ffn"):
                return name

        raise RuntimeError(
            f"Gemma3Adapter: FFN attr name not found in block {block.__class__.__name__}"
        )

    # -------------------------
    # 3. Attention Leaf Modules 찾기
    # -------------------------
    def find_attention_leaf_modules(
        self, block: nn.Module, keywords: Sequence[str]
    ) -> List[str]:
        """Attention 모듈 내 projection layer 경로를 반환한다."""
        attn_module = None
        attn_name = "self_attn"

        if hasattr(block, "self_attn"):
            attn_module = block.self_attn
        else:
            for name, child in block.named_children():
                if "attn" in name.lower():
                    attn_module = child
                    attn_name = name
                    break

        if attn_module is None:
            return []

        leaf_names: List[str] = []
        for n, m in attn_module.named_modules():
            if not any(k in n for k in keywords):
                continue
            if len(list(m.children())) != 0:
                continue
            full_path = f"{attn_name}.{n}" if n else attn_name
            leaf_names.append(full_path)

        return sorted(list(set(leaf_names)))

    # -------------------------
    # 4. Default Keywords
    # -------------------------
    def default_ffn_keywords(self) -> Sequence[str]:
        return ["gate_proj", "up_proj", "down_proj"]

    def default_attn_keywords(self) -> Sequence[str]:
        return ["q_proj", "k_proj", "v_proj", "o_proj"]
