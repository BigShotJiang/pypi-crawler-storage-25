# -*- coding: utf-8 -*-
"""
eulerforge.adapters.backbones.llama

Llama 계열(Llama-2, Llama-3, CodeLlama 등) 및 파생 모델 지원용 어댑터.
HuggingFace LlamaForCausalLM 구조를 따릅니다.
"""

from __future__ import annotations

from typing import Iterable, List, Sequence, Optional
import torch.nn as nn

from .base import BackboneAdapter, ExpertGroup


class LlamaAdapter(BackboneAdapter):
    """
    LlamaAdapter
    
    Target Models:
      - meta-llama/Llama-2-*
      - meta-llama/Meta-Llama-3-*
      - upstage/SOLAR-*
      - 01-ai/Yi-* (Llama 아키텍처 기반)
    
    Structure Assumptions:
      - Transformer Layers: model.model.layers
      - FFN Module: layer.mlp
      - Attention Module: layer.self_attn
    """

    name = "llama"

    # -------------------------
    # 1. Transformer Blocks 찾기
    # -------------------------
    def find_transformer_layers(self, model: nn.Module) -> Sequence[nn.Module]:
        """
        Llama 모델은 보통 `model.model.layers`에 ModuleList가 존재합니다.
        """
        # 1) Standard HF LlamaForCausalLM: model.model.layers
        if hasattr(model, "model") and hasattr(model.model, "layers"):
            layers = getattr(model.model, "layers")
            if isinstance(layers, (list, nn.ModuleList)) and len(layers) > 0:
                return layers

        # 2) Fallback: model.layers (일부 변형 모델)
        if hasattr(model, "layers"):
            layers = getattr(model, "layers")
            if isinstance(layers, (list, nn.ModuleList)) and len(layers) > 0:
                return layers
        
        # 3) Fallback for wrapped models (PEFT 등)
        if hasattr(model, "base_model") and hasattr(model.base_model, "model"):
            if hasattr(model.base_model.model, "layers"):
                return model.base_model.model.layers

        raise RuntimeError("LlamaAdapter: Cannot find transformer layers. Expected 'model.model.layers'.")

    # -------------------------
    # 2. FFN (MLP) 모듈 찾기
    # -------------------------
    def find_ffn_module(self, block: nn.Module) -> nn.Module:
        """
        Llama Block 내부의 FFN(MLP) 모듈을 반환합니다.
        보통 'mlp'라는 이름을 가집니다.
        """
        # Standard Llama
        if hasattr(block, "mlp") and isinstance(block.mlp, nn.Module):
            return block.mlp
        
        # Fallback (대소문자 무관 탐색)
        for name, child in block.named_children():
            if name.lower() in ("mlp", "feed_forward", "ffn"):
                return child
        
        raise RuntimeError(f"LlamaAdapter: FFN module not found in block {block.__class__.__name__}")

    # -------------------------
    # 3. Attention Leaf Modules 찾기
    # -------------------------
    def find_attention_leaf_modules(
        self, block: nn.Module, keywords: Sequence[str]
    ) -> List[str]:
        """
        Attention 모듈(`self_attn`) 내부의 Projection Layer 이름들을 반환합니다.
        Llama는 보통 q_proj, k_proj, v_proj, o_proj를 사용합니다.
        """
        attn_module = None
        attn_name = "self_attn" # default

        # 1) Find Attention Module
        if hasattr(block, "self_attn"):
            attn_module = block.self_attn
        else:
            # Fallback search
            for name, child in block.named_children():
                if "attn" in name.lower():
                    attn_module = child
                    attn_name = name
                    break
        
        if attn_module is None:
            return []

        # 2) Find leaf linear modules matching keywords inside attn_module
        leaf_names: List[str] = []
        for n, m in attn_module.named_modules():
            # 키워드 매칭 (예: "q_proj")
            if not any(k in n for k in keywords):
                continue
            # 자식이 없는 leaf module만 대상
            if len(list(m.children())) == 0:
                # block 기준 상대 경로 생성 (예: "self_attn.q_proj")
                full_path = f"{attn_name}.{n}" if n else attn_name
                leaf_names.append(full_path)
        
        return sorted(list(set(leaf_names)))

    # -------------------------
    # 4. Default Keywords Override
    # -------------------------
    def default_ffn_keywords(self) -> Sequence[str]:
        # Llama uses: gate_proj, up_proj, down_proj
        return ["gate_proj", "up_proj", "down_proj"]

    def default_attn_keywords(self) -> Sequence[str]:
        # Llama uses: q_proj, k_proj, v_proj, o_proj
        return ["q_proj", "k_proj", "v_proj", "o_proj"]
    

    def find_ffn_attr_name(self, block: nn.Module) -> str:
        """
        MoE 인젝터가 해당 블록 내에서 FFN 모듈을 교체하기 위해
        속성 이름(string)을 알아야 할 때 사용합니다.
        """
        # 1) Standard Llama
        if hasattr(block, "mlp") and isinstance(block.mlp, nn.Module):
            return "mlp"
            
        # 2) Fallback: 자식 이름 순회
        for name, child in block.named_children():
            if name.lower() in ("mlp", "feed_forward", "ffn"):
                return name
        
        raise RuntimeError(f"LlamaAdapter: FFN attribute name not found in block {block.__class__.__name__}")