# eulerforge/plugins/__init__.py
# -*- coding: utf-8 -*-
"""
EulerForge Plugin Discovery System.

Plugin 명령은 core CLI에 하드코딩되지 않고, 이 모듈을 통해 동적으로 발견된다.
Plugin 모듈이 존재하면 자동 등록되고, 존재하지 않으면 CLI에서 자연스럽게 사라진다.

Plugin 등록 규칙:
1. `eulerforge/plugins/{name}_plugin.py` 모듈 생성
2. 모듈에 `PLUGIN_SPEC: PluginSpec` 변수 정의
3. `_PLUGIN_MODULES`에 모듈 경로 추가

공개 배포판에서 plugin 모듈을 제외하면 해당 명령이 자동 비활성화된다.
"""
from __future__ import annotations

import importlib
import logging
from dataclasses import dataclass
from typing import Any, Callable, List, Optional

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PluginSpec:
    """Plugin 명령 정의.

    Attributes:
        command: CLI 명령 이름 (예: "pretrain")
        help_key: i18n 메시지 키 (예: "help.cmd.pretrain")
        main_fn: 명령 실행 함수 (argv 인자 수용)
    """
    command: str
    help_key: str
    main_fn: Callable[..., Any]


# Plugin 모듈 경로 목록 — 여기에 추가하면 자동 발견됨
# 향후 enterprise 기능 후보:
#   "eulerforge.plugins.distributed_plugin"   — 멀티GPU/분산 훈련
#   "eulerforge.plugins.governance_plugin"    — ���델 거버넌스/컴플라이언스
#   "eulerforge.plugins.registry_plugin"      — 모델 레지스트리
#   "eulerforge.plugins.deploy_plugin"        — 모델 배포
_PLUGIN_MODULES: List[str] = [
    "eulerforge.plugins.pretrain_plugin",
]


def discover_plugins() -> List[PluginSpec]:
    """등록된 plugin 모듈을 탐색하여 사용 가능한 PluginSpec 목록을 반환.

    Import 실패하는 모듈은 건너뛴다 (graceful degradation).
    """
    specs: List[PluginSpec] = []
    for mod_path in _PLUGIN_MODULES:
        try:
            mod = importlib.import_module(mod_path)
            spec = getattr(mod, "PLUGIN_SPEC", None)
            if isinstance(spec, PluginSpec):
                specs.append(spec)
        except (ImportError, ModuleNotFoundError):
            # Plugin 미설치 → 조용히 건너뜀
            pass
        except Exception as e:
            logger.debug(f"[Plugin] Failed to load {mod_path}: {e}")
    return specs
