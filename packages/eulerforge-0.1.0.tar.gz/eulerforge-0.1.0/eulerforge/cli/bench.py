# eulerforge/cli/bench.py
# -*- coding: utf-8 -*-
"""
eulerforge bench — 추론 벤치마크.

YAML spec으로 target/baseline/judge 모델을 설정하고,
벤치마크 데이터에서 샘플을 추출하여 추론 결과를 비교한다.

target 지정 방법 (정확히 하나만 사용):
- models.target.model: API 모델명 (ollama/openai/gemini)
- models.target.output_dir: 학습 출력 디렉토리 (자동 체크포인트 해석)
- models.target.model_dir: HuggingFace save_pretrained() 디렉토리

실행 모드:
- target-only: target 응답만 출력
- comparison: target + baseline 비교 출력
- pointwise: judge가 target 응답을 점수 평가
- pairwise: judge가 target vs baseline을 비교 평가
"""
from __future__ import annotations

import argparse
import glob as _glob
import json
import logging
import os
import sys
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

from ..utils.config import parse_kv_overrides, resolve_config, save_json
from ..utils.bench_client import ChatClient, JudgeClient, LocalHFClient
from ..utils.bench_sampler import sample_bench_data, extract_prompt
from ..utils.validator import ConfigValidationError

logger = logging.getLogger(__name__)

# -------------------------------------------------------------------------
# 유효값 상수
# -------------------------------------------------------------------------
_VALID_TASKS = ("sft", "preference")
_VALID_API_PROVIDERS = ("ollama", "openai", "gemini")
_VALID_PROVIDERS = ("ollama", "openai", "gemini", "local_hf")
_VALID_JUDGE_MODES = ("pointwise", "pairwise")
_VALID_CHECKPOINTS = ("final", "latest", "best")


# -------------------------------------------------------------------------
# 로컬 모델 체크포인트 해석
# -------------------------------------------------------------------------
def resolve_target_model_dir(output_dir: str, checkpoint: str = "final") -> str:
    """학습 출력 루트 디렉토리에서 모델 디렉토리를 해석한다.

    탐색 순서:
    - checkpoint="final"  → {output_dir}/final/
    - checkpoint="best"   → {output_dir}/checkpoint-best/
    - checkpoint="latest" → {output_dir}/checkpoint-latest/
                            → 없으면 가장 큰 번호의 checkpoint-N/

    Args:
        output_dir: 학습 출력 루트 디렉토리
        checkpoint: "final" | "latest" | "best"

    Returns:
        해석된 절대/상대 경로 문자열

    Raises:
        ConfigValidationError: output_dir 미존재 또는 체크포인트 없음
    """
    _DOC = "docs/tutorials/11_bench.md"

    if not os.path.isdir(output_dir):
        raise ConfigValidationError(
            f"output_dir not found: {output_dir}",
            category="Bench Config",
            fix="Run eulerforge train first, or check the output_dir path",
            doc=_DOC,
        )

    if checkpoint == "final":
        candidate = os.path.join(output_dir, "final")
        if os.path.isdir(candidate):
            return candidate
        raise ConfigValidationError(
            f"No checkpoint found in {output_dir} (checkpoint=final): 'final/' directory missing",
            category="Bench Config",
            fix="Run eulerforge train first, or use --checkpoint latest/best, or --target-model-dir",
            doc=_DOC,
        )

    if checkpoint == "best":
        candidate = os.path.join(output_dir, "checkpoint-best")
        if os.path.isdir(candidate):
            return candidate
        raise ConfigValidationError(
            f"No checkpoint found in {output_dir} (checkpoint=best): 'checkpoint-best/' missing",
            category="Bench Config",
            fix="Train with save_best=true, or use --checkpoint final/latest",
            doc=_DOC,
        )

    if checkpoint == "latest":
        # 1순위: checkpoint-latest/
        candidate = os.path.join(output_dir, "checkpoint-latest")
        if os.path.isdir(candidate):
            return candidate
        # 2순위: 가장 큰 번호의 checkpoint-N/
        pattern = os.path.join(output_dir, "checkpoint-*")
        dirs = [d for d in _glob.glob(pattern) if os.path.isdir(d)]
        if dirs:
            # 번호 기준 정렬 (checkpoint-500 → 500)
            def _step(d: str) -> int:
                base = os.path.basename(d)
                part = base.split("-")[-1]
                return int(part) if part.isdigit() else -1

            dirs_sorted = sorted(dirs, key=_step)
            return dirs_sorted[-1]
        raise ConfigValidationError(
            f"No checkpoint found in {output_dir} (checkpoint=latest): no checkpoint-*/ dirs",
            category="Bench Config",
            fix="Run eulerforge train first, or use --target-model-dir for direct path",
            doc=_DOC,
        )

    raise ConfigValidationError(
        f"Unknown checkpoint value: '{checkpoint}'",
        category="Bench Config",
        fix=f"Set checkpoint to one of: {', '.join(_VALID_CHECKPOINTS)}",
        doc=_DOC,
    )


# -------------------------------------------------------------------------
# Bench Config 검증
# -------------------------------------------------------------------------
def validate_bench_config(cfg: Dict[str, Any]) -> None:
    """bench 섹션 검증. ConfigValidationError(3줄 포맷) 사용."""
    bench = cfg.get("bench")
    if bench is None:
        raise ConfigValidationError(
            "Missing required section: 'bench'",
            category="Bench Config",
            fix="Add a 'bench' section with task, data_path, and models",
            doc="docs/tutorials/11_bench.md",
        )
    if not isinstance(bench, dict):
        raise ConfigValidationError(
            "'bench' must be a dict",
            category="Bench Config",
            fix="Ensure 'bench' is a YAML mapping",
            doc="docs/tutorials/11_bench.md",
        )

    # task
    task = bench.get("task")
    if not task:
        raise ConfigValidationError(
            "Missing bench.task",
            category="Bench Config",
            fix=f"Set bench.task to one of: {', '.join(_VALID_TASKS)}",
            doc="docs/tutorials/11_bench.md",
        )
    if task not in _VALID_TASKS:
        raise ConfigValidationError(
            f"Unknown bench.task '{task}'",
            category="Bench Config",
            fix=f"Set bench.task to one of: {', '.join(_VALID_TASKS)}",
            doc="docs/tutorials/11_bench.md",
        )

    # data_path
    data_path = bench.get("data_path")
    if not data_path:
        raise ConfigValidationError(
            "Missing bench.data_path",
            category="Bench Config",
            fix="Set bench.data_path to a JSONL file path",
            doc="docs/tutorials/11_bench.md",
        )

    # sample
    sample_cfg = bench.get("sample", {})
    if isinstance(sample_cfg, dict):
        k = sample_cfg.get("k", 10)
        if not isinstance(k, int) or k < 0:
            raise ConfigValidationError(
                f"bench.sample.k must be a non-negative integer, got {k}",
                category="Bench Config",
                fix="Set bench.sample.k to a positive integer (e.g., 10)",
                doc="docs/tutorials/11_bench.md",
            )

    # models
    models = bench.get("models", {})
    if not isinstance(models, dict):
        raise ConfigValidationError(
            "'bench.models' must be a dict",
            category="Bench Config",
            fix="Add bench.models with at least a 'target' section",
            doc="docs/tutorials/11_bench.md",
        )

    # target (필수) — 규칙 1: model / output_dir / model_dir / export_dir 중 정확히 하나
    target = models.get("target", {})
    if not isinstance(target, dict):
        target = {}

    has_model = bool(target.get("model"))
    has_output_dir = bool(target.get("output_dir"))
    has_model_dir = bool(target.get("model_dir"))
    has_export_dir = bool(target.get("export_dir"))
    n_specified = sum([has_model, has_output_dir, has_model_dir, has_export_dir])

    if n_specified == 0:
        raise ConfigValidationError(
            "bench.models.target requires exactly one of: 'model', 'output_dir', 'model_dir', or 'export_dir'",
            category="Bench Config",
            fix="Set bench.models.target.model (API), output_dir (run dir), model_dir (HF dir), or export_dir (exported HF dir)",
            doc="docs/tutorials/11_bench.md",
        )
    if n_specified > 1:
        raise ConfigValidationError(
            "bench.models.target: exactly one of 'model', 'output_dir', 'model_dir', 'export_dir' is allowed — found multiple",
            category="Bench Config",
            fix="Remove all but one: model (API), output_dir (run dir), model_dir (HF dir), export_dir (exported HF dir)",
            doc="docs/tutorials/11_bench.md",
        )

    t_provider = target.get("provider")
    if has_model:
        # API 모델: provider는 ollama/openai/gemini
        if t_provider is None:
            t_provider = "ollama"
        if t_provider not in _VALID_API_PROVIDERS:
            raise ConfigValidationError(
                f"Unknown provider '{t_provider}' for target",
                category="Bench Config",
                fix=f"Set provider to one of: {', '.join(_VALID_API_PROVIDERS)}",
                doc="docs/tutorials/11_bench.md",
            )
    else:
        # 로컬 모델(output_dir / model_dir / export_dir): provider는 local_hf 또는 미설정
        if t_provider is not None and t_provider != "local_hf":
            raise ConfigValidationError(
                f"bench.models.target uses local dir, so provider must be 'local_hf' or unset — got '{t_provider}'",
                category="Bench Config",
                fix="Set provider: local_hf or remove the provider field",
                doc="docs/tutorials/11_bench.md",
            )
        # checkpoint 값 검증 (output_dir 사용 시)
        if has_output_dir:
            chk = target.get("checkpoint", "final")
            if chk not in _VALID_CHECKPOINTS:
                raise ConfigValidationError(
                    f"Unknown checkpoint value '{chk}' for target.output_dir",
                    category="Bench Config",
                    fix=f"Set checkpoint to one of: {', '.join(_VALID_CHECKPOINTS)}",
                    doc="docs/tutorials/11_bench.md",
                )
        # model_dir 존재 확인
        if has_model_dir:
            model_dir = target["model_dir"]
            if not os.path.isdir(model_dir):
                raise ConfigValidationError(
                    f"bench.models.target.model_dir not found: {model_dir}",
                    category="Bench Config",
                    fix="Set model_dir to an existing HuggingFace model directory",
                    doc="docs/tutorials/11_bench.md",
                )
        # export_dir 존재 확인
        if has_export_dir:
            export_dir_val = target["export_dir"]
            if not os.path.isdir(export_dir_val):
                raise ConfigValidationError(
                    f"bench.models.target.export_dir not found: {export_dir_val}",
                    category="Bench Config",
                    fix="Run eulerforge export-hf first, or check the export_dir path",
                    doc="docs/tutorials/11_bench.md",
                )

    # baseline (선택)
    baseline = models.get("baseline", {})
    if isinstance(baseline, dict) and baseline.get("enabled", False):
        # model_dir가 있으면 LocalHFClient로 로드 — provider 검증 건너뜀
        if not (baseline.get("model_dir") or baseline.get("export_dir")):
            b_provider = baseline.get("provider", "ollama")
            if b_provider not in _VALID_API_PROVIDERS:
                raise ConfigValidationError(
                    f"Unknown provider '{b_provider}' for baseline",
                    category="Bench Config",
                    fix=f"Set provider to one of: {', '.join(_VALID_API_PROVIDERS)}, or use model_dir for local HF models",
                    doc="docs/tutorials/11_bench.md",
                )

    # judge (선택)
    judge = models.get("judge", {})
    if isinstance(judge, dict) and judge.get("enabled", False):
        j_provider = judge.get("provider", "ollama")
        if j_provider not in _VALID_API_PROVIDERS:
            raise ConfigValidationError(
                f"Unknown provider '{j_provider}' for judge",
                category="Bench Config",
                fix=f"Set provider to one of: {', '.join(_VALID_API_PROVIDERS)}",
                doc="docs/tutorials/11_bench.md",
            )
        j_mode = judge.get("mode", "pointwise")
        if j_mode not in _VALID_JUDGE_MODES:
            raise ConfigValidationError(
                f"Unknown judge mode '{j_mode}'",
                category="Bench Config",
                fix=f"Set bench.models.judge.mode to one of: {', '.join(_VALID_JUDGE_MODES)}",
                doc="docs/tutorials/11_bench.md",
            )
        # pairwise에서 baseline 없으면 경고
        if j_mode == "pairwise":
            bl = models.get("baseline", {})
            if not (isinstance(bl, dict) and bl.get("enabled", False)):
                logger.warning(
                    "[Bench] Judge mode is 'pairwise' but baseline is not enabled. "
                    "Pairwise scoring requires two responses. Falling back to pointwise."
                )


# -------------------------------------------------------------------------
# 모델 클라이언트 생성 헬퍼
# -------------------------------------------------------------------------
def _create_client(model_cfg: Dict[str, Any], role: str):
    """role별 모델 클라이언트를 생성한다.

    Args:
        model_cfg: 모델 설정 dict (target/baseline/judge)
        role: "target" | "baseline" | "judge"

    Returns:
        ChatClient | JudgeClient | LocalHFClient
    """
    if role == "judge":
        return JudgeClient.from_config(model_cfg)
    if model_cfg.get("model_dir") or model_cfg.get("export_dir"):
        return LocalHFClient.from_config(model_cfg)
    return ChatClient.from_config(model_cfg)


# -------------------------------------------------------------------------
# 벤치 실행 (순차 모델 로딩)
# -------------------------------------------------------------------------
def run_bench(cfg: Dict[str, Any], output_dir: str, dry_run: bool = False) -> None:
    """메인 벤치 루프 — 순차 모델 로딩.

    OOM 방지를 위해 모델을 1개씩 로드하여 전체 데이터를 처리한 뒤 언로드한다.
    Phase 1: target → 전체 샘플 추론 → 언로드
    Phase 2: baseline → 전체 샘플 추론 → 언로드 (enabled일 때)
    Phase 3: judge → 전체 샘플 평가 → 언로드 (enabled일 때)
    Phase 4: 결과 통합 → 기존과 동일한 출력 포맷
    """
    bench = cfg["bench"]
    task = bench["task"]
    data_path = bench["data_path"]

    # 샘플링 설정
    sample_cfg = bench.get("sample", {})
    k = sample_cfg.get("k", 10)
    seed = sample_cfg.get("seed", 42)
    shuffle = sample_cfg.get("shuffle", True)

    # 생성 설정
    gen_cfg = bench.get("generation", {})

    # 출력 설정
    out_cfg = bench.get("output", {})
    save_jsonl = out_cfg.get("save_jsonl", True)
    print_examples = out_cfg.get("print_examples", True)
    print_max_chars = out_cfg.get("print_max_chars", 1500)

    # 1. 데이터 샘플링
    logger.info(f"[Bench] Sampling {k} items from {data_path} (seed={seed})")
    samples = sample_bench_data(data_path, k=k, seed=seed, shuffle=shuffle)
    logger.info(f"[Bench] Sampled {len(samples)} items")

    if dry_run:
        print(f"\n[Dry-run] {len(samples)} samples extracted:")
        for i, item in enumerate(samples):
            prompt = extract_prompt(item, task)
            print(f"  [{i}] {prompt[:100]}{'...' if len(prompt) > 100 else ''}")
        return

    # 모델 설정 추출
    models = bench.get("models", {})
    target_cfg = models["target"]
    baseline_cfg = models.get("baseline", {})
    baseline_enabled = isinstance(baseline_cfg, dict) and baseline_cfg.get("enabled", False)
    judge_cfg = models.get("judge", {})
    judge_enabled = isinstance(judge_cfg, dict) and judge_cfg.get("enabled", False)

    # 실행 모드 결정
    judge_mode = judge_cfg.get("mode", "pointwise") if judge_enabled else None
    if judge_enabled and judge_mode == "pairwise" and not baseline_enabled:
        judge_mode = "pointwise"
        logger.warning("[Bench] Pairwise requires baseline. Falling back to pointwise.")

    # 프롬프트 추출
    prompts: List[Optional[str]] = []
    for item in samples:
        prompts.append(extract_prompt(item, task))

    target_model_id = (
        target_cfg.get("model")
        or target_cfg.get("model_dir")
        or target_cfg.get("export_dir")
        or target_cfg.get("output_dir", "unknown")
    )

    os.makedirs(output_dir, exist_ok=True)

    # ---- Phase 1: target ----
    logger.info(f"[Bench] Phase 1/3: Loading target model...")
    target_client = _create_client(target_cfg, "target")
    if target_cfg.get("model_dir"):
        logger.info(f"[Bench] Target (local_hf): {target_cfg['model_dir']}")
    elif target_cfg.get("model"):
        logger.info(f"[Bench] Target: {target_cfg['model']} ({target_cfg.get('provider', 'ollama')})")

    target_responses: Dict[int, str] = {}
    for idx, prompt in enumerate(prompts):
        if not prompt:
            continue
        messages = [{"role": "user", "content": prompt}]
        logger.info(f"[Phase1 Target] [{idx+1}/{len(samples)}] Generating response...")
        try:
            target_responses[idx] = target_client.chat(messages, gen_cfg)
        except Exception as e:
            logger.error(f"[Bench] Target generation failed: {e}")
            target_responses[idx] = f"[ERROR] {e}"

    target_client.unload()
    logger.info("[Bench] Phase 1 complete: target unloaded")

    # ---- Phase 2: baseline (if enabled) ----
    baseline_responses: Dict[int, str] = {}
    if not baseline_enabled:
        logger.info("[Bench] Baseline: disabled (skipping Phase 2)")
    if baseline_enabled:
        logger.info(f"[Bench] Phase 2/3: Loading baseline model...")
        baseline_client = _create_client(baseline_cfg, "baseline")
        _bl_name = baseline_cfg.get("model") or baseline_cfg.get("model_dir") or baseline_cfg.get("export_dir") or "unknown"
        logger.info(f"[Bench] Baseline: {_bl_name}")

        for idx, prompt in enumerate(prompts):
            if not prompt or idx not in target_responses:
                continue
            messages = [{"role": "user", "content": prompt}]
            logger.info(f"[Phase2 Baseline] [{idx+1}/{len(samples)}] Generating response...")
            try:
                resp = baseline_client.chat(messages, gen_cfg)
                if not resp or not resp.strip():
                    logger.warning(f"[Bench] Baseline returned empty response for sample {idx}")
                baseline_responses[idx] = resp
            except Exception as e:
                logger.error(f"[Bench] Baseline generation failed: {e}")
                baseline_responses[idx] = f"[ERROR] {e}"

        baseline_client.unload()
        logger.info("[Bench] Phase 2 complete: baseline unloaded")

    # ---- Phase 3: judge (if enabled) ----
    judge_results: Dict[int, Dict[str, Any]] = {}
    if judge_enabled:
        logger.info(f"[Bench] Phase 3/3: Loading judge model...")
        judge_client = _create_client(judge_cfg, "judge")
        logger.info(f"[Bench] Judge: {judge_cfg['model']} (mode={judge_mode})")

        for idx, prompt in enumerate(prompts):
            if not prompt or idx not in target_responses:
                continue
            logger.info(f"[Phase3 Judge] [{idx+1}/{len(samples)}] Evaluating ({judge_mode})...")
            try:
                target_resp = target_responses[idx]
                has_baseline = baseline_enabled and idx in baseline_responses
                baseline_resp = baseline_responses.get(idx, "") if has_baseline else ""

                if judge_mode == "pairwise" and has_baseline:
                    score = judge_client.score_pairwise(
                        prompt, target_resp, baseline_resp, gen_cfg,
                    )
                elif judge_mode == "pointwise" and has_baseline and baseline_resp:
                    # pointwise + baseline: 두 모델 모두 별도 평가
                    target_score = judge_client.score_pointwise(prompt, target_resp, gen_cfg)
                    baseline_score = judge_client.score_pointwise(prompt, baseline_resp, gen_cfg)
                    score = {
                        "target_score": target_score.get("score", 0),
                        "target_explanation": target_score.get("explanation", ""),
                        "baseline_score": baseline_score.get("score", 0),
                        "baseline_explanation": baseline_score.get("explanation", ""),
                        "score": target_score.get("score", 0),  # 하위호환
                    }
                else:
                    score = judge_client.score_pointwise(prompt, target_resp, gen_cfg)
                judge_results[idx] = score
            except Exception as e:
                logger.error(f"[Bench] Judge evaluation failed: {e}")
                judge_results[idx] = {"error": str(e)}

        judge_client.unload()
        logger.info("[Bench] Phase 3 complete: judge unloaded")

    # ---- Phase 4: 결과 통합 ----
    results: List[Dict[str, Any]] = []
    for idx, prompt in enumerate(prompts):
        if not prompt or idx not in target_responses:
            continue

        entry: Dict[str, Any] = {
            "id": idx,
            "prompt": prompt,
            "target_response": target_responses[idx],
            "target_model": target_model_id,
        }

        if idx in baseline_responses:
            entry["baseline_response"] = baseline_responses[idx]
            entry["baseline_model"] = baseline_cfg.get("model", "unknown")

        if idx in judge_results:
            entry["judge_result"] = judge_results[idx]

        results.append(entry)

        # 터미널 출력
        if print_examples:
            _print_entry(entry, idx, print_max_chars, judge_mode)

    # 5. 결과 저장
    if save_jsonl:
        out_path = os.path.join(output_dir, "bench_results.jsonl")
        with open(out_path, "w", encoding="utf-8") as f:
            for entry in results:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        logger.info(f"[Bench] Results saved to {out_path}")

    # 요약 저장
    summary = _build_summary(results, cfg, judge_mode)
    summary_path = os.path.join(output_dir, "bench_summary.json")
    save_json(summary_path, summary)
    logger.info(f"[Bench] Summary saved to {summary_path}")

    # 요약 출력
    _print_summary(summary)


# -------------------------------------------------------------------------
# 출력 헬퍼
# -------------------------------------------------------------------------
def _print_entry(
    entry: Dict[str, Any], idx: int, max_chars: int, judge_mode: Optional[str]
) -> None:
    """단일 벤치 결과를 터미널에 출력."""
    prompt = entry["prompt"]
    print(f"\n{'='*60}")
    print(f"[Sample {idx}]")
    print(f"Prompt: {prompt[:max_chars]}")
    print(f"\nTarget ({entry.get('target_model', '?')}):")
    print(f"  {entry['target_response'][:max_chars]}")

    if "baseline_response" in entry:
        print(f"\nBaseline ({entry.get('baseline_model', '?')}):")
        print(f"  {entry['baseline_response'][:max_chars]}")

    if "judge_result" in entry:
        jr = entry["judge_result"]
        if "error" in jr:
            print(f"\nJudge: [ERROR] {jr['error']}")
        elif judge_mode == "pairwise":
            print(f"\nJudge (pairwise): Winner={jr.get('winner', '?')} "
                  f"Score A={jr.get('score_a', '?')} B={jr.get('score_b', '?')}")
            print(f"  {jr.get('explanation', '')[:max_chars]}")
        elif "target_score" in jr and "baseline_score" in jr:
            # pointwise + baseline: 두 모델 모두 별도 평가
            print(f"\nJudge (pointwise): Target={jr['target_score']}/10  "
                  f"Baseline={jr['baseline_score']}/10")
            print(f"  [Target]   {jr.get('target_explanation', '')[:max_chars]}")
            print(f"  [Baseline] {jr.get('baseline_explanation', '')[:max_chars]}")
        else:
            print(f"\nJudge (pointwise): Score={jr.get('score', '?')}/10")
            print(f"  {jr.get('explanation', '')[:max_chars]}")


def _build_summary(
    results: List[Dict[str, Any]],
    cfg: Dict[str, Any],
    judge_mode: Optional[str],
) -> Dict[str, Any]:
    """벤치 결과 요약 생성."""
    target_cfg = cfg["bench"]["models"]["target"]
    target_id = (
        target_cfg.get("model")
        or target_cfg.get("model_dir")
        or target_cfg.get("output_dir", "unknown")
    )
    summary: Dict[str, Any] = {
        "total_samples": len(results),
        "task": cfg["bench"]["task"],
        "target_model": target_id,
        "timestamp": datetime.now().isoformat(),
    }

    bl_cfg = cfg["bench"]["models"].get("baseline", {})
    if isinstance(bl_cfg, dict) and bl_cfg.get("enabled"):
        summary["baseline_model"] = bl_cfg.get("model") or bl_cfg.get("model_dir") or bl_cfg.get("export_dir") or "unknown"

    if judge_mode:
        summary["judge_mode"] = judge_mode
        judge_results = [r["judge_result"] for r in results if "judge_result" in r and "error" not in r.get("judge_result", {})]
        if judge_mode == "pointwise" and judge_results:
            # target 점수
            target_scores = [jr["target_score"] for jr in judge_results if "target_score" in jr]
            if not target_scores:
                target_scores = [jr["score"] for jr in judge_results if "score" in jr]
            if target_scores:
                summary["target_avg_score"] = round(sum(target_scores) / len(target_scores), 2)
                summary["target_min_score"] = min(target_scores)
                summary["target_max_score"] = max(target_scores)
                # 하위호환: avg_score = target_avg_score
                summary["avg_score"] = summary["target_avg_score"]
                summary["min_score"] = summary["target_min_score"]
                summary["max_score"] = summary["target_max_score"]
            # baseline 점수 (pointwise + baseline 모드)
            baseline_scores = [jr["baseline_score"] for jr in judge_results if "baseline_score" in jr]
            if baseline_scores:
                summary["baseline_avg_score"] = round(sum(baseline_scores) / len(baseline_scores), 2)
                summary["baseline_min_score"] = min(baseline_scores)
                summary["baseline_max_score"] = max(baseline_scores)
        elif judge_mode == "pairwise" and judge_results:
            wins_a = sum(1 for jr in judge_results if jr.get("winner") == "A")
            wins_b = sum(1 for jr in judge_results if jr.get("winner") == "B")
            ties = sum(1 for jr in judge_results if jr.get("winner") == "tie")
            summary["target_wins"] = wins_a
            summary["baseline_wins"] = wins_b
            summary["ties"] = ties

    return summary


def _print_summary(summary: Dict[str, Any]) -> None:
    """요약을 터미널에 출력."""
    print(f"\n{'='*60}")
    print("[Bench Summary]")
    print(f"  Task: {summary['task']}")
    print(f"  Samples: {summary['total_samples']}")
    print(f"  Target: {summary['target_model']}")
    if "baseline_model" in summary:
        print(f"  Baseline: {summary['baseline_model']}")
    if "target_avg_score" in summary and "baseline_avg_score" in summary:
        print(f"  Pointwise Target:   avg={summary['target_avg_score']} "
              f"min={summary['target_min_score']} max={summary['target_max_score']}")
        print(f"  Pointwise Baseline: avg={summary['baseline_avg_score']} "
              f"min={summary['baseline_min_score']} max={summary['baseline_max_score']}")
    elif "avg_score" in summary:
        print(f"  Pointwise Score: avg={summary['avg_score']} "
              f"min={summary['min_score']} max={summary['max_score']}")
    if "target_wins" in summary:
        print(f"  Pairwise: Target wins={summary['target_wins']} "
              f"Baseline wins={summary['baseline_wins']} "
              f"Ties={summary['ties']}")
    print(f"{'='*60}\n")


# -------------------------------------------------------------------------
# CLI
# -------------------------------------------------------------------------
def build_argparser() -> argparse.ArgumentParser:
    from eulerforge.i18n import t

    parser = argparse.ArgumentParser(
        prog="eulerforge bench",
        description=t("help.bench.description"),
    )
    parser.add_argument(
        "--preset", type=str, required=True,
        help=t("help.bench.preset"),
    )
    parser.add_argument(
        "--set", dest="sets", action="append", default=[],
        help=t("help.bench.set"),
    )
    parser.add_argument(
        "--output-dir", type=str, default=None,
        help=t("help.bench.output_dir"),
    )
    parser.add_argument(
        "--validate-only", action="store_true",
        help=t("help.bench.validate_only"),
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help=t("help.bench.dry_run"),
    )
    # 로컬 모델 지정 플래그
    parser.add_argument(
        "--target-output-dir", type=str, default=None,
        help=t("help.bench.target_output_dir"),
    )
    parser.add_argument(
        "--checkpoint", type=str, default="final",
        choices=_VALID_CHECKPOINTS,
        help=t("help.bench.checkpoint"),
    )
    parser.add_argument(
        "--target-model-dir", type=str, default=None,
        help=t("help.bench.target_model_dir"),
    )
    parser.add_argument(
        "--target-device", type=str, default=None,
        help=t("help.bench.target_device"),
    )
    return parser


def main(argv=None):
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        stream=sys.stdout,
    )

    parser = build_argparser()
    args = parser.parse_args(argv)

    # Config 로딩
    overrides = parse_kv_overrides(args.sets)
    resolved = resolve_config(preset_path=args.preset, overrides=overrides)
    cfg = resolved.config

    # --set data_path=X 편의 지원: 최상위 data_path → bench.data_path로 호이스팅
    # bench는 bench.data_path를 읽으므로, 최상위 data_path가 있으면 bench 섹션으로 이동
    if "data_path" in cfg and "bench" in cfg and isinstance(cfg["bench"], dict):
        cfg["bench"]["data_path"] = cfg.pop("data_path")

    # CLI 플래그로 target 오버라이드 적용
    target_cfg = cfg.setdefault("bench", {}).setdefault("models", {}).setdefault("target", {})
    if args.target_output_dir:
        # --target-output-dir → output_dir 오버라이드 (model/model_dir 제거)
        target_cfg.pop("model", None)
        target_cfg.pop("model_dir", None)
        target_cfg["output_dir"] = args.target_output_dir
    if args.target_model_dir:
        # --target-model-dir → model_dir 오버라이드 (model/output_dir 제거)
        target_cfg.pop("model", None)
        target_cfg.pop("output_dir", None)
        target_cfg["model_dir"] = args.target_model_dir
    # --checkpoint 오버라이드 (target-output-dir 또는 output_dir 사용 시)
    if args.checkpoint != "final" or args.target_output_dir:
        if target_cfg.get("output_dir"):
            target_cfg["checkpoint"] = args.checkpoint
    # --target-device 오버라이드
    if args.target_device:
        target_cfg["device"] = args.target_device

    # 검증
    try:
        validate_bench_config(cfg)
    except ConfigValidationError as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

    if args.validate_only:
        print("Bench config validation passed.")
        return

    # output_dir → model_dir 해석 (로컬 모델)
    if target_cfg.get("output_dir") and not target_cfg.get("model_dir"):
        try:
            resolved_model_dir = resolve_target_model_dir(
                target_cfg["output_dir"],
                checkpoint=target_cfg.get("checkpoint", "final"),
            )
        except ConfigValidationError as e:
            print(str(e), file=sys.stderr)
            sys.exit(1)
        # output_dir → model_dir로 교체 (run_bench에서 LocalHFClient 사용)
        target_cfg["model_dir"] = resolved_model_dir
        logger.info(f"[Bench] Resolved model_dir: {resolved_model_dir}")

    # data_path 존재 확인 (검증 후 실행 전)
    data_path = cfg["bench"]["data_path"]
    if not os.path.isfile(data_path):
        print(
            f"Bench Config: Data file not found: {data_path}\n"
            f"Fix: Ensure bench.data_path points to an existing JSONL file\n"
            f"See: docs/tutorials/11_bench.md",
            file=sys.stderr,
        )
        sys.exit(1)

    # 출력 디렉토리
    out_cfg = cfg["bench"].get("output", {})
    output_dir = args.output_dir or out_cfg.get(
        "out_dir",
        os.path.join("outputs", "bench", datetime.now().strftime("run_%Y%m%d_%H%M%S")),
    )

    logger.info(f"[Bench] Output dir: {output_dir}")

    # resolved config 저장 (model_dir 반영)
    os.makedirs(output_dir, exist_ok=True)
    resolved.save_resolved(output_dir, "bench_resolved_config.json")

    # 실행
    run_bench(cfg, output_dir, dry_run=args.dry_run)


if __name__ == "__main__":
    main()
