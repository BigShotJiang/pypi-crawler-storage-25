# eulerforge/cli/convert.py
# -*- coding: utf-8 -*-
"""
eulerforge convert — convert arbitrary JSONL to standard raw JSONL.

Two modes:
  Recipe:   --recipe <name> [--messages-expr <expr>]
  Map:      --map OUT_KEY=EXPR  (repeatable)

Examples:
  eulerforge convert --task sft --input data.jsonl --output out.jsonl \\
      --recipe sft_messages --messages-expr json_record.messages

  eulerforge convert --task sft --input data.jsonl --output out.jsonl \\
      --map prompt=instruction --map response=output

  eulerforge convert --task sft --input data.jsonl --print-sample-flat

  eulerforge convert --task sft --input data.jsonl --validate
"""
from __future__ import annotations

import argparse
import os
import sys
import logging
from typing import List, Optional

from ..utils.convert import VALID_TASKS, VALID_RECIPES

logger = logging.getLogger(__name__)

_CONVERT_DOC = "docs/tutorials/00_data_preprocessing.md"


def _error_exit(what: str, fix: str) -> None:
    """Print 3-line error and exit 1."""
    sys.stderr.write(f"\nConvert: {what}\nFix: {fix}\nSee: {_CONVERT_DOC}\n")
    sys.exit(1)


def build_argparser() -> argparse.ArgumentParser:
    from eulerforge.i18n import t

    p = argparse.ArgumentParser(
        prog="eulerforge convert",
        description=t("help.convert.description"),
    )
    p.add_argument("--task", required=True, choices=VALID_TASKS,
                   help=t("help.convert.task"))
    p.add_argument("--input", required=True, help=t("help.convert.input"))
    p.add_argument("--output", default=None,
                   help=t("help.convert.output"))

    # Recipe mode
    p.add_argument("--recipe", choices=VALID_RECIPES,
                   help=t("help.convert.recipe"))
    p.add_argument("--messages-expr", default=None,
                   help=t("help.convert.messages_expr"))

    # Map mode
    p.add_argument("--map", action="append", metavar="OUT_KEY=EXPR",
                   help=t("help.convert.map"))
    p.add_argument("--flatten", choices=["dot", "none"], default="dot",
                   help=t("help.convert.flatten"))
    p.add_argument("--join-sep", default="\n",
                   help=t("help.convert.join_sep"))
    p.add_argument("--strict", action="store_true",
                   help=t("help.convert.strict"))

    # Options
    p.add_argument("--num-proc", type=int, default=1,
                   help=t("help.convert.num_proc"))
    p.add_argument("--overwrite", action="store_true",
                   help=t("help.convert.overwrite"))
    p.add_argument("--max-rows", type=int, default=None,
                   help=t("help.convert.max_rows"))
    p.add_argument("--validate", action="store_true",
                   help=t("help.convert.validate"))
    p.add_argument("--print-sample-flat", action="store_true",
                   help=t("help.convert.print_sample"))
    return p


def main(argv: Optional[List[str]] = None) -> None:
    parser = build_argparser()
    args = parser.parse_args(argv)

    # Validate input exists
    if not os.path.isfile(args.input):
        _error_exit(
            f"input file not found: {args.input}",
            "Check the --input path",
        )

    from ..utils.convert import (
        get_recipe,
        build_converter_from_map,
        convert_file,
        validate_file,
        print_sample_flat,
    )

    # Mode 1: --print-sample-flat → show fields and exit
    if args.print_sample_flat:
        print_sample_flat(args.input, flatten_mode=args.flatten)
        sys.exit(0)

    # Mode 2: --validate (validate-only, no conversion)
    if args.validate and args.output is None:
        result = validate_file(args.input, args.task)
        total = result["valid"] + result["invalid"]
        print(
            f"[Validate] {result['valid']}/{total} valid rows"
            f" ({result['invalid']} invalid) in {args.input}"
        )
        sys.exit(1 if result["invalid"] > 0 else 0)

    # Mode 3: Conversion
    if args.output is None:
        _error_exit(
            "--output is required for conversion",
            "Provide --output <path> or use --validate / --print-sample-flat",
        )

    # Validate output does not exist (unless --overwrite)
    if os.path.exists(args.output) and not args.overwrite:
        _error_exit(
            f"output file already exists: {args.output}",
            "Use --overwrite to replace, or choose a different --output path",
        )

    # Determine converter: recipe or --map
    has_recipe = args.recipe is not None
    has_map = bool(args.map)

    if not has_recipe and not has_map:
        _error_exit(
            "no conversion method specified",
            "Provide --recipe <name> or --map OUT_KEY=EXPR (repeatable)",
        )

    if has_recipe:
        try:
            converter, _expected_task = get_recipe(
                args.recipe, messages_expr=args.messages_expr
            )
        except ValueError as e:
            _error_exit(str(e), "Check --recipe and --messages-expr")
    else:
        try:
            converter = build_converter_from_map(
                args.task,
                args.map,
                flatten_mode=args.flatten,
                join_sep=args.join_sep,
                strict=args.strict,
            )
        except ValueError as e:
            _error_exit(str(e), "Check --map expressions (format: OUT_KEY=EXPR)")

    try:
        stats = convert_file(
            input_path=args.input,
            output_path=args.output,
            task=args.task,
            converter=converter,
            num_proc=args.num_proc,
            max_rows=args.max_rows,
            validate=True,
        )
        print(
            f"[Convert] Done. {stats['converted']}/{stats['total']} rows converted"
            f" ({stats['errors']} errors) → {args.output}"
        )
    except Exception as e:
        _error_exit(str(e), "Check input data format or recipe/--map options")
