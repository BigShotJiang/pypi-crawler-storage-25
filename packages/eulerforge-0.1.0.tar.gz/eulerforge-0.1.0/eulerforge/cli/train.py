# -*- coding: utf-8 -*-
"""
eulerforge.cli.train

EulerForge 훈련 엔트리 CLI.

주요 흐름
1) preset YAML + --set overrides로 config 생성
2) BackboneAdapter 선택
3) 모델 로드(HF transformers) - [Modified] 4/8bit Quantization 지원
4) InjectionStrategy 적용(A/B/C 모드)
5) checkpoint resume(옵션)
6) 데이터셋/DataLoader 준비
7) Optimizer/Scheduler 준비
8) Phase schedule 적용(Phase1/Phase2 freeze/unfreeze 정책)
9) 학습 루프(aux loss 합산, gradient accumulation, checkpoint 저장)
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
import shutil
import traceback
import copy
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

# [Modified] BitsAndBytesConfig 추가
from transformers import AutoTokenizer, AutoModelForCausalLM, get_scheduler, BitsAndBytesConfig

from ..utils.config import (
    ResolvedConfig,
    parse_kv_overrides,
    resolve_config,
)
from ..utils.moe_loss import combine_main_and_aux_loss
from ..utils.validator import validate_config, ConfigValidationError
from eulerforge.utils.data import ProcessedSFTDataset, ProcessedPromptDataset, make_collate_fn

# Adapters (backbone 선택용)
from ..adapters.backbones.base import BackboneAdapter
from eulerforge.adapters.backbones.qwen3 import Qwen3Adapter
from eulerforge.adapters.backbones.llama import LlamaAdapter
from eulerforge.adapters.backbones.gemma3 import Gemma3Adapter
from eulerforge.adapters.backbones.gemma4 import Gemma4Adapter

# Injection strategies
from ..injection.dense_lora import DenseLoRAInjection
from ..injection.dense_moe_expert_lora import DenseMoEExpertLoRAInjection
from ..injection.native_moe_expert_lora import NativeMoEExpertLoRAInjection

# Phase schedules
from eulerforge.phase_schedules import build_phase_schedule
from eulerforge.phase_schedules.universal import UniversalPhaseScheduler

from eulerforge.modules.utils import AdapterLayerMixin
from eulerforge.utils.preflight import run_preflight_check, PreflightError
from eulerforge.utils.metrics import MetricsCollector, TBWriter
from eulerforge.i18n import t as _t


logger = logging.getLogger(__name__)

# -------------------------
# Debug 옵션/유틸
# -------------------------

@dataclass
class DebugOptions:
    enabled: bool = False
    every: int = 50                 # N step마다 상세 출력
    max_modules: int = 50           # 너무 많아지는 것 방지
    topk_grad: int = 20
    attn: bool = False              # attention 관련 추가 출력
    dump_trainable_names: bool = False
    moe_routing: bool = True        # MixtureLoRA routing 통계 시도
    max_trainable_names: int = 200


def _now_tag() -> str:
    return time.strftime("%Y%m%d_%H%M%S", time.localtime())


def _ensure_dir(p: str) -> None:
    os.makedirs(p, exist_ok=True)


def _detect_eulerforge_checkpoint(model_name: str) -> Optional[Dict[str, Any]]:
    """model_name이 EulerForge LoRA 체크포인트 디렉토리인지 탐지.

    SFT → DPO 등 파이프라인 연속 훈련에서, model_name이 이전 훈련의
    체크포인트(lora_info.json 포함)를 가리키는 경우를 탐지한다.

    Returns:
        dict: base_model_name, checkpoint_dir, strategy 등 정보
        None: eulerforge 체크포인트가 아닌 경우 (일반 HF 모델)
    """
    # Hub 모델 이름이면 즉시 None
    if not os.path.isdir(model_name):
        return None

    # lora_info.json이 없으면 일반 HF 디렉토리
    lora_info_path = os.path.join(model_name, "lora_info.json")
    if not os.path.isfile(lora_info_path):
        return None

    # resolved_config.json 탐색: 같은 디렉토리 → 부모 디렉토리
    resolved_cfg = None
    for candidate in [model_name, os.path.dirname(os.path.abspath(model_name))]:
        rc_path = os.path.join(candidate, "resolved_config.json")
        if os.path.isfile(rc_path):
            with open(rc_path, "r", encoding="utf-8") as f:
                resolved_cfg = json.load(f)
            break

    if resolved_cfg is None:
        # base 모델을 알 수 없으면 None 반환 — 일반 경로로 fallback
        return None

    with open(lora_info_path, "r", encoding="utf-8") as f:
        lora_info = json.load(f)

    base_model_name = resolved_cfg.get("model_name", "")
    if not base_model_name:
        return None

    return {
        "base_model_name": base_model_name,
        "checkpoint_dir": str(model_name),
        "strategy": lora_info.get("strategy", "dense_lora"),
        "lora_info": lora_info,
        "resolved_config": resolved_cfg,
    }


def _override_injection_from_checkpoint(
    cfg: Dict[str, Any],
    ckpt_info: Dict[str, Any],
) -> None:
    """파이프라인 연속 훈련 시, 이전 체크포인트의 injection 설정으로 현재 config를 override.

    SFT(lora_r=48) → DPO(lora_r=24) 파이프라인에서, DPO 단계가 SFT 체크포인트를
    로드할 때 LoRA 구조가 일치해야 한다. 이전 체크포인트의 resolved_config.json에
    저장된 injection 파라미터(lora_r, lora_alpha, target_keywords, start_layer,
    num_layers, attn_lora 등)를 현재 config에 병합한다.

    training 설정(type, lr 등)은 override하지 않는다.
    """
    ckpt_resolved = ckpt_info.get("resolved_config", {})
    ckpt_injection = ckpt_resolved.get("injection")

    if not ckpt_injection:
        return

    current_injection = cfg.get("injection", {})

    # injection 키 중 구조에 영향을 주는 파라미터만 override
    _OVERRIDE_KEYS = (
        "lora_r", "lora_alpha", "lora_dropout",
        "target_keywords", "start_layer", "num_layers",
        "attn_lora",
        "num_experts", "top_k",
    )

    overridden = []
    for key in _OVERRIDE_KEYS:
        if key in ckpt_injection:
            old_val = current_injection.get(key)
            new_val = ckpt_injection[key]
            if old_val != new_val:
                overridden.append(f"{key}: {old_val} → {new_val}")
            current_injection[key] = new_val

    cfg["injection"] = current_injection

    if overridden:
        logger.warning(_t("train.pipeline_override", details="\n  ".join(overridden)))


def _load_lora_adapter_weights(model, checkpoint_state_dict: Dict[str, Any]) -> int:
    """체크포인트에서 LoRA 어댑터 가중치만 추출하여 모델에 로드.

    LoRA 키(lora_A, lora_B)만 매칭하여 로드한다.
    base_layer.weight 등은 이미 base 모델에서 로드되었으므로 건너뜀.

    키 prefix가 다를 수 있으므로(예: model.language_model.layers → model.layers)
    자동 매핑을 시도한다.

    Returns:
        로드된 LoRA 파라미터 수
    """
    model_sd = model.state_dict()
    model_lora_keys = {
        k for k in model_sd
        if "lora_A" in k or "lora_B" in k or "loraA" in k or "loraB" in k
    }

    # 1차: 직접 매칭
    lora_sd = {}
    for key, val in checkpoint_state_dict.items():
        if "lora_A" in key or "lora_B" in key or "loraA" in key or "loraB" in key:
            if key in model_lora_keys:
                lora_sd[key] = val

    # 2차: 직접 매칭 실패 시 prefix 자동 매핑 시도
    # 예) "model.language_model.layers.0.mlp.gate_proj.lora_A"
    #   → "model.layers.0.mlp.gate_proj.lora_A"
    if not lora_sd and model_lora_keys:
        ckpt_lora_keys = {
            k for k in checkpoint_state_dict
            if "lora_A" in k or "lora_B" in k or "loraA" in k or "loraB" in k
        }
        if ckpt_lora_keys:
            # 모델과 체크포인트 각각에서 lora 키의 suffix 패턴을 추출하여 prefix 매핑 유추
            # layers.X 이후 부분을 suffix로 사용
            import re
            def _extract_suffix(key: str) -> str:
                m = re.search(r"(layers\.\d+\..+)", key)
                return m.group(1) if m else key

            model_suffix_map = {}
            for k in model_lora_keys:
                suffix = _extract_suffix(k)
                model_suffix_map[suffix] = k

            for ck_key in ckpt_lora_keys:
                suffix = _extract_suffix(ck_key)
                if suffix in model_suffix_map:
                    model_key = model_suffix_map[suffix]
                    lora_sd[model_key] = checkpoint_state_dict[ck_key]

    if not lora_sd:
        return 0

    result = model.load_state_dict(lora_sd, strict=False)
    return len(lora_sd)


def _save_lora_info(cfg: Dict[str, Any], checkpoint_path: str) -> None:
    """체크포인트에 lora_info.json 저장 — LocalHFClient LoRA 병합 호환용."""
    injection = cfg.get("injection", {})
    strategy = str(injection.get("strategy", ""))
    lora_r = injection.get("lora_r", 0)
    lora_alpha = injection.get("lora_alpha", 1.0)
    if lora_r and "lora" in strategy.lower():
        lora_info = {
            "lora_r": int(lora_r),
            "lora_alpha": float(lora_alpha),
            "strategy": strategy,
        }
        with open(os.path.join(checkpoint_path, "lora_info.json"), "w", encoding="utf-8") as f:
            json.dump(lora_info, f)


def _format_time(seconds: float) -> str:
    if seconds <= 0:
        return "NA"
    days, rem = divmod(int(seconds), 86400)
    hours, rem = divmod(rem, 3600)
    minutes, secs = divmod(rem, 60)
    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    parts.append(f"{secs}s")
    return " ".join(parts)


def cfg_get(d: Any, *keys: str, default: Any = None) -> Any:
    """Read-first-key-wins getter for dict without mutating."""
    if not isinstance(d, dict):
        return default
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    return default


def cfg_get_section(cfg: Dict[str, Any], name: str) -> Dict[str, Any]:
    v = cfg.get(name)
    return v if isinstance(v, dict) else {}


def log_resolved_plan(cfg: Dict[str, Any]) -> None:
    inj = cfg.get("injection") if isinstance(cfg.get("injection"), dict) else {}

    attn = inj.get("attn_lora", {})
    logger.info(
        f"Train ResolvedInjection [AttnLoRA] enabled={attn.get('enabled')} keywords={attn.get('keywords')}"
    )


    tr = cfg.get("training") if isinstance(cfg.get("training"), dict) else {}
    lg = cfg.get("logging") if isinstance(cfg.get("logging"), dict) else {}
    ck = cfg.get("checkpoint") if isinstance(cfg.get("checkpoint"), dict) else {}

    # Quantization info log
    logger.info(f"Train ResolvedTraining quant_bits={tr.get('quant_bits', 'None (16)')}")

    logger.info(
        "Train ResolvedInjection strategy=%s startlayer=%s numlayers=%s stride=%s "
        "targetkeywords=%s lorar=%s loraalpha=%s loradropout=%s numexperts=%s topk=%s",
        inj.get("strategy"),
        inj.get("startlayer"),
        inj.get("numlayers"),
        inj.get("stride"),
        inj.get("targetkeywords"),
        inj.get("lorar"),
        inj.get("loraalpha"),
        inj.get("loradropout"),
        inj.get("numexperts"),
        inj.get("topk"),
    )

    logger.info(
        "Train ResolvedTraining phaseschedule=%s phase1steps=%s maxsteps=%s gradaccumsteps=%s "
        "batchsize=%s numworkers=%s valsize=%s lr=%s wd=%s warmup=%s maxgradnorm=%s",
        tr.get("phaseschedule"),
        tr.get("phase1steps"),
        tr.get("maxsteps"),
        tr.get("gradaccumsteps"),
        tr.get("batchsize"),
        tr.get("numworkers"),
        tr.get("valsize"),
        tr.get("lr"),
        tr.get("weightdecay"),
        tr.get("warmupsteps"),
        tr.get("maxgradnorm"),
    )

    logger.info(
        "Train ResolvedIntervals logsteps=%s savesteps=%s valsteps=%s (legacy logging.logsteps=%s, checkpoint.savesteps=%s)",
        tr.get("logsteps"),
        tr.get("savesteps"),
        tr.get("valsteps"),
        lg.get("logsteps"),
        ck.get("savesteps"),
    )


def _print_brief(cfg: Dict[str, Any]) -> None:
    backbone = cfg.get("backbone", None)
    model_name = cfg.get("modelname", None) or cfg.get("model_name", None)
    quant = cfg.get("training", {}).get("quant_bits", None)

    inj = (cfg.get("injection") or {}).get("strategy", None) if isinstance(cfg.get("injection"), dict) else None
    phases = (cfg.get("training") or {}).get("phases", None) if isinstance(cfg.get("training"), dict) else None
    num_phases = len(phases) if isinstance(phases, list) else 0
    print(f"[EulerForge] backbone={backbone} model_name={model_name} quant={quant} injection={inj} phases={num_phases}")


def _count_trainable_params(model: nn.Module) -> Tuple[int, int]:
    # (num_tensors, num_elements)
    tensors = 0
    elems = 0
    for p in model.parameters():
        if p.requires_grad:
            tensors += 1
            elems += p.numel()
    return tensors, elems


def _iter_named_trainable_params(model: nn.Module):
    for n, p in model.named_parameters():
        if p.requires_grad:
            yield n, p


def _debug_check_base_trainable_leak(model: nn.Module, prefix: str, current_phase_int: int = 1) -> None:
    """
    Phase 1/2: 베이스 가중치가 훈련되면 Leak(WARNING).
    Phase 3+: 베이스 가중치가 훈련되어야 정상(OK).
    """
    # "베이스 가중치"로 간주할 대표 키워드
    leak_keywords = (
        "embed_tokens.weight", "embedtokens.weight",
        ".q_proj.weight", ".k_proj.weight", ".v_proj.weight", ".o_proj.weight",
        ".gate_proj.weight", ".up_proj.weight", ".down_proj.weight",
        ".gate_proj.base_layer.weight", ".up_proj.base_layer.weight", ".down_proj.base_layer.weight", # MoE LoRA Base
    )

    hits = []
    for n, p in model.named_parameters():
        if not p.requires_grad:
            continue
        ln = n.lower()
        # LoRA 파라미터나 Router는 제외하고 순수 Base만 체크
        if "lora" in ln or "router" in ln:
            continue
            
        if any(k in ln for k in leak_keywords):
            hits.append(n)

    # 로직 분기: Phase 3 이상이면 Base가 있어야 정상
    if current_phase_int >= 3:
        if len(hits) > 0:
            logger.info(f"{prefix} [BaseCheck] OK (Phase 3 active: {len(hits)} base weights are trainable).")
        else:
            logger.warning(f"{prefix} [BaseCheck] WARNING: Phase 3 is active but NO base weights are trainable!")
    else:
        # Phase 1, 2에서는 Base가 없어야 정상
        if len(hits) == 0:
            logger.info(f"{prefix} [BaseLeakCheck] OK (no base weights are trainable).")
        else:
            sample = hits[:5]
            logger.warning(
                f"{prefix} [BaseLeakCheck] WARNING: base weights trainable count={len(hits)} (Leak?). "
                f"sample={sample}"
            )


def _debug_check_lora_only_expected(model: nn.Module, prefix: str) -> None:
    """
    LoRA-only여야 하는데 LoRA 파라미터가 하나도 trainable이 아닌 경우를 잡는다.
    """
    lora_hits = 0
    router_hits = 0

    for n, p in model.named_parameters():
        if not p.requires_grad:
            continue

        ln = n.lower()

        # LoRA 파라미터 감지
        if ln.endswith(".loraa") or ln.endswith(".lorab") or ln.endswith(".lora_a") or ln.endswith(".lora_b"):
            lora_hits += 1
            continue

        # Router-only phase 감지
        if ".router." in ln and (ln.endswith(".weight") or ln.endswith(".bias")):
            router_hits += 1
            continue

    if lora_hits == 0:
        if router_hits > 0:
            logger.info(
                f"{prefix} [LoRACheck] SKIP (no LoRA params trainable, but router params are trainable: {router_hits})."
            )
        else:
            logger.warning(f"{prefix} [LoRACheck] WARNING: no LoRA params are trainable.")
    else:
        logger.info(f"{prefix} [LoRACheck] OK (trainable LoRA tensors={lora_hits}).")


def _log_trainable_summary(model: nn.Module, prefix: str, dbg: DebugOptions) -> None:
    nt, ne = _count_trainable_params(model)
    logger.info(f"{prefix} Trainable tensors={nt}, params={ne}")
    if dbg.enabled and dbg.dump_trainable_names:
        shown = 0
        for n, p in _iter_named_trainable_params(model):
            logger.info(f"{prefix}   - trainable: {n} shape={tuple(p.shape)} dtype={p.dtype}")
            shown += 1
            if shown >= dbg.max_trainable_names:
                logger.info(f"{prefix}   ... (truncated, max={dbg.max_trainable_names})")
                break


def _build_optimizer_for_trainable(model: nn.Module, lr: float, weight_decay: float) -> torch.optim.Optimizer:
    params = [p for p in model.parameters() if p.requires_grad]
    if len(params) == 0:
        raise RuntimeError("No trainable parameters: all parameters have requires_grad=False.")
    return torch.optim.AdamW(params, lr=lr, weight_decay=weight_decay)


def _convert_to_optimizer_steps(micro_steps: int, grad_accum_steps: int) -> int:
    """micro steps를 optimizer steps로 변환.

    scheduler.step()은 optimizer step마다 호출되므로,
    warmup_steps와 num_training_steps를 optimizer step 단위로 변환해야 한다.
    """
    return max(1, micro_steps // grad_accum_steps)


def _compute_eta(elapsed: float, current_step: int, max_steps: int, resume_step: int = 0) -> float:
    """남은 훈련 시간 추정 (초).

    Resume 시 elapsed는 resume 이후 경과 시간이고,
    steps_done은 resume 이후 진행된 step 수로 계산해야 ETA가 정확하다.
    """
    steps_done = current_step - resume_step
    if steps_done <= 0:
        return 0.0
    remaining = max_steps - current_step
    if remaining <= 0:
        return 0.0
    time_per_step = elapsed / steps_done
    return time_per_step * remaining


def _build_scheduler(optimizer, warmup_steps: int, max_steps: int, current_step: int = 0):
    """LR scheduler 생성. warmup_steps, max_steps는 optimizer step 단위.

    scheduler.step()이 optimizer step마다 호출되므로,
    호출부에서 micro steps를 _convert_to_optimizer_steps()로 변환한 후 전달해야 한다.
    """
    scheduler = get_scheduler(
        "cosine",
        optimizer=optimizer,
        num_warmup_steps=warmup_steps,
        num_training_steps=max_steps,
    )
    # Fast-forward scheduler to maintain LR continuity after optimizer rebuild.
    # Without this, phase transitions restart cosine warmup from step 0,
    # causing an unexpected LR dip (e.g. 2e-5 → 0 → warmup back to 2e-5).
    if current_step > 0:
        scheduler.last_epoch = current_step
        for group, lr_val in zip(optimizer.param_groups, scheduler.get_lr()):
            group["lr"] = lr_val
    return scheduler


_BASE_FFN_KEYWORDS = ("gate_proj", "up_proj", "down_proj", "w1", "w2", "w3")


def _apply_base_ffn_lr_multiplier(
    optimizer: torch.optim.Optimizer,
    model: nn.Module,
    multiplier: float,
    base_lr: float,
) -> None:
    """Apply LR multiplier to base_ffn parameters only.

    Identifies base_ffn params by name keywords and adjusts only the param
    group that contains them.  Non-base_ffn param groups keep the scheduler LR.

    On first call, splits the default (flat) param group into two groups:
    [non_base_ffn, base_ffn] so the multiplier can be targeted precisely.
    """
    # Fast path: multiplier == 1.0 means no adjustment needed
    if abs(multiplier - 1.0) < 1e-9:
        return

    # Build id→name map for base_ffn detection
    base_ffn_ids: set = set()
    for name, param in model.named_parameters():
        if any(kw in name for kw in _BASE_FFN_KEYWORDS) and param.requires_grad:
            base_ffn_ids.add(id(param))

    # Split flat param group into [non_base_ffn, base_ffn] on first call.
    # After split, group 0 = non-base_ffn, group -1 = base_ffn.
    if not getattr(optimizer, "_base_ffn_split_done", False):
        if len(optimizer.param_groups) == 1 and base_ffn_ids:
            pg = optimizer.param_groups[0]
            non_ffn = [p for p in pg["params"] if id(p) not in base_ffn_ids]
            ffn = [p for p in pg["params"] if id(p) in base_ffn_ids]
            if ffn:
                current_lr = pg["lr"]
                pg["params"] = non_ffn
                optimizer.add_param_group({"params": ffn, "lr": current_lr,
                                           "weight_decay": pg.get("weight_decay", 0.01)})
        optimizer._base_ffn_split_done = True  # type: ignore[attr-defined]

    # Apply multiplier only to the base_ffn group (last group after split)
    for pg in optimizer.param_groups:
        pg_ids = {id(p) for p in pg["params"]}
        if pg_ids & base_ffn_ids:
            pg["lr"] = base_lr * multiplier


def _grad_norm(p: torch.Tensor) -> float:
    if p.grad is None:
        return 0.0
    return float(p.grad.data.norm(2).item())


def _log_topk_grad_norms(model: nn.Module, topk: int, prefix: str) -> None:
    items = []
    for n, p in model.named_parameters():
        if p.grad is None:
            continue
        g = float(p.grad.data.norm(2).item())
        if g != g:  # NaN
            g = float("inf")
        items.append((g, n))
    items.sort(reverse=True, key=lambda x: x[0])
    logger.info(f"{prefix} [GradNorm] Top {topk} parameters by grad norm (L2):")
    for g, n in items[:topk]:
        # log10도 같이
        lg = -999.0
        if g > 0 and g != float("inf"):
            lg = float(torch.log10(torch.tensor(g)).item())
        logger.info(f"{prefix}   - {n}: {g:.6e} (log10={lg:.3f})")


def _try_log_moe_perf(model: nn.Module, step: int, log_steps: int) -> None:
    """Log MoEPerf timing/token distribution from MoEFFN modules (if perf enabled)."""
    if step % log_steps != 0:
        return
    from eulerforge.modules.moe import MoEFFN
    for name, m in model.named_modules():
        if not isinstance(m, MoEFFN):
            continue
        perf = getattr(m, "last_perf", None)
        if perf is None:
            continue
        hist = perf.get("expert_token_hist", [])
        etimes = perf.get("expert_times_ms", [])
        logger.info(
            "[MoEPerf] layer=%s | router=%.2fms dispatch=%.2fms experts=%.2fms total=%.2fms | "
            "tokens=%d avg_per_expert=%.1f nonempty=%d/%d hist=%s expert_ms=%s",
            name,
            perf.get("router_ms", 0),
            perf.get("dispatch_ms", 0),
            perf.get("experts_ms", 0),
            perf.get("total_fwd_ms", 0),
            perf.get("total_tokens", 0),
            perf.get("avg_tokens_per_expert", 0),
            perf.get("nonempty_experts", 0),
            perf.get("num_experts", 0),
            hist,
            [f"{t:.2f}" for t in etimes],
        )


def _enable_moe_perf(model: nn.Module, enabled: bool = True) -> int:
    """Enable/disable MoEPerf on all MoEFFN modules. Returns count."""
    from eulerforge.modules.moe import MoEFFN
    count = 0
    for m in model.modules():
        if isinstance(m, MoEFFN):
            m.enable_perf(enabled)
            count += 1
    return count


def _try_log_moe_routing_stats(model: nn.Module, step: int, prefix: str, dbg: DebugOptions) -> None:
    if not dbg.enabled or not getattr(dbg, "moerouting", False):
        return

    logger.info(f"{prefix} MoE Routing stats at step {step}")
    shown = 0

    def _first_attr(obj, names):
        for n in names:
            if hasattr(obj, n):
                v = getattr(obj, n)
                if v is not None:
                    return v
        return None

    def _to_list(x):
        if x is None: return None
        if isinstance(x, torch.Tensor):
            return [float(v) for v in x.detach().float().cpu().view(-1)]
        if isinstance(x, (list, tuple)):
            try: return [float(v) for v in x]
            except Exception: return None
        return None

    def _to_float(x):
        if x is None: return None
        if isinstance(x, (float, int)): return float(x)
        if isinstance(x, torch.Tensor):
            if x.numel() == 1: return float(x.detach().float().cpu().item())
            return None
        return None

    def _to_int(x):
        if x is None: return None
        if isinstance(x, int): return int(x)
        if isinstance(x, torch.Tensor):
            if x.numel() == 1: return int(x.detach().cpu().item())
            return None
        return None

    def _format_vec(xs, fmt="{:.3f}", max_items=16):
        if xs is None: return None
        if len(xs) > max_items:
            head = xs[:max_items]
            return "[" + ", ".join(fmt.format(v) for v in head) + f", ...] (n={len(xs)})"
        return "[" + ", ".join(fmt.format(v) for v in xs) + "]"

    def _format_scalar_or_vec(xs, fmt="{:.3f}"):
        if xs is None: return None
        if len(xs) == 1: return fmt.format(xs[0])
        return "[" + ", ".join(fmt.format(v) for v in xs) + "]"

    def _summarize_int_tensor(x, k=16):
        if x is None: return None
        if isinstance(x, torch.Tensor):
            try:
                flat = x.detach().cpu().view(-1)
                vals = [int(v.item()) for v in flat[:k]]
                return vals, int(flat.numel())
            except Exception: return None
        return None

    def _summarize_float_tensor(x, k=16):
        xs = _to_list(x)
        if xs is None: return None
        if len(xs) > k: return xs[:k], len(xs)
        return xs, len(xs)

    for name, m in model.named_modules():
        token_frac = _first_attr(m, ["lasttokenfrac", "last_token_frac", "token_frac", "last_tokenfrac"])
        gate_prob = _first_attr(m, ["lastgateprob", "last_gate_prob", "gate_prob", "last_gateprob"])
        entropy = _first_attr(m, ["lastentropy", "last_entropy", "entropy", "gate_prob_entropy", "last_gate_prob_entropy"])
        total_tokens = _first_attr(m, ["totaltokens", "total_tokens", "totaltoken", "total_token", "T", "num_tokens"])
        density = _first_attr(m, ["lastdensity", "last_density", "density"])
        importance = _first_attr(m, ["lastimportance", "last_importance", "importance"])
        topk_idx = _first_attr(m, ["last_topk_idx", "topk_idx", "lasttopkidx"])
        topk_w = _first_attr(m, ["last_topk_w", "topk_w", "lasttopkw"])
        gate_logits = _first_attr(m, ["last_gate_logits", "gate_logits", "lastgatelogits"])
        gate_prob_full = _first_attr(m, ["last_gate_prob", "gate_prob_full"])

        if (token_frac is None and gate_prob is None and entropy is None and total_tokens is None and
            density is None and importance is None and topk_idx is None and topk_w is None and
            gate_logits is None and gate_prob_full is None):
            continue

        tf = _to_list(token_frac)
        gp = _to_list(gate_prob)
        dn = _to_list(density)
        im = _to_list(importance)
        ent = _to_float(entropy)
        tt = _to_int(total_tokens)
        tki = _summarize_int_tensor(topk_idx, k=16)
        tkw = _summarize_float_tensor(topk_w, k=16)
        glg = _summarize_float_tensor(gate_logits, k=8)
        gpf = _summarize_float_tensor(gate_prob_full, k=8)

        parts = [f"[MoE] module={name}"]
        if tf is not None: parts.append("token_frac=" + _format_vec(tf, fmt="{:.3f}", max_items=32))
        if gp is not None: parts.append("gate_prob=" + _format_vec(gp, fmt="{:.3f}", max_items=32))
        if ent is not None: parts.append(f"entropy={ent:.3f}")
        if tt is not None: parts.append(f"total_tokens={tt}")
        if dn is not None: parts.append("density=" + _format_scalar_or_vec(dn, fmt="{:.3f}"))
        if im is not None: parts.append("importance=" + _format_vec(im, fmt="{:.3f}", max_items=32))
        if tki is not None: parts.append("topk_idx_head=[" + ", ".join(str(v) for v in tki[0]) + f"] (n={tki[1]})")
        if tkw is not None: parts.append("topk_w_head=[" + ", ".join(f"{v:.3f}" for v in tkw[0]) + f"] (n={tkw[1]})")
        if glg is not None: parts.append("gate_logits_head=[" + ", ".join(f"{v:.3f}" for v in glg[0]) + f"] (n={glg[1]})")
        if gpf is not None and gp is None: parts.append("gate_prob_full_head=[" + ", ".join(f"{v:.3f}" for v in gpf[0]) + f"] (n={gpf[1]})")

        logger.info(f"{prefix} " + " | ".join(parts))
        shown += 1
        if shown >= dbg.maxmodules:
            logger.info(f"{prefix} ... (MoE module log truncated, max_modules={dbg.maxmodules})")
            break


def apply_auxlosscoeff_rules(
    model: nn.Module,
    rules: List[Dict[str, Any]],
    *,
    step: int,
    num_layers: int,
    phase1_steps: int,
) -> None:
    changed = 0
    # ... (implementation omitted for brevity as it was correct) ...
    # This function body seems fine in previous context, reusing logic.
    # Re-implementing briefly to ensure completeness if copied blindly.
    def _step_match(s, spec, p1):
        m = (spec.get("mode") or "all").lower()
        if m == "all": return True
        if m == "phase1": return s < p1
        if m == "phase2": return s >= p1
        if m == "range":
            st = int(spec.get("start", 0))
            ed = spec.get("end", None)
            return st <= s < int(ed) if ed is not None else s >= st
        return False
    
    def _layer_match(l_idx, n_l, spec):
        m = (spec.get("mode") or "all").lower()
        if m == "all": return True
        if l_idx is None: return False
        if m == "indices": return l_idx in [int(x) for x in spec.get("indices", [])]
        if m == "range":
            st = int(spec.get("start", 0))
            ed = spec.get("end", None)
            ed = int(ed) if ed is not None else n_l
            return st <= l_idx < ed
        if m == "last_n":
            n = int(spec.get("n", 0))
            return l_idx >= (n_l - n)
        return False
    
    def _type_match(mod, tnames):
        if not tnames: return True
        return mod.__class__.__name__ in set(tnames)

    for m in model.modules():
        if not hasattr(m, "aux_loss_coeff"): continue
        li = getattr(m, "layer_index", None)
        new_val = None
        for r in rules:
            if not bool(r.get("enabled", True)): continue
            if not _type_match(m, r.get("module_types", [])): continue
            if not _step_match(step, r.get("steps", {}), p1=phase1_steps): continue
            if not _layer_match(li, num_layers, r.get("layer", {})): continue
            new_val = float(r.get("value", 0.0))
        
        if new_val is not None and float(getattr(m, "aux_loss_coeff", 0.0)) != float(new_val):
            m.aux_loss_coeff = float(new_val)
            changed += 1


def _try_log_attention_summary(model: nn.Module, prefix: str, dbg: DebugOptions) -> None:
    if not dbg.enabled or not dbg.attn:
        return
    keywords = ("q_proj", "k_proj", "v_proj", "o_proj", "qproj", "kproj", "vproj", "oproj")
    found = 0
    logger.info(f"{prefix} [DebugAttn] Attention projection summary:")
    for name, m in model.named_modules():
        lname = name.lower()
        if not any(k in lname for k in keywords): continue
        if not hasattr(m, "weight"): continue
        w = getattr(m, "weight", None)
        if not isinstance(w, torch.Tensor): continue
        
        w_det = w.detach()
        w_mean = float(w_det.float().mean().item())
        w_std = float(w_det.float().std().item())
        w_norm = float(w_det.float().norm(2).item())
        g_norm = 0.0
        if w.grad is not None:
            g_norm = float(w.grad.detach().float().norm(2).item())
            
        logger.info(f"{prefix}   - {name}: W(mean={w_mean:.4e}, std={w_std:.4e}, norm={w_norm:.4e}) grad_norm={g_norm:.4e} req_grad={w.requires_grad}")
        found += 1
        if found >= dbg.max_modules:
            logger.info(f"{prefix} ... (attn log truncated)")
            break
    if found == 0:
        logger.info(f"{prefix}   (no attention projection modules matched keywords)")


# -------------------------
# Argparser
# -------------------------

def build_argparser() -> argparse.ArgumentParser:
    from eulerforge.i18n import t

    p = argparse.ArgumentParser(
        description=t("help.train.description"),
    )

    p.add_argument("--preset", type=str, default=None, help=t("help.train.preset"))
    p.add_argument("--set", dest="sets", action="append", default=[], help=t("help.train.set"))

    p.add_argument("--output-dir", type=str, default=None, help=t("help.train.output_dir"))
    p.add_argument("--run-name", type=str, default=None, help=t("help.train.run_name"))

    p.add_argument("--print-config", action="store_true", help=t("help.train.print_config"))
    p.add_argument("--validate-only", action="store_true", help=t("help.train.validate_only"))
    p.add_argument("--preflight", action="store_true", help=t("help.train.preflight"))

    # Metrics
    p.add_argument("--metrics-level", type=str, default=None,
                   choices=["minimal", "advanced"],
                   help=t("help.train.metrics_level"))

    # Debug
    p.add_argument("--debug", action="store_true", help=t("help.train.debug"))
    p.add_argument("--debug-every", type=int, default=50, help=t("help.train.debug_every"))
    p.add_argument("--debug-max-modules", type=int, default=50, help=t("help.train.debug_max_modules"))
    p.add_argument("--debug-topk-grad", type=int, default=20, help=t("help.train.debug_topk_grad"))
    p.add_argument("--debug-attn", action="store_true", help=t("help.train.debug_attn"))
    p.add_argument("--debug-trainable-names", action="store_true", help=t("help.train.debug_trainable_names"))
    return p


def _choose_output_dir(cfg: Dict[str, Any], cli_output_dir: Optional[str], run_name: Optional[str]) -> str:
    """
    Output directory 결정 우선순위:
    1. CLI argument (--output-dir)
    2. Config 'training.output_dir'
    3. Config 'checkpoint.output_dir' (이 부분 추가!)
    4. Default: ./outputs/run_{timestamp}
    """
    if cli_output_dir:
        return cli_output_dir

    # 1순위: training 섹션
    tr = cfg.get("training")
    if isinstance(tr, dict):
        od = tr.get("output_dir")
        if isinstance(od, str) and od.strip():
            return od.strip()
    
    # 2순위: checkpoint 섹션 확인
    ck = cfg.get("checkpoint")
    if isinstance(ck, dict):
        od = ck.get("output_dir")
        if isinstance(od, str) and od.strip():
            return od.strip()

    suffix = run_name.strip() if isinstance(run_name, str) and run_name.strip() else _now_tag()
    return os.path.join("./outputs", f"run_{suffix}")

# -------------------------
# Backbone Adapter 선택
# -------------------------

def _select_backbone_adapter(backbone_name: str) -> BackboneAdapter:
    bn = (backbone_name or "").lower()

    if "qwen" in bn:
        return Qwen3Adapter()
    
    # [추가됨] Llama 지원
    if "llama" in bn:
        return LlamaAdapter()

    # Gemma 4 (gemma4 must come before gemma3 to avoid substring match)
    if "gemma4" in bn or "gemma-4" in bn or "gemma_4" in bn:
        return Gemma4Adapter()

    # Gemma 3 only (gemma / gemma2 not supported)
    if "gemma3" in bn or "gemma-3" in bn or "gemma_3" in bn:
        return Gemma3Adapter()

    if "mixtral" in bn:
        import importlib
        mod = importlib.import_module("eulerforge.adapters.backbones.mixtral")
        candidates = [
            "MixtralBackboneAdapter",
            "MixtralAdapter",
            "MixtralNativeAdapter",
            "MixtralBackbone",
        ]
        for cname in candidates:
            cls = getattr(mod, cname, None)
            if cls is not None:
                return cls()
        for obj in mod.__dict__.values():
            if isinstance(obj, type) and issubclass(obj, BackboneAdapter) and obj is not BackboneAdapter:
                return obj()
        raise ImportError(
            "Could not find a Mixtral BackboneAdapter class in eulerforge.adapters.backbones.mixtral."
        )

    logger.warning(f"Unknown backbone '{backbone_name}', using base BackboneAdapter (generic).")
    return BackboneAdapter()


# -------------------------
# Injection 전략 선택
# -------------------------

def _apply_injection(
    model: nn.Module,
    adapter: BackboneAdapter,
    injection_cfg: Dict[str, Any],
    verbose: bool = True,
) -> Any:
    strategy = injection_cfg.get("strategy", "dense_lora")

    strategy = strategy.lower()

    # 금지: ffn_lora (alias도 금지)
    if strategy == "ffn_lora" or strategy == "ffnlora":
        raise ValueError("Injection strategy 'ffn_lora' is forbidden. Use 'moe_expert_lora' instead.")

    explicit = injection_cfg.get("layer_indices", None)
    start_layer = int(injection_cfg.get("start_layer", 0) or 0)

    num_layers_cfg = injection_cfg.get("num_layers", None)
    try:
        num_layers_int = int(num_layers_cfg) if num_layers_cfg is not None else 0
    except Exception:
        num_layers_int = 0

    if (explicit is None) and (num_layers_int <= 0):
        total_layers = len(list(adapter.find_transformer_layers(model)))
        num_layers_int = max(1, total_layers - start_layer)

    stride = int(injection_cfg.get("stride", 1) or 1)
    
    # Attn LoRA Config
    attn_cfg = injection_cfg.get("attn_lora", {})
    if not isinstance(attn_cfg, dict):
        attn_cfg = {} # enabled: false by default

    if strategy == "dense_lora":
        injector = DenseLoRAInjection()
        return injector.apply(
            model=model,
            adapter=adapter,
            mode=injector.MODE_DENSE_LORA,
            layer_indices=explicit,
            start_layer=start_layer,
            num_layers=num_layers_int,
            stride=stride,
            r=injection_cfg.get("lora_r", 16),
            alpha=injection_cfg.get("lora_alpha", 32.0),
            dropout=injection_cfg.get("lora_dropout", 0.05),
            target_keywords=injection_cfg.get("target_keywords", ("w1", "w2", "gate_proj", "up_proj", "down_proj")),
            num_experts=0,
            top_k=0,
            attn_lora_cfg=attn_cfg,
            verbose=verbose,
        )

    if strategy == "mixture_lora":
        injector = DenseLoRAInjection()
        return injector.apply(
            model=model,
            adapter=adapter,
            mode=injector.MODE_MIXTURE_LORA,
            layer_indices=explicit,
            start_layer=start_layer,
            num_layers=num_layers_int,
            stride=stride,
            r=injection_cfg.get("lora_r", 16),
            alpha=injection_cfg.get("lora_alpha", 32.0),
            dropout=injection_cfg.get("lora_dropout", 0.05),
            target_keywords=injection_cfg.get("target_keywords", ("w1", "w2", "gate_proj", "up_proj", "down_proj")),
            num_experts=injection_cfg.get("num_experts", 4),
            top_k=injection_cfg.get("top_k", 2),
            attn_lora_cfg=attn_cfg,
            verbose=verbose,
        )

    if strategy == "moe_expert_lora":
        injector = DenseMoEExpertLoRAInjection()
        return injector.apply(
            model=model,
            adapter=adapter,
            mode=injector.MODE_MOE_EXPERT_LORA,
            injection_cfg=injection_cfg,  # Pass full config for attn_lora extraction inside
            moe_layer_indices=explicit,
            moe_start_layer=start_layer,
            moe_num_layers=num_layers_int,
            moe_layer_stride=stride,
            num_experts=injection_cfg.get("num_experts", 4),
            top_k=injection_cfg.get("top_k", 2),
            lora_r=injection_cfg.get("lora_r", 16),
            lora_alpha=injection_cfg.get("lora_alpha", 32.0),
            lora_dropout=injection_cfg.get("lora_dropout", 0.05),
            aux_loss_coeff=float(injection_cfg.get("aux_loss_coeff", 0.0)),
            ffn_target_keywords=injection_cfg.get("target_keywords", ("w1", "w2", "gate_proj", "up_proj", "down_proj")),
            attn_lora_cfg=attn_cfg,
            verbose=verbose,
        )

    
    if strategy == "native_moe_expert_lora":
        injector = NativeMoEExpertLoRAInjection()
        return injector.apply_expert_lora(
            model=model,
            adapter=adapter,
            target_layers=explicit,
            r=injection_cfg.get("lora_r", 16),
            alpha=injection_cfg.get("lora_alpha", 32.0),
            dropout=injection_cfg.get("lora_dropout", 0.05),
            ffn_keywords=injection_cfg.get("target_keywords", ("w1", "w2", "gate_proj", "up_proj", "down_proj")),
            # [추가] Attention LoRA 설정을 전달해야 함!
            attn_lora_cfg=attn_cfg,
            verbose=verbose,
        )

    raise ValueError(f"Unknown injection strategy: {strategy}")


# -------------------------
# Phase schedule 선택
# -------------------------

def _select_phase_schedule(
    cfg: Dict[str, Any],
    dequantize_dtype: Optional[torch.dtype] = None,
) -> Optional[UniversalPhaseScheduler]:
    """Build phase schedule from config using the unified builder."""
    sched = build_phase_schedule(cfg, dequantize_dtype=dequantize_dtype)
    if sched is None:
        logger.info("[Train] No phase schedule configured.")
    else:
        logger.info(
            "[Train] PhaseScheduler: %d phases, steps=%s",
            sched.num_phases,
            [p.step for p in sched.phases],
        )
    return sched


# -------------------------
# Validation
# -------------------------

def _run_validation(model: nn.Module, val_loader: DataLoader, device: torch.device, use_amp: bool) -> float:
    was_training = model.training
    model.eval()
    total_loss = 0.0
    total_count = 0

    with torch.no_grad():
        for batch in val_loader:
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["labels"].to(device)

            with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=use_amp):
                outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
                loss = outputs.loss

            bs = input_ids.size(0)
            total_loss += loss.item() * bs
            total_count += bs

    if was_training:
        model.train()
    return total_loss / max(total_count, 1)



# -------------------------
# DPO & Adapter Control Utils
# -------------------------

@contextmanager
def disable_adapter_layers(model: nn.Module):
    """
    모델 내의 모든 AdapterLayerMixin 호환 모듈(LoRA, MixtureLoRA 등)을
    일시적으로 disable(base forward만 수행) 상태로 만듭니다.
    """
    managers = []
    for m in model.modules():
        if isinstance(m, AdapterLayerMixin):
            managers.append(m.disable_adapter())
    
    # 중첩된 컨텍스트 매니저 진입
    try:
        for mgr in managers:
            mgr.__enter__()
        yield
    finally:
        for mgr in managers:
            mgr.__exit__(None, None, None)


@contextmanager
def _use_reference_lora(model: nn.Module, ref_lora_sd: Dict[str, torch.Tensor]):
    """DPO reference forward용: LoRA 가중치를 초기(SFT) 상태로 일시 복원.

    파이프라인 DPO (SFT→DPO)에서 disable_adapter_layers()를 사용하면
    reference = base model이 되어 SFT 효과가 사라진다.
    이 context manager는 LoRA 가중치를 SFT 시점으로 되돌려
    올바른 reference (SFT model)를 제공한다.

    Args:
        model: LoRA가 적용된 모델
        ref_lora_sd: 초기(SFT) LoRA 가중치 snapshot
            {param_name: tensor} 형태
    """
    saved = {}
    params = dict(model.named_parameters())
    for name, ref_val in ref_lora_sd.items():
        if name in params:
            saved[name] = params[name].data.clone()
            params[name].data.copy_(ref_val)
    try:
        yield
    finally:
        for name, orig_val in saved.items():
            if name in params:
                params[name].data.copy_(orig_val)


def get_batch_logps(
    logits: torch.Tensor,
    labels: torch.Tensor,
    average_log_prob: bool = False,
) -> torch.Tensor:
    """
    DPO용 Log Probability 계산 함수.
    logits: (B, L, V)
    labels: (B, L)
    """
    if logits.shape[:-1] != labels.shape:
        raise ValueError("Logits (batch and sequence length dim) and labels must have the same shape.")

    # 마스킹 처리 (padding/prompt 부분은 -100 가정)
    loss_mask = (labels != -100)

    # gather에 -100을 넘기면 index out of bounds이므로, 마스킹 위치는 0으로 대체
    safe_labels = labels.clamp(min=0)

    # per-token log_softmax
    per_token_logps = torch.gather(logits.log_softmax(-1), dim=2, index=safe_labels.unsqueeze(2)).squeeze(2)

    # 마스킹 적용
    per_token_logps = per_token_logps * loss_mask

    # 배치별 합산
    sum_logps = per_token_logps.sum(-1)

    if average_log_prob:
        count = loss_mask.sum(-1).float().clamp(min=1)  # avoid NaN for fully-masked sequences
        return sum_logps / count
    else:
        return sum_logps


def dpo_loss_fn(
    policy_chosen_logps: torch.Tensor,
    policy_rejected_logps: torch.Tensor,
    ref_chosen_logps: torch.Tensor,
    ref_rejected_logps: torch.Tensor,
    beta: float,
    label_smoothing: float = 0.0,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    DPO Loss 계산.
    Returns: (losses, chosen_rewards, rejected_rewards)
    """
    pi_logratios = policy_chosen_logps - policy_rejected_logps
    ref_logratios = ref_chosen_logps - ref_rejected_logps

    logits = pi_logratios - ref_logratios

    # -log(sigmoid(beta * logits))
    losses = -F.logsigmoid(beta * logits) * (1 - label_smoothing) - \
             F.logsigmoid(-beta * logits) * label_smoothing

    with torch.no_grad():
        chosen_rewards = beta * (policy_chosen_logps - ref_chosen_logps).detach()
        rejected_rewards = beta * (policy_rejected_logps - ref_rejected_logps).detach()

    return losses, chosen_rewards, rejected_rewards


# -------------------------
# ORPO Loss
# -------------------------

def orpo_loss_fn(
    chosen_logps: torch.Tensor,
    rejected_logps: torch.Tensor,
    sft_loss: torch.Tensor,
    orpo_lambda: float = 1.0,
) -> Tuple[torch.Tensor, Dict[str, float]]:
    """
    ORPO (Odds Ratio Preference Optimization) Loss.

    Loss = SFT_loss + λ * ORPO_loss
    ORPO_loss = -log(σ(log(odds_chosen / odds_rejected)))

    No reference model needed (unlike DPO).
    """
    # odds = p / (1-p), log_odds = logp - log(1-p)
    # log(1 - exp(logp)) using log1p for numerical stability
    chosen_log_odds = chosen_logps - torch.log1p(-torch.exp(chosen_logps).clamp(max=1.0 - 1e-7))
    rejected_log_odds = rejected_logps - torch.log1p(-torch.exp(rejected_logps).clamp(max=1.0 - 1e-7))

    log_odds_ratio = chosen_log_odds - rejected_log_odds
    orpo_loss = -F.logsigmoid(log_odds_ratio).mean()

    total_loss = sft_loss + orpo_lambda * orpo_loss

    metrics = {
        "sft_loss": sft_loss.item(),
        "orpo_loss": orpo_loss.item(),
        "total_loss": total_loss.item(),
        "log_odds_ratio": log_odds_ratio.mean().item(),
    }
    return total_loss, metrics


# -------------------------
# RM (Reward Model) Components
# -------------------------

class RewardHead(nn.Module):
    """Scalar reward head: last-token hidden → scalar reward."""

    def __init__(self, hidden_size: int):
        super().__init__()
        self.linear = nn.Linear(hidden_size, 1)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> torch.Tensor:
        """
        Extract last real token's hidden state and project to scalar.

        Args:
            hidden_states: (B, L, H) - last layer hidden states
            attention_mask: (B, L) - 1 for real tokens, 0 for padding

        Returns:
            rewards: (B,) - scalar reward per sequence
        """
        # Find last non-padding position per sequence
        seq_lengths = attention_mask.sum(dim=1) - 1  # (B,)
        seq_lengths = seq_lengths.clamp(min=0)
        batch_idx = torch.arange(hidden_states.size(0), device=hidden_states.device)
        last_hidden = hidden_states[batch_idx, seq_lengths]  # (B, H)
        rewards = self.linear(last_hidden).squeeze(-1)  # (B,)
        return rewards


def rm_loss_fn(
    r_chosen: torch.Tensor,
    r_rejected: torch.Tensor,
) -> Tuple[torch.Tensor, Dict[str, float]]:
    """
    Reward Model loss (Bradley-Terry).
    Loss = -log(σ(r_chosen - r_rejected))
    """
    loss = -F.logsigmoid(r_chosen - r_rejected).mean()
    metrics = {
        "rm_loss": loss.item(),
        "reward_chosen": r_chosen.mean().item(),
        "reward_rejected": r_rejected.mean().item(),
        "reward_margin": (r_chosen - r_rejected).mean().item(),
        "accuracy": (r_chosen > r_rejected).float().mean().item(),
    }
    return loss, metrics


# -------------------------
#  DPO Dataset Helper
# -------------------------

# -------------------------
# PPO (RLHF) Components
# -------------------------

def compute_gae(
    rewards: torch.Tensor,
    values: torch.Tensor,
    gamma: float = 0.99,
    lam: float = 0.95,
) -> torch.Tensor:
    """
    Generalized Advantage Estimation (GAE).

    Args:
        rewards: (T,) per-step rewards
        values: (T,) value estimates
        gamma: discount factor
        lam: GAE lambda

    Returns:
        advantages: (T,) GAE advantages
    """
    T = rewards.size(0)
    advantages = torch.zeros_like(rewards)
    gae = 0.0
    for t in reversed(range(T)):
        next_value = values[t + 1] if t + 1 < T else 0.0
        delta = rewards[t] + gamma * next_value - values[t]
        gae = delta + gamma * lam * gae
        advantages[t] = gae
    return advantages


def _right_to_left_pad(
    input_ids: torch.Tensor,
    attention_mask: torch.Tensor,
    pad_token_id: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """right-padded 배치를 left-padded로 변환.

    decoder-only 모델의 generate()는 left-padding을 요구한다.
    각 시퀀스의 실제 토큰을 오른쪽으로 정렬하고, 왼쪽을 padding으로 채운다.

    Args:
        input_ids: (B, L) right-padded input_ids
        attention_mask: (B, L) right-padded attention_mask
        pad_token_id: padding token ID

    Returns:
        (left_padded_input_ids, left_padded_attention_mask) 튜플
    """
    B, L = input_ids.shape
    left_ids = torch.full_like(input_ids, pad_token_id)
    left_mask = torch.zeros_like(attention_mask)

    for i in range(B):
        seq_len = attention_mask[i].sum().item()
        if seq_len > 0:
            left_ids[i, L - seq_len:] = input_ids[i, :seq_len]
            left_mask[i, L - seq_len:] = 1

    return left_ids, left_mask


def _safe_generate_for_ppo(
    policy_model: nn.Module,
    prompt_ids: torch.Tensor,
    prompt_mask: torch.Tensor,
    max_gen_len: int = 64,
    temperature: float = 1.0,
) -> torch.Tensor:
    """PPO용 안전한 generate() 호출.

    1. right-padded → left-padded 변환 (decoder-only 요구사항)
    2. gradient checkpointing 임시 비활성화 (generate와 호환 불가)
    3. generate 완료 후 gradient checkpointing 복원

    Returns:
        generated token IDs (B, prompt_len + gen_len)
    """
    pad_token_id = getattr(policy_model.config, "pad_token_id", None)
    if pad_token_id is None:
        pad_token_id = getattr(policy_model.config, "eos_token_id", 0)

    # left-padding 변환
    left_ids, left_mask = _right_to_left_pad(
        prompt_ids, prompt_mask, pad_token_id=pad_token_id,
    )

    # gradient checkpointing은 generate()와 호환 불가 → 임시 비활성화
    gc_was_enabled = getattr(policy_model, "is_gradient_checkpointing", False)
    if gc_was_enabled:
        policy_model.gradient_checkpointing_disable()

    try:
        with torch.no_grad():
            generated = policy_model.generate(
                input_ids=left_ids,
                attention_mask=left_mask,
                max_new_tokens=max_gen_len,
                temperature=temperature,
                do_sample=True,
                pad_token_id=pad_token_id,
            )
    finally:
        # gradient checkpointing 복원
        if gc_was_enabled:
            policy_model.gradient_checkpointing_enable(
                gradient_checkpointing_kwargs={"use_reentrant": False}
            )

    return generated


def ppo_clipped_loss(
    ratios: torch.Tensor,
    advantages: torch.Tensor,
    clip_range: float = 0.2,
) -> torch.Tensor:
    """
    PPO clipped surrogate objective.

    Returns negative of clipped objective (to minimize via gradient descent).
    """
    surr1 = ratios * advantages
    surr2 = torch.clamp(ratios, 1.0 - clip_range, 1.0 + clip_range) * advantages
    return -torch.min(surr1, surr2).mean()


def run_ppo_iteration(
    batch: Dict[str, torch.Tensor],
    policy_model: nn.Module,
    reward_head: nn.Module,
    device: torch.device,
    use_amp: bool,
    clip_range: float = 0.2,
    kl_coef: float = 0.1,
    max_gen_len: int = 64,
    temperature: float = 1.0,
    ppo_epochs: int = 4,
    ref_lora_sd: Optional[Dict[str, torch.Tensor]] = None,
) -> Tuple[torch.Tensor, Dict[str, float]]:
    """
    Single PPO iteration: generate → score → GAE → clipped update.

    Args:
        batch: dict with 'input_ids', 'attention_mask' (prompts only)
        policy_model: the model being trained
        reward_head: RewardHead for scoring
        device: compute device
        use_amp: whether to use AMP
        clip_range: PPO clip epsilon
        kl_coef: KL penalty coefficient
        max_gen_len: max generation length
        temperature: sampling temperature
        ppo_epochs: number of PPO update epochs per batch

    Returns:
        (loss, metrics) tuple
    """
    prompt_ids = batch["input_ids"].to(device)
    prompt_mask = batch["attention_mask"].to(device)

    # Gemma 3 4B+ token_type_ids (text-only → all zeros)
    extra_kwargs: Dict[str, Any] = {}

    # 1. Generate rollout (left-padding + gradient checkpointing 안전 처리)
    generated = _safe_generate_for_ppo(
        policy_model, prompt_ids, prompt_mask,
        max_gen_len=max_gen_len, temperature=temperature,
    )
    # generated includes prompt + completion (left-padded)
    pad_token_id = getattr(policy_model.config, "pad_token_id", None)
    if pad_token_id is None:
        pad_token_id = getattr(policy_model.config, "eos_token_id", 0)
    _, prompt_mask_gen = _right_to_left_pad(
        prompt_ids, prompt_mask, pad_token_id=pad_token_id,
    )
    gen_mask = torch.ones_like(generated)
    gen_mask[:, :prompt_mask_gen.size(1)] = prompt_mask_gen

    if _needs_token_type_ids(policy_model):
        extra_kwargs["token_type_ids"] = torch.zeros_like(generated)

    # 2. Score with reward model
    with torch.no_grad():
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=use_amp):
            rm_out = policy_model(
                input_ids=generated,
                attention_mask=gen_mask,
                output_hidden_states=True,
                **extra_kwargs,
            )
            rewards = reward_head(rm_out.hidden_states[-1], gen_mask)  # (B,)

    # 3. Compute old log-probs (before update)
    with torch.no_grad():
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=use_amp):
            old_out = policy_model(input_ids=generated, attention_mask=gen_mask, **extra_kwargs)
            old_logits = old_out.logits[:, :-1, :]
            old_targets = generated[:, 1:]
            old_logps = get_batch_logps(old_logits, old_targets)

    # 4. Reference log-probs
    # Pipeline (SFT→PPO): ref_lora_sd → SFT 모델이 KL reference
    # Fresh: disable_adapter → base model이 reference
    ref_ctx = (
        _use_reference_lora(policy_model, ref_lora_sd)
        if ref_lora_sd is not None
        else disable_adapter_layers(policy_model)
    )
    with torch.no_grad():
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=use_amp):
            with ref_ctx:
                ref_out = policy_model(input_ids=generated, attention_mask=gen_mask, **extra_kwargs)
                ref_logits = ref_out.logits[:, :-1, :]
                ref_logps = get_batch_logps(ref_logits, old_targets)

    # 5. KL penalty
    kl = (old_logps - ref_logps).mean()
    adjusted_rewards = rewards - kl_coef * kl

    # 6. Simple value baseline (mean reward)
    values = torch.full_like(adjusted_rewards, adjusted_rewards.mean().item())
    advantages = compute_gae(adjusted_rewards, values, gamma=1.0, lam=1.0)
    advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

    # 7. PPO update epochs
    total_loss = torch.tensor(0.0, device=device, requires_grad=True)
    for _ in range(ppo_epochs):
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=use_amp):
            new_out = policy_model(input_ids=generated, attention_mask=gen_mask, **extra_kwargs)
            new_logits = new_out.logits[:, :-1, :]
            new_logps = get_batch_logps(new_logits, old_targets)

        ratios = torch.exp(new_logps - old_logps.detach())
        epoch_loss = ppo_clipped_loss(ratios, advantages.detach(), clip_range)
        total_loss = total_loss + epoch_loss

    loss = total_loss / ppo_epochs

    metrics = {
        "ppo_loss": loss.item(),
        "reward_mean": rewards.mean().item(),
        "kl": kl.item(),
        "advantages_mean": advantages.mean().item(),
    }
    return loss, metrics


def _build_cache_filename(
    raw_path: str,
    task: str,
    model_name: str,
    max_length: int,
) -> str:
    """사람이 읽을 수 있는 전처리 캐시 파일명을 생성한다.

    형식: ``{input_stem}_{task}_{model_short}_len{max_length}.jsonl``

    Examples:
        - ``dpo_10k_raw_sft_qwen3.5-0.8b-base_len512.jsonl``
        - ``sft_1k_raw_preference_llama-3.2-1b_len256.jsonl``

    동일한 입력(basename, task, model, max_length)이면 항상 같은 파일명을 반환하므로
    캐시 재사용이 가능하다.
    """
    import re

    # 1. 입력 파일 stem (확장자 제거)
    stem = os.path.splitext(os.path.basename(raw_path))[0]

    # 2. 모델 이름 정규화: org/name → name, 소문자, 특수문자 정리
    if not model_name:
        model_short = "unknown"
    else:
        # org/name → name part only
        model_short = model_name.split("/")[-1].lower()
        # 공백 → 하이픈, 괄호/특수문자 제거
        model_short = model_short.replace(" ", "-")
        model_short = re.sub(r"[^a-z0-9.\-]", "", model_short)
        model_short = re.sub(r"-+", "-", model_short).strip("-")
        if not model_short:
            model_short = "unknown"

    return f"{stem}_{task}_{model_short}_len{max_length}.jsonl"


def _resolve_data_path(
    cfg: Dict[str, Any],
    tokenizer,
    training_type: str,
    output_dir: str,
) -> str:
    """Resolve data path: supports ``data`` section and legacy ``processed_data_path``.

    Priority:
    1. ``cfg["data"]`` (new) — format=processed or format=raw
    2. ``cfg["processed_data_path"]`` or ``cfg["training"]["processed_data_path"]`` (legacy)
    """
    data_cfg = cfg.get("data")

    if data_cfg is not None:
        fmt = data_cfg.get("format", "processed")
        path = data_cfg["path"]

        if fmt == "processed":
            return path

        # fmt == "raw"
        task = data_cfg["task"]
        _default_cache = os.path.join("outputs", ".cache")
        cache_dir = data_cfg.get("cache_dir") or _default_cache
        os.makedirs(cache_dir, exist_ok=True)

        model_name = cfg.get("model_name", "")
        # 파이프라인 연속 훈련: 체크포인트 경로면 base 모델 이름으로 해석하여
        # 캐시 키 충돌을 방지한다 (다른 base 모델의 캐시를 재사용하는 버그 차단)
        _ckpt = _detect_eulerforge_checkpoint(model_name)
        if _ckpt is not None:
            model_name = _ckpt["base_model_name"]
        max_len = int(data_cfg.get("max_length", 512))
        cache_filename = _build_cache_filename(path, task, model_name, max_len)
        cache_file = os.path.join(cache_dir, cache_filename)

        if os.path.exists(cache_file):
            logger.info(f"[Data] Using cached preprocessed data: {cache_file}")
            return cache_file

        logger.info(f"[Data] Preprocessing raw data: {path} -> {cache_file}")
        from ..utils.tokenize import preprocess_file

        schema = data_cfg.get("schema") or {}
        _default_num_proc = max(1, (os.cpu_count() or 2) // 2)
        num_proc = int(data_cfg.get("num_proc", _default_num_proc))

        preprocess_file(
            input_path=path,
            output_path=cache_file,
            task=task,
            tokenizer=tokenizer,
            max_length=max_len,
            num_proc=num_proc,
            schema=schema,
        )
        return cache_file

    # Legacy fallback
    path = cfg.get("processed_data_path") or cfg.get("training", {}).get("processed_data_path")
    if not path:
        raise ValueError(
            "processed_data_path is required. Pass --set processed_data_path=... "
            "or add a data: section to your config."
        )
    return path


class ProcessedDPODataset(torch.utils.data.Dataset):
    """
    JSONL 포맷의 DPO 데이터셋.
    각 라인은 chosen_input_ids, rejected_input_ids 등을 포함해야 함.
    """
    def __init__(self, path: str):
        self.data = []
        skipped = 0
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    row = json.loads(line)
                    # Filter rows where response was truncated to empty (all labels = -100)
                    # These cause NaN loss (HuggingFace returns nan when all labels are -100)
                    cl = row.get("chosen_labels", [])
                    rl = row.get("rejected_labels", [])
                    has_chosen = any(x != -100 for x in cl)
                    has_rejected = any(x != -100 for x in rl)
                    if has_chosen and has_rejected:
                        self.data.append(row)
                    else:
                        skipped += 1
        if skipped > 0:
            logger.warning(
                f"[DPODataset] Filtered {skipped} rows with empty labels "
                f"(response truncated to 0 tokens). Kept {len(self.data)} rows."
            )
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        return self.data[idx] # Raw dict 반환 (collate에서 텐서 변환)


def dpo_collate_fn(batch: List[Dict[str, Any]], pad_token_id: int):
    """
    DPO 배치를 구성합니다. Chosen과 Rejected를 하나의 배차로 연결(concat)하여
    효율적인 Forward Pass를 지원합니다.
    """
    # 기본값 처리
    for item in batch:
        if "chosen_attention_mask" not in item:
            item["chosen_attention_mask"] = [1] * len(item["chosen_input_ids"])
        if "rejected_attention_mask" not in item:
            item["rejected_attention_mask"] = [1] * len(item["rejected_input_ids"])
            
    def pad_sequence(seqs, padding_val):
        max_len = max(len(s) for s in seqs)
        out = []
        for s in seqs:
            out.append(s + [padding_val] * (max_len - len(s)))
        return torch.tensor(out, dtype=torch.long)

    # Chosen / Rejected 리스트 추출
    chosen_ids = [x["chosen_input_ids"] for x in batch]
    rejected_ids = [x["rejected_input_ids"] for x in batch]
    chosen_labels = [x["chosen_labels"] for x in batch]
    rejected_labels = [x["rejected_labels"] for x in batch]
    chosen_mask = [x["chosen_attention_mask"] for x in batch]
    rejected_mask = [x["rejected_attention_mask"] for x in batch]
    
    # Concat: [c1, r1, c2, r2, ...] 순서로 쌓음
    combined_ids = []
    combined_labels = []
    combined_mask = []
    
    for i in range(len(batch)):
        combined_ids.extend([chosen_ids[i], rejected_ids[i]])
        combined_labels.extend([chosen_labels[i], rejected_labels[i]])
        combined_mask.extend([chosen_mask[i], rejected_mask[i]])
        
    return {
        "input_ids": pad_sequence(combined_ids, pad_token_id),
        "labels": pad_sequence(combined_labels, -100),
        "attention_mask": pad_sequence(combined_mask, 0)
    }


# -------------------------
# Training Step Logic (SFT/DPO Branching)
# -------------------------

def _needs_token_type_ids(model: nn.Module) -> bool:
    """Gemma3/4 ForConditionalGeneration은 training 시 token_type_ids가 필수."""
    _CONDITIONAL_GENERATION_CLASSES = (
        "Gemma3ForConditionalGeneration",
        "Gemma4ForConditionalGeneration",
    )
    cls_name = type(model).__name__
    if cls_name in _CONDITIONAL_GENERATION_CLASSES:
        return True
    # PEFT wrapper 등을 통해 감싸져 있��� 수 있음
    inner = getattr(model, "base_model", None)
    if inner is not None and type(inner).__name__ in _CONDITIONAL_GENERATION_CLASSES:
        return True
    # model 속성 탐색 (LoRA injection 후에도 class name 유지)
    inner_model = getattr(model, "model", None)
    if inner_model is not None:
        if hasattr(inner_model, "language_model") and hasattr(inner_model, "multi_modal_projector"):
            return True
    return False


def run_training_step(
    batch: Dict[str, torch.Tensor],
    model: nn.Module,
    training_type: str,
    device: torch.device,
    use_amp: bool,
    dpo_beta: float = 0.1,
    orpo_lambda: float = 1.0,
    reward_head: Optional[nn.Module] = None,
    ref_lora_sd: Optional[Dict[str, torch.Tensor]] = None,
) -> Tuple[torch.Tensor, Dict[str, float]]:
    """
    SFT/DPO/ORPO/RM의 Forward/Loss 계산 로직을 분리 처리합니다.
    """
    input_ids = batch["input_ids"].to(device)
    attention_mask = batch["attention_mask"].to(device)
    labels = batch["labels"].to(device)

    # Gemma 3 4B+ (multimodal wrapper)는 training 시 token_type_ids 필수.
    # text-only fine-tuning이므로 모든 토큰이 type 0 (text).
    extra_kwargs: Dict[str, Any] = {}
    if _needs_token_type_ids(model):
        extra_kwargs["token_type_ids"] = torch.zeros_like(input_ids)

    # --- Type A: SFT (Standard CrossEntropy) ---
    if training_type == "sft":
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=use_amp):
            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels, **extra_kwargs)
            loss = outputs.loss
        return loss, {"main_loss": loss.item()}

    # --- Type B: DPO ---
    elif training_type == "dpo":
        # 1. Policy Forward (Chosen + Rejected Concat Batch)
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=use_amp):
            policy_outputs = model(input_ids=input_ids, attention_mask=attention_mask, **extra_kwargs)
            policy_logits = policy_outputs.logits

            # Logits와 Labels를 Shift하여 Log Probability 계산 (Next Token Prediction)
            policy_preds = policy_logits[:, :-1, :]
            targets = labels[:, 1:]

            # DPO sigmoid: sum log probs (TRL 표준, average_log_prob=False)
            # average를 쓰면 gradient가 ~1/seq_len으로 줄어 학습이 안 됨
            # 이전 sum 불안정은 LR scheduler 버그가 원인이었음 (cosine decay 미적용)
            all_logps = get_batch_logps(policy_preds, targets, average_log_prob=False)

            # 짝수 인덱스: Chosen, 홀수 인덱스: Rejected
            policy_chosen_logps = all_logps[0::2]
            policy_rejected_logps = all_logps[1::2]

        # 2. Reference Forward - No Grad
        # Pipeline DPO (SFT→DPO): ref_lora_sd 사용 → SFT 모델이 reference
        # Fresh DPO: ref_lora_sd=None → disable_adapter → base model이 reference
        ref_ctx = (
            _use_reference_lora(model, ref_lora_sd)
            if ref_lora_sd is not None
            else disable_adapter_layers(model)
        )
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=use_amp):
            with torch.no_grad():
                with ref_ctx:
                    ref_outputs = model(input_ids=input_ids, attention_mask=attention_mask, **extra_kwargs)
                    ref_logits = ref_outputs.logits

                    ref_preds = ref_logits[:, :-1, :]
                    ref_all_logps = get_batch_logps(ref_preds, targets, average_log_prob=False)

                    ref_chosen_logps = ref_all_logps[0::2]
                    ref_rejected_logps = ref_all_logps[1::2]

        # 3. DPO Loss Calculation
        losses, chosen_rewards, rejected_rewards = dpo_loss_fn(
            policy_chosen_logps,
            policy_rejected_logps,
            ref_chosen_logps,
            ref_rejected_logps,
            beta=dpo_beta,
        )

        loss = losses.mean()

        metrics = {
            "dpo_loss": loss.item(),
            "reward_chosen": chosen_rewards.mean().item(),
            "reward_rejected": rejected_rewards.mean().item(),
            "reward_margin": (chosen_rewards - rejected_rewards).mean().item(),
            "accuracy": (chosen_rewards > rejected_rewards).float().mean().item(),
        }
        return loss, metrics

    # --- Type C: ORPO (No Reference Model) ---
    elif training_type == "orpo":
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=use_amp):
            # Forward (전체 배치: chosen + rejected interleaved)
            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels, **extra_kwargs)
            logits = outputs.logits

            # SFT loss는 chosen 샘플에만 적용 (ORPO 원논문 준수)
            # rejected를 SFT 목표로 학습하면 나쁜 응답도 생성하도록 학습됨
            preds = logits[:, :-1, :]
            targets = labels[:, 1:]

            # chosen 마스크 (짝수 인덱스)
            chosen_mask = torch.zeros(targets.shape[0], dtype=torch.bool, device=targets.device)
            chosen_mask[0::2] = True

            # chosen만의 per-token cross-entropy
            loss_fct = torch.nn.CrossEntropyLoss(ignore_index=-100, reduction='none')
            per_token_loss = loss_fct(
                preds.reshape(-1, preds.size(-1)),
                targets.reshape(-1),
            ).reshape(targets.shape)

            # chosen 샘플의 평균 loss
            chosen_token_mask = (targets != -100) & chosen_mask.unsqueeze(-1).expand_as(targets)
            sft_loss = per_token_loss[chosen_token_mask].mean() if chosen_token_mask.any() else per_token_loss.mean()

            # Log-probs for chosen/rejected (interleaved)
            # ORPO uses average log-prob per token for numerical stability
            all_logps = get_batch_logps(preds, targets, average_log_prob=True)

            chosen_logps = all_logps[0::2]
            rejected_logps = all_logps[1::2]

        loss, metrics = orpo_loss_fn(chosen_logps, rejected_logps, sft_loss, orpo_lambda)
        return loss, metrics

    # --- Type D: RM (Reward Model) ---
    elif training_type == "rm":
        if reward_head is None:
            raise ValueError("reward_head is required for RM training")

        with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=use_amp):
            outputs = model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                output_hidden_states=True,
                **extra_kwargs,
            )
            hidden_states = outputs.hidden_states[-1]  # last layer
            rewards = reward_head(hidden_states, attention_mask)  # (B,)

            # Interleaved: [chosen_0, rejected_0, chosen_1, rejected_1, ...]
            r_chosen = rewards[0::2]
            r_rejected = rewards[1::2]

        loss, metrics = rm_loss_fn(r_chosen, r_rejected)
        return loss, metrics

    else:
        raise ValueError(f"Unknown training type: {training_type}")


# -------------------------
# [MODIFIED] Training loop
# -------------------------
def run_training(
    model: nn.Module,
    tokenizer,
    train_loader: DataLoader,
    val_loader: Optional[DataLoader],
    optimizer,
    scheduler,
    device: torch.device,
    cfg: Dict[str, Any],
    phase_schedule,
    output_dir: str,
    dbg: DebugOptions,
    adapter: BackboneAdapter,
    reward_head: Optional[nn.Module] = None,
    metrics_jsonl_path: Optional[str] = None,
) -> None:
    tr_cfg = cfg.get("training", {})
    
    #  학습 타입 및 파라미터 로드
    training_type = tr_cfg.get("type", "sft").lower()
    dpo_beta = float(tr_cfg.get("dpo_beta", 0.1))
    orpo_lambda = float(tr_cfg.get("orpo_lambda", 1.0))

    # PPO 파라미터
    ppo_cfg = tr_cfg.get("ppo", {})
    ppo_clip_range = float(ppo_cfg.get("clip_range", 0.2))
    ppo_kl_coef = float(ppo_cfg.get("kl_coef", 0.1))
    ppo_max_gen_len = int(ppo_cfg.get("max_gen_len", 64))
    ppo_temperature = float(ppo_cfg.get("temperature", 1.0))
    ppo_epochs = int(ppo_cfg.get("epochs", 4))

    # ... (기존 Config Parsing 로직 동일) ...
    def _get_int(*keys, default: int) -> int:
        for k in keys:
            v = tr_cfg.get(k, None)
            if v is not None:
                return int(v)
        return int(default)

    legacy_logging = cfg.get("logging", {}) if isinstance(cfg.get("logging", {}), dict) else {}
    def _get_log_steps(default: int = 100) -> int:
        if tr_cfg.get("log_steps", None) is not None:
            return int(tr_cfg["log_steps"])
        if legacy_logging.get("log_steps", None) is not None:
            return int(legacy_logging["log_steps"])
        return int(default)
    def _get_save_steps(default: int = 1000) -> int:
        if tr_cfg.get("save_steps", None) is not None:
            return int(tr_cfg["save_steps"])
        return int(default)

    def _get_val_steps(default: int) -> int:
        if tr_cfg.get("val_steps", None) is not None:
            return int(tr_cfg["val_steps"])
        return int(default)

    max_steps = _get_int("max_steps", "max_train_steps", default=10000)
    grad_accum_steps = _get_int("grad_accum_steps", default=1)
    log_steps = max(1, int(_get_log_steps(default=100)))
    save_steps = max(1, int(_get_save_steps(default=1000)))
    val_steps = max(1, int(_get_val_steps(default=save_steps)))
    grad_accum_steps = max(1, int(grad_accum_steps))
    max_steps = max(1, int(max_steps))

    phase1_aux_weight = float(tr_cfg.get("phase1_aux_weight", 0.05))
    phase2_aux_weight = float(tr_cfg.get("phase2_aux_weight", 0.01))
    phase1_steps = int(tr_cfg.get("phase1_steps", 5000))

    lr = float(tr_cfg.get("lr", 1e-5))
    weight_decay = float(tr_cfg.get("weight_decay", 0.01))
    warmup_steps = int(tr_cfg.get("warmup_steps", 500))

    # scheduler는 optimizer step마다 .step() 호출되므로 optimizer step 단위로 변환
    warmup_optimizer_steps = _convert_to_optimizer_steps(warmup_steps, grad_accum_steps)
    max_optimizer_steps = _convert_to_optimizer_steps(max_steps, grad_accum_steps)

    use_amp = bool(tr_cfg.get("use_amp", True)) and (device.type == "cuda")

    # --- Metrics collector ---
    metrics_level = legacy_logging.get("metrics_level", "minimal")
    tb_cfg = legacy_logging.get("tensorboard", {})
    if not isinstance(tb_cfg, dict):
        tb_cfg = {}
    tb_enabled = bool(tb_cfg.get("enabled", False))
    tb_log_dir = str(tb_cfg.get("log_dir", os.path.join(output_dir, "tb")))
    metrics_log_interval = int(legacy_logging.get("log_interval", log_steps))
    max_experts_log = int(legacy_logging.get("max_experts_log", 16))

    tb_writer = TBWriter(enabled=tb_enabled, log_dir=tb_log_dir)
    collector = MetricsCollector(
        level=metrics_level,
        tb_writer=tb_writer,
        log_interval=metrics_log_interval,
        max_experts_log=max_experts_log,
        jsonl_path=metrics_jsonl_path,
    )
    tokens_seen = 0
    samples_seen = 0

    # [FINALIZE_METRICS] 훈련 루프 종료 시 최소 1건의 metrics 기록을 보장하기 위한 추적 변수.
    # 짧은 훈련(max_train_steps < log_steps, 예: grid search 2 trial × 20 step)에서도
    # metrics.jsonl이 항상 존재하도록 보장 (grid engine이 metric 추출에 의존).
    _last_logged_step = -1
    _last_record_args: Optional[Dict[str, Any]] = None

    try:
        num_layers = len(list(adapter.find_transformer_layers(model)))
    except Exception:
        num_layers = 0

    model.train()
    micro_step = 0
    optimizer_step = 0
    resume_start_step = 0  # resume 시작 micro_step (ETA 계산용)

    data_iter = iter(train_loader)

    # Resume Logic (기존 동일)
    best_val_loss = float("inf")
    latest_ckpt_path = os.path.join(output_dir, "checkpoint-latest", "training_state.pt")
    if os.path.exists(latest_ckpt_path):
        try:
            ckpt_state = torch.load(latest_ckpt_path, map_location="cpu")
            best_val_loss = ckpt_state.get("best_val_loss", float("inf"))
            micro_step = ckpt_state.get("step", 0)
            optimizer_step = ckpt_state.get("optimizer_step", micro_step // grad_accum_steps)
            logger.info(_t("train.resume_found",
                           micro_step=micro_step, optimizer_step=optimizer_step,
                           best_val_loss=f"{best_val_loss:.6f}"))
            # LR scheduler fast-forward: resume 지점의 LR로 즉시 복원
            if optimizer_step > 0:
                scheduler = _build_scheduler(
                    optimizer,
                    warmup_steps=warmup_optimizer_steps,
                    max_steps=max_optimizer_steps,
                    current_step=optimizer_step,
                )
                logger.info(_t("train.resume_lr_restored",
                               optimizer_step=optimizer_step,
                               lr=f"{optimizer.param_groups[0]['lr']:.2e}"))
            resume_start_step = micro_step  # ETA 계산의 기준점
        except Exception as e:
            logger.warning(_t("train.resume_failed", error=str(e)))

    start_time = time.time()  # resume 이후부터 시간 측정

    cfg_batch_size = int(tr_cfg.get("batch_size", 4))
    effective_batch = cfg_batch_size * grad_accum_steps
    total_optimizer_steps = max_steps // grad_accum_steps
    logger.info(_t("train.type_info",
                    type=training_type.upper(), max_steps=max_steps,
                    opt_steps=total_optimizer_steps, accum=grad_accum_steps,
                    batch=cfg_batch_size, effective=effective_batch))
    if training_type == "dpo":
        logger.info(_t("train.dpo_beta", beta=dpo_beta))
        # DPO + router-only phase 경고: LoRA가 freeze되면 policy=reference → reward=0 정상
        phases_cfg = tr_cfg.get("phases", [])
        if phases_cfg and isinstance(phases_cfg[0], dict):
            p0_groups = phases_cfg[0].get("trainable", [])
            if "lora" not in p0_groups and "attn_lora" not in p0_groups:
                logger.info(
                    "[Train] DPO Phase 0 has no LoRA trainable. "
                    "reward_chosen/rejected=0 is expected until LoRA is unfrozen."
                )

    # --- LoRA Handoff Scheduler (optional) ---
    handoff_scheduler = None
    handoff_cfg = tr_cfg.get("lora_handoff")
    if handoff_cfg and isinstance(handoff_cfg, dict):
        from eulerforge.handoff.scheduler import LoraHandoffScheduler
        handoff_scheduler = LoraHandoffScheduler(handoff_cfg)
        logger.info("[Train] LoRA Handoff Scheduler enabled: %s", list(handoff_cfg.keys()))

    # --- Reference LoRA State (pipeline SFT→DPO/PPO 지원) ---
    # Pipeline 훈련에서 LoRA에 SFT 가중치가 로드된 상태.
    # disable_adapter()를 쓰면 ref = base model (SFT 이전)이 되어 잘못됨.
    # 초기 LoRA 상태를 저장하여 reference forward 시 SFT 모델로 사용.
    # DPO: reference log-probs 계산, PPO: KL penalty reference
    _ref_lora_sd: Optional[Dict[str, torch.Tensor]] = None
    if training_type in ("dpo", "ppo"):
        # dense_lora: lora_A/lora_B, mixture_lora: loraA/loraB
        _lora_params = {
            k: v.clone()
            for k, v in model.named_parameters()
            if "lora_A" in k or "lora_B" in k or "loraA" in k or "loraB" in k
        }
        if _lora_params:
            # LoRA 가중치가 0이 아닌지 확인 (SFT 로드됨 = pipeline DPO)
            has_nonzero = any(v.abs().sum() > 0 for v in _lora_params.values())
            if has_nonzero:
                _ref_lora_sd = _lora_params
                logger.info(
                    f"[Train] DPO reference: using initial LoRA state as reference "
                    f"({len(_ref_lora_sd)} params, pipeline mode)"
                )
            else:
                logger.info("[Train] DPO reference: fresh LoRA (disable_adapter mode)")

    while micro_step < max_steps:
        # Phase transition via unified scheduler
        if phase_schedule is not None:
            phase_changed = phase_schedule.maybe_step(model, micro_step)
            if phase_changed:
                phase_info = phase_schedule.get_phase_info()
                phase_idx = phase_info["phase_idx"]
                active_groups = phase_info["current_phase"]["trainable"]
                logger.info(
                    "[Train] Phase transition -> phase %d at step %d, "
                    "active_groups=%s",
                    phase_idx, micro_step, active_groups,
                )
                # Dequantize is now handled inside set_trainable_by_groups()
                # via the dequantize_dtype parameter passed to the phase scheduler.
                optimizer = _build_optimizer_for_trainable(model, lr=lr, weight_decay=weight_decay)
                scheduler = _build_scheduler(optimizer, warmup_steps=warmup_optimizer_steps,
                                             max_steps=max_optimizer_steps, current_step=optimizer_step)
                _log_trainable_summary(
                    model,
                    prefix=f"[Phase{phase_idx}]",
                    dbg=dbg,
                )

        # LoRA Handoff step (scale adjustment + optional freeze)
        if handoff_scheduler is not None:
            handoff_result = handoff_scheduler.step(model, micro_step)
            if handoff_result.needs_optimizer_rebuild:
                optimizer = _build_optimizer_for_trainable(model, lr=lr, weight_decay=weight_decay)
                scheduler = _build_scheduler(optimizer, warmup_steps=warmup_optimizer_steps,
                                             max_steps=max_optimizer_steps, current_step=optimizer_step)
            # Apply base_ffn LR multiplier
            if handoff_result.base_ffn_lr_multiplier != 1.0:
                n_groups_before = len(optimizer.param_groups)
                _apply_base_ffn_lr_multiplier(
                    optimizer, model, handoff_result.base_ffn_lr_multiplier, base_lr=lr
                )
                # _apply_base_ffn_lr_multiplier splits optimizer from 1→2 param_groups
                # on first call. Scheduler must be rebuilt to match the new group count,
                # otherwise scheduler.step() crashes with ValueError (strict zip mismatch).
                if len(optimizer.param_groups) != n_groups_before:
                    scheduler = _build_scheduler(
                        optimizer, warmup_steps=warmup_optimizer_steps,
                        max_steps=max_optimizer_steps, current_step=optimizer_step,
                    )

        # Fetch Batch
        try:
            batch = next(data_iter)
        except StopIteration:
            data_iter = iter(train_loader)
            batch = next(data_iter)

        # Aux loss rule application
        rules = tr_cfg.get("auxlosscoeff_rules", [])
        if isinstance(rules, list) and rules:
            apply_auxlosscoeff_rules(
                model, rules, step=micro_step, num_layers=num_layers, phase1_steps=phase1_steps
            )

        # ------------------
        # [MODIFIED] Forward & Loss
        # ------------------
        if training_type == "ppo":
            main_loss, metrics = run_ppo_iteration(
                batch, model, reward_head, device, use_amp,
                clip_range=ppo_clip_range,
                kl_coef=ppo_kl_coef,
                max_gen_len=ppo_max_gen_len,
                temperature=ppo_temperature,
                ppo_epochs=ppo_epochs,
                ref_lora_sd=_ref_lora_sd,
            )
        else:
            main_loss, metrics = run_training_step(
                batch, model, training_type, device, use_amp,
                dpo_beta=dpo_beta,
                orpo_lambda=orpo_lambda,
                reward_head=reward_head,
                ref_lora_sd=_ref_lora_sd,
            )

        # MoE Aux Loss Handling
        current_phase_idx = phase_schedule.current_phase_idx if phase_schedule else 0
        aux_w = phase1_aux_weight if current_phase_idx == 0 else phase2_aux_weight
        loss, aux_summary = combine_main_and_aux_loss(main_loss, model, aux_weight=aux_w)
        loss = loss / float(grad_accum_steps)

        loss.backward()

        # Optimizer Step
        if (micro_step + 1) % grad_accum_steps == 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=float(tr_cfg.get("max_grad_norm", 1.0)))
            optimizer.step()
            scheduler.step()
            optimizer.zero_grad(set_to_none=True)
            optimizer_step += 1

        micro_step += 1

        # Token / sample counters
        batch_sz = batch["input_ids"].shape[0] if "input_ids" in batch else 0
        if "labels" in batch:
            batch_tokens = int((batch["labels"] != -100).sum().item())
        else:
            batch_tokens = batch["input_ids"].numel() if "input_ids" in batch else 0
        tokens_seen += batch_tokens
        if training_type in ("dpo", "orpo", "rm"):
            samples_seen += batch_sz // 2
        else:
            samples_seen += batch_sz

        # Logging
        phase_tag = f"Phase{current_phase_idx}"
        if micro_step % log_steps == 0:
            elapsed = time.time() - start_time
            eta = _compute_eta(elapsed, micro_step, max_steps, resume_start_step)
            lr_now = optimizer.param_groups[0]["lr"]

            # [MODIFIED] 메트릭 로깅 확장
            log_parts = [
                f"[{phase_tag}] Step {optimizer_step}/{total_optimizer_steps} (micro {micro_step}/{max_steps})",
                f"Loss: {main_loss.item():.4f}",
                f"LR: {lr_now:.2e}",
                f"Tokens: {tokens_seen}",
                f"Samples: {samples_seen}",
                f"ETA: {_format_time(eta)}"
            ]
            for k, v in metrics.items():
                if k != "main_loss":
                    log_parts.append(f"{k}: {v:.4f}")

            if aux_summary.aux_loss is not None:
                log_parts.append(f"aux_loss: {aux_summary.aux_loss.item():.4f}")

            if handoff_scheduler is not None:
                handoff_status = handoff_scheduler.format_status(micro_step)
                if handoff_status:
                    log_parts.append(handoff_status)

            logger.info(" | ".join(log_parts))

            # EULERFORGE_TRAIN_DEBUG=1: per-group LR, grad norms, precision
            if os.environ.get("EULERFORGE_TRAIN_DEBUG", "") == "1":
                for gi, pg in enumerate(optimizer.param_groups):
                    n_params = len(pg["params"])
                    grad_norms = [
                        float(p.grad.data.norm(2).item())
                        for p in pg["params"] if p.grad is not None
                    ]
                    avg_grad = sum(grad_norms) / max(len(grad_norms), 1)
                    dtypes = {str(p.dtype) for p in pg["params"]}
                    logger.debug(
                        "[TrainDebug] group=%d n_params=%d lr=%.2e "
                        "avg_grad=%.4e dtypes=%s",
                        gi, n_params, pg["lr"], avg_grad, dtypes,
                    )

            # MetricsCollector: structured recording + TensorBoard
            _record_args = dict(
                step=micro_step,
                main_loss=main_loss.item(),
                total_loss=loss.item() * float(grad_accum_steps),
                aux_loss=aux_summary.aux_loss.item() if aux_summary.aux_loss is not None else None,
                lr=lr_now,
                metrics=metrics,
                model=model,
                tokens_seen=tokens_seen,
                samples_seen=samples_seen,
                optimizer_step=optimizer_step,
                effective_batch=effective_batch,
            )
            collector.log_step(**_record_args)
            _last_logged_step = micro_step
            _last_record_args = _record_args

            _try_log_moe_routing_stats(model, step=micro_step, prefix=f"[{phase_tag}]", dbg=dbg)
            _try_log_moe_perf(model, step=micro_step, log_steps=log_steps)

        # Debug Logs (기존 동일)
        if dbg.enabled and (micro_step % max(1, dbg.every) == 0):
            prefix = f"[{phase_tag}]"
            _log_trainable_summary(model, prefix=prefix, dbg=dbg)
            # ... (나머지 디버그 함수 호출 동일) ...
            _try_log_moe_routing_stats(model, step=micro_step, prefix=prefix, dbg=dbg)


        # ─── Block 1: Validation (val_steps 주기) ────────────────────────────
        if val_loader is not None and micro_step % val_steps == 0:
            if training_type == "sft":
                current_val_loss = _run_validation(model, val_loader, device, use_amp)
                logger.info(f"[Validation] Step {micro_step} | val_loss={current_val_loss:.6f}")
                if current_val_loss < best_val_loss:
                    old_best = best_val_loss
                    best_val_loss = current_val_loss
                    best_path = os.path.join(output_dir, "checkpoint-best")
                    if os.path.exists(best_path):
                        shutil.rmtree(best_path)
                    _ensure_dir(best_path)
                    model.save_pretrained(best_path, safe_serialization=False)
                    tokenizer.save_pretrained(best_path)
                    _save_lora_info(cfg, best_path)
                    if reward_head is not None:
                        torch.save(reward_head.state_dict(), os.path.join(best_path, "reward_head.pt"))
                    torch.save({
                        'step': micro_step,
                        'optimizer_step': optimizer_step,
                        'optimizer_state_dict': optimizer.state_dict(),
                        'scheduler_state_dict': scheduler.state_dict(),
                        'best_val_loss': best_val_loss,
                    }, os.path.join(best_path, "training_state.pt"))
                    logger.info(
                        f"[Checkpoint] NEW BEST found! Loss {old_best:.6f} -> {best_val_loss:.6f}."
                    )
            else:
                logger.info("[Validation] Skipping validation for non-SFT.")

        # ─── Block 2: Checkpoint (save_steps 주기) ───────────────────────────
        if micro_step % save_steps == 0:
            logger.info(f"[Checkpoint] Triggered at step {micro_step}.")
            latest_path = os.path.join(output_dir, "checkpoint-latest")
            _ensure_dir(latest_path)
            model.save_pretrained(latest_path, safe_serialization=False)
            tokenizer.save_pretrained(latest_path)
            _save_lora_info(cfg, latest_path)
            if reward_head is not None:
                torch.save(reward_head.state_dict(), os.path.join(latest_path, "reward_head.pt"))
            torch.save({
                'step': micro_step,
                'optimizer_step': optimizer_step,
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'best_val_loss': best_val_loss,
            }, os.path.join(latest_path, "training_state.pt"))
            logger.info(f"[Checkpoint] Saved latest to {latest_path}")

    # =========================================================
    # [FINALIZE_METRICS] 훈련 루프 종료 시 metrics.jsonl 보장
    # =========================================================
    # max_train_steps < log_steps인 짧은 훈련(예: grid search 2 trial × 20 step)에서도
    # metrics.jsonl이 항상 존재하도록 마지막 step에서 1건을 추가 기록.
    # grid_engine._extract_metric이 이 파일을 필수로 요구함.
    if metrics_jsonl_path is not None and micro_step > 0 and _last_logged_step != micro_step:
        try:
            if _last_record_args is not None:
                # 마지막으로 기록된 step의 args를 재사용하되 step만 최종값으로 갱신
                _final_args = dict(_last_record_args)
                _final_args["step"] = micro_step
                _final_args["tokens_seen"] = tokens_seen
                _final_args["samples_seen"] = samples_seen
                _final_args["optimizer_step"] = optimizer_step
                collector.log_step(**_final_args)
            else:
                # 한 번도 log_step이 호출되지 않은 경우(짧은 훈련) — 최소 record 직접 기록
                import json as _json
                _final_record = {
                    "step": micro_step,
                    "train/main_loss": float("nan"),
                    "train/total_loss": float("nan"),
                    "train/learning_rate": float(optimizer.param_groups[0]["lr"]) if optimizer is not None else 0.0,
                    "train/tokens_seen": float(tokens_seen),
                    "train/samples_seen": float(samples_seen),
                    "train/optimizer_step": float(optimizer_step),
                    "train/micro_step": float(micro_step),
                    "train/effective_batch": float(effective_batch),
                    "_finalized": True,
                }
                os.makedirs(os.path.dirname(metrics_jsonl_path) or ".", exist_ok=True)
                with open(metrics_jsonl_path, "a", encoding="utf-8") as _f:
                    _f.write(_json.dumps(_final_record) + "\n")
            logger.info(f"[Train] Finalized metrics.jsonl at step={micro_step}")
        except Exception as _e:
            logger.warning(f"[Train] Failed to finalize metrics.jsonl: {_e}")

    # =========================================================
    # [FIX] 훈련 루프 종료 후 최종 모델 저장 로직 추가
    # =========================================================
    logger.info(f"[Train] Training done. Final step={micro_step}")
    
    final_path = os.path.join(output_dir, "final")
    _ensure_dir(final_path)
    logger.info(f"[Train] Saving FINAL model to {final_path}...")

    # LoRA Handoff export processing (remove/merge adapters if configured)
    if handoff_scheduler is not None and handoff_cfg:
        export_cfg = handoff_cfg.get("export", {})
        if isinstance(export_cfg, dict):
            if export_cfg.get("merge_adapters_on_export", False):
                from eulerforge.handoff.scheduler import merge_adapters_into_base
                merged_count = merge_adapters_into_base(model)
                logger.info(f"[Handoff Export] Merged {merged_count} LoRA adapters into base weights.")
            if export_cfg.get("remove_adapters_if_zero_scale", False):
                from eulerforge.handoff.scheduler import remove_zero_scale_adapters
                removed_count = remove_zero_scale_adapters(model)
                logger.info(f"[Handoff Export] Removed {removed_count} zero-scale LoRA adapters.")

    try:
        # 1. Model Weight & Config 저장
        # safe_serialization=False: 커스텀 구조(MoE 등) 호환성을 위해 pickle 사용 유지
        model.save_pretrained(final_path, safe_serialization=False)

        # 2. Tokenizer 저장
        tokenizer.save_pretrained(final_path)
        _save_lora_info(cfg, final_path)

        # 2.5. RewardHead 저장 (RM/PPO)
        if reward_head is not None:
            torch.save(reward_head.state_dict(), os.path.join(final_path, "reward_head.pt"))
            logger.info("[Train] RewardHead saved to final/reward_head.pt")

        # 3. Training State 저장 (Optimizer 등은 선택사항이나, 이어하기를 위해 저장 권장)
        torch.save({
            'step': micro_step,
            'optimizer_step': optimizer_step,
            'optimizer_state_dict': optimizer.state_dict(),
            'scheduler_state_dict': scheduler.state_dict(),
            'best_val_loss': best_val_loss,
        }, os.path.join(final_path, "training_state.pt"))
        
        logger.info("[Train] Final model saved successfully.")
        
    except Exception as e:
        logger.error(f"[Train] Failed to save final model: {e}")
        import traceback
        traceback.print_exc()

    # Close metrics collector (flush TensorBoard)
    collector.close()



def main(argv: Optional[List[str]] = None) -> None:
    # --- 0. CUBLAS workaround for RTX 5090 (Blackwell) ---
    if torch.cuda.is_available():
        torch.backends.cuda.preferred_blas_library("cublaslt")

    # --- 1. Global Exception Hook 설정 ---
    def global_exception_handler(exctype, value, tb):
        if exctype is KeyboardInterrupt:
            sys.stderr.write("\n[Interrupted] KeyboardInterrupt detected. Exiting...\n")
            return
        sys.stderr.write("\n[CRITICAL ERROR] Uncaught exception occurred:\n")
        traceback.print_exception(exctype, value, tb)

    sys.excepthook = global_exception_handler

    # --- 2. Logging 초기화 (Argparse 실패 로그도 잡기 위해 최상단 배치) ---
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        stream=sys.stdout,
        force=True  # 기존 핸들러 덮어쓰기 (중요)
    )
    
    print("[Launcher] Python script execution started.", file=sys.stderr)

    try:
        parser = build_argparser()
        args = parser.parse_args(argv)

        # Debug 모드면 로깅 레벨 DEBUG로 격상
        if args.debug:
            logger.setLevel(logging.DEBUG)
            logging.getLogger().setLevel(logging.DEBUG)
            logger.debug("[Launcher] Debug mode enabled. Logging level set to DEBUG.")

        dbg = DebugOptions(
            enabled=bool(args.debug),
            every=int(args.debug_every),
            max_modules=int(args.debug_max_modules),
            topk_grad=int(args.debug_topk_grad),
            attn=bool(args.debug_attn),
            dump_trainable_names=bool(args.debug_trainable_names),
        )

        # 1) Parse overrides
        overrides: Dict[str, Any] = {}
        if args.sets:
            overrides = parse_kv_overrides(args.sets)

        # 2) Resolve config
        resolved: ResolvedConfig = resolve_config(
            preset_path=args.preset,
            overrides=overrides,
        )
        cfg = resolved.config


        # CLI --metrics-level override → config
        if args.metrics_level is not None:
            if "logging" not in cfg or not isinstance(cfg.get("logging"), dict):
                cfg["logging"] = {}
            cfg["logging"]["metrics_level"] = args.metrics_level

        # Config 사전 검증 (Invalid Config 즉시 차단)
        try:
            validate_config(cfg)
        except ConfigValidationError as e:
            sys.stderr.write(f"\n{e}\n")
            sys.exit(1)

        # 3) Decide output dir
        out_dir = _choose_output_dir(cfg, args.output_dir, args.run_name)
        _ensure_dir(out_dir)

        # always save resolved
        resolved_path = resolved.save_resolved(out_dir, filename="resolved_config.json")

        # config에 output_dir 확정값 반영 + 저장
        if "training" not in cfg or not isinstance(cfg.get("training"), dict):
            cfg["training"] = {}
        cfg["training"]["output_dir"] = out_dir
        with open(resolved_path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)

        _print_brief(cfg)
        print(f"[EulerForge] resolved_config: {resolved_path}")

        if args.print_config:
            print(json.dumps(cfg, ensure_ascii=False, indent=2))

        if args.validate_only:
            print("[EulerForge] validate-only: done.")
            return

        logger.info("[Train] Starting training pipeline...")

        # A) Device
        device_str = cfg.get("device", "cuda" if torch.cuda.is_available() else "cpu")
        device = torch.device(device_str)
        logger.info(f"[Train] Device: {device}")

        # B) BackboneAdapter 선택
        backbone_name = cfg.get("backbone", "generic")
        adapter = _select_backbone_adapter(backbone_name)
        logger.info(f"[Train] BackboneAdapter: {adapter.__class__.__name__}")

        # C) 모델/토크나이저 로드
        model_name = cfg.get("modelname") or cfg.get("model_name") or cfg.get("model") or "gpt2"
        logger.info(f"[Train] Loading model: {model_name}")

        # C-0) EulerForge 체크포인트 탐지 (파이프라인 연속 훈련 지원)
        # SFT→DPO 등에서 model_name이 이전 훈련의 체크포인트를 가리키는 경우,
        # base 모델을 로드하고 LoRA injection 후 어댑터 가중치를 복원한다.
        _ckpt_info = _detect_eulerforge_checkpoint(model_name)
        _ckpt_adapter_sd = None
        if _ckpt_info is not None:
            _base_model = _ckpt_info["base_model_name"]
            logger.info(_t("train.detected_checkpoint",
                           strategy=_ckpt_info['strategy'], base_model=_base_model))
            # 체크포인트의 어댑터 가중치를 미리 읽어둔다
            _adapter_path = os.path.join(
                _ckpt_info["checkpoint_dir"], "model.safetensors"
            )
            if not os.path.isfile(_adapter_path):
                _adapter_path = os.path.join(
                    _ckpt_info["checkpoint_dir"], "pytorch_model.bin"
                )
            if os.path.isfile(_adapter_path):
                if _adapter_path.endswith(".safetensors"):
                    from safetensors.torch import load_file
                    _ckpt_adapter_sd = load_file(_adapter_path)
                else:
                    _ckpt_adapter_sd = torch.load(_adapter_path, map_location="cpu")
                logger.info(_t("train.loaded_adapter_sd", path=_adapter_path, count=len(_ckpt_adapter_sd)))
            # tokenizer는 체크포인트 디렉토리에서 로드 (SFT가 저장한 tokenizer)
            tokenizer = AutoTokenizer.from_pretrained(_ckpt_info["checkpoint_dir"], trust_remote_code=True)
            # 모델은 base에서 로드
            model_name = _base_model
        else:
            tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)

        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token

        # Quantization / Precision Setup (model.load_precision spec)
        from ..utils.load_precision import resolve_load_precision, resolve_compute_dtype

        lp = resolve_load_precision(cfg)
        lp_mode = lp["mode"]

        _DTYPE_MAP = {"fp32": torch.float32, "fp16": torch.float16, "bf16": torch.bfloat16}

        bnb_config = None
        if lp_mode == "int4":
            compute_dt = resolve_compute_dtype(lp["compute_dtype"])
            bnb_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type=lp.get("quant_type", "nf4"),
                bnb_4bit_use_double_quant=lp.get("double_quant", True),
                bnb_4bit_compute_dtype=compute_dt,
            )
            logger.info(
                "[Train] 4-bit quantization enabled (type=%s, double_quant=%s, compute=%s).",
                lp.get("quant_type", "nf4"), lp.get("double_quant", True), lp["compute_dtype"],
            )
        elif lp_mode == "int8":
            bnb_config = BitsAndBytesConfig(load_in_8bit=True)
            logger.info(
                "[Train] 8-bit quantization enabled (compute=%s, dequantize_on_train=%s).",
                lp["compute_dtype"], lp.get("dequantize_on_train", True),
            )
        else:
            torch_dtype = _DTYPE_MAP.get(lp_mode, torch.bfloat16)
            logger.info(f"[Train] Loading model in {lp_mode} precision.")

        # 모델 로드 (base 모델 — 체크포인트 탐지 시 이미 model_name이 base로 교체됨)
        load_dtype = _DTYPE_MAP.get(lp_mode, torch.bfloat16) if bnb_config is None else torch.bfloat16
        model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype=load_dtype,
            trust_remote_code=True,
            quantization_config=bnb_config,
            device_map=device if bnb_config else None,
        )

        # Quantized Training Preparation (peft)
        if bnb_config:
            from peft import prepare_model_for_kbit_training
            model = prepare_model_for_kbit_training(model)
            logger.info("[Train] Model prepared for k-bit training (peft helper applied).")

        # D-0) 파이프라인 연속 훈련: checkpoint의 injection 설정으로 override
        # SFT(lora_r=48) → DPO(lora_r=24) 등에서 LoRA 구조 불일치 방지
        if _ckpt_info is not None:
            _override_injection_from_checkpoint(cfg, _ckpt_info)

        # D) Injection 적용
        injection_cfg = cfg.get("injection", {})
        if not isinstance(injection_cfg, dict):
            injection_cfg = {}
        logger.info(f"[Train] Applying injection strategy: {injection_cfg.get('strategy', 'dense_lora')}")
        inj_result = _apply_injection(model, adapter, injection_cfg, verbose=True)

        logger.info(f"[Train] Injection result: {inj_result}")

        # D-1) 파이프라인 연속 훈련: 이전 체크포인트의 LoRA 어댑터 가중치 복원
        if _ckpt_adapter_sd is not None:
            loaded_count = _load_lora_adapter_weights(model, _ckpt_adapter_sd)
            logger.info(_t("train.loaded_adapter_params", count=loaded_count))
            del _ckpt_adapter_sd  # 메모리 해제

        # [Modified] Quantization 시에는 model.to(device) 호출 불가 (이미 device_map으로 배치됨)
        if bnb_config is None:
            model.to(device)

        # E) Phase schedule 선택/적용 (unified scheduler)
        # injection 결과의 실제 target layer indices를 cfg에 기록하여
        # phase scheduler의 base_ffn 자동 스코핑이 정확하게 동작하도록 한다.
        # (num_layers=0 + start_layer>0 일 때 _derive_injection_layer_indices가
        #  None을 반환하는 문제 방지)
        if hasattr(inj_result, "target_layer_indices") and inj_result.target_layer_indices:
            cfg.setdefault("injection", {})["layer_indices"] = list(inj_result.target_layer_indices)

        # Compute dequantize_dtype for quantized models so phase transitions
        # can auto-cast non-float params before setting requires_grad.
        _deq_dtype = None
        if lp_mode in ("int4", "int8") and lp.get("dequantize_on_train", True):
            _deq_dtype = resolve_compute_dtype(lp.get("compute_dtype", "bf16"))
        phase_schedule = _select_phase_schedule(cfg, dequantize_dtype=_deq_dtype)

        if phase_schedule is not None:
            # Apply initial phase (step 0)
            phase_schedule.maybe_step(model, 0)
            _log_trainable_summary(model, prefix="[Phase0]", dbg=dbg)
            if dbg.enabled:
                _debug_check_lora_only_expected(model, prefix="[Phase0]")
                _debug_check_base_trainable_leak(model, prefix="[Phase0]")
        else:
            logger.info("[Train] No phase schedule.")
            _log_trainable_summary(model, prefix="[Train]", dbg=dbg)

        # E-2) Preflight check (after injection + phase setup)
        if args.preflight:
            logger.info("[Preflight] Running preflight validation...")
            _tr_cfg = cfg.get("training", {})
            phases_cfg = _tr_cfg.get("phases", [])
            target_kwargs = _tr_cfg.get("phase_target_kwargs", {}) or {}
            bfk = target_kwargs.get("base_ffn_keywords")
            tl = target_kwargs.get("target_layers")
            try:
                n_layers = len(list(adapter.find_transformer_layers(model)))
            except Exception:
                n_layers = None
            try:
                report = run_preflight_check(
                    model=model,
                    phases=phases_cfg if isinstance(phases_cfg, list) else [],
                    injection_strategy=injection_cfg.get("strategy", ""),
                    base_ffn_keywords=bfk,
                    target_layers=tl,
                    num_transformer_layers=n_layers,
                )
                logger.info(f"[Preflight] PASSED. Group counts: {report.group_counts}")
            except PreflightError as e:
                logger.error(f"[Preflight] FAILED: {e}")
                sys.exit(1)

            # Run 1-step dummy forward to verify aux loss collection
            logger.info("[Preflight] Running 1-step dummy forward...")
            model.train()
            if hasattr(model.config, "use_cache"):
                model.config.use_cache = False
            dummy_ids = torch.randint(0, 100, (1, 8)).to(device)
            try:
                outputs = model(input_ids=dummy_ids, labels=dummy_ids)
                loss = outputs.loss
                from ..utils.moe_loss import collect_aux_loss
                aux_summary = collect_aux_loss(model, loss_device=loss.device, loss_dtype=loss.dtype)
                logger.info(f"[Preflight] Forward OK. main_loss={loss.item():.4f}, "
                      f"aux_modules={aux_summary.num_modules}, "
                      f"aux_loss={'None' if aux_summary.aux_loss is None else f'{aux_summary.aux_loss.item():.6f}'}")
            except Exception as e:
                logger.error(f"[Preflight] Dummy forward FAILED: {e}")
                sys.exit(1)

            logger.info("[Preflight] All checks passed. Exiting without training.")
            return

        # F) 데이터셋/DataLoader
        tr_cfg = cfg.get("training", {})
        training_type = tr_cfg.get("type", "sft").lower()

        # Resolve data path (supports data section, raw→processed, and legacy)
        try:
            processed_data_path = _resolve_data_path(cfg, tokenizer, training_type, out_dir)
        except (ValueError, ConfigValidationError) as e:
            sys.stderr.write(f"\n{e}\n")
            sys.exit(1)

        # Runtime data validation: check JSONL rows for required keys
        try:
            from ..utils.data_validator import validate_processed_data
            validate_processed_data(processed_data_path, training_type)
        except ConfigValidationError as e:
            sys.stderr.write(f"\n{e}\n")
            sys.exit(1)

        if training_type in ("dpo", "orpo", "rm"):
            logger.info(f"[Data] Loading {training_type.upper()} dataset (DPO format) from {processed_data_path}")
            dataset = ProcessedDPODataset(processed_data_path)
            collate_fn = lambda b: dpo_collate_fn(b, tokenizer.pad_token_id)
        elif training_type == "ppo":
            logger.info(f"[Data] Loading PPO prompt dataset from {processed_data_path}")
            dataset = ProcessedPromptDataset(processed_data_path)
            collate_fn = make_collate_fn(pad_token_id=tokenizer.pad_token_id)
        else:
            logger.info(f"[Data] Loading SFT dataset from {processed_data_path}")
            dataset = ProcessedSFTDataset(processed_data_path)
            collate_fn = make_collate_fn(pad_token_id=tokenizer.pad_token_id)

        val_size = min(int(cfg.get("training", {}).get("val_size", 1000)), len(dataset))
        train_size = len(dataset) - val_size
        if train_size <= 0:
            raise ValueError(f"Dataset size ({len(dataset)}) too small: train={train_size}, val={val_size}")

        train_dataset, val_dataset = torch.utils.data.random_split(
            dataset,
            [train_size, val_size],
            generator=torch.Generator().manual_seed(42),
        )

        batch_size = int(cfg.get("training", {}).get("batch_size", 1))
        num_workers = int(cfg.get("training", {}).get("num_workers", 2))

        train_loader = DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers,
            collate_fn=collate_fn,
        )
        val_loader = DataLoader(
            val_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            collate_fn=collate_fn,
        )

        # G) Optimizer/Scheduler
        lr = float(tr_cfg.get("lr", 1e-5))
        weight_decay = float(tr_cfg.get("weight_decay", 0.01))

        # RM/PPO: create RewardHead and add to optimizer
        reward_head_module = None
        if training_type in ("rm", "ppo"):
            cfg_obj = model.config
            hidden_size = getattr(cfg_obj, "hidden_size", None)
            if hidden_size is None:
                hidden_size = getattr(getattr(cfg_obj, "text_config", None), "hidden_size", 4096)

            # PPO: reward_model 설정에 따라 별도 모델 로드 또는 policy 모델 공유
            rm_cfg = tr_cfg.get("reward_model", {})
            rm_checkpoint = rm_cfg.get("checkpoint_path", "")
            if training_type == "ppo" and rm_checkpoint:
                # 학습된 RM 체크포인트에서 RewardHead 로드
                reward_head_module = RewardHead(hidden_size).to(device)
                rm_state = {}
                rm_ckpt_dir = Path(rm_checkpoint)
                if rm_ckpt_dir.is_dir():
                    rm_state_path = rm_ckpt_dir / "reward_head.pt"
                    if rm_state_path.exists():
                        rm_state = torch.load(rm_state_path, map_location=device, weights_only=True)
                        try:
                            reward_head_module.load_state_dict(rm_state)
                            logger.info(f"[Train] Loaded RewardHead from {rm_state_path}")
                        except RuntimeError as e:
                            if "size mismatch" in str(e):
                                logger.warning(
                                    f"[Train] RewardHead size mismatch (RM hidden_size != policy hidden_size): {e}. "
                                    f"Using random init instead."
                                )
                            else:
                                raise
                    else:
                        logger.warning(f"[Train] No reward_head.pt in {rm_ckpt_dir}, using random init")
                else:
                    logger.warning(f"[Train] RM checkpoint_path '{rm_checkpoint}' not found, using random init")
            else:
                reward_head_module = RewardHead(hidden_size).to(device)

            logger.info(f"[Train] Created RewardHead (hidden_size={hidden_size})")

        # 정석: 최초에도 trainable 기준으로 optimizer 생성(phase_schedule 적용 이후!)
        optimizer = _build_optimizer_for_trainable(model, lr=lr, weight_decay=weight_decay)

        # Add reward_head parameters to optimizer
        if reward_head_module is not None:
            optimizer.add_param_group({"params": list(reward_head_module.parameters())})

        max_steps = int(tr_cfg.get("max_steps") or tr_cfg.get("max_train_steps") or 10000)
        warmup_steps = int(tr_cfg.get("warmup_steps", 500))
        grad_accum_steps = max(1, int(tr_cfg.get("grad_accum_steps", 1)))
        # scheduler는 optimizer step 단위로 동작 → micro steps를 변환
        _warmup_opt = _convert_to_optimizer_steps(warmup_steps, grad_accum_steps)
        _max_opt = _convert_to_optimizer_steps(max_steps, grad_accum_steps)
        # NOTE: run_training 내부에서 resume 시 optimizer_step으로 fast-forward함
        scheduler = _build_scheduler(optimizer, warmup_steps=_warmup_opt, max_steps=_max_opt)

        # G-2) MoE perf profiling (env EULERFORGE_MOE_PERF=1)
        _moe_perf = os.environ.get("EULERFORGE_MOE_PERF", "0") == "1"
        if _moe_perf:
            n_perf = _enable_moe_perf(model, True)
            logger.info("[MoEPerf] Enabled on %d MoEFFN modules.", n_perf)

        # H) 학습 루프 실행
        run_training(
            model=model,
            tokenizer=tokenizer,
            train_loader=train_loader,
            val_loader=val_loader,
            optimizer=optimizer,
            scheduler=scheduler,
            device=device,
            cfg=cfg,
            phase_schedule=phase_schedule,
            output_dir=out_dir,
            dbg=dbg,
            adapter=adapter,
            reward_head=reward_head_module,
            metrics_jsonl_path=os.path.join(out_dir, "metrics.jsonl"),
        )

        logger.info("[Train] Training pipeline complete.")

    except SystemExit as e:
        if e.code != 0:
            logging.error(f"[FATAL] SystemExit: code={e.code}")
        raise

    except Exception:
        # main() 내부에서 발생한 모든 예외를 잡아서 출력
        sys.stderr.write("\n[FATAL] Unhandled exception in main():\n")
        traceback.print_exc()
        sys.exit(1)
        
if __name__ == "__main__":
    main()