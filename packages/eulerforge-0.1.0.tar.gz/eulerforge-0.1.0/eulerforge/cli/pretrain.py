# eulerforge/cli/pretrain.py
# -*- coding: utf-8 -*-
"""
eulerforge pretrain — scratch pretraining for assembled models.

EulerStack 등 외부 도구가 HuggingFace 형식으로 export한 모델을
raw text 데이터로 스크래치 사전훈련한다.

기존 train 명령어(LoRA/MoE 인젝션 + 페이즈 스케줄)와 완전히 분리된
전체 파라미터 causal LM 훈련 파이프라인.

Usage:
    eulerforge pretrain --preset configs/presets/pretrain/eulerstack_hybrid_moe.yml
    eulerforge pretrain --preset ... --set training.max_steps=1000
    eulerforge pretrain --preset ... --validate-only
"""
from __future__ import annotations

import argparse
import gc
import json
import logging
import os
import sys
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 설정 로드 + 검증
# ---------------------------------------------------------------------------

_FORBIDDEN_KEYS = {"injection", "moe", "backbone"}

_REQUIRED_KEYS = {"model_dir", "data", "training"}


def _load_preset(path: str) -> Dict[str, Any]:
    """pretrain YAML 프리셋을 로드한다."""
    import yaml

    if not os.path.isfile(path):
        sys.stderr.write(
            f"\nPretrain Config: preset file not found: {path}\n"
            f"Fix: Check the --preset path\n"
            f"See: docs/cli.md\n"
        )
        sys.exit(1)

    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    return cfg


def _apply_overrides(cfg: Dict[str, Any], overrides: List[str]) -> Dict[str, Any]:
    """--set key=value 오버라이드를 적용한다."""
    for kv in overrides:
        if "=" not in kv:
            continue
        key, val = kv.split("=", 1)
        # dot-path 지원: training.lr=3e-4
        parts = key.split(".")
        target = cfg
        for p in parts[:-1]:
            if p not in target or not isinstance(target[p], dict):
                target[p] = {}
            target = target[p]
        # 타입 추론
        try:
            target[parts[-1]] = json.loads(val)
        except (json.JSONDecodeError, ValueError):
            target[parts[-1]] = val
    return cfg


def validate_pretrain_config(cfg: Dict[str, Any]) -> None:
    """pretrain 설정을 검증한다. 위반 시 에러."""
    errors = []

    # 필수 키 검증
    for key in _REQUIRED_KEYS:
        if key not in cfg:
            errors.append(f"필수 키 '{key}' 누락")

    # 금지 키 검증 (injection/moe/backbone은 pretrain에서 사용 불가)
    for key in _FORBIDDEN_KEYS:
        if key in cfg:
            errors.append(
                f"'{key}' 키는 pretrain에서 사용할 수 없습니다. "
                f"pretrain은 전체 파라미터 훈련이며, LoRA/MoE 인젝션은 "
                f"'eulerforge train'을 사용하세요."
            )

    # model_dir 존재 확인
    model_dir = cfg.get("model_dir", "")
    if model_dir and not os.path.isdir(model_dir):
        errors.append(f"model_dir가 존재하지 않습니다: {model_dir}")

    # data 섹션 검증
    data = cfg.get("data", {})
    if isinstance(data, dict):
        if "path" not in data:
            errors.append("data.path 필수")
        elif data["path"] and not os.path.isfile(data["path"]):
            # 상대 경로일 수 있으므로 경고만
            pass
        if "text_column" not in data:
            errors.append("data.text_column 필수")

    # training 섹션 검증
    tr = cfg.get("training", {})
    if isinstance(tr, dict):
        if "max_steps" not in tr:
            errors.append("training.max_steps 필수")

    if errors:
        msg = "\n".join(f"  - {e}" for e in errors)
        sys.stderr.write(
            f"\nPretrain Config: validation failed\n"
            f"Fix: {errors[0]}\n"
            f"See: docs/cli.md\n"
            f"\n상세:\n{msg}\n"
        )
        sys.exit(1)


# ---------------------------------------------------------------------------
# 데이터 로드 (packed chunking)
# ---------------------------------------------------------------------------

def _load_packed_dataset(
    data_path: str,
    text_column: str,
    tokenizer,
    max_length: int,
    packing: bool = True,
) -> "torch.utils.data.Dataset":
    """raw text JSONL → packed token chunks 데이터셋."""
    import torch

    # JSONL 로드
    texts = []
    with open(data_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            text = row.get(text_column, "")
            if text:
                texts.append(text)

    if not texts:
        sys.stderr.write(
            f"\nPretrain Data: no text found in {data_path} (column='{text_column}')\n"
            f"Fix: Check data.path and data.text_column\n"
            f"See: docs/cli.md\n"
        )
        sys.exit(1)

    logger.info(f"[Pretrain] Loaded {len(texts)} texts from {data_path}")

    if packing:
        # Packed chunking: 모든 텍스트를 연결 → max_length 단위로 분할
        all_ids = []
        for text in texts:
            ids = tokenizer.encode(text, add_special_tokens=False)
            if tokenizer.eos_token_id is not None:
                ids.append(tokenizer.eos_token_id)
            all_ids.extend(ids)

        # 고정 길이 청크로 분할 (나머지 버림)
        chunks = []
        for i in range(0, len(all_ids) - max_length, max_length):
            chunk = all_ids[i:i + max_length]
            chunks.append(chunk)

        logger.info(
            f"[Pretrain] Packed: {len(all_ids)} tokens → {len(chunks)} chunks "
            f"(max_length={max_length})"
        )
    else:
        # 개별 텍스트 토큰화 (패딩/잘림)
        chunks = []
        for text in texts:
            ids = tokenizer.encode(text, max_length=max_length, truncation=True)
            if len(ids) < max_length:
                ids = ids + [tokenizer.pad_token_id or 0] * (max_length - len(ids))
            chunks.append(ids[:max_length])

    class PretrainDataset(torch.utils.data.Dataset):
        def __init__(self, token_chunks):
            self.chunks = token_chunks

        def __len__(self):
            return len(self.chunks)

        def __getitem__(self, idx):
            ids = torch.tensor(self.chunks[idx], dtype=torch.long)
            return {"input_ids": ids, "labels": ids.clone()}

    return PretrainDataset(chunks)


# ---------------------------------------------------------------------------
# 훈련 루프
# ---------------------------------------------------------------------------

def run_pretrain(cfg: Dict[str, Any], output_dir: str) -> None:
    """pretrain 훈련 루프 실행."""
    import torch
    from torch.utils.data import DataLoader
    from eulerforge.i18n import t

    # CUBLAS 워크어라운드 (RTX 5090)
    if torch.cuda.is_available():
        torch.backends.cuda.preferred_blas_library("cublaslt")

    tr = cfg["training"]
    data_cfg = cfg["data"]

    # 시드 고정
    seed = int(tr.get("seed", 42))
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    # 디바이스 (YAML에서 지정 가능: device: cuda:0, cuda:1, cpu)
    device_str = cfg.get("device", "cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(device_str)
    logger.info(f"[Pretrain] Device: {device}")

    # 모델 로드
    model_dir = cfg["model_dir"]
    trust_remote_code = cfg.get("trust_remote_code", False)
    logger.info(f"[Pretrain] Loading model from {model_dir}")

    from transformers import AutoModelForCausalLM, AutoTokenizer, AutoConfig

    model_config = AutoConfig.from_pretrained(
        model_dir, trust_remote_code=trust_remote_code,
    )

    # 훈련 dtype
    train_dtype_str = tr.get("dtype", "bfloat16")
    train_dtype = getattr(torch, train_dtype_str, torch.bfloat16)

    model = AutoModelForCausalLM.from_pretrained(
        model_dir,
        torch_dtype=train_dtype,
        trust_remote_code=trust_remote_code,
    )
    model = model.to(device)
    model.train()

    n_params = sum(p.numel() for p in model.parameters())
    n_trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    logger.info(
        f"[Pretrain] Model loaded: {n_params:,} params, "
        f"{n_trainable:,} trainable, dtype={train_dtype}"
    )

    # 토크나이저
    tokenizer_name = cfg.get("tokenizer") or model_dir
    tokenizer = AutoTokenizer.from_pretrained(
        tokenizer_name, trust_remote_code=trust_remote_code,
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    logger.info(f"[Pretrain] Tokenizer: {tokenizer_name} (vocab={tokenizer.vocab_size})")

    # vocab_size 불일치 처리: 토크나이저 > 모델이면 embedding resize
    model_vocab = getattr(model_config, "vocab_size", None)
    tok_vocab = tokenizer.vocab_size
    if model_vocab and tok_vocab > model_vocab:
        logger.warning(
            f"[Pretrain] Tokenizer vocab ({tok_vocab}) > model vocab ({model_vocab}). "
            f"Resizing model embeddings to {tok_vocab}."
        )
        model.resize_token_embeddings(tok_vocab)
        n_params = sum(p.numel() for p in model.parameters())
        logger.info(f"[Pretrain] After resize: {n_params:,} params")
    elif model_vocab and tok_vocab < model_vocab:
        logger.info(
            f"[Pretrain] Tokenizer vocab ({tok_vocab}) < model vocab ({model_vocab}). "
            f"No resize needed (unused embeddings ignored)."
        )

    # 데이터
    data_path = data_cfg["path"]
    if not os.path.isabs(data_path):
        data_path = os.path.join(os.getcwd(), data_path)
    text_column = data_cfg.get("text_column", "text")
    max_length = int(data_cfg.get("max_length", 2048))
    packing = data_cfg.get("packing", True)

    dataset = _load_packed_dataset(data_path, text_column, tokenizer, max_length, packing)

    batch_size = int(tr.get("batch_size", 2))
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, drop_last=True)

    # 옵티마이저
    lr = float(tr.get("lr", 3e-4))
    weight_decay = float(tr.get("weight_decay", 0.1))
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)

    # LR 스케줄러 (linear warmup + cosine decay)
    max_steps = int(tr["max_steps"])
    warmup_steps = int(tr.get("warmup_steps", 0))

    def lr_lambda(step):
        if step < warmup_steps:
            return float(step) / float(max(1, warmup_steps))
        progress = float(step - warmup_steps) / float(max(1, max_steps - warmup_steps))
        import math
        return max(0.0, 0.5 * (1.0 + math.cos(math.pi * progress)))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)

    # AMP — training.amp로 명시적 제어 (기본: dtype이 bf16/fp16이면 자동 활성)
    # FFT 등 bf16 미지원 연산이 있는 모델(Hyena 등)은 amp: false 권장
    amp_setting = tr.get("amp")
    if amp_setting is not None:
        use_amp = bool(amp_setting) and (device.type == "cuda")
    else:
        use_amp = (device.type == "cuda") and (train_dtype in (torch.bfloat16, torch.float16))

    if use_amp:
        logger.info(f"[Pretrain] AMP enabled (dtype={train_dtype})")
    else:
        logger.info(f"[Pretrain] AMP disabled (dtype={train_dtype})")

    scaler = torch.amp.GradScaler("cuda", enabled=(use_amp and train_dtype == torch.float16))

    # 훈련 파라미터
    grad_accum_steps = int(tr.get("grad_accum_steps", 1))
    max_grad_norm = float(tr.get("max_grad_norm", 1.0))
    log_steps = int(tr.get("log_steps", 10))
    save_steps = int(tr.get("save_steps", 500))

    # 출력 디렉토리
    os.makedirs(output_dir, exist_ok=True)
    # 설정 스냅샷 저장
    with open(os.path.join(output_dir, "pretrain_config.json"), "w") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    logger.info(f"[Pretrain] Output dir: {output_dir}")

    # 메트릭 JSONL
    metrics_path = os.path.join(output_dir, "metrics.jsonl")
    metrics_f = open(metrics_path, "w", encoding="utf-8")

    # ── 훈련 루프 ──
    logger.info(
        f"[Pretrain] Starting training: max_steps={max_steps}, "
        f"batch_size={batch_size}, grad_accum={grad_accum_steps}, "
        f"lr={lr}, warmup={warmup_steps}"
    )

    global_step = 0
    accum_loss = 0.0
    accum_count = 0
    start_time = time.time()
    data_iter = iter(dataloader)

    model.zero_grad()

    while global_step < max_steps:
        # 데이터 배치 가져오기 (epoch 순환)
        try:
            batch = next(data_iter)
        except StopIteration:
            data_iter = iter(dataloader)
            batch = next(data_iter)

        input_ids = batch["input_ids"].to(device).contiguous()
        labels = batch["labels"].to(device).contiguous()

        # position_ids 명시 생성 (일부 커스텀 모델이 non-contiguous 텐서를 .view() 하려 하면 에러)
        seq_len = input_ids.shape[1]
        position_ids = torch.arange(seq_len, device=device, dtype=torch.long).unsqueeze(0).expand_as(input_ids).contiguous()

        # Forward
        with torch.amp.autocast("cuda", dtype=train_dtype, enabled=use_amp):
            outputs = model(input_ids=input_ids, labels=labels, position_ids=position_ids)
            loss = outputs.loss / grad_accum_steps

        # Backward
        if use_amp and train_dtype == torch.float16:
            scaler.scale(loss).backward()
        else:
            loss.backward()

        accum_loss += loss.item() * grad_accum_steps
        accum_count += 1

        # Optimizer step (gradient accumulation)
        if accum_count % grad_accum_steps == 0:
            if use_amp and train_dtype == torch.float16:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
                scaler.step(optimizer)
                scaler.update()
            else:
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
                optimizer.step()

            scheduler.step()
            model.zero_grad()
            global_step += 1

            # 로깅
            if global_step % log_steps == 0:
                avg_loss = accum_loss / accum_count
                elapsed = time.time() - start_time
                steps_per_sec = global_step / elapsed if elapsed > 0 else 0
                current_lr = scheduler.get_last_lr()[0]
                logger.info(
                    f"[Pretrain] step={global_step}/{max_steps} | "
                    f"loss={avg_loss:.4f} | lr={current_lr:.2e} | "
                    f"{steps_per_sec:.2f} steps/s"
                )
                # 메트릭 기록
                record = {
                    "step": global_step,
                    "loss": round(avg_loss, 6),
                    "lr": current_lr,
                    "elapsed_sec": round(elapsed, 1),
                }
                metrics_f.write(json.dumps(record) + "\n")
                metrics_f.flush()
                accum_loss = 0.0
                accum_count = 0

            # 체크포인트 저장
            if global_step % save_steps == 0:
                ckpt_dir = os.path.join(output_dir, f"checkpoint-{global_step}")
                os.makedirs(ckpt_dir, exist_ok=True)
                model.save_pretrained(ckpt_dir)
                tokenizer.save_pretrained(ckpt_dir)
                logger.info(f"[Pretrain] Checkpoint saved: {ckpt_dir}")

    # ── 최종 저장 ──
    final_dir = os.path.join(output_dir, "final")
    os.makedirs(final_dir, exist_ok=True)
    model.save_pretrained(final_dir)
    tokenizer.save_pretrained(final_dir)
    metrics_f.close()

    total_time = time.time() - start_time
    logger.info(
        f"[Pretrain] Training complete. {global_step} steps in {total_time:.1f}s. "
        f"Final model saved to {final_dir}"
    )

    # GPU 정리
    del model, optimizer, scheduler
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_argparser() -> argparse.ArgumentParser:
    from eulerforge.i18n import t

    p = argparse.ArgumentParser(
        prog="eulerforge pretrain",
        description=t("help.pretrain.description"),
    )
    p.add_argument("--preset", required=True, help=t("help.pretrain.preset"))
    p.add_argument("--set", dest="sets", action="append", default=[],
                   help=t("help.pretrain.set"))
    p.add_argument("--output-dir", default=None, help=t("help.pretrain.output_dir"))
    p.add_argument("--validate-only", action="store_true",
                   help=t("help.pretrain.validate_only"))
    return p


def main(argv: Optional[List[str]] = None) -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )

    parser = build_argparser()
    args = parser.parse_args(argv)

    # 설정 로드
    cfg = _load_preset(args.preset)

    # 오버라이드 적용
    if args.sets:
        cfg = _apply_overrides(cfg, args.sets)

    # 출력 디렉토리
    if args.output_dir:
        cfg["output_dir"] = args.output_dir
    if "output_dir" not in cfg:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        cfg["output_dir"] = os.path.join("outputs", f"pretrain_{ts}")

    # 검증
    validate_pretrain_config(cfg)

    if args.validate_only:
        print("[Pretrain] Config validation passed.")
        print(f"[Pretrain] model_dir: {cfg.get('model_dir')}")
        print(f"[Pretrain] data.path: {cfg.get('data', {}).get('path')}")
        print(f"[Pretrain] training.max_steps: {cfg.get('training', {}).get('max_steps')}")
        return

    # 훈련 실행
    try:
        run_pretrain(cfg, cfg["output_dir"])
    except Exception:
        sys.stderr.write("\n[FATAL] Unhandled exception in pretrain:\n")
        import traceback
        traceback.print_exc()
        sys.exit(1)
