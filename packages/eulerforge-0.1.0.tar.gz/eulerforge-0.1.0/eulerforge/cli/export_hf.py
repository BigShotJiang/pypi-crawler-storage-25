# eulerforge/cli/export_hf.py
# -*- coding: utf-8 -*-
"""
eulerforge export-hf — HuggingFace 모델 내보내기 CLI.
"""
from __future__ import annotations

import argparse
import sys
from argparse import BooleanOptionalAction
from typing import List, Optional


def build_argparser() -> argparse.ArgumentParser:
    """CLI 인자 파서 생성."""
    from eulerforge.i18n import t

    parser = argparse.ArgumentParser(
        prog="eulerforge export-hf",
        description=t("help.export.description"),
    )
    parser.add_argument(
        "--checkpoint", required=True,
        help=t("help.export.checkpoint"),
    )
    parser.add_argument(
        "--output", required=True,
        help=t("help.export.output"),
    )
    parser.add_argument(
        "--format", default="auto",
        choices=["auto", "merged", "custom_moe"],
        help=t("help.export.format"),
    )
    parser.add_argument(
        "--select-checkpoint", default="final",
        choices=["final", "best", "latest"],
        help=t("help.export.select_checkpoint"),
    )
    parser.add_argument(
        "--dtype", default="auto",
        choices=["auto", "fp32", "fp16", "bf16"],
        help=t("help.export.dtype"),
    )
    parser.add_argument(
        "--safe-serialization",
        action=BooleanOptionalAction, default=True,
        help=t("help.export.safe_serialization"),
    )
    parser.add_argument(
        "--copy-tokenizer",
        action=BooleanOptionalAction, default=True,
        help=t("help.export.copy_tokenizer"),
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help=t("help.export.dry_run"),
    )
    parser.add_argument(
        "--validate-only", action="store_true",
        help=t("help.export.validate_only"),
    )
    parser.add_argument(
        "--skip-diversity-check", action="store_true",
        help=t("help.export.skip_diversity"),
    )
    return parser


def main(argv: Optional[List[str]] = None) -> None:
    """export-hf CLI 진입점."""
    parser = build_argparser()
    args = parser.parse_args(argv)

    from eulerforge.export.planner import plan_export

    try:
        plan = plan_export(
            checkpoint=args.checkpoint,
            output=args.output,
            format=args.format,
            select_checkpoint=args.select_checkpoint,
            dtype=args.dtype,
            safe_serialization=args.safe_serialization,
            copy_tokenizer=args.copy_tokenizer,
        )
        plan.skip_diversity_check = args.skip_diversity_check
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

    # dry-run: 계획만 출력
    if args.dry_run:
        print("[dry-run] Export plan:")
        print(f"  strategy:    {plan.strategy}")
        print(f"  format:      {plan.format}")
        print(f"  checkpoint:  {plan.checkpoint_dir}")
        print(f"  output:      {plan.output_dir}")
        print(f"  dtype:       {plan.dtype}")
        print(f"  backbone:    {plan.backbone}")
        return

    # validate-only: 검증만 수행
    if args.validate_only:
        print("[validate] Export plan is valid:")
        print(f"  strategy:    {plan.strategy}")
        print(f"  format:      {plan.format}")
        print(f"  checkpoint:  {plan.checkpoint_dir}")
        return

    # 실제 export
    if plan.format == "merged":
        from eulerforge.export.merged import export_merged

        result = export_merged(plan)
    elif plan.format == "custom_moe":
        from eulerforge.export.custom_moe import export_custom_moe

        result = export_custom_moe(plan)
    else:
        print(f"Unknown format: {plan.format}", file=sys.stderr)
        sys.exit(1)

    print(f"[Done] Exported to {result.output_dir}")
    print(f"  format:   {result.format}")
    print(f"  strategy: {result.strategy}")
    print(f"  files:    {result.num_files}")
