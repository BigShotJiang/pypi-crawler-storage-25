# eulerforge/cli/grid_search.py
# -*- coding: utf-8 -*-
"""
eulerforge grid — 하이퍼파라미터 서치 CLI.

지원: grid / random / bayes (Optuna 기반).
YAML spec 형식: docs/fixtures/specs/grid_search_spec.md 참조.
"""
from __future__ import annotations

import os
import sys
import argparse
from typing import List, Optional


def main(argv: Optional[List[str]] = None) -> None:
    from eulerforge.i18n import t

    parser = argparse.ArgumentParser(
        description=t("help.grid.description"),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  eulerforge grid configs/grid/sft_random_search.yml --dry-run\n"
            "  eulerforge grid configs/grid/sft_random_search.yml\n\n"
            "spec format: docs/fixtures/specs/grid_search_spec.md"
        ),
    )
    parser.add_argument("spec", help=t("help.grid.spec"))
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help=t("help.grid.dry_run"),
    )
    parser.add_argument(
        "--project-root",
        default=None,
        metavar="DIR",
        help=t("help.grid.project_root"),
    )

    args = parser.parse_args(argv)

    # --- spec 로드 & 검증 ---
    from eulerforge.utils.grid_validator import (
        load_and_validate_grid_spec,
        GridSpecValidationError,
    )
    try:
        spec = load_and_validate_grid_spec(args.spec)
    except FileNotFoundError as e:
        print(
            f"Grid Search Config: spec 파일을 찾을 수 없습니다: {e}\n"
            f"Fix: 파일 경로를 확인하세요\n"
            f"See: docs/fixtures/specs/grid_search_spec.md",
            file=sys.stderr,
        )
        sys.exit(1)
    except GridSpecValidationError as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

    if args.dry_run:
        print("[Grid] Spec validation passed.")
        sys.exit(0)

    # --- optuna 의존성 확인 ---
    try:
        import optuna  # noqa: F401
    except ImportError:
        print(
            "Grid Search Config: optuna가 설치되어 있지 않습니다\n"
            "Fix: pip install eulerforge[hpo]\n"
            "See: docs/tutorials/12_grid_search.md",
            file=sys.stderr,
        )
        sys.exit(1)

    # --- 실행 ---
    from eulerforge.utils.grid_engine import run_grid_search

    project_root = args.project_root or os.getcwd()

    try:
        summary = run_grid_search(spec, project_root)
    except Exception as e:
        print(
            f"Grid Search Error: {e}\n"
            f"Fix: 로그를 확인하고 spec 및 base_preset 설정을 점검하세요\n"
            f"See: docs/tutorials/12_grid_search.md",
            file=sys.stderr,
        )
        sys.exit(1)

    best = summary.get("best_trial", {})
    print(
        f"[Grid] Done. Best trial: #{best.get('number', '?')} "
        f"value={best.get('value', float('nan')):.6f} "
        f"params={best.get('params', {})}"
    )
