# eulerforge/cli/main.py
# -*- coding: utf-8 -*-
"""
Unified CLI entrypoint for EulerForge.

Core 명령은 하드코딩되고, plugin 명령은 동적으로 발견된다.
Plugin 모듈이 없으면 해당 명령은 help/실행 모두에서 자연스럽게 사라진다.

Usage:
    eulerforge [--lang LANG] train [OPTIONS]
    eulerforge [--lang LANG] bench [OPTIONS]
    eulerforge [--lang LANG] pretrain [OPTIONS]  # plugin이 설치된 경우
"""
from __future__ import annotations

import sys
from typing import Callable, Dict, List, Optional, Tuple

from eulerforge.i18n import t


# Core 명령 — 항상 사용 가능 (plugin 시스템과 무관)
_CORE_COMMANDS: List[Tuple[str, str]] = [
    ("train", "help.cmd.train"),
    ("convert", "help.cmd.convert"),
    ("preprocess", "help.cmd.preprocess"),
    ("bench", "help.cmd.bench"),
    ("eval", "help.cmd.eval"),
    ("grid", "help.cmd.grid"),
    ("export-hf", "help.cmd.export_hf"),
]

# Core 명령 dispatch table
_CORE_DISPATCH: Dict[str, Callable] = {
    "train": lambda argv: __import__("eulerforge.cli.train", fromlist=["main"]).main(argv=argv),
    "convert": lambda argv: __import__("eulerforge.cli.convert", fromlist=["main"]).main(argv=argv),
    "preprocess": lambda argv: __import__("eulerforge.cli.preprocess", fromlist=["main"]).main(argv=argv),
    "bench": lambda argv: __import__("eulerforge.cli.bench", fromlist=["main"]).main(argv=argv),
    "eval": lambda argv: __import__("eulerforge.cli.eval_ppl", fromlist=["main"]).main(argv=argv),
    "grid": lambda argv: __import__("eulerforge.cli.grid_search", fromlist=["main"]).main(argv=argv),
    "export-hf": lambda argv: __import__("eulerforge.cli.export_hf", fromlist=["main"]).main(argv=argv),
}


def _get_all_commands() -> List[Tuple[str, str]]:
    """Core 명령 + 발견된 plugin 명령을 합쳐 반환."""
    commands = list(_CORE_COMMANDS)
    try:
        from eulerforge.plugins import discover_plugins
        for plugin in discover_plugins():
            commands.append((plugin.command, plugin.help_key))
    except ImportError:
        pass
    return commands


def _get_plugin_dispatch() -> Dict[str, Callable]:
    """Plugin 명령의 dispatch table을 반환."""
    dispatch: Dict[str, Callable] = {}
    try:
        from eulerforge.plugins import discover_plugins
        for plugin in discover_plugins():
            dispatch[plugin.command] = plugin.main_fn
    except ImportError:
        pass
    return dispatch


def _print_help() -> None:
    print(f"{t('help.usage')}\n")
    print(f"{t('help.description')}\n")
    print(f"{t('help.global_options')}")
    print(f"  {'--lang LANG':<12} {t('help.lang_option')}")
    print(f"\n{t('help.commands_header')}")
    for cmd, msg_key in _get_all_commands():
        print(f"  {cmd:<12} {t(msg_key)}")
    print(f"\n{t('help.run_command_help')}")


def main(argv: Optional[List[str]] = None) -> None:
    args = argv if argv is not None else sys.argv[1:]

    # --lang 옵션 처리 (글로벌, 모든 서브커맨드에 적용)
    if len(args) >= 2 and args[0] == "--lang":
        from eulerforge.i18n import set_lang
        set_lang(args[1])
        args = args[2:]

    if not args or args[0] in ("-h", "--help"):
        _print_help()
        sys.exit(0)

    command = args[0]
    sub_argv = args[1:]

    # Core 명령 dispatch
    if command in _CORE_DISPATCH:
        _CORE_DISPATCH[command](sub_argv)
        return

    # Plugin 명령 dispatch
    plugin_dispatch = _get_plugin_dispatch()
    if command in plugin_dispatch:
        plugin_dispatch[command](sub_argv)
        return

    # Unknown command
    print(t("cli.unknown_command", command=command), file=sys.stderr)
    print(t("cli.run_help"), file=sys.stderr)
    sys.exit(1)


if __name__ == "__main__":
    main()
