# eulerforge/cli/preprocess.py
# -*- coding: utf-8 -*-
"""
eulerforge preprocess — offline data preprocessing.

Converts raw JSONL to tokenized processed JSONL.

Usage:
    eulerforge preprocess --task sft --input raw.jsonl --output processed.jsonl --model-name Qwen/Qwen3.5-0.8B-Base
"""
from __future__ import annotations

import argparse
import os
import sys
import logging
from typing import List, Optional

from ..utils.tokenize import VALID_TASKS

logger = logging.getLogger(__name__)


def build_argparser() -> argparse.ArgumentParser:
    from eulerforge.i18n import t

    p = argparse.ArgumentParser(
        prog="eulerforge preprocess",
        description=t("help.preprocess.description"),
    )
    p.add_argument("--task", required=True, choices=VALID_TASKS,
                   help=t("help.preprocess.task"))
    p.add_argument("--input", required=True, help=t("help.preprocess.input"))
    p.add_argument("--output", required=True, help=t("help.preprocess.output"))
    p.add_argument("--model-name", required=True,
                   help=t("help.preprocess.model_name"))
    p.add_argument("--max-length", type=int, default=512,
                   help=t("help.preprocess.max_length"))
    _default_num_proc = max(1, (os.cpu_count() or 2) // 2)
    p.add_argument("--num-proc", type=int, default=_default_num_proc,
                   help=t("help.preprocess.num_proc"))
    # Column mapping
    p.add_argument("--text-col", default="text",
                   help="Column for text (SFT text mode, default: text)")
    p.add_argument("--prompt-col", default="prompt",
                   help="Column for prompt (default: prompt)")
    p.add_argument("--response-col", default="response",
                   help="Column for response (default: response)")
    p.add_argument("--chosen-col", default="chosen",
                   help="Column for chosen (default: chosen)")
    p.add_argument("--rejected-col", default="rejected",
                   help="Column for rejected (default: rejected)")
    return p


def main(argv: Optional[List[str]] = None) -> None:
    parser = build_argparser()
    args = parser.parse_args(argv)

    # Validate input file exists
    if not os.path.isfile(args.input):
        sys.stderr.write(
            f"\nData: input file not found: {args.input}\n"
            f"Fix: Check the --input path\n"
            f"See: docs/tutorials/00_data_preprocessing.md\n"
        )
        sys.exit(1)

    # Load tokenizer
    from transformers import AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(args.model_name, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    schema = {
        "text_col": args.text_col,
        "prompt_col": args.prompt_col,
        "response_col": args.response_col,
        "chosen_col": args.chosen_col,
        "rejected_col": args.rejected_col,
    }

    from ..utils.tokenize import preprocess_file

    try:
        n = preprocess_file(
            input_path=args.input,
            output_path=args.output,
            task=args.task,
            tokenizer=tokenizer,
            max_length=args.max_length,
            num_proc=args.num_proc,
            schema=schema,
        )
        print(f"[Preprocess] Done. Wrote {n} rows to {args.output}")
    except Exception as e:
        sys.stderr.write(f"\n{e}\n")
        sys.exit(1)
