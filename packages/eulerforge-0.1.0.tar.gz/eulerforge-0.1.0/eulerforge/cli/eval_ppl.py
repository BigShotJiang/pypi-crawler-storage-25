# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse
from typing import List, Optional

def main(argv: Optional[List[str]] = None):
    from eulerforge.i18n import t

    parser = argparse.ArgumentParser(description=t("help.eval.description"))
    parser.parse_args(argv)
    print(t("help.eval.stub_message"))
