VERSION = (2026, 3, 28, 0)

__version__ = ".".join(map(str, VERSION))
