# Veyl

A quiet, minimal layer over Django admin.

Currently under active development.