# Changelog

## [1.4.0](https://github.com/OscillateLabsLLC/kiwix-mcp/compare/v1.3.0...v1.4.0) (2026-04-24)


### Features

* dynamic tool descriptions + CLI/env overrides (from [#8](https://github.com/OscillateLabsLLC/kiwix-mcp/issues/8)) ([f7b75fe](https://github.com/OscillateLabsLLC/kiwix-mcp/commit/f7b75fed3e8cb5c5d5a72140f5fc3d4f7c30c5ee))
* dynamic tool descriptions + CLI/env overrides (from issue [#8](https://github.com/OscillateLabsLLC/kiwix-mcp/issues/8)) ([f8e2e0c](https://github.com/OscillateLabsLLC/kiwix-mcp/commit/f8e2e0c29890715f696487b14c2341cfbbf8c35f))


### Bug Fixes

* raise ValueError on any 400 from /search ([#8](https://github.com/OscillateLabsLLC/kiwix-mcp/issues/8)) ([eb2ae0d](https://github.com/OscillateLabsLLC/kiwix-mcp/commit/eb2ae0dc58e5817842da386841e2601cfb6ea438))
* raise ValueError on any 400 from /search, not just "confusion-of-tongues" ([#8](https://github.com/OscillateLabsLLC/kiwix-mcp/issues/8)) ([ad1f97b](https://github.com/OscillateLabsLLC/kiwix-mcp/commit/ad1f97b9cc35fccdaa4357faab232d6a93bd327c))

## [1.3.0](https://github.com/OscillateLabsLLC/kiwix-mcp/compare/v1.2.1...v1.3.0) (2026-03-18)


### Features

* add CORS support for browser-based MCP clients ([197a0ea](https://github.com/OscillateLabsLLC/kiwix-mcp/commit/197a0eae51914f7cee8d99bf0e85ffc6b462cad9))

## [1.2.1](https://github.com/OscillateLabsLLC/kiwix-mcp/compare/v1.2.0...v1.2.1) (2026-03-17)


### Documentation

* add CONTRIBUTING.md with just/hatchling dev setup ([b88f656](https://github.com/OscillateLabsLLC/kiwix-mcp/commit/b88f6561c9936c22940bd4ca36bfb1f941d10f25))

## [1.2.0](https://github.com/OscillateLabsLLC/kiwix-mcp/compare/v1.1.0...v1.2.0) (2026-03-08)


### Features

* Docker setup ([13d8992](https://github.com/OscillateLabsLLC/kiwix-mcp/commit/13d8992aa172f059d939c2fdad79ec3a08e69a40))

## [1.1.0](https://github.com/OscillateLabsLLC/kiwix-mcp/compare/v1.0.0...v1.1.0) (2026-03-08)


### Features

* add dockerfile ([e304d42](https://github.com/OscillateLabsLLC/kiwix-mcp/commit/e304d4299afdded5b2ba89dc2889e8195d6bb308))
