import json
import os
import shutil
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional


_SECURITY_MODE_ALIASES = {
    "0": "open",
    "1": "standard",
    "2": "sandboxed",
    "3": "secured",
    "4": "encrypted",
    "locked": "encrypted",
    "secure": "secured",
}


def normalize_security_mode(mode: Optional[str], default: str = "sandboxed") -> str:
    """Normalize security mode strings/aliases to canonical runtime names."""
    if mode is None:
        return default
    normalized = str(mode).strip().lower()
    if not normalized:
        return default
    normalized = _SECURITY_MODE_ALIASES.get(normalized, normalized)
    valid_modes = {"open", "standard", "sandboxed", "secured", "encrypted"}
    return normalized if normalized in valid_modes else default

def resolve_config_path(path: Optional[str] = None) -> Path:
    """Resolve the active config path.

    Priority:
    1. Explicit path argument
    2. ANTARISBOT_CONFIG env var
    3. ANTARIS_CONFIG_DIR env var
    4. Default (~/.antaris/config.json)
    """
    if path:
        return Path(path).expanduser().resolve()

    env_path = os.environ.get("ANTARISBOT_CONFIG")
    if env_path:
        return Path(env_path).expanduser().resolve()

    env_dir = os.environ.get("ANTARIS_CONFIG_DIR")
    if env_dir:
        return (Path(env_dir).expanduser().resolve() / "config.json")

    return Path.home() / ".antaris" / "config.json"

DEFAULT_CONFIG_PATH = resolve_config_path()
DEFAULT_CONFIG_DIR = DEFAULT_CONFIG_PATH.parent


def resolve_auth_profiles_path(path: Optional[str] = None) -> Path:
    """Resolve active auth-profiles path.

    Priority:
    1. Explicit path argument
    2. ANTARIS_AUTH_PROFILES env var
    3. Config dir / auth-profiles.json (if exists)
    4. OpenClaw main agent auth-profiles.json (if exists)
    5. Default ~/.antaris/auth-profiles.json
    """
    if path:
        return Path(path).expanduser().resolve()

    env_path = os.environ.get("ANTARIS_AUTH_PROFILES")
    if env_path:
        return Path(env_path).expanduser().resolve()

    cfg = resolve_config_path()
    candidate = cfg.parent / 'auth-profiles.json'
    if candidate.exists():
        return candidate

    openclaw = Path.home() / '.openclaw' / 'agents' / 'main' / 'agent' / 'auth-profiles.json'
    if openclaw.exists():
        return openclaw

    return Path.home() / '.antaris' / 'auth-profiles.json'


def load_auth_profiles(path: Optional[str] = None) -> dict:
    auth_path = resolve_auth_profiles_path(path)
    if not auth_path.exists():
        return {}
    try:
        with open(auth_path) as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def resolve_provider_credential(provider_name: str, auth_profiles_path: Optional[str] = None) -> tuple[str, str] | tuple[None, None]:
    """Resolve provider credential from auth-profiles.json.

    Returns (credential, profile_id) or (None, None).
    Supports anthropic token profiles, openai/openai-codex oauth access tokens,
    and falls back to the ``order`` list when ``lastGood`` has no entry.
    Maps openai-codex -> openai runtime provider name.
    """
    data = load_auth_profiles(auth_profiles_path)
    profiles = data.get("profiles", {}) if isinstance(data.get("profiles", {}), dict) else {}
    last_good = data.get("lastGood", {}) if isinstance(data.get("lastGood", {}), dict) else {}

    candidates = [provider_name]
    if provider_name == "openai":
        candidates.append("openai-codex")

    for pname in candidates:
        profile_id = last_good.get(pname)
        # Fallback: use first entry in order list when lastGood has no entry
        if not profile_id:
            order = data.get("order", {})
            if isinstance(order, dict):
                order_list = order.get(pname, [])
                if order_list:
                    profile_id = order_list[0]
        if not profile_id or profile_id not in profiles:
            continue
        prof = profiles[profile_id]
        if not isinstance(prof, dict):
            continue
        cred = prof.get("token") or prof.get("apiKey") or prof.get("access")
        if isinstance(cred, str) and len(cred) > 20:
            return cred, profile_id
    return None, None


def load_auth_profile_credential(provider_name: str, auth_profiles_path: Optional[str] = None) -> tuple[str, str] | tuple[None, None]:
    """Load credential from auth-profiles.json for a provider.

    Returns (runtime_provider_name, token) or (None, None).
    Maps openai-codex -> openai runtime provider.

    This is a thin wrapper around :func:`resolve_provider_credential` that
    returns (runtime_provider_name, token) instead of (token, profile_id).
    """
    cred, profile_id = resolve_provider_credential(provider_name, auth_profiles_path)
    if not cred:
        return (None, None)
    # Determine runtime provider name (openai-codex -> openai)
    runtime_provider = provider_name
    if profile_id:
        data = load_auth_profiles(auth_profiles_path)
        profiles = data.get("profiles", {})
        if isinstance(profiles, dict) and profile_id in profiles:
            # Check if this was matched via openai-codex
            last_good = data.get("lastGood", {})
            if last_good.get("openai-codex") == profile_id:
                runtime_provider = "openai"
    return (runtime_provider, cred)



@dataclass
class Config:
    bot_name: str = "Antaris"
    provider_name: str = "anthropic"
    api_key: str = ""
    model: str = "claude-sonnet-4-6"
    fallback_model: str = "claude-sonnet-4-20250514"
    ollama_base_url: str = "http://localhost:11434/v1"
    discord_token: str = ""
    discord_enabled: bool = False
    discord_open_channels: list = field(default_factory=list)
    discord_require_mention: bool = True
    discord_bridge_enabled: bool = False
    discord_bridge_channels: list = field(default_factory=list)
    telegram_token: str = ""
    telegram_open_chats: list = field(default_factory=list)
    telegram_enabled: bool = False
    slack_bot_token: str = ""
    slack_app_token: str = ""
    slack_enabled: bool = False
    slack_open_channels: list = field(default_factory=list)
    memory_store: str = str(DEFAULT_CONFIG_DIR / "memory")
    memory_search_limit: int = 10
    memory_min_relevance: float = 0.3
    memory_storage_backend: str = "file"        # file | sqlite (future)
    memory_session_awareness: bool = False       # enable session-aware recall
    memory_tiered_storage: bool = False          # enable hot/cold tiered storage
    guard_mode: str = "monitor"  # monitor | warn | block
    security_mode: str = "standard"  # open(0) | standard(1) | sandboxed(2) | secured(3) | encrypted(4)
    context_max_tokens: int = 1000000
    rate_limit_messages: int = 20
    rate_limit_window_seconds: int = 60
    token_rate_limit_enabled: bool = False
    token_rate_limit_per_hour: int = 100000
    auto_update: bool = False
    notify_updates: bool = True
    config_path: str = str(DEFAULT_CONFIG_PATH)
    # Extra provider API keys for multi-provider routing
    anthropic_api_key: str = ""
    openai_api_key: str = ""
    google_api_key: str = ""
    qwen_api_key: str = ""
    extra_api_keys: dict = None  # Generic storage for providers without dedicated fields (deepseek, mistral, etc.)
    auth_profiles_path: str = ""
    auth_profile_id: str = ""
    auth_profiles_enabled: bool = False
    # Compaction notification settings
    owner_user_id: str = ""            # Discord user ID to DM on compaction
    compaction_threshold: int = 80     # percent of context_max_tokens to trigger ping
    keep_recent_tokens: int = 100000   # tokens of recent history to preserve on compaction
    pre_compaction_ratio: float = 0.75  # trigger pre-flush at this fraction of threshold
    startup_restore_days: int = 2      # how many days of daily logs to read on startup
    max_tool_iterations: int = 100     # max tool call loop iterations (safety net)
    timezone: str = "UTC"              # IANA timezone for date injection + cron default
    # push_guard: bool = False         # v2.3.3: CLI-based push approval gate (not yet wired)
    # Memory settings
    per_turn_recall: bool = True       # enable per-turn memory recall
    # Heartbeat settings
    heartbeat_enabled: bool = False    # enable heartbeat system
    heartbeat_interval_minutes: int = 30  # heartbeat check interval
    # Subagent settings
    max_subagents: int = 4             # max concurrent subagents (4 = base, 8-12 for powerful machines)
    # Session persistence settings
    session_persistence_enabled: bool = True
    session_save_interval: int = 5     # save every N messages
    session_max_age_hours: int = 48    # prune sessions older than this
    # v6.1: single-session mode — "one bot, one brain, everywhere"
    # "single" = all channels share one unified session (for non-technical users)
    # "multi" = each channel gets its own session (default, for power users)
    session_mode: str = "multi"

    # Cost tracking settings
    # v1.7.0: Cross-channel recency
    recency_enabled: bool = True
    recency_window: float = 6.0      # hours
    recency_limit: int = 5

    cost_tracking_enabled: bool = True
    cost_tracking_save_interval: int = 10

    # LLM defaults (0 = use per-model auto-detection)
    max_tokens: int = 0          # 0 = use get_model_max_tokens() auto-detection
    temperature: Optional[float] = None  # None = let model use its own default

    # Extension settings
    extensions_enabled: bool = True
    # Webhook settings (loaded from config.json "webhooks" section)
    webhooks_enabled: bool = False

    @classmethod
    def load(cls, path: Optional[str] = None) -> Optional["Config"]:
        config_path = resolve_config_path(path)
        if not config_path.exists():
            return None
        with open(config_path) as f:
            data = json.load(f)
        # Guard: if config.json is empty ({}), treat it as missing/corrupt
        if not data or (not data.get("provider") and not data.get("bot")):
            import logging, traceback
            logging.getLogger(__name__).warning(
                "Config.load(): config.json appears empty or corrupt (no provider/bot section). "
                "File size: %d bytes. Content preview: %s. "
                "Will attempt backup recovery.\nCaller: %s",
                config_path.stat().st_size,
                repr(data)[:200],
                ''.join(traceback.format_stack()[-4:])
            )
            return None
        cfg = cls()
        cfg.config_path = str(config_path)
        cfg.bot_name = data.get("bot", {}).get("name", "Antaris")
        provider = data.get("provider", {})
        cfg.auth_profiles_path = data.get("authProfilesPath", provider.get("authProfilesPath", ""))
        cfg.provider_name = provider.get("name", "anthropic")
        cfg.api_key = provider.get("apiKey", "")
        _model_raw = provider.get("model", "claude-sonnet-4-6")
        cfg.model = _model_raw.get("primary", "claude-sonnet-4-6") if isinstance(_model_raw, dict) else _model_raw
        cfg.fallback_model = provider.get("fallbackModel", "claude-sonnet-4-20250514")
        cfg._selected_models = provider.get("selectedModels", [])
        cfg._fallback_chain = provider.get("fallbackChain", [])
        cfg.ollama_base_url = provider.get("ollamaBaseUrl", "http://localhost:11434/v1")
        # Load extra provider keys for multi-provider routing
        extra_providers = data.get("providers", {})
        cfg.anthropic_api_key = extra_providers.get("anthropic", {}).get("apiKey", cfg.api_key if cfg.provider_name == "anthropic" else "")
        cfg.openai_api_key = extra_providers.get("openai", {}).get("apiKey", cfg.api_key if cfg.provider_name == "openai" else "")
        cfg.google_api_key = extra_providers.get("google", {}).get("apiKey", cfg.api_key if cfg.provider_name == "google" else "")
        cfg.qwen_api_key = extra_providers.get("qwen", {}).get("apiKey", cfg.api_key if cfg.provider_name == "qwen" else "")
        cfg._extra_providers = []
        _known_providers = {'anthropic', 'openai', 'google', 'qwen', 'ollama'}
        cfg.extra_api_keys = {}
        for _name, _cfg in extra_providers.items():
            if _name == "ollama":
                cfg._extra_providers.append({"provider": "ollama", "api_key": _cfg.get("baseUrl", "")})
            else:
                cfg._extra_providers.append({"provider": _name, "api_key": _cfg.get("apiKey", "")})
            # Store non-dedicated providers in generic dict
            if _name not in _known_providers and isinstance(_cfg, dict):
                cfg.extra_api_keys[_name] = _cfg

        # Auth-profiles: check legacy auth_profiles section first, then top-level authProfilesPath
        auth_profiles = data.get('auth_profiles', {})
        cfg.auth_profiles_enabled = bool(auth_profiles.get('enabled', False))
        if auth_profiles.get('path'):
            cfg.auth_profiles_path = auth_profiles['path']

        # Resolve credentials from auth-profiles for primary provider
        _auth_path = cfg.auth_profiles_path or None
        if not cfg.api_key:
            resolved_cred, profile_id = resolve_provider_credential(cfg.provider_name, _auth_path)
            if resolved_cred:
                cfg.api_key = resolved_cred
                cfg.auth_profile_id = profile_id or ""
        if not cfg.anthropic_api_key:
            cred, _ = resolve_provider_credential("anthropic", _auth_path)
            if cred:
                cfg.anthropic_api_key = cred
        if not cfg.openai_api_key:
            cred, _ = resolve_provider_credential("openai", _auth_path)
            if cred:
                cfg.openai_api_key = cred

        # Legacy auth_profiles.enabled: override provider/key if credential found
        if cfg.auth_profiles_enabled:
            resolved_provider, token = load_auth_profile_credential(cfg.provider_name, _auth_path)
            if token:
                if resolved_provider:
                    cfg.provider_name = resolved_provider
                cfg.api_key = token
        # Ollama base URL can be overridden per-provider in providers block
        _ollama_provider_url = extra_providers.get("ollama", {}).get("baseUrl", "")
        if _ollama_provider_url:
            cfg.ollama_base_url = _ollama_provider_url
        discord = data.get("channels", {}).get("discord", {})
        cfg.discord_enabled = discord.get("enabled", False)
        cfg.discord_token = discord.get("token", "")
        cfg.discord_open_channels = discord.get("openChannels", [])
        cfg.discord_require_mention = discord.get("requireMention", True)
        cfg.discord_bridge_enabled = discord.get("bridgeEnabled", False)
        cfg.discord_bridge_channels = discord.get("bridgeChannels", [])
        telegram = data.get("channels", {}).get("telegram", {})
        cfg.telegram_enabled = telegram.get("enabled", False)
        cfg.telegram_token = telegram.get("token", "")
        cfg.telegram_open_chats = telegram.get("openChats", [])
        slack = data.get("channels", {}).get("slack", {})
        cfg.slack_enabled = slack.get("enabled", False)
        cfg.slack_bot_token = slack.get("botToken", "")
        cfg.slack_app_token = slack.get("appToken", "")
        cfg.slack_open_channels = slack.get("openChannels", [])
        memory = data.get("memory", {})
        cfg.memory_store = memory.get("store", str(DEFAULT_CONFIG_DIR / "memory"))
        cfg.memory_search_limit = memory.get("searchLimit", 10)
        cfg.memory_min_relevance = memory.get("minRelevance", 0.3)
        cfg.memory_storage_backend = memory.get("storageBackend", "file")
        cfg.memory_session_awareness = memory.get("sessionAwareness", False)
        cfg.memory_tiered_storage = memory.get("tieredStorage", False)
        guard = data.get("guard", {})
        cfg.guard_mode = guard.get("mode", "monitor")
        security = data.get("security", {})
        cfg.security_mode = normalize_security_mode(security.get("mode", "sandboxed"))
        # Derive guard_mode from security_mode (can be overridden by explicit guard config)
        # Guard is ALWAYS on — it's part of Antaris Core (antaris-guard).
        # Security mode only affects the default intensity, never disables it.
        _mode_to_guard = {
            "open": "monitor",       # level 0
            "standard": "monitor",   # level 1
            "sandboxed": "monitor",  # level 2
            "secured": "warn",       # level 3
            "encrypted": "block",    # level 4
        }
        cfg.guard_mode = _mode_to_guard.get(cfg.security_mode, cfg.guard_mode)
        # But still allow explicit guard override in config
        if "mode" in guard:
            cfg.guard_mode = guard.get("mode", cfg.guard_mode)
        context_section = data.get("context", {})
        cfg.context_max_tokens = context_section.get("maxTokens", cfg.context_max_tokens)
        cfg.keep_recent_tokens = context_section.get("keepRecentTokens", cfg.keep_recent_tokens)
        rate_limit = data.get("rate_limit", {})
        cfg.rate_limit_messages = rate_limit.get("max_messages", 20)
        cfg.rate_limit_window_seconds = rate_limit.get("window_seconds", 60)
        token_rate_limit = data.get("token_rate_limit", {})
        cfg.token_rate_limit_enabled = token_rate_limit.get("enabled", False)
        cfg.token_rate_limit_per_hour = token_rate_limit.get("per_hour", 100000)
        updates = data.get("updates", {})
        cfg.auto_update = updates.get("autoUpdate", False)
        cfg.notify_updates = updates.get("notifyUpdates", True)
        bot_section = data.get("bot", {})
        cfg.owner_user_id = bot_section.get("ownerUserId", "")
        cfg.compaction_threshold = bot_section.get("compactionThreshold", 80)
        cfg.pre_compaction_ratio = bot_section.get("preCompactionRatio", 0.75)
        cfg.startup_restore_days = bot_section.get("startupRestoreDays", 2)
        # Memory settings  
        memory_section = data.get("memory", {})
        cfg.per_turn_recall = memory_section.get("perTurnRecall", True)
        # Heartbeat settings
        cfg.heartbeat_enabled = bot_section.get("heartbeatEnabled", False)
        cfg.heartbeat_interval_minutes = bot_section.get("heartbeatIntervalMinutes", 30)
        cfg.max_subagents = bot_section.get("maxSubagents", 4)
        cfg.max_tool_iterations = bot_section.get("maxToolIterations", 100)
        cfg.timezone = bot_section.get("timezone", "UTC")
        # cfg.push_guard = bot_section.get("pushGuard", False)  # v2.3.3
        # Session persistence
        cfg.session_persistence_enabled = bot_section.get("sessionPersistenceEnabled", True)
        cfg.session_save_interval = bot_section.get("sessionSaveInterval", 5)
        cfg.session_max_age_hours = bot_section.get("sessionMaxAgeHours", 48)
        # v6.1: single-session mode
        cfg.session_mode = bot_section.get("sessionMode", "multi")
        # v1.7.0: Cross-channel recency
        cfg.recency_enabled = bot_section.get("recencyEnabled", True)
        cfg.recency_window = float(bot_section.get("recencyWindow", 6.0))
        cfg.recency_limit = int(bot_section.get("recencyLimit", 5))
        # Cost tracking settings
        cost_section = data.get("cost_tracking", {})
        cfg.cost_tracking_enabled = cost_section.get("enabled", True)
        cfg.cost_tracking_save_interval = cost_section.get("saveInterval", 10)

        # LLM defaults (max_tokens, temperature)
        llm_section = data.get("llm", {})
        cfg.max_tokens = int(llm_section.get("maxTokens", 0))
        _temp_val = llm_section.get("temperature", None)
        cfg.temperature = float(_temp_val) if _temp_val is not None else None

        # Tools configuration
        cfg._tools_config = data.get("tools", {})

        # Extension master gate — defaults to True for backward compatibility,
        # but can be explicitly disabled in config.json.
        extensions_section = data.get("extensions", {})
        if isinstance(extensions_section, dict):
            cfg.extensions_enabled = extensions_section.get("enabled", True)
        else:
            cfg.extensions_enabled = True

        # Webhooks master gate — defaults to False (safe default).
        webhooks_section = data.get("webhooks", {})
        if isinstance(webhooks_section, dict):
            cfg.webhooks_enabled = webhooks_section.get("enabled", False)
        else:
            cfg.webhooks_enabled = False

        return cfg

    def save(self, path: Optional[str] = None):
        # Guard: never overwrite a valid config with an empty/unconfigured one.
        # Allow oat01 OAuth tokens and standard api03 keys.
        _has_key = bool(self.api_key) or bool(self.anthropic_api_key) or bool(self.openai_api_key)
        if not _has_key and self.provider_name != "ollama":
            import logging, traceback
            logging.getLogger(__name__).warning(
                "Config.save() blocked -- no API key set. Refusing to overwrite config with empty values.\n"
                "Caller traceback:\n%s", ''.join(traceback.format_stack())
            )
            return
        # Forensic logging: trace every save() call to diagnose config wipes
        import logging, traceback
        _logger = logging.getLogger(__name__)
        _logger.info(
            "Config.save() called — bot=%s, provider=%s, has_key=%s, has_discord_token=%s\n"
            "Caller: %s",
            self.bot_name, self.provider_name, bool(self.api_key),
            bool(self.discord_token), ''.join(traceback.format_stack()[-4:])
        )
        config_path = resolve_config_path(path or self.config_path)
        config_path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "bot": {
                "name": self.bot_name,
                "ownerUserId": self.owner_user_id,
                "compactionThreshold": self.compaction_threshold,
                "preCompactionRatio": self.pre_compaction_ratio,
                "startupRestoreDays": self.startup_restore_days,
                "heartbeatEnabled": self.heartbeat_enabled,
                "heartbeatIntervalMinutes": self.heartbeat_interval_minutes,
                "maxSubagents": self.max_subagents,
                "maxToolIterations": self.max_tool_iterations,
                # "pushGuard": self.push_guard,  # v2.3.3
                "timezone": self.timezone,
            },
            "provider": {
                "name": self.provider_name,
                "apiKey": self.api_key,
                "model": self.model,
                "fallbackModel": self.fallback_model,
                "selectedModels": getattr(self, '_selected_models', []),
                "fallbackChain": getattr(self, '_fallback_chain', []),
                "ollamaBaseUrl": self.ollama_base_url,
                "authProfilesPath": self.auth_profiles_path,
            },
            "authProfilesPath": self.auth_profiles_path,
            "channels": {
                "discord": {
                    "enabled": self.discord_enabled,
                    "token": self.discord_token,
                    "openChannels": self.discord_open_channels or [],
                    "requireMention": self.discord_require_mention,
                    "bridgeEnabled": self.discord_bridge_enabled,
                    "bridgeChannels": self.discord_bridge_channels or []
                },
                "telegram": {
                    "enabled": self.telegram_enabled,
                    "token": self.telegram_token,
                    "openChats": self.telegram_open_chats or []
                },
                "slack": {
                    "enabled": self.slack_enabled,
                    "botToken": self.slack_bot_token,
                    "appToken": self.slack_app_token,
                    "openChannels": self.slack_open_channels or []
                }
            },
            "memory": {
                "store": self.memory_store,
                "searchLimit": self.memory_search_limit,
                "minRelevance": self.memory_min_relevance,
                "storageBackend": self.memory_storage_backend,
                "sessionAwareness": self.memory_session_awareness,
                "tieredStorage": self.memory_tiered_storage,
                "autoIngest": True,
                "autoRecall": True,
                "perTurnRecall": self.per_turn_recall
            },
            "guard": {"mode": self.guard_mode},
            "security": {"mode": self.security_mode},
            "context": {
                "maxTokens": self.context_max_tokens,
                "keepRecentTokens": self.keep_recent_tokens,
            },
            "updates": {
                "autoUpdate": self.auto_update,
                "notifyUpdates": self.notify_updates
            },
            "tools": getattr(self, '_tools_config', {}),
            "rate_limit": {
                "max_messages": self.rate_limit_messages,
                "window_seconds": self.rate_limit_window_seconds,
            },
            "token_rate_limit": {
                "enabled": self.token_rate_limit_enabled,
                "per_hour": self.token_rate_limit_per_hour,
            },
            "cost_tracking": {
                "enabled": self.cost_tracking_enabled,
                "saveInterval": self.cost_tracking_save_interval,
            },
            "auth_profiles": {
                "enabled": self.auth_profiles_enabled,
                "path": self.auth_profiles_path,
            },
            "llm": {
                "maxTokens": self.max_tokens,
                **({"temperature": self.temperature} if self.temperature is not None else {}),
            },
        }
        # v1.7.0: Persist recency + session persistence into bot section
        data["bot"]["recencyEnabled"] = self.recency_enabled
        data["bot"]["recencyWindow"] = self.recency_window
        data["bot"]["recencyLimit"] = self.recency_limit
        data["bot"]["sessionPersistenceEnabled"] = self.session_persistence_enabled
        data["bot"]["sessionSaveInterval"] = self.session_save_interval
        data["bot"]["sessionMaxAgeHours"] = self.session_max_age_hours
        data["bot"]["sessionMode"] = self.session_mode
        # v2.5: Persist extra providers so multi-provider wizard config survives save/load.
        _providers = {}
        _extra_list = getattr(self, '_extra_providers', None)
        if isinstance(_extra_list, list) and _extra_list:
            _selected_extra = {str(ep.get('provider', '')).strip() for ep in _extra_list if isinstance(ep, dict)}
        else:
            _selected_extra = set()
            if self.anthropic_api_key and self.provider_name != 'anthropic':
                _selected_extra.add('anthropic')
            if self.openai_api_key and self.provider_name != 'openai':
                _selected_extra.add('openai')
            if self.google_api_key and self.provider_name != 'google':
                _selected_extra.add('google')
            if self.qwen_api_key and self.provider_name != 'qwen':
                _selected_extra.add('qwen')
        if 'anthropic' in _selected_extra and self.provider_name != 'anthropic':
            _providers['anthropic'] = {'apiKey': self.anthropic_api_key}
        if 'openai' in _selected_extra and self.provider_name != 'openai':
            _providers['openai'] = {'apiKey': self.openai_api_key}
        if 'google' in _selected_extra and self.provider_name != 'google':
            _providers['google'] = {'apiKey': self.google_api_key}
        if 'qwen' in _selected_extra and self.provider_name != 'qwen':
            _providers['qwen'] = {'apiKey': self.qwen_api_key}
        if 'ollama' in _selected_extra and self.provider_name != 'ollama':
            _providers['ollama'] = {'baseUrl': self.ollama_base_url or 'http://localhost:11434/v1'}
        # Persist generic extra providers (deepseek, mistral, groq, together, kimi, minimax, etc.)
        _generic = getattr(self, 'extra_api_keys', None) or {}
        for _gname, _gval in _generic.items():
            if _gname not in _providers:
                if isinstance(_gval, dict):
                    _providers[_gname] = _gval
                elif isinstance(_gval, str) and _gval:
                    _providers[_gname] = {'apiKey': _gval}
        data['providers'] = _providers

        # Preserve unknown top-level keys from existing config (providers, router, requireMention, etc.)
        # This prevents data loss when save() doesn't model all fields.
        if config_path.exists() and config_path.stat().st_size > 10:
            try:
                with open(config_path) as _f:
                    existing = json.load(_f)
                if isinstance(existing, dict):
                    for key, value in existing.items():
                        if key not in data:
                            data[key] = value
                            _logger.debug("Config.save(): preserved unknown key '%s' from existing config", key)
                    # Note: discord.requireMention is explicitly serialized above — do NOT re-read from disk here
            except (json.JSONDecodeError, OSError, KeyError):
                pass

        # Backup the existing config before overwriting, if it is non-empty valid JSON.
        bak_path = config_path.parent / ("." + config_path.name + ".bak")
        if config_path.exists() and config_path.stat().st_size > 0:
            try:
                with open(config_path) as _f:
                    json.load(_f)
                shutil.copy2(str(config_path), str(bak_path))
            except (json.JSONDecodeError, OSError):
                pass  # existing file is corrupt or unreadable -- skip backup
        # Atomic write: write to a temp file then rename into place.
        tmp_path = config_path.parent / (config_path.name + ".tmp")
        with open(tmp_path, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(str(tmp_path), str(config_path))
        print(f"   Config saved to {config_path}")

    @classmethod
    def load_with_fallback(cls, path: Optional[str] = None) -> Optional["Config"]:
        """Load config, falling back to .bak if main file is empty or corrupt."""
        cfg = cls.load(path)
        if cfg and cfg.api_key:
            return cfg
        # Try backup
        config_path = resolve_config_path(path)
        # Check both naming conventions for backup
        bak_path = config_path.parent / ("." + config_path.name + ".bak")
        if not bak_path.exists():
            bak_path = config_path.parent / (config_path.name + ".bak")
        if bak_path.exists():
            import logging
            logging.getLogger(__name__).warning(
                "Main config empty/corrupt, loading from backup: %s", bak_path
            )
            recovered = cls.load(str(bak_path))
            if recovered and recovered.api_key:
                # Self-heal: restore backup to main config path
                recovered.config_path = str(config_path)
                try:
                    shutil.copy2(str(bak_path), str(config_path))
                    logging.getLogger(__name__).info(
                        "Config self-healed: restored %s from backup", config_path
                    )
                except OSError as e:
                    logging.getLogger(__name__).warning(
                        "Could not self-heal config: %s", e
                    )
                return recovered
            return recovered
        return cfg

    def validate(self) -> list[str]:
        errors = []
        if self.provider_name != "ollama" and not self.api_key:
            errors.append("API key is required")
        if self.discord_enabled and not self.discord_token:
            errors.append("Discord token required when Discord is enabled")
        if self.telegram_enabled and not self.telegram_token:
            errors.append("Telegram token required when Telegram is enabled")
        if self.slack_enabled and not self.slack_bot_token:
            errors.append("Slack bot token required when Slack is enabled")
        if self.slack_enabled and not self.slack_app_token:
            errors.append("Slack app token required when Slack is enabled")
        self.security_mode = normalize_security_mode(self.security_mode)
        valid_modes = ("open", "standard", "sandboxed", "secured", "encrypted")
        if self.security_mode not in valid_modes:
            errors.append(f"Invalid security_mode '{self.security_mode}'. Must be one of: {', '.join(valid_modes)}")
        return errors


def _review_and_confirm(config: "Config") -> str:
    """Review the config and ask the user what to do next.

    Returns:
        One of: "save", "restart", "quit"
    """

    def _mask(s, show=12):
        if not s:
            return "(not set)"
        return s[:show] + "..." if len(s) > show + 4 else "***"

    print(f"\n{'═' * 50}")
    print("  Review your configuration:")
    print(f"{'═' * 50}")
    print(f"  Bot name:     {config.bot_name}")
    print(f"  Provider:     {config.provider_name} ({config.model})")
    print(f"  Credential:   {_mask(config.api_key)}")
    print(
        f"  Discord:      {'enabled (' + _mask(config.discord_token) + ')' if config.discord_enabled else 'not enabled'}"
    )
    print(f"  Security:     {config.security_mode}")
    print(f"  Memory:       {config.memory_store}")
    print(f"{'═' * 50}")

    import sys

    while True:
        try:
            sys.stdout.flush()
            choice = input("\nSave? [Y]es / [r]estart / [q]uit: ").strip().lower() or "y"
        except (EOFError, KeyboardInterrupt):
            print("\n")
            return "quit"
        if choice in ("y", "yes"):
            return "save"
        if choice in ("r", "restart"):
            return "restart"
        if choice in ("q", "quit"):
            return "quit"


def run_init_wizard(security_mode: str = None):
    """Interactive setup wizard.

    Args:
        security_mode: Pre-select security mode ('open', 'sandboxed', 'locked').
                       When provided, the security prompt is skipped entirely.
    """

    import sys

    while True:
        print("🤖 Welcome to Antaris Agent\n")

        config = Config()
        config_dir = DEFAULT_CONFIG_DIR
        config_dir.mkdir(parents=True, exist_ok=True)

        # ── Step 1: Bot name ───────────────────────────────────────────────
        print("── Step 1: Identity ──")
        name = input(f"Bot name [{config.bot_name}]: ").strip()
        if name:
            config.bot_name = name
        print(f"  ✅ Bot name: {config.bot_name}")

        # ── Step 2: Provider ───────────────────────────────────────────────
        print("\n── Step 2: LLM Provider ──")
        print("  [1] Anthropic (Claude) — recommended")
        print("  [2] OpenAI (GPT)")
        print("  [3] Google (Gemini)")
        print("  [4] Ollama (local, fully offline, zero cost)")
        choice = input("Select [1]: ").strip() or "1"
        if choice == "2":
            config.provider_name = "openai"
            config.model = "gpt-5.4"
            config.fallback_model = "gpt-5.2"
        elif choice == "3":
            config.provider_name = "google"
            config.model = "gemini-3.1-pro"
            config.fallback_model = "gemini-2.0-flash"
        elif choice == "4":
            config.provider_name = "ollama"
            config.api_key = "ollama"
            print("\nOllama model (installed models: run `ollama list`):")
            print("  Recommended: qwen3.5:4b (best balance, ~2.5GB)")
            print("  Lightweight: qwen3.5:2b, qwen3.5:0.8b")
            print("  High quality: qwen3.5:9b, qwen3:8b")
            model = input("Model [qwen3.5:4b]: ").strip() or "qwen3.5:4b"
            config.model = model
            config.fallback_model = model
            base_url = input("Ollama base URL [http://localhost:11434/v1]: ").strip()
            if base_url:
                config.ollama_base_url = base_url

        # ── Step 3: API Key or OAuth Token (skip for ollama) ──────────────
        if config.provider_name != "ollama":
            print("\n── Step 3: Authentication ──")
            print(f"Enter your {config.provider_name.capitalize()} API key or OAuth token.")
            print("(Paste it and press Enter)")
            sys.stdout.flush()
            api_key = input("> ").strip()
            config.api_key = api_key
            if api_key:
                masked = api_key[:12] + "..." + api_key[-4:] if len(api_key) > 20 else "***"
                print(f"  ✅ Credential saved ({masked})")
            else:
                print("  ⚠️  No credential entered — you can add one later in config.json")

        # Clear any leftover input from long pastes
        sys.stdout.flush()

        # ── Step 4: Discord ────────────────────────────────────────────────
        print("\n── Step 4: Discord ──")
        print("Enter your Discord bot token (or press Enter to skip):")
        sys.stdout.flush()
        discord_token = input("> ").strip()
        if discord_token:
            config.discord_enabled = True
            config.discord_token = discord_token
            masked_dt = discord_token[:12] + "..." if len(discord_token) > 16 else "***"
            print(f"  ✅ Discord enabled ({masked_dt})")
        else:
            print("  ⏭️  Skipped — Discord not enabled")

        # ── Step 5: Security mode ──────────────────────────────────────────
        print("\n── Step 5: Security ──")
        if security_mode:
            config.security_mode = security_mode
            print(f"Security mode: {security_mode} (pre-selected)")
        else:
            print("Security mode — how much can your bot access?")
            print("  [0] Open — no restrictions, full access, developer mode")
            print("  [1] Standard — light safety net, workspace + home scoped")
            print("  [2] Sandboxed (recommended) — filesystem restricted, subprocesses blocked")
            print("  [3] Secured — network allowlisted, destructive ops need approval")
            print("  [4] Encrypted — all tools need approval, owner-only memory, full audit")
            sys.stdout.flush()
            sec_choice = input("Select [2]: ").strip() or "2"
            config.security_mode = normalize_security_mode(sec_choice)
            print(f"  ✅ Security mode: {config.security_mode}")

        action = _review_and_confirm(config)
        if action == "restart":
            print("\n🔄 Restarting setup...\n")
            continue
        if action == "quit":
            print("\n❌ Setup cancelled. No config saved.")
            return

        # ── Validate & Save ────────────────────────────────────────────────
        errors = config.validate()
        if errors:
            print("\n⚠️  Validation issues:")
            for e in errors:
                print(f"   - {e}")
            choice = input("Save anyway? [y/N]: ").strip().lower()
            if choice not in ("y", "yes"):
                print("❌ Setup cancelled.")
                return

        config.save()
        break

    # Create default SOUL.md if it doesn't exist
    soul_path = config_dir / "SOUL.md"
    if not soul_path.exists():
        import shutil
        from pathlib import Path as P
        template = P(__file__).parent.parent / "persona" / "templates" / "default_soul.md"
        if template.exists():
            shutil.copy(template, soul_path)
            print(f"   SOUL.md created at {soul_path}")

    # Create USER.md if it doesn't exist
    user_path = config_dir / "USER.md"
    if not user_path.exists():
        user_path.write_text("# About You\n\n*Antaris will learn about you over time.*\n")
        print(f"   USER.md created at {user_path}")

    # Create memory dir
    memory_dir = Path(config.memory_store)
    memory_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n✅ {config.bot_name} initialized at {config_dir}")
    print("   Run 'antaris start' to launch.")
    if not config.discord_enabled:
        print("   Tip: Run 'antaris chat' to test in terminal first.")


def run_init_create(config_dir=None):
    """Create directory structure + blank skeleton config. No interactive prompts.

    This is the new 'antaris init' — just scaffolding. The browser wizard
    (antaris setup) or awakening chat handles the real configuration.
    """
    from pathlib import Path

    config_dir = Path(config_dir) if config_dir else DEFAULT_CONFIG_DIR
    config_dir.mkdir(parents=True, exist_ok=True)

    config_path = config_dir / "config.json"
    if config_path.exists():
        print(f"⚠️  Config already exists at {config_path}")
        print("   Run 'antaris setup' to reconfigure, or 'antaris start' to launch.")
        return

    # Blank skeleton — user fills in via wizard or awakening.
    # Write directly instead of Config.save() because save() has a guard
    # that refuses to write when no API key is set.
    import json
    skeleton = {
        "bot": {"name": ""},
        "provider": {"name": "", "apiKey": "", "model": ""},
        "channels": {},
        "memory": {"store": str(config_dir / "memory_store")},
        "security": {"mode": "standard"},
    }
    config_path.write_text(json.dumps(skeleton, indent=2) + "\n")
    config = Config.load(str(config_path))

    # Create SOUL.md
    soul_path = config_dir / "SOUL.md"
    if not soul_path.exists():
        import shutil
        template = Path(__file__).parent.parent / "persona" / "templates" / "default_soul.md"
        if template.exists():
            shutil.copy(template, soul_path)
            print(f"   SOUL.md created at {soul_path}")

    # Create USER.md
    user_path = config_dir / "USER.md"
    if not user_path.exists():
        user_path.write_text("# About You\n\n*Your agent will learn about you over time.*\n")
        print(f"   USER.md created at {user_path}")

    # Create memory dir
    memory_dir = Path(config.memory_store)
    memory_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n✅ Initialized at {config_dir}")
    print(f"   Config: {config_path}")
    print("   Run 'antaris setup' to configure, or 'antaris start' to launch.")
