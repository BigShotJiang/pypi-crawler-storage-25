"""
Antaris Agent — Main Bot class.

Wires all components together:
  Config → Memory → Guard → Persona → LLM → Pipeline → Channels
"""

import asyncio
import logging
import os
import signal
import sys
from pathlib import Path
from typing import Optional

from antaris_agent.core.config import Config, DEFAULT_CONFIG_PATH
from antaris_agent.core.logger import setup_logging
from antaris_agent.core.memory import BotMemory
from antaris_agent.core.guard import BotGuard
from antaris_agent.core.updater import Updater
from antaris_agent.core.pipeline import Pipeline
from antaris_agent.persona.loader import PersonaLoader
from antaris_agent.persona.awakening import Awakening
from antaris_agent.llm.anthropic import AnthropicProvider
from antaris_agent.channels.base import InboundMessage, OutboundMessage, ChannelAdapter
from antaris_agent.channels.terminal import TerminalAdapter
from antaris_agent.extensions.manager import ExtensionManager
from antaris_agent.extensions.loader import ExtensionLoader
# Channel adapters are lazy-imported at connect time to avoid
# requiring all platform dependencies at import time.
# See _connect_channels() for the actual imports.

logger = logging.getLogger(__name__)


class Bot:
    """
    Main Antaris Agent class. Loads config, initializes all components, runs channels.

    Usage:
        Bot().start()                      # all configured channels
        Bot().start(terminal_only=True)    # terminal only
        Bot().chat()                       # alias for terminal mode
    """

    def __init__(self, config_path: Optional[str] = None):
        self.config = Config.load_with_fallback(config_path)
        if not self.config:
            logger.error("Bot not initialized. Run 'antaris-agent init' first.")
            sys.exit(1)

        # ── Structured logging — set up before anything else ─────────────
        config_dir = str(Path(self.config.config_path).parent)
        setup_logging(config_dir)
        logger.info("Bot.__init__: config loaded from %s", self.config.config_path)

        errors = self.config.validate()
        if errors:
            logger.error("Configuration errors:")
            print("❌ Configuration errors:")
            for e in errors:
                logger.error("  - %s", e)
            sys.exit(1)

        # ── Components ────────────────────────────────────────────────────
        self._update_notification: Optional[str] = None
        self._first_message_sent: bool = False
        # Back-compat mirrors for older tests/helpers. Live handling now uses SessionState.
        self._message_count: int = 0
        self._compaction_notified: bool = False
        self._pre_compaction_flushed: bool = False
        self._conversation_buffer: list[tuple[str, str, str]] = []

        if getattr(self.config, "auto_update", False):
            logger.info("Auto-update enabled — checking for updates...")
        elif getattr(self.config, "notify_updates", True):
            notify_msg = Updater().check_and_notify()
            if notify_msg:
                logger.info("Update available: %s", notify_msg)

        # ── Initialize components ─────────────────────────────────────────
        # Guard: skip if config not yet loaded (setup wizard will run in start())
        self.memory = None
        self.guard = None
        self.persona = None
        self.awakening = None
        self.llm = None
        self.pipeline = None
        self.tool_middleware = None
        self.tool_registry = None
        self._channels: list[ChannelAdapter] = []

        if not self.config:
            return  # start() will run setup wizard and call _init_components()

        self._init_components()

    def _init_components(self) -> None:
        """Initialise bot components from self.config. Called after config is confirmed loaded."""
        # ── Security setup (must run first — audit hook is irremovable once set) ──
        security_mode = getattr(self.config, "security_mode", "sandboxed")

        # 1. Register audit hook
        from antaris_agent.core.guard import register_audit_hook
        # Use the config directory as workspace root (not just memory subdir)
        # so the audit hook allows access to config.json, SOUL.md, etc.
        _config_dir = str(Path(self.config.config_path).parent)
        register_audit_hook(
            security_mode=security_mode,
            workspace_path=_config_dir,
        )

        # 2. Load encryption key for encrypted mode
        #    ("locked" is a legacy alias, already normalized to "encrypted" by config)
        self._encryption_key: Optional[bytes] = None
        if security_mode in ("locked", "encrypted"):
            try:
                from antaris_agent.security.encrypted_store import load_or_create_key
                self._encryption_key = load_or_create_key()
            except Exception as e:
                raise RuntimeError(
                    "Encrypted mode requires a valid encryption key, but key initialization failed"
                ) from e

        if security_mode == "encrypted" and not self._encryption_key:
            raise RuntimeError("Encrypted mode cannot start without a 32-byte encryption key")

        self.memory = BotMemory(
            store_path=self.config.memory_store,
            search_limit=self.config.memory_search_limit,
            min_relevance=self.config.memory_min_relevance,
            security_mode=security_mode,
            encryption_key=self._encryption_key,
            agent_name=self.config.bot_name or "Antaris Agent",
            memory_storage_backend=self.config.memory_storage_backend,
            memory_session_awareness=self.config.memory_session_awareness,
            memory_tiered_storage=self.config.memory_tiered_storage,
        )
        self.guard = BotGuard(mode=self.config.guard_mode)

        # ── Push guard (v2.3.3 — CLI-based approval, not yet wired) ──────
        self.push_guard = None  # placeholder for v2.3.3

        # ── Tool middleware ────────────────────────────────────────────────
        from antaris_agent.security.tool_middleware import ToolMiddleware
        _audit_log_path = str(Path.home() / ".antaris" / "audit.log")
        self.tool_middleware = ToolMiddleware(
            mode_or_level=security_mode,
            audit_log_path=_audit_log_path,
        )

        self.persona = PersonaLoader(config_dir=_config_dir)

        if self.config.provider_name == "ollama":
            from antaris_agent.llm.ollama import OllamaProvider
            base_url = getattr(self.config, "ollama_base_url", "http://localhost:11434/v1")
            self.llm = OllamaProvider(model=self.config.model, base_url=base_url)
        elif self.config.provider_name == "openai":
            from antaris_agent.llm.openai import OpenAIProvider
            self.llm = OpenAIProvider(api_key=self.config.api_key, model=self.config.model)
        elif self.config.provider_name == "google":
            from antaris_agent.llm.google import GoogleProvider
            self.llm = GoogleProvider(api_key=self.config.api_key, model=self.config.model)
        else:
            self.llm = AnthropicProvider(api_key=self.config.api_key, model=self.config.model)

        self.awakening = Awakening(self.persona, llm=self.llm, memory=self.memory)

        # ── Multi-provider dispatcher for routing ─────────────────────────
        from antaris_agent.llm.dispatcher import LLMDispatcher
        self.dispatcher = LLMDispatcher()

        # Register the primary provider
        self.dispatcher.register(self.config.provider_name, self.llm)

        # Register additional providers if API keys are available in config
        _extra_providers = {
            "anthropic": ("antaris_agent.llm.anthropic", "AnthropicProvider"),
            "openai": ("antaris_agent.llm.openai", "OpenAIProvider"),
            "google": ("antaris_agent.llm.google", "GoogleProvider"),
            "ollama": ("antaris_agent.llm.ollama", "OllamaProvider"),
        }
        for _pname, (_mod, _cls) in _extra_providers.items():
            if _pname == self.config.provider_name:
                continue  # already registered as primary
            try:
                import importlib
                _m = importlib.import_module(_mod)
                _provider_cls = getattr(_m, _cls)
                if _pname == "ollama":
                    # Ollama uses baseUrl, not api_key
                    _base_url = getattr(self.config, "ollama_base_url", "http://localhost:11434/v1")
                    _extra_llm = _provider_cls(base_url=_base_url)
                    self.dispatcher.register(_pname, _extra_llm)
                    logger.info("Registered extra provider: ollama (%s)", _base_url)
                else:
                    _key = getattr(self.config, f"{_pname}_api_key", None)
                    if _key:
                        _provider_model_defaults = {
                            "anthropic": getattr(self.config, "fallback_model", None) or "claude-sonnet-4-6",
                            "openai": "gpt-5.4",
                            "google": "gemini-2.0-flash",
                        }
                        _provider_model = _provider_model_defaults.get(_pname, self.config.model)
                        _extra_llm = _provider_cls(api_key=_key, model=_provider_model)
                        self.dispatcher.register(_pname, _extra_llm)
                        logger.info("Registered extra provider: %s (%s)", _pname, _provider_model)
            except Exception as _e:
                logger.warning("Could not register extra provider %s: %s", _pname, _e)

        # ── Router (antaris-router) ────────────────────────────────────────
        self.router = None
        _router_config = getattr(self.config, "router_config_path", None)
        if _router_config:
            try:
                from antaris_agent.suite.router import Router
                self.router = Router(config_path=_router_config)
                logger.info("Router initialized from config: %s", _router_config)
            except Exception as _e:
                logger.warning("Could not initialize router: %s", _e)

        # ── User profiles ─────────────────────────────────────────────────
        from antaris_agent.core.profiles import ProfileManager
        _profiles_path = Path(self.config.config_path).parent / "profiles"
        self.profiles = ProfileManager(profiles_dir=_profiles_path)

        # ── Teaching store ────────────────────────────────────────────────
        from antaris_agent.core.teachings import TeachingStore
        _teachings_path = Path(self.config.config_path).parent / "teachings"
        self.teachings = TeachingStore(store_dir=_teachings_path)

        # ── Focus manager ─────────────────────────────────────────────────
        from antaris_agent.core.focus import FocusManager
        self.focus = FocusManager()

        # ── Thread manager ────────────────────────────────────────────────
        from antaris_agent.core.threads import ThreadManager
        _threads_path = Path(self.config.config_path).parent / "threads"
        self.threads = ThreadManager(_threads_path)

        # ── Shortcut learner ──────────────────────────────────────────────
        from antaris_agent.core.shortcuts import ShortcutLearner
        _shortcuts_path = Path(self.config.config_path).parent / "shortcuts"
        self.shortcuts = ShortcutLearner(_shortcuts_path)

        # ── Conversation exporter ─────────────────────────────────────────
        from antaris_agent.core.exporter import ConversationExporter
        _exports_path = Path(self.config.config_path).parent / "exports"
        self.exporter = ConversationExporter(self.memory, _exports_path)

        # ── Proactive memory ──────────────────────────────────────────────
        from antaris_agent.core.proactive import ProactiveMemory
        _proactive_path = Path(self.config.config_path).parent / "proactive"
        self.proactive = ProactiveMemory(_proactive_path)

        # ── Mood detector ─────────────────────────────────────────────────
        from antaris_agent.core.mood import MoodDetector
        self.mood = MoodDetector(window_size=10)

        # ── Feedback tracker ──────────────────────────────────────────────
        from antaris_agent.core.feedback import FeedbackTracker
        _feedback_path = Path(self.config.config_path).parent / "feedback"
        self.feedback = FeedbackTracker(store_dir=str(_feedback_path))

        # ── Tool registry ─────────────────────────────────────────────────
        self.tool_registry = self._init_tools()

        self.pipeline = Pipeline(
            config=self.config,
            memory=self.memory,
            guard=self.guard,
            persona=self.persona,
            llm=self.llm,
            awakening=self.awakening,
            tool_middleware=self.tool_middleware,
            router=self.router,
            dispatcher=self.dispatcher,
            profiles=self.profiles,
            teachings=self.teachings,
            focus=self.focus,
            threads=self.threads,
            shortcuts=self.shortcuts,
            proactive=self.proactive,
            mood=self.mood,
            feedback=self.feedback,
            tool_registry=self.tool_registry,
        )

        # ── Cron scheduler ────────────────────────────────────────────────
        from antaris_agent.core.cron import CronScheduler
        _jobs_path = Path(self.config.config_path).parent / "cron" / "jobs.json"
        self.cron = CronScheduler(
            jobs_path=_jobs_path,
            on_fire=self._on_cron_fire,
            default_tz=getattr(self.config, 'timezone', None),
        )

        # ── Command dispatcher ────────────────────────────────────────────
        from antaris_agent.core.commands import CommandDispatcher
        self.commands = CommandDispatcher(self)
        self.pipeline.commands = self.commands

        # Publish session manager for daemon IPC and external access
        self.sessions = getattr(self.pipeline, "_session_manager", None)

        # ── Heartbeat manager ─────────────────────────────────────────────
        from antaris_agent.core.heartbeat import HeartbeatManager
        self.heartbeat = HeartbeatManager(self)

        # ── Capability discovery / reminder system ────────────────────────
        from antaris_agent.core.discovery import DiscoveryManager
        _config_dir = str(Path(self.config.config_path).parent)
        self.discovery = DiscoveryManager(_config_dir)

        # ── Subagent registry ─────────────────────────────────────────────
        from antaris_agent.core.subagents import SubagentRegistry
        self.subagents = SubagentRegistry(
            bot=self,
            max_agents=getattr(self.config, "max_subagents", 4),
        )
        self._active_discord_channel = None  # set when Discord message arrives
        self._active_user_id = ""

        # ── Extension manager ─────────────────────────────────────────────
        self._extension_manager = ExtensionManager()

        # ── Extension security ────────────────────────────────────────────
        from antaris_agent.extensions.security import ExtensionSecurityManager
        _security_mode = getattr(self.config, "security_mode", "sandboxed")
        _config_dir = str(Path(self.config.config_path).parent) if self.config.config_path else ""
        self.extension_security = ExtensionSecurityManager(
            security_mode=_security_mode,
            config_dir=_config_dir,
        )

        # ── Webhook manager ───────────────────────────────────────────────
        from antaris_agent.extensions.webhooks import WebhookManager
        try:
            import json as _json
            _config_path = Path(self.config.config_path)
            if _config_path.exists():
                with open(_config_path) as _f:
                    _full_config = _json.load(_f)
            else:
                _full_config = {}
            self.webhooks = WebhookManager.from_config(_full_config, bot_name=self.config.bot_name)
        except Exception as _wh_err:
            logger.warning("Webhook manager init failed: %s", _wh_err)
            from antaris_agent.extensions.webhooks import WebhookManager
            self.webhooks = WebhookManager(bot_name=self.config.bot_name)

        # ── Auth monitor ──────────────────────────────────────────────────
        from antaris_agent.extensions.auth_monitor import AuthMonitor
        _auth_dir = str(Path(self.config.config_path).parent)
        _auth_profiles_path = getattr(self.config, 'auth_profiles_path', '') or None
        self.auth_monitor = AuthMonitor(
            config_dir=_auth_dir,
            auth_profiles_path=_auth_profiles_path,
        )
        self.auth_monitor._health.primary_provider = self.config.provider_name
        # Track the active profile ID if loaded from auth-profiles
        if getattr(self.config, 'auth_profile_id', ''):
            self.auth_monitor._health.active_profile = self.config.auth_profile_id
        # Wire auth monitor events to webhook system
        self.auth_monitor.set_event_callback(
            lambda event_type, data: self.webhooks.fire(event_type, data)
                if asyncio.get_event_loop().is_running()
                else None
        )
        # Wire operator notification callback (logs rotation events to a channel)
        self.auth_monitor.set_notification_callback(
            lambda msg: self._on_auth_notification(msg)
        )
        # Wire auth monitor into dispatcher for automatic failover on rate limits
        self.dispatcher.set_auth_monitor(self.auth_monitor)
        # Set active profile in dispatcher for profile-level tracking
        if getattr(self.config, 'auth_profile_id', ''):
            self.dispatcher.set_active_profile(
                self.config.provider_name,
                self.config.auth_profile_id,
            )

        # ── Custom skills ─────────────────────────────────────────────────
        from antaris_agent.extensions.skills import SkillLoader, SkillRegistry
        self.skill_registry = SkillRegistry()
        _skill_loader = SkillLoader(config_dir=str(Path(self.config.config_path).parent))
        for _skill in _skill_loader.discover():
            self.skill_registry.register(_skill)
            # Register skill tools into the main tool registry
            for _tool in _skill.tools:
                if self.tool_registry is not None:
                    from antaris_agent.tools import ToolDef as _ToolDef
                    self.tool_registry._native_tools[_tool.name] = _tool
                    self.tool_registry._tool_definitions[_tool.name] = _ToolDef(
                        name=_tool.name,
                        description=_tool.description,
                        input_schema=_tool.input_schema,
                        source=f"skill:{_skill.manifest.name}",
                    )

        # ── Model controller ─────────────────────────────────────────────
        from antaris_agent.extensions.model_control import ModelController
        self.model_controller = ModelController()

        # ── Register SpawnSubagentTool now that subagents registry exists ──
        # Must happen after both tool_registry and subagents are initialized,
        # because SpawnSubagentTool needs a reference to the SubagentRegistry.
        if self.tool_registry is not None:
            try:
                from antaris_agent.tools.native.spawn_subagent import SpawnSubagentTool
                from antaris_agent.tools import ToolDef
                spawn_tool = SpawnSubagentTool(registry=self.subagents, origin_channel=None)
                # Direct dict mutation (bypasses asyncio.Lock in register_native) — safe here
                # because _init_components runs during sequential bot startup, before any
                # message handlers or tool-accessing coroutines are active. The public
                # register_native() is async and would require asyncio.run(), which would
                # conflict with the existing event loop.
                self.tool_registry._native_tools['spawn_subagent'] = spawn_tool
                self.tool_registry._tool_definitions['spawn_subagent'] = ToolDef(
                    name='spawn_subagent',
                    description=spawn_tool.description,
                    input_schema=spawn_tool.input_schema,
                    source='native'
                )
                logger.info("Registered SpawnSubagentTool")
            except Exception as e:
                logger.warning("Failed to register SpawnSubagentTool: %s", e)

        self._accepting_messages = True

    @staticmethod
    def _register_tool(
        registry: 'ToolRegistry',
        ToolDef: type,
        name: str,
        tool_instance: object,
    ) -> None:
        """Register a pre-constructed native tool into *registry*.

        Stores both the tool instance and its ToolDef in the registry's
        internal dicts.  Called from :meth:`_init_tools`.
        """
        registry._native_tools[name] = tool_instance
        registry._tool_definitions[name] = ToolDef(
            name=name,
            description=tool_instance.description,
            input_schema=tool_instance.input_schema,
            source='native',
        )
        logger.info("Registered %s", type(tool_instance).__name__)

    def _init_tools(self) -> Optional['ToolRegistry']:
        """Initialize tool registry with configured tools (sync)."""
        from antaris_agent.tools import ToolRegistry, ToolDef

        registry = ToolRegistry()

        # Load tools config from config.json
        tools_config = getattr(self.config, '_tools_config', {})
        config_dir = str(Path(self.config.config_path).parent)

        # Register native tools synchronously (bypass async register_native)
        # This is safe because we're the only thread during init

        # 1. WebSearchTool — needs API key
        brave_config = tools_config.get('brave_search', {})
        if brave_config.get('enabled') and brave_config.get('apiKey'):
            try:
                from antaris_agent.tools.native.web_search import WebSearchTool
                self._register_tool(registry, ToolDef, 'web_search',
                                    WebSearchTool(api_key=brave_config['apiKey']))
            except Exception as e:
                logger.warning("Failed to register WebSearchTool: %s", e)

        # 2. WebFetchTool
        if tools_config.get('web_fetch', {}).get('enabled', False):
            try:
                from antaris_agent.tools.native.web_fetch import WebFetchTool
                self._register_tool(registry, ToolDef, 'web_fetch', WebFetchTool())
            except Exception as e:
                logger.warning("Failed to register WebFetchTool: %s", e)

        # 3. BrowserTool
        if tools_config.get('browser', {}).get('enabled'):
            try:
                from antaris_agent.tools.native.browser import BrowserTool
                self._register_tool(registry, ToolDef, 'browser',
                                    BrowserTool(workspace_path=config_dir))
            except Exception as e:
                logger.warning("Failed to register BrowserTool: %s", e)

        # 4. FileOpsTool
        if tools_config.get('file_ops', {}).get('enabled'):
            try:
                from antaris_agent.tools.native.file_ops import FileOpsTool
                self._register_tool(registry, ToolDef, 'file_ops',
                                    FileOpsTool(workspace_path=config_dir))
            except Exception as e:
                logger.warning("Failed to register FileOpsTool: %s", e)

        # 5. ShellTool
        if tools_config.get('shell', {}).get('enabled'):
            try:
                from antaris_agent.tools.native.shell import ShellTool
                self._register_tool(registry, ToolDef, 'shell',
                                    ShellTool(workspace_path=config_dir))
            except Exception as e:
                logger.warning("Failed to register ShellTool: %s", e)

        # 6. ImageTool — needs dispatcher reference
        if tools_config.get('image', {}).get('enabled'):
            try:
                from antaris_agent.tools.native.image import ImageTool
                self._register_tool(registry, ToolDef, 'image',
                                    ImageTool(dispatcher=self.dispatcher))
            except Exception as e:
                logger.warning("Failed to register ImageTool: %s", e)

        # 7. VideoTool — ffmpeg/whisper-backed video understanding
        if tools_config.get('video', {}).get('enabled'):
            try:
                from antaris_agent.tools.native.video import VideoTool
                self._register_tool(registry, ToolDef, 'video',
                                    VideoTool(dispatcher=self.dispatcher, workspace_path=config_dir))
            except Exception as e:
                logger.warning("Failed to register VideoTool: %s", e)

        # 8. TTSTool — optional voice param
        tts_config = tools_config.get('tts', {})
        if tts_config.get('enabled'):
            try:
                from antaris_agent.tools.native.tts import TTSTool
                self._register_tool(registry, ToolDef, 'tts',
                                    TTSTool(default_voice=tts_config.get('voice', 'Samantha')))
            except Exception as e:
                logger.warning("Failed to register TTSTool: %s", e)

        # 9. DiscordProactiveTool — discord_client set later
        if tools_config.get('discord_proactive', {}).get('enabled'):
            try:
                from antaris_agent.tools.native.discord_proactive import DiscordProactiveTool
                self._register_tool(registry, ToolDef, 'discord_proactive',
                                    DiscordProactiveTool(discord_client=None))
            except Exception as e:
                logger.warning("Failed to register DiscordProactiveTool: %s", e)

        # 10. SessionStatusTool — needs bot reference
        if tools_config.get('session_status', {}).get('enabled'):
            try:
                from antaris_agent.tools.native.session_status import SessionStatusTool
                self._register_tool(registry, ToolDef, 'session_status',
                                    SessionStatusTool(bot=self))
            except Exception as e:
                logger.warning("Failed to register SessionStatusTool: %s", e)

        # 11. CanvasTool — optional port param
        canvas_config = tools_config.get('canvas', {})
        if canvas_config.get('enabled'):
            try:
                from antaris_agent.tools.native.canvas import CanvasTool
                self._register_tool(registry, ToolDef, 'canvas',
                                    CanvasTool(default_port=canvas_config.get('port', 7777)))
            except Exception as e:
                logger.warning("Failed to register CanvasTool: %s", e)

        # 12. NodesTool
        if tools_config.get('nodes', {}).get('enabled'):
            try:
                from antaris_agent.tools.native.nodes import NodesTool
                self._register_tool(registry, ToolDef, 'nodes', NodesTool())
            except Exception as e:
                logger.warning("Failed to register NodesTool: %s", e)

        # 13. PeekabooTool
        if tools_config.get('peekaboo', {}).get('enabled'):
            try:
                from antaris_agent.tools.native.peekaboo import PeekabooTool
                self._register_tool(registry, ToolDef, 'peekaboo',
                                    PeekabooTool(workspace_path=config_dir))
            except Exception as e:
                logger.warning("Failed to register PeekabooTool: %s", e)

        # 14. PuppeteerTool
        if tools_config.get('puppeteer', {}).get('enabled'):
            try:
                from antaris_agent.tools.native.puppeteer import PuppeteerTool
                self._register_tool(registry, ToolDef, 'puppeteer',
                                    PuppeteerTool(workspace_path=config_dir))
            except Exception as e:
                logger.warning("Failed to register PuppeteerTool: %s", e)

        # 15. Google Workspace tools via gog
        google_workspace_config = tools_config.get('google_workspace', {})
        if google_workspace_config.get('enabled'):
            try:
                from antaris_agent.tools.native import (
                    GogRunner,
                    GmailSearchGogTool,
                    GmailReadGogTool,
                    GmailSendGogTool,
                    GmailDraftGogTool,
                    CalendarListEventsGogTool,
                    CalendarCreateEventGogTool,
                    DriveSearchGogTool,
                    DriveReadGogTool,
                    DocsCreateGogTool,
                    SheetsReadGogTool,
                    SheetsAppendGogTool,
                )
                gog_runner = GogRunner(account=google_workspace_config.get('account'))
                google_tools = [
                    GmailSearchGogTool(gog_runner),
                    GmailReadGogTool(gog_runner),
                    GmailSendGogTool(gog_runner),
                    GmailDraftGogTool(gog_runner),
                    CalendarListEventsGogTool(gog_runner),
                    CalendarCreateEventGogTool(gog_runner),
                    DriveSearchGogTool(gog_runner),
                    DriveReadGogTool(gog_runner),
                    DocsCreateGogTool(gog_runner),
                    SheetsReadGogTool(gog_runner),
                    SheetsAppendGogTool(gog_runner),
                ]
                for tool in google_tools:
                    self._register_tool(registry, ToolDef, tool.name, tool)
            except Exception as e:
                logger.warning("Failed to register Google Workspace tools: %s", e)

        # 15. PowerPointTool
        if tools_config.get('powerpoint', {}).get('enabled'):
            try:
                from antaris_agent.tools.native.pptx_tool import PowerPointTool
                self._register_tool(registry, ToolDef, 'powerpoint',
                                    PowerPointTool(workspace_path=config_dir))
            except Exception as e:
                logger.warning("Failed to register PowerPointTool: %s", e)

        # 16. Load JS bridges if js_bridges.json exists (informational for now)
        js_bridges_path = Path(self.config.config_path).parent / 'tools' / 'js_bridges.json'
        if js_bridges_path.exists():
            try:
                import json
                bridges = json.loads(js_bridges_path.read_text())
                for bridge in bridges.get('bridges', []):
                    logger.info("JS bridge detected: %s at %s", bridge['name'], bridge['script_path'])
            except Exception as e:
                logger.warning("Failed to load JS bridges: %s", e)
        
        # Mark as initialized
        registry._initialized = True
        
        # Return registry if it has native tools OR if MCP servers are configured
        # (MCP servers get connected later in _init_mcp_servers, but need the registry to exist)
        has_native_tools = bool(registry.list_tools())
        has_mcp_config = bool(tools_config.get('mcp_servers', []))
        
        if has_native_tools or has_mcp_config:
            if has_native_tools:
                logger.info("Tool registry initialized with %d tools: %s", 
                           len(registry.list_tools()), ', '.join(registry.list_tools()))
            if has_mcp_config:
                logger.info("MCP servers configured: %d (will connect after startup)", 
                           len(tools_config['mcp_servers']))
            return registry
        else:
            logger.debug("No tools configured, returning None")
            return None

    async def _load_extensions(self) -> None:
        """Discover and load extensions after bot startup (requires async context)."""
        if not hasattr(self, '_extension_manager'):
            return

        # Respect extensions_enabled as a true master gate
        if not getattr(self.config, 'extensions_enabled', True):
            logger.info("Extensions disabled by config (extensions_enabled=false)")
            return
        
        try:
            import json as _json
            _config_path = Path(self.config.config_path)
            if _config_path.exists():
                with open(_config_path) as _f:
                    _full_config = _json.load(_f)
            else:
                _full_config = {}
            
            # Store extensions config on the Config object for loader access
            self.config._extensions_config = _full_config.get("extensions", {})
            
            # Discover extensions from filesystem
            _config_dir = str(Path(self.config.config_path).parent)
            loader = ExtensionLoader(_config_dir)
            discovered = loader.discover_all(config=_full_config)
            
            for ext in discovered:
                # Pass source from loader if available
                _source = getattr(ext, '_source', None)
                self._extension_manager.register(ext, source=_source)
            
            # Load all registered extensions
            if self._extension_manager._extensions:
                results = await self._extension_manager.load_all(self)
                loaded = sum(1 for v in results.values() if v)
                failed = sum(1 for v in results.values() if not v)
                if loaded > 0 or failed > 0:
                    logger.info("Extensions: %d loaded, %d failed", loaded, failed)
        except Exception as e:
            logger.warning("Extension loading failed: %s", e)

    async def _init_mcp_servers(self) -> None:
        """Initialize MCP servers after bot startup (requires async context)."""
        if not self.tool_registry:
            return
            
        tools_config = getattr(self.config, '_tools_config', {})
        mcp_config = tools_config.get('mcp_servers', [])
        
        for server in mcp_config:
            try:
                await self.tool_registry.add_mcp_server(
                    name=server['name'],
                    transport=server.get('transport', 'stdio'),
                    command=server.get('command'),
                    env=server.get('env'),
                    url=server.get('url')
                )
                logger.info("Connected to MCP server: %s", server['name'])
            except Exception as e:
                logger.warning("Failed to connect MCP server %s: %s", server['name'], e)

    async def _on_cron_fire(self, job) -> None:
        """Handle a fired cron job."""
        from antaris_agent.channels.base import InboundMessage
        logger.info("Cron job fired: %s (%s)", job.id, job.name)
        if job.payload_kind == "agentTurn":
            # Fire as a synthetic message through the pipeline
            inbound = InboundMessage(
                id=f"cron_{job.id}",
                user_id="system_cron",
                user_name="system_cron",
                channel_id=job.channel_id or "",
                platform="internal",
                text=job.payload_text,
            )
            # Find the right adapter for this channel
            adapter = None
            for ch in self._channels:
                if hasattr(ch, 'channel_id') and ch.channel_id == job.channel_id:
                    adapter = ch
                    break
            if not adapter and self._channels:
                adapter = self._channels[0]
            if adapter:
                result = await self.pipeline.process(inbound, adapter)

            session = None
            if self.sessions:
                session = await self.sessions.get_or_create(
                    inbound.user_id,
                    inbound.channel_id,
                    inbound.platform,
                )

            # Track message count for checkpoints and estimate token usage for compaction detection
            # Back-compat mirror: keep _message_count updated while session.message_count is authoritative.
            if session is not None:
                self._message_count = session.increment_count()
            else:
                self._message_count += 1
            _threshold_pct = getattr(self.config, 'compaction_threshold', 80)
            _pre_ratio = getattr(self.config, 'pre_compaction_ratio', 0.75)
            _context_max_tokens = max(1, getattr(self.config, 'context_max_tokens', 1_000_000))
            _token_threshold = max(1, int(_context_max_tokens * (_threshold_pct / 100)))
            _pre_threshold = max(1, int(_token_threshold * _pre_ratio))
            _messages = self.pipeline.get_history(inbound.user_id, inbound.channel_id) if self.pipeline else []
            from antaris_agent.core.session import estimate_tokens
            _estimated_tokens = sum(estimate_tokens(m) for m in _messages)

            # Pre-compaction flush: save a session summary before hitting the full token threshold
            if (session is not None
                    and _estimated_tokens >= _pre_threshold
                    and not session.pre_compaction_flushed):
                session.pre_compaction_flushed = True
                self._pre_compaction_flushed = session.pre_compaction_flushed
                asyncio.create_task(self._pre_compaction_flush(session))

            # Full compaction ping: send DM to owner at the token threshold
            if (session is not None
                    and _estimated_tokens >= _token_threshold
                    and not session.compaction_notified
                    and getattr(self.config, 'owner_user_id', '')):
                session.compaction_notified = True
                self._compaction_notified = session.compaction_notified
                asyncio.create_task(self._send_compaction_ping(adapter, session))

            if result.success and result.response_text and session is not None:
                session.add_to_buffer(inbound.user_id, inbound.text, result.response_text)

            if result.response_text:
                    from antaris_agent.channels.base import OutboundMessage
                    await adapter.send(OutboundMessage(
                        channel_id=job.channel_id or "",
                        text=result.response_text,
                    ))
        elif job.payload_kind == "systemEvent":
            logger.info("Cron systemEvent: %s", job.payload_text[:100])
            # Handle heartbeat tick
            if job.payload_text == "heartbeat_tick" and hasattr(self, "heartbeat"):
                try:
                    await self.heartbeat.tick()
                except Exception as e:
                    logger.error("Heartbeat tick failed: %s", e)

    def start(self, terminal_only: bool = False):
        """Launch the bot. Blocks until stopped."""
        # Run setup wizard if the bot has not been configured yet
        from antaris_agent.setup.wizard import SetupWizard
        if SetupWizard().is_needed():
            cfg = SetupWizard().run()
            if cfg:
                self.config = cfg
                self._init_components()
            else:
                logger.error("Setup was cancelled. Run 'antaris setup' to configure.")
                return

        if not self.config:
            logger.error("Bot not initialized. Run 'antaris setup' or 'antaris init' first.")
            sys.exit(1)

        signal.signal(signal.SIGINT, self._handle_shutdown)
        signal.signal(signal.SIGTERM, self._handle_shutdown)

        try:
            asyncio.run(self._run(terminal_only=terminal_only))
        except KeyboardInterrupt:
            logger.info("KeyboardInterrupt received, shutting down.")
            print("\n👋 Stopped.")

    def chat(self):
        """Alias for terminal-only mode."""
        self.start(terminal_only=True)

    # ── Graceful shutdown ─────────────────────────────────────────────────

    def _handle_shutdown(self, sig, frame):
        """Flush memory, set shutdown flag, exit cleanly."""
        logger.info("Shutdown signal received (sig=%s), flushing memory...", sig)
        self._accepting_messages = False

        # Flush memory store
        try:
            if self.memory:
                for user_id, store in self.memory._stores.items():
                    try:
                        store.save()
                    except Exception:
                        pass
                logger.info("Memory stores flushed.")
        except Exception as e:
            logger.warning("Memory save failed during shutdown: %s", e)

        # Remove PID file
        pid_file = Path.home() / ".antaris" / "bot.pid"
        try:
            pid_file.unlink(missing_ok=True)
        except Exception:
            pass

        # Save conversation sessions
        if hasattr(self, 'pipeline') and self.pipeline:
            try:
                self.pipeline.save_sessions()
                logger.info("Conversation sessions saved.")
            except Exception as _e:
                logger.warning("Session save failed during shutdown: %s", _e)

        # ── Async cleanup helper ─────────────────────────────────────────
        # Signal handlers run while the event loop is active, so
        # run_until_complete() would raise "This event loop is already
        # running".  When a loop IS running we schedule the cleanup as a
        # task with an error-logging callback (best-effort — these calls
        # cancel background tasks and disconnect MCP clients; critical
        # state like memory and sessions is already flushed above).
        # When no loop is running we fall back to run_until_complete()
        # for synchronous guaranteed execution.
        import asyncio as _asyncio

        def _schedule_cleanup(coro_fn, label: str) -> None:
            """Run an async cleanup coroutine, adapting to loop state."""
            try:
                _loop = _asyncio.get_running_loop()

                async def _safe():
                    try:
                        await coro_fn()
                    except Exception as _exc:
                        logger.warning("%s cleanup error: %s", label, _exc)

                _loop.create_task(_safe())
            except RuntimeError:
                # No running loop — safe to block
                _new_loop = _asyncio.new_event_loop()
                try:
                    _new_loop.run_until_complete(coro_fn())
                except Exception as _exc:
                    logger.warning("%s cleanup error: %s", label, _exc)
                finally:
                    _new_loop.close()

        # Stop cron scheduler
        if hasattr(self, 'cron') and self.cron:
            _schedule_cleanup(self.cron.stop, "Cron")

        # Stop heartbeat system
        if hasattr(self, 'heartbeat') and self.heartbeat:
            try:
                self.heartbeat.stop()
            except Exception as _e:
                logger.warning("Heartbeat stop failed: %s", _e)

        # Shutdown extension manager
        if hasattr(self, '_extension_manager'):
            _schedule_cleanup(self._extension_manager.shutdown, "Extension manager")

        # Stop webhooks
        if hasattr(self, 'webhooks'):
            _schedule_cleanup(self.webhooks.stop, "Webhook manager")

        # Stop auth monitoring
        if hasattr(self, 'auth_monitor'):
            _schedule_cleanup(self.auth_monitor.stop_monitoring, "Auth monitor")

        # Shutdown tool registry
        if hasattr(self, 'tool_registry') and self.tool_registry:
            _schedule_cleanup(self.tool_registry.shutdown, "Tool registry")

        logger.info("Bot shut down cleanly.")
        sys.exit(0)

    # ── Internal ──────────────────────────────────────────────────────────

    def _setup_channels(self, terminal_only: bool):
        self._channels = []

        if terminal_only:
            self._channels.append(TerminalAdapter(bot_name=self.config.bot_name))
            return

        if self.config.discord_enabled and self.config.discord_token:
            try:
                from antaris_agent.channels.discord import DiscordAdapter
                self._channels.append(
                    DiscordAdapter(
                        token=self.config.discord_token,
                        bot_name=self.config.bot_name,
                        open_channels=self.config.discord_open_channels or [],
                        bot_memory=self.memory,
                        bot_llm=self.llm,
                        feedback_tracker=getattr(self, "feedback", None),
                        bridge_enabled=getattr(self.config, "discord_bridge_enabled", False),
                        bridge_channels=getattr(self.config, "discord_bridge_channels", []),
                    )
                )
            except ImportError:
                logger.error("Discord enabled but discord.py not installed. Run: pip install antaris-agent[discord]")

        if self.config.telegram_enabled and self.config.telegram_token:
            try:
                from antaris_agent.channels.telegram import TelegramAdapter
                self._channels.append(
                    TelegramAdapter(
                        token=self.config.telegram_token,
                        bot_name=self.config.bot_name,
                        open_chats=getattr(self.config, "telegram_open_chats", None) or [],
                    )
                )
            except ImportError:
                logger.error("Telegram enabled but python-telegram-bot not installed. Run: pip install antaris-agent[telegram]")

        if (
            getattr(self.config, "slack_enabled", False)
            and getattr(self.config, "slack_bot_token", "")
            and getattr(self.config, "slack_app_token", "")
        ):
            try:
                from antaris_agent.channels.slack import SlackAdapter
                self._channels.append(
                    SlackAdapter(
                        bot_token=self.config.slack_bot_token,
                        app_token=self.config.slack_app_token,
                        open_channels=getattr(self.config, "slack_open_channels", None) or [],
                    )
                )
            except ImportError:
                logger.error("Slack enabled but slack-bolt not installed. Run: pip install antaris-agent[slack]")

        if not self._channels:
            logger.warning("No channels configured — falling back to terminal mode.")
            logger.info("Tip: Run 'antaris-agent init' to add Discord or Telegram.")
            print("   ⚠️  No channels configured. Starting in terminal mode.")
            print("   Tip: Run 'antaris-agent init' to add Discord or Telegram.")
            self._channels.append(TerminalAdapter(bot_name=self.config.bot_name))
    async def _run(self, terminal_only: bool = False):
        self._setup_channels(terminal_only=terminal_only)
        
        # Initialize MCP servers (requires async context)
        await self._init_mcp_servers()
        
        # Load extensions (requires async context)
        await self._load_extensions()
        
        # Start webhook delivery worker
        if hasattr(self, 'webhooks'):
            await self.webhooks.start()
        
        # Start auth monitoring
        if hasattr(self, 'auth_monitor'):
            await self.auth_monitor.start_monitoring()
        
        if hasattr(self, 'cron') and self.cron:
            await self.cron.start()
        # Start heartbeat system
        if hasattr(self, 'heartbeat') and self.heartbeat:
            self.heartbeat.start()
        self._print_banner()
        for adapter in self._channels:
            adapter.on_message(self._make_handler(adapter))
        results = await asyncio.gather(
            *[adapter.connect() for adapter in self._channels],
            return_exceptions=True,
        )
        for adapter, result in zip(self._channels, results):
            if isinstance(result, Exception):
                name = type(adapter).__name__
                logger.error("Channel %s failed to connect: %s", name, result)
                print(f"   ❌ {name} failed: {result}")
        
        # Setup Discord client for Discord proactive tool
        await self._setup_discord_proactive_tool()

    def _make_handler(self, adapter: ChannelAdapter):
        async def handle(inbound: InboundMessage):
            if not self._accepting_messages:
                logger.debug("Ignoring message during shutdown from user=%s", inbound.user_id)
                return
            if not self._first_message_sent and self._update_notification:
                self._first_message_sent = True
                try:
                    await adapter.send(
                        OutboundMessage(
                            channel_id=inbound.channel_id,
                            text=self._update_notification,
                            reply_to=None,
                        )
                    )
                except Exception as exc:
                    logger.warning("Could not send update notification: %s", exc)
            elif not self._first_message_sent:
                self._first_message_sent = True

            # Resolve per-session state (same pattern as _on_cron_fire)
            session = None
            if self.sessions:
                session = await self.sessions.get_or_create(
                    inbound.user_id, inbound.channel_id, inbound.platform
                )

            result = await self.pipeline.process(inbound, adapter)

            # Track message count for checkpoints and estimate token usage for compaction detection
            if session is not None:
                self._message_count = session.increment_count()
            else:
                self._message_count += 1
            _threshold_pct = getattr(self.config, 'compaction_threshold', 80)
            _pre_ratio = getattr(self.config, 'pre_compaction_ratio', 0.75)
            _context_max_tokens = max(1, getattr(self.config, 'context_max_tokens', 1_000_000))
            _token_threshold = max(1, int(_context_max_tokens * (_threshold_pct / 100)))
            _pre_threshold = max(1, int(_token_threshold * _pre_ratio))
            _messages = self.pipeline.get_history(inbound.user_id, inbound.channel_id) if self.pipeline else []
            from antaris_agent.core.session import estimate_tokens
            _estimated_tokens = sum(estimate_tokens(m) for m in _messages)

            # Pre-compaction flush: save a session summary before hitting the full token threshold
            if (session is not None
                    and _estimated_tokens >= _pre_threshold
                    and not session.pre_compaction_flushed):
                session.pre_compaction_flushed = True
                asyncio.create_task(self._pre_compaction_flush(session))

            # Full compaction ping: send DM to owner at the token threshold
            if (session is not None
                    and _estimated_tokens >= _token_threshold
                    and not session.compaction_notified
                    and getattr(self.config, 'owner_user_id', '')):
                session.compaction_notified = True
                asyncio.create_task(self._send_compaction_ping(adapter, session))

            if result.success and result.response_text and session is not None:
                # Accumulate in conversation buffer (rolling window of 30 turns)
                session.add_to_buffer(inbound.user_id, inbound.text, result.response_text)

            if result.response_text:
                # ── Passive capability discovery ──────────────────────────
                # Occasionally append a capability hint to responses
                discovery_suffix = ""
                if hasattr(self, 'discovery') and self.discovery:
                    try:
                        hint = self.discovery.get_next_hint(
                            self.config,
                            message_count=session.message_count if session is not None else 0,
                        )
                        if hint:
                            from antaris_agent.core.discovery import format_hint_markdown
                            self.discovery.mark_shown(
                                hint.category,
                                message_count=session.message_count if session is not None else 0,
                            )
                            discovery_suffix = "\n\n---\n" + format_hint_markdown(hint)
                    except Exception as _disc_err:
                        logger.debug("Discovery hint check failed: %s", _disc_err)

                await adapter.send(
                    OutboundMessage(
                        channel_id=inbound.channel_id,
                        text=result.response_text + discovery_suffix,
                        reply_to=inbound.id,
                    )
                )
            if result.error:
                logger.error("Pipeline error for user=%s: %s", inbound.user_id, result.error)
            if result.failed_stages:
                logger.debug("Failed stages for user=%s: %s", inbound.user_id, result.failed_stages)
        return handle

    def _print_banner(self):
        """Log startup info."""
        memory_count = self._memory_count()
        channel_names = [type(c).__name__.replace("Adapter", "") for c in self._channels]

        logger.info(
            "Starting %s | memory=%d | guard=%s | model=%s via %s | channels=%s",
            self.config.bot_name, memory_count, self.config.guard_mode,
            self.config.model, self.config.provider_name, ", ".join(channel_names),
        )

        security_mode = getattr(self.config, "security_mode", "sandboxed")
        print(f"\n🤖 {self.config.bot_name} starting...")
        print(f"   Memory: {memory_count} entries")
        print(f"   Security: {security_mode} mode")
        print(f"   Guard: {self.config.guard_mode} mode")
        print(f"   Model: {self.config.model} via {self.config.provider_name}")
        print(f"   Channels: {', '.join(channel_names)}")
        if self.awakening.is_needed():
            logger.info("Identity: Awakening needed")
        else:
            logger.info("Identity: SOUL.md loaded")

    def _memory_count(self) -> int:
        try:
            return self.memory.stats().get("total", 0)
        except Exception:
            return 0

    def _on_auth_notification(self, message: str) -> None:
        """Handle auth rotation notifications — log to owner DM or active channel.
        
        Called synchronously from the auth monitor when a profile rotation
        or expiry event occurs. Schedules the async notification delivery.
        """
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self._deliver_auth_notification(message))
        except RuntimeError:
            # No running loop — just log it
            logger.info("Auth notification (no loop): %s", message.replace("\n", " | "))

    async def _deliver_auth_notification(self, message: str) -> None:
        """Deliver an auth notification to the operator.
        
        Tries in order:
          1. DM the owner via Discord
          2. Send to the active Discord channel
          3. Log only
        """
        owner_id = getattr(self.config, 'owner_user_id', '')
        
        # Try Discord DM to owner
        if owner_id:
            try:
                from antaris_agent.channels.discord import DiscordAdapter
                for adapter in self._channels:
                    if isinstance(adapter, DiscordAdapter) and hasattr(adapter, '_client') and adapter._client:
                        user = await adapter._client.fetch_user(int(owner_id))
                        if user:
                            await user.send(message)
                            logger.debug("Auth notification sent to owner DM")
                            return
            except Exception as e:
                logger.debug("Could not DM owner for auth notification: %s", e)
        
        # Try active Discord channel
        if self._active_discord_channel:
            try:
                from antaris_agent.channels.discord import DiscordAdapter
                for adapter in self._channels:
                    if isinstance(adapter, DiscordAdapter) and hasattr(adapter, '_client') and adapter._client:
                        channel = adapter._client.get_channel(int(self._active_discord_channel))
                        if channel:
                            await channel.send(message)
                            logger.debug("Auth notification sent to active channel")
                            return
            except Exception as e:
                logger.debug("Could not send auth notification to channel: %s", e)
        
        # Fallback: log only (already logged by _notify_operator in auth_monitor)
        logger.info("Auth notification (no delivery channel): %s", message[:200])

    def _build_conversation_summary(self, session=None) -> str:
        """Build a structured summary from recent conversation turns."""
        buffer = self._conversation_buffer if session is None else session.conversation_buffer
        if not buffer:
            return "(no conversation data available)"

        lines: list[str] = []
        lines.append("### Recent conversation summary\n")
        for _uid, user_msg, bot_resp in buffer:
            user_preview = user_msg[:150].replace("\n", " ")
            bot_preview = bot_resp[:150].replace("\n", " ")
            lines.append(f"- User: {user_preview}")
            lines.append(f"  Bot: {bot_preview}")
        return "\n".join(lines)

    async def _setup_discord_proactive_tool(self):
        """Setup Discord client for the Discord proactive tool."""
        if not self.tool_registry:
            return
        
        # Find Discord adapter (lazy import to avoid requiring discord.py at module level)
        discord_adapter = None
        try:
            from antaris_agent.channels.discord import DiscordAdapter as _DA
        except ImportError:
            _DA = None
        if _DA:
            for adapter in self._channels:
                if isinstance(adapter, _DA):
                    discord_adapter = adapter
                    break
        
        if not discord_adapter:
            return
        
        # Get Discord proactive tool
        discord_tool = self.tool_registry._native_tools.get('discord_proactive')
        if discord_tool and hasattr(discord_tool, 'set_discord_client'):
            # Wait for Discord to be ready
            await discord_adapter._ready.wait()
            # Set the client
            discord_tool.set_discord_client(discord_adapter._client)
            logger.info("Discord proactive tool configured with client")

    async def _pre_compaction_flush(self, session=None) -> None:
        """Save a session summary before context compaction occurs."""
        if session is None:
            logger.info(
                "Pre-compaction flush triggered for legacy session at message %d",
                self._message_count,
            )
        else:
            logger.info(
                "Pre-compaction flush triggered for session %s at message %d",
                session.session_id,
                session.message_count,
            )
        summary = self._build_conversation_summary(session)

        if self.memory:
            try:
                message_count = session.message_count if session is not None else self._message_count
                ingest_content = f"[Pre-compaction flush at message {message_count}]\n{summary}"
                bot_label = f"Session context saved before compaction (message {message_count})"
                await self.memory.ingest(
                    "system",
                    ingest_content,
                    bot_label,
                )
                logger.info("Pre-compaction summary ingested into memory")
            except Exception as e:
                logger.warning("Pre-compaction memory ingest failed: %s", e)

    async def _send_compaction_ping(self, adapter, session=None) -> None:
        """DM the owner when a session hits the compaction threshold."""
        owner_id = getattr(self.config, 'owner_user_id', '')
        if not owner_id:
            return
        session_id = session.session_id if session is not None else 'legacy'
        message_count = session.message_count if session is not None else self._message_count
        msg = (
            f"Context is getting long in session {session_id} ({message_count} messages). "
            "Consider starting a fresh session."
        )
        try:
            from antaris_agent.channels.discord import DiscordAdapter
            if isinstance(adapter, DiscordAdapter) and hasattr(adapter, '_client') and adapter._client:
                user = await adapter._client.fetch_user(int(owner_id))
                if user:
                    await user.send(msg)
                    logger.info("Sent compaction ping to owner %s", owner_id)
        except Exception as e:
            logger.warning("Could not send compaction DM: %s", e)

        # Persist compaction summary to memory regardless of DM success
        if self.memory:
            try:
                summary = self._build_conversation_summary(session)
                compaction_content = (
                    f"[Compaction at message {message_count}]\n{summary}"
                )
                compaction_label = f"Session compacted at message {message_count}"
                await self.memory.ingest(
                    "system",
                    compaction_content,
                    compaction_label,
                )
                logger.info("Compaction summary ingested into memory")
            except Exception as e:
                logger.warning("Compaction summary ingest failed: %s", e)
            return

        # Fallback: log only (no memory available)
        logger.warning("COMPACTION PING (no DM sent): %s", msg)
