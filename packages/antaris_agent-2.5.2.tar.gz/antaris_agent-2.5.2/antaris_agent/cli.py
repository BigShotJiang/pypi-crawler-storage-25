import argparse
import json
import os
import signal
import subprocess
import sys
from pathlib import Path

from antaris_agent._version import __version__ as VERSION


def _resolve_config_dir() -> Path:
    """Resolve the config directory, honoring ANTARIS_CONFIG_DIR env var."""
    env_dir = os.environ.get("ANTARIS_CONFIG_DIR")
    if env_dir:
        return Path(env_dir).expanduser().resolve()
    return Path.home() / ".antaris"


PID_FILE = _resolve_config_dir() / "bot.pid"


# ── Instance registry helpers ─────────────────────────────────────────────────

def _load_registry() -> dict:
    """Returns {name: config_dir_path_str} from ~/.antaris/.instances.json."""
    reg_path = Path.home() / ".antaris" / ".instances.json"
    if not reg_path.exists():
        return {}
    try:
        return json.loads(reg_path.read_text())
    except Exception:
        return {}


def _save_registry(reg: dict):
    reg_path = Path.home() / ".antaris" / ".instances.json"
    reg_path.parent.mkdir(parents=True, exist_ok=True)
    reg_path.write_text(json.dumps(reg, indent=2))


def _resolve_named_instance(name: str) -> str | None:
    """Returns config dir path for named instance, or None if not found."""
    reg = _load_registry()
    return reg.get(name)


def _is_instance_running(config_dir: str) -> tuple[bool, int | None]:
    """Checks if instance at config_dir is running. Returns (running, pid)."""
    pid_file = Path(config_dir) / "bot.pid"
    if not pid_file.exists():
        return False, None
    try:
        pid = int(pid_file.read_text().strip())
        os.kill(pid, 0)
        return True, pid
    except (ValueError, OSError, ProcessLookupError):
        return False, None


def _is_valid_snowflake(value: str) -> bool:
    """Discord snowflake: 17-19 digit integer string."""
    return value.isdigit() and 17 <= len(value) <= 19


def _write_pid():
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()))


def _read_pid() -> int | None:
    if not PID_FILE.exists():
        return None
    try:
        return int(PID_FILE.read_text().strip())
    except (ValueError, OSError):
        return None


def _clear_pid():
    try:
        PID_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _stop_bot() -> bool:
    """Send SIGTERM to the running bot. Returns True if stopped."""
    pid = _read_pid()
    if not pid:
        print("❌ No running bot found.")
        return False
    try:
        if sys.platform == "win32":
            # Windows: use taskkill for reliable process termination
            import subprocess
            subprocess.run(["taskkill", "/F", "/PID", str(pid)],
                          capture_output=True, check=True)
        else:
            os.kill(pid, signal.SIGTERM)
        _clear_pid()
        print(f"🛑 Bot stopped (PID {pid})")
        return True
    except (ProcessLookupError, OSError):
        print(f"⚠️  PID {pid} not found — was the bot already stopped?")
        _clear_pid()
        return False
    except subprocess.CalledProcessError:
        print(f"⚠️  PID {pid} could not be stopped.")
        _clear_pid()
        return False
    except PermissionError:
        print(f"❌ Permission denied stopping PID {pid}")
        return False


def _cmd_install_service() -> int:
    """Install Parsica Agent as a system service for 24/7 operation."""
    import platform
    import shutil
    system = platform.system()
    antaris_bin = shutil.which("antaris") or sys.executable.replace("python", "antaris")

    if system == "Linux":
        unit = f"""[Unit]
Description=Parsica Agent
After=network.target network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={antaris_bin} start --foreground
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
"""
        service_path = Path("/etc/systemd/system/parsica-agent.service")
        try:
            service_path.write_text(unit)
        except PermissionError:
            print("❌ Permission denied — run with sudo:")
            print(f"   sudo {' '.join(sys.argv)}")
            return 1
        import subprocess
        subprocess.run(["systemctl", "daemon-reload"], check=True)
        subprocess.run(["systemctl", "enable", "parsica-agent"], check=True)
        subprocess.run(["systemctl", "start", "parsica-agent"], check=True)
        print("✅ Parsica Agent installed as systemd service.")
        print("   Status:  sudo systemctl status parsica-agent")
        print("   Logs:    sudo journalctl -u parsica-agent -f")
        print("   Stop:    sudo systemctl stop parsica-agent")
        print("   Disable: sudo systemctl disable parsica-agent")
        return 0

    elif system == "Darwin":
        plist_label = "ai.antarisanalytics.parsica-agent"
        log_dir = Path.home() / ".antaris" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        plist = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{plist_label}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{antaris_bin}</string>
        <string>start</string>
        <string>--foreground</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log_dir}/antaris.log</string>
    <key>StandardErrorPath</key>
    <string>{log_dir}/antaris.log</string>
</dict>
</plist>
"""
        plist_dir = Path.home() / "Library" / "LaunchAgents"
        plist_dir.mkdir(parents=True, exist_ok=True)
        plist_path = plist_dir / f"{plist_label}.plist"
        plist_path.write_text(plist)
        import subprocess
        subprocess.run(["launchctl", "load", "-w", str(plist_path)], check=True)
        print("✅ Parsica Agent installed as launchd service.")
        print(f"   Logs:    tail -f {log_dir}/antaris.log")
        print(f"   Stop:    launchctl unload {plist_path}")
        print(f"   Remove:  antaris uninstall-service")
        return 0

    elif system == "Windows":
        print("⚠️  Windows service install is not yet supported.")
        print("   Workaround: add 'antaris start' to Task Scheduler → 'Run at logon'.")
        return 1

    else:
        print(f"❌ Unsupported platform: {system}")
        return 1


def _cmd_uninstall_service() -> int:
    """Remove the Parsica Agent system service."""
    import platform
    import subprocess
    system = platform.system()

    if system == "Linux":
        try:
            subprocess.run(["systemctl", "stop", "parsica-agent"], check=False)
            subprocess.run(["systemctl", "disable", "parsica-agent"], check=False)
            Path("/etc/systemd/system/parsica-agent.service").unlink(missing_ok=True)
            subprocess.run(["systemctl", "daemon-reload"], check=False)
            print("✅ parsica-agent systemd service removed.")
        except PermissionError:
            print("❌ Permission denied — run with sudo")
            return 1
        return 0

    elif system == "Darwin":
        plist_label = "ai.antarisanalytics.parsica-agent"
        plist_path = Path.home() / "Library" / "LaunchAgents" / f"{plist_label}.plist"
        if plist_path.exists():
            subprocess.run(["launchctl", "unload", "-w", str(plist_path)], check=False)
            plist_path.unlink()
            print("✅ parsica-agent launchd service removed.")
        else:
            print("⚠️  No service found to remove.")
        return 0

    else:
        print(f"❌ Unsupported platform: {system}")
        return 1


def _cmd_uninstall(remove_config: bool = False) -> int:
    """Uninstall antaris-agent from the current Python environment."""
    package = "antaris-agent"
    cmd = [sys.executable, "-m", "pip", "uninstall", "-y", package]
    print(f"🧹 Uninstalling {package}…")
    result = subprocess.run(cmd)
    if result.returncode == 0 and remove_config:
        config_dir = _resolve_config_dir()
        if config_dir.exists():
            import shutil
            shutil.rmtree(config_dir)
            print(f"🗑️  Removed config directory: {config_dir}")
    return result.returncode


def _cmd_reinstall() -> int:
    """Force-reinstall antaris-agent from PyPI."""
    package = "antaris-agent"
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "--force-reinstall", package]
    print(f"🔄 Reinstalling {package} from PyPI…")
    result = subprocess.run(cmd)
    if result.returncode == 0:
        print("✅ Reinstall complete.")
        print("   Run `antaris init` or `antaris setup` next.")
    return result.returncode


def _cmd_security_status():
    """Print current security configuration."""
    from antaris_agent.core.config import Config, DEFAULT_CONFIG_PATH
    config = Config.load()
    if not config:
        print("❌ Bot not initialized. Run 'antaris-agent init' first.")
        return
    security_mode = getattr(config, "security_mode", "sandboxed")
    guard_mode = getattr(config, "guard_mode", "monitor")

    mode_descriptions = {
        "open": "Open (0) — no restrictions, full access",
        "standard": "Standard (1) ★ — light safety net, workspace + home scoped (recommended)",
        "sandboxed": "Sandboxed (2) — filesystem restricted, subprocesses blocked",
        "secured": "Secured (3) — network allowlisted, destructive ops need approval",
        "encrypted": "Encrypted (4) — all tools need approval, owner-only memory, full audit",
        "locked": "Encrypted (4) — all tools need approval, owner-only memory, full audit",
    }

    print(f"\n🔐 Antaris Security Status")
    print(f"   Mode:         {mode_descriptions.get(security_mode, security_mode)}")
    print(f"   Guard:        {guard_mode}")
    print(f"   Memory store: {config.memory_store}")
    if security_mode == "locked":
        import os
        audit_path = os.path.expanduser("~/.antaris/audit.log")
        print(f"   Audit log:    {audit_path}")
        print(f"   Encryption:   Owner-only memory + audit enforcement (locked mode)")
    print(f"\n   CLI override: antaris-agent start --security {security_mode}")
    print()


def _cmd_tools(action: str):
    """Tool management commands — lightweight, no full Bot instantiation."""
    from antaris_agent.core.config import Config
    
    config = Config.load()
    if not config:
        print("❌ Bot not initialized. Run 'antaris init' first.")
        return
    
    tools_config = getattr(config, '_tools_config', {})
    
    if action == "list":
        print("\n🔧 Configured Tools\n")
        
        if not tools_config:
            print("   No tools configured in config.json")
            return
        
        # Show what WOULD be registered based on config (no Bot instantiation)
        tool_specs = {
            'brave_search': ('Web search via Brave Search API', lambda c: c.get('enabled') and c.get('apiKey')),
            'web_fetch': ('Fetch and extract readable content from URLs', lambda c: c.get('enabled', False)),
            'browser': ('Browser automation via Playwright', lambda c: c.get('enabled')),
            'file_ops': ('File read/write/edit operations', lambda c: c.get('enabled')),
            'shell': ('Execute shell commands', lambda c: c.get('enabled')),
            'video': ('Video understanding via ffmpeg/whisper + LLM summaries/Q&A', lambda c: c.get('enabled')),
        }
        
        registered = []
        for tool_name, (desc, check_fn) in tool_specs.items():
            tool_cfg = tools_config.get(tool_name, {})
            if check_fn(tool_cfg):
                registered.append((tool_name, desc))
        
        # Check MCP servers
        mcp_servers = tools_config.get('mcp_servers', [])
        
        if not registered and not mcp_servers:
            print("   No tools enabled")
        else:
            if registered:
                print(f"   Native tools ({len(registered)}):")
                for name, desc in registered:
                    print(f"     • {name} — {desc}")
            if mcp_servers:
                print(f"\n   MCP servers ({len(mcp_servers)}):")
                for server in mcp_servers:
                    transport = server.get('transport', 'stdio')
                    print(f"     • {server['name']} ({transport})")
        
    elif action == "status":
        print("\n🔧 Tool Configuration Status\n")
        
        if not tools_config:
            print("   No tools configured in config.json")
            print("\n   Add to config.json:")
            print('   "tools": {')
            print('     "brave_search": {"enabled": true, "apiKey": "your-key"},')
            print('     "web_fetch": {"enabled": true},')
            print('     "browser": {"enabled": false}')
            print('   }')
        else:
            for tool, config_data in tools_config.items():
                if tool == 'mcp_servers':
                    # Handle MCP servers list separately
                    print(f"   MCP servers: {len(config_data)} configured")
                    for server in config_data:
                        print(f"     • {server.get('name', 'unnamed')} ({server.get('transport', 'stdio')})")
                    continue
                enabled = config_data.get('enabled', False)
                status = "✅ enabled" if enabled else "⚪ disabled"
                if tool == 'brave_search':
                    has_key = bool(config_data.get('apiKey'))
                    if enabled and not has_key:
                        status = "❌ enabled but missing apiKey"
                print(f"     • {tool}: {status}")

def _cmd_doctor():
    """Run diagnostic checks and print honest status report."""
    import os
    import sys
    from pathlib import Path

    print("\n🩺 Antaris Agent Doctor\n")
    ok = True

    # --- Config ---
    from antaris_agent.core.config import Config, resolve_config_path
    config_path = resolve_config_path()
    cfg = Config.load(str(config_path))
    if cfg:
        print(f"  Config:           ✅ loaded from {config_path}")
    else:
        print(f"  Config:           ❌ not found — run 'antaris init'")
        ok = False

    # --- Provider ---
    if cfg:
        provider = cfg.provider_name or "unknown"
        model = cfg.model or "unknown"
        print(f"  Provider:         ✅ {provider} ({model})")
    else:
        print(f"  Provider:         ❌ no config loaded")
        ok = False

    # --- Memory store writable ---
    if cfg:
        store = Path(cfg.memory_store)
        if store.exists() and os.access(str(store), os.W_OK):
            print(f"  Memory store:     ✅ writable ({store})")
        elif store.exists():
            print(f"  Memory store:     ❌ not writable ({store})")
            ok = False
        else:
            # Directory doesn't exist yet — check if parent is writable
            parent = store.parent
            if parent.exists() and os.access(str(parent), os.W_OK):
                print(f"  Memory store:     ✅ will be created ({store})")
            else:
                print(f"  Memory store:     ❌ cannot create ({store})")
                ok = False
    else:
        print(f"  Memory store:     ❌ no config loaded")

    # --- Security mode ---
    security_mode = getattr(cfg, 'security_mode', 'sandboxed') if cfg else 'unknown'
    print(f"  Security mode:    {security_mode}")

    # --- Encryption (honest reporting) ---
    print(f"  Encryption:")

    # Key package (cryptography)
    try:
        import cryptography  # noqa: F401
        print(f"    Key package:    ✅ cryptography installed")
        has_crypto = True
    except ImportError:
        print(f"    Key package:    ❌ cryptography not installed")
        has_crypto = False

    # Key loaded (only meaningful in encrypted mode)
    if security_mode == "encrypted":
        if os.environ.get("ANTARISBOT_MEMORY_KEY"):
            print(f"    Key loaded:     ✅ from ANTARISBOT_MEMORY_KEY env var")
        else:
            try:
                import keyring
                stored = keyring.get_password("antaris-agent", "memory-key")
                if stored:
                    print(f"    Key loaded:     ✅ from keyring")
                else:
                    print(f"    Key loaded:     ❌ no key in keyring (run agent to set up)")
            except ImportError:
                print(f"    Key loaded:     ❌ keyring not installed (pip install antaris-agent[secure-store])")
            except Exception as _ke:
                print(f"    Key loaded:     ❌ keyring error: {_ke}")
    else:
        print(f"    Key loaded:     — not in encrypted mode")

    # Data-at-rest encryption — HONEST: not yet implemented
    print(f"    Data-at-rest:   ❌ not yet implemented")

    # --- Audit hook ---
    if hasattr(sys, 'addaudithook'):
        print(f"  Audit hook:       ✅ installable")
    else:
        print(f"  Audit hook:       ❌ sys.addaudithook not available")

    # --- Optional channel dependencies ---
    print(f"  Channels:")

    # Discord
    try:
        import discord  # noqa: F401
        print(f"    Discord:        ✅ discord.py installed")
    except ImportError:
        print(f"    Discord:        ❌ discord.py not installed")

    # Telegram
    try:
        import telegram  # noqa: F401
        print(f"    Telegram:       ✅ python-telegram-bot installed")
    except ImportError:
        print(f"    Telegram:       ❌ python-telegram-bot not installed")

    # Slack
    try:
        import slack_bolt  # noqa: F401
        print(f"    Slack:          ✅ slack-bolt installed")
    except ImportError:
        print(f"    Slack:          ❌ slack-bolt not installed")

    # --- Overall ---
    print()
    if ok:
        print(f"  Overall: ✅ Ready to start")
    else:
        print(f"  Overall: ❌ Issues found — fix the above and retry")
    print()


def main():
    # Detect invocation name
    prog = os.path.basename(sys.argv[0])
    if prog != "antaris":
        prog = "antaris"

    parser = argparse.ArgumentParser(
        prog=prog,
        description="Antaris — Personal AI assistant powered by antaris-suite",
        epilog=(
            "Popular commands:\n"
            "  antaris init                 First-time setup wizard\n"
            "  antaris start --terminal     Run in terminal-only mode\n"
            "  antaris status               Show bot status\n"
            "  antaris doctor               Check config + dependencies\n"
            "  antaris tools list           Discover enabled tools\n"
            "  antaris memory stats         Inspect memory usage\n"
            "  antaris setup                Launch browser setup wizard\n\n"
            "Discovery tips:\n"
            "  In chat, use !help / !models / !memory help / !agents\n"
            "  In CLI, use '<command> --help' for deeper command help\n"
            "\n"
            "Config directory: ~/.antaris (override with --config-dir or ANTARIS_CONFIG_DIR)."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"{prog} {VERSION}")
    parser.add_argument(
        "--config-dir",
        default=None,
        metavar="DIR",
        help="Config directory (default: ~/.antaris or $ANTARIS_CONFIG_DIR)",
    )

    subparsers = parser.add_subparsers(dest="command")

    # init
    parser_init = subparsers.add_parser("init", help="Create config directory and blank skeleton")
    parser_init.add_argument("--name", default=None, metavar="NAME", help="Named instance (registers in ~/.antaris/.instances.json)")

    # start
    start_parser = subparsers.add_parser("start", help="Launch the bot")
    start_parser.add_argument("--name", default=None, metavar="NAME", help="Named instance to start (from registry)")
    start_parser.add_argument("--terminal", action="store_true", help="Terminal mode only")
    start_parser.add_argument("--debug", action="store_true", help="Verbose logging")
    start_parser.add_argument("--daemon", "-d", action="store_true", help="Run in background (daemonize)")
    start_parser.add_argument("--foreground", action="store_true", help="Stay in foreground (default without --daemon)")
    start_parser.add_argument(
        "--security",
        choices=["open", "standard", "sandboxed", "secured", "encrypted"],
        default=None,
        metavar="MODE",
        help="Security mode: open (no restrictions), sandboxed (default, recommended), standard (more capability), secured/encrypted (approval gates + audit logging)",
    )

    # stop
    stop_parser = subparsers.add_parser("stop", help="Stop the running bot")
    stop_parser.add_argument("name", nargs="?", default=None, metavar="NAME", help="Named instance to stop (optional)")

    # pulse
    subparsers.add_parser("pulse", help="System health check — verify all components before launch")

    # restart
    restart_parser = subparsers.add_parser("restart", help="Restart the bot")
    restart_parser.add_argument("name", nargs="?", default=None, metavar="NAME", help="Named instance to restart (optional)")

    # fleet
    subparsers.add_parser("fleet", help="List all registered Parsica Agent instances and their status")

    # chat
    subparsers.add_parser("chat", help="Direct terminal conversation")

    # status
    subparsers.add_parser("status", help="Show bot status")

    # config
    config_parser = subparsers.add_parser("config", help="View or edit configuration")
    config_parser.add_argument("action", nargs="?", choices=["show", "set", "add", "telegram-token", "slack-token", "open-channel"])
    config_parser.add_argument("key", nargs="?")
    config_parser.add_argument("value", nargs="?")

    # memory
    mem_parser = subparsers.add_parser(
        "memory",
        help="Inspect and search the memory system",
        description=(
            "Memory inspection and export commands.\n\n"
            "Examples:\n"
            "  antaris memory stats\n"
            "  antaris memory search deployment\n"
            "  antaris memory export"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    mem_parser.add_argument("action", nargs="?", choices=["stats", "search", "export", "import", "prune"], help="stats/search/export/import/prune")
    mem_parser.add_argument("query", nargs="?", help="search query or output path, depending on action")

    # guard
    guard_parser = subparsers.add_parser("guard", help="Guard policy management")
    guard_parser.add_argument("action", nargs="?", choices=["status", "mode", "test"])
    guard_parser.add_argument("value", nargs="?")

    # persona
    persona_parser = subparsers.add_parser("persona", help="Persona management")
    persona_parser.add_argument("action", nargs="?", choices=["show", "edit", "reset"])

    # migrate
    migrate_parser = subparsers.add_parser("migrate", help="Import from another bot framework")
    migrate_parser.add_argument(
        "--from", dest="source",
        choices=["openclaw", "mem0", "langchain", "lancedb", "custom"],
    )
    migrate_parser.add_argument("--path")
    migrate_parser.add_argument("--dry-run", action="store_true")
    migrate_parser.add_argument("--user-id", dest="user_id", default=None,
        help="Discord user ID to assign imported memories to")
    migrate_parser.add_argument("--all", dest="import_all", action="store_true",
        help="Non-interactive: import everything without prompts")

    # export
    export_parser = subparsers.add_parser("export", help="Export bot data to a portable format")
    export_parser.add_argument("--full", action="store_true",
        help="Export everything (identity + config + memories)")
    export_parser.add_argument("--memories-only", action="store_true",
        help="Export memories only as JSONL")
    export_parser.add_argument("--identity-only", action="store_true",
        help="Export identity markdown files only")
    export_parser.add_argument("--output", default=None,
        help="Output path (file for --memories-only, directory otherwise)")

    # logs
    logs_parser = subparsers.add_parser("logs", help="View bot logs")
    logs_parser.add_argument("--follow", "-f", action="store_true", help="Stream new log lines (like tail -f)")
    logs_parser.add_argument("--tail", "-n", type=int, default=50, metavar="N", help="Number of lines to show (default: 50)")
    logs_parser.add_argument("--level", "-l", choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], metavar="LEVEL", help="Filter to only show lines at or above this level (e.g. ERROR)")

    # setup
    setup_parser = subparsers.add_parser("setup", help="Run the web setup wizard")
    setup_parser.add_argument("--no-browser", action="store_true", help="Don't open browser automatically")
    setup_parser.add_argument(
        "--wizard",
        choices=["general", "integrations", "automation", "power", "all"],
        default="all",
        help="Open a specific setup wizard for re-entry (default: all)",
    )

    # update
    update_parser = subparsers.add_parser("update", help="Update antaris-agent to the latest version")
    update_parser.add_argument(
        "--check", action="store_true",
        help="Check for updates without installing"
    )

    # install-service / uninstall-service
    subparsers.add_parser("install-service", help="Install Parsica Agent as a system service (systemd on Linux, launchd on macOS)")
    subparsers.add_parser("uninstall-service", help="Remove the Parsica Agent system service")

    # uninstall / reinstall
    uninstall_parser = subparsers.add_parser("uninstall", help="Uninstall antaris-agent from this Python environment")
    uninstall_parser.add_argument("--remove-config", action="store_true", help="Also remove the ~/.antaris config directory")
    subparsers.add_parser("reinstall", help="Force-reinstall antaris-agent from PyPI")

    # security
    parser_security = subparsers.add_parser("security", help="Show security status")
    parser_security.add_argument("action", nargs="?", default="status", choices=["status"])

    # doctor
    subparsers.add_parser("doctor", help="Check bot configuration and dependencies")

    # tools
    tools_parser = subparsers.add_parser(
        "tools",
        help="Discover and inspect enabled tools",
        description=(
            "Inspect Antaris tool availability.\n\n"
            "Examples:\n"
            "  antaris tools list\n"
            "  antaris tools status"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tools_parser.add_argument("action", nargs="?", default="list", 
                             choices=["list", "status"], 
                             help="list = show enabled tools, status = show tool configuration state")

    args = parser.parse_args()

    # Allow reassignment of the module-level PID_FILE throughout this function
    global PID_FILE

    # Apply --config-dir override before any command runs.
    # This sets the env var so that Config, pulse, and PID_FILE all pick it up.
    if getattr(args, "config_dir", None):
        os.environ["ANTARIS_CONFIG_DIR"] = str(Path(args.config_dir).expanduser().resolve())
        # Re-resolve module-level defaults that were computed at import time
        PID_FILE = _resolve_config_dir() / "bot.pid"

    if args.command is None:
        parser.print_help()
        return

    # ── Commands ─────────────────────────────────────────────────────────────

    if args.command == "init":
        from antaris_agent.core.config import run_init_create
        name = getattr(args, "name", None)
        if name:
            config_dir = Path.home() / ".antaris" / "instances" / name
            run_init_create(str(config_dir))
            reg = _load_registry()
            reg[name] = str(config_dir)
            _save_registry(reg)
            print(f"   Instance '{name}' registered.")
        else:
            run_init_create()

    elif args.command == "setup":
        from antaris_agent.setup.wizard import SetupWizard
        wizard_name = getattr(args, "wizard", "all") or "all"
        no_browser = getattr(args, "no_browser", False)
        wiz = SetupWizard()
        wiz.run(wizard=wizard_name, open_browser=not no_browser)
        print(f"\n   Config: ~/.antaris/config.json")

    elif args.command == "start":
        import atexit
        # Resolve named instance before PID check
        _instance_name = getattr(args, "name", None)
        if _instance_name and not getattr(args, "config_dir", None):
            _named_dir = _resolve_named_instance(_instance_name)
            if _named_dir:
                os.environ["ANTARIS_CONFIG_DIR"] = _named_dir
                PID_FILE = Path(_named_dir) / "bot.pid"
            else:
                print(f"❌ Instance '{_instance_name}' not found. Run 'antaris init --name {_instance_name}' first.")
                sys.exit(1)
        # Guard: prevent multiple instances
        existing_pid = _read_pid()
        if existing_pid:
            try:
                # os.kill(pid, 0) is Unix-only; use cross-platform process check
                if sys.platform == "win32":
                    import ctypes
                    kernel32 = ctypes.windll.kernel32
                    handle = kernel32.OpenProcess(0x1000, False, existing_pid)  # PROCESS_QUERY_LIMITED_INFORMATION
                    if handle:
                        kernel32.CloseHandle(handle)
                        _is_alive = True
                    else:
                        _is_alive = False
                else:
                    os.kill(existing_pid, 0)
                    _is_alive = True
                if _is_alive:
                    print(f"⚠️  Bot is already running (PID {existing_pid}).")
                    print(f"   Run 'antaris stop' first, or 'antaris restart'.")
                    sys.exit(1)
                else:
                    _clear_pid()  # stale PID file — clear and continue
            except (ProcessLookupError, OSError):
                _clear_pid()  # stale PID file — clear and continue
        _write_pid()
        atexit.register(_clear_pid)
        from antaris_agent.core.config import Config
        config = Config.load()

        # ── Security mode ─────────────────────────────────────────────
        # v2.5: Security prompt REMOVED from startup. Defaults to Standard (1).
        # Users change security via 'antaris setup' wizard or config.json directly.
        _selected_security = getattr(args, "security", None)
        if not _selected_security:
            _selected_security = getattr(config, "security_mode", "standard") if config else "standard"
        if config:
            config.security_mode = _selected_security

        # ── Daemonize if requested ───────────────────────────────────
        _daemon_mode = getattr(args, "daemon", False)
        if _daemon_mode and not getattr(args, "foreground", False):
            import platform as _plat
            if _plat.system() != "Windows":
                _log_dir = _resolve_config_dir() / "logs"
                _log_dir.mkdir(parents=True, exist_ok=True)
                _log_file = _log_dir / "antaris.log"
                print(f"🛡️  Security: {_selected_security}")
                print(f"🚀 Daemonizing... logs at {_log_file}")
                # First fork
                pid = os.fork()
                if pid > 0:
                    print(f"✅ Bot running in background (PID {pid})")
                    sys.exit(0)
                # Decouple from parent
                os.setsid()
                os.umask(0o077)
                # Second fork
                pid2 = os.fork()
                if pid2 > 0:
                    sys.exit(0)
                # Redirect stdio to log
                sys.stdout.flush()
                sys.stderr.flush()
                _lf = open(_log_file, "a")
                os.dup2(_lf.fileno(), sys.stdout.fileno())
                os.dup2(_lf.fileno(), sys.stderr.fileno())
                _devnull = open(os.devnull, "r")
                os.dup2(_devnull.fileno(), sys.stdin.fileno())
                # Re-write PID after fork
                _clear_pid()
                _write_pid()
            else:
                print("⚠️  --daemon not supported on Windows. Running in foreground.")

        from antaris_agent.core.bot import Bot
        bot = Bot()
        if bot.config:
            bot.config.security_mode = _selected_security
        if not _daemon_mode:
            print(f"🛡️  Security: {_selected_security}")
        bot.start(terminal_only=getattr(args, 'terminal', False))

    elif args.command == "stop":
        _stop_name = getattr(args, "name", None)
        if _stop_name:
            _stop_dir = _resolve_named_instance(_stop_name)
            if _stop_dir:
                PID_FILE = Path(_stop_dir) / "bot.pid"
            else:
                print(f"❌ Instance '{_stop_name}' not found. Run 'antaris init --name {_stop_name}' first.")
                sys.exit(1)
        _stop_bot()

    elif args.command == "pulse":
        import asyncio as _asyncio
        from antaris_agent.core.pulse import run_pulse
        report = _asyncio.run(run_pulse())
        print(report.summary())
        if not report.passed():
            sys.exit(1)

    elif args.command == "restart":
        _restart_name = getattr(args, "name", None)
        if _restart_name:
            _restart_dir = _resolve_named_instance(_restart_name)
            if _restart_dir:
                PID_FILE = Path(_restart_dir) / "bot.pid"
            else:
                print(f"❌ Instance '{_restart_name}' not found. Run 'antaris init --name {_restart_name}' first.")
                sys.exit(1)
        print("🔄 Restarting bot...")
        _stop_bot()
        import time, subprocess
        time.sleep(1.5)
        _restart_cmd = [sys.argv[0], "start"]
        if _restart_name:
            _restart_cmd += ["--name", _restart_name]
        subprocess.Popen(_restart_cmd)
        print("✅ Bot restarting.")

    elif args.command == "fleet":
        reg = _load_registry()
        # Default instance always listed first
        instances = {"(default)": str(_resolve_config_dir())}
        instances.update(reg)
        print(f"\n{'NAME':<16} {'STATUS':<10} {'PID':<8} {'CONFIG DIR'}")
        print("-" * 70)
        for _fname, _cdir in instances.items():
            _running, _pid = _is_instance_running(_cdir)
            _status = "running" if _running else "stopped"
            _pid_str = str(_pid) if _pid else "-"
            _short_dir = _cdir.replace(str(Path.home()), "~")
            print(f"{_fname:<16} {_status:<10} {_pid_str:<8} {_short_dir}")
        print()

    elif args.command == "chat":
        from antaris_agent.core.bot import Bot
        Bot().chat()

    elif args.command == "status":
        from antaris_agent.core.config import Config
        cfg = Config.load()
        if cfg:
            pid = _read_pid()
            status = f"Running (PID {pid})" if pid else "Stopped"
            print(f"🤖 {cfg.bot_name}")
            print(f"   Status: {status}")
            print(f"   Provider: {cfg.provider_name} / {cfg.model}")
            open_ch = cfg.discord_open_channels
            print(f"   Open channels: {len(open_ch)} configured")
        else:
            print("❌ Not initialized. Run 'antaris init' first.")

    elif args.command == "config":
        from antaris_agent.core.config import Config
        cfg = Config.load()
        if not cfg:
            print("❌ Not initialized. Run 'antaris init' first.")
            return
        action = getattr(args, 'action', None) or 'show'
        if action == 'show' or not action:
            import json
            with open(cfg.config_path) as f:
                print(json.dumps(json.load(f), indent=2))
        elif action == 'set':
            key = getattr(args, 'key', None)
            value = getattr(args, 'value', None)
            if not key or not value:
                print("Usage: antaris config set <key> <value>")
                return
            # Simple key=value setter for top-level provider fields
            if key == 'model':
                cfg.model = value
                cfg.save()
                print(f"✅ Model set to {value}")
            elif key == 'open-channel':
                channel_id = value
                if not _is_valid_snowflake(channel_id):
                    print(f"❌ Invalid channel ID '{channel_id}'. Discord channel IDs are 17-19 digit numbers.")
                    sys.exit(1)
                if channel_id not in (cfg.discord_open_channels or []):
                    cfg.discord_open_channels = (cfg.discord_open_channels or []) + [channel_id]
                    cfg.save()
                    print(f"✅ Added {channel_id} as open channel (restart bot to apply)")
                else:
                    print(f"Already an open channel: {channel_id}")
            elif key == 'remove-channel':
                channels = cfg.discord_open_channels or []
                if value in channels:
                    channels.remove(value)
                    cfg.discord_open_channels = channels
                    cfg.save()
                    print(f"✅ Removed {value} from open channels")
                else:
                    print(f"Not an open channel: {value}")
            else:
                print(f"Unknown config key: {key}")
                print("Available: model, open-channel, remove-channel")
        elif action == 'telegram-token':
            token = getattr(args, 'key', None)
            if not token:
                print("Usage: antaris config telegram-token <token>")
                return
            cfg.telegram_token = token
            cfg.telegram_enabled = True
            cfg.save()
            print(f"✅ Telegram token set and Telegram enabled")

        elif action == 'slack-token':
            bot_token = getattr(args, 'key', None)
            app_token = getattr(args, 'value', None)
            if not bot_token or not app_token:
                print("Usage: antaris config slack-token <bot-token> <app-token>")
                print("  bot-token: xoxb-... (Bot User OAuth Token)")
                print("  app-token: xapp-... (App-Level Token for Socket Mode)")
                return
            cfg.slack_bot_token = bot_token
            cfg.slack_app_token = app_token
            cfg.slack_enabled = True
            cfg.save()
            print(f"✅ Slack tokens set and Slack enabled")

        elif action == 'open-channel':
            sub = getattr(args, 'key', None)
            channel_id = getattr(args, 'value', None)

            def _is_valid_snowflake(cid: str) -> bool:
                """A Discord snowflake is a 17-19 digit integer string."""
                return cid.isdigit() and 17 <= len(cid) <= 19

            if sub == 'list' or not sub:
                channels = cfg.discord_open_channels or []
                if not channels:
                    print("   (no open channels configured)")
                else:
                    print(f"   Open channels ({len(channels)}):")
                    for ch in channels:
                        print(f"   • {ch}")

            elif sub == 'add':
                if not channel_id:
                    print("Usage: antaris config open-channel add <channel_id>")
                    return
                if not _is_valid_snowflake(channel_id):
                    print(f"❌ '{channel_id}' does not look like a Discord snowflake (17-19 digits).")
                    return
                channels = list(cfg.discord_open_channels or [])
                if channel_id in channels:
                    print(f"⚠️  Channel {channel_id} is already in the open-channels list.")
                else:
                    channels.append(channel_id)
                    cfg.discord_open_channels = channels
                    cfg.save()
                    print(f"✅ Added {channel_id} to open channels. Restart bot to apply.")

            elif sub == 'remove':
                if not channel_id:
                    print("Usage: antaris config open-channel remove <channel_id>")
                    return
                channels = list(cfg.discord_open_channels or [])
                if channel_id not in channels:
                    print(f"⚠️  Channel {channel_id} not found in open-channels list.")
                else:
                    channels.remove(channel_id)
                    cfg.discord_open_channels = channels
                    cfg.save()
                    print(f"✅ Removed {channel_id} from open channels. Restart bot to apply.")

            else:
                print(f"Unknown open-channel sub-command: {sub}")
                print("Usage: antaris config open-channel add|remove|list [channel_id]")

    elif args.command == "persona":
        action = getattr(args, 'action', None) or 'show'
        soul_path = Path.home() / ".antaris" / "SOUL.md"
        if action == 'show':
            if soul_path.exists():
                print(soul_path.read_text())
            else:
                print("No SOUL.md found. Run 'antaris init' first.")
        elif action == 'edit':
            editor = os.environ.get("EDITOR", "nano")
            os.system(f"{editor} {soul_path}")
        elif action == 'reset':
            print("⚠️  This will erase the current persona and trigger awakening on next start.")
            confirm = input("Are you sure? (y/N): ").strip().lower()
            if confirm in ("y", "yes"):
                soul_path.write_text("AWAKENING_NEEDED\n")
                print("✅ SOUL.md reset. Next bot start will trigger awakening.")
            else:
                print("Cancelled.")

    elif args.command == "memory":
        action = getattr(args, 'action', None) or 'stats'
        from antaris_agent.core.config import Config
        cfg = Config.load()
        if not cfg:
            print("❌ Not initialized. Run 'antaris init' first.")
            return

        from antaris_agent.core.memory import BotMemory
        memory = BotMemory(
            store_path=cfg.memory_store,
            search_limit=cfg.memory_search_limit,
            min_relevance=cfg.memory_min_relevance,
        )

        if action == 'stats' or not action:
            # List all users and their memory counts
            store_path = __import__('pathlib').Path(cfg.memory_store)
            if not store_path.exists() or not any(store_path.iterdir()):
                print("📭 No memories stored yet.")
                return
            total = 0
            for user_dir in sorted(store_path.iterdir()):
                if user_dir.is_dir():
                    stats = memory.stats(user_dir.name)
                    count = stats.get('entry_count', 0)
                    total += count
                    print(f"   {user_dir.name[:20]}: {count} memories")
            print(f"\n   Total: {total} memories across {len(list(store_path.iterdir()))} user(s)")

        elif action == 'search':
            query = getattr(args, 'query', None)
            if not query:
                print("Usage: antaris memory search <query>")
                return
            # Search across all users
            import asyncio
            store_path = __import__('pathlib').Path(cfg.memory_store)
            found_any = False
            for user_dir in sorted(store_path.iterdir()):
                if not user_dir.is_dir():
                    continue
                results = asyncio.run(memory.recall(user_dir.name, query))
                if results:
                    found_any = True
                    print(f"\n[{user_dir.name[:20]}]")
                    for r in results[:5]:
                        print(f"  • {r[:120]}")
            if not found_any:
                print(f"No memories found for '{query}'")

        elif action == 'export':
            import json, asyncio
            output_file = getattr(args, 'query', None) or 'memory_export.json'
            store_path = __import__('pathlib').Path(cfg.memory_store)
            export = {}
            for user_dir in sorted(store_path.iterdir()):
                if user_dir.is_dir():
                    results = asyncio.run(memory.recall(user_dir.name, ""))
                    export[user_dir.name] = results
            with open(output_file, 'w') as f:
                json.dump(export, f, indent=2)
            print(f"✅ Exported to {output_file}")

        else:
            print(f"Unknown memory action: {action}")

    elif args.command == "guard":
        print("Guard commands coming in next phase.")

    elif args.command == "migrate":
        from pathlib import Path as P
        source = getattr(args, 'source', None)
        source_path = getattr(args, 'path', None)
        dry_run = getattr(args, 'dry_run', False)
        user_id = getattr(args, 'user_id', None) or "migrated-user"
        import_all = getattr(args, 'import_all', False)
        dest_path = str(P.home() / ".antaris")

        from antaris_agent.migration import (
            OpenClawMigration, Mem0Migration, CustomMigration,
            LangChainMigration, LanceDBMigration,
        )

        source_class_map = {
            "openclaw": OpenClawMigration,
            "mem0": Mem0Migration,
            "langchain": LangChainMigration,
            "lancedb": LanceDBMigration,
            "custom": CustomMigration,
        }

        if not source:
            # Interactive mode: scan all known locations
            print("🔍 Scanning for importable data...\n")
            found_sources = []
            scan_targets = [
                ("openclaw", P.home() / ".openclaw" / "workspace"),
                ("mem0", P.home()),
                ("langchain", P.home()),
                ("lancedb", P.home() / ".openclaw" / "memory"),
            ]
            for src_name, default_path in scan_targets:
                cls = source_class_map.get(src_name)
                if cls:
                    try:
                        m = cls(str(default_path), dest_path, dry_run=dry_run, user_id=user_id)
                        if m.detect():
                            found_sources.append((src_name, str(default_path), cls))
                            print(f"  ✅ {src_name} — found at {default_path}")
                    except Exception:
                        pass

            if not found_sources:
                print("No importable data found in default locations.")
                print("Use --from to specify a source: antaris migrate --from openclaw|mem0|langchain|lancedb|custom")
                return

            if not import_all:
                print(f"\nFound {len(found_sources)} source(s). Run with --all to import all, or specify --from <source>.")
                return

            # Import all found sources
            for src_name, src_path, cls in found_sources:
                print(f"\n📦 Migrating from {src_name}...")
                m = cls(src_path, dest_path, dry_run=dry_run, user_id=user_id)
                result = m.migrate()
                print(result.summary())
            if not dry_run:
                print("\n✅ Migration complete. Run 'antaris start' to launch.")
            return

        if not source_path:
            # Default paths per source
            defaults = {
                "openclaw": str(P.home() / ".openclaw" / "workspace"),
                "mem0": str(P.home()),
                "langchain": str(P.home()),
                "lancedb": str(P.home() / ".openclaw" / "memory"),
                "custom": "import.json",
            }
            source_path = defaults.get(source, ".")
            print(f"No --path given, trying default: {source_path}")

        MigrationClass = source_class_map.get(source)
        if not MigrationClass:
            print(f"Unknown source: {source}")
            return

        migrator = MigrationClass(
            source_path=source_path,
            dest_path=dest_path,
            dry_run=dry_run,
            user_id=user_id,
        )

        if not migrator.detect():
            print(f"❌ Could not detect {source} data at: {source_path}")
            print("   Check the path and try again.")
            return

        if dry_run:
            print(f"🔍 Dry run — nothing will be written\n")
        else:
            print(f"📦 Migrating from {source}...\n")

        result = migrator.migrate()
        print(result.summary())

        if result.success and not dry_run:
            print(f"\n✅ Migration complete.")
            print(f"   Run 'antaris start' to launch with your imported data.")
        elif dry_run:
            print(f"\n   Run without --dry-run to apply.")

    elif args.command == "export":
        from pathlib import Path as P
        from antaris_agent.migration.export import ExportManager

        full = getattr(args, 'full', False)
        memories_only = getattr(args, 'memories_only', False)
        identity_only = getattr(args, 'identity_only', False)
        output = getattr(args, 'output', None)

        # Default output paths
        timestamp = __import__('datetime').datetime.now().strftime('%Y%m%d_%H%M%S')
        if not output:
            if memories_only:
                output = str(P.home() / f"antaris_memories_{timestamp}.jsonl")
            else:
                output = str(P.home() / f"antaris_export_{timestamp}")

        exporter = ExportManager()

        if memories_only:
            print(f"📤 Exporting memories to {output}...")
            count = exporter.export_memories(output)
            print(f"✅ Exported {count} memory entries to {output}")

        elif identity_only:
            print(f"📤 Exporting identity files to {output}...")
            count = exporter.export_identity(output)
            print(f"✅ Exported {count} identity files to {output}")

        elif full or not (memories_only or identity_only):
            print(f"📤 Exporting full Antaris data to {output}...")
            summary = exporter.export_full(output)
            print(f"✅ Export complete at {output}")
            for key, val in summary.items():
                print(f"   {key}: {val}")
            print(f"\n   To re-import: antaris migrate --from custom --path {output}")

    elif args.command == "logs":
        import subprocess
        log_dir = Path.home() / ".antaris" / "logs"
        log_file = log_dir / "antaris-agent.log"
        if not log_file.exists():
            print("No log file found. Logs appear here when the bot runs in daemon mode.")
            print("For now, logs print to terminal when running 'antaris start'.")
            return

        follow = getattr(args, 'follow', False)
        tail_n = getattr(args, 'tail', 50)
        level_filter = getattr(args, 'level', None)

        if follow and not level_filter:
            # Pure streaming — delegate to tail -f
            subprocess.run(["tail", "-f", str(log_file)])
        elif follow and level_filter:
            # Stream + filter: tail -f piped through grep
            import shlex
            tail_proc = subprocess.Popen(["tail", "-f", str(log_file)], stdout=subprocess.PIPE)
            grep_proc = subprocess.Popen(
                ["grep", "--line-buffered", f"[{level_filter}]"],
                stdin=tail_proc.stdout,
            )
            try:
                grep_proc.wait()
            except KeyboardInterrupt:
                tail_proc.terminate()
                grep_proc.terminate()
        elif level_filter:
            # Static read — tail N lines then filter
            result = subprocess.run(
                ["tail", "-n", str(tail_n), str(log_file)],
                capture_output=True, text=True,
            )
            for line in result.stdout.splitlines():
                if f"[{level_filter}]" in line:
                    print(line)
        else:
            # Plain tail — configurable number of lines
            subprocess.run(["tail", "-n", str(tail_n), str(log_file)])

    elif args.command == "update":
        from antaris_agent.core.updater import Updater
        updater = Updater()
        check_only = getattr(args, "check", False)

        if check_only:
            available, installed, latest = updater.is_update_available()
            print(f"📦 Installed: v{installed}")
            if latest == installed:
                print("✅ You are up to date.")
            elif available:
                print(f"⬆️  Latest:    v{latest}")
                print(f"   Run `antaris update` to upgrade.")
            else:
                print(f"   Latest:    v{latest}")
                print("✅ You are up to date.")
        else:
            available, installed, latest = updater.is_update_available()
            if not available:
                print(f"✅ Antaris v{installed} is already up to date.")
            else:
                print(f"⬆️  Updating Antaris v{installed} → v{latest}…")
            success = updater.update()
            if success:
                print("✅ Update complete.")
                print("   Run `antaris restart` to apply the update.")
            else:
                print("❌ Update failed. Check the output above for details.")

    elif args.command == "uninstall":
        rc = _cmd_uninstall(remove_config=getattr(args, "remove_config", False))
        sys.exit(rc)

    elif args.command == "reinstall":
        rc = _cmd_reinstall()
        sys.exit(rc)

    elif args.command == "security":
        _cmd_security_status()

    elif args.command == "doctor":
        _cmd_doctor()

    elif args.command == "tools":
        _cmd_tools(getattr(args, "action", "list"))

    else:
        print(f"'{args.command}' — coming soon.")


if __name__ == "__main__":
    main()
