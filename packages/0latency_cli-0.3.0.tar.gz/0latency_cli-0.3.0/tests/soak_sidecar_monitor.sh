#\!/bin/bash
PID=1275115
LOG=/root/0latency-cli/tests/soak_sidecar.log
DB=/root/0latency-cli/.zerolatency.db

echo "Sidecar monitor started $(date -u +%FT%TZ)" > "$LOG"
echo "PID=$PID" >> "$LOG"

while ps -p $PID > /dev/null 2>&1; do
    RSS=$(ps -p $PID -o rss= | tr -d " ")
    RSS_MB=$((RSS / 1024))
    ATOMS=$(sqlite3 "$DB" "SELECT COUNT(*) FROM atoms WHERE agent_id='soak-test';" 2>/dev/null || echo "NA")
    echo "$(date -u +%FT%TZ) RSS=${RSS_MB}MB ATOMS=${ATOMS}" >> "$LOG"
    sleep 60
done

echo "Sidecar monitor ended $(date -u +%FT%TZ) - process $PID exited" >> "$LOG"
