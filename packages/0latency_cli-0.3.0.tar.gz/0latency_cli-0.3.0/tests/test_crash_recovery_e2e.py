"""End-to-end crash recovery test: kill -9 mid-session, verify atoms recovered."""

import os
import sys
import time
import signal
import json
from pathlib import Path
import pytest

from zerolatency_cli.recovery import (
    get_session_buffer_path,
    write_atom_to_buffer,
    detect_orphaned_sessions,
    import_session,
    cleanup_session_buffer,
)
from zerolatency_cli.atom import Atom


def test_crash_recovery_e2e_simulation():
    """
    Simulate crash-recovery flow:
    1. Write N atoms to buffer (simulating wrapper mid-session)
    2. Simulate kill -9 (buffer left behind)
    3. Detect orphaned session
    4. Verify N atoms can be read from buffer
    5. Cleanup
    
    NOTE: This simulates the crash but does not test actual import_session()
    which requires cloud credentials. It verifies the buffer survives and
    atoms are recoverable.
    """
    session_id = "test-crash-e2e"
    N = 30  # 30 atoms
    
    # Step 1: Simulate wrapper writing atoms
    atoms = []
    for i in range(N):
        atom = Atom(
            role="user" if i % 2 == 0 else "assistant",
            content=f"Turn {i}: test content",
            content_raw=f"Turn {i}: test content".encode(),
            timestamp=f"2026-05-09T18:00:{i:02d}Z",
            agent_id="crash-test",
            agent_name="crash-test",
        )
        write_atom_to_buffer(atom, session_id)
        atoms.append(atom)
    
    # Step 2: Simulate kill -9 (buffer file left behind)
    buffer_path = get_session_buffer_path(session_id)
    assert buffer_path.exists(), "Buffer should exist after write"
    
    # Make buffer stale (simulate time passing after crash)
    old_time = time.time() - 10
    os.utime(buffer_path, (old_time, old_time))
    
    # Step 3: Detect orphaned session
    orphaned = detect_orphaned_sessions()
    found = False
    atom_count_detected = 0
    
    for path, count in orphaned:
        if session_id in str(path):
            found = True
            atom_count_detected = count
            break
    
    assert found, f"Session {session_id} should be detected as orphaned"
    assert atom_count_detected == N, f"Expected {N} atoms, detected {atom_count_detected}"
    
    # Step 4: Verify all N atoms are readable from buffer (simulate import_session recovery)
    recovered_atoms = []
    with open(buffer_path, 'r') as f:
        for line in f:
            atom_dict = json.loads(line.strip())
            recovered_atoms.append(atom_dict)
    
    assert len(recovered_atoms) == N, f"Expected {N} atoms in buffer, found {len(recovered_atoms)}"
    
    # Verify no duplicates (all unique)
    contents = [a['content'] for a in recovered_atoms]
    assert len(contents) == len(set(contents)), "Recovered atoms should have no duplicates"
    
    # Verify order preserved
    for i, recovered in enumerate(recovered_atoms):
        expected_content = f"Turn {i}: test content"
        assert recovered['content'] == expected_content, f"Atom {i} content mismatch"
    
    # Step 5: Cleanup
    cleanup_session_buffer(session_id)
    assert not buffer_path.exists(), "Buffer should be deleted after cleanup"
    
    print(f"\nCRASH RECOVERY E2E VERIFIED:")
    print(f"  - {N} atoms written to buffer")
    print(f"  - Orphaned session detected ({atom_count_detected} atoms)")
    print(f"  - All {N} atoms recovered from buffer")
    print(f"  - No duplicates, order preserved")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
