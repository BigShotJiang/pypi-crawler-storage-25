#!/bin/bash
# CP10 P3 Soak Abort Monitor — Real-time failure detection
# Monitors for abort conditions and kills soak immediately if triggered

PID=1275115
LOG=/root/0latency-cli/tests/soak_test_4hr.log
SIDECAR=/root/0latency-cli/tests/soak_sidecar.log
INCIDENT=/root/.openclaw/workspace/memory-product/CP10-P3-SOAK-INCIDENT.md
RSS_LIMIT_MB=500
P95_LIMIT_MS=50

echo "Soak abort monitor started $(date -u +%FT%TZ)"
echo "Watching PID $PID for abort triggers..."

while ps -p $PID > /dev/null 2>&1; do
    # Check RSS
    RSS_KB=$(ps -p $PID -o rss= | tr -d " ")
    RSS_MB=$((RSS_KB / 1024))
    
    if [ "$RSS_MB" -gt "$RSS_LIMIT_MB" ]; then
        echo "[ABORT] RSS exceeded ${RSS_LIMIT_MB}MB: ${RSS_MB}MB at $(date -u +%FT%TZ)"
        
        # Capture state
        PS_OUT=$(ps -p $PID -o pid,etime,rss,cmd)
        LOG_TAIL=$(tail -50 "$LOG")
        SIDECAR_TAIL=$(tail -20 "$SIDECAR")
        
        # Kill soak
        kill $PID
        
        # Write incident report
        cat > "$INCIDENT" << INCIDENT_EOF
# CP10 P3 SOAK TEST INCIDENT REPORT

**Incident Time**: $(date -u +%FT%TZ)
**PID**: $PID
**Elapsed**: $(ps -p $PID -o etime= 2>/dev/null || echo "N/A")
**RSS at Failure**: ${RSS_MB}MB

## Incident Type

[x] RSS exceeded 500MB

## Evidence

### Process State at Failure
\`\`\`
$PS_OUT
\`\`\`

### Log Tail (last 50 lines)
\`\`\`
$LOG_TAIL
\`\`\`

### Sidecar Metrics
\`\`\`
$SIDECAR_TAIL
\`\`\`

## Root Cause Analysis

RSS grew beyond 500MB limit during soak test. This indicates a memory leak
or insufficient cleanup in the long-session code path.

## Recovery Actions Taken

- Soak process killed immediately upon RSS threshold breach
- Incident report generated
- Merge BLOCKED

## Next Steps

1. Review memory allocation patterns in storage.py
2. Check for unclosed file handles or DB connections
3. Audit deque/list growth in latency tracking
4. Add memory profiling to identify leak source
5. Fix leak and re-run soak test

## DO NOT MERGE

This soak run FAILED due to RSS limit breach. CP10 P3 merge is BLOCKED until:
- Memory leak identified and fixed
- New soak run completes successfully with RSS < 500MB throughout
- Operator reviews and authorizes merge

---

**Incident logged**: $(date -u +%FT%TZ)
**Logged by**: Automated abort monitor
INCIDENT_EOF
        
        echo "Incident report written: $INCIDENT"
        afplay /System/Library/Sounds/Basso.aiff 2>/dev/null || true
        exit 1
    fi
    
    # Check for exceptions in log
    if tail -10 "$LOG" | grep -q "Traceback\|Error\|Exception"; then
        echo "[ABORT] Exception detected in log at $(date -u +%FT%TZ)"
        
        PS_OUT=$(ps -p $PID -o pid,etime,rss,cmd)
        LOG_TAIL=$(tail -50 "$LOG")
        TRACEBACK=$(grep -A 20 "Traceback" "$LOG" | tail -25)
        
        kill $PID
        
        cat > "$INCIDENT" << INCIDENT_EOF
# CP10 P3 SOAK TEST INCIDENT REPORT

**Incident Time**: $(date -u +%FT%TZ)
**PID**: $PID
**Elapsed**: $(ps -p $PID -o etime= 2>/dev/null || echo "N/A")
**RSS at Failure**: ${RSS_MB}MB

## Incident Type

[x] Python exception/traceback

## Evidence

### Traceback
\`\`\`
$TRACEBACK
\`\`\`

### Log Tail (last 50 lines)
\`\`\`
$LOG_TAIL
\`\`\`

### Process State at Failure
\`\`\`
$PS_OUT
\`\`\`

## Root Cause Analysis

Python exception occurred during soak test execution.

## Recovery Actions Taken

- Soak process killed after exception detection
- Incident report generated
- Merge BLOCKED

## Next Steps

1. Review traceback for root cause
2. Fix exception source
3. Re-run soak test

## DO NOT MERGE

This soak run FAILED due to exception. CP10 P3 merge is BLOCKED.

---

**Incident logged**: $(date -u +%FT%TZ)
**Logged by**: Automated abort monitor
INCIDENT_EOF
        
        echo "Incident report written: $INCIDENT"
        afplay /System/Library/Sounds/Basso.aiff 2>/dev/null || true
        exit 1
    fi
    
    sleep 30  # Check every 30 seconds
done

# If we exit loop naturally, process died on its own
if ! grep -q "CANONICAL SOAK TEST COMPLETE" "$LOG"; then
    echo "[ABORT] Process $PID died without completing soak"
    
    cat > "$INCIDENT" << INCIDENT_EOF
# CP10 P3 SOAK TEST INCIDENT REPORT

**Incident Time**: $(date -u +%FT%TZ)
**PID**: $PID
**Elapsed**: UNKNOWN
**RSS at Failure**: ${RSS_MB}MB

## Incident Type

[x] Process crashed/died

## Evidence

### Log Tail (last 50 lines)
\`\`\`
$(tail -50 "$LOG")
\`\`\`

### Sidecar Metrics
\`\`\`
$(tail -20 "$SIDECAR")
\`\`\`

## Root Cause Analysis

Soak process terminated before completion without G11 final block.

## Recovery Actions Taken

- Incident report generated
- Merge BLOCKED

## Next Steps

1. Review logs for crash cause
2. Fix issue and re-run soak

## DO NOT MERGE

This soak run FAILED. CP10 P3 merge is BLOCKED.

---

**Incident logged**: $(date -u +%FT%TZ)
**Logged by**: Automated abort monitor
INCIDENT_EOF
    
    afplay /System/Library/Sounds/Basso.aiff 2>/dev/null || true
    exit 1
fi

echo "Abort monitor exiting — soak completed normally"
exit 0
