# CP10 P3 CANONICAL SOAK COMPLETION CHECKLIST

**Start Time**: 2026-05-09 18:45:34 UTC
**Expected Completion**: ~2026-05-09 22:45 UTC (4 hours)
**PID**: 1275115
**Log File**: `/root/0latency-cli/tests/soak_test_4hr.log`
**Sidecar Log**: `/root/0latency-cli/tests/soak_sidecar.log`

## Progress Milestones

| Milestone | ETA (UTC) | Atoms | Expected Log Output |
|-----------|-----------|-------|---------------------|
| First progress | ~19:45 | 100 | `[100/400] Elapsed: 1.00h, RSS: XXmb, p95 latency: XXms` |
| Second progress | ~20:45 | 200 | `[200/400] Elapsed: 2.00h, RSS: XXmb, p95 latency: XXms` |
| Third progress | ~21:45 | 300 | `[300/400] Elapsed: 3.00h, RSS: XXmb, p95 latency: XXms` |
| Final progress | ~22:45 | 400 | `[400/400]` + final report block |

**Note**: Progress prints every 100 atoms (~60min intervals). No output before 19:45 is EXPECTED behavior.

## G11 Canonical Metrics (PASS criteria)

- ✓ Duration: ≥4 hours wall-clock
- ✓ Atoms: ≥400 written
- ✓ Max RSS: <500MB throughout
- ✓ p95 latency: <50ms maintained
- ✓ Atoms lost: 0

## Post-Completion Actions (DO NOT AUTO-EXECUTE)

1. **Verify process exit**: `ps -p 1275115` → should be dead
2. **Parse final block** from `/root/0latency-cli/tests/soak_test_4hr.log`
3. **Check sidecar metrics** from `/root/0latency-cli/tests/soak_sidecar.log`
4. **Create result report**: `/root/.openclaw/workspace/memory-product/CP10-P3-SOAK-RESULT.md`
5. **Update merge message**: `/root/.openclaw/workspace/memory-product/CP10-P3-MERGE-COMMIT-MESSAGE.txt`
6. **STOP and await operator merge authorization**

## Abort Triggers

- RSS exceeds 500MB at any sample
- p95 latency exceeds 50ms
- Process crashes/dies prematurely
- Any Python exception/traceback in logs

→ If abort, write incident report to `/root/.openclaw/workspace/memory-product/CP10-P3-SOAK-INCIDENT.md`
