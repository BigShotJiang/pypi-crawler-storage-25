#\!/bin/bash
# CP10 P3 Soak Monitor — run every 30-60 minutes while soak runs

echo "=== CP10 P3 SOAK MONITOR ==="
echo "Time: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo ""

# Check tmux session alive
if tmux has-session -t cp10p3soak 2>/dev/null; then
    echo "✓ Tmux session cp10p3soak is running"
else
    echo "✗ WARNING: Tmux session cp10p3soak not found\!"
    echo "  Soak may have crashed or completed early."
fi

# Check process alive
if ps -p 1275115 > /dev/null 2>&1; then
    echo "✓ Soak process (PID 1275115) alive"
else
    echo "✗ Process 1275115 not found (may have completed or crashed)"
fi

echo ""
echo "=== LAST 20 LINES OF LOG ==="
tail -20 /root/0latency-cli/tests/soak_test_4hr.log

echo ""
echo "=== CHECK FOR ANOMALIES ==="
echo "Looking for errors, RSS >500MB, p95 >50ms..."

if grep -i "error\|fail\|exception" /root/0latency-cli/tests/soak_test_4hr.log | tail -5; then
    echo "⚠️  Errors found in log (see above)"
else
    echo "✓ No errors in recent log"
fi

# Extract latest RSS/p95 if available
if grep "RSS:" /root/0latency-cli/tests/soak_test_4hr.log | tail -1; then
    echo "✓ Latest metrics (see above)"
else
    echo "  (No metrics reported yet, soak still early)"
fi

echo ""
echo "=== NEXT CHECK ==="
echo "Run this script again in 30-60 minutes."
echo "Expected completion: ~2026-05-09 22:45 UTC"
