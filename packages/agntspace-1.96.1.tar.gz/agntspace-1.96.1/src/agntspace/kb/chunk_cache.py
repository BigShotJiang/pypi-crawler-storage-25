"""Per-chunk extraction cache for chunked_extract (P4.6 — diff-aware re-ingest).

When a wiki source / library document is updated with a small change (e.g.
typo fix, paragraph rewrite, append-only edit), the current pipeline
re-runs the entire chunked extraction even though most chunks are
byte-identical to the prior ingest. On a 50K-char document split into
6 chunks, that's 6 LLM calls × ~2K tokens = ~12K tokens, where typically
1 of those 6 chunks changed.

This module caches per-chunk extraction results keyed on the chunk text
itself (plus prompt + model version). On re-ingest, unchanged chunks
return their cached extraction in microseconds; only changed chunks fire
LLM calls. The downstream merge step is unchanged.

Honest impact
=============

- **Append-only edits**: 100% cache hit on prior chunks; only the new
  trailing chunk fires LLM. ~5-10× speedup on large doc updates.
- **Rewrite-in-place** (replace one paragraph in middle): N-1 hits, 1
  miss. ~5× speedup on small edits to large docs.
- **Mid-document insertion** (paragraph added in the middle): hits
  capped at insertion position; chunks AFTER the insertion shift
  paragraph boundaries and miss. Cache hit rate drops to ~50% in this
  case. Still better than 0%.
- **Full rewrite / new document**: 0% hit (correct — every chunk is
  new content).

Architecture
============

1. **Key**: ``sha256[:16](chunk_text + prompt_version + model)`` —
   position-agnostic. The chunked_extract prompt template references
   "section X of Y" but extractions are functions of the chunk's
   CONTENT, not its position. Including position would defeat the
   cache on every paragraph-insertion edit.

2. **Per-KB scope**: cache file lives at
   ``<vault>/knowledge/<kb>/.chunk-extraction-cache.json``. Different
   KBs don't share entries (common boilerplate text in different KB
   contexts produces different downstream summaries, so a global
   cache would create subtle cross-context bugs).

3. **Schema-versioned**: ``schema_version: 1`` field at the top. A
   future change to the chunk-extract prompt OR the JSON shape bumps
   the version → next boot wipes the cache cleanly.

4. **Prompt-version-keyed**: the cache key includes ``prompt_version``.
   When the prompt changes, cached entries for the old prompt simply
   miss on lookup — no explicit cache wipe needed. Old entries get
   LRU-evicted naturally.

5. **LRU + max entries cap** (default 1000 per KB) so long-running
   KBs don't grow unbounded. Bounded memory; bounded JSON file size.

6. **Fail-soft at every boundary**: missing file / corrupt JSON /
   stale schema / write failure / lookup raises → cache miss, LLM
   fires, ingest succeeds. The cache is a perf optimization, NOT a
   correctness gate.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path

log = logging.getLogger(__name__)


# Inline `arch:deterministic` markers — these are structural perf-cache
# defaults, not strategy. The skill YAML overrides them; the constants
# guarantee fail-soft behavior when the YAML is missing or malformed.
_DEFAULT_MAX_ENTRIES: int = 1000  # arch:deterministic — LRU cap per KB cache file; prevents unbounded growth
_CACHE_FILENAME: str = ".chunk-extraction-cache.json"  # arch:deterministic — fixed sibling-to-compile-state.json location
_SCHEMA_VERSION: int = 1  # arch:deterministic — bump on JSON-shape change to force cache wipe across upgrade


@dataclass
class _CacheEntry:
    """One cached extraction with its insertion timestamp."""

    extraction: str
    stored_at: float  # epoch seconds (for cache file portability)


@dataclass
class CacheStats:
    """Lifetime counters exposed for observability."""

    hits: int = 0
    misses: int = 0
    writes: int = 0
    invalidations: int = 0
    evictions: int = 0
    load_failures: int = 0
    save_failures: int = 0

    def to_dict(self) -> dict:
        total = self.hits + self.misses
        return {
            "hits": self.hits,
            "misses": self.misses,
            "writes": self.writes,
            "invalidations": self.invalidations,
            "evictions": self.evictions,
            "load_failures": self.load_failures,
            "save_failures": self.save_failures,
            "hit_rate": round(self.hits / total, 4) if total > 0 else 0.0,
        }


@dataclass
class ChunkCacheConfig:
    """Resolved config — engine fallback when YAML is missing/malformed."""

    enabled: bool = True
    max_entries_per_kb: int = _DEFAULT_MAX_ENTRIES
    # prompt_version is bumped manually when _CHUNK_EXTRACT_PROMPT changes
    # in chunked_extract.py. Old entries miss naturally; LRU evicts them.
    prompt_version: str = "v1"


def resolve_config(skill_loader: object | None) -> ChunkCacheConfig:
    """Read chunk-extract-cache skill config; fall back to defaults.

    Fail-open at every step (missing loader, missing file, malformed
    YAML, non-dict, missing field, negative cap → use defaults).
    """
    cfg = ChunkCacheConfig()
    if skill_loader is None:
        return cfg
    try:
        raw = skill_loader.load_skill_config_file("chunk-extract-cache", "cache.yaml")
    except Exception:
        return cfg
    if not isinstance(raw, dict):
        return cfg

    cfg.enabled = bool(raw.get("enabled", cfg.enabled))
    raw_max = raw.get("max_entries_per_kb")
    if isinstance(raw_max, int) and not isinstance(raw_max, bool) and raw_max > 0:
        cfg.max_entries_per_kb = raw_max
    raw_pv = raw.get("prompt_version")
    if isinstance(raw_pv, str) and raw_pv.strip():
        cfg.prompt_version = raw_pv.strip()
    return cfg


def compute_chunk_key(chunk_text: str, prompt_version: str, model: str | None) -> str:
    """Deterministic cache key for one chunk.

    Position-agnostic by design — including chunk_num / total_chunks
    would defeat the cache on every paragraph-insertion edit. The
    chunked-extract LLM prompt mentions "section X of Y" but that's
    contextual hinting; extractions are deterministic functions of
    the chunk content.

    Includes the resolved model name so swapping ``qwen2.5:14b`` for
    ``gpt-5.4`` doesn't return stale extractions. ``None`` model is
    coerced to ``"default"`` (matches the LLM provider's default
    model behavior).
    """
    model_key = model.strip() if model else "default"
    payload = f"{chunk_text}{prompt_version}{model_key}".encode()
    return hashlib.sha256(payload).hexdigest()[:16]


class ChunkExtractionCache:
    """Per-KB persistent cache of chunk extractions.

    One instance per KB. Loaded lazily from disk on first ``get`` /
    ``put`` call. Writes to disk via atomic ``.tmp + replace`` on
    every ``put`` so a process crash doesn't lose entries — but
    bounded by IO cost: ``put`` is the only write site, and chunked
    extraction is already a multi-LLM-call operation where one extra
    SQLite-tier disk write is noise.

    Use from ``chunked_extract.chunked_extract``:

        cached = cache.get(chunk_text, prompt_version, model)
        if cached is not None:
            return cached
        # ... LLM call ...
        cache.put(chunk_text, prompt_version, model, extraction)
    """

    def __init__(
        self,
        cache_file_path: Path,
        config: ChunkCacheConfig | None = None,
    ) -> None:
        self._path = Path(cache_file_path)
        self._config = config or ChunkCacheConfig()
        # OrderedDict for LRU semantics — move_to_end on access,
        # popitem(last=False) on overflow.
        self._entries: OrderedDict[str, _CacheEntry] = OrderedDict()
        self._loaded = False
        self._stats = CacheStats()

    @property
    def config(self) -> ChunkCacheConfig:
        return self._config

    def stats(self) -> dict:
        return self._stats.to_dict()

    # ─── Read path ───

    def get(
        self,
        chunk_text: str,
        prompt_version: str | None = None,
        model: str | None = None,
    ) -> str | None:
        """Return cached extraction for a chunk, or ``None`` on miss.

        ``prompt_version=None`` uses the config's default. Fail-soft:
        cache load failure / lookup exception → miss + LLM falls through.
        """
        if not self._config.enabled:
            return None
        try:
            self._ensure_loaded()
            pv = prompt_version or self._config.prompt_version
            key = compute_chunk_key(chunk_text, pv, model)
            entry = self._entries.get(key)
            if entry is None:
                self._stats.misses += 1
                return None
            self._entries.move_to_end(key)
            self._stats.hits += 1
            return entry.extraction
        except Exception:
            log.debug("ChunkExtractionCache.get failed — falling through to LLM", exc_info=True)
            self._stats.misses += 1
            return None

    # ─── Write path ───

    def put(
        self,
        chunk_text: str,
        extraction: str,
        prompt_version: str | None = None,
        model: str | None = None,
    ) -> bool:
        """Store an extraction. Returns True on success, False on failure.

        Atomic write via ``.tmp + replace`` so partial files never
        replace a good one. LRU eviction at ``max_entries_per_kb``.
        """
        if not self._config.enabled:
            return False
        try:
            self._ensure_loaded()
            pv = prompt_version or self._config.prompt_version
            key = compute_chunk_key(chunk_text, pv, model)
            self._entries[key] = _CacheEntry(extraction=extraction, stored_at=time.time())
            self._entries.move_to_end(key)
            # LRU eviction
            while len(self._entries) > self._config.max_entries_per_kb:
                self._entries.popitem(last=False)
                self._stats.evictions += 1
            self._stats.writes += 1
            self._save_to_disk()
            return True
        except Exception:
            log.debug("ChunkExtractionCache.put failed — extraction not cached", exc_info=True)
            self._stats.save_failures += 1
            return False

    def invalidate_all(self) -> int:
        """Drop every entry. Useful for tests / admin reset. Returns count dropped."""
        try:
            self._ensure_loaded()
            count = len(self._entries)
            self._entries.clear()
            self._stats.invalidations += count
            self._save_to_disk()
            return count
        except Exception:
            log.debug("ChunkExtractionCache.invalidate_all failed", exc_info=True)
            return 0

    # ─── Persistence ───

    def _ensure_loaded(self) -> None:
        """Load cache file on first access. Fail-soft: any read failure
        leaves the cache empty + flagged as loaded (so we don't retry
        on every call)."""
        if self._loaded:
            return
        self._loaded = True
        if not self._path.exists():
            return
        try:
            raw = self._path.read_text(encoding="utf-8")
        except Exception:
            log.debug("ChunkExtractionCache: failed to read %s", self._path, exc_info=True)
            self._stats.load_failures += 1
            return
        if not raw.strip():
            return
        try:
            data = json.loads(raw)
        except Exception:
            log.warning(
                "ChunkExtractionCache: corrupt JSON at %s — starting fresh", self._path,
            )
            self._stats.load_failures += 1
            return
        if not isinstance(data, dict):
            log.warning("ChunkExtractionCache: unexpected JSON shape at %s — starting fresh", self._path)
            self._stats.load_failures += 1
            return
        # Schema-version gate. Mismatch = wipe.
        stored_version = data.get("schema_version")
        if stored_version != _SCHEMA_VERSION:
            log.info(
                "ChunkExtractionCache: schema version %s != %s — wiping cache at %s",
                stored_version, _SCHEMA_VERSION, self._path,
            )
            return
        raw_entries = data.get("entries")
        if not isinstance(raw_entries, dict):
            return
        for key, val in raw_entries.items():
            if not isinstance(key, str) or not isinstance(val, dict):
                continue
            extraction = val.get("extraction")
            stored_at = val.get("stored_at")
            if not isinstance(extraction, str):
                continue
            try:
                stored_at_f = float(stored_at) if stored_at is not None else time.time()
            except Exception:
                stored_at_f = time.time()
            self._entries[key] = _CacheEntry(extraction=extraction, stored_at=stored_at_f)
        # Respect LRU cap on load (file might have been edited externally)
        while len(self._entries) > self._config.max_entries_per_kb:
            self._entries.popitem(last=False)
            self._stats.evictions += 1

    def _save_to_disk(self) -> None:
        """Atomic write: serialize to .tmp, then replace. Fail-soft."""
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "schema_version": _SCHEMA_VERSION,
                "entries": {
                    key: {"extraction": entry.extraction, "stored_at": entry.stored_at}
                    for key, entry in self._entries.items()
                },
            }
            tmp = self._path.with_suffix(self._path.suffix + ".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            tmp.replace(self._path)
        except Exception:
            log.debug("ChunkExtractionCache: save failed for %s", self._path, exc_info=True)
            self._stats.save_failures += 1


__all__ = [
    "CacheStats",
    "ChunkCacheConfig",
    "ChunkExtractionCache",
    "compute_chunk_key",
    "resolve_config",
]
