"""Chat-ask detector — heuristic classifier for "drop into chat, not inbox" content.

Background
==========
The KB ingest pipeline assumes the file IS the content to be summarized + classified
+ cross-linked into wiki articles. When a user drops a *meta-prompt about content*
("could you analyze this framework?", "find epistemic flaws in this", or just a
URL with "analyze this") into a KB inbox, the agent currently:

  1. Wastes a capable-tier LLM classify call producing a wiki article that says
     things like "the user wants analysis of X" without producing the analysis.
  2. Adds a permanent placeholder wiki entry with N TODOs (canonical example:
     ``main/wiki/entities/products/platforms/obsidian-second-brain.md``).
  3. Holds up the agent dispatch / work queue retry loop on screenshots that
     legitimately can't produce useful ingest output.

This detector runs BEFORE the classify LLM call and short-circuits those cases:
fires a HIGH-importance activity event telling the user "this looks like a chat
ask, paste it into chat instead", and parks the file to
``<KB>/library/parked-chat-asks/`` with a ``.reason.txt`` sidecar (mirrors the
canonical ``park_unsupported_file`` pattern).

Architectural commitments
=========================
1. **Conservative — multiple signals must agree.** A single signal (e.g.
   "contains 'can you'") false-positives on legitimate content that quotes a
   request. Detection requires (a) addressed-to-agent phrasing AND (b) at
   least one corroborating signal (high question density, URL + ask, or
   imperative start). False-negatives are recoverable (the user gets a
   useless wiki entry, same as today). False-positives ROUTE A LEGITIMATE
   SOURCE TO A PARKED FOLDER, which is worse.
2. **Bounded by body length.** Documents over ``max_body_chars`` (default
   1500 chars) are never flagged. Real articles, papers, transcripts, and
   PDFs are out of scope. Chat-asks are short questions, not 5K-word docs.
3. **Pure function.** No I/O, no side effects, no LLM, no network. Engine
   substrate only. Strategy (every threshold + every pattern list) lives in
   ``_meta/inbox-chat-ask-detect/config/detect.yaml`` per Rule 12.
4. **Falls open on uncertainty.** Empty body, missing config, malformed
   patterns, anything weird → return ``(False, "", {})``. Detector NEVER
   raises into the ingest path; broken detection means the file goes
   through the normal pipeline (existing failure mode).
5. **Filename-derived gate at the call site.** This module doesn't filter
   by extension — the caller does. We get a ``source_text`` parameter and
   trust the caller has decided the source is text-shaped (``.md`` /
   ``.txt``). Images, PDFs, and other binary-derived sources are filtered
   at the call site before reaching us.
"""

from __future__ import annotations

import re
from typing import Any

__all__ = ["detect_chat_ask", "fallback_config"]


# Module-level fallback config. Same shape as the YAML — used when the skill
# loader isn't wired (tests, minimal installs) OR YAML is malformed.
#
# arch:deterministic — heuristic thresholds + canonical phrase lists tied 1:1
# to the test suite. Tuning lives in the YAML override; this is the safety
# net for "no YAML available".
_FALLBACK_CONFIG: dict[str, Any] = {
    "enabled": True,
    "max_body_chars": 1500,
    "address_patterns": [
        "can you ",
        "could you ",
        "would you ",
        "please analyze",
        "please look",
        "please find",
        "please give",
        "please check",
        "please tell",
        "please summarize",
        "please review",
        "please critique",
        "please evaluate",
        "what do you think",
        "what's your take",
        "what's your opinion",
        "your opinion",
        "your thoughts",
        "your take",
        "analyze this",
        "analyse this",
        "look at this",
        "check this",
        "review this",
        "summarize this",
        "summarise this",
        "critique this",
        "evaluate this",
        "find epistem",  # catches "epistemic flaws" + "epistemical flaws"
        "find flaws",
        "find issues",
        "find inconsistenc",
        "find wrong",
        "give suggestions",
        "give me suggestions",
        "give feedback",
        "tell me what",
        "tell me how",
        "tell me why",
        "show me how",
        "help me understand",
        "help me with",
        "explain to me",
        "for me to understand",
        "for the user",  # mirror catch — sometimes the user types this
    ],
    "imperative_starts": [
        "could you ",
        "can you ",
        "would you ",
        "please ",
        "give me ",
        "tell me ",
        "show me ",
        "help me ",
        "explain ",
        "analyze ",
        "analyse ",
        "review ",
        "critique ",
        "evaluate ",
        "summarize ",
        "summarise ",
        "compare ",
        "find ",
        "check ",
        "look at ",
        "draft ",
        "write ",
    ],
    "min_questions_per_kchar": 3.0,
    "max_chars_for_url_pattern": 400,
}


def fallback_config() -> dict[str, Any]:
    """Return a deep copy of the deterministic fallback config.

    Used by tests + callers who can't reach the skill loader. Returns a
    fresh dict so callers can mutate it without poisoning the constant.
    """
    return {
        **_FALLBACK_CONFIG,
        "address_patterns": list(_FALLBACK_CONFIG["address_patterns"]),
        "imperative_starts": list(_FALLBACK_CONFIG["imperative_starts"]),
    }


def _strip_frontmatter(text: str) -> str:
    """Remove leading YAML frontmatter block if present.

    Returns ``text`` unchanged when no frontmatter is found, or the body
    after the closing ``---`` marker. Conservative: only strips a SINGLE
    leading block, never raises on malformed frontmatter.
    """
    if not text.startswith("---"):
        return text
    # find the closing --- on its own line, starting after the opening
    rest = text[3:]
    end = rest.find("\n---")
    if end < 0:
        return text  # malformed — leave alone
    body = rest[end + 4:]  # past "\n---"
    return body.lstrip("\n")


def _normalize_for_match(text: str) -> str:
    """Lowercase + collapse whitespace runs to single spaces.

    Phrase matching tolerates newlines/tabs/extra spaces between words —
    "can\\nyou" and "can  you" both match "can you ".
    """
    return re.sub(r"\s+", " ", text.lower())


def _resolve_config(config: dict[str, Any] | None) -> dict[str, Any]:
    """Merge caller config over the deterministic fallback.

    Missing keys inherit the fallback. Wrong-type values fall back too:
    if address_patterns isn't a list, use the fallback list.
    """
    base = fallback_config()
    if not isinstance(config, dict):
        return base
    merged = base.copy()
    for key, value in config.items():
        if key == "address_patterns" or key == "imperative_starts":
            if isinstance(value, list) and all(isinstance(v, str) for v in value):
                merged[key] = [v.strip().lower() for v in value if v.strip()]
            # else: keep fallback
        elif key == "max_body_chars" or key == "max_chars_for_url_pattern":
            if isinstance(value, int) and value > 0:
                merged[key] = value
        elif key == "min_questions_per_kchar":
            if isinstance(value, (int, float)) and value >= 0:
                merged[key] = float(value)
        elif key == "enabled":
            merged[key] = bool(value)
        # unknown keys silently dropped
    return merged


def detect_chat_ask(
    body: str,
    *,
    config: dict[str, Any] | None = None,
) -> tuple[bool, str, dict[str, Any]]:
    """Determine whether ``body`` is a chat-ask vs. ingestable content.

    Returns ``(is_chat_ask, reasons_summary, signals)``.

    * ``is_chat_ask`` — True iff multiple corroborating signals agree.
    * ``reasons_summary`` — Human-readable string for the sidecar /
      activity event (e.g. ``"addresses agent + short with URL"``).
      Empty when ``is_chat_ask`` is False.
    * ``signals`` — Dict capturing every signal evaluated (useful for
      tests + the activity event ``details`` payload). Keys:
      ``char_count``, ``stripped_char_count``, ``addresses_agent``,
      ``matched_address_pattern``, ``question_density``,
      ``high_question_density``, ``has_url``, ``short_with_url``,
      ``starts_with_imperative``, ``matched_imperative``,
      ``oversize_skipped``, ``disabled_skipped``.

    Conservative architectural contract:

    * Requires ``addresses_agent`` AND at least one of
      ``high_question_density`` / ``short_with_url`` /
      ``starts_with_imperative``.
    * Documents over ``max_body_chars`` always return False.
    * Empty body / disabled config / malformed config return False.
    * Never raises. ``body=None`` returns False.
    """
    cfg = _resolve_config(config)

    signals: dict[str, Any] = {
        "char_count": 0,
        "stripped_char_count": 0,
        "addresses_agent": False,
        "matched_address_pattern": "",
        "address_pattern_count": 0,
        "multiple_address_patterns": False,
        "question_density": 0.0,
        "high_question_density": False,
        "has_url": False,
        "short_with_url": False,
        "starts_with_imperative": False,
        "matched_imperative": "",
        "oversize_skipped": False,
        "disabled_skipped": False,
    }

    if not cfg.get("enabled", True):
        signals["disabled_skipped"] = True
        return False, "", signals

    if not isinstance(body, str) or not body.strip():
        return False, "", signals

    signals["char_count"] = len(body)

    stripped = _strip_frontmatter(body).strip()
    signals["stripped_char_count"] = len(stripped)
    if not stripped:
        return False, "", signals

    max_chars = cfg["max_body_chars"]
    if len(stripped) > max_chars:
        signals["oversize_skipped"] = True
        return False, "", signals

    normalized = _normalize_for_match(stripped)

    # Signal A — addresses agent (count distinct phrase matches).
    # A single match flips ``addresses_agent``; two-or-more is a stronger
    # signal that catches "describe + then ask" shape (e.g. dam-spill
    # prompt: framework description followed by "could you analyze ...
    # find epistemic flaws ... give suggestions").
    matched_addrs: list[str] = []
    for pattern in cfg["address_patterns"]:
        if pattern in normalized:
            matched_addrs.append(pattern)
    signals["addresses_agent"] = bool(matched_addrs)
    signals["matched_address_pattern"] = matched_addrs[0] if matched_addrs else ""
    signals["address_pattern_count"] = len(matched_addrs)
    signals["multiple_address_patterns"] = len(matched_addrs) >= 2

    # Signal B — question density (?/1000 chars). Architectural rule:
    # require ``qs >= 2`` even if density crosses the threshold. A single
    # question mark in any text is almost always rhetorical, quoted, or
    # part of a normal sentence ("What does that mean?" inside an
    # explanatory paragraph). Real chat-asks are multi-question OR
    # carry corroborating signals from A/C/D/E. Without this rule, a
    # news article containing one quoted "?" from a CEO false-positives.
    qs = stripped.count("?")
    density = (qs / signals["stripped_char_count"]) * 1000.0
    signals["question_density"] = round(density, 2)
    signals["high_question_density"] = (
        qs >= 2 and density >= cfg["min_questions_per_kchar"]
    )

    # Signal C — URL present + short body + addresses agent
    has_url = "http://" in normalized or "https://" in normalized
    signals["has_url"] = has_url
    short_url = (
        has_url
        and signals["addresses_agent"]
        and signals["stripped_char_count"] <= cfg["max_chars_for_url_pattern"]
    )
    signals["short_with_url"] = short_url

    # Signal D — starts with imperative verb (after whitespace + frontmatter strip)
    starts_imp = ""
    for pattern in cfg["imperative_starts"]:
        if normalized.startswith(pattern):
            starts_imp = pattern
            break
    signals["starts_with_imperative"] = bool(starts_imp)
    signals["matched_imperative"] = starts_imp

    # Architectural rule: REQUIRE addresses_agent (A) AND at least one of
    # B/C/D/E. Single-signal detections are too noisy on real content;
    # multi-signal agreement keeps false-positive rate low.
    corroborating = (
        signals["high_question_density"]
        or signals["short_with_url"]
        or signals["starts_with_imperative"]
        or signals["multiple_address_patterns"]
    )
    if not (signals["addresses_agent"] and corroborating):
        return False, "", signals

    reasons: list[str] = []
    primary_addr = signals["matched_address_pattern"]
    if signals["multiple_address_patterns"]:
        reasons.append(
            f"{signals['address_pattern_count']} agent-address phrases "
            f"({primary_addr!r}, ...)"
        )
    elif signals["addresses_agent"]:
        reasons.append(f"addresses agent ({primary_addr!r})")
    if signals["short_with_url"]:
        reasons.append("short body with URL")
    if signals["high_question_density"]:
        reasons.append(
            f"high question density ({signals['question_density']:.1f}/1k chars)"
        )
    if signals["starts_with_imperative"] and not signals["short_with_url"]:
        # "starts with imperative" is implied by "short_with_url" when both
        # fire; don't duplicate the signal in the reason string.
        reasons.append(f"starts with imperative ({starts_imp!r})")

    return True, " + ".join(reasons), signals
