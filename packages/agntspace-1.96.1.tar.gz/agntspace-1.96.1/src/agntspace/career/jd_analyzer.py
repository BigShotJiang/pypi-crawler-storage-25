"""Career JD gap analyzer — Phase 3 Slice B Part 2 (2026-05-19 night-7).

For a given application (listing + facts/), produces a structured gap
report: which JD requirements the user's facts COVER, which are
PARTIALLY covered, and which are entirely MISSING. The report is the
anti-fabrication ground truth for Slice C's CV builder + cover letter
generator — they read THIS file and refuse to claim a missing requirement
as covered.

**Two consumers share one engine**:
- ``CareerService.analyze_application_gaps(slug)`` writes
  ``applications/{slug}/jd_analysis.md`` and appends ``jd_analysis.md``
  to the application's ``generated_assets``.
- Reserved for a future agent tool (``analyze_career_application``).

**Architectural commitments**:

- **Pure functions where possible.** ``analyze_gaps_via_llm`` is
  testable in isolation — the service composes it.
- **Strategy in YAML** (Rule 12): every threshold, every prompt token,
  every model tier lives in
  ``_meta/career-jd-analyzer/config/analyze.yaml``. Engine reads via
  ``SkillLoader.load_skill_config_file`` with a deterministic
  ``_FALLBACK_CONFIG`` tagged ``# arch:deterministic``.
- **Anti-fabrication rules** baked into the prompt: NEVER invent a
  requirement, NEVER claim a fact is present when the facts/ block
  doesn't show it. Empty arrays are CORRECT when nothing fits.
  Mirrors the ``fabrication_detector.py`` invariant for journal /
  memory / reflection writes.
- **Capable tier by default.** Multi-field structured JSON output with
  cross-field coupling (requirement ↔ fact citation ↔ severity) is
  exactly the workload the session 2026-04-27 night-3 lesson named as
  needing ≥ capable tier minimum. ``fast`` tier collapses the three
  buckets into junk defaults.
- **Fail-soft everywhere.** Missing LLM, malformed JSON, empty input,
  oversized input — all return either ``None`` or an empty ``GapReport``.
  NEVER raises into the caller.

Three architectural rules locked by tests:

1. ``analyze_gaps_via_llm`` returns an empty ``GapReport`` (NOT raises)
   when the agent is None, the JD is too short, or LLM output isn't
   valid JSON. Caller branches on ``report.has_minimum_signal``.
2. ``render_gap_report_markdown`` writes deterministic frontmatter
   (the user can grep ``applications/`` for ``application_slug:`` to
   find which analyses belong to which application even after a folder
   rename surprise).
3. Anti-fabrication: requirements emitted by the LLM are recorded
   verbatim; we never embellish them. The CV builder in Slice C reads
   the rendered markdown and treats each ``missing``/``partial`` row as
   a hard floor — claiming the user has X when the gap report shows
   ``X: missing`` is a fabrication-detector trigger.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agntspace.agent.agent import Agent
    from agntspace.skills.loader import SkillLoader

log = logging.getLogger(__name__)


# ── Module-level constants ─────────────────────────────────────────────────

# Deterministic fallback when the YAML config is missing / malformed.
# Each knob mirrors ``defaults/skills/_meta/career-jd-analyzer/config/
# analyze.yaml``. Marked ``# arch:deterministic`` because these are
# CAPABILITY-SURFACE constants — what the engine structurally can do —
# not strategy. Tuning happens in YAML; the engine survives YAML loss.
_FALLBACK_CONFIG: dict[str, Any] = {  # arch:deterministic — engine fallback when YAML missing/broken
    "enabled": True,
    "llm_tier": "capable",
    "llm_max_tokens": 3000,
    "llm_timeout_seconds": 120,
    "max_jd_chars": 40_000,
    "max_facts_chars": 60_000,
    "min_jd_chars": 80,
    "prompt_template": (
        "You are auditing a job application. The candidate has provided their "
        "structured FACTS (work history, skills, projects, achievements). "
        "Below is a JOB DESCRIPTION. Identify the candidate's REQUIREMENT-FIT "
        "gap as JSON.\n\n"
        "Return a SINGLE JSON object with EXACTLY these keys:\n"
        '  "covered"        (list of strings — JD requirements the FACTS prove the candidate meets)\n'
        '  "partial"        (list of objects — {{requirement: string, gap: string}} for partial matches)\n'
        '  "missing"        (list of strings — JD requirements no FACTS cover at all)\n'
        '  "honest_summary" (string — 2-4 sentence honest assessment for the candidate; NEVER overpromise)\n\n'
        "STRICT RULES:\n"
        "- NEVER invent requirements. Only list things literally stated or implied in the JD.\n"
        "- NEVER claim a FACT exists when the FACTS section doesn't show it. Empty arrays are CORRECT when nothing fits.\n"
        "- A requirement is COVERED only when a fact directly demonstrates it (e.g. '5 years Python' is covered when work history shows 5+ years Python work).\n"
        "- A requirement is PARTIAL when adjacent experience exists but doesn't fully match (e.g. JD wants Kubernetes; user has Docker but no K8s).\n"
        "- A requirement is MISSING when no fact addresses it.\n"
        "- The honest_summary must be honest. If half the requirements are missing, SAY SO. NEVER write a cover-letter-style pitch here.\n"
        "- Output ONLY the JSON object. No preamble, no markdown fences, no commentary.\n\n"
        "JOB DESCRIPTION:\n{jd_text}\n\n"
        "CANDIDATE FACTS:\n{facts_text}"
    ),
}


# ── Data class ─────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class GapReport:
    """Structured gap analysis between a JD and the candidate's facts/.

    All list fields default empty. An empty report is the CORRECT
    representation of "LLM produced no signal" — caller decides whether
    to retry or surface the empty result.

    ``honest_summary`` carries a 2-4 sentence assessment the user reads
    on the ApplicationsPage. It MUST be honest about gaps. CV builder
    + cover letter generator MUST NOT contradict this summary.
    """
    covered: list[str] = field(default_factory=list)
    partial: list[dict[str, str]] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    honest_summary: str = ""

    @property
    def has_minimum_signal(self) -> bool:
        """True iff at least one bucket is non-empty AND honest_summary is set.

        Caller uses this to decide whether to write the analysis file or
        surface "LLM produced no usable analysis, retry?" to the user.
        """
        any_bucket = bool(self.covered or self.partial or self.missing)
        return any_bucket and bool(self.honest_summary.strip())

    @property
    def coverage_ratio(self) -> float:
        """Ratio of covered requirements to total requirements (0.0–1.0).

        Returns 0.0 when there are no requirements at all (empty report).
        Used by ApplicationsPage to render a quick visual indicator.
        """
        total = len(self.covered) + len(self.partial) + len(self.missing)
        if total == 0:
            return 0.0
        return len(self.covered) / total


# ── Config loader ──────────────────────────────────────────────────────────


def resolve_config(skill_loader: SkillLoader | None) -> dict[str, Any]:
    """Load the ``career-jd-analyzer`` YAML config with deterministic fallback.

    Returns the merged config (fallback ∪ YAML, YAML wins). Missing /
    malformed YAML → fallback verbatim. Never raises.
    """
    if skill_loader is None:
        return dict(_FALLBACK_CONFIG)
    try:
        cfg = skill_loader.load_skill_config_file(
            "career-jd-analyzer", "analyze.yaml",
        )
    except Exception:
        log.debug("career-jd-analyzer: YAML load failed, using fallback", exc_info=True)
        return dict(_FALLBACK_CONFIG)
    if not isinstance(cfg, dict) or not cfg:
        return dict(_FALLBACK_CONFIG)
    merged = dict(_FALLBACK_CONFIG)
    for k, v in cfg.items():
        merged[k] = v
    return merged


# ── JSON parsing (mirrors jd_extract._parse_llm_json) ──────────────────────


def _parse_llm_json(output: str) -> dict[str, Any] | None:
    """Parse LLM output as a JSON object.

    Tolerates markdown fences (```json ... ```) and trailing / leading
    prose (extracts the first complete ``{...}`` object). Returns
    ``None`` on any failure.
    """
    if not output or not isinstance(output, str):
        return None
    cleaned = output.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        if len(lines) >= 2:
            inner = "\n".join(lines[1:])
            if inner.rstrip().endswith("```"):
                inner = inner.rstrip()[:-3].rstrip()
            cleaned = inner.strip()
    start = cleaned.find("{")
    if start < 0:
        return None
    depth = 0
    end = -1
    for i in range(start, len(cleaned)):
        c = cleaned[i]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                end = i + 1
                break
    if end < 0:
        return None
    try:
        parsed = json.loads(cleaned[start:end])
    except Exception:
        return None
    if not isinstance(parsed, dict):
        return None
    return parsed


def _coerce_gap_report(parsed: dict[str, Any]) -> GapReport:
    """Build a ``GapReport`` from a parsed JSON dict, with defensive coercion.

    - ``covered``: list of strings (non-strings dropped).
    - ``partial``: list of objects ``{requirement, gap}``; entries
      missing the requirement key are dropped; non-dict entries dropped.
    - ``missing``: list of strings (non-strings dropped).
    - ``honest_summary``: string (coerced to str).
    """
    def _str_list(key: str) -> list[str]:
        raw = parsed.get(key, [])
        if not isinstance(raw, list):
            return []
        out: list[str] = []
        for item in raw:
            if isinstance(item, str) and item.strip():
                out.append(item.strip())
        return out

    partial_raw = parsed.get("partial", [])
    partial_out: list[dict[str, str]] = []
    if isinstance(partial_raw, list):
        for item in partial_raw:
            if isinstance(item, dict):
                req = item.get("requirement", "")
                gap = item.get("gap", "")
                if isinstance(req, str) and req.strip():
                    partial_out.append({
                        "requirement": req.strip(),
                        "gap": str(gap).strip() if gap is not None else "",
                    })
            elif isinstance(item, str) and item.strip():
                # Tolerate "the LLM dropped to a bare string here" — preserve
                # as a partial with empty gap, surface to user honestly.
                partial_out.append({"requirement": item.strip(), "gap": ""})

    summary_raw = parsed.get("honest_summary", "")
    summary = str(summary_raw).strip() if summary_raw is not None else ""

    return GapReport(
        covered=_str_list("covered"),
        partial=partial_out,
        missing=_str_list("missing"),
        honest_summary=summary,
    )


# ── LLM analysis ───────────────────────────────────────────────────────────


async def analyze_gaps_via_llm(
    jd_text: str,
    facts_text: str,
    *,
    agent: Agent | None,
    skill_loader: SkillLoader | None = None,
    cfg: dict[str, Any] | None = None,
) -> GapReport:
    """LLM-analyze the gap between a JD and the candidate's facts.

    Returns an empty ``GapReport`` when:
    - ``cfg.enabled`` is False (kill switch).
    - ``agent`` is None.
    - ``jd_text`` shorter than ``min_jd_chars``.
    - LLM call raises / times out.
    - LLM output is not valid JSON.

    Truncates ``jd_text`` to ``max_jd_chars`` and ``facts_text`` to
    ``max_facts_chars`` before sending to LLM (with markers so the model
    knows the content was truncated).
    """
    config = cfg if cfg is not None else resolve_config(skill_loader)
    if not config.get("enabled", True):
        return GapReport()
    if agent is None:
        return GapReport()
    if not isinstance(jd_text, str) or not jd_text.strip():
        return GapReport()
    min_chars = int(config.get("min_jd_chars", 80))
    if len(jd_text.strip()) < min_chars:
        return GapReport()

    max_jd = int(config.get("max_jd_chars", 40_000))
    jd = jd_text.strip()
    if len(jd) > max_jd:
        jd = jd[:max_jd] + "\n\n[... JD truncated ...]"

    max_facts = int(config.get("max_facts_chars", 60_000))
    facts = (facts_text or "").strip()
    if len(facts) > max_facts:
        facts = facts[:max_facts] + "\n\n[... facts truncated ...]"
    if not facts:
        # Allowed: empty facts is honest — every requirement will be missing.
        facts = "[No facts on file yet. All requirements should be classified as MISSING.]"

    template = str(config.get("prompt_template", _FALLBACK_CONFIG["prompt_template"]))
    try:
        prompt = template.format(jd_text=jd, facts_text=facts)
    except (KeyError, ValueError):
        prompt = _FALLBACK_CONFIG["prompt_template"].format(
            jd_text=jd, facts_text=facts,
        )

    tier = str(config.get("llm_tier", "capable"))
    try:
        result = await agent.process_task(prompt, model_tier=tier)
    except Exception:
        log.debug("career-jd-analyzer: LLM call failed", exc_info=True)
        return GapReport()
    if not isinstance(result, str) or not result.strip():
        return GapReport()

    parsed = _parse_llm_json(result)
    if parsed is None:
        log.debug("career-jd-analyzer: LLM output not parseable as JSON: %r", result[:200])
        return GapReport()

    return _coerce_gap_report(parsed)


# ── Markdown rendering ─────────────────────────────────────────────────────


def render_gap_report_markdown(
    report: GapReport,
    *,
    application_slug: str,
    listing_slug: str,
    when_iso: str | None = None,
) -> str:
    """Render a ``GapReport`` to the canonical ``jd_analysis.md`` shape.

    Frontmatter carries the linkage (``application_slug``,
    ``listing_slug``) + counts + coverage ratio so the ApplicationsPage
    can render a quick visual indicator without parsing the body.

    Body has three sections (covered / partial / missing) plus the
    honest summary. Each bullet is verbatim from the LLM output —
    the renderer NEVER embellishes; the analyzer NEVER fabricates.
    """
    stamp = when_iso or datetime.now(UTC).isoformat(timespec="seconds")
    total = len(report.covered) + len(report.partial) + len(report.missing)
    coverage_pct = (
        f"{(len(report.covered) / total) * 100:.0f}%" if total > 0 else "0%"
    )

    def _yaml_str(value: str) -> str:
        # Quote single-line strings + escape embedded double quotes.
        cleaned = value.replace("\n", " ").replace('"', "'").strip()
        return f'"{cleaned}"'

    # Stash the canonical gap_report shape inline as a single-line
    # JSON string. The CV builder + cover letter builder read THIS
    # field (via _read_gap_report_dict) rather than re-parsing the
    # rendered markdown body — that closes the "user hand-edits the
    # file and the body-parser silently picks up their notes as fake
    # bucket items" footgun. The body remains the human-readable view.
    canonical = {
        "covered": list(report.covered),
        "partial": [dict(p) for p in report.partial],
        "missing": list(report.missing),
        "honest_summary": report.honest_summary,
    }
    # json.dumps with ensure_ascii=False keeps Unicode readable; the
    # YAML single-quoted string form lets us embed double-quoted JSON
    # without escaping. Single quotes inside the JSON are doubled per
    # YAML single-quoted-string spec.
    canonical_yaml = (
        "'"
        + json.dumps(canonical, ensure_ascii=False).replace("'", "''")
        + "'"
    )

    lines: list[str] = [
        "---",
        f"application_slug: {_yaml_str(application_slug)}",
        f"listing_slug: {_yaml_str(listing_slug)}",
        f"generated_at: {_yaml_str(stamp)}",
        f"covered_count: {len(report.covered)}",
        f"partial_count: {len(report.partial)}",
        f"missing_count: {len(report.missing)}",
        f"total_requirements: {total}",
        f'coverage_pct: "{coverage_pct}"',
        f"gap_report_json: {canonical_yaml}",
        "---",
        "",
        f"# JD Gap Analysis — {application_slug}",
        "",
        "## Honest Summary",
        "",
        report.honest_summary or "_LLM did not produce an honest_summary; re-run analysis._",
        "",
        f"## Covered ({len(report.covered)})",
        "",
    ]
    if report.covered:
        for item in report.covered:
            lines.append(f"- {item}")
    else:
        lines.append("_None._")
    lines.append("")
    lines.append(f"## Partial ({len(report.partial)})")
    lines.append("")
    if report.partial:
        for item in report.partial:
            req = item.get("requirement", "")
            gap = item.get("gap", "")
            if gap:
                lines.append(f"- **{req}** — _{gap}_")
            else:
                lines.append(f"- **{req}**")
    else:
        lines.append("_None._")
    lines.append("")
    lines.append(f"## Missing ({len(report.missing)})")
    lines.append("")
    if report.missing:
        for item in report.missing:
            lines.append(f"- {item}")
    else:
        lines.append("_None._")
    lines.append("")
    # Footer pointer so CV builder's anti-fabrication check has a
    # discoverable anchor. The CV builder reads THIS file and treats
    # every ``missing``/``partial`` row as a hard floor.
    lines.append("---")
    lines.append("")
    lines.append(
        "_Generated by AgntSpace career JD analyzer. The CV builder and "
        "cover-letter generator read this file as ground truth — every "
        "**missing** and **partial** entry is a hard floor; claiming the "
        "candidate meets a missing requirement is a fabrication-detector "
        "trigger._",
    )
    lines.append("")
    return "\n".join(lines)


__all__ = [
    "GapReport",
    "_FALLBACK_CONFIG",
    "_parse_llm_json",
    "_coerce_gap_report",
    "analyze_gaps_via_llm",
    "render_gap_report_markdown",
    "resolve_config",
]
