"""Career JD extraction — fetch URLs, parse PDFs/text, LLM-extract structured fields.

Phase 2.5 (2026-05-19 night). Three consumers share one engine:

- ``CareerInboxWatcher``: file drops in ``agntspace-career/inbox/``
  (PDF / .txt / .md / .html → ``ExtractedJob`` → ``CareerService.create_listing``).
- ``POST /api/career/listings/from-url``: user pastes a URL in the UI,
  agent fetches + extracts + creates listing in one call.
- Reserved for a future agent tool (``extract_job_description``).

**Architectural commitments**:

- **Pure functions where possible.** ``fetch_url_text`` and the LLM-driven
  ``extract_job_via_llm`` are testable in isolation — the watcher and the
  route compose them.
- **Strategy in YAML** (Rule 12): every threshold, every prompt token,
  every model tier lives in ``_meta/career-jd-extract/config/extract.yaml``.
  Engine reads via ``SkillLoader.load_skill_config_file`` with a
  deterministic ``_FALLBACK_CONFIG`` tagged ``# arch:deterministic``.
- **URL safety gate** before every outbound fetch — refuses non-HTTP schemes,
  private/loopback IPs, hostname blocklist matches. Same primitive every
  other outbound-fetching surface uses
  (``agntspace.infra.url_safety.classify_url``).
- **Anti-fabrication rules** baked into the prompt:
  empty string for unknown fields, NEVER invent a company / role / number
  not present in the source text. Mirrors the
  ``fabrication_detector.py`` invariant for journal/memory/reflection writes.
- **Fail-soft everywhere.** Missing LLM, malformed JSON, network errors,
  unreachable URL, oversized response — all return either ``None`` or an
  empty ``ExtractedJob``. NEVER raises into the caller.
- **Capable tier by default.** Multi-field structured classification with
  cross-field coupling (company ↔ role ↔ location ↔ tech_stack) is the
  exact category the session 2026-04-27 night-3 lesson named as needing
  ≥ capable tier. ``fast`` tier collapses these into junk defaults.

Three architectural rules locked by tests:

1. ``fetch_url_text`` returns ``("", "")`` (not an exception) when the URL
   fails safety classification, exceeds size cap, or the server doesn't
   return ``text/*`` / ``application/pdf``. Caller branches on empty.
2. ``extract_job_via_llm`` returns an empty ``ExtractedJob`` when LLM
   output isn't valid JSON OR is missing the required ``company`` key.
   NEVER raises.
3. ``extract_job_from_path`` handles ``.pdf`` / ``.txt`` / ``.md`` / ``.html``
   uniformly — caller doesn't branch on file type.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agntspace.agent.agent import Agent
    from agntspace.skills.loader import SkillLoader

log = logging.getLogger(__name__)


# ── Module-level constants ─────────────────────────────────────────────────

# Deterministic fallback when the YAML config is missing / malformed.
# Each knob mirrors the shipped ``defaults/skills/_meta/career-jd-extract/
# config/extract.yaml``. Marked ``# arch:deterministic`` because these
# are CAPABILITY-SURFACE constants — what the engine structurally can do —
# not strategy. Tuning happens in YAML; the engine survives YAML loss.
_FALLBACK_CONFIG: dict[str, Any] = {  # arch:deterministic — engine fallback when YAML missing/broken
    "enabled": True,
    "llm_tier": "capable",
    "llm_max_tokens": 2000,
    "llm_timeout_seconds": 90,
    "fetch_timeout_seconds": 30,
    "max_html_bytes": 4 * 1024 * 1024,   # 4 MB HTML cap — JD pages above this are spam
    "max_text_chars": 80_000,             # truncate text fed to LLM
    "min_text_chars": 100,                # below this, refuse to call LLM
    "user_agent": (
        "Mozilla/5.0 (compatible; AgntSpace/1.0; +https://agntspace.com/bot)"
    ),
    "prompt_template": (
        "You are extracting structured fields from a job description. "
        "Return a SINGLE JSON object with the keys:\n"
        '  "company"      (string — the hiring organization\'s name)\n'
        '  "role"         (string — the job title / position)\n'
        '  "location"     (string — city / region / country / "Remote")\n'
        '  "salary_range" (string — as published; empty if not stated)\n'
        '  "deadline"     (string — application deadline in ISO date YYYY-MM-DD if shown; else empty)\n'
        '  "tech_stack"   (list of strings — only technologies LITERALLY named)\n'
        '  "recruiter"    (string — named recruiter / contact if shown; else empty)\n'
        '  "posted_at"    (string — posting date in YYYY-MM-DD if shown; else empty)\n'
        '  "body"         (string — the full job description in clean markdown)\n\n'
        "STRICT RULES:\n"
        "- NEVER invent fields. If a value is not literally in the source text, return an EMPTY STRING (or empty list).\n"
        "- Do NOT extrapolate, summarize, or guess. Empty is correct when unknown.\n"
        "- Output ONLY the JSON object. No preamble, no markdown fences, no commentary.\n"
        "- ``body`` should be the cleaned-up JD content, NOT a summary.\n\n"
        "Source URL (informational, may be empty):\n{source_url}\n\n"
        "Source text:\n{raw_text}"
    ),
}

# Supported file extensions for ``extract_job_from_path``.
# Marked ``arch:deterministic`` because it's the capability surface of the
# extractor — adding a new extension means writing a new branch.
_SUPPORTED_EXTS: frozenset[str] = frozenset({  # arch:deterministic — file-type capability surface
    ".pdf", ".txt", ".md", ".html", ".htm",
})

# Regex for finding a URL in a .txt drop. Matches http(s):// at start of any
# line (after optional whitespace). Anchored to first URL only — multi-URL
# files unusual for JDs.
_URL_IN_TEXT_RE = re.compile(  # arch:deterministic — URL discovery in .txt drops
    r"(?:^|\s)(https?://[^\s<>'\"]+)", re.MULTILINE,
)


# ── Data class ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ExtractedJob:
    """Structured fields extracted from a JD source. All fields default empty.

    Empty fields are the CORRECT representation of "not stated" — never a
    placeholder. Caller is responsible for deciding whether enough fields
    are populated to proceed (typically ``company`` AND ``role`` non-empty
    is the minimum to create a listing).
    """
    company: str = ""
    role: str = ""
    location: str = ""
    salary_range: str = ""
    deadline: str = ""
    tech_stack: list[str] = field(default_factory=list)
    body: str = ""
    posted_at: str = ""
    recruiter: str = ""
    source_url: str = ""

    @property
    def has_minimum_fields(self) -> bool:
        """True iff company AND role are both non-empty — the minimum to
        create a listing. Other fields are optional.
        """
        return bool(self.company.strip() and self.role.strip())

    def to_listing_kwargs(self) -> dict[str, Any]:
        """Convert to the kwargs shape ``CareerService.create_listing`` expects.

        Returns a dict ready to splat: ``svc.create_listing(**job.to_listing_kwargs())``.
        Empty ``tech_stack`` lists are passed as ``[]`` (the service's
        ``normalize_tech_stack`` handles it).
        """
        return {
            "company": self.company,
            "role": self.role,
            "url": self.source_url,
            "raw_jd_text": self.body,
            "status": "saved",
            "source": "imported",
            "location": self.location,
            "salary_range": self.salary_range,
            "deadline": self.deadline,
            "tech_stack": list(self.tech_stack),
            "recruiter": self.recruiter,
            "posted_at": self.posted_at,
        }


# ── Config loader ──────────────────────────────────────────────────────────

def resolve_config(skill_loader: SkillLoader | None) -> dict[str, Any]:
    """Load the ``career-jd-extract`` YAML config with deterministic fallback.

    Returns the merged config (fallback ∪ YAML, YAML wins). Missing /
    malformed YAML → fallback verbatim. Never raises.
    """
    if skill_loader is None:
        return dict(_FALLBACK_CONFIG)
    try:
        cfg = skill_loader.load_skill_config_file(
            "career-jd-extract", "extract.yaml",
        )
    except Exception:
        log.debug("career-jd-extract: YAML load failed, using fallback", exc_info=True)
        return dict(_FALLBACK_CONFIG)
    if not isinstance(cfg, dict) or not cfg:
        return dict(_FALLBACK_CONFIG)
    merged = dict(_FALLBACK_CONFIG)
    for k, v in cfg.items():
        merged[k] = v
    return merged


# ── URL fetch ──────────────────────────────────────────────────────────────

async def fetch_url_text(
    url: str,
    *,
    cfg: dict[str, Any] | None = None,
    classify_url_fn: Any = None,
) -> tuple[str, str]:
    """Fetch ``url`` and return ``(text, content_type)``.

    - URL is classified for safety BEFORE any network call. Non-HTTP schemes,
      private/loopback IPs, hostname blocklist all return ``("", "")``.
    - Response must be ``text/*`` or ``application/pdf`` — anything else
      returns ``("", "")``.
    - Response > ``max_html_bytes`` returns ``("", "")``.
    - Network errors / timeouts return ``("", "")`` — never raises.

    For ``application/pdf`` responses, the second tuple element is
    ``"application/pdf"`` and the first element is the raw PDF bytes
    decoded as latin-1 (caller passes through to a PDF parser).
    For ``text/html``, returns the raw HTML body (caller strips noise).
    For ``text/plain``, returns the body as-is.

    The ``classify_url_fn`` parameter is the seam for tests — pass a stub
    to avoid loading the real ``url_safety`` module.
    """
    if not isinstance(url, str) or not url.strip():
        return ("", "")
    config = cfg if cfg is not None else _FALLBACK_CONFIG

    # ── 1. URL safety gate ───────────────────────────────────────────────
    try:
        if classify_url_fn is None:
            from agntspace.infra.url_safety import classify_url
        else:
            classify_url = classify_url_fn  # type: ignore[assignment]
        verdict = classify_url(
            url,
            scheme_allowlist=("http", "https"),
            hostname_blocklist=(),
            hostname_allowlist=(),
            block_private_ips=True,
        )
        if not verdict.allowed:
            log.debug("career-jd-extract: URL refused by safety gate: %s (%s)", url, verdict.reason)
            return ("", "")
    except Exception:
        log.debug("career-jd-extract: URL safety classifier failed, refusing", exc_info=True)
        return ("", "")

    # ── 2. Fetch ──────────────────────────────────────────────────────────
    try:
        import httpx
    except ImportError:
        log.warning("career-jd-extract: httpx not installed, cannot fetch URL")
        return ("", "")

    timeout = float(config.get("fetch_timeout_seconds", 30))
    max_bytes = int(config.get("max_html_bytes", 4 * 1024 * 1024))
    user_agent = str(config.get("user_agent", "AgntSpace-JD-Extractor/1.0"))

    try:
        async with httpx.AsyncClient(
            timeout=timeout,
            follow_redirects=True,
            headers={"User-Agent": user_agent},
        ) as client:
            resp = await client.get(url)
    except Exception as exc:
        log.debug("career-jd-extract: fetch failed for %s: %s", url, exc)
        return ("", "")

    if resp.status_code >= 400:
        log.debug("career-jd-extract: HTTP %d for %s", resp.status_code, url)
        return ("", "")

    content_type = resp.headers.get("content-type", "").split(";")[0].strip().lower()
    if not content_type:
        return ("", "")

    is_pdf = content_type == "application/pdf"
    is_text = content_type.startswith("text/")
    if not (is_pdf or is_text):
        log.debug("career-jd-extract: unsupported content-type %r for %s", content_type, url)
        return ("", "")

    body = resp.content
    if len(body) > max_bytes:
        log.debug("career-jd-extract: oversized response %d bytes for %s", len(body), url)
        return ("", "")

    if is_pdf:
        # Return raw bytes; caller routes to PDF parser. latin-1 is byte-safe.
        try:
            return (body.decode("latin-1"), "application/pdf")
        except Exception:
            return ("", "")

    # text/* — decode via response's detected encoding, fallback to utf-8.
    try:
        text = resp.text
    except Exception:
        try:
            text = body.decode("utf-8", errors="replace")
        except Exception:
            return ("", "")
    return (text, content_type)


# ── PDF parsing ────────────────────────────────────────────────────────────

def extract_pdf_text(path_or_bytes: Path | bytes) -> str:
    """Extract plain text from a PDF (file path OR raw bytes).

    Returns empty string on any failure. Uses pdfplumber (already an
    AgntSpace dependency via the kb file-type registry). Never raises.
    """
    try:
        import pdfplumber
    except ImportError:
        log.warning("career-jd-extract: pdfplumber not installed, PDF extraction unavailable")
        return ""

    try:
        if isinstance(path_or_bytes, (bytes, bytearray)):
            import io
            pdf_ctx = pdfplumber.open(io.BytesIO(bytes(path_or_bytes)))
        else:
            pdf_ctx = pdfplumber.open(path_or_bytes)
        with pdf_ctx as pdf:
            parts: list[str] = []
            for page in pdf.pages:
                try:
                    txt = page.extract_text() or ""
                except Exception:
                    continue
                if txt.strip():
                    parts.append(txt)
            return "\n\n".join(parts).strip()
    except Exception:
        log.debug("career-jd-extract: PDF parse failed", exc_info=True)
        return ""


# ── Text normalisation ─────────────────────────────────────────────────────

def normalize_to_plain_text(raw: str, content_type: str) -> str:
    """Convert raw text/HTML to clean plain text for the LLM.

    - HTML: stripped via ``agntspace.text.extract_readable_text`` (shared
      with web scraping). Drops script/style/nav/footer subtrees.
    - text/plain or .txt: returned as-is.
    - Empty input: empty string.
    """
    if not raw or not isinstance(raw, str):
        return ""
    if content_type in ("text/html", "text/htm", "application/xhtml+xml") or "html" in content_type:
        try:
            from agntspace.text import extract_readable_text
            return extract_readable_text(raw).strip()
        except Exception:
            log.debug("career-jd-extract: HTML strip failed, returning raw", exc_info=True)
            return raw.strip()
    return raw.strip()


# ── LLM extraction ─────────────────────────────────────────────────────────

def _parse_llm_json(output: str) -> dict[str, Any] | None:
    """Parse LLM output as a JSON object.

    Tolerates markdown fences (```json ... ```) and trailing/leading prose
    (extracts the first complete ``{...}`` object). Returns ``None`` on
    any failure.
    """
    if not output or not isinstance(output, str):
        return None
    # Strip code fences if present.
    cleaned = output.strip()
    if cleaned.startswith("```"):
        # Drop opening fence (```json or ```) and closing fence.
        lines = cleaned.splitlines()
        if len(lines) >= 2:
            # Drop first line; drop trailing ``` lines.
            inner = "\n".join(lines[1:])
            if inner.rstrip().endswith("```"):
                inner = inner.rstrip()[:-3].rstrip()
            cleaned = inner.strip()
    # Find first { and matching }.
    start = cleaned.find("{")
    if start < 0:
        return None
    # Walk forward tracking brace depth.
    depth = 0
    end = -1
    for i in range(start, len(cleaned)):
        c = cleaned[i]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                end = i + 1
                break
    if end < 0:
        return None
    try:
        parsed = json.loads(cleaned[start:end])
    except Exception:
        return None
    if not isinstance(parsed, dict):
        return None
    return parsed


def _coerce_extracted_job(parsed: dict[str, Any], source_url: str = "") -> ExtractedJob:
    """Build an ``ExtractedJob`` from a parsed JSON dict, with defensive coercion.

    Every field defaults empty. Non-string scalars are coerced to string;
    ``tech_stack`` is coerced to list of strings (drops non-strings).
    """
    def _s(key: str) -> str:
        v = parsed.get(key, "")
        if isinstance(v, str):
            return v.strip()
        if v is None:
            return ""
        try:
            return str(v).strip()
        except Exception:
            return ""

    tech_raw = parsed.get("tech_stack", [])
    tech_list: list[str] = []
    if isinstance(tech_raw, list):
        for item in tech_raw:
            if isinstance(item, str) and item.strip():
                tech_list.append(item.strip())

    return ExtractedJob(
        company=_s("company"),
        role=_s("role"),
        location=_s("location"),
        salary_range=_s("salary_range"),
        deadline=_s("deadline"),
        tech_stack=tech_list,
        body=_s("body"),
        posted_at=_s("posted_at"),
        recruiter=_s("recruiter"),
        source_url=source_url,
    )


async def extract_job_via_llm(
    raw_text: str,
    *,
    agent: Agent | None,
    skill_loader: SkillLoader | None = None,
    source_url: str = "",
    cfg: dict[str, Any] | None = None,
) -> ExtractedJob:
    """LLM-extract structured fields from cleaned JD text.

    Returns an empty ``ExtractedJob`` when:
    - ``raw_text`` shorter than ``min_text_chars``
    - ``agent`` is None
    - LLM call raises / times out
    - LLM output is not valid JSON
    - ``cfg.enabled`` is False (kill switch)

    Truncates ``raw_text`` to ``max_text_chars`` before sending to LLM
    (with a marker so the model knows the content was truncated).
    """
    config = cfg if cfg is not None else resolve_config(skill_loader)
    if not config.get("enabled", True):
        return ExtractedJob(source_url=source_url)
    if agent is None:
        return ExtractedJob(source_url=source_url)
    if not isinstance(raw_text, str) or not raw_text.strip():
        return ExtractedJob(source_url=source_url)
    min_chars = int(config.get("min_text_chars", 100))
    if len(raw_text.strip()) < min_chars:
        return ExtractedJob(source_url=source_url)

    max_chars = int(config.get("max_text_chars", 80_000))
    text = raw_text.strip()
    if len(text) > max_chars:
        text = text[:max_chars] + "\n\n[... truncated ...]"

    template = str(config.get("prompt_template", _FALLBACK_CONFIG["prompt_template"]))
    try:
        prompt = template.format(source_url=source_url or "", raw_text=text)
    except (KeyError, ValueError):
        # Malformed template (bad placeholder) → use fallback.
        prompt = _FALLBACK_CONFIG["prompt_template"].format(
            source_url=source_url or "", raw_text=text,
        )

    tier = str(config.get("llm_tier", "capable"))
    try:
        result = await agent.process_task(
            prompt,
            model_tier=tier,
        )
    except Exception:
        log.debug("career-jd-extract: LLM call failed", exc_info=True)
        return ExtractedJob(source_url=source_url)
    if not isinstance(result, str) or not result.strip():
        return ExtractedJob(source_url=source_url)

    parsed = _parse_llm_json(result)
    if parsed is None:
        log.debug("career-jd-extract: LLM output not parseable as JSON: %r", result[:200])
        return ExtractedJob(source_url=source_url)

    return _coerce_extracted_job(parsed, source_url=source_url)


# ── High-level orchestration ───────────────────────────────────────────────

async def extract_job_from_url(
    url: str,
    *,
    agent: Agent | None,
    skill_loader: SkillLoader | None = None,
) -> ExtractedJob:
    """Fetch ``url`` + extract structured fields.

    Empty ``ExtractedJob(source_url=url)`` returned on any failure
    (unreachable URL, oversized response, LLM failure). Never raises.
    """
    cfg = resolve_config(skill_loader)
    raw, content_type = await fetch_url_text(url, cfg=cfg)
    if not raw:
        return ExtractedJob(source_url=url)

    if content_type == "application/pdf":
        text = extract_pdf_text(raw.encode("latin-1"))
    else:
        text = normalize_to_plain_text(raw, content_type)
    if not text:
        return ExtractedJob(source_url=url)

    return await extract_job_via_llm(
        text,
        agent=agent,
        skill_loader=skill_loader,
        source_url=url,
        cfg=cfg,
    )


async def extract_job_from_path(
    path: Path,
    *,
    agent: Agent | None,
    skill_loader: SkillLoader | None = None,
) -> ExtractedJob:
    """Extract structured fields from a local file (``.pdf``, ``.txt``,
    ``.md``, ``.html``).

    For ``.txt`` files: if the file contains exactly one HTTP(S) URL on a
    line by itself (and otherwise short), treats it as a URL-pointer file
    and fetches the URL instead. Otherwise treats the body as raw JD text.

    Returns an empty ``ExtractedJob`` on any failure. Never raises.
    """
    cfg = resolve_config(skill_loader)
    ext = path.suffix.lower()
    if ext not in _SUPPORTED_EXTS:
        return ExtractedJob()

    if ext == ".pdf":
        text = extract_pdf_text(path)
        if not text:
            return ExtractedJob()
        return await extract_job_via_llm(
            text, agent=agent, skill_loader=skill_loader, source_url="", cfg=cfg,
        )

    # .txt / .md / .html / .htm — read body.
    try:
        body = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ExtractedJob()
    if not body.strip():
        return ExtractedJob()

    # URL-pointer detection: short .txt body that's mostly a URL.
    if ext == ".txt" and len(body) < 2000:
        urls = _URL_IN_TEXT_RE.findall(body)
        # Treat as a URL pointer if the whole non-URL content is short.
        non_url = _URL_IN_TEXT_RE.sub("", body).strip()
        if urls and len(non_url) < 200:
            return await extract_job_from_url(
                urls[0], agent=agent, skill_loader=skill_loader,
            )

    # Treat as raw JD text. Strip HTML noise for .html / .htm.
    if ext in (".html", ".htm"):
        text = normalize_to_plain_text(body, "text/html")
    else:
        text = body
    if not text.strip():
        return ExtractedJob()
    return await extract_job_via_llm(
        text, agent=agent, skill_loader=skill_loader, source_url="", cfg=cfg,
    )


__all__ = [
    "ExtractedJob",
    "extract_job_from_path",
    "extract_job_from_url",
    "extract_job_via_llm",
    "extract_pdf_text",
    "fetch_url_text",
    "normalize_to_plain_text",
    "resolve_config",
]
