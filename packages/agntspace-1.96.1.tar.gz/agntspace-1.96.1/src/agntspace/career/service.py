"""CareerService — Phase 1 facts CRUD.

This is the foundation of the career subsystem. The user authors structured
facts (work-history, education, skills, projects, achievements,
recommendations); the agent reads them as the GROUND TRUTH for CV / cover
letter generation in Phase 3+.

Architectural invariants:
    1. ``FACT_CATEGORIES`` is a closed enum tagged ``# arch:deterministic`` in
       ``templates.py``. Path injection is impossible — every category passed
       to ``get_fact`` / ``update_fact`` is validated against the frozen set.
    2. Writes go through ``VaultWriter`` with ``trust_reason="career_facts_edit"``
       so the runtime guard accepts inline-editor saves AND the boot-time
       scaffolding without forcing every route to authorize a specific
       contract action. Same pattern as graph persistence (session 59).
    3. ``ensure_facts_scaffolded()`` is idempotent — existence check per file.
       Re-running on a fully-scaffolded vault is a fast no-op. The boot path
       can call it unconditionally.
    4. Fail-soft at every boundary. A broken activity logger, missing reader,
       or write failure NEVER raises into the chat path. The user MIGHT lose
       a save (visible via toast); they NEVER lose a chat turn or a session.

Phase 2+ (listings, applications, CV generation) will extend this service,
not replace it.
"""
from __future__ import annotations

import logging
import re
import unicodedata
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

import frontmatter

from agntspace.career.templates import (
    APPLICATION_FRONTMATTER_FIELDS,
    APPLICATION_METADATA_TEMPLATE,
    APPLICATION_STATUSES,
    DEFAULT_FACT_TEMPLATES,
    FACT_CATEGORIES,
    LISTING_FRONTMATTER_FIELDS,
    LISTING_STATUSES,
    LISTING_TEMPLATE,
    is_valid_application_status,
    is_valid_listing_status,
)
from agntspace.vault.paths import VaultPaths
from agntspace.vault.reader import VaultReader
from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

# Closed enum re-exported for callers that import from service directly.
__all__ = [
    "CareerService",
    "FACT_CATEGORIES",
    "FactMeta",
    "ListingMeta",
    "LISTING_STATUSES",
]


_FACTS_DIR = "career/facts"  # logical path; VaultPaths resolves to agntspace-career/facts
_LISTINGS_DIR = "career/listings"  # → agntspace-career/listings
_APPLICATIONS_DIR = "career/applications"  # → agntspace-career/applications/{slug}/{metadata.md, cv.docx, ...}


def _now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


@dataclass(frozen=True)
class FactMeta:
    """Per-category summary returned by ``list_facts``."""
    category: str                # one of FACT_CATEGORIES
    path: str                    # logical vault path (e.g. "career/facts/skills.md")
    exists: bool                 # False before scaffolding has run for this category
    size_bytes: int              # 0 if missing
    last_updated: str            # frontmatter ``last_updated`` if non-empty, else file mtime ISO
    is_empty: bool               # True if the file body still matches the shipped template (heuristic)
    days_since_update: int | None = None   # Phase 4: None when last_updated empty / template
    freshness: str = "unknown"   # Phase 4: "fresh" | "aging" | "stale" | "very_stale" | "unknown"


# Per-category freshness thresholds in days. Each tuple is (aging, stale).
# Beyond stale is always "very_stale". Defaults pinned to domain-stable
# refresh cadences: skills change quarterly, work-history every 6 mo,
# education annually, recommendations rarely.
# Inline arch:deterministic marker per CLAUDE.md Rule 12 + lessons.md
# (block-comment markers above don't satisfy the scanner).
_FRESHNESS_THRESHOLDS_DAYS: dict[str, tuple[int, int]] = {  # arch:deterministic — domain-stable refresh cadences
    "work-history":     (180, 365),
    "education":        (365, 730),
    "skills":           (90, 180),
    "projects":         (180, 365),
    "achievements":     (180, 365),
    "recommendations":  (365, 730),
}


def compute_freshness(
    last_updated: str,
    category: str,
    *,
    now: datetime | None = None,
) -> tuple[int | None, str]:
    """Return ``(days_since_update, freshness)`` for a fact's last-edit ts.

    Args:
        last_updated: ISO-8601 timestamp string from frontmatter / mtime,
            empty string when missing.
        category: One of FACT_CATEGORIES (used to look up per-category
            thresholds). Unknown categories fall back to the median
            (180 aging, 365 stale).
        now: Override for testability. Defaults to ``datetime.now(UTC)``.

    Returns:
        ``(days, freshness)``. ``days`` is ``None`` when the timestamp
        cannot be parsed OR ``last_updated`` is empty (the file was never
        edited). ``freshness`` is one of:
            ``"fresh"``       — within aging threshold
            ``"aging"``       — between aging + stale
            ``"stale"``       — between stale + 2× stale
            ``"very_stale"``  — beyond 2× stale
            ``"unknown"``     — when ``days`` is ``None``

        Negative days (future timestamp due to clock drift) → ``"fresh"``
        with the actual negative day count preserved.

    Never raises; malformed input + missing timestamp both return
    ``(None, "unknown")``.
    """
    if not last_updated:
        return (None, "unknown")
    try:
        ts = datetime.fromisoformat(last_updated)
    except (ValueError, TypeError):
        return (None, "unknown")
    # Bare dates / naive datetimes default to UTC so the diff math works
    # consistently regardless of how the stamp was written.
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=UTC)
    current = now if now is not None else datetime.now(UTC)
    days = int((current - ts).total_seconds() // 86400)
    aging, stale = _FRESHNESS_THRESHOLDS_DAYS.get(category, (180, 365))
    if days < aging:
        return (days, "fresh")
    if days < stale:
        return (days, "aging")
    if days < (stale * 2):
        return (days, "stale")
    return (days, "very_stale")


@dataclass(frozen=True)
class ListingMeta:
    """Per-listing summary returned by ``list_listings``."""
    slug: str
    path: str                    # logical vault path (e.g. "career/listings/stripe-platform-eng-2026-05.md")
    company: str
    role: str
    status: str                  # one of LISTING_STATUSES
    url: str
    deadline: str                # ISO date string or empty
    posted_at: str               # ISO date string or empty
    created_at: str              # ISO timestamp


@dataclass(frozen=True)
class ApplicationMeta:
    """Per-application summary returned by ``list_applications``.

    Phase 3 — Slice A. Each application lives at
    ``agntspace-career/applications/<slug>/metadata.md`` plus sibling
    deliverable files (cv.docx, cover_letter.docx, jd_analysis.md)
    inside the same folder.
    """
    slug: str
    path: str                    # logical vault path to the metadata.md file
    folder: str                  # logical vault path to the application folder
    listing_slug: str            # linked listing
    status: str                  # one of APPLICATION_STATUSES
    created_at: str              # ISO timestamp
    generated_assets: list[str]  # relative paths inside the folder (e.g. ["cv.docx"])


# ── Pure helpers (testable without the service) ────────────────────

_SLUG_TRAILING = re.compile(r"-+$")
_SLUG_LEADING = re.compile(r"^-+")
_SLUG_BAD = re.compile(r"[^a-z0-9]+")


def derive_listing_slug(company: str, role: str, posted_at: str = "") -> str:
    """Build a deterministic, URL-safe slug from a listing's identity.

    Format: ``<company>-<role-head>-<YYYY-MM>``. Year-month suffix lets the
    same company + role be tracked across re-postings (companies frequently
    re-list the same req months apart). Falls back to current YYYY-MM when
    posted_at is empty so a slug always carries a date component.

    The slug must round-trip through pathlib + URL encoding without
    surprises — strict ASCII-lower-with-dashes only.
    """
    if not isinstance(company, str) or not company.strip():
        raise ValueError("company is required for slug derivation")
    if not isinstance(role, str) or not role.strip():
        raise ValueError("role is required for slug derivation")

    # ASCII-fold diacritics (Müller → muller) so slugs don't depend on Unicode form.
    def _ascii(s: str) -> str:
        norm = unicodedata.normalize("NFKD", s)
        ascii_only = norm.encode("ascii", "ignore").decode("ascii")
        return ascii_only.lower()

    company_slug = _SLUG_BAD.sub("-", _ascii(company)).strip("-")
    role_head = " ".join(role.split()[:3])  # cap role at first 3 words to keep slugs reasonable
    role_slug = _SLUG_BAD.sub("-", _ascii(role_head)).strip("-")

    # Year-month suffix.
    if posted_at and isinstance(posted_at, str) and len(posted_at) >= 7:
        # Accept YYYY-MM, YYYY-MM-DD, full ISO timestamp — slice the leading YYYY-MM.
        ym = posted_at[:7]
        if re.match(r"^\d{4}-\d{2}$", ym):
            date_suffix = ym
        else:
            date_suffix = datetime.now(UTC).strftime("%Y-%m")
    else:
        date_suffix = datetime.now(UTC).strftime("%Y-%m")

    parts = [p for p in (company_slug, role_slug, date_suffix) if p]
    slug = "-".join(parts)
    slug = _SLUG_LEADING.sub("", slug)
    slug = _SLUG_TRAILING.sub("", slug)
    if not slug:
        raise ValueError(
            f"derive_listing_slug produced empty slug from "
            f"company={company!r}, role={role!r}"
        )
    return slug


def normalize_tech_stack(value: object) -> list[str]:
    """Coerce a freeform tech_stack input to a clean list of strings.

    Accepts list, comma-string, or single string. Drops empty/whitespace
    entries. Preserves caller order (de-dup keeps first occurrence).
    """
    if value is None:
        return []
    if isinstance(value, str):
        items = [p.strip() for p in value.split(",")]
    elif isinstance(value, (list, tuple)):
        items = [str(p).strip() for p in value]
    else:
        return []
    seen: set[str] = set()
    out: list[str] = []
    for it in items:
        if not it or it in seen:
            continue
        seen.add(it)
        out.append(it)
    return out


def _yaml_tech_stack(items: list[str]) -> str:
    """Render a tech_stack list as inline YAML for the listing template."""
    if not items:
        return "[]"
    # Quote each entry; escape embedded double quotes.
    quoted = ", ".join(f'"{it.replace(chr(34), chr(39))}"' for it in items)
    return f"[{quoted}]"


def derive_application_slug(listing_slug: str, attempt: int = 1) -> str:
    """Build a deterministic, URL-safe slug for an application.

    Phase 3 — Slice A. Format: ``<listing_slug>-app-<NN>`` where NN is
    zero-padded to 2 digits. First application to a listing → ``-app-01``;
    retry → ``-app-02``; etc. Numeric suffix lets the user retry an
    application (e.g. after improving facts/, regenerate the CV) without
    losing the prior application's artifacts.

    The slug must round-trip through pathlib + URL encoding without
    surprises — strict ASCII-lower-with-dashes only.

    Args:
        listing_slug: the slug of the listing this application targets.
            MUST be a valid listing slug (already passes
            ``CareerService._validate_slug``); we re-validate the shape
            defensively here so a caller can't sneak a path-injection
            string through.
        attempt: 1-based retry counter. Defaults to 1 (the first
            application against this listing).

    Raises:
        ValueError: listing_slug empty / bad shape OR attempt < 1.
    """
    if not isinstance(listing_slug, str) or not listing_slug.strip():
        raise ValueError("listing_slug is required for application slug derivation")
    # Re-validate the listing slug shape (defensive — closes path-injection class).
    if "/" in listing_slug or "\\" in listing_slug or ".." in listing_slug:
        raise ValueError(
            f"listing_slug contains forbidden chars: {listing_slug!r}"
        )
    if not re.match(r"^[a-z0-9][a-z0-9-]*[a-z0-9]$|^[a-z0-9]$", listing_slug):
        raise ValueError(
            f"listing_slug must be ASCII lowercase + digits + hyphens "
            f"(got {listing_slug!r})"
        )
    if not isinstance(attempt, int) or attempt < 1:
        raise ValueError(f"attempt must be a positive integer, got {attempt!r}")
    return f"{listing_slug}-app-{attempt:02d}"


class CareerService:
    """Manage the user's professional facts (Phase 1 of the career subsystem).

    Phase 2+ additions (listings, applications, CV generation) will be
    sibling methods on this same class so the activity-logger + vault-paths
    dependency wiring lives in one place.
    """

    def __init__(
        self,
        vault_paths: VaultPaths,
        vault_reader: VaultReader,
        vault_writer: VaultWriter,
        activity_logger: Any | None = None,
    ) -> None:
        self._paths = vault_paths
        self._reader = vault_reader
        self._writer = vault_writer
        # Fail-soft optional dependency. None = no events emitted.
        self._activity = activity_logger
        # Phase 3 Slice B Part 2: post-wired in main.py after the agent
        # is built. Slice B's analyze_application_gaps + Slice C's CV /
        # cover-letter builders need both. Stay None-friendly so existing
        # consumers (FactsPage, listings CRUD) work without the agent.
        self._agent: Any | None = None
        self._skill_loader: Any | None = None

    # ------------------------------------------------------------------
    # Boot-time scaffolding
    # ------------------------------------------------------------------

    def ensure_facts_scaffolded(self) -> dict[str, str]:
        """Create the 6 default fact files in ``career/facts/`` if missing.

        Idempotent: per-file existence check; never overwrites. Safe to call
        on every boot. Returns a map of ``{category: outcome}`` where outcome
        is one of: ``"created"``, ``"already_exists"``, ``"failed:<reason>"``.

        Per Rule 18, the parent directory itself is pre-created by
        ``setup/init.py:_ROOT_DIRS`` + ``VaultPaths.all_init_dirs()`` so a
        fresh vault has the folder visible in the file explorer from day one;
        this method only ensures the TEMPLATE files exist inside it.
        """
        outcomes: dict[str, str] = {}
        facts_dir_phys = self._paths.resolve(_FACTS_DIR)
        try:
            facts_dir_phys.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            log.warning("Could not create %s: %s", facts_dir_phys, exc)
            return {cat: f"failed:mkdir:{exc}" for cat in FACT_CATEGORIES}

        for category, template in DEFAULT_FACT_TEMPLATES.items():
            rel_path = self._path_for(category)
            phys = self._paths.resolve(rel_path)
            if phys.exists():
                outcomes[category] = "already_exists"
                continue
            try:
                # Stamp last_updated to the scaffolding moment so freshness
                # heuristics work from day one. The template ships
                # last_updated: "" so the post-frontmatter render handles it.
                seeded = template.replace(
                    'last_updated: ""',
                    f'last_updated: "{_now_iso()}"',
                    1,
                )
                self._writer.write(
                    rel_path,
                    seeded,
                    versioned=False,  # scaffolding is not an edit; no .history snapshot
                    trust_reason="career_facts_scaffold",
                )
                outcomes[category] = "created"
                log.debug("Scaffolded career fact: %s", rel_path)
            except Exception as exc:  # noqa: BLE001 — fail-soft per architectural rule
                outcomes[category] = f"failed:{type(exc).__name__}:{exc}"
                log.warning("Failed to scaffold %s: %s", rel_path, exc)

        # Emit one aggregate event so the user sees scaffolding ran (low
        # importance — only first boot is interesting; re-runs report all
        # "already_exists" which is silent-noise).
        created_count = sum(1 for v in outcomes.values() if v == "created")
        if created_count:
            self._log_activity(
                action="career_facts_scaffolded",
                summary=f"Scaffolded {created_count} career fact file(s)",
                importance="low",
                details={"outcomes": outcomes},
            )
        return outcomes

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def list_facts(self) -> list[FactMeta]:
        """Return a per-category summary (always 6 entries, in canonical order).

        Categories with no file on disk return ``exists=False`` + ``size_bytes=0``
        + ``is_empty=True`` so the UI can render an "uncreated" affordance
        consistently (covers the rare case where scaffolding failed for one
        category on first boot).
        """
        out: list[FactMeta] = []
        for category in FACT_CATEGORIES:
            rel = self._path_for(category)
            phys = self._paths.resolve(rel)
            if not phys.is_file():
                out.append(FactMeta(
                    category=category, path=rel, exists=False,
                    size_bytes=0, last_updated="", is_empty=True,
                    days_since_update=None, freshness="unknown",
                ))
                continue
            try:
                stat = phys.stat()
                doc = self._reader.read(rel)
                body = doc.content or ""
                meta = doc.metadata or {}
                # Prefer explicit frontmatter timestamp; fall back to mtime.
                last_updated = ""
                raw_lu = meta.get("last_updated") if isinstance(meta, dict) else None
                if isinstance(raw_lu, str) and raw_lu.strip():
                    last_updated = raw_lu.strip()
                else:
                    last_updated = datetime.fromtimestamp(stat.st_mtime, UTC).isoformat(
                        timespec="seconds"
                    )
                is_empty = self._body_is_template(category, body)
                # Phase 4 — template-content facts surface as "unknown" freshness
                # so the UI doesn't nag the user to update a placeholder.
                if is_empty:
                    days_since, freshness = (None, "unknown")
                else:
                    days_since, freshness = compute_freshness(last_updated, category)
                out.append(FactMeta(
                    category=category, path=rel, exists=True,
                    size_bytes=stat.st_size, last_updated=last_updated,
                    is_empty=is_empty,
                    days_since_update=days_since, freshness=freshness,
                ))
            except Exception as exc:  # noqa: BLE001
                log.warning("Failed to inspect career fact %s: %s", rel, exc)
                out.append(FactMeta(
                    category=category, path=rel, exists=True,
                    size_bytes=0, last_updated="", is_empty=True,
                    days_since_update=None, freshness="unknown",
                ))
        return out

    def get_fact(self, category: str) -> dict[str, Any]:
        """Return the full body + parsed frontmatter for one category.

        Raises:
            KeyError: when ``category`` is not in ``FACT_CATEGORIES``. The
                route layer translates this to 404.
            FileNotFoundError: when the category is valid but no file
                exists yet (route → 404, suggest running scaffolding).
        """
        self._require_valid_category(category)
        rel = self._path_for(category)
        doc = self._reader.read(rel)  # raises FileNotFoundError naturally
        body = doc.content or ""
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        return {
            "category": category,
            "path": rel,
            "metadata": meta,
            "content": body,
            "is_empty": self._body_is_template(category, body),
        }

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def update_fact(self, category: str, content: str) -> FactMeta:
        """Replace a fact file's content. Auto-stamps ``last_updated``.

        Caller passes the FULL document (frontmatter + body) as ``content``
        — the same shape ``get_fact`` returns. The service rewrites the
        ``last_updated`` frontmatter value to now and persists.

        Returns the post-write ``FactMeta`` so the route can echo back the
        new size + timestamp without a second read.

        Raises:
            KeyError: invalid category (route → 404).
            ValueError: empty content (route → 422).
        """
        self._require_valid_category(category)
        if not isinstance(content, str):
            raise ValueError(f"content must be str, got {type(content).__name__}")
        if not content.strip():
            raise ValueError("content cannot be empty")

        rel = self._path_for(category)
        stamped = self._stamp_last_updated(content)

        # versioned=True so manual edits land in .history/ for safety.
        # trust_reason carries the audit label since career facts edits don't
        # have a dedicated contract_action in Phase 1 (will revisit in Phase 5).
        self._writer.write(
            rel,
            stamped,
            versioned=True,
            trust_reason="career_facts_edit",
        )

        self._log_activity(
            action="career_fact_updated",
            summary=f"Updated career facts: {category}",
            importance="medium",
            details={"category": category, "size_bytes": len(stamped)},
        )

        # Read back via list_facts machinery so the returned meta is exact.
        # Cheap on a single category since stat + frontmatter parse are fast.
        for fm in self.list_facts():
            if fm.category == category:
                return fm
        # Defensive — should never happen, list_facts always returns all 6.
        raise RuntimeError(f"update_fact succeeded but list_facts skipped {category}")

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _path_for(category: str) -> str:
        return f"{_FACTS_DIR}/{category}.md"

    @staticmethod
    def _require_valid_category(category: str) -> None:
        if not isinstance(category, str):
            raise KeyError(f"category must be str, got {type(category).__name__}")
        if category not in FACT_CATEGORIES:
            raise KeyError(
                f"Unknown career fact category {category!r}. Valid: "
                f"{sorted(FACT_CATEGORIES)}"
            )

    @staticmethod
    def _stamp_last_updated(content: str) -> str:
        """Rewrite ``last_updated:`` in frontmatter to now, or insert it.

        Caller MAY have already updated ``last_updated`` via the editor —
        we overwrite anyway so the displayed timestamp always matches the
        actual save moment. Same idempotency model the journal uses.
        """
        try:
            post = frontmatter.loads(content)
        except Exception:  # noqa: BLE001 — malformed yaml, write through
            return content
        post.metadata["last_updated"] = _now_iso()
        return frontmatter.dumps(post)

    def _body_is_template(self, category: str, body: str) -> bool:
        """Heuristic: True if the body is still mostly the shipped template.

        Two signals:
          1. Body length is within 10% of the template length.
          2. Body contains ``[e.g.,`` placeholder markers (the template
             convention) on any line.

        Both signals together is a high-confidence "user hasn't edited
        yet". Either alone is suggestive — we use OR so the UI nudges
        more readily, matching the ProfilePage placeholder-detection
        heuristic (lesson 2026-04-27 line 1303).
        """
        if not body:
            return True
        template = DEFAULT_FACT_TEMPLATES.get(category, "")
        # Extract the template body the same way the file would render.
        try:
            template_body = frontmatter.loads(template).content or ""
        except Exception:  # noqa: BLE001
            template_body = template
        if not template_body:
            return False
        # Signal 1: any [e.g., placeholder still in the body?
        if "[e.g.," in body:
            return True
        # Signal 2: byte-length within 10% of template indicates no user content.
        body_len = len(body.strip())
        tmpl_len = len(template_body.strip())
        if tmpl_len > 0 and abs(body_len - tmpl_len) / tmpl_len < 0.10:
            return True
        return False

    def _log_activity(self, *, action: str, summary: str, importance: str,
                      details: dict[str, Any] | None = None) -> None:
        """Fail-soft activity emission."""
        logger = self._activity
        if logger is None:
            return
        try:
            log_fn = getattr(logger, "log", None)
            if log_fn is None:
                return
            log_fn(
                category="career",
                action=action,
                summary=summary,
                importance=importance,
                details=details or {},
            )
        except Exception as exc:  # noqa: BLE001
            log.debug("activity logger raised on %s: %s", action, exc)

    # ==================================================================
    # Phase 2 — Listings (job announcements) CRUD
    # ==================================================================

    @staticmethod
    def _listing_path(slug: str) -> str:
        """Logical vault path for a listing's markdown file."""
        return f"{_LISTINGS_DIR}/{slug}.md"

    @staticmethod
    def _validate_slug(slug: object) -> str:
        """Validate a slug at the boundary. Closes the path-injection class."""
        if not isinstance(slug, str):
            raise KeyError(f"listing slug must be str, got {type(slug).__name__}")
        if not slug:
            raise KeyError("listing slug cannot be empty")
        if "/" in slug or "\\" in slug or ".." in slug:
            raise KeyError(f"listing slug contains forbidden chars: {slug!r}")
        if not re.match(r"^[a-z0-9][a-z0-9-]*[a-z0-9]$|^[a-z0-9]$", slug):
            raise KeyError(
                f"listing slug must be ASCII lowercase + digits + hyphens "
                f"(got {slug!r})"
            )
        return slug

    def list_listings(
        self,
        *,
        status: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        """Return a Rule-20-shaped page of listings.

        Args:
            status: optional filter by pipeline status. Invalid status →
                raises KeyError (route → 400).
            limit: max items per page. Clamped to [1, 500].
            offset: pagination offset. Clamped to >= 0.

        Returns:
            ``{"items": [ListingMeta-as-dict, ...], "total": N, "has_more": bool}``

            ``total`` is the FILTERED total (after status filter applies),
            never ``len(items)`` after slicing. Rule 20 compliant.
        """
        if status is not None and not is_valid_listing_status(status):
            raise KeyError(
                f"unknown listing status {status!r}. Valid: {sorted(LISTING_STATUSES)}"
            )
        try:
            limit = max(1, min(500, int(limit)))
        except (TypeError, ValueError):
            limit = 100
        try:
            offset = max(0, int(offset))
        except (TypeError, ValueError):
            offset = 0

        listings_dir = self._paths.resolve(_LISTINGS_DIR)
        if not listings_dir.is_dir():
            return {"items": [], "total": 0, "has_more": False}

        # Collect + sort by created_at desc (newest first). Defensive against
        # broken / missing frontmatter: a corrupt file shows up as an empty
        # ListingMeta with its slug derived from filename, so it's still
        # editable + deletable via the API.
        metas: list[ListingMeta] = []
        for path in sorted(listings_dir.glob("*.md")):
            slug = path.stem
            rel = self._listing_path(slug)
            try:
                doc = self._reader.read(rel)
                meta = doc.metadata if isinstance(doc.metadata, dict) else {}
            except Exception as exc:  # noqa: BLE001
                log.warning("Failed to read listing %s: %s", rel, exc)
                meta = {}
            metas.append(ListingMeta(
                slug=slug,
                path=rel,
                company=str(meta.get("company", "")).strip(),
                role=str(meta.get("role", "")).strip(),
                status=str(meta.get("status", "saved")).strip() or "saved",
                url=str(meta.get("url", "")).strip(),
                deadline=str(meta.get("deadline", "")).strip(),
                posted_at=str(meta.get("posted_at", "")).strip(),
                created_at=str(meta.get("created_at", "")).strip(),
            ))

        # Filter by status BEFORE the total count (Rule 20).
        if status is not None:
            metas = [m for m in metas if m.status == status]

        # Sort newest-first by created_at. Fall back to slug for ties /
        # missing timestamps.
        metas.sort(key=lambda m: (m.created_at, m.slug), reverse=True)

        total = len(metas)
        page = metas[offset : offset + limit]
        has_more = offset + len(page) < total
        return {
            "items": [
                {
                    "slug": m.slug,
                    "path": m.path,
                    "company": m.company,
                    "role": m.role,
                    "status": m.status,
                    "url": m.url,
                    "deadline": m.deadline,
                    "posted_at": m.posted_at,
                    "created_at": m.created_at,
                }
                for m in page
            ],
            "total": total,
            "has_more": has_more,
        }

    def get_listing(self, slug: str) -> dict[str, Any]:
        """Return full body + parsed frontmatter for one listing.

        Raises:
            KeyError: invalid slug shape (route → 404 / 400).
            FileNotFoundError: valid slug but no file on disk (route → 404).
        """
        slug = self._validate_slug(slug)
        rel = self._listing_path(slug)
        doc = self._reader.read(rel)  # raises FileNotFoundError naturally
        body = doc.content or ""
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        return {
            "slug": slug,
            "path": rel,
            "metadata": meta,
            "content": body,
        }

    def create_listing(
        self,
        *,
        company: str,
        role: str,
        url: str = "",
        raw_jd_text: str = "",
        status: str = "saved",
        source: str = "manual",
        location: str = "",
        salary_range: str = "",
        deadline: str = "",
        tech_stack: list[str] | str | None = None,
        recruiter: str = "",
        posted_at: str = "",
    ) -> dict[str, Any]:
        """Create a new listing markdown file.

        Slug derived from ``derive_listing_slug(company, role, posted_at)``.
        Collisions get a numeric suffix (``-2``, ``-3``, ...) so re-applying
        to the same role does NOT silently overwrite a prior listing.

        Returns:
            ``{slug, path, status, created_at}`` so the caller can navigate
            to the detail view without a second round-trip.

        Raises:
            ValueError: company/role missing OR status invalid (route → 400).
        """
        if not isinstance(company, str) or not company.strip():
            raise ValueError("company is required")
        if not isinstance(role, str) or not role.strip():
            raise ValueError("role is required")
        if not is_valid_listing_status(status):
            raise ValueError(
                f"unknown status {status!r}. Valid: {sorted(LISTING_STATUSES)}"
            )

        # Slug + collision suffix.
        base_slug = derive_listing_slug(company, role, posted_at)
        listings_dir = self._paths.resolve(_LISTINGS_DIR)
        listings_dir.mkdir(parents=True, exist_ok=True)
        slug = base_slug
        suffix = 1
        while (listings_dir / f"{slug}.md").exists():
            suffix += 1
            slug = f"{base_slug}-{suffix}"

        # Normalise tech_stack to a clean list and emit valid inline YAML.
        tech_list = normalize_tech_stack(tech_stack)
        created_at = _now_iso()

        # Escape any embedded quotes / newlines that would break the
        # YAML frontmatter shape. Lightweight — full YAML round-trip via
        # python-frontmatter would be heavier but here every field is a
        # short string so simple replacement suffices.
        def _esc(v: str) -> str:
            return v.replace('"', "'").replace("\n", " ").strip()

        body = LISTING_TEMPLATE.format(
            slug=_esc(slug),
            company=_esc(company),
            role=_esc(role),
            url=_esc(url),
            status=_esc(status),
            source=_esc(source),
            location=_esc(location),
            salary_range=_esc(salary_range),
            deadline=_esc(deadline),
            tech_stack_yaml=_yaml_tech_stack(tech_list),
            recruiter=_esc(recruiter),
            posted_at=_esc(posted_at),
            created_at=created_at,
            jd_body=(raw_jd_text or "").strip()
            or "_No JD body captured. Paste the full job description here._",
        )

        rel = self._listing_path(slug)
        self._writer.write(
            rel,
            body,
            versioned=True,
            trust_reason="career_listing_edit",
        )
        self._log_activity(
            action="career_listing_created",
            summary=f"Career listing created: {company} — {role}",
            importance="medium",
            details={"slug": slug, "company": company, "role": role, "status": status},
        )
        return {"slug": slug, "path": rel, "status": status, "created_at": created_at}

    def update_listing(self, slug: str, **fields: Any) -> dict[str, Any]:
        """Patch listing frontmatter fields (status uses update_listing_status).

        Only fields in ``LISTING_FRONTMATTER_FIELDS`` are accepted — unknown
        keys raise ``KeyError`` (route → 400). Closes route-injection of
        arbitrary metadata.

        Args:
            slug: listing slug (path-injection-validated).
            **fields: subset of LISTING_FRONTMATTER_FIELDS.

        Returns:
            ``{slug, path, updated_fields}``.

        Raises:
            KeyError: invalid slug or unknown field (route → 400/404).
            FileNotFoundError: slug valid but no file (route → 404).
        """
        slug = self._validate_slug(slug)
        # Reject status updates here — they're routed through
        # update_listing_status which maintains the status_history timeline.
        bad_keys = set(fields.keys()) - LISTING_FRONTMATTER_FIELDS
        if "status" in fields:
            raise KeyError(
                "status updates must go through PATCH /api/career/listings/{slug}/status"
            )
        if bad_keys:
            raise KeyError(
                f"unknown listing fields: {sorted(bad_keys)}. "
                f"Allowed: {sorted(LISTING_FRONTMATTER_FIELDS)}"
            )

        rel = self._listing_path(slug)
        doc = self._reader.read(rel)
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}

        updated: dict[str, Any] = {}
        for key, value in fields.items():
            if key == "tech_stack":
                value = normalize_tech_stack(value)
            meta[key] = value
            updated[key] = value

        new_content = frontmatter.dumps(frontmatter.Post(doc.content or "", **meta))
        self._writer.write(
            rel,
            new_content,
            versioned=True,
            trust_reason="career_listing_edit",
        )
        self._log_activity(
            action="career_listing_updated",
            summary=f"Career listing patched: {slug}",
            importance="low",
            details={"slug": slug, "fields_changed": sorted(updated.keys())},
        )
        return {"slug": slug, "path": rel, "updated_fields": updated}

    def update_listing_status(
        self, slug: str, new_status: str, note: str = "",
    ) -> dict[str, Any]:
        """Move a listing through the pipeline + append to status timeline.

        The status_history list in frontmatter is APPEND-ONLY — every
        transition is preserved for audit (when did "applied" happen? when
        did "rejected" arrive?). Same status as current is a no-op (no
        timeline pollution from accidental re-clicks).

        Raises:
            KeyError: invalid slug / unknown status (route → 400/404).
            FileNotFoundError: slug valid but no file (route → 404).
        """
        slug = self._validate_slug(slug)
        if not is_valid_listing_status(new_status):
            raise KeyError(
                f"unknown status {new_status!r}. Valid: {sorted(LISTING_STATUSES)}"
            )

        rel = self._listing_path(slug)
        doc = self._reader.read(rel)
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        prev_status = str(meta.get("status", "saved"))

        if new_status == prev_status:
            return {
                "slug": slug,
                "path": rel,
                "status": new_status,
                "changed": False,
                "previous_status": prev_status,
            }

        meta["status"] = new_status
        history = meta.get("status_history")
        if not isinstance(history, list):
            history = []
        history.append({
            "status": new_status,
            "at": _now_iso(),
            "note": (note or "").strip(),
        })
        meta["status_history"] = history

        new_content = frontmatter.dumps(frontmatter.Post(doc.content or "", **meta))
        self._writer.write(
            rel,
            new_content,
            versioned=True,
            trust_reason="career_listing_status_change",
        )
        self._log_activity(
            action="career_listing_status_changed",
            summary=f"Career listing {slug}: {prev_status} → {new_status}",
            importance="medium",
            details={
                "slug": slug,
                "previous_status": prev_status,
                "new_status": new_status,
                "note": (note or "").strip(),
            },
        )
        return {
            "slug": slug,
            "path": rel,
            "status": new_status,
            "previous_status": prev_status,
            "changed": True,
        }

    def delete_listing(self, slug: str) -> dict[str, Any]:
        """Delete a listing by slug. Idempotent.

        Returns:
            ``{deleted: True, slug}`` on real delete.
            ``{deleted: False, slug, reason: "not_found"}`` on idempotent
            no-op (file already gone). Same shape as the wiki article
            delete pattern from CLAUDE.md Rule 18 phantom-cleanup.
        """
        slug = self._validate_slug(slug)
        rel = self._listing_path(slug)
        phys = self._paths.resolve(rel)
        if not phys.is_file():
            return {"deleted": False, "slug": slug, "reason": "not_found"}
        try:
            phys.unlink()
        except OSError as exc:
            raise RuntimeError(f"failed to delete listing {slug}: {exc}") from exc
        self._log_activity(
            action="career_listing_deleted",
            summary=f"Career listing deleted: {slug}",
            importance="medium",
            details={"slug": slug},
        )
        return {"deleted": True, "slug": slug}

    # ==================================================================
    # Applications (Phase 3 Slice B)
    # ==================================================================
    #
    # Architectural decision (locked in night-5): each application is a
    # FOLDER under agntspace-career/applications/{slug}/, NOT a single
    # markdown file. The folder carries metadata.md plus deliverables
    # (cv.docx, cover_letter.docx, jd_analysis.md) added by Phase 3
    # Slice C's CV builder + this slice's JD analyzer.
    #
    # Slug shape: <listing_slug>-app-<NN> with 2-digit zero-padded
    # attempt counter (avoids -app-1 vs -app-10 sort surprise + lets
    # users retry an application against the same listing).
    #
    # status_history is append-only — every transition preserved for
    # audit. The dedicated update_application_status route mutates it;
    # the generic update_application PATCH route refuses to mutate
    # immutable fields (slug, listing_slug, status, created_at,
    # status_history) via APPLICATION_FRONTMATTER_FIELDS allowlist.

    @staticmethod
    def _application_folder(slug: str) -> str:
        """Logical vault path to the application FOLDER."""
        return f"{_APPLICATIONS_DIR}/{slug}"

    @staticmethod
    def _application_metadata_path(slug: str) -> str:
        """Logical vault path to the application's metadata.md FILE."""
        return f"{_APPLICATIONS_DIR}/{slug}/metadata.md"

    def _existing_listing_slugs(self) -> set[str]:
        """Set of slugs that exist as valid listings on disk.

        Used to validate that create_application's listing_slug actually
        points at a real listing. Closes the "create an application
        against a typo'd listing" silent-orphan class.
        """
        listings_dir = self._paths.resolve(_LISTINGS_DIR)
        if not listings_dir.is_dir():
            return set()
        return {p.stem for p in listings_dir.glob("*.md")}

    def _next_application_attempt(self, listing_slug: str) -> int:
        """Find the next free attempt number for a listing.

        Returns 1 if no application exists for this listing; 2 if -app-01
        exists; etc. Caller passes the result to derive_application_slug.
        """
        apps_dir = self._paths.resolve(_APPLICATIONS_DIR)
        if not apps_dir.is_dir():
            return 1
        # Match folders named ``<listing_slug>-app-NN``.
        attempts: list[int] = []
        prefix = f"{listing_slug}-app-"
        for entry in apps_dir.iterdir():
            if not entry.is_dir() or not entry.name.startswith(prefix):
                continue
            suffix = entry.name[len(prefix):]
            try:
                n = int(suffix)
            except ValueError:
                continue
            if n >= 1:
                attempts.append(n)
        return (max(attempts) + 1) if attempts else 1

    def list_applications(
        self,
        *,
        status: str | None = None,
        listing_slug: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        """Return a Rule-20-shaped page of applications.

        Args:
            status: optional filter by preparation pipeline status.
                Invalid status → raises KeyError (route → 400).
            listing_slug: optional filter — return only applications
                targeting this listing. Useful for "how many CV
                versions have I made for X?" queries.
            limit: max items per page. Clamped to [1, 500].
            offset: pagination offset. Clamped to >= 0.

        Returns:
            ``{"items": [ApplicationMeta-as-dict, ...], "total": N, "has_more": bool}``

            ``total`` is the FILTERED total (after status + listing_slug
            filters apply), never ``len(items)`` after slicing.
        """
        if status is not None and not is_valid_application_status(status):
            raise KeyError(
                f"unknown application status {status!r}. "
                f"Valid: {sorted(APPLICATION_STATUSES)}"
            )
        try:
            limit = max(1, min(500, int(limit)))
        except (TypeError, ValueError):
            limit = 100
        try:
            offset = max(0, int(offset))
        except (TypeError, ValueError):
            offset = 0

        apps_dir = self._paths.resolve(_APPLICATIONS_DIR)
        if not apps_dir.is_dir():
            return {"items": [], "total": 0, "has_more": False}

        # Walk folders, read metadata.md from each.
        metas: list[ApplicationMeta] = []
        for entry in sorted(apps_dir.iterdir()):
            if not entry.is_dir():
                continue
            slug = entry.name
            md_path = entry / "metadata.md"
            if not md_path.is_file():
                # Folder exists but metadata.md missing — could be
                # half-created or user-deleted. Skip silently rather
                # than poisoning the list with a broken row.
                continue
            rel = self._application_metadata_path(slug)
            folder_rel = self._application_folder(slug)
            try:
                doc = self._reader.read(rel)
                meta = doc.metadata if isinstance(doc.metadata, dict) else {}
            except Exception as exc:  # noqa: BLE001
                log.warning("Failed to read application %s: %s", rel, exc)
                meta = {}
            assets = meta.get("generated_assets", [])
            if not isinstance(assets, list):
                assets = []
            metas.append(ApplicationMeta(
                slug=slug,
                path=rel,
                folder=folder_rel,
                listing_slug=str(meta.get("listing_slug", "")).strip(),
                status=str(meta.get("status", "draft")).strip() or "draft",
                created_at=str(meta.get("created_at", "")).strip(),
                generated_assets=[str(a) for a in assets if isinstance(a, str)],
            ))

        # Filter by status + listing_slug BEFORE the total count (Rule 20).
        if status is not None:
            metas = [m for m in metas if m.status == status]
        if listing_slug is not None:
            metas = [m for m in metas if m.listing_slug == listing_slug]

        # Sort newest-first by created_at; ties broken by slug for determinism.
        metas.sort(key=lambda m: (m.created_at, m.slug), reverse=True)

        total = len(metas)
        page = metas[offset : offset + limit]
        has_more = offset + len(page) < total
        return {
            "items": [
                {
                    "slug": m.slug,
                    "path": m.path,
                    "folder": m.folder,
                    "listing_slug": m.listing_slug,
                    "status": m.status,
                    "created_at": m.created_at,
                    "generated_assets": list(m.generated_assets),
                }
                for m in page
            ],
            "total": total,
            "has_more": has_more,
        }

    def get_application(self, slug: str) -> dict[str, Any]:
        """Return full body + parsed frontmatter for one application.

        Raises:
            KeyError: invalid slug shape (route → 400).
            FileNotFoundError: valid slug but no metadata.md on disk
                (route → 404).
        """
        slug = self._validate_slug(slug)
        rel = self._application_metadata_path(slug)
        doc = self._reader.read(rel)  # raises FileNotFoundError naturally
        body = doc.content or ""
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        return {
            "slug": slug,
            "path": rel,
            "folder": self._application_folder(slug),
            "metadata": meta,
            "content": body,
        }

    def create_application(
        self,
        *,
        listing_slug: str,
        status: str = "draft",
    ) -> dict[str, Any]:
        """Create a new application folder + metadata.md for a listing.

        Slug derived from ``derive_application_slug(listing_slug,
        attempt)`` where ``attempt`` is the next free integer for this
        listing (1 if first, 2 if -app-01 exists, etc.). Multiple
        applications to the same listing get distinct folders.

        Returns:
            ``{slug, path, folder, status, created_at, listing_slug}``
            so the caller can navigate to the application detail view
            without a second round-trip.

        Raises:
            ValueError: listing_slug missing/invalid OR status invalid
                OR listing_slug doesn't point at a real listing
                (route → 400).
        """
        if not isinstance(listing_slug, str) or not listing_slug.strip():
            raise ValueError("listing_slug is required")
        listing_slug = listing_slug.strip()
        if not is_valid_application_status(status):
            raise ValueError(
                f"unknown application status {status!r}. "
                f"Valid: {sorted(APPLICATION_STATUSES)}"
            )

        # Confirm the listing actually exists — closes the silent-orphan
        # class where an application is created against a typo'd slug.
        existing = self._existing_listing_slugs()
        if listing_slug not in existing:
            raise ValueError(
                f"listing_slug {listing_slug!r} does not match any existing "
                f"listing on disk"
            )

        attempt = self._next_application_attempt(listing_slug)
        slug = derive_application_slug(listing_slug, attempt=attempt)
        created_at = _now_iso()

        # Materialise the folder + metadata.md.
        apps_dir = self._paths.resolve(_APPLICATIONS_DIR)
        apps_dir.mkdir(parents=True, exist_ok=True)
        app_folder = apps_dir / slug
        app_folder.mkdir(parents=True, exist_ok=True)

        def _esc(v: str) -> str:
            return v.replace('"', "'").replace("\n", " ").strip()

        body = APPLICATION_METADATA_TEMPLATE.format(
            slug=_esc(slug),
            listing_slug=_esc(listing_slug),
            status=_esc(status),
            created_at=created_at,
        )

        rel = self._application_metadata_path(slug)
        self._writer.write(
            rel,
            body,
            versioned=True,
            trust_reason="career_application_edit",
        )
        self._log_activity(
            action="career_application_created",
            summary=f"Career application created for listing {listing_slug}",
            importance="medium",
            details={
                "slug": slug,
                "listing_slug": listing_slug,
                "attempt": attempt,
                "status": status,
            },
        )
        return {
            "slug": slug,
            "path": rel,
            "folder": self._application_folder(slug),
            "listing_slug": listing_slug,
            "status": status,
            "created_at": created_at,
            "attempt": attempt,
        }

    def update_application(self, slug: str, **fields: Any) -> dict[str, Any]:
        """Patch application frontmatter fields (status uses
        ``update_application_status``).

        Only fields in ``APPLICATION_FRONTMATTER_FIELDS`` are accepted —
        unknown fields raise ValueError (route → 400). Immutable fields
        (slug, listing_slug, status, created_at, status_history) are
        rejected by the same allowlist — they're DELIBERATELY excluded
        from the constant so the PATCH route can never bypass the
        dedicated /status route or mutate the audit trail.

        Raises:
            KeyError: invalid slug shape OR metadata.md missing.
            ValueError: unknown / disallowed field in patch body.
        """
        slug = self._validate_slug(slug)
        if not fields:
            raise ValueError("at least one field must be provided in PATCH body")

        unknown = set(fields) - APPLICATION_FRONTMATTER_FIELDS
        if unknown:
            raise ValueError(
                f"unknown / disallowed application fields: {sorted(unknown)}. "
                f"Allowed: {sorted(APPLICATION_FRONTMATTER_FIELDS)}. "
                f"Status changes go through update_application_status; "
                f"slug / listing_slug / created_at / status_history are immutable."
            )

        rel = self._application_metadata_path(slug)
        doc = self._reader.read(rel)
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}

        # Coerce generated_assets to a clean list of strings.
        for key, value in fields.items():
            if key == "generated_assets":
                if not isinstance(value, list):
                    raise ValueError(
                        f"generated_assets must be a list, got {type(value).__name__}"
                    )
                meta[key] = [str(v) for v in value if isinstance(v, (str, int, float))]
            else:
                meta[key] = value

        new_content = frontmatter.dumps(frontmatter.Post(doc.content or "", **meta))
        self._writer.write(
            rel,
            new_content,
            versioned=True,
            trust_reason="career_application_edit",
        )
        self._log_activity(
            action="career_application_updated",
            summary=f"Career application updated: {slug}",
            importance="low",
            details={"slug": slug, "fields": sorted(fields.keys())},
        )
        return {
            "slug": slug,
            "path": rel,
            "folder": self._application_folder(slug),
            "fields_updated": sorted(fields.keys()),
        }

    def update_application_status(
        self, slug: str, new_status: str, note: str = "",
    ) -> dict[str, Any]:
        """Move an application through the preparation pipeline + append
        to status timeline.

        The status_history list in frontmatter is APPEND-ONLY — every
        transition preserved for audit. Same-status transition is a
        no-op (no timeline pollution from accidental re-clicks).

        Raises:
            KeyError: invalid slug / unknown status (route → 400/404).
            FileNotFoundError: slug valid but no metadata.md (route → 404).
        """
        slug = self._validate_slug(slug)
        if not is_valid_application_status(new_status):
            raise KeyError(
                f"unknown application status {new_status!r}. "
                f"Valid: {sorted(APPLICATION_STATUSES)}"
            )

        rel = self._application_metadata_path(slug)
        doc = self._reader.read(rel)
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        prev_status = str(meta.get("status", "draft"))

        if new_status == prev_status:
            return {
                "slug": slug,
                "path": rel,
                "status": new_status,
                "changed": False,
                "previous_status": prev_status,
            }

        meta["status"] = new_status
        history = meta.get("status_history")
        if not isinstance(history, list):
            history = []
        history.append({
            "status": new_status,
            "at": _now_iso(),
            "note": (note or "").strip(),
        })
        meta["status_history"] = history

        new_content = frontmatter.dumps(frontmatter.Post(doc.content or "", **meta))
        self._writer.write(
            rel,
            new_content,
            versioned=True,
            trust_reason="career_application_status_change",
        )
        self._log_activity(
            action="career_application_status_changed",
            summary=f"Career application {slug}: {prev_status} → {new_status}",
            importance="medium",
            details={
                "slug": slug,
                "previous_status": prev_status,
                "new_status": new_status,
                "note": (note or "").strip(),
            },
        )
        return {
            "slug": slug,
            "path": rel,
            "status": new_status,
            "previous_status": prev_status,
            "changed": True,
        }

    def delete_application(self, slug: str) -> dict[str, Any]:
        """Delete an application FOLDER by slug. Idempotent.

        Removes the entire ``applications/{slug}/`` directory including
        all generated deliverables (cv.docx, cover_letter.docx,
        jd_analysis.md). The user's choice to delete an application is
        a clean wipe — the deliverables are derived from the listing +
        facts, so they can always be regenerated.

        Returns:
            ``{deleted: True, slug, removed_files: [...]}`` on real delete.
            ``{deleted: False, slug, reason: "not_found"}`` on idempotent
            no-op (folder already gone). Same Rule 18 phantom-cleanup
            shape as delete_listing.
        """
        slug = self._validate_slug(slug)
        folder = self._paths.resolve(self._application_folder(slug))
        if not folder.is_dir():
            return {"deleted": False, "slug": slug, "reason": "not_found"}
        # Collect the file inventory BEFORE delete so the activity event
        # carries it (audit value — "you deleted these assets").
        removed_files: list[str] = []
        try:
            for entry in folder.rglob("*"):
                if entry.is_file():
                    removed_files.append(entry.relative_to(folder).as_posix())
        except OSError:
            pass
        try:
            import shutil
            shutil.rmtree(folder)
        except OSError as exc:
            raise RuntimeError(
                f"failed to delete application folder {slug}: {exc}"
            ) from exc
        self._log_activity(
            action="career_application_deleted",
            summary=f"Career application deleted: {slug}",
            importance="medium",
            details={"slug": slug, "removed_files": removed_files},
        )
        return {"deleted": True, "slug": slug, "removed_files": removed_files}

    # ==================================================================
    # Privacy — forget-all (Phase 4)
    # ==================================================================
    #
    # GDPR-aligned wipe of every piece of user career data: facts,
    # listings, applications + their deliverables, captured library
    # files, pending inbox drops.
    #
    # Two-step UX gate:
    #   1. ``confirm=False`` (default) returns the inventory WITHOUT
    #      deleting. UI/CLI shows the user what would be wiped.
    #   2. ``confirm=True`` actually wipes. Single high-importance
    #      activity event records the operation for the audit trail
    #      even after the source files are gone.
    #
    # Idempotent: re-running on an empty vault returns zero counts,
    # never raises. Mirrors the Rule 18 phantom-cleanup discipline
    # used by ``delete_listing`` / ``delete_application``.
    #
    # CONTENT-only delete: the parent directories
    # (``career/facts/``, ``career/inbox/``, etc.) stay in place so
    # the existing watchers, scaffolding, and Rule 18 layout
    # invariants keep working. Only files + the per-application
    # subdirectories are removed.

    _FORGET_ALL_DIRS = (
        ("facts", _FACTS_DIR),
        ("listings", _LISTINGS_DIR),
        ("applications", _APPLICATIONS_DIR),
        ("library", "career/library"),
        ("inbox", "career/inbox"),
    )

    def _scan_forget_all_inventory(self) -> dict[str, dict[str, Any]]:
        """Pure-ish helper: walk each forget-all dir and count files.

        Returns ``{category: {file_count, removed_paths}}`` where
        ``removed_paths`` is the list of file paths relative to the
        category root (used for the activity event's audit detail).

        Never raises; missing dirs simply report zero counts. Lock-in
        with ``_FORGET_ALL_DIRS`` ensures any future addition to the
        category list propagates automatically through inventory +
        wipe + tests.
        """
        inventory: dict[str, dict[str, Any]] = {}
        for label, rel_dir in self._FORGET_ALL_DIRS:
            phys_dir = self._paths.resolve(rel_dir)
            files: list[str] = []
            if phys_dir.is_dir():
                try:
                    for entry in phys_dir.rglob("*"):
                        if entry.is_file():
                            try:
                                files.append(entry.relative_to(phys_dir).as_posix())
                            except ValueError:
                                # Symlink or path-outside-root edge case.
                                # Skip rather than crash the inventory.
                                continue
                except OSError as exc:
                    log.warning("Could not walk %s for forget-all: %s", phys_dir, exc)
            inventory[label] = {
                "file_count": len(files),
                "removed_paths": files,
            }
        return inventory

    def forget_all(self, *, confirm: bool = False) -> dict[str, Any]:
        """Wipe ALL career data when ``confirm=True``; otherwise dry-run.

        Args:
            confirm: When False (default) returns the inventory WITHOUT
                deleting anything. When True, actually wipes every file
                under ``career/{facts,listings,applications,library,inbox}/``.

        Returns:
            ``{
                wiped: bool,                  # echoes confirm
                total_files: int,             # aggregate count
                categories: {
                    facts: {file_count, removed_paths},
                    listings: {file_count, removed_paths},
                    applications: {file_count, removed_paths},
                    library: {file_count, removed_paths},
                    inbox: {file_count, removed_paths},
                },
                errors: list[str],            # per-file errors during wipe
            }``

        Idempotent on empty vault (returns zero counts).
        Files are deleted; parent directories survive so watchers,
        scaffolding, and Rule 18 layout invariants keep working.

        Architectural commitment: a single high-importance
        ``career_forget_all`` activity event fires on wipe (NOT on
        dry-run). The event details carry the per-category file lists
        so the audit trail survives the data wipe.
        """
        inventory = self._scan_forget_all_inventory()
        total_files = sum(cat["file_count"] for cat in inventory.values())

        if not confirm:
            return {
                "wiped": False,
                "total_files": total_files,
                "categories": inventory,
                "errors": [],
            }

        errors: list[str] = []
        for label, rel_dir in self._FORGET_ALL_DIRS:
            phys_dir = self._paths.resolve(rel_dir)
            if not phys_dir.is_dir():
                continue
            try:
                for entry in sorted(phys_dir.iterdir()):
                    try:
                        if entry.is_file() or entry.is_symlink():
                            entry.unlink()
                        elif entry.is_dir():
                            import shutil
                            shutil.rmtree(entry)
                    except OSError as exc:
                        errors.append(f"{label}:{entry.name}:{type(exc).__name__}:{exc}")
            except OSError as exc:
                errors.append(f"{label}:iterdir:{type(exc).__name__}:{exc}")

        # Single aggregate event AFTER the wipe. High importance because
        # destructive + irreversible. Carries per-category audit detail
        # so the trail survives the data wipe.
        self._log_activity(
            action="career_forget_all",
            summary=(
                f"Career forget-all wiped {total_files} file(s) "
                f"across {sum(1 for c in inventory.values() if c['file_count'])} categories"
            ),
            importance="high",
            details={
                "total_files": total_files,
                "categories": {
                    label: cat["file_count"] for label, cat in inventory.items()
                },
                "errors": errors,
            },
        )

        return {
            "wiped": True,
            "total_files": total_files,
            "categories": inventory,
            "errors": errors,
        }

    # ==================================================================
    # Applications (Phase 3 Slice B Part 2) — JD gap analysis
    # ==================================================================
    #
    # Reads the listing's JD + the candidate's facts/, calls the LLM
    # analyzer in ``agntspace.career.jd_analyzer``, writes
    # ``applications/<slug>/jd_analysis.md``, appends ``jd_analysis.md``
    # to the application's ``generated_assets``. Optionally moves status
    # ``draft → preparing`` so the user sees forward motion on the
    # pipeline.
    #
    # Slice C's CV builder + cover letter generator read the written
    # ``jd_analysis.md`` as their anti-fabrication ground truth.

    def _read_listing_body(self, listing_slug: str) -> str:
        """Return the raw JD body for a listing slug (empty on miss)."""
        rel = self._listing_path(listing_slug)
        try:
            doc = self._reader.read(rel)
            return doc.content or ""
        except FileNotFoundError:
            return ""
        except Exception:  # noqa: BLE001 — fail-soft
            log.debug("career: could not read listing %s", listing_slug, exc_info=True)
            return ""

    def _read_facts_for_llm(self) -> str:
        """Concatenate every fact file's body for the analyzer prompt.

        Returns a single text blob with section dividers so the LLM can
        navigate. Missing files contribute nothing. Empty / template-only
        files surface as a marker so the analyzer can flag them.
        """
        parts: list[str] = []
        for category in FACT_CATEGORIES:
            rel = self._path_for(category)
            phys = self._paths.resolve(rel)
            if not phys.is_file():
                continue
            try:
                doc = self._reader.read(rel)
                body = (doc.content or "").strip()
            except Exception:  # noqa: BLE001
                log.debug("career: could not read fact %s", rel, exc_info=True)
                continue
            if not body:
                continue
            parts.append(f"## {category.replace('-', ' ').title()}\n\n{body}\n")
        return "\n".join(parts).strip()

    async def analyze_application_gaps(
        self,
        slug: str,
        *,
        force_refresh: bool = True,
    ) -> dict[str, Any]:
        """Run JD gap analysis for an application.

        Pipeline:
        1. Read application metadata → resolve listing_slug.
        2. Read listing's JD body.
        3. Concatenate the candidate's facts/ files.
        4. Call ``analyze_gaps_via_llm`` at capable tier.
        5. Render the result as ``jd_analysis.md``.
        6. Write the file inside the application folder.
        7. Append ``jd_analysis.md`` to generated_assets if not already there.
        8. If application status was ``draft`` and the analysis succeeded,
           promote to ``preparing``.

        Args:
            slug: application slug. Invalid slug → KeyError → 400.
            force_refresh: when False AND ``jd_analysis.md`` already
                exists, return the existing analysis without an LLM
                call. Default True (always re-run).

        Returns the result dict (see body for shape).

        Raises:
            KeyError: invalid slug → route 400.
            FileNotFoundError: valid slug but no metadata.md on disk
                → route 404.
        """
        from agntspace.career.jd_analyzer import (
            analyze_gaps_via_llm,
            render_gap_report_markdown,
            resolve_config,
        )

        slug = self._validate_slug(slug)
        rel = self._application_metadata_path(slug)
        # Surface 404 cleanly when the application doesn't exist.
        doc = self._reader.read(rel)  # raises FileNotFoundError naturally
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        listing_slug = str(meta.get("listing_slug", "")).strip()
        if not listing_slug:
            return {
                "ok": False,
                "reason": "application_missing_listing_slug",
                "slug": slug,
                "message": (
                    "This application's metadata.md is missing the "
                    "listing_slug field. Fix manually or recreate the "
                    "application."
                ),
            }

        # Master kill switch check — give a clean diagnostic before any
        # LLM is touched.
        cfg = resolve_config(self._skill_loader)
        if not cfg.get("enabled", True):
            return {
                "ok": False,
                "reason": "analyzer_disabled",
                "slug": slug,
                "message": (
                    "Career JD analyzer is disabled in "
                    "_meta/career-jd-analyzer/config/analyze.yaml. "
                    "Flip enabled: true to re-enable."
                ),
            }

        # Idempotency short-circuit — return the existing rendered file
        # if force_refresh is False and the file is on disk.
        analysis_rel = f"{self._application_folder(slug)}/jd_analysis.md"
        analysis_phys = self._paths.resolve(analysis_rel)
        if not force_refresh and analysis_phys.is_file():
            return {
                "ok": True,
                "slug": slug,
                "listing_slug": listing_slug,
                "path": analysis_rel,
                "cached": True,
            }

        if self._agent is None:
            return {
                "ok": False,
                "reason": "agent_not_wired",
                "slug": slug,
                "message": (
                    "Career analyzer is unwired (no Agent attached). "
                    "This is a server-config issue; check main.py."
                ),
            }

        jd_text = self._read_listing_body(listing_slug)
        if not jd_text.strip():
            return {
                "ok": False,
                "reason": "listing_jd_empty",
                "slug": slug,
                "listing_slug": listing_slug,
                "message": (
                    f"Listing {listing_slug!r} has no JD body on disk. "
                    "Open the listing and paste the JD or re-import the URL."
                ),
            }

        facts_text = self._read_facts_for_llm()

        try:
            report = await analyze_gaps_via_llm(
                jd_text,
                facts_text,
                agent=self._agent,
                skill_loader=self._skill_loader,
                cfg=cfg,
            )
        except Exception:  # noqa: BLE001 — analyzer is fail-soft; this is belt-and-braces
            log.exception("career: analyze_gaps_via_llm raised unexpectedly")
            return {
                "ok": False,
                "reason": "analyzer_crashed",
                "slug": slug,
                "listing_slug": listing_slug,
                "message": "Analyzer crashed unexpectedly. Check server logs.",
            }

        if not report.has_minimum_signal:
            return {
                "ok": False,
                "reason": "no_usable_signal",
                "slug": slug,
                "listing_slug": listing_slug,
                "message": (
                    "LLM did not produce a usable gap report. Common "
                    "causes: malformed JSON response, model timeout, "
                    "or LLM tier too weak. Re-run; if it persists, "
                    "check the analyzer config."
                ),
            }

        markdown = render_gap_report_markdown(
            report,
            application_slug=slug,
            listing_slug=listing_slug,
        )

        # Write the analysis file. versioned=True so re-runs land in
        # .history/ for safety — the user can recover a prior analysis
        # if the new one drifted.
        self._writer.write(
            analysis_rel,
            markdown,
            versioned=True,
            trust_reason="career_application_analyze_gaps",
        )

        # Append jd_analysis.md to generated_assets if not already there.
        assets = meta.get("generated_assets", [])
        if not isinstance(assets, list):
            assets = []
        if "jd_analysis.md" not in assets:
            assets.append("jd_analysis.md")
            meta["generated_assets"] = [str(a) for a in assets]
            import frontmatter as _fm  # local import — keep top of file thin
            new_content = _fm.dumps(_fm.Post(doc.content or "", **meta))
            self._writer.write(
                rel,
                new_content,
                versioned=True,
                trust_reason="career_application_edit",
            )

        # Promote draft → preparing so the user sees forward motion on
        # the pipeline. Other statuses left alone.
        prev_status = str(meta.get("status", "draft"))
        status_promoted = False
        if prev_status == "draft":
            try:
                self.update_application_status(
                    slug, "preparing",
                    note="Status auto-promoted by JD gap analysis.",
                )
                status_promoted = True
            except Exception:  # noqa: BLE001 — promotion failure shouldn't break the analysis
                log.debug(
                    "career: could not auto-promote status for %s", slug,
                    exc_info=True,
                )

        self._log_activity(
            action="career_application_analyzed",
            summary=(
                f"Career application gap-analyzed: {slug} "
                f"(covered={len(report.covered)}, "
                f"partial={len(report.partial)}, "
                f"missing={len(report.missing)})"
            ),
            importance="medium",
            details={
                "slug": slug,
                "listing_slug": listing_slug,
                "covered_count": len(report.covered),
                "partial_count": len(report.partial),
                "missing_count": len(report.missing),
                "coverage_ratio": report.coverage_ratio,
                "status_promoted": status_promoted,
            },
        )

        return {
            "ok": True,
            "slug": slug,
            "listing_slug": listing_slug,
            "path": analysis_rel,
            "covered_count": len(report.covered),
            "partial_count": len(report.partial),
            "missing_count": len(report.missing),
            "total_requirements": (
                len(report.covered) + len(report.partial) + len(report.missing)
            ),
            "coverage_ratio": report.coverage_ratio,
            "honest_summary": report.honest_summary,
            "status_promoted": status_promoted,
            "previous_status": prev_status,
        }

    # ==================================================================
    # Applications (Phase 3 Slice C) — CV + cover letter builders
    # ==================================================================
    #
    # Both builders read the previously-generated jd_analysis.md as the
    # anti-fabrication ground truth. If no analysis exists, both refuse
    # with reason="missing_gap_report" and instruct the user to run
    # analyze-gaps first. This contract is load-bearing — without the
    # gap report, the builders have no MISSING list to exclude and the
    # anti-fabrication guarantee collapses.

    def _read_gap_report_dict(self, slug: str) -> dict[str, Any] | None:
        """Read ``applications/<slug>/jd_analysis.md`` and reconstruct
        the gap-report dict the builders consume.

        Returns ``None`` when the file is missing OR malformed.

        Two paths, preferred → fallback:

        1. **Frontmatter ``gap_report_json``** (post-tightening canonical
           source). Single-line JSON string carrying the structured
           shape verbatim. If the user hand-edits the markdown body
           (adds notes, deletes bullets), the JSON in frontmatter
           still round-trips cleanly. This is the load-bearing
           anti-fabrication contract for the CV/cover-letter builders.

        2. **Markdown body re-parse** (legacy, pre-tightening). Files
           already on disk from before the JSON-stash shipment don't
           carry the frontmatter field — fall back to walking the
           rendered sections. Brittle (user edits to the body leak
           into the parse) but only fires for legacy files; a re-run
           of analyze-gaps writes the JSON field and the path returns
           to the canonical surface forever.
        """
        analysis_rel = f"{self._application_folder(slug)}/jd_analysis.md"
        analysis_phys = self._paths.resolve(analysis_rel)
        if not analysis_phys.is_file():
            return None
        try:
            doc = self._reader.read(analysis_rel)
        except Exception:  # noqa: BLE001
            log.debug("career: could not read gap report %s", analysis_rel, exc_info=True)
            return None
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        body = doc.content or ""

        # ── Preferred path: frontmatter gap_report_json ─────────────
        raw_json = meta.get("gap_report_json")
        if isinstance(raw_json, str) and raw_json.strip():
            try:
                import json as _json
                parsed = _json.loads(raw_json)
            except Exception:  # noqa: BLE001
                log.debug(
                    "career: gap_report_json malformed for %s, falling back to body parse",
                    slug, exc_info=True,
                )
                parsed = None
            if isinstance(parsed, dict):
                # Defensive shape coercion — drop non-list / non-string
                # entries silently so a corrupt JSON can't poison the
                # builder downstream. Same fail-soft posture the
                # legacy parser uses.
                covered = [
                    s for s in parsed.get("covered", [])
                    if isinstance(s, str) and s.strip()
                ]
                partial_raw = parsed.get("partial", [])
                partial: list[dict[str, str]] = []
                if isinstance(partial_raw, list):
                    for item in partial_raw:
                        if isinstance(item, dict):
                            req = str(item.get("requirement", "")).strip()
                            if not req:
                                continue
                            partial.append({
                                "requirement": req,
                                "gap": str(item.get("gap", "")).strip(),
                            })
                missing = [
                    s for s in parsed.get("missing", [])
                    if isinstance(s, str) and s.strip()
                ]
                honest = str(parsed.get("honest_summary", "")).strip()
                return {
                    "covered": covered,
                    "partial": partial,
                    "missing": missing,
                    "honest_summary": honest,
                }

        # ── Fallback path: re-parse the rendered markdown body ──────
        # (Legacy — only fires for files written before the
        # gap_report_json field shipped. Subject to the user-edit
        # leakage class noted above; running analyze-gaps once
        # rewrites the file with the JSON field and the preferred
        # path takes over forever.)
        covered: list[str] = []
        partial: list[dict[str, str]] = []
        missing: list[str] = []
        honest_summary = ""

        section = None
        # Match ``## Honest Summary``, ``## Covered (N)``, ``## Partial
        # (N)``, ``## Missing (N)``.
        summary_lines: list[str] = []
        for raw_line in body.splitlines():
            line = raw_line.rstrip()
            if line.startswith("## Honest Summary"):
                section = "summary"
                continue
            if line.startswith("## Covered"):
                section = "covered"
                continue
            if line.startswith("## Partial"):
                section = "partial"
                continue
            if line.startswith("## Missing"):
                section = "missing"
                continue
            if line.startswith("## ") or line.startswith("---"):
                section = None
                continue
            if section == "summary":
                summary_lines.append(line)
            elif section == "covered" and line.startswith("- "):
                item = line[2:].strip()
                if item and item != "_None._":
                    covered.append(item)
            elif section == "partial" and line.startswith("- "):
                item = line[2:].strip()
                if not item or item == "_None._":
                    continue
                # Match ``**Requirement** — _gap_`` or ``**Requirement**``.
                m = re.match(r"\*\*(.+?)\*\*(?:\s*—\s*_(.+?)_)?$", item)
                if m:
                    req = m.group(1).strip()
                    gap = (m.group(2) or "").strip()
                    partial.append({"requirement": req, "gap": gap})
                else:
                    partial.append({"requirement": item, "gap": ""})
            elif section == "missing" and line.startswith("- "):
                item = line[2:].strip()
                if item and item != "_None._":
                    missing.append(item)

        honest_summary = " ".join(s for s in summary_lines if s.strip()).strip()

        return {
            "covered": covered,
            "partial": partial,
            "missing": missing,
            "honest_summary": honest_summary,
        }

    async def build_application_cv(
        self,
        slug: str,
        *,
        force_refresh: bool = True,
    ) -> dict[str, Any]:
        """Build a tailored CV .docx for an application.

        Pipeline mirrors analyze_application_gaps — read application
        metadata, read listing JD, read gap report, read facts/, LLM
        build via cv_builder.py, render to .docx, append cv.docx to
        generated_assets, auto-promote draft→preparing.

        Requires a prior jd_analysis.md (the gap report is the
        anti-fabrication ground truth). Returns
        ``{ok: False, reason: "missing_gap_report"}`` if not present.

        Args:
            slug: application slug.
            force_refresh: when False AND cv.docx exists on disk,
                short-circuit. Default True.

        Raises:
            KeyError: invalid slug → 400.
            FileNotFoundError: valid slug but no metadata.md → 404.
        """
        from agntspace.career.cv_builder import (
            build_cv_content_via_llm,
            render_cv_to_docx,
        )
        from agntspace.career.cv_builder import (
            resolve_config as resolve_cv_config,
        )

        slug = self._validate_slug(slug)
        rel = self._application_metadata_path(slug)
        doc = self._reader.read(rel)  # raises FileNotFoundError naturally
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        listing_slug = str(meta.get("listing_slug", "")).strip()
        if not listing_slug:
            return {
                "ok": False,
                "reason": "application_missing_listing_slug",
                "slug": slug,
                "message": (
                    "This application's metadata.md is missing the "
                    "listing_slug field. Fix manually or recreate the "
                    "application."
                ),
            }

        cfg = resolve_cv_config(self._skill_loader)
        if not cfg.get("enabled", True):
            return {
                "ok": False,
                "reason": "builder_disabled",
                "slug": slug,
                "message": (
                    "Career CV builder is disabled in "
                    "_meta/career-cv-builder/config/build.yaml. "
                    "Flip enabled: true to re-enable."
                ),
            }

        cv_rel = f"{self._application_folder(slug)}/cv.docx"
        cv_phys = self._paths.resolve(cv_rel)
        if not force_refresh and cv_phys.is_file():
            return {
                "ok": True,
                "slug": slug,
                "listing_slug": listing_slug,
                "path": cv_rel,
                "cached": True,
            }

        if self._agent is None:
            return {
                "ok": False,
                "reason": "agent_not_wired",
                "slug": slug,
                "message": "CV builder is unwired (no Agent attached).",
            }

        gap_report = self._read_gap_report_dict(slug)
        if gap_report is None:
            return {
                "ok": False,
                "reason": "missing_gap_report",
                "slug": slug,
                "message": (
                    f"No jd_analysis.md found for application {slug!r}. "
                    "Run analyze-gaps first — the gap report is the "
                    "anti-fabrication ground truth for the CV builder."
                ),
            }

        jd_text = self._read_listing_body(listing_slug)
        if not jd_text.strip():
            return {
                "ok": False,
                "reason": "listing_jd_empty",
                "slug": slug,
                "listing_slug": listing_slug,
                "message": f"Listing {listing_slug!r} has no JD body.",
            }

        facts_text = self._read_facts_for_llm()
        if not facts_text.strip():
            return {
                "ok": False,
                "reason": "no_facts_on_file",
                "slug": slug,
                "message": (
                    "No career/facts/ content found. Fill in your facts "
                    "via the FactsPage before building a CV."
                ),
            }

        # Resolve candidate name from USER.md if present (best-effort).
        candidate_name = self._read_candidate_name()

        try:
            content = await build_cv_content_via_llm(
                jd_text=jd_text,
                facts_text=facts_text,
                gap_report=gap_report,
                agent=self._agent,
                skill_loader=self._skill_loader,
                cfg=cfg,
            )
        except Exception:  # noqa: BLE001
            log.exception("career: build_cv_content_via_llm raised unexpectedly")
            return {
                "ok": False,
                "reason": "builder_crashed",
                "slug": slug,
                "message": "CV builder crashed unexpectedly. Check server logs.",
            }

        if content.is_empty:
            return {
                "ok": False,
                "reason": "no_usable_content",
                "slug": slug,
                "listing_slug": listing_slug,
                "message": (
                    "LLM did not produce usable CV content. Common "
                    "causes: malformed JSON response, model timeout, "
                    "facts/ files are all template-only."
                ),
            }

        # Render directly to the physical path via python-docx — the
        # docx isn't VaultWriter-friendly (binary, no versioning).
        # We bypass VaultWriter for the actual write but DO touch the
        # metadata.md update through VaultWriter so the runtime guard
        # accepts the generated_assets append.
        ok = render_cv_to_docx(
            content,
            output_path=cv_phys,
            cfg=cfg,
            candidate_name=candidate_name,
        )
        if not ok:
            return {
                "ok": False,
                "reason": "docx_render_failed",
                "slug": slug,
                "message": (
                    "python-docx render failed. Ensure the `documents` "
                    "extra is installed (`pip install agntspace[documents]`)."
                ),
            }

        # Append cv.docx to generated_assets.
        assets = meta.get("generated_assets", [])
        if not isinstance(assets, list):
            assets = []
        if "cv.docx" not in assets:
            assets.append("cv.docx")
            meta["generated_assets"] = [str(a) for a in assets]
            import frontmatter as _fm
            new_content = _fm.dumps(_fm.Post(doc.content or "", **meta))
            self._writer.write(
                rel,
                new_content,
                versioned=True,
                trust_reason="career_application_edit",
            )

        # Promote draft → preparing.
        prev_status = str(meta.get("status", "draft"))
        status_promoted = False
        if prev_status == "draft":
            try:
                self.update_application_status(
                    slug, "preparing",
                    note="Status auto-promoted by CV build.",
                )
                status_promoted = True
            except Exception:  # noqa: BLE001
                log.debug(
                    "career: could not auto-promote status for %s", slug,
                    exc_info=True,
                )

        self._log_activity(
            action="career_application_cv_built",
            summary=f"Career CV built for application {slug}",
            importance="medium",
            details={
                "slug": slug,
                "listing_slug": listing_slug,
                "experience_count": len(content.experience),
                "skills_count": len(content.skills),
                "status_promoted": status_promoted,
            },
        )

        return {
            "ok": True,
            "slug": slug,
            "listing_slug": listing_slug,
            "path": cv_rel,
            "experience_count": len(content.experience),
            "education_count": len(content.education),
            "skills_count": len(content.skills),
            "projects_count": len(content.projects),
            "achievements_count": len(content.achievements),
            "status_promoted": status_promoted,
            "previous_status": prev_status,
        }

    async def build_application_cover_letter(
        self,
        slug: str,
        *,
        force_refresh: bool = True,
    ) -> dict[str, Any]:
        """Build a tailored cover letter .docx for an application.

        Same pipeline shape as build_application_cv — read application
        metadata, read listing JD + company/role/recruiter from listing
        frontmatter, read gap report, read facts/, LLM build, render
        .docx, append to generated_assets, auto-promote draft→preparing.

        Requires a prior jd_analysis.md.
        """
        from agntspace.career.cover_letter import (
            build_cover_letter_via_llm,
            render_cover_letter_to_docx,
        )
        from agntspace.career.cover_letter import (
            resolve_config as resolve_cl_config,
        )

        slug = self._validate_slug(slug)
        rel = self._application_metadata_path(slug)
        doc = self._reader.read(rel)
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        listing_slug = str(meta.get("listing_slug", "")).strip()
        if not listing_slug:
            return {
                "ok": False,
                "reason": "application_missing_listing_slug",
                "slug": slug,
                "message": (
                    "This application's metadata.md is missing the "
                    "listing_slug field. Fix manually or recreate."
                ),
            }

        cfg = resolve_cl_config(self._skill_loader)
        if not cfg.get("enabled", True):
            return {
                "ok": False,
                "reason": "builder_disabled",
                "slug": slug,
                "message": (
                    "Career cover letter builder is disabled in "
                    "_meta/career-cover-letter/config/build.yaml."
                ),
            }

        cl_rel = f"{self._application_folder(slug)}/cover_letter.docx"
        cl_phys = self._paths.resolve(cl_rel)
        if not force_refresh and cl_phys.is_file():
            return {
                "ok": True,
                "slug": slug,
                "listing_slug": listing_slug,
                "path": cl_rel,
                "cached": True,
            }

        if self._agent is None:
            return {
                "ok": False,
                "reason": "agent_not_wired",
                "slug": slug,
                "message": "Cover letter builder is unwired.",
            }

        gap_report = self._read_gap_report_dict(slug)
        if gap_report is None:
            return {
                "ok": False,
                "reason": "missing_gap_report",
                "slug": slug,
                "message": (
                    f"No jd_analysis.md found for application {slug!r}. "
                    "Run analyze-gaps first."
                ),
            }

        # Read listing frontmatter for company/role/recruiter.
        try:
            listing_doc = self._reader.read(self._listing_path(listing_slug))
            listing_meta = (
                dict(listing_doc.metadata) if isinstance(listing_doc.metadata, dict) else {}
            )
            jd_text = listing_doc.content or ""
        except FileNotFoundError:
            return {
                "ok": False,
                "reason": "listing_not_found",
                "slug": slug,
                "listing_slug": listing_slug,
                "message": (
                    f"Listing {listing_slug!r} not on disk. Was the "
                    "listing deleted after this application was created?"
                ),
            }

        if not jd_text.strip():
            return {
                "ok": False,
                "reason": "listing_jd_empty",
                "slug": slug,
                "listing_slug": listing_slug,
                "message": f"Listing {listing_slug!r} has no JD body.",
            }

        facts_text = self._read_facts_for_llm()
        if not facts_text.strip():
            return {
                "ok": False,
                "reason": "no_facts_on_file",
                "slug": slug,
                "message": (
                    "No career/facts/ content found. Fill in your facts "
                    "before building a cover letter."
                ),
            }

        company = str(listing_meta.get("company", "")).strip()
        role = str(listing_meta.get("role", "")).strip()
        recruiter = str(listing_meta.get("recruiter", "")).strip()

        try:
            content = await build_cover_letter_via_llm(
                jd_text=jd_text,
                facts_text=facts_text,
                gap_report=gap_report,
                company=company,
                role=role,
                recruiter=recruiter,
                agent=self._agent,
                skill_loader=self._skill_loader,
                cfg=cfg,
            )
        except Exception:  # noqa: BLE001
            log.exception("career: build_cover_letter_via_llm raised unexpectedly")
            return {
                "ok": False,
                "reason": "builder_crashed",
                "slug": slug,
                "message": "Cover letter builder crashed unexpectedly.",
            }

        if content.is_empty:
            return {
                "ok": False,
                "reason": "no_usable_content",
                "slug": slug,
                "listing_slug": listing_slug,
                "message": (
                    "LLM did not produce a usable cover letter. Common "
                    "causes: malformed JSON response, model timeout."
                ),
            }

        ok = render_cover_letter_to_docx(
            content,
            output_path=cl_phys,
            cfg=cfg,
        )
        if not ok:
            return {
                "ok": False,
                "reason": "docx_render_failed",
                "slug": slug,
                "message": "python-docx render failed.",
            }

        assets = meta.get("generated_assets", [])
        if not isinstance(assets, list):
            assets = []
        if "cover_letter.docx" not in assets:
            assets.append("cover_letter.docx")
            meta["generated_assets"] = [str(a) for a in assets]
            import frontmatter as _fm
            new_content = _fm.dumps(_fm.Post(doc.content or "", **meta))
            self._writer.write(
                rel,
                new_content,
                versioned=True,
                trust_reason="career_application_edit",
            )

        prev_status = str(meta.get("status", "draft"))
        status_promoted = False
        if prev_status == "draft":
            try:
                self.update_application_status(
                    slug, "preparing",
                    note="Status auto-promoted by cover-letter build.",
                )
                status_promoted = True
            except Exception:  # noqa: BLE001
                log.debug(
                    "career: could not auto-promote status for %s", slug,
                    exc_info=True,
                )

        self._log_activity(
            action="career_application_cover_letter_built",
            summary=f"Career cover letter built for application {slug}",
            importance="medium",
            details={
                "slug": slug,
                "listing_slug": listing_slug,
                "company": company,
                "role": role,
                "status_promoted": status_promoted,
            },
        )

        return {
            "ok": True,
            "slug": slug,
            "listing_slug": listing_slug,
            "path": cl_rel,
            "company": company,
            "role": role,
            "status_promoted": status_promoted,
            "previous_status": prev_status,
        }

    def _read_candidate_name(self) -> str:
        """Best-effort read of the candidate name from USER.md.

        Looks for a ``Name:`` field in the kv-style identity block.
        Empty string when missing — the CV renderer just omits the
        title row.
        """
        try:
            doc = self._reader.read("system/identity/USER.md")
        except Exception:  # noqa: BLE001
            return ""
        body = doc.content or ""
        # Match ``- **Name**: Some Name`` or ``Name: Some Name``.
        m = re.search(r"^\s*-?\s*\*?\*?Name\*?\*?\s*:\s*(.+?)\s*$", body, re.MULTILINE)
        if not m:
            return ""
        value = m.group(1).strip()
        # Drop bracketed placeholders.
        if value.startswith("[") and value.endswith("]"):
            return ""
        return value
