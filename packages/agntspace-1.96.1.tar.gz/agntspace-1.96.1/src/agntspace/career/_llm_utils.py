"""Shared helpers used by the career LLM-driven engines.

Three small utilities consumed by both ``cv_builder.py`` and
``cover_letter.py``. Extracted to a sibling module so cover_letter
doesn't import private (``_``-prefixed) names from cv_builder — that
boundary violation made the contract drift-prone (a future cv_builder
refactor renaming ``_str`` would silently break cover_letter at import
time).

This module is intentionally tiny + dependency-free. Adding logic here
should be limited to text-coercion primitives used by ≥ 2 career
engines. Engine-specific helpers live in their own module.
"""
from __future__ import annotations

from typing import Any


def coerce_str(value: Any) -> str:
    """Defensive string coercion.

    Returns:
        - Trimmed string for str / int / float / other str()-compatible values.
        - Empty string for None or values whose ``str()`` raises.

    Used by the JSON-output parsers in ``cv_builder`` and
    ``cover_letter`` to defend against malformed LLM output (the LLM
    might return a numeric where the schema expects a string).
    """
    if isinstance(value, str):
        return value.strip()
    if value is None:
        return ""
    try:
        return str(value).strip()
    except Exception:  # noqa: BLE001 — fail-soft per career engine contract
        return ""


def render_bullet_block(items: list[Any], empty_marker: str = "(none)") -> str:
    """Render a list as a markdown bullet block for an LLM prompt.

    Handles three input shapes per item:
        - ``str`` — rendered as ``- {item}``.
        - ``dict`` with ``requirement`` key — rendered as
          ``- {requirement}`` (with optional ``(gap: {gap})`` tail when
          a non-empty ``gap`` field is present). Matches the
          GapReport.partial shape.
        - Any other type — coerced via ``coerce_str``; dropped if
          coercion yields empty.

    Returns ``empty_marker`` (default ``(none)``) when the list is
    empty or every item drops out. The marker is load-bearing — an
    empty bullet block in the LLM prompt would prompt the model to
    invent content.
    """
    if not items:
        return empty_marker
    lines: list[str] = []
    for item in items:
        if isinstance(item, dict):
            req = coerce_str(item.get("requirement", ""))
            gap = coerce_str(item.get("gap", ""))
            if not req:
                continue
            if gap:
                lines.append(f"- {req} (gap: {gap})")
            else:
                lines.append(f"- {req}")
        else:
            s = coerce_str(item)
            if s:
                lines.append(f"- {s}")
    return "\n".join(lines) if lines else empty_marker


__all__ = [
    "coerce_str",
    "render_bullet_block",
]
