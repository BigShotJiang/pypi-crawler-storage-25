"""Career CV builder — Phase 3 Slice C (2026-05-19 night-7).

For a given application, generates a tailored CV ``.docx`` grounded in
the candidate's ``career/facts/`` files and the gap report produced by
``jd_analyzer.py``. Three architectural layers of anti-fabrication
defense:

1. **Facts/ files are the only source of resume content.** The LLM is
   explicitly forbidden from inventing employers, titles, dates, skills,
   or quantified outcomes the facts/ don't show. Empty fields are the
   correct shape for "candidate has nothing for this section" — the CV
   omits sections rather than padding them.

2. **Gap report is the anti-fabrication FLOOR.** Every requirement
   classified ``missing`` or ``partial`` in ``jd_analysis.md`` is fed
   to the prompt as a hard exclusion list: the CV MAY emphasise
   ``covered`` requirements, MUST NOT claim mastery of ``missing``
   ones, MAY mention ``partial`` ones with honest framing.

3. **Post-generation lint.** After the LLM produces CV content, the
   builder cross-checks every requirement-language phrase against
   ``missing``; if the LLM slipped a hallucinated claim through, the
   builder strips it before writing the .docx. Belt-and-braces — the
   prompt should catch this, the lint is the safety net.

**Architectural commitments**:

- **Pure functions where possible.** ``parse_cv_sections`` and
  ``check_for_missing_claim_leakage`` are testable in isolation.
- **Strategy in YAML** (Rule 12): every prompt token, every section
  ordering, every formatting choice lives in
  ``_meta/career-cv-builder/config/build.yaml``. Engine reads via
  ``SkillLoader.load_skill_config_file`` with a deterministic
  ``_FALLBACK_CONFIG`` tagged ``# arch:deterministic``.
- **Capable tier minimum.** Multi-section structured-output with
  cross-section coupling (employment dates ↔ duration claims ↔
  skill recency) is exactly the workload that needs ≥ capable tier.
- **Fail-soft.** Missing python-docx, missing LLM, JSON parse failure,
  oversized facts — all return either an error result or an empty
  builder result. NEVER raises into the caller.
- **Reads jd_analysis.md before the LLM call.** If the file doesn't
  exist, the builder fails with ``reason="missing_gap_report"`` and
  instructs the user to run analyze-gaps first.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agntspace.agent.agent import Agent
    from agntspace.skills.loader import SkillLoader

log = logging.getLogger(__name__)


# ── Module-level constants ─────────────────────────────────────────────────

# Deterministic fallback when the YAML config is missing / malformed.
_FALLBACK_CONFIG: dict[str, Any] = {  # arch:deterministic — engine fallback when YAML missing/broken
    "enabled": True,
    "llm_tier": "capable",
    "llm_max_tokens": 4000,
    "llm_timeout_seconds": 180,
    "max_facts_chars": 60_000,
    "max_jd_chars": 20_000,
    "prompt_template": (
        "You are tailoring a CV for a specific job application. Strict "
        "anti-fabrication discipline:\n\n"
        "RULES (LOAD-BEARING):\n"
        "1. EVERY claim in the CV must be supported by the FACTS section. NEVER invent employers, titles, dates, skills, or quantified outcomes.\n"
        "2. The MISSING list below is a HARD EXCLUSION. NEVER claim the candidate has those requirements. If the JD asks for Kubernetes and MISSING contains 'Kubernetes', the CV must NOT mention Kubernetes anywhere.\n"
        "3. The PARTIAL list is allowed but must be framed HONESTLY. If MISSING shows '5 years Rust' and the candidate has 1 year, say '1 year Rust experience' not '5 years' or '5+ years'.\n"
        "4. EMPHASISE the COVERED items — those are the candidate's strengths against this JD. Lead bullets with measurable impact (numbers, scope).\n"
        "5. Output JSON ONLY. No preamble, no markdown fences, no commentary. The schema is below.\n\n"
        "Return a SINGLE JSON object with EXACTLY these keys:\n"
        '  "headline"         (string — 1-line professional summary tailored to this role)\n'
        '  "summary"          (string — 2-4 sentence professional summary tailored to this role)\n'
        '  "experience"       (list of objects — {{title, company, start, end, bullets: [string]}})\n'
        '  "education"        (list of objects — {{degree, institution, start, end, detail}})\n'
        '  "skills"           (list of strings — only skills present in FACTS, prioritised by JD relevance)\n'
        '  "projects"         (list of objects — {{name, role, outcome}})\n'
        '  "achievements"     (list of strings — quantified achievements from FACTS)\n\n'
        "JOB DESCRIPTION:\n{jd_text}\n\n"
        "GAP REPORT — COVERED requirements (emphasise these):\n{covered_block}\n\n"
        "GAP REPORT — PARTIAL requirements (frame honestly):\n{partial_block}\n\n"
        "GAP REPORT — MISSING requirements (DO NOT CLAIM THESE):\n{missing_block}\n\n"
        "CANDIDATE FACTS (the ONLY source of CV content):\n{facts_text}"
    ),
    # Document layout knobs. Used by python-docx renderer.
    "doc": {
        "title_font": "Calibri",
        "title_size_pt": 18,
        "body_font": "Calibri",
        "body_size_pt": 11,
        "heading_size_pt": 13,
    },
    "section_order": [
        "headline",
        "summary",
        "experience",
        "education",
        "skills",
        "projects",
        "achievements",
    ],
}


# ── Data class ─────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class CvContent:
    """Structured CV content extracted from LLM output.

    Empty fields mean "no content in facts/ for this section" — the
    renderer omits empty sections rather than padding them.
    """
    headline: str = ""
    summary: str = ""
    experience: list[dict[str, Any]] = field(default_factory=list)
    education: list[dict[str, Any]] = field(default_factory=list)
    skills: list[str] = field(default_factory=list)
    projects: list[dict[str, Any]] = field(default_factory=list)
    achievements: list[str] = field(default_factory=list)

    @property
    def is_empty(self) -> bool:
        """True iff every section is empty (LLM produced nothing usable)."""
        return not (
            self.headline.strip()
            or self.summary.strip()
            or self.experience
            or self.education
            or self.skills
            or self.projects
            or self.achievements
        )


# ── Config loader ──────────────────────────────────────────────────────────


def resolve_config(skill_loader: SkillLoader | None) -> dict[str, Any]:
    """Load the ``career-cv-builder`` YAML config with deterministic fallback."""
    if skill_loader is None:
        return _deepcopy_config(_FALLBACK_CONFIG)
    try:
        cfg = skill_loader.load_skill_config_file(
            "career-cv-builder", "build.yaml",
        )
    except Exception:
        log.debug("career-cv-builder: YAML load failed, using fallback", exc_info=True)
        return _deepcopy_config(_FALLBACK_CONFIG)
    if not isinstance(cfg, dict) or not cfg:
        return _deepcopy_config(_FALLBACK_CONFIG)
    merged = _deepcopy_config(_FALLBACK_CONFIG)
    for k, v in cfg.items():
        merged[k] = v
    return merged


def _deepcopy_config(cfg: dict[str, Any]) -> dict[str, Any]:
    """Shallow + one-level-deep copy so nested dicts aren't shared."""
    out = dict(cfg)
    for k, v in out.items():
        if isinstance(v, dict):
            out[k] = dict(v)
        elif isinstance(v, list):
            out[k] = list(v)
    return out


# ── JSON parsing (mirrors jd_analyzer) ─────────────────────────────────────


def parse_cv_sections(output: str) -> dict[str, Any] | None:
    """Parse LLM output as a JSON object holding CV sections.

    Tolerates markdown fences + trailing/leading prose. Returns ``None``
    on any failure. Mirrors ``jd_analyzer._parse_llm_json`` but exposed
    publicly so the CV builder workflow tests can lock the contract.
    """
    if not output or not isinstance(output, str):
        return None
    cleaned = output.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        if len(lines) >= 2:
            inner = "\n".join(lines[1:])
            if inner.rstrip().endswith("```"):
                inner = inner.rstrip()[:-3].rstrip()
            cleaned = inner.strip()
    start = cleaned.find("{")
    if start < 0:
        return None
    depth = 0
    end = -1
    for i in range(start, len(cleaned)):
        c = cleaned[i]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                end = i + 1
                break
    if end < 0:
        return None
    try:
        parsed = json.loads(cleaned[start:end])
    except Exception:
        return None
    if not isinstance(parsed, dict):
        return None
    return parsed


# ── Coercion ───────────────────────────────────────────────────────────────
#
# ``_str`` is a back-compat alias for ``coerce_str`` from
# ``career._llm_utils``. The shared module is where the real
# implementation lives; we re-bind here so existing call sites + tests
# that import ``_str`` from this module keep working without churn.

from agntspace.career._llm_utils import coerce_str as _str  # noqa: E402


def coerce_cv_content(parsed: dict[str, Any]) -> CvContent:
    """Build a ``CvContent`` from a parsed JSON dict.

    Every coercion is defensive — non-string scalars are coerced to
    string; non-dict objects in list-of-objects fields are dropped;
    non-string entries in string-list fields are dropped.
    """
    def _str_list(key: str) -> list[str]:
        raw = parsed.get(key, [])
        if not isinstance(raw, list):
            return []
        out: list[str] = []
        for item in raw:
            s = _str(item)
            if s:
                out.append(s)
        return out

    def _obj_list(key: str, required_field: str) -> list[dict[str, Any]]:
        raw = parsed.get(key, [])
        if not isinstance(raw, list):
            return []
        out: list[dict[str, Any]] = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            req = _str(item.get(required_field, ""))
            if not req:
                continue
            # Normalize bullets to list-of-strings.
            bullets = item.get("bullets", [])
            if not isinstance(bullets, list):
                bullets = []
            else:
                bullets = [_str(b) for b in bullets if _str(b)]
            row: dict[str, Any] = {required_field: req}
            for k, v in item.items():
                if k == required_field:
                    continue
                if k == "bullets":
                    row[k] = bullets
                else:
                    row[k] = _str(v)
            if "bullets" not in row:
                row["bullets"] = bullets
            out.append(row)
        return out

    return CvContent(
        headline=_str(parsed.get("headline", "")),
        summary=_str(parsed.get("summary", "")),
        experience=_obj_list("experience", "title"),
        education=_obj_list("education", "degree"),
        skills=_str_list("skills"),
        projects=_obj_list("projects", "name"),
        achievements=_str_list("achievements"),
    )


# ── Anti-fabrication post-lint ─────────────────────────────────────────────


def check_for_missing_claim_leakage(
    content: CvContent,
    missing: list[str],
) -> list[str]:
    """Detect strings from the MISSING list that leaked into the CV.

    Returns the list of missing terms found anywhere in the CV's
    rendered text. Caller decides whether to strip + retry OR fail.

    Detection is conservative — substring match on lowercase. False
    positives are possible (e.g. MISSING contains "GO" and CV mentions
    "going") but tolerable: the post-lint surfaces the suspicion and
    the user can review. Tightening the check (word-boundary regex,
    fuzzy tokenisation) is a follow-up if false positives become noise.
    """
    if not missing:
        return []
    parts: list[str] = []
    parts.append(content.headline)
    parts.append(content.summary)
    for exp in content.experience:
        parts.append(_str(exp.get("title")))
        parts.append(_str(exp.get("company")))
        for b in exp.get("bullets", []):
            parts.append(_str(b))
    for edu in content.education:
        parts.append(_str(edu.get("degree")))
        parts.append(_str(edu.get("institution")))
        parts.append(_str(edu.get("detail")))
    parts.extend(content.skills)
    for p in content.projects:
        parts.append(_str(p.get("name")))
        parts.append(_str(p.get("role")))
        parts.append(_str(p.get("outcome")))
    parts.extend(content.achievements)
    full_text = " ".join(p for p in parts if p).lower()

    leaks: list[str] = []
    for term in missing:
        if not isinstance(term, str) or not term.strip():
            continue
        if term.strip().lower() in full_text:
            leaks.append(term.strip())
    return leaks


def strip_missing_claim_leakage(
    content: CvContent,
    missing: list[str],
) -> CvContent:
    """Return a new ``CvContent`` with MISSING-list terms removed.

    Conservative: lines that contain a missing term in their text are
    DROPPED entirely (we'd rather omit a bullet than mis-attribute).
    The skills list drops the missing item itself.
    """
    if not missing:
        return content
    missing_lower = {t.strip().lower() for t in missing if isinstance(t, str) and t.strip()}
    if not missing_lower:
        return content

    def _line_has_missing(line: str) -> bool:
        if not isinstance(line, str):
            return False
        low = line.lower()
        return any(m in low for m in missing_lower)

    def _strip_str(value: str) -> str:
        return "" if _line_has_missing(value) else value

    def _strip_list(items: list[str]) -> list[str]:
        return [s for s in items if not _line_has_missing(s)]

    def _strip_experience(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for row in rows:
            new = dict(row)
            new["bullets"] = _strip_list(new.get("bullets", []))
            # Drop the whole row if the title/company itself contains a
            # missing term — would be misleading to keep.
            if _line_has_missing(_str(new.get("title"))) or _line_has_missing(
                _str(new.get("company")),
            ):
                continue
            out.append(new)
        return out

    return CvContent(
        headline=_strip_str(content.headline),
        summary=_strip_str(content.summary),
        experience=_strip_experience(content.experience),
        education=[
            r for r in content.education
            if not (
                _line_has_missing(_str(r.get("degree")))
                or _line_has_missing(_str(r.get("detail")))
            )
        ],
        skills=_strip_list(content.skills),
        projects=[
            r for r in content.projects
            if not (
                _line_has_missing(_str(r.get("name")))
                or _line_has_missing(_str(r.get("outcome")))
            )
        ],
        achievements=_strip_list(content.achievements),
    )


# ── LLM build ──────────────────────────────────────────────────────────────
#
# ``_render_block`` is a back-compat alias for ``render_bullet_block``
# from ``career._llm_utils``. Same rationale as ``_str``: real
# implementation lives in the shared util; existing call sites keep
# their import.

from agntspace.career._llm_utils import render_bullet_block as _render_block  # noqa: E402


async def build_cv_content_via_llm(
    *,
    jd_text: str,
    facts_text: str,
    gap_report: dict[str, Any],
    agent: Agent | None,
    skill_loader: SkillLoader | None = None,
    cfg: dict[str, Any] | None = None,
) -> CvContent:
    """LLM-build structured CV content grounded in facts + gap report.

    Returns an empty ``CvContent`` on any failure (kill switch, missing
    agent, malformed LLM output). Never raises.

    ``gap_report`` is a dict with keys ``covered``, ``partial``,
    ``missing``, ``honest_summary`` — the shape produced by
    ``GapReport.__dict__`` or the analyzer's JSON output.
    """
    config = cfg if cfg is not None else resolve_config(skill_loader)
    if not config.get("enabled", True):
        return CvContent()
    if agent is None:
        return CvContent()
    if not isinstance(jd_text, str) or not jd_text.strip():
        return CvContent()

    max_jd = int(config.get("max_jd_chars", 20_000))
    jd = jd_text.strip()
    if len(jd) > max_jd:
        jd = jd[:max_jd] + "\n\n[... JD truncated ...]"

    max_facts = int(config.get("max_facts_chars", 60_000))
    facts = (facts_text or "").strip()
    if len(facts) > max_facts:
        facts = facts[:max_facts] + "\n\n[... facts truncated ...]"
    if not facts:
        # Without facts, the LLM has nothing to ground claims in.
        return CvContent()

    covered_block = _render_block(gap_report.get("covered", []))
    partial_block = _render_block(gap_report.get("partial", []))
    missing_block = _render_block(gap_report.get("missing", []))

    template = str(config.get("prompt_template", _FALLBACK_CONFIG["prompt_template"]))
    try:
        prompt = template.format(
            jd_text=jd,
            facts_text=facts,
            covered_block=covered_block,
            partial_block=partial_block,
            missing_block=missing_block,
        )
    except (KeyError, ValueError):
        prompt = _FALLBACK_CONFIG["prompt_template"].format(
            jd_text=jd,
            facts_text=facts,
            covered_block=covered_block,
            partial_block=partial_block,
            missing_block=missing_block,
        )

    tier = str(config.get("llm_tier", "capable"))
    try:
        result = await agent.process_task(prompt, model_tier=tier)
    except Exception:
        log.debug("career-cv-builder: LLM call failed", exc_info=True)
        return CvContent()
    if not isinstance(result, str) or not result.strip():
        return CvContent()

    parsed = parse_cv_sections(result)
    if parsed is None:
        log.debug(
            "career-cv-builder: LLM output not parseable as JSON: %r",
            result[:200],
        )
        return CvContent()

    content = coerce_cv_content(parsed)

    # Post-lint anti-fabrication — strip any MISSING-list terms that
    # slipped through the prompt's hard exclusion. Belt-and-braces.
    missing = gap_report.get("missing", [])
    if isinstance(missing, list):
        content = strip_missing_claim_leakage(content, missing)

    return content


# ── DOCX rendering ─────────────────────────────────────────────────────────


def render_cv_to_docx(
    content: CvContent,
    *,
    output_path: Path,
    cfg: dict[str, Any] | None = None,
    candidate_name: str = "",
) -> bool:
    """Render ``CvContent`` to a .docx file at ``output_path``.

    Returns True on successful write, False on any failure (missing
    python-docx, IOError, empty content). Caller decides whether to
    surface failure to the user.

    Empty sections are OMITTED rather than rendered as placeholders —
    no "(none)" or "[TODO: add education]" rows. The result is a clean
    document even when the candidate has gaps.
    """
    if content.is_empty:
        log.debug("career-cv-builder: empty CvContent — refusing to write")
        return False

    try:
        from docx import Document
        from docx.shared import Pt
    except ImportError:
        log.warning(
            "career-cv-builder: python-docx not installed, cannot render CV",
        )
        return False

    config = cfg if cfg is not None else _FALLBACK_CONFIG
    doc_cfg = config.get("doc", {}) if isinstance(config.get("doc"), dict) else {}
    body_font = str(doc_cfg.get("body_font", "Calibri"))
    body_size = int(doc_cfg.get("body_size_pt", 11))
    title_size = int(doc_cfg.get("title_size_pt", 18))
    heading_size = int(doc_cfg.get("heading_size_pt", 13))

    try:
        doc = Document()

        # Candidate name as title (optional).
        if candidate_name.strip():
            title = doc.add_paragraph()
            run = title.add_run(candidate_name.strip())
            run.bold = True
            run.font.size = Pt(title_size)
            run.font.name = body_font

        # Headline (small italic under the name).
        if content.headline.strip():
            headline = doc.add_paragraph()
            run = headline.add_run(content.headline.strip())
            run.italic = True
            run.font.size = Pt(body_size + 1)
            run.font.name = body_font

        def _heading(text: str) -> None:
            p = doc.add_paragraph()
            r = p.add_run(text.upper())
            r.bold = True
            r.font.size = Pt(heading_size)
            r.font.name = body_font

        def _body_para(text: str, *, bullet: bool = False) -> None:
            style = "List Bullet" if bullet else None
            p = doc.add_paragraph(style=style) if style else doc.add_paragraph()
            r = p.add_run(text)
            r.font.size = Pt(body_size)
            r.font.name = body_font

        # Summary
        if content.summary.strip():
            _heading("Summary")
            _body_para(content.summary.strip())

        # Experience
        if content.experience:
            _heading("Experience")
            for row in content.experience:
                title = _str(row.get("title"))
                company = _str(row.get("company"))
                start = _str(row.get("start"))
                end = _str(row.get("end"))
                header_bits: list[str] = []
                if title:
                    header_bits.append(title)
                if company:
                    header_bits.append(company)
                date_bit = ""
                if start or end:
                    date_bit = f" ({start} – {end})" if (start and end) else f" ({start or end})"
                if header_bits:
                    p = doc.add_paragraph()
                    r = p.add_run(" — ".join(header_bits) + date_bit)
                    r.bold = True
                    r.font.size = Pt(body_size)
                    r.font.name = body_font
                for bullet in row.get("bullets", []) or []:
                    if isinstance(bullet, str) and bullet.strip():
                        _body_para(bullet.strip(), bullet=True)

        # Education
        if content.education:
            _heading("Education")
            for row in content.education:
                degree = _str(row.get("degree"))
                institution = _str(row.get("institution"))
                start = _str(row.get("start"))
                end = _str(row.get("end"))
                detail = _str(row.get("detail"))
                line_bits: list[str] = []
                if degree:
                    line_bits.append(degree)
                if institution:
                    line_bits.append(institution)
                date_bit = ""
                if start or end:
                    date_bit = f" ({start} – {end})" if (start and end) else f" ({start or end})"
                if line_bits:
                    p = doc.add_paragraph()
                    r = p.add_run(" — ".join(line_bits) + date_bit)
                    r.bold = True
                    r.font.size = Pt(body_size)
                    r.font.name = body_font
                if detail:
                    _body_para(detail)

        # Skills
        if content.skills:
            _heading("Skills")
            _body_para(", ".join(content.skills))

        # Projects
        if content.projects:
            _heading("Projects")
            for row in content.projects:
                name = _str(row.get("name"))
                role = _str(row.get("role"))
                outcome = _str(row.get("outcome"))
                line_bits: list[str] = []
                if name:
                    line_bits.append(name)
                if role:
                    line_bits.append(role)
                if line_bits:
                    p = doc.add_paragraph()
                    r = p.add_run(" — ".join(line_bits))
                    r.bold = True
                    r.font.size = Pt(body_size)
                    r.font.name = body_font
                if outcome:
                    _body_para(outcome)

        # Achievements
        if content.achievements:
            _heading("Achievements")
            for a in content.achievements:
                _body_para(a, bullet=True)

        output_path.parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(output_path))
        return True
    except Exception:  # noqa: BLE001 — fail-soft
        log.exception("career-cv-builder: docx render failed")
        return False


__all__ = [
    "CvContent",
    "_FALLBACK_CONFIG",
    "build_cv_content_via_llm",
    "check_for_missing_claim_leakage",
    "coerce_cv_content",
    "parse_cv_sections",
    "render_cv_to_docx",
    "resolve_config",
    "strip_missing_claim_leakage",
]
