"""Career subsystem — job search + professional identity management.

Phase 1 (2026-05-19): facts CRUD + 6 default fact-file templates.

Public surface:
    CareerService                — facts CRUD service
    FACT_CATEGORIES              — closed enum of category slugs
    DEFAULT_FACT_TEMPLATES       — boot-time scaffolding source-of-truth

See ``tasks/plan-career-subsystem.md`` for the full architectural plan.
"""
from __future__ import annotations

from agntspace.career.service import CareerService
from agntspace.career.templates import DEFAULT_FACT_TEMPLATES, FACT_CATEGORIES

__all__ = ["CareerService", "DEFAULT_FACT_TEMPLATES", "FACT_CATEGORIES"]
