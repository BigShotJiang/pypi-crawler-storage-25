"""Career cover letter generator — Phase 3 Slice C (2026-05-19 night-7).

For a given application, generates a tailored cover letter ``.docx``
grounded in the candidate's ``career/facts/`` files, the linked
listing's JD, and the gap report's ``honest_summary``.

Anti-fabrication discipline mirrors the CV builder:

1. Facts/ files are the ONLY source of cited experience.
2. The gap report's MISSING list is a hard exclusion — the letter
   MUST NOT claim mastery of missing requirements.
3. The honest_summary frames the letter's tone — if the gap is large,
   the letter is honest about it (no overpromising).
4. Post-generation lint strips any MISSING-list terms that slipped
   into the body.

A cover letter is shorter than a CV (3-5 short paragraphs), so the
schema is simpler: greeting + 3 body paragraphs + closing. No bullet
lists; cover letters that read like CVs are a recruiter red flag.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from agntspace.career._llm_utils import (
    coerce_str as _str,
)
from agntspace.career._llm_utils import (
    render_bullet_block as _render_block,
)

# ``parse_cv_sections`` is the JSON parser the analyzer + CV builder
# share; cover_letter re-uses the same shape (markdown-fence tolerance
# + brace-walk + dict-at-root check) because every LLM-output schema
# in this subsystem is "single JSON object at root". Importing it
# crosses a sibling-module boundary but cv_builder exports it
# publicly (no underscore prefix) so the dependency is intentional.
from agntspace.career.cv_builder import parse_cv_sections

if TYPE_CHECKING:
    from agntspace.agent.agent import Agent
    from agntspace.skills.loader import SkillLoader

log = logging.getLogger(__name__)


# ── Module-level constants ─────────────────────────────────────────────────

_FALLBACK_CONFIG: dict[str, Any] = {  # arch:deterministic — engine fallback when YAML missing/broken
    "enabled": True,
    "llm_tier": "capable",
    "llm_max_tokens": 1500,
    "llm_timeout_seconds": 120,
    "max_facts_chars": 40_000,
    "max_jd_chars": 15_000,
    "prompt_template": (
        "You are writing a cover letter for a specific job application. Strict "
        "anti-fabrication discipline:\n\n"
        "RULES (LOAD-BEARING):\n"
        "1. EVERY claim must be traceable to the FACTS section. NEVER invent employers, dates, skills, or quantified outcomes.\n"
        "2. The MISSING list below is a HARD EXCLUSION. NEVER claim the candidate has those requirements.\n"
        "3. The HONEST_SUMMARY frames the letter's tone. If it acknowledges a gap, the letter must acknowledge it honestly too — never overpromise.\n"
        "4. Cover letters are SHORT. 3-5 paragraphs. No bullet lists. No section headers in the body. Conversational tone.\n"
        "5. Output JSON ONLY. No preamble, no markdown fences, no commentary.\n\n"
        "Return a SINGLE JSON object with EXACTLY these keys:\n"
        '  "greeting"    (string — e.g. "Dear Hiring Manager," or "Dear [name]," if recruiter named in JD)\n'
        '  "opening"     (string — 1 paragraph: who the candidate is + which role they\'re applying for)\n'
        '  "body_strong" (string — 1-2 paragraphs: emphasise COVERED requirements with concrete evidence from FACTS)\n'
        '  "body_honest" (string — 1 paragraph: acknowledge PARTIAL/MISSING gaps honestly + what the candidate brings instead; OMIT this paragraph if there are no gaps)\n'
        '  "closing"     (string — 1 paragraph + sign-off line)\n\n'
        "JOB DESCRIPTION:\n{jd_text}\n\n"
        "COMPANY: {company}\n"
        "ROLE: {role}\n"
        "RECRUITER (if shown): {recruiter}\n\n"
        "GAP REPORT — HONEST SUMMARY:\n{honest_summary}\n\n"
        "GAP REPORT — COVERED (emphasise these):\n{covered_block}\n\n"
        "GAP REPORT — PARTIAL (frame honestly):\n{partial_block}\n\n"
        "GAP REPORT — MISSING (DO NOT CLAIM THESE):\n{missing_block}\n\n"
        "CANDIDATE FACTS:\n{facts_text}"
    ),
    "doc": {
        "body_font": "Calibri",
        "body_size_pt": 11,
    },
}


@dataclass(frozen=True)
class CoverLetterContent:
    """Structured cover letter content extracted from LLM output."""
    greeting: str = ""
    opening: str = ""
    body_strong: str = ""
    body_honest: str = ""
    closing: str = ""

    @property
    def is_empty(self) -> bool:
        """True iff every section is empty (LLM produced nothing usable)."""
        return not (
            self.greeting.strip()
            or self.opening.strip()
            or self.body_strong.strip()
            or self.body_honest.strip()
            or self.closing.strip()
        )


def resolve_config(skill_loader: SkillLoader | None) -> dict[str, Any]:
    """Load the ``career-cover-letter`` YAML config with deterministic fallback."""
    if skill_loader is None:
        return _deepcopy_config(_FALLBACK_CONFIG)
    try:
        cfg = skill_loader.load_skill_config_file(
            "career-cover-letter", "build.yaml",
        )
    except Exception:
        log.debug("career-cover-letter: YAML load failed, using fallback", exc_info=True)
        return _deepcopy_config(_FALLBACK_CONFIG)
    if not isinstance(cfg, dict) or not cfg:
        return _deepcopy_config(_FALLBACK_CONFIG)
    merged = _deepcopy_config(_FALLBACK_CONFIG)
    for k, v in cfg.items():
        merged[k] = v
    return merged


def _deepcopy_config(cfg: dict[str, Any]) -> dict[str, Any]:
    out = dict(cfg)
    for k, v in out.items():
        if isinstance(v, dict):
            out[k] = dict(v)
        elif isinstance(v, list):
            out[k] = list(v)
    return out


def coerce_cover_letter(parsed: dict[str, Any]) -> CoverLetterContent:
    """Build a ``CoverLetterContent`` from a parsed JSON dict."""
    return CoverLetterContent(
        greeting=_str(parsed.get("greeting", "")),
        opening=_str(parsed.get("opening", "")),
        body_strong=_str(parsed.get("body_strong", "")),
        body_honest=_str(parsed.get("body_honest", "")),
        closing=_str(parsed.get("closing", "")),
    )


def check_for_missing_claim_leakage(
    content: CoverLetterContent,
    missing: list[str],
) -> list[str]:
    """Detect strings from the MISSING list that leaked into the cover letter.

    Same shape as the CV builder version — returns the list of missing
    terms found anywhere in the rendered text.
    """
    if not missing:
        return []
    full = " ".join([
        content.greeting,
        content.opening,
        content.body_strong,
        content.body_honest,
        content.closing,
    ]).lower()
    leaks: list[str] = []
    for term in missing:
        if not isinstance(term, str) or not term.strip():
            continue
        if term.strip().lower() in full:
            leaks.append(term.strip())
    return leaks


def strip_missing_claim_paragraphs(
    content: CoverLetterContent,
    missing: list[str],
) -> CoverLetterContent:
    """Strip MISSING-list terms from each paragraph.

    Conservative: when a paragraph contains a missing term, the
    ENTIRE paragraph is dropped (set to empty). Cover letters are
    paragraph-grained; surgically editing mid-sentence would produce
    broken prose. Better to drop the paragraph and let the user retry
    OR accept a shorter letter.
    """
    if not missing:
        return content
    missing_lower = {t.strip().lower() for t in missing if isinstance(t, str) and t.strip()}
    if not missing_lower:
        return content

    def _has(line: str) -> bool:
        if not isinstance(line, str):
            return False
        low = line.lower()
        return any(m in low for m in missing_lower)

    return CoverLetterContent(
        greeting=content.greeting if not _has(content.greeting) else "",
        opening=content.opening if not _has(content.opening) else "",
        body_strong=content.body_strong if not _has(content.body_strong) else "",
        body_honest=content.body_honest if not _has(content.body_honest) else "",
        closing=content.closing if not _has(content.closing) else "",
    )


async def build_cover_letter_via_llm(
    *,
    jd_text: str,
    facts_text: str,
    gap_report: dict[str, Any],
    company: str,
    role: str,
    recruiter: str = "",
    agent: Agent | None,
    skill_loader: SkillLoader | None = None,
    cfg: dict[str, Any] | None = None,
) -> CoverLetterContent:
    """LLM-build cover letter content grounded in facts + gap report.

    Returns an empty ``CoverLetterContent`` on any failure. Never raises.
    """
    config = cfg if cfg is not None else resolve_config(skill_loader)
    if not config.get("enabled", True):
        return CoverLetterContent()
    if agent is None:
        return CoverLetterContent()
    if not isinstance(jd_text, str) or not jd_text.strip():
        return CoverLetterContent()

    max_jd = int(config.get("max_jd_chars", 15_000))
    jd = jd_text.strip()
    if len(jd) > max_jd:
        jd = jd[:max_jd] + "\n\n[... JD truncated ...]"

    max_facts = int(config.get("max_facts_chars", 40_000))
    facts = (facts_text or "").strip()
    if len(facts) > max_facts:
        facts = facts[:max_facts] + "\n\n[... facts truncated ...]"
    if not facts:
        return CoverLetterContent()

    covered_block = _render_block(gap_report.get("covered", []))
    partial_block = _render_block(gap_report.get("partial", []))
    missing_block = _render_block(gap_report.get("missing", []))
    honest_summary = _str(gap_report.get("honest_summary", ""))

    template = str(config.get("prompt_template", _FALLBACK_CONFIG["prompt_template"]))
    try:
        prompt = template.format(
            jd_text=jd,
            facts_text=facts,
            covered_block=covered_block,
            partial_block=partial_block,
            missing_block=missing_block,
            honest_summary=honest_summary or "(not provided)",
            company=company or "(not provided)",
            role=role or "(not provided)",
            recruiter=recruiter or "(none)",
        )
    except (KeyError, ValueError):
        prompt = _FALLBACK_CONFIG["prompt_template"].format(
            jd_text=jd,
            facts_text=facts,
            covered_block=covered_block,
            partial_block=partial_block,
            missing_block=missing_block,
            honest_summary=honest_summary or "(not provided)",
            company=company or "(not provided)",
            role=role or "(not provided)",
            recruiter=recruiter or "(none)",
        )

    tier = str(config.get("llm_tier", "capable"))
    try:
        result = await agent.process_task(prompt, model_tier=tier)
    except Exception:
        log.debug("career-cover-letter: LLM call failed", exc_info=True)
        return CoverLetterContent()
    if not isinstance(result, str) or not result.strip():
        return CoverLetterContent()

    parsed = parse_cv_sections(result)
    if parsed is None:
        log.debug(
            "career-cover-letter: LLM output not parseable as JSON: %r",
            result[:200],
        )
        return CoverLetterContent()

    content = coerce_cover_letter(parsed)
    missing = gap_report.get("missing", [])
    if isinstance(missing, list):
        content = strip_missing_claim_paragraphs(content, missing)
    return content


def render_cover_letter_to_docx(
    content: CoverLetterContent,
    *,
    output_path: Path,
    cfg: dict[str, Any] | None = None,
) -> bool:
    """Render ``CoverLetterContent`` to a .docx file at ``output_path``.

    Returns True on successful write, False on any failure.
    """
    if content.is_empty:
        return False

    try:
        from docx import Document
        from docx.shared import Pt
    except ImportError:
        log.warning(
            "career-cover-letter: python-docx not installed, cannot render letter",
        )
        return False

    config = cfg if cfg is not None else _FALLBACK_CONFIG
    doc_cfg = config.get("doc", {}) if isinstance(config.get("doc"), dict) else {}
    body_font = str(doc_cfg.get("body_font", "Calibri"))
    body_size = int(doc_cfg.get("body_size_pt", 11))

    try:
        doc = Document()

        def _para(text: str) -> None:
            if not text.strip():
                return
            p = doc.add_paragraph()
            r = p.add_run(text.strip())
            r.font.size = Pt(body_size)
            r.font.name = body_font

        _para(content.greeting)
        _para(content.opening)
        _para(content.body_strong)
        _para(content.body_honest)
        _para(content.closing)

        output_path.parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(output_path))
        return True
    except Exception:  # noqa: BLE001
        log.exception("career-cover-letter: docx render failed")
        return False


__all__ = [
    "CoverLetterContent",
    "_FALLBACK_CONFIG",
    "build_cover_letter_via_llm",
    "check_for_missing_claim_leakage",
    "coerce_cover_letter",
    "render_cover_letter_to_docx",
    "resolve_config",
    "strip_missing_claim_paragraphs",
]
