"""Skill usage sidecar — per-skill lifecycle counters (Hermes-inspired, 2026-05-16 night).

Re-implementation of the pattern observed in NousResearch/hermes-agent
(MIT). Pattern only — no code copied. The architectural commitment:
every skill carries a small JSON sidecar tracking how often it was
loaded into the skill graph (``view_count`` / ``last_loaded_at``) and
how often the agent actually used it on a chat turn (``use_count`` /
``last_used_at``).

Sidecar lives at ``<skills_dir>/<skill_rel>/.usage.json`` so it travels
with the skill in vault sync / pip install / SkillSync's hash-gated
defaults reconciliation. Dot-prefixed name means the universal
dot-segment skip rule (kb/service.py + routes/wiki.py + memory/graph.py
+ raw_watcher) already excludes it from every traversal — agents never
KB-ingest their own usage logs.

Architectural commitments
-------------------------

1. **Fail-soft at every boundary.** Broken sidecar / missing file /
   corrupt JSON / disk-full / permission-denied → log debug, return
   canonical defaults, never raise. A broken sidecar must NEVER break
   skill loading, skill invocation, or chat dispatch.

2. **Atomic writes via .tmp + os.replace.** A crash mid-write leaves
   the prior version intact. Worst case: that one increment is lost.
   Never produces a corrupt JSON file the next read can't parse.

3. **Rate-limited load bumps.** ``bump_load`` is called from
   ``SkillLoader.get_skill`` which fires many times per chat turn (the
   tool dispatcher resolves the skill name to its body on every tool
   call). Without rate-limiting, a single chat turn with 5 tool calls
   to the same skill would write the sidecar 5 times. In-memory cache
   bounds writes to 1 per skill per ``_LOAD_BUMP_THROTTLE_SECONDS``
   (default 60).

4. **No rate-limit on use bumps.** ``bump_use`` is called once per
   activation per chat turn — a real signal worth one write.

5. **Schema versioned.** ``schema_version: 1`` in the JSON. Future
   schema bumps trigger a defensive re-read that drops unknown fields
   and writes the new shape. Forward-compat by structure, never by
   silent guess.

Sidecar shape
-------------

::

    {
        "schema_version": 1,
        "use_count": 42,
        "view_count": 5,
        "last_used_at": "2026-05-16T18:30:00+00:00",
        "last_loaded_at": "2026-05-16T18:35:00+00:00"
    }
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from datetime import UTC, datetime
from pathlib import Path

log = logging.getLogger(__name__)


# Rate-limit on ``bump_load`` writes. Background loaders (skill catalog
# refresh, tool dispatch resolution) hit ``get_skill`` many times per
# second; we don't want to write the sidecar on every call. 60s window
# means at most one disk write per skill per minute under load.
#
# arch:deterministic — engine substrate, not strategy. Tuning this knob
# changes write rate, not behavior.
_LOAD_BUMP_THROTTLE_SECONDS: float = 60.0


# Canonical default shape returned on missing / corrupt / unreadable
# sidecar. Callers never need to handle a None / partial dict.
_DEFAULT_USAGE: dict = {  # arch:deterministic — schema contract; default shape returned on every fail-soft path
    "schema_version": 1,
    "use_count": 0,
    "view_count": 0,
    "last_used_at": "",
    "last_loaded_at": "",
}


# Current schema version. Bump when the on-disk shape changes
# incompatibly. The defensive read drops unknown fields silently.
_CURRENT_SCHEMA_VERSION: int = 1  # arch:deterministic — schema contract; bumped only on incompatible on-disk changes


def _now_iso() -> str:
    """UTC ISO timestamp. Single source so tests can monkeypatch."""
    return datetime.now(UTC).isoformat()


def usage_sidecar_path(skill_dir: Path) -> Path:
    """Return the sidecar path inside a skill's directory.

    Dot-prefixed name is load-bearing: the universal dot-segment skip
    rule in kb/service.py + routes/wiki.py + memory/graph.py +
    raw_watcher already excludes it from every traversal, so agents
    never KB-ingest their own usage logs.
    """
    return skill_dir / ".usage.json"


def read_usage(skill_dir: Path) -> dict:
    """Return current usage counters for the skill at ``skill_dir``.

    Never raises. Returns the canonical default shape (``_DEFAULT_USAGE``)
    on every failure mode: missing file, corrupt JSON, unexpected type,
    permission-denied. Unknown fields are silently dropped.

    Schema-version mismatches (future-version sidecar opened by older
    code) are treated as missing — the default shape is returned without
    overwriting the on-disk file. The user retains their data; the
    older code just doesn't see counters it doesn't understand.
    """
    sidecar = usage_sidecar_path(skill_dir)
    if not sidecar.exists():
        return dict(_DEFAULT_USAGE)
    try:
        raw = sidecar.read_text(encoding="utf-8")
    except OSError as exc:
        log.debug("usage sidecar unreadable at %s: %s", sidecar, exc)
        return dict(_DEFAULT_USAGE)
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        log.debug("usage sidecar corrupt at %s: %s", sidecar, exc)
        return dict(_DEFAULT_USAGE)
    if not isinstance(data, dict):
        log.debug("usage sidecar root non-dict at %s", sidecar)
        return dict(_DEFAULT_USAGE)
    # Schema-version guard. Newer schema = drop to defaults without
    # destroying the file (the newer code that wrote it will reuse).
    version = data.get("schema_version", 0)
    if not isinstance(version, int) or version > _CURRENT_SCHEMA_VERSION:
        log.debug("usage sidecar schema version %s ahead of code %s at %s",
                  version, _CURRENT_SCHEMA_VERSION, sidecar)
        return dict(_DEFAULT_USAGE)
    # Defensive normalization: silently coerce known fields, drop unknowns.
    result = dict(_DEFAULT_USAGE)
    for key in ("use_count", "view_count"):
        raw_val = data.get(key, 0)
        if isinstance(raw_val, int) and raw_val >= 0:
            result[key] = raw_val
    for key in ("last_used_at", "last_loaded_at"):
        raw_val = data.get(key, "")
        if isinstance(raw_val, str):
            result[key] = raw_val
    return result


def _atomic_write_sidecar(skill_dir: Path, data: dict) -> bool:
    """Atomic .tmp + os.replace write. Returns True on success.

    Never raises. The directory MUST exist (the skill itself is a
    directory; this function won't create new skill dirs).
    """
    if not skill_dir.is_dir():
        log.debug("usage sidecar parent missing or not a dir: %s", skill_dir)
        return False
    sidecar = usage_sidecar_path(skill_dir)
    tmp_path = sidecar.with_suffix(sidecar.suffix + ".tmp")
    try:
        tmp_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp_path, sidecar)
        return True
    except OSError as exc:
        log.debug("usage sidecar write failed at %s: %s", sidecar, exc)
        # Best-effort cleanup of the half-written .tmp
        try:
            tmp_path.unlink()
        except OSError:
            pass
        return False


class SkillUsageRecorder:
    """Tracks per-skill usage counters via dot-prefixed JSON sidecars.

    Construction takes ``skills_dir`` (the root all skill subdirs live
    under) plus optional ``activity_logger`` for low-importance audit
    events. Both write paths (``bump_load`` / ``bump_use``) are
    fail-soft — broken sidecar NEVER breaks skill load / dispatch.

    Thread-safety: the in-memory rate-limit cache uses a Lock so
    concurrent ``bump_load`` calls (e.g. parallel tool dispatch on the
    same skill) collapse to one disk write per window.
    """

    def __init__(
        self,
        skills_dir: Path,
        *,
        activity_logger: object | None = None,
        load_bump_throttle_seconds: float | None = None,
    ) -> None:
        self._skills_dir = skills_dir
        self._activity_logger = activity_logger
        self._throttle = (
            load_bump_throttle_seconds
            if load_bump_throttle_seconds is not None
            else _LOAD_BUMP_THROTTLE_SECONDS
        )
        # In-memory last-bump tracker. Keyed by skill_name; value is
        # the wall-clock seconds of the last bump_load call. Used to
        # gate writes — never persists across process restart, which
        # is fine: a new process is allowed one fresh bump per skill.
        self._last_load_bump: dict[str, float] = {}
        self._lock = threading.Lock()

    def resolve_skill_dir(self, skill_rel_path: str) -> Path | None:
        """Resolve a skill's relative path (as stored on Skill.path) to its directory.

        ``Skill.path`` is stored RELATIVE to ``skills_dir`` and points at
        ``SKILL.md`` (e.g. ``core/kb-ingest/SKILL.md``). The sidecar lives
        in the parent directory. Returns None when the resolved directory
        doesn't exist — caller should skip the bump silently.
        """
        if not skill_rel_path:
            return None
        rel = Path(skill_rel_path)
        if rel.name == "SKILL.md":
            rel = rel.parent
        candidate = self._skills_dir / rel
        if not candidate.is_dir():
            return None
        return candidate

    def bump_use(self, skill_name: str, skill_rel_path: str) -> bool:
        """Record an activation. Returns True on successful write.

        Called once per skill per chat turn when the agent actually
        injects the skill body into the prompt (``_render_skill_activation_suffix``)
        OR dispatches via ``invoke_skill``. No rate limit — a real
        use signal warrants a write.
        """
        skill_dir = self.resolve_skill_dir(skill_rel_path)
        if skill_dir is None:
            return False
        current = read_usage(skill_dir)
        new_data = dict(current)
        new_data["use_count"] = int(current.get("use_count", 0)) + 1
        new_data["last_used_at"] = _now_iso()
        wrote = _atomic_write_sidecar(skill_dir, new_data)
        if wrote:
            self._maybe_emit_activity(skill_name, "skill_used", new_data["use_count"])
        return wrote

    def bump_load(self, skill_name: str, skill_rel_path: str) -> bool:
        """Record a load (lookup). Returns True on successful write.

        Rate-limited via ``_last_load_bump`` to at most one write per
        skill per ``_throttle`` seconds. Skill resolution fires many
        times per chat turn (tool dispatch resolves names to bodies
        repeatedly); without the gate, every chat turn would write the
        sidecar N times for hot skills.

        Within-throttle calls return True (the bump was honored —
        just not flushed to disk). The next call after the window
        elapses captures the cumulative behavior in one write.
        """
        skill_dir = self.resolve_skill_dir(skill_rel_path)
        if skill_dir is None:
            return False
        now = time.monotonic()
        with self._lock:
            last = self._last_load_bump.get(skill_name, 0.0)
            if (now - last) < self._throttle:
                # Within throttle window — increment in-memory only.
                # The next post-window bump will write a single +1 to
                # disk, which is the correct semantic for a "skill was
                # touched recently" signal.
                return True
            self._last_load_bump[skill_name] = now
        current = read_usage(skill_dir)
        new_data = dict(current)
        new_data["view_count"] = int(current.get("view_count", 0)) + 1
        new_data["last_loaded_at"] = _now_iso()
        wrote = _atomic_write_sidecar(skill_dir, new_data)
        if wrote:
            self._maybe_emit_activity(skill_name, "skill_loaded", new_data["view_count"])
        return wrote

    def get_usage(self, skill_rel_path: str) -> dict:
        """Public read API — returns the canonical-shape usage dict.

        Resolves the skill directory + delegates to ``read_usage``.
        Returns the default shape when the path can't be resolved.
        """
        skill_dir = self.resolve_skill_dir(skill_rel_path)
        if skill_dir is None:
            return dict(_DEFAULT_USAGE)
        return read_usage(skill_dir)

    def _maybe_emit_activity(self, skill_name: str, action: str, count: int) -> None:
        """Emit a low-importance audit event. Fail-soft on broken loggers."""
        if self._activity_logger is None:
            return
        try:
            self._activity_logger.log(
                category="skills",
                action=action,
                summary=f"{skill_name}: {action} (count={count})",
                importance="low",
                details={"skill": skill_name, "count": count},
            )
        except Exception:
            log.debug("usage activity log failed for %s/%s", skill_name, action, exc_info=True)
