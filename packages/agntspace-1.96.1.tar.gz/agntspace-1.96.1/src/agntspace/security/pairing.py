"""DM pairing policy: gate unknown senders on messaging channels.

P3.6 (2026-05-17): added per-channel policy override on top of the
global default. Users can now set distinct DM policies per channel —
e.g. WhatsApp self-chat open, Telegram inbound pairing, Discord
allowlist. The global ``dm_policy`` remains as the fallback when no
per-channel override is set, so existing installs see no change in
behavior.

Storage shape: per-channel overrides live in the ``settings`` table
under the key ``dm_policy:<channel>`` (lowercased channel name). The
global default stays at the key ``dm_policy``. No schema change
needed — the settings table is already key/value.

Lookup order in ``get_dm_policy(channel=None)``:

1. If ``channel`` provided, look up ``dm_policy:<channel.lower()>``.
2. Fall through to the global ``dm_policy`` row.
3. Fall through to the hardcoded default ``pairing``.

Closed enum of valid policies: ``"pairing" | "allowlist" | "open"``.
``set_dm_policy(policy, channel=None)`` validates against this enum;
``clear_dm_policy_override(channel)`` removes a per-channel entry
so the channel reverts to the global default.
"""

from __future__ import annotations

import logging
import secrets
from datetime import UTC, datetime, timedelta

import aiosqlite

log = logging.getLogger(__name__)

PAIRING_CODE_LENGTH = 6
PAIRING_EXPIRY_MINUTES = 10

# arch:deterministic — closed enum of valid DM policies. The engine validates
# every set_dm_policy() call against this set; broken YAML or malformed
# requests fall back to the previous policy rather than corrupting settings.
VALID_DM_POLICIES: tuple[str, ...] = ("pairing", "allowlist", "open")
_GLOBAL_POLICY_KEY: str = "dm_policy"  # arch:deterministic — settings key for the global fallback
_PER_CHANNEL_PREFIX: str = "dm_policy:"  # arch:deterministic — namespaced prefix for per-channel overrides


def _is_valid_policy(policy: str) -> bool:
    """Pure helper — `policy in VALID_DM_POLICIES`. Extracted for testability."""
    return isinstance(policy, str) and policy in VALID_DM_POLICIES


def _channel_key(channel: str) -> str:
    """Compose the settings key for a per-channel policy override.

    Channel names are lowercased so ``"WhatsApp"`` and ``"whatsapp"``
    collapse to one entry. Empty/None channel names raise — the
    caller should use the global key in that case.
    """
    if not channel or not isinstance(channel, str):
        raise ValueError("channel must be a non-empty string")
    return _PER_CHANNEL_PREFIX + channel.strip().lower()


class PairingService:
    def __init__(self, db: aiosqlite.Connection) -> None:
        self._db = db

    async def get_dm_policy(self, channel: str | None = None) -> str:
        """Resolve the effective DM policy for an optional channel.

        Lookup order (first hit wins):

        1. If ``channel`` is provided and non-empty, look up
           ``dm_policy:<channel.lower()>``. If a valid value is
           stored there, return it.
        2. Fall through to the global ``dm_policy`` row. If valid,
           return it.
        3. Hardcoded default ``"pairing"`` — the safest stance for
           an unknown channel (gate on unknown senders).

        Invalid values stored in the settings table (e.g. typos that
        slipped past the API gate) are skipped at lookup, preserving
        fall-through. This is the load-bearing fail-open posture —
        a corrupt setting can never produce an undefined policy.
        """
        # Step 1: per-channel override (only when channel provided)
        if channel:
            try:
                key = _channel_key(channel)
                async with self._db.execute(
                    "SELECT value FROM settings WHERE key = ?", (key,),
                ) as cur:
                    row = await cur.fetchone()
                    if row and _is_valid_policy(row[0]):
                        return row[0]
            except Exception:  # noqa: BLE001 — fail-open to global default
                log.debug("per-channel policy lookup failed", exc_info=True)

        # Step 2: global default
        try:
            async with self._db.execute(
                "SELECT value FROM settings WHERE key = ?", (_GLOBAL_POLICY_KEY,),
            ) as cur:
                row = await cur.fetchone()
                if row and _is_valid_policy(row[0]):
                    return row[0]
        except Exception:  # noqa: BLE001 — fail-open to hardcoded default
            log.debug("global policy lookup failed", exc_info=True)

        # Step 3: hardcoded default
        return "pairing"

    async def set_dm_policy(self, policy: str, channel: str | None = None) -> None:
        """Set the DM policy.

        With ``channel=None`` (default), updates the global ``dm_policy``
        row — back-compat with the pre-P3.6 single-policy callers.

        With ``channel`` set, writes a per-channel override at
        ``dm_policy:<channel.lower()>``. The global row stays untouched
        so removing the override later reverts to the global value.

        Raises ``ValueError`` on invalid policy. Validation here is
        the load-bearing gate that keeps the settings table clean —
        ``get_dm_policy`` is permissive on read by design (fail-open
        on corrupt data), so writes must NOT accept garbage.
        """
        if not _is_valid_policy(policy):
            raise ValueError(
                f"invalid policy {policy!r}; must be one of {VALID_DM_POLICIES}"
            )
        key = _channel_key(channel) if channel else _GLOBAL_POLICY_KEY
        await self._db.execute(
            "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
            (key, policy),
        )
        await self._db.commit()

    async def clear_dm_policy_override(self, channel: str) -> bool:
        """Remove a per-channel policy override.

        The channel reverts to the global default after this. Returns
        ``True`` when a row was removed, ``False`` when there was no
        override to begin with (idempotent — safe to re-call). Raises
        ``ValueError`` on empty/missing channel name to prevent
        accidentally clearing the global key.
        """
        key = _channel_key(channel)  # raises on empty/None
        cur = await self._db.execute("DELETE FROM settings WHERE key = ?", (key,))
        await self._db.commit()
        return (cur.rowcount or 0) > 0

    async def list_dm_policy_overrides(self) -> dict[str, str]:
        """Enumerate all per-channel policy overrides.

        Returns a dict of ``{channel_name: policy}`` with the per-channel
        portion of the settings table. The global default is NOT included
        — callers needing it should call ``get_dm_policy()`` with no
        argument. Result is unsorted; UI consumers sort as needed.

        Invalid values (typos that slipped past the API gate) are
        excluded from the returned dict so the UI never renders
        garbage choices.
        """
        rows: dict[str, str] = {}
        try:
            async with self._db.execute(
                "SELECT key, value FROM settings WHERE key LIKE ?",
                (f"{_PER_CHANNEL_PREFIX}%",),
            ) as cur:
                async for row in cur:
                    key = str(row[0] or "")
                    value = str(row[1] or "")
                    if not key.startswith(_PER_CHANNEL_PREFIX):
                        continue  # defensive — LIKE pattern could be tricked
                    channel = key[len(_PER_CHANNEL_PREFIX):]
                    if channel and _is_valid_policy(value):
                        rows[channel] = value
        except Exception:  # noqa: BLE001 — fail-open to empty dict
            log.debug("list_dm_policy_overrides failed", exc_info=True)
        return rows

    async def is_allowed(self, channel: str, sender_id: str) -> bool:
        """Check if a sender is in the allowlist."""
        async with self._db.execute(
            "SELECT 1 FROM dm_allowlist WHERE channel = ? AND sender_id = ?",
            (channel, sender_id),
        ) as cur:
            return await cur.fetchone() is not None

    async def add_to_allowlist(self, channel: str, sender_id: str) -> None:
        """Add a sender to the allowlist."""
        now = datetime.now(UTC).isoformat()
        await self._db.execute(
            "INSERT OR IGNORE INTO dm_allowlist (channel, sender_id, approved_at) VALUES (?, ?, ?)",
            (channel, sender_id, now),
        )
        await self._db.commit()

    async def remove_from_allowlist(self, channel: str, sender_id: str) -> None:
        """Remove a sender from the allowlist."""
        await self._db.execute(
            "DELETE FROM dm_allowlist WHERE channel = ? AND sender_id = ?",
            (channel, sender_id),
        )
        await self._db.commit()

    async def get_allowlist(self) -> list[dict]:
        """Get all allowlist entries."""
        async with self._db.execute(
            "SELECT channel, sender_id, approved_at FROM dm_allowlist ORDER BY approved_at DESC"
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]

    async def generate_pairing_code(self, channel: str, sender_id: str) -> str:
        """Generate a pairing code for an unknown sender. Idempotent — returns existing if pending."""
        now = datetime.now(UTC)

        # Check for existing pending code
        async with self._db.execute(
            "SELECT code FROM dm_pairing WHERE channel = ? AND sender_id = ? AND status = 'pending' AND expires_at > ?",
            (channel, sender_id, now.isoformat()),
        ) as cur:
            row = await cur.fetchone()
            if row:
                return row[0]

        # Generate new code
        code = secrets.token_hex(3).upper()  # 6 hex chars
        expires = now + timedelta(minutes=PAIRING_EXPIRY_MINUTES)
        await self._db.execute(
            "INSERT INTO dm_pairing (channel, sender_id, code, created_at, expires_at, status) VALUES (?, ?, ?, ?, ?, 'pending')",
            (channel, sender_id, code, now.isoformat(), expires.isoformat()),
        )
        await self._db.commit()
        log.info("Pairing code generated: %s for %s/%s", code, channel, sender_id)
        return code

    async def get_pending(self) -> list[dict]:
        """Get pending pairing requests."""
        now = datetime.now(UTC).isoformat()
        # Clean up expired first
        await self._db.execute(
            "UPDATE dm_pairing SET status = 'expired' WHERE status = 'pending' AND expires_at < ?",
            (now,),
        )
        await self._db.commit()

        async with self._db.execute(
            "SELECT channel, sender_id, code, created_at, expires_at FROM dm_pairing WHERE status = 'pending' ORDER BY created_at DESC"
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]

    async def approve(self, channel: str, sender_id: str) -> bool:
        """Approve a pairing request. Adds sender to allowlist."""
        async with self._db.execute(
            "SELECT id FROM dm_pairing WHERE channel = ? AND sender_id = ? AND status = 'pending'",
            (channel, sender_id),
        ) as cur:
            if not await cur.fetchone():
                return False

        await self._db.execute(
            "UPDATE dm_pairing SET status = 'approved' WHERE channel = ? AND sender_id = ? AND status = 'pending'",
            (channel, sender_id),
        )
        await self.add_to_allowlist(channel, sender_id)
        log.info("Pairing approved: %s/%s", channel, sender_id)
        return True

    async def reject(self, channel: str, sender_id: str) -> bool:
        """Reject a pairing request."""
        result = await self._db.execute(
            "UPDATE dm_pairing SET status = 'rejected' WHERE channel = ? AND sender_id = ? AND status = 'pending'",
            (channel, sender_id),
        )
        await self._db.commit()
        return result.rowcount > 0
