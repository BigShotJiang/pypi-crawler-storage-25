"""Speculative streaming engine — race a cheap draft model against the real one.

P4.5 (Slice 1, shipped 2026-05-18). Pure async-iterator wrapper that takes a
``draft_factory`` and a ``real_factory`` (callables returning ``AsyncIterator
[StreamChunk]``) and yields :class:`SpeculativeChunk` events the caller can
translate into UI actions:

* ``kind="add"`` — append ``text`` to the visible buffer. ``source`` is
  ``"draft"`` (might be retracted) or ``"real"`` (canonical).
* ``kind="retract"`` — remove the trailing ``retract_chars`` characters
  from the visible buffer. Sent when the real stream diverges from text
  that was already drafted to the UI.
* ``kind="done"`` — terminal event with summary stats.

Architectural commitments (load-bearing — read before changing):

1. **Real stream is canonical.** Every char the user ultimately sees came
   from the real stream. Draft chars that survive to ``done`` did so
   because the real stream produced byte-identical text at that position.
   The wrapper never lets unconfirmed-by-real content stay on screen at
   ``done``.

2. **Divergence triggers an explicit ``retract``.** The wrapper does NOT
   silently keep wrong content visible. When draft diverges from real,
   the wrapper emits exactly one ``retract`` event covering every
   already-yielded draft char past the common prefix, then continues
   with real-only output.

3. **Fail-soft = real-only.** Disabled config / null draft_factory /
   draft factory raises / draft stream raises mid-flight → switch to
   pass-through over real. Caller sees pure real chunks as ``source=
   "real"`` events. Real stream errors propagate (caller's problem).

4. **No LLM knowledge.** The module doesn't know about ``LLMProvider``,
   ``ModelRouter``, ``chat_stream``, tool calls, or skills. Caller
   supplies the factories. Caller decides when to skip (e.g. tool-call
   turns).

5. **Bounded draft lead.** ``config.draft_max_lead_chars`` caps how far
   ahead of the real buffer the draft can stream. Prevents the draft
   from racing to completion before real has produced anything, which
   would maximize retraction blast-radius on divergence.

Tests in ``tests/unit/agent/test_speculative_streaming.py``.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field
from typing import Any

from agntspace.llm.base import StreamChunk

log = logging.getLogger(__name__)


# Engine fallback when YAML missing / broken. Tuning lives in
# defaults/skills/_meta/speculative-streaming/config/speculation.yaml (Rule 12).
_FALLBACK_CONFIG: dict[str, Any] = {  # arch:deterministic — engine fallback when YAML missing; tuning in _meta/speculative-streaming/config/speculation.yaml
    "enabled": False,  # safe default; flip via vault YAML once UI swap handler ships
    "divergence_char_threshold": 10,
    "draft_max_lead_chars": 200,
    "draft_model_tier": "fast",
    "skip_on_tool_call_turns": True,
}


@dataclass(frozen=True)
class SpeculationConfig:
    """Resolved knobs for one speculative-stream call."""

    enabled: bool = False
    divergence_char_threshold: int = 10
    draft_max_lead_chars: int = 200
    draft_model_tier: str = "fast"
    skip_on_tool_call_turns: bool = True


@dataclass(frozen=True)
class SpeculativeChunk:
    """One event yielded by ``speculative_stream``.

    Three kinds:
        ``add`` — caller appends ``text`` to the visible buffer.
        ``retract`` — caller removes the trailing ``retract_chars`` chars.
        ``done`` — terminal event; ``stats`` carries telemetry.
    """

    kind: str  # "add" | "retract" | "done"
    text: str = ""
    retract_chars: int = 0
    source: str = ""  # "draft" | "real" | "" — telemetry hint
    stats: dict[str, Any] = field(default_factory=dict)


def resolve_speculation_config(
    skill_loader: Any,
    *,
    overrides: dict[str, Any] | None = None,
) -> SpeculationConfig:
    """Load config from the ``speculative-streaming`` skill YAML.

    Fail-open at every layer: no loader / missing config / non-dict
    YAML / unknown keys → returns a ``SpeculationConfig`` built from
    ``_FALLBACK_CONFIG`` merged with explicit ``overrides``. Never raises.
    """
    merged = dict(_FALLBACK_CONFIG)
    if skill_loader is not None:
        try:
            loaded = skill_loader.load_skill_config_file(
                "speculative-streaming", "speculation.yaml"
            )
            if isinstance(loaded, dict):
                for key in _FALLBACK_CONFIG:
                    if key in loaded:
                        merged[key] = loaded[key]
        except Exception:
            log.debug("speculative-streaming config load failed", exc_info=True)
    if overrides:
        for key, value in overrides.items():
            if key in _FALLBACK_CONFIG:
                merged[key] = value

    # Defensive coercion — YAML may produce wrong types.
    try:
        return SpeculationConfig(
            enabled=bool(merged.get("enabled", False)),
            divergence_char_threshold=max(
                0, int(merged.get("divergence_char_threshold", 10))
            ),
            draft_max_lead_chars=max(
                0, int(merged.get("draft_max_lead_chars", 200))
            ),
            draft_model_tier=str(merged.get("draft_model_tier", "fast")),
            skip_on_tool_call_turns=bool(
                merged.get("skip_on_tool_call_turns", True)
            ),
        )
    except (TypeError, ValueError):
        log.debug("speculative-streaming config coercion failed", exc_info=True)
        return SpeculationConfig()


def _common_prefix_len(a: str, b: str) -> int:
    """Length of the longest common prefix of two strings."""
    n = min(len(a), len(b))
    for i in range(n):
        if a[i] != b[i]:
            return i
    return n


async def _drain_into_queue(
    iterator: AsyncIterator[StreamChunk],
    queue: asyncio.Queue[tuple[str, Any]],
    tag: str,
) -> None:
    """Background task body — read every chunk from iterator into the queue.

    Emits ``(tag, "chunk", StreamChunk)`` per chunk, ``(tag, "error", exc)``
    on failure, ``(tag, "done", None)`` when exhausted. Cancellation
    propagates through naturally.
    """
    try:
        async for chunk in iterator:
            await queue.put((tag, "chunk", chunk))
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        await queue.put((tag, "error", exc))
    finally:
        await queue.put((tag, "done", None))


async def speculative_stream(
    draft_factory: Callable[[], AsyncIterator[StreamChunk]] | None,
    real_factory: Callable[[], AsyncIterator[StreamChunk]],
    *,
    config: SpeculationConfig | None = None,
) -> AsyncIterator[SpeculativeChunk]:
    """Race a draft stream against a real stream and yield UI events.

    Args:
        draft_factory: zero-arg callable returning an ``AsyncIterator[
            StreamChunk]`` for the cheap draft model. May be ``None`` to
            disable speculation for this call (equivalent to ``config.
            enabled=False``).
        real_factory: zero-arg callable returning the canonical stream.
            Always invoked. Its errors propagate.
        config: tuning knobs. Defaults to ``SpeculationConfig()``
            (kill switch off).

    Yields:
        :class:`SpeculativeChunk` events the caller translates into UI
        actions. Final event is always ``kind="done"`` with stats.
    """
    cfg = config or SpeculationConfig()

    # ── Pass-through path: speculation disabled OR no draft factory ──
    # Caller still gets one consistent event shape.
    if not cfg.enabled or draft_factory is None:
        displayed_chars = 0
        try:
            async for chunk in real_factory():
                if chunk.delta:
                    yield SpeculativeChunk(
                        kind="add", text=chunk.delta, source="real"
                    )
                    displayed_chars += len(chunk.delta)
        finally:
            yield SpeculativeChunk(
                kind="done",
                source="real",
                stats={
                    "mode": "passthrough",
                    "displayed_chars": displayed_chars,
                    "draft_started": False,
                    "diverged": False,
                    "retracted_chars": 0,
                },
            )
        return

    # ── Speculative path ──
    queue: asyncio.Queue[tuple[str, str, Any]] = asyncio.Queue()
    draft_task: asyncio.Task[None] | None = None
    real_task: asyncio.Task[None] | None = None

    # Start draft factory inside the try so a factory exception → fail-open.
    try:
        draft_iter = draft_factory()
    except Exception:
        log.debug("draft factory raised; falling back to real-only", exc_info=True)
        draft_iter = None

    real_iter = real_factory()
    real_task = asyncio.create_task(
        _drain_into_queue(real_iter, queue, "real"), name="speculative-real"
    )
    if draft_iter is not None:
        draft_task = asyncio.create_task(
            _drain_into_queue(draft_iter, queue, "draft"),
            name="speculative-draft",
        )

    draft_buffer = ""
    real_buffer = ""
    displayed = ""  # text already emitted via "add" events
    draft_done = draft_iter is None
    real_done = False
    diverged = False
    draft_yielded_chars = 0
    retracted_chars = 0

    def _emit_add(new_text: str, src: str) -> SpeculativeChunk:
        nonlocal displayed, draft_yielded_chars
        displayed += new_text
        if src == "draft":
            draft_yielded_chars += len(new_text)
        return SpeculativeChunk(kind="add", text=new_text, source=src)

    def _emit_retract(n: int) -> SpeculativeChunk:
        nonlocal displayed, retracted_chars
        # Bound n to actual displayed length.
        n = max(0, min(n, len(displayed)))
        displayed = displayed[:-n] if n > 0 else displayed
        retracted_chars += n
        return SpeculativeChunk(kind="retract", retract_chars=n, source="real")

    try:
        while not (real_done and draft_done):
            try:
                tag, event_kind, payload = await queue.get()
            except asyncio.CancelledError:
                raise

            if event_kind == "done":
                if tag == "real":
                    real_done = True
                else:  # tag == "draft"
                    draft_done = True
                continue

            if event_kind == "error":
                if tag == "real":
                    # Real stream failure propagates — but first cancel the draft.
                    if draft_task and not draft_task.done():
                        draft_task.cancel()
                    raise payload  # type: ignore[misc]
                # Draft error → switch to real-only.
                # DEFENSIVE: retract any draft chars displayed past the
                # common prefix with real_buffer. If we don't, real chunks
                # will append AFTER the wrong draft text and the user sees
                # corrupted output. This is the load-bearing fail-soft
                # contract: "draft stream raised → drop unconfirmed draft
                # text; real wins from here."
                log.debug("draft stream raised; switching to real-only")
                common = _common_prefix_len(displayed, real_buffer)
                if len(displayed) > common:
                    yield _emit_retract(len(displayed) - common)
                diverged = True  # treat as divergence — future real chunks just add
                draft_done = True
                continue

            # event_kind == "chunk"
            chunk: StreamChunk = payload
            delta = chunk.delta if isinstance(chunk.delta, str) else ""

            if tag == "draft":
                if diverged or draft_done:
                    # Already given up on draft; ignore.
                    continue
                draft_buffer += delta
                if diverged:
                    continue
                # Decide how much of draft_buffer to stream to caller.
                # We can stream draft up to (real_buffer_len + lead_cap).
                lead_cap = len(real_buffer) + cfg.draft_max_lead_chars
                desired_end = min(len(draft_buffer), lead_cap)
                if desired_end > len(displayed):
                    # Validate: draft_buffer[:len(real_buffer)] MUST match
                    # real_buffer (otherwise we're about to ship divergent
                    # text). If it doesn't, treat as divergence now.
                    if real_buffer and not draft_buffer.startswith(real_buffer[: min(len(real_buffer), len(draft_buffer))]):
                        common = _common_prefix_len(real_buffer, draft_buffer)
                        if common + cfg.divergence_char_threshold < min(
                            len(real_buffer), len(draft_buffer)
                        ):
                            # Divergence — handle in real branch below by
                            # not advancing draft here.
                            continue
                    yield _emit_add(draft_buffer[len(displayed):desired_end], "draft")

            elif tag == "real":
                if delta:
                    real_buffer += delta

                if diverged:
                    # Already in real-only mode — just emit any new real text.
                    if len(real_buffer) > len(displayed):
                        yield _emit_add(
                            real_buffer[len(displayed):], "real"
                        )
                    continue

                # Aligned check: real_buffer must be a prefix of draft_buffer
                # (allowing for a slack window of `divergence_char_threshold`
                # chars at the tail of whichever is shorter).
                common = _common_prefix_len(real_buffer, draft_buffer)
                shorter = min(len(real_buffer), len(draft_buffer))
                # If we have substantive overlap and the divergence is past
                # the slack threshold, divergence happened.
                if shorter > 0 and common < shorter - cfg.divergence_char_threshold:
                    diverged = True
                    # Retract any draft chars yielded past the common prefix.
                    if len(displayed) > common:
                        yield _emit_retract(len(displayed) - common)
                    # Emit the canonical real text beyond what's now displayed.
                    if len(real_buffer) > len(displayed):
                        yield _emit_add(
                            real_buffer[len(displayed):], "real"
                        )
                    # Cancel the draft task — we no longer care.
                    if draft_task and not draft_task.done():
                        draft_task.cancel()
                    draft_done = True
                else:
                    # Aligned. If real has produced text beyond what we've
                    # shown, emit that as "real" (canonical confirmation).
                    if len(real_buffer) > len(displayed):
                        yield _emit_add(
                            real_buffer[len(displayed):], "real"
                        )

        # Both streams done. Handle final reconciliation.
        if not diverged:
            if len(real_buffer) > len(displayed):
                # Rare: real had trailing chars beyond what draft yielded.
                yield _emit_add(real_buffer[len(displayed):], "real")
            elif len(displayed) > len(real_buffer):
                # Draft over-shot real — retract the excess.
                yield _emit_retract(len(displayed) - len(real_buffer))

    finally:
        # Best-effort cancellation. We don't await draft_task because it
        # may be blocked on a queue.put we'll never consume; just cancel.
        if draft_task and not draft_task.done():
            draft_task.cancel()
        if real_task and not real_task.done():
            real_task.cancel()

    yield SpeculativeChunk(
        kind="done",
        source="real",
        stats={
            "mode": "speculative",
            "displayed_chars": len(displayed),
            "draft_started": draft_iter is not None,
            "draft_yielded_chars": draft_yielded_chars,
            "diverged": diverged,
            "retracted_chars": retracted_chars,
            "real_buffer_chars": len(real_buffer),
            "draft_buffer_chars": len(draft_buffer),
        },
    )
