"""`/goal` Ralph-loop primitive — lock the agent onto a target across turns.

P3.1 (Hermes-borrow). Closes the "agent forgot the goal after 3
messages" UX complaint. Composes with — but is distinct from — the
existing ``CoachService`` goal machinery: that surface manages
long-lived project-level goals with status / metric / pursuit; the
Ralph loop is a lightweight per-conversation "stay focused on X"
overlay that lasts a configurable number of turns.

Architectural commitments:

1. **Process-local in-memory state, keyed by conversation_id.** Ralph
   loops are ephemeral — if the server restarts, the goal lifts.
   That's the right semantics: a goal locked in a conversation no
   longer represents the user's current focus a day later. The
   ``CoachService`` is the durable-goal surface; this module is the
   chat-focus surface.

2. **Slash command, not a tool.** ``/goal X`` and ``/goal clear`` are
   text the user types in the chat box. We intercept them BEFORE the
   LLM call so:
   - No tokens spent on a primitive that's just state mutation.
   - No tool round-trip latency between user message + acknowledgment.
   - Works even when the LLM is offline or budget is exhausted.

3. **Turn budget is the auto-clear mechanism.** ``default_max_turns``
   (10) means even a forgotten ``/goal`` doesn't haunt the user
   forever. Bumping the turn happens on every REAL chat turn (not the
   slash-command intercept itself). When budget exhausts, the goal
   lifts AND the next system prompt carries a one-time "goal lifted"
   notice so the user sees the transition.

4. **System-prompt injection is the agent-side hook.** Per turn, when
   a goal is active, we append a short banner to the system suffix
   telling the LLM what the user is working toward + how many turns
   remain. Skill-driven prompt template (Rule 12) so users can tune
   tone / wording without code changes.

5. **Fail-soft at every boundary.** Broken tracker / missing config /
   parser exception → goal feature acts as no-op. Chat path NEVER
   blocked by this layer.
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any

log = logging.getLogger(__name__)


_FALLBACK_CONFIG: dict[str, Any] = {  # arch:deterministic — engine fallback when YAML missing; tuning lives in _meta/active-goal/config/goal.yaml (Rule 12)
    "enabled": True,
    "default_max_turns": 10,
    "max_goal_chars": 500,
    "prompt_template": (
        "🎯 ACTIVE GOAL (turn {turn} of {max_turns}): {goal_text}\n\n"
        "You are working with the user toward this goal. Every reply should "
        "advance it. If the user shifts off-topic, gently steer back — unless "
        "they explicitly say stop, /goal clear, or that they're done."
    ),
    "expired_template": (
        "🎯 GOAL TIME-BUDGET EXHAUSTED: the goal \"{goal_text}\" was set "
        "{max_turns} turns ago and has now been auto-lifted. If the user "
        "wants to keep working on it, they can re-set with /goal."
    ),
}


@dataclass
class ActiveGoal:
    """The user-set goal for one conversation.

    Fields:
        conversation_id: Owning chat thread.
        goal_text: The user-supplied target.
        set_at: Unix timestamp when the goal was set.
        turn_count: How many real chat turns have elapsed since.
        max_turns: Auto-clear threshold.
    """

    conversation_id: str
    goal_text: str
    set_at: float = field(default_factory=time.time)
    turn_count: int = 0
    max_turns: int = 10

    def to_dict(self) -> dict[str, Any]:
        return {
            "conversation_id": self.conversation_id,
            "goal_text": self.goal_text,
            "set_at": self.set_at,
            "turn_count": self.turn_count,
            "max_turns": self.max_turns,
            "turns_remaining": max(0, self.max_turns - self.turn_count),
        }

    def is_exhausted(self) -> bool:
        """True iff the goal has consumed its full turn budget."""
        return self.turn_count >= self.max_turns


def parse_goal_command(text: str) -> tuple[str, str] | None:
    """Pure-function slash-command parser.

    Returns:
        ``("set", goal_text)`` when text matches ``/goal <body>``.
        ``("clear", "")`` when text matches ``/goal clear`` (case-
            insensitive; also matches ``/goal stop``, ``/goal done``,
            ``/goal off``).
        ``("status", "")`` when text matches ``/goal`` alone or
            ``/goal status``.
        ``None`` when text doesn't start with ``/goal``.

    Leading/trailing whitespace tolerated. Empty body after the
    keyword (``/goal `` with nothing) is treated as a status query
    rather than setting an empty goal — preserves the "no surprises"
    contract (setting an empty goal would be a confusing no-op).
    """
    if not isinstance(text, str):
        return None
    stripped = text.strip()
    if not stripped:
        return None
    # Case-insensitive prefix match. We accept ``/goal`` exactly OR
    # ``/goal <something>``; ``/goalkeeper`` and similar prefixes are
    # NOT goal commands.
    lowered = stripped.lower()
    if lowered == "/goal":
        return ("status", "")
    if not lowered.startswith("/goal "):
        return None
    body = stripped[len("/goal "):].strip()
    if not body:
        return ("status", "")
    body_lower = body.lower()
    if body_lower in ("clear", "stop", "done", "off", "cancel", "remove"):
        return ("clear", "")
    if body_lower in ("status", "show", "current"):
        return ("status", "")
    return ("set", body)


def resolve_config(skill_loader: object | None) -> dict[str, Any]:
    """Read ``_meta/active-goal/config/goal.yaml`` with fail-soft fallback.

    Rule 12: tuning is in YAML, engine fallback in code. Returns a
    fresh dict every call so callers can mutate without aliasing.
    """
    if skill_loader is None:
        return dict(_FALLBACK_CONFIG)
    try:
        cfg = skill_loader.load_skill_config_file(  # type: ignore[attr-defined]
            "active-goal", "goal.yaml",
        )
    except Exception:
        log.debug("active_goal: YAML read failed", exc_info=True)
        return dict(_FALLBACK_CONFIG)
    if not isinstance(cfg, dict):
        return dict(_FALLBACK_CONFIG)
    merged = dict(_FALLBACK_CONFIG)
    if "enabled" in cfg:
        merged["enabled"] = bool(cfg["enabled"])
    if "default_max_turns" in cfg:
        try:
            v = int(cfg["default_max_turns"])
            if v >= 1:
                merged["default_max_turns"] = v
        except (TypeError, ValueError):
            pass
    if "max_goal_chars" in cfg:
        try:
            v = int(cfg["max_goal_chars"])
            if v >= 1:
                merged["max_goal_chars"] = v
        except (TypeError, ValueError):
            pass
    if "prompt_template" in cfg and isinstance(cfg["prompt_template"], str):
        merged["prompt_template"] = cfg["prompt_template"]
    if "expired_template" in cfg and isinstance(cfg["expired_template"], str):
        merged["expired_template"] = cfg["expired_template"]
    return merged


class ActiveGoalTracker:
    """Per-conversation goal-state holder + lifecycle manager.

    Process-local + in-memory. Thread-safe via a single mutex around
    the dict (mutations from chat_stream are async-task-local but
    plugins or REST handlers could reach in concurrently).

    Public methods:
        set_goal(conv_id, goal_text, max_turns) → ActiveGoal
            Set or replace the goal for a conversation. ``max_turns``
            defaults to YAML's ``default_max_turns``. ``goal_text``
            is truncated to ``max_goal_chars`` so a paste-in essay
            doesn't blow the system prompt budget.
        clear_goal(conv_id) → ActiveGoal | None
            Remove the goal. Returns the prior state or None if no
            goal was set.
        get_state(conv_id) → ActiveGoal | None
            Peek without mutating.
        bump_turn(conv_id) → tuple[ActiveGoal | None, bool]
            Increment turn_count. Returns ``(state_or_none, was_just_exhausted)``.
            When the bump pushes turn_count past max_turns, the goal
            is auto-cleared AND ``was_just_exhausted=True`` so the
            caller can surface the expiration notice on this turn's
            system prompt.
        render_system_block(conv_id) → str
            Returns the per-turn system-prompt insert for the active
            goal, or empty string when no goal. Reads the YAML template.
    """

    def __init__(self, *, skill_loader: object | None = None) -> None:
        self._goals: dict[str, ActiveGoal] = {}
        self._just_exhausted: dict[str, ActiveGoal] = {}
        self._lock = threading.Lock()
        self._skill_loader = skill_loader

    def config(self) -> dict[str, Any]:
        return resolve_config(self._skill_loader)

    def is_enabled(self) -> bool:
        return bool(self.config().get("enabled", True))

    def set_goal(
        self,
        conversation_id: str,
        goal_text: str,
        *,
        max_turns: int | None = None,
    ) -> ActiveGoal:
        cfg = self.config()
        max_chars = int(cfg.get("max_goal_chars", 500))
        text = (goal_text or "").strip()
        if max_chars > 0 and len(text) > max_chars:
            text = text[: max_chars - 1].rstrip() + "…"
        eff_max = max_turns if max_turns is not None else int(cfg.get("default_max_turns", 10))
        if eff_max < 1:
            eff_max = 1
        goal = ActiveGoal(
            conversation_id=conversation_id,
            goal_text=text,
            max_turns=eff_max,
        )
        with self._lock:
            self._goals[conversation_id] = goal
            # Setting a new goal cancels any pending expiration notice.
            self._just_exhausted.pop(conversation_id, None)
        return goal

    def clear_goal(self, conversation_id: str) -> ActiveGoal | None:
        with self._lock:
            prior = self._goals.pop(conversation_id, None)
            self._just_exhausted.pop(conversation_id, None)
        return prior

    def get_state(self, conversation_id: str) -> ActiveGoal | None:
        with self._lock:
            return self._goals.get(conversation_id)

    def bump_turn(self, conversation_id: str) -> tuple[ActiveGoal | None, bool]:
        """Increment turn_count for the conversation's active goal.

        Returns ``(state_or_none, was_just_exhausted)``. When
        ``was_just_exhausted=True``, the goal has been auto-cleared
        AND queued for an expiration notice on the next
        ``render_system_block`` call.
        """
        with self._lock:
            goal = self._goals.get(conversation_id)
            if goal is None:
                return (None, False)
            goal.turn_count += 1
            if goal.is_exhausted():
                # Move to the just-exhausted slot so the next
                # render_system_block emits the expiration notice
                # exactly once.
                self._just_exhausted[conversation_id] = goal
                del self._goals[conversation_id]
                return (goal, True)
            return (goal, False)

    def render_system_block(self, conversation_id: str) -> str:
        """Per-turn system-prompt suffix for the active goal.

        Returns:
            Empty string when no goal is set + no expiration notice
            is pending. Otherwise a short banner formatted from the
            YAML template. The expiration notice is one-shot — pops
            from the just_exhausted queue and is gone next turn.
        """
        cfg = self.config()
        if not cfg.get("enabled", True):
            return ""
        with self._lock:
            # First, drain any pending expiration notice exactly once.
            expired = self._just_exhausted.pop(conversation_id, None)
            goal = self._goals.get(conversation_id)
        # The expiration notice and the active-goal banner are mutually
        # exclusive: if a goal was just exhausted on THIS turn's bump,
        # the same turn doesn't carry an active-goal banner because the
        # bump already moved it to just_exhausted. If the user sets a
        # NEW goal in the same turn, set_goal clears the just_exhausted
        # entry so we don't get a stale expiration notice next turn.
        if expired is not None:
            template = cfg.get("expired_template", _FALLBACK_CONFIG["expired_template"])
            try:
                return str(template).format(
                    goal_text=expired.goal_text,
                    max_turns=expired.max_turns,
                )
            except Exception:
                log.debug(
                    "active_goal: expired_template format failed", exc_info=True,
                )
                return ""
        if goal is None:
            return ""
        template = cfg.get("prompt_template", _FALLBACK_CONFIG["prompt_template"])
        try:
            return str(template).format(
                goal_text=goal.goal_text,
                turn=goal.turn_count + 1,  # 1-based for the user-visible banner
                max_turns=goal.max_turns,
                turns_remaining=max(0, goal.max_turns - goal.turn_count),
            )
        except Exception:
            log.debug("active_goal: prompt_template format failed", exc_info=True)
            return ""

    def stats(self) -> dict[str, Any]:
        """Diagnostic snapshot — count of active goals + their IDs."""
        with self._lock:
            return {
                "active_count": len(self._goals),
                "active_conversations": sorted(self._goals.keys()),
                "pending_expirations": len(self._just_exhausted),
            }


def format_command_response(
    action: str,
    *,
    prior_goal: ActiveGoal | None = None,
    new_goal: ActiveGoal | None = None,
    current_goal: ActiveGoal | None = None,
) -> str:
    """Render the assistant's response to a slash command.

    Pure function — no service state. Caller picks the action based on
    parser output + tracker mutation result.

    Args:
        action: One of ``"set"`` / ``"clear"`` / ``"status"`` /
            ``"clear_nothing"`` / ``"status_empty"``.
        prior_goal: For ``clear`` — the goal that was cleared.
        new_goal: For ``set`` — the just-set goal.
        current_goal: For ``status`` — the existing goal.
    """
    if action == "set" and new_goal is not None:
        return (
            f"🎯 Goal locked: **{new_goal.goal_text}**\n\n"
            f"I'll keep this in mind for the next {new_goal.max_turns} "
            f"turns. Type `/goal clear` any time to lift it, or "
            f"`/goal` to check progress."
        )
    if action == "clear" and prior_goal is not None:
        return (
            f"🎯 Goal lifted: ~~{prior_goal.goal_text}~~ "
            f"({prior_goal.turn_count} turns elapsed). "
            "Back to normal conversation."
        )
    if action == "clear_nothing":
        return "🎯 No goal was set — nothing to clear."
    if action == "status" and current_goal is not None:
        remaining = max(0, current_goal.max_turns - current_goal.turn_count)
        return (
            f"🎯 Active goal: **{current_goal.goal_text}**\n\n"
            f"Turn {current_goal.turn_count} of {current_goal.max_turns} "
            f"({remaining} remaining). "
            "Type `/goal clear` to lift, or `/goal <new text>` to replace."
        )
    if action == "status_empty":
        return (
            "🎯 No active goal. Set one with `/goal <description>` — for "
            "example: `/goal compile my research notes into a wiki article`."
        )
    # Defensive fallback — should never reach this with a valid action.
    return "🎯 Goal command received."
