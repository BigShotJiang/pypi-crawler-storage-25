"""Stale-claim scanner for wiki articles.

Wiki articles carry inline `(as of YYYY-MM, source)` markers next to
date-sensitive claims (financials, headcount, product status, prices,
percentages, company status). These markers are written by the kb-compile
skill (see ``defaults/skills/core/kb-compile/SKILL.md`` rule 19).

This module scans those markers across the vault and surfaces claims
whose marker date is older than a configurable threshold (default 6
months). Power users can review what's stale via the API / CLI; a
future heartbeat hook will pick ONE per day and re-research it
autonomously (P3.7 in plan-performance-roadmap.md).

The scanner is intentionally pure — no LLM, no network. It walks wiki
files, regex-matches markers, and returns a structured list. Cost on
Wolf's 1700-article vault: ~0.5s sequential, dominated by file reads.

Design choices:

- **Pure functions over a class**: easier to test in isolation. A
  ``StaleClaimScanner`` class would add ceremony without enabling
  anything we can't already do.
- **Per-line scan**: the line containing the marker IS the
  user-visible claim context. Reading line-by-line preserves line
  numbers for click-through navigation in future UI.
- **Multiple markers per line**: each marker contributes its own
  StaleClaim (rare but a single line CAN carry two).
- **Frozen dataclass**: returned values are descriptions of vault
  state, not mutable. Callers that need to track approval decisions
  build their own state on top.
"""

from __future__ import annotations

import logging
import re
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, date, datetime

from agntspace.vault.reader import VaultReader

log = logging.getLogger(__name__)


# Recognizes "(as of YYYY-MM)" and "(as of YYYY-MM, source-text)".
# Captures year, month, and optional source (everything after the
# comma up to the closing paren, with leading whitespace stripped).
# Non-greedy on the source to handle "(as of 2026-04, mem0.ai) and
# also (as of 2026-03)" on one line.
_AS_OF_MARKER_RE = re.compile(
    r"\(as of (\d{4})-(\d{2})(?:,\s*([^)]+?))?\)",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class StaleClaim:
    """A single `(as of YYYY-MM, ...)` marker exceeding the staleness threshold.

    Attributes:
        article_path: Logical vault path (e.g. ``knowledge/main/wiki/concepts/foo.md``).
        line_number: 1-based line number where the marker appears.
        line_text: Full text of the line (snippet for display).
        marker_year: Year from the marker, 4-digit (e.g. 2026).
        marker_month: Month from the marker, 1-12.
        marker_source: Optional source hint after the comma; empty
            string when the marker has no source.
        marker_raw: The raw matched marker text (e.g. ``"(as of 2026-04, mem0.ai)"``).
        age_months: How many months stale at scan time. Useful for
            sorting + display without recomputing from now-context.
    """

    article_path: str
    line_number: int
    line_text: str
    marker_year: int
    marker_month: int
    marker_source: str
    marker_raw: str
    age_months: int

    @property
    def marker_label(self) -> str:
        """Format the marker date as ``YYYY-MM`` for display."""
        return f"{self.marker_year:04d}-{self.marker_month:02d}"

    def to_dict(self) -> dict:
        """JSON-serialisable representation for API responses."""
        return {
            "article_path": self.article_path,
            "line_number": self.line_number,
            "line_text": self.line_text,
            "marker_label": self.marker_label,
            "marker_year": self.marker_year,
            "marker_month": self.marker_month,
            "marker_source": self.marker_source,
            "marker_raw": self.marker_raw,
            "age_months": self.age_months,
        }


def _age_in_months(marker_year: int, marker_month: int, now: date) -> int:
    """Compute calendar-month age between marker date and ``now``.

    Negative values (marker in the future) clamp to 0 — defensive,
    since a future marker isn't 'stale'. Pure function.
    """
    months = (now.year - marker_year) * 12 + (now.month - marker_month)
    return max(0, months)


def _valid_month(month: int) -> bool:
    """Validation gate — markers like ``(as of 2026-13)`` are typos."""
    return 1 <= month <= 12


def find_stale_in_text(
    text: str,
    *,
    article_path: str,
    threshold_months: int,
    now: date,
) -> list[StaleClaim]:
    """Scan ``text`` for stale `(as of YYYY-MM, ...)` markers.

    Returns markers whose age in calendar months is ``>= threshold_months``.
    Pure function: no I/O, no global state. Tests can pass any ``now``.

    Args:
        text: Article body to scan.
        article_path: Logical vault path; copied into each result.
        threshold_months: Minimum age (in months) for "stale". Default
            6 in the calling layer. ``threshold_months=0`` returns
            ALL markers regardless of age (useful for inspection).
        now: Reference date; pass UTC ``today`` from the caller to
            keep the function deterministic + testable.

    Returns:
        List of StaleClaim in document order (line ascending, then
        marker offset within line).
    """
    if not text or threshold_months < 0:
        return []

    results: list[StaleClaim] = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        for match in _AS_OF_MARKER_RE.finditer(line):
            try:
                year = int(match.group(1))
                month = int(match.group(2))
            except (TypeError, ValueError):
                # Defensive — regex already constrains to digits, but
                # be safe against future regex tweaks.
                continue
            if not _valid_month(month):
                # Typo'd marker like (as of 2026-13). Skip silently;
                # not our job to lint that here.
                continue
            age = _age_in_months(year, month, now)
            if age < threshold_months:
                continue
            source = (match.group(3) or "").strip()
            results.append(
                StaleClaim(
                    article_path=article_path,
                    line_number=line_no,
                    line_text=line.strip(),
                    marker_year=year,
                    marker_month=month,
                    marker_source=source,
                    marker_raw=match.group(0),
                    age_months=age,
                )
            )
    return results


def _iter_wiki_articles(
    reader: VaultReader,
) -> Iterable[tuple[str, str]]:
    """Yield ``(logical_path, body)`` for every wiki article under
    ``knowledge/<kb>/wiki/`` (excluding archives + history).

    Walks via the OS scandir-backed ``list_files`` path (with cache
    enabled in production). On a failed file read, logs at debug
    and continues — one bad file doesn't kill the sweep.
    """
    try:
        files = reader.list_files(pattern="**/*.md")
    except Exception:
        log.debug("stale_claims: list_files failed", exc_info=True)
        return

    for file_path in files:
        # Filter to wiki article paths only. Logical paths typically
        # look like ``knowledge/<kb>/wiki/<subdir>/<name>.md``. We
        # check the path contains ``/wiki/`` AND not a dot-prefixed
        # segment (which list_files's filter normally drops, but
        # belt-and-braces).
        relative: str
        if reader.paths:
            relative = reader.paths.to_logical(file_path)
        else:
            try:
                relative = str(file_path.relative_to(reader.vault_dir)).replace("\\", "/")
            except ValueError:
                continue
        if "/wiki/" not in relative:
            continue
        if any(part.startswith(".") for part in relative.split("/") if part):
            continue
        try:
            doc = reader.read(relative)
        except Exception:
            log.debug("stale_claims: read failed for %s", relative, exc_info=True)
            continue
        yield (relative, doc.content)


def find_stale_claims_in_vault(
    reader: VaultReader,
    *,
    threshold_months: int = 6,
    now: date | None = None,
    limit: int = 0,
) -> list[StaleClaim]:
    """Walk every wiki article in the vault and return stale claims.

    Args:
        reader: VaultReader for the active vault.
        threshold_months: See ``find_stale_in_text``. Default 6
            (knowledge-rots window from plan-research-perplexity.md).
            Set 0 to return ALL markers regardless of age.
        now: Reference date. Defaults to UTC today.
        limit: Cap the returned list size. 0 = unlimited. Results
            are sorted oldest-first BEFORE the limit applies, so
            the cap surfaces the worst offenders.

    Returns:
        List of StaleClaim sorted oldest-first (age_months desc),
        then by article_path + line_number for stable ordering of
        same-age entries.
    """
    if now is None:
        now = datetime.now(UTC).date()
    if threshold_months < 0:
        threshold_months = 0

    all_results: list[StaleClaim] = []
    for path, body in _iter_wiki_articles(reader):
        all_results.extend(
            find_stale_in_text(
                body,
                article_path=path,
                threshold_months=threshold_months,
                now=now,
            )
        )

    # Sort: oldest first (age_months desc), then stable by path + line.
    all_results.sort(
        key=lambda c: (-c.age_months, c.article_path, c.line_number),
    )

    if limit > 0:
        return all_results[:limit]
    return all_results
