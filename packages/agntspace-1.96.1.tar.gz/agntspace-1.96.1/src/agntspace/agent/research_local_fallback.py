"""Local-first DDG + scrape + Ollama fallback for `research_topic`.

P5.3 — closes the "research is unusable without Perplexity" gap from
plan-performance-roadmap.md.

Architecture commitments (locked):

1.  **Master kill switch defaults to FALSE.** Users opt in by editing
    `_meta/research-local-fallback/config/fallback.yaml`. The fallback
    quality is honestly lower than sonar-pro; making it default-on
    would silently degrade the research surface for everyone who
    hasn't configured Perplexity yet. Opt-in keeps the principle
    "no silent quality regressions" intact.

2.  **Fires ONLY when Perplexity is unavailable.** The Perplexity
    client check happens first; the fallback is a fall-through, never
    a competing path. Both can't fire on the same call. Cache hits
    are checked even earlier — a fallback dossier produced last week
    is returned just like a Perplexity dossier.

3.  **Same dossier shape on disk.** Triple extraction, file write,
    mention indexer, corroboration accumulator, and the research
    cache all read `dossier_text + citations` from the existing
    `_exec_research_topic` body. The fallback returns the same shape
    so the rest of the pipeline runs unchanged. The only difference
    that lands in frontmatter is `provider: ddg+local` (vs
    `provider: perplexity`) and `cost_usd: 0.000000` (vs the actual
    Perplexity cost).

4.  **Pure orchestration with injected callables.** The module owns
    no state — every external dependency (search, scrape, relevance
    check, LLM synthesis, progress logging) is passed in. Makes the
    full happy/fail-open/disabled matrix testable without standing
    up the ToolExecutor.

5.  **Fail-open at every boundary.** Missing skill loader → defaults.
    Broken YAML → defaults. Zero search results → `no_results`.
    All pages blocked by quality/relevance gates → `no_usable_pages`.
    Synthesis LLM call raises → `synthesis_failed`. Each branch
    returns a structured `LocalFallbackResult` rather than raising.

6.  **Reuses existing skill substrate.** Quality + relevance gates
    come from the same `browser-automation` skill that
    `_exec_research_scrape` reads. URL safety + robots.txt come from
    the same `url-safety` skill. The fallback config only carries
    knobs the OTHER substrates don't already own: enabled flag,
    page cap, synthesis tier, prompt template.
"""

from __future__ import annotations

import logging
import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urlparse

log = logging.getLogger(__name__)

_VALID_TIERS: tuple[str, ...] = ("fast", "capable", "reasoning")  # arch:deterministic — closed enum of supported synthesis tiers
_VALID_SEARCH_BACKENDS: tuple[str, ...] = ("ddg", "searxng")  # arch:deterministic — closed enum of search backends (P5.6)

# arch:deterministic — sentinel model tag stamped in the digest frontmatter so
# downstream code (UI, /costs aggregator) can distinguish the fallback path
# from a real Perplexity dossier without parsing the body.
FALLBACK_MODEL_TAG: str = "ddg+local"

# arch:deterministic — synthesis prompt template fallback when the YAML one is
# missing or malformed. Mirrors the perplexity prompt shape so the LLM emits
# the same 7-section dossier the rest of the pipeline expects.
_FALLBACK_PROMPT_TEMPLATE: str = (
    "You are a research analyst writing from web search results.\n\n"
    "Topic: {topic}\n"
    "Today: {today_iso}\n\n"
    "{baseline_section}\n\n"
    "SCRAPED SOURCES (treat as primary evidence):\n"
    "{pages_section}\n\n"
    "Produce a 7-section dossier:\n\n"
    "## Summary\n"
    "## Key Facts\n"
    "## Timeline\n"
    "## Key Players\n"
    "## Contrarian Views\n"
    "## Recommended Further Reading\n"
    "## Open Questions\n\n"
    "Rules:\n"
    "- Cite facts inline using [N] referring to the scraped source number.\n"
    "- Mark facts older than 6 months with (as of YYYY-MM).\n"
    "- NEVER fabricate. If a source doesn't say something, omit it.\n"
    "- Be concise. Aim for under 1800 tokens.\n"
)

# arch:deterministic — defaults applied when the skill YAML is absent OR
# malformed. Same fail-open posture as every other research config loader.
_FALLBACK_CONFIG: dict[str, Any] = {
    "enabled": False,
    "max_pages": 5,
    "synthesis_max_tokens": 1800,
    "synthesis_model_tier": "capable",
    "prompt_template": _FALLBACK_PROMPT_TEMPLATE,
    # P5.6 (2026-05-17) — search backend selection. `ddg` is the safe
    # default (no extra setup). `searxng` opts into a self-hosted instance.
    "search_backend": "ddg",
    "searxng_base_url": "",
}


@dataclass(frozen=True)
class LocalFallbackResult:
    """Result of one local-fallback orchestration call.

    Shape mirrors what `_exec_research_topic` needs to feed into the
    rest of its pipeline (triple extraction, file write, etc.) when
    coming from a Perplexity response. The `reason` field is empty
    when `ok=True` and carries a closed-enum failure code otherwise.
    """

    ok: bool
    dossier_text: str = ""
    citations: list[dict] = field(default_factory=list)
    pages_attempted: int = 0
    pages_scraped: int = 0
    pages_skipped_quality: int = 0
    pages_skipped_relevance: int = 0
    pages_skipped_safety: int = 0
    pages_skipped_robots: int = 0
    reason: str = ""
    error: str = ""


def resolve_fallback_config(skill_loader: Any) -> dict:
    """Read `_meta/research-local-fallback/config/fallback.yaml` with fallback.

    Fail-open at every error: no loader, missing file, malformed YAML
    all return `_FALLBACK_CONFIG`. Per-field merging so a partial
    YAML override (e.g. enabling the flag but leaving prompt blank)
    still produces a usable config.
    """
    cfg: dict[str, Any] = dict(_FALLBACK_CONFIG)
    if skill_loader is None or not hasattr(skill_loader, "load_skill_config_file"):
        return cfg
    try:
        raw = skill_loader.load_skill_config_file(
            "research-local-fallback", "fallback.yaml",
        )
    except Exception:  # noqa: BLE001 — broken loader is fail-open
        return cfg
    if not isinstance(raw, dict):
        return cfg

    if isinstance(raw.get("enabled"), bool):
        cfg["enabled"] = raw["enabled"]
    if isinstance(raw.get("max_pages"), int) and raw["max_pages"] > 0:
        cfg["max_pages"] = min(raw["max_pages"], 20)  # hard cap
    if isinstance(raw.get("synthesis_max_tokens"), int) and raw["synthesis_max_tokens"] > 0:
        cfg["synthesis_max_tokens"] = min(raw["synthesis_max_tokens"], 8000)
    tier_val = raw.get("synthesis_model_tier")
    if isinstance(tier_val, str) and tier_val in _VALID_TIERS:
        cfg["synthesis_model_tier"] = tier_val
    pt = raw.get("prompt_template")
    if isinstance(pt, str) and pt.strip():
        cfg["prompt_template"] = pt
    # P5.6 search backend selection
    backend_val = raw.get("search_backend")
    if isinstance(backend_val, str) and backend_val in _VALID_SEARCH_BACKENDS:
        cfg["search_backend"] = backend_val
    sxng_url = raw.get("searxng_base_url")
    if isinstance(sxng_url, str):
        cfg["searxng_base_url"] = sxng_url.strip()
    return cfg


def is_enabled(cfg: dict) -> bool:
    """Master kill switch."""
    return bool(cfg.get("enabled", False))


def build_pages_section(scraped_pages: list[dict], *, per_page_char_cap: int = 2400) -> str:
    """Render scraped pages as a numbered prompt section.

    Each page is capped at `per_page_char_cap` to keep the prompt
    bounded — local LLMs have context limits and scraping a long
    article can blow them. The cap is generous enough to capture
    the lead paragraphs which carry the load-bearing facts.
    """
    if not scraped_pages:
        return "(no pages scraped)"
    parts: list[str] = []
    for i, page in enumerate(scraped_pages, 1):
        title = page.get("title") or "(untitled)"
        url = page.get("url") or ""
        text = (page.get("text") or "")[:per_page_char_cap]
        parts.append(f"[{i}] {title}\n    URL: {url}\n    {text}\n")
    return "\n".join(parts)


def build_synthesis_prompt(
    *,
    topic: str,
    today_iso: str,
    baseline_section: str,
    scraped_pages: list[dict],
    prompt_template: str,
    per_page_char_cap: int = 2400,
) -> str:
    """Compose the local LLM's synthesis prompt.

    The `prompt_template` must contain at least `{topic}`, `{today_iso}`,
    `{baseline_section}`, and `{pages_section}` placeholders. Missing
    placeholders are silently filled — `str.format_map` with a defensive
    default dict so a half-edited YAML template doesn't raise.
    """
    pages_section = build_pages_section(scraped_pages, per_page_char_cap=per_page_char_cap)
    fields: dict[str, str] = {
        "topic": topic,
        "today_iso": today_iso,
        "baseline_section": baseline_section or "(no vault baseline)",
        "pages_section": pages_section,
    }

    class _DefensiveDict(dict):
        def __missing__(self, key: str) -> str:  # type: ignore[override]
            return ""

    try:
        return prompt_template.format_map(_DefensiveDict(fields))
    except Exception:  # noqa: BLE001 — malformed template fails open
        return _FALLBACK_PROMPT_TEMPLATE.format_map(_DefensiveDict(fields))


def _safe_domain(url: str) -> str:
    """Extract a domain for citation display; empty string on parse failure."""
    try:
        parsed = urlparse(url)
    except Exception:  # noqa: BLE001
        return ""
    return (parsed.netloc or "").replace("www.", "")


def build_citations(scraped_pages: list[dict]) -> list[dict]:
    """Turn scraped-page metadata into the citation list shape.

    Matches the shape `_format_digest_markdown` consumes: each entry
    is `{url, title, date}`. Date is empty because DDG search results
    don't carry structured publication dates reliably.
    """
    citations: list[dict] = []
    for page in scraped_pages:
        url = page.get("url") or ""
        if not url:
            continue
        citations.append({
            "url": url,
            "title": page.get("title") or _safe_domain(url),
            "date": "",
        })
    return citations


# Reusable counter so we don't introduce a third "scraping" path that
# can drift from `_exec_research_scrape`. The caller passes
# `scrape_filter_fn` (which wraps `_check_topic_relevance`) and
# `quality_cfg`/`relevance_cfg` directly.

async def synthesize_via_ddg_and_local(
    *,
    topic: str,
    today_iso: str,
    baseline_section: str,
    config: dict,
    quality_cfg: dict,
    relevance_cfg: dict,
    # Injected callables (testability):
    search_fn: Callable[[str, int], list[dict]],
    scrape_many_fn: Callable[[list[str], int], list[dict]],
    relevance_check_fn: Callable[[str, str, dict], tuple[bool, dict]],
    synth_fn: Callable[[str, int, str], Awaitable[str]],
    log_progress_fn: Callable[[str, str, dict, str], None] | None = None,
) -> LocalFallbackResult:
    """Full local-fallback orchestration: search → filter → scrape → synthesize.

    Returns `LocalFallbackResult` with the dossier text + citations on
    success. Every failure path returns ok=False with a structured
    `reason` so the caller can route the right activity event.

    Callables (injected for testability):

    * `search_fn(topic, max_results) → list[dict]` — DDG wrapper. Each
      result must have `title`, `href`/`url`, optionally `body`.
    * `scrape_many_fn(urls, min_len) → list[dict]` — `{url, text, error}`
      per input. Order MUST match input. (Matches
      `agntspace.integrations.browser.scrape_many` shape.)
    * `relevance_check_fn(content, topic, cfg) → (bool, dict)` —
      `ToolExecutor._check_topic_relevance`.
    * `synth_fn(prompt, max_tokens, tier) → str` async — LLM completion
      via local model. The caller decides how to route (provider-direct
      or orchestrator dispatch with prefer_local=True).
    * `log_progress_fn(action, summary, details, importance)` —
      `_log_research_progress` callback for sticky toast updates.

    The orchestration mirrors `_exec_research_scrape`'s pipeline but
    INSIDE the research synthesis path (vs. saving raw scrapes to KB
    inbox + relying on the watcher).
    """
    def _emit(action: str, summary: str, details: dict, importance: str) -> None:
        if log_progress_fn is None:
            return
        try:
            log_progress_fn(action, summary, details, importance)
        except Exception:  # noqa: BLE001 — broken logger never blocks synthesis
            log.debug("log_progress_fn raised in fallback", exc_info=True)

    max_pages = int(config.get("max_pages", 5))
    synthesis_max_tokens = int(config.get("synthesis_max_tokens", 1800))
    synthesis_tier = str(config.get("synthesis_model_tier", "capable"))
    if synthesis_tier not in _VALID_TIERS:
        synthesis_tier = "capable"
    prompt_template = config.get("prompt_template") or _FALLBACK_PROMPT_TEMPLATE

    # ── Step 1: DDG search ────────────────────────────────────────────
    _emit(
        "research_progress",
        "Searching the web (local fallback)…",
        {"topic": topic, "phase": "searching", "model": FALLBACK_MODEL_TAG},
        "low",
    )
    try:
        # Fetch a few extra so quality/relevance gates have headroom
        results = search_fn(topic, max_pages + 3)
    except Exception as exc:  # noqa: BLE001
        log.exception("DDG search failed in local fallback (topic=%r)", topic)
        return LocalFallbackResult(
            ok=False,
            reason="search_failed",
            error=f"{type(exc).__name__}: {exc}",
        )

    if not results:
        return LocalFallbackResult(ok=False, reason="no_results")

    # Filter PDFs / video / social — same shape as `_exec_research_scrape`
    skip_domains = {
        "youtube.com", "twitter.com", "x.com", "facebook.com",
        "reddit.com", "tiktok.com",
    }
    filtered: list[dict] = []
    for r in results:
        url = r.get("href") or r.get("url") or ""
        if not url:
            continue
        domain = _safe_domain(url)
        if domain in skip_domains:
            continue
        if url.lower().endswith(".pdf"):
            continue
        filtered.append({
            "title": r.get("title") or "",
            "href": url,
            "body": r.get("body") or "",
        })
        if len(filtered) >= max_pages:
            break

    if not filtered:
        return LocalFallbackResult(
            ok=False,
            reason="no_usable_search_results",
            pages_attempted=len(results),
        )

    # ── Step 2: scrape in parallel ───────────────────────────────────
    _emit(
        "research_progress",
        f"Scraping {len(filtered)} pages…",
        {"topic": topic, "phase": "scraping", "page_count": len(filtered)},
        "low",
    )
    urls = [r["href"] for r in filtered]
    min_words = int(quality_cfg.get("min_words_per_source", 150))
    try:
        scrape_results = scrape_many_fn(urls, 200)  # min_len=200 in agent-browser path
    except Exception as exc:  # noqa: BLE001
        log.exception("scrape_many failed in local fallback (topic=%r)", topic)
        return LocalFallbackResult(
            ok=False,
            reason="scrape_failed",
            error=f"{type(exc).__name__}: {exc}",
            pages_attempted=len(filtered),
        )

    # ── Step 3: quality + relevance gates ────────────────────────────
    scraped_pages: list[dict] = []
    skipped_quality = 0
    skipped_relevance = 0
    for r, sr in zip(filtered, scrape_results, strict=False):
        text = (sr or {}).get("text") or ""
        if not text:
            continue
        word_count = len(re.findall(r"\w+", text))
        if word_count < min_words:
            skipped_quality += 1
            continue
        try:
            is_relevant, _detail = relevance_check_fn(text, topic, relevance_cfg)
        except Exception:  # noqa: BLE001 — relevance failure = treat as off-topic
            is_relevant = False
        if not is_relevant:
            skipped_relevance += 1
            continue
        scraped_pages.append({
            "title": r["title"],
            "url": r["href"],
            "text": text,
        })

    if not scraped_pages:
        return LocalFallbackResult(
            ok=False,
            reason="no_usable_pages",
            pages_attempted=len(filtered),
            pages_skipped_quality=skipped_quality,
            pages_skipped_relevance=skipped_relevance,
        )

    # ── Step 4: synthesize via local LLM ─────────────────────────────
    _emit(
        "research_progress",
        f"Synthesizing dossier from {len(scraped_pages)} sources (local)…",
        {
            "topic": topic,
            "phase": "synthesizing",
            "model": FALLBACK_MODEL_TAG,
            "page_count": len(scraped_pages),
        },
        "low",
    )
    prompt = build_synthesis_prompt(
        topic=topic,
        today_iso=today_iso,
        baseline_section=baseline_section,
        scraped_pages=scraped_pages,
        prompt_template=prompt_template,
    )
    try:
        dossier_text = await synth_fn(prompt, synthesis_max_tokens, synthesis_tier)
    except Exception as exc:  # noqa: BLE001
        log.exception("Local synthesis failed (topic=%r)", topic)
        return LocalFallbackResult(
            ok=False,
            reason="synthesis_failed",
            error=f"{type(exc).__name__}: {exc}",
            pages_attempted=len(filtered),
            pages_scraped=len(scraped_pages),
            pages_skipped_quality=skipped_quality,
            pages_skipped_relevance=skipped_relevance,
        )

    if not isinstance(dossier_text, str) or not dossier_text.strip():
        return LocalFallbackResult(
            ok=False,
            reason="empty_dossier",
            pages_attempted=len(filtered),
            pages_scraped=len(scraped_pages),
            pages_skipped_quality=skipped_quality,
            pages_skipped_relevance=skipped_relevance,
        )

    citations = build_citations(scraped_pages)
    return LocalFallbackResult(
        ok=True,
        dossier_text=dossier_text.strip(),
        citations=citations,
        pages_attempted=len(filtered),
        pages_scraped=len(scraped_pages),
        pages_skipped_quality=skipped_quality,
        pages_skipped_relevance=skipped_relevance,
    )
