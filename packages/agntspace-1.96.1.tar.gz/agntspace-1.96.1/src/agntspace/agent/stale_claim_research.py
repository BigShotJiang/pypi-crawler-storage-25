"""Autonomous stale-claim re-research loop (P3.7 + plan-research-perplexity.md #8).

The 2026-05-14 evening session shipped the stale-claim SCANNER
(``agent/stale_claims.py``) as a read-only surface: list ``(as of YYYY-MM)``
markers older than ``threshold_months``. This module closes the loop on
the autonomous side: heartbeat picks ONE stale claim per day, fires
``research_topic(...)`` against just that claim, and emits a Rule 21
``research_update`` proposal so the user can review the fresh dossier.

Architectural commitments:

1. **One claim per tick.** ``max_per_run`` (default 1) guards the cost
   ceiling — heartbeat-driven cron sweeps over a 1700-article vault
   could fire dozens of Perplexity calls per day otherwise. Defaults
   match plan-research-perplexity.md §8: ~$0.005 per call × 1/day =
   ~$0.15/month.
2. **Cooldown by ``(article_path, marker_label)``.** A JSON state file
   at ``<vault>/agntspace/research/stale_claim_cooldowns.json`` records
   when each claim was last researched. Pre-cooldown picks are
   skipped — without this, the scanner returns the same oldest claim
   every cycle and we'd re-pick it forever.
3. **Reuse the existing ``_exec_research_topic`` engine.** It already
   handles: Perplexity call, dossier write, frontmatter, mention
   indexer, baseline scan, cost recording. We don't reinvent any of
   it — we just feed in a topic derived from the stale line.
4. **Always emit a proposal on success.** Even when the research result
   doesn't surface obvious "value drift", the user gets a fresh
   dossier + Rule 21 inbox item. Smarter drift detection (parse
   contradictions, extract new value, compare to old) is a follow-up.
   This matches the session's "ship visibility, defer autonomous
   action" rule: the loop fires + lands a proposal; humans decide.
5. **Master kill switch off by default.** ``daily_re_research_enabled:
   false`` in ``_meta/research-perplexity/config/perplexity.yaml``.
   Manual ``GET /api/research/stale-claims`` is the read-only surface
   users explore first; the autonomous loop is opt-in once they've
   verified the scanner's output.
6. **Fail-open at every boundary.** Broken cooldown file, broken
   research executor, broken proposal store → log + skip. The
   heartbeat tick MUST stay alive even when the autonomous research
   subsystem is partially wired.

The service is pure-engine. Every threshold + cadence + cooldown
window lives in YAML (Rule 12).
"""

from __future__ import annotations

import json
import logging
import re
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from agntspace.agent.stale_claims import (
    StaleClaim,
    find_stale_claims_in_vault,
)

log = logging.getLogger(__name__)


# arch:deterministic — JSON state file name + version.  Bumping the
# version invalidates cooldown state on rehydrate (treats every entry
# as expired).  Empty file path means "no persistence — in-memory only".
_COOLDOWN_FILE_NAME = "stale_claim_cooldowns.json"
_COOLDOWN_SCHEMA_VERSION = 1


_FALLBACK_CONFIG: dict[str, Any] = {  # arch:deterministic — engine fallback for YAML; tuning lives in _meta/research-perplexity/config/perplexity.yaml stale_claim block (Rule 12)
    "daily_re_research_enabled": False,
    "threshold_months": 6,
    "cadence_hours": 24,
    "cooldown_days": 14,
    "max_per_run": 1,
}


# Used to extract a wikilinked entity from a line: ``[[Foo Bar]]`` →
# "Foo Bar".  Falls back to the first multi-word Title Case run when
# no wikilink is present.
_WIKILINK_RE = re.compile(r"\[\[([^\]\|]+?)(?:\|[^\]]+)?\]\]")
_TITLE_CASE_RUN_RE = re.compile(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,})\b")


def cooldown_key(article_path: str, marker_label: str) -> str:
    """Canonical key for the cooldown JSON state file."""
    return f"{article_path}|{marker_label}"


def derive_topic_from_line(
    line_text: str,
    *,
    article_title: str = "",
    max_chars: int = 160,
) -> str:
    """Turn a stale-claim line into a research-topic prompt.

    Stale-claim lines look like:
        "Renewcell is based in Stockholm (as of 2024-03, source-X)."
        "Acme Corp had $50M in revenue (as of 2023-Q4)."

    The topic feeds straight to Perplexity, so it should read like
    natural-language research input.  Strategy:

    1. Strip every ``(as of ...)`` marker so the prompt doesn't carry
       a date the LLM might fixate on.
    2. Strip wikilink brackets but keep the inner text.
    3. Prefix with the article title when present + trailing colon.
    4. Truncate to ``max_chars`` so we don't blow Perplexity's prompt
       budget on a paragraph-long marker line.

    Returns an empty string only when the stripped line is empty,
    signalling "no topic derivable — skip this claim".
    """
    if not line_text:
        return ""
    # 1. Strip every (as of YYYY-MM[, ...]) marker.
    from agntspace.agent.stale_claims import _AS_OF_MARKER_RE
    stripped = _AS_OF_MARKER_RE.sub("", line_text)
    # 2. Strip wikilink brackets but keep the inner text.
    stripped = _WIKILINK_RE.sub(r"\1", stripped)
    # Collapse any double spaces left over from removal.
    stripped = re.sub(r"\s+", " ", stripped).strip(" .,:")
    if not stripped:
        return ""
    # 3. Prefix with the article title for context (if it's not already
    #    a substring of the line itself).
    title = (article_title or "").strip()
    if title and title.lower() not in stripped.lower():
        prefix = f"{title}: "
    else:
        prefix = ""
    topic = prefix + stripped
    # 4. Truncate.
    if max_chars > 0 and len(topic) > max_chars:
        topic = topic[: max_chars - 1].rstrip() + "…"
    return topic


def kb_slug_from_article_path(article_path: str) -> str:
    """Extract the KB slug from a wiki article's logical path.

    Logical paths shape: ``knowledge/<kb>/wiki/<subdir>/<name>.md``.
    Returns an empty string when the path doesn't match.  Defensive
    against slashes-vs-backslashes (Windows logical paths normalise
    via ``replace("\\\\", "/")`` upstream, but we double-guard).
    """
    if not article_path:
        return ""
    normalised = article_path.replace("\\", "/")
    parts = [p for p in normalised.split("/") if p]
    if len(parts) >= 2 and parts[0] == "knowledge":
        return parts[1]
    return ""


def load_cooldowns(state_path: Path) -> dict[str, float]:
    """Read the cooldown state file.

    Returns empty dict on any failure (missing file, malformed JSON,
    permission error, schema mismatch).  Pre-existing entries from a
    different schema version are dropped — better to re-research one
    extra claim than to honour a stale cooldown contract.
    """
    if not state_path or not state_path.exists():
        return {}
    try:
        raw = state_path.read_text(encoding="utf-8")
        data = json.loads(raw)
    except Exception:
        log.debug("cooldowns: read/parse failed for %s", state_path, exc_info=True)
        return {}
    if not isinstance(data, dict):
        return {}
    if data.get("schema_version") != _COOLDOWN_SCHEMA_VERSION:
        return {}
    entries = data.get("entries")
    if not isinstance(entries, dict):
        return {}
    cleaned: dict[str, float] = {}
    for k, v in entries.items():
        if not isinstance(k, str):
            continue
        try:
            cleaned[k] = float(v)
        except (TypeError, ValueError):
            continue
    return cleaned


def save_cooldowns(state_path: Path, cooldowns: dict[str, float]) -> None:
    """Persist cooldown state. Atomic write via .tmp + replace.

    Failures are logged at debug — the loop continues; the next tick
    will re-pick the same claim, which is fine (the dossier write
    succeeded; the worst case is one extra research call).
    """
    if not state_path:
        return
    try:
        state_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = state_path.with_suffix(state_path.suffix + ".tmp")
        payload = {
            "schema_version": _COOLDOWN_SCHEMA_VERSION,
            "entries": cooldowns,
        }
        tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        tmp.replace(state_path)
    except Exception:
        log.debug("cooldowns: save failed for %s", state_path, exc_info=True)


def prune_cooldowns(
    cooldowns: dict[str, float],
    *,
    now: float,
    cooldown_days: int,
) -> dict[str, float]:
    """Drop entries older than ``cooldown_days``. Pure function."""
    if cooldown_days <= 0:
        return {}
    cutoff = now - cooldown_days * 86400.0
    return {k: v for k, v in cooldowns.items() if v >= cutoff}


def pick_next_candidate(
    claims: list[StaleClaim],
    cooldowns: dict[str, float],
) -> StaleClaim | None:
    """Pick the oldest stale claim not currently in cooldown.

    ``claims`` is already sorted oldest-first by the scanner.  We walk
    once + return the first whose ``cooldown_key`` is absent from
    ``cooldowns``.  None means every stale claim is currently cooling
    down — nothing to do this tick.
    """
    for claim in claims:
        key = cooldown_key(claim.article_path, claim.marker_label)
        if key not in cooldowns:
            return claim
    return None


def resolve_config(skill_loader: object | None) -> dict[str, Any]:
    """Read the ``stale_claim`` block from ``research-perplexity/config/perplexity.yaml``.

    Falls back to ``_FALLBACK_CONFIG`` on every failure path so the
    loop is YAML-tunable without breaking when the YAML is malformed.
    """
    if skill_loader is None:
        return dict(_FALLBACK_CONFIG)
    try:
        cfg = skill_loader.load_skill_config_file(  # type: ignore[attr-defined]
            "research-perplexity", "perplexity.yaml",
        )
    except Exception:
        log.debug("stale_claim: YAML read failed", exc_info=True)
        return dict(_FALLBACK_CONFIG)
    if not isinstance(cfg, dict):
        return dict(_FALLBACK_CONFIG)
    section = cfg.get("stale_claim")
    if not isinstance(section, dict):
        return dict(_FALLBACK_CONFIG)
    merged = dict(_FALLBACK_CONFIG)
    for k in merged:
        if k in section:
            merged[k] = section[k]
    return merged


class StaleClaimResearcher:
    """Heartbeat-driven sweep: one stale claim → fresh dossier → proposal.

    Construct with the post-init dependency-injection pattern used
    elsewhere in main.py.  Every dependency is optional in the
    constructor signature so tests + minimal installs can build the
    object without standing up the full stack.

    Public surface:
        - ``run_once_if_due()``: heartbeat calls this on each tick.
          Returns a status dict for log + activity event.
        - ``config()``: current YAML-resolved knobs (read-only).
    """

    def __init__(
        self,
        *,
        vault_reader: object | None = None,
        tool_executor: object | None = None,
        proposal_store: object | None = None,
        skill_loader: object | None = None,
        activity_logger: object | None = None,
        state_dir: Path | None = None,
    ) -> None:
        self._vault_reader = vault_reader
        self._tool_executor = tool_executor
        self._proposal_store = proposal_store
        self._skill_loader = skill_loader
        self._activity_logger = activity_logger
        self._state_dir = state_dir
        # Internal — exposed for tests.
        self._last_run_ts: float = 0.0

    # ── Public API ───────────────────────────────────────────────────

    def config(self) -> dict[str, Any]:
        """Current YAML-resolved config (cheap to call)."""
        return resolve_config(self._skill_loader)

    @property
    def enabled(self) -> bool:
        """Master kill switch + dependency presence check."""
        cfg = self.config()
        if not bool(cfg.get("daily_re_research_enabled", False)):
            return False
        # Hard preconditions — without these the loop can't fire.
        if self._vault_reader is None:
            return False
        if self._tool_executor is None:
            return False
        if self._proposal_store is None:
            return False
        return True

    @property
    def cadence_hours(self) -> float:
        return float(self.config().get("cadence_hours", 24))

    @property
    def cooldown_path(self) -> Path | None:
        if self._state_dir is None:
            return None
        return self._state_dir / _COOLDOWN_FILE_NAME

    async def run_once_if_due(self) -> dict[str, Any]:
        """Run one autonomous research pick if the master switch is on
        AND the cadence has elapsed.

        Returns a dict describing what happened.  Always returns a
        dict — never raises — so the heartbeat loop can carry on even
        when this layer is partially broken.

        Status codes:
            ``disabled``: master switch off OR dependencies missing.
            ``deferred``: cadence not yet elapsed.
            ``no_candidates``: no stale claims OR every one in cooldown.
            ``no_topic``: candidate line couldn't be turned into a
              prompt (very short / corrupt line).
            ``research_failed``: ``_exec_research_topic`` returned
              ``{"ok": False, ...}``.
            ``proposal_failed``: proposal store rejected the create.
            ``ok``: dossier written + proposal landed.
        """
        if not self.enabled:
            return {"status": "disabled"}

        now_ts = time.time()
        cadence_seconds = self.cadence_hours * 3600
        if now_ts - self._last_run_ts < cadence_seconds:
            return {"status": "deferred"}

        cfg = self.config()
        threshold = int(cfg.get("threshold_months", 6))
        cooldown_days = int(cfg.get("cooldown_days", 14))
        # max_per_run is reserved for future fanout; today the loop
        # processes exactly one pick.  Keep the read so it's visible
        # in the status dict for debugging.
        max_per_run = max(1, int(cfg.get("max_per_run", 1)))  # noqa: F841

        # 1. Scan vault for stale claims.
        try:
            claims = find_stale_claims_in_vault(
                self._vault_reader,  # type: ignore[arg-type]
                threshold_months=threshold,
                now=datetime.now(UTC).date(),
                limit=0,
            )
        except Exception:
            log.debug("stale_claim: scanner raised", exc_info=True)
            return {"status": "no_candidates", "reason": "scanner_failed"}

        # 2. Load cooldowns + prune expired entries.
        state_path = self.cooldown_path
        cooldowns_raw = load_cooldowns(state_path) if state_path else {}
        cooldowns = prune_cooldowns(
            cooldowns_raw, now=now_ts, cooldown_days=cooldown_days,
        )

        # 3. Pick first claim not in cooldown.
        candidate = pick_next_candidate(claims, cooldowns)
        if candidate is None:
            # Save the pruned cooldowns even when there's nothing to
            # do, so the file doesn't grow unbounded across many ticks
            # where no candidate was picked.
            if state_path and cooldowns != cooldowns_raw:
                save_cooldowns(state_path, cooldowns)
            self._last_run_ts = now_ts
            return {
                "status": "no_candidates",
                "stale_count": len(claims),
                "cooldown_count": len(cooldowns),
            }

        # 4. Build the research-topic input.
        # The article title isn't directly available on StaleClaim; use
        # the slug derived from the basename as a best-effort fallback.
        article_title = _article_title_from_path(candidate.article_path)
        topic = derive_topic_from_line(
            candidate.line_text,
            article_title=article_title,
        )
        if not topic:
            # Mark cooldown anyway so we don't pick this broken line
            # every tick.  Doesn't burn an LLM call; honours the
            # contract that "every pick advances state".
            cooldowns[cooldown_key(candidate.article_path, candidate.marker_label)] = now_ts
            if state_path:
                save_cooldowns(state_path, cooldowns)
            self._last_run_ts = now_ts
            return {
                "status": "no_topic",
                "article_path": candidate.article_path,
                "marker_label": candidate.marker_label,
            }

        target_kb = kb_slug_from_article_path(candidate.article_path) or "main"

        # 5. Fire the existing research_topic engine.
        try:
            result = self._tool_executor._exec_research_topic(  # type: ignore[union-attr]
                {
                    "topic": topic,
                    "target_kb": target_kb,
                    "save_to_kb": True,
                    "deep_baseline_scan": False,
                    "force_fresh": False,
                }
            )
        except Exception:
            log.debug(
                "stale_claim: _exec_research_topic raised for %s",
                candidate.article_path,
                exc_info=True,
            )
            self._last_run_ts = now_ts
            self._emit_activity(
                action="stale_claim_research_failed",
                summary=f"Stale-claim research raised on {candidate.article_path}",
                importance="low",
                details={
                    "article_path": candidate.article_path,
                    "marker_label": candidate.marker_label,
                    "reason": "executor_exception",
                },
            )
            return {
                "status": "research_failed",
                "reason": "executor_exception",
                "article_path": candidate.article_path,
            }

        if not isinstance(result, dict) or not result.get("ok"):
            self._last_run_ts = now_ts
            reason = (
                result.get("reason") if isinstance(result, dict) else None
            ) or "unknown"
            self._emit_activity(
                action="stale_claim_research_failed",
                summary=f"Stale-claim research failed: {reason}",
                importance="low",
                details={
                    "article_path": candidate.article_path,
                    "marker_label": candidate.marker_label,
                    "reason": reason,
                },
            )
            return {
                "status": "research_failed",
                "reason": reason,
                "article_path": candidate.article_path,
            }

        # 6. Mark cooldown — successful research, don't pick again
        #    within cooldown_days.
        cooldowns[cooldown_key(candidate.article_path, candidate.marker_label)] = now_ts
        if state_path:
            save_cooldowns(state_path, cooldowns)

        # 7. Emit Rule 21 proposal via the existing store.
        recommendation = _build_recommendation(
            candidate=candidate,
            result_path=result.get("result_path", ""),
        )
        try:
            proposal = self._proposal_store.create(  # type: ignore[union-attr]
                topic=topic,
                target_kb=target_kb,
                recommendation=recommendation,
                source_synthesis_path=result.get("result_path", ""),
                correlation_id="",
                severity="medium",
                extra={
                    "kind": "stale_claim_re_research",
                    "article_path": candidate.article_path,
                    "line_number": candidate.line_number,
                    "marker_label": candidate.marker_label,
                    "marker_source": candidate.marker_source,
                    "age_months": candidate.age_months,
                },
            )
        except Exception:
            log.debug("stale_claim: proposal create failed", exc_info=True)
            self._last_run_ts = now_ts
            self._emit_activity(
                action="stale_claim_research_proposal_failed",
                summary=f"Stale-claim re-research dossier written but proposal failed: {candidate.article_path}",
                importance="medium",
                details={
                    "article_path": candidate.article_path,
                    "marker_label": candidate.marker_label,
                    "result_path": result.get("result_path", ""),
                },
            )
            return {
                "status": "proposal_failed",
                "article_path": candidate.article_path,
                "result_path": result.get("result_path", ""),
            }

        self._last_run_ts = now_ts
        proposal_id = getattr(proposal, "proposal_id", "")
        self._emit_activity(
            action="stale_claim_re_researched",
            summary=f"Re-researched stale claim in {candidate.article_path}",
            importance="medium",
            details={
                "article_path": candidate.article_path,
                "marker_label": candidate.marker_label,
                "age_months": candidate.age_months,
                "result_path": result.get("result_path", ""),
                "proposal_id": proposal_id,
                "cost_usd": result.get("cost_usd", 0.0),
                "topic": topic,
            },
        )
        return {
            "status": "ok",
            "article_path": candidate.article_path,
            "marker_label": candidate.marker_label,
            "result_path": result.get("result_path", ""),
            "proposal_id": proposal_id,
            "cost_usd": result.get("cost_usd", 0.0),
            "topic": topic,
        }

    # ── Helpers ──────────────────────────────────────────────────────

    def _emit_activity(
        self,
        *,
        action: str,
        summary: str,
        importance: str,
        details: dict[str, Any],
    ) -> None:
        """Fire an activity event — total, never raises."""
        logger = self._activity_logger
        if logger is None:
            return
        try:
            logger.log(  # type: ignore[union-attr]
                category="knowledge",
                action=action,
                summary=summary,
                details=details,
                importance=importance,
            )
        except Exception:
            log.debug("stale_claim: activity log failed", exc_info=True)


def _article_title_from_path(article_path: str) -> str:
    """Derive a human-readable title from a wiki article's filename.

    Logical paths look like ``knowledge/main/wiki/concepts/foo-bar.md``.
    We strip extension + dirs + replace ``-`` with `` `` + Title Case.
    A pure helper — no I/O.
    """
    if not article_path:
        return ""
    normalised = article_path.replace("\\", "/")
    stem = normalised.rsplit("/", 1)[-1]
    if stem.endswith(".md"):
        stem = stem[: -len(".md")]
    return stem.replace("-", " ").replace("_", " ").strip()


def _build_recommendation(
    *,
    candidate: StaleClaim,
    result_path: str,
) -> str:
    """Build the proposal's recommendation text.

    Single short sentence + the result path so the user can click
    through.  Long enough to convey context, short enough to fit in
    the proposals inbox card without overflow.
    """
    snippet = candidate.line_text.strip()
    if len(snippet) > 160:
        snippet = snippet[:157].rstrip() + "…"
    age_label = f"{candidate.age_months}mo old"
    path_hint = f" Dossier: {result_path}" if result_path else ""
    return (
        f"Stale claim re-researched ({age_label}, marker {candidate.marker_label}). "
        f"Review fresh dossier and update or remove the `(as of YYYY-MM)` marker. "
        f"Line: {snippet}.{path_hint}"
    )
