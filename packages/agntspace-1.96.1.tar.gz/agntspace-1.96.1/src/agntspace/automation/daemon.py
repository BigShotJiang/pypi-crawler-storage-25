"""Daemon installer — register AgntSpace to autostart for the current user.

**Per-user mechanism on every platform.** A LocalSystem-bound mechanism
(Windows Service via NSSM, system-level systemd unit) silently breaks the
agent: ``Path.home()`` resolves to the SYSTEM profile, so the running
process can't find the user's ``~/.agntspace/config.toml``, encrypted
credentials, vault, or anything else. The user sees "the app didn't
autostart" because even though the process IS up, it's pointing at a
phantom empty profile.

Per-user mechanisms (Task Scheduler logon task, ``systemd --user``,
launchd ``LaunchAgents``) all run as the logged-in user with the right
``Path.home()`` and the right env. They start when the user signs in,
which is what "autostart" means for a personal app on a desktop.

Backwards compatibility: at install time we detect and remove any legacy
NSSM service / system-level systemd unit so existing installs migrate
cleanly to the per-user shape on the next ``Enable autostart`` click.

| Platform | Mechanism | Location |
|----------|-----------|----------|
| Windows | Task Scheduler (logon task) | ``\\agntspace`` task |
| Linux | ``systemd --user`` | ``~/.config/systemd/user/agntspace.service`` |
| macOS | launchd ``LaunchAgents`` | ``~/Library/LaunchAgents/com.archerfutura.agntspace.plist`` |
"""

from __future__ import annotations

import getpass
import logging
import os
import platform
import shutil
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

log = logging.getLogger(__name__)

SERVICE_NAME = "agntspace"
SERVICE_DISPLAY = "AgntSpace Agent"
SERVICE_DESC = "Personal AI agent that runs your life alongside you."

LAUNCHD_LABEL = f"com.archerfutura.{SERVICE_NAME}"

# ── Process-split (Phase 2) constants ───────────────────────────────────────
#
# Three sibling daemons replace the singleton when ``mode='split'``. Each
# kind's port defaults to ``base_port + offset`` so a single ``--port``
# argument fans out cleanly. Web stays on the user-facing port so existing
# UI bookmarks keep working; worker + scheduler take +1 / +2.
#
# Service names are kind-suffixed (e.g. ``agntspace-worker``) so the OS
# scheduler's installed-service list shows what's running at a glance, and
# all three can coexist on one machine without name collision.

SPLIT_KINDS: tuple[str, ...] = ("web", "worker", "scheduler")
"""Canonical ordering. Used by every per-kind iteration."""

SPLIT_PORT_OFFSETS: dict[str, int] = {"web": 0, "worker": 1, "scheduler": 2}
"""Default port offsets from the user-supplied base port. ``--port 8000``
yields web=8000, worker=8001, scheduler=8002 — matches the CLI command
defaults documented in :func:`agntspace.cli.web/worker/scheduler`."""


def _service_name(kind: str | None) -> str:
    """Service name for ``kind``. ``None`` → singleton (``agntspace``).

    Split kinds are ``agntspace-web`` / ``agntspace-worker`` /
    ``agntspace-scheduler`` so the three coexist on one machine and the
    OS scheduler's listing is self-documenting.
    """
    if kind is None:
        return SERVICE_NAME
    return f"{SERVICE_NAME}-{kind}"


def _launchd_label(kind: str | None) -> str:
    """launchd label for ``kind``. ``None`` → singleton."""
    if kind is None:
        return LAUNCHD_LABEL
    return f"com.archerfutura.{SERVICE_NAME}-{kind}"


def _command_args(kind: str | None, host: str, port: int) -> str:
    """Render the ``python -m agntspace.cli ...`` argument string.

    Singleton (``kind=None``) → ``-m agntspace.cli start --host H --port P``.
    Split (``kind='web'/'worker'/'scheduler'``) → ``-m agntspace.cli {kind}
    --host H --port P --no-supervise``.

    ``--no-supervise`` is load-bearing in split mode: the OS scheduler
    (Task Scheduler / systemd / launchd) IS the supervisor. Letting
    Python's internal supervisor also run would create a doubled-process
    tree (OS spawns a supervisor that spawns a child; both visible in
    process listings, both racing to bind the port).
    """
    if kind is None:
        return f"-m agntspace.cli start --host {host} --port {port}"
    return f"-m agntspace.cli {kind} --host {host} --port {port} --no-supervise"


# ── Public dispatchers ──────────────────────────────────────────────────────


def install_daemon(
    host: str = "127.0.0.1",
    port: int = 8000,
    *,
    mode: str = "singleton",
    start_after_install: bool = True,
) -> str:
    """Install AgntSpace as a per-user autostart entry. Returns status message.

    ``mode`` (Phase 2 process split):
      - ``"singleton"`` (default, byte-identical to pre-Phase-2 behavior) —
        registers ONE daemon entry running ``agntspace start``.
      - ``"split"`` — registers THREE per-user daemons: ``agntspace-web``
        on ``port``, ``agntspace-worker`` on ``port+1``, ``agntspace-scheduler``
        on ``port+2``. Each runs the matching ``agntspace web/worker/scheduler``
        subcommand with ``--no-supervise`` (the OS scheduler is the supervisor).

    When ``start_after_install`` is False the installer registers (and enables)
    the entry but does NOT start it. The HTTP route that triggers an install
    from the running server passes False to avoid a self-kill race: starting
    the new instance would spawn a sibling on the same host:port whose
    ``_try_reclaim_port`` boot helper kills the live process mid-response,
    making the success look like a failure to the browser.

    Unknown ``mode`` falls back to ``singleton`` with a warning log so a
    typo never crashes the install path.
    """
    if mode == "split":
        return _install_split(
            host, port, start_after_install=start_after_install,
        )
    if mode != "singleton":
        log.warning(
            "Unknown install mode %r — falling back to singleton. "
            "Valid modes: singleton, split.",
            mode,
        )
    return _install_singleton(
        host, port, start_after_install=start_after_install,
    )


def _install_singleton(
    host: str, port: int, *, start_after_install: bool = True,
) -> str:
    """Per-platform dispatcher for the singleton install."""
    system = platform.system()
    if system == "Windows":
        return _install_windows(host, port, start_after_install=start_after_install)
    if system == "Linux":
        return _install_linux(host, port, start_after_install=start_after_install)
    if system == "Darwin":
        return _install_macos(host, port, start_after_install=start_after_install)
    return f"Unsupported platform: {system}"


def _install_split(
    host: str, port: int, *, start_after_install: bool = True,
) -> str:
    """Install three per-user daemons (web/worker/scheduler).

    Per-kind ports default to ``base + offset`` so a single ``--port 8000``
    yields web=8000, worker=8001, scheduler=8002. Each kind's installer runs
    independently — a failure on one is reported in the aggregate output but
    does NOT abort the others (the user can rerun to retry the failed kind,
    and partial-install state is recoverable via ``uninstall_daemon`` then
    re-install).
    """
    system = platform.system()
    if system not in ("Windows", "Linux", "Darwin"):
        return f"Unsupported platform: {system}"

    sections: list[str] = []
    sections.append(
        f"Installing AgntSpace in SPLIT mode (3 per-user daemons).\n"
        f"  Base port: {port}  (web={port}, worker={port + 1}, scheduler={port + 2})\n"
    )

    for kind in SPLIT_KINDS:
        kind_port = port + SPLIT_PORT_OFFSETS[kind]
        if system == "Windows":
            msg = _install_windows(
                host, kind_port,
                start_after_install=start_after_install,
                kind=kind,
            )
        elif system == "Linux":
            msg = _install_linux(
                host, kind_port,
                start_after_install=start_after_install,
                kind=kind,
            )
        else:
            msg = _install_macos(
                host, kind_port,
                start_after_install=start_after_install,
                kind=kind,
            )
        sections.append(f"── [{kind}] ──\n{msg}")

    sections.append(
        "\nSplit-mode install complete.\n"
        "  Set 'process_mode = \"web\"' in ~/.agntspace/config.toml [system] block\n"
        "  so the web daemon doesn't try to drain the work queue itself.\n"
        "  (Worker + scheduler infer their mode from the agntspace subcommand.)"
    )
    return "\n\n".join(sections)


def uninstall_daemon() -> str:
    """Remove AgntSpace autostart entries. Returns aggregate status message.

    Removes EVERY known entry: singleton + all three split kinds + legacy
    LocalSystem-scoped installs (NSSM service on Windows, ``/etc/systemd/system/``
    unit on Linux). Idempotent — missing entries report cleanly. The caller
    doesn't need to know which mode is currently installed.
    """
    system = platform.system()
    if system not in ("Windows", "Linux", "Darwin"):
        return f"Unsupported platform: {system}"

    sections: list[str] = []

    # Singleton + legacy LocalSystem cleanup.
    if system == "Windows":
        sections.append(_uninstall_windows())
    elif system == "Linux":
        sections.append(_uninstall_linux())
    else:
        sections.append(_uninstall_macos())

    # Split kinds.
    for kind in SPLIT_KINDS:
        if system == "Windows":
            kind_msg = _uninstall_windows(kind=kind)
        elif system == "Linux":
            kind_msg = _uninstall_linux(kind=kind)
        else:
            kind_msg = _uninstall_macos(kind=kind)
        # Skip the noisy "no autostart entry found" lines for kinds that
        # aren't installed — they'd dominate the output for the common
        # case (singleton-only install).
        if "No autostart entry found" not in kind_msg and "No agent" not in kind_msg:
            sections.append(f"── [{kind}] ──\n{kind_msg}")

    return "\n\n".join(s for s in sections if s)


def daemon_status() -> dict:
    """Check whether the autostart entry is installed and running.

    Returns ``{platform, method, installed, running, scope, legacy, mode,
    entries}`` where:
      - ``installed`` / ``running`` / ``scope`` / ``legacy`` summarize the
        UNION across singleton + split kinds (preserved for back-compat
        with pre-Phase-2 callers).
      - ``mode`` ∈ ``{"singleton", "split", "mixed", "none"}`` reflects what
        the OS scheduler currently has registered:
        * ``"singleton"`` — only ``agntspace`` registered.
        * ``"split"`` — all three split kinds registered (regardless of singleton).
        * ``"mixed"`` — partial split (1 or 2 kinds) OR singleton+split together.
        * ``"none"`` — nothing registered.
      - ``entries`` is a list of per-kind dicts ``{kind, name, installed,
        running, scope, legacy}`` covering singleton + every split kind.
        Callers that want just the aggregate can ignore it.
    """
    system = platform.system()
    base = {
        "platform": system,
        "installed": False,
        "running": False,
        "method": "",
        "scope": "",
        "legacy": False,
        "mode": "none",
        "entries": [],
    }

    if system == "Windows":
        base["method"] = "Task Scheduler (logon task)"
    elif system == "Linux":
        base["method"] = "systemd --user"
    elif system == "Darwin":
        base["method"] = "launchd"
    else:
        return base

    # Per-kind status (singleton + 3 split). Single-kind status reuses the
    # existing platform-specific helpers; we fold the results.
    entries: list[dict] = []
    for kind in (None,) + SPLIT_KINDS:
        kind_result = {
            "platform": system,
            "installed": False,
            "running": False,
            "method": base["method"],
            "scope": "",
            "legacy": False,
        }
        if system == "Windows":
            kind_result = _status_windows(kind_result, kind=kind)
        elif system == "Linux":
            kind_result = _status_linux(kind_result, kind=kind)
        elif system == "Darwin":
            kind_result = _status_macos(kind_result, kind=kind)

        entries.append({
            "kind": kind or "singleton",
            "name": _service_name(kind),
            "installed": kind_result["installed"],
            "running": kind_result["running"],
            "scope": kind_result["scope"],
            "legacy": kind_result["legacy"],
            "method": kind_result["method"],
        })

        # Singleton's method override (e.g. legacy NSSM detection) propagates
        # to the aggregate top-level method field — the legacy banner is what
        # the UI reads when it has to prompt the user to reinstall.
        if kind is None and kind_result["method"] != base["method"]:
            base["method"] = kind_result["method"]

    base["entries"] = entries

    # Compute aggregate top-level fields.
    singleton_installed = entries[0]["installed"]
    split_installed_count = sum(1 for e in entries[1:] if e["installed"])
    any_installed = singleton_installed or split_installed_count > 0

    base["installed"] = any_installed
    # 'running' is True when at least one entry reports running — a per-kind
    # view via 'entries' tells the precise story.
    base["running"] = any(e["running"] for e in entries)
    # 'scope' + 'legacy' reflect the singleton entry first (most common
    # back-compat case), falling back to the first installed split kind.
    primary = entries[0] if singleton_installed else next(
        (e for e in entries[1:] if e["installed"]), entries[0]
    )
    base["scope"] = primary["scope"]
    base["legacy"] = primary["legacy"]

    if not any_installed:
        base["mode"] = "none"
    elif singleton_installed and split_installed_count == 0:
        base["mode"] = "singleton"
    elif not singleton_installed and split_installed_count == len(SPLIT_KINDS):
        base["mode"] = "split"
    else:
        # Partial split, OR singleton coexisting with split kinds — both
        # are "mixed" deployments the user should clean up.
        base["mode"] = "mixed"

    return base


# ── Windows (Task Scheduler logon task) ─────────────────────────────────────


def _current_windows_user_id() -> str:
    """Return ``DOMAIN\\user`` for the current logged-in user.

    Falls back to ``HOSTNAME\\<getpass.getuser()>`` if the standard env vars
    aren't set (rare on Windows but defends against weird runners).
    """
    user = os.environ.get("USERNAME") or getpass.getuser()
    domain = os.environ.get("USERDOMAIN") or socket.gethostname()
    return f"{domain}\\{user}"


def _build_logon_task_xml(
    host: str,
    port: int,
    *,
    python: str,
    user_id: str,
    kind: str | None = None,
) -> str:
    """Render a Task Scheduler 1.2 XML for a per-user logon task.

    ``kind`` parameter (Phase 2 split): ``None`` → singleton (``agntspace
    start``); ``'web'``/``'worker'``/``'scheduler'`` → corresponding split
    subcommand with ``--no-supervise`` (the OS scheduler IS the supervisor).
    Service name auto-suffixed: ``agntspace-web`` etc.

    Settings chosen for a long-running personal-app process:
      - ``LogonTrigger`` with explicit ``UserId`` so the task only fires for
        THIS user (matters on shared machines).
      - ``InteractiveToken`` principal — runs in the user's interactive
        session with the correct ``HKEY_CURRENT_USER``, no stored password.
      - ``MultipleInstancesPolicy=IgnoreNew`` — re-login doesn't spawn a
        second instance.
      - ``ExecutionTimeLimit=PT0S`` — never auto-terminate; this is a
        long-running daemon, not a maintenance task.
      - ``RestartOnFailure`` — auto-restart up to 3 times at 1-min intervals
        if the process crashes (matches the NSSM/systemd behaviour).
      - ``DisallowStartIfOnBatteries=false`` + ``StopIfGoingOnBatteries=false``
        — laptops shouldn't lose the agent on unplug.
    """
    args = _command_args(kind, host, port)
    name = _service_name(kind)
    working_dir = str(Path.home())
    return f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>{SERVICE_DESC}</Description>
    <Author>AgntSpace</Author>
    <URI>\\{name}</URI>
  </RegistrationInfo>
  <Triggers>
    <LogonTrigger>
      <Enabled>true</Enabled>
      <UserId>{user_id}</UserId>
    </LogonTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>{user_id}</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings>
      <StopOnIdleEnd>false</StopOnIdleEnd>
      <RestartOnIdle>false</RestartOnIdle>
    </IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <Priority>7</Priority>
    <RestartOnFailure>
      <Interval>PT1M</Interval>
      <Count>3</Count>
    </RestartOnFailure>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>{python}</Command>
      <Arguments>{args}</Arguments>
      <WorkingDirectory>{working_dir}</WorkingDirectory>
    </Exec>
  </Actions>
</Task>
"""


_LEGACY_NSSM_NEEDS_ADMIN_HINT = (
    f"Found a legacy NSSM service '{SERVICE_NAME}' that needs an elevated\n"
    f"  terminal to remove. Open PowerShell as Administrator and run:\n"
    f"      sc.exe delete {SERVICE_NAME}\n"
    f"  (Harmless to leave — Paused services don't run, but it'll show in\n"
    f"  services.msc next to your new logon task.)"
)


def _remove_legacy_nssm_service() -> str | None:
    """Best-effort cleanup of the pre-2026 NSSM service.

    Verifies removal by RE-RUNNING ``nssm status`` after the remove call,
    rather than trusting ``nssm remove``'s exit code. Why: ``nssm remove``
    returns rc=0 even when it prints "Administrator access is needed" to
    stderr — observed live on a non-elevated session. Trust observed
    state, not the return code.

    Possible return values:
      - ``None``: no legacy service found (NSSM not on PATH, or no
        ``agntspace`` service registered).
      - ``"Removed legacy NSSM service ..."``: cleanly removed.
      - ``_LEGACY_NSSM_NEEDS_ADMIN_HINT``: the service is still
        registered after our removal attempt; surface the elevated-shell
        command for the user.

    Never raises — legacy state is opportunistic.
    """
    nssm = shutil.which("nssm")
    if not nssm:
        return None
    if not _nssm_service_exists(nssm):
        return None

    # Best-effort stop + remove. Don't trust the return codes.
    try:
        subprocess.run([nssm, "stop", SERVICE_NAME], capture_output=True, timeout=10)
        subprocess.run(
            [nssm, "remove", SERVICE_NAME, "confirm"],
            capture_output=True, text=True, timeout=10,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        # Tool went missing mid-call or hung. Verification below decides.
        pass

    # Verify by re-checking status. If the service is still registered,
    # the remove failed silently (typically access denied).
    if _nssm_service_exists(nssm):
        return _LEGACY_NSSM_NEEDS_ADMIN_HINT
    return "Removed legacy NSSM service (LocalSystem-bound; replaced by user logon task)."


def _nssm_service_exists(nssm: str) -> bool:
    """Return True when ``nssm status agntspace`` reports the service is
    registered. False on missing service, missing nssm, timeout, or any
    error — i.e. fail-closed for "service not found"."""
    try:
        out = subprocess.run(
            [nssm, "status", SERVICE_NAME],
            capture_output=True, text=True, timeout=5,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
    return out.returncode == 0


def _install_windows(
    host: str,
    port: int,
    *,
    start_after_install: bool = True,
    kind: str | None = None,
) -> str:
    """Install one Task Scheduler logon task. Singleton when ``kind`` is None;
    one of the three split kinds otherwise. Legacy NSSM cleanup runs only for
    the singleton (callers in split mode call it once before the per-kind loop).
    """
    if not shutil.which("schtasks"):
        return (
            "schtasks not found on PATH. AgntSpace registers a Windows\n"
            "Task Scheduler logon task; schtasks.exe ships with every modern\n"
            "Windows install. If it's truly missing, your Windows install is\n"
            "non-standard — please report this."
        )

    python = sys.executable
    user_id = _current_windows_user_id()
    legacy_note = _remove_legacy_nssm_service() if kind is None else None
    name = _service_name(kind)

    xml = _build_logon_task_xml(
        host, port, python=python, user_id=user_id, kind=kind,
    )

    # Task Scheduler requires UTF-16 XML. Write to a tempfile so spaces in
    # the path don't break command-line parsing. ``delete=False`` because
    # schtasks reads the file AFTER the context manager exits — we own the
    # cleanup in the finally block.
    with tempfile.NamedTemporaryFile(
        mode="wb", suffix=".xml", prefix="agntspace-task-", delete=False,
    ) as tmp:
        tmp.write(xml.encode("utf-16"))
        tmp_path = tmp.name
    try:
        result = subprocess.run(
            ["schtasks", "/Create", "/TN", name, "/XML", tmp_path, "/F"],
            capture_output=True, text=True, timeout=15,
        )
    finally:
        try:
            Path(tmp_path).unlink()
        except OSError:
            pass

    if result.returncode != 0:
        err = (result.stderr or result.stdout or "").strip()
        return f"Failed to register task: {err or 'schtasks returned non-zero'}"

    prefix = f"{legacy_note}\n" if legacy_note else ""

    if start_after_install:
        subprocess.run(
            ["schtasks", "/Run", "/TN", name],
            capture_output=True, timeout=10,
        )
        return (
            f"{prefix}AgntSpace registered as scheduled task '{name}'.\n"
            f"  Runs as: {user_id} (per-user, no stored password).\n"
            f"  Auto-starts at every logon, auto-restarts on crash.\n"
            f"  Manage: schtasks /Run|/End|/Query /TN {name}\n"
            f"  Logs: ~/.agntspace/logs/"
        )

    return (
        f"{prefix}AgntSpace registered as scheduled task '{name}'.\n"
        f"  Runs as: {user_id} (per-user, no stored password).\n"
        f"  Auto-starts at next logon.\n"
        f"  To hand off now, restart this server (the task will take over port {port}).\n"
        f"  Or start manually: schtasks /Run /TN {name}\n"
        f"  Logs: ~/.agntspace/logs/"
    )


def _uninstall_windows(kind: str | None = None) -> str:
    notes: list[str] = []
    name = _service_name(kind)

    # New per-user task.
    if shutil.which("schtasks"):
        result = subprocess.run(
            ["schtasks", "/Delete", "/TN", name, "/F"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            notes.append(f"Scheduled task '{name}' removed.")

    # Legacy NSSM service is only the singleton's concern.
    if kind is None:
        legacy = _remove_legacy_nssm_service()
        if legacy:
            notes.append(legacy)

    if notes:
        return "\n".join(notes)
    return f"No autostart entry found for '{name}'."


def _status_windows(result: dict, kind: str | None = None) -> dict:
    name = _service_name(kind)
    if shutil.which("schtasks"):
        try:
            out = subprocess.run(
                ["schtasks", "/Query", "/TN", name, "/FO", "CSV", "/NH"],
                capture_output=True, text=True, timeout=5,
            )
            if out.returncode == 0 and out.stdout.strip():
                result["installed"] = True
                result["scope"] = "user"
                # CSV: "TaskName","NextRunTime","Status"
                line = out.stdout.strip().splitlines()[0]
                # Defensive parse — schtasks sometimes wraps fields oddly.
                fields = [f.strip().strip('"') for f in line.split('","')]
                if len(fields) >= 3:
                    status = fields[2].rstrip('"').strip()
                    result["running"] = status.lower() == "running"
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    # Surface any legacy NSSM service so the UI can prompt for re-install.
    # Only relevant for the singleton — split kinds never had an NSSM path.
    if kind is None and not result["installed"]:
        nssm = shutil.which("nssm")
        if nssm:
            try:
                out = subprocess.run(
                    [nssm, "status", SERVICE_NAME],
                    capture_output=True, text=True, timeout=5,
                )
                if out.returncode == 0:
                    result["installed"] = True
                    result["running"] = "SERVICE_RUNNING" in out.stdout
                    result["scope"] = "system"
                    result["legacy"] = True
                    result["method"] = "nssm Service (LEGACY — runs as LocalSystem; please reinstall)"
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

    return result


# ── Linux (systemd --user) ──────────────────────────────────────────────────


def _user_systemd_unit_path(kind: str | None = None) -> Path:
    """Per-user systemd unit at ``~/.config/systemd/user/agntspace[-kind].service``.

    Per the XDG Base Directory spec; ``systemctl --user`` reads from here
    without sudo. ``kind=None`` → singleton; split kinds get suffixed names.
    """
    return Path.home() / ".config/systemd/user" / f"{_service_name(kind)}.service"


def _legacy_system_systemd_unit_path() -> Path:
    return Path(f"/etc/systemd/system/{SERVICE_NAME}.service")


def _build_user_systemd_unit(
    host: str,
    port: int,
    *,
    python: str,
    kind: str | None = None,
) -> str:
    """Render a systemd --user unit. ``kind=None`` → singleton.

    Description suffixed with the kind so ``systemctl --user list-units`` is
    self-documenting in split mode (`AgntSpace Agent (worker)` etc).
    """
    args = _command_args(kind, host, port)
    description_suffix = f" ({kind})" if kind else ""
    return f"""[Unit]
Description={SERVICE_DISPLAY}{description_suffix}
After=default.target

[Service]
Type=simple
ExecStart={python} {args}
Restart=always
RestartSec=5
WorkingDirectory={Path.home()}
Environment=PATH={Path(python).parent}:/usr/bin:/bin

[Install]
WantedBy=default.target
"""


def _detect_legacy_system_systemd_unit() -> str | None:
    """Return a hint to the user if a legacy ``/etc/systemd/system/`` unit
    exists. We can't safely remove it without sudo; the user must do so.
    """
    legacy = _legacy_system_systemd_unit_path()
    if not legacy.exists():
        return None
    return (
        f"Legacy system-level unit found at {legacy}.\n"
        f"  This runs as root and breaks Path.home(). Remove it with:\n"
        f"  sudo systemctl stop {SERVICE_NAME} && sudo systemctl disable {SERVICE_NAME} && sudo rm {legacy}"
    )


def _install_linux(
    host: str,
    port: int,
    *,
    start_after_install: bool = True,
    kind: str | None = None,
) -> str:
    """Install one systemd --user unit. Singleton when ``kind`` is None;
    one of the three split kinds otherwise. Legacy /etc/systemd/system hint
    runs only for the singleton path (callers in split mode call it once
    before the per-kind loop).
    """
    if not shutil.which("systemctl"):
        return (
            "systemctl not found. AgntSpace installs as a per-user systemd\n"
            "service. Your distro doesn't ship systemd; use a startup script\n"
            "in your shell profile or ~/.config/autostart/ instead."
        )

    python = sys.executable
    name = _service_name(kind)
    unit_path = _user_systemd_unit_path(kind)
    unit_path.parent.mkdir(parents=True, exist_ok=True)
    unit_path.write_text(_build_user_systemd_unit(host, port, python=python, kind=kind))

    legacy_note = _detect_legacy_system_systemd_unit() if kind is None else None

    try:
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            check=True, capture_output=True, text=True, timeout=10,
        )
        subprocess.run(
            ["systemctl", "--user", "enable", name],
            check=True, capture_output=True, text=True, timeout=10,
        )
    except subprocess.CalledProcessError as exc:
        err = (exc.stderr or "").strip()
        return f"systemctl --user failed: {err or exc}"
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        return f"systemctl --user not available: {exc}"

    # Best-effort: enable lingering so the service starts at boot, not just
    # at user login. Failure is OK — the service will still start at login.
    user = os.environ.get("USER") or getpass.getuser()
    linger_ok = False
    try:
        linger = subprocess.run(
            ["loginctl", "enable-linger", user],
            capture_output=True, text=True, timeout=10,
        )
        linger_ok = linger.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        linger_ok = False

    linger_note = (
        " (linger enabled — starts at boot)"
        if linger_ok
        else (
            f" (linger NOT enabled — starts at next login;\n"
            f"  run 'sudo loginctl enable-linger {user}' to start at boot)"
        )
    )
    legacy_prefix = f"{legacy_note}\n\n" if legacy_note else ""

    if start_after_install:
        subprocess.run(
            ["systemctl", "--user", "start", name],
            capture_output=True, timeout=10,
        )
        return (
            f"{legacy_prefix}AgntSpace installed as user systemd service '{name}'.\n"
            f"  Runs as: {user} (per-user, no sudo){linger_note}.\n"
            f"  Auto-starts on login, auto-restarts on crash.\n"
            f"  Manage: systemctl --user start|stop|restart|status {name}\n"
            f"  Logs: journalctl --user -u {name} -f"
        )

    return (
        f"{legacy_prefix}AgntSpace registered as user systemd service '{name}'.\n"
        f"  Runs as: {user} (per-user, no sudo){linger_note}.\n"
        f"  Auto-starts on next login.\n"
        f"  To hand off now, restart this server (the user service will take over port {port}).\n"
        f"  Or start manually: systemctl --user start {name}\n"
        f"  Logs: journalctl --user -u {name} -f"
    )


def _uninstall_linux(kind: str | None = None) -> str:
    notes: list[str] = []
    name = _service_name(kind)
    unit_path = _user_systemd_unit_path(kind)

    if unit_path.exists() and shutil.which("systemctl"):
        subprocess.run(
            ["systemctl", "--user", "stop", name],
            capture_output=True, timeout=10,
        )
        subprocess.run(
            ["systemctl", "--user", "disable", name],
            capture_output=True, timeout=10,
        )
        try:
            unit_path.unlink()
        except OSError:
            pass
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            capture_output=True, timeout=10,
        )
        notes.append(f"User service '{name}' removed.")

    # Legacy system-level unit is only the singleton's concern.
    if kind is None:
        legacy = _detect_legacy_system_systemd_unit()
        if legacy:
            notes.append(legacy)

    if notes:
        return "\n".join(notes)
    return f"No autostart entry found for '{name}'."


def _status_linux(result: dict, kind: str | None = None) -> dict:
    name = _service_name(kind)
    unit_path = _user_systemd_unit_path(kind)
    if unit_path.exists():
        result["installed"] = True
        result["scope"] = "user"
        if shutil.which("systemctl"):
            try:
                out = subprocess.run(
                    ["systemctl", "--user", "is-active", name],
                    capture_output=True, text=True, timeout=5,
                )
                result["running"] = out.stdout.strip() == "active"
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

    # Surface legacy install separately. Only relevant for the singleton —
    # split kinds never had a /etc/systemd/system path.
    if kind is None and not result["installed"] and _legacy_system_systemd_unit_path().exists():
        result["installed"] = True
        result["scope"] = "system"
        result["legacy"] = True
        result["method"] = "systemd /etc/systemd/system (LEGACY — please reinstall)"
        if shutil.which("systemctl"):
            try:
                out = subprocess.run(
                    ["systemctl", "is-active", SERVICE_NAME],
                    capture_output=True, text=True, timeout=5,
                )
                result["running"] = out.stdout.strip() == "active"
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

    return result


# ── macOS (launchd LaunchAgents — already per-user) ─────────────────────────


def _macos_plist_path(kind: str | None = None) -> Path:
    return Path.home() / "Library" / "LaunchAgents" / f"{_launchd_label(kind)}.plist"


def _build_macos_plist(
    host: str,
    port: int,
    *,
    python: str,
    kind: str | None = None,
) -> str:
    """Render a launchd plist. ``kind=None`` → singleton.

    Per-kind log files keep web/worker/scheduler streams separated when
    debugging the split deployment.
    """
    log_dir = Path.home() / ".agntspace" / "logs"
    label = _launchd_label(kind)
    log_stem = label.split(".")[-1]  # e.g. 'agntspace-worker' or 'agntspace'
    if kind is None:
        program_args = [
            "-m", "agntspace.cli", "start",
            "--host", str(host), "--port", str(port),
        ]
    else:
        program_args = [
            "-m", "agntspace.cli", kind,
            "--host", str(host), "--port", str(port),
            "--no-supervise",
        ]
    args_xml = "\n        ".join(f"<string>{arg}</string>" for arg in program_args)
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{label}</string>
    <key>ProgramArguments</key>
    <array>
        <string>{python}</string>
        {args_xml}
    </array>
    <key>WorkingDirectory</key>
    <string>{Path.home()}</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{log_dir}/{log_stem}.log</string>
    <key>StandardErrorPath</key>
    <string>{log_dir}/{log_stem}-error.log</string>
    <key>ThrottleInterval</key>
    <integer>5</integer>
</dict>
</plist>
"""


def _install_macos(
    host: str,
    port: int,
    *,
    start_after_install: bool = True,
    kind: str | None = None,
) -> str:
    """Install one launchd plist. Singleton when ``kind`` is None; one of the
    three split kinds otherwise.
    """
    python = sys.executable
    label = _launchd_label(kind)
    plist_path = _macos_plist_path(kind)
    plist_path.parent.mkdir(parents=True, exist_ok=True)
    plist_path.write_text(_build_macos_plist(host, port, python=python, kind=kind))

    if start_after_install:
        try:
            subprocess.run(
                ["launchctl", "load", str(plist_path)],
                check=True, capture_output=True, text=True, timeout=10,
            )
        except subprocess.CalledProcessError as exc:
            return f"launchctl load failed: {(exc.stderr or '').strip() or exc}"
        except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
            return f"launchctl not available: {exc}"
        return (
            f"AgntSpace installed as launchd agent '{label}'.\n"
            f"  Runs as: {os.environ.get('USER', getpass.getuser())} (per-user).\n"
            f"  Auto-starts on login, auto-restarts on crash.\n"
            f"  Manage: launchctl start|stop {label}\n"
            f"  Logs: ~/.agntspace/logs/"
        )

    return (
        f"AgntSpace registered as launchd agent '{label}'.\n"
        f"  Runs as: {os.environ.get('USER', getpass.getuser())} (per-user).\n"
        f"  Auto-starts on next login.\n"
        f"  To hand off now, restart this server (the agent will take over port {port}).\n"
        f"  Or start manually: launchctl load {plist_path}\n"
        f"  Logs: ~/.agntspace/logs/"
    )


def _uninstall_macos(kind: str | None = None) -> str:
    label = _launchd_label(kind)
    plist_path = _macos_plist_path(kind)
    if not plist_path.exists():
        return f"No autostart entry found for '{label}'."

    try:
        subprocess.run(
            ["launchctl", "unload", str(plist_path)],
            capture_output=True, timeout=10,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    try:
        plist_path.unlink()
    except OSError:
        pass
    return f"Agent '{label}' removed."


def _status_macos(result: dict, kind: str | None = None) -> dict:
    label = _launchd_label(kind)
    plist_path = _macos_plist_path(kind)
    if plist_path.exists():
        result["installed"] = True
        result["scope"] = "user"
        if shutil.which("launchctl"):
            try:
                out = subprocess.run(
                    ["launchctl", "list", label],
                    capture_output=True, text=True, timeout=5,
                )
                result["running"] = out.returncode == 0
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass
    return result
