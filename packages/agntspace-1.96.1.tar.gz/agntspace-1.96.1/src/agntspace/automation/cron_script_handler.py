"""Script-only cron handler (P3.5, 2026-05-17 night).

Closes the Hermes-borrow polish item: cron jobs that run external scripts
WITHOUT involving the agent. Empty stdout silent; non-empty stdout
delivered verbatim via the existing ``deliver_to`` layer (observations /
channel / webhook).

**Use cases**:
- Nightly backups whose stdout is just the rsync summary
- Watchdog probes that emit a one-line status when something's wrong
- CSV exports from external tools that the user wants captured into the
  journal observations file
- Health checks for external services (ping, curl, custom binary)

**Architectural commitments**:

1. **`command` is a list, NEVER a single string.** ``["rsync", "-av",
   "/src", "/dst"]`` is safe; ``"rsync -av /src /dst"`` would be shell-
   interpreted and open injection vectors. We refuse string commands
   at handler entry.

2. **No shell.** ``subprocess.run(shell=False)`` always. The list-form
   command goes directly to ``execvp`` (POSIX) / ``CreateProcess``
   (Windows); the user's shell never sees it.

3. **CWD defaults to the vault directory.** Backup scripts that
   reference relative paths land in the right tree. Caller can override
   via ``cwd=...`` but the value is REJECTED if it tries to escape the
   vault root via ``..`` segments.

4. **Hard timeout via ``asyncio.wait_for``.** The cron tick loop is
   sequential; an unbounded script call would block every other due job.
   Per-handler timeout cap from the skill YAML; default 300s. Mirrors
   the cron-handler-timeout shape that's already enforced for Python
   handlers.

5. **Stdout truncation** at ``max_output_bytes`` (default 4096). A
   script that floods stdout doesn't get to flood the journal. The
   truncation marker `\\n…[truncated after N bytes]` is appended so the
   user knows there was more.

6. **Non-zero exit raises**, which the cron tick translates to
   ``status="error"``. The stderr is captured + included in the error
   message so the failure is debuggable from ``cron_history``.

7. **Empty stdout is silent**. When the script produces no output, the
   handler returns an empty string. The cron tick's existing delivery
   check (``result_text and deliver_to=="observations"``) already skips
   the observations write. No new code needed for the silent path.

8. **No contract recheck per execution.** The contract action
   ``run_script_cron`` (default: confirm) is gated at ``add_job`` time.
   Once a script job is registered, the cron tick runs it without
   re-prompting — same semantics as every other contract-gated action.

9. **Fail-soft on environment lookups.** Broken / missing env values
   default cleanly; the subprocess inherits the parent's env when
   ``env=None`` (the legacy default).
"""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
from pathlib import Path

log = logging.getLogger(__name__)


# Hard caps — engine substrate, never tunable below these. Even when YAML
# overrides max_output_bytes, the engine refuses to allocate more than
# this. Protects against a misconfigured YAML draining memory via a
# command that floods stdout.
_HARD_MAX_OUTPUT_BYTES: int = 1_048_576  # arch:deterministic — 1 MiB ceiling regardless of YAML
_HARD_MAX_TIMEOUT_SECONDS: int = 3600  # arch:deterministic — 1 hour ceiling regardless of YAML

# Default knobs (skill YAML can override down to these floors, but the
# hard caps above always apply). 4 KB is enough for a one-paragraph
# rsync summary or a backup-completed message; 5 min covers most
# legitimate watchdog probes.
_DEFAULT_MAX_OUTPUT_BYTES: int = 4096  # arch:deterministic — engine default; YAML can override up to _HARD_MAX_OUTPUT_BYTES
_DEFAULT_TIMEOUT_SECONDS: int = 300  # arch:deterministic — engine default; YAML can override up to _HARD_MAX_TIMEOUT_SECONDS


class ScriptCronError(Exception):
    """Raised by the script handler on non-zero exit / invalid input.

    The cron tick translates this to ``status="error"`` with the exception
    message recorded in cron_history. The message includes the stderr tail
    so the failure is debuggable without spelunking through process logs.
    """


def _truncate_stdout(text: str, max_bytes: int) -> str:
    """Truncate stdout at the byte boundary.

    Encodes the text to UTF-8 (the canonical interchange format the
    journal observations file uses), checks the byte length, and trims
    at the byte boundary if over the cap. The truncation marker is
    appended as a separate suffix so the byte count is honest — we
    don't try to fit the marker INSIDE the cap because that would
    require trial-and-error encoding.

    Returns the (possibly truncated) text.
    """
    encoded = text.encode("utf-8", errors="replace")
    if len(encoded) <= max_bytes:
        return text
    # Trim at the byte boundary, then decode. errors='replace' covers
    # the case where the byte cut lands mid-codepoint — the trailing
    # partial sequence becomes a replacement char rather than raising.
    trimmed = encoded[:max_bytes].decode("utf-8", errors="replace")
    return f"{trimmed}\n…[truncated after {max_bytes} bytes]"


def _validate_command(command: object) -> list[str]:
    """Reject non-list commands; coerce list contents to strings.

    Returns the validated command list. Raises ScriptCronError on:
    - Non-list input (rejects shell-string injection vectors)
    - Empty list (no executable to run)
    - Non-string / non-pathlike entries (refuses arbitrary objects)
    """
    if not isinstance(command, (list, tuple)):
        raise ScriptCronError(
            f"command must be a list, got {type(command).__name__}. "
            "Shell-style strings are rejected — use ['rsync', '-av', '/src'] "
            "not 'rsync -av /src'."
        )
    if not command:
        raise ScriptCronError("command list is empty")
    out: list[str] = []
    for entry in command:
        if isinstance(entry, str):
            out.append(entry)
        elif isinstance(entry, (Path, os.PathLike)):
            out.append(str(entry))
        else:
            raise ScriptCronError(
                f"command entries must be strings or paths, got {type(entry).__name__}: {entry!r}"
            )
    return out


def _resolve_cwd(cwd: str | None, vault_root: Path | None) -> Path | None:
    """Resolve the working directory under the vault root.

    When ``cwd`` is None, returns ``vault_root`` if available else None
    (subprocess will default to the parent process's cwd, which is the
    app dir — that's fine for scripts that don't reference relative
    paths).

    When ``cwd`` is set:
    - Absolute paths are honored verbatim (caller has the system
      perspective)
    - Relative paths are resolved against the vault root
    - Either way, the resolved path MUST exist (else ScriptCronError)
    - ``..`` traversal is permitted only as long as the resolved path
      still exists — we don't sandbox cwd inside the vault. Scripts
      that need to write OUTSIDE the vault (e.g. backups to an external
      drive) MUST be able to set their own cwd. The security perimeter
      is the contract action gating ``run_script_cron`` at add time,
      not a cwd jail at execution time.
    """
    if cwd is None:
        return vault_root
    cwd_path = Path(cwd)
    if not cwd_path.is_absolute() and vault_root is not None:
        cwd_path = vault_root / cwd_path
    cwd_path = cwd_path.resolve()
    if not cwd_path.exists():
        raise ScriptCronError(f"cwd does not exist: {cwd_path}")
    if not cwd_path.is_dir():
        raise ScriptCronError(f"cwd is not a directory: {cwd_path}")
    return cwd_path


def _build_env(extra: dict | None) -> dict[str, str] | None:
    """Merge caller-supplied env onto the parent env.

    ``extra=None`` returns None (subprocess inherits parent env as-is).
    Non-string values are coerced to strings (POSIX `execve` requires
    string env values; passing an int would fail at the OS layer with
    a confusing error).
    """
    if extra is None:
        return None
    if not isinstance(extra, dict):
        raise ScriptCronError(
            f"env must be a dict, got {type(extra).__name__}"
        )
    merged = dict(os.environ)
    for key, value in extra.items():
        if not isinstance(key, str):
            raise ScriptCronError(f"env key must be string, got {type(key).__name__}: {key!r}")
        merged[key] = str(value) if value is not None else ""
    return merged


async def script_handler(
    command: list[str] | tuple[str, ...] | None = None,
    *,
    cwd: str | None = None,
    env: dict | None = None,
    max_bytes: int | None = None,
    timeout_seconds: int | None = None,
    vault_root: str | Path | None = None,
) -> str:
    """Run an external script as a cron handler.

    Returns the script's stdout (possibly truncated). Empty stdout
    returns "" — the cron tick's existing delivery layer skips
    observations writes for empty results.

    Raises ``ScriptCronError`` on:
    - Invalid command (non-list, empty, non-string entries)
    - Invalid cwd (doesn't exist, not a directory)
    - Invalid env (non-dict, non-string key)
    - Non-zero exit code (stderr included in message)
    - Subprocess timeout (cap reached, process force-cancelled)
    - Missing executable (PATH lookup failed)

    Args mirror the schema documented in ``_meta/script-cron/config/script.yaml``.
    Knobs are bounded by the engine's hard caps (1 MiB output, 1h timeout)
    regardless of YAML overrides.
    """
    # ── Input validation ───────────────────────────────────────────────
    if command is None:
        raise ScriptCronError("command is required (got None)")
    validated_command = _validate_command(command)

    # Resolve max_output_bytes against the engine cap.
    effective_max_bytes = max_bytes if max_bytes is not None else _DEFAULT_MAX_OUTPUT_BYTES
    if not isinstance(effective_max_bytes, int) or effective_max_bytes <= 0:
        effective_max_bytes = _DEFAULT_MAX_OUTPUT_BYTES
    effective_max_bytes = min(effective_max_bytes, _HARD_MAX_OUTPUT_BYTES)

    # Resolve timeout against the engine cap.
    effective_timeout = timeout_seconds if timeout_seconds is not None else _DEFAULT_TIMEOUT_SECONDS
    if not isinstance(effective_timeout, (int, float)) or effective_timeout <= 0:
        effective_timeout = _DEFAULT_TIMEOUT_SECONDS
    effective_timeout = min(effective_timeout, _HARD_MAX_TIMEOUT_SECONDS)

    # Resolve cwd + env (each can raise ScriptCronError on bad input).
    vault_path: Path | None = None
    if vault_root is not None:
        try:
            vault_path = Path(vault_root).resolve()
        except Exception as exc:  # pragma: no cover — defensive
            raise ScriptCronError(f"invalid vault_root: {exc}") from exc
    resolved_cwd = _resolve_cwd(cwd, vault_path)
    resolved_env = _build_env(env)

    # ── Executable existence check ─────────────────────────────────────
    # Without this, a missing executable produces a cross-platform mess
    # (PermissionError on some shells, FileNotFoundError elsewhere). Do
    # the lookup ourselves and raise a uniform error.
    executable = validated_command[0]
    if not Path(executable).is_absolute() and shutil.which(executable) is None:
        raise ScriptCronError(
            f"executable not found on PATH: {executable!r}. "
            "Use an absolute path or ensure the binary is reachable."
        )

    # ── Subprocess execution ───────────────────────────────────────────
    # subprocess.run blocks; we wrap in asyncio.to_thread so the cron
    # tick stays responsive. The asyncio.wait_for enforces the timeout
    # at the await layer; the inner subprocess.run carries the same
    # timeout for belt-and-braces (Python's subprocess kills the
    # process group on timeout).
    log.info(
        "cron script handler: %s (cwd=%s, timeout=%ds, max_bytes=%d)",
        " ".join(validated_command), resolved_cwd, effective_timeout, effective_max_bytes,
    )

    def _run_subprocess() -> subprocess.CompletedProcess[str]:
        return subprocess.run(  # noqa: S603 — list-form, shell=False, validated above
            validated_command,
            capture_output=True,
            text=True,
            cwd=resolved_cwd,
            env=resolved_env,
            timeout=effective_timeout,
            check=False,  # we want to inspect returncode ourselves
            shell=False,
        )

    try:
        completed = await asyncio.wait_for(
            asyncio.to_thread(_run_subprocess),
            timeout=effective_timeout + 5,  # 5s grace over the inner subprocess timeout
        )
    except TimeoutError as exc:
        raise ScriptCronError(
            f"script timed out after {effective_timeout}s: {' '.join(validated_command)}"
        ) from exc
    except subprocess.TimeoutExpired as exc:
        raise ScriptCronError(
            f"script timed out after {effective_timeout}s: {exc}"
        ) from exc
    except FileNotFoundError as exc:
        # Race: shutil.which said the binary was reachable but it
        # vanished between the lookup and the spawn. Or absolute-path
        # commands that don't actually exist.
        raise ScriptCronError(
            f"executable not found at spawn time: {executable!r}: {exc}"
        ) from exc
    except OSError as exc:
        # Permission denied / not executable / I/O error during spawn.
        raise ScriptCronError(
            f"failed to spawn {executable!r}: {exc}"
        ) from exc

    if completed.returncode != 0:
        # Include stderr tail in the message so cron_history captures
        # what went wrong. Bounded so a script that floods stderr
        # doesn't bloat the history table.
        stderr_tail = (completed.stderr or "").strip()
        if len(stderr_tail) > 500:
            stderr_tail = stderr_tail[-500:] + " (truncated)"
        raise ScriptCronError(
            f"script exited with code {completed.returncode}: "
            f"{' '.join(validated_command)}. stderr: {stderr_tail or '<empty>'}"
        )

    # ── Stdout delivery ────────────────────────────────────────────────
    # Empty stdout returns "" — the cron tick's existing delivery layer
    # skips observations writes when result_text is falsy. Non-empty
    # gets truncated then returned verbatim.
    stdout = completed.stdout or ""
    if not stdout.strip():
        return ""
    return _truncate_stdout(stdout, effective_max_bytes)
