"""Shared persistence layer for capability-gap proposals.

Implements **Rule 21**: every observed gap becomes a user-reviewable
proposal. Three sibling detectors (missing-tool, missing-agent,
missing-contract-action) all need the same pending-queue shape — write
JSON file with deterministic id, list pending, get one, reject (= delete).

Approval is **kind-specific** and therefore NOT in this module — the
detector or the route layer owns the approval effect (mutate
domains.yaml / create agent definition / etc.). This module is pure
storage + identity.

Storage layout::

    <vault>/agntspace/memory/pending/<kind>-proposals/<proposal_id>.json

where ``<kind>`` is the (singular) proposal kind: ``contract-action`` /
``tool`` / ``agent``. The directory name uses the hyphen form so it
matches the URL slug the routes use.

Idempotency: ``stable_proposal_id(kind, target)`` is a sha256-derived
short id keyed on the (kind, target) tuple, so re-running a detector on
the same gap overwrites the prior proposal (no pile-up). Detectors that
prefer to refresh content but keep the slot can write again with the
same id; detectors that want to skip when one already exists can call
``list_pending`` and check membership before writing.

This mirrors the shape ``kb/taxonomy_proposals.py`` already uses for
taxonomy nodes — different kind, same persistence contract.
"""
from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


# Allowed kinds — the directory name on disk is ``<kind>-proposals``.
# arch:deterministic — these slugs are structural identifiers tied 1:1
# to the detector modules (missing_tool_detector / missing_agent_detector
# / missing_contract_action_detector / skill_completeness_detector);
# they're a closed enumeration, not a user-tunable policy. Adding a new
# kind requires shipping a new detector module AND extending this tuple
# in the same PR.
_VALID_KINDS = ("contract-action", "tool", "agent", "skill-completeness", "stale-skill", "agent-anomaly")  # arch:deterministic — closed enumeration tied 1:1 to detector modules


# ── Path helpers ─────────────────────────────────────────────────────


def _validate_kind(kind: str) -> None:
    if kind not in _VALID_KINDS:
        raise ValueError(
            f"capability proposal kind must be one of {_VALID_KINDS}, got {kind!r}",
        )


def pending_dir(vault_dir: Path, kind: str) -> Path:
    """Resolve the pending-proposals directory for a given kind.

    ``vault_dir`` is the vault ROOT (the directory that contains the
    ``agntspace/`` subdir), NOT the agntspace subdir itself. This matches
    the convention used by ``kb/taxonomy_proposals.py``.
    """
    _validate_kind(kind)
    return Path(vault_dir) / "agntspace" / "memory" / "pending" / f"{kind}-proposals"


# ── Models ───────────────────────────────────────────────────────────


@dataclass
class CapabilityProposal:
    """A single capability-gap proposal awaiting user approval.

    Stored as one JSON file per proposal under ``pending_dir(kind)``.

    Fields:

    * ``proposal_id`` — deterministic from (kind, target). Re-running a
      detector overwrites in place rather than accumulating.
    * ``kind`` — one of ``contract-action`` / ``tool`` / ``agent``. The
      pending-queue directory is named after this.
    * ``target`` — the missing thing's identifier. For ``tool`` this is
      a tool name (``send_email_v2``); for ``agent`` an agent slug
      (``data-analyst``); for ``contract-action`` the action string
      (``my_new_action``).
    * ``title`` — short user-facing label.
    * ``description`` — one-paragraph rationale.
    * ``rationale`` — longer explanation surfacing the EVIDENCE behind
      the proposal (which skills granted it, how many call sites, etc.).
    * ``proposed_by`` — the detector / agent that emitted it.
    * ``created_at`` — ISO-8601 UTC.
    * ``examples`` — short list of relevant identifiers (slugs / tool
      names / skill names) for the user's review surface.
    * ``payload`` — kind-specific structured data the approve handler
      needs (e.g. proposed contract domain, suggested skill template,
      detected callers). Everything in ``payload`` is informational —
      the approve handler MAY read it but never blindly trusts it.
    """

    proposal_id: str
    kind: str
    target: str
    title: str
    description: str
    rationale: str
    proposed_by: str = "agent"
    created_at: str = ""
    examples: list[str] = field(default_factory=list)
    payload: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "proposal_id": self.proposal_id,
            "kind": self.kind,
            "target": self.target,
            "title": self.title,
            "description": self.description,
            "rationale": self.rationale,
            "proposed_by": self.proposed_by,
            "created_at": self.created_at,
            "examples": list(self.examples),
            "payload": dict(self.payload),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CapabilityProposal:
        kind = str(data.get("kind", ""))
        return cls(
            proposal_id=str(data.get("proposal_id", "")),
            kind=kind,
            target=str(data.get("target", "")),
            title=str(data.get("title", "")),
            description=str(data.get("description", "")),
            rationale=str(data.get("rationale", "")),
            proposed_by=str(data.get("proposed_by", "agent")),
            created_at=str(data.get("created_at", "")),
            examples=list(data.get("examples", []) or []),
            payload=dict(data.get("payload", {}) or {}),
        )


# ── Identity + timestamp ─────────────────────────────────────────────


def stable_proposal_id(kind: str, target: str) -> str:
    """Deterministic id keyed on (kind, target).

    ``cap-<sha8>`` shape so a glance at the id reveals the family.
    """
    _validate_kind(kind)
    digest = hashlib.sha256(f"{kind}:{target}".encode()).hexdigest()[:10]
    return f"cap-{digest}"


def _now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


# ── Persistence ──────────────────────────────────────────────────────


def list_pending(vault_dir: Path, kind: str) -> list[CapabilityProposal]:
    """Return every pending proposal of a given kind, newest first."""
    pdir = pending_dir(vault_dir, kind)
    if not pdir.is_dir():
        return []
    out: list[CapabilityProposal] = []
    for f in sorted(pdir.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            log.warning("Skipping unparseable %s proposal: %s", kind, f, exc_info=True)
            continue
        if isinstance(data, dict):
            try:
                out.append(CapabilityProposal.from_dict(data))
            except Exception:
                log.warning("Skipping malformed %s proposal: %s", kind, f, exc_info=True)
                continue
    out.sort(key=lambda p: p.created_at, reverse=True)
    return out


def write_proposal(
    vault_dir: Path,
    kind: str,
    *,
    target: str,
    title: str,
    description: str,
    rationale: str,
    proposed_by: str = "agent",
    examples: list[str] | None = None,
    payload: dict[str, Any] | None = None,
) -> tuple[CapabilityProposal | None, str]:
    """Persist a new proposal. Returns ``(proposal, error_or_empty)``.

    Idempotent — re-running with the same (kind, target) overwrites the
    prior file via atomic ``.tmp`` rename. The pending-queue directory
    is created on demand. ``target`` and ``title`` are required;
    ``description`` may be empty when the title carries the meaning.
    """
    try:
        _validate_kind(kind)
    except ValueError as exc:
        return None, str(exc)
    if not (target or "").strip():
        return None, "target is required"
    if not (title or "").strip():
        return None, "title is required"

    proposal = CapabilityProposal(
        proposal_id=stable_proposal_id(kind, target),
        kind=kind,
        target=target.strip(),
        title=title.strip(),
        description=(description or "").strip(),
        rationale=(rationale or "").strip(),
        proposed_by=proposed_by or "agent",
        created_at=_now_iso(),
        examples=list(examples or []),
        payload=dict(payload or {}),
    )
    pdir = pending_dir(vault_dir, kind)
    try:
        pdir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return None, f"could not create pending dir: {exc}"
    target_path = pdir / f"{proposal.proposal_id}.json"
    tmp = target_path.with_suffix(".json.tmp")
    try:
        tmp.write_text(json.dumps(proposal.to_dict(), indent=2), encoding="utf-8")
        tmp.replace(target_path)
    except OSError as exc:
        return None, f"could not write proposal: {exc}"
    return proposal, ""


def get_proposal(
    vault_dir: Path, kind: str, proposal_id: str,
) -> CapabilityProposal | None:
    """Look up a single proposal by id."""
    try:
        _validate_kind(kind)
    except ValueError:
        return None
    target = pending_dir(vault_dir, kind) / f"{proposal_id}.json"
    if not target.is_file():
        return None
    try:
        return CapabilityProposal.from_dict(
            json.loads(target.read_text(encoding="utf-8")),
        )
    except Exception:
        log.warning("Failed to read %s proposal %s", kind, proposal_id, exc_info=True)
        return None


def reject_proposal(vault_dir: Path, kind: str, proposal_id: str) -> bool:
    """Delete a pending proposal. Returns True iff a file was removed."""
    try:
        _validate_kind(kind)
    except ValueError:
        return False
    target = pending_dir(vault_dir, kind) / f"{proposal_id}.json"
    if not target.is_file():
        return False
    try:
        target.unlink()
        return True
    except OSError:
        log.warning("Failed to remove %s proposal %s", kind, proposal_id, exc_info=True)
        return False


def proposal_stats(vault_dir: Path) -> dict[str, Any]:
    """Aggregate counts across all three capability-proposal kinds."""
    out: dict[str, Any] = {"by_kind": {}, "total": 0}
    for kind in _VALID_KINDS:
        items = list_pending(vault_dir, kind)
        out["by_kind"][kind] = len(items)
        out["total"] += len(items)
    return out
