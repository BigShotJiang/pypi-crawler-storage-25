"""Inbox folder watcher — auto-ingests files dropped into inbox/.

Watches both the global inbox/ (vault root) and per-KB inbox/ directories.
When new files appear, triggers ingest automatically.
Checks every 30 seconds.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agntspace.agent.orchestrator import Orchestrator
    from agntspace.automation.heartbeat import Heartbeat
    from agntspace.kb.service import KnowledgeBaseService

log = logging.getLogger(__name__)


# ── Quarantine directory canonical name ─────────────────────────────────
# Single source of truth for the quarantine subdir under each KB inbox.
# ``quarantine`` (visible) — chosen over ``.quarantine`` (hidden) because
# the contents are USER content (failed-to-ingest .md notes etc.), not
# AgntSpace bookkeeping. Hidden dot-folders are excluded from Obsidian's
# vault index, so previously a user couldn't see their own files in their
# daily PKM tool unless they navigated to /pipeline. Visible name fixes
# that and is consistent with sibling ``library/unsupported/`` (also
# user content, also visible).
#
# Migration: ``main.py`` runs ``migrate_quarantine_dot_to_visible`` once
# per boot to rename any pre-existing ``.quarantine`` to ``quarantine``.
# The legacy name is kept in exclusion sets as defense-in-depth so a
# half-migrated vault still excludes legacy contents from graph scans.
QUARANTINE_DIRNAME: str = "quarantine"
QUARANTINE_LEGACY_DIRNAME: str = ".quarantine"


# ── Reason-sidecar exclusion ────────────────────────────────────────────
# `.reason.txt` sidecars are AgntSpace's own bookkeeping artifacts — written
# next to a parked / quarantined file to explain WHY it was skipped. The
# watcher must NEVER treat them as inbox candidates, OR it produces the
# cascade documented in CLAUDE.md (2026-05-19): the watcher sees
# `<file>.reason.txt` as a new `.txt` source → tries to ingest it →
# pipeline fails → produces `<file>.reason.txt.reason.txt` → next cycle
# sees THAT as new → infinite chain of `.reason.N.txt.reason.txt.reason.txt`.
# Pattern catches every variant:
#   <name>.reason.txt
#   <name>.reason.1.txt / .reason.2.txt / .reason.99.txt   (collision-suffix)
#   <name>.reason.txt.reason.txt                            (cascade depth ≥1)
# This is a structural identifier of our own write path, not user content —
# `arch:deterministic` (not strategy).
_REASON_SIDECAR_RE = re.compile(  # arch:deterministic — matches our own .reason.txt sidecars + cascade variants
    r"\.reason(?:\.\d+)?\.txt(?:\.reason(?:\.\d+)?\.txt)*$",
    re.IGNORECASE,
)


def is_reason_sidecar(name: str) -> bool:
    """Return True if *name* is one of our own `.reason.txt` sidecars.

    Pure function — testable without a watcher instance. Matches:
      * ``<x>.reason.txt`` (canonical)
      * ``<x>.reason.1.txt`` / ``<x>.reason.42.txt`` (collision suffix)
      * ``<x>.reason.txt.reason.txt`` (cascade — depth ≥ 1)
    The reverse direction (real user file with literal ``.reason`` in its
    name like ``annual.reason.report.md``) is NOT matched because we
    anchor on ``.txt`` at end of string.
    """
    if not name:
        return False
    return bool(_REASON_SIDECAR_RE.search(name))


# ── Obsidian-Clipper inline-image filter (Task #3, 2026-05-19 night-2) ──
# When the user clips a web article into AgntSpace via the Obsidian Clipper
# browser extension, the article body lands as an .md file BUT every inline
# image referenced by that article is ALSO downloaded as a sibling file in
# the same inbox — with the source URL URL-encoded as the filename. The
# canonical signature is filenames starting with ``https_3A_2F_2F...`` or
# ``http_3A_2F_2F...`` — where ``_3A_`` is the percent-encoded colon and
# ``_2F_`` is the percent-encoded forward-slash (Clipper's specific encoding
# scheme uses ``_`` separators around the hex pairs, NOT raw ``%XX``).
#
# Forensic finding (CLAUDE.md session 2026-05-19 night-2, line 1907): on
# Wolf's vault, 9/10 quarantined substack-newsletter hero gifs were these —
# byte-identical inline-image downloads of the same article hero, dropped
# into inbox as standalone files. Without this filter they cycle through
# the full ingest pipeline (vision-LLM description, KB source page,
# graph entity registration) PER FILE, producing pointless work-queue
# load and polluting the wiki with one-line "image of substack header"
# concept pages.
#
# Architectural choice: filter at the SCAN boundary (via
# ``_unsupported_reason``) so these files are moved to
# ``library/unsupported/`` with a ``.reason.txt`` sidecar explaining why.
# They show up in the Pipeline page's Failed column where the user can
# bulk-delete via the session 116 UI. Same shape as oversized files +
# unsupported-extension files — symmetric quarantine-on-scan.
#
# The regex is anchored at the start of the filename (URL prefix is
# always positional) and case-insensitive (Obsidian Clipper's encoding
# is case-sensitive in practice — `_3A_` — but defensively we match
# either case).
#
# Marked ``arch:deterministic`` because it's a structural identifier of
# Obsidian Clipper's output format — recognising an external tool's
# write signature, not user strategy.
_OBSIDIAN_CLIPPER_INLINE_IMAGE_RE = re.compile(  # arch:deterministic — Obsidian Clipper URL-encoded inline-image filename signature
    r"^https?_3A_2F_2F",
    re.IGNORECASE,
)


def is_obsidian_clipper_inline_image(name: str) -> bool:
    """Return True if *name* is an Obsidian-Clipper URL-encoded inline image.

    Pure function — testable without a watcher instance. Matches filenames
    starting with the URL-encoded ``http://`` or ``https://`` prefix that
    Obsidian Clipper uses when saving inline images alongside a clipped
    article. The article's accompanying .md file is a legitimate KB
    source; these inline images are NOT — they belong to the article and
    should not be ingested as standalone sources.

    Positive cases:
      * ``https_3A_2F_2Fexample.com_2Ffoo.png``
      * ``HTTP_3A_2F_2Fexample.com_2Fimage.jpg`` (case variant)
      * ``https_3A_2F_2Fsubstackcdn.com_2F..._320x180_6.gif`` (substack hero)

    Negative cases (deliberately NOT matched):
      * ``my_notes_https_links.md`` — substring, not prefix
      * ``http_log_2026.md`` — `http` without `_3A_2F_2F` suffix
      * ``https.txt`` — bare token, no URL encoding
      * ``httpsbar.md`` — missing the underscore separator

    Independent of file extension. Caller decides whether to apply this
    filter only to image-shaped files OR all files — see ``_unsupported_reason``
    for the canonical wiring (called for any file in a drop-zone).
    """
    if not name:
        return False
    return bool(_OBSIDIAN_CLIPPER_INLINE_IMAGE_RE.match(name))


def migrate_quarantine_dot_to_visible(vault_paths) -> int:
    """Rename ``.quarantine/`` → ``quarantine/`` in every KB inbox.

    Idempotent — runs every boot, no-op once complete. Conservative on
    edge cases:

    - Only ``.quarantine`` exists → rename
    - Only ``quarantine`` exists → no-op
    - Both exist → move every file from legacy to new, then rmdir legacy
    - Neither exists → no-op
    - Rename fails (cross-device, locked file) → log + continue, don't crash boot

    Returns the number of KB directories whose quarantine was migrated
    (rename or merge counts as one). Errors never propagate.
    """
    if vault_paths is None:
        return 0
    try:
        kb_root = vault_paths.resolve("knowledge")
    except Exception:
        return 0
    if not kb_root.is_dir():
        return 0

    migrated = 0
    try:
        kb_entries = list(kb_root.iterdir())
    except OSError:
        return 0

    for kb in kb_entries:
        if not kb.is_dir():
            continue
        legacy = kb / "inbox" / QUARANTINE_LEGACY_DIRNAME
        target = kb / "inbox" / QUARANTINE_DIRNAME

        if not legacy.is_dir():
            continue  # nothing to migrate for this KB

        try:
            if not target.exists():
                # Simple rename — fastest path
                legacy.rename(target)
                migrated += 1
                log.info("Quarantine migrated: %s -> %s", legacy, target)
                continue

            # Both exist — move files from legacy into target. We do NOT
            # overwrite — if the same filename is in both, the legacy copy
            # gets a ``.legacy.<n>`` suffix so no user content is lost.
            target.mkdir(parents=True, exist_ok=True)
            moved_any = False
            for src in list(legacy.iterdir()):
                if not src.is_file():
                    continue
                dest = target / src.name
                if dest.exists():
                    n = 1
                    while True:
                        alt = target / f"{src.name}.legacy.{n}"
                        if not alt.exists():
                            dest = alt
                            break
                        n += 1
                try:
                    src.rename(dest)
                    moved_any = True
                except OSError:
                    log.exception("quarantine migration: failed to move %s", src)
            # Remove now-empty legacy dir; ignore failure (might still have
            # subdirs or hidden cruft we don't touch).
            try:
                legacy.rmdir()
            except OSError:
                pass
            if moved_any:
                migrated += 1
                log.info("Quarantine merged into visible dir: %s", target)
        except Exception:
            log.exception("quarantine migration failed for KB: %s", kb.name)

    return migrated


class RawWatcher:
    """Watches inbox/ and root folder for new files to ingest."""

    _MAX_RETRIES = 5

    def __init__(
        self,
        vault_dir: Path,
        kb_service: KnowledgeBaseService,
        root_dir: Path | None = None,
        scan_root: bool = False,
        heartbeat: Heartbeat | None = None,
        orchestrator: Orchestrator | None = None,
        check_interval: int = 60,
        work_queue: object | None = None,
        settings_service: object | None = None,
    ) -> None:
        self._vault_dir = vault_dir
        self._paths = None  # Set via watcher._paths = vault_paths in main.py
        self._root_dir = root_dir if scan_root else None
        self._kb = kb_service
        self._heartbeat = heartbeat
        self._orchestrator = orchestrator
        self._interval = check_interval
        self._work_queue = work_queue
        # User-controlled pause flag (config.toml [watcher].paused). Read on every
        # loop tick + check_and_ingest entry so toggling via Settings takes effect
        # immediately without a restart. Default False — watcher runs on fresh
        # installs, matching pre-pause behavior.
        self._settings_service = settings_service
        # Phase 1 architecture (2026-04-30): the watcher is enqueue-only.
        # It NEVER calls ``agent.invoke_skill`` inline — that's the work-queue
        # ``ingest`` handler's job. The watcher detects new files and enqueues
        # one job per affected KB; the work queue dispatches via agent in the
        # background. This keeps the watcher loop non-blocking even when an
        # individual dispatch takes 600s on a slow local LLM.
        #
        # The CI guard at tests/arch/test_watcher_no_inline_dispatch.py locks
        # this choice: any call to ``invoke_skill`` from inside this file
        # fails the build.
        #
        # ``_agent_mediated`` and ``_agent`` are kept for backwards-compat
        # with two paths that still need direct fallback when no agent is
        # wired:
        #   1. Legacy/minimal installs where the work queue isn't wired.
        #   2. Tests that exercise the watcher without the full app stack.
        # Production runs ALWAYS go through the work queue. Falling back to
        # ``kb.ingest()`` direct from inside the watcher loop violates Rule
        # #17 Tier A and the reliability-over-speed memory rule.
        self._agent: object | None = None
        self._agent_mediated: bool = False
        self._task: asyncio.Task | None = None  # type: ignore[type-arg]
        self._running = False
        self._known_files: set[str] = set()
        # Track root folder files: path → content hash (for rename/move/delete detection)
        self._root_file_hashes: dict[str, str] = {}
        # Track file mtime at time of ingestion — detect content modifications
        self._known_mtimes: dict[str, float] = {}
        # Track file sizes at time of ingestion — detect content added after creation
        self._known_sizes: dict[str, int] = {}
        # Track failed ingest attempts per file — stop retrying after _MAX_RETRIES
        self._fail_counts: dict[str, int] = {}
        # Sticky give-up: when a root file or quarantined-inbox file
        # exhausts its retry budget, we record an entry here so future
        # cycles silently skip it instead of resetting the counter and
        # repeating the give-up announcement every cycle. Cleared when
        # the file's mtime moves past the captured ``snapshot_mtime``
        # (user edited it) OR when ``now`` exceeds ``until_ts``.
        # Schema:  fpath -> {"until_ts": float, "snapshot_mtime": float, "reason": str}
        # Persisted in the watcher state file alongside _known_files /
        # _known_sizes / _known_mtimes.
        self._gave_up_files: dict[str, dict[str, float | str]] = {}
        # Prevent concurrent ingest runs (watcher cycle vs manual API call)
        self._ingesting = False
        # Observability: track last cycle for /api/watcher/status
        self._last_cycle_at: float = 0.0
        self._last_cycle_ingested: int = 0
        self._last_cycle_deferred: int = 0
        self._last_error: str = ""
        self._cycle_count: int = 0
        # Event-driven wake-up: watchdog sets this to wake the poll loop
        # immediately on a filesystem event. Poll loop also wakes on its
        # own every `_interval` seconds as a safety net.
        self._event_drain: asyncio.Event = asyncio.Event()
        # Last time a watchdog event woke us up (for observability).
        self._last_wake_at: float = 0.0
        self._wake_count: int = 0
        # ActivityLogger is wired post-construction by main.py
        # (raw_watcher._activity = activity_logger). Default to None so the
        # `is not None` guards at the call sites (Rule #13 events) work
        # cleanly when the watcher runs without a wired logger (tests,
        # minimal installs).
        self._activity = None
        # DecisionLogger wired post-construction (raw_watcher._decisions
        # = decisions). Task #5 (2026-05-19 night): consulted by the
        # dedup-rescue check so files that ingest CORRECTLY deduplicated
        # (same content_hash as an existing library copy →
        # _safe_unlink_dedup) are recognized as successfully-handled
        # instead of being false-quarantined after 5 cycles. Without it,
        # substack-newsletter hero gifs (9 of 10 stuck gifs were
        # byte-identical to library/.../..._6.gif) get falsely parked.
        # Fail-soft at every edge: missing/broken logger NEVER promotes a
        # real failure to "success" — the rescue is purely additive on
        # top of the existing stem/name evidence check.
        self._decisions = None

    def _resolve(self, relative_path: str) -> Path:
        """Resolve a logical vault path to a physical path."""
        if self._paths:
            return self._paths.resolve(relative_path)
        return self._vault_dir / relative_path

    def _default_kb_slug(self, kbs: list[dict] | None = None, *, auto_create: bool = True) -> str:
        """Return the canonical default KB slug for this vault.

        2026-04-27: default renamed `general` → `main`. This helper handles
        the transition gracefully:
          1. If a KB with slug "main" exists → return "main".
          2. Else if a legacy KB with slug "general" exists → return "general"
             (existing vault that hasn't migrated yet — keep working).
          3. Else → return "main" and (if auto_create=True) create it.

        Centralizes the routing target across the 4+ watcher sites that
        used to hardcode "general". Memory: project_knowledge_architecture_v3.md.
        """
        if kbs is None:
            try:
                kbs = self._kb.list_kbs()
            except Exception:
                kbs = []
        slugs = {k.get("slug") for k in kbs}
        if "main" in slugs:
            return "main"
        if "general" in slugs:
            return "general"  # legacy vault — keep working until Stage D migration
        # Neither exists — create "main" (the canonical default)
        if auto_create:
            try:
                self._kb.create_kb("Main")
            except Exception:
                log.debug("Could not auto-create 'main' KB", exc_info=True)
        return "main"

    @property
    def _state_path(self) -> Path:
        return self._vault_dir / ".inbox-watcher-state.json"

    def _load_state(self) -> set[str]:
        """Load known files from disk so we don't re-process across restarts.

        Catch-up: inbox files that were marked known but never actually
        produced a library copy are dropped from the known set so the
        watcher retries them.  This fixes the case where a previous
        ingest failed (e.g. LLM was down) and the file got stuck.
        """
        try:
            if self._state_path.exists():
                data = json.loads(self._state_path.read_text(encoding="utf-8"))
                # Only keep entries for files that still exist
                known = {f for f in data.get("known_files", []) if Path(f).exists()}

                # Catch-up: inbox files without library evidence are orphans
                orphans: set[str] = set()
                kb_prefix = str(self._resolve("knowledge"))
                for fpath in known:
                    fpath_posix = fpath.replace("\\", "/")
                    if "/inbox/" not in fpath_posix:
                        continue
                    p = Path(fpath)
                    if not p.exists():
                        continue
                    # Resolve KB slug from path
                    if fpath.startswith(kb_prefix) or fpath.replace("\\", "/").startswith(kb_prefix.replace("\\", "/")):
                        try:
                            rel = p.relative_to(self._resolve("knowledge"))
                            slug = str(rel.parts[0])
                            lib_dir = self._resolve(f"knowledge/{slug}/library")
                            if lib_dir.is_dir() and any(
                                lf.stem == p.stem or lf.name == p.name
                                for lf in lib_dir.rglob("*") if lf.is_file()
                            ):
                                continue  # has library evidence — genuinely processed
                            orphans.add(fpath)
                        except (ValueError, IndexError):
                            pass

                if orphans:
                    log.info(
                        "Inbox watcher: %d orphaned inbox file(s) detected on startup — will retry: %s",
                        len(orphans),
                        ", ".join(Path(f).name for f in orphans),
                    )
                    known -= orphans

                # Restore persisted sizes and mtimes
                self._known_sizes = {
                    k: v for k, v in data.get("known_sizes", {}).items()
                    if k in known
                }
                self._known_mtimes = {
                    k: v for k, v in data.get("known_mtimes", {}).items()
                    if k in known
                }
                # Sticky give-up state. Each entry carries a cooldown
                # ``until_ts`` (epoch seconds) AND a ``snapshot_mtime``
                # captured when the give-up was marked. Entries are
                # silently dropped when (a) the file no longer exists,
                # (b) ``until_ts`` has elapsed, or (c) the file's mtime
                # has moved past ``snapshot_mtime`` (user edit). The
                # mtime check is the load-bearing "user edit retry"
                # contract from the existing root-file give-up code.
                raw_give_up = data.get("gave_up_files", {})
                if isinstance(raw_give_up, dict):
                    now_ts = time.time()
                    cleaned: dict[str, dict[str, float | str]] = {}
                    for fpath, entry in raw_give_up.items():
                        if not isinstance(entry, dict):
                            continue
                        try:
                            until_ts = float(entry.get("until_ts", 0.0))
                            snapshot_mtime = float(entry.get("snapshot_mtime", 0.0))
                        except (TypeError, ValueError):
                            continue
                        reason = str(entry.get("reason", "exhausted retries"))
                        # Drop expired cooldowns at load time so a stale
                        # state file from yesterday's run doesn't keep
                        # silently suppressing a file that's safe to retry.
                        if until_ts and now_ts >= until_ts:
                            continue
                        # Drop entries for files that no longer exist OR
                        # whose mtime has moved past the snapshot (user
                        # edit). Both signal "the file changed since we
                        # gave up — retry it".
                        try:
                            current_mtime = Path(fpath).stat().st_mtime
                            if current_mtime > snapshot_mtime + 0.5:  # 0.5s slop for FS time resolution
                                continue
                        except OSError:
                            continue  # file gone — drop entry
                        cleaned[fpath] = {
                            "until_ts": until_ts,
                            "snapshot_mtime": snapshot_mtime,
                            "reason": reason,
                        }
                    self._gave_up_files = cleaned
                return known
        except Exception:
            log.debug("Could not load watcher state, starting fresh")
        return set()

    def _save_state(self) -> None:
        """Persist known files and their sizes to disk."""
        try:
            self._state_path.write_text(
                json.dumps({
                    "known_files": list(self._known_files),
                    "known_sizes": self._known_sizes,
                    "known_mtimes": self._known_mtimes,
                    "gave_up_files": self._gave_up_files,
                }),
                encoding="utf-8",
            )
        except Exception:
            log.debug("Could not save watcher state", exc_info=True)

    # ── Sticky give-up state ────────────────────────────────────────────
    # Cooldown after the watcher exhausts retries on a file. Survives
    # restarts via the state file. Without this, root-file give-up
    # silently reset every cycle, producing the 2026-05-19 "gave up after
    # 9 / 10 / 11 cycles" loop on Wolf's vault — the counter ticked up
    # but the file was still being scanned + verified every minute.

    # Default cooldown — 7 days. Long enough that a real "this file is
    # broken" verdict sticks; short enough that a forgotten quarantine
    # doesn't suppress the file forever (next week the user might fix it).
    _GIVE_UP_COOLDOWN_SECONDS: int = 7 * 24 * 3600  # arch:deterministic — bounded cooldown window for sticky give-up

    def _is_give_up_active(self, fpath: str, current_mtime: float | None = None) -> bool:
        """Return True if *fpath* is under an active give-up cooldown.

        Three short-circuit branches in priority order:
          1. Not tracked → False (caller proceeds normally).
          2. Cooldown elapsed → entry pruned, False (retry permitted).
          3. File edited (mtime moved past snapshot) → entry pruned,
             False (user signal that they want a retry).
        Otherwise True (caller must skip this path silently).

        *current_mtime* may be supplied by callers that already have a
        ``stat`` result (avoids a duplicate syscall in the hot scan
        path). When omitted, we call ``Path(fpath).stat()`` ourselves and
        gracefully fall back to "not active" on OSError (the file is
        gone — drop the entry).
        """
        entry = self._gave_up_files.get(fpath)
        if entry is None:
            return False
        try:
            until_ts = float(entry.get("until_ts", 0.0))
            snapshot_mtime = float(entry.get("snapshot_mtime", 0.0))
        except (TypeError, ValueError):
            # Malformed entry — drop and proceed.
            self._gave_up_files.pop(fpath, None)
            return False
        now_ts = time.time()
        if until_ts and now_ts >= until_ts:
            self._gave_up_files.pop(fpath, None)
            return False
        # Resolve mtime — use caller-supplied value when available,
        # otherwise stat. Gone-from-disk files have no give-up to enforce.
        try:
            if current_mtime is None:
                current_mtime = Path(fpath).stat().st_mtime
        except OSError:
            self._gave_up_files.pop(fpath, None)
            return False
        # User-edited the file since we gave up → retry. The 0.5s slop
        # absorbs FS time resolution differences (FAT32 = 2s,
        # NTFS = 100ns; tests on tmp_path produce sub-second diffs).
        if current_mtime > snapshot_mtime + 0.5:
            self._gave_up_files.pop(fpath, None)
            return False
        return True

    def _mark_give_up(
        self,
        fpath: str,
        *,
        snapshot_mtime: float,
        reason: str,
        cooldown_seconds: int | None = None,
    ) -> None:
        """Record a sticky give-up entry for *fpath*.

        Caller passes the mtime captured at give-up time so a future
        user edit can lift the suppression (see ``_is_give_up_active``).
        ``cooldown_seconds`` defaults to ``_GIVE_UP_COOLDOWN_SECONDS``;
        tests can override for fast verification.
        """
        if cooldown_seconds is None:
            cooldown_seconds = self._GIVE_UP_COOLDOWN_SECONDS
        until_ts = time.time() + max(1, int(cooldown_seconds))
        self._gave_up_files[fpath] = {
            "until_ts": float(until_ts),
            "snapshot_mtime": float(snapshot_mtime),
            "reason": str(reason)[:200],
        }

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._known_files = self._load_state()
        self._task = asyncio.create_task(self._run())
        log.debug("Inbox watcher started (interval: %ds, %d known files)", self._interval, len(self._known_files))

    async def _run(self) -> None:
        """Initial check + regular loop."""
        # Small delay to let other services initialize
        await asyncio.sleep(5)
        # Process any files already in inbox/ (dropped while server was down)
        try:
            result = await self.check_and_ingest()
            if result:
                log.info("Inbox watcher: startup ingest processed %d files", len(result))
        except Exception:
            log.exception("Inbox watcher: startup ingest failed")
        await self._loop()

    def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            self._task = None

    def trigger(self) -> None:
        """Wake the poll loop immediately. Safe to call from any thread.

        Used by the watchdog event handler to translate filesystem events
        into watcher cycles without blocking.
        """
        try:
            self._event_drain.set()
        except Exception:
            log.debug("trigger: could not set drain event", exc_info=True)

    def is_paused(self) -> bool:
        """True when the user has paused automatic ingestion via Settings.

        Reads ``[watcher].paused`` from config.toml on every call so toggling
        in the UI takes effect on the next loop tick without a restart. Defaults
        to False (watcher runs) when the settings service is missing or the
        key is absent — matching pre-pause behavior on every existing vault.
        """
        svc = self._settings_service
        if svc is None:
            return False
        try:
            return bool(svc.get_value("watcher", "paused", False))
        except Exception:
            return False

    def get_status(self) -> dict:
        """Return current watcher state for observability (/api/watcher/status)."""
        import time
        now = time.time()
        state_path = self._state_path
        state_exists = state_path.is_file()
        state_mtime = state_path.stat().st_mtime if state_exists else 0

        # Count quarantined files across all KBs
        quarantine_count = 0
        try:
            kb_dir = self._resolve("knowledge")
            if kb_dir.is_dir():
                for kb in kb_dir.iterdir():
                    # Read both visible (canonical) and legacy (dot) names —
                    # belt-and-braces so a half-migrated vault still surfaces
                    # accurate counts.
                    for sub in (QUARANTINE_DIRNAME, QUARANTINE_LEGACY_DIRNAME):
                        q = kb / "inbox" / sub
                        if q.is_dir():
                            quarantine_count += sum(1 for _ in q.iterdir() if _.is_file())
        except Exception:
            pass

        # Optional fs_events bridge (watchdog). None if not wired up.
        fs_events_status: dict | None = None
        bridge = getattr(self, "_fs_bridge", None)
        if bridge is not None:
            try:
                fs_events_status = bridge.status()
            except Exception:
                fs_events_status = {"available": False, "running": False}

        return {
            "running": self._running,
            "paused": self.is_paused(),
            "interval_seconds": self._interval,
            "known_files": len(self._known_files),
            "fail_counts": sum(self._fail_counts.values()),
            "fail_tracked": len(self._fail_counts),
            "quarantine_count": quarantine_count,
            "cycle_count": self._cycle_count,
            "last_cycle_at": self._last_cycle_at,
            "last_cycle_seconds_ago": (now - self._last_cycle_at) if self._last_cycle_at else None,
            "last_cycle_ingested": self._last_cycle_ingested,
            "last_cycle_deferred": self._last_cycle_deferred,
            "last_error": self._last_error,
            "state_file": str(state_path),
            "state_file_exists": state_exists,
            "state_file_mtime": state_mtime,
            # Real-time event bridge
            "wake_count": self._wake_count,
            "last_wake_at": self._last_wake_at,
            "last_wake_seconds_ago": (now - self._last_wake_at) if self._last_wake_at else None,
            "fs_events": fs_events_status,
        }

    # Directories to skip when scanning root folder
    _SKIP_DIRS = {  # arch:deterministic — mirrors fs_events._SKIP_DIR_NAMES; structural vault internals + universal OS noise, not user-tunable
        # AgntSpace / vault internals (old + new layout)
        "agntspace", "agntspace-inbox", "agntspace-journal",
        "agntspace-knowledge", "agntspace-projects",
        "agntspace-goals", "agntspace-finance", "agntspace-career",
        ".obsidian", ".git", ".trash",
        # Dev / system
        "node_modules", "__pycache__", ".venv", "venv", ".env",
        # OS system dirs (when root is home dir)
        "AppData", "Application Data", ".cache", ".local", ".config", ".vscode",
        "Library", ".Trash",
        # Cloud sync (managed separately if user connects them)
        "OneDrive", "Dropbox", "Google Drive", "iCloud Drive",
        # Common large dirs
        "Downloads", ".npm", ".nuget", ".cargo", ".rustup",
        # External-source-of-truth trees that bring their own structure +
        # graph topology. These are owned by their source app (OneNote
        # import, Apple Notes export, Notion export, Roam export, Logseq
        # export). KB ingestion would re-process them as digests + library
        # copies, doubling every node in Obsidian's graph view AND in our
        # graph. The user's source-of-truth wins; KB ingest only runs on
        # files dropped into agntspace-inbox/ or per-KB inbox/ folders.
        # 2026-05-09 (synthesis bloat session): pre-fix the user's 301
        # OneNote pages all got re-ingested as wiki/sources/ digests +
        # library/ binary copies, producing the duplicate "Hydrofor" /
        # "Reefing" / "Vecka 1" nodes in Obsidian's graph view.
        "OneNote", "AppleNotes", "Apple Notes", "Notion", "Roam", "Logseq",
    }

    _SUPPORTED_EXTS = {  # arch:deterministic — capability surface of the ingest pipeline, mirrors fs_events._SUPPORTED_EXTS
        # Text + web (text_utf8 / html_parser)
        ".md", ".txt", ".html", ".htm", ".rst",
        # Documents (pdf / docx / pptx / xlsx / epub)
        ".pdf", ".docx", ".pptx", ".xlsx", ".xlsm", ".epub",
        # Images (vision_llm)
        ".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp",
        # Tabular / structured (csv_tabular / json_pretty / text_utf8 for yaml)
        ".csv", ".tsv", ".yaml", ".yml", ".json", ".jsonl",
        # Transcripts (vtt_srt)
        ".vtt", ".srt",
        # Code (text_utf8)
        ".py", ".js", ".ts",
        # Audio (audio_whisper)
        ".mp3", ".wav", ".m4a", ".flac", ".ogg", ".opus",
        # Video (video_ffmpeg_vision)
        ".mp4", ".webm", ".mov", ".mkv",
    }

    # ── Task #5 (2026-05-19 night): dedup-rescue evidence check ──────────
    # The 4 ingest skip-reasons that count as "successfully handled" by
    # kb_service.ingest's _safe_unlink_dedup paths. SYNCED 1:1 with the
    # call sites at kb/service.py lines 4554/4587/4617/4625 — adding a
    # reason here without adding it there silently marks files as
    # success that never went through dedup; removing one re-opens the
    # substack-gif quarantine class. Frozen + inline-marked so the
    # arch:deterministic scanner accepts it as structural, not strategy.
    _DEDUP_SKIP_REASONS: frozenset[str] = frozenset({  # arch:deterministic — frozen enum tied 1:1 to kb_service.ingest dedup call sites
        "duplicate",            # same content_hash, different filename, same KB
        "cross_kb_duplicate",   # same content_hash, already in another KB
        "unchanged",            # same filename + same content_hash as last cycle
        "empty_file",           # zero-byte file — system correctly skips
    })

    def _slug_from_inbox_path(self, fpath: str) -> str:
        """Derive a KB slug from a per-KB inbox path; ``""`` for global inbox.

        Pure helper extracted so the dedup-rescue check and any future
        per-KB watcher introspection share ONE parsing rule. Matches the
        kb_prefix logic in ``_sync_compute_known_set``: files under
        ``<vault>/knowledge/<slug>/inbox/...`` resolve to ``<slug>``;
        global inbox returns empty.
        """
        try:
            p = Path(fpath)
            kb_root = self._resolve("knowledge")
            rel = p.relative_to(kb_root)
            parts = rel.parts
            if len(parts) >= 2 and parts[1] == "inbox":
                return str(parts[0])
        except (ValueError, OSError):
            pass
        return ""

    async def _rescue_dedup_successes(
        self, unverified_paths: set[str],
    ) -> set[str]:
        """Ask the decision log: which unverified paths were dedup-skipped?

        A path "rescued" here was correctly handled by kb_service.ingest:
        recognized as a content_hash duplicate of an existing library
        copy and unlinked from inbox via ``_safe_unlink_dedup``. The
        watcher's stem/name-based library-evidence check can't see this
        because the library copy lives under a DIFFERENT filename (the
        first one that won the dedup race).

        Returns the subset of ``unverified_paths`` the caller should
        move from ``unverified_paths`` to ``successfully_known``.

        Fail-soft at EVERY edge — missing decision logger, broken query,
        malformed details JSON all return empty so a real failure is
        NEVER promoted to "success". The rescue is purely additive.

        Lookback semantics: file mtime is the lower bound for the
        decision query so an OLD dedup decision for a same-named file
        from days ago won't false-match. When the file is already gone
        from disk (the canonical post-dedup state), fall back to a
        bounded 1-hour window — catches the dispatch that JUST
        unlinked it without re-matching ancient decisions.
        """
        if self._decisions is None or not unverified_paths:
            return set()

        from datetime import UTC, datetime

        now_ts = datetime.now(UTC).timestamp()
        fallback_floor_ts = now_ts - 3600.0  # 1h lookback when file vanished

        handled: set[str] = set()
        for fpath in unverified_paths:
            try:
                slug = self._slug_from_inbox_path(fpath)
                if not slug:
                    # Global-inbox files have a separate path-shape; the
                    # decision_log target is always kb/{slug}/{fname}, so
                    # we can't construct the query target without a slug.
                    continue
                p = Path(fpath)
                fname = p.name
                target = f"kb/{slug}/{fname}"

                if p.exists():
                    try:
                        since_ts = p.stat().st_mtime
                    except OSError:
                        since_ts = fallback_floor_ts
                else:
                    since_ts = fallback_floor_ts
                since_iso = datetime.fromtimestamp(
                    since_ts, tz=UTC,
                ).isoformat()

                rows = await self._decisions.query(
                    action_type="ingest_file",
                    since=since_iso,
                    limit=50,
                )
                for row in rows:
                    if row.get("action_target") != target:
                        continue
                    if row.get("contract_result") != "skipped":
                        continue
                    details = row.get("details") or {}
                    if not isinstance(details, dict):
                        continue
                    reason = details.get("skip_reason", "")
                    if reason in self._DEDUP_SKIP_REASONS:
                        handled.add(fpath)
                        break  # one matching decision is enough
            except Exception:
                # Per-path failure NEVER prevents other rescues. A
                # broken query path also can't promote real failures
                # to success — we just don't rescue this one and fall
                # through to the legacy fail-count path.
                log.debug(
                    "dedup-rescue check failed for %s",
                    fpath,
                    exc_info=True,
                )

        return handled

    def _sync_compute_known_set(
        self,
        current_files: set[str],
        deferred: set[str],
        ingested: list[str],
    ) -> tuple[set[str], int]:
        """Sync helper — replaces the post-dispatch bookkeeping loop.

        Phase A perf fix (2026-05-06): walked every file in
        (current_files - deferred) and called the inner closure
        ``_has_library_evidence_in_any_kb`` which rglob()'s every KB's
        library + 2 quarantine dirs per file. On a 1700-article vault
        that produced O(N²) sync IO on the event loop and was the
        dominant blocker (30-90s per cycle).

        Pure sync; no async dispatch. Returns
        ``(successfully_known, unverified_skipped, unverified_paths)``
        so the caller can update ``self._known_files``, emit diagnostic
        events, AND increment ``_fail_counts`` for paths that completed
        ingest without producing library evidence. The third element is
        the set of those silent-fail paths (2026-05-12 give-up fix —
        before this, those paths logged "will retry" forever and never
        incremented the fail counter, so the existing exhaustion logic
        at line 1148 never fired for them).
        """
        from pathlib import Path as _Path

        ingested_names = {_Path(i).name for i in ingested}
        ingested_stems = {_Path(i).stem for i in ingested}

        def _has_library_evidence_in_any_kb(filename: str, stem: str) -> bool:
            """Walk every KB's library AND quarantine dirs for matching name/stem."""
            kb_root = self._resolve("knowledge")
            if not kb_root.is_dir():
                return False
            try:
                for kb in kb_root.iterdir():
                    if not kb.is_dir():
                        continue
                    for evidence_root in (
                        kb / "library",
                        kb / "inbox" / ".quarantine",
                        kb / "library" / ".quarantine",
                    ):
                        if not evidence_root.is_dir():
                            continue
                        for lf in evidence_root.rglob("*"):
                            if not lf.is_file():
                                continue
                            if lf.name == filename or lf.stem == stem:
                                return True
                            if "." in lf.stem and lf.stem.split(".", 1)[0] == stem:
                                return True
            except OSError:
                pass
            return False

        successfully_known: set[str] = set()
        unverified_skipped = 0
        # 2026-05-12 give-up fix: track which paths went through ingest
        # this cycle without producing library evidence. The caller
        # increments ``_fail_counts[fpath]`` for each so the existing
        # MAX_RETRIES exhaustion logic actually fires (pre-fix these
        # paths logged "will retry" forever and never incremented).
        unverified_paths: set[str] = set()
        kb_prefix = str(self._resolve("knowledge"))

        for fpath in current_files - deferred:
            p = _Path(fpath)
            fname = p.name
            stem = p.stem

            if "/inbox/" in fpath.replace("\\", "/") and p.exists():
                if fname in ingested_names:
                    successfully_known.add(fpath)
                    continue
                if fpath in self._known_files:
                    if fpath.startswith(kb_prefix):
                        rel = p.relative_to(self._resolve("knowledge"))
                        slug = str(rel.parts[0])
                        lib_dir = self._resolve(f"knowledge/{slug}/library")
                        if lib_dir.is_dir() and any(
                            lf.stem == stem or lf.name == fname
                            for lf in lib_dir.rglob("*") if lf.is_file()
                        ):
                            successfully_known.add(fpath)
                        else:
                            log.info("Inbox watcher: %s still in inbox with no library match — will retry", fname)
                            unverified_paths.add(fpath)
                    elif _has_library_evidence_in_any_kb(fname, stem):
                        successfully_known.add(fpath)
                    else:
                        log.info(
                            "Inbox watcher: %s in global inbox with no library "
                            "evidence in any KB — will retry next cycle", fname,
                        )
                        unverified_skipped += 1
                        unverified_paths.add(fpath)
                else:
                    log.info("Inbox watcher: %s still in inbox after ingest — will retry next cycle", fname)
                    unverified_paths.add(fpath)
            else:
                if fname in ingested_names or stem in ingested_stems:
                    # Ingested this cycle — root file's copy made it through.
                    successfully_known.add(fpath)
                elif _has_library_evidence_in_any_kb(fname, stem):
                    # A previous cycle's copy of this root file produced a
                    # library entry. Genuine evidence — mark known.
                    successfully_known.add(fpath)
                else:
                    log.info("Inbox watcher: root file %s not yet evidenced in any library — will retry", fname)
                    unverified_skipped += 1
                    unverified_paths.add(fpath)

        return successfully_known, unverified_skipped, unverified_paths

    def _sync_detect_modifications(self, candidates: set[str]) -> set[str]:
        """Sync helper — return the subset of *candidates* whose mtime/size
        signals a content change since the last ingest.

        Phase A perf fix (2026-05-06): extracted from ``_do_check_and_ingest``
        so the per-file ``Path.stat()`` calls run inside ``asyncio.to_thread``.
        Pure sync IO; no async dispatch. Mutating ``self._known_files`` is the
        caller's responsibility (we only return the modified set).
        """
        modified: set[str] = set()
        for fpath in candidates:
            if fpath in self._fail_counts and self._fail_counts[fpath] >= self._MAX_RETRIES:
                continue
            try:
                st = Path(fpath).stat()
            except OSError:
                continue
            old_mtime = self._known_mtimes.get(fpath)
            old_size = self._known_sizes.get(fpath, -1)
            if old_mtime is not None and st.st_mtime > old_mtime:
                log.info("Inbox watcher: file modified (mtime %s → %s), re-processing: %s",
                         old_mtime, st.st_mtime, Path(fpath).name)
                modified.add(fpath)
            elif old_size == 0 and st.st_size > 0:
                log.info("Inbox watcher: previously-empty file now has content (%d bytes), re-processing: %s",
                         st.st_size, Path(fpath).name)
                modified.add(fpath)
        return modified

    def _scan_all_raw(self) -> set[str]:
        """Scan inbox/ directories and root folder for files."""
        files: set[str] = set()

        # 1. agntspace/inbox/ (explicit drop zone)
        inbox = self._resolve("inbox")
        if inbox.is_dir():
            for f in inbox.iterdir():
                if f.is_file() and f.name != ".gitkeep":
                    files.add(str(f))

        # 2. Per-KB inbox/
        kb_dir = self._resolve("knowledge")
        if kb_dir.is_dir():
            for kb in kb_dir.iterdir():
                if kb.is_dir():
                    kb_inbox = kb / "inbox"
                    if kb_inbox.is_dir():
                        for f in kb_inbox.iterdir():
                            if f.is_file() and f.name != ".gitkeep":
                                files.add(str(f))

        # 3. Root folder — scan for user content to ingest as knowledge
        #    agntspace/ is inside root, so root IS the vault
        if self._root_dir and self._root_dir != self._vault_dir:
            self._scan_dir_recursive(self._root_dir, files)

        return files

    def _scan_dir_flat(self, directory: Path, files: set[str]) -> None:
        """Scan only top-level files in a directory (non-recursive).

        Excludes our own `.reason.txt` sidecars at scan time so the
        watcher never tries to re-ingest its own diagnostic output. The
        sidecar-cascade is the canonical 2026-05-19 stall mode.
        """
        try:
            for f in directory.iterdir():
                if not f.is_file():
                    continue
                if f.name.startswith("."):
                    continue
                if is_reason_sidecar(f.name):
                    continue
                if f.suffix.lower() not in self._SUPPORTED_EXTS:
                    continue
                # Sticky give-up: if this path was previously marked
                # give-up and its cooldown hasn't elapsed AND the file
                # hasn't been edited since, silently skip. The user
                # editing the file moves mtime past the give-up
                # snapshot, which clears the override (see
                # _is_give_up_active).
                if self._is_give_up_active(str(f)):
                    continue
                files.add(str(f))
        except OSError:
            pass

    # How many seconds a file must exist before we process it.
    # Editors like Obsidian create an empty file first, then write content
    # moments later.  Deferring very young files avoids ingesting the blank
    # shell and marking the file as "known" before the real content arrives.
    # At 30-second scan intervals, a 5-second grace period means the file
    # is picked up on the same cycle or the next one — no perceptible delay.
    _SETTLE_SECONDS = 5
    # Skip files larger than 10MB — likely binaries or exports that would
    # blow up LLM token budgets and chunked extraction runtime.
    _MAX_FILE_BYTES = 10 * 1024 * 1024

    def _scan_dir_recursive(self, directory: Path, files: set[str]) -> None:
        """Recursively scan a directory, skipping system/hidden dirs.

        Also excludes our own `.reason.txt` sidecars (cascade defense —
        see ``is_reason_sidecar``) and any path the watcher previously
        marked give-up that's still inside its cooldown window.
        """
        now = time.time()
        try:
            for f in directory.iterdir():
                if f.name.startswith(".") or f.name in self._SKIP_DIRS:
                    continue
                if f.is_dir():
                    self._scan_dir_recursive(f, files)
                elif f.is_file() and f.suffix.lower() in self._SUPPORTED_EXTS:
                    # Cascade defense — never re-ingest our own sidecars.
                    if is_reason_sidecar(f.name):
                        continue
                    try:
                        st = f.stat()
                    except OSError:
                        continue
                    # Skip empty files (0 bytes is never useful)
                    if st.st_size == 0:
                        continue
                    # Skip huge files (binaries, data dumps) — would blow up LLM budget
                    if st.st_size > self._MAX_FILE_BYTES:
                        log.debug("Skipping oversized file (%d bytes): %s",
                                  st.st_size, f.name)
                        continue
                    # Defer very young files — let the editor finish writing
                    if now - st.st_mtime < self._SETTLE_SECONDS:
                        continue
                    # Sticky give-up: previously marked + within cooldown +
                    # unchanged since marker → silently skip.
                    if self._is_give_up_active(str(f), st.st_mtime):
                        continue
                    files.add(str(f))
        except OSError:
            pass  # Skip inaccessible dirs (OneDrive placeholders, permissions)

    # Image extensions that can be referenced by markdown files.
    _IMAGE_EXTS = frozenset({  # arch:deterministic — image format capabilities of the vision pipeline
        ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".bmp", ".tiff", ".tif",
    })

    def _dest_name_for_source(self, src: Path, used_names: set[str]) -> str:
        """Produce a collision-safe destination filename for *src*.

        Pre-fix C (2026-05-01): the watcher copied multiple root files with
        the SAME filename into the same destination using ``dest = inbox /
        src.name``, so 10 OneNote ``Untitled page.md`` files from different
        sections all collided onto one inbox path. Only the latest copy
        survived; the rest got re-detected next cycle, retried forever, and
        produced the 104+ ``kb-ingest-anti-watcher`` anti-reflex hits.

        New behavior: if ``src.name`` is already used in this cycle, append
        a deterministic 8-char suffix derived from a hash of the source's
        full path. Same source path always produces the same destination
        name — idempotent across cycles.

        Returns the destination filename only (not full path); the caller
        joins it onto whichever destination dir it's targeting.
        """
        if src.name not in used_names:
            return src.name
        import hashlib
        # Hash the full source path so the dest name is deterministic for
        # this specific source even on retries.
        path_hash = hashlib.sha256(str(src).encode("utf-8")).hexdigest()[:8]
        return f"{src.stem}.{path_hash}{src.suffix}"

    def _resolve_unique_inbox_dest(
        self, src: Path, dest_dir: Path, used_names: set[str],
    ) -> Path:
        """Resolve the destination path for *src* in *dest_dir*, accounting
        for filename collisions within this cycle. Companion to
        ``_dest_name_for_source`` — wraps the name resolution and returns
        the full Path.
        """
        return dest_dir / self._dest_name_for_source(src, used_names)

    def _copy_sibling_images(self, md_file: Path, dest_dir: Path) -> int:
        """Copy images referenced by *md_file* into *dest_dir*.

        Parses ``![alt](path)`` and ``![[path]]`` references, resolves
        them relative to the markdown file's parent directory (and common
        attachment subdirs like ``assets/``, ``attachments/``, ``images/``),
        and copies any that exist.  Returns the number of images copied.

        This is the companion to ``kb.image_resolver.resolve_local_images``
        but runs at the watcher layer — before the file reaches the inbox —
        so images travel alongside their markdown.
        """
        try:
            from agntspace.kb.image_resolver import find_markdown_image_refs
        except ImportError:
            return 0

        try:
            text = md_file.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return 0

        refs = find_markdown_image_refs(text)
        if not refs:
            return 0

        source_dir = md_file.parent
        attachment_subdirs = ["", "assets", "attachments", "images", "files", "media"]
        copied = 0

        for ref in refs:
            path_str = ref["path"]

            # Skip remote URLs — the ingest pipeline downloads those itself.
            if path_str.startswith(("http://", "https://", "data:")):
                continue

            # Skip non-image extensions
            ext = Path(path_str).suffix.lower()
            if ext not in self._IMAGE_EXTS:
                continue

            # Search source dir + common attachment subdirs
            found: Path | None = None
            for subdir in attachment_subdirs:
                candidate = source_dir / subdir / path_str if subdir else source_dir / path_str
                try:
                    if candidate.exists() and candidate.is_file():
                        found = candidate
                        break
                except OSError:
                    continue

            if not found:
                continue

            try:
                st = found.stat()
                if st.st_size == 0 or st.st_size > self._MAX_FILE_BYTES:
                    continue
            except OSError:
                continue

            dest = dest_dir / found.name
            try:
                if not dest.exists():
                    import shutil as _shutil
                    _shutil.copy2(str(found), str(dest))
                    copied += 1
                    log.debug("Copied sibling image %s alongside %s", found.name, md_file.name)
            except OSError:
                log.debug("Could not copy sibling image %s", found.name, exc_info=True)

        if copied:
            log.info("Watcher: copied %d sibling image(s) for %s", copied, md_file.name)
        return copied

    def _snapshot_file_stats(self, files: set[str]) -> None:
        """Record size and mtime for all files so we detect future changes."""
        for fpath in files:
            try:
                st = Path(fpath).stat()
                self._known_sizes[fpath] = st.st_size
                self._known_mtimes[fpath] = st.st_mtime
            except OSError:
                pass

    # Phase 1 (2026-04-30) — the watcher no longer dispatches the agent inline.
    # Constants ``_AGENT_INGEST_TIMEOUT_SECONDS`` and ``_AGENT_LONG_DISPATCH_SECONDS``
    # moved to ``automation/agent_dispatch.AgentIngestDispatcher`` (used by the
    # work-queue ``ingest`` handler). The CI guard at
    # ``tests/arch/test_watcher_no_inline_dispatch.py`` enforces this — any
    # ``invoke_skill`` call from inside this module fails the build.

    async def _ingest_legacy_direct(self, slug: str) -> dict:
        """Direct ``kb.ingest()`` call — only used when no work queue is wired.

        Phase 1 (2026-04-30) made the watcher enqueue-only. Production paths
        always have ``_work_queue`` wired and call ``_enqueue_agent_retry()``
        instead. This direct path remains for two narrow cases:

          1. **Tests** that exercise the watcher without standing up the full
             work-queue + agent stack.
          2. **Minimal installs** where ``_work_queue is None``.

        It is NOT a fallback for failed agent dispatches. Per
        [memory: feedback_reliability_over_speed.md] ("never skip agents for
        speed"), production failures stay in the work queue's retry loop
        rather than silently bypassing the agent layer here.
        """
        result = await self._kb.ingest(slug)
        result.setdefault("via", "direct")
        return result

    async def _run_ingest_for_slug(self, slug: str, reason: str) -> dict:
        """Production path: enqueue. Test/minimal path: direct call.

        The watcher cycle calls this once per affected KB. It returns a
        dict whose shape is backwards-compatible with the legacy
        ``_ingest_via_agent`` return value so the existing cycle-body
        accounting (``result.get("ingested", [])`` etc.) keeps working
        unchanged.

        Production return shape (work queue wired):
            ``{"slug": slug, "status": "enqueued", "via": "work_queue",
                "ingested": [], "skipped": [], "count": 0, "mutations": {}}``

        Direct/legacy return shape (no work queue):
            Whatever ``KnowledgeBaseService.ingest()`` returns, with
            ``via: "direct"`` set if not already present.

        The "enqueued" status produces an empty ``ingested`` list — the
        watcher's downstream library-evidence check (next cycle) is the
        one that confirms the work actually completed. Compile cascade
        moves to the work-queue handler too (Phase 1) — the librarian's
        ``run_wiki_job`` skill chains compile internally, and the
        heartbeat-driven editor-quality-pass picks up anything that
        slips through.
        """
        if self._work_queue is not None and self._agent_mediated and self._agent is not None:
            await self._enqueue_agent_retry(slug, reason)
            return {
                "slug": slug,
                "status": "enqueued",
                "via": "work_queue",
                "ingested": [],
                "skipped": [],
                "count": 0,
                "mutations": {},
            }
        # Test fixtures, minimal installs without a work queue, or boot
        # phase before the queue is wired. The direct path is bounded
        # by the same per-KB lock inside ``KnowledgeBaseService.ingest``,
        # so concurrent calls won't race.
        return await self._ingest_legacy_direct(slug)

    async def _enqueue_agent_retry(self, slug: str, reason: str) -> None:
        """Enqueue an agent-mediated ingest job through the persistent work queue.

        Phase 1 (2026-04-30) — this is the watcher's ONLY path to ingest.
        The work-queue ``ingest`` handler dispatches via
        ``agent.invoke_skill("kb-ingest", {slug})`` with timeout + heartbeat +
        escalation in the background, so the watcher cycle returns in
        milliseconds regardless of how slow the LLM is.

        Best-effort: a missing or broken work queue is logged at debug level
        rather than raising. The watcher cycle still completes; the next
        cycle's library-evidence check will see the file unchanged and try
        again.

        Dedup is intentional — the watcher may detect the same KB slug
        across multiple consecutive cycles before the work-queue handler
        runs. ``deduplicate=True`` in ``WorkQueue.enqueue`` collapses these
        to one pending row per (job_type, payload) tuple.
        """
        if self._work_queue is None:
            log.debug("work queue not wired — cannot enqueue ingest for %s", slug)
            return
        try:
            await self._work_queue.enqueue(  # type: ignore[attr-defined]
                "ingest",
                {"slug": slug, "retry_reason": reason},
                deduplicate=True,
            )
        except Exception:
            log.debug("work queue enqueue failed for %s (%s)", slug, reason, exc_info=True)

    def _kb_pipeline_frozen(self) -> bool:
        """True when the global pipeline freeze flag is set.

        Mirrors ``is_paused()`` in shape but reads the ``[pipeline].frozen``
        config flag via ``self._kb.is_pipeline_frozen()``. Total — never
        raises. Returns False when the kb_service doesn't expose the
        method (test stubs, minimal installs) so the default is "run".

        2026-05-12 night-9: added to fix a spin-loop bug where, with
        pipeline frozen, the watcher enqueued ingest jobs that the
        handler bounced back as deferred-by-freeze via immediate
        re-enqueue. The re-enqueue ran at machine speed (~50/sec)
        consuming the work-queue worker AND triggering 22-second
        event-loop blocks via cumulative thread contention. The fix
        is to short-circuit at the SOURCE (watcher) so frozen periods
        produce zero new queue traffic, AND remove the handler's
        re-enqueue so existing queued jobs drain cleanly.
        """
        try:
            return bool(self._kb.is_pipeline_frozen())
        except Exception:
            return False

    async def check_and_ingest(self) -> list[str]:
        """Check for new files and auto-ingest them.

        Wraps the cycle in a correlation scope so every activity event
        and decision produced by the ingest pipeline shares the same
        causal ID (Rule #13). The scope prefix is ``watcher`` so the
        origin is clear in the /decisions page.
        """
        if self.is_paused():
            log.debug("Inbox watcher: paused via Settings, skipping cycle")
            return []
        # Pipeline-freeze gate (2026-05-12 night-9): when the global
        # freeze flag is set, every ingest job would hit the gate at
        # ``kb_service.ingest`` and re-enqueue, spinning the work queue.
        # Skip the cycle entirely at the source. Files stay in inbox;
        # the next cycle after unfreeze picks them up.
        if self._kb_pipeline_frozen():
            log.debug("Inbox watcher: pipeline frozen, skipping cycle")
            return []
        if self._ingesting:
            log.debug("Inbox watcher: ingest already in progress, skipping cycle")
            return []
        self._ingesting = True
        try:
            from agntspace.activity.decisions import (
                correlation_scope,
                new_correlation_id,
            )
            with correlation_scope(new_correlation_id("watcher")):
                return await self._do_check_and_ingest()
        finally:
            self._ingesting = False

    # Max files to process per watcher cycle. Prevents blocking for minutes
    # when a large vault is first connected. Remaining files are picked up
    # on subsequent 30-second cycles.
    #
    # Phase 2 (Rule 12): the cap is loaded from
    # ``defaults/skills/core/kb-ingest/config/throughput.yaml`` via
    # ``self._kb._load_throughput_cap("max_per_cycle", ...)`` so the
    # watcher and the kb-service share one source of truth and the
    # cap is user-tunable without code changes. The fallback below is
    # used only when the kb service / skill loader / config is missing.
    _FALLBACK_MAX_PER_CYCLE = 10  # arch:deterministic -- degraded-mode mirror of throughput.yaml; only used when the skill loader is unavailable, see Phase 2 docstring

    # Per-cycle file cap applied while the server is still booting (graph build
    # in progress, app.state.ready == False). The default ingest cap (10) plus
    # the backlog of 1000+ files on a full vault causes the ingest loop to
    # monopolize the event loop for the entire startup, keeping the UI
    # unresponsive for ~85 minutes. Throttling to 2/cycle during boot leaves
    # CPU + LLM bandwidth available for the background graph build to finish
    # (typically in 2-3 minutes), after which the cap reverts to the full
    # steady-state value from the skill config. Zero impact on steady-state
    # throughput — this only bites during the first few minutes post-restart.
    _BOOTING_MAX_PER_CYCLE = 2  # arch:deterministic — boot throttle (event-loop yielding), pure infrastructure

    @property
    def _max_per_cycle(self) -> int:
        # Boot-aware throttle: while the server is still warming up the
        # knowledge graph, yield CPU + LLM bandwidth by capping ingest at a
        # tiny batch. Falls back silently to the normal cap when no app
        # handle is wired (tests, minimal installs, or post-ready).
        app = getattr(self, "_app", None)
        if app is not None:
            try:
                if not bool(getattr(app.state, "ready", True)):
                    return self._BOOTING_MAX_PER_CYCLE
            except Exception:
                pass

        kb = getattr(self, "_kb", None)
        if kb is not None and hasattr(kb, "_load_throughput_cap"):
            try:
                return kb._load_throughput_cap("max_per_cycle", default=self._FALLBACK_MAX_PER_CYCLE)
            except Exception:
                pass
        return self._FALLBACK_MAX_PER_CYCLE

    def _unsupported_reason(self, f: Path) -> str | None:
        """Return a reason string if ``f`` is unsupported, else None.

        Called for files sitting in explicit drop-zones (global inbox or
        per-KB inbox). Root-folder files are already filtered by extension
        in ``_scan_dir_recursive`` — this method only fires for files the
        user actively placed in a drop-zone that the pipeline can't accept.

        The Obsidian-Clipper inline-image check is positioned BEFORE the
        ``_SUPPORTED_EXTS`` test because clipper inline images use real
        image extensions (.png/.jpg/.gif/.webp) which ARE supported by the
        pipeline — without this guard they'd cycle through vision-LLM
        description + standalone KB source creation, defeating the
        Task #3 architectural cure (CLAUDE.md session 2026-05-19 night-2).
        """
        try:
            st = f.stat()
        except OSError:
            return None
        if st.st_size == 0:
            return None  # 0-byte = "not ready", not "unsupported"
        import time
        if time.time() - st.st_mtime < self._SETTLE_SECONDS:
            return None  # too young — let it settle
        if st.st_size > self._MAX_FILE_BYTES:
            return f"oversized:{st.st_size}"
        # Obsidian-Clipper URL-encoded inline-image signature — these are
        # downloaded ALONGSIDE a clipped .md article, not standalone KB
        # sources. Quarantine via park_unsupported_file's sidecar machinery
        # so the user sees them in /pipeline's Failed column with a clear
        # reason; bulk-delete via the session 116 UI clears the noise.
        if is_obsidian_clipper_inline_image(f.name):
            return "clipper_inline_image"
        if f.suffix.lower() not in self._SUPPORTED_EXTS:
            return f"unsupported_type:{f.suffix.lower() or 'no_extension'}"
        return None

    def _quarantine_unverified_file(self, fpath: str) -> bool:
        """Quarantine a file that's exhausted ``_MAX_RETRIES`` of silent
        ingest failures (file completes ingest but never produces library
        evidence).

        Three placement cases:

        - **Per-KB inbox** (``knowledge/<slug>/inbox/<file>``): physically
          move into ``knowledge/<slug>/inbox/quarantine/<file>`` with a
          ``.reason.txt`` sidecar naming attempts. File leaves the active
          scan path so the watcher stops touching it.
        - **Global inbox** (``agntspace-inbox/<file>``): move into
          ``agntspace-inbox/quarantine/<file>`` with sidecar. Same shape.
        - **Root file** (user's vault root, e.g. ``Pasted image *.png``):
          per Rule #1 we never modify user files at vault root. Instead
          we snapshot mtime+size into ``_known_*`` so future watcher
          cycles skip this file via the existing ``_known_files``
          membership check. If the user edits the file (mtime changes),
          ``_sync_detect_modifications`` re-triggers the pipeline.

        Returns True when the file was successfully quarantined (or
        marked-known for the root case), False on any failure. Failures
        are non-fatal — caller logs and continues.

        Sync helper — called via ``asyncio.to_thread`` from the cycle
        loop. Never awaits.
        """
        from pathlib import Path as _Path

        p = _Path(fpath)
        if not p.exists():
            # File disappeared between scan and now (user moved/deleted) —
            # treat as resolved. The exhaustion bookkeeping happens above.
            return True

        # Determine placement via /inbox/ token in the path. Falls through
        # to root-file handling otherwise.
        slash_path = fpath.replace("\\", "/")
        is_inbox_file = "/inbox/" in slash_path and "/quarantine/" not in slash_path

        if is_inbox_file:
            try:
                quarantine_dir = p.parent / QUARANTINE_DIRNAME
                quarantine_dir.mkdir(parents=True, exist_ok=True)
                dest = quarantine_dir / p.name
                # Collision-safe: suffix .1, .2 if name exists
                suffix = 1
                while dest.exists():
                    dest = quarantine_dir / f"{p.stem}.{suffix}{p.suffix}"
                    suffix += 1
                # Move file
                p.replace(dest)
                # Drop reason sidecar
                attempts = self._fail_counts.get(fpath, self._MAX_RETRIES)
                reason = (
                    f"quarantined: {time.strftime('%Y-%m-%dT%H:%M:%S')} "
                    f"(ingest exhausted {attempts} retries)\n"
                    f"reason: file completed ingest pipeline {attempts} time(s) "
                    f"but never produced library evidence — likely thin content, "
                    f"vision-LLM quality gate rejection, or LLM classification failure\n"
                    f"action: review and either re-drop after fixing OR delete\n"
                )
                try:
                    (dest.parent / f"{dest.name}.reason.txt").write_text(
                        reason, encoding="utf-8"
                    )
                except OSError:
                    pass
                # Sticky give-up: the file IS physically moved but the
                # destination is in the same vault subtree, AND the
                # quarantine subdir IS in our scan path (the watcher's
                # `_SKIP_DIRS` exclusion is name-only — `quarantine` is
                # not in the list). Also record the give-up on the
                # ORIGINAL inbox path so that if anything ever re-creates
                # a file there with the same hash, we still skip it.
                try:
                    dest_st = dest.stat()
                    self._mark_give_up(
                        str(dest),
                        snapshot_mtime=dest_st.st_mtime,
                        reason=f"quarantined after {attempts} retries",
                    )
                except OSError:
                    pass
                log.warning(
                    "Inbox watcher: quarantined %s after %d failed ingest cycles → %s",
                    p.name, attempts, dest,
                )
                return True
            except Exception:
                log.exception(
                    "Inbox watcher: physical quarantine of %s failed",
                    p.name,
                )
                return False

        # Root file — per Rule #1, never touch user's vault-root content.
        # Mark as known + snapshot stats so the watcher stops scanning it
        # AND will re-evaluate if user edits (mtime change). Same pattern
        # the existing exhaustion code at line 1148 uses.
        #
        # 2026-05-19 sticky give-up fix: also record an entry in
        # ``_gave_up_files`` so future cycles silently skip BEFORE the
        # ingest pipeline runs. Pre-fix, ``_known_files`` membership
        # didn't stop the give-up warning from firing every cycle —
        # the verify-against-library check still ran. Now the scan
        # itself drops the file via ``_is_give_up_active``.
        try:
            st = p.stat()
            self._known_files.add(fpath)
            self._known_mtimes[fpath] = st.st_mtime
            self._known_sizes[fpath] = st.st_size
            attempts = self._fail_counts.get(fpath, self._MAX_RETRIES)
            self._mark_give_up(
                fpath,
                snapshot_mtime=st.st_mtime,
                reason=f"root file gave up after {attempts} cycles",
            )
            log.warning(
                "Inbox watcher: root file %s gave up after %d failed cycles "
                "(file stays at vault root per Rule #1; edit it to retry)",
                p.name, attempts,
            )
            return True
        except OSError:
            log.exception(
                "Inbox watcher: stat failed for root file %s",
                p.name,
            )
            return False

    async def _quarantine_unsupported_files(self) -> list[str]:
        """Park unsupported / oversized files in ``library/unsupported/``.

        Runs at the start of every cycle. Drops a sidecar ``.reason.txt``
        next to each parked file so the user knows WHY it was skipped,
        and emits a medium-importance activity event through the KB
        service so the fact is visible in /decisions and the activity
        feed (Rule #13 — no silent user actions).
        """
        parked: list[str] = []

        # 1. Global inbox → infer target KB (single-KB → that one, else general)
        global_inbox = self._resolve("inbox")
        if global_inbox.is_dir():
            global_candidates: list[tuple[Path, str]] = []
            for f in global_inbox.iterdir():
                if not f.is_file() or f.name == ".gitkeep":
                    continue
                reason = self._unsupported_reason(f)
                if reason:
                    global_candidates.append((f, reason))
            if global_candidates:
                # ALWAYS route to the canonical default catch-all (`main`),
                # even when only one KB exists. The previous "if len == 1
                # use that one" shortcut leaked OneNote / clipped content
                # into dedicated KBs whose SCHEMA.md described unrelated
                # topics. Dedicated bases must NEVER receive auto-routed
                # content — only files dropped directly into <kb>/inbox/
                # belong there. `_default_kb_slug()` ensures `main` exists.
                kbs = self._kb.list_kbs()
                slug = self._default_kb_slug(kbs)
                for f, reason in global_candidates:
                    try:
                        dest = await self._kb.park_unsupported_file(slug, f, reason)
                        if dest:
                            parked.append(str(dest))
                    except Exception:
                        log.debug("Failed to park global inbox file %s", f.name, exc_info=True)

        # 2. Per-KB inboxes
        kb_dir = self._resolve("knowledge")
        if kb_dir.is_dir():
            for kb in kb_dir.iterdir():
                if not kb.is_dir():
                    continue
                kb_inbox = kb / "inbox"
                if not kb_inbox.is_dir():
                    continue
                for f in kb_inbox.iterdir():
                    if not f.is_file() or f.name == ".gitkeep":
                        continue
                    # Skip the quarantine subdir contents already handled elsewhere.
                    # Both the canonical visible name and the legacy dot name are
                    # excluded so a half-migrated vault behaves correctly.
                    if f.parent.name in (QUARANTINE_DIRNAME, QUARANTINE_LEGACY_DIRNAME):
                        continue
                    reason = self._unsupported_reason(f)
                    if reason:
                        try:
                            dest = await self._kb.park_unsupported_file(kb.name, f, reason)
                            if dest:
                                parked.append(str(dest))
                        except Exception:
                            log.debug("Failed to park KB inbox file %s/%s", kb.name, f.name, exc_info=True)

        return parked

    async def _do_check_and_ingest(self) -> list[str]:
        """Internal implementation of check_and_ingest (holds the lock)."""
        # Park unsupported / oversized inbox files BEFORE the scan so the
        # pipeline never sees them. Keeps the inbox clean and gives the
        # user a visible event instead of silent skip.
        try:
            await self._quarantine_unsupported_files()
        except Exception:
            log.exception("Inbox watcher: unsupported-file quarantine failed")

        # Phase A perf fix (2026-05-06): the FS scan + mtime detection
        # is heavy sync IO on a 1700-article vault (rglob across 3 evidence
        # dirs per KB). Running it on the event loop blocked /api/health for
        # 30-90s in production. Both jumps below run via asyncio.to_thread
        # so the loop stays responsive while the watcher does its work.
        current_files = await asyncio.to_thread(self._scan_all_raw)
        new_files = current_files - self._known_files

        # Detect known files whose content has changed (mtime differs).
        # This covers: user edits a file in Obsidian, or a file was ingested
        # while empty and now has content.  The KB ingest pipeline handles
        # updates (replaces old source summary + produced pages).
        modified_paths = await asyncio.to_thread(
            self._sync_detect_modifications,
            current_files & self._known_files,
        )
        for fpath in modified_paths:
            new_files.add(fpath)
            self._known_files.discard(fpath)

        # Filter out files that have exceeded retry limit — queue to persistent work queue
        exhausted = {f for f in new_files if self._fail_counts.get(f, 0) >= self._MAX_RETRIES}
        if exhausted:
            log.warning("Inbox watcher: %d files exceeded %d retries — queuing for persistent retry: %s",
                        len(exhausted), self._MAX_RETRIES,
                        ", ".join(Path(f).name for f in list(exhausted)[:5]))
            # Queue exhausted files to the persistent work queue (retries forever)
            if hasattr(self, '_work_queue') and self._work_queue:
                for fpath in exhausted:
                    try:
                        # Determine which KB this file belongs to
                        p = Path(fpath)
                        kb_prefix = str(self._resolve("knowledge"))
                        if fpath.startswith(kb_prefix):
                            rel = p.relative_to(self._resolve("knowledge"))
                            slug = rel.parts[0]
                        else:
                            slug = self._default_kb_slug(auto_create=False)
                        asyncio.create_task(self._work_queue.enqueue(
                            "ingest", {"slug": slug}, deduplicate=True,
                        ))
                    except Exception:
                        log.debug("Inbox watcher: failed to queue %s", fpath, exc_info=True)
            self._known_files |= exhausted  # treat as known so they stop appearing
            new_files -= exhausted

        if not new_files:
            # Nothing new — update full state. Phase A perf fix: state write
            # off the event loop so a slow disk doesn't block /api/health.
            self._known_files = current_files
            self._snapshot_file_stats(current_files)
            await asyncio.to_thread(self._save_state)
            return []

        # Limit per cycle to avoid blocking for minutes on large vaults.
        # Unprocessed files stay "new" and are picked up next cycle.
        max_per_cycle = self._max_per_cycle
        if len(new_files) > max_per_cycle:
            batch = set(sorted(new_files)[:max_per_cycle])
            deferred = new_files - batch
            log.info("Inbox watcher: %d new files, processing %d this cycle (%d deferred)",
                     len(new_files), len(batch), len(deferred))
            new_files = batch
        else:
            deferred = set()

        ingested = []

        # Group by location: inbox files, KB inbox files, root folder files
        inbox_new = []
        kb_new: dict[str, list[str]] = {}
        root_new: list[Path] = []

        inbox_prefix = str(self._resolve("inbox"))
        kb_prefix = str(self._resolve("knowledge"))

        for fpath in new_files:
            p = Path(fpath)
            fpath_str = str(p)
            if fpath_str.startswith(inbox_prefix):
                inbox_new.append(p.name)
            elif fpath_str.startswith(kb_prefix):
                # Extract KB slug
                try:
                    rel = p.relative_to(self._resolve("knowledge"))
                    slug = rel.parts[0]
                    kb_new.setdefault(slug, []).append(p.name)
                except (ValueError, IndexError):
                    pass
            else:
                # Root folder file — user's own content
                root_new.append(p)

        import shutil

        slugs_to_compile: set[str] = set()

        # Process inbox/ files (explicit drop zone — files get MOVED)
        if inbox_new:
            log.info("Inbox watcher: %d new files in inbox/: %s", len(inbox_new), ", ".join(inbox_new[:5]))
            try:
                kbs = self._kb.list_kbs()
                slug = self._default_kb_slug(kbs)

                kb_inbox = self._resolve(f"knowledge/{slug}/inbox")
                kb_inbox.mkdir(parents=True, exist_ok=True)
                for fname in inbox_new:
                    src = self._resolve("inbox") / fname
                    if not src.exists():
                        continue
                    dest = kb_inbox / fname
                    if dest.exists():
                        src.unlink()  # already in KB inbox
                    else:
                        shutil.move(str(src), str(dest))

                # Phase 1: enqueue to work queue (which dispatches via
                # agent in the background). Direct fallback only when
                # the work queue isn't wired (tests / minimal installs).
                result = await self._run_ingest_for_slug(slug, "watcher_inbox")
                ingested.extend(result.get("ingested", []))
                if result.get("ingested") or result.get("mutations", {}).get("vault_writes"):
                    slugs_to_compile.add(slug)
                if self._heartbeat:
                    n = len(result.get("ingested", [])) or result.get("mutations", {}).get("vault_writes", 0)
                    await self._heartbeat.record_pulse("automation", f"Auto-ingested {n} files from inbox/")
            except Exception as exc:
                log.exception("Inbox watcher: inbox ingest failed")
                for fname in inbox_new:
                    fpath = str(self._resolve("inbox") / fname)
                    self._fail_counts[fpath] = self._fail_counts.get(fpath, 0) + 1
                if self._heartbeat:
                    await self._heartbeat.record_pulse("error", f"Inbox ingest failed: {exc}")

        # Process root folder files (user's content — COPY to KB inbox via global inbox)
        # Single KB → route there.  Multiple KBs → default to "general".
        if root_new:
            log.info("Inbox watcher: %d new files in root folder (queued in inbox/)", len(root_new))
            try:
                global_inbox = self._resolve("inbox")
                global_inbox.mkdir(parents=True, exist_ok=True)
                copied = 0
                # 2026-05-01 fix C — track which source path produced each
                # destination filename in this cycle. When two sources share
                # a filename (e.g. 10 OneNote `Untitled page.md` files from
                # different sections), the second one would overwrite the
                # first under the old `dest = global_inbox / src.name`
                # pattern. Build a per-source-path destination name when a
                # collision is detected so all files reach the pipeline.
                _cycle_used_dest_names: set[str] = set()
                for src in root_new:
                    dest = self._resolve_unique_inbox_dest(
                        src, global_inbox, _cycle_used_dest_names,
                    )
                    _cycle_used_dest_names.add(dest.name)
                    # Always copy — overwrites stale version for modified files
                    shutil.copy2(str(src), str(dest))
                    copied += 1

                    # Copy sibling images referenced by markdown files so
                    # the ingest pipeline can resolve ![alt](image.png) and
                    # ![[Pasted image.png]] refs.  Without this, images
                    # clipped alongside .md files (e.g., by Obsidian Clipper)
                    # sit unreferenced in the source dir while their markdown
                    # arrives in the inbox with dead image links.
                    if src.suffix.lower() in (".md", ".txt", ".html"):
                        self._copy_sibling_images(src, global_inbox)

                if copied:
                    # ALWAYS route auto-detected root-folder content to the
                    # canonical default KB (`main`). The previous "if only
                    # one KB exists, use it" shortcut leaked unrelated
                    # content (e.g. OneNote imports about boats) into
                    # dedicated KBs (e.g. `news-about-dam-failures`) just
                    # because they were the only existing KB. Dedicated
                    # bases describe specific topics in their SCHEMA.md;
                    # they must NEVER receive auto-routed content from
                    # outside their own inbox. `_default_kb_slug()` ensures
                    # `main` exists.
                    kbs = self._kb.list_kbs()
                    slug = self._default_kb_slug(kbs)

                    kb_inbox = self._resolve(f"knowledge/{slug}/inbox")
                    kb_inbox.mkdir(parents=True, exist_ok=True)
                    # 2026-05-01 fix C — track which destination names we've
                    # used in the kb_inbox this cycle so the move step
                    # preserves all files (matches the resolved global-inbox
                    # names from the copy step above).
                    _kb_used_dest_names: set[str] = set()
                    for src in root_new:
                        # Replay the dest resolver to produce the SAME name
                        # the copy step used in global_inbox, so the move
                        # finds the right file.
                        gi_dest_name = self._dest_name_for_source(
                            src, _kb_used_dest_names,
                        )
                        _kb_used_dest_names.add(gi_dest_name)
                        gi_file = global_inbox / gi_dest_name
                        if gi_file.exists():
                            dest = kb_inbox / gi_dest_name
                            if dest.exists():
                                dest.unlink()  # remove stale version
                            shutil.move(str(gi_file), str(dest))
                    # Phase 1: enqueue to work queue. Direct fallback only
                    # when the work queue isn't wired.
                    result = await self._run_ingest_for_slug(slug, "watcher_root_folder")
                    ingested.extend(result.get("ingested", []))
                    if result.get("ingested") or result.get("mutations", {}).get("vault_writes"):
                        slugs_to_compile.add(slug)
                    if self._heartbeat:
                        n = len(result.get("ingested", [])) or result.get("mutations", {}).get("vault_writes", 0)
                        await self._heartbeat.record_pulse("automation", f"Auto-ingested {n} root files into KB {slug}")
            except Exception as exc:
                log.exception("Inbox watcher: root folder processing failed")
                for src in root_new:
                    self._fail_counts[str(src)] = self._fail_counts.get(str(src), 0) + 1
                if self._heartbeat:
                    await self._heartbeat.record_pulse("error", f"Root folder processing failed: {exc}")

        # Process per-KB inbox/ files
        for slug, files in kb_new.items():
            log.info("Inbox watcher: %d new files in knowledge/%s/inbox/: %s", len(files), slug, ", ".join(files[:5]))
            try:
                # Phase 1: enqueue to work queue. Direct fallback only when
                # the work queue isn't wired.
                result = await self._run_ingest_for_slug(slug, "watcher_kb_inbox")
                ingested.extend(result.get("ingested", []))
                if result.get("ingested") or result.get("mutations", {}).get("vault_writes"):
                    slugs_to_compile.add(slug)
                if self._heartbeat:
                    await self._heartbeat.record_pulse("automation", f"Auto-ingested {len(files)} files into KB {slug}")
            except Exception:
                log.exception("Inbox watcher: KB %s ingest failed", slug)
                for fname in files:
                    fpath = str(self._resolve(f"knowledge/{slug}/inbox") / fname)
                    self._fail_counts[fpath] = self._fail_counts.get(fpath, 0) + 1

        # Compile once per KB after all ingests are done.
        # Bound with a timeout — local models can hang indefinitely.
        # Track per-KB compile size for the editor-quality-pass burst
        # trigger (Option B) — heavy batches deserve immediate quality
        # review, not a 24h cadence wait.
        compile_sizes: dict[str, int] = {}
        for slug in slugs_to_compile:
            try:
                compile_result = await asyncio.wait_for(self._kb.compile_wiki(slug), timeout=300)
                if isinstance(compile_result, dict):
                    compile_sizes[slug] = int(compile_result.get("count", 0))
            except TimeoutError:
                log.warning("Inbox watcher: compile_wiki timed out for KB %s after 5min", slug)
            except Exception:
                log.exception("Inbox watcher: compile_wiki failed for KB %s", slug)

        # Auto-lint (structural-only) after compile (Option A, shipped 2026-04-28).
        # Pure-engine deterministic dedup + orphan + broken-link detection —
        # no LLM, no hallucination risk that motivated removing the
        # editor-delegation path. Surfaces residual duplicates that the
        # engine-level dedup can't see (cross-pass slug collisions, orphan
        # articles whose wikilinks broke after a rename, missing frontmatter).
        # Each issue lands as an activity event the user sees in the UI.
        # Failures NEVER block the watcher cycle.
        for slug in slugs_to_compile:
            try:
                lint_result = await asyncio.wait_for(
                    self._kb.lint(slug, structural_only=True), timeout=60,
                )
                issue_count = lint_result.get("issue_count", 0)
                if issue_count > 0:
                    log.info(
                        "Inbox watcher: auto-lint found %d structural issue(s) in KB %s",
                        issue_count, slug,
                    )
                # ``kb.lint()`` itself emits ``lint_completed`` activity
                # events with issue_count + medium importance when issues
                # exist — surfaces in the UI without duplicate event spam
                # from the watcher. Heartbeat pulse marks the watcher's
                # cycle so /api/heartbeat shows the auto-lint cadence.
                if self._heartbeat:
                    await self._heartbeat.record_pulse(
                        "automation",
                        f"Auto-lint KB {slug}: {issue_count} issue(s)",
                    )
            except TimeoutError:
                log.warning("Inbox watcher: auto-lint timed out for KB %s after 60s", slug)
            except Exception:
                log.exception("Inbox watcher: auto-lint failed for KB %s", slug)

        # ── Editor quality pass — burst trigger (Option B follow-up) ──
        # The heartbeat fires the full editor pass on a 24h cadence
        # (default). But a single compile pass producing many articles
        # deserves immediate quality review — not a day-long wait.
        # When a KB's compile produced >= on_compile_threshold articles
        # (default 5), kick off the full pass for THAT KB now,
        # bypassing cadence. Reads threshold from the same skill YAML
        # the heartbeat uses; non-blocking.
        try:
            skill_loader = getattr(self._kb, "_skill_loader", None)
            cfg = (
                skill_loader.load_skill_config_file(
                    "editor-quality-pass", "schedule.yaml",
                ) or {}
            ) if skill_loader else {}
            if cfg.get("enabled", True):
                threshold = int(cfg.get("on_compile_threshold", 5))
                per_kb_timeout = float(cfg.get("per_kb_timeout_seconds", 180))
                include_reflect = bool(cfg.get("include_reflect", True))
                include_consolidate = bool(cfg.get("include_consolidate", True))
                if threshold > 0:
                    burst_kbs = [
                        slug for slug, count in compile_sizes.items()
                        if count >= threshold
                    ]
                    for slug in burst_kbs:
                        log.info(
                            "Inbox watcher: compile burst (%d articles) → editor quality pass for KB %s",
                            compile_sizes[slug], slug,
                        )
                        try:
                            await asyncio.wait_for(
                                self._kb.lint(slug), timeout=per_kb_timeout,
                            )
                        except TimeoutError:
                            log.warning("Inbox watcher: burst lint timed out for KB %s", slug)
                        except Exception:
                            log.debug("Inbox watcher: burst lint failed for KB %s", slug, exc_info=True)
                        if include_reflect:
                            try:
                                await asyncio.wait_for(
                                    self._kb.reflect(slug), timeout=per_kb_timeout,
                                )
                            except TimeoutError:
                                log.warning("Inbox watcher: burst reflect timed out for KB %s", slug)
                            except Exception:
                                log.debug("Inbox watcher: burst reflect failed for KB %s", slug, exc_info=True)
                        if include_consolidate and hasattr(self._kb, "consolidate_articles"):
                            try:
                                await asyncio.wait_for(
                                    self._kb.consolidate_articles(slug), timeout=per_kb_timeout,
                                )
                            except TimeoutError:
                                log.warning("Inbox watcher: burst consolidate timed out for KB %s", slug)
                            except Exception:
                                log.debug("Inbox watcher: burst consolidate failed for KB %s", slug, exc_info=True)
        except Exception:
            log.debug("Inbox watcher: editor-quality-pass burst trigger failed", exc_info=True)

        if ingested:
            log.info("Inbox watcher: auto-ingested %d files total", len(ingested))

        # Mark processed files as known — but ONLY if they actually left the
        # inbox (moved to library) or were successfully ingested.  Files that
        # are still sitting in an inbox/ dir after a failed ingest should stay
        # "unknown" so they're retried on the next cycle or after restart.
        # Verify EVERY file before marking it known. A file becomes "known"
        # only when there's hard evidence it was actually processed — either
        # it appears in this cycle's ``ingested`` list, OR a matching library
        # entry exists in some KB.
        #
        # The previous logic had a silent-failure class for ROOT files:
        # files outside any ``inbox/`` (e.g. ``<vault>/OneNote/.../X.md``
        # imported by a plugin) fell through to a wholesale "add to known"
        # branch with NO ingest verification. The watcher copies the root
        # file to a KB inbox during its cycle; that COPY then needs to flow
        # through ingest to produce a library entry. If ingest fails (LLM
        # timeout, contract block, anything), the root file STILL got marked
        # known — silently — and the watcher would never re-attempt it.
        #
        # Symptom (production-bug class observed 2026-04-28): user imports
        # 73 OneNote pages, watcher copies them, ingest fails for any
        # reason, watcher marks all 73 root files known. Next cycle: zero
        # new files. ``done_today_count`` stays at 0 forever. The user
        # sees a ``queued_count: 179`` from on-disk filesystem scan but
        # nothing ever ingests. No log line, no event, no diagnostic.
        #
        # The user's architectural rule (CLAUDE.md Rule #14, kb robustness
        # 15d): NEVER fail silently. This block is the canonical write-side
        # of that rule for the watcher.
        # Phase A perf fix (2026-05-06): the bookkeeping pass below was the
        # dominant event-loop block. Per file in (current_files - deferred)
        # it called _has_library_evidence_in_any_kb which rglob()'s over every
        # KB's library + 2 quarantine dirs — O(N²) sync IO on a 1700-article
        # vault. Live measurement: blocked /api/health for 30-90s per cycle.
        # Extracted into _sync_compute_known_set + run via asyncio.to_thread
        # so the event loop stays responsive while the FS walk happens.
        successfully_known, unverified_skipped, unverified_paths = await asyncio.to_thread(
            self._sync_compute_known_set,
            current_files,
            deferred,
            ingested,
        )

        # Task #5 (2026-05-19 night) — dedup-rescue. Files that ingest
        # CORRECTLY deduplicated (same content_hash as an existing
        # library copy) cannot show stem/name evidence in library/ —
        # the library copy lives under a DIFFERENT filename. Without
        # this rescue, every deduped file (substack newsletter hero
        # gifs were the canonical case) accumulates fail counts and
        # gets quarantined falsely after 5 cycles. The rescue queries
        # the decision_log for a recent ingest_file row with
        # contract_result='skipped' and a dedup skip_reason; matches
        # are moved from unverified → successfully_known so the
        # fail-counter loop below skips them.
        #
        # PURELY ADDITIVE: a missing/broken decision logger leaves
        # unverified_paths unchanged (rescued = empty set), so the
        # legacy quarantine-after-5-retries path still fires for
        # genuine failures. The rescue can never promote a real
        # failure to success.
        if unverified_paths:
            try:
                rescued = await self._rescue_dedup_successes(unverified_paths)
            except Exception:
                # Belt-and-braces — even though _rescue_dedup_successes
                # is fail-soft internally, wrap the awaiter too so a
                # surprise (event loop closing during shutdown,
                # coroutine cancellation, etc.) can't break the cycle.
                log.debug("dedup-rescue pass failed", exc_info=True)
                rescued = set()
            if rescued:
                for fpath in rescued:
                    unverified_paths.discard(fpath)
                    successfully_known.add(fpath)
                    # Also clear any prior fail counter so a future
                    # genuine-fail cycle starts from zero, not from
                    # the count we'd accumulated before realizing
                    # this file was actually being deduped correctly.
                    self._fail_counts.pop(fpath, None)
                log.info(
                    "Inbox watcher: rescued %d deduplicated file(s) — "
                    "ingest correctly handled them as content duplicates",
                    len(rescued),
                )
                if self._activity is not None:
                    try:
                        self._activity.log(
                            category="knowledge",
                            action="inbox_dedup_rescued",
                            summary=(
                                f"Rescued {len(rescued)} file(s) from "
                                f"false-quarantine — ingest deduped them correctly"
                            ),
                            details={
                                "rescued_count": len(rescued),
                                "examples": sorted(
                                    Path(p).name for p in list(rescued)[:5]
                                ),
                            },
                            importance="low",
                        )
                    except Exception:
                        log.debug(
                            "inbox_dedup_rescued event emit failed",
                            exc_info=True,
                        )

        # 2026-05-12 give-up fix for stuck files. Files that completed
        # ingest without producing library evidence (silent-fail paths)
        # used to loop forever — they never raised, so the existing
        # `except` blocks at lines 1253/1339/1358 never incremented
        # ``_fail_counts``, and the exhaustion logic at line 1148 never
        # fired. Now: increment per-path on every silent-fail cycle.
        # When count reaches MAX_RETRIES, ``_quarantine_unverified_file``
        # either physically moves the file to ``<inbox>/quarantine/`` (for
        # inbox copies) or marks it ``_known_files`` + snapshots stats
        # (for root files we can't move per Rule #1).
        quarantined_this_cycle: list[str] = []
        for fpath in unverified_paths:
            self._fail_counts[fpath] = self._fail_counts.get(fpath, 0) + 1
            if self._fail_counts[fpath] >= self._MAX_RETRIES:
                try:
                    if await asyncio.to_thread(self._quarantine_unverified_file, fpath):
                        quarantined_this_cycle.append(fpath)
                        successfully_known.add(fpath)  # stop scanning
                except Exception:
                    log.exception(
                        "Inbox watcher: quarantine of stuck file %s failed",
                        Path(fpath).name,
                    )

        if quarantined_this_cycle and self._activity is not None:
            try:
                self._activity.log(
                    category="knowledge",
                    action="inbox_quarantined_after_retries",
                    summary=(
                        f"Quarantined {len(quarantined_this_cycle)} stuck file(s) "
                        f"after {self._MAX_RETRIES} failed ingest cycles"
                    ),
                    details={
                        "max_retries": self._MAX_RETRIES,
                        "count": len(quarantined_this_cycle),
                        "files": [Path(p).name for p in quarantined_this_cycle[:10]],
                    },
                    importance="high",
                )
            except Exception:
                log.debug("Inbox watcher: activity log emit failed", exc_info=True)

        # ── Stall detection moved to Phase 3+4 (2026-04-30) ──
        # Pre-Phase-1, this watcher had a `_stall_streak` detector that
        # fired ``watcher_stalled`` HIGH events when ``not ingested and
        # unverified_skipped > 0`` for 3+ consecutive cycles. After Phase
        # 1 made the watcher enqueue-only (work queue handles dispatch
        # async), the ``ingested`` list is ALWAYS empty in production.
        # The detector fired EVERY cycle that had files in the queue —
        # producing the false-positive `watcher_stalled` storm Wolf saw on
        # 2026-04-30 (17 events in 12 hours that didn't reflect a real
        # additional failure mode beyond what the work queue / dispatch
        # state already tracked).
        #
        # Replaced by:
        #   - Phase 3 dispatch state machine (active → escalating → dormant)
        #     emits ``dispatch_state_dormant`` HIGH event on actual give-up.
        #   - Phase 4 pipeline health (``GET /api/pipeline/summary``)
        #     surfaces ``health.state="stalled"`` when the watcher is
        #     running, queue has backlog, and no successful ingest in 1h+
        #     (or never).
        # Both surfaces are decision-log-grounded (count successful
        # decisions, not synchronous return values), so they tell the
        # truth post-Phase-1.
        #
        # ``unverified_skipped`` counter is kept (next session may emit a
        # LOW-importance progress event for diagnostics — but never HIGH,
        # never per-cycle).
        _ = unverified_skipped  # suppress unused-var (semantic doc above)

        self._known_files = successfully_known
        self._snapshot_file_stats(successfully_known)
        # Phase A perf fix: state write off the event loop.
        await asyncio.to_thread(self._save_state)

        # Record cycle stats for observability
        import time
        self._last_cycle_at = time.time()
        self._last_cycle_ingested = len(ingested)
        self._last_cycle_deferred = len(deferred)
        self._cycle_count += 1

        # ── Detect deletions, renames, and moves in root folder ──
        if self._root_dir and self._root_dir != self._vault_dir:
            await self._detect_root_changes()

        return ingested

    async def _detect_root_changes(self) -> None:
        """Detect deleted, renamed, or moved files in the root folder.

        Uses content hashing (like git rename detection):
        - File gone from known path → search all files for same hash
        - Hash found at new path → renamed/moved → update source reference
        - Hash not found anywhere → truly deleted → mark wiki article as stale
        """
        import hashlib

        # Build current state: path → hash for all root files
        current_hashes: dict[str, str] = {}
        for f in self._root_dir.rglob("*"):
            if not f.is_file():
                continue
            rel_parts = f.relative_to(self._root_dir).parts
            if any(part in self._SKIP_DIRS or part.startswith(".") for part in rel_parts):
                continue
            if f.suffix.lower() in (".md", ".txt", ".html", ".pdf", ".png", ".jpg", ".jpeg", ".csv"):
                try:
                    content_hash = hashlib.md5(f.read_bytes()[:5000]).hexdigest()[:12]
                    current_hashes[str(f)] = content_hash
                except Exception:
                    pass

        # First run — just record state, don't detect changes
        if not self._root_file_hashes:
            self._root_file_hashes = current_hashes
            return

        # Find disappeared files
        old_paths = set(self._root_file_hashes.keys())
        new_paths = set(current_hashes.keys())
        disappeared = old_paths - new_paths

        if not disappeared:
            self._root_file_hashes = current_hashes
            return

        # Build reverse lookup: hash → current path
        hash_to_path: dict[str, str] = {}
        for path, h in current_hashes.items():
            hash_to_path[h] = path

        # Check each disappeared file
        for old_path in disappeared:
            old_hash = self._root_file_hashes[old_path]
            old_name = Path(old_path).name

            if old_hash in hash_to_path:
                # Found at a different path — renamed or moved
                new_path = hash_to_path[old_hash]
                new_name = Path(new_path).name
                log.info("Root file moved/renamed: %s → %s", old_name, new_name)
                # Update source reference in wiki (best effort)
                try:
                    self._update_source_reference(old_name, new_name, new_path)
                except Exception:
                    log.debug("Failed to update source reference for %s", old_name)
            else:
                # Hash not found anywhere — truly deleted
                log.info("Root file deleted: %s — marking wiki article as stale", old_name)
                try:
                    self._mark_article_stale(old_name)
                except Exception:
                    log.debug("Failed to mark article stale for %s", old_name)

        self._root_file_hashes = current_hashes

    def _mark_article_stale(self, filename: str) -> None:
        """Mark wiki source article as stale when source file is deleted."""
        import re
        slug = Path(filename).stem.lower().replace(" ", "-")

        # Search across all KBs for matching source page
        kb_dir = self._resolve("knowledge")
        if not kb_dir.is_dir():
            return

        for kb in kb_dir.iterdir():
            if not kb.is_dir():
                continue
            source_page = kb / "wiki" / "sources" / f"{slug}.md"
            if source_page.exists():
                content = source_page.read_text(encoding="utf-8")
                # Update status to stale
                if "status: verified" in content or "status: draft" in content:
                    content = re.sub(
                        r"status:\s*\w+",
                        "status: stale",
                        content, count=1,
                    )
                    # Add deletion note
                    content += (
                        f"\n\n> **Source deleted**: The original file `{filename}` "
                        f"was removed from the vault. This article may be outdated.\n"
                    )
                    source_page.write_text(content, encoding="utf-8")
                    log.info("Marked as stale: %s in KB %s", slug, kb.name)

    def _update_source_reference(self, old_name: str, new_name: str, new_path: str) -> None:
        """Update wiki source references when a file is renamed or moved."""
        kb_dir = self._resolve("knowledge")
        if not kb_dir.is_dir():
            return

        old_slug = Path(old_name).stem.lower().replace(" ", "-")
        new_slug = Path(new_name).stem.lower().replace(" ", "-")

        for kb in kb_dir.iterdir():
            if not kb.is_dir():
                continue
            source_page = kb / "wiki" / "sources" / f"{old_slug}.md"
            if source_page.exists():
                content = source_page.read_text(encoding="utf-8")
                # Update filename references
                content = content.replace(old_name, new_name)
                # Rename the file if slug changed
                if old_slug != new_slug:
                    new_page = kb / "wiki" / "sources" / f"{new_slug}.md"
                    source_page.rename(new_page)
                    new_page.write_text(content, encoding="utf-8")
                    log.info("Renamed source page: %s → %s in KB %s", old_slug, new_slug, kb.name)
                else:
                    source_page.write_text(content, encoding="utf-8")

    async def _delegate_to_librarian(self, task: str) -> str | None:
        """Try to delegate KB work to the Librarian subagent. Returns result or None."""
        if not self._orchestrator:
            return None
        try:
            result = await self._orchestrator.dispatch(
                agent_name="librarian",
                task=task,
                context="Triggered by inbox watcher automation.",
            )
            log.info("Librarian completed: %s", result.content[:100])
            return result.content
        except Exception:
            log.debug("Librarian delegation failed, falling back to direct KB call", exc_info=True)
            return None

    async def _delegate_to_editor(self, task: str) -> str | None:
        """Try to delegate quality/reflection work to the Editor subagent."""
        if not self._orchestrator:
            return None
        try:
            result = await self._orchestrator.dispatch(
                agent_name="editor",
                task=task,
                context="Triggered by post-compile reflection.",
            )
            log.info("Editor completed: %s", result.content[:100])
            return result.content
        except Exception:
            log.debug("Editor delegation failed", exc_info=True)
            return None

    async def _loop(self) -> None:
        while self._running:
            try:
                await self.check_and_ingest()
                self._last_error = ""
            except asyncio.CancelledError:
                break
            except Exception as exc:
                self._last_error = f"{type(exc).__name__}: {exc}"
                log.exception("Inbox watcher error")

            # Event-driven wait: wake immediately on a filesystem event,
            # otherwise fall through to the poll interval as a safety net.
            # If watchdog isn't running, _event_drain is never set and this
            # behaves exactly like the old `asyncio.sleep(interval)`.
            try:
                import time
                await asyncio.wait_for(
                    self._event_drain.wait(), timeout=self._interval,
                )
                # Woken by an event — record and clear for next cycle.
                # Small debounce so a burst of events produces one cycle.
                self._last_wake_at = time.time()
                self._wake_count += 1
                self._event_drain.clear()
                await asyncio.sleep(1.0)
            except TimeoutError:
                # Poll interval elapsed — normal tick, no events.
                pass
            except asyncio.CancelledError:
                break
