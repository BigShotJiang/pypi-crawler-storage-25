"""Career inbox watcher — auto-extracts job listings from files dropped
into ``agntspace-career/inbox/``.

Phase 2.5 (2026-05-19 night). Mirrors ``FinanceInboxWatcher`` shape: per-cycle
poll loop with event-driven wake-up, 5s settle-time, ``_MAX_RETRIES = 5``,
correlation-scope discipline (``career-watcher-*``), state persisted to
``<vault>/agntspace/system/.career-inbox-watcher-state.json``, quarantine
to ``agntspace-career/inbox/quarantine/`` after exhausted retries.

Pause flag is shared with RawWatcher + FinanceInboxWatcher
(``[watcher].paused`` in ``config.toml``) — one switch covers every
inbox watcher because "automatic ingestion" is the user's mental model.

Activity events (Rule 13):
- ``user/career_listing_imported`` (medium) — successful listing created
- ``user/career_listing_import_failed`` (medium) — extraction insufficient (will retry)
- ``user/career_listing_quarantined`` (high) — exhausted retries, parked
- ``user/career_unsupported_parked`` (medium) — wrong file type / oversized

Cadence knob: ``[watcher].career_interval_seconds`` (default 30s).

Successfully-extracted files move themselves out of the inbox into
``agntspace-career/library/YYYY-MM/<slug>{ext}`` so the user has the
original artifact attached to the listing for the application phase.
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import time
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agntspace.activity.logger import ActivityLogger
    from agntspace.agent.agent import Agent
    from agntspace.career.service import CareerService
    from agntspace.skills.loader import SkillLoader
    from agntspace.vault.paths import VaultPaths

log = logging.getLogger(__name__)


# Supported file types — the surface the JD extractor structurally
# accepts. Mirrors ``career.jd_extract._SUPPORTED_EXTS`` (single source
# of truth lives there). ``arch:deterministic`` because it's the
# capability surface of the import pipeline.
_SUPPORTED_EXTS: frozenset[str] = frozenset({  # arch:deterministic — JD extractor capability surface; mirrors career.jd_extract._SUPPORTED_EXTS
    ".pdf", ".txt", ".md", ".html", ".htm",
})

# Visible name (matches RawWatcher.QUARANTINE_DIRNAME +
# FinanceInboxWatcher._QUARANTINE_DIRNAME). Quarantined drops are USER
# content, not bookkeeping — visible name means user sees them in their
# file explorer and can restore manually.
_QUARANTINE_DIRNAME: str = "quarantine"


class CareerInboxWatcher:
    """Watches ``agntspace-career/inbox/`` for new JD drops to import."""

    # How many failed attempts before parking a file. Same threshold as
    # RawWatcher + FinanceInboxWatcher.
    _MAX_RETRIES = 5

    # Settle-time + size caps.
    _SETTLE_SECONDS = 5
    # 50 MB cap matches the receipt-pdf file-type spec — covers scanned
    # multi-page PDFs. Anything bigger is almost certainly NOT a JD.
    _MAX_FILE_BYTES = 50 * 1024 * 1024

    def __init__(
        self,
        vault_paths: VaultPaths,
        career_service: CareerService,
        agent: Agent | None,
        skill_loader: SkillLoader | None = None,
        *,
        check_interval: int = 30,
        settings_service: object | None = None,
        activity_logger: ActivityLogger | None = None,
    ) -> None:
        self._paths = vault_paths
        self._career = career_service
        self._agent = agent
        self._skill_loader = skill_loader
        self._interval = max(5, int(check_interval))  # floor 5s — never busy-loop
        self._settings_service = settings_service
        self._activity = activity_logger
        # Background task + run flag.
        self._task: asyncio.Task | None = None  # type: ignore[type-arg]
        self._running = False
        # File state tracking.
        self._fail_counts: dict[str, int] = {}
        self._known_mtimes: dict[str, float] = {}
        # Concurrency guard — one cycle at a time.
        self._ingesting = False
        # Event-driven wake-up.
        self._event_drain: asyncio.Event = asyncio.Event()
        # Observability fields.
        self._last_cycle_at: float = 0.0
        self._last_cycle_imported: int = 0
        self._last_cycle_failed: int = 0
        self._last_cycle_quarantined: int = 0
        self._last_error: str = ""
        self._cycle_count: int = 0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._fail_counts, self._known_mtimes = self._load_state()
        self._task = asyncio.create_task(self._run())
        log.debug(
            "Career inbox watcher started (interval: %ds, %d failed-files tracked)",
            self._interval, len(self._fail_counts),
        )

    def stop(self) -> None:
        self._running = False
        if self._task is not None:
            self._task.cancel()
            self._task = None

    def trigger(self) -> None:
        """Wake the loop immediately. Safe to call from any thread."""
        try:
            self._event_drain.set()
        except Exception:
            log.debug("trigger: could not set drain event", exc_info=True)

    async def _run(self) -> None:
        """Initial settle + startup catchup + steady loop."""
        await asyncio.sleep(5)  # let other services initialize
        try:
            imported = await self.check_and_import()
            if imported:
                log.info(
                    "Career inbox watcher: startup import processed %d listing(s)",
                    len(imported),
                )
        except Exception:
            log.exception("Career inbox watcher: startup import failed")
        await self._loop()

    async def _loop(self) -> None:
        """Steady-state poll loop with event-drain waker."""
        while self._running:
            try:
                # Wake on either timer OR external trigger.
                try:
                    await asyncio.wait_for(
                        self._event_drain.wait(), timeout=self._interval,
                    )
                except TimeoutError:
                    pass
                else:
                    self._event_drain.clear()
                if not self._running:
                    return
                await self.check_and_import()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("Career inbox watcher: cycle failed")
                await asyncio.sleep(self._interval)

    # ------------------------------------------------------------------
    # Pause + state persistence
    # ------------------------------------------------------------------
    def is_paused(self) -> bool:
        """True when the user has paused automatic ingestion via Settings.

        Reads ``[watcher].paused`` — same flag as RawWatcher +
        FinanceInboxWatcher. One switch covers every inbox watcher.
        Defaults False (running).
        """
        svc = self._settings_service
        if svc is None:
            return False
        try:
            return bool(svc.get_value("watcher", "paused", False))
        except Exception:
            return False

    @property
    def _state_path(self) -> Path:
        try:
            return self._paths.resolve("system") / ".career-inbox-watcher-state.json"
        except Exception:
            return Path(".career-inbox-watcher-state.json")

    def _load_state(self) -> tuple[dict[str, int], dict[str, float]]:
        """Load fail counts + known mtimes. Drop entries for missing files."""
        try:
            p = self._state_path
            if p.exists():
                data = json.loads(p.read_text(encoding="utf-8"))
                fails_raw = data.get("fail_counts", {})
                mtimes_raw = data.get("known_mtimes", {})
                fails = {
                    k: int(v) for k, v in fails_raw.items()
                    if isinstance(v, (int, float)) and Path(k).exists()
                }
                mtimes = {
                    k: float(v) for k, v in mtimes_raw.items()
                    if isinstance(v, (int, float)) and k in fails
                }
                return fails, mtimes
        except Exception:
            log.debug("Could not load career watcher state, starting fresh", exc_info=True)
        return {}, {}

    def _save_state(self) -> None:
        try:
            p = self._state_path
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(
                json.dumps({
                    "fail_counts": self._fail_counts,
                    "known_mtimes": self._known_mtimes,
                }),
                encoding="utf-8",
            )
        except Exception:
            log.debug("Could not save career watcher state", exc_info=True)

    # ------------------------------------------------------------------
    # Observability
    # ------------------------------------------------------------------
    def get_status(self) -> dict:
        """Return current state for the dashboard / debugging."""
        now = time.time()
        state_path = self._state_path
        state_exists = state_path.is_file()
        state_mtime = state_path.stat().st_mtime if state_exists else 0
        quarantine_count = 0
        try:
            qdir = self._paths.resolve(f"career/inbox/{_QUARANTINE_DIRNAME}")
            if qdir.is_dir():
                quarantine_count = sum(
                    1 for entry in qdir.iterdir()
                    if entry.is_file() and not entry.name.endswith(".reason.txt")
                )
        except Exception:
            pass
        return {
            "running": self._running,
            "paused": self.is_paused(),
            "interval_seconds": self._interval,
            "fail_counts": sum(self._fail_counts.values()),
            "fail_tracked": len(self._fail_counts),
            "quarantine_count": quarantine_count,
            "cycle_count": self._cycle_count,
            "last_cycle_at": self._last_cycle_at,
            "last_cycle_seconds_ago": (now - self._last_cycle_at) if self._last_cycle_at else None,
            "last_cycle_imported": self._last_cycle_imported,
            "last_cycle_failed": self._last_cycle_failed,
            "last_cycle_quarantined": self._last_cycle_quarantined,
            "last_error": self._last_error,
            "state_file": str(state_path),
            "state_file_exists": state_exists,
            "state_file_mtime": state_mtime,
        }

    # ------------------------------------------------------------------
    # Scan + import
    # ------------------------------------------------------------------
    def _scan_inbox(self) -> list[Path]:
        """Return career/inbox/ files ready for import.

        Filters: ``.gitkeep``, hidden dotfiles, quarantine subdir,
        wrong extension, 0-byte, oversized, too-young (settle).
        """
        try:
            inbox = self._paths.resolve("career/inbox")
        except Exception:
            return []
        if not inbox.is_dir():
            return []
        now = time.time()
        out: list[Path] = []
        try:
            for f in inbox.iterdir():
                if not f.is_file():
                    continue
                if f.name == ".gitkeep" or f.name.startswith("."):
                    continue
                if f.suffix.lower() not in _SUPPORTED_EXTS:
                    continue
                try:
                    st = f.stat()
                except OSError:
                    continue
                if st.st_size == 0:
                    continue
                if st.st_size > self._MAX_FILE_BYTES:
                    log.debug(
                        "Career watcher: skipping oversized file (%d bytes): %s",
                        st.st_size, f.name,
                    )
                    continue
                if now - st.st_mtime < self._SETTLE_SECONDS:
                    continue
                out.append(f)
        except OSError:
            return []
        return out

    async def check_and_import(self) -> list[str]:
        """Scan the career inbox + import each JD drop.

        Returns list of slugs successfully created. Skipped/quarantined/
        failed files do NOT appear in the return list.
        """
        if self.is_paused():
            log.debug("Career watcher: paused via Settings, skipping cycle")
            return []
        if self._ingesting:
            log.debug("Career watcher: cycle already in progress, skipping")
            return []
        self._ingesting = True
        try:
            from agntspace.activity.decisions import (
                correlation_scope,
                new_correlation_id,
            )
            with correlation_scope(new_correlation_id("career-watcher")):
                return await self._do_check_and_import()
        finally:
            self._ingesting = False

    async def _do_check_and_import(self) -> list[str]:
        """Internal cycle body — caller holds the concurrency lock."""
        # Park unsupported files BEFORE the main scan.
        try:
            await self._park_unsupported_files()
        except Exception:
            log.exception("Career watcher: unsupported-file park failed")

        files = self._scan_inbox()
        imported_slugs: list[str] = []
        failed_count = 0
        quarantined_count = 0
        try:
            for path in files:
                fpath = str(path)
                attempts = self._fail_counts.get(fpath, 0)
                if attempts >= self._MAX_RETRIES:
                    if await self._quarantine(path, attempts):
                        quarantined_count += 1
                        self._fail_counts.pop(fpath, None)
                        self._known_mtimes.pop(fpath, None)
                    continue

                # Run the JD extraction.
                slug = await self._import_one(path)
                if slug:
                    imported_slugs.append(slug)
                    self._fail_counts.pop(fpath, None)
                    self._known_mtimes.pop(fpath, None)
                else:
                    failed_count += 1
                    self._fail_counts[fpath] = attempts + 1
                    try:
                        self._known_mtimes[fpath] = path.stat().st_mtime
                    except OSError:
                        pass
        finally:
            self._cycle_count += 1
            self._last_cycle_at = time.time()
            self._last_cycle_imported = len(imported_slugs)
            self._last_cycle_failed = failed_count
            self._last_cycle_quarantined = quarantined_count
            self._save_state()
        return imported_slugs

    async def _import_one(self, path: Path) -> str:
        """Extract + create one listing from ``path``.

        Returns the created slug on success, empty string on failure.
        Emits activity events for both outcomes. Moves the file out of
        the inbox on success (to ``career/library/YYYY-MM/<slug>{ext}``).
        """
        try:
            from agntspace.career.jd_extract import extract_job_from_path
        except Exception:
            log.exception("Career watcher: failed to import jd_extract module")
            return ""

        try:
            job = await extract_job_from_path(
                path,
                agent=self._agent,
                skill_loader=self._skill_loader,
            )
        except Exception as exc:
            log.exception("Career watcher: extraction crashed for %s", path.name)
            self._last_error = f"crash: {exc}"
            self._emit_activity(
                action="career_listing_import_failed",
                summary=f"JD import crashed for {path.name}: {exc}",
                details={
                    "filename": path.name,
                    "error": str(exc),
                    "via": "watcher",
                },
                importance="medium",
            )
            return ""

        if not job.has_minimum_fields:
            self._last_error = "extraction_insufficient"
            self._emit_activity(
                action="career_listing_import_failed",
                summary=(
                    f"JD extraction insufficient for {path.name} "
                    f"(company={job.company!r}, role={job.role!r})"
                ),
                details={
                    "filename": path.name,
                    "extracted_company": job.company,
                    "extracted_role": job.role,
                    "via": "watcher",
                    "reason": "extraction_insufficient",
                },
                importance="medium",
            )
            return ""

        # Create the listing.
        try:
            result = self._career.create_listing(**job.to_listing_kwargs())
        except Exception as exc:
            log.exception("Career watcher: create_listing failed for %s", path.name)
            self._last_error = f"create_failed: {exc}"
            self._emit_activity(
                action="career_listing_import_failed",
                summary=f"JD listing creation failed for {path.name}: {exc}",
                details={
                    "filename": path.name,
                    "error": str(exc),
                    "via": "watcher",
                    "reason": "create_failed",
                },
                importance="medium",
            )
            return ""

        slug = result.get("slug", "") if isinstance(result, dict) else ""

        # Move the original file into career/library/YYYY-MM/<slug>{ext}.
        attached_path = self._attach_to_library(path, slug)

        self._emit_activity(
            action="career_listing_imported",
            summary=(
                f"Imported JD: {job.company} — {job.role} "
                f"({path.name} → {slug})"
            ),
            details={
                "filename": path.name,
                "slug": slug,
                "company": job.company,
                "role": job.role,
                "location": job.location,
                "source_url": job.source_url,
                "attached_path": attached_path,
                "via": "watcher",
            },
            importance="medium",
        )
        return slug

    def _attach_to_library(self, path: Path, slug: str) -> str:
        """Move the inbox file into ``career/library/YYYY-MM/<slug>{ext}``.

        Returns the new logical path on success, empty string on
        failure. Failure is logged but never raises — the listing
        markdown is already written; losing the attachment is a
        warning, not a fatal error.

        Collision-safe: numeric suffix on filename collision so a
        re-imported file with the same slug doesn't clobber the prior
        attachment.
        """
        try:
            today = datetime.now().strftime("%Y-%m")
            lib_dir = self._paths.resolve(f"career/library/{today}")
            lib_dir.mkdir(parents=True, exist_ok=True)
            ext = path.suffix.lower()
            dest = lib_dir / f"{slug}{ext}"
            if dest.exists():
                n = 1
                while True:
                    alt = lib_dir / f"{slug}-{n}{ext}"
                    if not alt.exists():
                        dest = alt
                        break
                    n += 1
            shutil.move(str(path), str(dest))
            return f"career/library/{today}/{dest.name}"
        except Exception:
            log.debug("Career watcher: could not attach %s to library", path.name, exc_info=True)
            return ""

    # ------------------------------------------------------------------
    # Unsupported parking
    # ------------------------------------------------------------------
    def _unsupported_reason(self, f: Path) -> str | None:
        """Return a reason string if ``f`` should be parked, else None."""
        try:
            st = f.stat()
        except OSError:
            return None
        if st.st_size == 0:
            return None
        if time.time() - st.st_mtime < self._SETTLE_SECONDS:
            return None
        if st.st_size > self._MAX_FILE_BYTES:
            return f"oversized:{st.st_size}"
        if f.suffix.lower() not in _SUPPORTED_EXTS:
            ext = f.suffix.lower() or "no_extension"
            return f"unsupported_type:{ext}"
        return None

    async def _park_unsupported_files(self) -> list[str]:
        """Move unsupported / oversized files to
        ``career/inbox/quarantine/unsupported/``.

        Drops a ``.reason.txt`` sidecar. Emits medium-importance
        activity event per parked file. Never raises.
        """
        try:
            inbox = self._paths.resolve("career/inbox")
        except Exception:
            return []
        if not inbox.is_dir():
            return []
        try:
            qdir = self._paths.resolve(
                f"career/inbox/{_QUARANTINE_DIRNAME}/unsupported",
            )
        except Exception:
            return []

        parked: list[str] = []
        try:
            entries = list(inbox.iterdir())
        except OSError:
            return []
        for f in entries:
            if not f.is_file():
                continue
            if f.name == ".gitkeep" or f.name.startswith("."):
                continue
            reason = self._unsupported_reason(f)
            if not reason:
                continue
            try:
                qdir.mkdir(parents=True, exist_ok=True)
                dest = qdir / f.name
                if dest.exists():
                    stem, ext = dest.stem, dest.suffix
                    n = 1
                    while True:
                        alt = qdir / f"{stem}.{n}{ext}"
                        if not alt.exists():
                            dest = alt
                            break
                        n += 1
                f.rename(dest)
                sidecar = dest.with_suffix(dest.suffix + ".reason.txt")
                try:
                    supported_list = ", ".join(sorted(_SUPPORTED_EXTS))
                    sidecar.write_text(
                        f"Career drop-zone parked this file because the JD pipeline "
                        f"can't read it.\n"
                        f"Reason: {reason}\n"
                        f"Supported types: {supported_list}\n"
                        f"Restore: move this file back to career/inbox/ to retry.\n",
                        encoding="utf-8",
                    )
                except OSError:
                    log.debug("Could not write unsupported-park sidecar", exc_info=True)
                parked.append(f.name)
                self._emit_activity(
                    action="career_unsupported_parked",
                    summary=f"Parked {f.name} from career inbox: {reason}",
                    details={
                        "filename": f.name,
                        "reason": reason,
                        "destination": str(dest),
                        "via": "watcher",
                    },
                    importance="medium",
                )
            except Exception:
                log.exception(
                    "Career watcher: failed to park unsupported file %s", f.name,
                )
        return parked

    # ------------------------------------------------------------------
    # Quarantine (failed extraction after MAX_RETRIES attempts)
    # ------------------------------------------------------------------
    async def _quarantine(self, path: Path, attempts: int) -> bool:
        """Move ``path`` to ``career/inbox/quarantine/`` with a sidecar.

        Returns True iff the move succeeded. Never raises.
        """
        try:
            qdir = self._paths.resolve(f"career/inbox/{_QUARANTINE_DIRNAME}")
            qdir.mkdir(parents=True, exist_ok=True)
            dest = qdir / path.name
            if dest.exists():
                stem = dest.stem
                suffix = dest.suffix
                n = 1
                while True:
                    alt = qdir / f"{stem}.{n}{suffix}"
                    if not alt.exists():
                        dest = alt
                        break
                    n += 1
            path.rename(dest)
            sidecar = dest.with_suffix(dest.suffix + ".reason.txt")
            try:
                sidecar.write_text(
                    f"JD listing quarantined after {attempts} failed import attempts.\n"
                    f"Last error: {self._last_error or 'unknown'}\n"
                    f"Restore: move this file back to career/inbox/ to retry.\n",
                    encoding="utf-8",
                )
            except OSError:
                log.debug("Could not write quarantine sidecar", exc_info=True)
            self._emit_activity(
                action="career_listing_quarantined",
                summary=(
                    f"JD file {path.name} quarantined after {attempts} failed attempts"
                ),
                details={
                    "filename": path.name,
                    "attempts": attempts,
                    "last_error": self._last_error,
                    "destination": str(dest),
                    "via": "watcher",
                },
                importance="high",
            )
            return True
        except Exception:
            log.exception("Career watcher: quarantine failed for %s", path.name)
            return False

    # ------------------------------------------------------------------
    # ActivityLogger plumbing
    # ------------------------------------------------------------------
    def _emit_activity(
        self,
        *,
        action: str,
        summary: str,
        details: dict,
        importance: str,
    ) -> None:
        """Emit an activity event. No-op when logger isn't wired (tests)."""
        if self._activity is None:
            return
        try:
            self._activity.log(
                category="user",
                action=action,
                summary=summary,
                details=details,
                importance=importance,
            )
        except Exception:
            log.debug("Failed to emit activity event %s", action, exc_info=True)


__all__ = ["CareerInboxWatcher"]
