"""Stale-skill detector — surface long-untouched active skills as Rule 21 proposals.

Hermes-inspired re-implementation (NousResearch/hermes-agent, MIT). Pattern only;
no code copied. Closes the loop that started with Item 2 (skill usage sidecar):
once we track ``use_count`` + ``last_loaded_at`` per skill, we can name the
skills the agent never touches and propose they be archived.

**The gap this closes**

Active skill counts grow monotonically as users + community skills land in
a vault. Many are tried once + forgotten. Without a detector:

- The skill catalog injected into the system prompt bloats (token cost
  every chat turn).
- Voyager semantic retrieval has more candidates to compare against (more
  noise in matching).
- The user has no way to know which skills are dead weight without
  manually scrolling the Skills page.

This detector reads each active skill's usage sidecar (Item 2's
``.usage.json``) + emits a ``stale-skill`` proposal for any skill that:

1. Has ``use_count == 0`` AND
2. Has ``last_loaded_at`` older than ``idle_days`` (default 90) OR
   ``last_loaded_at`` is empty AND the SKILL.md ``modified_at`` is older.
3. Is NOT in an exempt category (``_meta``, ``file-types``, ``private``).
4. Is NOT in the user's ``pinned_skills`` list.

**Engine vs strategy split** (Rule 12)

Thresholds + exemptions + cadence live in
``defaults/skills/_meta/stale-skill-detect/config/detect.yaml``. Engine
is pure mechanics — YAML decides what counts as stale.

**Heartbeat integration**

``automation/heartbeat.py`` calls ``StaleSkillDetector.detect_and_propose()``
weekly (cadence from YAML). Pure sidecar read + frontmatter check —
no LLM, no expensive ops.

**Approval semantics**

This module ONLY emits the proposal. Approve-handler (move skill to
``<skill_dir>/../.archive/<name>/`` + reload loader) is a separate
concern — ships as a follow-up so the user first eyeballs proposals
from their real vault before we wire mutation. Same pattern as
``missing_tool`` / ``missing_agent`` where approve = acknowledgment.

**Precision protection** (lessons.md 2026-04-29):

- ``idle_days`` defaults to 90 — long enough that genuine "didn't get
  around to it yet" isn't flagged. Below 30 explicitly rejected by
  ``config_with_floor_guards`` to prevent accidentally drowning the queue.
- Exempt categories baked in (``_meta`` engine substrates; ``file-types``
  dispatched by registry not triggers; ``private`` user opt-in).
- ``max_per_pass`` (default 20) caps the number of proposals written per
  heartbeat run so a brand-new vault with 200 untouched skills doesn't
  produce 200 proposals at once.
- Stable proposal id keyed on skill name means re-running is idempotent;
  rejection writes a cooldown marker (out of scope for this module —
  cooldown lives in the route layer's reject handler).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from agntspace.automation.capability_proposals import (
    list_pending,
    stable_proposal_id,
    write_proposal,
)
from agntspace.skills.usage import read_usage

log = logging.getLogger(__name__)


# Hard floors — even YAML can't relax these (precision protection per
# lessons.md "Heartbeat-driven detectors must ship with precision floor"
# guidance). idle_days < 30 would produce false positives on legitimately
# new skills the user just hasn't picked up yet.
#
# arch:deterministic — engine substrate, structural precision contract.
_HARD_FLOOR_IDLE_DAYS: int = 30
_HARD_CEILING_MAX_PER_PASS: int = 200


# Categories the detector NEVER flags as stale. _meta = engine
# substrates (cron-driven OR injected at boot, never trigger-activated
# by the user). file-types = dispatched by FileTypeRegistry, not by
# triggers, so use_count stays 0 by design. private = user's vault-only
# opt-in territory; flagging would betray the "yours forever" contract.
_DEFAULT_EXEMPT_CATEGORIES: tuple[str, ...] = ("_meta", "file-types", "private")  # arch:deterministic — closed exemption set, contract-bound


# Default config used when YAML isn't loadable. Mirrors the shipped
# defaults/skills/_meta/stale-skill-detect/config/detect.yaml.
_FALLBACK_CONFIG: dict[str, Any] = {  # arch:deterministic — engine fallback for missing/malformed YAML
    "enabled": True,
    "idle_days": 90,
    "max_per_pass": 20,
    "exempt_categories": list(_DEFAULT_EXEMPT_CATEGORIES),
    "pinned_skills": [],
    "skip_if_pending": True,
    "cadence_hours": 168,  # weekly
}


@dataclass
class StaleSkillCandidate:
    """One skill that meets the staleness threshold.

    ``last_signal_at`` is the most-recent observable activity timestamp
    we could find — last_used_at OR last_loaded_at OR the SKILL.md
    file's modification time. Empty string means we couldn't find ANY
    signal (skill exists but has no sidecar AND no mtime info), which
    we treat as "ancient" for staleness purposes.
    """

    name: str
    category: str
    title: str
    use_count: int
    view_count: int
    last_signal_at: str
    days_idle: int
    description: str = ""
    skill_path: str = ""

    def proposed_title(self) -> str:
        """Human-friendly title for the inbox card."""
        if self.title:
            return f"Stale skill: {self.title}"
        return f"Stale skill: {self.name}"

    def proposed_description(self) -> str:
        """One-paragraph rationale shown in the proposals inbox."""
        return (
            f"Skill '{self.name}' (category: {self.category}) hasn't been used "
            f"in {self.days_idle} days. use_count={self.use_count}, "
            f"view_count={self.view_count}. Archive it to reduce catalog noise "
            f"or pin it in detect.yaml if you want to keep it active."
        )

    def proposed_rationale(self) -> str:
        """Longer rationale for the proposals inbox details panel."""
        signal_label = self.last_signal_at or "<no recorded signal>"
        return (
            f"Detected by stale-skill-detect on {datetime.now(UTC).strftime('%Y-%m-%d')}. "
            f"Skill is active in the loader but its usage sidecar shows zero "
            f"activations (use_count={self.use_count}) and was last observed "
            f"on {signal_label} ({self.days_idle} days ago). Approving this "
            f"proposal acknowledges the recommendation; archive behavior is "
            f"a separate user action (move <skill>/SKILL.md to <category>/.archive/)."
        )

    def to_payload(self) -> dict[str, Any]:
        """Structured fields the proposal payload carries for the UI."""
        return {
            "skill_name": self.name,
            "category": self.category,
            "title": self.title,
            "use_count": self.use_count,
            "view_count": self.view_count,
            "last_signal_at": self.last_signal_at,
            "days_idle": self.days_idle,
            "skill_path": self.skill_path,
        }


def config_with_floor_guards(raw_config: dict[str, Any] | None) -> dict[str, Any]:
    """Clamp YAML values to the precision floors.

    Returns a fresh dict — never mutates input. YAML values below the
    hard floor are silently raised to the floor + logged at INFO (not
    warning — the YAML might be in-progress; we don't want noise).
    """
    cfg = dict(_FALLBACK_CONFIG)
    if isinstance(raw_config, dict):
        for key, value in raw_config.items():
            cfg[key] = value
    # idle_days floor
    try:
        idle = int(cfg.get("idle_days", _FALLBACK_CONFIG["idle_days"]))
    except (TypeError, ValueError):
        idle = _FALLBACK_CONFIG["idle_days"]
    if idle < _HARD_FLOOR_IDLE_DAYS:
        log.info(
            "stale-skill-detect: idle_days=%d below floor %d; clamping",
            idle, _HARD_FLOOR_IDLE_DAYS,
        )
        idle = _HARD_FLOOR_IDLE_DAYS
    cfg["idle_days"] = idle
    # max_per_pass ceiling
    try:
        cap = int(cfg.get("max_per_pass", _FALLBACK_CONFIG["max_per_pass"]))
    except (TypeError, ValueError):
        cap = _FALLBACK_CONFIG["max_per_pass"]
    if cap < 1:
        cap = 1
    if cap > _HARD_CEILING_MAX_PER_PASS:
        log.info(
            "stale-skill-detect: max_per_pass=%d above ceiling %d; clamping",
            cap, _HARD_CEILING_MAX_PER_PASS,
        )
        cap = _HARD_CEILING_MAX_PER_PASS
    cfg["max_per_pass"] = cap
    # exempt_categories type-check (must be list of strings)
    raw_exempt = cfg.get("exempt_categories")
    if isinstance(raw_exempt, list):
        cfg["exempt_categories"] = [str(x) for x in raw_exempt if isinstance(x, str)]
    else:
        cfg["exempt_categories"] = list(_DEFAULT_EXEMPT_CATEGORIES)
    # pinned_skills type-check
    raw_pin = cfg.get("pinned_skills")
    if isinstance(raw_pin, list):
        cfg["pinned_skills"] = [str(x) for x in raw_pin if isinstance(x, str)]
    else:
        cfg["pinned_skills"] = []
    return cfg


def _now_utc() -> datetime:
    """Single source so tests can monkeypatch."""
    return datetime.now(UTC)


def _parse_iso_datetime(value: str) -> datetime | None:
    """Parse an ISO-8601 string; return None on any failure."""
    if not value or not isinstance(value, str):
        return None
    try:
        # Replace trailing Z (UTC) with +00:00 for fromisoformat compat
        cleaned = value.replace("Z", "+00:00") if value.endswith("Z") else value
        dt = datetime.fromisoformat(cleaned)
    except ValueError:
        return None
    if dt.tzinfo is None:
        # Treat naive as UTC — sidecar writes always include tzinfo, but
        # legacy / migrated entries might not.
        dt = dt.replace(tzinfo=UTC)
    return dt


def _days_between(then: datetime, now: datetime) -> int:
    """Whole days between two timestamps. Future timestamps return 0."""
    diff = now - then
    if diff < timedelta(0):
        return 0
    return diff.days


def _resolve_skill_dir(skills_dir: Path, skill_rel_path: str) -> Path | None:
    """Mirror SkillUsageRecorder.resolve_skill_dir.

    Skill.path is RELATIVE to skills_dir and points at SKILL.md
    (e.g. ``core/kb-ingest/SKILL.md``). Sidecar lives in parent dir.
    """
    if not skill_rel_path:
        return None
    rel = Path(skill_rel_path)
    if rel.name == "SKILL.md":
        rel = rel.parent
    candidate = skills_dir / rel
    if not candidate.is_dir():
        return None
    return candidate


def _resolve_last_signal(
    skill_dir: Path,
    usage: dict[str, Any],
) -> tuple[str, datetime | None]:
    """Return (iso_string, parsed_datetime) — the most recent observable
    activity on this skill.

    Priority: last_used_at → last_loaded_at → SKILL.md mtime → empty.
    Empty string means we have NO signal whatsoever (treat as ancient).
    """
    # 1. last_used_at (real activation)
    candidate_iso = str(usage.get("last_used_at", "") or "")
    candidate_dt = _parse_iso_datetime(candidate_iso)
    if candidate_dt is not None:
        return candidate_iso, candidate_dt
    # 2. last_loaded_at (lookup signal)
    candidate_iso = str(usage.get("last_loaded_at", "") or "")
    candidate_dt = _parse_iso_datetime(candidate_iso)
    if candidate_dt is not None:
        return candidate_iso, candidate_dt
    # 3. SKILL.md mtime
    skill_md = skill_dir / "SKILL.md"
    if skill_md.is_file():
        try:
            mtime = datetime.fromtimestamp(skill_md.stat().st_mtime, tz=UTC)
            return mtime.isoformat(), mtime
        except OSError:
            pass
    return "", None


def find_stale_skills(
    skill_loader,
    skills_dir: Path,
    *,
    idle_days: int,
    exempt_categories: list[str] | tuple[str, ...] | None = None,
    pinned_skills: list[str] | tuple[str, ...] | None = None,
    max_results: int | None = None,
    now: datetime | None = None,
) -> list[StaleSkillCandidate]:
    """Pure function — scan loader's active skills + return candidates.

    Returns oldest-first so the most-stale skills surface first in the
    inbox. Caller is responsible for trimming to max_per_pass; this
    helper applies max_results when set (test convenience).
    """
    exempt = set(exempt_categories or _DEFAULT_EXEMPT_CATEGORIES)
    pinned = set(pinned_skills or [])
    now_dt = now or _now_utc()
    candidates: list[StaleSkillCandidate] = []

    try:
        all_skills = skill_loader.skills if hasattr(skill_loader, "skills") else {}
    except Exception:
        log.debug("stale-skill-detect: skill_loader.skills access failed", exc_info=True)
        return []

    for name, skill in (all_skills or {}).items():
        try:
            status = getattr(skill, "status", "active")
            if status != "active":
                continue
            if getattr(skill, "category", "") in exempt:
                continue
            if name in pinned:
                continue
            skill_path = str(getattr(skill, "path", ""))
            skill_dir = _resolve_skill_dir(skills_dir, skill_path)
            if skill_dir is None:
                # Path can't be resolved — skip silently. Detector NEVER
                # speculates about skills it can't actually inspect.
                continue
            usage = read_usage(skill_dir)
            use_count = int(usage.get("use_count", 0) or 0)
            view_count = int(usage.get("view_count", 0) or 0)
            # ONLY skills with use_count==0 are candidates. view_count>0
            # is fine — that just means the loader resolved the skill;
            # it doesn't mean the agent ever ACTIVATED it.
            if use_count > 0:
                continue
            signal_iso, signal_dt = _resolve_last_signal(skill_dir, usage)
            if signal_dt is None:
                # No signal anywhere — treat as ancient (max staleness).
                days_idle = 9999
            else:
                days_idle = _days_between(signal_dt, now_dt)
            if days_idle < idle_days:
                continue
            candidates.append(
                StaleSkillCandidate(
                    name=name,
                    category=getattr(skill, "category", ""),
                    title=getattr(skill, "title", "") or name,
                    use_count=use_count,
                    view_count=view_count,
                    last_signal_at=signal_iso,
                    days_idle=days_idle,
                    description=getattr(skill, "description", "") or "",
                    skill_path=skill_path,
                )
            )
        except Exception:
            log.debug("stale-skill-detect: per-skill scan failed for %s", name, exc_info=True)
            continue

    # Oldest-first so the most stale surface first
    candidates.sort(key=lambda c: c.days_idle, reverse=True)
    if max_results is not None and max_results > 0:
        candidates = candidates[:max_results]
    return candidates


class StaleSkillDetector:
    """Heartbeat-driven service wrapping find_stale_skills + persistence.

    Construct once at boot, call detect_and_propose() periodically. The
    public surface mirrors the other Rule 21 detectors (TaxonomyOrphanDetector,
    MissingToolDetector, etc.) so the heartbeat hook is uniform.

    Stateless — re-running with no changes is a no-op via stable proposal
    ids + skip_if_pending dedup.
    """

    KIND = "stale-skill"

    def __init__(
        self,
        skill_loader,
        skills_dir: Path,
        vault_dir: Path,
        *,
        config: dict[str, Any] | None = None,
        config_loader=None,
    ) -> None:
        """
        Args:
            skill_loader: SkillLoader with .skills dict.
            skills_dir: Root of all skill subdirs (for sidecar path resolution).
            vault_dir: Vault root for proposal persistence
                (vault_dir/agntspace/memory/pending/stale-skill-proposals).
            config: Pre-resolved config dict. When None, ``config_loader`` is
                called to read fresh YAML on every detect_and_propose call
                (hot-reload semantics matching other detectors).
            config_loader: Callable returning raw YAML dict. When None and
                config is also None, falls back to _FALLBACK_CONFIG.
        """
        self._skill_loader = skill_loader
        self._skills_dir = Path(skills_dir)
        self._vault_dir = Path(vault_dir)
        self._explicit_config = config
        self._config_loader = config_loader
        self._activity: object | None = None  # injected post-hoc
        self._decisions: object | None = None  # injected post-hoc

    def _resolve_config(self) -> dict[str, Any]:
        """Returns the current effective config, applying floor guards."""
        if self._explicit_config is not None:
            return config_with_floor_guards(self._explicit_config)
        if self._config_loader is not None:
            try:
                raw = self._config_loader() or {}
            except Exception:
                log.debug("stale-skill-detect: config loader raised", exc_info=True)
                raw = {}
            return config_with_floor_guards(raw)
        return config_with_floor_guards(None)

    @property
    def enabled(self) -> bool:
        """Heartbeat hook surface — read directly without invoking the scan.

        Always fail-soft → True (legacy "always on" semantics) when config
        resolution itself raises. The detect_and_propose call has its own
        kill-switch path; this property is just for the cadence gate.
        """
        try:
            return bool(self._resolve_config().get("enabled", True))
        except Exception:
            log.debug("stale-skill-detect: enabled getter failed", exc_info=True)
            return True

    @property
    def cadence_hours(self) -> int:
        """Heartbeat hook surface — how often to call detect_and_propose."""
        try:
            return int(self._resolve_config().get("cadence_hours", 168))
        except Exception:
            log.debug("stale-skill-detect: cadence_hours getter failed", exc_info=True)
            return 168

    async def detect_and_propose(self) -> dict[str, Any]:
        """One-shot scan + proposal write. Returns structured report."""
        cfg = self._resolve_config()
        if not cfg.get("enabled", True):
            return {
                "skipped": "disabled",
                "scanned": 0,
                "candidates_found": 0,
                "proposals_written": 0,
                "skipped_dedup": 0,
            }

        try:
            candidates = find_stale_skills(
                self._skill_loader,
                self._skills_dir,
                idle_days=int(cfg["idle_days"]),
                exempt_categories=cfg.get("exempt_categories"),
                pinned_skills=cfg.get("pinned_skills"),
                max_results=int(cfg["max_per_pass"]),
            )
        except Exception as exc:
            log.exception("stale-skill-detect: scan failed: %s", exc)
            return {
                "error": f"scan_failed: {exc}",
                "scanned": 0, "candidates_found": 0,
                "proposals_written": 0, "skipped_dedup": 0,
            }

        skip_if_pending = bool(cfg.get("skip_if_pending", True))
        existing_ids: set[str] = set()
        if skip_if_pending:
            try:
                for p in list_pending(self._vault_dir, self.KIND):
                    existing_ids.add(p.proposal_id)
            except Exception:
                log.debug("stale-skill-detect: list_pending failed", exc_info=True)

        proposals_written = 0
        skipped_dedup = 0
        write_errors: list[dict[str, Any]] = []

        for candidate in candidates:
            try:
                stable_id = stable_proposal_id(self.KIND, candidate.name)
            except Exception:
                log.debug("stale-skill-detect: stable_id failed for %s", candidate.name, exc_info=True)
                continue
            if skip_if_pending and stable_id in existing_ids:
                skipped_dedup += 1
                continue
            proposal, err = write_proposal(
                self._vault_dir,
                self.KIND,
                target=candidate.name,
                title=candidate.proposed_title(),
                description=candidate.proposed_description(),
                rationale=candidate.proposed_rationale(),
                proposed_by="stale-skill-detector",
                examples=[candidate.name],
                payload=candidate.to_payload(),
            )
            if proposal is None:
                write_errors.append({"skill": candidate.name, "error": err})
                continue
            proposals_written += 1

        # Activity event (Rule 13)
        if self._activity is not None and (proposals_written or skipped_dedup or write_errors):
            try:
                await self._activity.log(
                    category="skills",
                    action="stale_skill_scan_completed",
                    summary=(
                        f"stale-skill scan: {len(candidates)} candidate(s), "
                        f"{proposals_written} proposed, {skipped_dedup} deduped"
                    ),
                    importance="low" if proposals_written == 0 else "medium",
                    details={
                        "scanned": len(candidates),
                        "proposals_written": proposals_written,
                        "skipped_dedup": skipped_dedup,
                        "write_errors": write_errors[:5],
                    },
                )
            except Exception:
                log.debug("stale-skill-detect: activity log failed", exc_info=True)

        return {
            "scanned": len(candidates),
            "candidates_found": len(candidates),
            "proposals_written": proposals_written,
            "skipped_dedup": skipped_dedup,
            "write_errors": write_errors,
            "config": {
                "idle_days": cfg["idle_days"],
                "max_per_pass": cfg["max_per_pass"],
            },
        }


# ── Approve effect — actual archive move ────────────────────────────


def _resolve_archive_target(skill_dir: Path) -> Path:
    """Resolve the archive destination for a skill directory.

    ``<category>/<name>/`` → ``<category>/.archive/<name>/``. The
    ``.archive`` directory is dot-prefixed, so universal dot-segment
    skip rule in kb/service.py + routes/wiki.py + memory/graph.py +
    raw_watcher + SkillLoader excludes it from traversal — agents
    never re-discover an archived skill.

    Collision-safe: if ``<category>/.archive/<name>/`` already exists
    (skill was archived previously then restored then re-archived),
    appends a numeric suffix ``<name>-1``, ``<name>-2``, etc.
    """
    if skill_dir.name == "SKILL.md":
        skill_dir = skill_dir.parent
    parent = skill_dir.parent
    archive_root = parent / ".archive"
    base_name = skill_dir.name
    candidate = archive_root / base_name
    if not candidate.exists():
        return candidate
    # Collision — find first free suffix
    for n in range(1, 1000):
        candidate = archive_root / f"{base_name}-{n}"
        if not candidate.exists():
            return candidate
    # Pathological case — fall through to timestamp-suffix
    import time
    return archive_root / f"{base_name}-{int(time.time())}"


def archive_skill_directory(
    skills_dir: Path,
    skill_rel_path: str,
) -> tuple[bool, str, dict[str, Any]]:
    """Move a skill's directory to ``<category>/.archive/<name>/``.

    Pure filesystem mutation — caller resolves whether the move should
    happen (proposal exists, skill still active, etc.). Returns:

        (ok, status, details)

    ``status`` is a closed enum:
        - ``"archived"`` — happy path, move succeeded
        - ``"path_unresolvable"`` — skill_rel_path empty / doesn't resolve
        - ``"skill_md_missing"`` — directory exists but no SKILL.md inside
          (defensive — refuse to archive what isn't really a skill)
        - ``"move_failed"`` — OSError on rename; details carry exc message

    ``details`` carries ``{from, to, ...}`` on success or
    ``{from, error}`` on failure.
    """
    skill_dir = _resolve_skill_dir(skills_dir, skill_rel_path)
    if skill_dir is None:
        return False, "path_unresolvable", {"skill_rel_path": skill_rel_path}
    # Defensive sanity — only archive what actually looks like a skill
    if not (skill_dir / "SKILL.md").is_file():
        return False, "skill_md_missing", {"from": str(skill_dir)}
    target = _resolve_archive_target(skill_dir)
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        skill_dir.rename(target)
    except OSError as exc:
        return False, "move_failed", {
            "from": str(skill_dir),
            "to": str(target),
            "error": str(exc),
        }
    return True, "archived", {
        "from": str(skill_dir),
        "to": str(target),
    }


def approve_stale_skill_proposal(
    vault_dir: Path,
    proposal_id: str,
    *,
    skill_loader,
    skills_dir: Path,
) -> tuple[bool, str, dict[str, Any]]:
    """Approve handler — actually move the skill to .archive/.

    Returns ``(ok, status, details)`` matching the contract the
    capability_proposals approve handlers share. ``status`` closed enum:

        - ``"archived"`` — happy path
        - ``"not_found"`` — proposal id unknown
        - ``"skill_not_loaded"`` — skill no longer in loader (already
          removed manually, or never existed)
        - ``"path_unresolvable"`` / ``"skill_md_missing"`` / ``"move_failed"``
          — pass-through from archive_skill_directory

    On success, the pending proposal file is also removed. Caller is
    responsible for triggering ``skill_loader.load_all()`` to drop the
    archived skill from cache (we don't do it here so this function
    stays unit-testable without a real SkillLoader).
    """
    from agntspace.automation.capability_proposals import (
        get_proposal,
        reject_proposal,
    )

    proposal = get_proposal(vault_dir, "stale-skill", proposal_id)
    if proposal is None:
        return False, "not_found", {"proposal_id": proposal_id}

    skill_name = proposal.target
    # Verify skill still exists in the loader — user might have
    # manually removed it between proposal write + approve click.
    try:
        skill = skill_loader.skills.get(skill_name) if skill_loader else None
    except Exception:
        skill = None
    if skill is None:
        # Skill is gone; just remove the stale proposal + report
        reject_proposal(vault_dir, "stale-skill", proposal_id)
        return False, "skill_not_loaded", {
            "proposal_id": proposal_id,
            "skill": skill_name,
        }

    skill_rel_path = getattr(skill, "path", "") or str(proposal.payload.get("skill_path", ""))
    ok, status, details = archive_skill_directory(skills_dir, skill_rel_path)
    if not ok:
        # DON'T remove the pending file — user should see the failure
        # in the inbox and try again after fixing whatever broke (e.g.
        # permission issue).
        details["proposal_id"] = proposal_id
        details["skill"] = skill_name
        return False, status, details

    # Filesystem move succeeded — remove pending proposal
    reject_proposal(vault_dir, "stale-skill", proposal_id)

    details["proposal_id"] = proposal_id
    details["skill"] = skill_name
    return True, "archived", details
