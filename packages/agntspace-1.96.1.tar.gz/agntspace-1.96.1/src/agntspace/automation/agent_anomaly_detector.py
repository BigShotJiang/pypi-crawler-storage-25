"""Agent behavior anomaly detector — surface unusual operational
patterns (error storms, runaway dispatch, cost spikes) as Rule 21
proposals in the unified ``/proposals`` inbox.

**The gap this closes**: AgntSpace already has rich operational
substrate — ``decision_log`` v1.4 records every action with
``result_status`` + ``error_type`` + ``duration_ms``, ``cost_log``
records spend per caller, ``dispatch_log`` records subagent outcomes.
But the system never *correlates* across these signals to surface
"the agent is behaving weirdly right now." A runaway loop costing
$50/hour, an error storm flooding logs, a sudden cost spike — all
invisible unless the user happens to be watching the dashboards.

This detector closes the gap PROACTIVELY: heartbeat-throttled scan
that evaluates pure-function rules over recent decision history,
flags anomalies, surfaces them as user-actionable proposals via the
existing Rule 21 substrate.

**Phase 1 ships ONE rule** — ``error_storm`` — and the engine
substrate so future rules are mechanical YAML additions (Rule 12 —
strategy in skills, engine in code).

**Engine vs strategy split** (Rule 12):

The rules + thresholds + windows + cooldowns + severity ladder all
live in ``defaults/skills/_meta/agent-anomaly/config/rules.yaml``.
This module is pure mechanics — the YAML decides when to fire and
how loudly.
"""
from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from agntspace.automation.capability_proposals import (
    list_pending,
    stable_proposal_id,
    write_proposal,
)

log = logging.getLogger(__name__)


# ── Closed enum: rule kinds we know how to evaluate ──────────────────
# arch:deterministic — closed enumeration tied 1:1 to predicate
# functions below. Adding a new kind requires (a) extending this set,
# (b) adding a predicate function, (c) wiring it in _evaluate_rule.
_VALID_RULE_KINDS: frozenset[str] = frozenset({"error_storm", "runaway_dispatch", "cost_spike"})  # arch:deterministic — Phase 1 shipped error_storm; Phase 2a runaway_dispatch; Phase 2b cost_spike

# Severity ladder maps the rule's declared severity to importance for
# the Rule 21 inbox. low → housekeeping toast, medium → action card,
# high → prominent banner. arch:deterministic — mirrors the same
# levels used by every other capability proposal kind.
_VALID_SEVERITIES: frozenset[str] = frozenset({"low", "medium", "high"})  # arch:deterministic — proposal-card severity ladder


# ── Fallback config (used when YAML is missing / unreadable) ─────────
# arch:deterministic — minimal safe defaults. YAML override is the
# normal path; this fallback exists so a broken YAML never disables
# the detector entirely (it just makes everything firing-threshold-N
# higher).
_FALLBACK_CONFIG: dict[str, Any] = {  # arch:deterministic — degraded-mode fallback so broken YAML doesn't lock out anomaly detection
    "enabled": True,
    "cadence_hours": 1,
    "skip_if_pending": True,
    "default_window_minutes": 60,
    "cooldown_hours": 24,
    "rules": [
        {
            "name": "error_storm",
            "kind": "error_storm",
            "enabled": True,
            "window_minutes": 60,
            "min_count": 5,
            "severity": "medium",
            "description": (
                "Same error_type appeared 5+ times from the same actor "
                "in the last 60 minutes. May indicate a runaway retry "
                "loop, a broken external service, or a regression in "
                "a tool implementation."
            ),
        },
    ],
}


# ── Models ───────────────────────────────────────────────────────────


@dataclass
class AnomalyRule:
    """One declarative rule loaded from YAML.

    Pure data — the predicate logic lives in ``_evaluate_rule`` (so a
    typo in YAML can't crash the engine; unknown rule kinds are skipped
    with a warning).
    """

    name: str
    kind: str
    enabled: bool = True
    window_minutes: int = 60
    min_count: int = 5
    severity: str = "medium"
    description: str = ""
    # Per-rule cooldown override (falls through to global cooldown_hours
    # when None / 0).
    cooldown_hours: int = 0
    # Phase 2a — runaway_dispatch / cost_spike knobs. Default values
    # are unused when kind == "error_storm"; safe additive extension.
    # baseline_window_hours = how far back we look to compute the
    # comparison median. multiplier = how many ×baseline qualifies as
    # "runaway". min_baseline_count = floor on baseline activity below
    # which we don't flag (prevents spurious "3× of 1 dispatch" hits).
    baseline_window_hours: int = 24
    multiplier: float = 3.0
    min_baseline_count: int = 5

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AnomalyRule | None:
        """Parse one rule entry. Returns ``None`` if shape is invalid —
        caller logs a warning and skips."""
        try:
            kind = str(data.get("kind", "")).strip()
            if kind not in _VALID_RULE_KINDS:
                return None
            name = str(data.get("name", "")).strip() or kind
            severity = str(data.get("severity", "medium")).strip()
            if severity not in _VALID_SEVERITIES:
                severity = "medium"
            return cls(
                name=name,
                kind=kind,
                enabled=bool(data.get("enabled", True)),
                window_minutes=max(1, int(data.get("window_minutes", 60))),
                min_count=max(1, int(data.get("min_count", 5))),
                severity=severity,
                description=str(data.get("description", "")),
                cooldown_hours=int(data.get("cooldown_hours", 0) or 0),
                # Phase 2a knobs — clamped to safe floors so misconfig
                # can't cause divide-by-zero in baseline math.
                baseline_window_hours=max(1, int(data.get("baseline_window_hours", 24))),
                multiplier=max(1.0, float(data.get("multiplier", 3.0))),
                min_baseline_count=max(1, int(data.get("min_baseline_count", 5))),
            )
        except (TypeError, ValueError):
            return None


@dataclass
class Anomaly:
    """One detected anomaly. Becomes a CapabilityProposal at write
    time."""

    rule_name: str
    kind: str
    actor: str
    error_type: str  # empty when not applicable (Phase 1 error_storm uses it)
    occurrences: int
    window_minutes: int
    severity: str
    first_seen_iso: str
    last_seen_iso: str
    examples: list[str] = field(default_factory=list)
    # Phase 2a — runaway_dispatch needs to identify WHICH dispatch
    # target was runaway. Empty for Phase 1 error_storm. Additive so
    # existing pending files on disk parse cleanly (CapabilityProposal
    # tolerates missing payload keys).
    action_target: str = ""
    # baseline_count + multiplier are runaway_dispatch payload data;
    # populated only when kind == "runaway_dispatch". Empty/zero when
    # not applicable.
    baseline_median: float = 0.0
    multiplier_observed: float = 0.0
    # Phase 2b — cost_spike needs caller (the dimension that varies
    # for cost rows) + cost figures in USD. Empty/zero when not
    # applicable. Additive — Phase 1+2a pending files on disk stay valid.
    caller: str = ""
    cost_usd: float = 0.0
    baseline_cost_usd: float = 0.0

    @property
    def target(self) -> str:
        """Stable identifier for proposal_id derivation.

        We want re-detecting the same anomaly to OVERWRITE the prior
        proposal (not pile up duplicates). The target encodes the
        dimensions that make this anomaly unique within a cooldown
        window — rule name + actor (or caller) + the rule-specific
        dimension that identifies WHAT was anomalous (error_type for
        error_storm, action_target for runaway_dispatch, caller for
        cost_spike — note cost_spike uses caller AS the actor since
        spend is tracked by who triggered the LLM call, not by an
        orchestrator-style actor). The window of time is NOT in the
        target because the same anomaly at 14:00 and 15:00 is the
        SAME problem.
        """
        # Phase 2b — cost_spike keys on caller (the dimension that
        # varies for cost rows). The caller is the dispatcher that
        # triggered the LLM spend (e.g. "chat", "daily_briefing",
        # "kb_ingest_classify").
        if self.kind == "cost_spike" and self.caller:
            return f"{self.rule_name}:{self.caller}"
        # Phase 2a — runaway_dispatch keys on action_target (which
        # subagent was being looped on) not error_type.
        if self.kind == "runaway_dispatch" and self.action_target:
            return f"{self.rule_name}:{self.actor}:{self.action_target}"
        if self.error_type:
            return f"{self.rule_name}:{self.actor}:{self.error_type}"
        return f"{self.rule_name}:{self.actor}"


# ── Pure helpers (testable in isolation) ─────────────────────────────


def _parse_iso(ts: str) -> datetime | None:
    """Parse an ISO-8601 timestamp string. Returns None on any failure
    — caller treats a None as "couldn't bucket this row, skip it"."""
    if not ts:
        return None
    try:
        # Handle 'Z' suffix that strptime doesn't take.
        if ts.endswith("Z"):
            ts = ts[:-1] + "+00:00"
        dt = datetime.fromisoformat(ts)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        return dt
    except (ValueError, TypeError):
        return None


def _evaluate_error_storm(
    decisions: list[dict[str, Any]],
    rule: AnomalyRule,
    *,
    now: datetime | None = None,
) -> list[Anomaly]:
    """Detect error storms: same (actor, error_type) repeated >= min_count
    times in window_minutes.

    Pure function over an already-filtered list of decision dicts.
    Caller is responsible for fetching the rows within the time window;
    we re-check timestamps here as defense against malformed input.

    Returns one Anomaly per (actor, error_type) group meeting the
    threshold. Empty list if nothing crosses.
    """
    if now is None:
        now = datetime.now(UTC)
    cutoff = now - timedelta(minutes=rule.window_minutes)

    # Group by (actor, error_type), counting only rows with non-empty
    # error_type (errors) and timestamps within the window.
    buckets: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for d in decisions:
        actor = str(d.get("actor", "")).strip()
        err_type = str(d.get("error_type", "")).strip()
        if not actor or not err_type:
            continue
        ts = _parse_iso(str(d.get("timestamp", "")))
        if ts is None or ts < cutoff:
            continue
        buckets.setdefault((actor, err_type), []).append(d)

    out: list[Anomaly] = []
    for (actor, err_type), rows in buckets.items():
        if len(rows) < rule.min_count:
            continue
        # Sort by ts ascending so first/last are stable for proposal
        # rationale text.
        rows.sort(key=lambda r: r.get("timestamp", ""))
        first_iso = str(rows[0].get("timestamp", ""))
        last_iso = str(rows[-1].get("timestamp", ""))
        # Examples = up to 3 distinct action_target / action_type for
        # the reader's review.
        seen: list[str] = []
        for r in rows:
            sample = (
                str(r.get("action_target", "")).strip()
                or str(r.get("action_type", "")).strip()
            )
            if sample and sample not in seen:
                seen.append(sample)
            if len(seen) >= 3:
                break
        out.append(
            Anomaly(
                rule_name=rule.name,
                kind=rule.kind,
                actor=actor,
                error_type=err_type,
                occurrences=len(rows),
                window_minutes=rule.window_minutes,
                severity=rule.severity,
                first_seen_iso=first_iso,
                last_seen_iso=last_iso,
                examples=seen,
            )
        )
    # Determinism: sort by (occurrences desc, actor asc, error_type asc)
    out.sort(key=lambda a: (-a.occurrences, a.actor, a.error_type))
    return out


def _median(values: list[float]) -> float:
    """Compute the median of a list of floats. Returns 0.0 on empty
    input — caller treats that as "no baseline to compare against".

    Pure helper, deterministic. Median is resistant to single-spike
    outliers in the baseline series, which is exactly what we want
    for "what's the normal dispatch rate?" calculations: one heavy
    catch-up batch in the prior 24h shouldn't suppress today's
    runaway-loop detection.
    """
    if not values:
        return 0.0
    sorted_v = sorted(values)
    n = len(sorted_v)
    mid = n // 2
    if n % 2 == 1:
        return float(sorted_v[mid])
    return float((sorted_v[mid - 1] + sorted_v[mid]) / 2)


def _count_dispatches_per_window(
    decisions: list[dict[str, Any]],
    *,
    actor: str,
    action_target: str,
    window_start: datetime,
    window_end: datetime,
) -> int:
    """Count decision_log rows matching (actor, action_target,
    action_type=dispatch) with timestamps in [window_start, window_end).

    Pure function over an already-fetched decision list. Caller is
    responsible for the time-range query; we do the per-bucket count.
    Half-open interval semantics so adjacent buckets don't double-count.
    """
    count = 0
    for d in decisions:
        if str(d.get("actor", "")).strip() != actor:
            continue
        if str(d.get("action_target", "")).strip() != action_target:
            continue
        if str(d.get("action_type", "")).strip() != "dispatch":
            continue
        ts = _parse_iso(str(d.get("timestamp", "")))
        if ts is None:
            continue
        if window_start <= ts < window_end:
            count += 1
    return count


def _evaluate_runaway_dispatch(
    decisions: list[dict[str, Any]],
    rule: AnomalyRule,
    *,
    now: datetime | None = None,
) -> list[Anomaly]:
    """Detect runaway dispatch loops: an (actor, action_target) pair
    was dispatched ``multiplier×`` more in the recent window than the
    median across equal-width baseline windows.

    Comparison shape:

    * **Current window**: the most recent ``window_minutes`` ending now.
    * **Baseline windows**: ``baseline_window_hours × 60 / window_minutes``
      adjacent non-overlapping windows of the SAME width, going back
      from the start of the current window. Median across those.
    * **Floor**: baseline median must be ≥ ``min_baseline_count`` —
      otherwise "3× of 1 dispatch = trivial 3 dispatches" produces
      false positives on near-zero activity actors.
    * **Floor (current)**: current count must also be ≥ ``min_count``
      so we never flag noise (e.g. 0.5× baseline of 0 = 0).

    Pure function over an already-fetched decision list. Caller is
    responsible for fetching the rows within the full baseline window
    (current_window + baseline_windows); we bucket them here.

    Returns one Anomaly per (actor, action_target) pair meeting all
    thresholds. Empty list if nothing crosses.
    """
    if now is None:
        now = datetime.now(UTC)

    window_width = timedelta(minutes=rule.window_minutes)
    current_start = now - window_width
    # Baseline goes back from current_start, in equal-width windows.
    # We compute how many full windows fit in baseline_window_hours.
    baseline_seconds = rule.baseline_window_hours * 3600
    window_seconds = rule.window_minutes * 60
    n_baseline_windows = max(1, baseline_seconds // window_seconds)
    baseline_start = current_start - timedelta(seconds=int(n_baseline_windows * window_seconds))

    # Group ALL relevant dispatch rows by (actor, action_target) so
    # we can find every pair worth scoring. Cheaper than computing N×M
    # bucket counts when most pairs have zero baseline activity.
    pairs_seen: set[tuple[str, str]] = set()
    for d in decisions:
        if str(d.get("action_type", "")).strip() != "dispatch":
            continue
        actor = str(d.get("actor", "")).strip()
        target = str(d.get("action_target", "")).strip()
        if not actor or not target:
            continue
        ts = _parse_iso(str(d.get("timestamp", "")))
        if ts is None or ts < baseline_start:
            continue
        pairs_seen.add((actor, target))

    out: list[Anomaly] = []
    for actor, target in pairs_seen:
        # Current window count
        current_count = _count_dispatches_per_window(
            decisions,
            actor=actor,
            action_target=target,
            window_start=current_start,
            window_end=now,
        )
        # Below absolute floor → skip (no signal even if multiplier huge).
        if current_count < rule.min_count:
            continue

        # Compute baseline-window counts. Each baseline window has the
        # same width as the current window.
        baseline_counts: list[float] = []
        for i in range(int(n_baseline_windows)):
            w_end = current_start - timedelta(seconds=int(i * window_seconds))
            w_start = w_end - window_width
            baseline_counts.append(float(_count_dispatches_per_window(
                decisions,
                actor=actor,
                action_target=target,
                window_start=w_start,
                window_end=w_end,
            )))

        baseline = _median(baseline_counts)
        # Baseline-too-small floor — don't fire when normal activity
        # is near-zero (3× of 0 or 1 is meaningless noise).
        if baseline < rule.min_baseline_count:
            continue

        observed_ratio = current_count / baseline if baseline > 0 else float("inf")
        if observed_ratio < rule.multiplier:
            continue

        # Sort current-window rows ascending for stable first/last
        # timestamps in the proposal rationale.
        current_rows = [
            d for d in decisions
            if str(d.get("actor", "")).strip() == actor
            and str(d.get("action_target", "")).strip() == target
            and str(d.get("action_type", "")).strip() == "dispatch"
            and (ts := _parse_iso(str(d.get("timestamp", "")))) is not None
            and current_start <= ts < now
        ]
        current_rows.sort(key=lambda r: r.get("timestamp", ""))
        first_iso = str(current_rows[0].get("timestamp", "")) if current_rows else ""
        last_iso = str(current_rows[-1].get("timestamp", "")) if current_rows else ""

        # Examples = up to 3 distinct contract_action / triggered_by
        # samples for the reader's review (helps distinguish
        # legitimately-busy from runaway).
        seen: list[str] = []
        for r in current_rows:
            sample = (
                str(r.get("contract_action", "")).strip()
                or str(r.get("triggered_by", "")).strip()
            )
            if sample and sample not in seen:
                seen.append(sample)
            if len(seen) >= 3:
                break

        out.append(
            Anomaly(
                rule_name=rule.name,
                kind=rule.kind,
                actor=actor,
                error_type="",  # not applicable for runaway_dispatch
                action_target=target,
                occurrences=current_count,
                window_minutes=rule.window_minutes,
                severity=rule.severity,
                first_seen_iso=first_iso,
                last_seen_iso=last_iso,
                examples=seen,
                baseline_median=baseline,
                multiplier_observed=observed_ratio,
            )
        )

    # Determinism: sort by (observed_ratio desc, actor asc, target asc).
    out.sort(key=lambda a: (-a.multiplier_observed, a.actor, a.action_target))
    return out


def _sum_cost_per_window(
    cost_rows: list[dict[str, Any]],
    *,
    caller: str,
    window_start: datetime,
    window_end: datetime,
) -> float:
    """Sum ``estimated_cost`` for cost_log rows matching ``caller``
    with timestamps in ``[window_start, window_end)``.

    Pure function over an already-fetched cost-row list. Half-open
    interval semantics so adjacent buckets don't double-count.
    Non-numeric or missing ``estimated_cost`` rows contribute 0.0.
    """
    total = 0.0
    for r in cost_rows:
        if str(r.get("caller", "")).strip() != caller:
            continue
        ts = _parse_iso(str(r.get("timestamp", "")))
        if ts is None:
            continue
        if not (window_start <= ts < window_end):
            continue
        try:
            total += float(r.get("estimated_cost", 0.0) or 0.0)
        except (TypeError, ValueError):
            continue
    return total


def _evaluate_cost_spike(
    cost_rows: list[dict[str, Any]],
    rule: AnomalyRule,
    *,
    now: datetime | None = None,
) -> list[Anomaly]:
    """Detect cost spikes: a caller spent ``multiplier×`` more in the
    recent window than the median across equal-width baseline windows.

    Comparison shape mirrors ``_evaluate_runaway_dispatch`` exactly:

    * **Current window**: the most recent ``window_minutes`` ending now.
    * **Baseline windows**: equal-width windows going back
      ``baseline_window_hours``. Median across those.
    * **Floor (current)**: current-window total must be
      ≥ ``min_count`` (reused as $-floor; rule.min_count interpreted
      as cents-to-dollars conversion is awkward, so cost_spike YAML
      should override min_count to a sensible dollar value).
    * **Floor (baseline)**: baseline median must be
      ≥ ``min_baseline_count`` (same field, dollar interpretation).

    Pure function over an already-fetched cost-row list. Caller is
    responsible for the time-range query.

    Returns one Anomaly per caller crossing all thresholds. Empty
    list if nothing crosses.

    Note on the min_count/min_baseline_count fields: they're FLOAT
    thresholds for cost_spike (USD), not integer counts. AnomalyRule
    stores them as int (legacy), so cost_spike YAML uses dollar
    integers ($1 floor = min_count: 1). For sub-dollar floors,
    fractional thresholds via a separate field will land in a future
    Phase 2c (deliberately deferred to keep Phase 2b mechanical).
    """
    if now is None:
        now = datetime.now(UTC)

    window_width = timedelta(minutes=rule.window_minutes)
    current_start = now - window_width
    baseline_seconds = rule.baseline_window_hours * 3600
    window_seconds = rule.window_minutes * 60
    n_baseline_windows = max(1, baseline_seconds // window_seconds)
    baseline_start = current_start - timedelta(
        seconds=int(n_baseline_windows * window_seconds),
    )

    # Collect callers seen in the full baseline-or-current window.
    callers_seen: set[str] = set()
    for r in cost_rows:
        caller = str(r.get("caller", "")).strip()
        if not caller:
            continue
        ts = _parse_iso(str(r.get("timestamp", "")))
        if ts is None or ts < baseline_start:
            continue
        callers_seen.add(caller)

    out: list[Anomaly] = []
    for caller in callers_seen:
        # Current window total
        current_cost = _sum_cost_per_window(
            cost_rows,
            caller=caller,
            window_start=current_start,
            window_end=now,
        )
        # Absolute floor — don't flag tiny spend events even at huge
        # multipliers. AnomalyRule.min_count is repurposed as USD here.
        if current_cost < float(rule.min_count):
            continue

        # Baseline-window costs
        baseline_costs: list[float] = []
        for i in range(int(n_baseline_windows)):
            w_end = current_start - timedelta(seconds=int(i * window_seconds))
            w_start = w_end - window_width
            baseline_costs.append(_sum_cost_per_window(
                cost_rows,
                caller=caller,
                window_start=w_start,
                window_end=w_end,
            ))

        baseline = _median(baseline_costs)
        # Baseline-too-small floor — don't fire when normal spend is
        # near-zero. min_baseline_count repurposed as USD baseline floor.
        if baseline < float(rule.min_baseline_count):
            continue

        observed_ratio = (
            current_cost / baseline if baseline > 0 else float("inf")
        )
        if observed_ratio < rule.multiplier:
            continue

        # First/last timestamps from current-window rows for the
        # rationale.
        current_rows = [
            r for r in cost_rows
            if str(r.get("caller", "")).strip() == caller
            and (ts := _parse_iso(str(r.get("timestamp", "")))) is not None
            and current_start <= ts < now
        ]
        current_rows.sort(key=lambda r: r.get("timestamp", ""))
        first_iso = str(current_rows[0].get("timestamp", "")) if current_rows else ""
        last_iso = str(current_rows[-1].get("timestamp", "")) if current_rows else ""

        # Examples = up to 3 distinct models / actions
        seen: list[str] = []
        for r in current_rows:
            sample = (
                str(r.get("model", "")).strip()
                or str(r.get("action", "")).strip()
            )
            if sample and sample not in seen:
                seen.append(sample)
            if len(seen) >= 3:
                break

        out.append(
            Anomaly(
                rule_name=rule.name,
                kind=rule.kind,
                # actor field stays empty for cost_spike — the
                # cost-tracking caller is the relevant identity
                # dimension (see target property for how this routes
                # into the stable proposal id).
                actor="",
                error_type="",
                action_target="",
                caller=caller,
                cost_usd=current_cost,
                baseline_cost_usd=baseline,
                occurrences=len(current_rows),
                window_minutes=rule.window_minutes,
                severity=rule.severity,
                first_seen_iso=first_iso,
                last_seen_iso=last_iso,
                examples=seen,
                baseline_median=baseline,  # legacy field also populated
                multiplier_observed=observed_ratio,
            )
        )

    # Determinism: sort by (observed_ratio desc, caller asc).
    out.sort(key=lambda a: (-a.multiplier_observed, a.caller))
    return out


def _evaluate_rule(
    decisions: list[dict[str, Any]],
    rule: AnomalyRule,
    *,
    now: datetime | None = None,
) -> list[Anomaly]:
    """Dispatch a rule to its predicate. Returns [] for unknown kinds
    (defensive — caller logs a warning when shape is invalid; this
    catches mid-execution drift).

    Note: ``decisions`` argument name is legacy; for cost_spike it
    receives cost_log rows instead (caller responsibility — service
    must pass the right data source per rule kind).
    """
    if not rule.enabled:
        return []
    if rule.kind == "error_storm":
        return _evaluate_error_storm(decisions, rule, now=now)
    if rule.kind == "runaway_dispatch":
        return _evaluate_runaway_dispatch(decisions, rule, now=now)
    if rule.kind == "cost_spike":
        return _evaluate_cost_spike(decisions, rule, now=now)
    log.warning("agent_anomaly: unknown rule kind %r — skipping", rule.kind)
    return []


# ── Proposal-rendering helpers (pure, testable) ─────────────────────


def _render_error_storm_proposal(
    anomaly: Anomaly,
) -> tuple[str, str, str, dict[str, Any]]:
    """Render (title, description, rationale, payload) for an
    error_storm anomaly."""
    title = (
        f"Error storm: {anomaly.actor} hit {anomaly.error_type} "
        f"{anomaly.occurrences}× in {anomaly.window_minutes}m"
    )
    description = (
        f"Actor {anomaly.actor!r} produced the same error "
        f"({anomaly.error_type!r}) {anomaly.occurrences} times "
        f"between {anomaly.first_seen_iso} and "
        f"{anomaly.last_seen_iso} — {anomaly.window_minutes}-minute "
        f"window."
    )
    rationale = (
        f"Rule {anomaly.rule_name!r} (kind={anomaly.kind!r}) fired "
        f"because {anomaly.occurrences} matching rows exceeded the "
        f"threshold for {anomaly.window_minutes}m. This pattern "
        f"often indicates a runaway retry loop, a broken external "
        f"service (rate-limit / 5xx), or a regression in a tool "
        f"implementation. Review the affected targets in "
        f"/decisions filtered by actor={anomaly.actor!r} + "
        f"error_type={anomaly.error_type!r}."
    )
    payload = {
        "rule_name": anomaly.rule_name,
        "rule_kind": anomaly.kind,
        "actor": anomaly.actor,
        "error_type": anomaly.error_type,
        "occurrences": anomaly.occurrences,
        "window_minutes": anomaly.window_minutes,
        "severity": anomaly.severity,
        "first_seen_iso": anomaly.first_seen_iso,
        "last_seen_iso": anomaly.last_seen_iso,
        "examples": anomaly.examples,
    }
    return title, description, rationale, payload


def _render_runaway_dispatch_proposal(
    anomaly: Anomaly,
) -> tuple[str, str, str, dict[str, Any]]:
    """Render (title, description, rationale, payload) for a
    runaway_dispatch anomaly. Surfaces the multiplier-observed +
    baseline-median fields the user needs to judge whether this is a
    real loop vs legitimate burst (e.g. user-initiated backlog drain).
    """
    title = (
        f"Runaway dispatch: {anomaly.actor} → {anomaly.action_target} "
        f"{anomaly.occurrences}× in {anomaly.window_minutes}m "
        f"({anomaly.multiplier_observed:.1f}× baseline)"
    )
    description = (
        f"Actor {anomaly.actor!r} dispatched to "
        f"{anomaly.action_target!r} {anomaly.occurrences} times "
        f"between {anomaly.first_seen_iso} and "
        f"{anomaly.last_seen_iso} — "
        f"{anomaly.multiplier_observed:.1f}× the rolling baseline "
        f"of {anomaly.baseline_median:.1f} dispatches per "
        f"{anomaly.window_minutes}-minute window."
    )
    rationale = (
        f"Rule {anomaly.rule_name!r} (kind={anomaly.kind!r}) fired "
        f"because the dispatch count from {anomaly.actor!r} to "
        f"{anomaly.action_target!r} reached {anomaly.occurrences} in "
        f"the last {anomaly.window_minutes}m vs a median of "
        f"{anomaly.baseline_median:.1f} across recent windows — a "
        f"{anomaly.multiplier_observed:.1f}× spike. This pattern often "
        f"indicates a dispatch loop (orchestrator re-calling the same "
        f"subagent without progress), a stuck workflow, or a "
        f"legitimately heavy burst (backlog drain, scheduled batch). "
        f"Review /decisions filtered by actor={anomaly.actor!r} + "
        f"action_target={anomaly.action_target!r} to disambiguate."
    )
    payload = {
        "rule_name": anomaly.rule_name,
        "rule_kind": anomaly.kind,
        "actor": anomaly.actor,
        "action_target": anomaly.action_target,
        "occurrences": anomaly.occurrences,
        "window_minutes": anomaly.window_minutes,
        "severity": anomaly.severity,
        "first_seen_iso": anomaly.first_seen_iso,
        "last_seen_iso": anomaly.last_seen_iso,
        "examples": anomaly.examples,
        "baseline_median": anomaly.baseline_median,
        "multiplier_observed": anomaly.multiplier_observed,
    }
    return title, description, rationale, payload


def _render_cost_spike_proposal(
    anomaly: Anomaly,
) -> tuple[str, str, str, dict[str, Any]]:
    """Render (title, description, rationale, payload) for a
    cost_spike anomaly. Surfaces the current-window USD spend +
    baseline median + multiplier so the user can judge real-money
    impact in plain dollars without translating ratios.
    """
    title = (
        f"Cost spike: {anomaly.caller} spent ${anomaly.cost_usd:.2f} "
        f"in {anomaly.window_minutes}m "
        f"({anomaly.multiplier_observed:.1f}× baseline)"
    )
    description = (
        f"Caller {anomaly.caller!r} spent ${anomaly.cost_usd:.2f} "
        f"between {anomaly.first_seen_iso} and "
        f"{anomaly.last_seen_iso} — {anomaly.multiplier_observed:.1f}× "
        f"the rolling baseline of ${anomaly.baseline_cost_usd:.2f} per "
        f"{anomaly.window_minutes}-minute window. "
        f"{anomaly.occurrences} LLM calls in the window."
    )
    rationale = (
        f"Rule {anomaly.rule_name!r} (kind={anomaly.kind!r}) fired "
        f"because the spend from caller {anomaly.caller!r} reached "
        f"${anomaly.cost_usd:.2f} in the last {anomaly.window_minutes}m "
        f"vs a median of ${anomaly.baseline_cost_usd:.2f} across recent "
        f"windows — a {anomaly.multiplier_observed:.1f}× spike. This "
        f"pattern often indicates a runaway loop billing real money, "
        f"a heavier-tier model selected unexpectedly, or a legitimately "
        f"heavy burst (manual research / catch-up batch). Review "
        f"/admin/cost-routing-stats + /costs filtered by caller="
        f"{anomaly.caller!r} to disambiguate."
    )
    payload = {
        "rule_name": anomaly.rule_name,
        "rule_kind": anomaly.kind,
        "caller": anomaly.caller,
        "cost_usd": anomaly.cost_usd,
        "baseline_cost_usd": anomaly.baseline_cost_usd,
        "occurrences": anomaly.occurrences,
        "window_minutes": anomaly.window_minutes,
        "severity": anomaly.severity,
        "first_seen_iso": anomaly.first_seen_iso,
        "last_seen_iso": anomaly.last_seen_iso,
        "examples": anomaly.examples,
        "multiplier_observed": anomaly.multiplier_observed,
    }
    return title, description, rationale, payload


def render_proposal_for_anomaly(
    anomaly: Anomaly,
) -> tuple[str, str, str, dict[str, Any]]:
    """Render (title, description, rationale, payload) for any
    anomaly. Dispatches by ``anomaly.kind``; falls back to
    error_storm rendering for unknown kinds (defensive — never crash
    the proposal-write path)."""
    if anomaly.kind == "cost_spike":
        return _render_cost_spike_proposal(anomaly)
    if anomaly.kind == "runaway_dispatch":
        return _render_runaway_dispatch_proposal(anomaly)
    return _render_error_storm_proposal(anomaly)


def parse_rules(config: dict[str, Any]) -> list[AnomalyRule]:
    """Parse the YAML config into a list of AnomalyRule objects.

    Malformed rule entries are silently skipped (with a warning). An
    empty list is a legitimate result — caller treats it as "no rules
    enabled, nothing to do".
    """
    raw_rules = config.get("rules") or []
    if not isinstance(raw_rules, list):
        return []
    out: list[AnomalyRule] = []
    for entry in raw_rules:
        if not isinstance(entry, dict):
            continue
        rule = AnomalyRule.from_dict(entry)
        if rule is None:
            log.warning("agent_anomaly: skipping malformed rule entry: %r", entry)
            continue
        out.append(rule)
    return out


# ── Service ──────────────────────────────────────────────────────────


class AgentAnomalyDetector:
    """Heartbeat-driven detector. Construct once at boot, call
    ``detect_and_propose()`` periodically.

    Each call:

    1. Loads the YAML config (mtime-cached via skill_loader).
    2. Queries ``decision_log`` for rows in the widest configured
       window.
    3. Evaluates every enabled rule against the rows.
    4. Writes one proposal per anomaly to the user-approval queue.
    5. Skips writing if a pending proposal already exists with the
       same stable id AND ``skip_if_pending=True`` (default).

    Stateless across calls — re-running with no new anomalies is a
    no-op. Anomalies are deduplicated by stable id keyed on
    (rule, actor, error_type).
    """

    def __init__(
        self,
        vault_dir: Path,
        decision_logger,
        skill_loader,
        *,
        config: dict[str, Any] | None = None,
        cost_tracker=None,
    ):
        self._vault_dir = Path(vault_dir)
        self._decisions = decision_logger
        self._skill_loader = skill_loader
        self._explicit_config = dict(config) if config else None
        self._activity = None
        # Phase 2b — cost_spike rule reads cost_log. Optional; rules
        # of kind cost_spike skip with a debug log when not wired.
        self._cost_tracker = cost_tracker

    # ── Config resolution ──────────────────────────────────────────

    def _load_config(self) -> dict[str, Any]:
        """Load YAML config via skill_loader. Fall back to
        ``_FALLBACK_CONFIG`` on any failure."""
        if self._explicit_config is not None:
            return self._explicit_config
        if self._skill_loader is None:
            return dict(_FALLBACK_CONFIG)
        try:
            data = self._skill_loader.load_skill_config_file(
                "agent-anomaly", "rules.yaml",
            )
            if isinstance(data, dict) and data:
                return data
        except Exception:
            log.debug("agent_anomaly: YAML load failed, using fallback", exc_info=True)
        return dict(_FALLBACK_CONFIG)

    @property
    def enabled(self) -> bool:
        return bool(self._load_config().get("enabled", True))

    @property
    def cadence_hours(self) -> int:
        return max(1, int(self._load_config().get("cadence_hours", 1)))

    @property
    def skip_if_pending(self) -> bool:
        return bool(self._load_config().get("skip_if_pending", True))

    @property
    def cooldown_hours(self) -> int:
        return int(self._load_config().get("cooldown_hours", 24))

    # ── Main entrypoint ────────────────────────────────────────────

    async def detect_and_propose(self) -> dict[str, Any]:
        """One-shot scan. Returns a structured report."""
        config = self._load_config()
        if not bool(config.get("enabled", True)):
            return {
                "skipped": "disabled",
                "decisions_scanned": 0,
                "rules_evaluated": 0,
                "anomalies_found": 0,
                "proposals_written": 0,
                "skipped_dedup": 0,
            }

        rules = parse_rules(config)
        if not rules:
            return {
                "skipped": "no_rules",
                "decisions_scanned": 0,
                "rules_evaluated": 0,
                "anomalies_found": 0,
                "proposals_written": 0,
                "skipped_dedup": 0,
            }

        # Compute the widest LOOKBACK across all enabled rules.
        # Each rule needs decision rows covering the FULL baseline
        # window (window_minutes + baseline_window_hours), NOT just
        # window_minutes — otherwise rolling-baseline predicates see
        # empty baseline buckets and never fire. This bug was latent
        # in Phase 2a (error_storm only needs window_minutes; tests
        # bypassed the query layer with stub loggers so the bug
        # didn't surface). Caught + fixed alongside Phase 2b cost_spike
        # which would have re-tripped the same issue.
        def _rule_lookback_minutes(r: AnomalyRule) -> int:
            if r.kind in ("runaway_dispatch", "cost_spike"):
                return r.window_minutes + (r.baseline_window_hours * 60)
            return r.window_minutes

        widest_minutes = max(
            (_rule_lookback_minutes(r) for r in rules if r.enabled),
            default=int(config.get("default_window_minutes", 60)),
        )
        now = datetime.now(UTC)
        cutoff = now - timedelta(minutes=widest_minutes)
        cutoff_iso = cutoff.strftime("%Y-%m-%dT%H:%M:%SZ")

        # Query decision log when ANY non-cost rule is enabled. Cap
        # at 5000 rows to bound memory; if we ever blow this on a real
        # vault, the rule windows are too wide (or the system is in
        # catastrophic-failure state, in which case the user already
        # knows).
        needs_decisions = any(
            r.enabled and r.kind in ("error_storm", "runaway_dispatch")
            for r in rules
        )
        needs_cost = any(
            r.enabled and r.kind == "cost_spike" for r in rules
        )

        decisions: list[dict[str, Any]] = []
        if needs_decisions:
            try:
                decisions = await self._decisions.query(
                    since=cutoff_iso, limit=5000,
                )
            except Exception:
                log.exception("agent_anomaly: decision_log query failed")
                return {
                    "error": "query_failed",
                    "decisions_scanned": 0,
                    "rules_evaluated": len(rules),
                    "anomalies_found": 0,
                    "proposals_written": 0,
                    "skipped_dedup": 0,
                }

        # Query cost log when cost_spike rules are enabled. include_local
        # because runaway loops on local Ollama still consume real
        # wall-clock + GPU; the user wants to see them flagged.
        cost_rows: list[dict[str, Any]] = []
        if needs_cost:
            if self._cost_tracker is None:
                log.debug(
                    "agent_anomaly: cost_spike rules present but no cost_tracker wired; skipping",
                )
            else:
                try:
                    cost_rows = await self._cost_tracker.get_exposure_recent(
                        limit=5000, include_local=True,
                    )
                except Exception:
                    log.exception("agent_anomaly: cost_log query failed")
                    # Don't kill the whole run — error_storm + runaway_dispatch
                    # rules still fire against decisions. Cost rules skip
                    # this cycle with empty data.
                    cost_rows = []

        # Evaluate every enabled rule against the right data source.
        all_anomalies: list[Anomaly] = []
        for rule in rules:
            try:
                if rule.kind == "cost_spike":
                    all_anomalies.extend(_evaluate_rule(cost_rows, rule, now=now))
                else:
                    all_anomalies.extend(_evaluate_rule(decisions, rule, now=now))
            except Exception:
                log.exception(
                    "agent_anomaly: rule %r evaluation failed", rule.name,
                )

        # Write proposals (dedup against pending).
        existing_ids: set[str] = set()
        if self.skip_if_pending:
            try:
                for p in list_pending(self._vault_dir, "agent-anomaly"):
                    existing_ids.add(p.proposal_id)
            except Exception:
                pass

        proposals_written = 0
        skipped_dedup = 0
        proposal_records: list[dict[str, Any]] = []
        write_errors: list[dict[str, Any]] = []

        for anomaly in all_anomalies:
            stable_id = stable_proposal_id("agent-anomaly", anomaly.target)
            if self.skip_if_pending and stable_id in existing_ids:
                skipped_dedup += 1
                continue

            # Kind-dispatched proposal rendering. Each kind owns its
            # own title/description/rationale/payload shape. Pure
            # helper — testable in isolation.
            title, description, rationale, payload = render_proposal_for_anomaly(anomaly)

            proposal, err = write_proposal(
                self._vault_dir,
                "agent-anomaly",
                target=anomaly.target,
                title=title,
                description=description,
                rationale=rationale,
                proposed_by="agent-anomaly-detector",
                examples=anomaly.examples,
                payload=payload,
            )
            if proposal is None:
                write_errors.append({
                    "target": anomaly.target,
                    "error": err,
                })
                continue
            proposals_written += 1
            proposal_records.append({
                "target": anomaly.target,
                "actor": anomaly.actor,
                "error_type": anomaly.error_type,
                "occurrences": anomaly.occurrences,
                "severity": anomaly.severity,
                "proposal_id": proposal.proposal_id,
            })

        if self._activity is not None and (proposals_written or skipped_dedup):
            try:
                # importance follows the worst severity flagged this
                # cycle so a single 'high' surfaces with appropriate
                # weight even when other items are 'low'.
                severities = Counter(a.severity for a in all_anomalies)
                importance = (
                    "high" if severities.get("high")
                    else "medium" if proposals_written
                    else "low"
                )
                await self._activity.log(
                    category="agent",
                    action="agent_anomaly_proposals",
                    summary=(
                        f"Detected {len(all_anomalies)} anomaly(s); "
                        f"wrote {proposals_written} proposal(s), "
                        f"skipped {skipped_dedup} already-pending."
                    ),
                    details={
                        "decisions_scanned": len(decisions),
                        "rules_evaluated": len(rules),
                        "anomalies_found": len(all_anomalies),
                        "proposals_written": proposals_written,
                        "skipped_dedup": skipped_dedup,
                        "severities": dict(severities),
                        "proposals": proposal_records[:20],
                        "write_errors": write_errors[:5],
                    },
                    importance=importance,
                )
            except Exception:
                pass

        return {
            "decisions_scanned": len(decisions),
            "rules_evaluated": len(rules),
            "anomalies_found": len(all_anomalies),
            "proposals_written": proposals_written,
            "skipped_dedup": skipped_dedup,
            "proposals": proposal_records,
            "write_errors": write_errors,
        }
