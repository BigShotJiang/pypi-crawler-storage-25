"""WebSocket handler for streaming chat."""

from __future__ import annotations

import json
import logging
import time

from fastapi import WebSocket, WebSocketDisconnect

log = logging.getLogger(__name__)

# P4.7 follow-up (2026-05-17) — chunk batching constants. Cloud LLMs emit
# 50-200 chunks/sec; without batching each chunk is a JSON-serialize +
# send_json + frame-lock cycle. Batching collapses 100+ syscalls/sec into
# ~30/sec while staying under the 50ms perception threshold so the user
# never sees a "stutter" in the chat reply.
#
# Time window: 25ms. UI's RAF batching is 16ms; 25ms means at most one
# batch coalesces per UI render frame. Smaller and we'd batch nothing in
# practice; larger and the chat starts to feel like it's "typing in
# bursts" instead of streaming.
#
# Char ceiling: 96. A typical English LLM chunk is 5-15 chars; 96 chars =
# 8-16 chunks per flush. Hard ceiling protects responsiveness if the time
# window is delayed by other awaits in the loop.
_CHUNK_BATCH_INTERVAL_SECONDS: float = 0.025  # arch:deterministic — UX perception floor
_CHUNK_BATCH_MAX_CHARS: int = 96  # arch:deterministic — responsiveness ceiling


async def _flush_chunk_buffer(
    websocket: WebSocket,
    buffer: list[str],
    *,
    done: bool,
    model: str = "",
) -> None:
    """Send accumulated chunk deltas as ONE WS frame.

    No-op when buffer is empty AND not done. When done=True with empty
    buffer, still sends the terminal frame (UI's finalizeLastMessage
    gates on done=True).

    ``model`` (2026-05-23) — when set on the final (done=True) frame,
    carries the LLM model id that produced this turn. UI stamps it on
    the streaming message + renders a per-message chip ("via gpt-5.4"
    / "via local · qwen2.5:14b"). Empty string omits the field so
    older clients see byte-identical pre-2026-05-23 frames.

    Module-level helper (not nested in the WS loop) so closures don't
    capture loop-iteration state — keeps ruff B023 quiet.
    """
    if not buffer and not done:
        return
    delta = "".join(buffer)
    buffer.clear()
    payload: dict = {
        "type": "chunk",
        "delta": delta,
        "done": done,
    }
    if done and model:
        payload["model"] = model
    await websocket.send_json(payload)


async def ws_chat_handler(websocket: WebSocket, conversation_id: str) -> None:
    """Handle a WebSocket chat connection.

    Protocol:
    - Client sends: {"message": "user text"}
    - Server sends: {"type": "chunk", "delta": "text", "done": false}
    - Server sends: {"type": "chunk", "delta": "", "done": true} on completion
    - Server sends: {"type": "title", "title": "..."} after auto-titling
    """
    await websocket.accept()
    agent = websocket.app.state.agent
    memory = websocket.app.state.memory

    # Conversation row is created lazily on first add_message — opening a WS
    # without sending anything must not leave an empty row behind.

    log.info("WebSocket connected: conversation=%s", conversation_id)

    # P3.2 — Auto-resume hello handshake (Hermes-borrow).
    # If the user already had a chat turn in flight when this WS connected
    # (e.g. a reconnect after a network blip while the agent was processing
    # a slow tool call), the TurnRegistry will show phase != "idle" for
    # this conversation. Send the current state so the UI can render the
    # "still working" indicator immediately instead of polling the status
    # endpoint to discover it. Fail-soft: missing registry / broken state
    # → skip the hello, fall through to the normal receive-loop.
    try:
        registry = getattr(websocket.app.state, "turn_registry", None)
        if registry is not None:
            state = registry.get_status(conversation_id)
            if state is not None:
                await websocket.send_json({
                    "type": "in_flight",
                    "state": state.to_dict(),
                })
    except Exception:
        log.debug("WS hello handshake failed", exc_info=True)

    # P4.4 — fire predictive context prefetch (fire-and-forget). Pre-warms
    # the per-conversation cache slots (budget, recent messages, in-focus
    # artifact) so the first chat turn after this connect reads from
    # cache instead of SQLite. The prefetch runs in the background; we
    # never await it — if the user sends a message before prefetch
    # completes, the chat path will fall through to live fetch as
    # before. Fail-soft: missing cache, fetch failures, prefetch
    # exception → no impact on the chat path.
    try:
        prefetch_cache = getattr(websocket.app.state, "prefetch_cache", None)
        if prefetch_cache is not None:
            import asyncio
            asyncio.create_task(prefetch_cache.prefetch(conversation_id))
    except Exception:
        log.debug("WS prefetch dispatch failed", exc_info=True)

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send_json({"type": "error", "message": "Invalid JSON"})
                continue

            # Keepalive ping from client
            if data.get("type") == "ping":
                await websocket.send_json({"type": "pong"})
                continue

            # Regenerate path — the client just hit Try-again on the last
            # assistant reply, OR it just edited a user message via PATCH.
            # The REST route already truncated everything after the target
            # user message; we only need to produce a fresh reply against
            # the truncated history without inserting a new user row.
            #
            # Resolution rules:
            #   1. If the client passes ``message`` (the replay text from
            #      the REST response), use it. Cheaper — no extra DB read.
            #   2. Otherwise look up the last user message ourselves so
            #      raw ``{regenerate: true}`` works as a one-shot signal.
            #   3. If no user message exists at all, surface an error so
            #      the UI can recover (it's a bug, not a normal path).
            is_regenerate = bool(data.get("regenerate"))
            if is_regenerate:
                user_message = data.get("message", "").strip()
                if not user_message:
                    last = await memory.get_last_user_message(conversation_id)
                    if not last:
                        await websocket.send_json({
                            "type": "error",
                            "message": "No user message to regenerate from",
                        })
                        continue
                    user_message = last["content"]
            else:
                user_message = data.get("message", "").strip()
                if not user_message:
                    await websocket.send_json({"type": "error", "message": "Empty message"})
                    continue

            try:
                _provenance = {
                    "kind": "chat_stream_regenerate" if is_regenerate else "chat_stream",
                    "source_channel": "websocket",
                }
                # P4.7 follow-up (2026-05-17) — chunk batching state. Buffer
                # accumulates deltas; flush triggers on (a) time window
                # elapsed, (b) char ceiling hit, (c) done=True, or (d) a
                # tool_status event arrives (must preserve order: any
                # pending deltas flush BEFORE the event). Tracks the timer
                # AFTER first append so the first chunk lands as fast as
                # the LLM produces it (no artificial first-chunk delay).
                _buffer: list[str] = []
                _buffer_started_at: float = 0.0

                async for chunk in agent.chat_stream(
                    conversation_id, user_message,
                    provenance=_provenance,
                    skip_user_add=is_regenerate,
                ):
                    # P4.7 (2026-05-19) — correlation_id event. The agent
                    # emits this as the first chunk of every turn so the UI
                    # can match this assistant message to activity events
                    # fired by tools running inside the same correlation
                    # scope. Event-shaped (empty delta), pre-empts the
                    # buffer.  Older clients that don't read the field
                    # see byte-identical pre-P4.7 behavior — the empty-
                    # delta chunk produces no visible side effect on the
                    # delta-append path.
                    _chunk_corr_id = getattr(chunk, "correlation_id", "") or ""
                    if _chunk_corr_id:
                        if _buffer:
                            await _flush_chunk_buffer(websocket, _buffer, done=False)
                            _buffer_started_at = 0.0
                        await websocket.send_json({
                            "type": "correlation_id",
                            "correlation_id": _chunk_corr_id,
                        })

                    # Send tool status events for visibility. Event-shaped,
                    # not stream-shaped — flush any pending deltas FIRST so
                    # the UI sees them before the tool indicator.
                    if hasattr(chunk, "tool_name") and chunk.tool_name:
                        if _buffer:
                            await _flush_chunk_buffer(websocket, _buffer, done=False)
                            _buffer_started_at = 0.0
                        await websocket.send_json({
                            "type": "tool_status",
                            "tool": chunk.tool_name,
                            "status": chunk.tool_status or "running",
                        })

                    # P4.5 — speculative streaming retract. Event-shaped:
                    # flush any pending deltas FIRST so the client retracts
                    # against what it actually has on screen, not against
                    # an out-of-date snapshot. Then emit the retract event.
                    # If the chunk ALSO carries a delta (real replacement
                    # text), append it after the retract has been sent.
                    _replace_after = getattr(chunk, "replace_after", None)
                    if _replace_after:
                        if _buffer:
                            await _flush_chunk_buffer(websocket, _buffer, done=False)
                            _buffer_started_at = 0.0
                        await websocket.send_json({
                            "type": "chunk",
                            "delta": "",
                            "replace_after": int(_replace_after),
                            "done": False,
                        })

                    if chunk.delta:
                        if not _buffer:
                            _buffer_started_at = time.monotonic()
                        _buffer.append(chunk.delta)

                    # Flush triggers — done flushes immediately + carries
                    # the done flag. Otherwise flush when buffer hits the
                    # char ceiling or the time window elapsed. Pass the
                    # model id from the LLM response (when present) on
                    # the final frame so the UI can render the per-
                    # message chip without a refetch.
                    if chunk.done:
                        _model = ""
                        if chunk.response is not None and getattr(chunk.response, "model", None):
                            _model = chunk.response.model
                        await _flush_chunk_buffer(
                            websocket, _buffer, done=True, model=_model,
                        )
                        _buffer_started_at = 0.0
                    elif _buffer:
                        elapsed = time.monotonic() - _buffer_started_at
                        total_chars = sum(len(d) for d in _buffer)
                        if total_chars >= _CHUNK_BATCH_MAX_CHARS or elapsed >= _CHUNK_BATCH_INTERVAL_SECONDS:
                            await _flush_chunk_buffer(websocket, _buffer, done=False)
                            _buffer_started_at = 0.0
                # After streaming completes, auto-title in the background
                # so it never blocks the handler from processing the next
                # user message (was causing "infinite thinking" on the
                # second message in a conversation).
                import asyncio

                async def _auto_title() -> None:
                    try:
                        new_title = await memory.auto_title(
                            conversation_id, llm=agent._llm,
                        )
                        if new_title:
                            await websocket.send_json({
                                "type": "title",
                                "title": new_title,
                            })
                    except Exception:
                        log.debug("Auto-title failed", exc_info=True)

                asyncio.create_task(_auto_title())
            except Exception as exc:
                from agntspace.infra.cost_tracker import BudgetExceededError
                from agntspace.llm.base import LLMError

                if isinstance(exc, BudgetExceededError):
                    log.warning("Budget exceeded during chat: %s", exc)
                    detail = f"⚠ {exc}"
                elif isinstance(exc, LLMError):
                    log.error("LLM error during chat: %s", exc.user_message)
                    detail = exc.user_message
                else:
                    log.exception("Error during streaming response")
                    detail = str(exc)
                    if len(detail) > 300:
                        detail = detail[:300] + "…"
                await websocket.send_json({
                    "type": "error",
                    "message": detail or "Internal error during response generation",
                })
    except WebSocketDisconnect:
        log.info("WebSocket disconnected: conversation=%s", conversation_id)
