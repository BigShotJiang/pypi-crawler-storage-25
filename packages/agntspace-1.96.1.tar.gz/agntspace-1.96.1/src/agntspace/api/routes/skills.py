"""Skills and SkillSchool API endpoints."""

from __future__ import annotations

from datetime import UTC
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/skills", tags=["skills"])


class SkillUpdateRequest(BaseModel):
    content: str


class SkillCreateRequest(BaseModel):
    name: str
    title: str
    description: str
    category: str = "private"
    triggers: list[str] = []
    instructions: str = ""
    author: str = "user"
    tools_granted: list[str] = []
    depends_on: list[str] = []
    priority: int = 0
    model_tier: str = ""
    examples: list[dict] = []
    output_format: str = ""


class SkillImportRequest(BaseModel):
    """Phase 5 import request.

    Either ``source`` (preferred — accepts local paths, GitHub URLs,
    GitHub shorthand like ``owner/repo``, git URLs, zip URLs) or the
    legacy ``path`` (local-only) must be set. ``source`` wins when
    both are present.

    ``category`` defaults to inferred:
      * URL-based sources → ``community`` (ecosystem-imported, hash-gated)
      * Local sources → ``private`` (user-authored, never shipped)

    Pass an explicit ``category`` to override the inference.

    ``force=true`` bypasses agentskills.io spec validation but emits a
    high-importance ``skill_import_force_override`` activity event so
    the audit trail records the override.
    """

    path: str = ""
    source: str = ""
    category: str = ""  # empty → inferred from source kind
    overwrite: bool = False
    force: bool = False


class SkillImportPreviewRequest(BaseModel):
    """Read-only preview — resolves the source, validates SKILL.md,
    returns the validation report + inferred category + provenance hint.

    Never copies anything. Safe to call on every keystroke.
    """

    source: str


class SkillFileRequest(BaseModel):
    content: str


@router.get("")
async def list_skills(request: Request) -> list[dict]:
    """List all loaded skills."""
    skills = request.app.state.skills
    return skills.list_skills()


@router.post("/analyze")
async def analyze_patterns(request: Request) -> list[dict]:
    """Run SkillSchool pattern analysis on completed tasks."""
    skillschool = request.app.state.skillschool
    return await skillschool.analyze_patterns()


# ── Voyager-style semantic skill retrieval (2026-04-24) ──────────────

@router.get("/match")
async def match_skills(
    request: Request,
    q: str,
    top_k: int = 5,
    scope: str | None = None,
    min_score: float = 0.0,
) -> dict:
    """Find skills most semantically related to a task description.

    Query parameters:
      - ``q``: free-form task text (required)
      - ``top_k``: max matches to return (default 5, capped at 50)
      - ``scope``: optional comma-separated skill-name allowlist
      - ``min_score``: cosine similarity floor (default 0 — no filtering)

    Returns ``{query, hits: [{name, title, description, score}], fallback}``.
    When the embedding provider isn't wired (Ollama not running, or the
    embedding model isn't pulled), ``hits`` is empty and ``fallback=true``
    — callers should treat that as "retrieval unavailable, use priority
    order".
    """
    skills = request.app.state.skills

    top_k = max(1, min(50, int(top_k)))
    scope_list: list[str] | None = None
    if scope:
        scope_list = [s.strip() for s in scope.split(",") if s.strip()]

    matches = skills.find_matching_skills(
        task_text=q,
        top_k=top_k,
        scope=scope_list,
        min_score=float(min_score),
    )

    hits: list[dict] = []
    for name, score in matches:
        skill = skills.get_skill(name)
        if skill is None:
            continue
        hits.append({
            "name": skill.name,
            "title": skill.title,
            "description": skill.description,
            "score": round(float(score), 4),
            "category": skill.category,
            "priority": skill.priority,
        })

    return {
        "query": q,
        "hits": hits,
        "fallback": len(matches) == 0,
    }


# ── Hybrid skill sync (upgrades from shipped defaults) ──────────────────
#
# Registered BEFORE the catch-all GET /{skill_name} below so `/sync/*`
# paths aren't swallowed by the skill-name matcher.

def _build_skill_sync(request: Request):  # noqa: ANN202
    """Construct a SkillSync bound to the current vault + shipped defaults."""
    from agntspace.setup.init import _find_defaults_dir as _find_app_defaults
    from agntspace.skills.sync import SkillSync
    settings = request.app.state.settings
    return SkillSync(
        skills_dir=settings.skills_dir,
        defaults_dir=_find_app_defaults() / "skills",
    )


@router.get("/sync/status")
async def sync_status(request: Request) -> dict:
    """Cheap status read — counts only, no diff content."""
    try:
        sync = _build_skill_sync(request)
    except FileNotFoundError:
        return {"shipped_count": 0, "tracked": 0, "pending_count": 0, "pending_paths": []}
    return sync.status()


@router.get("/sync/pending")
async def sync_pending(request: Request) -> list[dict]:
    """List pending upgrades with full shipped+vault content for diffing."""
    try:
        sync = _build_skill_sync(request)
    except FileNotFoundError:
        return []
    return [
        {
            "path": p.path,
            "shipped_hash": p.shipped_hash,
            "accepted_hash": p.accepted_hash,
            "vault_hash": p.vault_hash,
            "shipped_content": p.shipped_content,
            "vault_content": p.vault_content,
            "classification": p.classification,
            "vault_edited": p.vault_edited,
        }
        for p in sync.list_pending()
    ]


@router.post("/sync/run")
async def sync_run(request: Request) -> dict:
    """Force an immediate sync pass (normally runs at boot)."""
    try:
        sync = _build_skill_sync(request)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    report = sync.sync_on_boot()
    # Reload the in-memory skill catalog so the new versions take effect
    # without a server restart.
    request.app.state.skills.load_all()
    return {
        "summary": report.summary(),
        "created": report.created,
        "overwritten_meta": report.overwritten_meta,
        "upgraded_clean": report.upgraded_clean,
        "skipped_user_edit": report.skipped_user_edit,
        "pending": report.pending,
    }


class SyncDecisionRequest(BaseModel):
    path: str


@router.post("/sync/accept")
async def sync_accept(request: Request, body: SyncDecisionRequest) -> dict:
    """User accepts the shipped version for a single pending path."""
    try:
        sync = _build_skill_sync(request)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    ok = sync.accept_upgrade(body.path)
    if not ok:
        raise HTTPException(status_code=404, detail=f"No pending upgrade for {body.path}")
    request.app.state.skills.load_all()
    return {"status": "accepted", "path": body.path}


@router.post("/sync/keep-mine")
async def sync_keep_mine(request: Request, body: SyncDecisionRequest) -> dict:
    """User chooses to keep their vault edit; manifest is pinned to it."""
    try:
        sync = _build_skill_sync(request)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    ok = sync.keep_mine(body.path)
    if not ok:
        raise HTTPException(status_code=404, detail=f"No pending upgrade for {body.path}")
    return {"status": "kept", "path": body.path}


def _slugify_skill_name(raw: str, fallback: str = "") -> str:
    """Reduce a name to the agentskills.io slug pattern.

    Lowercase, hyphens only, drop everything else. 60-char cap so the
    resulting folder name is filesystem-safe everywhere. Fallback is
    used when the primary input becomes empty after sanitization.
    """
    import re as _re
    out = _re.sub(r"[^a-z0-9-]", "", str(raw).lower().replace(" ", "-"))[:60].strip("-")
    if not out and fallback:
        out = _re.sub(r"[^a-z0-9-]", "", fallback.lower().replace(" ", "-"))[:60].strip("-")
    return out


@router.post("/import/preview")  # workflow:trivial — read-only preview, no vault mutation; covered by tests/unit/skills/test_import_route.py::TestPreview
async def import_skill_preview(request: Request, body: SkillImportPreviewRequest) -> dict:
    """Read-only preview for the Import Skill UI dialog.

    Resolves the source (download/clone if needed, but to a temp dir
    that's destroyed on return), parses SKILL.md, validates against
    the agentskills.io spec, and returns the structured report plus
    the inferred category + a stable provenance string. NEVER writes
    to the vault and NEVER touches the loaded skill catalog.

    UI consumers call this on every meaningful change to the source
    field so the dialog can show live feedback before commit.
    """
    from agntspace.skills.import_source import (
        SkillImportError,
        default_category_for,
        detect_source_kind,
        resolve_source,
    )
    from agntspace.skills.spec_validator import validate_skill_path

    src = (body.source or "").strip()
    if not src:
        raise HTTPException(status_code=400, detail="source is empty")

    detected_kind = detect_source_kind(src)
    inferred_category = default_category_for(detected_kind)

    try:
        with resolve_source(src) as resolved:
            report = validate_skill_path(resolved.folder)
            import frontmatter as _fm
            skill_md = resolved.folder / "SKILL.md"
            try:
                raw = skill_md.read_text(encoding="utf-8")
                if raw.startswith("﻿"):
                    raw = raw.lstrip("﻿")
                post = _fm.loads(raw)
                meta = post.metadata or {}
            except Exception:
                meta = {}

            slug = _slugify_skill_name(
                str(meta.get("name", "")) or resolved.folder.name,
                fallback=resolved.folder.name,
            )
            title = str(meta.get("title", "") or meta.get("name", slug))

            return {
                "ok": True,
                "kind": resolved.kind,
                "canonical": resolved.canonical,
                "inferred_category": inferred_category,
                "slug": slug,
                "title": title,
                "validation": report.to_dict(),
            }
    except SkillImportError as exc:
        return {
            "ok": False,
            "kind": detected_kind,
            "canonical": src,
            "inferred_category": inferred_category,
            "error": str(exc),
        }


@router.post("/import")
async def import_skill(request: Request, body: SkillImportRequest) -> dict:
    """Import a skill from a local path, git URL, zip URL, or GitHub source.

    Phase 5 — agentskills.io ecosystem-import path. Resolves the source,
    validates the resulting SKILL.md against the agentskills.io spec
    (rejected unless ``force=true``), copies the folder into
    ``system/skills/{category}/{slug}/``, stamps provenance metadata
    (``imported_from``, ``imported_at``, ``imported_kind``) into the
    SKILL.md's ``metadata:`` block, reloads the SkillLoader.
    """
    import shutil
    from datetime import datetime
    from pathlib import Path as P

    import frontmatter as fm

    from agntspace.skills.import_source import (
        SkillImportError,
        default_category_for,
        resolve_source,
    )
    from agntspace.skills.spec_validator import validate_skill_path

    source_str = (body.source or body.path or "").strip()
    if not source_str:
        raise HTTPException(status_code=400, detail="source or path is required")

    try:
        source_ctx = resolve_source(source_str)
    except SkillImportError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    try:
        with source_ctx as resolved:
            source_dir = resolved.folder
            kind = resolved.kind
            canonical = resolved.canonical

            report = validate_skill_path(source_dir)
            if not report.valid and not body.force:
                error_codes = [
                    f"{e.code} [{e.field}]: {e.message}"
                    for e in report.errors[:5]
                ]
                msg = (
                    f"agentskills.io validation failed for {canonical}. "
                    "Pass force=true to import anyway. Errors: "
                    + " | ".join(error_codes)
                )
                raise HTTPException(status_code=422, detail=msg)

            skill_md = source_dir / "SKILL.md"
            try:
                raw = skill_md.read_text(encoding="utf-8")
                if raw.startswith("﻿"):
                    raw = raw.lstrip("﻿")
                post = fm.loads(raw)
            except Exception as exc:
                raise HTTPException(status_code=400,
                                    detail=f"Failed to parse SKILL.md: {exc}") from exc

            if not post.metadata and "---" in post.content:
                try:
                    retry = fm.loads(post.content.lstrip())
                    if retry.metadata:
                        post = retry
                except Exception:
                    pass

            meta = post.metadata or {}
            slug = _slugify_skill_name(
                str(meta.get("name", "")) or source_dir.name,
                fallback=source_dir.name,
            )
            if not slug:
                raise HTTPException(status_code=400,
                                    detail="Could not derive a valid skill slug")

            category = body.category or default_category_for(kind)

            skills = request.app.state.skills
            existing = skills.get_skill(slug)
            if existing and not body.overwrite:
                raise HTTPException(
                    status_code=409,
                    detail=(
                        f"Skill '{slug}' already exists at {existing.path}. "
                        "Re-import with overwrite=true to replace it."
                    ),
                )

            settings = request.app.state.settings
            settings_skills_root = P(settings.skills_dir)

            if existing and body.overwrite:
                existing_dir = (settings_skills_root / existing.path).parent
                try:
                    if (
                        existing_dir.is_dir()
                        and existing_dir.resolve().is_relative_to(
                            settings_skills_root.resolve()
                        )
                    ):
                        shutil.rmtree(existing_dir)
                except Exception as exc:
                    raise HTTPException(
                        status_code=500,
                        detail=f"Failed to remove existing skill: {exc}",
                    ) from exc

            dest = settings_skills_root / category / slug
            dest.mkdir(parents=True, exist_ok=True)

            copied_files: list[str] = []
            for item in source_dir.rglob("*"):
                if not item.is_file():
                    continue
                rel_parts = item.relative_to(source_dir).parts
                if rel_parts and rel_parts[0] == ".git":
                    continue
                rel = item.relative_to(source_dir)
                target = dest / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, target)
                copied_files.append(str(rel).replace("\\", "/"))

            dest_skill_md = dest / "SKILL.md"
            try:
                post.metadata["status"] = "active"
                post.metadata["category"] = category
                post.metadata.pop("signature", None)
                post.metadata.pop("publisher", None)

                meta_block = post.metadata.get("metadata")
                if not isinstance(meta_block, dict):
                    meta_block = {}
                meta_block["imported_from"] = canonical
                meta_block["imported_kind"] = kind
                meta_block["imported_at"] = datetime.now(UTC).isoformat()
                if body.force and not report.valid:
                    meta_block["import_force_override"] = True
                post.metadata["metadata"] = meta_block

                dest_skill_md.write_text(fm.dumps(post), encoding="utf-8")
            except Exception as exc:
                raise HTTPException(
                    status_code=500,
                    detail=f"Failed to normalize SKILL.md: {exc}",
                ) from exc

            skills.load_all()
            loaded = skills.get_skill(slug)

            activity = getattr(request.app.state, "activity_logger", None)
            if activity is not None:
                try:
                    if body.force and not report.valid:
                        activity.log(
                            category="user_override",
                            action="skill_import_force_override",
                            summary=f"Force-imported {slug} from {canonical}",
                            details={
                                "slug": slug,
                                "canonical": canonical,
                                "kind": kind,
                                "category": category,
                                "errors": [
                                    {"code": e.code, "field": e.field}
                                    for e in report.errors[:10]
                                ],
                            },
                            importance="high",
                        )
                    else:
                        activity.log(
                            category="user",
                            action="skill_imported",
                            summary=f"Imported {slug} from {canonical}",
                            details={
                                "slug": slug,
                                "canonical": canonical,
                                "kind": kind,
                                "category": category,
                                "files_copied": len(copied_files),
                            },
                            importance="medium",
                        )
                except Exception:
                    pass

            return {
                "status": "imported",
                "name": slug,
                "title": loaded.title if loaded else meta.get("title", slug),
                "category": category,
                "kind": kind,
                "canonical": canonical,
                "path": f"system/skills/{category}/{slug}/SKILL.md",
                "files_copied": len(copied_files),
                "files": copied_files,
                "validation_passed": report.valid,
                "force_override": bool(body.force and not report.valid),
            }
    except HTTPException:
        raise
    except SkillImportError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.delete("/{skill_name}")
async def delete_skill(request: Request, skill_name: str) -> dict:
    """Remove a skill folder from the vault and reload the loader.

    Only skills under the vault's skills_dir may be deleted — this prevents a
    path-traversal slug from reaching into defaults or anywhere else on disk.
    Skills in the shipped `_meta/` engine tier are also refused; users can
    disable them via status in frontmatter but shouldn't delete them outright.
    """
    import shutil
    from pathlib import Path as P

    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")

    if skill.category == "_meta":
        raise HTTPException(
            status_code=403,
            detail="Engine-tier (_meta) skills can't be deleted — disable via frontmatter status instead.",
        )

    settings = request.app.state.settings
    skills_root = P(settings.skills_dir).resolve()
    skill_dir = (P(settings.skills_dir) / skill.path).parent
    try:
        resolved = skill_dir.resolve()
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Cannot resolve skill folder: {exc}") from exc

    if not resolved.is_relative_to(skills_root):
        raise HTTPException(status_code=403, detail="Skill path escapes skills directory")

    try:
        if resolved.is_dir():
            shutil.rmtree(resolved)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to delete skill: {exc}") from exc

    skills.load_all()
    return {"status": "deleted", "name": skill_name}


@router.get("/{skill_name}/validate")
async def validate_skill(request: Request, skill_name: str) -> dict:
    """Validate a skill against the agentskills.io specification.

    Pure read — never mutates the skill or its files. Returns the same
    ``ValidationReport.to_dict()`` shape as the CLI's ``skill-validate``
    command. UI consumers use this to surface non-compliance per skill;
    CI loops use ``GET /api/skills/_all/validate`` for the bulk variant.
    """
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")

    from agntspace.skills.spec_validator import validate_skill_path

    skill_md_path = (Path(skills._skills_dir) / skill.path).resolve()  # noqa: SLF001
    report = validate_skill_path(skill_md_path)
    return report.to_dict()


@router.post("/{skill_name}/export")
async def export_skill(request: Request, skill_name: str):
    """Export a vault skill as a spec-canonical ``.tar.gz`` tarball.

    Phase 6 — counterpart to ``POST /api/skills/import`` (Phase 5).
    The tarball contains a single top-level directory ``<slug>/`` with
    a rewritten SKILL.md (canonical agentskills.io frontmatter) +
    every auxiliary file in the source folder (templates/,
    examples/, references/, scripts/, etc.).

    Query params:
        ``strip_metadata=true`` → emit pure-spec form (drop AgntSpace
            flat extras like ``title``, ``category``, ``status``,
            ``author``; drop behavioral metadata like ``triggers``,
            ``priority``, ``model_tier``, ``examples``, ``language``).
            Result is what a stranger using only agentskills.io would
            expect. Default ``false`` keeps everything for round-trip
            via ``skill-import``.

    Response: ``application/gzip`` stream named ``<slug>.tar.gz``.
    Activity middleware classifies as ``skill_exported`` (user, low).
    """
    from fastapi.responses import Response as FastAPIResponse

    from agntspace.skills.export import (
        SkillExportError,
        export_skill_to_tarball,
    )

    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")

    strip_metadata = request.query_params.get("strip_metadata", "false").lower() == "true"

    skill_md_path = (Path(skills._skills_dir) / skill.path).resolve()  # noqa: SLF001
    skill_dir = skill_md_path.parent

    try:
        tarball_bytes = export_skill_to_tarball(skill_dir, strip_metadata=strip_metadata)
    except SkillExportError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return FastAPIResponse(
        content=tarball_bytes,
        media_type="application/gzip",
        headers={
            "Content-Disposition": f'attachment; filename="{skill_name}.tar.gz"',
            "X-Export-Mode": "pure-spec" if strip_metadata else "round-trip",
        },
    )


@router.get("/_all/validate")
async def validate_all_skills(request: Request) -> dict:
    """Validate every loaded skill. Returns a summary plus per-skill reports.

    The leading ``_all`` segment avoids colliding with skill names. Pure
    read; safe to poll. Use ``?include_warnings=false`` to drop warnings
    from the response when the consumer only cares about compliance.
    """
    include_warnings = request.query_params.get("include_warnings", "true").lower() != "false"

    skills = request.app.state.skills
    from agntspace.skills.spec_validator import (
        summarize_reports,
        validate_skill_directory,
    )

    skills_dir = Path(skills._skills_dir)  # noqa: SLF001
    reports = validate_skill_directory(skills_dir)
    summary = summarize_reports(reports)

    payload_reports = []
    for r in reports:
        d = r.to_dict()
        if not include_warnings:
            d.pop("warnings", None)
        payload_reports.append(d)

    return {
        **summary,
        "reports": payload_reports,
    }


@router.get("/{skill_name}/usage")
async def get_skill_usage(request: Request, skill_name: str) -> dict:
    """Per-skill usage counters from the sidecar JSON.

    Returns the canonical 5-key usage shape (schema_version, use_count,
    view_count, last_used_at, last_loaded_at). 404 when the skill is
    unknown to the loader. Returns the default shape (zeros + empty
    timestamps) when the skill exists but has no sidecar yet.

    Hermes-inspired (2026-05-16 night). Pure read — no mutation.
    """
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")
    recorder = getattr(request.app.state, "skill_usage_recorder", None)
    if recorder is None:
        # Recorder not wired (legacy boot path / tests). Return the
        # default shape so the UI renders consistently.
        from agntspace.skills.usage import _DEFAULT_USAGE  # noqa: PLC0415

        return {"skill": skill_name, **dict(_DEFAULT_USAGE)}
    try:
        usage = recorder.get_usage(skill.path)
    except Exception:
        # Fail-soft: broken recorder NEVER 500s the dashboard chip.
        # The recorder logs at debug internally; we just return defaults.
        from agntspace.skills.usage import _DEFAULT_USAGE  # noqa: PLC0415

        return {"skill": skill_name, **dict(_DEFAULT_USAGE)}
    return {"skill": skill_name, **usage}


@router.get("/{skill_name}")
async def get_skill(request: Request, skill_name: str) -> dict:
    """Get a single skill's full content."""
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")
    return {
        "name": skill.name,
        "title": skill.title,
        "description": skill.description,
        "category": skill.category,
        "status": skill.status,
        "triggers": skill.triggers,
        "body": skill.body,
        "path": str(skill.path),
        "files": skill.files,
        "author": skill.author,
        "tools_granted": skill.tools_granted,
        "depends_on": skill.depends_on,
        "priority": skill.priority,
        "model_tier": skill.model_tier,
        "examples": skill.examples,
        "output_format": skill.output_format,
        "version": skill.version,
        "signature": skill.signature,
        "publisher": skill.publisher,
        "content_hash": skill.content_hash,
        "signature_valid": _signature_valid(skill),
        "verification": _verification(skill),
    }


def _signature_valid(skill) -> bool | None:  # noqa: ANN001
    """Back-compat thin wrapper over `verify_signature` returning bool|None."""
    from agntspace.skills.signing import verify_signature
    status, _ = verify_signature(
        getattr(skill, "body", "") or "",
        getattr(skill, "signature", "") or "",
    )
    if status == "valid":
        return True
    if status == "invalid":
        return False
    return None  # unsigned or unknown scheme


def _verification(skill) -> dict:  # noqa: ANN001
    """Full verification report for the skill (gap #8)."""
    from agntspace.skills.signing import skill_verification_result
    return skill_verification_result(skill)


@router.put("/{skill_name}")
async def update_skill(request: Request, skill_name: str, body: SkillUpdateRequest) -> dict:
    """Update a skill's raw content (frontmatter + body)."""
    settings = request.app.state.settings
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")

    from agntspace.vault.writer import VaultWriter

    writer = VaultWriter(settings.vault_dir)
    writer.write(f"system/skills/{skill.path}", body.content)
    skills.load_all()
    return {"status": "updated", "name": skill_name}


@router.post("/create")
async def create_skill(request: Request, body: SkillCreateRequest) -> dict:
    """Create a new skill, emitting agentskills.io spec-canonical form.

    Phase 7 (2026-04-28): the scaffolding now matches the same shape
    Phase 3 migrated all default skills to:
      * Top-level: ``name``, ``description``, ``allowed-tools`` (translated
        from ``tools_granted: [list]``), plus AgntSpace flat extras
        ``title`` / ``category`` / ``status`` / ``author``.
      * Under ``metadata:``: behavioral fields (``triggers``, ``priority``,
        ``model_tier``, ``examples``, ``depends_on``, ``output_format``).
      * Body uses canonical headers: ``## Instructions``, ``## Rules``,
        ``## Examples`` (when examples are present).

    Result: every skill the user creates via the UI / CLI passes the
    `tests/arch/test_skills_spec_compliance.py` validator on first write.
    """
    import re

    import yaml

    settings = request.app.state.settings
    skills = request.app.state.skills

    slug = re.sub(r"[^a-z0-9-]", "", body.name.lower().replace(" ", "-"))[:60].strip("-")
    if not slug:
        raise HTTPException(status_code=400, detail="Invalid skill name")

    # ── Build the canonical frontmatter ────────────────────────────────
    fm: dict = {
        "name": slug,
        "description": body.description or f"{body.title} — describe what this skill does and when to use it.",
    }

    # allowed-tools: spec form, space-separated string. Predicates
    # like ``Bash(git:*)`` are kept verbatim if the caller passes them.
    if body.tools_granted:
        cleaned = [str(t).strip() for t in body.tools_granted if str(t).strip()]
        if cleaned:
            fm["allowed-tools"] = " ".join(cleaned)

    # AgntSpace flat extras (Phase 3 locked Decision 2 — kept top-level)
    if body.title:
        fm["title"] = body.title
    fm["category"] = body.category
    fm["status"] = "active"
    if body.author and body.author != "user":
        fm["author"] = body.author

    # Behavioral fields under metadata: (Phase 3 locked Decision 3)
    metadata: dict = {}
    triggers = list(body.triggers) if body.triggers else [slug]
    metadata["triggers"] = triggers
    if body.priority:
        metadata["priority"] = int(body.priority)
    if body.model_tier:
        metadata["model_tier"] = body.model_tier
    if body.depends_on:
        metadata["depends_on"] = list(body.depends_on)
    if body.examples:
        metadata["examples"] = [
            {
                "input": ex.get("input", "") if isinstance(ex, dict) else "",
                "output": ex.get("output", "") if isinstance(ex, dict) else "",
            }
            for ex in body.examples
        ]
    if body.output_format:
        metadata["output_format"] = body.output_format

    if metadata:
        fm["metadata"] = metadata

    yaml_text = yaml.safe_dump(
        fm,
        sort_keys=False,
        default_flow_style=False,
        allow_unicode=True,
        width=200,
    )

    # ── Body with canonical sections ──────────────────────────────────
    instructions = body.instructions or "Define the step-by-step instructions for this skill."
    body_text = (
        f"## Instructions\n\n{instructions}\n\n"
        "## Rules\n\n"
        "- Follow the user's preferences from PROFILE.md\n"
        "- Check CONTRACT.md permissions before taking action\n"
    )

    content = f"---\n{yaml_text}---\n\n{body_text}"

    from agntspace.vault.writer import VaultWriter

    writer = VaultWriter(settings.vault_dir)
    path = f"system/skills/{body.category}/{slug}/SKILL.md"
    writer.write(path, content)
    skills.load_all()
    return {"status": "created", "name": slug, "path": path}


@router.get("/{skill_name}/files/{file_path:path}")
async def get_skill_file(request: Request, skill_name: str, file_path: str) -> dict:
    """Read an additional file from a skill folder (template, example, etc.)."""
    skills = request.app.state.skills
    content = skills.get_skill_file(skill_name, file_path)
    if content is None:
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")
    return {"path": file_path, "content": content}


@router.put("/{skill_name}/files/{file_path:path}")
async def update_skill_file(request: Request, skill_name: str, file_path: str, body: SkillFileRequest) -> dict:
    """Write an additional file to a skill folder."""
    settings = request.app.state.settings
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")

    from pathlib import Path as P

    skill_dir = P(skill.path).parent
    full_path = f"system/skills/{skill_dir}/{file_path}"

    from agntspace.vault.writer import VaultWriter

    writer = VaultWriter(settings.vault_dir)
    writer.write(full_path, body.content)
    skills.load_all()
    return {"status": "updated", "path": full_path}
