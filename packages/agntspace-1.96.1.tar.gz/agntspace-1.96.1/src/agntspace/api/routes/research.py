"""Research API routes — plan-with-budget-gate approval surface (S3.A).

Plan: tasks/plan-research-perplexity.md S3.

When ``research_topic_deep`` is invoked from a chat scope, the gap-analysis
output is wrapped into a "plan" — a list of queries with an estimated cost
— and persisted in the in-memory ``ResearchPlanStore``. The user approves
via ``POST /api/research/plan/{plan_id}/approve`` or rejects via
``POST .../reject``. Approved plans are CONSUMED by the tool's re-invocation
path (``approved_plan_id`` arg).

Architectural choices:

1. **Read-only listing surfaces too** — ``GET /api/research/plan/{id}`` and
   ``GET /api/research/plans/pending`` so the UI can render the queue without
   touching mutating routes. No request body needed for either.

2. **Approval doesn't auto-fire the research** — it just flips state to
   ``approved``. The agent (or a UI follow-up) re-invokes the tool with the
   approved ``plan_id``. This separation is deliberate: approval is a
   **user act**; firing the research is a **tool act**. Conflating them
   would couple the route's auth surface to the agent's contract gate.

3. **Reject removes the plan from pending** but does NOT cascade to the
   trust posterior. That comes in S4 (Bayesian feedback on accept/reject
   of recommended vault updates) — different signal.
"""

from __future__ import annotations

import asyncio
import logging
import re
import time as _time_research
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

log = logging.getLogger(__name__)

router = APIRouter(prefix="/research", tags=["research"])


# arch:deterministic — research output filename pattern fixed by the
# tool that writes them (research_topic + research_topic_deep).  See
# server/src/agntspace/agent/tools.py:2461 (digest) and :3186
# (synthesis).  Drift here means the aggregator stops finding files.
_RESEARCH_FILE_RE = re.compile(r"^research-(?P<slug>.+)-(?P<date>\d{4}-\d{2}-\d{2})\.md$")
_SYNTHESIS_GLOB = "**/wiki/digests/synthesis/research-*.md"
_DIGEST_GLOB = "**/library/digests/research/research-*.md"
# arch:deterministic — Perplexity is the only research provider today;
# cost rows are tagged ``model="perplexity/<id>"`` at the call site
# (tools.py:2892).  Adding a second provider means adding an entry
# here AND wiring its cost-record path the same way.
_RESEARCH_MODEL_PREFIX = "perplexity/"


def _serialize_plan(plan: Any) -> dict:
    """Render a ResearchPlan dataclass as a JSON-safe dict."""
    return plan.to_dict() if hasattr(plan, "to_dict") else dict(plan)


@router.get("/plans/pending")
async def list_pending_plans(request: Request) -> dict:
    """Return every pending research plan, newest first.

    Read-only. The UI's ``/proposals`` page (S3.B) folds this into the
    unified inbox; this endpoint also serves the standalone /research
    plans view if a user wants to see them in isolation.
    """
    store = getattr(request.app.state, "research_plan_store", None)
    if store is None:
        return {"plans": [], "stats": {"total": 0}, "available": False}
    plans = [p.to_dict() for p in store.list_pending()]
    return {
        "plans": plans,
        "stats": store.stats(),
        "available": True,
    }


@router.get("/plan/{plan_id}")
async def get_plan(request: Request, plan_id: str) -> dict:
    """Look up a single research plan."""
    store = getattr(request.app.state, "research_plan_store", None)
    if store is None:
        raise HTTPException(status_code=503, detail="research_plan_store_not_wired")
    plan = store.get(plan_id)
    if plan is None:
        raise HTTPException(status_code=404, detail="plan_not_found_or_expired")
    return _serialize_plan(plan)


@router.post("/plan/{plan_id}/approve")
async def approve_plan(request: Request, plan_id: str) -> dict:
    """Mark a pending research plan as approved.

    Returns the updated plan dict on success. The tool consumes the plan
    on its re-invocation; this route doesn't auto-fire the research
    (separation of concerns — approval is a user act).
    """
    store = getattr(request.app.state, "research_plan_store", None)
    if store is None:
        raise HTTPException(status_code=503, detail="research_plan_store_not_wired")
    plan = store.approve(plan_id)
    if plan is None:
        # 404 covers both unknown id and expired/already-decided.
        raise HTTPException(status_code=404, detail="plan_not_found_or_already_decided")
    return _serialize_plan(plan)


@router.post("/plan/{plan_id}/reject")
async def reject_plan(request: Request, plan_id: str) -> dict:
    """Mark a pending research plan as rejected. Removes it from pending."""
    store = getattr(request.app.state, "research_plan_store", None)
    if store is None:
        raise HTTPException(status_code=503, detail="research_plan_store_not_wired")
    plan = store.reject(plan_id)
    if plan is None:
        raise HTTPException(status_code=404, detail="plan_not_found_or_already_decided")
    return _serialize_plan(plan)


# ──────────────────────────────────────────────────────────────────────
# research_update proposals (S3.B)
# ──────────────────────────────────────────────────────────────────────


def _serialize_proposal(prop: Any) -> dict:
    return prop.to_dict() if hasattr(prop, "to_dict") else dict(prop)


# arch:deterministic — researcher agent_key + Knowledge management trust
# domain are structural ties, not strategy.  research_web /
# research_deep tools are mapped to Knowledge management in
# trust-evolution/config/domains.yaml; the researcher agent owns those
# tools.  Editing these constants would silently break the feedback
# loop without a paired domains.yaml update.
_RESEARCH_TRUST_DOMAIN: str = "Knowledge management"
_RESEARCH_AGENT_KEY: str = "researcher"


def _emit_research_trust_feedback(request: Request, *, rating: str) -> dict:
    """Feed Bayesian trust posterior on research_update proposal decisions (S4).

    Approve → ``good`` signal. Reject → ``needs_improvement`` signal.
    Dismiss does NOT call this helper (soft "seen, no action needed" is
    not a quality grade).

    Returns ``{"recorded": bool, "rating": str, "domain": str,
    "agent_key": str}`` for the API response so callers can show
    "+1 good signal" without a follow-up read.

    Never raises; missing trust_service degrades to ``recorded=False``
    so the proposal decision still completes.
    """
    summary: dict[str, Any] = {
        "recorded": False,
        "rating": rating,
        "domain": _RESEARCH_TRUST_DOMAIN,
        "agent_key": _RESEARCH_AGENT_KEY,
    }
    if rating not in ("good", "needs_improvement"):
        # arch:deterministic — only the two ratings matter for S4; any
        # other value is a caller bug, surface as no-op rather than
        # corrupting the posterior.
        return summary
    trust = getattr(request.app.state, "trust_service", None)
    if trust is None:
        return summary
    try:
        trust.record_feedback(
            _RESEARCH_TRUST_DOMAIN,
            rating,
            agent_key=_RESEARCH_AGENT_KEY,
        )
        summary["recorded"] = True
    except Exception:
        log.exception(
            "research proposal trust feedback failed (rating=%s)", rating,
        )
    return summary


@router.get("/proposals")
async def list_research_proposals(request: Request, status: str = "pending") -> dict:
    """List research_update proposals.

    ``status`` controls filtering: ``pending`` (default — actionable),
    ``all`` (history including approved / rejected / dismissed). Other
    values fall through to ``pending``.
    """
    store = getattr(request.app.state, "research_proposal_store", None)
    if store is None:
        return {"proposals": [], "stats": {"total": 0}, "available": False}
    if status == "all":
        proposals = [p.to_dict() for p in store.list_all()]
    else:
        proposals = [p.to_dict() for p in store.list_pending()]
    return {
        "proposals": proposals,
        "stats": store.stats(),
        "available": True,
    }


@router.get("/proposal/{proposal_id}")
async def get_research_proposal(request: Request, proposal_id: str) -> dict:
    store = getattr(request.app.state, "research_proposal_store", None)
    if store is None:
        raise HTTPException(status_code=503, detail="research_proposal_store_not_wired")
    prop = store.get(proposal_id)
    if prop is None:
        raise HTTPException(status_code=404, detail="proposal_not_found_or_expired")
    return _serialize_proposal(prop)


class _ResearchProposalDecision(BaseModel):
    """Body for /approve and /reject — optional rationale."""
    rationale: str = ""


@router.post("/proposal/{proposal_id}/approve")
async def approve_research_proposal(
    request: Request, proposal_id: str, body: _ResearchProposalDecision | None = None,
) -> dict:
    """Mark a research_update proposal approved.

    Approval doesn't auto-apply the recommendation (that's a manual user
    or agent step). The proposal moves to ``approved`` status; downstream
    consumers (S4 Bayesian feedback) read this state to feed the trust
    posterior. The agent sees the approval in get_relationship_context()
    via the activity middleware classification.
    """
    store = getattr(request.app.state, "research_proposal_store", None)
    if store is None:
        raise HTTPException(status_code=503, detail="research_proposal_store_not_wired")
    rationale = body.rationale if body else ""
    prop = store.approve(proposal_id, rationale=rationale)
    if prop is None:
        raise HTTPException(status_code=404, detail="proposal_not_found_or_already_decided")
    trust_feedback = _emit_research_trust_feedback(request, rating="good")
    out = _serialize_proposal(prop)
    out["trust_feedback"] = trust_feedback
    return out


@router.post("/proposal/{proposal_id}/reject")
async def reject_research_proposal(
    request: Request, proposal_id: str, body: _ResearchProposalDecision | None = None,
) -> dict:
    """Mark a research_update proposal rejected.

    Rejection means "this recommendation is wrong" — distinct from
    dismiss ("seen, no action needed"). S4 feeds this signal into the
    researcher agent's trust posterior as a needs_improvement signal.
    """
    store = getattr(request.app.state, "research_proposal_store", None)
    if store is None:
        raise HTTPException(status_code=503, detail="research_proposal_store_not_wired")
    rationale = body.rationale if body else ""
    prop = store.reject(proposal_id, rationale=rationale)
    if prop is None:
        raise HTTPException(status_code=404, detail="proposal_not_found_or_already_decided")
    trust_feedback = _emit_research_trust_feedback(
        request, rating="needs_improvement",
    )
    out = _serialize_proposal(prop)
    out["trust_feedback"] = trust_feedback
    return out


@router.post("/proposal/{proposal_id}/dismiss")
async def dismiss_research_proposal(request: Request, proposal_id: str) -> dict:
    """Mark a research_update proposal as dismissed.

    Soft "I've seen it, no action needed" — distinct from reject. No
    trust feedback signal; just removes the proposal from /proposals.
    """
    store = getattr(request.app.state, "research_proposal_store", None)
    if store is None:
        raise HTTPException(status_code=503, detail="research_proposal_store_not_wired")
    prop = store.dismiss(proposal_id)
    if prop is None:
        raise HTTPException(status_code=404, detail="proposal_not_found_or_already_decided")
    return _serialize_proposal(prop)


# arch:deterministic — line shape the editor agent ends its narrative
# with so the route handler can transition the proposal status.  Drift
# here means apply outcomes are silently lost.  See research-apply
# SKILL.md "Outcome contract".
_APPLY_OUTCOME_RE = re.compile(
    r"APPLY OUTCOME:\s*(?P<status>[a-z_]+)\s*(?:[—-]\s*(?P<summary>.+))?$",
    flags=re.IGNORECASE | re.MULTILINE,
)
# arch:deterministic — cite-back line. Optional but strongly preferred
# on successful applies. The slug must match what query_knowledge
# returns and what update_article/create_article was called with —
# i.e. canonical kebab-case, not the title with spaces. Drift here
# means the UI's click-through to /wiki/<slug> 404s.
_APPLIED_ARTICLE_RE = re.compile(
    r"APPLIED ARTICLE:\s*(?P<slug>[a-zA-Z0-9_\-./]+)",
    flags=re.MULTILINE,
)
# Status values that count as a successful apply.  Any other value
# (including missing entirely) routes to ``apply_failed``.
_APPLY_OUTCOME_SUCCESS = {"applied"}


def _parse_apply_outcome(narrative: str) -> tuple[str, str]:
    """Pull ``(status, summary)`` from the editor agent's reply.

    Returns ``("crash", "")`` when no APPLY OUTCOME line is present,
    so the proposal is marked apply_failed rather than left dangling.
    """
    if not narrative:
        return ("crash", "")
    match = _APPLY_OUTCOME_RE.search(narrative)
    if match is None:
        return ("crash", "")
    status = (match.group("status") or "").strip().lower()
    summary = (match.group("summary") or "").strip()
    return (status, summary)


def _parse_applied_article_slug(narrative: str) -> str:
    """Pull the article slug from an ``APPLIED ARTICLE: <slug>`` line.

    Returns "" when the line is missing or malformed. Strips a
    leading slash if the editor wrote ``APPLIED ARTICLE: /foo``
    (defensive — the canonical form is bare slug, not a URL path).
    """
    if not narrative:
        return ""
    match = _APPLIED_ARTICLE_RE.search(narrative)
    if match is None:
        return ""
    raw = (match.group("slug") or "").strip()
    return raw.lstrip("/")


# ──────────────────────────────────────────────────────────────────────
# Research budget (gap #8) — spend caps + remaining headroom
# ──────────────────────────────────────────────────────────────────────


@router.get("/budget")
async def research_budget(request: Request) -> dict:
    """Return the configured Perplexity caps + current spend + remaining.

    Drives the UI's budget bar on /research. Caps come from
    ``research-deep/config/pipeline.yaml``'s ``cost_guardrails`` block;
    spend comes from ``cost_log`` rows where model LIKE 'perplexity/%'.
    Both windows reported (daily + weekly) so the UI can show whichever
    is closer to the cap.

    Errors:
      Returns ``{available: false}`` when cost_tracker isn't wired
      (graceful degrade — research still works, the UI just doesn't
      show a budget bar). Caps of 0.0 mean "disabled" — that window
      is reported with remaining=null.
    """
    tracker = getattr(request.app.state, "cost_tracker", None)
    if tracker is None:
        return {"available": False}

    # Read caps from the research-deep skill config. Mirrors the
    # ToolExecutor._check_research_cost_budget call site so the UI
    # bar matches what the guardrail actually enforces.
    skills = getattr(request.app.state, "skills", None)
    daily_cap = 5.0
    weekly_cap = 25.0
    enabled = True
    refusal_hint = ""
    if skills is not None:
        try:
            cfg = skills.load_skill_config_file("research-deep", "pipeline.yaml")
            guardrail_cfg = (cfg or {}).get("cost_guardrails", {}) or {}
            enabled = bool(guardrail_cfg.get("enabled", True))
            daily_cap = float(guardrail_cfg.get("daily_cap_usd", 5.0))
            weekly_cap = float(guardrail_cfg.get("weekly_cap_usd", 25.0))
            refusal_hint = str(guardrail_cfg.get("refusal_hint") or "").strip()
        except Exception:
            log.debug("research/budget: skill config load failed", exc_info=True)

    db = getattr(tracker, "_db", None)
    if db is None:
        return {
            "available": False,
            "enabled": enabled,
            "daily_cap_usd": daily_cap,
            "weekly_cap_usd": weekly_cap,
        }

    now = datetime.now(UTC)
    day_iso = (now - timedelta(days=1)).isoformat()
    week_iso = (now - timedelta(days=7)).isoformat()
    try:
        cursor = await db.execute(
            "SELECT COALESCE(SUM(estimated_cost), 0.0) FROM cost_log "
            "WHERE timestamp >= ? AND model LIKE 'perplexity/%'",
            (day_iso,),
        )
        row = await cursor.fetchone()
        daily_spent = float((row[0] if row else 0.0) or 0.0)
        cursor = await db.execute(
            "SELECT COALESCE(SUM(estimated_cost), 0.0) FROM cost_log "
            "WHERE timestamp >= ? AND model LIKE 'perplexity/%'",
            (week_iso,),
        )
        row = await cursor.fetchone()
        weekly_spent = float((row[0] if row else 0.0) or 0.0)
    except Exception:
        log.exception("research/budget: cost_log query failed")
        return {"available": False}

    def _remaining(cap: float, spent: float) -> float | None:
        # Cap of 0 = disabled → no "remaining" semantic; return null.
        if cap <= 0:
            return None
        return max(0.0, cap - spent)

    return {
        "available": True,
        "enabled": enabled,
        "daily_cap_usd": daily_cap,
        "weekly_cap_usd": weekly_cap,
        "daily_spent_usd": round(daily_spent, 6),
        "weekly_spent_usd": round(weekly_spent, 6),
        "daily_remaining_usd": _remaining(daily_cap, daily_spent),
        "weekly_remaining_usd": _remaining(weekly_cap, weekly_spent),
        "refusal_hint": refusal_hint,
    }


# ──────────────────────────────────────────────────────────────────────
# Research subscriptions (gap #7) — heartbeat-driven recurring research
# ──────────────────────────────────────────────────────────────────────


# arch:deterministic — name prefix for subscription cron jobs.  Used to
# filter list_jobs back to research-only entries (the cron table also
# carries briefing / eod / etc.).
_SUBSCRIPTION_NAME_PREFIX = "research:"

# arch:deterministic — slug character class for the topic-derived name.
# Strips anything that would break the cron name's role as a primary
# key. Matches kebab-case canonical form.
_SUBSCRIPTION_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _topic_to_subscription_name(topic: str) -> str:
    """Slugify a topic into the cron job name.

    ``research:<topic-slug>`` so list_jobs filtering is a simple
    startswith check. Empty / all-special input yields a single
    underscore so the name remains valid (cron table requires
    NOT NULL).
    """
    norm = _SUBSCRIPTION_SLUG_RE.sub("-", topic.strip().lower()).strip("-")
    return f"{_SUBSCRIPTION_NAME_PREFIX}{norm or 'topic'}"


class _SubscriptionRequest(BaseModel):
    """POST body for create-subscription."""

    topic: str
    target_kb: str = "main"
    schedule: str  # cron expression or "every 7d" / "every 30d" interval


@router.get("/subscriptions")
async def list_research_subscriptions(request: Request) -> dict:
    """List active research subscriptions.

    Wraps cron.list_jobs and filters to ``research:*`` jobs. Each row
    includes the next-run timestamp so the UI can show "next research
    on Foo: in 2 days".
    """
    cron = getattr(request.app.state, "cron", None)
    if cron is None:
        return {"subscriptions": [], "available": False}
    try:
        jobs = await cron.list_jobs()
    except Exception:
        log.exception("research_subscriptions: list_jobs failed")
        return {"subscriptions": [], "available": False}
    subs = [
        j for j in jobs if (j.get("name") or "").startswith(_SUBSCRIPTION_NAME_PREFIX)
    ]
    # Map back to per-subscription shape — the topic is recoverable
    # from the name suffix; deliver_to is unused here.
    out: list[dict] = []
    for j in subs:
        name = j.get("name", "")
        topic_slug = name[len(_SUBSCRIPTION_NAME_PREFIX):]
        out.append({
            "name": name,
            "topic_slug": topic_slug,
            "schedule": j.get("schedule", ""),
            "enabled": bool(j.get("enabled", False)),
            "last_run": j.get("last_run"),
            "next_run": j.get("next_run"),
        })
    return {"subscriptions": out, "available": True}


@router.post("/subscriptions")
async def create_research_subscription(
    request: Request, body: _SubscriptionRequest,
) -> dict:
    """Create or replace a research subscription.

    The cron's action_args carry topic + target_kb so the handler
    can dispatch research-deep on the next firing. ``schedule``
    accepts both cron expressions ("0 7 * * 1" — Mondays at 07:00)
    and interval form ("every 7d", "every 30d").

    Existing subscription with the same topic gets its schedule +
    target_kb replaced (cron.add_job uses ON CONFLICT UPDATE).

    Errors:
      400 — empty topic or schedule.
      503 — cron scheduler not wired.
    """
    cron = getattr(request.app.state, "cron", None)
    if cron is None:
        raise HTTPException(status_code=503, detail="cron_not_wired")
    topic = (body.topic or "").strip()
    schedule = (body.schedule or "").strip()
    if not topic:
        raise HTTPException(status_code=400, detail="topic_required")
    if not schedule:
        raise HTTPException(status_code=400, detail="schedule_required")
    name = _topic_to_subscription_name(topic)
    job_info = await cron.add_job(
        name=name,
        schedule=schedule,
        action="research_subscription",
        action_args={
            "topic": topic,
            "target_kb": body.target_kb or "main",
        },
    )
    return {
        "name": name,
        "topic": topic,
        "topic_slug": name[len(_SUBSCRIPTION_NAME_PREFIX):],
        "schedule": job_info.get("schedule", schedule),
        "next_run": job_info.get("next_run"),
        "target_kb": body.target_kb or "main",
    }


@router.delete("/subscriptions/{name}")
async def delete_research_subscription(request: Request, name: str) -> dict:
    """Remove a research subscription.

    The ``name`` must be the canonical ``research:<slug>`` form
    returned by GET /api/research/subscriptions.
    """
    cron = getattr(request.app.state, "cron", None)
    if cron is None:
        raise HTTPException(status_code=503, detail="cron_not_wired")
    if not name.startswith(_SUBSCRIPTION_NAME_PREFIX):
        raise HTTPException(status_code=400, detail="not_a_research_subscription")
    removed = await cron.remove_job(name)
    if not removed:
        raise HTTPException(status_code=404, detail="subscription_not_found")
    return {"removed": True, "name": name}


@router.post("/proposal/{proposal_id}/skip-apply")
async def skip_apply_research_proposal(
    request: Request, proposal_id: str, body: _ResearchProposalDecision | None = None,
) -> dict:
    """Mark an approved proposal complete WITHOUT dispatching the editor.

    State machine: ``approved → applied`` with ``apply_outcome=skipped``.
    The Bayesian approve-signal stays bumped; the proposal moves out of
    the Ready-to-apply queue. Distinct from rejection (which feeds
    needs_improvement) and dismissal (which is for pending only).

    Use case: user approved the recommendation but doesn't want the
    editor to mutate the vault — they'll handle it manually, the
    vault is already up to date, etc.

    Errors:
      404 — proposal not found.
      409 — proposal not in approved state.
      503 — research_proposal_store not wired.
    """
    store = getattr(request.app.state, "research_proposal_store", None)
    if store is None:
        raise HTTPException(status_code=503, detail="research_proposal_store_not_wired")
    prop = store.get(proposal_id)
    if prop is None:
        raise HTTPException(status_code=404, detail="proposal_not_found_or_expired")
    if prop.status != "approved":
        raise HTTPException(
            status_code=409,
            detail=f"proposal_not_approved (current_status={prop.status})",
        )
    rationale = body.rationale if body else ""
    out = store.skip_apply(proposal_id, rationale=rationale)
    if out is None:
        # Race — already transitioned between get + skip_apply.
        raise HTTPException(status_code=409, detail="proposal_state_changed")
    return _serialize_proposal(out)


@router.post("/proposal/{proposal_id}/retry-apply")
async def retry_apply_research_proposal(request: Request, proposal_id: str) -> dict:
    """Reset an apply_failed proposal back to approved so it can be re-applied.

    State machine: ``apply_failed → approved``.  Clears apply_started_at,
    apply_finished_at, apply_outcome, apply_summary, apply_error so the
    next apply pass starts clean. The user is expected to follow up
    with a separate POST .../apply to actually re-fire the editor —
    this route is JUST the state reset, mirroring the
    approve / reject / dismiss / apply / skip-apply pattern of
    "one POST per state transition".

    Errors:
      404 — proposal not found.
      409 — proposal not in apply_failed state.
      503 — research_proposal_store not wired.
    """
    store = getattr(request.app.state, "research_proposal_store", None)
    if store is None:
        raise HTTPException(status_code=503, detail="research_proposal_store_not_wired")
    prop = store.get(proposal_id)
    if prop is None:
        raise HTTPException(status_code=404, detail="proposal_not_found_or_expired")
    if prop.status != "apply_failed":
        raise HTTPException(
            status_code=409,
            detail=f"proposal_not_apply_failed (current_status={prop.status})",
        )
    out = store.retry_apply(proposal_id)
    if out is None:
        # Race — already transitioned between get + retry_apply.
        raise HTTPException(status_code=409, detail="proposal_state_changed")
    return _serialize_proposal(out)


@router.post("/proposal/{proposal_id}/apply")
async def apply_research_proposal(request: Request, proposal_id: str) -> dict:
    """Dispatch the editor agent to act on an approved recommendation.

    Pre-conditions:
      - proposal must be in ``approved`` state (call /approve first).
      - request.app.state.agent must be wired (the agent owns
        invoke_skill).

    Behaviour:
      Flips proposal to ``applying`` synchronously, then spawns a
      fire-and-forget asyncio task that runs ``research-apply`` skill
      via ``agent.invoke_skill`` against the editor specialist. The
      route returns immediately with the in-flight state so the UI
      can poll. The background task parses the agent's APPLY OUTCOME
      line and calls ``store.mark_applied`` with the result.

    Errors:
      403 — proposal not in approved state (rejected/dismissed/already
        applying/applied/apply_failed/pending).
      404 — proposal not found.
      503 — research_proposal_store or agent not wired.
    """
    store = getattr(request.app.state, "research_proposal_store", None)
    if store is None:
        raise HTTPException(status_code=503, detail="research_proposal_store_not_wired")
    agent = getattr(request.app.state, "agent", None)
    if agent is None:
        raise HTTPException(status_code=503, detail="agent_not_wired")

    prop = store.get(proposal_id)
    if prop is None:
        raise HTTPException(status_code=404, detail="proposal_not_found_or_expired")
    if prop.status != "approved":
        raise HTTPException(
            status_code=409,
            detail=f"proposal_not_approved (current_status={prop.status})",
        )

    transitioned = store.mark_applying(proposal_id)
    if transitioned is None:
        # Race between get + mark_applying — already in-flight.
        raise HTTPException(
            status_code=409,
            detail="proposal_already_applying",
        )

    # Build the task body for the editor agent. Keep it small + explicit
    # so a small LLM doesn't have to parse a multi-section blob.
    task_body = (
        f"Apply research_update proposal {proposal_id}.\n\n"
        f"target_kb: {prop.target_kb}\n"
        f"topic: {prop.topic}\n"
        f"severity: {prop.severity}\n"
        f"source_synthesis_path: {prop.source_synthesis_path}\n\n"
        f"recommendation:\n{prop.recommendation}\n\n"
        f"Procedure: see research-apply SKILL.md. Make ONE focused edit "
        f"that addresses the recommendation, citing the source synthesis. "
        f"End your reply with a single line:\n"
        f"  APPLY OUTCOME: <status> — <one-line summary>\n"
        f"where <status> is one of: applied, not_found, target_unclear, "
        f"requires_user_review, synthesis_missing_evidence."
    )

    async def _run_apply() -> None:
        """Background apply task — never blocks the route response."""
        try:
            outcome = await agent.invoke_skill(
                "research-apply",
                args={
                    "proposal_id": proposal_id,
                    "target_kb": prop.target_kb,
                    "topic": prop.topic,
                    "severity": prop.severity,
                    "source_synthesis_path": prop.source_synthesis_path,
                    "recommendation": prop.recommendation,
                },
                agent_name="editor",
                caller="research-apply",
                task_override=task_body,
            )
            narrative = getattr(outcome, "narrative", "") or ""
            status, summary = _parse_apply_outcome(narrative)
            applied_slug = _parse_applied_article_slug(narrative)
            store.mark_applied(
                proposal_id,
                outcome=status,
                summary=summary,
                applied_article_slug=applied_slug,
            )
        except Exception as exc:  # noqa: BLE001 — defensive: never crash the loop
            log.exception("research-apply task crashed for %s", proposal_id)
            store.mark_applied(
                proposal_id,
                outcome="crash",
                error=str(exc)[:500],
            )

    # Fire-and-forget. The route returns the applying-state proposal
    # immediately; the UI polls /proposal/{id} for the terminal state.
    import asyncio  # noqa: PLC0415
    asyncio.create_task(_run_apply())  # noqa: RUF006

    return _serialize_proposal(transitioned)


# ──────────────────────────────────────────────────────────────────────
# Cross-KB aggregators powering the dedicated /research page
# ──────────────────────────────────────────────────────────────────────


def _parse_research_filename(name: str) -> dict | None:
    """Pull the topic-slug + ISO date out of a research-* filename.

    Returns ``{"slug": <slug>, "date": "YYYY-MM-DD"}`` or ``None`` when
    the filename doesn't match the canonical research-* pattern (e.g.
    legacy hand-written digests in the same folders).
    """
    m = _RESEARCH_FILE_RE.match(name)
    if not m:
        return None
    return {"slug": m.group("slug"), "date": m.group("date")}


def _kb_slug_from_path(rel_path: Path) -> str:
    """Extract the KB slug from a vault-relative research file path.

    Layout (post KA-v3): ``knowledge/<kb>/wiki/digests/synthesis/...``
    or ``knowledge/<kb>/library/digests/research/...``.  Both put the
    KB at index 1.  Returns "" when the path is shorter than expected
    (defensive — never raises).
    """
    parts = rel_path.parts
    if len(parts) >= 2 and parts[0] == "knowledge":
        return parts[1]
    return ""


def _coerce_float(value: Any) -> float:
    """Defensive ``float()`` — never raises, returns 0.0 on any non-numeric."""
    try:
        if value is None:
            return 0.0
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _coerce_int(value: Any) -> int:
    """Defensive ``int()`` — never raises, returns 0 on any non-numeric."""
    try:
        if value is None:
            return 0
        return int(value)
    except (TypeError, ValueError):
        return 0


def _scan_research_files(vault, glob: str, kind: str) -> list[dict]:
    """Walk the vault for research output files matching ``glob``.

    Returns list of dicts shape:
        {path, kb, kind, slug, title, date, mtime_iso,
         topic, model, provider, cost_usd, citation_count,
         queries_executed, contradictions_count, research_pipeline}

    Files whose name doesn't match the canonical
    ``research-<slug>-<date>.md`` pattern are skipped — that protects
    the page from ingesting legacy / hand-written content that
    happens to live in the same folders.

    Failures are logged at debug; a broken vault returns ``[]``.
    """
    out: list[dict] = []
    if vault is None:
        return out
    try:
        files = vault.list_files("knowledge", glob)
    except Exception:
        log.debug("research aggregator: list_files failed for %s", glob, exc_info=True)
        return out

    for fp in files:
        # Defensive against accidental hidden / archived sub-trees.
        norm = str(fp).replace("\\", "/")
        if any(part.startswith(".") for part in norm.split("/") if part):
            continue
        info = _parse_research_filename(fp.name)
        if info is None:
            continue
        # vault.list_files returns absolute Paths; strip the vault root
        # for the rel_path the UI deep-links to /wiki/article/<slug>.
        try:
            root = Path(getattr(vault, "vault_dir", "."))
            rel = fp.relative_to(root)
        except Exception:
            rel = fp
        kb_slug = _kb_slug_from_path(rel)

        # Try frontmatter title first; fall back to slugified file stem.
        title = info["slug"].replace("-", " ").title()
        meta: dict = {}
        try:
            doc = vault.read(str(rel).replace("\\", "/"))
            meta = doc.metadata or {}
            fm_title = meta.get("title")
            if isinstance(fm_title, str) and fm_title.strip():
                title = fm_title.strip()
        except Exception:
            log.debug("research aggregator: read failed for %s", rel, exc_info=True)

        try:
            mtime_iso = datetime.fromtimestamp(fp.stat().st_mtime, UTC).isoformat()
        except Exception:
            mtime_iso = ""

        out.append({
            "path": str(rel).replace("\\", "/"),
            "kb": kb_slug,
            "kind": kind,
            "slug": info["slug"],
            "title": title,
            "date": info["date"],
            "mtime_iso": mtime_iso,
            # Provenance fields lifted from frontmatter — empty/zero when
            # the frontmatter is missing or malformed (legacy content).
            "topic": str(meta.get("topic") or "").strip(),
            "model": str(meta.get("model") or "").strip(),
            "provider": str(meta.get("provider") or "").strip(),
            "cost_usd": _coerce_float(meta.get("cost_usd")),
            "citation_count": _coerce_int(meta.get("citation_count")),
            "queries_executed": _coerce_int(meta.get("queries_executed")),
            "contradictions_count": _coerce_int(meta.get("contradictions_count")),
            "research_pipeline": str(meta.get("research_pipeline") or "").strip(),
        })
    return out


# ── Dashboard-poll perf cache (shipped 2026-05-11 night-3) ────────────
# /api/research/recent is dashboard-polled every ~15s by open browser tabs.
# Each call walks the vault for synthesis + digest files (sync I/O), parses
# frontmatter on every row, and aggregates. On the user's vault this was
# producing 200-500ms hot-path latency and showing up in the slow-request
# log every poll burst. Pattern mirrors `goals/progress-summary`'s 8s
# cache (lines 144-176): module-level dict keyed by query params, TTL gate,
# `asyncio.to_thread` for the actual walk so the event loop never blocks
# even on cold cache. Single-flight via threading.Lock so a thundering-herd
# cold-poll produces ONE filesystem walk, not N.
_RECENT_RESEARCH_CACHE: dict[tuple, dict] = {}
_RECENT_RESEARCH_TTL = 15.0
_RECENT_RESEARCH_LOCK = asyncio.Lock()


def _build_recent_research(
    vault: object | None,
    *,
    limit: int,
    offset: int,
    kb_filter: str,
    days: int,
    kind_norm: str,
) -> dict:
    """Pure compute for recent_research — sync I/O off the event loop.

    Extracted from the route body so it can be wrapped in ``asyncio.to_thread``
    without changing the response shape.  See the route docstring for the
    full contract.
    """
    syntheses = (
        _scan_research_files(vault, _SYNTHESIS_GLOB, "synthesis")
        if kind_norm in {"synthesis", "all"} else []
    )
    digests = (
        _scan_research_files(vault, _DIGEST_GLOB, "digest")
        if kind_norm in {"digest", "all"} else []
    )
    items = syntheses + digests

    # Dedup defense: if the same file somehow shows up under both
    # globs (shouldn't, but cheap insurance), keep the synthesis row
    # because that's the authoritative output of research-deep.
    seen: set[str] = set()
    deduped: list[dict] = []
    for it in sorted(items, key=lambda x: (x.get("kind") != "synthesis", x.get("path", ""))):
        path = it["path"]
        if path in seen:
            continue
        seen.add(path)
        deduped.append(it)

    # Apply post-dedup filters BEFORE slicing — Rule 20: ``total`` and
    # the aggregate spend reflect what the user is actually paging
    # through.  ``days=0`` means "no time bound".
    if kb_filter:
        deduped = [d for d in deduped if d.get("kb", "") == kb_filter]
    if days > 0:
        cutoff = (datetime.now(UTC) - timedelta(days=days)).isoformat()
        deduped = [d for d in deduped if d.get("mtime_iso", "") >= cutoff]

    deduped.sort(key=lambda x: x.get("mtime_iso", ""), reverse=True)
    total = len(deduped)
    sliced = deduped[offset:offset + limit]

    # Aggregates over the FULL filtered set, not the slice.  The
    # history view's headline ("$4.52 across 12 dossiers, last 7 days")
    # has to read these — re-summing the slice would lie when offset>0.
    total_cost = round(
        sum(_coerce_float(d.get("cost_usd")) for d in deduped), 6,
    )
    total_calls = len(deduped)
    distinct_kbs = sorted({d.get("kb", "") for d in deduped if d.get("kb")})

    return {
        "items": sliced,
        "total": total,
        "has_more": total > offset + len(sliced),
        "available": vault is not None,
        "filters": {
            "kb": kb_filter,
            "days": days,
            "kind": kind_norm,
            "limit": limit,
            "offset": offset,
        },
        "totals": {
            "cost_usd": total_cost,
            "dossiers": total_calls,
            "kbs": distinct_kbs,
        },
    }


@router.get("/recent")
async def recent_research(
    request: Request,
    limit: int = 20,
    offset: int = 0,
    kb: str = "",
    days: int = 0,
    kind: str = "all",
) -> dict:
    """Cross-KB feed of research outputs with optional filters.

    Returns synthesis pages (research_topic_deep) + digests
    (research_topic) interleaved newest-first by file mtime.  Each row
    carries provenance fields lifted from frontmatter — ``cost_usd``,
    ``citation_count``, ``topic``, ``model``, ``research_pipeline``,
    ``queries_executed``, ``contradictions_count`` — so the history
    view can render cost-per-dossier without a join.

    Aggregate ``total_cost`` + ``total_calls`` are computed over the
    **filtered** dataset, so the UI can show "12 dossiers · $4.52
    spend" honestly even with kb/kind/days filters applied.

    Rule 20: ``total`` is a true count over the FILTERED dataset
    (after dedup, before slicing), never ``len(items)`` after the
    slice.

    Perf: cached for 15s per ``(limit, offset, kb, days, kind)`` tuple,
    computed via ``asyncio.to_thread`` so the event loop never blocks
    on the underlying ``_scan_research_files`` filesystem walk.

    Query params:
        limit  — page size, capped at [1, 200], default 20.
        offset — pagination offset, ≥0, default 0.
        kb     — restrict to a single KB slug (exact match), or "" for all.
        days   — only items with mtime within the last N days; 0 = no limit.
        kind   — "synthesis" | "digest" | "all" (default).
    """
    if limit < 1:
        limit = 1
    if limit > 200:
        limit = 200
    if offset < 0:
        offset = 0
    kb_filter = (kb or "").strip()
    kind_norm = (kind or "all").strip().lower()
    if kind_norm not in {"synthesis", "digest", "all"}:
        kind_norm = "all"
    if days < 0:
        days = 0

    vault = getattr(request.app.state, "vault", None)

    # Cache key includes every filter that changes the output shape so
    # a poll with ?kb=X doesn't see the cache populated for the bare
    # /recent call (different filtered totals).
    cache_key = (id(request.app), limit, offset, kb_filter, days, kind_norm)
    now = _time_research.monotonic()
    cached = _RECENT_RESEARCH_CACHE.get(cache_key)
    if cached and (now - cached["ts"]) < _RECENT_RESEARCH_TTL and cached.get("data") is not None:
        return cached["data"]

    # Single-flight: under a burst of 4-5 concurrent dashboard polls hitting
    # a cold cache, only ONE filesystem walk runs.  The others wait on
    # the lock, re-check the cache, and return.
    async with _RECENT_RESEARCH_LOCK:
        cached = _RECENT_RESEARCH_CACHE.get(cache_key)
        if cached and (_time_research.monotonic() - cached["ts"]) < _RECENT_RESEARCH_TTL and cached.get("data") is not None:
            return cached["data"]
        out = await asyncio.to_thread(
            _build_recent_research,
            vault,
            limit=limit, offset=offset, kb_filter=kb_filter, days=days, kind_norm=kind_norm,
        )
        _RECENT_RESEARCH_CACHE[cache_key] = {"ts": _time_research.monotonic(), "data": out}
        return out


@router.get("/cost")
async def research_cost(request: Request, days: int = 30) -> dict:
    """Research-only LLM spend over the last ``days`` days.

    Filters cost_log to rows whose model starts with the research
    provider prefix (currently only Perplexity — see
    ``_RESEARCH_MODEL_PREFIX``).  Returns total + by-day + by-model
    breakdowns, defensive on every external call.

    Capped: days ∈ [1, 365].  Default 30.
    """
    if days < 1:
        days = 1
    if days > 365:
        days = 365

    tracker = getattr(request.app.state, "cost_tracker", None)
    if tracker is None:
        return {
            "available": False,
            "total_cost": 0.0,
            "total_calls": 0,
            "by_day": [],
            "by_model": [],
            "since": "",
            "until": "",
            "days": days,
        }

    since_iso = (datetime.now(UTC) - timedelta(days=days)).isoformat()
    until_iso = datetime.now(UTC).isoformat()

    # Use the existing cost_log SQLite connection directly — the
    # exposure dashboard already proves this connection is safe to
    # query read-only from a route handler.  We deliberately don't
    # add a "research-only" method to CostTracker because the prefix
    # filter is a query-time concern, not a storage concern.
    db = getattr(tracker, "_db", None)
    if db is None:
        return {
            "available": False,
            "total_cost": 0.0,
            "total_calls": 0,
            "by_day": [],
            "by_model": [],
            "since": since_iso,
            "until": until_iso,
            "days": days,
        }

    try:
        cursor = await db.execute(
            "SELECT COUNT(*), COALESCE(SUM(estimated_cost), 0.0) "
            "FROM cost_log "
            "WHERE timestamp >= ? AND timestamp <= ? AND model LIKE ?",
            (since_iso, until_iso, f"{_RESEARCH_MODEL_PREFIX}%"),
        )
        row = await cursor.fetchone()
        total_calls = int(row[0] or 0) if row else 0
        total_cost = float(row[1] or 0.0) if row else 0.0

        cursor = await db.execute(
            "SELECT substr(timestamp, 1, 10) AS day, "
            "COUNT(*), COALESCE(SUM(estimated_cost), 0.0) "
            "FROM cost_log "
            "WHERE timestamp >= ? AND timestamp <= ? AND model LIKE ? "
            "GROUP BY day ORDER BY day ASC",
            (since_iso, until_iso, f"{_RESEARCH_MODEL_PREFIX}%"),
        )
        by_day = [
            {"day": r[0], "calls": int(r[1] or 0), "cost": float(r[2] or 0.0)}
            for r in await cursor.fetchall()
        ]

        cursor = await db.execute(
            "SELECT model, COUNT(*), COALESCE(SUM(estimated_cost), 0.0) "
            "FROM cost_log "
            "WHERE timestamp >= ? AND timestamp <= ? AND model LIKE ? "
            "GROUP BY model ORDER BY 3 DESC",
            (since_iso, until_iso, f"{_RESEARCH_MODEL_PREFIX}%"),
        )
        by_model = [
            {"model": r[0], "calls": int(r[1] or 0), "cost": float(r[2] or 0.0)}
            for r in await cursor.fetchall()
        ]
    except Exception:
        log.debug("research cost query failed", exc_info=True)
        return {
            "available": False,
            "total_cost": 0.0,
            "total_calls": 0,
            "by_day": [],
            "by_model": [],
            "since": since_iso,
            "until": until_iso,
            "days": days,
        }

    return {
        "available": True,
        "total_cost": total_cost,
        "total_calls": total_calls,
        "by_day": by_day,
        "by_model": by_model,
        "since": since_iso,
        "until": until_iso,
        "days": days,
    }


# ──────────────────────────────────────────────────────────────────────
# Stale-claim scanner (P3.7 from plan-performance-roadmap.md)
# ──────────────────────────────────────────────────────────────────────
#
# Wiki articles carry `(as of YYYY-MM, source)` markers next to date-
# sensitive claims (see defaults/skills/core/kb-compile/SKILL.md rule 19).
# This endpoint surfaces markers older than ``threshold_months`` so the
# user can review what knowledge has gone stale.
#
# Read-only. The actual re-research action is a deferred follow-up
# (heartbeat hook + research_topic dispatch + Rule 21 proposal). Today
# the user gets visibility; future iterations close the loop.


@router.get("/stale-claims")
async def list_stale_claims(
    request: Request,
    threshold_months: int = 6,
    limit: int = 50,
) -> dict:
    """List `(as of YYYY-MM)` markers in wiki articles older than
    ``threshold_months``.

    Args:
        threshold_months: Minimum age in calendar months. Default 6
            (the "knowledge rots" window from plan-research-perplexity.md
            smart add #8). ``0`` returns ALL markers regardless of age.
        limit: Cap on returned items. Results are sorted oldest-first
            so the cap surfaces the worst offenders. 0 = unlimited
            (use with care on large vaults).

    Returns:
        Rule-20 shape ``{items, total, has_more, threshold_months, scanned_at}``.

    Notes:
        - Scans every wiki article under ``knowledge/<kb>/wiki/`` —
          excludes journal entries, agent observations, and version
          history (the marker convention is wiki-specific).
        - No LLM, no network. Pure regex + filesystem walk.
        - On Wolf's 1700-article vault: ~0.5s sequential.
    """
    from agntspace.agent.stale_claims import find_stale_claims_in_vault

    if threshold_months < 0:
        raise HTTPException(
            status_code=400,
            detail="threshold_months must be >= 0",
        )
    # Defensive cap — limit=0 means unlimited per the scanner contract,
    # but absurdly large values still get clamped at the route layer
    # to defend against denial-of-bandwidth from a misbehaving caller.
    if limit < 0:
        limit = 0
    if limit > 5000:
        limit = 5000

    vault = getattr(request.app.state, "vault", None)
    if vault is None:
        # No vault attached → service not ready. 503 mirrors other
        # research routes' "degraded" contract.
        raise HTTPException(
            status_code=503,
            detail="vault not initialised — stale-claim scanner unavailable",
        )

    # Run the scan off the event loop — list_files + file reads + regex
    # are CPU + I/O bound and would otherwise block other requests.
    claims = await asyncio.to_thread(
        find_stale_claims_in_vault,
        vault,
        threshold_months=threshold_months,
        limit=limit,
    )

    items = [c.to_dict() for c in claims]
    return {
        "items": items,
        "total": len(items),
        "has_more": len(items) >= limit if limit > 0 else False,
        "threshold_months": threshold_months,
        "scanned_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
