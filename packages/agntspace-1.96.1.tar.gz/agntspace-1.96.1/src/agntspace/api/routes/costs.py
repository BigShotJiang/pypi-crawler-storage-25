"""Cost tracking API — usage, budgets, and spending dashboard."""

from __future__ import annotations

from fastapi import APIRouter, Request
from pydantic import BaseModel

router = APIRouter(prefix="/costs", tags=["costs"])


class BudgetUpdate(BaseModel):
    daily: float | None = None
    monthly: float | None = None
    enforce: bool | None = None


@router.get("")
async def get_usage(request: Request, days: int = 7) -> dict:
    """Get usage summary for the last N days."""
    tracker = request.app.state.cost_tracker
    return await tracker.get_usage_summary(days=days)


@router.get("/budget")
async def check_budget(request: Request) -> dict:
    """Check current budget status."""
    tracker = request.app.state.cost_tracker
    return await tracker.check_budget()


@router.put("/budget")
async def update_budget(request: Request, body: BudgetUpdate) -> dict:
    """Update daily/monthly budget limits."""
    tracker = request.app.state.cost_tracker
    tracker.set_budgets(daily=body.daily, monthly=body.monthly)
    if body.enforce is not None:
        tracker._enforce_budget = body.enforce

    # Persist to settings
    request.app.state.settings_service.update_section("costs", {
        "daily_budget": tracker._daily_budget,
        "monthly_budget": tracker._monthly_budget,
        "enforce_budget": tracker._enforce_budget,
    })

    return await tracker.check_budget()


@router.get("/today")
async def today_cost(request: Request) -> dict:
    """Get today's spending."""
    tracker = request.app.state.cost_tracker
    return {"cost": await tracker.get_daily_cost()}


@router.get("/bill/daily")
async def daily_bill(request: Request, date: str | None = None) -> dict:
    """Get itemized daily bill — cost breakdown by action and model.

    Shows every LLM call made on a given day with model, tokens, cost.
    Grouped by action type (chat, compile, briefing, etc.) and by model.
    """
    tracker = request.app.state.cost_tracker
    return await tracker.get_daily_bill(date=date)


@router.get("/bill/monthly")
async def monthly_bill(request: Request, month: str | None = None) -> dict:
    """Get monthly bill — daily totals + model and action breakdown.

    Shows cost per day, totals by model, totals by action type, budget status.
    """
    tracker = request.app.state.cost_tracker
    return await tracker.get_monthly_bill(month=month)


@router.get("/cache-stats")
async def cache_stats(request: Request, days: int = 7) -> dict:
    """P1.6 (2026-05-09): Anthropic prompt-cache effectiveness.

    Returns per-model breakdown of cache_read / cache_write / input
    tokens plus hit_ratio and estimated_savings_usd. Lets the user
    verify that ``_build_messages`` cache_control directives are
    actually firing — empty hit_ratio across the period means the
    cache isn't hitting (likely cache key drift or system message
    too short to qualify for caching).

    The ``days`` window defaults to 7. Pass ``days=1`` to see today,
    ``days=30`` for monthly view, etc.
    """
    tracker = request.app.state.cost_tracker
    return await tracker.get_cache_stats(days=days)


@router.get("/cost-routing-stats")
async def cost_routing_stats(request: Request, days: int = 7) -> dict:
    """P4.3 follow-up (2026-05-16): cost-routing effectiveness dashboard.

    Reads the persisted ``tier_requested`` / ``tier_resolved`` /
    ``cost_routing_rule`` columns (added in the P4.3 observability ship)
    and aggregates over the period to surface:

    - How many calls were ACTUALLY downgraded by cost_routing (vs the
      legacy path).
    - Which rules fired most + estimated $ saved per rule.
    - Which callers benefit most (top 10 by routed_calls).
    - Tier-shift distribution (e.g. ``capable→fast`` count).

    Pure read; never raises on missing data — empty cost log returns a
    zero-shaped dict. Telemetry columns default to empty strings on
    pre-P4.3 rows so legacy traffic correctly classifies as ``noop``.

    The ``days`` window defaults to 7. Pass ``days=1`` to see today,
    ``days=30`` for monthly view, etc. Clamped to >=1 internally.
    """
    tracker = request.app.state.cost_tracker
    return await tracker.get_cost_routing_stats(days=days)
