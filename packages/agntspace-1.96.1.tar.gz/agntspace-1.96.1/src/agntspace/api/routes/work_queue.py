"""Work Queue API — monitor and manage the persistent job queue."""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Request

log = logging.getLogger(__name__)

router = APIRouter(prefix="/work-queue", tags=["work-queue"])


@router.get("")
async def get_status(request: Request) -> dict:
    """Get work queue status: LLM health, pending jobs, counts."""
    wq = getattr(request.app.state, "work_queue", None)
    if not wq:
        return {"error": "Work queue not initialized"}
    return await wq.get_status()


@router.get("/history")
async def get_history(request: Request, limit: int = 50) -> dict:
    """Get recently completed/dead_letter jobs.

    Returns ``{items, total, has_more}`` per CLAUDE.md Rule 20.
    """
    wq = getattr(request.app.state, "work_queue", None)
    if not wq:
        return {"items": [], "total": 0, "has_more": False}
    rows = await wq.get_history(limit=limit + 1)
    has_more = len(rows) > limit
    items = list(rows[:limit])
    return {"items": items, "total": len(items), "has_more": has_more}


@router.post("/retry/{job_id}")
async def retry_job(request: Request, job_id: int) -> dict:
    """Retry a failed or dead_letter job."""
    wq = getattr(request.app.state, "work_queue", None)
    if not wq:
        raise HTTPException(status_code=503, detail="Work queue not initialized")
    ok = await wq.retry_job(job_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Job not found or not in retryable state")
    return {"status": "queued", "job_id": job_id}


@router.post("/retry-all")
async def retry_all(request: Request) -> dict:
    """Retry all failed/dead_letter jobs."""
    wq = getattr(request.app.state, "work_queue", None)
    if not wq:
        raise HTTPException(status_code=503, detail="Work queue not initialized")
    count = await wq.retry_all()
    return {"status": "queued", "count": count}


@router.post("/reclaim")
async def reclaim_zombies(request: Request) -> dict:
    """Manually trigger zombie reclaim — sweep ``state='running'`` rows with
    stale heartbeats. Useful when the user sees a stuck "running" count on
    the dashboard and wants to flush it without waiting for the heartbeat.

    Returns ``{"scanned": N, "reclaimed": M, "dead_lettered": K}``. The
    sweep runs even if everything is healthy (no-op when no zombies).
    """
    wq = getattr(request.app.state, "work_queue", None)
    if not wq:
        raise HTTPException(status_code=503, detail="Work queue not initialized")
    if not hasattr(wq, "reclaim_zombies"):
        raise HTTPException(status_code=501, detail="reclaim_zombies not available on this work queue")
    summary = await wq.reclaim_zombies()
    return {"status": "ok", **summary}


@router.get("/{job_id}")
async def get_job(request: Request, job_id: int) -> dict:
    """Return the full state of a single work-queue job.

    Phase 2 Session 5 (2026-05-15): the route every async-job endpoint's
    ``status_url`` field has been pointing at since the Session 3/4
    conversions. The UI's poll-and-progress toaster relies on this:
    polling shows IN-FLIGHT progress (status, attempts, elapsed via
    last_heartbeat_at) until the job hits a terminal state, then
    surfaces the result (or error for dead_letter).

    Returns the canonical row shape from ``WorkQueue.get_job`` with
    ``terminal: true|false`` as a convenience boolean so clients can
    short-circuit polling without re-matching status strings.

    404 when the job_id doesn't exist; 503 when the work queue isn't
    wired (bare test apps).
    """
    wq = getattr(request.app.state, "work_queue", None)
    if not wq:
        raise HTTPException(status_code=503, detail="Work queue not initialized")
    job = await wq.get_job(job_id)
    if job is None:
        raise HTTPException(
            status_code=404, detail=f"Job {job_id} not found",
        )
    return job


@router.delete("/{job_id}")
async def cancel_job(request: Request, job_id: int) -> dict:
    """Cancel a pending/failed job."""
    wq = getattr(request.app.state, "work_queue", None)
    if not wq:
        raise HTTPException(status_code=503, detail="Work queue not initialized")
    ok = await wq.cancel_job(job_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Job not found or not cancellable")
    return {"status": "cancelled", "job_id": job_id}


@router.delete("/completed/clear")
async def clear_completed(request: Request, older_than_days: int = 7) -> dict:
    """Remove completed jobs older than N days."""
    wq = getattr(request.app.state, "work_queue", None)
    if not wq:
        raise HTTPException(status_code=503, detail="Work queue not initialized")
    count = await wq.clear_completed(older_than_days)
    return {"status": "cleared", "count": count}


@router.get("/llm-health")
async def llm_health(request: Request) -> dict:
    """Get current LLM health status and active model."""
    wq = getattr(request.app.state, "work_queue", None)
    llm = getattr(request.app.state, "llm", None)

    result: dict = {
        "healthy": True,
        "active_model": "unknown",
        "last_error": "",
    }

    if wq:
        result["healthy"] = wq.llm_healthy
        result["active_model"] = wq.active_model

    if llm:
        result["active_model"] = getattr(llm, "model_name", getattr(llm, "_model", result["active_model"]))
        result["last_error"] = getattr(llm, "last_error", "")
        result["provider_healthy"] = getattr(llm, "healthy", True)

    if wq:
        status = await wq.get_status()
        result["pending_jobs"] = status.get("total_pending", 0)

    return result
