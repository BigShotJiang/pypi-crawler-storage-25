"""Journal API endpoints.

User journal: one file per day with standardized sections.
  - Focus, Thoughts, Decisions, Learnings, Reflections
Agent observations: separate file (agent-observations_DATE.md).
"""

from __future__ import annotations

import hashlib
import logging
import mimetypes
import re
from pathlib import Path

from fastapi import APIRouter, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

log = logging.getLogger(__name__)

router = APIRouter(prefix="/journal", tags=["journal"])

# ── Attachment limits + accepted types ──
_ATTACHMENT_EXTS = frozenset({".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg"})  # arch:deterministic — capability surface of the journal attachment endpoint
_ATTACHMENT_MAX_BYTES = 10 * 1024 * 1024  # 10 MB hard cap
_DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_FILENAME_PATTERN = re.compile(r"^[a-f0-9]{8}\.[a-z]+$")


class JournalEntryResponse(BaseModel):
    date: str
    content: str
    metadata: dict
    # When the request resolves a daily user-journal file, ``note_bodies``
    # carries the resolved bodies for every per-file note referenced by a
    # ``[[notes/<date>/<slug>|label]]`` stub in the ``## Notes`` section.
    # Shape: ``{slug: {title, body, timestamp}}``. Empty / absent for any
    # other file type. Frontend uses it to render notes inline next to
    # Focus / Mood / Thoughts in the Journal tab.
    note_bodies: dict | None = None


class JournalAppendRequest(BaseModel):
    text: str
    section: str = "Thoughts"


class JournalNoteRequest(BaseModel):
    body: str
    title: str | None = None
    date: str | None = None


class JournalNoteUpdateRequest(BaseModel):
    """Body for ``PUT /api/journal/note/{date}/{slug}``.

    Both fields optional — ``None`` means "leave unchanged", empty string
    means explicit clear. The service rejects when both end up empty
    (use a delete endpoint for that, not edit).
    """
    title: str | None = None
    body: str | None = None


class JournalAttachmentResponse(BaseModel):
    path: str  # markdown-ready relative ref, e.g. ".attachments/2026-05-04/a1b2c3d4.png"
    url: str   # API URL for inline rendering, e.g. "/api/journal/attachment/2026-05-04/a1b2c3d4.png"
    size: int


class JournalEntryListItem(BaseModel):
    date: str
    path: str


class JournalEntryList(BaseModel):
    items: list[JournalEntryListItem]
    total: int
    has_more: bool


class JournalDateList(BaseModel):
    items: list[dict]
    total: int
    has_more: bool


@router.get("/today")
async def get_today(request: Request) -> JournalEntryResponse:
    """Get or create today's user journal entry."""
    journal = request.app.state.journal
    doc = journal.get_today()
    # Return clean date (YYYY-MM-DD), not the filename stem which
    # includes the prefix (e.g. "user-journal_2026-04-12").
    from datetime import date as dt_date
    today = dt_date.today().isoformat()
    return JournalEntryResponse(
        date=today,
        content=doc.content,
        metadata=doc.metadata,
        note_bodies=journal.get_note_bodies_for_date(today),
    )


@router.get("/entries")
async def list_entries(request: Request, limit: int = 30) -> JournalEntryList:
    """List recent user journal entries.

    Returns ``{items, total, has_more}`` per CLAUDE.md Rule 20. ``total`` is
    a lower bound (page count); ``has_more`` reflects whether older entries
    exist beyond the page.
    """
    journal = request.app.state.journal
    rows = journal.list_entries(limit=limit + 1)
    has_more = len(rows) > limit
    items = [JournalEntryListItem(**e) for e in rows[:limit]]
    return JournalEntryList(items=items, total=len(items), has_more=has_more)


@router.get("/entries/{date}")
async def get_entry(request: Request, date: str) -> JournalEntryResponse:
    """Get a specific user journal entry by date (YYYY-MM-DD)."""
    journal = request.app.state.journal
    doc = journal.get_entry(date)
    if not doc:
        raise HTTPException(status_code=404, detail=f"No journal entry for {date}")
    return JournalEntryResponse(
        date=date,
        content=doc.content,
        metadata=doc.metadata,
        note_bodies=journal.get_note_bodies_for_date(date),
    )


@router.get("/section/{section}")
async def get_section(request: Request, section: str, date: str | None = None) -> dict:
    """Read a specific section from today's (or a specific date's) journal."""
    journal = request.app.state.journal
    valid = set(journal.get_user_section_keys())
    if section not in valid:
        raise HTTPException(status_code=400, detail=f"Invalid section: {section}. Use: {', '.join(sorted(valid))}")
    content = journal.get_section(section, date)
    return {"section": section, "content": content, "date": date or "today"}


@router.post("/append")
async def append_entry(request: Request, body: JournalAppendRequest) -> dict:
    """Append to a section of today's user journal.

    Valid sections: Focus, Thoughts, Decisions, Learnings, Reflections.
    """
    journal = request.app.state.journal
    section = body.section
    valid = set(journal.get_user_section_keys())
    if section not in valid:
        raise HTTPException(status_code=400, detail=f"Invalid section: {section}. Use: {', '.join(sorted(valid))}")

    journal.append_to_user(section, body.text)
    return {"status": "ok", "section": section, "author": "user"}


@router.get("/dates")
async def list_dates(request: Request, limit: int = 30) -> JournalDateList:
    """List recent journal dates with available file types.

    Returns ``{items, total, has_more}`` per CLAUDE.md Rule 20.
    """
    journal = request.app.state.journal
    rows = journal.list_dates(limit=limit + 1)
    has_more = len(rows) > limit
    items = list(rows[:limit])
    return JournalDateList(items=items, total=len(items), has_more=has_more)


@router.get("/file/{date}/{file_type}")
async def get_file(request: Request, date: str, file_type: str) -> JournalEntryResponse:
    """Get a specific journal file type for a date.

    file_type: journal, observations, briefing, eod
    """
    journal = request.app.state.journal
    valid_types = journal.get_valid_file_types()
    if file_type not in valid_types:
        raise HTTPException(status_code=400, detail=f"Invalid file_type: {file_type}. Use: {', '.join(sorted(valid_types))}")
    doc = journal.get_file_for_date(date, file_type)
    if not doc:
        raise HTTPException(status_code=404, detail=f"No {file_type} for {date}")
    return JournalEntryResponse(
        date=date,
        content=doc.content,
        metadata=doc.metadata,
        # Only the daily user-journal file references per-note stubs; other
        # types (briefing, eod, observations, reflection) won't have them.
        note_bodies=journal.get_note_bodies_for_date(date) if file_type == "journal" else None,
    )


@router.get("/agent-observations")
async def get_agent_observations(request: Request, date: str | None = None) -> JournalEntryResponse:
    """Get agent observations for a date (defaults to today)."""
    journal = request.app.state.journal
    doc = journal.get_agent_observations(date)
    if not doc:
        raise HTTPException(status_code=404, detail=f"No agent observations for {date or 'today'}")
    return JournalEntryResponse(
        date=date or "today",
        content=doc.content,
        metadata=doc.metadata,
    )


# ── Rich Notes (multi-paragraph + images) ────────────────────────────
# Notes carry a ``### HH:MM — Title`` heading + free-form markdown body.
# Other journal sections keep the existing ``- HH:MM — one-liner`` shape
# via /append. Both shapes coexist in the Notes section.


@router.get("/notes")
async def list_today_notes(request: Request) -> dict:
    """Notes feed for today's user journal.

    Returns the parsed ``## Notes`` section as a list of
    ``{kind, timestamp, title, body, raw}`` dicts, newest-first. Used by
    the Notes-tab feed view in the journal UI when the user wants to see
    notes as discrete cards instead of as a wall of markdown alongside
    other sections.
    """
    journal = request.app.state.journal
    notes = journal.parse_notes()
    return {"date": "today", "items": notes, "total": len(notes), "has_more": False}


@router.get("/notes/{date}")
async def list_notes_for_date(request: Request, date: str) -> dict:
    """Notes feed for a specific date (YYYY-MM-DD)."""
    if not _DATE_PATTERN.match(date):
        raise HTTPException(status_code=400, detail="date must be YYYY-MM-DD")
    journal = request.app.state.journal
    notes = journal.parse_notes(date)
    return {"date": date, "items": notes, "total": len(notes), "has_more": False}


# Slug shape: timestamp-prefixed (``HH-MM`` or ``HH-MM-{slug-text}``),
# enforced via regex so the route can't be coerced into reading
# arbitrary vault files via path traversal.
_NOTE_SLUG_PATTERN = re.compile(r"^[a-z0-9]{2}-[a-z0-9]{2}(?:-[a-z0-9-]+)?$")


@router.get("/inventory/{date}")
async def get_date_inventory(request: Request, date: str) -> dict:
    """Sidebar-ready inventory for one date — file types + per-note files.

    Returns ``{date, file_types: [...], notes: [...]}``. Used to lazy-
    populate the date-folder children when the user expands a row in
    the sidebar. Empty arrays (not 404) when nothing exists.
    """
    if not _DATE_PATTERN.match(date):
        raise HTTPException(status_code=400, detail="date must be YYYY-MM-DD")
    journal = request.app.state.journal
    return journal.inventory(date)


@router.get("/note/{date}/{slug}")
async def get_single_note(request: Request, date: str, slug: str) -> dict:
    """Read one per-note file for the Reader UI.

    Returns ``{date, slug, timestamp, title, body, path}``. 404 when the
    note doesn't exist; 400 on malformed date or slug shape.
    """
    if not _DATE_PATTERN.match(date):
        raise HTTPException(status_code=400, detail="date must be YYYY-MM-DD")
    if not _NOTE_SLUG_PATTERN.match(slug):
        raise HTTPException(status_code=400, detail="invalid slug shape")
    journal = request.app.state.journal
    note = journal.read_note(date, slug)
    if note is None:
        raise HTTPException(status_code=404, detail=f"No note {slug} on {date}")
    return note


@router.put("/note/{date}/{slug}")
async def update_single_note(
    request: Request,
    date: str,
    slug: str,
    body: JournalNoteUpdateRequest,
) -> dict:
    """Edit an existing per-note file's title and/or body.

    Body fields ``title`` / ``body`` are optional — ``None`` leaves the
    existing value untouched, empty string explicitly clears. Rejects
    when the resulting note would be both-empty (400 — use delete for
    that). 404 when the note doesn't exist.

    On title change, the daily-journal stub link's label is updated to
    match. Slug stays stable so the file path doesn't churn.
    """
    if not _DATE_PATTERN.match(date):
        raise HTTPException(status_code=400, detail="date must be YYYY-MM-DD")
    if not _NOTE_SLUG_PATTERN.match(slug):
        raise HTTPException(status_code=400, detail="invalid slug shape")
    journal = request.app.state.journal
    try:
        result = journal.update_note(date, slug, title=body.title, body=body.body)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if result is None:
        raise HTTPException(status_code=404, detail=f"No note {slug} on {date}")
    return result


@router.post("/note")
async def write_note(request: Request, body: JournalNoteRequest) -> dict:
    """Write a rich note block (heading + body) to today's Notes section."""
    journal = request.app.state.journal
    if not (body.body or "").strip() and not (body.title or "").strip():
        raise HTTPException(status_code=400, detail="Note must have a title or body")
    if body.date and not _DATE_PATTERN.match(body.date):
        raise HTTPException(status_code=400, detail="date must be YYYY-MM-DD")
    try:
        result = journal.write_note(body=body.body, title=body.title, date=body.date)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"status": "ok", "section": "Notes", "author": "user", **result}


# ── Attachments (images embedded in Notes) ────────────────────────────
# Storage: ``agntspace-journal/user/.attachments/{date}/{sha8}.{ext}``.
# The dot-prefixed dir is automatically skipped by the inbox watcher's
# universal dot-segment exclusion (no agent will try to KB-ingest your
# screenshots). The markdown-ready path the editor inserts is the
# relative form ``.attachments/{date}/{file}`` so Obsidian / VS Code /
# GitHub all resolve it correctly when opening the journal file directly.

def _attachments_root(request: Request) -> Path:
    """Resolve the attachments directory under journal/user/, creating it on first use."""
    paths = getattr(request.app.state, "vault_paths", None)
    if paths is None:
        raise HTTPException(status_code=503, detail="Vault paths not wired")
    root = paths.resolve("journal/user/.attachments")
    return root


@router.post("/attach")
async def attach_image(
    request: Request,
    file: UploadFile = File(...),
    date: str | None = Form(None),
) -> JournalAttachmentResponse:
    """Upload an image to ``journal/user/.attachments/{date}/`` and return its
    relative path + serving URL.

    Filename is content-addressed (sha8 of bytes) so re-uploading the same
    image during a single editing session is idempotent — the markdown
    reference stays stable, the file isn't duplicated.
    """
    if date is None:
        from agntspace.infra.timezone import local_today
        date = local_today()
    if not _DATE_PATTERN.match(date):
        raise HTTPException(status_code=400, detail="date must be YYYY-MM-DD")

    if not file.filename:
        raise HTTPException(status_code=400, detail="filename is required")
    ext = Path(file.filename).suffix.lower()
    if ext not in _ATTACHMENT_EXTS:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported extension {ext!r}. Allowed: {sorted(_ATTACHMENT_EXTS)}",
        )

    # Read with hard size cap (read one byte past the cap to detect overflow
    # without loading the entire payload first).
    payload = await file.read(_ATTACHMENT_MAX_BYTES + 1)
    if len(payload) > _ATTACHMENT_MAX_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"Attachment exceeds {_ATTACHMENT_MAX_BYTES // (1024 * 1024)} MB cap",
        )
    if not payload:
        raise HTTPException(status_code=400, detail="Attachment is empty")

    sha8 = hashlib.sha256(payload).hexdigest()[:8]
    target_name = f"{sha8}{ext}"
    root = _attachments_root(request)
    target_dir = root / date
    target_dir.mkdir(parents=True, exist_ok=True)

    # Path-traversal guard — resolved target must stay under the attachments root.
    target = target_dir / target_name
    try:
        target.resolve().relative_to(root.resolve())
    except (ValueError, OSError):
        raise HTTPException(status_code=400, detail="Invalid attachment path") from None

    if not target.exists():
        target.write_bytes(payload)

    return JournalAttachmentResponse(
        path=f".attachments/{date}/{target_name}",
        url=f"/api/journal/attachment/{date}/{target_name}",
        size=len(payload),
    )


@router.get("/attachment/{date}/{filename}")
async def serve_attachment(request: Request, date: str, filename: str) -> FileResponse:
    """Serve a previously uploaded journal attachment.

    Refuses anything that doesn't match the canonical ``YYYY-MM-DD`` date
    + ``{sha8}.{ext}`` filename shape — so the endpoint can't be coerced
    into reading arbitrary vault files via path traversal.
    """
    if not _DATE_PATTERN.match(date):
        raise HTTPException(status_code=400, detail="Invalid date")
    if not _FILENAME_PATTERN.match(filename):
        raise HTTPException(status_code=400, detail="Invalid filename")

    root = _attachments_root(request)
    candidate = root / date / filename
    try:
        candidate.resolve().relative_to(root.resolve())
    except (ValueError, OSError):
        raise HTTPException(status_code=403, detail="Access denied") from None
    if not candidate.exists() or not candidate.is_file():
        raise HTTPException(status_code=404, detail="Attachment not found")

    media_type = mimetypes.guess_type(candidate.name)[0] or "application/octet-stream"
    return FileResponse(
        path=str(candidate),
        media_type=media_type,
        headers={"Cache-Control": "private, max-age=3600"},
    )
