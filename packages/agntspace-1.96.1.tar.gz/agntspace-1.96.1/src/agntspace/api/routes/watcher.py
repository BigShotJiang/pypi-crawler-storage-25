"""Watcher observability — status, quarantine, manual control."""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

log = logging.getLogger(__name__)

router = APIRouter(prefix="/watcher", tags=["watcher"])


@router.get("/status")
async def watcher_status(request: Request) -> dict:
    """Return current watcher state: cycles, known files, quarantine, errors."""
    watcher = getattr(request.app.state, "raw_watcher", None)
    if not watcher:
        raise HTTPException(status_code=503, detail="Watcher not initialized")
    try:
        return watcher.get_status()
    except Exception as exc:
        log.exception("watcher status failed")
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/quarantine")
async def list_quarantine(request: Request) -> dict:
    """List all quarantined files across all KBs."""
    vault = getattr(request.app.state, "vault", None)
    if not vault or not vault.paths:
        raise HTTPException(status_code=503, detail="Vault not available")

    kb_dir = vault.paths.resolve("knowledge")
    items: list[dict] = []
    if kb_dir.is_dir():
        seen: set[tuple[str, str]] = set()  # (kb_name, filename) dedup across legacy + canonical
        for kb in kb_dir.iterdir():
            if not kb.is_dir():
                continue
            # Read BOTH canonical (visible) and legacy (dot) names so a
            # half-migrated vault still lists everything. Canonical wins on
            # filename collision (we iterate it first).
            for sub in ("quarantine", ".quarantine"):
                q = kb / "inbox" / sub
                if not q.is_dir():
                    continue
                for f in q.iterdir():
                    if not f.is_file():
                        continue
                    key = (kb.name, f.name)
                    if key in seen:
                        continue
                    seen.add(key)
                    try:
                        st = f.stat()
                        items.append({
                            "kb": kb.name,
                            "filename": f.name,
                            "size": st.st_size,
                            "quarantined_at": st.st_mtime,
                        })
                    except OSError:
                        continue

    return {"count": len(items), "items": items}


class QuarantineAction(BaseModel):
    kb: str
    filename: str


def _resolve_quarantined_file(vault, kb: str, filename: str):
    """Find a quarantined file in either the canonical or legacy subdir.

    Canonical (``quarantine``) wins when the file exists in both. Returns
    the resolved path or ``None`` if absent from both.
    """
    for sub in ("quarantine", ".quarantine"):
        candidate = vault.paths.resolve(f"knowledge/{kb}/inbox/{sub}") / filename
        if candidate.is_file():
            return candidate
    return None


@router.post("/quarantine/restore")
async def restore_quarantined(request: Request, body: QuarantineAction) -> dict:
    """Move a quarantined file back to the KB inbox for retry."""
    vault = getattr(request.app.state, "vault", None)
    if not vault or not vault.paths:
        raise HTTPException(status_code=503, detail="Vault not available")

    q = _resolve_quarantined_file(vault, body.kb, body.filename)
    inbox = vault.paths.resolve(f"knowledge/{body.kb}/inbox") / body.filename
    if q is None:
        raise HTTPException(status_code=404, detail=f"Not quarantined: {body.filename}")
    if inbox.exists():
        raise HTTPException(status_code=409, detail=f"File already in inbox: {body.filename}")
    try:
        q.rename(inbox)
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Restore failed: {exc}") from exc
    return {"status": "restored", "kb": body.kb, "filename": body.filename}


@router.post("/quarantine/delete")
async def delete_quarantined(request: Request, body: QuarantineAction) -> dict:
    """Permanently delete a quarantined file."""
    vault = getattr(request.app.state, "vault", None)
    if not vault or not vault.paths:
        raise HTTPException(status_code=503, detail="Vault not available")

    q = _resolve_quarantined_file(vault, body.kb, body.filename)
    if q is None:
        raise HTTPException(status_code=404, detail=f"Not quarantined: {body.filename}")
    try:
        q.unlink()
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Delete failed: {exc}") from exc
    return {"status": "deleted", "kb": body.kb, "filename": body.filename}


class QuarantineBulkAction(BaseModel):
    """Multi-file variant of :class:`QuarantineAction`."""

    kb: str
    filenames: list[str]


# Mirrors pipeline.py's _BULK_DELETE_MAX. Independent constant because
# this file doesn't import pipeline; sync the value if the policy ever
# changes.
_QUARANTINE_BULK_DELETE_MAX = 500


@router.post("/quarantine/delete-bulk")
async def delete_quarantined_bulk(
    request: Request, body: QuarantineBulkAction,
) -> dict:
    """Bulk variant of :func:`delete_quarantined`.

    Mirrors pipeline.py's bulk-delete response shape exactly so the UI
    uses one code path for all three bucket types
    (inbox / unsupported / quarantine). Idempotent — already-gone
    files counted as ``deleted`` AND ``missing``, never ``failed``.

    Resolution honors the half-migrated-vault rule: canonical
    ``quarantine`` dir wins over legacy ``.quarantine``, same as the
    single-file path.
    """
    vault = getattr(request.app.state, "vault", None)
    if not vault or not vault.paths:
        raise HTTPException(status_code=503, detail="Vault not available")

    if not body.filenames:
        return {
            "status": "ok",
            "kb": body.kb,
            "deleted": [],
            "missing": [],
            "failed": [],
            "total_bytes": 0,
            "requested": 0,
            "truncated": False,
        }

    deleted: list[str] = []
    missing: list[str] = []
    failed: list[dict] = []
    total_bytes = 0

    for raw_name in body.filenames[:_QUARANTINE_BULK_DELETE_MAX]:
        # Defense in depth — path-traversal in a per-item filename is
        # NEVER allowed. The single-file route trusts kb-scoped resolve;
        # bulk lists are a larger attack surface so we explicitly reject
        # path-separator/.. names per-item without aborting the batch.
        if not raw_name or "/" in raw_name or "\\" in raw_name or ".." in raw_name:
            failed.append({"filename": raw_name, "error": "Invalid filename"})
            continue
        q = _resolve_quarantined_file(vault, body.kb, raw_name)
        if q is None:
            missing.append(raw_name)
            deleted.append(raw_name)
            continue
        try:
            try:
                total_bytes += q.stat().st_size
            except OSError:
                pass
            q.unlink()
            deleted.append(raw_name)
        except OSError as exc:
            failed.append({"filename": raw_name, "error": str(exc)})

    truncated = len(body.filenames) > _QUARANTINE_BULK_DELETE_MAX

    # Activity event mirrors the pipeline.py emitter shape so the
    # /api/activity surface treats quarantine + inbox + unsupported
    # bulk deletes uniformly. Best-effort — never let a broken activity
    # logger break the response.
    try:
        activity = getattr(request.app.state, "activity_logger", None)
        if activity is not None:
            activity.log(
                category="user",
                action="watcher_quarantine_deleted_bulk",
                summary=f"Bulk-deleted from quarantine: {len(deleted)} file(s)",
                details={
                    "kb": body.kb,
                    "deleted_count": len(deleted),
                    "missing_count": len(missing),
                    "failed_count": len(failed),
                    "total_bytes": total_bytes,
                    "requested": len(body.filenames),
                    "truncated": truncated,
                },
                importance="medium",
            )
    except Exception:
        log.debug(
            "activity emit failed for watcher_quarantine_deleted_bulk",
            exc_info=True,
        )

    return {
        "status": "ok" if not failed else "partial",
        "kb": body.kb,
        "deleted": deleted,
        "missing": missing,
        "failed": failed,
        "total_bytes": total_bytes,
        "requested": len(body.filenames),
        "truncated": truncated,
    }


@router.post("/quarantine/restore-all")
async def restore_all_quarantined(request: Request) -> dict:
    """Move every quarantined file back to its KB inbox for retry.

    Useful after recovering from an LLM outage: previously-timed-out files
    go back in the queue and the watcher picks them up on its next cycle.
    """
    vault = getattr(request.app.state, "vault", None)
    if not vault or not vault.paths:
        raise HTTPException(status_code=503, detail="Vault not available")

    kb_dir = vault.paths.resolve("knowledge")
    restored: list[dict] = []
    if kb_dir.is_dir():
        for kb in kb_dir.iterdir():
            if not kb.is_dir():
                continue
            # Walk BOTH canonical and legacy subdirs so a half-migrated
            # vault still restores everything that's stuck.
            for sub in ("quarantine", ".quarantine"):
                q = kb / "inbox" / sub
                if not q.is_dir():
                    continue
                for f in list(q.iterdir()):
                    if not f.is_file():
                        continue
                    dest = kb / "inbox" / f.name
                    if dest.exists():
                        continue  # don't overwrite active inbox items
                    try:
                        f.rename(dest)
                        restored.append({"kb": kb.name, "filename": f.name})
                    except OSError as exc:
                        log.warning("restore %s failed: %s", f, exc)
    return {"status": "ok", "count": len(restored), "restored": restored}


@router.post("/scan")
async def trigger_scan(request: Request) -> dict:
    """Trigger an immediate watcher scan (useful after adding files)."""
    watcher = getattr(request.app.state, "raw_watcher", None)
    if not watcher:
        raise HTTPException(status_code=503, detail="Watcher not initialized")
    try:
        ingested = await watcher.check_and_ingest()
        return {
            "status": "ok",
            "ingested": len(ingested) if ingested else 0,
        }
    except Exception as exc:
        log.exception("watcher scan failed")
        raise HTTPException(status_code=500, detail=str(exc)) from exc
