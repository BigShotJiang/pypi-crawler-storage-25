"""HTTP surface for capability-gap proposals (Rule 21 closure).

Three sibling kinds share this router::

    GET    /api/contract-actions/proposals
    POST   /api/contract-actions/proposals/{id}/approve
    POST   /api/contract-actions/proposals/{id}/reject

    GET    /api/tools/proposals
    POST   /api/tools/proposals/{id}/approve
    POST   /api/tools/proposals/{id}/reject

    GET    /api/agents/proposals
    POST   /api/agents/proposals/{id}/approve
    POST   /api/agents/proposals/{id}/reject

Each kind has its own pending queue at::

    <vault>/agntspace/memory/pending/<kind>-proposals/<id>.json

Approval semantics differ by kind:

* **contract-action** — mutates ``domains.yaml`` to add the action
  under the chosen domain (idempotent). Optional body
  ``{"domain": "<override>"}`` to override the proposal's suggested
  domain.
* **tool** — acknowledgment only (creating a tool is a code change).
  Removes pending file + emits activity event so the action plan can
  surface it for a developer.
* **agent** — acknowledgment only (assigning a skill to an agent is a
  manual frontmatter edit). Removes pending file + emits activity
  event.

Reject for all kinds: removes pending file, emits ``user_override``
activity event.

Vault root resolution: ``vault.vault_dir`` is the ``agntspace/``
SUBDIR. The persistence helpers expect the ROOT (the parent). We
centralize that here in ``_vault_root()`` — same gotcha
``proposals.py:_resolve_vault_root`` codifies for the unified inbox.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

log = logging.getLogger(__name__)

router = APIRouter(tags=["capability-proposals"])


# ── Common helpers ────────────────────────────────────────────────────


def _vault_root(request: Request) -> Path | None:
    """Resolve the vault ROOT (parent of ``agntspace/`` subdir).

    Returns ``None`` when the vault isn't wired (setup mode etc.) so
    callers can return 503 without crashing.
    """
    vault = getattr(request.app.state, "vault", None)
    if vault is None:
        return None
    vd = getattr(vault, "vault_dir", None)
    if vd is None:
        return None
    p = Path(vd)
    return p.parent if p.name == "agntspace" else p


def _skills_dir(request: Request) -> Path | None:
    """Resolve the SHIPPED skills dir (read for fallback config)."""
    return getattr(request.app.state, "skills_dir", None)


async def _emit_activity(
    request: Request,
    *,
    category: str,
    action: str,
    summary: str,
    details: dict,
    importance: str = "medium",
) -> None:
    activity = getattr(request.app.state, "activity_logger", None)
    if activity is None:
        return
    try:
        await activity.log(
            category=category,
            action=action,
            summary=summary,
            details=details,
            importance=importance,
        )
    except Exception:
        pass


# ── Pydantic bodies ───────────────────────────────────────────────────


class _ContractActionApproveRequest(BaseModel):
    domain: str | None = None  # override suggested domain at approval time


class _AgentApproveRequest(BaseModel):
    """Body for ``POST /api/agents/proposals/{id}/approve``.

    ``chosen_owner`` lets the user pick which specialist receives the
    orphan skill. When omitted, the approval falls back to the
    proposal's ``suggested_owner_agent``. Empty body = use suggestion.
    """

    chosen_owner: str | None = None


# ── Contract-action routes ────────────────────────────────────────────


@router.get("/contract-actions/proposals")
async def list_contract_action_proposals(request: Request) -> dict:
    """Return every pending contract-action proposal, newest-first."""
    from agntspace.automation.capability_proposals import list_pending

    root = _vault_root(request)
    if root is None:
        return {"proposals": [], "total": 0}
    items = list_pending(root, "contract-action")
    serialized = [p.to_dict() for p in items]
    return {
        "proposals": serialized,
        "total": len(serialized),
    }


@router.post("/contract-actions/proposals/{proposal_id}/approve")
async def approve_contract_action_proposal_route(
    request: Request,
    proposal_id: str,
    body: _ContractActionApproveRequest | None = None,
) -> dict[str, Any]:
    """Merge the proposed contract-action mapping into the vault
    override of ``domains.yaml``.

    Optional body: ``{"domain": "<override>"}`` — picks a different
    target domain than the proposal's suggestion. If neither the body
    nor the proposal payload carries a domain, returns 400.
    """
    from agntspace.automation.capability_proposals import get_proposal
    from agntspace.automation.missing_contract_action_detector import (
        approve_contract_action_proposal,
    )

    root = _vault_root(request)
    if root is None:
        raise HTTPException(status_code=503, detail="vault unavailable")
    skills_dir = _skills_dir(request)
    if skills_dir is None:
        raise HTTPException(status_code=503, detail="skills dir unavailable")

    proposal = get_proposal(root, "contract-action", proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="proposal not found")

    domain = (body.domain if body else None)
    ok, msg = approve_contract_action_proposal(
        root, Path(skills_dir), proposal_id, domain=domain,
    )
    if not ok:
        if msg == "not_found":
            raise HTTPException(status_code=404, detail="proposal not found")
        if msg == "no_domain_chosen":
            raise HTTPException(
                status_code=400,
                detail=(
                    "no domain chosen — pass {\"domain\": \"<name>\"} or "
                    "ensure the proposal carries a suggested_domain"
                ),
            )
        raise HTTPException(status_code=400, detail=msg)

    await _emit_activity(
        request,
        category="contract",
        action="contract_action_proposal_approved",
        summary=(
            f"Mapped contract action {proposal.target!r} to domain "
            f"{(domain or proposal.payload.get('suggested_domain') or '?')!r}"
        ),
        details={
            "proposal_id": proposal_id,
            "action": proposal.target,
            "domain": domain or proposal.payload.get("suggested_domain"),
        },
        importance="medium",
    )
    return {"approved": proposal_id, "message": msg}


@router.post("/contract-actions/proposals/{proposal_id}/reject")
async def reject_contract_action_proposal_route(
    request: Request, proposal_id: str,
) -> dict[str, Any]:
    """Reject and remove a pending contract-action proposal."""
    from agntspace.automation.capability_proposals import (
        get_proposal,
        reject_proposal,
    )

    root = _vault_root(request)
    if root is None:
        raise HTTPException(status_code=503, detail="vault unavailable")
    proposal = get_proposal(root, "contract-action", proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="proposal not found")
    if not reject_proposal(root, "contract-action", proposal_id):
        raise HTTPException(status_code=404, detail="proposal not found")
    await _emit_activity(
        request,
        category="contract",
        action="contract_action_proposal_rejected",
        summary=f"Rejected contract-action proposal: {proposal.target}",
        details={"proposal_id": proposal_id, "action": proposal.target},
        importance="low",
    )
    return {"rejected": proposal_id}


# ── Tool routes ───────────────────────────────────────────────────────


@router.get("/tools/proposals")
async def list_tool_proposals(request: Request) -> dict:
    """Return every pending tool proposal, newest-first."""
    from agntspace.automation.capability_proposals import list_pending

    root = _vault_root(request)
    if root is None:
        return {"proposals": [], "total": 0}
    items = list_pending(root, "tool")
    serialized = [p.to_dict() for p in items]
    return {
        "proposals": serialized,
        "total": len(serialized),
    }


@router.post("/tools/proposals/{proposal_id}/approve")
async def approve_tool_proposal_route(
    request: Request, proposal_id: str,
) -> dict[str, Any]:
    """Approve a pending tool proposal by scaffolding a Python stub.

    Tools require Python code to land — but the engine can produce a
    copy-pastable stub at
    ``<vault>/agntspace/system/proposed_tools/<tool_name>.py`` carrying
    the tool name, granting skills, and the registration boilerplate.
    The developer (or healer) replaces the ``raise NotImplementedError``
    with the real handler and moves the file into the codebase.

    HTTP status mapping (closed enum from ``approve_tool_proposal``):

    * 200 ``stub_scaffolded`` — stub written, pending removed.
    * 200 ``stub_already_exists`` — stub on disk, pending removed (idempotent).
    * 404 ``not_found`` — proposal id unknown.
    * 422 ``invalid_tool_name`` — tool name isn't a legal Python
      identifier; refuse to scaffold an unimportable file. Pending
      NOT removed so user retries after renaming.
    * 500 ``stub_write_failed`` — filesystem error; pending NOT
      removed so retry works once the underlying issue is fixed.
    """
    from agntspace.automation.capability_proposals import get_proposal
    from agntspace.automation.missing_tool_detector import approve_tool_proposal

    root = _vault_root(request)
    if root is None:
        raise HTTPException(status_code=503, detail="vault unavailable")

    proposal = get_proposal(root, "tool", proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="proposal not found")

    ok, status, details = approve_tool_proposal(root, proposal_id)
    if not ok:
        if status == "not_found":
            raise HTTPException(status_code=404, detail="proposal not found")
        if status == "invalid_tool_name":
            raise HTTPException(
                status_code=422,
                detail={
                    "error": "invalid_tool_name",
                    "message": (
                        f"Tool name {details.get('tool_name', '')!r} is not a "
                        "legal Python identifier. Refusing to scaffold an "
                        "unimportable stub. Rename the skill's "
                        "tools_granted entry first."
                    ),
                    **details,
                },
            )
        if status == "stub_write_failed":
            raise HTTPException(
                status_code=500,
                detail={"error": status, **details},
            )
        raise HTTPException(status_code=400, detail={"error": status, **details})

    summary_verb = (
        "Scaffolded stub for"
        if status == "stub_scaffolded"
        else "Stub already exists for"
    )
    await _emit_activity(
        request,
        category="agent",
        action="tool_proposal_approved",
        summary=(
            f"{summary_verb} tool {proposal.target!r} at "
            f"{details.get('stub_path', '')}"
        ),
        details={
            "proposal_id": proposal_id,
            "tool": proposal.target,
            "stub_path": details.get("stub_path", ""),
            "granting_skills": proposal.payload.get("granting_skills", []),
            "edit_status": status,
        },
        importance="medium",
    )
    return {
        "approved": proposal_id,
        "status": status,
        "tool": proposal.target,
        "stub_path": details.get("stub_path", ""),
    }


@router.post("/tools/proposals/{proposal_id}/reject")
async def reject_tool_proposal_route(
    request: Request, proposal_id: str,
) -> dict[str, Any]:
    """Reject and remove a pending tool proposal."""
    from agntspace.automation.capability_proposals import (
        get_proposal,
        reject_proposal,
    )

    root = _vault_root(request)
    if root is None:
        raise HTTPException(status_code=503, detail="vault unavailable")
    proposal = get_proposal(root, "tool", proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="proposal not found")
    if not reject_proposal(root, "tool", proposal_id):
        raise HTTPException(status_code=404, detail="proposal not found")
    await _emit_activity(
        request,
        category="agent",
        action="tool_proposal_rejected",
        summary=f"Rejected tool proposal: {proposal.target}",
        details={"proposal_id": proposal_id, "tool": proposal.target},
        importance="low",
    )
    return {"rejected": proposal_id}


# ── Agent routes ──────────────────────────────────────────────────────


@router.get("/agents/proposals")
async def list_agent_proposals(request: Request) -> dict:
    """Return every pending agent-skill ownership proposal, newest-first."""
    from agntspace.automation.capability_proposals import list_pending

    root = _vault_root(request)
    if root is None:
        return {"proposals": [], "total": 0}
    items = list_pending(root, "agent")
    serialized = [p.to_dict() for p in items]
    return {
        "proposals": serialized,
        "total": len(serialized),
    }


@router.post("/agents/proposals/{proposal_id}/approve")
async def approve_agent_proposal_route(
    request: Request,
    proposal_id: str,
    body: _AgentApproveRequest | None = None,
) -> dict[str, Any]:
    """Add the orphan skill to the chosen agent's ``skills:`` list.

    Approval is **active** — it edits ``<vault>/agntspace/system/agents/{owner}.md``
    in place to append the skill name to the agent's ``skills:`` YAML
    list (idempotent, atomic write, surgical line insert that preserves
    comments).

    Body shape: ``{"chosen_owner": "<agent_key>"}`` — pick which
    specialist receives the orphan. When omitted, falls back to the
    proposal's ``suggested_owner_agent``. The unified inbox sends
    ``chosen_owner`` from the agent picker on the proposal card.

    Returns ``{approved, status, agent_file, owner, skill}`` on success
    so the UI can surface the edited file in a toast and offer a
    deep-link.
    """
    from agntspace.automation.capability_proposals import get_proposal
    from agntspace.automation.missing_agent_detector import approve_agent_proposal

    root = _vault_root(request)
    if root is None:
        raise HTTPException(status_code=503, detail="vault unavailable")

    proposal = get_proposal(root, "agent", proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="proposal not found")

    chosen_owner = body.chosen_owner if body else None
    ok, status, details = approve_agent_proposal(
        root, proposal_id, chosen_owner=chosen_owner,
    )
    if not ok:
        if status == "not_found":
            raise HTTPException(status_code=404, detail="proposal not found")
        if status == "no_owner_chosen":
            # 422 = unprocessable: the request was structurally valid
            # but the user must pick an owner. Surface the suggestions
            # the proposal carries so the UI can render a picker.
            raise HTTPException(
                status_code=422,
                detail={
                    "error": "no_owner_chosen",
                    "message": (
                        "Pick an agent to receive this skill. Pass "
                        "{\"chosen_owner\": \"<agent_key>\"} in the body."
                    ),
                    "suggested_owners": details.get("suggested_owners", []),
                    "skill": details.get("skill", ""),
                },
            )
        if status == "agent_file_missing":
            raise HTTPException(
                status_code=400,
                detail=(
                    f"agent file not found: {details.get('owner')!r}. "
                    "Did you mistype the agent key? Check "
                    "<vault>/agntspace/system/agents/."
                ),
            )
        if status == "frontmatter_malformed":
            raise HTTPException(
                status_code=409,
                detail=(
                    f"Agent {details.get('owner')!r} has malformed YAML "
                    "frontmatter — fix it manually before approving."
                ),
            )
        if status == "agent_has_no_skills_block":
            raise HTTPException(
                status_code=409,
                detail=(
                    f"Agent {details.get('owner')!r} has no `skills:` "
                    "block in frontmatter — add one manually first."
                ),
            )
        # Generic write-failed / read-failed — surface the raw status
        # so the user has something to debug.
        raise HTTPException(status_code=500, detail=status)

    summary_verb = (
        "Added"
        if status == "added"
        else "Skill already present on"  # idempotent path
    )
    await _emit_activity(
        request,
        category="agent",
        action="agent_proposal_approved",
        summary=(
            f"{summary_verb} {proposal.target!r} to "
            f"{details.get('owner')!r} skills list"
        ),
        details={
            "proposal_id": proposal_id,
            "skill": proposal.target,
            "owner": details.get("owner"),
            "agent_file": details.get("agent_file"),
            "edit_status": status,
        },
        importance="medium",
    )
    # Build a vault-relative path for the UI deep-link (so the user
    # can click through to /files?path=... and see what changed).
    agent_file_abs = details.get("agent_file") or ""
    rel_path = ""
    if agent_file_abs:
        try:
            rel_path = str(Path(agent_file_abs).relative_to(root)).replace("\\", "/")
        except (ValueError, OSError):
            rel_path = ""
    return {
        "approved": proposal_id,
        "status": status,  # "added" | "already_present"
        "skill": proposal.target,
        "owner": details.get("owner"),
        "agent_file": rel_path,
    }


@router.post("/agents/proposals/refresh")
async def refresh_agent_proposals_route(request: Request) -> dict[str, Any]:
    """Re-run the missing-agent detector NOW (bypasses heartbeat cadence).

    Useful when the heuristic was changed and the user wants to refresh
    stale suggestions without waiting for the next 24h scan. Clears the
    pending queue first (so re-detection writes fresh entries) then
    triggers ``detect_and_propose()`` on the live detector.

    Body: none. Returns the detector's report dict.
    """
    detector = getattr(request.app.state, "missing_agent_detector", None)
    if detector is None:
        raise HTTPException(status_code=503, detail="detector unavailable")

    root = _vault_root(request)
    if root is None:
        raise HTTPException(status_code=503, detail="vault unavailable")

    # Clear existing pending agent proposals so re-detection isn't
    # short-circuited by skip_if_pending. Keeps the operation honest:
    # the user is asking "what would the detector propose RIGHT NOW".
    from agntspace.automation.capability_proposals import (
        list_pending,
        reject_proposal,
    )
    cleared = 0
    for p in list_pending(root, "agent"):
        if reject_proposal(root, "agent", p.proposal_id):
            cleared += 1

    try:
        report = await detector.detect_and_propose()
    except Exception as exc:
        log.exception("missing-agent refresh failed")
        raise HTTPException(status_code=500, detail=f"detect failed: {exc}") from exc

    await _emit_activity(
        request,
        category="agent",
        action="missing_agent_proposals_refreshed",
        summary=(
            f"User triggered missing-agent re-detection: cleared "
            f"{cleared} stale, wrote {report.get('proposals_written', 0)} "
            f"fresh proposals."
        ),
        details={"cleared": cleared, **{k: v for k, v in report.items() if k != "proposals"}},
        importance="medium",
    )
    return {
        "cleared_stale": cleared,
        **report,
    }


@router.post("/agents/proposals/{proposal_id}/reject")
async def reject_agent_proposal_route(
    request: Request, proposal_id: str,
) -> dict[str, Any]:
    """Reject and remove a pending agent-skill proposal."""
    from agntspace.automation.capability_proposals import (
        get_proposal,
        reject_proposal,
    )

    root = _vault_root(request)
    if root is None:
        raise HTTPException(status_code=503, detail="vault unavailable")
    proposal = get_proposal(root, "agent", proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="proposal not found")
    if not reject_proposal(root, "agent", proposal_id):
        raise HTTPException(status_code=404, detail="proposal not found")
    await _emit_activity(
        request,
        category="agent",
        action="agent_proposal_rejected",
        summary=f"Rejected orphan-skill ownership proposal: {proposal.target}",
        details={"proposal_id": proposal_id, "skill": proposal.target},
        importance="low",
    )
    return {"rejected": proposal_id}


# ── Skill-completeness routes ────────────────────────────────────────


@router.get("/skill-completeness/proposals")
async def list_skill_completeness_proposals(request: Request) -> dict:
    """Return every pending skill-completeness proposal, newest-first."""
    from agntspace.automation.capability_proposals import list_pending

    root = _vault_root(request)
    if root is None:
        return {"proposals": [], "total": 0}
    items = list_pending(root, "skill-completeness")
    serialized = [p.to_dict() for p in items]
    return {
        "proposals": serialized,
        "total": len(serialized),
    }


@router.post("/skill-completeness/proposals/{proposal_id}/approve")
async def approve_skill_completeness_proposal_route(
    request: Request, proposal_id: str,
) -> dict[str, Any]:
    """Approve a skill-completeness proposal by scaffolding empty
    ``triggers: []`` and/or ``tools_granted: []`` blocks in the
    skill's SKILL.md frontmatter (2026-05-16 active-approve sweep).

    The scaffolder closes the structural-gap side — adds the YAML
    blocks the user is missing. Trigger phrases + tool names remain
    the user's responsibility because they're domain-specific. The
    response carries the vault-relative ``skill_path`` so the UI can
    deep-link to ``/files?path=...`` for value entry.

    HTTP status mapping (closed enum from
    ``approve_skill_completeness_proposal``):

    * 200 ``scaffolded_blocks`` — at least one block added, pending removed.
    * 200 ``already_complete`` — both blocks present already, pending removed.
    * 404 ``not_found`` — proposal id unknown.
    * 410 ``skill_md_missing`` — SKILL.md file vanished between detect + approve.
    * 422 ``skill_path_missing`` — legacy proposal without payload.skill_path.
      User refreshes detector to get a fresh proposal with the path.
    * 409 ``frontmatter_malformed`` — fix YAML manually first.
    * 500 ``skill_md_unreadable`` / ``write_failed`` — filesystem error.

    Failure paths preserve the pending proposal so retry works after
    the underlying issue is fixed.
    """
    from agntspace.automation.capability_proposals import get_proposal
    from agntspace.automation.skill_completeness_detector import (
        approve_skill_completeness_proposal,
    )

    root = _vault_root(request)
    if root is None:
        raise HTTPException(status_code=503, detail="vault unavailable")

    proposal = get_proposal(root, "skill-completeness", proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="proposal not found")

    # Legacy-payload fallback: proposals written BEFORE the detector
    # learned to stamp ``skill_path`` (pre-2026-04-29) leave the field
    # empty. Resolve via SkillLoader before invoking the approve
    # function so the scaffolder has a target file. Mirrors the
    # detector's prefix logic so the same vault-relative shape works
    # for both old + new proposals.
    payload = proposal.payload or {}
    if not (payload.get("skill_path") or "").strip():
        skill_loader = getattr(request.app.state, "skills", None)
        if skill_loader is not None:
            try:
                skill_obj = skill_loader.get_skill(proposal.target)
                raw = (
                    (getattr(skill_obj, "path", "") or "")
                    if skill_obj is not None
                    else ""
                )
                if raw:
                    p = Path(raw)
                    resolved = ""
                    if p.is_absolute():
                        try:
                            resolved = str(
                                p.relative_to(root),
                            ).replace("\\", "/")
                        except ValueError:
                            resolved = str(p).replace("\\", "/")
                    else:
                        resolved = (
                            "agntspace/system/skills/"
                            + raw.replace("\\", "/")
                        )
                    if resolved:
                        # Stamp the proposal payload on disk so the
                        # approve function sees the resolved path.
                        import json

                        from agntspace.automation.capability_proposals import (
                            pending_dir,
                        )
                        file_path = pending_dir(root, "skill-completeness") / (
                            f"{proposal_id}.json"
                        )
                        try:
                            data = json.loads(
                                file_path.read_text(encoding="utf-8"),
                            )
                            data.setdefault("payload", {})[
                                "skill_path"
                            ] = resolved
                            file_path.write_text(
                                json.dumps(data), encoding="utf-8",
                            )
                        except OSError:
                            log.debug(
                                "skill-completeness route: payload "
                                "rewrite failed",
                                exc_info=True,
                            )
            except Exception:
                log.debug(
                    "skill-completeness route: skill_path fallback "
                    "failed for %s",
                    proposal.target,
                    exc_info=True,
                )

    ok, status, details = approve_skill_completeness_proposal(
        root, proposal_id,
    )
    if not ok:
        if status == "not_found":
            raise HTTPException(status_code=404, detail="proposal not found")
        if status == "skill_path_missing":
            raise HTTPException(
                status_code=422,
                detail={
                    "error": status,
                    "message": (
                        f"Proposal for {proposal.target!r} has no skill_path. "
                        "Re-run the detector via "
                        "POST /api/skill-completeness/proposals/refresh "
                        "to get a fresh proposal with the path."
                    ),
                    **details,
                },
            )
        if status == "skill_md_missing":
            raise HTTPException(
                status_code=410,
                detail={
                    "error": status,
                    "message": (
                        f"SKILL.md for {proposal.target!r} vanished between "
                        "detect and approve. Restore the file, then refresh."
                    ),
                    **details,
                },
            )
        if status == "frontmatter_malformed":
            raise HTTPException(
                status_code=409,
                detail={
                    "error": status,
                    "message": (
                        f"SKILL.md for {proposal.target!r} has malformed "
                        "frontmatter. Fix the YAML manually before approving."
                    ),
                    **details,
                },
            )
        if status in ("skill_md_unreadable", "write_failed"):
            raise HTTPException(
                status_code=500,
                detail={"error": status, **details},
            )
        raise HTTPException(status_code=400, detail={"error": status, **details})

    summary_verb = (
        "Scaffolded empty blocks for"
        if status == "scaffolded_blocks"
        else "Both blocks already present on"
    )
    added_blocks = details.get("added_blocks") or []
    await _emit_activity(
        request,
        category="agent",
        action="skill_completeness_proposal_approved",
        summary=(
            f"{summary_verb} {proposal.target!r}"
            f" (added: {', '.join(added_blocks) or '<none>'})"
        ),
        details={
            "proposal_id": proposal_id,
            "skill": proposal.target,
            "skill_path": details.get("skill_path", ""),
            "added_blocks": added_blocks,
            "missing_triggers": details.get("missing_triggers", False),
            "missing_tools_granted": details.get("missing_tools_granted", False),
            "edit_status": status,
        },
        importance="medium",
    )
    return {
        "approved": proposal_id,
        "status": status,
        "skill": details.get("skill", ""),
        "skill_path": details.get("skill_path", ""),
        "added_blocks": added_blocks,
        "missing_triggers": details.get("missing_triggers", False),
        "missing_tools_granted": details.get("missing_tools_granted", False),
    }


@router.post("/skill-completeness/proposals/refresh")
async def refresh_skill_completeness_proposals_route(
    request: Request,
) -> dict[str, Any]:
    """Re-run the skill-completeness detector NOW (bypasses heartbeat
    cadence). Same shape as ``/agents/proposals/refresh``.

    Useful when the detector's payload schema was updated (e.g. when
    ``skill_path`` was added 2026-04-29) and the user wants existing
    proposals rewritten with fresh payloads instead of waiting for the
    next 24h scan. Clears the pending queue first so re-detection
    isn't short-circuited by ``skip_if_pending``.
    """
    detector = getattr(request.app.state, "skill_completeness_detector", None)
    if detector is None:
        raise HTTPException(status_code=503, detail="detector unavailable")

    root = _vault_root(request)
    if root is None:
        raise HTTPException(status_code=503, detail="vault unavailable")

    from agntspace.automation.capability_proposals import (
        list_pending,
        reject_proposal,
    )
    cleared = 0
    for p in list_pending(root, "skill-completeness"):
        if reject_proposal(root, "skill-completeness", p.proposal_id):
            cleared += 1

    try:
        report = await detector.detect_and_propose()
    except Exception as exc:
        log.exception("skill-completeness refresh failed")
        raise HTTPException(status_code=500, detail=f"detect failed: {exc}") from exc

    await _emit_activity(
        request,
        category="agent",
        action="skill_completeness_proposals_refreshed",
        summary=(
            f"User triggered skill-completeness re-detection: cleared "
            f"{cleared} stale, wrote {report.get('proposals_written', 0)} "
            f"fresh proposals."
        ),
        details={"cleared": cleared, **{k: v for k, v in report.items() if k != "proposals"}},
        importance="medium",
    )
    return {"cleared_stale": cleared, **report}


@router.post("/skill-completeness/proposals/{proposal_id}/reject")
async def reject_skill_completeness_proposal_route(
    request: Request, proposal_id: str,
) -> dict[str, Any]:
    """Reject and remove a pending skill-completeness proposal."""
    from agntspace.automation.capability_proposals import (
        get_proposal,
        reject_proposal,
    )

    root = _vault_root(request)
    if root is None:
        raise HTTPException(status_code=503, detail="vault unavailable")
    proposal = get_proposal(root, "skill-completeness", proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="proposal not found")
    if not reject_proposal(root, "skill-completeness", proposal_id):
        raise HTTPException(status_code=404, detail="proposal not found")
    await _emit_activity(
        request,
        category="agent",
        action="skill_completeness_proposal_rejected",
        summary=f"Rejected skill-completeness proposal: {proposal.target}",
        details={"proposal_id": proposal_id, "skill": proposal.target},
        importance="low",
    )
    return {"rejected": proposal_id}


# ── Stale-skill routes (Hermes-borrow #3, 2026-05-16 night) ────────


@router.get("/stale-skills/proposals")
async def list_stale_skill_proposals_route(request: Request) -> dict[str, Any]:
    """List pending stale-skill proposals (Rule 20 shape).

    Hermes-borrow #3 follow-up — companion to the MVP detector shipped
    in commit 5a7671f. Read-only — surfaces what's in the queue so
    the unified inbox + Skills page can render counts.
    """
    from agntspace.automation.capability_proposals import list_pending

    root = _vault_root(request)
    if root is None:
        return {"proposals": [], "total": 0, "has_more": False, "available": False}
    try:
        items = list_pending(root, "stale-skill")
    except Exception:
        log.exception("stale-skill list_pending failed")
        return {"proposals": [], "total": 0, "has_more": False, "available": False}
    payload = [p.to_dict() for p in items]
    return {
        "proposals": payload,
        "total": len(payload),
        "has_more": False,
        "available": True,
    }


@router.post("/stale-skills/proposals/{proposal_id}/approve")
async def approve_stale_skill_proposal_route(
    request: Request, proposal_id: str,
) -> dict[str, Any]:
    """Approve = actually archive the skill.

    Moves ``<skills_dir>/<category>/<name>/`` to
    ``<skills_dir>/<category>/.archive/<name>/`` (dot-prefixed →
    universal skip rule excludes it from every traversal so the
    archived skill is gone from agent's world). Pending proposal file
    is removed on successful move.

    Failure paths return HTTP status codes mapping to the closed enum
    in ``approve_stale_skill_proposal``:

      - ``not_found`` → 404
      - ``skill_not_loaded`` → 410 Gone (proposal stale; cleaned up)
      - ``path_unresolvable`` / ``skill_md_missing`` → 422 (config issue)
      - ``move_failed`` → 500 (filesystem error)

    On success: reloads the SkillLoader so the archived skill drops
    from the active cache. Emits HIGH-importance activity event —
    vault structural changes warrant a toast.
    """
    from agntspace.automation.capability_proposals import get_proposal
    from agntspace.automation.stale_skill_detector import (
        approve_stale_skill_proposal,
    )

    root = _vault_root(request)
    if root is None:
        raise HTTPException(status_code=503, detail="vault unavailable")

    skills_loader = getattr(request.app.state, "skills", None)
    skills_dir = getattr(request.app.state, "skills_dir", None)
    if skills_loader is None or skills_dir is None:
        raise HTTPException(status_code=503, detail="skills not wired")

    proposal = get_proposal(root, "stale-skill", proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="proposal not found")

    ok, status, details = approve_stale_skill_proposal(
        root, proposal_id,
        skill_loader=skills_loader,
        skills_dir=Path(skills_dir),
    )
    if not ok:
        if status == "not_found":
            raise HTTPException(status_code=404, detail="proposal not found")
        if status == "skill_not_loaded":
            raise HTTPException(
                status_code=410,
                detail={
                    "error": status,
                    "message": (
                        f"Skill '{proposal.target}' no longer in the loader — "
                        "stale proposal cleaned up."
                    ),
                    **details,
                },
            )
        if status in ("path_unresolvable", "skill_md_missing"):
            raise HTTPException(
                status_code=422,
                detail={"error": status, **details},
            )
        if status == "move_failed":
            raise HTTPException(
                status_code=500,
                detail={"error": status, **details},
            )
        # Defensive fallthrough — unknown status
        raise HTTPException(status_code=400, detail={"error": status, **details})

    # Filesystem move succeeded — reload loader so archived skill drops
    # from cache. Fail-soft: a reload failure doesn't undo the archive.
    try:
        skills_loader.load_all()
    except Exception:
        log.warning("skill_loader.load_all() failed post-archive", exc_info=True)

    await _emit_activity(
        request,
        category="skills",
        action="stale_skill_archived",
        summary=f"Archived stale skill: {proposal.target}",
        details={
            "proposal_id": proposal_id,
            "skill": proposal.target,
            "from": details.get("from", ""),
            "to": details.get("to", ""),
        },
        importance="high",
    )
    return {
        "approved": proposal_id,
        "status": status,
        "skill": proposal.target,
        "archived_to": details.get("to", ""),
    }


@router.post("/stale-skills/proposals/{proposal_id}/reject")
async def reject_stale_skill_proposal_route(
    request: Request, proposal_id: str,
) -> dict[str, Any]:
    """Reject = remove pending file, keep skill active.

    Acknowledges the user's "no — keep this skill". The MVP doesn't
    write a cooldown marker yet (would prevent re-proposing for N
    months); for now, the same skill will re-propose on the next
    weekly heartbeat tick if it stays stale. User can pin the skill
    in detect.yaml's pinned_skills to permanently exempt.
    """
    from agntspace.automation.capability_proposals import (
        get_proposal,
        reject_proposal,
    )

    root = _vault_root(request)
    if root is None:
        raise HTTPException(status_code=503, detail="vault unavailable")
    proposal = get_proposal(root, "stale-skill", proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="proposal not found")
    if not reject_proposal(root, "stale-skill", proposal_id):
        raise HTTPException(status_code=404, detail="proposal not found")
    await _emit_activity(
        request,
        category="skills",
        action="stale_skill_proposal_rejected",
        summary=f"Kept stale skill: {proposal.target}",
        details={"proposal_id": proposal_id, "skill": proposal.target},
        importance="low",
    )
    return {"rejected": proposal_id}
