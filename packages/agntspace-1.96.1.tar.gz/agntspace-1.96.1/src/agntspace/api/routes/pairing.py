"""DM pairing and allowlist API routes.

P3.6 (2026-05-17): the GET/PUT /dm-policy routes gained an optional
``channel`` query/body field. Without it, they read/write the global
``dm_policy``. With it, they read/write the per-channel override at
``dm_policy:<channel>``. Back-compat preserved: legacy clients that
don't pass ``channel`` see byte-identical behavior.

Two new routes ship alongside:

* ``DELETE /dm-policy?channel=X`` — remove a per-channel override
  (channel reverts to the global default).
* ``GET /dm-policy/overrides`` — enumerate all per-channel overrides
  for the UI to render alongside the global policy.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel

from agntspace.security.pairing import VALID_DM_POLICIES

router = APIRouter(prefix="/security", tags=["security"])


class PolicyUpdate(BaseModel):
    policy: str  # pairing | allowlist | open
    # P3.6: optional per-channel override target. When omitted, the
    # update lands on the global `dm_policy` row (back-compat).
    channel: str | None = None


class PairingAction(BaseModel):
    channel: str
    sender_id: str


@router.get("/dm-policy")
async def get_dm_policy(
    request: Request,
    channel: str | None = Query(default=None),
) -> dict:
    """Resolve the effective DM policy.

    ``?channel=X`` resolves the per-channel policy with global fallback.
    Without ``channel``, returns the global default.

    The response is always shaped the same way so the UI doesn't need
    to branch on which form was called.
    """
    pairing = request.app.state.pairing
    if channel:
        # Channel-scoped: returns effective policy AFTER fallback
        # to global. UI uses the `effective_policy` field to render
        # what's actually enforced, and the `override_set` flag to
        # know whether the channel has its own row (vs. inheriting).
        overrides = await pairing.list_dm_policy_overrides()
        normalized = channel.strip().lower()
        return {
            "policy": await pairing.get_dm_policy(channel),
            "channel": channel,
            "override_set": normalized in overrides,
            "override_value": overrides.get(normalized, ""),
        }
    return {"policy": await pairing.get_dm_policy()}


@router.put("/dm-policy")
async def set_dm_policy(request: Request, body: PolicyUpdate) -> dict:
    if body.policy not in VALID_DM_POLICIES:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "invalid_policy",
                "message": (
                    f"Invalid policy {body.policy!r}. Must be one of: "
                    + ", ".join(VALID_DM_POLICIES)
                ),
                "valid_policies": list(VALID_DM_POLICIES),
            },
        )
    pairing = request.app.state.pairing
    # P3.6: optional channel routes the write to the per-channel key.
    if body.channel is not None:
        if not body.channel.strip():
            raise HTTPException(
                status_code=400,
                detail={
                    "error": "invalid_channel",
                    "message": "channel must be a non-empty string; omit to set the global default",
                },
            )
        await pairing.set_dm_policy(body.policy, channel=body.channel)
        return {"policy": body.policy, "channel": body.channel.strip().lower()}
    await pairing.set_dm_policy(body.policy)
    return {"policy": body.policy}


@router.delete("/dm-policy")
async def clear_dm_policy_override(
    request: Request,
    channel: str = Query(...),
) -> dict:
    """Remove a per-channel policy override.

    The channel reverts to the global default. Idempotent — returns
    ``cleared=False`` when no override existed. Refuses empty channel
    so the global key can never be accidentally deleted via this
    surface (the legacy PUT /dm-policy without channel writes the
    global; there's no symmetric DELETE for it).
    """
    if not channel.strip():
        raise HTTPException(
            status_code=400,
            detail={
                "error": "invalid_channel",
                "message": "channel must be a non-empty string",
            },
        )
    pairing = request.app.state.pairing
    cleared = await pairing.clear_dm_policy_override(channel)
    return {"cleared": cleared, "channel": channel.strip().lower()}


@router.get("/dm-policy/overrides")
async def list_dm_policy_overrides(request: Request) -> dict:
    """List all per-channel policy overrides."""
    pairing = request.app.state.pairing
    overrides = await pairing.list_dm_policy_overrides()
    return {"overrides": overrides, "global": await pairing.get_dm_policy()}


@router.get("/pairing/pending")
async def get_pending_pairings(request: Request) -> list[dict]:
    pairing = request.app.state.pairing
    return await pairing.get_pending()


@router.post("/pairing/approve")
async def approve_pairing(request: Request, body: PairingAction) -> dict:
    pairing = request.app.state.pairing
    ok = await pairing.approve(body.channel, body.sender_id)
    return {"approved": ok}


@router.post("/pairing/reject")
async def reject_pairing(request: Request, body: PairingAction) -> dict:
    pairing = request.app.state.pairing
    ok = await pairing.reject(body.channel, body.sender_id)
    return {"rejected": ok}


@router.get("/allowlist")
async def get_allowlist(request: Request) -> list[dict]:
    pairing = request.app.state.pairing
    return await pairing.get_allowlist()


@router.post("/allowlist")
async def add_to_allowlist(request: Request, body: PairingAction) -> dict:
    pairing = request.app.state.pairing
    await pairing.add_to_allowlist(body.channel, body.sender_id)
    return {"added": True}


@router.delete("/allowlist")
async def remove_from_allowlist(request: Request, body: PairingAction) -> dict:
    pairing = request.app.state.pairing
    await pairing.remove_from_allowlist(body.channel, body.sender_id)
    return {"removed": True}
