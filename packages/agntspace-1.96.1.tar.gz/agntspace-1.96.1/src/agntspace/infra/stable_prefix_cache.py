"""Sprint γ.2 — on-disk cache for the agent's compiled stable system-prompt prefix.

The stable prefix in ``Agent.initialize()`` is built from identity files +
trust summary + skills summary + capabilities + integrations. Pre-fix, every
process boot ran the full build: 6 identity-file reads + SQLite trust query +
skill-loader iteration over 155+ skills + string assembly. Honest measurement
on the user's 1700-article vault: ~100-700ms per boot.

This module caches the assembled prefix on disk at
``<vault>/agntspace/system/_cache/stable_prefix.json`` keyed by a fingerprint
of every input that materially affects the output. Same disk-cache pattern as
``structural_index.json`` (commit f3d47b9) and ``vault_index.mtime_ns``
(commit 7a0a7e9):

- Fingerprint = sha256 over (identity-file mtimes+sizes, skills-tree mtime
  walk, registry capability hash, trust summary string). Any change to any
  load-bearing input invalidates.
- Cache file is schema-versioned; bumping ``_SCHEMA_VERSION`` invalidates
  every existing cache file (planned breaking change route).
- Atomic write via ``.tmp`` + ``Path.replace()``.
- Fail-soft at every error path: missing file, corrupt JSON, schema mismatch,
  fingerprint mismatch, disk read error — all degrade to "build from scratch".
  The cache NEVER prevents a successful build.

Architectural decisions locked here:

1. **Trust summary IS part of the fingerprint**, not an extra rebuild trigger.
   The current ``Agent.initialize()`` already accepts that trust changes
   between identity-file edits go uncached until next mtime change (the
   prefix only rebuilds on identity-file mtime). Adding this cache doesn't
   make that worse, AND including trust_summary in the fingerprint means
   trust-table edits genuinely invalidate the cache rather than ride along
   on stale data.

2. **Skill fingerprint is mtime-walk over `skills_dir`**, not the rendered
   ``skills_summary`` string. Skills can be ~500K of body content; hashing
   the rendered string each boot costs ~5ms but reading mtimes is sub-ms.

3. **No content read for fingerprint**, only stat. The cache miss path
   reads + builds. This keeps the fingerprint check itself cheap.

4. **Cache is per-vault, not per-process**: different vaults have different
   identity files, different skills, different trust. The cache file lives
   inside the vault so vault switching automatically uses the right cache.

API:

- ``StablePrefixCache(vault_dir)`` — bind to a vault.
- ``fingerprint = cache.compute_fingerprint(identity_paths, skills_dir,
  trust_summary, capabilities_text, connected_integrations)`` — pure helper.
- ``cached_prefix = cache.try_load(fingerprint)`` — returns the cached string
  iff stored fingerprint matches. Returns None on every failure path.
- ``cache.save(fingerprint, prefix)`` — atomic write. Never raises.

Pure-function helpers (testable without filesystem):

- ``_compute_files_fingerprint_dict(...)`` — fingerprint dict for a list of
  files. Used for both identity files and skill files.
- ``_canonicalize_fingerprint(...)`` — turn the dict into a stable sha256.

Sprint γ.2 scope: just the prefix string. Sprint γ.3 (not in this commit)
extends to ontology + EntityRegistry indexes via the same disk-cache pattern.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


_CACHE_FILENAME = "stable_prefix.json"
_SCHEMA_VERSION = "1"  # arch:deterministic — bump invalidates every existing cache
_MAX_PREFIX_BYTES = 8 * 1024 * 1024  # 8 MB — defensive cap; legitimate prefix is ~50-300 KB


def _safe_stat(path: Path) -> tuple[int, int] | None:
    """Return (mtime_ns, size) or None on any error. Total — never raises."""
    try:
        st = path.stat()
        return (st.st_mtime_ns, st.st_size)
    except OSError:
        return None


def _compute_files_fingerprint_dict(paths: list[Path]) -> dict[str, list[int]]:
    """Pure helper: turn a list of paths into a deterministic mtime+size dict.

    Missing files contribute as the empty list ``[]`` — same as a future
    deletion. Output is JSON-serialisable + stable (sorted by str(path)).
    """
    result: dict[str, list[int]] = {}
    for p in sorted(paths, key=str):
        st = _safe_stat(p)
        result[str(p)] = list(st) if st is not None else []
    return result


def _walk_skills_dir_for_fingerprint(skills_dir: Path) -> dict[str, list[int]]:
    """Walk every .md / .yaml file under skills_dir, return mtime+size dict.

    Per skill: SKILL.md and any ``config/*.yaml`` are the load-bearing
    inputs to ``get_full_prompt_section``. Walking everything else (e.g.
    reference docs, templates) is acceptable — they rarely change, and
    a false invalidation just triggers a rebuild (correct, just slower).

    Fail-soft: a broken skill_dir → empty dict → cache check sees a
    different fingerprint → rebuild. Never raises.
    """
    if not skills_dir.is_dir():
        return {}
    result: dict[str, list[int]] = {}
    try:
        # Walk only files of interest to keep the fingerprint compact.
        # Globbing twice is cheaper than walking the whole tree once on
        # most filesystems because we hit the FS cache.
        for pattern in ("**/*.md", "**/*.yaml", "**/*.yml"):
            for p in skills_dir.glob(pattern):
                # Skip dot-prefixed dirs (`.history`, `.archives`, `.quarantine`)
                # same as the rest of the codebase. Dotted segments survive a
                # `Path.parts` walk.
                if any(part.startswith(".") for part in p.parts if part):
                    continue
                st = _safe_stat(p)
                if st is not None:
                    result[str(p.relative_to(skills_dir))] = list(st)
    except OSError:
        log.debug("stable_prefix_cache: skills_dir walk failed (non-fatal)", exc_info=True)
        return {}
    return result


def _canonicalize_fingerprint(payload: dict[str, Any]) -> str:
    """Hash a fingerprint payload deterministically. Pure."""
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


class StablePrefixCache:
    """Per-vault on-disk cache for the assembled stable system-prompt prefix.

    Construct once per Agent instance with the vault root. Methods are
    synchronous, fail-soft, and never raise on the read path.
    """

    def __init__(self, vault_dir: Path) -> None:
        self._vault_dir = Path(vault_dir)
        self._cache_path = self._vault_dir / "agntspace" / "system" / "_cache" / _CACHE_FILENAME

    @property
    def cache_path(self) -> Path:
        return self._cache_path

    def compute_fingerprint(
        self,
        *,
        identity_files: list[Path],
        skills_dir: Path | None,
        trust_summary: str | None,
        capabilities_text: str | None,
        connected_integrations: list[str] | None,
    ) -> str:
        """Compute a deterministic fingerprint over all stable-prefix inputs.

        Pure given filesystem state. Same inputs → same fingerprint.

        Note: ``connected_integrations`` is sorted before hashing so insertion
        order of integration plugins doesn't invalidate the cache spuriously.
        """
        payload: dict[str, Any] = {
            "schema": _SCHEMA_VERSION,
            "identity": _compute_files_fingerprint_dict(identity_files),
            "skills": _walk_skills_dir_for_fingerprint(skills_dir) if skills_dir else {},
            "trust": trust_summary or "",
            "capabilities": capabilities_text or "",
            "integrations": sorted(connected_integrations) if connected_integrations else [],
        }
        return _canonicalize_fingerprint(payload)

    def try_load(self, fingerprint: str) -> str | None:
        """Return the cached prefix iff stored fingerprint matches.

        Fail-soft at every step. Returns None on:
        - missing cache file
        - corrupt JSON
        - schema mismatch
        - fingerprint mismatch
        - missing/non-string ``prefix`` field
        - oversized prefix (defensive against bad writes)

        The cache NEVER raises on read.
        """
        if not self._cache_path.is_file():
            return None
        try:
            raw = self._cache_path.read_text(encoding="utf-8")
        except OSError:
            log.debug("stable_prefix_cache: read failed", exc_info=True)
            return None
        if not raw.strip():
            return None
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            log.info("stable_prefix_cache: corrupt JSON at %s — rebuilding", self._cache_path)
            return None
        if not isinstance(payload, dict):
            return None
        if payload.get("schema") != _SCHEMA_VERSION:
            log.info(
                "stable_prefix_cache: schema_version mismatch (cached=%s, expected=%s) — rebuilding",
                payload.get("schema"),
                _SCHEMA_VERSION,
            )
            return None
        if payload.get("fingerprint") != fingerprint:
            return None
        prefix = payload.get("prefix")
        if not isinstance(prefix, str):
            return None
        if len(prefix.encode("utf-8")) > _MAX_PREFIX_BYTES:
            log.warning("stable_prefix_cache: cached prefix oversized — rebuilding")
            return None
        return prefix

    def save(self, fingerprint: str, prefix: str) -> bool:
        """Atomically write the cache file. Returns True on success.

        Fail-soft: any error logs at debug level and returns False. The
        cache is purely best-effort — a failed save just means next boot
        rebuilds (correct, just slower).

        Uses ``.tmp`` + ``Path.replace()`` for atomicity, same pattern as
        every other vault cache (structural_index.json, wikilink_index.json,
        build_index.json).
        """
        if not isinstance(prefix, str):
            return False
        if len(prefix.encode("utf-8")) > _MAX_PREFIX_BYTES:
            log.warning("stable_prefix_cache: prefix too large to cache (%d bytes)", len(prefix))
            return False
        try:
            self._cache_path.parent.mkdir(parents=True, exist_ok=True)
        except OSError:
            log.debug("stable_prefix_cache: mkdir failed", exc_info=True)
            return False
        payload = {
            "schema": _SCHEMA_VERSION,
            "fingerprint": fingerprint,
            "prefix": prefix,
        }
        tmp = self._cache_path.with_suffix(".json.tmp")
        try:
            tmp.write_text(
                json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
                encoding="utf-8",
            )
            os.replace(tmp, self._cache_path)
            return True
        except OSError:
            log.debug("stable_prefix_cache: write failed", exc_info=True)
            try:
                if tmp.exists():
                    tmp.unlink()
            except OSError:
                pass
            return False

    def invalidate(self) -> bool:
        """Remove the cache file. Useful for explicit reset paths."""
        try:
            if self._cache_path.is_file():
                self._cache_path.unlink()
                return True
        except OSError:
            log.debug("stable_prefix_cache: invalidate failed", exc_info=True)
        return False
