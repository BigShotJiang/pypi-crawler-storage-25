"""Per-conversation prefetch cache (P4.4 — predictive context prefetch).

When a WebSocket chat connects, we know the user is about to send a message.
The first turn pays a small but accumulating cost reading conversation state
from SQLite — budget check, context messages, in-focus artifact. None of
those are individually expensive (5-20ms each), but they're SERIAL on the
hot path of the very first response a user sees in a session.

This module exposes ``ConversationPrefetchCache`` — a tiny TTL+invalidation
cache that the WS handler fires AT CONNECT (background, fire-and-forget) so
the per-turn fetches land from cache instead of from SQLite. Saves ~15-40ms
on the first turn after a tab activation; compounds across subsequent turns
because the explicit invalidators keep the cache fresh after writes.

Architectural commitments
=========================

1.  **Three orthogonal cache slots**: budget (process-global, keyed on
    "_global"), messages (per conversation_id), artifact (per
    conversation_id). Each has its own TTL because their staleness
    tolerances differ.

2.  **Explicit invalidation > TTL.** TTL is the safety net for missed
    invalidations; the primary correctness mechanism is the caller dropping
    the cache slot when its underlying state changes. ``add_message`` drops
    the messages slot; ``set_artifact`` / ``clear_artifact`` drops the
    artifact slot; cost-tracker writes drop the budget slot. Without
    explicit invalidation the cache would silently serve stale data after
    every write — exactly the failure mode lessons.md 2026-04-29 warned
    about.

3.  **Cache stores RESULTS, not promises.** ``prefetch(conv_id)`` fires
    asyncio.gather of fetch coroutines, awaits all of them, stores the
    settled results. Two back-to-back prefetches for the same conv with
    the cache still warm short-circuit on the second call (no duplicate
    SQLite reads).

4.  **Fail-soft at every boundary.** Missing cost_tracker / missing memory /
    fetch raises / cache lookup raises → caller falls back to live fetch.
    The cache MUST NEVER raise into the chat path; it's a perf optimization,
    not a correctness gate.

5.  **Backward-compat by absence.** Every ``get_*`` method returns ``None``
    on miss. Callers MUST check None and fall through to the live fetch.
    A vault without the cache wired sees byte-identical pre-P4.4 behavior.

6.  **Bounded memory.** Per-slot LRU cap (default 200 conversations) so
    long-running servers don't accumulate cache entries for conversations
    the user touched once and forgot.

The cache is NOT cross-process. Each AgntSpace process keeps its own.
Process-split deployments (when shipped) will need to either route all
chat for a conv through one worker, OR move the cache to a shared store
(Redis, sqlite shared mmap). For singleton + Phase 2 split (one worker
draining all chat), the in-process cache is the right primitive.
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections import OrderedDict
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any

log = logging.getLogger(__name__)


# Inline `# arch:deterministic` markers — these are structural perf-cache
# defaults, not strategy. The skill YAML overrides them; the constants
# guarantee fail-soft behavior when the YAML is missing or malformed.
_DEFAULT_BUDGET_TTL_SECONDS: float = 5.0  # arch:deterministic — cheap recheck; 5s staleness window means at most one over-budget call slips in
_DEFAULT_MESSAGES_TTL_SECONDS: float = 10.0  # arch:deterministic — conversation history changes only on add_message which invalidates explicitly
_DEFAULT_ARTIFACT_TTL_SECONDS: float = 15.0  # arch:deterministic — artifact changes only on set/clear which invalidate explicitly
_DEFAULT_MAX_PER_SLOT: int = 200  # arch:deterministic — LRU cap per cache slot; prevents long-running servers from accumulating entries


@dataclass
class _CacheEntry:
    """One cached result with its insertion timestamp."""

    value: Any
    stored_at: float  # monotonic seconds


@dataclass
class PrefetchStats:
    """Lifetime counters exposed for /admin observability."""

    prefetches_started: int = 0
    prefetches_completed: int = 0
    prefetches_failed: int = 0
    budget_hits: int = 0
    budget_misses: int = 0
    messages_hits: int = 0
    messages_misses: int = 0
    artifact_hits: int = 0
    artifact_misses: int = 0
    invalidations: int = 0

    def to_dict(self) -> dict:
        return {
            "prefetches_started": self.prefetches_started,
            "prefetches_completed": self.prefetches_completed,
            "prefetches_failed": self.prefetches_failed,
            "budget": {
                "hits": self.budget_hits,
                "misses": self.budget_misses,
                "hit_rate": _hit_rate(self.budget_hits, self.budget_misses),
            },
            "messages": {
                "hits": self.messages_hits,
                "misses": self.messages_misses,
                "hit_rate": _hit_rate(self.messages_hits, self.messages_misses),
            },
            "artifact": {
                "hits": self.artifact_hits,
                "misses": self.artifact_misses,
                "hit_rate": _hit_rate(self.artifact_hits, self.artifact_misses),
            },
            "invalidations": self.invalidations,
        }


def _hit_rate(hits: int, misses: int) -> float:
    total = hits + misses
    if total == 0:
        return 0.0
    return round(hits / total, 4)


@dataclass
class PrefetchConfig:
    """Resolved config — engine fallback when YAML is missing/malformed."""

    enabled: bool = True
    budget_enabled: bool = True
    messages_enabled: bool = True
    artifact_enabled: bool = True
    budget_ttl_seconds: float = _DEFAULT_BUDGET_TTL_SECONDS
    messages_ttl_seconds: float = _DEFAULT_MESSAGES_TTL_SECONDS
    artifact_ttl_seconds: float = _DEFAULT_ARTIFACT_TTL_SECONDS
    max_per_slot: int = _DEFAULT_MAX_PER_SLOT


def resolve_config(skill_loader: object | None) -> PrefetchConfig:
    """Read the conversation-prefetch skill config; fall back to defaults.

    Fail-open at every step:
      - missing loader → defaults
      - missing file → defaults
      - malformed YAML / non-dict / loader-raises → defaults
      - missing field → use default for that field
      - non-numeric TTL / negative TTL → use default for that field
    """
    cfg = PrefetchConfig()
    if skill_loader is None:
        return cfg
    try:
        raw = skill_loader.load_skill_config_file("conversation-prefetch", "prefetch.yaml")
    except Exception:
        return cfg
    if not isinstance(raw, dict):
        return cfg

    cfg.enabled = bool(raw.get("enabled", cfg.enabled))
    cfg.budget_enabled = bool(raw.get("budget_enabled", cfg.budget_enabled))
    cfg.messages_enabled = bool(raw.get("messages_enabled", cfg.messages_enabled))
    cfg.artifact_enabled = bool(raw.get("artifact_enabled", cfg.artifact_enabled))
    cfg.budget_ttl_seconds = _coerce_positive_float(raw.get("budget_ttl_seconds"), cfg.budget_ttl_seconds)
    cfg.messages_ttl_seconds = _coerce_positive_float(raw.get("messages_ttl_seconds"), cfg.messages_ttl_seconds)
    cfg.artifact_ttl_seconds = _coerce_positive_float(raw.get("artifact_ttl_seconds"), cfg.artifact_ttl_seconds)
    cfg.max_per_slot = _coerce_positive_int(raw.get("max_per_slot"), cfg.max_per_slot)
    return cfg


def _coerce_positive_float(value: Any, default: float) -> float:
    """Return a positive float or the default. Rejects bool, None, negative, non-numeric."""
    if isinstance(value, bool):
        return default
    if not isinstance(value, (int, float)):
        return default
    if value <= 0:
        return default
    return float(value)


def _coerce_positive_int(value: Any, default: int) -> int:
    """Return a positive int or the default. Rejects bool, None, negative, non-numeric."""
    if isinstance(value, bool):
        return default
    if not isinstance(value, int):
        return default
    if value <= 0:
        return default
    return value


# Sentinel for "this conv is being prefetched" so concurrent prefetch calls
# don't fire duplicate fetches. Stored in _in_flight; replaced by real entry
# once the prefetch completes.
_PREFETCH_PENDING = object()

# Public sentinel for "cache MISS". Callers MUST check `is PREFETCH_MISS`
# rather than `is None` because None is a VALID cached value for the
# artifact slot (meaning "no artifact in focus for this conv"). Returning
# None on miss would collapse the two cases and silently force every
# artifact-less conv to pay the SQLite read on every turn.
PREFETCH_MISS: object = object()

# Global budget cache key — budget is process-global (per-day total spend),
# not per-conversation. Stored under a synthetic conv id so the slot's
# LRU + TTL machinery works uniformly.
_GLOBAL_BUDGET_KEY = "__global__"


class ConversationPrefetchCache:
    """Three TTL-bounded LRU caches with explicit invalidation.

    Use from WS handler at chat-tab activation:

        cache.prefetch(conv_id)  # fire and forget

    Use from chat hot path:

        cached = cache.get_messages(conv_id)
        if cached is None:
            cached = await memory.get_context_messages(conv_id)

    Use from write sites:

        cache.invalidate_messages(conv_id)  # after add_message
        cache.invalidate_artifact(conv_id)  # after set/clear_artifact
        cache.invalidate_budget()           # after cost_tracker.record
    """

    def __init__(
        self,
        config: PrefetchConfig | None = None,
        *,
        budget_fetch: Callable[[], Awaitable[Any]] | None = None,
        messages_fetch: Callable[[str], Awaitable[Any]] | None = None,
        artifact_fetch: Callable[[str], Awaitable[Any]] | None = None,
        activity_logger: object | None = None,
    ) -> None:
        self._config = config or PrefetchConfig()
        self._budget_fetch = budget_fetch
        self._messages_fetch = messages_fetch
        self._artifact_fetch = artifact_fetch
        self._activity = activity_logger

        # OrderedDict for LRU semantics — move_to_end on access, popitem(last=False) on overflow.
        self._budget: OrderedDict[str, _CacheEntry] = OrderedDict()
        self._messages: OrderedDict[str, _CacheEntry] = OrderedDict()
        self._artifact: OrderedDict[str, _CacheEntry] = OrderedDict()

        # In-flight tracker — keys are conversation_ids currently being prefetched.
        # Prevents duplicate prefetch coroutines firing for the same conv.
        self._in_flight: set[str] = set()

        self._stats = PrefetchStats()

    # ─── Config + observability ───

    @property
    def config(self) -> PrefetchConfig:
        return self._config

    def update_fetchers(
        self,
        *,
        budget_fetch: Callable[[], Awaitable[Any]] | None = None,
        messages_fetch: Callable[[str], Awaitable[Any]] | None = None,
        artifact_fetch: Callable[[str], Awaitable[Any]] | None = None,
    ) -> None:
        """Late-wire fetcher callbacks. Useful when the cache is constructed
        before its data sources (cost_tracker, memory) exist in main.py
        lifespan ordering."""
        if budget_fetch is not None:
            self._budget_fetch = budget_fetch
        if messages_fetch is not None:
            self._messages_fetch = messages_fetch
        if artifact_fetch is not None:
            self._artifact_fetch = artifact_fetch

    def stats(self) -> dict:
        """Lifetime stats for /admin observability."""
        return self._stats.to_dict()

    # ─── Read path (chat hot path) ───

    def get_budget(self) -> Any:
        """Return cached budget snapshot or ``PREFETCH_MISS`` on miss.

        Budget is process-global; the conv_id parameter is omitted on purpose.
        On hit, increments hit counter and LRU-bumps the entry.

        Callers MUST check ``is PREFETCH_MISS`` (not ``is None``) because
        a cached None could in principle be a valid budget-check result
        for a tracker that returns None on success.
        """
        if not self._config.enabled or not self._config.budget_enabled:
            return PREFETCH_MISS
        return self._get_slot(self._budget, _GLOBAL_BUDGET_KEY, self._config.budget_ttl_seconds,
                              hit_counter="budget_hits", miss_counter="budget_misses")

    def get_messages(self, conversation_id: str) -> Any:
        """Return cached context messages for a conversation or ``PREFETCH_MISS``."""
        if not self._config.enabled or not self._config.messages_enabled:
            return PREFETCH_MISS
        if not conversation_id:
            return PREFETCH_MISS
        return self._get_slot(self._messages, conversation_id, self._config.messages_ttl_seconds,
                              hit_counter="messages_hits", miss_counter="messages_misses")

    def get_artifact(self, conversation_id: str) -> Any:
        """Return cached artifact for a conversation or ``PREFETCH_MISS`` on miss.

        Note: a TRUE absence of artifact is a valid cached value (None inside
        the entry). Callers MUST check ``is PREFETCH_MISS`` (not ``is None``)
        — otherwise every artifact-less conv would pay the SQLite read on
        every turn instead of getting the cache hit it earned.
        """
        if not self._config.enabled or not self._config.artifact_enabled:
            return PREFETCH_MISS
        if not conversation_id:
            return PREFETCH_MISS
        return self._get_slot(self._artifact, conversation_id, self._config.artifact_ttl_seconds,
                              hit_counter="artifact_hits", miss_counter="artifact_misses")

    def _get_slot(
        self,
        slot: OrderedDict[str, _CacheEntry],
        key: str,
        ttl: float,
        *,
        hit_counter: str,
        miss_counter: str,
    ) -> Any:
        """Common get-from-slot path. Returns ``PREFETCH_MISS`` on miss /
        expired / pending; the actual cached value (which may be None) on hit.
        """
        entry = slot.get(key)
        if entry is None or entry.value is _PREFETCH_PENDING:
            setattr(self._stats, miss_counter, getattr(self._stats, miss_counter) + 1)
            return PREFETCH_MISS
        age = time.monotonic() - entry.stored_at
        if age > ttl:
            setattr(self._stats, miss_counter, getattr(self._stats, miss_counter) + 1)
            return PREFETCH_MISS
        slot.move_to_end(key)
        setattr(self._stats, hit_counter, getattr(self._stats, hit_counter) + 1)
        return entry.value

    # ─── Invalidation (write sites) ───

    def invalidate_messages(self, conversation_id: str) -> None:
        """Drop the messages cache slot for one conversation."""
        if not conversation_id:
            return
        if self._messages.pop(conversation_id, None) is not None:
            self._stats.invalidations += 1

    def invalidate_artifact(self, conversation_id: str) -> None:
        """Drop the artifact cache slot for one conversation."""
        if not conversation_id:
            return
        if self._artifact.pop(conversation_id, None) is not None:
            self._stats.invalidations += 1

    def invalidate_budget(self) -> None:
        """Drop the global budget snapshot."""
        if self._budget.pop(_GLOBAL_BUDGET_KEY, None) is not None:
            self._stats.invalidations += 1

    def invalidate_conversation(self, conversation_id: str) -> None:
        """Drop every slot for one conversation. Budget is global so untouched."""
        self.invalidate_messages(conversation_id)
        self.invalidate_artifact(conversation_id)

    def clear_all(self) -> None:
        """Drop every cache slot. Used by tests + admin reset."""
        size = len(self._budget) + len(self._messages) + len(self._artifact)
        self._budget.clear()
        self._messages.clear()
        self._artifact.clear()
        self._stats.invalidations += size

    # ─── Prefetch (WS connect / chat-tab activation) ───

    async def prefetch(self, conversation_id: str) -> None:
        """Fire fetches for the three slots in parallel; populate caches.

        Single-flight: if a prefetch for this conv is already in progress,
        return immediately. The in-flight set is cleared in the finally
        block to handle exceptions cleanly.

        Awaitable but the caller should NOT block on it. Fire as
        ``asyncio.create_task(cache.prefetch(conv_id))`` from the WS handler.
        """
        if not self._config.enabled:
            return
        if not conversation_id:
            return
        if conversation_id in self._in_flight:
            return
        self._in_flight.add(conversation_id)
        self._stats.prefetches_started += 1

        # Decide which fetches to fire based on per-slot enable AND fetcher availability.
        # Some slots may not have a fetcher wired (e.g. budget_fetch=None when
        # cost_tracker isn't wired) — skip those silently.
        tasks: dict[str, Awaitable[Any]] = {}
        if self._config.budget_enabled and self._budget_fetch is not None:
            tasks["budget"] = self._budget_fetch()
        if self._config.messages_enabled and self._messages_fetch is not None:
            tasks["messages"] = self._messages_fetch(conversation_id)
        if self._config.artifact_enabled and self._artifact_fetch is not None:
            tasks["artifact"] = self._artifact_fetch(conversation_id)

        if not tasks:
            self._in_flight.discard(conversation_id)
            return

        try:
            keys = list(tasks.keys())
            results = await asyncio.gather(*tasks.values(), return_exceptions=True)
            now = time.monotonic()
            for key, result in zip(keys, results, strict=False):
                if isinstance(result, Exception):
                    log.debug(
                        "prefetch %s for %s failed: %s",
                        key, conversation_id, type(result).__name__,
                    )
                    continue
                self._store(key, conversation_id, result, now)
            self._stats.prefetches_completed += 1
        except Exception:  # pragma: no cover — gather with return_exceptions can't raise
            self._stats.prefetches_failed += 1
            log.debug("prefetch gather raised for %s", conversation_id, exc_info=True)
        finally:
            self._in_flight.discard(conversation_id)

    def _store(self, slot_name: str, conversation_id: str, value: Any, now: float) -> None:
        """Insert into the named slot. Evicts LRU when slot exceeds max_per_slot."""
        if slot_name == "budget":
            slot = self._budget
            key = _GLOBAL_BUDGET_KEY
        elif slot_name == "messages":
            slot = self._messages
            key = conversation_id
        elif slot_name == "artifact":
            slot = self._artifact
            key = conversation_id
        else:
            return
        slot[key] = _CacheEntry(value=value, stored_at=now)
        slot.move_to_end(key)
        # LRU eviction
        while len(slot) > self._config.max_per_slot:
            slot.popitem(last=False)


__all__ = [
    "ConversationPrefetchCache",
    "PREFETCH_MISS",
    "PrefetchConfig",
    "PrefetchStats",
    "resolve_config",
]
