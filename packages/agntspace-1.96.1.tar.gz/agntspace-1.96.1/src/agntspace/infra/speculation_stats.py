"""In-memory aggregator for P4.5 speculative-streaming telemetry.

Engine module ``agent.speculative_streaming`` emits a terminal
``SpeculativeChunk(kind="done", stats={...})`` event per chat turn carrying:

  * ``mode``                 — "passthrough" (kill switch off / no draft) or
                                "speculative" (raced both streams).
  * ``displayed_chars``      — total chars yielded to the caller (after any
                                retract events were applied).
  * ``draft_started``        — whether the draft iterator was constructed.
  * ``draft_yielded_chars``  — chars emitted with source="draft" (subject
                                to retract on divergence).
  * ``diverged``             — whether real disagreed with draft and we
                                emitted at least one retract event.
  * ``retracted_chars``      — total chars retracted across the turn.
  * ``real_buffer_chars``    — total chars from the real stream.
  * ``draft_buffer_chars``   — total chars from the draft stream.

This module aggregates those per-turn dicts into running counters + derived
rates that the ``/api/admin/speculation-stats`` endpoint exposes.

In-memory only — process restart resets. Bounded memory (small fixed-size
counters; no per-turn history retained). Total failure-tolerance: every
``record()`` call is wrapped; broken stats payloads degrade to a no-op
without raising.

Adopt-on-call: ``Agent`` keeps a ``self._speculation_stats`` attribute that
may be None when the collector isn't wired (test harnesses, minimal apps).
The speculative-path code uses ``getattr`` so callers without a collector
keep working unchanged.
"""

from __future__ import annotations

import logging
import threading
from typing import Any

log = logging.getLogger(__name__)


class SpeculationStatsCollector:
    """Process-local aggregator. Thread-safe; uses a single lock around
    every counter update."""

    __slots__ = (
        "_lock",
        "_passthrough_turns",
        "_speculative_turns",
        "_diverged_turns",
        "_total_retracted_chars",
        "_total_draft_yielded_chars",
        "_total_displayed_chars",
        "_total_real_buffer_chars",
        "_total_draft_buffer_chars",
        "_record_failures",
    )

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._passthrough_turns: int = 0
        self._speculative_turns: int = 0
        self._diverged_turns: int = 0
        self._total_retracted_chars: int = 0
        self._total_draft_yielded_chars: int = 0
        self._total_displayed_chars: int = 0
        self._total_real_buffer_chars: int = 0
        self._total_draft_buffer_chars: int = 0
        self._record_failures: int = 0

    def record(self, stats: dict[str, Any] | None) -> None:
        """Update counters from one turn's ``done.stats`` payload.

        Tolerant of missing keys + wrong types — bumps ``_record_failures``
        instead of raising. A broken stats payload MUST NEVER break the
        chat path that produced it.
        """
        if not isinstance(stats, dict):
            with self._lock:
                self._record_failures += 1
            return
        try:
            mode = str(stats.get("mode", ""))
            displayed = int(stats.get("displayed_chars", 0) or 0)
            draft_yielded = int(stats.get("draft_yielded_chars", 0) or 0)
            diverged = bool(stats.get("diverged", False))
            retracted = int(stats.get("retracted_chars", 0) or 0)
            real_buf = int(stats.get("real_buffer_chars", 0) or 0)
            draft_buf = int(stats.get("draft_buffer_chars", 0) or 0)
        except (TypeError, ValueError):
            with self._lock:
                self._record_failures += 1
            return

        with self._lock:
            if mode == "speculative":
                self._speculative_turns += 1
                self._total_draft_yielded_chars += draft_yielded
                self._total_draft_buffer_chars += draft_buf
                if diverged:
                    self._diverged_turns += 1
                    self._total_retracted_chars += retracted
            else:
                # "passthrough" OR unknown mode (degrade gracefully).
                self._passthrough_turns += 1
            self._total_displayed_chars += displayed
            self._total_real_buffer_chars += real_buf

    def snapshot(self) -> dict[str, Any]:
        """Pure read — returns a dict with counters + derived rates.

        Derived rates are bounded to [0.0, 1.0]; denominators are clamped
        to 1 to avoid div-by-zero on a fresh collector.
        """
        with self._lock:
            speculative = self._speculative_turns
            passthrough = self._passthrough_turns
            diverged = self._diverged_turns
            aligned = speculative - diverged
            total = speculative + passthrough
            return {
                "total_turns": total,
                "speculative_turns": speculative,
                "passthrough_turns": passthrough,
                "diverged_turns": diverged,
                "aligned_turns": aligned,
                "total_retracted_chars": self._total_retracted_chars,
                "total_draft_yielded_chars": self._total_draft_yielded_chars,
                "total_displayed_chars": self._total_displayed_chars,
                "total_real_buffer_chars": self._total_real_buffer_chars,
                "total_draft_buffer_chars": self._total_draft_buffer_chars,
                "record_failures": self._record_failures,
                "speculation_rate": (
                    speculative / total if total > 0 else 0.0
                ),
                "alignment_rate": (
                    aligned / speculative if speculative > 0 else 0.0
                ),
                "divergence_rate": (
                    diverged / speculative if speculative > 0 else 0.0
                ),
                "avg_retract_per_diverged_turn": (
                    self._total_retracted_chars / diverged
                    if diverged > 0
                    else 0.0
                ),
            }

    def reset(self) -> None:
        """Clear all counters. Test fixtures + admin "reset stats" button."""
        with self._lock:
            self._passthrough_turns = 0
            self._speculative_turns = 0
            self._diverged_turns = 0
            self._total_retracted_chars = 0
            self._total_draft_yielded_chars = 0
            self._total_displayed_chars = 0
            self._total_real_buffer_chars = 0
            self._total_draft_buffer_chars = 0
            self._record_failures = 0
