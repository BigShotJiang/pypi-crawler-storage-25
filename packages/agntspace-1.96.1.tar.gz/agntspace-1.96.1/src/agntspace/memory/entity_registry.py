"""Unified Entity Registry — single source of truth for all entities.

Every subsystem (memory graph, KB wiki, agent tools, vault search) references
entities through this registry. One slug, one canonical name, one set of aliases.

Storage: memory/graph/entities.json (vault-centric, same as before but now
the registry owns it exclusively).
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import threading
from datetime import UTC, datetime
from difflib import SequenceMatcher
from pathlib import Path
from typing import TYPE_CHECKING, Any

from agntspace.memory.ontology import EntityType, resolve_entity_type
from agntspace.text import sanitize_name as _sanitize_name
from agntspace.text import strip_comma_descriptor as _strip_comma_descriptor

if TYPE_CHECKING:
    from agntspace.vault.reader import VaultReader
    from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

_ENTITIES_PATH = "memory/graph/entities.json"
_ENTITY_INDEXES_PATH = "memory/graph/entity_indexes.json"
_ENTITY_INDEXES_SCHEMA_VERSION = 1  # bump when on-disk shape changes

# ── Resolution thresholds ──
_EMBEDDING_RESOLVE = 0.82       # Tier 3 cutoff (embedding cosine)
_SEQUENCE_RESOLVE = 0.92        # Tier 4 cutoff (SequenceMatcher, hardened 2026-04-17)


def _on_async_event_loop() -> bool:
    """True when the current thread is running an asyncio event loop.

    Calling a synchronous ``httpx.Client`` request (or any blocking I/O) from
    here would freeze every pending FastAPI request for the duration of the
    HTTP round-trip — 8 s on cold-start Ollama and 50 ms even on warm calls.
    With thousands of entities that's minutes of stacked blockage on the main
    loop. Callers on the loop MUST skip embedding and fall back to the string
    tiers; background work (graph build runs in a pool executor) still runs
    embedding normally because ``get_running_loop()`` raises there.
    """
    try:
        asyncio.get_running_loop()
        return True
    except RuntimeError:
        return False


def _slugify(name: str) -> str:
    """Convert entity name to a stable slug ID."""
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")


def _now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _differs_only_in_digits(a: str, b: str) -> bool:
    """Return True if *a* and *b* differ only in their digit characters.

    "oldentity0" vs "oldentity1" → True (same letters, different digits).
    "sarah chen" vs "sarah c."   → False (letters differ).
    """
    alpha_a = re.sub(r"\d", "", a)
    alpha_b = re.sub(r"\d", "", b)
    return alpha_a == alpha_b and a != b


class RegistrySnapshotReader:
    """Read-only consumer of the EntityRegistry on-disk index snapshot.

    Sprint γ.3 Phase 2 (2026-05-15). Worker processes that only need
    name → slug resolution can construct one of these from the snapshot
    file written by :meth:`EntityRegistry.save` without taking the
    write-side lock, holding a VaultWriter, or loading entities.json
    (which can be megabytes on heavy vaults).

    **Contract — tier-1 + tier-1b + tier-2 only.** Mirrors the first
    three resolution tiers of :meth:`EntityRegistry.resolve`:

    1. Exact slug match — derived from the union of ``name_index``
       values (every entity contributes one canonical-name entry).
    2. Exact canonical-name match (case-insensitive) via ``name_index``.
    3. Alias match via ``alias_index``.

    Tier-3 (embedding cosine) and tier-4 (SequenceMatcher) are NOT
    supported — callers that need fuzzy resolution must use the full
    :class:`EntityRegistry`. The snapshot's contract is "what the
    persisted indexes know"; embedding state lives in a separate cache
    that's not part of the snapshot, and fuzzy matching would need the
    full entity catalog which we deliberately don't carry here.

    Construction paths:

    - :meth:`from_vault` — load + validate from disk. Returns None on
      missing / corrupt / version-mismatched snapshots. Use this from
      worker processes that boot independently of the main registry.
    - :meth:`from_dict` — construct from a pre-parsed snapshot dict.
      Use this from in-process callers (tests, the main process
      passing a snapshot to a child via pickle).

    Instances are **immutable after construction** and **pickleable**.
    All internal collections are `frozenset` / read-only-dict at the
    public boundary so worker processes can share a single instance
    across threads without locking.
    """

    __slots__ = (
        "_name_index",
        "_alias_index",
        "_known_slugs",
        "_entity_count",
        "_schema_version",
        "_saved_at",
    )

    def __init__(
        self,
        *,
        name_index: dict[str, str],
        alias_index: dict[str, str],
        entity_count: int,
        schema_version: int,
        saved_at: str,
    ) -> None:
        # Defensive copies so the caller can't mutate our state by
        # mutating their original dicts post-construction.
        self._name_index: dict[str, str] = dict(name_index)
        self._alias_index: dict[str, str] = dict(alias_index)
        # Tier-1 "is this slug known?" needs a fast set. Build it once
        # from the values of both indexes — every entity contributes
        # exactly one canonical-name entry to name_index, so its slug
        # is always present there. Alias entries point at the same
        # slugs, so the union is exhaustive.
        self._known_slugs: frozenset[str] = frozenset(self._name_index.values())
        self._entity_count: int = int(entity_count)
        self._schema_version: int = int(schema_version)
        self._saved_at: str = str(saved_at)

    # ── Construction ──

    @classmethod
    def from_vault(
        cls, vault_dir: Path | str,
    ) -> RegistrySnapshotReader | None:
        """Load + validate a snapshot from a vault directory.

        Returns None on every failure path (missing file / corrupt JSON
        / non-dict root / schema_version mismatch / malformed indexes).
        Callers MUST handle the None case by falling back to a full
        :class:`EntityRegistry` load.

        The ``entity_count`` field is NOT cross-checked against
        ``entities.json`` here because worker processes typically don't
        load entities.json. If the snapshot is stale relative to
        entities.json, the main process's next :meth:`EntityRegistry.save`
        will rewrite it. Workers consume "what the snapshot says" — the
        main process owns the freshness contract.
        """
        vault_dir = Path(vault_dir)
        snap_path = vault_dir / _ENTITY_INDEXES_PATH
        if not snap_path.exists():
            return None

        try:
            raw = snap_path.read_text(encoding="utf-8")
            data = json.loads(raw)
        except Exception:
            log.debug(
                "RegistrySnapshotReader: snapshot at %s unreadable", snap_path,
                exc_info=True,
            )
            return None

        return cls.from_dict(data)

    @classmethod
    def from_dict(cls, data: object) -> RegistrySnapshotReader | None:
        """Construct from a pre-parsed snapshot dict. Same validation
        rules as :meth:`EntityRegistry._load_indexes_locked` minus the
        entity_count cross-check (workers don't have entities.json).
        """
        if not isinstance(data, dict):
            return None
        if data.get("schema_version") != _ENTITY_INDEXES_SCHEMA_VERSION:
            return None

        name_index = data.get("name_index")
        alias_index = data.get("alias_index")
        if not isinstance(name_index, dict) or not isinstance(alias_index, dict):
            return None

        # Coerce + validate every entry. One bad row returns None.
        new_name: dict[str, str] = {}
        for key, value in name_index.items():
            if not isinstance(key, str) or not isinstance(value, str):
                return None
            new_name[key] = value
        new_alias: dict[str, str] = {}
        for key, value in alias_index.items():
            if not isinstance(key, str) or not isinstance(value, str):
                return None
            new_alias[key] = value

        entity_count_raw = data.get("entity_count", 0)
        try:
            entity_count = int(entity_count_raw)
        except (TypeError, ValueError):
            return None

        saved_at = data.get("saved_at", "")
        if not isinstance(saved_at, str):
            saved_at = ""

        return cls(
            name_index=new_name,
            alias_index=new_alias,
            entity_count=entity_count,
            schema_version=_ENTITY_INDEXES_SCHEMA_VERSION,
            saved_at=saved_at,
        )

    # ── Resolution ──

    def resolve(self, name: str) -> str | None:
        """Resolve an entity name to its slug. Tier-1 + tier-1b + tier-2 only.

        - Tier 1: exact slug match (case-preserving slugify of the input)
        - Tier 1b: exact canonical-name match (case-insensitive)
        - Tier 2: exact alias match (case-insensitive)

        Returns None when no tier matches. Callers that need fuzzy /
        embedding-based matching must fall back to the full
        :class:`EntityRegistry`. The snapshot reader's contract is
        intentionally narrow so worker processes can resolve without
        loading the embedding model or holding any locks.
        """
        name = _sanitize_name(name)
        if not name:
            return None
        name_lower = name.lower().strip()
        slug = _slugify(name)

        # Tier 1: exact slug match (was the caller already slugified?)
        if slug in self._known_slugs:
            return slug

        # Tier 1b: exact canonical name
        if name_lower in self._name_index:
            return self._name_index[name_lower]

        # Tier 2: alias match
        if name_lower in self._alias_index:
            return self._alias_index[name_lower]

        return None

    # ── Read-only introspection ──

    @property
    def entity_count(self) -> int:
        """Number of entities captured in the snapshot at save time."""
        return self._entity_count

    @property
    def schema_version(self) -> int:
        """Snapshot schema version (always matches the engine's expected version)."""
        return self._schema_version

    @property
    def saved_at(self) -> str:
        """ISO-8601 UTC timestamp from the snapshot. May be empty on legacy files."""
        return self._saved_at

    @property
    def known_slugs(self) -> frozenset[str]:
        """Frozen view of every slug the snapshot can resolve to."""
        return self._known_slugs

    def __contains__(self, slug: str) -> bool:
        """Membership test: ``'sarah-chen' in reader`` returns True iff
        the snapshot has a name_index entry for that slug.
        """
        return slug in self._known_slugs

    def __len__(self) -> int:
        """Number of known slugs. May differ from :attr:`entity_count`
        only if the snapshot is malformed (the on-disk format guarantees
        they agree)."""
        return len(self._known_slugs)

    def __repr__(self) -> str:
        return (
            f"RegistrySnapshotReader(entities={self._entity_count}, "
            f"names={len(self._name_index)}, aliases={len(self._alias_index)}, "
            f"schema_version={self._schema_version}, saved_at={self._saved_at!r})"
        )

    # ── Pickle support ──
    # __slots__ + simple types make us pickleable by default, but we
    # define __getstate__/__setstate__ explicitly to lock the contract
    # against future __slots__ changes accidentally breaking workers
    # that receive snapshots over IPC.

    def __getstate__(self) -> dict:
        return {
            "name_index": dict(self._name_index),
            "alias_index": dict(self._alias_index),
            "entity_count": self._entity_count,
            "schema_version": self._schema_version,
            "saved_at": self._saved_at,
        }

    def __setstate__(self, state: dict) -> None:
        self._name_index = dict(state["name_index"])
        self._alias_index = dict(state["alias_index"])
        self._known_slugs = frozenset(self._name_index.values())
        self._entity_count = int(state["entity_count"])
        self._schema_version = int(state["schema_version"])
        self._saved_at = str(state["saved_at"])


class EntityRegistry:
    """Canonical registry for all entities in the system.

    Every entity has:
    - slug: stable ID derived from name
    - canonical_name: display name
    - entity_type: from ontology EntityType
    - aliases: alternative names
    - authority: explicit > system > inferred (never downgrades)
    - decay_condition: when to forget
    - access tracking: first_seen, last_accessed, access_count
    - status: active or decayed
    """

    def __init__(
        self,
        vault: VaultReader | None = None,
        writer: VaultWriter | None = None,
    ) -> None:
        self._vault = vault
        self._writer = writer
        self._entities: dict[str, dict[str, Any]] = {}
        self._dirty = False

        # Indexes for fast lookup
        self._name_index: dict[str, str] = {}   # lowercase name -> slug
        self._alias_index: dict[str, str] = {}   # lowercase alias -> slug

        # Reentrant lock guards every read and write of the shared state
        # (_entities / _name_index / _alias_index / _embedding_cache / _dirty).
        # The knowledge-graph build runs in a ThreadPoolExecutor while KB
        # ingest + chat entity extraction call add()/resolve() from the main
        # event loop and other worker tasks; without this lock iteration and
        # mutation race, producing "dictionary changed size during iteration"
        # that kills the background graph build permanently. RLock (not Lock)
        # because add() calls resolve() and merge() calls _rebuild_indexes.
        self._lock = threading.RLock()

        # Embedding-based dedup (Tier 4 resolution).
        # Injected post-hoc: ``registry._embedder = vault_embeddings._get_model()``
        # When set, resolve() uses cosine similarity as a final fallback
        # after string-based tiers fail. This catches paraphrases,
        # abbreviations, and name permutations that SequenceMatcher misses.
        self._embedder: object | None = None
        self._embedding_cache: dict[str, Any] = {}  # slug -> embedding vector
        # Optional shared EmbeddingQueryCache (P1.4). Injected post-hoc
        # by main.py: ``registry._query_cache = embedding_query_cache``.
        # When wired, name-resolution embed calls short-circuit through
        # the cache before hitting Ollama. None preserves legacy path.
        self._query_cache: Any | None = None
        # Circuit breaker: when embedding calls fail (Ollama slow/unreachable),
        # skip the embedding tier for the rest of the process lifetime rather
        # than blocking every entity resolution on 40-second cold-start calls.
        # Reset only by service restart — deliberately NOT time-based because
        # a thrashing cold-start that recovers on retry N is still worse than
        # deterministic FTS-only behavior. The user can re-enable by restarting
        # after warming up the embedding model.
        self._embedding_disabled: bool = False
        # Tier 4 (SequenceMatcher) disable flag — mirrors _embedding_disabled.
        # Set by callers that resolve thousands of names in a tight loop where
        # Tier 4's O(entities × name_length²) cost would saturate CPU for
        # minutes producing no progress. The historical pathology: incremental
        # graph build's _project_wikilink_index calls resolve() ~50 × 2600
        # = 132K times against a 7000-entity registry; each Tier 4 call does
        # 14K+ SequenceMatcher.ratio() comparisons; CPU pinned at 100%, no
        # progress, no log lines, indistinguishable from a deadlock.
        # Tier 1 (exact slug) and Tier 2 (alias index) are O(1) and remain
        # active — they handle every wikilink that was successfully resolved
        # in the original scan, which is all the projection cares about.
        self._fuzzy_disabled: bool = False
        # Cap the per-call cache-refresh batch size. At 3766 entities a full
        # refresh hits Ollama with one giant batch that takes minutes to return
        # cold. Capping at N means first resolve embeds N entities, next N
        # entities get embedded on next resolve, etc — no single call ever
        # blocks the event loop for more than ~1× single-embed latency.
        self._embedding_batch_cap: int = 50

    def load(self) -> int:
        """Load entities from vault JSON. Returns count loaded.

        After loading entities.json, attempts to load the persisted
        ``_name_index`` + ``_alias_index`` snapshot from
        :data:`_ENTITY_INDEXES_PATH` (Sprint γ.3, 2026-05-15). When that
        snapshot is fresh (matches entity_count and schema_version), we
        skip ``_rebuild_indexes()``. On any failure — missing file,
        corrupt JSON, version mismatch, entity_count drift — we fall
        back to the legacy rebuild path. Behavior is byte-identical to
        the pre-snapshot path when the snapshot is absent or stale.
        """
        if not self._vault:
            return 0

        if not self._vault.exists(_ENTITIES_PATH):
            return 0

        try:
            path = self._vault.paths.resolve(_ENTITIES_PATH) if self._vault.paths else self._vault._vault_dir / _ENTITIES_PATH
            raw = path.read_text(encoding="utf-8")
            data = json.loads(raw)
            with self._lock:
                self._entities = data
                count = len(self._entities)
                # Try the fast path first: load persisted indexes when the
                # snapshot is fresh for the entity_count we just read.
                if not self._load_indexes_locked(expected_count=count):
                    self._rebuild_indexes()
            log.debug("EntityRegistry: loaded %d entities", count)
            return count
        except Exception as e:
            log.warning("EntityRegistry: failed to load entities.json: %s", e)
            with self._lock:
                self._entities = {}
            return 0

    def save(self) -> None:
        """Persist entities to vault JSON.

        Also persists the index snapshot to :data:`_ENTITY_INDEXES_PATH`
        in the same write window so a future :meth:`load` can skip
        ``_rebuild_indexes()``. Index save is best-effort: a failure
        never breaks the entities.json write or raises to the caller —
        the next boot just falls back to the rebuild path.
        """
        if not self._writer:
            return
        # Serialize under lock to prevent iteration during mutation; then
        # release the lock before doing vault I/O so a slow write doesn't
        # block resolve() / add() for seconds.
        with self._lock:
            if not self._dirty:
                return
            entities_json = json.dumps(self._entities, separators=(",", ":"), ensure_ascii=False)
            indexes_json = self._serialize_indexes_locked(entity_count=len(self._entities))
            self._dirty = False
            count = len(self._entities)
        # Internal bookkeeping write — the graph state is a side effect of
        # higher-level decisions (chat turn entity extraction, KB ingest,
        # dream phases, memory consolidation). Those callers gate their
        # own contract checks; here we declare trusted persistence so the
        # VaultWriter runtime guard passes regardless of caller scope.
        self._writer.write(_ENTITIES_PATH, entities_json, trust_reason="graph_persist")
        # Index snapshot — Sprint γ.3 Phase 1. Best-effort: a broken
        # snapshot write never propagates because the next boot rebuilds
        # the indexes from entities.json regardless.
        try:
            self._writer.write(_ENTITY_INDEXES_PATH, indexes_json, trust_reason="graph_persist")
        except Exception:
            log.debug("EntityRegistry: index snapshot write failed", exc_info=True)
        log.info("EntityRegistry: saved %d entities", count)

    def _serialize_indexes_locked(self, *, entity_count: int) -> str:
        """Serialize ``_name_index`` + ``_alias_index`` for on-disk snapshot.

        Caller must hold ``self._lock``. Schema-versioned so future
        shape changes invalidate stale files via ``_load_indexes_locked``'s
        version check. ``entity_count`` is the load-time validation key —
        if entities.json grows or shrinks out-of-band, the snapshot is
        considered stale and rebuilt.
        """
        payload = {
            "schema_version": _ENTITY_INDEXES_SCHEMA_VERSION,
            "entity_count": entity_count,
            "saved_at": _now_iso(),
            "name_index": dict(self._name_index),
            "alias_index": dict(self._alias_index),
        }
        return json.dumps(payload, separators=(",", ":"), ensure_ascii=False)

    def _load_indexes_locked(self, *, expected_count: int) -> bool:
        """Populate ``_name_index`` + ``_alias_index`` from on-disk snapshot.

        Caller must hold ``self._lock``. Returns True iff the snapshot
        was loaded successfully (caller can skip ``_rebuild_indexes``).
        Every failure path returns False silently so the caller falls
        back to the rebuild — no warning spam on fresh vaults that
        legitimately have no snapshot yet.

        Validation order (failure on any returns False, in-memory indexes
        left empty so the caller's rebuild starts from a clean slate):

        1. Vault is wired AND file exists
        2. JSON parses without raising
        3. Top-level is a dict
        4. ``schema_version`` matches :data:`_ENTITY_INDEXES_SCHEMA_VERSION`
        5. ``entity_count`` matches ``expected_count`` (entities.json drift)
        6. ``name_index`` and ``alias_index`` are dicts with string keys/values
        """
        if not self._vault:
            return False
        if not self._vault.exists(_ENTITY_INDEXES_PATH):
            return False

        try:
            path = self._vault.paths.resolve(_ENTITY_INDEXES_PATH) if self._vault.paths else self._vault._vault_dir / _ENTITY_INDEXES_PATH
            raw = path.read_text(encoding="utf-8")
            data = json.loads(raw)
        except Exception:
            log.debug("EntityRegistry: index snapshot unreadable, will rebuild", exc_info=True)
            return False

        if not isinstance(data, dict):
            return False
        if data.get("schema_version") != _ENTITY_INDEXES_SCHEMA_VERSION:
            return False
        if data.get("entity_count") != expected_count:
            return False

        name_index = data.get("name_index")
        alias_index = data.get("alias_index")
        if not isinstance(name_index, dict) or not isinstance(alias_index, dict):
            return False

        # Coerce + validate every entry. A single bad row falls back to
        # rebuild rather than silently corrupting the registry. The cost
        # is one Python pass over the entries; the rebuild it skips is
        # the same shape, so net cost is the dominant of (validate, rebuild).
        new_name: dict[str, str] = {}
        for key, value in name_index.items():
            if not isinstance(key, str) or not isinstance(value, str):
                return False
            new_name[key] = value
        new_alias: dict[str, str] = {}
        for key, value in alias_index.items():
            if not isinstance(key, str) or not isinstance(value, str):
                return False
            new_alias[key] = value

        # Cross-check: every indexed slug must reference an entity that
        # actually exists in self._entities (otherwise a stale snapshot
        # would happily resolve names to deleted slugs). One drift here
        # invalidates the whole snapshot — rebuild path is cheap and
        # always produces a consistent answer.
        for slug in new_name.values():
            if slug not in self._entities:
                return False
        for slug in new_alias.values():
            if slug not in self._entities:
                return False

        self._name_index = new_name
        self._alias_index = new_alias
        return True

    def _rebuild_indexes(self) -> None:
        """Rebuild name and alias indexes from entity data.

        Caller must hold self._lock (internal helper — already invoked from
        load() / merge() / add() which take the lock themselves).
        """
        self._name_index.clear()
        self._alias_index.clear()
        for slug, ent in self._entities.items():
            name_lower = ent["canonical_name"].lower()
            self._name_index[name_lower] = slug
            for alias in ent.get("aliases", []):
                self._alias_index[alias.lower()] = slug

    # ── Resolution ──

    def resolve(self, name: str) -> str | None:
        """Resolve an entity name to its slug. Four-tier matching.

        1. Exact slug or canonical name (case-insensitive) — O(1)
        2. Alias match (via index) — O(1)
        3. Embedding similarity (cosine ≥ 0.82) — semantic match that
           catches abbreviations ("J. Smith" → "John Smith"), name
           permutations ("Chen, Sarah" → "Sarah Chen"), and paraphrases.
           Primary fuzzy tier when embedder is available.
        4. SequenceMatcher (≥ 0.92) — character-level fallback when
           embedder is unavailable (test fixtures, Ollama offline,
           embedding model not pulled). Hardened 2026-04-17 to 0.92
           to avoid false-positive merges between distinct entities.
        """
        name = _sanitize_name(name)
        if not name:
            return None
        name_lower = name.lower().strip()
        slug = _slugify(name)

        with self._lock:
            # Tier 1: exact slug
            if slug in self._entities:
                return slug

            # Tier 1b: exact canonical name (via index)
            if name_lower in self._name_index:
                return self._name_index[name_lower]

            # Tier 2: alias (via index)
            if name_lower in self._alias_index:
                return self._alias_index[name_lower]

        # Tier 3: embedding similarity (primary fuzzy tier). Released the
        # lock before the LLM call so a slow Ollama embed doesn't block
        # other resolves — _resolve_by_embedding reacquires it around
        # the cache iteration itself.
        if len(name) > 3 and self._embedder is not None:
            try:
                match = self._resolve_by_embedding(name)
                if match is not None:
                    return match
            except Exception:
                log.debug("Embedding resolution failed", exc_info=True)

        # Tier 4: SequenceMatcher fallback. Under the lock to prevent
        # mid-iteration mutation from the graph-build thread. Skipped
        # when ``_fuzzy_disabled`` is set — see flag docstring above
        # for the runaway-loop pathology this guards against.
        if len(name) > 5 and not self._fuzzy_disabled:
            with self._lock:
                best_score = 0.0
                best_slug = None
                best_candidate = ""
                for s, ent in self._entities.items():
                    canon = ent["canonical_name"].lower()
                    score = SequenceMatcher(None, name_lower, canon).ratio()
                    if score > best_score:
                        best_score = score
                        best_slug = s
                        best_candidate = canon
                    for alias in ent.get("aliases", []):
                        al = alias.lower()
                        score = SequenceMatcher(None, name_lower, al).ratio()
                        if score > best_score:
                            best_score = score
                            best_slug = s
                            best_candidate = al
                if best_score >= _SEQUENCE_RESOLVE and best_slug:
                    # Guard: names differing only in digits are distinct
                    # entities (Entity0 vs Entity1, Version2 vs Version3).
                    if not _differs_only_in_digits(name_lower, best_candidate):
                        return best_slug

        return None

    def _resolve_by_embedding(
        self, name: str, min_score: float = _EMBEDDING_RESOLVE,
    ) -> str | None:
        """Resolve via cosine similarity on entity name embeddings.

        Embeds the query name and compares against cached embeddings of
        all canonical names + aliases. Returns the slug of the best
        match above *min_score*, or None.

        Concurrency-safe: snapshots the cache before iterating so parallel
        writes from the graph-build thread don't raise
        "dictionary changed size during iteration". Circuit breaker
        (``_embedding_disabled``) trips on first embed failure to avoid
        40-second cold-start stalls on every resolve.
        """
        import math

        model = self._embedder
        with self._lock:
            if model is None or not self._entities or self._embedding_disabled:
                return None

        # Event-loop safety: refuse to run a blocking HTTP embed call from the
        # main asyncio loop. The circuit breaker is NOT tripped — this is a
        # "skip this tier for this caller" decision, not a permanent embed
        # failure. Graph-build callers run in a pool executor and pass this
        # check; chat / ingest / API callers on the main loop fall back to
        # string tiers (which are fast and pure Python).
        if _on_async_event_loop():
            return None

        # P1.4: short-circuit through the shared embedding query cache
        # when wired. Same-name resolves (which fire repeatedly during
        # ingest as the same entity appears in multiple chunks) become
        # microsecond cache hits instead of Ollama round-trips.
        query_cache = self._query_cache
        cached_emb: list[float] | None = None
        if query_cache is not None:
            try:
                cached_emb = query_cache.get_or_embed(model, name)
            except Exception:
                log.debug(
                    "EntityRegistry: query cache failed, falling through",
                    exc_info=True,
                )
                cached_emb = None

        if cached_emb is not None:
            query_emb = [float(x) for x in cached_emb]
        else:
            try:
                query_emb = [float(x) for x in list(model.embed([name]))[0]]
            except Exception:
                # First embed failure trips the breaker — further calls would
                # time out identically and block every resolve for ~40s each.
                with self._lock:
                    self._embedding_disabled = True
                log.info(
                    "EntityRegistry: embedding tier disabled for this process "
                    "(query embed failed — Ollama not reachable or model not pulled). "
                    "Resolution falls back to string tiers.",
                )
                return None
        query_sq = sum(x * x for x in query_emb)
        if query_sq < 1e-18:
            return None
        query_norm = math.sqrt(query_sq)

        self._refresh_embedding_cache()

        best_score = 0.0
        best_slug = None
        # Hold the lock across the cache iteration. Pure arithmetic, so
        # contention is minimal; prevents the build thread from mutating
        # _embedding_cache mid-scan (which crashed resolve today at 17:21).
        with self._lock:
            for slug, emb in self._embedding_cache.items():
                emb_list = list(emb) if not isinstance(emb, list) else emb
                if len(emb_list) != len(query_emb):
                    continue
                emb_sq = 0.0
                dot = 0.0
                for a, b in zip(query_emb, emb_list, strict=False):
                    dot += a * float(b)
                    emb_sq += float(b) * float(b)
                if emb_sq < 1e-18:
                    continue
                score = dot / (query_norm * math.sqrt(emb_sq))
                if score > best_score:
                    best_score = score
                    best_slug = slug

        if best_score >= min_score and best_slug:
            log.debug(
                "Embedding resolved '%s' -> '%s' (score=%.3f)",
                name, best_slug, best_score,
            )
            return best_slug
        return None

    def _refresh_embedding_cache(self) -> None:
        """Rebuild embedding cache for entities not yet cached.

        Capped at ``_embedding_batch_cap`` per call. With thousands of
        entities and a cold-start Ollama model, an uncapped batch would
        block resolution for minutes on first call. Capped means we amortize
        the cache fill across many resolves — each call embeds a small batch
        while still making progress. Ambiguous placeholders are excluded
        (they are resolution outputs, never targets).
        """
        model = self._embedder
        with self._lock:
            if model is None or self._embedding_disabled:
                return

        # Event-loop safety: same rule as _resolve_by_embedding. Skipping is
        # safe — the cache fills opportunistically from off-loop callers
        # (graph build, explicit warm-up) and resolves on-loop gracefully
        # miss the embedding tier rather than blocking the loop for seconds.
        if _on_async_event_loop():
            return

        with self._lock:
            # Collect texts to embed (canonical name + aliases, one per slug).
            # Under the lock so we can iterate self._entities + self._embedding_cache
            # without racing the graph-build thread.
            to_embed: list[tuple[str, str]] = []  # (slug, text)
            for slug, ent in self._entities.items():
                if slug in self._embedding_cache:
                    continue
                # Combine canonical name + aliases into one embedding text
                parts = [ent["canonical_name"]]
                parts.extend(ent.get("aliases", [])[:3])  # cap aliases
                to_embed.append((slug, " | ".join(parts)))
                if len(to_embed) >= self._embedding_batch_cap:
                    break

        if not to_embed:
            return

        texts = [t[1] for t in to_embed]
        # Embed outside the lock — a slow Ollama call must not block
        # every resolver behind us for its full duration.
        try:
            embeddings = list(model.embed(texts))
        except Exception:
            # Trip the circuit breaker on the first failure so later calls
            # don't retry. Logged at INFO so the operator sees it without
            # exception spam.
            with self._lock:
                self._embedding_disabled = True
            log.info(
                "EntityRegistry: embedding cache refresh failed "
                "(Ollama not reachable or model not pulled). "
                "Falling back to string resolution tiers.",
            )
            return

        with self._lock:
            for (slug, _), emb in zip(to_embed, embeddings, strict=False):
                self._embedding_cache[slug] = emb

    def invalidate_embedding_cache(self, slug: str | None = None) -> None:
        """Clear cached embeddings. Called after entity add/merge/delete."""
        with self._lock:
            if slug:
                self._embedding_cache.pop(slug, None)
            else:
                self._embedding_cache.clear()

    def backfill_embeddings_blocking(
        self,
        *,
        batch_size: int = 50,
        max_entities: int | None = None,
    ) -> dict:
        """Embed every registered entity that isn't yet in the cache.

        Blocking — caller MUST run via ``asyncio.to_thread`` or in a worker
        thread, NEVER on the asyncio main loop. The event-loop guard in
        ``_refresh_embedding_cache`` is bypassed here on purpose: this is
        an explicit user-triggered fill, not an opportunistic resolver
        side-effect.

        Resets the circuit breaker (``_embedding_disabled``) at the start
        — the user may have just installed Ollama or pulled the model and
        wants a fresh attempt. If the embed call fails again, the breaker
        trips as normal and the loop exits.

        Side-effect-free w.r.t. epistemic semantics: embeddings are a
        similarity lookup tool. No triple is added, removed, repointed,
        or reweighted. No status, authority, decay, or cascade is touched.
        Worst case (all batches fail): the cache is no fuller than before.

        Args:
            batch_size: number of entities to embed per round trip. Bounded
                so that a single failed call doesn't waste a huge batch.
            max_entities: hard cap on total entities scanned in this call.
                ``None`` = no cap, fill the whole registry. Useful for
                throttled / cancellable progressive runs.

        Returns:
            dict with: ``scanned`` (entities pulled into batches),
            ``embedded`` (entities successfully embedded),
            ``failed`` (entities in the failing batch when the breaker
            tripped — they're NOT cached), ``total_entities`` (registry
            size at exit), ``cached_after`` (cache size at exit),
            ``embedder_disabled`` (final state of the circuit breaker),
            ``reason`` (only on early-out: ``"no_embedder"``).
        """
        model = self._embedder
        if model is None:
            return {
                "scanned": 0,
                "embedded": 0,
                "failed": 0,
                "total_entities": len(self._entities),
                "cached_after": len(self._embedding_cache),
                "embedder_disabled": False,
                "reason": "no_embedder",
            }

        # Reset breaker — explicit user-triggered retry. If embeds fail
        # again, the loop trips it back on the first batch failure.
        with self._lock:
            self._embedding_disabled = False

        embedded = 0
        failed = 0
        scanned = 0
        if batch_size < 1:
            batch_size = 1

        while True:
            with self._lock:
                if max_entities is not None and scanned >= max_entities:
                    break
                # Collect next batch — entities not yet cached.
                to_embed: list[tuple[str, str]] = []
                for slug, ent in self._entities.items():
                    if slug in self._embedding_cache:
                        continue
                    parts = [ent["canonical_name"]]
                    parts.extend(ent.get("aliases", [])[:3])
                    to_embed.append((slug, " | ".join(parts)))
                    if len(to_embed) >= batch_size:
                        break

            if not to_embed:
                break

            # Respect max_entities even mid-batch.
            if max_entities is not None:
                remaining = max_entities - scanned
                if remaining < len(to_embed):
                    to_embed = to_embed[:remaining]
                if not to_embed:
                    break

            scanned += len(to_embed)
            texts = [t[1] for t in to_embed]
            try:
                # Embed outside the lock — Ollama latency is real.
                embeddings = list(model.embed(texts))
            except Exception as exc:
                # Trip the breaker so subsequent resolvers don't all stall
                # for the same reason.
                log.info(
                    "EntityRegistry: backfill embed batch failed: %s", exc,
                )
                failed += len(to_embed)
                with self._lock:
                    self._embedding_disabled = True
                break

            with self._lock:
                for (slug, _), emb in zip(to_embed, embeddings, strict=False):
                    self._embedding_cache[slug] = emb
                    embedded += 1

        return {
            "scanned": scanned,
            "embedded": embedded,
            "failed": failed,
            "total_entities": len(self._entities),
            "cached_after": len(self._embedding_cache),
            "embedder_disabled": self._embedding_disabled,
        }

    # ── CRUD ──

    def add(
        self,
        name: str,
        entity_type: str | EntityType = EntityType.THING,
        authority: str = "inferred",
        aliases: list[str] | None = None,
        decay_condition: str = "when:unaccessed:90d",
    ) -> str:
        """Add or update an entity. Returns the slug.

        If entity exists: merges aliases, upgrades authority (never downgrades),
        updates entity_type if more specific.
        """
        # Sanitize name first — reject embedded newlines, markdown markers,
        # and control-only junk. This is the single chokepoint for every
        # entity write; callers that pass garbage get an empty slug back
        # and nothing is stored.
        name = _sanitize_name(name)
        if not name:
            return ""

        # Comma-descriptor strip: catches the LLM extraction error where
        # a role/description gets glued to a proper-noun head with a
        # comma — "Erasmo Zuleta, gobernador de Córdoba" gets stripped
        # to "Erasmo Zuleta" while the original full string is seeded
        # as an alias so prior queries still resolve. Conservative — only
        # fires when the post-comma segment starts with a lowercase
        # letter AND neither part contains another comma. Preserves
        # legitimate names like "University of California, Berkeley" and
        # "Smith, John". This is the deterministic safety net behind the
        # skill-driven Name Purity rule (kb-ingest, memory-consolidate,
        # memory-dream-light/deep/rem). See ``strip_comma_descriptor``.
        clean_name, original_full = _strip_comma_descriptor(name)
        comma_descriptor_alias = ""
        if original_full and clean_name and clean_name != name:
            log.debug(
                "Entity name normalized: '%s' -> '%s' (comma-descriptor stripped; "
                "original preserved as alias)",
                original_full, clean_name,
            )
            name = clean_name
            comma_descriptor_alias = original_full

        # Cross-language canonicalization (spec v1.1 item 6):
        # If the caller passes a non-English form of a known canonical entity
        # (e.g. "Стокгольм", "北京"), swap to the English canonical name so
        # the slug stays ASCII-safe, and remember the foreign form as an
        # alias to seed below.
        _was_non_canonical_alias = False
        try:
            from agntspace.infra.language import canonical_from_alias
            canonical = canonical_from_alias(name)
            if canonical and canonical != name:
                name = canonical
                _was_non_canonical_alias = True
        except Exception:
            pass

        # Normalize entity_type
        if isinstance(entity_type, str):
            etype = resolve_entity_type(entity_type)
        else:
            etype = entity_type

        existing = self.resolve(name)
        now = _now_iso()

        # If the comma-descriptor strip fired AND the canonical short form
        # already exists in the registry, fold the original full string
        # into the existing entity's aliases instead of dropping it.
        merge_aliases = list(aliases or [])
        if comma_descriptor_alias and comma_descriptor_alias not in merge_aliases:
            merge_aliases.append(comma_descriptor_alias)

        # RLock is reentrant — resolve() / _merge_existing() can safely
        # reacquire. Holding the lock across the whole block ensures the
        # slug-collision counter below doesn't race with a concurrent add().
        with self._lock:
            if existing:
                return self._merge_existing(existing, etype, authority, merge_aliases, now)

            # New entity
            slug = _slugify(name)
            base_slug = slug
            counter = 2
            while slug in self._entities:
                slug = f"{base_slug}-{counter}"
                counter += 1

            # Cross-language alias seeding (spec §19 item 6):
            # If `name` is a known canonical entity (or a known alias), auto-add
            # all cross-language forms so "Stockholm" / "Стокгольм" / "斯德哥尔摩"
            # all resolve to the same slug.
            seeded_aliases: list[str] = list(aliases or [])
            # Preserve the pre-strip full string as an alias so prior
            # queries / extractions that used the long form still resolve
            # to this slug. Insert ahead of cross-language forms so the
            # original spelling stays first in the alias list.
            if comma_descriptor_alias and comma_descriptor_alias not in seeded_aliases:
                seeded_aliases.append(comma_descriptor_alias)
            try:
                from agntspace.infra.language import (
                    canonical_from_alias,
                    cross_language_aliases,
                )
                canonical = canonical_from_alias(name) or name
                extra = cross_language_aliases(canonical)
                # If the user passed a non-English form, also add the canonical
                # English form as an alias so lookup works from any direction.
                if canonical != name and canonical not in seeded_aliases:
                    seeded_aliases.append(canonical)
                for form in extra:
                    if form and form != name and form not in seeded_aliases:
                        seeded_aliases.append(form)
            except Exception:
                pass

            self._entities[slug] = {
                "canonical_name": name,
                "entity_type": etype.value,
                "aliases": seeded_aliases,
                "authority": authority,
                "decay_condition": decay_condition,
                "first_seen": now,
                "last_accessed": now,
                "access_count": 0,
                "status": "active",
            }

            # Update indexes
            self._name_index[name.lower()] = slug
            for alias in seeded_aliases:
                self._alias_index[alias.lower()] = slug

            self._dirty = True
            self.invalidate_embedding_cache(slug)
            return slug

    def _merge_existing(
        self,
        slug: str,
        entity_type: EntityType,
        authority: str,
        aliases: list[str] | None,
        now: str,
    ) -> str:
        """Merge new data into an existing entity.

        Caller must hold ``self._lock`` — invoked from ``add()`` which already
        holds it. RLock is reentrant so nested acquisition is safe; we declare
        the invariant so future refactors don't accidentally bypass the lock.
        """
        ent = self._entities[slug]

        # Merge aliases
        if aliases:
            current_aliases = set(ent.get("aliases", []))
            new_aliases = set(aliases) - current_aliases
            if new_aliases:
                current_aliases.update(new_aliases)
                ent["aliases"] = sorted(current_aliases)
                for alias in new_aliases:
                    self._alias_index[alias.lower()] = slug

        # Upgrade authority (never downgrade)
        auth_rank = {"inferred": 0, "system": 1, "explicit": 2}
        if auth_rank.get(authority, 0) > auth_rank.get(ent.get("authority", "inferred"), 0):
            ent["authority"] = authority

        # Upgrade entity_type if more specific (THING -> specific type)
        current_type = resolve_entity_type(ent.get("entity_type", "thing"))
        if current_type == EntityType.THING and entity_type != EntityType.THING:
            ent["entity_type"] = entity_type.value

        # Track re-encounters separately from query access.
        # Entity dedup (re-adding same entity) should NOT bump last_accessed —
        # that defeats unaccessed decay. last_accessed is only set by
        # bump_access() which is called from actual query paths.
        ent["last_encountered"] = now
        self._dirty = True
        self.invalidate_embedding_cache(slug)
        return slug

    def get(self, slug: str) -> dict | None:
        """Get entity data by slug."""
        with self._lock:
            return self._entities.get(slug)

    def get_name(self, slug: str | None) -> str:
        """Get display name for a slug. Returns '?' if not found."""
        if not slug:
            return "?"
        with self._lock:
            ent = self._entities.get(slug)
            return ent["canonical_name"] if ent else slug

    def get_type(self, slug: str) -> EntityType:
        """Get the EntityType for a slug."""
        with self._lock:
            ent = self._entities.get(slug)
            if not ent:
                return EntityType.THING
            return resolve_entity_type(ent.get("entity_type", "thing"))

    def bump_access(self, slug: str) -> None:
        """Record that an entity was accessed (for relevance decay tracking)."""
        with self._lock:
            ent = self._entities.get(slug)
            if ent:
                ent["last_accessed"] = _now_iso()
                ent["access_count"] = ent.get("access_count", 0) + 1
                self._dirty = True

    def mark_verified(self, slug: str) -> None:
        """Record that an entity was epistemically verified (not just accessed).

        Verification events: user approval, authority upgrade, triple re-confirmation.
        This is distinct from bump_access which tracks reads.
        """
        with self._lock:
            ent = self._entities.get(slug)
            if ent:
                ent["last_verified"] = _now_iso()
                self._dirty = True

    def add_alias(self, slug: str, alias: str) -> bool:
        """Add an alias to an existing entity."""
        with self._lock:
            ent = self._entities.get(slug)
            if not ent:
                return False
            aliases = set(ent.get("aliases", []))
            if alias not in aliases:
                aliases.add(alias)
                ent["aliases"] = sorted(aliases)
                self._alias_index[alias.lower()] = slug
                self._dirty = True
            return True

    def restore(self, slug: str, entity_data: dict) -> bool:
        """Resurrect an entity at the given slug from a snapshot.

        Used by ``KnowledgeGraph.unmerge_entities`` to reverse a destructive
        merge. ``entity_data`` is typically the full dict captured from
        ``self.get(slug_remove)`` BEFORE ``merge()`` destroyed the row, so
        restoration is lossless on every field (canonical_name, aliases,
        authority, first_seen, access_count, status, decay_condition,
        last_verified, etc.).

        Returns True on success. Returns False (idempotent no-op) when
        the slug is already occupied by an entity with the same
        canonical_name — the caller can treat this as already-restored.
        Returns False when the slug is occupied by a DIFFERENT entity
        — the caller surfaces that conflict.
        """
        with self._lock:
            existing = self._entities.get(slug)
            canonical = (entity_data or {}).get("canonical_name", "")
            if not canonical:
                return False
            if existing:
                # Idempotent restore: same canonical name = treat as success
                return existing.get("canonical_name") == canonical

            ent = dict(entity_data)
            # Default any missing fields so the row is well-formed even when
            # the snapshot came from an older schema (forward compatibility).
            ent.setdefault("aliases", [])
            ent.setdefault("authority", "system")
            ent.setdefault("status", "active")
            ent.setdefault("first_seen", _now_iso())
            ent.setdefault("last_accessed", _now_iso())
            ent.setdefault("access_count", 0)

            self._entities[slug] = ent

            # Re-establish index entries
            self._name_index[canonical.lower()] = slug
            for alias in ent.get("aliases", []) or []:
                if isinstance(alias, str) and alias:
                    self._alias_index[alias.lower()] = slug

            self._dirty = True
            self.invalidate_embedding_cache(slug)
            log.info("Entity restored at slug='%s' (canonical='%s')", slug, canonical)
            return True

    def merge(self, slug_keep: str, slug_remove: str) -> bool:
        """Merge two entities. Keeps slug_keep, removes slug_remove.

        Aliases from removed entity are added to kept entity.
        Returns True if merge happened.
        """
        with self._lock:
            keep = self._entities.get(slug_keep)
            remove = self._entities.get(slug_remove)
            if not keep or not remove:
                return False

            # Merge aliases (include the removed entity's canonical name)
            keep_aliases = set(keep.get("aliases", []))
            keep_aliases.add(remove["canonical_name"])
            keep_aliases.update(remove.get("aliases", []))
            keep["aliases"] = sorted(keep_aliases)

            # Upgrade authority
            auth_rank = {"inferred": 0, "system": 1, "explicit": 2}
            if auth_rank.get(remove.get("authority", "inferred"), 0) > auth_rank.get(keep.get("authority", "inferred"), 0):
                keep["authority"] = remove["authority"]

            # Keep earliest first_seen
            if remove.get("first_seen", "z") < keep.get("first_seen", "z"):
                keep["first_seen"] = remove["first_seen"]

            # Sum access counts
            keep["access_count"] = keep.get("access_count", 0) + remove.get("access_count", 0)

            # Remove the merged entity
            del self._entities[slug_remove]

            # Rebuild indexes
            self._rebuild_indexes()
            self._dirty = True

            log.info("Merged entity '%s' into '%s'", slug_remove, slug_keep)
            return True

    def get_slug_redirect(self, old_slug: str) -> str | None:
        """Check if a slug was merged into another entity.

        After merge, the old slug's canonical name becomes an alias of the kept entity.
        This allows callers to find the new slug for a merged entity.
        """
        with self._lock:
            # Check alias index — merged entity's name is stored as alias
            for alias_lower, slug in self._alias_index.items():
                if _slugify(alias_lower) == old_slug:
                    return slug
            return None

    def upgrade_authority(self, slug: str, new_authority: str) -> bool:
        """Upgrade authority for an entity (never downgrades)."""
        with self._lock:
            ent = self._entities.get(slug)
            if not ent:
                return False
            auth_rank = {"inferred": 0, "system": 1, "explicit": 2}
            if auth_rank.get(new_authority, 0) > auth_rank.get(ent.get("authority", "inferred"), 0):
                ent["authority"] = new_authority
                self._dirty = True
                return True
            return False

    # ── Decay ──

    def mark_decayed(self, slug: str) -> None:
        """Mark an entity as decayed."""
        with self._lock:
            ent = self._entities.get(slug)
            if ent and ent.get("status") != "decayed":
                ent["status"] = "decayed"
                ent["decayed_at"] = _now_iso()
                self._dirty = True

    # ── Search ──

    def search(self, query: str, limit: int = 20) -> list[dict]:
        """Search entities by name/alias. Returns list of matches."""
        query_lower = query.lower()
        results = []

        with self._lock:
            for slug, ent in self._entities.items():
                if ent.get("status") == "decayed":
                    continue
                name = ent["canonical_name"]
                match = query_lower in name.lower()
                if not match:
                    match = any(query_lower in a.lower() for a in ent.get("aliases", []))
                if match:
                    results.append({
                        "slug": slug,
                        "name": name,
                        "entity_type": ent.get("entity_type", "thing"),
                        "authority": ent.get("authority", "inferred"),
                        "aliases": ent.get("aliases", []),
                        "access_count": ent.get("access_count", 0),
                    })

        _auth_rank = {"explicit": 2, "system": 1, "inferred": 0}
        results.sort(key=lambda x: (
            _auth_rank.get(x.get("authority", "inferred"), 0),
            x.get("access_count", 0),
        ), reverse=True)
        return results[:limit]

    def list_all(self, include_decayed: bool = False) -> list[dict]:
        """List all entities."""
        results = []
        with self._lock:
            for slug, ent in self._entities.items():
                if not include_decayed and ent.get("status") == "decayed":
                    continue
                results.append({"slug": slug, **ent})
        return results

    # ── Stats ──

    def stats(self) -> dict:
        """Entity statistics."""
        with self._lock:
            active = [e for e in self._entities.values() if e.get("status", "active") == "active"]
            decayed = [e for e in self._entities.values() if e.get("status") == "decayed"]
            total = len(self._entities)

        type_counts: dict[str, int] = {}
        for ent in active:
            etype = ent.get("entity_type", "thing")
            type_counts[etype] = type_counts.get(etype, 0) + 1

        authority_counts: dict[str, int] = {}
        for ent in active:
            auth = ent.get("authority", "inferred")
            authority_counts[auth] = authority_counts.get(auth, 0) + 1

        return {
            "total": total,
            "active": len(active),
            "decayed": len(decayed),
            "by_type": type_counts,
            "by_authority": authority_counts,
        }

    def export_snapshot_reader(self) -> RegistrySnapshotReader:
        """Return a :class:`RegistrySnapshotReader` built from the current
        in-memory indexes.

        Sprint γ.3 Phase 2 (2026-05-15). Avoids a disk round-trip when
        the main process wants to hand a worker an immutable snapshot
        directly (e.g. via :mod:`multiprocessing`'s shared-state
        primitives or pickle-over-pipe). The reader holds defensive
        copies of the indexes, so subsequent mutations on this registry
        do not affect the reader.

        Returns a valid reader even when the registry is empty (0
        entities, 0 names, 0 aliases) — workers can construct a noop
        resolver from a fresh boot.
        """
        with self._lock:
            entity_count = len(self._entities)
            name_index = dict(self._name_index)
            alias_index = dict(self._alias_index)
        return RegistrySnapshotReader(
            name_index=name_index,
            alias_index=alias_index,
            entity_count=entity_count,
            schema_version=_ENTITY_INDEXES_SCHEMA_VERSION,
            saved_at=_now_iso(),
        )

    @property
    def entities(self) -> dict[str, dict[str, Any]]:
        """Snapshot view of entity data (for graph building).

        Returns a SHALLOW COPY of the outer dict so callers (graph.build,
        KBService, query_entity, etc.) can iterate .items() safely even
        while other threads are adding/merging entities. Inner per-entity
        dicts remain shared references — existing read-only access patterns
        (``registry.entities[slug].get("entity_type")``) still work; callers
        that mutate would need to go through registry methods anyway.
        """
        with self._lock:
            return dict(self._entities)

    @property
    def dirty(self) -> bool:
        with self._lock:
            return self._dirty

    @dirty.setter
    def dirty(self, value: bool) -> None:
        with self._lock:
            self._dirty = value
