"""Narrative mention scanner — Phase 1 of the second-brain integration push.

The scanner walks any narrative content (journal entries, EOD reports, daily
memory files, goal pursuit logs, decision rationales, chat messages, channel
messages) for references to known entities. For every match it emits a
``(source_path, references, entity_slug)`` triple with snippet context. The
triples surface as a "Mentioned in" panel on every wiki entity page.

Architectural rules this module honors:

- **Pure scanner**. ``scan_mentions()`` is a deterministic function with no
  side-effects. It takes text + registry + config and returns a sorted list
  of :class:`Mention` records. Easy to test in isolation.
- **Skill-driven strategy**. Every threshold, every snippet size, every
  ignore-list item lives in the ``_meta/mention-scan`` skill YAML. Engine
  reads it at scan time. Tuning never requires Python edits (Rule 12).
- **Channel-agnostic**. ``context_type`` is an opaque string; the scanner
  doesn't care what label callers pass. New channels add a one-line call.
- **Predicate is `references`, NOT `mentions`**. The ontology comment at
  ``defaults/skills/_meta/ontology/config/ontology.yaml:303-308`` warns
  that ``mentions`` is reserved for the wikilink co-occurrence graph
  (filtered as noise by default in the graph UI). Using it would make
  every emitted triple silently invisible.

The scanner runs three independent passes over the input text and dedupes
by ``(source_path, entity_slug)``:

1. **Wikilink pass** — explicit ``[[Name]]`` references. Highest precision.
2. **Title-Case pass** — ``extract_entity_candidates()`` from
   ``agntspace.text.candidates`` finds multi-word Title-Case runs; the
   registry then resolves them to slugs.
3. **Alias-substring pass** — for high-confidence multi-word aliases the
   user has explicitly registered, we scan for the literal alias as a
   word-bounded substring. Catches ``"Coffee with sarah today"`` when
   ``"sarah"`` is a registered alias of the canonical ``Sarah Chen``.

Single-word names from prose are intentionally NOT matched (``"Today"`` is
not an entity). Single-word entities only match if explicitly bracketed or
registered as an alias (configurable via ``require_multiword_for_title_case``).
"""

from __future__ import annotations

import asyncio
import logging
import re
import threading
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import UTC, datetime

from agntspace.text.candidates import extract_entity_candidates

log = logging.getLogger(__name__)

# Wikilink pattern — matches ``[[Display Name]]`` and ``[[slug|Display]]``.
# We extract the display half (after ``|`` if present) so the registry
# can resolve through canonical-name and alias indexes.
_WIKILINK_RE = re.compile(r"\[\[([^\]\[|]+)(?:\|([^\]\[]+))?\]\]")


# Word-boundary pattern for alias-substring scanning. ``\b`` works fine
# in Python's re module for ASCII; for non-ASCII aliases the boundary is
# computed manually below to handle Cyrillic/Greek/CJK correctly.
_WORD_CHAR_RE = re.compile(r"\w", re.UNICODE)


@dataclass(frozen=True)
class Mention:
    """A single detected reference of an entity in narrative content.

    Frozen + hashable so the dedup pass can use a set.
    """

    entity_slug: str
    matched_text: str  # the exact span that matched
    snippet: str  # context window around the match (skill-configured size)
    offset: int  # character offset in the source text
    context_type: str  # opaque label from caller
    source_path: str  # vault path or synthetic identifier
    pass_name: str  # which detection pass produced this ("wikilink"/"title_case"/"alias")


# ─────────────────────────────────────────────────────────────────────
# Default config — used when the skill YAML is missing or malformed.
# Pre-Phase-2 behaviour is preserved by ``enabled = True``: a vault that
# has never seen the skill still gets sane defaults. Tagged as
# ``arch:deterministic`` because the engine MUST function when the
# strategy substrate is absent (skill loader unavailable, file deleted).
# ─────────────────────────────────────────────────────────────────────
_FALLBACK_CONFIG: dict = {  # arch:deterministic — engine must boot without the skill
    "enabled": True,
    "snippet_chars_before": 80,
    "snippet_chars_after": 80,
    "min_match_length": 2,
    "max_mentions_per_source": 200,
    "ignore_segments": [".history/", ".archives/", ".quarantine/", ".trash/"],
    "context_types": [
        "journal_user",
        "journal_agent",
        "eod_report",
        "morning_briefing",
        "daily_memory",
        "goal_pursuit_log",
        "decision",
        "chat",
        "email",
    ],
    "predicate": "references",
    "confidence": 0.7,
    "knowledge_type": "episodic",
    "decay_condition": "when:unaccessed:90d",
    "authority": "system",
    "epistemic_status": "believed",
    "require_multiword_for_title_case": True,
    # P2.5 (2026-05-11 night-5g) — batched-mention debounce window.
    # When > 0, BatchedMentionIndexer queues writes per source_path and
    # flushes them as ONE scan after this many seconds of quiet. Set to 0
    # to disable batching (every index() call scans immediately, legacy
    # behavior). 5s default catches typical journal-append bursts during
    # active user sessions while keeping the scan-result latency tight
    # enough that the dashboard graph view sees mentions promptly.
    "debounce_seconds": 5.0,
}


def resolve_scan_config(skill_loader=None) -> dict:
    """Read the ``_meta/mention-scan`` skill YAML and merge with fallback.

    Missing skill loader / missing YAML / malformed YAML → fallback. We
    never crash the scanner because the strategy substrate is absent.
    Caller-supplied keys override fallback keys; lists are replaced
    wholesale (not merged) so a user override truly wins.
    """
    cfg = dict(_FALLBACK_CONFIG)
    if skill_loader is None:
        return cfg
    try:
        # The skill stores config in config/scan.yaml — load via the
        # SkillLoader's config-file API, not the frontmatter API.
        loaded = skill_loader.load_skill_config_file("mention-scan", "scan.yaml")
    except Exception:  # noqa: BLE001
        log.debug("mention-scan skill config not available; using fallback", exc_info=True)
        return cfg
    if not isinstance(loaded, dict):
        return cfg
    for key, value in loaded.items():
        cfg[key] = value
    return cfg


def _is_ignored_path(source_path: str, ignore_segments: Iterable[str]) -> bool:
    """Return True if any configured ignore-segment substring is in the path."""
    if not source_path:
        return False
    return any(seg and seg in source_path for seg in ignore_segments)


def _build_snippet(text: str, start: int, end: int, before: int, after: int) -> str:
    """Return a single-line snippet of length ``before+match+after`` chars,
    centered on the match. Newlines are collapsed to spaces so the snippet
    renders cleanly in a UI panel."""
    snippet_start = max(0, start - before)
    snippet_end = min(len(text), end + after)
    raw = text[snippet_start:snippet_end]
    return " ".join(raw.split())


def _ascii_word_bounded_at(text: str, start: int, end: int) -> bool:
    """Return True if ``text[start:end]`` has word boundaries on both sides
    even when the surrounding characters are non-ASCII. ``\\b`` in Python's
    re module is Unicode-aware for ``\\w`` so this is mostly equivalent to
    using ``\\b`` directly, but we compute it explicitly to keep the
    alias-scan loop clear and to handle the start-of-text and end-of-text
    edge cases without separate branches."""
    if start > 0:
        prev = text[start - 1]
        if _WORD_CHAR_RE.match(prev):
            return False
    if end < len(text):
        nxt = text[end]
        if _WORD_CHAR_RE.match(nxt):
            return False
    return True


def _scan_wikilinks(
    text: str,
    registry,
    *,
    config: dict,
    source_path: str,
    context_type: str,
) -> list[Mention]:
    """Extract ``[[Name]]`` references and resolve through the registry."""
    out: list[Mention] = []
    for match in _WIKILINK_RE.finditer(text):
        # If the wikilink has a pipe (``[[slug|display]]``), the slug is
        # what the user meant; otherwise the display text resolves through
        # the canonical-name + alias indexes.
        slug_or_display = match.group(1).strip()
        if not slug_or_display:
            continue
        try:
            entity_slug = registry.resolve(slug_or_display)
        except Exception:  # noqa: BLE001
            log.debug("registry.resolve raised on '%s'", slug_or_display, exc_info=True)
            continue
        if not entity_slug:
            continue
        if len(slug_or_display) < config["min_match_length"]:
            continue
        snippet = _build_snippet(
            text,
            match.start(),
            match.end(),
            config["snippet_chars_before"],
            config["snippet_chars_after"],
        )
        out.append(
            Mention(
                entity_slug=entity_slug,
                matched_text=slug_or_display,
                snippet=snippet,
                offset=match.start(),
                context_type=context_type,
                source_path=source_path,
                pass_name="wikilink",
            )
        )
    return out


def _scan_title_case(
    text: str,
    registry,
    *,
    config: dict,
    source_path: str,
    context_type: str,
) -> list[Mention]:
    """Walk Title-Case multi-word runs via the existing extractor and
    resolve each through the registry."""
    candidates = extract_entity_candidates(text)
    if not candidates:
        return []
    out: list[Mention] = []
    # We need offsets, so for each candidate we re-scan the text for its
    # first occurrence. This is O(n*k) but k (candidates per source) is
    # small (typically <30) and n is the source length. Plenty fast.
    for candidate in candidates:
        if len(candidate) < config["min_match_length"]:
            continue
        try:
            entity_slug = registry.resolve(candidate)
        except Exception:  # noqa: BLE001
            log.debug("registry.resolve raised on '%s'", candidate, exc_info=True)
            continue
        if not entity_slug:
            continue
        # Find every occurrence — same entity mentioned three times in a
        # journal entry is three pieces of evidence, but we cap to one
        # mention record per (source, entity) pair via the dedup later.
        # We still want to find the FIRST occurrence's offset for the
        # snippet.
        idx = text.find(candidate)
        if idx < 0:
            continue
        snippet = _build_snippet(
            text,
            idx,
            idx + len(candidate),
            config["snippet_chars_before"],
            config["snippet_chars_after"],
        )
        out.append(
            Mention(
                entity_slug=entity_slug,
                matched_text=candidate,
                snippet=snippet,
                offset=idx,
                context_type=context_type,
                source_path=source_path,
                pass_name="title_case",
            )
        )
    return out


def _scan_aliases(
    text: str,
    registry,
    *,
    config: dict,
    source_path: str,
    context_type: str,
) -> list[Mention]:
    """For every registered alias of every entity in the registry, scan
    the text for the literal alias as a word-bounded substring. Only
    multi-word aliases are checked unless ``require_multiword_for_title_case``
    is False — single-word aliases like ``"sarah"`` would generate too many
    false positives without explicit user opt-in via that flag."""
    require_multiword = config.get("require_multiword_for_title_case", True)
    text_lower = text.lower()
    out: list[Mention] = []

    aliases = _enumerate_aliases(registry)
    for alias, entity_slug in aliases:
        if len(alias) < config["min_match_length"]:
            continue
        if require_multiword and " " not in alias:
            continue
        alias_lower = alias.lower()
        # Find the first occurrence; finditer with re.escape handles
        # special characters in the alias gracefully.
        for match in re.finditer(re.escape(alias_lower), text_lower):
            start, end = match.start(), match.end()
            if not _ascii_word_bounded_at(text, start, end):
                continue
            snippet = _build_snippet(
                text,
                start,
                end,
                config["snippet_chars_before"],
                config["snippet_chars_after"],
            )
            out.append(
                Mention(
                    entity_slug=entity_slug,
                    matched_text=text[start:end],  # original case from source
                    snippet=snippet,
                    offset=start,
                    context_type=context_type,
                    source_path=source_path,
                    pass_name="alias",
                )
            )
            break  # one alias-pass mention per (alias, source) is enough
    return out


def _enumerate_aliases(registry) -> list[tuple[str, str]]:
    """Yield ``(alias, entity_slug)`` pairs from the registry. Returns []
    on any unexpected internal shape — we don't want a registry change
    to silently break the scanner."""
    out: list[tuple[str, str]] = []
    try:
        # EntityRegistry exposes ``_alias_index: dict[str, str]`` mapping
        # lowercase alias → slug. Snapshot under the lock to avoid mid-
        # iteration mutation from the graph-build thread.
        if hasattr(registry, "_alias_index") and hasattr(registry, "_lock"):
            with registry._lock:
                snapshot = list(registry._alias_index.items())
            for alias_lower, slug in snapshot:
                if not alias_lower or not slug:
                    continue
                out.append((alias_lower, slug))
    except Exception:  # noqa: BLE001
        log.debug("alias enumeration failed", exc_info=True)
    return out


def _dedup_mentions(mentions: list[Mention], cap: int) -> list[Mention]:
    """Dedup by ``(entity_slug, source_path)`` keeping the lowest offset
    (earliest mention wins). Cap the result to ``max_mentions_per_source``."""
    if not mentions:
        return []
    by_key: dict[tuple[str, str], Mention] = {}
    for mention in mentions:
        key = (mention.entity_slug, mention.source_path)
        existing = by_key.get(key)
        if existing is None or mention.offset < existing.offset:
            by_key[key] = mention
    deduped = sorted(by_key.values(), key=lambda m: m.offset)
    if cap > 0:
        deduped = deduped[:cap]
    return deduped


def scan_mentions(
    text: str,
    registry,
    *,
    source_path: str,
    context_type: str,
    config: dict | None = None,
) -> list[Mention]:
    """Scan ``text`` for references to entities in the registry.

    Pure function. Returns a deterministic, dedup'd, offset-sorted list
    of :class:`Mention` records. Returns ``[]`` on:

    - Empty / very short text
    - Disabled config (``enabled: false``)
    - Path matching any configured ignore segment
    - No entities in the registry

    Never raises. Every failure mode is converted to a debug log + ``[]``
    return so a broken scanner never breaks the writer that called it.
    """
    if not text or len(text) < 4:
        return []
    cfg = config if config is not None else dict(_FALLBACK_CONFIG)
    if not cfg.get("enabled", True):
        return []
    if _is_ignored_path(source_path, cfg.get("ignore_segments", [])):
        return []
    if registry is None:
        return []

    try:
        wikilink_hits = _scan_wikilinks(
            text, registry, config=cfg, source_path=source_path, context_type=context_type
        )
        title_case_hits = _scan_title_case(
            text, registry, config=cfg, source_path=source_path, context_type=context_type
        )
        alias_hits = _scan_aliases(
            text, registry, config=cfg, source_path=source_path, context_type=context_type
        )
    except Exception:  # noqa: BLE001
        log.exception("mention scan failed for %s", source_path)
        return []

    all_hits = wikilink_hits + title_case_hits + alias_hits
    return _dedup_mentions(all_hits, cfg.get("max_mentions_per_source", 200))


# ─────────────────────────────────────────────────────────────────────
# Indexer — wraps the pure scanner with graph persistence.
# ─────────────────────────────────────────────────────────────────────
def _now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class MentionIndexer:
    """Wraps :func:`scan_mentions` with graph persistence + activity events.

    Construction is lazy — the indexer accepts the graph + skill loader +
    optional activity logger at init, then ``index()`` is called from each
    narrative writer's hook point. A None graph is treated as ``disabled``;
    legacy boot paths that don't wire the graph see a no-op indexer.

    Triples are emitted with::

        (source_path, references, entity_slug)
        authority="system"
        epistemic_status="believed"
        confidence=<from skill YAML>
        knowledge_type="episodic"
        situational_context={
            snippet, context_type, matched_text, offset, when, pass_name
        }

    Source path is stored as the triple subject. Subjects are resolved
    through the entity registry like any other triple, so the source
    document gets registered as a ``document`` entity automatically.
    """

    def __init__(
        self,
        graph,
        *,
        skill_loader=None,
        activity_logger=None,
    ) -> None:
        self._graph = graph
        self._skill_loader = skill_loader
        self._activity_logger = activity_logger

    def index(
        self,
        text: str,
        *,
        source_path: str,
        context_type: str,
        when: str | None = None,
    ) -> dict:
        """Scan ``text`` and persist mentions as triples.

        Returns a counts dict ``{scanned, recorded, skipped_existing,
        ignored, disabled, skipped_reason?}`` so the caller (or tests)
        can inspect what happened. Never raises — every internal failure
        becomes a debug log entry and the caller continues.
        """
        if self._graph is None:
            return {"scanned": 0, "recorded": 0, "skipped_existing": 0, "ignored": 0, "disabled": True}

        # Hermes-inspired skip_memory gate (2026-05-16 night). Cron
        # handlers registered with ``skip_memory=True`` set the
        # ``_skip_memory_var`` contextvar before running their handler;
        # we read it here at the outermost entry so the entire mention
        # pipeline is bypassed for that tick. Cheap import + lookup;
        # legacy callers (no contextvar set) see False and proceed.
        try:
            from agntspace.activity.decisions import current_skip_memory

            if current_skip_memory():
                if self._activity_logger is not None:
                    try:
                        self._activity_logger.log(
                            category="memory",
                            action="mention_indexer_skipped",
                            summary=f"Skipped {context_type} mentions ({len(text)} chars)",
                            importance="low",
                            details={
                                "reason": "skip_memory_contextvar",
                                "source_path": source_path,
                                "context_type": context_type,
                                "text_length": len(text),
                            },
                        )
                    except Exception:
                        log.debug("MentionIndexer: activity logger failed during skip_memory log", exc_info=True)
                return {
                    "scanned": 0,
                    "recorded": 0,
                    "skipped_existing": 0,
                    "ignored": 0,
                    "disabled": False,
                    "skipped_reason": "skip_memory_contextvar",
                }
        except ImportError:
            # decisions module unavailable (test fixtures, minimal installs)
            # — proceed with legacy behavior.
            pass

        config = resolve_scan_config(self._skill_loader)
        if not config.get("enabled", True):
            return {"scanned": 0, "recorded": 0, "skipped_existing": 0, "ignored": 0, "disabled": True}

        registry = getattr(self._graph, "registry", None) or getattr(self._graph, "_registry", None)
        if registry is None:
            log.debug("MentionIndexer: graph has no registry, skipping")
            return {"scanned": 0, "recorded": 0, "skipped_existing": 0, "ignored": 0, "disabled": False}

        mentions = scan_mentions(
            text,
            registry,
            source_path=source_path,
            context_type=context_type,
            config=config,
        )
        if not mentions:
            return {"scanned": 0, "recorded": 0, "skipped_existing": 0, "ignored": 0, "disabled": False}

        when_iso = when or _now_iso()
        recorded = 0
        skipped_existing = 0
        predicate = config.get("predicate", "references")
        confidence = float(config.get("confidence", 0.7))
        knowledge_type = config.get("knowledge_type", "episodic")
        decay_condition = config.get("decay_condition", "when:unaccessed:90d")
        authority = config.get("authority", "system")
        epistemic_status = config.get("epistemic_status", "believed")

        for mention in mentions:
            try:
                triple_id = self._graph.add_triple(
                    subject=mention.source_path,
                    predicate=predicate,
                    obj=mention.entity_slug,
                    authority=authority,
                    source_file=mention.source_path,
                    source_date=when_iso,
                    confidence=confidence,
                    decay_condition=decay_condition,
                    subject_type="document",
                    object_type="concept",
                    epistemic_status=epistemic_status,
                    knowledge_type=knowledge_type,
                    valid_from=when_iso,
                    situational_context={
                        "snippet": mention.snippet,
                        "context_type": mention.context_type,
                        "matched_text": mention.matched_text,
                        "offset": mention.offset,
                        "when": when_iso,
                        "pass_name": mention.pass_name,
                    },
                )
            except Exception:  # noqa: BLE001
                log.debug(
                    "MentionIndexer: add_triple raised for %s -> %s",
                    mention.source_path,
                    mention.entity_slug,
                    exc_info=True,
                )
                continue
            if triple_id and triple_id > 0:
                recorded += 1
            else:
                skipped_existing += 1

        # Persist the graph if any new triple was added. The graph holds
        # an in-memory dirty flag; save() is idempotent and uses
        # `trust_reason="graph_persist"` internally for the VaultWriter
        # runtime guard, so we don't need to pass it here.
        if recorded > 0:
            try:
                self._graph.save()
            except Exception:  # noqa: BLE001
                log.debug("graph.save() failed after mention index", exc_info=True)

        if self._activity_logger and recorded > 0:
            try:
                self._activity_logger.log(
                    category="knowledge",
                    action="mentions_indexed",
                    summary=f"Indexed {recorded} mention{'s' if recorded != 1 else ''} from {source_path}",
                    importance="low",
                    details={
                        "source_path": source_path,
                        "context_type": context_type,
                        "scanned": len(mentions),
                        "recorded": recorded,
                        "skipped_existing": skipped_existing,
                    },
                )
            except Exception:  # noqa: BLE001
                log.debug("activity_logger.log failed for mentions_indexed", exc_info=True)

        return {
            "scanned": len(mentions),
            "recorded": recorded,
            "skipped_existing": skipped_existing,
            "ignored": 0,
            "disabled": False,
            "batched": False,
        }


# ─── P2.5 — BatchedMentionIndexer ─────────────────────────────────────


@dataclass
class _PendingBatch:
    """One queued batch keyed on source_path.

    ``segments`` holds (text, context_type, when_iso) tuples in arrival
    order. ``flush_task`` is the asyncio task that fires the scan after
    the debounce window. Reset on every new write to the same source.
    """

    segments: list[tuple[str, str, str | None]] = field(default_factory=list)
    flush_task: asyncio.Task | None = None


class BatchedMentionIndexer:
    """Debounced wrapper around :class:`MentionIndexer`.

    Five narrative writes to the same file in 30 seconds = 5 scanner
    passes under the legacy indexer. This wrapper queues writes per
    ``source_path`` for ``debounce_seconds`` of quiet, then flushes the
    concatenated text as ONE scan. Mentions from EVERY queued segment
    are preserved — we don't drop "earlier" writes the way naive
    last-write coalescing would.

    Architecture:
    - Each ``index()`` call queues the new segment onto
      ``self._pending[source_path].segments`` (thread-safe via ``_lock``).
    - If an asyncio event loop is running on the calling thread, schedule
      (or reset) a debounced flush task via ``asyncio.create_task``. The
      task sleeps ``debounce_seconds`` then calls ``flush(source_path)``.
    - If NO event loop is running (e.g. sync test fixtures, threadpool
      callers), fall back to immediate scan: passthrough to the wrapped
      indexer with NO queueing. Legacy behavior is byte-identical in
      that case.
    - ``flush(source_path=None)``: synchronous flush. ``None`` flushes
      every queue. Idempotent on empty queues.
    - ``debounce_seconds == 0``: feature disabled, every call is
      passthrough — legacy behavior.

    Fail-soft contract: every internal failure becomes a debug log;
    the caller's index() returns a counts dict either way, the
    narrative-write path is never broken by indexer issues.
    """

    def __init__(
        self,
        underlying: MentionIndexer,
        *,
        debounce_seconds: float = 5.0,
        skill_loader=None,
    ) -> None:
        self._underlying = underlying
        # Allow per-instance override of the debounce window. Constructor
        # default = legacy non-batched behavior threshold; production
        # wiring threads the skill YAML value in.
        self._debounce_seconds = float(debounce_seconds)
        self._skill_loader = skill_loader
        self._pending: dict[str, _PendingBatch] = {}
        self._lock = threading.Lock()

    @property
    def debounce_seconds(self) -> float:
        return self._debounce_seconds

    def index(
        self,
        text: str,
        *,
        source_path: str,
        context_type: str,
        when: str | None = None,
        force: bool = False,
    ) -> dict:
        """Queue a mention-scan for this ``source_path``.

        Returns:
            - ``force=True`` OR no event loop OR ``debounce_seconds<=0``:
              passes through to the wrapped indexer's full result dict.
            - Otherwise: ``{queued: True, source_path, segments_queued,
              debounce_seconds, batched: True}`` indicating the write
              landed in the queue, no scan ran yet.
        """
        if force or self._debounce_seconds <= 0:
            return self._underlying.index(
                text, source_path=source_path,
                context_type=context_type, when=when,
            )

        # If no event loop is running we can't schedule the debounce
        # task — fall back to immediate passthrough so sync callers
        # (tests, threadpool work) keep working.
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return self._underlying.index(
                text, source_path=source_path,
                context_type=context_type, when=when,
            )

        with self._lock:
            pending = self._pending.get(source_path)
            if pending is None:
                pending = _PendingBatch()
                self._pending[source_path] = pending
            pending.segments.append((text, context_type, when))
            # Cancel any in-flight flush task — we want to reset the
            # debounce window now that a new write arrived.
            prior_task = pending.flush_task
            pending.flush_task = loop.create_task(
                self._debounced_flush(source_path),
            )
            segments_queued = len(pending.segments)

        if prior_task is not None and not prior_task.done():
            prior_task.cancel()

        return {
            "queued": True,
            "source_path": source_path,
            "segments_queued": segments_queued,
            "debounce_seconds": self._debounce_seconds,
            "batched": True,
        }

    async def _debounced_flush(self, source_path: str) -> None:
        """Wait the debounce window, then flush ``source_path``.

        Cancelled cleanly when a new write replaces this task. The
        flush itself runs even on cancellation IF the cancellation
        happens after the sleep returns — but ``_pop_segments`` is
        idempotent so a concurrent ``flush()`` call wins races safely.
        """
        try:
            await asyncio.sleep(self._debounce_seconds)
        except asyncio.CancelledError:
            return
        try:
            self.flush(source_path)
        except Exception:  # noqa: BLE001
            log.debug(
                "BatchedMentionIndexer: debounced flush failed for %s",
                source_path, exc_info=True,
            )

    def flush(self, source_path: str | None = None) -> dict:
        """Drain queued segments and scan via the underlying indexer.

        ``source_path=None`` flushes every queue. Otherwise flushes
        only the named queue. Returns a counts dict aggregating results
        across whatever was flushed.

        Idempotent: flushing an empty queue is a no-op returning
        zero counts. Safe to call from sync and async contexts.
        """
        targets: list[str]
        if source_path is not None:
            targets = [source_path]
        else:
            with self._lock:
                targets = list(self._pending.keys())

        aggregate: dict[str, int | bool] = {
            "scanned": 0, "recorded": 0, "skipped_existing": 0,
            "ignored": 0, "disabled": False, "batched": True,
            "sources_flushed": 0,
        }

        for path in targets:
            segments, ctx_type, when_first = self._pop_segments(path)
            if not segments:
                continue
            aggregate["sources_flushed"] = int(aggregate["sources_flushed"]) + 1
            # Concatenate all queued text with a blank line between
            # segments so the scanner's offset tracking + snippet
            # extraction work cleanly.
            combined = "\n\n".join(segments)
            try:
                result = self._underlying.index(
                    combined, source_path=path,
                    context_type=ctx_type, when=when_first,
                )
            except Exception:  # noqa: BLE001
                log.debug(
                    "BatchedMentionIndexer: underlying flush failed for %s",
                    path, exc_info=True,
                )
                continue
            for k in ("scanned", "recorded", "skipped_existing", "ignored"):
                aggregate[k] = int(aggregate[k]) + int(result.get(k, 0))
            if result.get("disabled"):
                aggregate["disabled"] = True

        return aggregate

    def _pop_segments(
        self, source_path: str,
    ) -> tuple[list[str], str, str | None]:
        """Pop every queued segment for ``source_path``.

        Returns (texts, context_type, when) where context_type is the
        FIRST queued segment's context (queues are keyed per source so
        the context is stable in practice — segments to the same path
        almost always carry the same context_type). ``when`` is the
        FIRST queued segment's timestamp; later writes inherit it so
        the scanner's per-mention metadata reflects when the batch
        STARTED rather than when it flushed.
        """
        with self._lock:
            pending = self._pending.pop(source_path, None)
            if pending and pending.flush_task is not None:
                pending.flush_task = None
        if pending is None or not pending.segments:
            return [], "", None
        texts = [seg[0] for seg in pending.segments]
        ctx = pending.segments[0][1]
        when = pending.segments[0][2]
        return texts, ctx, when

    def pending_count(self, source_path: str | None = None) -> int:
        """Diagnostic: how many segments are queued?

        ``source_path=None``: total across every queue. Useful for
        tests + observability surfaces (e.g. dashboard "N writes
        pending" indicator on the mention-scan health view).
        """
        with self._lock:
            if source_path is not None:
                p = self._pending.get(source_path)
                return len(p.segments) if p else 0
            return sum(len(p.segments) for p in self._pending.values())
