"""Read markdown files from the vault with YAML frontmatter parsing."""

from __future__ import annotations

import os
import threading
import time
from collections.abc import Iterator
from dataclasses import dataclass, field
from pathlib import Path

import frontmatter

from agntspace.vault.paths import VaultPaths


@dataclass
class VaultDocument:
    """A parsed markdown file from the vault."""

    path: Path
    metadata: dict = field(default_factory=dict)
    content: str = ""
    raw: str = ""


_IDENTITY_FILES = ("SOUL.md", "USER.md", "PROFILE.md", "CONTRACT.md", "TRUST.md", "RELATIONSHIP.md")  # arch:deterministic — structural list of the six identity files the reader hot-watches; vault layout invariant

# 2026-05-12 perf — short-lived glob cache.
# ``list_files(pattern="**/*.md")`` on Wolf's 1700-article Windows
# vault takes 40+ seconds (antivirus scan + ACL checks per file). Both
# ``knowledge_graph.build()`` AND ``vault_search.index_vault()`` glob
# at boot — costing 80+ seconds total of duplicate work. Cache the
# result with a short TTL so all consumers share a single walk; cache
# auto-invalidates after the TTL so structural changes are picked up
# on the next request. ``invalidate_list_cache()`` exists for explicit
# busts after known mass-mutations.
_DEFAULT_LIST_CACHE_TTL_SECONDS: float = 5.0  # arch:deterministic — share-the-glob window; covers boot-time consumer fan-out, expires fast enough that structural changes propagate within a tick


def _parse_simple_glob_pattern(pattern: str) -> tuple[bool, str | None]:
    """Parse a simple glob into ``(recursive, ext)`` or ``(False, None)``.

    Supports:
      - ``"**/*.md"`` → ``(True, ".md")``
      - ``"*.md"`` → ``(False, ".md")``
      - ``"**/*.txt"`` → ``(True, ".txt")``

    Returns ``(False, None)`` for anything more complex — callers should
    fall back to the legacy ``Path.glob`` path. Deliberately narrow:
    these are the patterns the hot graph/search/embeddings callers use;
    anything else is rare and not worth fast-pathing.
    """
    if not pattern:
        return (False, None)
    if pattern.startswith("**/*.") and "/" not in pattern[4:] and "*" not in pattern[5:]:
        return (True, pattern[len("**/*"):])  # ".md"
    if pattern.startswith("*.") and "/" not in pattern and "*" not in pattern[2:]:
        return (False, pattern[1:])  # ".md"
    return (False, None)


def _iter_files_with_stat(
    root: Path,
    recursive: bool,
    ext: str,
    skip_dirs: frozenset[str],
) -> Iterator[tuple[Path, int, int]]:
    """Walk ``root`` via ``os.scandir()`` yielding ``(path, mtime_ns, size)``.

    Honors ``skip_dirs`` (prunes traversal — never descends into them).
    Suffix match is case-sensitive to mirror the rglob convention on the
    Linux/macOS side; Windows is case-insensitive at the filesystem layer
    so callers see consistent behavior across platforms.

    Stat failures (file vanished between scandir and yield) are silently
    dropped — same contract as the existing ``_filter_archived`` +
    ``Path.stat()`` flow in graph.py.
    """
    try:
        scanner = os.scandir(root)
    except OSError:
        return
    with scanner:
        for entry in scanner:
            try:
                name = entry.name
                if entry.is_dir(follow_symlinks=False):
                    if name in skip_dirs:
                        continue
                    if recursive:
                        yield from _iter_files_with_stat(
                            Path(entry.path), recursive, ext, skip_dirs,
                        )
                elif entry.is_file(follow_symlinks=False):
                    if not name.endswith(ext):
                        continue
                    try:
                        st = entry.stat()
                    except OSError:
                        continue
                    yield (Path(entry.path), st.st_mtime_ns, st.st_size)
            except OSError:
                # Race: entry's type changed between scandir + check.
                # Silent drop matches prior behavior.
                continue


class VaultReader:
    """Reads markdown files from the vault directory."""

    def __init__(self, vault_dir: Path, *, paths: VaultPaths | None = None) -> None:
        self._vault_dir = vault_dir
        self._paths = paths
        # 2026-05-12 perf: per-(directory, pattern) TTL cache for the
        # whole-vault glob. Threading.Lock ensures concurrent boot-time
        # consumers don't all kick off the same 40-second walk. Lock is
        # held only for the cache lookup / save — the actual glob runs
        # outside the lock so a slow walk doesn't block other reads.
        # Key: (directory, pattern). Value: (cached_at_monotonic, dir_mtime, paths).
        # dir_mtime makes new-file creates / deletes / renames invalidate
        # automatically (parent dir mtime changes on those — verified on
        # Windows, macOS, Linux). Content edits to existing files don't
        # invalidate, which is correct: list_files returns paths only.
        self._list_cache: dict[tuple[str, str], tuple[float, float, list[Path]]] = {}
        self._list_cache_lock = threading.Lock()
        # Default TTL=0 = cache DISABLED. Production calls
        # ``enable_list_cache(ttl_seconds=5.0)`` at boot before the
        # boot-time consumer fan-out (knowledge_graph.build,
        # vault_search.index_vault). Tests get the default (no cache)
        # so rapid write→build→write→build cycles aren't poisoned by
        # stale cache hits in deep subdirs (where the root vault_dir
        # mtime doesn't move).
        self._list_cache_ttl: float = 0.0

    def _resolve(self, relative_path: str) -> Path:
        """Resolve a logical vault path to a physical path."""
        if self._paths:
            return self._paths.resolve(relative_path)
        return self._vault_dir / relative_path

    @property
    def vault_dir(self) -> Path:
        return self._vault_dir

    @property
    def paths(self) -> VaultPaths | None:
        return self._paths

    def resolve_identity_path(self, filename: str) -> str:
        """Resolve an identity file path."""
        return f"system/identity/{filename}"

    def read(self, relative_path: str) -> VaultDocument:
        """Read a single vault file. Raises FileNotFoundError if missing."""
        path = self._resolve(relative_path)
        if not path.is_file():
            raise FileNotFoundError(f"Vault file not found: {path}")
        raw = path.read_text(encoding="utf-8")
        post = frontmatter.loads(raw)
        return VaultDocument(
            path=path,
            metadata=dict(post.metadata),
            content=post.content,
            raw=raw,
        )

    def read_identity_files(self) -> dict[str, VaultDocument]:
        """Read the core identity files + MEMORY.

        Identity files (SOUL, USER, PROFILE, CONTRACT, TRUST) live in system/identity/.
        MEMORY.md lives in memory/.
        Returns a dict keyed by filename stem (e.g., 'SOUL', 'USER', 'MEMORY').
        """
        result: dict[str, VaultDocument] = {}
        for filename in _IDENTITY_FILES:
            path = self._resolve(f"system/identity/{filename}")
            if path.is_file():
                result[path.stem] = self.read(f"system/identity/{filename}")

        # MEMORY.md lives in memory/
        mem_path = self._resolve("memory/MEMORY.md")
        if mem_path.is_file():
            result["MEMORY"] = self.read("memory/MEMORY.md")

        return result

    # Directories that contain archived/versioned content — never included in listings.
    # Individual callers no longer need to filter these out.
    _SKIP_DIRS = frozenset((".history", ".archives", "_archives"))  # arch:deterministic — version-history and archive directories, never included in listings regardless of caller or user preference

    def list_files(self, directory: str = "", pattern: str = "*.md") -> list[Path]:
        """List markdown files in a vault subdirectory.

        Automatically excludes .history/, .archives/, and _archives/ directories
        so archived/versioned files never leak into knowledge pipelines.

        When VaultPaths is available, resolves the directory through the
        path resolver. When directory is empty, scans all content roots.

        2026-05-12 perf: per-(directory, pattern) TTL cache. On Wolf's
        1700-article Windows vault, the recursive glob takes 40+
        seconds. Multiple boot-time consumers (knowledge_graph.build,
        vault_search.index_vault, etc.) used to each pay the full
        glob cost. With the cache, the second consumer within
        ``_list_cache_ttl`` seconds reuses the first one's result.
        Single-flight: a concurrent second caller blocks on the lock
        long enough to see the freshly-saved cache entry (no parallel
        duplicate glob).
        """
        # Fast bail when caching is disabled (default). Hot path for
        # tests + minimal installs that never enabled the cache.
        if self._list_cache_ttl <= 0.0:
            return self._list_files_uncached(directory, pattern)

        # 2026-05-13 — mtime probe DROPPED. Original design (commit f982510
        # bumping TTL to 300s) checked ``vault_dir.stat().st_mtime`` to
        # invalidate the cache when ANY file changed. Sounds correct, but
        # in production it's defeating itself: the inbox watcher / finance
        # reconciler / journal writer all create files under vault_dir
        # during the seconds BETWEEN vault_search.index_vault() (which
        # warmed the cache) and knowledge_graph.build() (which expected
        # the cache hit). Every such write ticks vault_dir mtime → cache
        # miss → full glob walks again (101s on the user's 1700-file
        # vault, measured 2026-05-13 21:56).
        #
        # The mtime probe traded ~50µs of "always correct" for ~101s of
        # "actually slow". TTL-only is the right invalidation strategy:
        # the 300s window is short enough that no operator is hand-
        # editing the vault during the boot window, and ANY operation
        # that needs guaranteed fresh data (live "did the user just
        # create a file?" queries) can call ``invalidate_list_cache()``
        # explicitly. Within the TTL window the cache is intentionally
        # treated as eventually-consistent — that's the architectural
        # commitment.
        #
        # Tests get the same TTL=0 default they always got, so this
        # change doesn't affect them.
        cache_key = (directory, pattern)
        now = time.monotonic()
        # Fast path: cache hit + within TTL
        with self._list_cache_lock:
            entry = self._list_cache.get(cache_key)
            if entry is not None:
                cached_at, _cached_mtime, cached_value = entry
                if now - cached_at < self._list_cache_ttl:
                    return list(cached_value)  # defensive copy

        # Compute outside the lock so a slow walk doesn't block other
        # readers / writers on unrelated keys.
        result = self._list_files_uncached(directory, pattern)

        with self._list_cache_lock:
            # mtime field kept in the cache shape for backward compat
            # with anything that introspects it (none does today, but
            # the dict shape is part of the published contract).
            self._list_cache[cache_key] = (time.monotonic(), 0.0, list(result))
        return result

    def _list_files_uncached(self, directory: str, pattern: str) -> list[Path]:
        """Pure file-walk implementation. Always re-globs.

        Extracted so the cached path can call it without recursion. Same
        behavior as the pre-cache ``list_files``.
        """
        if self._paths:
            if directory:
                base = self._paths.resolve(directory)
                if not base.is_dir():
                    return []
                return sorted(self._filter_archived(base.glob(pattern)))
            # Empty directory = scan all content roots
            results: list[Path] = []
            for root in self._paths.all_content_roots():
                results.extend(self._filter_archived(root.glob(pattern)))
            return sorted(results)

        base = self._vault_dir / directory if directory else self._vault_dir
        if not base.is_dir():
            return []
        return sorted(self._filter_archived(base.glob(pattern)))

    def list_files_with_stat(
        self, directory: str = "", pattern: str = "**/*.md",
    ) -> list[tuple[Path, int, int]]:
        """Like ``list_files`` but returns ``(path, mtime_ns, size)`` per file.

        Walks via ``os.scandir()`` so file stat metadata comes from the
        DirEntry the OS already produced during directory iteration — on
        Windows this is ZERO extra syscalls vs. ``Path.stat()`` on each
        file (~25ms each on antivirus-protected systems). On Wolf's
        1700-file vault this drops the boot stat sweep from ~28s to
        ~few-hundred-ms.

        Correctness: the mtime/size returned are CURRENT (from this
        walk's DirEntry, not any prior session's cache). So callers
        comparing against a persisted index correctly detect modified
        files — no regression vs. the previous ``Path.stat()`` path.

        Supported patterns:
          - ``"**/*.<ext>"`` — recursive walk, match files with ``<ext>``.
          - ``"*.<ext>"`` — flat walk in the given directory.
          - Other patterns: returns ``[]`` (caller should fall back to
            ``list_files`` + manual stat).

        ``_SKIP_DIRS`` is honored (``.history`` / ``.archives`` /
        ``_archives`` are pruned during the walk).

        Results sorted by path for deterministic output, matching
        ``list_files``'s contract.
        """
        recursive, ext = _parse_simple_glob_pattern(pattern)
        if ext is None:
            return []

        if self._paths and not directory:
            roots = list(self._paths.all_content_roots())
        elif self._paths:
            base = self._paths.resolve(directory)
            if not base.is_dir():
                return []
            roots = [base]
        else:
            base = self._vault_dir / directory if directory else self._vault_dir
            if not base.is_dir():
                return []
            roots = [base]

        results: list[tuple[Path, int, int]] = []
        for root in roots:
            results.extend(_iter_files_with_stat(root, recursive, ext, self._SKIP_DIRS))
        results.sort(key=lambda triple: triple[0])
        return results

    def invalidate_list_cache(self) -> None:
        """Drop the cached file lists. Useful after a known mass-mutation
        (KB rename, vault restructure, etc.) that should be reflected in
        the next ``list_files`` call without waiting for TTL expiry."""
        with self._list_cache_lock:
            self._list_cache.clear()

    def enable_list_cache(self, ttl_seconds: float = _DEFAULT_LIST_CACHE_TTL_SECONDS) -> None:
        """Turn on the ``list_files`` TTL cache.

        Production calls this at boot so consumer fan-out (graph build,
        FTS5 index, embeddings index) shares a single vault walk. Default
        is OFF — tests do rapid write→build→write→build cycles in deep
        subdirs where the root vault_dir's mtime doesn't move, so any
        non-zero TTL produces stale hits. Production has a well-defined
        boot window where the cache is safe.

        Pass ``ttl_seconds <= 0`` to disable.
        """
        with self._list_cache_lock:
            self._list_cache_ttl = max(0.0, float(ttl_seconds))
            if self._list_cache_ttl <= 0.0:
                self._list_cache.clear()

    @classmethod
    def _filter_archived(cls, paths) -> list[Path]:
        """Remove files inside archive/history directories."""
        return [
            p for p in paths
            if not cls._SKIP_DIRS.intersection(p.parts)
        ]

    def exists(self, relative_path: str) -> bool:
        """Check whether a vault file exists."""
        return self._resolve(relative_path).is_file()

    def dir_exists(self, relative_path: str) -> bool:
        """Check whether a vault directory exists."""
        return self._resolve(relative_path).is_dir()
