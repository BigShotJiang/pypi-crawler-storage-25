"""Post-write delta lint for vault files (P3.3, Hermes-borrow).

Every `VaultWriter.write()` and `VaultWriter.append()` syntax-checks
the FINAL file content based on its extension. Bad output (broken
Python, malformed JSON, etc.) surfaces immediately as a high-importance
``tool_output_lint_failed`` activity event so the agent sees it on
its next turn — instead of shipping silently downstream where a
malformed YAML config or invalid JSON dataset eventually crashes some
unrelated consumer hours later.

Architectural commitments:

1. **Non-blocking.** A lint failure NEVER reverts the write. The
   broken file lands on disk + the lint failure lands in the activity
   feed. Reverting would create a worse failure mode (caller gets
   nothing, no way to inspect the bad output) and is at odds with the
   "make the failure visible" principle. The agent's next turn reads
   the activity context and can self-correct.

2. **Pure functions only.** ``lint_python(content)`` etc. take a
   string + return a ``LintResult``. They never touch disk, never
   read the filesystem, never raise. Easy to test in isolation.

3. **Extension-based dispatch via a closed set.** ``.py`` / ``.json``
   / ``.yaml`` / ``.yml`` / ``.toml``. Other extensions (``.md`` / no
   extension / binary) skip linting entirely — ``lint_content`` returns
   ``None`` to signal "no applicable linter". The dispatcher is a
   single function so adding a new linter is one entry.

4. **Stdlib only.** ``ast`` for Python, ``json`` for JSON, ``yaml``
   (PyYAML — already a base dep) for YAML, ``tomllib`` for TOML
   (Python 3.11+). No new dependencies.

5. **Size cap to defend the chat path.** Linting a 50 MB JSON blob
   would block the write call for seconds. ``MAX_LINT_BYTES`` (default
   2 MiB) skips oversized files with a `oversized` reason. Pure
   defense; the lint feature is opt-in via the YAML config anyway.

6. **Skill-driven.** Engine reads ``_meta/post-write-lint/config/lint.yaml``
   for the master switch + ignored path prefixes + size cap. Rule 12:
   tuning lives in YAML, not Python.

7. **Fail-open at every boundary.** The runner (``lint_content`` +
   ``run_post_write_lint``) catches every exception and returns
   ``None`` / no-op. A broken linter MUST NOT break the write path.
"""

from __future__ import annotations

import ast
import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


_EXTENSION_LINTERS: dict[str, str] = {  # arch:deterministic — closed enum of extension → linter; adding a new linter requires a new pure function, so the map is engine substrate not strategy
    ".py": "python",
    ".json": "json",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".toml": "toml",
}

_DEFAULT_MAX_LINT_BYTES: int = 2 * 1024 * 1024  # arch:deterministic — 2 MiB size cap; YAML can tune
_FALLBACK_CONFIG: dict[str, Any] = {  # arch:deterministic — engine fallback for YAML; tuning lives in _meta/post-write-lint/config/lint.yaml (Rule 12)
    "enabled": True,
    "max_bytes": _DEFAULT_MAX_LINT_BYTES,
    "ignore_path_prefixes": [".history/", ".archives/", ".quarantine/"],
}


@dataclass(frozen=True)
class LintResult:
    """Outcome of a single lint pass.

    Attributes:
        ok: True iff content parsed cleanly OR the linter doesn't apply.
        language: One of ``"python"`` / ``"json"`` / ``"yaml"`` /
            ``"toml"`` — empty when no applicable linter.
        reason: Machine-readable failure code. Empty on ok.
            Closed set: ``"syntax_error"`` / ``"oversized"`` /
            ``"parser_unavailable"`` / ``"unknown"``.
        message: Single-line human-readable error message; empty on ok.
        line: 1-based line number of the error; None when not available.
    """

    ok: bool
    language: str
    reason: str = ""
    message: str = ""
    line: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "language": self.language,
            "reason": self.reason,
            "message": self.message,
            "line": self.line,
        }


# ── Pure-function linters ─────────────────────────────────────────────


def lint_python(content: str) -> LintResult:
    """Syntax-check a Python file via ``ast.parse``.

    Catches SyntaxError + IndentationError + value errors. Doesn't run
    the code; ``ast.parse`` is a static parser. Empty / whitespace-only
    content passes (an empty .py is a valid module).
    """
    try:
        ast.parse(content)
    except SyntaxError as e:
        return LintResult(
            ok=False,
            language="python",
            reason="syntax_error",
            message=(e.msg or "syntax error")[:240],
            line=e.lineno,
        )
    except Exception as e:
        # ast.parse on extreme-deep nesting can raise other errors;
        # treat them all as syntax-class failures.
        return LintResult(
            ok=False,
            language="python",
            reason="syntax_error",
            message=str(e)[:240],
            line=None,
        )
    return LintResult(ok=True, language="python")


def lint_json(content: str) -> LintResult:
    """Validate JSON via ``json.loads``.

    Empty content fails (JSON requires at least one value). The
    ``json.JSONDecodeError`` carries ``lineno`` for click-through.
    """
    if not content.strip():
        return LintResult(
            ok=False,
            language="json",
            reason="syntax_error",
            message="empty file is not valid JSON",
            line=1,
        )
    try:
        json.loads(content)
    except json.JSONDecodeError as e:
        return LintResult(
            ok=False,
            language="json",
            reason="syntax_error",
            message=(e.msg or "json decode error")[:240],
            line=e.lineno,
        )
    except Exception as e:
        return LintResult(
            ok=False,
            language="json",
            reason="syntax_error",
            message=str(e)[:240],
            line=None,
        )
    return LintResult(ok=True, language="json")


def lint_yaml(content: str) -> LintResult:
    """Validate YAML via ``yaml.safe_load``.

    PyYAML is a base dependency, so import is safe. Empty content is
    valid YAML (loads to None) so we don't reject it. Caller's caller
    decides whether None is acceptable.
    """
    try:
        import yaml  # PyYAML, base dep
    except ImportError:
        return LintResult(
            ok=True,  # not our job to fail when the parser isn't installed
            language="yaml",
            reason="parser_unavailable",
            message="pyyaml not installed; skipping",
        )
    try:
        yaml.safe_load(content)
    except yaml.YAMLError as e:
        # PyYAML's YAMLError has a ``problem_mark`` carrying line info
        # on the canonical SyntaxError-like subclasses.
        line = None
        msg = str(e)[:240]
        mark = getattr(e, "problem_mark", None)
        if mark is not None:
            line_attr = getattr(mark, "line", None)
            if isinstance(line_attr, int):
                line = line_attr + 1  # PyYAML uses 0-based; normalise to 1-based
        return LintResult(
            ok=False,
            language="yaml",
            reason="syntax_error",
            message=msg,
            line=line,
        )
    except Exception as e:
        return LintResult(
            ok=False,
            language="yaml",
            reason="syntax_error",
            message=str(e)[:240],
            line=None,
        )
    return LintResult(ok=True, language="yaml")


def lint_toml(content: str) -> LintResult:
    """Validate TOML via ``tomllib`` (Python 3.11+).

    Empty content is valid TOML (empty document). ``tomllib`` is
    read-only — we don't need ``tomli_w``.
    """
    try:
        import tomllib  # Python 3.11+ stdlib
    except ImportError:
        return LintResult(
            ok=True,
            language="toml",
            reason="parser_unavailable",
            message="tomllib not available (Python < 3.11?); skipping",
        )
    try:
        tomllib.loads(content)
    except tomllib.TOMLDecodeError as e:
        return LintResult(
            ok=False,
            language="toml",
            reason="syntax_error",
            message=str(e)[:240],
            line=None,
        )
    except Exception as e:
        return LintResult(
            ok=False,
            language="toml",
            reason="syntax_error",
            message=str(e)[:240],
            line=None,
        )
    return LintResult(ok=True, language="toml")


# ── Dispatcher ────────────────────────────────────────────────────────


def detect_language(relative_path: str) -> str:
    """Return the language for ``relative_path`` based on extension.

    Returns ``""`` when no applicable linter — caller should skip.
    Pure function; no I/O.
    """
    if not relative_path:
        return ""
    normalised = relative_path.replace("\\", "/").lower()
    # Take the last segment's extension. Path with multiple dots
    # (e.g. ``foo.bar.json``) takes the rightmost extension.
    last_dot = normalised.rfind(".")
    if last_dot < 0:
        return ""
    ext = normalised[last_dot:]
    return _EXTENSION_LINTERS.get(ext, "")


def lint_content(
    content: str,
    relative_path: str,
    *,
    max_bytes: int = _DEFAULT_MAX_LINT_BYTES,
) -> LintResult | None:
    """Lint ``content`` based on the file's extension.

    Returns:
        ``LintResult`` when an applicable linter ran (ok or fail).
        ``None`` when no linter applies (e.g. ``.md``, no extension,
        binary). Callers MUST treat ``None`` as "skip — no signal".

    Fail-open at every boundary: a broken linter raises → log debug
    + return None (treated as skipped). The write path NEVER sees an
    exception from this function.
    """
    language = detect_language(relative_path)
    if not language:
        return None
    try:
        size = len(content.encode("utf-8", errors="ignore"))
    except Exception:
        return None
    if max_bytes > 0 and size > max_bytes:
        return LintResult(
            ok=False,
            language=language,
            reason="oversized",
            message=f"content exceeds lint cap of {max_bytes} bytes ({size} actual)",
            line=None,
        )
    try:
        if language == "python":
            return lint_python(content)
        if language == "json":
            return lint_json(content)
        if language == "yaml":
            return lint_yaml(content)
        if language == "toml":
            return lint_toml(content)
    except Exception:
        log.debug("lint: dispatcher raised for %s", relative_path, exc_info=True)
        return None
    # Defensive — should never reach here given the closed enum.
    return None


# ── YAML resolver + ignore-path check ─────────────────────────────────


def resolve_config(skill_loader: object | None) -> dict[str, Any]:
    """Read ``_meta/post-write-lint/config/lint.yaml`` with fallback.

    Rule 12: every knob lives in YAML; engine reads with deterministic
    fallback when the YAML is missing / malformed / loader is broken.
    """
    if skill_loader is None:
        return dict(_FALLBACK_CONFIG)
    try:
        cfg = skill_loader.load_skill_config_file(  # type: ignore[attr-defined]
            "post-write-lint", "lint.yaml",
        )
    except Exception:
        log.debug("post-write-lint: YAML read failed", exc_info=True)
        return dict(_FALLBACK_CONFIG)
    if not isinstance(cfg, dict):
        return dict(_FALLBACK_CONFIG)
    merged = dict(_FALLBACK_CONFIG)
    if "enabled" in cfg:
        merged["enabled"] = bool(cfg["enabled"])
    if "max_bytes" in cfg:
        try:
            merged["max_bytes"] = int(cfg["max_bytes"])
        except (TypeError, ValueError):
            pass
    if "ignore_path_prefixes" in cfg:
        ignore = cfg["ignore_path_prefixes"]
        if isinstance(ignore, list):
            merged["ignore_path_prefixes"] = [
                str(p) for p in ignore if isinstance(p, str) and p
            ]
    return merged


def is_ignored_path(relative_path: str, ignore_prefixes: list[str]) -> bool:
    """True iff any segment of ``relative_path`` starts with a prefix.

    Default ignores (`.history/` / `.archives/` / `.quarantine/`)
    cover the canonical "agent never wrote this; it's a snapshot or
    quarantined dropout" cases. Pure function.
    """
    if not relative_path:
        return True
    normalised = relative_path.replace("\\", "/")
    for prefix in ignore_prefixes:
        if not prefix:
            continue
        # Either the path starts with the prefix, or it contains the
        # prefix as a path segment.
        if normalised.startswith(prefix):
            return True
        if "/" + prefix.rstrip("/") + "/" in "/" + normalised:
            return True
    return False


# ── Activity event runner (called from VaultWriter) ──────────────────


def run_post_write_lint(
    *,
    path: Path,
    relative_path: str,
    content: str | None,
    skill_loader: object | None,
    activity_logger: object | None,
) -> None:
    """Run the lint pass + emit activity event on failure.

    This is the single entry point ``VaultWriter`` calls. Fail-open at
    every boundary — broken loader / broken file read / broken
    activity logger never propagate. The write itself is already on
    disk before this runs.

    Args:
        path: Resolved on-disk path (for fallback content re-read on
            append paths where the caller doesn't have the final
            content in hand).
        relative_path: Logical vault path (for the activity event +
            ignore-prefix check).
        content: Final file content. Pass None to re-read from disk
            (the append() case — partial content can't be linted).
        skill_loader: For YAML config resolution. None falls back to
            _FALLBACK_CONFIG.
        activity_logger: For emitting the failure event. None → skip
            event but still run the check (logging path).
    """
    try:
        cfg = resolve_config(skill_loader)
        if not cfg.get("enabled", True):
            return
        # Skip ignored paths (history / archives / quarantine).
        ignore = cfg.get("ignore_path_prefixes") or []
        if is_ignored_path(relative_path, ignore):
            return
        # Quick extension gate — avoid reading the file when we won't
        # lint anyway.
        if not detect_language(relative_path):
            return
        # Re-read from disk if content wasn't provided (append path).
        if content is None:
            try:
                content = path.read_text(encoding="utf-8")
            except Exception:
                log.debug("post-write-lint: read failed for %s", path, exc_info=True)
                return
        max_bytes = int(cfg.get("max_bytes", _DEFAULT_MAX_LINT_BYTES))
        result = lint_content(content, relative_path, max_bytes=max_bytes)
    except Exception:
        log.debug("post-write-lint: runner raised", exc_info=True)
        return
    if result is None:
        return
    if result.ok:
        return
    _emit_failure_event(
        activity_logger=activity_logger,
        relative_path=relative_path,
        result=result,
    )


def _emit_failure_event(
    *,
    activity_logger: object | None,
    relative_path: str,
    result: LintResult,
) -> None:
    """Fire a ``tool_output_lint_failed`` activity event. Total."""
    if activity_logger is None:
        return
    try:
        # Mirrors the Hermes-borrow action name verbatim so future
        # observers can grep across both codebases. medium importance
        # → lands in observations + agent's next-turn relationship
        # context. Not 'high' because a single lint failure isn't a
        # production-impacting issue; it's a quality signal.
        activity_logger.log(  # type: ignore[attr-defined]
            "system",
            "tool_output_lint_failed",
            f"Lint failed for {relative_path} ({result.language}): {result.message}",
            {
                "path": relative_path,
                "language": result.language,
                "reason": result.reason,
                "message": result.message,
                "line": result.line,
            },
            importance="medium",
        )
    except Exception:
        log.debug("post-write-lint: activity emit failed", exc_info=True)
