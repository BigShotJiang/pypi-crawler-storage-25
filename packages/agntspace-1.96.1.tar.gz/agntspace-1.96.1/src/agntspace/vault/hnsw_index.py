"""HNSW (Hierarchical Navigable Small World) vector-index primitive for
sub-linear semantic search over ``vault_embeddings``.

**Why**: ``VaultEmbeddings.search`` previously did a linear scan of every
chunk's float32 blob and computed cosine in pure Python. At ~1700 articles
that's a few hundred ms per query; at 10K it's seconds. HNSW gives
O(log N) approximate-nearest-neighbor lookup at the cost of ~5-10% recall
trade — universally accepted for semantic retrieval where the top-10 is
already noisy from the embedding model itself.

**Architectural commitments locked here**:

1. **Fail-soft everywhere.** Missing ``hnswlib`` (the optional dep) is the
   common case — first-run users don't have it. Every public method
   returns a safe sentinel (``False`` / ``None`` / ``[]``) when the
   library is missing or any internal call raises. Callers see
   ``is_available()`` is ``False`` and fall through to the linear-scan
   path. The primitive NEVER raises into the search path.
2. **Pure wrapper, no policy.** Build / add / query / save / load are
   the surface. Staleness detection (e.g. "DB row count changed → mark
   index stale") lives on the caller (``VaultEmbeddings``) because the
   right staleness signal is domain-specific.
3. **Index is per-vault, per-model.** The on-disk file lives next to
   ``agntspace.db``; the model identity is checked at load time so a
   bge-m3 → nomic-embed-text swap drops the stale HNSW alongside the
   embedding wipe.
4. **L2-normalized cosine via the 'ip' (inner product) space.** HNSW
   uses inner product on unit-length vectors, which is equivalent to
   cosine similarity. We normalize on add + on query so callers don't
   need to know.
5. **No numpy dependency.** ``hnswlib`` takes Python lists of floats
   just fine via its ``add_items`` API when passed as a single nested
   list; we use only the parts of the API that accept native Python.
   Keeps the vault-embeddings stack pure-stdlib + ``httpx``.

**License**: ``hnswlib`` is Apache-2.0. Per Rule 6 (unified license
priority), Tier-2 (permissive non-MIT) acceptable when no proper MIT
alternative exists. There is no maintained MIT HNSW library at
hnswlib's quality + correctness level; ``hnswlib`` is the de-facto
implementation referenced by every research paper using HNSW. Tagged
``arch:no-mit-alternative`` at the pyproject.toml dep line.
"""

from __future__ import annotations

import json
import logging
import math
import os
from collections.abc import Sequence
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

# arch:deterministic — schema version of the on-disk sidecar metadata.
# Bump when the metadata file shape changes (e.g. adding a new field
# the loader must check). Old sidecars with a mismatched version are
# treated as stale and the index is rebuilt. Pure infrastructure, not
# a user-tunable preference.
_SIDECAR_SCHEMA_VERSION: int = 1

# arch:deterministic — HNSW construction parameters. These are the
# empirically-standard defaults from the original HNSW paper (Malkov
# & Yashunin 2018). M=16 is the graph degree (memory/quality
# tradeoff); ef_construction=200 controls build-time quality.
# ef_query is the search-time exploration count — higher = better
# recall, slower. 50 is a reasonable mid-point for the 1024-dim
# embedding space we use. Not user-tunable today; if a user reports
# specific recall problems, surface a YAML knob then.
_DEFAULT_M: int = 16
_DEFAULT_EF_CONSTRUCTION: int = 200
_DEFAULT_EF_QUERY: int = 50


def _l2_normalize(vec: Sequence[float]) -> list[float]:
    """Return a unit-length copy of ``vec``. Returns the input as a list
    unchanged when the norm is zero so an all-zero vector doesn't crash
    the indexer (it just becomes a useless point — handled by hnswlib).
    """
    if not vec:
        return []
    s = 0.0
    for x in vec:
        s += x * x
    if s <= 0.0:
        return list(vec)
    inv = 1.0 / math.sqrt(s)
    return [x * inv for x in vec]


class HNSWIndex:
    """Fail-soft HNSW wrapper.

    Construction is cheap and never touches the filesystem or the network.
    Call ``build(...)`` to populate the in-memory index, ``save(path)``
    to persist, ``load(path)`` to rehydrate. ``query(...)`` returns the
    top-K nearest items as ``(label, score)`` pairs where ``score`` is
    cosine similarity in [-1, 1] (1.0 = identical direction).
    """

    __slots__ = (
        "_dim",
        "_index",
        "_size",
        "_model_identity",
        "_ef_query",
    )

    def __init__(
        self,
        *,
        dim: int = 0,
        model_identity: str = "",
        ef_query: int = _DEFAULT_EF_QUERY,
    ) -> None:
        self._dim: int = int(dim) if dim > 0 else 0
        self._index: Any = None  # hnswlib.Index when built; None otherwise
        self._size: int = 0
        self._model_identity: str = model_identity
        self._ef_query: int = int(ef_query) if ef_query > 0 else _DEFAULT_EF_QUERY

    # ── Capability gate ──────────────────────────────────────────────────

    @staticmethod
    def is_available() -> bool:
        """``True`` iff the optional ``hnswlib`` import succeeds. Caller
        gates the entire HNSW path on this — a missing dep is a fall-through,
        never an error.
        """
        try:
            import hnswlib  # noqa: F401
        except Exception:
            return False
        return True

    # ── Read accessors ───────────────────────────────────────────────────

    @property
    def size(self) -> int:
        """Number of items currently in the index. 0 when not built or empty."""
        return self._size

    @property
    def dim(self) -> int:
        """Embedding dimensionality. 0 when not built."""
        return self._dim

    @property
    def model_identity(self) -> str:
        """Backing model identity (e.g. ``ollama:bge-m3``) recorded at build
        time. Empty string when not built. Used by ``load()`` to refuse
        rehydrating an index whose model doesn't match the current one.
        """
        return self._model_identity

    @property
    def ready(self) -> bool:
        """``True`` iff the in-memory index has at least one item and the
        backing library loaded successfully."""
        return self._index is not None and self._size > 0

    # ── Mutators ─────────────────────────────────────────────────────────

    def build(
        self,
        vectors: Sequence[Sequence[float]],
        labels: Sequence[int],
        *,
        max_elements: int | None = None,
    ) -> bool:
        """Build a fresh index from ``vectors`` (one vector per row) and
        the matching ``labels`` (one int per row, used as the integer id
        returned by ``query``).

        Returns ``True`` on success, ``False`` on any failure (caller
        treats it as "index unavailable, fall through to linear scan").
        ``max_elements`` defaults to ``2 * len(vectors)`` so incremental
        ``add`` calls can grow the index without rebuilding.
        """
        if not self.is_available():
            return False
        if len(vectors) != len(labels):
            log.warning(
                "HNSWIndex.build: vectors / labels length mismatch (%d != %d)",
                len(vectors), len(labels),
            )
            return False
        if not vectors:
            # Empty build is valid — produces a usable but empty index.
            try:
                import hnswlib
                idx = hnswlib.Index(space="ip", dim=max(self._dim, 1))
                idx.init_index(max_elements=max(max_elements or 1, 1),
                               ef_construction=_DEFAULT_EF_CONSTRUCTION,
                               M=_DEFAULT_M)
                idx.set_ef(self._ef_query)
                self._index = idx
                self._size = 0
                return True
            except Exception:
                log.debug("HNSWIndex.build: empty-index init failed", exc_info=True)
                return False

        # Infer dim from the first vector if not pre-set.
        first = list(vectors[0])
        if not first:
            return False
        if self._dim <= 0:
            self._dim = len(first)
        if len(first) != self._dim:
            log.warning(
                "HNSWIndex.build: first vector dim %d != index dim %d",
                len(first), self._dim,
            )
            return False

        try:
            import hnswlib
            cap = max_elements if max_elements is not None else max(len(vectors) * 2, 16)
            idx = hnswlib.Index(space="ip", dim=self._dim)
            idx.init_index(max_elements=cap,
                           ef_construction=_DEFAULT_EF_CONSTRUCTION,
                           M=_DEFAULT_M)
            idx.set_ef(self._ef_query)
            # L2-normalize so inner product == cosine.
            normalized = [_l2_normalize(v) for v in vectors]
            idx.add_items(normalized, list(labels))
            self._index = idx
            self._size = len(vectors)
            return True
        except Exception:
            log.debug("HNSWIndex.build: hnswlib raised", exc_info=True)
            self._index = None
            self._size = 0
            return False

    def add(self, vector: Sequence[float], label: int) -> bool:
        """Append a single ``(vector, label)`` to the index.

        Returns ``False`` if the index isn't built, dims mismatch, or
        hnswlib raises. Caller can react by rebuilding from scratch.
        Growing past ``max_elements`` (the cap given at build time)
        will fail; caller should rebuild when this returns False
        repeatedly.
        """
        if not self.ready and self._index is None:
            return False
        if self._dim > 0 and len(vector) != self._dim:
            return False
        try:
            normalized = _l2_normalize(vector)
            self._index.add_items([normalized], [label])
            self._size += 1
            return True
        except Exception:
            log.debug("HNSWIndex.add: hnswlib raised", exc_info=True)
            return False

    # ── Query ────────────────────────────────────────────────────────────

    def query(
        self, vector: Sequence[float], top_k: int = 10,
    ) -> list[tuple[int, float]]:
        """Return up to ``top_k`` nearest items as ``(label, cosine_score)``.

        Returns ``[]`` on any failure (caller falls through to linear
        scan). ``cosine_score`` is in [-1, 1]; higher = more similar.
        """
        if not self.ready:
            return []
        if self._dim > 0 and len(vector) != self._dim:
            return []
        if top_k <= 0:
            return []
        try:
            normalized = _l2_normalize(vector)
            # hnswlib clamps k to min(k, size) internally but newer
            # versions raise on k > size; defend explicitly.
            k = min(top_k, self._size)
            if k <= 0:
                return []
            labels, distances = self._index.knn_query([normalized], k=k)
            # hnswlib returns 2D arrays even for a single query.
            label_row = labels[0]
            dist_row = distances[0]
            # 'ip' space stores ``1 - inner_product`` as distance for
            # normalized vectors. Cosine = 1 - distance.
            out: list[tuple[int, float]] = []
            for lab, dist in zip(label_row, dist_row, strict=False):
                score = 1.0 - float(dist)
                # Clamp numerical noise. Don't filter here — caller
                # decides whether to drop low-score hits.
                if score > 1.0:
                    score = 1.0
                elif score < -1.0:
                    score = -1.0
                out.append((int(lab), score))
            return out
        except Exception:
            log.debug("HNSWIndex.query: hnswlib raised", exc_info=True)
            return []

    # ── Persistence ──────────────────────────────────────────────────────

    def save(self, path: str | Path) -> bool:
        """Persist the index + sidecar metadata. Returns ``False`` on any
        write failure. The sidecar (``<path>.meta.json``) carries the
        model identity + dim + size + schema version so ``load()`` can
        refuse stale snapshots without bringing up hnswlib.
        """
        if not self.is_available() or self._index is None:
            return False
        try:
            path = Path(path)
            path.parent.mkdir(parents=True, exist_ok=True)
            # Atomic write via .tmp + os.replace so a crash mid-write
            # never leaves a truncated index file the next boot would
            # try to load (and crash on).
            tmp_index = path.with_suffix(path.suffix + ".tmp")
            self._index.save_index(str(tmp_index))
            os.replace(tmp_index, path)
            meta = {
                "schema_version": _SIDECAR_SCHEMA_VERSION,
                "model_identity": self._model_identity,
                "dim": self._dim,
                "size": self._size,
                "ef_query": self._ef_query,
            }
            meta_path = Path(str(path) + ".meta.json")
            tmp_meta = meta_path.with_suffix(".json.tmp")
            tmp_meta.write_text(json.dumps(meta, indent=2), encoding="utf-8")
            os.replace(tmp_meta, meta_path)
            return True
        except Exception:
            log.debug("HNSWIndex.save: failed", exc_info=True)
            return False

    def load(self, path: str | Path, *, expected_model_identity: str = "") -> bool:
        """Rehydrate from disk. Returns ``False`` when:

        - hnswlib isn't installed
        - the index file or sidecar doesn't exist
        - the sidecar's schema version doesn't match
        - ``expected_model_identity`` is given and the sidecar's identity
          differs (caller has switched embedding models since save)
        - hnswlib raises on load (corrupt file)
        """
        if not self.is_available():
            return False
        try:
            path = Path(path)
            meta_path = Path(str(path) + ".meta.json")
            if not path.exists() or not meta_path.exists():
                return False
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception:
                log.debug("HNSWIndex.load: sidecar unreadable", exc_info=True)
                return False
            if not isinstance(meta, dict):
                return False
            if meta.get("schema_version") != _SIDECAR_SCHEMA_VERSION:
                log.info(
                    "HNSWIndex.load: schema version mismatch (got %r, expected %d) — treating as stale",
                    meta.get("schema_version"), _SIDECAR_SCHEMA_VERSION,
                )
                return False
            sidecar_identity = str(meta.get("model_identity", ""))
            if expected_model_identity and sidecar_identity != expected_model_identity:
                log.info(
                    "HNSWIndex.load: model identity mismatch (%r != %r) — treating as stale",
                    sidecar_identity, expected_model_identity,
                )
                return False
            dim = int(meta.get("dim", 0) or 0)
            size = int(meta.get("size", 0) or 0)
            if dim <= 0:
                return False
            ef_query = int(meta.get("ef_query", _DEFAULT_EF_QUERY) or _DEFAULT_EF_QUERY)

            import hnswlib
            idx = hnswlib.Index(space="ip", dim=dim)
            # max_elements must be at least size; pass size for the cap
            # then set_ef. Newer hnswlib accepts max_elements override
            # in load_index; older versions infer from file.
            try:
                idx.load_index(str(path), max_elements=max(size * 2, 16))
            except TypeError:
                idx.load_index(str(path))
            idx.set_ef(ef_query)
            self._index = idx
            self._dim = dim
            self._size = size
            self._model_identity = sidecar_identity
            self._ef_query = ef_query
            return True
        except Exception:
            log.debug("HNSWIndex.load: hnswlib raised", exc_info=True)
            return False
