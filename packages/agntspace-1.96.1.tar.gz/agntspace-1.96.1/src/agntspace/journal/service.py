"""Journal service: user journal + agent observations, always separate files.

Section names ("Focus", "Mood", etc.) are canonical ASCII keys — they are
structural identifiers used by code, vault tooling, and PKM editors, the
same way HTML tag names or frontmatter field names stay in English. Every
piece of user-visible text (titles, descriptions, section hints) is loaded
through ``infra.i18n.t()`` so the content renders in the user's locale.

Section definitions, file naming, and timestamp format are loaded from the
``journal-template`` meta-skill's ``config/sections.yaml`` (Rule #12).
Hardcoded fallbacks are kept for backward compat when the skill isn't loaded.
"""

from __future__ import annotations

import logging
import re
from datetime import date as _date_cls
from pathlib import Path
from typing import TYPE_CHECKING

from agntspace.infra.i18n import t
from agntspace.vault.reader import VaultDocument, VaultReader
from agntspace.vault.writer import VaultWriter

if TYPE_CHECKING:
    from agntspace.skills.loader import SkillLoader

log = logging.getLogger(__name__)

# ── Hardcoded fallbacks (used only when skill config is unavailable) ──

_FALLBACK_USER_SECTIONS: tuple[tuple[str, str], ...] = (
    ("Focus", "journal.user_hints.focus"),
    ("Mood", "journal.user_hints.mood"),
    ("Gratitude", "journal.user_hints.gratitude"),
    ("Thoughts", "journal.user_hints.thoughts"),
    ("Notes", "journal.user_hints.notes"),
    ("Questions", "journal.user_hints.questions"),
    ("Decisions", "journal.user_hints.decisions"),
    ("Learnings", "journal.user_hints.learnings"),
    ("Blockers", "journal.user_hints.blockers"),
    ("Reflections", "journal.user_hints.reflections"),
)

_FALLBACK_AGENT_SECTIONS: tuple[tuple[str, str], ...] = (
    ("Observations", "journal.agent_hints.observations"),
    ("Actions", "journal.agent_hints.actions"),
    ("Tool Activity", "journal.agent_hints.tool_activity"),
    ("Subagent Activity", "journal.agent_hints.subagent_activity"),
    ("System Health", "journal.agent_hints.system_health"),
    ("Knowledge Changes", "journal.agent_hints.knowledge_changes"),
    ("User Patterns", "journal.agent_hints.user_patterns"),
    ("Notes", "journal.agent_hints.notes"),
)

_FALLBACK_FILE_TYPES: dict[str, dict[str, str]] = {
    "journal": {"prefix": "user-journal_", "dir": "user"},
    "observations": {"prefix": "agent-observations_", "dir": "agnt"},
    "briefing": {"prefix": "morning-briefing_", "dir": "agnt"},
    "eod": {"prefix": "eod-report_", "dir": "agnt"},
    "reflection": {"prefix": "daily-reflection_", "dir": "agnt"},
    "weekly_reflection": {"prefix": "weekly-reflection_", "dir": "agnt"},
}

_FALLBACK_TIMESTAMP_FORMAT = "%H:%M"

# Notes routing: short text-only notes write inline as ``- HH:MM — text`` in
# the daily journal so the user sees them directly in the Journal tab next
# to Focus / Mood / Thoughts. Long-form / formatted / image-bearing notes
# split into a per-file at journal/user/notes/{date}/{slug}.md with a stub
# wikilink in the daily journal. Threshold + markers are deterministic
# structural decisions, not user-tunable strategy.
_NOTE_QUICK_MAX_CHARS = 280  # arch:deterministic — quick-vs-rich content-length floor
_NOTE_RICH_MARKERS = (  # arch:deterministic — any of these forces rich-per-file
    "![",        # image embed
    "```",       # code fence
    "\n\n",      # multiple paragraphs
)
_NOTE_LIST_LINE = re.compile(r"^(?:[-*+]\s|\d+\.\s)", re.MULTILINE)
_NOTE_HEADING_LINE = re.compile(r"^#{1,6}\s", re.MULTILINE)


def _load_sections_config(skill_loader: SkillLoader | None) -> dict | None:
    """Load sections.yaml from the journal-template meta-skill."""
    if not skill_loader:
        return None
    try:
        return skill_loader.load_skill_config_file("journal-template", "sections.yaml")
    except Exception:
        return None


def _parse_section_list(raw: list[dict] | None) -> tuple[tuple[str, str], ...] | None:
    """Parse a YAML section list into the (key, hint_i18n) tuple format."""
    if not raw or not isinstance(raw, list):
        return None
    result = []
    for entry in raw:
        if isinstance(entry, dict) and "key" in entry:
            result.append((entry["key"], entry.get("hint_i18n", "")))
    return tuple(result) if result else None


def _build_template(
    date: str,
    sections: tuple[tuple[str, str], ...],
    title_key: str,
    desc_key: str,
    author: str,
    extra_fm: dict[str, str] | None = None,
) -> str:
    """Build a journal template from section definitions."""
    title = t(title_key, date=date)
    description = t(desc_key)
    parts = [
        "---",
        f'title: "{title}"',
        f'date: "{date}"',
        f"author: {author}",
    ]
    if extra_fm:
        for k, v in extra_fm.items():
            parts.append(f"{k}: {v}")
    parts.append(f'description: "{description}"')
    parts.append("---")
    parts.append("")
    for header, hint_key in sections:
        parts.append(f"## {header}")
        if hint_key:
            parts.append(f"*{t(hint_key)}*")
        parts.append("")
    return "\n".join(parts)


class JournalService:
    """Manages daily journal entries in vault/journal/.

    Section structure, file types, and timestamp format are loaded from the
    ``journal-template`` meta-skill's ``config/sections.yaml`` at init time,
    with hardcoded fallbacks for backward compat.
    """

    # Directory constants
    _USER_DIR = "journal/user"
    _AGNT_DIR = "journal/agnt"

    def __init__(
        self,
        vault_reader: VaultReader,
        vault_writer: VaultWriter,
        skill_loader: SkillLoader | None = None,
        mention_indexer=None,
    ) -> None:
        self._reader = vault_reader
        self._writer = vault_writer
        self._skill_loader = skill_loader
        # Phase 1 second-brain integration — optional. None = no-op,
        # preserving legacy behaviour. Wired by main.py after the graph
        # is built.
        self._mention_indexer = mention_indexer

        # Load config from skill YAML, fall back to hardcoded defaults
        cfg = _load_sections_config(skill_loader)

        self._user_sections = (
            _parse_section_list(cfg.get("user_sections")) if cfg else None
        ) or _FALLBACK_USER_SECTIONS

        self._agent_sections = (
            _parse_section_list(cfg.get("agent_sections")) if cfg else None
        ) or _FALLBACK_AGENT_SECTIONS

        self._file_types: dict[str, dict[str, str]] = (
            cfg.get("file_types") if cfg and isinstance(cfg.get("file_types"), dict) else None
        ) or _FALLBACK_FILE_TYPES

        self._timestamp_format: str = (
            cfg.get("timestamp_format") if cfg else None
        ) or _FALLBACK_TIMESTAMP_FORMAT

        if cfg:
            log.debug("Journal sections loaded from journal-template skill config")
        else:
            log.debug("Journal sections using hardcoded fallbacks")

    # ---- Public accessors for config-driven data ----

    def get_user_section_keys(self) -> list[str]:
        """Return the list of valid user journal section keys."""
        return [key for key, _ in self._user_sections]

    def get_agent_section_keys(self) -> list[str]:
        """Return the list of valid agent observation section keys."""
        return [key for key, _ in self._agent_sections]

    def get_valid_file_types(self) -> set[str]:
        """Return the set of recognized file type keys."""
        return set(self._file_types.keys())

    # ---- Path helpers ----

    def _user_path(self, date: str | None = None) -> str:
        if not date:
            from agntspace.infra.timezone import local_today
            date = local_today()
        ft = self._file_types.get("journal", _FALLBACK_FILE_TYPES["journal"])
        return f"{self._USER_DIR}/{ft['prefix']}{date}.md"

    def _agent_path(self, date: str | None = None) -> str:
        if not date:
            from agntspace.infra.timezone import local_today
            date = local_today()
        ft = self._file_types.get("observations", _FALLBACK_FILE_TYPES["observations"])
        return f"{self._AGNT_DIR}/{ft['prefix']}{date}.md"

    def today_path(self) -> str:
        """Return the relative vault path for today's user journal."""
        return self._user_path()

    # ---- Read ----

    def get_today(self) -> VaultDocument:
        """Get or create today's user journal entry."""
        path = self._user_path()
        if not self._reader.exists(path):
            self._create_user_entry(path)
        return self._reader.read(path)

    def get_entry(self, date: str) -> VaultDocument | None:
        """Get a user journal entry by date string (YYYY-MM-DD)."""
        path = self._user_path(date)
        if not self._reader.exists(path):
            return None
        return self._reader.read(path)

    def get_agent_observations(self, date: str | None = None) -> VaultDocument | None:
        """Get agent observations for a date."""
        path = self._agent_path(date)
        if not self._reader.exists(path):
            return None
        return self._reader.read(path)

    def list_entries(self, limit: int = 30) -> list[dict]:
        """List recent user journal entries (newest first)."""
        journal_prefix = self._file_types.get("journal", _FALLBACK_FILE_TYPES["journal"])["prefix"]
        user_files = [
            f for f in self._reader.list_files(self._USER_DIR, "*.md")
            if f.name.startswith(journal_prefix)
        ]
        user_files.sort(key=lambda f: f.name, reverse=True)
        return [
            {"date": f.stem.replace(journal_prefix.rstrip("_"), "").lstrip("_"), "path": f"{self._USER_DIR}/{f.name}"}
            for f in user_files[:limit]
        ]

    def list_dates(self, limit: int = 30) -> list[dict]:
        """List recent journal dates with file types and status flags (newest first)."""
        date_map: dict[str, dict] = {}
        # Build prefix→file_type map from config
        _PREFIX_MAP = {
            ft_info["prefix"]: ft_key
            for ft_key, ft_info in self._file_types.items()
        }

        all_files = []
        for d in (self._USER_DIR, self._AGNT_DIR):
            all_files.extend(self._reader.list_files(d, "*.md"))

        for f in all_files:
            if f.suffix != ".md":
                continue
            name = f.name
            for prefix, file_type in _PREFIX_MAP.items():
                if name.startswith(prefix):
                    date = name.replace(prefix, "").replace(".md", "")
                    # weekly_reflection files are named with an ISO-week label
                    # (e.g. ``weekly-reflection_2026-W20.md``). Treating that
                    # label as a calendar date pollutes the sidebar with
                    # phantom ``2026-W##`` rows whose inventory endpoint
                    # 404s — folder hangs at "Loading…" forever. Attach the
                    # weekly file to the Sunday of its ISO week instead, so
                    # the user sees a "Weekly" tab on that Sunday's entry.
                    if file_type == "weekly_reflection":
                        try:
                            year_str, week_str = date.split("-W", 1)
                            sunday = _date_cls.fromisocalendar(
                                int(year_str), int(week_str), 7
                            )
                            date = sunday.isoformat()
                        except (ValueError, AttributeError):
                            # Malformed week label — drop the file entirely
                            # rather than create a broken phantom entry.
                            break
                    date_map.setdefault(date, {"date": date, "types": [], "flags": []})
                    if file_type not in date_map[date]["types"]:
                        date_map[date]["types"].append(file_type)
                    break

        # Enrich with status flags (lightweight — only reads metadata/sections, not full content)
        for date, entry in date_map.items():
            flags = entry["flags"]
            # Check reflection status
            if "reflection" in entry["types"]:
                refl_prefix = self._file_types.get("reflection", _FALLBACK_FILE_TYPES["reflection"])["prefix"]
                refl_path = f"{self._AGNT_DIR}/{refl_prefix}{date}.md"
                if self._reader.exists(refl_path):
                    doc = self._reader.read(refl_path)
                    status = doc.metadata.get("status", "")
                    if status == "pending":
                        flags.append("pending_reflection")
                    elif status == "approved":
                        flags.append("approved_reflection")
            # Check for blockers and questions in user journal
            if "journal" in entry["types"]:
                blockers = self.get_section("Blockers", date)
                if blockers:
                    flags.append("has_blockers")
                questions = self.get_section("Questions", date)
                if questions:
                    flags.append("has_questions")

        result = sorted(date_map.values(), key=lambda x: x["date"], reverse=True)
        return result[:limit]

    def _resolve_agnt_path(self, filename: str) -> str:
        """Resolve an agent journal file."""
        return f"{self._AGNT_DIR}/{filename}"

    def get_file_for_date(self, date: str, file_type: str) -> VaultDocument | None:
        """Get a specific journal file type for a date.

        ``weekly_reflection`` files are named with an ISO-week label
        (``weekly-reflection_2026-W20.md``), but ``list_dates`` surfaces them
        attached to their week's Sunday in ``YYYY-MM-DD`` form (so the
        Weekly tab appears alongside other tabs on Sunday entries). When the
        caller asks for a weekly_reflection by a Sunday date, convert back
        to the ISO-week label before resolving the path.
        """
        ft_info = self._file_types.get(file_type)
        if not ft_info:
            return None
        prefix = ft_info["prefix"]
        ft_dir = ft_info.get("dir", "agnt")
        file_token = date
        if file_type == "weekly_reflection" and "W" not in date:
            try:
                parsed = _date_cls.fromisoformat(date)
                iso_year, iso_week, _ = parsed.isocalendar()
                file_token = f"{iso_year}-W{iso_week:02d}"
            except ValueError:
                # Malformed input — fall through to the literal lookup
                # (will return None on miss).
                pass
        if ft_dir == "user":
            path = f"{self._USER_DIR}/{prefix}{file_token}.md"
        else:
            path = f"{self._AGNT_DIR}/{prefix}{file_token}.md"
        if not self._reader.exists(path):
            return None
        return self._reader.read(path)

    def get_section(self, section: str, date: str | None = None) -> str | None:
        """Read a specific section from the user journal."""
        path = self._user_path(date)
        if not self._reader.exists(path):
            return None
        doc = self._reader.read(path)
        # Extract section content between ## headers
        pattern = rf"## {re.escape(section)}\b.*?\n(.*?)(?=\n## |\Z)"
        match = re.search(pattern, doc.raw, re.DOTALL)
        if match:
            content = match.group(1).strip()
            # Strip HTML comments and italic hint lines
            content = re.sub(r"<!--.*?-->", "", content, flags=re.DOTALL)
            content = re.sub(r"^\*[^*]+\*$", "", content, flags=re.MULTILINE)
            content = content.strip()
            return content if content else None
        return None

    # ---- User writes (to user journal — user-only, agent never writes here) ----

    def append_to_user(self, section: str, text: str) -> None:
        """Append a timestamped entry to any user journal section."""
        self._append_to_user_section(section, f"- {self._timestamp()} — {text}")

    # Convenience methods kept for backward compat — delegate to generic append.
    def set_focus(self, text: str) -> None:
        self.append_to_user("Focus", text)

    def append_mood(self, text: str) -> None:
        self.append_to_user("Mood", text)

    def append_gratitude(self, text: str) -> None:
        self.append_to_user("Gratitude", text)

    def append_thought(self, text: str) -> None:
        self.append_to_user("Thoughts", text)

    def append_note(self, text: str) -> None:
        self.append_to_user("Notes", text)

    @staticmethod
    def _slugify(text: str, *, max_len: int = 60) -> str:
        """Slugify a string for use in a filename.

        Lowercase, strip diacritics, collapse non-alphanumerics to hyphens,
        trim leading/trailing hyphens, cap length. Returns empty string
        when input has no slug-able characters (caller decides fallback).
        """
        import unicodedata
        if not text:
            return ""
        normalized = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
        slug = re.sub(r"[^a-zA-Z0-9]+", "-", normalized).strip("-").lower()
        return slug[:max_len].rstrip("-")

    def _note_relpath(self, date: str, slug_no_ext: str) -> str:
        """Logical path to a per-note file under journal/user/notes/."""
        return f"{self._USER_DIR}/notes/{date}/{slug_no_ext}.md"

    def _note_link_path(self, date: str, slug_no_ext: str) -> str:
        """Wikilink-friendly path inserted into the daily journal stub.

        Relative to the daily journal file's location (``journal/user/``)
        so Obsidian and our own resolver both find it: ``notes/{date}/{slug}``.
        """
        return f"notes/{date}/{slug_no_ext}"

    def _resolve_unique_note_slug(self, date: str, base_slug: str) -> str:
        """Find a non-colliding slug for a per-note file.

        ``base_slug`` is the timestamp (e.g. ``14-30``) optionally followed
        by a slugified title (``14-30-sketch-of-flow``). If the file
        already exists, append ``-1``, ``-2``, ... until free.
        """
        candidate = base_slug
        i = 1
        while self._reader.exists(self._note_relpath(date, candidate)):
            candidate = f"{base_slug}-{i}"
            i += 1
            if i > 200:  # paranoid stop
                break
        return candidate

    @staticmethod
    def _is_quick_note(body: str, title: str) -> bool:
        """True iff the note should be written inline as ``- HH:MM — text``
        in the daily journal's ``## Notes`` section instead of split out to
        its own file.

        Heuristic (all must hold): no title, no image embed, no code fence,
        no markdown heading, no list line, no paragraph break, and body
        length within ``_NOTE_QUICK_MAX_CHARS``. The result: short jot-like
        notes render in the Journal tab next to Focus / Mood / Thoughts
        without forcing a separate file for every "decided to postpone"
        capture. Anything richer (images, multi-paragraph, code, lists, or
        a deliberate title) routes through the per-file path that already
        supports the full markdown editor surface.
        """
        if title.strip():
            return False
        text = body.strip()
        if not text or len(text) > _NOTE_QUICK_MAX_CHARS:
            return False
        if any(marker in text for marker in _NOTE_RICH_MARKERS):
            return False
        if _NOTE_HEADING_LINE.search(text):
            return False
        if _NOTE_LIST_LINE.search(text):
            return False
        return True

    def write_note(
        self,
        *,
        body: str,
        title: str | None = None,
        date: str | None = None,
    ) -> dict:
        """Write a note. Quick notes (short text-only) go inline as
        ``- HH:MM — text`` so they appear in the Journal tab next to
        Focus / Mood / Thoughts. Rich notes (images, headings, lists,
        long body, or a title) split out to their own file at
        ``journal/user/notes/{date}/{slug}.md`` with a stub wikilink in
        the daily journal's ``## Notes`` section.

        Routing decided by ``_is_quick_note(body, title)``. Both shapes
        coexist in ``## Notes`` and ``parse_notes`` handles both. The
        ``kind`` field in the result tells the caller which path ran:
        ``"line"`` for inline quick notes, ``"rich"`` for per-file notes.

        Dedup: skips when ``body`` (when present) or ``title`` (when body
        is empty) already appears verbatim in the section AND the dedup
        key is ≥30 chars (shorter notes might legitimately repeat
        single words like "done" / "ok").
        """
        body_text = (body or "").strip()
        title_text = (title or "").strip()

        if not body_text and not title_text:
            raise ValueError("Note must have a title or body")

        # Quick path — short text-only notes write inline so they're
        # immediately visible in the Journal view. Other journal sections
        # (Focus / Mood / Thoughts / Gratitude) already use the same
        # ``- HH:MM — text`` shape; quick notes match it byte for byte.
        if self._is_quick_note(body_text, title_text):
            return self._write_quick_note(body_text, date=date)

        # Resolve target date — per-note file path needs an explicit date
        # string, not just "today's user journal path".
        from agntspace.infra.timezone import local_today
        target_date = date or local_today()

        timestamp = self._timestamp()
        timestamp_slug = timestamp.replace(":", "-")  # "14:30" → "14-30"
        title_slug = self._slugify(title_text)
        base_slug = f"{timestamp_slug}-{title_slug}" if title_slug else timestamp_slug

        # Dedup BEFORE creating a new file. The daily-journal Notes section
        # No dedup gate. User writes are intentional input and are always
        # honored. Earlier versions silently dropped identical bodies as
        # a defense against agent retry-storms, but that policy overrode
        # the user's explicit action — they could type the same note
        # twice and the second write vanished. Restart-storm protection
        # belongs at the agent layer (the caller), not in the journal
        # service. Locked by ``test_user_can_write_identical_notes`` so
        # the dedup layer can't quietly come back.
        daily_path = self._user_path(date) if date else self._user_path()
        if not self._reader.exists(daily_path):
            self._create_user_entry(daily_path)

        # Resolve a non-colliding slug — appends -1, -2 if a same-minute
        # same-title note already exists.
        slug_no_ext = self._resolve_unique_note_slug(target_date, base_slug)
        note_path = self._note_relpath(target_date, slug_no_ext)
        link_path = self._note_link_path(target_date, slug_no_ext)

        # Build per-note file content with frontmatter that mirrors the
        # daily-journal template's shape (date, author, type) so vault
        # tooling can filter notes via standard frontmatter queries.
        # Title in frontmatter is YAML-quoted to defang colons / quotes.
        fm_title = title_text.replace('"', '\\"') if title_text else ""
        note_md = (
            "---\n"
            f'title: "{fm_title}"\n'
            f"date: {target_date}\n"
            f'timestamp: "{timestamp}"\n'
            f"slug: {slug_no_ext}\n"
            "author: user\n"
            "type: note\n"
            "---\n"
            "\n"
            f"{body_text}\n" if body_text else
            "---\n"
            f'title: "{fm_title}"\n'
            f"date: {target_date}\n"
            f'timestamp: "{timestamp}"\n'
            f"slug: {slug_no_ext}\n"
            "author: user\n"
            "type: note\n"
            "---\n"
        )
        self._writer.write(note_path, note_md, trust_reason="journal_write")

        # Insert the stub into the daily-journal ## Notes section. The
        # wikilink uses path-form so it resolves unambiguously in Obsidian
        # and via the loader. Label is the title when set, else "note".
        link_label = title_text or "note"
        stub = f"- {timestamp} — [[{link_path}|{link_label}]]"
        self._append_to_section(
            daily_path, "Notes", stub, trust_reason="journal_write"
        )

        # Index entity references against both title and body — same as the
        # legacy inline-rich path.
        scan_text = "\n".join(filter(None, [title_text, body_text]))
        if scan_text:
            self._index_mentions(note_path, scan_text, "journal_user")

        return {
            "kind": "rich",
            "timestamp": timestamp,
            "title": title_text,
            "body_chars": len(body_text),
            "deduped": False,
            "slug": slug_no_ext,
            "path": note_path,
        }

    def _write_quick_note(self, body_text: str, *, date: str | None) -> dict:
        """Inline-append a quick note to the daily journal's ``## Notes``
        section as ``- HH:MM — text``. Shape matches every other journal
        section (Focus / Mood / Thoughts), so the Journal tab renders it
        directly without stub-link resolution.

        Returns the same dict shape as the rich path with ``kind="line"``,
        ``slug=""`` and ``path=""`` so the caller can react uniformly.
        """
        timestamp = self._timestamp()

        # Ensure target file exists (matches the rich path).
        daily_path = self._user_path(date) if date else self._user_path()
        if not self._reader.exists(daily_path):
            self._create_user_entry(daily_path)

        # No dedup. User input is intentional and is always honored. See
        # ``write_note`` for the architectural rationale — restart-storm
        # protection belongs at the caller, not the journal service.
        line = f"- {timestamp} — {body_text}"
        self._append_to_section(
            daily_path, "Notes", line, trust_reason="journal_write"
        )

        # Index entity references — same as the rich path so wiki backlinks
        # work on quick notes too. Source path is the daily journal file
        # because that's where the quick note actually lives.
        if body_text:
            self._index_mentions(daily_path, body_text, "journal_user")

        return {
            "kind": "line",
            "timestamp": timestamp,
            "title": "",
            "body_chars": len(body_text),
            "deduped": False,
            "slug": "",
            "path": "",
        }

    def get_note_bodies_for_date(self, date: str) -> dict[str, dict]:
        """Resolve every per-note file referenced by the daily journal's
        ``## Notes`` section. Returns ``{slug: {title, body, timestamp}}``.

        Used by the journal-file API to enrich the Journal-tab response so
        the renderer can expand ``[[notes/<date>/<slug>|label]]`` stubs into
        inline content without a second round trip. Skips quick notes
        (``- HH:MM — text`` lines) — they're already inline. Empty dict
        when the daily file or section is missing.
        """
        daily_path = self._user_path(date)
        if not self._reader.exists(daily_path):
            return {}
        doc = self._reader.read(daily_path)
        m = re.search(r"## Notes\b[^\n]*\n(.*?)(?=\n## |\Z)", doc.raw, re.DOTALL)
        if not m:
            return {}
        section_body = m.group(1)
        # Same stub regex shape as ``parse_notes`` so the two stay in sync.
        stub_re = re.compile(
            r"^- (\d{2}:\d{2})\s*—\s*\[\[notes/[^/]+/([a-zA-Z0-9\-]+)(?:\|([^\]]+))?\]\]\s*$",
            re.MULTILINE,
        )
        bodies: dict[str, dict] = {}
        for stub_match in stub_re.finditer(section_body):
            timestamp = stub_match.group(1)
            slug = stub_match.group(2)
            label = (stub_match.group(3) or "").strip()
            note_data = self._read_note_for_parse(date, slug)
            if note_data is None:
                continue
            fm_title, body_text = note_data
            # Stub label is more authoritative than frontmatter title (label
            # is what the user typed; frontmatter title may be empty for
            # body-only notes). "note" is the placeholder used when neither
            # is set, so treat it as empty.
            effective_title = label if label and label != "note" else fm_title
            bodies[slug] = {
                "title": effective_title,
                "body": body_text,
                "timestamp": timestamp,
            }
        return bodies

    def parse_notes(self, date: str | None = None) -> list[dict]:
        """Parse the ``## Notes`` section of a day's user journal into a
        list of note dicts, newest-first.

        Handles THREE shapes that coexist in the section:

          ``- HH:MM — text``                                (kind: "line")
          ``- HH:MM — [[notes/<date>/<slug>|<label>]]``     (kind: "rich" — body
                                                             loaded from per-note
                                                             file at notes/<date>/
                                                             <slug>.md, the
                                                             post-2026-05-04 shape)
          ``### HH:MM — Title\\n\\nBody...``                (legacy inline rich
                                                             block; kind: "rich")

        Returns ``[{"kind", "timestamp", "title", "body", "raw", "slug"}, ...]``
        where ``title`` is ``""`` for ``line`` shapes (the text after the
        em-dash carries everything) and for rich shapes that lacked a
        title; ``slug`` is set for stub-linked rich notes (so the UI can
        deep-link directly to the per-note file) and empty for legacy
        inline blocks. Returns ``[]`` when the file or section doesn't exist.
        """
        path = self._user_path(date) if date else self._user_path()
        if not self._reader.exists(path):
            return []

        doc = self._reader.read(path)
        # Capture the full Notes section (header + body up to next ## or EOF)
        match = re.search(r"## Notes\b[^\n]*\n(.*?)(?=\n## |\Z)", doc.raw, re.DOTALL)
        if not match:
            return []
        body = match.group(1)

        # Strip the italic hint line (e.g. "*Quick captures...*") if present.
        body = re.sub(r"^\*[^*]+\*\s*$", "", body, flags=re.MULTILINE).strip()
        if not body:
            return []

        notes: list[dict] = []
        rich_re = re.compile(r"^### (\d{2}:\d{2})(?:\s*—\s*(.+))?\s*$")
        # Stub-link shape: ``- HH:MM — [[notes/<date>/<slug>|<label>]]``
        # The label is what the user sees as the title; if missing, the
        # bare wikilink form ``[[notes/<date>/<slug>]]`` is also accepted.
        stub_re = re.compile(
            r"^- (\d{2}:\d{2})\s*—\s*\[\[notes/[^/]+/([a-zA-Z0-9\-]+)(?:\|([^\]]+))?\]\]\s*$"
        )
        line_re = re.compile(r"^- (\d{2}:\d{2})\s*—\s*(.+)$")

        current: dict | None = None
        body_lines: list[str] = []

        def flush_current() -> None:
            if current is None:
                return
            current["body"] = "\n".join(body_lines).strip()
            current["raw"] = f"### {current['timestamp']}" + (
                f" — {current['title']}" if current["title"] else ""
            ) + ("\n" + current["body"] if current["body"] else "")
            notes.append(current)

        for raw_line in body.splitlines():
            stripped = raw_line.strip()
            rich_m = rich_re.match(stripped)
            stub_m = stub_re.match(stripped)
            line_m = line_re.match(stripped) if not stub_m else None

            if rich_m:
                flush_current()
                current = {
                    "kind": "rich",
                    "timestamp": rich_m.group(1),
                    "title": (rich_m.group(2) or "").strip(),
                    "slug": "",
                }
                body_lines = []
            elif stub_m:
                # Per-note file shape — load body from the linked file.
                flush_current()
                current = None
                timestamp = stub_m.group(1)
                slug = stub_m.group(2)
                label = (stub_m.group(3) or "").strip()
                note_data = self._read_note_for_parse(date, slug)
                if note_data is None:
                    # File missing or unreadable — surface as a rich note
                    # with empty body so the user sees something rather
                    # than dropping the entry silently.
                    notes.append({
                        "kind": "rich",
                        "timestamp": timestamp,
                        "title": label if label != "note" else "",
                        "body": "",
                        "raw": raw_line,
                        "slug": slug,
                    })
                    continue
                title_text, body_text = note_data
                # The stub label is more authoritative than frontmatter
                # title (label is what the user wrote when sending; the
                # frontmatter title may be empty for body-only notes).
                effective_title = label if label and label != "note" else title_text
                notes.append({
                    "kind": "rich",
                    "timestamp": timestamp,
                    "title": effective_title,
                    "body": body_text,
                    "raw": raw_line,
                    "slug": slug,
                })
            elif line_m:
                flush_current()
                current = None
                notes.append({
                    "kind": "line",
                    "timestamp": line_m.group(1),
                    "title": "",
                    "body": line_m.group(2).strip(),
                    "raw": raw_line,
                    "slug": "",
                })
            elif current is not None:
                body_lines.append(raw_line)
            # else: pre-first-heading content that isn't a one-liner —
            # discard (matches the existing-section hint-line tolerance)

        flush_current()

        # File order = chronological insertion order (notes are appended
        # at end of section). Newest-first for the feed view = reversed
        # file order. Stable across same-minute timestamps.
        notes.reverse()
        return notes

    def _read_note_for_parse(
        self, date: str | None, slug: str
    ) -> tuple[str, str] | None:
        """Read a per-note file and return (title, body). None on miss.

        Used by ``parse_notes`` to load body content for stub-linked
        notes. ``date`` is the journal-day date the parse was scoped to;
        when ``None``, fall through to today.
        """
        from agntspace.infra.timezone import local_today
        target_date = date or local_today()
        relpath = self._note_relpath(target_date, slug)
        if not self._reader.exists(relpath):
            return None
        try:
            note_doc = self._reader.read(relpath)
        except Exception:  # noqa: BLE001
            return None
        title_text = str(note_doc.metadata.get("title", "") or "").strip()
        body_text = (note_doc.content or "").strip()
        return title_text, body_text

    def read_note(self, date: str, slug: str) -> dict | None:
        """Read a single per-note file. Returns None when not found.

        Returns ``{date, slug, timestamp, title, body, path}`` ready for
        a JSON response. Used by the ``GET /api/journal/note/{date}/{slug}``
        endpoint that powers the NoteReader UI.
        """
        relpath = self._note_relpath(date, slug)
        if not self._reader.exists(relpath):
            return None
        try:
            doc = self._reader.read(relpath)
        except Exception:  # noqa: BLE001
            return None
        meta = doc.metadata or {}
        return {
            "date": date,
            "slug": slug,
            "timestamp": str(meta.get("timestamp", "") or ""),
            "title": str(meta.get("title", "") or "").strip(),
            "body": (doc.content or "").strip(),
            "path": relpath,
        }

    def inventory(self, date: str) -> dict:
        """Build a sidebar-ready inventory of everything on a date.

        Returns ``{date, file_types, notes}`` where:

          * ``file_types`` is the list of journal file_type keys that
            actually exist for the date (``journal``, ``briefing``,
            ``observations``, ``eod``, ``reflection``,
            ``weekly_reflection`` — driven by ``self._file_types`` so
            new types ship for free).
          * ``notes`` is the list of per-note files for the date, each
            with ``{slug, title, timestamp, has_images, body_chars}``
            so the sidebar can render label + image badge without a
            second fetch.

        Lightweight by design — used to lazy-populate the date-folder
        children when the user expands a row in the sidebar. Returns
        empty arrays (not 404) when nothing exists, so the UI can
        render "no entries yet" instead of erroring out.
        """
        result: dict = {"date": date, "file_types": [], "notes": []}

        # File types — walk the configured map and check for the
        # corresponding file's existence on disk.
        # weekly_reflection files use an ISO-week label (``2026-W20``) but
        # the inventory is keyed by YYYY-MM-DD; convert to the week label
        # for that one file_type so the Weekly tab surfaces on the Sunday
        # entry. See ``list_dates`` + ``get_file_for_date`` for the
        # matching write+read sides of the same convention.
        week_token: str | None = None
        try:
            parsed = _date_cls.fromisoformat(date)
            iso_year, iso_week, _ = parsed.isocalendar()
            week_token = f"{iso_year}-W{iso_week:02d}"
        except ValueError:
            week_token = None
        for ft_key, ft_info in self._file_types.items():
            ft_dir = ft_info.get("dir", "agnt")
            prefix = ft_info["prefix"]
            base_dir = self._USER_DIR if ft_dir == "user" else self._AGNT_DIR
            file_token = date
            if ft_key == "weekly_reflection" and week_token is not None and "W" not in date:
                file_token = week_token
            relpath = f"{base_dir}/{prefix}{file_token}.md"
            if self._reader.exists(relpath):
                result["file_types"].append({"type": ft_key})

        # Per-note files — walk notes/<date>/ and pull metadata from
        # each file's frontmatter.
        notes_dir = f"{self._USER_DIR}/notes/{date}"
        try:
            files = self._reader.list_files(notes_dir, "*.md")
        except Exception:  # noqa: BLE001
            files = []
        notes_meta: list[dict] = []
        for f in files:
            relpath = f"{notes_dir}/{f.name}"
            try:
                doc = self._reader.read(relpath)
            except Exception:  # noqa: BLE001
                continue
            meta = doc.metadata or {}
            slug = str(meta.get("slug", "") or f.stem).strip()
            title = str(meta.get("title", "") or "").strip()
            timestamp = str(meta.get("timestamp", "") or "").strip()
            body = doc.content or ""
            has_images = bool(re.search(r"!\[[^\]]*\]\([^)]+\)", body))
            notes_meta.append({
                "slug": slug,
                "title": title,
                "timestamp": timestamp,
                "has_images": has_images,
                "body_chars": len(body.strip()),
            })
        # Newest-first by timestamp (string compare on HH:MM is correct
        # within a single day — the inventory is scoped to one date).
        notes_meta.sort(key=lambda n: n.get("timestamp", ""), reverse=True)
        result["notes"] = notes_meta
        return result

    def update_note(
        self,
        date: str,
        slug: str,
        *,
        title: str | None = None,
        body: str | None = None,
    ) -> dict | None:
        """Update an existing per-note file's title and/or body.

        Both ``title`` and ``body`` are optional:

          * ``None`` → leave the existing value untouched.
          * ``""`` → explicit clear (title becomes empty / body becomes empty).
          * non-empty string → replace.

        At least one of body or title must be present after the update —
        a note can't have both title and body empty (mirrors ``write_note``).
        Raises ``ValueError`` on that constraint violation.

        When the title changes, the daily-journal stub link's label is
        rewritten to match (slug stays stable so the file path doesn't
        churn). When the title becomes empty, the label falls back to
        ``"note"``.

        Returns the updated note dict (same shape as ``read_note``) or
        ``None`` if the note doesn't exist.

        Empty new-state guard: rejecting BOTH-empty matches write_note
        semantics; the user can't accidentally erase a note via update.
        Use a separate delete endpoint for that.
        """
        relpath = self._note_relpath(date, slug)
        if not self._reader.exists(relpath):
            return None
        existing_doc = self._reader.read(relpath)
        existing_meta = existing_doc.metadata or {}
        existing_title = str(existing_meta.get("title", "") or "").strip()
        existing_body = (existing_doc.content or "").strip()

        new_title = existing_title if title is None else (title or "").strip()
        new_body = existing_body if body is None else (body or "").strip()
        if not new_title and not new_body:
            raise ValueError("Note must have a title or body")

        if new_title == existing_title and new_body == existing_body:
            # No-op update — return current state without touching disk.
            return self.read_note(date, slug)

        # Rewrite the per-note file with the new title + body, preserving
        # the rest of the frontmatter (timestamp, date, slug, author, type).
        timestamp = str(existing_meta.get("timestamp", "") or "")
        fm_title = new_title.replace('"', '\\"')
        note_md = (
            "---\n"
            f'title: "{fm_title}"\n'
            f"date: {date}\n"
            f'timestamp: "{timestamp}"\n'
            f"slug: {slug}\n"
            "author: user\n"
            "type: note\n"
            "---\n"
            "\n"
            f"{new_body}\n"
        ) if new_body else (
            "---\n"
            f'title: "{fm_title}"\n'
            f"date: {date}\n"
            f'timestamp: "{timestamp}"\n'
            f"slug: {slug}\n"
            "author: user\n"
            "type: note\n"
            "---\n"
        )
        self._writer.write(relpath, note_md, trust_reason="journal_write")

        # Re-fire the mention indexer with the new content. The indexer
        # dedupes by (entity_slug, source_path) so updating in place
        # naturally replaces stale references.
        scan_text = "\n".join(filter(None, [new_title, new_body]))
        if scan_text:
            self._index_mentions(relpath, scan_text, "journal_user")

        # Rewrite the daily-journal stub label if the title changed.
        if new_title != existing_title:
            self._relabel_note_stub(date, slug, new_title)

        return self.read_note(date, slug)

    def _relabel_note_stub(self, date: str, slug: str, new_title: str) -> None:
        """Update the daily-journal stub-link label for a renamed note.

        The slug stays stable (file path doesn't change); only the
        wikilink display label flips. ``[[notes/.../slug|old]]`` →
        ``[[notes/.../slug|new]]``. When ``new_title`` is empty, the
        label falls back to ``note``.
        """
        daily_path = self._user_path(date)
        if not self._reader.exists(daily_path):
            return
        doc = self._reader.read(daily_path)
        link_path = self._note_link_path(date, slug)
        new_label = new_title or "note"

        # Match the stub line with any existing label and replace just
        # the label segment. ``re.escape`` on the path defangs slashes.
        pattern = re.compile(
            rf"(\[\[{re.escape(link_path)}\|)[^\]]*(\]\])"
        )
        new_content, n = pattern.subn(rf"\g<1>{new_label}\g<2>", doc.raw)
        if n > 0 and new_content != doc.raw:
            self._writer.write(daily_path, new_content, trust_reason="journal_write")

    def _append_note_block(self, path: str, block: str, *, dedup_key: str = "") -> bool:
        """Insert a multi-line note block into the Notes section.

        Always appends — no dedup. ``dedup_key`` kwarg kept for caller
        signature compatibility; ignored. If the Notes section is missing
        entirely (vault edited by hand to remove it), append a new
        section at end of file rather than failing. Returns True on
        success.
        """
        _ = dedup_key  # accepted for back-compat; unused (no dedup)
        doc = self._reader.read(path)
        content = doc.raw

        pattern = r"(## Notes\b.*?)(\n## |\Z)"
        match = re.search(pattern, content, re.DOTALL)
        if not match:
            self._writer.write(
                path,
                content + f"\n## Notes\n{block}\n",
                trust_reason="journal_write",
            )
            return True

        section_end = match.end(1)
        new_content = content[:section_end] + block + content[section_end:]
        self._writer.write(path, new_content, trust_reason="journal_write")
        return True

    def append_question(self, text: str) -> None:
        self.append_to_user("Questions", text)

    def append_decision(self, text: str) -> None:
        self.append_to_user("Decisions", text)

    def append_learning(self, text: str) -> None:
        self.append_to_user("Learnings", text)

    def append_blocker(self, text: str) -> None:
        self.append_to_user("Blockers", text)

    def append_reflection(self, text: str) -> None:
        self.append_to_user("Reflections", text)

    # ---- Agent writes (to agent observations file) ----

    def append_observation(self, text: str) -> None:
        """Append an agent observation to today's agent file."""
        self._append_to_agent_section(
            "Observations",
            f"- {self._timestamp()} — {text}",
        )

    def append_action(self, text: str) -> None:
        """Append an agent action to today's agent file."""
        self._append_to_agent_section(
            "Actions",
            f"- {self._timestamp()} — {text}",
        )

    def append_agent_note(self, text: str) -> None:
        """Append an agent note to today's agent file."""
        self._append_to_agent_section(
            "Notes",
            f"- {self._timestamp()} — {text}",
        )

    # ---- Internal ----

    def _append_to_user_section(self, section: str, line: str) -> None:
        """Append a line to a section of today's user journal."""
        path = self._user_path()
        if not self._reader.exists(path):
            self._create_user_entry(path)
        self._append_to_section(path, section, line, trust_reason="journal_write")
        self._index_mentions(path, line, "journal_user")

    def _append_to_agent_section(self, section: str, line: str) -> None:
        """Append a line to a section of today's agent observations."""
        path = self._agent_path()
        if not self._reader.exists(path):
            self._create_agent_entry(path)
        self._append_to_section(path, section, line, trust_reason="agent_journal_write")
        self._index_mentions(path, line, "journal_agent")

    def _index_mentions(self, path: str, text: str, context_type: str) -> None:
        """Scan the appended line for entity references and emit
        ``references`` triples. No-op when the indexer isn't wired.
        Never raises — broken indexer never breaks the journal write."""
        indexer = self._mention_indexer
        if indexer is None:
            return
        try:
            indexer.index(text, source_path=path, context_type=context_type)
        except Exception:  # noqa: BLE001
            log.debug("MentionIndexer failed for %s", path, exc_info=True)

    def _append_to_section(self, path: str, section: str, line: str, *, trust_reason: str = "journal_write") -> bool:
        """Append a line to a specific section of a file.

        Dedup: extracts the text after the timestamp+author tag and skips
        if that same text already appears in the section (prevents
        duplicate entries from restarts / repeated tool calls).

        Returns True when the line was appended, False when dedup
        suppressed it. Existing callers that ignored the return value are
        unaffected — adding the return is purely additive.
        """
        doc = self._reader.read(path)
        content = doc.raw

        # Find the section and append before the next section or end.
        # No dedup. The journal is the user's record of intent — typing
        # the same note twice records two events. Restart-storm
        # protection (the original justification for dedup) is a
        # caller-layer concern, not a write-layer concern.
        pattern = rf"(## {re.escape(section)}\b.*?)(\n## |\Z)"
        match = re.search(pattern, content, re.DOTALL)
        if match:
            section_end = match.end(1)
            new_content = content[:section_end] + "\n" + line + content[section_end:]
            self._writer.write(path, new_content, trust_reason=trust_reason)
            return True
        self._writer.write(path, content + f"\n## {section}\n{line}\n", trust_reason=trust_reason)
        return True

    def _create_user_entry(self, path: str) -> None:
        journal_prefix = self._file_types.get("journal", _FALLBACK_FILE_TYPES["journal"])["prefix"]
        date = Path(path).stem.replace(journal_prefix.rstrip("_"), "").lstrip("_")
        content = _build_template(
            date, self._user_sections,
            "journal.user_title", "journal.user_description",
            "user",
        )
        self._writer.write(path, content, trust_reason="journal_create")

    def _create_agent_entry(self, path: str) -> None:
        date = path.split("_")[-1].replace(".md", "")
        content = _build_template(
            date, self._agent_sections,
            "journal.agent_title", "journal.agent_description",
            "agent",
            extra_fm={"type": "agent_observations", "agent": "main"},
        )
        self._writer.write(path, content, trust_reason="agent_journal_create")

    def _timestamp(self) -> str:
        from agntspace.infra.timezone import now_local
        return now_local().strftime(self._timestamp_format)

    @staticmethod
    def is_thinking_out_loud(text: str, vault_dir: Path | None = None) -> bool:
        """Detect if a user message sounds like thinking out loud.

        Phrase markers are loaded from the ``memory-consolidate`` skill's
        multilingual ``thinking-out-loud.yaml`` so the classifier works in
        any user language without hardcoded English regex.
        """
        from agntspace.infra.language_patterns import load_keywords

        if not text:
            return False

        # Normalize: lowercase, expand common contractions, strip punctuation.
        lower = text.lower().strip()
        lower = (
            lower.replace("'m ", " am ")
            .replace("'ve ", " have ")
            .replace("'re ", " are ")
            .replace("'s ", " is ")
        )
        # Collapse "i am" / "i have" / "i've" etc. down to "i " so YAML
        # phrases like "i thinking" match "i am thinking" and "i'm thinking".
        collapsed = re.sub(r"\bi\s+(am|have|had|was|will|would)\s+", "i ", lower)

        phrases = load_keywords(
            "core/memory-consolidate/config/thinking-out-loud.yaml",
            vault_dir=vault_dir,
        )
        if not phrases:
            return False
        return any(collapsed.startswith(p) or lower.startswith(p) for p in phrases)
