"""SearXNG search client — local-first DDG alternative.

P5.6 (2026-05-17) — closes the "research without ANY external dependency"
gap left by P5.3. The P5.3 local fallback still hit DDG for search; users
who self-host SearXNG can now point research at their own instance and
keep the entire pipeline (search → scrape → synthesize) inside their
network perimeter.

Architectural commitments (locked):

1.  **DDG-compatible result shape.** Returns the same dict shape DDG's
    ``ddgs.DDGS().text(topic, max_results)`` produces: a list of
    ``{title, href, body}`` entries. This means every downstream consumer
    (quality gate, relevance check, scraper, citation builder) keeps
    working unchanged. Only the search source changes — not the contract.

2.  **Stateless client.** Same pattern as
    ``agntspace.integrations.perplexity``: one client instance shared
    across the process; recreate when the user changes the base URL.
    No caching, no retry-state, no session pinning.

3.  **Fail-open at every error.** Every public method returns a list
    (possibly empty) rather than raising. The caller branches on
    ``len(results) == 0`` exactly the same way it would for an empty
    DDG response. A misconfigured SearXNG NEVER breaks the research
    pipeline — the local-fallback orchestrator's "no_results" branch
    handles it cleanly.

4.  **HTTP-level retry on transient failures.** Same backoff schedule
    as Perplexity (1s, 3s, 8s) on 429 + 5xx. SearXNG instances are
    often resource-constrained (single-user homelabs); transient
    rate limiting is the norm, not an emergency.

5.  **JSON format only.** SearXNG supports JSON output via
    ``?format=json``. The HTML form would need a parser; the JSON
    form gives us structured results directly. Instances that have
    disabled JSON (some default configs) return HTML; we detect
    that and fail open with an empty list.

6.  **No API key.** SearXNG is unauthenticated by design (it's a
    metasearch frontend). The only required configuration is
    ``base_url``. Users behind a basic-auth reverse proxy can put
    credentials in the URL itself (``https://user:pass@host/``);
    httpx supports that natively.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

import httpx

log = logging.getLogger(__name__)

# arch:deterministic — exponential backoff schedule matching perplexity.py
_RETRY_DELAYS: tuple[float, ...] = (1.0, 3.0, 8.0)
# arch:deterministic — transient HTTP error class shared with perplexity
_RETRY_STATUS_CODES: frozenset[int] = frozenset({429, 500, 502, 503, 504})
# arch:deterministic — total request timeout. SearXNG meta-searches can take
# 5-10s when a backend (Google, Bing) is slow; 30s is the documented
# ceiling for the JSON endpoint.
_REQUEST_TIMEOUT_SECONDS: float = 30.0
# arch:deterministic — User-Agent header. Some SearXNG instances block
# default httpx UA strings as bot traffic; identifying ourselves as
# "agntspace-research" makes the access pattern visible in the
# instance's logs.
_USER_AGENT: str = "agntspace-research-searxng/1.0"


@dataclass(frozen=True)
class SearXNGResult:
    """A single search result. Internal — converted to dict at boundary."""

    title: str
    url: str
    body: str


def _normalize_base_url(raw: str) -> str:
    """Strip trailing slash + path so we can append ``/search`` cleanly.

    SearXNG instances are typically served at a path like
    ``https://search.example.com/`` or behind a reverse proxy at
    ``https://example.com/searxng/``. We append ``/search`` to whatever
    the user gave us (after stripping one trailing slash) so both
    layouts work.
    """
    if not isinstance(raw, str):
        return ""
    s = raw.strip()
    if not s:
        return ""
    # Drop trailing slash so concatenation doesn't double-slash.
    if s.endswith("/"):
        s = s[:-1]
    return s


def _is_valid_base_url(raw: str) -> bool:
    """Pure helper — check that a URL looks like an http(s) endpoint."""
    if not isinstance(raw, str) or not raw.strip():
        return False
    try:
        parsed = urlparse(raw.strip())
    except Exception:  # noqa: BLE001
        return False
    return parsed.scheme in ("http", "https") and bool(parsed.netloc)


def _coerce_results(payload: Any, max_results: int) -> list[dict]:
    """Convert a SearXNG JSON payload into DDG-compatible dict list.

    SearXNG JSON shape:
        {"query": "...", "results": [{"title": "...", "url": "...",
                                       "content": "...", ...}], ...}

    Maps to:
        [{"title": "...", "href": "...", "body": "..."}]

    Returns an empty list on any malformed input — fail-open at the
    boundary so the caller sees the same shape as "no results found".

    Caps at ``max_results`` regardless of how many entries SearXNG
    returned (some instances ignore the &count= parameter).
    """
    if not isinstance(payload, dict):
        return []
    raw_results = payload.get("results")
    if not isinstance(raw_results, list):
        return []
    out: list[dict] = []
    for entry in raw_results:
        if not isinstance(entry, dict):
            continue
        title = entry.get("title", "")
        url = entry.get("url", "")
        body = entry.get("content", "") or entry.get("body", "")
        if not isinstance(title, str) or not isinstance(url, str):
            continue
        if not url.strip():
            continue
        if not isinstance(body, str):
            body = ""
        out.append({
            "title": title.strip(),
            "href": url.strip(),
            "body": body.strip(),
        })
        if len(out) >= max_results:
            break
    return out


class SearXNGClient:
    """Async client for a self-hosted SearXNG instance.

    Construct once at lifespan (or when the user updates the base URL
    in Settings) and share across the process. Stateless — each call
    is a fresh HTTP request. ``configured`` flag mirrors the
    PerplexityClient pattern so callers can `if not client.configured:
    fall_back()` uniformly.
    """

    def __init__(
        self,
        base_url: str = "",
        *,
        client_override: httpx.AsyncClient | None = None,
    ) -> None:
        normalized = _normalize_base_url(base_url)
        # ``configured`` mirrors PerplexityClient's surface: callers
        # check this flag before assuming the integration is live.
        self.base_url: str = normalized if _is_valid_base_url(normalized) else ""
        self.configured: bool = bool(self.base_url)
        # Allow test injection of a pre-configured httpx client (e.g.
        # one with httpx.MockTransport). Production callers never pass
        # this — the lazy AsyncClient inside ``_get_client`` is the
        # canonical path.
        self._client_override: httpx.AsyncClient | None = client_override
        # The lazy client is constructed on first use because httpx
        # AsyncClient construction requires an event loop AND we don't
        # want to spin one up just to instantiate the integration.
        self._client: httpx.AsyncClient | None = None
        self._client_lock = asyncio.Lock()

    async def _get_client(self) -> httpx.AsyncClient:
        """Lazy-construct + cache the httpx.AsyncClient."""
        if self._client_override is not None:
            return self._client_override
        if self._client is not None:
            return self._client
        async with self._client_lock:
            if self._client is None:
                self._client = httpx.AsyncClient(
                    timeout=_REQUEST_TIMEOUT_SECONDS,
                    headers={"User-Agent": _USER_AGENT},
                )
        return self._client

    async def close(self) -> None:
        """Close the underlying httpx client. Safe to call multiple times."""
        if self._client_override is not None:
            return  # caller owns the override
        if self._client is None:
            return
        try:
            await self._client.aclose()
        except Exception:  # noqa: BLE001 — close-time errors are non-fatal
            pass
        self._client = None

    async def text(self, query: str, max_results: int = 10) -> list[dict]:
        """Run a text search. Returns DDG-compatible result dicts.

        Fail-open at every step: malformed payload, HTTP error, JSON
        decode failure, configured=False all return an empty list. The
        caller branches on ``len(results) == 0`` exactly like the
        no-results path on DDG.

        Retries 1s/3s/8s on 429 + 5xx (same schedule as PerplexityClient).
        Non-retryable errors (4xx other than 429, network exceptions
        on the final attempt) fall through to an empty list.
        """
        if not self.configured:
            return []
        if not isinstance(query, str) or not query.strip():
            return []
        if not isinstance(max_results, int) or max_results < 1:
            max_results = 10

        url = f"{self.base_url}/search"
        params = {
            "q": query,
            "format": "json",
            # SearXNG's count parameter is a hint — some instances ignore
            # it. We cap server-side AND client-side via _coerce_results.
            "count": str(max_results),
        }

        client = await self._get_client()
        last_status: int | None = None
        last_error: str = ""

        for attempt, delay in enumerate((0.0,) + _RETRY_DELAYS):
            if delay > 0.0:
                await asyncio.sleep(delay)
            try:
                resp = await client.get(url, params=params)
            except Exception as exc:  # noqa: BLE001 — network errors fail-open
                last_error = f"{type(exc).__name__}: {exc}"
                log.debug(
                    "SearXNG request raised (attempt %d): %s",
                    attempt + 1, last_error,
                )
                # Retry on network errors too
                continue

            last_status = resp.status_code
            if resp.status_code in _RETRY_STATUS_CODES:
                log.debug(
                    "SearXNG retryable status %d (attempt %d)",
                    resp.status_code, attempt + 1,
                )
                continue
            if resp.status_code >= 400:
                log.debug(
                    "SearXNG non-retryable status %d (attempt %d)",
                    resp.status_code, attempt + 1,
                )
                return []

            # 2xx — try to parse JSON. Some instances return HTML when
            # JSON is disabled in their config; detect that and fail open.
            content_type = resp.headers.get("content-type", "").lower()
            if "json" not in content_type:
                log.debug(
                    "SearXNG returned non-JSON content-type %r — instance "
                    "may have JSON disabled. Falling back to empty results.",
                    content_type,
                )
                return []
            try:
                payload = resp.json()
            except Exception as exc:  # noqa: BLE001 — JSON parse fail-open
                last_error = f"{type(exc).__name__}: {exc}"
                log.debug("SearXNG JSON parse failed: %s", last_error)
                return []
            return _coerce_results(payload, max_results)

        # All retries exhausted — return empty
        log.info(
            "SearXNG exhausted retries (final status=%s, error=%s)",
            last_status, last_error or "(none)",
        )
        return []
