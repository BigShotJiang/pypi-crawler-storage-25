"""Bootstrap a Frisky cluster inside an existing Dask cluster.

Usage:

    from dask.distributed import LocalCluster, Client as DaskClient
    import frisky

    with LocalCluster() as dc:
        with DaskClient(dc) as dask_client:
            frisky_client = frisky.hijack(dask_client)
            assert frisky_client.submit(lambda: 10).result() == 10

The Frisky scheduler runs inside the Dask scheduler process; one Frisky
worker runs inside each Dask worker process. The Frisky scheduler address
is stored on the Dask scheduler as `frisky_address` so workers (and the
returned client) can connect.

The Frisky dashboard is also mounted on the Dask scheduler's HTTP server,
replacing the Dask dashboard at `/`. This means the existing Dask dashboard
URL (e.g. `http://host:8787/`) now serves the Frisky dashboard. The
underlying Dask dashboard pages (`/status`, `/workers`, ...) and operational
endpoints (`/metrics`, `/health`, `/json/identity.json`, ...) remain reachable
at their original paths — see `install_dashboard_proxy` for the exact claimed
route list.
"""
from urllib.parse import urlparse

import tornado.httpclient
import tornado.ioloop
import tornado.web
import tornado.websocket
from distributed.diagnostics.plugin import SchedulerPlugin, WorkerPlugin

from frisky.frisky import Client, Scheduler, Worker


class FriskySchedulerPlugin(SchedulerPlugin):
    name = "frisky-scheduler"
    idempotent = True

    def start(self, scheduler):
        self._dask_scheduler = scheduler
        # Bind to 0.0.0.0 so remote workers (different EC2 instances on Coiled
        # etc.) can connect. Advertise the dask scheduler's host as the address
        # workers/clients dial. For LocalCluster this is 127.0.0.1; for a real
        # cluster it's the head node's VPC-internal IP.
        self.scheduler = Scheduler(
            "0.0.0.0:0",
            dashboard=True,
            dashboard_address="127.0.0.1:0",
        )
        bound_port = self.scheduler.address.rsplit(":", 1)[1]
        dask_host = urlparse(scheduler.address).hostname or "127.0.0.1"
        scheduler.frisky_address = f"{dask_host}:{bound_port}"
        if self.scheduler.dashboard_address:
            scheduler.frisky_dashboard = self.scheduler.dashboard_address
            install_dashboard_proxy(scheduler, self.scheduler.dashboard_address)

    async def close(self):
        # Point the proxy at no upstream BEFORE shutting Frisky down, so any
        # in-flight requests get a clean 503 instead of a confusing ConnectionRefused.
        s = getattr(self, "_dask_scheduler", None)
        if s is not None:
            getattr(s, "_frisky_proxy_state", {}).pop("upstream", None)
        self.scheduler.close()


class FriskyWorkerPlugin(WorkerPlugin):
    name = "frisky-worker"
    idempotent = True

    def __init__(self, scheduler_address):
        self.scheduler_address = scheduler_address

    def setup(self, worker):
        self.worker = Worker(
            self.scheduler_address,
            nthreads=worker.state.nthreads,
            memory_limit=worker.memory_manager.memory_limit,
        )

    def teardown(self, worker):
        self.worker.close()


def hijack(dask_client, connect_client=True):
    """Bootstrap a Frisky cluster on a running Dask cluster and return a Frisky Client.

    Parameters
    ----------
    dask_client:
        A connected ``distributed.Client``.
    connect_client:
        If ``True`` (default), construct and return a ``frisky.Client``
        bound to the Frisky scheduler. On clusters where the calling
        machine can't reach the Frisky scheduler directly (e.g. Coiled,
        where the scheduler binds to a VPC-internal address), set this
        to ``False`` to avoid a ~75 s TCP-retry hang; the function then
        returns ``None`` and the caller can submit work via
        ``dask_client.run_on_scheduler`` instead.
    """
    dask_client.register_plugin(FriskySchedulerPlugin())
    frisky_address = dask_client.run_on_scheduler(
        lambda dask_scheduler: dask_scheduler.frisky_address
    )
    dask_client.register_plugin(FriskyWorkerPlugin(frisky_address))
    if connect_client:
        return Client(frisky_address)
    return None


# ---------------------------------------------------------------------------
# Dashboard proxy
# ---------------------------------------------------------------------------
#
# Frisky's scheduler runs its own dashboard HTTP server on a random local port.
# We install Tornado handlers on the Dask scheduler's http_application so that
# requests to the Dask dashboard port are reverse-proxied to Frisky.
#
# Top-level routes added via `add_handlers` take priority over the BokehApplication
# routes that Dask's dashboard installs (see distributed.http.routing.RoutingApplication).
# That lets us claim `/` for Frisky while leaving Dask's `/status`, `/workers`, etc.
# reachable at their original paths.


# Hop-by-hop headers (RFC 7230 6.1) plus content-encoding/length.
# We strip content-encoding because tornado's AsyncHTTPClient decompresses
# the body by default — forwarding the original encoding would cause double
# decompression in the browser.
_DROP_HEADERS = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailers", "transfer-encoding", "upgrade", "host",
    "content-length", "content-encoding",
}


class _HTTPProxy(tornado.web.RequestHandler):
    """Forward HTTP requests to an upstream URL, preserving method/body/headers."""

    SUPPORTED_METHODS = ("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS")

    def initialize(self, state):
        # `state` is a dict shared with install_dashboard_proxy; "upstream" is
        # either the upstream base URL (e.g. "http://127.0.0.1:54321") or None
        # when the Frisky scheduler is shutting down.
        self._state = state

    async def _forward(self):
        upstream = self._state.get("upstream")
        if upstream is None:
            self.set_status(503)
            self.write("Frisky dashboard not available")
            return
        url = upstream + self.request.uri
        headers = {k: v for k, v in self.request.headers.items()
                   if k.lower() not in _DROP_HEADERS}
        body = self.request.body if self.request.method in ("POST", "PUT", "PATCH") else None
        client = tornado.httpclient.AsyncHTTPClient()
        try:
            resp = await client.fetch(
                url,
                method=self.request.method,
                headers=headers,
                body=body,
                allow_nonstandard_methods=True,
                follow_redirects=False,
                raise_error=False,
                request_timeout=30,
            )
        except Exception as e:
            self.set_status(502)
            self.write(f"Bad gateway: {e}")
            return
        self.set_status(resp.code)
        for header, value in resp.headers.get_all():
            if header.lower() in _DROP_HEADERS:
                continue
            self.set_header(header, value)
        if resp.body:
            self.write(resp.body)

    async def get(self, *args, **kwargs):    await self._forward()
    async def post(self, *args, **kwargs):   await self._forward()
    async def put(self, *args, **kwargs):    await self._forward()
    async def delete(self, *args, **kwargs): await self._forward()
    async def patch(self, *args, **kwargs):  await self._forward()
    async def head(self, *args, **kwargs):   await self._forward()
    async def options(self, *args, **kwargs): await self._forward()


class _WebSocketProxy(tornado.websocket.WebSocketHandler):
    """Bidirectional WebSocket reverse proxy."""

    def initialize(self, state):
        self._state = state
        self._upstream = None

    def check_origin(self, origin):
        # Browser already connected to the Dask dashboard; trust that origin.
        return True

    async def open(self):
        upstream_ws = self._state.get("ws_upstream")
        if upstream_ws is None:
            self.close(code=1011, reason="frisky dashboard not available")
            return
        try:
            self._upstream = await tornado.websocket.websocket_connect(upstream_ws)
        except Exception:
            self.close(code=1011, reason="upstream connect failed")
            return
        tornado.ioloop.IOLoop.current().spawn_callback(self._pump_from_upstream)

    async def _pump_from_upstream(self):
        try:
            while True:
                msg = await self._upstream.read_message()
                if msg is None:
                    break
                await self.write_message(msg, binary=isinstance(msg, (bytes, bytearray)))
        except Exception:
            pass
        finally:
            self.close()

    async def on_message(self, message):
        # NB: must be async — write_message returns a coroutine on
        # WebSocketClientConnection; a sync handler would silently drop frames.
        if self._upstream is not None:
            await self._upstream.write_message(
                message, binary=isinstance(message, (bytes, bytearray))
            )

    def on_close(self):
        if self._upstream is not None:
            self._upstream.close()
            self._upstream = None


def install_dashboard_proxy(dask_scheduler, frisky_dashboard_url):
    """Mount a reverse proxy to the Frisky dashboard on the Dask HTTP application.

    Routes claimed on the Dask dashboard port: `/`, `/ws`, `/api/*`, `/assets/*`,
    `/vite.svg`. Dask's own pages (`/status`, `/workers`, `/json/identity.json`,
    `/metrics`, `/health`, ...) remain reachable at their original paths.

    Idempotent: a second call updates the upstream URL in place. After the
    Frisky scheduler closes, requests get a clean 503 until a new hijack runs.
    """
    parsed = urlparse(frisky_dashboard_url)
    state = getattr(dask_scheduler, "_frisky_proxy_state", None)
    if state is None:
        state = {}
        dask_scheduler._frisky_proxy_state = state
        # Note: `/health` deliberately falls through to Dask's
        # `distributed.http.health` handler — Frisky doesn't need to own it,
        # and load-balancer probes that expect Dask-shaped JSON keep working.
        # `/metrics` (Prometheus, scraped by Coiled) also falls through.
        routes = [
            (r"/ws", _WebSocketProxy, dict(state=state)),
            (r"/api/.*", _HTTPProxy, dict(state=state)),
            (r"/assets/.*", _HTTPProxy, dict(state=state)),
            (r"/vite\.svg", _HTTPProxy, dict(state=state)),
            (r"/", _HTTPProxy, dict(state=state)),
        ]
        dask_scheduler.http_application.add_handlers(r".*", routes)
    state["upstream"] = f"http://{parsed.netloc}"
    state["ws_upstream"] = f"ws://{parsed.netloc}/ws"
