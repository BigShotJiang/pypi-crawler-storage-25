"""CLI for Veris – Connect agents to simulations."""

import click

from veris_cli.commands.auth import login
from veris_cli.commands.env import env
from veris_cli.commands.evaluations import evaluations
from veris_cli.commands.profile import profile
from veris_cli.commands.reports import reports
from veris_cli.commands.run import run
from veris_cli.commands.scenarios import scenarios
from veris_cli.commands.simulations import simulations


@click.group()
@click.version_option(prog_name="veris")
@click.pass_context
def cli(ctx):
    """Veris CLI - Connect your existing agent to Veris simulations."""
    ctx.ensure_object(dict)


# Top-level commands
cli.add_command(login)
cli.add_command(run)

# Resource groups
cli.add_command(env)
cli.add_command(scenarios)
cli.add_command(simulations)
cli.add_command(evaluations)
cli.add_command(reports)
cli.add_command(profile)


def main():
    """Main entry point."""
    cli()


if __name__ == "__main__":
    main()
