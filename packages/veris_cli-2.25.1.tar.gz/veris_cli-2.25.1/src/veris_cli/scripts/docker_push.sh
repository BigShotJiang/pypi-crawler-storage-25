#!/usr/bin/env bash
set -e

# Docker push script for Veris CLI
# Usage: docker_push.sh <image_uri> <registry> <username> <password>

IMAGE_URI="$1"
REGISTRY="$2"
USERNAME="$3"
PASSWORD="$4"

if [ -z "$IMAGE_URI" ] || [ -z "$REGISTRY" ] || [ -z "$USERNAME" ] || [ -z "$PASSWORD" ]; then
    echo "Usage: $0 <image_uri> <registry> <username> <password>"
    exit 1
fi

# Use a temporary Docker config directory to avoid conflicts with
# system credential helpers (e.g., gcloud credHelper for gcr.io)
TEMP_DOCKER_CONFIG=$(mktemp -d)
export DOCKER_CONFIG="$TEMP_DOCKER_CONFIG"
trap "rm -rf $TEMP_DOCKER_CONFIG" EXIT

# Preserve credential helpers from the default config.
# We only copy credHelpers (not the full config) to avoid importing
# Docker Desktop context references that break in the temp directory.
# Exclude the target registry from credHelpers so docker login token is used
# instead of a potentially-stale gcloud credential helper.
DEFAULT_DOCKER_CONFIG="${HOME}/.docker"
if [ -f "$DEFAULT_DOCKER_CONFIG/config.json" ]; then
    if command -v jq &> /dev/null; then
        jq --arg reg "$REGISTRY" '{"credHelpers": ((.credHelpers // {}) | del(.[$reg]))}' "$DEFAULT_DOCKER_CONFIG/config.json" > "$TEMP_DOCKER_CONFIG/config.json"
    fi
fi

echo "Logging in to Docker registry..."
echo "  Registry: $REGISTRY"
echo "  Username: $USERNAME"
echo ""

# Login to registry
echo "$PASSWORD" | docker login -u "$USERNAME" --password-stdin "$REGISTRY"

echo ""
echo "Pushing Docker image..."
echo "  Image: $IMAGE_URI"
echo ""

# Push image
docker push "$IMAGE_URI"

echo ""
echo "✓ Image pushed successfully: $IMAGE_URI"
echo ""
echo "Note: Push credentials expire in 1 hour"
