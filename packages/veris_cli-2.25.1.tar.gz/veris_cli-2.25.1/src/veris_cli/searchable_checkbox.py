"""Searchable checkbox prompt — type to filter, arrow keys to navigate,
right/left to toggle, enter to confirm."""

from __future__ import annotations

from prompt_toolkit import Application
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import Layout, HSplit, Window, FormattedTextControl
from prompt_toolkit.formatted_text import FormattedText


def searchable_checkbox(
    message: str,
    items: list[dict],
    title_fn: callable,
    search_fn: callable,
) -> list[dict]:
    """Interactive searchable checkbox.

    Args:
        message: Prompt message shown at top.
        items: List of item dicts to choose from.
        title_fn: fn(item) -> display string.
        search_fn: fn(item) -> lowercase searchable string.

    Returns:
        List of selected item dicts.

    Keys:
        Type to filter, Up/Down to move, Right to select, Left to deselect,
        Space to toggle, Enter to confirm, Ctrl+C to cancel.
    """
    selected: set[int] = set()  # indices into `items`
    cursor = [0]  # mutable for closure
    query = [""]

    def get_visible():
        if not query[0]:
            return list(range(len(items)))
        q = query[0].lower()
        return [i for i in range(len(items)) if q in search_fn(items[i])]

    def get_body():
        visible = get_visible()
        lines: list[tuple[str, str]] = []

        lines.append(("class:prompt", f"? {message}\n"))
        lines.append(("class:search", f"  Filter: {query[0]}█\n"))

        if not visible:
            lines.append(("class:muted", "  No matches\n"))
        else:
            # Clamp cursor
            if cursor[0] >= len(visible):
                cursor[0] = max(0, len(visible) - 1)

            for vi, idx in enumerate(visible):
                is_cursor = vi == cursor[0]
                is_selected = idx in selected
                marker = "◼" if is_selected else "◻"
                prefix = "❯ " if is_cursor else "  "
                style = "class:selected" if is_selected else ""
                if is_cursor:
                    style = "class:cursor"
                lines.append((style, f"{prefix}{marker} {title_fn(items[idx])}\n"))

        sel_count = len(selected)
        lines.append(("class:muted", f"\n  {sel_count} selected · ←/→ toggle · enter confirm\n"))
        return FormattedText(lines)

    body_control = FormattedTextControl(get_body)

    kb = KeyBindings()

    @kb.add("up")
    def _up(event):
        cursor[0] = max(0, cursor[0] - 1)

    @kb.add("down")
    def _down(event):
        visible = get_visible()
        cursor[0] = min(len(visible) - 1, cursor[0] + 1) if visible else 0

    @kb.add("right")
    def _select(event):
        visible = get_visible()
        if visible and cursor[0] < len(visible):
            selected.add(visible[cursor[0]])

    @kb.add("left")
    def _deselect(event):
        visible = get_visible()
        if visible and cursor[0] < len(visible):
            selected.discard(visible[cursor[0]])

    @kb.add("space")
    def _toggle(event):
        visible = get_visible()
        if visible and cursor[0] < len(visible):
            idx = visible[cursor[0]]
            if idx in selected:
                selected.discard(idx)
            else:
                selected.add(idx)

    @kb.add("enter")
    def _confirm(event):
        event.app.exit(result=[items[i] for i in sorted(selected)])

    @kb.add("c-c")
    def _cancel(event):
        event.app.exit(result=[])

    @kb.add("backspace")
    def _backspace(event):
        query[0] = query[0][:-1]
        cursor[0] = 0

    @kb.add("<any>")
    def _type(event):
        ch = event.data
        if ch.isprintable() and len(ch) == 1:
            query[0] += ch
            cursor[0] = 0

    layout = Layout(HSplit([Window(body_control)]))
    app: Application[list[dict]] = Application(
        layout=layout,
        key_bindings=kb,
        style=None,
        full_screen=False,
    )

    return app.run()
