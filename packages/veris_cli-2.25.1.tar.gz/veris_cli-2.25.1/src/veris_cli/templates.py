"""Static file templates for veris init."""

DOCKERFILE_SANDBOX = """# Extends veris-gvisor base with your agent code
ARG GVISOR_BASE=us-central1-docker.pkg.dev/veris-ai-prod/veris-sandbox/veris-gvisor:latest
FROM ${GVISOR_BASE}

# ============================================================
# 1. AGENT CODE — Update paths to match your project structure
# ============================================================
# NOTE: Build context is project root, so paths are relative
# to project root (even though this Dockerfile is in .veris/)

COPY app /agent/app

# ============================================================
# 2. DEPENDENCIES — Uncomment ONE section below
# ============================================================
WORKDIR /agent

# ── uv (default) ──────────────────────────────────────────
COPY pyproject.toml /agent/
COPY README.md /agent/
# COPY uv.lock /agent/
RUN uv sync --no-dev

# ── pip ────────────────────────────────────────────────────
# COPY requirements.txt /agent/
# RUN pip install --no-cache-dir -r requirements.txt

# ── poetry ─────────────────────────────────────────────────
# COPY pyproject.toml poetry.lock /agent/
# RUN pip install poetry && poetry install --no-dev

WORKDIR /app
"""

VERIS_YAML_HEADER = '# Veris simulation configuration\nversion: "1.0"\n'

# Body of a single target — indented two spaces so it nests under a top-level
# `<target_name>:` key. `__AGENT_NAME__` is replaced at scaffold time.
TARGET_BODY = """\
  # Uncomment the services your agent calls. dns_aliases should match the
  # domains your agent makes requests to — they'll be routed to the mock automatically.
  services:

    # - name: calendar
    #   dns_aliases:
    #     - www.googleapis.com
    #     - calendar.google.com
    #     - calendar-json.googleapis.com
    #     - googleapis.com
    #     - oauth2.googleapis.com

    # - name: crm
    #   dns_aliases:
    #     - login.salesforce.com
    #     - test.salesforce.com
    #     - your-domain.salesforce.com

    # - name: postgres
    #   config:
    #     SCHEMA_PATH: /agent/schemas/schema.sql

    # - name: mcp/stripe
    #   dns_aliases:
    #     - mcp.stripe.com

    # - name: mcp/shopify-storefront
    #   dns_aliases:
    #     - veris-ai.myshopify.com

    # - name: mcp/shopify-customer
    #   dns_aliases:
    #     - veris-ai.account.myshopify.com

    # - name: oracle

    # - name: atlassian/jira
    #   dns_aliases:
    #     - api.atlassian.com
    #     - your-instance.atlassian.net

    # - name: atlassian/confluence
    #   dns_aliases:
    #     - api.atlassian.com
    #     - your-instance.atlassian.net

    # - name: slack
    #   dns_aliases:
    #     - slack.com
    #     - api.slack.com

    # - name: zendesk-support
    #   dns_aliases:
    #     - your-subdomain.zendesk.com

    # - name: twilio
    #   dns_aliases:
    #     - api.twilio.com

    # - name: hogan
    #   dns_aliases:
    #     - api-gateway.wellsfargo.net

    # - name: microsoft/graph
    #   dns_aliases:
    #     - graph.microsoft.com

    # - name: microsoft/devops
    #   dns_aliases:
    #     - dev.azure.com
    #     - almsearch.dev.azure.com

    # - name: llm-proxy
    #   dns_aliases:
    #     - my-deployment.openai.azure.com

  persona:
    modality:
      type: http                         # http | ws | email
      url: http://localhost:8008/chat
      # method: POST
      # headers:
      #   Content-Type: application/json
      # request:
      #   message_field: message
      #   session_field: session_id
      # response:
      #   type: json                     # json | sse
      #   message_field: response
      #   session_field: session_id

    # config:
    #   RESPONSE_INTERVAL: "2"
    #   POLL_INTERVAL: "3"
    #   REFLECTION_INTERVAL: "5"

  agent:
    name: __AGENT_NAME__
    code_path: /agent
    entry_point: uv run --no-sync uvicorn app.main:app --host 0.0.0.0 --port 8008
    port: 8008
    # environment:
      # DATABASE_URL: postgresql://postgres:postgres@localhost:5432/SIMULATION_ID
"""


DOCKERIGNORE = """\
# Veris build context — excluded from `veris env push` uploads
.git
.venv
__pycache__
node_modules
.env
.env.*
*.egg-info
dist
build
.mypy_cache
.pytest_cache
.ruff_cache
"""


def get_dockerignore() -> str:
    """Get .dockerignore template for .veris/ directory."""
    return DOCKERIGNORE.strip()


def get_dockerfile_sandbox() -> str:
    """Get Dockerfile.sandbox template."""
    return DOCKERFILE_SANDBOX.strip()


def get_target_block(target_name: str, agent_name: str | None = None) -> str:
    """Render a single target block (top-level `<target_name>:` + indented body)."""
    name = agent_name if agent_name else target_name
    body = TARGET_BODY.replace("__AGENT_NAME__", name)
    return f"{target_name}:\n{body}"


def get_veris_yaml(target_name: str, agent_name: str | None = None) -> str:
    """Get the static veris.yaml template — multi-target shape with one target."""
    return f"{VERIS_YAML_HEADER}\n{get_target_block(target_name, agent_name)}".rstrip() + "\n"


def build_veris_yaml(
    target_name: str,
    services: list[dict],
    channels: list[dict] | None = None,
    agent_name: str | None = None,
) -> str:
    """Build veris.yaml from API-selected services and channels (multi-target shape).

    Args:
        target_name: Top-level target key (== backend env name).
        services: List of service dicts from the API (must have example_config).
        channels: List of channel dicts from the API (must have example_config).
        agent_name: Display name for the agent — written under agent.name.
    """
    import yaml

    target_body: dict = {}
    if services:
        target_body["services"] = [svc["example_config"] for svc in services]

    ch_configs = (
        [ch["example_config"] for ch in channels]
        if channels
        else [{"type": "http", "url": "http://localhost:8008"}]
    )
    target_body["actor"] = {"channels": ch_configs}

    agent: dict = {}
    if agent_name:
        agent["name"] = agent_name
    agent.update(
        {
            "code_path": "/agent",
            "entry_point": "uv run --no-sync uvicorn app.main:app --host 0.0.0.0 --port 8008",
            "port": 8008,
        }
    )
    target_body["agent"] = agent

    config: dict = {"version": "1.0", target_name: target_body}
    return yaml.dump(config, default_flow_style=False, sort_keys=False).strip()
