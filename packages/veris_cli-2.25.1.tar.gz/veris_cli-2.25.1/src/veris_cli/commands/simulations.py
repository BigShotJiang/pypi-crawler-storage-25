"""Simulation run commands: create, status, list, cancel."""

import sys
import time

import click

from veris_cli import output, prompts
from veris_cli.api import VerisAPI
from veris_cli.commands._helpers import (
    get_console_url,
    get_profile,
    try_get_project_env_id,
)


@click.group()
def simulations():
    """Simulation run management commands."""
    pass


@simulations.command(name="create")
@click.option("--scenario-set-id", default=None, help="Scenario set ID")
@click.option("--env-id", default=None, help="Environment ID")
@click.option(
    "--simulation-timeout",
    default=None,
    type=int,
    help="Simulation timeout in seconds (60-3600)",
)
@click.option("--image-tag", default=None, help="Image tag to use (default: latest)")
@click.option(
    "--auto-evaluate/--no-auto-evaluate",
    default=True,
    help="Auto-trigger evaluation on completion (default: enabled)",
)
@click.pass_context
def simulations_create(
    ctx,
    scenario_set_id: str,
    env_id: str,
    simulation_timeout: int,
    image_tag: str,
    auto_evaluate: bool,
):
    """Create a new simulation run."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if not env_id:
            project_env_id = try_get_project_env_id(profile)

            result = api.list_environments(status="ready")
            env_id = prompts.select_environment(
                result.get("environments", []), default=project_env_id
            )
            if not env_id:
                output.print_error("No environment selected")
                sys.exit(1)

        if not scenario_set_id:
            result = api.list_scenario_sets(environment_id=env_id)
            scenario_set_id = prompts.select_scenario(result)
            if not scenario_set_id:
                output.print_error("No scenario selected")
                sys.exit(1)

        config = {}
        if simulation_timeout is not None:
            config["simulation_timeout"] = simulation_timeout
        if image_tag is not None:
            config["image_tag"] = image_tag

        result = api.create_run(
            scenario_set_id=scenario_set_id,
            environment_id=env_id,
            config=config or None,
            auto_evaluate=auto_evaluate,
        )

        run_id = result.get("id")
        output.print_success(f"Simulation run created: {run_id}")
        output.print_info(f"→ {get_console_url(profile)}/simulations/{run_id}")
        output.print_info(f"→ Next: veris simulations status {run_id} --watch")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to create simulation run: {e}")
        sys.exit(1)


@simulations.command(name="status")
@click.argument("sim_run_id")
@click.option("--watch", is_flag=True, help="Poll every 3 seconds")
@click.option("--log", is_flag=True, help="Append event stream below status")
@click.pass_context
def simulations_status(ctx, sim_run_id: str, watch: bool, log: bool):
    """Get simulation run status with progress and sim list."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)

        if watch:
            from rich.live import Live

            try:
                with Live(console=output.console, refresh_per_second=1) as live:
                    while True:
                        run_data = api.get_run(sim_run_id)
                        live.update(output.build_simulation_status_panel(run_data))

                        status = run_data.get("status", "")
                        if status in ["completed", "failed", "cancelled"]:
                            break

                        time.sleep(3)
            except KeyboardInterrupt:
                output.print_info("\nStopped watching.")
                return

            # Print final state with sim list
            run_data = api.get_run(sim_run_id)
            sims_resp = api.list_run_simulations(sim_run_id)
            sims = sims_resp.get("simulations", [])
            output.print_simulation_run_details(run_data, sims)
            output.print_info(f"\n→ {get_console_url(profile)}/simulations/{sim_run_id}")
            output.print_info(f"→ Next: veris evaluations create --sim-run-id {sim_run_id}")
        else:
            run_data = api.get_run(sim_run_id)
            sims_resp = api.list_run_simulations(sim_run_id)
            sims = sims_resp.get("simulations", [])
            output.print_simulation_run_details(run_data, sims)
            output.print_info(f"\n→ {get_console_url(profile)}/simulations/{sim_run_id}")

        # Append event stream if --log
        if log:
            result = api.get_run_events(sim_run_id)
            output.print_run_events(result.get("events", []))

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to get simulation run status: {e}")
        sys.exit(1)


@simulations.command(name="list")
@click.option("--status", default=None, help="Filter by status")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@click.pass_context
def simulations_list(ctx, status: str, env_id: str):
    """List simulation runs for an environment."""
    profile = get_profile(ctx)
    try:
        if not env_id:
            env_id = try_get_project_env_id(profile)

        api = VerisAPI(profile=profile)
        result = api.list_runs(status=status, environment_id=env_id)
        output.print_runs_table(result.get("runs", []))
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list simulation runs: {e}")
        sys.exit(1)


@simulations.command(name="cancel")
@click.argument("sim_run_id")
@click.pass_context
def simulations_cancel(ctx, sim_run_id: str):
    """Cancel a simulation run."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        api.cancel_run(sim_run_id)
        output.print_success(f"Simulation run {sim_run_id} cancelled")
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to cancel simulation run: {e}")
        sys.exit(1)
