"""Environment management commands: create, push, list, delete, set-var, get-vars, rm-var."""

import sys
import time
from datetime import UTC, datetime
from pathlib import Path

import click
import httpx
import yaml

from veris_cli import output, prompts, templates
from veris_cli.api import VerisAPI
from veris_cli.commands._helpers import (
    find_target_on_other_profiles,
    get_profile,
    repo_dir_fallback,
    resolve_env_id,
    resolve_target,
)
from veris_cli.config import Config, ProjectConfig
from veris_cli.veris_yaml import DEFAULT_DOCKERFILE, VerisYaml, slugify


def _env_push_local(
    env_id: str,
    tag: str,
    tag_result: dict,
    profile: str | None = None,
    dockerfile: str = DEFAULT_DOCKERFILE,
):
    """Build locally and push to the customer's external registry."""
    import subprocess

    pull_creds = tag_result["pull_credentials"]
    image_uri = tag_result["image_uri"]
    base_image = tag_result["base_image"]
    registry_host = pull_creds["registry_url"]

    try:
        # Step 1: Login to Veris AR to pull base image
        output.print_info(f"Authenticating with Veris registry ({registry_host})...")
        login_proc = subprocess.run(
            ["docker", "login", "-u", pull_creds["username"], "--password-stdin", registry_host],
            input=pull_creds["password"],
            capture_output=True,
            text=True,
        )
        if login_proc.returncode != 0:
            output.print_error(f"Docker login failed: {login_proc.stderr}")
            sys.exit(1)

        # Step 2: Build locally
        output.print_info(f"Building image from {dockerfile}...")
        build_proc = subprocess.run(
            [
                "docker",
                "build",
                "--platform",
                "linux/amd64",
                "-f",
                dockerfile,
                "--build-arg",
                f"GVISOR_BASE={base_image}",
                "-t",
                image_uri,
                ".",
            ],
            text=True,
        )
        if build_proc.returncode != 0:
            output.print_error("Docker build failed")
            sys.exit(1)
        output.print_success("Image built")

        # Step 3: Push to customer's registry
        # Customer must already be authenticated to their own registry (e.g. aws ecr get-login-password)
        output.print_info(f"Pushing to {image_uri}...")
        push_proc = subprocess.run(
            ["docker", "push", image_uri],
            text=True,
        )
        if push_proc.returncode != 0:
            output.print_error(
                "Docker push failed. Make sure you are authenticated to your registry."
            )
            sys.exit(1)

        output.print_success(f"Image pushed: {tag}")

    except FileNotFoundError:
        output.print_error("Docker not found. Install Docker to use local builds.")
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Local build failed: {e}")
        sys.exit(1)


def _env_push_remote(
    env_id: str,
    tag: str,
    profile: str | None = None,
    dockerfile: str = DEFAULT_DOCKERFILE,
):
    tarball_path = None
    try:
        from veris_cli.build_context import create_build_context

        output.print_info("Packaging build context...")
        tarball_path, size = create_build_context(Path.cwd(), dockerfile=dockerfile)
        size_mb = size / 1024 / 1024
        output.print_success(f"Build context: {size_mb:.1f} MB")

        api = VerisAPI(profile=profile)
        build_result = api.create_build(environment_id=env_id, tag=tag)
        build_id = build_result["build_id"]
        upload_url = build_result["upload_url"]

        output.print_info("Uploading build context...")
        with open(tarball_path, "rb") as f:
            upload_resp = httpx.put(
                upload_url,
                content=f,
                headers={"Content-Type": "application/gzip"},
                timeout=300,
            )
        if upload_resp.status_code not in (200, 201):
            output.print_error(f"Upload failed: {upload_resp.status_code} {upload_resp.text}")
            sys.exit(1)
        output.print_success("Upload complete")

        output.print_info("Building image...")
        api.notify_build_uploaded(environment_id=env_id, build_id=build_id)

        from rich.console import Console
        from rich.live import Live
        from rich.spinner import Spinner

        console = Console()
        cursor = None
        logs_started = False
        build_status = "building"
        drain_attempts = 0

        # Show spinner until first log lines arrive
        spinner = Live(
            Spinner("dots", text="Building image..."), console=console, refresh_per_second=4
        )
        spinner.start()

        poll_errors = 0
        try:
            while True:
                time.sleep(2)
                try:
                    result = api.get_build_logs(
                        environment_id=env_id, build_id=build_id, cursor=cursor
                    )
                    poll_errors = 0
                except Exception:
                    poll_errors += 1
                    if poll_errors >= 5:
                        raise
                    continue
                lines = result.get("lines") or []
                build_status = result.get("status", build_status)
                new_cursor = result.get("cursor")
                if new_cursor:
                    cursor = new_cursor

                if lines and not logs_started:
                    # First log lines arrived — stop spinner, print header
                    spinner.stop()
                    logs_started = True
                    console.rule("Build logs")

                for line in lines:
                    click.echo(line)

                if build_status in ("complete", "failed"):
                    if not lines or not new_cursor:
                        drain_attempts += 1
                        if drain_attempts >= 5:
                            break
                    else:
                        drain_attempts = 0
        finally:
            if not logs_started:
                spinner.stop()

        if logs_started:
            console.rule()

        # Fetch final status for image URI / error detail
        status_result = api.get_build_status(environment_id=env_id, build_id=build_id)

        if build_status == "failed":
            error = status_result.get("error", "Unknown error")
            output.print_error(f"Build failed: {error}")
            sys.exit(1)

        output.print_success(f"Image pushed: {tag}")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to push: {e}")
        sys.exit(1)
    finally:
        if tarball_path:
            tarball_path.unlink(missing_ok=True)


@click.group()
def env():
    """Environment management commands."""
    pass


def _env_name_from_agent_name(agent_name: str) -> str:
    """Default target/env name from an agent name: slugify + '-env' suffix."""
    slug = slugify(agent_name)
    if not slug:
        return ""
    if slug.endswith("-env"):
        return slug
    return f"{slug}-env"


def target_option(f):
    """Shared --target click option used by env push, vars, run, etc."""
    return click.option(
        "--target",
        default=None,
        help="Target name from veris.yaml. Auto-detected if there's only one.",
    )(f)


def _maybe_migrate_shape_a(path: Path, parsed: VerisYaml) -> VerisYaml:
    """If `parsed` came from a shape-A file, migrate it to shape B on disk.

    Interactive behaviour depends on whether agent.name exists:
    - agent.name present  → derive target name, confirm with user
    - agent.name missing  → prompt for agent name, derive from that

    Non-interactive mode always uses the auto-derived name.
    """
    if not parsed.was_legacy_shape_a:
        return parsed

    implicit = next(iter(parsed.targets), None)
    if not implicit:
        return parsed

    target_obj = next(iter(parsed.targets.values()))
    has_agent_name = target_obj.agent and target_obj.agent.name
    new_agent_name: str | None = None

    if sys.stdin.isatty():
        import questionary

        output.print_info("Migrating veris.yaml to multi-target format.")

        if has_agent_name:
            # Agent name exists — confirm the derived target name.
            chosen = questionary.text(
                "Target name:",
                default=implicit,
                validate=lambda x: len(x.strip()) > 0 or "Name cannot be empty",
            ).ask()
            if chosen is None:
                output.print_warning("Migration skipped.")
                return parsed
            target_name = chosen.strip()
        else:
            # No agent name — ask for one so we can derive a good slug.
            new_agent_name = prompts.prompt_agent_name()
            if not new_agent_name:
                output.print_warning("Migration skipped.")
                return parsed
            target_name = _env_name_from_agent_name(new_agent_name)
    else:
        target_name = implicit

    parsed = VerisYaml.migrate_shape_a(path, target_name, agent_name=new_agent_name)
    output.print_info(
        f"Migrated .veris/veris.yaml to multi-target format "
        f"(config moved under target '{target_name}')."
    )
    return parsed


def _load_veris_yaml(path: Path) -> VerisYaml:
    """Parse and validate .veris/veris.yaml, exiting with a nice error on failure."""
    try:
        parsed = VerisYaml.load(path, legacy_target_fallback=repo_dir_fallback())
    except FileNotFoundError:
        output.print_error(f"{path} not found. Run 'veris env create' first.")
        sys.exit(1)
    except (yaml.YAMLError, ValueError) as e:
        output.print_error(f"Failed to parse {path}: {e}")
        sys.exit(1)
    return _maybe_migrate_shape_a(path, parsed)


def _try_load_veris_yaml(path: Path) -> VerisYaml | None:
    """Best-effort parse — returns None instead of exiting on failure."""
    try:
        parsed = VerisYaml.load(path, legacy_target_fallback=repo_dir_fallback())
    except (FileNotFoundError, yaml.YAMLError, ValueError):
        return None
    return _maybe_migrate_shape_a(path, parsed)


def _append_target_block(text: str, target_name: str, agent_name: str) -> str:
    """Append a fresh target block to existing veris.yaml text."""
    block = templates.get_target_block(target_name, agent_name)
    if text and not text.endswith("\n"):
        text += "\n"
    return f"{text}\n{block}"


@env.command(name="create")
@click.option(
    "--name",
    default=None,
    help="Environment/target name (e.g. 'customer-support-env'). Used verbatim.",
)
@click.option(
    "--agent-name",
    default=None,
    help="Agent display name (e.g. 'Customer Support'). Stored in veris.yaml agent.name.",
)
@click.pass_context
def env_create(ctx, name: str | None, agent_name: str | None):
    """Create a new environment on Veris.

    \b
      veris env create --name customer-support-env --agent-name "Customer Support"
        → target/env = customer-support-env
        → agent.name = Customer Support

    If only --name is given, agent.name is prompted interactively.
    If neither is given, the CLI offers existing targets or prompts for both.

    Run multiple times to add more agents to the same repo.
    """
    profile = get_profile(ctx)
    veris_dir = Path.cwd() / ".veris"

    # If the user didn't specify --name, check whether veris.yaml already has
    # targets that aren't configured on this profile yet. If so, offer to
    # create an environment for one of those instead of scaffolding a new agent.
    if not name and sys.stdin.isatty():
        veris_yaml_path = veris_dir / "veris.yaml"
        if veris_yaml_path.exists():
            parsed = _try_load_veris_yaml(veris_yaml_path)
            if parsed and parsed.targets:
                unconfigured = [
                    t
                    for t in parsed.target_names
                    if not ProjectConfig(profile=profile, target=t).get_environment_id()
                ]
                if unconfigured:
                    import questionary

                    _NEW_TARGET = "__new__"
                    choices = [questionary.Choice(title=t, value=t) for t in unconfigured] + [
                        questionary.Choice(title="Create a new target", value=_NEW_TARGET),
                    ]
                    selected = questionary.select(
                        "Existing targets found in veris.yaml. Set up environment for:",
                        choices=choices,
                    ).ask()
                    if selected is None:
                        return
                    if selected and selected != _NEW_TARGET:
                        name = selected
                        # Pull the agent name from the target block
                        t_obj = parsed.get_target(selected)
                        if t_obj.agent and t_obj.agent.name:
                            agent_name = t_obj.agent.name

    # Prompt for env name if still not set
    if not name:
        if sys.stdin.isatty():
            import questionary

            name = questionary.text(
                "Environment name (e.g. 'customer-support-env'):",
                validate=lambda x: len(x.strip()) > 0 or "Name cannot be empty",
            ).ask()
            if not name:
                return
            name = name.strip()
        else:
            output.print_error("--name is required in non-interactive mode.")
            sys.exit(1)

    # Prompt for agent display name if not provided
    if not agent_name:
        if sys.stdin.isatty():
            agent_name = prompts.prompt_agent_name()
        if not agent_name:
            agent_name = name  # fall back to env name as display name

    env_name = name

    project_config = ProjectConfig(profile=profile, target=env_name)
    existing_env_id = project_config.get_environment_id()
    if existing_env_id:
        existing_name = project_config.get_environment_name() or "unknown"
        output.print_info(
            f"Environment already configured for target '{env_name}': "
            f"{existing_env_id} ({existing_name})"
        )
        return

    parsed_yaml = _scaffold_veris_dir(
        veris_dir, target_name=env_name, agent_name=agent_name, profile=profile
    )

    output.print_info(f"\nCreating environment '{env_name}' (agent: {agent_name})...")
    try:
        api = VerisAPI(profile=profile)
        result = api.create_environment(name=env_name)

        environment = result.get("environment", {})
        env_id = environment.get("id")

        if not env_id:
            output.print_error("Failed to get environment ID from response")
            sys.exit(1)

        project_config.set_environment_id(env_id, env_name)

        target_obj = parsed_yaml.targets.get(env_name) if parsed_yaml else None
        if target_obj is not None:
            try:
                api.upload_environment_config(env_id, target_obj.to_upload_dict())
                output.print_success("Config uploaded")
            except Exception as e:
                output.print_warning(f"Config upload failed (non-fatal): {e}")

        output.print_success(f"Environment created: {env_id}")
        output.print_info(f"Environment ID saved to .veris/config.yaml under target '{env_name}'")
        output.print_info("\nNext steps:")
        output.print_info("  Option A — Self-serve:")
        output.print_info("    1. Edit .veris/Dockerfile.sandbox and .veris/veris.yaml")
        output.print_info("    2. Run 'veris env push' to build and push your agent")
        output.print_info("  Option B — Let Veris set it up:")
        output.print_info("    1. Run 'veris env submit' to upload your code")
        output.print_info("    2. We'll email you when your environment is ready")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except httpx.ConnectError:
        output.print_error(
            f"Could not connect to backend at {Config(profile=profile).get_backend_url()}"
        )
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to create environment: {e}")
        sys.exit(1)


def _build_veris_yaml(target_name: str, profile: str | None, agent_name: str | None) -> str:
    """Build veris.yaml — interactive with API data if possible, static fallback."""
    if not sys.stdin.isatty():
        return templates.get_veris_yaml(target_name=target_name, agent_name=agent_name)

    try:
        api = VerisAPI(profile=profile)
        services_data = api.list_services()
        channels_data = api.list_channels()
    except Exception:
        output.print_info(
            "Not authenticated — using static template. Run 'veris login' first for interactive setup."
        )
        return templates.get_veris_yaml(target_name=target_name, agent_name=agent_name)

    services = services_data.get("services", [])
    channels = channels_data.get("channels", [])

    if not services and not channels:
        return templates.get_veris_yaml(target_name=target_name, agent_name=agent_name)

    output.print_info("\nConfigure your agent's communication channels:")
    selected_channels = prompts.select_channels(channels) if channels else []

    output.print_info("\nSelect services your agent interacts with:")
    selected_services = prompts.select_services(services) if services else []

    return templates.build_veris_yaml(
        target_name=target_name,
        services=selected_services,
        channels=selected_channels,
        agent_name=agent_name,
    )


def _scaffold_veris_dir(
    veris_dir: Path,
    target_name: str,
    agent_name: str,
    profile: str | None = None,
) -> VerisYaml | None:
    """Create or extend .veris/ for a target. Returns the parsed VerisYaml after scaffolding.

    Auto-migrates legacy shape-A files to shape B before appending a new
    target block, then returns the final parsed state so the caller can
    upload the new target's block without re-reading the file.
    """
    veris_dir.mkdir(parents=True, exist_ok=True)

    created_files = []

    dockerfile_path = veris_dir / "Dockerfile.sandbox"
    if not dockerfile_path.exists():
        dockerfile_path.write_text(templates.get_dockerfile_sandbox())
        created_files.append("  - .veris/Dockerfile.sandbox — Agent image definition")

    veris_yaml_path = veris_dir / "veris.yaml"
    if not veris_yaml_path.exists():
        veris_yaml_path.write_text(_build_veris_yaml(target_name, profile, agent_name))
        created_files.append("  - .veris/veris.yaml — Simulation configuration")
        parsed = _try_load_veris_yaml(veris_yaml_path)
    else:
        # _try_load_veris_yaml → VerisYaml.load() auto-migrates shape A → B
        # on disk, so by the time we get `parsed` back the file is already
        # in multi-target format.
        parsed = _try_load_veris_yaml(veris_yaml_path)

        if parsed is not None and target_name not in parsed.targets:
            veris_yaml_path.write_text(
                _append_target_block(veris_yaml_path.read_text(), target_name, agent_name)
            )
            output.print_info(f"Appended new target block '{target_name}' to .veris/veris.yaml")
            parsed = _try_load_veris_yaml(veris_yaml_path)

    dockerignore_path = veris_dir / ".dockerignore"
    if not dockerignore_path.exists():
        dockerignore_path.write_text(templates.get_dockerignore())
        created_files.append("  - .veris/.dockerignore — Files excluded from image build")

    if created_files:
        output.print_success("Environment initiated.")
        output.print_info("Created files:")
        for file in created_files:
            output.print_info(file)
        output.print_info("")

    return parsed


def _migrate_legacy_config(
    profile: str | None,
    target_name: str,
    parsed: VerisYaml | None,
) -> str | None:
    """Detect a legacy profile-level env_id and offer to migrate it to the
    target-scoped format. Returns the env_id if migrated, None otherwise.

    This handles the upgrade path for users who set up their environment
    before multi-target support: their .veris/config.yaml has environment_id
    at the profile level instead of under targets.<name>.
    """
    # Already has a target-scoped env_id — nothing to migrate
    if ProjectConfig(profile=profile, target=target_name).get_environment_id():
        return None

    # Check for legacy profile-level env_id
    legacy_pc = ProjectConfig(profile=profile)
    legacy_env_id = legacy_pc.get_environment_id()
    if not legacy_env_id:
        return None

    legacy_env_name = legacy_pc.get_environment_name() or target_name
    current_profile = legacy_pc.profile

    output.print_info(
        f"Found environment '{legacy_env_name}' ({legacy_env_id}) on profile "
        f"'{current_profile}' in legacy config format. "
        f"Migrating to target '{target_name}'."
    )

    # Write the env_id under the target and clean up legacy profile-level keys.
    pc = ProjectConfig(profile=profile, target=target_name)
    pc.set_environment_id(legacy_env_id, target_name)

    # Remove the legacy profile-level environment_id/environment_name —
    # they're now scoped under targets.<name>.
    profile_data = legacy_pc._load_profile()
    profile_data.pop("environment_id", None)
    profile_data.pop("environment_name", None)
    legacy_pc._save_profile(profile_data)

    output.print_success(
        f"Migrated '{legacy_env_name}' to target '{target_name}' in .veris/config.yaml"
    )
    return legacy_env_id


def _resolve_or_create_cross_profile(
    profile: str | None,
    target_name: str,
    env_name: str,
) -> str | None:
    """If the target has no env_id on the current profile but does on another,
    offer to create it on the current profile. Returns the new env_id or None.
    """
    scoped = ProjectConfig(profile=profile, target=target_name).get_environment_id()
    if scoped:
        return scoped

    other = find_target_on_other_profiles(target_name, profile)
    if not other:
        return None

    current = ProjectConfig(profile=profile).profile
    output.print_warning(
        f"Target '{target_name}' is configured on profile '{other}' but not on '{current}'."
    )

    if not sys.stdin.isatty():
        return None

    if not prompts.confirm_action(
        f"Create environment '{env_name}' on profile '{current}'?",
        default=True,
        flag_hint="--env-id",
    ):
        return None

    try:
        api = VerisAPI(profile=profile)
        result = api.create_environment(name=env_name)
        env_id = result.get("environment", {}).get("id")
        if env_id:
            ProjectConfig(profile=profile, target=target_name).set_environment_id(env_id, env_name)
            output.print_success(
                f"Environment '{env_name}' created on profile '{current}': {env_id}"
            )
            return env_id
    except Exception as e:
        output.print_error(f"Failed to create environment: {e}")

    return None


@env.command(name="submit")
@click.option("--env-id", default=None, help="Environment ID (overrides config)")
@target_option
@click.pass_context
def env_submit(ctx, env_id: str | None, target: str | None):
    """Submit your repo for managed environment setup.

    Packages your project into a tarball and uploads it to Veris. The team
    will generate your Dockerfile.sandbox and veris.yaml. You'll receive an
    email when the setup is complete.

    \b
    After receiving the email:
      veris env config pull       # Pull generated config files
      veris env push      # Build and push your agent
    """
    profile = get_profile(ctx)
    resolved_target = resolve_target(target, profile)

    # Prompt for target selection if multiple targets and none resolved
    if not resolved_target and not env_id and sys.stdin.isatty():
        veris_yaml_path = Path.cwd() / ".veris" / "veris.yaml"
        parsed = _try_load_veris_yaml(veris_yaml_path)
        if parsed and len(parsed.target_names) > 1:
            import questionary

            resolved_target = questionary.select(
                "Multiple targets found. Submit which one?",
                choices=parsed.target_names,
            ).ask()
            if not resolved_target:
                return

    env_id = resolve_env_id(profile, env_id, resolved_target)

    tarball_path = None
    try:
        from veris_cli.build_context import create_build_context

        output.print_info("Packaging project...")
        tarball_path, size = create_build_context(Path.cwd(), require_dockerfile=False)
        size_mb = size / 1024 / 1024
        output.print_success(f"Package size: {size_mb:.1f} MB")

        api = VerisAPI(profile=profile)
        submit_result = api.create_submit(env_id)
        upload_url = submit_result["upload_url"]

        output.print_info("Uploading...")
        with open(tarball_path, "rb") as f:
            upload_resp = httpx.put(
                upload_url,
                content=f,
                headers={"Content-Type": "application/gzip"},
                timeout=300,
            )
        if upload_resp.status_code not in (200, 201):
            output.print_error(f"Upload failed: {upload_resp.status_code}")
            sys.exit(1)
        output.print_success("Upload complete")

        api.notify_submit_uploaded(env_id)
        output.print_success("Submitted for managed setup!")
        output.print_info("You'll receive an email when your environment is ready.")
        output.print_info("Then run 'veris env push' to build and deploy.")

    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Submit failed: {e}")
        sys.exit(1)
    finally:
        if tarball_path:
            tarball_path.unlink(missing_ok=True)


@env.command(name="push")
@click.option("--tag", default="latest", help="Image tag (default: latest)")
@click.option("--env-id", default=None, help="Environment ID (overrides config)")
@click.option(
    "--force",
    "-f",
    is_flag=True,
    default=False,
    help="Skip the sync guard for managed-setup envs (use in CI).",
)
@target_option
@click.pass_context
def env_push(ctx, tag: str, env_id: str | None, force: bool, target: str | None):
    """Build and push environment image to Veris.

    Resolves the target's block from veris.yaml (including an optional
    per-target dockerfile override) and the target's env_id from
    .veris/config.yaml. If only one target is defined, --target is optional.
    Otherwise pass --target <name> or set an active target with
    `veris env targets set <name>`.
    """
    profile = get_profile(ctx)
    veris_dir = Path.cwd() / ".veris"
    veris_yaml_path = veris_dir / "veris.yaml"

    if not veris_dir.exists():
        output.print_error(".veris/ not found. Run 'veris env create' first.")
        sys.exit(1)

    if not veris_yaml_path.exists():
        output.print_error(".veris/veris.yaml not found. Run 'veris env create' first.")
        sys.exit(1)

    parsed = _load_veris_yaml(veris_yaml_path)
    resolved_target = resolve_target(target, profile, parsed_veris_yaml=parsed)

    if not resolved_target and not env_id and sys.stdin.isatty() and len(parsed.target_names) > 1:
        import questionary

        resolved_target = questionary.select(
            "Multiple targets found. Push which one?",
            choices=parsed.target_names,
        ).ask()
        if not resolved_target:
            return

    try:
        target_obj = parsed.get_target(resolved_target)
    except KeyError as e:
        output.print_error(str(e))
        sys.exit(1)

    dockerfile_rel = target_obj.resolved_dockerfile()
    dockerfile_path = Path.cwd() / dockerfile_rel

    if not env_id and not target:
        env_id = _migrate_legacy_config(profile, resolved_target, parsed)
    if not env_id:
        env_id = _resolve_or_create_cross_profile(profile, resolved_target, resolved_target)
    if not env_id:
        env_id = resolve_env_id(profile, env_id, resolved_target)

    api = VerisAPI(profile=profile)

    if not dockerfile_path.exists():
        output.print_error(
            f"{dockerfile_rel} not found. Run 'veris env create' or 'veris env config pull' first."
        )
        sys.exit(1)

    # Config sync guard: only managed-setup envs (status=ready) have config
    # that could be authored by someone other than this CLI user. For self-serve
    # envs (status=created), the user IS the author — no divergence is possible
    # and the guard would only cause spurious CI failures (local config_synced_at
    # is always missing on fresh runners). status=pending is already blocked by
    # the backend with its own message.
    try:
        env_info = api.get_environment(env_id)
    except Exception:
        env_info = {}

    pc = ProjectConfig(profile=profile, target=resolved_target)

    if env_info.get("status") == "ready" and not force:
        remote_config_at = env_info.get("config_updated_at")
        local_synced_at = pc.get_config_synced_at()
        if remote_config_at and (not local_synced_at or remote_config_at > local_synced_at):
            if sys.stdin.isatty():
                import questionary

                action = questionary.select(
                    "Remote config was updated since your last sync.",
                    choices=[
                        questionary.Choice(
                            title="Pull remote config (overwrites local)", value="pull"
                        ),
                        questionary.Choice(
                            title="Push local config (overwrites remote)", value="push"
                        ),
                        questionary.Choice(title="Cancel", value="cancel"),
                    ],
                ).ask()
                if action == "cancel" or action is None:
                    return
                if action == "pull":
                    ctx.invoke(config_pull, env_id=env_id, target=resolved_target)
                    # Reload target config after pull (resolved_target stays the same)
                    parsed = _load_veris_yaml(veris_yaml_path)
                    target_obj = parsed.get_target(resolved_target)
                    dockerfile_rel = target_obj.resolved_dockerfile()
                    dockerfile_path = Path.cwd() / dockerfile_rel
            else:
                output.print_error(
                    "Remote config was updated since your last sync. "
                    "Run 'veris env config pull' first, or pass --force to overwrite."
                )
                sys.exit(1)

    try:
        api.upload_environment_config(env_id, target_obj.to_upload_dict())
        # Re-fetch to get the server-assigned config_updated_at
        updated_env = api.get_environment(env_id)
        pc.set_config_synced_at(
            updated_env.get("config_updated_at") or datetime.now(UTC).isoformat()
        )
        output.print_success("Config validated and uploaded")
    except Exception as e:
        detail = getattr(e, "detail", str(e))
        output.print_error(f"veris.yaml validation failed:\n{detail}")
        sys.exit(1)

    # On-prem clusters route through the customer's external registry instead of Cloud Build.
    try:
        if env_info.get("image_registry_url"):
            tag_result = api.create_image_tag(env_id, tag)
            if tag_result.get("pull_credentials"):
                _env_push_local(env_id, tag, tag_result, profile, dockerfile=dockerfile_rel)
                return
    except Exception:
        pass  # Fall through to Cloud Build

    _env_push_remote(env_id, tag, profile, dockerfile=dockerfile_rel)


@env.group()
def targets():
    """Active target management."""
    pass


@targets.command(name="get")
@click.pass_context
def target_get(ctx):
    """Show the active target for this project.

    Example: veris env targets get
    """
    profile = get_profile(ctx)
    active = ProjectConfig(profile=profile).get_active_target()
    if active:
        output.print_info(f"Active target: {active}")
    else:
        output.print_info(
            "No active target set. If only one target is defined in veris.yaml, "
            "it's used automatically."
        )


@targets.command(name="set")
@click.argument("name")
@click.pass_context
def target_set(ctx, name: str):
    """Set the active target for this project.

    Example: veris env targets set my-cool-agent-env
    """
    profile = get_profile(ctx)
    yaml_path = Path.cwd() / ".veris" / "veris.yaml"
    parsed = _try_load_veris_yaml(yaml_path)
    if parsed and parsed.targets and name not in parsed.targets:
        output.print_warning(
            f"Target '{name}' is not defined in veris.yaml "
            f"(configured: {', '.join(parsed.target_names) or 'none'}). Saving anyway."
        )

    ProjectConfig(profile=profile).set_active_target(name)
    output.print_success(f"Active target set to '{name}'.")


@targets.command(name="list")
@click.pass_context
def target_list(ctx):
    """List configured targets from veris.yaml.

    Example: veris env targets list
    """
    profile = get_profile(ctx)
    yaml_path = Path.cwd() / ".veris" / "veris.yaml"
    parsed = _try_load_veris_yaml(yaml_path)
    names = parsed.target_names if parsed else []
    if not names:
        output.print_info("No targets defined in veris.yaml.")
        return
    active = ProjectConfig(profile=profile).get_active_target()
    output.print_info("Configured targets:")
    for n in names:
        marker = " (active)" if n == active else ""
        output.print_info(f"  - {n}{marker}")


@targets.command(name="clear")
@click.pass_context
def target_clear(ctx):
    """Clear the active target for this project.

    Example: veris env targets clear
    """
    profile = get_profile(ctx)
    ProjectConfig(profile=profile).set_active_target(None)
    output.print_success("Active target cleared.")


@env.command(name="list")
@click.pass_context
def env_list(ctx):
    """List environments for current profile."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        result = api.list_environments()
        output.print_environments_table(result.get("environments", []))
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list environments: {e}")
        sys.exit(1)


@env.command(name="delete")
@click.argument("env_id")
@click.pass_context
def env_delete(ctx, env_id: str):
    """Delete an environment."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        api.delete_environment(env_id)
        output.print_success(f"Environment {env_id} deleted")
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to delete environment: {e}")
        sys.exit(1)


@env.group()
def config():
    """Environment config (veris.yaml) management."""
    pass


@config.command(name="push")
@click.option(
    "--file",
    "file_path",
    default=None,
    type=click.Path(exists=True),
    help="Path to veris.yaml (default: .veris/veris.yaml)",
)
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@click.option(
    "--force",
    "-f",
    is_flag=True,
    default=False,
    help="Skip the sync guard for managed-setup envs (use in CI).",
)
@target_option
@click.pass_context
def config_push(ctx, file_path: str | None, env_id: str, force: bool, target: str | None):
    """Upload veris.yaml config to the backend without building an image.

    Reads .veris/veris.yaml by default, or a custom path via --file. With
    --target, uploads only that target's block.

    Example: veris env config push --file path/to/veris.yaml
    """
    profile = get_profile(ctx)
    resolved_target = resolve_target(target, profile)
    env_id = resolve_env_id(profile, env_id, resolved_target)

    config_path = Path(file_path) if file_path else Path.cwd() / ".veris" / "veris.yaml"
    if not config_path.exists():
        output.print_error(f"{config_path} not found. Run 'veris env create' first.")
        sys.exit(1)

    parsed = _load_veris_yaml(config_path)

    try:
        target_obj = parsed.get_target(resolved_target)
    except KeyError as e:
        output.print_error(str(e))
        sys.exit(1)

    api = VerisAPI(profile=profile)
    pc = ProjectConfig(profile=profile, target=resolved_target)

    # Config sync guard — only meaningful for managed-setup envs (status=ready)
    # where someone else may have authored the remote config. See env_push for
    # the full rationale.
    try:
        env_info = api.get_environment(env_id)
    except Exception:
        env_info = {}

    if env_info.get("status") == "ready" and not force:
        remote_config_at = env_info.get("config_updated_at")
        local_synced_at = pc.get_config_synced_at()
        if remote_config_at and (not local_synced_at or remote_config_at > local_synced_at):
            if sys.stdin.isatty():
                import questionary

                action = questionary.select(
                    "Remote config was updated since your last sync.",
                    choices=[
                        questionary.Choice(
                            title="Pull remote config (overwrites local)", value="pull"
                        ),
                        questionary.Choice(
                            title="Push local config (overwrites remote)", value="push"
                        ),
                        questionary.Choice(title="Cancel", value="cancel"),
                    ],
                ).ask()
                if action == "cancel" or action is None:
                    return
                if action == "pull":
                    # Delegate to config pull logic
                    output.print_info("Pulling remote config...")
                    ctx.invoke(config_pull, env_id=env_id, target=resolved_target)
                    return
            else:
                output.print_error(
                    "Remote config was updated since your last sync. "
                    "Run 'veris env config pull' first, or pass --force to overwrite."
                )
                sys.exit(1)

    try:
        api.upload_environment_config(env_id, target_obj.to_upload_dict())
        env_info = api.get_environment(env_id)
        config_ts = env_info.get("config_updated_at") or datetime.now(UTC).isoformat()
        pc.set_config_synced_at(config_ts)
        output.print_success(f"Config uploaded for environment {env_id}")
    except Exception as e:
        detail = getattr(e, "detail", str(e))
        output.print_error(f"Config upload failed:\n{detail}")
        sys.exit(1)


@config.command(name="pull")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@target_option
@click.pass_context
def config_pull(ctx, env_id: str | None, target: str | None):
    """Pull config files from Veris to local .veris/ directory.

    Downloads the Dockerfile.sandbox and veris.yaml from the backend.
    Use after 'veris env submit' (managed setup) or to sync with
    remote config changes.

    Example: veris env config pull
    """
    profile = get_profile(ctx)
    resolved_target = resolve_target(target, profile)
    env_id = resolve_env_id(profile, env_id, resolved_target)

    try:
        api = VerisAPI(profile=profile)
        result = api.get_managed_config(env_id)

        status = result.get("status", "created")
        if status != "ready":
            output.print_info(f"Environment status: {status}")
            if status == "pending":
                output.print_info(
                    "Your environment is being set up. You'll receive an email when it's ready."
                )
            else:
                output.print_info("No remote config available. Run 'veris env submit' first.")
            return

        veris_dir = Path.cwd() / ".veris"
        veris_dir.mkdir(parents=True, exist_ok=True)

        dockerfile_url = result.get("dockerfile_url")
        if dockerfile_url:
            resp = httpx.get(dockerfile_url, timeout=60)
            if resp.status_code == 200:
                (veris_dir / "Dockerfile.sandbox").write_text(resp.text)
                output.print_success("Downloaded .veris/Dockerfile.sandbox")
            else:
                output.print_warning("Failed to download Dockerfile.sandbox")

        veris_yaml_url = result.get("veris_yaml_url")
        if veris_yaml_url and resolved_target:
            resp = httpx.get(veris_yaml_url, timeout=60)
            if resp.status_code == 200:
                flat_config = yaml.safe_load(resp.text)
                # Merge into existing veris.yaml to preserve other targets
                yaml_path = veris_dir / "veris.yaml"
                if yaml_path.exists():
                    existing = yaml.safe_load(yaml_path.read_text()) or {}
                else:
                    existing = {"version": "1.0"}
                existing.setdefault("version", "1.0")
                existing[resolved_target] = flat_config
                yaml_path.write_text(yaml.dump(existing, default_flow_style=False, sort_keys=False))
                output.print_success("Downloaded .veris/veris.yaml")
            else:
                output.print_warning("Failed to download veris.yaml")

        # Save sync timestamp
        env_detail = api.get_environment(env_id)
        config_ts = env_detail.get("config_updated_at") or datetime.now(UTC).isoformat()
        ProjectConfig(profile=profile, target=resolved_target).set_config_synced_at(config_ts)

    except Exception as e:
        output.print_error(f"Failed to pull config: {e}")
        sys.exit(1)


@env.group()
def vars():
    """Environment variable management."""
    pass


@vars.command(name="set")
@click.argument("key_values", nargs=-1, required=True)
@click.option("--secret", is_flag=True, help="Mark all values as secret (encrypted at rest)")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@target_option
@click.pass_context
def vars_set(ctx, key_values: tuple[str, ...], secret: bool, env_id: str, target: str | None):
    """Set environment variables.

    Pass one or more KEY=VALUE pairs:

      veris env vars set OPENAI_API_KEY=sk-... --secret
      veris env vars set DB_HOST=localhost DB_PORT=5432 --target ragie
    """
    profile = get_profile(ctx)
    variables = []
    for item in key_values:
        if "=" not in item:
            output.print_error(f"Invalid format: '{item}'. Expected KEY=VALUE.")
            sys.exit(1)
        key, _, value = item.partition("=")
        key = key.strip()
        if not key:
            output.print_error(f"Empty key in: '{item}'")
            sys.exit(1)
        variables.append({"key": key, "value": value, "is_secret": secret})

    try:
        api = VerisAPI(profile=profile)
        env_id = resolve_env_id(profile, env_id, target)
        result = api.upsert_environment_variables(env_id, variables)
        count = len(result.get("variables", []))
        output.print_success(f"{count} variable(s) saved to environment {env_id}")
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to set variables: {e}")
        sys.exit(1)


@vars.command(name="list")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@target_option
@click.pass_context
def vars_list(ctx, env_id: str, target: str | None):
    """List environment variables."""
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        env_id = resolve_env_id(profile, env_id, target)
        result = api.list_environment_variables(env_id)
        output.print_environment_variables_table(result.get("variables", []))
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to list variables: {e}")
        sys.exit(1)


@vars.command(name="rm")
@click.argument("key")
@click.option("--env-id", default=None, help="Environment ID (uses project config if omitted)")
@target_option
@click.pass_context
def vars_rm(ctx, key: str, env_id: str, target: str | None):
    """Remove an environment variable by key.

    Example: veris env vars rm OPENAI_API_KEY
    """
    profile = get_profile(ctx)
    try:
        api = VerisAPI(profile=profile)
        env_id = resolve_env_id(profile, env_id, target)
        api.delete_environment_variable(env_id, key)
        output.print_success(f"Variable '{key}' removed from environment {env_id}")
    except ValueError as e:
        output.print_error(str(e))
        sys.exit(1)
    except Exception as e:
        output.print_error(f"Failed to remove variable: {e}")
        sys.exit(1)
