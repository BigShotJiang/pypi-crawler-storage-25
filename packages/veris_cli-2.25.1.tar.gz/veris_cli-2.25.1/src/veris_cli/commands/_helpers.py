"""Shared helpers for CLI command modules."""

import sys
import time
from pathlib import Path
from typing import Any, Callable

import click
import yaml

from veris_cli.config import ProjectConfig


def get_console_url(profile: str | None = None) -> str:
    """Get console base URL from config, defaults to https://console.veris.ai."""
    from veris_cli.config import Config

    return Config(profile=profile).get_console_url()


def get_profile(ctx: click.Context) -> str | None:
    """Get profile from Click context."""
    return ctx.obj.get("profile") if ctx.obj else None


def veris_yaml_path() -> Path:
    """Default location of the project's veris.yaml."""
    return Path.cwd() / ".veris" / "veris.yaml"


def repo_dir_fallback() -> str:
    """Used as the legacy_target_fallback for VerisYaml.load."""
    return Path.cwd().name


def resolve_target(
    target: str | None,
    profile: str | None = None,
    parsed_veris_yaml=None,
) -> str | None:
    """Resolve target name.

    Priority:
      1. Explicit `--target` flag
      2. Persisted `active_target` in .veris/config.yaml
      3. Auto-detect from veris.yaml: if exactly one target is defined, use its
         name (so single-target repos never need a flag). Pass `parsed_veris_yaml`
         to avoid re-parsing when the caller already loaded it.
      4. None — caller will fall back to legacy profile-level config
    """
    if target:
        return target
    try:
        active = ProjectConfig(profile=profile).get_active_target()
        if active:
            return active
    except (OSError, yaml.YAMLError):
        pass

    if parsed_veris_yaml is None:
        path = veris_yaml_path()
        if path.exists():
            try:
                from veris_cli.veris_yaml import VerisYaml

                parsed_veris_yaml = VerisYaml.load(path, legacy_target_fallback=repo_dir_fallback())
            except (OSError, yaml.YAMLError, ValueError):
                parsed_veris_yaml = None

    if parsed_veris_yaml is not None:
        sole = parsed_veris_yaml.sole_target_name()
        if sole:
            return sole

    return None


def _lookup_env_id(profile: str | None, target: str | None) -> tuple[str | None, str | None]:
    """Look up env_id without raising. Returns (env_id, resolved_target).

    Resolution: target's scoped env_id (when one was explicit/active/auto-detected),
    or — only when no target could be resolved at all — the legacy profile-level
    env_id. We do NOT silently fall through from a missing target to legacy:
    that would mask "wrong env" bugs when a user passes --target X but X has no
    env_id under the profile.
    """
    resolved_target = resolve_target(target, profile)
    if resolved_target:
        scoped = ProjectConfig(profile=profile, target=resolved_target).get_environment_id()
        return scoped, resolved_target
    legacy = ProjectConfig(profile=profile).get_environment_id()
    return legacy, None


def find_target_on_other_profiles(
    target_name: str,
    current_profile: str | None,
) -> str | None:
    """Check if target_name has an env_id under a different profile. Returns that profile name."""
    from veris_cli.config import Config

    resolved_profile = ProjectConfig(profile=current_profile).profile
    for other in Config(profile=current_profile).list_profiles():
        if other == resolved_profile:
            continue
        other_pc = ProjectConfig(profile=other, target=target_name)
        if other_pc.get_environment_id():
            return other
    return None


def resolve_env_id(
    profile: str | None,
    env_id: str | None,
    target: str | None = None,
) -> str:
    """Resolve environment ID from flag, target, or project config. Exits on failure."""
    if env_id:
        return env_id

    found, resolved_target = _lookup_env_id(profile, target)
    if found:
        return found

    from veris_cli import output

    hint = f" for target '{resolved_target}'" if resolved_target else ""
    msg = f"No environment configured{hint}. Use --env-id or run 'veris env create' first."

    if resolved_target:
        other = find_target_on_other_profiles(resolved_target, profile)
        if other:
            current = ProjectConfig(profile=profile).profile
            msg += (
                f"\n  (Target '{resolved_target}' exists on profile '{other}' "
                f"but not on '{current}'. "
                f"Run 'veris env create --name ...' on this profile, "
                f"or switch with 'veris profile use {other}'.)"
            )

    output.print_error(msg)
    sys.exit(1)


def try_get_project_env_id(profile: str | None, target: str | None = None) -> str | None:
    """Safely get env_id from project config, returning None if not found."""
    try:
        found, _ = _lookup_env_id(profile, target)
        return found
    except (OSError, yaml.YAMLError):
        return None


def require_veris_dir() -> Path:
    """Return the .veris directory, exiting if it doesn't exist."""
    veris_dir = Path.cwd() / ".veris"
    if not veris_dir.exists():
        from veris_cli import output

        output.print_error(".veris/ not found. Run 'veris init' first.")
        sys.exit(1)
    return veris_dir


def select_grader_interactive(
    api: Any,
    env_id: str,
    scenario_set_id: str | None = None,
) -> str:
    """Prompt user to select a grader. Pre-selects the one matching scenario_set_id.

    Lists all graders for the environment. Marks matching ones with ★.
    Returns selected grader ID or exits on failure.
    """
    from veris_cli import output, prompts

    graders_result = api.list_graders(environment_id=env_id)
    graders = graders_result.get("graders", [])
    if not graders:
        output.print_error(
            f"No graders found for environment {env_id}. "
            "Generate scenarios first with 'veris scenarios create'."
        )
        sys.exit(1)

    # Find the best default: first grader matching the scenario set
    default_grader_id = None
    if scenario_set_id:
        for g in graders:
            if g.get("scenario_set_id") == scenario_set_id:
                default_grader_id = g.get("id")
                break

    choices = []
    for g in graders:
        created = (g.get("created_at") or "")[:10]
        sset = g.get("scenario_set_id") or "global"
        marker = " ★" if scenario_set_id and g.get("scenario_set_id") == scenario_set_id else ""
        title = f"{g.get('id', '')}  {sset}  {created}{marker}"
        choices.append({"id": g.get("id", ""), "title": title})

    grader_id = prompts.select_from_list(
        "Select a grader:", choices, flag_hint="--grader-id", default=default_grader_id
    )
    if not grader_id:
        output.print_error("No grader selected")
        sys.exit(1)
    return grader_id


def poll_with_spinner(
    fetch_fn: Callable[[], dict],
    format_msg: Callable[[dict], str],
    terminal_states: set[str],
    label: str,
    poll_interval: int = 5,
) -> dict:
    """Generic polling with Rich spinner on TTY, plain lines on non-TTY.

    Used by `veris run` pipeline for stderr progress output.

    Args:
        fetch_fn: Callable that returns the resource dict.
        format_msg: Callable that takes resource dict and returns a status message string.
        terminal_states: Set of status values that indicate completion.
        label: Label for terminal output (e.g. "Simulations", "Evaluation").
        poll_interval: Seconds between polls.

    Returns:
        The final resource dict.
    """
    is_tty = sys.stderr.isatty()
    last_msg = None

    live = None
    if is_tty:
        from rich.console import Console
        from rich.live import Live
        from rich.spinner import Spinner

        stderr_console = Console(stderr=True)
        live = Live(console=stderr_console, refresh_per_second=8, transient=True)
        live.start()

    try:
        while True:
            try:
                data = fetch_fn()
            except Exception as e:
                if live:
                    live.stop()
                click.echo(f"Error: Failed to poll {label.lower()}: {e}", err=True)
                sys.exit(1)

            status = data["status"]
            msg = format_msg(data)

            if status in terminal_states:
                if live:
                    live.stop()
                    icon = "[green]✓[/green]" if status == "completed" else "[red]✗[/red]"
                    stderr_console.print(f"{icon} {label} {status} — {msg}")
                else:
                    icon = "✓" if status == "completed" else "✗"
                    click.echo(f"{icon} {label} {status} — {msg}", err=True)
                return data

            if is_tty:
                live.update(Spinner("dots", text=f"{label}: {msg}"))
            elif msg != last_msg:
                click.echo(f"  {label}: {msg}", err=True)
                last_msg = msg
            time.sleep(poll_interval)
    finally:
        if live:
            live.stop()
