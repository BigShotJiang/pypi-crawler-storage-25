"""Profile management commands: list, get, use, delete, login, org."""

import sys

import click

from veris_cli import output
from veris_cli.config import Config


@click.group()
def profile():
    """Manage named profiles for different environments."""
    pass


@profile.command(name="list")
def profile_list():
    """List all profiles in global config."""
    config = Config()
    profiles = config.list_profiles()
    active = config.get_active_profile() or "default"

    if not profiles:
        output.print_info("No profiles configured. Run 'veris login' to create one.")
        return

    for name in profiles:
        marker = " (active)" if name == active else ""
        output.print_info(f"  {name}{marker}")


@profile.command(name="get")
def profile_get():
    """Show active profile's settings."""
    from veris_cli.config import ProjectConfig

    config = Config()
    project_config = ProjectConfig()

    output.print_info(f"Profile: {config.profile}")

    global_data = config._load_profile()
    if global_data:
        output.print_info("\nGlobal settings (~/.veris/config.yaml):")
        for k, v in global_data.items():
            display_v = v
            if k == "api_key" and v:
                display_v = v[:8] + "..." if len(v) > 8 else v
            output.print_info(f"  {k}: {display_v}")
    else:
        output.print_info("\nNo global settings for this profile.")

    project_data = project_config._load_profile()
    if project_data:
        output.print_info("\nProject settings (.veris/config.yaml):")
        for k, v in project_data.items():
            output.print_info(f"  {k}: {v}")


@profile.command(name="use")
@click.argument("name", required=False, default=None)
def profile_use(name: str | None):
    """Set active profile.

    Without arguments, interactively prompts for profile selection.
    """
    config = Config()
    profiles = config.list_profiles()

    if not name:
        if not profiles:
            output.print_error("No profiles configured. Run 'veris login' to create one.")
            sys.exit(1)

        from veris_cli import prompts

        choices = [{"id": p, "title": p} for p in profiles]
        name = prompts.select_from_list("Select a profile:", choices, flag_hint="NAME")
        if not name:
            output.print_error("No profile selected")
            sys.exit(1)

    if profiles and name not in profiles:
        output.print_error(f"Profile '{name}' does not exist.")
        output.print_info(f"Available profiles: {', '.join(profiles)}")
        sys.exit(1)

    config.set_active_profile(name)
    output.print_success(f"Active profile set to '{name}'")


@profile.command(name="delete")
@click.argument("name")
def profile_delete(name: str):
    """Remove a profile from global config."""
    if name == "default":
        output.print_error("Cannot delete the default profile.")
        sys.exit(1)

    config = Config()
    if config.delete_profile(name):
        output.print_success(f"Profile '{name}' deleted")
    else:
        output.print_error(f"Profile '{name}' not found")
        sys.exit(1)


@profile.command(name="login")
@click.argument("api_key", required=False, default=None)
@click.option(
    "--profile",
    "profile_name",
    default=None,
    help="Profile to log in to (creates it if new). Sets it as the active profile.",
)
@click.option(
    "--backend-url",
    default=None,
    help="Backend URL (default: https://sandbox.api.veris.ai)",
)
@click.option(
    "--org",
    default=None,
    help="Organization ID to scope this profile to (e.g. org_abc123)",
)
@click.option(
    "--console-url",
    default=None,
    help="Console URL (default: https://console.veris.ai)",
)
def profile_login(
    api_key: str | None,
    profile_name: str | None,
    backend_url: str | None,
    org: str | None,
    console_url: str | None,
):
    """Authenticate with Veris (convenience alias for 'veris login').

    Usage:
      veris profile login                           # Browser-based Google login
      veris profile login <api-key>                 # Direct API key login
      veris profile login --profile staging         # Log in under a named profile
      veris profile login --profile staging --org org_abc123
    """
    from veris_cli.commands.auth import _do_login

    _do_login(profile_name, api_key, backend_url, org, console_url)


# --- org subgroup ---


@profile.group(name="org")
def profile_org():
    """Manage organization for the active profile."""
    pass


@profile_org.command(name="set")
@click.argument("org_id")
def org_set(org_id: str):
    """Set organization ID for the active profile."""
    config = Config()
    config.set_organization_id(org_id)
    output.print_success(f"Organization set to '{org_id}' for profile '{config.profile}'")


@profile_org.command(name="rm")
def org_rm():
    """Remove organization ID from the active profile."""
    config = Config()
    if not config.get_organization_id():
        output.print_info(f"No organization set for profile '{config.profile}'")
        return
    config.set_organization_id(None)
    output.print_success(f"Organization removed from profile '{config.profile}'")
