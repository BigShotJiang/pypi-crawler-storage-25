"""Typed loader for .veris/veris.yaml.

Supports two shapes, distinguished at load time:

1. **Single-target (legacy)** — top-level has `services`/`persona`/`agent`.
   Loaded as a VerisYaml with one implicit target whose key is derived from
   the slug of `agent.name` (or a fallback if absent).

2. **Multi-target** — top-level has `version` plus target-named keys,
   each holding `{dockerfile?, services, persona, agent}`.

       version: "1.0"
       my-cool-agent:
         dockerfile: .veris/Dockerfile.sandbox
         services: [...]
         persona: {...}
         agent:
           name: My Cool Agent
       customer-support:
         services: [...]
         persona: {...}
         agent:
           name: Customer Support

Final-stage validation (service keys, persona modality fields, etc.) still
happens server-side at push time. These models just ensure structure, so the
CLI can reliably pick a target, resolve its dockerfile, and serialize the
target block for upload.
"""

from __future__ import annotations

import re
import textwrap
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError

DEFAULT_DOCKERFILE = ".veris/Dockerfile.sandbox"
# Internal placeholder used only when shape A has neither agent.name nor a
# usable repo dir name. Never written to disk; never shown to users.
_FALLBACK_TARGET = "agent"

# Top-level keys that belong to a single-target config body (not to a target map).
# Public so commands/env.py can reuse the same set when detecting/converting shape A.
BODY_KEYS = {"services", "persona", "actor", "agent"}
# Top-level keys that are meta, not targets.
_META_KEYS = {"version"}

# Regex matching a body key at column 0 (used by shape-A → shape-B text conversion).
_BODY_KEY_LINE_RE = re.compile(rf"^({'|'.join(sorted(BODY_KEYS))})\s*:")


class _LooseModel(BaseModel):
    """Base that allows extra fields — server does the final validation."""

    model_config = ConfigDict(extra="allow")


class Service(_LooseModel):
    name: str
    dns_aliases: list[str] | None = None
    config: dict[str, Any] | None = None


class PersonaModality(_LooseModel):
    type: str
    url: str | None = None
    email_address: str | None = None


class Persona(_LooseModel):
    modality: PersonaModality | None = None
    config: dict[str, Any] | None = None
    channels: list[dict[str, Any]] | None = None


class Agent(_LooseModel):
    name: str | None = None
    code_path: str | None = None
    entry_point: str | None = None
    port: int | None = None
    environment: dict[str, Any] | None = None


class Target(_LooseModel):
    """A single simulation target — one agent + its sandbox config."""

    dockerfile: str | None = Field(
        default=None,
        description="Path to the Dockerfile for this target, relative to project root.",
    )
    services: list[Service] | None = None
    persona: Persona | None = None
    actor: dict[str, Any] | None = None
    agent: Agent | None = None

    def resolved_dockerfile(self) -> str:
        """Dockerfile path to use for this target (falls back to the default)."""
        return self.dockerfile or DEFAULT_DOCKERFILE

    def to_upload_dict(self) -> dict[str, Any]:
        """Serialize this target to the dict shape the backend expects.

        Strips the `dockerfile` field (CLI-only) and drops unset/None values.
        """
        data = self.model_dump(exclude_none=True, exclude={"dockerfile"})
        return data


def slugify(value: str) -> str:
    """Lowercase kebab-case slug: 'My Cool Agent!' -> 'my-cool-agent'."""
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


class VerisYaml(_LooseModel):
    """Typed representation of .veris/veris.yaml."""

    version: Any | None = None
    targets: dict[str, Target] = Field(default_factory=dict)
    # True iff the file was parsed as legacy shape A (top-level body keys).
    # Used by env_create to decide whether to auto-migrate to shape B before
    # appending a new target. Excluded from upload_dict-style serializations.
    was_legacy_shape_a: bool = Field(default=False, exclude=True)

    @property
    def target_names(self) -> list[str]:
        return list(self.targets.keys())

    def sole_target_name(self) -> str | None:
        """Return the single target's name if there's exactly one, else None."""
        if len(self.targets) == 1:
            return self.target_names[0]
        return None

    def get_target(self, name: str | None) -> Target:
        """Return the named target.

        - If `name` is None and there's exactly one target, return it.
        - If `name` is None and there are multiple, raise KeyError.
        - Otherwise, look up by exact name.
        """
        if not self.targets:
            raise KeyError("veris.yaml has no targets defined.")
        if name is None:
            if len(self.targets) == 1:
                return next(iter(self.targets.values()))
            raise KeyError(
                f"veris.yaml defines multiple targets: {', '.join(self.target_names)}. "
                "Pass --target <name>."
            )
        if name not in self.targets:
            raise KeyError(
                f"Target '{name}' not found in veris.yaml. "
                f"Available: {', '.join(self.target_names) or '(none)'}"
            )
        return self.targets[name]

    @classmethod
    def from_dict(
        cls,
        raw: dict[str, Any],
        legacy_target_fallback: str | None = None,
    ) -> VerisYaml:
        """Parse a raw dict into a VerisYaml, auto-detecting single/multi shape.

        For shape A (legacy single-target), the synthesized target key is
        derived from agent.name slug, falling back to `legacy_target_fallback`
        (typically the repo directory name slug).
        """
        if not isinstance(raw, dict):
            raise ValueError(f"veris.yaml must be a mapping, got {type(raw).__name__}")

        version = raw.get("version")

        # Single-target detection: top-level has a body key (services/persona/agent).
        is_single_target = any(k in raw for k in BODY_KEYS)

        if is_single_target:
            body = {k: v for k, v in raw.items() if k not in _META_KEYS}
            try:
                target = Target.model_validate(body)
            except ValidationError as e:
                raise ValueError(f"Invalid veris.yaml (single-target): {e}") from e
            target_name = _derive_legacy_target_name(target, legacy_target_fallback)
            return cls(
                version=version,
                targets={target_name: target},
                was_legacy_shape_a=True,
            )

        # Multi-target: every top-level key that's not meta and maps to a dict is a target.
        target_entries = {
            k: v for k, v in raw.items() if k not in _META_KEYS and isinstance(v, dict)
        }

        if not target_entries:
            # Empty / stub file — synthesize a single empty target with a fallback name.
            stub_name = _derive_legacy_target_name(Target(), legacy_target_fallback)
            return cls(version=version, targets={stub_name: Target()})

        targets: dict[str, Target] = {}
        for name, body in target_entries.items():
            try:
                targets[name] = Target.model_validate(body)
            except ValidationError as e:
                raise ValueError(f"Invalid veris.yaml target '{name}': {e}") from e

        return cls(version=version, targets=targets)

    @classmethod
    def load(
        cls,
        path: Path,
        legacy_target_fallback: str | None = None,
    ) -> VerisYaml:
        """Load and parse a veris.yaml file from disk.

        `legacy_target_fallback` is used to name the implicit target for shape A
        (legacy single-target) files when `agent.name` is missing.

        Detection of shape A sets `was_legacy_shape_a=True` on the returned
        object so callers can trigger an interactive migration (prompting the
        user for a target name) before writing the converted file back.
        Use `migrate_shape_a(path, target_name)` to perform the on-disk
        conversion.
        """
        if not path.exists():
            raise FileNotFoundError(f"veris.yaml not found at {path}")
        raw = yaml.safe_load(path.read_text()) or {}
        return cls.from_dict(raw, legacy_target_fallback=legacy_target_fallback)

    @classmethod
    def migrate_shape_a(
        cls,
        path: Path,
        target_name: str,
        agent_name: str | None = None,
    ) -> VerisYaml:
        """Convert a shape-A file on disk to shape B under `target_name` and return the re-parsed result.

        If `agent_name` is provided and the file has no ``agent: name:`` field,
        it is injected before the shape conversion so the resulting shape-B
        block includes the name.
        """
        text = path.read_text()
        if agent_name:
            text = _inject_agent_name(text, agent_name)
        path.write_text(convert_shape_a_to_shape_b(text, target_name))
        # Re-parse — now it's shape B, was_legacy_shape_a will be False.
        raw = yaml.safe_load(path.read_text()) or {}
        return cls.from_dict(raw)


def _inject_agent_name(text: str, agent_name: str) -> str:
    """Insert ``  name: <agent_name>`` after a bare ``agent:`` line in shape-A text.

    No-op if ``agent:`` already has a ``name:`` child or is not present.
    """
    lines = text.splitlines(keepends=True)
    out: list[str] = []
    i = 0
    while i < len(lines):
        out.append(lines[i])
        # Match a top-level "agent:" line (no value on same line)
        if re.match(r"^agent:\s*$", lines[i]):
            # Check if the next line is already "  name:"
            if i + 1 < len(lines) and re.match(r"^\s+name:", lines[i + 1]):
                pass  # already has a name
            else:
                out.append(f"  name: {agent_name}\n")
        i += 1
    return "".join(out)


def convert_shape_a_to_shape_b(text: str, target_name: str) -> str:
    """Indent legacy shape-A body content under a new top-level target key.

    Comment-preserving: text manipulation only. We find the first top-level
    body key (services/persona/actor/agent at column 0), insert
    `<target_name>:` immediately before it, then indent every subsequent line
    by two spaces. `version:` and any leading comments are left untouched.
    """
    lines = text.splitlines(keepends=False)
    first_body_idx = next(
        (i for i, line in enumerate(lines) if _BODY_KEY_LINE_RE.match(line)),
        None,
    )
    if first_body_idx is None:
        return text

    head = lines[:first_body_idx]
    if head and head[-1].strip():
        head.append("")
    head.append(f"{target_name}:")

    body_text = "\n".join(lines[first_body_idx:])
    indented_body = textwrap.indent(body_text, "  ")
    new_text = "\n".join(head) + "\n" + indented_body
    if text.endswith("\n") and not new_text.endswith("\n"):
        new_text += "\n"
    return new_text


def _derive_legacy_target_name(target: Target, fallback: str | None) -> str:
    """Pick an implicit name for a shape-A target.

    Priority: slugified agent.name > caller-provided fallback > _FALLBACK_TARGET.
    Always suffixed with `-env` to match `env create`'s naming convention so
    legacy shape-A files round-trip with config.yaml entries created via the CLI.
    """
    base: str | None = None
    if target.agent and target.agent.name:
        base = slugify(target.agent.name)
    if not base and fallback:
        base = slugify(fallback)
    if not base:
        base = _FALLBACK_TARGET
    if not base.endswith("-env"):
        base = f"{base}-env"
    return base
