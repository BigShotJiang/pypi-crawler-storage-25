"""Markdown summary formatter for the `veris run` pipeline command."""

from __future__ import annotations

from collections import defaultdict


def _fmt_duration(seconds: int | None) -> str:
    if seconds is None:
        return "—"
    m, s = divmod(seconds, 60)
    return f"{m}m {s:02d}s"


def format_markdown_summary(
    run: dict,
    scenario_set: dict,
    simulations: list[dict],
    eval_run: dict,
    console_url: str = "https://console.veris.ai",
) -> str:
    """Build a markdown report from run + evaluation data."""

    lines: list[str] = []
    lines.append("## Veris Simulation Report")
    lines.append("")

    run_id = run["id"]
    eval_run_id = eval_run["id"]

    # Metadata table
    set_title = scenario_set.get("title", "—")
    lines.append("| Field | Value |")
    lines.append("|-------|-------|")
    lines.append(f"| Run | `{run_id}` |")
    lines.append(f"| Eval Run | `{eval_run_id}` |")
    lines.append(f"| Status | {run['status']} |")
    lines.append(f"| Scenario Set | {set_title} |")
    lines.append(f"| Simulations | {len(simulations)} |")
    lines.append(f"| Duration | {_fmt_duration(run.get('duration_seconds'))} |")
    lines.append("")

    # Aggregate grading scores by category
    grading_results = eval_run.get("grading_results") or []
    cat_counts: dict[str, dict[str, int]] = defaultdict(lambda: {"pass": 0, "fail": 0})
    for gr in grading_results:
        if gr.get("status") != "completed":
            continue
        score = (gr.get("result") or {}).get("score") or {}
        for cat_name, cat_data in score.items():
            for _criterion, crit_data in (cat_data.get("score") or {}).items():
                if not crit_data:
                    continue
                result = crit_data.get("result")
                if result == "false":
                    cat_counts[cat_name]["pass"] += 1
                elif result == "true":
                    cat_counts[cat_name]["fail"] += 1

    # Assertion summary
    assertion_results = eval_run.get("assertion_results") or []
    assertion_pass = sum(1 for ar in assertion_results if ar.get("verdict") == "PASS")
    assertion_fail = sum(1 for ar in assertion_results if ar.get("verdict") == "FAIL")
    assertion_total = assertion_pass + assertion_fail

    if cat_counts or assertion_results:
        lines.append("### Results")
        lines.append("")
        lines.append("| Category | Pass | Fail | Score |")
        lines.append("|----------|------|------|-------|")
        for cat in sorted(cat_counts):
            p = cat_counts[cat]["pass"]
            f = cat_counts[cat]["fail"]
            total = p + f
            pct = f"{p / total:.0%}" if total > 0 else "—"
            label = cat.replace("_", " ").title()
            lines.append(f"| {label} | {p} | {f} | {pct} |")
        if assertion_total > 0:
            pct = f"{assertion_pass / assertion_total:.0%}"
            lines.append(
                f"| Scenario-Level Success Criteria | {assertion_pass} | {assertion_fail} | {pct} |"
            )
        lines.append("")

    lines.append(f"[View in Console]({console_url}/evaluations/{run_id}/{eval_run_id})")
    lines.append("")

    return "\n".join(lines)
