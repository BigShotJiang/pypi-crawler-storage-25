"""promptfork CLI — Git for prompts.

Commands:
  push <name> --file <path>         Create or update a prompt with a new version.
  add-test <name> <test_name>       Attach a test case (--input k=v, --expected, --rubric).
  test <name>                       Run prompt across models; --baseline N for regression.
  get <name>                        Show prompt + versions + test cases.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import click
import httpx


API_BASE = os.environ.get("PROMPTFORK_API_BASE", "https://promptfork.online")
API_KEY = os.environ.get("PROMPTFORK_API_KEY", "")

GREEN = "\033[32m"
RED = "\033[31m"
YEL = "\033[33m"
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"


def _client() -> httpx.Client:
    if not API_KEY:
        click.echo("error: PROMPTFORK_API_KEY not set", err=True)
        sys.exit(2)
    return httpx.Client(
        base_url=API_BASE,
        headers={"X-API-Key": API_KEY},
        timeout=600,
    )


def _find_prompt(c: httpx.Client, name: str) -> dict | None:
    r = c.get("/v2/prompts")
    r.raise_for_status()
    for p in r.json().get("prompts", []):
        if p["name"] == name:
            return p
    return None


@click.group()
@click.version_option()
def main():
    """promptfork — Git for prompts."""


@main.command()
@click.argument("name")
@click.option("--file", "file_", type=click.Path(exists=True, dir_okay=False),
              required=True, help="Path to prompt body.")
@click.option("--message", default="update", help="Version message.")
def push(name: str, file_: str, message: str):
    """Create or update a prompt with a new version."""
    body = Path(file_).read_text(encoding="utf-8")
    with _client() as c:
        existing = _find_prompt(c, name)
        if existing:
            r = c.post(f"/v2/prompts/{existing['id']}/versions",
                       json={"body": body, "message": message})
            r.raise_for_status()
            v = r.json()
            click.echo(f"{GREEN}✓{RESET} {name} → v{v['version_num']}  {DIM}({v['id']}){RESET}")
        else:
            r = c.post("/v2/prompts",
                       json={"name": name, "body": body, "message": message})
            r.raise_for_status()
            p = r.json()
            click.echo(f"{GREEN}✓{RESET} created {name} v1  {DIM}({p['id']}){RESET}")


@main.command("add-test")
@click.argument("prompt_name")
@click.argument("test_name")
@click.option("--input", "inputs", multiple=True, help="key=value (repeatable)")
@click.option("--expected", default=None)
@click.option("--rubric", default=None)
def add_test(prompt_name: str, test_name: str, inputs: tuple,
             expected: str | None, rubric: str | None):
    """Attach a test case to a prompt."""
    input_vars = {}
    for kv in inputs:
        if "=" not in kv:
            click.echo(f"error: --input expects key=value, got {kv}", err=True)
            sys.exit(2)
        k, v = kv.split("=", 1)
        input_vars[k] = v
    with _client() as c:
        p = _find_prompt(c, prompt_name)
        if not p:
            click.echo(f"error: prompt '{prompt_name}' not found", err=True)
            sys.exit(2)
        r = c.post(f"/v2/prompts/{p['id']}/test-cases", json={
            "name": test_name, "input_vars": input_vars or None,
            "expected": expected, "rubric": rubric,
        })
        r.raise_for_status()
        click.echo(f"{GREEN}✓{RESET} test '{test_name}' attached to {prompt_name}")


@main.command()
@click.argument("name")
@click.option("--baseline", type=int, default=None,
              help="Compare against version number N (regression check).")
@click.option("--models", default=None,
              help="Comma-separated model ids; default = sonnet+haiku+gpt-4.1.")
def test(name: str, baseline: int | None, models: str | None):
    """Run prompt across models. Exit non-zero on regression."""
    with _client() as c:
        p = _find_prompt(c, name)
        if not p:
            click.echo(f"error: prompt '{name}' not found", err=True)
            sys.exit(2)

        baseline_vid = None
        if baseline is not None:
            r = c.get(f"/v2/prompts/{p['id']}/versions")
            r.raise_for_status()
            for v in r.json().get("versions", []):
                if v["version_num"] == baseline:
                    baseline_vid = v["id"]
                    break
            if not baseline_vid:
                click.echo(f"error: baseline v{baseline} not found", err=True)
                sys.exit(2)
            # Pre-run the baseline so we have outputs to compare against
            click.echo(f"{DIM}→ priming baseline v{baseline}…{RESET}")
            payload = {"version_id": baseline_vid}
            if models:
                payload["models"] = [m.strip() for m in models.split(",")]
            c.post(f"/v2/prompts/{p['id']}/runs", json=payload).raise_for_status()

        click.echo(f"{DIM}→ running {name} v{p.get('current_version_id')}…{RESET}")
        payload = {}
        if baseline_vid:
            payload["baseline_version_id"] = baseline_vid
        if models:
            payload["models"] = [m.strip() for m in models.split(",")]
        r = c.post(f"/v2/prompts/{p['id']}/runs", json=payload)
        r.raise_for_status()
        d = r.json()
        s = d["summary"]
        click.echo()
        click.echo(f"  calls: {s['calls_ok']}/{s['calls_total']} ok  "
                   f"cost: ${s.get('total_cost_usd', 0):.4f}")
        if "regressions" in s:
            tag = (RED if s["regressions"] else GREEN)
            click.echo(f"  judge: {s.get('judged', 0)} compared, "
                       f"{tag}{s['regressions']} regressions{RESET}")
        click.echo(f"  {DIM}run: {API_BASE}/runs/{d['run_id']}{RESET}")
        if s.get("regressions", 0) > 0:
            sys.exit(1)


@main.command()
@click.argument("name")
def get(name: str):
    """Show prompt + versions + test cases."""
    with _client() as c:
        p = _find_prompt(c, name)
        if not p:
            click.echo(f"error: prompt '{name}' not found", err=True)
            sys.exit(2)
        r = c.get(f"/v2/prompts/{p['id']}")
        r.raise_for_status()
        d = r.json()
        click.echo(f"{BOLD}{d['name']}{RESET}  {DIM}({d['id']}){RESET}")
        if d.get("description"):
            click.echo(f"  {d['description']}")
        click.echo(f"\n  versions: {len(d.get('versions', []))}")
        for v in d.get("versions", [])[:5]:
            cur = "*" if v["id"] == d.get("current_version_id") else " "
            msg = f" — {v['message']}" if v.get("message") else ""
            click.echo(f"    {cur} v{v['version_num']}{msg}")
        click.echo(f"\n  test cases: {len(d.get('test_cases', []))}")
        for t in d.get("test_cases", []):
            click.echo(f"    • {t['name']}")


if __name__ == "__main__":
    main()
