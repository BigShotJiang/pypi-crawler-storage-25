# promptfork

Git for prompts. Cross-model regression testing CLI.

## Install

```bash
pip install promptfork
```

## Quick start

```bash
export PROMPTFORK_API_KEY=pf_xxxxx

# 1. Init a prompt + first version from a file
promptfork push summarize_ticket --file prompts/summarize.txt --message "initial"

# 2. Add a test case
promptfork add-test summarize_ticket angry_refund \
  --input ticket="I want my money back!" \
  --rubric "must mention refund"

# 3. Run across models
promptfork test summarize_ticket

# 4. Compare against a baseline version (regression check)
promptfork test summarize_ticket --baseline 1
```

Exits non-zero on regression — drop it into CI.

## Config

`PROMPTFORK_API_KEY` — your account key from https://promptfork.online/dashboard
`PROMPTFORK_API_BASE` — defaults to `https://promptfork.online`

## License

MIT.
