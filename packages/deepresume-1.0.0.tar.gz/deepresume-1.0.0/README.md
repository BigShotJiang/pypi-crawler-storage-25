# DeepResume

> AI career agent that tailors your resume for every job -- 10x your interview chances in 30 seconds.

[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![PyPI version](https://img.shields.io/pypi/v/deepresume?style=for-the-badge&logo=pypi&color=3775A9)](https://pypi.org/project/deepresume/)

## What It Does

DeepResume uses AI to analyze job listings and tailor your resume for maximum ATS (Applicant Tracking System) compatibility. It goes beyond simple keyword matching -- it understands context, rewrites your experience bullets with impact, and generates cover letters that get noticed.

```
Your Resume  +  Job Listing  =  Tailored Resume + Cover Letter + Interview Prep
```

## Features

- **Multi-format resume parsing** -- PDF, DOCX, JSON, or plain text
- **ATS optimization** -- keyword density analysis, compatibility checks, score breakdown
- **AI-powered tailoring** -- rewrites summary, skills, and experience for each job
- **Cover letter generation** -- 5 tone options (professional, enthusiastic, conversational, formal, creative)
- **Batch processing** -- tailor for multiple jobs in one run
- **Interview preparation** -- generates likely questions based on the job listing
- **Match scoring** -- detailed breakdown of keyword, skills, experience, and education match
- **Security-first** -- no personal data in logs, input sanitization, API keys via env vars only

## Demo Flow

```
$ deepresume tailor resume.json "https://jobs.company.com/senior-dev-123"

  ____                      _     _____
 |  _ \  ___  ___ _ __ ___ | |__ | ____|_  _____  ___
 | | | |/ _ \/ _ \ '_ ` _ \| '_ \|  _| \ \/ / _ \/ __|
 | |_| |  __/  __/ | | | | | |_) | |___ >  <  __/\__ \
 |____/ \___|\___|_| |_| |_|_.__/|_____/_/\_\___||___/

Resume: resume.json
Job: https://jobs.company.com/senior-dev-123

Processing...

┌─────────────────────────────────────────────────────┐
│            Resume-Job Match Analysis                 │
├──────────────┬──────────┬───────────────────────────┤
│ Category     │ Score    │ Bar                        │
├──────────────┼──────────┼───────────────────────────┤
│ Overall      │ 82.5%    │ ||||||||||||||....         │
│ Keywords     │ 85.0%    │ |||||||||||||||...         │
│ Skills       │ 75.0%    │ |||||||||||||......        │
│ Experience   │ 88.0%    │ ||||||||||||||||..         │
│ Education    │ 90.0%    │ |||||||||||||||||.         │
└──────────────┴──────────┴───────────────────────────┘

Missing Keywords: kubernetes, terraform, ci/cd pipelines

Generated files:
  [report] ./deepresume_output/analysis_report.md
  [resume] ./deepresume_output/tailored_resume.pdf
  [cover_letter] ./deepresume_output/cover_letter.pdf
  [interview_prep] ./deepresume_output/interview_prep.md

Done! Your tailored resume is ready.
```

## Installation

```bash
# Install from PyPI
pip install deepresume

# Or clone the repository
git clone https://github.com/theihtisham/deep-resume.git
cd deep-resume

# Create a virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -e ".[dev]"

# Set your API key
export OPENAI_API_KEY="your-key-here"
```

### Requirements

- Python 3.10+
- OpenAI API key (or compatible API endpoint)

## Usage

### Tailor Resume for a Job

```bash
# From a job URL
deepresume tailor resume.pdf "https://linkedin.com/jobs/view/123456"

# From pasted job text
deepresume tailor resume.json "Senior Python Developer at TechCorp. Requirements: 5+ years..."

# Specify output format and tone
deepresume tailor resume.docx "https://jobs.example.com/123" --format markdown --tone enthusiastic

# Batch: tailor for multiple jobs
deepresume tailor resume.json \
  "https://jobs.company.com/role-1" \
  "https://jobs.company.com/role-2" \
  "https://jobs.company.com/role-3"
```

### Analyze Match (No Output Files)

```bash
# Quick analysis of how well your resume matches
deepresume analyze resume.pdf "Job listing text or URL"
```

### Generate Cover Letter Only

```bash
# Generate a cover letter with specific tone
deepresume cover-letter resume.json "Job listing" --tone creative --format docx
```

### Interview Preparation

```bash
# Generate interview questions from job listing
deepresume interview resume.json "Job listing URL or text"
```

### ATS Compatibility Check (No API Key Needed)

```bash
# Check your resume for common ATS issues
deepresume check resume.pdf
```

### Configuration Info

```bash
deepresume info
```

## CLI Commands

| Command | Description | Requires API Key |
|---------|-------------|-----------------|
| `tailor` | Full pipeline: analyze, tailor, generate resume + cover letter | Yes |
| `analyze` | Score resume-job match, show missing keywords | Yes |
| `cover-letter` | Generate customized cover letter | Yes |
| `interview` | Generate interview preparation questions | Yes |
| `check` | Check resume for ATS compatibility issues | No |
| `info` | Show version and configuration info | No |

## Configuration

All configuration is via environment variables or CLI flags:

| Variable | Default | Description |
|----------|---------|-------------|
| `OPENAI_API_KEY` | (required) | Your API key |
| `OPENAI_API_BASE` | `https://api.openai.com/v1` | API base URL (for compatible endpoints) |
| `DEEPRESUME_MODEL` | `gpt-4` | AI model to use |
| `DEEPRESUME_MAX_TOKENS` | `4096` | Max response tokens |
| `DEEPRESUME_TEMPERATURE` | `0.7` | Response randomness (0-2) |
| `DEEPRESUME_TIMEOUT` | `60` | API timeout in seconds |
| `DEEPRESUME_LOG_LEVEL` | `WARNING` | Logging level |
| `DEEPRESUME_SANITIZE_LOGS` | `true` | Strip PII from logs |

## JSON Resume Format

For best results, use a structured JSON resume:

```json
{
  "contact": {
    "name": "Jane Developer",
    "email": "jane@example.com",
    "phone": "(555) 123-4567",
    "location": "San Francisco, CA",
    "linkedin": "https://linkedin.com/in/janedoe",
    "github": "https://github.com/janedoe"
  },
  "summary": "Senior Python developer with 5 years of web development experience.",
  "skills": ["Python", "Django", "PostgreSQL", "Docker", "AWS"],
  "experience": [
    {
      "title": "Senior Developer",
      "company": "TechCorp",
      "start_date": "Jan 2020",
      "end_date": "Present",
      "descriptions": [
        "Built REST APIs serving 1M requests/day",
        "Led team of 5 engineers"
      ]
    }
  ],
  "education": [
    {
      "degree": "BS Computer Science",
      "institution": "State University",
      "graduation_date": "2019",
      "gpa": "3.8"
    }
  ],
  "certifications": ["AWS Solutions Architect"]
}
```

## Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=deepresume --cov-report=html

# Run specific test file
pytest tests/test_parsers.py -v

# Skip integration tests (require API key)
pytest -m "not integration"
```

## Security

- **No personal data in logs** -- PII (emails, phone numbers, SSNs) is automatically stripped from all log output
- **Input sanitization** -- all user input is sanitized to prevent injection attacks
- **API keys via env vars only** -- credentials are never stored in config files or logs
- **No data persistence** -- DeepResume does not store or transmit your resume data beyond the AI API call

## Project Structure

```
10-deep-resume/
  deepresume/
    __init__.py              # Package init with version
    cli.py                   # Click CLI interface
    config.py                # Environment configuration
    exceptions.py            # Custom exception hierarchy
    models.py                # Pydantic data models
    orchestrator.py          # Main pipeline orchestrator
    ai_engine.py             # OpenAI API interface
    utils.py                 # Text processing utilities
    parsers/
      __init__.py
      resume_parser.py       # PDF/DOCX/JSON resume parsing
      job_parser.py          # URL/text job listing parsing
    analyzers/
      __init__.py
      ats_analyzer.py        # ATS compatibility analysis
    generators/
      __init__.py
      resume_generator.py    # PDF/DOCX/Markdown output
      cover_letter_generator.py
    templates/
      __init__.py
      report.md.j2           # Analysis report template
      interview_prep.md.j2   # Interview prep template
  tests/
    test_models.py
    test_utils.py
    test_parsers.py
    test_analyzers.py
    test_generators.py
    test_config.py
    test_exceptions.py
    test_cli.py
  pyproject.toml
  requirements.txt
  .gitignore
  LICENSE
  README.md
```

## License

[MIT](LICENSE) -- use it however you like.

---

Built with Python, Click, Pydantic, ReportLab, python-docx, and OpenAI.
