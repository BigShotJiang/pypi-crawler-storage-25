"""Custom exceptions for DeepResume."""


class DeepResumeError(Exception):
    """Base exception for all DeepResume errors."""


class ConfigurationError(DeepResumeError):
    """Raised when configuration is invalid or missing."""


class ParseError(DeepResumeError):
    """Raised when resume or job listing parsing fails."""


class AIError(DeepResumeError):
    """Raised when AI API calls fail."""


class OutputError(DeepResumeError):
    """Raised when output generation fails."""


class JobFetchError(DeepResumeError):
    """Raised when fetching a job listing URL fails."""


class ValidationError(DeepResumeError):
    """Raised when input validation fails."""
