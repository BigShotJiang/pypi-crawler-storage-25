"""Generate tailored resume output in PDF, DOCX, and Markdown formats."""

from __future__ import annotations

import io
import re
from pathlib import Path
from typing import Any

from deepresume.exceptions import OutputError
from deepresume.models import (
    ExperienceEntry,
    OutputFormat,
    ResumeData,
    TailoredResume,
)


def _get_attr(data: Any, key: str, default: str = "") -> str:
    """Get a value from either a dict or an object with attributes."""
    if isinstance(data, dict):
        return str(data.get(key, default))
    return str(getattr(data, key, default))


def _get_list(data: Any, key: str) -> list[Any]:
    """Get a list value from either a dict or an object with attributes."""
    if isinstance(data, dict):
        return data.get(key, [])
    return getattr(data, key, [])


class ResumeGenerator:
    """Generate tailored resume files in multiple formats."""

    def generate(
        self,
        tailored: TailoredResume,
        output_path: str | Path,
        fmt: OutputFormat = OutputFormat.PDF,
    ) -> Path:
        """Generate a tailored resume file.

        Args:
            tailored: Tailored resume data.
            output_path: Output file path.
            fmt: Output format.

        Returns:
            Path to generated file.

        Raises:
            OutputError: If generation fails.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            if fmt == OutputFormat.MARKDOWN:
                return self._generate_markdown(tailored, output_path)
            elif fmt == OutputFormat.DOCX:
                return self._generate_docx(tailored, output_path)
            elif fmt == OutputFormat.PDF:
                return self._generate_pdf(tailored, output_path)
            else:
                raise OutputError(f"Unsupported format: {fmt}")
        except OutputError:
            raise
        except Exception as e:
            raise OutputError(f"Failed to generate {fmt.value} resume: {e}") from e

    def _get_experience_entries(self, tailored: TailoredResume) -> list[Any]:
        """Get unified experience entries (tailored or original)."""
        if tailored.tailored_experience:
            return tailored.tailored_experience
        return tailored.original_resume.experience

    def generate_markdown_text(self, tailored: TailoredResume) -> str:
        """Generate markdown text for a tailored resume.

        Args:
            tailored: Tailored resume data.

        Returns:
            Markdown string.
        """
        resume = tailored.original_resume
        contact = resume.contact
        sections: list[str] = []

        # Header with name
        name = contact.name or "Your Name"
        sections.append(f"# {name}")
        sections.append("")

        # Contact line
        contact_parts: list[str] = []
        if contact.email:
            contact_parts.append(contact.email)
        if contact.phone:
            contact_parts.append(contact.phone)
        if contact.location:
            contact_parts.append(contact.location)
        if contact.linkedin:
            contact_parts.append(f"[LinkedIn]({contact.linkedin})")
        if contact.github:
            contact_parts.append(f"[GitHub]({contact.github})")
        if contact.website:
            contact_parts.append(f"[Website]({contact.website})")

        if contact_parts:
            sections.append(" | ".join(contact_parts))
            sections.append("")

        # Professional Summary
        summary = tailored.tailored_summary or resume.summary
        if summary:
            sections.append("## Professional Summary")
            sections.append("")
            sections.append(summary)
            sections.append("")

        # Skills
        skills = tailored.tailored_skills or resume.skills
        if skills:
            sections.append("## Skills")
            sections.append("")
            sections.append(", ".join(skills))
            sections.append("")

        # Work Experience
        experience = self._get_experience_entries(tailored)
        if experience:
            sections.append("## Work Experience")
            sections.append("")
            for exp in experience:
                title = _get_attr(exp, "title")
                company = _get_attr(exp, "company")
                location = _get_attr(exp, "location")
                start = _get_attr(exp, "start_date")
                end = _get_attr(exp, "end_date")
                descriptions = _get_list(exp, "descriptions")

                header_parts = [f"**{title}**"]
                if company:
                    header_parts.append(f"| {company}")
                if location:
                    header_parts.append(f"| {location}")
                sections.append(" ".join(header_parts))

                if start or end:
                    sections.append(f"*{start} - {end}*")
                sections.append("")

                for desc in descriptions:
                    sections.append(f"- {desc}")
                sections.append("")

        # Education
        if resume.education:
            sections.append("## Education")
            sections.append("")
            for edu in resume.education:
                line = f"**{edu.degree}**"
                if edu.institution:
                    line += f" | {edu.institution}"
                sections.append(line)
                if edu.graduation_date:
                    sections.append(f"*{edu.graduation_date}*")
                if edu.gpa:
                    sections.append(f"GPA: {edu.gpa}")
                for highlight in edu.highlights:
                    sections.append(f"- {highlight}")
                sections.append("")

        # Certifications
        if resume.certifications:
            sections.append("## Certifications")
            sections.append("")
            for cert in resume.certifications:
                sections.append(f"- {cert}")
            sections.append("")

        # Projects
        if resume.projects:
            sections.append("## Projects")
            sections.append("")
            for proj in resume.projects:
                proj_name = proj.get("name", proj.get("title", ""))
                desc = proj.get("description", "")
                link = proj.get("url", proj.get("link", ""))
                line = f"**{proj_name}**"
                if link:
                    line += f" — [Link]({link})"
                sections.append(line)
                if desc:
                    sections.append(f"  {desc}")
                sections.append("")

        return "\n".join(sections)

    def _generate_markdown(self, tailored: TailoredResume, path: Path) -> Path:
        """Write markdown resume to file."""
        content = self.generate_markdown_text(tailored)
        path.write_text(content, encoding="utf-8")
        return path

    def _generate_docx(self, tailored: TailoredResume, path: Path) -> Path:
        """Generate DOCX resume."""
        try:
            from docx import Document
            from docx.shared import Inches, Pt, RGBColor
        except ImportError:
            raise OutputError(
                "python-docx is required for DOCX output. "
                "Install with: pip install python-docx"
            )

        doc = Document()
        resume = tailored.original_resume
        contact = resume.contact

        # Name
        name = contact.name or "Your Name"
        name_para = doc.add_heading(name, level=0)
        name_para.alignment = 1  # Center

        # Contact info
        contact_parts: list[str] = []
        if contact.email:
            contact_parts.append(contact.email)
        if contact.phone:
            contact_parts.append(contact.phone)
        if contact.location:
            contact_parts.append(contact.location)
        if contact.linkedin:
            contact_parts.append(contact.linkedin)
        if contact.github:
            contact_parts.append(contact.github)
        if contact_parts:
            contact_para = doc.add_paragraph(" | ".join(contact_parts))
            contact_para.alignment = 1
            for run in contact_para.runs:
                run.font.size = Pt(10)
                run.font.color.rgb = RGBColor(100, 100, 100)

        # Summary
        summary = tailored.tailored_summary or resume.summary
        if summary:
            doc.add_heading("Professional Summary", level=2)
            doc.add_paragraph(summary)

        # Skills
        skills = tailored.tailored_skills or resume.skills
        if skills:
            doc.add_heading("Skills", level=2)
            doc.add_paragraph(", ".join(skills))

        # Experience
        experience = self._get_experience_entries(tailored)
        if experience:
            doc.add_heading("Work Experience", level=2)
            for exp in experience:
                title = _get_attr(exp, "title")
                company = _get_attr(exp, "company")
                start = _get_attr(exp, "start_date")
                end = _get_attr(exp, "end_date")
                descriptions = _get_list(exp, "descriptions")

                header = title
                if company:
                    header += f" — {company}"
                if start or end:
                    header += f" ({start} - {end})"

                p = doc.add_paragraph()
                run = p.add_run(header)
                run.bold = True

                for desc in descriptions:
                    doc.add_paragraph(str(desc), style="List Bullet")

        # Education
        if resume.education:
            doc.add_heading("Education", level=2)
            for edu in resume.education:
                header = edu.degree
                if edu.institution:
                    header += f" — {edu.institution}"
                p = doc.add_paragraph()
                run = p.add_run(header)
                run.bold = True
                if edu.graduation_date:
                    p.add_run(f" ({edu.graduation_date})")
                if edu.gpa:
                    doc.add_paragraph(f"GPA: {edu.gpa}")

        # Certifications
        if resume.certifications:
            doc.add_heading("Certifications", level=2)
            for cert in resume.certifications:
                doc.add_paragraph(cert, style="List Bullet")

        # Projects
        if resume.projects:
            doc.add_heading("Projects", level=2)
            for proj in resume.projects:
                proj_name = proj.get("name", proj.get("title", "Project"))
                desc = proj.get("description", "")
                p = doc.add_paragraph()
                run = p.add_run(proj_name)
                run.bold = True
                if desc:
                    p.add_run(f": {desc}")

        doc.save(str(path))
        return path

    def _generate_pdf(self, tailored: TailoredResume, path: Path) -> Path:
        """Generate PDF resume using reportlab."""
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import inch
            from reportlab.lib.colors import HexColor
            from reportlab.platypus import (
                SimpleDocTemplate,
                Paragraph,
                Spacer,
                HRFlowable,
            )
        except ImportError:
            raise OutputError(
                "reportlab is required for PDF output. "
                "Install with: pip install reportlab"
            )

        doc = SimpleDocTemplate(
            str(path),
            pagesize=letter,
            topMargin=0.5 * inch,
            bottomMargin=0.5 * inch,
            leftMargin=0.75 * inch,
            rightMargin=0.75 * inch,
        )

        styles = getSampleStyleSheet()

        # Custom styles
        name_style = ParagraphStyle(
            "ResumeName",
            parent=styles["Title"],
            fontSize=22,
            spaceAfter=4,
            textColor=HexColor("#1a1a2e"),
        )
        contact_style = ParagraphStyle(
            "ResumeContact",
            parent=styles["Normal"],
            fontSize=9,
            textColor=HexColor("#555555"),
            alignment=1,
            spaceAfter=12,
        )
        section_style = ParagraphStyle(
            "ResumeSection",
            parent=styles["Heading2"],
            fontSize=13,
            textColor=HexColor("#16213e"),
            spaceBefore=14,
            spaceAfter=6,
            borderWidth=0,
            borderPadding=0,
        )
        body_style = ParagraphStyle(
            "ResumeBody",
            parent=styles["Normal"],
            fontSize=10,
            leading=14,
            spaceAfter=4,
        )
        bullet_style = ParagraphStyle(
            "ResumeBullet",
            parent=styles["Normal"],
            fontSize=10,
            leading=14,
            leftIndent=20,
            bulletIndent=8,
            spaceAfter=2,
        )
        job_header_style = ParagraphStyle(
            "JobHeader",
            parent=styles["Normal"],
            fontSize=11,
            leading=14,
            spaceAfter=2,
        )

        story: list[Any] = []
        resume = tailored.original_resume
        contact = resume.contact

        # Name
        name = contact.name or "Your Name"
        story.append(Paragraph(name, name_style))

        # Contact line
        contact_parts: list[str] = []
        if contact.email:
            contact_parts.append(contact.email)
        if contact.phone:
            contact_parts.append(contact.phone)
        if contact.location:
            contact_parts.append(contact.location)
        if contact.linkedin:
            contact_parts.append(contact.linkedin)
        if contact.github:
            contact_parts.append(contact.github)
        if contact_parts:
            story.append(Paragraph(" | ".join(contact_parts), contact_style))

        story.append(HRFlowable(width="100%", thickness=1, color=HexColor("#16213e")))

        # Summary
        summary = tailored.tailored_summary or resume.summary
        if summary:
            story.append(Spacer(1, 6))
            story.append(Paragraph("PROFESSIONAL SUMMARY", section_style))
            story.append(Paragraph(summary, body_style))

        # Skills
        skills = tailored.tailored_skills or resume.skills
        if skills:
            story.append(Spacer(1, 6))
            story.append(Paragraph("SKILLS", section_style))
            skills_text = ", ".join(skills)
            story.append(Paragraph(skills_text, body_style))

        # Experience
        experience = self._get_experience_entries(tailored)
        if experience:
            story.append(Spacer(1, 6))
            story.append(Paragraph("WORK EXPERIENCE", section_style))

            for exp in experience:
                title = _get_attr(exp, "title")
                company = _get_attr(exp, "company")
                start = _get_attr(exp, "start_date")
                end = _get_attr(exp, "end_date")
                descriptions = _get_list(exp, "descriptions")

                header = f"<b>{title}</b>"
                if company:
                    header += f" — {company}"
                if start or end:
                    header += f" ({start} - {end})"
                story.append(Paragraph(header, job_header_style))

                for desc in descriptions:
                    safe_desc = self._escape_html(str(desc))
                    story.append(
                        Paragraph(f"<bullet>&bull;</bullet> {safe_desc}", bullet_style)
                    )

        # Education
        if resume.education:
            story.append(Spacer(1, 6))
            story.append(Paragraph("EDUCATION", section_style))
            for edu in resume.education:
                header = f"<b>{edu.degree}</b>"
                if edu.institution:
                    header += f" — {edu.institution}"
                if edu.graduation_date:
                    header += f" ({edu.graduation_date})"
                story.append(Paragraph(header, job_header_style))
                if edu.gpa:
                    story.append(Paragraph(f"GPA: {edu.gpa}", bullet_style))
                for highlight in edu.highlights:
                    safe = self._escape_html(highlight)
                    story.append(
                        Paragraph(f"<bullet>&bull;</bullet> {safe}", bullet_style)
                    )

        # Certifications
        if resume.certifications:
            story.append(Spacer(1, 6))
            story.append(Paragraph("CERTIFICATIONS", section_style))
            for cert in resume.certifications:
                safe = self._escape_html(cert)
                story.append(
                    Paragraph(f"<bullet>&bull;</bullet> {safe}", bullet_style)
                )

        # Projects
        if resume.projects:
            story.append(Spacer(1, 6))
            story.append(Paragraph("PROJECTS", section_style))
            for proj in resume.projects:
                proj_name = proj.get("name", proj.get("title", "Project"))
                desc = proj.get("description", "")
                header = f"<b>{self._escape_html(proj_name)}</b>"
                if desc:
                    header += f": {self._escape_html(desc)}"
                story.append(Paragraph(header, bullet_style))

        doc.build(story)
        return path

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters for reportlab Paragraphs."""
        text = text.replace("&", "&amp;")
        text = text.replace("<", "&lt;")
        text = text.replace(">", "&gt;")
        return text
