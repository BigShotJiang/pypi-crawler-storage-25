"""Cover letter output generator."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from deepresume.exceptions import OutputError
from deepresume.models import TailoredResume


class CoverLetterGenerator:
    """Generate cover letter files in PDF, DOCX, and Markdown formats."""

    def generate_markdown(
        self,
        tailored: TailoredResume,
        cover_letter_text: str,
        output_path: str | Path,
    ) -> Path:
        """Write cover letter as Markdown.

        Args:
            tailored: Tailored resume with job and contact info.
            cover_letter_text: Generated cover letter text.
            output_path: Output file path.

        Returns:
            Path to generated file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        resume = tailored.original_resume
        contact = resume.contact

        lines: list[str] = []
        lines.append(f"**{contact.name or 'Your Name'}**")
        if contact.email:
            lines.append(contact.email)
        if contact.phone:
            lines.append(contact.phone)
        if contact.location:
            lines.append(contact.location)
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append(cover_letter_text)

        output_path.write_text("\n".join(lines), encoding="utf-8")
        return output_path

    def generate_docx(
        self,
        tailored: TailoredResume,
        cover_letter_text: str,
        output_path: str | Path,
    ) -> Path:
        """Generate cover letter as DOCX.

        Args:
            tailored: Tailored resume with job and contact info.
            cover_letter_text: Generated cover letter text.
            output_path: Output file path.

        Returns:
            Path to generated file.
        """
        try:
            from docx import Document
            from docx.shared import Pt, Inches
        except ImportError:
            raise OutputError(
                "python-docx is required for DOCX output. "
                "Install with: pip install python-docx"
            )

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        doc = Document()
        resume = tailored.original_resume
        contact = resume.contact

        # Header with contact info
        name = contact.name or "Your Name"
        p = doc.add_paragraph()
        run = p.add_run(name)
        run.bold = True
        run.font.size = Pt(14)

        contact_parts: list[str] = []
        if contact.email:
            contact_parts.append(contact.email)
        if contact.phone:
            contact_parts.append(contact.phone)
        if contact.location:
            contact_parts.append(contact.location)
        if contact_parts:
            doc.add_paragraph(" | ".join(contact_parts))

        doc.add_paragraph("")  # Spacer

        # Cover letter body
        for paragraph_text in cover_letter_text.split("\n\n"):
            paragraph_text = paragraph_text.strip()
            if paragraph_text:
                doc.add_paragraph(paragraph_text)

        # Closing
        doc.add_paragraph("")
        closing = doc.add_paragraph()
        closing.add_run("Sincerely,").bold = False
        doc.add_paragraph(name)

        doc.save(str(output_path))
        return output_path

    def generate_pdf(
        self,
        tailored: TailoredResume,
        cover_letter_text: str,
        output_path: str | Path,
    ) -> Path:
        """Generate cover letter as PDF.

        Args:
            tailored: Tailored resume with job and contact info.
            cover_letter_text: Generated cover letter text.
            output_path: Output file path.

        Returns:
            Path to generated file.
        """
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import inch
            from reportlab.lib.colors import HexColor
            from reportlab.platypus import (
                SimpleDocTemplate,
                Paragraph,
                Spacer,
            )
        except ImportError:
            raise OutputError(
                "reportlab is required for PDF output. "
                "Install with: pip install reportlab"
            )

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        doc = SimpleDocTemplate(
            str(output_path),
            pagesize=letter,
            topMargin=1 * inch,
            bottomMargin=1 * inch,
            leftMargin=1 * inch,
            rightMargin=1 * inch,
        )

        styles = getSampleStyleSheet()
        resume = tailored.original_resume
        contact = resume.contact

        name_style = ParagraphStyle(
            "CLName",
            parent=styles["Heading1"],
            fontSize=16,
            spaceAfter=4,
        )
        contact_style = ParagraphStyle(
            "CLContact",
            parent=styles["Normal"],
            fontSize=9,
            textColor=HexColor("#555555"),
            spaceAfter=12,
        )
        body_style = ParagraphStyle(
            "CLBody",
            parent=styles["Normal"],
            fontSize=11,
            leading=16,
            spaceAfter=8,
        )

        story: list[Any] = []

        # Header
        name = contact.name or "Your Name"
        story.append(Paragraph(name, name_style))

        contact_parts: list[str] = []
        if contact.email:
            contact_parts.append(contact.email)
        if contact.phone:
            contact_parts.append(contact.phone)
        if contact.location:
            contact_parts.append(contact.location)
        if contact_parts:
            story.append(Paragraph(" | ".join(contact_parts), contact_style))

        story.append(Spacer(1, 24))

        # Cover letter body
        for paragraph_text in cover_letter_text.split("\n\n"):
            paragraph_text = paragraph_text.strip()
            if paragraph_text:
                safe = self._escape_html(paragraph_text)
                story.append(Paragraph(safe, body_style))

        # Closing
        story.append(Spacer(1, 20))
        story.append(Paragraph("Sincerely,", body_style))
        story.append(Spacer(1, 24))
        story.append(Paragraph(name, body_style))

        doc.build(story)
        return output_path

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters for reportlab Paragraphs."""
        text = text.replace("&", "&amp;")
        text = text.replace("<", "&lt;")
        text = text.replace(">", "&gt;")
        return text
