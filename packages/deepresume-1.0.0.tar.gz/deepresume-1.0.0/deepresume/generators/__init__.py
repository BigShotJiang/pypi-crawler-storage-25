"""Output generators for resumes and cover letters."""

from deepresume.generators.resume_generator import ResumeGenerator
from deepresume.generators.cover_letter_generator import CoverLetterGenerator

__all__ = ["ResumeGenerator", "CoverLetterGenerator"]
