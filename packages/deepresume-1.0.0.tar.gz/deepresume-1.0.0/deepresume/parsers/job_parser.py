"""Job listing parser supporting URLs and raw text."""

from __future__ import annotations

import re
from typing import Any

from deepresume.exceptions import JobFetchError, ParseError, ValidationError
from deepresume.models import JobListing
from deepresume.utils import clean_html, sanitize_input


class JobParser:
    """Parse job listings from URLs or raw text into structured data."""

    def parse(self, source: str) -> JobListing:
        """Parse a job listing from URL or text.

        Args:
            source: Job listing URL or pasted text.

        Returns:
            Structured JobListing.

        Raises:
            ValidationError: If source is empty.
            JobFetchError: If URL fetching fails.
        """
        source = source.strip()
        if not source:
            raise ValidationError("Job listing source is empty.")

        if self._is_url(source):
            return self._parse_url(source)
        return self._parse_text(source)

    def _is_url(self, text: str) -> bool:
        """Check if text looks like a URL."""
        return bool(re.match(r"https?://", text.strip(), re.IGNORECASE))

    def _parse_url(self, url: str) -> JobListing:
        """Fetch and parse a job listing from a URL."""
        try:
            import requests

            headers = {
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0.0.0 Safari/537.36"
                ),
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            }
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()
        except ImportError:
            raise JobFetchError(
                "requests is required for URL fetching. Install with: pip install requests"
            )
        except Exception as e:
            raise JobFetchError(f"Failed to fetch job listing from {url}: {e}") from e

        text = clean_html(response.text)
        if not text.strip():
            raise JobFetchError(f"No content extracted from {url}")

        return self._extract_job(text, url=url)

    def _parse_text(self, text: str) -> JobListing:
        """Parse a job listing from pasted text."""
        text = sanitize_input(text)
        if not text:
            raise ValidationError("Job listing text is empty after sanitization.")
        return self._extract_job(text)

    def _extract_job(self, text: str, url: str = "") -> JobListing:
        """Extract structured job data from text.

        Uses heuristic parsing to identify title, company, requirements, etc.
        """
        lines = text.split("\n")
        lines = [l.strip() for l in lines if l.strip()]

        title = self._extract_title(lines)
        company = self._extract_company(text)
        location = self._extract_location(text)
        requirements = self._extract_section(text, "requirements")
        responsibilities = self._extract_section(text, "responsibilities")
        benefits = self._extract_section(text, "benefits")

        return JobListing(
            title=title,
            company=company,
            location=location,
            description=text[:500],
            requirements=requirements,
            responsibilities=responsibilities,
            benefits=benefits,
            url=url,
            raw_text=text,
        )

    def _extract_title(self, lines: list[str]) -> str:
        """Extract job title from first meaningful lines."""
        # Skip common headers
        skip_patterns = {"job", "career", "opportunity", "position"}
        for line in lines[:5]:
            words = line.lower().split()
            if len(words) > 2 and not all(w in skip_patterns for w in words):
                return line
        return lines[0] if lines else ""

    def _extract_company(self, text: str) -> str:
        """Try to extract company name from text."""
        patterns = [
            r"(?:at|by|for|company[:\s]+)\s*([A-Z][A-Za-z0-9&\s]+?)(?:\s*[,.]|\s+(?:is|seeks|looking))",
            r"company[:\s]+(.+?)(?:\n|$)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                company = match.group(1).strip()
                if len(company) < 50:
                    return company
        return ""

    def _extract_location(self, text: str) -> str:
        """Extract job location."""
        patterns = [
            r"(?:location|city|address|where)[:\s]+(.+?)(?:\n|$)",
            r"([A-Z][a-z]+(?:\s[A-Z][a-z]+)*,\s*[A-Z]{2})(?:\s|$)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1).strip()
        return ""

    def _extract_section(self, text: str, section_name: str) -> list[str]:
        """Extract bullet points from a named section."""
        pattern = re.compile(
            rf"{section_name}[:\s\-]+(.*?)(?=\n\n|\n[A-Z][A-Za-z]+[:\s]|\Z)",
            re.DOTALL | re.IGNORECASE,
        )
        match = pattern.search(text)
        if not match:
            return []

        section_text = match.group(1)
        bullets = re.split(r"\n", section_text)
        items: list[str] = []
        for bullet in bullets:
            bullet = bullet.strip()
            if not bullet:
                continue
            # Clean bullet markers
            bullet = re.sub(r"^[-*\u2022\u2013\u2023]\s*", "", bullet)
            bullet = re.sub(r"^\d+[.)]\s*", "", bullet)
            if bullet and len(bullet) > 3:
                items.append(bullet)
        return items
