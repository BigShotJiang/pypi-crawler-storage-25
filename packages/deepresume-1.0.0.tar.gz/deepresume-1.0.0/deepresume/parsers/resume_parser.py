"""Resume parser supporting PDF, DOCX, and JSON formats."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from deepresume.exceptions import ParseError, ValidationError
from deepresume.models import (
    ContactInfo,
    EducationEntry,
    ExperienceEntry,
    ResumeData,
)
from deepresume.utils import sanitize_input


class ResumeParser:
    """Parse resume files into structured ResumeData."""

    def parse(self, source: str | Path) -> ResumeData:
        """Parse a resume file into structured data.

        Args:
            source: Path to resume file (PDF, DOCX, or JSON).

        Returns:
            Structured ResumeData.

        Raises:
            ValidationError: If the file path is invalid.
            ParseError: If parsing fails.
        """
        path = Path(source)
        if not path.exists():
            raise ValidationError(f"Resume file not found: {path}")

        suffix = path.suffix.lower()
        if suffix == ".pdf":
            raw_text = self._parse_pdf(path)
        elif suffix == ".docx":
            raw_text = self._parse_docx(path)
        elif suffix == ".json":
            raw_text = self._parse_json_raw(path)
        else:
            raise ValidationError(
                f"Unsupported resume format: {suffix}. Use PDF, DOCX, or JSON."
            )

        if not raw_text.strip():
            raise ParseError(f"Could not extract text from {path}")

        return self._structure(raw_text, source_is_json=(suffix == ".json"), path=path)

    def parse_text(self, text: str) -> ResumeData:
        """Parse resume from raw text.

        Args:
            text: Raw resume text.

        Returns:
            Structured ResumeData.

        Raises:
            ValidationError: If text is empty.
        """
        text = sanitize_input(text)
        if not text:
            raise ValidationError("Resume text is empty.")
        return self._structure(text)

    def _parse_pdf(self, path: Path) -> str:
        """Extract text from a PDF file."""
        try:
            from pypdf import PdfReader

            reader = PdfReader(str(path))
            pages = []
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    pages.append(page_text)
            return "\n".join(pages)
        except ImportError:
            raise ParseError(
                "pypdf is required for PDF parsing. Install with: pip install pypdf"
            )
        except Exception as e:
            raise ParseError(f"Failed to parse PDF {path}: {e}") from e

    def _parse_docx(self, path: Path) -> str:
        """Extract text from a DOCX file."""
        try:
            from docx import Document

            doc = Document(str(path))
            paragraphs = [para.text for para in doc.paragraphs if para.text.strip()]
            return "\n".join(paragraphs)
        except ImportError:
            raise ParseError(
                "python-docx is required for DOCX parsing. Install with: pip install python-docx"
            )
        except Exception as e:
            raise ParseError(f"Failed to parse DOCX {path}: {e}") from e

    def _parse_json_raw(self, path: Path) -> str:
        """Load JSON resume and return raw text representation."""
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            return json.dumps(data, indent=2)
        except (json.JSONDecodeError, OSError) as e:
            raise ParseError(f"Failed to parse JSON {path}: {e}") from e

    def _structure(
        self, text: str, source_is_json: bool = False, path: Path | None = None
    ) -> ResumeData:
        """Convert raw text into structured ResumeData.

        For JSON files, parse structured fields directly. For PDF/DOCX,
        use heuristic text parsing.
        """
        if source_is_json and path is not None:
            return self._structure_from_json(path)

        contact = self._extract_contact(text)
        skills = self._extract_skills(text)
        experience = self._extract_experience(text)
        education = self._extract_education(text)
        summary = self._extract_summary(text)

        return ResumeData(
            contact=contact,
            summary=summary,
            skills=skills,
            experience=experience,
            education=education,
            raw_text=text,
        )

    def _structure_from_json(self, path: Path) -> ResumeData:
        """Parse a structured JSON resume file."""
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            raise ParseError(f"Failed to read JSON resume: {e}") from e

        contact_data = data.get("contact", data.get("basics", {}))
        contact = ContactInfo(
            name=contact_data.get("name", ""),
            email=contact_data.get("email", ""),
            phone=contact_data.get("phone", ""),
            location=contact_data.get("location", ""),
            linkedin=contact_data.get("linkedin", ""),
            website=contact_data.get("website", contact_data.get("url", "")),
            github=contact_data.get("github", ""),
        )

        skills = data.get("skills", [])
        if isinstance(skills, dict):
            skills = []
            for category_items in skills.values():
                if isinstance(category_items, list):
                    skills.extend(category_items)

        experience_entries = []
        for exp in data.get("experience", data.get("work", [])):
            experience_entries.append(
                ExperienceEntry(
                    title=exp.get("title", exp.get("position", "")),
                    company=exp.get("company", exp.get("name", "")),
                    location=exp.get("location", ""),
                    start_date=exp.get("start_date", exp.get("startDate", "")),
                    end_date=exp.get("end_date", exp.get("endDate", "")),
                    descriptions=exp.get("descriptions", exp.get("highlights", [])),
                )
            )

        education_entries = []
        for edu in data.get("education", []):
            education_entries.append(
                EducationEntry(
                    degree=edu.get("degree", ""),
                    institution=edu.get("institution", edu.get("name", "")),
                    location=edu.get("location", ""),
                    graduation_date=edu.get("graduation_date", edu.get("endDate", "")),
                    gpa=edu.get("gpa", ""),
                    highlights=edu.get("highlights", []),
                )
            )

        summary = data.get("summary", data.get("basics", {}).get("summary", ""))

        return ResumeData(
            contact=contact,
            summary=summary,
            skills=skills,
            experience=experience_entries,
            education=education_entries,
            certifications=data.get("certifications", []),
            projects=data.get("projects", []),
            raw_text=json.dumps(data, indent=2),
        )

    def _extract_contact(self, text: str) -> ContactInfo:
        """Extract contact information using regex patterns."""
        email = ""
        email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", text)
        if email_match:
            email = email_match.group()

        phone = ""
        phone_match = re.search(
            r"(?:\+1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}", text
        )
        if phone_match:
            phone = phone_match.group()

        linkedin = ""
        linkedin_match = re.search(
            r"linkedin\.com/in/[\w-]+", text, re.IGNORECASE
        )
        if linkedin_match:
            linkedin = "https://" + linkedin_match.group()

        github = ""
        github_match = re.search(r"github\.com/[\w-]+", text, re.IGNORECASE)
        if github_match:
            github = "https://" + github_match.group()

        # First line is typically the name
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        name = lines[0] if lines else ""

        # Skip if first line looks like email/phone
        if name and (re.match(r"^[\w.+-]+@", name) or re.match(r"^\d", name)):
            name = ""

        return ContactInfo(
            name=name, email=email, phone=phone, linkedin=linkedin, github=github
        )

    def _extract_skills(self, text: str) -> list[str]:
        """Extract skills section from resume text."""
        text_lower = text.lower()

        # Look for a skills section
        skills_section = ""
        patterns = [
            r"(?:technical\s+)?skills[:\s]+(.*?)(?:\n\n|\n[A-Z]|\Z)",
            r"technologies[:\s]+(.*?)(?:\n\n|\n[A-Z]|\Z)",
            r"competencies[:\s]+(.*?)(?:\n\n|\n[A-Z]|\Z)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text_lower, re.DOTALL | re.IGNORECASE)
            if match:
                skills_section = match.group(1)
                break

        if skills_section:
            # Split by common delimiters
            skills = re.split(r"[,;|•\u2022\n]+", skills_section)
            return [s.strip().title() for s in skills if s.strip() and len(s.strip()) > 1]

        return []

    def _extract_experience(self, text: str) -> list[ExperienceEntry]:
        """Extract work experience entries from resume text."""
        entries: list[ExperienceEntry] = []
        lines = text.split("\n")

        # Simple heuristic: look for date patterns
        date_pattern = re.compile(
            r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)"
            r"[a-z]*\.?\s+\d{4}\s*[-\u2013to]+\s*"
            r"(?:(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{4}|present|current)",
            re.IGNORECASE,
        )

        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if not line:
                i += 1
                continue

            date_match = date_pattern.search(line)
            if date_match:
                # The line before or the current line contains title/company
                title_line = line[: date_match.start()].strip() if date_match.start() > 0 else ""
                if not title_line and i > 0:
                    title_line = lines[i - 1].strip()

                parts = title_line.split("|")
                if len(parts) >= 2:
                    title = parts[0].strip()
                    company = parts[1].strip()
                elif len(parts) == 1:
                    # Try splitting by "at" or "-"
                    at_split = re.split(r"\s+at\s+|\s*[-|]\s*", parts[0], maxsplit=1)
                    title = at_split[0].strip()
                    company = at_split[1].strip() if len(at_split) > 1 else ""

                date_str = date_match.group().strip()
                start_date = date_str.split("-")[0].strip() if "-" in date_str else date_str.split("\u2013")[0].strip()
                end_date = ""
                if "-" in date_str:
                    end_date = date_str.split("-")[-1].strip()
                elif "\u2013" in date_str:
                    end_date = date_str.split("\u2013")[-1].strip()

                descriptions: list[str] = []
                i += 1
                while i < len(lines):
                    bullet = lines[i].strip()
                    if not bullet:
                        i += 1
                        continue
                    if date_pattern.search(bullet):
                        break
                    if bullet.startswith(("-", "*", "\u2022", "\u2013")) or (len(bullet) > 0 and bullet[0].isdigit()):
                        descriptions.append(bullet.lstrip("-*\u2022\u2013 ").strip())
                    elif not descriptions:
                        break
                    else:
                        break
                    i += 1

                entries.append(
                    ExperienceEntry(
                        title=title,
                        company=company,
                        start_date=start_date,
                        end_date=end_date,
                        descriptions=descriptions,
                    )
                )
            else:
                i += 1

        return entries

    def _extract_education(self, text: str) -> list[EducationEntry]:
        """Extract education entries from resume text."""
        entries: list[EducationEntry] = []
        text_lower = text.lower()

        # Look for education section
        edu_match = re.search(
            r"education[:\s]+(.*?)(?:\n\n|\Z)",
            text,
            re.DOTALL | re.IGNORECASE,
        )
        if not edu_match:
            return entries

        edu_text = edu_match.group(1)
        lines = [l.strip() for l in edu_text.split("\n") if l.strip()]

        degree_keywords = [
            "bachelor", "master", "phd", "doctorate", "associate",
            "bs", "ba", "ms", "ma", "mba", "b.sc", "m.sc", "b.e", "m.e",
            "btech", "mtech", "llb", "llm", "md", "do",
        ]

        i = 0
        while i < len(lines):
            line = lines[i]
            if any(kw in line.lower() for kw in degree_keywords):
                degree = line
                institution = lines[i + 1].strip() if i + 1 < len(lines) else ""

                grad_match = re.search(r"\d{4}", line)
                grad_date = grad_match.group() if grad_match else ""

                gpa_match = re.search(r"gpa[:\s]*([\d.]+)", line, re.IGNORECASE)
                gpa = gpa_match.group(1) if gpa_match else ""

                entries.append(
                    EducationEntry(
                        degree=degree,
                        institution=institution,
                        graduation_date=grad_date,
                        gpa=gpa,
                    )
                )
                i += 2
            else:
                i += 1

        return entries

    def _extract_summary(self, text: str) -> str:
        """Extract professional summary from resume text."""
        summary_match = re.search(
            r"(?:summary|profile|objective|about)[:\s\-]+(.*?)(?:\n\n|\n[A-Z][A-Z])",
            text,
            re.DOTALL | re.IGNORECASE,
        )
        if summary_match:
            return summary_match.group(1).strip()

        # Fallback: first non-contact paragraph
        lines = text.split("\n")
        paragraphs: list[str] = []
        current: list[str] = []
        for line in lines:
            stripped = line.strip()
            if stripped:
                current.append(stripped)
            else:
                if current:
                    paragraphs.append(" ".join(current))
                    current = []
        if current:
            paragraphs.append(" ".join(current))

        # Skip first paragraph if it's just contact info
        for para in paragraphs:
            # Skip if it's mostly email/phone/URL
            if re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", para):
                continue
            if len(para.split()) > 15:
                return para

        return ""
