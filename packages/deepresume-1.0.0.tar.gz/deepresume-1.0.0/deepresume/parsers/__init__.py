"""Resume and job listing parsers."""

from deepresume.parsers.resume_parser import ResumeParser
from deepresume.parsers.job_parser import JobParser

__all__ = ["ResumeParser", "JobParser"]
