"""Main orchestrator that ties all DeepResume components together."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Sequence

from jinja2 import Environment, FileSystemLoader, select_autoescape

from deepresume.ai_engine import AIEngine
from deepresume.analyzers.ats_analyzer import ATSAnalyzer
from deepresume.config import Config
from deepresume.exceptions import DeepResumeError, OutputError
from deepresume.generators.cover_letter_generator import CoverLetterGenerator
from deepresume.generators.resume_generator import ResumeGenerator
from deepresume.models import (
    CoverLetterTone,
    JobListing,
    MatchResult,
    OutputFormat,
    ResumeData,
    TailoredResume,
)
from deepresume.parsers.job_parser import JobParser
from deepresume.parsers.resume_parser import ResumeParser

logger = logging.getLogger(__name__)


class DeepResumeOrchestrator:
    """Orchestrate the full resume tailoring pipeline.

    Coordinates parsing, analysis, AI tailoring, and output generation.
    """

    def __init__(self, config: Config | None = None) -> None:
        self._config = config or Config.from_env()
        self._resume_parser = ResumeParser()
        self._job_parser = JobParser()
        self._ats_analyzer = ATSAnalyzer()
        self._ai_engine = AIEngine(self._config)
        self._resume_generator = ResumeGenerator()
        self._cover_letter_generator = CoverLetterGenerator()
        self._jinja_env = Environment(
            loader=FileSystemLoader(
                str(Path(__file__).parent / "templates"),
                autoescape=select_autoescape(),
            ),
            autoescape=False,
        )

    def parse_resume(self, source: str | Path) -> ResumeData:
        """Parse a resume file or text into structured data.

        Args:
            source: Path to resume file (PDF, DOCX, JSON) or raw text.

        Returns:
            Structured ResumeData.
        """
        path = Path(source)
        if path.exists():
            return self._resume_parser.parse(path)
        return self._resume_parser.parse_text(str(source))

    def parse_job(self, source: str) -> JobListing:
        """Parse a job listing from URL or text.

        Args:
            source: Job listing URL or pasted text.

        Returns:
            Structured JobListing.
        """
        return self._job_parser.parse(source)

    def analyze(self, resume: ResumeData, job: JobListing) -> MatchResult:
        """Run ATS analysis on resume-job match.

        Uses local rule-based analysis (fast, no API needed) followed
        by optional AI-powered deep analysis.

        Args:
            resume: Structured resume data.
            job: Structured job listing.

        Returns:
            MatchResult with scores and suggestions.
        """
        # Fast local analysis first
        local_result = self._ats_analyzer.analyze(resume, job)

        # Try AI-powered analysis for more accurate results
        try:
            ai_result = self._ai_engine.analyze_match(resume, job)
            # Merge: prefer AI scores but keep local keyword data as fallback
            if not ai_result.matched_keywords:
                ai_result.matched_keywords = local_result.matched_keywords
            if not ai_result.missing_keywords:
                ai_result.missing_keywords = local_result.missing_keywords
            if not ai_result.keyword_density:
                ai_result.keyword_density = local_result.keyword_density
            return ai_result
        except DeepResumeError as e:
            logger.warning("AI analysis failed, using local analysis: %s", e)
            return local_result

    def check_ats(self, resume: ResumeData) -> list[str]:
        """Check resume for ATS compatibility issues.

        Args:
            resume: Structured resume data.

        Returns:
            List of warning strings.
        """
        return self._ats_analyzer.check_ats_compatibility(resume)

    def tailor(
        self, resume: ResumeData, job: JobListing, match: MatchResult
    ) -> TailoredResume:
        """Tailor a resume for a specific job listing using AI.

        Args:
            resume: Original resume data.
            job: Target job listing.
            match: Pre-computed match analysis.

        Returns:
            TailoredResume with optimized content.
        """
        return self._ai_engine.tailor_resume(resume, job, match)

    def generate_cover_letter(
        self,
        resume: ResumeData,
        job: JobListing,
        tailored: TailoredResume,
        tone: CoverLetterTone = CoverLetterTone.PROFESSIONAL,
    ) -> str:
        """Generate a cover letter.

        Args:
            resume: Original resume data.
            job: Target job listing.
            tailored: Tailored resume data.
            tone: Desired tone for the cover letter.

        Returns:
            Cover letter text.
        """
        return self._ai_engine.generate_cover_letter(resume, job, tailored, tone)

    def generate_interview_prep(
        self, resume: ResumeData, job: JobListing
    ) -> list[str]:
        """Generate interview preparation questions.

        Args:
            resume: Candidate's resume.
            job: Target job listing.

        Returns:
            List of interview questions.
        """
        return self._ai_engine.generate_interview_questions(resume, job)

    def output_resume(
        self,
        tailored: TailoredResume,
        output_path: str | Path,
        fmt: OutputFormat = OutputFormat.PDF,
    ) -> Path:
        """Generate tailored resume output file.

        Args:
            tailored: Tailored resume data.
            output_path: Output file path.
            fmt: Output format (PDF, DOCX, Markdown).

        Returns:
            Path to generated file.
        """
        return self._resume_generator.generate(tailored, output_path, fmt)

    def output_cover_letter(
        self,
        tailored: TailoredResume,
        cover_letter_text: str,
        output_path: str | Path,
        fmt: OutputFormat = OutputFormat.PDF,
    ) -> Path:
        """Generate cover letter output file.

        Args:
            tailored: Tailored resume with contact info.
            cover_letter_text: Generated cover letter text.
            output_path: Output file path.
            fmt: Output format.

        Returns:
            Path to generated file.
        """
        output_path = Path(output_path)
        if fmt == OutputFormat.MARKDOWN:
            return self._cover_letter_generator.generate_markdown(
                tailored, cover_letter_text, output_path
            )
        elif fmt == OutputFormat.DOCX:
            return self._cover_letter_generator.generate_docx(
                tailored, cover_letter_text, output_path
            )
        elif fmt == OutputFormat.PDF:
            return self._cover_letter_generator.generate_pdf(
                tailored, cover_letter_text, output_path
            )
        raise OutputError(f"Unsupported format: {fmt}")

    def generate_report(
        self, resume: ResumeData, job: JobListing, match: MatchResult, output_path: str | Path
    ) -> Path:
        """Generate an analysis report as Markdown.

        Args:
            resume: Original resume data.
            job: Target job listing.
            match: Match analysis results.
            output_path: Output file path.

        Returns:
            Path to generated report.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        template = self._jinja_env.get_template("report.md.j2")
        content = template.render(job=job, resume=resume, match=match)
        output_path.write_text(content, encoding="utf-8")
        return output_path

    def generate_interview_guide(
        self,
        resume: ResumeData,
        job: JobListing,
        questions: list[str],
        output_path: str | Path,
    ) -> Path:
        """Generate an interview preparation guide.

        Args:
            resume: Candidate's resume.
            job: Target job listing.
            questions: List of interview questions.
            output_path: Output file path.

        Returns:
            Path to generated guide.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Categorize questions
        behavioral: list[str] = []
        technical: list[str] = []
        situational: list[str] = []
        ask_interviewer: list[str] = []

        for q in questions:
            q_lower = q.lower()
            if "ask the interviewer" in q_lower or "ask them" in q_lower or "you should ask" in q_lower:
                ask_interviewer.append(q)
            elif any(
                w in q_lower
                for w in ["tell me about a time", "describe a situation", "give an example", "behavioral"]
            ):
                behavioral.append(q)
            elif any(
                w in q_lower
                for w in ["what would you", "how would you handle", "imagine", "scenario"]
            ):
                situational.append(q)
            else:
                technical.append(q)

        # If no categorization happened, split evenly
        if not behavioral and not technical and not situational:
            third = len(questions) // 3
            behavioral = questions[:third]
            technical = questions[third : third * 2]
            situational = questions[third * 2 :]

        template = self._jinja_env.get_template("interview_prep.md.j2")
        content = template.render(
            job=job,
            resume=resume,
            behavioral=behavioral,
            technical=technical,
            situational=situational,
            ask_interviewer=ask_interviewer,
        )
        output_path.write_text(content, encoding="utf-8")
        return output_path

    def run_full_pipeline(
        self,
        resume_source: str | Path,
        job_source: str,
        output_dir: str | Path,
        fmt: OutputFormat = OutputFormat.PDF,
        tone: CoverLetterTone = CoverLetterTone.PROFESSIONAL,
        include_cover_letter: bool = True,
        include_interview_prep: bool = True,
    ) -> dict[str, Path]:
        """Run the complete resume tailoring pipeline.

        Args:
            resume_source: Path to resume file or raw text.
            job_source: Job listing URL or text.
            output_dir: Directory for output files.
            fmt: Output format.
            tone: Cover letter tone.
            include_cover_letter: Whether to generate a cover letter.
            include_interview_prep: Whether to generate interview prep.

        Returns:
            Dictionary mapping output type to file path.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        results: dict[str, Path] = {}

        # Step 1: Parse resume and job
        logger.info("Parsing resume...")
        resume = self.parse_resume(resume_source)
        logger.info("Parsing job listing...")
        job = self.parse_job(job_source)

        # Step 2: Analyze match
        logger.info("Analyzing resume-job match...")
        match = self.analyze(resume, job)
        results["report"] = self.generate_report(
            resume, job, match, output_dir / "analysis_report.md"
        )

        # Step 3: Tailor resume
        logger.info("Tailoring resume with AI...")
        tailored = self.tailor(resume, job, match)

        # Step 4: Generate output
        ext = fmt.value
        results["resume"] = self.output_resume(
            tailored, output_dir / f"tailored_resume.{ext}", fmt
        )

        # Step 5: Cover letter
        if include_cover_letter:
            logger.info("Generating cover letter...")
            cover_letter = self.generate_cover_letter(resume, job, tailored, tone)
            results["cover_letter"] = self.output_cover_letter(
                tailored, cover_letter, output_dir / f"cover_letter.{ext}", fmt
            )

        # Step 6: Interview prep
        if include_interview_prep:
            logger.info("Preparing interview questions...")
            questions = self.generate_interview_prep(resume, job)
            if questions:
                results["interview_prep"] = self.generate_interview_guide(
                    resume, job, questions, output_dir / "interview_prep.md"
                )

        return results

    def run_batch(
        self,
        resume_source: str | Path,
        job_sources: Sequence[str],
        output_dir: str | Path,
        fmt: OutputFormat = OutputFormat.PDF,
        tone: CoverLetterTone = CoverLetterTone.PROFESSIONAL,
    ) -> list[dict[str, Path]]:
        """Tailor resume for multiple job listings.

        Args:
            resume_source: Path to resume file or raw text.
            job_sources: List of job listing URLs or texts.
            output_dir: Base output directory.
            fmt: Output format.
            tone: Cover letter tone.

        Returns:
            List of result dictionaries, one per job.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        logger.info("Parsing resume...")
        resume = self.parse_resume(resume_source)

        all_results: list[dict[str, Path]] = []
        for i, job_source in enumerate(job_sources, 1):
            logger.info("Processing job %d of %d...", i, len(job_sources))
            try:
                # Create subdirectory for each job
                job_output = output_dir / f"job_{i:03d}"
                job_output.mkdir(parents=True, exist_ok=True)

                results = self.run_full_pipeline(
                    resume_source=resume,
                    job_source=job_source,
                    output_dir=job_output,
                    fmt=fmt,
                    tone=tone,
                )
                results["index"] = i  # type: ignore[assignment]
                all_results.append(results)
            except DeepResumeError as e:
                logger.error("Failed to process job %d: %s", i, e)
                all_results.append({"error": Path(str(e))})

        return all_results
