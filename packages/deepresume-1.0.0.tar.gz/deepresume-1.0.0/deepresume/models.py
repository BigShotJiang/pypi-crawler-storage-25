"""Pydantic models for DeepResume data structures."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator


class OutputFormat(str, Enum):
    """Supported output formats for tailored resumes."""

    PDF = "pdf"
    DOCX = "docx"
    MARKDOWN = "markdown"


class CoverLetterTone(str, Enum):
    """Tone options for cover letter generation."""

    PROFESSIONAL = "professional"
    ENTHUSIASTIC = "enthusiastic"
    CONVERSATIONAL = "conversational"
    FORMAL = "formal"
    CREATIVE = "creative"


class ContactInfo(BaseModel):
    """Contact information on a resume."""

    name: str = ""
    email: str = ""
    phone: str = ""
    location: str = ""
    linkedin: str = ""
    website: str = ""
    github: str = ""

    @field_validator("email")
    @classmethod
    def sanitize_email(cls, v: str) -> str:
        return v.strip().lower() if v else ""


class ExperienceEntry(BaseModel):
    """A single work experience entry."""

    title: str = ""
    company: str = ""
    location: str = ""
    start_date: str = ""
    end_date: str = ""
    descriptions: list[str] = Field(default_factory=list)


class EducationEntry(BaseModel):
    """A single education entry."""

    degree: str = ""
    institution: str = ""
    location: str = ""
    graduation_date: str = ""
    gpa: str = ""
    highlights: list[str] = Field(default_factory=list)


class ResumeData(BaseModel):
    """Structured resume data."""

    contact: ContactInfo = Field(default_factory=ContactInfo)
    summary: str = ""
    skills: list[str] = Field(default_factory=list)
    experience: list[ExperienceEntry] = Field(default_factory=list)
    education: list[EducationEntry] = Field(default_factory=list)
    certifications: list[str] = Field(default_factory=list)
    projects: list[dict[str, Any]] = Field(default_factory=list)
    raw_text: str = ""

    @property
    def full_name(self) -> str:
        return self.contact.name or "Candidate"


class JobListing(BaseModel):
    """Structured job listing data."""

    title: str = ""
    company: str = ""
    location: str = ""
    description: str = ""
    requirements: list[str] = Field(default_factory=list)
    responsibilities: list[str] = Field(default_factory=list)
    benefits: list[str] = Field(default_factory=list)
    salary_range: str = ""
    url: str = ""
    raw_text: str = ""


class MatchResult(BaseModel):
    """Result of resume-job matching analysis."""

    overall_score: float = Field(default=0.0, ge=0, le=100)
    keyword_score: float = Field(default=0.0, ge=0, le=100)
    experience_score: float = Field(default=0.0, ge=0, le=100)
    education_score: float = Field(default=0.0, ge=0, le=100)
    skills_score: float = Field(default=0.0, ge=0, le=100)
    matched_keywords: list[str] = Field(default_factory=list)
    missing_keywords: list[str] = Field(default_factory=list)
    suggestions: list[str] = Field(default_factory=list)
    keyword_density: dict[str, float] = Field(default_factory=dict)


class TailoredResume(BaseModel):
    """Result of tailoring a resume to a job listing."""

    original_resume: ResumeData
    job: JobListing
    match: MatchResult
    tailored_summary: str = ""
    tailored_skills: list[str] = Field(default_factory=list)
    tailored_experience: list[ExperienceEntry] = Field(default_factory=list)
    cover_letter: str = ""
    interview_questions: list[str] = Field(default_factory=list)
