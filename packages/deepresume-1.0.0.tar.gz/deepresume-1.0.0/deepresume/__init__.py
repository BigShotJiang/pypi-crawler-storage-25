"""DeepResume — AI career agent that tailors your resume for every job."""

__version__ = "1.0.0"
