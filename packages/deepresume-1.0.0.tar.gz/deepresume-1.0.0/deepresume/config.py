"""Configuration and environment management."""

from __future__ import annotations

import os
from dataclasses import dataclass, field

from deepresume.exceptions import ConfigurationError


@dataclass
class Config:
    """Application configuration loaded from environment variables."""

    api_key: str = ""
    api_base: str = "https://api.openai.com/v1"
    model: str = "gpt-4"
    max_tokens: int = 4096
    temperature: float = 0.7
    timeout: int = 60
    log_level: str = "WARNING"
    sanitize_logs: bool = True

    @classmethod
    def from_env(cls) -> Config:
        """Load configuration from environment variables.

        Raises:
            ConfigurationError: If required environment variables are missing.
        """
        api_key = os.getenv("OPENAI_API_KEY", "")
        if not api_key:
            raise ConfigurationError(
                "OPENAI_API_KEY environment variable is required. "
                "Set it with: export OPENAI_API_KEY='your-key-here'"
            )
        return cls(
            api_key=api_key,
            api_base=os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1"),
            model=os.getenv("DEEPRESUME_MODEL", "gpt-4"),
            max_tokens=int(os.getenv("DEEPRESUME_MAX_TOKENS", "4096")),
            temperature=float(os.getenv("DEEPRESUME_TEMPERATURE", "0.7")),
            timeout=int(os.getenv("DEEPRESUME_TIMEOUT", "60")),
            log_level=os.getenv("DEEPRESUME_LOG_LEVEL", "WARNING"),
            sanitize_logs=os.getenv("DEEPRESUME_SANITIZE_LOGS", "true").lower() == "true",
        )

    @classmethod
    def from_dict(cls, data: dict) -> Config:
        """Create configuration from a dictionary."""
        api_key = data.get("api_key", "")
        if not api_key:
            raise ConfigurationError("api_key is required in configuration.")
        return cls(
            api_key=api_key,
            api_base=data.get("api_base", "https://api.openai.com/v1"),
            model=data.get("model", "gpt-4"),
            max_tokens=data.get("max_tokens", 4096),
            temperature=data.get("temperature", 0.7),
            timeout=data.get("timeout", 60),
            log_level=data.get("log_level", "WARNING"),
            sanitize_logs=data.get("sanitize_logs", True),
        )
