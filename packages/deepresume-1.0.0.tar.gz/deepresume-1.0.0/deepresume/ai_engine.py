"""AI engine for resume tailoring, cover letters, and interview prep."""

from __future__ import annotations

import json
import logging
from typing import Any

from openai import OpenAI

from deepresume.config import Config
from deepresume.exceptions import AIError
from deepresume.models import (
    CoverLetterTone,
    JobListing,
    MatchResult,
    ResumeData,
    TailoredResume,
)
from deepresume.utils import sanitize_for_logging, truncate_text

logger = logging.getLogger(__name__)


class AIEngine:
    """Interface with OpenAI-compatible API for resume optimization."""

    def __init__(self, config: Config) -> None:
        self._config = config
        self._client = OpenAI(
            api_key=config.api_key,
            base_url=config.api_base,
            timeout=config.timeout,
        )

    def _chat(self, system_prompt: str, user_prompt: str) -> str:
        """Send a chat completion request.

        Args:
            system_prompt: System-level instructions.
            user_prompt: User message content.

        Returns:
            Assistant response text.

        Raises:
            AIError: If the API call fails.
        """
        try:
            if self._config.sanitize_logs:
                logger.debug("System prompt: %s", sanitize_for_logging(system_prompt[:200]))
            else:
                logger.debug("System prompt: %s", system_prompt[:200])

            response = self._client.chat.completions.create(
                model=self._config.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                max_tokens=self._config.max_tokens,
                temperature=self._config.temperature,
            )
            content = response.choices[0].message.content
            if content is None:
                raise AIError("Empty response from AI model.")
            return content.strip()
        except AIError:
            raise
        except Exception as e:
            raise AIError(f"AI API call failed: {e}") from e

    def _chat_json(self, system_prompt: str, user_prompt: str) -> dict[str, Any]:
        """Send a chat request and parse JSON response.

        Args:
            system_prompt: System-level instructions.
            user_prompt: User message content.

        Returns:
            Parsed JSON dictionary.

        Raises:
            AIError: If the API call fails or JSON is invalid.
        """
        raw = self._chat(system_prompt, user_prompt)
        # Strip markdown code fences if present
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1]
        if raw.endswith("```"):
            raw = raw.rsplit("```", 1)[0]
        raw = raw.strip()
        if raw.startswith("json"):
            raw = raw[4:].strip()

        try:
            return json.loads(raw)
        except json.JSONDecodeError as e:
            raise AIError(f"Failed to parse AI response as JSON: {e}") from e

    def analyze_match(self, resume: ResumeData, job: JobListing) -> MatchResult:
        """Analyze how well a resume matches a job listing.

        Args:
            resume: Structured resume data.
            job: Structured job listing data.

        Returns:
            MatchResult with scores and analysis.
        """
        system_prompt = (
            "You are an expert ATS (Applicant Tracking System) analyzer and career advisor. "
            "Analyze how well the candidate's resume matches the job listing. "
            "Return a JSON object with these fields:\n"
            "- overall_score: float 0-100 (overall match percentage)\n"
            "- keyword_score: float 0-100 (keyword alignment)\n"
            "- experience_score: float 0-100 (experience relevance)\n"
            "- education_score: float 0-100 (education match)\n"
            "- skills_score: float 0-100 (skills overlap)\n"
            "- matched_keywords: list of keywords present in both\n"
            "- missing_keywords: list of important keywords missing from resume\n"
            "- suggestions: list of actionable improvement suggestions\n"
            "- keyword_density: object mapping key terms to their density percentage\n\n"
            "Be precise and realistic with scoring. Focus on ATS-relevant factors."
        )

        resume_text = truncate_text(resume.raw_text or resume.model_dump_json(), 3000)
        job_text = truncate_text(job.raw_text or job.model_dump_json(), 3000)

        user_prompt = (
            f"CANDIDATE RESUME:\n{resume_text}\n\n"
            f"JOB LISTING:\n{job_text}\n\n"
            "Analyze the match and return the JSON object."
        )

        try:
            result = self._chat_json(system_prompt, user_prompt)
            return MatchResult(
                overall_score=float(result.get("overall_score", 0)),
                keyword_score=float(result.get("keyword_score", 0)),
                experience_score=float(result.get("experience_score", 0)),
                education_score=float(result.get("education_score", 0)),
                skills_score=float(result.get("skills_score", 0)),
                matched_keywords=result.get("matched_keywords", []),
                missing_keywords=result.get("missing_keywords", []),
                suggestions=result.get("suggestions", []),
                keyword_density=result.get("keyword_density", {}),
            )
        except Exception as e:
            raise AIError(f"Match analysis failed: {e}") from e

    def tailor_resume(
        self, resume: ResumeData, job: JobListing, match: MatchResult
    ) -> TailoredResume:
        """Tailor a resume to better match a job listing.

        Args:
            resume: Original resume data.
            job: Target job listing.
            match: Pre-computed match analysis.

        Returns:
            TailoredResume with optimized content.
        """
        tailored_summary = self._tailor_summary(resume, job, match)
        tailored_skills = self._tailor_skills(resume, job, match)
        tailored_experience = self._tailor_experience(resume, job, match)

        return TailoredResume(
            original_resume=resume,
            job=job,
            match=match,
            tailored_summary=tailored_summary,
            tailored_skills=tailored_skills,
            tailored_experience=tailored_experience,
        )

    def _tailor_summary(
        self, resume: ResumeData, job: JobListing, match: MatchResult
    ) -> str:
        """Generate an ATS-optimized professional summary."""
        system_prompt = (
            "You are an expert resume writer specializing in ATS optimization. "
            "Write a concise, impactful professional summary (3-4 sentences) that:\n"
            "1. Incorporates key terms from the job description\n"
            "2. Highlights the candidate's most relevant experience\n"
            "3. Quantifies achievements where possible\n"
            "4. Avoids cliches and generic language\n\n"
            "Return ONLY the summary text, no labels or markdown."
        )

        user_prompt = (
            f"Candidate's current summary: {resume.summary}\n"
            f"Candidate's skills: {', '.join(resume.skills[:20])}\n"
            f"Job title: {job.title}\n"
            f"Job requirements: {'; '.join(job.requirements[:10])}\n"
            f"Missing keywords to weave in: {', '.join(match.missing_keywords[:10])}\n\n"
            "Write an optimized professional summary."
        )

        return self._chat(system_prompt, user_prompt)

    def _tailor_skills(
        self, resume: ResumeData, job: JobListing, match: MatchResult
    ) -> list[str]:
        """Optimize and reorder skills section for the job."""
        system_prompt = (
            "You are an ATS optimization expert. Given the candidate's skills and "
            "the job's requirements, return a JSON array of optimized skill strings. "
            "Rules:\n"
            "1. Reorder skills so the most relevant to this job come first\n"
            "2. Use exact terminology from the job listing where the candidate has equivalent skills\n"
            "3. Add missing skills the candidate likely has based on their experience "
            "(only if clearly inferable from resume context)\n"
            "4. Remove skills not relevant to this position to keep it concise\n"
            "5. Keep the total to 15-20 most relevant skills\n\n"
            'Return ONLY a JSON array like ["Skill1", "Skill2", ...]'
        )

        user_prompt = (
            f"Candidate's skills: {json.dumps(resume.skills)}\n"
            f"Job title: {job.title}\n"
            f"Job requirements: {json.dumps(job.requirements[:15])}\n"
            f"Matched keywords: {json.dumps(match.matched_keywords[:15])}\n"
            f"Missing keywords: {json.dumps(match.missing_keywords[:10])}\n\n"
            "Return the optimized skills array."
        )

        try:
            result = self._chat_json(system_prompt, user_prompt)
            if isinstance(result, list):
                return [str(s) for s in result]
            return resume.skills
        except AIError:
            logger.warning("Skills tailoring failed, using original skills")
            return resume.skills

    def _tailor_experience(
        self, resume: ResumeData, job: JobListing, match: MatchResult
    ) -> list[dict[str, Any]]:
        """Optimize experience bullet points for the job."""
        if not resume.experience:
            return []

        system_prompt = (
            "You are an expert resume writer. Rewrite the work experience bullet points "
            "to better align with the target job. Rules:\n"
            "1. Use the STAR method (Situation, Task, Action, Result)\n"
            "2. Start each bullet with a strong action verb\n"
            "3. Incorporate keywords from the job listing naturally\n"
            "4. Quantify achievements where possible\n"
            "5. Keep each bullet to 1-2 lines\n"
            "6. Maintain factual accuracy - do not invent experience\n\n"
            "Return a JSON array of objects, each with 'title', 'company', 'location', "
            "'start_date', 'end_date', and 'descriptions' (array of strings)."
        )

        exp_data = [
            {
                "title": e.title,
                "company": e.company,
                "location": e.location,
                "start_date": e.start_date,
                "end_date": e.end_date,
                "descriptions": e.descriptions,
            }
            for e in resume.experience
        ]

        user_prompt = (
            f"Candidate's experience: {json.dumps(exp_data)}\n"
            f"Job title: {job.title}\n"
            f"Key job requirements: {'; '.join(job.requirements[:10])}\n"
            f"Target keywords: {', '.join(match.missing_keywords[:8])}\n\n"
            "Rewrite the experience entries for maximum impact. Return JSON."
        )

        try:
            result = self._chat_json(system_prompt, user_prompt)
            if isinstance(result, list):
                return result
            return exp_data
        except AIError:
            logger.warning("Experience tailoring failed, using original experience")
            return exp_data

    def generate_cover_letter(
        self,
        resume: ResumeData,
        job: JobListing,
        tailored: TailoredResume,
        tone: CoverLetterTone = CoverLetterTone.PROFESSIONAL,
    ) -> str:
        """Generate a customized cover letter.

        Args:
            resume: Original resume data.
            job: Target job listing.
            tailored: Tailored resume with optimized content.
            tone: Desired tone for the cover letter.

        Returns:
            Cover letter text.
        """
        tone_descriptions = {
            CoverLetterTone.PROFESSIONAL: "professional and confident",
            CoverLetterTone.ENTHUSIASTIC: "enthusiastic and passionate",
            CoverLetterTone.CONVERSATIONAL: "conversational yet professional",
            CoverLetterTone.FORMAL: "formal and traditional",
            CoverLetterTone.CREATIVE: "creative and distinctive",
        }

        system_prompt = (
            f"You are an expert cover letter writer. Write a {tone_descriptions[tone]} "
            "cover letter that:\n"
            "1. Opens with a compelling hook about why this role excites the candidate\n"
            "2. Connects 2-3 specific achievements to job requirements\n"
            "3. Shows genuine knowledge of or interest in the company\n"
            "4. Ends with a confident call to action\n"
            "5. Is 3-4 paragraphs, fitting on one page\n"
            "6. Uses specific metrics and examples from the resume\n\n"
            "Return ONLY the cover letter text. No placeholders like [Date] or [Hiring Manager]. "
            "Use the candidate's actual name. Use 'Hiring Manager' as the salutation."
        )

        user_prompt = (
            f"Candidate name: {resume.contact.name}\n"
            f"Candidate email: {resume.contact.email}\n"
            f"Candidate phone: {resume.contact.phone}\n"
            f"Professional summary: {tailored.tailored_summary or resume.summary}\n"
            f"Key skills: {', '.join(tailored.tailored_skills[:10])}\n"
            f"Experience highlights: {json.dumps([e.descriptions[:2] for e in resume.experience[:2]])}\n\n"
            f"Job title: {job.title}\n"
            f"Company: {job.company}\n"
            f"Job description excerpt: {truncate_text(job.raw_text, 1500)}\n\n"
            f"Write a {tone_descriptions[tone]} cover letter."
        )

        return self._chat(system_prompt, user_prompt)

    def generate_interview_questions(
        self, resume: ResumeData, job: JobListing
    ) -> list[str]:
        """Generate interview preparation questions based on job listing.

        Args:
            resume: Candidate's resume.
            job: Target job listing.

        Returns:
            List of likely interview questions.
        """
        system_prompt = (
            "You are a technical interviewer and career coach. Generate 15 likely "
            "interview questions for this role, organized into categories:\n"
            "- 5 behavioral questions (based on job requirements)\n"
            "- 5 technical/role-specific questions\n"
            "- 3 situational questions (hypothetical scenarios)\n"
            "- 2 questions the candidate should ask the interviewer\n\n"
            "Return a JSON array of question strings. Each question should be "
            "specific to this role and company, not generic."
        )

        user_prompt = (
            f"Job title: {job.title}\n"
            f"Company: {job.company}\n"
            f"Requirements: {'; '.join(job.requirements[:10])}\n"
            f"Responsibilities: {'; '.join(job.responsibilities[:8])}\n"
            f"Candidate skills: {', '.join(resume.skills[:15])}\n\n"
            "Generate targeted interview questions."
        )

        try:
            result = self._chat_json(system_prompt, user_prompt)
            if isinstance(result, list):
                return [str(q) for q in result]
            return []
        except AIError:
            logger.warning("Interview question generation failed")
            return []
