"""ATS (Applicant Tracking System) analyzer for resume optimization."""

from __future__ import annotations

import re
from difflib import SequenceMatcher

from deepresume.models import JobListing, MatchResult, ResumeData
from deepresume.utils import compute_keyword_density, extract_keywords


class ATSAnalyzer:
    """Local ATS analysis without requiring AI API calls.

    Provides fast, deterministic analysis of resume-job match based on
    keyword overlap, density analysis, and structural checks.
    """

    # Common ATS-unfriendly formatting patterns
    ATS_RED_FLAGS = [
        (re.compile(r"[^\x00-\x7F]"), "Non-ASCII characters may not parse correctly"),
        (re.compile(r"\t"), "Tab characters can confuse ATS parsers"),
        (re.compile(r"\|"), "Pipe characters may cause parsing issues"),
        (re.compile(r"_{3,}"), "Underline sequences can be misread"),
    ]

    def analyze(self, resume: ResumeData, job: JobListing) -> MatchResult:
        """Perform local ATS analysis of resume-job match.

        This is a fast, rule-based analysis that does not require AI API calls.
        For AI-powered analysis, use AIEngine.analyze_match().

        Args:
            resume: Structured resume data.
            job: Structured job listing.

        Returns:
            MatchResult with computed scores.
        """
        resume_text = self._get_resume_text(resume)
        job_text = self._get_job_text(job)

        resume_keywords = set(kw.lower() for kw in extract_keywords(resume_text))
        job_keywords = set(kw.lower() for kw in extract_keywords(job_text))

        # Matched and missing keywords
        matched = sorted(resume_keywords & job_keywords)
        missing = sorted(job_keywords - resume_keywords)

        # Compute scores
        keyword_score = self._keyword_score(resume_keywords, job_keywords)
        skills_score = self._skills_score(resume, job)
        experience_score = self._experience_score(resume, job)
        education_score = self._education_score(resume, job)

        # Weighted overall score
        overall_score = (
            keyword_score * 0.30
            + skills_score * 0.30
            + experience_score * 0.25
            + education_score * 0.15
        )

        # Keyword density for top job keywords
        density = compute_keyword_density(resume_text, list(job_keywords)[:20])

        # Generate suggestions
        suggestions = self._generate_suggestions(
            resume, job, matched, missing, keyword_score, skills_score
        )

        return MatchResult(
            overall_score=round(overall_score, 1),
            keyword_score=round(keyword_score, 1),
            experience_score=round(experience_score, 1),
            education_score=round(education_score, 1),
            skills_score=round(skills_score, 1),
            matched_keywords=matched[:30],
            missing_keywords=missing[:30],
            suggestions=suggestions,
            keyword_density=density,
        )

    def check_ats_compatibility(self, resume: ResumeData) -> list[str]:
        """Check resume for ATS compatibility issues.

        Args:
            resume: Structured resume data.

        Returns:
            List of warnings about potential ATS issues.
        """
        warnings: list[str] = []
        resume_text = self._get_resume_text(resume)

        # Check for formatting red flags
        for pattern, message in self.ATS_RED_FLAGS:
            if pattern.search(resume_text):
                warnings.append(message)

        # Check for missing sections
        if not resume.summary:
            warnings.append("Missing professional summary — ATS systems look for this section")
        if not resume.skills:
            warnings.append("Missing skills section — critical for keyword matching")
        if not resume.experience:
            warnings.append("Missing work experience section")
        if not resume.education:
            warnings.append("Missing education section")

        # Check contact info completeness
        if not resume.contact.email:
            warnings.append("Missing email address in contact info")
        if not resume.contact.phone:
            warnings.append("Missing phone number in contact info")

        # Check skill count
        if len(resume.skills) < 8:
            warnings.append(
                f"Only {len(resume.skills)} skills listed — aim for 12-20 relevant skills"
            )
        elif len(resume.skills) > 30:
            warnings.append(
                f"{len(resume.skills)} skills listed — consider trimming to most relevant 15-20"
            )

        # Check bullet point quality
        for exp in resume.experience:
            for desc in exp.descriptions:
                if len(desc.split()) < 5:
                    warnings.append(
                        f"Vague bullet point in {exp.title}: '{desc[:50]}...'"
                    )
                if not any(c.isdigit() for c in desc):
                    # No quantification — not critical but worth noting
                    pass

        return warnings

    def _get_resume_text(self, resume: ResumeData) -> str:
        """Get full text representation of resume."""
        parts: list[str] = []
        if resume.contact.name:
            parts.append(resume.contact.name)
        if resume.summary:
            parts.append(resume.summary)
        parts.extend(resume.skills)
        for exp in resume.experience:
            parts.append(exp.title)
            parts.append(exp.company)
            parts.extend(exp.descriptions)
        for edu in resume.education:
            parts.append(edu.degree)
            parts.append(edu.institution)
        parts.extend(resume.certifications)
        if resume.raw_text:
            parts.append(resume.raw_text)
        return " ".join(parts)

    def _get_job_text(self, job: JobListing) -> str:
        """Get full text representation of job listing."""
        parts: list[str] = [
            job.title,
            job.company,
            job.description,
        ]
        parts.extend(job.requirements)
        parts.extend(job.responsibilities)
        if job.raw_text:
            parts.append(job.raw_text)
        return " ".join(parts)

    def _keyword_score(self, resume_kw: set[str], job_kw: set[str]) -> float:
        """Calculate keyword overlap score."""
        if not job_kw:
            return 50.0
        overlap = len(resume_kw & job_kw)
        return min(100.0, (overlap / len(job_kw)) * 100)

    def _skills_score(self, resume: ResumeData, job: JobListing) -> float:
        """Calculate skills match score using fuzzy matching."""
        if not resume.skills:
            return 0.0

        job_text = self._get_job_text(job).lower()
        resume_skills_lower = [s.lower() for s in resume.skills]

        matched = 0
        job_keywords = extract_keywords(job_text)

        for kw in job_keywords[:30]:
            for skill in resume_skills_lower:
                similarity = SequenceMatcher(None, kw, skill).ratio()
                if similarity > 0.75 or kw in skill or skill in kw:
                    matched += 1
                    break

        total = min(len(job_keywords), 30)
        if total == 0:
            return 50.0
        return min(100.0, (matched / total) * 100)

    def _experience_score(self, resume: ResumeData, job: JobListing) -> float:
        """Calculate experience relevance score."""
        if not resume.experience:
            return 0.0

        job_text = self._get_job_text(job).lower()
        job_keywords = set(extract_keywords(job_text)[:20])

        total_score = 0.0
        for exp in resume.experience:
            exp_text = f"{exp.title} {' '.join(exp.descriptions)}".lower()
            exp_keywords = set(extract_keywords(exp_text))
            overlap = len(exp_keywords & job_keywords)
            total_score += min(100.0, (overlap / max(len(job_keywords), 1)) * 100)

        return min(100.0, total_score / len(resume.experience))

    def _education_score(self, resume: ResumeData, job: JobListing) -> float:
        """Calculate education match score."""
        if not resume.education:
            return 30.0  # Not critical for all roles

        job_text = self._get_job_text(job).lower()

        # Check if job mentions degree requirements
        degree_keywords = [
            "bachelor", "master", "phd", "doctorate", "associate",
            "bs", "ba", "ms", "ma", "mba", "degree",
        ]
        job_requires_degree = any(kw in job_text for kw in degree_keywords)

        if not job_requires_degree:
            return 70.0  # No specific requirement

        # Check if candidate has matching degree
        for edu in resume.education:
            edu_text = edu.degree.lower()
            for kw in degree_keywords:
                if kw in edu_text:
                    return 90.0

        return 40.0  # Job requires degree, candidate doesn't show one

    def _generate_suggestions(
        self,
        resume: ResumeData,
        job: JobListing,
        matched: list[str],
        missing: list[str],
        keyword_score: float,
        skills_score: float,
    ) -> list[str]:
        """Generate actionable improvement suggestions."""
        suggestions: list[str] = []

        if keyword_score < 50:
            suggestions.append(
                "Keyword match is low. Review the job listing and incorporate "
                "more relevant terminology throughout your resume."
            )

        if missing and len(missing) <= 10:
            suggestions.append(
                f"Consider adding these missing keywords: {', '.join(missing[:8])}"
            )
        elif missing:
            suggestions.append(
                f"Top missing keywords to add: {', '.join(missing[:8])}"
            )

        if skills_score < 60:
            suggestions.append(
                "Skills section needs better alignment with job requirements. "
                "Reorder skills to prioritize the most relevant ones."
            )

        if not resume.summary:
            suggestions.append(
                "Add a professional summary that targets this specific role."
            )

        if len(resume.skills) < 10:
            suggestions.append(
                "Expand your skills section — aim for 12-20 relevant skills."
            )

        # Check for quantified achievements
        has_quantified = any(
            any(c.isdigit() for c in desc)
            for exp in resume.experience
            for desc in exp.descriptions
        )
        if not has_quantified:
            suggestions.append(
                "Add quantified achievements (e.g., 'Increased sales by 25%') "
                "to your experience section for stronger impact."
            )

        if not suggestions:
            suggestions.append(
                "Your resume is well-aligned with this position. "
                "Consider minor tweaks to mirror the exact terminology used in the job listing."
            )

        return suggestions
