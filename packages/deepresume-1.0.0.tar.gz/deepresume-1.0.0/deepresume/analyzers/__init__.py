"""Resume-job match analyzers."""

from deepresume.analyzers.ats_analyzer import ATSAnalyzer

__all__ = ["ATSAnalyzer"]
