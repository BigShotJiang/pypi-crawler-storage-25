"""Jinja2 templates for report rendering."""

from pathlib import Path

TEMPLATES_DIR = Path(__file__).parent
