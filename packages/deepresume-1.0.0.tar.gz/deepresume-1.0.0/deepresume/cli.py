"""Command-line interface for DeepResume."""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from deepresume.config import Config
from deepresume.exceptions import DeepResumeError
from deepresume.models import CoverLetterTone, OutputFormat

console = Console()

BANNER = r"""
  ____                      _     _____
 |  _ \  ___  ___ _ __ ___ | |__ | ____|_  _____  ___
 | | | |/ _ \/ _ \ '_ ` _ \| '_ \|  _| \ \/ / _ \/ __|
 | |_| |  __/  __/ | | | | | |_) | |___ >  <  __/\__ \
 |____/ \___|\___|_| |_| |_|_.__/|_____/_/\_\___||___/

 AI career agent — 10x your interview chances in 30 seconds.
"""


def _setup_logging(level: str) -> None:
    """Configure logging with sanitized output."""
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.WARNING),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


def _get_config(api_key: str | None, api_base: str | None, model: str | None) -> Config:
    """Build config from CLI options and environment."""
    try:
        config = Config.from_env()
    except DeepResumeError:
        if not api_key:
            console.print("[red]Error:[/red] OPENAI_API_KEY environment variable is not set.")
            console.print("Set it with: [bold]export OPENAI_API_KEY='your-key-here'[/bold]")
            console.print("Or pass it with: [bold]--api-key YOUR_KEY[/bold]")
            raise SystemExit(1)
        config = Config(api_key=api_key)

    # Override with CLI options
    if api_key:
        config = Config(
            api_key=api_key,
            api_base=api_base or config.api_base,
            model=model or config.model,
        )
    if api_base:
        config.api_base = api_base
    if model:
        config.model = model

    return config


def _display_match(match: Any) -> None:
    """Display match results in a rich table."""
    table = Table(title="Resume-Job Match Analysis", show_header=True, header_style="bold cyan")
    table.add_column("Category", style="bold")
    table.add_column("Score", justify="right")
    table.add_column("Bar", justify="left")

    def _score_bar(score: float) -> str:
        filled = int(score / 5)
        empty = 20 - filled
        if score >= 80:
            color = "green"
        elif score >= 60:
            color = "yellow"
        else:
            color = "red"
        return f"[{color}]{'|' * filled}{'.' * empty}[/{color}]"

    table.add_row("Overall", f"{match.overall_score:.1f}%", _score_bar(match.overall_score))
    table.add_row("Keywords", f"{match.keyword_score:.1f}%", _score_bar(match.keyword_score))
    table.add_row("Skills", f"{match.skills_score:.1f}%", _score_bar(match.skills_score))
    table.add_row("Experience", f"{match.experience_score:.1f}%", _score_bar(match.experience_score))
    table.add_row("Education", f"{match.education_score:.1f}%", _score_bar(match.education_score))

    console.print(table)

    # Missing keywords
    if match.missing_keywords:
        console.print()
        kw_text = ", ".join(
            f"[yellow]{kw}[/yellow]" for kw in match.missing_keywords[:15]
        )
        console.print(Panel(kw_text, title="Missing Keywords", border_style="yellow"))

    # Suggestions
    if match.suggestions:
        console.print()
        console.print("[bold]Suggestions:[/bold]")
        for i, suggestion in enumerate(match.suggestions, 1):
            console.print(f"  {i}. {suggestion}")


@click.group()
@click.version_option(version="1.0.0", prog_name="deepresume")
def cli() -> None:
    """DeepResume — AI career agent that tailors your resume for every job."""
    pass


@cli.command()
@click.argument("resume", type=click.Path(exists=True))
@click.argument("job", nargs=-1, required=True)
@click.option(
    "--output", "-o",
    default="./deepresume_output",
    help="Output directory for generated files.",
)
@click.option(
    "--format", "-f",
    type=click.Choice(["pdf", "docx", "markdown"], case_sensitive=False),
    default="pdf",
    help="Output format for resume and cover letter.",
)
@click.option(
    "--tone", "-t",
    type=click.Choice([t.value for t in CoverLetterTone], case_sensitive=False),
    default="professional",
    help="Tone for the generated cover letter.",
)
@click.option(
    "--no-cover-letter",
    is_flag=True,
    default=False,
    help="Skip cover letter generation.",
)
@click.option(
    "--no-interview-prep",
    is_flag=True,
    default=False,
    help="Skip interview preparation.",
)
@click.option(
    "--api-key",
    envvar="OPENAI_API_KEY",
    default=None,
    help="OpenAI API key (or set OPENAI_API_KEY env var).",
)
@click.option(
    "--api-base",
    envvar="OPENAI_API_BASE",
    default=None,
    help="OpenAI-compatible API base URL.",
)
@click.option(
    "--model",
    envvar="DEEPRESUME_MODEL",
    default=None,
    help="AI model to use (default: gpt-4).",
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    default=False,
    help="Enable verbose output.",
)
def tailor(
    resume: str,
    job: tuple[str, ...],
    output: str,
    format: str,
    tone: str,
    no_cover_letter: bool,
    no_interview_prep: bool,
    api_key: str | None,
    api_base: str | None,
    model: str | None,
    verbose: bool,
) -> None:
    """Tailor your resume for one or more job listings.

    RESUME is the path to your resume file (PDF, DOCX, or JSON).
    JOB is one or more job listing URLs or text snippets.
    """
    _setup_logging("DEBUG" if verbose else "WARNING")
    config = _get_config(api_key, api_base, model)

    console.print(BANNER, style="bold blue")

    from deepresume.orchestrator import DeepResumeOrchestrator

    try:
        orch = DeepResumeOrchestrator(config)
        fmt = OutputFormat(format)
        cover_tone = CoverLetterTone(tone)

        if len(job) == 1:
            # Single job mode
            console.print(f"[bold]Resume:[/bold] {resume}")
            console.print(f"[bold]Job:[/bold] {job[0][:80]}...")
            console.print()

            with console.status("[bold green]Processing..."):
                results = orch.run_full_pipeline(
                    resume_source=resume,
                    job_source=job[0],
                    output_dir=output,
                    fmt=fmt,
                    tone=cover_tone,
                    include_cover_letter=not no_cover_letter,
                    include_interview_prep=not no_interview_prep,
                )

            # Parse the match from the report
            resume_data = orch.parse_resume(resume)
            job_data = orch.parse_job(job[0])
            match = orch.analyze(resume_data, job_data)
            _display_match(match)

        else:
            # Batch mode
            console.print(f"[bold]Resume:[/bold] {resume}")
            console.print(f"[bold]Jobs:[/bold] {len(job)} listings")
            console.print()

            with console.status("[bold green]Processing batch..."):
                all_results = orch.run_batch(
                    resume_source=resume,
                    job_sources=list(job),
                    output_dir=output,
                    fmt=fmt,
                    tone=cover_tone,
                )

            console.print(f"\n[bold green]Processed {len(all_results)} jobs.[/bold green]")

        # Show output files
        console.print()
        console.print("[bold]Generated files:[/bold]")
        if len(job) == 1 and isinstance(results, dict):
            for label, path in results.items():
                console.print(f"  [{label}] {path}")
        else:
            console.print(f"  Output directory: {Path(output).resolve()}")

        console.print()
        console.print(
            "[bold green]Done![/bold green] Your tailored resume is ready."
        )

    except DeepResumeError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@cli.command()
@click.argument("resume", type=click.Path(exists=True))
@click.argument("job", nargs=1)
@click.option(
    "--api-key",
    envvar="OPENAI_API_KEY",
    default=None,
    help="OpenAI API key.",
)
@click.option(
    "--api-base",
    envvar="OPENAI_API_BASE",
    default=None,
    help="API base URL.",
)
@click.option(
    "--model",
    envvar="DEEPRESUME_MODEL",
    default=None,
    help="AI model to use.",
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    default=False,
    help="Enable verbose output.",
)
def analyze(
    resume: str,
    job: str,
    api_key: str | None,
    api_base: str | None,
    model: str | None,
    verbose: bool,
) -> None:
    """Analyze how well your resume matches a job listing.

    Shows match scores, missing keywords, and improvement suggestions.
    Does NOT generate any output files.
    """
    _setup_logging("DEBUG" if verbose else "WARNING")
    config = _get_config(api_key, api_base, model)

    console.print(BANNER, style="bold blue")

    from deepresume.orchestrator import DeepResumeOrchestrator

    try:
        orch = DeepResumeOrchestrator(config)

        with console.status("[bold green]Analyzing..."):
            resume_data = orch.parse_resume(resume)
            job_data = orch.parse_job(job)
            match = orch.analyze(resume_data, job_data)

            # Also check ATS compatibility
            ats_warnings = orch.check_ats(resume_data)

        console.print(f"[bold]Resume:[/bold] {resume}")
        console.print(f"[bold]Job:[/bold] {job[:80]}...")
        console.print()

        _display_match(match)

        if ats_warnings:
            console.print()
            console.print("[bold]ATS Compatibility Warnings:[/bold]")
            for warning in ats_warnings:
                console.print(f"  [yellow]![/yellow] {warning}")

    except DeepResumeError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@cli.command()
@click.argument("resume", type=click.Path(exists=True))
@click.argument("job", nargs=1)
@click.option(
    "--output", "-o",
    default="./cover_letter_output",
    help="Output directory.",
)
@click.option(
    "--format", "-f",
    type=click.Choice(["pdf", "docx", "markdown"], case_sensitive=False),
    default="pdf",
    help="Output format.",
)
@click.option(
    "--tone", "-t",
    type=click.Choice([t.value for t in CoverLetterTone], case_sensitive=False),
    default="professional",
    help="Cover letter tone.",
)
@click.option(
    "--api-key",
    envvar="OPENAI_API_KEY",
    default=None,
    help="OpenAI API key.",
)
@click.option(
    "--api-base",
    envvar="OPENAI_API_BASE",
    default=None,
    help="API base URL.",
)
@click.option(
    "--model",
    envvar="DEEPRESUME_MODEL",
    default=None,
    help="AI model to use.",
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    default=False,
    help="Enable verbose output.",
)
def cover_letter(
    resume: str,
    job: str,
    output: str,
    format: str,
    tone: str,
    api_key: str | None,
    api_base: str | None,
    model: str | None,
    verbose: bool,
) -> None:
    """Generate a cover letter for a job listing.

    Creates a customized cover letter based on your resume and the job listing.
    """
    _setup_logging("DEBUG" if verbose else "WARNING")
    config = _get_config(api_key, api_base, model)

    console.print(BANNER, style="bold blue")

    from deepresume.orchestrator import DeepResumeOrchestrator

    try:
        orch = DeepResumeOrchestrator(config)
        fmt = OutputFormat(format)
        cover_tone = CoverLetterTone(tone)

        with console.status("[bold green]Generating cover letter..."):
            resume_data = orch.parse_resume(resume)
            job_data = orch.parse_job(job)
            match = orch.analyze(resume_data, job_data)
            tailored = orch.tailor(resume_data, job_data, match)
            cover_text = orch.generate_cover_letter(
                resume_data, job_data, tailored, cover_tone
            )

            ext = fmt.value
            path = orch.output_cover_letter(
                tailored, cover_text, Path(output) / f"cover_letter.{ext}", fmt
            )

        console.print(f"\n[bold green]Cover letter generated![/bold green]")
        console.print(f"  Output: {path}")
        console.print()
        console.print(Panel(cover_text, title="Cover Letter Preview", border_style="green"))

    except DeepResumeError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@cli.command()
@click.argument("resume", type=click.Path(exists=True))
@click.argument("job", nargs=1)
@click.option(
    "--output", "-o",
    default="./interview_prep",
    help="Output directory.",
)
@click.option(
    "--api-key",
    envvar="OPENAI_API_KEY",
    default=None,
    help="OpenAI API key.",
)
@click.option(
    "--api-base",
    envvar="OPENAI_API_BASE",
    default=None,
    help="API base URL.",
)
@click.option(
    "--model",
    envvar="DEEPRESUME_MODEL",
    default=None,
    help="AI model to use.",
)
@click.option(
    "--verbose", "-v",
    is_flag=True,
    default=False,
    help="Enable verbose output.",
)
def interview(
    resume: str,
    job: str,
    output: str,
    api_key: str | None,
    api_base: str | None,
    model: str | None,
    verbose: bool,
) -> None:
    """Generate interview preparation questions.

    Creates a study guide with likely interview questions based on the job listing.
    """
    _setup_logging("DEBUG" if verbose else "WARNING")
    config = _get_config(api_key, api_base, model)

    console.print(BANNER, style="bold blue")

    from deepresume.orchestrator import DeepResumeOrchestrator

    try:
        orch = DeepResumeOrchestrator(config)

        with console.status("[bold green]Preparing interview questions..."):
            resume_data = orch.parse_resume(resume)
            job_data = orch.parse_job(job)
            questions = orch.generate_interview_prep(resume_data, job_data)

            if questions:
                path = orch.generate_interview_guide(
                    resume_data, job_data, questions, Path(output) / "interview_prep.md"
                )

        console.print(f"\n[bold green]Interview preparation guide generated![/bold green]")
        if questions:
            console.print(f"  Output: {path}")
            console.print()
            console.print(f"[bold]{len(questions)} questions prepared:[/bold]")
            for i, q in enumerate(questions, 1):
                console.print(f"  {i}. {q}")

    except DeepResumeError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@cli.command()
@click.argument("resume", type=click.Path(exists=True))
def check(resume: str) -> None:
    """Check resume for ATS compatibility issues.

    Analyzes your resume format and content for common ATS pitfalls.
    Does NOT require an API key.
    """
    console.print(BANNER, style="bold blue")

    from deepresume.orchestrator import DeepResumeOrchestrator

    try:
        # ATS check does not need AI, but orchestrator requires config
        # We use a dummy config for this
        config = Config(api_key="dummy_for_ats_check")
        orch = DeepResumeOrchestrator(config)

        resume_data = orch.parse_resume(resume)
        warnings = orch.check_ats(resume_data)

        console.print(f"[bold]Resume:[/bold] {resume}")
        console.print()

        if warnings:
            console.print(f"[bold yellow]{len(warnings)} ATS issues found:[/bold yellow]")
            for i, warning in enumerate(warnings, 1):
                console.print(f"  {i}. [yellow]![/yellow] {warning}")
        else:
            console.print("[bold green]No ATS issues found! Your resume looks ATS-friendly.[/bold green]")

    except DeepResumeError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@cli.command()
def info() -> None:
    """Show DeepResume version and configuration info."""
    from deepresume import __version__

    console.print(BANNER, style="bold blue")

    table = Table(title="DeepResume Configuration", show_header=False)
    table.add_column("Key", style="bold")
    table.add_column("Value")

    table.add_row("Version", __version__)
    table.add_row("Python", sys.version.split()[0])

    try:
        config = Config.from_env()
        table.add_row("API Base", config.api_base)
        table.add_row("Model", config.model)
        table.add_row("API Key", "***configured***" if config.api_key else "[red]NOT SET[/red]")
    except DeepResumeError:
        table.add_row("API Key", "[red]NOT SET[/red]")

    table.add_row(
        "Supported Formats",
        "PDF, DOCX, Markdown (input); PDF, DOCX, Markdown (output)",
    )
    console.print(table)


if __name__ == "__main__":
    cli()
