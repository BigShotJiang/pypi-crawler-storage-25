"""Utility functions for text processing and sanitization."""

from __future__ import annotations

import re
import string
from typing import Any


SENSITIVE_PATTERNS = [
    (re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b"), "[EMAIL]"),
    (re.compile(r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b"), "[PHONE]"),
    (re.compile(r"\b\d{3}[-]\d{2}[-]\d{4}\b"), "[SSN]"),
    (re.compile(r"\b(?:\+1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"), "[PHONE]"),
]


def sanitize_for_logging(text: str) -> str:
    """Remove personally identifiable information from text for safe logging.

    Args:
        text: Input text that may contain PII.

    Returns:
        Text with PII replaced by placeholder tokens.
    """
    sanitized = text
    for pattern, replacement in SENSITIVE_PATTERNS:
        sanitized = pattern.sub(replacement, sanitized)
    return sanitized


def sanitize_input(text: str) -> str:
    """Sanitize user input to prevent injection attacks.

    Args:
        text: Raw user input.

    Returns:
        Cleaned text with control characters removed.
    """
    # Replace null bytes and control characters with space (except newline/tab)
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", " ", text)
    # Normalize whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return text


def extract_keywords(text: str) -> list[str]:
    """Extract meaningful keywords from text.

    Removes common stop words and returns lowercased unique terms.

    Args:
        text: Input text to extract keywords from.

    Returns:
        List of unique keywords sorted by frequency (descending).
    """
    stop_words = {
        "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for",
        "of", "with", "by", "from", "is", "are", "was", "were", "be", "been",
        "being", "have", "has", "had", "do", "does", "did", "will", "would",
        "could", "should", "may", "might", "must", "shall", "can", "need",
        "dare", "ought", "used", "it", "its", "this", "that", "these", "those",
        "i", "me", "my", "myself", "we", "our", "ours", "ourselves", "you",
        "your", "yours", "yourself", "yourselves", "he", "him", "his", "himself",
        "she", "her", "hers", "herself", "they", "them", "their", "theirs",
        "themselves", "what", "which", "who", "whom", "when", "where", "why",
        "how", "all", "each", "every", "both", "few", "more", "most", "other",
        "some", "such", "no", "not", "only", "own", "same", "so", "than",
        "too", "very", "just", "because", "as", "until", "while", "about",
        "between", "through", "during", "before", "after", "above", "below",
        "up", "down", "out", "off", "over", "under", "again", "further",
        "then", "once", "here", "there", "any", "if", "into", "also",
        "etc", "e.g.", "ie", "eg", "including", "include", "includes",
        "able", "work", "working", "experience", "team", "strong",
        "excellent", "good", "great", "looking", "join", "opportunity",
        "position", "role", "company", "candidate", "job", "apply",
        "required", "preferred", "qualification", "qualifications",
        "responsibility", "responsibilities", "requirement", "requirements",
        "year", "years", "plus", "new", "well", "using", "use", "used",
        "ensure", "across", "help", "within", "make", "based", "ability",
        "knowledge", "understanding", "related", "relevant", "field",
        "like", "set", "sets", "skills", "skill", "minimum", "ideal",
    }

    # Remove punctuation and convert to lowercase
    cleaned = text.lower()
    cleaned = cleaned.translate(str.maketrans("", "", string.punctuation.replace("-", "").replace("+", "")))
    words = cleaned.split()

    # Count frequencies
    freq: dict[str, int] = {}
    for word in words:
        if len(word) > 2 and word not in stop_words:
            freq[word] = freq.get(word, 0) + 1

    # Sort by frequency
    sorted_keywords = sorted(freq.keys(), key=lambda w: freq[w], reverse=True)
    return sorted_keywords


def compute_keyword_density(text: str, keywords: list[str]) -> dict[str, float]:
    """Compute keyword density as percentage of total words.

    Args:
        text: The text to analyze.
        keywords: Keywords to compute density for.

    Returns:
        Dictionary mapping keyword to its density percentage.
    """
    words = text.lower().split()
    total = len(words)
    if total == 0:
        return {kw: 0.0 for kw in keywords}

    density: dict[str, float] = {}
    text_lower = text.lower()
    for keyword in keywords:
        count = text_lower.count(keyword.lower())
        density[keyword] = round((count / total) * 100, 2)
    return density


def truncate_text(text: str, max_length: int = 4000) -> str:
    """Truncate text to a maximum length, preserving word boundaries.

    Args:
        text: Text to truncate.
        max_length: Maximum character length.

    Returns:
        Truncated text with ellipsis if needed.
    """
    if len(text) <= max_length:
        return text
    truncated = text[:max_length]
    last_space = truncated.rfind(" ")
    if last_space > max_length * 0.8:
        truncated = truncated[:last_space]
    return truncated + "..."


def clean_html(html: str) -> str:
    """Strip HTML tags and decode entities.

    Args:
        html: HTML content.

    Returns:
        Clean plain text.
    """
    from html.parser import HTMLParser
    from io import StringIO

    class _HTMLStripper(HTMLParser):
        def __init__(self) -> None:
            super().__init__()
            self._text = StringIO()

        def handle_data(self, data: str) -> None:
            self._text.write(data)

        def get_text(self) -> str:
            return self._text.getvalue()

    stripper = _HTMLStripper()
    stripper.feed(html)
    return stripper.get_text()


def format_score(score: float) -> str:
    """Format a match score as a visual bar with percentage.

    Args:
        score: Score between 0 and 100.

    Returns:
        Formatted string with bar and percentage.
    """
    filled = int(score / 5)
    empty = 20 - filled
    bar = "|" * filled + "." * empty
    return f"[{bar}] {score:.1f}%"
