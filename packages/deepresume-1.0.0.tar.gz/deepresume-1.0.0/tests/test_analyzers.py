"""Tests for ATS analyzer."""

import pytest

from deepresume.analyzers.ats_analyzer import ATSAnalyzer
from deepresume.models import (
    ContactInfo,
    EducationEntry,
    ExperienceEntry,
    JobListing,
    MatchResult,
    ResumeData,
)


@pytest.fixture
def sample_resume() -> ResumeData:
    """Create a sample resume for testing."""
    return ResumeData(
        contact=ContactInfo(
            name="Jane Developer",
            email="jane@example.com",
            phone="(555) 123-4567",
        ),
        summary="Experienced Python developer with 5 years of web development experience.",
        skills=[
            "Python", "Django", "Flask", "PostgreSQL", "Redis",
            "Docker", "AWS", "JavaScript", "React", "Git",
        ],
        experience=[
            ExperienceEntry(
                title="Senior Python Developer",
                company="TechCorp",
                start_date="Jan 2020",
                end_date="Present",
                descriptions=[
                    "Built REST APIs serving 1M requests/day",
                    "Led migration to microservices architecture",
                    "Reduced deployment time by 60% using CI/CD pipelines",
                ],
            ),
            ExperienceEntry(
                title="Python Developer",
                company="StartupXYZ",
                start_date="Jun 2018",
                end_date="Dec 2019",
                descriptions=[
                    "Developed Django web application for e-commerce",
                    "Implemented payment processing with Stripe",
                ],
            ),
        ],
        education=[
            EducationEntry(
                degree="BS Computer Science",
                institution="State University",
                graduation_date="2018",
                gpa="3.7",
            )
        ],
        raw_text=(
            "Jane Developer Experienced Python developer Django Flask PostgreSQL "
            "Redis Docker AWS JavaScript React Senior Python Developer TechCorp "
            "Built REST APIs Led migration Reduced deployment time Python Developer "
            "StartupXYZ Developed Django web application BS Computer Science"
        ),
    )


@pytest.fixture
def sample_job() -> JobListing:
    """Create a sample job listing for testing."""
    return JobListing(
        title="Senior Python Developer",
        company="Acme Inc",
        location="San Francisco, CA",
        requirements=[
            "5+ years Python experience",
            "Django or Flask proficiency",
            "PostgreSQL and Redis knowledge",
            "Docker and Kubernetes experience",
            "AWS or GCP cloud services",
        ],
        responsibilities=[
            "Design and build REST APIs",
            "Mentor junior developers",
            "Implement CI/CD pipelines",
        ],
        raw_text=(
            "Senior Python Developer at Acme Inc Requirements 5 years Python "
            "Django Flask PostgreSQL Redis Docker Kubernetes AWS GCP cloud "
            "Responsibilities Design build REST APIs Mentor junior developers "
            "CI/CD pipelines deployment automation microservices"
        ),
    )


@pytest.fixture
def analyzer() -> ATSAnalyzer:
    return ATSAnalyzer()


class TestATSAnalyzerMatch:
    """Tests for match analysis."""

    def test_analyze_returns_match_result(
        self, analyzer: ATSAnalyzer, sample_resume: ResumeData, sample_job: JobListing
    ) -> None:
        result = analyzer.analyze(sample_resume, sample_job)
        assert isinstance(result, MatchResult)

    def test_overall_score_in_range(
        self, analyzer: ATSAnalyzer, sample_resume: ResumeData, sample_job: JobListing
    ) -> None:
        result = analyzer.analyze(sample_resume, sample_job)
        assert 0 <= result.overall_score <= 100

    def test_keyword_score_in_range(
        self, analyzer: ATSAnalyzer, sample_resume: ResumeData, sample_job: JobListing
    ) -> None:
        result = analyzer.analyze(sample_resume, sample_job)
        assert 0 <= result.keyword_score <= 100

    def test_matched_keywords_found(
        self, analyzer: ATSAnalyzer, sample_resume: ResumeData, sample_job: JobListing
    ) -> None:
        result = analyzer.analyze(sample_resume, sample_job)
        assert len(result.matched_keywords) > 0

    def test_suggestions_generated(
        self, analyzer: ATSAnalyzer, sample_resume: ResumeData, sample_job: JobListing
    ) -> None:
        result = analyzer.analyze(sample_resume, sample_job)
        assert len(result.suggestions) > 0

    def test_keyword_density_populated(
        self, analyzer: ATSAnalyzer, sample_resume: ResumeData, sample_job: JobListing
    ) -> None:
        result = analyzer.analyze(sample_resume, sample_job)
        assert isinstance(result.keyword_density, dict)

    def test_good_match_has_higher_score(
        self, analyzer: ATSAnalyzer
    ) -> None:
        resume = ResumeData(
            skills=["Python", "Django", "PostgreSQL", "Docker", "AWS"],
            raw_text="Python Django PostgreSQL Docker AWS developer",
        )
        job = JobListing(
            title="Python Developer",
            raw_text="Python Django PostgreSQL Docker AWS developer",
        )
        result = analyzer.analyze(resume, job)
        assert result.overall_score > 50

    def test_poor_match_has_lower_score(
        self, analyzer: ATSAnalyzer
    ) -> None:
        resume = ResumeData(
            skills=["Graphic Design", "Photoshop", "Illustrator"],
            raw_text="Graphic designer with Photoshop and Illustrator skills",
        )
        job = JobListing(
            title="Python Developer",
            raw_text="Python Django PostgreSQL Docker Kubernetes AWS microservices",
        )
        result = analyzer.analyze(resume, job)
        assert result.overall_score < 60


class TestATSCompatibility:
    """Tests for ATS compatibility checking."""

    def test_complete_resume_no_warnings(
        self, analyzer: ATSAnalyzer, sample_resume: ResumeData
    ) -> None:
        warnings = analyzer.check_ats_compatibility(sample_resume)
        # A well-structured resume should have few warnings
        assert isinstance(warnings, list)

    def test_empty_resume_warnings(self, analyzer: ATSAnalyzer) -> None:
        resume = ResumeData()
        warnings = analyzer.check_ats_compatibility(resume)
        assert len(warnings) > 0
        assert any("summary" in w.lower() for w in warnings)
        assert any("skills" in w.lower() for w in warnings)

    def test_no_email_warning(self, analyzer: ATSAnalyzer) -> None:
        resume = ResumeData(
            contact=ContactInfo(name="Test"),
            skills=["Python"] * 12,
        )
        warnings = analyzer.check_ats_compatibility(resume)
        assert any("email" in w.lower() for w in warnings)

    def test_too_few_skills_warning(self, analyzer: ATSAnalyzer) -> None:
        resume = ResumeData(skills=["Python", "Django"])
        warnings = analyzer.check_ats_compatibility(resume)
        assert any("skills" in w.lower() for w in warnings)

    def test_too_many_skills_warning(self, analyzer: ATSAnalyzer) -> None:
        resume = ResumeData(skills=[f"Skill{i}" for i in range(35)])
        warnings = analyzer.check_ats_compatibility(resume)
        assert any("trimming" in w.lower() or "consider" in w.lower() for w in warnings)

    def test_missing_education_warning(self, analyzer: ATSAnalyzer) -> None:
        resume = ResumeData()
        warnings = analyzer.check_ats_compatibility(resume)
        assert any("education" in w.lower() for w in warnings)
