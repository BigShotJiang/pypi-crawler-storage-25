"""Tests for configuration module."""

import os

import pytest

from deepresume.config import Config
from deepresume.exceptions import ConfigurationError


class TestConfig:
    """Tests for Config class."""

    def test_from_dict_valid(self) -> None:
        config = Config.from_dict({"api_key": "sk-test123"})
        assert config.api_key == "sk-test123"
        assert config.model == "gpt-4"
        assert config.api_base == "https://api.openai.com/v1"

    def test_from_dict_custom(self) -> None:
        config = Config.from_dict({
            "api_key": "sk-test",
            "api_base": "https://custom.api.com/v1",
            "model": "gpt-3.5-turbo",
            "max_tokens": 2048,
            "temperature": 0.5,
        })
        assert config.api_base == "https://custom.api.com/v1"
        assert config.model == "gpt-3.5-turbo"
        assert config.max_tokens == 2048
        assert config.temperature == 0.5

    def test_from_dict_missing_key(self) -> None:
        with pytest.raises(ConfigurationError):
            Config.from_dict({})

    def test_from_env_missing_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        with pytest.raises(ConfigurationError):
            Config.from_env()

    def test_from_env_with_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("OPENAI_API_KEY", "sk-envtest")
        config = Config.from_env()
        assert config.api_key == "sk-envtest"

    def test_from_env_custom_base(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        monkeypatch.setenv("OPENAI_API_BASE", "https://custom.api.com/v1")
        config = Config.from_env()
        assert config.api_base == "https://custom.api.com/v1"

    def test_from_env_model(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        monkeypatch.setenv("DEEPRESUME_MODEL", "gpt-3.5-turbo")
        config = Config.from_env()
        assert config.model == "gpt-3.5-turbo"

    def test_sanitize_logs_default(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        config = Config.from_env()
        assert config.sanitize_logs is True

    def test_sanitize_logs_disabled(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        monkeypatch.setenv("DEEPRESUME_SANITIZE_LOGS", "false")
        config = Config.from_env()
        assert config.sanitize_logs is False

    def test_defaults(self) -> None:
        config = Config(api_key="sk-test")
        assert config.max_tokens == 4096
        assert config.temperature == 0.7
        assert config.timeout == 60
        assert config.log_level == "WARNING"
        assert config.sanitize_logs is True
