"""Tests for Pydantic data models."""

import pytest

from deepresume.models import (
    ContactInfo,
    CoverLetterTone,
    EducationEntry,
    ExperienceEntry,
    JobListing,
    MatchResult,
    OutputFormat,
    ResumeData,
    TailoredResume,
)


class TestContactInfo:
    """Tests for ContactInfo model."""

    def test_default_contact(self) -> None:
        contact = ContactInfo()
        assert contact.name == ""
        assert contact.email == ""

    def test_email_sanitization(self) -> None:
        contact = ContactInfo(email="  John@Example.COM  ")
        assert contact.email == "john@example.com"

    def test_full_contact(self) -> None:
        contact = ContactInfo(
            name="Jane Doe",
            email="jane@example.com",
            phone="(555) 123-4567",
            location="San Francisco, CA",
            linkedin="https://linkedin.com/in/janedoe",
            github="https://github.com/janedoe",
        )
        assert contact.name == "Jane Doe"
        assert contact.email == "jane@example.com"


class TestResumeData:
    """Tests for ResumeData model."""

    def test_default_resume(self) -> None:
        resume = ResumeData()
        assert resume.contact.name == ""
        assert resume.skills == []
        assert resume.experience == []

    def test_full_name_property(self) -> None:
        resume = ResumeData(contact=ContactInfo(name="Alice Smith"))
        assert resume.full_name == "Alice Smith"

    def test_full_name_fallback(self) -> None:
        resume = ResumeData()
        assert resume.full_name == "Candidate"

    def test_resume_with_experience(self) -> None:
        exp = ExperienceEntry(
            title="Software Engineer",
            company="Acme Corp",
            start_date="Jan 2020",
            end_date="Present",
            descriptions=["Led team of 5", "Shipped product v2.0"],
        )
        resume = ResumeData(experience=[exp])
        assert len(resume.experience) == 1
        assert resume.experience[0].title == "Software Engineer"
        assert len(resume.experience[0].descriptions) == 2


class TestJobListing:
    """Tests for JobListing model."""

    def test_default_job(self) -> None:
        job = JobListing()
        assert job.title == ""
        assert job.requirements == []

    def test_full_job(self) -> None:
        job = JobListing(
            title="Senior Python Developer",
            company="TechCorp",
            location="Remote",
            requirements=["5+ years Python", "AWS experience"],
            responsibilities=["Build APIs", "Mentor juniors"],
        )
        assert job.title == "Senior Python Developer"
        assert len(job.requirements) == 2


class TestMatchResult:
    """Tests for MatchResult model."""

    def test_default_match(self) -> None:
        match = MatchResult(overall_score=75.5)
        assert match.overall_score == 75.5
        assert match.keyword_score == 0.0
        assert match.matched_keywords == []

    def test_score_bounds(self) -> None:
        match = MatchResult(overall_score=100.0)
        assert match.overall_score == 100.0

        match = MatchResult(overall_score=0.0)
        assert match.overall_score == 0.0

    def test_invalid_score(self) -> None:
        with pytest.raises(Exception):
            MatchResult(overall_score=150.0)

    def test_negative_score(self) -> None:
        with pytest.raises(Exception):
            MatchResult(overall_score=-10.0)


class TestOutputFormat:
    """Tests for OutputFormat enum."""

    def test_values(self) -> None:
        assert OutputFormat.PDF.value == "pdf"
        assert OutputFormat.DOCX.value == "docx"
        assert OutputFormat.MARKDOWN.value == "markdown"

    def test_from_string(self) -> None:
        assert OutputFormat("pdf") == OutputFormat.PDF


class TestCoverLetterTone:
    """Tests for CoverLetterTone enum."""

    def test_all_tones(self) -> None:
        tones = list(CoverLetterTone)
        assert len(tones) == 5

    def test_default_tone(self) -> None:
        assert CoverLetterTone.PROFESSIONAL.value == "professional"


class TestTailoredResume:
    """Tests for TailoredResume model."""

    def test_create_tailored(self) -> None:
        resume = ResumeData(contact=ContactInfo(name="Test"))
        job = JobListing(title="Dev")
        match = MatchResult(overall_score=80.0)
        tailored = TailoredResume(
            original_resume=resume,
            job=job,
            match=match,
            tailored_summary="Optimized summary",
        )
        assert tailored.tailored_summary == "Optimized summary"
        assert tailored.original_resume.contact.name == "Test"
