"""Tests for utility functions."""

import pytest

from deepresume.utils import (
    clean_html,
    compute_keyword_density,
    extract_keywords,
    format_score,
    sanitize_for_logging,
    sanitize_input,
    truncate_text,
)


class TestSanitizeForLogging:
    """Tests for PII sanitization in logs."""

    def test_email_removal(self) -> None:
        text = "Contact john@example.com for details"
        result = sanitize_for_logging(text)
        assert "john@example.com" not in result
        assert "[EMAIL]" in result

    def test_phone_removal(self) -> None:
        text = "Call 555-123-4567 anytime"
        result = sanitize_for_logging(text)
        assert "555-123-4567" not in result
        assert "[PHONE]" in result

    def test_ssn_removal(self) -> None:
        text = "SSN: 123-45-6789"
        result = sanitize_for_logging(text)
        assert "123-45-6789" not in result
        assert "[SSN]" in result

    def test_multiple_pii(self) -> None:
        text = "Email: jane@corp.com Phone: 555-999-0000"
        result = sanitize_for_logging(text)
        assert "jane@corp.com" not in result
        assert "555-999-0000" not in result

    def test_no_pii(self) -> None:
        text = "Python developer with 5 years experience"
        result = sanitize_for_logging(text)
        assert result == text


class TestSanitizeInput:
    """Tests for input sanitization."""

    def test_removes_control_chars(self) -> None:
        text = "Hello\x00World\x07"
        result = sanitize_input(text)
        assert result == "Hello World"

    def test_normalizes_whitespace(self) -> None:
        text = "too   many    spaces"
        result = sanitize_input(text)
        assert result == "too many spaces"

    def test_strips(self) -> None:
        text = "  hello  "
        result = sanitize_input(text)
        assert result == "hello"

    def test_preserves_normal_text(self) -> None:
        text = "Normal text with punctuation!"
        result = sanitize_input(text)
        assert result == text


class TestExtractKeywords:
    """Tests for keyword extraction."""

    def test_basic_extraction(self) -> None:
        text = "Python developer with experience in Django, Flask, and REST APIs"
        keywords = extract_keywords(text)
        assert "python" in keywords
        assert "django" in keywords
        assert "flask" in keywords

    def test_stop_words_filtered(self) -> None:
        text = "The developer is working on a new project"
        keywords = extract_keywords(text)
        assert "the" not in keywords
        assert "is" not in keywords
        assert "a" not in keywords

    def test_frequency_sorting(self) -> None:
        text = "python python python javascript javascript css"
        keywords = extract_keywords(text)
        assert keywords.index("python") < keywords.index("javascript")
        assert keywords.index("javascript") < keywords.index("css")

    def test_empty_text(self) -> None:
        keywords = extract_keywords("")
        assert keywords == []

    def test_short_words_filtered(self) -> None:
        text = "I am a go developer"
        keywords = extract_keywords(text)
        assert "go" not in keywords  # Too short (2 chars)

    def test_case_insensitive(self) -> None:
        text = "Python PYTHON python"
        keywords = extract_keywords(text)
        assert "python" in keywords
        assert keywords.count("python") == 1


class TestComputeKeywordDensity:
    """Tests for keyword density computation."""

    def test_basic_density(self) -> None:
        text = "python is great python is awesome python"
        density = compute_keyword_density(text, ["python"])
        assert density["python"] > 0

    def test_zero_density(self) -> None:
        text = "hello world"
        density = compute_keyword_density(text, ["python"])
        assert density["python"] == 0.0

    def test_empty_text(self) -> None:
        density = compute_keyword_density("", ["python"])
        assert density["python"] == 0.0

    def test_multiple_keywords(self) -> None:
        text = "python javascript python css"
        density = compute_keyword_density(text, ["python", "javascript", "css"])
        assert density["python"] > density["css"]


class TestTruncateText:
    """Tests for text truncation."""

    def test_short_text_unchanged(self) -> None:
        text = "Short text"
        result = truncate_text(text, max_length=100)
        assert result == text

    def test_long_text_truncated(self) -> None:
        text = "word " * 2000
        result = truncate_text(text, max_length=100)
        assert len(result) <= 103  # 100 + "..."
        assert result.endswith("...")

    def test_exact_length(self) -> None:
        text = "a" * 100
        result = truncate_text(text, max_length=100)
        assert result == text


class TestCleanHtml:
    """Tests for HTML stripping."""

    def test_simple_tags(self) -> None:
        html = "<p>Hello <b>World</b></p>"
        result = clean_html(html)
        assert "Hello" in result
        assert "World" in result
        assert "<p>" not in result
        assert "<b>" not in result

    def test_nested_tags(self) -> None:
        html = "<div><ul><li>Item 1</li><li>Item 2</li></ul></div>"
        result = clean_html(html)
        assert "Item 1" in result
        assert "Item 2" in result
        assert "<li>" not in result

    def test_plain_text(self) -> None:
        text = "Just plain text"
        result = clean_html(text)
        assert result == text


class TestFormatScore:
    """Tests for score formatting."""

    def test_perfect_score(self) -> None:
        result = format_score(100.0)
        assert "100.0%" in result
        assert "|" in result

    def test_zero_score(self) -> None:
        result = format_score(0.0)
        assert "0.0%" in result
        assert "." in result

    def test_mid_score(self) -> None:
        result = format_score(50.0)
        assert "50.0%" in result
