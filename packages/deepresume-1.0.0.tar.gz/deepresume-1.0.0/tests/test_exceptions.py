"""Tests for custom exceptions."""

from deepresume.exceptions import (
    AIError,
    ConfigurationError,
    DeepResumeError,
    JobFetchError,
    OutputError,
    ParseError,
    ValidationError,
)


class TestExceptions:
    """Tests for exception hierarchy."""

    def test_base_exception(self) -> None:
        err = DeepResumeError("test error")
        assert str(err) == "test error"
        assert isinstance(err, Exception)

    def test_configuration_error(self) -> None:
        err = ConfigurationError("bad config")
        assert isinstance(err, DeepResumeError)

    def test_parse_error(self) -> None:
        err = ParseError("parse failed")
        assert isinstance(err, DeepResumeError)

    def test_ai_error(self) -> None:
        err = AIError("api failed")
        assert isinstance(err, DeepResumeError)

    def test_output_error(self) -> None:
        err = OutputError("output failed")
        assert isinstance(err, DeepResumeError)

    def test_job_fetch_error(self) -> None:
        err = JobFetchError("fetch failed")
        assert isinstance(err, DeepResumeError)

    def test_validation_error(self) -> None:
        err = ValidationError("invalid input")
        assert isinstance(err, DeepResumeError)

    def test_catch_all_with_base(self) -> None:
        """All custom exceptions should be catchable via DeepResumeError."""
        exceptions = [
            ConfigurationError("a"),
            ParseError("b"),
            AIError("c"),
            OutputError("d"),
            JobFetchError("e"),
            ValidationError("f"),
        ]
        for exc in exceptions:
            try:
                raise exc
            except DeepResumeError as e:
                assert isinstance(e, DeepResumeError)
