"""Tests for resume and job parsers."""

import json
import tempfile
from pathlib import Path

import pytest

from deepresume.exceptions import ParseError, ValidationError
from deepresume.models import JobListing, ResumeData
from deepresume.parsers.job_parser import JobParser
from deepresume.parsers.resume_parser import ResumeParser


class TestResumeParserText:
    """Tests for ResumeParser with raw text input."""

    def setup_method(self) -> None:
        self.parser = ResumeParser()

    def test_parse_text_basic(self) -> None:
        text = """
        John Doe
        john@example.com
        (555) 123-4567

        Summary: Experienced Python developer with 5 years in web development.

        Skills: Python, Django, Flask, PostgreSQL, Docker, AWS, JavaScript, React

        Experience:
        Senior Developer at TechCorp (Jan 2020 - Present)
        - Led team of 5 developers
        - Built microservices architecture
        - Reduced deployment time by 50%
        """
        resume = self.parser.parse_text(text)
        assert isinstance(resume, ResumeData)
        assert resume.contact.email == "john@example.com"
        assert resume.raw_text != ""

    def test_parse_text_empty(self) -> None:
        with pytest.raises(ValidationError):
            self.parser.parse_text("")

    def test_parse_text_whitespace_only(self) -> None:
        with pytest.raises(ValidationError):
            self.parser.parse_text("   \n   \t   ")

    def test_contact_extraction(self) -> None:
        text = """
        Jane Smith
        jane.smith@company.com
        (415) 555-9876
        https://linkedin.com/in/janesmith
        https://github.com/janesmith
        """
        resume = self.parser.parse_text(text)
        assert resume.contact.email == "jane.smith@company.com"
        assert resume.contact.phone == "(415) 555-9876"
        assert "linkedin.com/in/janesmith" in resume.contact.linkedin
        assert "github.com/janesmith" in resume.contact.github

    def test_skills_extraction(self) -> None:
        text = """
        Skills: Python, JavaScript, React, Docker, AWS, PostgreSQL, Redis, Git
        """
        resume = self.parser.parse_text(text)
        assert len(resume.skills) > 0
        # Check some skills are extracted (title-cased)
        skills_lower = [s.lower() for s in resume.skills]
        assert "python" in skills_lower

    def test_summary_extraction(self) -> None:
        text = """
        Summary: Full-stack developer with 8 years of experience building
        scalable web applications using Python and JavaScript.
        """
        resume = self.parser.parse_text(text)
        assert resume.summary != ""
        assert "Full-stack" in resume.summary or "full-stack" in resume.summary.lower()


class TestResumeParserJSON:
    """Tests for ResumeParser with JSON files."""

    def setup_method(self) -> None:
        self.parser = ResumeParser()

    def test_parse_json_file(self) -> None:
        resume_json = {
            "contact": {
                "name": "Alice Johnson",
                "email": "alice@example.com",
                "phone": "(555) 111-2222",
                "location": "New York, NY",
                "linkedin": "https://linkedin.com/in/alicej",
            },
            "summary": "Senior software engineer specializing in distributed systems.",
            "skills": ["Python", "Go", "Kubernetes", "AWS", "PostgreSQL", "Redis"],
            "experience": [
                {
                    "title": "Senior Software Engineer",
                    "company": "BigTech Inc",
                    "start_date": "Mar 2019",
                    "end_date": "Present",
                    "descriptions": [
                        "Designed distributed caching layer serving 10M requests/day",
                        "Led migration from monolith to microservices",
                    ],
                }
            ],
            "education": [
                {
                    "degree": "BS Computer Science",
                    "institution": "MIT",
                    "graduation_date": "2017",
                    "gpa": "3.9",
                }
            ],
        }

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False, encoding="utf-8"
        ) as f:
            json.dump(resume_json, f)
            f.flush()
            path = Path(f.name)

        try:
            resume = self.parser.parse(path)
            assert resume.contact.name == "Alice Johnson"
            assert resume.contact.email == "alice@example.com"
            assert len(resume.skills) == 6
            assert len(resume.experience) == 1
            assert resume.experience[0].title == "Senior Software Engineer"
            assert len(resume.education) == 1
            assert resume.education[0].degree == "BS Computer Science"
            assert resume.summary != ""
        finally:
            path.unlink()

    def test_parse_json_with_basics_format(self) -> None:
        """Test JSON resume with 'basics' key (JSON Resume standard)."""
        resume_json = {
            "basics": {
                "name": "Bob Builder",
                "email": "bob@build.com",
                "phone": "(555) 333-4444",
                "summary": "Master builder with 20 years experience.",
            },
            "skills": ["Construction", "Management", "Safety"],
            "work": [
                {
                    "position": "Lead Builder",
                    "name": "BuildCo",
                    "startDate": "Jan 2015",
                    "endDate": "Present",
                    "highlights": ["Built 50+ structures", "Zero safety incidents"],
                }
            ],
        }

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False, encoding="utf-8"
        ) as f:
            json.dump(resume_json, f)
            f.flush()
            path = Path(f.name)

        try:
            resume = self.parser.parse(path)
            assert resume.contact.name == "Bob Builder"
            assert len(resume.experience) == 1
            assert resume.experience[0].title == "Lead Builder"
        finally:
            path.unlink()

    def test_parse_nonexistent_file(self) -> None:
        with pytest.raises(ValidationError):
            self.parser.parse("/nonexistent/path/resume.pdf")

    def test_parse_unsupported_format(self) -> None:
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as f:
            f.write(b"some text")
            path = Path(f.name)

        try:
            with pytest.raises(ValidationError):
                self.parser.parse(path)
        finally:
            path.unlink()


class TestJobParser:
    """Tests for JobParser."""

    def setup_method(self) -> None:
        self.parser = JobParser()

    def test_parse_text_basic(self) -> None:
        text = (
            "Senior Python Developer at TechCorp\n\n"
            "We are looking for a Senior Python Developer to join our team.\n\n"
            "Requirements:\n"
            "- 5+ years of Python experience\n"
            "- Experience with Django or Flask\n"
            "- Knowledge of PostgreSQL and Redis\n"
            "- Familiarity with Docker and Kubernetes\n\n"
            "Responsibilities:\n"
            "- Design and build REST APIs\n"
            "- Mentor junior developers\n"
            "- Participate in code reviews\n\n"
            "Benefits:\n"
            "- Competitive salary\n"
            "- Remote work\n"
            "- Health insurance"
        )
        job = self.parser.parse(text)
        assert isinstance(job, JobListing)
        assert len(job.requirements) > 0
        assert len(job.responsibilities) > 0
        assert len(job.benefits) > 0

    def test_parse_empty_text(self) -> None:
        with pytest.raises(ValidationError):
            self.parser.parse("")

    def test_url_detection(self) -> None:
        assert self.parser._is_url("https://example.com/jobs/123")
        assert self.parser._is_url("http://linkedin.com/jobs/view/456")
        assert not self.parser._is_url("Just some job text")

    def test_title_extraction(self) -> None:
        lines = ["Senior Software Engineer", "At TechCorp", "Remote"]
        title = self.parser._extract_title(lines)
        assert title != ""

    def test_location_extraction(self) -> None:
        text = "Location: San Francisco, CA\nThis is a remote-friendly position."
        location = self.parser._extract_location(text)
        assert "San Francisco" in location

    def test_section_extraction(self) -> None:
        text = (
            "Requirements:\n"
            "- Python proficiency\n"
            "- 3 years experience\n"
            "- AWS knowledge\n\n"
            "Other section starts here."
        )
        requirements = self.parser._extract_section(text, "requirements")
        assert len(requirements) >= 2
        assert any("Python" in r for r in requirements)


class TestJobParserURL:
    """Tests for JobParser URL handling."""

    def setup_method(self) -> None:
        self.parser = JobParser()

    def test_invalid_url(self) -> None:
        # This should fail because it can't connect
        from deepresume.exceptions import JobFetchError

        with pytest.raises((JobFetchError, Exception)):
            self.parser.parse("https://this-domain-does-not-exist-12345.com/jobs")
