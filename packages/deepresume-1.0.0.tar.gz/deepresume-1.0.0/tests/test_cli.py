"""Tests for the CLI interface."""

from click.testing import CliRunner

from deepresume.cli import cli


class TestCLIInfo:
    """Tests for the info command (no API key needed)."""

    def test_info_command(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["info"])
        assert result.exit_code == 0
        assert "DeepResume" in result.output or "Version" in result.output

    def test_version(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "1.0.0" in result.output

    def test_help(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "tailor" in result.output
        assert "analyze" in result.output
        assert "cover-letter" in result.output
        assert "interview" in result.output
        assert "check" in result.output

    def test_tailor_help(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["tailor", "--help"])
        assert result.exit_code == 0
        assert "RESUME" in result.output
        assert "JOB" in result.output

    def test_analyze_help(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["analyze", "--help"])
        assert result.exit_code == 0
        assert "--format" in result.output or "JOB" in result.output

    def test_cover_letter_help(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["cover-letter", "--help"])
        assert result.exit_code == 0
        assert "--tone" in result.output

    def test_interview_help(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["interview", "--help"])
        assert result.exit_code == 0

    def test_check_help(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["check", "--help"])
        assert result.exit_code == 0
        assert "RESUME" in result.output
