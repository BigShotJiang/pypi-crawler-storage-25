"""Tests for resume and cover letter generators."""

import tempfile
from pathlib import Path

import pytest

from deepresume.exceptions import OutputError
from deepresume.generators.cover_letter_generator import CoverLetterGenerator
from deepresume.generators.resume_generator import ResumeGenerator
from deepresume.models import (
    ContactInfo,
    EducationEntry,
    ExperienceEntry,
    MatchResult,
    OutputFormat,
    ResumeData,
    TailoredResume,
)


@pytest.fixture
def tailored_resume() -> TailoredResume:
    """Create a tailored resume for testing."""
    resume = ResumeData(
        contact=ContactInfo(
            name="Test Developer",
            email="test@example.com",
            phone="(555) 123-4567",
            location="San Francisco, CA",
            linkedin="https://linkedin.com/in/testdev",
            github="https://github.com/testdev",
        ),
        summary="Experienced Python developer.",
        skills=["Python", "Django", "PostgreSQL", "Docker", "AWS"],
        experience=[
            ExperienceEntry(
                title="Senior Developer",
                company="TechCorp",
                location="San Francisco, CA",
                start_date="Jan 2020",
                end_date="Present",
                descriptions=[
                    "Built REST APIs serving 1M daily requests",
                    "Led team of 5 engineers",
                    "Reduced costs by 40%",
                ],
            )
        ],
        education=[
            EducationEntry(
                degree="BS Computer Science",
                institution="MIT",
                graduation_date="2019",
                gpa="3.8",
            )
        ],
        certifications=["AWS Solutions Architect"],
    )
    job_data = {
        "title": "Senior Python Developer",
        "company": "Acme Inc",
    }
    match = MatchResult(
        overall_score=82.5,
        keyword_score=85.0,
        experience_score=80.0,
        education_score=90.0,
        skills_score=75.0,
    )
    return TailoredResume(
        original_resume=resume,
        job=job_data,  # type: ignore
        match=match,
        tailored_summary="Results-driven Python developer with 5+ years building scalable web applications.",
        tailored_skills=["Python", "Django", "PostgreSQL", "Docker", "AWS", "REST APIs", "Microservices"],
        tailored_experience=[
            {
                "title": "Senior Developer",
                "company": "TechCorp",
                "location": "San Francisco, CA",
                "start_date": "Jan 2020",
                "end_date": "Present",
                "descriptions": [
                    "Architected REST APIs handling 1M+ daily requests with 99.9% uptime",
                    "Led cross-functional team of 5 engineers in agile sprints",
                    "Optimized infrastructure costs by 40% through containerization",
                ],
            }
        ],
    )


class TestResumeGeneratorMarkdown:
    """Tests for Markdown resume generation."""

    def test_generate_markdown(self, tailored_resume: TailoredResume) -> None:
        gen = ResumeGenerator()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "resume.md"
            result = gen.generate(tailored_resume, path, OutputFormat.MARKDOWN)
            assert result.exists()
            content = path.read_text(encoding="utf-8")
            assert "Test Developer" in content
            assert "Professional Summary" in content
            assert "Skills" in content
            assert "Work Experience" in content
            assert "Education" in content

    def test_markdown_contains_contact_info(
        self, tailored_resume: TailoredResume
    ) -> None:
        gen = ResumeGenerator()
        text = gen.generate_markdown_text(tailored_resume)
        assert "test@example.com" in text
        assert "(555) 123-4567" in text
        assert "linkedin.com/in/testdev" in text

    def test_markdown_contains_tailored_content(
        self, tailored_resume: TailoredResume
    ) -> None:
        gen = ResumeGenerator()
        text = gen.generate_markdown_text(tailored_resume)
        assert "Results-driven Python developer" in text
        assert "Microservices" in text

    def test_markdown_certifications(self, tailored_resume: TailoredResume) -> None:
        gen = ResumeGenerator()
        text = gen.generate_markdown_text(tailored_resume)
        assert "Certifications" in text
        assert "AWS Solutions Architect" in text


class TestResumeGeneratorDOCX:
    """Tests for DOCX resume generation."""

    def test_generate_docx(self, tailored_resume: TailoredResume) -> None:
        gen = ResumeGenerator()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "resume.docx"
            result = gen.generate(tailored_resume, path, OutputFormat.DOCX)
            assert result.exists()
            assert result.stat().st_size > 0


class TestResumeGeneratorPDF:
    """Tests for PDF resume generation."""

    def test_generate_pdf(self, tailored_resume: TailoredResume) -> None:
        gen = ResumeGenerator()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "resume.pdf"
            result = gen.generate(tailored_resume, path, OutputFormat.PDF)
            assert result.exists()
            assert result.stat().st_size > 0

    def test_pdf_valid_header(self, tailored_resume: TailoredResume) -> None:
        gen = ResumeGenerator()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "resume.pdf"
            gen.generate(tailored_resume, path, OutputFormat.PDF)
            content = path.read_bytes()
            assert content.startswith(b"%PDF")


class TestCoverLetterGenerator:
    """Tests for cover letter generation."""

    def test_generate_markdown(self, tailored_resume: TailoredResume) -> None:
        gen = CoverLetterGenerator()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "cover_letter.md"
            result = gen.generate_markdown(
                tailored_resume,
                "Dear Hiring Manager,\n\nI am excited to apply...",
                path,
            )
            assert result.exists()
            content = path.read_text(encoding="utf-8")
            assert "Test Developer" in content
            assert "test@example.com" in content

    def test_generate_docx(self, tailored_resume: TailoredResume) -> None:
        gen = CoverLetterGenerator()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "cover_letter.docx"
            result = gen.generate_docx(
                tailored_resume,
                "Dear Hiring Manager,\n\nI am excited to apply for this role.",
                path,
            )
            assert result.exists()
            assert result.stat().st_size > 0

    def test_generate_pdf(self, tailored_resume: TailoredResume) -> None:
        gen = CoverLetterGenerator()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "cover_letter.pdf"
            result = gen.generate_pdf(
                tailored_resume,
                "Dear Hiring Manager,\n\nI am excited to apply for this role.",
                path,
            )
            assert result.exists()
            assert result.stat().st_size > 0
            content = path.read_bytes()
            assert content.startswith(b"%PDF")


class TestResumeGeneratorEmptyResume:
    """Tests for edge case: minimal resume data."""

    def test_generate_markdown_minimal(self) -> None:
        resume = ResumeData()
        job_data = {"title": "Job", "company": "Co"}
        match = MatchResult(overall_score=50.0)
        tailored = TailoredResume(
            original_resume=resume,
            job=job_data,  # type: ignore
            match=match,
        )

        gen = ResumeGenerator()
        text = gen.generate_markdown_text(tailored)
        assert "Your Name" in text  # Default name fallback
