"""Core DMP protocol implementation"""
