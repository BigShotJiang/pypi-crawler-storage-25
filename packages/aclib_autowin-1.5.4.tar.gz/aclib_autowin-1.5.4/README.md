# Installation

### General
    pip install aclib.autowin
### Work with dm
    pip install aclib.autowin[dm]
### Work with cv
    pip install aclib.autowin[cv]
### Add Windows.Graphics.Capture support for cv
    pip install zbl
### Full installation
    pip install aclib.autowin[full]


# Usage

```python
# base typing
from aclib.autowin import _Pos, _Size, _Area, _Areas
# base api
from aclib.autowin import BaseWindow, screen, Window

# create win32 application
from aclib.autowin.appwindow import AppWindow
# css typing
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from aclib.autowin.appwindow._typing import _AppCSS

# use opencv
from aclib.autowin.cvwindow import CvWindow     # [cv] requires

# use dm plugin
from aclib.autowin.dmwindow import DmWindow     # [dm] requires

```


# Examples

```python
from aclib.autowin.cvwindow import CvWindow

# Get window
win = CvWindow.findwindow('游戏窗口标题')
if not win:
    raise Exception('not found window')

# Enable Windows.Graphics.Capture(WGC).
# If the target window doesn't support GDI capture, use WGC.
# Run "pip install zbl" with a 64-bit python first.
win.cv_start_wgc()
# Release WGC
win.cv_stop_wgc()

# Show capture to test if cvwindow works or not
cap = win.cvcapture()
cap.show(usebrowser=True)

# Find color
area = (0, 0, 1920, 1080)
target = win.cvfindcolor('ffffff|000000--222222|888888-101010', area)
targets = win.cvfindcolors('ffffff|000000--222222|888888-101010', area)
print(target)

# Set dotsetlib
dlib = CvWindow.DotsetLib.fromfile(r"点阵库路径")
win.cvset(dlib=dlib)
# Find dotset
area = (0, 0, 1920, 1080)
target = win.cvfinddotset('点阵名称', area)
targets = win.cvfinddotsets('点阵名称', area)
print(target)

# Set fontlib
flib = CvWindow.FontLib.fromfile(r"字库路径")
win.cvset(flib=flib)
# Find text
area = (0, 0, 1920, 1080)
target = win.cvfindtext('文本', area)
targets = win.cvfindtexts('文本', area)
line_targets = win.cvocr(area)
print(target)

# use target
print(target.name)
print(target.start)
print(target.center)
print(target.end)
print(target.similarity)
target.click_if_exists()
if not target:
    print('not found target')
```