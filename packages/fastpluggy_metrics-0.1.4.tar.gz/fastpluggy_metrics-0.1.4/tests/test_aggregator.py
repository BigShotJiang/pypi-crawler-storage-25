from unittest.mock import MagicMock

from fastpluggy.core.metrics import MetricEntry, MetricsProvider, MetricsResult

from fastpluggy_plugin.metrics.aggregator import MetricsAggregator


class FakeProvider:
    """A fake MetricsProvider for testing."""

    def __init__(self, result: MetricsResult | None = None):
        self._result = result or MetricsResult()

    def get_metrics(self) -> MetricsResult:
        return self._result


class BrokenProvider:
    """A provider that raises on get_metrics()."""

    def get_metrics(self) -> MetricsResult:
        raise RuntimeError("boom")


def _gauge(name: str, value: float, **labels) -> MetricEntry:
    return MetricEntry(name=name, value=value, type="gauge", labels=labels)


def _counter(name: str, value: float, help_text: str = "") -> MetricEntry:
    return MetricEntry(name=name, value=value, type="counter", help=help_text)


class TestMetricsAggregator:
    def test_no_providers(self):
        agg = MetricsAggregator(providers={})
        assert agg.collect_all() == {}

    def test_single_provider(self):
        provider = FakeProvider(MetricsResult(gauges=[_gauge("cpu", 42.0)]))
        agg = MetricsAggregator(providers={"my_plugin": provider})
        result = agg.collect_all()
        assert "my_plugin" in result
        assert len(result["my_plugin"].gauges) == 1
        assert result["my_plugin"].gauges[0].name == "cpu"

    def test_multiple_providers(self):
        p1 = FakeProvider(MetricsResult(gauges=[_gauge("a", 1)]))
        p2 = FakeProvider(MetricsResult(counters=[_counter("b", 2)]))
        agg = MetricsAggregator(providers={"p1": p1, "p2": p2})
        result = agg.collect_all()
        assert len(result) == 2
        assert result["p1"].gauges[0].name == "a"
        assert result["p2"].counters[0].name == "b"

    def test_broken_provider_skipped(self):
        good = FakeProvider(MetricsResult(gauges=[_gauge("ok", 1)]))
        bad = BrokenProvider()
        agg = MetricsAggregator(providers={"good": good, "bad": bad})
        result = agg.collect_all()
        assert "good" in result
        assert "bad" not in result

    def test_protocol_check(self):
        assert isinstance(FakeProvider(), MetricsProvider)
        assert not isinstance(object(), MetricsProvider)


class TestCollectAllJson:
    def test_structure(self):
        provider = FakeProvider(MetricsResult(
            gauges=[_gauge("cpu", 42.5, host="web1")],
            counters=[_counter("reqs", 100, help_text="Total requests")],
        ))
        agg = MetricsAggregator(providers={"demo": provider})
        data = agg.collect_all_json()

        assert "timestamp" in data
        assert data["sources"] == 1
        assert "demo" in data["plugins"]

        demo = data["plugins"]["demo"]
        assert len(demo["gauges"]) == 1
        assert demo["gauges"][0]["name"] == "cpu"
        assert demo["gauges"][0]["labels"] == {"host": "web1"}
        assert len(demo["counters"]) == 1
        assert demo["counters"][0]["help"] == "Total requests"
        assert demo["histograms"] == []

    def test_empty(self):
        agg = MetricsAggregator(providers={})
        data = agg.collect_all_json()
        assert data["sources"] == 0
        assert data["plugins"] == {}


class TestCollectPrometheusText:
    def test_basic_output(self):
        provider = FakeProvider(MetricsResult(
            gauges=[_gauge("queue_depth", 5, topic="emails")],
        ))
        agg = MetricsAggregator(providers={"worker": provider})
        text = agg.collect_prometheus_text()

        assert '# TYPE fp_worker_queue_depth gauge' in text
        assert 'fp_worker_queue_depth{topic="emails"} 5' in text

    def test_help_line(self):
        provider = FakeProvider(MetricsResult(
            counters=[_counter("total", 99, help_text="Total processed")],
        ))
        agg = MetricsAggregator(providers={"app": provider})
        text = agg.collect_prometheus_text()

        assert "# HELP fp_app_total Total processed" in text
        assert "# TYPE fp_app_total counter" in text
        assert "fp_app_total 99" in text

    def test_no_labels(self):
        provider = FakeProvider(MetricsResult(gauges=[_gauge("up", 1)]))
        agg = MetricsAggregator(providers={"svc": provider})
        text = agg.collect_prometheus_text()
        assert "fp_svc_up 1" in text
        # No curly braces when no labels
        assert "fp_svc_up{" not in text

    def test_empty_returns_empty(self):
        agg = MetricsAggregator(providers={})
        assert agg.collect_prometheus_text() == ""


class TestCoreMetricsDiscovery:
    """Test that core metrics provider is discovered via GlobalRegistry."""

    def test_core_provider_included_in_aggregator(self):
        """Simulate what on_load_complete does: discover core_metrics_provider."""
        from fastpluggy.core.global_registry import GlobalRegistry
        from fastpluggy.core.core_metrics import CoreMetricsProvider

        # Set up a mock FastPluggy
        fp = MagicMock()
        fp.module_manager.modules = {}
        fp.module_manager._plugin_load_times = {}
        fp._load_time_ms = 100.0
        fp.events.events_dispatched = 5
        fp.events.listener_count.return_value = 3

        core_provider = CoreMetricsProvider(fp)
        GlobalRegistry.register_global("core_metrics_provider", core_provider)

        try:
            # Replicate the discovery logic from MetricsPlugin.on_load_complete
            providers: dict[str, MetricsProvider] = {}
            retrieved = GlobalRegistry.get_global("core_metrics_provider")
            if retrieved and isinstance(retrieved, MetricsProvider):
                providers["core"] = retrieved

            agg = MetricsAggregator(providers=providers)

            # Verify core metrics appear in Prometheus output
            text = agg.collect_prometheus_text()
            assert "fp_core_plugins_loaded" in text
            assert "fp_core_load_time_ms" in text
            assert "fp_core_events_dispatched_total" in text
            assert "fp_core_event_listeners_count" in text

            # Verify JSON output
            data = agg.collect_all_json()
            assert "core" in data["plugins"]
            assert data["sources"] == 1
        finally:
            GlobalRegistry.clear_globals_key("core_metrics_provider")
