from typing import List

from fastpluggy.core.config import BaseDatabaseSettings


class MetricsSettings(BaseDatabaseSettings):
    enable_metrics: bool = True
    metrics_collect_interval: int = 0  # seconds; 0 = on-demand (no caching)
    cardinality_threshold: int = 30  # warn when a metric has more unique label combos than this
    disabled_providers: List[str] = []  # provider keys to skip (e.g. ["core", "tasks_worker"])
