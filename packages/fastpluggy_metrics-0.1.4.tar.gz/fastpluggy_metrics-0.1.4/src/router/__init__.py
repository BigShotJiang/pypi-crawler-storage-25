import time

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse

from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.global_registry import GlobalRegistry
from fastpluggy.core.widgets.categories.display.custom import CustomTemplateWidget

metrics_router = APIRouter()


@metrics_router.get("/", response_class=HTMLResponse, name="metrics_dashboard")
def metrics_dashboard(request: Request, view_builder=Depends(get_view_builder)):
    """Dashboard page — summary cards + per-plugin metrics tables."""
    aggregator = GlobalRegistry.get_global("metrics_aggregator")
    if aggregator is None:
        plugins_data = {}
        total = 0
        disabled = set()
        warnings = []
    else:
        data = aggregator.collect_all_json()
        plugins_data = data.get("plugins", {})
        warnings = data.get("warnings", [])
        total = sum(
            len(p.get("gauges", [])) + len(p.get("counters", [])) + len(p.get("histograms", []))
            for p in plugins_data.values()
        )
        disabled = aggregator.disabled

    return view_builder.generate(
        request,
        title="Metrics Dashboard",
        widgets=[
            CustomTemplateWidget(
                template_name="metrics/dashboard.html.j2",
                context={
                    "sources": len(plugins_data),
                    "total_metrics": total,
                    "last_collected": time.strftime("%H:%M:%S"),
                    "plugins": plugins_data,
                    "warnings": warnings,
                    "disabled_providers": sorted(disabled),
                },
            ),
        ],
    )


@metrics_router.get("/api/all", response_class=JSONResponse, name="metrics_all")
def metrics_all():
    """JSON endpoint — aggregated metrics from all providers."""
    aggregator = GlobalRegistry.get_global("metrics_aggregator")
    if aggregator is None:
        return JSONResponse({"error": "Metrics aggregator not initialized"}, status_code=503)
    return JSONResponse(aggregator.collect_all_json())


@metrics_router.get("/api/prometheus", response_class=PlainTextResponse, name="metrics_prometheus")
def metrics_prometheus():
    """Prometheus text exposition endpoint — aggregated from all providers."""
    aggregator = GlobalRegistry.get_global("metrics_aggregator")
    if aggregator is None:
        return PlainTextResponse("# Metrics aggregator not initialized\n", status_code=503)
    return PlainTextResponse(
        aggregator.collect_prometheus_text(),
        media_type="text/plain; version=0.0.4; charset=utf-8",
    )
