import logging
import time
from dataclasses import dataclass, field

from fastpluggy.core.metrics import MetricsProvider, MetricsResult

logger = logging.getLogger(__name__)


@dataclass
class MetricsAggregator:
    """Collects metrics from all registered MetricsProvider plugins."""

    providers: dict[str, MetricsProvider] = field(default_factory=dict)
    cardinality_threshold: int = 30  # default fallback; overridden by MetricsSettings at init
    disabled: set[str] = field(default_factory=set)

    def collect_all(self) -> dict[str, MetricsResult]:
        """Call get_metrics() on each provider, return results keyed by plugin name."""
        results: dict[str, MetricsResult] = {}
        for name, provider in self.providers.items():
            try:
                results[name] = provider.get_metrics()
            except Exception:
                logger.exception("Failed to collect metrics from %s", name)
        return results

    def check_cardinality(self, collected: dict[str, MetricsResult]) -> list[dict]:
        """Check for high-cardinality label usage across all plugins.

        Returns a list of warning dicts for any metric with more than
        self.cardinality_threshold unique label value combinations.
        """
        warnings: list[dict] = []
        for plugin_name, result in collected.items():
            # Group entries by metric name, count unique label combos
            label_sets: dict[str, set[tuple]] = {}
            for entry in result.all_entries:
                if entry.labels:
                    key = entry.name
                    combo = tuple(sorted(entry.labels.items()))
                    label_sets.setdefault(key, set()).add(combo)

            for metric_name, combos in label_sets.items():
                if len(combos) > self.cardinality_threshold:
                    warnings.append({
                        "plugin": plugin_name,
                        "metric": metric_name,
                        "label_count": len(combos),
                        "threshold": self.cardinality_threshold,
                        "message": (
                            f"{plugin_name}: {metric_name} has {len(combos)} label values "
                            f"(threshold: {self.cardinality_threshold}) — consider reducing cardinality"
                        ),
                    })
        return warnings

    def collect_all_json(self) -> dict:
        """Collect all metrics and return a JSON-serializable dict."""
        collected = self.collect_all()
        warnings = self.check_cardinality(collected)
        out: dict = {
            "timestamp": time.time(),
            "sources": len(collected),
            "plugins": {},
            "warnings": warnings,
        }
        for plugin_name, result in collected.items():
            out["plugins"][plugin_name] = {
                "gauges": [_entry_to_dict(e) for e in result.gauges],
                "counters": [_entry_to_dict(e) for e in result.counters],
                "histograms": [_entry_to_dict(e) for e in result.histograms],
            }
        return out

    def collect_prometheus_text(self) -> str:
        """Collect all metrics and format as Prometheus text exposition."""
        collected = self.collect_all()
        lines: list[str] = []
        for plugin_name, result in collected.items():
            for entry in result.all_entries:
                metric_name = f"fp_{plugin_name}_{entry.name}"
                if entry.help:
                    lines.append(f"# HELP {metric_name} {entry.help}")
                lines.append(f"# TYPE {metric_name} {entry.type}")
                label_str = _format_labels(entry.labels)
                lines.append(f"{metric_name}{label_str} {entry.value}")
        return "\n".join(lines) + "\n" if lines else ""


def _entry_to_dict(entry) -> dict:
    return {
        "name": entry.name,
        "value": entry.value,
        "type": entry.type,
        "help": entry.help,
        "labels": entry.labels,
    }


def _format_labels(labels: dict[str, str]) -> str:
    if not labels:
        return ""
    parts = [f'{k}="{v}"' for k, v in sorted(labels.items())]
    return "{" + ",".join(parts) + "}"
