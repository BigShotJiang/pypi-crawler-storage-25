from typing import Annotated, Any

from fastpluggy.core.module_base import FastPluggyBaseModule
from fastpluggy.core.tools.inspect_tools import InjectDependency
from .config import MetricsSettings


def get_metrics_router():
    from .router import metrics_router
    return metrics_router


class MetricsPlugin(FastPluggyBaseModule):
    """Central metrics aggregator — discovers plugins with the 'metrics' capability
    and exposes aggregated data via JSON and Prometheus endpoints."""

    module_name: str = "metrics"

    module_menu_name: str = "Metrics"
    module_menu_icon: str = "fa fa-chart-line"
    module_menu_type: str = "main"

    module_settings: Any = MetricsSettings
    module_router: Any = get_metrics_router

    def on_load_complete(self, fast_pluggy: Annotated["FastPluggy", InjectDependency]):
        settings = MetricsSettings()

        # Instrument the application with prometheus-fastapi-instrumentator
        if settings.enable_metrics:
            from prometheus_fastapi_instrumentator import Instrumentator
            instrumentator = Instrumentator().instrument(fast_pluggy.app)
            instrumentator.expose(fast_pluggy.app, include_in_schema=False, should_gzip=True)

        # Discover all plugins that declare the "metrics" capability
        from fastpluggy.core.metrics import MetricsProvider
        from .aggregator import MetricsAggregator

        disabled = set(settings.disabled_providers)

        providers: dict[str, MetricsProvider] = {}
        for mod_name, mod_state in fast_pluggy.module_manager.modules.items():
            if mod_name in disabled:
                continue
            plugin = mod_state.plugin
            if "metrics" in getattr(plugin, "capabilities", []) and isinstance(plugin, MetricsProvider):
                providers[mod_name] = plugin

        # Check for core metrics provider registered in GlobalRegistry
        if "core" not in disabled:
            from fastpluggy.core.global_registry import GlobalRegistry
            core_provider = GlobalRegistry.get_global("core_metrics_provider")
            if core_provider and isinstance(core_provider, MetricsProvider):
                providers["core"] = core_provider

        self._aggregator = MetricsAggregator(
            providers=providers,
            cardinality_threshold=settings.cardinality_threshold,
            disabled=disabled,
        )
        GlobalRegistry.register_global("metrics_aggregator", self._aggregator)

        # Register capability so it appears on the admin capabilities page
        GlobalRegistry.register_capability(
            "metrics_aggregator", self, description="Central metrics aggregator"
        )
