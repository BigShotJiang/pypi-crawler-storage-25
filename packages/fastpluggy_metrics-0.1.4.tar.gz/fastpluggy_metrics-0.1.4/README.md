# fastpluggy-metrics

![Metrics](https://img.shields.io/badge/FastPluggy-Metrics-blue)
[![Release](https://gitlab.ggcorp.fr/open/fastpluggy/plugins/metrics/-/badges/release.svg)](https://gitlab.ggcorp.fr/open/fastpluggy/plugins/metrics/-/releases)
[![Pipeline Status](https://gitlab.ggcorp.fr/open/fastpluggy/plugins/metrics/badges/main/pipeline.svg?key_text=CI)](https://gitlab.ggcorp.fr/open/fastpluggy/plugins/metrics/-/pipelines?ignore_skipped=true)
[![Coverage](https://gitlab.ggcorp.fr/open/fastpluggy/plugins/metrics/badges/main/coverage.svg)](https://gitlab.ggcorp.fr/open/fastpluggy/plugins/metrics/-/pipelines)

Prometheus metrics plugin for FastPluggy. Collects and exposes metrics from all plugins that implement the MetricsProvider capability.

## Installation

```bash
pip install fastpluggy-metrics
```

## Dependencies

- psutil
- prometheus-client
- prometheus-fastapi-instrumentator

## Features

- Prometheus `/metrics` endpoint
- Auto-discovers plugins with `MetricsProvider` capability
- System metrics (CPU, memory, disk) via psutil
- FastAPI request instrumentation
- Cardinality monitoring and warnings
- Dashboard with per-provider metric viewer

## Documentation

See [docs/README.md](docs/README.md) for detailed documentation.
