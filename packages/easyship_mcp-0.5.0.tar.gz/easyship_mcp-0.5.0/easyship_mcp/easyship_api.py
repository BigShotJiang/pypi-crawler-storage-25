"""HTTP client and shared helpers for the Easyship public API.

This module owns everything that talks to ``public-api.easyship.com``:

* base URL / API version constants
* bearer token extraction and ``httpx.AsyncClient`` construction
* uniform error parsing
* identity / KYC verification detection and support-link enrichment
* :func:`easyship_request`, a thin wrapper that centralizes the
  try/except, status-code, and JSON-decoding boilerplate that every
  Easyship MCP tool would otherwise repeat.
"""

from __future__ import annotations

import os
from typing import Any

import httpx

BASE_URL = "https://public-api.easyship.com"
API_VERSION = "2024-09"

SUPPORT_EMAIL = "support@easyship.com"
SUPPORT_EMAIL_MAILTO = f"mailto:{SUPPORT_EMAIL}"

# Known Easyship API error codes that signal identity/KYC verification is
# blocking labels. Add codes here as they are confirmed from production API
# responses.
IDENTITY_VERIFICATION_ERROR_CODES: frozenset[str] = frozenset({
    "identity_verification_required",
    "kyc_required",
    "account_verification_required",
    "verification_pending",
    "verification_in_progress",
})


def get_token_from_headers(headers: dict[str, str]) -> str | None:
    """Extract the Bearer token from inbound HTTP headers, if present."""
    auth = headers.get("authorization", "")
    if auth.startswith("Bearer "):
        return auth[7:]
    return None


def get_client(token: str | None = None) -> httpx.AsyncClient:
    """Build an ``httpx.AsyncClient`` pre-configured for the Easyship API.

    Falls back to the ``EASYSHIP_API_ACCESS_TOKEN`` environment variable when
    no token is supplied (e.g. stdio transport without an Authorization
    header). Raises ``ValueError`` if neither is available.
    """
    api_key = token or os.environ.get("EASYSHIP_API_ACCESS_TOKEN", "")
    if not api_key:
        raise ValueError(
            "EASYSHIP_API_ACCESS_TOKEN environment variable is not set. "
            "Get your API key from https://app.easyship.com/connect/api"
        )
    return httpx.AsyncClient(
        base_url=BASE_URL,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        timeout=30.0,
    )


def parse_error(response: httpx.Response) -> dict[str, Any]:
    """Build a structured error dict from a non-success Easyship response."""
    try:
        body = response.json()
        err = body.get("error", {})
        return {
            "error": True,
            "status_code": response.status_code,
            "type": err.get("type", "unknown_error"),
            "code": err.get("code", "unknown"),
            "message": err.get("message", response.text),
            "details": err.get("details", []),
        }
    except Exception:
        return {
            "error": True,
            "status_code": response.status_code,
            "message": response.text or f"HTTP {response.status_code}",
        }


def _text_indicates_identity_verification_issue(text: str) -> bool:
    """True when free-text from the API suggests identity verification blocks labels."""
    if not text:
        return False
    t = text.lower()
    if "kyc" in t:
        return True
    if "identity" in t and "verification" in t:
        return True
    if "verification" in t and ("in process" in t or "in progress" in t):
        return True
    return False


def enrich_identity_verification_support(result: dict[str, Any]) -> dict[str, Any]:
    """Add support contact fields when identity verification may block label purchase.

    Adds ``support_email``, ``support_email_link``, and ``support_reply_hint``
    with factual verification-support text for clients to surface to users.

    On errors: checks the structured ``error.code`` first (precise), then falls
    back to scanning ``message`` and ``details`` text.

    On success (200/201): only scans ``meta.errors`` and ``meta.status`` — the
    fields the Easyship API uses for server-side warnings — to avoid
    false-positives from parcel descriptions or address content.
    """
    matched = False

    if result.get("error"):
        if result.get("code") in IDENTITY_VERIFICATION_ERROR_CODES:
            matched = True
        else:
            parts = [str(result.get("message", ""))]
            det = result.get("details")
            if isinstance(det, list):
                parts.extend(str(x) for x in det)
            elif det is not None:
                parts.append(str(det))
            matched = _text_indicates_identity_verification_issue(" ".join(parts))
    else:
        meta = result.get("meta") if isinstance(result, dict) else None
        if isinstance(meta, dict):
            candidates: list[str] = []
            status = meta.get("status")
            if isinstance(status, str):
                candidates.append(status)
            for entry in meta.get("errors") or []:
                if isinstance(entry, str):
                    candidates.append(entry)
            matched = any(_text_indicates_identity_verification_issue(c) for c in candidates)

    if not matched:
        return result

    enriched = dict(result)
    enriched["support_email"] = SUPPORT_EMAIL
    enriched["support_email_link"] = SUPPORT_EMAIL_MAILTO
    enriched["support_reply_hint"] = (
        "Easyship account or identity verification may be required before labels can be purchased. "
        f"Support contact: {SUPPORT_EMAIL} ({SUPPORT_EMAIL_MAILTO})."
    )
    return enriched


def _maybe_enrich(result: dict[str, Any], enrich: bool) -> dict[str, Any]:
    return enrich_identity_verification_support(result) if enrich else result


async def easyship_request(
    method: str,
    path: str,
    *,
    headers: dict[str, str],
    params: dict[str, Any] | None = None,
    json: Any = None,
    success_codes: tuple[int, ...] = (200,),
    enrich_identity_verification: bool = False,
) -> dict[str, Any]:
    """Perform an authenticated request against the Easyship API.

    Centralizes the boilerplate every tool would otherwise repeat:

    * extract the bearer token from MCP headers,
    * build an ``httpx.AsyncClient`` and issue the request,
    * translate ``ValueError`` (missing token) and ``httpx.HTTPError`` into
      structured error dicts,
    * validate the HTTP status against ``success_codes`` and call
      :func:`parse_error` otherwise,
    * decode the JSON body (returning ``{"success": True}`` for ``204``),
    * optionally pass the result through
      :func:`enrich_identity_verification_support`.

    Args:
        method: HTTP method (e.g. ``"GET"``, ``"POST"``, ``"PATCH"``, ``"DELETE"``).
        path: Path beginning with ``/`` (e.g. ``f"/{API_VERSION}/shipments"``).
        headers: Inbound MCP request headers used to extract the bearer token.
        params: Optional query string parameters.
        json: Optional JSON request body.
        success_codes: HTTP status codes considered successful for this call.
        enrich_identity_verification: When ``True``, run the result through
            :func:`enrich_identity_verification_support` so label-related
            tools surface Easyship support contact info on KYC blocks.

    Returns:
        Either the parsed JSON dict (or ``{"success": True}`` for ``204``) on
        success, or a structured error dict shaped like::

            {
              "error": True,
              "status_code": int,
              "type": str,
              "code": str,
              "message": str,
              "details": list,
            }
    """
    try:
        token = get_token_from_headers(headers)
        async with get_client(token) as client:
            resp = await client.request(method, path, params=params, json=json)
    except ValueError as e:
        return _maybe_enrich({"error": True, "message": str(e)}, enrich_identity_verification)
    except httpx.HTTPError as e:
        return _maybe_enrich(
            {"error": True, "message": f"HTTP request failed: {e}"},
            enrich_identity_verification,
        )

    if resp.status_code not in success_codes:
        return _maybe_enrich(parse_error(resp), enrich_identity_verification)

    if resp.status_code == 204:
        return {"success": True}

    try:
        data = resp.json()
    except Exception:
        return _maybe_enrich(
            {
                "error": True,
                "status_code": resp.status_code,
                "message": "Invalid JSON response",
            },
            enrich_identity_verification,
        )

    if not isinstance(data, dict):
        return {"data": data}

    return _maybe_enrich(data, enrich_identity_verification)


async def easyship_request_raw(
    method: str,
    path: str,
    *,
    headers: dict[str, str],
    params: dict[str, Any] | None = None,
    json: Any = None,
    success_codes: tuple[int, ...] = (200,),
) -> tuple[dict[str, Any] | None, httpx.Response | None]:
    """Like :func:`easyship_request` but returns the raw response on success.

    Use this when the endpoint returns binary content (e.g. a PDF) or the
    caller needs response headers.

    Returns:
        ``(None, response)`` on success, or ``(error_dict, None)`` on failure.
    """
    try:
        token = get_token_from_headers(headers)
        async with get_client(token) as client:
            resp = await client.request(method, path, params=params, json=json)
            if resp.status_code not in success_codes:
                return parse_error(resp), None
            # Read the body before the client is closed by ``async with``.
            _ = resp.content
            return None, resp
    except ValueError as e:
        return {"error": True, "message": str(e)}, None
    except httpx.HTTPError as e:
        return {"error": True, "message": f"HTTP request failed: {e}"}, None
