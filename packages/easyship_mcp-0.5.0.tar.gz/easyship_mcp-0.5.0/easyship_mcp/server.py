"""Easyship MCP Server — shipping rates and tracking via the Easyship API."""

from __future__ import annotations

import os
from typing import Any

from fastmcp import FastMCP
from fastmcp.server.dependencies import CurrentHeaders

from .easyship_api import (
    API_VERSION,
    easyship_request,
    easyship_request_raw,
)
from .oauth import register_oauth_routes

# ── Tool annotation presets ─────────────────────────────────────────────────
# Keep call sites one line and consistent across the file. These mirror the
# MCP "tool annotations" object — see the MCP spec for the full set.
# openWorldHint: false — bounded Easyship API only (ChatGPT Apps SDK).
READ_ONLY: dict[str, Any] = {"readOnlyHint": True, "openWorldHint": False}
DESTRUCTIVE: dict[str, Any] = {
    "destructiveHint": True,
    "openWorldHint": False,
}


def _tool_title(friendly: str, fn_name: str) -> str:
    """Human-facing MCP tool title with machine name (connector review expectation)."""

    return f"{friendly} ({fn_name})"

MCP_INSTRUCTIONS = """\
Easyship MCP server - Tools for shipping rates, shipments, labels, tracking, pickups, address validations, billing, and analytics across 550+ couriers in 200+ countries.

API responses may include `shipping_documents` with authenticated download URLs; pass those through so users can open or save files. Some errors or meta warnings include `support_email`, `support_email_link`, and `support_reply_hint` when account verification affects labels—use those fields as factual support guidance for the user.
"""

mcp = FastMCP(
    "Easyship",
    instructions=MCP_INSTRUCTIONS,
)

# OAuth metadata endpoints (RFC 9728 + RFC 8414) live in oauth.py.
register_oauth_routes(mcp)


# ── get_rates ───────────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("Get Rates", "get_rates"), annotations=READ_ONLY)
async def get_rates(
    origin_country_alpha2: str,
    destination_country_alpha2: str,
    total_actual_weight: float,
    length: float,
    width: float,
    height: float,
    headers: dict[str, str] = CurrentHeaders(),
    item_description: str = "General goods",
    item_quantity: int = 1,
    item_declared_customs_value: float = 10.0,
    item_declared_currency: str = "USD",
    item_category: str | None = None,
    item_hs_code: str | None = None,
    origin_line_1: str | None = None,
    origin_city: str | None = None,
    origin_state: str | None = None,
    origin_postal_code: str | None = None,
    destination_city: str | None = None,
    destination_state: str | None = None,
    destination_postal_code: str | None = None,
    destination_line_1: str | None = None,
    output_currency: str | None = None,
    incoterms: str | None = None,
) -> list[dict[str, Any]] | dict[str, Any]:
    """Get available shipping rates (courier options with prices and delivery times) for a parcel.

    Compares couriers to find the cheapest, fastest, or best-value option for
    shipping a package between two countries.

    **Before calling:** You must have at minimum the origin country, destination country, and weight.
    If any of these are missing, ask the user first.

    **If you use assumed or estimated data** (e.g. generic postal codes, standard dimensions), you MUST
    tell the user: "These are estimated rates based on standard package dimensions. Exact rates may
    change with a full address and precise box measurements."

    Each item should include either `item_category` or `item_hs_code` for accurate customs and duty estimates.

    Args:
        origin_country_alpha2: ISO 3166-1 alpha-2 origin country code, e.g. "US", "HK", "GB".
        destination_country_alpha2: ISO 3166-1 alpha-2 destination country code, e.g. "SG", "DE", "JP".
        total_actual_weight: Total weight of the parcel in kg, including packaging. Example: 1.5
        length: Box length in cm. Example: 30
        width: Box width in cm. Example: 20
        height: Box height in cm. Example: 15
        item_description: Short description of what is being shipped. Example: "Cotton T-Shirts"
        item_quantity: Number of items in the parcel. Default 1.
        item_declared_customs_value: Declared customs value per item in the currency specified. Must be > 0 unless category is "documents". Example: 25.0
        item_declared_currency: ISO-4217 currency code for customs value. Example: "USD", "EUR", "GBP".
        item_category: Item category slug. Provide this or `item_hs_code` for accurate duty estimates. Valid values: "mobile_phones", "tablets", "computers_laptops", "cameras", "accessory_no_battery", "accessory_with_battery", "health_beauty", "fashion", "watches", "home_appliances", "home_decor", "toys", "sport_leisure", "bags_luggages", "audio_video", "documents", "jewelry", "dry_food_supplements", "books_collectibles", "pet_accessory".
        item_hs_code: Harmonized System code for the item. Provide this or `item_category` for accurate duty estimates.
        origin_line_1: Origin street address line 1. Use "General Delivery" if unknown.
        origin_city: Origin city. Recommended for US, CA, MX, AU for accurate rates.
        origin_state: Origin state/province. Use 2-letter abbreviation for US/CA.
        origin_postal_code: Origin postal code. Required for most countries.
        destination_city: Destination city. Recommended for US, CA, MX, AU.
        destination_state: Destination state/province. Use 2-letter abbreviation for US/CA.
        destination_postal_code: Destination postal code. Required for most countries.
        destination_line_1: Destination street address line 1. Some couriers need this for accurate rates.
        output_currency: ISO-4217 currency for returned prices (e.g. "USD"). Defaults to origin country currency.
        incoterms: "DDU" (buyer pays duties on delivery) or "DDP" (seller pre-pays duties). Optional.

    Returns:
        A list of rate options, each with courier name, price breakdown, and delivery estimate.
    """
    origin_address: dict[str, Any] = {"country_alpha2": origin_country_alpha2}
    if origin_line_1:
        origin_address["line_1"] = origin_line_1
    if origin_city:
        origin_address["city"] = origin_city
    if origin_state:
        origin_address["state"] = origin_state
    if origin_postal_code:
        origin_address["postal_code"] = origin_postal_code

    destination_address: dict[str, Any] = {"country_alpha2": destination_country_alpha2}
    if destination_line_1:
        destination_address["line_1"] = destination_line_1
    if destination_city:
        destination_address["city"] = destination_city
    if destination_state:
        destination_address["state"] = destination_state
    if destination_postal_code:
        destination_address["postal_code"] = destination_postal_code

    item: dict[str, Any] = {
        "description": item_description,
        "quantity": item_quantity,
        "declared_customs_value": item_declared_customs_value,
        "declared_currency": item_declared_currency,
    }
    if item_category:
        item["category"] = item_category
    if item_hs_code:
        item["hs_code"] = item_hs_code

    payload: dict[str, Any] = {
        "origin_address": origin_address,
        "destination_address": destination_address,
        "parcels": [
            {
                "total_actual_weight": total_actual_weight,
                "box": {"length": length, "width": width, "height": height},
                "items": [item],
            }
        ],
    }

    if output_currency:
        payload["shipping_settings"] = {"output_currency": output_currency}
    if incoterms:
        payload["incoterms"] = incoterms

    data = await easyship_request(
        "POST",
        f"/{API_VERSION}/rates",
        headers=headers,
        json=payload,
    )
    if data.get("error"):
        return data

    rates = data.get("rates", [])

    # Flatten to only the fields an AI agent would care about
    return [
        {
            "courier_name": r.get("courier_service", {}).get("name"),
            "courier_id": r.get("courier_service", {}).get("id"),
            "min_delivery_days": r.get("min_delivery_time"),
            "max_delivery_days": r.get("max_delivery_time"),
            "total_charge": r.get("total_charge"),
            "shipment_charge": r.get("shipment_charge"),
            "fuel_surcharge": r.get("fuel_surcharge"),
            "insurance_fee": r.get("insurance_fee"),
            "remote_area_surcharge": r.get("remote_area_surcharge"),
            "currency": r.get("currency"),
            "incoterms": r.get("incoterms"),
            "estimated_import_tax": r.get("estimated_import_tax"),
            "estimated_import_duty": r.get("estimated_import_duty"),
            "description": r.get("full_description"),
            "cost_rank": r.get("cost_rank"),
            "delivery_time_rank": r.get("delivery_time_rank"),
            "value_for_money_rank": r.get("value_for_money_rank"),
            "easyship_rating": r.get("easyship_rating"),
            "discount_amount": (r.get("discount") or {}).get("amount"),
            "payment_recipient": r.get("payment_recipient"),
        }
        for r in rates
    ]


# ── track_shipment ──────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("Track Shipment", "track_shipment"), annotations=READ_ONLY)
async def track_shipment(
    easyship_shipment_id: str | None = None,
    platform_order_number: str | None = None,
    headers: dict[str, str] = CurrentHeaders(),
) -> dict[str, Any] | list[dict[str, Any]]:
    """Track a shipment and get its current status plus checkpoint history.

    At least one of `easyship_shipment_id` or `platform_order_number` is required; omitting both returns an error from this tool.

    Returns the latest status, estimated delivery date, and a list of tracking
    checkpoints showing the shipment's journey.

    Args:
        easyship_shipment_id: The Easyship shipment ID, e.g. "ESSG10006001" or "ESHK10017799".
            You get this when creating a shipment via the API or from the Easyship dashboard.
            **Required if `platform_order_number` is not provided.**
        platform_order_number: Your store's order number, e.g. "#1042". Use this if you
            don't have the Easyship shipment ID. **Required if `easyship_shipment_id` is not provided.**

    Returns:
        Tracking status with checkpoints showing the shipment's journey, or an error.
    """
    if not easyship_shipment_id and not platform_order_number:
        return {
            "error": True,
            "message": "Provide either easyship_shipment_id or platform_order_number.",
        }

    params: dict[str, Any] = {"include_checkpoints": "true"}
    if easyship_shipment_id:
        params["easyship_shipment_id"] = easyship_shipment_id
    if platform_order_number:
        params["platform_order_number"] = platform_order_number

    data = await easyship_request(
        "GET",
        f"/{API_VERSION}/shipments/trackings",
        headers=headers,
        params=params,
    )
    if data.get("error"):
        return data

    shipments = data.get("shipments", [])

    if not shipments:
        return {
            "error": True,
            "message": "No shipment found for the given ID.",
        }

    results = []
    for s in shipments:
        checkpoints = [
            {
                "time": cp.get("checkpoint_time"),
                "status": cp.get("primary_status"),
                "message": cp.get("message"),
                "location": cp.get("location"),
                "city": cp.get("city"),
                "country": cp.get("country_name"),
                "handler": cp.get("handler"),
            }
            for cp in (s.get("checkpoints") or [])
        ]

        tracking_numbers = [
            {
                "tracking_number": t.get("tracking_number"),
                "handler": t.get("handler"),
                "leg": t.get("leg_number"),
                "state": t.get("tracking_state"),
            }
            for t in (s.get("trackings") or [])
        ]

        results.append(
            {
                "easyship_shipment_id": s.get("easyship_shipment_id"),
                "status": s.get("status"),
                "eta_date": s.get("eta_date"),
                "origin_country": s.get("origin_country_alpha2"),
                "destination_country": s.get("destination_country_alpha2"),
                "platform_order_number": s.get("platform_order_number"),
                "tracking_page_url": s.get("tracking_page_url"),
                "tracking_numbers": tracking_numbers,
                "checkpoints": checkpoints,
            }
        )

    return results[0] if len(results) == 1 else results


# ── create_shipment ─────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("Create Shipment", "create_shipment"), annotations=DESTRUCTIVE)
async def create_shipment(
    shipment_data: dict[str, Any],
    headers: dict[str, str] = CurrentHeaders(),
) -> dict[str, Any]:
    """Create a new shipment and optionally buy a label in one call.

Required authorization scope: `public.shipment:write` (and `public.label:write` if buying a label).

**Before calling:** collect complete address details from the user — contact names, emails, phones, and company name (required for origin).

**Parcel line items (server-enforced):** For every object in `parcels[].items[]`, the **user** must provide at least one of **`category`** (Easyship category slug) or **`hs_code`**. The MCP rejects the request when both (hs_code and category) are missing / empty is missing on any item — **do not pick a default** (e.g. do not assume `fashion`). Ask which product category applies or for the HS code.

## When to buy a label vs just create a shipment

- **"Ship this" / "Buy a label" / "Create a shipping label"** → Set `buy_label: true` and `buy_label_synchronous: true` in `shipping_settings`. With `format: "url"` in `printing_options`, responses include HTTPS URLs under `shipping_documents`.
- **"Create a shipment, don't buy the label yet"** → Omit `buy_label` or set it to `false`. The shipment is created in draft state; the user can buy the label later.

## Choosing a courier

- **No courier specified** → Omit `courier_settings.courier_service_id`. The API auto-selects the best value-for-money courier (no separate rates call required).
- **User names a specific courier** (e.g. "buy a label with UPS Ground") → Use `get_rates` to resolve the matching `courier_service_id`, then pass it as `courier_settings.courier_service_id` with `allow_fallback: false`.

## Reading the label from the response

When `buy_label: true` and `buy_label_synchronous: true`, the response includes a `shipping_documents` array. Entries use `category` (e.g. `label`, `packing_slip`, `commercial_invoice`) and, when `format` is `url`, an `url` field. Example:
```json
"shipping_documents": [
  { "category": "label", "format": "url", "url": "https://...", "page_size": "4x6" },
  { "category": "packing_slip", "format": "url", "url": "https://...", "page_size": "4x6" },
  { "category": "commercial_invoice", ... }
]
```

## Identity / KYC and labels

If the response includes `support_email`, `support_email_link`, or `support_reply_hint`, the payload is noting account or identity verification limits on labels; those fields carry suggested end-user wording from Easyship.

## Payload schema

`shipment_data` is a JSON dict with this structure (fields marked * are required):

```json
{
  "destination_address": {
    "contact_name": "string *",
    "contact_email": "string *",
    "contact_phone": "string * (nullable)",
    "line_1": "string * (max 35)",
    "city": "string *",
    "country_alpha2": "string * (ISO 3166-1)",
    "state": "string (required for AU,CA,CN,ID,MX,MY,TH,US,VN)",
    "postal_code": "string (required for most countries, null for HK)",
    "line_2": "string",
    "company_name": "string"
  },
  "origin_address": {
    "company_name": "string * (max 27)",
    "contact_name": "string * (max 22)",
    "contact_email": "string *",
    "contact_phone": "string *",
    "line_1": "string * (max 35)",
    "city": "string *",
    "state": "string (required for AU,CA,CN,ID,MX,MY,TH,US,VN)",
    "postal_code": "string (required for most countries)",
    "country_alpha2": "string (ISO 3166-1)"
  },
  "parcels": [
    {
      "total_actual_weight": 1.5,
      "box": { "length": 30, "width": 20, "height": 15 },
      "items": [
        {
          "description": "string * (max 200)",
          "quantity": 1,
          "actual_weight": 1.5,
          "dimensions": { "length": 10, "width": 10, "height": 10 },
          "declared_currency": "USD",
          "declared_customs_value": 50.0,
          "category": "<slug from user — required unless hs_code set>",
          "sku": "string",
          "hs_code": "<from user — required unless category set>",
          "contains_battery_pi966": false,
          "contains_battery_pi967": false,
          "contains_liquids": false,
          "origin_country_alpha2": "US"
        }
      ]
    }
  ],
  "incoterms": "DDU or DDP",
  "insurance": { "is_insured": false },
  "courier_settings": {
    "courier_service_id": "uuid (omit to auto-select best courier)",
    "apply_shipping_rules": true,
    "allow_fallback": false
  },
  "shipping_settings": {
    "buy_label": true,
    "buy_label_synchronous": true,
    "units": { "weight": "kg | g | lb | oz", "dimensions": "cm | in" },
    "printing_options": {
      "format": "url",
      "label": "4x6 | A4 | A5",
      "commercial_invoice": "4x6 | A4",
      "packing_slip": "4x6 | A4 | none"
    }
  },
  "order_data": {
    "platform_name": "string",
    "platform_order_number": "string",
    "buyer_notes": "string",
    "seller_notes": "string"
  },
  "set_as_residential": true,
  "metadata": {}
}
```

## Weight and dimensions — three ways

1. Provide `total_actual_weight` + `box` at parcel level.
2. Provide `actual_weight` + `dimensions` per item — total weight and box auto-calculated.
3. Provide `sku` per item — weight and dimensions taken from product catalog.

## Item categories (valid slugs)

mobile_phones, tablets, computers_laptops, cameras, accessory_no_battery, accessory_with_battery,
health_beauty, fashion, watches, home_appliances, home_decor, toys, sport_leisure, bags_luggages,
audio_video, documents, jewelry, dry_food_supplements, books_collectibles, pet_accessory

    Args:
        shipment_data: The full shipment payload as a JSON dict. See schema above.
            At minimum: `destination_address`, `origin_address` (or `origin_address_id`), and `parcels` with at least one item.

    Returns:
        The created shipment object including selected courier, rates, and — if `buy_label` was true — `shipping_documents` array with label/packing slip/invoice URLs.
        If identity verification affects label purchase, the payload may include `support_email`, `support_email_link`, and `support_reply_hint`.
    """
    return await easyship_request(
        "POST",
        f"/{API_VERSION}/shipments",
        headers=headers,
        json=shipment_data,
        success_codes=(200, 201),
        enrich_identity_verification=True,
    )


# ── update_shipment ─────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("Update Shipment", "update_shipment"), annotations=DESTRUCTIVE)
async def update_shipment(
    easyship_shipment_id: str,
    shipment_data: dict[str, Any],
    headers: dict[str, str] = CurrentHeaders(),
) -> dict[str, Any]:
    """Update an existing shipment's details.

Required authorization scope: `public.shipment:write`.

The `shipment_data` dict follows the same schema as `create_shipment` — include only the fields you want to change. See `create_shipment` docstring for the full payload schema.

If you include **`parcels`**, each line item must still have **`category` or `hs_code`** from the user (same validation as `create_shipment`).

    Args:
        easyship_shipment_id: Easyship Shipment ID, e.g. "ESSG10006001".
        shipment_data: Partial shipment payload — same schema as create_shipment, include only fields to update.
            Common updates: destination_address, parcels, courier_settings, shipping_settings, incoterms.

    Returns:
        The updated shipment object from the Easyship API.
    """
    return await easyship_request(
        "PATCH",
        f"/{API_VERSION}/shipments/{easyship_shipment_id}",
        headers=headers,
        json=shipment_data,
    )


# ── list_shipments ──────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("List Shipments", "list_shipments"), annotations=READ_ONLY)
async def list_shipments(
    headers: dict[str, str] = CurrentHeaders(),
    page: int | None = None,
    per_page: int | None = None,
    label_state: list[str] | None = None,
    pickup_state: list[str] | None = None,
    created_at_to: str | None = None,
    updated_at_to: str | None = None,
    delivery_state: list[str] | None = None,
    shipment_state: str | None = None,
    created_at_from: str | None = None,
    updated_at_from: str | None = None,
    warehouse_state: list[str] | None = None,
    label_paid_at_to: str | None = None,
    label_paid_at_from: str | None = None,
    easyship_shipment_id: list[str] | None = None,
    label_generated_at_to: str | None = None,
    origin_country_alpha2: list[str] | None = None,
    platform_order_number: str | None = None,
    label_generated_at_from: str | None = None,
    destination_country_alpha2: list[str] | None = None,
    return_shipment: str | None = None,
) -> dict[str, Any]:
    """Retrieve a list of shipments.
This is for detailed shipment objects.
"DO NOT include cancelled shipments in response unless user explicitly asks"
** USE THIS TOOL FOR:**
- Retrieving detailed shipment information for specific shipments (by ID, tracking number, etc.)
- Getting full shipment objects with all details
- Filtering shipments by specific criteria (state, courier, etc.) when you need the full shipment objects
- When you need individual shipment details, not aggregated analytics

** DO NOT USE THIS TOOL FOR:**
- Analytics queries -> Use analytics tools instead

Required authorization scope: `public.shipment:read`

    Args:
        page: Page number to fetch, default: `1`
        per_page: Number of records per page to fetch, default: `20`
        label_state: Filter by label status. Valid values: "not_created", "pending", "generating", "generated", "printed", "failed", "technical_failed", "reported".
        pickup_state: Filter by pickup status. Valid values: "not_requested", "pending_confirmation", "pending_drop_off", "request_failed", "requested", "completed", "cancelled".
        created_at_to: Search for shipments created before this date: ISO8601 date format.
        updated_at_to: Search for shipments updated before this date: ISO8601 date format.
        delivery_state: Filter by delivery status. Valid values: "not_created", "pending", "info_received", "in_transit_to_customer", "out_for_delivery", "delivered", "failed_attempt", "exception", "expired", "lost_by_courier", "returned_to_shipper".
        shipment_state: Filter by shipment status. Valid values: "created", "cancelled".
        created_at_from: Search for shipments created since this date: ISO8601 date format.
        updated_at_from: Search for shipments updated since this date: ISO8601 date format.
        warehouse_state: For eFulfilment only. Valid values: "pending", "created", "packed", "shipped".
        label_paid_at_to: Search for shipments where the labels were paid for before this date: ISO8601 date format.
        label_paid_at_from: Search for shipments where the labels were paid for since this date: ISO8601 date format.
        easyship_shipment_id: Easyship Shipment ID provided when creating the shipment.
        label_generated_at_to: Search for labels generated before this date: ISO8601 date format.
        origin_country_alpha2: Search by the shipment origin country code: Alpha-2 format (ISO 3166-1).
        platform_order_number: Order number on the sales platform.
        label_generated_at_from: Search for labels generated since this date: ISO8601 date format.
        destination_country_alpha2: Search by shipment destination country code: Alpha-2 format (ISO 3166-1).
        return_shipment: Search by shipment whether the shipment is return shipment or not.

    Returns:
        A paginated list of shipment objects matching the filter criteria.
    """
    params: dict[str, Any] = {}
    if page is not None:
        params["page"] = page
    if per_page is not None:
        params["per_page"] = per_page
    if label_state is not None:
        params["label_state[]"] = label_state
    if pickup_state is not None:
        params["pickup_state[]"] = pickup_state
    if created_at_to is not None:
        params["created_at_to"] = created_at_to
    if updated_at_to is not None:
        params["updated_at_to"] = updated_at_to
    if delivery_state is not None:
        params["delivery_state[]"] = delivery_state
    if shipment_state is not None:
        params["shipment_state"] = shipment_state
    if created_at_from is not None:
        params["created_at_from"] = created_at_from
    if updated_at_from is not None:
        params["updated_at_from"] = updated_at_from
    if warehouse_state is not None:
        params["warehouse_state[]"] = warehouse_state
    if label_paid_at_to is not None:
        params["label_paid_at_to"] = label_paid_at_to
    if label_paid_at_from is not None:
        params["label_paid_at_from"] = label_paid_at_from
    if easyship_shipment_id is not None:
        params["easyship_shipment_id[]"] = easyship_shipment_id
    if label_generated_at_to is not None:
        params["label_generated_at_to"] = label_generated_at_to
    if origin_country_alpha2 is not None:
        params["origin_country_alpha2[]"] = origin_country_alpha2
    if platform_order_number is not None:
        params["platform_order_number"] = platform_order_number
    if label_generated_at_from is not None:
        params["label_generated_at_from"] = label_generated_at_from
    if destination_country_alpha2 is not None:
        params["destination_country_alpha2[]"] = destination_country_alpha2
    if return_shipment is not None:
        params["return"] = return_shipment

    return await easyship_request(
        "GET",
        f"/{API_VERSION}/shipments",
        headers=headers,
        params=params,
    )


# ── get_shipment ────────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("Get Shipment", "get_shipment"), annotations=READ_ONLY)
async def get_shipment(
    easyship_shipment_id: str,
    headers: dict[str, str] = CurrentHeaders(),
    label: str | None = None,
    format: str | None = None,
    packing_slip: str | None = None,
    commercial_invoice: str | None = None,
) -> dict[str, Any]:
    """Fetch a single shipment by Easyship ID, including parcel data and `shipping_documents` metadata when available.

Optional query parameters control document format and page sizes; when `format` is `url`, document entries include HTTPS download links in the API payload.

Required authorization scope: `public.shipment:read`

> All shipment documents are customisable. You can set:
>
> - Document format: URL, PDF or PNG
> - Label page size: A4, A5 or 4x6
> - Commercial invoice page size: A4 or 4x6
> - Packing slip page size: A4 or 4x6

    Args:
        easyship_shipment_id: The Easyship shipment ID, e.g. "ESSG10006001".
        label: Label page size: A4, A5, or 4x6.
        format: Document format: URL, PDF, or PNG.
        packing_slip: Packing slip page size: none, A4, or 4x6.
        commercial_invoice: Commercial invoice page size: A4 or 4x6.

    Returns:
        Full shipment details including shipping documents metadata.
    """
    params: dict[str, Any] = {}
    if label is not None:
        params["label"] = label
    if format is not None:
        params["format"] = format
    if packing_slip is not None:
        params["packing_slip"] = packing_slip
    if commercial_invoice is not None:
        params["commercial_invoice"] = commercial_invoice

    return await easyship_request(
        "GET",
        f"/{API_VERSION}/shipments/{easyship_shipment_id}",
        headers=headers,
        params=params,
    )


# ── delete_shipment ─────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("Delete Shipment", "delete_shipment"), annotations=DESTRUCTIVE)
async def delete_shipment(
    easyship_shipment_id: str,
    headers: dict[str, str] = CurrentHeaders(),
) -> dict[str, Any]:
    """Delete a shipment that has not yet been shipped.

Required authorization scope: `public.shipment:write`

    Args:
        easyship_shipment_id: The Easyship shipment ID, e.g. "ESSG10006001".

    Returns:
        Confirmation of the deleted shipment, or an error.
    """
    return await easyship_request(
        "DELETE",
        f"/{API_VERSION}/shipments/{easyship_shipment_id}",
        headers=headers,
        success_codes=(200, 204),
    )


# ── cancel_shipment ─────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("Cancel Shipment", "cancel_shipment"), annotations=DESTRUCTIVE)
async def cancel_shipment(
    easyship_shipment_id: str,
    headers: dict[str, str] = CurrentHeaders(),
) -> dict[str, Any]:
    """Cancel a shipment that has been shipped. \n\nRequired authorization scope: `public.shipment:write`\n\n> You can cancel your shipment after it has been shipped only if its label failed to be generated or if the label is already generated, but the shipment is not yet in transit.\n

    Args:
        easyship_shipment_id: The Easyship shipment ID, e.g. "ESSG10006001".

    Returns:
        Confirmation of the cancelled shipment, or an error.
    """
    return await easyship_request(
        "POST",
        f"/{API_VERSION}/shipments/{easyship_shipment_id}/cancel",
        headers=headers,
    )


# ── create_label ────────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("Create Label", "create_label"), annotations=DESTRUCTIVE)
async def create_label(
    easyship_shipment_id: str,
    headers: dict[str, str] = CurrentHeaders(),
    courier_service_id: str | None = None,
    format: str = "url",
    label: str = "4x6",
    commercial_invoice: str = "A4",
    packing_slip: str = "4x6",
    remarks: str | None = None,
) -> dict[str, Any]:
    """Create a label for an existing shipment and retrieve it synchronously.

This is the **preferred way to buy a label** for a shipment that already exists. Use this instead of
passing `buy_label` via `update_shipment` — it is a dedicated endpoint that finalizes the shipment,
books it with the courier, and returns the label and shipping documents in one synchronous call.

Required authorization scope: `public.label:write`

**Typical use:** Buying or regenerating a label for an existing shipment ID where `label_state` is `not_created` or similar.

Successful responses include `shipping_documents` with `category` values such as `label`, `packing_slip`, and `commercial_invoice`; with `format` `url`, entries include `url` fields.

If the response includes `support_reply_hint`, `support_email`, or `support_email_link`, the API is noting verification limits on labels—those fields contain Easyship-provided support guidance.

    Args:
        easyship_shipment_id: The Easyship shipment ID, e.g. "ESUS323672208".
        courier_service_id: UUID of the courier service to use. Omit to keep the shipment's current
            courier or let Easyship auto-select the best value-for-money option.
        format: Document format. One of: "url", "pdf", "png", "zpl". Default "url" (returns clickable links).
        label: Label page size. One of: "4x6", "A4", "A5". Default "4x6".
        commercial_invoice: Commercial invoice page size. One of: "4x6", "A4". Default "A4".
        packing_slip: Packing slip page size. One of: "4x6", "A4", "none". Default "4x6".
        remarks: Custom commercial invoice remarks (max 70 chars). Overrides company-level remarks.

    Returns:
        The full shipment object with `shipping_documents` containing label/invoice/packing slip URLs.
        If identity verification affects label purchase, the payload may include `support_email`, `support_email_link`, and `support_reply_hint`.
    """
    body: dict[str, Any] = {
        "printing_options": {
            "format": format,
            "label": label,
            "commercial_invoice": commercial_invoice,
            "packing_slip": packing_slip,
        },
    }
    if courier_service_id is not None:
        body["courier_service_id"] = courier_service_id
    if remarks is not None:
        body["printing_options"]["remarks"] = remarks

    return await easyship_request(
        "POST",
        f"/{API_VERSION}/shipments/{easyship_shipment_id}/label",
        headers=headers,
        json=body,
        success_codes=(200, 201),
        enrich_identity_verification=True,
    )


# ── get_shipment_documents ──────────────────────────────────────────────────


@mcp.tool(
    title=_tool_title("Get Shipment Documents", "get_shipment_documents"),
    annotations=READ_ONLY,
)
async def get_shipment_documents(
    easyship_shipment_id: str,
    document_type: str,
    headers: dict[str, str] = CurrentHeaders(),
    page_size: str | None = None,
) -> dict[str, Any]:
    """Request a shipment document (e.g. commercial invoice) from the API.

The MCP transport cannot return raw PDF bytes; the implementation responds with content-type and size metadata only. Downloadable HTTPS URLs for documents are available via `get_shipment` when document `format` is `url`.

Required authorization scope: `public.shipment_document:read`

    Args:
        easyship_shipment_id: The Easyship shipment ID, e.g. "ESSG10006001".
        document_type: The type of document to retrieve. Must be "commercial_invoice".
        page_size: Page size for the document: "4x6" or "A4". Default: "A4".

    Returns:
        Metadata only (content type and size). For downloadable URLs, use `get_shipment` with format="URL".
    """
    params: dict[str, Any] = {"document_type": document_type}
    if page_size is not None:
        params["page_size"] = page_size

    err, resp = await easyship_request_raw(
        "GET",
        f"/{API_VERSION}/shipments/{easyship_shipment_id}/documents",
        headers=headers,
        params=params,
    )
    if err is not None or resp is None:
        return err or {"error": True, "message": "Unknown request error"}

    return {
        "message": "Binary PDF content received",
        "content_type": resp.headers.get("content-type"),
        "size_bytes": len(resp.content),
    }


# ── list_pickups ────────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("List Pickups", "list_pickups"), annotations=READ_ONLY)
async def list_pickups(
    headers: dict[str, str] = CurrentHeaders(),
    page: int | None = None,
    per_page: int | None = None,
    courier: str | None = None,
    pickup_date: str | None = None,
    shipment_id: str | None = None,
    pickup_state: str | None = None,
) -> dict[str, Any]:
    """Retrieve a list of pickups.

Required authorization scope: `public.pickup:read`

    Args:
        page: Page number to fetch, minimum: 1.
        per_page: Number of records per page to fetch, minimum: 1, maximum: 100.
        courier: Filter by courier name. One of: USPS, Australia Post eParcel, StarTrack, Royal Mail, DHL eCommerce, Canada Post, Quantium.
        pickup_date: Filter by pickup date in YYYY-MM-DD format.
        shipment_id: Filter by shipment ID.
        pickup_state: Filter by pickup state. One of: cancelled, completed, partially-completed, pending-confirmation, pending-delayed-api-request, pending-drop-off, pending-handover, request-failed, request-pickup-window-failed, request-technical-failed, requested.

    Returns:
        A paginated list of pickup objects matching the filter criteria.
    """
    params: dict[str, Any] = {}
    if page is not None:
        params["page"] = page
    if per_page is not None:
        params["per_page"] = per_page
    if courier is not None:
        params["courier"] = courier
    if pickup_date is not None:
        params["pickup_date"] = pickup_date
    if shipment_id is not None:
        params["shipment_id"] = shipment_id
    if pickup_state is not None:
        params["pickup_state"] = pickup_state

    return await easyship_request(
        "GET",
        f"/{API_VERSION}/pickups",
        headers=headers,
        params=params,
    )


# ── get_pickup ──────────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("Get Pickup", "get_pickup"), annotations=READ_ONLY)
async def get_pickup(
    easyship_pickup_id: str,
    headers: dict[str, str] = CurrentHeaders(),
) -> dict[str, Any]:
    """Retrieve details of a specific pickup.

Required authorization scope: `public.pickup:write` (note: the API requires write scope even for this read operation).

    Args:
        easyship_pickup_id: The Easyship pickup ID.

    Returns:
        Full pickup details, or an error.
    """
    return await easyship_request(
        "GET",
        f"/{API_VERSION}/pickups/{easyship_pickup_id}",
        headers=headers,
    )


# ── cancel_pickup ───────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("Cancel Pickup", "cancel_pickup"), annotations=DESTRUCTIVE)
async def cancel_pickup(
    easyship_pickup_id: str,
    headers: dict[str, str] = CurrentHeaders(),
) -> dict[str, Any]:
    """Cancel a pickup.

Required authorization scope: `public.pickup:write`

    Args:
        easyship_pickup_id: The Easyship pickup ID.

    Returns:
        Confirmation of the cancelled pickup, or an error.
    """
    return await easyship_request(
        "POST",
        f"/{API_VERSION}/pickups/{easyship_pickup_id}/cancel",
        headers=headers,
    )


# ── get_pickup_slots ───────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("Get Pickup Slots", "get_pickup_slots"), annotations=READ_ONLY)
async def get_pickup_slots(
    courier_service_id: str,
    headers: dict[str, str] = CurrentHeaders(),
    origin_address_id: str | None = None,
) -> dict[str, Any]:
    """Retrieve available pickup time slots for a courier.

Call this before `create_pickup` to show the user available dates and time windows.

**Typical workflow:**
1. User wants a pickup for a shipment → call `get_shipment` to get the `courier_service_id`
2. Call this tool with that `courier_service_id` to get available slots
3. Present the dates and time windows to the user (or pick the earliest if they want the closest)
4. Call `create_pickup` with the chosen `time_slot_id` or `selected_from_time`/`selected_to_time`

Required authorization scope: `public.pickup:read`

    Args:
        courier_service_id: UUID of the courier service. Get this from the shipment's courier details via `get_shipment`.
        origin_address_id: Origin address ID to check pickup availability for. Optional — defaults to the account's primary address.

    Returns:
        Available pickup slots grouped by date, each with time windows containing `time_slot_id`, `from_time`, and `to_time`.
    """
    params: dict[str, Any] = {}
    if origin_address_id is not None:
        params["origin_address_id"] = origin_address_id

    return await easyship_request(
        "GET",
        f"/{API_VERSION}/courier_services/{courier_service_id}/pickup_slots",
        headers=headers,
        params=params,
    )


# ── create_pickup ──────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("Create Pickup", "create_pickup"), annotations=DESTRUCTIVE)
async def create_pickup(
    courier_service_id: str,
    selected_date: str,
    easyship_shipment_ids: list[str],
    headers: dict[str, str] = CurrentHeaders(),
    time_slot_id: str | None = None,
    selected_from_time: str | None = None,
    selected_to_time: str | None = None,
) -> dict[str, Any]:
    """Schedule a courier pickup for one or more shipments.

**Before calling this tool:**
1. Get the `courier_service_id` from the shipment via `get_shipment`
2. Call `get_pickup_slots` to find available dates/times — present options to user unless they want the closest available
3. All shipments must use the **same courier** and have labels that are pending or generated

You must provide either `time_slot_id` (from `get_pickup_slots`) OR both `selected_from_time` and `selected_to_time`.

Required authorization scope: `public.pickup:write`

    Args:
        courier_service_id: UUID of the courier service (from shipment details).
        selected_date: Pickup date in YYYY-MM-DD format.
        easyship_shipment_ids: List of Easyship shipment IDs to include, e.g. ["ESSG10006001", "ESSG10006002"]. All must use the same courier.
        time_slot_id: UUID of a time slot from `get_pickup_slots`. Provide this OR `selected_from_time`/`selected_to_time`.
        selected_from_time: Pickup window start time (e.g. "09:00"). Required if `time_slot_id` is not provided.
        selected_to_time: Pickup window end time (e.g. "17:00"). Required if `time_slot_id` is not provided.

    Returns:
        The created pickup object with confirmation details, or an error.
    """
    if not time_slot_id and not (selected_from_time and selected_to_time):
        return {
            "error": True,
            "message": "Provide either time_slot_id OR both selected_from_time and selected_to_time.",
        }

    body: dict[str, Any] = {
        "courier_service_id": courier_service_id,
        "selected_date": selected_date,
        "easyship_shipment_ids": easyship_shipment_ids,
    }
    if time_slot_id is not None:
        body["time_slot_id"] = time_slot_id
    if selected_from_time is not None:
        body["selected_from_time"] = selected_from_time
    if selected_to_time is not None:
        body["selected_to_time"] = selected_to_time

    return await easyship_request(
        "POST",
        f"/{API_VERSION}/pickups",
        headers=headers,
        json=body,
        success_codes=(200, 201),
    )


# ── list_pickup_shipments ───────────────────────────────────────────────────


@mcp.tool(
    title=_tool_title("List Pickup Shipments", "list_pickup_shipments"),
    annotations=READ_ONLY,
)
async def list_pickup_shipments(
    pickup_id: str,
    headers: dict[str, str] = CurrentHeaders(),
    page: int | None = None,
    per_page: int | None = None,
    return_shipment: str | None = None,
    label_state: list[str] | None = None,
    pickup_state: list[str] | None = None,
    created_at_to: str | None = None,
    updated_at_to: str | None = None,
    delivery_state: list[str] | None = None,
    shipment_state: str | None = None,
    created_at_from: str | None = None,
    updated_at_from: str | None = None,
    warehouse_state: list[str] | None = None,
    label_paid_at_to: str | None = None,
    label_paid_at_from: str | None = None,
    label_generated_at_to: str | None = None,
    origin_country_alpha2: list[str] | None = None,
    platform_order_number: str | None = None,
    label_generated_at_from: str | None = None,
    destination_country_alpha2: list[str] | None = None,
) -> dict[str, Any]:
    """Retrieve a list of pickup's shipments. \nRequired authorization scope: `public.shipment:read`

    Args:
        pickup_id: The pickup ID to retrieve shipments for.
        page: Page number to fetch, minimum: 1.
        per_page: Number of records per page to fetch, minimum: 1, maximum: 100.
        return_shipment: Search by whether the shipment is a return shipment or not.
        label_state: Filter by label status. Valid values: "not_created", "pending", "generating", "generated", "printed", "failed", "technical_failed", "reported".
        pickup_state: Filter by pickup status. Valid values: "not_requested", "pending_confirmation", "pending_drop_off", "request_failed", "requested", "completed", "cancelled".
        created_at_to: Search for shipments created before this date: ISO8601 date format.
        updated_at_to: Search for shipments updated before this date: ISO8601 date format.
        delivery_state: Filter by delivery status. Valid values: "not_created", "pending", "info_received", "in_transit_to_customer", "out_for_delivery", "delivered", "failed_attempt", "exception", "expired", "lost_by_courier", "returned_to_shipper".
        shipment_state: Filter by shipment status. Valid values: "created", "cancelled".
        created_at_from: Search for shipments created since this date: ISO8601 date format.
        updated_at_from: Search for shipments updated since this date: ISO8601 date format.
        warehouse_state: For eFulfilment only. Valid values: "pending", "created", "packed", "shipped".
        label_paid_at_to: Search for shipments where the labels were paid for before this date: ISO8601 date format.
        label_paid_at_from: Search for shipments where the labels were paid for since this date: ISO8601 date format.
        label_generated_at_to: Search for labels generated before this date: ISO8601 date format.
        origin_country_alpha2: Search by the shipment origin country code: Alpha-2 format (ISO 3166-1).
        platform_order_number: Order number on the sales platform.
        label_generated_at_from: Search for labels generated since this date: ISO8601 date format.
        destination_country_alpha2: Search by shipment destination country code: Alpha-2 format (ISO 3166-1).

    Returns:
        A paginated list of shipment objects for the specified pickup.
    """
    params: dict[str, Any] = {}
    if page is not None:
        params["page"] = page
    if per_page is not None:
        params["per_page"] = per_page
    if return_shipment is not None:
        params["return"] = return_shipment
    if label_state is not None:
        params["label_state[]"] = label_state
    if pickup_state is not None:
        params["pickup_state[]"] = pickup_state
    if created_at_to is not None:
        params["created_at_to"] = created_at_to
    if updated_at_to is not None:
        params["updated_at_to"] = updated_at_to
    if delivery_state is not None:
        params["delivery_state[]"] = delivery_state
    if shipment_state is not None:
        params["shipment_state"] = shipment_state
    if created_at_from is not None:
        params["created_at_from"] = created_at_from
    if updated_at_from is not None:
        params["updated_at_from"] = updated_at_from
    if warehouse_state is not None:
        params["warehouse_state[]"] = warehouse_state
    if label_paid_at_to is not None:
        params["label_paid_at_to"] = label_paid_at_to
    if label_paid_at_from is not None:
        params["label_paid_at_from"] = label_paid_at_from
    if label_generated_at_to is not None:
        params["label_generated_at_to"] = label_generated_at_to
    if origin_country_alpha2 is not None:
        params["origin_country_alpha2[]"] = origin_country_alpha2
    if platform_order_number is not None:
        params["platform_order_number"] = platform_order_number
    if label_generated_at_from is not None:
        params["label_generated_at_from"] = label_generated_at_from
    if destination_country_alpha2 is not None:
        params["destination_country_alpha2[]"] = destination_country_alpha2

    return await easyship_request(
        "GET",
        f"/{API_VERSION}/pickups/{pickup_id}/shipments",
        headers=headers,
        params=params,
    )


# ── list_transactions ───────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("List Transactions", "list_transactions"), annotations=READ_ONLY)
async def list_transactions(
    headers: dict[str, str] = CurrentHeaders(),
    page: int | None = None,
    transaction_type: str | None = None,
    to_date: str | None = None,
    per_page: int | None = None,
    from_date: str | None = None,
    adjustment: bool | None = None,
    days_from_now: int | None = None,
    easyship_shipment_id: str | None = None,
) -> dict[str, Any]:
    """Retrieve a list of all transactions within range.
Pagination of this endpoint is not indexed.
`count` on the response body will always be `null`.

Required authorization scope: `public.transaction_record:read`

    Args:
        page: Page number to fetch, minimum: 1.
        transaction_type: Filter by transaction type. One of: shipment, pickup, claim, policy, payment.
        to_date: Filter transactions before this date in YYYY-MM-DD format.
        per_page: Number of records per page to fetch, minimum: 1, maximum: 100.
        from_date: Filter transactions since this date in YYYY-MM-DD format.
        adjustment: Filter by adjustment transactions.
        days_from_now: Filter transactions from this many days ago, minimum: 1.
        easyship_shipment_id: Filter by Easyship shipment ID, e.g. "ESSG10006001". Must match pattern ^ES\\w{2}\\d{7,}$.

    Returns:
        A paginated list of transaction objects matching the filter criteria.
    """
    params: dict[str, Any] = {}
    if page is not None:
        params["page"] = page
    if transaction_type is not None:
        params["type"] = transaction_type
    if to_date is not None:
        params["to_date"] = to_date
    if per_page is not None:
        params["per_page"] = per_page
    if from_date is not None:
        params["from_date"] = from_date
    if adjustment is not None:
        params["adjustment"] = adjustment
    if days_from_now is not None:
        params["days_from_now"] = days_from_now
    if easyship_shipment_id is not None:
        params["easyship_shipment_id"] = easyship_shipment_id

    return await easyship_request(
        "GET",
        f"/{API_VERSION}/transaction_records",
        headers=headers,
        params=params,
    )


# ── list_billing_transactions ───────────────────────────────────────────────


@mcp.tool(
    title=_tool_title("List Billing Transactions", "list_billing_transactions"),
    annotations=READ_ONLY,
)
async def list_billing_transactions(
    billing_document_id: str,
    headers: dict[str, str] = CurrentHeaders(),
    page: int | None = None,
    to_date: str | None = None,
    per_page: int | None = None,
    from_date: str | None = None,
) -> dict[str, Any]:
    """Retrieve a list of all billing document's transactions.
Pagination of this endpoint is not indexed.
`count` on the response body will always be `null`.

Required authorization scope: `public.transaction_record:read`

    Args:
        billing_document_id: The billing document ID.
        page: Page number to fetch, minimum: 1.
        to_date: Filter transactions before this date in YYYY-MM-DD format.
        per_page: Number of records per page to fetch, minimum: 1, maximum: 100.
        from_date: Filter transactions since this date in YYYY-MM-DD format.

    Returns:
        A paginated list of transaction objects for the specified billing document.
    """
    params: dict[str, Any] = {}
    if page is not None:
        params["page"] = page
    if to_date is not None:
        params["to_date"] = to_date
    if per_page is not None:
        params["per_page"] = per_page
    if from_date is not None:
        params["from_date"] = from_date

    return await easyship_request(
        "GET",
        f"/{API_VERSION}/billing_documents/{billing_document_id}/transaction_records",
        headers=headers,
        params=params,
    )


# ── validate_address ────────────────────────────────────────────────────────


@mcp.tool(title=_tool_title("Validate Address", "validate_address"), annotations=DESTRUCTIVE)
async def validate_address(
    line_1: str,
    city: str,
    headers: dict[str, str] = CurrentHeaders(),
    country_alpha2: str | None = None,
    state: str | None = None,
    line_2: str | None = None,
    postal_code: str | None = None,
    company_name: str | None = None,
    replace_with_validation_result: bool | None = None,
) -> dict[str, Any]:
    """Validate a shipping address. Works for both US domestic and international addresses.

If `country_alpha2` is "US" or omitted, uses the domestic validation endpoint.
Otherwise, uses the international validation endpoint.

Required authorization scope:
- `public.address_validation_domestic:write` for US addresses.
- `public.address_validation:write` for international addresses.

> This API requires an updated contract with Easyship. Contact your account manager or Easyship Support Team.

    Args:
        line_1: Address line 1 (street address).
        city: City name.
        country_alpha2: Country code in Alpha-2 format (ISO 3166-1). Omit or use "US" for US domestic validation.
        state: State or province. Required for AU, CA, CN, ID, MX, MY, TH, US, VN.
        line_2: Address line 2 (apartment, suite, etc.).
        postal_code: Postal or ZIP code.
        company_name: Company name.
        replace_with_validation_result: Whether to replace the address with the validation result. Default: false.

    Returns:
        Address validation result with suggested corrections, or an error.
    """
    is_domestic = country_alpha2 is None or country_alpha2.upper() == "US"

    body: dict[str, Any] = {
        "line_1": line_1,
        "city": city,
    }
    if not is_domestic and country_alpha2 is not None:
        body["country_alpha2"] = country_alpha2
    if state is not None:
        body["state"] = state
    if line_2 is not None:
        body["line_2"] = line_2
    if postal_code is not None:
        body["postal_code"] = postal_code
    if company_name is not None:
        body["company_name"] = company_name
    if replace_with_validation_result is not None:
        body["replace_with_validation_result"] = replace_with_validation_result

    endpoint = (
        f"/{API_VERSION}/addresses/validations_domestic"
        if is_domestic
        else f"/{API_VERSION}/addresses/validations"
    )

    return await easyship_request(
        "POST",
        endpoint,
        headers=headers,
        json=body,
    )


# ── analytics_top_destinations ──────────────────────────────────────────────


@mcp.tool(
    title=_tool_title("Analytics Top Destinations", "analytics_top_destinations"),
    annotations=READ_ONLY,
)
async def analytics_top_destinations(
    from_date: str,
    to_date: str,
    headers: dict[str, str] = CurrentHeaders(),
) -> dict[str, Any]:
    """Retrieves top shipping destinations ranked by shipment volume.

Use for any question about where shipments are going, top destinations, or destination countries.

Returns `total_shipments_count`, `shipments_count_by_zone` (zone name + count), and `shipments_count_by_country` (country name, alpha2 code, count, percentage).

**Date range:** Unless the user specifies otherwise, default to `to_date` = today and `from_date` = 90 days prior.

Required authorization scope: `public.analytics:read`

    Args:
        from_date: Start date in YYYY-MM-DD format. Default to 90 days before to_date if user doesn't specify.
        to_date: End date in YYYY-MM-DD format. Default to today if user doesn't specify.

    Returns:
        Top shipping destinations with shipment counts by zone and by country.
    """
    return await easyship_request(
        "GET",
        f"/{API_VERSION}/analytics/top_shipments_destinations",
        headers=headers,
        params={"from_date": from_date, "to_date": to_date},
    )


# ── analytics_shipments ─────────────────────────────────────────────────────


@mcp.tool(
    title=_tool_title("Analytics Shipments", "analytics_shipments"),
    annotations=READ_ONLY,
)
async def analytics_shipments(
    from_date: str,
    to_date: str,
    headers: dict[str, str] = CurrentHeaders(),
) -> dict[str, Any]:
    """Retrieve shipment volume overview: total shipment count and daily shipment counts over time.

Returns `total_shipments_count` and `shipments_count_by_date` (a time series with daily totals and a `max` peak value).

**Use this tool for:**
- "How many shipments did I create?" — total count for a period
- "Show me my shipment volume trend" — daily time series
- Overall shipment volume and trends over time

**Do NOT use this tool for:**
- Destination-specific analytics → Use `analytics_top_destinations`
- Shipped/label-generated counts → Use `analytics_shipped`
- Shipment status breakdown → Use `analytics_shipment_status`
- Courier performance → Use `analytics_top_couriers`
- Sales channel analytics → Use `analytics_sale_channels`

**Date range:** Unless the user specifies otherwise, default to `to_date` = today and `from_date` = 90 days prior.

Required authorization scope: `public.analytics:read`

    Args:
        from_date: Start date in YYYY-MM-DD format. Default to 90 days before to_date if user doesn't specify.
        to_date: End date in YYYY-MM-DD format. Default to today if user doesn't specify.

    Returns:
        Total shipment count and daily shipment count time series for the date range.
    """
    return await easyship_request(
        "GET",
        f"/{API_VERSION}/analytics/shipments",
        headers=headers,
        params={"from_date": from_date, "to_date": to_date},
    )


# ── analytics_shipped ───────────────────────────────────────────────────────


@mcp.tool(
    title=_tool_title("Analytics Shipped", "analytics_shipped"),
    annotations=READ_ONLY,
)
async def analytics_shipped(
    from_date: str,
    to_date: str,
    headers: dict[str, str] = CurrentHeaders(),
) -> dict[str, Any]:
    """Retrieves data for shipments that have already been shipped (labels generated) within a date range.

Returns `has_ever_shipped` (boolean) and `currency` info. Use this for questions about past shipping activity.

**USE THIS TOOL FOR:**
- "Did I ship anything yesterday?", "How many shipments last week?"
- "Show me shipments from last month", "Have I ever shipped anything?"
- Historical shipping activity confirmation

**Do NOT use for:** destination analytics, status breakdowns, or courier performance — use the specific analytics tools instead.
Use `list_shipments` only when you need detailed shipment objects by ID, not for date-based analytics.

**Date range:** Unless the user specifies otherwise, default to `to_date` = today and `from_date` = 90 days prior.

Required authorization scope: `public.analytics:read`

    Args:
        from_date: Start date in YYYY-MM-DD format. Default to 90 days before to_date if user doesn't specify.
        to_date: End date in YYYY-MM-DD format. Default to today if user doesn't specify.

    Returns:
        Shipped shipment data including whether the account has ever shipped and currency info.
    """
    return await easyship_request(
        "GET",
        f"/{API_VERSION}/analytics/shipments_shipped",
        headers=headers,
        params={"from_date": from_date, "to_date": to_date},
    )


# ── analytics_shipment_status ───────────────────────────────────────────────


@mcp.tool(
    title=_tool_title("Analytics Shipment Status", "analytics_shipment_status"),
    annotations=READ_ONLY,
)
async def analytics_shipment_status(
    from_date: str,
    to_date: str,
    headers: dict[str, str] = CurrentHeaders(),
) -> dict[str, Any]:
    """Retrieve shipment status distribution: how many shipments are in each status.

Returns `in_progress_shipments_count`, `completed_shipments_count`, and `in_progress_shipments` array (each with `status` and `count`).

Possible statuses: Label Pending, Label Rejected, Label Ready, Pickup/Drop-off in Progress, In Transit to Customer, Failed Delivery Attempt, Exception.

**Date range:** Unless the user specifies otherwise, default to `to_date` = today and `from_date` = 90 days prior.

Required authorization scope: `public.analytics:read`

    Args:
        from_date: Start date in YYYY-MM-DD format. Default to 90 days before to_date if user doesn't specify.
        to_date: End date in YYYY-MM-DD format. Default to today if user doesn't specify.

    Returns:
        Shipment counts by status (in-progress breakdown + completed total).
    """
    return await easyship_request(
        "GET",
        f"/{API_VERSION}/analytics/shipment_status",
        headers=headers,
        params={"from_date": from_date, "to_date": to_date},
    )


# ── analytics_top_couriers ──────────────────────────────────────────────────


@mcp.tool(
    title=_tool_title("Analytics Top Couriers", "analytics_top_couriers"),
    annotations=READ_ONLY,
)
async def analytics_top_couriers(
    from_date: str,
    to_date: str,
    headers: dict[str, str] = CurrentHeaders(),
) -> dict[str, Any]:
    """Retrieves top couriers ranked by shipment volume.

Returns `total_shipments_count` and `couriers` array (each with `name`, `shipments_count`, `percentage`).

Use for: "Which courier do I use most?", "Show courier breakdown", carrier performance analysis.

**Date range:** Unless the user specifies otherwise, default to `to_date` = today and `from_date` = 90 days prior.

Required authorization scope: `public.analytics:read`

    Args:
        from_date: Start date in YYYY-MM-DD format. Default to 90 days before to_date if user doesn't specify.
        to_date: End date in YYYY-MM-DD format. Default to today if user doesn't specify.

    Returns:
        Top couriers with shipment counts and percentage of total volume.
    """
    return await easyship_request(
        "GET",
        f"/{API_VERSION}/analytics/top_couriers",
        headers=headers,
        params={"from_date": from_date, "to_date": to_date},
    )


# ── analytics_sale_channels ─────────────────────────────────────────────────


@mcp.tool(
    title=_tool_title("Analytics Sale Channels", "analytics_sale_channels"),
    annotations=READ_ONLY,
)
async def analytics_sale_channels(
    from_date: str,
    to_date: str,
    headers: dict[str, str] = CurrentHeaders(),
) -> dict[str, Any]:
    """Retrieve shipment volume by sales channel (e.g. Shopify, WooCommerce, API, manual).

Returns `total_shipments_count` and `channels` array (each with `name`, `shipments_count`, `percentage`).

Use for: "Which sales channel has the most shipments?", "Show me channel breakdown."

**Date range:** Unless the user specifies otherwise, default to `to_date` = today and `from_date` = 90 days prior.

Required authorization scope: `public.analytics:read`

    Args:
        from_date: Start date in YYYY-MM-DD format. Default to 90 days before to_date if user doesn't specify.
        to_date: End date in YYYY-MM-DD format. Default to today if user doesn't specify.

    Returns:
        Sales channels with shipment counts and percentage of total volume.
    """
    return await easyship_request(
        "GET",
        f"/{API_VERSION}/analytics/sale_channels",
        headers=headers,
        params={"from_date": from_date, "to_date": to_date},
    )


def main():
    transport = os.environ.get("MCP_TRANSPORT", "stdio")
    if transport == "streamable-http":
        port = int(os.environ.get("PORT", "8080"))
        mcp.run(transport="streamable-http", host="0.0.0.0", port=port)
    else:
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
