"""OAuth 2.0 metadata endpoints for the Easyship MCP server.

Exposes RFC 9728 (Protected Resource Metadata) and RFC 8414
(Authorization Server Metadata) documents that MCP clients use to
discover Easyship's OAuth flow. Registration is opt-in via
:func:`register_oauth_routes` so the route handlers stay co-located with
the scope list they advertise.
"""

from __future__ import annotations

import os

from fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import JSONResponse

# Doorkeeper base URL (no trailing slash). Defaults to production; set to
# ``https://auth-staging.easyship.com`` for staging.
_AUTH_BASE = os.environ.get(
    "EASYSHIP_OAUTH_AUTH_BASE", "https://auth.easyship.com"
).rstrip("/")

def _metadata_origin(request: Request) -> str:
    """Origin used as ``issuer`` / ``resource`` for OAuth metadata (RFC 8414 §3.3).

    Must match the URL the client used to reach this server (e.g. localhost in
    dev). Trailing slash stripped.
    """

    return str(request.base_url).rstrip("/")


SCOPES: list[str] = [
    "public.shipment:read",
    "public.shipment:write",
    "public.rate:read",
    "public.label:write",
    "public.pickup:read",
    "public.pickup:write",
    "public.address_validation:write",
    "public.address_validation_domestic:write",
    "public.shipment_document:read",
    "public.transaction_record:read",
    "public.analytics:read",
    "public.track:read",
]


def register_oauth_routes(mcp: FastMCP) -> None:
    """Attach the OAuth 2.0 metadata endpoints to ``mcp``."""

    # RFC 9728 — OAuth 2.0 Protected Resource Metadata
    # Tells MCP clients which authorization server handles token issuance for
    # this server. ``authorization_servers`` points to ourselves because we
    # serve the AS metadata document below
    # (``/.well-known/oauth-authorization-server``) that proxies Doorkeeper's
    # endpoints.
    @mcp.custom_route(
        "/.well-known/oauth-protected-resource",
        methods=["GET"],
        include_in_schema=False,
    )
    async def oauth_protected_resource(request: Request) -> JSONResponse:
        origin = _metadata_origin(request)
        return JSONResponse(
            {
                "resource": origin,
                "authorization_servers": [origin],
                "scopes_supported": SCOPES,
                "resource_name": "Easyship MCP",
                "resource_documentation": "https://developers.easyship.com",
            }
        )

    # RFC 8414 — OAuth 2.0 Authorization Server Metadata
    # ``issuer`` MUST equal the URL prefix used to fetch this document
    # (RFC 8414 §3.3). Authorize/token/revoke URLs point at Doorkeeper
    # (production by default; override with ``EASYSHIP_OAUTH_AUTH_BASE``).
    @mcp.custom_route(
        "/.well-known/oauth-authorization-server",
        methods=["GET"],
        include_in_schema=False,
    )
    async def oauth_authorization_server(request: Request) -> JSONResponse:
        return JSONResponse(
            {
                "issuer": _metadata_origin(request),
                "authorization_endpoint": f"{_AUTH_BASE}/oauth2/authorize",
                "token_endpoint": f"{_AUTH_BASE}/oauth2/token",
                "revocation_endpoint": f"{_AUTH_BASE}/oauth2/revoke",
                "response_types_supported": ["code"],
                "grant_types_supported": ["authorization_code", "refresh_token"],
                "code_challenge_methods_supported": ["S256"],
                "token_endpoint_auth_methods_supported": [
                    "client_secret_post",
                    "client_secret_basic",
                ],
                "scopes_supported": SCOPES,
                "service_documentation": "https://developers.easyship.com",
            }
        )
