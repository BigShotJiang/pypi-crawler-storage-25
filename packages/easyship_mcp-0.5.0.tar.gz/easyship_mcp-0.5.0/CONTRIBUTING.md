# Publishing a New Version

## 1. Bump the version

Update `version` in both files:

- `pyproject.toml`
- `server.json`

## 2. Build and publish to PyPI

```bash
rm -rf dist/
uv run python -m build
uv run python -m twine upload dist/*
```

Username: `__token__`
Password: your PyPI API token (starts with `pypi-`)

## 3. Publish to the MCP Registry

```bash
PRIVATE_KEY="$(openssl pkey -in mcp-key.pem -noout -text | grep -A3 'priv:' | tail -n +2 | tr -d ' :\n')"
mcp-publisher login dns --domain easyship.com --private-key "${PRIVATE_KEY}"
mcp-publisher publish
```

## Domain verification

The `mcp-key.pem` file is the Ed25519 private key used for domain verification. The matching public key is published as a DNS TXT record on `easyship.com`:

```
easyship.com.  IN  TXT  "v=MCPv1; k=ed25519; p=<PUBLIC_KEY>"
```

Keep `mcp-key.pem` safe and out of version control.

## Deploying to Cloud Run

### Build and push

```bash
gcloud builds submit --tag gcr.io/easyship-production/easyship-mcp
```

### Deploy

```bash
gcloud run deploy easyship-mcp \
  --image gcr.io/easyship-production/easyship-mcp \
  --region us-central1 \
  --port 8080 \
  --set-env-vars MCP_TRANSPORT=streamable-http \
  --service-account mcp-server@easyship-production.iam.gserviceaccount.com \
  --allow-unauthenticated
```

No API token is set on the server. Each user passes their own token via the `Authorization: Bearer` header with every MCP request.

### Test

```bash
curl -X POST https://easyship-mcp-HASH-uc.a.run.app/mcp \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "Authorization: Bearer YOUR_EASYSHIP_TOKEN" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}'
```
