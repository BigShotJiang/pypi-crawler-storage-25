---
name: review-pr
description: >-
  Perform comprehensive PR reviews covering requirement validation, test coverage, security, performance, edge cases, and business logic. Use when reviewing pull requests, examining code changes, or when the user asks to review a PR. Uses gh for GitHub PRs and acli jira workitem view for JIRA (description field only).
---

# Comprehensive PR Review

## Code reference format (required)

Whenever you reference production code, tests, or snippets from the PR, **always include the repo-relative file path and line number(s)**:

- Single line: `` `app/models/user.rb:45` ``
- Range: `` `app/controllers/api/v1/auth_controller.rb:67-89` ``

Use the same format in bullets and tables. **Never print large code blocks** — cite the location (path + line range) only. Never cite code with only a line number and no file path.

## Suggestion format (required)

When proposing fixes or improvements, **never write complete code solutions**. Always use pseudo code that conveys intent, not implementation:

```
# pseudo code example
# fetch the record with a scoped query (owner-filtered)
# validate presence before proceeding
# return appropriate error if missing
```

Keep pseudo code concise — 3–6 lines max. Focus on the _what_, not the _how_.

## Where to save PR reviews

When saving the completed review as a markdown file on disk, write it under **`~/Code/pr-reviews/`**. Use a clear filename (for example `PR_<PR_NUMBER>_review.md` or `<repository>_PR_<number>.md`) so reviews stay organized across repositories.

## Before You Start

Ask the user **two questions** before beginning the review:

**1. Cross-squad review?**  
Ask: *"Is this a cross-squad PR review?"* (yes / no).  
- If **yes**: Load `.cursor/docs/ep_files.md` (the enterprise-be-group owned file list) and include a **Cross-Squad Impact** section in the report (see Step 2b below).  
- If **no**: Skip the cross-squad section entirely.

**2. Which sections to skip?**  
Use the AskQuestion tool to present these options (allow multiple selections):
- Summary
- Requirement Validation
- Edge Cases
- Test Cases
- Performance Improvements
- Security Audit
- Typos & Debuggers
- Human Verification Points
- AI Suggestions
- Cross-Squad Impact *(only shown if cross-squad = yes)*

If AskQuestion is unavailable, ask both questions conversationally.

## Tools Required

- **GitHub CLI**: Use `gh pr view <PR_NUMBER>` to fetch PR details, files, and diff
- **Atlassian CLI**: Use `acli jira workitem view <ISSUE_KEY>` to fetch the work item. For **requirement validation**, use **only the work item’s description** as the source of truth (ignore title, status, comments, and other fields for mapping acceptance criteria unless the user explicitly asks otherwise).

## Review Process

### Step 1: Gather Context

1. **Fetch PR details**:
   ```bash
   gh pr view <PR_NUMBER> --json title,body,files,additions,deletions
   gh pr diff <PR_NUMBER>
   ```

2. **Extract JIRA ticket key** from PR title/body (e.g., `PROJ-123`). If multiple keys appear, prefer the one clearly tied to the feature; note ambiguity in the review.

3. **Fetch JIRA work item** (when a key was found):
   ```bash
   acli jira workitem view <ISSUE_KEY>
   ```
   **IMPORTANT**: When using the Shell tool to invoke this command, always include `required_permissions: ["all"]` to ensure network access to Atlassian APIs.
   
   Parse the output and **extract only the description** text. Use that description for requirement validation—not the summary/title alone.

4. **JIRA fetch status (must appear in the review)**  
   In the final report, include a short **JIRA / ticket context** subsection (near the top, after PR metadata) that states exactly what happened:

   | Situation | What to write |
   |-----------|----------------|
   | Key found, `acli` succeeded, description present | Quote or summarize the description; state that requirement validation is based on **description only**. |
   | Key found, `acli` failed (non‑zero exit, auth error, network, etc.) | State the failure reason if known; say requirement validation **could not be tied to JIRA** and rely on PR body/title only—**highlight prominently**. |
   | Key found but description empty / missing in output | Say description was unavailable; requirement validation uses PR description only—**highlight**. |
   | No key found in PR | Say no ticket key detected; requirement validation uses PR description/body only—**highlight**. |
   | User skipped “Requirement Validation” | Note that JIRA was ignored for that section by user choice. |

5. **Read all modified files** to understand the full scope of changes

### Step 2: Summary (if not skipped)

Provide a concise summary covering:

**Business Context:**
- What business problem does this PR solve?
- What user/customer impact will this have?
- Key functionality being added/modified

Do **not** include a flat list of all files changed. Only mention files when discussing a specific concern or impact.

Format:
```markdown
## Summary

### Business Impact
[1-2 paragraphs explaining what this achieves in business terms]
```

### Step 2b: Cross-Squad Impact (only if cross-squad = yes, and not skipped)

Read `.cursor/docs/ep_files.md`. Cross-reference every file in the PR diff against the enterprise-be-group owned patterns listed in that file.

Report:
- Which PR files match enterprise-be-group owned paths, and how the changes in the PR may affect them (behaviour change, dependency shift, interface break, etc.)
- Only mention files where there is a real concern or coupling worth flagging — not a plain inventory.

Format:
```markdown
## Cross-Squad Impact

### ⚠️ Enterprise BE Group Files Affected
- `app/models/public_api/app_access.rb:34-67` — Change to `scope` method may alter token resolution behaviour relied on by open-api controllers
- `app/policies/shipment_policy.rb:12` — New permission check may conflict with existing enterprise API authorization flow

### ℹ️ No Concerns
- `app/services/public_api/rate_calculator.rb` — Touched but no interface or behaviour change detected
```

### Step 3: Requirement Validation (if not skipped)

**Critical**: Compare requirements from the **JIRA work item description** (see Step 1) against code changes. If JIRA was not fetched or description was missing, derive requirements from the PR body/title and **state that explicitly** in this section too.

For each requirement in the JIRA description (or fallback source):
1. Identify the specific acceptance criteria
2. Trace through the code changes to verify implementation
3. Flag any missing or partially implemented requirements

Format:
```markdown
## Requirement Validation

### ✅ Implemented Requirements
- [JIRA-123, AC1] User can enable MFA → Verified in `app/controllers/api/v1/auth_controller.rb:45-67`
- [JIRA-123, AC2] MFA codes expire after 5 minutes → Verified in `app/services/mfa_service.rb:23`

### ❌ Missing Requirements
- [JIRA-123, AC3] Email notification on MFA enable → No implementation found
- [JIRA-123, AC4] Admin can disable MFA for users → Missing `app/controllers/admin/mfa_controller.rb` (or equivalent)

### ⚠️ Partial Implementation
- [JIRA-123, AC5] Support for SMS and authenticator app → Only authenticator app implemented
```

### Step 4: Edge Cases (if not skipped)

Analyze the code for edge case handling:

- **Nil/null checks**: Are all nullable values handled?
- **Empty collections**: What happens with empty arrays/hashes?
- **Boundary values**: Min/max values, zero, negative numbers
- **Concurrent operations**: Race conditions, locking issues
- **Data states**: What if record is deleted, archived, or in transition?
- **External dependencies**: What if API call fails, times out, or returns unexpected data?

Format:
```markdown
## Edge Cases

### 🔴 Critical Missing
- `app/models/courier_account.rb:45` — `CourierAccount.find(params[:id])` — No handling for deleted accounts
- `app/models/user.rb:78` — `user.email.downcase` — Crashes if email is nil

### 🟡 Potential Issues
- `app/services/shipment_processor.rb:123` — Loop may be slow with 10k+ items — consider pagination
- `app/lib/external_api/client.rb:234` — No timeout on external API call

### 🟢 Well Handled
- `app/queries/rate_query.rb:56-60` — Proper validation for date range boundaries
- `app/services/courier_gateway.rb:89-95` — Graceful fallback when courier service is unavailable
```

### Step 5: Test Cases (if not skipped)

Verify test coverage matches code changes:

1. **Map tests to production changes** — does each significant change have tests? Only call out files where coverage is missing or insufficient.
2. **Check test quality**:
   - Happy path covered?
   - Error scenarios tested?
   - Edge cases included?
   - Mocks used appropriately?

Format:
```markdown
## Test Coverage

### ✅ Well Tested
- `app/models/user.rb` → Covered by `spec/models/user_spec.rb` (lines 45-89)
  - Happy path, edge cases, and error scenarios all tested

### ❌ Missing Tests
- `app/services/billing_service.rb` (lines 123-145) → No tests for refund logic
- `app/lib/courier_platform/rates/calculator.rb` → New method `calculate_zone_surcharge` untested

### ⚠️ Insufficient Coverage
- `app/controllers/api/v1/shipments_controller.rb` → Only happy path tested
  - Missing: validation error scenarios, unauthorized access, rate limit tests
```

### Step 6: Performance Improvements (if not skipped)

Identify performance optimization opportunities:

- **N+1 queries**: Missing `includes`/`joins`?
- **Eager loading**: Using `bridge` pattern for associations (as mentioned in user example)?
- **Unnecessary queries**: Can data be cached or fetched once?
- **Large loops**: Can be optimized with batch operations?
- **Memory usage**: Large object allocations, string concatenation in loops?
- **Database indexes**: New queries need indexes?

Format:
```markdown
## Performance Improvements

### 🔴 Critical
- **N+1 Query** — `app/controllers/shipments_controller.rb:67`:
  Suggestion (pseudo code):
  ```
  # eager-load courier_account association before iterating
  # use .includes(:courier_account) on the collection
  ```

- **Missing Index** — `app/models/user.rb:234`: database filter on `users.external_id` needs index for scale

### 🟡 Optimization Opportunities
- `app/models/courier_account.rb:45` — Use `CourierAccount.bridge` pattern instead of direct query
- `app/services/bulk_shipments.rb:123` — `process_bulk_shipments` runs one-by-one — consider batching

### 🟢 Already Optimized
- `app/queries/shipment_query.rb:89` — Proper use of `select` to limit columns
- `app/services/rate_service.rb:156` — Cached courier rates lookup
```

### Step 7: Security Audit (if not skipped)

Check for security vulnerabilities:

- **SQL Injection**: Raw SQL with user input? Use parameterized queries
- **XSS**: User input rendered without escaping?
- **Authentication**: Endpoints properly protected?
- **Authorization**: Proper permission checks? Can user access others' data?
- **Mass assignment**: Strong parameters used?
- **Sensitive data**: Passwords/tokens logged or exposed?
- **Memory leaks**: Large objects not garbage collected?
- **Input validation**: All user inputs validated?
- **CSRF protection**: Forms properly protected?

Format:
```markdown
## Security Audit

### 🔴 Vulnerabilities Found
- **SQL Injection Risk** — `app/models/shipment.rb:89`:
  Suggestion (pseudo code):
  ```
  # use parameterized query instead of string interpolation
  # pass status as a named parameter to where()
  ```

- **Authorization Bypass** — `app/controllers/api/v1/shipments_controller.rb:145`:
  No check if user owns shipment before deletion

- **Sensitive Data Exposure** — `app/services/payment_gateway.rb:67`:
  API key logged in error message

### 🟡 Potential Concerns
- `app/models/user.rb:234` — Mass assignment on `User` — verify strong params
- `app/controllers/api/v1/webhooks_controller.rb:12` — No rate limiting on new endpoint

### 🟢 Security Best Practices Followed
- Proper authentication on all endpoints
- Strong parameters used correctly
- Sensitive fields excluded from logs
```

### Step 8: Typos & Debuggers (if not skipped)

Scan for common mistakes:

- **Debuggers**: `debugger`, `binding.pry`, `console.log`, `byebug`, `puts` (for debugging)
- **Typos**: Misspelled variable names, comments, strings
- **Invalid characters**: UTF-8 issues, smart quotes in code
- **Commented code**: Large blocks of commented code
- **TODO/FIXME**: Unresolved TODO items being committed
- **Hardcoded values**: Magic numbers, hardcoded URLs/credentials

Format:
```markdown
## Typos & Code Quality

### 🔴 Must Fix
- `app/controllers/api/v1/mfa_controller.rb:145` — `binding.pry` — Remove debugger
- `app/controllers/api/v1/mfa_controller.rb:67`, `app/controllers/api/v1/mfa_controller.rb:89`, `app/models/user.rb:234` — `puts "DEBUG: ..."` — Remove debug statements

### 🟡 Should Fix
- `app/models/courier_account.rb:234` — Typo: `curier_account` should be `courier_account`
- `app/services/external_client.rb:456` — Hardcoded URL `https://api.example.com` — Use config
- `app/lib/totp_generator.rb:123-156` — Large commented block — Remove or document why kept

### 💡 Code Quality
- `app/services/checkout_service.rb:89-102` — Consider extracting complex conditional into named method
- `app/models/subscription.rb:67` — Magic number `86400` — Use `1.day.seconds` or constant
```

### Step 9: Human Verification Points (if not skipped)

Flag items requiring human judgment that AI cannot fully validate:

- **Business logic correctness**: Does the algorithm match business rules?
- **UX implications**: Will users understand this flow?
- **Integration points**: Does this integrate correctly with external systems?
- **Compliance**: Does this meet legal/regulatory requirements?
- **Pricing logic**: Are calculations correct for all scenarios?
- **Customer communication**: Are emails/notifications appropriate?
- **Data migration**: Will existing data migrate correctly?
- **Feature flags**: Should this be behind a flag for gradual rollout?

Format:
```markdown
## Human Verification Required

### Business Logic Validation
1. **Pricing calculation** — `app/services/pricing_calculator.rb:145-189`:
   - Verify the zone surcharge formula matches latest pricing policy
   - Confirm handling of promotional discounts is correct
   
2. **Refund logic** — `app/services/refund_service.rb:234-267`:
   - Validate refund eligibility rules match business requirements
   - Check if partial refunds are handled per latest policy

### User Experience
3. **Error message** — `app/controllers/api/v1/shipments_controller.rb:89`:
   - "Invalid shipment parameters" — Is this message clear enough for end users?
   - Should include which parameters are invalid?

4. **Email notification** — `app/views/user_mailer/mfa_enabled.html.erb:1-40` / `app/mailers/user_mailer.rb:123-145`:
   - Review email copy for tone and clarity
   - Verify it matches brand voice guidelines

### Integration & Compliance
5. **Third-party API integration** — `app/lib/vendor_api/client.rb:456-489`:
   - Confirm API contract hasn't changed (check with vendor)
   - Verify test credentials work in staging

6. **Data retention** — `app/models/user.rb:234`:
   - Deleting user data after 90 days — confirm GDPR compliance
```

### Step 10: AI Suggestions (if not skipped)

Provide business logic improvements based on existing codebase patterns:

- **Pattern consistency**: Are similar operations done similarly?
- **Code reuse**: Can this use existing utilities/services?
- **Architecture**: Does this fit the existing architecture?
- **Bridge pattern**: Should `bridge` be used for associations? (user's example)
- **Service extraction**: Should logic move to service object?
- **Better abstractions**: Can complexity be reduced?

Format:
```markdown
## AI Suggestions - Business Logic Improvements

### Architecture & Patterns
1. **Use bridge pattern for CourierAccount queries** — `app/controllers/api/v1/courier_accounts_controller.rb:67`:
   Suggestion (pseudo code):
   ```
   # scope query through company association
   # use .bridge pattern consistent with rest of codebase
   # find record within that scoped collection
   ```
   Benefit: Consistent with codebase pattern, better scoping

2. **Extract to service object** — `app/controllers/api/v1/checkout_controller.rb:123-189`:
   Complex pricing logic in controller — move to `PricingCalculator` service  
   Benefit: Testability, reusability, separation of concerns

### Code Quality
3. **Simplify conditional logic** — `app/services/order_processor.rb:89-102`:
   Suggestion (pseudo code):
   ```
   # replace nested if/else with early returns
   # guard clause: return reject unless approved?
   # then handle each status with a flat conditional or state machine
   ```

4. **Leverage existing utilities** — `app/helpers/date_helper.rb:234`:
   Custom date formatting — use `DateFormatter` utility already in codebase

### Data Modeling
5. **Consider using existing association** — `app/queries/shipment_reports_query.rb:145`:
   Building manual join — `Shipment` already has `courier_shipments` association  
   Suggestion: traverse association instead of raw SQL join
```

## Final Output Format

Present all findings in a structured report:

```markdown
# PR Review: [PR Title]

**PR**: #123
**JIRA**: PROJ-456 (or “none detected” / “fetch failed — see below”)
**Reviewer**: AI Agent
**Date**: [Date]

### JIRA / ticket context

Briefly state: key detected or not; `acli jira workitem view` outcome; confirm requirement validation used **description only** or explain fallback (PR body only, fetch error, empty description). If anything was wrong or skipped, **make this subsection prominent** (e.g., callout or “Attention”).

---

[Include only non-skipped sections in order:]
1. Summary
2. Cross-Squad Impact *(only if cross-squad = yes and not skipped)*
3. Requirement Validation
4. Edge Cases
5. Test Coverage
6. Performance Improvements
7. Security Audit
8. Typos & Code Quality
9. Human Verification Required
10. AI Suggestions

---

## Overall Assessment

**Recommendation**: ✅ Approve / ⚠️ Approve with comments / ❌ Request changes

**Blocking Issues**: [Count]
**Suggestions**: [Count]

**Key Strengths**:
- [List 2-3 things done well]

**Priority Fixes**:
1. [Most critical issue to address]
2. [Second most critical]
3. [Third most critical]
```

## Tips for Effective Reviews

1. **Be specific**: Always cite **`path/to/file.ext:startLine`** or **`path/to/file.ext:startLine-endLine`** with every code reference (never line-only citations, never raw code dumps)
2. **Be actionable**: Provide pseudo code suggestions, not full implementations
3. **Be selective**: Only mention files where there is an actual concern — never list files just for inventory
4. **Be balanced**: Acknowledge good patterns, not just issues
5. **Be thorough**: Read the entire diff, don't skim
6. **Context matters**: Consider the JIRA ticket requirements throughout
7. **Think like a user**: How will this affect end users?
8. **Verify claims**: Don't assume—read the actual code
9. **Cross-squad awareness**: When cross-squad = yes, always load `.cursor/docs/ep_files.md` before writing the Cross-Squad Impact section
