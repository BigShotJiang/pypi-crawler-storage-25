---
name: write-tests
description: Write RSpec and/or Swagger test cases for changed code in the current branch. Use when the user asks to write tests, add test coverage, generate specs, or write test cases.
---

# Write Tests

## Step 1: Determine scope

Run git diff to find changed files (excluding docs):

```bash
git diff $(git merge-base HEAD origin/main) HEAD --name-only -- ':(exclude)CLAUDE.md' ':(exclude)*.md'
```

Then read the relevant changed source files to understand what needs testing.

## Step 2: Ask which tests to write

Use `AskQuestion` (allow_multiple: true) with options:
- **RSpec** – unit/integration specs
- **Swagger** – request specs for API documentation

## Step 3: Ask for reference specs

Before writing, ask: "Any specific existing spec file you'd like me to follow as a reference?" If yes, read it. Otherwise, find a similar spec in `spec/` near the files being tested and use it as a pattern guide.

## Step 4: Write the tests

### RSpec
- Mirror the file path: `app/actors/foo/bar.rb` → `spec/actors/foo/bar_spec.rb`
- Follow patterns from reference/nearby specs: `subject`, `let`, `create(factory)`, `include_context`, shared examples
- Use `described_class.call(...)` for actors/services
- Cover: happy path, failure paths, edge cases, side effects
- Use `expect(subject).to be_success / be_failure` for service objects

### Swagger (request specs)
- Place in `spec/requests/` or `spec/swagger/` matching existing convention
- Use existing swagger helper/shared contexts from nearby specs
- Cover: 200, 4xx responses with example payloads

## Key rules
- Do not invent factories every time— check `spec/factories/` or use existing `create(:name)` calls from nearby specs. Feel free to create, if necessary
- Match indentation, style, and shared context usage of reference specs
- If scope is large, confirm with user which files to prioritize
