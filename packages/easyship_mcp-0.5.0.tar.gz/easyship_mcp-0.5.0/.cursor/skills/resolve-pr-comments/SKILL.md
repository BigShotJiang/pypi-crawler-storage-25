---
name: resolve-pr-comments
description: >-
  Resolve, fix, or address PR review comments by critically evaluating each comment, asking clarifying questions, and applying targeted fixes with updated tests. Use when the user asks to resolve PR comments, fix reviewer feedback, address review suggestions, or respond to PR review issues.
---

# Resolve PR Comments

## Before You Start

Ask these questions **before touching any code**:

**1. Which comments to resolve?**  
Use AskQuestion to present:
- All open comments
- Only suggestions
- Only issues / bugs
- Comments from a specific reviewer (ask for their name)

**2. Research direction**  
Ask: *"Any particular direction you'd like the research & fix to go in?"* (e.g., performance, simplicity, consistency with existing patterns). Note the answer — it guides all decisions.

## Fetching Context

```bash
gh pr view <PR_NUMBER>                 # PR description, files, comments
acli jira workitem view <ISSUE_KEY>    # Ticket scope (if Jira key is in PR)
```

Use the Jira ticket to understand **intended scope** before evaluating comments.

## Per-Comment Workflow

Work through each comment one at a time:

### Step 1 — Evaluate first, fix second

Before writing any code, ask yourself:
- Is this concern actually valid given the PR scope and Jira ticket?
- Is the suggestion consistent with the existing codebase patterns?
- Could fixing this introduce unintended side effects?

If the comment is **vague, imprecise, or lacks enough detail** to act on safely, **ask the reviewer (or user) a clarifying question** before proceeding. Do not guess.

### Step 2 — Decide: fix or push back

| Situation | Action |
|-----------|--------|
| Valid, clear, in-scope concern | Fix it |
| Valid but out of scope | Flag it; ask user if they want to include it |
| Unclear / needs more context | Ask a targeted clarifying question |
| Not a valid concern | Explain why and skip (with user confirmation) |

### Step 3 — Fix

Apply the minimal change that addresses the comment. Follow the direction provided in the pre-start question. Do not refactor unrelated code.

### Step 4 — Tests

For every file changed:
1. Find the corresponding spec file (`spec/` mirror of `app/`).
2. Update existing tests that cover the changed behaviour.
3. If no tests exist for the changed path, add them.
4. Run:

```bash
RAILS_ENV=test bundle exec rspec <spec_file_path>
```

All specs must pass before moving to the next comment.

## Rules

- Never fix multiple comments in one go without pausing to evaluate each.
- Never skip the test step.
- Always confirm with the user before skipping or pushing back on a comment.
- **Never commit or push anything** — once fixes and tests pass, present the changes and ask the user for explicit approval before committing.
