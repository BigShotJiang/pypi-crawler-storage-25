## Summary

- Describe the change and why it is needed.

## Validation

- [ ] Tests run locally (or explain why not)
- [ ] Relevant bakeoff smoke/full checks completed
- [ ] README or inline project guidance updated when behavior changed

## Bake-off / Corpus Reviewer Checklist

Complete when this PR changes corpus/spec/threshold behavior:

- [ ] New adversarial cases included where behavior changed
- [ ] Benign counterexamples included where relevant
- [ ] Threshold change includes explicit justification
- [ ] Baseline impact recorded (run artifact path or diff report)
- [ ] `bench/results/*` artifacts or references updated to match the new contract
