# LLM Input Hardening

This site covers the release-facing parts of the project:

- what the package does
- how to install and call it
- which policy preset to use
- how to integrate it into gateways and application code
- where the security boundaries are

Research notes, draft writing, and evaluation machinery stay in the repository, but they are intentionally out of the default docs path.

## Start here

- [Overview](overview.md)
- [Installation](installation.md)
- [Quickstart](quickstart.md)
- [Policies](policies/presets.md)
- [Python API](api/python.md)
