# Policy Presets

```mermaid
flowchart LR
    A["Input Context"] --> B{"User chat text?"}
    B -- "yes" --> C["balanced_chat"]
    B -- "no (tool args / high risk)" --> D["strict_exec"]
    B -- "source text / code blocks" --> E["code_mode"]
```

## Unicode behavior matrix

| Class / Behavior | `balanced_chat` | `strict_exec` |
|---|---|---|
| Normalization | NFC | NFKC |
| Bidi controls | remove | remove |
| C0/C1 controls (`\n`, `\t` excepted) | remove | remove |
| Known junk invisibles (ZWSP, BOM, WORD JOINER) | remove | remove |
| ZWJ/ZWNJ | preserve | remove |
| Emoji variation selectors | preserve | remove |
| Tag characters | preserve | remove |
| Base64-like flag | yes | yes |
| High entropy flag | yes | yes |
| High combining ratio flag | yes | yes |
| Confusable mixed-script flag | yes | yes |

`code_mode` uses source-text defaults: NFC, no whitespace tidy, strict default-ignorable stripping, and confusable backend defaulting to `confusable_homoglyphs`.

Full matrix (strict/balanced/permissive + code mode): [Policy behaviour matrix](matrix.md).

## Backward-compatible aliases

- `balanced` -> `balanced_chat`
- `strict` -> `strict_exec`
- `code` -> `code_mode`

## Profile guidance

- `strict_exec`: identifier/tool-argument profile.
- `balanced_chat`: default free-text profile.
- `preserve`: lowest-touch free-text profile when formatting fidelity matters.
