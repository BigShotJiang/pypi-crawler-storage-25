# Installation

Install the base package:

```bash
pip install llm-input-hardening
```

Optional extras:

- `security`: `confusable_homoglyphs` backend for stronger confusable detection
- `ftfy`: pre-sanitize text repair

Examples:

```bash
pip install "llm-input-hardening[security]"
pip install "llm-input-hardening[ftfy]"
```

## From source

```bash
uv sync --all-extras
uv run maturin develop --release
```
