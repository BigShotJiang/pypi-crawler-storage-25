# Evaluation: Classifier Lift

This repository includes an evaluation-only script to measure whether deterministic sanitization improves a simple moderation-style detector.

Run:

```bash
python bench/run_classifier_lift.py --out bench/results/classifier_lift.json
```

Method:
- run lexical moderation classifier on raw input (`before`)
- sanitize input (`balanced_chat`)
- run the same classifier on sanitized output (`after`)
- compare detection rates across obfuscation corpus samples

Latest local run (`bench/results/classifier_lift.json`):
- before detection rate: `0.4286`
- after detection rate: `0.5714`
- delta: `+0.1429`

This is an experiment only. Moderation is not part of the core library.
