# Report schema

This project returns a structured report for every sanitization call.

The schema is **versioned** so applications can safely parse and evolve with the library.

---

## Top-level fields

- `report_version` (int): schema version (currently `1`)
- `policy` (str): effective policy name (e.g. `"balanced"`)
- `normalization` (str): effective normalization (e.g. `"NFC"`, `"NFKC"`)
- `changed` (bool): whether output differs from input
- `removed_counts` (dict[str, int]): counts by removal category
- `flagged_counts` (dict[str, int]): counts by flag type
- `spans` (list[SpanEvent]): present for every call; populated only when `return_spans=True`
- `stats` (dict[str, Any]): additional measurements (see below)

---

## removed_counts keys

These keys are stable and may be extended over time:

- `carriage_return`: removed `\r` characters
- `bidi_control`: removed bidi control codepoints (visual spoofing / hiding)
- `junk_invisible`: removed explicit “junk invisible” codepoints (ZWSP, WORD JOINER, BOM)
- `control_or_format`: removed disallowed `Control`/`Format` characters (except `\n`, `\t`)
- `default_ignorable`: removed Unicode Default-Ignorable code points (joiners, variation selectors, tags, etc.)
- `whitespace_tidy`: whitespace changes made by tidying (count is a coarse indicator)

Keep keys stable. Prefer adding new keys over changing meanings.

---

## flagged_counts keys

Flags are signals; they do not necessarily imply an input should be rejected.

- `base64ish_blob`: the (trimmed) output text looks like a base64 payload
- `high_entropy`: Shannon entropy over the first 2,000 characters exceeds a threshold
- `high_combining_ratio`: combining marks exceed a ratio threshold
- `hex_blob`: long hex-like payload shape
- `mixed_script_word`: at least one word mixes scripts (Latin/Cyrillic/Greek)
- `confusable_mixed_script`: mixed-script homoglyph signal from the optional confusable backend

---

## stats

Current keys:
- `ascii_fast_path` (bool): present when the fast-path was used
- `normalized_changed` (bool): whether Unicode normalization changed the input
- `combining_ratio` (float): combining mark ratio (0–1)
- `base64ish` (bool): base64ish detector result
- `entropy_2000` (float): Shannon entropy over the first 2,000 characters
- `confusables_backend` (str): backend name when confusable checks are enabled
- `confusables_available` (bool): whether the backend import succeeded
- `confusables_mixed_script` (bool): backend mixed-script signal
- `confusables_dangerous` (bool): backend dangerous/confusable signal
- `confusable_count` (int): backend-reported confusable character count
- `mixed_script_word_count` (int): number of mixed-script words detected
- `mixed_script_words` (list[str]): sample mixed-script words
- `confusables_error` (str): backend error text when detection fails
- `hexbish` (bool): hex-like detector result
- `entropy_window_max` (float): max entropy over sliding windows
- `default_ignorable_removed` (int): total removed by the Python default-ignorable pass
- `default_ignorable_removed_joiner` (int): removed joiners (`ZWNJ`, `ZWJ`)
- `default_ignorable_removed_variation_selector` (int): removed variation selectors
- `default_ignorable_removed_tag` (int): removed Unicode tag characters
- `default_ignorable_removed_other` (int): removed other default-ignorables

---

## spans (SpanEvent)

Each span event describes an observed removal or flag at a point in the scan.

Shape:

```json
{
  "kind": "removed",
  "reason": "bidi_control",
  "start": 10,
  "end": 13,
  "detail": "U+202E"
}
```

Rules:
- `kind` is `"removed"` or `"flag"`.
- `reason` matches the keys used in `removed_counts` / `flagged_counts`.
- `detail` contains additional context (usually a `U+XXXX` codepoint).
- `start/end` are **UTF-8 byte indices into the string after normalization** (the exact string that is scanned internally).
  - If `stats.normalized_changed` is false, these byte indices also match the original input string.

---

## Example report

```json
{
  "report_version": 1,
  "policy": "balanced",
  "normalization": "NFC",
  "changed": true,
  "removed_counts": {"bidi_control": 1, "junk_invisible": 1},
  "flagged_counts": {"base64ish_blob": 1},
  "spans": [],
  "stats": {"normalized_changed": false, "base64ish": true, "entropy_2000": 4.2, "combining_ratio": 0.0}
}
```
