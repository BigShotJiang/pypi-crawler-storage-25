# Integrations

This project is most useful when it runs **automatically** on every inbound user input.

---

## FastAPI / Starlette middleware

Recommended behavior:
- Parse JSON body
- If a configured field is present (default `prompt` or `input`), sanitize it
- Replace the body so downstream handlers see only sanitized text
- Attach metadata headers so downstream services and logs can see what happened

Example (pseudo-code):

```python
from fastapi import FastAPI
from llm_input_hardening.middleware import StarlettePromptSanitizerMiddleware

app = FastAPI()
app.add_middleware(
    StarlettePromptSanitizerMiddleware,
    field="prompt",
    policy="balanced",
    limit_tokens=128_000,
)
```

### Request mutation semantics

The middleware:
- only runs for `Content-Type: application/json`
- only mutates requests where `body[field]` is a string
- replaces `body[field]` with the sanitized string
- adds response headers:
  - `x-sanitize-changed: true|false`
  - `x-tokens-before: <int>`
  - `x-tokens-after: <int>`

---

## LangChain

Where to plug in:
- before you format prompt templates
- before you append user inputs to memory
- before tool/function argument strings are passed to an LLM

Pattern:

```python
clean, report = sanitize(user_text)
chain.invoke({"input": clean})
```

Enforcement pattern:

```python
from llm_input_hardening import sanitize_and_decide

clean, report, decision = sanitize_and_decide(
    user_text,
    sanitize_policy="strict",
    confusables_backend="confusable_homoglyphs",
)
if decision["action"] != "allow":
    # route to human review / challenge flow
    ...
```

---

## Tool calling / function calling

Sanitize *every* untrusted string:
- user instructions
- retrieved documents (indirect injection risk)
- tool arguments

For nested structures, implement `sanitize_json(obj)` to recursively sanitize string fields.

## RAG warning (retrieved text)

If you use retrieval, treat retrieved text as **untrusted**:
- sanitize it before it enters the prompt
- consider separate policies/thresholds for retrieved sources
- log flags by document source to find compromised content
