# Pipeline (Step by Step)

1. Optional text repair (`use_ftfy=True`).
2. Unicode normalization (preset + optional override).
3. Character filtering (bidi, control chars, known invisibles).
4. Optional aggressive Default-Ignorable stripping (`strict_exec`).
5. Signal extraction (entropy, base64-like, combining ratio, confusables).
6. Stable report assembly with reason codes.

## Result

Each call returns:
- sanitized text
- structured `SanitizeReport` for logging, metrics, and enforcement policy decisions
