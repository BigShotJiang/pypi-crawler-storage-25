# LinkedIn Draft

![Layered architecture](../assets/layered_architecture.svg)

## Hook

We’re building safety systems for probabilistic machines using more probabilistic machines.  
What if the most reliable guardrails aren’t AI at all?

## Technical breakdown

In `llm-input-hardening`, we treat text integrity as a deterministic boundary:
- normalize Unicode consistently
- remove bidi/control and invisible obfuscation
- preserve multilingual fidelity in `balanced_chat`
- emit stable reason codes for observability

Then we hand cleaner text to semantic policy layers (moderation, rails, classifiers).

## Repo

https://github.com/davidwebstar34/llm-input-hardening

## Invite discussion

How are you separating deterministic preprocessing from probabilistic safety layers in production LLM systems?
