# You Don’t Reduce Uncertainty by Adding More Probability

## Draft

LLM safety stacks increasingly rely on probabilistic layers: moderation models, policy classifiers, and behavior heuristics. These are useful, but they often run on already-ambiguous text.

The result: probabilistic systems are asked to interpret payloads that deterministic preprocessing could have normalized or stripped first.

## Guardrail landscape

- OpenAI moderation and policy tooling
- Anthropic constitutional and policy-guided controls
- NVIDIA NeMo Guardrails orchestration and policy rails

All of these systems are valuable. None are substitutes for deterministic text integrity at the entry boundary.

## The probabilistic stacking problem

If each probabilistic layer has edge-case uncertainty, stacking them does not eliminate uncertainty; it can compound latency and operational cost while preserving bypass paths in malformed text.

## Deterministic text integrity layer

`llm-input-hardening` is positioned as a deterministic first layer:
- canonical normalization
- invisible/control character removal
- obfuscation signal reporting with stable reason codes

It does not do semantic moderation.

![Layered architecture](../assets/layered_architecture.svg)

## Real obfuscation examples

![Before and after obfuscation cleanup](../assets/obfuscation_before_after.svg)

## Where deterministic stops

Deterministic text integrity cannot decide whether a user’s request is malicious in meaning. Semantic policy layers are still required for intent and outcome control.

## Why both layers are required

1. Deterministic layer: remove character-level ambiguity early and cheaply.
2. Probabilistic layer: evaluate intent/policy on cleaner text.

## Code snippet (`sanitize_and_decide`)

```python
from llm_input_hardening import sanitize_and_decide

clean, report, decision = sanitize_and_decide(
    user_text,
    sanitize_policy="balanced_chat",
    confusables_backend="confusable_homoglyphs",
)
if decision["action"] == "reject":
    raise ValueError({"reason_codes": decision["reason_codes"]})
```
