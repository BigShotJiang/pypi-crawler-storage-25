# How it works

This page describes the **algorithmic pipeline**, **invariants**, and **threat rationale** for the sanitizer shipped in this repo.

---

## Design goals

1. **Deterministic**: same input + policy → same output + report.
2. **Streaming-friendly**: linear scan over the text where possible.
3. **Low overhead**: safe to run on every user request.
4. **Explicit scope**: remove stealth Unicode aggressively, while leaving semantic text interpretation out of scope.
5. **Actionable reporting**: every change is counted; suspicious patterns are flagged.

---

## Pipeline

### 1) Optional “text repair”

If enabled (`use_ftfy=True`), apply `ftfy.fix_text()` to fix:
- mojibake
- broken unicode sequences
- mis-decoded text

This step is optional because it can meaningfully alter user input. It should be opt-in or policy-controlled.

### 2) Newline normalization

Normalize Windows newlines so templating and downstream rules are stable:

- `\r\n` → `\n` (by removing `\r`)
- `\r` → removed

**Invariant**: output contains no `\r`.

### 3) Unicode normalization (policy-controlled)

- `NFC`: canonical composition (default safe).
- `NFKC`: compatibility composition (stricter; can fold “lookalike” characters).

**Why it matters**: attackers can use compatibility characters, full-width variants, and odd combining sequences to bypass filters or create ambiguous prompts.

### 4) Character filtering

Perform a single pass over Unicode scalar values:

Remove (policy-controlled):
- **Bidi controls** (visual spoofing / hiding)
- **Junk invisibles** (ZWSP/BOM/WORD JOINER; explicit library list)
- **Control / format characters** except allowed controls (`\n`, `\t`)
- **Default-Ignorable code points** (including joiners, variation selectors, and tags)

Preserve (by default):
- common whitespace (space, newline, tab)

**Invariant**: with the preset policies, output contains:
- no bidi control characters listed by the library
- no “junk invisibles” listed by the library
- no Default-Ignorable code points listed by the library
- no `char::is_control()` characters except `\n` and `\t`

### 5) Optional whitespace tidying

When enabled:
- collapse repeated spaces
- trim leading/trailing whitespace
- trim spaces around newlines
- strip trailing newlines

This is useful when you inject user input into prompt templates and want stable formatting.

### 6) Flags / signals (heuristics)

Flags do **not** necessarily modify output. They are signals for application-level handling:

Examples:
- `base64ish_blob`: base64-alphabet text with padding/length properties
- `high_entropy`: high Shannon entropy in the first 2,000 characters
- `high_combining_ratio`: unusually high combining-mark ratio
- `hex_blob`: long hex-looking payload
- `confusable_mixed_script`: optional mixed-script homoglyph signal via `confusable_homoglyphs`

### 7) Report generation

A structured report is returned containing:
- `changed`
- `removed_counts`
- `flagged_counts`
- optionally spans so you can highlight exactly what was removed and where.
- `stats` with additional measurements (e.g., entropy and combining ratio).

See [Report schema](report-schema.md).

---

## Complexity and performance notes

- Unicode normalization and filtering are **O(n)** in the number of characters.
- Whitespace tidying is **O(n)**.
- Entropy is computed over only the first 2,000 characters (bounded).
- The implementation includes an ASCII fast-path when it can prove no changes are needed.

This is intended to be cheap enough to run on every request, not just at “ingress”.

---

## Language-safety notes

- **ZWJ/ZWNJ are removed** as part of Default-Ignorable stripping.
- Variation selectors and tag characters are removed.
- **Combining marks are not removed** by default; the library only measures and flags suspicious ratios.
- **NFKC can distort text** (it is a compatibility normalization). Use `strict` when you can tolerate folding in exchange for stronger canonicalization.

---

## Recommended application patterns

- Always run sanitization on **untrusted user input** before it reaches the model.
- Treat `flagged_counts` as a decision signal:
  - log it
  - rate-limit
  - require CAPTCHA / auth step
  - reject or route to review
- Use `sanitize_and_decide()` when you want a built-in `allow` / `quarantine` / `reject` decision layer.
- Keep “strict” mode for high-risk contexts (tool execution, code generation, sensitive data).

## Determinism guarantees

For a given version of this library:
- the sanitizer is deterministic (no randomness)
- the output depends only on `(text, policy, normalization override, tidy override, use_ftfy)`
- `use_ftfy=True` is deterministic given a fixed `ftfy` version
