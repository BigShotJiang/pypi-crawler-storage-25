# References

## Mindgard (Apr 29, 2025)

- [Outsmarting AI Guardrails: Hidden Text and Adversarial Prompts](https://mindgard.ai/blog/outsmarting-ai-guardrails-hidden-text-and-adversarial-prompts)
  - Shows how invisible Unicode and prompt obfuscation can bypass naive guardrails, motivating deterministic text cleanup before semantic controls.

## Dynamo AI (Apr 28, 2025)

- [How to Evaluate LLM Guardrails](https://www.getdynamo.ai/post/how-to-evaluate-llm-guardrails)
  - Discusses operational cost/latency tradeoffs for guardrail stacks and supports placing low-latency deterministic layers early in the pipeline.
