# Security notes

## Threat model (what we’re defending against)

This library targets *text-shaping and ambiguity attacks* against LLM applications, including:

- **Unicode obfuscation**: bidi controls and “invisible” codepoints that can hide or reorder text visually.
- **Prompt boundary corruption**: control characters and newline quirks that break assumptions in prompt templates.
- **Encoded payload smuggling**: high-entropy or base64-ish blobs that are unlikely to be normal language and may carry hidden instructions/data.
- **Indirect prompt injection** (supporting control): retrieved documents can contain the same ambiguity tricks as user text.

It does **not** attempt to solve the semantic problem of “will the model follow malicious instructions”.

## What this library does well

- Removes hidden/ambiguous characters that can:
  - hide instructions visually (bidi controls)
  - alter tokenization invisibly (zero-width junk)
  - cause prompt template escapes via control characters
- Normalizes Unicode to reduce confusable or compatibility bypasses
- Emits flags for suspicious payloads to support blocking/monitoring

## What this library does NOT do

- It does not “solve” prompt injection.
- It does not ensure the model follows your system/developer instructions.
- It does not sandbox tools.
- It does not prevent indirect prompt injection unless you sanitize retrieved text too.

## Recommended defense-in-depth

- Strong system prompts + least privilege tool access
- Allowlist-based tool routing
- Retrieval filtering + citations
- Output validation (schemas, allowlists)
- Logging/monitoring of flags for abuse detection
- Human review for high-impact actions

## Recommended production patterns

- Sanitize **all inbound strings**, not just the “prompt” field:
  - user messages
  - retrieved documents (RAG)
  - tool/function-call string arguments
- Treat `flagged_counts` and `removed_counts` as observability signals:
  - log + aggregate by route / tenant / IP
  - alert on spikes
  - optionally reject/step-up auth on suspicious patterns
- Use `strict` (NFKC) only when you can tolerate text distortion; prefer `balanced` for normal chat UX.
- For spoof-prone workflows (identity, payments, admin actions), enable `confusables_backend="confusable_homoglyphs"` and enforce `allow/quarantine/reject` decisions.

## Confusable classification notes

- Confusable analysis is best-effort and reports a UTS #39-aligned `confusables_restriction_level`.
- Mixed-script detection is exposed as telemetry (`confusables_mixed_script`, `mixed_script_words`).
- Skeletons are analysis-only and are not stored in reports.
