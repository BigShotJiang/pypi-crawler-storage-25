# Report Schema

```mermaid
classDiagram
    class SanitizeReport {
      int report_version
      string policy
      string normalization
      bool changed
      map removed_counts
      map flagged_counts
      map reason_codes
      list spans
      map stats
    }
```

## Stability contract

- `report_version` is schema-versioned.
- `reason_codes` use stable identifiers.
- new stats keys can be added without breaking existing keys.

## Canonical reason code examples

- `IH001_BIDI_CONTROL`
- `IH002_DEFAULT_IGNORABLE`
- `IH010_HIGH_ENTROPY`
- `IH020_CONFUSABLE_MIXED_SCRIPT`
- `IH030_BASE64_LIKE_PAYLOAD`

## Enforcement linkage

`decide_enforcement()` consumes sanitize counts but emits stable `reason_codes` rather than ad-hoc strings.
