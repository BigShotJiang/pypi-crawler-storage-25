# Benchmarks

Run:

```bash
make bench
make bench-plots
make bakeoff
make bakeoff-schema
make bakeoff-diff
make bakeoff-diff-assert
make microbench
# optional: tokenizer-accurate token stability mode
# uv run --with llm-guard --with confusable-homoglyphs --with tiktoken \
#   python bench/run_bakeoff.py --tokenizer tiktoken --tokenizer-model o200k_base
```

Primary performance outputs:
- per-case latency p50/p95 (`bench/run_benchmarks.py`)
- throughput MiB/s
- bake-off detection quality across obfuscation corpus

The bake-off summary includes:
- `micro_precision` / `micro_recall`
- `postcondition_pass_rate`
- `benign_changed_rate`
- confidence intervals (`wilson_lo` / `wilson_hi`)
- token stability (`token_delta`) and invariance ratio
- processing time p50/p95 (ms)
- microbench throughput/latency output (`bench/run_microbench.py`, pyperf-backed)
