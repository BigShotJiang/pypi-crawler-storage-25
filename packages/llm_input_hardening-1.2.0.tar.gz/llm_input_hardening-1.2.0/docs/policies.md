# Policies

Policies define *what to remove*, *what to normalize*, and *what to flag*.

---

## Presets (recommended)

The library ships with three presets implemented in Rust:

| Policy | Normalization | Removes | Whitespace tidy | Flags enabled |
|---|---|---|---:|---|
| `preserve` | NFC | bidi + junk invisibles + disallowed controls/formats + default-ignorables | no | entropy + combining ratio + mixed-script |
| `balanced` | NFC | bidi + junk invisibles + disallowed controls/formats + default-ignorables | yes | base64-ish + hex + entropy + combining ratio + mixed-script |
| `strict` | NFKC | bidi + junk invisibles + disallowed controls/formats + default-ignorables | yes | base64-ish + hex + entropy + combining ratio + mixed-script |

Notes:
- All presets remove bidi controls and the library’s “junk invisibles” list.
- All presets remove `char::is_control()` characters except `\n` and `\t`.
- All presets remove Unicode Default-Ignorable code points (including ZWJ/ZWNJ, variation selectors, and tag chars).
- `strict` uses **NFKC**: this can change text meaning/appearance in some languages. Use it for high-risk contexts.

---

## Per-call overrides (Python)

`sanitize()` exposes limited overrides without defining a custom policy:

- `normalization="NFC" | "NFKC"`: override the preset’s normalization.
- `tidy_whitespace=True | False`: override the preset’s whitespace behavior.
- `return_spans=True`: include span events in the report (see report schema).
- `use_ftfy=True`: run `ftfy.fix_text()` before sanitization (requires extra dependency).
- `confusables_backend="heuristic" | "confusable_homoglyphs"`: mixed-script/confusable detection backend. `heuristic` is default; `confusable_homoglyphs` requires optional `security` extra.

---

## Heuristic thresholds (current)

These are part of the current implementation and may evolve; the report schema is versioned so you can detect changes.

- `base64ish_blob`:
  - triggers when the *trimmed* text is at least 64 characters, length is divisible by 4, and only uses the base64 alphabet plus `=`.
- `high_entropy`:
  - computes Shannon entropy over the first 2,000 characters and triggers when entropy > 5.0 and total length > 200.
- `high_combining_ratio`:
  - counts combining marks (common combining ranges) and triggers when ratio > 0.20 and total length > 40.
- `hex_blob`:
  - triggers when trimmed text length is >= 64, even-length, and hexadecimal-only.

## Practical advice

- Start with `balanced` for most chat-style user input.
- Use `strict` for high-risk contexts (tool execution, code generation, sensitive operations).
- Use `preserve` when you care about formatting, but still want to remove dangerous control and spoofing characters.

### Recommended defaults by flow

| Flow | Recommended policy | Why |
|---|---|---|
| Normal chat UX | `balanced` | Keeps user text mostly intact while removing high-risk Unicode/control ambiguity. |
| Tool arguments / function calls | `strict` | NFKC normalization reduces compatibility bypasses before high-impact execution. |
| Retrieved RAG text before prompt assembly | `balanced` (or `strict` for high-risk sources) | Preserves readability by default while still removing spoofing/invisibles. |
| Security-sensitive actions (payments, admin ops) | `strict` + confusables backend | Favors safety and catches mixed-script homoglyph tricks. |

If you enable strict-mode pathways in production, monitor false positives and language distortion impact by locale.
