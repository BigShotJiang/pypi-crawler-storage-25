use serde::Deserialize;
use std::collections::HashMap;
use std::sync::OnceLock;

/// Sanitization policy preset.
#[derive(Debug, Clone)]
pub struct Policy {
    pub name: &'static str,
    pub normalize: Normalization,
    pub remove_bidi: bool,
    pub remove_junk_invisibles: bool,
    pub remove_other_controls: bool,
    pub remove_default_ignorables: bool,
    pub tidy_whitespace: bool,
    pub flag_default_ignorables: bool,
    pub flag_base64ish: bool,
    pub flag_combining_abuse: bool,
}

/// Unicode normalization mode.
#[derive(Debug, Clone, Copy)]
pub enum Normalization {
    Nfc,
    Nfkc,
}

#[derive(Debug, Deserialize)]
struct PolicyRegistry {
    aliases: HashMap<String, String>,
    presets: HashMap<String, PolicySpec>,
}

#[derive(Debug, Deserialize)]
struct PolicySpec {
    normalization: String,
    remove_bidi: bool,
    remove_junk_invisibles: bool,
    remove_other_controls: bool,
    remove_default_ignorables: bool,
    tidy_whitespace: bool,
    flag_default_ignorables: bool,
    flag_base64ish: bool,
    flag_combining_abuse: bool,
}

fn registry() -> &'static PolicyRegistry {
    static REGISTRY: OnceLock<PolicyRegistry> = OnceLock::new();
    REGISTRY.get_or_init(|| {
        serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/python/llm_input_hardening/policy_registry.json"
        )))
        .expect("policy registry must be valid JSON")
    })
}

fn normalization_from_string(value: &str) -> Option<Normalization> {
    match value {
        "NFC" => Some(Normalization::Nfc),
        "NFKC" => Some(Normalization::Nfkc),
        _ => None,
    }
}

fn canonical_name(value: &str) -> Option<&'static str> {
    match value {
        "preserve" => Some("preserve"),
        "balanced_chat" => Some("balanced_chat"),
        "strict_exec" => Some("strict_exec"),
        "code_mode" => Some("code_mode"),
        _ => None,
    }
}

/// Get a built-in policy preset by name.
pub fn get_policy(name: &str) -> Option<Policy> {
    let registry = registry();
    let canonical = registry
        .aliases
        .get(name)
        .map(String::as_str)
        .unwrap_or(name);
    let spec = registry.presets.get(canonical)?;

    Some(Policy {
        name: canonical_name(canonical)?,
        normalize: normalization_from_string(&spec.normalization)?,
        remove_bidi: spec.remove_bidi,
        remove_junk_invisibles: spec.remove_junk_invisibles,
        remove_other_controls: spec.remove_other_controls,
        remove_default_ignorables: spec.remove_default_ignorables,
        tidy_whitespace: spec.tidy_whitespace,
        flag_default_ignorables: spec.flag_default_ignorables,
        flag_base64ish: spec.flag_base64ish,
        flag_combining_abuse: spec.flag_combining_abuse,
    })
}
