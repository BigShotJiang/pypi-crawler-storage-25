//! Multilingual-safe LLM input hardening.
//!
//! This crate implements a deterministic, low-overhead sanitizer intended for use
//! on untrusted text before it is embedded into LLM prompts or templates.
//!
//! The core entrypoint is [`sanitize_inner`]. When built with the `python` feature,
//! the sanitizer is exposed as a Python extension module via PyO3.
#![allow(clippy::useless_conversion)] // PyO3 macro expansion triggers this lint on PyResult paths.

pub mod policy;
pub mod report;

use policy::{get_policy, Normalization};
use report::{SanitizeReport, SpanEvent};

use serde_json::json;
use unicode_normalization::UnicodeNormalization;
#[cfg(feature = "python")]
use {pyo3::exceptions::PyValueError, pyo3::prelude::*, pyo3::types::PyModule, pyo3::Bound};

use std::borrow::Cow;

const BIDI_CODEPOINTS: &[u32] = &[
    0x061C, 0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069,
];

// Must stay sorted for binary_search
const JUNK_INVISIBLES: &[u32] = &[
    0x200B, // ZWSP
    0x2060, // WORD JOINER
    0xFEFF, // BOM
];

const PRESERVE_JOINERS: &[u32] = &[
    0x200C, // ZWNJ
    0x200D, // ZWJ
];

const DEFAULT_IGNORABLE_RANGES: &[(u32, u32)] = &[
    (0x00AD, 0x00AD),
    (0x034F, 0x034F),
    (0x061C, 0x061C),
    (0x115F, 0x1160),
    (0x17B4, 0x17B5),
    (0x180B, 0x180F),
    (0x200B, 0x200F),
    (0x202A, 0x202E),
    (0x2060, 0x206F),
    (0x3164, 0x3164),
    (0xFE00, 0xFE0F),
    (0xFEFF, 0xFEFF),
    (0xFFA0, 0xFFA0),
    (0xFFF0, 0xFFF8),
    (0x1BCA0, 0x1BCA3),
    (0x1D173, 0x1D17A),
    (0xE0000, 0xE0001),
    (0xE0002, 0xE001F),
    (0xE0020, 0xE007F),
    (0xE0080, 0xE00FF),
    (0xE0100, 0xE01EF),
];

fn is_bidi(cp: u32) -> bool {
    BIDI_CODEPOINTS.binary_search(&cp).is_ok()
}
fn is_junk_invisible(cp: u32) -> bool {
    JUNK_INVISIBLES.binary_search(&cp).is_ok()
}
fn is_preserve_joiner(cp: u32) -> bool {
    PRESERVE_JOINERS.binary_search(&cp).is_ok()
}
fn in_ranges(cp: u32, ranges: &[(u32, u32)]) -> bool {
    ranges
        .iter()
        .any(|(start, end)| (*start..=*end).contains(&cp))
}
fn is_default_ignorable(cp: u32) -> bool {
    in_ranges(cp, DEFAULT_IGNORABLE_RANGES)
}
fn is_variation_selector(cp: u32) -> bool {
    (0xFE00..=0xFE0F).contains(&cp) || (0xE0100..=0xE01EF).contains(&cp)
}
fn is_tag_char(cp: u32) -> bool {
    (0xE0000..=0xE007F).contains(&cp) || (0xE0080..=0xE00FF).contains(&cp)
}

fn is_allowed_control(ch: char) -> bool {
    ch == '\n' || ch == '\t'
}

fn is_control_or_format(ch: char) -> bool {
    // Cc or Cf
    matches!(
        unicode_general_category::get_general_category(ch),
        unicode_general_category::GeneralCategory::Control
            | unicode_general_category::GeneralCategory::Format
    )
}

// dependency-free general category helper:
mod unicode_general_category {
    // Tiny mapping via std unicode category? Rust std doesn't expose GC directly.
    // We'll approximate using `char::is_control()` for Cc and a Cf heuristic.
    // If you need full Unicode General Category coverage, switch to a dedicated crate.
    #[derive(Debug, Clone, Copy)]
    pub enum GeneralCategory {
        Control,
        Format,
        Other,
    }

    pub fn get_general_category(ch: char) -> GeneralCategory {
        if ch.is_control() {
            return GeneralCategory::Control;
        }
        // Heuristic: treat common “format-ish” ranges as Cf.
        // This is intentionally conservative and paired with explicit lists.
        let cp = ch as u32;
        // common Cf ranges (partial): zero-width, direction marks, variation selectors etc.
        if (0x200B..=0x200F).contains(&cp)
            || (0x202A..=0x202E).contains(&cp)
            || (0x2060..=0x206F).contains(&cp)
        {
            return GeneralCategory::Format;
        }
        GeneralCategory::Other
    }
}

fn normalize_text<'a>(s: &'a str, norm: Normalization) -> Cow<'a, str> {
    match norm {
        Normalization::Nfc => {
            // if already NFC-ish, we still need to allocate; do a cheap compare:
            let normalized: String = s.nfc().collect();
            if normalized == s {
                Cow::Borrowed(s)
            } else {
                Cow::Owned(normalized)
            }
        }
        Normalization::Nfkc => {
            let normalized: String = s.nfkc().collect();
            if normalized == s {
                Cow::Borrowed(s)
            } else {
                Cow::Owned(normalized)
            }
        }
    }
}

fn shannon_entropy(prefix: &str) -> f64 {
    use std::collections::HashMap;
    let mut counts: HashMap<char, usize> = HashMap::new();
    let mut n: usize = 0;
    for ch in prefix.chars() {
        *counts.entry(ch).or_insert(0) += 1;
        n += 1;
    }
    if n == 0 {
        return 0.0;
    }
    let mut ent = 0.0f64;
    for (_k, v) in counts {
        let p = (v as f64) / (n as f64);
        ent -= p * p.ln() / 2f64.ln();
    }
    ent
}

fn looks_base64ish(s: &str) -> bool {
    let t = s.trim();
    if t.len() < 64 {
        return false;
    }
    if !t.len().is_multiple_of(4) {
        return false;
    }
    // simple check: only base64 alphabet + '='
    if !t
        .chars()
        .all(|c| c.is_ascii_alphanumeric() || c == '+' || c == '/' || c == '=')
    {
        return false;
    }
    true
}

fn tidy_whitespace(s: String) -> String {
    // collapse spaces/tabs (not newlines), trim around newlines, strip ends
    // fast-ish manual pass:
    let mut out = String::with_capacity(s.len());
    let mut last_was_space = false;
    let mut last_was_nl = false;

    for ch in s.chars() {
        if ch == ' ' || ch == '\t' {
            if last_was_nl {
                continue;
            } // trim after newline
            if !last_was_space {
                out.push(' ');
                last_was_space = true;
            }
            continue;
        }
        if ch == '\n' {
            // trim space before newline
            if out.ends_with(' ') {
                out.pop();
            }
            out.push('\n');
            last_was_space = false;
            last_was_nl = true;
            continue;
        }
        last_was_space = false;
        last_was_nl = false;
        out.push(ch);
    }

    // trim ends
    while out.starts_with(' ') {
        out.remove(0);
    }
    while out.ends_with(' ') {
        out.pop();
    }
    while out.ends_with('\n') {
        out.pop();
    }

    out
}

fn parse_normalization(name: &str) -> Result<Normalization, String> {
    match name.to_ascii_uppercase().as_str() {
        "NFC" => Ok(Normalization::Nfc),
        "NFKC" => Ok(Normalization::Nfkc),
        _ => Err(format!("unknown normalization: {name}")),
    }
}

/// Sanitize text using a named policy preset.
///
/// Returns the cleaned text and a structured report with removal counts, heuristic flags,
/// and optional span events.
pub fn sanitize_inner(
    text: &str,
    policy_name: &str,
    return_spans: bool,
) -> Result<(String, SanitizeReport), String> {
    sanitize_inner_with_overrides(text, policy_name, None, None, return_spans)
}

fn sanitize_inner_with_overrides(
    text: &str,
    policy_name: &str,
    normalization: Option<Normalization>,
    tidy_override: Option<bool>,
    return_spans: bool,
) -> Result<(String, SanitizeReport), String> {
    let mut pol =
        get_policy(policy_name).ok_or_else(|| format!("unknown policy: {policy_name}"))?;
    if let Some(norm) = normalization {
        pol.normalize = norm;
    }
    if let Some(tidy) = tidy_override {
        pol.tidy_whitespace = tidy;
    }

    // Normalize first
    let normalized = normalize_text(text, pol.normalize);
    let norm_changed = match &normalized {
        Cow::Borrowed(_) => false,
        Cow::Owned(_) => true,
    };
    let scan = normalized.as_ref();

    // ASCII fast-path (no allocations) if no changes likely
    // If pure ASCII and no CR, and policy doesn't tidy whitespace, we can skip.
    let normalization_label = match pol.normalize {
        Normalization::Nfc => "NFC",
        Normalization::Nfkc => "NFKC",
    }
    .to_string();

    if scan.is_ascii() && !scan.contains('\r') && !pol.tidy_whitespace && !norm_changed {
        let rep = SanitizeReport {
            policy: pol.name.to_string(),
            normalization: normalization_label.clone(),
            changed: false,
            stats: json!({"ascii_fast_path": true, "normalized_changed": false}),
            ..Default::default()
        };
        return Ok((scan.to_string(), rep));
    }

    let mut out = String::with_capacity(scan.len());
    let mut rep = SanitizeReport {
        policy: pol.name.to_string(),
        normalization: normalization_label,
        ..Default::default()
    };

    let mut changed = norm_changed;

    // Stats for combining marks
    let mut combining = 0usize;
    let mut total = 0usize;
    let mut default_ignorable_removed = 0usize;
    let mut default_ignorable_removed_joiner = 0usize;
    let mut default_ignorable_removed_variation_selector = 0usize;
    let mut default_ignorable_removed_tag = 0usize;
    let mut default_ignorable_removed_other = 0usize;

    for (i, ch) in scan.char_indices() {
        let cp = ch as u32;

        if ch == '\r' {
            changed = true;
            rep.bump_removed("carriage_return", 1);
            if return_spans {
                rep.spans.push(SpanEvent {
                    kind: "removed".into(),
                    reason: "carriage_return".into(),
                    start: i,
                    end: i + ch.len_utf8(),
                    detail: "U+000D".into(),
                });
            }
            continue;
        }

        if pol.remove_bidi && is_bidi(cp) {
            changed = true;
            rep.bump_removed("bidi_control", 1);
            if return_spans {
                rep.spans.push(SpanEvent {
                    kind: "removed".into(),
                    reason: "bidi_control".into(),
                    start: i,
                    end: i + ch.len_utf8(),
                    detail: format!("U+{cp:04X}"),
                });
            }
            continue;
        }

        if pol.remove_junk_invisibles && is_junk_invisible(cp) {
            changed = true;
            rep.bump_removed("junk_invisible", 1);
            if return_spans {
                rep.spans.push(SpanEvent {
                    kind: "removed".into(),
                    reason: "junk_invisible".into(),
                    start: i,
                    end: i + ch.len_utf8(),
                    detail: format!("U+{cp:04X}"),
                });
            }
            continue;
        }

        if pol.remove_other_controls && is_control_or_format(ch) && !is_allowed_control(ch) {
            if is_preserve_joiner(cp) {
                if !pol.remove_default_ignorables {
                    out.push(ch);
                    total += 1;
                    continue;
                }
            } else {
                changed = true;
                rep.bump_removed("control_or_format", 1);
                if return_spans {
                    rep.spans.push(SpanEvent {
                        kind: "removed".into(),
                        reason: "control_or_format".into(),
                        start: i,
                        end: i + ch.len_utf8(),
                        detail: format!("U+{cp:04X}"),
                    });
                }
                continue;
            }
        }

        if pol.remove_default_ignorables && is_default_ignorable(cp) {
            changed = true;
            default_ignorable_removed += 1;
            if is_preserve_joiner(cp) {
                default_ignorable_removed_joiner += 1;
            } else if is_variation_selector(cp) {
                default_ignorable_removed_variation_selector += 1;
            } else if is_tag_char(cp) {
                default_ignorable_removed_tag += 1;
            } else {
                default_ignorable_removed_other += 1;
            }
            rep.bump_removed("default_ignorable", 1);
            if return_spans {
                rep.spans.push(SpanEvent {
                    kind: "removed".into(),
                    reason: "default_ignorable".into(),
                    start: i,
                    end: i + ch.len_utf8(),
                    detail: format!("U+{cp:04X}"),
                });
            }
            continue;
        }

        if pol.flag_default_ignorables && !is_preserve_joiner(cp) && is_default_ignorable(cp) {
            rep.bump_flagged("default_ignorable", 1);
            if return_spans {
                rep.spans.push(SpanEvent {
                    kind: "flag".into(),
                    reason: "default_ignorable".into(),
                    start: i,
                    end: i + ch.len_utf8(),
                    detail: format!("U+{cp:04X}"),
                });
            }
        }

        // combining marks ratio
        if pol.flag_combining_abuse {
            // Mn/Mc/Me approximation: use unicode_normalization? We'll do a name/category heuristic:
            // simplest: check if char is in combining diacritical marks ranges (not perfect but ok v0.1)
            if (0x0300..=0x036F).contains(&cp)
                || (0x1AB0..=0x1AFF).contains(&cp)
                || (0x1DC0..=0x1DFF).contains(&cp)
            {
                combining += 1;
            }
        }

        out.push(ch);
        total += 1;
    }

    if pol.tidy_whitespace {
        let before = out.clone();
        let after = tidy_whitespace(out);
        if after != before {
            changed = true;
            rep.bump_removed("whitespace_tidy", 1);
        }
        out = after;
    }

    // Flags: base64-ish, entropy, combining ratio
    let mut stats = serde_json::Map::new();
    stats.insert("normalized_changed".into(), json!(norm_changed));
    stats.insert(
        "default_ignorable_removed".into(),
        json!(default_ignorable_removed),
    );
    stats.insert(
        "default_ignorable_removed_joiner".into(),
        json!(default_ignorable_removed_joiner),
    );
    stats.insert(
        "default_ignorable_removed_variation_selector".into(),
        json!(default_ignorable_removed_variation_selector),
    );
    stats.insert(
        "default_ignorable_removed_tag".into(),
        json!(default_ignorable_removed_tag),
    );
    stats.insert(
        "default_ignorable_removed_other".into(),
        json!(default_ignorable_removed_other),
    );
    stats.insert(
        "default_ignorable_stripped".into(),
        json!(pol.remove_default_ignorables),
    );

    if pol.flag_combining_abuse && total > 0 {
        let ratio = (combining as f64) / (total as f64);
        stats.insert("combining_ratio".into(), json!(ratio));
        if ratio > 0.20 && total > 40 {
            rep.bump_flagged("high_combining_ratio", 1);
        }
    }

    if pol.flag_base64ish {
        let b64 = looks_base64ish(&out);
        stats.insert("base64ish".into(), json!(b64));
        if b64 {
            rep.bump_flagged("base64ish_blob", 1);
        }
    }

    let prefix: String = out.chars().take(2000).collect();
    let ent = shannon_entropy(&prefix);
    stats.insert("entropy_2000".into(), json!(ent));
    if ent > 5.0 && out.chars().count() > 200 {
        rep.bump_flagged("high_entropy", 1);
    }

    rep.stats = serde_json::Value::Object(stats);
    rep.changed = changed;

    Ok((out, rep))
}

#[cfg(feature = "python")]
#[allow(clippy::useless_conversion)]
#[pyfunction(signature = (text, policy="balanced_chat", normalization=None, tidy_whitespace=None, return_spans=false))]
fn sanitize(
    py: Python<'_>,
    text: &str,
    policy: &str,
    normalization: Option<&str>,
    tidy_whitespace: Option<bool>,
    return_spans: bool,
) -> PyResult<(String, PyObject)> {
    let norm_override = match normalization {
        Some(n) => Some(parse_normalization(n).map_err(PyValueError::new_err)?),
        None => None,
    };
    let (clean, report) =
        sanitize_inner_with_overrides(text, policy, norm_override, tidy_whitespace, return_spans)
            .map_err(PyValueError::new_err)?;

    let json_str =
        serde_json::to_string(&report).map_err(|e| PyValueError::new_err(e.to_string()))?;
    // convert json -> Python via serde_json string roundtrip (simple v0.1)
    let py_json = py.import("json")?;
    let py_val = py_json.getattr("loads")?.call1((json_str.as_str(),))?;
    py_val.downcast::<pyo3::types::PyDict>()?;
    Ok((clean, py_val.unbind()))
}

#[cfg(feature = "python")]
#[pymodule]
fn _core(_py: Python<'_>, m: &Bound<PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(sanitize, m)?)?;
    Ok(())
}
