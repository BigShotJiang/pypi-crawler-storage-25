from __future__ import annotations

from collections.abc import Mapping
from typing import Any, cast

from ._service import sanitize_text
from .policies import policy_preset, resolve_policy_name
from .reason_codes import reason_code_counts
from .types import SanitizeReport


def _bump_counts(target: dict[str, int], source: Mapping[str, int]) -> None:
    for key, raw_count in source.items():
        count = int(raw_count)
        if count <= 0:
            continue
        target[key] = target.get(key, 0) + count


def sanitize_json(
    obj: Any,
    *,
    policy: str = "balanced_chat",
    return_spans: bool = False,
    normalization: str | None = None,
    tidy_whitespace: bool | None = None,
    use_ftfy: bool = False,
    confusables_backend: str | None = None,
) -> tuple[Any, SanitizeReport]:
    """Recursively sanitize all string leaves in a JSON-like payload.

    The object shape is preserved. Non-string values are returned unchanged.
    """

    canonical_policy = resolve_policy_name(policy)
    preset = policy_preset(canonical_policy)

    removed_counts: dict[str, int] = {}
    flagged_counts: dict[str, int] = {}
    string_leaf_count = 0
    changed_string_leaves = 0

    def walk(node: Any) -> Any:
        nonlocal string_leaf_count, changed_string_leaves

        if isinstance(node, str):
            string_leaf_count += 1
            clean, rep = sanitize_text(
                # Local alias avoids module-import cycles.
                node,
                policy=canonical_policy,
                return_spans=return_spans,
                normalization=normalization,
                tidy_whitespace=tidy_whitespace,
                use_ftfy=use_ftfy,
                confusables_backend=confusables_backend,
            )
            if clean != node:
                changed_string_leaves += 1
            _bump_counts(removed_counts, rep.get("removed_counts", {}))
            _bump_counts(flagged_counts, rep.get("flagged_counts", {}))
            return clean

        if isinstance(node, list):
            return [walk(item) for item in node]

        if isinstance(node, tuple):
            return tuple(walk(item) for item in node)

        if isinstance(node, Mapping):
            # Preserve insertion order for deterministic payload output.
            return {key: walk(value) for key, value in node.items()}

        return node

    clean_obj = walk(obj)

    if normalization is not None:
        norm = normalization
    else:
        norm = preset.normalization

    report: SanitizeReport = {
        "report_version": 1,
        "policy": canonical_policy,
        "normalization": norm,
        "changed": changed_string_leaves > 0,
        "removed_counts": {k: removed_counts[k] for k in sorted(removed_counts)},
        "flagged_counts": {k: flagged_counts[k] for k in sorted(flagged_counts)},
        "reason_codes": reason_code_counts(removed_counts, flagged_counts),
        "spans": [],
        "stats": {
            "json_string_leaf_count": string_leaf_count,
            "json_changed_string_leaves": changed_string_leaves,
        },
    }
    return clean_obj, cast(SanitizeReport, report)
