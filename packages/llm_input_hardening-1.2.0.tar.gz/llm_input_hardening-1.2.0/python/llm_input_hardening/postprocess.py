from __future__ import annotations

import math
import re
from collections import Counter


_HEX_RE = re.compile(r"^[0-9a-fA-F]+$")


def looks_hex_blob(text: str) -> bool:
    """Heuristic: long even-length, hex-only token (signal only)."""

    t = text.strip()
    if len(t) < 64 or len(t) % 2 != 0:
        return False
    return _HEX_RE.fullmatch(t) is not None


def shannon_entropy(text: str) -> float:
    if not text:
        return 0.0
    counts = Counter(text)
    n = len(text)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


def max_entropy_window(text: str, *, window: int = 256, stride: int = 64) -> float:
    """Compute max entropy over sliding windows (signal only)."""

    if not text:
        return 0.0
    if len(text) <= window:
        return shannon_entropy(text)

    best = 0.0
    stop = len(text) - window + 1
    for i in range(0, stop, stride):
        ent = shannon_entropy(text[i : i + window])
        if ent > best:
            best = ent
    if (len(text) - window) % stride != 0:
        best = max(best, shannon_entropy(text[-window:]))
    return best
