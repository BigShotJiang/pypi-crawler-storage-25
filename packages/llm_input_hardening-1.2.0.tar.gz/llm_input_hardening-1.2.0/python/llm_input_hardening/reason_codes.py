from __future__ import annotations

from typing import Mapping

# Stable reason-code registry for removed/flagged signals.
# Keep these identifiers backward-compatible across releases.
REASON_CODE_REGISTRY: dict[str, str] = {
    "bidi_control": "IH001_BIDI_CONTROL",
    "default_ignorable": "IH002_DEFAULT_IGNORABLE",
    "junk_invisible": "IH003_JUNK_INVISIBLE",
    "control_or_format": "IH004_CONTROL_OR_FORMAT",
    "carriage_return": "IH005_CARRIAGE_RETURN",
    "whitespace_tidy": "IH006_WHITESPACE_TIDY",
    "high_entropy": "IH010_HIGH_ENTROPY",
    "high_combining_ratio": "IH011_HIGH_COMBINING_RATIO",
    "confusable_mixed_script": "IH020_CONFUSABLE_MIXED_SCRIPT",
    "mixed_script_word": "IH020_CONFUSABLE_MIXED_SCRIPT",
    "base64ish_blob": "IH030_BASE64_LIKE_PAYLOAD",
    "hex_blob": "IH031_HEX_LIKE_PAYLOAD",
}

DECISION_REASON_CODES: dict[str, str] = {
    "total_removed_threshold": "IH090_REMOVAL_VOLUME_THRESHOLD",
}


def reason_code_for_signal(signal: str) -> str | None:
    return REASON_CODE_REGISTRY.get(signal)


def reason_code_counts(
    removed_counts: Mapping[str, int],
    flagged_counts: Mapping[str, int],
) -> dict[str, int]:
    counts: dict[str, int] = {}
    for source in (removed_counts, flagged_counts):
        for signal, raw_count in source.items():
            count = int(raw_count)
            if count <= 0:
                continue
            code = reason_code_for_signal(signal)
            if code is None:
                continue
            counts[code] = counts.get(code, 0) + count
    return {code: counts[code] for code in sorted(counts)}


def merge_reason_code_counts(*items: Mapping[str, int]) -> dict[str, int]:
    merged: dict[str, int] = {}
    for item in items:
        for code, raw_count in item.items():
            count = int(raw_count)
            if count <= 0:
                continue
            merged[code] = merged.get(code, 0) + count
    return {code: merged[code] for code in sorted(merged)}

