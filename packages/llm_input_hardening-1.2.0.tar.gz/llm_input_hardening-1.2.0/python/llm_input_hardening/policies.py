from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True)
class PolicyPreset:
    name: str
    normalization: str
    remove_bidi: bool
    remove_junk_invisibles: bool
    remove_other_controls: bool
    remove_default_ignorables: bool
    tidy_whitespace: bool
    flag_default_ignorables: bool
    flag_base64ish: bool
    flag_combining_abuse: bool


def _registry_path() -> Path:
    return Path(__file__).with_name("policy_registry.json")


@lru_cache(maxsize=1)
def _registry() -> dict[str, object]:
    with _registry_path().open("r", encoding="utf-8") as handle:
        return json.load(handle)


@lru_cache(maxsize=1)
def _presets() -> dict[str, PolicyPreset]:
    raw = _registry().get("presets", {})
    if not isinstance(raw, dict):
        raise ValueError("policy registry presets must be a mapping")

    presets: dict[str, PolicyPreset] = {}
    for name, spec in raw.items():
        if not isinstance(name, str) or not isinstance(spec, dict):
            raise ValueError("policy registry preset entries must be mappings")
        presets[name] = PolicyPreset(name=name, **spec)
    return presets


@lru_cache(maxsize=1)
def _aliases() -> dict[str, str]:
    raw = _registry().get("aliases", {})
    if not isinstance(raw, dict):
        raise ValueError("policy registry aliases must be a mapping")
    return {
        alias: canonical
        for alias, canonical in raw.items()
        if isinstance(alias, str) and isinstance(canonical, str)
    }


def resolve_policy_name(policy: str) -> str:
    key = policy.strip()
    canonical = _aliases().get(key, key)
    if canonical not in _presets():
        allowed = ", ".join(sorted([*list(_presets().keys()), *list(_aliases().keys())]))
        raise ValueError(f"unknown policy: {policy}. Supported policies: {allowed}")
    return canonical


def policy_preset(policy: str) -> PolicyPreset:
    canonical = resolve_policy_name(policy)
    return _presets()[canonical]


def cli_policy_choices() -> list[str]:
    return [*_presets().keys(), *_aliases().keys()]
