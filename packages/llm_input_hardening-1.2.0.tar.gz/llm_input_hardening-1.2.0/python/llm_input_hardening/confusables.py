from __future__ import annotations

import unicodedata
from typing import Any, TypedDict


class ConfusableSignal(TypedDict):
    """Best-effort confusable/homoglyph signal for one text sample."""

    backend: str
    available: bool
    mixed_script: bool
    dangerous: bool
    restriction_level: str
    script_set: list[str]
    skeleton_stored: bool
    confusable_count: int
    mixed_word_count: int
    mixed_words: list[str]
    error: str | None


_BACKEND_ALIASES = {
    "heuristic": "heuristic",
    "confusable-homoglyphs": "confusable_homoglyphs",
    "confusable_homoglyphs": "confusable_homoglyphs",
    "homoglyphs": "confusable_homoglyphs",
}
_PREFERRED_ALIASES = ["LATIN"]


def _normalized_backend(name: str) -> str:
    backend = _BACKEND_ALIASES.get(name, name)
    if backend not in {"heuristic", "confusable_homoglyphs"}:
        raise ValueError(
            f"unknown confusables backend: {name}. "
            "Supported backends: heuristic, confusable_homoglyphs"
        )
    return backend


def _script_alias(ch: str) -> str | None:
    if not ch.isalpha():
        return None
    name = unicodedata.name(ch, "")
    for script in (
        "LATIN",
        "CYRILLIC",
        "GREEK",
        "ARABIC",
        "HEBREW",
        "HAN",
        "HIRAGANA",
        "KATAKANA",
        "HANGUL",
        "DEVANAGARI",
        "THAI",
    ):
        if script in name:
            return script
    return None


def _detect_mixed_script_words(text: str) -> list[str]:
    words: list[str] = []
    current: list[str] = []

    def flush() -> None:
        if not current:
            return
        token = "".join(current)
        scripts = {_script_alias(ch) for ch in token}
        scripts.discard(None)
        if len(scripts) >= 2:
            words.append(token)
        current.clear()

    for ch in text:
        if ch.isalpha():
            current.append(ch)
        else:
            flush()
    flush()
    return words


def _script_set(text: str) -> set[str]:
    scripts = set()
    for ch in text:
        alias = _script_alias(ch)
        if alias:
            scripts.add(alias)
    return scripts


def _restriction_level(text: str) -> tuple[str, list[str]]:
    scripts = _script_set(text)
    script_list = sorted(scripts)
    ascii_only = bool(text) and all(ord(ch) < 128 for ch in text)
    if ascii_only:
        return "ASCII_ONLY", script_list
    if len(scripts) <= 1:
        return "SINGLE_SCRIPT_RESTRICTIVE", script_list
    # UTS #39-aligned naming; this is heuristic classification, not a full spoof checker.
    highly = {"LATIN", "HAN", "HIRAGANA", "KATAKANA"}
    moderate = highly | {"BOPOMOFO", "HANGUL"}
    if scripts.issubset(highly):
        return "HIGHLY_RESTRICTIVE", script_list
    if scripts.issubset(moderate):
        return "MODERATELY_RESTRICTIVE", script_list
    if scripts == {"LATIN", "GREEK"} or scripts == {"LATIN", "CYRILLIC"}:
        return "UNRESTRICTIVE", script_list
    return "MINIMALLY_RESTRICTIVE", script_list


def detect_confusables(text: str, *, backend: str = "heuristic") -> ConfusableSignal:
    """Detect mixed-script confusable signals with optional backend enrichment."""

    backend = _normalized_backend(backend)
    mixed_words = _detect_mixed_script_words(text)
    heuristic_mixed = bool(mixed_words)
    restriction_level, script_set = _restriction_level(text)
    if backend == "heuristic":
        return {
            "backend": backend,
            "available": True,
            "mixed_script": heuristic_mixed,
            "dangerous": heuristic_mixed,
            "restriction_level": restriction_level,
            "script_set": script_set,
            "skeleton_stored": False,
            "confusable_count": len(mixed_words),
            "mixed_word_count": len(mixed_words),
            "mixed_words": mixed_words[:8],
            "error": None,
        }

    try:
        from confusable_homoglyphs import confusables
    except Exception as exc:
        return {
            "backend": backend,
            "available": False,
            "mixed_script": heuristic_mixed,
            "dangerous": heuristic_mixed,
            "restriction_level": restriction_level,
            "script_set": script_set,
            "skeleton_stored": False,
            "confusable_count": 0,
            "mixed_word_count": len(mixed_words),
            "mixed_words": mixed_words[:8],
            "error": str(exc),
        }

    try:
        mixed = bool(confusables.is_mixed_script(text)) or heuristic_mixed
        dangerous = bool(
            confusables.is_dangerous(text, preferred_aliases=_PREFERRED_ALIASES)
        ) or heuristic_mixed
        details: Any = confusables.is_confusable(
            text, preferred_aliases=_PREFERRED_ALIASES
        )
        count = len(details) if isinstance(details, list) else 0
        return {
            "backend": backend,
            "available": True,
            "mixed_script": mixed,
            "dangerous": dangerous,
            "restriction_level": restriction_level,
            "script_set": script_set,
            "skeleton_stored": False,
            "confusable_count": max(count, len(mixed_words)),
            "mixed_word_count": len(mixed_words),
            "mixed_words": mixed_words[:8],
            "error": None,
        }
    except Exception as exc:
        return {
            "backend": backend,
            "available": True,
            "mixed_script": heuristic_mixed,
            "dangerous": heuristic_mixed,
            "restriction_level": restriction_level,
            "script_set": script_set,
            "skeleton_stored": False,
            "confusable_count": 0,
            "mixed_word_count": len(mixed_words),
            "mixed_words": mixed_words[:8],
            "error": str(exc),
        }
