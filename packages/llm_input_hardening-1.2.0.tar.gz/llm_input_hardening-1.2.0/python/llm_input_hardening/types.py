from __future__ import annotations

from typing import Literal, TypedDict


class SpanEvent(TypedDict):
    """One span event emitted by the sanitizer when `return_spans=True`."""

    kind: Literal["removed", "flag"]
    reason: str
    start: int
    end: int
    detail: str


class SanitizeStats(TypedDict, total=False):
    """Additional measurements included in `SanitizeReport["stats"]`.

    Keys may be added over time; consumers should treat this as best-effort telemetry.
    """

    ascii_fast_path: bool
    normalized_changed: bool
    combining_ratio: float
    base64ish: bool
    entropy_2000: float
    confusables_backend: str
    confusables_available: bool
    confusables_mixed_script: bool
    confusables_dangerous: bool
    confusables_restriction_level: str
    confusables_scripts: list[str]
    confusables_skeleton_stored: bool
    confusable_count: int
    confusables_error: str
    mixed_script_word_count: int
    mixed_script_words: list[str]
    hexbish: bool
    entropy_window_max: float
    default_ignorable_removed: int
    default_ignorable_removed_joiner: int
    default_ignorable_removed_variation_selector: int
    default_ignorable_removed_tag: int
    default_ignorable_removed_other: int
    default_ignorable_stripped: bool
    json_string_leaf_count: int
    json_changed_string_leaves: int


class SanitizeReport(TypedDict):
    """Structured report returned by `sanitize()`."""

    report_version: int
    policy: str
    normalization: str
    changed: bool
    removed_counts: dict[str, int]
    flagged_counts: dict[str, int]
    reason_codes: dict[str, int]
    spans: list[SpanEvent]
    stats: SanitizeStats


class TokenMeter(TypedDict):
    """Token budget information emitted by `meter()`."""

    tokenizer: str
    input_tokens: int
    limit_tokens: int | None
    reserved_output_tokens: int
    available_tokens: int | None
    percent_used: float | None


class MeterResult(TypedDict):
    """Return type for `meter()`."""

    sanitize: SanitizeReport
    tokens_before: TokenMeter
    tokens_after: TokenMeter


EnforcementAction = Literal["allow", "quarantine", "reject"]


class EnforcementDecision(TypedDict):
    """Decision emitted by `decide_enforcement()`."""

    action: EnforcementAction
    reason_codes: list[str]
    reasons: list[str]
    triggered_flags: dict[str, int]
    triggered_removed: dict[str, int]
