from __future__ import annotations

from typing import Any, Optional, Tuple, cast

from ._service import sanitize_text
from .types import MeterResult, SanitizeReport, TokenMeter


def _fallback_token_estimate(text: str) -> int:
    # rough estimate; only used if no tokenizer libs installed
    import re
    if not text:
        return 0
    chunks = re.findall(r"[A-Za-z0-9]+|[^ \t\r\nA-Za-z0-9]+", text)
    return max(1, int(len(chunks) * 0.9))


def _count_tokens(text: str, model: Optional[str], tokenizer: Optional[Any]) -> Tuple[int, str]:
    if tokenizer is not None:
        try:
            enc = tokenizer.encode(text)
            return len(enc.ids), "hf_tokenizers:custom"
        except Exception:
            pass

    try:
        import tiktoken
        if model:
            enc = tiktoken.encoding_for_model(model)
            return len(enc.encode(text)), f"tiktoken:model:{model}"
        enc = tiktoken.get_encoding("o200k_base")
        return len(enc.encode(text)), "tiktoken:o200k_base"
    except Exception:
        return _fallback_token_estimate(text), "fallback"


def meter(
    text: str,
    *,
    model: Optional[str] = None,
    limit_tokens: Optional[int] = None,
    reserved_output_tokens: int = 512,
    policy: str = "balanced_chat",
    tokenizer: Optional[Any] = None,
    use_ftfy: bool = False,
    sanitized: tuple[str, SanitizeReport] | None = None,
) -> MeterResult:
    """Estimate token usage before/after sanitization.

    This is useful when you enforce context window budgets. The meter:
    - counts tokens on the original input
    - sanitizes the text (via `sanitize()`)
    - counts tokens again on the sanitized output

    Token counting strategy:
    1) If `tokenizer` is provided, it is used first.
    2) Else if `tiktoken` is installed, it is used (optionally with `model`).
    3) Else a rough fallback heuristic is used.

    Args:
        text: Input text to sanitize and measure.
        model: Optional model name for `tiktoken.encoding_for_model`.
        limit_tokens: Optional hard token limit (context window).
        reserved_output_tokens: Tokens reserved for the model’s response.
        policy: Sanitization policy (`"preserve"`, `"balanced_chat"`, `"strict_exec"`).
        tokenizer: Optional HuggingFace `tokenizers.Tokenizer`-like object.
        use_ftfy: Whether to run `ftfy` repair before sanitizing (see `sanitize()`).
        sanitized: Optional `(clean_text, report)` to reuse a prior `sanitize()` result.

    Returns:
        A dict containing the sanitize report and token counts before/after.
    """
    before_tokens, before_label = _count_tokens(text, model, tokenizer)
    if sanitized is None:
        cleaned, srep = sanitize_text(text, policy=policy, use_ftfy=use_ftfy)
    else:
        cleaned, srep = sanitized
    after_tokens, after_label = _count_tokens(cleaned, model, tokenizer)

    def mk(tokens: int, label: str) -> TokenMeter:
        if limit_tokens is not None:
            avail = max(0, limit_tokens - tokens - reserved_output_tokens)
            pct = (tokens / limit_tokens) * 100.0 if limit_tokens else None
        else:
            avail, pct = None, None
        return {
            "tokenizer": label,
            "input_tokens": tokens,
            "limit_tokens": limit_tokens,
            "reserved_output_tokens": reserved_output_tokens,
            "available_tokens": avail,
            "percent_used": pct,
        }

    return cast(
        MeterResult,
        {
            "sanitize": srep,
            "tokens_before": mk(before_tokens, before_label),
            "tokens_after": mk(after_tokens, after_label),
        },
    )
