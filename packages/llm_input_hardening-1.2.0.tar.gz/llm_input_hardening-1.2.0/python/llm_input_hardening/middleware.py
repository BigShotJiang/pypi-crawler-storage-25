from __future__ import annotations

import json
from typing import Any, Awaitable, Callable, Optional

from ._service import sanitize_text
from .meter import meter


Receive = Callable[[], Awaitable[dict[str, Any]]]
Send = Callable[[dict[str, Any]], Awaitable[None]]


def _header_value(scope: dict[str, Any], name: bytes) -> str:
    for key, value in scope.get("headers", []):
        if key.lower() == name:
            return value.decode("latin-1")
    return ""


def _set_content_length(scope: dict[str, Any], length: int) -> dict[str, Any]:
    headers = [
        (key, value)
        for key, value in scope.get("headers", [])
        if key.lower() != b"content-length"
    ]
    headers.append((b"content-length", str(length).encode("latin-1")))
    updated = dict(scope)
    updated["headers"] = headers
    return updated


async def _read_body(receive: Receive) -> bytes:
    chunks: list[bytes] = []
    while True:
        message = await receive()
        if message["type"] != "http.request":
            continue
        chunks.append(message.get("body", b""))
        if not message.get("more_body", False):
            return b"".join(chunks)


def _replay_body(body: bytes) -> Receive:
    sent = False

    async def receive() -> dict[str, Any]:
        nonlocal sent
        if sent:
            return {"type": "http.request", "body": b"", "more_body": False}
        sent = True
        return {"type": "http.request", "body": body, "more_body": False}

    return receive


class StarlettePromptSanitizerMiddleware:
    """Starlette/FastAPI middleware that sanitizes one JSON string field.

    Behavior:
    - Only runs for HTTP requests with `Content-Type: application/json`.
    - Parses the request body as JSON.
    - If `body[field]` is a string, it is sanitized and replaced in the body.
    - Adds response headers for downstream visibility:
      - `x-sanitize-changed: true|false`
      - `x-tokens-before: <int>`
      - `x-tokens-after: <int>`

    If parsing fails or the field is missing/not a string, the request is passed through
    unchanged.
    """

    def __init__(
        self,
        app: Any,
        *,
        field: str = "prompt",
        policy: str = "balanced_chat",
        model: Optional[str] = None,
        limit_tokens: Optional[int] = None,
        reserved_output_tokens: int = 512,
    ):
        """Create the middleware.

        Args:
            app: Downstream ASGI app.
            field: JSON key to sanitize (default: `"prompt"`).
            policy: Sanitization policy (`"preserve"`, `"balanced_chat"`, `"strict_exec"`).
            model: Optional model name for token counting (used by `tiktoken` when available).
            limit_tokens: Optional context window limit (for `available_tokens` calculation).
            reserved_output_tokens: Tokens reserved for the model’s response.
        """
        self.app = app
        self.field = field
        self.policy = policy
        self.model = model
        self.limit_tokens = limit_tokens
        self.reserved_output_tokens = reserved_output_tokens

    async def __call__(self, scope: dict[str, Any], receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            return await self.app(scope, receive, send)

        ctype = _header_value(scope, b"content-type")
        if "application/json" not in ctype.lower():
            return await self.app(scope, receive, send)

        body = await _read_body(receive)
        if not body:
            return await self.app(scope, _replay_body(body), send)

        try:
            data = json.loads(body.decode("utf-8"))
        except Exception:
            return await self.app(scope, _replay_body(body), send)

        if isinstance(data, dict) and isinstance(data.get(self.field), str):
            original = data[self.field]
            cleaned, srep = sanitize_text(original, policy=self.policy)
            data[self.field] = cleaned

            rep = meter(
                original,
                model=self.model,
                limit_tokens=self.limit_tokens,
                reserved_output_tokens=self.reserved_output_tokens,
                policy=self.policy,
                sanitized=(cleaned, srep),
            )

            new_body = json.dumps(data, ensure_ascii=False).encode("utf-8")

            async def send_wrapper(message):
                if message["type"] == "http.response.start":
                    headers = message.setdefault("headers", [])

                    def add(k, v):
                        headers.append((k.encode("latin-1"), v.encode("latin-1")))

                    add("x-sanitize-changed", str(rep["sanitize"]["changed"]).lower())
                    add("x-tokens-before", str(rep["tokens_before"]["input_tokens"]))
                    add("x-tokens-after", str(rep["tokens_after"]["input_tokens"]))
                await send(message)

            return await self.app(
                _set_content_length(scope, len(new_body)),
                _replay_body(new_body),
                send_wrapper,
            )

        return await self.app(scope, _replay_body(body), send)
