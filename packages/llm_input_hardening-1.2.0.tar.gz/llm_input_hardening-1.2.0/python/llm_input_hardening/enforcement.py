from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from ._service import sanitize_text
from .reason_codes import DECISION_REASON_CODES, reason_code_for_signal
from .types import EnforcementDecision, SanitizeReport


@dataclass(frozen=True)
class EnforcementPolicy:
    """Threshold policy for `decide_enforcement()`."""

    reject_flags: frozenset[str] = frozenset(
        {"confusable_mixed_script", "mixed_script_word"}
    )
    quarantine_flags: frozenset[str] = frozenset(
        {"base64ish_blob", "hex_blob", "high_entropy", "high_combining_ratio"}
    )
    reject_removed: frozenset[str] = frozenset({"bidi_control", "control_or_format"})
    quarantine_removed: frozenset[str] = frozenset({"junk_invisible", "default_ignorable"})
    quarantine_total_removed_at_or_above: int = 12


DEFAULT_ENFORCEMENT_POLICY = EnforcementPolicy()


def _triggered_counts(
    counts: Mapping[str, int], keys: frozenset[str]
) -> dict[str, int]:
    return {key: int(counts.get(key, 0)) for key in sorted(keys) if counts.get(key, 0) > 0}


def decide_enforcement(
    report: SanitizeReport, *, policy: EnforcementPolicy = DEFAULT_ENFORCEMENT_POLICY
) -> EnforcementDecision:
    """Map a sanitize report to `allow`, `quarantine`, or `reject`."""

    removed_counts = report.get("removed_counts", {})
    flagged_counts = report.get("flagged_counts", {})

    reject_flag_hits = _triggered_counts(flagged_counts, policy.reject_flags)
    reject_removed_hits = _triggered_counts(removed_counts, policy.reject_removed)
    if reject_flag_hits or reject_removed_hits:
        reason_codes = sorted(
            {
                code
                for key in [*reject_flag_hits.keys(), *reject_removed_hits.keys()]
                for code in [reason_code_for_signal(key)]
                if code is not None
            }
        )
        return {
            "action": "reject",
            "reason_codes": reason_codes,
            "reasons": reason_codes,
            "triggered_flags": reject_flag_hits,
            "triggered_removed": reject_removed_hits,
        }

    quarantine_flag_hits = _triggered_counts(flagged_counts, policy.quarantine_flags)
    quarantine_removed_hits = _triggered_counts(removed_counts, policy.quarantine_removed)

    total_removed = sum(int(v) for v in removed_counts.values())
    total_removed_trigger = total_removed >= policy.quarantine_total_removed_at_or_above

    if quarantine_flag_hits or quarantine_removed_hits or total_removed_trigger:
        reason_code_set = {
            code
            for key in [*quarantine_flag_hits.keys(), *quarantine_removed_hits.keys()]
            for code in [reason_code_for_signal(key)]
            if code is not None
        }
        if total_removed_trigger:
            reason_code_set.add(DECISION_REASON_CODES["total_removed_threshold"])
        reason_codes = sorted(reason_code_set)
        return {
            "action": "quarantine",
            "reason_codes": reason_codes,
            "reasons": reason_codes,
            "triggered_flags": quarantine_flag_hits,
            "triggered_removed": quarantine_removed_hits,
        }

    return {
        "action": "allow",
        "reason_codes": [],
        "reasons": [],
        "triggered_flags": {},
        "triggered_removed": {},
    }


def sanitize_and_decide(
    text: str,
    *,
    sanitize_policy: str = "balanced_chat",
    enforcement_policy: EnforcementPolicy = DEFAULT_ENFORCEMENT_POLICY,
    **sanitize_kwargs: object,
) -> tuple[str, SanitizeReport, EnforcementDecision]:
    """Convenience wrapper that runs sanitize then enforcement decisioning."""

    clean, report = sanitize_text(text, policy=sanitize_policy, **sanitize_kwargs)
    return clean, report, decide_enforcement(report, policy=enforcement_policy)
