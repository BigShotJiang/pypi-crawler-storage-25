from __future__ import annotations

import importlib.util

import pytest

from llm_input_hardening import sanitize


def test_confusable_backend_flags_mixed_script() -> None:
    if importlib.util.find_spec("confusable_homoglyphs") is None:
        pytest.skip("confusable_homoglyphs is not installed")

    clean, rep = sanitize(
        "раypal",
        policy="balanced_chat",
        confusables_backend="confusable_homoglyphs",
    )
    assert clean == "раypal"
    assert rep["flagged_counts"].get("confusable_mixed_script", 0) == 1
    assert rep["stats"].get("confusables_available") is True
    assert rep["stats"].get("confusables_restriction_level") in {
        "UNRESTRICTIVE",
        "MINIMALLY_RESTRICTIVE",
    }
    assert rep["stats"].get("confusables_skeleton_stored") is False


def test_heuristic_flags_mixed_script_without_backend() -> None:
    _, rep = sanitize("раypal", policy="balanced_chat")
    assert rep["flagged_counts"].get("mixed_script_word", 0) == 1
    assert rep["flagged_counts"].get("confusable_mixed_script", 0) == 1
    assert rep["stats"].get("mixed_script_word_count", 0) >= 1


def test_unknown_confusable_backend_raises() -> None:
    with pytest.raises(ValueError, match="unknown confusables backend"):
        sanitize("paypal", confusables_backend="icu")


def test_confusable_backend_avoids_arabic_false_positive() -> None:
    _, rep = sanitize(
        "می‌خواهم کتاب",
        policy="balanced_chat",
        confusables_backend="confusable_homoglyphs",
    )
    assert rep["flagged_counts"].get("confusable_mixed_script", 0) == 0


def test_pure_non_latin_script_does_not_flag() -> None:
    _, rep = sanitize("пример текста", policy="balanced_chat")
    assert rep["flagged_counts"].get("mixed_script_word", 0) == 0
    assert rep["flagged_counts"].get("confusable_mixed_script", 0) == 0
    assert rep["stats"].get("confusables_restriction_level") == "SINGLE_SCRIPT_RESTRICTIVE"
