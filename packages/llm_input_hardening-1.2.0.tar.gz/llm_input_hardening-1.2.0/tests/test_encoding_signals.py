from __future__ import annotations

from llm_input_hardening import sanitize


def test_base64_blob_flag_without_transform() -> None:
    text = "QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVo=" * 3
    clean, rep = sanitize(text, policy="balanced_chat")
    assert clean == text
    assert rep["flagged_counts"].get("base64ish_blob", 0) == 1


def test_hex_blob_flag_without_transform() -> None:
    text = "deadbeef" * 32
    clean, rep = sanitize(text, policy="balanced_chat")
    assert clean == text
    assert rep["flagged_counts"].get("hex_blob", 0) == 1


def test_high_entropy_window_flag_without_transform() -> None:
    text = "".join(chr(0x2500 + (i % 64)) for i in range(600))
    clean, rep = sanitize(text, policy="balanced_chat")
    assert clean == text
    assert rep["flagged_counts"].get("high_entropy", 0) == 1
