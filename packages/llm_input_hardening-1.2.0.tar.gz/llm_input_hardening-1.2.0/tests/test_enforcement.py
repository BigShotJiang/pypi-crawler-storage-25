from __future__ import annotations

from llm_input_hardening import sanitize
from llm_input_hardening.enforcement import decide_enforcement, sanitize_and_decide


def test_reject_on_confusable_flag() -> None:
    _, rep = sanitize("раypal", policy="balanced_chat", confusables_backend="confusable_homoglyphs")
    decision = decide_enforcement(rep)
    assert decision["action"] == "reject"
    assert "IH020_CONFUSABLE_MIXED_SCRIPT" in decision["reason_codes"]
    assert decision["reasons"] == decision["reason_codes"]


def test_quarantine_on_entropy_flag() -> None:
    payload = "".join(chr(0x2500 + (i % 64)) for i in range(512))
    _, rep = sanitize(payload, policy="balanced_chat")
    decision = decide_enforcement(rep)
    assert decision["action"] == "quarantine"
    assert "IH010_HIGH_ENTROPY" in decision["reason_codes"]


def test_allow_for_clean_text() -> None:
    _, rep = sanitize("hello world", policy="balanced_chat")
    decision = decide_enforcement(rep)
    assert decision["action"] == "allow"
    assert decision["reasons"] == []


def test_sanitize_and_decide_wrapper() -> None:
    clean, rep, decision = sanitize_and_decide("abc\u202Edef")
    assert clean == "abcdef"
    assert rep["removed_counts"].get("bidi_control", 0) == 1
    assert decision["action"] == "reject"
