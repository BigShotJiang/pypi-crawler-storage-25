from __future__ import annotations

from llm_input_hardening import sanitize_json


def test_chat_message_array() -> None:
    payload = [
        {"role": "system", "content": "Be safe"},
        {"role": "user", "content": "abc\u202Edef"},
    ]
    clean, rep = sanitize_json(payload, policy="balanced_chat")
    assert clean[1]["content"] == "abcdef"
    assert rep["changed"] is True
    assert rep["removed_counts"].get("bidi_control", 0) == 1


def test_nested_tool_argument_dict() -> None:
    payload = {
        "tool": "run",
        "args": {"path": "a\u200Bb", "command": "echo ok"},
    }
    clean, rep = sanitize_json(payload, policy="balanced_chat")
    assert clean["args"]["path"] == "ab"
    assert rep["removed_counts"].get("junk_invisible", 0) == 1


def test_deeply_nested_json() -> None:
    payload = {"a": {"b": {"c": {"d": "x\u202Ey"}}}}
    clean, rep = sanitize_json(payload, policy="balanced_chat")
    assert clean["a"]["b"]["c"]["d"] == "xy"
    assert rep["changed"] is True


def test_mixed_list_dict_payload_preserves_non_string_types() -> None:
    payload = {"items": [1, None, True, {"v": "A\u200BB"}, 3.14]}
    clean, rep = sanitize_json(payload, policy="balanced_chat")
    assert clean["items"][0] == 1
    assert clean["items"][1] is None
    assert clean["items"][2] is True
    assert clean["items"][4] == 3.14
    assert clean["items"][3]["v"] == "AB"
    assert rep["stats"]["json_string_leaf_count"] >= 1
