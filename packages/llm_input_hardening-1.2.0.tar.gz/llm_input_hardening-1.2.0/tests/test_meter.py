from __future__ import annotations

from llm_input_hardening import meter, sanitize


class _Encoded:
    def __init__(self, text: str):
        self.ids = list(text)


class _Tokenizer:
    def encode(self, text: str) -> _Encoded:
        return _Encoded(text)


def test_meter_reports_before_after_counts() -> None:
    result = meter(
        "abc\u202Edef",
        limit_tokens=32,
        reserved_output_tokens=4,
        policy="balanced_chat",
        tokenizer=_Tokenizer(),
    )
    assert result["sanitize"]["changed"] is True
    assert result["tokens_before"]["input_tokens"] == 7
    assert result["tokens_after"]["input_tokens"] == 6
    assert result["tokens_after"]["available_tokens"] == 22


def test_meter_reuses_precomputed_sanitize_result() -> None:
    sanitized = sanitize("x\u200dy", policy="code_mode")
    result = meter(
        "x\u200dy",
        policy="code_mode",
        tokenizer=_Tokenizer(),
        sanitized=sanitized,
    )
    assert result["sanitize"] is sanitized[1]
    assert result["tokens_after"]["input_tokens"] == 2
