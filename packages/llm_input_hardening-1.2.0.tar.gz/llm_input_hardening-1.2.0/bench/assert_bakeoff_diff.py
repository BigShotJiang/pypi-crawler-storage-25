from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


def _load(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise SystemExit(f"Failed to load diff JSON {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise SystemExit(f"Diff JSON root must be object: {path}")
    return payload


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Fail when bake-off diff report contains regressions."
    )
    parser.add_argument(
        "--in",
        dest="input_path",
        default="bench/results/bakeoff_diff_latest.json",
        help="Bake-off diff JSON path.",
    )
    args = parser.parse_args()

    path = Path(args.input_path)
    if not path.exists():
        raise SystemExit(f"Missing diff JSON: {path}")

    payload = _load(path)
    engines = payload.get("engines", [])
    if not isinstance(engines, list):
        raise SystemExit("Diff JSON malformed: engines must be a list")

    failing: list[str] = []
    for engine in engines:
        if not isinstance(engine, dict):
            continue
        if not bool(engine.get("regression_detected", False)):
            continue
        name = str(engine.get("engine", "<unknown-engine>"))
        regressions = engine.get("regressions", [])
        if isinstance(regressions, list):
            metric_list = ", ".join(sorted(str(m) for m in regressions))
        else:
            metric_list = "<unknown-metrics>"
        failing.append(f"{name}: {metric_list}")

    if failing or bool(payload.get("regression_detected", False)):
        print("Bake-off regression gate failed:", file=sys.stderr)
        for item in failing or ["regression_detected=true"]:
            print(f"  - {item}", file=sys.stderr)
        raise SystemExit(1)

    print("Bake-off regression gate passed (no bootstrap metric regressions).")


if __name__ == "__main__":
    main()
