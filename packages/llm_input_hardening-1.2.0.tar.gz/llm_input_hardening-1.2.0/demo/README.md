# Playground

Run a local obfuscation-removal playground:

```bash
uv run --extra web python -m demo.playground
```

Open `http://127.0.0.1:8000` and test before/after sanitization with `balanced_chat` vs `strict_exec`.
