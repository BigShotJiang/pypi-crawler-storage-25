﻿"""
Guardian SDK - AI Agent Security & Governance

A production-ready SDK for intercepting and securing AI agent tool calls.
"""

# Version
from .version import __version__, __version_info__, get_version

# Core client
from .client import GuardianClient
from .sync_client import SyncGuardianClient

# Configuration
from .schemas import GuardianConfig, Decision, ApprovalTimeoutAction

# Exceptions
from .exceptions import (
    GuardianSDKException,
    GuardianSecurityViolation,
    GuardianConnectionError,
    GuardianConfigurationError,
    GuardianApprovalTimeout,
)

# Constants
from .constants import (
    DEFAULT_BACKEND_URL,
    DEFAULT_TIMEOUT_SECONDS,
    DEFAULT_MAX_RETRIES,
    DEFAULT_AGENT_ID,
    DECISION_ALLOW,
    DECISION_BLOCK,
    DECISION_ASK,
)

__all__ = [
    # Version
    "__version__",
    "__version_info__",
    "get_version",
    # Core clients
    "GuardianClient",
    "SyncGuardianClient",
    # Configuration
    "GuardianConfig",
    "Decision",
    "ApprovalTimeoutAction",
    # Exceptions
    "GuardianSDKException",
    "GuardianSecurityViolation",
    "GuardianConnectionError",
    "GuardianConfigurationError",
    "GuardianApprovalTimeout",
    # Constants
    "DEFAULT_BACKEND_URL",
    "DEFAULT_TIMEOUT_SECONDS",
    "DEFAULT_MAX_RETRIES",
    "DEFAULT_AGENT_ID",
    "DECISION_ALLOW",
    "DECISION_BLOCK",
    "DECISION_ASK",
]
