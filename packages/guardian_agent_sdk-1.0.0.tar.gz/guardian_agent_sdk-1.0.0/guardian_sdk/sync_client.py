"""
Thread-safe synchronous client for Guardian SDK.

This module provides a synchronous wrapper around the async client,
suitable for non-async environments and legacy codebases.
"""

import asyncio
import logging
import threading
import concurrent.futures
from typing import Any, Dict, Optional, Union

from .client import GuardianClient as AsyncGuardianClient
from .schemas import GuardianConfig

logger = logging.getLogger(__name__)


class SyncGuardianClient:
    """
    Thread-safe synchronous client for Guardian SDK.
    
    This client wraps the async client and provides synchronous methods
    for use in environments where asyncio is not available.
    
    Example:
        >>> client = SyncGuardianClient(api_key="your_key")
        >>> result = client.check_action("execute_sql", {"query": "SELECT 1"})
        >>> print(result)
    """
    
    def __init__(self, config: Union[GuardianConfig, Dict[str, Any], None] = None):
        """
        Initialize the synchronous Guardian client.
        
        Args:
            config: Configuration object or dictionary, or None to use env vars
        """
        self._config = config
        self._async_client = AsyncGuardianClient(config)
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread_lock = threading.Lock()
        
    def _get_or_create_event_loop(self) -> asyncio.AbstractEventLoop:
        """Get or create an event loop for this thread."""
        with self._thread_lock:
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                # No running loop, create one for this thread
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                self._loop = loop
            else:
                self._loop = loop
            return self._loop
    
    def _run_async(self, coroutine):
        """Run an async coroutine synchronously."""
        loop = self._get_or_create_event_loop()
        
        if loop.is_running():
            # Another thread/loop is running, create a new loop
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(loop.run_until_complete, coroutine)
                return future.result()
        else:
            return loop.run_until_complete(coroutine)
    
    def check_action(
        self,
        tool_name: str,
        tool_input: Dict[str, Any],
        agent_id: str,
    ) -> Dict[str, Any]:
        """
        Synchronously check if an action is allowed.
        
        Args:
            tool_name: Name of the tool being called
            tool_input: Arguments passed to the tool
            agent_id: Agent identifier
            
        Returns:
            Decision dictionary with keys: decision, policy_id, reason, event_id
        """
        return self._run_async(
            self._async_client._check_action(tool_name, tool_input, agent_id)
        )
    
    def wrap_openai(self, client: Any, agent_id: Optional[str] = None) -> Any:
        """
        Wrap an OpenAI client with Guardian interception.
        
        Args:
            client: OpenAI client instance (must be synchronous)
            agent_id: Optional agent ID override
            
        Returns:
            Wrapped client with synchronous interception
        """
        return self._run_async(
            self._async_client.wrap_openai(client, agent_id, sync=True)
        )
    
    def wrap_anthropic(self, client: Any, agent_id: Optional[str] = None) -> Any:
        """
        Wrap an Anthropic client with Guardian interception.
        
        Args:
            client: Anthropic client instance
            agent_id: Optional agent ID override
            
        Returns:
            Wrapped client
        """
        return self._run_async(
            self._async_client.wrap_anthropic(client, agent_id)
        )
    
    def wrap_tool(
        self,
        tool_func,
        agent_id: str,
        tool_name: Optional[str] = None,
        fail_safe_decision: Optional[str] = None,
    ):
        """
        Wrap a synchronous tool function for interception.
        
        Args:
            tool_func: The tool function to wrap
            agent_id: Agent identifier
            tool_name: Optional custom tool name
            fail_safe_decision: Override fail-safe decision
            
        Returns:
            Wrapped function (sync)
        """
        async_wrapped = self._async_client.wrap_tool(
            tool_func, agent_id, tool_name, fail_safe_decision
        )
        
        # Convert async wrapper to sync
        def sync_wrapper(*args, **kwargs):
            return self._run_async(async_wrapped(*args, **kwargs))
        
        return sync_wrapper
    
    def get_stats(self) -> Dict[str, Any]:
        """Get SDK statistics."""
        return self._async_client.get_stats()
    
    def close(self) -> None:
        """Close the client and release resources."""
        if self._loop and not self._loop.is_closed():
            self._run_async(self._async_client.close())
            self._loop.close()
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()