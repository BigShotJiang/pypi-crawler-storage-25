"""
Pydantic schemas for Guardian SDK.

Defines all data models used for request/response validation,
configuration management, and telemetry collection.
"""

from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, field_validator, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Decision(str, Enum):
    """Policy decision outcomes."""
    ALLOW = "allow"
    BLOCK = "block"
    ASK = "ask"


class ApprovalTimeoutAction(str, Enum):
    """Action to take when approval polling times out."""
    BLOCK = "block"      # Deny by default (safe option)
    ALLOW = "allow"      # Allow by default (risky, use with caution)
    RAISE = "raise"      # Raise an exception


class GuardianConfig(BaseSettings):
    """
    Configuration for the Guardian SDK.
    
    Loads from environment variables with prefix GUARDIAN_ (e.g., GUARDIAN_API_KEY).
    Also supports loading from a .env file.
    """
    
    model_config = SettingsConfigDict(
        env_prefix="GUARDIAN_",
        env_file=".env",
        extra="ignore",
        validate_default=True,
    )
    
    # Authentication
    API_KEY: Optional[SecretStr] = Field(
        None,
        description="API key for authenticating with the Guardian Backend."
    )
    
    # Connection Settings
    BACKEND_URL: str = Field(
        "http://localhost:8000",
        description="URL of the Guardian Backend API."
    )
    TIMEOUT_SECONDS: float = Field(
        30.0,
        description="HTTP request timeout for backend calls.",
        ge=1.0,
        le=120.0
    )
    
    # Retry Configuration
    MAX_RETRIES: int = Field(
        3,
        description="Maximum number of retries for backend calls.",
        ge=0,
        le=10
    )
    RETRY_DELAY_SECONDS: float = Field(
        1.0,
        description="Base delay between retries (exponential backoff).",
        ge=0.1,
        le=30.0
    )
    
    # Agent Settings
    DEFAULT_AGENT_ID: str = Field(
        "default-agent",
        description="Default agent ID to use if not specified in wrap_client.",
        min_length=1,
        max_length=255
    )
    FAIL_SAFE_DECISION: Decision = Field(
        Decision.ALLOW,
        description="Decision to make if backend is unreachable (allow/block)."
    )
    
    # Human-in-the-Loop (HITL) Settings
    POLL_INTERVAL_SECONDS: float = Field(
        2.0,
        description="Interval for polling human approval status.",
        ge=0.5,
        le=10.0
    )
    MAX_POLL_SECONDS: float = Field(
        300.0,
        description="Maximum time to poll for human approval (5 minutes).",
        ge=10.0,
        le=3600.0
    )
    APPROVAL_TIMEOUT_ACTION: ApprovalTimeoutAction = Field(
        ApprovalTimeoutAction.BLOCK,
        description="Action if human approval times out."
    )
    
    # Telemetry Settings
    ENABLE_TELEMETRY: bool = Field(
        True,
        description="Enable or disable telemetry collection."
    )
    TELEMETRY_SAMPLE_RATE: float = Field(
        0.1,
        description="Sample rate for telemetry events (0.0 to 1.0)."
    )
    TELEMETRY_MAX_EVENTS: int = Field(
        1000,
        description="Maximum telemetry events to buffer before flushing.",
        ge=10,
        le=10000
    )
    TELEMETRY_FLUSH_INTERVAL_SECONDS: float = Field(
        60.0,
        description="Interval for periodic telemetry flush.",
        ge=5.0,
        le=600.0
    )
    
    # Streaming Support
    ENABLE_STREAMING_SUPPORT: bool = Field(
        True,
        description="Enable or disable streaming response reassembly."
    )
    
    @field_validator("TELEMETRY_SAMPLE_RATE")
    @classmethod
    def validate_sample_rate(cls, v: float) -> float:
        """Ensure sample rate is between 0 and 1."""
        if not 0.0 <= v <= 1.0:
            raise ValueError(f"TELEMETRY_SAMPLE_RATE must be between 0.0 and 1.0, got {v}")
        return v
    
    @field_validator("BACKEND_URL")
    @classmethod
    def validate_backend_url(cls, v: str) -> str:
        """Ensure backend URL ends with /api/v1 format."""
        v = v.rstrip('/')
        if not v.endswith('/api/v1'):
            # Auto-append /api/v1 if missing
            v = f"{v}/api/v1"
        return v
    
    def model_post_init(self, __context: Any) -> None:
        """Validate required fields after initialization."""
        if not self.API_KEY or not self.API_KEY.get_secret_value():
            raise ValueError(
                "GUARDIAN_API_KEY must be provided either in GuardianConfig or as an environment variable"
            )


class ToolCallRequest(BaseModel):
    """Schema for the request sent from SDK to Backend for tool call validation."""
    
    agent_id: str = Field(
        ...,
        description="Identifier for the AI agent making the tool call",
        min_length=1,
        max_length=255,
        examples=["agent-123"]
    )
    tool_name: str = Field(
        ...,
        description="Name of the tool being called",
        min_length=1,
        max_length=100,
        examples=["execute_sql"]
    )
    tool_input: Dict[str, Any] = Field(
        ...,
        description="Arguments passed to the tool",
        examples=[{"query": "SELECT * FROM users"}]
    )
    trace_id: Optional[str] = Field(
        None,
        description="Optional trace ID for distributed tracing",
        max_length=100
    )


class PolicyDecisionResponse(BaseModel):
    """Schema for the response from Backend to SDK after policy evaluation."""
    
    decision: Decision = Field(
        ...,
        description="Decision made by the policy engine (allow, block, ask)"
    )
    policy_id: str = Field(
        ...,
        description="ID or name of the policy that triggered the decision"
    )
    reason: str = Field(
        ...,
        description="Explanation for the decision"
    )
    event_id: str = Field(
        ...,
        description="Unique identifier for the security event"
    )
    rule_name: Optional[str] = Field(
        None,
        description="Name of the specific rule that matched"
    )
    matched_pattern: Optional[str] = Field(
        None,
        description="Regex pattern that caused the match"
    )


class SecurityEventResponse(BaseModel):
    """Schema for a security event, typically used for fetching logs from the backend."""
    
    id: str = Field(..., description="Unique identifier for the security event")
    agent_id: str
    tool_name: str
    tool_input: Dict[str, Any]
    policy_violation: Optional[str]
    decision: Decision
    human_decision_by: Optional[str]
    human_decision_at: Optional[str]
    latency_ms: int
    created_at: str


class TelemetryEvent(BaseModel):
    """Schema for a single telemetry event."""
    
    type: str
    session_id: str
    tool_name: str
    decision: str
    latency_ms: float
    error: Optional[str] = None
    timestamp: float


class TelemetryBatch(BaseModel):
    """Schema for a batch of telemetry events sent to the backend."""
    
    events: List[TelemetryEvent]
    
    @field_validator("events")
    @classmethod
    def validate_not_empty(cls, v: List[TelemetryEvent]) -> List[TelemetryEvent]:
        """Ensure batch is not empty."""
        if not v:
            raise ValueError("Telemetry batch cannot be empty")
        return v