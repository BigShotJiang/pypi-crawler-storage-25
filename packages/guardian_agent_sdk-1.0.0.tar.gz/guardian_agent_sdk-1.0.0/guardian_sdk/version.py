﻿"""
Version information for Guardian SDK.
"""

__version__ = "1.0.0"
__version_info__ = (1, 0, 0)

def get_version() -> str:
    """Return the current version of the Guardian SDK."""
    return __version__

def get_version_info() -> tuple:
    """Return the version as a tuple of integers (major, minor, patch)."""
    return __version_info__
