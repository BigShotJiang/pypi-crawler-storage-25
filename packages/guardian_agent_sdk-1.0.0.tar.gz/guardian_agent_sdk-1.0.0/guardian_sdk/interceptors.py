"""
Interceptors for Guardian SDK.

This module provides interceptors that can be used to wrap LLM clients
and tool functions, allowing the SDK to intercept and validate tool calls
before they are executed.

The interceptors handle:
- OpenAI chat.completions.create (async and sync)
- Anthropic messages.create (async and sync)
- Direct tool function wrapping
- Streaming response reassembly
"""

import json
import logging
import functools
from typing import Any, Dict, List, Optional, Callable, TypeVar, ParamSpec, Union, AsyncIterator, Iterator
from enum import Enum

from .exceptions import GuardianSecurityViolation, GuardianApprovalTimeout
from .constants import (
    DECISION_ALLOW,
    DECISION_BLOCK,
    DECISION_ASK,
    DECISION_HUMAN_APPROVED,
    DECISION_HUMAN_DENIED,
)

logger = logging.getLogger(__name__)

# Type variables for function wrapping
P = ParamSpec("P")
R = TypeVar("R")
ToolFunc = TypeVar("ToolFunc", bound=Callable)


class InterceptorType(str, Enum):
    """Types of interceptors available."""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    TOOL = "tool"


class StreamingChunkCollector:
    """
    Collects and reassembles streaming chunks from OpenAI.
    
    This enables full interception of tool calls in streaming mode by
    buffering chunks, reassembling tool call arguments, and validating
    them before yielding chunks to the caller.
    
    Example:
        collector = StreamingChunkCollector()
        async for chunk in stream:
            collector.add_chunk(chunk)
            if collector.is_complete():
                tool_calls = collector.get_complete_tool_calls()
                for call in tool_calls:
                    # Validate tool call
                    pass
            yield chunk
    """
    
    def __init__(self):
        """Initialize a new streaming chunk collector."""
        self.chunks: List[Dict[str, Any]] = []
        self.tool_call_buffer: Dict[int, Dict[str, Any]] = {}
    
    def add_chunk(self, chunk: Any) -> Any:
        """
        Add a chunk and check if we have a complete tool call.
        
        Args:
            chunk: A streaming chunk from OpenAI or Anthropic
            
        Returns:
            The original chunk (for chaining)
        """
        self.chunks.append(chunk)
        
        # Check for tool calls in this chunk (OpenAI format)
        if hasattr(chunk, 'choices') and chunk.choices:
            delta = chunk.choices[0].delta
            
            if hasattr(delta, 'tool_calls') and delta.tool_calls:
                for tool_call in delta.tool_calls:
                    idx = tool_call.index
                    
                    if idx not in self.tool_call_buffer:
                        self.tool_call_buffer[idx] = {
                            "name": "",
                            "arguments": ""
                        }
                    
                    if hasattr(tool_call, 'function'):
                        if hasattr(tool_call.function, 'name') and tool_call.function.name:
                            self.tool_call_buffer[idx]["name"] = tool_call.function.name
                        if hasattr(tool_call.function, 'arguments') and tool_call.function.arguments:
                            self.tool_call_buffer[idx]["arguments"] += tool_call.function.arguments
        
        # Check for tool calls in Anthropic format
        if hasattr(chunk, 'type') and chunk.type == 'content_block_delta':
            if hasattr(chunk, 'delta') and hasattr(chunk.delta, 'tool_use'):
                # Anthropic streaming format
                pass
        
        return chunk
    
    def get_complete_tool_calls(self) -> List[Dict[str, Any]]:
        """
        Get fully assembled tool calls from streamed chunks.
        
        Returns:
            List of complete tool calls with name and arguments
        """
        tool_calls = []
        for idx, data in self.tool_call_buffer.items():
            if data["name"] and data["arguments"]:
                try:
                    arguments = json.loads(data["arguments"])
                    tool_calls.append({
                        "name": data["name"],
                        "arguments": arguments
                    })
                except json.JSONDecodeError:
                    # Still incomplete, skip
                    pass
        return tool_calls
    
    def is_complete(self) -> bool:
        """
        Check if all tool calls are complete.
        
        Returns:
            True if all tool calls have complete JSON arguments
        """
        for data in self.tool_call_buffer.values():
            if data["name"] and data["arguments"]:
                try:
                    json.loads(data["arguments"])
                except json.JSONDecodeError:
                    return False
        return True
    
    def clear(self) -> None:
        """Clear all collected chunks and buffers."""
        self.chunks.clear()
        self.tool_call_buffer.clear()


class OpenAIIntegrator:
    """
    Integrator for OpenAI chat.completions.create.
    
    This class provides methods to wrap OpenAI client's create method
    for both streaming and non-streaming responses.
    """
    
    @staticmethod
    async def process_non_streaming_response(
        response: Any,
        context: Any,
        check_action_func: Callable
    ) -> Any:
        """
        Process a non-streaming OpenAI response, intercepting tool calls.
        
        Args:
            response: The OpenAI response object
            context: Agent context for check_action
            check_action_func: Function to call for checking actions
            
        Returns:
            The original response (if allowed) or raises exception
        """
        if hasattr(response, 'choices') and response.choices:
            message = response.choices[0].message
            
            if hasattr(message, 'tool_calls') and message.tool_calls:
                for tool_call in message.tool_calls:
                    tool_name = tool_call.function.name
                    
                    try:
                        tool_args = json.loads(tool_call.function.arguments)
                    except json.JSONDecodeError:
                        logger.warning(f"Could not parse tool arguments for {tool_name}")
                        tool_args = {"raw_arguments": tool_call.function.arguments}
                    
                    decision_data = await check_action_func(tool_name, tool_args)
                    decision = decision_data.get("decision")
                    event_id = decision_data.get("event_id")
                    reason = decision_data.get("reason", "No reason provided")
                    
                    if decision == DECISION_BLOCK:
                        raise GuardianSecurityViolation(
                            f"Guardian BLOCKED: Tool '{tool_name}' is not allowed. "
                            f"Reason: {reason}",
                            event_id=event_id,
                            decision=decision,
                            rule_name=decision_data.get("rule_name"),
                            matched_pattern=decision_data.get("matched_pattern")
                        )
                    
                    elif decision == DECISION_ASK:
                        logger.info(f"Action {tool_name} requires human approval (event: {event_id})")
                        # Wait for approval (handled by caller)
                        # This will raise GuardianApprovalTimeout on timeout
                        pass
        
        return response
    
    @staticmethod
    async def wrap_async_create(
        original_create: Callable[P, R],
        context: Any,
        check_action_func: Callable,
        wait_for_approval_func: Callable,
        enable_streaming: bool = True
    ) -> Callable[P, R]:
        """
        Wrap async OpenAI chat.completions.create method.
        
        Args:
            original_create: The original create method
            context: Agent context
            check_action_func: Function to check actions
            wait_for_approval_func: Function to wait for approval
            enable_streaming: Whether to support streaming responses
            
        Returns:
            Wrapped create method
        """
        @functools.wraps(original_create)
        async def wrapped_create(*args: P.args, **kwargs: P.kwargs) -> R:
            is_streaming = kwargs.get("stream", False)
            
            if is_streaming and enable_streaming:
                # For streaming, we need to collect chunks and validate after
                logger.debug("Streaming mode enabled, collecting chunks for validation")
                collector = StreamingChunkCollector()
                
                # Start streaming
                stream = await original_create(*args, **kwargs)
                
                async def streaming_wrapper():
                    async for chunk in stream:
                        collector.add_chunk(chunk)
                        
                        if collector.is_complete():
                            tool_calls = collector.get_complete_tool_calls()
                            for tool_call in tool_calls:
                                decision_data = await check_action_func(
                                    tool_call["name"],
                                    tool_call["arguments"]
                                )
                                
                                if decision_data.get("decision") == DECISION_BLOCK:
                                    raise GuardianSecurityViolation(
                                        f"Guardian BLOCKED: Tool '{tool_call['name']}' blocked in streaming mode",
                                        event_id=decision_data.get("event_id"),
                                        decision=decision_data.get("decision")
                                    )
                                
                                if decision_data.get("decision") == DECISION_ASK:
                                    approved = await wait_for_approval_func(
                                        decision_data.get("event_id"),
                                        tool_call["name"]
                                    )
                                    if not approved:
                                        raise GuardianSecurityViolation(
                                            f"Guardian DENIED: Tool '{tool_call['name']}' denied in streaming mode",
                                            event_id=decision_data.get("event_id"),
                                            decision=decision_data.get("decision")
                                        )
                        
                        yield chunk
                
                return streaming_wrapper()
            
            # Non-streaming: standard interception
            response = await original_create(*args, **kwargs)
            return await OpenAIIntegrator.process_non_streaming_response(
                response, context, check_action_func
            )
        
        return wrapped_create
    
    @staticmethod
    def wrap_sync_create(
        original_create: Callable[P, R],
        context: Any,
        check_action_sync_func: Callable
    ) -> Callable[P, R]:
        """
        Wrap sync OpenAI chat.completions.create method.
        
        Args:
            original_create: The original create method
            context: Agent context
            check_action_sync_func: Function to check actions synchronously
            
        Returns:
            Wrapped create method
        """
        @functools.wraps(original_create)
        def wrapped_create(*args: P.args, **kwargs: P.kwargs) -> R:
            is_streaming = kwargs.get("stream", False)
            
            if is_streaming:
                logger.warning(
                    "Streaming interception in sync mode is limited. "
                    "Use AsyncOpenAI for full streaming support."
                )
                return original_create(*args, **kwargs)
            
            response = original_create(*args, **kwargs)
            
            if hasattr(response, 'choices') and response.choices:
                message = response.choices[0].message
                
                if hasattr(message, 'tool_calls') and message.tool_calls:
                    for tool_call in message.tool_calls:
                        tool_name = tool_call.function.name
                        
                        try:
                            tool_args = json.loads(tool_call.function.arguments)
                        except json.JSONDecodeError:
                            tool_args = {"raw_arguments": tool_call.function.arguments}
                        
                        decision_data = check_action_sync_func(tool_name, tool_args)
                        decision = decision_data.get("decision")
                        event_id = decision_data.get("event_id")
                        reason = decision_data.get("reason", "No reason provided")
                        
                        if decision == DECISION_BLOCK:
                            raise GuardianSecurityViolation(
                                f"Guardian BLOCKED: Tool '{tool_name}' is not allowed. "
                                f"Reason: {reason}",
                                event_id=event_id,
                                decision=decision
                            )
                        
                        elif decision == DECISION_ASK:
                            raise RuntimeError(
                                f"Guardian ASK: Tool '{tool_name}' requires human approval. "
                                f"Event ID: {event_id}. Use async client for polling."
                            )
            
            return response
        
        return wrapped_create


class AnthropicIntegrator:
    """
    Integrator for Anthropic messages.create.
    
    This class provides methods to wrap Anthropic client's create method
    for async responses (streaming support TBD).
    """
    
    @staticmethod
    async def wrap_async_create(
        original_create: Callable[P, R],
        context: Any,
        check_action_func: Callable,
        wait_for_approval_func: Callable
    ) -> Callable[P, R]:
        """
        Wrap async Anthropic messages.create method.
        
        Args:
            original_create: The original create method
            context: Agent context
            check_action_func: Function to check actions
            wait_for_approval_func: Function to wait for approval
            
        Returns:
            Wrapped create method
        """
        @functools.wraps(original_create)
        async def wrapped_create(*args: P.args, **kwargs: P.kwargs) -> R:
            response = await original_create(*args, **kwargs)
            
            # Anthropic returns tool_use blocks in content
            if hasattr(response, 'content'):
                for block in response.content:
                    if hasattr(block, 'type') and block.type == 'tool_use':
                        tool_name = block.name
                        tool_args = block.input if hasattr(block, 'input') else {}
                        
                        decision_data = await check_action_func(tool_name, tool_args)
                        decision = decision_data.get("decision")
                        event_id = decision_data.get("event_id")
                        
                        if decision == DECISION_BLOCK:
                            raise GuardianSecurityViolation(
                                f"Guardian BLOCKED: Tool '{tool_name}' is not allowed. "
                                f"Reason: {decision_data.get('reason')}",
                                event_id=event_id,
                                decision=decision
                            )
                        
                        elif decision == DECISION_ASK:
                            approved = await wait_for_approval_func(event_id, tool_name)
                            if not approved:
                                raise GuardianSecurityViolation(
                                    f"Guardian DENIED: Tool '{tool_name}' was denied",
                                    event_id=event_id,
                                    decision=decision
                                )
            
            return response
        
        return wrapped_create


class ToolIntegrator:
    """
    Integrator for direct tool function wrapping.
    
    This class provides methods to wrap individual tool functions
    to intercept their execution before the tool runs.
    """
    
    @staticmethod
    def wrap_async_tool(
        tool_func: ToolFunc,
        context: Any,
        check_action_func: Callable,
        wait_for_approval_func: Callable,
        tool_name: str,
    ) -> ToolFunc:
        """
        Wrap an async tool function.
        
        Args:
            tool_func: The async tool function to wrap
            context: Agent context
            check_action_func: Function to check actions
            wait_for_approval_func: Function to wait for approval
            tool_name: Name of the tool
            
        Returns:
            Wrapped async function
        """
        @functools.wraps(tool_func)
        async def async_wrapper(*args, **kwargs):
            decision_data = await check_action_func(
                tool_name,
                {"args": args, "kwargs": kwargs}
            )
            
            if decision_data.get("decision") == DECISION_BLOCK:
                raise GuardianSecurityViolation(
                    f"Guardian BLOCKED: Tool '{tool_name}' is not allowed. "
                    f"Reason: {decision_data.get('reason')}",
                    event_id=decision_data.get("event_id"),
                    decision=decision_data.get("decision")
                )
            
            if decision_data.get("decision") == DECISION_ASK:
                event_id = decision_data.get("event_id")
                logger.info(f"Tool '{tool_name}' requires human approval (event: {event_id})")
                approved = await wait_for_approval_func(event_id, tool_name)
                if not approved:
                    raise GuardianSecurityViolation(
                        f"Guardian DENIED: Tool '{tool_name}' was denied by human review. "
                        f"Event ID: {event_id}",
                        event_id=event_id,
                        decision=decision_data.get("decision")
                    )
            
            return await tool_func(*args, **kwargs)
        
        return async_wrapper
    
    @staticmethod
    def wrap_sync_tool(
        tool_func: ToolFunc,
        context: Any,
        check_action_sync_func: Callable,
        tool_name: str,
    ) -> ToolFunc:
        """
        Wrap a sync tool function.
        
        Args:
            tool_func: The sync tool function to wrap
            context: Agent context
            check_action_sync_func: Function to check actions synchronously
            tool_name: Name of the tool
            
        Returns:
            Wrapped sync function
        """
        @functools.wraps(tool_func)
        def sync_wrapper(*args, **kwargs):
            decision_data = check_action_sync_func(
                tool_name,
                {"args": args, "kwargs": kwargs}
            )
            
            if decision_data.get("decision") == DECISION_BLOCK:
                raise GuardianSecurityViolation(
                    f"Guardian BLOCKED: Tool '{tool_name}' is not allowed. "
                    f"Reason: {decision_data.get('reason')}",
                    event_id=decision_data.get("event_id"),
                    decision=decision_data.get("decision")
                )
            
            if decision_data.get("decision") == DECISION_ASK:
                raise RuntimeError(
                    f"Guardian ASK: Tool '{tool_name}' requires human approval. "
                    f"Event ID: {decision_data.get('event_id')}. "
                    f"Please use async client for human-in-the-loop approval."
                )
            
            return tool_func(*args, **kwargs)
        
        return sync_wrapper


class InterceptorFactory:
    """
    Factory for creating appropriate interceptors based on client type.
    
    This class provides a unified interface for creating interceptors
    for different LLM clients (OpenAI, Anthropic) and tool functions.
    """
    
    @staticmethod
    def create_openai_interceptor(
        is_async: bool = True,
        enable_streaming: bool = True
    ) -> OpenAIIntegrator:
        """
        Create an OpenAI interceptor.
        
        Args:
            is_async: Whether the client is async
            enable_streaming: Whether to support streaming responses
            
        Returns:
            OpenAIIntegrator instance
        """
        return OpenAIIntegrator()
    
    @staticmethod
    def create_anthropic_interceptor() -> AnthropicIntegrator:
        """
        Create an Anthropic interceptor.
        
        Returns:
            AnthropicIntegrator instance
        """
        return AnthropicIntegrator()
    
    @staticmethod
    def create_tool_interceptor() -> ToolIntegrator:
        """
        Create a tool interceptor.
        
        Returns:
            ToolIntegrator instance
        """
        return ToolIntegrator()