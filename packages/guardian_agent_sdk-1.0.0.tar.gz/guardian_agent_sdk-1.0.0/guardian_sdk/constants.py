"""
Centralized constants for the Guardian SDK.

This module contains all default values, configuration limits,
and timeout settings used throughout the SDK.
"""

# ========== HTTP & Connection Defaults ==========
DEFAULT_BACKEND_URL = "http://localhost:8000"
DEFAULT_TIMEOUT_SECONDS = 30.0
DEFAULT_MAX_RETRIES = 3
DEFAULT_RETRY_DELAY_SECONDS = 1.0
DEFAULT_RETRY_BACKOFF_FACTOR = 2.0
DEFAULT_MAX_RETRY_DELAY_SECONDS = 30.0

# ========== Agent Configuration ==========
DEFAULT_AGENT_ID = "default-agent"
DEFAULT_FAIL_SAFE_DECISION = "allow"  # "allow" or "block"

# ========== Polling & Approval Settings ==========
DEFAULT_POLL_INTERVAL_SECONDS = 2.0
DEFAULT_MAX_POLL_SECONDS = 300.0  # 5 minutes
DEFAULT_APPROVAL_TIMEOUT_ACTION = "block"  # "block", "allow", "raise"

# ========== Telemetry Configuration ==========
DEFAULT_ENABLE_TELEMETRY = True
DEFAULT_TELEMETRY_SAMPLE_RATE = 0.1  # 10% of requests
DEFAULT_TELEMETRY_MAX_EVENTS = 1000
DEFAULT_TELEMETRY_FLUSH_INTERVAL_SECONDS = 60.0

# ========== Streaming Support ==========
DEFAULT_ENABLE_STREAMING_SUPPORT = True

# ========== HTTP Headers ==========
HEADER_API_KEY = "X-Guardian-API-Key"
HEADER_CONTENT_TYPE = "Content-Type"
HEADER_USER_AGENT = "User-Agent"

# ========== API Endpoints ==========
ENDPOINT_CHECK = "/api/v1/check"
ENDPOINT_EVENTS = "/api/v1/events"
ENDPOINT_EVENT_APPROVE = "/api/v1/events/{event_id}/approve"
ENDPOINT_EVENT_DENY = "/api/v1/events/{event_id}/deny"
ENDPOINT_TELEMETRY = "/api/v1/telemetry"

# ========== Decision Values ==========
DECISION_ALLOW = "allow"
DECISION_BLOCK = "block"
DECISION_ASK = "ask"
DECISION_HUMAN_APPROVED = "human_approved"
DECISION_HUMAN_DENIED = "human_denied"

# ========== HTTP Status Codes ==========
HTTP_STATUS_OK = 200
HTTP_STATUS_CREATED = 201
HTTP_STATUS_BAD_REQUEST = 400
HTTP_STATUS_UNAUTHORIZED = 401
HTTP_STATUS_FORBIDDEN = 403
HTTP_STATUS_NOT_FOUND = 404
HTTP_STATUS_TOO_MANY_REQUESTS = 429
HTTP_STATUS_INTERNAL_ERROR = 500

# ========== Rate Limiting ==========
RATE_LIMIT_RETRY_AFTER_HEADER = "Retry-After"
DEFAULT_RATE_LIMIT_WAIT_SECONDS = 60

# ========== Message Types (WebSocket) ==========
WS_MSG_TYPE_AUTH = "auth"
WS_MSG_TYPE_AUTH_JWT = "auth_jwt"
WS_MSG_TYPE_PING = "ping"
WS_MSG_TYPE_PONG = "pong"
WS_MSG_TYPE_NEW_EVENT = "new_event"
WS_MSG_TYPE_EVENT_UPDATED = "event_updated"
WS_MSG_TYPE_AGENT_STATUS = "agent_status"