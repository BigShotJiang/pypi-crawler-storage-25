"""
Guardian Agent Python SDK - Production Ready

This SDK provides security interception for AI agents with:
- Per-client agent ID isolation (no shared config mutation)
- Streaming response support (full chunk reassembly)
- Direct tool wrapping (before LLM call)
- Async/sync support with consistent patterns
- Non-blocking telemetry with background worker
- Configurable timeout fail-safe for approval polling
- Environment variable support for cloud deployment
- Full Anthropic SDK support

Usage:
    from openai import AsyncOpenAI
    from guardian_sdk import GuardianClient
    
    # Use environment variables for configuration
    sdk = GuardianClient()  # Reads GUARDIAN_API_KEY, GUARDIAN_BACKEND_URL from env
    
    # Or explicit config
    sdk = GuardianClient({
        "api_key": "your_key",
        "backend_url": "https://guardian.example.com",
        "default_agent_id": "my-agent"
    })
    
    # Wrap OpenAI client
    client = sdk.wrap_openai(AsyncOpenAI(api_key="sk-..."), agent_id="my-agent")
"""

import asyncio
import json
import logging
import random
import time
import functools
import uuid
import os
from typing import Any, Dict, List, Optional, Callable, TypeVar, ParamSpec, Union, AsyncIterator, Iterator
from enum import Enum
from dataclasses import dataclass, field
from contextlib import asynccontextmanager

import httpx

# Configure logger
logger = logging.getLogger(__name__)

# Type variables
ClientType = TypeVar("ClientType")
P = ParamSpec("P")
R = TypeVar("R")
ToolFunc = TypeVar("ToolFunc", bound=Callable)


class Decision(str, Enum):
    """Policy decision outcomes."""
    ALLOW = "allow"
    BLOCK = "block"
    ASK = "ask"


class ApprovalTimeoutAction(str, Enum):
    """Action to take when approval polling times out."""
    BLOCK = "block"  # Deny by default (safe option)
    ALLOW = "allow"  # Allow by default (risky, use with caution)
    RAISE = "raise"  # Raise an exception


@dataclass
class GuardianConfig:
    """Configuration for the Guardian SDK."""
    api_key: Optional[str] = None
    backend_url: Optional[str] = None
    default_agent_id: str = "default-agent"
    timeout_seconds: float = 30.0
    max_retries: int = 3
    retry_delay_seconds: float = 1.0
    fail_safe_decision: str = "allow"  # "allow" or "block"
    poll_interval_seconds: float = 2.0
    max_poll_seconds: float = 300.0  # 5 minutes
    approval_timeout_action: ApprovalTimeoutAction = ApprovalTimeoutAction.BLOCK
    enable_telemetry: bool = True
    telemetry_sample_rate: float = 0.1
    telemetry_max_events: int = 1000
    telemetry_flush_interval_seconds: float = 60.0
    enable_streaming_support: bool = True
    
    def __post_init__(self):
        """Load from environment variables if not provided."""
        if self.api_key is None:
            self.api_key = os.getenv("GUARDIAN_API_KEY")
        if self.backend_url is None:
            self.backend_url = os.getenv("GUARDIAN_BACKEND_URL", "http://localhost:8000")
        
        if not self.api_key:
            raise ValueError(
                "GUARDIAN_API_KEY must be provided either in config or as environment variable"
            )


class TelemetryCollector:
    """
    Collects and sends telemetry data (if enabled).
    
    Features:
    - Random sampling to reduce data volume
    - Auto-flush when max events reached
    - Periodic flush based on time interval
    - Non-blocking background flush
    """
    
    def __init__(
        self, 
        enabled: bool = True, 
        sample_rate: float = 0.1,
        max_events: int = 1000,
        flush_interval_seconds: float = 60.0
    ):
        self.enabled = enabled
        self.sample_rate = sample_rate
        self.max_events = max_events
        self.flush_interval_seconds = flush_interval_seconds
        self._events: List[Dict[str, Any]] = []
        self._session_id = str(uuid.uuid4())
        self._last_flush_time = time.time()
        self._flush_callback: Optional[Callable[[List[Dict[str, Any]]], None]] = None
        self._background_task: Optional[asyncio.Task] = None
        self._stop_background = False
    
    def set_flush_callback(self, callback: Callable[[List[Dict[str, Any]]], None]) -> None:
        """Set a callback to be called when events are flushed."""
        self._flush_callback = callback
    
    def start_background_flusher(self) -> None:
        """Start background task for periodic flushing."""
        if not self.enabled or self._background_task:
            return
        
        async def background_flusher():
            while not self._stop_background:
                await asyncio.sleep(self.flush_interval_seconds)
                if self._events:
                    self.flush()
        
        self._background_task = asyncio.create_task(background_flusher())
    
    async def stop_background_flusher(self) -> None:
        """Stop the background flusher task."""
        self._stop_background = True
        if self._background_task:
            self._background_task.cancel()
            try:
                await self._background_task
            except asyncio.CancelledError:
                pass
            self._background_task = None
    
    def should_record(self) -> bool:
        """Determine if this request should be recorded based on sample rate."""
        if not self.enabled:
            return False
        return random.random() < self.sample_rate
    
    def _check_and_flush(self) -> None:
        """Check if we should flush based on size only (time-based is handled by background)."""
        if len(self._events) >= self.max_events:
            logger.debug(f"Telemetry: Flushing due to size limit ({len(self._events)} events)")
            self.flush()
    
    def record_check(
        self, 
        tool_name: str, 
        decision: str, 
        latency_ms: float, 
        error: Optional[str] = None
    ) -> None:
        """Record a check event."""
        if not self.should_record():
            return
        
        self._events.append({
            "type": "check",
            "session_id": self._session_id,
            "tool_name": tool_name,
            "decision": decision,
            "latency_ms": latency_ms,
            "error": error,
            "timestamp": time.time()
        })
        
        self._check_and_flush()
    
    def flush(self) -> List[Dict[str, Any]]:
        """
        Flush collected events to the callback (non-blocking).
        
        Returns:
            The events that were flushed (or empty list if no callback)
        """
        if not self._events:
            return []
        
        events_to_flush = self._events.copy()
        self._events = []
        self._last_flush_time = time.time()
        
        if self._flush_callback:
            # Non-blocking: fire and forget
            asyncio.create_task(self._async_flush(events_to_flush))
        
        return events_to_flush
    
    async def _async_flush(self, events: List[Dict[str, Any]]) -> None:
        """Asynchronously flush events without blocking the main task."""
        try:
            if self._flush_callback:
                await self._flush_callback(events) if asyncio.iscoroutinefunction(self._flush_callback) else self._flush_callback(events)
        except Exception as e:
            logger.error(f"Telemetry flush failed: {e}")
    
    def get_events(self) -> List[Dict[str, Any]]:
        """Get all recorded events (without flushing)."""
        return self._events.copy()
    
    def clear(self) -> None:
        """Clear all recorded events without flushing."""
        self._events = []
        self._last_flush_time = time.time()


class StreamingChunkCollector:
    """
    Collects and reassembles streaming chunks from OpenAI.
    
    This enables full interception of tool calls in streaming mode.
    """
    
    def __init__(self):
        self.chunks: List[Dict[str, Any]] = []
        self.tool_call_buffer: Dict[int, Dict[str, Any]] = {}
    
    def add_chunk(self, chunk: Any) -> Any:
        """Add a chunk and check if we have a complete tool call."""
        self.chunks.append(chunk)
        
        # Check for tool calls in this chunk
        if hasattr(chunk, 'choices') and chunk.choices:
            delta = chunk.choices[0].delta
            
            if hasattr(delta, 'tool_calls') and delta.tool_calls:
                for tool_call in delta.tool_calls:
                    idx = tool_call.index
                    
                    if idx not in self.tool_call_buffer:
                        self.tool_call_buffer[idx] = {
                            "name": "",
                            "arguments": ""
                        }
                    
                    if hasattr(tool_call, 'function'):
                        if hasattr(tool_call.function, 'name') and tool_call.function.name:
                            self.tool_call_buffer[idx]["name"] = tool_call.function.name
                        if hasattr(tool_call.function, 'arguments') and tool_call.function.arguments:
                            self.tool_call_buffer[idx]["arguments"] += tool_call.function.arguments
        
        return chunk
    
    def get_complete_tool_calls(self) -> List[Dict[str, Any]]:
        """Get fully assembled tool calls from streamed chunks."""
        tool_calls = []
        for idx, data in self.tool_call_buffer.items():
            if data["name"] and data["arguments"]:
                try:
                    arguments = json.loads(data["arguments"])
                    tool_calls.append({
                        "name": data["name"],
                        "arguments": arguments
                    })
                except json.JSONDecodeError:
                    # Still incomplete
                    pass
        return tool_calls
    
    def is_complete(self) -> bool:
        """Check if all tool calls are complete."""
        for data in self.tool_call_buffer.values():
            if data["name"] and data["arguments"]:
                try:
                    json.loads(data["arguments"])
                except json.JSONDecodeError:
                    return False
        return True


class AgentContext:
    """Holds context for a specific agent wrapper."""
    
    def __init__(
        self,
        parent_client: "GuardianClient",
        agent_id: str,
        fail_safe_decision: Optional[str] = None
    ):
        self.parent = parent_client
        self.agent_id = agent_id
        self.fail_safe_decision = fail_safe_decision or parent_client.config.fail_safe_decision
        self._pending_approvals: Dict[str, asyncio.Future] = {}
    
    @property
    def config(self) -> GuardianConfig:
        return self.parent.config
    
    async def check_action(
        self,
        tool_name: str,
        tool_input: Dict[str, Any],
        retry_count: int = 0
    ) -> Dict[str, Any]:
        return await self.parent._check_action(
            tool_name=tool_name,
            tool_input=tool_input,
            agent_id=self.agent_id,
            retry_count=retry_count
        )
    
    def check_action_sync(
        self,
        tool_name: str,
        tool_input: Dict[str, Any],
        retry_count: int = 0
    ) -> Dict[str, Any]:
        return self.parent._check_action_sync(
            tool_name=tool_name,
            tool_input=tool_input,
            agent_id=self.agent_id,
            retry_count=retry_count
        )
    
    async def wait_for_approval(self, event_id: str, tool_name: str) -> bool:
        return await self.parent._wait_for_approval(event_id, tool_name)


class GuardianClient:
    """
    Guardian SDK client for intercepting AI tool calls.
    
    Features:
    - Per-agent context isolation
    - Full streaming support with chunk reassembly
    - Direct tool wrapping
    - Async/sync support
    - Non-blocking telemetry
    - Configurable approval timeout actions
    - Environment variable configuration
    """
    
    def __init__(self, config: Union[GuardianConfig, Dict[str, Any], None] = None):
        """
        Initialize the Guardian SDK client.
        
        Args:
            config: Either a GuardianConfig object, dictionary, or None (uses env vars)
            
        Example:
            # Using environment variables
            sdk = GuardianClient()
            
            # Using dictionary
            sdk = GuardianClient({
                "api_key": "your_key",
                "backend_url": "https://guardian.example.com"
            })
        """
        if config is None:
            self.config = GuardianConfig()
        elif isinstance(config, dict):
            self.config = GuardianConfig(**config)
        else:
            self.config = config
        
        self._http_client: Optional[httpx.AsyncClient] = None
        self._sync_http_client: Optional[httpx.Client] = None
        self._telemetry = TelemetryCollector(
            enabled=self.config.enable_telemetry,
            sample_rate=self.config.telemetry_sample_rate,
            max_events=self.config.telemetry_max_events,
            flush_interval_seconds=self.config.telemetry_flush_interval_seconds
        )
        self._telemetry.set_flush_callback(self._flush_telemetry)
        self._telemetry.start_background_flusher()
        self._stats = {
            "total_checks": 0,
            "allowed": 0,
            "blocked": 0,
            "pending": 0,
            "errors": 0,
        }
    
    def _create_context(self, agent_id: str, fail_safe_decision: Optional[str] = None) -> AgentContext:
        return AgentContext(self, agent_id, fail_safe_decision)
    
    async def _flush_telemetry(self, events: List[Dict[str, Any]]) -> None:
        """Send telemetry events to backend (non-blocking)."""
        if not events:
            return
        
        # Fire and forget - don't await
        asyncio.create_task(self._send_telemetry_async(events))
    
    async def _send_telemetry_async(self, events: List[Dict[str, Any]]) -> None:
        """Actually send telemetry without blocking the main flow."""
        try:
            await self.http_client.post(
                f"{self.config.backend_url}/api/v1/telemetry",
                json={"events": events, "session_id": self._telemetry._session_id},
                headers={"X-Guardian-API-Key": self.config.api_key},
                timeout=5.0
            )
            logger.debug(f"Telemetry: Sent {len(events)} events to backend")
        except Exception as e:
            logger.warning(f"Telemetry: Failed to send events: {e}")
    
    @property
    def http_client(self) -> httpx.AsyncClient:
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(
                timeout=self.config.timeout_seconds,
                limits=httpx.Limits(max_keepalive_connections=20),
            )
        return self._http_client
    
    @property
    def sync_http_client(self) -> httpx.Client:
        if self._sync_http_client is None:
            self._sync_http_client = httpx.Client(
                timeout=self.config.timeout_seconds,
                limits=httpx.Limits(max_keepalive_connections=20),
            )
        return self._sync_http_client
    
    def _update_stats(self, decision: str) -> None:
        self._stats["total_checks"] += 1
        if decision == "allow":
            self._stats["allowed"] += 1
        elif decision == "block":
            self._stats["blocked"] += 1
        elif decision == "ask":
            self._stats["pending"] += 1
    
    async def _check_action(
        self,
        tool_name: str,
        tool_input: Dict[str, Any],
        agent_id: str,
        retry_count: int = 0
    ) -> Dict[str, Any]:
        start_time = time.time()
        error = None
        
        try:
            response = await self.http_client.post(
                f"{self.config.backend_url}/api/v1/check",
                json={
                    "agent_id": agent_id,
                    "tool_name": tool_name,
                    "tool_input": tool_input
                },
                headers={
                    "X-Guardian-API-Key": self.config.api_key,
                    "Content-Type": "application/json",
                    "User-Agent": f"Guardian-Agent-SDK/{self.__class__.__name__}"
                }
            )
            response.raise_for_status()
            result = response.json()
            
            decision = result.get("decision", "unknown")
            self._update_stats(decision)
            
            latency_ms = (time.time() - start_time) * 1000
            self._telemetry.record_check(tool_name, decision, latency_ms)
            
            logger.debug(
                f"Check result for {tool_name}: {decision} "
                f"(event_id: {result.get('event_id')}, latency: {latency_ms:.2f}ms)"
            )
            
            return result
            
        except httpx.TimeoutException as e:
            error = f"Timeout: {e}"
            logger.warning(f"Timeout checking action {tool_name}: {e}")
            if retry_count < self.config.max_retries:
                delay = self.config.retry_delay_seconds * (2 ** retry_count)
                await asyncio.sleep(delay)
                return await self._check_action(tool_name, tool_input, agent_id, retry_count + 1)
            
        except httpx.RequestError as e:
            error = f"RequestError: {e}"
            logger.error(f"Request error checking action {tool_name}: {e}")
            
        except httpx.HTTPStatusError as e:
            error = f"HTTP {e.response.status_code}"
            logger.error(f"HTTP {e.response.status_code} checking action {tool_name}")
            
            if 400 <= e.response.status_code < 500 and e.response.status_code != 429:
                self._stats["errors"] += 1
                latency_ms = (time.time() - start_time) * 1000
                self._telemetry.record_check(tool_name, "error", latency_ms, error)
                return {
                    "decision": self.config.fail_safe_decision,
                    "reason": f"Client error: {e.response.status_code}",
                    "event_id": None
                }
            
            if retry_count < self.config.max_retries:
                delay = self.config.retry_delay_seconds * (2 ** retry_count)
                await asyncio.sleep(delay)
                return await self._check_action(tool_name, tool_input, agent_id, retry_count + 1)
            
        except Exception as e:
            error = str(e)
            logger.exception(f"Unexpected error checking action {tool_name}: {e}")
        
        self._stats["errors"] += 1
        latency_ms = (time.time() - start_time) * 1000
        self._telemetry.record_check(tool_name, "error", latency_ms, error)
        
        return {
            "decision": self.config.fail_safe_decision,
            "reason": f"Error: {error}",
            "event_id": None
        }
    
    def _check_action_sync(
        self,
        tool_name: str,
        tool_input: Dict[str, Any],
        agent_id: str,
        retry_count: int = 0
    ) -> Dict[str, Any]:
        start_time = time.time()
        error = None
        
        try:
            response = self.sync_http_client.post(
                f"{self.config.backend_url}/api/v1/check",
                json={
                    "agent_id": agent_id,
                    "tool_name": tool_name,
                    "tool_input": tool_input
                },
                headers={
                    "X-Guardian-API-Key": self.config.api_key,
                    "Content-Type": "application/json"
                }
            )
            response.raise_for_status()
            result = response.json()
            
            decision = result.get("decision", "unknown")
            self._update_stats(decision)
            
            latency_ms = (time.time() - start_time) * 1000
            self._telemetry.record_check(tool_name, decision, latency_ms)
            
            return result
            
        except Exception as e:
            error = str(e)
            logger.error(f"Error checking action {tool_name}: {e}")
            self._stats["errors"] += 1
            latency_ms = (time.time() - start_time) * 1000
            self._telemetry.record_check(tool_name, "error", latency_ms, error)
            
            return {
                "decision": self.config.fail_safe_decision,
                "reason": f"Error: {error}",
                "event_id": None
            }
    
    async def _wait_for_approval(self, event_id: str, tool_name: str) -> bool:
        """
        Wait for human approval of a pending action.
        
        Features:
        - Configurable timeout action (block/allow/raise)
        - Non-blocking polling with asyncio.sleep
        - Graceful timeout handling
        """
        start_time = time.time()
        
        while time.time() - start_time < self.config.max_poll_seconds:
            try:
                response = await self.http_client.get(
                    f"{self.config.backend_url}/api/v1/events/{event_id}",
                    headers={"X-Guardian-API-Key": self.config.api_key}
                )
                
                if response.status_code == 200:
                    event = response.json()
                    decision = event.get("decision")
                    
                    if decision in ("human_approved", "allow"):
                        logger.info(f"Action {tool_name} approved (event: {event_id})")
                        return True
                    elif decision in ("human_denied", "block"):
                        logger.info(f"Action {tool_name} denied (event: {event_id})")
                        return False
                    
                await asyncio.sleep(self.config.poll_interval_seconds)
                
            except Exception as e:
                logger.warning(f"Error polling approval status: {e}")
                await asyncio.sleep(self.config.poll_interval_seconds)
        
        # Timeout reached - apply configured action
        logger.warning(f"Approval timeout for {tool_name} after {self.config.max_poll_seconds}s")
        
        if self.config.approval_timeout_action == ApprovalTimeoutAction.ALLOW:
            logger.info(f"Approval timeout: allowing {tool_name} (configured action: ALLOW)")
            return True
        elif self.config.approval_timeout_action == ApprovalTimeoutAction.RAISE:
            raise TimeoutError(
                f"Approval timeout for {tool_name} (event: {event_id}) after "
                f"{self.config.max_poll_seconds}s. Configured action: RAISE"
            )
        else:  # BLOCK by default
            logger.info(f"Approval timeout: denying {tool_name} (configured action: BLOCK)")
            return False
    
    # ========== Streaming OpenAI Wrapper ==========
    
    async def _wrap_openai_streaming_create(
        self,
        original_create: Callable[P, R],
        context: AgentContext,
        *args: P.args,
        **kwargs: P.kwargs
    ) -> AsyncIterator[Any]:
        """
        Wrap streaming OpenAI responses to intercept tool calls.
        
        Collects chunks, reassembles tool calls, validates, then yields chunks.
        """
        collector = StreamingChunkCollector()
        
        # Start streaming
        stream = await original_create(*args, **kwargs)
        
        async for chunk in stream:
            # Add to collector and check for complete tool calls
            collector.add_chunk(chunk)
            
            # If we have complete tool calls, validate them
            if collector.is_complete():
                tool_calls = collector.get_complete_tool_calls()
                for tool_call in tool_calls:
                    decision_data = await context.check_action(
                        tool_call["name"],
                        tool_call["arguments"]
                    )
                    
                    if decision_data.get("decision") == Decision.BLOCK.value:
                        raise PermissionError(
                            f"Guardian BLOCKED: Tool '{tool_call['name']}' blocked in streaming mode"
                        )
                    
                    if decision_data.get("decision") == Decision.ASK.value:
                        approved = await context.wait_for_approval(
                            decision_data.get("event_id"),
                            tool_call["name"]
                        )
                        if not approved:
                            raise PermissionError(
                                f"Guardian DENIED: Tool '{tool_call['name']}' denied in streaming mode"
                            )
            
            yield chunk
    
    def _wrap_openai_async_create(self, original_create: Callable[P, R], context: AgentContext) -> Callable[P, R]:
        """Wraps async OpenAI chat.completions.create to intercept tool calls."""
        
        @functools.wraps(original_create)
        async def guarded_create(*args: P.args, **kwargs: P.kwargs) -> R:
            is_streaming = kwargs.get("stream", False)
            
            if is_streaming and self.config.enable_streaming_support:
                # Return an async generator that intercepts tool calls
                async def streaming_wrapper():
                    async for chunk in self._wrap_openai_streaming_create(
                        original_create, context, *args, **kwargs
                    ):
                        yield chunk
                return streaming_wrapper()
            
            # Non-streaming: standard interception
            response = await original_create(*args, **kwargs)
            
            if hasattr(response, 'choices') and response.choices:
                message = response.choices[0].message
                
                if hasattr(message, 'tool_calls') and message.tool_calls:
                    for tool_call in message.tool_calls:
                        tool_name = tool_call.function.name
                        
                        try:
                            tool_args = json.loads(tool_call.function.arguments)
                        except json.JSONDecodeError:
                            logger.warning(f"Could not parse tool arguments for {tool_name}")
                            tool_args = {"raw_arguments": tool_call.function.arguments}
                        
                        decision_data = await context.check_action(tool_name, tool_args)
                        decision = decision_data.get("decision")
                        event_id = decision_data.get("event_id")
                        reason = decision_data.get("reason", "No reason provided")
                        
                        if decision == Decision.BLOCK.value:
                            raise PermissionError(
                                f"Guardian BLOCKED: Tool '{tool_name}' is not allowed. "
                                f"Reason: {reason} (Event ID: {event_id})"
                            )
                        
                        elif decision == Decision.ASK.value:
                            logger.info(f"Action {tool_name} requires human approval (event: {event_id})")
                            approved = await context.wait_for_approval(event_id, tool_name)
                            
                            if not approved:
                                raise PermissionError(
                                    f"Guardian DENIED: Tool '{tool_name}' was denied by human review. "
                                    f"Reason: {reason} (Event ID: {event_id})"
                                )
            
            return response
        
        return guarded_create
    
    def _wrap_openai_sync_create(self, original_create: Callable[P, R], context: AgentContext) -> Callable[P, R]:
        """Wraps sync OpenAI chat.completions.create to intercept tool calls."""
        
        @functools.wraps(original_create)
        def guarded_create(*args: P.args, **kwargs: P.kwargs) -> R:
            is_streaming = kwargs.get("stream", False)
            
            if is_streaming:
                logger.warning(
                    "Streaming interception requires async client. "
                    "Use AsyncOpenAI for full streaming support."
                )
                return original_create(*args, **kwargs)
            
            response = original_create(*args, **kwargs)
            
            if hasattr(response, 'choices') and response.choices:
                message = response.choices[0].message
                
                if hasattr(message, 'tool_calls') and message.tool_calls:
                    for tool_call in message.tool_calls:
                        tool_name = tool_call.function.name
                        
                        try:
                            tool_args = json.loads(tool_call.function.arguments)
                        except json.JSONDecodeError:
                            tool_args = {"raw_arguments": tool_call.function.arguments}
                        
                        decision_data = context.check_action_sync(tool_name, tool_args)
                        decision = decision_data.get("decision")
                        event_id = decision_data.get("event_id")
                        reason = decision_data.get("reason")
                        
                        if decision == Decision.BLOCK.value:
                            raise PermissionError(
                                f"Guardian BLOCKED: Tool '{tool_name}' is not allowed. "
                                f"Reason: {reason} (Event ID: {event_id})"
                            )
                        
                        elif decision == Decision.ASK.value:
                            raise RuntimeError(
                                f"Guardian ASK: Tool '{tool_name}' requires human approval. "
                                f"Event ID: {event_id}. "
                                f"Sync mode cannot poll for approvals. "
                                f"Please use async client (wrap_openai with AsyncOpenAI) "
                                f"if you need human-in-the-loop approval."
                            )
            
            return response
        
        return guarded_create
    
    def wrap_openai(
        self,
        client: Any,
        agent_id: Optional[str] = None,
        sync: bool = False
    ) -> Any:
        """Wrap an OpenAI client with Guardian interception."""
        context = self._create_context(
            agent_id or self.config.default_agent_id,
            None
        )
        
        if not hasattr(client, "chat") or not hasattr(client.chat, "completions"):
            raise ValueError("OpenAI client does not have chat.completions attribute")
        
        create_method = getattr(client.chat.completions, "create", None)
        if not create_method:
            raise ValueError("OpenAI client does not have chat.completions.create method")
        
        is_async = not sync and asyncio.iscoroutinefunction(create_method)
        
        if is_async:
            client.chat.completions.create = self._wrap_openai_async_create(create_method, context)
            logger.info(f"Wrapped async OpenAI client for agent: {context.agent_id}")
        else:
            client.chat.completions.create = self._wrap_openai_sync_create(create_method, context)
            logger.info(f"Wrapped sync OpenAI client for agent: {context.agent_id}")
        
        return client
    
    # ========== Tool Wrapping ==========
    
    def wrap_tool(
        self,
        tool_func: ToolFunc,
        agent_id: str,
        tool_name: Optional[str] = None,
        fail_safe_decision: Optional[str] = None
    ) -> ToolFunc:
        """Wrap a single tool function to intercept its execution."""
        context = self._create_context(agent_id, fail_safe_decision)
        actual_tool_name = tool_name or tool_func.__name__
        
        if asyncio.iscoroutinefunction(tool_func):
            @functools.wraps(tool_func)
            async def async_wrapper(*args, **kwargs):
                decision_data = await context.check_action(
                    actual_tool_name,
                    {"args": args, "kwargs": kwargs}
                )
                
                if decision_data.get("decision") == Decision.BLOCK.value:
                    raise PermissionError(
                        f"Guardian BLOCKED: Tool '{actual_tool_name}' is not allowed. "
                        f"Reason: {decision_data.get('reason')}"
                    )
                
                if decision_data.get("decision") == Decision.ASK.value:
                    event_id = decision_data.get("event_id")
                    logger.info(f"Tool '{actual_tool_name}' requires human approval (event: {event_id})")
                    approved = await context.wait_for_approval(event_id, actual_tool_name)
                    if not approved:
                        raise PermissionError(
                            f"Guardian DENIED: Tool '{actual_tool_name}' was denied by human review. "
                            f"Event ID: {event_id}"
                        )
                
                return await tool_func(*args, **kwargs)
            return async_wrapper
        
        else:
            @functools.wraps(tool_func)
            def sync_wrapper(*args, **kwargs):
                decision_data = context.check_action_sync(
                    actual_tool_name,
                    {"args": args, "kwargs": kwargs}
                )
                
                if decision_data.get("decision") == Decision.BLOCK.value:
                    raise PermissionError(
                        f"Guardian BLOCKED: Tool '{actual_tool_name}' is not allowed. "
                        f"Reason: {decision_data.get('reason')}"
                    )
                
                if decision_data.get("decision") == Decision.ASK.value:
                    raise RuntimeError(
                        f"Guardian ASK: Tool '{actual_tool_name}' requires human approval. "
                        f"Event ID: {decision_data.get('event_id')}. "
                        f"Please use async client for human-in-the-loop approval."
                    )
                
                return tool_func(*args, **kwargs)
            return sync_wrapper
    
    def wrap_tools(
        self,
        tools: Dict[str, Callable],
        agent_id: str,
        fail_safe_decision: Optional[str] = None
    ) -> Dict[str, Callable]:
        """Wrap multiple tool functions at once."""
        return {
            name: self.wrap_tool(func, agent_id, name, fail_safe_decision)
            for name, func in tools.items()
        }
    
    # ========== Anthropic Wrapper ==========
    
    def _wrap_anthropic_async_create(self, original_create: Callable[P, R], context: AgentContext) -> Callable[P, R]:
        """Wraps async Anthropic messages.create to intercept tool calls."""
        
        @functools.wraps(original_create)
        async def guarded_create(*args: P.args, **kwargs: P.kwargs) -> R:
            response = await original_create(*args, **kwargs)
            
            if hasattr(response, 'content'):
                for block in response.content:
                    if hasattr(block, 'type') and block.type == 'tool_use':
                        tool_name = block.name
                        tool_args = block.input if hasattr(block, 'input') else {}
                        
                        decision_data = await context.check_action(tool_name, tool_args)
                        decision = decision_data.get("decision")
                        
                        if decision == Decision.BLOCK.value:
                            raise PermissionError(
                                f"Guardian BLOCKED: Tool '{tool_name}' is not allowed. "
                                f"Reason: {decision_data.get('reason')}"
                            )
                        
                        elif decision == Decision.ASK.value:
                            approved = await context.wait_for_approval(
                                decision_data.get("event_id"),
                                tool_name
                            )
                            if not approved:
                                raise PermissionError(
                                    f"Guardian DENIED: Tool '{tool_name}' was denied"
                                )
            
            return response
        
        return guarded_create
    
    def wrap_anthropic(
        self,
        client: Any,
        agent_id: Optional[str] = None
    ) -> Any:
        """Wrap an Anthropic client with Guardian interception."""
        context = self._create_context(
            agent_id or self.config.default_agent_id,
            None
        )
        
        if not hasattr(client, "messages") or not hasattr(client.messages, "create"):
            raise ValueError("Anthropic client does not have messages.create method")
        
        create_method = getattr(client.messages, "create", None)
        if not create_method:
            raise ValueError("Anthropic client does not have messages.create method")
        
        if asyncio.iscoroutinefunction(create_method):
            client.messages.create = self._wrap_anthropic_async_create(create_method, context)
            logger.info(f"Wrapped async Anthropic client for agent: {context.agent_id}")
        else:
            logger.warning("Sync Anthropic client not fully tested. Use async for production.")
        
        return client
    
    # ========== Generic Wrapper ==========
    
    def wrap(
        self,
        client: Any,
        client_type: str,
        agent_id: Optional[str] = None
    ) -> Any:
        """Generic wrapper for any supported client."""
        if client_type.lower() == "openai":
            return self.wrap_openai(client, agent_id)
        elif client_type.lower() == "anthropic":
            return self.wrap_anthropic(client, agent_id)
        else:
            raise ValueError(f"Unsupported client type: {client_type}")
    
    # ========== Lifecycle Management ==========
    
    async def flush_telemetry(self) -> None:
        """Manually flush telemetry events to the backend."""
        self._telemetry.flush()
    
    async def close(self) -> None:
        """Close HTTP client connections and flush telemetry."""
        await self._telemetry.stop_background_flusher()
        await self.flush_telemetry()
        
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None
        
        if self._sync_http_client:
            self._sync_http_client.close()
            self._sync_http_client = None
    
    def get_stats(self) -> Dict[str, Any]:
        """Get SDK statistics."""
        return {
            **self._stats,
            "telemetry": {
                "enabled": self.config.enable_telemetry,
                "events_recorded": len(self._telemetry.get_events()),
                "sample_rate": self.config.telemetry_sample_rate,
                "max_events": self.config.telemetry_max_events,
                "flush_interval_seconds": self.config.telemetry_flush_interval_seconds,
            },
            "config": {
                "backend_url": self.config.backend_url,
                "default_agent_id": self.config.default_agent_id,
                "timeout_seconds": self.config.timeout_seconds,
                "fail_safe_decision": self.config.fail_safe_decision,
                "approval_timeout_action": self.config.approval_timeout_action.value,
            }
        }
    
    def get_telemetry(self) -> List[Dict[str, Any]]:
        """Get recorded telemetry events (without flushing)."""
        return self._telemetry.get_events()
    
    def reset_stats(self) -> None:
        """Reset statistics."""
        self._stats = {
            "total_checks": 0,
            "allowed": 0,
            "blocked": 0,
            "pending": 0,
            "errors": 0,
        }
        self._telemetry.clear()


@asynccontextmanager
async def create_guardian_client(config: Union[GuardianConfig, Dict[str, Any], None] = None):
    """Context manager for GuardianClient that ensures proper cleanup."""
    client = GuardianClient(config)
    try:
        yield client
    finally:
        await client.close()


# ========== Example Usage ==========

if __name__ == "__main__":
    async def demo():
        print("Guardian SDK - Production Ready Demo")
        print("=" * 50)
        
        # Using environment variables (recommended)
        os.environ["GUARDIAN_API_KEY"] = "test_key"
        os.environ["GUARDIAN_BACKEND_URL"] = "http://localhost:8000"
        
        sdk = GuardianClient()
        print("✓ SDK initialized from environment variables")
        
        # Example: Wrap an async tool
        async def async_send_email(to: str, subject: str) -> dict:
            return {"sent": True, "to": to}
        
        wrapped_email = sdk.wrap_tool(async_send_email, agent_id="email-agent")
        print("✓ Async tool wrapped (supports ASK polling)")
        
        print(f"\nStats: {sdk.get_stats()}")
        
        await sdk.close()
        print("\n✓ Demo complete")
    
    asyncio.run(demo())