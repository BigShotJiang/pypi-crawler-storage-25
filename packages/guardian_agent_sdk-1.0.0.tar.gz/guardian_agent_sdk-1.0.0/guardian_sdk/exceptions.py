"""
Custom exceptions for Guardian SDK.

Provides a clear hierarchy of exceptions for different error scenarios:
- Configuration errors (API key missing, invalid URLs)
- Connection errors (backend unreachable, network issues)
- Security violations (blocked actions, approval required)
- Timeout errors (approval polling timeout)
"""


class GuardianSDKException(Exception):
    """
    Base exception for all Guardian SDK errors.
    
    All other exceptions inherit from this class, allowing users to catch
    any Guardian-specific error with a single except block if desired.
    
    Example:
        try:
            result = client.check_action(...)
        except GuardianSDKException as e:
            print(f"Guardian SDK error: {e}")
    """
    pass


class GuardianConfigurationError(GuardianSDKException):
    """
    Raised when the SDK is improperly configured.
    
    Common causes:
    - Missing or invalid API key
    - Invalid backend URL format
    - Missing required environment variables
    
    Example:
        >>> config = GuardianConfig(API_KEY=None)
        Traceback (most recent call last):
        GuardianConfigurationError: GUARDIAN_API_KEY must be provided
    """
    
    def __init__(self, message: str, config_key: str = None, provided_value: str = None):
        """
        Initialize a configuration error.
        
        Args:
            message: Human-readable error message
            config_key: The configuration key that caused the error (e.g., "API_KEY")
            provided_value: The invalid value that was provided (redacted for security)
        """
        super().__init__(message)
        self.config_key = config_key
        self.provided_value = provided_value
        
    def __str__(self) -> str:
        """Return a formatted error message with configuration context."""
        base = super().__str__()
        if self.config_key:
            return f"[Configuration Error: {self.config_key}] {base}"
        return base


class GuardianConnectionError(GuardianSDKException):
    """
    Raised when the SDK cannot connect to the Guardian Backend.
    
    Common causes:
    - Backend server not running
    - Network issues (firewall, DNS, routing)
    - Invalid backend URL
    - Timeout during connection
    
    Example:
        >>> await client.check_action(...)
        Traceback (most recent call last):
        GuardianConnectionError: Failed to connect to backend at http://localhost:8000
    """
    
    def __init__(
        self,
        message: str,
        url: str = None,
        status_code: int = None,
        retry_count: int = None
    ):
        """
        Initialize a connection error.
        
        Args:
            message: Human-readable error message
            url: The backend URL that failed to connect
            status_code: HTTP status code if available
            retry_count: Number of retry attempts made
        """
        super().__init__(message)
        self.url = url
        self.status_code = status_code
        self.retry_count = retry_count
        
    def __str__(self) -> str:
        """Return a formatted error message with connection context."""
        base = super().__str__()
        parts = []
        if self.url:
            parts.append(f"URL: {self.url}")
        if self.status_code:
            parts.append(f"Status: {self.status_code}")
        if self.retry_count:
            parts.append(f"Retries: {self.retry_count}")
        
        if parts:
            return f"{base} ({', '.join(parts)})"
        return base


class GuardianSecurityViolation(GuardianSDKException):
    """
    Raised when the Guardian Policy Engine blocks an action or requires human approval.
    
    This is the most important exception for security monitoring. It indicates that
    an AI agent attempted an action that was either:
    - BLOCKED: Explicitly denied by a policy (e.g., DROP TABLE)
    - ASK: Requires human review (the SDK may wait or raise based on configuration)
    
    Example:
        >>> await client.check_action("execute_sql", {"query": "DROP TABLE users"})
        Traceback (most recent call last):
        GuardianSecurityViolation: Action blocked by policy: destructive_sql_blocked
        Event ID: evt_abc123
        Decision: block
    """
    
    def __init__(
        self,
        message: str,
        event_id: str = None,
        decision: str = None,
        policy_id: str = None,
        rule_name: str = None,
        matched_pattern: str = None
    ):
        """
        Initialize a security violation error.
        
        Args:
            message: Human-readable error message
            event_id: Unique identifier for the security event
            decision: The decision made (allow, block, ask)
            policy_id: ID of the policy that triggered the decision
            rule_name: Name of the specific rule that matched
            matched_pattern: The regex pattern that caused the match (if block)
        """
        super().__init__(message)
        self.event_id = event_id
        self.decision = decision
        self.policy_id = policy_id
        self.rule_name = rule_name
        self.matched_pattern = matched_pattern
        
    def __str__(self) -> str:
        """Return a formatted error message with security context."""
        base = super().__str__()
        parts = []
        if self.event_id:
            parts.append(f"Event: {self.event_id}")
        if self.decision:
            parts.append(f"Decision: {self.decision}")
        if self.policy_id:
            parts.append(f"Policy: {self.policy_id}")
        if self.rule_name:
            parts.append(f"Rule: {self.rule_name}")
        if self.matched_pattern:
            parts.append(f"Pattern: {self.matched_pattern}")
        
        if parts:
            return f"{base} ({', '.join(parts)})"
        return base


class GuardianApprovalTimeout(GuardianSDKException):
    """
    Raised when a human approval request times out.
    
    This occurs when the SDK is configured to wait for human approval (ASK decision)
    but the configured MAX_POLL_SECONDS is exceeded before a human responds.
    
    The timeout action is configurable via APPROVAL_TIMEOUT_ACTION in GuardianConfig:
    - RAISE: Raise this exception (default for RAISE action)
    - BLOCK: Treat as block (no exception)
    - ALLOW: Treat as allow (no exception)
    
    Example:
        >>> config = GuardianConfig(
        ...     MAX_POLL_SECONDS=10,
        ...     APPROVAL_TIMEOUT_ACTION="raise"
        ... )
        >>> await client.check_action("send_email", {...})
        Traceback (most recent call last):
        GuardianApprovalTimeout: Approval timeout for send_email after 10 seconds
        Event ID: evt_abc123
    """
    
    def __init__(
        self,
        message: str,
        event_id: str = None,
        tool_name: str = None,
        timeout_seconds: float = None
    ):
        """
        Initialize an approval timeout error.
        
        Args:
            message: Human-readable error message
            event_id: Unique identifier for the event awaiting approval
            tool_name: Name of the tool that was being called
            timeout_seconds: Number of seconds waited before timeout
        """
        super().__init__(message)
        self.event_id = event_id
        self.tool_name = tool_name
        self.timeout_seconds = timeout_seconds
        
    def __str__(self) -> str:
        """Return a formatted error message with timeout context."""
        base = super().__str__()
        parts = []
        if self.event_id:
            parts.append(f"Event: {self.event_id}")
        if self.tool_name:
            parts.append(f"Tool: {self.tool_name}")
        if self.timeout_seconds:
            parts.append(f"Timeout: {self.timeout_seconds}s")
        
        if parts:
            return f"{base} ({', '.join(parts)})"
        return base


class GuardianRateLimitError(GuardianSDKException):
    """
    Raised when rate limit is exceeded on the backend.
    
    This exception includes retry-after information to help with
    implementing appropriate backoff strategies.
    """
    
    def __init__(
        self,
        message: str,
        retry_after_seconds: int = None,
        limit: int = None,
        remaining: int = None
    ):
        """
        Initialize a rate limit error.
        
        Args:
            message: Human-readable error message
            retry_after_seconds: Seconds to wait before retrying
            limit: The rate limit per minute
            remaining: Remaining requests in current window
        """
        super().__init__(message)
        self.retry_after_seconds = retry_after_seconds
        self.limit = limit
        self.remaining = remaining
        
    def __str__(self) -> str:
        """Return a formatted error message with rate limit context."""
        base = super().__str__()
        if self.retry_after_seconds:
            return f"{base} (Retry after {self.retry_after_seconds}s)"
        return base


class GuardianInvalidResponseError(GuardianSDKException):
    """
    Raised when the backend returns an invalid or malformed response.
    
    Common causes:
    - Invalid JSON in response
    - Missing required fields
    - Unexpected data types
    """
    
    def __init__(self, message: str, response_body: str = None, status_code: int = None):
        """
        Initialize an invalid response error.
        
        Args:
            message: Human-readable error message
            response_body: The raw response body (truncated)
            status_code: HTTP status code
        """
        super().__init__(message)
        self.response_body = response_body[:500] if response_body else None  # Truncate
        self.status_code = status_code
        
    def __str__(self) -> str:
        """Return a formatted error message with response context."""
        base = super().__str__()
        parts = []
        if self.status_code:
            parts.append(f"Status: {self.status_code}")
        if self.response_body:
            parts.append(f"Body: {self.response_body[:100]}...")
        
        if parts:
            return f"{base} ({', '.join(parts)})"
        return base