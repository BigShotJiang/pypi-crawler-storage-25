"""
Utility functions for the Guardian SDK.

Includes retry logic with exponential backoff, async/sync helpers,
and common utility functions for the SDK.
"""

import asyncio
import time
import logging
from typing import TypeVar, Callable, Any, Optional, Awaitable
from functools import wraps

from .constants import (
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_DELAY_SECONDS,
    DEFAULT_RETRY_BACKOFF_FACTOR,
    DEFAULT_MAX_RETRY_DELAY_SECONDS,
)

logger = logging.getLogger(__name__)

T = TypeVar("T")


def calculate_backoff_delay(
    attempt: int,
    base_delay: float = DEFAULT_RETRY_DELAY_SECONDS,
    backoff_factor: float = DEFAULT_RETRY_BACKOFF_FACTOR,
    max_delay: float = DEFAULT_MAX_RETRY_DELAY_SECONDS,
) -> float:
    """
    Calculate exponential backoff delay with jitter.
    
    Args:
        attempt: Current retry attempt number (0-indexed)
        base_delay: Initial delay in seconds
        backoff_factor: Multiplier for each retry
        max_delay: Maximum delay cap in seconds
        
    Returns:
        Delay in seconds to wait before next retry
    """
    delay = base_delay * (backoff_factor ** attempt)
    delay = min(delay, max_delay)
    
    # Add small jitter (±20%) to prevent thundering herd
    import random
    jitter = random.uniform(0.8, 1.2)
    delay = delay * jitter
    
    return delay


async def retry_async(
    func: Callable[..., Awaitable[T]],
    *args,
    max_retries: int = DEFAULT_MAX_RETRIES,
    base_delay: float = DEFAULT_RETRY_DELAY_SECONDS,
    backoff_factor: float = DEFAULT_RETRY_BACKOFF_FACTOR,
    max_delay: float = DEFAULT_MAX_RETRY_DELAY_SECONDS,
    retry_on_exceptions: tuple = (Exception,),
    **kwargs,
) -> T:
    """
    Execute an async function with exponential backoff retry logic.
    
    Args:
        func: Async function to execute
        *args: Positional arguments for func
        max_retries: Maximum number of retry attempts
        base_delay: Initial delay between retries
        backoff_factor: Multiplier for exponential backoff
        max_delay: Maximum delay cap
        retry_on_exceptions: Tuple of exceptions that trigger retry
        **kwargs: Keyword arguments for func
        
    Returns:
        Result of the function call
        
    Raises:
        Last exception encountered after all retries exhausted
    """
    last_exception = None
    
    for attempt in range(max_retries + 1):
        try:
            return await func(*args, **kwargs)
        except retry_on_exceptions as e:
            last_exception = e
            if attempt < max_retries:
                delay = calculate_backoff_delay(attempt, base_delay, backoff_factor, max_delay)
                logger.warning(
                    f"Retry {attempt + 1}/{max_retries} after {delay:.2f}s: {e}"
                )
                await asyncio.sleep(delay)
            else:
                logger.error(f"All {max_retries + 1} attempts failed: {e}")
                raise
    
    raise last_exception  # type: ignore


def retry_sync(
    func: Callable[..., T],
    *args,
    max_retries: int = DEFAULT_MAX_RETRIES,
    base_delay: float = DEFAULT_RETRY_DELAY_SECONDS,
    backoff_factor: float = DEFAULT_RETRY_BACKOFF_FACTOR,
    max_delay: float = DEFAULT_MAX_RETRY_DELAY_SECONDS,
    retry_on_exceptions: tuple = (Exception,),
    **kwargs,
) -> T:
    """
    Execute a sync function with exponential backoff retry logic.
    
    Args:
        func: Synchronous function to execute
        *args: Positional arguments for func
        max_retries: Maximum number of retry attempts
        base_delay: Initial delay between retries
        backoff_factor: Multiplier for exponential backoff
        max_delay: Maximum delay cap
        retry_on_exceptions: Tuple of exceptions that trigger retry
        **kwargs: Keyword arguments for func
        
    Returns:
        Result of the function call
        
    Raises:
        Last exception encountered after all retries exhausted
    """
    import time
    last_exception = None
    
    for attempt in range(max_retries + 1):
        try:
            return func(*args, **kwargs)
        except retry_on_exceptions as e:
            last_exception = e
            if attempt < max_retries:
                delay = calculate_backoff_delay(attempt, base_delay, backoff_factor, max_delay)
                logger.warning(
                    f"Retry {attempt + 1}/{max_retries} after {delay:.2f}s: {e}"
                )
                time.sleep(delay)
            else:
                logger.error(f"All {max_retries + 1} attempts failed: {e}")
                raise
    
    raise last_exception  # type: ignore


def is_async_callable(obj: Any) -> bool:
    """Check if an object is an async callable function or method."""
    import asyncio
    return asyncio.iscoroutinefunction(obj) or (
        hasattr(obj, '__call__') and asyncio.iscoroutinefunction(obj.__call__)
    )


def ensure_async(func: Callable[..., T]) -> Callable[..., Awaitable[T]]:
    """
    Decorator that wraps a sync function to return an async function.
    
    Useful for keeping consistent async interfaces.
    """
    if is_async_callable(func):
        return func
    
    @wraps(func)
    async def async_wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    
    return async_wrapper


def truncate_string(value: str, max_length: int = 500, suffix: str = "...") -> str:
    """Truncate a string to a maximum length, adding a suffix if truncated."""
    if len(value) <= max_length:
        return value
    return value[:max_length - len(suffix)] + suffix


def safe_json_serialize(obj: Any) -> Any:
    """Safely convert an object to a JSON-serializable format."""
    import json
    try:
        json.dumps(obj)
        return obj
    except (TypeError, ValueError):
        return str(obj)


def generate_trace_id() -> str:
    """Generate a unique trace ID for distributed tracing."""
    import uuid
    return uuid.uuid4().hex[:16]


def get_user_agent() -> str:
    """Generate User-Agent string for SDK."""
    from .version import __version__
    return f"Guardian-Agent-SDK/{__version__}"