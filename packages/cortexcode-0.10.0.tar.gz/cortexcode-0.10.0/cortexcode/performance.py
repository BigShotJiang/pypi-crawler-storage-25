"""Performance optimizations and utilities for CortexCode."""

from cortexcode.performance import (
    DEFAULT_MAX_FILE_SIZE,
    MONOREPO_MARKERS,
    IndexStats,
    detect_monorepo,
    get_file_size_limit,
    should_skip_large_file,
    compress_index,
    load_compressed_index,
    get_index_stats,
    preview_indexing,
    parallel_index_files,
    create_default_config,
)


__all__ = [
    "DEFAULT_MAX_FILE_SIZE",
    "MONOREPO_MARKERS",
    "IndexStats",
    "detect_monorepo",
    "get_file_size_limit",
    "should_skip_large_file",
    "compress_index",
    "load_compressed_index",
    "get_index_stats",
    "preview_indexing",
    "parallel_index_files",
    "create_default_config",
]
