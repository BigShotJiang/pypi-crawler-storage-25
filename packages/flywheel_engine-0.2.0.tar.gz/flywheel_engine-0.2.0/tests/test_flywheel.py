from flywheel_engine import Flywheel, TaskQueue


def test_momentum_boosts():
    fw = Flywheel(boost=0.5)
    fw.tick(True)
    assert fw.momentum == 0.5
    fw.tick(True)
    assert fw.momentum == 1.0  # capped


def test_momentum_decays():
    fw = Flywheel(momentum=0.8, decay_rate=0.1)
    import time
    time.sleep(0.1)
    fw.tick(False)
    assert fw.momentum < 0.8


def test_should_continue():
    fw = Flywheel(threshold=0.5)
    assert fw.should_continue is False
    fw.tick(True)
    fw.tick(True)
    assert fw.should_continue is True


def test_status():
    fw = Flywheel(threshold=0.5, boost=0.9)
    assert fw.status == "stalling"
    fw.tick(True)
    assert fw.status == "full_speed"


def test_task_queue():
    q = TaskQueue()
    q.add("low", priority=0.3)
    q.add("high", priority=0.9)
    q.add("mid", priority=0.6)
    assert q.next() == "high"
    assert q.remaining == 2
