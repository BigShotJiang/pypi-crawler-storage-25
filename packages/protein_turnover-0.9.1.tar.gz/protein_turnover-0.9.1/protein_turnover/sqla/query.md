## ProteinQuery

We build a intermediary table `T` that we can filter Peptides (see `ProteinQuery.peptide_subquery` method)
`T` has a set of unique `proteinid` integers

```sql
(SELECT PepProt.proteinid, agg(Peptide.somecolumn) as agg FROM PepProt JOIN Peptide ON (PepProt.peptideid = Peptide.peptideid)
    WHERE Peptide.somecolumn >= ? -- from FormFilter
    GROUP BY PepProt.proteinid) as T
```

```python
# in python
q=select(*[PepProt.proteinid, *self.agg_columns]).select_from(Join)
T=q.where(self.peptide_filter).group_by(PepProt.proteinid).subquery('T')
```
Or if there are no aggregates

```sql
(SELECT PepProt.proteinid FROM PepProt JOIN Peptide ON (PepProt.peptideid = Peptide.peptideid)
    WHERE Peptide.somecolumn >= ? -- from FormFilter
    )
```

```python
q=select(PepProt.proteinid).select_from(Join)
T=q.where(self.peptide_filter)
```

Protein Query is like: (join is 1 to 1)

```sql
SELECT Protein.somecolumn, T.agg FROM Protein join T
 ON (Protein.proteinid = T.proteinid)
    WHERE Protein.somecolumn >= ? -- from DTQuery
    AND Protein.somecolumn >= ? -- from protein_filter
```

```python
# in build_queries
q= select(*[Protein + T.c.columns[1:]]).select_from(join(Protein,T,Protein.proteinid == T.c.proteinid))
q = q.where(self.protein_filter)
q = q.where(self.dtquery_filter)
```

and

```sql
SELECT count(Protein.proteinid) FROM Protein JOIN T ON (Protein.proteinid = T.proteinid)
    WHERE Protein.somecolumn >= ? -- from DTQuery
    AND Protein.somecolumn >= ? -- from protein_filter
```
```python
q= select(func.count(Protein.proteinid)).select_from(join(Protein,T,Protein.proteinid == T.c.proteinid))
```

## ProteinQueryGrouped


So the peptide list on the turnover website shows all peptides that belong to the `group_number`
of the selected Protein. Peptides coloured in light blue are peptides that belong to the group but
*not* the actual highlighted protein.

To do this we need unique `(group_number,peptideid)` pairs that satisfy the `FormFilter` (from the filter form on the webpage)
and the Protein Filter
(from DataTables aka `DTQuery`)

We create a subquery:

```sql
(SELECT DISTINCT Protein.group_number, Peptide.peptideid FROM Protein JOIN PepProt

    ON (Protein.proteinid = PepProt.proteinid) JOIN Peptide ON (PepProt.peptideid = Peptide.peptideid)
    WHERE Peptide.somecolumn >= ?  -- from e.g. FormFilter
    AND
    Protein.somecolumn >= ?  -- from protein_filter


    ) as T1
```

```python
FullJoin = join(join(Protein, PepProt), Peptide)
T1 = select(Protein.group_number, Peptide.peptideid).distinct().select_from(FullJoin)
T1 = T1.where(self.peptide_filter)
T1 = T1.where(self.protein_filter)
# T1 = T1.where(self.dtquery_filter)
T1 = T1.subquery('T1')
```

Now to do the aggregate functions grouping by `group_number`.

```sql
(SELECT T1.group_number, agg(Peptide.somecolumn) as agg FROM T1 JOIN Peptide ON (T1.peptideid = Peptide.peptideid)
    GROUP BY T1.group_number) as T
```

```python
T = select(T1.c.group_number,*agg_columns)
T = T.select_from(join(T1,Peptide,T1.c.peptideid == Peptide.peptideid))
T = T.group_by(T1.group_number).subquery('T')
```

Now join to the Protein table

```sql
SELECT Protein, T.agg FROM Protein JOIN T ON (T.group_number = Protein.group_number)
    WHERE
    Protein.somecolumn >= ?  -- from DTQuery e.g. search
    ORDER BY somecolumn -- from DTQuery (possibly T.agg)
    LIMIT n OFFSET m -- from DTQuery
```

```python

q=select(*(self.protein_columns + list(T.columns[1:]))).select_from(join(Protein,T, Protein.group_number == T.c.group_number))
q = q.where(self.dtquery_filter) # From dtquery

```


for `recordsTotal` we need to not filter with DTQuery

```sql
(SELECT DISTINCT Protein.group_number FROM Protein
    JOIN PepProt ON (Protein.proteinid = PepProt.proteinid)
    JOIN Peptide ON (PepProt.peptideid = Peptide.peptideid)
    WHERE Peptide.somecolumn >= ?  -- from e.g. FormFilter
    AND Protein.somecolumn >= ? -- from protein_filter
    ) as T2
```

```python
t2=select(Protein.group_number.distinct()).select_from(FullJoin)
t2=t2.where(self.peptide_filter)
T2 = t2.where(self.protein_filter).subquery()
```

Then we can get a count of the number of proteins

```sql
SELECT COUNT(Protein.proteinid) WHERE Protein.group_number in T2
```

```python
recordsTotal = select(func.count(Protein.proteinid)).where(Protein.group_number.in_(T2))
```

Count `recordsFiltered` does a final filter on
protein values for dtquery_filter


```sql
SELECT COUNT(Protein.proteinid) WHERE Protein.group_number in T2
AND Protein.somecolumn >= ?  -- from DTQuery
```
```python
recordsFiltered = recordsTotal.where(self.dtquery_filter)
```
