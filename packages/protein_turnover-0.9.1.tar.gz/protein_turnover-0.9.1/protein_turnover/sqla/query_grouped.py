from __future__ import annotations

from typing import Any
from typing import override
from typing import TYPE_CHECKING

from sqlalchemy import join
from sqlalchemy import select

from .model import PepProt
from .model import Peptide
from .model import Protein
from .query import ProteinQueryBase
from .query import QueryTriple

if TYPE_CHECKING:
    from sqlalchemy import Select, Subquery


class ProteinQueryGrouped(ProteinQueryBase):
    FullJoin = join(join(Protein, PepProt), Peptide)
    T1 = (
        select(Protein.group_number, Peptide.peptideid).distinct().select_from(FullJoin)
    )
    COUNTS = select(Protein.group_number).distinct().select_from(FullJoin)

    def peptide_subquery_(self) -> Subquery:
        t1 = self.T1
        if self.peptide_filter is not None:
            t1 = t1.where(self.peptide_filter)
        if self.protein_filter is not None:
            t1 = t1.where(self.protein_filter)
        if self.dtquery_filter is not None:
            t1 = t1.where(self.dtquery_filter)
        t1 = t1.subquery("T1")
        T = select(t1.c.group_number, *self.agg_columns).select_from(
            join(t1, Peptide, t1.c.peptideid == Peptide.peptideid),
        )

        T = T.group_by(t1.c.group_number).subquery("T")

        return T

    def count_(self) -> tuple[Select[Any], Select[Any]]:
        recordsTotal = self.COUNTS
        if self.peptide_filter is not None:
            recordsTotal = recordsTotal.where(self.peptide_filter)
        if self.protein_filter is not None:
            recordsTotal = recordsTotal.where(self.protein_filter)
        if self.dtquery_filter is not None:
            recordsFiltered = recordsTotal.where(self.dtquery_filter)
        else:
            recordsFiltered = recordsTotal

        cp = self.COUNT_PROTEIN
        return cp.where(Protein.group_number.in_(recordsTotal)), cp.where(
            Protein.group_number.in_(recordsFiltered),
        )

    @override
    def build_queries(self) -> QueryTriple:
        peptide_sq = self.peptide_subquery_()
        agg_cols = peptide_sq.columns[1:]  # aggregate columns

        columns = self.protein_columns + list(agg_cols)

        q: Select[Any] = select(*columns)

        q = q.join(peptide_sq, peptide_sq.c.group_number == Protein.group_number)

        recordsTotal, recordsFiltered = self.count_()

        q = self.add_dt_order_and_slice_(q)
        return QueryTriple(q, recordsFiltered, recordsTotal)
