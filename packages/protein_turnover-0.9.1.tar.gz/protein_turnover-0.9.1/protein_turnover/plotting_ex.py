from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import pandas as pd
from matplotlib.figure import Figure

from .plotting import despine
from .plotting import FIGSIZE
from .plotting import plotEICS
from .plotting import plotFittedEnvelopes
from .plotting import plotLabelledEnvelope


if TYPE_CHECKING:
    from matplotlib.axes import Axes
    from .utils import PeptideSettings
    from .types.turnovertype import TurnoverDict


def plot_eics_sidebyside(  # pragma: no cover
    b: TurnoverDict,
    suffix: str = "_me",
    figsize: tuple[float, float] = (15.0, 5.0),
) -> tuple[Figure, Axes, Axes]:
    fig = Figure(figsize=figsize)
    [ax1, ax2] = fig.subplots(1, 2)

    plotEICS(b, ax=ax1)
    plotEICS(rename(b, suffix), ax=ax2)  # type: ignore
    return fig, ax1, ax2


def plot_fitted_sidebyside(  # pragma: no cover
    b: TurnoverDict,
    settings: PeptideSettings,
    suffix: str = "_me",
    figsize: tuple[float, float] = (15, 5),
) -> tuple[Figure, Axes, Axes]:
    fig = Figure(figsize=figsize)
    [ax1, ax2] = fig.subplots(1, 2)

    plotFittedEnvelopes(b, settings, ax=ax1)
    plotFittedEnvelopes(rename(b, suffix), settings, ax=ax2)  # type: ignore
    return fig, ax1, ax2


def plot_labelled_sidebyside(  # pragma: no cover
    b: TurnoverDict,
    settings: PeptideSettings,
    suffix: str = "_me",
    figsize: tuple[float, float] = (15, 5),
) -> tuple[Figure, Axes, Axes]:
    fig = Figure(figsize=figsize)
    [ax1, ax2] = fig.subplots(1, 2)

    plotLabelledEnvelope(b, settings, ax=ax1)
    plotLabelledEnvelope(rename(b, suffix), settings, ax=ax2)  # type: ignore
    return fig, ax1, ax2


def plot_fit_arrays(  # pragma: no cover
    row: TurnoverDict,
    suffix: str = "_me",
    figsize: tuple[float, float] = (15, 12),
) -> tuple[Figure, list[list[Axes]]]:
    b: TurnoverDict = row  # type: ignore
    fig = Figure(figsize=figsize)
    axes = fig.subplots(
        5,
        2,
        gridspec_kw=dict(hspace=0.5),
    )
    [[ax1, ax2], [ax3, _ax4], [ax5, ax6], [_ax7, ax8], [ax9, _ax10]] = axes

    def plot_a(name: str, ax: Axes) -> None:
        x = list(range(0, len(b[name])))  # type: ignore
        v = b[name + suffix]  # type: ignore
        if len(x) != len(v):
            ax.set(title=f"bad {name}")
            return
        dodge = np.nanmax(np.abs(v)) / 50
        ax.plot(x, b[name])  # type: ignore
        ax.plot(x, v + dodge)
        ax.set(title=f"{name}")

    def plot_a_col(name: str, ax: Axes, col: int) -> None:
        x = list(range(0, len(b[name][:, col])))  # type: ignore
        v = b[name + suffix][:, col]  # type: ignore
        if len(x) != len(v):
            ax.set(title=f"bad {name}")
            return
        dodge = np.nanmax(np.abs(v)) / 50
        ax.plot(x, b[name][:, col])  # type: ignore
        ax.plot(x, v + dodge)
        ax.set(title=f"{name}")

    def ratio(name: str) -> np.ndarray:
        a = b[name]  # type: ignore
        m = b[name + suffix]  # type: ignore
        if len(a) != len(m):
            return a * 0
        both = (a == 0) & (m == 0)
        ret = m / np.where(a != 0, a, 1e-6)
        if both.sum() > 0:  # 0/0 is 1 !
            ret = np.where(both, 1.0, ret)
        return ret

    def plot_ratio(name: str, ax: Axes) -> None:
        val = b[name]  # type: ignore
        x = list(range(0, len(val)))
        ax.plot(x, ratio(name))
        ax.set(title=f"{name} ratio")

    plot_a_col("isotopeRegressions", ax1, 1)
    ax1.set(title="regression intensity")

    plot_a_col("isotopeRegressions", ax2, 0)
    ax2.set(title="adjusted R-squared")

    plot_a("isotopeEnvelopes", ax3)
    # plot_a("heavyDistribution", ax4)
    # plot_heavy_fit(ax4)
    plot_a("labelledEnvelopes", ax5)
    plot_a("monoFitParams", ax6)
    # plot_a("heavyFitParams", ax7)

    plot_ratio("monoFitParams", ax8)
    plot_ratio("isotopeEnvelopes", ax9)
    # plot_ratio("heavyDistribution", ax10)

    return fig, axes


# for use in jupyter notebooks....
def plot_all_sidebyside(  # pragma: no cover
    b: TurnoverDict,
    settings: PeptideSettings,
) -> tuple[Figure, Figure, Figure, Figure]:
    f1, *_axes = plot_eics_sidebyside(b)
    f2, *_axes = plot_fitted_sidebyside(b, settings)
    f3, *_axes = plot_labelled_sidebyside(b, settings)
    f4, _axes = plot_fit_arrays(b)
    return f1, f2, f3, f4


def rename(s: pd.Series, suffix: str = "_me") -> pd.Series:  # pragma: no cover
    r = pd.Series(dtype=object)
    for key in [
        "isotopeEnvelopes",
        "relativeIsotopeAbundance",
        "monoFitParams",
        "eics",
        "labelledEnvelopes",
        "labelledElementCount",
        "enrichment",
        "heavyFitParams",
        "heavyCor",
    ]:
        r[key] = s[key + suffix]

    r["peptide"] = s["peptide"]
    r["modcol"] = s["modcol"]
    r["maxIso"] = int(s["maxIso" + suffix])
    return r


def correlation_plot(
    df: pd.DataFrame,
    column: str,
    xlabel: str | None = None,
    ax: Axes | None = None,
    figsize: tuple[float, float] | None = None,
) -> Axes:
    if ax is None:
        fig = Figure(figsize=figsize if figsize else FIGSIZE)
        ax = fig.subplots(1, 1)
    # mn,mx = nnls_residual.min(), nnls_residual.max()
    col = df[column]
    ax.hist(col, bins="auto", color="turquoise")
    despine(ax, trim=True, offset=5)
    ax.set(ylabel="counts", xlabel=xlabel or column)
    return ax
