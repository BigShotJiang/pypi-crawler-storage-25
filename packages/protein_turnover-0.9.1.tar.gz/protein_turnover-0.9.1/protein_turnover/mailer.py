from __future__ import annotations

import smtplib
from email.mime.text import MIMEText
from typing import Literal


def sendmail(
    html: str,
    you: str,
    *,
    sender: str | None = None,
    replyto: str | list[str] | None = None,
    mailhost: str | None = None,
    subject: str | None = None,
    mimetype: Literal["html", "plain"] = "html",
    timeout: float = 20.0,
) -> bool:
    from . import config

    if mailhost is None:
        mailhost = config.MAIL_SERVER

    if mailhost is None or mailhost == "none":
        return False

    username = password = None
    if "@" in mailhost:
        uw, mailhost = mailhost.split("@", maxsplit=1)
        username, password = uw.split(":", maxsplit=1)

    port = 0
    if ":" in mailhost:
        mailhost, p = mailhost.split(":", maxsplit=1)
        port = int(p)

    if subject is None:
        subject = config.MAIL_SUBJECT

    if sender is None:
        sender = config.MAIL_DEFAULT_SENDER

    msg = MIMEText(html, mimetype)

    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = you
    if replyto is not None:
        msg["Reply-To"] = replyto if isinstance(replyto, str) else ",".join(replyto)

    if username is not None and password is not None:
        with smtplib.SMTP(mailhost, port, timeout=timeout) as s:
            s.ehlo()
            s.starttls()
            s.ehlo()
            s.login(username, password)
            s.sendmail(sender, [you], msg.as_string())
        return True

    with smtplib.SMTP(mailhost, port, timeout=timeout) as s:
        s.sendmail(sender, [you], msg.as_string())

    return True
