from __future__ import annotations

from abc import ABC
from abc import abstractmethod
from typing import Callable
from typing import TYPE_CHECKING

from . import fit_latest
from . import fit_original
from .utils import AlgosType

if TYPE_CHECKING:
    from .utils import PeptideSettings
    from .utils import PeptideInfo
    import numpy as np
    from .types.numpytypes import NP1DF64Array, NP2DF64Array, NP1DF32Array


class Algo(ABC):
    @staticmethod
    @abstractmethod
    def mk_maxIso(settings: PeptideSettings) -> Callable[[str], np.int32]: ...

    # @staticmethod
    # @abstractmethod
    # def isotopic_distribution(
    #     pepinfo: PeptideInfo, abundance: float | None = None
    # ) -> NP1DF64Array: ...

    @staticmethod
    @abstractmethod
    def make_envelope_array(
        pepinfo: PeptideInfo,
        maxIso: int,
    ) -> tuple[NP1DF64Array, NP2DF64Array]: ...
    @staticmethod
    @abstractmethod
    def natural_dist(
        pepinfo: PeptideInfo,
        monoScale: float,
    ) -> NP1DF32Array: ...


class AlgoLatest(Algo):
    @staticmethod
    def mk_maxIso(settings: fit_latest.PeptideSettings) -> Callable[[str], np.int32]:
        return fit_latest.mk_maxIso(settings)

    # @staticmethod
    # def isotopic_distribution(
    #     pepinfo: PeptideInfo, abundance: float | None = None
    # ) -> NP1DF64Array:
    #     return current_fit.isotopic_distribution(pepinfo, abundance)

    @staticmethod
    def make_envelope_array(
        pepinfo: PeptideInfo,
        maxIso: int,
    ) -> tuple[NP1DF64Array, NP2DF64Array]:
        return fit_latest.make_envelope_array(pepinfo, maxIso)

    @staticmethod
    def natural_dist(
        pepinfo: PeptideInfo,
        monoScale: float,
    ) -> NP1DF32Array:
        return fit_latest.natural_dist(pepinfo, monoScale)


class Algo2023(Algo):
    @staticmethod
    def mk_maxIso(settings: fit_latest.PeptideSettings) -> Callable[[str], np.int32]:
        return fit_original.mk_maxIso(settings)

    # @staticmethod
    # def isotopic_distribution(
    #     pepinfo: PeptideInfo, abundance: float | None = None
    # ) -> NP1DF64Array:
    #     return dec2023_fit.isotopic_distribution(pepinfo, abundance)

    @staticmethod
    def make_envelope_array(
        pepinfo: PeptideInfo,
        maxIso: int,
    ) -> tuple[NP1DF64Array, NP2DF64Array]:
        return fit_original.make_envelope_array(pepinfo, maxIso)

    @staticmethod
    def natural_dist(
        pepinfo: PeptideInfo,
        monoScale: float,
    ) -> NP1DF32Array:
        return fit_original.natural_dist(pepinfo, monoScale)


ALGO: dict[AlgosType, type[Algo]] = {
    "Latest": AlgoLatest,
    "2023": Algo2023,
    "Original": Algo2023,
}


def settings_to_algo(settings: PeptideSettings) -> type[Algo]:
    return ALGO[settings.pipelineAlgo]
