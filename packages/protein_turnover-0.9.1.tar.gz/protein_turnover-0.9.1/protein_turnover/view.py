from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
from typing import TYPE_CHECKING

import pandas as pd

from .fitenvelopes import fails
from .logger import logger
from .logger import show_fit_warnings
from .logger import show_log
from .pepxml import compute_maxIso
from .pepxml import compute_modcol
from .pepxml import compute_mz
from .pepxml import getpepxml
from .plotting import FIGSIZE
from .plotting import pepsize
from .plotting import plot_all
from .plotting import plotEICS
from .plotting import plotFittedEnvelopes
from .plotting import plotIntensities
from .plotting import plotLabelledEnvelope
from .pymz import compute_rt
from .pymz import MZI
from .pymz import mzml_calc_pep_envelopes
from .pymz import mzml_create
from .resourcefiles import MzMLResourceFileLocal
from .resourcefiles import PepXMLResourceFileLocal
from .utils import has_package
from .utils import PeptideSettings

if TYPE_CHECKING:
    from collections.abc import Sequence
    from matplotlib.figure import Figure


@dataclass(kw_only=True)
class PlotOptions:
    figsize: tuple[float, float] = FIGSIZE
    with_rsq: bool = True
    layout: tuple[int, int] = (2, 2)


class PlotView:
    def __init__(
        self,
        row: pd.Series,
        settings: PeptideSettings,
        *,
        plot_options: PlotOptions = PlotOptions(),
    ):
        self.row = row
        self.settings = settings
        self.plot_options = plot_options

    def plotAll(self) -> Figure:
        t = plot_all(
            self.row,  # type: ignore
            self.settings,
            figsize=self.plot_options.figsize,
            layout=self.plot_options.layout,
        )  # type: ignore
        return t[0]

    def plotEICS(self) -> Figure:
        return plotEICS(self.row, figsize=self.plot_options.figsize).get_figure()  # type: ignore

    def plotFittedEnvelopes(self) -> Figure:
        return plotFittedEnvelopes(
            self.row,  # type: ignore
            self.settings,
            figsize=self.plot_options.figsize,
            with_rsq=self.plot_options.with_rsq,
        ).get_figure()

    def plotLabelledEnvelope(self) -> Figure:
        return plotLabelledEnvelope(
            self.row,  # type: ignore
            self.settings,
            figsize=self.plot_options.figsize,
        ).get_figure()

    def plotIntensities(self) -> Figure:
        return plotIntensities(
            self.row,  # type: ignore
            None,
            figsize=self.plot_options.figsize,
        ).get_figure()

    def plotNNLS(self) -> Figure:
        from .utils import PeptideInfo
        from .algo import settings_to_algo

        peptide = self.row["peptide"]

        info = PeptideInfo(peptide, self.settings)
        maxIso = round(self.row["maxIso"])

        algo = settings_to_algo(self.settings)
        enrichment, m = algo.make_envelope_array(info, maxIso)

        df = pd.DataFrame(m, columns=[str(round(x, 4)) for x in enrichment])
        df.index.name = "Iso"
        df.columns.name = "enrichment"
        n, e = self.settings.labelledIsotopeNumber, self.settings.labelledElement
        title = f"$^{{{n}}}{e}$ {pepsize(peptide)}[maxIso={maxIso}/{info.elementCount}]"
        return df.plot(figsize=self.plot_options.figsize, title=title).get_figure()  # type: ignore

    def failed(self) -> str | None:
        e = self.row["fail"]
        if not e:
            return None
        return fails(e)

    @classmethod
    def available_plots(cls) -> list[str]:
        return [
            f for f in dir(cls) if f.startswith("plot") and callable(getattr(cls, f))
        ]


def has_cols(df: pd.DataFrame, cols: Sequence[str]) -> bool:
    return all(c in df.columns for c in cols)


class TurnoverView:
    PlotViewClass: type[PlotView] = PlotView

    def __init__(
        self,
        pepxmlfile: Path | str | pd.DataFrame,
        mzmlfile: Path | str | MZI,
        settings: PeptideSettings,
        *,
        cache_dir: str | Path | None = None,
        quiet: bool = False,
        plot_options: PlotOptions = PlotOptions(),
        query: str | None = None,
        limit: int | tuple[int, ...] | None = None,
    ):
        self.settings = settings
        self.quiet = quiet
        self.plot_options = plot_options
        self.cache_dir = cache_dir

        if isinstance(mzmlfile, MZI):
            self.mzi = mzmlfile
        else:
            mzml = MzMLResourceFileLocal(mzmlfile, cache_dir=cache_dir)
            if not mzml.cache_ok():
                with show_log(quiet):
                    mzml_create(mzml)
            self.mzi = MZI(mzml)

        if isinstance(pepxmlfile, pd.DataFrame):
            self.pepxml = pepxmlfile
        else:
            pep = PepXMLResourceFileLocal(pepxmlfile, cache_dir=cache_dir)
            with show_log(quiet):
                df = getpepxml(pep)
                self.pepxml = self.filter(df, query=query, limit=limit)

    def filter(
        self,
        pepxml: pd.DataFrame,
        query: str | None = None,
        limit: int | tuple[int, ...] | None = None,
    ) -> pd.DataFrame:
        if query is not None:
            pepxml = pepxml.query(query).copy(deep=False)
        if limit is not None:
            if isinstance(limit, int):
                pepxml = pepxml.iloc[slice(limit)]
            else:
                pepxml = pepxml.iloc[slice(*limit)]
            pepxml = pepxml.copy(deep=False)
        return pepxml

    def precompute(self, recompute: bool = False):
        """precompute all mzranges, maxIso, rtmax, rtmin"""
        with show_log(self.quiet):
            logger.info("computing mzranges, etc.")
            self.pepxml = self.compute(self.pepxml, recompute=recompute)
            logger.info("done.")

    def query(self, query: str) -> TurnoverView:
        return self.__class__(
            self.pepxml.query(query).copy(deep=False),
            self.mzi,
            self.settings,
            cache_dir=self.cache_dir,
            quiet=self.quiet,
            plot_options=self.plot_options,
        )

    def compute(self, pepxml: pd.DataFrame, recompute: bool = False) -> pd.DataFrame:
        if recompute or not has_cols(pepxml, ["mz", "observed_mz"]):
            pepxml = compute_mz(pepxml)
        if recompute or not has_cols(pepxml, ["modcol"]):
            pepxml = compute_modcol(pepxml)
        if recompute or not has_cols(
            pepxml,
            ["modcol", "mzranges", "labelledElementCount"],
        ):
            pepxml = compute_maxIso(pepxml, self.settings)
        if recompute or not has_cols(pepxml, ["rtmin", "rtmax"]):
            pepxml = compute_rt(pepxml, self.settings)
        return pepxml

    def create_rec(self, rec: pd.Series) -> tuple[dict[str, Any] | None, int]:
        return mzml_calc_pep_envelopes(self.mzi, rec, self.settings)  # type: ignore

    def plotview(
        self,
        index_or_series: int | pd.Series | pd.DataFrame | str,
        *,
        plot_options: PlotOptions | None = None,
    ) -> PlotView:
        if isinstance(index_or_series, str):
            s = index_or_series
            index_or_series = self.pepxml.query(index_or_series)
            if len(index_or_series) == 0:
                raise ValueError(f'Query "{s}" results in zero length dataframe!')
        if isinstance(index_or_series, int):
            s = self.pepxml.iloc[index_or_series]
        elif isinstance(index_or_series, pd.DataFrame):
            if len(index_or_series) == 0:
                raise ValueError("Zero length dataframe!")
            s = index_or_series.iloc[0]
        else:
            s = index_or_series

        if not isinstance(s, pd.Series):
            raise ValueError(
                "index_or_series should be an integer or a Series or a DataFrame",
            )

        if "mzranges" not in s:
            s = self.compute(pd.DataFrame([s])).iloc[0]
        if "eics" not in s:
            with show_fit_warnings(self.quiet):
                rt, fail = self.create_rec(s)
            if rt is None:  # pragma no cover
                raise ValueError("can't fit EICs!")
            rt["fail"] = fail
            rt["fail_reason"] = fails(fail)

            ret = pd.Series(rt)
            s = pd.concat([ret, s])
        return self.PlotViewClass(
            s,
            self.settings,
            plot_options=plot_options or self.plot_options,
        )

    def get_many(
        self,
        peps: pd.DataFrame,
        include_failures: bool = False,
    ) -> pd.DataFrame:
        retl = []
        if not isinstance(peps, pd.DataFrame):  # pragma: no cover
            raise ValueError("argument is not a DataFrame!")
        peps = self.compute(peps)
        if not has_cols(peps, ["eics"]):
            with show_fit_warnings(self.quiet):
                for row in peps.itertuples(index=True):
                    idx = row[0]
                    rt, fail = self.create_rec(row)  # type: ignore
                    if rt is not None:
                        rt["peptide_index"] = idx
                        rt["fail"] = fail
                        rt["fail_reason"] = fails(fail)
                        retl.append(rt)
                    elif include_failures:  # pragma: no cover
                        rt = {
                            "peptide_index": idx,
                            "fail": fail,
                            "fail_reason": fails(fail),
                        }
                        retl.append(rt)
                if len(retl) == 0:  # pragma: no cover
                    return pd.DataFrame()
                df = pd.DataFrame(retl)
                df = df.set_index("peptide_index")

                ret = df.join(peps)
                return ret
        return peps

    def compute_all(self, include_failures: bool = False) -> None:
        self.pepxml = self.get_many(self.pepxml, include_failures=include_failures)

    def query_df(self, query: str, include_failures: bool = False) -> pd.DataFrame:
        return self.get_many(
            self.pepxml.query(str(query)).copy(deep=False),
            include_failures,
        )

    def interact(
        self,
        *,
        plot="plotAll",
        figsize: tuple[float, float] | None = None,
        continuous_update=True,
    ) -> None:
        if not has_package("ipywidgets"):
            raise ImportError("ipywidgets is required for interact!")
        if not getattr(self.PlotViewClass, plot, None):
            raise ValueError(
                f"unknown plot function {plot}! available: {self.PlotViewClass.available_plots()}",
            )

        import ipywidgets as widgets  # type: ignore
        from IPython.display import display  # type: ignore

        disp = plot not in {
            "plotNNLS",
        }

        def plotview(iloc: int) -> None:
            pv = self.plotview(iloc)
            peptide.value = pv.row["peptide"]
            fig = getattr(pv, plot)()
            if figsize is not None:
                fig.set_size_inches(figsize)
            if disp:
                display(fig)

        slider = widgets.IntSlider(
            0,
            min=0,
            max=len(self.pepxml),
            description="index:",
            continuous_update=continuous_update,
        )
        peptide = widgets.Text(value="", description="peptide:")

        box = widgets.HBox([slider, peptide])
        out = widgets.interactive_output(plotview, dict(iloc=slider))
        display(box, out)

    def plotCountHist(
        self,
        exclude: tuple[str, ...] | None = ("Se", "S", "P"),
        *,
        alpha: float = 0.5,
        bins: int = 50,
        **kwargs: Any,
    ) -> Figure:
        from protein_turnover.utils import NAMES, PeptideInfo

        if exclude is None:
            ex = set()
        else:
            ex = set(exclude)

        def f(pep: str) -> pd.Series:
            pi = PeptideInfo(pep, self.settings)
            return pd.Series(
                {k: v for k, v in zip(NAMES, pi.formula) if k not in ex},
            )

        counts = self.pepxml["peptide"].apply(f)
        if "title" not in kwargs:
            title = f"Element count histogram for {len(self.pepxml)} peptides"
            kwargs["title"] = title
        return counts.plot(kind="hist", bins=bins, alpha=alpha, **kwargs).get_figure()

    def plotEnrichment(self) -> Figure:
        from .plotting import enrichment_plot

        self.compute_all()
        return enrichment_plot(self.pepxml).get_figure()  # type: ignore

    def plotLPF(self) -> Figure:
        from .plotting import plotLPF

        self.compute_all()
        return plotLPF(self.pepxml).get_figure()  # type: ignore
