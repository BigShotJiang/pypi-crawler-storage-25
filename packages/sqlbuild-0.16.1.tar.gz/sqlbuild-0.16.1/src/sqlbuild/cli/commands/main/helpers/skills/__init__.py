"""Skills command helpers."""
