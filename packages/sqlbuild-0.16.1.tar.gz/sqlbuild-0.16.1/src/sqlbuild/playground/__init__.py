"""Packaged playground project templates."""
