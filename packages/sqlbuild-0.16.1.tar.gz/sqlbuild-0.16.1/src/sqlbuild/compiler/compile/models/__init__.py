"""Compile model modules."""
