"""Build the first attached compile input snapshot from discovered inputs."""

from __future__ import annotations

from sqlbuild.compiler.auditing.main.builtins import build_builtin_audit_resolution
from sqlbuild.compiler.compile.helpers.attachment import (
    build_audit_inputs,
    build_effective_connection,
    build_effective_settings,
    build_effective_vars,
    build_model_inputs,
    build_scenario_inputs,
    build_seed_inputs,
    build_source_inputs,
    build_sql_function_inputs,
    build_test_inputs,
    index_generic_audit_definitions,
    resolve_environment_config,
    resolve_environment_name,
    resolve_run_id,
)
from sqlbuild.compiler.compile.helpers.macros import load_project_macros
from sqlbuild.compiler.compile.models.core import (
    CompileAuditInput,
    CompileModelInput,
    CompileProjectInputs,
    CompileSeedInput,
    CompileSourceInput,
    CompileSqlFunctionInput,
    CompileSqlScenarioInput,
    LoadedMacro,
    MacroContext,
)
from sqlbuild.compiler.compile.models.sql_tests import CompileSqlTestInput
from sqlbuild.compiler.diagnostics.models import CompilerDiagnostic
from sqlbuild.compiler.discovery.models import (
    DiscoveredAuditBlock,
    DiscoveredAuditFile,
    DiscoveredProjectInputs,
)
from sqlbuild.shared.types import ExternalSqlReferenceResolver
from sqlbuild.spec.models.project import (
    EnvironmentConfig,
    SettingsConfig,
    resolve_effective_adapter_name,
)


def build_compile_inputs(
    discovered_inputs: DiscoveredProjectInputs,
    *,
    selected_environment: str | None = None,
    cli_vars: dict[str, object] | None = None,
    run_id: str | None = None,
    no_sql_validation: bool = False,
    python_functions_inherit_default_namespace: bool = True,
    external_sql_reference_resolver: ExternalSqlReferenceResolver | None = None,
) -> CompileProjectInputs:
    """Attach discovered metadata into the first compile input snapshot."""

    effective_environment_name: str | None = resolve_environment_name(
        project_config=discovered_inputs.project_config,
        local_config=discovered_inputs.local_config,
        selected_environment=selected_environment,
    )
    effective_environment: EnvironmentConfig | None = None
    if effective_environment_name is not None:
        effective_environment = resolve_environment_config(
            project_config=discovered_inputs.project_config,
            local_config=discovered_inputs.local_config,
            environment_name=effective_environment_name,
        )

    effective_vars: dict[str, object] = build_effective_vars(
        project_config=discovered_inputs.project_config,
        local_config=discovered_inputs.local_config,
        environment_config=effective_environment,
        cli_vars={} if cli_vars is None else cli_vars,
    )
    effective_settings: SettingsConfig = build_effective_settings(
        project_config=discovered_inputs.project_config,
        local_config=discovered_inputs.local_config,
    )
    macro_context: MacroContext = MacroContext(
        adapter_name=resolve_effective_adapter_name(
            project_config=discovered_inputs.project_config,
            local_config=discovered_inputs.local_config,
        ),
        sqlglot_enabled=effective_settings.sqlglot,
        environment_name=effective_environment_name,
        vars=effective_vars,
    )
    resolved_run_id: str = resolve_run_id(selected_run_id=run_id)
    loaded_macros: dict[str, LoadedMacro] = load_project_macros(discovered_inputs.macro_files)
    model_inputs: tuple[CompileModelInput, ...] = build_model_inputs(
        discovered_inputs,
        effective_vars=effective_vars,
        effective_settings=effective_settings,
        environment_config=effective_environment,
        effective_environment_name=effective_environment_name,
        run_id=resolved_run_id,
        macro_context=macro_context,
        no_sql_validation=no_sql_validation,
        external_sql_reference_resolver=external_sql_reference_resolver,
    )
    seed_inputs: tuple[CompileSeedInput, ...] = build_seed_inputs(discovered_inputs)
    sql_function_inputs: tuple[CompileSqlFunctionInput, ...] = build_sql_function_inputs(
        discovered_inputs,
        effective_vars=effective_vars,
        effective_settings=effective_settings,
        environment_config=effective_environment,
        adapter_name=macro_context.adapter_name,
        macro_context=macro_context,
        no_sql_validation=no_sql_validation,
        python_functions_inherit_default_namespace=(python_functions_inherit_default_namespace),
    )
    source_inputs: tuple[CompileSourceInput, ...] = build_source_inputs(
        discovered_inputs,
        effective_vars=effective_vars,
        effective_settings=effective_settings,
        macro_context=macro_context,
        no_sql_validation=no_sql_validation,
    )
    test_inputs: tuple[CompileSqlTestInput, ...] = build_test_inputs(
        discovered_inputs,
        effective_vars=effective_vars,
        macro_context=macro_context,
    )
    scenario_inputs: tuple[CompileSqlScenarioInput, ...] = build_scenario_inputs(
        discovered_inputs,
        effective_vars=effective_vars,
        macro_context=macro_context,
    )
    project_audit_definitions: dict[str, tuple[DiscoveredAuditFile, DiscoveredAuditBlock]] = (
        index_generic_audit_definitions(discovered_inputs.audit_files)
    )
    generic_audit_definitions: dict[str, tuple[DiscoveredAuditFile, DiscoveredAuditBlock]]
    diagnostics: tuple[CompilerDiagnostic, ...]
    generic_audit_definitions, diagnostics = build_builtin_audit_resolution(
        project_audit_definitions
    )
    audit_inputs: tuple[CompileAuditInput, ...] = build_audit_inputs(
        discovered_inputs,
        effective_settings=effective_settings,
        model_inputs=model_inputs,
        source_inputs=source_inputs,
        effective_vars=effective_vars,
        macro_context=macro_context,
        generic_audit_definitions=generic_audit_definitions,
    )
    return CompileProjectInputs(
        project_config=discovered_inputs.project_config,
        local_config=discovered_inputs.local_config,
        discovered_inputs=discovered_inputs,
        run_id=resolved_run_id,
        effective_environment_name=effective_environment_name,
        effective_environment=effective_environment,
        effective_connection=build_effective_connection(
            project_config=discovered_inputs.project_config,
            local_config=discovered_inputs.local_config,
            environment_config=effective_environment,
            effective_vars=effective_vars,
        ),
        effective_settings=effective_settings,
        effective_vars=effective_vars,
        loaded_macros=loaded_macros,
        model_inputs=model_inputs,
        seed_inputs=seed_inputs,
        source_inputs=source_inputs,
        sql_function_inputs=sql_function_inputs,
        test_inputs=test_inputs,
        scenario_inputs=scenario_inputs,
        audit_inputs=audit_inputs,
        diagnostics=diagnostics,
        external_sql_reference_resolver=external_sql_reference_resolver,
    )
