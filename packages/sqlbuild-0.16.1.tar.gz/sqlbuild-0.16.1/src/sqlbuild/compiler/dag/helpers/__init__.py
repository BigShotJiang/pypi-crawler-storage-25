"""Static DAG helper package."""
