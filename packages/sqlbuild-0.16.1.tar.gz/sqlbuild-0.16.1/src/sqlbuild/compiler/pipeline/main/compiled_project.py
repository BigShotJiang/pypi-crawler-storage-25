"""Build a compiled project with target defaults and adapter-aware validation."""

from __future__ import annotations

from sqlbuild.adapter.base.base_adapter import BaseAdapter
from sqlbuild.compiler.compile.main.assemble_project import assemble_project
from sqlbuild.compiler.compile.main.build_compile_inputs import build_compile_inputs
from sqlbuild.compiler.compile.models.core import (
    CompiledProject,
    CompileProjectInputs,
)
from sqlbuild.compiler.discovery.models import DiscoveredProjectInputs
from sqlbuild.compiler.pipeline.helpers.target_defaults import apply_target_defaults
from sqlbuild.compiler.pipeline.helpers.target_validation import validate_project_targets
from sqlbuild.shared.types import ExternalSqlReferenceResolver
from sqlbuild.spec.models.project import resolve_effective_adapter_name


def build_compiled_project(
    *,
    discovered_inputs: DiscoveredProjectInputs,
    adapter: BaseAdapter,
    selected_environment: str | None = None,
    no_sql_validation: bool = False,
    cli_vars: dict[str, object] | None = None,
    external_sql_reference_resolver: ExternalSqlReferenceResolver | None = None,
) -> CompiledProject:
    """Build one compiled project with adapter defaults and target validation applied."""

    compile_inputs: CompileProjectInputs = build_compile_inputs(
        discovered_inputs,
        selected_environment=selected_environment,
        no_sql_validation=no_sql_validation,
        cli_vars=cli_vars,
        python_functions_inherit_default_namespace=(
            adapter.python_functions_inherit_default_namespace()
        ),
        external_sql_reference_resolver=external_sql_reference_resolver,
    )
    project: CompiledProject = apply_target_defaults(
        assemble_project(
            compile_inputs,
            inference_profile=adapter.expression_inference_profile(),
        ),
        default_schema=adapter.default_schema(),
        default_database=adapter.default_database(),
        render_qualified_name=adapter.render_qualified_name,
        python_functions_inherit_default_namespace=(
            adapter.python_functions_inherit_default_namespace()
        ),
    )
    validate_project_targets(
        adapter_name=resolve_effective_adapter_name(
            project_config=discovered_inputs.project_config,
            local_config=discovered_inputs.local_config,
        ),
        project=project,
    )
    return project
