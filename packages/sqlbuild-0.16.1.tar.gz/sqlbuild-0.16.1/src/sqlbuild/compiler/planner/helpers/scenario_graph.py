"""Graph inference and validation for SQL-native scenarios."""

from __future__ import annotations

import re
from typing import Any

from sqlbuild.compiler.compile.models.core import (
    CompiledModel,
    CompiledObjectKey,
    CompiledProject,
    CompiledSqlScenario,
    CompileSqlScenarioCte,
)
from sqlbuild.compiler.compile.types import CompiledResourceType
from sqlbuild.compiler.planner.models import PlanWarning, ScenarioGraphPlan
from sqlbuild.compiler.planner.types import WarningSeverity
from sqlbuild.shared.constants import (
    SCENARIO_PLAN_GRAPH_VALIDATION,
    SCENARIO_PLAN_SQLGLOT_PARSE,
    SCENARIO_PLAN_SQLGLOT_UNAVAILABLE,
)
from sqlbuild.shared.helpers.sql_reference_patterns import reference_call_prefix_pattern_text
from sqlbuild.shared.helpers.sqlglot import import_sqlglot, import_sqlglot_expressions
from sqlbuild.shared.types import SqlReferenceKind

_REF_PATTERN: re.Pattern[str] = re.compile(
    rf"{reference_call_prefix_pattern_text(SqlReferenceKind.REF)}\s*"
    r"[\"']?(?P<name>[A-Za-z_][A-Za-z0-9_.]*)[\"']?\s*\)"
)


def plan_scenario_graph(
    *,
    scenario: CompiledSqlScenario,
    project: CompiledProject,
    sqlglot_enabled: bool = True,
    sqlglot_dialect: str | None = None,
) -> tuple[ScenarioGraphPlan, tuple[PlanWarning, ...]]:
    """Infer scenario target models, build closure, and required fixtures."""

    model_map: dict[str, CompiledModel] = {model.name: model for model in project.models}
    source_names: frozenset[str] = frozenset(source.name for source in project.sources)
    seed_names: frozenset[str] = frozenset(seed.name for seed in project.seeds)
    assertion_target_names, assertion_warnings = _extract_assertion_target_names(
        scenario.assertion_ctes,
        scenario_name=scenario.name,
        sqlglot_enabled=sqlglot_enabled,
        sqlglot_dialect=sqlglot_dialect,
    )
    target_model_names: tuple[str, ...] = _dedupe_names(
        (*scenario.expected_model_names, *assertion_target_names)
    )

    warnings: list[PlanWarning] = []
    warnings.extend(assertion_warnings)
    _validate_declared_names(
        scenario=scenario,
        target_model_names=target_model_names,
        assertion_target_names=assertion_target_names,
        model_map=model_map,
        source_names=source_names,
        seed_names=seed_names,
        warnings=warnings,
    )

    ref_fixture_names: frozenset[str] = frozenset(scenario.ref_fixture_names)
    source_fixture_names: frozenset[str] = frozenset(scenario.source_fixture_names)
    seed_fixture_names: frozenset[str] = frozenset(scenario.seed_fixture_names)
    dbt_ref_fixture_names: frozenset[str] = frozenset(scenario.dbt_ref_fixture_names)
    model_names: set[str] = set()
    required_ref_fixture_names: set[str] = set()
    required_source_names: set[str] = set()
    required_seed_names: set[str] = set()
    required_dbt_ref_fixture_names: set[str] = set()
    function_deps: list[CompiledObjectKey] = []
    seen_function_deps: set[CompiledObjectKey] = set()

    target_model_name: str
    for target_model_name in target_model_names:
        _walk_model_upstream(
            model_name=target_model_name,
            scenario_name=scenario.name,
            model_map=model_map,
            ref_fixture_names=ref_fixture_names,
            model_names=model_names,
            required_ref_fixture_names=required_ref_fixture_names,
            required_source_names=required_source_names,
            required_seed_names=required_seed_names,
            required_dbt_ref_fixture_names=required_dbt_ref_fixture_names,
            function_deps=function_deps,
            seen_function_deps=seen_function_deps,
            warnings=warnings,
        )

    missing_source_names: tuple[str, ...] = tuple(
        sorted(required_source_names - source_fixture_names)
    )
    source_name: str
    for source_name in missing_source_names:
        warnings.append(
            PlanWarning(
                model_name=None,
                severity=WarningSeverity.ERROR,
                message=(
                    f"Scenario '{scenario.name}' requires source '{source_name}', "
                    "but no fixture was provided. Add a CTE named "
                    f"__source__{_fixture_name_for(source_name)} AS (...)."
                ),
            )
        )

    dbt_ref_fixture_name: str
    for dbt_ref_fixture_name in sorted(required_dbt_ref_fixture_names - dbt_ref_fixture_names):
        warnings.append(
            PlanWarning(
                model_name=None,
                severity=WarningSeverity.ERROR,
                message=(
                    f"Scenario '{scenario.name}' requires dbt ref '{dbt_ref_fixture_name}', "
                    "but no fixture was provided. Add a CTE named "
                    f"__dbt_ref__{dbt_ref_fixture_name} AS (...)."
                ),
            )
        )

    plan: ScenarioGraphPlan = ScenarioGraphPlan(
        key=scenario.key,
        name=scenario.name,
        target_model_names=tuple(sorted(target_model_names)),
        assertion_target_model_names=tuple(sorted(assertion_target_names)),
        model_names=tuple(sorted(model_names)),
        source_fixture_names=tuple(sorted(required_source_names)),
        ref_fixture_names=tuple(sorted(required_ref_fixture_names)),
        seed_names=tuple(sorted(required_seed_names)),
        seed_fixture_names=tuple(sorted(required_seed_names & seed_fixture_names)),
        dbt_ref_fixture_names=tuple(sorted(required_dbt_ref_fixture_names)),
        function_deps=tuple(function_deps),
    )
    return plan, tuple(warnings)


def _extract_assertion_target_names(
    assertion_ctes: tuple[CompileSqlScenarioCte, ...],
    *,
    scenario_name: str,
    sqlglot_enabled: bool,
    sqlglot_dialect: str | None,
) -> tuple[tuple[str, ...], tuple[PlanWarning, ...]]:
    names: list[str] = []
    warnings: list[PlanWarning] = []
    cte: CompileSqlScenarioCte
    for cte in assertion_ctes:
        if sqlglot_enabled:
            try:
                names.extend(
                    _extract_assertion_target_names_with_sqlglot(
                        cte.sql_body,
                        sqlglot_dialect=sqlglot_dialect,
                    )
                )
            except ValueError as error:
                warnings.append(
                    _error(
                        f"Scenario '{scenario_name}' assertion CTE '{cte.name}' could not be "
                        f"parsed with SQLGlot: {error}",
                        code=str(getattr(error, "code", SCENARIO_PLAN_SQLGLOT_PARSE)),
                    )
                )
            continue
        match: re.Match[str]
        for match in _REF_PATTERN.finditer(cte.sql_body):
            names.append(match.group("name"))
    return _dedupe_names(tuple(names)), tuple(warnings)


def _extract_assertion_target_names_with_sqlglot(
    sql: str, *, sqlglot_dialect: str | None
) -> tuple[str, ...]:
    sqlglot_module: Any | None = import_sqlglot()
    expressions_module: Any | None = import_sqlglot_expressions()
    if sqlglot_module is None or expressions_module is None:
        error: ValueError = ValueError("SQLGlot is enabled but unavailable")
        object.__setattr__(error, "code", SCENARIO_PLAN_SQLGLOT_UNAVAILABLE)
        raise error
    try:
        parsed: Any = (
            sqlglot_module.parse_one(sql, read=sqlglot_dialect)
            if sqlglot_dialect is not None
            else sqlglot_module.parse_one(sql)
        )
    except Exception as error:
        value_error: ValueError = ValueError(str(error))
        object.__setattr__(value_error, "code", SCENARIO_PLAN_SQLGLOT_PARSE)
        raise value_error from None

    table_type: type[Any] = expressions_module.Table
    anonymous_type: type[Any] = expressions_module.Anonymous
    names: list[str] = []
    table: Any
    for table in parsed.find_all(table_type):
        anonymous: Any = table.this
        if not isinstance(anonymous, anonymous_type):
            continue
        function_name: str = str(anonymous.this).lower()
        if function_name != SqlReferenceKind.REF.function_name:
            continue
        expressions: list[Any] = list(anonymous.expressions)
        if len(expressions) != 1:
            continue
        argument: Any = expressions[0]
        if not hasattr(argument, "name"):
            continue
        names.append(str(argument.name))
    return tuple(names)


def _validate_declared_names(
    *,
    scenario: CompiledSqlScenario,
    target_model_names: tuple[str, ...],
    assertion_target_names: tuple[str, ...],
    model_map: dict[str, CompiledModel],
    source_names: frozenset[str],
    seed_names: frozenset[str],
    warnings: list[PlanWarning],
) -> None:
    expected_model_name: str
    for expected_model_name in scenario.expected_model_names:
        if expected_model_name not in model_map:
            warnings.append(
                _error(f"Scenario '{scenario.name}' expects unknown model '{expected_model_name}'.")
            )

    assertion_target_name: str
    for assertion_target_name in assertion_target_names:
        if assertion_target_name not in model_map:
            warnings.append(
                _error(
                    f"Scenario '{scenario.name}' assertion references unknown model "
                    f"'{assertion_target_name}'."
                )
            )

    if not target_model_names:
        warnings.append(
            _error(
                f"Scenario '{scenario.name}' has no target models. Add __expected__<model> "
                "or reference a model with __ref(...) inside an __assert__ CTE."
            )
        )

    ref_fixture_name: str
    for ref_fixture_name in scenario.ref_fixture_names:
        if ref_fixture_name not in model_map:
            warnings.append(
                _error(
                    f"Scenario '{scenario.name}' provides fixture for unknown model "
                    f"'{ref_fixture_name}'."
                )
            )

    source_fixture_name: str
    for source_fixture_name in scenario.source_fixture_names:
        if source_fixture_name not in source_names:
            warnings.append(
                _error(
                    f"Scenario '{scenario.name}' provides fixture for unknown source "
                    f"'{source_fixture_name}'."
                )
            )

    seed_fixture_name: str
    for seed_fixture_name in scenario.seed_fixture_names:
        if seed_fixture_name not in seed_names:
            warnings.append(
                _error(
                    f"Scenario '{scenario.name}' provides fixture for unknown seed "
                    f"'{seed_fixture_name}'."
                )
            )


def _walk_model_upstream(
    *,
    model_name: str,
    scenario_name: str,
    model_map: dict[str, CompiledModel],
    ref_fixture_names: frozenset[str],
    model_names: set[str],
    required_ref_fixture_names: set[str],
    required_source_names: set[str],
    required_seed_names: set[str],
    required_dbt_ref_fixture_names: set[str],
    function_deps: list[CompiledObjectKey],
    seen_function_deps: set[CompiledObjectKey],
    warnings: list[PlanWarning],
) -> None:
    if model_name in ref_fixture_names:
        required_ref_fixture_names.add(model_name)
        return
    if model_name in model_names:
        return

    model: CompiledModel | None = model_map.get(model_name)
    if model is None:
        return
    model_names.add(model_name)

    dep_key: CompiledObjectKey
    for dep_key in model.deps:
        if dep_key.resource_type == CompiledResourceType.MODEL:
            if dep_key.name in ref_fixture_names:
                required_ref_fixture_names.add(dep_key.name)
                continue
            if dep_key.name not in model_map:
                warnings.append(
                    _error(
                        f"Scenario '{scenario_name}' requires model '{dep_key.name}', "
                        "but it does not exist and no __ref__ fixture was provided."
                    )
                )
                continue
            _walk_model_upstream(
                model_name=dep_key.name,
                scenario_name=scenario_name,
                model_map=model_map,
                ref_fixture_names=ref_fixture_names,
                model_names=model_names,
                required_ref_fixture_names=required_ref_fixture_names,
                required_source_names=required_source_names,
                required_seed_names=required_seed_names,
                required_dbt_ref_fixture_names=required_dbt_ref_fixture_names,
                function_deps=function_deps,
                seen_function_deps=seen_function_deps,
                warnings=warnings,
            )
            continue
        if dep_key.resource_type == CompiledResourceType.SOURCE:
            required_source_names.add(dep_key.name)
            continue
        if dep_key.resource_type == CompiledResourceType.SEED:
            required_seed_names.add(dep_key.name)
            continue
        if dep_key.resource_type == CompiledResourceType.DBT_REF:
            required_dbt_ref_fixture_names.add(dep_key.name.replace(".", "__"))
            continue
        if dep_key.resource_type == CompiledResourceType.FUNCTION:
            if dep_key in seen_function_deps:
                continue
            seen_function_deps.add(dep_key)
            function_deps.append(dep_key)


def _dedupe_names(names: tuple[str, ...]) -> tuple[str, ...]:
    deduped: list[str] = []
    seen: set[str] = set()
    name: str
    for name in names:
        if name in seen:
            continue
        seen.add(name)
        deduped.append(name)
    return tuple(deduped)


def _fixture_name_for(name: str) -> str:
    return name.replace(".", "__")


def _error(message: str, *, code: str = SCENARIO_PLAN_GRAPH_VALIDATION) -> PlanWarning:
    return PlanWarning(
        model_name=None,
        severity=WarningSeverity.ERROR,
        message=message,
        code=code,
    )
