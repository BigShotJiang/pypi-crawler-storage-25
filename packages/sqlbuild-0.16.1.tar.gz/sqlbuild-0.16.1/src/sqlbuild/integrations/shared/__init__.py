"""Shared integration support."""
