"""Shared integration classes."""
