"""MotherDuck adapter."""
