"""PostgreSQL adapter."""
