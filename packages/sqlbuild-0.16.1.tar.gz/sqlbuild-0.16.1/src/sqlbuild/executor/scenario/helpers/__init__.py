"""Scenario executor helper modules."""
