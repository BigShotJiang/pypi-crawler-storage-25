"""Scenario execution entry points."""
