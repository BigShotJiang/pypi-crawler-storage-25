"""Scenario execution helpers."""
