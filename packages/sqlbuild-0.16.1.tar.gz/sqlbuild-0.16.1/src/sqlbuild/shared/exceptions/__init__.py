"""Shared exception package."""
