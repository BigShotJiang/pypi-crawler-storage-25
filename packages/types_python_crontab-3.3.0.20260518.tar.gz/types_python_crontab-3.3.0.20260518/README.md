## Typing stubs for python-crontab

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`python-crontab`](https://gitlab.com/doctormo/python-crontab) package. It can be used by type checkers
to check code that uses `python-crontab`. This version of
`types-python-crontab` aims to provide accurate annotations for
`python-crontab==3.3.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/python-crontab`](https://github.com/python/typeshed/tree/main/stubs/python-crontab)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 2.1.0
* [pyright](https://github.com/microsoft/pyright) 1.1.409

It was generated from typeshed commit
[`3402466d17144ed7edfc92940c6973167ba285af`](https://github.com/python/typeshed/commit/3402466d17144ed7edfc92940c6973167ba285af).