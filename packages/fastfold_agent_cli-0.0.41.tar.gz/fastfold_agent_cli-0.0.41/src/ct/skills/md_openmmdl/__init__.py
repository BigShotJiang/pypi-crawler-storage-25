"""OpenMMDL FastFold skill package."""

