"""Tests for lofigui package."""
