import click
import datetime
import pdb
import os
import re
import sys

from typing import TYPE_CHECKING, List
from urllib.parse import urlparse
from filelock import FileLock, Timeout

if TYPE_CHECKING:
    from requests import Request

from stoobly_agent.app.models.adapters.raw_joined import RawJoinedRequestAdapterFactory
from stoobly_agent.app.models.factories.resource.local_db.helpers.log import Log
from stoobly_agent.app.models.factories.resource.local_db.helpers.log_event import LogEvent, PUT_ACTION, REQUEST_RESOURCE, SCENARIO_RESOURCE
from stoobly_agent.app.models.factories.resource.local_db.helpers.request_snapshot import RequestSnapshot
from stoobly_agent.app.models.factories.resource.local_db.helpers.scenario_snapshot import ScenarioSnapshot
from stoobly_agent.app.models.helpers.apply import Apply
from stoobly_agent.app.models.request_model import RequestModel
from stoobly_agent.app.models.scenario_model import ScenarioModel
from stoobly_agent.app.settings import Settings
from stoobly_agent.config.data_dir import DataDir
from stoobly_agent.lib.api.keys import RequestKey, ScenarioKey

from .helpers.print_service import FORMATS, print_snapshots, select_print_options
from .helpers.update_request_snapshots_service import update_request_snapshots

@click.group(
    epilog="Run 'stoobly-agent project COMMAND --help' for more information on a command.",
    help="Manage snapshots"
)
@click.pass_context
def snapshot(ctx):
    pass

@snapshot.command(
  help="Apply snapshots.",
)
@click.option('--force', is_flag=True, default=False, help="Toggles whether resources are hard deleted.")
@click.option('--lock-timeout', default=60, type=int, help='Lock timeout in seconds (default: 60).')
@click.argument('uuid', required=False)
def apply(**kwargs):
  data_dir: DataDir = DataDir.instance()
  lock_file_path = os.path.join(data_dir.tmp_dir_path, '.snapshot-apply.lock')
  lock = FileLock(lock_file_path, timeout=kwargs.get('lock_timeout', 60))

  try:
    with lock:
      apply = Apply(force=kwargs['force']).with_logger(print)
      completed = True

      if kwargs.get('uuid'):
        completed = apply.single(kwargs['uuid'])
      else:
        completed = apply.all()

      if not completed:
        sys.exit(1)
  except Timeout:
    print("Error: Another snapshot apply command is already running. Please wait for it to complete.", file=sys.stderr)
    sys.exit(1)

@snapshot.command(
  help="Reset requests and scenarios that have snapshots to their last snapshot state."
)
@click.option('--hard', is_flag=True, default=False, help='Delete all requests and scenarios before resetting.')
@click.option('--lock-timeout', default=60, type=int, help='Lock timeout in seconds (default: 60).')
@click.option('--yes', is_flag=True, default=False, help='Proceed without confirmation.')
def reset(**kwargs):
  data_dir: DataDir = DataDir.instance()
  lock_file_path = os.path.join(data_dir.tmp_dir_path, '.snapshot-reset.lock')
  lock = FileLock(lock_file_path, timeout=kwargs.get('lock_timeout', 60))

  try:
    with lock:
      log = Log()
      apply_service = Apply().with_logger(print)

      # Determine unique resources to be reset for confirmation
      request_ids = set()
      scenario_ids = set()

      for event in log.target_events:
        if event.action != PUT_ACTION:
          continue
        if event.resource == REQUEST_RESOURCE:
          request_ids.add(event.resource_uuid)
        elif event.resource == SCENARIO_RESOURCE:
          scenario_ids.add(event.resource_uuid)

      if not kwargs.get('yes'):
        total = len(request_ids) + len(scenario_ids)
        message = f"This will reset {len(request_ids)} request(s) and {len(scenario_ids)} scenario(s) to their last snapshot state ({total} total)."
        if kwargs.get('hard'):
          message += " WARNING: --hard is set and will delete ALL requests and scenarios before resetting."
        message += " Continue?"
        if not click.confirm(message, default=False):
          print("Aborted.")
          return

      if kwargs.get('hard'):
        __hard_delete_all(force=True)

      processed_requests = set()
      processed_scenarios = set()
      success_count = 0
      failure_count = 0

      # Iterate latest snapshot events and reset corresponding resources
      for event in log.target_events:
        if event.action != PUT_ACTION:
          continue

        if event.resource == REQUEST_RESOURCE:
          uuid = event.resource_uuid
          if uuid in processed_requests:
            continue
          processed_requests.add(uuid)

          ok = apply_service.request(uuid)
          if ok:
            success_count += 1
          else:
            failure_count += 1
        elif event.resource == SCENARIO_RESOURCE:
          uuid = event.resource_uuid
          if uuid in processed_scenarios:
            continue
          processed_scenarios.add(uuid)

          ok = apply_service.scenario(uuid)
          if ok:
            success_count += 1
          else:
            failure_count += 1

      if failure_count > 0:
        print(f"Completed with {failure_count} failures ({success_count} succeeded).", file=sys.stderr)
        sys.exit(1)
  except Timeout:
    print("Error: Another snapshot reset command is already running. Please wait for it to complete.", file=sys.stderr)
    sys.exit(1)

@snapshot.command(
  help="Copy snapshots to a different data directory."
)
@click.option('--request-key', multiple=True, help='')
@click.option('--scenario-key', multiple=True, help='')
@click.argument('destination', required=True)
def copy(**kwargs):
  destination = kwargs['destination']
  __copy_scenarios(kwargs['scenario_key'], destination)
  __copy_requests(kwargs['request_key'], destination)

@snapshot.command(
  help="List snapshots.",
  name="list"
)
@click.option('--format', type=click.Choice(FORMATS), help='Format output.')
@click.option('--pending', default=False, is_flag=True, help='Lists not yet processed snapshots.')
@click.option(
  '--resource',
  default=REQUEST_RESOURCE,
  type=click.Choice([REQUEST_RESOURCE, SCENARIO_RESOURCE]),
  help=f"Defaults to {REQUEST_RESOURCE}."
)
@click.option('--scenario', help='Scenario name regex pattern to filter snapshots by')
@click.option('--search', help='Regex pattern to filter snapshots by.')
@click.option('--select', multiple=True, help='Select column(s) to display.')
@click.option('--size', default=10, help='Number of rows to display.')
@click.option('--without-headers', is_flag=True, default=False, help='Disable printing column headers.')
def _list(**kwargs):
  print_options = select_print_options(kwargs)

  log = Log()

  events = None
  if kwargs.get('pending'):
    events = log.unprocessed_events
  else:
    events = log.target_events

  if events:
    formatted_events = __format_events(events, **kwargs)

    if len(formatted_events):
      print_snapshots(formatted_events, **print_options)

@snapshot.command(
  help="Prune deleted snapshots."
)
@click.option('--dry-run', is_flag=True, default=False)
def prune(**kwargs):
  log = Log()
  log.prune(kwargs['dry_run'])

@snapshot.command(
  help="Update a snapshot.",
)
@click.option('--no-verify', is_flag=True, default=False)
@click.option('--lifecycle-hooks-path', help='Path to lifecycle hooks script.')
@click.argument('file_path')
def update(**kwargs):
  update_request_snapshots(
    file_path=kwargs['file_path'],
    lifecycle_hooks_path=kwargs.get('lifecycle_hooks_path'),
    no_verify=kwargs.get('no_verify', False)
  )

def __format_events(events: List[LogEvent], **kwargs):
  count = 0
  formatted_events = []
  size = 10 if kwargs.get('size') == None else kwargs['size']

  if kwargs.get('resource') == SCENARIO_RESOURCE:
    for event in events:
      if count == size:
        break

      if event.resource != SCENARIO_RESOURCE:
        continue

      if not __scenario_matches(event, kwargs.get('scenario')):
        continue

      snapshot = event.snapshot()
      if not __description_matches(snapshot, kwargs.get('search')):
        continue

      path = os.path.relpath(snapshot.metadata_path)

      formatted_events.append({
        **__transform_scenario(snapshot),
        'snapshot': path,
        **__transform_event(event)
      })

      count += 1
  else:
    joined_events = []
    for event in events:
      if event.resource != REQUEST_RESOURCE:
        snapshot: ScenarioSnapshot = event.snapshot()
        snapshot.iter_request_snapshots(lambda snapshot: joined_events.append((event, snapshot)))
      else:
        joined_events.append((event, event.snapshot()))

    for joined_event in joined_events:
      if count == size:
        break

      event, snapshot = joined_event
      request = __to_request(snapshot)

      if not __scenario_matches(event, kwargs.get('scenario')):
        continue

      if not __request_matches(request, kwargs.get('search')):
        continue

      path = os.path.relpath(snapshot.path)
      scenario = ''

      if event.resource == SCENARIO_RESOURCE:
        snapshot: ScenarioSnapshot = event.snapshot()
        scenario = snapshot.metadata.get('name')

      formatted_events.append({
        **__transform_request(request),
        'snapshot': path,
        **__transform_event(event),
        'scenario': scenario
      })

      count += 1

  return formatted_events



def __transform_event(event: LogEvent):
  event_dict = {}

  event_dict['uuid'] = event.uuid
  event_dict['action'] = event.action

  if event.created_at:
    event_dict['created_at'] = datetime.datetime.fromtimestamp(event.created_at / 1000)

  return event_dict

def __to_request(snapshot: RequestSnapshot):
  raw_request = snapshot.request
  if not raw_request:
    return None

  return RawJoinedRequestAdapterFactory(raw_request).python_request()

def __request_matches(request: 'Request', search: str):
  if not search:
    return True

  if not request:
    return False

  if re.match(search, request.url):
    return True

  uri = urlparse(request.url)
  if uri.hostname and re.match(search, uri.hostname):
    return True

  if re.match(search, uri.path):
    return True
  
  return False

def __transform_request(request: 'Request'):
  event_dict = { 'method': '', 'host': '', 'port': '', 'path': '', 'query': ''}

  if request:
    uri = urlparse(request.url)
    event_dict['method'] = request.method
    event_dict['host'] = uri.hostname
    event_dict['port'] = uri.port
    event_dict['path'] = uri.path
    event_dict['query'] = uri.query

  return event_dict

def __description_matches(snapshot: ScenarioSnapshot, search: str):
  if not search:
    return True

  metadata = snapshot.metadata
  return re.match(search, metadata.get('description') or '')

def __scenario_matches(event: LogEvent, search: str):
  if not search:
    return True

  if event.resource != SCENARIO_RESOURCE:
    return False

  snapshot = event.snapshot()
  metadata = snapshot.metadata
  return re.match(search, metadata.get('name') or '')

def __transform_scenario(snapshot: ScenarioSnapshot):
  event_dict = {}

  metadata = snapshot.metadata
  event_dict['name'] = metadata.get('name')
  event_dict['description'] = metadata.get('description')

  return event_dict

def __copy_requests(request_keys: list, destination: str):
  log = Log()

  data_dir = DataDir.instance(destination)
  destination_log = Log(data_dir)

  for request_key in request_keys:
    found = False

    for event in log.target_events:
      if event.action != PUT_ACTION:
        continue

      if event.resource != REQUEST_RESOURCE:
        continue

      key = RequestKey(request_key)
      if event.resource_uuid != key.id:
        continue

      snapshot: RequestSnapshot = event.snapshot()
      snapshot.copy(destination)
      resource = snapshot.find_resource()

      if not resource:
        print(f"Could not find request {key.id}", file=sys.stderr)
      else:
        destination_log.put(resource)
        found = True

      if not found:
        print(f"No snapshot found for {key}", file=sys.stderr)

def __copy_scenarios(scenario_keys: list, destination: str):
  log = Log()

  data_dir =  DataDir.instance(destination)
  destination_log = Log(data_dir)

  for scenario_key in scenario_keys:
    found = False

    for event in log.target_events:
      if event.action != PUT_ACTION:
        continue

      if event.resource != SCENARIO_RESOURCE:
        continue

      key = ScenarioKey(scenario_key)
      if event.resource_uuid != key.id:
        continue

      snapshot: ScenarioSnapshot = event.snapshot()
      snapshot.copy(destination)
      resource = snapshot.find_resource()

      if not resource:
        print(f"Could not find scenario {key.id}", file=sys.stderr)
      else:
        destination_log.put(resource)
        found = True

      if not found:
        print(f"No snapshot found for {key}", file=sys.stderr)

def __hard_delete_all(force: bool):
  settings = Settings.instance()

  request_model = RequestModel(settings)
  request_model.as_local()
  # Delete all requests first
  while True:
    res, status = request_model.index(page=0, size=100)
    if status != 200:
      print(f"Error: Failed to list requests for hard delete (status: {status}).", file=sys.stderr)
      sys.exit(1)
    requests = res.get('list') or []
    if not requests:
      break
    for r in requests:
      request_model.destroy(r['uuid'], force=force)

  scenario_model = ScenarioModel(settings)
  scenario_model.as_local()
  # Then delete all scenarios
  while True:
    res, status = scenario_model.index(page=0, size=100)
    if status != 200:
      print(f"Error: Failed to list scenarios for hard delete (status: {status}).", file=sys.stderr)
      sys.exit(1)
    scenarios = res.get('list') or []
    if not scenarios:
      break
    for s in scenarios:
      scenario_model.destroy(s['uuid'], force=force)
