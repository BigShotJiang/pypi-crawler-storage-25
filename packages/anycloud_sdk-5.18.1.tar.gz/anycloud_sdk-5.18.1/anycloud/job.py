"""Job — a future-like handle to a running deployment."""

from __future__ import annotations

import threading
import time
from typing import TYPE_CHECKING, Any

from anycloud.errors import JobFailedError, TimeoutError
from anycloud.types import DeploymentState, StatusResponse

if TYPE_CHECKING:
    from anycloud.client import Client


class Job:
    """A promise-like handle to an anycloud deployment.

    Returned by ``Client.submit()``. Supports polling, blocking waits,
    and dependency chaining via ``after``.

    Usage::

        job = client.submit("train:latest", cloud_config=cc, gpu="h100:8")
        job.wait()          # block until terminal
        print(job.state)    # DeploymentState.Completed
        print(job.logs())   # container stdout/stderr

    Dependencies::

        prep = client.submit("prep:latest", cloud_config=cc)
        train = client.submit("train:latest", cloud_config=cc, after=[prep])
        train.wait()  # waits for prep first, then train
    """

    def __init__(
        self,
        client: Client,
        deployment_id: str,
        *,
        after: list[Job] | None = None,
    ):
        self._client = client
        self._id = deployment_id
        self._state: DeploymentState | None = None
        self._status_response: StatusResponse | None = None
        self._after: list[Job] = list(after or [])
        self._submitted = after is None  # deferred jobs aren't submitted yet
        self._submit_kwargs: dict[str, Any] | None = None
        self._lock = threading.Lock()
        self._done_event = threading.Event()
        self._error: Exception | None = None

    # ------------------------------------------------------------------
    # Identity
    # ------------------------------------------------------------------

    @property
    def id(self) -> str:
        return self._id

    @property
    def state(self) -> DeploymentState | None:
        """Last-known state (call ``refresh()`` or ``status()`` to update)."""
        return self._state

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def status(self) -> StatusResponse:
        """Fetch full status from the API server (events, VM health, etc.).

        Also updates ``self.state`` as a side effect.
        """
        if not self._submitted:
            raise RuntimeError(
                f"Job {self._id} has not been submitted yet. "
                "Call wait() to submit deferred jobs."
            )
        resp = self._client._status(self._id)
        self._status_response = resp
        if resp.events:
            self._state = resp.events[-1].state
        return resp

    # ------------------------------------------------------------------
    # Blocking wait
    # ------------------------------------------------------------------

    def wait(self, *, timeout: float | None = None, poll_interval: float = 2.0) -> Job:
        """Block until the job reaches a terminal state.

        If this job has dependencies (``after``), waits for all of them
        first, then submits this job, then waits for it to complete.

        Returns ``self`` on success (Completed).
        Raises ``JobFailedError`` on Errored / Failed / Invalid.
        Raises ``TimeoutError`` if *timeout* seconds elapse.
        """
        deadline = time.monotonic() + timeout if timeout is not None else None

        # Wait for upstream dependencies in parallel
        if self._after:
            self._wait_for_deps(deadline, poll_interval)

        # Submit if deferred
        if not self._submitted:
            self._do_submit()

        # Poll until terminal
        while True:
            self.status()
            if self._state is not None and self._state.is_terminal:
                if self._state == DeploymentState.Completed:
                    return self
                raise JobFailedError(self._id, self._state.value, self._error_message())
            if deadline is not None and time.monotonic() >= deadline:
                raise TimeoutError(f"Job {self._id} did not complete within {timeout}s")
            time.sleep(poll_interval)

    # ------------------------------------------------------------------
    # Logs
    # ------------------------------------------------------------------

    def logs(self) -> str | None:
        """Return the most recent container logs (from the status endpoint)."""
        if not self._submitted:
            raise RuntimeError(
                f"Job {self._id} has not been submitted yet. "
                "Call wait() to submit deferred jobs."
            )
        resp = self._client._status(self._id, verbose=True)
        self._status_response = resp
        if resp.events:
            self._state = resp.events[-1].state
        if resp.vm_statuses:
            for vm in resp.vm_statuses:
                container = vm.get("container", {})
                if container and container.get("logs"):
                    return container["logs"]
        return None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def terminate(self) -> None:
        """Terminate the deployment."""
        self._client._terminate(self._id)
        self._state = DeploymentState.Terminated

    def resubmit(self) -> Job:
        """Resubmit a terminal deployment. Returns a new Job handle."""
        self._client._resubmit(self._id)
        return Job(self._client, self._id)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _wait_for_deps(self, deadline: float | None, poll_interval: float) -> None:
        """Wait for all upstream jobs to complete, in parallel."""
        errors: list[Exception] = []

        def _wait_one(dep: Job) -> None:
            try:
                remaining = (deadline - time.monotonic()) if deadline else None
                dep.wait(timeout=remaining, poll_interval=poll_interval)
            except Exception as exc:
                errors.append(exc)

        if len(self._after) == 1:
            _wait_one(self._after[0])
        else:
            threads = [
                threading.Thread(target=_wait_one, args=(dep,), daemon=True)
                for dep in self._after
            ]
            for t in threads:
                t.start()
            for t in threads:
                t.join()

        if errors:
            raise errors[0]

    def _do_submit(self) -> None:
        """Actually submit the deferred job to the API server."""
        if self._submit_kwargs is None:
            raise RuntimeError("Deferred job has no submit kwargs")
        data = self._client._submit_raw(self._submit_kwargs)
        self._id = data["id"]
        self._submitted = True

    def _error_message(self) -> str | None:
        if self._status_response and self._status_response.events:
            last = self._status_response.events[-1]
            if last.metadata:
                return last.metadata.get("error")
        return None

    def __repr__(self) -> str:
        state_str = self._state.value if self._state else "pending"
        deps = f", after=[{', '.join(d.id for d in self._after)}]" if self._after else ""
        return f"Job({self._id!r}, state={state_str!r}{deps})"
