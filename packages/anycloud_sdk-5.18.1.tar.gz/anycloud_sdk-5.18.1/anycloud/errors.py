"""anycloud SDK exceptions."""


class AnyCloudError(Exception):
    """Base exception for anycloud SDK."""


class APIError(AnyCloudError):
    """HTTP error from the API server."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        super().__init__(f"[{status_code}] {message}")


class ConflictError(APIError):
    """Deployment ID already exists (409)."""

    def __init__(self, message: str = "Deployment ID already exists"):
        super().__init__(409, message)


class NotFoundError(APIError):
    """Deployment not found (404)."""

    def __init__(self, message: str = "Deployment not found"):
        super().__init__(404, message)


class JobFailedError(AnyCloudError):
    """Job reached a terminal failure state."""

    def __init__(self, job_id: str, state: str, message: str | None = None):
        self.job_id = job_id
        self.state = state
        detail = f": {message}" if message else ""
        super().__init__(f"Job {job_id} {state}{detail}")


class TimeoutError(AnyCloudError):
    """Operation timed out."""
