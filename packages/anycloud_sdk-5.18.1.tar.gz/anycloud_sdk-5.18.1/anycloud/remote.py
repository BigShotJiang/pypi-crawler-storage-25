"""RemoteFunction — a decorated function that submits as an anycloud job."""

from __future__ import annotations

import functools
import inspect
from typing import TYPE_CHECKING, Any, Callable

from anycloud.image import Image
from anycloud.job import Job
from anycloud.types import CloudConfig

if TYPE_CHECKING:
    from anycloud.client import Client


class RemoteFunction:
    """A function decorated with ``@client.job()`` that can be submitted as an anycloud job.

    Function parameters become environment variables (uppercased) when submitted.
    The function body is ignored — the Docker image is what actually runs.

    Usage::

        @ac.job(image=IMG, cloud_config=my_config, gpu="h100:8")
        def train(lr: float = 0.001, batch_size: int = 32):
            ...

        job = train.submit(lr=0.01)       # submits with env LR=0.01, BATCH_SIZE=32
        job = train.submit(after=[prep])   # DAG dependency
        job.wait()
    """

    def __init__(
        self,
        client: Client,
        fn: Callable,
        *,
        image: Image | str,
        cloud_config: CloudConfig | None = None,
        gpu: str | None = None,
        docker_options: dict[str, Any] | None = None,
        command: list[str] | None = None,
    ):
        self._client = client
        self._fn = fn
        self._image = image.ref if isinstance(image, Image) else image
        self._defaults: dict[str, Any] = {}

        # Fixed job config
        self._job_kwargs: dict[str, Any] = {}
        if cloud_config is not None:
            self._job_kwargs["cloud_config"] = cloud_config
        if gpu is not None:
            self._job_kwargs["gpu"] = gpu
        if docker_options is not None:
            self._job_kwargs["docker_options"] = docker_options
        if command is not None:
            self._job_kwargs["command"] = command

        # Extract default param values from function signature
        sig = inspect.signature(fn)
        for name, param in sig.parameters.items():
            if param.default is not inspect.Parameter.empty:
                self._defaults[name] = param.default

        functools.update_wrapper(self, fn)

    @property
    def name(self) -> str:
        return self._fn.__name__

    def submit(
        self,
        *,
        after: list[Job] | None = None,
        env: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> Job:
        """Submit this function as an anycloud job.

        Keyword arguments are merged with function defaults and converted to
        uppercase environment variables. For example, ``train.submit(lr=0.01)``
        sets ``LR=0.01`` in the container environment.

        Args:
            after: Upstream jobs that must complete before this one starts.
            env: Extra environment variables (not derived from function params).
            **kwargs: Function parameter overrides → env vars.

        Returns:
            A ``Job`` promise.
        """
        # Merge defaults with overrides → env vars
        merged = {**self._defaults, **kwargs}
        job_env = {k.upper(): str(v) for k, v in merged.items()}
        if env:
            job_env.update(env)

        return self._client.submit(
            self._image,
            env=job_env if job_env else None,
            after=after,
            **self._job_kwargs,
        )

    def __call__(self, **kwargs: Any) -> Job:
        """Shorthand for ``submit(**kwargs)``."""
        return self.submit(**kwargs)

    def __repr__(self) -> str:
        params = ", ".join(
            f"{k}={v!r}" for k, v in self._defaults.items()
        )
        return f"RemoteFunction({self.name}({params}), image={self._image!r})"
