"""Image reference for anycloud jobs."""

from __future__ import annotations


class Image:
    """A reference to a Docker image.

    Usage::

        IMG = anycloud.image("pytorch/pytorch:2.1.0-cuda12.1-cudnn8-runtime")

        @ac.job(image=IMG, gpu="h100:8")
        def train(lr: float = 0.001):
            ...
    """

    def __init__(self, ref: str):
        self.ref = ref

    def __repr__(self) -> str:
        return f"Image({self.ref!r})"


def image(ref: str) -> Image:
    """Create an image reference.

    Args:
        ref: Docker image reference (e.g. ``"pytorch/pytorch:2.1.0"``).
    """
    return Image(ref)
