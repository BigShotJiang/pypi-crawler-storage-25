#!/usr/bin/env python3
"""Example: submit a 3-step chain (prep → train → eval) using the anycloud SDK."""

import os
import anycloud
from anycloud.types import CloudConfig, AWSCredentials


def main(ac: anycloud.Client):
    # -- Build a chain: prep → train → eval ----------------------------------------
    prep = ac.submit("my-prep:latest", gpu="a100:1")
    print(f"Submitted prep:  {prep.id}")

    train = ac.submit("my-train:latest", gpu="a100:8", after=[prep])
    print(f"Deferred  train: {train.id}  (waiting on prep)")

    eval_ = ac.submit("my-eval:latest", gpu="a100:1", after=[train])
    print(f"Deferred  eval:  {eval_.id}  (waiting on train)")

    # -- Wait for the full chain ----------------------------------------------------
    print("\nWaiting for chain to complete...")
    eval_.wait()

    print(f"\nprep  → {prep.state}")
    print(f"train → {train.state}")
    print(f"eval  → {eval_.state}")

    # -- Print logs from the final step ---------------------------------------------
    logs = eval_.logs()
    if logs:
        print(f"\n--- eval logs ---\n{logs}")


if __name__ == "__main__":
    cc = CloudConfig(
        cloudProvider="AWS",
        credentials=AWSCredentials(
            accessKeyId=os.environ["AWS_ACCESS_KEY_ID"],
            secretAccessKey=os.environ["AWS_SECRET_ACCESS_KEY"],
        ),
        spot=True,
    )

    with anycloud.Client(cloud_config=cc) as ac:
        main(ac)
