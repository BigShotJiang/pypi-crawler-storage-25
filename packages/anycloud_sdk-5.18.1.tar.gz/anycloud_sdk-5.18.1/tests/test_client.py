"""Tests for Client.submit() and Job interactions using httpx mock transport."""

import json
from unittest.mock import patch

import httpx
import pytest

import anycloud
from anycloud import Client, Image, Job, RemoteFunction, image
from anycloud.errors import APIError, ConflictError, JobFailedError, NotFoundError, TimeoutError
from anycloud.types import AWSCredentials, CloudConfig, DeploymentState, StatusResponse


def _mock_transport(routes: dict[str, tuple[int, dict | list]]) -> httpx.MockTransport:
    """Create a mock transport that returns canned responses by path."""

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if path in routes:
            status, body = routes[path]
            return httpx.Response(status, json=body)
        return httpx.Response(404, json={"error": "not found"})

    return httpx.MockTransport(handler)


def _status_response(state: str) -> dict:
    return {
        "events": [
            {"id": 1, "deploymentId": "j1", "state": state, "metadata": None, "createdAt": 1000}
        ],
        "status": "up" if state == "running" else "down",
    }


def _aws_config(**overrides) -> CloudConfig:
    """Build a minimal AWS CloudConfig for tests."""
    defaults = dict(
        cloudProvider="AWS",
        credentials=AWSCredentials(accessKeyId="fake", secretAccessKey="fake"),
    )
    defaults.update(overrides)
    return CloudConfig(**defaults)


class TestSubmit:
    def test_submit_returns_job(self):
        transport = _mock_transport({
            "/v1/new": (200, {"id": "test-123"}),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = ac.submit("my-image:latest", cloud_config=_aws_config())
            assert isinstance(job, Job)
            assert job.id == "test-123"

    def test_submit_with_all_options(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "full-opts"})

        cc = _aws_config(region="us-east-1", spot=True)
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.submit(
                "train:latest",
                cloud_config=cc,
                gpu="h100:8",
                env={"LR": "0.001"},
                command=["python", "train.py"],
                persist=True,
            )

        body = captured["body"]
        assert body["image"] == "train:latest"
        assert body["gpuType"] == "h100:8"
        assert body["env"] == {"LR": "0.001"}
        assert body["command"] == ["python", "train.py"]
        assert body["persist"] is True
        assert body["deploymentType"] == "job"
        assert body["cloudConfig"]["region"] == "us-east-1"
        assert body["cloudConfig"]["spot"] is True

    def test_submit_conflict_raises(self):
        transport = _mock_transport({
            "/v1/new": (409, {"error": "exists"}),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            with pytest.raises(ConflictError):
                ac.submit("img:latest", cloud_config=_aws_config())

    def test_submit_not_found_raises(self):
        transport = _mock_transport({
            "/v1/new": (404, {"error": "not found"}),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            with pytest.raises(NotFoundError):
                ac.submit("img:latest", cloud_config=_aws_config())

    def test_submit_api_error_raises(self):
        transport = _mock_transport({
            "/v1/new": (500, {"error": "internal"}),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            with pytest.raises(APIError) as exc_info:
                ac.submit("img:latest", cloud_config=_aws_config())
            assert exc_info.value.status_code == 500

    def test_submit_with_after_defers(self):
        """submit(after=[...]) should NOT call the API immediately."""
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            calls.append(request.url.path)
            return httpx.Response(200, json={"id": f"id-{len(calls)}"})

        cc = _aws_config()
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            job_a = ac.submit("a:latest", cloud_config=cc)
            assert len(calls) == 1  # job_a submitted immediately

            job_b = ac.submit("b:latest", cloud_config=cc, after=[job_a])
            assert len(calls) == 1  # job_b is deferred — no API call yet
            assert job_b._submitted is False


class TestJobStatus:
    def test_status_returns_full_response_and_updates_state(self):
        transport = _mock_transport({
            "/v1/status": (200, _status_response("running")),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            assert job.state is None  # no state before first status call
            resp = job.status()
            assert isinstance(resp, StatusResponse)
            assert len(resp.events) == 1
            assert resp.events[0].state == DeploymentState.Running
            assert job.state == DeploymentState.Running

    def test_status_raises_for_unsubmitted_job(self):
        with Client(access_token="tok") as ac:
            job = Job(ac, "j1", after=[Job(ac, "dep")])
            with pytest.raises(RuntimeError, match="not been submitted"):
                job.status()


class TestWaitWithDeps:
    def test_wait_chains_deps(self):
        """wait() on a deferred job should: wait deps → submit → wait self."""
        call_log = []

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            path = request.url.path
            call_log.append(path)

            if path == "/v1/status":
                dep_id = body["id"]
                return httpx.Response(200, json={
                    "events": [{"id": 1, "deploymentId": dep_id, "state": "completed",
                                "metadata": None, "createdAt": 1000}],
                    "status": "down",
                })
            if path == "/v1/new":
                return httpx.Response(200, json={"id": "child-id"})
            return httpx.Response(404, json={})

        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")

            parent = Job(ac, "parent-id")
            parent._state = DeploymentState.Completed  # pretend already done
            parent._submitted = True

            child = ac.submit("child:latest", cloud_config=_aws_config(), after=[parent])
            child.wait()

            # Should have: checked parent status, submitted child, checked child status
            assert "/v1/new" in call_log

    def test_wait_returns_self_on_success(self):
        transport = _mock_transport({
            "/v1/status": (200, _status_response("completed")),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            result = job.wait()
            assert result is job

    def test_wait_timeout_raises(self):
        transport = _mock_transport({
            "/v1/status": (200, _status_response("running")),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            with pytest.raises(TimeoutError, match="did not complete"):
                job.wait(timeout=0.05, poll_interval=0.01)

    def test_wait_fan_out_parallel(self):
        """Multiple deps should all be waited before child submits."""
        checked_deps = []

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            path = request.url.path
            if path == "/v1/status":
                checked_deps.append(body["id"])
                return httpx.Response(200, json={
                    "events": [{"id": 1, "deploymentId": body["id"], "state": "completed",
                                "metadata": None, "createdAt": 1000}],
                    "status": "down",
                })
            if path == "/v1/new":
                return httpx.Response(200, json={"id": "child-id"})
            return httpx.Response(404, json={})

        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")

            dep_a = Job(ac, "dep-a")
            dep_a._submitted = True
            dep_b = Job(ac, "dep-b")
            dep_b._submitted = True

            child = ac.submit("child:latest", cloud_config=_aws_config(), after=[dep_a, dep_b])
            child.wait()

            assert "dep-a" in checked_deps
            assert "dep-b" in checked_deps

    def test_wait_raises_on_dep_failure(self):
        """If a dependency fails, the deferred job should raise without submitting."""
        submit_count = [0]

        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            path = request.url.path
            if path == "/v1/status":
                return httpx.Response(200, json={
                    "events": [{"id": 1, "deploymentId": body["id"], "state": "errored",
                                "metadata": {"error": "OOM"}, "createdAt": 1000}],
                    "status": "down",
                })
            if path == "/v1/new":
                submit_count[0] += 1
                return httpx.Response(200, json={"id": f"id-{submit_count[0]}"})
            return httpx.Response(404, json={})

        cc = _aws_config()
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")

            parent = ac.submit("parent:latest", cloud_config=cc)  # immediate submit
            assert submit_count[0] == 1

            child = ac.submit("child:latest", cloud_config=cc, after=[parent])
            with pytest.raises(JobFailedError, match="errored"):
                child.wait()

            # Child should never have been submitted
            assert submit_count[0] == 1


class TestTerminate:
    def test_terminate(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json={"message": "ok"})

        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            job = Job(ac, "j1")
            job.terminate()
            assert job.state == DeploymentState.Terminated
            assert "/v1/terminate" in calls


class TestList:
    def test_list_deployments(self):
        transport = _mock_transport({
            "/v1/list": (200, [
                {
                    "id": "d1",
                    "userId": "u1",
                    "deploymentType": "job",
                    "image": "img:latest",
                    "cloudProvider": "AWS",
                    "spot": False,
                    "persist": False,
                    "state": "completed",
                    "startedAt": 1000,
                    "dockerCommand": "docker run img:latest",
                    "vmCount": 1,
                    "sshPrivateKey": "key",
                    "credentialId": "cred-1",
                },
            ]),
        })
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            deployments = ac.list()
            assert len(deployments) == 1
            assert deployments[0].id == "d1"
            assert deployments[0].state == DeploymentState.Completed


class TestJobDecorator:
    def test_decorator_returns_remote_function(self):
        with Client(access_token="tok") as ac:
            IMG = image("train:latest")

            @ac.job(image=IMG, cloud_config=_aws_config(), gpu="h100:8")
            def train(lr: float = 0.001, batch_size: int = 32):
                ...

            assert isinstance(train, RemoteFunction)
            assert train.name == "train"

    def test_submit_sends_params_as_env(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")

            IMG = image("train:latest")

            @ac.job(image=IMG, cloud_config=_aws_config(), gpu="h100:8")
            def train(lr: float = 0.001, batch_size: int = 32):
                ...

            train.submit(lr=0.01)

        body = captured["body"]
        assert body["image"] == "train:latest"
        assert body["gpuType"] == "h100:8"
        assert body["env"]["LR"] == "0.01"
        assert body["env"]["BATCH_SIZE"] == "32"  # default carried through

    def test_call_is_shorthand_for_submit(self):
        transport = _mock_transport({"/v1/new": (200, {"id": "j1"})})
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")

            @ac.job(image="img:latest", cloud_config=_aws_config())
            def work():
                ...

            job = work()
            assert isinstance(job, Job)

    def test_submit_with_after_defers(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json={"id": f"id-{len(calls)}"})

        cc = _aws_config()
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")

            @ac.job(image="prep:latest", cloud_config=cc)
            def preprocess():
                ...

            @ac.job(image="train:latest", cloud_config=cc, gpu="h100:8")
            def train(lr: float = 0.001):
                ...

            prep_job = preprocess()
            assert len(calls) == 1

            train_job = train.submit(lr=0.01, after=[prep_job])
            assert len(calls) == 1  # deferred
            assert train_job._submitted is False

    def test_image_function(self):
        img = anycloud.image("pytorch:2.1.0")
        assert isinstance(img, Image)
        assert img.ref == "pytorch:2.1.0"

    def test_extra_env_merged(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")

            @ac.job(image="img:latest", cloud_config=_aws_config())
            def train(lr: float = 0.001):
                ...

            train.submit(env={"WANDB_KEY": "abc"})

        env = captured["body"]["env"]
        assert env["LR"] == "0.001"
        assert env["WANDB_KEY"] == "abc"


class TestGet:
    def test_get_returns_job(self):
        with Client(access_token="tok") as ac:
            job = ac.get("existing-id")
            assert isinstance(job, Job)
            assert job.id == "existing-id"


class TestResubmit:
    def test_resubmit(self):
        calls = []

        def handler(request: httpx.Request) -> httpx.Response:
            calls.append(request.url.path)
            return httpx.Response(200, json={"message": "ok"})

        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            job = Job(ac, "j1")
            new_job = job.resubmit()
            assert isinstance(new_job, Job)
            assert new_job.id == "j1"
            assert "/v1/resubmit" in calls


class TestLogs:
    def test_logs_returns_container_logs(self):
        status_data = {
            "events": [
                {"id": 1, "deploymentId": "j1", "state": "running", "metadata": None, "createdAt": 1000}
            ],
            "status": "up",
            "vmStatuses": [
                {"container": {"state": "running", "logs": "epoch 1/10 loss=0.5\n"}}
            ],
        }
        transport = _mock_transport({"/v1/status": (200, status_data)})
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            assert job.logs() == "epoch 1/10 loss=0.5\n"

    def test_logs_returns_none_when_empty(self):
        transport = _mock_transport({"/v1/status": (200, _status_response("running"))})
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=transport, base_url="http://test")
            job = Job(ac, "j1")
            assert job.logs() is None


class TestCloudConfig:
    def test_submit_without_cloud_raises(self):
        with Client(access_token="tok") as ac:
            with pytest.raises(ValueError, match="cloud config is required"):
                ac.submit("img:latest")

    def test_cloud_config_fields_sent(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        cc = _aws_config(
            region="us-west-2",
            vmType="p4d.24xlarge",
            spot=True,
            inputBucket="my-input",
            outputBucket="my-output",
            diskSizeGb=200,
        )
        with Client(access_token="tok") as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.submit("img:latest", cloud_config=cc)

        cc_body = captured["body"]["cloudConfig"]
        assert cc_body["region"] == "us-west-2"
        assert cc_body["vmType"] == "p4d.24xlarge"
        assert cc_body["spot"] is True
        assert cc_body["inputBucket"] == "my-input"
        assert cc_body["outputBucket"] == "my-output"
        assert cc_body["diskSizeGb"] == 200

    def test_default_cloud_config(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "j1"})

        cc = _aws_config(region="us-east-1")
        with Client(access_token="tok", cloud_config=cc) as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            ac.submit("img:latest")

        assert captured["body"]["cloudConfig"]["region"] == "us-east-1"


class TestClientInit:
    @patch.dict("os.environ", {
        "ANYCLOUD_ACCESS_TOKEN": "env-token",
        "ANYCLOUD_API_URL": "http://custom:9090",
    })
    def test_env_var_fallbacks(self):
        with Client() as ac:
            assert ac._access_token == "env-token"
            assert ac._base_url == "http://custom:9090"

    @patch.dict("os.environ", {
        "ANYCLOUD_CONDUCTOR_URL": "http://legacy:9090",
    }, clear=False)
    def test_legacy_conductor_url_fallback(self):
        with Client(access_token="tok") as ac:
            assert ac._base_url == "http://legacy:9090"
