# anycloud Python SDK

Submit jobs, build DAGs, run workloads on any cloud.

## Install

```bash
pip install anycloud
```

## Define jobs as functions

```python
import anycloud

ac = anycloud.Client()
IMG = anycloud.image("my-training:latest")

@ac.job(image=IMG, gpu="h100:8")
def train(lr: float = 0.001, batch_size: int = 32):
    ...

# Submit — function params become env vars (LR=0.01, BATCH_SIZE=32)
job = train.submit(lr=0.01)
job.wait()
print(job.logs())
```

## DAGs via `after`

```python
@ac.job(image=anycloud.image("prep:latest"))
def preprocess():
    ...

@ac.job(image=IMG, gpu="h100:8")
def train(lr: float = 0.001):
    ...

@ac.job(image=anycloud.image("eval:latest"))
def evaluate():
    ...

prep = preprocess()
t = train.submit(lr=0.01, after=[prep])
e = evaluate.submit(after=[t])
e.wait()  # preprocess → train → evaluate
```

## Fan-out / fan-in

```python
split = preprocess()
shards = [train.submit(lr=lr, after=[split]) for lr in [0.1, 0.01, 0.001]]
best = evaluate.submit(after=shards)
best.wait()  # preprocess → 3× train (parallel) → evaluate
```

## Low-level API

```python
# submit() works without the decorator too
job = ac.submit("my-image:latest", cloud="aws", gpu="h100:8", env={"LR": "0.01"})
job.wait()
```
