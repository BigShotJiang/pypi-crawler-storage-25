# SPDX-FileCopyrightText: © Shaun Wilson
# SPDX-License-Identifier: MIT

__version__ = '1.2.0'

from .assertions import *
from .facts import *
from .theories import *
from .traits import *


__all__ = [
    'assertions',
    'collections', 'exceptions', 'strings',
    'facts',
    'fact',
    'theories',
    'theory', 'inlinedata',
    'traits',
    'trait'
]
