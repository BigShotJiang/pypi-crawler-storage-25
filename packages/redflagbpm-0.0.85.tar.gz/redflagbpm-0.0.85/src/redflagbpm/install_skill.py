"""Install or update the BPM skill bundled with this package.

Invocation::

    python3 -m redflagbpm.install_skill                    # install for every detected client
    python3 -m redflagbpm.install_skill --client claude    # install only for one client
    python3 -m redflagbpm.install_skill --user             # install at user level (~/.<client>/...)
    python3 -m redflagbpm.install_skill --target /custom/dir  # override target
    python3 -m redflagbpm.install_skill --list             # show targets without writing
    python3 -m redflagbpm.install_skill --uninstall        # remove the skill from detected targets
    python3 -m redflagbpm.install_skill --no-gitignore     # skip the sibling .gitignore

The skill (`SKILL.md`, `references/`, `scripts/`) is shipped inside this
package as `resources/skills/bpm/`. The installer copies it (or symlinks it
when `--symlink` is passed) into the per-client conventional skills folder:

    Claude Code / Claude Desktop:  <root>/.claude/skills/bpm/
    opencode:                      <root>/.opencode/skills/bpm/
    Cursor:                        <root>/.cursor/skills/bpm/
    Codex:                         <root>/.agents/skills/bpm/

Where `<root>` is either the current working directory (default) or the
user's home (with ``--user``).

To avoid polluting the destination repo, the installer also drops a
`.gitignore` next to the skill folder (e.g. `.claude/skills/.gitignore`)
with an entry for the skill name so the injected files stay untracked.
Use ``--no-gitignore`` to opt out.
"""
from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path

try:
    from importlib import resources
except ImportError:                                # pragma: no cover
    import importlib_resources as resources         # type: ignore


SKILL_NAME = "bpm"

# Map of client → relative path of its skills directory under <root>.
CLIENT_DIRS = {
    "claude":   ".claude/skills",
    "opencode": ".opencode/skills",
    "cursor":   ".cursor/skills",
    "codex":    ".agents/skills",
}


# ---------------------------------------------------------------------------
# Locate the bundled skill inside the package
# ---------------------------------------------------------------------------

def _bundled_skill_path() -> Path:
    """Absolute filesystem path to the bundled skill folder.

    Works for both wheel installs (where data lives next to the package) and
    editable installs (where it lives in ``src/redflagbpm/resources/skills/bpm``).
    """
    pkg = resources.files("redflagbpm")
    candidate = pkg / "resources" / "skills" / SKILL_NAME
    if not candidate.is_dir():
        raise FileNotFoundError(
            f"Bundled skill not found at {candidate}. "
            "Was the wheel built with the skill copied into resources/? "
            "Run sdk/python/deploy.sh from the bpmapp repo."
        )
    # `resources.files` may return a non-Path traversable on some Python versions;
    # cast to Path via str when possible.
    return Path(str(candidate))


# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------

def detect_clients(root: Path) -> list[str]:
    """Return the clients whose marker directory exists under `root`.

    The marker is the top-level folder of each client's skills path
    (e.g. `.claude` for `claude`, `.agents` for `codex`).
    """
    found = []
    for client, rel in CLIENT_DIRS.items():
        marker = root / Path(rel).parts[0]
        if marker.exists() and marker.is_dir():
            found.append(client)
    return found


def resolve_target(client: str, root: Path) -> Path:
    """Compute the per-client target directory for the bpm skill."""
    rel = CLIENT_DIRS[client]
    return root / rel / SKILL_NAME


# ---------------------------------------------------------------------------
# Install / uninstall
# ---------------------------------------------------------------------------

def install_to(target: Path, source: Path, *, symlink: bool, force: bool,
               write_gitignore: bool = True) -> None:
    """Install the bundled skill at `target` (replace if present)."""
    target.parent.mkdir(parents=True, exist_ok=True)

    if target.exists() or target.is_symlink():
        if not force:
            print(f"  ! exists, replacing: {target}")
        if target.is_symlink() or target.is_file():
            target.unlink()
        else:
            shutil.rmtree(target)

    if symlink:
        os.symlink(source, target, target_is_directory=True)
        print(f"  ✓ symlinked {target} -> {source}")
    else:
        shutil.copytree(source, target, symlinks=False,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc",
                                                       ".pytest_cache"))
        print(f"  ✓ copied to {target}")

    if write_gitignore:
        _ensure_gitignore_entry(target.parent, SKILL_NAME)


def uninstall_from(target: Path, *, clean_gitignore: bool = True) -> bool:
    if not target.exists() and not target.is_symlink():
        return False
    if target.is_symlink() or target.is_file():
        target.unlink()
    else:
        shutil.rmtree(target)
    print(f"  ✓ removed {target}")
    if clean_gitignore:
        _remove_gitignore_entry(target.parent, SKILL_NAME)
    return True


# ---------------------------------------------------------------------------
# .gitignore management
# ---------------------------------------------------------------------------

def _ensure_gitignore_entry(parent: Path, entry: str) -> None:
    """Add `entry` to <parent>/.gitignore so the destination repo doesn't
    track the injected skill files. Idempotent."""
    gi = parent / ".gitignore"
    if gi.exists():
        existing = gi.read_text(encoding="utf-8")
        for line in existing.splitlines():
            if line.strip() == entry:
                print(f"  · .gitignore already ignores '{entry}' in {gi}")
                return
        sep = "" if not existing or existing.endswith("\n") else "\n"
        gi.write_text(existing + sep + entry + "\n", encoding="utf-8")
        print(f"  ✓ appended '{entry}' to {gi}")
    else:
        gi.write_text(entry + "\n", encoding="utf-8")
        print(f"  ✓ created {gi} with '{entry}'")


def _remove_gitignore_entry(parent: Path, entry: str) -> None:
    """Remove `entry` from <parent>/.gitignore; delete the file if empty."""
    gi = parent / ".gitignore"
    if not gi.exists():
        return
    lines = gi.read_text(encoding="utf-8").splitlines()
    kept = [l for l in lines if l.strip() != entry]
    if len(kept) == len(lines):
        return
    if not any(l.strip() for l in kept):
        gi.unlink()
        print(f"  ✓ removed empty {gi}")
    else:
        gi.write_text("\n".join(kept) + "\n", encoding="utf-8")
        print(f"  ✓ removed '{entry}' from {gi}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_clients(value: str | None, root: Path) -> list[str]:
    if value in (None, "", "auto"):
        detected = detect_clients(root)
        if not detected:
            return list(CLIENT_DIRS.keys())   # nothing detected → install for all
        return detected
    if value == "all":
        return list(CLIENT_DIRS.keys())
    if value not in CLIENT_DIRS:
        raise SystemExit(
            f"Unknown client {value!r}. Use one of: "
            f"{', '.join(CLIENT_DIRS)}, all, auto."
        )
    return [value]


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="python3 -m redflagbpm.install_skill",
        description="Install/update the bundled BPM skill for "
                    "Claude Code, opencode, Cursor, or Codex.",
    )
    ap.add_argument(
        "--client",
        default="auto",
        help="Target client: claude | opencode | cursor | codex | all | auto (default). "
             "auto = install only for clients whose marker dir (.claude/, .opencode/, "
             ".cursor/, .agents/) exists under the root; if none, installs for all four.",
    )
    ap.add_argument(
        "--user",
        action="store_true",
        help="Install at user level (~/) instead of the current directory.",
    )
    ap.add_argument(
        "--target",
        type=Path,
        default=None,
        help="Override the destination folder for the skill (overrides "
             "--client / --user). The skill is copied as <target>/SKILL_NAME.",
    )
    ap.add_argument(
        "--symlink",
        action="store_true",
        help="Symlink instead of copy (handy in dev — changes to the source "
             "package are reflected immediately).",
    )
    ap.add_argument(
        "--force", "-f",
        action="store_true",
        help="Replace existing installations without warning.",
    )
    ap.add_argument(
        "--list",
        action="store_true",
        help="Show the targets that would be written, without making changes.",
    )
    ap.add_argument(
        "--uninstall",
        action="store_true",
        help="Remove the bpm skill from the resolved targets instead of installing.",
    )
    ap.add_argument(
        "--no-gitignore",
        dest="write_gitignore",
        action="store_false",
        help="Do not create/update the sibling .gitignore that prevents the "
             "destination repo from tracking the injected skill files.",
    )
    args = ap.parse_args(argv)

    try:
        source = _bundled_skill_path()
    except FileNotFoundError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    root = Path.home() if args.user else Path.cwd()

    if args.target:
        targets = [(args.target.expanduser().resolve() / SKILL_NAME)]
        scope = "custom"
    else:
        clients = _parse_clients(args.client, root)
        targets = [resolve_target(c, root) for c in clients]
        scope = ", ".join(clients)

    print(f"BPM skill source: {source}")
    print(f"Root:             {root}")
    print(f"Scope:            {scope}")
    print()

    if args.list:
        print("Targets (no changes will be made):")
        for t in targets:
            mark = "exists" if t.exists() else "new"
            print(f"  - {t}  [{mark}]")
        return 0

    if args.uninstall:
        any_removed = False
        for t in targets:
            print(f"Uninstalling: {t}")
            if uninstall_from(t, clean_gitignore=args.write_gitignore):
                any_removed = True
            else:
                print(f"  (not present, skipping)")
        return 0 if any_removed else 1

    for t in targets:
        print(f"Installing: {t}")
        install_to(t, source, symlink=args.symlink, force=args.force,
                   write_gitignore=args.write_gitignore)

    print()
    print("Done. To verify, list the installed skill:")
    for t in targets:
        print(f"  ls {t}")
    return 0


if __name__ == "__main__":     # `python3 -m redflagbpm.install_skill`
    raise SystemExit(main())
