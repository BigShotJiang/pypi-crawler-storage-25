"""Validate Value Provider (Query with id+caption) artifact YAML."""
from __future__ import annotations

import re
from typing import Any

from .common import ValidationResult
from .enums import STRING_FORMAT_PLACEHOLDER_RE
from .query import validate as validate_query


def validate(body: Any, config: Any, result: ValidationResult) -> None:
    if not isinstance(body, dict):
        result.error("not-a-mapping", "VP body must be a YAML mapping")
        return

    # A VP is a Query — run all Query checks first.
    validate_query(body, config, result)

    cols = body.get("columns") or []
    col_names = {c.get("name") for c in cols if isinstance(c, dict)}

    # id and caption must be declared as columns
    for required in ("id", "caption"):
        if required not in col_names:
            result.error(
                f"vp-missing-{required}",
                f"Value Provider columns must include {required!r}",
                "columns",
            )

    keys = body.get("keys") or []
    if isinstance(keys, list) and keys != ["id"]:
        result.warning(
            "vp-keys-not-id",
            "VP keys is recommended to be ['id']",
            "keys",
        )

    # ACL recommended
    if not (body.get("targetUsers") or body.get("targetGroups")):
        result.warning(
            "vp-no-acl",
            "VP without targetUsers/targetGroups will be invisible to end users",
            "targetGroups",
        )

    opts = body.get("options") or {}
    if isinstance(opts, dict):
        if opts.get("crud"):
            result.warning("vp-crud-true",
                           "options.crud should be false for a Value Provider",
                           "options.crud")

    if body.get("exportable"):
        result.warning("vp-exportable-true",
                       "exportable should be false for a Value Provider",
                       "exportable")

    # stringFormat placeholders refer to declared columns
    sf = body.get("stringFormat")
    if isinstance(sf, str):
        for m in STRING_FORMAT_PLACEHOLDER_RE.finditer(sf):
            placeholder = m.group(0)
            named = re.match(r"%\{(\w+)\}", placeholder)
            if named:
                if named.group(1) not in col_names:
                    result.warning(
                        "vp-stringformat-unknown-column",
                        f"stringFormat references column {named.group(1)!r} "
                        "which is not declared in columns",
                        "stringFormat",
                    )

    # SQL ?-vs-viewBindings count is already checked by query.validate
