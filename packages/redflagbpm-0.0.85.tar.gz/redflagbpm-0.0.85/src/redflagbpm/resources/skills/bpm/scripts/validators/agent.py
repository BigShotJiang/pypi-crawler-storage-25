"""Validate Agent (and Mcp) artifact YAML."""
from __future__ import annotations

from typing import Any

from .common import Severity, ValidationResult, check_regex
from .enums import (
    AGENT_PROVIDERS,
    ARTIFACT_ID_RE,
    ENV_VAR_REF_RE,
    MODEL_FQ_RE,
)


def validate(body: Any, config: Any, result: ValidationResult) -> None:
    if not isinstance(body, dict):
        result.error("not-a-mapping", "Agent body must be a YAML mapping")
        return

    # `id` in the body is no longer authoritative — the runtime takes the id
    # from the .config sidecar (CodeService.toAgentInfo overrides it). Two
    # failure modes to flag:
    #   1. Divergent: body and config both set, different values. Confusing.
    #   2. Body-only / bad shape: legacy. Runtime ignores it.
    body_id = body.get("id")
    config_id = config.get("id") if isinstance(config, dict) else None
    if body_id and config_id and str(body_id) != str(config_id):
        result.warning(
            "agent-body-config-id-mismatch",
            f"body id {body_id!r} differs from .config id {config_id!r}. "
            f"The runtime uses the .config id; remove the `id:` line from "
            f"the body YAML or align it with the .config to avoid confusion.",
            "id",
        )
    if body_id and not ARTIFACT_ID_RE.match(str(body_id)):
        result.warning(
            "agent-body-id-bad-shape",
            f"body id {body_id!r} should match PROJECT/AGENT_ID. The runtime "
            f"ignores this field — preferably remove it from the body.",
            "id",
        )

    if not body.get("name"):
        result.warning("missing-name", "name is recommended", "name")

    provider = body.get("provider")
    if not provider:
        result.error("missing-provider", "provider is required", "provider")
    elif provider not in AGENT_PROVIDERS:
        result.warning(
            "unknown-provider",
            f"provider {provider!r} not in known set "
            f"{sorted(AGENT_PROVIDERS)}",
            "provider",
        )

    model = body.get("model")
    if not model:
        result.error("missing-model", "model is required", "model")

    if not body.get("instructions"):
        result.warning("missing-instructions",
                       "instructions (system prompt) is recommended",
                       "instructions")

    # Properties — model parameters and API keys
    props = body.get("properties") or {}
    if isinstance(props, dict):
        # API key shape
        for key in ("apiKey", "embeddingModelApiKey"):
            v = props.get(key)
            if v and isinstance(v, str) and not v.startswith("@"):
                result.warning(
                    "literal-api-key",
                    f"{key} {v!r} should reference an env var as @VAR_NAME, "
                    f"not a literal value",
                    f"properties.{key}",
                )
            if isinstance(v, str) and v.startswith("@"):
                check_regex(result, v, ENV_VAR_REF_RE, "bad-env-var-ref",
                            f"properties.{key}", Severity.WARNING)

        # Numeric ranges
        for key, lo, hi in [
            ("temperature", 0.0, 2.0),
            ("topP", 0.0, 1.0),
            ("presencePenalty", -2.0, 2.0),
            ("frequencyPenalty", -2.0, 2.0),
        ]:
            val = props.get(key)
            if val is not None:
                try:
                    f = float(val)
                    if f < lo or f > hi:
                        result.warning(
                            f"{key.lower()}-out-of-range",
                            f"{key} {val} outside expected [{lo}, {hi}]",
                            f"properties.{key}",
                        )
                except (TypeError, ValueError):
                    result.error(
                        f"{key.lower()}-not-number",
                        f"{key} must be a number", f"properties.{key}",
                    )

        # Vector index dim sanity
        out_dim = props.get("outputDimensionality")
        if out_dim is not None and isinstance(out_dim, int) and out_dim > 2000:
            if props.get("ragUseIndex") not in (False, None):
                result.warning(
                    "rag-index-disabled",
                    "outputDimensionality > 2000 — IVFFlat index will be auto-disabled",
                    "properties.outputDimensionality",
                )

    # access-control lists at body level
    for fld in ("targetUsers", "targetGroups"):
        v = body.get(fld)
        if v is None:
            continue
        if not isinstance(v, list):
            result.error(f"{fld.lower()}-not-list",
                         f"{fld} must be a list of strings", fld)
            continue
        for i, x in enumerate(v):
            if not isinstance(x, str) or not x.strip():
                result.error(f"{fld.lower()}-bad-entry",
                             f"{fld}[{i}] must be a non-empty string",
                             f"{fld}[{i}]")

    alias = body.get("alias")
    if alias is not None and (not isinstance(alias, str) or not alias.strip()):
        result.error("alias-not-string", "alias must be a non-empty string", "alias")

    # tools must be list of artifact ids
    tools = body.get("tools") or []
    if not isinstance(tools, list):
        result.error("tools-not-list", "tools must be a list", "tools")
    else:
        for i, t in enumerate(tools):
            if not isinstance(t, str):
                result.error("tool-not-string",
                             f"tools[{i}] must be a string", f"tools[{i}]")
                continue
            if not ARTIFACT_ID_RE.match(t):
                result.warning("bad-tool-ref",
                               f"tools[{i}] {t!r} should be PROJECT/SCRIPT_ID",
                               f"tools[{i}]")

    # memoryEnabled requires chatStore for cross-session
    if body.get("memoryEnabled") and not body.get("chatStore"):
        result.info(
            "memory-without-chatstore",
            "memoryEnabled is true but no chatStore configured — "
            "memory will be in-memory per session only",
            "chatStore",
        )

    # model FQ (provider/model) when relevant
    if isinstance(model, str) and "/" in model:
        check_regex(result, model, MODEL_FQ_RE, "bad-model-fq",
                    "model", Severity.WARNING)
