# Common Pitfalls

A consolidated catalogue of things that fail silently, raise unexpected errors, or behave differently from what idiomatic Python / YAML usage suggests when working with BPM artifacts and the `redflagbpm` SDK. Each entry is the symptom + the correct pattern — see the per-topic reference for full context.

Audience: configurators writing artifacts on top of BPM. If something here feels wrong, verify against current code and update this file.

---

## Table of contents

- [Python SDK & `bpm.context`](#python-sdk--bpmcontext)
- [Scripts & shebangs](#scripts--shebangs)
- [Detached / forked work](#detached--forked-work)
- [Endpoints](#endpoints)
- [Services](#services)
- [Queries & data sources](#queries--data-sources)
- [Value providers](#value-providers)
- [Forms](#forms)
- [Templates & post-processors](#templates--post-processors)
- [Pages](#pages)
- [Reports](#reports)
- [Kanban](#kanban)
- [Collections](#collections)
- [Agents, prompts & RAG](#agents-prompts--rag)
- [Coder & Analyst](#coder--analyst)
- [Sandbox / Docker](#sandbox--docker)
- [Datasource utilities (PgUtils / MSSQLUtils)](#datasource-utilities-pgutils--mssqlutils)
- [.config / artifact metadata](#config--artifact-metadata)
- [Known SDK quirks](#known-sdk-quirks)

---

## Python SDK & `bpm.context`

### `getattr(bpm.context, "x", None)` does NOT default to `None`
The Context proxy raises `NameError` (not `AttributeError`) for missing keys, so the third argument of `getattr` is never used and the error propagates.
**Fix:** `bpm.context.get("x")` (or `bpm.context.get("x", default)`). It catches the missing-key path internally.

### `bpm.context.x` reads can silently fall back to `os.environ`
When the JVM event-bus address is unavailable (e.g. the script is run outside a BPM execution), reads transparently fall back to an in-memory `fakeContext` dict and then to `os.environ`. A typo in a variable name can resolve to an unrelated environment variable instead of erroring.
**Fix:** keep variable names domain-specific (avoid colliding with shell envs like `USER`, `HOME`, `PATH`, `DEBUG`). Validate critical keys with `bpm.context.get("key") is not None`.

### `bpm.context["x"] = v` outside an execution silently writes to `fakeContext`
Without a JVM address, writes are kept in process memory and never reach the BPM context. The next BPM-side read sees nothing.
**Fix:** make sure the script is invoked inside a BPM execution (the launcher sets `BPM_EVENT_BUS_REPLY` automatically). Don't construct `BPMService()` from a stand-alone script and expect writes to reach the platform.

### `bpm.user` does not exist
There is no `bpm.user` property. The user identity comes from different places depending on how the script was launched:
- HTTP endpoint (`/api/run/...`): `bpm.context.json._requestHeaders["x-user"]`.
- Service / Query / Page launched from the UI: `bpm.context.userId` (auto-injected by the launcher).
- Service launched via token URL or programmatically: only present if the caller passed it — `bpm.context.get("userId")`.

### `BPMService` is `None` when the EventBus client is not installed
If `vertx-eventbus-client` is missing, importing `BPMService` succeeds but the symbol is `None`. Instantiating it fails with `TypeError: 'NoneType' object is not callable`.
**Fix:** `pip install redflagbpm` pulls the dependency. In Docker images, ensure the install ran in the layer used by the script.

### `bpm.execute(sql, ...)` does not exist
There is no SQL helper on the `bpm` global. `bpm.service.execute(scriptId, context, timeout)` runs another script (by id), not SQL. Calls like `bpm.execute("SELECT ...")` raise — the method either does not resolve or, if it does, treats the SQL string as a script id.
**Fix:** use `redflagbpm.PgUtils.get_connection(bpm, "datasource")` (Postgres) or `redflagbpm.MSSQLUtils.get_connection(bpm, "datasource")` (SQL Server) and run statements through the cursor:
```python
from redflagbpm.PgUtils import get_connection
with get_connection(bpm, "my_datasource") as conn, conn.cursor() as cur:
    cur.execute("SELECT id, total FROM orders WHERE status = %s", (status,))
    rows = cur.fetchall()
```
For Collections, prefer `bpm.documentService.readList(collection, filter, sort, limit)`.

More: `references/sdk-python.md`.

---

## Scripts & shebangs

### `lang: "Python"` is **Jython**, not CPython
No `requests`, no `pandas`, no `numpy` — only stdlib and what Jython ships. Jython speaks Python 2.7 syntax in many builds.
**Fix:** for CPython use `lang: "Shell"` with `#!python3` (or the path to a venv) at the top of the script.

### `#!python3` shebang is **silently ignored** by `lang: "Python"`
A shebang line at the top of a Python-typed script is just a comment to Jython.
**Fix:** if you need CPython, the artifact must be `lang: "Shell"`.

### Hard-coded venv shebang breaks across deployments
`#!/opt/repos/PROJECT/.venv/bin/python` works in one container and not another. The path may not exist after redeploying to a new machine.
**Fix:** prefer `#!python3` and let the deployment image install the deps system-wide, or expose the venv path via env var resolved at runtime.

### Shell directives are scanned only in the first ~10 lines
`# CWD`, `# TIMEOUT`, `# WAIT_FOR_RESPONSE` placed below imports may be ignored.
**Fix:** put them right after the shebang, before any imports.

### `selectionScope` accepts only `{0, 1, -1, -2, -3, -4}`
Any other integer is a configuration error.

### `selectionScope: 1` flattens the selected row into `bpm.context`
Each column of the selected row becomes a top-level context variable. Other scopes pass the selection as an array — same script reading `bpm.context.id` works for `selectionScope: 1` but fails for the others.

More: `references/scripts-and-tools.md`.

---

## Detached / forked work

### `bpm.context` disappears after the engine returns
The context JSON file is deleted as soon as the script returns control to the engine. Any read from a forked child after that point raises.
**Fix:** read everything you need into local Python variables **before** `os.fork()`.

### Auth context is not inherited by the child
BPM session credentials, the EventBus address, and the user identity do not survive `fork()`.
**Fix:** capture the user id (`bpm.context.userId` or `_requestHeaders["x-user"]`) into a local before forking. To notify the user from the child, use `bpm.service.notifyUser(userId, ...)` with the captured id.

### Stdout / stderr from the child can corrupt the parent's response
If the child writes to fds 1/2 after the parent has already flushed its HTTP response, output gets injected mid-response or after the connection closes.
**Fix:** in the child, `os.close(0); os.close(1); os.close(2)` (or use `subprocess.Popen(..., stdout=DEVNULL, stderr=DEVNULL)`). Always `sys.stdout.flush()` in the parent before forking.

### Without `# TIMEOUT`, the engine waits for the forked process to exit
The early-reply pattern hinges on the engine returning while the child keeps running. Without the directive, the engine blocks on the process group and the detach is defeated.
**Fix:** declare `# TIMEOUT 100` (ms) near the top. `# WAIT_FOR_RESPONSE` only matters when the reply is sent *after* the timeout fires.

More: `references/scripts-and-tools.md` § 4.3, `references/endpoints.md` § 8.

---

## Endpoints

### `/api/run/...` rejects non-endpoint artifact types with `401 Not an endpoint`
The router only accepts artifacts of `type: ".+ endpoint"`.

### `_responseHeaders["status"]` only keeps numeric characters
Setting it to `"201 Created"` ends up as `201`. Status codes work; status reason phrases don't.

### Public endpoints have `x-user == "nobody"`
Don't gate on the absence of `x-user`; check the value. User endpoints reject `"nobody"`. Web service endpoints additionally require `x-ws-auth == "true"`.

### Only `{project}` and `{code}` are recognised path parameters
There are no first-class REST path params for arbitrary IDs.
**Fix:** pass extra IDs via query string or JSON body.

### Endpoints don't use `bpm.reply()`
Endpoint output is the script's stdout plus `_responseHeaders`. `bpm.reply()` belongs to forms / services.

### Large or binary responses should stream from disk, not stdout
Buffering big payloads through stdout doubles memory.
**Fix:** write the file under `bpm.resourceService.accessTempPath(...)` and set `_responseHeaders["resource"] = path`.

More: `references/endpoints.md`.

---

## Services

### `responseType` is UPPERCASE
`MESSAGE`, `ASSET`, `DISPLAY`, `QUERY`, `REPORT`, `SERVICE`, `TERMINAL`, `FORM`. `Message` or `message` won't match.

### `DISPLAY` in YAML, not `ASSET_DISPLAY`
The internal constant is `ASSET_DISPLAY` but the YAML value is just `DISPLAY`.

### `responseType: ASSET` short-circuits on status `100-199` or `204`
A response with one of these statuses is rendered as an HTML banner instead of being downloaded — even if the script wrote bytes. Status `>= 400` is rendered as an ERROR banner.
**Fix:** use status `100` deliberately for "I started, will deliver later" Services. Don't accidentally return `204` if you actually wanted a download.

### `responseFilter` (JQ) only applies to JSON responses
Setting it on a `MESSAGE` or `TERMINAL` Service is silently ignored.

### `${field}` substitution in `requestUrl`
VTL-style `${...}` interpolation is applied to `requestUrl` (and to the request script context). Useful for `curl`-style request URLs; surprising if you didn't expect it.

### A Service launched programmatically does NOT auto-inject `userId`
`bpm.context.userId` is only populated by the UI launcher views. Token-URL and `bpm.execute(...)` callers must pass it explicitly.
**Fix:** guard with `bpm.context.get("userId")`.

More: `references/services.md`.

---

## Queries & data sources

### `viewBindings` count must match `?` placeholders in `view`
A mismatch yields silent NULL bindings or a SQL error at runtime.

### `?` (positional) vs `::value::` (named) are not interchangeable
`?` works in `view`, `viewBindings`, and `defaultFilterExpression`. `::value::` only in filter `expression`. Swapping them silently breaks filtering.

### `defaultFilter` values that start with `;` are evaluated as JavaScript
The leading `;` is stripped, and what follows runs in a JS context (with `context` in scope). To store a literal value that begins with `;`, prepend a space.

### JSON / REST data sources ignore filter `expression` (`::value::`)
Filtering must happen in `dataSourceOptions.filter` (JQ) or client-side. The named filter is dropped.

### `dataSourceOptions.collection` and SQL `view` are mutually exclusive
Setting both produces undefined behaviour.

### `fieldType: null` on a filter is meaningful
It means "no value binding" — required when the filter `expression` has no `::value::` and you want the literal applied unconditionally. Forgetting it makes the filter inert.

### Hidden columns must still be in the SELECT
Removing a column from `columns:` only hides it. If it isn't in the SQL `SELECT` (or JSON payload), scripts reading it get `None`.

### `themeVariants` are case-sensitive
They map to a Java enum: `LUMO_COMPACT` works, `lumo_compact` throws at render.

### Filter `name` typos are silent
The name must match a `viewBindings` entry, a column name, or one referenced in `expression`. A typo produces an inert filter, no error.

### Every Query needs a sibling `.config` with `type: "Query"`, `lang: "YAML"`
Without it the artifact is not registered.

More: `references/queries.md`.

---

## Value providers

### Aliases `AS id` and `AS caption` are mandatory
The VP query is consumed by column name. Forgetting them yields an unusable VP.

### Columns referenced by `stringFormat` must be in `columns:`
Undeclared columns are silently dropped from the query result.

### `id` type must match the form field's `type`
Numeric DB column with `type: string` field → selection round-trips fail.
**Fix:** cast in SQL — `product_id::varchar AS id`.

### Missing `targetGroups`/`targetUsers` makes the VP invisible
Even if the query works, the dropdown will appear empty in the UI.

### `crud: true` exposes a CRUD UI for what is meant to be a lookup
Always set `options.crud: false` on VPs.

### `stringFormat` is cosmetic — only `id` is persisted
What the user sees in the dropdown is `stringFormat`; what is saved to the form is `id`.

### `valueProvider` references must be project-prefixed
`valueProvider: "PROJECT/VP_ID"` — bare `VP_ID` does not resolve.

### Dependent VPs need `viewBindings` to match every `?`
Same rule as queries; missing bindings throw at lookup time.

### VPs run on every dropdown open
Heavy joins or large scans translate directly into UI latency.
**Fix:** index the columns used in `WHERE` / `ORDER BY`; avoid expensive computations.

More: `references/value-providers.md`.

---

## Forms

### Unknown `hints` keys are silently ignored
Typos like `hint` (singular) or `widgetType` don't error — the field just doesn't react.
**Fix:** cross-check against the documented hints when a field "doesn't behave".

### `subtype` outside the documented set throws at form open
Falls through to `AceMode.valueOf(subtype)` and raises if the value isn't a valid Ace mode.

### `required` is an array at the schema level, not a property
```yaml
required: [name, email]      # correct
properties:
  name:
    required: true            # WRONG — silently ignored
```

### Validation script must wrap errors in `[[[ ]]]`
Plain `raise ValueError("bad")` surfaces as `"bad"` literal text, not as a styled error. Use `raise ValueError("[[[invalid email]]]")`.

More: `references/forms.md`.

---

## Templates & post-processors

### Polymer attribute names are lowercased
`innerHTML` is dropped. Use `inner-h-t-m-l` for HTML injection in Polymer-rendered cells.

### Attribute bindings need a trailing `$`
`class="[[item.x]]"` is read as a literal string. Use `class$="[[item.x]]"` to evaluate the binding.

### Markdown post-processors only set `row.template`
You can't also assign `row.foo` from a Markdown post-processor.
**Fix:** pair with a separate Python/JS post-processor when you need both.

### YAML / JSON post-processors are not template-rendered
The body is copied verbatim into `row.template`. Substitutions like `{{order_id}}` survive as literal text — they are not Mustache.

### Velocity post-processors capture stdout, not the return value
Emit the HTML directly with `print(...)`; don't `return` it. Errors written to stdout end up in the cell, too.

### Per-row execution — no per-row DB / HTTP calls
A post-processor runs once per row. N HTTP calls = N round-trips at render. Pre-aggregate in the SQL or do a single bulk lookup.

### Query-level `template` overrides `row.template`
If both are set, the post-processor's HTML is silently ignored.

### Silent script-not-found writes to `tempalte` (sic)
A script lookup failure on a post-processor writes the error message into a misspelled column called `tempalte`. If the cell looks empty for "no reason", check the script id — and yes, this is a known typo in the platform.

More: `references/templates.md`.

---

## Pages

### URL parameters arrive as strings
`?id=42` is the string `"42"`, not an int. Cast / parse as needed.

### Velocity Pages cannot query the backend
They can only read context values. To inject query results, render Velocity yourself from a Python or JavaScript Page that called the backend.

### User-supplied values must be HTML-escaped
The `escape(...)` helper exists for this purpose. Failing to escape opens an XSS hole when rendering form input or external data.

More: `references/pages.md`.

---

## Reports

### Files must be UTF-8 (no BOM)
Velocity templates are loaded with explicit UTF-8. Saving with BOM or another encoding mojibakes accents.

### Jasper image expressions are bare filenames
`"cherry.jpg"` — not absolute paths. The file must be listed in `properties.resources`.

### Non-built-in fonts silently fall back
Calibri, Inter, etc. are rendered with the JVM default unless you ship a font extension JAR.
**Fix:** stick to the PDF built-in font families (Helvetica, Times, Courier).

### Connection name in `defaultdataadapter` must match the BPM datasource name verbatim
It is the lookup key. Case mismatch → "datasource not found".

### Parameter type mismatches throw at fill time
Passing a Python `int` where the report declares `java.lang.String` raises `ClassCastException`. Either fix the declaration or stringify on the script side.

### Stale `.jasper` next to a redeployed `.jrxml`
The runtime recompiles on `.jrxml` change, but a leftover `.jasper` with the same basename can win.
**Fix:** keep one source of truth — either `.jrxml` (recommended) or precompiled `.jasper`, not both.

### Empty `targetGroups` means "all users"
Not "no one". Lock down explicitly when the report carries sensitive data.

### XLSX reports without `excelOptimized: true` reproduce visual layout
The output has merged cells and padding rows mirroring the Jasper canvas — bad for spreadsheet consumers. Set the flag for clean tabular XLSX.

More: `references/reports.md`.

---

## Kanban

### `kanbanColumns` keys are case-sensitive
If the SQL returns `'todo'` (lowercase) and the key is `TODO`, every card lands in the catch-all `other` column.

### `bodyField` is rendered as raw HTML — XSS risk
Use SQL-side escaping for any user-provided text. `titleField` is plain text and safe.

### Without `cardIdField`, drag-and-drop is unstable
Cards fall back to `hashCode()`-based ids that change on refresh.

### `cardMovedScript` does not auto-persist
If the script doesn't `UPDATE` the backing table, the next refresh reverts the move.

More: `references/kanban.md`.

---

## Collections

### Every Collection needs a sibling `.config` with `type: "Collection"`
Same rule as Queries.

### `WHERE collection = '...'` is mandatory in every SQL over Collections
All Collection documents share one physical table partitioned by the `collection` column. Forgetting the predicate scans the entire table.

### JSONB extraction needs explicit casts
- numbers: `(body#>>'{price}')::numeric`
- booleans: `(body#>>'{is_active}') = 'true'`
- strings come out as text natively.

### `$id` is the logical key, `$oid` is the physical UUID
`$id` comes from `idExpression` and may be non-unique by mistake. `$oid` is the true PK.
**Fix:** use `$oid` when you need a guaranteed unique reference.

More: `references/collections-and-mail.md`.

---

## Agents, prompts & RAG

### `provider` is a free string — typos surface only at first call
Unknown providers don't fail at parse. Use canonical capitalisation: `OpenAI`, `Anthropic`, `Gemini`, `Bedrock`.

### API keys via `@VAR_NAME`
`apiKey: "@OPENAI_API_KEY"` resolves to the env var. Omitting `apiKey` falls back to the conventional env name for that provider — be explicit when running multiple keys.

### RAG embeddings beyond 2000 dimensions disable IVFFlat
Index falls back to a slower path. Pick a model whose output fits.

### `ragResources` rebuild when files change (mtime)
A bulk `touch` on a large doc set triggers a full rebuild.

### `ragResources` and `mdResources` are different mechanisms
`ragResources` are vector-indexed and auto-augmented. `mdResources` expose a `loadContext` tool for the agent to fetch on demand. Don't expect retrieval-by-similarity from `mdResources`.

### Prompt artifacts are `type: "Script"`, `lang: "Prompt"`
`type: "Prompt"` is **invalid**. Legacy files using it must migrate.

### Workflow type strings are lowercase
`sequence`, `parallel`, `loop`, `conditional`, `supervisor`. Capitalised forms throw.

### Conditional workflows need a `condition` on every sub-agent
First match wins — order matters. Use `condition: "true"` as a fallback.

### `${var}` (Velocity) vs `{{var}}` (Langchain4j) are evaluated at different times
Velocity is resolved at build time (BPM context, process vars). `{{var}}` is read at runtime from `AgenticScope`. Mixing them up means the agent sees raw `${...}` placeholders.

### `ChatMemory` is per-agent; `AgenticScope` is per-execution
Memory carries conversational history for one agent. Scope is a shared KV bag across sub-agents in a workflow. Workflow data flow uses scope, not memory.

More: `references/agents-and-rag.md`, `references/prompts-agenticos.md`.

---

## Coder & Analyst

### SSH keys must have no passphrase
The Coder cannot prompt — passphrased keys silently fail to authenticate. Ed25519 or RSA without passphrase.

### Model field is `provider/modelID`
`openai/gpt-5.1-codex-max`. Bare `gpt-5.1-codex-max` does not resolve.

### Bedrock requires inference-profile IDs, not bare model IDs
Region-prefixed IDs (`us.`, `eu.`, `apac.`, `global.`) — raw `anthropic.claude-…` raises `ValidationException`.

### EC2 instance role: IMDS hop limit must be ≥ 2
Default is 1. Docker is one extra hop, so the container can't reach IMDS and the role isn't picked up. Fix with `aws ec2 modify-instance-metadata-options ... --http-put-response-hop-limit 2`.

### `prompt` (string) vs `instructions` (paths array)
`agent.<name>.prompt` is the literal system prompt. `instructions` is an array of file paths the agent loads on boot. Putting paths in `prompt` ships the literal path text to the model; putting prose in `instructions` looks for a file with that prose as the filename.

### Coder web tools are enabled by default
`webfetch` and `websearch` are on for all Coder repos. Deny explicitly in `opencodeConfig` for sensitive repos.

### Coder defaults are opt-out; Analyst defaults are opt-in
Coder is permissive (most use cases edit code freely). Analyst is restrictive (multi-tenant). When a Coder repo is sensitive, mirror Analyst's deny-list manually.

### `toolsPause` / MCP allowlist patterns are case-sensitive globs (no regex)
`bpm_eb_document_read_*` must match the literal name. Coder-only tool names (`bpm_coder_*`) don't exist on the Analyst.

### Analyst sandbox `mode: host` is invalid
Only Coder accepts `host`. Analyst always runs in Docker.

### Analyst `bootScript` runs on every chat spawn
Keep it cheap. Output becomes `${boot_prompt}` for use in `instructions`. Two forms exist: `#!shebang` (run via `evalScript`) or a snippet (run via `execute`).

More: `references/coder.md`, `references/analyst.md`.

---

## Sandbox / Docker

### Without `ARG BPM_BUILD_MARKER`, layers stay stale
Without the marker early in the Dockerfile, `RUN pip install` reuses cached layers indefinitely even when project content changed.
**Fix:** declare `ARG BPM_BUILD_MARKER` early; the build hash invalidates the cache.

### Build context convention is `./docker/`
Validators warn (don't fail) when `build.context` is elsewhere. Legacy repos still work but the lint surface is noisy.

### Implicit Dockerfile detection
If neither `image:` nor `build:` is set and `<baseDir>/docker/Dockerfile` exists, BPM uses it automatically. Surprising if you expected an `image:` default.

More: `references/sandbox.md`.

---

## Datasource utilities (PgUtils / MSSQLUtils)

### Connections come back with `autocommit = True`
`PgUtils.get_connection(...)` and `MSSQLUtils.get_connection(...)` both default to autocommit. `BEGIN`/`ROLLBACK` won't behave as expected, and a partial failure leaves prior statements committed.
**Fix:** set `conn.autocommit = False` immediately after acquiring the connection if you need a transaction. Or use the document service for transactional CRUD.

### MSSQL pool's `getconn()` is not a context manager
`with pool.getconn() as conn:` does NOT auto-return the connection.
**Fix:** call `pool.putconn(conn)` explicitly in a `try/finally`.

### Datasource dialect must match the helper
`get_connection()` expects `dialect: 'DEFAULT'`. `get_dblink()` and `get_pool()` (MSSQL) expect `dialect: 'MSSQL'`. Mismatch surfaces as "dialect not supported".

More: `references/sdk-python.md` (PgUtils / MSSQLUtils sections).

---

## .config / artifact metadata

### `lang` defaults to `JavaScript` when omitted
And there is no shebang fallback for `lang: "Python"`. Always set `lang` explicitly.

### `id` must be `PROJECT/ARTIFACT_ID` and `PROJECT` must equal the `project` field
Validators flag mismatches. Common when copy-pasting between projects and forgetting to rewrite the prefix.

### `form: true` is deprecated
Still accepted, but flagged. Drop it from new files.

### `type` and `lang` coherence is a warning, not an error
Unusual pairings (`Python` + `Query`) emit a validator warning, not a failure. They may still run but are likely a bug.

More: `references/artifacts-and-config.md`.

---

## Known SDK quirks

These are SDK-side defects that can confuse a configurator. Workarounds noted.

### `RuntimeService.setTaskOwner(priority=...)` is unreachable
Two methods share the name; the userId-based one shadows the priority-based one in Python. The `priority`-keyword overload cannot be called.
**Fix:** to set priority, call the runtime endpoint directly via `bpm.call("EBHBPMRuntime.setTaskPriority", body={...})` until the SDK splits the methods.

### `DocumentService.deleteByCriteria(...)` actually calls `updateByCriteria`
A copy-paste bug means the helper does not delete.
**Fix:** call `bpm.call("EBHBPMDocumentService.deleteByCriteria", body={...})` directly until the SDK is corrected.

### `register_handler(address, handler_path_string)` shells out without quoting
Spaces or shell metacharacters in the path break the spawn.
**Fix:** prefer passing a callable. If a path is required, keep it free of spaces and metacharacters.
