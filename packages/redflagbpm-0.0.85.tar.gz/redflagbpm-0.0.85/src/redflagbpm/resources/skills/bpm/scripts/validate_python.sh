#!/usr/bin/env bash
# validate_python.sh — compile-check CPython script artifacts in BPM repos.
#
# Walks one or more paths and runs `python3 -m py_compile` on every `.py`
# file that targets CPython (lang: "Shell" + #!python3 shebang). Catches
# what the YAML validator can't: SyntaxError, top-level `return`, shebang
# typos like `#!pyhton3`, and `import redflagbpm` under `lang: "Python"`
# (Jython runtime — would fail at runtime with ImportError).
#
# The interpreter used is the one selected by each file's shebang:
#   - absolute path  →  invoked directly (e.g. /opt/venv/bin/python3)
#   - `#!/usr/bin/env python3`  →  `python3` from PATH
#   - `#!python3`  →  the system `python3` (BPM resolves this to its
#                     DEFAULT venv at runtime; we can't know the path
#                     locally, so we fall back to whatever python3 is
#                     on PATH)
# If the shebang's interpreter does not exist on this host, the file
# is checked with the fallback interpreter (system `python3`) and an
# info note is emitted. Override the fallback with --python <path>.
#
# Files marked `lang: "Python"` are Jython 2.7-ish — skipped.
# Files with no .config and no python3 shebang are skipped.
#
# Skipped dirs: venv/, .venv/, anything under venvs/, .git/, .idea/,
# .opencode/, node_modules/, __pycache__/.
#
# After validation, every __pycache__/ created during the run is removed
# (pre-existing caches are left alone). Pass --keep-cache to disable.
#
# Usage:
#   validate_python.sh path/to/repo
#   validate_python.sh file1.py file2.py
#   validate_python.sh --strict path/
#   validate_python.sh --python /opt/venv/bin/python3 path/
#
# Exit codes:
#   0 — no errors (warnings allowed unless --strict)
#   1 — at least one error (or warning, with --strict)
#   2 — invalid invocation

set -u

# ----- argument parsing -----------------------------------------------------

strict=0
keep_cache=0
fallback_python=""
paths=()

while [[ $# -gt 0 ]]; do
  case "$1" in
    --strict)        strict=1; shift ;;
    --keep-cache)    keep_cache=1; shift ;;
    --python)        fallback_python="$2"; shift 2 ;;
    --python=*)      fallback_python="${1#--python=}"; shift ;;
    -h|--help)
      sed -n '2,40p' "$0" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    --)              shift; while [[ $# -gt 0 ]]; do paths+=("$1"); shift; done ;;
    -*)              echo "unknown option: $1" >&2; exit 2 ;;
    *)               paths+=("$1"); shift ;;
  esac
done

if [[ ${#paths[@]} -eq 0 ]]; then
  echo "usage: $(basename "$0") [--strict] [--keep-cache] [--python PATH] <path>..." >&2
  exit 2
fi

# Resolve fallback interpreter (system python3 by default).
if [[ -z "$fallback_python" ]]; then
  fallback_python="$(command -v python3 || true)"
fi
if [[ -z "$fallback_python" || ! -x "$fallback_python" ]]; then
  echo "no usable python3 found (looked for system python3); pass --python <path>" >&2
  exit 2
fi

# Validate paths up-front.
for p in "${paths[@]}"; do
  if [[ ! -e "$p" ]]; then
    echo "path does not exist: $p" >&2
    exit 2
  fi
done

# ----- helpers --------------------------------------------------------------

# Extract the `lang` field from a .config (works for both YAML and JSON-ish).
lang_from_config() {
  local cfg="$1"
  [[ -f "$cfg" ]] || return 0
  # Prints just the value, or empty if not found.
  grep -E '"?lang"?[[:space:]]*:' "$cfg" 2>/dev/null \
    | head -1 \
    | sed -E 's/.*"?lang"?[[:space:]]*:[[:space:]]*"?([A-Za-z]+)"?.*/\1/'
}

# First non-empty line of a file (typically the shebang).
first_nonempty_line() {
  awk 'NF { print; exit }' "$1" 2>/dev/null
}

# Given a shebang line, echo the interpreter to use, or empty.
# Examples:
#   '#!python3'                           → 'python3'
#   '#!/usr/bin/env python3'              → 'python3'  (resolved via PATH)
#   '#!/usr/bin/env python3.11'           → 'python3.11'
#   '#!/opt/venvs/data/bin/python3'       → '/opt/venvs/data/bin/python3'
interp_from_shebang() {
  local line="$1"
  # Strip leading '#!' and surrounding whitespace.
  [[ "$line" =~ ^#!\ *(.*)$ ]] || return 0
  local rest="${BASH_REMATCH[1]}"
  # Case 1: /usr/bin/env <prog> [args...]  → take <prog>
  if [[ "$rest" =~ ^/[^[:space:]]*env[[:space:]]+([^[:space:]]+) ]]; then
    echo "${BASH_REMATCH[1]}"
    return 0
  fi
  # Case 2: any other token (absolute path or bare name).
  echo "${rest%% *}"
}

# Decide if a token names a CPython3 interpreter (by name pattern).
is_python3_token() {
  case "$1" in
    python3|python3.[0-9]|python3.[0-9][0-9]) return 0 ;;
    */python3|*/python3.[0-9]|*/python3.[0-9][0-9]) return 0 ;;
    */python|python) return 0 ;;  # bare name; only allowed when .config says Shell — caller checks
    *) return 1 ;;
  esac
}

# Detect a shebang typo (e.g. `#!pyhton3`).
has_shebang_typo() {
  local line="$1"
  # First line begins with '#' and contains a typo of "python".
  if [[ "$line" =~ ^# ]] && \
     [[ "$line" =~ (pyhton|pthyon|phyton|pythn) ]]; then
    return 0
  fi
  return 1
}

# Walk a path and emit .py files (NUL-separated), skipping excluded dirs.
list_py_files() {
  local root="$1"
  if [[ -f "$root" ]]; then
    printf '%s\0' "$root"
    return 0
  fi
  find "$root" \
    \( -type d \( -name venv -o -name .venv -o -name venvs \
                  -o -name .git -o -name .idea -o -name .opencode \
                  -o -name node_modules -o -name __pycache__ -o -name env \) \
       -prune \) -o \
    \( -type f -name '*.py' -print0 \)
}

# Snapshot existing __pycache__ dirs (so we don't delete pre-existing ones).
snapshot_pycache() {
  local root="$1"
  [[ -d "$root" || -f "$root" ]] || return 0
  local search_root="$root"
  [[ -f "$root" ]] && search_root="$(dirname "$root")"
  find "$search_root" -type d -name __pycache__ \
    \( -path '*/.opencode/*' -o -path '*/node_modules/*' \
       -o -path '*/.git/*' -o -path '*/venv/*' -o -path '*/.venv/*' \
       -o -path '*/venvs/*' \) -prune -o \
    -type d -name __pycache__ -print 2>/dev/null
}

cleanup_pycache() {
  # $1 = roots (space-separated), $2 = pre-existing list (newline-separated)
  local pre="$2"
  local removed=0
  for root in $1; do
    local search_root="$root"
    [[ -f "$root" ]] && search_root="$(dirname "$root")"
    while IFS= read -r cache; do
      [[ -z "$cache" ]] && continue
      if ! grep -Fxq "$cache" <<<"$pre"; then
        rm -rf "$cache" && removed=$((removed + 1))
      fi
    done < <(find "$search_root" -type d -name __pycache__ 2>/dev/null)
  done
  echo "$removed"
}

# ----- main loop ------------------------------------------------------------

declare -i n_total=0 n_ok=0 n_err=0 n_warn=0 n_skip=0
declare -i had_warn=0

# Snapshot pycache before we start.
pre_caches=""
for root in "${paths[@]}"; do
  pre_caches+="$(snapshot_pycache "$root")"$'\n'
done

# Color hints (only if stdout is a TTY).
if [[ -t 1 ]]; then
  C_OK=$'\033[32m'; C_ERR=$'\033[31m'; C_WARN=$'\033[33m'
  C_DIM=$'\033[2m'; C_RST=$'\033[0m'
else
  C_OK=""; C_ERR=""; C_WARN=""; C_DIM=""; C_RST=""
fi

# Note: we set PYTHONDONTWRITEBYTECODE only inside the dispatch — leaving
# it unset lets py_compile write to __pycache__ as the user requested
# (we clean it up at the end).

for root in "${paths[@]}"; do
  while IFS= read -r -d '' py; do
    n_total=$((n_total + 1))

    cfg="${py}.config"
    lang="$(lang_from_config "$cfg")"
    first="$(first_nonempty_line "$py")"

    # ---- decide whether to compile -----------------------------------------
    decision="skip"
    skip_reason=""
    interp_token=""
    cpython_under_jython=0

    if [[ "$lang" == "Python" ]]; then
      decision="skip"
      skip_reason='lang: "Python" (Jython runtime)'
      # Footgun común: configurador eligió lang: "Python" (Jython) pero el script
      # importa redflagbpm, que es CPython3-only. En runtime fallaría con
      # ImportError. Detectamos el caso y emitimos warning antes de skipear.
      if grep -qE '^[[:space:]]*(import[[:space:]]+redflagbpm|from[[:space:]]+redflagbpm)' "$py" 2>/dev/null; then
        cpython_under_jython=1
      fi
    else
      interp_token="$(interp_from_shebang "$first")"
      typo=0
      has_shebang_typo "$first" && typo=1

      if [[ "$lang" == "Shell" ]]; then
        if [[ $typo -eq 1 ]]; then
          decision="cpython"           # try anyway; we'll also flag the typo
        elif [[ -n "$interp_token" ]] && is_python3_token "$interp_token"; then
          decision="cpython"
        elif [[ -n "$interp_token" ]]; then
          decision="cpython"           # other interpreter under lang: Shell — try and surface errors
        else
          decision="cpython"
        fi
      else
        # No .config — depend on the shebang.
        if [[ $typo -eq 1 ]]; then
          decision="skip"; skip_reason="shebang typo: '$first' (no .config to confirm CPython)"
        elif [[ -n "$interp_token" ]] && is_python3_token "$interp_token" \
             && [[ "$interp_token" != "python" && "$interp_token" != *"/python" ]]; then
          decision="cpython"
        elif [[ -n "$interp_token" ]] && is_python3_token "$interp_token" ; then
          # bare `python` without `3` — ambiguous
          decision="skip"; skip_reason="shebang '$first' is ambiguous (no .config to disambiguate)"
        else
          decision="skip"; skip_reason="no .config and no python3 shebang"
        fi
      fi
    fi

    if [[ "$decision" == "skip" ]]; then
      if [[ $cpython_under_jython -eq 1 ]]; then
        n_warn=$((n_warn + 1)); had_warn=1
        printf '%s!%s  %s  %s(skipped — see warning)%s\n' \
          "$C_WARN" "$C_RST" "$py" "$C_DIM" "$C_RST"
        printf '     %s!%s [warn/wrong-lang] script imports redflagbpm but .config has lang: "Python" (Jython runtime).\n' \
          "$C_WARN" "$C_RST"
        printf '       redflagbpm requires CPython3 — change .config to `lang: "Shell"` and add\n'
        printf '       shebang `#!python3` as the first line. See skill bpm § scripts-and-tools.\n'
      else
        n_skip=$((n_skip + 1))
        printf '%s⏭%s  %s  %s[skipped: %s]%s\n' \
          "$C_DIM" "$C_RST" "$py" "$C_DIM" "$skip_reason" "$C_RST"
      fi
      continue
    fi

    # ---- pick the interpreter ---------------------------------------------
    interp="$fallback_python"
    interp_note=""
    if [[ -n "$interp_token" ]]; then
      if [[ "$interp_token" = /* ]]; then
        if [[ -x "$interp_token" ]]; then
          interp="$interp_token"
        else
          interp_note="shebang '$interp_token' not executable on this host; using $fallback_python"
        fi
      else
        # Bare name — let PATH resolve it.
        if which_path="$(command -v "$interp_token" 2>/dev/null)"; then
          interp="$which_path"
        else
          interp_note="shebang '$interp_token' not on PATH; using $fallback_python"
        fi
      fi
    fi

    # ---- run py_compile ----------------------------------------------------
    err_output="$("$interp" -m py_compile "$py" 2>&1)"
    rc=$?

    # ---- report ------------------------------------------------------------
    declare -i this_err=0 this_warn=0
    file_lines=()

    if [[ $typo -eq 1 ]]; then
      file_lines+=("     ${C_ERR}✗${C_RST} [error/bad-shebang]:1 first line does not select python3 — BPM will not dispatch the script ('$first')")
      this_err=$((this_err + 1))
    fi

    if [[ $rc -ne 0 ]]; then
      # Parse last line of output for "ExceptionType: msg".
      summary="$(printf '%s\n' "$err_output" | grep -v '^$' | tail -1)"
      # Try to extract a line number.
      lineno="$(printf '%s\n' "$err_output" | grep -oE 'line [0-9]+' | head -1 | awk '{print $2}')"
      loc=""
      [[ -n "$lineno" ]] && loc=":$lineno"
      file_lines+=("     ${C_ERR}✗${C_RST} [error/syntax-error]${loc} ${summary:-py_compile failed (rc=$rc)}")
      this_err=$((this_err + 1))
    fi

    if [[ -n "$interp_note" ]]; then
      file_lines+=("     ${C_DIM}i${C_RST} [info/interp-fallback] $interp_note")
      this_warn=$((this_warn + 1))
    fi

    if [[ ${this_err} -gt 0 ]]; then
      n_err=$((n_err + 1))
      printf '%s✗%s  %s  %s(%s)%s\n' "$C_ERR" "$C_RST" "$py" "$C_DIM" "$interp" "$C_RST"
      printf '%s\n' "${file_lines[@]}"
    elif [[ ${this_warn} -gt 0 ]]; then
      n_warn=$((n_warn + 1)); had_warn=1
      printf '%s!%s  %s  %s(%s)%s\n' "$C_WARN" "$C_RST" "$py" "$C_DIM" "$interp" "$C_RST"
      printf '%s\n' "${file_lines[@]}"
    else
      n_ok=$((n_ok + 1))
      printf '%s✓%s  %s\n' "$C_OK" "$C_RST" "$py"
    fi
  done < <(list_py_files "$root")
done

# ----- cleanup pycache ------------------------------------------------------

removed=0
if [[ $keep_cache -eq 0 ]]; then
  removed="$(cleanup_pycache "${paths[*]}" "$pre_caches")"
fi

# ----- summary --------------------------------------------------------------

echo
printf '%d file(s): %d ok, %d error, %d warn-only, %d skipped\n' \
  "$n_total" "$n_ok" "$n_err" "$n_warn" "$n_skip"
if [[ "$removed" != "0" && -n "$removed" ]]; then
  printf '%scleaned up %s __pycache__ dir(s)%s\n' "$C_DIM" "$removed" "$C_RST"
fi

if [[ $n_err -gt 0 ]] || ( [[ $strict -eq 1 ]] && [[ $had_warn -eq 1 ]] ); then
  exit 1
fi
exit 0
