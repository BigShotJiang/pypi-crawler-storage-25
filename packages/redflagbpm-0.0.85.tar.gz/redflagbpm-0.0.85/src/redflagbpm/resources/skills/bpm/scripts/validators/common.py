"""Shared helpers for all validators.

Provides the issue/severity model, YAML loading, .config detection and
artifact-type auto-detection used by `validate.py` to dispatch to the right
validator module.
"""
from __future__ import annotations

import enum
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Optional


class Severity(str, enum.Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class Issue:
    severity: Severity
    code: str
    message: str
    path: str = ""
    line: Optional[int] = None

    def to_dict(self) -> dict[str, Any]:
        d = {
            "severity": self.severity.value,
            "code": self.code,
            "message": self.message,
        }
        if self.path:
            d["path"] = self.path
        if self.line is not None:
            d["line"] = self.line
        return d


@dataclass
class ValidationResult:
    file: str
    artifact_type: str = "unknown"
    issues: list[Issue] = field(default_factory=list)

    def add(
        self,
        severity: Severity,
        code: str,
        message: str,
        path: str = "",
        line: Optional[int] = None,
    ) -> None:
        self.issues.append(Issue(severity, code, message, path, line))

    def error(self, code: str, message: str, path: str = "") -> None:
        self.add(Severity.ERROR, code, message, path)

    def warning(self, code: str, message: str, path: str = "") -> None:
        self.add(Severity.WARNING, code, message, path)

    def info(self, code: str, message: str, path: str = "") -> None:
        self.add(Severity.INFO, code, message, path)

    @property
    def errors(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == Severity.ERROR]

    @property
    def warnings(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == Severity.WARNING]

    @property
    def is_ok(self) -> bool:
        return not self.errors

    def is_strict_ok(self) -> bool:
        return not self.errors and not self.warnings

    def to_dict(self) -> dict[str, Any]:
        return {
            "file": self.file,
            "artifact_type": self.artifact_type,
            "ok": self.is_ok,
            "issues": [i.to_dict() for i in self.issues],
        }


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

try:
    import yaml  # PyYAML
except ImportError as e:  # pragma: no cover
    raise SystemExit(
        "PyYAML is required: pip install pyyaml"
    ) from e


def load_yaml(path: Path) -> Any:
    """Load a YAML or JSON file. Returns the parsed structure."""
    text = path.read_text(encoding="utf-8")
    suffix = path.suffix.lower()
    if suffix == ".json":
        return json.loads(text)
    return yaml.safe_load(text)


def load_artifact_pair(path: Path) -> tuple[Any, Optional[Any]]:
    """Load an artifact and its sibling .config (if any).

    Args:
        path: Path to either the artifact body or the .config file.

    Returns:
        (body_data, config_data). Either may be None if the corresponding
        file is missing or unreadable.
    """
    if path.name.endswith(".config"):
        config_path = path
        body_path = path.with_name(path.name[:-len(".config")])
    else:
        body_path = path
        config_path = path.with_name(path.name + ".config")

    body = None
    config = None
    if body_path.exists():
        try:
            body = load_yaml(body_path)
        except Exception:
            body = None
    if config_path.exists():
        try:
            config = load_yaml(config_path)
        except Exception:
            config = None
    return body, config


# ---------------------------------------------------------------------------
# Type detection
# ---------------------------------------------------------------------------

# Heuristics for body shapes when no .config is available.
_BODY_HEURISTICS: list[tuple[str, callable]] = [
    ("repo",          lambda d: isinstance(d, dict) and "url" in d and "key" in d),
    # McpInfo: has profile + toolList (or `tools` typo), no provider/model.
    # Catches both correct YAML and the common `tools:` typo so the dedicated
    # mcp validator can flag it explicitly.
    ("mcp",           lambda d: isinstance(d, dict) and "profile" in d
                                and ("toolList" in d or "tools" in d)
                                and "model" not in d),
    ("analyst",       lambda d: isinstance(d, dict) and "id" in d and "model" in d
                                and ("sandbox" in d or "prompts" in d or "tools" in d)),
    ("prompt",        lambda d: isinstance(d, dict)
                                and (("workflow" in d) or ("subAgents" in d)
                                     or ("agent" in d and "prompt" in d))),
    ("agent",         lambda d: isinstance(d, dict) and "provider" in d and "model" in d
                                and "instructions" in d),
    ("query",         lambda d: isinstance(d, dict)
                                and ("dataSource" in d or "view" in d
                                     or ("dataSourceOptions" in d
                                         and isinstance(d.get("dataSourceOptions"), dict)
                                         and "collection" in d["dataSourceOptions"]))
                                and "columns" in d),
    ("kanban",        lambda d: isinstance(d, dict)
                                and isinstance(d.get("options"), dict)
                                and bool(d["options"].get("kanban"))),
    ("value_provider", lambda d: isinstance(d, dict) and "stringFormat" in d
                                 and "columns" in d and "view" in d),
    ("service",       lambda d: isinstance(d, dict)
                                and "requestUrl" in d and "responseType" in d),
    ("menu",          lambda d: isinstance(d, dict) and "id" in d and "items" in d),
    ("form",          lambda d: isinstance(d, dict) and d.get("type") == "object"
                                and isinstance(d.get("properties"), dict)),
    ("sandbox",       lambda d: isinstance(d, dict)
                                and ("image" in d or "build" in d)
                                and "service" in d),
]

_CONFIG_TYPE_TO_VALIDATOR = {
    "Query": "query",
    "Service": "service",
    "Form": "form",
    "Agent": "agent",
    "Mcp": "mcp",
    "Analyst": "analyst",
    "Menu": "menu",
    "Collection": "form",    # Collection schema shape == Form shape (JSON Schema)
    "Report": "config_file", # Report bodies are binary; only .config is YAML
    "Page": "config_file",
    "Public endpoint": "config_file",
    "User endpoint": "config_file",
    "Web service endpoint": "config_file",
    "Script": "config_file",
}


def detect_artifact_type(
    body: Any,
    config: Any,
    explicit: Optional[str] = None,
) -> str:
    """Decide which validator module should run.

    Priority:
      1. `explicit` argument (from --type CLI flag).
      2. `config["type"]` mapped via `_CONFIG_TYPE_TO_VALIDATOR`.
      3. Heuristics on the body shape.
      4. "config_file" (assume the input is a .config and validate just that).
    """
    if explicit:
        return explicit
    if isinstance(config, dict):
        t = config.get("type")
        if isinstance(t, str) and t in _CONFIG_TYPE_TO_VALIDATOR:
            return _CONFIG_TYPE_TO_VALIDATOR[t]
    for name, predicate in _BODY_HEURISTICS:
        try:
            if predicate(body):
                return name
        except Exception:
            continue
    return "config_file"


# ---------------------------------------------------------------------------
# Reusable validators
# ---------------------------------------------------------------------------

def check_required_fields(
    result: ValidationResult,
    obj: Any,
    required: Iterable[str],
    path: str = "",
) -> None:
    if not isinstance(obj, dict):
        result.error("not-a-mapping", f"expected an object at {path or 'root'}", path)
        return
    for field_name in required:
        if field_name not in obj or obj[field_name] in (None, "", [], {}):
            result.error(
                "missing-required",
                f"required field '{field_name}' is missing or empty",
                f"{path}.{field_name}" if path else field_name,
            )


def check_unknown_keys(
    result: ValidationResult,
    obj: Any,
    allowed: set[str],
    path: str = "",
    severity: Severity = Severity.WARNING,
) -> None:
    if not isinstance(obj, dict):
        return
    extra = set(obj.keys()) - allowed
    for k in sorted(extra):
        result.add(
            severity,
            "unknown-field",
            f"unknown field '{k}' (not in {sorted(allowed)})",
            f"{path}.{k}" if path else k,
        )


def check_enum(
    result: ValidationResult,
    value: Any,
    valid: Iterable[Any],
    code: str,
    field_path: str,
    severity: Severity = Severity.ERROR,
) -> None:
    if value is None:
        return
    if value not in valid:
        result.add(
            severity,
            code,
            f"value {value!r} not in {sorted(valid) if all(isinstance(v, str) for v in valid) else list(valid)}",
            field_path,
        )


def check_regex(
    result: ValidationResult,
    value: Any,
    pattern: re.Pattern[str],
    code: str,
    field_path: str,
    severity: Severity = Severity.ERROR,
) -> None:
    if value is None:
        return
    if not isinstance(value, str) or not pattern.match(value):
        result.add(
            severity,
            code,
            f"value {value!r} does not match {pattern.pattern}",
            field_path,
        )
