"""Validate Form artifacts and embedded inputSchema blocks (JSON Schema)."""
from __future__ import annotations

from typing import Any

from .common import Severity, ValidationResult
from .enums import FORM_SUBTYPES, ARTIFACT_ID_RE


_BUILTIN_VPS = {"people", "groups", "projects"}
_FORMAT_KNOWN = {"date", "datetime", "time", "email", "password",
                 "text", "rich", "uri", "date-time"}


def validate(body: Any, config: Any, result: ValidationResult) -> None:
    if not isinstance(body, dict):
        result.error("not-a-mapping", "form schema must be a YAML mapping")
        return

    if body.get("type") != "object":
        result.error("root-not-object",
                     "Form schema root must be type: object", "type")

    properties = body.get("properties")
    if properties is not None and not isinstance(properties, dict):
        result.error("properties-not-mapping",
                     "properties must be a mapping", "properties")
        return

    required = body.get("required")
    if required is not None:
        if not isinstance(required, list):
            result.error("required-not-list",
                         "required must be a list", "required")
        elif isinstance(properties, dict):
            for r in required:
                if r not in properties:
                    result.error(
                        "required-not-in-properties",
                        f"required field {r!r} is not declared in properties",
                        "required",
                    )

    if isinstance(properties, dict):
        for prop_name, prop in properties.items():
            _validate_property(prop_name, prop, result, path=f"properties.{prop_name}")


def _validate_property(name: str, prop: Any, result: ValidationResult,
                       path: str) -> None:
    if not isinstance(prop, dict):
        result.error("property-not-mapping",
                     f"property {name!r} must be a mapping", path)
        return

    if "type" not in prop and "$ref" not in prop \
            and "oneOf" not in prop and "anyOf" not in prop:
        result.error("property-missing-type",
                     f"property {name!r} must declare 'type' (or $ref/oneOf/anyOf)",
                     path)

    fmt = prop.get("format")
    if fmt is not None and fmt not in _FORMAT_KNOWN:
        result.warning(
            "unknown-format",
            f"format {fmt!r} is not in the documented set {sorted(_FORMAT_KNOWN)}",
            f"{path}.format",
        )

    hints = prop.get("hints")
    if isinstance(hints, dict):
        _validate_hints(hints, result, path=f"{path}.hints")

    # array items
    if prop.get("type") == "array":
        items = prop.get("items")
        if isinstance(items, dict):
            if "type" not in items and "$ref" not in items:
                result.error("array-items-missing-type",
                             f"array items must declare 'type'", f"{path}.items")
            if items.get("type") == "object":
                sub_props = items.get("properties")
                if isinstance(sub_props, dict):
                    for sp_name, sp in sub_props.items():
                        _validate_property(sp_name, sp, result,
                                           path=f"{path}.items.properties.{sp_name}")

    # object nesting
    if prop.get("type") == "object":
        sub = prop.get("properties")
        if isinstance(sub, dict):
            for sp_name, sp in sub.items():
                _validate_property(sp_name, sp, result,
                                   path=f"{path}.properties.{sp_name}")


def _validate_hints(hints: dict, result: ValidationResult, path: str) -> None:
    subtype = hints.get("subtype")
    if subtype is not None and subtype not in FORM_SUBTYPES:
        result.warning(
            "unknown-subtype",
            f"subtype {subtype!r} is not in the known set "
            f"(static + common AceMode); verify it is a valid AceMode",
            f"{path}.subtype",
        )

    vp = hints.get("valueProvider")
    if vp and isinstance(vp, str) and vp not in _BUILTIN_VPS:
        if not ARTIFACT_ID_RE.match(vp):
            result.warning(
                "bad-vp-id",
                f"valueProvider {vp!r} should be 'people' / 'groups' / 'projects' "
                f"or PROJECT/ARTIFACT_ID",
                f"{path}.valueProvider",
            )

    # Upload requires resourcePath
    if subtype == "upload" and not hints.get("resourcePath"):
        result.error(
            "upload-missing-resource-path",
            "subtype: upload requires hints.resourcePath",
            f"{path}.resourcePath",
        )
