# Reports

Reports are BPM artifacts that turn a template plus runtime data into a downloadable document — PDF, XLSX, HTML, DOCX, ODT, or JPG. The template engine is either **JasperReports** (binary `.jrxml` compiled at run time) or **Apache Velocity** (HTML/text templates merged into a JSON `content` object). Reports are launched from Services, Scripts, or directly from the menu, and always live as a `Binary` artifact with a sibling `.config`.

> **Source of truth**: `dev/redflag/core/services/report/ReportOptions.java`, `dev/redflag/core/services/report/ReportData.java`, `dev/redflag/core/services/report/ReportProperties.java`, `dev/redflag/core/reports/DefaultReportService.java`, `dev/redflag/core/reports/template/VelocityReport.java`. The Java code wins when it disagrees with this guide.
>
> **See also**: `references/artifacts-and-config.md` (the sibling `.config` file), `references/services.md` (invoking reports from a Service with `responseType: REPORT`), `references/queries.md` (using a Query as the data source), `references/reports-jasper.md` (authoring `.jrxml` in Jaspersoft Studio: supported version, Data Adapters, filter properties, JSON sources, resource bundling).

---

## Report types

| Type | Template extension | Engine | Typical data source |
|---|---|---|---|
| **Jasper** | `.jrxml` (or pre-compiled `.jasper`) | JasperReports | SQL connection embedded in the template; parameters from caller |
| **Velocity** | `.vhtml` | Apache Velocity → HTML → format converter | JSON `content` injected from a Python/JS script |
| **HTML** | `.vhtml` rendered straight to HTML | Velocity (no PDF conversion) | Same as Velocity |

Jasper is preferred for tabular, paginated, print-grade output (invoices, statements). Velocity wins when the layout is HTML-shaped (dashboards, emails, simple receipts) or when the data does not live in a SQL connection.

---

## The `.config` file

Every Report is `lang: "Binary"` and `type: "Report"`. The `.config` sits next to the template file with the same basename plus `.config`.

```yaml
project: "HLW"
id: "HLW/Clientes"
lang: "Binary"
type: "Report"
properties:
  targetGroups: ["ADMIN", "DEVELOPERS", "USER"]
  resources: ["cherry.jpg"]
```

| Property | Purpose |
|---|---|
| `properties.resources[]` | Auxiliary files copied alongside the template at execution time — images, sub-report templates, header fragments, CSS. Reference them by **bare filename** from the `.jrxml` / `.vhtml`. |
| `properties.targetGroups[]` | ACL: which groups can list and run the report. Empty means all users. |
| `properties.targetUsers[]` | ACL by username (rarely used; prefer groups). |
| `properties.menus[]` | Menu paths where the report appears in the UI. |
| `properties.icon` | Icon name for the menu entry. |
| `properties.title` | Display title (defaults to the file basename). |
| `properties.excelOptimized` | When `true`, XLSX output skips Jasper's pixel-positioning to produce clean spreadsheet rows. |
| `properties.filterGroupInfo` | Optional filter group used by the standalone Reports view to prompt parameters. |

Backed by `dev/redflag/core/services/report/ReportProperties.java`.

---

## Output formats

`ReportOptions.Format` enum — six values:

| Format | Notes | Format-specific options |
|---|---|---|
| `PDF` | Default for printable reports. | `autoprint`, `silentPrint`, `password` |
| `HTML` | Web-friendly. Velocity reports produce HTML natively. | — |
| `XLSX` | Excel. Combine with `properties.excelOptimized: true` for clean rows. | — |
| `ODT` | OpenDocument Text. | — |
| `DOCX` | Microsoft Word. | — |
| `JPG` | Renders one page as an image. | `pageIndex`, `reportIndex`, `zoom` |

Common option key for all formats: `resource` — absolute output path (e.g. `/tmp/report.pdf`). When omitted, the service returns a temp-file URL.

---

## API: `renderReport` and `renderReports`

The Python `redflagbpm` library exposes both methods on `bpm.reportService`. Java equivalents live in `dev.redflag.core.services.ReportService` (event-bus proxy) and `DefaultReportService` (implementation).

### `renderReport(options, reportData)`

Generate one report.

```python
#!python3
import redflagbpm

bpm = redflagbpm.BPMService()

options = {
    "format": "PDF",                        # ReportOptions.Format enum value
    "options": {                            # format-specific knobs
        "resource": "/tmp/clientes.pdf",
        "autoprint": False
    }
}

reportData = {
    "reportName": "HLW/Clientes",           # PROJECT/REPORT_ID
    "parameters": {                         # passed to template ($P{cliente} in Jasper)
        "cliente": "Acme"
    },
    "contentType": "NONE"                   # report uses its own SQL data adapter
}

result = bpm.reportService.renderReport(options=options, reportData=reportData)
bpm.reply(f"Report ready: {result}")
```

### `renderReports(options, reports)`

Generate several reports and concatenate them into a single output (typical for stitched PDF books). `options` applies to the whole batch; `reports` is a list of `reportData` dicts.

```python
result = bpm.reportService.renderReports(
    options={"format": "PDF", "options": {"resource": "/tmp/pack.pdf"}},
    reports=[
        {"reportName": "HLW/Clientes",     "parameters": {"cliente": None}},
        {"reportName": "HLW/Proveedores",  "parameters": {}}
    ]
)
```

---

## Passing parameters

Parameters arrive at the template as `$P{name}` (Jasper) or `$name` (Velocity). The `parameters` dict is a JSON object — values must be JSON-serialisable (`str`, `int`, `float`, `bool`, `null`, list, dict). Datetimes need to be stringified by the caller.

| Convention | What to do |
|---|---|
| Optional Jasper parameters | Make the SQL clause defensive: `where $P{cliente} is null or contact_name like '%'\|\|$P{cliente}\|\|'%'`. Pass `None` when the user leaves the field blank. |
| Numeric parameters | Pass real Python `int`/`float`. Jasper coerces to the parameter's declared `class`. |
| Subreport parameters | Set them under `parameters` with the same key the master report passes to the subreport's `<subreportParameter>`. |
| Velocity context | Every key in `parameters` becomes a top-level Velocity variable (`$title`, `$company`). The `content` field, when supplied, is also exposed as `$content`. |

---

## Subreports

Subreports are extra `.jrxml` files referenced from the master via `<subreport>` with a `subreportExpression` like `"sub_detail.jasper"`. Two ways to ship them:

1. **As resources of the master**: list the subreport file in `properties.resources` of the master's `.config`. The runtime drops them next to the master before execution, so a bare-filename expression resolves.
2. **As their own Report artifact**: useful only if you want ACL or direct invocation on the subreport. The master still references them by filename, so a copy ends up in `resources` regardless.

Pre-compile to `.jasper` when subreports are large — it skips the per-call jrxml compile cost. Compiled and source files coexist in the same folder.

---

## Data sources

`ReportData.contentType` — values from the `ContentType` enum:

| `contentType` | Where the data comes from |
|---|---|
| `NONE` *(default)* | Report supplies its own data: Jasper uses its embedded `<queryString>` against the connection named in `com.jaspersoft.studio.data.defaultdataadapter`; Velocity reads only `parameters`. |
| `SQL` | Run a SQL `content` string against the report's adapter and feed the rows as the JR datasource. |
| `JSON_STRING` | `content` is a JSON document passed as the datasource (Jasper `JsonDataSource`) or as `$content` (Velocity). |
| `JSON_URL` | `content` is an `http(s)://` URL; the runtime fetches and parses JSON. |
| `JSON_RESOURCE` | `content` is a `PROJECT/path/to/file.json` resource — fetched from BPM storage. |

### SQL connection (Jasper)

Inside Jaspersoft Studio set:

```xml
<property name="com.jaspersoft.studio.data.defaultdataadapter" value="NORTHWIND"/>
```

The string `NORTHWIND` must match the BPM connection name, otherwise the report fails at execution with "Data adapter not found". Parameters in the SQL are bound by name (`$P{cliente}`) and class (`java.lang.String`, `java.lang.Integer`, ...).

### JSON content (Velocity)

```python
import json
content = json.dumps({
    "customers": [
        {"name": "John Doe",  "email": "john@example.com",  "total": 1500.00},
        {"name": "Jane Smith","email": "jane@example.com",  "total": 2300.50}
    ]
})

reportData = {
    "reportName": "HLW/CUSTOMER_LIST",
    "parameters": {"title": "Customer Report"},
    "content": content,
    "contentType": "JSON_STRING"
}
```

The Velocity template references `$content.customers` and iterates with `#foreach($c in $content.customers) ... #end`.

---

## Examples

### Jasper PDF report

`HLW/Clientes.jrxml.config`:

```yaml
project: "HLW"
id: "HLW/Clientes"
lang: "Binary"
type: "Report"
properties:
  targetGroups: ["ADMIN", "USER"]
  resources: ["cherry.jpg"]
```

The `.jrxml` declares a `<parameter name="cliente" class="java.lang.String"/>` and a SQL `<queryString>` against the `NORTHWIND` adapter. Invocation:

```python
result = bpm.reportService.renderReport(
    options={"format": "PDF", "options": {"resource": "/tmp/clientes.pdf"}},
    reportData={"reportName": "HLW/Clientes", "parameters": {"cliente": "Acme"}}
)
```

### Velocity HTML report

`HLW/CUSTOMER_LIST.vhtml`:

```html
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>$title</title></head>
<body>
  <h1>$title</h1>
  <table>
    <tr><th>Name</th><th>Email</th><th>Total</th></tr>
    #foreach($c in $content.customers)
      <tr><td>$c.name</td><td>$c.email</td><td>$c.total</td></tr>
    #end
  </table>
</body>
</html>
```

Invoked exactly like the JSON sample above with `format: "HTML"`. To deliver as PDF, change `format` — the HTML is converted by the format pipeline.

---

## End-to-end: report invoked from a Service

Goal: a Service `HLW/SRV_REPORT_CLIENTES` that prompts for a customer name and returns the rendered PDF.

`forms/SRV_REPORT_CLIENTES.yaml`:

```yaml
name: "HLW/SRV_REPORT_CLIENTES"
caption: "Customer listing"
icon: "REPORT"
requestUrl: "run:HLW/SCRIPT_REPORT_CLIENTES"
responseType: "ASSET"           # The service returns a downloadable file
inputSchema:
  type: object
  required: [cliente]
  properties:
    cliente:
      type: string
      title: "Customer (optional)"
targetGroups: ["USER"]
```

`scripts/SCRIPT_REPORT_CLIENTES.py`:

```python
#!python3
import redflagbpm

bpm = redflagbpm.BPMService()
params = bpm.context.input or {}

result = bpm.reportService.renderReport(
    options={
        "format": "PDF",
        "options": {"resource": f"/tmp/clientes_{bpm.context.requestId}.pdf"}
    },
    reportData={
        "reportName": "HLW/Clientes",
        "parameters": {"cliente": params.get("cliente") or None}
    }
)

bpm.reply(result)               # returns the file path; ASSET response type streams it
```

Pair both YAML files with their `.config` (see `references/artifacts-and-config.md`). The user clicks the menu entry, fills the form, the script runs, the PDF streams back.

---

## Common gotchas

- **Encoding**: Velocity templates must be saved as UTF-8 (`engine.getTemplate(name, "UTF-8")` in `VelocityReport.java`). Save with BOM-less UTF-8 or accented characters render as mojibake.
- **Image paths**: in Jasper use bare filenames in `imageExpression` (e.g. `"cherry.jpg"`), not absolute paths. The file must be listed in `properties.resources` of the `.config` so the runtime stages it next to the template.
- **Velocity image paths**: same rule — reference images by basename. The HTML-to-PDF converter resolves them relative to the merged HTML's directory, which is the staging folder.
- **Fonts**: Jasper renders PDFs with the JVM default font set unless you embed a font extension JAR. Reports designed in Jaspersoft Studio with non-standard fonts (e.g. Calibri) will silently substitute. Stick to PDF-built-in fonts (`Helvetica`, `Times-Roman`, `Courier`) or deploy a font extension.
- **Connection name mismatch**: `com.jaspersoft.studio.data.defaultdataadapter` must equal the BPM connection name verbatim — it is the lookup key, not just designer metadata.
- **`contentType: NONE` with no embedded query**: Jasper renders an empty body. If your report should iterate over `parameters`, you still need an empty `<queryString>` and a JR datasource (commonly `JREmptyDataSource` or a `JsonDataSource` via `JSON_STRING`).
- **Parameter type mismatches**: passing a Python `int` to a parameter declared `java.lang.String` raises a `ClassCastException` at fill time. Stringify or fix the declaration.
- **`renderReports` order**: pages are concatenated in the order of the `reports` list. There is no per-report cover/divider unless you add it as another entry.
- **`.jasper` vs `.jrxml` cache**: when you redeploy a `.jrxml`, the runtime recompiles. If you also ship a stale `.jasper` with the same basename it can win — keep one source of truth per report.
- **ACL surprises**: an empty `targetGroups` is "all users", not "no one". Lock down explicitly when the report exposes sensitive data.
- **XLSX layout**: without `excelOptimized: true`, JR reproduces visual positioning with merged cells and empty padding rows. Set the flag when you actually want a usable spreadsheet.

---

## Validation summary

Before publishing a Report artifact:

- `.config` exists, is YAML/JSON, has `type: "Report"` and `lang: "Binary"`.
- `id` matches `PROJECT/<basename>` and is unique in the project.
- `properties.targetGroups` is set (or deliberately empty for public reports).
- Every image / subreport / asset referenced from the template appears in `properties.resources`.
- Jasper: `com.jaspersoft.studio.data.defaultdataadapter` matches a real BPM connection name.
- Jasper: every `$P{...}` used in SQL or expressions has a `<parameter>` declaration with the right `class`.
- Velocity: template saved as UTF-8; every `$variable` is either in `parameters` or under `$content`.
- Caller sets `format` to one of `PDF | HTML | XLSX | ODT | DOCX | JPG`.
- Caller sets `contentType` consistent with the template (`NONE` for self-fetching Jasper, `JSON_STRING` for Velocity-with-data).
- If invoked from a Service, the Service's `responseType` matches the desired delivery (`ASSET` to download, `REPORT` to open in viewer).
- Smoke test in each target output format you advertise — PDF passing does not guarantee XLSX is usable.
