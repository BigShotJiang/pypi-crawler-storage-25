"""Validate Query artifact YAML."""
from __future__ import annotations

import re
from typing import Any

from .common import Severity, ValidationResult, check_enum, check_regex
from .enums import (
    ARTIFACT_ID_RE,
    COLUMN_ALIGN,
    COLUMN_FIELD_TYPES,
    COLUMN_WIDTH_TYPES,
    GRID_VARIANTS,
    SCRIPT_REF_RE,
)


def validate(body: Any, config: Any, result: ValidationResult) -> None:
    if not isinstance(body, dict):
        result.error("not-a-mapping", "Query body must be a YAML mapping")
        return

    if not body.get("caption"):
        result.warning("missing-caption", "caption is recommended", "caption")

    # name
    name = body.get("name")
    if name is not None:
        check_regex(result, name, ARTIFACT_ID_RE, "bad-artifact-id", "name",
                    Severity.WARNING)

    _validate_data_source(body, result)
    _validate_view_bindings(body, result)
    _validate_columns(body, result)
    _validate_filter_group(body, result)
    _validate_actions(body, result)
    _validate_options(body, result)


def _validate_data_source(body: dict, result: ValidationResult) -> None:
    ds = body.get("dataSource")
    view = body.get("view")
    dso = body.get("dataSourceOptions") if isinstance(body.get("dataSourceOptions"), dict) else {}
    opts = body.get("options") if isinstance(body.get("options"), dict) else {}

    is_collection = (
        bool(dso.get("collection"))
        or bool(opts.get("collection"))
        or bool(opts.get("crud"))
    )
    is_script = isinstance(ds, str) and ds.startswith("run:")
    is_url = isinstance(ds, str) and re.match(r"^https?://", ds)
    is_curl = isinstance(ds, str) and ds.startswith("curl ")
    is_sql = ds and not (is_script or is_url or is_curl) and not is_collection

    if not (is_collection or is_script or is_url or is_curl or is_sql):
        result.warning(
            "no-data-source",
            "could not detect a data source type (set dataSource or dataSourceOptions.collection)",
            "dataSource",
        )

    # SQL view + collection mutual exclusion
    if is_collection and view:
        result.warning(
            "view-with-collection",
            "view is set together with a Collection data source — Collections do not use view",
            "view",
        )

    # JSON/REST + filter expressions with ::value::
    if not is_sql and not is_collection:
        fg = body.get("filterGroup")
        if isinstance(fg, dict):
            for f in fg.get("filters", []) or []:
                if isinstance(f, dict) and isinstance(f.get("expression"), str) \
                        and "::value::" in f["expression"]:
                    result.warning(
                        "filter-expression-on-non-sql",
                        "filter.expression with ::value:: is ignored for JSON/REST sources",
                        "filterGroup.filters",
                    )
                    break


def _validate_view_bindings(body: dict, result: ValidationResult) -> None:
    view = body.get("view")
    bindings = body.get("viewBindings") or []
    if not isinstance(view, str):
        return
    if not isinstance(bindings, list):
        result.error("view-bindings-not-list", "viewBindings must be a list",
                     "viewBindings")
        return
    # Count '?' that are NOT inside single-quoted strings (a rough SQL parse
    # that handles common cases like LIKE '%' || ? || '%').
    placeholder_count = _count_sql_placeholders(view)
    if placeholder_count != len(bindings):
        # Warning, not error: the count heuristic can miss '?' inside ::value::
        # expansion or comments, and viewBindings is sometimes a superset by design.
        result.warning(
            "view-bindings-count-mismatch",
            f"viewBindings has {len(bindings)} entries but view has "
            f"~{placeholder_count} '?' placeholders (excluding quoted strings)",
            "viewBindings",
        )


def _count_sql_placeholders(sql: str) -> int:
    """Count '?' placeholders that are not inside single-quoted strings."""
    count = 0
    in_string = False
    i = 0
    while i < len(sql):
        c = sql[i]
        if c == "'":
            # Handle '' escape inside string
            if in_string and i + 1 < len(sql) and sql[i + 1] == "'":
                i += 2
                continue
            in_string = not in_string
        elif c == "?" and not in_string:
            count += 1
        i += 1
    return count


def _validate_columns(body: dict, result: ValidationResult) -> None:
    cols = body.get("columns")
    if cols is None:
        return
    if not isinstance(cols, list):
        result.error("columns-not-list", "columns must be a list", "columns")
        return
    for i, col in enumerate(cols):
        path = f"columns[{i}]"
        if not isinstance(col, dict):
            result.error("column-not-mapping", "each column must be a mapping", path)
            continue
        if not col.get("name"):
            result.error("column-missing-name", "column missing 'name'", path)
        if not col.get("caption"):
            result.warning("column-missing-caption",
                           "column missing 'caption' (recommended)", path)

        ft = col.get("fieldType")
        if ft is not None:
            check_enum(result, ft, COLUMN_FIELD_TYPES,
                       "unknown-field-type", f"{path}.fieldType",
                       Severity.WARNING)

        align = col.get("align")
        check_enum(result, align, COLUMN_ALIGN, "bad-align",
                   f"{path}.align", Severity.ERROR)

        width = col.get("width")
        if width is not None:
            # ColumnInfo.java: `Integer width`. Aceptamos int o string que
            # parseable como int (algunos YAMLs vienen con `width: "120"`).
            ok = False
            if isinstance(width, bool):
                ok = False  # bools son ints en Python — explícitamente rechazar
            elif isinstance(width, int):
                ok = width >= 0
            elif isinstance(width, str):
                try:
                    ok = int(width) >= 0
                except ValueError:
                    ok = False
            if not ok:
                result.error("bad-width",
                             f"width must be a non-negative integer, got {width!r}",
                             f"{path}.width")

        width_type = col.get("widthType")
        if width_type is not None:
            check_enum(result, width_type, COLUMN_WIDTH_TYPES,
                       "bad-width-type",
                       f"{path}.widthType", Severity.ERROR)


def _validate_filter_group(body: dict, result: ValidationResult) -> None:
    fg = body.get("filterGroup")
    if fg is None:
        return
    if not isinstance(fg, dict):
        result.error("filter-group-not-mapping", "filterGroup must be a mapping",
                     "filterGroup")
        return
    filters = fg.get("filters") or []
    if not isinstance(filters, list):
        result.error("filters-not-list", "filterGroup.filters must be a list",
                     "filterGroup.filters")
        return

    declared = set()
    for i, f in enumerate(filters):
        path = f"filterGroup.filters[{i}]"
        if not isinstance(f, dict):
            result.error("filter-not-mapping", "filter must be a mapping", path)
            continue
        name = f.get("name")
        if not name:
            result.error("filter-missing-name", "filter missing 'name'", path)
        else:
            declared.add(name)
        if not f.get("caption"):
            result.warning("filter-missing-caption",
                           "filter missing 'caption' (recommended)", path)

        if f.get("possibleValues") and f.get("valueProvider"):
            result.warning(
                "filter-possible-and-vp",
                "possibleValues and valueProvider are mutually exclusive",
                path,
            )

        # Filter expression with ::value:: but fieldType: null
        expr = f.get("expression")
        if (isinstance(expr, str) and "::value::" in expr
                and f.get("fieldType") in (None, "null")):
            result.warning(
                "expression-without-binding",
                "::value:: in expression but fieldType is null — value is never bound",
                f"{path}.expression",
            )

        vp = f.get("valueProvider")
        if vp:
            check_regex(result, vp, ARTIFACT_ID_RE, "bad-vp-id",
                        f"{path}.valueProvider", Severity.WARNING)

    # dependents reference declared filter names
    for i, f in enumerate(filters):
        if not isinstance(f, dict):
            continue
        deps = f.get("dependents") or []
        for d in deps:
            if d not in declared:
                result.warning(
                    "dependent-not-found",
                    f"dependents['{d}'] does not match any filter name",
                    f"filterGroup.filters[{i}].dependents",
                )

    # defaultFilter keys
    df = fg.get("defaultFilter")
    if isinstance(df, dict):
        for k in df.keys():
            if k not in declared:
                result.warning(
                    "default-filter-unknown-name",
                    f"defaultFilter['{k}'] does not match any filter name",
                    "filterGroup.defaultFilter",
                )


def _validate_actions(body: dict, result: ValidationResult) -> None:
    for field in ("details", "reports", "services", "scripts", "postProcessors"):
        items = body.get(field) or []
        if not isinstance(items, list):
            result.error(f"{field}-not-list", f"{field} must be a list", field)
            continue
        for i, item in enumerate(items):
            if not isinstance(item, str):
                result.error("ref-not-string", f"{field}[{i}] must be a string",
                             f"{field}[{i}]")
                continue
            ref = item
            if ref.startswith("run:"):
                ref = ref[len("run:"):]
            if not ARTIFACT_ID_RE.match(ref) and not SCRIPT_REF_RE.match(item):
                result.warning(
                    "bad-ref-id",
                    f"{item!r} does not match PROJECT/ARTIFACT_ID",
                    f"{field}[{i}]",
                )


def _validate_options(body: dict, result: ValidationResult) -> None:
    opts = body.get("options") or {}
    if not isinstance(opts, dict):
        return
    tv = opts.get("themeVariants")
    if tv is not None:
        if not isinstance(tv, list):
            result.error("theme-variants-not-list", "themeVariants must be a list",
                         "options.themeVariants")
        else:
            for i, v in enumerate(tv):
                check_enum(result, v, GRID_VARIANTS, "bad-theme-variant",
                           f"options.themeVariants[{i}]", Severity.ERROR)
