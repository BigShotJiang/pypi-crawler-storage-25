# Templates and Post-Processors

> Customize how query rows render and/or transform row data before display.

Use a **template** when you want to replace the default tabular grid with a single-column custom HTML layout (Polymer/Vaadin syntax with `[[item.field]]` bindings). Use a **post-processor** when you need to mutate row data per-row in Python/JavaScript (computed fields, lookups), or to generate the row template dynamically from Markdown/Velocity/YAML/JSON.

Cross-references: `references/queries.md` for where `template` and `postProcessors` sit in `QueryInfo`, and `references/value-providers.md` for how templates customize combo-box rendering.

---

## Templates (Polymer/Vaadin)

A template is a single string of HTML using Polymer-style data binding. When a query (or value provider) defines `template`, the grid stops rendering individual columns and instead renders **one column per row** using your HTML.

Source: `dev/redflag/vaadinui/data/query/QueryGrid.java` — `TemplateRenderer.of(metadata.getTemplate())` plus a `withProperty` call for each `ColumnInfo` (so every declared column is automatically bindable).

### Syntax basics

| Construct | Purpose |
|---|---|
| `[[item.fieldName]]` | One-way binding to a row field (text content) |
| `data-status$="[[item.status]]"` | Bind to an HTML attribute (note the trailing `$`) |
| `class$="status-[[item.status]]"` | Computed class binding |
| `<div inner-h-t-m-l="[[item.html]]"></div>` | Render raw HTML — Polymer requires hyphenated form, never `innerHTML` |
| `[[[item.id]]]` | Triple-bracket: literal escape used in some BPM internal templates |

All row fields are exposed via `[[item.<name>]]`, **including hidden fields** (columns produced by SQL or post-processors but not declared in `columns`). The grid renderer iterates only over declared `ColumnInfo`s when registering bindings, so any extra field returned by SQL is also accessible because it lives on the same `ProxyData`.

### Example: status badges

```yaml
template: |
  <div class$="row-[[item.status]]" style="padding:8px;">
    <strong>[[item.order_id]]</strong> — [[item.company_name]]
    <span style="margin-left:8px;padding:2px 8px;border-radius:10px;color:#fff;background:[[item.status_color]];">
      [[item.status]]
    </span>
  </div>
```

`status_color` here is a hidden field — produced either by SQL (`CASE status WHEN ...`) or by a post-processor (see below).

### Templates in value providers

Same syntax. The template is used to render dropdown items in combo boxes (`StringReferenceJsonField`, `LongReferenceJsonField`, `IntegerReferenceJsonField`). Typically:

```yaml
template: |
  <div>
    <strong>[[item.caption]]</strong>
    <small>[[item.contact_name]] · [[item.phone]]</small>
  </div>
```

---

## Post-processors

Post-processors are scripts identified by `PROJECT/SCRIPT_ID` and executed **once per row** after the SQL result is fetched, in array order. Each script can:

- Mutate the `row` dict (add computed fields, transform values, look up external data).
- Generate the row's HTML template by writing it into `row.template` (only for certain `lang` values — see below).

Source: `dev/redflag/bpm/impl/SimpleBPMService.java` `setPostProcessors(...)`.

### Configuration

```yaml
postProcessors:
  - "PROJECT/POST_PROCESS_ORDER"
  - "PROJECT/POST_PROCESS_BADGE"
```

Execution order matters: the second script sees `row` after the first has mutated it.

### Script context

Two ways the script sees the row, depending on the engine:

- `row` — the live `JsonObject`. Mutations persist (this is what the grid will use).
- All top-level row fields are also bound as individual variables (e.g. `order_id`, `company_name`).

This means in Python/JavaScript you should mutate via `row[...]` rather than reassigning the bare variables (the latter would only rebind the local).

### Languages and their behavior

The dispatch in `SimpleBPMService.setPostProcessors` switches on `CodeDTO.lang` (constants in `dev/redflag/bpm/dto/CodeDTO.java:24-34`):

| `lang` | Effect on the row |
|---|---|
| `Python` | Run via `codeService.executeCode`. Mutate `row` in-place. Stdout is captured but ignored. |
| `JavaScript` | Same as Python — mutate `row`. Stdout captured but ignored. |
| `Markdown` | Source is parsed by commonmark and rendered HTML is **assigned to `row.template`**. Cannot mutate other fields. |
| `YAML` | Raw script text is **assigned verbatim to `row.template`**. No parsing, no interpolation. |
| `JSON` | Raw script text is **assigned verbatim to `row.template`**. No parsing. |
| `Velocity` | VTL is rendered with `row` (and all row fields) as context; the writer's contents are **assigned to `row.template`**. Errors are also written to `row.template`. |

**Practical takeaway:** if you need computed fields *plus* a custom template, either (a) chain a Python/JS post-processor (writes fields) followed by a Velocity post-processor (reads them, emits HTML), or (b) generate the HTML inside the Python script and write it to a hidden field, then declare a top-level `template:` that does `<div inner-h-t-m-l="[[item.html_content]]"></div>`.

### Template precedence

If the `QueryInfo.template` field is set, `QueryGrid` uses it directly. Otherwise the grid falls back to `row.template` (when present, populated by a Markdown/YAML/JSON/Velocity post-processor). A `template:` defined on the query always wins over `row.template`.

---

## Top-level fields (where they live)

These two top-level fields on `QueryInfo` (`dev/redflag/core/services/info/QueryInfo.java`) cover the topic:

| Field | Type | Default | Purpose |
|---|---|---|---|
| `template` | `String` (HTML) | `null` | Polymer template for the row. When set, replaces all column rendering. |
| `postProcessors` | `List<String>` | `[]` | Ordered list of `PROJECT/SCRIPT_ID` references. Each script runs per row. |

Related but separate:
- `stringFormat` — printf-style fallback rendering when no `template` is set; still uses one column per row.
- There is **no** column-level template; templates are query-level only.

---

## End-to-end example

**Goal:** orders grid with a card-style row showing a colored status badge and a formatted total.

### 1. Query (`PROJECT/QRY_ORDERS.config`)

```yaml
name: "PROJECT/QRY_ORDERS"
caption: "Orders"
dataSource: "NORTHWIND"
view: |
  SELECT order_id, company_name, order_date, total_amount, status
  FROM orders
columns:
  - { name: order_id,     caption: "Order",    fieldType: integer }
  - { name: company_name, caption: "Customer", fieldType: string  }
  - { name: order_date,   caption: "Date",     fieldType: date    }
  - { name: total_amount, caption: "Total",    fieldType: number  }
  - { name: status,       caption: "Status",   fieldType: string  }
keys: [ order_id ]
postProcessors:
  - "PROJECT/POST_PROCESS_ORDER"
template: |
  <div style="padding:10px;border-left:4px solid [[item.status_color]];">
    <div style="display:flex;justify-content:space-between;">
      <strong>Order #[[item.order_id]]</strong>
      <span style="background:[[item.status_color]];color:#fff;padding:2px 8px;border-radius:10px;">
        [[item.status]]
      </span>
    </div>
    <div>[[item.company_name]] — [[item.total_formatted]]</div>
  </div>
```

### 2. Post-processor (`PROJECT/POST_PROCESS_ORDER` with `lang: Python`)

```python
#!python3
status = (row.get('status') or '').lower()
row['status_color'] = {
    'pending':    '#ffc107',
    'processing': '#17a2b8',
    'shipped':    '#28a745',
    'delivered':  '#6c757d',
    'cancelled':  '#dc3545',
}.get(status, '#6c757d')

amount = row.get('total_amount') or 0
row['total_formatted'] = f"${float(amount):,.2f}"
```

`status_color` and `total_formatted` are not declared in `columns` — they are hidden but accessible to the template via `[[item.status_color]]` / `[[item.total_formatted]]`.

---

## Common gotchas

- **`inner-h-t-m-l`, not `innerHTML`.** Polymer converts attribute names to lowercase; camelCase is silently dropped. Use the hyphenated form for HTML injection.
- **Attribute bindings need a trailing `$`.** `class="[[item.x]]"` is read as a literal string by the browser; use `class$="[[item.x]]"`.
- **Markdown post-processors overwrite `row.template`.** They do not let you set other fields. Pair with a separate Python/JS post-processor if you need both.
- **YAML/JSON post-processors are not rendered.** The script body is copied verbatim to `row.template`. There is no `{{order_id}}` substitution in the engine — those characters survive as literal text.
- **Velocity captures stdout, not the return value.** Just emit the HTML directly; don't assign it. Errors go to `row.template` too (so a syntax error becomes visible HTML).
- **There's a typo in the error path.** When the script lookup fails, `SimpleBPMService` writes to `tempalte` (sic) instead of `template`. If a row mysteriously shows no error and no content, check the script ID resolves.
- **Post-processors run for every row.** Avoid per-row DB or HTTP calls; cache lookups outside the loop is not possible (each script invocation is independent), so prefer SQL joins or a single batched call from a different layer.
- **A query-level `template` always beats `row.template`.** If you set both, the post-processor's HTML is silently ignored.
- **Hidden columns are visible to templates.** You don't need to declare a column in `columns:` for `[[item.x]]` to work — only for sorting/filtering/header display.

---

## Validation summary

There is no dedicated validator for `template` or `postProcessors`. They are stored as plain strings and a `List<String>` on `QueryInfo` and parsed by Jackson without schema constraints. The only effective validation is at runtime:

- **Template:** invalid Polymer/HTML produces a render error in the browser console; Vaadin's `TemplateRenderer.of(...)` accepts any string.
- **Post-processor reference:** if `codeService.readCode(script)` fails (script not found, no permission), the error message is written into `row.tempalte` (note the typo) and processing continues with the next row.
- **Script lang:** must be one of the constants in `CodeDTO`. The dispatch only special-cases `Markdown`, `YAML`, `JSON`, `Velocity`; everything else falls through to a generic `executeCode` that mutates `row` only.

What `validators/query.py` adds (cross-file mode):
- Each entry in `postProcessors` is a valid `PROJECT/ARTIFACT_ID`.
- The referenced script's `lang` is a valid value (warning if the lang is unsuitable for the use case — e.g. `Markdown` paired with a query that already declares `template:`, since the markdown output will be ignored).
- For value providers, the template references at least one of `id` and `caption` to be useful in dropdowns.

---

## Where this is implemented

- `dev/redflag/core/services/info/QueryInfo.java` — `template` and `postProcessors` fields.
- `dev/redflag/vaadinui/data/query/QueryGrid.java` — `TemplateRenderer.of(...)` wiring.
- `dev/redflag/bpm/impl/SimpleBPMService.java` — `setPostProcessors(...)` per-row dispatch by `lang`.
- `dev/redflag/bpm/dto/CodeDTO.java` — `lang` constants.
- `dev/redflag/core/services/query/AbstractQueryService.java` — `addPostProcessor(...)` and the per-row `postProcess(JsonObject obj)` invocation.
