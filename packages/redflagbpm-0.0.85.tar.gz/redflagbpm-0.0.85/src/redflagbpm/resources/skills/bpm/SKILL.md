---
name: bpm
description: Build and validate artifacts for the RedFlag BPM low-code platform. Use when editing or creating artifacts under a BPM project (queries, forms, scripts, services, agents, agentic prompts, reports, kanban, value providers, pages, endpoints, menus, mail sources, collections, .config files), or when configuring the Coder repos (RepoDTO), Analyst entities (AnalystInfo), or sandbox YAML for either. Includes Python validators for artifact files.
---

# BPM Skill

A skill for **configurators** of the RedFlag BPM platform — people who write artifacts (YAML, scripts, forms, agents) inside BPM projects. Not for internal product development of the bpmapp itself.

The skill is self-contained: the `references/` files document everything you need to write artifacts, and the validators under `scripts/` lint them. The only runtime dependency from the BPM product is the Python SDK `redflagbpm` (installed separately with `pip install redflagbpm`); see `references/sdk-python.md`.

---

## When to use this skill

Trigger on any of these:

- Editing a file under a BPM project (`*.yml`, `*.yaml`, `*.config`, scripts).
- The user mentions: query, form, service, script, post-processor, value provider, kanban, agent, prompt, agentic workflow, RAG, vector store, report, page, endpoint, menu, mail source, collection.
- The user mentions Coder, repo, RepoDTO, opencode config, model field for Coder.
- The user mentions Analyst, AnalystInfo, MCP allowlist, skills/prompts for Analyst.
- The user asks about the `sandbox:` field, Docker config for Coder/Analyst, or wants to change container settings.
- The user wants to validate, lint, or check an artifact file.
- The user references the Python SDK `redflagbpm` or the MCP server.

Do **not** use this skill for: internal Java development of the bpmapp (ACP protocol, JSON-RPC, SandboxRunner internals, AcpChatLauncher). Those live under `doc/ACP_*.md` and are out of scope here.

---

## Quick decision table

| You need to… | Open this reference |
|---|---|
| Understand `.config` files, `lang`, `type`, project/id naming | `references/artifacts-and-config.md` |
| Define a SQL/Collection/REST query, columns, filters, actions | `references/queries.md` |
| Customize cell rendering, post-process query rows | `references/templates.md` |
| Build a dropdown/lookup driven by a query | `references/value-providers.md` |
| Define a Kanban board | `references/kanban.md` |
| Define a form or `inputSchema` | `references/forms.md` |
| Render a custom page (HTML/Velocity/Python/JS) | `references/pages.md` |
| Define a service (request/response, scripts, downloads) | `references/services.md` |
| Generate a PDF/XLSX/HTML report | `references/reports.md` |
| Author a Jasper `.jrxml` (Studio version, Data Adapters, filter properties, JSON sources, resources) | `references/reports-jasper.md` |
| Write a script (form/feedback/action/tool) | `references/scripts-and-tools.md` |
| Expose a REST endpoint | `references/endpoints.md` |
| Configure an LLM agent + RAG | `references/agents-and-rag.md` |
| Build an agentic workflow (sequence/parallel/loop/conditional/supervisor) | `references/prompts-agenticos.md` |
| Define menus and application routes | `references/menus-and-routes.md` |
| Define a Collection or a Mail Source | `references/collections-and-mail.md` |
| Configure a repo for the Coder | `references/coder.md` (+ `sandbox.md`) |
| Configure an Analyst | `references/analyst.md` (+ `sandbox.md`) |
| Customize the Docker sandbox for Coder/Analyst | `references/sandbox.md` |
| Use the `redflagbpm` Python SDK from a script | `references/sdk-python.md` |
| Configure logs from scripts (naming, files, inspection from Coder) | `references/logging.md` |
| Diagnose surprising behaviour, silent failures, or "why doesn't this work" | `references/pitfalls.md` |
| **Debug** an Agent that calls a tool but the tool seems to fail / return empty / time out | `references/scripts-and-tools.md` § 7 + § 9 (`bpm.context.args` vs `bpm.context.get`, `bpm.reply` vs `print`) and `references/pitfalls.md` *Agents*. Run `validate.py` on the tool's `.config` first — the linter catches the most common silent-failure shapes. |
| **Debug** an Agent menu link / route that doesn't open | `references/menus-and-routes.md` (use `Agent?__agent__=PROJECT/ID`, not the path-style form) |
| **Investigate** a real chat (this BPM) — find / read / visually open a session your user had | `references/coder.md` § *Sessions / memory introspection* (`bpm_coder_list_agent_memories`, `read_agent_memory`, `show_chat`, `list_coder_sessions`). For unflushed live sessions, `read_agent_memory` falls back to the opencode SQLite. |
| **Investigate** a chat that lives in **another BPM** (prod / replica) — debug what an agent answered to a real user without moving data | `references/coder.md` § *Acceder a chats de una DB externa* (`bpm_coder_external_list_chats`, `external_read_chat`, `external_show_chat`). Requires a `DataSourceDTO` configured pointing at the target DB; the target must have the canonical `document.document` schema. |

Load only the references the current task needs. Do not pre-load everything.

### `schemas/` — auto-generated structural specs

Para confirmar el shape exacto de un artifact (qué campos, qué tipo, qué
orden canónico) sin leer la referencia entera, hay JSON Schemas
auto-generados de los DTOs Java en `schemas/<type>.schema.json`. Hoy:
`agent.schema.json`. Más a medida que se incorporen.

Reglas:

- La markdown de `references/` tiene los **gotchas, recipes y ejemplos**. Es lo que leés primero.
- El JSON Schema de `schemas/` tiene la **verdad estructural** (re-generada del DTO Java en cada build). Si discrepan, el JSON gana.
- No hay `required` ni enums cerrados todavía — el shape estructural está, las restricciones cruzadas siguen viviendo en `scripts/validators/`. Para enforcement completo, corré `validate.py` (que ya combina ambas capas).

### Navigating the references

The skill is mounted **outside your repo workspace**, so `bpm_grep` and
`bpm_glob` don't see it — those tools only scan the workspace. To explore the
skill:

- **Read a whole reference**: `bpm_read $BPM_SKILL_DIR/references/<file>.md`.
  This is the canonical move when you know which file you need (the table
  above maps tasks → files). `$BPM_SKILL_DIR` is exported in the sandbox
  environment.
- **Search across references**: there is no `bpm_skill_grep`. The fallback is
  `bpm_bash 'grep -rn <pattern> $BPM_SKILL_DIR/references/'` (or `find …`).
  Avoid `cat <file> | grep -A N`: the `-A N` slice is lossy and you'll re-run
  it three times to get enough context. Either grep with a wide enough window
  or just `bpm_read` the whole file.
- **Don't paraphrase from memory**: re-reading a reference is cheaper than
  shipping a wrong field name. The references are the single source of truth.

---

## Identifier conventions

- **Project code**: `SCREAMING_SNAKE_CASE` (`HLW`, `SALES`, `CRM`).
- **Artifact id**: `PROJECT/ARTIFACT_ID` (`HLW/QRY_CLIENTES`, `SALES/AGT_ASSISTANT`).
- **Script reference** (in YAML fields like `requestUrl`, action targets): `run:PROJECT/SCRIPT_ID`.
- **Environment-variable reference** (in YAML, e.g. API keys): `@VAR_NAME` (uppercase).
- **stringFormat placeholders**: `%{fieldName}` for named, `%1$s` for positional.

---

## `.config` files at a glance

Every artifact (except plain `Script`) has a sibling `.config` (YAML). Required fields:

```yaml
project: "HLW"                  # SCREAMING_SNAKE_CASE
id: "HLW/QRY_CLIENTES"          # PROJECT/ARTIFACT_ID
lang: "YAML"                    # see closed list below
type: "Query"                   # see closed list below
properties: null                # type-specific properties (object) or null
```

Extra fields: `description`, `cron` (scheduled execution), `env` (test-time variables).

**Closed sets** (validators enforce these):

- `lang` ∈ {JavaScript, Python, Velocity, JSON, YAML, JUEL, Vertx, Shell, Prompt, Markdown, Binary}.
- `type` ∈ {Agent, Mcp, Analyst, Script, Form, Page, Public endpoint, User endpoint, Web service endpoint, Query, Service, Collection, Report, Menu}.

Coherence (warning, not error) — common pairings: `Query/Service/Form/Collection/Menu/Agent/Mcp/Analyst → YAML|JSON`; `Report → Binary`; `Page → Velocity|Python|JavaScript|Shell|Binary|Markdown`.

See `references/artifacts-and-config.md` for the full spec, examples, and validation details.

---

## Validation

Two complementary validators ship with the skill. They live in this skill's
own `scripts/` directory — **not** in your repo workspace.

The Coder/Analyst sandbox exposes the env var `BPM_SKILL_DIR` pointing at
this skill's root (e.g. `.../opencode-config/skills/bpm`). Use it verbatim
from `bpm_bash` — no need to copy the absolute path each time, and no need to
prefix with `python3` (both validators are executable, with shebang).

```bash
# YAML / .config schema and rules
"$BPM_SKILL_DIR/scripts/validate.py" <path-in-your-repo>
"$BPM_SKILL_DIR/scripts/validate.py" --type query path/to/QRY_CLIENTES.yml
"$BPM_SKILL_DIR/scripts/validate.py" --strict --json path/to/file

# Python syntax check on .py scripts that target CPython (lang: Shell + #!python3)
"$BPM_SKILL_DIR/scripts/validate_python.sh" <path-or-dir>
"$BPM_SKILL_DIR/scripts/validate_python.sh" --strict path/to/repo
```

`OPENCODE_SKILLS_DIR` is the parent (sibling skills root) if you ever need to
reach a different skill. The argument to the validators (`<path>` /
`<path-or-dir>`) is relative to your repo workspace as usual — only the
validator binary needs the absolute skill path, and `$BPM_SKILL_DIR` resolves
that for you.

> Fallback: if for some reason `BPM_SKILL_DIR` is unset, use the absolute
> base directory opencode reports when this skill loads (the
> `Base directory for this skill: …` line). The path looks like
> `.../opencode-config/skills/bpm`. Do **not** use a workspace-relative
> path like `skills/bpm/scripts/validate.py` — the skill is not mounted
> under the workspace.

**When to validate.** Run `validate.py` against a `.config` (or its sibling
artifact body) immediately after every `bpm_write` or `bpm_edit` to a `.config`
file, **before** reporting a task as done. The validator is fast (sub-second)
and catches misplaced fields silently (e.g. `properties.targetGroups` on an
Agent, `inputSchema` instead of `properties.tool.args_schema`, body id ≠
`.config` id). Don't wait for the user to report a regression.

> **Done-checklist.** Before declaring a task complete, run for every artifact
> you touched:
>
> ```bash
> "$BPM_SKILL_DIR/scripts/validate.py" --strict path/to/file
> ```
>
> A green run (no errors, no warnings under `--strict`) is the contract for
> "task is done from the artifact-shape side". This does not replace
> functional testing (smoke-test the artifact in the UI / chat), but it is
> non-negotiable: do **not** mark `todowrite` items as `completed` while the
> validator is red. Per-type recipes embed this step.

`validate.py` covers artifact structure (closed value sets, required fields, schema shape). `validate_python.sh` covers what `py_compile` catches: `SyntaxError`, top-level `return`, shebang typos like `#!pyhton3`. Each file is compiled with the interpreter named by its shebang (so scripts targeting `/app/files/BpmApp/venvs/data-science/bin/python3` are checked under *that* venv when it exists locally; otherwise the validator falls back to system `python3` with an info note). Jython files (`lang: "Python"`) are skipped — their 2.7-ish syntax may legitimately diverge from Python 3. `__pycache__/` directories the run creates are removed at the end.

`--strict` turns warnings into errors. `--json` emits machine-readable output. Without `--type`, `validate.py` auto-detects from the path/extension/content.

Severities:

- **error** — closed set violation or missing required field, or a Python syntax error. Fails the run.
- **warning** — value outside known set but the runtime accepts free strings (e.g. unusual `subtype`, untested `provider`).
- **info** — style suggestion (e.g. icon names, formatting).

YAML validators live under `scripts/validators/` (closed value sets in `validators/enums.py`, the only authoritative copy). See `scripts/README.md` for the full CLI reference and per-validator coverage.

---

## When the references seem off

The references are derived from the bpmapp Java source and are kept in sync by the skill maintainer. If a YAML you write *should* work according to a reference but the runtime rejects it (or vice versa), that is a maintainer-side discrepancy — open an issue against the bpmapp repo so the reference can be updated. End users do not need access to the bpmapp source to use this skill; the references and the validators are the operational surface.

The validators' closed value sets live in `scripts/validators/enums.py` — that file carries `# source:` comments pointing at the Java files for maintainers who *do* have the bpmapp checkout.

---

## Glossary

- **Artifact**: any unit a configurator authors — query, form, script, service, agent, etc. Each lives as a file (YAML/JSON/script) in a project repo, paired with a `.config`.
- **Project**: a logical grouping of artifacts under a single code (`HLW`, `CRM`).
- **Query**: declarative data view (SQL, Collection, JSON/REST). Renders as an interactive table with filters/actions.
- **Post-processor**: row-level script that runs after retrieval (computed columns, validation).
- **Value Provider (VP)**: a query designed to feed dropdowns; returns rows with at least `id` and `caption`.
- **Selection scope**: which row selection a script-action expects (none/single/many/group/filter).
- **Kanban**: alternate visual rendering of a query as a board of columns and cards.
- **Form**: artifact rendered from a JSON Schema; reused as `inputSchema` for services and scripts.
- **Service**: triggerable artifact that runs a request (URL, script) and presents a response (message/asset/query/report).
- **Endpoint**: HTTP route exposed by the platform — Public (anonymous), User (authenticated), Web service (token).
- **Agent**: LLM configuration (provider, model, instructions, RAG).
- **Prompt**: agentic call definition (PromptDTO) that may be a single agent call or compose sub-agents into a workflow.
- **Workflow**: orchestration pattern over sub-agents — `sequence`, `parallel`, `loop`, `conditional`, `supervisor`.
- **AgenticScope**: shared key/value bag passed across sub-agents within a workflow.
- **RAG**: retrieval-augmented generation; `vectorSearchStores` and `fileSearchStores` on AgentInfo enable it.
- **Coder**: in-platform AI agent that edits a configured repo (driven by RepoDTO).
- **Analyst**: end-user-facing AI assistant configured per AnalystInfo, with MCP tool allowlist and skills (pinned prompts).
- **Sandbox**: Docker container subset (compose-like) where Coder/Analyst shell tools execute. See `references/sandbox.md`.
- **MCP**: Model Context Protocol; how the Analyst exposes BPM tools to its LLM.
- **Mail Source**: artifact that polls an inbox and triggers processing per message.
- **Collection**: schemaless document store with CRUD + SQL-over-JSON querying.
