# Sandbox

El field `sandbox:` describe el container hermano donde el agente (Coder en modo `docker`, Analyst siempre) ejecuta sus tools (`bpm_bash`, `bpm_read`, `bpm_write`, `bpm_edit`, `bpm_glob`, `bpm_grep`). Es un subset compose-like del schema de `docker-compose service:`, acotado a un set chico de campos seguros.

Es **subset** porque BPM controla los invariantes de hardening (capabilities, namespaces, entrypoint, /workspace) — exponer todos los campos compose abriría escape vectors triviales (`privileged: true`, `pid: host`, `network_mode: host`, etc.). Los campos peligrosos se rechazan al **parse-time** (al cargar el RepoDTO/AnalystInfo), no a runtime.

Compartido por dos features: `RepoDTO.sandbox` (Coder, ver `references/coder.md`) y `AnalystInfo.sandbox` (Analyst, ver `references/analyst.md`). Implementación en `dev/redflag/bpm/impl/ai/acp/SandboxConfigParser.java` + `DockerSandboxRunner.java`.

---

## Modo: `host` vs `docker`

```yaml
sandbox:
  mode: docker          # o "host"
  image: bpm/analyst-python-ds:1.4
  service:
    ...
```

| Modo | Aplica a | Comportamiento |
|---|---|---|
| `host` | Solo Coder | El agente ejecuta tools directamente en el host del BPM, sin container. El field `image`/`service`/etc. se ignora. Solo apto para repos confiables (developer-mode). |
| `docker` | Coder y Analyst | Default. El runner (`DockerSandboxRunner`) crea un container long-running con `sleep infinity` y enruta cada tool call via `docker exec`. |

Para Analyst, `mode: host` no es válido — Analyst siempre corre en docker (aislamiento obligatorio para multi-tenant chats).

---

## Estructura YAML básica

Dos formas de definir la imagen del container:

**A) Imagen prebuilt (`image:`)** — usar un tag ya pull-eado en el daemon del host.

```yaml
sandbox:
  image: bpm/analyst-python-ds:1.4
  service:
    mem_limit: "512m"
    cpus: "1"
```

**B) Build local (`build:`)** — construir desde un Dockerfile relativo al `baseDir` (parent dir del YAML para Analyst, root del repo para Coder).

```yaml
sandbox:
  build: ./docker/Dockerfile         # ← convención BPM: bajo `docker/`
  service:
    cpus: "2"
```

O long form, idéntico semánticamente a `docker-compose`:

```yaml
sandbox:
  image: my-org/analyst-foo:dev      # tag estable; opcional
  build:
    context: ./docker                # ← convención BPM
    dockerfile: Dockerfile           # relativo al context
    args:
      VERSION: "1.0"
    target: dev-stage                # opcional, multi-stage
  service:
    ...
```

Si la YAML declara `build:` pero no `image:`, el tag se auto-genera como `bpm-acp-build:<hash12>` donde el hash deriva del Dockerfile content + args ordenados + target. Cambiar el Dockerfile cambia el hash → nuevo tag → rebuild.

### Convención del build context

**Estándar BPM**: el contexto de build vive en una subcarpeta `docker/` bajo el `baseDir` (sibling folder del Analyst, root del repo para Coder).

```
analystinfo/sales-reporter/      ← sibling folder del Analyst
├── agents/
├── skills/
├── commands/
├── modes/
└── docker/                      ← ← ← `sandbox.build.context`
    ├── Dockerfile
    └── requirements.txt
```

Por qué: la sibling folder de un Analyst aloja recursos de varios kinds opencode (`agents/`, `skills/`, `commands/`, `modes/`, ...). Consolidar Dockerfiles bajo `docker/` mantiene esa lista navegable, evita confundir build artifacts con recursos opencode, y simplifica el `.dockerignore` (excluye todos los kinds canónicos de un golpe).

**Forma corta** (recomendada para builds simples):

```yaml
sandbox:
  build: ./docker/Dockerfile
```

**Forma larga** (build con `args`, `target` o multi-Dockerfile):

```yaml
sandbox:
  build:
    context: ./docker
    dockerfile: Dockerfile         # ó: prod.Dockerfile, dev.Dockerfile, etc.
    args:
      VERSION: "1.0"
    target: production
```

El validator `validate.py` emite un **WARNING** (`sandbox-build-not-under-docker` / `sandbox-build-context-not-docker`) si `build.context` o el path del `Dockerfile` no caen bajo `docker/`. No rompe el build (el parser Java acepta cualquier path relativo válido), pero queda visible en el lint para code review.

> Excepción legacy aceptable: repos Coder donde el `Dockerfile` ya vive en el root por razones históricas. Para Analysts nuevos, mantener `./docker/`.

### Convención `ARG BPM_BUILD_MARKER`

Tu Dockerfile tiene que declarar `ARG BPM_BUILD_MARKER` cerca del top, antes de los `RUN install/apt` cuyas capas querés invalidar cuando cambia el Dockerfile:

```dockerfile
FROM python:3.12-slim

ARG BPM_BUILD_MARKER

RUN pip install --no-cache-dir pandas tabulate
```

Es una sola línea. El autor **no mantiene** el valor: BPM inyecta automáticamente un hash derivado del contenido del Dockerfile como `--build-arg BPM_BUILD_MARKER=<hash>` al hacer `docker build`.

Por qué hace falta declarar el `ARG`:

- Cambia el Dockerfile (cualquier línea) → el hash que BPM calcula cambia → el ARG cambia → la capa del `ARG` y todas las posteriores se re-ejecutan en el próximo `docker build`. Las dependencias `pip install` se reinstalan, los `apt-get` se actualizan.
- No cambia el Dockerfile → hash igual → ARG igual → cache de Docker reusa todas las capas, build es instantáneo.

Sin esa línea, las capas `RUN install` quedarían cacheadas para siempre por Docker daemon aunque el `image-tag` BPM cambiara — el ARG es lo que las invalida.

### Auto-detect: build implícito por convención

Como bonificación de la convención: si la YAML **no declara ni `image:` ni `build:`** y existe `<baseDir>/docker/Dockerfile` en disco, BPM lo usa automáticamente como build (con `context = <baseDir>/docker`). El log lo registra con `INFO sandbox: auto-detected build via convention (...)`.

Resultado: para un Analyst con sandbox personalizado pero parámetros estándar, alcanza con:

```yaml
sandbox:
  service:
    mem_limit: "1g"
    cpus: "2"
```

más un `docker/Dockerfile` versionado en la sibling folder. Sin tener que escribir `build:` explícito.

Si querés `build.args`, `build.target`, o un Dockerfile con otro nombre (`prod.Dockerfile`, `dev.Dockerfile`), declarás `build:` explícito y la convención implícita se ignora.

Si declarás `image:` (prebuilt), idem — gana lo explícito y el `docker/Dockerfile` que pueda existir queda como artefacto del repo no consumido por el spawn.

### Dockerfile default

Como **último fallback**: si la YAML no declara `image:`, no declara `build:`, y no existe `<baseDir>/docker/Dockerfile` local, BPM usa un Dockerfile default bundled con la plataforma. Sirve para Analysts genéricos sin necesidad de escribir nada de Docker.

**Base image**: `python:3-slim` (Debian glibc, sin pin de minor). Se actualiza automáticamente cuando el equipo de Python publica una nueva minor (3.12 → 3.13 → ...). Cuando llegue Python 4, el tag NO avanza solo — protección contra major bump. Si en algún momento conviene pinear a una minor específica (ej. wheels rotos tras un release), se cambia el resource bundled a `python:3.12-slim` y se redeploya BPM.

Stack incluido (Python 3.12-slim como base):

| Categoría | Paquetes |
|---|---|
| **Sistema (apt)** | `pandoc`, `git`, `curl`, `fonts-dejavu-core`, `fonts-liberation` |
| **Lint / dev tools** | `black`, `ruff`, `mypy`, `ipython` |
| **Data science** | `pandas`, `numpy`, `matplotlib`, `pillow` |
| **Office / docs** | `openpyxl` (.xlsx), `python-docx` (.docx), `python-pptx` (.pptx) |
| **PDF** | `reportlab`, `fpdf2`, `pypdf2` |

Dejás un sandbox minimal:

```yaml
sandbox:
  service:
    mem_limit: "1g"
    cpus: "2"
```

…y al primer spawn, BPM hace `docker build` del default a un tag estable y lo reusa. El log dice `INFO sandbox: usando Dockerfile default bundled (...)`.

**Cuándo no usar el default**: si tu Analyst necesita deps que no están listadas (ej. `scikit-learn`, `duckdb`, `psycopg2`), ahí sí declarás `<baseDir>/docker/Dockerfile` propio (la convención auto-detect) o un `image:` prebuilt.

Precedencia completa, en orden:

```
sandbox.image declarado     → usa image (prebuilt)
sandbox.build declarado     → usa build (Dockerfile explícito)
<baseDir>/docker/Dockerfile → auto-detect convención
ninguna de las anteriores   → Dockerfile default bundled
```

El runner cachea por tag: antes del `docker build`, hace `docker image inspect <tag>`; si existe, skipea el build. El timeout del build es de 10 minutos.

---

## Top-level: campos permitidos

| Campo | Tipo | Descripción |
|---|---|---|
| `mode` | `host` o `docker` | Selector de runner. Solo Coder respeta `host`; Analyst es siempre `docker`. |
| `image` | string (tag) | Imagen Docker prebuilt. Required salvo que se declare `build:`. |
| `build` | string u objeto | Spec de build local (short form: path al Dockerfile; long form: `{context, dockerfile, args, target}`). |
| `service` | objeto | Subset compose-like del field `service:`. Ver tabla siguiente. |

Cualquier otro campo top-level (`ports`, `command`, `entrypoint`, `privileged`, `depends_on`, `devices`, `cgroup_parent`) está prohibido — ver [PROHIBIDO](#prohibido).

---

## `service:` campos permitidos

| Campo | Tipo | Default | Descripción |
|---|---|---|---|
| `mem_limit` | string | sin limit | RAM máxima. Ej. `"512m"`, `"1g"`. |
| `cpus` | string o number | sin limit | CPUs. Ej. `"1"`, `"0.5"`, `2`. |
| `pids_limit` | int | `100` | Máximo de procesos en el container. |
| `read_only` | bool | `true` | Root fs read-only (forza `--read-only`). |
| `user` | string | imagen default | uid:gid del proceso. Ej. `"1000:1000"`. |
| `working_dir` | string | `/workspace` | Working directory de `docker exec`. |
| `tmpfs` | array de strings | `[]` | RAM-backed mounts. Ej. `["/tmp:size=50m"]`. |
| `volumes` | array | `[]` | Bind mounts (solo `type: bind`). |
| `environment` | objeto o array | `{}` | Variables de entorno. |
| `network` | string | `bridge` | Network del container. Ver [Network](#network). |
| `extra_hosts` | array de strings | `[]` | Entries en `/etc/hosts` del container. Ej. `["api.example.com:10.0.0.5"]`. |
| `security_opt` | array de strings | `[]` | Extras encima de `no-new-privileges:true` (forzado). |
| `sysctls` | objeto | `{}` | Sysctls del container. Ej. `{"net.ipv4.ping_group_range": "0 2147483647"}`. |
| `init` | bool | `false` | `--init` (tini como PID 1, manejo de zombies). |
| `shm_size` | string | sin override | Tamaño de `/dev/shm`. Ej. `"64m"`. |
| `cap_add` | array de strings | `[]` | Capabilities adicionales (encima de `--cap-drop ALL` forzado). |
| `cap_drop` | array de strings | `[]` | No-op semántico (BPM ya forza `--cap-drop ALL`). |
| `labels` | objeto o array | `{}` | Labels custom del container. |

Cualquier campo no listado se ignora silenciosamente, salvo los explícitamente prohibidos abajo (rechazo al parse).

---

## PROHIBIDO

El parser rechaza al **load-time** del RepoDTO/AnalystInfo (no en runtime) los siguientes campos. Lanza `ValidationError` con mensaje `service.<field> is not allowed (rejected by BPM)`:

| Campo | Motivo |
|---|---|
| `service.command` | El runner forza el arg `infinity` del entrypoint. Override rompe el modelo plugin-mediated. |
| `service.entrypoint` | El runner forza `--entrypoint sleep`. Override impide que `docker exec` funcione. |
| `service.privileged: true` | Daría capabilities root del host al container = escape efectivo. |
| `service.ports` | Exponer puertos al host. No es necesario (las tools van por `docker exec`, no por red). |
| `service.depends_on` | El BPM gestiona la cardinalidad — no hay otros services que esperar. |
| `service.networks` (plural) | Multi-network no soportado. Usar `network` (singular). |
| `service.pid: host` (o cualquier no-`private`) | PID namespace del host = ver y matar procesos del host. |
| `service.ipc: host` | IPC namespace del host. Solo `private` y `shareable` se aceptan. |
| `service.userns_mode` | Bypass del user namespace = ineficaz `--user`. |
| `service.devices` | Acceso a `/dev/*` del host (block devices, GPU, etc.). |
| `service.cgroup_parent` | Manipular cgroups del host. |
| `service.network: host` | Network namespace del host = stack de red completo del host. |
| `service.network_mode: host` | Idem. Otros valores de `network_mode` se aceptan como alias de `network`. |
| Mount `source` con prefix de la denylist | Ver [Volumes](#volumes). |
| Mount `type` distinto de `bind` | Solo `bind` se acepta. Para `volume`/`tmpfs` usar otros mecanismos. |

Si una customización legítima necesita un campo prohibido, abrir issue — algunos pueden permitirse con un mecanismo controlado (ej. exposición puntual de un device GPU vía system property).

---

## Network

```yaml
sandbox:
  service:
    network: <name>
```

`network_mode` es alias de `network` (mismo efecto, salvo que `network_mode: host` siempre se rechaza explícitamente).

Valores típicos:

| Valor | Efecto |
|---|---|
| `bridge` (default) | Network bridge default de Docker. NAT al host: el container ve LAN del host + internet pública. |
| `none` | Sin red. Solo loopback del container. `bpm_bash curl ...` falla. Útil para tareas puramente CPU/disk-bound. |
| `agent-runtime` | Network custom creada por el admin del host con reglas iptables que dropean RFC1918 (`10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`), loopback (`127.0.0.0/8`) y link-local (`169.254.0.0/16`) — solo internet pública pasa. Ver [receta abajo](#4-sandbox-con-red-restringida-solo-internet-pública). |
| Otro nombre | Se pasa tal cual a `--network`. La network tiene que existir previamente en el daemon del host. |

**Rechazado**: `host` en cualquier variante. Daría acceso al stack de red del host = escape efectivo.

### Bedrock + EC2 IAM role (gotcha)

Si el BPM corre sobre EC2 con un IAM role attacheado (en vez de configurar `BEDROCK_CONFIG` como parámetro — ver `references/coder.md`), el SDK de AWS adentro del sandbox necesita alcanzar el IMDS en `169.254.169.254`. Dos requisitos:

1. **`agent-runtime` lo bloquea**: las reglas iptables drop link-local (`169.254.0.0/16`) por diseño. Bedrock-via-IAM-role solo funciona con `network: bridge` (default) u otra network que no filtre link-local.
2. **Hop limit del IMDS**: la EC2 host debe tener `HttpPutResponseHopLimit=2` en sus instance metadata options. Default `1` deja el host alcanzando IMDS pero los containers no (un hop más). Setear con `aws ec2 modify-instance-metadata-options --http-put-response-hop-limit 2`.

Si ninguno de los dos está, el modelo Bedrock falla con timeout o `Unable to locate credentials`. La alternativa siempre disponible es definir `BEDROCK_CONFIG` (YAML con `accessKeyId`/`secretAccessKey`) — esa ruta no depende de la network ni del hop limit.

### `extra_hosts`

```yaml
service:
  extra_hosts:
    - "crm.empresa.com:203.0.113.10"
    - "internal-api:10.0.5.20"
```

Útil combinado con `network: agent-runtime` para abrir destinos puntuales (DNS estático) sin relajar las reglas iptables.

---

## Volumes

```yaml
sandbox:
  service:
    volumes:
      # Short form: "src:tgt[:mode]"
      - ${bpm.files.dir}/opencode/scratch/${userId}:/data:ro

      # Long form
      - type: bind
        source: ${bpm.files.dir}/opencode/scratch/shared
        target: /shared
        read_only: false

      # Source relativa — solo en Analyst, ver "Source paths relativos" abajo
      - "./resources:/workspace/assets:ro"
```

**Solo `type: bind`** se acepta. Otras formas (`volume`, `tmpfs` como type) lanzan `ValidationError`.

### Source paths relativos (`./...`) — solo Analyst

Un volume cuyo `source` empieza con `./` se resuelve **contra el sibling resource dir del AnalystInfo** (el directorio donde viven `agents/`, `skills/`, `commands/`, etc., con el mismo stem que el archivo YAML). Ejemplo:

```
analystinfo/sales-reporter.yaml          ← AnalystInfo
analystinfo/sales-reporter/              ← sibling resource dir (= baseDir)
  agents/
    chart-builder/
      chart-builder.md
  skills/
    excel-export/
      SKILL.md
  resources/                             ← assets bind-mounteables
    template.docx
    logo.png
  prompts/
    style-guide.md
```

YAML del Analyst:

```yaml
sandbox:
  image: bpm/analyst-python-ds:1.4
  service:
    volumes:
      - "./resources:/workspace/assets:ro"
      - "./prompts:/workspace/refs:ro"
```

Resolución:
- `./resources` → `<absolutepath>/analystinfo/sales-reporter/resources`
- `./prompts` → `<absolutepath>/analystinfo/sales-reporter/prompts`

Reglas:

1. **Solo el prefijo exacto `./`** dispara la expansión. Otras formas (`../foo`, `foo/`, `~/foo`) NO se interpretan; se tratan como literales y caen en denylist/allowlist normal.
2. **No se permite escape**: tras normalizar el path, si la ruta resuelta sale del sibling dir (ej. `./../etc`), el parser rechaza con `relative volume source '...' escapes baseDir`.
3. **Allowlist implícito**: cualquier `source` absoluto (escrito a mano o expandido desde `./`) que cae bajo el sibling dir está permitido sin necesidad de configurar `bpm.acp.mount.allowedPrefixes`. La filosofía: el author del Analyst eligió poner archivos ahí; BPM confía en su propio dir.
4. **`./` requiere baseDir**: si el AnalystInfo no tiene un sibling dir (porque no está cargado desde filesystem o porque el dir no existe), `./` falla con `requires baseDir context`. Para AnalystInfos creados via UI sin sibling dir todavía, no se puede usar `./`.
5. **No aplica al Coder en esta versión** — para el Coder, los assets que necesite el agente vienen del repo clonado (`/workspace/...`); no hay convención `./` separada porque el use-case es marginal. Si necesitás bind-mounts adicionales fuera del repo, usá paths absolutos contra el `bpm.acp.mount.allowedPrefixes`.

**Casos típicos**:

| Para… | Layout |
|---|---|
| Logo + plantillas .docx para reportes | `<sibling>/resources/{logo.png, template.docx}` + `./resources:/workspace/assets:ro` |
| Datasets de referencia | `<sibling>/data/` + `./data:/workspace/data:ro` |
| Prompts firmes en archivo (legales, glosarios) | `<sibling>/refs/` + `./refs:/workspace/refs:ro` |
| Workspace persistente del Analyst (cross-chat) | `<sibling>/workspace/` + `./workspace:/workspace:rw` (sobreescribe el auto-mount default) |

### Allowlist de mount sources

`SandboxConfigParser.validateMountSource` acepta sources con uno de los siguientes prefijos (default, derivados de `bpm.files.dir`):

- `${bpm.files.dir}/opencode/scratch` (en prod `/app/files/opencode/scratch`)
- `${bpm.files.dir}/opencode/repos`
- `/tmp/bpm-`
- `/tmp/acp-`
- `/tmp/launcher-`

Configurable via system property `bpm.acp.mount.allowedPrefixes` (CSV) en el deploy del BPM. Sources con otro prefijo → `mount source not in allowlist: <path>` al parse.

**Nota**: la allowlist se aplica solo a mounts que el USER declara en su YAML. Los mounts auto-inyectados por BPM (workspace bind, etc., ver sección [Forced by BPM](#forced-by-bpm-no-override)) no pasan por esta validación — son trusted.

### Denylist absoluta (no configurable)

Siempre rechazada, sin override posible:

- `/etc`
- `/proc`
- `/sys`
- `/dev`
- `/root`
- `/var/run`
- `/run/docker.sock`
- `/var/lib/docker`

Tienen prioridad sobre la allowlist.

### `/workspace` auto-mount

Si la YAML no declara un mount con `target: /workspace`, BPM **auto-injecta un bind mount** desde un path del filesystem (no anonymous volume):

- **Analyst**: bind source = `${bpm.files.dir}/opencode/workspace/<chatId>` (BPM-view). Per-chat, BPM crea el dir antes del spawn.
- **Coder mode:docker**: bind source = `repoDir.getAbsolutePath()` (path del repo clonado). El agente edita el repo directamente.

**Por qué bind y no anonymous volume**: con bind, BPM accede al workspace via `Files.copy` directo — los uploads del user (📎 / drag&drop al chat), `bpm_create_download_link`, y otros file ops del runner toman fast path sin pasar por `docker cp`. Mucho más rápido para archivos grandes.

**Path translation en prod (DooD)**: si BPM corre adentro de un container, el daemon Docker resuelve los bind sources contra el filesystem **del host**, no del container BPM. `HostPathResolver` (`dev/redflag/bpm/impl/ai/acp/HostPathResolver.java`) hace `docker inspect` sobre el propio container BPM al startup, lee la lista de mounts (named volumes, host binds) y construye un mapping `containerPath → hostPath`. Cuando BPM va a emitir un bind al sandbox sibling, traduce el `bpm.files.dir`-based path al path real del host:

| Compose setup | `bpm.files.dir` (BPM-view) | Bind source (host-view) |
|---|---|---|
| Named volume `bpm-files:/app/files` | `/app/files/opencode/workspace/abc` | `/var/lib/docker/volumes/bpm-files/_data/opencode/workspace/abc` |
| Host bind `/var/lib/bpm/files:/app/files` | `/app/files/opencode/workspace/abc` | `/var/lib/bpm/files/opencode/workspace/abc` |
| Dev local (no container) | `<demo>/data/files/opencode/workspace/abc` | mismo (identity) |

**Cero config requerida en el compose para esto** — `HostPathResolver` lo descubre solo. Funciona con named volumes (sin necesidad de cambiarlos a bind), siempre que `docker.sock` esté montado (que ya lo está para DooD).

Para overridear el auto-mount (ej. workspace persistente cross-sesión, ramdisk, etc.) declarar un `target: /workspace` explícito en `volumes` o `tmpfs` — BPM detecta y respeta:

```yaml
service:
  volumes:
    - type: bind
      source: ${bpm.files.dir}/opencode/scratch/${userId}/persistent-ws
      target: /workspace
      read_only: false
```

O un tmpfs efímero in-RAM para casos donde no querés que el workspace toque disk:

```yaml
service:
  tmpfs:
    - "/workspace:size=512m,uid=1000,gid=1000"
```

---

## Tmpfs

```yaml
sandbox:
  service:
    tmpfs:
      - /tmp:size=50m
      - /home/sandbox:size=20m,uid=1000,gid=1000,mode=0700
```

RAM-backed mounts: el contenido vive en RAM del host, se borra al stop del container. Útil con `read_only: true` para que el container pueda escribir en `/tmp` y similares sin necesidad de volume real.

### Scratch dir auto-injectado

BPM auto-inyecta una tmpfs en `/tmp/scratch` (200MB default, mode 1777, owned por `service.user`) si la YAML no la cubre ya con un mount/tmpfs existente — y exporta las env vars `BPM_SCRATCH_DIR=/tmp/scratch` y `TMPDIR=/tmp/scratch` al sandbox. En modo `host` (solo Coder), el equivalente es `/tmp/bpm-scratch/<bpmInstanceId>/<chatId>/` en el FS del JVM, también exportado vía las mismas env vars. Las file ops del plugin (`bpm_read/write/edit`) aceptan paths bajo el scratch dir además del workspace.

Para qué sirve: el agente tiene un dir writable, ephemero, **fuera del workspace** para drafts de scripts, fixtures, datos intermedios — todo lo que no debe terminar en el repo. Si ya declarás algo con target en `/tmp` o `/tmp/scratch`, BPM respeta tu config y no superpone. Tamaño configurable con `-Dbpm.acp.scratch.tmpfs.size=...` (solo aplica al auto-inject en modo docker).

**Aislación entre instalaciones BPM en el mismo box**: cada instalación tiene un id estable persistido en `${bpm.files.dir}/.bpm-instance-id`. Containers se taggean con la label `bpm-instance-id=<id>` y los scratch dirs viven bajo `/tmp/bpm-scratch/<id>/` — el reaper de boot filtra por ese id, así dos BPMs corriendo en el mismo daemon Docker / mismo host no se barren mutuamente.

---

## Resources

```yaml
sandbox:
  service:
    mem_limit: "512m"     # 256m, 1g, 2g... default sin limit
    cpus: "1"             # 0.5, 1, 2... default sin limit
    pids_limit: 100       # max procesos. default 100
    shm_size: 64m         # /dev/shm size. opcional
    init: true            # tini PID 1. default false
```

Sin `mem_limit`/`cpus`, una sesión malformada del agente puede consumir recursos del host sin tope. Recomendado fijarlos siempre — un valor conservador es `mem_limit: "512m"`, `cpus: "1"`, que permite cómodamente un Python/Node interactivo.

---

## User / identity

```yaml
sandbox:
  service:
    user: "1000:1000"     # opcional — BPM lo auto-injecta si no lo declarás
```

uid:gid del proceso adentro del container. Si la imagen tiene un `USER` declarado en el Dockerfile, ese es el default; `user:` aquí lo overridea.

**Auto-inject de BPM**: si la YAML **no declara** `service.user`, BPM lo setea automáticamente al uid:gid del JVM corriendo BPM (ver `SandboxAutoConfig.ensureSandboxUserMatchesJvm` + `currentJvmUidGid`). Eso garantiza que el sandbox sibling escribe en el bind workspace con la misma ownership que BPM le dio al crear el dir — sin esto, `cap-drop ALL` en el container haría que cualquier mismatch de uid bloquee writes.

Resolución del uid del JVM (en orden):

1. `com.sun.security.auth.module.UnixSystem` (JDK estándar Linux/macOS).
2. Fallback exec `id -u` / `id -g`.
3. Si todo falla → ningún `user:` injectado, el container usa el USER de la imagen (potencial mismatch — declarar `user:` explícito).

**Cuándo declarar `user:` explícito en la YAML**:

- Querés correr el sandbox como un uid distinto al de BPM (raro, casos de hardening multi-tenant).
- La imagen tiene un USER específico que querés respetar (sino BPM lo sobreescribe con el uid del JVM).
- Estás haciendo testing de un setup particular y querés control total.

Para 99% de los casos, **omití el field**. BPM hace lo correcto.

---

## Environment variables

Sintaxis objeto:

```yaml
sandbox:
  service:
    environment:
      MY_VAR: "hello"
      ANALYST_NAME: "${analystId}"      # placeholders ok
      LANG: "es_AR.UTF-8"
```

O sintaxis array (compose alternativo):

```yaml
sandbox:
  service:
    environment:
      - MY_VAR=hello
      - ANALYST_NAME=${analystId}
```

**Importante**: las API keys de los providers (`ANTHROPIC_API_KEY`, etc.) **no se exponen al container**. Esas las usa opencode en el host del BPM. La separación es deliberada — `bpm_bash echo $ANTHROPIC_API_KEY` adentro devuelve vacío. No agregar API keys al `environment` de este field.

---

## Placeholders

En cualquier string del YAML (sources de mounts, env values, extra_hosts, build args, labels), se pueden usar:

| Placeholder | Resuelve a | Disponible en |
|---|---|---|
| `${userId}` | Id del user que abrió el chat. | Coder y Analyst |
| `${chatId}` | Id interno del chat (ej. `analyst-<uuid>`). | Coder y Analyst |
| `${analystId}` | Id del `AnalystInfo`. | Solo Analyst |
| `${repoUrl}` | URL del repo. | Solo Coder (`RepoDTO.sandbox`) |
| `${repoDir}` | Path absoluto local del repo (ya clonado). | Solo Coder |

Ejemplos:

```yaml
volumes:
  - /var/lib/bpm/scratch/${userId}/${analystId}:/data:rw
environment:
  CHAT_ID: ${chatId}
extra_hosts:
  - "${analystId}.internal:127.0.0.1"
```

Si un placeholder no aplica al contexto (ej. `${analystId}` en un sandbox de Coder), resuelve a string vacío.

---

## Forced by BPM (no override)

Encima de lo que diga la YAML, el runner siempre aplica:

```
docker create --rm
  --name bpm-acp-<chatId>
  --cap-drop ALL                              # ← forzado
  --security-opt no-new-privileges:true       # ← forzado
  --label owned-by=bpm-acp
  --label chat-id=<chatId>
  --workdir /workspace                        # (a menos que se override working_dir)
  --entrypoint sleep                          # ← forzado
  ... (todo lo del YAML)
  <image>
  infinity                                    # ← forzado (arg del entrypoint)
```

Plus:

- **Bind mount en `/workspace`** auto-inyectado si la YAML no declara un mount ahí. Source es el path en el FS del host que BPM puede leer/escribir directo (Analyst: per-chat dir bajo `bpm.files.dir`; Coder docker: el repo clonado). Permite `Files.copy` desde el JVM sin pasar por `docker cp`. Path source resuelto via `HostPathResolver` para DooD prod.
- **`service.user` auto-injectado** al uid:gid del JVM si la YAML no lo declara. Garantiza que el sandbox sibling escribe en el workspace con la misma ownership.
- **`--cap-drop ALL`**: aún si la imagen tiene `USER root` y el agente ejecuta cualquier código, no puede chmod files que no le pertenecen, abrir raw sockets, montar fs, etc.
- **`--security-opt no-new-privileges:true`**: previene gain de privs vía setuid binaries.
- **`--rm`**: el container se borra automáticamente al stop. No queda basura en el daemon.
- **Labels `owned-by=bpm-acp` y `chat-id=<chatId>`**: usados por scripts de cleanup del admin.
- **`--entrypoint sleep` + arg `infinity`**: el container queda durmiendo y cada tool call entra via `docker exec`. El `ENTRYPOINT`/`CMD` del Dockerfile se ignora.

`--cap-drop ALL` es el invariante más importante. Es lo que hace que el modelo sea defendible aun frente a un agente comprometido que ejecute código arbitrario en `bpm_bash`.

---

## Ejemplos

### 1. Sandbox simple con imagen prebuilt

Caso típico de Analyst que solo necesita Python + libs estándar — **mínimo viable**:

```yaml
sandbox:
  image: bpm/analyst-python-ds:1.4
  service:
    mem_limit: "512m"
    cpus: "1"
    network: bridge
```

BPM auto-injecta:
- `service.user` = uid:gid del JVM.
- `/workspace` bind desde `${bpm.files.dir}/opencode/workspace/<chatId>` (resuelto al host vía `HostPathResolver`).

Filesystem read-only por default. Si necesitás scratch persistente, override de `/workspace` (ver receta 3).

### 2. Sandbox con build local (Dockerfile)

```yaml
sandbox:
  build: ./Dockerfile
  service:
    mem_limit: "1g"
    cpus: "2"
    user: "1000:1000"
```

`Dockerfile` (en el mismo dir que el YAML del Analyst):

```dockerfile
FROM bpm/analyst-python-ds:1.4
USER root
RUN pip install --no-cache-dir scipy duckdb sqlalchemy
USER 1000:1000
```

### 3. Sandbox con scratch persistente cross-sesión

Workspace que sobrevive entre chats del mismo user:

```yaml
sandbox:
  image: bpm/analyst-python-ds:1.4
  service:
    user: "1000:1000"
    volumes:
      # Sobreescribe el anonymous volume default.
      - type: bind
        source: /var/lib/bpm/scratch/${userId}/persistent-ws
        target: /workspace
        read_only: false
```

Setup en el host (admin):

```bash
sudo mkdir -p /var/lib/bpm/scratch/<userId>/persistent-ws
sudo chown 1000:1000 /var/lib/bpm/scratch/<userId>/persistent-ws
```

### 4. Sandbox con red restringida (solo internet pública)

```yaml
sandbox:
  image: bpm/analyst-python-ds:1.4
  service:
    network: agent-runtime
    extra_hosts:
      - "internal-mirror.empresa.com:203.0.113.10"   # whitelist puntual
    mem_limit: "512m"
    cpus: "1"
```

Setup previo de la network (admin del host, una sola vez):

```bash
docker network create --driver bridge agent-runtime
SUBNET=$(docker network inspect -f '{{range .IPAM.Config}}{{.Subnet}}{{end}}' agent-runtime)
sudo iptables -I DOCKER-USER -s $SUBNET -d 10.0.0.0/8     -j DROP
sudo iptables -I DOCKER-USER -s $SUBNET -d 172.16.0.0/12  -j DROP
sudo iptables -I DOCKER-USER -s $SUBNET -d 192.168.0.0/16 -j DROP
sudo iptables -I DOCKER-USER -s $SUBNET -d 169.254.0.0/16 -j DROP
sudo iptables -I DOCKER-USER -s $SUBNET -d 127.0.0.0/8    -j DROP
```

### 5. Build multi-stage (target dev/prod)

`Dockerfile`:

```dockerfile
FROM bpm/analyst-python-ds:1.4 AS base
USER 1000:1000

FROM base AS dev
USER root
RUN pip install --no-cache-dir ipdb pytest jupyter
USER 1000:1000

FROM base AS prod
COPY scripts/ /opt/scripts/
```

`analyst-foo.yaml`:

```yaml
sandbox:
  image: my-org/analyst-foo:dev      # tag estable, controlado
  build:
    context: .
    target: dev                       # cambiá a "prod" para producción
    args:
      EXTRA_LIBS: "scipy duckdb"
  service:
    mem_limit: "1g"
    cpus: "2"
```

---

## Common gotchas

- **`service.privileged: true` rechazado**: es exactamente lo esperado. No hay override. Si necesitás capabilities específicas (ej. `NET_RAW` para hacer ping), usá `cap_add: [NET_RAW]` — `--cap-drop ALL` se aplica primero, después se re-agregan las del `cap_add`.
- **`network_mode: host` bloqueado**: también esperado. Si necesitás ver servicios del host desde el container, usar `extra_hosts:` con la IP del host (`host.docker.internal` en Docker Desktop, o la IP del `docker0` bridge en Linux).
- **Mount paths deben ser absolutos y dentro de la allowlist**: `source: ./mi-data` o `source: ~/data` no funcionan. Usar paths absolutos (`/var/lib/bpm/scratch/...`) y verificar que el prefix esté en `bpm.acp.mount.allowedPrefixes`.
- **El container arranca y se muere inmediato**: lo más típico es que la imagen no tenga `sleep` en `PATH`. Las imágenes derivadas de `busybox` minimal o `scratch` no lo tienen. Usar una base con coreutils (Debian/Alpine standard).
- **`bpm_bash` falla con `exec sh: file not found`**: la imagen tiene que tener `sh` en `PATH`. Si solo tenés `bash`, agregar `RUN ln -s /bin/bash /bin/sh` al Dockerfile.
- **`docker exec: permission denied` al escribir en `/workspace`**: si declaraste `user:` explícito en la YAML y NO matchea al uid del JVM (que es el que crea el bind dir), el container no puede escribir. Solución: omitir `service.user` (BPM lo auto-injecta correctamente) o asegurarte que el `user:` coincida. En prod el JVM corre como uid 1000; en dev coincide con tu user local.
- **Bind workspace que no se ve adentro del sandbox** (en DooD prod): BPM usa `HostPathResolver.toHostPath(...)` para traducir paths. Si el resolver no detecta el container ID o `docker inspect` falla, queda en identity y el daemon no encuentra el path. Diagnóstico: `grep HostPathResolver demo/logs/bpm.core.log` en startup. Override manual via `-Dbpm.acp.container.id=<id>` si la auto-detección falla.
- **`build.dockerfile not found`**: el path se resuelve relativo al `baseDir` (dir del YAML para Analyst, root del repo para Coder). Si el Analyst se cargó programmatically sin path local en el FS, el parser lanza `sandbox.build requires baseDir...`. Solución: dar `image:` prebuilt en lugar de `build:`.
- **Build muy lento la primera vez**: el build se hace en el daemon del host, no en BPM. La cache de Docker es per-host. Para `RUN apt install`, considerar `RUN --mount=type=cache,target=/var/cache/apt apt install -y ...` (requiere buildkit, enabled by default en Docker 23+).
- **El agente no ve un env var que pasaste**: verificar que no sea una API key — esas se filtran intencionalmente. Si es var custom y no aparece, revisar que el `environment:` esté dentro de `service:`, no top-level del `sandbox:`.

---

## Validation summary

`validators/sandbox.py` chequea (matching el comportamiento de `SandboxConfigParser`):

1. **Falta `image`, `build` y `docker/Dockerfile`**: ya no es error — BPM cae al Dockerfile default bundled (ver § "Dockerfile default"). El validator emite un INFO `sandbox-using-default-image` para que el autor sepa qué imagen va a correr.
2. **Campo prohibido en `service:`**: el parser chequea contra `SANDBOX_SERVICE_FORBIDDEN` (ver `enums.py`). Mensaje: `service.<field> is not allowed (rejected by BPM)`.
3. **`privileged: true` explícito**: chequeo separado. Mensaje: `service.privileged: true is denied`.
4. **`pid` distinto de `private`**: mensaje `service.pid: <val> is denied (must be private)`.
5. **`ipc` distinto de `private` o `shareable`**: mensaje `service.ipc: <val> is denied`.
6. **`userns_mode` presente**: cualquier valor. Mensaje `service.userns_mode is denied`.
7. **`network: host` o `network_mode: host`**: mensaje `network: host is denied` / `service.network_mode: host is denied (BPM controls network)`.
8. **`network` distinto de los conocidos** (`bridge`, `none`, `agent-runtime`): warning (puede ser una network custom del admin).
9. **Mount source en denylist**: mensaje `mount source denied (<prefix>): <path>`.
10. **Mount source absoluto fuera de allowlist** (default `${bpm.files.dir}/opencode/scratch`, `${bpm.files.dir}/opencode/repos`, `/tmp/bpm-`, `/tmp/acp-`, `/tmp/launcher-`): mensaje `mount source not in allowlist: <path>`. La allowlist se aplica solo a mounts del USER YAML — los auto-injected (workspace bind) no la usan.
11. **Mount `type` distinto de `bind`**: mensaje `volume type not supported: <type> (only 'bind' for v1)`.
12. **Volume short form malformado**: mensaje `volume short form requires src:tgt[:mode]: <entry>`.
13. **`build:` sin `baseDir`** o paths de build inexistentes (cross-file mode).
14. **Placeholder no reconocido** (no en `SANDBOX_PLACEHOLDERS`): warning.

Los placeholders válidos (`${userId}`, `${chatId}`, `${analystId}`, `${repoUrl}`, `${repoDir}`) no causan validación de aplicabilidad: si no aplican al contexto resuelven a string vacío en runtime.

---

## Cross-refs

- `references/coder.md` — `RepoDTO.sandbox` y modos `host`/`docker` para repos.
- `references/analyst.md` — `AnalystInfo.sandbox` y el ciclo de vida del container per chat de Analyst.
