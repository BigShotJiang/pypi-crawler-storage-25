# Jasper Reports — Authoring Guide

Practical guide for designing `.jrxml` reports in Jaspersoft Studio so they run correctly inside BPM. Covers everything that is **specific to BPM**: which Studio version to use, how to bind a report to a configured BPM database, how parameters become runtime filters, how to feed a report from JSON, and how to bundle auxiliary resources.

> Read `references/reports.md` first for the artifact-level shape (the `.config`, `lang: "Binary"`, `type: "Report"`, `renderReport(...)` API). This file picks up where that one stops — at the contents of the `.jrxml`.

---

## 1. Supported JasperReports version

BPM bundles **JasperReports Library 6.21.4**. Use **Jaspersoft Studio 6.21.x** to design reports — the closest compatible Studio build is **6.21.0 (or 6.21.3) "final"**, downloadable from the official Jaspersoft community site.

Why this matters:

- `.jrxml` files saved by a newer Studio (7.x, 8.x, JR Cloud) may use schema features or expression APIs that the 6.21.4 runtime cannot compile. Symptom: the report registers fine but fails at fill time with `JRException: cannot resolve symbol …` or unknown XML attributes.
- Older Studio releases (≤ 6.18) are also fine for the basics, but lack some of the parameter-property tooling (Input Controls editor) that point 4 below relies on.
- The first `<!-- Created with Jaspersoft Studio version X.Y.Z … -->` comment at the top of a `.jrxml` is the easiest way to spot the Studio version another developer used.

Rule of thumb: if your team standardises on **Studio 6.21.0**, every author on the project produces `.jrxml` files that the BPM runtime can fill without surprises.

---

## 2. Binding a report to a BPM database (Data Adapters)

In BPM, every database registered under **Configuración → Bases de datos** is exposed by its `name`. The same `name` is what Jasper reports look up at fill time.

### 2.1 Why use a Data Adapter at all

Reports authored against an embedded JDBC URL ("Database JDBC Connection" in Studio) carry credentials inside the `.jrxml`, only run on the developer's machine, and break the moment the Postgres host changes. The BPM way is:

1. Configure the database **once** in BPM (`Configuración → Bases de datos`), giving it a clear `name` (e.g. `NORTHWIND`, `ERP_PROD`, `WAREHOUSE`).
2. In Jaspersoft Studio, create a **Data Adapter** with the **exact same `Name`** (case-sensitive). The connection details inside Studio are only used at design time — the runtime ignores them and uses the BPM-managed pool.
3. Save the report so the adapter name lands in the `.jrxml` as a property.

### 2.2 Creating the Data Adapter in Studio

1. Open **Window → Show View → Repository Explorer**.
2. Right-click **Data Adapters → Create Data Adapter**.
3. Pick **Database JDBC Connection** (or any other type — JR will only use it locally).
4. Set **Name** to the BPM database name verbatim.
5. Fill in JDBC URL/credentials so you can preview the report locally.
6. Save.

Then, with the report open in the editor:

1. Open the **Outline** view.
2. Click the root `<jasperReport>` node.
3. In **Properties → Data Source**, pick the Data Adapter you just created. Studio writes:

   ```xml
   <property name="com.jaspersoft.studio.data.defaultdataadapter" value="NORTHWIND"/>
   ```

That single property is what BPM reads. If you skip the Data Adapter step and rely on Studio's JDBC URL, the report will fail at runtime because the property is missing.

### 2.3 What happens at runtime

When the report runs and the query language is SQL (or `contentType: "SQL"` is forced from Python):

- BPM reads `com.jaspersoft.studio.data.defaultdataadapter`.
- It looks up a registered connection runner with that exact name.
- If found, BPM borrows a connection from the pool, fills the report, and returns it to the pool.
- If the name does not match any registered BPM database, the report fails with `Undefined connection provider for report …`.

### 2.4 Common pitfalls

- **Trailing whitespace / wrong case** in the adapter name. `NORTHWIND ` ≠ `NORTHWIND`.
- **No Data Adapter selected** — Studio falls back to a "default" connection that the runtime cannot recreate.
- **Renaming the BPM database** without updating every report that references it. There is no rename hook; do a project-wide search for the old `value="OLD_NAME"` string.
- **Subreports with their own adapter property**. Each sub-report needs the same property; they are not inherited from the master.

---

## 3. Parameterised SQL query strings

Because the connection is provided by BPM, you write the query in Studio exactly the way Jasper expects it. There is **no BPM-specific templating**: every parameter substitution uses the standard JR syntax.

| Syntax | Behaviour | Use it for |
|---|---|---|
| `$P{name}` | Bound as a `PreparedStatement` parameter (safe). | Single scalar values: `where customer_id = $P{customer_id}`. |
| `$P!{name}` | Raw substitution into the SQL text. **No SQL-injection protection.** | Identifiers and SQL fragments: `order by $P!{sortColumn}`. Validate the value before calling. |
| `$X{IN, field, paramList}` | Built-in conditional clause; emits nothing when the parameter is null/empty. | Multi-value filters: `$X{IN, country, $P{countries}}`. Also `NOTIN`, `EQUAL`, `BETWEEN`, `LESS`, `GREATER`. |

### 3.1 Defensive optional filters

For optional single-value filters, the canonical pattern in this codebase is:

```sql
where $P{cliente} is null
   or contact_name like '%' || $P{cliente} || '%'
   or company_name like '%' || $P{cliente} || '%'
```

When the user leaves the field blank, the caller passes `None`/`null`, the first branch short-circuits and the filter disappears. This is preferred over building two separate queries, because Jasper compiles the SQL once.

### 3.2 Type coercion

The runtime tries to coerce inbound parameters to the declared `class` of each `<parameter>`:

- `Long` (epoch millis) → `java.sql.Date`, `java.sql.Time`, `java.sql.Timestamp`, `java.util.Date`.
- `String` → `BigDecimal`, `BigInteger`.
- Any `Number` → `Integer`, `Double`, `Float`, `BigDecimal`.

So Python callers can ship dates as epoch milliseconds (`int`) and let BPM widen them to `java.sql.Date`. If the declared class is `String` and you pass an `int`, you'll get a `ClassCastException` — stringify in the caller.

### 3.3 Built-in parameters that always work

These are populated by BPM before the fill — you can reference them in expressions or SQL without declaring them:

| Parameter | Value |
|---|---|
| `REPORT_DIR` | Absolute path to the staging folder for this report (where resources have been copied). Trailing separator included. |
| `SUBREPORT_DIR` | Same value as `REPORT_DIR`; the canonical name for `<subreport>` directory expressions. |

Use `$P{SUBREPORT_DIR} + "sub_detail.jasper"` as the subreport expression.

---

## 4. Turning parameters into runtime filters

When a user opens a report from the BPM Reports view, BPM auto-builds a filter form from the `.jrxml` parameters. The mapping has rules — get them right and the form looks polished without any extra `.config`.

### 4.1 Which parameters become filters

A `<parameter>` is exposed as a filter **only when both** of the following hold:

1. `isForPrompting="true"` (this is the Studio default; double-check it has not been turned off).
2. `<parameterDescription>` is non-empty.

Parameters used internally (e.g. `REPORT_DIR`, helper computed values) should have `isForPrompting="false"` so they do not pollute the filter form.

### 4.2 What the filter form picks up automatically

For each prompting parameter, BPM derives:

- **Caption** ← `<parameterDescription>`. Shown as the field label.
- **Field type** ← Java `class` of the parameter:
  - `java.lang.String` / `java.lang.Character` → text input.
  - `java.lang.Boolean` → checkbox.
  - `java.lang.Integer` / `Long` / `Short` / `Byte` / `BigInteger` → integer input.
  - `java.lang.Double` / `Float` / `BigDecimal` → number input.
  - `java.sql.Date` / `java.util.Date` → date picker.
  - `java.sql.Time` → time picker.
  - `java.sql.Timestamp` → datetime picker.
- **Default value** ← `<defaultValueExpression>` evaluated server-side at form build time (good for `new java.util.Date()` defaults, current user, etc.).

### 4.3 Tuning a filter via parameter properties

Inside Studio, select the parameter and use the **Properties** view → **Properties** tab to add custom properties. BPM reads the following keys (each one is **optional**, and accepts both the short form and the fully-qualified `dev.redflag.core.services.info.FilterInfo.<name>` form):

| Property | Effect |
|---|---|
| `required` | `true` makes the field mandatory in the form. |
| `format` | Display format — `stringFormat` semantics, used for date/number formatting on the form (`yyyy-MM-dd`, `#,##0.00`). |
| `expression` | Server-evaluated expression used to derive the value when the user does not type one. |
| `dependents` | Comma-separated list of other filter names that should be re-evaluated whenever this field changes (cascading dropdowns: pick *country* → reload *city*). |
| `valueProvider` | Name of a Value Provider (see `references/value-providers.md`) that supplies the dropdown options. Use this to back a parameter with a SQL/Collection/REST query. |
| `possibleValues` | Static dropdown values: a JSON array (`["A","B","C"]`) or a comma-separated list. Renders the field as an enum. |

### 4.4 Power user: full FilterInfo as YAML

If the simple key/value properties cannot express what you need, attach a single property `com.jaspersoft.studio.js.ic.value` (this is the same key the Studio "Input Control" editor uses) whose value is a YAML-encoded `FilterInfo`:

```yaml
caption: "Country"
fieldType: "java.lang.String"
required: true
valueProvider: "QRY_COUNTRIES@HLW/CLIENTES"
dependents:
  - "city"
possibleValues:
  - "AR"
  - "BR"
  - "UY"
```

This blob takes precedence over the individual properties and lets you set every field of `FilterInfo` at once.

### 4.5 Override the entire filter form from `.config`

If the parameter-by-parameter approach does not fit your form (e.g. you want subgroups, headers, ordered field disposition), override at report level by setting `properties.filterGroupInfo` in the `.config`. When present, BPM uses it verbatim and does **not** scan the `.jrxml` parameters for filters:

```yaml
project: "HLW"
id: "HLW/Clientes"
lang: "Binary"
type: "Report"
properties:
  filterGroupInfo:
    name: "HLW/Clientes"
    caption: "Listado de clientes"
    callToAction: "Generar"
    formDisposition: "country:6, city:6, fromDate:6, toDate:6"
    filters:
      - { name: "country",  caption: "País",        fieldType: "java.lang.String", valueProvider: "QRY_COUNTRIES" }
      - { name: "city",     caption: "Ciudad",      fieldType: "java.lang.String", valueProvider: "QRY_CITIES",    dependents: ["country"] }
      - { name: "fromDate", caption: "Desde",       fieldType: "java.sql.Date",    required: true }
      - { name: "toDate",   caption: "Hasta",       fieldType: "java.sql.Date",    required: true }
```

`formDisposition` controls field order and column span (`name:span` pairs separated by `,` or `;`, total = 12 columns).

### 4.6 Default filter values

There are two ways to seed defaults:

- `<defaultValueExpression>` on the parameter — evaluated by Jasper at form build time. Good for `new java.util.Date()` or environment-derived values.
- `defaultFilter` map inside a `.config`-level `filterGroupInfo` — a plain JSON object with the field names as keys. Wins when both are set.

---

## 5. Reports fed from JSON (no SQL)

Jasper can iterate over a JSON document instead of a SQL ResultSet. Useful when the data is produced by a script, fetched from a REST API, or pre-computed and stored as a Collection.

### 5.1 In the `.jrxml`: declare a JSON query

```xml
<queryString language="json">
  <![CDATA[customers]]>
</queryString>

<field name="name"  class="java.lang.String"><fieldDescription><![CDATA[name]]></fieldDescription></field>
<field name="email" class="java.lang.String"><fieldDescription><![CDATA[email]]></fieldDescription></field>
<field name="total" class="java.math.BigDecimal"><fieldDescription><![CDATA[total]]></fieldDescription></field>
```

Notes:

- `language="json"` is what tells Jasper to use the JSON query executer (no Data Adapter needed).
- The query body is a **JSON path** that points at the array to iterate. `customers` walks `root.customers[]`. Use `customers.active` for nested objects, `*` for "all top-level array elements".
- Each `<field>` uses `<fieldDescription>` as the JSON property name to extract, **not** the `name` attribute. They can match for convenience but do not have to.

### 5.2 In the caller: pick the right `contentType`

| `contentType` | What `content` should hold |
|---|---|
| `JSON_STRING` | The JSON document inline (a string). Best for small payloads computed by the script. |
| `JSON_RESOURCE` | A BPM resource path (`PROJECT/path/to/file.json`). Best when the JSON is itself an artifact. |
| `JSON_URL` | An `http(s)://` URL the runtime fetches and parses. |

```python
import json, redflagbpm

bpm = redflagbpm.BPMService()
content = json.dumps({
    "customers": [
        {"name": "Alice", "email": "a@x.com", "total": 1500.00},
        {"name": "Bob",   "email": "b@x.com", "total": 2300.50},
    ]
})

bpm.reportService.renderReport(
    options={"format": "PDF", "options": {"resource": "/tmp/customers.pdf"}},
    reportData={
        "reportName": "HLW/CUSTOMER_LIST",
        "parameters": {"title": "Customer Report"},
        "content": content,
        "contentType": "JSON_STRING",
    }
)
```

### 5.3 Formatting hints (optional caller parameters)

When `contentType` is any `JSON_*`, BPM forwards these caller-provided parameters straight to JR's JSON query executer. Pass them through `parameters` in the call:

| Parameter key | Default | Purpose |
|---|---|---|
| `JSON_DATE_PATTERN` | `yyyy-MM-dd` | How JR parses date fields out of strings. |
| `JSON_NUMBER_PATTERN` | `#,##0.##` | How JR parses numeric fields. |
| `JSON_LOCALE` | `en-US` | Locale tag for parsing. |

```python
"parameters": {
    "JSON_DATE_PATTERN": "dd/MM/yyyy",
    "JSON_NUMBER_PATTERN": "#,##0.00",
    "JSON_LOCALE": "es-AR",
    "title": "..."
}
```

### 5.4 SQL vs JSON — when to pick which

- **SQL**: data lives in a database BPM already knows about. Best for transactional listings, statements, anything where reproducibility matters and you want the report self-contained.
- **JSON**: data comes from a non-database source (REST, computation, file), or you want to compose the data in a script first (filter, denormalise, sort) and pass a clean payload to the report.

You can also mix them: a SQL-backed master with a JSON-backed subreport that receives a parameter pointing at the in-memory document.

---

## 6. Bundling auxiliary resources via `.config`

Reports rarely live alone — they ship with logos, footer images, subreport `.jrxml` files, CSS for HTML output, sometimes a font extension JAR. Tell BPM about each of them with `properties.resources` in the report `.config`:

```yaml
project: "HLW"
id: "HLW/Clientes"
lang: "Binary"
type: "Report"
properties:
  targetGroups: ["ADMIN", "USER"]
  resources:
    - "cherry.jpg"                # bare filename → same folder as the .jrxml
    - "./header.png"              # explicit "current folder"
    - "../shared/footer.png"      # parent folder
    - "HLW/assets/logo.svg"       # full project path
    - "sub_detail.jrxml"          # subreport — auto-compiled to .jasper
    - "fonts.jar"                 # font extension — auto-extracted
```

### 6.1 How resource paths resolve

Each entry is interpreted against the **report's folder**:

| Pattern | Resolves to |
|---|---|
| `foo.png` (no slash) | `<report_folder>/foo.png`. |
| `./foo.png` | `<report_folder>/foo.png`. |
| `../foo.png` | `<report_folder>/../foo.png` (one level up). |
| `PROJECT/path/foo.png` (contains `/`) | Absolute project path; fetched from BPM storage as-is. |

Files are copied next to the `.jrxml` at registration time, so any expression in the report that uses a **bare filename** ("just the basename") will resolve.

### 6.2 Special handling

- **`.jrxml` resources** are pre-compiled to `.jasper` automatically. Drop the source files in `resources` and reference them as `"sub_detail.jasper"` in subreport expressions — no separate compile step.
- **`.jar` and `.zip` resources** are **extracted** into the report folder. This is how to ship font extensions or a small bundle of images. The zip must not contain `..` paths (zip-slip is rejected).

### 6.3 Referencing resources from the `.jrxml`

Always reference by **bare filename** so Jasper resolves against `REPORT_DIR`:

```xml
<image>
  <reportElement x="456" y="0" width="99" height="132"/>
  <imageExpression><![CDATA["cherry.jpg"]]></imageExpression>
</image>

<subreport>
  <subreportExpression><![CDATA["sub_detail.jasper"]]></subreportExpression>
</subreport>
```

Avoid absolute paths and `${WORKSPACE}/...` Studio variables — they only resolve on the developer machine, not at runtime.

### 6.4 Folder organisation

A typical project layout:

```
repos/HLW/
└── reports/
    ├── Clientes.jrxml
    ├── Clientes.jrxml.config
    ├── cherry.jpg                # resource, listed in .config
    ├── sub_detail.jrxml          # subreport, listed in .config
    └── fonts.jar                 # font bundle, listed in .config
```

Or, when a logo is shared across many reports, keep it in a dedicated `assets/` folder inside the project and reference it with a project-absolute path:

```yaml
properties:
  resources:
    - "HLW/assets/corporate-logo.png"
```

The runtime stages it next to each report that lists it, so the `.jrxml` still uses the bare filename `"corporate-logo.png"`.

---

## Validation checklist (Jasper-specific)

Before publishing a `.jrxml` artifact:

- Studio version stamped in the `<!--` comment is **6.21.x**.
- A Data Adapter exists in Studio with the **exact** BPM database name and the report has `com.jaspersoft.studio.data.defaultdataadapter` set to it.
- Every prompting parameter has a `<parameterDescription>` so it shows up in the filter form.
- Optional SQL filters are written `where $P{x} is null or …`, not as two separate queries.
- For JSON-backed reports, `<queryString language="json">` is present and every `<field>` declares the JSON path via `<fieldDescription>`.
- Every image / subreport / asset referenced from the template is listed in `properties.resources`.
- Subreport expressions use bare filenames (or `$P{SUBREPORT_DIR} + "..."`), never absolute paths.
- Smoke test in **each** advertised output format (PDF, XLSX, HTML) — Jasper layouts that look great as PDF often need `properties.excelOptimized: true` to be readable in Excel.
