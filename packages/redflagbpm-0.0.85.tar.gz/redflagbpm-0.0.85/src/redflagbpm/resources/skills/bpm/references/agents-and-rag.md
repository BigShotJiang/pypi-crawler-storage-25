# Agents and RAG

> Reference for configuring `Agent` artifacts in BPM: LLM-backed assistants with provider/model selection, system instructions, function tools, RAG knowledge bases, vector stores, memory and MCP servers.

Agents are first-class artifacts (`type: Agent`) defined as YAML. They wire together a provider/model, a system prompt (`instructions`), optional tools (Scripts marked as tools), retrieval sources (RAG, vector stores, file search, MCP), and runtime properties. Use them whenever a feature needs natural-language reasoning, conversational memory, or knowledge-base lookup — not for deterministic scripted logic, which belongs in a Script.

---

## Recipe — create an Agent from scratch

In order. Don't skip the validator.

1. **Decide the id**: `PROJECT/AGENT_ID`.
2. **Author the body** `path/to/AGENT_FOO.yaml` (see § 1 YAML structure). Set `name`, `provider`, `model`, `instructions`, `active: true`. Add `targetGroups` for ACL. Omit `id:` from the body — the runtime takes it from the `.config` (see § 2 callout).
3. **Create the `.config`**:
   ```yaml
   project: "MYPROJ"
   id: "MYPROJ/AGENT_FOO"
   lang: "YAML"
   type: "Agent"
   description: "…"
   properties: null
   ```
4. **Wire tools**: each tool id in `tools:` must reference a Script with `properties.tool` declared (see `references/scripts-and-tools.md` § 7 + the "Adding a tool" recipe).
5. **Wire RAG / memory** (optional): `ragResources`, `mdResources`, `memoryEnabled` + `chatStore`.
6. **Validate**:
   ```bash
   "$BPM_SKILL_DIR/scripts/validate.py" --strict path/to/AGENT_FOO.yaml.config
   ```
7. **Smoke-test** by chatting with the agent at `Agent?__agent__=MYPROJ/AGENT_FOO`. Verify it can reach each tool and respond.

---

## 1. YAML structure

The recommended field order follows `@JsonPropertyOrder` in `AgentInfo`. All non-listed fields go inside `properties`.

```yaml
name: "Documentation Assistant"            # display name
# `id` is no longer needed in the body — the runtime takes the agent id from
# the .config sidecar. Setting it here is harmless but ignored; if it diverges
# from the .config id the loader logs a warning. New agents should omit it.
active: true                               # enable / disable
provider: "OpenAI"                         # OpenAI | Gemini | Bedrock | Anthropic ...
model: "gpt-4o-mini"                       # provider-specific model id
instructions: |                            # system prompt
  You are a helpful assistant for the Acme product line.
  Always answer in Spanish unless asked otherwise.
bootScript: "PROJECT/AGENT_BOOT"           # optional script run at agent start
tools:                                     # script ids exposed as function tools
  - "PROJECT/SEARCH_CUSTOMER"
  - "PROJECT/CREATE_TICKET"
streaming: true                            # stream tokens to the client
memoryEnabled: true                        # persist chat memory per user
mdResources:                               # tool-based markdown KB
  - "faq.md"
ragResources:                              # auto-augmented RAG (pgvector)
  - "PROJECT/MANUAL_PDF"
  - "guide.md"
fileSearchStores:                          # Gemini File Search store ids
  - "fileSearchStores/store-abc"
vectorSearchStores:                        # OpenAI vector store ids
  - "vs_abc123"
mcpServers:                                # MCP servers (map keyed by alias)
  jiraServer:
    name: "Jira MCP"
    # ... MCPClientInfo fields
chatStore: "PROJECT/CHAT_STORE"            # persistence store id
targetUsers: []                            # empty = all users
targetGroups:
  - "ADMIN"
alias: "DocBot"                            # short alias
properties:                                # free-form JsonObject (provider, RAG, model params)
  apiKey: "@OPENAI_API_KEY"
  temperature: 0.4
  maxTokens: 2000
  embeddingModelProvider: "OpenAI"
  embeddingModelName: "text-embedding-3-large"
  ragMaxResults: 10
  ragMinScore: 0.3
```

---

## 2. Top-level fields (`AgentInfo`)

These are the fields parsed directly from YAML into `AgentInfo`. Anything else lives inside `properties`.

| Field | Type | Default | Purpose |
|---|---|---|---|
| `id` | String | — | **Ignored at runtime.** The agent's authoritative id is the `.config` `id`. Kept in the table for backwards-compat YAMLs; if you set it and it diverges from the `.config`, the loader logs a warning. New agents should omit it. |
| `name` | String | — | Display name shown to users. |
| `alias` | String | null | Optional short alias (used by some UIs / Telegram). |
| `active` | boolean | false | Enables/disables the agent at runtime. |
| `provider` | String | — | Provider name. **Free string** — see policy below. |
| `model` | String | — | Provider-specific model id (e.g. `gpt-4o-mini`, `gemini-2.5-flash`). |
| `instructions` | String | — | System prompt (multiline `|` recommended). |
| `bootScript` | String | null | Script id executed when the agent boots a session. |
| `tools` | List&lt;String&gt; | [] | Script ids exposed as function/tool calls (see `references/scripts-and-tools.md`). |
| `streaming` | boolean | false | Stream tokens to the client. |
| `memoryEnabled` | boolean | false | Keep chat history across turns. |
| `chatStore` | String | null | Identifier of the persistence store for chat history. |
| `ragResources` | List&lt;String&gt; | [] | Files auto-chunked + embedded into pgvector and **always** used to augment prompts. |
| `mdResources` | List&lt;String&gt; | [] | Markdown files exposed as a tool (`loadContext`) — agent fetches sections on demand. |
| `fileSearchStores` | List&lt;String&gt; | [] | Gemini File Search store ids. Tool or augmentation (see `useFileSearchAsTool`). |
| `vectorSearchStores` | List&lt;String&gt; | [] | OpenAI vector store ids. Tool or augmentation (see `useVectorStoreAsTool`). |
| `mcpServers` | Map&lt;String, MCPClientInfo&gt; | {} | MCP server connections, keyed by alias. |
| `targetUsers` | List&lt;String&gt; | [] | Restrict to specific user ids. Empty = all users. |
| `targetGroups` | List&lt;String&gt; | [] | Restrict to groups. |
| `properties` | JsonObject | {} | Catch-all for provider-specific config, RAG tuning, model parameters, etc. |

> **Where access control lives:** `targetUsers` and `targetGroups` go at the **top level of the agent body YAML** (the file the agent itself is in), not inside `properties` and **not** in the `.config` sidecar. Agents follow the "config inside the artifact body" pattern (see `references/artifacts-and-config.md` § *properties per type*) — so the `.config.properties` for `type: Agent` stays `null`. Putting `targetGroups` under `properties` (or under the `.config`) is silently ignored: the agent ends up world-readable.

Source of truth: `dev/redflag/core/services/info/AgentInfo.java`.

---

## 3. Providers

`provider` is a **free string** parsed by the runtime; there is no closed Java enum. The runtime resolves it case-by-case (typically case-sensitive). Common values seen in the codebase and docs:

| Provider | Typical models |
|---|---|
| `OpenAI` | `gpt-4o`, `gpt-4o-mini`, `o3-mini` |
| `Gemini` | `gemini-2.5-flash`, `gemini-2.5-pro` |
| `Bedrock` | Claude / Cohere / Titan ids on AWS |
| `Anthropic` | `claude-sonnet-4-5`, `claude-opus-4-7` |

### Warning policy

Because `provider` and `model` are not validated against an enum:

- **Use the canonical capitalization** documented above (`OpenAI`, `Gemini`, `Bedrock`, `Anthropic`). The dev guide also shows `"openai"` lowercase working in some examples — prefer the capitalized form for safety.
- An unknown provider does **not** produce a hard error at parse time. Failures surface only when the agent first tries to call the LLM, often as cryptic SDK exceptions.
- Linters / validators in this skill emit **warnings** (not errors) for unrecognized providers, since custom providers are legitimate.
- For Coder/Analyst-style agents the `model` field uses `providerID/modelID` (e.g. `openai/gpt-4o-mini`); see `references/analyst.md`.

---

## 4. Model parameters (in `properties`)

Parameters live under `properties` and are forwarded to the provider's SDK. The set is provider-specific. The most universal ones:

| Parameter | Type | Range | Effect |
|---|---|---|---|
| `temperature` | double | 0.0–2.0 | Randomness. 0–0.3 deterministic, 0.4–0.7 balanced (default for most), 0.8+ creative. |
| `topP` | double | 0.0–1.0 | Nucleus sampling. Lower = focused. |
| `topK` | int | — | Gemini only. Top-K sampling. |
| `maxTokens` | int | — | OpenAI: cap on generated tokens. |
| `maxCompletionTokens` | int | — | OpenAI: cap on completion (output) only. |
| `maxOutputTokens` | int | — | Gemini equivalent of `maxTokens`. |
| `stop` / `stopSequences` | string[] | — | Stop sequences. |
| `seed` | int | — | Deterministic outputs given identical inputs. |
| `presencePenalty` | double | -2.0–2.0 | Discourage repeated topics. |
| `frequencyPenalty` | double | -2.0–2.0 | Discourage repeated tokens. |
| `responseFormat` | string | `json_object` / `json_schema` / `TEXT` / `JSON` | Structured output mode. |
| `parallelToolCalls` | boolean | — | OpenAI: allow parallel tool invocations. |
| `strictTools` | boolean | — | OpenAI: force tool use when available. |
| `duration` | int (sec) | default 60 | Request timeout. |
| `logRequests` / `logResponses` | boolean | — | Debug logging. |

### API keys and env vars

API keys, regions and other secrets accept the `@VARIABLE_NAME` syntax to pull from the environment:

```yaml
properties:
  apiKey: "@OPENAI_API_KEY"          # OpenAI
  # apiKey: "@GEMINIAI_API_KEY"      # Gemini default
  # region: "@AWS_BEDROCK_REGION"    # Bedrock default
  # accessKey: "@AWS_BEDROCK_ACCESS_KEY"
  # secretKey: "@AWS_BEDROCK_SECRET_KEY"
```

If `apiKey` is omitted, providers fall back to their conventional env var (`@OPENAI_API_KEY`, `@GEMINIAI_API_KEY`, etc.).

---

## 5. Instructions (system prompt)

`instructions` is the system prompt. Keep it specific and structured:

```yaml
instructions: |
  # Role
  You are the customer-onboarding assistant for Acme.

  # Tone
  Concise, professional, Spanish by default.

  # Capabilities
  - Look up customers via `searchCustomer`.
  - Create tickets via `createTicket`.
  - Cite the manual chunks returned by RAG when answering policy questions.

  # Guardrails
  - Never reveal internal IDs.
  - If unsure, ask a clarifying question — do not invent answers.
```

Best practices and patterns for writing agentic prompts (role, capabilities, guardrails, tool usage, refusal patterns) are covered in `references/prompts-agenticos.md`.

---

## 6. Tools (function calling)

The `tools` array contains **Script artifact ids**. A script becomes an LLM tool when its YAML declares the tool metadata under `properties.tool`. See `references/scripts-and-tools.md` section 7 for the full tool authoring guide.

Then on the agent:

```yaml
tools:
  - "PROJECT/SEARCH_CUSTOMER"
  - "PROJECT/CREATE_TICKET"
```

The runtime registers these as function tools with the LLM SDK and routes calls back to the script.

Additional tool sources:

- **`mcpServers`** — connects to external MCP servers; their tools are auto-exposed.
- **`mdResources`** — exposes a `loadContext` tool that fetches sections from indexed markdown.
- **`fileSearchStores`** with `useFileSearchAsTool: true` — exposes a `queryDocumentation` tool.
- **`vectorSearchStores`** with `useVectorStoreAsTool: true` — exposes `queryVectorStoreDocumentation`.

---

## 7. RAG (Retrieval-Augmented Generation)

Four resource mechanisms exist; pick based on size and access pattern:

| Mechanism | Backend | Mode | Best for |
|---|---|---|---|
| `ragResources` | PostgreSQL + pgvector | **Always-on augmentation** | Core knowledge that must influence every reply. |
| `mdResources` | Local markdown index | **Tool** (`loadContext`) | Curated docs the agent should fetch on demand. |
| `fileSearchStores` | Google Gemini File Search | Tool **or** augmentation | Large doc sets (Google service). Default = tool (recommended). |
| `vectorSearchStores` | OpenAI vector stores | Tool **or** augmentation | Doc sets using OpenAI embeddings. Default = augmentation. |

### `ragResources` pipeline

1. **Load** files (relative to YAML dir if no `/`, otherwise via the resource service).
2. **Parse**: `.md` → MarkdownDocumentParser; `.pdf` → ApachePdfBox; rest → Apache Tika.
3. **Chunk**: recursive splitter, default `ragChunkSize=1024`, `ragChunkOverlap=256`.
4. **Embed** each chunk with the configured embedding model.
5. **Store** in PostgreSQL table `pgv_{agent_id}_embeddings` (pgvector).
6. **Auto-rebuild** when files change (mtime-based) or resources are added/removed.
7. At query time: embed the user query, cosine-similarity search, top-`ragMaxResults` chunks above `ragMinScore` are injected into the prompt.

### Embedding configuration

```yaml
properties:
  embeddingModelProvider: "OpenAI"            # OpenAI | Gemini | Bedrock | (omit = local E5)
  embeddingModelName: "text-embedding-3-large"
  embeddingModelApiKey: "@OPENAI_API_KEY"
  # Gemini-specific
  taskType: "RETRIEVAL_DOCUMENT"
  outputDimensionality: 1536                  # >2000 disables IVFFlat index
  titleMetadataKey: "title"
```

Defaults by provider:

- OpenAI: `text-embedding-3-small`, key `@OPENAI_API_KEY`.
- Gemini: `gemini-embedding-001`, key `@GEMINIAI_API_KEY`, dimension 1536.
- Bedrock: id via `embeddingModelId` (e.g. `cohere.embed-english-v3`).
- Omitted: local `E5SmallV2QuantizedEmbeddingModel` (no API key, lower quality, fine for tests).

### Retrieval / chunking / index tuning

```yaml
properties:
  ragMaxResults: 10           # chunks injected per query
  ragMinScore: 0.3            # 0.0 = no filtering; 0.3-0.5 typical
  ragChunkSize: 1024          # 512-1024 normal, 2048 for technical docs
  ragChunkOverlap: 256        # 20-30% of chunk size
  ragEmbeddingStoreType: "database"   # database (pgvector) | inmemory
  ragUseIndex: true           # auto-disabled if dim > 2000
  ragIndexListSize: 100       # IVFFlat lists; 100 default, 200-500 for >100k vectors
```

### File Search (Gemini) and Vector Store (OpenAI)

```yaml
properties:
  fileSearchModel: "gemini-2.5-flash"
  useFileSearchAsTool: true        # default; use as tool (recommended — augmentation is slow)

  vectorStoreModel: "gpt-4o"
  useVectorStoreAsTool: false      # default; ContentRetriever (faster than tool mode)
  vectorStoreMaxResults: 10
```

---

## 8. Memory (chat history)

Enable conversation memory with `memoryEnabled: true` and tune in `properties`:

| Property | Default | Effect |
|---|---|---|
| `maxMessages` | 30 | Recent messages kept verbatim. |
| `summarizeMemory` | false | Summarize older messages to save tokens. |
| `summaryTokenLimit` | 5000 | Max tokens in the running summary. |
| `summaryWindowLimit` | 30 | Recent messages preserved before summarizing the rest. |

`chatStore` selects where conversation state is persisted across sessions.

---

## 9. Examples

### 9.1 Simple chatbot (OpenAI)

```yaml
name: "Acme FAQ Bot"
id: "ACME/FAQ_BOT"
active: true
provider: "OpenAI"
model: "gpt-4o-mini"
instructions: |
  You are the Acme FAQ assistant. Answer in Spanish.
  If you don't know the answer, say so — do not invent.
streaming: true
memoryEnabled: true
properties:
  apiKey: "@OPENAI_API_KEY"
  temperature: 0.3
  maxTokens: 800
  maxMessages: 20
```

### 9.2 Agent with RAG knowledge base

```yaml
name: "Documentation Assistant"
id: "ACME/DOC_ASSISTANT"
active: true
provider: "OpenAI"
model: "gpt-4o-mini"
instructions: |
  You answer product questions strictly from the supplied manual chunks.
  Quote the relevant section header when possible.
ragResources:
  - "ACME/USER_MANUAL_PDF"
  - "docs/release-notes.md"
properties:
  apiKey: "@OPENAI_API_KEY"
  temperature: 0.2
  embeddingModelProvider: "OpenAI"
  embeddingModelName: "text-embedding-3-large"
  embeddingModelApiKey: "@OPENAI_API_KEY"
  ragMaxResults: 12
  ragMinScore: 0.35
  ragChunkSize: 1024
  ragChunkOverlap: 256
```

### 9.3 Agent with function-calling tools

```yaml
name: "Support Agent"
id: "ACME/SUPPORT"
active: true
provider: "OpenAI"
model: "gpt-4o"
instructions: |
  You are a support agent. Use `searchCustomer` to find users
  and `createTicket` to open issues. Always confirm with the user
  before creating a ticket.
tools:
  - "ACME/SEARCH_CUSTOMER"
  - "ACME/CREATE_TICKET"
streaming: true
memoryEnabled: true
properties:
  apiKey: "@OPENAI_API_KEY"
  temperature: 0.2
  parallelToolCalls: true
  strictTools: false
```

### 9.4 End-to-end: tools + RAG + memory

```yaml
name: "Onboarding Concierge"
id: "ACME/ONBOARDING"
active: true
provider: "OpenAI"
model: "gpt-4o"
instructions: |
  # Role
  You are the onboarding concierge for new Acme customers.

  # Capabilities
  - Use `searchCustomer` to look up an existing record.
  - Use `createCustomer` to register a new customer.
  - Use `scheduleKickoff` to book the kickoff call.
  - Quote the onboarding handbook (RAG) when explaining policies.

  # Guardrails
  - Always confirm before writing data.
  - Reply in the user's language.
bootScript: "ACME/ONBOARDING_BOOT"
tools:
  - "ACME/SEARCH_CUSTOMER"
  - "ACME/CREATE_CUSTOMER"
  - "ACME/SCHEDULE_KICKOFF"
streaming: true
memoryEnabled: true
chatStore: "ACME/ONBOARDING_CHAT"
ragResources:
  - "ACME/ONBOARDING_HANDBOOK_PDF"
  - "docs/sla.md"
mdResources:
  - "policies.md"
targetGroups:
  - "SALES"
  - "CSM"
properties:
  apiKey: "@OPENAI_API_KEY"
  temperature: 0.3
  maxTokens: 2500
  parallelToolCalls: true
  maxMessages: 40
  summarizeMemory: true
  summaryTokenLimit: 4000

  # RAG tuning
  embeddingModelProvider: "OpenAI"
  embeddingModelName: "text-embedding-3-large"
  embeddingModelApiKey: "@OPENAI_API_KEY"
  ragMaxResults: 10
  ragMinScore: 0.3
  ragChunkSize: 1024
  ragChunkOverlap: 256
  ragEmbeddingStoreType: "database"
```

---

## 10. Common gotchas

- **Provider case-sensitivity.** `OpenAI`, `Gemini`, `Bedrock`, `Anthropic` — capitalization matters at runtime in most code paths. Lowercase `openai` is shown in some doc examples but the safe form is `OpenAI`.
- **Free-string provider/model.** Typos surface at first LLM call, not at parse time. Validate in dev.
- **Env-var prefix `@`.** `apiKey: "@OPENAI_API_KEY"` reads the env var; `apiKey: "OPENAI_API_KEY"` passes the literal string and will fail. Same for `region`, `accessKey`, `secretKey`.
- **`ragResources` always augments.** Every user message triggers an embedding lookup and prompt injection. For occasional lookups prefer `mdResources` or `fileSearchStores` with `useFileSearchAsTool: true`.
- **pgvector dimension limit.** IVFFlat indexes only support dimensions ≤ 2000. Setting `outputDimensionality` above 2000 silently disables the index — search still works but slows down on large stores.
- **`useFileSearchAsTool` defaults to `true` for a reason.** Using Gemini file search as augmentation is very slow; leave it as a tool unless you have a specific need.
- **`useVectorStoreAsTool` defaults to `false`** (ContentRetriever / augmentation). The opposite default of file search — easy to confuse.
- **Costs.** Streaming + large `maxMessages` + RAG + parallel tool calls can multiply token usage quickly. Cap `maxTokens`/`maxOutputTokens`, set `ragMaxResults` conservatively (5–10), enable `summarizeMemory` for long-running chats.
- **Auto-rebuild is async.** When a `ragResources` file changes, the rebuild happens in a background thread — early queries after a change may hit stale embeddings.
- **`memoryEnabled` requires `chatStore`** for cross-session persistence; without one, memory is per in-memory session only.
- **Tools must be Scripts with `properties.tool`.** Listing a script id in `tools` without the tool descriptor in the script does nothing.
- **`bootScript` runs once per session start** — keep it cheap; long boot scripts delay first-token latency.

---

## Validation summary

`validators/agent.py` checks:

- `id` matches `PROJECT/AGENT_ID` and `name` is present.
- `provider` is one of the documented values (warn, don't error, on unknown).
- `model` is set and consistent with the provider.
- `instructions` is non-empty.
- Every id in `tools` resolves to a Script artifact whose `properties.tool` declares `name`, `description`, `parameters` (cross-file mode).
- Every id in `ragResources`, `mdResources`, `fileSearchStores`, `vectorSearchStores`, `bootScript`, `chatStore` resolves to an existing artifact / store id (cross-file mode).
- All API-key/region fields use the `@VAR` form (no literal secrets in YAML).
- `temperature ∈ [0, 2]`, `topP ∈ [0, 1]`, `presencePenalty`/`frequencyPenalty ∈ [-2, 2]`.
- If `outputDimensionality > 2000`, `ragUseIndex` is `false` (or omitted — auto-disabled).
- If `memoryEnabled: true`, a `chatStore` is configured for cross-session persistence.
- `mcpServers` entries reference reachable MCP endpoints with valid auth.

---

## Cross-references

- `references/scripts-and-tools.md` — authoring Scripts and exposing them as agent tools (`properties.tool`).
- `references/prompts-agenticos.md` — patterns for writing the `instructions` system prompt and orchestrating multi-agent workflows.
- `references/analyst.md` — Analyst/Coder agents and the `providerID/modelID` model format.
