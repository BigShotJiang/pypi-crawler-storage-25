# Kanban

Alternate view for a Query that renders each row as a draggable card across columns (swimlanes). Useful for state-driven flows: "todo / doing / done", sales pipelines, order statuses, etc.

A Kanban is a **rendering mode for a Query**, not a separate artifact: enable it with `options.kanban: true` inside a Query YAML and reuse the same `view` (SQL), `columns`, `keys`, `dataSource`, `filterGroup`, IPO actions, autorefresh, etc.

> Cross-references: `references/queries.md` for everything related to the underlying Query, `references/scripts-and-tools.md` for `cardMovedScript`.

---

## YAML structure

The Kanban is configured **inside `options:`** of the Query (not as a sibling section):

```yaml
caption: "Sales Pipeline"
icon: "ADDRESS_BOOK"
dataSource: NORTHWIND
view: |
  SELECT id, title, status, body
    FROM opportunities
columns:
  - { name: id,     fieldType: integer }
  - { name: title,  fieldType: string  }
  - { name: status, fieldType: string  }
  - { name: body,   fieldType: string  }
keys: [id]
options:
  kanban: true                   # enables the view
  kanbanColumns:                 # map columnId -> caption
    NEW:    "New"
    QUAL:   "Qualified"
    WON:    "Won"
    LOST:   "Lost"
  titleField:    title           # row field -> card title
  bodyField:     body            # row field -> card body (HTML)
  cardIdField:   id              # row field -> unique card id
  columnIdField: status          # row field -> destination column key
  cardMovedScript: "run:CRM/MOVE_OPP"   # script triggered on drag&drop
scripts:
  - CRM/MOVE_OPP
```

Keys consumed by `KanbanQueryView`:

| Key | Default | Required | Description |
|---|---|---|---|
| `kanban` | `false` | yes | Boolean, enables Kanban mode. |
| `kanbanColumns` | `{}` | yes | Map `columnId -> "Caption"`, ordered by declaration. |
| `titleField` | `"title"` | recommended | Row field used as card title. |
| `bodyField` | `"body"` | recommended | Row field rendered as HTML inside the card. |
| `cardIdField` | `"cardId"` | recommended | Row field with the card's unique id; usually equals `keys`. |
| `columnIdField` | `"columnId"` | recommended | Row field whose value matches a key in `kanbanColumns`. |
| `cardMovedScript` | (none) | no | Tool/script invoked when a card is dropped. |
| `defaultAction` | (none) | no | IPO action name fired on double-click. |
| `selectionScript` | (none) | no | Script that receives card selection changes. |

---

## Columns

Columns are **declared statically** in `kanbanColumns` as an ordered map:

```yaml
kanbanColumns:
  TODO:    "To do"
  DOING:   "In progress"
  REVIEW:  "Review"
  DONE:    "Done"
```

- **Key** = value the `columnIdField` field must carry in the SELECT (case-sensitive).
- **Value** = caption shown in the column header.
- **Visual order** = order of appearance in the YAML.

There is **no YAML key for column color or icon**: `KanbanColumn` applies fixed Lumo styles (`--lumo-contrast-5pct`, default border/radius) and a blue highlight on drag-over. Differentiate cards/columns visually via HTML/CSS inside `bodyField` (see gotchas).

**Fallback column `other`**: if a row carries a `columnIdField` value that doesn't match any declared key, `KanbanQueryView.search()` automatically creates a column `other` (caption `"Other"`) and drops those cards there. Useful to detect unexpected values without losing rows.

---

## Cards

Each row becomes a `KanbanCard<JsonObject>` via `JsonCardRenderer`, which uses:

- **Title** = `row[titleField]` (plain text, no HTML).
- **Body** = `row[bodyField]` (rendered as **raw HTML**).
- **Id** = `row[cardIdField]` (string; if absent, falls back to `hashCode()` — always supply a real id).
- **Destination column** = `row[columnIdField]`.

The body template is built **in SQL** by string-concatenating HTML — there is no separate templating system:

```sql
SELECT
  id,
  title,
  status,
  '<div style="font-size:0.85em">'
    || '<p><b>' || coalesce(owner,'-') || '</b></p>'
    || '<p>Amount: $' || to_char(amount,'FM999G999') || '</p>'
    || '<p>Close: ' || to_char(close_date,'DD/MM/YYYY') || '</p>'
  || '</div>' AS body
  FROM opportunities
```

Alternative: generate the HTML in a post-processor (`references/templates.md`) instead of the SELECT, keeping the relational query clean.

---

## Drag & drop: `cardMovedScript`

When the user drops a card on another column (or reorders within the same one), `KanbanQueryView` internally fires the IPO action `@@@CARD_MOVED@@@`. If `options.cardMovedScript` is set to a `run:PROJECT/SCRIPT_ID`, that script receives the event.

**Payload (`bpm.context`)** — fields guaranteed by `CardMoveEvent`:

| Field | Type | Description |
|---|---|---|
| `cardId` | string | Id of the moved card (= value of `cardIdField`). |
| `sourceColumnId` | string | Source column (key of `kanbanColumns`, not the caption). |
| `targetColumnId` | string | Destination column. |
| `newIndex` | int | 0-based position in the destination column. |
| `previousCardId` | string? | Id of the previous card in destination (`null` at top). |
| `nextCardId` | string? | Id of the next card in destination (`null` at bottom). |

In addition, the moved row itself is passed as `selection` (one-element array) to the IPO service.

**Typical Python skeleton:**

```python
#!python3
import redflagbpm
from redflagbpm.PgUtils import get_connection
bpm = redflagbpm.BPMService()

card_id = bpm.context["cardId"]
src     = bpm.context["sourceColumnId"]
dst     = bpm.context["targetColumnId"]

with get_connection(bpm, "sales") as conn, conn.cursor() as cur:
    if src == dst:
        # Reorder within the column; persist index if relevant.
        cur.execute(
            "UPDATE opportunities SET sort_order = %s WHERE id = %s",
            (bpm.context["newIndex"], card_id),
        )
    else:
        cur.execute(
            "UPDATE opportunities SET status = %s WHERE id = %s",
            (dst, card_id),
        )

# Optional message rendered in the board footer (text or HTML).
print(f"Moved to {dst}")
```

If the script returns `text/html` or a string starting with `<` and ending with `>`, it is rendered as HTML in the board footer; otherwise it shows as a `Label`.

**No automatic rollback**: if the `UPDATE` fails, the card stays visually in the new column until the next `search()`. Returning a terminal-change response (the type returned by create/update/delete IPO) or calling refresh forces the reload.

---

## Per-column configuration (caption / color / icon)

At the YAML level, the **only per-column configuration is the caption** (`Key: "Caption"`). There are no YAML keys for `color` or `icon` per column.

To differentiate visually:

- **Card color by status**: include `<div style="border-left:4px solid red">…</div>` in `bodyField` with the color derived from the status in SQL (`CASE WHEN status='LOST' THEN 'red' …`).
- **Icon in the title**: add `<vaadin-icon icon="vaadin:check"></vaadin-icon>` or an `<img>` inside the body HTML (`titleField` is plain text, not HTML).
- **Column color**: requires global theme CSS, not configurable per board.

---

## End-to-end example

Task board with 4 columns and state persistence via script:

```yaml
# queries/TASKS/BOARD.yaml
caption: "Task Board"
icon: "TASKS"
dataSource: APP
view: |
  SELECT t.id,
         t.title,
         t.status,
         '<div style="font-size:0.85em">'
           || '<p><b>' || coalesce(u.full_name,'-') || '</b></p>'
           || '<p>Due: ' || to_char(t.due_date,'DD/MM/YYYY') || '</p>'
           || CASE WHEN t.priority='HIGH'
                   THEN '<span style="color:red">[HIGH]</span>'
                   ELSE '' END
         || '</div>' AS body
    FROM tasks t
    LEFT JOIN users u ON u.id = t.assignee_id
   WHERE t.archived = false
columns:
  - { name: id,     fieldType: integer }
  - { name: title,  fieldType: string  }
  - { name: status, fieldType: string  }
  - { name: body,   fieldType: string  }
keys: [id]
filterGroup:
  filters:
    - { name: assignee_id, caption: "Owner", fieldType: integer,
        valueProvider: "USERS/LOOKUP" }
options:
  kanban: true
  kanbanColumns:
    TODO:    "To do"
    DOING:   "In progress"
    REVIEW:  "Review"
    DONE:    "Done"
  titleField:      title
  bodyField:       body
  cardIdField:     id
  columnIdField:   status
  cardMovedScript: "run:TASKS/ON_MOVE"
  defaultAction:   "EDIT_TASK"   # double-click opens edit
scripts:
  - TASKS/ON_MOVE
```

```python
# scripts/TASKS/ON_MOVE.py
#!python3
import redflagbpm
bpm = redflagbpm.BPMService()

task_id = int(bpm.context["cardId"])
target  = bpm.context["targetColumnId"]
source  = bpm.context["sourceColumnId"]

ALLOWED = {
    "TODO":   {"DOING"},
    "DOING":  {"TODO", "REVIEW"},
    "REVIEW": {"DOING", "DONE"},
    "DONE":   {"REVIEW"},
}

if source != target and target not in ALLOWED.get(source, set()):
    bpm.text(f"<b>Transition not allowed:</b> {source} -> {target}")
    return

bpm.execute(
    "UPDATE tasks SET status=:s, updated_at=now() WHERE id=:id",
    s=target, id=task_id,
)
bpm.text(f"Task {task_id} -> {target}")
```

---

## Common gotchas

- **`kanbanColumns` is case-sensitive**: if SELECT returns `'todo'` lowercase and the key is `TODO`, cards land in the `other` column.
- **Don't declare `other` yourself**: if a key is named `other` the system uses it and you lose the "unexpected value" indicator.
- **`bodyField` is rendered as raw HTML** (Vaadin `Html`): any user-provided data must be escaped in SQL to prevent XSS. `titleField` in contrast is plain text.
- **Without a valid `cardIdField`** cards get a `hashCode()`-derived id and selectors / drag&drop become unstable after a refresh.
- **`cardMovedScript` doesn't auto-persist**: if you don't UPDATE, the next `search()` reverts the card to its original column (the backend's).
- **Intra-column reordering**: `sourceColumnId == targetColumnId` with a different `newIndex`. If order doesn't matter to you, ignore that case to avoid pointless UPDATEs.
- **No visual rollback**: an exception in the script doesn't return the card to its source column; the error appears in the footer and the next refresh syncs.
- **`waitForFilter`**: if the query has it `true`, the board starts empty until a filter is applied (`searchOnAttach = !waitForFilter`).
- **Autorefresh + drag&drop**: with `autorefresh > 0`, a reload while a user has a card "in flight" can confuse them — prefer generous intervals.
- **No pagination**: `KanbanQueryView` calls `fetch(0, Integer.MAX_VALUE, …)`. For large datasets, filter aggressively in `filterGroup` or use a different view.
- **Per-column color/icon need global CSS**, not YAML attributes.
- **Double-click vs default action**: if `options.defaultAction` is missing, `KanbanQueryView` infers one (first action with `HINT_DEFAULT`, then any `OPEN/DISPLAY/QUERY`, then any `UPDATE`). If none exists, double-click does nothing.

---

## Validation summary

`validators/kanban.py` (or `query.py` when `options.kanban: true`) checks:

- `options.kanban: true` is present.
- `kanbanColumns` declares at least one key, and the values that `columnIdField` produces (when statically detectable) match those keys exactly (case-sensitive).
- The SELECT (or columns) includes the four fields: `cardIdField`, `columnIdField`, `titleField`, `bodyField`. They appear in `columns:` with the right `fieldType`.
- `cardIdField` is unique per row (ideally matches `keys`).
- `bodyField` is **escaped/sanitized** in SQL when it concatenates user data (warning if the validator detects raw concatenation of free-text columns).
- If `cardMovedScript` is defined, the script exists, is listed in `scripts:`, and persists the change to `columnIdField` in the data source.
- If `defaultAction` is defined, its `name` matches an IPO action published by the query.
- `filterGroup` filters that return huge datasets are flagged (no pagination).
- No assumptions about per-column color/icon from YAML; visual differentiation is embedded in the `bodyField` HTML.
