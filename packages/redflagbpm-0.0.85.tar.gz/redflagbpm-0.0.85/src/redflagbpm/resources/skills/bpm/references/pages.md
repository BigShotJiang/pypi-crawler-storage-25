# Pages

Pages are server-rendered UI artifacts: HTML produced on demand from a Velocity template, a Python/JS/Shell script that prints to stdout, a Markdown file, or a static Binary asset (image, PDF). They are mounted under the route `Page/p?__page__=PROJECT/PAGE_ID` and rendered inside the standard application chrome (header, menus, user session) — think microsite, dashboard, embedded report, or a custom landing tab.

Pages differ from **Reports** in three ways: (1) Pages are interactive HTML rendered in the browser, Reports are generated documents (PDF/XLSX/DOCX/HTML asset); (2) Pages run on every navigation with the live URL parameters in `bpm.context`, Reports are kicked off as a download/print job from a service; (3) Pages live in the Vaadin shell (`MainLayout`) and can be linked from menus, while Reports are dispatched via `Service/s?__service__=…`. Use a Page when the user needs to *read* a screen; use a Report when the user needs to *export* a file.

> **Source of truth**: `dev/redflag/bpm/dto/CodeDTO.java` (`TYPE_PAGE`, `lang` constants), `dev/redflag/bpm/impl/SimpleBPMService.java#page()`, `dev/redflag/bpm/app/bpm/BPMPageView.java` (URL → context wiring), `dev/redflag/bpm/impl/ipos/PagesIPOService.java` (Pages list view), `dev/redflag/bpm/impl/util/MenuBuilder.java` (menu integration). The Java code wins when it disagrees with the developer guide.
>
> **See also**: `references/artifacts-and-config.md` (the sibling `.config` file), `references/queries.md` (queries you can link or embed), `references/templates.md` (HTML/Markdown rendering used by post-processors — same spirit), `references/scripts-and-tools.md` (the `bpm.context` API).

---

## The artifact

A Page is a `CodeDTO` with `type: "Page"` and one of the following `lang` values:

| `lang` | File extension | What runs |
|---|---|---|
| `Velocity` | `.vtl`, `.vhtml`, `.html`, `.htm` | Apache Velocity template; `$variables` resolved from context |
| `Python` | `.py` | Jython script; whatever it prints to stdout becomes the HTML body |
| `JavaScript` | `.js` | Nashorn/JS engine; `print(...)` writes the HTML body |
| `Shell` | `.sh`, `.py3`, etc. | Shebang-driven (`#!/bin/bash`, `#!python3`, `#!/usr/bin/env node`) — stdout becomes HTML |
| `Markdown` | `.md` | Rendered to HTML and shown |
| `Binary` | `.png`, `.pdf`, `.svg`, `.jpg`, … | Bytes streamed as-is with the right content type |

The runtime accepts any combination of `lang` and `type`, but the validators warn outside the list above (see `references/artifacts-and-config.md`).

### `properties`

```yaml
properties:
  title: "Dashboard"        # browser/tab title (string)
  icon: "DASHBOARD"         # Vaadin icon used by Pages list and menus
  caption: "Dashboard"      # caption displayed when the Page appears in a menu
  menus:                    # menus where the Page should auto-appear
    - "MAIN_MENU"
  targetUsers: []           # access control (empty = all signed-in users)
  targetGroups:
    - "SALES"
```

`title` is the only Page-specific property; the rest are common artifact metadata. See `references/artifacts-and-config.md` for the closed lists.

---

## Examples by `lang`

### 1. Velocity — typical dashboard

```yaml
# pages/dashboard.vtl.config
project: "SALES"
id: "SALES/PAGE_DASHBOARD"
lang: "Velocity"
type: "Page"
description: "Sales overview dashboard."
properties:
  title: "Sales Dashboard"
  icon: "CHART"
  menus: ["MAIN_MENU"]
```

```vtl
## pages/dashboard.vhtml
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>$!properties.title</title>
  <style>
    body { font-family: system-ui, sans-serif; margin: 0; padding: 24px; }
    .kpi { display: inline-block; min-width: 200px; padding: 16px; margin-right: 12px;
           border-radius: 8px; background: #f4f6f8; }
    .kpi .v { font-size: 28px; font-weight: 600; }
  </style>
</head>
<body>
  <h1>Hello $!userId</h1>
  <p>Showing data for region: <b>$!region</b></p>

  <div class="kpi"><div>Open orders</div><div class="v">$!openOrders</div></div>
  <div class="kpi"><div>Revenue MTD</div><div class="v">$!revenueMtd</div></div>
</body>
</html>
```

Variables (`$userId`, `$region`, `$openOrders`, …) come from URL query parameters and from values the user has on the session (`userId`, `userGroups` are always present — see [Accessing parameters](#accessing-parameters)). Use `$!var` (silent) instead of `$var` to render an empty string when the variable is missing.

### 2. Python — dynamic content with backend queries

```yaml
# pages/orders_today.py.config
project: "SALES"
id: "SALES/PAGE_ORDERS_TODAY"
lang: "Python"
type: "Page"
description: "Page that lists today's orders for the requested region."
properties:
  title: "Orders today"
```

```python
#!python3
import redflagbpm
from html import escape

bpm = redflagbpm.BPMService()
region = bpm.context.region or "ALL"

rows = bpm.execute(
    "SELECT order_id, customer_name, total FROM orders "
    "WHERE order_date = CURRENT_DATE AND (? = 'ALL' OR region = ?)",
    region, region
)

print(f"""<!DOCTYPE html>
<html><head><title>Orders today</title></head>
<body>
  <h1>Orders for {escape(region)}</h1>
  <table border="1" cellspacing="0" cellpadding="6">
    <thead><tr><th>#</th><th>Customer</th><th>Total</th></tr></thead>
    <tbody>""")
for r in rows:
    print(f"<tr><td>{r['order_id']}</td>"
          f"<td>{escape(r['customer_name'])}</td>"
          f"<td>{r['total']:.2f}</td></tr>")
print("</tbody></table></body></html>")
```

Everything written to **stdout** becomes the HTML body. Anything sent to stderr is dropped. Always escape user/data values (see [Common gotchas](#common-gotchas)).

### 3. Markdown — documentation / help

```yaml
# pages/help_orders.md.config
project: "SALES"
id: "SALES/PAGE_HELP_ORDERS"
lang: "Markdown"
type: "Page"
description: "Help page for the orders module."
properties:
  title: "Orders — help"
  icon: "QUESTION"
  menus: ["HELP_MENU"]
```

```markdown
# Orders — help

This module lets you manage **open orders**.

## Workflow
1. Open the *Orders* query.
2. Select one or more rows.
3. Run the *Approve* action from the toolbar.

> Need access? Ask your administrator to add you to the `SALES` group.
```

The Markdown is parsed server-side and rendered inside the standard page chrome.

### 4. Binary — static asset (image / PDF)

```yaml
# pages/brand_logo.png.config
project: "BRAND"
id: "BRAND/PAGE_LOGO"
lang: "Binary"
type: "Page"
description: "Public brand logo (PNG)."
properties:
  title: "Logo"
```

The file is served as-is. Use a Binary Page to publish a stable URL for an image or PDF that other artifacts (Velocity templates, queries with `htmlColumns`, emails) can `<img src="...">` or link to.

---

## Accessing parameters

Pages are reached via:

```
/Page/p?__page__=PROJECT/PAGE_ID&region=EU&customer_id=42
```

`__page__` is reserved and stripped by `BPMPageView#setParameter`. Every other query parameter is added to the page context:

- single value → string
- repeated key (`tag=a&tag=b`) → JSON array

The runtime always adds `userId` and `userGroups` to the context before invoking the page (`SimpleBPMService#page`).

**From Python / JavaScript / Shell:**

```python
bpm = redflagbpm.BPMService()
region      = bpm.context.region          # ?region=EU         -> "EU"
customer_id = bpm.context.customer_id     # ?customer_id=42    -> "42" (string)
tags        = bpm.context.tag             # ?tag=a&tag=b       -> ["a", "b"]
who         = bpm.context.userId          # always populated
groups      = bpm.context.userGroups      # always populated (list)
```

```javascript
var region = bpm.context.region;
print("Region: " + region);
```

**From Velocity:**

```vtl
Region: $!region
User:   $!userId
#foreach($g in $userGroups)
  - $g
#end
```

URL parameters are always strings — cast/parse them in the script if you need numbers, dates, or JSON.

---

## Calling backend data from a Page

The Page script has the same `bpm.*` API as any other script (see `references/scripts-and-tools.md` section 5):

| API | Use it for |
|---|---|
| `redflagbpm.PgUtils.get_connection(bpm, "datasource")` | Direct SQL against a registered Postgres datasource (use `MSSQLUtils` for SQL Server). See `references/sdk-python.md`. |
| `bpm.documentService.readList(collection, filter, sort, limit)` | Read from a Collection |
| `bpm.service.execute(scriptId, context)` | Reuse logic from another Script |
| `bpm.service.env()` | Environment variables |
| `bpm.logger.info("category", "msg")` | Server log |

Velocity Pages do not have a script engine — they only see what the runtime put in the context. To inject query results into a Velocity Page, write a small Python/JS Page that runs the query and renders Velocity itself, **or** use Python/JS as the page `lang` and produce HTML directly.

---

## Layout: embedding queries, charts and other widgets

Pages render arbitrary HTML, so embedding is just a matter of pointing to the right URL or loading the right asset:

- **Link to a Query**: `<a href="Query/q?__query__=SALES/QRY_ORDERS&region=EU">Open orders</a>`
- **Open a Service**: `<a href="Service/s?__service__=SALES/SRV_REPORT">Run report</a>`
- **Embed another Page**: `<iframe src="Page/p?__page__=SALES/PAGE_KPI&region=EU" style="width:100%;height:320px;border:0"></iframe>`
- **Embed a Binary Page** (image / PDF): `<img src="Page/p?__page__=BRAND/PAGE_LOGO"/>` or `<embed src="Page/p?__page__=DOCS/PAGE_TERMS_PDF" type="application/pdf"/>`
- **Charts**: include a JS library inline (e.g. Chart.js via CDN) and feed it data the script already has:
  ```html
  <canvas id="c" width="600" height="240"></canvas>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    new Chart(document.getElementById('c'),
      { type: 'bar', data: { labels: ['A','B','C'], datasets: [{ data: [10,20,15] }] } });
  </script>
  ```

For grids, prefer linking to or `<iframe>`-ing an existing Query rather than rebuilding the table by hand — the Query gets sorting, paging, filters, exports, actions and access control for free.

---

## End-to-end example: dashboard with a header and two embedded queries

```yaml
# pages/sales_home.py.config
project: "SALES"
id: "SALES/PAGE_HOME"
lang: "Python"
type: "Page"
description: "Sales home dashboard with KPIs and two embedded queries."
properties:
  title: "Sales — home"
  icon: "DASHBOARD"
  caption: "Sales home"
  menus: ["MAIN_MENU"]
  targetGroups: ["SALES"]
```

```python
#!python3
import redflagbpm
from html import escape

bpm = redflagbpm.BPMService()
region = bpm.context.region or "ALL"

# 1. KPIs computed on the server
kpi = bpm.execute(
    "SELECT COUNT(*) AS open_orders, COALESCE(SUM(total),0) AS revenue_mtd "
    "FROM orders "
    "WHERE status = 'OPEN' AND DATE_TRUNC('month', order_date) = DATE_TRUNC('month', CURRENT_DATE) "
    "AND (? = 'ALL' OR region = ?)",
    region, region
)[0]

# 2. Two queries we want to embed below the header
qry_orders    = "SALES/QRY_ORDERS_OPEN"
qry_top_cust  = "SALES/QRY_TOP_CUSTOMERS"

print(f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>Sales — home</title>
  <style>
    body  {{ font-family: system-ui, sans-serif; margin: 0; padding: 16px; }}
    .row  {{ display: flex; gap: 16px; flex-wrap: wrap; }}
    .kpi  {{ flex: 1 1 200px; padding: 16px; border-radius: 8px; background: #f4f6f8; }}
    .kpi .v {{ font-size: 28px; font-weight: 600; }}
    iframe  {{ width: 100%; height: 360px; border: 1px solid #e0e0e0; border-radius: 6px; }}
    h2    {{ margin-top: 24px; }}
  </style>
</head>
<body>
  <h1>Hello {escape(bpm.context.userId or '')}</h1>
  <p>Region: <b>{escape(region)}</b></p>

  <div class="row">
    <div class="kpi"><div>Open orders</div><div class="v">{kpi['open_orders']}</div></div>
    <div class="kpi"><div>Revenue MTD</div><div class="v">{kpi['revenue_mtd']:.2f}</div></div>
  </div>

  <h2>Open orders</h2>
  <iframe src="Query/q?__query__={qry_orders}&amp;region={escape(region)}"></iframe>

  <h2>Top customers</h2>
  <iframe src="Query/q?__query__={qry_top_cust}&amp;region={escape(region)}"></iframe>
</body>
</html>""")
```

Reach it as `Page/p?__page__=SALES/PAGE_HOME&region=EU`. The page reads `region`, runs one SQL aggregate, embeds two existing Queries that already know how to filter by `region`, and inherits the standard `MainLayout` navigation around it.

---

## Common gotchas

- **Always escape data going into HTML.** Velocity does **not** escape `$var` by default and Python/JS string concatenation does no escaping at all. Use `html.escape(...)` (Python) or a library helper (`he.encode`, `_.escape`) and keep URL parameters out of attributes without `&amp;`-encoding `&` separators.
- **The script must print to stdout.** Anything sent to `stderr` is dropped (`SimpleBPMService#page` only consumes stdout). If a Python page renders blank, check whether you accidentally used `sys.stderr.write(...)` or a logger that prints to stderr.
- **Pages run on every request.** Heavy SQL or external HTTP calls inside the script will be re-executed on every navigation and on every refresh — there is no built-in HTTP cache. For expensive aggregates, persist the result in a Collection and read it back, or move the work to a `cron` Script that refreshes a materialized table.
- **No client-side state by default.** A Page is server-rendered HTML; the URL is the only persistent state. To preserve filters across navigations, encode them in query parameters and read them on every render (`bpm.context.<name>`).
- **`bpm.context.<param>` is always a `String` (or `JSONArray` if repeated).** Cast to `int`, `float`, `date` explicitly. `bpm.context.foo or default` is a safe pattern in Python.
- **Velocity Pages cannot run SQL.** If you need data, choose `Python`/`JavaScript`/`Shell` as `lang`, **or** precompute the data in a script and pass it in as URL parameters.
- **Markdown Pages render the file as-is** — they do not interpolate `bpm.context`. For dynamic Markdown, use a Python Page that prints the Markdown rendered by your favorite library (or HTML directly).
- **Binary Pages are not templated.** They are raw bytes. Don't put `Velocity` directives inside a Binary asset — they will be served verbatim.
- **`__page__` is reserved.** Don't use `__page__` as one of your own query parameter names; it is consumed by the router and overwritten with the artifact id.
- **Access control still applies.** `targetUsers`/`targetGroups` in `properties` gate the Pages list (`PagesIPOService`) and menu visibility (`MenuBuilder`), but a user who knows the URL can still hit the Page if no group restriction is enforced upstream — check `bpm.context.userGroups` inside the script for sensitive content.
- **Tabs/title.** The browser tab uses `properties.title`; if missing, it falls back to `description`, then to the artifact id. Always set `title` for user-facing pages.

---

## Validation summary

- `type: "Page"` is required (`CodeDTO.TYPE_PAGE`); `SimpleBPMService#page` rejects artifacts whose `type` is anything else.
- `lang` must be one of `Velocity`, `Python`, `JavaScript`, `Shell`, `Markdown`, `Binary` (validators warn for any other combination — see `references/artifacts-and-config.md`).
- `id` matches `^[A-Z][A-Z0-9_]*/[A-Z][A-Z0-9_]*$` and the prefix matches the `project` field.
- For Python/JS/Shell pages, the script must print HTML to **stdout**. stderr output is silently dropped.
- For Velocity pages, `$variables` must come from the URL or from `userId` / `userGroups` — there is no script context.
- `properties.title` should be a non-empty string for user-facing pages.
- `properties.menus` entries must reference existing Menu artifacts; otherwise the page will not appear in the navigation but is still reachable by URL.
- `properties.targetUsers`/`targetGroups` gate the Pages list and menu visibility; protect sensitive pages by also checking `bpm.context.userGroups` inside the script.
- Reserve `__page__` for the router; do not use it as a custom URL parameter name.
- All HTML produced by the script (including Velocity output) must escape user-supplied or DB-supplied values to avoid XSS.
