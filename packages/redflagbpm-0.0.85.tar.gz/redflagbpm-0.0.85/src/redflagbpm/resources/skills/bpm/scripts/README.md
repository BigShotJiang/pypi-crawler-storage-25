# BPM skill validators

Two CLIs:

- **`validate.py`** — schema/rules check on YAML artifacts (`.yml`, `.yaml`, `.config`).
- **`validate_python.sh`** — Python syntax check (`py_compile`) on `.py` script artifacts that target CPython. Plain bash on top of `python3 -m py_compile`; no extra dependencies.

Use them together: the YAML validator catches `.config`/body-level mistakes; the Python validator catches `SyntaxError`s, top-level `return`, and shebang typos that the YAML validator can't see.

---

## `validate.py` — BPM artifact validator CLI

Validate one or more BPM artifact files against the rules documented in `skills/bpm/references/`. Auto-detects the artifact type from the `.config` sidecar or the body shape; can be forced with `--type`.

The single source of truth for closed value sets lives in `validators/enums.py` (`ARTIFACT_TYPES`, `LANGS`, `ACTION_TYPES`, `IPO_RESPONSE_TYPES`, `WORKFLOW_TYPES`, `GRID_VARIANTS`, `FORM_SUBTYPES`, `SANDBOX_*`, …). Each constant cites the Java file and line that authoritatively defines it.

---

## Install

The validators only need PyYAML at runtime; pytest is used for the test suite.

```bash
pip install pyyaml
# Or with the system-package guard on Debian/Ubuntu:
pip install --user --break-system-packages pyyaml

# For tests:
pip install pytest
```

Python 3.10+ recommended.

---

## Usage

```bash
# Auto-detect type (looks at sibling .config first, then body shape)
python skills/bpm/scripts/validate.py path/to/artifact.yml

# Force a validator (skips auto-detection)
python skills/bpm/scripts/validate.py --type query path/to/QRY_ORDERS.yml

# Strict mode: warnings count as errors for the exit code
python skills/bpm/scripts/validate.py --strict path/to/file

# JSON output (machine-readable, for CI / pre-commit hooks)
python skills/bpm/scripts/validate.py --json path/to/file

# Multiple files at once
python skills/bpm/scripts/validate.py file1.yml file2.yml.config dir/file3.yml
```

`--type` accepts: `agent`, `analyst`, `config_file`, `form`, `kanban`, `menu`, `prompt`, `query`, `repo`, `sandbox`, `service`, `value_provider`.

---

## Auto-detection rules

`detect_artifact_type` (`validators/common.py`) follows this priority:

1. `--type` flag, if given.
2. `config["type"]` from the sibling `.config` (e.g. `Query` → `query`, `Mcp` → `agent`, `Analyst` → `analyst`).
3. Body-shape heuristics in this order — first match wins:
   `repo` → `analyst` → `prompt` → `agent` → `query` → `kanban` → `value_provider` → `service` → `menu` → `form` → `sandbox`.
4. Fallback: `config_file` (treats the input as a `.config` file).

When the detection is wrong, pass `--type` explicitly.

---

## Severities

| Severity | Meaning | Effect on exit code |
|---|---|---|
| **error** | Closed-set violation, missing required field, structural problem. | Always counts. |
| **warning** | Value outside the documented common set, but the runtime accepts free strings (e.g. unusual `subtype`, untested LLM `provider`, `model: google/gemini-2.5-flash`). | Counts only with `--strict`. |
| **info** | Style suggestion or deprecation note (e.g. legacy `form: false`, `debug: true` shipped to end users). | Never affects exit code. |

---

## Exit codes

| Code | Meaning |
|---|---|
| `0` | All files passed. With `--strict`, also no warnings. |
| `1` | At least one error (or warning, if `--strict`). |
| `2` | Invalid invocation (argparse error). |

---

## What each validator checks

Quick mapping. Full coverage is in each reference's "Validation summary" section.

| Validator | Reference | Headline checks |
|---|---|---|
| `config_file` | `artifacts-and-config.md` | `project`/`id`/`lang`/`type` required; `lang` ∈ `LANGS`; `type` ∈ `ARTIFACT_TYPES`; `id` matches `PROJECT/ARTIFACT_ID` and matches `project`; `lang ↔ type` coherence; Script `properties.type`/`displayHints`/`selectionScope`. |
| `query` | `queries.md` | data source detection; `viewBindings` count vs `?`; column `align`/`width`/`fieldType`; filter group; action references; `themeVariants` ∈ `GRID_VARIANTS`. |
| `form` | `forms.md` | root `type: object`; `required` references declared properties; `hints.subtype` ∈ `FORM_SUBTYPES`; `hints.upload` requires `resourcePath`; `format` ∈ known. |
| `service` | `services.md` | `requestUrl` matches one of three forms; `responseType` ∈ 16 IPO values; `responseTarget` required for QUERY/REPORT/SERVICE; `inputSchema` is a valid form. |
| `agent` | `agents-and-rag.md` | `id`/`provider`/`model` required; `apiKey` should be `@VAR`; numeric ranges (`temperature`, `topP`, …); tools are valid `PROJECT/ID`. |
| `prompt` | `prompts-agenticos.md` | `workflow` ∈ `WORKFLOW_TYPES`; sub-agents inherit `agent`; `loop`/`conditional` config rules; schema validity. |
| `kanban` | `kanban.md` | `options.kanban: true`; `kanbanColumns` declared; `titleField`/`bodyField`/`cardIdField`/`columnIdField` exist in columns; `cardMovedScript` reference. |
| `value_provider` | `value-providers.md` | columns include `id` + `caption`; `keys: [id]`; ACL set; `crud: false`; `stringFormat` references declared columns. |
| `menu` | `menus-and-routes.md` | `MenuInfo` field allowlist; `id`/`name` recommended; `items` recursion; separator handling. |
| `repo` | `coder.md` | `url` SSH form; `key`/`username`/`email` required; `model` FQ; opencode `prompt` vs `instructions` confusion; `sandbox` delegated. |
| `analyst` | `analyst.md` | required `id`/`name`/`model`/`sandbox`; `sandbox.mode != host`; `tools` not listing plugin tools; `resources` URI scheme; `prompts.<key>.message` required. |
| `sandbox` | `sandbox.md` | `image` or `build`; `service` allow/forbid lists; `network`/`pid`/`ipc`/`userns_mode` rules; mount source allowlist/denylist; placeholder names. |

---

## Testing

```bash
python -m pytest skills/bpm/scripts/tests/ -v
```

The test suite (`tests/test_validators.py`) is parametrised over `tests/fixtures/`:

- **`tests/fixtures/valid/<validator>_*.yaml`** — must produce zero errors.
- **`tests/fixtures/invalid/<validator>_*.yaml`** — must produce at least one error.

Filenames drive the validator dispatch: a fixture starting with `query_` is validated with `--type query`, etc. To add coverage for a new edge case, drop a YAML file into the right `valid/` or `invalid/` folder; pytest will pick it up automatically.

---

## Calling from Python

```python
from pathlib import Path
import sys
sys.path.insert(0, "skills/bpm/scripts")
from validate import validate_path

result = validate_path(Path("path/to/artifact.yml"), explicit_type=None)
print(result.is_ok, len(result.errors), len(result.warnings))
for issue in result.issues:
    print(issue.severity.value, issue.code, issue.message)
```

`ValidationResult.to_dict()` returns the same structure as `--json` output.

---

## Adding a new validator

1. Add a module `validators/<name>.py` that exposes `validate(body, config, result) -> None`.
2. Import value sets from `validators/enums.py` (extend it if you need new ones — always cite the Java source).
3. Register the module in `VALIDATOR_MODULES` (in `validate.py`) and in `_CONFIG_TYPE_TO_VALIDATOR` / `_BODY_HEURISTICS` (in `validators/common.py`) if the new type should be auto-detected.
4. Add at least one valid and one invalid fixture under `tests/fixtures/`.
5. Run the test suite.

---

## `validate_python.sh` — Python syntax check for CPython script artifacts

Walks one or more paths and runs `python3 -m py_compile` on every `.py` file that targets **CPython** (`lang: "Shell"` with a `python3` shebang). Catches what the YAML validator cannot:

- `SyntaxError` (mismatched brackets, mistyped `def`, etc.).
- `return` outside a function (a real bug we hit several times in the docs and in samples).
- Shebang typos like `#!pyhton3` — BPM won't dispatch the script and the file silently never runs.

Each file is compiled with the **interpreter named by its shebang**, when that interpreter exists on the host. So a script with `#!/app/files/BpmApp/venvs/data-science/bin/python3` is checked under that exact venv; one with `#!/usr/bin/env python3.11` uses 3.11 from PATH; one with the BPM-specific `#!python3` falls back to whatever `python3` is on PATH (the runtime resolves it to the DEFAULT venv at deploy time — we can't see that locally). When the shebang's interpreter isn't installed locally, the validator reports an info note and falls back to the system `python3`.

We use per-file `py_compile`, **not** `python3 -m compileall`, because compileall surfaces import-time errors as soon as a folder contains sibling modules — a shape that is rare in BPM repos and noisy when it appears.

### Usage

```bash
# Recurse over a repo / folder
skills/bpm/scripts/validate_python.sh path/to/repo

# One or more files
skills/bpm/scripts/validate_python.sh path/to/script.py another.py

# Strict: warnings count as errors
skills/bpm/scripts/validate_python.sh --strict path/

# Override the fallback interpreter (used when a shebang's interpreter is missing)
skills/bpm/scripts/validate_python.sh --python /opt/venv/bin/python3 path/

# Keep the __pycache__ dirs (default: cleaned up at the end)
skills/bpm/scripts/validate_python.sh --keep-cache path/
```

### What gets validated, what gets skipped

For each `.py` file the validator looks at the sibling `<file>.py.config` (if any) and the file's first line:

| Source signal | Decision |
|---|---|
| `.config` declares `lang: "Shell"` + a `python3`-flavoured shebang | **CPython** — compile with the shebang's interpreter |
| `.config` declares `lang: "Shell"` but the shebang is mistyped (e.g. `#!pyhton3`) | **error: bad-shebang** + still try to compile via fallback |
| `.config` declares `lang: "Python"` | **skip** (Jython 2.7-ish — syntax may legitimately differ) |
| No `.config`, shebang `#!python3` / `#!/usr/bin/env python3` / absolute `.../python3` | **CPython** — compile |
| No `.config`, shebang `#!python` (no `3`) | **skip** (ambiguous — BPM only honours the shebang under `lang: "Shell"`) |
| No `.config`, no shebang | **skip** (assumed Jython or non-script `.py`) |

Skipped directories: `venv/`, `.venv/`, anything called `venvs`, `.git/`, `.idea/`, `.opencode/`, `node_modules/`, `__pycache__/`, `env/`.

### Cleanup

`py_compile` writes byte-compiled output into `__pycache__/<file>.cpython-XY.pyc` next to the source. After the run the validator removes every `__pycache__/` it created (pre-existing caches in the tree are left alone). Pass `--keep-cache` to disable cleanup.

### Cross-folder imports

Scripts that import a sibling module (`from helpers import …` where `helpers.py` lives in the same folder) compile cleanly because `py_compile` only parses syntax — it does not run imports. If you need to verify imports too, run the script under its venv directly:

```bash
demo/data/files/BpmApp/venvs/venv/bin/python -c "import path.to.script"
```

That's outside the validator's scope.

### Exit codes

| Code | Meaning |
|---|---|
| `0` | No syntax errors. With `--strict`, also no warnings. |
| `1` | At least one syntax error (or bad shebang, or warning when `--strict`). |
| `2` | Invalid invocation (path does not exist, missing python3, unknown flag). |

### Output

```
✓  path/to/ok.py
⏭  path/to/jython.py  [skipped: lang: "Python" (Jython runtime)]
✗  path/to/broken.py  (/usr/bin/python3)
     ✗ [error/syntax-error]:4 SyntaxError: 'return' outside function
!  path/to/missing-venv.py  (/usr/bin/python3)
     i [info/interp-fallback] shebang '/opt/missing-venv/bin/python3' not executable on this host; using /usr/bin/python3
```

The interpreter shown in parentheses is the one actually used to compile the file.
