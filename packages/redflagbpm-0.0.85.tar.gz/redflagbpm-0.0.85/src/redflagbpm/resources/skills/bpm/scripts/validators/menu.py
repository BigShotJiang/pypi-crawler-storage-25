"""Validate Menu (MenuInfo) artifact YAML."""
from __future__ import annotations

from typing import Any

from .common import Severity, ValidationResult, check_unknown_keys
from .enums import MENU_ALL_FIELDS


def validate(body: Any, config: Any, result: ValidationResult) -> None:
    if not isinstance(body, dict):
        result.error("not-a-mapping", "Menu body must be a YAML mapping")
        return

    _validate_node(body, result, path="")


def _validate_node(node: Any, result: ValidationResult, path: str = "") -> None:
    if not isinstance(node, dict):
        result.error("menu-node-not-mapping", "menu node must be a mapping",
                     path or "root")
        return

    check_unknown_keys(result, node, MENU_ALL_FIELDS, path, Severity.WARNING)

    if node.get("separator"):
        # separator nodes don't need name/id; warn on extra meaningful fields.
        for unexpected in ("name", "icon", "items", "target"):
            if unexpected in node and node[unexpected]:
                result.info(
                    "separator-extra-field",
                    f"separator entry has {unexpected!r}; the field will be ignored",
                    f"{path}.{unexpected}" if path else unexpected,
                )
        return

    if not node.get("id"):
        result.warning("menu-missing-id",
                       "menu node missing 'id' (recommended; "
                       "without id, sub-artifacts cannot reference it via properties.menus)",
                       f"{path}.id" if path else "id")
    if not node.get("name"):
        result.warning("menu-missing-name",
                       "menu node missing 'name' (recommended; node will appear blank)",
                       f"{path}.name" if path else "name")

    items = node.get("items")
    if items is not None:
        if not isinstance(items, list):
            result.error("menu-items-not-list",
                         "items must be a list",
                         f"{path}.items" if path else "items")
        else:
            for i, child in enumerate(items):
                child_path = (f"{path}.items[{i}]"
                              if path else f"items[{i}]")
                _validate_node(child, result, child_path)
