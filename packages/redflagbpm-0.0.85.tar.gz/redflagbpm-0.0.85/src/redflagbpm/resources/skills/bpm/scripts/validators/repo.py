"""Validate RepoDTO YAML/JSON for Coder repos."""
from __future__ import annotations

from typing import Any

from .common import Severity, ValidationResult, check_regex, check_required_fields
from .enums import (
    GIT_SSH_URL_RE,
    MODEL_FQ_RE,
    REPO_ALL_FIELDS,
    REPO_REQUIRED_FIELDS,
)
from .sandbox import validate as validate_sandbox


_BAD_DEFAULT_MODEL = "google/gemini-2.5-flash"


def validate(body: Any, config: Any, result: ValidationResult) -> None:
    if not isinstance(body, dict):
        result.error("not-a-mapping", "Repo body must be a YAML mapping")
        return

    check_required_fields(result, body, REPO_REQUIRED_FIELDS)

    # Unknown fields are noteworthy
    extra = set(body.keys()) - REPO_ALL_FIELDS
    for k in sorted(extra):
        result.warning(
            "repo-unknown-field",
            f"unknown field {k!r}", k,
        )

    # url shape
    url = body.get("url")
    if url:
        check_regex(result, url, GIT_SSH_URL_RE, "bad-repo-url",
                    "url", Severity.ERROR)
        if isinstance(url, str) and (url.startswith("http://")
                                     or url.startswith("https://")):
            result.error(
                "repo-https-not-supported",
                "HTTPS URLs are not supported; use SSH (git@...)",
                "url",
            )

    # model FQ
    model = body.get("model")
    if model:
        check_regex(result, model, MODEL_FQ_RE, "bad-model-fq",
                    "model", Severity.WARNING)
        if model == _BAD_DEFAULT_MODEL:
            result.warning(
                "model-known-regression",
                f"{_BAD_DEFAULT_MODEL!r} has a known regression with toolsets >=5 — "
                "prefer 'google/gemini-flash-latest' or any OpenAI/Anthropic model",
                "model",
            )

    # opencodeConfig agent.<name>.{instructions,systemPrompt} silently ignored
    oc = body.get("opencodeConfig") or {}
    if isinstance(oc, dict):
        agent_block = oc.get("agent")
        if isinstance(agent_block, dict):
            for agent_name, agent_cfg in agent_block.items():
                if not isinstance(agent_cfg, dict):
                    continue
                for bad in ("instructions", "systemPrompt"):
                    if bad in agent_cfg:
                        result.warning(
                            "opencode-bad-prompt-key",
                            f"opencodeConfig.agent.{agent_name}.{bad} is silently "
                            "ignored by opencode — use 'prompt' instead",
                            f"opencodeConfig.agent.{agent_name}.{bad}",
                        )
        instr = oc.get("instructions")
        if instr is not None and not isinstance(instr, list):
            result.error(
                "opencode-instructions-not-list",
                "opencodeConfig.instructions must be an array of file paths, "
                "not inline text",
                "opencodeConfig.instructions",
            )

    # sandbox: delegate
    sandbox = body.get("sandbox")
    if isinstance(sandbox, dict) and sandbox:
        sub = ValidationResult(file=result.file, artifact_type="sandbox")
        validate_sandbox(sandbox, None, sub)
        for issue in sub.issues:
            issue.path = f"sandbox.{issue.path}" if issue.path else "sandbox"
            result.issues.append(issue)
