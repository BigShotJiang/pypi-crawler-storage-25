"""Validate Prompt (PromptDTO) artifact YAML."""
from __future__ import annotations

from typing import Any

from .common import Severity, ValidationResult, check_unknown_keys
from .enums import (
    ARTIFACT_ID_RE,
    PROMPT_ALL_FIELDS,
    PROMPT_CONTENT_FIELDS,
    WORKFLOW_TYPES,
)


def validate(body: Any, config: Any, result: ValidationResult) -> None:
    if not isinstance(body, dict):
        # Could be a shebang-style prompt — accept silently
        return

    _validate_prompt_dto(body, result, path="", inherited_agent=None)


def _validate_prompt_dto(prompt: Any, result: ValidationResult,
                         path: str = "",
                         inherited_agent: Any = None) -> None:
    if not isinstance(prompt, dict):
        result.error("not-a-mapping",
                     "PromptDTO must be a mapping", path or "root")
        return

    check_unknown_keys(result, prompt, PROMPT_ALL_FIELDS, path,
                       Severity.WARNING)

    workflow = prompt.get("workflow")
    sub_agents = prompt.get("subAgents")
    agent = prompt.get("agent")

    if workflow:
        if workflow not in WORKFLOW_TYPES:
            result.error(
                "bad-workflow-type",
                f"workflow {workflow!r} not in {sorted(WORKFLOW_TYPES)}",
                f"{path}.workflow" if path else "workflow",
            )
        if not isinstance(sub_agents, list) or not sub_agents:
            result.error(
                "workflow-missing-sub-agents",
                f"workflow {workflow!r} requires non-empty subAgents",
                f"{path}.subAgents" if path else "subAgents",
            )

        # Workflow-specific config checks
        wc = prompt.get("workflowConfig") or {}
        if workflow == "loop":
            if not wc.get("maxIterations") and not wc.get("exitCondition"):
                result.warning(
                    "loop-no-bound",
                    "loop has neither maxIterations nor exitCondition — "
                    "may run forever",
                    f"{path}.workflowConfig" if path else "workflowConfig",
                )
        elif workflow == "conditional" and isinstance(sub_agents, list):
            for i, sub in enumerate(sub_agents):
                if isinstance(sub, dict):
                    sw = sub.get("workflowConfig") or {}
                    if "condition" not in sw:
                        result.error(
                            "conditional-missing-condition",
                            "every sub-agent in a conditional workflow needs "
                            "workflowConfig.condition",
                            f"{path}.subAgents[{i}].workflowConfig.condition"
                            if path else f"subAgents[{i}].workflowConfig.condition",
                        )

    else:
        # Single-agent prompt — agent may be inherited from parent
        effective_agent = agent or inherited_agent
        if not effective_agent:
            result.error("missing-agent",
                         "single-agent prompt requires 'agent' (or an inherited "
                         "default from a parent workflow)",
                         f"{path}.agent" if path else "agent")
        if not prompt.get("prompt"):
            result.error("missing-prompt",
                         "'prompt' field is required",
                         f"{path}.prompt" if path else "prompt")

    # agent reference shape
    if agent and not ARTIFACT_ID_RE.match(str(agent)):
        result.warning(
            "bad-agent-id",
            f"agent {agent!r} should match PROJECT/AGENT_ID",
            f"{path}.agent" if path else "agent",
        )

    # Mutually exclusive content fields
    set_content = [f for f in PROMPT_CONTENT_FIELDS if prompt.get(f)]
    if len(set_content) > 1 and "content" in set_content:
        # 'content' is just the resource list; contentPrompt/Agent/Variable
        # complement it. Only warn when contentPrompt and contentAgent both set
        # without a contentVariable, which is unusual.
        pass
    if prompt.get("contentPrompt") and not prompt.get("content"):
        result.info(
            "content-prompt-without-content",
            "contentPrompt is set but content is empty — "
            "the prompt will run on the input only",
            f"{path}.contentPrompt" if path else "contentPrompt",
        )

    # Schema validity
    schema = prompt.get("schema")
    if schema is not None and schema != {}:
        if not isinstance(schema, dict):
            result.error("schema-not-mapping",
                         "schema must be a JSON Schema object",
                         f"{path}.schema" if path else "schema")

    # Recurse into subAgents, passing the effective default agent down.
    if isinstance(sub_agents, list):
        # Default agent for children: this prompt's agent if any,
        # otherwise the one inherited from the grandparent.
        child_default = agent or inherited_agent
        for i, sub in enumerate(sub_agents):
            sub_path = (f"{path}.subAgents[{i}]" if path
                        else f"subAgents[{i}]")
            if isinstance(sub, dict):
                _validate_prompt_dto(sub, result, sub_path,
                                     inherited_agent=child_default)
