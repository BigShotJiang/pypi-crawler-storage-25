# Forms

Forms render a JSON Schema as an interactive UI. The renderer (`StringJsonField` and siblings under `dev/redflag/vaadinui/forms/`) walks the schema tree and instantiates Vaadin fields driven by `type`, `format`, `enum` and a custom `hints` block.

There are two places where this same JSON-Schema-with-hints dialect appears:

1. **Form artifacts** (`type: Form`): a stand-alone configurable form (commonly the input UI of a user task or a manual trigger). Requires a sibling `.config` file (see `references/artifacts-and-config.md`).
2. **`inputSchema` blocks**: embedded inside Service / Script / Tool artifacts to declare the parameters the caller must provide. The renderer used at design time / for parameter prompting is the same.

Anything documented below applies to both unless explicitly noted.

> Cross-refs: `references/value-providers.md` (dropdown sources), `references/services.md` and `references/scripts-and-tools.md` (where `inputSchema` lives), `references/artifacts-and-config.md` (the `.config` companion).

---

## Recipe — create a Form (or `inputSchema`)

In order. Don't skip the validator.

1. **Decide where it goes**: stand-alone `type: Form` artifact, or embedded as `inputSchema:` inside a Service / Script / Tool. The shape is identical; only the wrapper differs.
2. **Author the schema body** as YAML — `type: object`, `properties: { … }`, `required: […]`. Use `hints:` for renderer extensions (`fieldOrder`, `valueProvider`, `multiline`, etc.).
3. **For a stand-alone Form**, create the `.config`:
   ```yaml
   project: "MYPROJ"
   id: "MYPROJ/FORM_FOO"
   lang: "YAML"
   type: "Form"
   description: "…"
   properties: null
   ```
4. **Validate**:
   ```bash
   "$BPM_SKILL_DIR/scripts/validate.py" --strict path/to/FORM_FOO.yaml.config
   ```
   For embedded `inputSchema`, the parent artifact's validator runs the form schema check transitively.
5. **Smoke-test**: trigger the parent Service / Script and verify the form renders + binds correctly.

---

## Top-level shape

A Form artifact is a JSON Schema document written in YAML. The root must be an object schema:

```yaml
type: object
title: "New customer"
required: [name, email]
properties:
  name:
    type: string
    title: "Name"
  email:
    type: string
    title: "Email"
    format: email
hints:
  callToAction: "Create"
  fieldOrder: [name, email]
```

For an embedded `inputSchema` only the `properties` / `required` / `hints` payload matters; the wrapper service supplies the rest.

### Form-level `hints`

| Hint                | Type                | Effect |
|---------------------|--------------------|--------|
| `callToAction`      | string             | Label of the submit button. |
| `fieldOrder`        | string[]           | Render order of top-level fields. Anything not listed is appended. |
| `clearOnSubmit`     | boolean            | Reset the form after a successful submit. |
| `defaults`          | script (`#!python3`) | Run once on open to seed `bpm.context.input`. |
| `formDisposition`   | enum               | Layout strategy (single column, grid, …). |
| `feedback`          | array of actions   | Extra buttons (try/except/if/else blocks). |

---

## Field-level `hints`

`hints` lives **inside a property**, not at root. Below are the hints honoured by the renderer (see `dev/redflag/vaadinui/forms/StringJsonField.java:53-191` and the related `*JsonField` classes):

| Hint                  | Type                  | Notes |
|-----------------------|----------------------|-------|
| `subtype`             | string                | Picks the widget. See the closed list below. |
| `valueProvider`       | string                | `people`, `groups`, `projects` or a Query ID. See `references/value-providers.md`. |
| `valueProviderInputs` | object                | Map of inputs forwarded to the query. |
| `callToAction`        | string                | Used on action-style fields (e.g. buttons inside the form). |
| `multiline`           | boolean               | Hint to use a textarea-like widget for short text. |
| `readOnly`            | boolean               | Disables editing (`HINT_READ_ONLY`). |
| `visible`             | boolean (default true)| Hide the field (`HINT_VISIBLE`). |
| `rows`                | integer               | Visible rows for multi-line / code editors. |
| `colspan`             | integer               | Columns the field spans in the grid layout. |
| `rowStart` / `rowEnd` | boolean               | Force a layout break before/after the field. |
| `dependents`          | string[]              | Field names re-evaluated when this one changes. |
| `defaults` / `validation` / `feedback` | script  | Python snippets, see "Scripts in fields". |
| `resourcePath`        | string                | Target folder for `subtype: upload`. Supports `{UUID}` placeholder. |
| `acceptedFileTypes`   | string                | MIME / extension filter for uploads (e.g. `image/*,application/pdf`). |
| `multiple`            | boolean               | Multi-file upload. |
| `dropLabel`           | string                | Custom label inside the upload drop zone. |
| `display`             | `"grid"`              | For `type: array`, render as table instead of a list of subforms. |
| `selectOnly`          | boolean               | In array-as-grid, allow only row selection. |
| `titlePlural`         | string                | Plural caption for array fields. |
| `wrap`                | boolean               | Soft-wrap inside code editors (auto-true for `text` / `markdown`). |
| `value`               | string                | For `subtype: expression`, the VTL template that produces the rendered HTML/text. |

`hints` is a free-form JSON object: unknown keys are silently ignored, so typos do not error — they just fail to apply. Cross-check against the table when a field "doesn't react".

---

## `subtype` values

The set of subtypes is partly closed (hard-coded branches in `StringJsonField.init()`) and partly dynamic (anything `AceMode.valueOf(subtype)` accepts becomes a syntax-highlighted code editor).

### Static subtypes (decorative / structural)

- `headline-with-line` — H2 underlined, takes its text from `title`.
- `headline` — Plain H2.
- `horizontal-line` — `<hr>` separator.
- `spacer` — Vertical gap (`var(--lumo-space-tall-xl)`).
- `expression` — Read-only computed value. Renders the `hints.value` template (typically `#!vtl`); auto-detects HTML when the result starts with `<` and ends with `>`.
- `hyperlink` — `<a target="_blank">` whose text is `title` and href is the `default`.

### Static subtypes (input)

- `upload` — File uploader (Vaadin `UploadField`). Honours `resourcePath` (required), `multiple`, `acceptedFileTypes`, `dropLabel`.
- `password` — Masked input. Equivalent to `format: password`.
- `text` — Code editor in plain-text mode (soft-wrap on by default).
- `markdown` — Code editor with Markdown highlighting (soft-wrap on).
- `multi-line-text` — Vaadin `TextArea`. Equivalent to `format: text`.
- `rich` — Quill rich text editor. Equivalent to `format: rich`.

### Dynamic subtypes (code editors via `AceMode`)

Anything resolvable by `AceMode.valueOf(subtype)` (`dev/redflag/vaadinui/ui/ace/AceMode.java`) is rendered as an Ace editor. Confirmed-common values:

`yaml`, `json`, `sql`, `python`, `javascript`, `typescript`, `java`, `xml`, `html`, `css`, `sh`, `groovy`, `ruby`, `go`, `rust`, `dockerfile`, `properties`, `ini`, `toml`.

If a subtype string does not match a static branch and is not a valid `AceMode`, the renderer throws `IllegalArgumentException` at form open time. Keep to the lists above.

> Implicit subtypes via `format`: `email` → `EmailField`, `password` → `PasswordField`, `text` → `TextArea`, `rich` → `QuillEditor`. You can use `format` instead of `hints.subtype` for these.

---

## Field types

Forms accept the standard JSON Schema primitive types. The widget chosen depends on `type` + `subtype`/`format`:

- **`string`** — Default `TextField`. Modified by `subtype`, `format`, `enum` (renders a select), `valueProvider` (renders a remote-backed combo).
- **`integer`** — Numeric input, integer step.
- **`number`** — Numeric input, decimal step.
- **`boolean`** — Checkbox / toggle.
- **`array`** — A repeating block. With `items.type: object` it is a list of subforms; add `hints.display: grid` (on `items.hints`) for a table editor.
- **`object`** — A nested fieldset. Use to group fields under a common key.

Use `enum` for fixed choice lists; combine with `enumNames` (or `@SchemaEnumOfString` from Java) when the displayed text differs from the stored value.

---

## Validation

Validation comes from three layers:

1. **Schema constraints**:
   - `required: [field, …]` at the schema level (do not put `required: true` on the property; use the array on its parent).
   - `pattern` (regex), `minLength`, `maxLength` for strings.
   - `minimum`, `maximum`, `exclusiveMinimum`, `exclusiveMaximum`, `multipleOf` for numerics.
   - `minItems`, `maxItems`, `uniqueItems` for arrays.
2. **`format`**:
   - `date`, `datetime`, `time` — date pickers.
   - `email`, `password`, `text`, `rich` — see widget mapping above.
   - `uri` — URL syntax check.
3. **Custom Python**: `hints.validation` runs against `bpm.context.input` and raises (or `bpm.fail(...)`) to surface a message:

   ```yaml
   hints:
     validation: |
       #!python3
       import redflagbpm
       bpm = redflagbpm.BPMService()
       price = bpm.context.input.get('price')
       if price is None or price <= 0:
           raise '[[[Price must be greater than 0]]]'
   ```

Validation messages support i18n keys; literal strings are passed through.

---

## Layout

Forms render as a responsive grid. Layout knobs:

- **`hints.colspan`** — Make a field span N columns.
- **`hints.rowStart` / `hints.rowEnd`** — Force the field to begin a new row, or be the last in its row.
- **`hints.fieldOrder`** (form- or array-item level) — Explicit ordering. Anything missing is appended in declaration order.
- **`hints.formDisposition`** — Form-level layout flavour.
- **Headlines & rules** — Use `headline`, `headline-with-line`, `horizontal-line`, `spacer` as layout-only fields (`type: string`, no value).

Row grouping example:

```yaml
properties:
  first_name:
    type: string
    title: First name
    hints: { colspan: 2, rowStart: true }
  last_name:
    type: string
    title: Last name
    hints: { colspan: 2, rowEnd: true }
  notes:
    type: string
    title: Notes
    hints: { subtype: multi-line-text, colspan: 4 }
```

---

## Scripts in fields

Three hint slots accept Python snippets (always shebang `#!python3`):

- **`defaults`** — Runs on open to pre-fill `bpm.context.input`.
- **`validation`** — Runs on submit / change; raise to block.
- **`feedback`** — Array of actions exposed as buttons. Each action supports `try`, `except`, `if`, `else`. Useful for "Calculate", "Lookup", etc., that mutate the form state without submitting.

Snippets share the standard `redflagbpm.BPMService()` API. See `references/scripts-and-tools.md`.

---

## Examples

### 1. Minimal form

```yaml
type: object
title: "Create ticket"
required: [title]
properties:
  title:
    type: string
    title: "Title"
  priority:
    type: string
    title: "Priority"
    enum: [low, medium, high]
    default: medium
hints:
  callToAction: "Create ticket"
```

### 2. Form with a value provider

```yaml
type: object
required: [customer]
properties:
  customer:
    type: string
    title: "Customer"
    hints:
      valueProvider: HLW/VP_CUSTOMERS
      dependents: [summary]
  summary:
    type: string
    title: "Summary"
    hints:
      subtype: expression
      value: |
        #!vtl
        <b>Selected customer:</b> $!{customer}
```

### 3. Array of objects rendered as a table

```yaml
type: object
properties:
  operations:
    type: array
    title: "Operations"
    items:
      type: object
      title: "Operation"
      properties:
        kind:
          type: string
          title: "Kind"
          enum: [BUY, SELL]
        price:
          type: number
          title: "Price"
        qty:
          type: integer
          title: "Quantity"
      hints:
        display: grid
        fieldOrder: [kind, price, qty]
        titlePlural: Operations
```

### 4. File upload

```yaml
type: object
properties:
  receipt:
    type: string
    title: "Receipt"
    hints:
      subtype: upload
      resourcePath: "uploads/receipts/{UUID}"
      acceptedFileTypes: "application/pdf,image/*"
      multiple: false
      dropLabel: "Drop the receipt here"
```

The stored value is the resource path (or array of paths if `multiple: true`).

### 5. End-to-end Form artifact

`forms/new-customer.yaml`:

```yaml
type: object
title: "New customer"
required: [name, email, vat_status]
properties:
  header:
    type: string
    title: "Customer information"
    hints: { subtype: headline-with-line, colspan: 4 }

  name:
    type: string
    title: "Name"
    hints: { colspan: 2, rowStart: true }

  email:
    type: string
    title: "Email"
    format: email
    hints: { colspan: 2, rowEnd: true }

  vat_status:
    type: string
    title: "VAT status"
    hints:
      valueProvider: HLW/VP_VAT_STATUS
      colspan: 2

  notes:
    type: string
    title: "Notes"
    hints: { subtype: multi-line-text, colspan: 4 }

hints:
  callToAction: "Create"
  fieldOrder: [header, name, email, vat_status, notes]
  defaults: |
    #!python3
    import redflagbpm
    bpm = redflagbpm.BPMService()
    bpm.context.input.setdefault("vat_status", "RI")
```

`forms/new-customer.yaml.config` (sibling, see `references/artifacts-and-config.md`):

```yaml
project: "HLW"
id: "HLW/FORM_NEW_CUSTOMER"
type: "Form"
lang: "YAML"
```

---

## Common gotchas

- **Missing `.config`**: Form artifacts without a sibling `.config` will not be picked up by the engine. Always pair them.
- **`required` placement**: Use `required: [field]` on the parent object schema, never `required: true` on the property itself — JSON Schema ignores it.
- **`hints` typos are silent**: Misspelt hints are dropped. Cross-check the tables above when a hint "does nothing".
- **Unknown `subtype`**: A `subtype` that is neither in the static list nor a valid `AceMode` throws at open time (`IllegalArgumentException` from `AceMode.valueOf`).
- **`expression` is not editable**: `subtype: expression` binds via `ReadOnlyHasValue` and is removed from the submitted payload — never use it for inputs.
- **`upload` requires `resourcePath`**: Without it the field will NPE at construction. Use `{UUID}` to scope uploads per form instance.
- **`format: email` adds a validator**: Even if `required: false`, an invalid email blocks submit.
- **Code editors override placeholder/title**: For `subtype` in the AceMode set, the title becomes the placeholder, not a floating label. Use a preceding `headline` field if you need a visible caption.
- **`fieldOrder` must list raw property names**: Names with hyphens / dots break the YAML key match — keep them snake_case.
- **`enum` + `valueProvider` conflict**: Pick one; `enum` wins on the renderer side and you lose the dynamic source.
- **Default values for dates**: `default: "today"` is a renderer convention for date fields; for numerics use a literal (e.g. `default: 0`).

---

## Validation summary

`validators/form.py` checks:

- The document parses as YAML and the root is `type: object`.
- Every `required` entry references a key that exists in `properties`.
- Every property declares a `type` (or a `$ref`).
- `enum` values are scalars compatible with the declared `type`.
- `hints.subtype`, when present on a string property, is in the static set (`FORM_SUBTYPES_STATIC`) or in the common Ace subset (`FORM_SUBTYPES_ACE_COMMON`); other values get a warning ("verify it is a valid AceMode").
- `hints.valueProvider` references either a built-in (`people`, `groups`, `projects`) or a valid `PROJECT/ARTIFACT_ID`.
- `hints.resourcePath` is set whenever `subtype: upload` is used.
- `format` values are within the supported set (`date`, `datetime`, `time`, `email`, `password`, `text`, `rich`, `uri`).
- Inline scripts (`defaults`, `validation`, `feedback[*].try/except/if/else`) start with a recognised shebang (`#!python3` / `#!vtl`).
- Array items declare their own `type` (and `properties` when `type: object`).
- `fieldOrder` entries reference defined properties.
- For Form artifacts, a sibling `.config` exists and declares `type: Form`.

---

## Related references

- `references/value-providers.md` — Building dropdown sources used by `hints.valueProvider`.
- `references/services.md` — Where `inputSchema` shows up on services.
- `references/scripts-and-tools.md` — Scripts and Tools that also embed `inputSchema` and accept the same Python snippet conventions.
- `references/artifacts-and-config.md` — The `.config` companion required by every Form artifact.

---

### Source pointers

- `dev/redflag/vaadinui/forms/StringJsonField.java` (lines 53-191) — closed set of static subtypes and the `AceMode` dispatch.
- `dev/redflag/vaadinui/ui/ace/AceMode.java` — full list of dynamic code-editor subtypes.
- `doc/BPM_Developer_Guide.md` (lines 3410-3606) — narrative reference for hints and examples.
