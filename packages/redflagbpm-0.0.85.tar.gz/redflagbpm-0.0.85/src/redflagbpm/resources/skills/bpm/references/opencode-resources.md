# opencode resource kinds — guía para autores BPM

Esta página describe **qué tipos de artefactos opencode soporta** (agents, skills, commands, modes, plugins, tools, themes), cómo declararlos como autor de un `AnalystInfo` o un `RepoDTO`, y qué de cada kind es funcional dentro del **BPM Coder y Analyst** (que corren opencode en modo ACP, no TUI).

> Cross-refs: `references/analyst.md` para los campos del `AnalystInfo` y la convención del sibling resource dir; `references/coder.md` para `RepoDTO.opencodeConfig` y el layout `.opencode/` del repo; `references/sandbox.md` para volúmenes y `./` paths.

---

## ACP vs TUI — la diferencia que importa

opencode tiene dos modos de uso:

- **TUI** (`opencode` standalone en una terminal): el usuario tipea slash-commands (`/clear`, `/share`, `/connect`), tiene mode picker, agent picker, theme picker — todo dentro de la terminal.
- **ACP** (Agent Client Protocol, lo que usa BPM Coder y Analyst): opencode arranca como `opencode acp` y expone JSON-RPC; un cliente externo (BPM) envía `session/prompt` con texto crudo del user y recibe `session/update` con la respuesta. **No hay TUI; los slash-commands del TUI no aplican**.

Implicancia práctica: si declarás `commands` o `modes` en tu Analyst/Repo, BPM los lista en sus pickers propios; los slash-commands históricos del TUI (`/clear`, `/share`, etc.) no funcionan, BPM tiene equivalentes propios (botón "reiniciar chat", etc.).

La columna "Usable en BPM" en cada tabla abajo indica qué realmente sirve.

---

## Layout en disco — flat preferido

opencode espera los recursos como **archivos `.md` flat** dentro del kind dir, NO en subdirs. Si ponés un mode/agent/command como `<kind>/<name>/<name>.md` (subdir), opencode lo lista como id `<name>/<name>` (con slash literal) y queda invisible en los pickers.

| Layout | opencode lo ve como | Funciona |
|---|---|---|
| `agents/reviewer.md` | `reviewer` | ✅ |
| `agents/reviewer/reviewer.md` | `reviewer/reviewer` | ❌ (id raro, invisible) |
| `skills/sql-conventions/SKILL.md` | `sql-conventions` | ✅ (skills es la excepción — usa subdir + `SKILL.md`) |
| `commands/review.md` | `review` | ✅ |
| `modes/refactor.md` | `refactor` | ✅ |

**Regla práctica**:
- **Skills**: `skills/<name>/SKILL.md` (con `SKILL.md` literal, en un subdir nombrado — porque las skills suelen tener archivos auxiliares al lado).
- **Resto** (agents, commands, modes, plugins, themes, tools): `<kind>/<name>.md` flat.

---

## Resource kinds al vuelo

| Kind | Layout | Usable en BPM | Sección |
|---|---|---|---|
| **agents** | `agents/<name>.md` | ✅ Sí — `@<name>` en el prompt + autocomplete en el mention picker | [agents](#agents) |
| **skills** | `skills/<name>/SKILL.md` | ✅ Sí — referencia por nombre desde un agent prompt o `instructions:` | [skills](#skills) |
| **commands** | `commands/<name>.md` | ✅ Sí — slash-picker + expansión de `$ARGUMENTS`/`$1..$9`/`!\`bash\``/`@file` | [commands](#commands) |
| **modes** | `modes/<name>.md` | ✅ Sí — mode picker (botón con ContextMenu en el Coder y Analyst) | [modes](#modes) |
| **plugins** | `plugins/<name>/<name>.ts` | ⚠️ Cargado pero comparte namespace con el plugin BPM `bundle.js` — evitar | [plugins](#plugins) |
| **tools** | `tools/<name>.ts` | ❌ Bloqueado — BPM enforce native tools off; tools custom van vía MCP | [tools](#tools) |
| **themes** | `themes/<name>.json` | ❌ TUI-only, ignorado en ACP | [themes](#themes) |

---

## Cómo le doy recursos a un Analyst (producción)

Tres caminos, ordenados por simplicidad:

### Camino 1 — Inline en `AnalystInfo.opencodeConfig` (recomendado para casos chicos)

Los agentes y modes se pueden declarar inline en el campo `opencodeConfig` del propio YAML del `AnalystInfo`. Sin filesystem extra. Producción-friendly: el AnalystInfo es una `CodeDTO` en DB, todo viaja con él.

```yaml
# AnalystInfo YAML
id: sales-reporter
name: Sales Reporter
model: anthropic/claude-sonnet-4-5

instructions: |
  Sos el reporter de ventas. Para gráficos, delegá a @chart-builder.

opencodeConfig:
  agent:
    chart-builder:                      # subagent inline — se invoca con @chart-builder
      mode: subagent
      model: anthropic/claude-haiku-4-5
      prompt: |
        Sos un experto en visualización. Recibís datos y devolvés código matplotlib.
      permission:
        bash: allow
        edit: deny
        write: deny
```

Limitaciones del inline: no soporta bodies multi-archivo (skills no son inline), no soporta ejecución `!\`bash\`` (commands sí pueden tenerlos como string, pero la expansión client-side de BPM solo aplica a templates leídos del filesystem).

### Camino 2 — Sibling resource dir (recomendado para Analysts complejos)

Si el `AnalystInfo` está cargado desde filesystem (su YAML vive en disco con un `analyst.sourcePath` set), BPM busca un dir hermano con el mismo stem y materializa todos los kinds que encuentre adentro.

```
analystinfo/
  sales-reporter.yaml          ← el AnalystInfo
  sales-reporter/              ← sibling resource dir (mismo stem que el .yaml)
    agents/
      chart-builder.md         ← subagent
      data-validator.md        ← otro subagent
    skills/
      excel-export/
        SKILL.md               ← skill (subdir + filename literal)
        templates/             ← archivos auxiliares disponibles a la skill
          report.docx
    commands/
      report.md                ← /report ... slash-command
    modes/
      strict.md                ← mode primary alternativo
    resources/                 ← assets bind-mounteables (ver sandbox.md)
      logo.png
      template.docx
```

Cuando se abre un chat con este Analyst, BPM symlinkea cada subdir canónico al `OPENCODE_CONFIG_DIR` del chat y opencode los autodescubre.

### Camino 3 — Mezcla de ambos

Inline para lo simple, sibling dir para lo que requiere bodies grandes o helpers. La merge la hace BPM al spawn — primero el opencodeConfig inline, después el sibling dir (este último gana en collisions de nombre).

### Cómo se lo doy a un Repo (Coder context)

Si la audiencia de producción usa el Coder sobre un repo, el repo puede traer un `.opencode/` checkeado al root:

```
<repo-root>/
  .opencode/
    agents/
      reviewer.md
    skills/
      sql-conventions/
        SKILL.md
    commands/
      deploy-staging.md
    modes/
      refactor.md
```

Cualquiera que abra el Coder sobre ese repo levanta esos artefactos automáticamente.

---

## agents

Subagentes (callable como tool con `@<name>`) y primary agents (modos top-level alternativos al `build` default).

### Frontmatter completo

```markdown
---
description: "Code reviewer specialized for SQL migrations"
mode: subagent              # primary | subagent | all
model: anthropic/claude-haiku-4-5    # opcional, override
prompt: |
  Sos un code reviewer enfocado en migrations SQL.
  Antes de aprobar:
  - Verificá que el rollback exista.
  - Que las columnas nuevas tengan default si NOT NULL.
temperature: 0.2
top_p: 0.95
permission:                 # fine-grained tool gating
  bash: deny
  read: allow
  edit: deny
color: secondary            # primary | secondary | accent | warning | success | hex
steps: 20                   # max iteraciones agentic antes de respuesta final
hidden: false               # si true, no aparece en autocomplete @
disable: false              # kill switch
bpmIcon: SEARCH             # convención BPM (opcional, ver más abajo)
bpmCaption: Code reviewer   # convención BPM (opcional)
---

(El cuerpo del .md también se concatena al system prompt, después del `prompt` field.)
```

| Campo | Tipo | Significado |
|---|---|---|
| `description` | string | Texto que el primary lee al decidir si delegar. Crítico para la calidad del routing. |
| `mode` | `primary` \| `subagent` \| `all` | `subagent` = callable como tool. `primary` = modo top-level. `all` = ambos. |
| `model` | `provider/model` | Override del modelo. Permite que un subagent barato (Haiku) atienda tareas mecánicas mientras el primary usa Sonnet. |
| `prompt` | string | System prompt del agent. Para subagentes, REEMPLAZA cualquier inherited prompt. |
| `temperature`, `top_p` | number | Sampling. |
| `permission` | object | Per-tool overrides (`allow` / `deny` / `ask`). Útil para subagentes restringidos. |
| `color` | string | Color del label en logs y, en TUI, en la UI. En BPM se ignora visualmente pero no rompe. |
| `steps` | number | Cap del loop agentic — útil para subagentes "one-shot" (steps: 1-3). |
| `hidden`, `disable` | boolean | Self-explicativos. |
| `bpmIcon`, `bpmCaption` | string | Convenciones BPM (ver § "Convenciones BPM"). |

### Invocación

- **Desde el user**: `@reviewer revisá este commit` en el textarea. opencode parsea el `@` server-side y dispatcha al subagent.
- **Desde otro agent**: el primary, vía la "Task tool" interna de opencode, invoca al subagent con un prompt y recibe el resultado como tool output. Pasa por default cuando el primary decide delegar (no hace falta `@` explícito; el primary route por `description`).

### Mention picker en BPM

Al tipear `@`, el picker lista en este orden, con tags + iconos:

| Posición | Tag | Tipo | Icono default | Override |
|---|---|---|---|---|
| 1 | `[Subagent]` | mode `subagent`/`all`/null | `BOLT` ⚡ | `bpmIcon` del agent .md |
| 2 | `[Primary]` | mode `primary` | `STAR` ★ | `bpmIcon` del agent .md |
| 3 | (sin tag) | files del workspace | `FILE_O` / `FOLDER` | — |

Filtrá tipeando: `@rev` muestra `@reviewer` y `@reviews/foo.txt` si ambos existen. La diferenciación al envío usa una heurística: si el `@<algo>` no tiene slash ni extensión `.<ext>`, se preserva literal y opencode lo procesa como subagent mention. Si tiene `/` o `.<ext>` y el archivo existe en el workspace, se reemplaza con su contenido (ver § commands → `@<path>`).

### Cuándo declarar un subagent

- Tareas repetitivas con un prompt firme (chart-builder, migration-reviewer, doc-writer).
- Casos donde un modelo más barato/rápido alcanza (subagent con `model: anthropic/claude-haiku-4-5`).
- Aislar permisos: un subagent que SOLO puede leer o SOLO puede escribir, manteniendo el primary como router.

---

## skills

Bundles de conocimiento que el agent carga por nombre. Pensar en ellos como "documentación inline" que opencode inyecta al contexto cuando un agent las referencia.

### Layout

```
skills/sql-conventions/
  SKILL.md             ← punto de entrada (frontmatter opcional + body)
  examples/            ← archivos auxiliares accesibles desde SKILL.md
    good-migration.sql
    bad-migration.sql
```

El frontmatter del SKILL.md típicamente incluye `description` (cuándo usar la skill); el body es la guía/checklist/conventions que el agent debe seguir.

```markdown
---
description: SQL migration conventions del proyecto
bpmIcon: DATABASE
bpmCaption: Migrations SQL
---

Reglas de migrations en este proyecto:
1. Cada migration tiene rollback en `down.sql`.
2. Columnas nuevas NOT NULL requieren `default`.
3. ...
```

### Cómo se "activa"

Las skills no se invocan con un comando especial; se referencian por nombre:

- Desde el `prompt:` de un agent (`Para SQL, seguí la skill 'sql-conventions'`).
- Desde el `instructions:` de tu `opencodeConfig`.
- Desde el campo top-level `instructions` del `AnalystInfo` (que BPM materializa al `instructions:` de opencode).

opencode también puede matchear automáticamente skills por description vs tarea actual — por eso la `description` es importante.

### Cuándo escribir una skill vs incluir en `agent.prompt`

| Caso | Dónde |
|---|---|
| Reglas de estilo / conventions de un dominio (SQL, Python, naming) | skill (puede crecer; reutilizable cross-agent) |
| Persona / tono general del agent | `prompt` del agent |
| Glosario corto (5-10 términos) | `prompt` del agent |
| Procedimiento paso-a-paso firme (cómo hacer X) | skill |

---

## commands

Plantillas de prompt invocables como `/<name> arg1 arg2`. El archivo `.md` define la plantilla y los argumentos.

### Frontmatter

```markdown
---
template: |              # opcional — si no, el body del .md es el template
  Hacé deploy a staging del branch $1. Antes:
  - Corré tests con `!npm test` y abortá si hay fallas.
  - Revisá @CHANGELOG.md y avisá si hay breaking changes.
description: Deploy del branch indicado a staging
agent: deployer          # opcional — qué agent intenta el command (informativo)
model: openai/gpt-4o     # opcional — informativo
subtask: true            # opcional — informativo
bpmIcon: ROCKET          # convención BPM
bpmCaption: Deploy
---
```

Si el frontmatter no declara `template:`, el body completo del `.md` (después del frontmatter) se usa como template.

### Variables del template (expansión client-side)

| Variable | Comportamiento |
|---|---|
| `$ARGUMENTS` | Reemplazada por todos los args como un solo string (`args.join(" ")`) |
| `$1`, `$2`, …, `$9` | Args posicionales separados por whitespace; ausente → string vacío |
| `` !`comando` `` | Stdout del comando ejecutado en el **sandbox** del chat. Timeout 30s por sub. Si exit≠0, se inyecta `[bash exit=N] stdout err=stderr` para que el LLM vea el contexto. |
| `@<path>` | Contenido del archivo bajo el workspace, fenced con la extensión como hint de syntax (`` ```md ``, `` ```py ``, etc.). Trailing whitespace stripped. **Solo se trata como path** si `<path>` contiene `/` o termina en `.<ext>` (3-10 chars alfanuméricos). |

### Frontmatter fields informativos vs accionables

| Field | Comportamiento en BPM |
|---|---|
| `template:` | ✅ Honored. Si está, gana sobre el body. |
| `description:` | ✅ Mostrado en el slash picker. |
| `agent:`, `model:`, `subtask:` | ⚠️ **Informativos** — la sesión sigue con el primary y modelo actuales. Para forzar dispatch a un subagent, incluí `@<agentname>` en el body de la template; opencode lo parsea server-side. |
| `bpmIcon`, `bpmCaption` | ✅ Honored por BPM (no por opencode). |

### Disambiguación `@file` vs `@agent`

`@<name>` se interpreta como path SOLO si parece un path:

- `@docs/spec.md` → file mention, expandido a contenido fenced (tiene slash).
- `@README.md` → file mention (tiene extensión).
- `@reviewer` → bareword, queda literal y opencode lo procesa como invocación de subagent.
- `@reviewer123` → bareword, preservado.
- `@a/b/c` → file mention (tiene slash), pero si `a/b/c` no existe en el workspace queda literal.

Esto significa que **podés mezclar libremente**: `Pedile a @reviewer que mire @docs/spec.md` resuelve ambos correctamente.

### Tags y iconos en el slash picker

Cada item del slash picker lleva un **tag entre corchetes al inicio de la descripción** que indica su origen:

| Tag | Origen | Icono default | Override |
|---|---|---|---|
| `[BPM]` | Commands MCP del lado servidor (publicados por opencode en `availableCommands`) | `TERMINAL` ⌨ | — |
| `[Command]` | Commands declarados en `commands/<n>.md`, template-only | `MAGIC` ✨ | `bpmIcon` del frontmatter |
| `[Command → @<agent>]` | Commands con frontmatter `agent:` o `subtask: true` (hint de routing intencional) | `BOLT` ⚡ | `bpmIcon` del frontmatter |
| `[Skill]` | `AnalystInfo.prompts` (templates Mustache `{{vars}}` per-Analyst) | `LIGHTBULB` 💡 | — |

Filtrá tipeando: `/rev` muestra cualquier `/review*`. El tag te dice de dónde viene cada item.

### Ejemplo end-to-end

`commands/spec.md`:

```markdown
---
description: Especifica una feature usando branch + diff + last commit
bpmIcon: PENCIL
bpmCaption: Especificar
---
Estamos en branch `!`git branch --show-current`` con el siguiente diff sin commitear:

!`git diff --stat`

El último commit relevante:

!`git log -1 --format="%H %s%n%n%b"`

Convenciones del repo: @AGENTS.md

Ahora especificá la feature: $ARGUMENTS

Output: un .md en `specs/` siguiendo la plantilla del repo.
```

Cuando el user manda `/spec login con OAuth`:

1. `$ARGUMENTS` → `login con OAuth`.
2. Cada `` !`...` `` se ejecuta en el sandbox del chat. El stdout reemplaza el bloque.
3. `@AGENTS.md` se reemplaza con el contenido del archivo (fenced).
4. El LLM recibe un prompt completo: branch + diff + commit + conventions + tarea — sin que el user copy-paste nada.

El history del chat muestra solo `/spec login con OAuth` (limpio).

---

## modes

Primary agents alternativos. Cambian la persona top-level del agent. Se eligen desde el **mode picker** del Coder y Analyst — un botón con ContextMenu que lista todos los `availableModes` que opencode publica tras `session/new`. El click dispara un mode switch server-side; los próximos turns usan el mode nuevo (system prompt, permission overrides, modelo, sampling).

### Frontmatter

Mismo modelo que un `agent` con `mode: primary`. De hecho `modes/<n>.md` y `agents/<n>.md` con `mode: primary` son intercambiables conceptualmente.

```markdown
---
mode: primary
description: Read-only code review mode — no edits, no shell.
permission:
  edit: deny
  write: deny
  bash: ask
temperature: 0.1
bpmIcon: SEARCH
bpmCaption: Revisar
---

Estás en review mode. Tu rol es revisar código y devolver hallazgos estructurados.
NO modificás archivos. ...
```

### Modes built-in (siempre disponibles)

Cualquier chat trae estos dos modes que opencode publica como defaults:

- `build` (caption por default: "Normal", icono `CLUSTER`) — comportamiento estándar, edit libre.
- `plan` (caption por default: "Planificar", icono `LIST_OL`) — read-mostly, plan-first.

Cualquier mode adicional que declares en tu Analyst sibling dir o repo `.opencode/modes/` se suma al picker.

---

## Convenciones BPM en el frontmatter (`bpmIcon`, `bpmCaption`)

opencode ignora keys desconocidas del frontmatter, así que BPM aprovecha eso para inyectar overrides UI-only sin romper el spec del recurso. Las dos keys que BPM mira:

| Key | Tipo | Para qué |
|---|---|---|
| `bpmIcon` | string (nombre de VaadinIcon) | Override del icono en el picker correspondiente |
| `bpmCaption` | string | Override del display name (ej. "Planificar" en lugar de "plan") |

**Aplican a todos los kinds**: `agents/<n>.md`, `commands/<n>.md`, `modes/<n>.md`, `skills/<n>/SKILL.md`. Para `commands` el caption se usa en el slash picker; para `agents` en el mention picker; para `modes` en el mode picker; para `skills` cuando se surfacean en UI.

### Resolución del icono (mode picker)

1. `bpmIcon: <NAME>` → `VaadinIcon.<NAME>` (case-insensitive). Si el name no resuelve, fallback al siguiente paso.
2. Defaults por id: `build` → `CLUSTER`, `plan` → `LIST_OL`.
3. Fallback genérico: `BOLT`.

### Resolución del caption (mode picker)

1. `bpmCaption: <texto>` → ese texto.
2. Aliases hardcoded para built-ins: `build` → `Normal`, `plan` → `Planificar`.
3. Fallback: el `name` que opencode publica.

### Catálogo recomendado de iconos

Vaadin tiene cientos; estos son los que mejor representan use cases típicos:

| Use case | bpmIcon |
|---|---|
| Build / edit libre | `TOOLS`, `CLUSTER` |
| Plan / read-mostly | `LIST_OL` |
| Review / hallazgos | `SEARCH`, `EYE` |
| Explain / solo prosa | `BOOK`, `INFO_CIRCLE` |
| Refactor / multi-file | `MAGIC` |
| Migration / DB | `DATABASE` |
| Testing | `CHECK_CIRCLE` |
| Security audit | `LOCK`, `SHIELD` |
| Deploy | `ROCKET`, `CLOUD_UPLOAD` |
| Data viz | `CHART` |
| Debug / smoke | `BUG` |
| Genérico custom | `BOLT` (default) |

Si `<NAME>` no existe, BPM usa el default sin fallar.

---

## Inline shell `!cmd` (estilo Claude Code)

Independiente de los slash-commands y de la expansión `!\`bash\`` adentro de templates, BPM Coder y Analyst soportan un **modo shell inline**: cualquier mensaje del user que arranca con `!` se trata como comando shell directo.

### Comportamiento

1. User tipea en el textarea: `!git status -s`.
2. Al enviar, BPM detecta el prefijo `!` (ignora `!\`...\`` que es expansión interna de templates).
3. El comando se ejecuta en el **sandbox del chat** (mismo runner que `bpm_bash`), 60s de timeout.
4. El history del chat muestra el output como bloque tipo terminal (prompt `$ cmd` + stdout en monospace, fenced).
5. **No se manda al LLM** — el `!cmd` es local, sin gastar tokens.
6. **Pero** el output queda **bufferado** y se incluye como preamble en el próximo mensaje real que el user mande al LLM. Ejemplo:
   ```
   !git status -s
   !git diff --stat
   ¿qué deberíamos commitear primero?
   ```
   El LLM recibe en el último turn un preamble con los outputs concatenados + la pregunta. El buffer se vacía después del envío.

### Activación

- **Coder**: siempre disponible (audiencia dev por definición).
- **Analyst**: gated por el field `inlineShellEnabled: true` del `AnalystInfo`. Default `false` porque la audiencia del Analyst es no-técnica. Activá solo cuando el sandbox está hardenizado y el user es capaz de usarlo con criterio. Ver `references/analyst.md` § "`inlineShellEnabled`".

### Caveats

- **No es shell interactivo**. Cada `!cmd` es one-shot — `cd`, `export`, etc. no persisten entre llamadas. Encadená en un solo `!cd /workspace/foo && do-thing`.
- **60s timeout duro**. Para comandos lentos, dividilos.
- **Diferencia con `!\`bash\`` en templates**: la versión template (`!\`comando\``) corre cuando el LLM va a recibir el prompt expandido (parte del context engineering del slash command). La versión inline (`!cmd`) corre on-demand por iniciativa del user; nunca se mete adentro de un template.

---

## plugins

Plugins TypeScript/JavaScript que extienden opencode con tools custom, hooks, integraciones.

### Caveat en BPM

⚠️ **BPM ya inyecta su propio plugin** que define los `bpm_*` tools (`bpm_bash`, `bpm_read`, etc.) y maneja el flow ACP. Plugins repo-side se cargan también, pero comparten namespace y orden de hooks. Si necesitás un tool custom, **declaralo como `McpInfo`** (ver `references/coder.md` § "McpInfo schema reference") — es la ruta cubierta, gated por permisos, y observable.

---

## tools

❌ **BPM enforce que los native tools de opencode (`bash`, `read`, `write`, `edit`, `glob`, `grep`) están OFF** — las invariantes los desactivan post-merge para forzar el uso del plugin BPM (que aplica sandbox, logging, permission checks). Los tools custom de `tools/` siguen el mismo path: opencode los registra, pero el invariant los apaga.

**Para sumar un tool custom al Coder/Analyst, usar `McpInfo`** con el `properties.tool` declarado en un `CodeDTO`. Ver `references/scripts-and-tools.md` § "MCP tools" y `references/coder.md` § "McpInfo schema reference".

---

## themes

❌ **TUI-only**. En ACP no hay UI de opencode — la UI la pinta Vaadin del lado BPM. Cualquier theme que declares se carga pero nunca se renderiza. Equivalente a no tenerlo.

---

## Mini-receta: Analyst con sibling resource dir

Layout end-to-end de un Analyst con primary tuneado + subagent + skill + assets bind-mounteados:

```
analystinfo/
  sales-reporter.yaml          ← AnalystInfo
  sales-reporter/              ← sibling resource dir (mismo stem)
    agents/
      chart-builder.md         ← mode: subagent, prompt: "render charts via matplotlib"
    skills/
      excel-export/
        SKILL.md               ← cómo exportar XLSX según conventions corporativos
    commands/
      report.md                ← /report ... slash-command
    resources/                 ← bind-mount via ./resources:/workspace/assets:ro
      template.docx
      logo.png
```

YAML del Analyst:

```yaml
id: sales-reporter
name: Sales Reporter
model: anthropic/claude-sonnet-4-5
inlineShellEnabled: false      # default — no shell directo para el user

instructions: |
  Sos el reporter de ventas. Reglas:
  - Para gráficos, delegá a @chart-builder.
  - Antes de exportar Excel, leé skill 'excel-export'.
  - Assets en /workspace/assets (logo, plantilla).

opencodeConfig:
  agent:
    build:
      temperature: 0.2
      tools:
        bpm_write: false        # primary NO escribe; chart-builder sí

sandbox:
  image: bpm/analyst-python-ds:1.4
  service:
    volumes:
      - "./resources:/workspace/assets:ro"
```

### Lo que pasa al spawn

1. BPM detecta el sibling resource dir y lo materializa al chat: agents, skills, commands, modes simlinkeados al `OPENCODE_CONFIG_DIR`.
2. El `./resources` del volume se expande contra el sibling dir y se monta read-only en `/workspace/assets`.
3. opencode arranca con la config combinada. Descubre `chart-builder` como subagent (vía sibling dir + lo que hubiera en `opencodeConfig.agent` inline) y `excel-export` como skill.
4. El primary (build) consulta `excel-export` cuando matchea por description, llama `@chart-builder` para los charts, redacta el .docx copiando `/workspace/assets/template.docx`.

### Si no podés usar sibling dir (Analyst en DB sin filesystem source)

Mismo Analyst expresado todo inline:

```yaml
opencodeConfig:
  agent:
    chart-builder:
      mode: subagent
      model: anthropic/claude-haiku-4-5
      prompt: |
        Sos un experto en visualización con matplotlib. Recibís datos y devolvés
        el código Python que genera el chart pedido. Output: solo el código,
        sin explicación. ...
      permission:
        bash: allow
        edit: deny
        write: deny
```

Trade-off: las skills (que necesitan archivo + helpers) no se pueden expresar inline. Si tu Analyst depende de skills, considerá publicarlo desde filesystem o internalizar el contenido de la skill en el `instructions:` del Analyst.

---

## Verificar qué cargó

El mode picker, mention picker y slash picker del chat te muestran exactamente qué descubrió opencode. Si esperás un kind y no aparece:

1. **Estructura plural** del subdir (`agents/`, no `agent/`).
2. **Layout flat** para agents/commands/modes/plugins/themes/tools — `<kind>/<name>.md`, NO `<kind>/<name>/<name>.md`. Skills es la excepción: `skills/<name>/SKILL.md`.
3. **Frontmatter válido**: `---` apertura y cierre en líneas propias, YAML correcto adentro.
4. Si declarás un mode con `mode: primary` esperando que aparezca como subagent: revisá — `subagent` y `primary` son mutuamente excluyentes salvo que pongas `mode: all`.

Para un dispatch de subagent que no sucede:
- El primary route por `description` del subagent. Si la `description` es vaga o ausente, el primary no sabe cuándo delegar.
- `@<name>` explícito en el body de un command o en el textarea fuerza el dispatch.
