# `schemas/` — JSON Schemas auto-generados

Schemas formales de los DTOs Java de cada artifact type. Complementan la
documentación narrativa de `references/` con una **spec estructural** — útil
cuando el agente necesita confirmar nombres exactos de campos, tipos, o el
orden canónico de autoría.

> Regla: la markdown narrativa tiene los gotchas, recipes y ejemplos. Estos
> JSON tienen la verdad estructural. Si discrepan, **el JSON gana** (se
> regenera del DTO Java en cada build).

## Cómo se generan

```bash
# Desde la raíz del repo bpmapp
mvn -q exec:java \
    -Dexec.mainClass=dev.redflag.bpm.tools.SkillSchemaGenerator \
    -Dexec.classpathScope=runtime
```

El generador (`src/main/java/dev/redflag/bpm/tools/SkillSchemaGenerator.java`)
recorre los DTOs listados en su mapa `TARGETS` y emite un archivo
`<type>.schema.json` por cada uno. Es idempotente — re-correrlo regenera
todo y el diff queda visible en git.

## Qué cubre cada schema

| Archivo | DTO Java | Cobertura |
|---|---|---|
| `agent.schema.json`   | `dev.redflag.core.services.info.AgentInfo`   | Body YAML del Agent. |
| `analyst.schema.json` | `dev.redflag.core.services.info.AnalystInfo` | Body YAML del Analyst. |
| `query.schema.json`   | `dev.redflag.core.services.info.QueryInfo`   | Body YAML de un Query — incluye `$ref`s a sub-DTOs (FilterGroupInfo, ColumnInfo, etc.) en `definitions/`. |
| `service.schema.json` | `dev.redflag.bpm.dto.ServiceInfo`            | Body YAML de un Service. |
| `form.schema.json`    | `dev.redflag.core.services.info.FormInfo`    | Body de un Form / `inputSchema`. |
| `menu.schema.json`    | `dev.redflag.bpm.dto.MenuInfo`               | Body YAML de un Menu (recursivo via `$ref`). |
| `mcp.schema.json`     | `dev.redflag.core.services.info.McpInfo`     | Body YAML de un Mcp (perfil de tools). |
| `repo.schema.json`    | `dev.redflag.bpm.dto.RepoDTO`                | Config de un repo del Coder. |

Para agregar tipos nuevos (Page, Report, Collection, Kanban, ValueProvider),
una línea más en el mapa `TARGETS` del generator y re-correr.

## Limitaciones conocidas

- **No marca `required:`** — los DTOs todavía no tienen `@JsonProperty(required=true)`. Por eso la cara estructural acepta YAMLs sin `name`/`provider`/`model`. Los validators de `scripts/validators/` siguen catcheando esos casos.
- **No extrae enums** — `provider` y `model` salen como `string` libre porque la implementación los acepta así. Las listas conocidas viven en `validators/enums.py` y en las tablas de `references/`.
- **`properties: JsonObject` sale con un sub-objeto `{map: {object}}`** por la representación interna de Vert.x. Es ruido cosmético; el agente puede ignorarlo. Para limpiarlo se necesita un custom mapping en `dev.redflag.core.json.schema.CoreModule`.

Estas limitaciones se pueden ir cerrando incrementalmente sobre el mismo
generator. Lo importante: el shape básico (qué campos existen, qué tipo, en
qué orden) ya está y se mantiene solo.
