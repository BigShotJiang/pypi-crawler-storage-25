#!/usr/bin/env python3
"""CLI entrypoint for BPM artifact validation.

Usage:
    python validate.py path/to/artifact.yml
    python validate.py --type query path/to/artifact.yml
    python validate.py --strict --json path/to/artifact.yml

Exit codes:
    0 — no errors (warnings allowed, unless --strict)
    1 — at least one error (or warning when --strict)
    2 — invalid invocation
"""
from __future__ import annotations

import argparse
import importlib
import json
import sys
from pathlib import Path

# Make `validators` importable when invoked as `python skills/bpm/scripts/validate.py`
sys.path.insert(0, str(Path(__file__).resolve().parent))

from validators.common import (
    ValidationResult,
    detect_artifact_type,
    load_artifact_pair,
)

VALIDATOR_MODULES = {
    "config_file":    "validators.config_file",
    "query":          "validators.query",
    "form":           "validators.form",
    "service":        "validators.service",
    "agent":          "validators.agent",
    "prompt":         "validators.prompt",
    "kanban":         "validators.kanban",
    "value_provider": "validators.value_provider",
    "menu":           "validators.menu",
    "repo":           "validators.repo",
    "analyst":        "validators.analyst",
    "mcp":            "validators.mcp",
    "sandbox":        "validators.sandbox",
}


def _format_human(result: ValidationResult) -> str:
    lines = [f"{result.file}  [{result.artifact_type}]"]
    if not result.issues:
        lines.append("  ✓ ok")
        return "\n".join(lines)
    for issue in result.issues:
        sym = {"error": "✗", "warning": "!", "info": "i"}[issue.severity.value]
        path = f" @ {issue.path}" if issue.path else ""
        lines.append(f"  {sym} [{issue.severity.value}/{issue.code}] {issue.message}{path}")
    err = len(result.errors)
    warn = len(result.warnings)
    info = len(result.issues) - err - warn
    lines.append(f"  → {err} error(s), {warn} warning(s), {info} info")
    return "\n".join(lines)


def validate_path(path: Path, explicit_type: str | None) -> ValidationResult:
    body, config = load_artifact_pair(path)
    artifact_type = detect_artifact_type(body, config, explicit_type)
    result = ValidationResult(file=str(path), artifact_type=artifact_type)

    module_name = VALIDATOR_MODULES.get(artifact_type)
    if module_name is None:
        result.error("unknown-type", f"no validator for type {artifact_type!r}")
        return result

    try:
        module = importlib.import_module(module_name)
    except ImportError as e:
        result.error("validator-import-error", f"could not import {module_name}: {e}")
        return result

    if not hasattr(module, "validate"):
        result.error(
            "validator-missing-validate",
            f"module {module_name} has no `validate(body, config, result)` function",
        )
        return result

    module.validate(body, config, result)
    return result


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Validate BPM artifact files.")
    ap.add_argument("paths", nargs="+", type=Path, help="Files to validate.")
    ap.add_argument(
        "--type",
        dest="explicit_type",
        choices=sorted(VALIDATOR_MODULES.keys()),
        help="Force a validator (otherwise auto-detected).",
    )
    ap.add_argument(
        "--strict",
        action="store_true",
        help="Treat warnings as errors for the exit code.",
    )
    ap.add_argument(
        "--json",
        action="store_true",
        help="Emit JSON output instead of human-readable text.",
    )
    args = ap.parse_args(argv)

    results: list[ValidationResult] = []
    for path in args.paths:
        if not path.exists():
            r = ValidationResult(file=str(path), artifact_type="unknown")
            r.error("file-not-found", f"path does not exist: {path}")
            results.append(r)
            continue
        results.append(validate_path(path, args.explicit_type))

    if args.json:
        print(json.dumps([r.to_dict() for r in results], indent=2))
    else:
        for r in results:
            print(_format_human(r))
            print()

    has_errors = any(not r.is_ok for r in results)
    has_warns = any(r.warnings for r in results)
    if has_errors or (args.strict and has_warns):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
