"""Enums and value sets used to validate BPM artifact YAML/JSON files.

Single source of truth for closed value sets across all validators.

Each constant cites its source-of-truth Java class with `# source:`.
The Java code under `src/main/java/` always wins over markdown docs in
`doc/` — if you find a discrepancy, update the Java reference and refresh
this file.
"""
from __future__ import annotations

import re

# ---------------------------------------------------------------------------
# .config files: artifact `type` and `lang`
# source: src/main/java/dev/redflag/bpm/dto/CodeDTO.java:24-49
# ---------------------------------------------------------------------------

ARTIFACT_TYPES = frozenset({
    "Agent",
    "Mcp",
    "Analyst",
    "Script",
    "Form",
    "Page",
    "Public endpoint",
    "User endpoint",
    "Web service endpoint",
    "Query",
    "Service",
    "Collection",
    "Report",
    "Menu",
})
"""Closed set: CodeDTO TYPE_* constants. Used as `type:` in .config files."""

# Subset selectable from the UI (CodeDTO @SchemaEnumOfString annotation excludes JUEL).
ARTIFACT_TYPES_UI_SELECTABLE = frozenset({
    "Script", "Form", "Public endpoint", "User endpoint", "Web service endpoint",
    "Query", "Service", "Collection", "Report", "Page", "Menu",
    "Agent", "Mcp", "Analyst",
})

LANGS = frozenset({
    "JavaScript",
    "Python",
    "Velocity",
    "JSON",
    "YAML",
    "JUEL",
    "Vertx",
    "Shell",
    "Prompt",
    "Markdown",
    "Binary",
})
"""Closed set: CodeDTO JS/PY/VTL/JSON/YAML/JUEL/VERTX/SHELL/PROMPT/MARKDOWN/BINARY."""

# Subset visible in the .config UI dropdown — JUEL is omitted from the
# @SchemaEnumOfString annotation (CodeDTO.java:66) although the constant exists.
LANGS_UI_SELECTABLE = frozenset({
    "JavaScript", "Python", "Velocity", "JSON", "YAML",
    "Vertx", "Shell", "Markdown", "Prompt", "Binary",
})

# Coherence: which langs are typically expected by which type.
# Used as a soft hint (warning, not error). Empty set means "any lang allowed".
TYPE_LANG_COHERENCE: dict[str, frozenset[str]] = {
    "Query":               frozenset({"YAML", "JSON"}),
    "Service":             frozenset({"YAML", "JSON"}),
    "Form":                frozenset({"YAML", "JSON"}),
    "Collection":          frozenset({"YAML", "JSON"}),
    "Menu":                frozenset({"YAML", "JSON"}),
    "Agent":               frozenset({"YAML", "JSON"}),
    "Mcp":                 frozenset({"YAML", "JSON"}),
    "Analyst":             frozenset({"YAML", "JSON"}),
    "Report":              frozenset({"Binary"}),
    "Page":                frozenset({"Velocity", "Python", "JavaScript", "Shell", "Binary", "Markdown"}),
    "Script":              frozenset({"Python", "JavaScript", "Shell", "YAML", "JSON", "Vertx", "JUEL", "Velocity", "Prompt"}),
    "Public endpoint":     frozenset({"Python", "JavaScript", "Shell", "Vertx", "JUEL"}),
    "User endpoint":       frozenset({"Python", "JavaScript", "Shell", "Vertx", "JUEL"}),
    "Web service endpoint":frozenset({"Python", "JavaScript", "Shell", "Vertx", "JUEL"}),
}

# ---------------------------------------------------------------------------
# Action artifact (Script-as-action / row actions)
# source: src/main/java/dev/redflag/core/services/ipo/Action.java:14-35
# ---------------------------------------------------------------------------

ACTION_TYPES = frozenset({
    "create", "update", "delete", "query", "display", "call", "open",
})
"""Action.TYPE_* constants. Default in code is "call"."""

ACTION_DISPLAY_HINTS = frozenset({
    "default", "main", "confirm",
    "small", "medium", "large", "x-large",
    "refresh-on-close",
})
"""Action.HINT_* constants."""

# Action.SELECTION_SCOPE_* constants. Note: code declares 0/-1/-2/-3/-4
# AND the default field value is 1 (single selection) — so 1 is also valid.
ACTION_SELECTION_SCOPES = frozenset({0, 1, -1, -2, -3, -4})
ACTION_SELECTION_SCOPE_LABELS = {
    0: "NONE",
    1: "SINGLE (default)",
    -1: "ANY",
    -2: "MANY",
    -3: "GROUP",
    -4: "FILTER",
}

# ---------------------------------------------------------------------------
# Service responseType
# source: src/main/java/dev/redflag/core/services/ipo/IPOResponseType.java:3-5
# (used at runtime for the IPO/response envelope; ServiceInfo.java:26-32 has
#  the configurator-facing constants — note ASSET_DISPLAY, NOT "DISPLAY")
# ---------------------------------------------------------------------------

IPO_RESPONSE_TYPES = frozenset({
    "TERMINAL", "TERMINAL_UPDATE", "TERMINAL_DELETE", "TERMINAL_CREATE",
    "ERROR", "MESSAGE", "AGENT", "QUERY", "IPO", "CUBE", "REPORT", "ASSET",
    "OPEN", "OPEN_UPDATE", "OPEN_NEW", "OPEN_NEW_UPDATE",
})

# Configurator-facing values that ServiceInfo exposes as constants.
# source: src/main/java/dev/redflag/bpm/dto/ServiceInfo.java:26-32
SERVICE_RESPONSE_TYPES = frozenset({
    "QUERY", "ASSET", "DISPLAY", "SERVICE", "TERMINAL", "MESSAGE", "REPORT",
})
"""Subset commonly written by configurators in service YAML.
Note ServiceInfo.ASSET_DISPLAY = "DISPLAY" — not "ASSET_DISPLAY"."""

# Response types that REQUIRE responseTarget (artifact reference like PROJECT/ID)
SERVICE_RESPONSE_TYPES_REQUIRING_TARGET = frozenset({
    "QUERY", "REPORT", "SERVICE",
})

# ---------------------------------------------------------------------------
# Workflow types in agentic prompts (PromptDTO.workflow)
# source: src/main/java/dev/redflag/bpm/impl/ai/WorkflowBuilder.java:64-78
# ---------------------------------------------------------------------------

WORKFLOW_TYPES = frozenset({
    "sequence", "parallel", "loop", "conditional", "supervisor",
})

# ---------------------------------------------------------------------------
# Form field hint `subtype`
# source: src/main/java/dev/redflag/vaadinui/forms/StringJsonField.java:53-191
# Plus AceMode dynamic enum:
# source: src/main/java/dev/redflag/vaadinui/ui/ace/AceMode.java:7-16
# ---------------------------------------------------------------------------

# Static subtypes recognised explicitly in StringJsonField
# plus widely-used widget hints handled by sibling field classes (date/number).
FORM_SUBTYPES_STATIC = frozenset({
    # StringJsonField static branches
    "headline-with-line", "headline", "horizontal-line", "spacer",
    "expression", "hyperlink", "upload", "password",
    "text", "markdown", "multi-line-text", "rich",
    # Convention observed in real artifacts (handled by Date/Integer/Number fields
    # via format-equivalent code paths)
    "date", "datetime", "time", "number",
})

# Dynamic subtypes resolved via AceMode.valueOf(): any code-editor language.
# Subset most commonly used in BPM artifacts (YAML, JSON, SQL, Python, etc.).
# Full enum has ~120 values; we ship the common ones and let validators emit
# `info` (not `warning`) on uncommon-but-valid AceMode values.
FORM_SUBTYPES_ACE_COMMON = frozenset({
    "yaml", "json", "sql", "python", "javascript", "typescript", "java",
    "xml", "html", "css", "sh", "groovy", "ruby", "go", "rust",
    "dockerfile", "properties", "ini", "toml",
})

# Full superset of accepted subtypes. If a value is not here, validators
# emit a soft warning ("not in known subtypes — verify it's a valid AceMode").
FORM_SUBTYPES = FORM_SUBTYPES_STATIC | FORM_SUBTYPES_ACE_COMMON

# ---------------------------------------------------------------------------
# Query column / filter typing
# source: BPM_Developer_Guide.md (no closed enum in code; ColumnInfo accepts free strings)
# ---------------------------------------------------------------------------

COLUMN_FIELD_TYPES = frozenset({
    "string", "integer", "decimal", "number",
    "date", "datetime", "boolean", "null",
})

COLUMN_ALIGN = frozenset({"CENTER", "START", "END"})

# Width: par de campos en ColumnInfo.java — `Integer width` (magnitud) +
# `String widthType` (unidad). El widthType es opcional (default = flex weight).
COLUMN_WIDTH_TYPES = frozenset({"px", "em", "rem", "%", "flex"})

# ---------------------------------------------------------------------------
# Vaadin GridVariant for `themeVariants`
# Usage in code: QueryGrid delegates to GridVariant.valueOf(String)
# Lista canónica de Vaadin Flow 24.x:
# ---------------------------------------------------------------------------

GRID_VARIANTS = frozenset({
    "LUMO_NO_BORDER",
    "LUMO_NO_ROW_BORDERS",
    "LUMO_COLUMN_BORDERS",
    "LUMO_COMPACT",
    "LUMO_ROW_STRIPES",
    "LUMO_WRAP_CELL_CONTENT",
    "MATERIAL_COLUMN_DIVIDERS",
})

# ---------------------------------------------------------------------------
# Agent providers (free-form string in code, but warning if outside known set)
# source: src/main/java/dev/redflag/core/services/info/AgentInfo.java
# ---------------------------------------------------------------------------

AGENT_PROVIDERS = frozenset({
    "OpenAI", "openai",
    "Gemini", "gemini",
    "Bedrock", "bedrock",
    "Anthropic", "anthropic",
})
"""Provider strings observed in the codebase. Case-sensitive at runtime.
Validator emits warning, not error, when value is outside this set."""

MODEL_FQ_RE = re.compile(r"^[\w-]+/[\w.\-:]+$")
"""Coder/Analyst model strings: 'providerID/modelID' (e.g. 'google/gemini-2.5-flash')."""

# ---------------------------------------------------------------------------
# Sandbox YAML (used in RepoDTO.sandbox and AnalystInfo.sandbox)
# source: doc/Sandbox_Manual.md + dev/redflag/bpm/impl/ai/acp/SandboxConfigParser
# ---------------------------------------------------------------------------

SANDBOX_TOP_LEVEL_ALLOWED = frozenset({
    "image", "build", "service", "mode",
})

SANDBOX_TOP_LEVEL_FORBIDDEN = frozenset({
    "privileged", "ports", "command", "entrypoint",
    "depends_on", "devices", "cgroup_parent",
})

# Inside `service:` (compose-like subset)
SANDBOX_SERVICE_ALLOWED = frozenset({
    "mem_limit", "cpus", "pids_limit", "read_only", "user",
    "tmpfs", "volumes", "environment", "network",
    "extra_hosts", "security_opt", "sysctls",
})

SANDBOX_SERVICE_FORBIDDEN = frozenset({
    "network_mode",  # bans `host`, but the field itself is not allowed under `service`
    "pid", "ipc", "userns_mode",
    "ports", "command", "entrypoint",
    "privileged", "depends_on", "devices",
})

SANDBOX_NETWORK_VALUES = frozenset({"bridge", "none", "agent-runtime"})

SANDBOX_PLACEHOLDERS = frozenset({
    "userId", "chatId", "analystId", "repoUrl", "repoDir",
})

SANDBOX_MODE = frozenset({"host", "docker"})

# ---------------------------------------------------------------------------
# Identifier patterns
# source: BPM_Developer_Guide.md + observed in artifacts
# ---------------------------------------------------------------------------

PROJECT_ID_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")
"""Project code: identifier (SCREAMING_SNAKE_CASE recommended, camelCase accepted)."""

ARTIFACT_ID_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*/[A-Za-z][A-Za-z0-9_]*$")
"""Full artifact identifier: PROJECT/ARTIFACT_ID. Both halves are identifiers
(letters/digits/underscores, must start with a letter). SCREAMING_SNAKE_CASE
is the recommended convention but camelCase is observed in real artifacts."""

SCRIPT_REF_RE = re.compile(r"^run:[A-Za-z][A-Za-z0-9_]*/[A-Za-z][A-Za-z0-9_]*$")
"""Script reference: run:PROJECT/SCRIPT_ID."""

ENV_VAR_REF_RE = re.compile(r"^@[A-Z][A-Z0-9_]*$")
"""Environment variable reference in YAML values: @VAR_NAME."""

REQUEST_URL_RE = re.compile(r"^(run:[A-Z][A-Z0-9_]*/[A-Z][A-Z0-9_]*|curl\s.+|https?://.+)$")
"""Service.requestUrl: run:..., curl ..., or http(s)://..."""

GIT_SSH_URL_RE = re.compile(r"^(ssh://)?git@[^:/\s]+[:/][\w./~\-]+(\.git)?$")
"""Repo URL (SSH form): git@host:path[.git] or ssh://git@host/path."""

CRON_RE = re.compile(r"^\S+(\s+\S+){4,6}$")
"""Loose cron format check: 5–7 whitespace-separated tokens."""

STRING_FORMAT_PLACEHOLDER_RE = re.compile(r"%\{[A-Za-z_][A-Za-z0-9_]*\}|%\d+\$s")
"""stringFormat placeholders: %{fieldName} or positional %1$s."""

# ---------------------------------------------------------------------------
# RepoDTO required fields
# source: src/main/java/dev/redflag/bpm/dto/RepoDTO.java (@SchemaRequired markers)
# ---------------------------------------------------------------------------

REPO_REQUIRED_FIELDS = frozenset({"url", "key", "username", "email"})
REPO_ALL_FIELDS = frozenset({
    "url", "branch", "key", "username", "email", "path",
    "processes", "description", "model", "sandbox", "opencodeConfig",
})

# ---------------------------------------------------------------------------
# AnalystInfo fields
# source: src/main/java/dev/redflag/core/services/info/AnalystInfo.java:42-101
# ---------------------------------------------------------------------------

ANALYST_ALL_FIELDS = frozenset({
    "id", "name", "description", "active", "debug",
    "targetUsers", "targetGroups",
    "model", "instructions", "bootScript",
    "tools", "confirmPolicy",
    "inlineShellEnabled", "webfetchEnabled", "websearchEnabled",
    "resources", "prompts",
    "sandbox", "opencodeConfig",
    "properties",
})
# `id` is no longer required in the body — the runtime takes the id from the
# .config sidecar. Keeping `name` required for the UI.
ANALYST_REQUIRED_FIELDS = frozenset({"name"})

# ---------------------------------------------------------------------------
# McpInfo fields
# source: src/main/java/dev/redflag/core/services/info/McpInfo.java
# ---------------------------------------------------------------------------

MCP_ALL_FIELDS = frozenset({
    "id", "name", "description",
    "profile",
    "targetUsers", "targetGroups",
    "toolList",            # ← canonical; `tools` is INVALID for McpInfo
    "confirmPolicy",
    "resources", "prompts",
    "properties",
})
MCP_REQUIRED_FIELDS = frozenset({"id", "name"})
MCP_VALID_PROFILES = frozenset({"coder", "external", "analyst"})

# Valid values for confirmPolicy on McpInfo / AnalystInfo. Lowercase only;
# null/absent means "destructive" (default).
CONFIRM_POLICY_VALUES = frozenset({"destructive", "all", "none"})

# ---------------------------------------------------------------------------
# MenuInfo fields
# source: src/main/java/dev/redflag/bpm/dto/MenuInfo.java:18-30
# ---------------------------------------------------------------------------

MENU_ALL_FIELDS = frozenset({
    "id", "parentId", "name", "icon", "theme", "target",
    "users", "groups", "items", "separator", "sort",
})

# ---------------------------------------------------------------------------
# PromptDTO fields
# source: src/main/java/dev/redflag/bpm/dto/PromptDTO.java:22-40
# ---------------------------------------------------------------------------

PROMPT_ALL_FIELDS = frozenset({
    "agent", "prompt",
    "content", "contentPrompt", "contentAgent", "contentVariable",
    "schema", "workflow", "outputKey", "subAgents", "workflowConfig",
})

# Mutually exclusive content sources (only one of these may be set).
PROMPT_CONTENT_FIELDS = frozenset({
    "content", "contentPrompt", "contentAgent", "contentVariable",
})

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def is_known_subtype(value: str) -> bool:
    """True if subtype is a documented static or common ACE mode."""
    return value in FORM_SUBTYPES


def is_artifact_id(value: str) -> bool:
    """Validate full PROJECT/ARTIFACT_ID identifier."""
    return bool(ARTIFACT_ID_RE.match(value))
