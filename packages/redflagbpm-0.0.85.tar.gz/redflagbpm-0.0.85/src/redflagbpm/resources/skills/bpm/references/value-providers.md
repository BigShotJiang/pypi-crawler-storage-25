# Value Providers

Value Providers (VPs) are special Queries used to populate dynamic dropdown lists in form fields, query filters and grid columns. A VP returns at minimum two columns — `id` (the value stored) and `caption` (the display text) — and is referenced from other artifacts via the `valueProvider` hint.

Use a VP whenever a user must pick from a list whose contents come from a database (clients, products, suppliers, statuses, countries, cities). Do **not** use a VP for fixed enums — for those use a JSON-Schema `enum` directly in the form.

> Cross-references: `references/queries.md` (a VP is a Query), `references/forms.md` (consumer of VPs in `properties.*.hints`).

---

## YAML structure

A Value Provider is a Query, so every field documented in `references/queries.md` is available. The minimum required subset is:

| Field | Required | Notes |
|---|---|---|
| `dataSource` | yes | Database connection ID (e.g. `NORTHWIND`). |
| `view` | yes | SQL `SELECT` returning at least `id` and `caption` columns (use `AS id` / `AS caption` aliases). |
| `columns` | yes | Must declare at least `id` and `caption` with `name` and `fieldType`. Add one entry per column referenced by `stringFormat`. |
| `keys` | yes | Always `[id]` for a VP. |
| `caption` | recommended | Human title shown in admin/listing screens. |
| `stringFormat` | optional | Display template (see below). Defaults to the `caption` column. |
| `viewBindings` | optional | Names of bound parameters consumed by the SQL `?` placeholders — used for filtering/searching inside the dropdown. |
| `targetGroups` / `targetUsers` | recommended | Authorization. Without these no user can resolve the VP. |
| `options.crud: false` | recommended | A VP is read-only; disable CRUD UI. |
| `exportable: false` | recommended | A VP is not a report. |

**Minimum skeleton:**

```yaml
caption: "Customer list"
dataSource: NORTHWIND
view: |
  SELECT
    customer_id AS id,
    company_name AS caption
  FROM customers
columns:
  - name: id
    caption: "Customer ID"
    fieldType: string
  - name: caption
    caption: "Name"
    fieldType: string
keys:
  - id
targetGroups:
  - INTERNAL
options:
  crud: false
exportable: false
```

---

## `stringFormat` syntax

`stringFormat` controls the text shown for each option in the dropdown. It does **not** change what is stored — the stored value is always the `id` column.

Two placeholder styles are supported:

- **Named:** `%{fieldName}` is replaced with the value of the column whose `name` matches `fieldName`.
- **Positional:** `%1$s`, `%2$s`, … (1-indexed) refers to columns in the order they appear in the `SELECT`.

```yaml
stringFormat: "%{id} - %{caption}"            # "ALFKI - Alfreds Futterkiste"
stringFormat: "%{caption} (%{contact_name})"  # "Alfreds Futterkiste (Maria Anders)"
stringFormat: "%1$s - %2$s"                   # first column - second column
```

Any column referenced from `stringFormat` must be declared in `columns:` — otherwise the placeholder is rendered literally.

---

## How a Value Provider is referenced

Reference syntax everywhere is `PROJECT/QUERY_ID`, e.g. `HLW/VP_CLIENTES`. The project prefix is required even when the consumer lives in the same project.

### From a form field (`properties.<field>.hints.valueProvider`)

The dropdown stores the VP's `id` into the form field. Field `type` should match the `id` column type (`string` for varchar IDs, `integer` for numeric IDs).

```yaml
properties:
  cliente:
    type: string
    title: "Customer"
    hints:
      valueProvider: HLW/VP_CLIENTES
      callToAction: "Pick a customer"
```

### From a query filter (`filterGroup.filters[].valueProvider`)

Inside a filter, `valueProvider` lets the user pick the filter value from a dropdown. Filter-level `stringFormat` overrides the VP's own format for this consumer.

```yaml
filterGroup:
  filters:
    - name: customer_id
      caption: "Customer"
      fieldType: string
      valueProvider: HLW/VP_CLIENTES
      stringFormat: "%{id} - %{caption}"
```

### From a grid column (`columns[].valueProvider`)

When set on a column, the VP is used to **render** the stored value as a friendly label in the grid (the column data is still whatever the main query returned).

```yaml
columns:
  - name: customer_id
    caption: "Customer ID"
    fieldType: string
    valueProvider: HLW/VP_CLIENTES
```

### Differences at a glance

| Consumer | What VP does | Stored / shown |
|---|---|---|
| Form field hint | Selector + label | Stores `id`, shows `stringFormat` while editing. |
| Filter | Selector for the filter value | Stores `id` as filter parameter. |
| Grid column | Label resolver | The grid keeps the raw value, displays the resolved `caption` / `stringFormat`. |

---

## Examples

### 1. Simple list (countries)

```yaml
caption: "Countries"
dataSource: NORTHWIND
view: |
  SELECT DISTINCT
    country AS id,
    country AS caption
  FROM customers
  WHERE country IS NOT NULL
  ORDER BY country
columns:
  - name: id
    fieldType: string
  - name: caption
    fieldType: string
keys: [id]
targetGroups: [INTERNAL]
options: { crud: false }
exportable: false
```

### 2. Dependent VP (cities filtered by country)

The dependency is implemented with `viewBindings`: each `?` placeholder in the SQL is matched, in order, with the names listed in `viewBindings`. The consuming form/filter must supply a parameter with that same name (the platform passes it in when the parent field changes).

```yaml
caption: "Cities by country"
dataSource: NORTHWIND
view: |
  SELECT DISTINCT
    city AS id,
    city AS caption
  FROM customers
  WHERE country = ?::varchar
  ORDER BY city
viewBindings:
  - country
columns:
  - name: id
    fieldType: string
  - name: caption
    fieldType: string
keys: [id]
targetGroups: [INTERNAL]
options: { crud: false }
exportable: false
```

### 3. Multi-field caption (`stringFormat`)

```yaml
caption: "Customers (with contact)"
dataSource: NORTHWIND
view: |
  SELECT
    customer_id AS id,
    company_name AS caption,
    contact_name,
    phone
  FROM customers
stringFormat: "%{id} - %{caption} (%{contact_name})"
columns:
  - name: id
    fieldType: string
  - name: caption
    fieldType: string
  - name: contact_name
    fieldType: string
  - name: phone
    fieldType: string
keys: [id]
targetGroups: [INTERNAL]
options: { crud: false }
exportable: false
```

---

## Common gotchas

- **Missing aliases.** Forgetting `AS id` / `AS caption` on the `SELECT` makes the VP unusable — column names in the result set must literally be `id` and `caption`.
- **Column not declared.** Any column used in `stringFormat` (or referenced by a consumer) must be in `columns:`. Undeclared columns are silently dropped.
- **Type mismatch on `id`.** If the database column is numeric and the form field is `type: string`, cast in SQL: `product_id::varchar AS id`. Otherwise selection round-trips fail.
- **Missing `targetGroups`.** A VP with no `targetUsers`/`targetGroups` is invisible to end users; the dropdown will appear empty.
- **`crud: true` on a VP.** Exposes a CRUD UI for what is meant to be a lookup query. Always set `options.crud: false`.
- **`stringFormat` does not change the stored value.** Only the `id` column is persisted; `stringFormat` is purely cosmetic.
- **Project prefix required.** `valueProvider: VP_CLIENTES` (no slash) does not resolve. Always use `PROJECT/VP_ID`.
- **Dependent VP without `viewBindings`.** A `?` placeholder in `view` without a matching `viewBindings` entry will fail at execution time.
- **Heavy queries.** A VP is fetched on every dropdown open. Avoid joins and large scans; index the columns used in `WHERE` / `ORDER BY`.

---

## End-to-end example

A complete VP and a form field that consumes it.

**`queries/VP_CLIENTES.yaml`**

```yaml
caption: "Customer list"
dataSource: NORTHWIND
view: |
  SELECT
    customer_id AS id,
    company_name AS caption,
    contact_name
  FROM customers
  WHERE
    ?::varchar IS NULL OR
    lower(company_name) LIKE lower('%'||?::varchar||'%') OR
    lower(contact_name) LIKE lower('%'||?::varchar||'%')
viewBindings:
  - search_term
  - search_term
  - search_term
stringFormat: "%{id} - %{caption}"
columns:
  - name: id
    caption: "Customer ID"
    fieldType: string
  - name: caption
    caption: "Company name"
    fieldType: string
  - name: contact_name
    caption: "Contact"
    fieldType: string
keys:
  - id
sortables:
  - caption
targetGroups:
  - INTERNAL
options:
  crud: false
exportable: false
```

**Consumer form field**

```yaml
properties:
  cliente:
    type: string
    title: "Customer"
    hints:
      valueProvider: HLW/VP_CLIENTES
      callToAction: "Pick a customer"
```

When the user opens the dropdown the platform fetches `HLW/VP_CLIENTES`, optionally passing the typed search text as `search_term`, and renders each row as `"ALFKI - Alfreds Futterkiste"`. On selection, the form stores `"ALFKI"` in `cliente`.

---

## Validation summary

`validators/value_provider.py` checks:

- `dataSource` points to a non-empty connection name.
- `view` is a non-empty `SELECT`. Aliases `AS id` and `AS caption` are present (case-insensitive).
- `columns` declares at least `id` and `caption`, plus every column referenced by `stringFormat`.
- `keys: [id]`.
- `targetGroups` or `targetUsers` is non-empty (warning if both empty — VP will be invisible).
- `options.crud` is `false` (warning if true).
- `exportable` is `false` or absent (warning if true).
- `stringFormat` placeholders match declared `column.name`s, or use valid `%N$s` indices (1-based, in range).
- If `view` contains `?` placeholders, `viewBindings` count equals `?` count.
- `id` column `fieldType` is consistent with consumers when cross-file mode is on.
