"""Validate Kanban-mode Query artifact YAML."""
from __future__ import annotations

from typing import Any

from .common import ValidationResult
from .query import validate as validate_query


_KANBAN_KEYS_DEFAULTS = {
    "titleField": "title",
    "bodyField": "body",
    "cardIdField": "cardId",
    "columnIdField": "columnId",
}


def validate(body: Any, config: Any, result: ValidationResult) -> None:
    if not isinstance(body, dict):
        result.error("not-a-mapping", "Kanban body must be a YAML mapping")
        return

    # Kanban is a Query with options.kanban: true — run query checks first.
    validate_query(body, config, result)

    opts = body.get("options") or {}
    if not isinstance(opts, dict):
        return

    if not opts.get("kanban"):
        result.error(
            "kanban-flag-missing",
            "options.kanban must be true for a Kanban view",
            "options.kanban",
        )

    columns = opts.get("kanbanColumns")
    if not isinstance(columns, dict) or not columns:
        result.error(
            "kanban-columns-missing",
            "options.kanbanColumns must declare at least one column",
            "options.kanbanColumns",
        )

    # Required mapping keys
    declared_columns = {c.get("name") for c in (body.get("columns") or [])
                        if isinstance(c, dict) and c.get("name")}

    for key, default in _KANBAN_KEYS_DEFAULTS.items():
        field = opts.get(key, default)
        if not isinstance(field, str):
            result.error(
                "kanban-key-not-string",
                f"options.{key} must be a string",
                f"options.{key}",
            )
            continue
        if declared_columns and field not in declared_columns:
            result.warning(
                f"kanban-{key.lower()}-not-in-columns",
                f"options.{key}={field!r} is not declared in columns",
                f"options.{key}",
            )

    # cardMovedScript reference
    cms = opts.get("cardMovedScript")
    if cms and not (isinstance(cms, str)
                    and (cms.startswith("run:") or "/" in cms)):
        result.warning(
            "kanban-bad-card-moved-script",
            f"options.cardMovedScript {cms!r} should be 'run:PROJECT/SCRIPT'",
            "options.cardMovedScript",
        )
