# Endpoints

Custom HTTP endpoints exposed by the BPM backend. Each endpoint is an artifact whose `code` is a script (Python / JavaScript / Vertx / Shell / JUEL); the BPM platform executes the script when an HTTP request hits its routed URL, makes the request available through `bpm.context`, and turns the script's stdout (or a referenced resource) into the HTTP response.

Use endpoints when you need to expose webhooks, REST APIs, HTML pages or file downloads driven by a BPM artifact — anywhere a fixed URL must trigger BPM logic.

Cross-references:
- See `references/scripts-and-tools.md` for the scripting model (`bpm.context`, languages, `BPMService`).
- See `references/artifacts-and-config.md` for `.config` requirements and artifact metadata.

## 1. Endpoint types (closed set)

The artifact `type` field selects the endpoint flavor. The platform classifies any value matching the regex `.+ endpoint` as an endpoint (`CodeDTO.isEndpoint`, `dev/redflag/bpm/dto/CodeDTO.java:249-252`). Only three values are supported:

| Type string             | Constant            | Authentication                        | Use case                                  |
|-------------------------|---------------------|---------------------------------------|-------------------------------------------|
| `Public endpoint`       | `TYPE_PUB_ENDPOINT` | None — anonymous access allowed       | Public webhooks, status checks, callbacks |
| `User endpoint`         | `TYPE_USR_ENDPOINT` | Authenticated user (session or token) | UI-adjacent APIs that act on behalf of the logged-in user |
| `Web service endpoint`  | `TYPE_WEB_ENDPOINT` | Token-based; user must hold `WS` role | System-to-system REST APIs                |

Any non-endpoint type (`Script`, `Form`, `Query`, etc.) sent through `/api/run/...` returns `401` with message "Not and endpoint" (`SimpleBPMService.run`).

### Authorization rules enforced by the platform

`SimpleBPMService.run` (`dev/redflag/bpm/impl/SimpleBPMService.java`) applies these checks before executing the script:

- `Public endpoint` — no checks. The script runs even when `x-user` is `nobody`.
- `User endpoint` — requires `x-user != "nobody"`. Otherwise `401`.
- `Web service endpoint` — requires `x-user != "nobody"` AND `x-ws-auth == "true"`. Otherwise `401`.

`x-ws-auth` is `"true"` only when the JWT presented contains the `WS` role.

## 2. URL routing

Endpoints are reached through the Spring controller `ApiRestController` (`dev/redflag/bpm/app/rest/ApiRestController.java`, base path `api`). Two routes invoke an endpoint script:

- `GET|POST|PUT|DELETE /api/run/{project}/{code}` — generic dispatcher. Body (when present) is read as JSON and merged into `bpm.context`. Method is preserved in `_requestHeaders["x-method"]`.
- `POST /api/run/{project}/{code}` with `Content-Type: multipart/form-data` is handled by `/api/post/{project}/{code}`, which downloads each uploaded file to a temp path and passes the path through `bpm.context.<fieldName>`.

Mapping rules:

- `{project}` and `{code}` together form the artifact id `<project>/<code>`.
- The platform calls `service.bpmService().run(project + "/" + code, input)`.
- There is no path templating beyond `{project}/{code}` — additional path segments are not supported. Route variability must be expressed via query parameters or request body.

### Helper endpoints (not artifacts, built into the platform)

- `GET /api/authToken?user=<u>&password=<p>` — exchanges credentials for a JWT (returns plain text token).
- `POST /api/payloadToken?token=<jwt>` with JSON body — signs the body with the supplied token and returns a new signed JWT.
- `GET /api/test` — liveness check, returns `Test worked`.
- `POST /api/taskComplete?token=<jwt>&taskId=<id>` — completes a BPM user task.

## 3. Authentication modes

The dispatcher resolves the caller in this priority order:

1. Session attribute `CURRENT_USER_SESSION_ATTRIBUTE_KEY` — set when the request comes from a logged-in browser session. The session user's `WS` authorization is also checked.
2. Query parameter `?token=<jwt>` — validated by `securityService().isValid(...)`. `WS` role checked via `securityService().hasRole(token, "WS")`.
3. `Authorization` header — accepted as raw token or with `Bearer ` prefix. Same validation as above.
4. None — `userId` is set to `"nobody"`.

The resolved values are written into `_requestHeaders` as:

- `x-user` — the JWT subject (`sub`) or session user id, or `"nobody"`.
- `x-ws-auth` — string `"true"` / `"false"`.
- `x-method` — request HTTP method.

All other incoming HTTP headers are copied verbatim into `_requestHeaders` as well.

### Token lifecycle

- Obtain: `GET /api/authToken?user=USERNAME&password=PASSWORD` returns the JWT as plain text.
- Use: pass via query (`?token=...`), `Authorization: <token>`, or `Authorization: Bearer <token>`.
- Sign data with token: `POST /api/payloadToken?token=<token>` + JSON body returns a new JWT containing that payload.
- Validation errors: `401 Unauthorized` (invalid token), `404 Not Found` (user not found at `/authToken`).

## 4. Request access via `bpm.context`

Inside the script, `bpm.context` exposes:

- **URL query parameters**: each `?k=v` becomes `bpm.context.k`. Repeated parameters become a JSON array.
- **JSON body**: when `Content-Type` parses as JSON, every top-level field is merged into `bpm.context`. Nested objects remain dicts.
- **Form fields** (`application/x-www-form-urlencoded` or `multipart/form-data` via `/api/post`): each field becomes `bpm.context.<field>`.
- **Multipart files** (via `/api/post`): each file field is replaced by the absolute path of a temp file containing the upload, or a JSON array of paths if multiple files share the field name.
- **`inputJson` parameter**: a special parameter; if present its value is parsed as JSON and merged into the context (allows packing arbitrary structure even on `GET`).
- **Headers**: `bpm.context.json._requestHeaders` — all request headers plus the synthetic `x-user`, `x-ws-auth`, `x-method`.

There is no separate `body` variable — POST body fields are accessed exactly like GET query parameters.

```python
#!python3
import redflagbpm
bpm = redflagbpm.BPMService()

# Same code works for GET ?nombre=Juan and POST {"nombre":"Juan"}
nombre = bpm.context.nombre

headers = bpm.context.json._requestHeaders
user_id = headers.get('x-user', 'anonymous')
method  = headers.get('x-method', 'GET')
ws_auth = headers.get('x-ws-auth', 'false')
```

There is no first-class "path parameter" mechanism — only `{project}` and `{code}` are recognized by the router. Pass additional identifiers via query string or JSON body.

## 5. Building the response

The response is assembled from three places:

1. **Body** — whatever the script writes to stdout (`print(...)` in Python, `console.log` in JS, etc.). The dispatcher reads the engine's writer and returns it as the response body.
2. **Status & headers** — the script writes into the special object `_responseHeaders`, accessed as `bpm.context.json._responseHeaders`. Reserved keys:
   - `status` — HTTP status code (string or integer; non-numeric characters are stripped).
   - `resource` — if set, the dispatcher streams the BPM resource at that path back to the client instead of stdout. The resource's recorded `Content-Length` is used.
   - All other keys become response headers verbatim.
3. **Errors** — if the script throws and `status` is unset, the dispatcher returns `500` with the captured stderr text as body.

```python
_responseHeaders = bpm.context.json._responseHeaders
_responseHeaders["status"] = "200"
_responseHeaders["Content-Type"] = "application/json"
_responseHeaders["Content-Encoding"] = "UTF-8"
```

Returning binary or large content via the `resource` key is the preferred way to avoid buffering an entire payload through stdout:

```python
ruta = "/tmp/report.pdf"
# ... generate file ...
_responseHeaders["resource"] = ruta
_responseHeaders["Content-Type"] = "application/pdf"
```

> Endpoints do NOT use `bpm.reply()` — that helper belongs to forms and services where execution returns structured UI directives. Endpoint output is the script's stdout plus `_responseHeaders`.

## 6. Examples

### 6.1 Public endpoint — webhook receiver

Artifact `webhooks/github` of type `Public endpoint`, language Python:

```python
#!python3
import json, redflagbpm
bpm = redflagbpm.BPMService()

event = bpm.context.json._requestHeaders.get('X-GitHub-Event', 'unknown')
payload = bpm.context  # POST body fields are top-level

# Persist or hand off to a service
bpm.execution().setVariable("last_github_event", event)

resp = {"received": True, "event": event}
print(json.dumps(resp))

h = bpm.context.json._responseHeaders
h["status"] = "200"
h["Content-Type"] = "application/json"
```

Call: `curl -X POST http://host/api/run/webhooks/github -H "X-GitHub-Event: push" -d @payload.json`.

### 6.2 User endpoint — return data for the logged-in user

Artifact `me/profile` of type `User endpoint`:

```python
#!python3
import json, redflagbpm
bpm = redflagbpm.BPMService()

user_id = bpm.context.json._requestHeaders["x-user"]  # always present here
profile = bpm.execute("crm/getProfile", {"userId": user_id})  # reuse a Service

print(json.dumps(profile))

h = bpm.context.json._responseHeaders
h["status"] = "200"
h["Content-Type"] = "application/json"
```

Call from the browser session (cookie auth): `GET /api/run/me/profile`.
Call with token: `curl -H "Authorization: Bearer $TOKEN" http://host/api/run/me/profile`.

### 6.3 Web service endpoint — REST API for a partner system

Artifact `api/orders` of type `Web service endpoint`. Caller must hold `WS` role.

```python
#!python3
import json, redflagbpm
bpm = redflagbpm.BPMService()

method = bpm.context.json._requestHeaders.get("x-method", "GET")
h = bpm.context.json._responseHeaders
h["Content-Type"] = "application/json"

if method == "GET":
    rows = bpm.execute("orders/list", {"status": bpm.context.get("status")})
    print(json.dumps(rows))
    h["status"] = "200"
elif method == "POST":
    new_id = bpm.execute("orders/create", {
        "customer": bpm.context.customer,
        "items":    bpm.context.items,
    })
    print(json.dumps({"id": new_id}))
    h["status"] = "201"
else:
    h["status"] = "405"
    print(json.dumps({"error": "method not allowed"}))
```

Caller flow:

```bash
TOKEN=$(curl -s "http://host/api/authToken?user=integrator&password=secret")
curl -X POST "http://host/api/run/api/orders" \
     -H "Authorization: Bearer $TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"customer":"ACME","items":[{"sku":"A1","qty":3}]}'
```

If the integrator user lacks the `WS` role the call returns `401` before the script runs.

## 7. End-to-end example: validate signed payload, return JSON

Use case: a partner calls `/api/run/api/secure-action`. They have already obtained a token via `/api/authToken` and signed their payload with `/api/payloadToken`. The endpoint must verify the signed payload, do the work, and return JSON.

Artifact `api/secure-action` (type `Web service endpoint`):

```python
#!python3
import json, redflagbpm
bpm = redflagbpm.BPMService()

req_h = bpm.context.json._requestHeaders
res_h = bpm.context.json._responseHeaders
res_h["Content-Type"] = "application/json"

# Hard checks: dispatcher already enforced WS, but be defensive.
if req_h.get("x-ws-auth") != "true":
    res_h["status"] = "401"
    print(json.dumps({"error": "WS role required"}))
else:
    # The signed payload arrives in the JSON body field "signedPayload"
    signed = bpm.context.get("signedPayload")
    if not signed:
        res_h["status"] = "400"
        print(json.dumps({"error": "missing signedPayload"}))
    else:
        # securityService().getPrincipal validates and returns claims
        sec = bpm.securityService()
        if not sec.isValid(signed):
            res_h["status"] = "401"
            print(json.dumps({"error": "invalid signature"}))
        else:
            claims = sec.getPrincipal(signed)        # JsonObject
            action = claims.getString("action")
            target = claims.getString("target")

            result = bpm.execute("ops/perform", {
                "action": action,
                "target": target,
                "actor":  req_h["x-user"],
            })

            res_h["status"] = "200"
            print(json.dumps({"ok": True, "result": result}))
```

Partner caller:

```bash
TOKEN=$(curl -s "http://host/api/authToken?user=partner&password=...")
SIGNED=$(curl -s -X POST "http://host/api/payloadToken?token=$TOKEN" \
              -H "Content-Type: application/json" \
              -d '{"action":"approve","target":"ORDER-42"}')
curl -X POST "http://host/api/run/api/secure-action" \
     -H "Authorization: Bearer $TOKEN" \
     -H "Content-Type: application/json" \
     -d "{\"signedPayload\":\"$SIGNED\"}"
```

## 8. Long-running endpoints — respond fast, work later

When the work takes more than a few seconds, do not block the HTTP request on it. Build the synchronous response (stdout + `_responseHeaders`), then fork the heavy work into a detached child and exit the parent. Endpoints do **not** use `bpm.reply()` (see § 5) — the response is purely the script's stdout plus the `_responseHeaders` it mutated. Pattern detail in `references/scripts-and-tools.md` § 4.3.

### 8.1 `200 OK` with partial / status snapshot

Use when the early response carries something useful the client can render right now (a status snapshot, a cached partial, the latest known counters).

`ops/rebuildIndex` (`User endpoint`, `lang: "Shell"`):

```python
#!/usr/bin/env python3
import os, sys, json
import redflagbpm
from redflagbpm.PgUtils import get_connection
bpm = redflagbpm.BPMService()

# Capture identity BEFORE forking — context is gone in the child
caller = bpm.context.json._requestHeaders.get("x-user")

with get_connection(bpm, "ops") as conn, conn.cursor() as cur:
    cur.execute("SELECT data FROM ops_status WHERE k = 'rebuild' LIMIT 1")
    row = cur.fetchone()
body = {"state": "running", "partial": row[0] if row else None}

h = bpm.context.json._responseHeaders
h["status"] = "200"
h["Content-Type"] = "application/json"
print(json.dumps(body))
sys.stdout.flush()

if os.fork() == 0:
    os.setsid()
    os.close(0); os.close(1); os.close(2)
    rebuild_index()
    if caller:
        bpm.service.notifyUser(caller, "Index rebuild OK")
```

### 8.2 `202 Accepted` with a job id

Use when the early response is purely informational and the client will poll a separate endpoint for completion. Persist a job row so the polling endpoint has something to read.

`ops/startJob` (`Web service endpoint`, `lang: "Shell"`):

```python
#!/usr/bin/env python3
import os, sys, json, uuid
import redflagbpm
bpm = redflagbpm.BPMService()

job_id = str(uuid.uuid4())
bpm.documentService.create("ops_jobs", {"id": job_id, "state": "queued"})

h = bpm.context.json._responseHeaders
h["status"] = "202"
h["Content-Type"] = "application/json"
h["Location"] = f"/api/run/ops/jobStatus?id={job_id}"
print(json.dumps({"jobId": job_id}))
sys.stdout.flush()

if os.fork() == 0:
    os.setsid()
    os.close(0); os.close(1); os.close(2)
    do_work(job_id)
```

A companion `ops/jobStatus` endpoint reads `ops_jobs` by id and returns the current `state`, `progress`, `result`. The client polls until `state == "done"`.

### 8.3 Caveats specific to endpoints

In addition to the caveats in `references/scripts-and-tools.md` § 4.3:

- **Finalize the response before forking.** `print(...)` and `_responseHeaders` mutations are read at parent-exit time. Anything written or set by the detached child is invisible to the dispatcher.
- **Flush stdout before forking.** Without `sys.stdout.flush()`, Python's buffer may still hold the response when the child closes `fd 1`. Flush in the parent first.
- **`_responseHeaders["resource"]` and detach are mutually exclusive.** Streaming a large file via `resource` requires the engine to read the file after the script ends — there is no body to "finalize before detach" in that case. Split into two endpoints if you need both.
- **Pick the right type.** A `Public endpoint` polled anonymously is fine for status; a job-creating endpoint usually wants `User endpoint` or `Web service endpoint` so the audit trail records `x-user`.

## 9. Common gotchas

- **Missing `.config`** — every endpoint artifact requires a sibling `.config`. Without it the artifact is not loaded. See `references/artifacts-and-config.md`.
- **Wrong type string** — only `Public endpoint`, `User endpoint`, `Web service endpoint` are routed. `Endpoint`, `public-endpoint`, `WS endpoint`, etc. are rejected with `401 / Not and endpoint`.
- **`User endpoint` with no session and no token** — returns `401` even if the script would otherwise tolerate anonymous calls. Use `Public endpoint` for that case.
- **`Web service endpoint` user lacks `WS` role** — `401`. The role is checked against the JWT, not against the BPM session.
- **CORS** — the platform copies request headers in but does not auto-emit CORS response headers. Set `Access-Control-Allow-Origin`, `Access-Control-Allow-Methods`, etc. in `_responseHeaders` when a browser from another origin will call the endpoint.
- **`Content-Type` of the response** — defaults to nothing (Spring picks one). Always set `_responseHeaders["Content-Type"]` explicitly for JSON, HTML, binary.
- **Status codes** — the dispatcher parses `_responseHeaders["status"]` by stripping non-digits, so `"200 OK"` becomes `200`. `null` falls back to `200`. Set numeric strings (`"201"`, `"404"`).
- **Streaming / response size** — the response body is buffered in memory unless you use `_responseHeaders["resource"]`. For files larger than a few MB always write to a BPM resource and return its path.
- **Async work** — the HTTP request blocks until the script finishes. For work longer than a few seconds use the reply-and-detach pattern in § 8, model it as a BPMN process, or schedule it with `cron:` in the artifact `.config`.
- **Token in logs** — the dispatcher writes `x-user` to the audit log. Do not put secrets in headers you also log.
- **`inputJson` param collision** — a query parameter literally named `inputJson` is parsed as JSON and merged into context. Avoid using that name as a regular parameter.
- **GET with body** — `/api/run/{project}/{code}` accepts any HTTP method, but only POST/PUT-style requests have their input stream read as the body. GET requests should pack data into query params.

## 10. Validation summary

Confirm an endpoint is configured correctly:

1. Artifact has a `.config` file alongside it.
2. `type` field is exactly one of `Public endpoint`, `User endpoint`, `Web service endpoint` (case-sensitive).
3. `lang` is one of `Python`, `JavaScript`, `Vertx`, `Shell`, `JUEL` (or `JSON` / `YAML` / `Markdown` for static responses).
4. `id` is `<project>/<code>` and is reachable as `/api/run/<project>/<code>`.
5. The script reads inputs from `bpm.context` (not from a `body` variable).
6. The script writes its body via `print(...)` and sets `_responseHeaders["status"]` plus `_responseHeaders["Content-Type"]`.
7. For `User endpoint`: the call carries either an active session cookie or a valid JWT — confirm `x-user` is not `nobody`.
8. For `Web service endpoint`: the calling user has the `WS` role — confirm `x-ws-auth == "true"`.
9. CORS headers are emitted explicitly when browser cross-origin clients are involved.
10. Large or binary responses are returned via `_responseHeaders["resource"]`, not buffered through stdout.
11. Errors inside the script return a controlled status by setting `_responseHeaders["status"]` before printing the error JSON; uncaught exceptions surface as `500` with stderr in the body.
12. Smoke test:
    - `Public endpoint`: `curl http://host/api/run/<id>` succeeds without auth.
    - `User endpoint`: same call returns `401`; same call with `Authorization: Bearer $TOKEN` succeeds.
    - `Web service endpoint`: call with token of a non-WS user returns `401`; call with WS-token succeeds and `x-ws-auth` is `true` in the script.
