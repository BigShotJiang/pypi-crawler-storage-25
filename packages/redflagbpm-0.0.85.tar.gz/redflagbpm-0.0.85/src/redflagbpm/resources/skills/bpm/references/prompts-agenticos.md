# Agentic Prompts

Agentic Prompts are RedFlag BPM artifacts stored as **`type: "Script"`** with **`lang: "Prompt"`** — the body is a `PromptDTO` (YAML or JSON). A simple Prompt sends one message to one Agent and returns a response. An agentic Prompt orchestrates multiple Agents in `sequence`, `parallel`, `loop`, `conditional` or `supervisor` patterns, sharing data through an `AgenticScope`. Agents are referenced by ID (`PROJECT/AGENT_ID`); see `references/agents-and-rag.md` for how Agents themselves are defined.

> **Heads-up sobre el `type` válido**: `Prompt` **NO** es un `type` de CodeDTO — solo es un `lang` (engine name registrado por `AgentScriptEngineFactory.getNames()`, valores `prompt`/`Prompt`/`PROMPT`). Los `type` válidos son `Script`, `Form`, `Page`, `Public endpoint`, `User endpoint`, `Web service endpoint`, `Query`, `Service`, `Collection`, `Report`, `Menu`, `Agent`, `Mcp`, `Analyst` (ver `dev/redflag/bpm/dto/CodeDTO.java:36-48`). Si encontrás archivos legacy con `type: "Prompt"` (existen en demo data: `forms/PROMPT_BIENVENIDA.prompt.config`), **migralos a `type: "Script"` + `lang: "Prompt"`** — NO a `type: "Agent"`. Un Agent es un artefacto distinto (`AgentInfo`, definición de modelo + tools); un Prompt es un script invocable que orquesta agents.

The runtime is the `langchain4j-agentic` module. When the `workflow` field is absent the artifact behaves as a single-agent prompt (backward compatible). When present, the prompt is built and executed by `dev/redflag/bpm/impl/ai/WorkflowBuilder.java`.

---

## PromptDTO Structure

The recommended YAML field order matches `@JsonPropertyOrder` on `PromptDTO`:

```yaml
agent: "PROJECT/AGENT_ID"
prompt: |
  Instructions or task for the agent (Velocity is processed here).
content: []
contentPrompt: |
  Instructions to convert multimodal content into text.
contentAgent: "PROJECT/CONTENT_AGENT"
contentVariable: contentText
schema:
  type: object
  properties:
    field: { type: string }
  required: [field]
workflow: sequence
outputKey: result
subAgents: []
workflowConfig: {}
```

### Field reference

| Field | Type | Required | Notes |
|---|---|---|---|
| `agent` | String | Required for single-agent; optional in workflows | Agent ID `PROJECT/AGENT_ID`. At workflow top level it is the **default agent** inherited by sub-agents that omit `agent`. In supervisor workflows it is the coordinator. |
| `prompt` | String | Required | Velocity-processed (`${...}`) at build time. In workflows the top-level value is the input data, available as `{{input}}` in the scope. |
| `content` | `List<String>` | Optional | Each element is a JUEL expression resolving to one or more resource paths (PDF, image, audio, video). |
| `contentPrompt` | String | Optional | Instructions for the LLM that converts the multimodal content to text. In workflows, if `content` is present and `contentPrompt` is absent, the default `"Extract the text from the attached content"` is used. |
| `contentAgent` | String | Optional | Agent that interprets the content. Defaults to `agent`. Useful for using a vision-capable model just for content extraction. |
| `contentVariable` | String | Optional | Name of the scope key where the extracted text is stored. Default: `contentText`. |
| `schema` | `JsonObject` | Optional | JSON Schema for structured output. When set, the agent response is constrained to JSON matching it. |
| `workflow` | String | Optional | Switches to agentic mode. Closed set: `sequence`, `parallel`, `loop`, `conditional`, `supervisor`. |
| `outputKey` | String | Optional | Scope key where this agent's output is stored. |
| `subAgents` | `List<PromptDTO>` | Optional | Sub-agent definitions (each is itself a full PromptDTO and may define its own `workflow` for nesting). |
| `workflowConfig` | `JsonObject` | Optional | Workflow-specific keys (`maxIterations`, `exitCondition`, `condition`, `supervisorContext`, `maxInvocations`, `contextStrategy`, `responseStrategy`). |

Source of truth: `dev/redflag/bpm/dto/PromptDTO.java`.

### Companion `.config`

```yaml
project: "PROJECT_CODE"
id: "PROJECT/PROMPT_ID"
type: "Script"         # CodeDTO type — siempre "Script" para prompts agentic
lang: "Prompt"         # JSR-233 engine — "Prompt" rutea al AgentScriptEngine
description: "Optional description"
```

El `lang: "Prompt"` es lo que enchufa el body al `AgentScriptEngine` (ver `dev/redflag/bpm/jsr233/AgentScriptEngineFactory.java:42-44`). El body se parsea como `PromptDTO`. Sin esto el body no se ejecutaría como prompt agentic.

### Shebang format (single-agent only)

```text
#!PROJECT/AGENT_ID

Free-text prompt body. The first line specifies the agent.
```

This format does not allow `schema`, `workflow`, `subAgents`, `content`, etc. Those must live in YAML.

---

## Workflow Types (closed set)

The `WorkflowBuilder.buildWorkflow` switch (`dev/redflag/bpm/impl/ai/WorkflowBuilder.java:64-78`) accepts exactly these five values. Any other string raises `IllegalArgumentException: Workflow type not supported`. Values are **case-sensitive** (lowercase).

| Type | Execution | Use when |
|---|---|---|
| `sequence` | Sub-agents run **in order**, each reads previous outputs from the scope. | The task decomposes into linear, dependent steps. |
| `parallel` | Sub-agents run **concurrently**; their outputs land in the scope when all finish. | Independent analyses that can be done at the same time. |
| `loop` | Sub-agents run **repeatedly** until `exitCondition` is true or `maxIterations` is reached. | Iterative refinement with generator + evaluator. |
| `conditional` | The first sub-agent whose `workflowConfig.condition` evaluates to true runs. | Branching by classification. |
| `supervisor` | An LLM coordinator (the top-level `agent`) decides dynamically which sub-agents to call and when. | Open-ended tasks where the order is not known up front. |

### Sequence

```yaml
agent: HLW/BOTIN
prompt: "${textInput}"
workflow: sequence
subAgents:
  - prompt: "Extract key points from: {{input}}"
    outputKey: analysis
  - prompt: "Summarize: {{analysis}}"
    outputKey: summary
```

Each sub-agent reads earlier `outputKey` values via `{{key}}`. The final result is the last `outputKey`'s value (see [Workflow result](#workflow-result-resolution-order)).

### Parallel

```yaml
prompt: "Multi-perspective document analysis"
workflow: parallel
content:
  - "${documentPath}"
subAgents:
  - agent: LEGAL/RISK
    prompt: "Risk analysis of: {{input}}"
    outputKey: risk
  - agent: LEGAL/FINANCIAL
    prompt: "Financial implications of: {{input}}"
    outputKey: financial
  - agent: LEGAL/COMPLIANCE
    prompt: "Compliance check of: {{input}}"
    outputKey: compliance
```

All three agents see the same `{{input}}` and run concurrently. To consolidate, wrap a `parallel` step inside a `sequence` (see [Composition](#subagents-and-composition)).

### Loop

```yaml
agent: HR/ASSISTANT
prompt: "${input}"
workflow: loop
workflowConfig:
  maxIterations: 3
  exitCondition: "${score > 8}"
  testExitAtLoopEnd: true
subAgents:
  - prompt: |
      Improve the CV. Previous: {{cv}}. Feedback: {{feedback}}.
    outputKey: cv
  - prompt: |
      Score the CV from 1 to 10. Reply JSON: {"score": N, "feedback": "..."}.
      CV: {{cv}}
    outputKey: score
```

`workflowConfig` for `loop`:

| Key | Type | Description |
|---|---|---|
| `maxIterations` | Integer | Hard cap on iterations. |
| `exitCondition` | String | JUEL evaluated against the scope. Loop exits when `true`. |
| `testExitAtLoopEnd` | Boolean | If `true`, evaluate at the end of each iteration; default tests at the start. |

### Conditional

```yaml
prompt: "${ticketDescription}"
workflow: conditional
subAgents:
  - agent: SUPPORT/TECHNICAL
    prompt: "Resolve technical issue: {{input}}"
    outputKey: response
    workflowConfig:
      condition: "${category == 'technical'}"
  - agent: SUPPORT/BILLING
    prompt: "Handle billing query: {{input}}"
    outputKey: response
    workflowConfig:
      condition: "${category == 'billing'}"
  - agent: SUPPORT/GENERAL
    prompt: "Generic answer: {{input}}"
    outputKey: response
    workflowConfig:
      condition: "true"
```

Every sub-agent **must** carry `workflowConfig.condition`. Use `"true"` as the fallback branch — order matters, the first matching condition wins.

### Supervisor

```yaml
agent: RESEARCH/COORDINATOR
prompt: "Investigate and write a full report on: ${topic}"
workflow: supervisor
workflowConfig:
  supervisorContext: |
    You are the team coordinator. Use all available agents to produce a
    complete report. Start with research, then analysis, then writing.
    Always reply in Spanish.
  maxInvocations: 10
  contextStrategy: CHAT_MEMORY_AND_SUMMARIZATION
  responseStrategy: SUMMARY
subAgents:
  - agent: RESEARCH/INVESTIGATOR
    prompt: "Research the given topic; gather data and sources."
  - agent: RESEARCH/ANALYST
    prompt: "Analyze the gathered data; identify patterns."
  - agent: RESEARCH/WRITER
    prompt: "Write the final report with executive summary and findings."
```

The top-level `agent` is the coordinator's own LLM. Sub-agents do not declare `outputKey` — the supervisor decides what to do with each result.

`workflowConfig` for `supervisor`:

| Key | Type | Description |
|---|---|---|
| `supervisorContext` | String | Extra instructions appended to the supervisor's system prompt. |
| `maxInvocations` | Integer | Total cap on sub-agent calls. |
| `contextStrategy` | String | `CHAT_MEMORY` / `SUMMARIZATION` / `CHAT_MEMORY_AND_SUMMARIZATION`. |
| `responseStrategy` | String | `LAST` (default) / `SUMMARY` / `SCORED`. |

`contextStrategy` controls how much history the supervisor keeps between sub-agent calls; `responseStrategy` controls how the supervisor produces its final answer (`LAST` returns the last sub-agent's output, `SUMMARY` produces a synthesized summary, `SCORED` evaluates and returns the best).

---

## AgenticScope

The `AgenticScope` is the per-execution key/value store that all agents in a workflow share. It is the **only** mechanism for passing data between sub-agents.

- The top-level `prompt` (after Velocity processing) is written to the scope under the key **`input`**.
- Each sub-agent writes its result to the scope under its own `outputKey`.
- Sub-agents read scope values with `{{key}}` (langchain4j templating).
- If `content` is present at the top level, the extracted text is written under `contentVariable` (default `contentText`), so sub-agents can reference it as `{{contentText}}`.

The scope is independent from `ChatMemory`. `ChatMemory` is per-agent conversational history (enabled with `memoryEnabled: true` on the Agent definition); it is **not** shared across sub-agents. Workflows pass data through the scope, not through memory.

---

## Template Engines

Two template engines coexist in agentic prompts. Knowing **when** each one runs is the most common source of bugs.

### Velocity — `${var}` (build time)

Velocity is processed when `WorkflowBuilder` constructs the workflow, **before any agent runs**. Available context: the BPM script context — process variables, `bpm.service.execute()` context map, Flowable execution variables, service references.

```yaml
prompt: "${textInput}"
subAgents:
  - prompt: "Analyze report from ${department} for ${period}: {{input}}"
    outputKey: analysis
```

Here `${department}` and `${period}` are resolved at build time from BPM variables; the agent never sees the placeholders.

### Langchain4j — `{{var}}` (runtime)

Double braces are resolved by langchain4j when each agent executes, reading the AgenticScope.

```yaml
subAgents:
  - prompt: "Extract: {{input}}"
    outputKey: data
  - prompt: "Summarize: {{data}}"   # reads previous output
    outputKey: summary
```

### Precedence and rules

| Syntax | Engine | Resolved | Reads from |
|---|---|---|---|
| `${var}` in `prompt`, `contentPrompt` | Velocity | Build time | BPM script context (process vars, execution context) |
| `{{var}}` in `prompt` | langchain4j | Agent runtime | AgenticScope (`input`, `outputKey` of previous agents, `contentText`) |
| `${expr}` in `exitCondition`, `condition` | JUEL | Workflow runtime | AgenticScope keys (note: same `${}` syntax as Velocity, **but evaluated by JUEL against the scope**, not by Velocity at build time) |
| `${var}` in `content` items | JUEL | Build time | BPM script context (resource path resolution) |
| `{{var}}` in sub-agent `content` | Scope substitution | Sub-agent runtime | AgenticScope (lets one agent generate a file path that another reads) |

**Rule of thumb:** use `${...}` for static data known before the workflow starts, and `{{...}}` for dynamic data produced by agents during the workflow. Both syntaxes can appear in the same prompt string without conflict.

---

## Multimodal Content

The `content` field attaches PDFs, images, audio or video to the user message sent to the agent.

### `content` — JUEL resource expressions

Each list item is a JUEL expression evaluated at build time. Accepted return types:

| Return type | Behavior |
|---|---|
| `String` | One resource path. |
| `List<String>` / `Collection<String>` / `String[]` | One path per element. |
| `JsonObject` | Reads the `filePath` field. |
| `JsonArray` of `JsonObject` | Reads `filePath` from each element. |
| `JsonArray` of other types | Each element converted to string and used as a path. |

A `null` return throws.

Supported file types (matched first by MIME, then by extension):

| Type | Extensions / MIME |
|---|---|
| PDF | `application/pdf`, `.pdf` |
| Image | `image/*`, `.jpg`, `.jpeg`, `.png`, `.gif`, `.bmp`, `.webp` |
| Audio | `.mp3`, `.ogg` |
| Video | `.mp4` |

### `contentPrompt` and `contentAgent` — text pre-processing

When sub-agents need to reason over the content as **text** (rather than as a multimodal attachment), `contentPrompt` is set. The pipeline becomes:

1. Build a multimodal `UserMessage` with `contentPrompt` as the text and `content` items as attachments.
2. Send it to `contentAgent` (defaults to the main `agent`).
3. The LLM's textual interpretation is stored in the scope under `contentVariable` (default `contentText`).
4. If `prompt` contains the placeholder `${contentText}`, it is replaced; otherwise the extracted text is **prepended** to the prompt.

| Scenario | `contentPrompt` | Behavior |
|---|---|---|
| Single-agent, no `contentPrompt` | absent | Multimodal `UserMessage` sent directly to the agent. |
| Single-agent, with `contentPrompt` | present | Pre-process to text via `contentAgent`, then send a textual `UserMessage` with `${contentText}` interpolated. |
| Workflow, no `contentPrompt` | absent | Default prompt `"Extract the text from the attached content"` is used. Result lands in scope under `{{contentText}}`. |
| Workflow, with `contentPrompt` | present | Same as above but with custom extraction instructions. |

### `contentVariable` — naming the extracted text

Defaults to `contentText`. Override when several different content blocks coexist at different levels of the same workflow:

```yaml
prompt: "Compare the original contract with the addendum"
workflow: sequence
content:
  - "${contractPath}"
contentPrompt: "Transcribe the contract verbatim"
contentVariable: contractText
subAgents:
  - prompt: |
      Compare:
      Contract: {{contractText}}
      Addendum: {{addendumText}}
    content:
      - "${addendumPath}"
    contentPrompt: "Transcribe the addendum verbatim"
    contentVariable: addendumText
    outputKey: comparison
```

### Content in sub-agents — build-time vs runtime

Sub-agents can declare their own `content`. The resolution time depends on the syntax:

- `"${variable}"` — resolved at **build time** by JUEL against the BPM context. The extracted text is injected into the sub-agent's prompt via `${contentVariable}`.
- `"{{outputKey}}"` — resolved at **runtime** against the scope. Lets one agent generate a file (e.g. via a tool) and a later agent read it.

```yaml
workflow: sequence
subAgents:
  - prompt: "Generate the monthly report PDF and return only its path"
    outputKey: pdfPath
  - prompt: "Verify the report follows corporate format"
    content:
      - "{{pdfPath}}"
    contentPrompt: "Extract all text preserving section structure"
    outputKey: verification
```

`content` is **not inherited** from the parent. Each level that needs to process content must declare it explicitly.

---

## Schema (Structured Output)

`schema` is a JSON Schema object. When present, the agent response is constrained to JSON matching it (the system uses the provider's structured-output feature). The runtime auto-detects:

| Agent response | Returned type |
|---|---|
| JSON object `{...}` | `JsonObject` |
| JSON array `[...]` | `JsonArray` |
| Markdown ```` ```json ... ``` ```` block | `JsonObject` or `JsonArray` |
| Anything else | `String` |

```yaml
agent: HLW/SIGNUP
prompt: "Collect the user's data through a friendly conversation."
schema:
  type: object
  description: "User profile form"
  properties:
    customer:
      type: string
      title: Customer
      description: "Use valueProvider HLW/VP_CUSTOMERS."
    name:
      type: string
      title: Name
    style:
      type: string
      enum: [Formal, Informal]
  required: [customer, name, style]
```

In workflows the schema applies to whatever sub-agent declares it; it is not a workflow-wide setting.

---

## SubAgents and Composition

`subAgents` is a `List<PromptDTO>`. Each entry is itself a full PromptDTO and may either:

- reference an `agent` and define a `prompt` (a leaf agent), or
- declare its own `workflow` and `subAgents` (a nested workflow — composition).

This makes workflows fully composable. A common pattern is `sequence` containing a `parallel` block followed by a consolidation step:

```yaml
prompt: "Full document processing pipeline"
workflow: sequence
content:
  - "${documentPath}"
subAgents:
  - agent: DOC/CLASSIFIER
    prompt: "Classify the document: {{input}}"
    outputKey: classification

  - workflow: parallel
    subAgents:
      - agent: DOC/SENTIMENT
        prompt: "Sentiment of: {{input}}"
        outputKey: sentiment
      - agent: DOC/TOPICS
        prompt: "Main topics in: {{input}}"
        outputKey: topics
      - agent: DOC/ENTITIES
        prompt: "Named entities in: {{input}}"
        outputKey: entities

  - agent: DOC/REPORT
    prompt: |
      Build the final report.
      Classification: {{classification}}
      Sentiment: {{sentiment}}
      Topics: {{topics}}
      Entities: {{entities}}
    outputKey: report
```

### Agent inheritance

When `agent` is set at the top level of a workflow, every sub-agent that omits `agent` inherits it. A sub-agent can override by declaring its own `agent`. The check is enforced in `WorkflowBuilder.buildSubAgent`: a sub-agent without an `agent`, without an inherited default, and without a nested `workflow` raises `IllegalArgumentException`.

---

## Real-world use cases

The following are recurring patterns that map cleanly to the closed set of workflow types:

- **Text analysis** — `sequence`: extract → summarize → report.
- **Invoice extraction** — single-agent with `content` (PDF) and `schema` for structured fields.
- **Employee onboarding** — `sequence`: onboarding plan → access list → welcome email.
- **Content QA loop** — `loop` with generator + scorer, exits when score crosses threshold.
- **Customer service routing** — `sequence` (classifier) wrapping a `conditional` block per category.
- **Quarterly financial reports** — `supervisor` over revenue, cost, market analysts and a writer.
- **Legal document analysis** — `sequence` containing a `parallel` block (risk, financial, comparative) and a final consolidator.
- **Document generation + verification** — `sequence` where one agent uses a tool to produce a PDF and the next reads it via runtime `content: ["{{pdfPath}}"]`.

When the same problem can be solved by more than one pattern, the choice depends on:

- **`sequence`** — predictable flow, well-defined steps.
- **`parallel`** — tasks are independent and can run at the same time.
- **`loop`** — quality gating via repeated refinement.
- **`conditional`** — the action depends on a prior classification.
- **`supervisor`** — the optimal order is unknown and has to be decided by the LLM.

---

## Workflow result resolution order

Both single-agent and workflow prompts apply the same auto-detection (`JsonObject` / `JsonArray` / `String`). For workflows, the value before auto-detection is resolved in this order:

1. Value returned directly by the workflow engine.
2. Value of the **top-level** `outputKey` in the scope.
3. Value of the **last sub-agent's** `outputKey` in the scope.
4. The full scope as a JSON object (fallback — almost never what you want).

Always set `outputKey` on the last sub-agent of a sequence (or on the workflow itself) to avoid the fallback.

---

## Execution

### From a script

```python
#!python3
import redflagbpm

bpm = redflagbpm.BPMService()
result = bpm.service.execute(
    script="PROJECT/PROMPT_ID",
    context={"textInput": "Q1 revenue rose 15%..."}
)
```

### From a Flowable Script Task

- **Script**: `PROJECT/PROMPT_ID`
- **Script Format**: `code`

The result is stored as a process variable. If it is a `JsonObject`, top-level properties are exposed as individual variables (`execution.getVariable("name")`).

### Logging

Workflow runs emit per-agent events under the logger `bpm.agents.workflows`:

| Level | What is logged |
|---|---|
| `INFO` | Agent invocation/completion (name, output size), tool calls (name, args, summarized result). |
| `DEBUG` | All of the above plus complete inputs/outputs and full scope state after each step. |

For raw HTTP requests/responses to the LLM provider, set `logRequests: true` / `logResponses: true` in the Agent's `properties`.

---

## Common gotchas

- **`content` and `contentPrompt` are independent fields, not alternatives** — `content` lists the resources, `contentPrompt` (optional) tells an LLM how to convert them to text. The mutually-exclusive choice is more subtle: if you want the agent to receive the file as a multimodal attachment, omit `contentPrompt`. If you want a text-pre-processed version (so `${contentText}` / `{{contentText}}` becomes available), set `contentPrompt`. In **workflows**, when `content` is present `contentPrompt` is effectively forced (defaulted to the extraction instruction), because sub-agents can only consume scope text, not multimodal attachments.
- **`workflow` values are case-sensitive.** `Sequence`, `SEQUENCE`, `loop ` (trailing space) all fail with `Workflow type not supported`. The closed set is exactly: `sequence`, `parallel`, `loop`, `conditional`, `supervisor`.
- **Velocity vs JUEL ambiguity.** The same `${...}` syntax means **Velocity** in `prompt`/`contentPrompt` (build time, BPM context) and **JUEL** in `exitCondition`/`condition` (runtime, scope). They are different engines reading different contexts at different times.
- **Sub-agents cannot read sibling memory.** `ChatMemory` is per-agent. Sharing data between sub-agents only works through the AgenticScope (`outputKey` → `{{key}}`).
- **Top-level `prompt` is data, not instructions, in workflows.** It is processed by Velocity and then stored under `input`. Each sub-agent must carry its own instructions in its own `prompt`.
- **Conditional needs `condition` on every sub-agent.** Forgetting `workflowConfig.condition` on one branch breaks the routing. Always include a `"true"` fallback as the last branch.
- **`outputKey` collisions overwrite.** If two sub-agents in a `sequence` share an `outputKey` (e.g. two branches under a `conditional` writing to `response`), that is intentional; in `parallel`, it is a bug — the last writer wins non-deterministically.
- **`content` is not inherited.** Each sub-agent that needs its own multimodal resource must declare its own `content` (and usually `contentVariable`). Top-level `content` only feeds the workflow's `input`/`contentText`.
- **Build-time vs runtime in sub-agent `content`.** `"${path}"` is resolved before the workflow starts. `"{{key}}"` is resolved when the sub-agent runs. Use the second form whenever the path is produced by a previous agent.
- **Schema applies where it is declared.** A top-level schema does not propagate to sub-agents; declare `schema` on the specific PromptDTO (sub-agent) whose output you want constrained.
- **Agent inheritance is single-level scope.** The default agent set at the workflow top is inherited by direct sub-agents only. A nested `workflow` block re-establishes its own default if it declares `agent`; otherwise inheritance continues from the outer level.
- **`subAgents: []` with `workflow:` set is an error in practice.** All five workflow types require at least one sub-agent; an empty list is accepted by parsing but the orchestrator has nothing to run.

---

## Validation summary

`validators/prompt.py` checks:

- **Artifact** — `lang` in the `.config` is `YAML` (or `Python` for shebang format), `type` is `Prompt`.
- **Required fields** — single-agent prompts have both `agent` and `prompt`; workflows have `workflow` plus `subAgents` (and either a top-level `agent` or an `agent` per leaf sub-agent).
- **Workflow type** — exactly one of `sequence`, `parallel`, `loop`, `conditional`, `supervisor` (lowercase). `WORKFLOW_TYPES` in `enums.py`.
- **`workflowConfig`** — present when needed:
  - `loop` — `maxIterations` and/or `exitCondition` (otherwise the loop runs forever or exits immediately).
  - `conditional` — every sub-agent has `workflowConfig.condition`; a `"true"` fallback is the last entry.
  - `supervisor` — `maxInvocations` set; `contextStrategy` and `responseStrategy` only use the documented enum values.
- **Templates** — `${...}` only references variables that exist in the BPM context at build time; `{{...}}` only references `input`, `contentVariable` (default `contentText`), or earlier `outputKey` values.
- **Result** — last sub-agent (or workflow itself) has an explicit `outputKey`, otherwise the fallback returns the whole scope as JSON.
- **Schema** — when an `outputKey` is consumed by a downstream prompt that expects fields, the producing agent has a `schema` (so the value is a `JsonObject`, not a free-text `String`).
- **Multimodal** — `content` items resolve to supported file types; `contentVariable` names are unique per workflow level.
- **Agent inheritance** — every leaf sub-agent either declares its own `agent` or inherits one from the nearest workflow ancestor.

---

## Cross-references

- `references/agents-and-rag.md` — Agent definition, providers, memory, tools, RAG via `mdResources` / `fileSearchStores` / `vectorSearchStores`.
- `references/scripts-and-tools.md` — Tools used by agents, and `bpm.service.execute()` from Python and Groovy scripts.
