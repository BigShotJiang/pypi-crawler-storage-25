# Logging desde scripts y debugging

Cómo escribir logs ordenados desde tus scripts y cómo inspeccionarlos cuando algo no anda. La API en código está en `references/sdk-python.md` § `bpm.logger`; este documento cubre **dónde aterrizan esos logs**, **cómo separarlos por proyecto/módulo**, **cómo leerlos desde el Coder** y **cómo subir/bajar niveles en runtime para debuggear**.

## 1. Cómo `bpm.logger` mapea a archivos

Cuando hacés:

```python
bpm.logger.info("bpm.code/HLW", "procesando pedido %s" % order_id)
```

el primer argumento (`"bpm.code/HLW"`) es el **nombre del logger** y determina **el archivo de disco** donde queda la línea. Cada nombre único genera un archivo separado dentro del directorio de logs del runtime BPM.

Reglas que aplica el runtime al armar el filename:

| Nombre que pasás | Archivo en disco |
|---|---|
| `bpm.code/HLW` | `bpm.code.HLW.log` (el `/` se transforma a `.`) |
| `bpm.code.HLW` | `bpm.code.HLW.log` (idem — son el **mismo archivo**) |
| `bpm.security` | `bpm.security.log` (archivo dedicado, retención 30 días) |
| `bpm.miModulo` | `bpm.miModulo.log` |
| Cualquier `dev.redflag.bpm.*` | `bpm.core.log` (engine interno) |
| Cualquier `org.flowable.*` | `bpm.flowable.log` (motor workflow) |
| Cualquier otro nombre que **no** empiece con `bpm.` ni `dev.redflag.` | `default.log` |

> Consecuencia importante: si elegís un nombre genérico tipo `"log"`, `"mylog"`, `"test"` o `"x"`, **no va a un archivo propio** — termina mezclado en `default.log` con el ruido de las dependencias (Spring, Atmosphere, etc.). Para que tu log sea aislable, prefijalo con `bpm.` o usá `bpm.code/<PROJECT>`.

## 2. Convención recomendada de naming

| Caso de uso | Nombre sugerido | Archivo resultante |
|---|---|---|
| Logs de un script del proyecto `HLW` | `bpm.code/HLW` | `bpm.code.HLW.log` |
| Logs de un módulo dentro de un proyecto | `bpm.code/HLW/imports` | `bpm.code.HLW.imports.log` |
| Auditoría / acciones sensibles | `bpm.security` | `bpm.security.log` |
| Integración o módulo transversal | `bpm.<modulo>` (ej. `bpm.crm`, `bpm.facturacion`) | `bpm.<modulo>.log` |

Reglas de pulgar:

- **Empezá siempre con `bpm.`** salvo que tengas razón explícita para no hacerlo.
- **No mezcles `/` y `.` arbitrariamente** — son equivalentes en el filename, así que `bpm.code/HLW` y `bpm.code.HLW` aterrizan en el mismo archivo. Elegí una forma y mantenela en el proyecto.
- **Usá un nombre por proyecto, no uno por script.** Si tenés 50 scripts en `HLW`, todos pueden loguear a `bpm.code/HLW` y diferenciarse por el contenido del mensaje (incluí el id del script, business key, lo que sirva). Crear 50 archivos chicos dificulta el debugging.
- **Si necesitás un eje secundario** (ej. separar imports de exports), agregá un segundo segmento: `bpm.code/HLW/imports`, `bpm.code/HLW/exports`.

## 3. Niveles disponibles

```python
bpm.logger.debug("bpm.code/HLW", "valor calculado: %s" % x)
bpm.logger.info("bpm.code/HLW", "iniciando proceso")
bpm.logger.warn("bpm.code/HLW", "stock bajo para producto %s" % sku)
bpm.logger.error("bpm.code/HLW", "fallo al notificar a %s" % email)
bpm.logger.trace("bpm.code/HLW", "detalle ultra-fino")
```

El nivel global del runtime es **INFO**. Eso significa que `debug` y `trace` se aceptan pero no se escriben a disco salvo que el logger esté configurado más permisivo (config del bpmapp, no del configurador). Para debugging temporal alcanza con usar `info`/`warn`/`error`.

`bpm.security` está configurado a nivel INFO con retención de 30 días — todo lo que se loguee con ese nombre queda con esa política. Los demás archivos no tienen política de retención automática.

## 4. Dónde quedan los archivos en disco

El runtime resuelve el directorio de logs vía la system property `LOG_PATH`, con fallback `./logs` relativo al cwd del proceso BPM.

| Entorno | Path real |
|---|---|
| Dev local (`scripts/bpm-dev.sh`) | `<repo>/demo/logs/` (cwd del proceso = `demo/`) |
| Producción Docker | `/app/logs/` dentro del container, montado al host como `./data/logs/` (bind del compose) |

Como configurador no necesitás conocer estos paths para escribir logs — sí los conviene saber para localizarlos cuando estés debuggeando manualmente. Para inspeccionarlos desde el Coder hay tools dedicadas (§ 6).

## 5. Rotación

Cada logger tiene **dos formas de archivo**:

- **Current**: `<logger>.log` — sin sufijo de fecha. Es el archivo del día en curso. Es donde está pasando todo *ahora*.
- **Rotados**: `<logger>-YYYY-MM-DD.log` — un archivo por cada día anterior, generado automáticamente al cambiar de día.

> En la práctica, **el 95% del tiempo querés mirar el current** (el archivo sin sufijo). Solo necesitás los rotados cuando estás reconstruyendo qué pasó un día específico.

## 6. Estrategia de búsqueda cuando no sabés dónde está tu mensaje

Cuando estás debuggeando y no estás seguro de dónde aterrizó lo que buscás, recorré los archivos en este orden — de lo más cercano a tu código a lo más ajeno:

1. **`bpm.code.<PROYECTO>.log`** — primero acá, es donde van los `bpm.logger.*("bpm.code/<PROYECTO>", ...)` que escribiste vos.
2. **`bpm.code.log`** — engine de scripts. Es donde caen los `print()` y los errores que estallan **antes** de que tu script alcance a loguear (traceback de import, NameError en la primera línea, etc.).
3. **`bpm.flowable.log`** — solo si el síntoma huele a workflow/transición (timer que no dispara, gateway raro, listener que no corre). Salteá si no aplica.
4. **`bpm.core.log`** — engine BPM interno (`dev.redflag.bpm.*`). Acá aparecen problemas de infraestructura BPM: persistencia, eventos, auth, configuración.
5. **`default.log`** — dependencias y todo lo que no está namespaced (Spring, Atmosphere, Jetty, drivers JDBC, etc.). Última parada — solo si nada de lo anterior reveló el problema.

> Atajo: si tu script tira excepción y el mensaje no está en (1), casi seguro está en (2) — ahí cae el traceback completo del intérprete Python antes de que cualquier `try/except` lo agarre.

Las tools del Coder (§ 7) están pensadas para recorrer este orden rápido: `bpm_log_grep` sin `loggers` ya escanea **todos los current** de una, lo que te da una primera pasada barata antes de bajar a archivos específicos.

## 7. Inspección desde el Coder

El Coder expone tres tools para inspeccionar logs **del runtime BPM** (no del workspace). **Solo Coder** — no se exponen al Analyst, porque los logs pueden contener auditoría y datos cross-tenant.

### `bpm_log_list`

Lista qué archivos hay y su tamaño. Útil para descubrir qué está escribiendo logs.

```
bpm_log_list({ pattern: "bpm.code" })
```

Por default muestra solo los **current**; pasá `includeRotated: true` para ver también los rotados.

### `bpm_log_tail`

Últimas N líneas de uno o varios loggers (default 200 líneas).

```
bpm_log_tail({ loggers: ["bpm.code.HLW"], lines: 100 })
bpm_log_tail({ loggers: ["bpm.security"], level: "ERROR" })
bpm_log_tail({ loggers: ["bpm.code.HLW"], date: "2026-04-30" })   // archivo rotado
```

### `bpm_log_grep`

Regex sobre los logs, con filtros opcionales:

```
bpm_log_grep({ pattern: "OrderNotFound" })                                    // todos los current
bpm_log_grep({ pattern: "timeout", loggers: ["bpm.code.HLW"], level: "ERROR" })
bpm_log_grep({ pattern: "user=ana", since: "30m" })                          // últimos 30 min
bpm_log_grep({ pattern: "auth fail", date: "2026-04-30" })                   // en rotados de ese día
```

`since` acepta `<N>[smhd]` (ej. `10m`, `2h`, `1d`), `today`, `yesterday`, o un timestamp ISO (`2026-04-30T12:00:00`).

> **El nombre de logger en `loggers`** se pasa como aparece en el filename — sin extensión `.log` y sin sufijo de fecha. Los `/` se aceptan y se normalizan a `.` igual que al escribir, así que `bpm.code/HLW` y `bpm.code.HLW` funcionan ambos.

## 8. Cambiar niveles de logger en runtime (debugging)

A veces el log a INFO no alcanza y querés ver lo que escribiste con `bpm.logger.debug(...)` o `.trace(...)`. El default global es INFO, así que esos mensajes no llegan a disco. Las dos tools siguientes te permiten subir el nivel **temporalmente** desde el Coder, sin pedirle al ADMIN que entre a la vista de configuración.

### `bpm_log_level_list`

Lista loggers registrados y sus niveles. Útil para ver qué tenés activo antes de cambiar nada.

```
bpm_log_level_list()                                  // bpm.*, dev.redflag.*, org.flowable.*, ROOT, y los explícitos
bpm_log_level_list({ pattern: "bpm.code" })           // filtra por substring
bpm_log_level_list({ includeAll: true })              // TODOS (incluye Spring, Atmosphere — ruidoso)
```

Cada entrada trae `level` (explícito si fue seteado) y `effectiveLevel` (el que efectivamente aplica, considerando herencia del parent).

### `bpm_log_level_set`

Cambia el nivel de un logger.

```
bpm_log_level_set({ logger: "bpm.code.HLW", level: "DEBUG" })       // subir para debuggear
bpm_log_level_set({ logger: "bpm.code.HLW", level: "INHERIT" })     // limpiar — vuelve a heredar (INFO)
bpm_log_level_set({ logger: "bpm.code.HLW", level: "INFO" })        // o setear explícito a INFO
```

Niveles válidos: `DEBUG`, `INFO`, `WARN`, `ERROR`, `TRACE`, `ALL`, `OFF`, `INHERIT`.

### Buenas prácticas

- **El runtime es compartido**. El proceso BPM atiende a todos los users de la instancia; subir DEBUG en un logger ancho como `bpm.code` o `dev.redflag.bpm` floodea el log de todos. **Preferí scope estrecho**: `bpm.code.MIPROYECTO` en vez de `bpm.code`, `dev.redflag.bpm.persistence` en vez de `dev.redflag.bpm`.
- **Volvé a INFO o INHERIT cuando termines.** Aunque los cambios son efímeros (revierten al restart), entre restart y restart todo el mundo está pagando tu DEBUG. `INHERIT` es la opción más limpia: borra el override y deja que herede del parent.
- **Los cambios no persisten.** Al próximo restart del runtime, los niveles vuelven a lo configurado en `logs/loggers-config.json` (gestionado por el ADMIN vía `BPMLogConfigView`). Si necesitás un cambio permanente, pedile al ADMIN — no es algo que el configurador deba hacer desde Coder.
- **Safety por default**: `level_set` solo permite **subir o setear** un nivel explícito en loggers bajo `bpm.*`, `dev.redflag.*`, `org.flowable.*`. Para tocar otros (ej. `org.springframework.*`) tenés que pasar `force: true` — y casi nunca es lo que querés. El `ROOT` está bloqueado siempre.
- **INHERIT no necesita force**: limpiar un override es siempre seguro, así que podés pasar `level: "INHERIT"` sobre cualquier logger sin necesidad del flag — incluso sobre uno que hayas tocado antes con `force: true`. Esto evita la fricción de tener que reposponer `force` solo para cleanup.
- **Workflow típico de debugging**:
  1. `bpm_log_level_set({ logger: "bpm.code.HLW", level: "DEBUG" })` — abrir el grifo en tu proyecto.
  2. Reproducir el bug (correr el script, disparar el evento).
  3. `bpm_log_tail({ loggers: ["bpm.code.HLW"], lines: 200 })` — leer lo que apareció.
  4. `bpm_log_level_set({ logger: "bpm.code.HLW", level: "INHERIT" })` — cerrar el grifo.

## 9. Pitfalls

- **`print()` no va al log.** En scripts Python, `print(...)` escribe a stdout del proceso de script — eso lo captura el motor BPM y puede aparecer en el archivo `bpm.code.log` con formato distinto, pero **no es lo mismo** que `bpm.logger.info(...)`. Para logging estructurado, siempre `bpm.logger.*`.
- **El nombre del logger es el filename.** Si lo pensás como "qué archivo quiero ver al final", no te confundís con el primer argumento.
- **`debug`/`trace` no aparecen al INFO global.** Si tu mensaje no aparece, chequeá el nivel efectivo con `bpm_log_level_list({ pattern: "tu.logger" })` y subilo con `bpm_log_level_set` si hace falta. Acordate de bajarlo cuando termines.
- **Cambios de nivel afectan a todos los users del runtime.** El proceso BPM es compartido. DEBUG en `bpm.code` (sin proyecto) o `dev.redflag.bpm` floodea el log de todo el mundo. Scope estrecho siempre — `bpm.code.MIPROYECTO`, no `bpm.code`.
- **Cambios de nivel desde el Coder son efímeros.** Revierten al restart porque no se persisten en `logs/loggers-config.json`. Si necesitás un cambio permanente, pedile al ADMIN que lo haga vía `BPMLogConfigView`.
- **Loggers nuevos = archivos nuevos automáticamente.** No hay que registrar nada; en cuanto hacés `bpm.logger.info("bpm.code/NUEVO", "x")`, aparece `bpm.code.NUEVO.log` en el directorio. Pero el logger no aparece en `bpm_log_level_list` hasta que se haya usado al menos una vez (logback lo crea on-demand).
- **Archivos rotados solo aparecen al día siguiente.** Si pasaste `date: "2026-04-30"` y el archivo no existe, puede ser que ese logger no escribió nada ese día (no hay rotación para días vacíos).
- **`bpm.security` tiene appender propio con formato distinto** (sin nombre del logger en la línea). Si grep'eás por nombre de clase en `bpm.security` no vas a encontrar nada — usá patrones del mensaje.

## 10. Ejemplo end-to-end

Script de un proyecto `HLW`:

```python
#!python3
import redflagbpm
bpm = redflagbpm.BPMService()

LOG = "bpm.code/HLW"

order_id = bpm.context.id_order
bpm.logger.info(LOG, "approving order %s by %s" % (order_id, bpm.context.userId))
bpm.logger.debug(LOG, "payload: %s" % bpm.context.payload)   # solo se ve si subimos el nivel

try:
    process(order_id)
    bpm.logger.info(LOG, "order %s approved OK" % order_id)
except Exception as e:
    bpm.logger.error(LOG, "order %s failed: %s" % (order_id, e))
    raise
```

Sesión de debugging desde el Coder:

```
# 1. Inspección rápida — empezamos por el log del proyecto
bpm_log_tail({ loggers: ["bpm.code.HLW"], lines: 50 })
bpm_log_grep({ pattern: "failed", loggers: ["bpm.code.HLW"], level: "ERROR", since: "1h" })

# 2. Si el script estalla antes de loguear, miramos el del engine de scripts
bpm_log_tail({ loggers: ["bpm.code"], lines: 100 })

# 3. Necesitamos ver el debug del payload — subimos el nivel temporalmente
bpm_log_level_set({ logger: "bpm.code.HLW", level: "DEBUG" })

# 4. Re-disparar el script y leer
bpm_log_tail({ loggers: ["bpm.code.HLW"], lines: 50 })

# 5. Cerrar el grifo
bpm_log_level_set({ logger: "bpm.code.HLW", level: "INHERIT" })
```

## 11. Cross-references

- `references/sdk-python.md` § `bpm.logger` — métodos disponibles, integración con `logging` stdlib via `BPMLoggingHandler`.
- `references/scripts-and-tools.md` § 5.1 — `bpm.logger` como parte de la API de `bpm` en cualquier rol de script.
- `references/pitfalls.md` — diagnóstico de "por qué no veo nada en mis logs" / "mi log apareció en `default.log`".
