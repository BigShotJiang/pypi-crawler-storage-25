# Python SDK (redflagbpm)

`redflagbpm` is the official Python client for the RedFlag BPM platform. It exposes a `BPMService` class that opens a connection to the backend and routes calls to business services: scripts, documents (Collections), runtime (BPMN processes and tasks), reports, agents, resources and notifications.

Use it from:

- **Script artifacts** of `lang: "Shell"` with a `#!python3` (or `#!/usr/bin/env python3`) shebang — the backend launches the script as a subprocess and the SDK picks up the connection details automatically.
- **External CPython processes** (3.7+) — point the client at the BPM host with `BPM_HOST` / `BPM_PORT` env vars.

The package also **bundles this skill** (`SKILL.md`, `references/`, `scripts/`) as resource data and ships an installer (`python3 -m redflagbpm.install_skill`) that drops it into `.claude/skills/bpm/`, `.opencode/skills/bpm/` and/or `.cursor/skills/bpm/` of the current project (or `~/`). See [Skill installer](#skill-installer) below.

> **Important**: there is no `bpm.execute(sql, ...)` helper. For SQL go through `redflagbpm.PgUtils` (Postgres) or `redflagbpm.MSSQLUtils` (SQL Server); for Collections through `bpm.documentService`. See "Common gotchas" below.

---

## Installation

```bash
pip install redflagbpm
```

Current version (this skill copy): `0.0.85` — bundled with the `redflagbpm` package that shipped it. The single source of truth is `sdk/python/pyproject.toml`. The package is published to PyPI by `sdk/python/deploy.sh`, which auto-increments the patch in `pyproject.toml`, rsyncs the `skills/bpm/` folder from the bpmapp repo into `src/redflagbpm/resources/skills/bpm/`, and stamps the new version into the bundled `references/`.

Required dependency: `vertx-eventbus-client`. For `PgUtils`, `psycopg2`. For `MSSQLUtils`, `pymssql`.

Python supported: CPython `>=3.7`. **Not Jython** — the in-process Script runtime (`lang: "Python"`) is a different surface and is not this SDK; see [Common gotchas](#common-gotchas).

---

## How a script gets invoked

The most common shape of a `redflagbpm` user script is a Shell-language artifact in a BPM project — for example, an action button on a query, a tool exposed to an agent, or an HTTP endpoint:

```python
#!python3
import redflagbpm
bpm = redflagbpm.BPMService()

# Read what the caller passed in
target = bpm.context.get("targetUser")

# Do work
bpm.service.notifyUser(target, "Done", "Operation complete")

# Send a structured reply to the caller (the action / endpoint / agent tool)
bpm.reply({"type": "MESSAGE", "statusMessage": f"Notified {target}"})
```

The backend sets `BPM_HOST`, `BPM_PORT` and `BPM_EVENT_BUS_REPLY` in the environment before launching the subprocess, so `BPMService()` connects without arguments and `bpm.reply(...)` answers the right caller.

### Picking which venv runs the script

The shebang on the first line decides which CPython interpreter (and therefore which set of `pip`-installed libraries) will run the script. BPM keeps a registry of named **venvs** that admins create and deploy from the UI; each one has a name, an installation path and its own `requirements.txt`. The two shebang forms a script writer needs:

| Shebang | What it runs |
|---|---|
| `#!python3` | The venv currently marked **DEFAULT** in the registry. Use it whenever the script doesn't need a specific library set — the resolved interpreter follows whichever venv the admin promoted. |
| `#!/app/files/BpmApp/venvs/<name>/bin/python3` | A specific named venv. Use it when the script needs libraries that only that venv has installed (e.g. `pandas`, `playwright`, `openai`). |

```python
# Default venv — works for most scripts
#!python3
import redflagbpm
bpm = redflagbpm.BPMService()

# Or pin to a specific venv that ships pandas
#!/app/files/BpmApp/venvs/data-science/bin/python3
import pandas as pd
import redflagbpm
bpm = redflagbpm.BPMService()
```

`redflagbpm` itself is installed automatically into every venv during deploy, so the `import redflagbpm; bpm = redflagbpm.BPMService()` boilerplate works regardless of which venv you pick. Anything else (`requests`, `pandas`, `pymssql`, …) must be in that venv's `requirements.txt` — there's no fallback to a system Python.

To add a new library, an admin edits the venv's `requirements.txt` from the **VENVs** menu and re-runs **Desplegar** (Deploy). The skill's `validate_python.sh` checker only verifies syntax, not imports — a missing library is a runtime error that surfaces only when the script actually runs.

The full management story (registry, deploy action, recreate-from-scratch flag, paths) is in `references/scripts-and-tools.md` § 4.1.

## Basic client (any context)

```python
import redflagbpm

# Connects to the BPM backend (auto-connect, auto-close at exit)
bpm = redflagbpm.BPMService()

# Notify a logged-in user
bpm.service.notifyUser("redflag", "Hello", "Message from Python")

# Explicit close — also runs at process exit
bpm.close()
```

`BPMService` works as a context manager:

```python
with redflagbpm.BPMService() as bpm:
    bpm.service.notifyUser("admin", "ping", "ok")
```

---

## Configuration

`BPMService.__init__(host=None, port=None, options=None, err_handler=None, ssl_context=None)` resolves the connection like this:

| Parameter | Default | Environment variable |
| --- | --- | --- |
| `host` | `localhost` | `BPM_HOST` |
| `port` | `7000` | `BPM_PORT` (read only when `BPM_HOST` is set) |
| reply address | (none) | `BPM_EVENT_BUS_REPLY` |

Relevant variables:

- `BPM_HOST`, `BPM_PORT` — TCP endpoint of the backend.
- `BPM_EVENT_BUS_REPLY` — the address the SDK uses to reply to the caller. The backend sets it automatically when it dispatches a script. **Without it (and without an explicit `address=` argument), the SDK enters "fake context" mode**: `reply`/`fail` print the payload to stdout and `context.x = ...` writes to an in-memory dict — useful for local tests, but a script that should reply to BPM will silently fail to do so.

Tunables:

- `bpm.call_timeout` — timeout in seconds for synchronous calls. Default `30.0`. For long-running scripts, prefer the `timeout=` argument on `bpm.service.execute(...)` (it adjusts both this and the underlying transport timeout for that call only).
- `bpm.delay` — sleep in seconds of the `start()` loop. Default `10`.

---

## Main API of `BPMService`

### Replying and failing

- `bpm.reply(body=None, address=None, headers=None)` — sends the result back to the caller (the BPM action, endpoint or selection that launched the script). In fake-context mode, prints `{"reply": body}` and `exit(0)`.
- `bpm.fail(message=None, do_quit=True, address=None, headers=None)` — sends an error response (`{"error": ..., "succeeded": False}`). When `message` is `None`, it uses the current Python traceback. By default the script terminates afterwards (`do_quit=True`).
- `bpm.text(...)`, `bpm.user`, `bpm.execute(sql, ...)` — **do not exist**. See [Common gotchas](#common-gotchas).

### Generic messaging

- `bpm.call(address, body=None, headers=None)` — synchronous request to a backend service address. Unpacks `body.reply` and raises `ServiceError` if `succeeded == False`. Most of the helpers under `bpm.service`, `bpm.documentService`, etc. are thin wrappers over this.
- `bpm.send(address, headers=None, body=None)` — like `call`, but returns the full envelope instead of unpacking the reply.
- `bpm.publish(address, body=None, headers=None)` — fire-and-forget.
- `bpm.request(request, address=None)` — raw request with `{"request": ...}` in the body.
- `bpm.exec(script, lang='juel', context=None, address=None)` — evaluates a JUEL/EL expression in the script context. Used internally by `bpm.context` and `bpm.execution` to read/write variables. **Not for SQL.**

### Connection and handlers

- `bpm.connect()` / `bpm.close()` / `bpm.isConnected()` / `bpm.stop()` — lifecycle. `close()` is also registered with `atexit`, so explicit close is rarely required.
- `bpm.register_handler(address, handler)` — registers a handler on the message bus. `handler` is a callable `(msg) -> None`. (A string can also be passed as a path to a Python script that the backend will run in a fresh subprocess.)
- `bpm.unregister_handler(address, handler=None)`.
- `bpm.run(address, handler)` — `register_handler` + `start()` (sleeps forever until KeyboardInterrupt).
- `bpm.register_app(app, prefix=None)` — exposes every route of a FastAPI app as a handler addressed by its path. Supports sync and `async` route functions.

### Script context (`bpm.context`)

`bpm.context` is a mutable proxy over the variables the BPM platform makes visible to the running script (form input, query selection, request parameters, identity injected by the launcher, etc.). Access by attribute or by index.

```python
# Read
name = bpm.context.name             # attribute style
name = bpm.context['name']          # item style
age  = bpm.context.get('age', 0)    # with default if the variable is missing

# Write
bpm.context.name = "Alice"
bpm.context['balance'] = 1000

# JSON sub-object: bpm.context.<obj>[<key>] = ...
bpm.context.myJson['field'] = "value"

# Input form fields specifically: bpm.context.input[<key>]
bpm.context.input['field'] = "value"

# Agent-tool args specifically: bpm.context.args[<key>] (when the script is
# invoked as a tool from an Agent — the LLM-supplied arguments live here,
# not at the top level of bpm.context).
viaje = bpm.context.args.get('viaje')
```

> **Three sub-bags, three roles.** `bpm.context.<key>` / `bpm.context.get(...)`
> reads the **top-level context** populated by Service / Action / HTTP /
> Selection launchers. `bpm.context.input` holds form-submitted values
> (Action scripts with `inputSchema`, form feedback). `bpm.context.args` holds
> the parameters the LLM filled in for an agent tool call (`properties.tool`).
> They are **disjoint** — reading one when the script's role is the other
> returns `None`. The most common bug: a tool script that does
> `bpm.context.get("foo")` instead of `bpm.context.args.get("foo")` and ends
> up with `None` regardless of what the LLM sent. See
> `references/scripts-and-tools.md` § 7 for the full tool authoring contract.

Two well-known JSON sub-objects:

- `bpm.context.json._requestHeaders` — incoming HTTP headers when the script runs as an endpoint, plus `x-user`, `x-ws-auth`, `x-method` injected by the dispatcher.
- `bpm.context.json._responseHeaders` — write `status`, `Content-Type`, `resource`, etc. to shape the HTTP response.

When there is no live connection to BPM (local tests), reads and writes fall back to an in-memory dict (`bpm.context.fakeContext`); reads also fall back to `os.environ` when a key is missing — handy for local dev, surprising in production if a typo accidentally resolves to a shell var.

> **Do not use `getattr(bpm.context, "x", None)` to default missing variables.** The context proxy raises `NameError` (not `AttributeError`) for missing keys, so `getattr`'s default is never returned and the call propagates the error. Use `bpm.context.get("x")` (or `bpm.context.get("x", default)`) instead.

> There is no `bpm.user` property. The caller's identity comes from `bpm.context.userId` (injected by Service / Query / Page launchers) or `bpm.context.json._requestHeaders["x-user"]` (HTTP endpoints). For programmatic / token launches, `userId` is only present if the caller passed it — guard with `bpm.context.get("userId")`.

Lower-level helpers used internally and available if needed:

- `bpm.context.getValue(expr, address=None)` — evaluate a JUEL expression against the live context (`bpm.context.x` is a thin wrapper for `${x}`).
- `bpm.context.setValue(name, value, address=None)`.
- `bpm.context.getJsonValue(obj, key, address=None)` / `setJsonValue(obj, key, value, address=None)`.
- `bpm.context.getInputValue(key, address=None)` / `setInputValue(key, value, address=None)`.

### No `bpm.execute(sql, ...)` method on the SDK

The SDK does NOT expose a direct SQL method on `BPMService`. For SQL use `redflagbpm.PgUtils` (Postgres) or `redflagbpm.MSSQLUtils`, which open connections to a datasource registered in BPM:

```python
from redflagbpm.PgUtils import get_connection

with get_connection(bpm, "my_datasource") as conn:
    with conn.cursor() as cur:
        cur.execute("SELECT id, name FROM people WHERE active = %s", (True,))
        for row in cur.fetchall():
            print(row)
```

`get_pool(bpm, datasource, max_connections=5)` returns a `psycopg2.pool.SimpleConnectionPool`. `get_dblink(bpm, datasource, ignore_host=True)` returns the connection string for a Postgres dblink.

Only supports `POSTGRES` dialect; raises `ValueError` for others (MSSQL datasources live in `MSSQLUtils`).

### Read-only DataSources (`preventDestructiveActions`)

A registered DataSource can be flagged as read-only by setting `preventDestructiveActions: true` on its definition (`DataSourceDTO`, configurable from the Conexiones a base de datos editor). The flag exists because some DataSources point at production replicas, audit/historical schemas, or third-party DBs where writes from the Coder are unacceptable under any circumstance.

#### Server-side enforcement (automatic)

`bpm_coder_sql_execute` rejects with `PERMISSION_DENIED` **before** asking the user for confirmation. Server-side, **non-overridable** — accepting the confirm dialog does NOT bypass it (the dialog never opens). This is the only path that's automatically protected.

#### Script-side enforcement (your responsibility)

Scripts (Python via `redflagbpm.PgUtils.get_connection` / `redflagbpm.MSSQLUtils.get_connection`, JDBC, anything that opens a connection by name) are **NOT** auto-blocked by the engine — the connection is opened normally and the driver doesn't know whether a statement is destructive without parsing it. The flag is a **hard contract** that you, the agent, must enforce.

**Mandatory protocol before writing SQL against a named DataSource:**

1. **Always check the flag first**. Either:
   - Call `bpm_coder_sql_databases` and look at `preventDestructiveActions` for that DataSource, OR
   - Read the DataSource record (`bpm_eb_document_read_by_id` against `@@@@@DATASOURCE_COLLECTION@@@@@` — but the tool above is more direct).

2. **If `preventDestructiveActions == true`**:
   - **Permitted**: `SELECT`, `WITH ... SELECT`, `SHOW`, `EXPLAIN`, `EXPLAIN ANALYZE`. (Read-only verbs only.)
   - **Forbidden** (in *any* form, including dynamic SQL, stored procedures with side effects, or `DO` blocks): `INSERT`, `UPDATE`, `DELETE`, `MERGE`, `REPLACE`, `UPSERT`, `COPY ... FROM` (write side), `TRUNCATE`, `ALTER`, `DROP`, `CREATE`, `RENAME`, `GRANT`, `REVOKE`, `VACUUM`, `REINDEX`, `LOCK`, `SET` (when it changes session/system state in a way the next caller observes), and any DDL/DCL/TCL not strictly read.
   - **Do NOT offer to "skip" or "override"** the flag at the user's request. If the user explicitly insists they need to write, the correct response is:
     > "Esta DB tiene `preventDestructiveActions=true`. No puedo generar sentencias destructivas contra ella. Si necesitás escribir, abrí el editor del DataSource y desactivá el flag, o conectate desde un script que use otro DataSource sin la restricción."

   Then stop. Do not author the script, do not ask follow-up questions about the SQL.

3. **If `preventDestructiveActions == false` (or absent)**: comportate normalmente — el dialog de confirm del Coder igual va a aparecer para sentencias destructivas vía `bpm_coder_sql_execute`, y para scripts el user revisa el código antes de guardar.

**Rationale**: the engine can't introspect arbitrary script SQL at runtime without overhead, and the production-grade defense (read-only DB users, network-segregated test envs, separate write/read DataSource entries) is the customer's responsibility. The flag is a fast, declarative way to tell the agent "no escrituras acá, ni preguntes". Honoring it cleanly is the difference between a useful Coder and a Coder that costs the customer real data.

---

## Services

Access to the backend's services through the client:

| Attribute | Class | Purpose |
| --- | --- | --- |
| `bpm.service` | `Service` | Mail, notifications, script/template execution, env, code, list, tokenize. |
| `bpm.context` | `Context` | Read/write of BPM context variables. |
| `bpm.execution` | `ExecutionService` | Operations on the current `execution` (variables, businessKey, processInstanceName). |
| `bpm.documentService` | `DocumentService` | CRUD over Collections (documents). |
| `bpm.resourceService` | `ResourceService` | Access to backend files/resources. |
| `bpm.runtimeService` | `RuntimeService` | BPMN process / task operations (start, signal, message, variables, task assignee/owner). |
| `bpm.reportService` | `ReportService` | Render Reports (Jasper PDF/XLSX/HTML). |
| `bpm.agentService` | `AgentService` | Agent orchestration (chat, WhatsApp, Telegram). |
| `bpm.logger` | `Logger` | Structured logging against the backend. |

### `bpm.service`

```python
bpm.service.execute(scriptId, context=None, timeout=None)
# Executes a BPM script by id (VTL template, agentic prompt, another
# Python/Shell script, etc.). For long-running scripts pass timeout
# in seconds — it widens the per-call deadline only.

bpm.service.sendMail({
    "from": "no-reply@company.com",
    "to": ["dest@company.com"],
    "subject": "Hello",
    "message": "<b>HTML body</b>",
    "attachments": {"invoice.pdf": "path/to/resource"},
})

bpm.service.notifyUser(user, title, description, target=None, sound=False)
bpm.service.notifyGroup(group, title, description, target=None, sound=False)

bpm.service.env()                 # dict with env vars exposed by BPM
bpm.service.now()                 # server timestamp
bpm.service.today()
bpm.service.nextBusinessKey(processKey)
bpm.service.getProperty(code, the_property)
bpm.service.text(name)            # text of a parameter (TEXT/...)
bpm.service.code(name)            # CODE/...
bpm.service.code_properties(name)
bpm.service.list(name, the_filter=None)
bpm.service.checkCron(cron)
bpm.service.tokenize(user, payload=None)
```

### `bpm.documentService` (Collections)

```python
ds = bpm.documentService

ds.registerCollection(schema)            # creates a collection
ds.unregisterCollection("MY_COLLECTION")
ds.listCollections()                     # List[str]
ds.getSchema("MY_COLLECTION")            # dict

oid = ds.create("MY_COLLECTION", {"name": "Ana"})
ds.createList("MY_COLLECTION", [{"name": "Ana"}, {"name": "Bea"}])

doc = ds.readById("MY_COLLECTION", "LOGICAL_ID")
doc = ds.readByOid(oid)
docs = ds.readList("MY_COLLECTION",
                   criteria="name = :n",
                   parameters={"n": "Ana"},
                   sorting="name asc")

ds.upsert("MY_COLLECTION", {"id": "X", "name": "Ana"})
ds.updateById("MY_COLLECTION", "X", {"name": "Ana M."})
ds.updateByOid("MY_COLLECTION", oid, {"name": "Ana M."})
ds.updateByCriteria("MY_COLLECTION", toSet={"active": False},
                    criteria="lastLogin < :d",
                    parameters={"d": "2024-01-01"})

ds.deleteById("MY_COLLECTION", "X")
ds.deleteByOid(oid)
ds.deleteByCriteria("MY_COLLECTION",
                    criteria="active = false")
```

### `bpm.runtimeService`

Process and task operations on the BPMN engine. Address everything by `executionId` (or `processInstanceId` for process-level operations).

```python
rt = bpm.runtimeService

# Start a process
pi = rt.startProcessInstanceByKey("myProcess", "BK-001",
                                  variables={"amount": 1000})

rt.startProcessInstanceByKeyAndTenantId(processKey, businessKey, tenantId, variables)
rt.startProcessInstanceById(processDefinitionId, businessKey, variables)
rt.startProcessInstanceByMessage("MSG_START", "BK-001", {})
rt.startProcessInstanceByMessageAndTenantId(messageName, businessKey, tenantId, variables)

# Lifecycle
rt.deleteProcessInstance(piId, "reason")
rt.updateBusinessKey(piId, "BK-002")
rt.getBusinessKey(piId)
rt.getProcessInstance(piId)
rt.setProcessInstanceName(piId, "Ana's request")

# Process / execution variables
rt.getVariables(executionId)
rt.getVariable(executionId, "amount")
rt.hasVariable(executionId, "amount")
rt.setVariable(executionId, "approved", True)
rt.removeVariable(executionId, "amount")

# Events delivered to a waiting execution
rt.signalEventReceived(executionId, "AUTHORIZED", processVariables={...})
rt.messageEventReceived(executionId, "MSG_OK", processVariables={...})

# Task ownership / assignment
rt.setTaskAssignee("user1", taskId="t-123")
rt.setTaskOwner("user1", processInstanceId=piId, taskName="Review")
```

> `setTaskOwner(priority=...)` is unreachable in the current SDK — only the `setTaskOwner(userId, ...)` form is callable. To set a task's priority, see `references/pitfalls.md`.

### `bpm.execution`

Shortcut to operate on the current `execution` without passing `executionId`:

```python
bpm.execution.getProcessInstanceId()
bpm.execution.getBusinessKey()
bpm.execution.updateBusinessKey("BK-NEW")
bpm.execution.setProcessInstanceName("Ana's request")
bpm.execution.getVariables()
bpm.execution.getVariable("amount")
bpm.execution.hasVariable("amount")
bpm.execution.setVariable("approved", True)
bpm.execution.removeVariable("amount")
```

### `bpm.reportService`

```python
opts = {"format": "PDF", "templatePath": "rep/invoice.jasper"}
data = {"invoiceId": "F-001", "items": [...]}

pdf_bytes = bpm.reportService.renderReport(opts, data)

multi = bpm.reportService.renderReports(opts, [data1, data2, data3])
```

### `bpm.resourceService`

Access BPM-managed files and per-job temporary storage.

```python
rs = bpm.resourceService

# Persistent resources (BPM filestore)
url  = rs.accessPath("share://invoice.pdf")        # URL the backend resolves
path = rs.accessFile("share://invoice.pdf")        # absolute local path

# Per-job temporary storage
tmp_url  = rs.accessTempPath("tmp://job123/out.csv")
tmp_path = rs.accessTempFile("tmp://job123/out.csv")

info  = rs.getResourceInfo("share://invoice.pdf")  # metadata
items = rs.listPaths("share://folder")             # children of a folder
```

`accessFile` / `accessTempFile` are the most common — they return a path you can `open(...)` directly. For an HTTP endpoint that serves a large download, prefer setting `bpm.context.json._responseHeaders["resource"] = path` instead of buffering through stdout.

### `bpm.agentService`

Agentic chat orchestration:

```python
def on_msg(msg):
    print("agent said:", msg["body"])

chatId = bpm.agentService.startChat(
    agent="MY_AGENT",
    userId="redflag",
    handler=on_msg,
    body={"initialContext": "..."}
)

bpm.agentService.chat(chatId, "Hello")
bpm.agentService.endChat(chatId)

# Other channels
bpm.agentService.startWhatsappChat(agent, userId, wp_template,
                                   language, values, mission)
bpm.agentService.startTelegramChat(agent, userId, message, mission)
```

`startChat` registers a handler on the bus against the `address` returned by the backend; `endChat` unregisters it.

### `bpm.logger`

The first argument is the **logger name**, which determines the **file on disk** where the line is written: each unique name produces a separate `<name>.log` in the BPM logs directory (`/` characters are normalized to `.`). Pick a stable name per project/module — `bpm.code/<PROJECT>` for project code, `bpm.security` for audit, `bpm.<modulo>` for cross-cutting modules.

```python
bpm.logger.info("bpm.code/HLW", "starting")
bpm.logger.warn("bpm.code/HLW", "slow")
bpm.logger.error("bpm.code/HLW", "boom")
bpm.logger.debug("bpm.code/HLW", "value=42")
bpm.logger.trace("bpm.code/HLW", "...")
# Generic
bpm.logger.log("bpm.code/HLW", "msg", level="info")
```

To reuse `logging` stdlib, there is a handler that forwards to the backend (see `redflagbpm/Logging.py`):

```python
import logging
from redflagbpm.Logging import BPMLoggingHandler

logger = logging.getLogger("bpm.code/HLW")
logger.setLevel(logging.DEBUG)
logger.addHandler(BPMLoggingHandler(bpm))
logger.info("now logging against BPM")
```

See `references/logging.md` for naming conventions, file/rotation layout, and the Coder tools (`bpm_log_list`, `bpm_log_tail`, `bpm_log_grep` for reading; `bpm_log_level_list`, `bpm_log_level_set` for tweaking levels in runtime).

---

## Skill installer

`pip install redflagbpm` ships this entire skill (`SKILL.md`, `references/`, `scripts/`) as package data under `redflagbpm/resources/skills/bpm/`. To make a Claude Code, opencode or Cursor session see it, copy it into the right per-client folder with:

```bash
# Auto: detects which of .claude/, .opencode/, .cursor/ exist in the cwd
# and installs the skill into each. If none are detected, installs for all three.
python3 -m redflagbpm.install_skill
# Equivalent shorter alias (same module under the hood):
redflagbpm-install-skill
```

Common variants:

```bash
# Install only for one client:
python3 -m redflagbpm.install_skill --client claude
python3 -m redflagbpm.install_skill --client opencode
python3 -m redflagbpm.install_skill --client cursor

# Install for all three explicitly:
python3 -m redflagbpm.install_skill --client all

# Install at user level (~/.claude/skills/bpm/, etc.) instead of cwd:
python3 -m redflagbpm.install_skill --user

# Override the destination (skill is copied as <target>/bpm):
python3 -m redflagbpm.install_skill --target /path/to/dir

# Symlink instead of copy — handy in dev (changes to the package source
# are reflected immediately):
python3 -m redflagbpm.install_skill --symlink

# Show the targets that would be written, without making changes:
python3 -m redflagbpm.install_skill --list

# Remove the skill from the resolved targets:
python3 -m redflagbpm.install_skill --uninstall
```

### Per-client install paths

The installer writes to:

| Client                       | Path under `<root>` |
|------------------------------|---------------------|
| Claude Code / Claude Desktop | `.claude/skills/bpm/`   |
| opencode                     | `.opencode/skills/bpm/` |
| Cursor                       | `.cursor/skills/bpm/`   |

`<root>` is the current directory by default, or `~/` with `--user`. The installer creates the parent folder if missing. Existing installations are replaced; pass `--force` to skip the warning.

### Updating

Re-running the installer overwrites the previous copy with the version that came in the latest `pip install --upgrade redflagbpm`. There is no separate sync command — `python3 -m redflagbpm.install_skill` is idempotent.

---

## Local testing without a backend

You can exercise the client without a live BPM connection. Two modes:

```python
import redflagbpm

# (1) "Fake context" — no host, no reply address. Useful for unit tests.
bpm = redflagbpm.BPMService()         # connects if BPM_HOST is set, otherwise fails
bpm.context['name'] = "Ana"           # goes into an in-memory dict
print(bpm.context['name'])
bpm.reply("Hello Ana")                # prints {"reply": "Hello Ana"} and exits(0)
```

For end-to-end tests against a running backend, point `BPM_HOST` / `BPM_PORT` at it; export `BPM_EVENT_BUS_REPLY` with a known address and call `bpm.run(address, handler)` to behave as if the script had been dispatched by the platform.

---

## Examples

### Simple script returning a message

```python
import redflagbpm

bpm = redflagbpm.BPMService()
name = bpm.context.get("name", "world")
bpm.reply({"greeting": f"Hello, {name}"})
```

### Script with SQL and reply

```python
import redflagbpm
from redflagbpm.PgUtils import get_connection

bpm = redflagbpm.BPMService()
ds = bpm.context["datasource"]   # datasource name

with get_connection(bpm, ds) as conn, conn.cursor() as cur:
    cur.execute(
        "SELECT id, name FROM customers WHERE active = %s LIMIT 50",
        (True,),
    )
    rows = [{"id": r[0], "name": r[1]} for r in cur.fetchall()]

bpm.reply({"customers": rows})
```

### Invoke another BPM script

```python
template = bpm.service.execute("REPORTS/INVOICE_TEMPLATE",
                               {"id": "F-001"})
print(template)

# Long agentic workflow: raise the timeout
response = bpm.service.execute("AGENTS/LEGAL_REVIEWER",
                               {"text": contract},
                               timeout=300)
```

### Start a process

```python
pi = bpm.runtimeService.startProcessInstanceByKey(
    processDefinitionKey="creditRequest",
    businessKey=bpm.service.nextBusinessKey("creditRequest"),
    variables={"amount": 50000, "customer": "C-123"},
)
bpm.reply({"processInstanceId": pi["id"]})
```

### Chat with an agent

```python
import threading

done = threading.Event()
responses = []

def handler(msg):
    body = msg.get("body") or {}
    responses.append(body)
    if body.get("end"):
        done.set()

chat_id = bpm.agentService.startChat("LEGAL_ADVISOR", "redflag", handler)
bpm.agentService.chat(chat_id, "Summarize this contract in 3 points.")
done.wait(timeout=120)
bpm.agentService.endChat(chat_id)

bpm.reply({"responses": responses})
```

### Install the BPM skill into a Claude Code / Cursor / opencode project

```bash
cd <my-bpm-project>
pip install --upgrade redflagbpm
python3 -m redflagbpm.install_skill --client all
```

This drops the bundled skill into `.claude/skills/bpm/`, `.opencode/skills/bpm/`, and `.cursor/skills/bpm/` of the project. Re-run after every `pip install --upgrade redflagbpm` to refresh the skill to the package's bundled version. See [Skill installer](#skill-installer) for all options.

---

## Common gotchas

- **CPython, not Jython.** This SDK runs under CPython 3.7+ (it depends on `vertx-eventbus-client` and `psycopg2`). The in-process Script runtime (`lang: "Python"`) is a different engine on the platform side — a script written for that runtime is not this SDK. For real Python with PyPI packages, use `lang: "Shell"` with a `#!python3` shebang.
- **`bpm.execute(sql, ...)` does not exist.** What is callable is `bpm.service.execute(scriptId, context, timeout)` (runs another script by id) and `bpm.exec(script, lang='juel', context=...)` (evaluates JUEL/EL — not SQL). For SQL use `PgUtils.get_connection`/`get_pool` (Postgres) or `MSSQLUtils`. Old docs that show `bpm.execute(sql, ...)` are wrong; treat them as a phantom API.
- **No `bpm.user`.** Read identity from `bpm.context.userId` (UI launchers) or `bpm.context.json._requestHeaders["x-user"]` (HTTP endpoints).
- **No address = fake mode.** Without `BPM_EVENT_BUS_REPLY` and without an explicit `address=`, `reply` prints `{"reply": ...}` and `exit(0)`, and `context.x = ...` writes only to an in-memory dict. Great for local tests; if BPM is expecting a real reply this is a silent failure.
- **`bpm.reply` may `exit(0)`.** Only in the no-address path. If your script has cleanup after `reply`, make sure a valid address is set first.
- **Timeouts.** `bpm.call_timeout` (default 30s) applies to every synchronous call. For long-running scripts call `bpm.service.execute(scriptId, context, timeout=300)` — that argument is scoped to the single call.
- **One thread per `BPMService`.** The reply address is stored per thread. Don't share one client across worker threads; create one per thread, or reply only from the same thread that received the request.
- **Datasource dialect.** `PgUtils` raises `ValueError("Only POSTGRES dialect is supported: ...")` for non-Postgres datasources. MSSQL datasources go through `redflagbpm.MSSQLUtils`.
- **Datasource autocommit.** `PgUtils.get_connection(...)` and `MSSQLUtils.get_connection(...)` both return connections with `autocommit=True`. To run an explicit transaction, set `conn.autocommit = False` right after acquiring the connection.
- **`setTaskOwner(priority=...)` is unreachable.** Only `setTaskOwner(userId, ...)` is callable in the current SDK; the priority overload is shadowed. Use the runtime call directly until the SDK splits the methods — see `references/pitfalls.md`.
- **`DocumentService.deleteByCriteria(...)` is broken.** It currently dispatches to `updateByCriteria` and does not delete. Workaround in `references/pitfalls.md`.
- **`getattr(bpm.context, "x", None)` doesn't default.** The proxy raises `NameError`, so `getattr`'s default is never returned. Use `bpm.context.get("x")`.

---

## Cross-references

- `references/scripts-and-tools.md` — how a script artifact is wired (`.config`, `lang`, shebang, action / tool / endpoint roles). What you pass to `bpm.service.execute(scriptId, context)` is resolved against the project's script artifacts.
- `references/agents-and-rag.md` — agent definition (what `bpm.agentService.startChat` expects, message format, chat lifecycle).
- `references/endpoints.md` — how `bpm.context.json._requestHeaders` / `_responseHeaders` shape the HTTP request / response.
- `references/pitfalls.md` — full list of silent-failure cases referenced from the gotchas above.
