"""Validate McpInfo YAML.

McpInfo is the CodeDTO with `type: Mcp`. It declares a profile-scoped
allowlist of MCP tools/resources/prompts. The Java source of truth is
`src/main/java/dev/redflag/core/services/info/McpInfo.java`.

This validator catches the common authoring mistakes that produce
"login OK but tools/list returns empty":

  * Using `tools:` instead of `toolList:` (silently dropped by Jackson →
    empty allowlist → 0 tools for the user).
  * Writing scalar instead of list for `targetUsers` / `targetGroups` /
    `toolList` / `resources` (`targetGroups: "ADMIN"` instead of
    `targetGroups: ["ADMIN"]`) — Jackson can't coerce, field stays default-empty.
  * Bad `profile` value (must be lowercase `coder`/`external`/`analyst`,
    or omitted to apply to all).
  * Listing plugin-only tools (`bpm_bash`, `bpm_read`, ...) — plugin tools
    are global and never go through McpInfo allowlists.
"""
from __future__ import annotations

from typing import Any

from .common import (
    Severity,
    ValidationResult,
    check_required_fields,
    check_unknown_keys,
)
from .enums import (
    CONFIRM_POLICY_VALUES,
    MCP_ALL_FIELDS,
    MCP_REQUIRED_FIELDS,
    MCP_VALID_PROFILES,
)


_PLUGIN_TOOLS = {
    "bpm_bash", "bpm_read", "bpm_write", "bpm_edit",
    "bpm_glob", "bpm_grep", "bpm_ask_user",
}

_LIST_FIELDS = ("targetUsers", "targetGroups", "toolList", "resources")


def validate(body: Any, config: Any, result: ValidationResult) -> None:
    if not isinstance(body, dict):
        result.error("not-a-mapping", "Mcp body must be a YAML mapping")
        return

    check_required_fields(result, body, MCP_REQUIRED_FIELDS)
    check_unknown_keys(result, body, MCP_ALL_FIELDS, severity=Severity.WARNING)

    # The most common authoring mistake: `tools:` instead of `toolList:`.
    # Jackson silently drops the unknown key — the user sees 0 tools at runtime.
    if "tools" in body and "toolList" not in body:
        result.error(
            "mcp-tools-not-toollist",
            "Field is `toolList`, NOT `tools` (an `AnalystInfo` uses `tools` but "
            "an `McpInfo` uses `toolList`). Rename `tools:` → `toolList:` or the "
            "MCP server will return an empty tool list to the user.",
            "tools",
        )

    # `profile` must be one of the known values (or omitted = applies to all).
    profile = body.get("profile")
    if profile is not None:
        if not isinstance(profile, str):
            result.error(
                "mcp-bad-profile-type",
                "profile must be a string (or omitted to apply to all profiles)",
                "profile",
            )
        elif profile not in MCP_VALID_PROFILES:
            result.error(
                "mcp-unknown-profile",
                f"profile must be one of {sorted(MCP_VALID_PROFILES)} or omitted; "
                f"got {profile!r}. Profiles are case-sensitive lowercase.",
                "profile",
            )

    # `confirmPolicy`: must be one of destructive/all/none (or omitted = default destructive).
    confirm_policy = body.get("confirmPolicy")
    if confirm_policy is not None:
        if not isinstance(confirm_policy, str):
            result.error(
                "mcp-bad-confirm-policy-type",
                "confirmPolicy must be a string (one of "
                f"{sorted(CONFIRM_POLICY_VALUES)}) or omitted",
                "confirmPolicy",
            )
        elif confirm_policy not in CONFIRM_POLICY_VALUES:
            result.error(
                "mcp-unknown-confirm-policy",
                f"confirmPolicy must be one of {sorted(CONFIRM_POLICY_VALUES)} "
                f"or omitted (default: destructive); got {confirm_policy!r}. "
                "Lowercase only.",
                "confirmPolicy",
            )

    # All list-shaped fields must actually be lists. Catches
    # `targetGroups: ADMIN` (string) → field deserializes to empty.
    for field in _LIST_FIELDS:
        if field not in body:
            continue
        value = body[field]
        if value is None:
            continue
        if not isinstance(value, list):
            result.error(
                f"mcp-{_dash(field)}-not-a-list",
                f"`{field}` must be a YAML list, got {type(value).__name__}. "
                f"Even with one entry, write `{field}: [<value>]` (not "
                f"`{field}: <value>`).",
                field,
            )
            continue
        for i, item in enumerate(value):
            if not isinstance(item, str):
                result.error(
                    f"mcp-{_dash(field)}-non-string",
                    f"`{field}[{i}]` must be a string, got {type(item).__name__}",
                    f"{field}[{i}]",
                )

    # `prompts` must be a mapping name → template string.
    prompts = body.get("prompts")
    if prompts is not None and not isinstance(prompts, dict):
        result.error(
            "mcp-prompts-not-a-map",
            "`prompts` must be a YAML mapping (name → template string)",
            "prompts",
        )
    elif isinstance(prompts, dict):
        for name, tpl in prompts.items():
            if not isinstance(tpl, str):
                result.warning(
                    "mcp-prompt-not-string",
                    f"prompts.{name} should be a string template; "
                    f"got {type(tpl).__name__}",
                    f"prompts.{name}",
                )

    # toolList: warn on plugin-only tools (no-op listing them here).
    tool_list = body.get("toolList")
    if isinstance(tool_list, list):
        for i, name in enumerate(tool_list):
            if not isinstance(name, str):
                continue
            if name in _PLUGIN_TOOLS:
                result.warning(
                    "mcp-plugin-tool-listed",
                    f"`{name}` is a plugin tool (global, always available). "
                    "Listing it in McpInfo.toolList is a no-op — the plugin "
                    "exposes these directly without going through MCP.",
                    f"toolList[{i}]",
                )


def _dash(field: str) -> str:
    """camelCase → kebab-case for issue codes."""
    out = []
    for ch in field:
        if ch.isupper():
            out.append("-")
            out.append(ch.lower())
        else:
            out.append(ch)
    return "".join(out)
