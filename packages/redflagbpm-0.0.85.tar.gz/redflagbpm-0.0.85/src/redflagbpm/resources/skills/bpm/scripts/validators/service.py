"""Validate Service artifact YAML (ServiceInfo shape)."""
from __future__ import annotations

from typing import Any

from .common import Severity, ValidationResult, check_regex
from .enums import (
    IPO_RESPONSE_TYPES,
    REQUEST_URL_RE,
    SERVICE_RESPONSE_TYPES,
    SERVICE_RESPONSE_TYPES_REQUIRING_TARGET,
)
from .form import validate as validate_form


# Union of configurator-side and runtime-side accepted values.
_ACCEPTED_RESPONSE_TYPES = IPO_RESPONSE_TYPES | SERVICE_RESPONSE_TYPES


def validate(body: Any, config: Any, result: ValidationResult) -> None:
    if not isinstance(body, dict):
        result.error("not-a-mapping", "Service body must be a YAML mapping")
        return

    if not body.get("caption"):
        result.warning("missing-caption", "caption is recommended", "caption")

    # requestUrl
    request_url = body.get("requestUrl")
    if not request_url:
        result.error("missing-request-url",
                     "requestUrl is required", "requestUrl")
    else:
        check_regex(result, request_url, REQUEST_URL_RE,
                    "bad-request-url", "requestUrl", Severity.ERROR)

    # responseType
    rt = body.get("responseType")
    if not rt:
        result.error("missing-response-type",
                     "responseType is required", "responseType")
    elif rt not in _ACCEPTED_RESPONSE_TYPES:
        # Common case: lowercase
        if isinstance(rt, str) and rt.upper() in _ACCEPTED_RESPONSE_TYPES:
            result.error(
                "response-type-case",
                f"responseType {rt!r} must be UPPERCASE — try {rt.upper()!r}",
                "responseType",
            )
        else:
            result.error(
                "bad-response-type",
                f"responseType {rt!r} not in accepted set "
                f"(configurator-common: {sorted(SERVICE_RESPONSE_TYPES)}, "
                f"runtime: {sorted(IPO_RESPONSE_TYPES)})",
                "responseType",
            )

    # responseTarget required for QUERY/REPORT/SERVICE
    if isinstance(rt, str) and rt in SERVICE_RESPONSE_TYPES_REQUIRING_TARGET:
        if not body.get("responseTarget"):
            result.error(
                "missing-response-target",
                f"responseTarget is required when responseType is {rt!r}",
                "responseTarget",
            )

    # inputSchema must be a JSON Schema object
    input_schema = body.get("inputSchema")
    if input_schema is not None and input_schema != {}:
        if not isinstance(input_schema, dict):
            result.error("input-schema-not-mapping",
                         "inputSchema must be a mapping", "inputSchema")
        else:
            sub = ValidationResult(file=result.file, artifact_type="form")
            validate_form(input_schema, None, sub)
            for issue in sub.issues:
                issue.path = f"inputSchema.{issue.path}" if issue.path else "inputSchema"
                result.issues.append(issue)

    # requestOptions must be a mapping
    request_options = body.get("requestOptions")
    if request_options is not None and request_options != {} \
            and not isinstance(request_options, dict):
        result.error("request-options-not-mapping",
                     "requestOptions must be a mapping (JsonObject)",
                     "requestOptions")
