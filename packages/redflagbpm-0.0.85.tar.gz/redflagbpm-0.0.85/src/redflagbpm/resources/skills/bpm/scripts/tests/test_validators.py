"""Smoke tests for the validator suite.

For each fixture under `fixtures/valid/`, expect zero errors.
For each fixture under `fixtures/invalid/`, expect at least one error.

Filenames double as the validator hint via prefix mapping.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

# Make scripts/ importable when running pytest from anywhere.
SCRIPTS_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from validate import validate_path  # noqa: E402


FIXTURES_DIR = Path(__file__).parent / "fixtures"

# Filename prefix -> --type to force (so prefixes drive the dispatch).
TYPE_OVERRIDES = {
    "query":          "query",
    "service":        "service",
    "form":           "form",
    "agent":          "agent",
    "prompt":         "prompt",
    "kanban":         "kanban",
    "value_provider": "value_provider",
    "menu":           "menu",
    "repo":           "repo",
    "analyst":        "analyst",
    "sandbox":        "sandbox",
    "config_file":    "config_file",
}


def _explicit_type(path: Path) -> str | None:
    name = path.stem
    for prefix, t in TYPE_OVERRIDES.items():
        if name.startswith(prefix):
            return t
    return None


def _list_fixtures(subdir: str) -> list[Path]:
    return sorted((FIXTURES_DIR / subdir).rglob("*.yaml*"))


@pytest.mark.parametrize("path", _list_fixtures("valid"),
                         ids=lambda p: p.name)
def test_valid_fixture_has_no_errors(path: Path) -> None:
    result = validate_path(path, _explicit_type(path))
    assert not result.errors, (
        f"{path.name} should have no errors, got: "
        f"{[(i.code, i.message) for i in result.errors]}"
    )


@pytest.mark.parametrize("path", _list_fixtures("invalid"),
                         ids=lambda p: p.name)
def test_invalid_fixture_has_errors(path: Path) -> None:
    result = validate_path(path, _explicit_type(path))
    assert result.errors, (
        f"{path.name} should have at least one error, got only warnings/info: "
        f"{[(i.code, i.message) for i in result.issues]}"
    )
