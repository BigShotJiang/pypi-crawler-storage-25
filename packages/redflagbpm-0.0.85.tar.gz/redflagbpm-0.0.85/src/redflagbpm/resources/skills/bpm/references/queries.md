# Queries

Queries define how tabular data is retrieved, displayed, filtered, and acted upon. They are authored as YAML artifacts paired with a `.config` file (`type: "Query"`, `lang: "YAML"`). Use a Query whenever a user needs to browse, filter, sort, drill down, or trigger actions on a result set sourced from a SQL connection, a Collection, or a JSON/REST endpoint.

> **Source of truth**: `dev/redflag/core/services/info/ColumnInfo.java`, `dev/redflag/core/services/info/FilterInfo.java`, `dev/redflag/core/services/info/FilterGroupInfo.java`, `dev/redflag/core/services/ipo/Action.java`. The Java code wins when it disagrees with the developer guide.
>
> **See also**: `references/templates.md` (custom row rendering), `references/value-providers.md` (filter dropdowns), `references/services.md` (action targets), `references/artifacts-and-config.md` (the sibling `.config` file).

---

## Recipe — create a Query from scratch

In order. Don't skip the validator.

1. **Decide the id and project**: `PROJECT/QRY_ID` (uppercase, underscores).
2. **Create the body** `path/to/QRY_FOO.yaml` (see § Top-level fields). Start with the minimal `dataSource` + `columns` + `view` and grow from there.
3. **Create the `.config` sibling** `path/to/QRY_FOO.yaml.config`:
   ```yaml
   project: "MYPROJ"
   id: "MYPROJ/QRY_FOO"
   lang: "YAML"
   type: "Query"
   description: "…"
   properties: null
   ```
4. **Wire actions if any** (`details`, `scripts`, `services`, `reports`, `postProcessors`). Each entry is a Script id; the Script's `.config.properties` declares the action shape (caption, icon, type, selectionScope — see `references/scripts-and-tools.md` § 3).
5. **Validate** before declaring done — `--strict` is the contract:
   ```bash
   "$BPM_SKILL_DIR/scripts/validate.py" --strict path/to/QRY_FOO.yaml.config
   ```
6. **Smoke-test** the Query by navigating to `Query?__query__=MYPROJ/QRY_FOO` (or via a menu link). If you can't drive the browser, leave a clear note for the user instead of claiming "listo".

---

## Top-level fields

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | string | optional | Full identifier `PROJECT/QUERY_ID` (usually derived from filename). |
| `caption` | string | recommended | Visible title at the top of the grid. |
| `icon` | string | optional | Vaadin icon name (e.g. `SHOPPING_CART`) or custom icon. |
| `dataSource` | string | conditional | Connection name (SQL), `run:PROJECT/SCRIPT_ID` (script JSON), `https?://...` (REST), or `curl ...` (CURL). Optional when `dataSourceOptions.collection` is set. |
| `view` | string | conditional | SQL `SELECT` for SQL data sources. **Omit** for Collections and JSON/REST sources. |
| `viewBindings` | string[] | optional | Names of context/filter values bound to `?` placeholders in `view`, in order. |
| `stringFormat` | string | optional | Display template for value-provider mode, e.g. `"%{id} - %{caption}"`. |
| `template` | string | optional | Polymer/Vaadin template for custom row rendering. See `references/templates.md`. |
| `defaultFilterExpression` | string | optional | SQL expression used by the global search box. Uses `?` placeholders, **not** `::value::`. |
| `columns` | object[] | recommended | Column definitions. See [Columns](#columns). |
| `keys` | string[] | recommended | Primary key field names. May reference hidden fields. |
| `sortables` | string[] | optional | Field names enabled for client-side sorting. |
| `targetUsers` | string[] | optional | Specific usernames allowed (empty = all users). |
| `targetGroups` | string[] | optional | Group names allowed to access the query. |
| `menus` | string[] | optional | Menu locations where the query appears. |
| `filterGroup` | object | optional | Filter form configuration. See [Filter groups](#filter-groups). |
| `details` | string[] | optional | Query IDs opened as drill-down details on selection. |
| `reports` | string[] | optional | Report IDs available from the toolbar. |
| `services` | string[] | optional | Service IDs available from the toolbar. |
| `scripts` | string[] | optional | Script IDs invokable from the toolbar. |
| `postProcessors` | string[] | optional | Script IDs run for each row retrieved. See `references/templates.md` (post-processors section). |
| `context` | object | optional | Initial context values merged into execution scope (filters, bindings, scripts). |
| `initContextScript` | string | optional | JavaScript executed before the query, with access to `context`. |
| `selectionScript` | string | optional | Script executed on every selection change; sees `bpm.context.selection`. |
| `dataSourceOptions` | object | optional | Source-type-specific tuning (collection ID, JQ filter, page size, CRUD flags, etc.). |
| `options` | object | optional | UI/behavior tuning (`pageSize`, `themeVariants`, `htmlColumns`, `frozenColumns`, `classColumn`, `crud`, `exportable`, `autorefresh`). |
| `debug` | boolean | optional | Print SQL to browser console (default `false`). |
| `waitForFilter` | boolean | optional | If `true`, query does not run until the user applies filters. |
| `exportable` | boolean | optional | Enable Excel export. May also live under `options`. |
| `autorefresh` | integer | optional | Auto-refresh period in seconds. May also live under `options`. |

---

## Data sources

The data source type is determined by `dataSource`/`dataSourceOptions`. **They are mutually exclusive** — pick exactly one.

Detection order (first match wins):

1. **Collection** — `dataSourceOptions.collection` or `options.collection` is set, or `options.crud: true`.
2. **Script (JSON)** — `dataSource` starts with `run:`.
3. **REST (JSON)** — `dataSource` matches `http://` or `https://`.
4. **CURL (JSON)** — `dataSource` starts with `curl `.
5. **SQL** — default.

### SQL

```yaml
dataSource: "NORTHWIND"
view: |
  SELECT order_id, customer_id, order_date, total_amount
  FROM orders
  WHERE status = ?
viewBindings:
  - status
dataSourceOptions:
  onOpen: "SET SESSION group_concat_max_len = 10240"
  onClose: "COMMIT"
  where: "deleted = false"
  orderBy: "order_date DESC"
  pageSize: 100
  timeout: 30000
  canCreate: true
  canUpdate: true
  canDelete: true
```

`?` placeholders in `view` are bound positionally from `viewBindings` (each entry is a context/filter key). Filter expressions with `::value::` are supported.

### Collection

```yaml
dataSourceOptions:
  collection: "PROJECT/ORDERS_COLLECTION"
# view is omitted
```

For full CRUD on a Collection:

```yaml
options:
  crud: true
  collection: "PROJECT/ORDERS_COLLECTION"
```

Filter expressions use PostgreSQL JSONB operators.

### JSON / REST

Three flavors, all without a `view`:

```yaml
# A. Script: must return JSON array (one row per element) or object (single row)
dataSource: "run:PROJECT/FETCH_ORDERS_SCRIPT"

# B. URL
dataSource: "https://api.example.com/v1/orders"

# C. CURL
dataSource: "curl -X GET https://api.example.com/v1/orders -H 'Authorization: Bearer ${token}'"

dataSourceOptions:
  filter: ".items[] | select(.status == \"active\")"   # JQ expression
  pageSize: 100
  timeout: 30000
```

JSON/REST queries **do not support `::value::` filter expressions**; filters are applied client-side, or pre-shaped via `dataSourceOptions.filter` (JQ).

---

## Columns

Defined in `dev/redflag/core/services/info/ColumnInfo.java`. Only fields listed in `columns` render in the grid; other fields returned by the source remain available to scripts, `keys`, `postProcessors`, and `bpm.context.selection` ("hidden columns").

### Field reference

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | string | yes | Must match a column in the SQL `SELECT`, a Collection field, or a JSON property. |
| `caption` | string | yes | Header label shown in the grid. |
| `fieldType` | string | yes | See closed set below. |
| `format` | string | optional | Java `NumberFormat` / `SimpleDateFormat` pattern (e.g. `"#,##0.00"`, `"yyyy-MM-dd"`). |
| `width` | integer | optional | Numeric magnitude only. Pair with `widthType` for the unit. See [width and widthType](#width-and-widthtype). |
| `widthType` | string | optional | Unit of `width`: `px`, `em`, `rem`, `%`, or `flex`. Default if omitted: flex weight. |
| `align` | string | optional | `START`, `CENTER`, or `END`. |
| `valueProvider` | string | optional | Per-cell value provider, e.g. `"PROJECT/VP_STATUSES"`. |
| `template` | string | optional | Per-column inline template (see `references/templates.md`). |

### `fieldType` (column)

Documented set: `string`, `integer`, `decimal`, `date`, `datetime`, `boolean`.

`ColumnInfo.fieldType` is a free-form string; the validator additionally accepts `number` and `null`. **Common values (validator: warning if other)** — citation: `dev/redflag/core/services/info/ColumnInfo.java`, `skills/bpm/scripts/validators/enums.py:COLUMN_FIELD_TYPES`.

```yaml
columns:
  - name: total_amount
    caption: "Total"
    fieldType: decimal
    format: "#,##0.00"
    align: END
    width: 120
    widthType: px
```

### `align`

**Closed set** (validator: error if other): `START`, `CENTER`, `END`. Citation: `dev/redflag/core/services/info/ColumnInfo.java`.

### Width and widthType

Citation: `dev/redflag/core/services/info/ColumnInfo.java` (`Integer width` + `String widthType`).

Width is a **two-field pair**: `width` is the numeric magnitude (integer), `widthType` is the unit (string). Combine them at runtime to form CSS values like `120px`, `1em`, `25%`, etc.

| `widthType` | Effect |
|---|---|
| `px` | Pixels. `width: 120` + `widthType: px` → 120 px. |
| `em` | Relative to font size. |
| `rem` | Relative to root font size. |
| `%` | Percentage of grid width. |
| `flex` | Flex weight. `width: 2` + `widthType: flex` → twice the share of `width: 1, widthType: flex`. |
| _(omitted)_ | Default treatment is a flex weight (same as `widthType: flex`). |

Examples:

```yaml
columns:
  - {name: id,         caption: "ID",      fieldType: integer, width: 80,  widthType: px}
  - {name: customer,   caption: "Cliente", fieldType: string,  width: 2,   widthType: flex}
  - {name: order_date, caption: "Fecha",   fieldType: date,    width: 25,  widthType: "%"}
  - {name: notes,      caption: "Notas",   fieldType: string,  width: 1}    # default = flex weight
```

**Closed set** for `widthType` (validator: error if other): `px`, `em`, `rem`, `%`, `flex`. Citation: `skills/bpm/scripts/validators/enums.py:COLUMN_WIDTH_TYPES`.

### Hidden columns

To keep a field available without rendering it, include it in the `SELECT` / Collection document / JSON payload but **omit it from `columns`**. Hidden fields can still appear in `keys`, `sortables`, scripts, and exports.

```yaml
view: |
  SELECT order_id, customer_id, internal_notes, status_code
  FROM orders
columns:
  - {name: order_id,    caption: "Order ID", fieldType: integer}
  - {name: customer_id, caption: "Customer", fieldType: string}
  # internal_notes and status_code are hidden but available in scripts
keys: [order_id]
```

---

## Filter groups

`filterGroup` builds a form (rendered as JSON-Schema-driven UI) that produces filter values for the query. Source: `dev/redflag/core/services/info/FilterGroupInfo.java`.

### Group fields

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | string | recommended | Internal group identifier. |
| `caption` | string | recommended | Form title shown to the user. |
| `description` | string | optional | Subtitle text inside the form. |
| `callToAction` | string | optional | Label of the apply button (e.g. `"Filter"`). |
| `header` | string (HTML) | optional | Rendered above the filters. |
| `summary` | string (HTML) | optional | Rendered below the filters. |
| `formDisposition` | string | optional | Field layout, comma- or semicolon-separated. `field2:2` sets colspan = 2. |
| `defaultFilter` | object | optional | Initial filter values (JSON). See [Default filter](#default-filter-and-js-expressions). |
| `filters` | object[] | optional | Filter field definitions. |
| `subgroups` | object[] | optional | Nested filter groups (rendered as arrays of items). |
| `minItems` / `maxItems` | integer | optional | Cardinality bounds for subgroup items. |
| `uniqueItems` | boolean | optional | Forbid duplicate items in subgroup arrays. |

```yaml
filterGroup:
  callToAction: "Filter Orders"
  name: "OrderFilters"
  caption: "Order Filters"
  formDisposition: "start_date, end_date, status:2"
  filters:
    - name: start_date
      caption: "Start"
      fieldType: date
      required: true
```

### Filter fields

Source: `dev/redflag/core/services/info/FilterInfo.java`.

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | string | yes | Filter key. Must match a `viewBindings` entry or a column name (or be referenced from `expression`). |
| `caption` | string | yes | Form label. |
| `fieldType` | string | conditional | Drives input rendering and parameter binding. Use `null` (or omit) for a **fixed condition**. |
| `required` | boolean | optional | Block query execution until populated. Defaults `false`. |
| `possibleValues` | string[] | optional | Static dropdown values. Mutually exclusive with `valueProvider`. |
| `valueProvider` | string | optional | `PROJECT/VP_ID` for dynamic dropdown. See `references/value-providers.md`. |
| `stringFormat` | string | optional | Display template when `valueProvider` is set, e.g. `"%{id} - %{caption}"`. |
| `expression` | string | optional | Custom SQL/JSONB expression with `::value::` placeholders. |
| `validationScript` | string | optional | `run:PROJECT/SCRIPT_ID` (or inline) executed before the filter is applied. |
| `dependents` | string[] | optional | Other filter `name`s that must refresh when this one changes. |

#### `fieldType` (filter)

Common values (validator: warning if other): `string`, `integer`, `number`, `decimal`, `date`, `datetime`, `boolean`, `null`. The Java type is a free string mapped through `FilterInfo.getSchemaType` (see `dev/redflag/core/services/info/FilterInfo.java`), which also accepts FQN aliases (`java.lang.String`, `java.math.BigDecimal`, `java.util.Date`, …) for backward compatibility — prefer the short forms.

`fieldType: null` (or omitted) marks the filter as a **fixed condition**: `expression` is injected verbatim into the WHERE clause with no value binding (see [Filter expressions](#filter-expressions)).

#### Dependents

```yaml
filters:
  - name: country
    caption: "Country"
    fieldType: string
    valueProvider: "PROJECT/VP_COUNTRIES"
  - name: city
    caption: "City"
    fieldType: string
    valueProvider: "PROJECT/VP_CITIES"
    dependents: ["country"]   # city refreshes whenever country changes
```

### Default filter and JS expressions

`defaultFilter` is a JSON object of seed values. Any string value beginning with `;` is **evaluated as JavaScript** with `context` in scope; the rest of the string is the expression body (the leading `;` is stripped).

```yaml
filterGroup:
  defaultFilter:
    status: "active"                                              # static literal
    start_date: ";new Date().getTime() - 30*24*60*60*1000"        # JS expression (last 30 days)
    user_id: ";context.userId"                                    # JS reading from context
```

Tip: `initContextScript` runs **before** `defaultFilter` is computed, so values you write into `context` there are visible to the `;` expressions.

### Form disposition

`formDisposition: "field1, field2:2, field3"` controls field order and column span. Tokens are split on `,` or `;`. Suffix `:N` sets the colspan to `N` (parsed in `FilterGroupInfo.toJsonSchema`).

---

## Filter expressions

The `expression` field on a filter customises how the filter value enters the WHERE clause. Supported only for **SQL** and **Collection** queries — JSON/REST sources ignore it.

Use `::value::` as the value placeholder. Each occurrence is rewritten to a SQL parameter `(?)` and the same filter value is bound to every occurrence:

```yaml
filters:
  - name: search_term
    caption: "Search"
    fieldType: string
    expression: "(company_name LIKE '%' || ::value:: || '%' OR contact_name LIKE '%' || ::value:: || '%')"
```

Without `::value::`, the value is bound once to the entire expression:

```yaml
- name: status
  fieldType: string
  expression: "status = ?"
```

Fixed condition (no value binding) — set `fieldType: null` or omit it:

```yaml
- name: active_only
  caption: "Active Only"
  fieldType: null
  expression: "status = 'active' AND deleted = false"
```

### `defaultFilterExpression` vs filter `expression`

- `defaultFilterExpression` is the **global search box** behavior. It uses raw `?` placeholders bound to the user-typed text (often repeated for multi-column LIKE).
- A filter `expression` is per-filter and uses `::value::`.

```yaml
defaultFilterExpression: "company_name LIKE '%' || ? || '%' OR order_id::text LIKE '%' || ? || '%'"
```

---

## Actions: details, reports, services, scripts

Actions live in **separate** top-level arrays, each holding artifact IDs. The button caption, icon, type, scope, and behavior are configured in the **target artifact's** `.config` (under `properties`), not in the query.

```yaml
details:  ["PROJECT/QRY_ORDER_LINES"]
reports:  ["PROJECT/RPT_ORDER_SUMMARY"]
services: ["PROJECT/SRV_NEW_ORDER"]
scripts:  ["PROJECT/SCRIPT_CANCEL_ORDER", "PROJECT/SCRIPT_EXPORT"]
```

### Action `properties` (in the target `.config`)

| Field | Type | Description |
|---|---|---|
| `caption` | string | Button label. |
| `icon` | string | Icon name. |
| `type` | string | See [Action `type`](#action-type-closed-set) (default `call`). |
| `selectionScope` | int | See [Selection scope](#selection-scope-closed-set) (default `1`). |
| `displayHints` | string[] | See [Display hints](#display-hints-closed-set). |
| `reusable` | boolean | Keep the action open after execution (default `false`). |
| `asynchronous` | boolean | Execute asynchronously (default `false`). |
| `groupName` | string | Group label in the toolbar. |
| `shortcuts` | object | Keyboard shortcuts, e.g. `{ok: "Enter", cancel: "Escape"}`. |

### Action `type` (closed set)

**Closed set** (validator: error if other): `create`, `update`, `delete`, `query`, `display`, `call`, `open`. Citation: `dev/redflag/core/services/ipo/Action.java:14-20`.

- `call` (default) — invoke a script/service.
- `create` — "New" button.
- `update` — "Edit" button.
- `delete` — auto-confirmation dialog.
- `query` — open another query view.
- `display` — render a display view inline (use size hints).
- `open` — open in a new window/tab.

### `displayHints` (closed set)

**Closed set** (validator: error if other): `default`, `main`, `confirm`, `small`, `medium`, `large`, `x-large`, `refresh-on-close`. Citation: `dev/redflag/core/services/ipo/Action.java:22-29`.

- `default` — invoked on row double-click.
- `main` — promoted toolbar button.
- `confirm` — show confirmation dialog (auto-applied for `type: delete`).
- `small` / `medium` / `large` / `x-large` — display size for `type: display`.
- `refresh-on-close` — refresh the parent query when the display view closes.

### Selection scope (closed set)

**Closed set** (validator: error if other): `0`, `1`, `-1`, `-2`, `-3`, `-4`. Citation: `dev/redflag/core/services/ipo/Action.java:31-35` plus default field value `1` at line 40.

| Value | Constant | Meaning |
|---|---|---|
| `0` | `SELECTION_SCOPE_NONE` | Always available. |
| `1` | (default) | Exactly one row selected. |
| `-1` | `SELECTION_SCOPE_ANY` | Any number of rows (0+). |
| `-2` | `SELECTION_SCOPE_MANY` | Two or more rows. |
| `-3` | `SELECTION_SCOPE_GROUP` | Continuous group selection. |
| `-4` | `SELECTION_SCOPE_FILTER` | Send filter values instead of rows. |

---

## `themeVariants`

Configured under `options.themeVariants`. Resolved at runtime via `GridVariant.valueOf(String)` (Vaadin Flow 24.x).

**Closed set** (validator: error if other): `LUMO_NO_BORDER`, `LUMO_NO_ROW_BORDERS`, `LUMO_COLUMN_BORDERS`, `LUMO_COMPACT`, `LUMO_ROW_STRIPES`, `LUMO_WRAP_CELL_CONTENT`, `MATERIAL_COLUMN_DIVIDERS`. Citation: `skills/bpm/scripts/validators/enums.py:GRID_VARIANTS` (canonical Vaadin enum, not project-specific).

```yaml
options:
  themeVariants:
    - LUMO_COMPACT
    - LUMO_ROW_STRIPES
    - LUMO_COLUMN_BORDERS
```

---

## Row styling: `classColumn`

`options.classColumn` names a column whose value is applied as a CSS class to every row. The value must match a class declared in your theme's `vaadin-grid.css`. `null` / empty values yield no class.

```yaml
view: |
  SELECT id, status,
         CASE status
           WHEN 'shipped'   THEN 'success-row'
           WHEN 'cancelled' THEN 'error-row'
           ELSE 'pending-row'
         END AS row_class
  FROM orders
options:
  classColumn: "row_class"
```

Predefined classes shipped by the BPM theme (status-based): `error-row`, `warning-row`, `success-row`, `in-progress-row`, `pending-row`, `highlight-row`, `disabled-row`, plus business-logic and color-tone classes — see the developer guide for the full list.

---

## Context and initialization

### `context`

Static seed values merged into the execution context. Available to `viewBindings`, filter `expression`s, `postProcessors`, and `selectionScript`.

```yaml
context:
  department: "Sales"
  year: 2024
```

### `initContextScript` (JavaScript)

Runs before the query executes. `context` (alias `initContext`) is mutable.

```yaml
initContextScript: |
  var now = new Date();
  context.start_date = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
  context.user = context.userId;
```

### `selectionScript` (Python or JS)

Fires whenever the user changes the row selection. Receives `bpm.context.selection` (always an array) and `bpm.context.inputData` (current filter values). Output is rendered as the grid footer (HTML allowed).

```yaml
selectionScript: |
  #!python3
  import redflagbpm
  bpm = redflagbpm.BPMService()
  n = len(bpm.context.selection)
  bpm.reply(f"<strong>{n}</strong> selected" if n else "No selection")
```

### `postProcessors`

Each script in the array runs **per row** as data is retrieved, allowing enrichment / mutation. See `references/templates.md` (post-processors section).

---

## Common gotchas

1. **`viewBindings` order matches `?` order**. Each `?` in `view` consumes the next entry from `viewBindings`. Mismatched count → silent NULL bindings or runtime SQL error.
2. **`?` placeholders ≠ `::value::`**. `?` is for `view`/`viewBindings` and `defaultFilterExpression`. `::value::` is only for filter `expression` fields.
3. **`defaultFilter` values starting with `;` are JavaScript**. The leading `;` is stripped, the rest is `eval`'d with `context` in scope. To store a literal value that begins with a semicolon, prepend a space.
4. **JSON/REST sources ignore `::value::`**. Pre-shape data with `dataSourceOptions.filter` (JQ) or filter client-side.
5. **Data source types are mutually exclusive**. Setting `dataSourceOptions.collection` together with a SQL `view` produces undefined behavior — pick one.
6. **`fieldType: null` means "no value binding"**. Useful for fixed WHERE clauses; required when the `expression` contains no `::value::` and you want the literal applied unconditionally.
7. **Hidden fields must still be in the source**. Removing a column from `columns` only hides it; if it isn't in the SQL `SELECT` / JSON payload, scripts will receive `None`.
8. **`themeVariants` are case-sensitive**. They are passed straight to `GridVariant.valueOf` — `lumo_compact` will throw at runtime.
9. **`name` on filters must match the binding source**. Either a `viewBindings` entry, a column name, or a name referenced from `expression`. A typo silently produces an inert filter.
10. **`.config` is mandatory**. Every Query needs a sibling `.config` with `type: "Query"` and `lang: "YAML"`. See `references/artifacts-and-config.md`.

---

## End-to-end example

```yaml
# QRY_ORDERS — orders dashboard with filters, drill-down, and bulk actions.
# Sibling .config: { type: "Query", lang: "YAML" }
name: "HLW/QRY_ORDERS"
caption: "Order Management"
icon: "SHOPPING_CART"

# --- SQL data source -------------------------------------------------------
dataSource: "NORTHWIND"
view: |
  SELECT
    o.order_id,
    o.order_date,
    c.company_name,
    o.total_amount,
    o.status,
    CASE
      WHEN o.status = 'shipped'   THEN 'success-row'
      WHEN o.status = 'cancelled' THEN 'error-row'
      ELSE 'pending-row'
    END AS row_class                       -- hidden column, used by classColumn
  FROM orders o
  JOIN customers c ON o.customer_id = c.customer_id
  WHERE o.order_date >= ?::date            -- bound from viewBindings[0]
viewBindings:
  - start_date

# --- Search box ------------------------------------------------------------
defaultFilterExpression: "c.company_name LIKE '%' || ? || '%' OR o.order_id::text LIKE '%' || ? || '%'"
stringFormat: "%{order_id} - %{company_name}"

# --- Visible columns -------------------------------------------------------
columns:
  - {name: order_id,     caption: "Order ID", fieldType: integer, width: 1, widthType: flex, align: END}
  - {name: order_date,   caption: "Date",     fieldType: date,    format: "yyyy-MM-dd", width: 110, widthType: px}
  - {name: company_name, caption: "Customer", fieldType: string,  width: 2, widthType: flex}
  - {name: total_amount, caption: "Total",    fieldType: decimal, format: "#,##0.00", align: END, width: 120, widthType: px}
  - {name: status,       caption: "Status",   fieldType: string,  width: 1, widthType: flex}
keys:      [order_id]
sortables: [order_date, company_name, total_amount]

# --- Access control --------------------------------------------------------
targetGroups: ["SALES", "ADMIN"]
menus:        ["Orders"]

# --- Filter form -----------------------------------------------------------
filterGroup:
  callToAction: "Filter"
  name: "OrderFilters"
  caption: "Order Filters"
  formDisposition: "start_date, status:2"
  defaultFilter:
    start_date: ";new Date(new Date().getFullYear(), new Date().getMonth(), 1).getTime()"
    status: "Pending"
  filters:
    - name: start_date
      caption: "Start Date"
      fieldType: date
      required: true
      expression: "o.order_date >= ::value::"
    - name: status
      caption: "Status"
      fieldType: string
      possibleValues: ["Pending", "Processing", "Shipped", "Delivered", "Cancelled"]
      expression: "o.status = ::value::"
    - name: high_value_only          # fixed condition: fieldType null, no binding
      caption: "High value only"
      fieldType: null
      expression: "o.total_amount > 1000"

# --- Actions (defined in their own artifacts) ------------------------------
details:  ["HLW/QRY_ORDER_LINES"]
reports:  ["HLW/RPT_ORDER_SUMMARY"]
services: ["HLW/SRV_NEW_ORDER"]
scripts:  ["HLW/SCRIPT_CANCEL_ORDER", "HLW/SCRIPT_EXPORT_ORDERS"]

# --- Context & lifecycle ---------------------------------------------------
context:
  default_status: "Pending"
initContextScript: |
  // Make the user available to defaultFilter ; expressions
  context.user = context.userId;
selectionScript: |
  #!python3
  import redflagbpm
  bpm = redflagbpm.BPMService()
  sel = bpm.context.selection or []
  total = sum(float(r.get('total_amount', 0)) for r in sel)
  bpm.reply(f"<strong>{len(sel)}</strong> orders — total ${total:,.2f}")

# --- Source tuning & UI ----------------------------------------------------
dataSourceOptions:
  pageSize: 50
  timeout: 30000
  where: "o.deleted = false"
  orderBy: "o.order_date DESC"
options:
  pageSize: 50
  exportable: true
  classColumn: "row_class"
  themeVariants:
    - LUMO_COMPACT
    - LUMO_ROW_STRIPES
debug: false
waitForFilter: false
autorefresh: 300
```

---

## Validation summary

The `validators/query.py` validator checks:

- **Top-level shape** — file parses as YAML/JSON, root is a mapping, no unknown top-level keys (warning), required key `caption` present (warning if absent).
- **Identifiers** — `name`, `details[]`, `reports[]`, `services[]`, `scripts[]`, `postProcessors[]`, filter `valueProvider`, filter `validationScript` (after stripping `run:`) match `ARTIFACT_ID_RE` (`PROJECT/ARTIFACT_ID`).
- **Data-source coherence** — exactly one source type detectable per the rules in [Data sources](#data-sources); warns when SQL `view` is set together with `dataSourceOptions.collection`, when `viewBindings` is non-empty for a non-SQL source, and when JSON/REST queries declare filter `expression`s with `::value::`.
- **`viewBindings` vs `?` count** — number of `?` placeholders in `view` equals `len(viewBindings)` (error if mismatched).
- **Columns**
  - `name` and `caption` present (error if missing).
  - `fieldType` in `COLUMN_FIELD_TYPES` — warning if outside the common set.
  - `align` in `COLUMN_ALIGN` (`START`, `CENTER`, `END`) — error otherwise.
  - `width` is a non-negative integer (string form parseable as int también acepta) — error otherwise.
  - `widthType` (when present) in `COLUMN_WIDTH_TYPES` (`px`, `em`, `rem`, `%`, `flex`) — error otherwise.
- **Filter group**
  - Each filter has `name` and `caption` (error if missing).
  - `fieldType` in the documented set — warning if outside.
  - Mutually exclusive `possibleValues` vs `valueProvider` — warning if both set.
  - `expression` containing `::value::` paired with `fieldType: null` — warning (the value is never bound).
  - `dependents[]` entries reference other filter `name`s in the same group — warning if unresolved.
  - `defaultFilter` keys reference declared filter `name`s — warning if unknown.
  - Tokens in `formDisposition` reference declared filter `name`s; `:N` colspan parses as integer.
- **Actions** — when `properties` from referenced artifacts is inspected (cross-file mode):
  - `type` in `ACTION_TYPES` (`create`, `update`, `delete`, `query`, `display`, `call`, `open`) — error otherwise.
  - `displayHints[]` items in `ACTION_DISPLAY_HINTS` — error otherwise.
  - `selectionScope` in `ACTION_SELECTION_SCOPES` (`0, 1, -1, -2, -3, -4`) — error otherwise.
- **Theme variants** — every entry in `options.themeVariants` is in `GRID_VARIANTS` — error otherwise (case-sensitive).
- **`classColumn`** — references either a column declared in `columns` or a hidden field present in the `SELECT` (warning if not visibly declared anywhere).
- **`defaultFilter` JS expressions** — values that begin with `;` are flagged as JS expressions (info), and a warning is emitted if the body is empty.
