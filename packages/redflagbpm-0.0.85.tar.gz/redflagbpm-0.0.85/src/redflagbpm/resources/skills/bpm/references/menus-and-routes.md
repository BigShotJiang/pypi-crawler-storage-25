# Menus and Routes

This reference covers Menu artifacts (type `Menu`) used to define application navigation, plus the URL route catalog the Vaadin Flow frontend exposes. Menus combine an explicit hierarchy (defined in YAML artifacts) with implicit items contributed by other artifacts via `properties.menus`. Use this guide alongside `references/artifacts-and-config.md` whenever you wire navigation or external links.

> Source of truth: `dev/redflag/bpm/dto/MenuInfo.java` (the DTO Jackson deserializes the YAML into) and `doc/BPM_Developer_Guide.md` lines 7042-7733.

## Recipe — create a Menu from scratch

In order.

1. **Decide the id**: `PROJECT/MENU_ID` for the artifact id, plus a short `id:` inside the body other artifacts will reference from `properties.menus[]`.
2. **Author the body** `path/to/MAIN_MENU.yaml` with the `MenuInfo` document (`id`, `name`, optional `parentId`, `items: […]`).
3. **Create the `.config`**:
   ```yaml
   project: "MYPROJ"
   id: "MYPROJ/MAIN_MENU"
   lang: "YAML"
   type: "Menu"
   description: "Main navigation"
   properties: null
   ```
4. **Wire children**: explicit (`items: [...]`), or implicit by adding the menu's body `id` to `properties.menus: [...]` of the contributing artifacts (Query/Service/Report/Page).
5. **Validate**:
   ```bash
   "$BPM_SKILL_DIR/scripts/validate.py" --strict path/to/MAIN_MENU.yaml.config
   ```
6. **Smoke-test** by reloading the BPM frontend — the menu should appear in the navigation drawer with the entries you wired.

---

## Menu artifacts

A Menu is a regular artifact: a body file plus a `.config` sibling.

- Body: `*.yaml` containing one `MenuInfo` document.
- Config: `*.yaml.config` with `type: Menu`, `lang: YAML`, `project`, `id`.
- The artifact `id` in the config (`PROJECT/MENU_ID`) is the qualified identifier; the `id` inside the body is the short identifier other artifacts will reference from their `properties.menus` array.

Example `.config`:

```yaml
project: "MYPROJ"
id: "MYPROJ/MAIN_MENU"
lang: "YAML"
type: "Menu"
description: "Main application menu"
```

The body is parsed with Jackson via `MenuInfo.fromYaml(...)` (Vert.x JSON / YAML mapper). Unknown fields are ignored, but only the eleven fields below are wired.

### MenuInfo fields

| Field       | Type             | Required | Purpose                                                                                                                              |
|-------------|------------------|----------|--------------------------------------------------------------------------------------------------------------------------------------|
| `id`        | string           | Yes      | Short, project-unique identifier. Referenced by `parentId` and by other artifacts' `properties.menus[]`.                              |
| `parentId`  | string \| null   | No       | ID of the parent menu. `null` (or omitted) for root-level menus. Use it to nest a menu without inlining it under `items`.            |
| `name`      | string           | Yes      | Display label rendered in the navigation drawer.                                                                                     |
| `icon`      | string           | No       | Vaadin icon name (e.g. `HOME`, `SHOPPING_CART`) or a custom icon registered by the theme.                                            |
| `theme`     | string \| null   | No       | Optional CSS class / theme variant applied to the menu node for custom styling.                                                      |
| `target`    | string \| null   | No       | Where the item navigates when clicked. Leave `null` for container menus that only group children. Format described in routes section.|
| `users`     | string[]         | No       | Whitelist of user IDs allowed to see the menu. Empty / null means "no user-level restriction" (groups still apply).                  |
| `groups`    | string[]         | No       | Whitelist of group names allowed to see the menu. Empty / null means "no group-level restriction".                                   |
| `items`     | MenuInfo[]       | No       | Inline children (submenus or leaves). Recursive: each item is itself a `MenuInfo`. Empty array allows implicit population.            |
| `separator` | boolean          | No       | When `true`, render this entry as a separator line. Other fields are ignored on a separator entry.                                   |
| `sort`      | boolean          | No       | When `true`, children (explicit + implicit) are alphabetised by `name` at render time.                                               |

JSON serialisation order is fixed by `@JsonPropertyOrder` and `null` values are stripped (`JsonInclude.NON_NULL`), so saved menus stay diff-friendly.

## Explicit vs implicit menus

There are two complementary ways an entry ends up in the navigation:

1. **Explicit** — declared inside a Menu artifact body, either as a top-level `MenuInfo` or nested under `items`. Use this for the skeleton: root menus, submenus, separators, group containers.
2. **Implicit** — contributed by other artifacts (Queries, Services, Reports, Pages, ...) that list one or more menu IDs in their config:

   ```yaml
   # *.config of a Query / Service / Report / Page
   properties:
     menus:
       - "ORDERS_SUBMENU"
       - "SALES_MENU"
   ```

   The runtime resolves each name against the global pool of Menu artifacts. If a Menu with that `id` exists, the contributing artifact is appended as a leaf under that menu. Its label, icon, and access control come from the artifact itself (`caption`/`name`, `icon`, `targetUsers`, `targetGroups`).

The auto-generated `target` follows the artifact type:

- Query  → `Query/q?__query__=PROJECT/QUERY_ID`
- Service → `Service/s?__service__=PROJECT/SERVICE_ID`
- Report  → `Service/s?__service__=PROJECT/REPORT_ID`
- Page    → `Page/p?__page__=PROJECT/PAGE_ID`

**Agents are not contributed implicitly.** `properties.menus` on an Agent is ignored — the `MenuBuilder` only walks Queries, Services, Reports and Pages. To put an Agent in the navigation, declare an explicit menu entry with `target: "Agent?__agent__=PROJECT/AGENT_ID"`.

A Menu can mix both worlds: declare a couple of fixed children explicitly and leave `items: []` so implicit ones land in the same node.

## Hierarchy

There are two ways to nest:

- **Inline** — put a `MenuInfo` inside the parent's `items` list. The child inherits no fields automatically; you still set `parentId` for clarity (and so consumers that index by `id` can walk back).
- **Reference** — define the child as a top-level Menu artifact in another file and set `parentId: "PARENT_ID"`. The runtime grafts it under the parent at load time.

Inline form:

```yaml
id: "SALES_MENU"
name: "Sales"
items:
  - id: "ORDERS_SUBMENU"
    name: "Orders"
    parentId: "SALES_MENU"
    items: []
  - id: "CUSTOMERS_SUBMENU"
    name: "Customers"
    parentId: "SALES_MENU"
    items: []
```

`MenuInfo.stream()` (used by tooling and validation) walks the tree depth-first, yielding the parent before its children — useful when you need to flatten a menu for searching or auditing.

## Separators and sorting

A separator is a `MenuInfo` whose only meaningful field is `separator: true`:

```yaml
items:
  - id: "ITEM_1"
    name: "First"
    items: []
  - separator: true
  - id: "ITEM_2"
    name: "Second"
    items: []
```

Sorting is per-container and opt-in: set `sort: true` on the parent and the renderer alphabetises every child (explicit + implicit) by `name`. If you need a deterministic order, leave `sort` unset / `false` and order the `items` list manually — be aware that implicit items appended afterwards will land at the end.

## Access control

`users` and `groups` apply at the menu node level:

```yaml
id: "ADMIN_MENU"
name: "Administration"
groups:
  - "ADMIN"
items: []
```

Rules of thumb:

- A user must satisfy menu-level access **and** the access control of any leaf artifact.
- If the user is filtered out of the parent menu, all children are hidden — even ones they would otherwise be allowed to see.
- Implicit leaves keep their own `targetUsers` / `targetGroups`; the menu's restrictions act as an additional gate.
- Empty `users` and empty `groups` together mean "no restriction"; populate one or both to constrain visibility.

## `target`: what gets opened

The `target` string is fed to the frontend's navigation layer. Recognised forms:

| Form                                  | Behaviour                                                                                  |
|---------------------------------------|--------------------------------------------------------------------------------------------|
| `null` / omitted                      | Container menu — clicking it just expands children.                                        |
| Vaadin route name (e.g. `Queries`)    | Navigates to that view.                                                                    |
| Route + query string                  | Navigates and feeds query params to the artifact context (see Application Routes).         |
| `/api/...`                            | Hits a REST endpoint. Useful for downloads or webhooks; not meant for in-app views.        |
| Absolute URL (`https://...`)          | External link, opens in the same tab unless the theme overrides target behaviour.          |

When an artifact contributes implicitly via `properties.menus`, you cannot override `target` — it is generated from the artifact type/ID. To open something with custom params, declare an explicit menu entry.

## Themes

`theme` is a freeform CSS hook. The frontend applies it as a class (or Lumo theme variant) on the menu node. Common uses:

- Highlighting an environment banner (`theme: "warning"`).
- Applying a brand colour to the root menu.
- Differentiating admin sections.

There is no built-in catalogue — values are valid only if your front-end theme defines them. Coordinate with whoever owns the application theme bundle.

## Application Routes

The frontend (Vaadin Flow) registers a fixed set of `@Route` views. Menu `target` values, plus any URL you build in scripts (`OPEN`, `OPEN_NEW` responses), use these names.

### Artifact view routes

| Route     | Required parameter         | Notes                                                  |
|-----------|----------------------------|--------------------------------------------------------|
| `Query`   | `__query__=PROJECT/QRY_ID` | Default Query view.                                    |
| `QueryW`  | `__query__=PROJECT/QRY_ID` | Window-style layout (popup / modal-friendly).          |
| `Service` | `__service__=PROJECT/SRV_ID` | Default Service view.                                |
| `ServiceW`| `__service__=PROJECT/SRV_ID` | Window-style layout.                                 |
| `Page`    | `__page__=PROJECT/PAGE_ID` | Renders a Page artifact.                               |
| `PageW`   | `__page__=PROJECT/PAGE_ID` | Window-style layout.                                   |
| `Agent`   | `__agent__=PROJECT/AGENT_ID` | Use the query-string form `Agent?__agent__=PROJECT/AGENT_ID`. The view reads `parameter` as a single path segment, so `Agent/PROJECT/AGENT_ID` is parsed wrong (the `/` between project and id breaks the route). |
| `Analyst` | `__analyst__=PROJECT/ANALYST_ID` | Same shape as `Agent`. Path-only `Analyst/<id>` still works for legacy single-segment ids; for the qualified `PROJECT/ID` form (recommended) use the query string. |

The `q` / `s` / `p` / `f` slugs you may see (`Query/q?...`, `Service/s?...`, `Page/p?...`, `Form/f?...`) are the canonical forms emitted by the implicit-menu generator. They are equivalent to the bare route name plus the same query string.

### List view routes

| Route          | Purpose                          |
|----------------|----------------------------------|
| `Queries`      | All available Queries.           |
| `Services`     | All available Services.          |
| `Pages`        | All available Pages.             |
| `Reports`      | All available Reports.           |
| `Agents`       | All registered Agents.           |
| `VectorStores` | Vector store catalogue.          |

### Process management routes

| Route                    | Parameter                                    |
|--------------------------|----------------------------------------------|
| `ListTasks/{appId}`      | App ID in path.                              |
| `ListProcesses/{appId}`  | App ID in path.                              |
| `ListProcessTasks/{appId}` | App ID in path.                            |
| `StartProcess/{appId}`   | App ID in path.                              |
| `StartProcessByName`     | `?processName=...`                           |
| `StartTask`              | `?taskId=...`                                |
| `StartNextProcessTask`   | `?processInstanceId=...`                     |
| `AdminTasks/{appId}`     | App ID in path. ADMIN-only.                  |
| `AdminProcesses/{appId}` | App ID in path. ADMIN-only.                  |
| `TestProcess/{appId}`    | Process testing harness.                     |

### Configuration routes (ADMIN)

`ConfigCode`, `ConfigQueries`, `ConfigServices`, `ConfigReports`, `ConfigCollections`, `ConfigProjects`, `ConfigApps`, `ConfigDatasets`, `ConfigDatasources`, `ConfigMailsources`, `ConfigParameters`, `ConfigRepos`, `ConfigVenvs`, `ConfigHandlers`, `ConfigAssistants`, `LogView`, `LogConfig`. All require ADMIN privileges and take no parameters.

### REST API routes

REST endpoints are prefixed with `/api/`. They are not view routes — they return JSON / files / redirects. The full catalogue (script execution, auth tokens, service / agent proxies, OAuth callbacks, WhatsApp webhooks, resources, task completion) lives in `references/endpoints.md`. Use them as menu `target` only when the goal is a download or a one-shot HTTP action.

### Route parameters

- **Query string** — append `?key=value&...` to any view route. Reserved keys (`__query__`, `__service__`, `__page__`, `__form__`) identify the artifact; everything else is forwarded to the artifact context (parameters, filters, default values).
- **Path** — process routes embed the ID directly in the path (`ListTasks/myapp`). Mix with query strings if needed (`StartProcess/myapp?customer=42`). The `Agent` route is the exception: it cannot use a path segment with a `/` inside (single-segment path parameter), so the artifact id always travels in the query string (`Agent?__agent__=MYPROJ/SUPPORT_BOT`).
- **Encoding** — values must be URL-encoded; the `Menu` renderer does not encode for you.

## Examples

### Simple menu with three items

```yaml
# main_menu.yaml
id: "MAIN_MENU"
name: "Main Menu"
icon: "HOME"
items:
  - id: "ORDERS"
    name: "Orders"
    icon: "SHOPPING_CART"
    target: "Query?__query__=HLW/QRY_ORDERS"
    items: []
  - id: "CUSTOMERS"
    name: "Customers"
    icon: "USERS"
    target: "Query?__query__=HLW/QRY_CUSTOMERS"
    items: []
  - id: "REPORTS_LIST"
    name: "Reports"
    icon: "FILE_TEXT"
    target: "Reports"
    items: []
```

### Hierarchical menu (parent + children)

```yaml
# sales_menu.yaml
id: "SALES_MENU"
name: "Sales"
icon: "CHART"
sort: true
items:
  - id: "ORDERS_SUBMENU"
    name: "Orders"
    icon: "SHOPPING_CART"
    parentId: "SALES_MENU"
    sort: true
    items: []                         # populated implicitly
  - id: "CUSTOMERS_SUBMENU"
    name: "Customers"
    icon: "USERS"
    parentId: "SALES_MENU"
    items: []
```

### Menu link to an Agent

Agents have to be linked explicitly (the implicit-menu generator skips them):

```yaml
# ai_menu.yaml
id: "AI_MENU"
name: "AI Assistants"
icon: "MAGIC"
items:
  - id: "GEMINI_LINK"
    name: "Gemini Assistant"
    icon: "ROBOT"
    target: "Agent?__agent__=MYPROJ/GEMINI_AGENT"
    items: []
```

### Menu with separators

```yaml
id: "TOOLS_MENU"
name: "Tools"
icon: "WRENCH"
items:
  - id: "IMPORT"
    name: "Import"
    target: "Service?__service__=HLW/SRV_IMPORT"
    items: []
  - separator: true
  - id: "EXPORT"
    name: "Export"
    target: "Service?__service__=HLW/SRV_EXPORT"
    items: []
  - separator: true
  - id: "ADMIN_LINK"
    name: "Admin"
    target: "ConfigQueries"
    groups:
      - "ADMIN"
    items: []
```

### Implicit menu (artifact contributing via `properties.menus`)

The Menu artifact only declares the container:

```yaml
# orders_submenu.yaml
id: "ORDERS_SUBMENU"
name: "Orders"
icon: "SHOPPING_CART"
sort: true
items: []
```

A Query opts into it via its `.config`:

```yaml
# qry_orders.yaml.config
project: "HLW"
id: "HLW/QRY_ORDERS"
lang: "YAML"
type: "Query"
properties:
  caption: "All Orders"
  icon: "LIST"
  menus:
    - "ORDERS_SUBMENU"
  targetGroups:
    - "SALES"
    - "ADMIN"
```

At runtime the Query appears as a leaf under `ORDERS_SUBMENU` with target `Query/q?__query__=HLW/QRY_ORDERS`, and the entry is alphabetised against any siblings because the parent has `sort: true`.

### End-to-end menu artifact

```yaml
# main_menu.yaml
id: "MAIN_MENU"
name: "Main"
icon: "MENU"
parentId: null
sort: false
items:
  - id: "DASHBOARD_LINK"
    name: "Dashboard"
    icon: "DASHBOARD"
    target: "Page?__page__=HLW/PAGE_DASHBOARD"
    items: []

  - id: "SALES_MENU"
    name: "Sales"
    icon: "CHART"
    parentId: "MAIN_MENU"
    sort: true
    items:
      - id: "ORDERS_SUBMENU"
        name: "Orders"
        icon: "SHOPPING_CART"
        parentId: "SALES_MENU"
        items: []                     # implicit population
      - id: "CUSTOMERS_SUBMENU"
        name: "Customers"
        icon: "USERS"
        parentId: "SALES_MENU"
        items: []

  - separator: true

  - id: "BPM_MENU"
    name: "Processes"
    icon: "COG"
    items:
      - id: "MY_TASKS"
        name: "My Tasks"
        target: "ListTasks/default"
        items: []
      - id: "START_ORDER_PROCESS"
        name: "Start Order"
        target: "StartProcess/orders"
        items: []

  - separator: true

  - id: "ADMIN_MENU"
    name: "Administration"
    icon: "COGS"
    groups:
      - "ADMIN"
    items:
      - id: "QRY_MGMT"
        name: "Queries"
        target: "ConfigQueries"
        items: []
      - id: "SVC_MGMT"
        name: "Services"
        target: "ConfigServices"
        items: []
      - id: "LOGS"
        name: "Logs"
        target: "LogView"
        items: []
```

```yaml
# main_menu.yaml.config
project: "HLW"
id: "HLW/MAIN_MENU"
lang: "YAML"
type: "Menu"
description: "Top-level navigation for the Helloworld project"
```

## Common gotchas

- **`id` clashes** — Menu IDs live in a single global pool used by `properties.menus`. Reusing the same `id` across projects causes implicit items to attach to whichever Menu loaded last. Prefix or namespace generously.
- **Missing `.config`** — A `*.yaml` body without a sibling `*.yaml.config` (with `type: Menu`) is silently ignored. The body alone is not enough.
- **Forgetting `items: []`** — Implicit items require an existing Menu node. Setting `items` to `null` (omitting it) still works for explicit children, but if you also want implicit contributions, prefer an explicit empty list to make the intent obvious.
- **Separator with extra fields** — A separator entry should only set `separator: true`. Adding `name`, `icon`, etc. is harmless but misleading; some tooling renders the redundant fields.
- **`sort: true` and stable ordering** — Sorting is purely by `name`. Localised names will sort by their displayed string, not by ID. If you need a fixed ordering, drop `sort` and order the `items` list yourself.
- **Access control is additive** — A user must pass *every* gate from root to leaf. A permissive leaf under a restrictive parent is still hidden.
- **`target` for containers** — A container menu with `target` set will navigate on click *and* expand. If you only want grouping, leave `target` `null`.
- **Encoding query strings** — `target` is taken verbatim. Spaces, `&`, and unicode in parameter values must be URL-encoded by hand.
- **`/api/...` targets** — These hit REST endpoints; they will not render an in-app view. Use them only for downloads or webhook triggers.
- **Implicit `target` cannot be overridden** — If you need custom query params for a Query/Service entry, define an explicit menu item with the desired `target` instead of relying on `properties.menus`.

## Validation summary

`validators/menu.py` checks:

- Body parses as valid YAML and into `MenuInfo` (no unknown top-level fields you cared about — they will be dropped).
- Each non-separator entry has an `id` and a `name`.
- All `id` values used in `parentId` and in other artifacts' `properties.menus` resolve to a known Menu (cross-file mode).
- Root menus have `parentId: null` (or omit the field).
- Separator entries set only `separator: true`.
- `target` strings either match a Vaadin route in the catalogue, start with `/api/`, or are absolute URLs.
- `__query__` / `__service__` / `__page__` / `__agent__` parameters use the qualified `PROJECT/ID` form.
- `Agent` targets use the query-string form (`Agent?__agent__=PROJECT/ID`); a literal `Agent/PROJECT/ID` in `target` is flagged because the `/` inside the project/id pair breaks the path-parameter route.
- `users` / `groups` reference principals that actually exist in the realm.
- `.config` sibling exists with `type: Menu`, `lang: YAML`, the correct `project` and the qualified `id` (`PROJECT/MENU_ID`).
- Implicit-only containers (`items: []`) actually have at least one artifact pointing at them, otherwise they will render empty.
- If `sort: true`, alphabetic order is acceptable.

## Cross-references

- `references/artifacts-and-config.md` — anatomy of `.config` files, `properties.menus` placement, and the artifact loading lifecycle.
- `references/queries.md` — Query-specific `caption`, `icon`, `targetUsers`, `targetGroups` fields exposed in the navigation.
- `references/pages.md` — Page artifacts and the `Page` / `PageW` view routes.
- `references/services.md` — Service artifacts and the `Service` / `ServiceW` view routes (also used by Reports).
- `references/endpoints.md` — full REST API catalogue for `/api/...` `target` values and script integrations.
