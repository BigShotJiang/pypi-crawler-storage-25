# Artifacts & `.config` Files

Every artifact authored in a BPM project is stored as a file in a project repo, paired with a sibling `.config` file that holds metadata. This reference covers the `.config` shape, naming, allowed values, and per-type properties.

**Source of truth**: `dev/redflag/bpm/dto/CodeDTO.java`. This reference matches the constants in that file.

---

## File location and naming

If the artifact file is named `myscript.py`, the config must be named `myscript.py.config` and live in the **same directory**. The system finds the `.config` by appending `.config` to the artifact path; placing it elsewhere will not work.

```
repos/
└── my_project/
    └── scripts/
        ├── my_script.py          # Artifact
        └── my_script.py.config   # Config (same directory)
```

---

## YAML structure

```yaml
project: "PROJECT_CODE"           # required, SCREAMING_SNAKE_CASE
id: "PROJECT_CODE/ARTIFACT_ID"    # required, full identifier
lang: "Python"                    # required, see closed list
type: "Script"                    # required, see closed list (default "Script")
description: "Optional description"
cron: null                        # optional cron for scheduled execution
properties:                       # optional, type-specific (object or null)
  caption: "My Script Action"
  selectionScope: 1
env:                              # optional environment variables (test-time)
  MY_VAR: "value"
```

> **Deprecated**: the boolean field `form` (e.g. `form: false`) is no longer needed — it has been replaced by `type: "Form"`. The setter is marked `@Deprecated` in `CodeDTO.java:184-187`. Remove it from new files.

---

## `lang` — closed list

Source: `dev/redflag/bpm/dto/CodeDTO.java:24-34` (constants `JS`, `PY`, `VTL`, `JSON`, `YAML`, `JUEL`, `VERTX`, `SHELL`, `PROMPT`, `MARKDOWN`, `BINARY`).

| `lang` value | Used for | Notes |
|---|---|---|
| `Python` | Python scripts (`.py`) | Runs under **Jython**. For CPython3, use `Shell` with shebang `#!python3`. |
| `JavaScript` | JS files (`.js`) | Nashorn / default JS engine. |
| `Shell` | Any script with a shebang (`.sh`, `.py3`, etc.) | The `#!` line determines the interpreter (`#!/bin/bash`, `#!/usr/bin/env node`, …). If `#!` is unrecognized, falls back to shell. |
| `YAML` | `.yaml`/`.yml` files | Parsed YAML → JSON. |
| `JSON` | `.json` files | Parsed JSON. |
| `Velocity` | `.vtl`, `.vhtml`, `.html`, `.htm` | Apache Velocity template engine. |
| `JUEL` | Java Unified EL expressions | Expression evaluation only. *Note*: present as a constant in code but not exposed in the UI dropdown (`@SchemaEnumOfString` excludes it). |
| `Vertx` | Vert.x scripts | Vert.x script engine. |
| `Prompt` | `.prompt` files | Processed as Shell scripts. |
| `Markdown` | `.md` files | Rendered as HTML. |
| `Binary` | Binary assets (`.pdf`, `.docx`, `.jasper`, `.jrxml`, `.zip`, images) | Stored as bytes; not executed. |

**Default**: if `lang` is omitted and the file has no shebang, the runtime falls back to `JavaScript`.

---

## `type` — closed list

Source: `dev/redflag/bpm/dto/CodeDTO.java:36-49`.

| `type` value | Description | Reference |
|---|---|---|
| `Script` | Executable code; the most common type. Often used as an action via `properties`. | `references/scripts-and-tools.md` |
| `Form` | Renders a form from a JSON Schema. | `references/forms.md` |
| `Page` | Custom page (HTML, Velocity, Python, JS). | `references/pages.md` |
| `Public endpoint` | HTTP endpoint, no authentication. | `references/endpoints.md` |
| `User endpoint` | HTTP endpoint, requires authenticated user. | `references/endpoints.md` |
| `Web service endpoint` | HTTP endpoint, token-based / system-to-system. | `references/endpoints.md` |
| `Query` | Tabular data view (SQL, Collection, JSON/REST). | `references/queries.md` |
| `Service` | Triggerable artifact (request/response, downloads, scripts). | `references/services.md` |
| `Collection` | Schemaless document store with CRUD. | `references/collections-and-mail.md` |
| `Report` | Generated document (PDF, XLSX, HTML, DOCX). | `references/reports.md` |
| `Menu` | Menu definition (explicit or implicit). | `references/menus-and-routes.md` |
| `Agent` | LLM agent definition (provider, model, RAG). | `references/agents-and-rag.md` |
| `Mcp` | MCP server connection definition (exposed to Analyst tool allowlists). | `references/agents-and-rag.md` |
| `Analyst` | End-user-facing AI assistant configuration. | `references/analyst.md` |

**Endpoint detection**: `CodeDTO.isEndpoint()` uses regex `.+ endpoint`, so any of the three endpoint types matches.

---

## `lang ↔ type` coherence

The runtime accepts any combination, but these pairings are conventional. Validators emit a **warning** (not an error) when you stray from them.

| `type` | Conventional `lang` |
|---|---|
| `Query`, `Service`, `Form`, `Collection`, `Menu`, `Agent`, `Mcp`, `Analyst` | `YAML` or `JSON` |
| `Report` | `Binary` (a `.jasper`/`.jrxml`/`.docx` template) |
| `Page` | `Velocity`, `Python`, `JavaScript`, `Shell`, `Markdown`, `Binary` |
| `Script` | `Python`, `JavaScript`, `Shell`, `YAML`, `JSON`, `Vertx`, `JUEL`, `Velocity`, `Prompt` |
| `Public endpoint`, `User endpoint`, `Web service endpoint` | `Python`, `JavaScript`, `Shell`, `Vertx`, `JUEL` |

---

## `properties` per type

`properties` is a YAML object whose shape depends on `type`. Set it to `null` when nothing applies.

### Script (when used as a query action)

Full reference in `references/scripts-and-tools.md`. Quick view:

```yaml
properties:
  caption: "Approve"
  icon: "CHECK_CIRCLE"
  type: "call"                    # action type, see below
  selectionScope: 1               # 0=ninguna, 1=exactamente una (default), -1=cualquier cantidad, -2=≥1, -3=≥2, -4=opera sobre filter
  displayHints:
    - "main"                      # toolbar button
    - "confirm"                   # require confirmation
    - "refresh-on-close"
  reusable: false
  asynchronous: false
  groupName: "approval"
  shortcuts:
    ok: "Enter"
    cancel: "Escape"
  inputSchema:                    # optional form for action arguments
    type: object
    properties: { ... }
```

**Action `type`** (closed set):
`create`, `update`, `delete`, `query`, `display`, `call` (default), `open`.

**Action `displayHints`** (closed set):
`default`, `main`, `confirm`, `small`, `medium`, `large`, `x-large`, `refresh-on-close`.

**`selectionScope`** — cuántas rows necesitan estar seleccionadas para habilitar el botón:
- `0` — habilitado cuando NO hay rows seleccionadas (toolbar / acción de creación).
- `1` (default) — exactamente 1 row.
- `-1` — cualquier cantidad (incluido 0): siempre habilitado.
- `-2` — 1 o más (≥ 1).
- `-3` — 2 o más (estrictamente > 1, rechaza single-row).
- `-4` — opera sobre el query filter actual; siempre habilitado, el script recibe el filter en lugar de rows.

### Report

```yaml
properties:
  resources:                      # auxiliary asset filenames bundled with the report
    - "logo.png"
    - "header.jpg"
  targetGroups:                   # access control
    - "ADMIN"
    - "SALES"
```

### Page

```yaml
properties:
  title: "Dashboard"              # browser title
```

### Query / Service / Form / Collection / Menu / Agent / Mcp / Analyst

These types put their configuration **inside the artifact file itself** (the `.yml`, not the `.config`). `properties` is normally `null`. See each type's reference for the full schema.

---

## Identifier conventions

- **`project`**: `^[A-Z][A-Z0-9_]*$` — uppercase letters, digits, underscores; must start with a letter.
- **`id`**: `^PROJECT/ARTIFACT_ID$` where both halves follow the same rule (`^[A-Z][A-Z0-9_]*/[A-Z][A-Z0-9_]*$`).
- The `project` prefix in `id` must match the `project` field. Validators check this.

---

## Complete examples

### Script

```yaml
# scripts/approve_order.py.config
project: "SALES"
id: "SALES/APPROVE_ORDER"
lang: "Python"
type: "Script"
description: "Approve a single order from the orders query."
properties:
  caption: "Approve"
  icon: "CHECK_CIRCLE"
  type: "call"
  selectionScope: 1
  displayHints: ["main", "confirm", "refresh-on-close"]
env:
  TEST_USER: "demo"
```

### Query

```yaml
# queries/orders.yml.config
project: "SALES"
id: "SALES/QRY_ORDERS"
lang: "YAML"
type: "Query"
description: "Open orders for the current month."
properties: null
```

### Service

```yaml
# services/search.yml.config
project: "SALES"
id: "SALES/SRV_SEARCH"
lang: "YAML"
type: "Service"
description: "Faceted search across customers and orders."
properties: null
```

### Report (binary template)

```yaml
# reports/sales_summary.jasper.config
project: "SALES"
id: "SALES/RPT_SALES_SUMMARY"
lang: "Binary"
type: "Report"
description: "Monthly sales summary."
properties:
  resources:
    - "logo.png"
  targetGroups:
    - "ADMIN"
    - "SALES_MANAGERS"
```

### Page

```yaml
# pages/dashboard.vtl.config
project: "SALES"
id: "SALES/PAGE_DASHBOARD"
lang: "Velocity"
type: "Page"
description: "Sales dashboard."
properties:
  title: "Dashboard"
```

### Endpoint

```yaml
# endpoints/api_orders.py.config
project: "SALES"
id: "SALES/EP_ORDERS"
lang: "Python"
type: "Public endpoint"           # or "User endpoint", "Web service endpoint"
description: "Public REST endpoint that returns the open orders."
properties: null
```

### Agent

```yaml
# agents/assistant.yml.config
project: "SALES"
id: "SALES/AGT_ASSISTANT"
lang: "YAML"
type: "Agent"
description: "Sales assistant agent."
properties: null
```

### Analyst

```yaml
# analysts/sales_analyst.yml.config
project: "SALES"
id: "SALES/ANL_SALES"
lang: "YAML"
type: "Analyst"
description: "End-user assistant for the sales team."
properties: null
```

### Mcp

```yaml
# mcps/postgres_mcp.yml.config
project: "SALES"
id: "SALES/MCP_POSTGRES"
lang: "YAML"
type: "Mcp"
description: "Postgres MCP server exposed to the Sales analyst."
properties: null
```

---

## Validation summary

The `config_file` validator checks:

- Required: `project`, `id`, `lang`, `type` are present.
- `lang` is in the closed set (error if not).
- `type` is in the closed set (error if not).
- `id` matches `^PROJECT/ARTIFACT_ID$` and the `PROJECT` matches the `project` field.
- `lang ↔ type` coherence: warning when an unconventional pair is used.
- For `type: Script`, `properties.type` (the action type) is in the action-type closed set when present.
- For `type: Script`, `properties.selectionScope` is `{-4, -3, -2, -1, 0, 1}` o cualquier entero positivo (default `1`).
- `properties.displayHints[*]` are in the action-display-hints closed set.
- `cron` matches a loose 5–7 token shape when present.
- The deprecated boolean `form` field, if present, emits an info-level note.

Run it with:

```bash
python skills/bpm/scripts/validate.py path/to/artifact.something.config
```
