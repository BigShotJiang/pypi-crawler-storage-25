"""Validate AnalystInfo YAML."""
from __future__ import annotations

from typing import Any

from .common import (
    Severity,
    ValidationResult,
    check_regex,
    check_required_fields,
    check_unknown_keys,
)
from .enums import ANALYST_ALL_FIELDS, ANALYST_REQUIRED_FIELDS, ARTIFACT_ID_RE, MODEL_FQ_RE
from .form import validate as validate_form
from .sandbox import validate as validate_sandbox


_PLUGIN_TOOLS = {
    "bpm_bash", "bpm_read", "bpm_write", "bpm_edit",
    "bpm_glob", "bpm_grep", "bpm_ask_user",
}

_BPM_RESOURCE_SCHEMES = {"query", "code", "doc", "resource"}


def validate(body: Any, config: Any, result: ValidationResult) -> None:
    if not isinstance(body, dict):
        result.error("not-a-mapping", "Analyst body must be a YAML mapping")
        return

    check_required_fields(result, body, ANALYST_REQUIRED_FIELDS)
    check_unknown_keys(result, body, ANALYST_ALL_FIELDS, severity=Severity.WARNING)

    # `id` in the body is no longer authoritative — runtime takes it from the
    # .config sidecar. Same warnings as Agent.
    body_id = body.get("id")
    config_id = config.get("id") if isinstance(config, dict) else None
    if body_id and config_id and str(body_id) != str(config_id):
        result.warning(
            "analyst-body-config-id-mismatch",
            f"body id {body_id!r} differs from .config id {config_id!r}. "
            f"The runtime uses the .config id; remove the `id:` line from "
            f"the body YAML or align it with the .config to avoid confusion.",
            "id",
        )
    if body_id and not ARTIFACT_ID_RE.match(str(body_id)):
        result.warning(
            "analyst-body-id-bad-shape",
            f"body id {body_id!r} should match PROJECT/ANALYST_ID. The runtime "
            f"ignores this field — preferably remove it from the body.",
            "id",
        )

    if not body.get("model"):
        result.error("missing-model", "model is required", "model")
    else:
        check_regex(result, body["model"], MODEL_FQ_RE, "bad-model-fq",
                    "model", Severity.ERROR)

    sandbox = body.get("sandbox")
    if not isinstance(sandbox, dict) or not sandbox:
        result.error("missing-sandbox",
                     "sandbox is required for an Analyst (always Docker)",
                     "sandbox")
    else:
        # Analyst cannot run host mode
        mode = sandbox.get("mode")
        if mode == "host":
            result.error(
                "analyst-host-mode",
                "Analyst sandbox.mode must be 'docker' (or omitted); 'host' is not allowed",
                "sandbox.mode",
            )
        sub = ValidationResult(file=result.file, artifact_type="sandbox")
        validate_sandbox(sandbox, None, sub)
        for issue in sub.issues:
            issue.path = f"sandbox.{issue.path}" if issue.path else "sandbox"
            result.issues.append(issue)

    # tools: warn if listing a plugin tool
    tools = body.get("tools") or []
    if isinstance(tools, list):
        for i, t in enumerate(tools):
            if isinstance(t, str) and t in _PLUGIN_TOOLS:
                result.warning(
                    "tool-is-plugin",
                    f"tool {t!r} is a global plugin tool and should not be listed",
                    f"tools[{i}]",
                )

    # resources: bpm://<scheme>/<path>
    resources = body.get("resources") or []
    if isinstance(resources, list):
        for i, r in enumerate(resources):
            if not isinstance(r, str) or not r.startswith("bpm://"):
                result.error(
                    "bad-resource-uri",
                    f"resources[{i}] {r!r} must start with 'bpm://'",
                    f"resources[{i}]",
                )
                continue
            scheme = r.split("://", 1)[1].split("/", 1)[0]
            if scheme not in _BPM_RESOURCE_SCHEMES:
                result.error(
                    "bad-resource-scheme",
                    f"resources[{i}] scheme {scheme!r} not in {sorted(_BPM_RESOURCE_SCHEMES)}",
                    f"resources[{i}]",
                )

    # prompts: each must have a non-empty message
    prompts = body.get("prompts") or {}
    if isinstance(prompts, dict):
        for name, p in prompts.items():
            if not isinstance(p, dict):
                result.error("prompt-not-mapping",
                             f"prompts['{name}'] must be a mapping",
                             f"prompts.{name}")
                continue
            if not p.get("message"):
                result.error(
                    "prompt-missing-message",
                    f"prompts['{name}'].message is required",
                    f"prompts.{name}.message",
                )
            input_schema = p.get("inputSchema")
            if isinstance(input_schema, dict) and input_schema:
                sub = ValidationResult(file=result.file, artifact_type="form")
                validate_form(input_schema, None, sub)
                for issue in sub.issues:
                    issue.path = (f"prompts.{name}.inputSchema.{issue.path}"
                                  if issue.path
                                  else f"prompts.{name}.inputSchema")
                    result.issues.append(issue)

    # debug warning for shipped Analysts
    if body.get("debug"):
        result.info(
            "debug-true",
            "debug: true exposes internal tool calls — set false before "
            "shipping to end users",
            "debug",
        )
