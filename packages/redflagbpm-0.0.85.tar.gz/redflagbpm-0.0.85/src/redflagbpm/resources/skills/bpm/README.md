# `bpm` skill

An Anthropic-style skill that documents the **RedFlag BPM low-code platform** for configurators (devs and admins who write artifacts in BPM projects). It pairs a compact `SKILL.md` with topic references under `references/` and Python validators under `scripts/` that lint artifact files (queries, forms, services, agents, prompts, sandbox configs, …).

This skill is bundled with the bpmapp source tree (`skills/bpm/`) so it travels with the platform release. The Java code under `src/main/java/` is the **source of truth**; the references mirror what the code accepts, and the validators import a single `enums.py` whose constants cite their Java origins.

---

## Layout

```
skills/bpm/
├── SKILL.md                       # frontmatter + index + decision table + glossary
├── README.md                      # this file
├── references/                    # one .md per topic; load on demand
│   ├── artifacts-and-config.md    # .config files, type, lang, project/id naming
│   ├── queries.md                 # Query YAML
│   ├── templates.md               # row templates + post-processors
│   ├── value-providers.md         # VPs (queries with id/caption)
│   ├── kanban.md                  # kanban-mode queries
│   ├── forms.md                   # JSON Schema + hints
│   ├── pages.md                   # HTML/Velocity/Python/JS pages
│   ├── services.md                # request/response, all 16 IPOResponseTypes
│   ├── reports.md                 # JasperReports / Velocity reports
│   ├── scripts-and-tools.md       # action scripts, post-processors, agent tools
│   ├── endpoints.md               # Public/User/Web service endpoints
│   ├── agents-and-rag.md          # AgentInfo, providers, RAG
│   ├── prompts-agenticos.md       # PromptDTO + workflow patterns
│   ├── menus-and-routes.md        # MenuInfo + Vaadin route catalog
│   ├── collections-and-mail.md    # JSONB collections + mail sources
│   ├── coder.md                   # Coder repo configuration (RepoDTO)
│   ├── analyst.md                 # AnalystInfo (end-user-facing AI assistant)
│   ├── sandbox.md                 # docker `sandbox:` field (Coder + Analyst)
│   └── sdk-python.md              # `redflagbpm` Python SDK reference
└── scripts/
    ├── validate.py                # CLI entrypoint
    ├── validators/                # one module per artifact type
    │   ├── enums.py               # single source of truth for closed value sets
    │   ├── common.py              # severity/issue model, loaders, dispatch
    │   ├── config_file.py
    │   ├── query.py
    │   ├── form.py
    │   ├── service.py
    │   ├── agent.py
    │   ├── prompt.py
    │   ├── kanban.py
    │   ├── value_provider.py
    │   ├── menu.py
    │   ├── repo.py
    │   ├── analyst.py
    │   └── sandbox.py
    ├── README.md                  # CLI usage, severities, exit codes
    └── tests/
        ├── test_validators.py     # pytest, valid + invalid fixtures
        └── fixtures/              # one valid + one invalid per validator
            ├── valid/
            └── invalid/
```

`SKILL.md` is the entry point and stays small (~280 lines). It enumerates triggers ("when to use this skill"), a quick decision table to pick the right reference, identifier conventions, the `.config` summary, and a glossary. References are self-contained and load on demand — never preload everything.

---

## Installation as a Claude/Anthropic skill

The skill is a self-contained directory. Two ways to make it visible to a Claude-style client:

### A. Symlink into your user skills folder

```bash
ln -s "$(pwd)/skills/bpm" ~/.claude/skills/bpm
```

### B. Copy

```bash
cp -r skills/bpm ~/.claude/skills/bpm
```

For a per-project install (so any clone of a downstream BPM project gets the skill):

```bash
mkdir -p <client-project>/.claude/skills
ln -s /absolute/path/to/bpmapp/skills/bpm <client-project>/.claude/skills/bpm
```

The skill auto-loads when the host environment scans `~/.claude/skills/` or `<project>/.claude/skills/`.

---

## Versioning

| Field | Value |
|---|---|
| Skill version | `0.0.85` |
| Source-of-truth code revision | the `bpmapp` commit that ships this skill (run `git rev-parse HEAD` from `skills/bpm/`) |
| Anthropic skill spec | `name` + `description` only (frontmatter at the top of `SKILL.md`) |

The skill version tracks the `redflagbpm` Python package that bundles it: each `sdk/python/deploy.sh` run bumps the patch version and stamps it here on the copy that ships under `redflagbpm/resources/skills/bpm/`. In the bpmapp repo source the field above shows a placeholder that `deploy.sh` rewrites with `sed` after rsync'ing the skill into the package's resources — the value you see in an installed copy is the real version of the package that brought it.

Updates: edit references and validators in lockstep with the Java code. The Java files cited in `enums.py` (`# source:` comments) are the canonical reference — when those move or rename, refresh `enums.py` first, then the references that mention the same paths.

---

## Validation usage

```bash
# Validate one file (auto-detects type)
python skills/bpm/scripts/validate.py path/to/artifact.yml

# Force a validator
python skills/bpm/scripts/validate.py --type query path/to/QRY_X.yml

# Strict mode (warnings count as errors for the exit code)
python skills/bpm/scripts/validate.py --strict path/to/file

# JSON output (for CI)
python skills/bpm/scripts/validate.py --json path/to/file
```

See `scripts/README.md` for the full CLI reference, severity policy, and exit codes.

---

## Running the test suite

```bash
pip install pytest pyyaml
python -m pytest skills/bpm/scripts/tests/ -v
```

Each validator has at least one valid fixture (must produce zero errors) and one invalid fixture (must produce at least one error). The current suite has 23 cases.

---

## Audience

This skill is for **configurators** of the RedFlag BPM platform — people who write artifacts (YAML, scripts, forms, agents) inside BPM projects. It does **not** document internal product development of the bpmapp itself (ACP protocol, JSON-RPC plumbing, SandboxRunner internals, etc.). Those live under `doc/ACP_*.md` and are out of scope for this skill.
