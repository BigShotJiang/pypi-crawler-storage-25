# Collections and Mail Sources

Two distinct configuration topics compacted into one reference for brevity. **Collections** are schemaless JSON document stores backed by PostgreSQL JSONB, queried via SQL and exposed through CRUD-enabled Queries. **Mail Sources** are scheduled IMAP/Gmail polls that turn incoming emails into BPMN events or feed them to a custom processing script. Both are YAML artifacts under a project, both require a `.config` companion (see `references/artifacts-and-config.md`), and both interact heavily with Queries and Scripts.

---

## Collections

A Collection defines a NoSQL-like document type (JSON Schema for validation + UI hints). All documents land in the shared `document.document` table, partitioned logically by the `collection` column. There is no per-collection table — the engine relies on JSONB indexing and the `collection` filter to scope queries.

A Collection on its own is just a schema. To make it usable in the UI you almost always pair it with a **Query** (`crud: true`, `options.collection: PROJECT/COLLECTION_ID`) which renders the grid and reuses the Collection schema as the create/edit form. See `references/queries.md` for the Query side.

### YAML structure

The body is a JSON Schema `type: object` with the same vocabulary as Forms, plus a `hints.idExpression` JQ expression that extracts the document's logical ID:

```yaml
type: object
title: "Favorite coffee per customer"
description: "Coffee preference per customer"
hints:
  idExpression: ".customer"          # JQ expression, value goes to document.id column
properties:
  customer:
    type: string
    title: "Customer"
    description: "Customer ID"
    hints:
      valueProvider: PROJECT/VP_CUSTOMERS   # dropdown via Value Provider
  favorite_coffee:
    type: string
    title: "Favorite coffee"
    enum: [ESPRESSO, AMERICANO, CORTADO, LATTE]
  sweetener:
    type: boolean
    title: "Sweetener"
  notes:
    type: string
    title: "Notes"
    hints:
      multiline: true
required:
  - customer
  - favorite_coffee
```

**Top-level keys**

| Key            | Purpose                                                                                |
|----------------|----------------------------------------------------------------------------------------|
| `type`         | Always `object` for a Collection root.                                                 |
| `title`        | Human-readable collection name (used in admin UI).                                     |
| `description`  | Free text for documentation.                                                           |
| `hints.idExpression` | JQ expression evaluated on each document; result is stored in `document.id`.     |
| `properties`   | JSON Schema field map. Nested objects/arrays are allowed.                              |
| `required`     | Standard JSON Schema array of required field names.                                    |

**Field-level hints** (inside each property's `hints:`) follow the Forms vocabulary: `valueProvider`, `multiline`, `format`, `mask`, `readOnly`, `visible`, etc. See `references/forms.md` for the full list — Collections reuse it verbatim because the schema doubles as the edit form.

**Indexes.** There is no per-collection index DSL — physical indexing on `body` is handled by the platform (GIN on JSONB) plus the always-present `(collection, id)` lookup. If you need a covering index for a specific field, add it via the database migration system rather than the artifact YAML.

### Storage model

All Collection documents live in one table:

| Column       | Type    | Notes                                                                  |
|--------------|---------|------------------------------------------------------------------------|
| `oid`        | UUID    | Primary key, auto-generated. Exposed as `$oid`.                        |
| `id`         | VARCHAR | Logical ID extracted by `idExpression`. Exposed as `$id`.              |
| `collection` | VARCHAR | Always `PROJECT/COLLECTION_ID`. Mandatory in every WHERE clause.       |
| `body`       | JSONB   | The complete document, including `$id` and `$oid` echoed inside.       |

A stored document looks like:

```json
{
  "$id": "customer123",
  "$oid": "550e8400-e29b-41d4-a716-446655440000",
  "customer": "customer123",
  "favorite_coffee": "ESPRESSO",
  "sweetener": true
}
```

### CRUD operations

All CRUD goes through a CRUD-enabled Query and the platform's DocumentService — there is no direct artifact-level mutation API. From a Script, prefer the helpers in `bpm.service` rather than hand-written SQL. See `references/scripts-and-tools.md` for the full DocumentService surface; the relevant calls are roughly:

- `bpm.service.documentService.create('PROJECT/COLLECTION_ID', body)` — insert; `idExpression` decides the `id`.
- `bpm.service.documentService.update('PROJECT/COLLECTION_ID', oidOrId, partialBody)` — patch via `jsonb_set()`.
- `bpm.service.documentService.delete('PROJECT/COLLECTION_ID', oidOrId)` — hard delete.
- `bpm.service.documentService.findById(...)` / `findAll(...)` — read.

The CRUD Query (with `crud: true`) is what wires these into the grid's New/Edit/Delete buttons; the Collection schema drives the modal form rendered for create/edit.

### Querying with SQL over JSONB

Collections are queryable like any other table — the engine just exposes the JSONB column and you extract fields with `body#>>'{...}'`. The platform already knows how to type-coerce these for grids if you go through `dataSourceOptions.collection` (see below); the manual form is for custom Queries, reports, or scripts.

**Skeleton** — always include `collection = '...'`:

```sql
SELECT
  oid::varchar AS "$oid",
  id           AS "$id",
  body#>>'{customer}'        AS customer,
  body#>>'{favorite_coffee}' AS favorite_coffee
FROM document.document
WHERE collection = 'PROJECT/CAFE_FAVORITO'
```

**Type casting** for non-string fields:

```sql
-- Date stored as epoch milliseconds
(TIMESTAMP with time zone 'epoch' +
   ((body#>>'{order_date}')::numeric) * INTERVAL '1 millisecond')::DATE AS order_date

-- Numeric
(body#>>'{price}')::numeric    AS price
(body#>>'{quantity}')::integer AS quantity

-- Boolean
(body#>>'{is_active}') = 'true' AS is_active
```

**Filtering / nesting / arrays:**

```sql
WHERE body#>>'{status}'           = 'active'
WHERE body#>>'{customer,name}'    = 'John Doe'   -- nested object
WHERE body#>>'{tags,0}'           = 'important'  -- array index
ORDER BY body#>>'{name}' ASC
```

**Auto-generated SQL via `dataSourceOptions.collection`.** When you want a simple grid you can skip the SQL entirely; the Query's `dataSourceOptions.collection` triggers automatic SQL generation using the column `fieldType` for casting:

```yaml
caption: "Coffee Management"
icon: "COFFEE"
dataSourceOptions:
  collection: "PROJECT/CAFE_FAVORITO"   # auto SQL
columns:
  - name: customer
    caption: "Customer"
    fieldType: string
  - name: favorite_coffee
    caption: "Favorite coffee"
    fieldType: string
keys:
  - "$oid"
options:
  collection: "PROJECT/CAFE_FAVORITO"   # link Collection for CRUD/form
  crud: true
```

Cross-ref: `references/queries.md` covers `dataSourceOptions`, `columns`, `keys`, and the rest of the Query surface.

### Complete Collection example

`PROJECT/COL_TICKETS.yaml`:

```yaml
type: object
title: "Support tickets"
description: "Tickets created from email or portal"
hints:
  idExpression: ".ticketNumber"
properties:
  ticketNumber:
    type: string
    title: "Number"
  subject:
    type: string
    title: "Subject"
  reporter:
    type: string
    title: "Reported by"
    hints:
      valueProvider: PROJECT/VP_USERS
  priority:
    type: string
    title: "Priority"
    enum: [LOW, MEDIUM, HIGH, URGENT]
  openedAt:
    type: string
    format: date-time
    title: "Opened at"
  closed:
    type: boolean
    title: "Closed"
required: [ticketNumber, subject, reporter, priority]
```

Companion CRUD Query `PROJECT/Q_TICKETS.yaml`:

```yaml
caption: "Tickets"
icon: "TICKET"
dataSourceOptions:
  collection: "PROJECT/COL_TICKETS"
columns:
  - { name: ticketNumber, caption: "Number",   fieldType: string }
  - { name: subject,      caption: "Subject",  fieldType: string }
  - { name: priority,     caption: "Priority", fieldType: string }
  - { name: openedAt,     caption: "Opened",   fieldType: datetime }
  - { name: closed,       caption: "Closed",   fieldType: boolean }
keys: ["$oid"]
options:
  collection: "PROJECT/COL_TICKETS"
  crud: true
```

---

## Mail Sources

A Mail Source polls one inbox on a cron schedule and either:

1. **Default mode (no `scanScript`)** — decodes the `References` header of each new email looking for the BPM token `<payload@*.bpm.redflag.dev>`, then triggers a BPMN message or signal event on the matching process instance. This is how "reply by email" works for tasks the platform itself sent.
2. **Custom mode (`scanScript` set)** — drops each email to a temp `.eml` file and runs the configured Script with the file path as input. The script decides whether to archive or leave it.

Mail Source artifacts are stored as documents in the platform's `mailSources` collection. The DTO that defines the YAML/JSON shape is `dev/redflag/bpm/dto/MailSourceDTO.java`.

### YAML structure

Field names match `MailSourceDTO` exactly (camelCase). Required fields are marked with `Yes`.

| Field           | Type    | Required | Description                                                                                          |
|-----------------|---------|----------|------------------------------------------------------------------------------------------------------|
| `name`          | string  | Yes      | Unique identifier for this source.                                                                   |
| `host`          | string  | Yes      | Mail server host. Use `gmail.com` to enable Gmail OAuth.                                             |
| `port`          | integer | No       | IMAP port (omit for Gmail OAuth).                                                                    |
| `ssl`           | boolean | No       | Require SSL for IMAP.                                                                                |
| `username`      | string  | No       | IMAP username (not used for Gmail OAuth).                                                            |
| `password`      | string  | No       | IMAP password / Gmail app password.                                                                  |
| `scanFolder`    | string  | No       | Folder polled. Default: `INBOX` (IMAP) / `inbox` (Gmail).                                            |
| `archiveFolder` | string  | Yes      | Folder where processed emails are moved. Default: `Todos`.                                           |
| `scanScript`    | string  | No       | Script ID `PROJECT/SCRIPT_ID` to run per email. Omitting it activates default reference processing.  |
| `cron`          | string  | No       | Schedule: `[hour[:minute]] [days of month] [days of week] [months] [years]`.                          |
| `credentials`   | string  | No       | Google OAuth JSON. Filled automatically during the authorization flow.                               |
| `token`         | string  | No       | Google access token (managed by the platform).                                                       |
| `refreshToken`  | string  | No       | Google refresh token (managed by the platform).                                                      |

**Connection types**

- **Gmail OAuth** — set `host: gmail.com`, save, then run the in-platform authorization flow. Don't fill `credentials`/`token`/`refreshToken` by hand; they are populated and rotated by the platform. The DTO marks them `readOnly`/`visible: false`.
- **IMAP (Gmail app password or other provider)** — set `host`, `port`, `ssl`, `username`, `password`. No OAuth flow.

### Reference-based processing (default)

When `scanScript` is empty, every incoming message is matched against its `References` header. If one entry matches `<payload@*.bpm.redflag.dev>` the payload is decoded into:

- a process instance / execution ID (or the literal `SIGNAL`),
- a BPMN message or signal name,
- an optional properties map.

The platform then calls one of:

- `runtimeService.messageEventReceived(name, executionId, variables)` when the ID is a process/execution ID, or
- `runtimeService.signalEventReceived(name, variables)` when the ID is `"SIGNAL"`.

The original email is also stored as a BPM resource and its path is exposed to the receiving process as the `emailResource` variable.

**Sender side.** To make a reply land on the right event, the sending Script Task encodes the binding when it calls `sendMail`:

```python
#!python3
import redflagbpm

bpm = redflagbpm.BPMService()

# Targeted message event
bpm.service.sendMail({
    "from": "noreply@example.com",
    "to": ["user@example.com"],
    "subject": "Action required: Approve order #123",
    "message": "<p>Please reply to this email to approve.</p>",
    "messageEventId": bpm.context.processInstanceId,   # process/execution ID
    "messageEventName": "approvalResponse",            # BPMN message name
    "messageEventProperties": {"orderId": 123}
})

# Global signal
bpm.service.sendMail({
    "from": "noreply@example.com",
    "to": ["team@example.com"],
    "subject": "New incident reported",
    "message": "<p>Reply to acknowledge.</p>",
    "messageEventId": "SIGNAL",
    "messageEventName": "incidentAcknowledged",
    "messageEventProperties": {"severity": "high"}
})
```

| Field                     | Description                                                                            |
|---------------------------|----------------------------------------------------------------------------------------|
| `messageEventId`          | Process / execution ID, or `"SIGNAL"`/`null` for a global signal.                      |
| `messageEventName`        | BPMN message or signal name to fire on reply.                                          |
| `messageEventProperties`  | Optional variables passed into the process at event time.                              |

See `references/scripts-and-tools.md` for the full `sendMail` payload and other `bpm.service` helpers.

### Custom scan script

When `scanScript` is set, the default reference logic is **bypassed**. For each email the platform writes the raw message to a temporary `.eml` file and runs the configured Script with the file path bound to the `email` context variable.

| Variable | Type   | Description                                            |
|----------|--------|--------------------------------------------------------|
| `email`  | string | Absolute path to the temporary `.eml` file.            |

The script's return value drives archiving:

- Return `null` or the string `"true"` (or simply fall through with no return) — email is **processed** and moved to `archiveFolder`.
- Return any other string (typically `"false"`) — email is **left untouched** and will be re-seen on the next scan.

```python
#!python3
import redflagbpm
import email
from email import policy

bpm = redflagbpm.BPMService()

email_path = bpm.context.get('email')
with open(email_path, 'rb') as f:
    msg = email.message_from_binary_file(f, policy=policy.default)

subject = msg['subject'] or ''
sender  = msg['from'] or ''
body    = msg.get_body(preferencelist=('plain',))
text    = body.get_content() if body else ''

if '[TICKET]' in subject:
    bpm.service.runtimeService.startProcessInstanceByKey(
        'ticketProcess',
        {
            'subject': subject,
            'sender': sender,
            'body': text,
            'emailResource': email_path,
        },
    )
    bpm.reply(f"Ticket created from: {sender}")
    # falls through -> archived

elif '[IGNORE]' in subject:
    bpm.reply('false')   # leave it in the inbox
```

**Reading archived emails later.** Once a message is saved as a BPM resource, scripts can read it back over HTTP:

```
GET /api/mailResource?path={resource_path}&cid={content_id}
```

- `path` — e.g. `mailSources/source1/2026/03/18/uuid.eml`
- `cid` — optional content ID for a specific attachment or inline image

### Scheduling

The `cron` field uses the platform's compact format:

```
[hour[:minute]] [days of month] [days of week] [months] [years]
```

| `cron`           | Meaning                                              |
|------------------|------------------------------------------------------|
| `8`              | Every day at 08:00.                                  |
| `8:30`           | Every day at 08:30.                                  |
| `*/5`            | Every 5 minutes (the hour field).                    |
| `9 1-15`         | At 09:00, days 1 through 15.                         |
| `10 * MON-FRI`   | At 10:00, Monday through Friday.                     |

If `cron` is empty the source still exists but is never scanned automatically (it can still be triggered manually).

### Rate limiting

For Gmail OAuth sources the platform automatically catches HTTP 429 (rate limit). When that happens the source is paused until the retry time Google indicates and then resumes on the next scheduled scan. There is no manual back-off to configure.

### Complete Mail Source example

Reference-binding source (default mode) for replies to platform-generated tasks:

```yaml
name: "support-replies"
host: "gmail.com"                   # OAuth
archiveFolder: "Todos"
cron: "*/5"                         # every 5 minutes
# scanScript intentionally omitted -> default reference-based processing
```

IMAP source with custom processing, used as a ticket inbox:

```yaml
name: "tickets-inbox"
host: "imap.example.com"
port: 993
ssl: true
username: "tickets@example.com"
password: "${SECRET_TICKETS_PASSWORD}"
scanFolder: "INBOX"
archiveFolder: "Processed"
scanScript: "PROJECT/SCR_PROCESS_TICKET_EMAIL"
cron: "*/2 * MON-FRI"               # every 2 minutes, weekdays
```

---

## Common gotchas

**Collections**

- `idExpression` is JQ, not JSONPath — write `.customer`, not `$.customer`.
- The `id` column is *not* a primary key. Two documents in the same collection with the same `id` are technically allowed; uniqueness is your responsibility (model `idExpression` on a truly unique field, or use `$oid`).
- Always include `WHERE collection = '...'` in custom SQL. Forgetting it scans the entire `document.document` table.
- Cast JSONB fields explicitly in custom SQL (`::numeric`, `::integer`, `... = 'true'`). Without casts, sorts and comparisons go lexicographic.
- Dates are stored as **epoch milliseconds**, not ISO strings, when written through the platform — use the `(TIMESTAMP with time zone 'epoch' + ...)` pattern to read them back.
- A Collection is invisible in the UI until at least one Query references it via `options.collection` + `crud: true`.
- The `.config` companion is required (see `references/artifacts-and-config.md`); deploying the YAML alone does nothing.

**Mail Sources**

- `scanScript` and reference-based processing are mutually exclusive. Setting `scanScript` disables the default `References` decoding for *every* email — even ones that were sent via `sendMail` with `messageEventId` set. If you need both behaviors, implement them inside the script.
- Gmail OAuth requires `host: gmail.com` *exactly*. Any other host string falls back to plain IMAP and the OAuth fields are ignored.
- Don't hand-edit `credentials`, `token`, or `refreshToken` — they are managed (and rotated) by the platform during the authorization flow. Hand-editing typically breaks the source until you re-authorize.
- Forgetting `archiveFolder` leaves emails in the inbox even when the script returns `"true"` — it's `Yes` in the required column for a reason. The default `"Todos"` only applies if you never override it.
- Return value semantics in `scanScript` are inverted from intuition: returning `"false"` (the *string*) keeps the email; returning `null`/`"true"`/nothing archives it.
- Cron in compact form is positional (`hour[:minute] dom dow month year`), not standard 5-field cron. `*/5 * * * *` will not parse the way you expect — use `*/5` to mean every 5 minutes.
- Scripts triggered by a Mail Source run outside any process instance unless they explicitly start one. `bpm.context.processInstanceId` is not available; you only get `email` (the .eml path).
- The `emailResource` variable is set automatically only in the default reference-based flow. In custom `scanScript` mode you must pass it yourself when you start a process (see the example).

---

## Validation summary

`validators/collection.py` and `validators/mail_source.py` check the standard schema/required-field rules above. In particular:

**Collection**

- `type: object` at the root.
- `hints.idExpression` set and points to a field that is actually unique (and `required`).
- All `properties` either have `type` or compose `$ref`/`oneOf` correctly.
- `required` lists every field that must exist for the form to submit.
- `.config` companion file exists with `type: Collection`, `lang: YAML`.

**Mail Source**

- `name` is unique within the platform.
- `host` is set (`gmail.com` for OAuth, real hostname for IMAP).
- If IMAP: `port`, `ssl`, `username`, `password` all set.
- If Gmail OAuth: `credentials`/`token`/`refreshToken` left blank for the authorization flow to fill.
- `archiveFolder` set (defaults to `Todos`, but be explicit).
- Exactly one processing mode chosen — either `scanScript` is set, or it is not. Never half-set.
- `cron` set (or accept that the source will only run on manual trigger).
- `.config` companion file exists.

Cross-references: `references/queries.md` (CRUD wiring and `dataSourceOptions.collection`), `references/scripts-and-tools.md` (`bpm.service.sendMail`, DocumentService, runtimeService events), `references/artifacts-and-config.md` (the mandatory `.config` companion files).
