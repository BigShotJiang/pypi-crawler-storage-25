# Services

Services are triggerable BPM artifacts that wrap a request/response interaction behind an optional input form. They can call internal scripts (`run:PROJECT/SCRIPT`), shell-out to `curl`, or hit any HTTP(S) endpoint, then transform and route the response to the user (message, terminal, file, query, report, another service).

A Service is the user-facing equivalent of a script: it appears in menus, asks for parameters via `inputSchema`, runs `requestScript` → request → `responseFilter` → `responseScript`, and finally renders according to `responseType`.

> Every Service artifact (`*.yaml` typed `Service`) requires a sibling `.config` file. See `references/artifacts-and-config.md`.

---

## Recipe — create a Service from scratch

In order. Don't skip the validator.

1. **Decide the id and project**: `PROJECT/SRV_ID`.
2. **Create the body** `path/to/SRV_FOO.yaml` (see § YAML structure). Pick `requestUrl` (one of: `run:PROJECT/SCRIPT`, `curl ...`, or an HTTP URL) and `responseType`.
3. **Create the `.config` sibling**:
   ```yaml
   project: "MYPROJ"
   id: "MYPROJ/SRV_FOO"
   lang: "YAML"
   type: "Service"
   description: "…"
   properties: null
   ```
4. **Wire input** if needed via `inputSchema` (see `references/forms.md`).
5. **Wire scripts** referenced by `requestScript`/`responseScript`/`requestUrl: run:…` — they need their own `.config` with `type: Script`.
6. **Validate** before declaring done:
   ```bash
   "$BPM_SKILL_DIR/scripts/validate.py" --strict path/to/SRV_FOO.yaml.config
   ```
7. **Smoke-test** by opening `Service?__service__=MYPROJ/SRV_FOO`.

---

## YAML structure

```yaml
name: "PROJECT/SRV_ID"          # Optional; usually derived from filename
caption: "Human Readable Title" # Shown in menus and window title
icon: "ANALYSIS"                # Icon name (see icon catalog)
reusable: true                  # true = window stays open after run; false = closes
requestUrl: "run:PROJECT/SCRIPT_ID"  # Required. See "Request URL forms"
requestOptions:                 # JsonObject, free-form HTTP/run options
  timeout: 30
  method: POST
  headers:
    Content-Type: application/json
  upload: false
requestScript: |                # JavaScript, executed BEFORE the request
  context.timestamp = new Date().getTime();
responseType: "MESSAGE"         # See "Response types" table
responseFilter: ".result"       # JQ expression applied to JSON response
responseScript: |               # JavaScript, executed AFTER filter
  response.label = "OK: " + response.code;
responseTarget: "PROJECT/QRY_X" # Required for QUERY / REPORT / SERVICE
targetUsers: []                 # Empty = all users
targetGroups: ["ADMIN"]         # ACL by group
menus:                          # Where the service appears in the UI
  - "Tools"
  - "Reports"
inputSchema:                    # JSON Schema for the parameter form
  type: object
  title: "Parameters"
  required: [field1]
  properties:
    field1:
      type: string
      title: "Label"
```

### Top-level fields

| Field            | Type        | Required | Description |
|------------------|-------------|----------|-------------|
| `name`           | string      | no       | Fully-qualified ID `PROJECT/SRV_ID`. If omitted, derived from path. |
| `caption`        | string      | yes      | Display title in menus and window header. |
| `icon`           | string      | no       | Named icon (catalog defined in the platform). |
| `reusable`       | boolean     | no       | `true` keeps window open for repeat runs; `false` closes it after first run. |
| `requestUrl`     | string      | yes      | One of: `run:...`, `curl ...`, `http://...`/`https://...`. |
| `requestOptions` | JsonObject  | no       | HTTP/run options: `timeout`, `method`, `headers`, `body`, `upload`, etc. Free-form JSON object. |
| `requestScript`  | string      | no       | JavaScript executed before the request to mutate `context`. |
| `responseScript` | string      | no       | JavaScript executed after `responseFilter` to mutate `response`. |
| `responseType`   | string enum | yes      | See response types table below. Case-sensitive (UPPERCASE). |
| `responseFilter` | string      | no       | JQ expression applied to JSON response payload. |
| `responseTarget` | string      | cond.    | Required when `responseType` is `QUERY`, `REPORT`, or `SERVICE`. |
| `targetUsers`    | string[]    | no       | Allow-list of usernames. Empty = no per-user restriction. |
| `targetGroups`   | string[]    | no       | Allow-list of group names (ACL). |
| `inputSchema`    | JsonObject  | no       | JSON Schema describing the input form (object). Empty = no form. |
| `menus`          | string[]    | no       | Menu paths where the service is exposed. |

Source of truth: `dev/redflag/bpm/dto/ServiceInfo.java`.

---

## `requestUrl`: three valid forms

The `requestUrl` field selects the execution backend. Exactly one of these patterns must match.

### 1. Internal script: `run:PROJECT/SCRIPT_ID`

Runs a Script artifact in-process. The form values become the script's `context` (Python: `bpm.context.json`).

```yaml
requestUrl: "run:HLW/SEARCH_ORDERS"
```

The script's stdout / response headers determine the payload. See `references/scripts-and-tools.md`.

### 2. Shell: `curl ...`

A literal `curl` command line. Default timeout is 300 seconds. VTL `${var}` substitution from form fields is applied.

```yaml
requestUrl: "curl -X POST https://api.example.com/v1/run -H 'Authorization: Bearer ${token}' -d '${payload}'"
requestOptions:
  timeout: 60
```

### 3. HTTP(S) URL: `http://...` or `https://...`

A direct HTTP request. VTL `${field}` substitution from form fields is applied to the URL.

```yaml
requestUrl: "https://api.example.com/users/${userId}/orders?status=${status}"
requestOptions:
  method: GET
  headers:
    Authorization: "Bearer ${token}"
```

---

## `requestOptions`

`requestOptions` is a free-form `JsonObject` (no fixed schema in `ServiceInfo`). Common keys:

| Key       | Type    | Notes |
|-----------|---------|-------|
| `timeout` | integer | Max wait in seconds. Default 300 for `curl`. |
| `method`  | string  | `GET`, `POST`, `PUT`, `DELETE`, `PATCH` (HTTP form). |
| `headers` | object  | HTTP headers map (HTTP/`curl` forms). |
| `body`    | string/object | Request body. Often built in `requestScript`. |
| `upload`  | boolean | `true` enables POST/multipart for file-upload form fields. |

When `upload: true` and the form contains upload-typed fields, files are auto-attached as multipart parts.

---

## `requestScript`

JavaScript snippet executed **before** the request fires. Lets you derive values, add auth headers, or restructure the payload.

Available bindings:

- `context` — the form input object. Mutate in place. Every `inputSchema` property is exposed as `context.<fieldName>`.
- VTL substitution `${fieldName}` in `requestUrl` reads the **post-script** `context`.

```javascript
context.timestamp = new Date().getTime();
context.searchQuery = context.customer_name + " " + context.order_id;
context.headers = { Authorization: "Bearer " + context.token };
```

Language: JavaScript (Nashorn/GraalJS-style runtime). Keep it pure and side-effect-free; persistence belongs in scripts.

---

## `responseScript`

JavaScript snippet executed **after** the response is received and `responseFilter` is applied.

Available bindings (shape depends on `responseType`):

- `response` — mutate or reassign to change what the renderer receives.
  - `QUERY` → JsonArray
  - `SERVICE` / `REPORT` → JsonObject
  - `MESSAGE` / `TERMINAL` → String
  - `ASSET` / `DISPLAY` → binary; transformation here is uncommon

```javascript
// QUERY: enrich rows
response.forEach(r => { r.label = r.code + " - " + r.name; });

// MESSAGE: wrap in HTML
response = "<div class='alert alert-success'>" + response + "</div>";

// SERVICE: reshape for target service input
response = { formData: { id: response.customer.id, name: response.customer.name } };
```

---

## `inputSchema`

Standard JSON Schema (object) describing the parameter form shown before execution. Stored as a `JsonObject`, so it must be valid JSON when serialized — write it as YAML mapping in the file.

```yaml
inputSchema:
  type: object
  title: "Search Orders"
  description: |
    <p>Find orders by <strong>customer</strong> or ID.</p>
  required:
    - customer_name
  properties:
    customer_name:
      type: string
      title: "Customer Name"
    order_id:
      type: string
      title: "Order ID"
    auth_token:
      type: string
      title: "API Token"
      hints:
        subtype: password
```

`hints.subtype` enables widgets like `password`, `date`, `textarea`, `upload`. See `references/forms.md` for the full widget catalog.

---

## `responseType`

There are **two relevant lists** of values. Use the configurator-common list unless you have a runtime reason to need the others.

### Configurator-common values (7)

These are the constants exposed in `dev/redflag/bpm/dto/ServiceInfo.java:26-32` and are the values you almost always write in YAML.

| Constant in code  | YAML value  | Purpose |
|-------------------|-------------|---------|
| `MESSAGE`         | `MESSAGE`   | Default. Display a status message (string / HTML). |
| `TERMINAL`        | `TERMINAL`  | Monospaced, scrollable terminal-style output. |
| `ASSET`           | `ASSET`     | Download a file (PDF, Excel, ...). Endpoint returns binary + headers. |
| `ASSET_DISPLAY`   | `DISPLAY`   | **Note:** constant is `ASSET_DISPLAY` but YAML value is `"DISPLAY"`. Inline asset (e.g. PDF viewer). |
| `QUERY`           | `QUERY`     | Open / refresh a query with the response data. Requires `responseTarget`. |
| `SERVICE`         | `SERVICE`   | Open another service with the response as input. Requires `responseTarget`. |
| `REPORT`          | `REPORT`    | Generate a report with the response as parameters. Requires `responseTarget`. |

### Full runtime enum (16) — `IPOResponseType`

The runtime IPO (Input/Process/Output) channel can emit any of these. Most are produced by the platform itself, but advanced services occasionally need to set them explicitly (e.g. `AGENT`, `IPO`, `OPEN*`).

| Value                | Configurator-common? | Notes |
|----------------------|----------------------|-------|
| `TERMINAL`           | yes                  | Terminal output. |
| `TERMINAL_UPDATE`    | no                   | Streaming update to a terminal pane. |
| `TERMINAL_DELETE`    | no                   | Streaming delete event. |
| `TERMINAL_CREATE`    | no                   | Streaming create event. |
| `ERROR`              | no                   | Error envelope (rendered as error). |
| `MESSAGE`            | yes                  | Default user-facing message. |
| `AGENT`              | no                   | Hand off to an AI agent channel. |
| `QUERY`              | yes                  | Push data into a Query target. |
| `IPO`                | no                   | Nested IPO continuation. |
| `CUBE`               | no                   | Render in a cube/OLAP target. |
| `REPORT`             | yes                  | Render in a Report target. |
| `ASSET`              | yes                  | Binary file download. |
| `OPEN`               | no                   | Open an artifact in current frame. |
| `OPEN_UPDATE`        | no                   | Open + push update event. |
| `OPEN_NEW`           | no                   | Open in a new frame. |
| `OPEN_NEW_UPDATE`    | no                   | Open in new frame + push update. |

> The constant `ASSET_DISPLAY` (value `"DISPLAY"`) lives in `ServiceInfo` but is **not** in `IPOResponseType`. It is a configurator-side hint that selects inline rendering for an `ASSET` payload.

Source of truth: `dev/redflag/core/services/ipo/IPOResponseType.java` (16 values), `dev/redflag/bpm/dto/ServiceInfo.java:26-32` (7 configurator constants).

---

## When to use which `responseType`

| Use case                                 | `responseType`           |
|------------------------------------------|--------------------------|
| Show a brief success/failure banner      | `MESSAGE`                |
| Stream long log output to a console pane | `TERMINAL`               |
| Let user download generated PDF/XLSX     | `ASSET`                  |
| Show generated PDF inline                | `DISPLAY`                |
| Populate a tabular query with rows       | `QUERY` + `responseTarget` |
| Generate a parameterized report          | `REPORT` + `responseTarget` |
| Pre-fill another service's form          | `SERVICE` + `responseTarget` |
| Open an arbitrary artifact (advanced)    | `OPEN` / `OPEN_NEW`      |
| Hand a long task to an AI agent (adv.)   | `AGENT`                  |
| Stream incremental terminal updates (adv.) | `TERMINAL_UPDATE` etc. |

---

## `responseTarget`

Specifies the artifact id that receives the response payload. Required for:

| `responseType` | `responseTarget` must point to |
|----------------|-------------------------------|
| `QUERY`        | a Query artifact (`PROJECT/QRY_*`) |
| `REPORT`       | a Report artifact (`PROJECT/RPT_*`) |
| `SERVICE`      | another Service artifact (`PROJECT/SRV_*`) |

For the advanced `OPEN*` types, `responseTarget` is the artifact path being opened.

```yaml
responseType: QUERY
responseTarget: "HLW/QRY_ORDER_RESULTS"
```

---

## `responseFilter`

JQ expression applied to the JSON response **before** `responseScript`. Use it to extract or reshape:

```yaml
responseFilter: ".result"                            # extract field
responseFilter: ".data.orders[]"                     # flatten nested array
responseFilter: ".items | map(select(.active))"      # filter
responseFilter: "{id: .id, name: .name}"             # reshape
```

If the response is not JSON (e.g. plain text from `MESSAGE` / `TERMINAL`), omit `responseFilter`.

---

## Common gotchas

- **`responseType` is case-sensitive.** Always UPPERCASE: `MESSAGE`, not `message` or `Message`.
- **`DISPLAY` vs `ASSET_DISPLAY`.** The YAML value is `DISPLAY`, even though the Java constant is named `ASSET_DISPLAY`.
- **`inputSchema` and `requestOptions` are `JsonObject`.** Plain YAML mappings serialize fine, but anchors/aliases that produce non-object structures will fail Jackson deserialization.
- **`responseTarget` is silently ignored** for `MESSAGE` / `TERMINAL` / `ASSET` / `DISPLAY`. It is **required** (and validated at runtime) for `QUERY` / `REPORT` / `SERVICE`.
- **`reusable: false` closes the window** as soon as the response renders — do not use it for `QUERY` services where the user expects to keep browsing the result.
- **`requestScript` mutations to `context` are visible** to VTL `${...}` in `requestUrl` and to the request body. `responseScript` mutations to `response` are visible to the renderer.
- **VTL `${var}` substitution** in `requestUrl` only looks at form-derived `context` keys; for HTTP `headers`/`body`, build them in `requestScript` rather than relying on substitution.
- **Default timeout for `curl`** is 300s; for `run:` and HTTP, set `timeout` explicitly when calls may run long.

---

## Examples

### 1. Simple service: run a script, show a message

```yaml
caption: "Mark Order Paid"
icon: "CHECK"
reusable: false
requestUrl: "run:HLW/MARK_ORDER_PAID"
responseType: MESSAGE
responseScript: |
  response = "<div class='alert alert-success'>Order " + context.order_id + " marked as paid.</div>";
inputSchema:
  type: object
  required: [order_id]
  properties:
    order_id:
      type: string
      title: "Order ID"
menus: ["Orders"]
```

### 2. Asset download

```yaml
caption: "Generate PDF Report"
icon: "FILE"
reusable: false
requestUrl: "run:HLW/GENERATE_PDF"
requestOptions:
  timeout: 120
responseType: ASSET
inputSchema:
  type: object
  required: [startDate, endDate]
  properties:
    startDate:
      type: integer
      title: "Start Date"
      hints: { subtype: date }
    endDate:
      type: integer
      title: "End Date"
      hints: { subtype: date }
    format:
      type: string
      title: "Format"
      enum: [PDF, Excel]
      default: PDF
targetGroups: [ADMIN]
```

The script must emit binary content with `Content-Type` and (optionally) `Content-Disposition` headers.

### 3. Service that opens a query

```yaml
caption: "Search Orders"
icon: "SEARCH"
reusable: true
requestUrl: "run:HLW/SEARCH_ORDERS"
responseType: QUERY
responseFilter: ".data.orders[]"
responseTarget: "HLW/QRY_ORDER_RESULTS"
inputSchema:
  type: object
  required: [customer_name]
  properties:
    customer_name: { type: string, title: "Customer Name" }
    order_id:      { type: string, title: "Order ID" }
menus: ["Orders"]
targetGroups: [SALES]
```

### 4. Long job: respond immediately, finish in background

A Service whose script kicks off a multi-minute job and renders an HTML banner synchronously. When the `requestUrl` is `run:...`, the script's response is built from **stdout + `_responseHeaders`** (same protocol as endpoints) — there is no `bpm.reply` involved at this layer. After writing the response the parent forks the heavy work and exits. Pattern detail in `references/scripts-and-tools.md` § 4.3.

`OPS/SRV_REBUILD_INDEX.yaml`:

```yaml
caption: "Rebuild Search Index"
icon: "REFRESH"
reusable: false
requestUrl: "run:OPS/REBUILD_INDEX"
responseType: MESSAGE
inputSchema:
  type: object
  properties: {}
targetGroups: [ADMIN]
menus: ["Operations"]
```

`OPS/REBUILD_INDEX` (`lang: "Shell"`):

```python
#!/usr/bin/env python3
import os, sys
import redflagbpm
bpm = redflagbpm.BPMService()

# Capture identity BEFORE forking — bpm.context is gone in the child.
# The BPM launcher auto-injects bpm.context.userId with the logged-in user
# for UI-launched Services / Queries / Pages.
caller = bpm.context.get("userId")

# Synchronous response: HTML banner, status 200
h = bpm.context.json._responseHeaders
h["status"] = "200"
h["Content-Type"] = "text/html"
print("<div class='alert alert-info'><strong>Started.</strong> "
      "Reindex is running in the background.</div>")
sys.stdout.flush()

# Detach the heavy work
if os.fork() == 0:
    os.setsid()
    os.close(0); os.close(1); os.close(2)
    try:
        rebuild_index()
        if caller:
            bpm.service.notifyUser(caller, "Index rebuild OK")
    except Exception as e:
        if caller:
            bpm.service.notifyUser(caller, f"Index rebuild FAILED: {e}")
```

> There is no `bpm.user` property in the SDK. Use `bpm.context.userId` — it is auto-injected by the BPM launcher view (Services, Queries, Pages) for the logged-in user. For Services launched via token URL or programmatically (`bpm.execute(...)`) `userId` is only set if the caller put it in the context — guard with `bpm.context.get("userId")`. Do **not** use `getattr(bpm.context, "userId", None)`: the Context proxy raises `NameError` (not `AttributeError`) for missing keys, so `getattr`'s default is never returned.

#### Status 100 for ASSET-typed services

When a Service has `responseType: ASSET` (or `DISPLAY`) and the underlying response carries an HTTP status in the **100-199** range or **204**, the platform short-circuits the file download and renders the body as an HTML message banner instead. Status `>= 400` produces an `ERROR` banner the same way. This is the cleanest "I started a long export — there is no file yet" hand-off:

`OPS/SRV_REPORT.yaml`:

```yaml
caption: "Generate Monthly Report (PDF)"
requestUrl: "run:OPS/REPORT_BUILD"
responseType: ASSET
inputSchema:
  type: object
  properties:
    deliveryEmail:
      type: string
      title: "Email to deliver the PDF"
```

`OPS/REPORT_BUILD` (`lang: "Shell"`):

```python
#!/usr/bin/env python3
import os, sys
import redflagbpm
bpm = redflagbpm.BPMService()

email = bpm.context.get("deliveryEmail")

# status 100 turns the ASSET-typed response into a MESSAGE banner — no download
h = bpm.context.json._responseHeaders
h["status"] = "100"
h["Content-Type"] = "text/html"
print("<div class='alert alert-info'>Report build started. "
      f"You'll get the PDF at <strong>{email}</strong> when it finishes.</div>")
sys.stdout.flush()

if os.fork() == 0:
    os.setsid()
    os.close(0); os.close(1); os.close(2)
    build_pdf_and_email(email)
```

### 5. External HTTP API with response transformation

```yaml
caption: "External API Integration"
icon: "CLOUD"
reusable: true
requestUrl: "https://api.example.com/v1/process?userId=${user_id}&action=${action}"
requestOptions:
  timeout: 30
  method: GET
requestScript: |
  context.headers = {
    "Authorization": "Bearer " + context.api_token,
    "Content-Type": "application/json"
  };
responseType: MESSAGE
responseFilter: ".result.message"
responseScript: |
  response = "<div class='alert alert-success'><strong>OK:</strong> " + response + "</div>";
inputSchema:
  type: object
  required: [user_id, action, api_token]
  properties:
    user_id:   { type: string, title: "User ID" }
    action:    { type: string, title: "Action", enum: [create, update, delete] }
    api_token: { type: string, title: "API Token", hints: { subtype: password } }
targetGroups: [ADMIN]
```

---

## End-to-end example

Service that calls an internal script, filters the JSON response, enriches each row in JS, and pushes the result into a query target. Includes ACL, menu placement, and a parameter form.

```yaml
name: "HLW/SRV_SEARCH_ORDERS"
caption: "Search Orders"
icon: "SEARCH"
reusable: true

requestUrl: "run:HLW/SEARCH_ORDERS_SCRIPT"
requestOptions:
  timeout: 60

requestScript: |
  // Compose a single search expression from the two form fields
  context.searchQuery = (context.customer_name || "").trim();
  if (context.order_id) context.searchQuery += " #" + context.order_id;
  context.requestedAt = new Date().toISOString();

responseType: QUERY
responseFilter: ".data.orders[]"
responseScript: |
  response.forEach(o => {
    o.totalFormatted = "$" + (o.total || 0).toFixed(2);
    o.statusColor    = o.status === "completed" ? "green" : "orange";
    o.daysOld        = Math.floor((Date.now() - o.orderDate) / 86400000);
  });
responseTarget: "HLW/QRY_ORDER_RESULTS"

targetGroups: [SALES, MANAGEMENT]
menus:
  - "Orders"
  - "Search"

inputSchema:
  type: object
  title: "Search Orders"
  description: |
    <p>Find orders by <strong>customer</strong> or <strong>order ID</strong>.</p>
  required: [customer_name]
  properties:
    customer_name:
      type: string
      title: "Customer Name"
    order_id:
      type: string
      title: "Order ID"
    auth_token:
      type: string
      title: "API Token"
      hints:
        subtype: password
```

---

## Validation summary

`validators/service.py` checks:

- **`responseType`** is one of (UPPERCASE, exact match):
  `TERMINAL`, `TERMINAL_UPDATE`, `TERMINAL_DELETE`, `TERMINAL_CREATE`, `ERROR`, `MESSAGE`, `AGENT`, `QUERY`, `IPO`, `CUBE`, `REPORT`, `ASSET`, `DISPLAY`, `OPEN`, `OPEN_UPDATE`, `OPEN_NEW`, `OPEN_NEW_UPDATE`.
  Configurator-common subset: `MESSAGE`, `TERMINAL`, `ASSET`, `DISPLAY`, `QUERY`, `SERVICE`, `REPORT`.
- **`responseTarget`** is set whenever `responseType` is `QUERY`, `REPORT`, or `SERVICE` (and for `OPEN*` advanced uses).
- **`requestUrl`** matches one of:
  - `^run:[A-Z][A-Z0-9_]*/[A-Z][A-Z0-9_]*$`
  - `^curl(\s+.+)+$`
  - `^https?://.+$`
- **`inputSchema`** is a valid JSON Schema object (`type: object` recommended) or omitted/empty.
- **`requestOptions`** is a JsonObject (mapping); arrays/scalars are not accepted.
- **`caption`** is non-empty.
- **A sibling `.config` file exists** for the artifact (see `references/artifacts-and-config.md`).

---

## Source of truth

- `dev/redflag/bpm/dto/ServiceInfo.java` — top-level YAML schema, configurator constants for `responseType` (lines 26-32), JSON/YAML serialization.
- `dev/redflag/core/services/ipo/IPOResponseType.java` — full runtime enum of 16 IPO response types.

## Cross-references

- `references/scripts-and-tools.md` — how `run:PROJECT/SCRIPT_ID` endpoints are written, and the `bpm.context` API.
- `references/queries.md` — target artifact for `responseType: QUERY`.
- `references/reports.md` — target artifact for `responseType: REPORT`.
- `references/forms.md` — widget hints (`subtype`, `upload`, etc.) usable in `inputSchema`.
- `references/artifacts-and-config.md` — mandatory `.config` sidecar.
