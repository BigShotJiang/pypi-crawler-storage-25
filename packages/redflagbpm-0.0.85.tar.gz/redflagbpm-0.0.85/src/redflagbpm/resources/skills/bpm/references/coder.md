# Coder

The **Coder** is an AI agent that edits a configured repo from inside BPM. Each chat spawns its own `opencode acp` subprocess (under user `bpm-coder`) that clones the repo, reads/writes files via `bpm_*` tools, runs tests, and pushes commits back using the repo's SSH key.

This page describes only what a configurator sees and edits — the **`RepoDTO`** (the form used to register a repo for the Coder), plus the two repo-versioned config files the Coder reads at spawn time. Internal ACP plumbing (JSON-RPC framing, sandbox runners, plugin protocol) is out of scope; see `doc/ACP_*.md` if you need that level.

> Cross-references: `references/sandbox.md` (the `sandbox:` field below), `references/analyst.md` (the Analyst is the read-only sibling of the Coder and shares the sandbox model), `references/opencode-resources.md` (catalog of opencode kinds — agents, skills, commands, modes, plugins — usable in `.opencode/` of the repo).

---

## RepoDTO fields

A repo is registered through the BPM Repos admin form, which renders the schema of `RepoDTO`. Order, required-ness and hints below come straight from the DTO annotations (`dev/redflag/bpm/dto/RepoDTO.java`).

| # | Field | Required | Type | Notes |
|---|---|---|---|---|
| 1 | `url` | yes | string | SSH URL of the repo (e.g. `git@github.com:org/repo.git`). HTTPS is not supported — auth is by SSH key only. |
| 2 | `branch` | no | string | Branch to check out. Defaults to the remote's default branch. |
| 3 | `key` | yes | upload | Private SSH key. Rendered as an upload widget (`subtype: upload`, `resourcePath: repoKeys`). See **SSH key upload** below. |
| 4 | `username` | yes | string | Git committer name written into commits made by the Coder. |
| 5 | `email` | yes | string | Git committer email. |
| 6 | `path` | no | string | Subdirectory inside the repo to operate on. Empty = repo root. |
| 7 | `processes` | no | text | Free-text list of BPM processes / artifacts this repo backs (documentation only). |
| 8 | `description` | no | text | Free-text description shown in listings. |
| 9 | `model` | no | string | Default LLM model for the Coder, in `providerID/modelID` format. See **Model field** below. Empty = use the opencode config default. |
| 10 | `sandbox` | no | YAML | Sandbox runner config. See `references/sandbox.md`. |
| 11 | `opencodeConfig` | no | YAML | Custom opencode config merged on top of the BPM base. See **opencodeConfig overrides** below. |

All four required fields (`url`, `key`, `username`, `email`) must be set before the form will save.

---

## SSH key upload

The `key` field is rendered as an upload widget, not a textarea. It points at the BPM resource path `repoKeys/`:

- Click the upload control and pick the **private** key file (typically `id_ed25519` or `id_rsa`, **without** passphrase — the Coder cannot prompt for one).
- BPM stores the key under `repoKeys/<userId>.key` plus a sidecar `repoKeys/<userId>.json` with metadata.
- At spawn time, the Coder materializes the key to a tempfile and exports `GIT_SSH_COMMAND` so `git clone / fetch / push` work without further setup.
- The remote (Gitea, GitHub, GitLab, …) must list this key as a deploy key or user key for the repo.

If the same `userId` already has a key uploaded for another repo, re-uploading replaces it — the slot is per user, not per repo.

---

## `model` field

Format: `providerID/modelID` (slash-separated). The form's value provider `opencodeModels` populates a filterable dropdown of models that are actually usable given the current BPM-level provider keys.

A model is "usable" when **either** its provider has an API key configured in BPM parameters, **or** the provider is `opencode` (Zen free tier). Provider keys are read by name from BPM parameters:

| Provider | BPM parameter | Example model values |
|---|---|---|
| `google` | `GEMINIAI_API_KEY` | `google/gemini-flash-latest`, `google/gemini-flash-lite-latest`, `google/gemini-2.5-pro` |
| `openai` | `OPENAI_API_KEY` | `openai/gpt-5.1-codex-max`, `openai/gpt-5.1` |
| `anthropic` | `ANTHROPIC_API_KEY` | `anthropic/claude-sonnet-4-5`, `anthropic/claude-opus-4-1` |
| `amazon-bedrock` | `BEDROCK_CONFIG` | `amazon-bedrock/us.anthropic.claude-haiku-4-5-20251001-v1:0`, `amazon-bedrock/us.anthropic.claude-sonnet-4-5-20250929-v1:0` |
| `opencode` | none (Zen free tier) | `opencode/grok-code`, `opencode/code-supernova` |

Notes:

- API keys are **never** put on `RepoDTO`. They are global BPM parameters, applied to every repo. There is no per-repo provider key — opencode auth is process-wide.
- `model` here sets the **default** for new chats on this repo. The user can still pick a different model per chat from the Coder view's combo box.
- Avoid `google/gemini-2.5-flash` as default — it has a known regression with toolsets ≥5 tools (silently returns 0 output tokens). Prefer `google/gemini-flash-latest` or `openai/gpt-5.1-codex-max`.
- Empty `model` → falls back to whatever the merged opencode config (BPM base + `.bpm_opencode.config` + `opencodeConfig`) declares.

### Bedrock parameter (`BEDROCK_CONFIG`)

Unlike the other providers, `BEDROCK_CONFIG` is **not a single API key** — it is a multi-line YAML blob stored as a BPM parameter. AWS auth needs several values (region + key id + secret + optional session token) and the YAML keeps them grouped instead of polluting the parameters list with `AWS_*` siblings.

Shape:

```yaml
# BPM parameter: BEDROCK_CONFIG
region: us-east-1
accessKeyId: AKIAxxxxxxxxxxxxxxxx
secretAccessKey: xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
sessionToken: ""        # optional — only when using STS / temporary creds
```

At spawn time BPM expands each key to the corresponding `AWS_*` env var (`AWS_REGION`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_SESSION_TOKEN`) and exports them to the opencode subprocess. opencode auto-detects the provider as `amazon-bedrock` from those env vars alone — no extra `provider:` block needed in `opencode.json`. **The Bedrock provider only appears in the model combo when `BEDROCK_CONFIG` exists and is non-empty** — same gating logic as the other API-key parameters.

#### Use **inference profile IDs**, not raw model IDs

Most current Claude models on Bedrock do **not** accept on-demand calls by raw model id. AWS returns `ValidationException: Invocation of model ID ... with on-demand throughput isn't supported. Retry your request with the ID or ARN of an inference profile that contains this model.`

Use the regional inference profile id (prefix `us.`, `eu.`, `apac.`, or `global.`):

| Raw model id (won't work) | Inference profile id (use this) |
|---|---|
| `anthropic.claude-haiku-4-5-20251001-v1:0` | `us.anthropic.claude-haiku-4-5-20251001-v1:0` |
| `anthropic.claude-sonnet-4-5-20250929-v1:0` | `us.anthropic.claude-sonnet-4-5-20250929-v1:0` |
| `anthropic.claude-opus-4-1-20250805-v1:0` | `us.anthropic.claude-opus-4-1-20250805-v1:0` |

So the full model field on `RepoDTO` / `AnalystInfo` looks like `amazon-bedrock/us.anthropic.claude-haiku-4-5-20251001-v1:0`. List the available profiles for an account/region with `aws bedrock list-inference-profiles --region <region>`.

The legacy `claude-3-*` and `claude-3-5-haiku` profiles also exist but Bedrock returns "marked Legacy and you have not been actively using the model in the last 30 days" if you have not invoked them recently — prefer the active 4.x line.

#### Alternative: EC2 instance role (no parameter)

If the BPM JVM runs directly on an EC2 instance, you can skip `BEDROCK_CONFIG` entirely and attach an IAM role with `bedrock:InvokeModel*` to the instance. The AWS SDK inside opencode will pick up rotating creds via IMDSv2 (`http://169.254.169.254`). Two non-obvious requirements before this works:

1. **EC2 instance metadata `HttpPutResponseHopLimit` must be `2`** (default is `1`). With hop limit 1, the host can reach IMDS but Docker containers (one extra network hop) cannot — opencode hangs on the metadata call. Fix once per instance:
   ```bash
   aws ec2 modify-instance-metadata-options \
     --instance-id i-xxxxxxxxxxxxxxxxx \
     --http-put-response-hop-limit 2 \
     --http-tokens required
   ```
   Or set it in the launch template / Terraform `metadata_options { http_put_response_hop_limit = 2 }`.
2. **The sandbox network must allow link-local** (`169.254.0.0/16`). The default `bridge` network does. The hardened `agent-runtime` network in `references/sandbox.md` **drops link-local on purpose** — Bedrock-via-IAM-role will not work there. Either keep `network: bridge` for repos that use Bedrock, or add a one-off rule to your custom network.

This path does **not** apply on EKS — pods don't see the node's IMDS. For EKS use IRSA (web identity token) which is not yet wired; today, on EKS, fall back to `BEDROCK_CONFIG`.

---

## `opencodeConfig` overrides

A YAML object merged (deep merge) on top of the BPM base opencode config at spawn time. BPM still enforces the invariants — native tools off, BPM plugin loaded — those cannot be overridden.

The most common keys you will set:

```yaml
# Default model for this repo (same as RepoDTO.model, but here you can also
# set per-agent overrides below).
model: "openai/gpt-5.1-codex-max"

# Per-agent system prompt. The agent name comes from the opencode config
# (the BPM base defines `build` as the main coder agent).
agent:
  build:
    prompt: |
      You are the Coder for this repo. Before proposing changes:
      - Call bpm_coder_current_file() to see the editor's live file.
      - When touching a YAML, validate it with bpm_bash python3 ... before saving.
      - For commits, use bpm_coder_git, not `bash git`.

# Top-level instruction files: paths (absolute or repo-relative) to markdown
# files appended to the system prompt for ALL agents in this repo.
instructions:
  - "AGENTS.md"
  - "docs/coder-rules.md"

# Extra MCP servers, in addition to the BPM MCP that BPM auto-wires per chat.
mcpServers:
  myservice:
    type: "remote"
    url: "https://mcp.example.com/sse"
    headers:
      Authorization: "Bearer @MY_SERVICE_TOKEN"
```

### Critical: `prompt` vs `instructions`

These two keys are easy to confuse and **opencode silently ignores the wrong ones**:

| You want… | Use this | Shape | Where it goes |
|---|---|---|---|
| A system prompt for one agent | `agent.<name>.prompt` | **string** | Prepended to that agent's system prompt. |
| A list of instruction files appended for all agents | `instructions` | **array of file paths** | Each file is read at spawn and concatenated to the system prompt. |

Common mistakes (all silently no-op):

- `agent.build.instructions: "..."` — wrong key, ignored. Use `prompt`.
- `agent.build.systemPrompt: "..."` — not a real key, ignored. Use `prompt`.
- `instructions: "AGENTS.md"` — must be an **array**, not a string.
- Putting prompt **text** into `instructions` — `instructions` only takes file paths; the file content is what gets injected.

If your custom prompt does not seem to take effect, check this first.

---

## Web tools (`webfetch` / `websearch`)

opencode ships two native HTTP-only tools — `webfetch` (read URLs) and `websearch` (search engine queries) — that the BPM base config **does NOT deny**. They stay **enabled by default** for every Coder repo: dev-time use cases (read PR descriptions, fetch upstream docs, look up APIs) are common enough that the default is opt-out, not opt-in.

To turn them off on a repo that handles secrets or that you want offline, add explicit denies via `opencodeConfig`:

```yaml
opencodeConfig:
  permission:
    webfetch: "deny"
    websearch: "deny"
```

Notes:

- **Asymmetry with the Analyst.** `AnalystInfo` exposes dedicated `webfetchEnabled` / `websearchEnabled` flags (default **off**), and `BPMAnalystViewComponent` injects `permission.<id>: "deny"` whenever they are false. The Coder has no such flag because its audience is dev — flipping to "deny by default" would block the most common use cases. Mirror the Analyst defaults manually in `opencodeConfig` if your repo is sensitive.
- **`permission.<id>: "deny"` filters the tool out of `tools/list`** entirely (the LLM does not even see it). Same mechanism opencode uses for the BPM-enforced FS/shell denies.
- **BPM invariants do not force these.** `OpencodeConfigBuilder.FORCED_DENY_PERMISSIONS` only covers `bash`, `read`, `write`, `edit`, `glob`, `grep`, `ls`, `lsp`, `patch`, `multiedit`. Your `permission.webfetch` / `permission.websearch` overrides stick.
- **Risks if you leave them on.** `webfetch` is GET-only (no body exfil), but `websearch` can leak prompt or context fragments into the search query — the agent may include sensitive data in the search string itself.

---

## Repo-versioned config: `.bpm_opencode.config` and `.bpm_sandbox.config`

A repo can ship its own defaults by committing two YAML files at the repo root:

| File | Overridden by | Purpose |
|---|---|---|
| `.bpm_opencode.config` | `RepoDTO.opencodeConfig` (deep merge) | Opencode config defaults (model, agent prompts, MCP servers, instructions). |
| `.bpm_sandbox.config` | `RepoDTO.sandbox` (deep merge) | Sandbox runner defaults (`mode`, `image`, `service:` block). See `references/sandbox.md`. |

Resolution order at spawn time:

1. BPM base (built-in invariants — native tools off, BPM plugin, BPM MCP wiring).
2. `.bpm_<x>.config` from the repo (if present).
3. `RepoDTO.<x>` from the form.

Each step **deep-merges** on top of the previous. Use `.bpm_opencode.config` for "every chat on this repo gets these settings" rules that should travel with the repo (e.g. an `AGENTS.md` instruction file living next to it). Use `RepoDTO.opencodeConfig` for environment- or installation-specific overrides.

---

## Repo-versioned `.opencode/` (subagents, skills, commands, modes)

Beyond the two `.bpm_*.config` YAML files described above, the Coder also auto-discovers an **`.opencode/` directory at the repo root** if it exists. This is the same convention native opencode uses for project-local resources, so a repo that already works with `opencode` standalone CLI gets its agents/skills/commands picked up by the BPM Coder for free.

### Layout

`.opencode/` follows opencode's plural-names convention (opencode 1.14+):

```
<repo-root>/
  .opencode/
    agents/
      reviewer/
        reviewer.md           ← subagent or primary agent (frontmatter declares mode)
    skills/
      sql-conventions/
        SKILL.md              ← skill markdown
    commands/
      deploy-staging/
        deploy-staging.md     ← slash command
    modes/
      strict/
        strict.md             ← primary agent / mode
    prompts/                  ← any other canonical kind opencode supports
      ...
```

Any of the canonical opencode kinds (`agents`, `skills`, `commands`, `modes`, `plugins`, `tools`, `themes`) found under `.opencode/` is wired into the chat's `OPENCODE_CONFIG_DIR` at spawn time via symlink. opencode auto-discovers them when the chat starts.

### Resolution order

```
1. CODER_OPENCODE_CONFIG_DIR (global defaults, default /usr/local/lib/bpm/coder)
2. <repo-root>/.opencode (repo-versioned)
```

Step 2 is processed AFTER step 1 — meaning a repo `.opencode/agents/reviewer/reviewer.md` **overrides** a global `reviewer/reviewer.md` of the same name (the symlink gets replaced). This lets a repo customize a globally available agent for its specific context (e.g. a generic `reviewer` becomes "reviewer specialized for our SQL style") without having to fork the global.

### What you can put there

- **Subagents** (`agents/<name>/<name>.md` with `mode: subagent` in frontmatter) — callable as tools by the primary agent. The primary invokes them with `@<name>` or by tool call. Useful for "specialist" personas: `chart-builder`, `report-writer`, `migration-reviewer`, etc.
- **Primary agents / modes** (`agents/<name>/<name>.md` with `mode: primary` or under `modes/`) — alternative top-level personas the user can switch to. Primary mode picker in the Coder UI surfaces these.
- **Skills** (`skills/<name>/SKILL.md` plus optional helpers next to it) — knowledge bundles loaded by name. Best for procedures the agent should follow exactly (e.g. "how we write migrations").
- **Slash commands** (`commands/<name>/<name>.md`) — user-typeable shortcuts (e.g. `/deploy-staging`).

### Trust model

The `.opencode/` directory is **executed in the same trust band as the rest of the repo**: anyone with push access can change the Coder's agent/skill/command roster for everyone who opens the Coder on this repo. This is consistent with `.bpm_opencode.config` and `.bpm_sandbox.config`, which already let the repo set the model, system prompt, and sandbox image.

What `.opencode/` **cannot** do (security boundaries that stay in BPM):

- It cannot grant access to MCP tools the user does not already have. The MCP tool allowlist (per-`McpInfo` × `targetGroups`/`targetUsers`) is enforced server-side, regardless of what an agent definition references.
- It cannot bypass the sandbox (cap_drop, network policy, mount allowlist). The agent runs inside the same Docker constraints as everything else in the chat.
- It cannot change the BPM-enforced opencode invariants (native `bash`/`read`/`write` stay disabled in favor of the BPM plugin tools).

So: a repo can DEFINE a "do-everything" agent in `.opencode/agents/superuser/superuser.md`, but if the user opening the Coder doesn't have access to the underlying tools, the agent simply can't call them.

### When to put it in `.opencode/` vs `RepoDTO.opencodeConfig`

| Use case | Where it goes |
|---|---|
| Subagent persona that travels with the repo | `.opencode/agents/<name>/<name>.md` |
| One-off `agent.<name>.prompt` tweak per-environment | `RepoDTO.opencodeConfig` (form override) |
| Deploy-target slash command (e.g. `/deploy-staging`) tied to repo CI | `.opencode/commands/deploy-staging/deploy-staging.md` |
| Repo-specific SQL/style/glossary the agent must follow | `.opencode/skills/<name>/SKILL.md` + reference it from `instructions:` in `.bpm_opencode.config` |
| Different model defaults for prod vs dev | `RepoDTO.opencodeConfig.model` (env-specific, not repo-versioned) |

### Verifying it loaded

In TUI standalone you would type `/agents` `/skills` `/commands`, but **the BPM Coder runs opencode in ACP mode where TUI slash commands do not apply**. Verify via BPM logs at chat startup:

```
INFO  ACP[<chatId>] repo-versioned .opencode dir detectado: /path/to/repo/.opencode
INFO  wired opencode agents: <chatDir>/opencode-config/agents/<name> → /repo/.opencode/agents/<name>
INFO  wired opencode skills: <chatDir>/opencode-config/skills/<name> → /repo/.opencode/skills/<name>
```

If you committed something under `.opencode/` and don't see the corresponding `wired opencode <kind>:` line:

1. Check the layout — opencode 1.14+ uses **plural** subdir names (`agents/`, not `agent/`).
2. Each resource is a NAMED SUBDIR with the file inside (`agents/reviewer/reviewer.md`, not `agents/reviewer.md`).
3. **Commands** (`commands/<name>/<name>.md`) load AND are invokable in BPM Coder/Analyst (phase 1: `$ARGUMENTS` and `$1..$9` are expanded client-side; `!\`bash\`` and `@file` are phase 2 — see `references/opencode-resources.md`). Some other kinds load but are not usable: `themes` (TUI-only), `tools` (BPM enforces native tools off).

For a comprehensive guide on what each kind does, frontmatter fields, and which ones actually work in the BPM ACP context, see `references/opencode-resources.md`.

---

## Full example

A repo backed by Gitea, defaulting to GPT-5.1 codex, with a custom system prompt and a Docker sandbox carrying Playwright:

```yaml
url: "git@gitea.example.com:platform/sales-ui.git"
branch: "main"
key: "repoKeys/jdoe.key"      # set by the upload widget; do not edit by hand
username: "Coder Bot"
email: "coder@example.com"
path: ""
processes: |
  SALES/PAGE_DASHBOARD
  SALES/AGT_ASSISTANT
description: "Sales front-end and assistant config"

model: "openai/gpt-5.1-codex-max"

opencodeConfig:
  agent:
    build:
      prompt: |
        Coder for the Sales front-end. Rules:
        - Before touching a .yml, read it with bpm_read and validate with
          python3 skills/bpm/scripts/validate.py.
        - To run E2E tests, use `bpm_bash npx playwright test`
          (the sandbox already has playwright installed).
        - Commits in English, message in imperative.
  instructions:
    - "AGENTS.md"

sandbox:
  mode: docker
  image: "mcr.microsoft.com/playwright:v1.48.0-jammy"
  service:
    environment:
      - "TZ=America/Asuncion"
    volumes:
      - "./test-results:/workspace/test-results"
```

A simpler host-mode example (no Docker, default model from BPM):

```yaml
url: "git@github.com:redflag/internal-tools.git"
branch: "main"
key: "repoKeys/jdoe.key"
username: "Coder Bot"
email: "coder@example.com"
```

---

## Tools available to the Coder

The Coder agent sees three layers of tools when it queries `tools/list` against the BPM MCP server:

**1. Plugin tools — always available, no config needed.** Provided by the BPM opencode plugin (`bundle.js`) embedded in every chat. These never appear in MCP `tools/list` because the plugin exposes them directly to the agent runtime, but the agent can use them at any time:

| Tool | Purpose |
|---|---|
| `bpm_bash` | Run shell commands in the sandbox (`/workspace`). |
| `bpm_read` / `bpm_write` / `bpm_edit` | File I/O against the workspace o el scratch dir ephemero. |
| `bpm_glob` / `bpm_grep` | File search. |
| `bpm_ask_user` | Ask the user mid-turn via Vaadin dialog. |

Las file ops aceptan paths bajo el workspace **y** bajo un scratch dir ephemero per-chat, fuera del repo. El path concreto se publica al sandbox como `BPM_SCRATCH_DIR` (y `TMPDIR`); los valores difieren por sandbox: en Coder mode `host` es `/tmp/bpm-scratch-<chatId>/` (FS del JVM, cleanup al cerrar el chat), en docker (Coder mode `docker` y Analyst) es `/tmp/scratch/` (tmpfs auto-inyectada). Pensado para drafts de scripts, fixtures, datos intermedios — todo lo que NO debe terminar en el repo. El agente debe referirse a la env var, no hardcodear el path.

**2. Server-side defaults — always available for `profile=coder`.** Hardcoded in `UnionOfProfilesScope.isCoderDefault` so the Coder works out of the box without an `McpInfo` record. Three families:

| Family | Tools | Notes |
|---|---|---|
| `bpm_coder_*` | `open_file`, `current_file`, `run_test`, `run`, `preview`, `git`, `list_repos`, `list_agent_memories`, `read_agent_memory`, `show_chat`, `list_coder_sessions`, `external_list_chats`, `external_read_chat`, `external_show_chat` | Affordances atadas al `BPMCoderView` (file panel, run, git) + introspección cross-repo, de sesiones/memoria locales y de chats en DBs externas. Requieren `ctx.chatId`. Ver "Cross-repo read access", "Sessions / memory introspection" y "Acceder a chats de una DB externa". |
| `bpm_chat_*` | `list_modes`, `switch_mode` | Discovery / cambio de mode opencode (build/plan/...). Comunes a Coder y Analyst. |
| `bpm_eb_*` | `bpm_eb_service_*`, `bpm_eb_document_*`, `bpm_eb_runtime_*`, `bpm_eb_resource_*`, `bpm_eb_report_*`, `bpm_eb_agent_*` | Event bus toolset estándar. Las que mutan declaran `annotations.destructiveHint: true` y disparan dialog de confirmación bajo el `confirmPolicy` efectivo (default `destructive`). |

`bpm_coder_*` y `bpm_chat_*` requieren `ctx.chatId` — solo funcionan desde un `BPMCoderView`. `bpm_eb_*` no tiene esa dependencia, pero por estar gateadas por confirm policy las acciones destructivas se materializan ante el user.

### Cross-repo read access (Coder mode `host`)

Cuando el Coder corre en mode `host`, el sandbox extiende su política de lectura para incluir **todos los demás repos del user**, además del workspace del chat:

- `bpm_read`, `bpm_grep` y `bpm_glob` aceptan paths absolutos (o `path:` arg) bajo cualquier repo registrado en BPM.
- Las operaciones de **escritura** (`bpm_write`, `bpm_edit`) siguen confinadas al repo del chat — los otros repos son read-only.
- `bpm_coder_list_repos` lista los repos visibles con su `hostPath`. Marca el repo del chat con `current: true`. Úsalo cuando el user pide "inspirate en cómo lo hicimos en el otro proyecto" — listás los repos, identificás el que aplica, leés con `bpm_read`/`bpm_grep` los archivos de interés.
- En mode `docker` el cross-repo no aplica (el container tiene un único bind mount al repo del chat).

### Sessions / memory introspection (para desarrollar Agents y Analysts)

Tres tools facilitan la depuración de Agents y Analysts existentes:

- **`bpm_coder_list_agent_memories({query?, agentId?, userId?, since?, limit?})`** — lista las sesiones de memoria de Agents (`type: Agent` con `memoryEnabled: true`) y de Coder/Analyst flusheadas. Devuelve metadata por sesión: `memoryId`, `kind` (`agent_legacy` o `coder_or_analyst`), `messageCount`, `lastModifiedDT/MS` cuando aplica. Filtros opcionales: `query` (substring case-insensitive contra el body, **incluye texto de mensajes**), agente, user, fecha. **Sin mensajes en la respuesta** (heavy) — usá `read_agent_memory` para eso.
- **`bpm_coder_read_agent_memory({memoryId})`** — **read-only histórico**. Trae el row entero de una sesión, incluyendo el array `messages` serializado por LangChain4j. Los `UserMessage` del transcript son lo que el user dijo en *esa otra* sesión: NO los re-ejecutes, NO recrees artefactos mencionados. Resuelve en orden: (1) `MEMORY_STORE_COLLECTION` para Agents legacy y Coder/Analyst sessions ya flusheadas; (2) si el id es `ses_*` y no está, busca `userId` en `CHAT_COLLECTION` y lee directo de la SQLite de opencode (cubre sesiones live / sin flush). La respuesta lleva `source: 'memory_store' | 'opencode_sqlite'` y `_note` con el disclaimer.
- **`bpm_coder_show_chat({sessionId})`** — abre un dialog Vaadin del Coder con el transcript renderizado (globos por mensaje, cards plegables para tool calls + sus resultados). Resuelve el `sessionId` con la misma lógica que `read_agent_memory`. Pensado para mostrarle al user una sesión histórica visualmente, sin parsear JSON crudo. Read-only: el dialog solo muestra, no edita.
- **`bpm_coder_list_coder_sessions({userId?, profile?, since?, limit?})`** — lista sesiones de chat opencode (Coder/Analyst). Devuelve metadata + costos / tokens / modelo. Cada entry trae `sessionId`; pasalo a `read_agent_memory` o `show_chat`.

#### Acceder a chats de una DB externa (prod / réplica)

Cuando estás afinando un agente en test/dev y necesitás analizar conversaciones reales de prod, podés apuntar el Coder a una DB externa (configurada en `Bases de datos` → `DataSourceDTO`) y leer ahí. La DB target tiene que tener el schema `document.document` (canonical de BPM). Pensado para escenarios "el agente respondió mal a un cliente, dame el chat para corregir el código".

- **`bpm_coder_external_list_chats({database, query?, agentId?, userId?, since?, limit?})`** — lista chats de la DB externa. Recorre las dos collections (`MEMORY_STORE` con transcripts + `CHAT_COLLECTION` con audit log de opencode). Cada entry indica `kind: 'memory_store' | 'audit_log'`. Mismos filtros que `list_agent_memories`, más `database` (nombre del DataSource).
- **`bpm_coder_external_read_chat({database, chatId})`** — lee un chat específico por id (busca en cualquiera de las dos collections). Mismo shape de envelope que `read_agent_memory` (read-only histórico). Sin fallback a SQLite — la SQLite del dumper vive en disco local, no es portable a otra DB.
- **`bpm_coder_external_show_chat({database, chatId})`** — abre el dialog del Coder con el chat renderizado (mismo formato del live: globos + ActivityStrip).

Recomendación operativa: configurar el DataSource de prod como **read-only desde el lado de la DB** (user con `SELECT` solamente) y/o marcar `preventDestructiveActions: true` en la entrada del DataSource — la lectura de chats no necesita escritura, así evitás cualquier deslizamiento accidental de tooling.

Use cases típicos:
- "El agente Y respondió mal a un cliente, mostrame las últimas conversaciones": `list_agent_memories(agentId="…")` → tomás los `memoryId` recientes → `read_agent_memory` para los problemáticos.
- "Quiero ver qué tools le quedan cortas al Analyst Z": `list_coder_sessions(profile="analyst")` → identificás sesiones, dumpeás `read_agent_memory` por cada `chatId`.

**3. Custom MCP tools — opt-in via `McpInfo`.** Any CodeDTO with `properties.tool.name` declared (`references/scripts-and-tools.md` §7) lives in the BPM tool catalog. To make it visible to the Coder (or to an external token), create an `McpInfo` artifact with the matching `profile` and add the script id to `toolList` (or use a glob). Esto **extiende** los defaults — no hay que volver a listar `bpm_eb_*`.

### McpInfo schema reference

`McpInfo` is a CodeDTO with `type: Mcp`. The body YAML (top-level fields, NOT under `properties`):

| Field | Type | Required | Notes |
|---|---|---|---|
| `id` | string | yes | Unique identifier (often `<PROJECT>/<NAME>`). Used for diagnostics; the lookup key is the CodeDTO id. |
| `name` | string | yes | Human-readable label. |
| `description` | string | no | Free text. |
| `profile` | string | recommended | `coder` / `external` / `analyst` / null. **null/absent → applies to ALL profiles** (every JWT can pick it up). Tokens with `profile: X` see the union of `toolList`/`resources`/`prompts` from every McpInfo whose `profile` is X or null. |
| `targetUsers` | **list of strings** | no | Empty list (or absent) = public. If non-empty, the JWT user must be in the list. |
| `targetGroups` | **list of strings** | no | Same semantics as `targetUsers` but matches BPM groups. Either list grants access (union, not intersection). **Always a YAML list — `targetGroups: "ADMIN"` is a bug, write `targetGroups: ["ADMIN"]`**. |
| `toolList` | **list of strings** | recommended | Tool names (or globs) that the JWT can invoke. **The field is `toolList` — NOT `tools`. `tools:` is silently ignored, leaving the list empty and producing a 0-tools result for the user**. Globs use shell syntax: `*` (all), `bpm_eb_*` (prefix), `*/RUN_*` (cross-project). |
| `confirmPolicy` | string | no | `destructive` (default) / `all` / `none`. Decides which tools require an in-UI confirmation dialog before invocation. See **`confirmPolicy`** below. |
| `resources` | list of strings | no | URIs the JWT can `resources/read`. Match is exact (no globs). Schemes typically `bpm://query/...`, `bpm://code/...`, `bpm://doc/...`, `bpm://resource/...`. |
| `prompts` | map of string→string | no | Named MCP prompts. Key = prompt name; value = template (Mustache `{{var}}`). |

```yaml
# Example: BPM_SAMPLES/MCP_ADMIN — full ADMIN tool surface for external tokens
id: "BPM_SAMPLES/MCP_ADMIN"
name: "MCP Admin"
profile: external                # <— gate by JWT profile
targetGroups:                    # <— LIST, even with one item
  - ADMIN
toolList:                        # <— `toolList`, NOT `tools`
  - "bpm_eb_service_now"
  - "bpm_eb_service_today"
  - "*_admin"                    # globs supported
resources: []
prompts: {}
```

```yaml
# Example: scoped to Coder, public (no targetGroups)
id: "MYPROJ/MCP_CODER"
name: "MyProj — Coder tools"
profile: coder
toolList:
  - "MYPROJ/SEARCH_ORDERS_TOOL"
  - "MYPROJ/RUN_QUERY"
  - "*_admin"
```

**Common authoring mistakes** (the validator at `scripts/validators/mcp.py` flags these):
- `tools:` instead of `toolList:` → leaves `toolList` empty, JWT sees 0 tools.
- `targetGroups: ADMIN` (string) instead of `targetGroups: [ADMIN]` (list) → fails to deserialize, treated as empty.
- `targetUsers: nmaurel` instead of `targetUsers: [nmaurel]` → same.
- `profile: ANALYST` (uppercase) → does not match; profiles are lowercase strings.
- `toolList:` containing plugin tool names (`bpm_bash`, `bpm_read`, etc.) → no-op; plugin tools are global, not gated by McpInfo.

Multiple `McpInfo` artifacts with `profile: coder` are accumulated (union of `toolList` from all that match the user). `targetUsers`/`targetGroups` on the `McpInfo` itself gate who sees that bundle; `targetUsers`/`targetGroups` on the individual tool's CodeDTO gate who can actually invoke it (enforced by `BpmMcpToolRegistry.enforceToolAccess`).

**Tool count seen in `tools/list`.** When you open a Coder, the BPM logs:

```
INFO  d.r.b.app.mcp.BpmMcpToolRegistry - MCP tools/list: returning N tools for profile=[coder] user=[X]
```

`N = ~10 (bpm_coder_*) + 2 (bpm_chat_*) + ~60 (bpm_eb_*) + (custom tools matched by McpInfos for this user)`. Plugin tools are not counted here — they live entirely client-side.

### `confirmPolicy`

Decides which tools require an in-UI confirmation dialog before they execute. The dialog is the same one used by the ACP `session/request_permission` flow (Permitir / Siempre permitir / Denegar, 60s timeout — reject by default).

| Value | Behaviour |
|---|---|
| `destructive` (default) | Confirm only tools whose spec MCP declares `annotations.destructiveHint: true`. Read-only tools pass without dialog. The right choice for production Coder/Analyst sessions. |
| `all` | Confirm **every** tool call regardless of annotations. Maximum auditability — useful for highly regulated environments or external tokens. |
| `none` | Skip confirmation entirely. Only for dev-local sessions where the agent runs unsupervised and you accept the blast radius. |

When several `McpInfo` artifacts apply to the same JWT, the **strictest** policy wins (`all > destructive > none`). The matching `AnalystInfo` uses the field with the same name and semantics.

The classification of "destructive vs read-only" lives **in the tool itself** — see `references/scripts-and-tools.md` §7 (`annotations.destructiveHint`). EB tools (`bpm_eb_runtime_*`, `bpm_eb_document_*`, `bpm_eb_service_*`, `bpm_coder_*`, etc.) come pre-classified out of the box: starts/updates/deletes/sends are destructive, reads/lists/lookups are read-only.

**Common case**: granting `bpm_eb_*` to a Coder in production.

```yaml
profile: coder
toolList:
  - "bpm_eb_*"           # full event bus surface
confirmPolicy: destructive   # default; explicit for documentation
```

Result: the Coder can invoke any `bpm_eb_*` tool, but mutating ones (`start_process_*`, `delete_*`, `update_*`, `set_variable`, `send_mail`, `notify_*`, `execute`, …) trigger the dialog. Read-only ones (`get_*`, `list_*`, `read_*`, `now`, `today`, `env`, …) run silently.

---

## Common gotchas

- **API keys do NOT go on `RepoDTO`.** Set `GEMINIAI_API_KEY`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY` in BPM parameters once; every repo picks them up. There is no per-repo provider key — opencode loads providers process-wide.
- **`prompt` vs `instructions` vs `systemPrompt`.** Only `agent.<name>.prompt` (string) and top-level `instructions` (array of file paths) are honored. Anything else is silently ignored by opencode. See the table above.
- **`instructions` is paths, not text.** Put the prompt content inside a markdown file in the repo and list its path; do not paste prose into the array.
- **SSH key must be passphrase-less.** The Coder cannot answer a passphrase prompt, and `git push` will hang.
- **HTTPS URLs are not supported.** Use the SSH form (`git@host:org/repo.git`); auth is exclusively via the uploaded private key.
- **Don't pick `gemini-2.5-flash` as default.** Known regression with toolsets ≥5 tools — agent silently returns 0 output tokens and the chat looks frozen. Use `gemini-flash-latest`, `gemini-flash-lite-latest`, or any OpenAI/Anthropic model.
- **Repo-versioned config is the base, not the override.** `.bpm_opencode.config` in the repo is merged **first**; `RepoDTO.opencodeConfig` wins on conflicts. If a setting "isn't sticking" from the repo file, check whether the form is overriding it.
- **`sandbox.mode = host` runs as user `bpm-coder` on the BPM box.** For anything that needs system packages (Selenium, Playwright, Node toolchains, language SDKs), switch to `mode: docker` with an appropriate image — see `references/sandbox.md`.
- **Git commits use `username` / `email` from `RepoDTO`**, not from the BPM user who started the chat. Set them to a recognizable bot identity so commits are attributable.
- **`webfetch` / `websearch` are ON by default for the Coder** — opposite of the Analyst. Add `permission.webfetch: deny` and `permission.websearch: deny` under `opencodeConfig` if the repo is sensitive. See **Web tools** above.

---

## Validation summary

`validators/repo.py` checks:

- `url` matches `GIT_SSH_URL_RE` (SSH form `git@…:…`); HTTPS rejected.
- `key`, `username`, `email` non-empty (`@SchemaRequired` in code).
- `branch`, `path`, `processes`, `description` are strings when present.
- `model`, if set, matches `MODEL_FQ_RE` (`providerID/modelID`).
- `model` warning if value is `google/gemini-2.5-flash` (known regression).
- `sandbox` is a valid object — delegates to `validators/sandbox.py`.
- `opencodeConfig` is a valid object; warns if it contains `agent.<name>.instructions` or `agent.<name>.systemPrompt` (silently ignored by opencode).
- Warns if the YAML contains literal API keys instead of `@VAR` references.
