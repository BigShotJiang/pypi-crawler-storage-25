# Scripts and Tools

Scripts are the workhorse artifact of BPM. Almost every piece of dynamic behaviour — query actions, form validations, footer summaries, agent tools, post-processors, scheduled jobs and HTTP endpoints — is a `type: Script` artifact with a code body and a `.config` sidecar.

This reference covers what you can put in `properties`, the closed sets of values BPM accepts, the `bpm.context` API your script sees at runtime, and the gotchas around Jython vs. CPython. For closely related material see `references/queries.md` (how queries invoke action scripts), `references/forms.md` (the `inputSchema` form spec), `references/agents-and-rag.md` (agent tools) and `references/templates.md` (post-processors that render `row.template`).

## 1. Script roles by use

A single artifact (`type: Script` in CodeDTO terms) plays a different role depending on **where it is referenced**. The script body is just Python/JS/Shell — what changes is the `properties` block in the `.config` and what BPM injects into `bpm.context`.

| Role | Referenced from | Key `properties` keys | Reads from `bpm.context` |
|---|---|---|---|
| **Action script** | `query.scripts: [PROJ/SCRIPT]` | `caption, icon, type, selectionScope, displayHints, reusable, asynchronous, groupName, shortcuts, inputSchema` | `selection`, merged row props, `inputData` / `input` |
| **Selection script** | `query.selectionScript` (inline body) | n/a (inline) | `selection` |
| **Form feedback / validation** | `form.properties.<field>.hints.feedback[*]` | n/a (inline) | `input` (= form fields, mutable) |
| **Tool script (agent)** | `agent.tools: [PROJ/SCRIPT]` | `tool.{name, description, args_schema, uxFeedback*}` | `args` (**not** `bpm.context.get`!), `ctx`. Returns via `bpm.reply(...)` (**not** `print`!). |
| **Post-processor** | `query.postProcessors: [PROJ/SCRIPT]` | (typically `lang: Markdown/Velocity/YAML/JSON`) | `row` (mutable) — see `references/templates.md` |
| **Endpoint** | direct HTTP / cron | `properties.public, properties.cron`, etc. | request payload via `bpm.context.input` |
| **Init / startup** | wired via menu/service config | varies | varies |
| **Script Task (BPMN)** | BPMN process activity | n/a | `bpm.execution` (process scope) |

The same code can be reused across roles — what differs is which keys you populate in `properties` and which slots of `bpm.context` are filled by the runtime.

## 2. Anatomy: script + `.config`

Every script artifact is **two files**: the code body and a sibling `.config` (YAML).

`my_action.py`:
```python
#!python3
import redflagbpm
bpm = redflagbpm.BPMService()

bpm.reply({"type": "MESSAGE", "statusMessage": "Hello world"})
```

`my_action.py.config`:
```yaml
project: "MYPROJ"
id: "MYPROJ/MY_ACTION"
type: "Script"
lang: "Shell"             # because we used a #! shebang for CPython3
description: "My example action"
properties:
  caption: "Greet"
  icon: "fa fa-hand-wave"
  type: "call"
  selectionScope: 1
  displayHints: ["main"]
```

El `.config` tiene un schema fijo (`project`, `id`, `lang`, `description`, `type`, `cron`, `properties`, `env`, `form`); todo lo específico del rol del artifact vive bajo `properties` (mapa free-form cuyo shape depende del kind de artifact).

## 3. Action script `properties` (full reference)

This is the most common case: a script that appears as a button in a query toolbar / row menu.

| Key | Type | Default | Notes |
|---|---|---|---|
| `caption` | string | id | Button label shown to the user |
| `icon` | string | – | Icon class (e.g. `fa fa-check`) |
| `type` | enum | `call` | One of the **closed set** below |
| `selectionScope` | int | `1` | One of the **closed set** below |
| `displayHints` | list&lt;string&gt; | `[]` | Each entry from the **closed set** below |
| `reusable` | bool | `false` | Action survives across query refreshes |
| `asynchronous` | bool | `false` | Run in background; UI does not block |
| `groupName` | string | – | Groups multiple actions in the toolbar dropdown |
| `shortcuts` | map&lt;string,string&gt; | – | Named keyboard shortcuts |
| `pathScope` | string | `$..*` | JSONPath restricting where the action appears |
| `inputSchema` | object | – | JSON Schema for a form shown before run (see `references/forms.md`) |
| `availableFeedbacks` | list&lt;string&gt; | `[]` | Feedback ids enabled for this action |

### 3.1 `type` — closed set

```
create | update | delete | query | display | call | open
```

| Value | Meaning |
|---|---|
| `create` | Action creates a new row; UI may append a row after success |
| `update` | Action updates the selected row(s) |
| `delete` | Action deletes the selected row(s) |
| `query` | Action runs and triggers a query refresh |
| `display` | Read-only action; no mutation expected |
| `call` | **Default.** Plain RPC: run the script, show its reply |
| `open` | Action opens another service/URL rather than executing logic |

Validation: `properties.type` MUST be one of the seven values above. Unknown values are a configuration error.

> Cuidado: en runtime, un script puede devolver un response con un campo `type` UPPERCASE (`OPEN_NEW_UPDATE`, `TERMINAL`, `MESSAGE`, etc. — ver § 6 "bpm.reply"). Eso es **otro contexto**: lo que devuelve el código del script al ejecutarse, no la metadata del botón. Si en el `.config` ves `properties.type: "OPEN_NEW_UPDATE"` es un bug — `properties.type` siempre va lowercase de la lista de arriba.

### 3.2 `displayHints` — closed set

`displayHints` is a **list** (multiple hints can apply). Each entry must be one of:

| Value | Effect |
|---|---|
| `default` | No special placement |
| `main` | Render as the prominent / primary button in the toolbar |
| `confirm` | Ask the user to confirm before executing |
| `small` | Open the action's modal at small width |
| `medium` | Open at medium width |
| `large` | Open at large width |
| `x-large` | Open at extra-large width |
| `refresh-on-close` | Refresh the underlying query after the modal closes |

Use `["main", "confirm"]` for a primary destructive action. Use `["large", "refresh-on-close"]` for an action whose `inputSchema` form should open large and trigger a refresh after submit.

### 3.3 `selectionScope` — closed set (default `1`)

Controla cuándo el botón está habilitado en función de cuántas filas hay seleccionadas. Valores:

| Value | Habilitado cuando | Notas |
|---|---|---|
| `0` | Hay 0 filas seleccionadas (toolbar-level, sin selección) | Para acciones de creación o que no operan sobre rows. |
| `1` (default) | Hay **exactamente 1** fila seleccionada | Las columnas de esa row se mergean en `bpm.context`. |
| `-1` | Cualquier cantidad (incluido 0) — siempre habilitado | "any" |
| `-2` | Hay **1 o más** filas (≥ 1) | "many" — incluye selección de una sola row. |
| `-3` | Hay **2 o más** filas (estrictamente > 1) | Útil para acciones que solo tienen sentido sobre múltiples rows (ej. "fusionar"). NO acepta 1. |
| `-4` | Siempre habilitado, opera sobre el query filter actual | El script recibe el filter, no rows individuales. |

> Cualquier entero positivo `N` (ej. `2`, `3`) significa "exactamente N filas seleccionadas". Poco usado en la práctica — los casos comunes son `0`, `1`, `-1`, `-2`, `-3`, `-4`.

**Behaviour difference for `selectionScope: 1`:** the selected row's columns are flattened onto `bpm.context` so you can write `bpm.context.id_doc` instead of `bpm.context.selection[0].id_doc`. For any other value the selection lives only under `bpm.context.selection` (always an array).

Validation: `properties.selectionScope` MUST be one of `0, 1, -1, -2, -3, -4`. Any other integer is a configuration error.

## 4. `lang` — supported languages

```
JavaScript | Python | Velocity | JSON | YAML | JUEL | Vertx | Shell | Prompt | Markdown | Binary
```

Most script artifacts pick from this short list:

| `lang` | Engine | When to use |
|---|---|---|
| `Python` | **Jython** (Java-on-JVM Python 2.7-ish) | Default for action / tool / feedback scripts that don't need PyPI packages |
| `Shell` | Shebang dispatch (`#!/usr/bin/env python3`, `#!python3`, `#!/bin/bash`, …) | When you need real CPython3, native pip packages, or any other interpreter |
| `JavaScript` | Nashorn / GraalJS depending on build | Short data shaping, quick condition logic |
| `Velocity` | Apache Velocity | Templating in post-processors and reports |
| `Markdown` / `JSON` / `YAML` | n/a (data) | Post-processors that emit `row.template` (see `references/templates.md`) |
| `Prompt` | Agent script engine | Inline LLM call con agente seleccionado por shebang |
| `Binary` | – | Static asset payloads |

**Critical gotcha:** `lang: "Python"` is **Jython**, not CPython3. There is no `requests`, `pandas`, `numpy`, `openai`, etc. If you need any of those, set `lang: "Shell"` and write a shebang as the first line:

```python
#!python3
import requests, pandas as pd
import redflagbpm
bpm = redflagbpm.BPMService()
# ...
```

The shebang detection runs only when `lang: "Shell"`. With `lang: "Python"`, the file is fed straight to Jython and a `#!python3` line at the top is silently ignored.

### 4.1 Virtual environments (venvs) and shebangs

> Quick orientation for script writers: `references/sdk-python.md` § "Picking which venv runs the script" shows the shebang patterns side by side. The full management story (registry, deploy action, recreate-from-scratch) follows below.

`lang: "Shell"` shells out to whatever interpreter the shebang names. To run scripts inside a controlled CPython environment with a specific set of `pip`-installed libraries, BPM lets administrators register **venvs** from the menu **Configuración → VENVs** (or its localized equivalent). Each venv has:

- a **name** (e.g. `DEFAULT`, `data-science`, `playwright`),
- a **path** (typically `/app/files/BpmApp/venvs/<name>` in the production layout, but can be any absolute path),
- a **`requirements.txt`** body that defines its installed packages.

Once registered, the admin runs the **Desplegar / Deploy** action on the row, which executes `python -m venv <path>` followed by `pip install -r requirements.txt` (with optional `--upgrade` and "recreate from scratch" flags). The result is reported back as a notification with a downloadable installation log.

**Two shebang forms**:

| Shebang | Meaning |
|---|---|
| `#!python3` | Run with the **default venv** — the one the admin marked as `DEFAULT` (path published as the JVM property `DEFAULT_VENV`). Use this when the script doesn't have specific environment requirements. |
| `#!/app/files/BpmApp/venvs/<name>/bin/python3` | Run inside a specific named venv. Use this when the script needs particular libraries (`pandas`, `playwright`, `openai`, …) that live in that venv. |

```python
#!/app/files/BpmApp/venvs/data-science/bin/python3
import pandas as pd
import redflagbpm
bpm = redflagbpm.BPMService()
# ... uses pandas from the data-science venv
```

`redflagbpm` itself is installed automatically in every venv as part of the deploy. You can keep the regular `import redflagbpm; bpm = redflagbpm.BPMService()` boilerplate regardless of which venv you target.

**Operational notes**:

- Always set `lang: "Shell"` for scripts that need CPython3 — both shebang forms only work under `Shell` dispatch.
- Don't hardcode an absolute venv path that doesn't exist in the deployment target. If the same script must run on multiple environments, prefer `#!python3` (the default venv) and let each environment's admin define what `DEFAULT` resolves to.
- Adding a new library to a venv requires editing its `requirements.txt` from the menu and re-running **Desplegar**. The validators in this skill cannot check that a script's `import` statements are satisfied by the chosen venv — that is enforced at runtime.
- Custom venv paths outside `/app/files/BpmApp/venvs/` are valid as long as the absolute path exists and contains `bin/python3` after deploy.

### 4.2 Shell directive comments

When `lang: "Shell"`, the engine reads a small set of comment directives from the **first 10 lines** of the script. They tune how long the engine waits and where the script runs.

| Directive | Default | Purpose |
|---|---|---|
| `#!<interpreter>` | `/usr/bin/bash` | Shebang. Only the first one wins. `#!python3` resolves to the `DEFAULT` venv. |
| `# CWD = <path>` | system temp dir | Working directory. Relative paths resolve from the script's parent directory; the directory is created if it doesn't exist. |
| `# TIMEOUT = <ms>` | none (wait until the process exits) | Hard cap on how long the engine waits for the script. After this elapses the engine returns control to the caller **even if the process is still running**. |
| `# WAIT_FOR_RESPONSE = <ms>` | `100` | After the engine stops waiting (process exit or `TIMEOUT`), how long it waits for a `bpm.reply()` to arrive on the bus before giving up. |

Whitespace around `=` is tolerated; the keyword is matched case-insensitively. Scanning stops at the first 10 lines, so put directives at the top.

```bash
#!python3
# CWD = workdir
# TIMEOUT = 500
# WAIT_FOR_RESPONSE = 200
import redflagbpm
bpm = redflagbpm.BPMService()
# ...
```

### 4.3 Long-running scripts: detach after responding

Pattern for actions, services, or endpoints that kick off heavy work (third-party sync, multi-minute report build, batch import) without making the user wait. The shape depends on which response protocol the script's caller uses.

#### A. Endpoint and `run:` Service scripts — `print` + `_responseHeaders` + fork + exit

Endpoints (§ `references/endpoints.md` § 5) and Services whose `requestUrl` is `run:PROJECT/SCRIPT` build the synchronous response from the script's **stdout** plus the `_responseHeaders` it mutates. The script does **not** use `bpm.reply()` — it just writes the response, forks the heavy work, and exits the parent. The engine sees the parent exit and returns the buffered response to the caller.

```python
#!/usr/bin/env python3
import os, sys, json
import redflagbpm
bpm = redflagbpm.BPMService()

# 1. Build the synchronous response in the parent
h = bpm.context.json._responseHeaders
h["status"] = "200"
h["Content-Type"] = "application/json"
print(json.dumps({"state": "started"}))
sys.stdout.flush()

# 2. Detach. Parent exits immediately; child runs the heavy work.
if os.fork() == 0:
    os.setsid()
    os.close(0); os.close(1); os.close(2)        # don't share stdio with the parent
    do_long_work()
```

No `# TIMEOUT` directive is needed: the engine waits for the **parent** to exit, which happens immediately after the fork.

If the heavy work is a different program, spawn it with `subprocess.Popen` and exit the parent:

```python
import subprocess, sys
subprocess.Popen(
    ["python3", "/path/to/worker.py", arg1],
    start_new_session=True,
    stdin=subprocess.DEVNULL,
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL,
)
sys.exit(0)
```

#### B. Action scripts — `bpm.reply()` early + `# TIMEOUT`

When the caller is an Action (button on a query, form submit, selection), the response goes back through `bpm.reply()` (see § 6). To detach in this role, send the reply early and tell the engine not to wait for the process:

1. `bpm.reply(...)` with the synchronous payload.
2. `# TIMEOUT = <small_ms>` so the engine returns to the caller after that many milliseconds even if the process is still alive.
3. Fork and keep working.

```python
#!/usr/bin/env python3
# TIMEOUT = 300
import os, redflagbpm
bpm = redflagbpm.BPMService()

bpm.reply({"type": "MESSAGE", "statusMessage": "Started — you can close this dialog."})

if os.fork() == 0:
    os.setsid()
    do_long_work()
```

Without `# TIMEOUT` the engine waits for the process to actually exit, defeating the purpose. `# WAIT_FOR_RESPONSE` matters only when the reply is sent *after* `TIMEOUT` fires; for early-reply detach the default `100` ms is fine.

#### Caveats — apply to both A and B

- **Capture identity before forking.** There is no `bpm.user` property in the SDK. The way you read the caller depends on the role:
  - HTTP endpoint (called from outside via `/api/run/...`): `bpm.context.json._requestHeaders["x-user"]`.
  - Service / Query / Page launched from the UI: `bpm.context.userId` (the BPM launcher views auto-inject it).
  - Service launched via token URL or programmatically via `bpm.execute(...)`: `userId` is only present if the caller passed it; guard with `bpm.context.get("userId")` (returns `None` if missing). Do **not** use `getattr(bpm.context, "userId", None)` — the Context proxy raises `NameError` for missing keys, so `getattr`'s default never fires.

  Read into a local variable in the parent — `bpm.context` is gone in the child. Note that when a Service invokes an endpoint-typed script via `run:`, `_requestHeaders["x-user"]` is **not** auto-populated; use `bpm.context.userId` instead.
- **Notifications need an explicit recipient.** If the detached child should ping someone, you must already have their userId in a local. Then `bpm.service.notifyUser(userId, ...)` from inside the child.
- **The `bpm.context` JSON file is deleted when the engine returns.** Anything you need from it must be in local variables before fork.
- **Auth context is not inherited.** Whatever credentials the BPM session carried do not survive into the child.
- **Stdout / stderr written from the child are lost** (after `os.close(1)/(2)`) or, if not closed, may interfere with the parent's already-flushed response. Always close `0/1/2` in the child or use `subprocess.Popen(..., stdout=DEVNULL, ...)`.
- **On platforms without `os.fork()`** (Windows, some container runtimes), use the `subprocess.Popen(..., start_new_session=True)` form.

#### When NOT to use this pattern

- **Recurring or scheduled jobs** — set `cron:` in the artifact `.config` instead.
- **Jobs that must retry on failure or escalate to a human** — model them as a BPMN process; you get retry, observability, and user-task escalation for free.
- **Jobs where the caller needs streaming progress** — the caller is gone after the response. Have the UI poll a status endpoint or a Query, or model it as a BPMN process.

## 5. The `bpm.context` API

What's available depends on the role; here is the union.

### 5.1 In every role

```python
import redflagbpm
bpm = redflagbpm.BPMService()

bpm.reply(payload)             # return result to the caller (action, endpoint, selection)
bpm.fail("error message")      # signal failure
bpm.text(msg)                  # convenience: short-circuit reply with plain text

bpm.service.sendMail(msg)      # email
bpm.service.notifyUser(...)    # in-app notification
bpm.service.execute(scriptId, context)   # call another script (by id)
bpm.service.env()              # env vars

bpm.documentService.create / readById / readList / updateById / deleteById
bpm.runtimeService.startProcessInstanceByKey / setVariable / getVariable

bpm.logger.info("category", "message")
```

> No `bpm.user`: get the caller from `bpm.context.userId` (UI launchers) or `bpm.context.json._requestHeaders["x-user"]` (HTTP endpoints) — see `references/sdk-python.md`.
> No `bpm.execute(sql, ...)`: for SQL use `redflagbpm.PgUtils.get_connection(bpm, "datasource")` (Postgres) or `redflagbpm.MSSQLUtils.get_connection(bpm, "datasource")` (SQL Server). For Collections use `bpm.documentService.readList(...)`.

### 5.2 Action scripts

| Field | When it's set | Notes |
|---|---|---|
| `bpm.context.selection` | Always (may be empty) | Array of selected rows |
| `bpm.context.<colName>` | When `selectionScope == 1` | Merged from the single selected row for convenience |
| `bpm.context.input` / `bpm.context.inputData` | When the action declares `inputSchema` | The submitted form values (mutable) |

### 5.3 Selection scripts (`query.selectionScript`)

| Field | Notes |
|---|---|
| `bpm.context.selection` | Currently selected rows |
| `bpm.reply(html_or_text)` | Renders into the query **footer** (HTML allowed) |

### 5.4 Form feedback / validation scripts

| Field | Notes |
|---|---|
| `bpm.context.input[fieldName]` | Read or **assign** to mutate form values live |
| `raise '[[[message]]]'` | The text inside `[[[ ... ]]]` is shown to the user (works for both validation errors and feedback messages) |

### 5.5 Tool scripts (agents and MCP)

| Field | Notes |
|---|---|
| `bpm.context.args.<param>` | Arguments the LLM filled in, as per `tool.args_schema` |
| `bpm.context.ctx.toolId` / `toolName` | Execution context (the LLM-side call id and tool name). |
| `bpm.context.ctx.userId` / `userName` | The BPM user behind the JWT (populated for Coder/Analyst tokens; `userName` is empty for external/OAuth tokens). |
| `bpm.context.ctx.profile` | `coder`, `analyst`, or `external` (the JWT profile). |
| `bpm.context.ctx.chatId` / `analystId` / `repo` | Chat-scoped extras (Analyst → `analystId`, Coder → `repo`). Absent for external/OAuth tokens. |
| `bpm.context.ctx.channel` / `subchannel` | `BPM` (Coder/Analyst), `MCP`/`EXTERNAL` (external/OAuth), `WHATSAPP`, `TELEGRAM`. Useful for branching DEV-only fake-id mappings. |
| `bpm.context.ctx.memoryId` | Agent execution memory key (legacy Agent tools only). |
| `return value` | Return value is coerced to **String** and sent back to the LLM. |

The full origin and semantics of every `ctx` field are documented in §7.1 below.

### 5.6 BPMN script tasks

| Field | Notes |
|---|---|
| `bpm.execution.getVariable(name)` / `setVariable(...)` / `getBusinessKey()` | Process-scoped variables (only inside BPMN runs) |

## 6. Action script response (`bpm.reply`) cheat-sheet

`bpm.reply(...)` accepts either a plain string (rendered as a `TERMINAL` message) or an object with a `type` discriminator. Quick reference; see the developer guide section 4347-4502 for the full spec.

| `type` | Effect |
|---|---|
| `MESSAGE` | Show `statusMessage` (set `statusMessageContentType: text/html` for HTML) |
| `TERMINAL` | Monospace, scrollable output |
| `ERROR` | Show error toast |
| `TERMINAL_UPDATE` | Refresh the calling query |
| `TERMINAL_DELETE` | Drop the selected rows from the grid + refresh |
| `TERMINAL_CREATE` | Append a created row + refresh |
| `OPEN` / `OPEN_UPDATE` | Open another service in the same window (optionally refresh after) |
| `OPEN_NEW` / `OPEN_NEW_UPDATE` | Open a URL in a new tab |
| `QUERY` | Run another query with `content` parameters |
| `REPORT` | Generate a report (`report.reportName`, `report.parameters`) |
| `ASSET` | Download a file from `asset` path; optional `assetContentType` |

## 7. Tool definitions (agent tools)

A script becomes a tool when its `.config` declares a `tool` block. The agent's chat client receives the tool's `name`, `description` and `args_schema` as a JSON Schema function-call spec; the LLM decides when to invoke it.

### Recipe — adding a tool to an existing agent

In order. Every step must succeed before moving on; do not mark the task done until step 6 passes.

1. **Write the script body** (`PROJECT/MY_TOOL.py`). Read args from `bpm.context.args.get(...)`, return via `bpm.reply(...)`. See § 7 for the exact contract — do **not** copy patterns from action / endpoint scripts (those use `bpm.context.get` and HTTP responses; tools don't).
2. **Create the `.config` sidecar** with `type: Script`, `lang: Shell`, and `properties.tool.{description, args_schema}`. `properties.tool.name` is optional (defaults to the sanitized id). Do **not** put the schema under `properties.inputSchema` — that's for action-script form prompts and the agent will silently not register the tool.
3. **Wire the tool into the agent**: edit `<agent>.yaml` and append the tool's qualified id (`PROJECT/MY_TOOL`) to the `tools:` list.
4. **Validate the config** before declaring done: `"$BPM_SKILL_DIR/scripts/validate.py" path/to/MY_TOOL.py.config`. If anything errors, fix and re-validate.
5. **Validate the script syntax** if it targets CPython: `"$BPM_SKILL_DIR/scripts/validate_python.sh" path/to/MY_TOOL.py`.
6. **Smoke-test by invoking the agent**: open the agent in chat (`Agent?__agent__=PROJECT/AGENT_ID`) and ask it to use the new tool with a real input. If you can't drive the chat from this session, leave a clear message to the user that step 6 is pending — don't claim "listo" without it.

### Translating from an action / endpoint script to a tool script

A common path: the user pastes an existing action or endpoint script and asks "do this as a tool". Do **not** copy the API surface verbatim — the runtime hooks are different.

| Action / endpoint script | Tool of an agent |
|---|---|
| `bpm.context.get("x")` (or `bpm.context.x`) | `bpm.context.args.get("x")` |
| `bpm.context.input.get("x")` | `bpm.context.args.get("x")` |
| `bpm.reply(payload)` | `bpm.reply(payload)` (same call; the receiver is the LLM via the event bus) |
| `bpm.fail("msg")` | `bpm.reply({"error": "msg"})` is preferred (LLM gets structured feedback it can act on); `bpm.fail` still works but surfaces as `"Error al ejecutar <tool>: ..."` literal text. |
| `bpm.context.setJsonValue("_responseHeaders", ...)` | No HTTP — drop it. The LLM consumes whatever you pass to `bpm.reply` as text. |
| `print(...)` (in endpoint, the stdout becomes the body) | `bpm.reply(payload)`. `print` writes to logs but the script's return value to the LLM is `null` — see pitfalls. |
| `bpm.context.userId` (HTTP endpoint sets `x-user`) | `bpm.context.ctx.userId` (MCP injects ctx) — see § 7.1 JWT context table. |
| Long synchronous work + `bpm.reply` at end | Same, but consider `properties.tool.uxFeedback*` so the chat doesn't go silent for >5s. |

If the original is an endpoint that pre-validates input and produces a downloadable file, the tool flavour usually returns a description of what was generated plus a reference (URL / id) — the LLM can't display a binary directly.



```yaml
properties:
  tool:
    name: "searchOrders"                 # OPTIONAL, name the LLM will use; defaults to the
                                          # sanitized CodeDTO id (`/` and other invalid chars
                                          # replaced by `_`). Must match
                                          # `^[A-Za-z][A-Za-z0-9_-]*$` when set explicitly.
    description: "Search orders by..."   # REQUIRED, helps the LLM decide when to call
    args_schema:                          # REQUIRED, JSON Schema (object)
      type: object
      properties:
        query:
          type: string
          title: "Consulta"               # ← human label shown in the permission dialog
          description: "Free-text query"  #   description goes to the LLM as field doc
        limit:
          type: integer
          title: "Cantidad máxima"
          description: "Max results"
      required: [query]
    annotations:                          # optional — MCP-standard hints about the tool's nature
      destructiveHint: false              #   true = mutates state (the registry will request user confirmation)
      readOnlyHint: true                  #   true = does not mutate anything
      idempotentHint: true                #   true = repeated calls have the same effect
      title: "Search Orders"              #   human-readable label (some MCP clients show this)
    uxFeedback: "Searching orders..."    # optional, sent immediately
    uxFeedbackWait: 15                   # optional, seconds before progress kicks in
    uxFeedback1: "Still searching..."    # optional, 1st progress message
    uxFeedback2: "Almost done..."        # optional, 2nd progress message
    uxFeedbackN: "One moment..."         # optional, fallback for further updates
```

Supported `args_schema` field types: `string` (with optional `enum`), `integer`, `number`, `boolean`. The schema is forwarded to the LLM provider via langchain4j, so anything outside basic JSON Schema may be silently dropped.

> **Always declare `title:` on each property.** When BPM asks the user for permission to invoke the tool (under the default `confirmPolicy: destructive` for destructive tools, or `confirmPolicy: all`), the dialog uses each property's `title` as the human-readable label. Without `title`, the dialog falls back to the raw key (e.g. `incluirCheques:` instead of `Incluir cheques:`). `description:` keeps going to the LLM as field documentation; it does **not** replace `title` for the UI.

### `annotations` — MCP-standard tool hints

Optional sub-block. The keys come from the MCP spec and travel verbatim to every consumer (Agents, Coder, Analyst, external clients), so a third-party MCP client that respects annotations can render the right UI without knowing anything about BPM.

| Key | Type | What it says |
|---|---|---|
| `destructiveHint` | bool | The tool may mutate state in a way that's hard to undo. **The BPM registry uses this hint** to decide whether to request user confirmation, gated by the `confirmPolicy` of the active `McpInfo` / `AnalystInfo` (see `references/coder.md`). |
| `readOnlyHint` | bool | The tool does not mutate anything. Mutually exclusive with `destructiveHint: true`. |
| `idempotentHint` | bool | Calling the tool repeatedly with the same args produces the same effect. |
| `title` | string | Human-readable label shown by some MCP clients in lieu of `name`. |

If you skip `annotations` entirely, the registry treats the tool as **non-destructive** (no confirmation under the default `confirmPolicy: destructive`). For tools that mutate data, send notifications, run arbitrary code, or commit/push — set `destructiveHint: true`.

The script reads arguments from **`bpm.context.args`** (not `bpm.context`!) and returns its result by calling **`bpm.reply(...)`** (not `print(...)`!). Whatever you pass to `bpm.reply` becomes the tool's return value seen by the LLM — string, dict, list — coerced to string at the LangChain4j boundary. Returning structured data (a dict / `json.dumps`-style payload) lets the LLM reason over fields; returning a one-shot string is fine for simple answers.

```python
#!python3
import redflagbpm
from redflagbpm.PgUtils import get_connection
bpm = redflagbpm.BPMService()

q = bpm.context.args.get("query", "")            # ← .args, not bpm.context.get
limit = bpm.context.args.get("limit", 10)

with get_connection(bpm, "sales") as conn, conn.cursor() as cur:
    cur.execute(
        "SELECT id, total FROM orders WHERE name ILIKE %s LIMIT %s",
        (f"%{q}%", limit),
    )
    rows = cur.fetchall()

bpm.reply({                                       # ← bpm.reply, not print
    "matches": [{"id": r[0], "total": float(r[1])} for r in rows],
    "count": len(rows),
})
```

For tools that touch slow backends (DB, HTTP, file processing) set `properties.tool.uxFeedback*` in the `.config` so the chat shows progress while the script runs:

```yaml
properties:
  tool:
    description: "..."
    args_schema: { ... }
    uxFeedback: "Buscando órdenes..."     # sent immediately when the tool is invoked
    uxFeedbackWait: 5                     # seconds before the next progress message
    uxFeedback1: "Sigo buscando..."       # 1st progress message
    uxFeedback2: "Casi listo..."          # 2nd progress message
    uxFeedbackN: "Un momento más..."      # fallback for further updates
```

Without these, a tool that takes >5s leaves the chat silent — users assume the agent froze. Anything that hits an external DB / API should set at least `uxFeedback` and `uxFeedbackWait`.

> **Why not `print(...)`?** The Shell engine awaits `bpm.reply(...)` on the event bus and returns its payload as the script's value. Anything written to `stdout` is logged but **discarded** as the script's result, unless you explicitly opt in with a `# RETURN STDOUT` directive (uncommon and not recommended for tools). A tool that exits without `bpm.reply` returns `null`/`"null"` to the LLM and can corrupt the chat history (see `references/pitfalls.md` § *Agents*: orphan AiMessage).
>
> **Don't be fooled by ad-hoc test runs.** If you invoke the script directly via `bpm_bash` or a CLI test runner, `print(...)` will *look* like it works because you see the JSON on stdout — and the agent's reflex is "the script returns data, the bug must be elsewhere". It's a **false positive**: the Agent path consumes the event-bus reply, not your terminal's stdout. Treat the validator's `tool-uses-print-not-reply` error as ground truth — the only valid return path for an Agent tool is `bpm.reply(...)`. To smoke-test for real, ask the agent in chat to invoke the tool and watch what comes back to the LLM.
>
> **Why not `bpm.context.get(...)`?** `bpm.context.get("x")` reads the **top-level context bag** — populated when the script runs as a Service / Action / HTTP endpoint. When the script runs as an agent tool, the LLM-supplied arguments live under **`bpm.context.args`**. Reading from `bpm.context` directly returns `None` and the tool body never sees the LLM's parameters.

Wire it into an agent (`references/agents-and-rag.md`):

```yaml
type: "Agent"
tools:
  - "MYPROJ/SEARCH_ORDERS_TOOL"
```

### 7.1 Tool exposure across the BPM MCP surface

Declaring `properties.tool` is the **single gate** that exposes a script as a tool — not only to Agents but to every BPM MCP profile. Once a script has a `properties.tool.name`, it appears in the BPM MCP catalog and any of these consumers can opt in by listing the script id:

| Consumer | Where you list the id | Visibility |
|---|---|---|
| **Agent** | `Agent.tools` (`references/agents-and-rag.md`) | LangChain4j tool wired to that specific agent. |
| **Coder** | `McpInfo` with `profile: coder`, `toolList: [<id> or glob]` | Tool appears in `tools/list` for the Coder JWT. |
| **Analyst** | `AnalystInfo.tools: [<id> or glob]` | Self-contained allowlist; no McpInfo needed. |
| **External** (Claude Desktop, opencode 3rd-party, OAuth, Bearer) | `McpInfo` with `profile: external`, `toolList: [<id> or glob]` | Tool appears in `tools/list` for the external JWT. |

**Type does not matter.** Any CodeDTO type works (Script, *.endpoint, etc.) as long as `properties.tool.name` is present and `bpm.execute()` can run it. The legacy `properties.coder.exposed: true` flag is no longer required and is ignored — only `properties.tool` controls exposure.

**The LLM-visible tool name** is the same across Agent and MCP paths:

1. If `properties.tool.name` is declared, that is what the LLM sees.
2. Otherwise, BPM derives it from the CodeDTO id by replacing every char outside `[A-Za-z0-9_-]` with `_` — typically just the project/id slash. Example: `IA_SERIN/BUSCA_VIAJE` → `IA_SERIN_BUSCA_VIAJE`.

In both cases the **routing key** stays the qualified CodeDTO id (`MYPROJ/SEARCH_ORDERS_TOOL`). The Agent looks up the script in `tools:` by id; the MCP registry resolves the LLM-supplied name back to the id at dispatch time and uses that for `scope.isToolAllowed`, access checks, and execution.

Practical consequences:
- You almost never need to set `properties.tool.name` — the sanitized id is a fine default.
- If you do set it, keep it `^[A-Za-z][A-Za-z0-9_-]*$` (validator enforces this). Punctuation other than `_`/`-` is rejected by every major provider.
- In `Agent.tools[]` and `McpInfo.toolList[]` always list the **CodeDTO id** (`MYPROJ/SEARCH_ORDERS_TOOL`). The id is the routing key — the LLM-visible name is generated from it.

**Per-tool security gates** (besides the allowlist match):
- `targetUsers` / `targetGroups` at the CodeDTO root → `BpmMcpToolRegistry.enforceToolAccess` rejects with `-32002` before invoking `bpm.run()` if the JWT user does not match.
- `properties.tool.annotations.destructiveHint: true` → under the default `confirmPolicy: destructive` of the active `McpInfo`/`AnalystInfo`, blocks the tool call until the chat UI accepts a confirmation dialog (60s timeout, only applies when the JWT carries a `chatId` bound to a UI). Override with `confirmPolicy: all` (confirm everything) or `none` (skip confirmation entirely) — see `references/coder.md`.

**JWT context available in scripts.** Tools invoked via MCP get the JWT context injected into `bpm.context.ctx` (in addition to the args). Scripts can rely on:

| Field | Source | Notes |
|---|---|---|
| `userId` | JWT `sub` | The BPM user. For external/OAuth tokens this is whatever user authenticated when the token was issued. |
| `userName` | resolved from BPM `IdentityService` (Coder/Analyst); not set for external tokens. |
| `profile` | JWT `profile` claim | `coder`, `analyst`, or `external`. |
| `chatId` | JWT extra ctx (Coder/Analyst only) | UUID of the chat in BPM. Absent for external/OAuth. |
| `analystId` | JWT extra ctx (Analyst only) | The `AnalystInfo.id`. |
| `repo` | JWT extra ctx (Coder only) | Git URL of the active repo. |
| `channel` | JWT extra ctx | `BPM` (Coder/Analyst), `MCP` (external/OAuth), `WHATSAPP`, `TELEGRAM`. |
| `subchannel` | JWT extra ctx | `BPM` (Coder/Analyst), `EXTERNAL` (external/OAuth), `WHATSAPP`, `TELEGRAM`. |
| `clientName` / `clientId` | OAuth tokens only | Useful for auditing 3rd-party clients. |

## 8. `inputSchema` — pre-action forms

Action scripts that need user input declare a JSON Schema in `properties.inputSchema`. BPM renders a form, and the submitted values arrive in `bpm.context.input`. Full form spec (hints, layout, validation feedback) is in `references/forms.md`.

```yaml
properties:
  caption: "Approve order"
  type: "update"
  selectionScope: 1
  displayHints: ["large", "confirm", "refresh-on-close"]
  inputSchema:
    type: object
    title: "Approval confirmation"
    hints:
      fieldOrder: ["reason", "amount"]
      callToAction: "Approve"
    properties:
      reason: { type: string, title: "Reason" }
      amount: { type: number, title: "Authorized amount" }
    required: [reason, amount]
```

In the script:
```python
reason = bpm.context.input.get("reason")
amount = bpm.context.input.get("amount", 0)
```

## 9. Common gotchas

- **Python ≠ CPython.** `lang: "Python"` is Jython. Use `lang: "Shell"` + shebang (`#!python3`) for CPython3 and pip packages.
- **Shebang only honored in `Shell`.** A `#!python3` line is decorative under `lang: "Python"`.
- **`bpm.context` is not Python `locals()`.** When `selectionScope == 1`, the selected row's columns appear on `bpm.context` directly, but only on `bpm.context` — `id_doc` is not a bare local variable.
- **`bpm.context.input` vs `bpm.context.args` vs `bpm.context.get`.** Forms write to `input`; agent tools receive `args`; the top-level context bag (Service/Action/HTTP launches) lives at `bpm.context.<key>` / `bpm.context.get(...)`. Don't mix them. **A tool that reads `bpm.context.get("foo")` instead of `bpm.context.args.get("foo")` always sees `None`** — the LLM-supplied parameters are not in the top-level bag.
- **Agent tools use `properties.tool.args_schema`, not `properties.inputSchema`.** `inputSchema` is for action scripts that show a pre-action form (§ 8). For an agent tool the schema MUST live under `properties.tool.args_schema`, otherwise the script lands in the catalog as a non-tool and `properties.tool.name` is missing — the agent simply does not see it.
- **Agent tools return via `bpm.reply(...)`, not `print(...)`.** The Shell engine awaits a `reply` on the event bus and treats that as the script's return value. `print(...)` writes to the log and is **dropped** as the return — the tool effectively returns `null`/`"null"` to the LLM. Worse, a tool that exits without `bpm.reply` can corrupt the chat memory: the agent loop tries to follow up with another `AiMessage`, which `MessageWindowChatMemory.validateMessageSequence` rejects as `Orphan AiMessage`. Always end the tool body with `bpm.reply(<payload>)` — pass a dict / list / string, never silently fall through.
- **Don't use `bpm.fail(...)` as a tool error path.** `bpm.fail` raises a `ScriptException` on the engine side, which surfaces as a Java exception captured by the AgentBuilder and turned into the literal string `"Error al ejecutar <tool>: <msg>"`. The LLM gets that as the result. For tool-side validation, prefer `bpm.reply({"error": "..."})` so the LLM sees structured feedback it can react to. Reserve `bpm.fail` for unexpected failures.
- **`asynchronous: true` actions can't `bpm.reply` interactively.** Their output is delivered out-of-band (notification) — use `bpm.service.notifyUser` for confirmations.
- **`raise '[[[message]]]'` is the user-feedback channel for forms.** A normal Python exception will surface as an internal error; the triple-bracket form is what BPM extracts and shows nicely.
- **`displayHints: "main"` is wrong.** It's a **list** — write `displayHints: ["main"]`.
- **Multiple `selectionScope = 1` rows is impossible** — BPM disables the action when more than one row is selected. Use `-2` if you want bulk processing.

## 10. Examples

### 10.1 Simple action: cancel order

`cancel_order.py`:
```python
#!python3
import redflagbpm
bpm = redflagbpm.BPMService()

order_id = bpm.context.id_doc      # selectionScope == 1, columns merged
bpm.documentService.updateById("orders", order_id, {"status": "CANCELLED"})
bpm.reply({"type": "TERMINAL_UPDATE"})    # refresh the query
```

`cancel_order.py.config`:
```yaml
project: "MYPROJ"
id: "MYPROJ/CANCEL_ORDER"
type: "Script"
lang: "Shell"
properties:
  caption: "Cancel"
  icon: "fa fa-ban"
  type: "update"
  selectionScope: 1
  displayHints: ["confirm"]
```

### 10.2 Selection script: footer summary

Inline inside the query (not a separate `.config`):
```yaml
selectionScript: |
  #!python3
  import redflagbpm
  bpm = redflagbpm.BPMService()
  sel = bpm.context.selection or []
  if sel:
      total = sum(r.get("amount", 0) for r in sel)
      bpm.reply(f"<strong>{len(sel)} orders</strong> — Total: ${total:,.2f}")
  else:
      bpm.reply("No selection")
```

### 10.3 Tool script for an agent: search docs

`search_docs.py`:
```python
#!python3
import redflagbpm
bpm = redflagbpm.BPMService()

q = bpm.context.args.get("query", "").strip()
if not q:
    bpm.reply("Provide a query")
else:
    rows = bpm.documentService.readList(
        collection="kb",
        criteria="content LIKE ?",
        parameters={"1": f"%{q}%"})
    bpm.reply({
        "results": [{"title": r.get("title", "(untitled)"),
                     "snippet": r.get("snippet", "")}
                    for r in rows[:5]],
        "count": min(5, len(rows)),
    })
```

`search_docs.py.config`:
```yaml
project: "MYPROJ"
id: "MYPROJ/SEARCH_DOCS_TOOL"
type: "Script"
lang: "Shell"
properties:
  tool:
    name: "searchDocs"
    description: "Search the knowledge base by free text. Use this when the user asks for information that may exist in our documents."
    args_schema:
      type: object
      properties:
        query: { type: string, description: "Free-text search query" }
      required: [query]
```

### 10.4 Post-processor that mutates row

`enrich_row.py`:
```python
#!python3
import redflagbpm
bpm = redflagbpm.BPMService()

row = bpm.context.row
row["status_label"] = {"P": "Pending", "A": "Approved", "R": "Rejected"}.get(row.get("status"), row.get("status"))
row["template"] = f"<strong>{row['name']}</strong> · {row['status_label']}"
```

`enrich_row.py.config`:
```yaml
project: "MYPROJ"
id: "MYPROJ/ENRICH_ROW"
type: "Script"
lang: "Shell"
```

Wired from a query: `postProcessors: ["MYPROJ/ENRICH_ROW"]`. See `references/templates.md` for the full row-template mechanics.

## 11. End-to-end example: action with `inputSchema` and rich `displayHints`

`approve_invoice.py`:
```python
#!python3
import sys
import redflagbpm
from redflagbpm.PgUtils import get_connection
bpm = redflagbpm.BPMService()

invoice_id = bpm.context.id_invoice
reason = bpm.context.input.get("reason", "")
amount  = bpm.context.input.get("authorized_amount", 0)
caller  = bpm.context.userId   # auto-injected by the BPM launcher

if amount <= 0:
    bpm.reply({"type": "ERROR", "statusMessage": "Amount must be > 0"})
    sys.exit(0)

with get_connection(bpm, "finance") as conn, conn.cursor() as cur:
    cur.execute(
        "UPDATE invoices "
        "   SET status = 'APPROVED', authorized_amount = %s, "
        "       approval_reason = %s, approved_by = %s "
        " WHERE id = %s",
        (amount, reason, caller, invoice_id),
    )

bpm.service.notifyUser(
    user="finance-team",
    title="Invoice approved",
    desc=f"Invoice {invoice_id} approved by {caller}",
    target=f"finance/invoices/{invoice_id}")

bpm.reply({
    "type": "MESSAGE",
    "statusMessage": f"<h3>Invoice approved</h3><p>Authorized amount: <b>${amount:,.2f}</b></p>",
    "statusMessageContentType": "text/html"
})
```

`approve_invoice.py.config`:
```yaml
project: "FIN"
id: "FIN/APPROVE_INVOICE"
type: "Script"
lang: "Shell"
description: "Approve an invoice after authorizing the amount"
properties:
  caption: "Approve"
  icon: "fa fa-check"
  type: "update"
  selectionScope: 1
  displayHints: ["main", "confirm", "large", "refresh-on-close"]
  reusable: false
  asynchronous: false
  groupName: "Approvals"
  shortcuts:
    primary: "ctrl+enter"
  inputSchema:
    type: object
    title: "Approve invoice"
    hints:
      fieldOrder: ["authorized_amount", "reason"]
      callToAction: "Approve invoice"
    properties:
      authorized_amount:
        type: number
        title: "Authorized amount"
      reason:
        type: string
        title: "Reason / notes"
        format: "text"
    required: ["authorized_amount", "reason"]
```

This single artifact: lives as a primary toolbar button (`main`), asks the user to confirm (`confirm`), opens a wide modal (`large`) with a 2-field form, refreshes the underlying query when the modal closes (`refresh-on-close`), groups under "Approvals" with siblings, has a Ctrl+Enter shortcut, and uses CPython3 for any libraries it needs.

## 12. Validation summary

`validators/script.py` (or `config_file.py` when `type: Script`) checks:

| Check | Rule | Severity |
|---|---|---|
| `type` (top-level) | Must equal `Script` for script artifacts | error |
| `lang` | Must be one of `JavaScript, Python, Velocity, JSON, YAML, JUEL, Vertx, Shell, Prompt, Markdown, Binary` | error |
| `properties.type` | Must be one of `{create, update, delete, query, display, call, open}` (lowercase) | error |
| `properties.selectionScope` | Must be one of `{0, 1, -1, -2, -3, -4}` (default `1`) | error |
| `properties.displayHints[*]` | Each entry must be in `{default, main, confirm, small, medium, large, x-large, refresh-on-close}` | error |
| `properties.displayHints` | Must be a list (not a single string) | error |
| `properties.inputSchema` | Must be a syntactically valid JSON Schema (`type: object` at root, `properties` map, optional `required` array) | error |
| `properties.tool.name` | Required if `tool` block present; non-empty string | error |
| `properties.tool.description` | Required if `tool` block present | error |
| `properties.tool.args_schema` | Required if `tool` block present; must be valid JSON Schema with `type: object` | error |
| `properties.tool.args_schema.properties[*].type` | Should be one of `string, integer, number, boolean` (LLM-friendly subset) | warn |
| Code body starts with shebang | If `lang: Shell`, first line must start with `#!` | warn |
| `#!python3` with `lang: Python` | Likely user expected CPython3 — should be `lang: Shell` | warn |
| `properties.asynchronous: true` + `bpm.reply` | Async actions can't reply interactively — flag uses of `bpm.reply` for structured UI types | warn |
| `properties.reusable` / `properties.asynchronous` | Must be boolean | error |
| `properties.shortcuts` | Must be a map of string → string | error |

## 13. References

Cross-references in this skill:

- `references/queries.md` — how queries declare action `scripts`/`details`/`reports`/`services`/`postProcessors` referencing script ids and how `selectionScript` is wired.
- `references/forms.md` — full `inputSchema` spec including `hints.feedback` for inline validation scripts.
- `references/agents-and-rag.md` — how agents consume `tool` blocks and orchestrate tool calls.
- `references/templates.md` — post-processors, `row.template`, and rendering semantics for `Markdown` / `YAML` / `JSON` / `Velocity` post-processors.
