"""Validate `.config` files (CodeDTO shape)."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .common import (
    Severity,
    ValidationResult,
    check_enum,
    check_regex,
    check_required_fields,
)
from .enums import (
    ARTIFACT_ID_RE,
    ARTIFACT_TYPES,
    ACTION_DISPLAY_HINTS,
    ACTION_SELECTION_SCOPES,
    ACTION_TYPES,
    CRON_RE,
    LANGS,
    PROJECT_ID_RE,
    TYPE_LANG_COHERENCE,
)

# Tool name shown to the LLM. OpenAI / Gemini / Anthropic accept
# `^[A-Za-z0-9_-]+$` (with a leading-letter requirement varying by provider).
# We require a leading letter for safety. The `/` from a raw CodeDTO id is the
# most common accidental violation; if `properties.tool.name` is omitted the
# runtime sanitizes the id automatically (replaces `/` with `_`).
_TOOL_NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_-]*$")

# Types whose access control fields live at the top level of the artifact
# *body* YAML (not in the `.config` properties). Putting `targetUsers`/
# `targetGroups` under `.config.properties` for these types is silently
# ignored at runtime.
_BODY_LEVEL_ACCESS_TYPES = {"Agent", "Analyst", "Mcp", "Menu",
                            "Query", "Service", "Form", "Collection"}

_REQUIRED = ("project", "id", "lang", "type")


def validate(body: Any, config: Any, result: ValidationResult) -> None:
    # When called as the entry validator, the "body" we receive is actually
    # the .config contents (since we called load_artifact_pair on a .config file).
    cfg = config if config is not None else body
    if not isinstance(cfg, dict):
        result.error("not-a-mapping", "config file root must be a YAML mapping")
        return

    check_required_fields(result, cfg, _REQUIRED)

    # project
    project = cfg.get("project")
    if isinstance(project, str):
        check_regex(result, project, PROJECT_ID_RE, "bad-project-id", "project")

    # id matches PROJECT/ID and starts with project field
    # (Mcp artifacts use a global id without a slash, by convention)
    art_id = cfg.get("id")
    art_type = cfg.get("type")
    if isinstance(art_id, str) and art_type != "Mcp":
        check_regex(result, art_id, ARTIFACT_ID_RE, "bad-artifact-id", "id")
        if isinstance(project, str) and "/" in art_id:
            prefix = art_id.split("/", 1)[0]
            if prefix != project:
                result.error(
                    "id-project-mismatch",
                    f"id prefix {prefix!r} does not match project field {project!r}",
                    "id",
                )

    # lang
    check_enum(result, cfg.get("lang"), LANGS, "bad-lang", "lang", Severity.ERROR)

    # type
    check_enum(result, art_type, ARTIFACT_TYPES, "bad-type", "type", Severity.ERROR)

    # type ↔ lang coherence
    lang = cfg.get("lang")
    if isinstance(art_type, str) and isinstance(lang, str):
        expected = TYPE_LANG_COHERENCE.get(art_type)
        if expected and lang not in expected:
            result.warning(
                "lang-type-mismatch",
                f"lang {lang!r} is unusual for type {art_type!r} (typical: {sorted(expected)})",
                "lang",
            )

    # cron
    cron = cfg.get("cron")
    if cron not in (None, ""):
        check_regex(result, cron, CRON_RE, "bad-cron", "cron", Severity.WARNING)

    # deprecated `form` boolean
    if "form" in cfg:
        result.info(
            "deprecated-form-field",
            "the boolean 'form' field is deprecated — use type: Form instead",
            "form",
        )

    # Script properties
    if art_type == "Script":
        _validate_script_properties(cfg.get("properties"), result)

    # Body-level access-control fields placed under `.config.properties`
    # are silently ignored for these types — flag them.
    if isinstance(art_type, str) and art_type in _BODY_LEVEL_ACCESS_TYPES:
        props = cfg.get("properties")
        if isinstance(props, dict):
            for misplaced in ("targetUsers", "targetGroups"):
                if misplaced in props:
                    result.warning(
                        "access-control-misplaced",
                        f"properties.{misplaced} on type {art_type!r} is ignored "
                        f"at runtime — move it to the top level of the artifact "
                        f"body YAML (e.g. agent.yaml), not the .config sidecar.",
                        f"properties.{misplaced}",
                    )


def _validate_script_properties(props: Any, result: ValidationResult) -> None:
    if not isinstance(props, dict):
        return
    p_type = props.get("type")
    check_enum(result, p_type, ACTION_TYPES, "bad-action-type",
               "properties.type", Severity.ERROR)

    p_scope = props.get("selectionScope")
    if p_scope is not None:
        check_enum(result, p_scope, ACTION_SELECTION_SCOPES,
                   "bad-selection-scope", "properties.selectionScope",
                   Severity.ERROR)

    hints = props.get("displayHints")
    if hints is not None:
        if not isinstance(hints, list):
            result.error(
                "display-hints-not-list",
                "properties.displayHints must be a list of strings",
                "properties.displayHints",
            )
        else:
            for i, h in enumerate(hints):
                check_enum(result, h, ACTION_DISPLAY_HINTS,
                           "bad-display-hint",
                           f"properties.displayHints[{i}]",
                           Severity.ERROR)

    # tool block (when script is an agent tool)
    tool = props.get("tool")
    if isinstance(tool, dict):
        _check_tool_returns_via_reply(result)
        # `name` is now optional — when omitted, BPM exposes the tool as the
        # CodeDTO id with `/` (and other invalid chars) replaced by `_`.
        # Description and args_schema are still required.
        for required in ("description", "args_schema"):
            if not tool.get(required):
                result.error(
                    "tool-missing-field",
                    f"properties.tool.{required} is required when 'tool' block is present",
                    f"properties.tool.{required}",
                )

        # When `name` is provided it must be LLM-friendly. Most providers reject
        # `/`, dots, and other punctuation in function names. Allowing `-`
        # because OpenAI/Gemini/Anthropic all accept it.
        tool_name = tool.get("name")
        if isinstance(tool_name, str) and tool_name and not _TOOL_NAME_RE.match(tool_name):
            result.error(
                "tool-name-bad-shape",
                f"properties.tool.name {tool_name!r} must match "
                f"^[A-Za-z][A-Za-z0-9_-]*$ — most LLM providers reject `/`, "
                f"dots and other punctuation in function names. Either fix "
                f"the name or remove it (BPM will derive it from the id by "
                f"replacing `/` with `_`).",
                "properties.tool.name",
            )

        # annotations: optional, MCP-standard hints. Validate shape if present.
        annotations = tool.get("annotations")
        if annotations is not None:
            if not isinstance(annotations, dict):
                result.error(
                    "tool-annotations-not-a-map",
                    "properties.tool.annotations must be a mapping with MCP hints "
                    "(destructiveHint, readOnlyHint, idempotentHint, title)",
                    "properties.tool.annotations",
                )
            else:
                for hint in ("destructiveHint", "readOnlyHint", "idempotentHint",
                             "openWorldHint"):
                    if hint in annotations and not isinstance(annotations[hint], bool):
                        result.error(
                            "tool-annotation-not-bool",
                            f"properties.tool.annotations.{hint} must be true or false",
                            f"properties.tool.annotations.{hint}",
                        )
                if "title" in annotations and not isinstance(annotations["title"], str):
                    result.error(
                        "tool-annotation-title-not-string",
                        "properties.tool.annotations.title must be a string",
                        "properties.tool.annotations.title",
                    )
                # destructiveHint=true + readOnlyHint=true is contradictory.
                if (annotations.get("destructiveHint") is True
                        and annotations.get("readOnlyHint") is True):
                    result.warning(
                        "tool-annotations-contradictory",
                        "destructiveHint=true and readOnlyHint=true are contradictory; "
                        "destructive tools mutate state, read-only tools don't.",
                        "properties.tool.annotations",
                    )


# `bpm.reply(` or `bpm.fail(` — both reach the LLM via the event bus.
# We treat them as equivalent for the "this script returns to the LLM" check
# even though we recommend `bpm.reply({"error": ...})` for tool errors.
_REPLY_RE = re.compile(r"\bbpm\.(reply|fail)\s*\(")
# `print(...)` invocation — both flat and inside expressions. We strip strings
# and comments first so we don't false-positive on docstrings or `# print` notes.
_PRINT_RE = re.compile(r"\bprint\s*\(")
# Opt-in directive that promotes stdout to the script's return value. If the
# script declares this, `print` is intentional and we should not warn.
_RETURN_STDOUT_RE = re.compile(r"^\s*#\s*RETURN\s+STDOUT\b", re.IGNORECASE | re.MULTILINE)


def _check_tool_returns_via_reply(result: ValidationResult) -> None:
    """Read the sibling source file of the .config and warn if a tool script
    relies on stdout (`print`) instead of `bpm.reply`/`bpm.fail`.

    The Shell engine awaits a `reply` on the event bus and returns its payload
    as the script's value. `print(...)` is logged but discarded, so the LLM
    receives `null`/`"null"` and the chat memory may end up with an orphan
    AiMessage. Common gotcha when porting endpoint/action scripts to tools.

    Heuristic: triggers only when the source ends in `.py` (Jython files use
    `lang: Python` and rarely act as Agent tools, but we still apply the same
    logic since the SDK call signature is identical). Skips if the script
    declares the `# RETURN STDOUT` directive (legitimate stdout-as-return).
    """
    raw_path = getattr(result, "file", None)
    if not raw_path:
        return
    p = Path(raw_path)
    # Resolve sibling source: if .config was passed, strip the suffix.
    src = p.with_name(p.name[:-len(".config")]) if p.name.endswith(".config") else p
    if src.suffix.lower() != ".py":
        return
    if not src.is_file():
        return
    try:
        text = src.read_text(encoding="utf-8")
    except OSError:
        return
    sanitized = _strip_strings_and_comments(text)
    has_print = bool(_PRINT_RE.search(sanitized))
    has_reply = bool(_REPLY_RE.search(sanitized))
    has_return_stdout = bool(_RETURN_STDOUT_RE.search(text))
    if has_print and not has_reply and not has_return_stdout:
        result.error(
            "tool-uses-print-not-reply",
            "Tool script uses print(...) but never calls bpm.reply(...). The "
            "Shell engine returns the bpm.reply payload to the LLM via the "
            "event bus; print(...) is logged but discarded. Convert each "
            "return path to bpm.reply({...}) (use bpm.reply({\"error\": ...}) "
            "for tool-side validation errors). Add `# RETURN STDOUT` near the "
            "shebang only if you really want stdout-as-return — not "
            "recommended for Agent tools.",
            "code",
        )
    elif has_print and has_reply:
        # Mixed: probably ok (print to log, reply to LLM), but warn just in case.
        result.info(
            "tool-mixes-print-and-reply",
            "Tool script uses both print(...) and bpm.reply(...). The LLM only "
            "sees what bpm.reply returns; print(...) only goes to the script "
            "log. If the print was meant for the LLM, replace it with bpm.reply.",
            "code",
        )


def _strip_strings_and_comments(text: str) -> str:
    """Best-effort removal of Python string literals and `#` comments so the
    `print(`/`bpm.reply(` regex doesn't false-positive on docstrings or notes.

    Not a full parser — handles the common cases (single/double quotes, triple
    quotes, line comments). Acceptable: a few false negatives are ok; what we
    want to avoid is false positives that would block legitimate tool scripts.
    """
    # Triple-quoted strings (greedy, multi-line). Keep newlines for line numbers.
    text = re.sub(r"(?s)\"\"\".*?\"\"\"", lambda m: "\n" * m.group().count("\n"),
                  text)
    text = re.sub(r"(?s)'''.*?'''", lambda m: "\n" * m.group().count("\n"),
                  text)
    # Single-line strings (do not span newlines).
    text = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', text)
    text = re.sub(r"'(?:\\.|[^'\\\n])*'", "''", text)
    # `#` comments to end of line.
    text = re.sub(r"#[^\n]*", "", text)
    return text
