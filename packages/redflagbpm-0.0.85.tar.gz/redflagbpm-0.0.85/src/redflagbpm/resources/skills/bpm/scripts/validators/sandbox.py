"""Validate sandbox YAML (used by Coder RepoDTO and AnalystInfo)."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .common import Severity, ValidationResult
from .enums import (
    SANDBOX_MODE,
    SANDBOX_NETWORK_VALUES,
    SANDBOX_PLACEHOLDERS,
    SANDBOX_SERVICE_ALLOWED,
    SANDBOX_SERVICE_FORBIDDEN,
    SANDBOX_TOP_LEVEL_ALLOWED,
    SANDBOX_TOP_LEVEL_FORBIDDEN,
)


_PLACEHOLDER_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")

_MOUNT_DENYLIST_PREFIXES = (
    "/etc", "/proc", "/sys", "/dev", "/root",
    "/var/run", "/run/docker.sock", "/var/lib/docker",
)
_MOUNT_DEFAULT_ALLOWLIST_PREFIXES = (
    # Prod default: ${bpm.files.dir}/opencode/{scratch,repos} con bpm.files.dir
    # = /app/files (el path del named volume bpm-files montado en BPM container).
    # Configurable via -Dbpm.acp.mount.allowedPrefixes en el deploy del BPM.
    "/app/files/opencode/scratch", "/app/files/opencode/repos",
    "/tmp/bpm-", "/tmp/acp-", "/tmp/launcher-",
)


def validate(body: Any, config: Any, result: ValidationResult) -> None:
    if not isinstance(body, dict):
        result.error("not-a-mapping", "sandbox must be a YAML mapping")
        return

    # Top-level: image, build o convención. Si nada de eso aplica, BPM cae al
    # Dockerfile default bundled (Python 3.12-slim + data science stack). Le
    # avisamos al autor con un INFO para que sepa qué imagen va a correr —
    # casi siempre conviene declarar algo explícito.
    if not body.get("image") and not body.get("build"):
        if not _convention_dockerfile_exists(result):
            result.add(
                Severity.INFO,
                "sandbox-using-default-image",
                "sandbox sin `image:`, `build:` ni `docker/Dockerfile` local — BPM "
                "usará el Dockerfile default bundled (Python 3.12-slim + pandas, "
                "numpy, matplotlib, reportlab, pandoc, ...). Si tu Analyst necesita "
                "deps específicas, declará `image:` (prebuilt), `build:` (Dockerfile "
                "explícito), o agregá un `docker/Dockerfile` en la sibling folder. "
                "Ver references/sandbox.md § 'Dockerfile default'.",
                "image",
            )

    # Top-level forbidden
    for k in body.keys():
        if k in SANDBOX_TOP_LEVEL_FORBIDDEN:
            result.error(
                "sandbox-top-level-forbidden",
                f"top-level field {k!r} is not allowed",
                k,
            )

    # mode
    mode = body.get("mode")
    if mode is not None and mode not in SANDBOX_MODE:
        result.error(
            "sandbox-bad-mode",
            f"mode {mode!r} not in {sorted(SANDBOX_MODE)}",
            "mode",
        )

    # service block
    service = body.get("service")
    if service is not None:
        if not isinstance(service, dict):
            result.error("sandbox-service-not-mapping",
                         "sandbox.service must be a mapping", "service")
        else:
            _validate_service(service, result)

    # build block — convención BPM: Dockerfile bajo `./docker/`
    build = body.get("build")
    if build is not None:
        _validate_build(build, result)

    # Convención BPM: el Dockerfile (declarado o auto-detectado) debe declarar
    # `ARG BPM_BUILD_MARKER`. BPM lo inyecta como --build-arg para invalidar
    # capas cacheadas cuando el Dockerfile cambia. Sin esa línea, las capas
    # `RUN install` quedan cacheadas indefinidamente.
    if not body.get("image"):
        _validate_build_marker_arg(build, result)

    # placeholders
    _check_placeholders(body, result, path="")


_ARG_MARKER_RE = re.compile(r"^\s*ARG\s+BPM_BUILD_MARKER(?:\s|=|$)", re.MULTILINE)


def _resolve_dockerfile_path(build: Any, base_dir: Path) -> Path | None:
    """Devuelve el path absoluto del Dockerfile a validar, o None si no aplica."""
    if isinstance(build, str):
        return (base_dir / build).resolve()
    if isinstance(build, dict):
        df = build.get("dockerfile")
        ctx = build.get("context")
        if isinstance(df, str):
            df_path = Path(df)
            if df_path.is_absolute():
                return df_path.resolve()
            if isinstance(ctx, str):
                return (base_dir / ctx / df_path).resolve()
            return (base_dir / df_path).resolve()
        if isinstance(ctx, str):
            return (base_dir / ctx / "Dockerfile").resolve()
        return (base_dir / "Dockerfile").resolve()
    # Auto-detect convention: <baseDir>/docker/Dockerfile.
    if build is None:
        return (base_dir / "docker" / "Dockerfile").resolve()
    return None


def _convention_dockerfile_exists(result: ValidationResult) -> bool:
    """True si existe `<baseDir>/docker/Dockerfile` por convención BPM."""
    if not result.file:
        return False
    base_dir = _resolve_base_dir(Path(result.file).resolve())
    return (base_dir / "docker" / "Dockerfile").is_file()


def _resolve_base_dir(file_path: Path) -> Path:
    """Mismo que el Java parser: si junto al YAML hay un sibling dir con el
    stem (convención Analyst), ese es el baseDir; sino, el parent del YAML
    (convención Coder/RepoDTO).
    """
    parent = file_path.parent
    stem = file_path.stem
    sibling = parent / stem
    return sibling if sibling.is_dir() else parent


def _validate_build_marker_arg(build: Any, result: ValidationResult) -> None:
    """Convención BPM: el Dockerfile declara `ARG BPM_BUILD_MARKER`.

    Si encontramos el archivo en disco, leemos y chequeamos. Si no lo
    encontramos (Dockerfile referenciado fuera del FS local, contexto de
    validación remoto, etc.) silenciosamente skipeamos.
    """
    if not result.file:
        return
    base_dir = _resolve_base_dir(Path(result.file).resolve())
    dockerfile_path = _resolve_dockerfile_path(build, base_dir)
    if dockerfile_path is None:
        return
    if not dockerfile_path.is_file():
        # Si declararon `build:` pero el archivo no está, _validate_build
        # ya cubre el shape; acá no agregamos ruido. Para auto-detect
        # (build is None) no emitimos nada — significa que el Analyst
        # apunta a una `image:` prebuilt o aún no creó el Dockerfile.
        return
    try:
        content = dockerfile_path.read_text(encoding="utf-8")
    except OSError:
        return
    if not _ARG_MARKER_RE.search(content):
        result.warning(
            "sandbox-dockerfile-missing-build-marker",
            f"Dockerfile {dockerfile_path.name} no declara `ARG BPM_BUILD_MARKER`. "
            "BPM inyecta ese build-arg con un hash del Dockerfile para invalidar "
            "capas cacheadas (apt/pip refresh) cuando el Dockerfile cambia. Sin "
            "el ARG, los `RUN install` quedan cacheados indefinidamente. Agregá "
            "`ARG BPM_BUILD_MARKER` cerca del top, antes de los RUN. Ver "
            "references/sandbox.md § 'Convención `ARG BPM_BUILD_MARKER`'.",
            "build",
        )


def _validate_build(build: Any, result: ValidationResult) -> None:
    """Convención BPM: el build context vive en `<sibling>/docker/`.

    No es un error duro (el parser Java lo acepta igual), pero el equipo
    estandariza Dockerfiles bajo `docker/` para mantener prolija la sibling
    folder del Analyst (skills/, agents/, commands/, modes/, docker/, ...).
    Emitimos un WARNING para visibilizar deviations.
    """
    if isinstance(build, str):
        # Short form: `build: ./docker/Dockerfile` (o variante).
        # Aceptamos cualquier path que termine en `docker/<name>` o cuyo parent sea `docker`.
        path = build.lstrip("./").rstrip("/")
        parts = path.split("/")
        if "docker" not in parts[:-1]:
            result.warning(
                "sandbox-build-not-under-docker",
                "Convención BPM: ubicar Dockerfiles bajo `docker/` (estándar de la "
                "sibling folder del Analyst — junto a skills/, agents/, commands/, "
                "modes/). Ej: `build: ./docker/Dockerfile`. Ver references/sandbox.md "
                "§ 'Convención del build context'.",
                "build",
            )
        return

    if isinstance(build, dict):
        # Long form: {context: ./docker, dockerfile: Dockerfile, ...}.
        context = build.get("context")
        dockerfile = build.get("dockerfile")
        if isinstance(context, str):
            ctx_norm = context.lstrip("./").rstrip("/")
            # OK: context apunta a `docker` o a un path bajo `docker/`.
            # Deviation: cualquier otra cosa, incluyendo `.` (root del baseDir,
            # demasiado amplio — incluye agents/, skills/, etc. en el tarball).
            if ctx_norm != "docker" and not ctx_norm.endswith("/docker"):
                result.warning(
                    "sandbox-build-context-not-docker",
                    "Convención BPM: `build.context` debería apuntar a `./docker` "
                    "(o un subdir bajo `docker/`). Estandariza la sibling folder y "
                    "evita inflar el tarball del build con archivos no relacionados. "
                    "Ver references/sandbox.md § 'Convención del build context'.",
                    "build.context",
                )
        elif isinstance(dockerfile, str):
            # context default = parent del dockerfile
            df_norm = dockerfile.lstrip("./").rstrip("/")
            parts = df_norm.split("/")
            if "docker" not in parts[:-1]:
                result.warning(
                    "sandbox-build-not-under-docker",
                    "Convención BPM: ubicar Dockerfiles bajo `docker/` (estándar "
                    "de la sibling folder del Analyst). Ver references/sandbox.md "
                    "§ 'Convención del build context'.",
                    "build.dockerfile",
                )


def _validate_service(service: dict, result: ValidationResult) -> None:
    # Forbidden service fields
    for key in service.keys():
        if key in SANDBOX_SERVICE_FORBIDDEN:
            result.error(
                "sandbox-service-forbidden",
                f"service.{key} is not allowed (rejected by BPM)",
                f"service.{key}",
            )

    # Special-cases: privileged / network / network_mode / pid / ipc / userns_mode
    if service.get("privileged") is True:
        result.error("sandbox-privileged",
                     "service.privileged: true is denied", "service.privileged")
    pid = service.get("pid")
    if pid is not None and pid != "private":
        result.error("sandbox-pid",
                     f"service.pid: {pid!r} is denied (must be 'private')",
                     "service.pid")
    ipc = service.get("ipc")
    if ipc is not None and ipc not in ("private", "shareable"):
        result.error("sandbox-ipc",
                     f"service.ipc: {ipc!r} is denied",
                     "service.ipc")
    if "userns_mode" in service:
        result.error("sandbox-userns-mode",
                     "service.userns_mode is denied",
                     "service.userns_mode")
    if service.get("network") == "host":
        result.error("sandbox-network-host",
                     "service.network: host is denied",
                     "service.network")
    if service.get("network_mode") == "host":
        result.error("sandbox-network-mode-host",
                     "service.network_mode: host is denied (BPM controls network)",
                     "service.network_mode")

    # network value warning when not in known set
    network = service.get("network")
    if network is not None and network != "host" \
            and network not in SANDBOX_NETWORK_VALUES:
        result.warning(
            "sandbox-network-unknown",
            f"network {network!r} not in known set {sorted(SANDBOX_NETWORK_VALUES)} "
            "(may be a custom network defined by the host admin)",
            "service.network",
        )

    # Unknown service fields: info, since BPM ignores them silently
    for key in service.keys():
        if (key not in SANDBOX_SERVICE_ALLOWED
                and key not in SANDBOX_SERVICE_FORBIDDEN
                and key not in {"privileged", "pid", "ipc", "userns_mode",
                                "network_mode"}):
            result.info(
                "sandbox-service-unknown",
                f"service.{key!r} not in known set; will be ignored at runtime",
                f"service.{key}",
            )

    # volumes
    volumes = service.get("volumes")
    if isinstance(volumes, list):
        for i, vol in enumerate(volumes):
            _validate_volume(vol, result, path=f"service.volumes[{i}]")


def _validate_volume(vol: Any, result: ValidationResult, path: str) -> None:
    if isinstance(vol, str):
        # Short form: src:tgt[:mode]
        parts = vol.split(":")
        if len(parts) < 2:
            result.error(
                "sandbox-volume-short-form",
                f"volume short form requires src:tgt[:mode]: {vol!r}",
                path,
            )
            return
        source = parts[0]
        _validate_mount_source(source, result, path)
    elif isinstance(vol, dict):
        if vol.get("type") and vol["type"] != "bind":
            result.error(
                "sandbox-volume-type",
                f"volume type {vol['type']!r} not supported (only 'bind' for v1)",
                f"{path}.type",
            )
        source = vol.get("source")
        if source:
            _validate_mount_source(source, result, f"{path}.source")
    else:
        result.error("sandbox-volume-shape",
                     "volume must be a short string or a mapping", path)


def _validate_mount_source(source: str, result: ValidationResult,
                            path: str) -> None:
    # Resolve simple placeholders
    expanded = _PLACEHOLDER_RE.sub("PLACEHOLDER", source)
    for prefix in _MOUNT_DENYLIST_PREFIXES:
        if expanded.startswith(prefix):
            result.error(
                "sandbox-mount-denied",
                f"mount source denied ({prefix}): {source!r}",
                path,
            )
            return
    if expanded.startswith("/"):
        if not any(expanded.startswith(p)
                   for p in _MOUNT_DEFAULT_ALLOWLIST_PREFIXES):
            result.warning(
                "sandbox-mount-not-in-allowlist",
                f"mount source not in default allowlist: {source!r} "
                "(configurable via system property bpm.acp.mount.allowedPrefixes)",
                path,
            )


def _check_placeholders(obj: Any, result: ValidationResult,
                        path: str) -> None:
    if isinstance(obj, str):
        for m in _PLACEHOLDER_RE.finditer(obj):
            name = m.group(1)
            if name not in SANDBOX_PLACEHOLDERS:
                result.warning(
                    "sandbox-unknown-placeholder",
                    f"placeholder ${{{name}}} not in {sorted(SANDBOX_PLACEHOLDERS)}",
                    path,
                )
    elif isinstance(obj, dict):
        for k, v in obj.items():
            _check_placeholders(v, result, f"{path}.{k}" if path else k)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            _check_placeholders(v, result, f"{path}[{i}]")
