"""redflagbpm — Python SDK for the RedFlag BPM platform.

`BPMService` is the main client. It is imported lazily so that companion
entry points (`python3 -m redflagbpm.install_skill`) work even when the
optional `vertx-eventbus-client` dependency is not installed.
"""
try:
    from redflagbpm.BPMService import BPMService  # noqa: F401
except ImportError:
    # vertx-eventbus-client is missing; BPMService cannot be used in this
    # environment, but the skill installer (and other lightweight commands)
    # can still run.
    BPMService = None  # type: ignore[assignment]
