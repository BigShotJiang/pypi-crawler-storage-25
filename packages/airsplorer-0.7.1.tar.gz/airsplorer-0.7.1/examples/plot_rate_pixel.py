"""
Plot all info available for a given pixel based on rate, ramp, uncal and corresponding CDP files.
"""
import matplotlib.pyplot as plt

from airsplorer import plot

path = r"C:\Users\ccossou\LocalStorage\data\ariel\2026_03_EM_CONFIG1\tmp\260414_125052_2028_ifpa_em_ch0_rate.fits"
# (x,y)
coords =[(37, 178)]


plot.plot_pixel_study(path, (37, 178), int_i=1)
plt.show()

# for c in coords:
#     print(f"Plotting pixel {c}...")
#     fig = plot.plot_pixel_study(path, c, int_i=1)
#     plt.show()
#     # fig.savefig(f"pixel_study_{c[0]}_{c[1]}.png")
#     # plt.close(fig)
