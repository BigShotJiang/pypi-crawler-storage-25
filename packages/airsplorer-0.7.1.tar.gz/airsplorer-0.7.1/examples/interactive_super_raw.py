"""
Using a _ramp .fits, explore the datacube, click on a pixel to see its integration and correspondant group flags.
Select group and integration to see the corresponding image.
"""
import airsplorer

filename = r"C:\Users\ccossou\LocalStorage\data\ariel\2026_03_EM_CONFIG1\CH0\Ref2_9999nm_Tx\260428_103124_2150_ifpa_em_ch0"
filename = r"C:\Users\ccossou\LocalStorage\data\ariel\2026_03_EM_CONFIG1\CH0\Ref2_9999nm_Tx\260428_091710_2143_ifpa_em_ch0"
filename = r"C:\Users\ccossou\LocalStorage\data\ariel\2026_03_EM_CONFIG1\CH0\Ref2_9999nm_Tx\260428_133824_2173_ifpa_em_ch0"

interactive_ramp = airsplorer.gui.ql_super_raw.interactive_super_raw(filename, ypos=1, xpos=1)
