"""
Using a _ramp .fits, explore the datacube, click on a pixel to see its integration and correspondant group flags.
Select group and integration to see the corresponding image.
"""

import matplotlib.pyplot as plt

import airsplorer

filename = r"C:\Users\ccossou\LocalStorage\data\ariel\2026_03_EM_CONFIG1\CH0\Ref2_9999nm_Tx\260416_135957_2107_ifpa_em_ch0_ramp.fits"
# filename = r"C:\Users\ccossou\LocalStorage\data\ariel\2026_03_EM_CONFIG1\CH0\Ref2_9999nm_Tx\260416_135957_2107_ifpa_em_ch0_uncal.fits"

interactive_ramp = airsplorer.gui.ql_ramp.interactive_ramp(filename)

plt.show()
