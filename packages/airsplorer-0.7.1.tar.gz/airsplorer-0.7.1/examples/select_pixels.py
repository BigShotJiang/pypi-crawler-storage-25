from astropy.io import fits

import airsplorer

path = r"C:\Users\ccossou\LocalStorage\data\ariel\2026_03_EM_CONFIG2\CH0\Ref1_Tests_scripts\260422_092059_1011_ifpa_em_ch0_rate.fits"

image = fits.getdata(path)

airsplorer.gui.pix_click.select_pixels(image)

# excluded_pixels = [(20, 310), (51, 44), (59, 180), (44, 39), (22, 313), (21, 40), (4, 82), (30, 12), (58, 211), (18, 114), (20, 291), (19, 265), (45, 58), (41, 39), (0, 276), (52, 45), (24, 352), (5, 247), (45, 140), (28, 14), (6, 44), (1, 292), (16, 116), (52, 145), (46, 141), (4, 294), (60, 45), (40, 256), (56, 127), (8, 346), (25, 277), (7, 198), (21, 78), (53, 146), (61, 248), (26, 278), (20, 39), (21, 172), (37, 342), (8, 150)]
# ql.select_pixels(image, exclude=excluded_pixels)
