"""
Compare multiple fits with the same format
"""
import matplotlib.pyplot as plt

from airsplorer import comp

files = [
r"C:\Users\ccossou\LocalStorage\Documents\Ariel\CDP\ariel_airs_saturation_CH1_BBM_3_00003.fits",
r"C:\Users\ccossou\LocalStorage\Documents\Ariel\CDP\ariel_airs_saturation_CH1_BBM_3_00001.fits",
]

# Fits file comparison
import astropy.io.fits as fits

comparison = fits.FITSDiff(*files, ignore_keywords=['DATE', 'EXPEND', 'EXPSTART', 'TIME-OBS', 'DATE-OBS', 'FILENAME'])
print(comparison.report())

# Compare rates
# comp.compare_fits(files, titles=['2029', '2028'])

# Compare ramps
# comp.compare_fits(files, titles=['old', 'new'], slice=(1,10))

# Compare values of multiple files at the same slice
# comp.compare_values(files, extension=1, slice=(1,0, 40, 6))

plt.show()
