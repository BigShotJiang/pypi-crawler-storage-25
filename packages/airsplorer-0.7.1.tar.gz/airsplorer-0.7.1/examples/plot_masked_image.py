"""
Show a 2D image masking invalid pixels
"""
import matplotlib.pyplot as plt
from astropy.io import fits

from airsplorer import plot

path = r"C:\Users\ccossou\LocalStorage\data\ariel\2026_03_EM_CONFIG1\CH1\Ref3_Dark\260409_155022_3013_ifpa_em_ch1_rate.fits"

with fits.open(path) as hdul:
    image = hdul["SCI"].data
    dq = hdul['DQ'].data


#fig = plot.masked_image(image, dq)
fig = plot.single_image(dq)
plt.show()
