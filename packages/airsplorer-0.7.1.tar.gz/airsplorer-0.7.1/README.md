# AIRSplorer

Convenience tools for analysis and data manipulation related to ARIEL AIRS. The package provides utilities for working with images and cubes, basic flux calculations, coordinate conversions, mask handling, I/O helpers, and common plotting routines.

- Python ≥ 3.11
- License: MIT
- Repository: https://github.com/ccossou/airsplorer

## Key features

- Image and cube manipulation (load, save, simple transforms)
- Basic photometry and flux/statistics utilities
- Sky/pixel coordinate conversions
- Mask creation, application, and operations
- Plotting helpers and tabulated outputs
- Test suite for core functionality

Indicative modules:
- `coord`: coordinate conversions and utilities
- `flux`: simple photometry and flux-related computations
- `imager` / `imlib`: image operations
- `mask`: mask creation and manipulation
- `plot`: common plotting helpers
- `utils`: assorted utility functions

## Installation

From PyPI (when available):
```
bash
python -m pip install airsplorer
```
From source (development):
```
bash
git clone https://github.com/ccossou/airsplorer.git
cd airsplorer
python -m pip install -e .
```
Main runtime dependencies are installed automatically.

On windows, one might have to install extra dependencies, namely, *Visual C++ Redistributable*. Go to [Visual Studio](https://visualstudio.microsoft.com/fr/downloads/), go at the bottom of the page, to the *Downloads/Autre outils, infrastructures et redistribuables* and take *Microsoft Visual C++ v14 Redistributable x64* (or newer if any).

On Mac/Linux, the dependencies should be installed automatically.

> [!IMPORTANT]
> Installation easily fail if it's done in a python environment that is not properly set up, like, for instance, the base environment for spyder/miniforge/miniconda. I advise to use a dedicated environment that is not the system python, or base environment for any virtual environment manager to avoid any potential issues. It is not necessary, however, to create a specific environment for airsplorer and it can be installed in a pre-existing one. Creating a new environment is a good idea if you struggle to make it work, and want to test if it work better in a brand new environment.

## Quick start
```
python
# Example imports (see function docstrings for exact APIs)
from airsplorer import coord, flux, imager, mask, utils, read, write, plot

# Loading and saving (adjust paths and formats to your data)
# data = read.load_image("path/to/file.fits")
# write.save_image(data, "path/to/output.fits")

# Image operations
# img2 = imager.normalize(data)
# m = mask.create_threshold_mask(img2, threshold=5.0)
# img3 = imager.apply_mask(img2, m)

# Flux calculations
# f = flux.aperture_photometry(img3, center=(x0, y0), radius=5)

# Coordinate conversions
# px, py = coord.sky_to_pixel(ra, dec, wcs_header)
# ra2, dec2 = coord.pixel_to_sky(px, py, wcs_header)

# Plotting
# plot.imshow(img3, title="Processed image")
```
Notes:
- Check each function’s docstring for signatures, units, and options.
- Adjust examples to your data formats and WCS headers.


## License and citation

- License: MIT
- If you use airsplorer in scientific work, please cite the repository and the software version you used. A DOI or BibTeX entry may be added in the future.
```
