import sys
import warnings


@warnings.deprecated("Deprecated, use the cli airsql directly or see SAMBA/scripts for updated example instead.")
def interactive_ramp(*args, **kwargs):
    """
    Deprecated, use gui.ql_ramp.interactive_ramp instead
    """
    sys.exit()

@warnings.deprecated("Deprecated, use the cli airsql directly or see SAMBA/scripts for updated example instead.")
def interactive_super_raw(*args, **kwargs):
    """
    Deprecated, use gui.ql_super_raw.interactive_super_raw instead
    """
    sys.exit()
