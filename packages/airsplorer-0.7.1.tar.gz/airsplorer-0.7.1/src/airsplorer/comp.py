"""
Compare library
"""
import os

import matplotlib.pyplot as plt
import numpy as np
from astropy.io import fits
from astropy.visualization import interval
from matplotlib import colors

from . import filediag


def compare_fits(filenames, extensions=(1,), titles=None, slice=None):

    print(filediag.compare_headers(filenames))

    if titles is None:
        titles = [os.path.basename(path) for path in filenames]

    for ext in extensions:
        ext_title = f"Extension {ext}"
        images = []
        ext_slice = slice
        for path in filenames:
            image = fits.getdata(path, ext=ext)

            # If more than 2D, take a slice
            if image.ndim > 2:
                if ext_slice is None:
                    ext_slice = (0,) * (image.ndim - 2)
                    ext_title += f" (slice: {slice})"

                image = image[ext_slice]

            images.append(image)

        fig = compare_images(images, titles)
        fig.suptitle(f"Extension {ext}")


def compare_images(images, titles=None, vrange=None):
    n_images = len(images)

    if titles is not None:
        if not isinstance(titles, (list, tuple)):
            raise ValueError(f"Expect ititles to be list or tuple of strings, was given '{titles}'")

        n_titles = len(titles)
        if n_titles != n_images:
            raise ValueError(f"Number of images ({n_images}) and titles ({n_titles}) do not match.")

    nb_plots = n_images
    nb_x_plots = int(np.ceil(np.sqrt(nb_plots)))
    nb_y_plots = int(np.ceil(nb_plots / nb_x_plots))

    # Plot
    # define a figure which can contains several plots, you can define resolution and so on here...
    fig, axarr = plt.subplots(nb_y_plots, nb_x_plots, sharex='all', sharey='all', figsize=(9., 7.))
    fig.set_layout_engine('constrained', compress=True)

    if nb_plots > 1:
        axarr = axarr.flatten()
    else:
        axarr = [axarr]

    zscale = interval.ZScaleInterval(n_samples=600, contrast=0.25, max_reject=0.5, min_npixels=5, krej=2.5,
                                     max_iterations=5)

    if vrange is not None:
        (vmin, vmax) = vrange
    else:
        mins = []
        maxs = []
        for image in images:
            (vmin, vmax) = zscale.get_limits(image)
            mins.append(vmin)
            maxs.append(vmax)

        vmin = np.min(mins)
        vmax = np.max(maxs)

    normalization = colors.Normalize(vmin=vmin, vmax=vmax)  # Linear

    for ax, image, title in zip(axarr, images, titles):
        cmap = ax.imshow(image, origin='lower', norm=normalization, cmap="viridis")
        ax.set_title(title)

    cbar = fig.colorbar(cmap, ax=fig.get_axes())

    return fig


def compare_values(filenames, extension, slice):
    """_summary_

    use_fsspec and lazy_load_hdus could improve read time for big files if needed

    :param _type_ filenames: _description_
    :param _type_ extension: _description_
    :param _type_ slice: _description_
    :return _type_: _description_
    """
    values = {}
    for path in filenames:
        with fits.open(path) as hdulist:
            data = hdulist[extension].section[slice]

        print(f"{os.path.basename(path)}: {data}")
        values[path] = data

    return values
