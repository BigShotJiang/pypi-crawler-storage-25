import glob
import os
import sys
import time

import numpy as np
from astropy.io import fits
from astropy.visualization import interval
from matplotlib import colors
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import \
    NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
from matplotlib.gridspec import GridSpec
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QHBoxLayout,
                               QLabel, QLineEdit, QMainWindow, QPushButton,
                               QSizePolicy, QSlider, QSplitter, QVBoxLayout,
                               QWidget)

from ..version import __version__


class InteractiveSuperRawQt(QMainWindow):
    def __init__(self, inputpath, xpos=0, ypos=0, grouppos=None):
        super().__init__()

        if os.path.isdir(inputpath):
            print(f"Warning: {inputpath} is a directory. Take first .fits in it as input.")
            inputpath = glob.glob(os.path.join(inputpath, '*.fits'))[0]

        if not os.path.isfile(inputpath):
            raise ValueError(f"{inputpath} is not a valid file.")

        self.setWindowTitle(f"Interactive Super Raw Viewer (v{__version__}): {inputpath}")
        self.setGeometry(100, 100, 1400, 800)

        # Load data
        t_start = time.time()
        with fits.open(inputpath) as hdulist:
            self.datacube = hdulist[1].data['IMG']

            house_keeping = {}
            for col_name in hdulist[1].columns.names:
                if col_name not in ('IMG', 'STATUS'):
                    house_keeping[col_name] = hdulist[1].data[col_name]

            # if BBM format, try to get RESET from STATUS
            if 'RESET' not in house_keeping:
                RESET_BIT = 70368744177664  # 2**46
                if 'STATUS' in hdulist[1].columns.names:
                    str_status = hdulist[1].data['STATUS']
                    int_status = np.array([int(value, 16) for value in str_status], dtype=np.uint64)
                    reset_value = (int_status & RESET_BIT).astype(bool).astype(int)
                    house_keeping['RESET'] = reset_value

            self.house_keeping = house_keeping

        print(f"Loaded data in {time.time() - t_start:.2f}s")

        self.hk_names = list(self.house_keeping.keys())
        self.hk_names.sort()

        self.ngroups, self.ny, self.nx = self.datacube.shape

        if grouppos is None:
            grouppos = self.ngroups - 1

        self.group_i = grouppos
        self.xi = xpos
        self.yi = ypos
        self.xmin = 0
        self.xmax = self.ngroups - 1

        # Default values
        # RESET is the most usefull default HK to display, but some old data do not have it, so prepare fallback just in case
        if 'RESET' in self.hk_names:
            self.hk_name = 'RESET'
        else:
            self.hk_name = 'IMGNUM'
        self.hk_values = self.house_keeping[self.hk_name]
        self.xdata = np.arange(self.ngroups)
        self.xlabel = 'Frame'

        # Create main widget and layout
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(main_widget)

        # Create splitter for plots
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left side: Image plot
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)

        # Init tool to get vrange
        zscale = interval.ZScaleInterval(n_samples=600, contrast=0.1, max_reject=0.5, min_npixels=5, krej=2.5,
                                         max_iterations=5)
        self.zscale = zscale

        fig_h = 4
        fig_w = fig_h * self.nx/self.ny

        self.fig_image = Figure(figsize=(fig_w, fig_h))
        self.fig_image.set_layout_engine('constrained', h_pad=0, w_pad=0)
        self.canvas_image = FigureCanvas(self.fig_image)
        self.toolbar_image = NavigationToolbar(self.canvas_image, self)

        # Left canvas: only take needed space, don't expand
        self.canvas_image.setSizePolicy(QSizePolicy.Policy.Minimum,
                                         QSizePolicy.Policy.Expanding)

        left_layout.addWidget(self.toolbar_image)
        left_layout.addWidget(self.canvas_image)

        self.ax_im = self.fig_image.add_subplot(111)

        # Right side: Ramp plot
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)

        self.fig_ramp = Figure(figsize=(8, 6))
        self.canvas_ramp = FigureCanvas(self.fig_ramp)
        self.toolbar_ramp = NavigationToolbar(self.canvas_ramp, self)

        # Right canvas: expand to fill all available space
        self.canvas_ramp.setSizePolicy(QSizePolicy.Policy.Expanding,
                                        QSizePolicy.Policy.Expanding)

        right_layout.addWidget(self.toolbar_ramp)
        right_layout.addWidget(self.canvas_ramp)

        self.ax_ramp = self.fig_ramp.add_subplot(111)

        splitter.addWidget(left_widget)
        splitter.addWidget(right_widget)

        main_layout.addWidget(splitter, stretch=1)

        # Control panel
        control_widget = QWidget()
        control_layout = QHBoxLayout(control_widget)

        # Group slider
        control_layout.addWidget(QLabel("Image: 0"))
        self.group_slider = QSlider(Qt.Orientation.Horizontal)
        self.group_slider.setMinimum(0)
        self.group_slider.setMaximum(self.ngroups - 1)
        self.group_slider.setValue(self.group_i)
        self.group_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.group_slider.setTickInterval(max(1, self.ngroups // 10))
        self.group_slider.valueChanged.connect(self.on_group_change)
        control_layout.addWidget(self.group_slider)

        self.group_label = QLabel(str(self.group_i))
        self.group_label.setMinimumWidth(50)
        control_layout.addWidget(self.group_label)

        control_layout.addSpacing(30)

        # X range inputs
        control_layout.addWidget(QLabel("Im min:"))
        self.xmin_input = QLineEdit(str(self.xmin))
        self.xmin_input.setMaximumWidth(80)
        self.xmin_input.returnPressed.connect(self.on_xrange_change)
        control_layout.addWidget(self.xmin_input)

        control_layout.addWidget(QLabel("Im max:"))
        self.xmax_input = QLineEdit(str(self.xmax))
        self.xmax_input.setMaximumWidth(80)
        self.xmax_input.returnPressed.connect(self.on_xrange_change)
        control_layout.addWidget(self.xmax_input)

        update_btn = QPushButton("Update Range")
        update_btn.clicked.connect(self.on_xrange_change)
        control_layout.addWidget(update_btn)

        control_layout.addSpacing(30)

        # Checkbox for extra axis
        # Extra axis (derivative) - initially None
        self.ax_hk = None
        self.hk_data = None
        self.show_house_keeping_cb = QCheckBox("Show HK")
        self.show_house_keeping_cb.stateChanged.connect(self.on_toggle_hk)
        self.show_house_keeping_cb.setChecked(True)
        control_layout.addWidget(self.show_house_keeping_cb)

        self.show_time_cb = QCheckBox("Show Time")
        self.show_time_cb.stateChanged.connect(self.on_toggle_time)
        control_layout.addWidget(self.show_time_cb)

        control_layout.addSpacing(30)

        # Dropdown menu for HK name selection
        control_layout.addWidget(QLabel("HK:"))
        self.hk_combo = QComboBox()
        self.hk_combo.addItems(self.hk_names)
        # Set default selection to current hk_name
        if self.hk_name in self.hk_names:
            self.hk_combo.setCurrentText(self.hk_name)
        self.hk_combo.currentTextChanged.connect(self.on_hk_name_change)
        control_layout.addWidget(self.hk_combo)

        control_layout.addSpacing(30)

        control_layout.addStretch()

        main_layout.addWidget(control_widget)

        # Connect click event on image
        self.canvas_image.mpl_connect('button_press_event', self.on_detector_click)
        self.canvas_ramp.mpl_connect('button_press_event', self.on_ramp_click)

        # Initial plots
        self.init_plots()

    def init_plots(self):
        """Initialize the plots."""
        self.xdata = np.arange(self.ngroups)
        vmin, vmax = self.zscale.get_limits(self.datacube[self.group_i])

        norm = colors.Normalize(vmin=vmin, vmax=vmax)  # Linear

        self.im = self.ax_im.imshow(
            self.datacube[self.group_i],
            origin='lower', norm=norm,
            cmap='viridis_r'
        )
        self.fig_image.colorbar(self.im, ax=self.ax_im)
        self.center, = self.ax_im.plot(
            self.xi, self.yi, '+',
            color='red', markersize=15, markeredgewidth=2
        )
        self.ax_im.set_title(f"Image: {self.group_i}")

        # Ramp plot
        ramp = self.datacube[:, self.yi, self.xi]
        self.ramp_line, = self.ax_ramp.plot(self.xdata, ramp, 'r-o', markersize=3)
        self.ax_ramp.set_xlabel("Image")
        self.ax_ramp.set_ylabel("Signal [DN]")
        self.ax_ramp.set_title(f"Pixel: (x, y) = ({self.xi}, {self.yi})")
        self.ax_ramp.grid(True, linestyle='--', alpha=0.7)

        # if self.ax_hk is not None:
        #     self.hk_line, = self.ax_hk.plot(self.xdata, self.hk_values, 'b-o', markersize=3)

        # self.fig_image.tight_layout()
        self.fig_ramp.tight_layout()

        self.update_ramp_range()

    def on_group_change(self, value):
        """Handle group slider change."""
        self.group_i = value

        data = self.datacube[self.group_i]
        self.im.set_data(data)

        vmin, vmax = self.zscale.get_limits(data)

        self.im.set_clim(vmin, vmax)
        self.ax_im.set_title(f"Image: {self.group_i}")

        self.canvas_image.draw_idle()

    def on_xrange_change(self):
        """Handle X range input change."""
        try:
            xmin = int(self.xmin_input.text())
            xmax = int(self.xmax_input.text())

            if 0 <= xmin < xmax <= self.ngroups:
                self.xmin = xmin
                self.xmax = xmax
                self.update_ramp_range()
        except ValueError:
            # Reset to current values if invalid
            self.xmin_input.setText(str(self.xmin))
            self.xmax_input.setText(str(self.xmax))

    def on_detector_click(self, event):
        """Handle click on image to select pixel."""
        if event.inaxes is None:
            return

        self.xi = int(round(event.xdata))
        self.yi = int(round(event.ydata))

        # Clamp to valid range
        self.xi = max(0, min(self.nx - 1, self.xi))
        self.yi = max(0, min(self.ny - 1, self.yi))

        # Update center marker
        self.center.set_data([self.xi], [self.yi])
        self.canvas_image.draw_idle()

        # Update ramp
        self.update_ramp()

    def on_ramp_click(self, event):
        """Handle click on image to select pixel."""
        if event.inaxes is None:
            return

        xi = int(round(event.xdata))
        group_i = int(round(xi))
        self.group_slider.setValue(group_i)

    def update_ramp(self):
        """Update the ramp plot for the selected pixel."""
        ramp = self.datacube[:, self.yi, self.xi]
        self.ramp_line.set_ydata(ramp)
        self.ax_ramp.set_title(f"Pixel: (x, y) = ({self.xi}, {self.yi})")

        self.update_ramp_range()

    def update_ramp_range(self):
        """Update the ramp plot x/y range."""
        ramp = self.ramp_line.get_ydata()
        ramp_slice = ramp[self.xmin:self.xmax + 1]

        if len(ramp_slice) > 0:
            ymin, ymax = np.nanmin(ramp_slice), np.nanmax(ramp_slice)
            padding = (ymax - ymin) * 0.05 if ymax != ymin else 1

            self.ax_ramp.set_xlim(self.xdata[self.xmin], self.xdata[self.xmax])
            self.ax_ramp.set_ylim(ymin - padding, ymax + padding)

        if self.ax_hk is not None:
            ramp = self.hk_line.get_ydata()
            ramp_slice = ramp[self.xmin:self.xmax + 1]

            if len(ramp_slice) > 0:
                ymin, ymax = np.nanmin(ramp_slice), np.nanmax(ramp_slice)
                padding = (ymax - ymin) * 0.05 if ymax != ymin else 1

                self.ax_hk.set_xlim(self.xdata[self.xmin], self.xdata[self.xmax])
                self.ax_hk.set_ylim(ymin - padding, ymax + padding)

        self.canvas_ramp.draw_idle()

    def on_toggle_hk(self, state):
        """Handle checkbox toggle for derivative axis."""
        if state:  # Checkbox is checked
            self.add_hk_axis()
        else:  # Checkbox is unchecked
            self.remove_hk_axis()

    def on_toggle_time(self, state):
        """Handle checkbox toggle for derivative axis."""
        if state:  # Checkbox is checked
            fine = self.house_keeping['FINE']
            coarse = self.house_keeping['COARSE']
            self.xdata = (coarse * 10000 + fine) * 100e-6
            self.xdata -= self.xdata[0]

            # self.xdata = np.arange(self.ngroups) / 100
            self.xlabel = 'Time [s]'

        else:  # Checkbox is unchecked
            self.xdata = np.arange(self.ngroups)
            self.xlabel = 'Image'

        self.ramp_line.set_xdata(self.xdata)
        self.ax_ramp.set_xlabel(self.xlabel)
        if self.ax_hk is not None:
            self.hk_line.set_xdata(self.xdata)
            self.ax_hk.set_xlabel(self.xlabel)

        self.update_ramp_range()



    def add_hk_axis(self):
        """Add derivative axis to the ramp figure."""
        if self.ax_hk is not None:
            return  # Already exists

        # Create a new GridSpec for 2 rows
        gs = GridSpec(2, 1, figure=self.fig_ramp)

        # Change ramp axis to take the top position
        self.ax_ramp.set_subplotspec(gs[0, 0])

        # Add derivative axis
        self.ax_hk = self.fig_ramp.add_subplot(gs[1, 0], sharex=self.ax_ramp)
        self.ax_hk.set_xlabel(self.xlabel)
        self.ax_hk.set_ylabel(self.hk_name)
        self.ax_hk.grid(True, linestyle='--', alpha=0.7)

        # Calculate and plot derivative
        self.hk_values = self.house_keeping[self.hk_name]
        self.hk_line, = self.ax_hk.plot(self.xdata, self.hk_values, 'b-o', markersize=3)

        self.fig_ramp.tight_layout()
        self.canvas_ramp.draw_idle()

    def remove_hk_axis(self):
        """Remove derivative axis from the ramp figure."""
        if self.ax_hk is None:
            return  # Doesn't exist

        # Remove the derivative axis
        self.fig_ramp.delaxes(self.ax_hk)
        self.ax_hk = None
        self.hk_values = None

        # Create a new GridSpec for 1 row and restore ramp axis to full size
        gs = GridSpec(1, 1, figure=self.fig_ramp)
        self.ax_ramp.set_subplotspec(gs[0, 0])

        self.fig_ramp.tight_layout()
        self.canvas_ramp.draw_idle()

    def on_hk_name_change(self, text):
        """Handle HK name dropdown change."""
        self.hk_name = text

        # If the derivative axis is visible, update it with the new HK data
        if self.ax_hk is not None:
            self.hk_values = self.house_keeping[self.hk_name]
            self.hk_line.set_ydata(self.hk_values)
            self.ax_hk.set_ylabel(self.hk_name)
            self.update_ramp_range()

def interactive_super_raw(inputpath, xpos=0, ypos=0, grouppos=None):
    """Launch the Qt-based interactive viewer."""
    app = QApplication(sys.argv)
    viewer = InteractiveSuperRawQt(inputpath, xpos, ypos, grouppos)
    viewer.show()
    sys.exit(app.exec())
