import matplotlib.pyplot as plt
import numpy as np
from astropy.visualization import interval
from matplotlib import colors


class PixelSelection:
    def __init__(self, image, exclude=None):

        fig, ax = plt.subplots()

        zscale = interval.ZScaleInterval(n_samples=600, contrast=0.25, max_reject=0.5, min_npixels=5, krej=2.5,
                                         max_iterations=5)
        (vmin, vmax) = zscale.get_limits(image)
        normalization = colors.Normalize(vmin=vmin, vmax=vmax)  # Linear

        cmap = ax.imshow(image, origin='lower', norm=normalization, cmap='Grays_r')

        cbar = fig.colorbar(cmap, ax=ax)

        if exclude is not None:
            ex_x, ex_y = zip(*exclude)
            ax.plot(ex_x, ex_y, 'rx', label='Excluded pixels')

        self.ax = ax
        self.figure = fig
        self.coords = []
        self.cid = ax.figure.canvas.mpl_connect('button_press_event', self)

    def __call__(self, event):

        # Ignore clicks outside axes
        if event.inaxes != self.ax:
            return


        # Access toolbar (backend-dependent but works for standard GUIs)
        toolbar = getattr(self.figure.canvas, "toolbar", None)

        # If mode is not "", it means some tool is active, in that case, ignore clicks
        # (in particular, when we zoom)
        if toolbar is not None and toolbar.mode != "":
            return

        # Only left-click
        if event.button != 1:
            return

        x = int(np.round(event.xdata))
        y = int(np.round(event.ydata))

        # Display clicks
        self.ax.plot(x, y, 'r+')
        self.ax.figure.canvas.draw()

        self.coords.append((x, y))
        print(f"Clicked pixel: (x,y) = ({x},{y})")

    def get_coords(self):

        unique_coords = list(set(self.coords))

        return unique_coords


def select_pixels(image, exclude=None):
    """
    Use the input image, and allow user to make a list of pixels of interest.

    :param _type_ image: _description_
    """
    pixel_selection = PixelSelection(image, exclude=exclude)

    plt.show()

    coords = pixel_selection.get_coords()
    print(f"Selected pixels: (x,y) {coords}")
