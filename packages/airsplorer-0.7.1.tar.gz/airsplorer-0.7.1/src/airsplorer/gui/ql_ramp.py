import os
import sys
import time

import numpy as np
from astropy.io import fits
from astropy.visualization import interval
from matplotlib import colors, ticker
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import \
    NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
from PySide6.QtCore import QEvent, QObject, Qt
from PySide6.QtWidgets import (QApplication, QComboBox, QHBoxLayout, QLabel,
                               QLineEdit, QMainWindow, QPushButton,
                               QSizePolicy, QSplitter, QVBoxLayout, QWidget)

from .. import constants
from .. import mask as mk
from ..version import __version__


class ArrowKeyFilter(QObject):
    """Event filter to handle arrow keys in input fields"""

    def __init__(self, parent_window):
        super().__init__()
        self.parent_window = parent_window

    def eventFilter(self, obj, event):
        # For some reason KeyPress event do not exist for Left and Right arrow key in some cases,
        # I assume that some focused widget capture them. Funny enough, keyPressEvent do not capture them when filterEvent does.
        if event.type() != QEvent.Type.KeyRelease:
            return False

        key = event.key()
        modifiers = event.modifiers()

        # Check for Ctrl key
        ctrl_pressed = modifiers & Qt.KeyboardModifier.ControlModifier

        # Ctrl must be pressed
        if not ctrl_pressed:
            return False

        dx, dy = (0, 0)
        if key == Qt.Key.Key_Up:
            dy = 1
        elif key == Qt.Key.Key_Down:
            dy = -1
        elif key == Qt.Key.Key_Left:
            dx = -1
        elif key == Qt.Key.Key_Right:
            dx = 1
        else:
            return False

        old_x = self.parent_window.xi
        new_x = old_x + dx
        new_x = max(0, new_x)
        new_x = min(self.parent_window.nx - 1, new_x)

        old_y = self.parent_window.yi
        new_y = old_y + dy
        new_y = max(0, new_y)
        new_y = min(self.parent_window.ny - 1, new_y)

        if (new_x != old_x) or (new_y != old_y):
            self.parent_window.input_pixel.setText(f"{new_x},{new_y}")
            self.parent_window.on_pixel_change()
        return True


class InteractiveRampQt(QMainWindow):
    neighbor_marker = {
    "n": "^",
    "s": "v",
    "e": ">",
    "w": "<",
    "se": "*",
    "sw": "D",
    "ne": "s",
    "nw": "P",
    }

    neigbor_shifts = [  # key, y, x
        ("n", 1, 0),
        ("s", -1, 0),
        ("e", 0, 1),
        ("w", 0, -1),
        ("se", -1, 1),
        ("sw", -1, -1),
        ("ne", 1, 1),
        ("nw", 1, -1),
    ]
    def __init__(self, inputpath, xpos=None, ypos=None, intpos=None, grouppos=None):
        super().__init__()

        if not os.path.isfile(inputpath):
            raise ValueError(f"{inputpath} is not a valid file.")

        # Load data
        t_start = time.time()
        hk_options = []
        with fits.open(inputpath) as hdulist:
            datacube = hdulist["SCI"].data

            if "GROUPDQ" in hdulist:
                groupdq = hdulist['GROUPDQ'].data
                hk_options.append('DQ')
            else:
                groupdq = None

            house_keeping = {}
            for col_name in hdulist['HK_TABLE'].columns.names:
                if col_name not in ('IMG', 'STATUS'):
                    house_keeping[col_name] = hdulist['HK_TABLE'].data[col_name]
                    hk_options.append(col_name)

            self.house_keeping = house_keeping
            self.hk_options = hk_options
        print(f"Loaded data in {time.time() - t_start:.2f}s")

        self.datacube = datacube
        self.dqcube = groupdq

        nints, ngroups, ny, nx = datacube.shape
        self.ny = ny
        self.nx = nx
        self.nints = nints
        self.ngroups = ngroups

        self.hk_option = self.hk_options[0]

        # configure event filter to capture arrow key press event (even from QlineEdit)
        self.event_filter = ArrowKeyFilter(self)
        self.installEventFilter(self.event_filter)

        # Do a given neighbor need to be displayed or not?
        self.active_neighbors = {key: False for key in self.neighbor_marker.keys()}

        # Init tool to get vrange
        zscale = interval.ZScaleInterval(n_samples=600, contrast=0.1, max_reject=0.5, min_npixels=5, krej=2.5,
                                         max_iterations=5)
        self.zscale = zscale

        self.setWindowTitle(f"Interactive Ramp Viewer  (v{__version__}): {inputpath}")
        self.setGeometry(100, 100, 1400, 1000)

        if intpos is None:
            # First non partial integration
            intpos = 1 if nints > 1 else 0
        if grouppos is None:
            grouppos = self.ngroups - 1
        if xpos is None:
            xpos = 0
        if ypos is None:
            ypos = 0

        self.int_i = intpos
        self.group_i = grouppos
        self.xi = xpos
        self.yi = ypos

        self.xmin = 0
        self.xmax = self.ngroups - 1

        self.xdata = np.arange(self.ngroups)
        self.xlabel = 'Frame'

        # Create main widget and layout
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(main_widget)

        # Create splitter for plots
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left side: Image plot
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)


        fig_h = 6
        fig_w = fig_h * self.nx/self.ny

        self.fig_image = Figure(figsize=(fig_w, fig_h))
        self.fig_image.set_layout_engine('constrained', h_pad=0, w_pad=0)
        self.canvas_image = FigureCanvas(self.fig_image)
        self.toolbar_image = NavigationToolbar(self.canvas_image, self)

        # Left canvas: only take needed space, don't expand
        self.canvas_image.setSizePolicy(QSizePolicy.Policy.Minimum,
                                         QSizePolicy.Policy.Expanding)

        left_layout.addWidget(self.toolbar_image)
        left_layout.addWidget(self.canvas_image)

        self.ax_im = self.fig_image.add_subplot(111)

        # Right side: Ramp plot
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)

        self.fig_ramp = Figure(figsize=(8, 6))
        self.fig_ramp.set_constrained_layout(True)
        self.canvas_ramp = FigureCanvas(self.fig_ramp)
        self.toolbar_ramp = NavigationToolbar(self.canvas_ramp, self)

        # Right canvas: expand to fill all available space
        self.canvas_ramp.setSizePolicy(QSizePolicy.Policy.Expanding,
                                        QSizePolicy.Policy.Expanding)

        right_layout.addWidget(self.toolbar_ramp)
        right_layout.addWidget(self.canvas_ramp)

        self.ax_ramp = self.fig_ramp.add_subplot(211)
        self.ax_hk = self.fig_ramp.add_subplot(212, sharex=self.ax_ramp)

        # Store ramp figure ranges for when we change pixel, integration or hk
        self.home_xrange = (0, self.ngroups-1)
        self.home_yrange_ramp = (None, None)
        self.home_yrange_hk = (None, None)
        self.zoom_xrange = self.home_xrange
        self.zoom_yrange_ramp = (None, None)
        self.zoom_yrange_hk = (None, None)

        splitter.addWidget(left_widget)
        splitter.addWidget(right_widget)

        main_layout.addWidget(splitter, stretch=1)

        # Control panel
        control_widget = QWidget()
        control_layout = QHBoxLayout(control_widget)


        control_layout.addSpacing(30)

        # X range inputs
        control_layout.addWidget(QLabel(f"Int [0-{self.nints-1}]:"))
        self.int_input = QLineEdit(str(self.int_i))
        self.int_input.setMaximumWidth(80)
        self.int_input.returnPressed.connect(self.on_int_change)
        control_layout.addWidget(self.int_input)

        control_layout.addWidget(QLabel(f"Group [0-{self.ngroups-1}]:"))
        self.group_input = QLineEdit(str(self.group_i))
        self.group_input.setMaximumWidth(80)
        self.group_input.returnPressed.connect(self.on_group_change)
        control_layout.addWidget(self.group_input)

        control_layout.addWidget(QLabel(f"(x,y) [0-{self.nx-1},0-{self.ny-1}]:"))
        self.input_pixel = QLineEdit(f"{self.xi},{self.yi}")
        self.input_pixel.setMaximumWidth(80)
        self.input_pixel.returnPressed.connect(self.on_pixel_change)
        control_layout.addWidget(self.input_pixel)


        control_layout.addSpacing(30)

        control_layout.addWidget(QLabel("HK:"))
        self.hk_combo = QComboBox()
        self.hk_combo.addItems(self.hk_options)
        # Set default selection to current hk_name
        self.hk_combo.setCurrentText(self.hk_option)
        self.hk_combo.currentTextChanged.connect(self.on_hk_option_change)
        control_layout.addWidget(self.hk_combo)

        # Dropdown menu for HK name selection
        control_layout.addWidget(QLabel("Neighbors:"))
        self.neighbors_options = ['None', '+', '-', '|', 'x', 'all']
        self.neighbors_combo = QComboBox()
        self.neighbors_combo.addItems(self.neighbors_options)
        self.neighbors_combo.setCurrentText(self.neighbors_options[0])
        self.neighbors_combo.currentTextChanged.connect(self.on_neighbor_change)
        control_layout.addWidget(self.neighbors_combo)
        #
        update_btn = QPushButton("Reset zoom")
        update_btn.clicked.connect(self.reset_zoom)
        control_layout.addWidget(update_btn)

        control_layout.addStretch()

        main_layout.addWidget(control_widget)

        # Connect click event on image
        self.canvas_image.mpl_connect('button_press_event', self.on_detector_click)
        self.canvas_ramp.mpl_connect('button_press_event', self.on_ramp_click)

        # Initial plots
        self.init_plots()
        self.update_ramp()


    def init_plots(self):
        """Initialize the plots."""
        self.xdata = np.arange(self.ngroups)
        image = self.datacube[self.int_i, self.group_i]
        vmin, vmax = self.zscale.get_limits(image[(image > 0) & (image < 65536)])

        norm = colors.Normalize(vmin=vmin, vmax=vmax)  # Linear

        self.im = self.ax_im.imshow(
            image,
            origin='lower', norm=norm,
            cmap='viridis'
        )
        self.fig_image.colorbar(self.im, ax=self.ax_im)
        self.center, = self.ax_im.plot(
            self.xi, self.yi, '+',
            color='red', markersize=15, markeredgewidth=2
        )

        self.neighbor_center = {}
        for key, marker in self.neighbor_marker.items():
            self.neighbor_center[key], = self.ax_im.plot(self.xi, self.yi, marker, color="black")

        self.ax_im.set_title(f"Int: {self.int_i} ; Group: {self.group_i}")

        # Ramp plot
        ramp = self.datacube[self.int_i, :, self.yi, self.xi]
        self.ramp_line, = self.ax_ramp.plot(self.xdata, ramp, 'r-o', markersize=3, label="Selected pixel")

        # Set default value for home yrange (will be changed later)
        self.home_yrange_ramp = (np.nanmin(ramp), np.nanmax(ramp))

        # Draw neigbors integrations Identified by position (n=North, ne= North-East, etc...)
        # For now, just placeholders we can update later
        self.neighbor_lines = {}
        for key, marker in self.neighbor_marker.items():
            self.neighbor_lines[key], = self.ax_ramp.plot(self.datacube[self.int_i, :, self.yi, self.xi], ":", label=key, marker=marker)

        self.ax_ramp.legend()

        self.ax_ramp.set_xlabel("Group")
        self.ax_ramp.set_ylabel("Signal [DN]")
        self.ax_ramp.set_title(f"Pixel: (x, y) = ({self.xi}, {self.yi})")
        self.ax_ramp.grid(True, linestyle='--', alpha=0.7)

        if self.hk_option == 'DQ':
            self._init_dq_axis()
        else:
            self._init_hk_axis()

        # Force xlim or else I have issues with wrong values
        self.ax_hk.set_xlim(self.home_xrange)

    def _init_dq_axis(self):
        # Clear previous axis definition without creating from scratch to avoid messing with layout
        self.ax_hk.clear()

        # other variables for other HK options are set to None
        self.hk_values = None
        self.hk_line = None
        self.dq_im = None

        cmap = colors.ListedColormap(["white", "#1f77b4"])
        self.dq_im = self.ax_hk.imshow(np.zeros((32, self.ngroups)), aspect="auto",
                                       cmap=cmap, vmin=0, vmax=1, origin="lower")
        # self.ax_dq.set_yticks(range(32))

        dq_ticks = [""] * 32
        for key, value in constants.pixel_flags.items():
            dq_ticks[value.bit_length() - 1] = key

        # Put ticks at integer positions and map to labels
        self.ax_hk.yaxis.set_major_locator(ticker.FixedLocator(range(32)))
        self.ax_hk.yaxis.set_major_formatter(
            ticker.FuncFormatter(lambda v, pos: dq_ticks[int(np.round(v))] if -0.5 <= v < 31.5 else ""))

        # self.ax_dq.set_yticklabels(dq_ticks)
        self.ax_hk.set_xlabel("group")
        self.ax_hk.set_title("Active flags per x (1 = colored)")

        # Optional: gridlines for readability
        for j in range(32 + 1):
            self.ax_hk.axhline(j - 0.5, color="#ddd", lw=0.5, zorder=0)

        self.dq_im.set_clim(0, 1)
        self.home_yrange_hk = (-0.5, 31.5)
        self.zoom_yrange_hk = self.home_yrange_hk

    def _init_hk_axis(self):
        """
        Init Hk axis.

        Do not define yrange here, since it depends on what HK is currently displayed
        """
        # Delete previous HK axis if it exists
        self.ax_hk.clear()

        # other variables for other HK options are set to None
        self.hk_values = None
        self.hk_line = None
        self.dq_im = None

        # Add derivative axis
        self.ax_hk.set_xlabel('group')
        self.ax_hk.set_ylabel('Nothing')
        self.ax_hk.grid(True, linestyle='--', alpha=0.7)

        # Calculate and plot derivative
        self.hk_line, = self.ax_hk.plot(self.xdata, np.zeros_like(self.xdata), 'b-o', markersize=3)

    def on_group_change(self):
        """Handle group slider change."""
        old_group_i = self.group_i
        self.group_i = int(self.group_input.text())

        # Only update image if group_i changed
        if old_group_i != self.group_i:
            self.update_image()

    def on_int_change(self):
        """Handle group slider change."""

        old_int_i = self.int_i
        self.int_i = int(self.int_input.text())

        # Only update image and integration if int_i changed
        if old_int_i != self.int_i:
            self.update_ramp()

            self.update_image()

    def on_pixel_change(self):
        """
        Handle pixel position change
        """
        old_text = f"{self.xi},{self.yi}"
        text = self.input_pixel.text()
        try:
            x_text,y_text = text.split(',')
            xi = int(x_text)
            yi = int(y_text)
        except:
            self.input_pixel.setText(old_text)
            return
        self.update_pixel(xi, yi)


    def update_image(self):
        """
        Update detector image displayed
        """
        data = self.datacube[self.int_i, self.group_i]
        self.im.set_data(data)

        vmin, vmax = self.zscale.get_limits(data[(data > 0) & (data < 65536)])

        self.im.set_clim(vmin, vmax)
        self.ax_im.set_title(f"Int: {self.int_i} ; Group: {self.group_i}")

        self.canvas_image.draw_idle()


    def on_detector_click(self, event):
        """Handle click on image to select pixel."""
        if event.inaxes != self.ax_im:
            return

        xi = int(round(event.xdata))
        yi = int(round(event.ydata))

        self.input_pixel.setText(f"{xi},{yi}")

        self.update_pixel(xi, yi)

    def update_pixel(self, xi, yi):
        # Clamp to valid range
        xi = max(0, min(self.nx - 1, xi))
        yi = max(0, min(self.ny - 1, yi))

        old_xi = self.xi
        old_yi = self.yi

        is_changed = (old_xi != xi) or (old_yi != yi)
        if is_changed:
            self.xi = xi
            self.yi = yi

            # Update center marker
            self.center.set_data([self.xi], [self.yi])
            self.canvas_image.draw_idle()

            # Update ramp
            # Only update hk if it's GROUPDQ, because other HK are valid for the whole detector
            if self.hk_option == 'DQ':
                update_hk = True
            else:
                update_hk = False
            self.update_ramp(update_hk=update_hk)

    def on_ramp_click(self, event):
        """Handle click on image to select pixel."""
        if event.inaxes is None:
            return

        xi = int(round(event.xdata))
        self.group_input.setText(str(xi))
        self.on_group_change()

    def _update_neigbors_int(self):
        # Prepare range values to ensure main + neighbors all fit in the axis range
        xmin, xmax = self.zoom_xrange
        xmin = int(np.ceil(xmin))
        xmax = int(xmax)
        xslice = slice(xmin, xmax+1)
        home_ymin = [self.home_yrange_ramp[0]]
        home_ymax = [self.home_yrange_ramp[1]]
        zoom_ymin = [self.zoom_yrange_ramp[0]]
        zoom_ymax = [self.zoom_yrange_ramp[1]]
        for key, dy, dx in self.neigbor_shifts:

            is_active = self.active_neighbors[key]

            nyi = self.yi + dy
            nxi = self.xi + dx

            outside_boundaries = (nyi < 0) or (nyi >= self.ny) or (nxi < 0) or (nxi >= self.nx)

            if outside_boundaries or not is_active:
                self.neighbor_lines[key].set_visible(False)
                self.neighbor_lines[key].set_label("_hidden")

                self.neighbor_center[key].set_visible(False)
                self.neighbor_center[key].set_label("_hidden")
            else:
                # Set visibility again for neigbor
                if not self.neighbor_lines[key].get_visible():
                    self.neighbor_lines[key].set_visible(True)
                    self.neighbor_lines[key].set_label(key)

                    self.neighbor_center[key].set_visible(True)

                # Update integration
                data = self.datacube[self.int_i, :, nyi, nxi]
                home_ymin.append(np.nanmin(data))
                home_ymax.append(np.nanmax(data))
                zoom_ymin.append(np.nanmin(data[xslice]))
                zoom_ymax.append(np.nanmax(data[xslice]))

                self.neighbor_lines[key].set_ydata(data)

                # Update neighbor position in image
                self.neighbor_center[key].set_data([nxi], [nyi])

        home_ymin = np.nanmin(home_ymin)
        home_ymax = np.nanmax(home_ymax)
        zoom_ymin = np.nanmin(zoom_ymin)
        zoom_ymax = np.nanmax(zoom_ymax)

        # Update ramp range with neighbor data, in addition to the selected pixel that was just called before.
        self.home_yrange_ramp = (home_ymin, home_ymax)
        self.zoom_yrange_ramp = (zoom_ymin, zoom_ymax)


    def update_ramp(self, update_hk=True):
        """Update the ramp plot for the selected pixel."""

        xmin, xmax = self.ax_ramp.get_xlim()

        # Update zoom xrange so the yrange can be computed accordingly
        self.zoom_xrange = (xmin, xmax)

        # Define ydata slice that correspond to the zoomed range
        xmin = int(np.ceil(xmin))
        xmax = int(xmax)
        xslice = slice(xmin, xmax+1)

        ramp = self.datacube[self.int_i, :, self.yi, self.xi]
        self.ramp_line.set_ydata(ramp)

        # Update yrange for main ramp
        self.home_yrange_ramp = (np.nanmin(ramp), np.nanmax(ramp))
        self.zoom_yrange_ramp = (np.nanmin(ramp[xslice]), np.nanmax(ramp[xslice]))

        # yrange is updated in it, based on the new reference set above and any visible neighbors
        self._update_neigbors_int()

        self.ax_ramp.set_title(f"Int: {self.int_i} ; Pixel: (x, y) = ({self.xi}, {self.yi})")

        self.ax_ramp.legend()

        if update_hk:
            self.update_hk()

        # Define home value for ramp_figure
        self._set_home_silently()

        # restore zoom
        self._restore_zoom()

        self.canvas_ramp.draw_idle()


    def _set_home_silently(self):
        """
        After internal change, set the new home value for the ramp figure based on internal
         parameters that have been updated.

        variable needed are:
        self.home_xrange
        self.home_yrange_ramp
        self.home_yrange_hk
        """
        # Do nothing if no home exist
        if len(self.toolbar_ramp._nav_stack) == 0:
            return

        # Get the state definition of the home configuration
        # navstack elements are a snapshot of plot configuration.
        # Each element is a tuple (dict, tuple(BBox, BBox)),
        # we just change the xlim/ylim in the dictionary for each axis
        home_ref = self.toolbar_ramp._nav_stack._elements[0]

        # Hack to get the corresponding key to each axis
        keys = list(home_ref.keys())
        ramp_key = keys[0]
        hk_key = keys[1]

        # Manual update of home ramp x and y range
        home_ref[ramp_key][0]['xlim'] = self.home_xrange
        home_ref[ramp_key][0]['ylim'] = self.home_yrange_ramp

        # Manual update of home hk x and y range
        home_ref[hk_key][0]['xlim'] = self.home_xrange
        home_ref[hk_key][0]['ylim'] = self.home_yrange_hk


    def _restore_zoom(self):
        """
        After internal change, set the new home value for the ramp figure based on internal
         parameters that have been updated.

        variable needed are:
        self.zoom_xrange
        self.zoom_yrange_ramp
        self.zoom_yrange_hk
        """
        self.ax_ramp.set_xlim(*self.zoom_xrange)
        self.ax_ramp.set_ylim(*self.zoom_yrange_ramp)
        self.ax_hk.set_ylim(*self.zoom_yrange_hk)
        self.toolbar_ramp.push_current()


    def reset_zoom(self):
        """
        Set current zoom to home values
        """
        self.ax_ramp.set_xlim(*self.home_xrange)
        self.ax_ramp.set_ylim(*self.home_yrange_ramp)
        self.ax_hk.set_ylim(*self.home_yrange_hk)
        self.toolbar_ramp.update()
        self.toolbar_ramp.push_current()

        self.canvas_ramp.draw_idle()

    def on_neighbor_change(self, neighbor_option):
        """Apply option change for neigbor configuration"""

        # Set which keys are active depending on the option
        if neighbor_option == "x":
            true_keys = ["ne", "se", "sw", "nw"]
        elif neighbor_option == "-":
            true_keys = ["w", "e"]
        elif neighbor_option == "|":
            true_keys = ["n", "s"]
        elif neighbor_option == "+":
            true_keys = ["e", "s", "w", "n"]
        elif neighbor_option == "all":
            true_keys = ["n", "ne", "e", "se", "s", "sw", "w", "nw"]
        else:
            true_keys = []

        for key in self.active_neighbors.keys():
            if key in true_keys:
                self.active_neighbors[key] = True
            else:
                self.active_neighbors[key] = False

        # Update clear the zoom history.
        self.toolbar_ramp.update()
        self.toolbar_ramp.push_current()  # Add one element so we can define the home in it.

        self.update_ramp(update_hk=False)

        # Force update of changes applied to neighbors arrows
        self.canvas_image.draw_idle()

    def update_hk(self):

        if self.hk_option == 'DQ':
            dq_int = self.dqcube[self.int_i, :, self.yi, self.xi]
            dq_image = mk.get_separated_dq_array(dq_int)
            self.dq_im.set_data(dq_image.T)

        else:
            self.ax_hk.set_ylabel(self.hk_option)

            index_start = self.int_i * self.ngroups
            index_stop = index_start + self.ngroups

            hk_values = self.house_keeping[self.hk_option][index_start:index_stop]
            self.hk_line.set_ydata(hk_values)

            # Update home range
            ymin = np.nanmin(hk_values)
            ymax = np.nanmax(hk_values)
            padding = (ymax - ymin) * 0.05 if ymax != ymin else 1

            self.home_yrange_hk = (ymin - padding, ymax + padding)

            # Update zoom range definition
            xmin, xmax = self.zoom_xrange
            xslice = slice(int(np.ceil(xmin)), int(xmax) + 1)

            zoom_data = hk_values[xslice]
            ymin = np.nanmin(zoom_data)
            ymax = np.nanmax(zoom_data)
            padding = (ymax - ymin) * 0.05 if ymax != ymin else 1
            self.zoom_yrange_hk = (ymin - padding, ymax + padding)


    def on_hk_option_change(self, text):
        """Handle HK name dropdown change."""
        old_hk_option = self.hk_option

        # Do nothing
        if old_hk_option == text:
            return

        # Option changed, so we update what's necessary
        self.hk_option = text

        # DQ and regular HK do not have the same type of axis, so extra changes are needed
        if old_hk_option == 'DQ' or text == 'DQ':
            if self.hk_option == 'DQ':
                self._init_dq_axis()
            else:
                self._init_hk_axis()

            # Reset tight layout and zoom reference because BBox can change
            # self.fig_ramp.tight_layout()
            self.toolbar_ramp.update()
            self.toolbar_ramp.push_current()

        # Update hk data
        self._save_zoom_state()
        self.update_hk()

        # Define home value for ramp_figure
        self._set_home_silently()

        # restore zoom
        self._restore_zoom()

        self.canvas_ramp.draw_idle()

    def _save_zoom_state(self):
        """
        For ramp and hk axis, save the current zoom state to be restored later.
        """
        self.zoom_xrange = self.ax_ramp.get_xlim()
        self.zoom_yrange_ramp = self.ax_ramp.get_ylim()
        self.zoom_yrange_hk = self.ax_hk.get_ylim()


def interactive_ramp(inputpath, xpos=0, ypos=0, grouppos=None):
    """Launch the Qt-based interactive viewer."""
    app = QApplication(sys.argv)
    viewer = InteractiveRampQt(inputpath, xpos, ypos, grouppos)
    viewer.show()
    sys.exit(app.exec())
