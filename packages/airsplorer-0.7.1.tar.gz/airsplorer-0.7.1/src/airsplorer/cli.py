"""
Command line interfaces of AIRSPlorer
"""
import argparse
import os
import sys

from astropy.io import fits


def airsql():
    """
    AIRS Quick Look for bin2fits or ramp/uncal fits files.
    """
    # Create argument parser to track and handle command line arguments.
    parser = argparse.ArgumentParser(
        description=f"Launch AIRS Quick Look for .fits files"
    f"\n\nExample:\n> airsql filename_ramp.fits", formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('file', type=str,
                        help='relative or absolute path to a .fits file (bin2fits, ramp or uncal')
    known = parser.parse_args()

    # Verify path file exists.
    filepath = known.file

    if not filepath.endswith('.fits'):
        print(f"Input file is not a .fits file: {filepath}")
        parser.print_help()

    if not os.path.exists(filepath):
        print(f"Fits file not found: '{filepath}'")
        parser.print_help()

    # Get fits header to infer fits type
    header = fits.getheader(filepath, ext=1)
    filetype = "Unknown"

    naxis = header['NAXIS']
    extension_type = header['XTENSION']

    if extension_type == "BINTABLE":
        filetype = "bin2fits"
    elif naxis == 4:
        filetype = "ramp"
    else:
        msg = f"Unsupported .fits type (probably rate or rateints). Only bin2fits and ramp files are supported"
        sys.exit(msg)

    if filetype == "ramp":
        from airsplorer.gui import ql_ramp
        ql_ramp.interactive_ramp(filepath)
    elif filetype == "bin2fits":
        from airsplorer.gui import ql_super_raw
        ql_super_raw.interactive_super_raw(filepath)
    else:
        print(f"Unknown filetype: {filetype} (probably an airsplorer bug)")
