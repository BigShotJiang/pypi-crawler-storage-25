"""QA evaluation framework."""
