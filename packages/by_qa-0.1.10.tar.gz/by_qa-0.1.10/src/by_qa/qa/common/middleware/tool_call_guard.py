"""ToolCallGuardMiddleware: intercepts invalid tool calls and runtime exceptions."""

from __future__ import annotations

import json
from typing import Any, Callable

from langchain.agents.middleware import AgentMiddleware, ToolCallRequest
from langchain_core.messages import ToolMessage
from langchain_core.tools.base import InjectedToolArg
from pydantic import ValidationError

from by_qa.core.logger import error, warning


def _strip_injected_fields(schema: type) -> type:
    """Return a schema variant that makes runtime-injected fields optional with defaults.

    LangGraph injects fields like InjectedState and InjectedToolCallId at runtime;
    they never appear in the LLM's tool call args.  We override them to ``Any = None``
    so Pydantic won't report them as missing, while preserving all field_validators
    defined on the original schema.
    """
    injected: set[str] = set()
    for name, fi in schema.model_fields.items():
        if any(
            isinstance(m, InjectedToolArg)
            or (isinstance(m, type) and issubclass(m, InjectedToolArg))
            for m in fi.metadata
        ):
            injected.add(name)
    if not injected:
        return schema
    ns: dict[str, Any] = {"__annotations__": {}}
    for name in injected:
        ns["__annotations__"][name] = Any
        ns[name] = None
    return type(schema.__name__, (schema,), ns)


def _validate_args(tool: Any, args: dict[str, Any]) -> ValidationError | None:
    # Prefer args_schema over tool_call_schema: LangChain rebuilds tool_call_schema
    # as a flat BaseModel subclass that drops field_validators defined on the original
    # schema, so coercion (e.g. JSON-string → list) would be silently skipped.
    schema = getattr(tool, "args_schema", None) or getattr(
        tool, "tool_call_schema", None
    )
    if schema is None:
        return None
    schema = _strip_injected_fields(schema)
    try:
        schema.model_validate(args)
    except ValidationError as exc:
        return exc
    return None


def _error_message(
    *,
    error_type: str,
    tool_name: str,
    message: str,
    details: dict[str, Any],
    tool_call_id: str,
) -> ToolMessage:
    content = json.dumps(
        {
            "error": True,
            "error_type": error_type,
            "tool_name": tool_name,
            "message": message,
            "details": details,
        },
        ensure_ascii=False,
    )
    return ToolMessage(content=content, name=tool_name, tool_call_id=tool_call_id)


class ToolCallGuardMiddleware(AgentMiddleware):
    """First-in-chain middleware that converts tool call failures into structured ToolMessage errors."""

    async def awrap_tool_call(self, request: ToolCallRequest, handler: Callable) -> Any:
        tool_name: str = request.tool_call["name"]
        tool_call_id: str = request.tool_call["id"]

        if request.tool is None:
            warning(
                "[tool_call_guard] InvalidToolName: tool='%s' tool_call_id='%s'",
                tool_name,
                tool_call_id,
            )
            return _error_message(
                error_type="InvalidToolName",
                tool_name=tool_name,
                message=f"Tool '{tool_name}' is not registered.",
                details={"available_tools": []},
                tool_call_id=tool_call_id,
            )

        val_error = _validate_args(request.tool, request.tool_call.get("args", {}))
        if val_error is not None:
            warning(
                "[tool_call_guard] InvalidToolArgs: tool='%s' tool_call_id='%s' errors=%s",
                tool_name,
                tool_call_id,
                val_error.errors(),
            )
            return _error_message(
                error_type="InvalidToolArgs",
                tool_name=tool_name,
                message="Tool argument validation failed.",
                details={"validation_errors": val_error.errors()},
                tool_call_id=tool_call_id,
            )

        try:
            return await handler(request)
        except Exception as exc:  # noqa: BLE001
            error(
                "[tool_call_guard] ToolExecutionError: tool='%s' tool_call_id='%s' exc=%s",
                tool_name,
                tool_call_id,
                exc,
            )
            return _error_message(
                error_type="ToolExecutionError",
                tool_name=tool_name,
                message=str(exc),
                details={"exception_type": type(exc).__name__},
                tool_call_id=tool_call_id,
            )


__all__ = ["ToolCallGuardMiddleware"]
