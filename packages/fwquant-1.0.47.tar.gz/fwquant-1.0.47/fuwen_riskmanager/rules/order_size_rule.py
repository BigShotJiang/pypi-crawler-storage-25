from fuwen_adaptor.trader.object import OrderRequest, ContractData

from ..template import RuleTemplate
from fuwen_frame.公共库.语言 import _


class OrderSizeRule(RuleTemplate):
    """委托规模检查风控规则"""

    name: str = _("委托规模检查")

    parameters: dict[str, str] = {
        "order_volume_limit": _("委托数量上限"),
        "order_value_limit": _("委托价值上限"),
    }

    def on_init(self) -> None:
        """初始化"""
        self.order_volume_limit: int = 500
        self.order_value_limit: float = 1_000_000

    def check_allowed(self, req: OrderRequest, gateway_name: str) -> bool:
        """检查是否允许委托"""
        if req.volume > self.order_volume_limit:
            self.write_log(f"{_('委托数量')} {req.volume} {_('超过上限')} {self.order_volume_limit}：{req}")
            return False

        contract: ContractData | None = self.get_contract(req.fw_symbol)
        if contract and req.price:      # 只考虑限价单
            order_value: float = req.volume * req.price * contract.size
            if order_value > self.order_value_limit:
                self.write_log(f"{_('委托价值')} {order_value} {_('超过上限')} {self.order_value_limit}：{req}")
                return False

        return True
