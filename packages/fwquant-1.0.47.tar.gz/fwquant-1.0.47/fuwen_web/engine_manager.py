import os
import sys
import importlib
import json
import time
import traceback
from typing import Dict, Any, List

from fuwen_config import 常量

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

CONFIG_DIR = 常量.福纹配置目录
os.makedirs(CONFIG_DIR, exist_ok=True)


class EngineManager:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
            cls._instance.event_engine = None
            cls._instance.main_engine = None
            cls._instance.available_gateways = {}
            cls._instance.available_apps = {}
        return cls._instance

    def initialize(self):
        if self._initialized:
            return {"success": True, "msg": "Engine already initialized"}

        try:
            from fuwen_adaptor.event import EventEngine
            from fuwen_frame.gateway.fw_adaptor.trader.engine import fw_MainEngine

            self.event_engine = EventEngine()
            self.main_engine = fw_MainEngine(self.event_engine)

            self.available_gateways = {
                "OKX": {
                    "module": "fuwen_frame.gateway.fw_okx.OkxGateway",
                    "class_name": "fw_OkxGateway",
                    "status": "disconnected",
                    "config": {}
                }
            }

            self.available_apps = {
                "CtaStrategy": {"module": "fuwen_ctastrategy", "class": "CtaStrategyApp", "status": "stopped",
                                "instance": None},
                "SingleBacktester": {"module": "fuwen_backtest_single", "class": "SingleBacktesterApp",
                                     "status": "stopped", "instance": None},
                "DataManager": {"module": "fuwen_datamanager", "class": "DataManagerApp", "status": "stopped",
                                "instance": None},
                "RiskManager": {"module": "fuwen_riskmanager", "class": "RiskManagerApp", "status": "stopped",
                                "instance": None}
            }

            self._initialized = True
            return {"success": True, "msg": "Engine initialized successfully"}
        except Exception as e:
            return {"success": False, "msg": str(e), "traceback": traceback.format_exc()}

    def get_status(self) -> Dict[str, Any]:
        if not self._initialized:
            return {
                "initialized": False,
                "main_engine": "stopped",
                "gateways": {},
                "apps": {}
            }

        gateways_info = {}
        for name, info in self.available_gateways.items():
            gateways_info[name] = {
                "status": info["status"],
                "config": {}
            }

        apps_info = {}
        for name, info in self.available_apps.items():
            apps_info[name] = {
                "status": info["status"]
            }

        return {
            "initialized": True,
            "main_engine": "running" if self.main_engine else "stopped",
            "gateways": gateways_info,
            "apps": apps_info
        }

    def get_gateways_info(self) -> Dict[str, Any]:
        gateways_info = {}
        for name, info in self.available_gateways.items():
            gateways_info[name] = {
                "status": info["status"]
            }
        return gateways_info

    def _load_gateway_config(self, gateway_name: str) -> Dict[str, Any]:
        config_path = os.path.join(CONFIG_DIR, f"connect_{gateway_name.lower()}.json")
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                return json.load(f)
        return {}

    def _save_gateway_config(self, gateway_name: str, config: Dict[str, Any]):
        config_path = os.path.join(CONFIG_DIR, f"connect_{gateway_name.lower()}.json")
        if not os.path.exists(config_path):
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=4)

    def add_gateway(self, gateway_name: str) -> Dict[str, Any]:
        if not self._initialized:
            return {"success": False, "msg": "Engine not initialized. Please call initialize() first."}

        if gateway_name not in self.available_gateways:
            return {"success": False, "msg": f"Gateway {gateway_name} not available"}

        gw_info = self.available_gateways[gateway_name]

        try:
            module = importlib.import_module(gw_info["module"])
            gw_class = getattr(module, gw_info["class_name"])
            self.main_engine.add_gateway(gateway_class=gw_class, gateway_name=gateway_name)
            gw_info["status"] = "added"
            return {"success": True, "msg": f"Gateway {gateway_name} added successfully"}
        except Exception as e:
            return {"success": False, "msg": str(e)}

    def connect_gateway(self, gateway_name: str, config: Dict[str, Any]) -> Dict[str, Any]:
        if not self._initialized:
            return {"success": False, "msg": "Engine not initialized. Please call initialize() first."}

        if gateway_name not in self.available_gateways:
            return {"success": False, "msg": f"Gateway {gateway_name} not available"}

        gw_info = self.available_gateways[gateway_name]

        try:
            self._save_gateway_config(gateway_name, config)

            gateway = self.main_engine.get_gateway(gateway_name)
            if not gateway:
                module = importlib.import_module(gw_info["module"])
                gw_class = getattr(module, gw_info["class_name"])
                self.main_engine.add_gateway(gateway_class=gw_class, gateway_name=gateway_name)
                gateway = self.main_engine.get_gateway(gateway_name)

            if gateway:
                try:
                    gateway.connect(config)

                    time.sleep(4)

                    auth_failed = False
                    auth_error_msg = ""

                    if hasattr(gateway, 'rest_api'):
                        if hasattr(gateway.rest_api, 'active') and not gateway.rest_api.active:
                            auth_failed = True
                            auth_error_msg = "REST API未激活"

                    if hasattr(gateway, '_error_message') and gateway._error_message:
                        auth_failed = True
                        auth_error_msg = gateway._error_message

                    if hasattr(gateway, 'private_api'):
                        if hasattr(gateway.private_api, 'connected') and not gateway.private_api.connected:
                            auth_failed = True
                            auth_error_msg = "Private API未连接"

                        if hasattr(gateway.private_api, '_error_message') and gateway.private_api._error_message:
                            error_msg = gateway.private_api._error_message
                            if '60024' in error_msg or 'Wrong passphrase' in error_msg or 'passphrase' in error_msg.lower():
                                auth_failed = True
                                auth_error_msg = "Passphrase错误"
                            else:
                                auth_failed = True
                                auth_error_msg = error_msg

                    if auth_failed:
                        gw_info["status"] = "disconnected"
                        return {"success": False, "msg": f"❌ 网关 {gateway_name} 连接失败: {auth_error_msg}"}

                    gw_info["status"] = "connected"
                    return {"success": True, "msg": f"✅ 网关 {gateway_name} 连接成功"}
                except Exception as conn_e:
                    gw_info["status"] = "disconnected"
                    error_message = str(conn_e)
                    if 'Invalid API Key' in error_message or 'Invalid signature' in error_message or 'Invalid passphrase' in error_message or '401' in error_message or 'authentication' in error_message.lower() or '60024' in error_message:
                        return {"success": False, "msg": f"❌ 网关 {gateway_name} 连接失败: API密钥验证失败"}
                    return {"success": False, "msg": f"❌ 网关 {gateway_name} 连接失败: {error_message}"}
            else:
                gw_info["status"] = "disconnected"
                return {"success": False, "msg": f"❌ 网关 {gateway_name} 未找到"}
        except Exception as e:
            gw_info["status"] = "disconnected"
            return {"success": False, "msg": f"❌ 连接网关失败: {str(e)}"}

    def disconnect_gateway(self, gateway_name: str) -> Dict[str, Any]:
        if not self._initialized:
            return {"success": False, "msg": "Engine not initialized. Please call initialize() first."}

        if gateway_name not in self.available_gateways:
            return {"success": False, "msg": f"Gateway {gateway_name} not available"}

        gw_info = self.available_gateways[gateway_name]

        try:
            gateway = self.main_engine.get_gateway(gateway_name)
            if gateway and hasattr(gateway, 'close'):
                gateway.close()
            gw_info["status"] = "disconnected"
            return {"success": True, "msg": f"Gateway {gateway_name} disconnected successfully"}
        except Exception as e:
            return {"success": False, "msg": str(e)}

    def get_apps_info(self) -> Dict[str, Any]:
        apps_info = {}
        for name, info in self.available_apps.items():
            apps_info[name] = {
                "status": info["status"]
            }
        return apps_info

    def start_app(self, app_name: str) -> Dict[str, Any]:
        if not self._initialized:
            return {"success": False, "msg": "Engine not initialized. Please call initialize() first."}

        if app_name not in self.available_apps:
            return {"success": False, "msg": f"App {app_name} not available"}

        app_info = self.available_apps[app_name]
        if app_info["status"] == "running":
            return {"success": False, "msg": f"App {app_name} is already running"}

        try:
            module = importlib.import_module(app_info["module"])
            app_class = getattr(module, app_info["class"])
            app_instance = app_class()

            if hasattr(app_instance, 'init_engine'):
                app_instance.init_engine(self.main_engine)
            elif hasattr(app_instance, 'start'):
                app_instance.start111223()
            elif hasattr(self.main_engine, 'add_app'):
                self.main_engine.add_app(app_instance)

            app_info["instance"] = app_instance
            app_info["status"] = "running"
            return {"success": True, "msg": f"App {app_name} started successfully"}
        except Exception as e:
            return {"success": False, "msg": str(e)}

    def stop_app(self, app_name: str) -> Dict[str, Any]:
        if not self._initialized:
            return {"success": False, "msg": "Engine not initialized. Please call initialize() first."}

        if app_name not in self.available_apps:
            return {"success": False, "msg": f"App {app_name} not available"}

        app_info = self.available_apps[app_name]
        if app_info["status"] != "running":
            return {"success": False, "msg": f"App {app_name} is not running"}

        try:
            if app_info["instance"] and hasattr(app_info["instance"], 'stop'):
                app_info["instance"].stop()
            app_info["status"] = "stopped"
            return {"success": True, "msg": f"App {app_name} stopped successfully"}
        except Exception as e:
            return {"success": False, "msg": str(e)}

    def get_accounts(self) -> List[Dict[str, Any]]:
        if not self._initialized:
            return []

        try:
            accounts = []
            for gateway_name in self.available_gateways:
                gateway = self.main_engine.get_gateway(gateway_name)
                if gateway and hasattr(gateway, 'get_accounts'):
                    try:
                        gateway_accounts = gateway.get_accounts()
                        for acc in gateway_accounts:
                            accounts.append({
                                "accountid": acc.accountid,
                                "balance": acc.balance,
                                "frozen": acc.frozen,
                                "available": acc.available,
                                "currency": acc.currency,
                                "gateway": gateway_name
                            })
                    except:
                        pass
            return accounts
        except Exception as e:
            return []

    def get_positions(self) -> List[Dict[str, Any]]:
        if not self._initialized:
            return []

        try:
            positions = []
            for gateway_name in self.available_gateways:
                gateway = self.main_engine.get_gateway(gateway_name)
                if gateway and hasattr(gateway, 'get_positions'):
                    try:
                        gateway_positions = gateway.get_positions()
                        for pos in gateway_positions:
                            positions.append({
                                "symbol": pos.symbol,
                                "direction": str(pos.direction),
                                "volume": pos.volume,
                                "price": pos.price,
                                "pnl": pos.pnl,
                                "gateway": gateway_name
                            })
                    except:
                        pass
            return positions
        except Exception as e:
            return []

    def get_orders(self) -> List[Dict[str, Any]]:
        if not self._initialized:
            return []

        try:
            orders = []
            for gateway_name in self.available_gateways:
                gateway = self.main_engine.get_gateway(gateway_name)
                if gateway and hasattr(gateway, 'get_orders'):
                    try:
                        gateway_orders = gateway.get_orders()
                        for order in gateway_orders:
                            orders.append({
                                "orderid": order.orderid,
                                "symbol": order.symbol,
                                "direction": str(order.direction),
                                "offset": str(order.offset),
                                "price": order.price,
                                "volume": order.volume,
                                "traded": order.traded,
                                "status": str(order.status),
                                "gateway": gateway_name
                            })
                    except:
                        pass
            return orders
        except Exception as e:
            return []


engine_manager = EngineManager()
