from fastapi import APIRouter, HTTPException, Query
from typing import List, Dict, Any
from fuwen_api import FuWenAPI

router = APIRouter()
api = FuWenAPI()


@router.get("/symbols", summary="获取交易对列表")
async def list_symbols() -> Dict[str, Any]:
    result = api.sync_call('market', 'list_symbols')
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.get("/ticker/{symbol}", summary="获取行情")
async def get_ticker(symbol: str) -> Dict[str, Any]:
    result = api.sync_call('market', 'get_ticker', symbol=symbol)
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.get("/orderbook/{symbol}", summary="获取订单簿")
async def get_order_book(symbol: str, depth: int = Query(10, ge=1, le=100)) -> Dict[str, Any]:
    result = api.sync_call('market', 'get_order_book', symbol=symbol, depth=depth)
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.get("/kline/{symbol}", summary="获取K线数据")
async def get_kline(symbol: str, interval: str = Query('1m'), limit: int = Query(100, ge=1, le=1000)) -> Dict[str, Any]:
    result = api.sync_call('market', 'get_kline', symbol=symbol, interval=interval, limit=limit)
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.get("/summary", summary="获取市场概览")
async def get_market_summary() -> Dict[str, Any]:
    result = api.sync_call('market', 'get_market_summary')
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result