from fastapi import APIRouter, HTTPException, Query
from typing import List, Dict, Any
from fuwen_api import FuWenAPI

router = APIRouter()
api = FuWenAPI()


@router.get("/", summary="获取账户列表")
async def list_accounts() -> Dict[str, Any]:
    result = api.sync_call('account', 'list_accounts')
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.get("/{account_id}", summary="获取账户详情")
async def get_account(account_id: str) -> Dict[str, Any]:
    result = api.sync_call('account', 'get_account', account_id=account_id)
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.get("/{account_id}/balance", summary="获取账户余额")
async def get_balance(account_id: str) -> Dict[str, Any]:
    result = api.sync_call('account', 'get_balance', account_id=account_id)
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.get("/{account_id}/positions", summary="获取持仓")
async def get_positions(account_id: str) -> Dict[str, Any]:
    result = api.sync_call('account', 'get_positions', account_id=account_id)
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.get("/{account_id}/trades", summary="获取交易历史")
async def get_trade_history(account_id: str, limit: int = Query(100, ge=1, le=1000)) -> Dict[str, Any]:
    result = api.sync_call('account', 'get_trade_history', account_id=account_id, limit=limit)
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result