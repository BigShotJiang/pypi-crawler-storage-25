import os
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.exceptions import RequestValidationError
from pydantic import ValidationError
from .routers import strategy, account, market, system, engine, gateway, trading

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = FastAPI(
    title="FuWen Web API",
    description="量化交易框架统一接口服务",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(strategy.router, prefix="/api/strategy", tags=["策略管理"])
app.include_router(account.router, prefix="/api/account", tags=["账户管理"])
app.include_router(market.router, prefix="/api/market", tags=["市场数据"])
app.include_router(system.router, prefix="/api/system", tags=["系统管理"])
app.include_router(engine.router, prefix="/api/engine", tags=["引擎管理"])
app.include_router(gateway.router, prefix="/api/gateway", tags=["网关管理"])
app.include_router(trading.router, prefix="/api/trading", tags=["交易界面"])

static_dir = os.path.join(BASE_DIR, "static")
templates_dir = os.path.join(BASE_DIR, "templates")
app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/", tags=["首页"], response_class=HTMLResponse)
async def read_root():
    template_path = os.path.join(templates_dir, "index.html")
    with open(template_path, "r", encoding="utf-8") as f:
        return f.read()

@app.get("/guide", tags=["新手引导"], response_class=HTMLResponse)
async def guide():
    template_path = os.path.join(templates_dir, "guide.html")
    with open(template_path, "r", encoding="utf-8") as f:
        return f.read()


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    errors = []
    for error in exc.errors():
        field = ".".join(str(e) for e in error["loc"])
        message = error["msg"]
        errors.append(f"{field}: {message}")
    return JSONResponse(
        status_code=422,
        content={"success": False, "message": "验证失败: " + ", ".join(errors)}
    )