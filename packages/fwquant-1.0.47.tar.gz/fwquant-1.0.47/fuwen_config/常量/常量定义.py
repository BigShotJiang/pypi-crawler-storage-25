import os

# 只暴露这些公共变量
__all__ = [
              "福纹配置目录名称",
              "福纹配置目录",
              "福纹配置文件路径",
          ] + [
              "项目根目录",
              "缓存目录",
              "日志目录",
              "当前工作区目录",
          ] + ["默认端口",
               ]  # 这里写你允许外部用的变量

# ============================================
# 配置目录与文件路径（用户家目录）
# ============================================

# 中文变量（对外接口）
福纹配置文件名称: str = "fw_setting.json"  # 例 ：fw_setting.json
福纹配置目录名称: str = ".fw_quant"  # 例 ：.fw_quant
# 跨平台兼容：使用 os.path.join 确保 MAC/Linux/Windows 路径分隔符正确
福纹配置目录: str = os.path.join(os.path.expanduser("~"), 福纹配置目录名称)  # 例 ：~/.fw_quant
福纹配置文件路径: str = os.path.join(福纹配置目录, 福纹配置文件名称)  # 例 ：~/.fw_quant/fw_setting.json

# ============================================
# 项目根目录
# ============================================
# 中文变量（对外接口）
项目根目录: str = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../'))
当前工作区目录: str = 项目根目录

# ============================================
# 缓存与日志目录
# ============================================
_cache_dir_name = "temp"
_log_dir_name = "logs"

_cache_dir = os.path.join(项目根目录, _cache_dir_name)
_log_dir = os.path.join(项目根目录, _log_dir_name)

# 中文变量（对外接口）
缓存目录 = _cache_dir
日志目录 = _log_dir

默认端口 = 15881

# ============================================
# 确保目录存在
# ============================================
os.makedirs(_cache_dir, exist_ok=True)
os.makedirs(_log_dir, exist_ok=True)

if __name__ == '__main__':
    print(f"福纹配置文件路径: [{福纹配置文件路径}]")
    print(f"当前工作区目录: [{当前工作区目录}]")
