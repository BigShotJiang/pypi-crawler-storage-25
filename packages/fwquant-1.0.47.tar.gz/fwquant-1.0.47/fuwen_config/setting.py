"""
Global setting of the trading platform.
"""

from logging import INFO
from tzlocal import get_localzone_name

from fuwen_adaptor.trader.utility import load_json
from fuwen_config.常量.常量定义 import 福纹配置文件名称


SETTINGS: dict = {
    "font.family": "微软雅黑",
    "font.size": 12,

    "log.active": True,
    "log.level": INFO,
    "log.console": True,
    "log.file": True,

    "email.server": "smtp.qq.com",
    "email.port": 465,
    "email.username": "",
    "email.password": "",
    "email.sender": "",
    "email.receiver": "",

    "datafeed.name": "",
    "datafeed.username": "",
    "datafeed.password": "",

    "database.timezone": get_localzone_name(),
    "database.name": "sqlite",
    "database.database": "database.db",
    "database.host": "",
    "database.port": 0,
    "database.user": "",
    "database.password": ""
}

# Load global setting from json file.
SETTING_FILENAME: str = 福纹配置文件名称
SETTINGS.update(load_json(SETTING_FILENAME))


if __name__ == '__main__':
    print(f"SETTINGS: {SETTINGS}")
