"""
fuwen_config - 福纹量化配置模块

提供统一的配置管理接口，包含配置目录、项目路径等核心配置。
"""

try:
    from .常量 import *
except ImportError:
    from 常量 import *

__version__ = "1.0.47"

if __name__ == '__main__':
    print(f"当前工作区目录: [{当前工作区目录}]")