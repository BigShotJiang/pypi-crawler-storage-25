import os
import shutil
import sys

def get_project_root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def remove_directory(path):
    if os.path.exists(path):
        try:
            shutil.rmtree(path)
            print(f"已删除目录: {path}")
            return True
        except Exception as e:
            print(f"删除目录失败 {path}: {e}")
            return False
    else:
        print(f"目录不存在: {path}")
        return True

def cleanup():
    project_root = get_project_root()
    
    dirs_to_clean = [
        os.path.join(project_root, 'build'),
        os.path.join(project_root, 'collected_static'),
        os.path.join(project_root, 'fwquant.egg-info'),
        os.path.join(project_root, 'logs'),
        os.path.join(project_root, 'temp'),
    ]
    
    print(f"项目根目录: {project_root}")
    print("=" * 60)
    print("开始清理临时文件、日志和缓存...")
    print("=" * 60)
    
    success_count = 0
    total_count = len(dirs_to_clean)
    
    for dir_path in dirs_to_clean:
        if remove_directory(dir_path):
            success_count += 1
    
    print("=" * 60)
    print(f"清理完成! 成功: {success_count}/{total_count}")
    
    return success_count == total_count

if __name__ == '__main__':
    sys.exit(0 if cleanup() else 1)