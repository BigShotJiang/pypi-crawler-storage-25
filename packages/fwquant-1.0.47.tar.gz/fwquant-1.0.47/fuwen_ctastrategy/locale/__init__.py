import gettext
from pathlib import Path


localedir = Path(__file__).parent

translations: gettext.NullTranslations = gettext.translation('fuwen_ctastrategy', localedir=localedir, fallback=True)

_ = translations.gettext
