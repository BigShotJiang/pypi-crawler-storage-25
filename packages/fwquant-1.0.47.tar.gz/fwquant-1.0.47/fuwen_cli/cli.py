import socket

import click
import sys
import os
import asyncio

from fuwen.core.公共函数 import get_local_ip
from fuwen_config import 默认端口

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def find_available_port(start_port=默认端口):
    """查找可用端口"""
    port = start_port
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.bind(('127.0.0.1', port))
            s.close()
            return port
        except socket.error:
            port += 1


@click.group()
@click.version_option(version="1.0.0", prog_name="fwquant")
def cli():
    """FWQuant - 量化交易框架命令行工具"""
    pass


@cli.group()
def web():
    """Web服务管理"""
    pass


def start_web_server(host="0.0.0.0", port=默认端口, reload=False, verbose=True):
    """启动Web API服务（可被外部调用）"""
    from fuwen_web.app import app

    available_port = find_available_port(port)
    if available_port != port and verbose:
        click.secho(f"⚠️  端口 {port} 已被占用，自动切换到端口 {available_port}", fg="yellow")

    local_ip = get_local_ip()
    if verbose:
        click.secho(f"🚀 启动 FWQuant Web API 服务", fg="green")
        click.secho(f"📡 绑定地址: {host}", fg="cyan")
        click.secho(f"🔌 监听端口: {available_port}", fg="cyan")
        click.secho(f"🏠 本机访问: http://127.0.0.1:{available_port}/", fg="yellow")
        click.secho(f"🌐 局域网访问: http://{local_ip}:{available_port}/", fg="yellow")

    if reload:
        import uvicorn
        uvicorn.run(app, host=host, port=available_port, reload=True)
    else:
        from uvicorn.server import Server
        from uvicorn.config import Config
        config = Config(app=app, host=host, port=available_port)
        server = Server(config=config)
        try:
            asyncio.run(server.serve())
        except KeyboardInterrupt:
            if verbose:
                click.secho("\n⏹️ 服务已停止", fg="yellow")
            sys.exit(0)


@web.command("run")
@click.option("--host", default="0.0.0.0", help="绑定地址")
@click.option("--port", default=默认端口, help=f"监听端口 (默认: {默认端口})")
@click.option("--reload", is_flag=True, help="自动重载")
def web_run(host, port, reload):
    """启动Web API服务"""
    try:
        start_web_server(host, port, reload)
    except ImportError as e:
        click.secho(f"❌ 导入错误: {e}", fg="red")
        sys.exit(1)


@web.command("stop")
def web_stop():
    """停止Web API服务"""
    click.secho("⏹️ 停止Web API服务", fg="yellow")
    click.secho("提示: 请使用 Ctrl+C 停止运行中的服务", fg="blue")


@cli.group()
def gui():
    """GUI界面管理"""
    pass


def start_gui():
    """启动GUI界面"""
    try:
        from fuwen.gui import start as gui_start
        click.secho("🚀 启动 FWQuant GUI 界面", fg="green")
        gui_start()
    except ImportError as e:
        click.secho(f"❌ GUI模块导入失败: {e}", fg="red")
        click.secho("💡 请安装PySide6依赖: uv pip install PySide6", fg="blue")
        sys.exit(1)


@gui.command("run")
def gui_run():
    """启动GUI界面"""
    try:
        start_gui()
    except Exception as e:
        click.secho(f"❌ GUI启动失败: {e}", fg="red")
        sys.exit(1)


@gui.command("stop")
def gui_stop():
    """停止GUI界面"""
    click.secho("⏹️ 停止GUI界面", fg="yellow")
    click.secho("提示: 请关闭GUI窗口或使用 Ctrl+C 停止", fg="blue")


@cli.group()
def strategy():
    """策略管理"""
    pass


@strategy.command("list")
def strategy_list():
    """列出所有策略"""
    click.secho("📋 策略列表:", fg="green")
    click.echo("  • 网格策略")
    click.echo("  • 趋势策略")
    click.echo("  • 套利策略")


@strategy.command("start")
@click.argument("name")
def strategy_start(name):
    """启动指定策略"""
    click.secho(f"▶️ 启动策略: {name}", fg="green")


@strategy.command("stop")
@click.argument("name")
def strategy_stop(name):
    """停止指定策略"""
    click.secho(f"⏹️ 停止策略: {name}", fg="yellow")


@cli.group()
def account():
    """账户管理"""
    pass


@account.command("info")
def account_info():
    """查看账户信息"""
    click.secho("👤 账户信息:", fg="green")
    click.echo("  • 账户余额: **** USDT")
    click.echo("  • 可用资金: **** USDT")
    click.echo("  • 持仓市值: **** USDT")


@cli.command()
def version():
    """显示版本信息"""
    click.secho("FWQuant v1.0.0", fg="green")
    click.echo("量化交易框架统一接口服务")


if __name__ == "__main__":
    cli()
