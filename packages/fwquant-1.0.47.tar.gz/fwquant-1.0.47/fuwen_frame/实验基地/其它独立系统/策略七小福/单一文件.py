# -*- coding: utf-8 -*-
"""
Created on Mon Jul 28 13:37:34 2025

@author: xinli
"""
from ccxt.base.types import SubType
from futu import *
import numpy as np
import json
import os
import pandas as pd
from datetime import datetime, time, timedelta
import logging
from functools import wraps
import traceback


# 添加日志配置（保持原配置，确保格式统一）
def setup_logging():
    """配置日志系统"""
    # 创建logs目录如果不存在
    if not os.path.exists('../logs'):
        os.makedirs('../logs')

    # 生成日志文件名（带日期）
    log_filename = f"logs/trading_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

    # 配置日志：格式为「时间 - 日志名 - 级别 - 信息」
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_filename, encoding='utf-8'),  # 写入文件
            logging.StreamHandler()  # 控制台输出
        ]
    )

    # 创建特定的logger（避免与其他模块日志冲突）
    logger = logging.getLogger('TradingStrategy')
    logger.setLevel(logging.INFO)

    return logger


# 创建日志记录器（全局使用）
logger = setup_logging()


def log_function_call(func):
    """装饰器：记录函数调用和异常（保持原逻辑）"""

    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            logger.info(f"开始执行函数: {func.__name__}")
            if args:
                logger.debug(f"函数参数: {args}")
            if kwargs:
                logger.debug(f"关键字参数: {kwargs}")

            result = func(*args, **kwargs)

            logger.info(f"函数执行完成: {func.__name__}")
            return result

        except Exception as e:
            logger.error(f"函数 {func.__name__} 执行出错: {str(e)}")
            logger.error(f"异常堆栈: {traceback.format_exc()}")
            raise

    return wrapper


def log_important_event(event_type, message, level='info'):
    """记录重要事件（保持原逻辑）"""
    if level == 'info':
        logger.info(f"[{event_type}] {message}")
    elif level == 'warning':
        logger.warning(f"[{event_type}] {message}")
    elif level == 'error':
        logger.error(f"[{event_type}] {message}")
    elif level == 'critical':
        logger.critical(f"[{event_type}] {message}")


# Pandas 显示配置（保持原逻辑）
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)

############################ 全局变量设置 ############################
FUTUOPEND_ADDRESS = '127.0.0.1'  # OpenD 监听地址
FUTUOPEND_PORT = 11111  # OpenD 监听端口
TRADING_ENVIRONMENT = TrdEnv.SIMULATE  # 交易环境：真实TrdEnv.REAL / 模拟TrdEnv.SIMULATE
TRADING_MARKET = TrdMarket.HK  # 交易市场权限
TRADING_PWD = 'Kalaiqi0'  # 交易密码（模拟环境可忽略，真实环境需谨慎）
TRADING_PERIOD_1 = KLType.K_1M  # 1分钟K线周期
TRADING_PERIOD_3 = KLType.K_3M  # 3分钟K线周期
TRADING_PERIOD_5 = KLType.K_5M  # 5分钟K线周期
TRADING_SECURITY = 'HK.MHI2510'  # 交易标的

############################ 参数设置 ##################################
settings = {
    'N秒后撤单': 45,
    '平仓规则4的止盈': 30,  # 代表利润回撤50%
    '均线1': 5,
    '均线2': 20,
    '均线3': 60,
    'K线周期1': 1,  # 1分钟K线
    'K线周期2': 3,  # 3分钟K线
    'K线周期3': 5  # 5分钟K线
}

# 初始化行情/交易对象（保持原逻辑）
quote_context = OpenQuoteContext(host=FUTUOPEND_ADDRESS, port=FUTUOPEND_PORT)
trade_context = OpenFutureTradeContext(
    host='127.0.0.1',
    port=11111,
    is_encrypt=None,
    security_firm=SecurityFirm.FUTUSECURITIES
)
order_id = ''  # 全局订单ID
positions = dict()  # 全局持仓（后续从JSON加载）


def save_positions_to_json(positions, filename=TRADING_SECURITY.split('.')[1] + "_pos.json"):
    """将策略持仓保存到JSON文件（修复print为logger）"""
    try:
        if not isinstance(positions, dict):
            raise TypeError("持仓数据必须是字典类型，格式为{symbol: 持仓数量}")

        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(positions, f, ensure_ascii=False, indent=4)

        logger.info(f"持仓数据已成功保存到：{os.path.abspath(filename)}")
        return True

    except Exception as e:
        # 替换print为logger.error，保留错误信息
        logger.error(f"保存持仓数据失败：{str(e)}")
        return False


#
def load_positions_from_json(filename=TRADING_SECURITY.split('.')[1] + "_pos.json"):
    """从JSON文件读取策略持仓（修复print为logger）"""
    try:
        if not os.path.exists(filename):
            logger.info(f"持仓文件 {filename} 不存在，返回初始空持仓")
            return {'pos': 0, 'open_time': '', 'action': '', 'price': 0}

        with open(filename, 'r', encoding='utf-8') as f:
            positions = json.load(f)

        if not isinstance(positions, dict):
            raise TypeError("持仓数据应为字典类型")

        logger.info(f"成功从 {os.path.abspath(filename)} 读取持仓数据：{positions}")
        return positions

    except Exception as e:
        logger.error(f"读取持仓数据失败：{str(e)}")
        return None


def unlock_trade():
    """解锁交易（修复日志参数格式）"""
    if TRADING_ENVIRONMENT == TrdEnv.REAL:
        ret, data = trade_context.unlock_trade(TRADING_PWD)
        if ret != RET_OK:
            # 原代码用逗号分隔，改为f-string格式化
            logger.error(f"解锁交易失败：{data}")
            return False
        logger.info("解锁交易成功！")
    return True


def is_normal_trading_time(code):
    """获取市场状态（修复日志参数格式）"""
    ret, data = quote_context.get_market_state([code])
    if ret != RET_OK:
        logger.error(f"获取市场状态失败：{data}")
        return False

    market_state = data['market_state'][0]
    valid_states = [
        MarketState.MORNING, MarketState.AFTERNOON,
        MarketState.FUTURE_DAY_OPEN, MarketState.FUTURE_OPEN,
        MarketState.FUTURE_BREAK_OVER, MarketState.NIGHT_OPEN
    ]

    if market_state in valid_states:
        return True
    logger.info(f"当前非持续交易时段，市场状态：{market_state}")
    return False


def cal_high_low_point(opens, highs, lows, closes):
    """计算高低点（无日志，保持原逻辑）"""
    k_high_point = np.zeros(len(closes))
    k_low_point = np.zeros(len(closes))
    length = len(closes) - 1

    for i in range(1, len(closes) - 3):
        # 高点判断
        if highs[i] > highs[i - 1] and highs[i] > highs[i + 1]:
            right_low_list = lows[i + 2:min(i + 7, length + 1)]
            right_close_list = closes[i + 2:min(i + 7, length + 1)]
            if min(right_low_list) < lows[i] and min(right_low_list) < lows[i + 1]:
                if min(right_close_list) < closes[i] and min(right_close_list) < closes[i + 1]:
                    k_high_point[i] = 1
                    continue
        # 低点判断
        if lows[i] < lows[i - 1] and lows[i] < lows[i + 1]:
            right_high_list = highs[i + 2:min(i + 7, length + 1)]
            right_close_list = closes[i + 2:min(i + 7, length + 1)]
            if max(right_high_list) > highs[i] and max(right_high_list) > highs[i + 1]:
                if max(right_close_list) > closes[i] and max(right_close_list) > closes[i + 1]:
                    k_low_point[i] = 1
                    continue
    return k_high_point, k_low_point


def cal_high_point(opens, highs, lows, closes):
    """计算高点（无日志，保持原逻辑）"""
    k_high_point = np.zeros(len(closes))
    length = len(closes) - 1

    for i in range(1, len(closes) - 3):
        if highs[i] > highs[i - 1] and highs[i] > highs[i + 1]:
            right_low_list = lows[i + 2:min(i + 7, length + 1)]
            right_close_list = closes[i + 2:min(i + 7, length + 1)]
            if min(right_low_list) < lows[i] and min(right_low_list) < lows[i + 1]:
                if min(right_close_list) < closes[i] and min(right_close_list) < closes[i + 1]:
                    k_high_point[i] = 1
                    continue
    return k_high_point


def cal_low_point(opens, highs, lows, closes):
    """计算低点（无日志，保持原逻辑）"""
    k_low_point = np.zeros(len(closes))
    length = len(closes) - 1

    for i in range(1, len(closes) - 3):
        if lows[i] < lows[i - 1] and lows[i] < lows[i + 1]:
            right_high_list = highs[i + 2:min(i + 7, length + 1)]
            right_close_list = closes[i + 2:min(i + 7, length + 1)]
            if max(right_high_list) > highs[i] and max(right_high_list) > highs[i + 1]:
                if max(right_close_list) > closes[i] and max(right_close_list) > closes[i + 1]:
                    k_low_point[i] = 1
                    continue
    return k_low_point


def get_holding_position(code):
    """获取持仓数量（修复print为logger）"""
    holding_position = 0
    ret, data = trade_context.position_list_query(code=code, trd_env=TRADING_ENVIRONMENT)

    if ret != RET_OK:
        logger.error(f"获取持仓数据失败：{data}")
        return None
    else:
        holding_position = data['qty'].sum()  # 简化求和逻辑
        logger.info(f"【持仓状态】{TRADING_SECURITY} 的持仓数量为：{holding_position}")
    return holding_position


def calculate_quantity():
    """计算下单数量（修复print为logger）"""
    ret, data = quote_context.get_market_snapshot([TRADING_SECURITY])
    if ret != RET_OK:
        logger.error(f"获取市场快照失败：{data}")
        return 0
    price_quantity = data['lot_size'][0]  # 最小交易量
    logger.debug(f"计算下单数量：最小交易量为 {price_quantity}")
    return price_quantity


def is_valid_quantity(code, quantity, price):
    """判断购买力是否足够（修复print为logger）"""
    ret, data = trade_context.acctradinginfo_query(
        order_type=OrderType.NORMAL,
        code=code,
        price=price,
        trd_env=TRADING_ENVIRONMENT
    )

    if ret != RET_OK:
        logger.error(f"获取最大可买可卖数量失败：{data}")
        return False

    max_can_buy = data['max_cash_buy'][0]
    max_can_sell = data['max_sell_short'][0]

    if quantity > 0:
        is_valid = quantity < max_can_buy
        logger.debug(f"判断购买力：需买入 {quantity}，最大可买 {max_can_buy}，是否有效：{is_valid}")
        return is_valid
    elif quantity < 0:
        is_valid = abs(quantity) < max_can_sell
        logger.debug(f"判断购买力：需卖出 {abs(quantity)}，最大可卖 {max_can_sell}，是否有效：{is_valid}")
        return is_valid
    else:
        logger.warning("下单数量为0，无效")
        return False


def show_order_status(data):
    """展示订单回调（修复print为logger）"""
    order_status = data['order_status'][0]
    order_info = {
        '代码': data['code'][0],
        '价格': data['price'][0],
        '方向': data['trd_side'][0],
        '数量': data['qty'][0],
        '成交数量': data['dealt_qty'][0]
    }
    logger.info(f"【订单状态】{order_status} | {order_info}")


############################ 策略核心函数（修复日志格式） ############################
def on_init():
    """策略启动初始化（保持原逻辑）"""
    if not unlock_trade():
        return False
    logger.info("************ 策略开始运行 ************")
    return True


def on_tick():
    """每个tick运行（预留，无逻辑）"""
    pass


def on_bar_open():
    """新K线生成时运行（原逻辑，补充日志）"""
    logger.info("*************************************")
    if not is_normal_trading_time(TRADING_SECURITY):
        return

    # 原代码中 calculate_bull_bear 未定义，此处补充日志提醒
    logger.warning("calculate_bull_bear 函数未定义，暂不执行多空判断")
    holding_position = get_holding_position(TRADING_SECURITY)

    if holding_position == 0:
        logger.info("【操作信号】当前无持仓，暂不操作（多空判断函数未定义）")
    elif holding_position > 0:
        logger.info("【操作信号】当前有多头持仓，暂不平仓（多空判断函数未定义）")


def on_fill(data):
    """委托成交回调（预留，无逻辑）"""
    pass


def on_order_status(data):
    """订单状态变化回调（修复print为logger）"""
    if data['code'][0] == TRADING_SECURITY:
        show_order_status(data)


def close_3m_5m_2K_ma5_pos(cur_time, period):
    """平仓规则1（修复日志参数格式）"""
    global order_id
    global positions
    ma1_length = settings['均线1']

    # 获取K线数据
    if period == settings['K线周期3']:
        k_ret, k_data = quote_context.get_cur_kline(
            TRADING_SECURITY,
            settings['K线周期3'] * 10 + 1,
            TRADING_PERIOD_1,
            AuType.NONE
        )
    else:
        k_ret, k_data = quote_context.get_cur_kline(
            TRADING_SECURITY,
            25,
            TRADING_PERIOD_1,
            AuType.NONE
        )

    if k_ret == RET_OK:
        # 数据预处理
        k_data = k_data.iloc[:-1]
        k_data['time_key'] = pd.to_datetime(k_data['time_key'])
        k_data = k_data.set_index('time_key')
        five_min_df = k_data.resample(f"{period}min").agg({
            'open': 'first',
            'high': 'max',
            'low': 'min',
            'close': 'last',
            'volume': 'sum'
        })
        k_data = five_min_df
        closes = k_data['close'].values
        last_close = closes[-1]
        last2_close = closes[-2]
        ma1_last = np.mean(closes[-ma1_length:]) if len(closes) >= ma1_length else 0
        ma1_last2 = np.mean(closes[-(ma1_length + 1):-1]) if len(closes) >= ma1_length + 1 else 0

        # 修复日志：用f-string替换逗号分隔
        logger.info(
            f"【平仓规则1】时间：{cur_time} | 最新收盘价：{last_close} | "
            f"MA{ma1_length}（最新）：{ma1_last} | 前次收盘价：{last2_close} | "
            f"MA{ma1_length}（前次）：{ma1_last2}"
        )

        # 多头平仓判断
        if positions['pos'] > 0:
            if last_close < ma1_last and last2_close < ma1_last2:
                order_ret, order_data = trade_context.place_order(
                    price=last_close,
                    order_type=OrderType.MARKET,
                    qty=abs(positions['pos']),
                    code=TRADING_SECURITY,
                    trd_side=TrdSide.SELL,
                    trd_env=TRADING_ENVIRONMENT,
                    session=Session.NONE
                )
                if order_ret == RET_OK:
                    order_id = order_data['order_id'][0]
                    positions['action'] = 'SELL_CLOSE'
                    positions['open_time'] = cur_time
                    logger.info(
                        f"【平仓规则1】成功 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                        f"周期：{period}min | 操作：卖出平仓 | 订单ID：{order_id}"
                    )
                else:
                    logger.error(
                        f"【平仓规则1】失败 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                        f"原因：{order_data}"
                    )

        # 空头平仓判断
        if positions['pos'] < 0:
            if last_close > ma1_last and last2_close > ma1_last2:
                order_ret, order_data = trade_context.place_order(
                    price=last_close,
                    order_type=OrderType.MARKET,
                    qty=abs(positions['pos']),
                    code=TRADING_SECURITY,
                    trd_side=TrdSide.BUY,
                    trd_env=TRADING_ENVIRONMENT,
                    session=Session.NONE
                )
                if order_ret == RET_OK:
                    order_id = order_data['order_id'][0]
                    positions['action'] = 'BUY_CLOSE'
                    positions['open_time'] = cur_time
                    logger.info(
                        f"【平仓规则1】成功 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                        f"周期：{period}min | 操作：买入平仓 | 订单ID：{order_id}"
                    )
                else:
                    logger.error(
                        f"【平仓规则1】失败 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                        f"原因：{order_data}"
                    )
    else:
        logger.error(
            f"【平仓规则1】获取K线失败 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
            f"原因：{k_data}"
        )


def close_3m_high_low_point(cur_time, period, n):
    """平仓规则2（修复日志参数格式）"""
    global order_id
    global positions
    ma1_length = settings['均线1']

    # 获取K线数据
    k_ret, k_data = quote_context.get_cur_kline(
        TRADING_SECURITY,
        (n + 5) * 3 + 1,
        TRADING_PERIOD_1,
        AuType.NONE
    )

    if k_ret == RET_OK:
        # 数据预处理
        k_data = k_data.iloc[:-1]
        k_data['time_key'] = pd.to_datetime(k_data['time_key'])
        k_data = k_data.set_index('time_key')
        resampled_df = k_data.resample(f"{period}min").agg({
            'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last', 'volume': 'sum'
        })
        opens = resampled_df['open'].values
        highs = resampled_df['high'].values
        lows = resampled_df['low'].values
        closes = resampled_df['close'].values
        last_close = closes[-1]
        last2_close = closes[-2]
        ma1_last = np.mean(closes[-ma1_length:]) if len(closes) >= ma1_length else 0

        # 多头平仓判断
        if positions['pos'] > 0:
            if closes[-1] < opens[-1] and closes[-2] < opens[-2] and last_close < ma1_last:
                high_point = cal_high_point(opens, highs, lows, closes)
                if 1 in high_point[-n:]:
                    order_ret, order_data = trade_context.place_order(
                        price=last_close,
                        order_type=OrderType.MARKET,
                        qty=abs(positions['pos']),
                        code=TRADING_SECURITY,
                        trd_side=TrdSide.SELL,
                        trd_env=TRADING_ENVIRONMENT,
                        session=Session.NONE
                    )
                    if order_ret == RET_OK:
                        order_id = order_data['order_id'][0]
                        positions['action'] = 'SELL_CLOSE'
                        positions['open_time'] = cur_time
                        logger.info(
                            f"【平仓规则2】成功 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                            f"周期：{period}min | 操作：卖出平仓 | 订单ID：{order_id}"
                        )
                    else:
                        logger.error(
                            f"【平仓规则2】失败 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                            f"原因：{order_data}"
                        )

        # 空头平仓判断
        if positions['pos'] < 0:
            if closes[-1] > opens[-1] and closes[-2] > opens[-2] and last_close > ma1_last:
                low_point = cal_low_point(opens, highs, lows, closes)
                if 1 in low_point[-n:]:
                    order_ret, order_data = trade_context.place_order(
                        price=last_close,
                        order_type=OrderType.MARKET,
                        qty=abs(positions['pos']),
                        code=TRADING_SECURITY,
                        trd_side=TrdSide.BUY,
                        trd_env=TRADING_ENVIRONMENT,
                        session=Session.NONE
                    )
                    if order_ret == RET_OK:
                        order_id = order_data['order_id'][0]
                        positions['action'] = 'BUY_CLOSE'
                        positions['open_time'] = cur_time
                        logger.info(
                            f"【平仓规则2】成功 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                            f"周期：{period}min | 操作：买入平仓 | 订单ID：{order_id}"
                        )
                    else:
                        logger.error(
                            f"【平仓规则2】失败 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                            f"原因：{order_data}"
                        )
    else:
        logger.error(
            f"【平仓规则2】获取K线失败 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
            f"原因：{k_data}"
        )


def close_3m_high_low_point_compare(cur_time, period, n):
    """平仓规则3（修复日志参数格式）"""
    global order_id
    global positions
    ma1_length = settings['均线1']

    # 获取K线数据
    k_ret, k_data = quote_context.get_cur_kline(
        code=TRADING_SECURITY,
        num=100 * 3 + 1,
        ktype=TRADING_PERIOD_1,
        autype=AuType.NONE
    )

    if k_ret == RET_OK:
        # 数据预处理
        k_data = k_data.iloc[:-1]
        k_data['time_key'] = pd.to_datetime(k_data['time_key'])
        k_data = k_data.set_index('time_key')
        resampled_df = k_data.resample(f"{period}min").agg({
            'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last', 'volume': 'sum'
        })
        opens = resampled_df['open'].values
        highs = resampled_df['high'].values
        lows = resampled_df['low'].values
        closes = resampled_df['close'].values
        last_close = closes[-1]
        ma1_last = np.mean(closes[-ma1_length:]) if len(closes) >= ma1_length else 0

        # 多头平仓判断
        if positions['pos'] > 0 and last_close < ma1_last:
            high_point = cal_high_point(opens, highs, lows, closes)
            if 1 in high_point[-n:] and np.sum(high_point) >= 2:
                # 找到最近2个高点位置
                high_indices = [i for i, val in enumerate(high_point[::-1]) if val == 1][:2]
                if len(high_indices) == 2:
                    idx1, idx2 = -(high_indices[0] + 1), -(high_indices[1] + 1)
                    if highs[idx1] < highs[idx2]:
                        order_ret, order_data = trade_context.place_order(
                            price=last_close,
                            order_type=OrderType.MARKET,
                            qty=abs(positions['pos']),
                            code=TRADING_SECURITY,
                            trd_side=TrdSide.SELL,
                            trd_env=TRADING_ENVIRONMENT,
                            session=Session.NONE
                        )
                        if order_ret == RET_OK:
                            order_id = order_data['order_id'][0]
                            positions['action'] = 'SELL_CLOSE'
                            positions['open_time'] = cur_time
                            logger.info(
                                f"【平仓规则3】成功 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                                f"周期：{period}min | 操作：卖出平仓 | 订单ID：{order_id}"
                            )
                        else:
                            logger.error(
                                f"【平仓规则3】失败 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                                f"原因：{order_data}"
                            )

        # 空头平仓判断
        if positions['pos'] < 0 and last_close > ma1_last:
            low_point = cal_low_point(opens, highs, lows, closes)
            if 1 in low_point[-n:] and np.sum(low_point) >= 2:
                # 找到最近2个低点位置
                low_indices = [i for i, val in enumerate(low_point[::-1]) if val == 1][:2]
                if len(low_indices) == 2:
                    idx1, idx2 = -(low_indices[0] + 1), -(low_indices[1] + 1)
                    if lows[idx1] > lows[idx2]:
                        order_ret, order_data = trade_context.place_order(
                            price=last_close,
                            order_type=OrderType.MARKET,
                            qty=abs(positions['pos']),
                            code=TRADING_SECURITY,
                            trd_side=TrdSide.BUY,
                            trd_env=TRADING_ENVIRONMENT,
                            session=Session.NONE
                        )
                        if order_ret == RET_OK:
                            order_id = order_data['order_id'][0]
                            positions['action'] = 'BUY_CLOSE'
                            positions['open_time'] = cur_time
                            logger.info(
                                f"【平仓规则3】成功 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                                f"周期：{period}min | 操作：买入平仓 | 订单ID：{order_id}"
                            )
                        else:
                            logger.error(
                                f"【平仓规则3】失败 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                                f"原因：{order_data}"
                            )
    else:
        logger.error(
            f"【平仓规则3】获取K线失败 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
            f"原因：{k_data}"
        )


def close_1m_stop_profit(cur_time, price, period, n):
    """平仓规则4（修复日志参数格式）"""
    global order_id
    global positions
    stop_profit_ratio = settings['平仓规则4的止盈'] / 100  # 止盈比例（50% → 0.5）

    # 获取K线数据
    k_ret, k_data = quote_context.get_cur_kline(
        TRADING_SECURITY,
        n + 10,
        TRADING_PERIOD_1,
        AuType.NONE
    )

    if k_ret == RET_OK:
        opens = k_data['open'].values
        highs = k_data['high'].values
        lows = k_data['low'].values
        closes = k_data['close'].values
        last_close = closes[-1]

        # 多头止盈平仓
        if positions['pos'] > 0:
            high_point = cal_high_point(opens, highs, lows, closes)
            max_high = max(highs[-n:]) if len(highs) >= n else 0
            # 止盈条件：有2个高点 + 利润回撤达到比例
            if (1 in high_point[-n:] and np.sum(high_point[-n:]) >= 2 and
                    (max_high - price) * stop_profit_ratio >= (last_close - price)):
                order_ret, order_data = trade_context.place_order(
                    price=last_close,
                    order_type=OrderType.MARKET,
                    qty=abs(positions['pos']),
                    code=TRADING_SECURITY,
                    trd_side=TrdSide.SELL,
                    trd_env=TRADING_ENVIRONMENT,
                    session=Session.NONE
                )
                if order_ret == RET_OK:
                    order_id = order_data['order_id'][0]
                    positions['action'] = 'SELL_CLOSE'
                    positions['open_time'] = cur_time
                    logger.info(
                        f"【平仓规则4】成功 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                        f"周期：{period} | 操作：卖出平仓 | 订单ID：{order_id} | "
                        f"开仓价：{price} | 最新价：{last_close} | 止盈比例：{stop_profit_ratio}"
                    )
                else:
                    logger.error(
                        f"【平仓规则4】失败 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                        f"原因：{order_data}"
                    )

        # 空头止盈平仓
        if positions['pos'] < 0:
            low_point = cal_low_point(opens, highs, lows, closes)
            min_low = min(lows[-n:]) if len(lows) >= n else 0
            # 止盈条件：有2个低点 + 利润回撤达到比例
            if (1 in low_point[-n:] and np.sum(low_point[-n:]) >= 2 and
                    (price - min_low) * stop_profit_ratio >= (price - last_close)):
                order_ret, order_data = trade_context.place_order(
                    price=last_close,
                    order_type=OrderType.MARKET,
                    qty=abs(positions['pos']),
                    code=TRADING_SECURITY,
                    trd_side=TrdSide.BUY,
                    trd_env=TRADING_ENVIRONMENT,
                    session=Session.NONE
                )
                if order_ret == RET_OK:
                    order_id = order_data['order_id'][0]
                    positions['action'] = 'BUY_CLOSE'
                    positions['open_time'] = cur_time
                    logger.info(
                        f"【平仓规则4】成功 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                        f"周期：{period} | 操作：买入平仓 | 订单ID：{order_id} | "
                        f"开仓价：{price} | 最新价：{last_close} | 止盈比例：{stop_profit_ratio}"
                    )
                else:
                    logger.error(
                        f"【平仓规则4】失败 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
                        f"原因：{order_data}"
                    )
    else:
        logger.error(
            f"【平仓规则4】获取K线失败 | 标的：{TRADING_SECURITY} | 时间：{cur_time} | "
            f"原因：{k_data}"
        )


################################ 回调类（修复日志格式） ##################################
# 回调类：处理实时行情数据
class OnQuoteClass(StockQuoteHandlerBase):
    # 记录上一次时间（用于分钟级判断）
    last_time = None

    def on_recv_rsp(self, rsp_pb):
        global order_id
        global positions
        ma1_length = settings['均线1']
        ma2_length = settings['均线2']
        ma3_length = settings['均线3']

        # 调用父类方法获取行情数据
        Quote_ret_code, Quote_data = super(OnQuoteClass, self).on_recv_rsp(rsp_pb)
        if Quote_ret_code != RET_OK:
            logger.error(f"获取行情数据失败：{Quote_data}")
            return

        # 提取行情关键信息
        data_time = Quote_data['data_time'][0]
        data_date = Quote_data['data_date'][0]
        cur_datetime_str = f"{data_date} {data_time[:8]}"  # 格式：YYYY-MM-DD HH:MM:SS
        last_price = Quote_data['last_price'][0]

        # 初始化last_time（首次运行）
        if self.last_time is None:
            self.last_time = data_time[3:5]  # 取分钟数（如「13:37:34」→「37」）
            return

        ############################ 45秒后撤单逻辑（修复日志格式） ############################
        if (order_id != '' and len(positions['open_time']) > 0 and
                positions['action'] in ['BUY_OPEN', 'SELL_OPEN']):

            # 时间格式转换
            try:
                cur_order_time = datetime.strptime(cur_datetime_str, "%Y-%m-%d %H:%M:%S")
                open_time = datetime.strptime(positions['open_time'], "%Y-%m-%d %H:%M:%S")
                time_diff = (cur_order_time - open_time).total_seconds()
            except ValueError as e:
                logger.error(f"时间格式转换失败：{e} | 开仓时间：{positions['open_time']}")
                return

            # 判断是否达到撤单时间（N秒后）
            if time_diff >= settings['N秒后撤单']:
                # 查询订单状态
                order_query_ret, order_query_data = trade_context.order_list_query(
                    order_id=order_id,
                    code=TRADING_SECURITY,
                    trd_env=TRADING_ENVIRONMENT
                )

                if order_query_ret == RET_OK:
                    logger.info(
                        f"【撤单检查】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                        f"订单ID：{order_id} | 订单状态：{order_query_data.to_dict('records')}"
                    )

                    # 判断订单是否存在且未完全成交
                    if (not order_query_data.empty and
                            order_id in order_query_data['order_id'].values):
                        order_query_data = order_query_data.set_index('order_id')
                        remaining_qty = order_query_data.loc[order_id, 'qty'] - order_query_data.loc[
                            order_id, 'dealt_qty']

                        if remaining_qty > 0:
                            # 撤单
                            cancel_ret, cancel_data = trade_context.modify_order(
                                modify_order_op=ModifyOrderOp.CANCEL,
                                order_id=order_id,
                                qty=0,
                                price=0,
                                trd_env=TRADING_ENVIRONMENT
                            )

                            if cancel_ret == RET_OK:
                                # 撤单后重新市价开仓
                                trd_side = order_query_data.loc[order_id, 'trd_side']
                                order_ret, order_data = trade_context.place_order(
                                    price=last_price,
                                    order_type=OrderType.MARKET,
                                    qty=remaining_qty,
                                    code=TRADING_SECURITY,
                                    trd_side=trd_side,
                                    trd_env=TRADING_ENVIRONMENT,
                                    session=Session.NONE
                                )

                                if order_ret == RET_OK:
                                    new_order_id = order_data['order_id'][0]
                                    positions['open_time'] = cur_datetime_str
                                    order_id = new_order_id

                                    if trd_side == TrdSide.BUY:
                                        logger.info(
                                            f"【撤单重开】成功 | 标的：{TRADING_SECURITY} | 时间：{data_time} | "
                                            f"原订单ID：{order_id} | 新订单ID：{new_order_id} | 操作：市价买入"
                                        )
                                    else:
                                        logger.info(
                                            f"【撤单重开】成功 | 标的：{TRADING_SECURITY} | 时间：{data_time} | "
                                            f"原订单ID：{order_id} | 新订单ID：{new_order_id} | 操作：市价卖出"
                                        )
                                else:
                                    logger.error(
                                        f"【撤单重开】失败 | 标的：{TRADING_SECURITY} | 时间：{data_time} | "
                                        f"原因：{order_data}"
                                    )
                            else:
                                logger.error(
                                    f"【撤单】失败 | 标的：{TRADING_SECURITY} | 时间：{data_time} | "
                                    f"订单ID：{order_id} | 原因：{cancel_data}"
                                )
                        else:
                            logger.info(
                                f"【撤单检查】订单已完全成交 | 标的：{TRADING_SECURITY} | "
                                f"订单ID：{order_id} | 剩余数量：{remaining_qty}"
                            )
                else:
                    logger.error(
                        f"【撤单检查】查询订单失败 | 标的：{TRADING_SECURITY} | 时间：{data_time} | "
                        f"订单ID：{order_id} | 原因：{order_query_data}"
                    )
            else:
                logger.debug(
                    f"【撤单检查】未达撤单时间 | 标的：{TRADING_SECURITY} | 时间：{data_time} | "
                    f"已挂单：{time_diff:.1f}秒 | 需挂单：{settings['N秒后撤单']}秒"
                )

        ############################ 分钟级策略逻辑（修复日志格式） ############################
        current_minute = data_time[3:5]
        if self.last_time != current_minute and abs(positions['pos']) > 0:
            try:
                cur_quote_time = datetime.strptime(cur_datetime_str, "%Y-%m-%d %H:%M:%S")
                open_time = datetime.strptime(positions['open_time'], "%Y-%m-%d %H:%M:%S")
                time_since_open = (cur_quote_time - open_time).total_seconds() / 60  # 开仓后分钟数
            except ValueError as e:
                logger.error(f"时间格式转换失败：{e} | 开仓时间：{positions['open_time']}")
                return

            # 平仓规则1（5分钟周期）
            if order_id == '' and int(current_minute) % settings['K线周期3'] == 0:
                logger.info(
                    f"【策略触发】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                    f"触发规则：平仓规则1（{settings['K线周期3']}min周期）"
                )
                close_3m_5m_2K_ma5_pos(cur_datetime_str, settings['K线周期3'])

            # 平仓规则2（3分钟周期，开仓后至少2个周期）
            if (order_id == '' and time_since_open >= 2 * settings['K线周期2'] and
                    int(current_minute) % settings['K线周期2'] == 0):
                n = int(time_since_open / settings['K线周期2'])
                logger.info(
                    f"【策略触发】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                    f"触发规则：平仓规则2（{settings['K线周期2']}min周期）| 开仓后周期数：{n}"
                )
                close_3m_high_low_point(cur_datetime_str, settings['K线周期2'], n)

            # 平仓规则3（3分钟周期，开仓后至少2个周期）
            if (order_id == '' and time_since_open >= 2 * settings['K线周期2'] and
                    int(current_minute) % settings['K线周期2'] == 0):
                n = int(time_since_open / settings['K线周期2'])
                logger.info(
                    f"【策略触发】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                    f"触发规则：平仓规则3（{settings['K线周期2']}min周期）| 开仓后周期数：{n}"
                )
                close_3m_high_low_point_compare(cur_datetime_str, settings['K线周期2'], n)

            # 平仓规则4（1分钟周期，开仓后至少5分钟）
            if order_id == '' and time_since_open >= settings['K线周期3']:
                n = int(time_since_open)  # 开仓后分钟数（作为K线数量）
                logger.info(
                    f"【策略触发】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                    f"触发规则：平仓规则4（1min周期）| 开仓后分钟数：{n}"
                )
                close_1m_stop_profit(cur_datetime_str, positions['price'], KLType.K_1M, n)

        ############################ 开仓逻辑（修复日志格式） ############################
        '''
        logger.info(
            f"【分钟级监控】标的：{TRADING_SECURITY} | 时间：{data_time} | "
            f"订单ID：{order_id} | 持仓数量：{abs(positions['pos'])} | 最新价：{last_price}"
        )
        '''
        # 分钟级日志（避免重复输出）
        if self.last_time != current_minute:

            # 无持仓且无订单时，触发开仓判断
            if order_id == '' and abs(positions['pos']) == 0:
                # 获取120根1分钟K线
                k_ret, k_data = quote_context.get_cur_kline(
                    TRADING_SECURITY,
                    120,
                    KLType.K_1M,
                    AuType.NONE
                )

                if k_ret == RET_OK:
                    #
                    if k_data['time_key'].values[-1][14:16] != current_minute:
                        k_data = k_data.iloc[:-1]  # 剔除最新未完成K线
                    opens = k_data['open'].values
                    highs = k_data['high'].values
                    lows = k_data['low'].values
                    closes = k_data['close'].values

                    # 计算均线
                    ma5 = k_data['close'].rolling(window=ma1_length).mean().fillna(0)
                    ma10 = k_data['close'].rolling(window=ma2_length).mean().fillna(0)
                    ma20 = k_data['close'].rolling(window=ma3_length).mean().fillna(0)

                    logger.info(
                        f"【开仓判断】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                        f"MA5：{ma5.iloc[-1]:.2f} | MA10：{ma10.iloc[-1]:.2f} | MA20：{ma20.iloc[-1]:.2f}"
                        f" time: {k_data['time_key'].values[-1]} K1_close:{closes[-1]} | K2_close:{closes[-2]} K3_close:{closes[-3]}"
                    )

                    ############################ 多头开仓信号 ############################

                    # 做多  判断
                    if ma5.iloc[-1] > ma20.iloc[-1]:
                        # 信号1：MA5 ≥ MA10 ≥ MA20 + 连续2根阳线 + 突破MA5
                        if ((ma5.iloc[-1] >= ma10.iloc[-1] >= ma20.iloc[-1]
                             and closes[-1] > opens[-1]
                             and closes[-2] > opens[-2]
                             and closes[-1] > ma5.iloc[-1]
                             and closes[-2] > ma5.iloc[-2]
                             and closes[-3] < ma5.iloc[-3])
                             and order_id == ''):

                            # 立即以当前市场最优价格买入1手恒指期货
                            # 高概率成交 （市价单优先成交）
                            # 开立多头仓位 （买入开仓）
                            order_ret, order_data = trade_context.place_order(
                                price=last_price,
                                order_type=OrderType.MARKET,
                                qty=1,  # 固定1手，可根据实际调整
                                code=TRADING_SECURITY,
                                trd_side=TrdSide.BUY,
                                trd_env=TRADING_ENVIRONMENT,
                                session=Session.NONE
                            )

                            if order_ret == RET_OK:
                                order_id = order_data['order_id'][0]
                                positions['open_time'] = cur_datetime_str
                                positions['action'] = 'BUY_OPEN'
                                logger.info(
                                    f"【开仓成功】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                                    f"信号：多头信号1 | 订单ID：{order_id} | 市价：{last_price}"

                                )
                            else:
                                logger.error(
                                    f"【开仓失败】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                                    f"信号：多头信号1 | 原因：{order_data}"
                                )

                        # 信号2：MA5金叉MA20后持续向上 + 低点上移
                        ma5_above_ma20 = ma5 > ma20
                        crossover = ma5_above_ma20 & ~ma5_above_ma20.shift(1, fill_value=False)
                        crossover_indices = crossover[crossover].index

                        if not crossover_indices.empty:
                            last_crossover_idx = crossover_indices[-1]
                            # 金叉后MA5始终在MA20上方
                            if ma5_above_ma20.loc[last_crossover_idx:].all() and order_id == '':
                                # 计算高低点
                                last_low_point = cal_low_point(opens[:-1], highs[:-1], lows[:-1], closes[:-1])
                                current_low_point = cal_low_point(opens, highs, lows, closes)

                                if np.sum(current_low_point) > np.sum(last_low_point):
                                    # 取最近2个低点
                                    low_indices = [i for i, val in enumerate(current_low_point) if val == 1][:2]
                                    if len(low_indices) == 2:
                                        idx1, idx2 = -(low_indices[0] + 1), -(low_indices[1] + 1)
                                        if lows[idx1] > lows[idx2] and closes[idx1] > ma5.iloc[idx1]:
                                            # 计算限价（高点与MA5均值）
                                            limit_price = round((highs[-1] + ma5.iloc[-1]) / 2, 2)
                                            order_ret, order_data = trade_context.place_order(
                                                price=limit_price,
                                                order_type=OrderType.NORMAL,
                                                adjust_limit=0.01,
                                                qty=1,
                                                code=TRADING_SECURITY,
                                                trd_side=TrdSide.BUY,
                                                trd_env=TRADING_ENVIRONMENT,
                                                session=Session.NONE
                                            )

                                            if order_ret == RET_OK:
                                                order_id = order_data['order_id'][0]
                                                positions['open_time'] = cur_datetime_str
                                                positions['action'] = 'BUY_OPEN'
                                                logger.info(
                                                    f"【开仓成功】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                                                    f"信号：多头信号2 | 订单ID：{order_id} | 限价：{limit_price}"
                                                )
                                            else:
                                                logger.error(
                                                    f"【开仓失败】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                                                    f"信号：多头信号2 | 限价：{limit_price} | 原因：{order_data}"
                                                )


                    ############################ 空头开仓信号 ############################
                    elif ma5.iloc[-1] < ma20.iloc[-1]:
                        # 信号1：MA5 ≤ MA10 ≤ MA20 + 连续2根阴线 + 跌破MA5
                        if (ma5.iloc[-1] <= ma10.iloc[-1] <= ma20.iloc[-1] and
                            closes[-1] < opens[-1] and closes[-2] < opens[-2] and
                            closes[-1] < ma5.iloc[-1] and closes[-2] < ma5.iloc[-2] and
                            closes[-3] > ma5.iloc[-3]) and order_id == '':
                            # 信号工厂 1 空头开仓信号
                            order_ret, order_data = trade_context.place_order(
                                price=last_price,
                                order_type=OrderType.MARKET,
                                qty=1,
                                code=TRADING_SECURITY,
                                trd_side=TrdSide.SELL,
                                trd_env=TRADING_ENVIRONMENT,
                                session=Session.NONE
                            )

                            if order_ret == RET_OK:
                                order_id = order_data['order_id'][0]
                                positions['open_time'] = cur_datetime_str
                                positions['action'] = 'SELL_OPEN'
                                logger.info(
                                    f"【开仓成功】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                                    f"信号：空头信号1 | 订单ID：{order_id} | 市价：{last_price}"
                                )
                            else:
                                logger.error(
                                    f"【开仓失败】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                                    f"信号：空头信号1 | 原因：{order_data}"
                                )

                        # 信号2：MA5死叉MA20后持续向下 + 高点下移
                        ma5_below_ma20 = ma5 < ma20
                        crossunder = ma5_below_ma20 & ~ma5_below_ma20.shift(1, fill_value=False)
                        crossunder_indices = crossunder[crossunder].index

                        if not crossunder_indices.empty:
                            last_crossunder_idx = crossunder_indices[-1]
                            # 死叉后MA5始终在MA20下方
                            if ma5_below_ma20.loc[last_crossunder_idx:].all() and order_id == '':
                                # 计算高低点
                                last_high_point = cal_high_point(opens[:-1], highs[:-1], lows[:-1], closes[:-1])
                                current_high_point = cal_high_point(opens, highs, lows, closes)

                                if np.sum(current_high_point) > np.sum(last_high_point):
                                    # 取最近2个高点
                                    high_indices = [i for i, val in enumerate(current_high_point) if val == 1][:2]
                                    if len(high_indices) == 2:
                                        idx1, idx2 = -(high_indices[0] + 1), -(high_indices[1] + 1)
                                        if highs[idx1] < highs[idx2] and closes[idx1] < ma5.iloc[idx1]:
                                            # 计算限价（低点与MA5均值）
                                            limit_price = round((lows[-1] + ma5.iloc[-1]) / 2, 2)
                                            # 信号工厂 2 空头开仓信号
                                            order_ret, order_data = trade_context.place_order(
                                                price=limit_price,
                                                order_type=OrderType.NORMAL,
                                                adjust_limit=-0.01,
                                                qty=1,
                                                code=TRADING_SECURITY,
                                                trd_side=TrdSide.SELL,
                                                trd_env=TRADING_ENVIRONMENT,
                                                session=Session.NONE
                                            )

                                            if order_ret == RET_OK:
                                                order_id = order_data['order_id'][0]
                                                positions['open_time'] = cur_datetime_str
                                                positions['action'] = 'SELL_OPEN'
                                                logger.info(
                                                    f"【开仓成功】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                                                    f"信号：空头信号2 | 订单ID：{order_id} | 限价：{limit_price}"
                                                )
                                            else:
                                                logger.error(
                                                    f"【开仓失败】标的：{TRADING_SECURITY} | 时间：{data_time} | "
                                                    f"信号：空头信号2 | 限价：{limit_price} | 原因：{order_data}"
                                                )
                        else:
                            pass
                else:
                    logger.error(
                        f"【开仓判断】获取K线失败 | 标的：{TRADING_SECURITY} | 时间：{data_time} | "
                        f"原因：{k_data}"
                    )

        # 更新last_time（避免重复触发分钟级逻辑）
        self.last_time = current_minute

        # 订单状态回调（修复日志格式）


class OnOrderClass(TradeOrderHandlerBase):
    """订单状态回调（修复日志格式）"""

    def on_recv_rsp(self, rsp_pb):
        global order_id
        global positions

        ret, data = super(OnOrderClass, self).on_recv_rsp(rsp_pb)
        if ret == RET_OK:
            if data['code'][0] == TRADING_SECURITY:
                order_status = data['order_status'][0]
                logger.info(
                    f"【订单回调】标的：{data['code'][0]} | 订单ID：{data['order_id'][0]} | "
                    f"状态：{order_status} | 方向：{data['trd_side'][0]} | "
                    f"数量：{data['qty'][0]} | 成交：{data['dealt_qty'][0]}"
                )

                # 订单完全成交
                if order_status == OrderStatus.FILLED_ALL and data['order_id'][0] == order_id:
                    order_id = ''  # 重置订单ID
                    dealt_qty = data['dealt_qty'][0]
                    dealt_avg_price = data['dealt_avg_price'][0]

                    # 多头开仓成交
                    if positions['action'] == 'BUY_OPEN':
                        positions['pos'] = dealt_qty
                        positions['price'] = dealt_avg_price
                        logger.info(
                            f"【成交确认】标的：{TRADING_SECURITY} | 操作：买入开仓 | "
                            f"成交数量：{dealt_qty} | 成交均价：{dealt_avg_price}"
                        )

                    # 空头开仓成交
                    elif positions['action'] == 'SELL_OPEN':
                        positions['pos'] = -dealt_qty
                        positions['price'] = dealt_avg_price
                        logger.info(
                            f"【成交确认】标的：{TRADING_SECURITY} | 操作：卖出开仓 | "
                            f"成交数量：{dealt_qty} | 成交均价：{dealt_avg_price}"
                        )

                    # 平仓成交
                    elif positions['action'] in ['BUY_CLOSE', 'SELL_CLOSE']:
                        positions['pos'] = 0
                        logger.info(
                            f"【成交确认】标的：{TRADING_SECURITY} | 操作：{positions['action']} | "
                            f"成交数量：{dealt_qty} | 成交均价：{dealt_avg_price}"
                        )

                    # 保存持仓到JSON
                    save_positions_to_json(positions)
        else:
            logger.error(f"【订单回调】获取订单数据失败：{data}")


# 成交回调（补充日志）
class OnFillClass(TradeDealHandlerBase):
    """成交回调（补充日志）"""

    def on_recv_rsp(self, rsp_pb):
        ret, data = super(OnFillClass, self).on_recv_rsp(rsp_pb)
        if ret == RET_OK:
            logger.info(
                f"【成交明细】标的：{data['code'][0]} | 订单ID：{data['order_id'][0]} | "
                f"成交ID：{data['deal_id'][0]} | 方向：{data['trd_side'][0]} | "
                f"价格：{data['deal_price'][0]} | 数量：{data['deal_qty'][0]} | "
                f"时间：{data['deal_time'][0]}"
            )
            on_fill(data)
        else:
            logger.error(f"【成交回调】获取成交数据失败：{data}")


############################ 主函数（修复日志格式） ############################
if __name__ == '__main__':
    # 加载持仓数据
    positions = load_positions_from_json()
    if positions is None:
        logger.error("加载持仓数据失败，初始化空持仓")
        positions = {'pos': 0, 'open_time': '', 'action': '', 'price': 0}

    # 初始化策略
    if not on_init():
        logger.error("策略初始化失败，脚本退出！")
        quote_context.close()
        trade_context.close()
    else:
        # 输出初始持仓信息
        logger.info(f"【策略初始化】当前持仓：{positions} | 交易标的：{TRADING_SECURITY} | 环境：{TRADING_ENVIRONMENT}")

        # 设置回调
        quote_context.set_handler(OnQuoteClass())
        trade_context.set_handler(OnOrderClass())
        trade_context.set_handler(OnFillClass())

        # 订阅行情（1分钟K线、摆盘、逐笔）
        subscribe_ret, subscribe_data = quote_context.subscribe(
            code_list=[TRADING_SECURITY],
            subtype_list=[SubType.QUOTE, SubType.ORDER_BOOK, TRADING_PERIOD_1]
        )

        if subscribe_ret == RET_OK:
            logger.info(
                f"【行情订阅】成功 | 标的：{TRADING_SECURITY} | 订阅类型：{[SubType.QUOTE, SubType.ORDER_BOOK, TRADING_PERIOD_1]}")
        else:
            logger.error(f"【行情订阅】失败 | 原因：{subscribe_data}")
            quote_context.close()
            trade_context.close()
