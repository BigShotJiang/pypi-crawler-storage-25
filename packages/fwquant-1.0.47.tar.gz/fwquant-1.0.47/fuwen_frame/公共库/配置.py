from fuwen_adaptor.trader.setting import SETTINGS

IS_DEBUG = True

FW_SETTINGS = SETTINGS.copy()

if __name__ == '__main__':
    print(f"FW_SETTINGS: {FW_SETTINGS}")
