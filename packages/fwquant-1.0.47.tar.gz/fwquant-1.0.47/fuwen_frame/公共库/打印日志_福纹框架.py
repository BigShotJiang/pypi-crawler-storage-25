"""
loguru_adapter.py - 完全兼容原 fw_log 的 loguru 实现
保持所有接口、行为、输出格式完全一致，性能更优
"""
import sys
import os
import datetime
from pathlib import Path
from loguru import logger as loguru_logger

from fuwen_config.常量 import 日志目录



class fw_log:
    """loguru 实现版 - 完全兼容原 fw_log 接口"""

    LOG_LEVELS = {
        "DEBUG": 10,
        "INFO": 20,
        "WARNING": 30,
        "ERROR": 40
    }
    默认模块名 = "FWLOG"

    def __init__(self, name: str = "", level: str = "INFO", save_to_file: bool = True):
        if name != "":
            self.默认模块名 = name
        self.name = name
        self.save_to_file = save_to_file
        self.fuwen主引擎: "MainEngine" = None

        # 初始化日志目录
        self.log_dir = 日志目录 or self._init_log_dir()

        # 设置日志级别
        self.set_level(level)

        # 只在第一次创建时配置 loguru
        if not hasattr(fw_log, '_loguru_configured'):
            self._configure_loguru()
            fw_log._loguru_configured = True

        # 绑定模块名
        self._bound_logger = loguru_logger.bind(name=self.name)

    def setname(self, name: str = ""):
        """设置日志名称，空值时使用默认名称"""
        if not name or name.strip() == "":
            self.name = self.默认模块名
        else:
            self.name = name
        self._bound_logger = loguru_logger.bind(name=self.name)

    def _init_log_dir(self):
        """初始化日志文件目录（与原版完全一致）"""
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            parent_dir = os.path.dirname(current_dir)
            log_dir = os.path.join(parent_dir, "Logs")
            if not os.path.exists(log_dir):
                os.makedirs(log_dir)
            return log_dir
        except Exception as e:
            log_dir = os.path.join(os.getcwd(), "Logs")
            if not os.path.exists(log_dir):
                os.makedirs(log_dir)
            print(f"日志目录初始化失败，降级到当前目录：{e}")
            return log_dir

    def _configure_loguru(self):
        """配置 loguru（保持与原版完全一致的输出格式）"""
        loguru_logger.remove()

        # 自定义格式函数：保持与原版完全相同的输出格式
        def format_record(record):
            # 时间戳格式与原版一致
            timestamp = record["time"].strftime("%Y-%m-%d %H:%M:%S")
            level = record["level"].name
            name = record["extra"].get("name", self.name)
            msg = record["message"]

            # ERROR 整行红色，其他级别只有标识有颜色（与原版一致）
            if level == "ERROR":
                # ERROR：整行红色
                return f"\033[31m[{timestamp}] [{name}] [{level}] {msg}\033[0m\n"
            else:
                # 其他级别：只有级别标识有颜色
                level_color = {
                    "DEBUG": "\033[37m",  # 灰色
                    "INFO": "\033[32m",  # 绿色
                    "WARNING": "\033[33m"  # 黄色
                }.get(level, "\033[0m")
                reset_color = "\033[0m"
                return f"[{timestamp}] [{name}] {level_color}[{level}]{reset_color} {msg}\n"

        # 添加控制台输出
        loguru_logger.add(
            sys.stdout,
            colorize=False,  # 我们手动控制颜色
            format=format_record,
            level=self.level_name
        )

        # 文件输出（与原版格式完全一致）
        if self.save_to_file:
            log_dir = Path(self.log_dir)
            log_dir.mkdir(exist_ok=True)

            def file_format(record):
                timestamp = record["time"].strftime("%Y-%m-%d %H:%M:%S")
                level = record["level"].name
                name = record["extra"].get("name", self.name)
                msg = record["message"]
                return f"[{timestamp}] [{name}] [{level}] {msg}\n"

            loguru_logger.add(
                str(log_dir / f"{self.name}_{{time:YYYY-MM-DD}}.log"),
                format=file_format,
                rotation="00:00",
                retention="30 days",
                encoding="utf-8",
                level=self.level_name,
                enqueue=True,  # 异步写入，不阻塞主线程
                filter=lambda record: record["extra"].get("name") == self.name
            )

    def set_level(self, level: str):
        """设置日志级别（与原版完全一致）"""
        if level.upper() not in self.LOG_LEVELS:
            print(f"日志级别 {level} 不合法，默认使用 INFO 级别")
            self.level = self.LOG_LEVELS["INFO"]
            self.level_name = "INFO"
        else:
            self.level = self.LOG_LEVELS[level.upper()]
            self.level_name = level.upper()
        print(f"日志级别已设置为：{self.level_name}（仅打印≥该级别的日志）")

    def 设置主引擎(self, 引擎):
        """关联 fuwen_adaptor 主引擎（与原版完全一致）"""
        from fuwen_adaptor.trader.engine import MainEngine
        self.fuwen主引擎: MainEngine = 引擎

    def _should_print(self, level: str) -> bool:
        """判断是否需要打印（与原版完全一致）"""
        return self.LOG_LEVELS[level] >= self.level

    def _print_log(self, msg: str, level: str):
        """内部打印方法（与原版逻辑完全一致）"""
        if not self._should_print(level):
            return

        # 使用 loguru 输出
        getattr(self._bound_logger, level.lower())(msg)

    def _打印到引擎(self, msg: str, gateway_name: str = ""):
        """输出到引擎（与原版完全一致）"""
        引擎 = None
        if gateway_name != "":
            if self.fuwen主引擎 is not None:
                引擎 = self.fuwen主引擎.get_gateway(gateway_name=gateway_name)
            if 引擎 is not None:
                引擎 = self.fuwen主引擎
        else:
            引擎 = self.fuwen主引擎

        if 引擎 is not None:
            引擎.write_log(msg=f"{msg}")

    # 兼容原版所有接口
    def debug(self, msg: str, gateway_name: str = "", name: str = ""):
        self.setname(name)
        self._print_log(msg, "DEBUG")
        self._打印到引擎(msg=msg, gateway_name=gateway_name)

    def info(self, msg: str, gateway_name: str = "", name: str = ""):
        self.setname(name)
        self._print_log(msg, "INFO")
        self._打印到引擎(msg=msg, gateway_name=gateway_name)

    def warning(self, msg: str, gateway_name: str = "", name: str = ""):
        self.setname(name)
        self._print_log(msg, "WARNING")
        self._打印到引擎(msg=msg, gateway_name=gateway_name)

    def error(self, msg: str, gateway_name: str = "", name: str = ""):
        self.setname(name)
        self._print_log(msg, "ERROR")
        self._打印到引擎(msg=msg, gateway_name=gateway_name)

    def write_log(self, msg: str):
        self._print_log(msg, "INFO")
        if self.fuwen主引擎 is not None:
            self.fuwen主引擎.write_log(msg=msg)


# 创建全局实例（与原版完全相同）
logger = fw_log(name="", level="DEBUG")

if __name__ == "__main__":
    print("\n=== 测试：完全兼容原版 fw_log ===\n")
    logger.debug("这是调试信息")
    logger.info("这是普通信息")
    logger.warning("这是警告信息")
    logger.error("这是错误信息")
    logger.write_log("这是兼容的write_log方法")

    # 测试 name 参数
    logger.debug("这是调试信息", name="模块1")
    logger.info("这是普通信息", name="模块2")
    logger.warning("这是警告信息", name="模块3")
    logger.error("这是错误信息", name="模块4")

    # 测试 gateway_name 参数
    logger.info("CTP通道连接成功", gateway_name="CTP")
    logger.error("聚宽接口断开", gateway_name="JQ")

    print("\n=== 测试完成 ===\n")