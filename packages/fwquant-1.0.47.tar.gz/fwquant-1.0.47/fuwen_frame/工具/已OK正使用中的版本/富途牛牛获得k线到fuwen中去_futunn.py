import csv
import os
import sqlite3
import time
import traceback
import warnings
from datetime import datetime, timedelta
from typing import Dict

import pandas as pd
from futu import OpenQuoteContext, KLType, AuType

from fuwen_adaptor.trader.setting import SETTINGS
from fuwen_config import 常量, 福纹配置目录
from fw_engine.网关管理.交易所.欧易.原生接口.公共数据 import 网关常量

# 1. 关闭resource_tracker警告
warnings.filterwarnings('ignore', category=UserWarning, module='multiprocessing.resource_tracker')

# -------------------------- 配置参数（新增：夜市开启+时间范围保留） --------------------------
# 下载数据需要用到的值
股票代码 = "HK.HSImain"  # 恒指主力合约通用代码，也可改为具体合约如HK.HSI2601/HK.HSI2602
开始时间 = (datetime.now() - timedelta(days=10)).strftime("%Y-%m-%d %H:%M:%S")
结束时间 = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
# 开始时间 = "2026-02-10 00:00:00"
# 结束时间 = "2026-02-28 00:00:00"
时间_格式化 = f"{开始时间}到{结束时间}".replace(":", "").replace(" ", "_").replace("-", "")
_当前工作区目录 = 常量.当前工作区目录
# 当前工作区目录=f"/Users/yanhuang/github/fwquant/fuwen_frame"
保存csv路径 = f"{_当前工作区目录}/缓存目录/{股票代码}_{时间_格式化}_1m_白天+夜市.csv"

# fuwen数据库需要用到的值
标的代码 = "HSImain"
周期 = "1m"
交易所 = "GLOBAL"  # 恒指期货交易所代码     HK_HSI      GLOBAL
数据库名称: str=  SETTINGS["database.database"] or "database.db"
数据库sqlite文件路径 = f"{福纹配置目录}/database.db"

# 恒指期货真实交易时间配置（白天+夜市，全部开启）
HSI_TRADING_TIME = {
    "早盘": ("09:15", "12:00"),  # 白天早盘
    "午盘": ("13:00", "16:30"),  # 白天午盘
    "夜市": ("17:15", "03:00")  # 夜市（17:15-次日03:00，跨天）
}


# --------------------------------------------------------------
def 过滤恒指交易时段(数据框):
    """
    核心修改1：开启夜市数据过滤，适配跨天逻辑
    解决：02:00夜市时段无数据的问题
    """
    df = 数据框.copy()
    # 提取时间小时分钟（HH:MM）和日期，处理夜市跨天
    df['time_hm'] = df['datetime'].dt.strftime('%H:%M')
    df['date'] = df['datetime'].dt.date

    有效时间 = []
    # 白天时段：早盘+午盘（当天）
    start1, end1 = HSI_TRADING_TIME["早盘"]
    start2, end2 = HSI_TRADING_TIME["午盘"]
    有效时间.extend([f"{h:02d}:{m:02d}" for h in range(24) for m in range(60)
                     if (start1 <= f"{h:02d}:{m:02d}" <= end1) or (start2 <= f"{h:02d}:{m:02d}" <= end2)])
    df_白天 = df[df['time_hm'].isin(有效时间)].copy()

    # 核心修改：开启夜市数据过滤，适配跨天逻辑（17:15-23:59 + 00:00-03:00）
    start3, end3 = HSI_TRADING_TIME["夜市"]
    df_夜市 = df[(df['time_hm'] >= start3) | (df['time_hm'] <= end3)].copy()

    # 合并白天+夜市数据，去重并按时间排序
    df_有效 = pd.concat([df_白天, df_夜市], ignore_index=True)
    df_有效 = df_有效.drop_duplicates(subset=['datetime']).sort_values('datetime').reset_index(drop=True)
    # 删除辅助列
    df_有效 = df_有效.drop(columns=['time_hm', 'date'], errors='ignore')
    return df_有效


def 获取港股期货数据_富途(股票代码, 开始时间, 结束时间):
    """使用富途牛牛API获取港股期货数据（优化后：支持白天+夜市）"""
    print(f"🔍 使用富途牛牛获取 {股票代码} 数据...")
    print(f"   时间范围: {开始时间} 至 {结束时间}")

    行情上下文 = None
    try:
        行情上下文 = OpenQuoteContext(host='127.0.0.1', port=11111)
        print("✅ 已连接富途牛牛客户端")

        开始时间_dt = pd.to_datetime(开始时间)
        结束时间_dt = pd.to_datetime(结束时间)
        开始日期 = 开始时间_dt.strftime('%Y-%m-%d')
        结束日期 = 结束时间_dt.strftime('%Y-%m-%d')

        print(f"   请求日期范围: {开始日期} 至 {结束日期}")
        返回码, 历史k线数据, 分页键 = 行情上下文.request_history_kline(
            code=股票代码,
            start=开始日期,
            end=结束日期,
            ktype=KLType.K_1M,  # 1分钟K线
            autype=AuType.NONE,  # 期货原始价格，无需复权
            max_count=100000,
            extended_time=False  # 期货无额外盘前盘后，保持关闭
        )

        if 返回码 != 0:
            print(f"❌ 获取历史K线数据失败: {历史k线数据}")
            return pd.DataFrame()
        if 历史k线数据 is None or len(历史k线数据) == 0:
            print("❌ 未获取到任何数据")
            return pd.DataFrame()
        print(f"✅ 成功获取 {len(历史k线数据)} 条原始K线数据（含白天+夜市）")

        # 转换为DataFrame并映射列
        数据框 = pd.DataFrame(历史k线数据)
        列映射 = {
            'time_key': 'datetime',
            'open': 'open',
            'high': 'high',
            'low': 'low',
            'close': 'close',
            'volume': 'volume',
            'turnover': 'turnover'
        }
        数据框 = 数据框.rename(columns=列映射)
        数据框['datetime'] = pd.to_datetime(数据框['datetime'])

        # 1. 精确过滤时间范围
        过滤条件 = (数据框['datetime'] >= 开始时间_dt) & (数据框['datetime'] <= 结束时间_dt)
        数据框 = 数据框[过滤条件].copy()
        # 2. 核心：开启白天+夜市有效时段过滤（不再剔除夜市）
        数据框 = 过滤恒指交易时段(数据框)
        # 3. 过滤0成交无效数据（保留真实交易）
        数据框 = 数据框[数据框['volume'] > 0].copy()

        if len(数据框) == 0:
            print(f"⚠️  过滤后无有效数据（非交易时段/0成交/休市）")
            return pd.DataFrame()
        print(f"📅 过滤后有效数据（白天+夜市）: {len(数据框)} 条")

        # 补充fuwen所需列
        数据框['open_interest'] = 0  # 富途期货无持仓量，默认0
        数据框['symbol'] = 股票代码  # 若需具体合约代码，可改为如HK.HSI2601

        # 匹配fuwen标准列序
        必须列 = ['datetime', 'open', 'high', 'low', 'close',
                  'volume', 'turnover', 'open_interest', 'symbol']
        存在列 = [列名 for 列名 in 必须列 if 列名 in 数据框.columns]
        数据框 = 数据框[存在列].sort_values('datetime').reset_index(drop=True)

        return 数据框

    except Exception as 异常:
        print(f"❌ 富途API调用失败: {str(异常)}")
        traceback.print_exc()
        return pd.DataFrame()
    finally:
        if 行情上下文:
            try:
                行情上下文.close()
                print("🔒 已关闭富途连接")
            except:
                pass


def 检查数据质量(数据框, 股票代码):
    """检查数据质量（优化：适配白天+夜市数据）"""
    if 数据框.empty:
        print("❌ 数据为空，无法进行质量检查")
        return

    print(f"\n🔍 {股票代码} 数据质量检查（白天+夜市）：")
    print(f"   总有效数据量: {len(数据框)} 条")
    print(f"   时间范围: {数据框['datetime'].min()} 至 {数据框['datetime'].max()}")
    print(f"   缺失值数量: {数据框.isnull().sum().sum()}")

    # 价格统计
    print(f"\n📈 价格统计（恒指期货）：")
    print(
        f"   开盘价: 最高{数据框['open'].max():.2f} | 最低{数据框['open'].min():.2f} | 均值{数据框['open'].mean():.2f}")
    print(
        f"   收盘价: 最高{数据框['close'].max():.2f} | 最低{数据框['close'].min():.2f} | 均值{数据框['close'].mean():.2f}")
    print(f"   波幅: 最大{数据框['high'].max() - 数据框['low'].min():.2f} 点")

    # 成交量统计
    print(f"\n📊 成交量统计：")
    print(f"   平均成交量: {数据框['volume'].mean():.0f}")
    print(f"   最大成交量: {数据框['volume'].max():.0f}")
    print(f"   总成交量: {数据框['volume'].sum():,.0f}")
    print(f"   总成交额: {数据框['turnover'].sum():,.2f} 港币")

    # 时间间隔检查（适配夜市跨天，忽略休市间隔）
    print(f"\n⏱️  时间间隔检查（白天+夜市，含跨天）：")
    时间差 = 数据框['datetime'].diff().dropna()
    标准间隔 = timedelta(minutes=1)
    异常间隔 = 时间差[时间差 != 标准间隔]
    if len(异常间隔) == 0:
        print(f"   ✅ 时间间隔完全连续（1分钟），无数据缺口")
    else:
        print(f"   ⚠️  发现 {len(异常间隔)} 个异常时间间隔，最大缺口: {异常间隔.max()}")
        print(f"   ℹ️  异常间隔多为午间休市/夜市跨天/港股休市导致，属正常现象")


def 保存数据_带备份(数据框, 保存路径):
    """保存数据并创建备份（适配fuwen：datetime转字符串，成交量转整数）"""
    if 数据框.empty:
        print("❌ 数据为空，无法保存")
        return False
    try:
        os.makedirs(os.path.dirname(保存路径), exist_ok=True)
        # fuwen适配：datetime转字符串，成交量/成交额转整数（避免小数）
        数据框_fuwen = 数据框.copy()
        数据框_fuwen['datetime'] = 数据框_fuwen['datetime'].dt.strftime('%Y-%m-%d %H:%M:%S')
        数据框_fuwen['volume'] = 数据框_fuwen['volume'].astype(int)
        数据框_fuwen['turnover'] = 数据框_fuwen['turnover'].astype(int)

        # 备份原有文件
        if os.path.exists(保存路径):
            import shutil
            时间戳 = datetime.now().strftime("%Y%m%d_%H%M%S")
            备份路径 = 保存路径.replace('.csv', f'_备份_{时间戳}.csv')
            shutil.copy2(保存路径, 备份路径)
            print(f"📂 已创建备份: {备份路径}")

        # 保存数据
        数据框_fuwen.to_csv(保存路径, index=False, encoding='utf-8')
        文件大小 = os.path.getsize(保存路径) / 1024
        print(f"💾 数据已保存（白天+夜市）: {保存路径}")
        print(f"   文件大小: {文件大小:.1f} KB | 数据条数: {len(数据框_fuwen)}")
        return True
    except Exception as 异常:
        print(f"❌ 保存数据失败: {str(异常)}")
        return False


def 获取数据_分页方式(股票代码, 开始时间, 结束时间):
    """分页获取历史K线数据（优化：支持白天+夜市，大时间范围专用）"""
    print(f"📊 分页获取 {股票代码} 历史数据（白天+夜市）...")
    行情上下文 = None
    try:
        行情上下文 = OpenQuoteContext(host='127.0.0.1', port=11111)
        开始时间_dt = pd.to_datetime(开始时间)
        结束时间_dt = pd.to_datetime(结束时间)
        开始日期 = 开始时间_dt.strftime('%Y-%m-%d')
        结束日期 = 结束时间_dt.strftime('%Y-%m-%d')
        print(f"   日期范围: {开始日期} 至 {结束日期}")

        所有数据 = []
        分页键 = None
        页码 = 1
        while True:
            print(f"   正在获取第{页码}页数据...")
            返回码, 页面数据, 新分页键 = 行情上下文.request_history_kline(
                code=股票代码,
                start=开始日期,
                end=结束日期,
                ktype=KLType.K_1M,
                autype=AuType.NONE,
                max_count=2000,  # 每页2000条，避免请求超限
                extended_time=False,
                page_req_key=分页键
            )
            # 终止条件：请求失败/无数据
            if 返回码 != 0 or 页面数据 is None or len(页面数据) == 0:
                break
            print(f"   第{页码}页获取到 {len(页面数据)} 条数据")
            所有数据.extend(页面数据)
            # 终止条件：无新分页键（获取完所有数据）
            if 新分页键 is None or 新分页键 == 分页键:
                break
            分页键 = 新分页键
            页码 += 1
            time.sleep(0.1)  # 防止请求过快，触发富途限流

        if len(所有数据) == 0:
            return pd.DataFrame()
        # 数据处理：映射列+转换时间
        数据框 = pd.DataFrame(所有数据)
        列映射 = {'time_key': 'datetime', 'open': 'open', 'high': 'high', 'low': 'low', 'close': 'close',
                  'volume': 'volume', 'turnover': 'turnover'}
        数据框 = 数据框.rename(columns=列映射)
        数据框['datetime'] = pd.to_datetime(数据框['datetime'])

        # 过滤逻辑：时间范围+白天+夜市+0成交剔除
        数据框 = 数据框[(数据框['datetime'] >= 开始时间_dt) & (数据框['datetime'] <= 结束时间_dt)].copy()
        数据框 = 过滤恒指交易时段(数据框)
        数据框 = 数据框[数据框['volume'] > 0].copy()

        if len(数据框) == 0:
            return pd.DataFrame()
        # 补充fuwen列
        数据框['open_interest'] = 0
        数据框['symbol'] = 股票代码
        # 匹配fuwen列序
        必须列 = ['datetime', 'open', 'high', 'low', 'close', 'volume', 'turnover', 'open_interest', 'symbol']
        存在列 = [列名 for 列名 in 必须列 if 列名 in 数据框.columns]
        数据框 = 数据框[存在列].sort_values('datetime').reset_index(drop=True)
        return 数据框
    except Exception as 异常:
        print(f"❌ 分页获取失败: {str(异常)}")
        traceback.print_exc()
        return pd.DataFrame()
    finally:
        if 行情上下文:
            try:
                行情上下文.close()
            except:
                pass


def 导入CSV到fuwen数据库中(导入数据文件路径: str, 数据库文件路径: str, 标的代码: str, 周期: str, 交易所: str) -> Dict:
    """
    将CSV文件中的行情数据导入到SQLite数据库的dbbardata表中，跳过重复的datetime记录

    参数:
        导入数据文件路径: CSV数据文件的完整路径
        数据库文件路径: SQLite数据库文件的完整路径
        标的代码: 对应数据库的symbol字段
        周期: 对应数据库的interval字段（如1m）
        交易所: 对应数据库的exchange字段（如HK_HSI）

    返回:
        字典，包含导入状态、成功导入条数、详细内容
    """
    # 初始化返回结果
    result = {
        "导入状态": "失败",
        "成功导入数据的条数": 0,
        "详细内容": ""
    }

    # 统计变量
    total_rows = 0  # 读取的总行数
    success_rows = 0  # 成功导入的行数
    skip_rows = 0  # 跳过的重复行数
    error_rows = []  # 出错的行

    try:
        # 1. 连接数据库
        conn = sqlite3.connect(数据库文件路径)
        cursor = conn.cursor()

        # 2. 检查dbbardata表是否存在（避免表不存在报错）
        cursor.execute("""
                       CREATE TABLE IF NOT EXISTS dbbardata
                       (
                           id
                           INTEGER
                           PRIMARY
                           KEY
                           AUTOINCREMENT,
                           symbol
                           TEXT
                           NOT
                           NULL,
                           exchange
                           TEXT
                           NOT
                           NULL,
                           datetime
                           TEXT
                           NOT
                           NULL,
                           interval
                           TEXT
                           NOT
                           NULL,
                           volume
                           REAL,
                           turnover
                           REAL,
                           open_interest
                           REAL,
                           open_price
                           REAL,
                           high_price
                           REAL,
                           low_price
                           REAL,
                           close_price
                           REAL,
                           -- 添加唯一索引，确保核心字段不重复（也用于快速查重）
                           UNIQUE
                       (
                           symbol,
                           exchange,
                           interval,
                           datetime
                       )
                           )
                       """)
        conn.commit()

        # 3. 读取CSV文件并逐行处理
        with open(导入数据文件路径, 'r', encoding='utf-8') as csvfile:
            # 创建CSV阅读器，使用第一行作为字段名
            reader = csv.DictReader(csvfile)

            # 检查CSV字段是否完整
            required_fields = ['datetime', 'open', 'high', 'low', 'close', 'volume', 'turnover', 'open_interest']
            if not all(field in reader.fieldnames for field in required_fields):
                result["详细内容"] = f"CSV文件字段缺失，需要包含：{required_fields}"
                return result

            # 逐行读取数据
            for row_num, row in enumerate(reader, start=2):  # 行号从2开始（跳过表头）
                total_rows += 1
                try:
                    # 提取并清洗数据
                    datetime_str = row['datetime'].strip()
                    # 验证时间格式（可选，增强鲁棒性）
                    datetime.strptime(datetime_str, '%Y-%m-%d %H:%M:%S')

                    # 构建插入SQL（使用INSERT OR IGNORE，利用唯一索引自动跳过重复）
                    insert_sql = """
                                 INSERT
                                 OR IGNORE INTO dbbardata
                                 (symbol, exchange, datetime, interval, volume, turnover, open_interest,
                                  open_price, high_price, low_price, close_price)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) \
                                 """
                    # 准备插入参数
                    insert_params = (
                        标的代码,
                        交易所,
                        datetime_str,
                        周期,
                        float(row['volume'] or 0),
                        float(row['turnover'] or 0),
                        float(row['open_interest'] or 0),
                        float(row['open'] or 0),
                        float(row['high'] or 0),
                        float(row['low'] or 0),
                        float(row['close'] or 0)
                    )

                    # 执行插入（INSERT OR IGNORE会自动跳过唯一索引重复的记录）
                    cursor.execute(insert_sql, insert_params)

                    # 判断是否插入成功（rowcount=1表示插入，0表示跳过）
                    if cursor.rowcount == 1:
                        success_rows += 1
                    else:
                        skip_rows += 1

                except Exception as e:
                    error_rows.append(f"第{row_num}行：{str(e)}")
                    continue

        # 4. 提交事务
        conn.commit()

        # 5. 更新返回结果
        result["导入状态"] = "成功"
        result["成功导入数据的条数"] = success_rows
        result["详细内容"] = (
                f"共读取{total_rows}行数据，"
                f"成功导入{success_rows}行，"
                f"跳过重复数据{skip_rows}行，"
                f"出错{len(error_rows)}行。"
                + (f"错误详情：{'; '.join(error_rows)}" if error_rows else "")
        )

    except FileNotFoundError as e:
        result["详细内容"] = f"文件不存在：{str(e)}"
    except sqlite3.Error as e:
        result["详细内容"] = f"数据库操作错误：{str(e)}"
    except Exception as e:
        result["详细内容"] = f"未知错误：{str(e)}"
    finally:
        # 确保数据库连接关闭
        if 'conn' in locals() and conn:
            conn.close()

    return result


def 主函数():
    """主函数（优化：适配白天+夜市，新增主力合约换月提示）"""

    result = {}
    print("=" * 60)
    print("📊 恒指期货数据获取工具 - 富途牛牛版（白天+夜市完整版）")
    print("=" * 60)
    print(f"目标标的: {股票代码}")
    print(f"时间范围: {开始时间} 至 {结束时间}")
    print(f"保存路径: {保存csv路径}")
    print("-" * 60)
    print("\n⚠️  核心注意点（必看）：")
    print("   1. 已启动富途牛牛客户端并开启API服务（默认端口11111）")
    print("   2. HK.HSImain为通用主力代码，会自动换月，若需连续数据请用具体合约代码（如HK.HSI2601）")
    print("   3. 已开启白天+夜市完整数据（白天：09:15-16:30，夜市：17:15-次日03:00）")
    print("   4. 恒指期货休市同港股，节假日/周六日无数据")
    print("-" * 60)

    try:
        # 1. 尝试直接获取数据（小时间范围）
        print("\n尝试方法一：直接获取历史K线...")
        数据框 = 获取港股期货数据_富途(股票代码, 开始时间, 结束时间)
        # 2. 方法一失败则分页获取（大时间范围，如1个月以上）
        if 数据框.empty:
            print("\n尝试方法二：分页获取历史K线（适配大时间范围）...")
            数据框 = 获取数据_分页方式(股票代码, 开始时间, 结束时间)
        # 3. 最终无数据则提示原因
        if 数据框.empty:
            print("\n❌ 未能获取到有效数据，原因排查：")
            print("   - 富途牛牛API服务未开启/未登录账户")
            print("   - 指定时间为港股节假日/休市日（周六日/法定节假日）")
            print("   - 通用主力代码（HSImain）换月，导致老合约数据断层（改用具体合约代码）")
            print("   - 具体合约已到期（恒指期货到期日为每月倒数第二个交易日）")
            return
        # 4. 检查数据质量
        检查数据质量(数据框, 股票代码)
        # 5. 保存数据
        成功 = 保存数据_带备份(数据框, 保存csv路径)
        if 成功:
            print(f"\n📋 数据预览（前5行，含夜市）：")
            print(数据框.head())
            print(f"\n📋 数据预览（后5行，含夜市）：")
            print(数据框.tail())
            print(f"\n🎉 数据处理完成！已获取白天+夜市完整数据，可直接在fuwen中用CsvLoader导入")

            # 导入文件到数据库中
            result = 导入CSV到fuwen数据库中(导入数据文件路径=保存csv路径, 数据库文件路径=数据库sqlite文件路径,
                                           标的代码=标的代码, 周期=周期, 交易所=交易所)
            print(f"导入结果: {result}")
    except Exception as 异常:
        print(f"\n❌ 程序执行失败：{str(异常)}")
        traceback.print_exc()
    return result


if __name__ == '__main__':
    result = 主函数()
    print(f"result: {result}")
