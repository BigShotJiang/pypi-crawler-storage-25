import warnings
from datetime import datetime

from fuwen_ctastrategy import CtaTemplate
from fuwen_adaptor.trader.object import BarData, OrderData, TradeData
from fuwen_adaptor.trader.constant import Direction, Offset

# 屏蔽pandas的FutureWarning
warnings.filterwarnings('ignore', category=FutureWarning, module='pyqtgraph')


class 示例_指定时间交易类(CtaTemplate):
    """指定时间交易策略 - 读取fuwen界面回测参数"""

    作者 = "示例_指定时间交易策略"
    默认交易数量 = 10
    parameters = ["作者", '默认交易数量']  # 仅保留策略专属参数

    # 用于存储交易记录的列表
    交易记录列表 = []

    # 初始化持仓变量（适配回测环境）
    pos_long = 0  # 多头持仓
    pos_short = 0  # 空头持仓

    def __init__(self, cta_engine, strategy_name, fw_symbol, setting):
        super().__init__(cta_engine, strategy_name, fw_symbol, setting)

        # ========== 核心修改：从回测引擎读取配置参数 ==========
        self.回测配置 = {}
        # 判断是否是回测环境
        if hasattr(self.cta_engine, 'setting'):


            # 从回测引擎读取界面配置的参数
            self.回测配置 = self.cta_engine.setting
            # 回测参数映射（fuwen回测界面的参数名）
            self.初始资金 = self.回测配置.get("capital", 100000)  # 初始资金
            self.手续费率 = self.回测配置.get("commission_rate", 0.0003)  # 手续费率
            self.滑点 = self.回测配置.get("slippage", 0.2)  # 滑点
            self.合约乘数 = self.回测配置.get("size", 10)  # 合约乘数
        else:
            # 实盘环境使用默认值
            self.初始资金 = 100000
            self.手续费率 = 0.0003
            self.滑点 = 0.2
            self.合约乘数 = 10

        # 初始化交易记录表头
        self.交易记录列表.append({
            "交易序号": "序号",
            "操作类型": "操作类型",
            "触发时间": "触发时间",
            "委托时间": "委托时间",
            "成交时间": "成交时间",
            "成交价格": "成交价格",
            "成交手数": "成交手数",
            "成交金额": "成交金额",
            "订单编号": "订单编号",
            "持仓变化": "持仓变化"
        })
        self.交易序号 = 0
        self.委托订单缓存 = {}  # 初始化缓存，避免属性不存在

        # 资金相关初始化
        self.当前资金 = self.初始资金
        self.总盈亏 = 0
        self.总手续费 = 0
        self.总滑点成本 = 0
        self.成交记录 = []  # 记录每笔成交的详细盈亏

        # 初始化持仓（兼容实盘/回测）
        if hasattr(self, 'pos'):
            if self.pos > 0:
                self.pos_long = self.pos
                self.pos_short = 0
            elif self.pos < 0:
                self.pos_short = abs(self.pos)
                self.pos_long = 0
            else:
                self.pos_long = self.pos_short = 0

    def on_init(self) -> None:
        """策略初始化"""
        self.write_log("策略初始化完成 - 读取fuwen回测参数")
        print(f"\n【策略启动信息】")
        print(f"策略名称: {self.strategy_name}")
        print(f"交易合约: {self.fw_symbol}")
        print(f"默认交易手数: {self.默认交易数量}")
        print(f"初始资金: {self.初始资金:.2f} 元 (来自fuwen界面配置)")
        print(f"手续费率: {self.手续费率 * 10000} ‰（万{self.手续费率 * 10000}）")
        print(f"滑点设置: {self.滑点} 点")
        print(f"合约乘数: {self.合约乘数}")
        print("-" * 120)

    def on_bar(self, bar: BarData):
        """K线数据处理 - 触发交易指令"""
        self.last_bar = bar  # 保存最后一根K线用于平仓

        # 统一管理的交易指令列表
        预计交易订单列表 = [
            {"时间": "2026-03-09 10:34", "操作": "开多"},
            {"时间": "2026-03-09 10:57", "操作": "平多"},
            # {"时间": "2026-03-09 11:00", "操作": "开空"},
            # {"时间": "2026-03-09 11:30", "操作": "平空"},
        ]

        # 格式化当前K线时间
        当前时间 = bar.datetime.strftime("%Y-%m-%d %H:%M")

        # 操作映射
        操作映射 = {
            "开多": (self.buy, Direction.LONG, Offset.OPEN),
            "平多": (self.sell, Direction.LONG, Offset.CLOSE),
            "开空": (self.short, Direction.SHORT, Offset.OPEN),
            "平空": (self.cover, Direction.SHORT, Offset.CLOSE)
        }

        # 遍历交易指令
        for 指令 in 预计交易订单列表:
            if 当前时间 == 指令["时间"]:
                价格 = bar.close_price
                数量 = 指令.get("手数", self.默认交易数量)
                操作方法, 方向, 开平 = 操作映射[指令["操作"]]

                # 记录触发信息
                self.write_log(f"触发{指令['操作']}指令 | 触发时间: {当前时间} | 委托价格: {价格} | 委托手数: {数量}")
                print(f"\n【触发交易指令】")
                print(f"操作类型: {指令['操作']} | 触发时间: {当前时间}")
                print(f"委托价格: {价格:.2f} | 委托手数: {数量}")

                # 执行交易操作
                try:
                    vt_orderids = 操作方法(price=价格, volume=数量)
                    for vt_orderid in vt_orderids:
                        self.委托订单缓存[vt_orderid] = {
                            "操作类型": 指令["操作"],
                            "触发时间": 当前时间,
                            "委托价格": 价格,
                            "委托手数": 数量,
                            "委托时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "bar_close": bar.close_price
                        }
                except Exception as e:
                    print(f"【委托失败】{指令['操作']} | 错误信息: {str(e)}")
                    self.write_log(f"委托失败: {指令['操作']} | 错误: {str(e)}")

    def on_trade(self, trade: TradeData):
        """成交回报回调 - 计算资金"""
        if trade.fw_symbol != self.fw_symbol:
            return

        # 更新持仓
        if trade.direction == Direction.LONG:
            if trade.offset == Offset.OPEN:
                self.pos_long += trade.volume
            else:
                self.pos_long -= trade.volume
        else:
            if trade.offset == Offset.OPEN:
                self.pos_short += trade.volume
            else:
                self.pos_short -= trade.volume

        # 生成交易序号
        self.交易序号 += 1

        # 转换操作类型为中文
        方向映射 = {Direction.LONG: "多", Direction.SHORT: "空"}
        开平映射 = {Offset.OPEN: "开", Offset.CLOSE: "平"}
        操作类型 = f"{开平映射[trade.offset]}{方向映射[trade.direction]}"

        # 计算成交金额（使用从界面读取的合约乘数）
        成交金额 = trade.price * trade.volume * self.合约乘数

        # 计算手续费（使用从界面读取的手续费率）
        手续费 = 成交金额 * self.手续费率
        self.总手续费 += 手续费

        # 计算滑点成本（使用从界面读取的滑点）
        委托信息 = self.委托订单缓存.get(trade.vt_orderid, {})
        委托价格 = 委托信息.get("bar_close", trade.price)
        if 操作类型 == "开多" or 操作类型 == "平空":
            滑点成本 = (trade.price - 委托价格 + self.滑点) * trade.volume * self.合约乘数
        else:
            滑点成本 = (委托价格 - trade.price + self.滑点) * trade.volume * self.合约乘数
        self.总滑点成本 += abs(滑点成本)

        # 计算单笔盈亏
        单笔盈亏 = 0
        if 操作类型 == "平多":
            开仓记录 = [x for x in self.成交记录 if x["操作类型"] == "开多" and x["未平仓手数"] > 0]
            if 开仓记录:
                开仓均价 = sum([x["成交价格"] * x["未平仓手数"] for x in 开仓记录]) / sum(
                    [x["未平仓手数"] for x in 开仓记录])
                单笔盈亏 = (trade.price - 开仓均价) * trade.volume * self.合约乘数
                for record in 开仓记录:
                    if record["未平仓手数"] >= trade.volume:
                        record["未平仓手数"] -= trade.volume
                        break
        elif 操作类型 == "平空":
            开仓记录 = [x for x in self.成交记录 if x["操作类型"] == "开空" and x["未平仓手数"] > 0]
            if 开仓记录:
                开仓均价 = sum([x["成交价格"] * x["未平仓手数"] for x in 开仓记录]) / sum(
                    [x["未平仓手数"] for x in 开仓记录])
                单笔盈亏 = (开仓均价 - trade.price) * trade.volume * self.合约乘数
                for record in 开仓记录:
                    if record["未平仓手数"] >= trade.volume:
                        record["未平仓手数"] -= trade.volume
                        break

        # 更新总盈亏和当前资金
        self.总盈亏 += 单笔盈亏
        self.当前资金 = self.初始资金 + self.总盈亏 - self.总手续费 - self.总滑点成本

        # 记录开仓信息
        if 操作类型 in ["开多", "开空"]:
            self.成交记录.append({
                "操作类型": 操作类型,
                "成交价格": trade.price,
                "成交手数": trade.volume,
                "未平仓手数": trade.volume,
                "成交时间": trade.datetime
            })

        # 获取持仓变化
        净持仓 = self.pos_long - self.pos_short
        持仓变化 = f"多头{self.pos_long}手 | 空头{self.pos_short}手 | 净{净持仓}手"

        # 完整交易记录
        交易记录 = {
            "交易序号": self.交易序号,
            "操作类型": 操作类型,
            "触发时间": 委托信息.get("触发时间", "未知"),
            "委托时间": 委托信息.get("委托时间", "未知"),
            "成交时间": trade.datetime.strftime("%Y-%m-%d %H:%M:%S"),
            "成交价格": trade.price,
            "成交手数": trade.volume,
            "成交金额": 成交金额,
            "手续费": 手续费,
            "滑点成本": abs(滑点成本),
            "单笔盈亏": 单笔盈亏,
            "累计盈亏": self.总盈亏,
            "当前资金": self.当前资金,
            "订单编号": trade.vt_orderid,
            "持仓变化": 持仓变化
        }

        # 添加到交易记录列表
        self.交易记录列表.append(交易记录)

        # 打印成交详情
        print("\n" + "=" * 120)
        print(f"【第{self.交易序号}笔成交记录】")
        print(f"操作类型: {操作类型} | 成交时间: {trade.datetime.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"成交价格: {trade.price:.2f} | 成交手数: {trade.volume} | 成交金额: {成交金额:.2f}")
        print(f"手续费: {手续费:.2f} | 滑点成本: {abs(滑点成本):.2f} | 单笔盈亏: {单笔盈亏:.2f}")
        print(f"累计盈亏: {self.总盈亏:.2f} | 当前资金: {self.当前资金:.2f}")
        print(f"订单编号: {trade.vt_orderid} | 当前持仓: {持仓变化}")
        print("=" * 120)

        # 写入日志
        self.write_log(
            f"成交[{操作类型}] | 价格:{trade.price} | 手数:{trade.volume} | 盈亏:{单笔盈亏:.2f} | 资金:{self.当前资金:.2f}")

    def on_stop(self):
        """策略结束时自动平仓并计算最终资金"""
        print("\n" + "=" * 120)
        print("【策略结束 - 开始平仓】")

        # 获取平仓价格
        平仓价格 = self.last_bar.close_price if hasattr(self, 'last_bar') else (
            self.成交记录[-1]["成交价格"] if self.成交记录 else 1.0)

        平仓记录 = []

        # 平掉所有多头持仓
        if self.pos_long > 0:
            print(f"自动平多 | 持仓手数: {self.pos_long} | 平仓价格: {平仓价格:.2f}")
            开仓均价 = sum([x["成交价格"] * x["未平仓手数"] for x in self.成交记录 if x["操作类型"] == "开多"]) / sum(
                [x["未平仓手数"] for x in self.成交记录 if x["操作类型"] == "开多"]) if self.成交记录 else 平仓价格
            平仓盈亏 = (平仓价格 - 开仓均价) * self.pos_long * self.合约乘数
            平仓手续费 = 平仓价格 * self.pos_long * self.合约乘数 * self.手续费率

            self.总盈亏 += 平仓盈亏
            self.总手续费 += 平仓手续费
            self.当前资金 = self.初始资金 + self.总盈亏 - self.总手续费 - self.总滑点成本

            平仓记录.append({
                "操作": "自动平多",
                "手数": self.pos_long,
                "开仓均价": 开仓均价,
                "平仓价格": 平仓价格,
                "盈亏": 平仓盈亏,
                "手续费": 平仓手续费
            })
            self.pos_long = 0

        # 平掉所有空头持仓
        if self.pos_short > 0:
            print(f"自动平空 | 持仓手数: {self.pos_short} | 平仓价格: {平仓价格:.2f}")
            开仓均价 = sum([x["成交价格"] * x["未平仓手数"] for x in self.成交记录 if x["操作类型"] == "开空"]) / sum(
                [x["未平仓手数"] for x in self.成交记录 if x["操作类型"] == "开空"]) if self.成交记录 else 平仓价格
            平仓盈亏 = (开仓均价 - 平仓价格) * self.pos_short * self.合约乘数
            平仓手续费 = 平仓价格 * self.pos_short * self.合约乘数 * self.手续费率

            self.总盈亏 += 平仓盈亏
            self.总手续费 += 平仓手续费
            self.当前资金 = self.初始资金 + self.总盈亏 - self.总手续费 - self.总滑点成本

            平仓记录.append({
                "操作": "自动平空",
                "手数": self.pos_short,
                "开仓均价": 开仓均价,
                "平仓价格": 平仓价格,
                "盈亏": 平仓盈亏,
                "手续费": 平仓手续费
            })
            self.pos_short = 0

        # 打印最终资金汇总
        print("\n【回测最终结果汇总】")
        print(f"初始资金: {self.初始资金:.2f} 元 (fuwen界面配置)")
        print(f"最终资金: {self.当前资金:.2f} 元")
        print(f"总盈亏: {self.总盈亏:.2f} 元 ({self.总盈亏 / self.初始资金 * 100:.2f}%)")
        print(f"总手续费: {self.总手续费:.2f} 元 (费率: {self.手续费率 * 10000}‰)")
        print(f"总滑点成本: {self.总滑点成本:.2f} 元 (滑点: {self.滑点}点)")
        print(f"最终持仓: 多头{self.pos_long}手 | 空头{self.pos_short}手 (已全部平仓)")
        print(f"总交易笔数: {self.交易序号} 笔")

        # 打印平仓明细
        if 平仓记录:
            print("\n【自动平仓明细】")
            for idx, record in enumerate(平仓记录, 1):
                print(
                    f"{idx}. {record['操作']} | 手数:{record['手数']} | 开仓均价:{record['开仓均价']:.2f} | 平仓价:{record['平仓价格']:.2f} | 盈亏:{record['盈亏']:.2f} | 手续费:{record['手续费']:.2f}")

        print("=" * 120)
        self.write_log(
            f"回测结束 | 初始资金:{self.初始资金:.2f} | 最终资金:{self.当前资金:.2f} | 总盈亏:{self.总盈亏:.2f}")

    def show_all_trades(self):
        """打印所有交易记录汇总"""
        print("\n" + "=" * 120)
        print("【所有交易记录汇总】")
        for record in self.交易记录列表[1:]:
            print(
                f"序号:{record['交易序号']} | 操作:{record['操作类型']} | 成交时间:{record['成交时间']} | 价格:{record['成交价格']:.2f} | "
                f"手数:{record['成交手数']} | 盈亏:{record.get('单笔盈亏', 0):.2f} | 资金:{record.get('当前资金', 0):.2f}"
            )
        print("=" * 120)