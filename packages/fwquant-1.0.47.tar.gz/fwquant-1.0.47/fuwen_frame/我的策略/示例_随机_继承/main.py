from typing import Any, Optional, Dict

from fuwen_frame.公共库.打印日志_福纹框架 import logger
from fuwen_frame.我的策略.策略信号来源_适配器.main import 双均线金叉死叉_信号引擎_适配器, 随机_信号引擎_适配器

from fuwen_frame.我的策略.策略基类.策略 import 策略_基类

class 示例_随机_继承(策略_基类):
    """整合版：示例模板策略 + 模板信号引擎"""
    author = "示例_随机策略"
    下单数量 = 1
    最大持仓量 = 3
    显示列表 = ['author', '下单数量', '最大持仓量']
    parameters = 显示列表

    def __init__(self, cta_engine: Any, strategy_name: str, fw_symbol: str, setting: dict):
        self.最大持仓量 = 3
        self._标的代码 = None
        # 优化点1：从setting加载周期参数（支持外部配置，避免硬编码）
        self.随机种子 = setting.get("随机种子", 10)
        self._信号参数.update({"随机种子": self.随机种子})
        self.parameters = self.显示列表
        super().__init__(cta_engine, strategy_name, fw_symbol, setting)


    def 初始化信号引擎(self, 参数=None):
        """初始化信号引擎（自身即为信号引擎）"""
        if 参数 is None:
            参数 = self._信号参数

        # 优化点2：强制更新周期参数（确保与策略参数一致）
        参数['随机种子'] = self.随机种子
        # 优化点3：增加信号引擎实例判空（避免重复创建）
        if not hasattr(self, '信号引擎实例') or self.信号引擎实例 is None:
            self.信号引擎实例 = 随机_信号引擎_适配器(请求参数=参数)
        else:
            # 复用实例，更新参数（减少对象创建开销）
            self.信号引擎实例._参数 = 参数
            self.信号引擎实例.随机种子 = 参数['随机种子']
