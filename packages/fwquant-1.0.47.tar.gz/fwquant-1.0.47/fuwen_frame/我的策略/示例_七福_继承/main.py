from typing import Any
import pandas as pd

from fw_signal.信号工厂.七福 import 七福信号引擎
from fuwen_frame.我的策略.策略基类.策略 import 策略_基类
from fuwen_adaptor.trader.object import BarData


class 示例_七福_继承(策略_基类):
    """
    七福策略 - 继承基类版本（已修复KeyError崩溃）
    功能与 示例_七福.py 完全一致
    """
    author = "七福_策略"

    # ==================== 策略参数（与原版完全一致） ====================
    均线快周期 = 5  # MA5
    均线中周期 = 20  # MA20
    均线慢周期 = 60  # MA60

    止盈回撤比例 = 0.5
    止损比例 = 0.3
    下单数量 = 1
    最大持仓量 = 2
    开仓成功N分钟后才允许平仓 = 5
    n个周期内查找低点 = 30

    # 暴露给fuwen的参数列表
    显示列表 = [
        'author', '均线快周期', '均线中周期', '均线慢周期',
        '止盈回撤比例', '止损比例', '下单数量', '最大持仓量'
    ]
    parameters = 显示列表
    当前K线索引 = 0
    总K线数量 = 0
    bar_k_lines_df = pd.DataFrame()
    bar_k_lines_list = []

    def __init__(self, cta_engine: Any, strategy_name: str, fw_symbol: str, setting: dict):
        super().__init__(cta_engine, strategy_name, fw_symbol, setting)
        self.update_setting(setting)

    def 初始化信号引擎(self, 参数=None):
        """
        重写基类方法：初始化七福原版信号引擎
        与 示例_七福.py 中的 _初始化七福对象 逻辑完全一致
        """
        # 构建原版七福引擎需要的完整参数
        七福参数 = {
            '订单_id': self.订单_id,
            '仓位': self.仓位,
            '最大持仓量': self.最大持仓量,
            '持仓数量': self.pos,

            '均线快周期': self.均线快周期,
            '均线中周期': self.均线中周期,
            '均线慢周期': self.均线慢周期,
            '止盈回撤比例': self.止盈回撤比例,
            '止损比例': self.止损比例,
            '开仓成功N分钟后才允许平仓': self.开仓成功N分钟后才允许平仓,
            'n个周期内查找低点': self.n个周期内查找低点,

            '当前k线': None,
            '历史k线': None,
            '当前k线时间': self.当前k线时间,
            '当前K线索引': self.当前K线索引,
            '总K线数量_回测': self.总K线数量
        }

        # 创建原版七福信号引擎
        self.信号引擎实例 = 七福信号引擎(参数=七福参数)

        # 回测环境：加载全量历史K线
        try:
            if self.cta_engine.get_engine_type().value in ['回测']:
                history_data = self.cta_engine.history_data
                if history_data:
                    df = self.获得当前回测引擎所有历史数据_df(history_data)
                    self.信号引擎实例.更新历史k线_全量_回测(全量历史k线=df)
        except Exception as e:
            pass

    def on_bar(self, bar: BarData) -> None:
        super().on_bar(bar)
        self.bar_k_lines_list.append(bar)
        self.bar_k_lines_df = pd.DataFrame(self.bar_k_lines_list)
        self.总K线数量 = len(self.bar_k_lines_list)
        self.处理1分钟K线(bar)

    def 处理1分钟K线(self, bar):
        """
        重写基类核心K线处理方法
        完全复刻 示例_七福.py 的开平仓逻辑
        """
        self.当前k线_1分钟 = bar
        self.当前k线时间_1分钟 = bar.datetime.strftime("%Y-%m-%d %H:%M:%S")

        # 同步持仓
        if self.仓位['持仓数量'] != int(self.pos):
            self.仓位['持仓数量'] = int(self.pos)

        # 获取K线
        # ret, f历史k线 = self.获取历史K线(数量=120, 周期="K_1M")
        # if ret != 0:
        #     return

        f历史k线 = self.bar_k_lines_df

        # 增量更新K线到七福引擎
        新k线 = f历史k线[-1:]
        self.信号引擎实例.追加历史k线(新k线=新k线)
        self.信号引擎实例.更新当前k线(当前k线=新k线)

        # ============== 原版逻辑：无持仓 → 判断开仓 ==============
        if abs(int(self.pos)) == 0:
            self._开仓_判断()

        # ============== 原版逻辑：有持仓 → 判断平仓 ==============
        if abs(int(self.pos)) > 0 and self.订单_id != '':
            self._平仓_判断()

        self.put_event()

    # ==================== 修复版：开仓判断（防崩溃） ====================
    def _开仓_判断(self):
        """原版七福开仓信号判断 + 安全获取字段，防止KeyError"""
        参数 = self.信号引擎实例.获取参数()
        参数['持仓数量'] = self.pos
        参数['仓位']['持仓数量'] = self.pos

        result = self.信号引擎实例.开仓检测(参数=参数)
        开仓id = int(result.get("id", "0"))

        # ✅ 修复：安全获取判断详情，不存在就给默认值
        判断详情 = result.get("判断详情", {})
        最终说明 = 判断详情.get("最终说明", "无说明")
        原因 = f"<{开仓id}>{最终说明}"

        下单价格 = result.get('价格') or self.当前k线.close_price

        # 开多
        if 开仓id in [1001, 1003] and self.订单_id == '':
            self.仓位['方向'] = '多头'
            self.开仓(方向="buy", 价格=下单价格, 数量=self.下单数量, 原因=原因)

        # 开空
        if 开仓id in [1002, 1004] and self.订单_id == '':
            self.仓位['方向'] = '空头'
            self.开仓(方向="sell", 价格=下单价格, 数量=self.下单数量, 原因=原因)

    # ==================== 修复版：平仓判断（防崩溃） ====================
    def _平仓_判断(self):
        """原版七福平仓信号判断 + 安全获取字段"""
        result_平仓规则 = self.信号引擎实例.平仓判断(参数=self.信号引擎实例.获取参数())
        平仓规则 = result_平仓规则.get("平仓规则")
        if not 平仓规则:
            return

        推荐平仓方向 = 平仓规则.get('推荐平仓方向', '')
        推荐平仓价格 = 平仓规则.get('推荐平仓价格', 0.0)
        推荐平仓数量 = 平仓规则.get('推荐平仓数量', 0)
        平仓ID = result_平仓规则.get('id', '')

        # ✅ 修复：安全获取原因
        原因文本 = 平仓规则.get("原因", "平仓信号触发")
        原因 = f"<{平仓ID}>{原因文本}"

        self.平仓(
            方向=推荐平仓方向,
            价格=推荐平仓价格,
            数量=推荐平仓数量,
            原因=原因
        )

    # ==================== 工具函数 ====================
    def 获得当前回测引擎所有历史数据_df(self, history_data):
        """与原版完全一致的历史数据转换函数"""
        if not history_data:
            return pd.DataFrame()

        data_list = []
        for bar in history_data:
            data_list.append({
                'open': bar.open_price,
                'high': bar.high_price,
                'low': bar.low_price,
                'close': bar.close_price,
                'volume': bar.volume,
                'time_key': bar.datetime
            })
        df = pd.DataFrame(data_list)
        df['time_key'] = pd.to_datetime(df['time_key'])
        df = df.set_index('time_key').sort_index()
        return df
