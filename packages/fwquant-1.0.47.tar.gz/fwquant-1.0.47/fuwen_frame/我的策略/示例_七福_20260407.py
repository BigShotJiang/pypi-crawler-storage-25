import traceback
from datetime import datetime
from typing import Any, Dict, Optional

import pandas as pd
import numpy as np
from fuwen_ctastrategy import CtaTemplate, StopOrder

from fw_signal.信号工厂.七福 import 七福信号引擎
from fuwen_frame.公共库.打印日志_福纹框架 import logger
from fuwen_frame.我的策略.策略函数.回测交易记录器 import 回测交易记录器类

from fuwen_adaptor.trader.object import TickData, BarData, OrderData, TradeData
from fuwen_adaptor.trader.utility import BarGenerator, ArrayManager

# ========== 性能开关 ==========
写数据库 = False
IS_DEBUG = False

RET_OK = 0


class 示例_七福类20260407(CtaTemplate):
    """高性能版CTA策略类 - 极致性能优化"""

    author = "示例_七福类20260407"

    # 策略参数
    均线快周期 = 5
    均线中周期 = 20
    均线慢周期 = 60
    止盈回撤比例 = 0.5
    止损比例 = 0.3
    下单数量 = 1
    最大持仓量 = 2
    开仓成功N分钟后才允许平仓 = 5
    n个周期内查找低点 = 30

    当前k线时间 = None
    当前K线索引 = 0
    总K线数量 = 0
    回测引擎 = None

    # 策略变量
    订单_id = ''
    仓位 = {'持仓数量': 0, '开仓时间': '', '方向': '', '开仓价格': 0.0, '委托时间': None}
    parameters = ['均线快周期', '均线中周期', '均线慢周期', '止盈回撤比例', '下单数量', '最大持仓量']

    _开仓次数 = 0
    _平仓次数 = 0

    def __init__(self, cta_engine: Any, strategy_name: str, fw_symbol: str, setting: dict):
        super().__init__(cta_engine, strategy_name, fw_symbol, setting)

        self.回测任务ID = None
        self.策略名称 = strategy_name
        self.策略开启时间 = None
        self.策略停止时间 = None

        # 交易记录器（仅在需要时创建）
        self.交易记录器 = 回测交易记录器类(策略名称=strategy_name) if 写数据库 else None

        # K线合成器
        self.bg1 = BarGenerator(self.on_bar, window=1, on_window_bar=self.处理1分钟合成K线)

        # ========== 性能优化：使用numpy数组缓存K线数据 ==========
        self._open_prices = []  # 开盘价列表
        self._high_prices = []  # 最高价列表
        self._low_prices = []  # 最低价列表
        self._close_prices = []  # 收盘价列表
        self._volumes = []  # 成交量列表
        self._time_keys = []  # 时间列表
        self._max_cache_size = 150

        # 预创建的DataFrame（复用）
        self._cached_df = None
        self._cache_valid = False

        self.当前k线 = None
        self.当前k线_1分钟 = None
        self.当前k线时间_1分钟 = None
        self.进度百分比 = 0

        self.am = ArrayManager(size=120)

        self._缓存回测引擎引用()
        self._初始化七福对象()

    def _缓存回测引擎引用(self):
        """缓存回测引擎引用"""
        self.回测引擎 = None
        engine = self.cta_engine

        if hasattr(engine, 'backtesting_engine') and engine.backtesting_engine:
            self.回测引擎 = engine.backtesting_engine
        elif hasattr(engine, 'main_engine') and hasattr(engine.main_engine, 'backtesting_engine'):
            self.回测引擎 = engine.main_engine.backtesting_engine
        elif hasattr(engine, 'engine') and hasattr(engine.engine, 'backtesting_engine'):
            self.回测引擎 = engine.engine.backtesting_engine

    def _获取七福参数配置(self, 更新参数=None) -> Dict[str, Any]:
        if 更新参数 is None:
            更新参数 = {}
        res_配置 = {
            '订单_id': self.订单_id,
            '仓位': self.仓位,
            '最大持仓量': self.最大持仓量,
            '持仓数量': self.pos,
            '均线快周期': self.均线快周期,
            '均线中周期': self.均线中周期,
            '均线慢周期': self.均线慢周期,
            '止盈回撤比例': self.止盈回撤比例,
            '止损比例': self.止损比例,
            '开仓成功N分钟后才允许平仓': self.开仓成功N分钟后才允许平仓,
            'n个周期内查找低点': self.n个周期内查找低点,
            '当前k线': None,
            '历史k线': None,
            '当前k线时间': self.当前k线时间,
            '当前k线索引': self.当前K线索引,
            '总K线数量_回测': self.总K线数量
        }
        if 更新参数 and isinstance(更新参数, dict):
            res_配置.update(更新参数)
        return res_配置

    def _初始化七福对象(self):
        参数 = self._获取七福参数配置()
        self.七福对象 = 七福信号引擎(参数=参数)

        if self.cta_engine.get_engine_type().value in ['回测']:
            数量 = len(self.cta_engine.history_data)
            if 数量 > 0:
                历史k线_全量_回测 = self.获得当前回测引擎所有历史数据_df(self.cta_engine.history_data)
                参数['历史k线_全量_回测'] = 历史k线_全量_回测
                self.七福对象.更新历史k线_全量_回测(全量历史k线=历史k线_全量_回测)

    def on_init(self) -> None:
        self._初始化七福对象()
        self._平仓次数 = 0
        self._开仓次数 = 0

        if self.cta_engine.get_engine_type().value in ['回测']:
            self.总K线数量 = len(self.cta_engine.history_data)
        else:
            self.总K线数量 = -1

    def on_start(self) -> None:
        self._初始化七福对象()
        self.策略开启时间 = datetime.now()
        logger.info(f"策略启动")

        if self.cta_engine.get_engine_type().value in ['回测'] and 写数据库:
            self.创建回测任务()

        self.put_event()

    def on_stop(self) -> None:
        self.策略停止时间 = datetime.now()
        logger.info(f"策略停止")

        if self.cta_engine.get_engine_type().value in ['回测'] and 写数据库:
            self.更新回测任务()
            self._导出交易记录()

        self.put_event()

    def on_tick(self, tick: TickData) -> None:
        self.bg1.update_tick(tick)

    def on_bar(self, bar: BarData) -> None:
        """Bar数据更新 - 极简版"""
        self.当前k线时间 = datetime.strftime(bar.datetime, '%Y-%m-%d %H:%M')
        self.当前k线 = bar
        self.当前K线索引 += 1

        if self.总K线数量 == 0:
            self.总K线数量 = len(self.cta_engine.history_data)

        # 更新K线合成器
        self.bg1.update_bar(bar)

        # ========== 性能优化：使用列表存储，避免频繁创建对象 ==========
        self._open_prices.append(bar.open_price)
        self._high_prices.append(bar.high_price)
        self._low_prices.append(bar.low_price)
        self._close_prices.append(bar.close_price)
        self._volumes.append(bar.volume)
        self._time_keys.append(bar.datetime)

        # 限制缓存大小
        if len(self._open_prices) > self._max_cache_size:
            self._open_prices.pop(0)
            self._high_prices.pop(0)
            self._low_prices.pop(0)
            self._close_prices.pop(0)
            self._volumes.pop(0)
            self._time_keys.pop(0)

        self._cache_valid = False  # 缓存失效
        self.am.update_bar(bar)

    def on_order(self, order: OrderData) -> None:
        if not order.is_active():
            self.仓位['委托时间'] = order.datetime
            self.put_event()

    def on_trade(self, trade: TradeData) -> None:
        super().on_trade(trade)

        if trade.offset.value in ["CLOSE", "CLOSETODAY", "CLOSEYESTERDAY"]:
            self.订单_id = ""
            self.仓位['持仓数量'] = 0
            self.仓位['平仓时间'] = trade.datetime
            self.仓位['平仓成交价格'] = trade.price
        else:
            self.仓位['持仓数量'] = int(self.pos)
            self.仓位['开仓时间'] = trade.datetime
            self.仓位['开仓成交价格'] = trade.price

        self.put_event()

    def on_stop_order(self, stop_order: StopOrder) -> None:
        pass

    def 处理1分钟合成K线(self, bar: BarData) -> None:
        """1分钟合成K线 - 核心交易逻辑"""
        self.当前k线_1分钟 = bar
        self.当前k线时间_1分钟 = bar.datetime.strftime("%Y-%m-%d %H:%M:%S")

        # 同步持仓
        if self.仓位['持仓数量'] != int(self.pos):
            self.仓位['持仓数量'] = int(self.pos)

        # 更新K线到七福引擎
        if self._更新七福K线():
            if abs(int(self.pos)) == 0:
                self._开仓_判断(self.七福对象)
            if abs(int(self.pos)) > 0 and self.订单_id != '':
                self._平仓_判断(self.七福对象)

        self.put_event()

    def _更新七福K线(self) -> bool:
        """高性能K线更新 - 直接传递numpy数组转换的DataFrame"""
        if len(self._close_prices) < 2:
            return False

        # 构建DataFrame（仅在缓存失效时）
        if not self._cache_valid or self._cached_df is None:
            self._cached_df = pd.DataFrame({
                'open': self._open_prices,
                'high': self._high_prices,
                'low': self._low_prices,
                'close': self._close_prices,
                'volume': self._volumes,
                'time_key': self._time_keys
            })
            self._cache_valid = True

        # 取最后120根
        df = self._cached_df.tail(120)
        新k线 = df.tail(1)

        # 增量更新
        self.七福对象.追加历史k线(新k线=新k线)
        self.七福对象.更新当前k线(当前k线=新k线)
        return True

    def _开仓_判断(self, 七福对象):
        """开仓判断"""
        参数 = 七福对象.获取参数()
        参数['持仓数量'] = self.pos
        参数['仓位']['持仓数量'] = self.pos
        result = 七福对象.开仓检测(参数=参数)
        开仓id = int(result.get("id", "0"))

        if 开仓id in [1001, 1003] and self.订单_id == '':
            原因 = f"<{开仓id}>{result['判断详情']['最终说明']}"
            下单价格 = result['价格'] if result['价格'] else 七福对象._参数['当前k线'].close.iloc[0]
            备注 = result['判断详情']
            self.仓位['方向'] = '多头'
            self.开仓(方向="buy", 价格=下单价格, 数量=self.下单数量, 原因=原因, 备注=备注)

        if 开仓id in [1002, 1004] and self.订单_id == '':
            原因 = f"<{开仓id}>{result['判断详情']['最终说明']}"
            下单价格 = result['价格'] if result['价格'] else 七福对象._参数['当前k线'].close.iloc[0]
            备注 = result['判断详情']
            self.仓位['方向'] = '空头'
            self.开仓(方向="sell", 价格=下单价格, 数量=self.下单数量, 原因=原因, 备注=备注)

    def _平仓_判断(self, 七福对象):
        """平仓判断"""
        result_平仓规则 = 七福对象.平仓判断(参数=七福对象.获取参数())
        平仓规则 = result_平仓规则.get("平仓规则", None)

        if 平仓规则 is not None:
            推荐平仓方向 = 平仓规则.get('推荐平仓方向', '')
            推荐平仓价格 = 平仓规则.get('推荐平仓价格', 0.0)
            推荐平仓数量 = 平仓规则.get('推荐平仓数量', 0.0)
            平仓ID = result_平仓规则.get('id', '')
            备注 = result_平仓规则
            原因 = f"<{平仓ID}>{平仓规则['原因']}"

            self.平仓(价格=推荐平仓价格, 方向=推荐平仓方向, 数量=推荐平仓数量, 原因=原因, 备注=备注)

    def 获得当前回测引擎所有历史数据_df(self, history_data) -> pd.DataFrame:
        """转换历史数据为DataFrame"""
        if not history_data:
            return pd.DataFrame()

        data_list = []
        for bar in history_data:
            data_list.append({
                'open': bar.open_price,
                'high': bar.high_price,
                'low': bar.low_price,
                'close': bar.close_price,
                'volume': bar.volume,
                'time_key': bar.datetime
            })

        df = pd.DataFrame(data_list)
        df['time_key'] = pd.to_datetime(df['time_key'])
        df = df.set_index('time_key')
        return df

    def 开仓(self, 价格=0, 方向: str = "buy", 数量: int = 1, 原因: str | Dict[str, Any] = "", 备注=None) -> tuple:
        """开仓函数"""
        self._开仓次数 += 1

        try:
            if abs(self.pos) >= abs(self.最大持仓量):
                return -1, "超出最大持仓限制"

            开仓成功订单号 = ""
            if 方向 in ("buy", "long"):
                开仓成功订单号 = self.buy(价格, 数量)
            elif 方向 in ("sell", "short"):
                开仓成功订单号 = self.short(价格, 数量)

            if 开仓成功订单号:
                self.订单_id = 开仓成功订单号
                self.仓位.update({
                    '开仓订单id': 开仓成功订单号,
                    '持仓数量': int(self.pos),
                    '开仓数量': 数量,
                    '开仓价格': 价格,
                    '开仓方向': 方向,
                    '委托开仓时间': self.当前k线.datetime
                })
                return 0, {'状态': 'success', '订单号': 开仓成功订单号}
            return -1, {'状态': 'failed'}

        except Exception as e:
            return -2, f"开仓异常: {str(e)}"

    def 平仓(self, 方向: str = "buy", 价格=0, 数量: int = 0, 原因: str | Dict[str, Any] = "", 备注=None):
        """平仓函数"""
        self._平仓次数 += 1

        if 数量 == 0:
            数量 = abs(int(self.pos))

        平仓成功订单号 = ""

        if self.pos > 0:
            if 方向 in ("buy", "long"):
                平仓成功订单号 = self.sell(价格, 数量)
            else:
                return -1, f"平多失败: 持仓方向不匹配"
        elif self.pos < 0:
            if 方向 in ("sell", "short"):
                平仓成功订单号 = self.cover(价格, 数量)
            else:
                return -2, f"平空失败: 持仓方向不匹配"
        else:
            return -3, "无持仓"

        if 平仓成功订单号:
            self.订单_id = ""
            self.仓位.update({
                '平仓订单id': 平仓成功订单号,
                '平仓数量': 数量,
                '平仓价格': 价格,
                '平仓方向': 方向,
                '持仓数量': 0,
                '平仓下单时间': self.当前k线.datetime
            })
            return 0, {'order_id': 平仓成功订单号}

        return -4, "平仓失败"

    def 获取引擎环境(self):
        return self.cta_engine.get_engine_type().value

    def _导出交易记录(self):
        if not 写数据库 or not self.交易记录器:
            return {}
        try:
            if self.交易记录器.获取交易统计().get("总交易数", 0) > 0:
                return {"success": True, "file_path": self.交易记录器.导出交易记录()}
        except Exception as e:
            return {"success": False, "msg": str(e)}
        return {"success": True, "msg": "无交易记录"}

    def 创建回测任务(self):
        if not 写数据库 or not self.交易记录器:
            return {}
        result = self.交易记录器.创建回测任务(
            cta_engine=self.cta_engine, strategy=self,
            回测名称=self.回测任务ID or self.策略名称,
            交易品种=self.cta_engine.symbol,
            初始资金=self.cta_engine.capital,
            手续费率=self.cta_engine.rate,
            滑点=self.cta_engine.risk_free,
            合约乘数=self.cta_engine.size,
            回测备注="七福策略回测"
        )
        self.回测任务ID = result.get('回测任务ID')
        return result

    def 更新回测任务(self):
        if not 写数据库 or not self.交易记录器:
            return {}
        return self.交易记录器.更新回测任务(
            cta_engine=self.回测引擎 or self.cta_engine,
            回测任务ID=self.回测任务ID,
            回测状态="已完成",
            回测备注=f"总耗时：{self.策略停止时间 - self.策略开启时间}"
        )