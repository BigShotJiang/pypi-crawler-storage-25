import sys
import time
import os
from datetime import datetime
from typing import cast

# 添加路径以便导入福纹组件
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from fuwen_adaptor.event import EventEngine
from fuwen_adaptor.trader import setting
from fuwen_adaptor.trader.constant import Direction, Exchange, Offset, OrderType
from fuwen_adaptor.trader.object import OrderRequest, SubscribeRequest
from fuwen_frame.gateway.fw_adaptor.trader.engine import fw_MainEngine
from fuwen_frame.gateway.fw_okx.OkxGateway import fw_OkxGateway

from fuwen import logger


def on_tick(event):
    tick = event.data
    logger.info(f"收到行情: {tick.fw_symbol} - 最新价: {tick.last_price}")


def on_order(event):
    order = event.data
    logger.info(f"订单更新: {order.vt_orderid} - 状态: {order.status}")


def on_trade(event):
    trade = event.data
    logger.info(f"成交回报: {trade.vt_tradeid} - 价格: {trade.price} - 数量: {trade.volume}")


def on_position(event):
    position = event.data
    logger.info(f"持仓更新: {position.vt_positionid} - 持仓量: {position.volume}")


def main():
    event_engine = EventEngine()
    main_engine = fw_MainEngine(event_engine)
    gateway = cast(fw_OkxGateway, main_engine.add_gateway(fw_OkxGateway, gateway_name="OKX"))

    logger.info("连接OKX...")
    setting_okx = setting.load_json("connect_okx.json")
    main_engine.connect(setting_okx, gateway_name="OKX")

    max_wait_seconds = 30
    wait_interval = 0.5
    elapsed = 0

    while elapsed < max_wait_seconds:
        contracts = main_engine.get_all_contracts()
        if contracts:
            logger.info(f"合约数据加载完成，耗时 {elapsed:.1f} 秒")
            break
        time.sleep(wait_interval)
        elapsed += wait_interval
    else:
        logger.info(f"等待 {max_wait_seconds} 秒后合约数据仍未加载")

    contracts = main_engine.get_all_contracts()  # 所有可用合约
    symbols = [c.symbol for c in contracts]  # 合约符号列表
    symbols = sorted(symbols)  # 排序
    logger.info(f"合约列表=[{symbols[:10]}] ，\n 共找到合约[{len(contracts)}]个")

    elapsed = 0
    logger.info(f"等待 WebSocket 连接...")
    websocket_ready = False

    while elapsed < max_wait_seconds:
        if hasattr(gateway, 'private_api'):
            private_api = gateway.private_api
            if hasattr(private_api, 'connected') and private_api.connected:
                logger.info(f"WebSocket 连接完成，耗时 {elapsed:.1f} 秒")
                websocket_ready = True
                break
            else:
                logger.info(
                    f"等待中... ({elapsed:.1f}s) - private_api.connected = {getattr(private_api, 'connected', 'N/A')}")
        time.sleep(wait_interval)
        elapsed += wait_interval
    else:
        logger.info(f"等待 {max_wait_seconds} 秒后 WebSocket 仍未连接")

    if not websocket_ready:
        logger.info("WebSocket 未就绪，无法发送订单")
        main_engine.close()
        return

    contract = main_engine.get_contract("BTCUSDT_SWAP_OKX.GLOBAL")

    if not contract:
        logger.info("合约未找到")
        main_engine.close()
        return

    logger.info(f"找到合约: {contract.name}")
    order_req = OrderRequest(
        symbol="BTCUSDT_SWAP_OKX",
        exchange=Exchange.GLOBAL,
        direction=Direction.LONG,
        type=OrderType.MARKET,
        volume=0.01,
        price=0,
        offset=Offset.OPEN
    )

    logger.info(f"发送订单: {order_req}")
    try:
        orderid = main_engine.send_order(order_req, "OKX")
        logger.info(f"开单完成，订单ID: {orderid}")
    except Exception as e:
        logger.info(f"发送订单失败: {e}")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("\n关闭连接...")
        main_engine.close()


if __name__ == "__main__":
    main()
