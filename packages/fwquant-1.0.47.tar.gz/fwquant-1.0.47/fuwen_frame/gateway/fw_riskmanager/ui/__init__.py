from .widget import Fw_RiskManager


__all__ = ["Fw_RiskManager"]
