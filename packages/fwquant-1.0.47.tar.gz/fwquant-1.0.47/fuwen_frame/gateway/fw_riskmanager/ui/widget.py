from PySide6 import QtWidgets

from fuwen_frame.公共库.语言 import _
from fuwen_riskmanager.ui.widget import RuleWidget, RiskManager


class Fw_RiskManager(RiskManager):
    """风控管理器"""
    pass

    def init_ui(self) -> None:
        """初始化UI界面"""
        self.setWindowTitle(_("交易风控"))

        rule_names: list[str] = self.rm_engine.get_all_rule_names()

        self.list_widget: QtWidgets.QListWidget = QtWidgets.QListWidget()
        self.list_widget.addItems(rule_names)

        self.stacked_widget: QtWidgets.QStackedWidget = QtWidgets.QStackedWidget()
        for rule_name in rule_names:
            rule_widget: RuleWidget = RuleWidget(rule_name, self.rm_engine)
            self.stacked_widget.addWidget(rule_widget)
            self.rule_widgets[rule_name] = rule_widget

            data: dict = self.rm_engine.get_rule_data(rule_name)
            rule_widget.update_data(data)

        splitter: QtWidgets.QSplitter = QtWidgets.QSplitter()
        splitter.addWidget(self.list_widget)
        splitter.addWidget(self.stacked_widget)

        vbox: QtWidgets.QVBoxLayout = QtWidgets.QVBoxLayout()
        vbox.addWidget(splitter)
        self.setLayout(vbox)

        self.list_widget.currentRowChanged.connect(self.stacked_widget.setCurrentIndex)
        self.list_widget.setCurrentRow(0)
