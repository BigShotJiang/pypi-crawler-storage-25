from fuwen_frame.gateway.fw_riskmanager.engine import fw_RiskEngine
from fuwen_riskmanager import RiskManagerApp


class fw_RiskManagerApp(RiskManagerApp):
    """"""
    pass
    engine_class: type[fw_RiskEngine] = fw_RiskEngine
