from typing import Any, Dict, List, Optional
from ..exceptions import APIException, ErrorCode


class StrategyRouter:
    def __init__(self):
        self.strategies = {}

    def list_strategies(self) -> List[Dict[str, Any]]:
        return list(self.strategies.values())

    def get_strategy(self, strategy_id: str) -> Optional[Dict[str, Any]]:
        return self.strategies.get(strategy_id)

    def start_strategy(self, strategy_id: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        if strategy_id in self.strategies:
            if self.strategies[strategy_id].get('status') == 'running':
                raise APIException(ErrorCode.STRATEGY_ALREADY_RUNNING, "Strategy already running")
        
        self.strategies[strategy_id] = {
            'id': strategy_id,
            'status': 'running',
            'params': params or {},
            'started_at': None,
            'pnl': 0.0
        }
        return {'message': 'Strategy started successfully', 'strategy_id': strategy_id}

    def stop_strategy(self, strategy_id: str) -> Dict[str, Any]:
        if strategy_id not in self.strategies:
            raise APIException(ErrorCode.STRATEGY_NOT_FOUND, "Strategy not found")
        
        if self.strategies[strategy_id].get('status') != 'running':
            raise APIException(ErrorCode.STRATEGY_NOT_RUNNING, "Strategy is not running")
        
        self.strategies[strategy_id]['status'] = 'stopped'
        return {'message': 'Strategy stopped successfully', 'strategy_id': strategy_id}

    def update_strategy_params(self, strategy_id: str, params: Dict[str, Any]) -> Dict[str, Any]:
        if strategy_id not in self.strategies:
            raise APIException(ErrorCode.STRATEGY_NOT_FOUND, "Strategy not found")
        
        self.strategies[strategy_id]['params'].update(params)
        return {'message': 'Parameters updated successfully', 'strategy_id': strategy_id}