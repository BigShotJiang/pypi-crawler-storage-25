from typing import Any, Dict, List
from ..exceptions import APIException, ErrorCode


class MarketRouter:
    def __init__(self):
        self.market_data = {}

    def get_ticker(self, symbol: str) -> Dict[str, Any]:
        if symbol not in self.market_data:
            raise APIException(ErrorCode.MARKET_DATA_ERROR, f"Symbol {symbol} not found")
        
        return self.market_data[symbol]

    def get_order_book(self, symbol: str, depth: int = 10) -> Dict[str, Any]:
        if symbol not in self.market_data:
            raise APIException(ErrorCode.MARKET_DATA_ERROR, f"Symbol {symbol} not found")
        
        return {
            'symbol': symbol,
            'bids': [],
            'asks': []
        }

    def get_kline(self, symbol: str, interval: str = '1m', limit: int = 100) -> List[Dict[str, Any]]:
        if symbol not in self.market_data:
            raise APIException(ErrorCode.MARKET_DATA_ERROR, f"Symbol {symbol} not found")
        
        return []

    def list_symbols(self) -> List[str]:
        return list(self.market_data.keys())

    def get_market_summary(self) -> Dict[str, Any]:
        return {
            'total_symbols': len(self.market_data),
            'active_symbols': 0
        }