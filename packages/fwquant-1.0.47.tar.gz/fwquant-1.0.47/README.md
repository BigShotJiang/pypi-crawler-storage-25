# FWQuant

一个从 0 到 1 完全自建的量化交易平台。

**📋 项目概述**：FWQuant 是一款企业级量化交易系统，支持 CTP 期货网关和 OKX 数字资产交易，提供策略开发、回测验证、实盘交易、风险管理的完整链路。采用事件驱动架构，内置多种经典策略模板，支持单/多策略并行回测，具备完善的风控体系。

<div style="text-align: center;">
  <img src="fuwen.jpg" alt="fuwen">
</div>

## 快速开始

### 安装

```bash
uv pip install fwquant -U
```

### 启动

```bash
fwquant web run
```

---

## ⚡ 核心功能

| 模块类别 | 核心能力 | 说明 |
|:-------|:--------|:-----|
| **交易网关** | CTP / OKX | 支持期货、数字资产实盘交易 |
| **策略引擎** | CTA策略框架 | 内置6+经典策略模板 |
| **回测系统** | 单/多策略并行 | 支持历史数据回测验证 |
| **风险管理** | 实时风控引擎 | 仓位/止损/熔断管理 |
| **数据管理** | REST/WebSocket | 实时行情与历史数据 |

---

## 📖 文档入口

| 类别   | 文档名称 | 路径 |
|:-----|:-------|:-----|
| **用户指南** | 📦 安装指南 | [docs/用户安装.md](docs/用户安装.md) |
| | 🚀 运行服务 | [docs/运行服务.md](docs/运行服务.md) |
| | 💡 帮助文档 | [docs/help.md](docs/help.md) |
| **程序开发** | 📦 上传打包 | [docs/上传打包_pypi.md](docs/上传打包_pypi.md) |
| | 📝 开发日志 | [docs/开发日志.md](docs/开发日志.md) |
| | 📚 模块文档 | [docs/module_docs/](docs/module_docs/) |
| **综合运维** | 🔧 运维手册 | [docs/运维手册.md](docs/运维手册.md) |

---

<details>
<summary>📦 内置策略（点击展开）</summary>

- **趋势策略**: Dual Thrust、Double MA、King Keltner
- **震荡策略**: ATR-RSI、Boll Channel
- **组合策略**: 七福策略（多规则融合）

</details>

<details>
<summary>🛠️ 技术架构（点击展开）</summary>

- **语言**: Python 3.12+
- **框架**: FastAPI + PyQt5
- **数据库**: SQLite
- **网关**: CTP / OKX API
- **计算**: Pandas / NumPy / TA-Lib

</details>

<details>
<summary>📚 参考工具（点击展开）</summary>

- **VN.PY**: 量化交易框架设计灵感来源
- **backtrader**: 量化回测框架参考
- **crewAI**: AI 智能体协作框架
- **LangChain**: 大语言模型应用框架
- **ccxt**: 交易网关库
</details>

---

**致谢**：感谢 VN.PY、backtrader、crewAI、LangChain 及所有开源社区的贡献！