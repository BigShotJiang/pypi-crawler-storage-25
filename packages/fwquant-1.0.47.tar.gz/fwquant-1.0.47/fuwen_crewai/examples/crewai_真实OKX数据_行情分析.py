#!/usr/bin/env python
import os
import requests
from crewai import Agent, Task, Crew
from dotenv import load_dotenv

load_dotenv()

# 获取OKX真实行情数据（公开接口，无需API Key）
def get_okx_price(symbol="ETH-USDT"):
    url = f"https://www.okx.com/api/v5/market/ticker?instId={symbol}"
    t = requests.get(url).json()['data'][0]
    last = float(t['last'])
    open24h = float(t['open24h'])
    change = last - open24h
    changePct = (change / open24h) * 100
    return f"""【{symbol} 实时行情】
价格: {last:,.2f} USDT
24h涨跌: {change:+.2f} USDT ({changePct:+.2f}%)
最高: {float(t['high24h']):,.2f} USDT
最低: {float(t['low24h']):,.2f} USDT
成交量: {float(t['vol24h']):,.2f} {symbol.split('-')[0]}"""

def main():
    # 获取真实数据
    market_data = get_okx_price("ETH-USDT")
    print("📊 获取到OKX真实行情数据:\n", market_data)

    # 创建Agent（使用字符串配置LLM）
    analyst = Agent(
        role="加密货币分析师",
        goal="分析真实的ETH市场趋势",
        backstory="专业金融分析师，擅长技术分析和市场情绪研判。",
        llm="dashscope/qwen-turbo",
        verbose=True
    )

    # 创建任务
    task = Task(
        description=f"""基于以下真实行情数据进行分析：
    {market_data}
    
    分析要求：
    1. 当前价格走势和趋势方向
    2. 支撑位和压力位分析
    3. 市场情绪判断
    4. 提供操作建议""",
        agent=analyst,
        expected_output="一份包含最新数据、分析和操作建议的市场报告。"
    )

    # 执行分析
    crew = Crew(agents=[analyst], tasks=[task])
    result = crew.kickoff()
    print("\n" + "="*60)
    print("📋 分析报告")
    print("="*60)
    print(result)

if __name__ == '__main__':
    print("Hello, World!")
