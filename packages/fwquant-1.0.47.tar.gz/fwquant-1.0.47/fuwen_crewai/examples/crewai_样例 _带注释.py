#!/usr/bin/env python
import logging
# 隐藏 asyncio 调试警告（PyDev 调试器兼容问题）
logging.getLogger('asyncio').setLevel(logging.CRITICAL)

# 导入 crewai 核心组件
from crewai import Agent, Task, Crew
from dotenv import load_dotenv

# 加载 .env 环境变量（API Key 等敏感配置）
load_dotenv(override=True)


def main():
    # ========== 1. 创建 Agent（智能角色） ==========
    # role: 角色名称，定义身份定位
    # goal: 核心目标，明确要完成什么
    # backstory: 背景故事，赋予角色专业背景
    # llm: 模型配置，格式 "厂商/模型名"（需在 .env 配置对应 API）
    agent = Agent(
        role="加密货币分析师",
        goal="分析加密货币市场趋势",
        backstory="资深加密货币市场分析师，擅长技术分析和基本面研究",
        llm="openai/qwen-turbo"  # 使用阿里云通义千问
    )

    # ========== 2. 创建 Task（任务） ==========
    # description: 任务描述，详细说明要做什么
    # agent: 指定执行任务的 Agent
    # expected_output: 期望输出格式和内容要求
    task = Task(
        description="分析ETH当前市场趋势，包括近期价格走势、关键支撑压力位、市场情绪指标",
        agent=agent,
        expected_output="结构化的市场分析报告，包含分析结论和投资建议"
    )

    # ========== 3. 创建 Crew（团队）并执行 ==========
    # agents: Agent 列表，可包含多个角色协作
    # tasks: Task 列表，任务队列
    # kickoff(): 启动执行，返回结果
    result = Crew(agents=[agent], tasks=[task]).kickoff()

    # 输出最终结果
    print(result)


if __name__ == '__main__':
    main()