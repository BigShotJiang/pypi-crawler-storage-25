"""
公共工具函数

该模块包含基础的工具函数，不依赖任何业务模块，避免循环导入。
"""
import socket

import json

from pathlib import Path


from fuwen_config.常量.常量定义 import 福纹配置目录名称

import socket

import socket

import socket

def get_local_ip():
    """
    100% 获取本机 局域网 IPv4 地址（Windows / Linux / Mac 通用）
    不连外网、不搞虚的，直接读取本机网卡
    """
    ip_list = []

    # 获取本机所有网卡的真实 IP
    try:
        # 获取本机计算机名
        hostname = socket.getfqdn()
        # 获取本机所有IP列表
        addrinfo = socket.gethostbyname_ex(hostname)[-1]

        for ip in addrinfo:
            # 过滤：只保留内网IP
            if ip == "127.0.0.1":
                continue
            if ip.startswith("::"):
                continue
            if ip.startswith("169.254"):
                continue

            # 内网标准网段
            if (
                    ip.startswith("192.168.")
                    or ip.startswith("10.")
                    or (ip.startswith("172.") and 16 <= int(ip.split(".")[1]) <= 31)
            ):
                ip_list.append(ip)

    except Exception:
        pass

    # 方案 B：兜底（不连外网，纯本地获取）
    if not ip_list:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("10.255.255.255", 1))  # 不产生真实流量
            ip = s.getsockname()[0]
            s.close()
            if ip != "127.0.0.1" and not ip.startswith("169.254"):
                ip_list.append(ip)
        except Exception:
            pass

    # 返回第一个有效IP，没有就返回127.0.0.1
    return ip_list[0] if ip_list else "127.0.0.1"


def _get_trader_dir(temp_name: str) -> tuple[Path, Path]:
    """
    Get path where trader is running in.
    """
    cwd: Path = Path.cwd()
    temp_path: Path = cwd.joinpath(temp_name)

    # If 福纹配置目录名称 folder exists in current working directory,
    # then use it as trader running path.
    if temp_path.exists():
        return cwd, temp_path

    # Otherwise use home path of system.
    home_path: Path = Path.home()
    temp_path = home_path.joinpath(temp_name)

    # Create 福纹配置目录名称 folder under home path if not exist.
    if not temp_path.exists():
        temp_path.mkdir()

    return home_path, temp_path


TRADER_DIR, TEMP_DIR = _get_trader_dir(福纹配置目录名称)


def get_file_path(filename: str) -> Path:
    """
    Get path for temp file with filename.
    """
    return TEMP_DIR.joinpath(filename)


def save_json(filename: str, data: dict) -> None:
    """
    Save data into json file in temp path.
    """
    filepath: Path = get_file_path(filename)
    with open(filepath, mode="w+", encoding="UTF-8") as f:
        json.dump(
            data,
            f,
            indent=4,
            ensure_ascii=False
        )


def load_json(filename: str) -> dict:
    """
    Load data from json file in temp path.
    """
    filepath: Path = get_file_path(filename)

    if filepath.exists():
        with open(filepath, encoding="UTF-8") as f:
            data: dict = json.load(f)
        return data
    else:
        save_json(filename, {})
        return {}


def fw_float(x) -> float:
    """
    将输入转换为float类型
    
    :param x: 输入值，可以是字符串、数字或其他可转换类型
    :return: 转换后的float值
    """
    if x is None:
        return 0.0
    try:
        return float(x)
    except (ValueError, TypeError):
        return 0.0


if __name__ == '__main__':
    print(f"当前局域网IP: {get_local_ip()}")
