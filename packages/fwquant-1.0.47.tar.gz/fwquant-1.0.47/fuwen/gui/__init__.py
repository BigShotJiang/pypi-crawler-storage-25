"""
FuWen GUI模块

提供图形界面启动和管理功能。
"""

import sys
import os

# 添加项目路径到Python路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# 延迟导入以避免循环依赖
fuwen_frame_loaded = False
gui_run = None


def _load_gui_module():
    """
    延迟加载GUI模块
    
    避免启动时的循环导入问题
    """
    global gui_run, fuwen_frame_loaded
    
    if fuwen_frame_loaded:
        return
    
    try:
        from fuwen_frame.启动程序 import 启动_福纹系统 as gui_run_module
        gui_run = gui_run_module
        fuwen_frame_loaded = True
        print("✅ GUI模块加载成功")
    except ImportError as e:
        print(f"❌ GUI模块加载失败: {e}")
        raise


def start():
    """
    启动福纹量化GUI界面
    
    这是GUI启动的主入口函数。
    """
    print("🚀 启动福纹量化GUI...")
    
    _load_gui_module()
    
    if gui_run is None:
        print("❌ GUI模块未加载成功")
        return
    
    try:
        gui_run.main()
    except Exception as e:
        print(f"❌ GUI启动失败: {e}")
        import traceback
        traceback.print_exc()


def run():
    """
    启动福纹量化GUI（便捷别名）
    """
    start()


if __name__ == '__main__':
    start()