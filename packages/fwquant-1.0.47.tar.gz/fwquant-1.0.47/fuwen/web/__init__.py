"""
FuWen Web服务模块

提供Web服务启动和管理功能。
"""

import socket
import sys
import os
import traceback

from fuwen.core.公共函数 import get_local_ip
from fuwen_config import 默认端口

# 添加项目路径到Python路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))




def initialize_engine():
    """
    初始化引擎
    
    :return: 初始化结果字典
    """
    try:
        from fuwen_web.engine_manager import engine_manager
        print("正在初始化引擎...")
        result = engine_manager.initialize()
        if result["success"]:
            print(f"✅ 引擎初始化成功: {result['msg']}")
            return True
        else:
            print(f"❌ [FWQuant.fuwen.web.initialize_engine]引擎初始化失败: {result['msg']}")
            if 'traceback' in result:
                print(f"   完整堆栈:\n{result['traceback']}")
            return False
    except ImportError as e:
        print(f"❌ 导入引擎管理器失败: {e}")
        return False
    except Exception as e:
        tb_str = traceback.format_exc()
        print(f"❌ 引擎初始化错误: {type(e).__name__}: {e}")
        print(f"   完整堆栈:\n{tb_str}")
        return False


def run(
    host: str = "0.0.0.0",
    port: int = 默认端口,
    reload: bool = False,
    log_level: str = "info"
):
    """
    启动Web服务
    
    :param host: 绑定地址，默认0.0.0.0
    :param port: 服务端口
    :param reload: 是否启用自动重载（开发模式）
    :param log_level: 日志级别
    """
    print(f"🚀 启动福纹量化Web服务...")
    
    # 初始化引擎
    if not initialize_engine():
        print("❌ 引擎初始化失败，无法启动Web服务")
        return
    
    try:
        import uvicorn
        
        local_ip = get_local_ip()
        
        print(f"\n📡 服务配置:")
        print(f"   - 本地地址: http://127.0.0.1:{port}")
        print(f"   - 局域网地址: http://{local_ip}:{port}")
        print(f"   - 外部地址: http://0.0.0.0:{port}")
        print(f"   - 重载模式: {'开启' if reload else '关闭'}")
        print(f"   - 日志级别: {log_level.upper()}")
        
        print(f"\n🔄 启动服务...")
        
        uvicorn.run(
            "fuwen_web.app:app",
            host=host,
            port=port,
            reload=reload,
            log_level=log_level.lower()
        )
        
    except ImportError:
        print("❌ 未安装uvicorn，请先安装: pip install uvicorn")
    except Exception as e:
        print(f"❌ Web服务启动失败: {e}")


if __name__ == "__main__":
    run()