def get_post_pksk(parent_pksk, post_url):
    
    post_slug = post_url.strip('/post/')

    return {
        "pk": parent_pksk,
        "sk": f"post#{post_slug}"
    }

