def listpublic(API) -> dict:
    """
    Fetches the list of public posts from the API.

    Args:
        branch_slug (str): Slug of the branch to fetch posts for.
        Returns:
            dict: The list of public posts.
    """
    post_list = API.make_request("GET", "content", f"post/public", authenticate=True)
    return post_list