def listall(API) -> dict:
    """
    Fetches the list of posts for a given branch from the API.

    Args:
        branch_slug (str): Slug of the branch to fetch posts for.
        Returns:
            dict: The list of posts for the branch.
    """
    post_list = API.make_request("GET", "content", f"post", authenticate=True)
    return post_list