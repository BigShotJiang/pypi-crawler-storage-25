from .Stubs import (
    empty_function as empty_function,
    record_init_args as record_init_args,
    NodeInitArgs as NodeInitArgs,
)
from .ClassHelper import (
    get_class_effective_init as get_class_effective_init,
    clone_class_detached as clone_class_detached,
)
from .ObjectProxy import ObjectProxy as ObjectProxy
from .ObjectProxy import FunctionProxy as FunctionProxy
