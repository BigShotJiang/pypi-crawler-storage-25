from .instrumentation import (
    instrument_openai,
    instrument_anthropic,
    instrument_gemini,
    instrument_groq,
)
from .client import get_runtime_config, start_session, configure, log_llm, log_tool, log_decision, log_error

# NiitakaCallbackHandler is optional — only available when langchain-core is installed.
# Import it directly: from sdk.langchain_handler import NiitakaCallbackHandler
try:
    from .langchain_handler import NiitakaCallbackHandler
except ImportError:
    pass


def auto_instrument():
    """Instrument all installed LLM providers.

    Calls each provider's instrument function and silently skips any that
    are not installed.  Equivalent to calling each function individually.
    """
    instrument_openai()
    instrument_anthropic()
    instrument_gemini()
    instrument_groq()
