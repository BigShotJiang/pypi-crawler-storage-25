"""sdk/instrumentation.py — auto-instrumentation for multiple LLM providers.

Supported providers
-------------------
- OpenAI        — ``instrument_openai()``
- Anthropic     — ``instrument_anthropic()``
- Google Gemini — ``instrument_gemini()``
- Groq          — ``instrument_groq()``

Each function patches the provider's sync completion method in-place so that
every LLM call is automatically:

  1. Evaluated against the active policy set (pre-execution and on-error).
  2. Retried / fallen back according to policy decisions.
  3. Logged as an event (input, output, cost, token counts) to the Niitaka backend.
  4. Counted toward the session's running cost total.

Streaming support
-----------------
When ``stream=True`` is passed, a transparent pass-through generator is returned
instead of a complete response object.  The wrapper yields each chunk to the
caller unchanged, accumulates text and token counts across the stream, then logs
a single event with the full output and accurate cost when the stream exhausts
(or errors).

Usage::

    from sdk import instrument_openai, instrument_anthropic
    instrument_openai()
    instrument_anthropic()
"""
from __future__ import annotations

import json
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import wraps
from typing import Any, Callable, Dict, Iterator, Optional, Tuple

from .client import log_llm, client, AgentExecutionStopped, _session_state
from .policy_engine import (
    EvaluationStage,
    PolicyContext,
    evaluate_policies,
    resolve_actions,
)

# ── Execution ceiling ─────────────────────────────────────────────────────────
MAX_TOTAL_STEPS = 10

# ── Trace sampling ────────────────────────────────────────────────────────────
TRACE_SAMPLE_RATE = 1.0


# ── Provider adapter ──────────────────────────────────────────────────────────

@dataclass
class ProviderAdapter:
    """Normalises provider-specific API shapes for both sync and streaming calls.

    Attributes:
        name:
            Human-readable provider name stored in event metadata.
        get_model:
            Extract the model name from the *kwargs* dict of the call.
        extract_usage:
            For non-streaming responses: extract ``(prompt_tokens, completion_tokens)``
            from the complete response object.
        inject_stream_kwargs:
            Extra kwargs to merge into the call when ``stream=True``.  Used by
            OpenAI and Groq to inject ``stream_options={"include_usage": True}``
            so the final streaming chunk carries token counts.
        extract_stream_chunk:
            For streaming: called on every chunk with the chunk and a mutable
            ``state`` dict (shared across the stream).  Returns
            ``(text_delta, prompt_tokens, completion_tokens)`` where any value
            may be ``None`` if not present in this particular chunk.

            Anthropic is the primary user of ``state`` — input tokens arrive in
            ``message_start`` while output tokens arrive in ``message_delta``, so
            they must be accumulated across separate events.
        apply_config:
            Optional hook that applies runtime config fields (model, temperature,
            max_tokens, system_prompt) to the call kwargs dict before execution.
            Config values always win over the agent's coded defaults.
            Signature: ``(kwargs: dict, config: dict) -> dict``.
    """

    name: str
    get_model: Callable[[dict], str]
    extract_usage: Callable[[Any], Tuple[int, int]]
    inject_stream_kwargs: Dict[str, Any] = field(default_factory=dict)
    extract_stream_chunk: Optional[
        Callable[[Any, dict], Tuple[Optional[str], Optional[int], Optional[int]]]
    ] = None
    apply_config: Optional[Callable[[dict, dict], dict]] = None


# ── Serialization helpers ─────────────────────────────────────────────────────

def _serialize_input(kwargs: dict) -> str:
    """Serialize LLM call kwargs to JSON for storage.

    Stores the full call shape (model, messages, temperature, …) so the UI
    can render the messages array with role chips instead of a Python repr.
    Non-serialisable values (e.g. Pydantic models) are coerced via ``str()``.
    """
    return json.dumps(kwargs, default=str)


def _serialize_response(response: Any) -> str:
    """Serialize a provider response object to a JSON messages array.

    Produces ``[{"role": "assistant", "content": "…", …}]`` so the UI
    message-viewer can display the output with the correct role chip.

    Handles OpenAI/Groq ``ChatCompletion``, Anthropic ``Message``, and
    Gemini ``GenerateContentResponse``.  Falls back to a ``{"raw": …}``
    envelope for any unrecognised shape.
    """
    try:
        # ── OpenAI / Groq ─────────────────────────────────────────────────────
        choices = getattr(response, "choices", None)
        if choices:
            msg = getattr(choices[0], "message", None)
            if msg:
                content = getattr(msg, "content", "") or ""
                # Tool calls (function-calling responses)
                tool_calls = getattr(msg, "tool_calls", None)
                out: Dict[str, Any] = {
                    "role":          getattr(msg, "role", "assistant"),
                    "content":       content,
                    "model":         getattr(response, "model", ""),
                    "finish_reason": getattr(choices[0], "finish_reason", None),
                }
                if tool_calls:
                    out["tool_calls"] = [
                        {
                            "id":       tc.id,
                            "type":     tc.type,
                            "function": {
                                "name":      tc.function.name,
                                "arguments": tc.function.arguments,
                            },
                        }
                        for tc in tool_calls
                    ]
                return json.dumps([out])

        # ── Anthropic ─────────────────────────────────────────────────────────
        content_blocks = getattr(response, "content", None)
        if content_blocks is not None and isinstance(content_blocks, list):
            text_parts = []
            tool_uses = []
            for block in content_blocks:
                block_type = getattr(block, "type", "")
                if block_type == "text":
                    text_parts.append(getattr(block, "text", ""))
                elif block_type == "tool_use":
                    tool_uses.append({
                        "id":    getattr(block, "id", ""),
                        "name":  getattr(block, "name", ""),
                        "input": getattr(block, "input", {}),
                    })
            out = {
                "role":        getattr(response, "role", "assistant"),
                "content":     "\n".join(text_parts),
                "model":       getattr(response, "model", ""),
                "stop_reason": getattr(response, "stop_reason", None),
            }
            if tool_uses:
                out["tool_uses"] = tool_uses
            return json.dumps([out])

        # ── Gemini ────────────────────────────────────────────────────────────
        text = getattr(response, "text", None)
        if text is not None:
            return json.dumps([{"role": "model", "content": text}])

        # ── Generic fallback ──────────────────────────────────────────────────
        try:
            return json.dumps([{"role": "assistant", "content": response.model_dump()}], default=str)
        except Exception:
            return json.dumps([{"role": "assistant", "content": str(response)}])

    except Exception as exc:
        return json.dumps([{"role": "assistant", "content": f"[serialization error: {exc}]"}])


# ── Shared helpers ────────────────────────────────────────────────────────────

def _emit_decision_trace(
    matched: list,
    trace: Any,
    stage: EvaluationStage,
    context: PolicyContext,
) -> None:
    """Post the full decision trace to the backend (non-blocking, sampled)."""
    if random.random() > TRACE_SAMPLE_RATE:
        return
    try:
        client.log_decision_trace({
            "session_id":           _session_state.get("session_id"),
            "evaluation_stage":     stage.value,
            "context":              context.model_dump(),
            "matched_policy_count": len(matched),
            "candidate_actions":    trace.candidate_actions,
            "resolution_reason":    trace.resolution_reason,
            "winning_type":         trace.winning_type,
            "final_decision":       trace.winner,
            "timestamp":            datetime.now(timezone.utc).isoformat(),
        })
    except Exception as e:
        print("Niitaka decision trace failed:", e)


_SIGNAL_TYPE_MAP = {
    "retry":            "control",
    "fallback":         "control",
    "retry_exhausted":  "control",
    "policy_triggered": "policy",
}


def _emit_signal(subtype: str, message: str, data: dict) -> None:
    """Emit one of the four allowed operational signal subtypes."""
    sig_type = _SIGNAL_TYPE_MAP.get(subtype)
    if sig_type is None:
        return
    try:
        client.emit_signal(type=sig_type, subtype=subtype, message=message, data=data)
    except Exception as e:
        print("Niitaka signal failed:", e)


def _cost_from_tokens(model: str, prompt_tokens: int, completion_tokens: int) -> Tuple[float, dict]:
    """Calculate cost from token counts using the pricing module."""
    from .pricing import calculate_cost as _calc
    try:
        pricing_overrides = _session_state.get("pricing", {})
        return _calc(model, prompt_tokens, completion_tokens, overrides=pricing_overrides)
    except Exception:
        return 0.0, {
            "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0,
            "input_cost": 0.0,  "output_cost": 0.0,
            "pricing_source": "error", "pricing_version": "",
        }


def _extract_cost(response: Any, model: str) -> Tuple[float, dict]:
    """Extract token counts from a complete (non-streaming) response then cost it."""
    try:
        usage = getattr(response, "usage", None) or getattr(response, "usage_metadata", None)
        if usage is None:
            raise ValueError("no usage field")

        prompt_tokens = (
            getattr(usage, "prompt_tokens",      None) or
            getattr(usage, "input_tokens",       None) or
            getattr(usage, "prompt_token_count", None) or 0
        )
        completion_tokens = (
            getattr(usage, "completion_tokens",      None) or
            getattr(usage, "output_tokens",          None) or
            getattr(usage, "candidates_token_count", None) or 0
        )
        return _cost_from_tokens(model, prompt_tokens, completion_tokens)
    except Exception:
        return 0.0, {
            "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0,
            "input_cost": 0.0,  "output_cost": 0.0,
            "pricing_source": "error", "pricing_version": "",
        }


# ── Streaming wrapper ─────────────────────────────────────────────────────────

def _wrap_stream(
    raw_stream: Any,
    adapter: ProviderAdapter,
    original_model: str,
    used_model: str,
    kwargs: dict,
    runtime: dict,
    start_time: float,
    policies: list,
) -> Iterator[Any]:
    """Transparent pass-through generator that logs after stream exhaustion.

    Yields every chunk from *raw_stream* unchanged.  After the last chunk
    (or on error), emits one LLM event with the full accumulated text and
    accurate token-based cost.  On success also emits a POST_SUCCESS decision
    trace with the updated session cost so the Evaluate engine has non-zero
    context to replay against.
    """
    text_parts: list = []
    prompt_tokens: int = 0
    completion_tokens: int = 0
    state: dict = {}       # mutable per-stream state for adapters (e.g. Anthropic)
    stream_error: Optional[Exception] = None

    try:
        for chunk in raw_stream:
            if adapter.extract_stream_chunk is not None:
                text_delta, p_t, c_t = adapter.extract_stream_chunk(chunk, state)
                if text_delta:
                    text_parts.append(text_delta)
                if p_t is not None:
                    prompt_tokens = p_t
                if c_t is not None:
                    completion_tokens = c_t
            yield chunk

    except Exception as e:
        stream_error = e
        raise

    finally:
        duration          = time.time() - start_time
        full_output       = "".join(text_parts)
        cost, token_meta  = _cost_from_tokens(used_model, prompt_tokens, completion_tokens)

        meta: dict = {
            "provider":       adapter.name,
            "model":          used_model,
            "original_model": original_model,
            "latency":        duration,
            "streaming":      True,
            "status":         "error" if stream_error else "success",
            "error_type":     type(stream_error).__name__ if stream_error else None,
            "fallback_used":  runtime.get("fallback_used", False),
            "total_steps":    _session_state.get("total_steps", 0),
            **token_meta,
        }
        if stream_error:
            meta["error_message"] = str(stream_error)

        log_llm(
            input=_serialize_input(kwargs),
            # Always log accumulated text — preserves partial output for debugging.
            # Error details are in metadata.error_type / metadata.error_message.
            output=full_output,
            metadata=meta,
            cost=cost,
        )

        # Emit a POST_SUCCESS trace with the session cost that log_llm just
        # accumulated — this gives the Evaluate engine non-zero context to
        # replay policies against.
        if not stream_error and policies:
            try:
                post_ctx = PolicyContext(
                    total_steps=_session_state.get("total_steps", 0),
                    fallback_used=runtime.get("fallback_used", False),
                    cost=_session_state.get("total_cost", 0.0),
                )
                matched = evaluate_policies(policies, post_ctx, EvaluationStage.POST_SUCCESS)
                _, trace = resolve_actions(matched)
                _emit_decision_trace(matched, trace, EvaluationStage.POST_SUCCESS, post_ctx)
            except Exception as e:
                print("Niitaka post-success trace failed (stream):", e)


# ── Runtime config application helpers ───────────────────────────────────────

def _apply_openai_config(kwargs: dict, config: dict) -> dict:
    """Apply runtime config to OpenAI/Groq call kwargs (config always wins)."""
    if config.get("model"):
        kwargs["model"] = config["model"]
    if config.get("temperature") is not None:
        kwargs["temperature"] = config["temperature"]
    if config.get("max_tokens") is not None:
        kwargs["max_tokens"] = config["max_tokens"]
    sys_prompt = config.get("system_prompt")
    if sys_prompt:
        messages = list(kwargs.get("messages") or [])
        if messages and messages[0].get("role") == "system":
            messages[0] = {**messages[0], "content": sys_prompt}
        else:
            messages.insert(0, {"role": "system", "content": sys_prompt})
        kwargs["messages"] = messages
    return kwargs


def _apply_anthropic_config(kwargs: dict, config: dict) -> dict:
    """Apply runtime config to Anthropic call kwargs (config always wins)."""
    if config.get("model"):
        kwargs["model"] = config["model"]
    if config.get("temperature") is not None:
        kwargs["temperature"] = config["temperature"]
    if config.get("max_tokens") is not None:
        kwargs["max_tokens"] = config["max_tokens"]
    sys_prompt = config.get("system_prompt")
    if sys_prompt:
        # Anthropic supports a top-level ``system`` string param; this is
        # cleaner than injecting into messages and also works with streaming.
        kwargs["system"] = sys_prompt
    return kwargs


def _apply_gemini_config(kwargs: dict, config: dict) -> dict:
    """Apply runtime config to Gemini call kwargs (config always wins).

    Gemini uses a nested ``config`` kwarg (``GenerateContentConfig``).  We
    extract it to a plain dict, apply the fields, and put it back so the SDK
    accepts it as-is.
    """
    if config.get("model"):
        kwargs["model"] = config["model"]
    needs_cfg = (
        config.get("temperature") is not None
        or config.get("max_tokens") is not None
        or config.get("system_prompt")
    )
    if needs_cfg:
        gen_cfg = kwargs.get("config")
        if gen_cfg is None:
            gen_cfg = {}
        elif hasattr(gen_cfg, "model_dump"):
            gen_cfg = gen_cfg.model_dump(exclude_none=True)
        elif not isinstance(gen_cfg, dict):
            gen_cfg = {}
        else:
            gen_cfg = dict(gen_cfg)
        if config.get("temperature") is not None:
            gen_cfg["temperature"] = config["temperature"]
        if config.get("max_tokens") is not None:
            gen_cfg["max_output_tokens"] = config["max_tokens"]
        if config.get("system_prompt"):
            gen_cfg["system_instruction"] = config["system_prompt"]
        kwargs["config"] = gen_cfg
    return kwargs


# ── Core instrumentation factory ──────────────────────────────────────────────

def _make_instrumented_fn(original_fn: Callable, adapter: ProviderAdapter) -> Callable:
    """Wrap *original_fn* with Niitaka policy enforcement, retry/fallback, and logging.

    Handles both sync and streaming (``stream=True``) calls:

    - **Sync**: full pre-execution policy → guardrail → retry/fallback loop → log.
    - **Streaming**: pre-execution policy → guardrail → single attempt → return
      transparent ``_wrap_stream`` generator that logs on exhaustion.
      Retry/fallback is skipped for streams because the caller may already be
      consuming chunks by the time an error surfaces mid-stream.
    """

    @wraps(original_fn)
    def wrapped(*args: Any, **kwargs: Any) -> Any:
        start_time     = time.time()
        runtime        = _session_state.get("runtime", {})
        policies       = _session_state.get("policies", [])
        original_model = adapter.get_model(kwargs)
        used_model     = original_model
        attempts       = 0

        # Apply runtime config (experiment variant or active version) before the
        # call.  Config always wins over the agent's hard-coded defaults so that
        # experiment variants and shipped version configs take full effect.
        _rc = _session_state.get("runtime_config")
        _rc_config = (_rc.get("config") or {}) if isinstance(_rc, dict) else {}
        if _rc_config and adapter.apply_config:
            try:
                kwargs = adapter.apply_config(dict(kwargs), _rc_config)
                _cfg_model = adapter.get_model(kwargs)
                if _cfg_model and _cfg_model != original_model:
                    used_model = _cfg_model
            except Exception as _cfg_exc:
                print(f"Niitaka: config application failed ({_cfg_exc}), using original kwargs")

        # ── inner helpers ─────────────────────────────────────────────────────

        def _build_context(**overrides: Any) -> PolicyContext:
            return PolicyContext(
                error_type=overrides.get("error_type"),
                attempts=overrides.get("attempts", attempts),
                total_steps=_session_state.get("total_steps", 0),
                fallback_used=runtime.get("fallback_used", False),
                cost=_session_state.get("total_cost", 0.0),
            )

        def _execute(model: Optional[str]) -> Any:
            new_kw = dict(kwargs)
            if model:
                new_kw["model"] = model
            return original_fn(*args, **new_kw)

        def _handle_final_failure(error: Exception, attempts: int) -> None:
            duration   = time.time() - start_time
            error_type = type(error).__name__
            log_llm(
                input=_serialize_input(kwargs),
                output=str(error),
                metadata={
                    "provider":      adapter.name,
                    "model":         original_model,
                    "error_type":    error_type,
                    "latency":       duration,
                    "attempt":       attempts,
                    "fallback_used": runtime.get("fallback_used", False),
                    "status":        "error",
                    "total_steps":   _session_state.get("total_steps", 0),
                },
                cost=0,
            )
            _emit_signal(
                "retry_exhausted",
                "Retries exhausted — giving up",
                {"attempts": attempts, "error_type": error_type},
            )
            raise error

        # ── pre-execution policy (runs for both sync and streaming) ───────────
        try:
            pre_ctx = _build_context()
            matched = evaluate_policies(policies, pre_ctx, EvaluationStage.PRE_EXECUTION)
            final_action, trace = resolve_actions(matched)
            _emit_decision_trace(matched, trace, EvaluationStage.PRE_EXECUTION, pre_ctx)

            if final_action is not None and final_action.type != "ignore":
                if final_action.type == "stop":
                    _emit_signal(
                        "policy_triggered",
                        "Execution stopped by policy before first attempt",
                        {"final_decision": trace.winner, "reason": trace.resolution_reason},
                    )
                    raise AgentExecutionStopped("Stopped by policy (pre-execution)")

                elif final_action.type == "fallback":
                    if not runtime.get("fallback_used"):
                        # Schema uses "fallback_model"; legacy configs may use "model"
                        used_model = (
                            final_action.params.get("fallback_model")
                            or final_action.params.get("model")
                            or used_model
                        )
                        runtime["fallback_used"] = True
                        _emit_signal(
                            "policy_triggered",
                            f"Pre-execution fallback applied — using model '{used_model}'",
                            {"final_decision": trace.winner, "reason": trace.resolution_reason},
                        )

                elif final_action.type == "retry":
                    runtime["max_retries"] = final_action.params.get(
                        "max_retries", runtime.get("max_retries", client.max_retries)
                    )
                    _emit_signal(
                        "policy_triggered",
                        "Retry policy applied — max_retries updated",
                        {"final_decision": trace.winner, "reason": trace.resolution_reason},
                    )

        except AgentExecutionStopped:
            log_llm(
                input=_serialize_input(kwargs), output="Stopped by policy",
                metadata={
                    "provider":      adapter.name,
                    "error_type":    "PolicyStop",
                    "attempt":       0,
                    "fallback_used": runtime.get("fallback_used", False),
                    "status":        "stop",
                    "stage":         "pre_execution",
                    "total_steps":   _session_state.get("total_steps", 0),
                },
                cost=0,
            )
            raise
        except Exception as e:
            print(f"Niitaka policy evaluation failed (pre, {adapter.name}):", e)

        # ── guardrail (both paths) ────────────────────────────────────────────
        try:
            client.check_cost_guardrail()
            client.check_step_guardrail()
        except AgentExecutionStopped as g:
            log_llm(
                input=_serialize_input(kwargs), output=str(g),
                metadata={
                    "provider":      adapter.name,
                    "error_type":    "GuardrailViolation",
                    "attempt":       0,
                    "fallback_used": False,
                    "status":        "stop",
                    "stage":         "pre_execution",
                    "total_steps":   _session_state.get("total_steps", 0),
                },
                cost=0,
            )
            raise

        # ── streaming path ────────────────────────────────────────────────────
        is_streaming = bool(kwargs.get("stream"))

        if is_streaming:
            # Step counter
            total_steps = _session_state.get("total_steps", 0)
            if total_steps >= MAX_TOTAL_STEPS:
                _emit_signal(
                    "policy_triggered",
                    "Execution stopped: max total steps exceeded",
                    {"total_steps": total_steps, "ceiling": MAX_TOTAL_STEPS},
                )
                raise AgentExecutionStopped(
                    f"Execution stopped: max steps exceeded ({total_steps}/{MAX_TOTAL_STEPS})"
                )
            _session_state["total_steps"] = total_steps + 1

            # Inject provider-specific stream kwargs (e.g. include_usage for OpenAI)
            if adapter.inject_stream_kwargs:
                merged = dict(kwargs)
                for k, v in adapter.inject_stream_kwargs.items():
                    if k not in merged:
                        merged[k] = v
                kwargs = merged

            # Start the stream — errors here (connection, auth) propagate normally
            new_kw = dict(kwargs)
            if used_model:
                new_kw["model"] = used_model
            raw_stream = original_fn(*args, **new_kw)

            # Return transparent wrapper — caller iterates it as normal
            return _wrap_stream(
                raw_stream=raw_stream,
                adapter=adapter,
                original_model=original_model,
                used_model=used_model,
                kwargs=kwargs,
                runtime=runtime,
                start_time=start_time,
                policies=policies,
            )

        # ── sync retry/fallback loop ──────────────────────────────────────────
        max_attempts = runtime.get("max_retries", client.max_retries)

        while True:
            total_steps = _session_state.get("total_steps", 0)
            if total_steps >= MAX_TOTAL_STEPS:
                _emit_signal(
                    "policy_triggered",
                    "Execution stopped: max total steps exceeded",
                    {"total_steps": total_steps, "ceiling": MAX_TOTAL_STEPS},
                )
                raise AgentExecutionStopped(
                    f"Execution stopped: max steps exceeded ({total_steps}/{MAX_TOTAL_STEPS})"
                )

            _session_state["total_steps"] = total_steps + 1

            try:
                response = _execute(used_model)
                break

            except AgentExecutionStopped:
                raise

            except Exception as e:
                error_type = type(e).__name__
                print(f"🔥 ERROR ({adapter.name}): {error_type}, attempt={attempts}")

                err_ctx = _build_context(error_type=error_type, attempts=attempts)
                matched = evaluate_policies(policies, err_ctx, EvaluationStage.ON_ERROR)
                final_action, trace = resolve_actions(matched)
                _emit_decision_trace(matched, trace, EvaluationStage.ON_ERROR, err_ctx)

                if final_action is None or final_action.type == "ignore":
                    return _handle_final_failure(e, attempts)

                if final_action.type == "stop":
                    _emit_signal(
                        "policy_triggered",
                        "Execution stopped by policy on error",
                        {"final_decision": trace.winner, "reason": trace.resolution_reason},
                    )
                    log_llm(
                        input=_serialize_input(kwargs), output=str(e),
                        metadata={
                            "provider":      adapter.name,
                            "error_type":    error_type,
                            "attempt":       attempts,
                            "fallback_used": runtime.get("fallback_used", False),
                            "status":        "stop",
                            "stage":         "on_error",
                            "total_steps":   _session_state.get("total_steps", 0),
                        },
                        cost=0,
                    )
                    raise AgentExecutionStopped("Stopped by policy (on error)")

                if final_action.type == "fallback":
                    if runtime.get("fallback_used"):
                        return _handle_final_failure(e, attempts)
                    # Schema uses "fallback_model"; legacy configs may use "model"
                    fallback_model = (
                        final_action.params.get("fallback_model")
                        or final_action.params.get("model")
                        or used_model
                    )
                    runtime["fallback_used"] = True
                    print(f"↩️  FALLBACK ({adapter.name}) to '{fallback_model}'")
                    _emit_signal("fallback", f"Switching to fallback model '{fallback_model}'",
                                 {"model": fallback_model, "original_error": error_type})
                    _emit_signal("policy_triggered", "Fallback policy applied",
                                 {"final_decision": trace.winner, "reason": trace.resolution_reason})
                    try:
                        response = _execute(fallback_model)
                        used_model = fallback_model
                        break
                    except Exception as fallback_err:
                        return _handle_final_failure(fallback_err, attempts)

                if final_action.type == "retry":
                    max_attempts = final_action.params.get("max_retries", max_attempts)
                    if attempts < max_attempts:
                        attempts += 1
                        print(f"🔁 RETRY ({adapter.name}) {attempts}/{max_attempts}")
                        _emit_signal("retry", f"Retrying attempt {attempts}/{max_attempts}",
                                     {"attempt": attempts, "max_attempts": max_attempts,
                                      "error_type": error_type})
                        _emit_signal("policy_triggered", "Retry policy applied",
                                     {"final_decision": trace.winner, "reason": trace.resolution_reason})
                        # Apply backoff delay before the next attempt
                        base_delay = float(final_action.params.get("backoff_seconds", 2))
                        if base_delay > 0:
                            algo = final_action.params.get("backoff", "exponential")
                            if algo == "linear":
                                delay = base_delay * attempts
                            elif algo == "constant":
                                delay = base_delay
                            else:  # exponential (default)
                                delay = base_delay * (2 ** (attempts - 1))
                            print(f"  ⏱ sleeping {delay:.1f}s ({algo})")
                            time.sleep(delay)
                        continue
                    else:
                        return _handle_final_failure(e, attempts)

        # ── sync success ──────────────────────────────────────────────────────
        duration         = time.time() - start_time
        cost, token_meta = _extract_cost(response, used_model or "")

        log_llm(
            input=_serialize_input(kwargs),
            output=_serialize_response(response),
            metadata={
                "provider":       adapter.name,
                "model":          used_model,
                "original_model": original_model,
                "latency":        duration,
                "streaming":      False,
                "attempt":        attempts,
                "fallback_used":  runtime.get("fallback_used", False),
                "status":         "success",
                "error_type":     None,
                "total_steps":    _session_state.get("total_steps", 0),
                **token_meta,
            },
            cost=cost,
        )

        # Emit a POST_SUCCESS trace after log_llm has updated total_cost so the
        # Evaluate engine sees real cost/step values when replaying policies.
        if policies:
            try:
                post_ctx = _build_context()
                matched = evaluate_policies(policies, post_ctx, EvaluationStage.POST_SUCCESS)
                _, trace = resolve_actions(matched)
                _emit_decision_trace(matched, trace, EvaluationStage.POST_SUCCESS, post_ctx)
            except Exception as e:
                print("Niitaka post-success trace failed (sync):", e)

        return response

    return wrapped


# ── Per-provider chunk extractors ─────────────────────────────────────────────

def _openai_extract_chunk(
    chunk: Any, state: dict
) -> Tuple[Optional[str], Optional[int], Optional[int]]:
    """Extract text delta and usage from one OpenAI/Groq streaming chunk.

    Usage only appears on the final chunk when ``stream_options={"include_usage": True}``
    was passed (which ``inject_stream_kwargs`` handles automatically).
    """
    text = None
    choices = getattr(chunk, "choices", None)
    if choices:
        delta = getattr(choices[0], "delta", None)
        if delta:
            text = getattr(delta, "content", None)

    prompt_t = completion_t = None
    usage = getattr(chunk, "usage", None)
    if usage is not None:
        prompt_t     = getattr(usage, "prompt_tokens",     0) or 0
        completion_t = getattr(usage, "completion_tokens", 0) or 0

    return text, prompt_t, completion_t


def _anthropic_extract_chunk(
    chunk: Any, state: dict
) -> Tuple[Optional[str], Optional[int], Optional[int]]:
    """Extract text delta and usage from one Anthropic streaming event.

    Anthropic's streaming splits token counts across multiple event types:
    - ``message_start``  → input_tokens (stored in *state* for later)
    - ``content_block_delta`` → text delta
    - ``message_delta``  → output_tokens
    - ``message_stop``   → we return the accumulated totals
    """
    event_type = getattr(chunk, "type", None)
    text = prompt_t = completion_t = None

    if event_type == "message_start":
        msg   = getattr(chunk, "message", None)
        usage = getattr(msg, "usage", None) if msg else None
        if usage:
            state["prompt_tokens"] = getattr(usage, "input_tokens", 0) or 0

    elif event_type == "content_block_delta":
        delta = getattr(chunk, "delta", None)
        if delta and getattr(delta, "type", None) == "text_delta":
            text = getattr(delta, "text", None)

    elif event_type == "message_delta":
        usage = getattr(chunk, "usage", None)
        if usage:
            state["completion_tokens"] = getattr(usage, "output_tokens", 0) or 0

    elif event_type == "message_stop":
        # Emit the accumulated totals once, on stream end
        prompt_t     = state.get("prompt_tokens",     0)
        completion_t = state.get("completion_tokens", 0)

    return text, prompt_t, completion_t


def _gemini_extract_chunk(
    chunk: Any, state: dict
) -> Tuple[Optional[str], Optional[int], Optional[int]]:
    """Extract text delta and usage from one Gemini streaming chunk.

    Gemini provides ``usage_metadata`` on every chunk; we take the last
    non-None value so the final chunk's counts (which are cumulative) win.
    """
    text   = getattr(chunk, "text", None)
    prompt_t = completion_t = None

    usage_meta = getattr(chunk, "usage_metadata", None)
    if usage_meta is not None:
        p = getattr(usage_meta, "prompt_token_count",     None)
        c = getattr(usage_meta, "candidates_token_count", None)
        if p is not None:
            prompt_t     = p
            completion_t = c or 0

    return text, prompt_t, completion_t


# ── Per-provider instrument functions ─────────────────────────────────────────

def instrument_openai() -> None:
    """Patch ``openai.resources.chat.completions.Completions.create`` with Niitaka instrumentation.

    Patches at the class level so every ``openai.OpenAI()`` client instance is
    covered, including those created after instrumentation is applied.
    Handles both sync and streaming (``stream=True``) calls.  When streaming,
    ``stream_options={"include_usage": True}`` is injected automatically so that
    the final chunk carries token counts for cost calculation.
    """
    try:
        import openai
    except ImportError:
        print("Niitaka: openai not installed, skipping instrumentation")
        return

    try:
        Completions = openai.resources.chat.completions.Completions
        original    = Completions.create

        # Guard: skip if already patched to avoid stacking wrapper layers.
        if getattr(original, "_niitaka_instrumented", False):
            return

        adapter = ProviderAdapter(
            name="openai",
            get_model=lambda kw: kw.get("model", ""),
            extract_usage=lambda r: (
                getattr(r.usage, "prompt_tokens",     0) or 0,
                getattr(r.usage, "completion_tokens", 0) or 0,
            ),
            inject_stream_kwargs={"stream_options": {"include_usage": True}},
            extract_stream_chunk=_openai_extract_chunk,
            apply_config=_apply_openai_config,
        )
        patched = _make_instrumented_fn(original, adapter)
        patched._niitaka_instrumented = True
        Completions.create = patched
        print("Niitaka: OpenAI instrumentation active")

    except Exception as e:
        print("Niitaka: OpenAI instrumentation failed:", e)


def instrument_anthropic() -> None:
    """Patch ``anthropic.Anthropic().messages.create`` with Niitaka instrumentation.

    Patches at the class level so every client instance is covered.
    Handles both sync and streaming (``stream=True``) calls.
    """
    try:
        import anthropic
    except ImportError:
        print("Niitaka: anthropic not installed, skipping instrumentation")
        return

    try:
        Messages = anthropic.resources.messages.Messages
        original = Messages.create

        # Guard: skip if already patched to avoid stacking wrapper layers.
        if getattr(original, "_niitaka_instrumented", False):
            return

        adapter = ProviderAdapter(
            name="anthropic",
            get_model=lambda kw: kw.get("model", ""),
            extract_usage=lambda r: (
                getattr(r.usage, "input_tokens",  0) or 0,
                getattr(r.usage, "output_tokens", 0) or 0,
            ),
            inject_stream_kwargs={},   # Anthropic doesn't need extra kwargs
            extract_stream_chunk=_anthropic_extract_chunk,
            apply_config=_apply_anthropic_config,
        )
        patched = _make_instrumented_fn(original, adapter)
        patched._niitaka_instrumented = True
        Messages.create = patched
        print("Niitaka: Anthropic instrumentation active")

    except Exception as e:
        print("Niitaka: Anthropic instrumentation failed:", e)


def instrument_gemini() -> None:
    """Patch ``google.genai.models.Models.generate_content`` with Niitaka instrumentation.

    Uses the current ``google-genai`` SDK (``google.genai`` package).  Patches at
    the class level so every ``genai.Client`` instance is automatically covered.

    The ``model`` argument is a keyword argument in the new SDK, so we capture it
    directly from the call kwargs rather than from an instance attribute.
    """
    try:
        from google.genai import models as _genai_models
    except ImportError:
        print("Niitaka: google-genai not installed, skipping instrumentation")
        return

    try:
        Models            = _genai_models.Models
        original_generate = Models.generate_content

        @wraps(original_generate)
        def patched_generate(
            self: Any,
            *,
            model: str = "",
            contents: Any = None,
            config: Any = None,
            **extra: Any,
        ) -> Any:
            # Normalise model name: strip "models/" prefix if present.
            model_name = model
            if model_name.startswith("models/"):
                model_name = model_name[len("models/"):]

            # Flatten all call arguments into a single kwargs dict so that the
            # shared instrumentation framework can inspect and pass them through.
            call_kwargs: Dict[str, Any] = {"model": model_name, "contents": contents}
            if config is not None:
                call_kwargs["config"] = config
            call_kwargs.update(extra)

            adapter = ProviderAdapter(
                name="gemini",
                get_model=lambda kw: kw.get("model", ""),
                extract_usage=lambda r: (
                    getattr(getattr(r, "usage_metadata", None), "prompt_token_count",     0) or 0,
                    getattr(getattr(r, "usage_metadata", None), "candidates_token_count", 0) or 0,
                ),
                inject_stream_kwargs={},
                extract_stream_chunk=_gemini_extract_chunk,
                apply_config=_apply_gemini_config,
            )

            instrumented = _make_instrumented_fn(
                # original_fn receives **kw from the framework; forward to the
                # real method via self so instance state is preserved.
                lambda *a, **kw: original_generate(self, **kw),
                adapter,
            )
            return instrumented(**call_kwargs)

        # Guard: if already patched, skip to avoid stacking wrapper layers.
        if getattr(Models.generate_content, "_niitaka_instrumented", False):
            print("Niitaka: Gemini already instrumented, skipping")
            return

        patched_generate._niitaka_instrumented = True
        Models.generate_content = patched_generate
        print("Niitaka: Gemini instrumentation active")

    except Exception as e:
        print("Niitaka: Gemini instrumentation failed:", e)


def instrument_groq() -> None:
    """Patch ``groq.resources.chat.completions.Completions.create`` with Niitaka instrumentation.

    Groq is OpenAI-compatible — same response shape, same ``stream_options`` support.
    Patches at the class level so every ``groq.Groq()`` client instance is covered.
    """
    try:
        import groq
    except ImportError:
        print("Niitaka: groq not installed, skipping instrumentation")
        return

    try:
        Completions = groq.resources.chat.completions.Completions
        original    = Completions.create

        # Guard: skip if already patched to avoid stacking wrapper layers.
        if getattr(original, "_niitaka_instrumented", False):
            return

        adapter = ProviderAdapter(
            name="groq",
            get_model=lambda kw: kw.get("model", ""),
            extract_usage=lambda r: (
                getattr(r.usage, "prompt_tokens",     0) or 0,
                getattr(r.usage, "completion_tokens", 0) or 0,
            ),
            inject_stream_kwargs={},   # Groq does not support stream_options
            extract_stream_chunk=_openai_extract_chunk,   # same chunk shape as OpenAI
            apply_config=_apply_openai_config,            # same kwargs shape as OpenAI
        )
        patched = _make_instrumented_fn(original, adapter)
        patched._niitaka_instrumented = True
        Completions.create = patched
        print("Niitaka: Groq instrumentation active")

    except Exception as e:
        print("Niitaka: Groq instrumentation failed:", e)


# ── Legacy compatibility ──────────────────────────────────────────────────────

def extract_cost(response: Any, model: str = "") -> Tuple[float, dict]:
    """Backwards-compatible shim — delegates to the shared ``_extract_cost``."""
    return _extract_cost(response, model)
