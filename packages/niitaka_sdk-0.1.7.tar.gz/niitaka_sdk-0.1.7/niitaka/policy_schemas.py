"""policy_schemas.py — JSON Schema definitions for each policy type.

Canonical config structure for all policy types::

    config:
        condition: <type-specific mapping>
        action:    <type-specific mapping>
        priority:  int  (optional, default 0)

Schemas are used by:
  - sdk/policy_loader.py  — validate YAML/JSON policy files on load
  - backend POST /policies — validate single policy creation
  - backend POST /policies/import — validate batch import
  - backend GET /policies/schemas — serve schemas to tooling / UI
"""
from __future__ import annotations

from typing import Dict, Any

# ── Per-type schemas ──────────────────────────────────────────────────────────

#: JSON Schema for the ``condition`` block of each policy type.
CONDITION_SCHEMAS: Dict[str, dict] = {
    "cost_limit": {
        "type": "object",
        "required": ["cost_exceeded"],
        "additionalProperties": False,
        "properties": {
            "cost_exceeded": {
                "type": "number",
                "exclusiveMinimum": 0,
                "description": "Trigger when projected session cost exceeds this dollar amount.",
            },
        },
    },
    "step_limit": {
        "type": "object",
        "required": ["steps_exceeded"],
        "additionalProperties": False,
        "properties": {
            "steps_exceeded": {
                "type": "integer",
                "minimum": 1,
                "description": "Trigger when the agent step count reaches or exceeds this value.",
            },
        },
    },
    "retry": {
        "type": "object",
        "required": ["on_error"],
        "additionalProperties": False,
        "properties": {
            "on_error": {
                "type": "boolean",
                "description": "Trigger when any LLM/tool call raises an error.",
            },
        },
    },
    "fallback": {
        "type": "object",
        "required": ["on_error"],
        "additionalProperties": False,
        "properties": {
            "on_error": {
                "type": "boolean",
                "description": "Trigger when any LLM/tool call raises an error.",
            },
        },
    },
}

#: JSON Schema for the ``action`` block of each policy type.
ACTION_SCHEMAS: Dict[str, dict] = {
    "cost_limit": {
        "type": "object",
        "required": ["type"],
        "additionalProperties": False,
        "properties": {
            "type": {
                "type": "string",
                "enum": ["abort", "warn"],
                "description": "'abort' raises AgentExecutionStopped; 'warn' logs a signal and continues.",
            },
        },
    },
    "step_limit": {
        "type": "object",
        "required": ["type"],
        "additionalProperties": False,
        "properties": {
            "type": {
                "type": "string",
                "enum": ["abort", "warn"],
                "description": "'abort' raises AgentExecutionStopped; 'warn' logs a signal and continues.",
            },
        },
    },
    "retry": {
        "type": "object",
        "required": ["max_retries"],
        "additionalProperties": False,
        "properties": {
            "max_retries": {
                "type": "integer",
                "minimum": 1,
                "description": "Maximum number of retry attempts before giving up.",
            },
            "backoff_seconds": {
                "type": "number",
                "minimum": 0,
                "description": "Seconds to wait between retries. Defaults to 2.",
            },
            "backoff": {
                "type": "string",
                "enum": ["linear", "exponential"],
                "description": "Backoff algorithm. 'linear' waits backoff_seconds each time; "
                               "'exponential' doubles the delay on each attempt. Defaults to 'exponential'.",
            },
            "on_errors": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Optional list of error-type strings to retry on. "
                               "If empty or omitted, retries on any error.",
            },
        },
    },
    "fallback": {
        "type": "object",
        "required": ["fallback_model"],
        "additionalProperties": False,
        "properties": {
            "fallback_model": {
                "type": "string",
                "minLength": 1,
                "description": "Model ID to switch to on error (e.g. 'gpt-4o-mini').",
            },
            "on_errors": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Optional list of error-type strings to fall back on. "
                               "If empty or omitted, falls back on any error.",
            },
        },
    },
}

#: Full per-type schema (condition + action + priority wrapper) — returned by
#: ``GET /policies/schemas`` and used for documentation / UI form generation.
SCHEMAS: Dict[str, dict] = {
    policy_type: {
        "type": "object",
        "required": ["condition", "action"],
        "properties": {
            "condition": CONDITION_SCHEMAS[policy_type],
            "action":    ACTION_SCHEMAS[policy_type],
            "priority": {
                "type": "integer",
                "default": 0,
                "description": "Higher numbers are evaluated first.",
            },
        },
    }
    for policy_type in CONDITION_SCHEMAS
}

KNOWN_TYPES = set(SCHEMAS.keys())


# ── Validation helper ─────────────────────────────────────────────────────────

class PolicyValidationError(ValueError):
    """Raised when a policy config fails schema validation."""


def validate_policy_config(policy_type: str, config: Dict[str, Any]) -> None:
    """Validate *config* against the JSON Schema for *policy_type*.

    *config* must be a dict with ``condition`` and ``action`` sub-dicts.
    Raises :class:`PolicyValidationError` with a human-readable message on
    failure, or does nothing when the config is valid.

    Uses the ``jsonschema`` library when available; falls back to a lightweight
    hand-written check so the SDK stays usable without the extra dependency.
    """
    if policy_type not in KNOWN_TYPES:
        raise PolicyValidationError(
            f"Unknown policy type '{policy_type}'. Allowed: {', '.join(sorted(KNOWN_TYPES))}"
        )

    if not isinstance(config, dict):
        raise PolicyValidationError(
            f"config must be a dict, got {type(config).__name__}"
        )

    condition = config.get("condition")
    action    = config.get("action")

    if not isinstance(condition, dict):
        raise PolicyValidationError(
            f"{policy_type}: config.condition must be a mapping"
        )
    if not isinstance(action, dict):
        raise PolicyValidationError(
            f"{policy_type}: config.action must be a mapping"
        )

    try:
        import jsonschema  # type: ignore
        _validate_with_jsonschema(policy_type, condition, action)
    except ImportError:
        _validate_fallback(policy_type, condition, action)


def _validate_with_jsonschema(
    policy_type: str,
    condition: dict,
    action: dict,
) -> None:
    """Validate using the jsonschema library for precise error messages."""
    import jsonschema  # type: ignore

    for section, schema, value in [
        ("condition", CONDITION_SCHEMAS[policy_type], condition),
        ("action",    ACTION_SCHEMAS[policy_type],    action),
    ]:
        try:
            jsonschema.validate(instance=value, schema=schema)
        except jsonschema.ValidationError as exc:
            # Build a friendly path like "condition.cost_exceeded"
            path = ".".join(str(p) for p in exc.absolute_path)
            location = f"{policy_type} {section}" + (f".{path}" if path else "")
            raise PolicyValidationError(f"{location}: {exc.message}") from exc


def _validate_fallback(policy_type: str, condition: dict, action: dict) -> None:
    """Lightweight validation used when jsonschema is not installed."""
    c_schema = CONDITION_SCHEMAS[policy_type]
    a_schema = ACTION_SCHEMAS[policy_type]

    for section, schema, value in [
        ("condition", c_schema, condition),
        ("action",    a_schema, action),
    ]:
        for required_field in schema.get("required", []):
            if required_field not in value:
                raise PolicyValidationError(
                    f"{policy_type} {section}: missing required field '{required_field}'"
                )

        if schema.get("additionalProperties") is False:
            allowed = set(schema.get("properties", {}).keys())
            extras = set(value.keys()) - allowed
            if extras:
                raise PolicyValidationError(
                    f"{policy_type} {section}: unexpected field(s): {', '.join(sorted(extras))}. "
                    f"Allowed: {', '.join(sorted(allowed))}"
                )

        props = schema.get("properties", {})
        for field, field_schema in props.items():
            if field not in value:
                continue
            val = value[field]
            expected_type = field_schema.get("type")
            if expected_type == "number" and not isinstance(val, (int, float)):
                raise PolicyValidationError(
                    f"{policy_type} {section}.{field}: expected a number, got {type(val).__name__}"
                )
            if expected_type == "integer" and not isinstance(val, int):
                raise PolicyValidationError(
                    f"{policy_type} {section}.{field}: expected an integer, got {type(val).__name__}"
                )
            if expected_type == "boolean" and not isinstance(val, bool):
                raise PolicyValidationError(
                    f"{policy_type} {section}.{field}: expected a boolean, got {type(val).__name__}"
                )
            if expected_type == "string" and not isinstance(val, str):
                raise PolicyValidationError(
                    f"{policy_type} {section}.{field}: expected a string, got {type(val).__name__}"
                )
            if expected_type == "array" and not isinstance(val, list):
                raise PolicyValidationError(
                    f"{policy_type} {section}.{field}: expected a list, got {type(val).__name__}"
                )
            if "enum" in field_schema and val not in field_schema["enum"]:
                raise PolicyValidationError(
                    f"{policy_type} {section}.{field}: '{val}' is not one of "
                    f"{field_schema['enum']}"
                )
            if "minimum" in field_schema and isinstance(val, (int, float)):
                if val < field_schema["minimum"]:
                    raise PolicyValidationError(
                        f"{policy_type} {section}.{field}: must be >= {field_schema['minimum']}, got {val}"
                    )
            if "exclusiveMinimum" in field_schema and isinstance(val, (int, float)):
                if val <= field_schema["exclusiveMinimum"]:
                    raise PolicyValidationError(
                        f"{policy_type} {section}.{field}: must be > {field_schema['exclusiveMinimum']}, got {val}"
                    )
            if "minLength" in field_schema and isinstance(val, str):
                if len(val) < field_schema["minLength"]:
                    raise PolicyValidationError(
                        f"{policy_type} {section}.{field}: must be at least "
                        f"{field_schema['minLength']} character(s)"
                    )
