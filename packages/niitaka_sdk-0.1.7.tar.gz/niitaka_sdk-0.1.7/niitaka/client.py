from __future__ import annotations

import requests
import uuid
import time
import threading
from typing import Optional

# -------------------------
# Global State
# -------------------------
_current_session_id = None
_event_stack = []
_policy_cache = {}
_file_policies: list = []   # policies loaded from a local policy file

_session_state = {
    "session_id": None,
    "agent_id": None,
    "total_cost": 0.0,
    "step_count": 0,
    "total_steps": 0,       # execution attempts across all wrapped_create calls
    "recent_costs": [],
    "recent_errors": [],
    "policies": [],
    "runtime": {},
    "runtime_config": None, # last result from get_runtime_config(); read by instrumentation
    "event_sequence": 0,    # monotonic counter; sent as sequence_num so backend can order same-second events
}

# Stack of (session_id, session_state snapshot) for nested sessions.
# When a child session ends inside an active parent session (same process),
# the parent state is automatically restored.
_session_stack: list = []

# -------------------------
# Exceptions
# -------------------------
class AgentExecutionStopped(Exception):
    pass


# -------------------------
# Client
# -------------------------
class NiitakaClient:
    def __init__(self, api_url="http://127.0.0.1:8000", api_key=None,
                 max_retries: int = 2):
        self.api_url = api_url
        self.api_key = api_key          # X-API-Key sent with every request
        self.max_retries = max_retries  # default ceiling when no retry policy is configured

    def _auth_headers(self) -> dict:
        """Return auth headers to attach to every outbound request."""
        if self.api_key:
            return {"X-API-Key": str(self.api_key)}
        return {}

    # -------------------------
    # Session Management
    # -------------------------

    def start_session(self, goal=None, agent_id=None, session_id=None,
                      experiment_id=None, variant=None, parent_session_id=None,
                      environment=None):
        """Return a context manager that opens a session with the backend.

        Args:
            goal:              Human-readable description of what the session will do.
            agent_id:          Identifier of the agent running this session.
            session_id:        Explicit session ID (UUID); auto-generated if omitted.
            experiment_id:     ID of an experiment this session belongs to (A/B testing).
            variant:           Variant label for the experiment (e.g. "control", "gpt-4o").
            parent_session_id: Session ID of the orchestrator / parent agent.
                               Set this on sub-agent sessions to build a multi-agent tree.
            environment:       Customer environment tag — 'production', 'staging',
                               'development', or any custom string.  Falls back to the
                               ``NIITAKA_ENV`` environment variable, then 'production'.
        """
        return SessionContext(self, goal, agent_id, session_id,
                              experiment_id, variant, parent_session_id,
                              environment=environment)

    def get_runtime_config(
        self,
        experiment_id: Optional[str] = None,
        variant: Optional[str] = None,
        sticky_key: Optional[str] = None,
    ) -> dict:
        """Fetch runtime config from Niitaka.

        Two modes:

        **A/B experiment mode** (``experiment_id`` provided):
            Resolves a variant for the current session and returns that
            variant's config.  Assignment priority:
            explicit ``variant`` > ``sticky_key`` hash > ``session_id`` hash.

        **Steady-state mode** (``experiment_id`` omitted):
            Returns the agent's active shipped version config.  Use this when
            no experiment is running — the agent always gets the production
            config without having to know which version is live.

        Must be called inside an active ``start_session()`` context.

        Args:
            experiment_id: UUID of the experiment to resolve, or None to use
                           the agent's active shipped version.
            variant:       Explicit variant override (experiment mode only).
            sticky_key:    Stable customer/user ID for cross-session variant
                           consistency (experiment mode only).

        Returns:
            A dict with:
              ``variant``       — assigned variant name (str or None)
              ``experiment_id`` — echoed back (None in steady-state mode)
              ``version_number``— active version number (steady-state mode only)
              ``config``        — runtime config (model, temperature, max_tokens,
                                  system_prompt, policies)

        On any network or auth error returns an empty config so the agent
        keeps running with its own defaults.
        """
        session_id = _session_state.get("session_id")
        agent_id   = _session_state.get("agent_id")

        if not session_id:
            return {"variant": None, "experiment_id": experiment_id, "config": {}}

        # ── Steady-state mode — no experiment ─────────────────────────────────
        if not experiment_id:
            cache_key = "runtime_config:active_version"
            cached = _session_state.get(cache_key)
            if cached is not None:
                return cached

            result: dict = {"variant": None, "experiment_id": None, "config": {}}
            if agent_id:
                try:
                    resp = requests.get(
                        f"{self.api_url}/runtime-config",
                        headers=self._auth_headers(),
                        params={"agent_id": agent_id},
                        timeout=5,
                    )
                    if resp.status_code == 200:
                        result = resp.json()
                except Exception:
                    pass  # fall through with empty config

            _session_state[cache_key] = result
            _session_state["runtime_config"] = result
            self._apply_variant_policy_overrides(result.get("config", {}))
            return result

        # ── Experiment mode ───────────────────────────────────────────────────
        cache_key = f"runtime_config:{experiment_id}:{sticky_key or ''}"
        cached = _session_state.get(cache_key)
        if cached is not None:
            return cached

        try:
            params: dict = {
                "experiment_id": str(experiment_id),
                "session_id":    session_id,
            }
            if variant:
                params["variant"] = variant
            if sticky_key:
                params["sticky_key"] = sticky_key
            resp = requests.get(
                f"{self.api_url}/runtime-config",
                headers=self._auth_headers(),
                params=params,
                timeout=5,
            )
            if resp.status_code == 200:
                result = resp.json()
            else:
                result = {"variant": None, "experiment_id": experiment_id, "config": {}}
        except Exception:
            result = {"variant": None, "experiment_id": experiment_id, "config": {}}

        _session_state[cache_key] = result
        _session_state["runtime_config"] = result  # instrumentation reads this path

        # Merge variant policy overrides into session-level policy limits
        self._apply_variant_policy_overrides(result.get("config", {}))

        # Write the assigned variant back to the session record so the metrics
        # query can group sessions by variant correctly.
        if result.get("variant") and session_id:
            self._fire_async(self._patch, f"/sessions/{session_id}", {"variant": result["variant"]})

        # Log the assignment as a decision event — only when variant resolved.
        if result.get("variant"):
            try:
                import json as _json
                if variant:
                    method = "explicit"
                elif sticky_key:
                    method = "sticky_key"
                else:
                    method = "sticky_hash"
                self.log_decision(_json.dumps({
                    "type":          "variant_assignment",
                    "experiment_id": experiment_id,
                    "variant":       result["variant"],
                    "config":        result.get("config", {}),
                    "method":        method,
                }))
            except Exception:
                pass  # never let observability failure affect the agent

        return result

    def _apply_variant_policy_overrides(self, config: dict) -> None:
        """Merge variant/version guardrails into the session's live policy list.

        Reads ``config["guardrails"]`` (Phase 2+ schema) with fallback to the
        legacy ``config["policies"]`` key so old variants keep working.

        Supported guardrail fields:
          cost_limit_usd  → cost_limit policy rule (stops session when exceeded)
          max_steps       → step_limit policy rule
          retry           → retry policy rule (triggers on any error)
          fallback        → fallback policy rule (triggers on any error, lower priority)

        Rules are injected into ``_session_state["policies"]`` alongside DB-level
        rules so both apply.  Re-calling this method replaces the previous
        runtime_config rules of the same type (idempotent).

        Note: ``retry.on_errors`` and ``fallback.on_errors`` are stored in the
        action params for future per-error-type filtering but do not yet filter —
        the condition uses ``on_error: true`` (trigger on any error).
        """
        if not isinstance(config, dict):
            return
        guardrails_mode = config.get("guardrails_mode", "inherit")
        # Read guardrails (new) falling back to policies (legacy)
        pol = config.get("guardrails") or config.get("policies")

        existing = list(_session_state.get("policies", []))

        # override_all: suppress the entire Policies table for this session so
        # only rules explicitly set in the variant/version config apply.
        if guardrails_mode == "override_all":
            existing = []

        if not pol:
            # If override_all wiped everything, still persist the empty list.
            if guardrails_mode == "override_all":
                _session_state["policies"] = existing
            return

        cost_limit = pol.get("cost_limit_usd")
        max_steps  = pol.get("max_steps")

        if cost_limit is not None:
            # Superseding: remove ALL cost_limit rules from lower-priority sources
            existing = [p for p in existing if p.get("type") != "cost_limit"]
            existing.append({
                "id":        None,
                "type":      "cost_limit",
                "condition": {"cost_exceeded": float(cost_limit)},
                "action":    {"type": "stop"},
                "priority":  10,
                "source":    "runtime_config",
            })

        if max_steps is not None:
            # Superseding: remove ALL step_limit rules from lower-priority sources
            existing = [p for p in existing if p.get("type") != "step_limit"]
            existing.append({
                "id":        None,
                "type":      "step_limit",
                "condition": {"steps_exceeded": int(max_steps)},
                "action":    {"type": "stop"},
                "priority":  10,
                "source":    "runtime_config",
            })

        retry = pol.get("retry")
        if retry and isinstance(retry, dict) and retry.get("max_retries"):
            # Superseding: remove ALL retry rules from lower-priority sources
            existing = [p for p in existing if p.get("type") != "retry"]
            existing.append({
                "id":        None,
                "type":      "retry",
                "condition": {"on_error": True},
                "action":    {
                    "type":           "retry",
                    "max_retries":    int(retry["max_retries"]),
                    "backoff":        retry.get("backoff", "exponential"),
                    "backoff_seconds": float(retry.get("backoff_seconds", 2)),
                    "on_errors":      retry.get("on_errors", []),
                },
                "priority":  10,
                "source":    "runtime_config",
            })

        fallback = pol.get("fallback")
        if fallback and isinstance(fallback, dict) and fallback.get("model"):
            # Superseding: remove ALL fallback rules from lower-priority sources
            existing = [p for p in existing if p.get("type") != "fallback"]
            existing.append({
                "id":        None,
                "type":      "fallback",
                "condition": {"on_error": True},
                "action":    {
                    "type":           "fallback",
                    "fallback_model": fallback["model"],
                    "on_errors":      fallback.get("on_errors", []),
                },
                "priority":  9,   # lower than retry so retry fires first
                "source":    "runtime_config",
            })

        _session_state["policies"] = existing

    def _start_heartbeat(self, session_id: str) -> None:
        """Spawn a daemon thread that pings the heartbeat endpoint every 30 s.

        Sends an immediate ping on startup so ``last_heartbeat_at`` is set
        even for very short-lived sessions that finish before 30 s elapse.
        The thread is a daemon so it never prevents process exit.
        All network errors are swallowed — heartbeat failure must not affect
        the agent's own execution.
        """
        self._heartbeat_stop = threading.Event()

        def _ping():
            try:
                requests.post(
                    f"{self.api_url}/sessions/{session_id}/heartbeat",
                    headers=self._auth_headers(),
                    timeout=2,
                )
            except Exception:
                pass

        def _loop():
            _ping()  # immediate first ping
            while not self._heartbeat_stop.wait(timeout=30):
                _ping()

        t = threading.Thread(target=_loop, daemon=True, name="niitaka-heartbeat")
        t.start()

    def _stop_heartbeat(self) -> None:
        """Signal the heartbeat thread to exit on its next wake-up."""
        stop = getattr(self, "_heartbeat_stop", None)
        if stop is not None:
            stop.set()

    def _create_session(self, goal=None, agent_id=None, session_id=None,
                        experiment_id=None, variant=None, parent_session_id=None,
                        environment=None):
        global _current_session_id, _session_state, _session_stack
        import os as _os

        if session_id is None:
            session_id = str(uuid.uuid4())

        # Resolve environment: explicit arg > NIITAKA_ENV env var > 'production'
        if environment is None:
            environment = _os.environ.get("NIITAKA_ENV", "production")

        # Clear any cached runtime config from a previous session. The cache key
        # does not include session_id, so without this, every session in the same
        # process would reuse the first session's variant assignment.
        for _k in [k for k in _session_state if k.startswith("runtime_config:")]:
            del _session_state[_k]
        _session_state["runtime_config"] = None

        # If there is already an active session in this process, push its state
        # onto the stack so we can restore it when this nested session ends.
        if _current_session_id is not None:
            _session_stack.append((_current_session_id, dict(_session_state)))
            self._stop_heartbeat()  # pause parent heartbeat while child runs

        payload = {
            "session_id":  session_id,
            "goal":        goal,
            "agent_id":    agent_id,
            "environment": environment,
        }
        if experiment_id is not None:
            payload["experiment_id"] = str(experiment_id)
        if variant is not None:
            payload["variant"] = variant
        if parent_session_id is not None:
            payload["parent_session_id"] = parent_session_id

        self._fire_async(self._post, "/sessions", payload)

        _current_session_id = session_id

        policies = self.fetch_policies(agent_id)
        pricing  = self.fetch_pricing()

        _session_state["session_id"] = session_id
        _session_state["agent_id"] = agent_id
        _session_state["goal"] = goal
        _session_state["parent_session_id"] = parent_session_id
        _session_state["total_cost"] = 0.0
        _session_state["step_count"] = 0
        _session_state["total_steps"] = 0
        _session_state["recent_costs"] = []
        _session_state["recent_errors"] = []
        _session_state["policies"] = policies
        _session_state["pricing"]  = pricing
        _session_state["event_sequence"] = 0

        # -------------------------
        # Build runtime config
        # -------------------------
        runtime = {
            "max_retries":  self.max_retries,  # ceiling used before any retry policy fires
            "fallback_used": False,             # guards against re-triggering fallback
        }

        _session_state["runtime"] = runtime

        # Start liveness pings so the backend can detect if this process dies
        self._start_heartbeat(session_id)

        return session_id

    def _end_session(self, status: str = "done", metrics: Optional[dict] = None):
        global _current_session_id, _session_state, _session_stack

        # Stop heartbeat before clearing state so the final ping (if in-flight)
        # still references a valid session_id.
        self._stop_heartbeat()

        # Mark the session with its final status on the backend.
        session_id = _current_session_id
        if session_id:
            try:
                self._patch(f"/sessions/{session_id}", {"status": status})
            except Exception:
                pass  # best-effort — never let cleanup failure raise

            # Report outcome metrics if provided.
            if metrics:
                try:
                    self._patch(f"/sessions/{session_id}/metrics", {"metrics": metrics})
                except Exception as exc:
                    print(f"Niitaka: metrics report failed ({exc})")

        # Restore the parent session's state if this was a nested call.
        if _session_stack:
            prev_id, prev_state = _session_stack.pop()
            _current_session_id = prev_id
            _session_state.update(prev_state)
            # Resume the parent's heartbeat.
            self._start_heartbeat(prev_id)
        else:
            _current_session_id = None
            _session_state["session_id"] = None

    def report_metrics(self, session_id: str, metrics: dict) -> dict:
        """Report outcome metrics for a completed (or running) session.

        Can be called up to 7 days after session creation.  Merges additively
        with any previously reported metrics — existing keys are not removed.

        Reserved keys:
        - ``goal_completed`` (bool): whether the agent achieved its goal.
        - ``score`` (float 0–1): quality score, e.g. from an LLM-as-judge call.
          Note: if you run an LLM call to produce the score, log its cost in
          the ``_judge_cost_usd`` key so it is visible in Niitaka (e.g.
          ``metrics={"score": 0.82, "_judge_cost_usd": 0.0014}``).

        Custom keys must be numeric (int or float). Maximum 10 custom keys
        across all calls for the same session.

        Args:
            session_id: ID of the session to annotate.
            metrics:    Dict of key/value outcome metrics.

        Returns:
            The updated metrics dict from the backend.

        Raises:
            requests.HTTPError: on validation failure (422) or expired window (7 days).
        """
        resp = self._patch(f"/sessions/{session_id}/metrics", {"metrics": metrics})
        return resp.get("metrics", {}) if isinstance(resp, dict) else {}

    def get_current_session(self):
        return _current_session_id

    # -------------------------
    # Policies
    # -------------------------
    def fetch_policies(self, agent_id):
        """Return normalised policies for *agent_id*.

        Precedence:
          1. File policies (loaded via configure(policy_file=...)) — if the file
             covers this agent, those policies are used exclusively.
          2. DB policies fetched from the backend API — used for agents not in any
             loaded file, with in-process caching.
        """
        if not agent_id:
            return []

        # ── 1. File policies (highest priority) ──────────────────────────────
        if _file_policies:
            from .policy_loader import policies_for_agent
            file_matched = policies_for_agent(_file_policies, agent_id)
            if file_matched is not None:
                return file_matched  # file is authoritative for this agent

        # ── 2. DB policies (with cache) ───────────────────────────────────────
        if agent_id in _policy_cache:
            return _policy_cache[agent_id]

        try:
            res = requests.get(
                f"{self.api_url}/policies/{agent_id}",
                headers=self._auth_headers(),
                timeout=5,
            )
            raw_policies = res.json()
        except Exception:
            raw_policies = []

        # Normalise DB response into the same shape as file policies
        policies = []
        for p in raw_policies:
            config = p.get("config", {})
            if "config" in config:          # unwrap legacy nested config
                config = config.get("config", {})
            policies.append({
                "id":        p.get("id"),
                "type":      p.get("type"),
                "condition": config.get("condition", {}),
                "action":    config.get("action", {}),
                "priority":  config.get("priority", 0),
                "source":    "db",
            })

        _policy_cache[agent_id] = policies
        return policies

    def fetch_pricing(self) -> dict:
        """Fetch the live pricing table from the backend and return as an override dict.

        The returned dict maps normalised model names to ``{input, output}`` per
        million token rates.  Falls back to an empty dict (SDK defaults are used)
        when the backend is unreachable or returns an unexpected response.
        """
        try:
            res = requests.get(
                f"{self.api_url}/pricing",
                headers=self._auth_headers(),
                timeout=5,
            )
            if res.status_code != 200:
                return {}
            rows = res.json()
            return {
                row["model"]: {
                    "input":  row["input_per_million"],
                    "output": row["output_per_million"],
                }
                for row in rows
                if "model" in row
            }
        except Exception:
            return {}

    # -------------------------
    # Signals (ASYNC, NON-BLOCKING)
    # -------------------------
    def emit_signal(self, type, subtype, message, data=None, event_id=None, blocking=False):
        payload = {
            "session_id": _session_state["session_id"],
            "event_id": event_id,
            "type": type,
            "subtype": subtype,
            "message": message,
            "data": data or {},
        }

        if blocking:
            self._post("/signals", payload)
        else:
            self._fire_async(self._post, "/signals", payload)

    # -------------------------
    # Guardrails
    # -------------------------
    def check_cost_guardrail(self, next_cost=0):
        """Pre-call gate: checks accumulated cost + projected next_cost against limits.

        Raises AgentExecutionStopped when an abort-level threshold would be crossed.
        Called before every LLM call; next_cost defaults to 0 so accumulated-only
        checks work correctly with the default argument.
        """
        total_cost = _session_state["total_cost"]
        projected_cost = total_cost + next_cost
        policies = _session_state.get("policies", [])

        should_abort = False
        for p in policies:
            if p.get("type") != "cost_limit":
                continue
            limit = p.get("condition", {}).get("cost_exceeded", 0)
            if projected_cost <= limit:
                continue
            action_type = p.get("action", {}).get("type", "abort")
            self.emit_signal(
                type="guardrail",
                subtype="cost_limit",
                message=f"Cost {'limit exceeded' if action_type != 'warn' else 'warning'} (${projected_cost:.4f} > ${limit})",
                data={"limit": limit, "actual": projected_cost, "action": action_type},
            )
            if action_type != "warn":
                should_abort = True

        if should_abort:
            raise AgentExecutionStopped(
                f"Cost guardrail triggered (${projected_cost:.4f})"
            )

    def emit_cost_signals(self, total_cost: float) -> None:
        """Post-call observer: emits warn/abort signals when total_cost crosses a threshold.

        Never raises — the call has already completed and the cost is already incurred.
        Signals here ensure observability even if the session ends without a next call.
        The actual abort gate is check_cost_guardrail(), called pre-call.
        """
        policies = _session_state.get("policies", [])
        for p in policies:
            if p.get("type") != "cost_limit":
                continue
            limit = p.get("condition", {}).get("cost_exceeded", 0)
            if total_cost <= limit:
                continue
            action_type = p.get("action", {}).get("type", "abort")
            self.emit_signal(
                type="guardrail",
                subtype="cost_limit",
                message=f"Cost {'limit exceeded' if action_type != 'warn' else 'warning'} (${total_cost:.4f} > ${limit})",
                data={"limit": limit, "actual": total_cost, "action": action_type},
            )

    def check_step_guardrail(self):
        step_count = _session_state["step_count"]
        policies = _session_state.get("policies", [])

        should_abort = False
        for p in policies:
            if p.get("type") != "step_limit":
                continue
            limit = p.get("condition", {}).get("steps_exceeded", 0)
            if step_count < limit:
                continue
            action_type = p.get("action", {}).get("type", "abort")
            self.emit_signal(
                type="guardrail",
                subtype="step_limit",
                message=f"Step {'limit exceeded' if action_type != 'warn' else 'warning'} ({step_count} >= {limit})",
                data={"limit": limit, "actual": step_count, "action": action_type},
            )
            if action_type != "warn":
                should_abort = True

        if should_abort:
            raise AgentExecutionStopped(
                f"Step limit triggered ({step_count} steps)"
            )
                
    # -------------------------
    # Alerts
    # -------------------------
    def check_cost_spike(self, cost):
        history = _session_state["recent_costs"]

        history.append(cost)

        # keep last N
        if len(history) > 5:
            history.pop(0)

        if len(history) < 5:
            return

        avg = sum(history[:-1]) / (len(history) - 1)

        # spike condition
        if avg > 0 and cost > avg * 3:
            self.emit_signal(
                type="alert",
                subtype="cost_spike",
                message="Cost spike detected",
                data={
                    "current": cost,
                    "avg": avg,
                },
            )

    def check_error_spike(self, is_error):
        history = _session_state["recent_errors"]
        history.append(1 if is_error else 0)
        if len(history) > 10:
            history.pop(0)

        if len(history) < 10:
            return

        error_rate = sum(history) / len(history)

        if error_rate > 0.5:
            self.emit_signal(
                type="alert",
                subtype="error_spike",
                message="High error rate detected",
                data={
                    "error_rate": error_rate,
                },
            )

    # -------------------------
    # Core Logging
    # -------------------------
    def log_event(self, type, data, session_id=None):
        global _current_session_id, _event_stack

        if session_id is None:
            session_id = _current_session_id

        if session_id is None:
            raise Exception("No active session.")

        # Generate UUID client-side so we can return immediately without a round-trip.
        # The POST fires in a background thread; the server stores the client-provided id.
        event_id        = str(uuid.uuid4())
        parent_event_id = _event_stack[-1] if _event_stack else None

        _session_state["event_sequence"] = _session_state.get("event_sequence", 0) + 1
        seq = _session_state["event_sequence"]

        payload = {
            "event_id":          event_id,
            "session_id":        session_id,
            "type":              type,
            "data":              data,
            "parent_event_id":   parent_event_id,
            "agent_id":          _session_state.get("agent_id"),
            "goal":              _session_state.get("goal"),
            "parent_session_id": _session_state.get("parent_session_id"),
            "sequence_num":      seq,
        }

        self._fire_async(self._post, "/events", payload)
        return event_id

    def log_llm(self, input, output=None, cost=0, metadata=None, session_id=None):
        # Guardrail gate is pre-call (instrumentation.py / caller's responsibility).
        # Here we only observe after the fact so we never lose a completed call's data.
        self.check_cost_spike(cost)
        self.check_error_spike(False)

        start = time.time()

        # non-context mode
        if output is not None:
            duration = int((time.time() - start) * 1000)

            event_id = self.log_event(
                "llm",
                {
                    "input": input,
                    "output": output,
                    "cost": cost,
                    "meta": metadata,
                    "duration_ms": duration,
                },
                session_id=session_id,
            )

            # Update totals, then emit signals — the call is done so we record it
            # regardless of whether it pushed accumulated cost over a threshold.
            _session_state["total_cost"] += cost
            _session_state["step_count"] += 1
            self.emit_cost_signals(_session_state["total_cost"])

            # Store so callers can retrieve the event_id and use it as a parent.
            _session_state["last_llm_event_id"] = event_id

            return trace(event_id)

        return timed_trace(self, "llm", input, cost, metadata, session_id)

    def log_tool(self, input, output, cost=0, session_id=None):
        # No pre-log abort — the tool call is already done, always capture it.
        event_id = self.log_event(
            "tool",
            {
                "input": input,
                "output": output,
                "cost": cost,
            },
            session_id=session_id,
        )

        _session_state["total_cost"] += cost
        _session_state["step_count"] += 1
        self.emit_cost_signals(_session_state["total_cost"])

        return event_id

    def log_decision(self, output, session_id=None):
        return self.log_event(
            "decision",
            {"output": output},
            session_id=session_id,
        )

    def log_error(self, error_message, session_id=None):
        self.check_error_spike(True)
        return self.log_event(
            "error",
            {
                "output": error_message,
                "status": "error",
            },
            session_id=session_id,
        )

    # -------------------------
    # Decision Trace (NON-BLOCKING)
    # -------------------------
    def log_decision_trace(self, data: dict):
        """Post a full policy decision trace to the backend (non-blocking).

        Each call represents one policy evaluation phase (pre_execution or
        on_error) and carries the full candidate list, resolution reason,
        and the final winning action.
        """
        def send():
            try:
                self._post("/decisions", data)
            except Exception:
                pass

        threading.Thread(target=send, daemon=True).start()

    # -------------------------
    # HTTP Helpers (SAFE)
    # -------------------------
    def _post(self, path, payload):
        try:
            response = requests.post(
                f"{self.api_url}{path}",
                json=payload,
                headers=self._auth_headers(),
                timeout=10,
            )
            return response.json()
        except Exception as e:
            print(f"Niitaka error ({path}):", e)
            return None

    def _patch(self, path, payload):
        try:
            response = requests.patch(
                f"{self.api_url}{path}",
                json=payload,
                headers=self._auth_headers(),
                timeout=10,
            )
            return response.json()
        except Exception:
            return None

    def _fire_async(self, fn, *args) -> None:
        """Run fn(*args) in a daemon thread. All errors are swallowed."""
        def run():
            try:
                fn(*args)
            except Exception:
                pass
        threading.Thread(target=run, daemon=True).start()


# -------------------------
# Context Managers
# -------------------------

# -------------------------
# Context Managers
# -------------------------
class SessionContext:
    def __init__(self, client, goal, agent_id, session_id,
                 experiment_id=None, variant=None, parent_session_id=None,
                 environment=None):
        self.client = client
        self.goal = goal
        self.agent_id = agent_id
        self.session_id = session_id
        self.experiment_id = experiment_id
        self.variant = variant
        self.parent_session_id = parent_session_id
        self.environment = environment
        self._metrics: Optional[dict] = None   # set via set_metrics() inside the block

    def set_metrics(self, metrics: dict) -> None:
        """Stage outcome metrics to be reported when the session closes.

        Call this anywhere inside the ``with client.start_session()`` block.
        The metrics are sent to the backend on exit (alongside the status update).

        See :py:meth:`NiitakaClient.report_metrics` for key contract details.
        """
        self._metrics = metrics

    def __enter__(self):
        self.session_id = self.client._create_session(
            goal=self.goal,
            agent_id=self.agent_id,
            session_id=self.session_id,
            experiment_id=self.experiment_id,
            variant=self.variant,
            parent_session_id=self.parent_session_id,
            environment=self.environment,
        )
        print(f"🟢 Session started: {self.session_id}"
              + (f" (parent: {self.parent_session_id})" if self.parent_session_id else ""))
        # Auto-fetch runtime config so instrumentation can apply it to every
        # LLM call without requiring the agent to call get_runtime_config() explicitly.
        # Errors are silently swallowed — config failure must never break the agent.
        try:
            self.client.get_runtime_config(self.experiment_id, variant=self.variant)
        except Exception as _exc:
            print(f"Niitaka: runtime config pre-fetch failed ({_exc}), using defaults")
        return self.session_id

    def __exit__(self, exc_type, exc_val, exc_tb):
        final_status = "error" if exc_type is not None else "done"
        # Only report goal_completed=True on clean exit if not already staged
        self.client._end_session(final_status, metrics=self._metrics)
        print("🔴 Session ended")


class trace:
    def __init__(self, event_id):
        self.event_id = event_id

    def __enter__(self):
        _event_stack.append(self.event_id)

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            # Log an error event parented under this trace before the stack unwinds,
            # so the session timeline shows decision → error instead of a dead end.
            try:
                error_msg = f"{exc_type.__name__}: {exc_val}"
                client.log_error(error_msg)
            except Exception:
                pass  # never let observability code break the agent
        _event_stack.pop()
        return False  # always re-raise the original exception


class timed_trace:
    def __init__(self, client, event_type, input, cost, metadata, session_id):
        self.client = client
        self.event_type = event_type
        self.input = input
        self.cost = cost
        self.metadata = metadata
        self.session_id = session_id

    def __enter__(self):
        # Pre-call gate: checks accumulated cost from previous calls (next_cost=0)
        # and step count. Cost of *this* call is not yet known / not yet incurred.
        self.client.check_cost_guardrail()
        self.client.check_step_guardrail()
        _session_state["step_count"] += 1
        self.start = time.time()

        self.event_id = self.client.log_event(
            self.event_type,
            {
                "input": self.input,
                "output": None,
                "cost": self.cost,
                "meta": self.metadata,
            },
            session_id=self.session_id,
        )

        _event_stack.append(self.event_id)

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        duration = int((time.time() - self.start) * 1000)

        is_error = exc_type is not None

        self.client.check_error_spike(is_error)

        if not is_error:
            self.client.check_cost_spike(self.cost)

        if exc_type is not None:
            status = "error"
            output = str(exc_val)
        else:
            status = "success"
            output = "completed"

            # Update cost after success, then observe — never abort here since
            # the operation is already done.
            _session_state["total_cost"] += self.cost
            self.client.emit_cost_signals(_session_state["total_cost"])

        self.client._fire_async(
            self.client._patch,
            f"/events/{self.event_id}",
            {
                "data": {
                    "output": output,
                    "duration_ms": duration,
                    "status": status,
                }
            },
        )

        _event_stack.pop()

        return False


# -------------------------
# Singleton
# -------------------------
client = NiitakaClient()


# -------------------------
# Public API
# -------------------------

def configure(api_key: str = None, api_url: str = None, policy_file: str = None):
    """Configure the singleton client — call once at agent startup.

    Args:
        api_key:     X-API-Key sent with every backend request.
        api_url:     Backend base URL (default http://127.0.0.1:8000).
        policy_file: Path to a YAML or JSON policy file.  When set, policies
                     for agents listed in the file are loaded from disk rather
                     than fetched from the backend.  Agents *not* in the file
                     still use DB policies as normal.

    Example:
        import sdk.client as niitaka
        niitaka.configure(
            api_key=os.getenv("NIITAKA_API_KEY"),
            policy_file="policies.yaml",
        )
    """
    global _file_policies

    if api_key is not None:
        client.api_key = api_key
    if api_url is not None:
        client.api_url = api_url

    if policy_file is not None:
        from .policy_loader import load_policy_file
        _file_policies = load_policy_file(policy_file)
        agent_ids = sorted({p["agent_id"] for p in _file_policies})
        print(f"[niitaka] Loaded {len(_file_policies)} policies from '{policy_file}' "
              f"for agents: {', '.join(agent_ids)}")


def start_session(goal=None, agent_id=None, session_id=None,
                  experiment_id=None, variant=None, parent_session_id=None,
                  environment=None):
    return client.start_session(goal, agent_id, session_id,
                                experiment_id=experiment_id, variant=variant,
                                parent_session_id=parent_session_id,
                                environment=environment)


def get_runtime_config(
    experiment_id: Optional[str] = None,
    variant: Optional[str] = None,
    sticky_key: Optional[str] = None,
) -> dict:
    """Module-level convenience wrapper for ``NiitakaClient.get_runtime_config``.

    Must be called inside an active ``start_session()`` context.

    Args:
        experiment_id: The experiment UUID to resolve.
        variant:       Force a specific variant (bypasses hashing).
        sticky_key:    Stable customer/user ID — pins the same entity to the
                       same variant across sessions.  Omit for per-session
                       independent assignment.

    Returns:
        ``{"variant": str|None, "experiment_id": str, "config": dict}``
        where *config* may contain: model, temperature, max_tokens,
        system_prompt, policies (max_steps, cost_limit_usd).
    """
    return client.get_runtime_config(experiment_id, variant=variant, sticky_key=sticky_key)


def log_llm(input, output=None, cost=0, metadata=None, session_id=None):
    return client.log_llm(input, output, cost, metadata, session_id)


def log_tool(input, output, cost=0, session_id=None):
    return client.log_tool(input, output, cost, session_id)


def log_decision(output, session_id=None):
    return client.log_decision(output, session_id)


def log_error(error_message, session_id=None):
    return client.log_error(error_message, session_id)