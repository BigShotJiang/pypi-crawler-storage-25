import os
import jinja2
from typing import ClassVar, Optional
from pathlib import Path

from tai_sql import pm
from ...base import BaseGenerator

class AsyncCRUDGenerator(BaseGenerator):
    """
    Generador de clases CRUD para modelos SQLAlchemy con soporte sync/async.
    """

    _jinja_env: ClassVar[jinja2.Environment] = None
    
    def __init__(self,
                 output_dir: Optional[str] = None,
                 models_import_path: str = "...models",
                 max_depth: int = 5,
                 logger_name: str = 'tai-sql',
                 connection_params: Optional[dict] = None) -> None:
        """
        Inicializa el generador CRUD.

        Args:
            output_dir: Directorio de salida para los archivos CRUD.
            models_import_path: Import path hacia el paquete de modelos generados.
                                 Calculado automáticamente por CRUDGenerator.
            connection_params: Parámetros de conexión del engine. Si se omite se leen
                                desde pm.db.provider en tiempo de generación.
        """
        super().__init__(output_dir)
        self.models_import_path = models_import_path
        self.max_depth = max_depth
        self.logger_name = logger_name
        self._connection_params = connection_params

    @property
    def utils_models_import_path(self) -> str:
        """
        Import path hacia los modelos desde el subdirectorio utils/.

        utils/ está un nivel más profundo que el directorio principal del
        generador, por lo que necesita un dot extra respecto a models_import_path:
            crud/asyn/        → ...models
            crud/asyn/utils/  → ....models
        """
        return '.' + self.models_import_path
    
    @property
    def jinja_env(self) -> jinja2.Environment:
        """Retorna el entorno Jinja2 configurado"""
        if self._jinja_env is None:
            templates_dir = os.path.join(os.path.dirname(__file__), 'templates')
            self._jinja_env = jinja2.Environment(
                loader=jinja2.FileSystemLoader(templates_dir),
                trim_blocks=True,
                lstrip_blocks=True
            )
            self._jinja_env.filters['repr'] = repr
            
            # Custom filter for transforming trigger references
            def transform_refs(text: str, context: dict) -> str:
                """Transform trigger references like t.data to actual variable names."""
                result = text
                for trigger_ref, actual_var in context.items():
                    result = result.replace(trigger_ref, actual_var)
                return result
            
            self._jinja_env.filters['transform_refs'] = transform_refs
        return self._jinja_env
    
    def generate(self) -> str:
        """
        Genera las clases CRUD según el modo especificado.
        
        Returns:
            Ruta al directorio generado
        """
        
        # Generar session_manager.py
        self.generate_session_manager()
        
        # Generar daos.py
        self.generate_daos()

        # Generar dtos.py
        self.generate_dtos()
        
        # Generar __init__.py
        self.generate_init_file()

        # Generar utils.py
        self.generate_utils()

        return self.config.output_dir
    
    def generate_session_manager(self) -> None:
        """
        Genera el archivo session_manager.py
        """
        template = self.jinja_env.get_template(f'session_manager.py.jinja2')

        imports = [
            'from __future__ import annotations',
            'import os',
            'import re',
            'from urllib.parse import (',
            '    unquote,',
            '    urlparse,',
            '    parse_qs',
            ')',
            'from typing import (',
            '    Optional,',
            '    AsyncGenerator',
            ')',
            'from contextlib import asynccontextmanager',
            'from sqlalchemy import URL',
            'from sqlalchemy.ext.asyncio import (',
            '    create_async_engine,',
            '    AsyncEngine,',
            '    AsyncSession,',
            '    async_sessionmaker',
            ')'
        ]
        
        connection_params = self._connection_params or pm.db.provider.get_connection_params()
        code = template.render(
            imports=imports,
            provider=pm.db.provider,
            connection_params=connection_params
        )

        file_path = os.path.join(self.config.output_dir, 'session_manager.py')
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(code)
    
    def generate_daos(self) -> None:
        """
        Genera el archivo daos.py
        """
        template = self.jinja_env.get_template(f'daos.py.jinja2')

        imports = [
            'from __future__ import annotations',
            'from typing import (',
            '    List,',
            '    Optional,',
            '    Dict,',
            '    Union,',
            '    Literal,',
            '    Any',
            ')',
            'from datetime import datetime, date, time',
            'from sqlalchemy.ext.asyncio import AsyncSession',
            'from sqlalchemy import (',
            '    select,',
            '    update,',
            '    delete,',
            '    func,',
            '    literal_column,',
            '    or_,',
            '    and_',
            ')',
            'from .session_manager import AsyncSessionManager',
            'from .dtos import *',
            'from .utils import (',
            '    error_handler,',
            '    get_loading_options,',
            '    load_relationships_from_dto,',
            '    RLSQueryApplicator,',
            '    ExpressionParser,',
            '    RLS',
            ')',
            f'from {self.models_import_path} import *',
            'from tai_alphi import Alphi',
        ]
        
        models_data = [model.info('async') for model in self.models]
        
        code = template.render(
            imports=imports,
            models=models_data,
            models_import_path=self.models_import_path,
            schema_name=pm.db.schema_name,
            max_depth=self.max_depth,
            logger_name=self.logger_name
        )
        
        file_path = os.path.join(self.config.output_dir, 'daos.py')
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(code)
    
    def generate_dtos(self) -> None:
        """
        Genera el archivo dtos.py
        """
        template = self.jinja_env.get_template(f'dtos.py.jinja2')

        imports = [
            'from __future__ import annotations',
            'from enum import Enum',
            'from typing import (',
            '    List,',
            '    Optional,',
            '    Dict,',
            '    Literal,',
            '    Union,',
            '    Any',
            ')',
            f'from {self.models_import_path} import *',
            'from pydantic import (',
            '    Field,',
            '    ConfigDict',
            ')',
            'from tai_alphi import Alphi',
            '',
            'from .utils import (',
            '    should_include_relation,',
            '    get_nested_includes,',
            '    PrettyModel',
            ')'
        ]

        has_datetime = any(
                any(col.type == 'datetime' or col.type == 'date' or col.type == 'time' for col in model.columns.values())
                for model in self.models
            )
        if has_datetime:
            imports.append('from datetime import datetime, date, time')
        
        models_data = [model.info() for model in self.models]
        
        code = template.render(
            imports=imports,
            models=models_data,
            models_import_path=self.models_import_path,
            schema_name=pm.db.schema_name,
            max_depth=self.max_depth,
            logger_name=self.logger_name
        )
        
        file_path = os.path.join(self.config.output_dir, 'dtos.py')
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(code)
    
    def generate_init_file(self) -> None:
        """
        """
        template = self.jinja_env.get_template(f'__init__.py.jinja2')
        
        imports = [
            'from __future__ import annotations',
            'from typing import Optional',
            'from .session_manager import AsyncSessionManager',
            'from .dtos import *',
            'from .daos import *',
            'from .utils import sqlalchemy_table_mapper',
        ]

        models = [{'name': model._name, 'tablename': model.tablename, 'is_view': model.is_view} for model in self.models]
        enums = [enum.info() for enum in self.enums]
        
        code = template.render(
            imports=imports,
            models=models,
            enums=enums,
            models_import_path=self.models_import_path,
            mode_prefix='Async',  # 'Sync' o 'Async'
            schema_name=pm.db.schema_name
        )
        
        file_path = os.path.join(self.config.output_dir, '__init__.py')
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(code)

    def generate_utils(self) -> None:
        """
        Genera el archivo utils.py
        """
        utils_dir = Path(self.config.output_dir) / 'utils'
        utils_dir.mkdir(parents=True, exist_ok=True)

        init = self.jinja_env.get_template(f'utils/__init__.py.jinja2')
        funcs = self.jinja_env.get_template(f'utils/funcs.py.jinja2')
        rls = self.jinja_env.get_template(f'utils/rls.py.jinja2')
        
        init_content = init.render()
        funcs_content = funcs.render(
            logger_name=self.logger_name,
            schema_name=pm.db.schema_name,
            models=[model.info() for model in self.models],
            models_import_path=self.utils_models_import_path,
        )
        rls_content = rls.render(
            logger_name=self.logger_name,
            schema_name=pm.db.schema_name
        )

        file_path = os.path.join(utils_dir, '__init__.py')
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(init_content)

        file_path = os.path.join(utils_dir, 'funcs.py')
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(funcs_content)

        file_path = os.path.join(utils_dir, 'rls.py')
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(rls_content)