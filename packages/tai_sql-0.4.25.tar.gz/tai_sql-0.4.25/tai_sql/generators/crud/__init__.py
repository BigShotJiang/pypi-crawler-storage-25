import os
from typing import List, Union, Optional, Literal, Dict
from pathlib import Path

from tai_sql import pm
from ..base import BaseGenerator
from .sync import SyncCRUDGenerator
from .asyn import AsyncCRUDGenerator
from ..models import ModelsGenerator

class CRUDGenerator(BaseGenerator):
    """
    Generador de clases CRUD para modelos SQLAlchemy con soporte sync/async.

    Requiere un ModelsGenerator configurado con el mismo output_dir para poder
    derivar automáticamente el import path de los modelos generados.
    """

    def __init__(self,
                 output_dir: Optional[str] = None,
                 models_import_path: Optional[str] = None,
                 mode: Literal['sync', 'async', 'both'] = 'sync',
                 max_depth: int = 5,
                 logger_name: str = 'tai-sql',
                 pool_size: Optional[int] = None,
                 max_overflow: Optional[int] = None,
                 pool_timeout: Optional[int] = None,
                 pool_pre_ping: Optional[bool] = None,
                 pool_recycle: Optional[int] = None,
                 ssl: Optional[bool] = None,
                 sqlalchemy_logs: Optional[bool] = None):
        """
        Inicializa el generador CRUD.

        Args:
            output_dir: Directorio de salida. Debe coincidir con el output_dir del
                        ModelsGenerator asociado para que el import path se derive
                        automáticamente.
            models_import_path: Import path explícito hacia los modelos. Si se omite,
                                 se calcula automáticamente desde el ModelsGenerator
                                 que comparta el mismo output_dir.
            mode: Modo de generación ('sync', 'async', 'both').
            pool_size: Sobreescribe el pool_size configurado en datasource().
            max_overflow: Sobreescribe el max_overflow configurado en datasource().
            pool_timeout: Sobreescribe el pool_timeout configurado en datasource().
            pool_pre_ping: Sobreescribe el pool_pre_ping configurado en datasource().
            pool_recycle: Sobreescribe el pool_recycle configurado en datasource().
            ssl: Sobreescribe el ssl configurado en datasource().
            sqlalchemy_logs: Sobreescribe el sqlalchemy_logs configurado en datasource().
        """
        super().__init__(output_dir)
        self._models_import_path = models_import_path
        self.mode = mode
        self.max_depth = max_depth
        self.logger_name = logger_name
        self._pool_size = pool_size
        self._max_overflow = max_overflow
        self._pool_timeout = pool_timeout
        self._pool_pre_ping = pool_pre_ping
        self._pool_recycle = pool_recycle
        self._ssl = ssl
        self._sqlalchemy_logs = sqlalchemy_logs

    @property
    def models_generator(self) -> ModelsGenerator:
        """
        Localiza el ModelsGenerator asociado buscando en pm.db.generators aquel
        cuyo output_dir coincida con el de este CRUDGenerator.

        El output_dir compartido es el vínculo natural entre ambos generadores:
        - ModelsGenerator produce en {output_dir}/{schema}/models/
        - CRUDGenerator produce en {output_dir}/{schema}/crud/{mode}/

        Raises:
            ValueError: Si no existe ningún ModelsGenerator con el mismo output_dir.
        """
        for generator in pm.db.generators:
            if (isinstance(generator, ModelsGenerator) and
                    os.path.abspath(generator.config.output_dir) ==
                    os.path.abspath(self.config.output_dir)):
                return generator
        raise ValueError(
            f"No se encontró un ModelsGenerator con output_dir='{self.config.output_dir}'. "
            "Asegúrate de que ModelsGenerator y CRUDGenerator compartan el mismo output_dir."
        )

    @property
    def models_import_path(self) -> str:
        """
        Import path Python hacia el paquete de modelos generados.

        Si se proporcionó manualmente en el constructor se usa ese valor.
        En caso contrario se calcula contando cuántos niveles separan el
        directorio del CRUD del directorio de modelos:

            {output_dir}/{schema}/crud/{mode}/  →  ../../models
            2 niveles "../" + 1 base = 3 dots   →  ...models
        """
        if self._models_import_path:
            return self._models_import_path

        models_dir = self.models_generator.file_path
        # 'syn' y 'asyn' tienen la misma profundidad relativa; usamos 'syn' como
        # referencia canónica para el cálculo (modo 'both' incluye ambos).
        ref_mode   = 'syn' if self.mode in ('sync', 'both') else 'asyn'
        crud_dir   = Path(self.config.output_dir) / pm.db.schema_name / 'crud' / ref_mode
        rel        = Path(os.path.relpath(models_dir, crud_dir))
        dots       = sum(1 for p in rel.parts if p == '..') + 1
        return '.' * dots + rel.parts[-1]
    
    @property
    def connection_params(self) -> Dict:
        """
        Parámetros de conexión del engine para el session_manager generado.

        Toma como base los valores configurados en datasource() y sobreescribe
        únicamente los que se hayan pasado explícitamente al constructor.
        """
        params = pm.db.provider.get_connection_params().copy()
        overrides = {
            'pool_size': self._pool_size,
            'max_overflow': self._max_overflow,
            'pool_timeout': self._pool_timeout,
            'pool_pre_ping': self._pool_pre_ping,
            'pool_recycle': self._pool_recycle,
            'ssl': self._ssl,
            'sqlalchemy_logs': self._sqlalchemy_logs,
        }
        for key, value in overrides.items():
            if value is not None:
                params[key] = value
        return params

    @property
    def sync_generator(self) -> SyncCRUDGenerator:
        output_dir = os.path.join(self.config.output_dir, pm.db.schema_name, 'crud', 'syn')
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        return SyncCRUDGenerator(
            output_dir=output_dir,
            models_import_path=self.models_import_path,
            max_depth=self.max_depth,
            logger_name=self.logger_name,
            connection_params=self.connection_params
        )
    
    @property
    def async_generator(self) -> AsyncCRUDGenerator:
        output_dir = os.path.join(self.config.output_dir, pm.db.schema_name, 'crud', 'asyn')
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        return AsyncCRUDGenerator(
            output_dir=output_dir,
            models_import_path=self.models_import_path,
            max_depth=self.max_depth,
            logger_name=self.logger_name,
            connection_params=self.connection_params
        )
    
    def generate(self) -> Union[tuple[str, str], str]:
        """
        Genera las clases CRUD según el modo especificado.
        
        Returns:
            Ruta al directorio generado
        """
        if self.validate_configuration():
            if self.mode in ['sync', 'both']:
                sync_result = self.sync_generator.generate()
            
            if self.mode in ['async', 'both']:
                async_result = self.async_generator.generate()
            
            if self.mode == 'both':
                return sync_result, async_result
            
            elif self.mode == 'sync':
                return sync_result
            
            elif self.mode == 'async':
                return async_result
    
    def validate_configuration(self) -> bool:
        """
        Valida que la configuración del generador sea correcta
        
        Returns:
            True si la configuración es válida
            
        Raises:
            ValueError: Si la configuración es inválida
        """
        if not pm.db.provider:
            raise ValueError("No se ha configurado un provider. Usa datasource() primero.")

        if not pm.db.provider.source_input_type:
            raise ValueError("El provider no tiene source_input_type configurado.")

        if self.mode not in ['sync', 'async', 'both']:
            raise ValueError(f"Modo no válido: {self.mode}. Debe ser 'sync', 'async' o 'both'.")

        # Verificar que existe un ModelsGenerator asociado (mismo output_dir),
        # a menos que el developer haya proporcionado models_import_path manualmente.
        if not self._models_import_path:
            self.models_generator  # lanza ValueError si no existe
        
        if not self.models:
            raise ValueError("No se encontraron modelos para generar CRUDs.")
        
        return True
    
    def __str__(self) -> str:
        return f"CRUDGenerator(mode={self.mode}, output_dir={self.config.output_dir})"
    
    def __repr__(self) -> str:
        return self.__str__()