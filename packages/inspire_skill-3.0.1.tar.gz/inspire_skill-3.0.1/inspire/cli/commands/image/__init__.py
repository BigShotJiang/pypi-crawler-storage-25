"""Image management commands.

Usage:
    inspire image list [--source official|public|private|all]
    inspire image detail <name>
    inspire image register -n "name" -v v1.0
    inspire image save <notebook-name> -n "name" [--public|--private]
    inspire image set-visibility <name> --public|--private
    inspire image delete <name>
    inspire image set-default --job <name> --notebook <name>
"""

from __future__ import annotations

import click

from .image_commands import (
    delete_image_cmd,
    image_detail,
    list_images_cmd,
    register_image_cmd,
    save_image_cmd,
    set_default_image_cmd,
    set_image_visibility_cmd,
)


@click.group()
def image():
    """Manage Docker images for notebooks and jobs.

    \b
    Examples:
        inspire image list                              # List official images
        inspire image list --source private             # List personal-visible images
        inspire image save <notebook-name> -n my-img    # Save notebook as image
        inspire image save <notebook-name> -n shared --public
        inspire image set-visibility <name> --public    # Flip visibility
        inspire image register -n my-img -v v1.0        # Register external image
        inspire image set-default --job my-pytorch      # Set default image
    """
    pass


image.add_command(list_images_cmd)
image.add_command(image_detail)
image.add_command(register_image_cmd)
image.add_command(save_image_cmd)
image.add_command(set_image_visibility_cmd)
image.add_command(delete_image_cmd)
image.add_command(set_default_image_cmd)
