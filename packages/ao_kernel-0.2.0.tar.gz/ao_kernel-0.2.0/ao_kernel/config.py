"""Workspace resolver and bundled defaults loader.

Resolution order for workspace_root():
    1. ``override`` argument (from --workspace-root CLI flag)
    2. ``.ao/`` directory (searched from CWD upward)
    3. ``.cache/ws_customer_default`` (legacy — MUST remain in v1.x)
    4. None (library mode — no workspace required)
"""

from __future__ import annotations

import json
import warnings
from importlib.resources import files
from pathlib import Path
from typing import Any

from ao_kernel.errors import DefaultsNotFoundError, WorkspaceCorruptedError

_VALID_RESOURCE_TYPES = frozenset({
    "policies",
    "schemas",
    "registry",
    "extensions",
    "operations",
})


def workspace_root(override: str | Path | None = None) -> Path | None:
    """Resolve the workspace root directory.

    Returns None in library mode (no workspace found).
    CLI commands should treat None as an error and exit with a message.
    """
    if override is not None:
        p = Path(override).resolve()
        if not p.is_dir():
            raise FileNotFoundError(f"Workspace override path does not exist: {p}")
        return p

    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        candidate = parent / ".ao"
        if candidate.is_dir():
            return candidate

    for parent in [cwd, *cwd.parents]:
        candidate = parent / ".cache" / "ws_customer_default"
        if candidate.is_dir():
            warnings.warn(
                f"Using legacy workspace at {candidate}. "
                "Migrate to .ao/ with 'ao-kernel init'. "
                "Legacy support will be removed in v2.0.0.",
                DeprecationWarning,
                stacklevel=2,
            )
            return candidate

    return None


def load_workspace_json(workspace: Path) -> dict[str, Any]:
    """Load and validate workspace.json from the given workspace directory."""
    ws_file = workspace / "workspace.json"
    if not ws_file.is_file():
        raise WorkspaceCorruptedError(
            f"workspace.json not found in {workspace}. "
            "Run 'ao-kernel init' to create a workspace."
        )
    try:
        data = json.loads(ws_file.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise WorkspaceCorruptedError(
            f"workspace.json is not valid JSON: {e}"
        ) from e

    for key in ("version", "kind"):
        if key not in data:
            raise WorkspaceCorruptedError(
                f"workspace.json missing required field: {key!r}"
            )
    return data


def load_default(resource_type: str, filename: str) -> Any:
    """Load a bundled default JSON file from ao_kernel/defaults/.

    Args:
        resource_type: One of "policies", "schemas", "registry",
                       "extensions", "operations".
                       For nested paths use slash: "extensions/PRJ-AIRUNNER".
        filename: The JSON filename.

    Returns:
        Parsed JSON content.
    """
    base_type = resource_type.split("/")[0]
    if base_type not in _VALID_RESOURCE_TYPES:
        raise ValueError(
            f"resource_type base must be one of {sorted(_VALID_RESOURCE_TYPES)}, "
            f"got {base_type!r}"
        )

    resource = files("ao_kernel.defaults").joinpath(resource_type).joinpath(filename)
    try:
        text = resource.read_text(encoding="utf-8")
    except (FileNotFoundError, TypeError) as e:
        raise DefaultsNotFoundError(
            f"Bundled default not found: {resource_type}/{filename}"
        ) from e
    return json.loads(text)


def load_with_override(
    resource_type: str,
    filename: str,
    workspace: Path | None = None,
) -> Any:
    """Load a JSON resource, preferring workspace override over bundled default.

    If workspace contains resource_type/filename, loads from there.
    Otherwise falls back to the bundled default.
    """
    if workspace is not None:
        override_path = workspace / resource_type / filename
        if override_path.is_file():
            return json.loads(override_path.read_text(encoding="utf-8"))
    return load_default(resource_type, filename)
