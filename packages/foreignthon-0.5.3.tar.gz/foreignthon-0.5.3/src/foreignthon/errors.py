from __future__ import annotations

import sys
import traceback

from .pack import PackNotFoundError, load_pack

_active_lang: str | None = None


def activate(lang_code: str) -> None:
    """Install the bilingual error hook for the given language."""
    global _active_lang
    _active_lang = lang_code
    sys.excepthook = _bilingual_hook


def deactivate() -> None:
    """Restore the default Python error hook."""
    global _active_lang
    _active_lang = None
    sys.excepthook = sys.__excepthook__


def _bilingual_hook(exc_type, exc_value, exc_tb) -> None:
    """
    Print errors in foreign language first, English below.

    [ES] ErrorDeValor: el argumento debe ser un número entero
    [EN] ValueError: argument must be an integer
         Traceback ...
    """
    try:
        pack = load_pack(_active_lang)
        error_messages = pack.get("error_messages", {})
        exceptions = pack.get("exceptions", {})

        # Reverse exceptions map: English name → foreign name
        en_to_foreign = {v: k for k, v in exceptions.items()}

        en_name = exc_type.__name__
        foreign_name = en_to_foreign.get(en_name, en_name)
        foreign_msg = error_messages.get(en_name, str(exc_value))
        lang_code = pack["meta"]["code"].upper()

        print(f"[{lang_code}] {foreign_name}: {foreign_msg}", file=sys.stderr)
        print(f"[EN] {en_name}: {exc_value}", file=sys.stderr)
        print(file=sys.stderr)

    except (PackNotFoundError, Exception):
        # If anything goes wrong with translation, fall back silently
        pass

    # Always print the standard traceback at the end
    traceback.print_exception(exc_type, exc_value, exc_tb)
