from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("foreignthon")
except PackageNotFoundError:
    # Fallback for local editable development or running scripts directly
    __version__ = "0.0.0"