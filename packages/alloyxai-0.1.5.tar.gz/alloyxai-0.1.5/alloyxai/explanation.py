#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
机器学习模型可解释性分析主脚本

统一调用不同的可解释性分析方法，支持通过命令行参数选择分析方法。
"""

import os
import sys
import argparse
import glob
import json
import logging
import time
import pandas as pd
import matplotlib.pyplot as plt


def _get_project_root():
    return os.getcwd()


def _import_explanation_module(module_name):
    if module_name == 'shap_analysis':
        from .explain import shap_analysis as mod
    elif module_name == 'lime_analysis':
        from .explain import lime_analysis as mod
    elif module_name == 'feature_importance_analysis':
        from .explain import feature_importance_analysis as mod
    elif module_name == 'ale_analysis':
        from .explain import ale_analysis as mod
    elif module_name == 'pdp_analysis':
        from .explain import pdp_analysis as mod
    else:
        raise ImportError(f"未知的解释模块: {module_name}")
    return mod


# 设置日志记录
def setup_logging():
    """
    设置日志记录
    
    返回:
    logger: 配置好的日志记录器
    """
    log_dir = os.path.join(_get_project_root(), 'results', 'logs')
    os.makedirs(log_dir, exist_ok=True)
    
    log_filename = f'explanation_{time.strftime("%Y%m%d_%H%M%S")}.log'
    log_path = os.path.join(log_dir, log_filename)
    
    logger = logging.getLogger('Explanation')
    logger.setLevel(logging.INFO)
    
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    file_handler = logging.FileHandler(log_path, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)
    
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(console_handler)
    
    return logger

logger = setup_logging()

# 设置Matplotlib全局样式
plt.rcParams.update({
    'font.size': 24,
    'font.family': 'Times New Roman',
    'axes.titlesize': 28,
    'axes.labelsize': 24,
    'xtick.labelsize': 20,
    'ytick.labelsize': 20,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'axes.linewidth': 1.2,
    'grid.linewidth': 0.6,
    'lines.linewidth': 2.0,
})

# 方法配置字典
METHOD_CONFIGS = {
    'shap': {
        'module': 'shap_analysis',
        'requires': ['shap'],
        'install_hint': 'pip install shap'
    },
    'lime': {
        'module': 'lime_analysis',
        'requires': ['lime'],
        'install_hint': 'pip install lime'
    },
    'feature_importance': {
        'module': 'feature_importance_analysis',
        'requires': [],
        'install_hint': ''
    },
    'ale': {
        'module': 'ale_analysis',
        'requires': [],
        'install_hint': ''
    },
    'pdp': {
        'module': 'pdp_analysis',
        'requires': [],
        'install_hint': ''
    }
}

class Args:
    """参数对象类"""
    def __init__(self, model, data, target, output):
        self.model = model
        self.data = data
        self.target = target
        self.output = output

def parse_arguments():
    """
    解析命令行参数
    
    返回:
    argparse.Namespace: 解析后的参数
    """
    parser = argparse.ArgumentParser(
        description='机器学习模型可解释性分析工具',
        epilog='''
使用示例:
    # 运行所有可解释性分析方法
    python explanation.py -m path/to/model.joblib -d path/to/data.csv
    
    # 运行指定的分析方法
    python explanation.py -m path/to/model.joblib -d path/to/data.csv -e shap lime
    
    # 指定目标变量
    python explanation.py -m path/to/model.joblib -d path/to/data.csv -t target_column
    
    # 指定输出目录
    python explanation.py -m path/to/model.joblib -d path/to/data.csv -o path/to/output
    
    # 自动使用最优模型和最新数据
    python explanation.py
        ''',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument('-m', '--model', type=str,
                        help='训练好的模型文件路径')
    
    parser.add_argument('-d', '--data', type=str,
                        help='数据文件路径')
    
    parser.add_argument('-t', '--target', type=str,
                        help='目标变量名称，默认使用最后一列')
    
    parser.add_argument('-e', '--explanation', type=str, action='append',
                        choices=['shap', 'lime', 'feature_importance', 'ale', 'pdp'],
                        help='可解释性分析方法，默认运行所有方法')
    
    default_output = os.path.join(_get_project_root(), 'results', 'explanation')
    parser.add_argument('-o', '--output', type=str, default=default_output,
                        help=f'输出目录，默认保存在 {default_output}')
    
    args = parser.parse_args()
    
    if not args.explanation:
        args.explanation = ['shap', 'lime', 'feature_importance', 'ale', 'pdp']
    
    if not args.model:
        args.model = find_best_model()
        if not args.model:
            logger.error("错误: 未找到模型文件，请指定模型路径")
            sys.exit(1)
    
    if not args.data:
        args.data = find_latest_data()
        if not args.data:
            logger.error("错误: 未找到数据文件，请指定数据路径")
            sys.exit(1)
    
    return args

def check_dependencies(requires, install_hint):
    """
    检查依赖是否已安装
    
    参数:
    requires: 需要的依赖包列表
    install_hint: 安装提示
    
    返回:
    bool: 所有依赖是否都已安装
    """
    for dep in requires:
        try:
            __import__(dep)
        except ImportError:
            logger.error(f"错误: 缺少依赖: {dep}")
            if install_hint:
                logger.info(f"提示: 请在当前Python环境中安装 {dep} 库")
                logger.info(f"安装命令: {install_hint}")
            return False
    return True

def run_explanation_method(method, model_path, data_path, target_column, output_dir):
    """
    运行指定的可解释性分析方法
    
    参数:
    method: 分析方法名称
    model_path: 模型文件路径
    data_path: 数据文件路径
    target_column: 目标变量列名
    output_dir: 输出目录
    
    返回:
    bool: 运行是否成功
    """
    logger.info(f"\n=== 运行 {method} 分析 ===")
    
    config = METHOD_CONFIGS.get(method)
    if not config:
        logger.error(f"错误: 未知的分析方法 '{method}'")
        return False
    
    # 按模型文件名分子目录，避免换模型后仍打开旧的 decision_tree 等同名图造成误解
    model_stem = os.path.splitext(os.path.basename(model_path))[0] if model_path else 'model'
    method_output_dir = os.path.join(output_dir, method, model_stem)
    os.makedirs(method_output_dir, exist_ok=True)
    
    try:
        if not check_dependencies(config['requires'], config['install_hint']):
            return False

        module = _import_explanation_module(config['module'])
        logger.info(f"{config['module']}模块导入成功！")
        
        args = Args(model_path, data_path, target_column, method_output_dir)
        
        logger.info(f"运行{method.upper()}分析...")
        module.main(args)
        
        logger.info(f"\n=== {method} 分析完成 ===")
        return True
    except Exception as e:
        logger.error(f"错误: {method} 分析失败: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return False

def _collect_model_scores_from_eval_jsons(project_root):
    """从 evaluation/*.json 读取 (score, model_path)，回归为 -RMSE（越大越好）。"""
    eval_patterns = [
        'results/alloy_machine_learning/**/evaluation/*.json',
        'heaML/**/evaluation/*.json',
    ]
    all_eval_files = []
    for pattern in eval_patterns:
        all_eval_files.extend(glob.glob(os.path.join(project_root, pattern), recursive=True))

    model_performance = []
    for eval_file in all_eval_files:
        try:
            with open(eval_file, 'r', encoding='utf-8') as f:
                eval_data = json.load(f)

            model_path = eval_data.get('model_path')
            if not model_path:
                model_name = os.path.basename(eval_file).replace('_evaluation.json', '')
                model_dir = os.path.dirname(os.path.dirname(eval_file))
                model_path = os.path.join(model_dir, 'models', f'{model_name}.joblib')

            if not os.path.exists(model_path):
                continue

            metrics = eval_data.get('metrics', {})
            task_type = eval_data.get('task_type', 'regression')
            if task_type == 'regression':
                rmse = metrics.get('rmse', float('inf'))
                score = -rmse
            elif task_type == 'classification':
                accuracy = metrics.get('accuracy', 0)
                score = accuracy
            else:
                r2 = metrics.get('r2_score', float('-inf'))
                score = r2

            model_performance.append((score, model_path))
        except Exception as e:
            logger.warning(f"警告: 读取评估文件 {eval_file} 失败: {e}")
            continue
    return model_performance


def _collect_model_scores_from_heaml_results(project_root):
    """
    从 heaML 各算法输出的 results/*_results_quick.json（扁平含 rmse）匹配对应 models/*.joblib。
    与 machine_learning 汇总对比表的数据源一致。
    """
    result_patterns = [
        os.path.join(project_root, 'results', 'alloy_machine_learning', '*', 'results', '*_results_quick.json'),
    ]
    model_performance = []
    for pattern in result_patterns:
        for result_path in glob.glob(pattern):
            try:
                with open(result_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                # 扁平 metrics（quick 结果）或嵌套 metrics
                metrics = data.get('metrics', data)
                rmse = metrics.get('rmse')
                if rmse is None:
                    continue
                algo_dir = os.path.dirname(os.path.dirname(result_path))
                models_dir = os.path.join(algo_dir, 'models')
                if not os.path.isdir(models_dir):
                    continue
                joblibs = glob.glob(os.path.join(models_dir, '*.joblib'))
                if not joblibs:
                    continue
                joblibs.sort(key=os.path.getmtime, reverse=True)
                model_path = joblibs[0]
                model_performance.append((-float(rmse), model_path))
            except Exception as e:
                logger.warning(f"警告: 读取训练结果 {result_path} 失败: {e}")
                continue
    return model_performance


def find_best_model():
    """
    查找最优的模型文件
    
    返回:
    str: 最优模型文件路径
    """
    project_root = _get_project_root()

    model_performance = _collect_model_scores_from_eval_jsons(project_root)
    if not model_performance:
        model_performance = _collect_model_scores_from_heaml_results(project_root)

    if not model_performance:
        return find_latest_model()

    model_performance.sort(reverse=True)
    best_model_path = model_performance[0][1]
    logger.info(f"找到最优模型: {best_model_path}")
    return best_model_path

def find_latest_model():
    """
    查找最新的模型文件
    
    返回:
    str: 最新模型文件路径
    """
    project_root = _get_project_root()

    model_patterns = [
        'results/alloy_machine_learning/**/models/*.joblib',
        'heaML/**/models/*.joblib'
    ]
    
    all_models = []
    for pattern in model_patterns:
        all_models.extend(glob.glob(os.path.join(project_root, pattern), recursive=True))
    
    if not all_models:
        return None
    
    all_models.sort(key=os.path.getmtime, reverse=True)
    return all_models[0]

def find_latest_data():
    """
    查找最新的数据文件
    
    返回:
    str: 最新数据文件路径
    """
    project_root = _get_project_root()

    data_patterns = [
        'results/engineer/feature_engineering/*.csv',
        'results/feature_engineering/*.csv',
        'data/*.csv',
        'data/*.xlsx',
    ]
    
    all_data = []
    for pattern in data_patterns:
        all_data.extend(glob.glob(os.path.join(project_root, pattern), recursive=True))
    
    # 排除 Excel 占用时产生的锁文件（~$*.xlsx），避免 Permission denied
    all_data = [p for p in all_data if not os.path.basename(p).startswith('~$')]
    
    if not all_data:
        return None

    def _data_file_sort_key(path):
        """优先使用特征工程 CSV，避免依赖 openpyxl 读 xlsx 或误选临时文件。"""
        p_norm = path.replace('\\', '/')
        if 'engineer/feature_engineering' in p_norm and path.endswith('.csv'):
            tier = 2
        elif path.endswith('.csv'):
            tier = 1
        else:
            tier = 0
        return (tier, os.path.getmtime(path))

    all_data.sort(key=_data_file_sort_key, reverse=True)
    return all_data[0]

def generate_comparison_chart(results_dir, output_dir):
    """
    生成可解释性分析结果对比图表
    
    参数:
    results_dir: 结果目录
    output_dir: 输出目录
    """
    logger.info(f"\n=== 生成可解释性分析对比图表 ===")
    
    try:
        feature_importance_data = {}
        importance_files = glob.glob(os.path.join(results_dir, '**/*feature_importance*.csv'), recursive=True)
        
        for file_path in importance_files:
            method = os.path.basename(os.path.dirname(file_path))
            try:
                df = pd.read_csv(file_path)
                top_features = df.head(10)
                feature_importance_data[method] = top_features
            except Exception as e:
                logger.warning(f"警告: 读取文件 {file_path} 失败: {e}")
                continue
        
        if not feature_importance_data:
            logger.warning("警告: 没有找到特征重要性数据")
            return
        
        plt.figure(figsize=(20, 15), dpi=300)
        
        n_methods = len(feature_importance_data)
        n_rows = (n_methods + 1) // 2
        n_cols = min(2, n_methods)
        
        for i, (method, data) in enumerate(feature_importance_data.items()):
            plt.subplot(n_rows, n_cols, i + 1)
            plt.barh(data['feature'], data['importance'])
            plt.title(f'{method.upper()} Feature Importance', fontsize=24, fontweight='bold')
            plt.xlabel('Importance', fontsize=20)
            plt.ylabel('Feature', fontsize=20)
            plt.xticks(fontsize=18)
            plt.yticks(fontsize=18)
            plt.grid(axis='x', linestyle='--', alpha=0.7)
        
        plt.tight_layout()
        
        chart_path = os.path.join(output_dir, 'explanation_comparison.png')
        plt.savefig(chart_path, bbox_inches='tight', dpi=300)
        logger.info(f"可解释性分析对比图表保存成功: {chart_path}")
        
        plt.close()
    except Exception as e:
        logger.error(f"错误: 生成对比图表失败: {e}")

def run(args=None):
    """主函数"""
    if args is None:
        args = parse_arguments()
    os.makedirs(args.output, exist_ok=True)
    
    success_count = 0
    total_count = len(args.explanation)
    
    for method in args.explanation:
        success = run_explanation_method(method, args.model, args.data, args.target, args.output)
        if success:
            success_count += 1
    
    generate_comparison_chart(args.output, args.output)
    
    logger.info(f"\n=== 任务完成 ===")
    logger.info(f"运行了 {total_count} 个可解释性分析方法")
    logger.info(f"成功: {success_count}")
    logger.info(f"失败: {total_count - success_count}")
    logger.info(f"所有结果已保存到: {args.output}")

if __name__ == '__main__':
    run()
