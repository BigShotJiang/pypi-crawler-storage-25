# -*- coding: utf-8 -*-
"""
数据预处理主脚本
==============

功能说明：
- 调用dataProcessing文件夹中的代码，实现完整的数据预处理功能
- 支持命令行参数，方便用户进行配置
- 将合金成分数据从"元素:百分比"格式转换为化学式格式
- 同时保存处理后的数据为Excel和CSV格式
- 生成详细的处理日志并保存到results/logs目录

使用方法：
1. 直接运行（自动处理data目录下最新的Excel文件）：
   python data_processing.py

2. 指定输入文件：
   python data_processing.py -i input_file.xlsx

3. 指定输出目录：
   python data_processing.py -o custom_output_dir

4. 指定要处理的列名：
   python data_processing.py -c "成分列名"

5. 同时保存为CSV格式：
   python data_processing.py --save-csv

参数说明：
- -i, --input <file_path>：输入的Excel文件路径（可选）
- -o, --output <output_directory>：输出目录（可选，默认为 results/data_pre-processing）
- -c, --column <column_name>：要处理的列名（可选，默认为alloy_composition）
- --save-csv：同时保存为CSV格式（可选，默认只保存Excel）

示例：
# 使用默认设置
python data_processing.py

# 指定输入文件
python data_processing.py -i data.xlsx

# 指定列名并保存CSV
python data_processing.py -i data.xlsx -c "成分" --save-csv

注意：
- 默认处理的输入文件为 'data' 目录下最新的Excel文件
- 输出文件将保存在 'results/data_pre-processing' 目录下
- 日志文件将保存在 'results/logs' 目录下，文件名为 'dataProcessing_时间戳.log'
- 确保运行脚本前已安装所有必要的依赖包
"""

import os
import sys
import argparse
import datetime
import glob

from .dataProcessing import data_preprocessing

load_and_preprocess_data = data_preprocessing.load_and_preprocess_data


def _get_project_root():
    return os.getcwd()


def setup_logging():
    """设置日志文件"""
    project_root = _get_project_root()
    logs_dir = os.path.join(project_root, "results", "logs")
    os.makedirs(logs_dir, exist_ok=True)

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = f"dataProcessing_{timestamp}.log"
    log_path = os.path.join(logs_dir, log_filename)

    return log_path


class Logger:
    def __init__(self, log_path):
        self.terminal = sys.stdout
        self.log = open(log_path, 'w', encoding='utf-8')

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()

    def flush(self):
        self.terminal.flush()
        self.log.flush()


def find_latest_excel_file(directory=None):
    """
    查找指定目录下最新的Excel文件

    参数:
    directory: 要查找的目录（默认是data目录）

    返回:
    str: 最新的Excel文件路径，如果没有找到则返回None
    """
    if directory is None:
        project_root = _get_project_root()
        directory = os.path.join(project_root, "data")

    if not os.path.exists(directory):
        print(f"目录不存在: {directory}")
        return None

    excel_patterns = ["*.xlsx", "*.xls", "*.xlsm"]
    excel_files = []

    for pattern in excel_patterns:
        excel_files.extend(glob.glob(os.path.join(directory, pattern)))

    if not excel_files:
        print(f"在目录 {directory} 中未找到Excel文件")
        return None

    latest_file = max(excel_files, key=os.path.getmtime)
    print(f"找到最新的Excel文件: {latest_file}")
    return latest_file


def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='数据预处理主脚本')

    parser.add_argument('-i', '--input', type=str, help='输入的Excel文件路径')
    parser.add_argument('-o', '--output', type=str, help='输出目录')
    parser.add_argument('-c', '--column', type=str, default='alloy_composition',
                        help='要处理的列名（默认：alloy_composition）')
    parser.add_argument('--save-csv', action='store_true',
                        help='同时保存为CSV格式（默认：只保存Excel）')

    return parser.parse_args()


def process_data(file_path, output_dir, column_name, save_csv=False):
    """
    处理数据文件：执行数据预处理

    参数:
    file_path: 输入文件路径
    output_dir: 输出目录
    column_name: 要处理的列名
    save_csv: 是否同时保存为CSV格式
    """
    print(f"开始处理文件: {file_path}")
    print(f"要处理的列名: {column_name}")
    print(f"输出目录: {output_dir if output_dir else '默认目录'}")
    print(f"保存CSV格式: {'是' if save_csv else '否'}")

    try:
        df = load_and_preprocess_data(
            file_path,
            save_to_file=True,
            column_name=column_name,
            output_dir=output_dir,
            save_csv=save_csv
        )

        print(f"\n处理完成！")
        print(f"\n处理流程总结:")
        print(f"1. 处理的列: {column_name}")
        print(f"2. 处理的数据行数: {len(df)}")
        print(f"3. 输出格式: {'Excel + CSV' if save_csv else 'Excel'}")

    except Exception as e:
        print(f"处理文件时出错: {e}")
        import traceback
        print(traceback.format_exc())
        raise


def run(args=None):
    if args is None:
        args = parse_args()

    project_root = _get_project_root()

    logs_dir = os.path.join(project_root, "results", "logs")
    os.makedirs(logs_dir, exist_ok=True)

    log_path = setup_logging()
    sys.stdout = Logger(log_path)

    print(f"当前工作目录: {os.getcwd()}")
    print(f"日志文件路径: {log_path}")

    if args.input:
        data_file_path = args.input
        if not os.path.isabs(data_file_path):
            data_file_path = os.path.join(project_root, data_file_path)
        print(f"\n使用指定的输入文件: {data_file_path}")
    else:
        print("\n自动查找data目录下最新的Excel文件...")
        data_file_path = find_latest_excel_file()

    if data_file_path is None:
        print("\n无法找到Excel文件，请确保data目录中有Excel文件，或通过 -i 参数指定输入文件")
        sys.exit(1)

    if not os.path.exists(data_file_path):
        print(f"\n错误: 输入文件 '{data_file_path}' 不存在")
        sys.exit(1)

    if not data_file_path.endswith('.xlsx'):
        print(f"\n错误: 输入文件必须是Excel文件，扩展名为.xlsx")
        sys.exit(1)

    print("\n=== 开始数据预处理 ===")
    try:
        process_data(data_file_path, args.output, args.column, args.save_csv)
        print("\n=== 数据预处理完成 ===")
    except Exception as e:
        print(f"\n=== 数据预处理失败 ===")
        print(f"错误: {e}")
        sys.exit(1)


if __name__ == "__main__":
    run()
