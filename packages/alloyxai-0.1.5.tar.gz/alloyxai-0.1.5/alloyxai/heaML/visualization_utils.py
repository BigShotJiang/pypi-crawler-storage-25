# -*- coding: utf-8 -*-
"""
通用可视化工具模块

为机器学习算法提供高质量的可视化功能，支持分类和回归任务
"""

import os
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.metrics import (
    confusion_matrix, precision_recall_curve, roc_curve, auc,
    mean_squared_error, mean_absolute_error, r2_score
)

# 设置全局样式，确保图表质量符合期刊发表标准
plt.rcParams.update({
    'font.size': 24,
    'font.family': 'Times New Roman',  # 期刊常用字体
    'axes.titlesize': 28,
    'axes.labelsize': 24,
    'xtick.labelsize': 20,
    'ytick.labelsize': 20,
    'xtick.major.size': 10,  # 增大x轴主刻度线大小
    'xtick.major.width': 1.0,  # 增大x轴主刻度线宽度
    'ytick.major.size': 10,  # 增大y轴主刻度线大小
    'ytick.major.width': 1.0,  # 增大y轴主刻度线宽度
    'figure.figsize': (12, 8),  # 增大图表大小以容纳更大的字体
    'figure.dpi': 300,  # 高分辨率
    'savefig.dpi': 300,  # 保存时使用高分辨率
    'savefig.format': 'png',  # 默认保存格式
    'axes.linewidth': 1.2,  # 增大坐标轴线条宽度
    'grid.linewidth': 0.6,  # 增大网格线条宽度
    'lines.linewidth': 2.0,  # 线条宽度
    'lines.markersize': 8,  # 增大标记大小
})

# 设置不同算法的配色方案
ALGORITHM_COLORS = {
    'linear_regression': '#1f77b4',  # 蓝色
    'svm': '#9467bd',  # 紫色
    'knn': '#2ca02c',  # 绿色
    'decision_tree': '#8c564b',  # 棕色
    'bayesian': '#ffd700',  # 黄色
    'random_forest': '#4caf50',  # 森林绿
    'gradient_boosting': '#ff7f0e',  # 橙色
    'xgb': '#17becf',  # 青色
    'neural_network': '#1f77b4',  # 蓝色
}

def ensure_directory_exists(directory):
    """
    确保目录存在
    
    参数:
    directory: 目录路径
    """
    if not os.path.exists(directory):
        os.makedirs(directory, exist_ok=True)

def plot_actual_vs_predicted(y_true, y_pred, algorithm_name='algorithm', save_dir=None):
    """
    绘制实际值与预测值的散点图
    
    参数:
    y_true: 实际值
    y_pred: 预测值
    algorithm_name: 算法名称
    save_dir: 保存目录
    
    返回:
    fig: matplotlib Figure对象
    """
    fig, ax = plt.subplots(figsize=(12, 10))
    
    # 计算对角线，用于参考
    min_val = min(min(y_true), min(y_pred))
    max_val = max(max(y_true), max(y_pred))
    ax.plot([min_val, max_val], [min_val, max_val], 'k--', alpha=0.75, linewidth=1.5)
    
    # 绘制散点图
    scatter = ax.scatter(
        y_true, y_pred, 
        alpha=0.6, 
        color=ALGORITHM_COLORS.get(algorithm_name, '#1f77b4')
    )
    
    # 添加标题和标签
    ax.set_title(f'Actual vs Predicted Values ({algorithm_name})', fontsize=28, fontweight='bold')
    ax.set_xlabel('Actual Values', fontsize=24)
    ax.set_ylabel('Predicted Values', fontsize=24)
    
    # 添加网格
    ax.grid(alpha=0.3)
    
    # 添加统计信息
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    
    stats_text = (f'MSE: {mse:.4f}\n'  
                 f'RMSE: {rmse:.4f}\n' 
                 f'MAE: {mae:.4f}\n'  
                 f'R²: {r2:.4f}')
    ax.text(0.05, 0.95, stats_text, transform=ax.transAxes, 
            fontsize=18, verticalalignment='top', 
            bbox=dict(boxstyle='round', alpha=0.1))
    
    # 保存图表
    if save_dir:
        ensure_directory_exists(save_dir)
        save_path = os.path.join(save_dir, f'{algorithm_name}_actual_vs_predicted.png')
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"图表已保存到: {save_path}")
        
        # 保存图表数据到CSV文件
        import pandas as pd
        data_df = pd.DataFrame({
            'actual': y_true,
            'predicted': y_pred
        })
        data_path = os.path.join(save_dir, f'{algorithm_name}_actual_vs_predicted_data.csv')
        data_df.to_csv(data_path, index=False)
        print(f"图表数据已保存到: {data_path}")
    
    return fig

def plot_residuals(y_true, y_pred, algorithm_name='algorithm', save_dir=None):
    """
    绘制残差图
    
    参数:
    y_true: 实际值
    y_pred: 预测值
    algorithm_name: 算法名称
    save_dir: 保存目录
    
    返回:
    fig: matplotlib Figure对象
    """
    residuals = y_true - y_pred
    
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # 绘制残差散点图
    scatter = ax.scatter(
        y_pred, residuals, 
        alpha=0.6, 
        color=ALGORITHM_COLORS.get(algorithm_name, '#1f77b4')
    )
    
    # 添加水平线表示零残差
    ax.axhline(y=0, color='k', linestyle='--', alpha=0.75, linewidth=1.5)
    
    # 添加标题和标签
    ax.set_title(f'Residual Plot ({algorithm_name})', fontsize=28, fontweight='bold')
    ax.set_xlabel('Predicted Values', fontsize=24)
    ax.set_ylabel('Residuals', fontsize=24)
    
    # 添加网格
    ax.grid(alpha=0.3)
    
    # 保存图表
    if save_dir:
        ensure_directory_exists(save_dir)
        save_path = os.path.join(save_dir, f'{algorithm_name}_residuals.png')
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"图表已保存到: {save_path}")
        
        # 保存图表数据到CSV文件
        import pandas as pd
        data_df = pd.DataFrame({
            'predicted': y_pred,
            'residuals': residuals
        })
        data_path = os.path.join(save_dir, f'{algorithm_name}_residuals_data.csv')
        data_df.to_csv(data_path, index=False)
        print(f"图表数据已保存到: {data_path}")
    
    return fig

def plot_coefficient_importance(coefficients, feature_names, algorithm_name='algorithm', save_dir=None):
    """
    绘制系数重要性条形图
    
    参数:
    coefficients: 模型系数
    feature_names: 特征名称
    algorithm_name: 算法名称
    save_dir: 保存目录
    
    返回:
    fig: matplotlib Figure对象
    """
    # 计算系数绝对值
    abs_coeffs = np.abs(coefficients)
    
    # 按绝对值排序
    sorted_indices = np.argsort(abs_coeffs)[::-1]
    sorted_coeffs = coefficients[sorted_indices]
    sorted_features = np.array(feature_names)[sorted_indices]
    
    # 只取前20个特征，避免图表过于拥挤
    if len(sorted_features) > 20:
        sorted_features = sorted_features[:20]
        sorted_coeffs = sorted_coeffs[:20]
    
    fig, ax = plt.subplots(figsize=(14, 10))
    
    # 绘制条形图
    bars = ax.bar(
        np.arange(len(sorted_coeffs)), 
        sorted_coeffs, 
        color=[ALGORITHM_COLORS.get(algorithm_name, '#1f77b4') if coeff >= 0 else '#e377c2' 
               for coeff in sorted_coeffs]
    )
    
    # 在每个柱形上面显示数据
    for bar, coeff in zip(bars, sorted_coeffs):
        if coeff >= 0:
            # 正数柱形，标签显示在柱形顶部，添加小偏移量
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.5, 
                    f'{coeff:.2f}', 
                    ha='center', va='bottom', 
                    fontsize=16)
        else:
            # 负数柱形，标签显示在柱形底部，添加小偏移量
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height - 0.5, 
                    f'{coeff:.2f}', 
                    ha='center', va='top', 
                    fontsize=16)
    
    # 添加标题和标签
    ax.set_title(f'Feature Importance ({algorithm_name})', fontsize=28, fontweight='bold')
    ax.set_xlabel('Features', fontsize=24)
    ax.set_ylabel('Coefficient Value', fontsize=24)
    
    # 设置x轴标签
    ax.set_xticks(np.arange(len(sorted_features)))
    ax.set_xticklabels(sorted_features, rotation=45, ha='right')
    
    # 添加网格
    ax.grid(axis='y', alpha=0.3)
    
    # 调整布局
    plt.tight_layout()
    
    # 保存图表
    if save_dir:
        ensure_directory_exists(save_dir)
        save_path = os.path.join(save_dir, f'{algorithm_name}_coefficient_importance.png')
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"图表已保存到: {save_path}")
        
        # 保存图表数据到CSV文件
        import pandas as pd
        data_df = pd.DataFrame({
            'feature': sorted_features,
            'coefficient': sorted_coeffs,
            'abs_coefficient': np.abs(sorted_coeffs)
        })
        data_path = os.path.join(save_dir, f'{algorithm_name}_coefficient_importance_data.csv')
        data_df.to_csv(data_path, index=False)
        print(f"图表数据已保存到: {data_path}")
    
    return fig

def plot_confusion_matrix(y_true, y_pred, algorithm_name='algorithm', save_dir=None):
    """
    绘制混淆矩阵
    
    参数:
    y_true: 实际值
    y_pred: 预测值
    algorithm_name: 算法名称
    save_dir: 保存目录
    
    返回:
    fig: matplotlib Figure对象
    """
    cm = confusion_matrix(y_true, y_pred)
    
    fig, ax = plt.subplots(figsize=(10, 8))
    
    # 使用seaborn绘制热力图
    sns.heatmap(
        cm, 
        annot=True, 
        fmt='d', 
        cmap='Blues', 
        ax=ax,
        cbar_kws={'label': 'Count'}
    )
    
    # 添加标题和标签
    ax.set_title(f'Confusion Matrix ({algorithm_name})', fontsize=16, fontweight='bold')
    ax.set_xlabel('Predicted Label', fontsize=14)
    ax.set_ylabel('True Label', fontsize=14)
    
    # 调整布局
    plt.tight_layout()
    
    # 保存图表
    if save_dir:
        ensure_directory_exists(save_dir)
        save_path = os.path.join(save_dir, f'{algorithm_name}_confusion_matrix.png')
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"图表已保存到: {save_path}")
    
    return fig

def plot_precision_recall_curve(y_true, y_score, algorithm_name='algorithm', save_dir=None):
    """
    绘制精确率-召回率曲线
    
    参数:
    y_true: 实际值
    y_score: 预测得分
    algorithm_name: 算法名称
    save_dir: 保存目录
    
    返回:
    fig: matplotlib Figure对象
    """
    precision, recall, _ = precision_recall_curve(y_true, y_score)
    pr_auc = auc(recall, precision)
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # 绘制曲线
    ax.plot(
        recall, 
        precision, 
        lw=2, 
        color=ALGORITHM_COLORS.get(algorithm_name, '#1f77b4'),
        label=f'PR curve (AUC = {pr_auc:.3f})'
    )
    
    # 添加随机猜测线
    ax.plot([0, 1], [0.5, 0.5], 'k--', lw=1, label='Random Guess')
    
    # 添加标题和标签
    ax.set_title(f'Precision-Recall Curve ({algorithm_name})', fontsize=16, fontweight='bold')
    ax.set_xlabel('Recall', fontsize=14)
    ax.set_ylabel('Precision', fontsize=14)
    
    # 添加图例
    ax.legend(loc='best', fontsize=12)
    
    # 添加网格
    ax.grid(alpha=0.3)
    
    # 保存图表
    if save_dir:
        ensure_directory_exists(save_dir)
        save_path = os.path.join(save_dir, f'{algorithm_name}_precision_recall_curve.png')
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"图表已保存到: {save_path}")
    
    return fig

def plot_roc_curve(y_true, y_score, algorithm_name='algorithm', save_dir=None):
    """
    绘制ROC曲线
    
    参数:
    y_true: 实际值
    y_score: 预测得分
    algorithm_name: 算法名称
    save_dir: 保存目录
    
    返回:
    fig: matplotlib Figure对象
    """
    fpr, tpr, _ = roc_curve(y_true, y_score)
    roc_auc = auc(fpr, tpr)
    
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # 绘制曲线
    ax.plot(
        fpr, 
        tpr, 
        lw=2, 
        color=ALGORITHM_COLORS.get(algorithm_name, '#1f77b4'),
        label=f'ROC curve (AUC = {roc_auc:.3f})'
    )
    
    # 添加对角线
    ax.plot([0, 1], [0, 1], 'k--', lw=1, label='Random Guess')
    
    # 添加标题和标签
    ax.set_title(f'ROC Curve ({algorithm_name})', fontsize=16, fontweight='bold')
    ax.set_xlabel('False Positive Rate', fontsize=14)
    ax.set_ylabel('True Positive Rate', fontsize=14)
    
    # 添加图例
    ax.legend(loc='best', fontsize=12)
    
    # 添加网格
    ax.grid(alpha=0.3)
    
    # 保存图表
    if save_dir:
        ensure_directory_exists(save_dir)
        save_path = os.path.join(save_dir, f'{algorithm_name}_roc_curve.png')
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"图表已保存到: {save_path}")
    
    return fig

def plot_feature_importance(importances, feature_names, algorithm_name='algorithm', save_dir=None):
    """
    绘制特征重要性条形图
    
    参数:
    importances: 特征重要性
    feature_names: 特征名称
    algorithm_name: 算法名称
    save_dir: 保存目录
    
    返回:
    fig: matplotlib Figure对象
    """
    # 按重要性排序
    sorted_indices = np.argsort(importances)[::-1]
    sorted_importances = importances[sorted_indices]
    sorted_features = np.array(feature_names)[sorted_indices]
    
    # 只取前20个特征，避免图表过于拥挤
    if len(sorted_features) > 20:
        sorted_features = sorted_features[:20]
        sorted_importances = sorted_importances[:20]
    
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # 绘制条形图
    bars = ax.bar(
        np.arange(len(sorted_importances)), 
        sorted_importances, 
        color=ALGORITHM_COLORS.get(algorithm_name, '#1f77b4')
    )
    
    # 添加标题和标签
    ax.set_title(f'Feature Importance ({algorithm_name})', fontsize=16, fontweight='bold')
    ax.set_xlabel('Features', fontsize=14)
    ax.set_ylabel('Importance', fontsize=14)
    
    # 设置x轴标签
    ax.set_xticks(np.arange(len(sorted_features)))
    ax.set_xticklabels(sorted_features, rotation=45, ha='right')
    
    # 添加网格
    ax.grid(axis='y', alpha=0.3)
    
    # 调整布局
    plt.tight_layout()
    
    # 保存图表
    if save_dir:
        ensure_directory_exists(save_dir)
        save_path = os.path.join(save_dir, f'{algorithm_name}_feature_importance.png')
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"图表已保存到: {save_path}")
    
    return fig

def create_regression_visualizations(
    model, X_train, X_test, y_train, y_test, 
    feature_names, algorithm_name='algorithm', 
    save_dir=None
):
    """
    为回归任务创建所有可视化
    
    参数:
    model: 训练好的模型
    X_train: 训练集特征
    X_test: 测试集特征
    y_train: 训练集目标变量
    y_test: 测试集目标变量
    feature_names: 特征名称
    algorithm_name: 算法名称
    save_dir: 保存目录
    
    返回:
    dict: 包含所有图表的字典
    """
    # 确保保存目录存在
    if save_dir:
        ensure_directory_exists(save_dir)
    
    # 生成预测
    y_pred = model.predict(X_test)
    
    visualizations = {}
    
    # 绘制实际值与预测值对比图
    visualizations['actual_vs_predicted'] = plot_actual_vs_predicted(
        y_test, y_pred, algorithm_name, save_dir
    )
    
    # 绘制残差图
    visualizations['residuals'] = plot_residuals(
        y_test, y_pred, algorithm_name, save_dir
    )
    
    # 尝试绘制系数重要性图（如果模型有coef_属性）
    if hasattr(model, 'coef_'):
        try:
            coefficients = model.coef_
            if coefficients.ndim > 1:
                coefficients = coefficients[0]  # 处理多输出情况
            visualizations['coefficient_importance'] = plot_coefficient_importance(
                coefficients, feature_names, algorithm_name, save_dir
            )
        except Exception as e:
            print(f"绘制系数重要性图时出错: {e}")
    
    # 关闭所有图表，避免内存泄漏
    plt.close('all')
    
    return visualizations

def create_classification_visualizations(
    model, X_train, X_test, y_train, y_test, 
    feature_names, algorithm_name='algorithm', 
    save_dir=None
):
    """
    为分类任务创建所有可视化
    
    参数:
    model: 训练好的模型
    X_train: 训练集特征
    X_test: 测试集特征
    y_train: 训练集目标变量
    y_test: 测试集目标变量
    feature_names: 特征名称
    algorithm_name: 算法名称
    save_dir: 保存目录
    
    返回:
    dict: 包含所有图表的字典
    """
    # 确保保存目录存在
    if save_dir:
        ensure_directory_exists(save_dir)
    
    # 生成预测
    y_pred = model.predict(X_test)
    
    visualizations = {}
    
    # 绘制混淆矩阵
    visualizations['confusion_matrix'] = plot_confusion_matrix(
        y_test, y_pred, algorithm_name, save_dir
    )
    
    # 尝试绘制精确率-召回率曲线和ROC曲线
    try:
        # 生成预测概率或得分
        if hasattr(model, 'predict_proba'):
            y_score = model.predict_proba(X_test)[:, 1]
        elif hasattr(model, 'decision_function'):
            y_score = model.decision_function(X_test)
        else:
            y_score = y_pred
        
        # 绘制精确率-召回率曲线
        visualizations['precision_recall_curve'] = plot_precision_recall_curve(
            y_test, y_score, algorithm_name, save_dir
        )
        
        # 绘制ROC曲线
        visualizations['roc_curve'] = plot_roc_curve(
            y_test, y_score, algorithm_name, save_dir
        )
    except Exception as e:
        print(f"绘制分类曲线时出错: {e}")
    
    # 尝试绘制特征重要性图
    if hasattr(model, 'feature_importances_'):
        try:
            importances = model.feature_importances_
            visualizations['feature_importance'] = plot_feature_importance(
                importances, feature_names, algorithm_name, save_dir
            )
        except Exception as e:
            print(f"绘制特征重要性图时出错: {e}")
    elif hasattr(model, 'coef_'):
        try:
            coefficients = model.coef_
            if coefficients.ndim > 1:
                coefficients = coefficients[0]  # 处理多输出情况
            visualizations['coefficient_importance'] = plot_coefficient_importance(
                coefficients, feature_names, algorithm_name, save_dir
            )
        except Exception as e:
            print(f"绘制系数重要性图时出错: {e}")
    
    # 关闭所有图表，避免内存泄漏
    plt.close('all')
    
    return visualizations
