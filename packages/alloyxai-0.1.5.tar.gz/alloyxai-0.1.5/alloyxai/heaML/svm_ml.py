﻿# -*- coding: utf-8 -*-
"""
SVM算法机器学习实现

支持分类和回归任务，提供快速模式和超参数模式
"""

import os
import argparse
import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, confusion_matrix,
    mean_squared_error, mean_absolute_error, r2_score
)
from sklearn.svm import SVC, SVR


import sys
import logging
import time

# 设置日志记录
def setup_logging():
    """
    设置日志记录
    
    返回:
    logger: 配置好的日志记录器
    """
    # 日志目录
    log_dir = os.path.join(os.getcwd(), 'results', 'logs')
    os.makedirs(log_dir, exist_ok=True)
    
    # 日志文件名
    log_filename = f'%s_ml_{time.strftime("%Y%m%d_%H%M%S")}.log' % 'svm'
    log_path = os.path.join(log_dir, log_filename)
    
    # 配置日志
    logger = logging.getLogger('%sML' % 'svm'.upper())
    logger.setLevel(logging.INFO)
    
    # 清除已有的处理器
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # 文件处理器
    file_handler = logging.FileHandler(log_path, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)
    
    # 控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(console_handler)
    
    return logger

# 创建日志记录器
logger = setup_logging()
# 导入可视化工具
from visualization_utils import (
    plot_actual_vs_predicted, plot_residuals, plot_coefficient_importance,
    plot_confusion_matrix
)

def find_latest_feature_engineering_file():
    """
    查找最新的特征工程输出文件
    
    返回:
    str: 最新的特征工程输出文件路径
    """
    # 定义默认的特征工程输出目录
    default_dir = os.path.join(os.getcwd(), 
                               'results', 'engineer', 'feature_engineering')
    
    print(f"\n=== 查找默认数据文件 ===")
    logger.info(f"默认特征工程输出目录: {default_dir}")
    
    # 检查目录是否存在
    if not os.path.exists(default_dir):
        logger.warning(f"警告: 特征工程输出目录不存在: {default_dir}")
        return None
    
    # 查找目录下的CSV和Excel文件
    data_files = []
    for ext in ['.csv', '.xlsx']:
        for root, dirs, files in os.walk(default_dir):
            for file in files:
                if file.endswith(ext):
                    file_path = os.path.join(root, file)
                    # 获取文件修改时间
                    mtime = os.path.getmtime(file_path)
                    data_files.append((mtime, file_path))
    
    # 如果没有找到文件
    if not data_files:
        logger.warning(f"警告: 在特征工程输出目录中未找到数据文件: {default_dir}")
        return None
    
    # 按修改时间排序，获取最新的文件
    data_files.sort(reverse=True)
    latest_file = data_files[0][1]
    
    logger.info(f"找到最新的特征工程输出文件: {latest_file}")
    return latest_file

def read_feature_list():
    """
    读取feature_list.txt文件，获取特征和目标变量
    
    返回:
    tuple: (features, target)，其中features是特征列表，target是目标变量名
    """
    # 特征列表文件路径
    feature_list_path = os.path.join(os.getcwd(), 
                                   'results', 'engineer', 'feature_engineering', 'feature_list.txt')
    
    # 检查文件是否存在
    if not os.path.exists(feature_list_path):
        logger.info(f"未找到feature_list.txt文件: {feature_list_path}")
        return None, None
    
    print(f"\n=== 读取特征列表 ===")
    logger.info(f"特征列表文件: {feature_list_path}")
    
    features = []
    target = None
    
    try:
        with open(feature_list_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # 解析文件内容
        in_features = False
        in_target = False
        
        for line in lines:
            line = line.strip()
            
            # 跳过注释和空行
            if not line or line.startswith('#'):
                if '# 选择的特征:' in line:
                    in_features = True
                    in_target = False
                elif '# 目标变量:' in line:
                    in_features = False
                    in_target = True
                continue
            
            if in_features:
                features.append(line)
            elif in_target:
                target = line
                break
        
        logger.info(f"从feature_list.txt中读取了 {len(features)} 个特征")
        if target:
            logger.info(f"从feature_list.txt中读取了目标变量: {target}")
        else:
            logger.warning("在feature_list.txt中未找到目标变量")
        
        return features, target
    except Exception as e:
        logger.error(f"读取feature_list.txt文件时出错: {e}")
        return None, None

def detect_task_type(y):
    """
    自动检测任务类型
    
    参数:
    y: 目标变量
    
    返回:
    task_type: 任务类型 ('classification' 或 'regression')
    """
    # 计算目标变量的唯一值数量
    unique_values = y.nunique()
    total_values = len(y)
    
    # 如果唯一值数量较少（小于10）或占总样本比例较小（小于5%），则认为是分类任务
    if unique_values < 10 or (unique_values / total_values) < 0.05:
        task_type = 'classification'
    else:
        task_type = 'regression'
    
    print(f"\n=== 自动检测任务类型 ===")
    logger.info(f"目标变量唯一值数量: {unique_values}")
    logger.info(f"总样本数量: {total_values}")
    logger.info(f"检测结果: {task_type}")
    
    return task_type

def load_data(data_path, target_column, feature_list=None):
    """
    加载数据
    
    参数:
    data_path: 数据文件路径
    target_column: 目标变量列名
    feature_list: 特征列表，如果为None则使用所有数值列
    
    返回:
    X: 特征矩阵
    y: 目标变量
    feature_names: 特征名列表
    """
    print(f"\n=== 加载数据 ===")
    logger.info(f"数据文件: {data_path}")
    logger.info(f"目标变量: {target_column}")
    
    # 根据文件扩展名选择读取方法
    if data_path.endswith('.csv'):
        df = pd.read_csv(data_path)
    elif data_path.endswith('.xlsx'):
        df = pd.read_excel(data_path)
    else:
        raise ValueError("不支持的文件格式，请使用CSV或Excel文件")
    
    # 检查目标变量列是否存在
    if target_column not in df.columns:
        raise ValueError(f"目标变量列 '{target_column}' 在数据中不存在")
    
    # 分离特征和目标变量
    # 不仅要drop目标变量列，还要drop目标变量的归一化和标准化版本
    columns_to_drop = [target_column]
    # 添加目标变量的归一化和标准化版本
    for col in df.columns:
        if col.startswith(target_column) and (col.endswith('_normalized') or col.endswith('_scaled')):
            columns_to_drop.append(col)
    
    logger.info(f"需要排除的列: {columns_to_drop}")
    
    if feature_list:
        # 使用指定的特征列表
        logger.info(f"使用feature_list.txt中的特征列表，共 {len(feature_list)} 个特征")
        # 检查特征是否存在
        valid_features = []
        for feature in feature_list:
            if feature in df.columns and feature not in columns_to_drop:
                valid_features.append(feature)
            else:
                logger.warning(f"特征 '{feature}' 不存在或为目标变量，将被跳过")
        
        if not valid_features:
            raise ValueError("没有有效的特征可以使用")
        
        X = df[valid_features]
        feature_names = valid_features
    else:
        # 使用所有非目标变量的数值列
        X = df.drop(columns=columns_to_drop)
        # 只保留数值型特征
        numeric_cols = X.select_dtypes(include=['number']).columns
        X = X[numeric_cols]
        feature_names = list(X.columns)
    
    y = df[target_column]
    
    logger.info(f"特征数量: {X.shape[1]}")
    logger.info(f"样本数量: {X.shape[0]}")
    logger.info(f"特征名: {feature_names}")
    
    return X, y, feature_names
def create_svm_model(task_type, hyperparameters=None):
    """
    创建SVM模型
    
    参数:
    task_type: 任务类型 ('classification' 或 'regression')
    hyperparameters: 超参数字典
    
    返回:
    model: 模型实例
    """
    if hyperparameters is None:
        hyperparameters = {'C': 1.0, 'kernel': 'rbf'}
    
    print(f"\n=== 创建模型 ===")
    logger.info(f"任务类型: {task_type}")
    print(f"算法: {'SVC' if task_type == 'classification' else 'SVR'}")
    print(f"超参数: {hyperparameters}")
    
    # 根据任务类型创建模型
    if task_type == 'classification':
        model = SVC(**hyperparameters)
    elif task_type == 'regression':
        model = SVR(**hyperparameters)
    else:
        raise ValueError(f"不支持的任务类型: {task_type}")
    
    return model

def train_model(X, y, task_type, mode='quick', hyperparameters=None, test_size=0.2):
    """
    训练模型
    
    参数:
    X: 特征矩阵
    y: 目标变量
    task_type: 任务类型 ('classification' 或 'regression')
    mode: 模式 ('quick' 或 'hyperparameter')
    hyperparameters: 自定义超参数字典
    test_size: 测试集大小
    
    返回:
    model: 训练好的模型
    X_train: 训练集特征
    X_test: 测试集特征
    y_train: 训练集目标变量
    y_test: 测试集目标变量
    """
    print(f"\n=== 训练模型 ===")
    logger.info(f"模式: {mode}")
    
    # 分割数据集
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42
    )
    
    logger.info(f"训练集大小: {X_train.shape[0]}")
    logger.info(f"测试集大小: {X_test.shape[0]}")
    
    # 特征标准化
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    if mode == 'quick':
        # 快速模式：使用默认超参数
        model = create_svm_model(task_type, hyperparameters)
        model.fit(X_train_scaled, y_train)
    elif mode == 'hyperparameter':
        # 超参数模式：使用网格搜索
        print("\n执行超参数网格搜索...")
        base_model = create_svm_model(task_type)
        
        # SVM的超参数网格
        if hyperparameters:
            param_grid = hyperparameters
        else:
            param_grid = {
                'C': [0.1, 1, 10],
                'kernel': ['linear', 'rbf'],
                'gamma': ['scale', 'auto']
            }
        
        # 执行网格搜索
        grid_search = GridSearchCV(
            estimator=base_model,
            param_grid=param_grid,
            cv=5,
            scoring='accuracy' if task_type == 'classification' else 'r2',
            n_jobs=-1
        )
        grid_search.fit(X_train_scaled, y_train)
        
        logger.info(f"最佳超参数: {grid_search.best_params_}")
        logger.info(f"最佳交叉验证分数: {grid_search.best_score_:.4f}")
        
        model = grid_search.best_estimator_
    else:
        raise ValueError(f"不支持的模式: {mode}")
    
    return model, X_train_scaled, X_test_scaled, y_train, y_test

def evaluate_model(model, X_test, y_test, task_type):
    """
    评估模型
    
    参数:
    model: 训练好的模型
    X_test: 测试集特征
    y_test: 测试集目标变量
    task_type: 任务类型 ('classification' 或 'regression')
    
    返回:
    metrics: 评估指标字典
    """
    print(f"\n=== 评估模型 ===")
    
    # 预测
    y_pred = model.predict(X_test)
    
    metrics = {}
    
    if task_type == 'classification':
        # 分类任务评估指标
        metrics['accuracy'] = accuracy_score(y_test, y_pred)
        metrics['precision'] = precision_score(y_test, y_pred, average='weighted')
        metrics['recall'] = recall_score(y_test, y_pred, average='weighted')
        metrics['f1_score'] = f1_score(y_test, y_pred, average='weighted')
        metrics['confusion_matrix'] = confusion_matrix(y_test, y_pred).tolist()
        
        logger.info(f"准确率: {metrics['accuracy']:.4f}")
        logger.info(f"精确率: {metrics['precision']:.4f}")
        logger.info(f"召回率: {metrics['recall']:.4f}")
        logger.info(f"F1分数: {metrics['f1_score']:.4f}")
        print(f"混淆矩阵:\n{confusion_matrix(y_test, y_pred)}")
    elif task_type == 'regression':
        # 回归任务评估指标
        metrics['mse'] = mean_squared_error(y_test, y_pred)
        metrics['rmse'] = np.sqrt(metrics['mse'])
        metrics['mae'] = mean_absolute_error(y_test, y_pred)
        metrics['r2'] = r2_score(y_test, y_pred)
        
        logger.info(f"均方误差 (MSE): {metrics['mse']:.4f}")
        logger.info(f"均方根误差 (RMSE): {metrics['rmse']:.4f}")
        logger.info(f"平均绝对误差 (MAE): {metrics['mae']:.4f}")
        logger.info(f"R² 评分: {metrics['r2']:.4f}")
    
    return metrics

def save_model(model, model_path):
    """
    保存模型
    
    参数:
    model: 训练好的模型
    model_path: 模型保存路径
    """
    print(f"\n=== 保存模型 ===")
    logger.info(f"模型保存路径: {model_path}")
    
    # 确保保存目录存在
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    
    # 保存模型
    joblib.dump(model, model_path)
    logger.info("模型保存成功！")

def save_train_test_data(X_train, X_test, y_train, y_test, feature_names, output_dir, mode, target_column):
    """
    保存训练集和测试集数据
    
    参数:
    X_train: 训练集特征
    X_test: 测试集特征
    y_train: 训练集目标变量
    y_test: 测试集目标变量
    feature_names: 特征名称列表
    output_dir: 输出目录
    mode: 模式
    target_column: 目标变量列名
    """
    print(f"\n=== 保存训练集和测试集数据 ===")
    
    # 确保数据保存目录存在
    data_dir = os.path.join(output_dir, 'data')
    os.makedirs(data_dir, exist_ok=True)
    
    # 保存训练集
    train_df = pd.DataFrame(X_train, columns=feature_names)
    train_df[target_column] = y_train.values
    train_path = os.path.join(data_dir, f'train_data_{mode}.csv')
    train_df.to_csv(train_path, index=False, encoding='utf-8')
    logger.info(f"训练集保存到: {train_path}")
    
    # 保存测试集
    test_df = pd.DataFrame(X_test, columns=feature_names)
    test_df[target_column] = y_test.values
    test_path = os.path.join(data_dir, f'test_data_{mode}.csv')
    test_df.to_csv(test_path, index=False, encoding='utf-8')
    logger.info(f"测试集保存到: {test_path}")
    
    # 保存数据集信息
    data_info = {
        'train_size': X_train.shape[0],
        'test_size': X_test.shape[0],
        'feature_count': X_train.shape[1],
        'features': feature_names,
        'target_column': target_column
    }
    info_path = os.path.join(data_dir, f'data_info_{mode}.json')
    import json
    with open(info_path, 'w', encoding='utf-8') as f:
        json.dump(data_info, f, indent=2, ensure_ascii=False)
    logger.info(f"数据集信息保存到: {info_path}")
    logger.info("训练集和测试集保存成功！")


def save_results(metrics, task_type, mode, output_dir):
    """
    保存评估结果
    
    参数:
    metrics: 评估指标字典
    task_type: 任务类型
    mode: 模式
    output_dir: 输出目录
    """
    print(f"\n=== 保存评估结果 ===")
    
    # 确保结果保存目录存在
    results_dir = os.path.join(output_dir, 'results')
    os.makedirs(results_dir, exist_ok=True)
    
    # 结果文件路径
    results_filename = f"{task_type}_svm_results_{mode}.json"
    results_path = os.path.join(results_dir, results_filename)
    
    # 保存结果
    import json
    with open(results_path, 'w', encoding='utf-8') as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)
    
    logger.info(f"评估结果保存到: {results_path}")
    logger.info("结果保存成功！")

def main():
    """
    主函数
    """
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='支持向量机机器学习模型训练工具')
    
    # 数据文件路径参数（可选，默认自动查找特征工程输出结果）
    parser.add_argument('-d', '--data', type=str, help='数据文件路径，默认自动查找特征工程输出结果')
    
    # 目标变量列名参数（可选，默认使用最后一列）
    parser.add_argument('-t', '--target', type=str, help='目标变量列名，默认使用最后一列')
    
    # 可选参数
    parser.add_argument('-T', '--task', type=str, choices=['classification', 'regression'], 
                        help='任务类型: classification (分类) 或 regression (回归)，如果不指定则自动检测')
    parser.add_argument('-m', '--mode', type=str, default='quick', choices=['quick', 'hyperparameter'], 
                        help='模式: quick (快速模式) 或 hyperparameter (超参数模式)')
    # 默认输出目录为项目根目录下的 results/alloy_machine_learning
    default_output = os.path.join(os.getcwd(), 
                                 'results', 'alloy_machine_learning')
    parser.add_argument('-o', '--output', type=str, default=default_output, 
                        help='输出目录，默认保存在项目根目录下的 results/alloy_machine_learning')
    parser.add_argument('--test-size', type=float, default=0.2, 
                        help='测试集大小，默认0.2（20%）')
    parser.add_argument('--params', type=str, nargs='*', 
                        help='自定义超参数，格式为 key=value')
    
    args = parser.parse_args()
    
    # 处理自定义超参数
    hyperparameters = None
    if args.params:
        hyperparameters = {}
        for param in args.params:
            key, value = param.split('=')
            # 尝试将值转换为适当的类型
            try:
                if '.' in value:
                    value = float(value)
                else:
                    value = int(value)
            except ValueError:
                # 如果转换失败，保持字符串类型
                pass
            hyperparameters[key] = value
    
    try:
        # 确定数据文件路径
        data_path = args.data
        if data_path is None:
            # 自动查找最新的特征工程输出文件
            data_path = find_latest_feature_engineering_file()
            if data_path is None:
                raise ValueError("无法找到默认数据文件，请使用 -d 参数指定数据文件路径")
        
        # 读取特征列表文件
        feature_list, feature_list_target = read_feature_list()
        
        # 确定目标变量列名
        target_column = args.target
        if target_column is None:
            # 如果feature_list.txt中有目标变量，则使用它
            if feature_list_target:
                target_column = feature_list_target
                print(f"\n=== 从特征列表文件选择目标变量 ===")
                logger.info(f"从feature_list.txt中读取目标变量: {target_column}")
            else:
                # 否则自动使用最后一列作为目标变量
                # 先读取文件以获取列名
                if data_path.endswith('.csv'):
                    df = pd.read_csv(data_path)
                elif data_path.endswith('.xlsx'):
                    df = pd.read_excel(data_path)
                else:
                    raise ValueError("不支持的文件格式，请使用CSV或Excel文件")
                target_column = df.columns[-1]
                print(f"\n=== 自动选择目标变量 ===")
                logger.info(f"未指定目标变量，自动使用最后一列: {target_column}")
        
        # 加载数据
        X, y, feature_names = load_data(data_path, target_column, feature_list)
        
        # 确定任务类型
        if args.task:
            task_type = args.task
            print(f"\n=== 使用指定的任务类型 ===")
            logger.info(f"任务类型: {task_type}")
        else:
            # 自动检测任务类型
            task_type = detect_task_type(y)
        
        # 训练模型
        model, X_train, X_test, y_train, y_test = train_model(
            X, y, task_type, args.mode, hyperparameters, args.test_size
        )
        
        # 评估模型
        metrics = evaluate_model(model, X_test, y_test, task_type)
        
        # 为SVM模型创建独立的输出目录结构
        svm_output_dir = os.path.join(args.output, 'svm')
        
        # 保存训练集和测试集数据
        save_train_test_data(X_train, X_test, y_train, y_test, feature_names, svm_output_dir, args.mode, target_column)
        
        # 保存模型及其相关信息
        model_dir = os.path.join(svm_output_dir, 'models')
        model_filename = f"{task_type}_svm_model_{args.mode}.joblib"
        model_path = os.path.join(model_dir, model_filename)
        
        # 保存模型信息
        model_info = {
            'model': model,
            'feature_names': feature_names,
            'task_type': task_type,
            'mode': args.mode,
            'hyperparameters': hyperparameters,
            'scaler': StandardScaler()  # 保存标准化器
        }
        
        # 确保保存目录存在
        os.makedirs(os.path.dirname(model_path), exist_ok=True)
        
        # 保存模型
        joblib.dump(model_info, model_path)
        print(f"\n=== 保存模型 ===")
        logger.info(f"模型保存路径: {model_path}")
        logger.info("模型保存成功！")
        
        # 保存评估结果
        save_results(metrics, task_type, args.mode, svm_output_dir)
        
        # 生成可视化图表
        print("\n=== 生成可视化图表 ===")
        images_dir = os.path.join(svm_output_dir, 'images')
        os.makedirs(images_dir, exist_ok=True)
        
        if task_type == 'regression':
            # 回归任务可视化
            y_pred = model.predict(X_test)
            plot_actual_vs_predicted(y_test, y_pred, 'svm', images_dir)
            plot_residuals(y_test, y_pred, 'svm', images_dir)
        elif task_type == 'classification':
            # 分类任务可视化
            y_pred = model.predict(X_test)
            plot_confusion_matrix(y_test, y_pred, 'svm', images_dir)
        
        print("\n=== 训练完成 ===")
        logger.info(f"模型已保存到: {model_path}")
        logger.info(f"评估结果已保存到: {os.path.join(svm_output_dir, 'results')}")
        logger.info(f"可视化图表已保存到: {images_dir}")
        logger.info("所有任务执行成功！")
        
    except Exception as e:
        print(f"\n错误: {e}")
        import traceback
        logger.error(traceback.format_exc())

if __name__ == '__main__':
    main()
