"""
AlloyXAI - 合金材料性能预测与可解释性分析平台

一个用于合金材料性能预测与可解释性分析的机器学习开源软件包。
集成了数据预处理、描述符计算、数据清理、特征工程、
9种机器学习算法 benchmark 以及 SHAP/ALE/LIME 等可解释性分析。
"""

__version__ = "0.1.0"
__author__ = "Chemistry Team"
