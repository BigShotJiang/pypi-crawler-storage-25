﻿# -*- coding: utf-8 -*-
import sys
import os


# 导入所需模块
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

# 元素符号到原子序数的映射
ELEMENT_TO_ATOMIC_NUMBER = {
    'H': 1, 'He': 2, 'Li': 3, 'Be': 4, 'B': 5, 'C': 6, 'N': 7, 'O': 8, 'F': 9, 'Ne': 10,
    'Na': 11, 'Mg': 12, 'Al': 13, 'Si': 14, 'P': 15, 'S': 16, 'Cl': 17, 'Ar': 18, 'K': 19, 'Ca': 20,
    'Sc': 21, 'Ti': 22, 'V': 23, 'Cr': 24, 'Mn': 25, 'Fe': 26, 'Co': 27, 'Ni': 28, 'Cu': 29, 'Zn': 30,
    'Ga': 31, 'Ge': 32, 'As': 33, 'Se': 34, 'Br': 35, 'Kr': 36, 'Rb': 37, 'Sr': 38, 'Y': 39, 'Zr': 40,
    'Nb': 41, 'Mo': 42, 'Tc': 43, 'Ru': 44, 'Rh': 45, 'Pd': 46, 'Ag': 47, 'Cd': 48, 'In': 49, 'Sn': 50,
    'Sb': 51, 'Te': 52, 'I': 53, 'Xe': 54, 'Cs': 55, 'Ba': 56, 'La': 57, 'Ce': 58, 'Pr': 59, 'Nd': 60,
    'Pm': 61, 'Sm': 62, 'Eu': 63, 'Gd': 64, 'Tb': 65, 'Dy': 66, 'Ho': 67, 'Er': 68, 'Tm': 69, 'Yb': 70,
    'Lu': 71, 'Hf': 72, 'Ta': 73, 'W': 74, 'Re': 75, 'Os': 76, 'Ir': 77, 'Pt': 78, 'Au': 79, 'Hg': 80,
    'Tl': 81, 'Pb': 82, 'Bi': 83, 'Po': 84, 'At': 85, 'Rn': 86, 'Fr': 87, 'Ra': 88, 'Ac': 89, 'Th': 90,
    'Pa': 91, 'U': 92, 'Np': 93, 'Pu': 94, 'Am': 95, 'Cm': 96, 'Bk': 97, 'Cf': 98, 'Es': 99, 'Fm': 100
}

# 原子序数到元素符号的映射
ATOMIC_NUMBER_TO_ELEMENT = {v: k for k, v in ELEMENT_TO_ATOMIC_NUMBER.items()}

# σ相形成元素对矩阵（来自HEAPS）
# 第一列是元素A的原子序数，后续列是能与A形成σ相的元素B的原子序数
SFE_MATRIX = [
    [13, 0, 0, 0, 0, 41, 0, 0, 0, 0, 73, 0, 0, 0, 0, 0],      # Al
    [23, 25, 26, 27, 28, 0, 0, 0, 0, 0, 0, 75, 0, 0, 0, 0],    # V
    [24, 25, 26, 27, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],      # Cr
    [25, 0, 0, 0, 0, 0, 43, 0, 0, 0, 0, 75, 0, 0, 0, 0],        # Mn
    [26, 0, 0, 0, 0, 0, 43, 0, 0, 0, 0, 75, 0, 0, 0, 0],        # Fe
    [41, 0, 26, 0, 0, 0, 0, 0, 45, 46, 0, 75, 76, 0, 78, 0],    # Nb
    [42, 25, 26, 27, 0, 0, 43, 44, 0, 0, 0, 75, 76, 77, 0, 0],  # Mo
    [73, 0, 0, 0, 0, 0, 0, 0, 45, 0, 0, 75, 76, 77, 78, 79],    # Ta
    [74, 0, 0, 0, 0, 0, 43, 44, 0, 0, 0, 75, 76, 77, 0, 0]       # W
]

def get_atomic_number(element):
    """
    获取元素的原子序数
    
    参数:
        element (str): 元素符号
        
    返回:
        int: 原子序数
    """
    if element not in ELEMENT_TO_ATOMIC_NUMBER:
        raise ValueError(f"未知元素: {element}")
    return ELEMENT_TO_ATOMIC_NUMBER[element]

def calculate_psfe(formula):
    """
    计算σ相形成对参数PSFE
    公式：PSFE = 2 * 100 * Σ min(c_i, c_j) （对于形成σ相的元素对）
    
    参数:
        formula (str): 化学配方字符串
        
    返回:
        float: PSFE参数值（百分比）
        None: 计算失败时返回None
    """
    try:
        # 解析化学式
        elements, counts = get_elements_and_counts(formula)
        molar_fractions = get_molar_fractions(formula)
        
        # 创建元素及其原子分数的字典
        element_fractions = {elem: molar_fractions[elem] for elem in elements}
        
        # 创建原子序数到元素符号的映射
        atomic_number_to_element = {get_atomic_number(elem): elem for elem in elements if elem in ELEMENT_TO_ATOMIC_NUMBER}
        
        # 计算PSFE
        psfe = 0.0
        
        # 遍历SFE矩阵
        for row in SFE_MATRIX:
            a_atomic_number = row[0]
            
            # 检查元素A是否在合金中
            if a_atomic_number not in atomic_number_to_element:
                continue
            
            elem_a = atomic_number_to_element[a_atomic_number]
            a_fraction = element_fractions[elem_a]
            
            # 检查元素B
            for b_atomic_number in row[1:]:
                if b_atomic_number == 0:
                    continue
                
                # 检查元素B是否在合金中
                if b_atomic_number not in atomic_number_to_element:
                    continue
                
                elem_b = atomic_number_to_element[b_atomic_number]
                b_fraction = element_fractions[elem_b]
                
                # 计算最小原子分数并累加到PSFE
                min_fraction = min(a_fraction, b_fraction)
                psfe += min_fraction
                
                # 从元素分数中减去已计算的部分，避免重复计算
                element_fractions[elem_a] -= min_fraction
                element_fractions[elem_b] -= min_fraction
        
        # 乘以200（2*100）得到百分比
        psfe = round(psfe * 200, 2)
        
        # 限制最大值为100%
        if psfe > 100:
            psfe = 100
        
        return psfe
        
    except Exception as e:
        print(f"[PSFE参数错误] {e}")
        return None

if __name__ == "__main__":
    print("===== σ相形成对参数PSFE测试 =====")
    print("公式: PSFE = 2 * 100 * Σ min(c_i, c_j) （对于形成σ相的元素对）")
    
    # 测试用例
    test_formulas = [
        "FeNiCoCrMn",     # 典型高熵合金
        "AlCrFeNiMo",     # 含Mo的合金
        "NbFeNi",         # 含Nb的合金
        "TaWReOsIr",      # 含Ta、W的合金
        "FeCr",           # 二元合金
        "Fe",             # 单一元素
    ]
    
    for formula in test_formulas:
        psfe = calculate_psfe(formula)
        if psfe is not None:
            print(f"{formula:<20} PSFE = {psfe:.2f}%")
        else:
            print(f"{formula:<20} 计算失败")
    
    print("\n测试完成!")
