﻿# -*- coding: utf-8 -*-
import re
import sys
import os


# 导入半径数据模块
from ..config import radius_data

# 导入化学式解析模块
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

def average_atomic_radius_calculated(formula):
    """根据化学式计算合金的平均原子半径（计算半径）"""
    try:
        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效半径数据
        for elem in elements:
            if radius_data.radius_calculated_dict is None or elem not in radius_data.radius_calculated_dict:
                raise ValueError(f"元素 {elem} 没有可用的原子半径数据")
            r = radius_data.radius_calculated_dict.get(elem)
            if r is None:
                raise ValueError(f"元素 {elem} 的计算半径数据为None，此合金不适合计算计算半径")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        radii = [radius_data.radius_calculated_dict[elem] for elem in elements]
        return sum(c * r for c, r in zip(concentrations, radii))
    except Exception as e:
        print(f"[calculated 出错] {e}")
        return None


def average_atomic_radius_empirical(formula):
    """根据化学式计算合金的平均原子半径（经验半径）"""
    try:
        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效半径数据
        for elem in elements:
            if radius_data.radius_empirical_dict is None or elem not in radius_data.radius_empirical_dict:
                raise ValueError(f"元素 {elem} 没有可用的原子半径数据")
            r = radius_data.radius_empirical_dict.get(elem)
            if r is None:
                raise ValueError(f"元素 {elem} 的经验半径数据为None，此合金不适合计算经验半径")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        radii = [radius_data.radius_empirical_dict[elem] for elem in elements]
        return sum(c * r for c, r in zip(concentrations, radii))
    except Exception as e:
        print(f"[empirical 出错] {e}")
        return None


def average_atomic_radius_covalent(formula):
    """根据化学式计算合金的平均原子半径（共价半径）"""
    try:
        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效半径数据
        for elem in elements:
            if radius_data.radius_covalent_dict is None or elem not in radius_data.radius_covalent_dict:
                raise ValueError(f"元素 {elem} 没有可用的原子半径数据")
            r = radius_data.radius_covalent_dict.get(elem)
            if r is None:
                raise ValueError(f"元素 {elem} 的共价半径数据为None，此合金不适合计算共价半径")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        radii = [radius_data.radius_covalent_dict[elem] for elem in elements]
        return sum(c * r for c, r in zip(concentrations, radii))
    except Exception as e:
        print(f"[covalent 出错] {e}")
        return None


def average_atomic_radius_vanderWaals(formula):
    """根据化学式计算合金的平均原子半径（范德华半径）"""
    try:
        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效半径数据
        for elem in elements:
            if radius_data.radius_vdw_dict is None or elem not in radius_data.radius_vdw_dict:
                raise ValueError(f"元素 {elem} 没有可用的原子半径数据")
            r = radius_data.radius_vdw_dict.get(elem)
            if r is None:
                raise ValueError(f"元素 {elem} 的范德华半径数据为None，此合金不适合计算范德华半径")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        radii = [radius_data.radius_vdw_dict[elem] for elem in elements]
        return sum(c * r for c, r in zip(concentrations, radii))
    except Exception as e:
        print(f"[vdW 出错] {e}")
        return None


if __name__ == '__main__':
    # 测试不同类型的化学式
    test_formulas = [
        "Fe2Ni",      # 简单合金
        "CuZn",       # 二元合金
        "FeCoCrNi",   # 四元合金
        "(Fe0.5Ni0.5)2O3"  # 带括号和小数系数的复杂化学式
    ]
    
    # 计算半径测试
    print("=== 平均原子半径测试（计算半径）===")
    for formula in test_formulas:
        result = average_atomic_radius_calculated(formula)
        print(f"{formula}: {result} Å")
    
    # 经验半径测试
    print("\n=== 平均原子半径测试（经验半径）===")
    for formula in test_formulas:
        result = average_atomic_radius_empirical(formula)
        print(f"{formula}: {result} Å")
    
    # 共价半径测试
    print("\n=== 平均原子半径测试（共价半径）===")
    for formula in test_formulas:
        result = average_atomic_radius_covalent(formula)
        print(f"{formula}: {result} Å")
    
    # 范德华半径测试
    print("\n=== 平均原子半径测试（范德华半径）===")
    for formula in test_formulas:
        result = average_atomic_radius_vanderWaals(formula)
        print(f"{formula}: {result} Å")
    
    # 摩尔浓度测试
    print("\n=== 摩尔浓度测试 ===")
    for formula in test_formulas:
        try:
            molar_fractions = get_molar_fractions(formula)
            print(f"{formula} 摩尔分数: {molar_fractions}")
            print(f"摩尔分数总和: {sum(molar_fractions.values()):.10f}")
            # 验证摩尔分数总和是否接近1.0
            assert abs(sum(molar_fractions.values()) - 1.0) < 1e-9, "摩尔分数总和不等于1.0"
            print(f"[OK] {formula} 摩尔分数验证通过")
        except Exception as e:
            print(f"[ERROR] {formula} 摩尔分数测试失败: {e}")
    
    print("\n所有测试完成！")
