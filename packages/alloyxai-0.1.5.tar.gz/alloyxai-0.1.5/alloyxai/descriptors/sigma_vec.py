﻿# -*- coding: utf-8 -*-
import sys
import os
import math


# 导入必要的模块
from ..utilities.formula_parser import get_molar_fractions
from .vec import average_vec, valence_electrons

def calculate_sigma_vec(formula):
    """
    根据化学式计算合金/化合物的价电子浓度标准差(σ VEC)
    
    使用公式：
    σ VEC = √(Σ(c_i*(VEC_i-VEC̄)^2))
    
    其中：
    - c_i 是元素i的摩尔分数（或浓度）
    - VEC_i 是元素i的价电子数
    - VEC̄ 是平均价电子浓度
    
    参数:
        formula (str): 化学式字符串，例如 "FeCu", "Al2O3", "(Fe0.5Ni0.5)2O3"
    
    返回:
        float: 价电子浓度标准差，计算失败返回None
    """
    try:
        # 获取元素和摩尔分数
        molar_fractions = get_molar_fractions(formula)
        
        # 检查所有元素是否有有效价电子数据
        for elem in molar_fractions:
            if elem not in valence_electrons:
                raise ValueError(f"元素 {elem} 不存在，请检查元素书写是否正确")
            vec = valence_electrons.get(elem)
            if vec is None:
                raise ValueError(f"元素 {elem} 的价电子数据为 None")
        
        # 计算平均价电子浓度
        avg_vec = average_vec(formula)
        if avg_vec is None:
            raise ValueError("无法计算平均价电子浓度")
        
        # 计算加权方差：Σ(c_i*(VEC_i-VEC̄)^2)
        variance = 0.0
        for elem, fraction in molar_fractions.items():
            vec_i = valence_electrons[elem]
            variance += fraction * ((vec_i - avg_vec) ** 2)
        
        # 返回标准差
        return math.sqrt(variance)
        
    except Exception as e:
        print(f"[σ VEC 计算出错] {e}")
        return None

# 如果作为主程序运行，提供测试用例
if __name__ == "__main__":
    # 测试不同类型的化学式
    test_formulas = [
        "Fe2Ni",      # 简单合金
        "CuZn",       # 二元合金
        "Al2O3",      # 含氧化合物
        "FeCoCrNi",   # 四元合金
        "(Fe0.5Ni0.5)2O3"  # 带括号和小数系数的复杂化学式
    ]
    
    print("=== 价电子浓度标准差(σ VEC)测试 ===")
    for formula in test_formulas:
        result = calculate_sigma_vec(formula)
        print(f"{formula}: {result}")
    
    # 手动验证一个简单案例
    print("\n=== 手动验证案例（CuZn）===")
    formula = "CuZn"
    molar_fractions = get_molar_fractions(formula)
    avg_vec = average_vec(formula)
    
    print(f"Cu的价电子数: {valence_electrons['Cu']}, 摩尔分数: {molar_fractions['Cu']}")
    print(f"Zn的价电子数: {valence_electrons['Zn']}, 摩尔分数: {molar_fractions['Zn']}")
    print(f"平均VEC: {avg_vec}")
    
    # 手动计算方差和标准差
    manual_variance = 0
    for elem, fraction in molar_fractions.items():
        manual_variance += fraction * ((valence_electrons[elem] - avg_vec) ** 2)
    manual_sigma = math.sqrt(manual_variance)
    
    print(f"手动计算σ VEC: {manual_sigma}")
    print(f"函数计算σ VEC: {calculate_sigma_vec(formula)}")