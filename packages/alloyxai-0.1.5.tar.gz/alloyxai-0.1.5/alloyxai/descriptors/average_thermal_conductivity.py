﻿# -*- coding: utf-8 -*-
# 导入必要的模块
import sys
import os
import re


# 导入化学式解析模块
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

# 导热性数据 (W/(m·K))
thermal_conductivity_dict = {
    "H": 0.1805, "He": 0.1513, "Li": 85, "Be": 190, "B": 27, "C": 140, "N": 0.02583, "O": 0.02658,
    "F": 0.0277, "Ne": 0.0491, "Na": 140, "Mg": 160, "Al": 235, "Si": 150, "P": 0.236, "S": 0.205,
    "Cl": 0.0089, "Ar": 0.01772, "K": 100, "Ca": 200, "Sc": 16, "Ti": 22, "V": 31, "Cr": 94,
    "Mn": 7.8, "Fe": 80, "Co": 100, "Ni": 91, "Cu": 400, "Zn": 120, "Ga": 29, "Ge": 60,
    "As": 50, "Se": 0.52, "Br": 0.12, "Kr": 0.00943, "Rb": 58, "Sr": 35, "Y": 17, "Zr": 23,
    "Nb": 54, "Mo": 139, "Tc": 51, "Ru": 120, "Rh": 150, "Pd": 72, "Ag": 430, "Cd": 97,
    "In": 82, "Sn": 67, "Sb": 24, "Te": 3, "I": 0.449, "Xe": 0.00565, "Cs": 36, "Ba": 18,
    "La": 13, "Ce": 11, "Pr": 13, "Nd": 17, "Pm": 15, "Sm": 13, "Eu": 14, "Gd": 11, "Tb": 11,
    "Dy": 11, "Ho": 16, "Er": 15, "Tm": 17, "Yb": 39, "Lu": 16, "Hf": 23, "Ta": 57, "W": 170,
    "Re": 48, "Os": 88, "Ir": 150, "Pt": 72, "Au": 320, "Hg": 8.3, "Tl": 46, "Pb": 35, "Bi": 8,
    "Po": None, "At": 2, "Rn": 0.00361, "Fr": None, "Ra": 19, "Ac": 12, "Th": 54, "Pa": 47,
    "U": 27, "Np": 6, "Pu": 6, "Am": 10, "Cm": None, "Bk": 10, "Cf": None, "Es": None, "Fm": None,
    "Md": None, "No": None, "Lr": None, "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None,
    "Mt": None, "Ds": None, "Rg": None, "Cn": None, "Nh": None, "Fl": None, "Mc": None, "Lv": None,
    "Ts": None, "Og": None
}

# 导热性计算
def average_thermal_conductivity(formula):
    """根据化学式计算合金的平均导热性（原子分数加权）"""
    try:
        # 使用导入的化学式解析模块获取元素列表
        elements, _ = get_elements_and_counts(formula)
        
        # 验证所有元素都有导热性数据
        for elem in elements:
            if thermal_conductivity_dict is None or elem not in thermal_conductivity_dict:
                raise ValueError(f"元素 {elem} 没有可用的导热性数据")
            tc = thermal_conductivity_dict.get(elem)
            if tc is None:
                raise ValueError(f"元素 {elem} 的导热性数据为 None，此合金不适合计算平均导热性")
        
        # 使用formula_parser模块中的get_molar_fractions函数获取摩尔分数
        molar_fractions = get_molar_fractions(formula)
        
        # 提取对应的导热性值和摩尔分数
        tc_values = [thermal_conductivity_dict[elem] for elem in elements]
        concentrations = [molar_fractions[elem] for elem in elements]

        # 加权平均计算：property = Σ(c_i × property_i)
        return sum(c * tc for c, tc in zip(concentrations, tc_values))

    except Exception as e:
        print(f"[thermal_conductivity 出错] {e}")
        return None

# 测试部分
if __name__ == "__main__":
    # 测试用例
    test_formulas = ["Al", "Cu", "Fe", "Ni", "FeCu", "Al2CoCrFeNi"]
    
    print("=== 平均导热性测试 ===")
    for formula in test_formulas:
        try:
            avg_tc = average_thermal_conductivity(formula)
            if avg_tc is not None:
                print(f"{formula}: {avg_tc:.4f} W/(m·K)")
        except Exception as e:
            print(f"{formula}: 计算失败 - {e}")
    
    print("\n所有测试完成！")
