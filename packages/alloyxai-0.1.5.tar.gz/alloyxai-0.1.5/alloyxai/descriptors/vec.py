﻿# -*- coding: utf-8 -*-
import sys
import os


import re
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

# 价电子浓度字典
valence_electrons = {
    "H": 1, "He": 2,
    "Li": 1, "Be": 2, "B": 3, "C": 4, "N": 5, "O": 6, "F": 7, "Ne": 8,
    "Na": 1, "Mg": 2, "Al": 3, "Si": 4, "P": 5, "S": 6, "Cl": 7, "Ar": 8,
    "K": 1, "Ca": 2, "Sc": 3, "Ti": 4, "V": 5, "Cr": 6, "Mn": 7, "Fe": 8, "Co": 9, "Ni": 10, "Cu": 1, "Zn": 2, "Ga": 3, "Ge": 4, "As": 5, "Se": 6, "Br": 7, "Kr": 8,
    "Rb": 1, "Sr": 2, "Y": 3, "Zr": 4, "Nb": 5, "Mo": 6, "Tc": 7, "Ru": 8, "Rh": 9, "Pd": 10,
    "Ag": 1, "Cd": 2, "In": 3, "Sn": 4, "Sb": 5, "Te": 6, "I": 7, "Xe": 8,
    "Cs": 1, "Ba": 2, "La": 3, "Ce": 3, "Pr": 3, "Nd": 2, "Pm": 2, "Sm": 2, "Eu": 2,
    "Gd": 3, "Tb": 3, "Dy": 3, "Ho": 3, "Er": 3, "Tm": 3, "Yb": 2, "Lu": 3,
    "Hf": 4, "Ta": 5, "W": 6, "Re": 7, "Os": 8, "Ir": 9, "Pt": 10,
    "Au": 1, "Hg": 2, "Tl": 3, "Pb": 4, "Bi": 5, "Po": 6, "At": 7, "Rn": 8,
    "Fr": 1, "Ra": 2, "Ac": 3, "Th": 4, "Pa": 5, "U": 6, "Np": 5,
    "Pu": 3, "Am": 3, "Cm": 3, "Bk": 3, "Cf": 3, "Es": 3, "Fm": 3, "Md": 3, "No": 2, "Lr": 3,
    "Rf": 4, "Db": 5, "Sg": 6, "Bh": 7, "Hs": 8, "Mt": 9, "Ds": 10,
    "Rg": 1, "Cn": 2, "Nh": 3, "Fl": 4, "Mc": 5, "Lv": 6, "Ts": 7, "Og": 8
}

def average_vec(formula):
    r"""
    根据化学式计算合金/化合物的平均价电子浓度(VEC)
    
    使用公式：
    \overline{VEC} = \sum_{i=1}^{n}c_i \cdot VEC_i
    
    其中：
    - c_i 是元素i的摩尔分数（或浓度）
    - VEC_i 是元素i的价电子数
    
    参数:
        formula (str): 化学式字符串，例如 "FeCu", "Al2O3", "(Fe0.5Ni0.5)2O3"
    
    返回:
        float: 平均价电子浓度值，计算失败返回None
    """
    try:
        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效价电子数据
        for elem in elements:
            if elem not in valence_electrons:
                raise ValueError(f"元素 {elem} 不存在，请检查元素书写是否正确")
            vec = valence_electrons.get(elem)
            if vec is None:
                raise ValueError(f"元素 {elem} 的价电子数据为 None，此化合物不适合计算平均VEC")

        # 计算总原子数和各元素浓度
        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        
        # 获取各元素的价电子数
        vecs = [valence_electrons[elem] for elem in elements]
        
        # 计算平均价电子浓度：sum(c_i * VEC_i)
        return sum(c * vec for c, vec in zip(concentrations, vecs))
    except Exception as e:
        print(f"[VEC 出错] {e}")
        return None


# 如果作为主程序运行，提供一些测试用例
if __name__ == "__main__":
    # 测试不同类型的化学式
    test_formulas = [
        "Fe2Ni",      # 简单合金
        "CuZn",       # 二元合金
        "Al2O3",      # 含氧化合物
        "FeCoCrNi",   # 四元合金
        "(Fe0.5Ni0.5)2O3"  # 带括号和小数系数的复杂化学式
    ]
    
    print("=== 平均价电子浓度(VEC)测试 ===")
    for formula in test_formulas:
        result = average_vec(formula)
        print(f"{formula}: {result}")
    
    # 摩尔浓度测试
    print("\n=== 摩尔浓度测试 ===")
    for formula in test_formulas:
        try:
            molar_fractions = get_molar_fractions(formula)
            print(f"{formula} 摩尔分数: {molar_fractions}")
            print(f"摩尔分数总和: {sum(molar_fractions.values()):.10f}")
            # 验证摩尔分数总和是否接近1.0
            assert abs(sum(molar_fractions.values()) - 1.0) < 1e-9, "摩尔分数总和不等于1.0"
            print(f"[OK] {formula} 摩尔分数验证通过")
        except Exception as e:
            print(f"[FAIL] {formula} 摩尔分数测试失败: {e}")
    
    print("\n所有测试完成！")

