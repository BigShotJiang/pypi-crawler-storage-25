﻿# -*- coding: utf-8 -*-
import re
import math

# 导入必要的模块
import sys
import os


# 导入化学式解析模块
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions
from .average_electric_conductivity import average_electric_conductivity, electric_conductivity_dict

"""
根据化学式计算合金的导电性加权偏差 δ(EC)
使用公式: δ(EC) = √{∑_{i=1}^{n}{c_i(1-EC_i/EC̄)^2}}

参数:
    formula : str
        化学式，例如 "FeNi", "Al2CoCrFeNi"
返回:
    float 或 None
        成功时返回δ(EC)值；失败时返回None
"""

# 计算导电性加权偏差
def delta_electric_conductivity(formula):
    """
    根据化学式计算合金的导电性加权偏差 δ(EC)
    使用公式: δ(EC) = √{∑_{i=1}^{n}{c_i(1-EC_i/EC̄)^2}}
    
    Args:
        formula: 化学式字符串
    
    Returns:
        float: 导电性加权偏差δ(EC)，计算失败返回None
    """
    try:
        # 1. 解析化学式获取元素列表和原子计数
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效导电性数据
        for elem in elements:
            if elem not in electric_conductivity_dict:
                raise ValueError(f"元素 {elem} 没有导电性数据")
            if electric_conductivity_dict[elem] is None:
                raise ValueError(f"元素 {elem} 的导电性数据为 None，无法计算导电性偏差")
        
        # 2. 计算平均导电性
        EC_bar = average_electric_conductivity(formula)
        if EC_bar is None:
            raise ValueError("无法计算平均导电性")
        if EC_bar <= 0:
            raise ValueError(f"平均导电性 {EC_bar} 无效（必须为正值）")
        
        # 3. 计算原子分数
        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        
        # 4. 计算 δ(EC)
        delta = math.sqrt(sum(
            ci * (1 - electric_conductivity_dict[elem] / EC_bar) ** 2
            for elem, ci in zip(elements, concentrations)
        ))
        return delta
    
    except ValueError as e:
        print(f"[δ(EC) 出错] {e}")
        return None
    except Exception as e:
        print(f"[δ(EC) 计算异常] {e}")
        return None

# 内部函数：验证化学式格式
def _validate_formula(formula):
    """
    验证化学式格式是否有效
    
    Args:
        formula: 化学式字符串
    
    Returns:
        tuple: (是否有效, 错误信息)
    """
    if not formula or not isinstance(formula, str):
        return False, "化学式不能为空且必须是字符串类型"
    
    # 检查是否包含有效元素符号的模式（简化检查）
    # 实际的化学式验证应该由formula_parser模块处理
    return True, ""


if __name__ == '__main__':
    # 测试不同类型的化学式
    test_formulas = [
        "Al",            # 单元素
        "Cu",            # 单元素
        "Fe",            # 单元素
        "Ni",            # 单元素
        "FeNi",          # 二元合金
        "Fe2Ni",         # 简单合金带系数
        "FeCu",          # 二元合金
        "Al2CoCrFeNi"    # 五元高熵合金
    ]
    
    # 导电性偏差测试
    print("=== 导电性加权偏差测试 ===")
    print("使用公式: δ(EC) = √{∑c_i(1-EC_i/EC̄)^2}")
    print("=" * 70)
    
    for formula in test_formulas:
        print(f"\n化学式: {formula}")
        result = delta_electric_conductivity(formula)
        if result is not None:
            print(f"  导电性偏差 δ(EC): {result:.6f}")
        else:
            print(f"  导电性偏差 δ(EC): 计算失败")
    
    # 验证原子分数计算
    print("\n=== 原子分数验证 ===")
    print("=" * 70)
    for formula in test_formulas:
        try:
            molar_fractions = get_molar_fractions(formula)
            print(f"{formula} 原子分数: {molar_fractions}")
            total = sum(molar_fractions.values())
            print(f"  原子分数总和: {total:.10f} (验证: {abs(total - 1.0) < 1e-10})")
        except Exception as e:
            print(f"{formula} 原子分数计算失败: {e}")
    
    print("\n所有测试完成！")
