﻿# -*- coding: utf-8 -*-
import re
import math

# 导入必要的模块
import sys
import os


# 导入化学式解析模块
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions
from .average_thermal_conductivity import average_thermal_conductivity, thermal_conductivity_dict

"""
根据化学式计算合金的导热性加权偏差 δ(TC)
使用公式: δ(TC) = √{∑_{i=1}^{n}{c_i(1-TC_i/TC̄)^2}}

参数:
    formula : str
        化学式，例如 "FeNi", "Al2CoCrFeNi"
返回:
    float 或 None
        成功时返回δ(TC)值；失败时返回None
"""

# 计算导热性加权偏差
def delta_thermal_conductivity(formula):
    """
    根据化学式计算合金的导热性加权偏差 δ(TC)
    使用公式: δ(TC) = √{∑_{i=1}^{n}{c_i(1-TC_i/TC̄)^2}}
    
    Args:
        formula: 化学式字符串
    
    Returns:
        float: 导热性加权偏差δ(TC)，计算失败返回None
    """
    try:
        # 1. 解析化学式获取元素列表和原子计数
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效导热性数据
        for elem in elements:
            if elem not in thermal_conductivity_dict:
                raise ValueError(f"元素 {elem} 没有导热性数据")
            if thermal_conductivity_dict[elem] is None:
                raise ValueError(f"元素 {elem} 的导热性数据为 None，无法计算导热性偏差")
        
        # 2. 计算平均导热性
        TC_bar = average_thermal_conductivity(formula)
        if TC_bar is None:
            raise ValueError("无法计算平均导热性")
        if TC_bar <= 0:
            raise ValueError(f"平均导热性 {TC_bar} 无效（必须为正值）")
        
        # 3. 计算原子分数
        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        
        # 4. 计算 δ(TC)
        delta = math.sqrt(sum(
            ci * (1 - thermal_conductivity_dict[elem] / TC_bar) ** 2
            for elem, ci in zip(elements, concentrations)
        ))
        return delta
    
    except ValueError as e:
        print(f"[δ(TC) 出错] {e}")
        return None
    except Exception as e:
        print(f"[δ(TC) 计算异常] {e}")
        return None

# 内部函数：验证化学式格式
def _validate_formula(formula):
    """
    验证化学式格式是否有效
    
    Args:
        formula: 化学式字符串
    
    Returns:
        tuple: (是否有效, 错误信息)
    """
    if not formula or not isinstance(formula, str):
        return False, "化学式不能为空且必须是字符串类型"
    
    # 检查是否包含有效元素符号的模式（简化检查）
    # 实际的化学式验证应该由formula_parser模块处理
    return True, ""


if __name__ == '__main__':
    # 测试不同类型的化学式
    test_formulas = [
        "Al",            # 单元素
        "Cu",            # 单元素
        "Fe",            # 单元素
        "Ni",            # 单元素
        "FeNi",          # 二元合金
        "Fe2Ni",         # 简单合金带系数
        "FeCu",          # 二元合金
        "Al2CoCrFeNi"    # 五元高熵合金
    ]
    
    # 导热性偏差测试
    print("=== 导热性加权偏差测试 ===")
    print("使用公式: δ(TC) = √{∑c_i(1-TC_i/TC̄)^2}")
    print("=" * 70)
    
    for formula in test_formulas:
        print(f"\n化学式: {formula}")
        result = delta_thermal_conductivity(formula)
        if result is not None:
            print(f"  导热性偏差 δ(TC): {result:.6f}")
        else:
            print(f"  导热性偏差 δ(TC): 计算失败")
    
    # 验证原子分数计算
    print("\n=== 原子分数验证 ===")
    print("=" * 70)
    for formula in test_formulas:
        try:
            molar_fractions = get_molar_fractions(formula)
            print(f"{formula} 原子分数: {molar_fractions}")
            total = sum(molar_fractions.values())
            print(f"  原子分数总和: {total:.10f} (验证: {abs(total - 1.0) < 1e-10})")
        except Exception as e:
            print(f"{formula} 原子分数计算失败: {e}")
    
    print("\n所有测试完成！")
