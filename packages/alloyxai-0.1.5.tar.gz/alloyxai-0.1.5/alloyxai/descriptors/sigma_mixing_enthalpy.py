﻿# -*- coding: utf-8 -*-
import sys
import os
import math
import json


# 使用绝对导入混合焓计算函数
from .mixing_enthalpy import mixing_enthalpy, HIJ_DATA
# 使用绝对导入formula_parser模块
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

def sigma_mixing_enthalpy(formula):
    """
    计算混合焓的加权标准差 σΔH
    
    公式: σΔH = √{∑_{i=1,i≠j}^{n} c_i c_j (H_{i,j} - ΔH_{mix})²}
    
    参数:
        formula (str): 化学式字符串，例如 'Fe2Ni', 'CuZn', 'Al2O3'
    
    返回:
        float: 混合焓的标准差
    """
    try:
        # 检查输入类型
        if not isinstance(formula, str):
            raise ValueError("化学式必须是字符串类型")
        
        # 使用formula_parser解析化学式
        molar_fractions = get_molar_fractions(formula)
        elements = list(molar_fractions.keys())
        
        # 检查所有元素是否在Hij数据库中
        for element in elements:
            if not any((element == e1 or element == e2) for e1, e2 in HIJ_DATA.keys()):
                raise ValueError(f"元素 '{element}' 在混合焓数据库中不存在")
        
        # 计算平均混合焓 ΔH_mix
        delta_h_mix = mixing_enthalpy(formula)
        
        # 计算加权标准差的平方和
        variance_sum = 0.0
        
        # 优化计算：只计算i<j的元素对，然后乘以2（因为H_ij = H_ji）
        # 这样避免了重复计算(a,b)和(b,a)这样的对称元素对
        for i in range(len(elements)):
            for j in range(i + 1, len(elements)):  # 只考虑i<j的情况
                element_i = elements[i]
                element_j = elements[j]
                c_i = molar_fractions[element_i]
                c_j = molar_fractions[element_j]
                
                # 获取H_ij值（由于H_ij = H_ji，只需要获取一次）
                hij = HIJ_DATA.get((element_i, element_j), 0.0)
                
                # 计算项 (c_i*c_j + c_j*c_i) * (H_ij - ΔH_mix)² = 2*c_i*c_j*(H_ij - ΔH_mix)²
                variance_sum += 2 * c_i * c_j * (hij - delta_h_mix) ** 2
        
        # 计算标准差 σΔH
        sigma_delta_h = math.sqrt(variance_sum)
        
        return sigma_delta_h
        
    except Exception as e:
        print(f"[sigma_mixing_enthalpy 出错] {e}")
        return None

# 测试函数
def test_sigma_mixing_enthalpy():
    """
    测试混合焓标准差计算函数
    """
    print("开始测试混合焓标准差计算...")
    
    # 测试用例
    test_cases = [
        'CuZn',    # 二元合金
        'FeNi',    # 二元合金
        'AlCu',    # 二元合金
        'NiFe2',   # 带系数的二元合金
        'AgCdIn',  # 三元合金
        '(Ag0.5Cd0.5)'  # 复杂化学式
    ]
    
    # 执行测试
    for formula in test_cases:
        try:
            # 计算平均混合焓
            delta_h_mix = mixing_enthalpy(formula)
            # 计算混合焓标准差
            sigma_delta_h = sigma_mixing_enthalpy(formula)
            print(f"\n化学式: {formula}")
            print(f"  平均混合焓 ΔH_mix = {delta_h_mix:.4f} kJ/mol")
            print(f"  混合焓标准差 σΔH = {sigma_delta_h:.4f} kJ/mol")
        except ValueError as e:
            print(f"计算 {formula} 时出错: {e}")
    
    print("\n所有测试完成!")

if __name__ == "__main__":
    test_sigma_mixing_enthalpy()