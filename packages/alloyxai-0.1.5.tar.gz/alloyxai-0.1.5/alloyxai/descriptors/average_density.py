﻿# -*- coding: utf-8 -*-
import re
import sys
import os


# 导入化学式解析模块
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions



# STP (kg/m³)
density_stp_kg_dict = {
    "H": 0.0899, "He": 0.1785, "Li": 535, "Be": 1848, "B": 2460, "C": 2260, "N": 1.251, "O": 1.429,
    "F": 1.696, "Ne": 0.9, "Na": 968, "Mg": 1738, "Al": 2700, "Si": 2330, "P": 1823, "S": 1960,
    "Cl": 3.214, "Ar": 1.784, "K": 856, "Ca": 1550, "Sc": 2985, "Ti": 4507, "V": 6110, "Cr": 7190,
    "Mn": 7470, "Fe": 7874, "Co": 8900, "Ni": 8908, "Cu": 8960, "Zn": 7140, "Ga": 5904, "Ge": 5323,
    "As": 5727, "Se": 4819, "Br": 3120, "Kr": 3.75, "Rb": 1532, "Sr": 2630, "Y": 4472, "Zr": 6511,
    "Nb": 8570, "Mo": 10280, "Tc": 11500, "Ru": 12370, "Rh": 12450, "Pd": 12023, "Ag": 10490, "Cd": 8650,
    "In": 7310, "Sn": 7310, "Sb": 6697, "Te": 6240, "I": 4940, "Xe": 5.9, "Cs": 1879, "Ba": 3510,
    "La": 6146, "Ce": 6689, "Pr": 6640, "Nd": 7010, "Pm": 7264, "Sm": 7353, "Eu": 5244, "Gd": 7901,
    "Tb": 8219, "Dy": 8551, "Ho": 8795, "Er": 9066, "Tm": 9320, "Yb": 6570, "Lu": 9841, "Hf": 13310,
    "Ta": 16650, "W": 19250, "Re": 21020, "Os": 22590, "Ir": 22560, "Pt": 21450, "Au": 19300, "Hg": 13534,
    "Tl": 11850, "Pb": 11340, "Bi": 9780, "Po": 9196, "At": None, "Rn": 9.73,
    "Fr": None, "Ra": 5000, "Ac": 10070, "Th": 11724, "Pa": 15370, "U": 19050, "Np": 20450, "Pu": 19816,
    "Am": 13670, "Cm": 13510, "Bk": 14780, "Cf": 15100, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# STP (g/cm³)
density_stp_g_dict = {
    "H": 8.99e-5, "He": 1.785e-4, "Li": 0.535, "Be": 1.848, "B": 2.46, "C": 2.26, "N": 0.001251, "O": 0.001429,
    "F": 0.001696, "Ne": 0.0009, "Na": 0.968, "Mg": 1.738, "Al": 2.70, "Si": 2.33, "P": 1.823, "S": 1.96,
    "Cl": 0.003214, "Ar": 0.001784, "K": 0.856, "Ca": 1.55, "Sc": 2.985, "Ti": 4.507, "V": 6.11, "Cr": 7.19,
    "Mn": 7.47, "Fe": 7.874, "Co": 8.90, "Ni": 8.908, "Cu": 8.96, "Zn": 7.14, "Ga": 5.904, "Ge": 5.323,
    "As": 5.727, "Se": 4.819, "Br": 3.12, "Kr": 0.00375, "Rb": 1.532, "Sr": 2.63, "Y": 4.472, "Zr": 6.511,
    "Nb": 8.57, "Mo": 10.28, "Tc": 11.5, "Ru": 12.37, "Rh": 12.45, "Pd": 12.023, "Ag": 10.49, "Cd": 8.65,
    "In": 7.31, "Sn": 7.31, "Sb": 6.697, "Te": 6.24, "I": 4.94, "Xe": 0.0059, "Cs": 1.879, "Ba": 3.51,
    "La": 6.146, "Ce": 6.689, "Pr": 6.64, "Nd": 7.01, "Pm": 7.264, "Sm": 7.353, "Eu": 5.244, "Gd": 7.901,
    "Tb": 8.219, "Dy": 8.551, "Ho": 8.795, "Er": 9.066, "Tm": 9.32, "Yb": 6.57, "Lu": 9.841, "Hf": 13.31,
    "Ta": 16.65, "W": 19.25, "Re": 21.02, "Os": 22.59, "Ir": 22.56, "Pt": 21.45, "Au": 19.3, "Hg": 13.534,
    "Tl": 11.85, "Pb": 11.34, "Bi": 9.78, "Po": 9.20, "At": None, "Rn": 0.00973,
    "Fr": None, "Ra": 5.0, "Ac": 10.07, "Th": 11.72, "Pa": 15.37, "U": 19.05, "Np": 20.45, "Pu": 19.82,
    "Am": 13.67, "Cm": 13.51, "Bk": 14.78, "Cf": 15.1, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# Liquid (kg/m³)
density_liquid_kg_dict = {
    "H": 70.8, "He": 0.145, "Li": 512, "Be": 1690, "B": 2080, "C": None, "N": None, "O": None,
    "F": None, "Ne": None, "Na": 927, "Mg": 1584, "Al": 2375, "Si": 2570, "P": None, "S": 1819,
    "Cl": None, "Ar": None, "K": 828, "Ca": 1378, "Sc": 2800, "Ti": 4110, "V": 5500, "Cr": 6300,
    "Mn": 5950, "Fe": 6980, "Co": 7750, "Ni": 7810, "Cu": 8020, "Zn": 6570,
    "Ga": 6095, "Ge": 5600, "As": 5220, "Se": 3990, "Br": 3120, "Kr": None,
    "Rb": 1460, "Sr": 2375, "Y": 4240, "Zr": 5800, "Nb": None, "Mo": 9330, "Tc": 11500, "Ru": 10650, "Rh": 10700,
    "Pd": 10380, "Ag": 9320, "Cd": 7996,
    "In": 7020, "Sn": 6990, "Sb": 6530, "Te": 5700, "I": None, "Xe": None,
    "Cs": 1843, "Ba": 3338,
    "La": 5940, "Ce": 6550, "Pr": 6500, "Nd": 6890, "Pm": None, "Sm": 7160, "Eu": 5130, "Gd": 7400, "Tb": 7650,
    "Dy": 8370, "Ho": 8340, "Er": 8860, "Tm": 8560, "Yb": 6210, "Lu": 9300,
    "Hf": 12000, "Ta": 15000, "W": 17600, "Re": 18900, "Os": 20000, "Ir": 19000, "Pt": None, "Au": None, "Hg": 13534,
    "Tl": None, "Pb": None, "Bi": None, "Po": None, "At": None, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": None, "Pa": None, "U": None, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# Liquid (g/cm³)
density_liquid_g_dict = {
    "H": 0.0708, "He": 0.000145, "Li": 0.512, "Be": 1.69, "B": 2.08, "C": None, "N": None, "O": None,
    "F": None, "Ne": None, "Na": 0.927, "Mg": 1.584, "Al": 2.375, "Si": 2.57, "P": None, "S": 1.819,
    "Cl": None, "Ar": None, "K": 0.828, "Ca": 1.378, "Sc": 2.8, "Ti": 4.11, "V": 5.5, "Cr": 6.3,
    "Mn": 5.95, "Fe": 6.98, "Co": 7.75, "Ni": 7.81, "Cu": 8.02, "Zn": 6.57,
    "Ga": 6.095, "Ge": 5.6, "As": 5.22, "Se": 3.99, "Br": 3.12, "Kr": None,
    "Rb": 1.46, "Sr": 2.375, "Y": 4.24, "Zr": 5.8, "Nb": None, "Mo": 9.33, "Tc": 11.5, "Ru": 10.65, "Rh": 10.7,
    "Pd": 10.38, "Ag": 9.32, "Cd": 7.996,
    "In": 7.02, "Sn": 6.99, "Sb": 6.53, "Te": 5.7, "I": None, "Xe": None,
    "Cs": 1.843, "Ba": 3.338,
    "La": 5.94, "Ce": 6.55, "Pr": 6.5, "Nd": 6.89, "Pm": None, "Sm": 7.16, "Eu": 5.13, "Gd": 7.4, "Tb": 7.65,
    "Dy": 8.37, "Ho": 8.34, "Er": 8.86, "Tm": 8.56, "Yb": 6.21, "Lu": 9.3,
    "Hf": 12.0, "Ta": 15.0, "W": 17.6, "Re": 18.9, "Os": 20.0, "Ir": 19.0, "Pt": None, "Au": None, "Hg": 13.534,
    "Tl": None, "Pb": None, "Bi": None, "Po": None, "At": None, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": None, "Pa": None, "U": None, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}


# 根据化学式计算合金在 STP 条件下的平均密度（kg/m³, 原子分数加权）
def average_density_stp_kg(formula):
    try:
        elements, counts = get_elements_and_counts(formula)
        
        # 检查元素是否有密度数据
        for elem in elements:
            if elem not in density_stp_kg_dict:
                raise ValueError(f"元素 {elem} 没有可用的 STP 密度数据 (kg/m³)")
            rho = density_stp_kg_dict.get(elem)
            if rho is None:
                raise ValueError(f"元素 {elem} 的 STP 密度数据 (kg/m³) 为 None，此合金不适合计算平均密度")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        rho_values = [density_stp_kg_dict[elem] for elem in elements]

        return sum(c * rho for c, rho in zip(concentrations, rho_values))

    except Exception as e:
        print(f"[average_density_stp_kg 出错] {e}")
        return None

# 根据化学式计算合金在 STP 条件下的平均密度（g/cm³, 原子分数加权）
def average_density_stp_g(formula):

    try:
        elements, counts = get_elements_and_counts(formula)
        
        # 检查元素是否有密度数据
        for elem in elements:
            if elem not in density_stp_g_dict:
                raise ValueError(f"元素 {elem} 没有可用的 STP 密度数据 (g/cm³)")
            rho = density_stp_g_dict.get(elem)
            if rho is None:
                raise ValueError(f"元素 {elem} 的 STP 密度数据 (g/cm³) 为 None，此合金不适合计算平均密度")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        rho_values = [density_stp_g_dict[elem] for elem in elements]

        return sum(c * rho for c, rho in zip(concentrations, rho_values))

    except Exception as e:
        print(f"[average_density_stp_g 出错] {e}")
        return None

# 根据化学式计算合金在液态下的平均密度（kg/m³, 原子分数加权）
def average_density_liquid_kg(formula):

    try:
        elements, counts = get_elements_and_counts(formula)
        
        # 检查元素是否有密度数据
        for elem in elements:
            if elem not in density_liquid_kg_dict:
                raise ValueError(f"元素 {elem} 没有可用的液态密度数据 (kg/m³)")
            rho = density_liquid_kg_dict.get(elem)
            if rho is None:
                raise ValueError(f"元素 {elem} 的液态密度数据 (kg/m³) 为 None，此合金不适合计算平均密度")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        rho_values = [density_liquid_kg_dict[elem] for elem in elements]

        return sum(c * rho for c, rho in zip(concentrations, rho_values))

    except Exception as e:
        print(f"[average_density_liquid_kg 出错] {e}")
        return None

# 根据化学式计算合金在液态下的平均密度（g/cm³, 原子分数加权）
def average_density_liquid_g(formula):
    try:
        elements, counts = get_elements_and_counts(formula)
        
        # 检查元素是否有密度数据
        for elem in elements:
            if elem not in density_liquid_g_dict:
                raise ValueError(f"元素 {elem} 没有可用的液态密度数据 (g/cm³)")
            rho = density_liquid_g_dict.get(elem)
            if rho is None:
                raise ValueError(f"元素 {elem} 的液态密度数据 (g/cm³) 为 None，此合金不适合计算平均密度")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        rho_values = [density_liquid_g_dict[elem] for elem in elements]

        return sum(c * rho for c, rho in zip(concentrations, rho_values))

    except Exception as e:
        print(f"[average_density_liquid_g 出错] {e}")
        return None


if __name__ == "__main__":
    # 测试不同的化学式
    test_formulas = ["Fe","Fe2Ni", "CuZn", "Al2O3", "Fe3O4", "(Fe0.5Ni0.5)2O3"]
    
    # 密度计算测试
    print("密度计算测试:")
    for formula in test_formulas:
        print(f"\n化学式: {formula}")
        print(f"STP 密度 (g/cm³): {average_density_stp_g(formula)}")
        print(f"STP 密度 (kg/m³): {average_density_stp_kg(formula)}")
        print(f"液态密度 (g/cm³): {average_density_liquid_g(formula)}")
        print(f"液态密度 (kg/m³): {average_density_liquid_kg(formula)}")
    
    # 摩尔浓度测试
    print("\n\n摩尔浓度测试:")
    for formula in test_formulas:
        print(f"\n化学式: {formula}")
        molar_fractions = get_molar_fractions(formula)
        print(f"摩尔分数: {molar_fractions}")
        # 验证摩尔分数总和是否接近1
        total = sum(molar_fractions.values())
        print(f"摩尔分数总和: {total}")
        print(f"验证总和接近1: {abs(total - 1.0) < 1e-10}")


