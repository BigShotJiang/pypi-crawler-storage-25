﻿# -*- coding: utf-8 -*-
import re
import math
import sys
import os


# 延迟导入以避免循环依赖
from .average_modulus import bulk_modulus_dict, shear_modulus_dict, young_modulus_dict
from .average_modulus import average_bulk_modulus, average_shear_modulus, average_young_modulus
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

# 直接调用导入的函数
def get_average_bulk_modulus(formula):
    return average_bulk_modulus(formula)

def get_average_shear_modulus(formula):
    return average_shear_modulus(formula)

def get_average_young_modulus(formula):
    return average_young_modulus(formula)

def bulk_modulus_std(formula):
    """根据化学式计算合金体积模量的加权标准差 σ_K"""
    try:
        # 先算平均体积模量 K
        K_avg = get_average_bulk_modulus(formula)

        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效体积模量数据
        for elem in elements:
            if elem not in bulk_modulus_dict:
                raise ValueError(f"元素 {elem} 没有可用的体积模量数据")
            K = bulk_modulus_dict.get(elem)
            if K is None:
                raise ValueError(f"元素 {elem} 的体积模量数据为 None，此合金不适合计算 σ_K")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        K_values = [bulk_modulus_dict[elem] for elem in elements]

        # 计算加权标准差
        variance = sum(c * (K - K_avg) ** 2 for c, K in zip(concentrations, K_values))
        return math.sqrt(variance)

    except Exception as e:
        print(f"[bulk_modulus_std 出错] {e}")
        return None

def shear_modulus_std(formula):
    """根据化学式计算合金剪切模量的加权标准差 σ_G"""
    try:
        # 先算平均剪切模量 G
        G_avg = get_average_shear_modulus(formula)

        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效剪切模量数据
        for elem in elements:
            if elem not in shear_modulus_dict:
                raise ValueError(f"元素 {elem} 没有可用的剪切模量数据")
            G = shear_modulus_dict.get(elem)
            if G is None:
                raise ValueError(f"元素 {elem} 的剪切模量数据为 None，此合金不适合计算 σ_G")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        G_values = [shear_modulus_dict[elem] for elem in elements]

        # 计算加权标准差
        variance = sum(c * (G - G_avg) ** 2 for c, G in zip(concentrations, G_values))
        return math.sqrt(variance)

    except Exception as e:
        print(f"[shear_modulus_std 出错] {e}")
        return None

def young_modulus_std(formula):
    """根据化学式计算合金杨氏模量的加权标准差 σ_E"""
    try:
        # 先算平均杨氏模量 E
        E_avg = get_average_young_modulus(formula)

        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效杨氏模量数据
        for elem in elements:
            if elem not in young_modulus_dict:
                raise ValueError(f"元素 {elem} 没有可用的杨氏模量数据")
            E = young_modulus_dict.get(elem)
            if E is None:
                raise ValueError(f"元素 {elem} 的杨氏模量数据为 None，此合金不适合计算 σ_E")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        E_values = [young_modulus_dict[elem] for elem in elements]

        # 计算加权标准差
        variance = sum(c * (E - E_avg) ** 2 for c, E in zip(concentrations, E_values))
        return math.sqrt(variance)

    except Exception as e:
        print(f"[young_modulus_std 出错] {e}")
        return None


if __name__ == "__main__":
    # 测试不同类型的化学式
    test_formulas = [
        "Fe2Ni",      # 简单合金
        "CuZn",       # 二元合金
        "FeCoCrNi",   # 四元合金
        "(Fe0.5Ni0.5)2O3",  # 带括号和小数系数的复杂化学式
        "Fe",         # 单一元素
        "Ni"          # 单一元素
    ]
    
    # 平均体积模量和标准差测试
    print("=== 平均体积模量和标准差测试 ===")
    for formula in test_formulas:
        K_avg = get_average_bulk_modulus(formula)
        K_std = bulk_modulus_std(formula)
        print(f"{formula}:")
        print(f"  平均体积模量: {K_avg} GPa")
        print(f"  体积模量标准差: {K_std} GPa")
    
    # 平均剪切模量和标准差测试
    print("\n=== 平均剪切模量和标准差测试 ===")
    for formula in test_formulas:
        G_avg = get_average_shear_modulus(formula)
        G_std = shear_modulus_std(formula)
        print(f"{formula}:")
        print(f"  平均剪切模量: {G_avg} GPa")
        print(f"  剪切模量标准差: {G_std} GPa")
    
    # 平均杨氏模量和标准差测试
    print("\n=== 平均杨氏模量和标准差测试 ===")
    for formula in test_formulas:
        E_avg = get_average_young_modulus(formula)
        E_std = young_modulus_std(formula)
        print(f"{formula}:")
        print(f"  平均杨氏模量: {E_avg} GPa")
        print(f"  杨氏模量标准差: {E_std} GPa")
    
    # 摩尔浓度测试
    print("\n=== 摩尔浓度测试 ===")
    for formula in test_formulas:
        try:
            molar_fractions = get_molar_fractions(formula)
            print(f"{formula} 摩尔分数: {molar_fractions}")
            print(f"摩尔分数总和: {sum(molar_fractions.values()):.10f}")
            # 验证摩尔分数总和是否接近1.0
            assert abs(sum(molar_fractions.values()) - 1.0) < 1e-9, "摩尔分数总和不等于1.0"
            print(f"[OK] {formula} 摩尔分数验证通过")
        except Exception as e:
            print(f"[ERROR] {formula} 摩尔分数测试失败: {e}")
    
    print("\n所有测试完成！")
