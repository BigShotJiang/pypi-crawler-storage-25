﻿# -*- coding: utf-8 -*-

import re
import sys
import os


# 导入化学式解析模块
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

hardness_brinell_dict = {
    "H": None, "He": None,
    "Li": None, "Be": 600, "B": None, "C": None, "N": None, "O": None, "F": None, "Ne": None,
    "Na": 0.69, "Mg": 260, "Al": 245, "Si": None, "P": None, "S": None, "Cl": None, "Ar": None,
    "K": 0.363, "Ca": 167, "Sc": 750, "Ti": 716, "V": 628, "Cr": 1120, "Mn": 196, "Fe": 490, "Co": 700,
    "Ni": 700, "Cu": 874, "Zn": 412,
    "Ga": 60, "Ge": None, "As": 1440, "Se": 736, "Br": None, "Kr": None,
    "Rb": 0.216, "Sr": None, "Y": 589, "Zr": 650, "Nb": 736, "Mo": 1500, "Tc": None, "Ru": 2160, "Rh": 1100,
    "Pd": 37.3, "Ag": 24.5, "Cd": 203,
    "In": 8.83, "Sn": 51, "Sb": 294, "Te": 180, "I": None, "Xe": None,
    "Cs": 0.14, "Ba": None,
    "La": 363, "Ce": 412, "Pr": 481, "Nd": 265, "Pm": None, "Sm": 441, "Eu": None, "Gd": None, "Tb": 677,
    "Dy": 500, "Ho": 746, "Er": 814, "Tm": 471, "Yb": 343, "Lu": 893,
    "Hf": 1700, "Ta": 800, "W": 2570, "Re": 1320, "Os": 3920, "Ir": 1670, "Pt": 392, "Au": 25, "Hg": None,
    "Tl": 26.4, "Pb": 38.3, "Bi": 94.2, "Po": None, "At": None, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": 400, "Pa": None, "U": 2400, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

hardness_mohs_dict = {
    "H": None, "He": None,
    "Li": 0.6, "Be": 5.5, "B": 9.3, "C": 0.5, "N": None, "O": None, "F": None, "Ne": None,
    "Na": 0.5, "Mg": 2.5, "Al": 2.75, "Si": 6.5, "P": None, "S": 2, "Cl": None, "Ar": None,
    "K": 0.4, "Ca": 1.75, "Sc": None, "Ti": 6, "V": 7, "Cr": 8.5, "Mn": 6, "Fe": 4, "Co": 5,
    "Ni": 4, "Cu": 3, "Zn": 2.5,
    "Ga": 1.5, "Ge": 6, "As": 3.5, "Se": 2, "Br": None, "Kr": None,
    "Rb": 0.3, "Sr": 1.5, "Y": None, "Zr": 5, "Nb": 6, "Mo": 5.5, "Tc": None, "Ru": 6.5, "Rh": 6,
    "Pd": 4.75, "Ag": 2.5, "Cd": 2,
    "In": 1.2, "Sn": 1.5, "Sb": 3, "Te": 2.25, "I": None, "Xe": None,
    "Cs": 0.2, "Ba": 1.25,
    "La": 2.5, "Ce": 2.5, "Pr": None, "Nd": None, "Pm": None, "Sm": None, "Eu": None, "Gd": None, "Tb": None,
    "Dy": None, "Ho": None, "Er": None, "Tm": None, "Yb": None, "Lu": None,
    "Hf": 5.5, "Ta": 6.5, "W": 7.5, "Re": 7, "Os": 7, "Ir": 6.5, "Pt": 3.5, "Au": 2.5, "Hg": None,
    "Tl": 1.2, "Pb": 1.5, "Bi": 2.25, "Po": None, "At": None, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": 3, "Pa": None, "U": 6, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

hardness_vickers_dict = {
    "H": None, "He": None,
    "Li": None, "Be": 1670, "B": 4900, "C": None, "N": None, "O": None, "F": None, "Ne": None,
    "Na": None, "Mg": None, "Al": 167, "Si": None, "P": None, "S": None, "Cl": None, "Ar": None,
    "K": None, "Ca": None, "Sc": None, "Ti": 970, "V": 628, "Cr": 1060, "Mn": None, "Fe": 608, "Co": 1043,
    "Ni": 638, "Cu": 369, "Zn": None,
    "Ga": None, "Ge": None, "As": None, "Se": None, "Br": None, "Kr": None,
    "Rb": None, "Sr": None, "Y": None, "Zr": 903, "Nb": 1320, "Mo": 1530, "Tc": None, "Ru": None, "Rh": 1246,
    "Pd": 461, "Ag": 251, "Cd": None,
    "In": None, "Sn": None, "Sb": None, "Te": None, "I": None, "Xe": None,
    "Cs": None, "Ba": None,
    "La": 491, "Ce": 270, "Pr": 400, "Nd": 343, "Pm": None, "Sm": 412, "Eu": 167, "Gd": 570, "Tb": 863,
    "Dy": 540, "Ho": 481, "Er": 589, "Tm": 520, "Yb": 206, "Lu": 1160,
    "Hf": 1760, "Ta": 873, "W": 3430, "Re": 2450, "Os": None, "Ir": 1760, "Pt": 549, "Au": 216, "Hg": None,
    "Tl": None, "Pb": None, "Bi": None, "Po": None, "At": None, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": 350, "Pa": None, "U": 1960, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# 布氏硬度

def average_hardness_brinell(formula):
    """根据化学式计算合金的平均布氏硬度（Brinell Hardness, 原子分数加权）"""
    try:
        # 使用导入的化学式解析模块获取元素列表
        elements, _ = get_elements_and_counts(formula)
        
        # 验证所有元素都有硬度数据
        for elem in elements:
            if hardness_brinell_dict is None or elem not in hardness_brinell_dict:
                raise ValueError(f"元素 {elem} 没有可用的布氏硬度数据")
            H = hardness_brinell_dict.get(elem)
            if H is None:
                raise ValueError(f"元素 {elem} 的布氏硬度数据为 None，此合金不适合计算平均布氏硬度")
        
        # 使用formula_parser模块中的get_molar_fractions函数获取摩尔分数
        molar_fractions = get_molar_fractions(formula)
        
        # 提取对应的 H_i 和摩尔分数
        H_values = [hardness_brinell_dict[elem] for elem in elements]
        concentrations = [molar_fractions[elem] for elem in elements]

        # 加权平均
        return sum(c * H for c, H in zip(concentrations, H_values))

    except Exception as e:
        print(f"[hardness_brinell 出错] {e}")
        return None

# 莫氏硬度
def average_hardness_mohs(formula):
    """根据化学式计算合金的平均莫氏硬度（Mohs Hardness, 原子分数加权）"""
    try:
        # 使用导入的化学式解析模块获取元素列表
        elements, _ = get_elements_and_counts(formula)

        # 验证所有元素都有硬度数据
        for elem in elements:
            if hardness_mohs_dict is None or elem not in hardness_mohs_dict:
                raise ValueError(f"元素 {elem} 没有可用的莫氏硬度数据")
            H = hardness_mohs_dict.get(elem)
            if H is None:
                raise ValueError(f"元素 {elem} 的莫氏硬度数据为 None，此合金不适合计算平均莫氏硬度")

        # 使用formula_parser模块中的get_molar_fractions函数获取摩尔分数
        molar_fractions = get_molar_fractions(formula)
        
        # 提取对应的 H_i 和摩尔分数
        H_values = [hardness_mohs_dict[elem] for elem in elements]
        concentrations = [molar_fractions[elem] for elem in elements]

        # 加权平均
        return sum(c * H for c, H in zip(concentrations, H_values))

    except Exception as e:
        print(f"[hardness_mohs 出错] {e}")
        return None

# 维氏硬度
def average_hardness_vickers(formula):
    """根据化学式计算合金的平均维氏硬度（Vickers Hardness, 原子分数加权）"""
    try:
        # 使用导入的化学式解析模块获取元素列表
        elements, _ = get_elements_and_counts(formula)

        # 验证所有元素都有硬度数据
        for elem in elements:
            if hardness_vickers_dict is None or elem not in hardness_vickers_dict:
                raise ValueError(f"元素 {elem} 没有可用的维氏硬度数据")
            H = hardness_vickers_dict.get(elem)
            if H is None:
                raise ValueError(f"元素 {elem} 的维氏硬度数据为 None，此合金不适合计算平均维氏硬度")

        # 使用formula_parser模块中的get_molar_fractions函数获取摩尔分数
        molar_fractions = get_molar_fractions(formula)
        
        # 提取对应的 H_i 和摩尔分数
        H_values = [hardness_vickers_dict[elem] for elem in elements]
        concentrations = [molar_fractions[elem] for elem in elements]

        # 加权平均
        return sum(c * H for c, H in zip(concentrations, H_values))

    except Exception as e:
        print(f"[hardness_vickers 出错] {e}")
        return None


if __name__ == "__main__":
    # 测试各种化学式格式
    test_formulas = [
        "Fe",             # 单元素
        "Fe2Ni",          # 简单的二元合金
        "Fe0.2Ni0.3",     # 带小数系数的合金
        "(FeNi)3",        # 带括号的合金
        "FeNiCr",         # 三元合金
        "Fe Ni",          # 带空格的合金
        "Fe(NiCr)2",      # 嵌套括号的复杂合金
        "Fe-10Ni",        # 带连字符的合金
        "CuZn5",          # 简单的二元合金
        "(TiAl)3V2",      # 带括号的复杂合金
    ]
    
    print("布氏硬度测试:")
    print("=" * 50)
    for formula in test_formulas:
        result = average_hardness_brinell(formula)
        print(f"{formula}: {result}")
    
    print("\n莫氏硬度测试:")
    print("=" * 50)
    for formula in test_formulas:
        result = average_hardness_mohs(formula)
        print(f"{formula}: {result}")
    
    print("\n维氏硬度测试:")
    print("=" * 50)
    for formula in test_formulas:
        result = average_hardness_vickers(formula)
        print(f"{formula}: {result}")
    
    # 验证带括号的化学式解析是否正确（使用formula_parser模块）
    print("\n化学式解析验证:")
    print("=" * 50)
    from ..utilities.formula_parser import parse_formula
    
    # 摩尔浓度测试
    print("\n摩尔浓度测试:")
    print("=" * 50)
    from ..utilities.formula_parser import get_molar_fractions
    for formula in test_formulas:
        molar_fractions = get_molar_fractions(formula)
        print(f"{formula}: {molar_fractions}")
        # 验证摩尔分数之和是否为1
        total = sum(molar_fractions.values())
        print(f"  总和: {total:.6f}, 是否接近1: {abs(total - 1.0) < 1e-10}")
    test_formula = "(FeNi)3"
    parsed = parse_formula(test_formula)
    print(f"{test_formula} 解析结果: {parsed}")  # 应该是 {'Fe': 3, 'Ni': 3}
    
    test_formula2 = "Fe(NiCr)2"
    parsed2 = parse_formula(test_formula2)
    print(f"{test_formula2} 解析结果: {parsed2}")  # 应该是 {'Fe': 1, 'Ni': 2, 'Cr': 2}



