﻿# -*- coding: utf-8 -*-
import re
import sys
import os

from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

# 已整理好的 bulk_modulus_dict（体积模量，单位 GPa）
bulk_modulus_dict = {
    "H": None, "He": None,
    "Li": 11, "Be": 130, "B": None, "C": 33, "N": None, "O": None, "F": None, "Ne": None,
    "Na": 6.3, "Mg": 45, "Al": 76, "Si": 100, "P": 11, "S": 7.7, "Cl": 1.1, "Ar": None,
    "K": 3.1, "Ca": 17, "Sc": 57, "Ti": 110, "V": 160, "Cr": 160, "Mn": 120, "Fe": 170, "Co": 180,
    "Ni": 180, "Cu": 140, "Zn": 70,
    "Ga": None, "Ge": None, "As": 22, "Se": 8.3, "Br": 1.9, "Kr": None,
    "Rb": 2.5, "Sr": 6.1, "Y": 41, "Zr": 33, "Nb": 170, "Mo": 230, "Tc": None, "Ru": 220, "Rh": 380,
    "Pd": 180, "Ag": 100, "Cd": 42,
    "In": None, "Sn": 58, "Sb": 42, "Te": 65, "I": 7.7, "Xe": None,
    "Cs": 1.6, "Ba": 9.6,
    "La": 28, "Ce": 22, "Pr": 29, "Nd": 32, "Pm": None, "Sm": 38, "Eu": 8.3, "Gd": 38, "Tb": 38.7,
    "Dy": 41, "Ho": 40, "Er": 44, "Tm": 45, "Yb": 31, "Lu": 48,
    "Hf": 33, "Ta": 200, "W": 310, "Re": 370, "Os": 222, "Ir": 320, "Pt": None, "Au": None, "Hg": None,
    "Tl": None, "Pb": None, "Bi": None, "Po": None, "At": None, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": None, "Pa": None, "U": None, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

shear_modulus_dict = {
    "H": None, "He": None,
    "Li": 4.2, "Be": 132, "B": None, "C": None, "N": None, "O": None, "F": None, "Ne": None,
    "Na": 3.3, "Mg": 17, "Al": 26, "Si": None, "P": None, "S": None, "Cl": None, "Ar": None,
    "K": 1.3, "Ca": 7.4, "Sc": 29, "Ti": 44, "V": 47, "Cr": 115, "Mn": None, "Fe": 82, "Co": 75,
    "Ni": 76, "Cu": 48, "Zn": 43,
    "Ga": None, "Ge": None, "As": None, "Se": 3.7, "Br": None, "Kr": None,
    "Rb": None, "Sr": 6.1, "Y": 26, "Zr": 33, "Nb": 38, "Mo": 120, "Tc": None, "Ru": 173, "Rh": 150,
    "Pd": 44, "Ag": 30, "Cd": 19,
    "In": None, "Sn": 18, "Sb": 20, "Te": 16, "I": None, "Xe": None,
    "Cs": None, "Ba": 4.9,
    "La": 14, "Ce": 14, "Pr": 15, "Nd": 16, "Pm": 18, "Sm": 20, "Eu": 7.9, "Gd": 22, "Tb": 22,
    "Dy": 25, "Ho": 26, "Er": 28, "Tm": 31, "Yb": 9.9, "Lu": 27,
    "Hf": 30, "Ta": 69, "W": 161, "Re": 178, "Os": 222, "Ir": 210, "Pt": 61, "Au": 27, "Hg": None,
    "Tl": 2.8, "Pb": 5.6, "Bi": 12, "Po": None, "At": None, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": 31, "Pa": None, "U": 111, "Np": None, "Pu": 43, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

young_modulus_dict = {
    "H": None, "He": None,
    "Li": 4.9, "Be": 287, "B": None, "C": None, "N": None, "O": None, "F": None, "Ne": None,
    "Na": 10, "Mg": 45, "Al": 70, "Si": 47, "P": None, "S": None, "Cl": None, "Ar": None,
    "K": None, "Ca": 20, "Sc": 74, "Ti": 116, "V": 128, "Cr": 279, "Mn": 198, "Fe": 211, "Co": 209,
    "Ni": 200, "Cu": 130, "Zn": 108,
    "Ga": None, "Ge": None, "As": 8, "Se": 10, "Br": None, "Kr": None,
    "Rb": 2.4, "Sr": None, "Y": 64, "Zr": 68, "Nb": 105, "Mo": 329, "Tc": None, "Ru": 447, "Rh": 275,
    "Pd": 121, "Ag": 83, "Cd": 50,
    "In": 11, "Sn": 50, "Sb": 55, "Te": 43, "I": None, "Xe": None,
    "Cs": 1.7, "Ba": 13,
    "La": 37, "Ce": 34, "Pr": 37, "Nd": 41, "Pm": 46, "Sm": 50, "Eu": 18, "Gd": 55, "Tb": 56,
    "Dy": 61, "Ho": 65, "Er": 70, "Tm": 74, "Yb": 24, "Lu": 69,
    "Hf": 78, "Ta": 186, "W": 411, "Re": 463, "Os": None, "Ir": 528, "Pt": 168, "Au": 78, "Hg": None,
    "Tl": 8, "Pb": 16, "Bi": 32, "Po": None, "At": None, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": 79, "Pa": None, "U": 208, "Np": None, "Pu": 96, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}


def average_bulk_modulus(formula):
    """根据化学式计算合金的平均体积模量（Bulk modulus, 原子分数加权）"""
    try:
        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效体积模量数据
        for elem in elements:
            if bulk_modulus_dict is None or elem not in bulk_modulus_dict:
                raise ValueError(f"元素 {elem} 没有可用的体积模量数据")
            K = bulk_modulus_dict.get(elem)
            if K is None:
                raise ValueError(f"元素 {elem} 的体积模量数据为 None，此合金不适合计算体积模量")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        K_values = [bulk_modulus_dict[elem] for elem in elements]
        return sum(c * K for c, K in zip(concentrations, K_values))
    except Exception as e:
        print(f"[bulk_modulus 出错] {e}")
        return None


def average_shear_modulus(formula):
    """根据化学式计算合金的平均剪切模量（Shear modulus, 原子分数加权）"""
    try:
        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效剪切模量数据
        for elem in elements:
            if shear_modulus_dict is None or elem not in shear_modulus_dict:
                raise ValueError(f"元素 {elem} 没有可用的剪切模量数据")
            G = shear_modulus_dict.get(elem)
            if G is None:
                raise ValueError(f"元素 {elem} 的剪切模量数据为 None，此合金不适合计算剪切模量")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        G_values = [shear_modulus_dict[elem] for elem in elements]
        return sum(c * G for c, G in zip(concentrations, G_values))
    except Exception as e:
        print(f"[shear_modulus 出错] {e}")
        return None


def average_young_modulus(formula):
    """根据化学式计算合金的平均杨氏模量（Young's modulus, 原子分数加权）"""
    try:
        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效杨氏模量数据
        for elem in elements:
            if young_modulus_dict is None or elem not in young_modulus_dict:
                raise ValueError(f"元素 {elem} 没有可用的杨氏模量数据")
            E = young_modulus_dict.get(elem)
            if E is None:
                raise ValueError(f"元素 {elem} 的杨氏模量数据为 None，此合金不适合计算杨氏模量")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        E_values = [young_modulus_dict[elem] for elem in elements]
        return sum(c * E for c, E in zip(concentrations, E_values))
    except Exception as e:
        print(f"[young_modulus 出错] {e}")
        return None


if __name__ == "__main__":
    # 测试不同类型的化学式
    test_formulas = [
        "Fe2Ni",      # 简单合金
        "CuZn",       # 二元合金
        "FeCoCrNi",   # 四元合金
        "Fe",         # 单一元素
        "Ni"
    ]
    
    # 平均体积模量测试
    print("=== 平均体积模量测试 ===")
    for formula in test_formulas:
        result = average_bulk_modulus(formula)
        print(f"{formula}: {result} GPa")
    
    # 平均剪切模量测试
    print("\n=== 平均剪切模量测试 ===")
    for formula in test_formulas:
        result = average_shear_modulus(formula)
        print(f"{formula}: {result} GPa")
    
    # 平均杨氏模量测试
    print("\n=== 平均杨氏模量测试 ===")
    for formula in test_formulas:
        result = average_young_modulus(formula)
        print(f"{formula}: {result} GPa")
    
    # 摩尔浓度测试
    print("\n=== 摩尔浓度测试 ===")
    for formula in test_formulas:
        try:
            molar_fractions = get_molar_fractions(formula)
            print(f"{formula} 摩尔分数: {molar_fractions}")
            print(f"摩尔分数总和: {sum(molar_fractions.values()):.10f}")
            # 验证摩尔分数总和是否接近1.0
            assert abs(sum(molar_fractions.values()) - 1.0) < 1e-9, "摩尔分数总和不等于1.0"
            print(f"[OK] {formula} 摩尔分数验证通过")
        except Exception as e:
            print(f"[ERROR] {formula} 摩尔分数测试失败: {e}")
    
    print("\n所有测试完成！")