﻿# -*- coding: utf-8 -*-
import re
import math
import sys
import os


# 导入半径数据模块
from ..config.radius_data import radius_covalent_dict
from ..config.radius_data import radius_calculated_dict
from ..config.radius_data import radius_empirical_dict
from ..config.radius_data import radius_vdw_dict

# 导入平均半径模块
from . import average_radius

# 导入化学式解析模块
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

"""
根据化学式计算合金的原子半径畸变量 δr
参数:
    formula : str
        化学式，例如 "Al2CoCrFeNi"
返回:
    str
        成功时返回格式化后的 δr 字符串；失败时返回错误信息字符串
"""
# 此函数以经验半径为基底来计算
def delta_r_radius_empirical(formula):

    try:
        # 1. 使用formula_parser解析化学式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效经验半径数据
        for elem in elements:
            if elem not in radius_empirical_dict:
                raise ValueError(f"元素 {elem} 不在 radius_data 中")
            if radius_empirical_dict[elem] is None:
                raise ValueError(f"元素 {elem} 的经验半径数据缺失 (None)，无法计算半径畸变量")
        # print('elements, counts', elements, counts)
        # 2. 计算平均原子半径
        r_bar = average_radius.average_atomic_radius_empirical(formula)

        # 3. 计算原子分数
        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]

        # 4. 计算 δr
        delta = math.sqrt(sum(
            ci * (1 - radius_empirical_dict[elem] / r_bar) ** 2
            for elem, ci in zip(elements, concentrations)
        ))
        return delta

    except ValueError as e:
        return f"[错误] {e}"



# 此函数以计算半径为基底来计算
def delta_r_radius_calculated(formula):

    try:
        # 1. 使用formula_parser解析化学式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效计算半径数据
        for elem in elements:
            if elem not in radius_calculated_dict:
                raise ValueError(f"元素 {elem} 不在 radius_data 中")
            if radius_calculated_dict[elem] is None:
                raise ValueError(f"元素 {elem} 的计算半径数据缺失 (None)，无法计算半径畸变量")

        # 2. 计算平均原子半径
        r_bar = average_radius.average_atomic_radius_calculated(formula)

        # 3. 计算原子分数
        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]

        # 4. 计算 δr
        delta = math.sqrt(sum(
            ci * (1 - radius_calculated_dict[elem] / r_bar) ** 2
            for elem, ci in zip(elements, concentrations)
        ))
        return delta

    except ValueError as e:
        return f"[错误] {e}"


# 此函数以共价半径为基底来计算
def delta_r_radius_covalent(formula):

    try:
        # 1. 使用formula_parser解析化学式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效共价半径数据
        for elem in elements:
            if elem not in radius_covalent_dict:
                raise ValueError(f"元素 {elem} 不在 radius_data 中")
            if radius_covalent_dict[elem] is None:
                raise ValueError(f"元素 {elem} 的共价半径数据缺失 (None)，无法计算半径畸变量")

        # 2. 计算平均原子半径
        r_bar = average_radius.average_atomic_radius_covalent(formula)

        # 3. 计算原子分数
        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]

        # 4. 计算 δr
        delta = math.sqrt(sum(
            ci * (1 - radius_covalent_dict[elem] / r_bar) ** 2
            for elem, ci in zip(elements, concentrations)
        ))
        return delta

    except ValueError as e:
        return f"[错误] {e}"

# 此函数以范德华半径为基底来计算
def delta_r_radius_vanderWaals(formula):

    try:
        # 1. 使用formula_parser解析化学式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效范德华半径数据
        for elem in elements:
            if elem not in radius_vdw_dict:
                raise ValueError(f"元素 {elem} 不在 radius_data 中")
            if radius_vdw_dict[elem] is None:
                raise ValueError(f"元素 {elem} 的范德华半径数据缺失 (None)，无法计算半径畸变量")

        # 2. 计算平均原子半径
        r_bar = average_radius.average_atomic_radius_vanderWaals(formula)

        # 3. 计算原子分数
        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]

        # 4. 计算 δr
        delta = math.sqrt(sum(
            ci * (1 - radius_vdw_dict[elem] / r_bar) ** 2
            for elem, ci in zip(elements, concentrations)
        ))
        return delta

    except ValueError as e:
        return f"[错误] {e}"

if __name__ == '__main__':
    # 测试不同类型的化学式
    test_formulas = [
        "Fe2Ni",      # 简单合金
        "CuZn",       # 二元合金
        "FeCoCrNi",   # 四元合金
        "(Fe0.5Ni0.5)2O3",  # 带括号和小数系数的复杂化学式
        "Al2CoCrFeNi", # 原有测试用例
        "AtCoCrFeNi"   # 故意包含错误元素测试
    ]
    
    # 定义所有半径类型的函数和名称
    radius_functions = [
        (delta_r_radius_empirical, "经验半径"),
        (delta_r_radius_calculated, "计算半径"),
        (delta_r_radius_covalent, "共价半径"),
        (delta_r_radius_vanderWaals, "范德华半径")
    ]
    
    # 半径畸变量测试
    print("=== 半径畸变量测试 ===")
    for formula in test_formulas:
        print(f"\n化学式: {formula}")
        for func, name in radius_functions:
            result = func(formula)
            print(f"  使用{name}计算的半径畸变量 δr: {result}")
    
    # 摩尔浓度测试
    print("\n=== 摩尔浓度测试 ===")
    for formula in test_formulas[:-1]:  # 排除错误元素的测试用例
        try:
            molar_fractions = get_molar_fractions(formula)
            print(f"{formula} 摩尔分数: {molar_fractions}")
            print(f"摩尔分数总和: {sum(molar_fractions.values()):.10f}")
            # 验证摩尔分数总和是否接近1.0
            assert abs(sum(molar_fractions.values()) - 1.0) < 1e-9, "摩尔分数总和不等于1.0"
            print(f"[OK] {formula} 摩尔分数验证通过")
        except Exception as e:
            print(f"[ERROR] {formula} 摩尔分数测试失败: {e}")
    
    print("\n所有测试完成！")