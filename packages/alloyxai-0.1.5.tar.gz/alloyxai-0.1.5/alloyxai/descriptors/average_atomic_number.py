﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import os


from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions



atomic_number_dict = {
    "H": 1,  "He": 2,  "Li": 3,  "Be": 4,  "B": 5,   "C": 6,   "N": 7,   "O": 8,
    "F": 9,  "Ne": 10, "Na": 11, "Mg": 12, "Al": 13, "Si": 14, "P": 15,  "S": 16,
    "Cl": 17,"Ar": 18, "K": 19,  "Ca": 20, "Sc": 21, "Ti": 22, "V": 23,  "Cr": 24,
    "Mn": 25,"Fe": 26, "Co": 27, "Ni": 28, "Cu": 29, "Zn": 30, "Ga": 31, "Ge": 32,
    "As": 33,"Se": 34, "Br": 35, "Kr": 36, "Rb": 37, "Sr": 38, "Y": 39,  "Zr": 40,
    "Nb": 41,"Mo": 42, "Tc": 43, "Ru": 44, "Rh": 45, "Pd": 46, "Ag": 47, "Cd": 48,
    "In": 49,"Sn": 50, "Sb": 51, "Te": 52, "I": 53,  "Xe": 54, "Cs": 55, "Ba": 56,
    "La": 57,"Ce": 58, "Pr": 59, "Nd": 60, "Pm": 61, "Sm": 62, "Eu": 63, "Gd": 64,
    "Tb": 65,"Dy": 66, "Ho": 67, "Er": 68, "Tm": 69, "Yb": 70, "Lu": 71, "Hf": 72,
    "Ta": 73,"W": 74,  "Re": 75, "Os": 76, "Ir": 77, "Pt": 78, "Au": 79, "Hg": 80,
    "Tl": 81,"Pb": 82, "Bi": 83, "Po": 84, "At": 85, "Rn": 86, "Fr": 87, "Ra": 88,
    "Ac": 89,"Th": 90, "Pa": 91, "U": 92,  "Np": 93, "Pu": 94, "Am": 95, "Cm": 96,
    "Bk": 97,"Cf": 98, "Es": 99, "Fm": 100,"Md": 101,"No": 102,"Lr": 103,"Rf": 104,
    "Db": 105,"Sg": 106,"Bh": 107,"Hs": 108,"Mt": 109,"Ds": 110,"Rg": 111,"Cn": 112,
    "Nh": 113,"Fl": 114,"Mc": 115,"Lv": 116,"Ts": 117,"Og": 118
}


def average_atomic_number(formula):
    """
    计算平均原子序数
    公式: $\overline{AN} = \sum_{i=1}^{n} c_i \cdot AN_i$
    
    参数:
        formula: 化学式字符串，如 "FeNi", "Al2Cu", "FeNiCoCrMn"
        
    返回:
        float: 平均原子序数
        
    异常:
        ValueError: 当化学式无效或包含未知元素时
    """
    try:
        # 获取元素的摩尔分数
        molar_fractions = get_molar_fractions(formula)
        
        # 验证所有元素都在原子序数字典中
        for element in molar_fractions:
            if element not in atomic_number_dict:
                raise ValueError(f"元素 '{element}' 的原子序数在数据库中不存在")
        
        # 计算平均原子序数
        avg_atomic_number = 0.0
        for element, fraction in molar_fractions.items():
            avg_atomic_number += fraction * atomic_number_dict[element]
        
        return avg_atomic_number
        
    except Exception as e:
        raise ValueError(f"计算平均原子序数时出错: {str(e)}")


# 测试代码
if __name__ == "__main__":
    test_formulas = ["CuZn", "FeNi", "Al2Cu", "FeNiCoCrMn", "Cu"]
    
    print("测试平均原子序数计算:")
    print("=" * 50)
    
    for formula in test_formulas:
        try:
            result = average_atomic_number(formula)
            print(f"化学式: {formula}")
            print(f"平均原子序数 (̅AN): {result:.2f}")
            print()
        except ValueError as e:
            print(f"化学式: {formula}")
            print(f"错误: {e}")
            print()
