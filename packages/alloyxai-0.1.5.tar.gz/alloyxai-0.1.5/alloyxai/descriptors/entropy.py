﻿# -*- coding: utf-8 -*-
import sys
import os
import math


# 导入所需模块
from ..config.radius_data import radius_empirical_dict
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

"""
熵计算模块

功能：
    1. 计算理想混合熵 ΔS_mix
    2. 计算过剩组态熵 S^{xs}
    3. 计算总熵（理想混合熵 + 过剩熵）

应用：
    - 混合熵：基础热力学分析，理想混合过程
    - 过剩熵：精确的相形成分析，考虑实际原子排列和晶体结构
    - 总熵：全面的熵分析，综合考虑理想和实际因素
"""

# 理想气体常数
R = 8.314472  # J/(molK)

# 堆垛因子
XIBCC = 0.68  # BCC结构堆垛因子
XIFCC = 0.74  # FCC结构堆垛因子

def mixing_entropy(formula):
    """
    计算理想混合熵 ΔS_mix
    公式：ΔS_mix = -R Σ (c_i * ln(c_i))
    
    Args:
        formula (str): 化学配方字符串
        
    Returns:
        float or str: 混合熵值或错误信息
    """
    try:
        # 使用formula_parser解析化学式
        result = get_elements_and_counts(formula)
        
        # 检查解析结果
        if isinstance(result, str):  # 如果返回的是错误信息
            return result
        
        elements, counts = result
        
        # 检查是否只有单一元素
        if len(elements) == 1:
            return 0.0  # 单一元素的混合熵为0
        
        # 计算总原子数
        total = sum(counts)
        
        # 过滤掉数量为0的元素
        filtered_counts = [cnt for cnt in counts if cnt > 0]
        
        # 重新计算过滤后的总原子数
        filtered_total = sum(filtered_counts)
        
        # 检查过滤后是否还有元素
        if len(filtered_counts) == 0:
            return "错误: 所有元素的数量都为0"
        elif len(filtered_counts) == 1:
            # 过滤后只有单一元素，混合熵为0
            return 0.0
        
        # 计算混合熵
        entropy = -R * sum((cnt / filtered_total) * math.log(cnt / filtered_total) for cnt in filtered_counts)
        
        # 确保结果合理
        if math.isnan(entropy) or math.isinf(entropy):
            return "错误: 计算得到的混合熵无效（NaN或无穷大）"
        
        return entropy
        
    except ValueError as e:
        return f"错误: 数值计算错误 - {str(e)}"
    except Exception as e:
        return f"错误: 计算过程中发生异常 - {str(e)}"

def validate_formula(formula):
    """
    验证化学式格式是否正确
    
    Args:
        formula (str): 化学配方字符串
        
    Returns:
        tuple: (是否有效, 错误信息或None)
    """
    if not formula or not isinstance(formula, str):
        return False, "错误: 化学式不能为空且必须是字符串类型"
    
    # 使用formula_parser进行验证
    result = get_elements_and_counts(formula)
    if isinstance(result, str):  # 如果返回的是错误信息
        return False, result
    
    return True, None

def get_atomic_diameter(element):
    """
    获取元素的原子直径（基于经验原子半径）
    
    Args:
        element (str): 元素符号
        
    Returns:
        float: 原子直径
    """
    if element not in radius_empirical_dict:
        raise ValueError(f"元素 {element} 不在 radius_data 中")
    if radius_empirical_dict[element] is None:
        raise ValueError(f"元素 {element} 的经验半径数据缺失 (None)，无法计算原子直径")
    
    # 原子直径 = 2 * 原子半径
    return 2 * radius_empirical_dict[element]

def calculate_excess_entropy(formula, structure='bcc'):
    """
    计算过剩组态熵 S^{xs}
    基于HEAPS中的计算方法
    
    Args:
        formula (str): 化学配方字符串
        structure (str): 晶体结构，可选 'bcc' 或 'fcc'
        
    Returns:
        float: 过剩组态熵值 (J/(molK))
        None: 计算失败时返回None
    """
    try:
        # 解析化学式
        elements, counts = get_elements_and_counts(formula)
        molar_fractions = get_molar_fractions(formula)
        
        # 检查是否只有单一元素
        if len(elements) == 1:
            return 0.0  # 单一元素的过剩熵为0
        
        # 计算原子直径
        atomic_diameters = {elem: get_atomic_diameter(elem) for elem in elements}
        
        # 计算xi值和xitotal
        xi = {}
        xit = 0.0
        
        for elem in elements:
            D = atomic_diameters[elem]
            c = molar_fractions[elem]
            xi[elem] = (D ** 3) * c
            xit += xi[elem]
        
        # 计算y1、y2、y3
        y1 = 0.0
        y2 = 0.0
        y3 = 0.0
        
        # 计算y1和y2
        for i in range(len(elements)):
            for j in range(i + 1, len(elements)):
                elem_i = elements[i]
                elem_j = elements[j]
                
                D_i = atomic_diameters[elem_i]
                D_j = atomic_diameters[elem_j]
                c_i = molar_fractions[elem_i]
                c_j = molar_fractions[elem_j]
                xi_i = xi[elem_i]
                xi_j = xi[elem_j]
                
                # 计算deltaij
                deltaij = ((D_i - D_j) ** 2) * ((xi_i * xi_j * c_i * c_j) ** 0.5) / (xit * D_i * D_j)
                
                # 计算y1
                y1 += deltaij * (D_i + D_j) * (D_i * D_j) ** -0.5
                
                # 计算y2
                for k in range(len(elements)):
                    elem_k = elements[k]
                    D_k = atomic_diameters[elem_k]
                    xi_k = xi[elem_k]
                    y2 += deltaij * (xi_k * (D_i * D_j) ** 0.5) / (xit * D_k)
        
        # 计算y3
        for elem in elements:
            xi_elem = xi[elem]
            c_elem = molar_fractions[elem]
            y3 += ((xi_elem / xit) ** (2/3)) * (c_elem ** (1/3))
        y3 = y3 ** 3
        
        # 根据晶体结构选择堆垛因子
        if structure.lower() == 'bcc':
            xi_structure = XIBCC
        elif structure.lower() == 'fcc':
            xi_structure = XIFCC
        else:
            raise ValueError("晶体结构必须是 'bcc' 或 'fcc'")
        
        # 计算Z和t1
        Z = ((1 + xi_structure + xi_structure ** 2) - 3 * xi_structure * (y1 + y2 * xi_structure) - y3 * xi_structure ** 3) * (1 - xi_structure) ** -3
        t1 = -1.5 * (1 - y1 + y2 + y3) + (3 * y2 + 2 * y3) * (1 - xi_structure) ** -1 + 1.5 * (1 - y1 - y2 - y3/3) * (1 - xi_structure) ** -2 + (y3 - 1) * math.log(1 - xi_structure)
        
        # 计算过剩熵
        se = R * (t1 - math.log(Z) - (3 - 2 * xi_structure) * ((1 - xi_structure) ** -2) + 3 + math.log((1 + xi_structure + xi_structure ** 2 - xi_structure ** 3) * (1 - xi_structure) ** -3))
        
        return round(se, 5)
        
    except Exception as e:
        print(f"[过剩组态熵错误] {e}")
        return None

def excess_entropy_bcc(formula):
    """
    计算BCC结构的过剩组态熵
    
    Args:
        formula (str): 化学配方字符串
        
    Returns:
        float: BCC结构的过剩组态熵值
    """
    return calculate_excess_entropy(formula, 'bcc')

def excess_entropy_fcc(formula):
    """
    计算FCC结构的过剩组态熵
    
    Args:
        formula (str): 化学配方字符串
        
    Returns:
        float: FCC结构的过剩组态熵值
    """
    return calculate_excess_entropy(formula, 'fcc')

def total_entropy(formula, structure='bcc'):
    """
    计算总熵（理想混合熵 + 过剩熵）
    
    Args:
        formula (str): 化学配方字符串
        structure (str): 晶体结构，可选 'bcc' 或 'fcc'
        
    Returns:
        float: 总熵值 (J/(molK))
        None: 计算失败时返回None
    """
    try:
        # 计算理想混合熵
        mix_entropy = mixing_entropy(formula)
        if isinstance(mix_entropy, str):
            raise ValueError(f"混合熵计算失败: {mix_entropy}")
        
        # 计算过剩熵
        excess_entropy = calculate_excess_entropy(formula, structure)
        if excess_entropy is None:
            raise ValueError("过剩熵计算失败")
        
        # 计算总熵
        total_entropy_value = mix_entropy + excess_entropy
        return round(total_entropy_value, 5)
        
    except Exception as e:
        print(f"[总熵计算错误] {e}")
        return None

if __name__ == "__main__":
    print("===== 熵计算测试 =====")
    
    # 测试用例
    test_formulas = [
        "FeNiCoCrMn",     # 典型高熵合金
        "AlCuFeMnNi",     # 多元素合金
        "AgCd",           # 二元合金
        "CuZn",           # 二元黄铜
        "Fe",             # 单一元素
    ]
    
    print("\n1. 混合熵测试:")
    print("-" * 80)
    for formula in test_formulas:
        result = mixing_entropy(formula)
        print(f"{formula:<20} 的混合熵 = {result:>20} J/(mol·K)")
    
    print("\n2. 过剩熵测试:")
    print("-" * 80)
    for formula in test_formulas:
        print(f"\n{formula}:")
        se_bcc = excess_entropy_bcc(formula)
        se_fcc = excess_entropy_fcc(formula)
        if se_bcc is not None:
            print(f"  BCC结构 S^{{xs}} = {se_bcc:.5f} J/(molK)")
        else:
            print(f"  BCC结构 S^{{xs}} 计算失败")
        if se_fcc is not None:
            print(f"  FCC结构 S^{{xs}} = {se_fcc:.5f} J/(molK)")
        else:
            print(f"  FCC结构 S^{{xs}} 计算失败")
    
    print("\n3. 总熵测试:")
    print("-" * 80)
    for formula in test_formulas:
        print(f"\n{formula}:")
        total_bcc = total_entropy(formula, 'bcc')
        total_fcc = total_entropy(formula, 'fcc')
        if total_bcc is not None:
            print(f"  BCC结构 总熵 = {total_bcc:.5f} J/(molK)")
        else:
            print(f"  BCC结构 总熵计算失败")
        if total_fcc is not None:
            print(f"  FCC结构 总熵 = {total_fcc:.5f} J/(molK)")
        else:
            print(f"  FCC结构 总熵计算失败")
    
    print("\n===== 测试完成 =====")
