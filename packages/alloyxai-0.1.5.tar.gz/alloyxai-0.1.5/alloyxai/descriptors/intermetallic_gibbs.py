﻿# -*- coding: utf-8 -*-
import sys
import os


# 导入所需模块
from .mixing_enthalpy import mixing_enthalpy
from .entropy import mixing_entropy

# 理想气体常数
R = 8.314472  # J/(molK)

# k2参数
k2 = 0.6

def intermetallic_gibbs(formula, temperature=300):
    """
    计算金属间相形成吉布斯自由能 ΔG^{ic}
    公式：ΔG^{ic} = ΔH^{ic} - TΔS^{ic}
    其中：ΔS^{ic} = k2 * ΔS^m
    
    参数:
        formula (str): 化学配方字符串
        temperature (float): 温度（K），默认为300K
        
    返回:
        float: 金属间相形成吉布斯自由能值 (kJ/mol)
        None: 计算失败时返回None
    """
    try:
        # 计算混合焓（替代金属间相形成焓）
        him = mixing_enthalpy(formula)
        
        # 计算混合熵
        smix = mixing_entropy(formula)
        if isinstance(smix, str):  # 如果返回的是错误信息
            raise ValueError(f"混合熵计算失败: {smix}")
        if smix is None:
            raise ValueError("混合熵计算失败，无法继续计算ΔG^{ic}")
        
        # 计算金属间相形成熵
        sim = k2 * smix  # J/(molK)
        
        # 计算tsim (kJ/mol)
        tsim = temperature * sim / 1000
        
        # 计算ΔG^{ic}
        gim = round(him - tsim, 2)
        return gim
        
    except Exception as e:
        print(f"[金属间相形成吉布斯自由能错误] {e}")
        return None

if __name__ == "__main__":
    print("===== 金属间相形成吉布斯自由能测试 =====")
    print("公式: ΔG^{ic} = ΔH^{ic} - TΔS^{ic}")
    print(f"其中: ΔS^{{ic}} = {k2} * ΔS^m")
    
    # 测试用例
    test_formulas = [
        "FeNiCoCrMn",     # 典型高熵合金
        "AlCuFeMnNi",     # 多元素合金
        "AgCd",           # 二元合金
        "CuZn",           # 二元黄铜
        "Fe",             # 单一元素
    ]
    
    # 测试不同温度
    temperatures = [300, 600, 900, 1200]
    
    for formula in test_formulas:
        print(f"\n{formula}:")
        for temp in temperatures:
            gim = intermetallic_gibbs(formula, temp)
            if gim is not None:
                print(f"  T={temp}K: ΔG^{{ic}} = {gim:.2f} kJ/mol")
            else:
                print(f"  T={temp}K: 计算失败")
    
    print("\n测试完成!")
