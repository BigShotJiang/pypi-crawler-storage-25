﻿# -*- coding: utf-8 -*-
import re
# 导入必要的模块
import sys
import os


from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

# 导入化学式解析模块


# 摄氏度熔点
melting_point_celsius_dict = {
    "H": -259.1, "He": None, "Li": 180.5, "Be": 1287, "B": 2075, "C": 3642, "N": -210.1, "O": -218,
    "F": -220, "Ne": -248.6, "Na": 97.7, "Mg": 650, "Al": 660.3, "Si": 1414, "P": 44.1, "S": 115.2,
    "Cl": -101.5, "Ar": -189, "K": 63.4, "Ca": 842, "Sc": 1541, "Ti": 1668, "V": 1910, "Cr": 1907,
    "Mn": 1246, "Fe": 1538, "Co": 1495, "Ni": 1455, "Cu": 1084.6, "Zn": 419.5, "Ga": 29.8, "Ge": 938.3,
    "As": 816.9, "Se": 221, "Br": -7.3, "Kr": -157.4, "Rb": 39.3, "Sr": 776, "Y": 1526, "Zr": 1855,
    "Nb": 2477, "Mo": 2623, "Tc": 2157, "Ru": 2334, "Rh": 1964, "Pd": 1555, "Ag": 961.8, "Cd": 321.1,
    "In": 156.6, "Sn": 231.9, "Sb": 630.6, "Te": 449.5, "I": 113.7, "Xe": -111.8, "Cs": 28.4, "Ba": 730,
    "La": 919.9, "Ce": 797.9, "Pr": 930.9, "Nd": 1021, "Pm": 1100, "Sm": 1072, "Eu": 821.9, "Gd": 1313,
    "Tb": 1356, "Dy": 1412, "Ho": 1474, "Er": 1497, "Tm": 1545, "Yb": 818.9, "Lu": 1663, "Hf": 2233,
    "Ta": 3017, "W": 3422, "Re": 3186, "Os": 3033, "Ir": 2466, "Pt": 1768, "Au": 1064, "Hg": -38.8,
    "Tl": 303.6, "Pb": 327.5, "Bi": 271.3, "Po": 254, "At": None, "Rn": None,
    "Fr": None, "Ra": 700, "Ac": 1050, "Th": 1750, "Pa": 1572, "U": 1135, "Np": 644, "Pu": 640,
    "Am": 1176, "Cm": 1345, "Bk": 1050, "Cf": 900, "Es": 860, "Fm": 1500, "Md": 830, "No": 830, "Lr": 1600,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# 开氏温度熔点
melting_point_kelvin_dict = {
    "H": 14.01, "He": None, "Li": 454, "Be": 1560, "B": 2348, "C": 3915, "N": 63.05, "O": 54.8,
    "F": 53.5, "Ne": 24.56, "Na": 371, "Mg": 923, "Al": 933, "Si": 1687, "P": 317, "S": 388,
    "Cl": 171.6, "Ar": 83.8, "K": 337, "Ca": 1115, "Sc": 1814, "Ti": 1941, "V": 2183, "Cr": 2180,
    "Mn": 1519, "Fe": 1811, "Co": 1768, "Ni": 1728, "Cu": 1358, "Zn": 693, "Ga": 303, "Ge": 1211,
    "As": 1090, "Se": 494, "Br": 266, "Kr": 116, "Rb": 312, "Sr": 1050, "Y": 1799, "Zr": 2128,
    "Nb": 2750, "Mo": 2896, "Tc": 2430, "Ru": 2607, "Rh": 2237, "Pd": 1828, "Ag": 1235, "Cd": 594,
    "In": 430, "Sn": 505, "Sb": 904, "Te": 723, "I": 387, "Xe": 161, "Cs": 302, "Ba": 1000,
    "La": 1193, "Ce": 1071, "Pr": 1204, "Nd": 1294, "Pm": 1373, "Sm": 1345, "Eu": 1095, "Gd": 1586,
    "Tb": 1629, "Dy": 1685, "Ho": 1747, "Er": 1770, "Tm": 1818, "Yb": 1092, "Lu": 1936, "Hf": 2506,
    "Ta": 3290, "W": 3695, "Re": 3459, "Os": 3306, "Ir": 2739, "Pt": 2041, "Au": 1337, "Hg": 234,
    "Tl": 577, "Pb": 601, "Bi": 544, "Po": 527, "At": None, "Rn": None,
    "Fr": None, "Ra": 973, "Ac": 1323, "Th": 2023, "Pa": 1845, "U": 1408, "Np": 917, "Pu": 913,
    "Am": 1449, "Cm": 1618, "Bk": 1323, "Cf": 1173, "Es": 1133, "Fm": 1800, "Md": 1100, "No": 1100, "Lr": 1900,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# 华氏温度熔点
melting_point_fahrenheit_dict = {
    "H": -434.5, "He": None, "Li": 356.9, "Be": 2348, "B": 3767, "C": 6587, "N": -346.2, "O": -361,
    "F": -363, "Ne": -415.5, "Na": 207.9, "Mg": 1202, "Al": 1220.6, "Si": 2577, "P": 111.5, "S": 239.4,
    "Cl": -150.8, "Ar": -309, "K": 146.1, "Ca": 1547, "Sc": 2806, "Ti": 3034, "V": 3470, "Cr": 3464,
    "Mn": 2275, "Fe": 2800, "Co": 2723, "Ni": 2651, "Cu": 1984, "Zn": 787, "Ga": 85.6, "Ge": 1721,
    "As": 1502, "Se": 430, "Br": 19, "Kr": -251, "Rb": 102.8, "Sr": 1430, "Y": 2779, "Zr": 3371,
    "Nb": 4490, "Mo": 4753, "Tc": 3914, "Ru": 4233, "Rh": 3567, "Pd": 2831, "Ag": 1763, "Cd": 609,
    "In": 313.9, "Sn": 449.5, "Sb": 1167, "Te": 841, "I": 236.7, "Xe": -169, "Cs": 83.2, "Ba": 1340,
    "La": 1688, "Ce": 1468, "Pr": 1709, "Nd": 1870, "Pm": 2012, "Sm": 1961, "Eu": 1511, "Gd": 2395,
    "Tb": 2473, "Dy": 2573, "Ho": 2685, "Er": 2726, "Tm": 2813, "Yb": 1506, "Lu": 3025, "Hf": 4051,
    "Ta": 5462, "W": 6191, "Re": 5767, "Os": 5491, "Ir": 4471, "Pt": 3215, "Au": 1947, "Hg": -38.8,
    "Tl": 579, "Pb": 621, "Bi": 520, "Po": 505, "At": None, "Rn": None,
    "Fr": None, "Ra": 1290, "Ac": 1922, "Th": 3182, "Pa": 2861, "U": 2075, "Np": 1190, "Pu": 1180,
    "Am": 2149, "Cm": 2453, "Bk": 1922, "Cf": 1652, "Es": 1580, "Fm": 2800, "Md": 2012, "No": 2012, "Lr": 3452,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# 平均熔点 (K)

def average_melting_point_kelvin(formula):
    """根据化学式计算合金的平均熔点（K, 原子分数加权）"""
    try:
        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效熔点数据
        for elem in elements:
            if elem not in melting_point_kelvin_dict:
                raise ValueError(f"元素 {elem} 没有可用的熔点数据 (K)")
            Tm = melting_point_kelvin_dict.get(elem)
            if Tm is None:
                raise ValueError(f"元素 {elem} 的熔点数据 (K) 为 None，此合金不适合计算平均熔点")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        Tm_values = [melting_point_kelvin_dict[elem] for elem in elements]

        return sum(c * Tm for c, Tm in zip(concentrations, Tm_values))

    except Exception as e:
        print(f"[average_melting_point_kelvin 出错] {e}")
        return None

# 平均熔点 (°C)
def average_melting_point_celsius(formula):
    """根据化学式计算合金的平均熔点（°C, 原子分数加权）"""
    try:
        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效熔点数据
        for elem in elements:
            if elem not in melting_point_celsius_dict:
                raise ValueError(f"元素 {elem} 没有可用的熔点数据 (°C)")
            Tm = melting_point_celsius_dict.get(elem)
            if Tm is None:
                raise ValueError(f"元素 {elem} 的熔点数据 (°C) 为 None，此合金不适合计算平均熔点")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        Tm_values = [melting_point_celsius_dict[elem] for elem in elements]

        return sum(c * Tm for c, Tm in zip(concentrations, Tm_values))

    except Exception as e:
        print(f"[average_melting_point_celsius 出错] {e}")
        return None

# 平均熔点 (°F)
def average_melting_point_fahrenheit(formula):
    """根据化学式计算合金的平均熔点（°F, 原子分数加权）"""
    try:
        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效熔点数据
        for elem in elements:
            if elem not in melting_point_fahrenheit_dict:
                raise ValueError(f"元素 {elem} 没有可用的熔点数据 (°F)")
            Tm = melting_point_fahrenheit_dict.get(elem)
            if Tm is None:
                raise ValueError(f"元素 {elem} 的熔点数据 (°F) 为 None，此合金不适合计算平均熔点")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        Tm_values = [melting_point_fahrenheit_dict[elem] for elem in elements]

        return sum(c * Tm for c, Tm in zip(concentrations, Tm_values))

    except Exception as e:
        print(f"[average_melting_point_fahrenheit 出错] {e}")
        return None


if __name__ == "__main__":
    # 测试不同类型的化学式
    test_formulas = [
        "Fe2Ni",      # 简单合金
        "CuZn",       # 二元合金
        "FeCoCrNi",   # 四元合金
        "(Fe0.5Ni0.5)2O3"  # 带括号和小数系数的复杂化学式
    ]
    
    print("=== 平均熔点测试（K）===")
    for formula in test_formulas:
        result = average_melting_point_kelvin(formula)
        print(f"{formula}: {result} K")
    
    print("\n=== 平均熔点测试（°C）===")
    for formula in test_formulas:
        result = average_melting_point_celsius(formula)
        print(f"{formula}: {result} °C")
    
    print("\n=== 平均熔点测试（°F）===")
    for formula in test_formulas:
        result = average_melting_point_fahrenheit(formula)
        print(f"{formula}: {result} °F")
    
    # 摩尔浓度测试
    print("\n=== 摩尔浓度测试 ===")
    for formula in test_formulas:
        try:
            molar_fractions = get_molar_fractions(formula)
            print(f"{formula} 摩尔分数: {molar_fractions}")
            print(f"摩尔分数总和: {sum(molar_fractions.values()):.10f}")
            # 验证摩尔分数总和是否接近1.0
            assert abs(sum(molar_fractions.values()) - 1.0) < 1e-9, "摩尔分数总和不等于1.0"
            print(f"[OK] {formula} 摩尔分数验证通过")
        except Exception as e:
            print(f"[ERROR] {formula} 摩尔分数测试失败: {e}")
    
    print("\n所有测试完成！")


