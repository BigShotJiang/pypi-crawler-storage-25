﻿# -*- coding: utf-8 -*-
import sys
import os
import re


from .average_modulus import average_shear_modulus, shear_modulus_dict
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions


def validate_formula(formula):
    """
    验证化学式格式是否正确
    
    参数:
        formula: 字符串，表示化学式
    
    返回:
        布尔值: 如果格式正确返回True，否则返回False
    
    异常:
        ValueError: 如果化学式格式不正确
    """
    if not isinstance(formula, str):
        raise ValueError("错误: 化学式必须是字符串类型")
    
    # 使用formula_parser进行验证
    result = get_elements_and_counts(formula)
    if isinstance(result, str):  # 如果返回的是错误信息
        raise ValueError(result)
    
    return True


def sigma_shear(formula):
    """
    根据化学式计算 σ_G 指标（等效剪切模量偏差）
    
    参数:
        formula: 字符串，表示合金的化学式，如 'FeNi'、'Al2Cu1'
    
    返回:
        float: σ_G 计算结果
        None: 如果计算过程中出错
    
    说明:
        σ_G 是衡量等效剪切模量与各组分剪切模量偏差的指标
        计算公式: σ_G = Σ[2*(G_i - G)/(G_i + G)]，其中 G_i 是各元素的剪切模量，G 是平均剪切模量
    """
    try:
        # 检查化学式是否为字符串类型
        if not isinstance(formula, str):
            raise ValueError("错误: 化学式必须是字符串类型")
        
        # 使用formula_parser解析化学式
        elements_counts = get_elements_and_counts(formula)
        if isinstance(elements_counts, str):  # 如果返回的是错误信息
            raise ValueError(elements_counts)
        
        elements, _ = elements_counts
        
        # 验证所有元素都有剪切模量数据
        for elem in elements:
            if elem not in shear_modulus_dict:
                raise ValueError(f"错误: 元素 {elem} 没有可用的剪切模量数据")
            g = shear_modulus_dict.get(elem)
            if g is None:
                raise ValueError(f"错误: 元素 {elem} 的剪切模量数据为 None，此合金不适合计算 σ_G")
        
        # 先用已有函数计算整体等效剪切模量 G
        G = average_shear_modulus(formula)
        if G is None:
            raise ValueError("错误: 平均剪切模量 G 计算失败，无法继续计算 σ_G")
        
        # 处理单一元素情况
        if len(elements) == 1:
            return 0.0  # 单一元素的σ_G为0

        # 取出各元素的 Gi，按公式计算 σ_G
        shear_values = [shear_modulus_dict[elem] for elem in elements]
        sigma = sum(2 * (g_i - G) / (g_i + G) for g_i in shear_values)
        return sigma

    except ValueError as e:
        print(f"[σ_G 出错] {str(e)}")
        return None
    except Exception as e:
        print(f"[σ_G 出错] 计算过程中发生未知错误: {str(e)}")
        return None


# 测试函数
def run_tests():
    """
    运行sigma_shear函数的测试用例
    """
    print("===== σ_G (等效剪切模量偏差) 测试 =====\n")
    
    # 扩展测试用例
    test_cases = [
        "Fe2Ni",           # 简单合金
        "CuZn",            # 二元等原子比
        "FeCoCrNi",        # 四元等原子比合金
        "(Fe0.5Ni0.5)2O3", # 带括号和小数系数
        "FeNi",            # 二元合金
        "AlCu",            # 二元合金
        "Fe",              # 单一元素
        "FeNiCoCrMn",      # 五元高熵合金
        "Al2Cu1",          # 带系数二元合金
    ]
    
    print("标准测试用例:")
    print("-" * 50)
    for formula in test_cases:
        result = sigma_shear(formula)
        if result is not None:
            print(f"  {formula:<20} σ_G = {result:.6f}")
        else:
            print(f"  {formula:<20} 计算失败")
    
    print("\n错误处理测试:")
    print("-" * 50)
    error_cases = [
        "InvalidFormula123",  # 无效化学式
        "Al-1Cu",             # 负系数
        123,                   # 非字符串类型
        "XYZ123",             # 不存在的元素
    ]
    
    for formula in error_cases:
        result = sigma_shear(formula)
        print(f"  输入: {formula:<15} 返回: {result}")
    
    print("\n摩尔分数测试:")
    print("-" * 50)
    for formula in test_cases:
        # 跳过非字符串类型的测试用例
        if not isinstance(formula, str):
            continue
        
        # 获取摩尔分数
        molar_fractions = get_molar_fractions(formula)
        
        if isinstance(molar_fractions, str):
            print(f"  {formula:<20} -> {molar_fractions}")
            continue
        
        # 计算摩尔分数总和
        total = sum(molar_fractions.values())
        
        # 打印摩尔分数信息
        fractions_info = ", ".join([f"{elem}:{frac:.4f}" for elem, frac in molar_fractions.items()])
        print(f"  {formula:<20} -> 摩尔分数: {fractions_info}, 总和: {total:.6f}")
        
        # 验证总和是否接近1.0
        if abs(total - 1.0) < 1e-6:
            print(f"  {'':<22} [OK] 验证通过: 摩尔分数总和为1.0")
        else:
            print(f"  {'':<22} [ERROR] 验证失败: 摩尔分数总和不为1.0")


# 运行测试
if __name__ == "__main__":
    run_tests()
