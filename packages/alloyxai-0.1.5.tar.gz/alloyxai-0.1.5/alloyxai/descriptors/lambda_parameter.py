﻿# -*- coding: utf-8 -*-
import sys
import os


# 导入所需模块
from .entropy import mixing_entropy
from .delta_r import delta_r_radius_empirical
from .delta_r import delta_r_radius_calculated
from .delta_r import delta_r_radius_covalent
from .delta_r import delta_r_radius_vanderWaals


# 以经验半径来计算
def lambda_parameter_empirical(formula):
    """根据化学式计算 Λ = ΔSmix / δ²，用于固溶体形成判据"""

    try:
        # 计算混合熵 ΔSmix
        Smix = mixing_entropy(formula)
        if Smix is None:
            raise ValueError("混合熵 ΔSmix 计算失败，无法继续计算 Λ")

        # 计算原子尺寸差异 δ
        delta = delta_r_radius_empirical(formula)

        # 检查 delta 是否是字符串（错误信息）
        if isinstance(delta, str):
            raise ValueError(f"原子尺寸差异 δ 计算失败: {delta}")

        if delta is None or delta == 0:
            raise ValueError("原子尺寸差异 δ 计算失败或为 0，无法继续计算 Λ")

        # 计算 Λ
        Lambda = Smix / (delta ** 2)
        return Lambda

    except Exception as e:
        print(f"[Λ 出错] {e}")
        return None


# 以计算半径来计算
def lambda_parameter_calculated(formula):
    """根据化学式计算 Λ = ΔSmix / δ²，用于固溶体形成判据"""
    try:
        # 计算混合熵 ΔSmix
        Smix = mixing_entropy(formula)
        if Smix is None:
            raise ValueError("混合熵 ΔSmix 计算失败，无法继续计算 Λ")

        # 计算原子尺寸差异 δ
        delta = delta_r_radius_calculated(formula)

        # 检查 delta 是否是字符串（错误信息）
        if isinstance(delta, str):
            raise ValueError(f"原子尺寸差异 δ 计算失败: {delta}")

        if delta is None or delta == 0:
            raise ValueError("原子尺寸差异 δ 计算失败或为 0，无法继续计算 Λ")

        # 计算 Λ
        Lambda = Smix / (delta ** 2)
        return Lambda

    except Exception as e:
        print(f"[Λ 出错] {e}")
        return None


# 以共价半径来计算
def lambda_parameter_covalent(formula):
    """根据化学式计算 Λ = ΔSmix / δ²，用于固溶体形成判据"""
    try:
        # 计算混合熵 ΔSmix
        Smix = mixing_entropy(formula)
        if Smix is None:
            raise ValueError("混合熵 ΔSmix 计算失败，无法继续计算 Λ")

        # 计算原子尺寸差异 δ
        delta = delta_r_radius_covalent(formula)

        # 检查 delta 是否是字符串（错误信息）
        if isinstance(delta, str):
            raise ValueError(f"原子尺寸差异 δ 计算失败: {delta}")

        if delta is None or delta == 0:
            raise ValueError("原子尺寸差异 δ 计算失败或为 0，无法继续计算 Λ")

        # 计算 Λ
        Lambda = Smix / (delta ** 2)
        return Lambda

    except Exception as e:
        print(f"[Λ 出错] {e}")
        return None


# 以范德华半径来计算
def lambda_parameter_vanderWaals(formula):
    """根据化学式计算 Λ = ΔSmix / δ²，用于固溶体形成判据"""

    try:
        # 计算混合熵 ΔSmix
        Smix = mixing_entropy(formula)
        if Smix is None:
            raise ValueError("混合熵 ΔSmix 计算失败，无法继续计算 Λ")

        # 计算原子尺寸差异 δ
        delta = delta_r_radius_vanderWaals(formula)

        # 检查 delta 是否是字符串（错误信息）
        if isinstance(delta, str):
            raise ValueError(f"原子尺寸差异 δ 计算失败: {delta}")

        if delta is None or delta == 0:
            raise ValueError("原子尺寸差异 δ 计算失败或为 0，无法继续计算 Λ")

        # 计算 Λ
        Lambda = Smix / (delta ** 2)
        return Lambda

    except Exception as e:
        print(f"[Λ 出错] {e}")
        return None


# 示例 - 使用原始测试用例
if __name__ == "__main__":
    print("Al0.75CoCrCu0.25FeNiTi0.5 Λ:", lambda_parameter_empirical("Al0.75CoCrCu0.25FeNiTi0.5"))  # 恢复为 "FeNa"
    print("AlCrFe2Ni2 Λ:", lambda_parameter_empirical("AlCrFe2Ni2"))

    print("FeNi 合金 Λ:", lambda_parameter_calculated("FeNi"))  # 恢复为 "FeNa"
    print("Al2O3 Λ:", lambda_parameter_calculated("Al2O3"))

    print("FeNi 合金 Λ:", lambda_parameter_covalent("FeNi"))  # 恢复为 "FeNa"
    print("Al2O3 Λ:", lambda_parameter_covalent("Al2O3"))

    print("AgPd 合金 Λ:", lambda_parameter_vanderWaals("AgPd"))
    print("Al2O3 Λ:", lambda_parameter_vanderWaals("Al2O3"))