﻿# -*- coding: utf-8 -*-
import sys
import os
import math


from .average_melting_point import (
    melting_point_kelvin_dict,
    melting_point_celsius_dict,
    melting_point_fahrenheit_dict,
    average_melting_point_kelvin,
    average_melting_point_celsius,
    average_melting_point_fahrenheit
)
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions


def _calculate_sigma_Tm(formula, temp_dict, avg_temp_func, unit="K"):
    """
    计算熔点分散度σ_Tm的内部函数
    
    参数:
        formula: 字符串，表示合金的化学式
        temp_dict: 字典，元素的熔点数据
        avg_temp_func: 函数，计算平均熔点的函数
        unit: 字符串，温度单位
    
    返回:
        float: σ_Tm计算结果
    """
    # 完全依赖utilities中的formula_parser来解析化学式，不再进行手动验证
    elements, counts = get_elements_and_counts(formula)
    
    # 处理单一元素情况
    if len(elements) == 1:
        return 0.0  # 单一元素的σ_Tm为0
    
    # 检查每个元素是否有可用的熔点数据
    for elem in elements:
        if elem not in temp_dict:
            raise ValueError(f"错误: 元素 {elem} 没有可用的熔点数据 ({unit})")
        if temp_dict.get(elem) is None:
            raise ValueError(f"错误: 元素 {elem} 的熔点数据 ({unit}) 为 None，此合金不适合计算 σ_Tm")
    
    # 计算原子分数
    concentrations = get_molar_fractions(formula)
    
    # 调用平均熔点函数
    Tm = avg_temp_func(formula)
    if Tm is None:
        raise ValueError(f"错误: 平均熔点计算失败，无法继续计算 σ_Tm ({unit})")

    # 计算 σ_Tm
    sigma = (sum(concentrations[e] * (1 - temp_dict[e] / Tm) ** 2
                 for e in elements)) ** 0.5

    return sigma


def sigma_Tm_kelvin(formula):
    """
    根据化学式计算合金的熔点分散度 σ_Tm (开氏温度)
    
    参数:
        formula: 字符串，表示合金的化学式，如 'FeNi'、'Al2Cu1'
    
    返回:
        float: σ_Tm计算结果 (开氏温度)
        None: 如果计算过程中出错
    
    说明:
        σ_Tm 是衡量合金组分熔点分散程度的指标
        计算公式: σ_Tm = sqrt(Σ c_i (1 - T_i/Tm)^2)
        其中 c_i 是元素i的原子分数，T_i 是元素i的熔点，Tm是合金的平均熔点
    """
    try:
        return _calculate_sigma_Tm(formula, melting_point_kelvin_dict, 
                                  average_melting_point_kelvin, "K")
    except ValueError as e:
        print(f"[σ_Tm (K) 出错] {str(e)}")
        return None
    except Exception as e:
        print(f"[σ_Tm (K) 出错] 计算过程中发生未知错误: {str(e)}")
        return None


def sigma_Tm_celsius(formula):
    """
    根据化学式计算合金的熔点分散度 σ_Tm (摄氏温度)
    
    参数:
        formula: 字符串，表示合金的化学式，如 'FeNi'、'Al2Cu1'
    
    返回:
        float: σ_Tm计算结果 (摄氏温度)
        None: 如果计算过程中出错
    
    说明:
        σ_Tm 是衡量合金组分熔点分散程度的指标
        计算公式: σ_Tm = sqrt(Σ c_i (1 - T_i/Tm)^2)
        其中 c_i 是元素i的原子分数，T_i 是元素i的熔点，Tm是合金的平均熔点
    """
    try:
        return _calculate_sigma_Tm(formula, melting_point_celsius_dict, 
                                  average_melting_point_celsius, "°C")
    except ValueError as e:
        print(f"[σ_Tm (°C) 出错] {str(e)}")
        return None
    except Exception as e:
        print(f"[σ_Tm (°C) 出错] 计算过程中发生未知错误: {str(e)}")
        return None


def sigma_Tm_fahrenheit(formula):
    """
    根据化学式计算合金的熔点分散度 σ_Tm (华氏温度)
    
    参数:
        formula: 字符串，表示合金的化学式，如 'FeNi'、'Al2Cu1'
    
    返回:
        float: σ_Tm计算结果 (华氏温度)
        None: 如果计算过程中出错
    
    说明:
        σ_Tm 是衡量合金组分熔点分散程度的指标
        计算公式: σ_Tm = sqrt(Σ c_i (1 - T_i/Tm)^2)
        其中 c_i 是元素i的原子分数，T_i 是元素i的熔点，Tm是合金的平均熔点
    """
    try:
        return _calculate_sigma_Tm(formula, melting_point_fahrenheit_dict, 
                                  average_melting_point_fahrenheit, "°F")
    except ValueError as e:
        print(f"[σ_Tm (°F) 出错] {str(e)}")
        return None
    except Exception as e:
        print(f"[σ_Tm (°F) 出错] 计算过程中发生未知错误: {str(e)}")
        return None


# 移除默认的sigma_Tm函数，只保留三个具体温度单位的函数


# 测试函数
def run_tests():
    """
    运行sigma_Tm函数的测试用例
    """
    print("===== σ_Tm (熔点分散度) 测试 =====\n")
    
    # 扩展测试用例，包括各种复杂化学式
    test_cases = [
        "(FeCoNi)86-Al7Ti7",
        "(FeCoNi)86-Al8Ti6",
        "Fe2Ni",           # 简单合金
        "CuZn",            # 二元合金
        "FeCoCrNi",        # 四元合金
        "(Fe0.5Ni0.5)2O3", # 带括号和小数系数的复杂化学式
        "FeNiCoCrMn",      # 五元合金
        "Al2Cu",           # 带系数二元合金
        "Al0.2CoCrFeNi",   # 带小数系数的五元合金
        "Fe",              # 单一元素
    ]
    
    print("标准测试用例 (开氏温度):")
    for formula in test_cases:
        result = sigma_Tm_kelvin(formula)
        if result is not None:
            print(f"  {formula:<20} σ_Tm (K) = {result:.6f}")
        else:
            print(f"  {formula:<20} 计算失败")
    
    print("\n不同温度单位测试 (FeNi合金):")
    print(f"  σ_Tm (K)   = {sigma_Tm_kelvin('FeNi'):.6f}")
    print(f"  σ_Tm (°C)  = {sigma_Tm_celsius('FeNi'):.6f}")
    print(f"  σ_Tm (°F)  = {sigma_Tm_fahrenheit('FeNi'):.6f}")
    
    print("\n错误处理测试:")
    error_cases = [
        "InvalidFormula123",  # 无效化学式
        "Al-1Cu",             # 负系数
        123,                   # 非字符串类型
        "XYZ123",             # 不存在的元素
    ]
    
    for formula in error_cases:
        result = sigma_Tm_kelvin(formula)
        print(f"  输入: {formula:<15} 返回: {result}")
    
    print("\n摩尔分数测试:")
    for formula in test_cases:
        try:
            # 只测试能正常解析的化学式
            fractions = get_molar_fractions(formula)
            total = sum(fractions.values())
            print(f"  {formula:<20} 摩尔分数总和 = {total:.10f} {'[OK]' if abs(total - 1.0) < 1e-10 else '[ERROR]'}")
        except Exception as e:
            print(f"  {formula:<20} 解析失败: {str(e)}")


# 运行测试
if __name__ == "__main__":
    run_tests()
