﻿# -*- coding: utf-8 -*-
import math
import sys
import os


# 导入vec模块
from . import vec
from .vec import average_vec, valence_electrons

# 导入化学式解析模块
from ..utilities.formula_parser import get_elements_and_counts

"""
根据化学式计算合金的价电子浓度加权偏差 δ(VEC)
使用公式: δ(VEC) = √{∑_{i=1}^{n}{c_i(VEC_i - VEC̄)^2}}

参数:
    formula : str
        化学式，例如 "FeNi", "Al2CoCrFeNi"
返回:
    float 或 None
        成功时返回δ(VEC)值；失败时返回None
"""

def delta_vec(formula):
    """
    根据化学式计算合金的价电子浓度加权偏差 δ(VEC)
    使用公式: δ(VEC) = √{∑_{i=1}^{n}{c_i(VEC_i - VEC̄)^2}}
    
    Args:
        formula: 化学式字符串
    
    Returns:
        float: 价电子浓度加权偏差δ(VEC)，计算失败返回None
    """
    try:
        # 1. 解析化学式获取元素列表和原子计数
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有价电子数据
        for elem in elements:
            if elem not in valence_electrons:
                raise ValueError(f"元素 {elem} 没有价电子数据")
            if valence_electrons[elem] is None:
                raise ValueError(f"元素 {elem} 的价电子数据为 None，无法计算价电子浓度偏差")
        
        # 2. 计算平均价电子浓度
        vec_bar = average_vec(formula)
        if vec_bar is None:
            raise ValueError("无法计算平均价电子浓度")
        
        # 3. 计算原子分数
        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        
        # 4. 计算 δ(VEC)
        delta = math.sqrt(sum(
            ci * (valence_electrons[elem] - vec_bar) ** 2
            for elem, ci in zip(elements, concentrations)
        ))
        return delta
    
    except ValueError as e:
        print(f"[δ(VEC) 出错] {e}")
        return None
    except Exception as e:
        print(f"[δ(VEC) 计算异常] {e}")
        return None


# 如果作为主程序运行，提供一些测试用例
if __name__ == "__main__":
    # 测试不同类型的化学式
    test_formulas = [
        "Fe2Ni",      # 简单合金
        "CuZn",       # 二元合金
        "Al2O3",      # 含氧化合物
        "FeCoCrNi",   # 四元合金
        "(Fe0.5Ni0.5)2O3"  # 带括号和小数系数的复杂化学式
    ]
    
    print("=== 价电子浓度加权偏差(δ(VEC))测试 ===")
    for formula in test_formulas:
        try:
            vec_value = average_vec(formula)
            delta_value = delta_vec(formula)
            print(f"{formula}:")
            print(f"  平均VEC: {vec_value}")
            print(f"  δ(VEC): {delta_value}")
        except Exception as e:
            print(f"{formula}: 计算失败 - {e}")
    
    # 测试错误情况
    print("\n=== 错误情况测试 ===")
    error_formulas = [
        "XYZ",  # 不存在的元素
        "FeCuX"  # 包含不存在的元素
    ]
    
    for formula in error_formulas:
        print(f"{formula}: δ(VEC) = {delta_vec(formula)}")
    
    print("\n所有测试完成！")