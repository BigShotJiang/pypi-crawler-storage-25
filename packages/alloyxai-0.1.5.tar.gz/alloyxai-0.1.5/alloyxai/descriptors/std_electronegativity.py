﻿# -*- coding: utf-8 -*-
import sys
import os
import math
import re


from .average_electronegativity import average_electronegativity, electronegativity_dict
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

def validate_formula(formula):
    """
    验证化学式格式是否正确
    
    Args:
        formula: 待验证的化学式字符串
    
    Returns:
        tuple: (是否有效, 错误信息或None)
    """
    if not formula or not isinstance(formula, str):
        return False, "化学式必须是非空字符串"
    
    # 使用formula_parser验证化学式
    try:
        elements, counts = get_elements_and_counts(formula)
        if not elements:
            return False, "无法从化学式中提取元素"
        return True, None
    except Exception as e:
        return False, f"化学式解析错误: {str(e)}"

def _calculate_std_electronegativity(formula):
    """
    内部函数：根据化学式计算电负性标准偏差 Δχ
    
    Args:
        formula: 化学式字符串
    
    Returns:
        float: 电负性标准偏差 Δχ
    """
    # 先计算平均电负性 χ̄
    chi_bar = average_electronegativity(formula)
    if chi_bar is None:
        raise ValueError("平均电负性 χ̄ 计算失败，无法继续计算 Δχ")

    # 使用formula_parser解析化学式
    elements, counts = get_elements_and_counts(formula)

    # 检查每个元素是否有可用的电负性数据
    for elem in elements:
        if elem not in electronegativity_dict:
            raise ValueError(f"元素 {elem} 没有可用的电负性数据")
        if electronegativity_dict.get(elem) is None:
            raise ValueError(f"元素 {elem} 的电负性数据为 None，此合金不适合计算 Δχ")

    # 计算原子分数
    concentrations = get_molar_fractions(formula)

    # 计算 Δχ
    delta_chi = (sum(concentrations[elem] * (electronegativity_dict[elem] - chi_bar) ** 2 
                    for elem in elements)) ** 0.5
    return delta_chi

def std_electronegativity(formula):
    """
    根据化学式计算电负性标准偏差 Δχ
    
    Args:
        formula: 化学式字符串
    
    Returns:
        float: 电负性标准偏差 Δχ，如果计算失败返回 None
    """
    try:
        # 验证化学式
        is_valid, error_msg = validate_formula(formula)
        if not is_valid:
            raise ValueError(error_msg)
        
        # 调用内部计算函数
        return _calculate_std_electronegativity(formula)

    except Exception as e:
        print(f"错误: {e}")
        return None

def run_tests():
    """
    运行测试用例验证函数正确性
    """
    # 扩展测试用例，包括各种复杂化学式
    test_cases = [
        ("Fe2Ni", True),          # 简单合金
        ("CuZn", True),           # 二元合金
        ("FeCoCrNi", True),       # 四元合金
        ("(Fe0.5Ni0.5)2O3", True),# 带括号和小数系数的复杂化学式
        ("FeNiCoCrMn", True),     # 五元合金
        ("Al2Cu", True),          # 带系数二元合金
        ("Al0.2CoCrFeNi", True),  # 带小数系数的五元合金
        ("Fe", True),             # 单一元素（Δχ 应为 0）
        ("InvalidFormula123", False),  # 无效化学式
        ("123Invalid", False),  # 无效化学式（数字开头）
        ("", False),            # 空字符串
        (None, False)            # None值
    ]
    
    print("开始测试 std_electronegativity 函数...")
    print("\n1. 功能测试:")
    
    for formula, should_succeed in test_cases:
        result = std_electronegativity(formula)
        
        if should_succeed:
            if result is not None:
                formula_str = str(formula) if formula is not None else 'None'
                print(f"[OK] {formula_str:<20} Δχ: {result:.6f}")
                # 对于单一元素，Δχ 应该为 0
                try:
                    elements, _ = get_elements_and_counts(formula)
                    if len(elements) == 1:
                        assert abs(result) < 1e-10, f"单一元素 {formula} 的 Δχ 应为 0，实际为 {result}"
                except:
                    pass
            else:
                formula_str = str(formula) if formula is not None else 'None'
                print(f"[ERROR] {formula_str:<20} 计算失败，但应该成功")
        else:
            if result is None:
                formula_str = str(formula) if formula is not None else 'None'
                print(f"[OK] {formula_str:<20} 正确返回错误")
            else:
                formula_str = str(formula) if formula is not None else 'None'
                print(f"[ERROR] {formula_str:<20} 应该返回错误，但得到了 {result}")
    
    print("\n2. 摩尔分数测试:")
    # 只测试有效的化学式
    valid_formulas = [formula for formula, should_succeed in test_cases if should_succeed]
    for formula in valid_formulas:
        try:
            fractions = get_molar_fractions(formula)
            total = sum(fractions.values())
            print(f"  {formula:<20} 摩尔分数总和 = {total:.10f} {'[OK]' if abs(total - 1.0) < 1e-10 else '[ERROR]'}")
        except Exception as e:
            print(f"  {formula:<20} 解析失败: {str(e)}")
    
    print("\n测试完成！")

# 示例和测试
if __name__ == "__main__":
    print("示例计算：")
    print(f"FeNi 合金 Δχ: {std_electronegativity('FeNi')}")
    print(f"FeCoCrNi 高熵合金 Δχ: {std_electronegativity('FeCoCrNi')}")
    print(f"(Fe0.5Ni0.5)2O3 复杂化学式 Δχ: {std_electronegativity('(Fe0.5Ni0.5)2O3')}")
    print()
    run_tests()
