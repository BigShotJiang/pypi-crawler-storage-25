﻿# -*- coding: utf-8 -*-
import re
import sys
import os

from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions
from ..utilities.formula_parser import parse_formula
from ..utilities.formula_parser import get_molar_fractions

# 导入化学式解析模块

# 摄氏度
boiling_point_celsius_dict = {
    "H": -252.87, "He": -268.93,
    "Li": 1342, "Be": 2471, "B": 4000, "C": 3642, "N": -195.79, "O": -182.95, "F": -188.12, "Ne": -246.08,
    "Na": 883, "Mg": 1091, "Al": 2519, "Si": 2900, "P": 280.5, "S": 444.7, "Cl": -34.04, "Ar": -185.8,
    "K": 759, "Ca": 1484, "Sc": 2836, "Ti": 3287, "V": 3407, "Cr": 2671, "Mn": 2061, "Fe": 2862, "Co": 2927,
    "Ni": 2913, "Cu": 2562, "Zn": 907,
    "Ga": 2204, "Ge": 2820, "As": 614, "Se": 685, "Br": 59, "Kr": -153.22,
    "Rb": 688, "Sr": 1382, "Y": 3345, "Zr": 4409, "Nb": 4744, "Mo": 4639, "Tc": 4265, "Ru": 4090, "Rh": 3413,
    "Pd": 2963, "Ag": 2162, "Cd": 767,
    "In": 2072, "Sn": 2602, "Sb": 1587, "Te": 988, "I": 184.3, "Xe": -108.1,
    "Cs": 671, "Ba": 1870,
    "La": 3464, "Ce": 3400, "Pr": 3290, "Nd": 3100, "Pm": 3000, "Sm": 1803, "Eu": 1527, "Gd": 3243, "Tb": 3229,
    "Dy": 2567, "Ho": 2700, "Er": 2868, "Tm": 1950, "Yb": 1196, "Lu": 3402,
    "Hf": 4603, "Ta": 5458, "W": 5555, "Re": 5596, "Os": 5012, "Ir": 4150,
    "Pt": None, "Au": None, "Hg": None, "Tl": None, "Pb": None, "Bi": None, "Po": None, "At": None, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": None, "Pa": None, "U": None, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# 华氏温度
boiling_point_fahrenheit_dict = {
    "H": -423.17, "He": -452.07,
    "Li": 2448, "Be": 4460, "B": 7173, "C": 6599, "N": -320.42, "O": -297.31, "F": -306.62, "Ne": -410.94,
    "Na": 1621, "Mg": 1996, "Al": 4566, "Si": 5252, "P": 536.9, "S": 832.5, "Cl": -29.27, "Ar": -302.4,
    "K": 1398, "Ca": 2703, "Sc": 5137, "Ti": 5949, "V": 6165, "Cr": 4840, "Mn": 3742, "Fe": 5182, "Co": 5301,
    "Ni": 5275, "Cu": 4644, "Zn": 1665,
    "Ga": 3999, "Ge": 5108, "As": 1137, "Se": 1265, "Br": 138, "Kr": -243.8,
    "Rb": 1270, "Sr": 2519, "Y": 6053, "Zr": 7968, "Nb": 8571, "Mo": 8382, "Tc": 7710, "Ru": 7403, "Rh": 6175,
    "Pd": 5365, "Ag": 3924, "Cd": 1413,
    "In": 3762, "Sn": 4715, "Sb": 2870, "Te": 1810, "I": 363.7, "Xe": -162.6,
    "Cs": 1240, "Ba": 3398,
    "La": 6267, "Ce": 6172, "Pr": 5954, "Nd": 5627, "Pm": 5432, "Sm": 3277, "Eu": 2781, "Gd": 5869, "Tb": 5845,
    "Dy": 4653, "Ho": 4892, "Er": 5174, "Tm": 3542, "Yb": 2185, "Lu": 6156,
    "Hf": 8317, "Ta": 9856, "W": 10031, "Re": 10105, "Os": 9053, "Ir": 7502,
    "Pt": None, "Au": None, "Hg": None, "Tl": None, "Pb": None, "Bi": None, "Po": None, "At": None, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": None, "Pa": None, "U": None, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# 开式温度
boiling_point_kelvin_dict = {
    "H": 20.28, "He": 4.22,
    "Li": 1615, "Be": 2743, "B": 4273, "C": 3915, "N": 77.36, "O": 90.2, "F": 85.03, "Ne": 27.07,
    "Na": 1156, "Mg": 1363, "Al": 2792, "Si": 3173, "P": 553.6, "S": 717.87, "Cl": 239.11, "Ar": 87.3,
    "K": 1032, "Ca": 1757, "Sc": 3103, "Ti": 3560, "V": 3680, "Cr": 2944, "Mn": 2334, "Fe": 3134, "Co": 3200,
    "Ni": 3186, "Cu": 2835, "Zn": 1180,
    "Ga": 2477, "Ge": 3093, "As": 887, "Se": 958, "Br": 332, "Kr": 119.93,
    "Rb": 961, "Sr": 1655, "Y": 3618, "Zr": 4682, "Nb": 5017, "Mo": 4912, "Tc": 4538, "Ru": 4423, "Rh": 3968,
    "Pd": 3236, "Ag": 2435, "Cd": 1040,
    "In": 2345, "Sn": 2875, "Sb": 1860, "Te": 1261, "I": 457.4, "Xe": 165.1,
    "Cs": 944, "Ba": 2143,
    "La": 3737, "Ce": 3633, "Pr": 3563, "Nd": 3373, "Pm": 3273, "Sm": 2076, "Eu": 1800, "Gd": 3523, "Tb": 3503,
    "Dy": 2840, "Ho": 2973, "Er": 3141, "Tm": 2223, "Yb": 1469, "Lu": 3675,
    "Hf": 4876, "Ta": 5731, "W": 5828, "Re": 5869, "Os": 5285, "Ir": 4423, "Pt": None, "Au": None, "Hg": None,
    "Tl": None, "Pb": None, "Bi": None, "Po": None, "At": None, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": None, "Pa": None, "U": None, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}



# 摄氏度
def average_boiling_point_celsius(formula):
    """根据化学式计算合金的平均沸点（Boiling point, 原子分数加权）"""
    try:
        # 使用导入的化学式解析模块获取元素列表
        elements, _ = get_elements_and_counts(formula)
        # print(get_elements_and_counts(formula))
        # 验证所有元素都有沸点数据
        for elem in elements:
            if boiling_point_celsius_dict is None or elem not in boiling_point_celsius_dict:
                raise ValueError(f"元素 {elem} 没有可用的沸点数据（摄氏度）")
            Tb = boiling_point_celsius_dict.get(elem)
            if Tb is None:
                raise ValueError(f"元素 {elem} 的沸点数据（摄氏度）为 None，此合金不适合计算平均沸点")
        
        # 获取元素和原子数量用于调试（如果需要）
        # elements_list, counts_list = get_elements_and_counts(formula)
        # print("elements, counts:", elements_list, counts_list)
        # 使用formula_parser模块中的get_molar_fractions函数获取摩尔分数
        molar_fractions = get_molar_fractions(formula)
        
        # 提取对应的 Tb_i 和摩尔分数
        Tb_values = [boiling_point_celsius_dict[elem] for elem in elements]
        concentrations = [molar_fractions[elem] for elem in elements]

        # 加权平均
        return sum(c * Tb for c, Tb in zip(concentrations, Tb_values))

    except Exception as e:
        print(f"[boiling_point 出错] {e}")
        return None

# 开尔文
def average_boiling_point_kelvin(formula):
    """根据化学式计算合金的平均沸点（Boiling point, K, 原子分数加权）"""
    try:
        # 使用导入的化学式解析模块获取元素列表
        elements, _ = get_elements_and_counts(formula)

        # 验证所有元素都有沸点数据
        for elem in elements:
            if boiling_point_kelvin_dict is None or elem not in boiling_point_kelvin_dict:
                raise ValueError(f"元素 {elem} 没有可用的沸点数据（K）")
            Tb = boiling_point_kelvin_dict.get(elem)
            if Tb is None:
                raise ValueError(f"元素 {elem} 的沸点数据（K）为 None，此合金不适合计算平均沸点")

        # 使用formula_parser模块中的get_molar_fractions函数获取摩尔分数
        molar_fractions = get_molar_fractions(formula)
        
        # 提取对应的 Tb_i 和摩尔分数
        Tb_values = [boiling_point_kelvin_dict[elem] for elem in elements]
        concentrations = [molar_fractions[elem] for elem in elements]

        # 加权平均
        return sum(c * Tb for c, Tb in zip(concentrations, Tb_values))

    except Exception as e:
        print(f"[boiling_point_kelvin 出错] {e}")
        return None

# 华氏度
def average_boiling_point_fahrenheit(formula):
    """根据化学式计算合金的平均沸点（Boiling point, °F, 原子分数加权）"""
    try:
        # 使用导入的化学式解析模块获取元素列表
        elements, _ = get_elements_and_counts(formula)

        # 验证所有元素都有沸点数据
        for elem in elements:
            if boiling_point_fahrenheit_dict is None or elem not in boiling_point_fahrenheit_dict:
                raise ValueError(f"元素 {elem} 没有可用的沸点数据（°F）")
            Tb = boiling_point_fahrenheit_dict.get(elem)
            if Tb is None:
                raise ValueError(f"元素 {elem} 的沸点数据（°F）为 None，此合金不适合计算平均沸点")

        # 使用formula_parser模块中的get_molar_fractions函数获取摩尔分数
        molar_fractions = get_molar_fractions(formula)
        
        # 提取对应的 Tb_i 和摩尔分数
        Tb_values = [boiling_point_fahrenheit_dict[elem] for elem in elements]
        concentrations = [molar_fractions[elem] for elem in elements]

        # 加权平均
        return sum(c * Tb for c, Tb in zip(concentrations, Tb_values))

    except Exception as e:
        print(f"[boiling_point_fahrenheit 出错] {e}")
        return None


if __name__ == "__main__":
    # 测试各种化学式格式
    test_formulas = [
        "Fe",             # 单元素
        "Fe2Ni",          # 简单的二元合金
        "Fe0.2Ni0.3",     # 带小数系数的合金
        "(FeNi)3",        # 带括号的合金
        "FeNiCr",         # 三元合金
        "Fe Ni",          # 带空格的合金
        "Fe(NiCr)2",      # 嵌套括号的复杂合金
        "Fe-10Ni",        # 带连字符的合金
        "CuZn5",          # 简单的二元合金
        "(TiAl)3V2",      # 带括号的复杂合金
    ]
    
    print("摄氏度测试:")
    print("=" * 50)
    for formula in test_formulas:
        result = average_boiling_point_celsius(formula)
        print(f"{formula}: {result}")
    
    print("\n开尔文测试:")
    print("=" * 50)
    for formula in test_formulas:
        result = average_boiling_point_kelvin(formula)
        print(f"{formula}: {result}")
    
    print("\n华氏度测试:")
    print("=" * 50)
    for formula in test_formulas:
        result = average_boiling_point_fahrenheit(formula)
        print(f"{formula}: {result}")
    
    # 验证带括号的化学式解析是否正确（使用formula_parser模块）
    print("\n化学式解析验证:")
    print("=" * 50)
    
    # 摩尔浓度测试
    print("\n摩尔浓度测试:")
    print("=" * 50)
    for formula in test_formulas:
        molar_fractions = get_molar_fractions(formula)
        print(f"{formula}: {molar_fractions}")
        # 验证摩尔分数之和是否为1
        total = sum(molar_fractions.values())
        print(f"  总和: {total:.6f}, 是否接近1: {abs(total - 1.0) < 1e-10}")
    test_formula = "(FeNi)3"
    parsed = parse_formula(test_formula)
    print(f"{test_formula} 解析结果: {parsed}")  # 应该是 {'Fe': 3, 'Ni': 3}
    
    test_formula2 = "Fe(NiCr)2"
    parsed2 = parse_formula(test_formula2)
    print(f"{test_formula2} 解析结果: {parsed2}")  # 应该是 {'Fe': 1, 'Ni': 2, 'Cr': 2}
