﻿# -*- coding: utf-8 -*-
import re
import math
import sys
import os


# 导入硬度模块
from . import average_hardness
from .average_hardness import hardness_brinell_dict, hardness_mohs_dict, hardness_vickers_dict

# 导入化学式解析模块
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

"""
根据化学式计算合金的硬度标准差 σ(hardness)
使用公式: σ(hardness) = √{∑_{i=1}^{n}{c_i{(hardness_i-hardness̄)}^2}}

参数:
    formula : str
        化学式，例如 "FeNi", "Al2CoCrFeNi"
返回:
    float 或 None
        成功时返回σ(hardness)值；失败时返回None
"""

# 计算布氏硬度标准差
def sigma_hardness_brinell(formula):
    """
    根据化学式计算合金的布氏硬度标准差 σ(HB)
    使用公式: σ(HB) = √{∑_{i=1}^{n}{c_i{(HB_i-HB̄)}^2}}
    
    Args:
        formula: 化学式字符串
    
    Returns:
        float: 布氏硬度标准差σ(HB)，计算失败返回None
    """
    try:
        # 1. 解析化学式获取元素列表和原子计数
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效布氏硬度数据
        for elem in elements:
            if elem not in hardness_brinell_dict:
                raise ValueError(f"元素 {elem} 没有布氏硬度数据")
            if hardness_brinell_dict[elem] is None:
                raise ValueError(f"元素 {elem} 的布氏硬度数据为 None，无法计算硬度标准差")
        
        # 2. 计算平均布氏硬度
        HB_bar = average_hardness.average_hardness_brinell(formula)
        if HB_bar is None:
            raise ValueError("无法计算平均布氏硬度")
        
        # 3. 计算原子分数
        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        
        # 4. 计算 σ(HB)
        sigma = math.sqrt(sum(
            ci * (hardness_brinell_dict[elem] - HB_bar) ** 2
            for elem, ci in zip(elements, concentrations)
        ))
        return sigma
    
    except ValueError as e:
        print(f"[δ(HB) 出错] {e}")
        return None
    except Exception as e:
        print(f"[δ(HB) 计算异常] {e}")
        return None

# 计算莫氏硬度标准差
def sigma_hardness_mohs(formula):
    """
    根据化学式计算合金的莫氏硬度标准差 σ(HM)
    使用公式: σ(HM) = √{∑_{i=1}^{n}{c_i{(HM_i-HM̄)}^2}}
    
    Args:
        formula: 化学式字符串
    
    Returns:
        float: 莫氏硬度标准差σ(HM)，计算失败返回None
    """
    try:
        # 1. 解析化学式获取元素列表和原子计数
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效莫氏硬度数据
        for elem in elements:
            if elem not in hardness_mohs_dict:
                raise ValueError(f"元素 {elem} 没有莫氏硬度数据")
            if hardness_mohs_dict[elem] is None:
                raise ValueError(f"元素 {elem} 的莫氏硬度数据为 None，无法计算硬度标准差")
        
        # 2. 计算平均莫氏硬度
        HM_bar = average_hardness.average_hardness_mohs(formula)
        if HM_bar is None:
            raise ValueError("无法计算平均莫氏硬度")
        
        # 3. 计算原子分数
        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        
        # 4. 计算 σ(HM)
        sigma = math.sqrt(sum(
            ci * (hardness_mohs_dict[elem] - HM_bar) ** 2
            for elem, ci in zip(elements, concentrations)
        ))
        return sigma
    
    except ValueError as e:
        print(f"[δ(HM) 出错] {e}")
        return None
    except Exception as e:
        print(f"[δ(HM) 计算异常] {e}")
        return None

# 计算维氏硬度标准差
def sigma_hardness_vickers(formula):
    """
    根据化学式计算合金的维氏硬度标准差 σ(HV)
    使用公式: σ(HV) = √{∑_{i=1}^{n}{c_i{(HV_i-HV̄)}^2}}
    
    Args:
        formula: 化学式字符串
    
    Returns:
        float: 维氏硬度标准差σ(HV)，计算失败返回None
    """
    try:
        # 1. 解析化学式获取元素列表和原子计数
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效维氏硬度数据
        for elem in elements:
            if elem not in hardness_vickers_dict:
                raise ValueError(f"元素 {elem} 没有维氏硬度数据")
            if hardness_vickers_dict[elem] is None:
                raise ValueError(f"元素 {elem} 的维氏硬度数据为 None，无法计算硬度标准差")
        
        # 2. 计算平均维氏硬度
        HV_bar = average_hardness.average_hardness_vickers(formula)
        if HV_bar is None:
            raise ValueError("无法计算平均维氏硬度")
        
        # 3. 计算原子分数
        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        
        # 4. 计算 σ(HV)
        sigma = math.sqrt(sum(
            ci * (hardness_vickers_dict[elem] - HV_bar) ** 2
            for elem, ci in zip(elements, concentrations)
        ))
        return sigma
    
    except ValueError as e:
        print(f"[δ(HV) 出错] {e}")
        return None
    except Exception as e:
        print(f"[δ(HV) 计算异常] {e}")
        return None

# 内部函数：验证化学式格式
def _validate_formula(formula):
    """
    验证化学式格式是否有效
    
    Args:
        formula: 化学式字符串
    
    Returns:
        tuple: (是否有效, 错误信息)
    """
    if not formula or not isinstance(formula, str):
        return False, "化学式不能为空且必须是字符串类型"
    
    # 检查是否包含有效元素符号的模式（简化检查）
    # 实际的化学式验证应该由formula_parser模块处理
    return True, ""


if __name__ == '__main__':
    # 测试不同类型的化学式
    test_formulas = [
        "Fe",            # 单元素
        "FeNi",          # 二元合金
        "Fe2Ni",         # 简单合金带系数
        "FeCoCrNi",      # 四元合金
        "CuZn5",         # 简单二元合金
        "(Fe0.5Ni0.5)2O3", # 带括号和小数系数的复杂化学式
        "Al2CoCrFeNi",   # 五元高熵合金
        "FeCu"           # 二元合金（铜和铁）
    ]
    
    # 定义所有硬度类型的函数和名称
    hardness_functions = [
        (sigma_hardness_brinell, "布氏硬度标准差 σ(HB)"),
        (sigma_hardness_mohs, "莫氏硬度标准差 σ(HM)"),
        (sigma_hardness_vickers, "维氏硬度标准差 σ(HV)")
    ]
    
    # 硬度标准差测试
    print("=== 硬度标准差测试 ===")
    print("使用公式: σ(hardness) = √{∑c_i(hardness_i-hardness̄)^2}")
    print("=" * 70)
    
    for formula in test_formulas:
        print(f"\n化学式: {formula}")
        for func, name in hardness_functions:
            result = func(formula)
            if result is not None:
                print(f"  {name}: {result:.6f}")
            else:
                print(f"  {name}: 计算失败")
    
    # 验证原子分数计算
    print("\n=== 原子分数验证 ===")
    print("=" * 70)
    for formula in test_formulas:
        try:
            molar_fractions = get_molar_fractions(formula)
            print(f"{formula} 原子分数: {molar_fractions}")
            total = sum(molar_fractions.values())
            print(f"  原子分数总和: {total:.10f} (验证: {abs(total - 1.0) < 1e-10})")
        except Exception as e:
            print(f"{formula} 原子分数计算失败: {e}")
    
    print("\n所有测试完成！")