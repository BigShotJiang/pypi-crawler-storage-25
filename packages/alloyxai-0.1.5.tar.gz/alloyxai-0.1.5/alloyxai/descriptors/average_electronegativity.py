﻿# -*- coding: utf-8 -*-
import re
import sys
import os


# 导入化学式解析模块
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

# electronegativity_dict
electronegativity_dict = {
    "H": 2.20, "He": None,
    "Li": 0.98, "Be": 1.57, "B": 2.04, "C": 2.55, "N": 3.04, "O": 3.44, "F": 3.98, "Ne": None,
    "Na": 0.93, "Mg": 1.31, "Al": 1.61, "Si": 1.90, "P": 2.19, "S": 2.58, "Cl": 3.16, "Ar": None,
    "K": 0.82, "Ca": 1.00, "Sc": 1.36, "Ti": 1.54, "V": 1.63, "Cr": 1.66, "Mn": 1.55, "Fe": 1.83, "Co": 1.88,
    "Ni": 1.91, "Cu": 1.90, "Zn": 1.65,
    "Ga": 1.81, "Ge": 2.01, "As": 2.18, "Se": 2.55, "Br": 2.96, "Kr": 3.00,
    "Rb": 0.82, "Sr": 0.95, "Y": 1.22, "Zr": 1.33, "Nb": 1.60, "Mo": 2.16, "Tc": 1.90, "Ru": 2.20, "Rh": 2.28,
    "Pd": 2.20, "Ag": 1.93, "Cd": 1.69,
    "In": 1.78, "Sn": 1.96, "Sb": 2.05, "Te": 2.10, "I": 2.66, "Xe": 2.60,
    "Cs": 0.79, "Ba": 0.89,
    "La": 1.10, "Ce": 1.12, "Pr": 1.13, "Nd": 1.14, "Pm": None, "Sm": 1.17, "Eu": None, "Gd": 1.20, "Tb": None,
    "Dy": 1.22, "Ho": 1.23, "Er": 1.24, "Tm": 1.25, "Yb": None, "Lu": 1.27,
    "Hf": 1.30, "Ta": 1.50, "W": 2.36, "Re": 1.90, "Os": 2.20, "Ir": 2.28, "Pt": 2.28, "Au": 2.54, "Hg": 2.00,
    "Tl": 1.62, "Pb": 2.33, "Bi": 2.02, "Po": 2.00, "At": 2.20, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": None, "Pa": None, "U": None, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

def average_electronegativity(formula):
    """根据化学式计算合金/化合物的平均电负性"""
    try:
        # 使用formula_parser中的函数替代正则表达式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查所有元素是否有有效电负性数据
        for elem in elements:
            if elem not in electronegativity_dict:
                raise ValueError(f"元素 {elem} 不存在，请检查元素书写是否正确")
            chi = electronegativity_dict.get(elem)
            if chi is None:
                raise ValueError(f"元素 {elem} 的电负性数据为 None，此化合物不适合计算平均电负性")

        total_atoms = sum(counts)
        concentrations = [c / total_atoms for c in counts]
        chis = [electronegativity_dict[elem] for elem in elements]
        return sum(c * chi for c, chi in zip(concentrations, chis))
    except Exception as e:
        print(f"[electronegativity 出错] {e}")
        return None


if __name__ == '__main__':
    # 测试不同类型的化学式
    test_formulas = [
        "Fe2Ni",      # 简单合金
        "CuZn",       # 二元合金
        "Al2O3",      # 含氧化合物
        "FeCoCrNi",   # 四元合金
        "(Fe0.5Ni0.5)2O3"  # 带括号和小数系数的复杂化学式
    ]
    
    print("=== 平均电负性测试 ===")
    for formula in test_formulas:
        result = average_electronegativity(formula)
        print(f"{formula}: {result}")
    
    # 摩尔浓度测试
    print("\n=== 摩尔浓度测试 ===")
    for formula in test_formulas:
        try:
            molar_fractions = get_molar_fractions(formula)
            print(f"{formula} 摩尔分数: {molar_fractions}")
            print(f"摩尔分数总和: {sum(molar_fractions.values()):.10f}")
            # 验证摩尔分数总和是否接近1.0
            assert abs(sum(molar_fractions.values()) - 1.0) < 1e-9, "摩尔分数总和不等于1.0"
            print(f"✓ {formula} 摩尔分数验证通过")
        except Exception as e:
            print(f"✗ {formula} 摩尔分数测试失败: {e}")
    
    print("\n所有测试完成！")
