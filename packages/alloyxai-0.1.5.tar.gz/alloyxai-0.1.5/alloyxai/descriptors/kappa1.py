﻿# -*- coding: utf-8 -*-
import sys
import os


# 导入所需模块
from .mixing_enthalpy import mixing_enthalpy

# k2参数（固定值，来自HEAPS）
k2 = 0.6

def kappa1(formula):
    """
    计算相竞争参数κ1
    公式：κ1 = ΔH^{ic} / ΔH^m
    
    参数:
        formula (str): 化学配方字符串
        
    返回:
        float: κ1参数值
        None: 计算失败时返回None
    """
    try:
        # 计算混合焓
        hmix = mixing_enthalpy(formula)
        
        # 计算混合焓（替代金属间相形成焓）
        him = mixing_enthalpy(formula)
        
        # 计算κ1
        if hmix == 0:
            raise ValueError("混合焓为0，无法计算κ1")
        
        kappa1_value = him / hmix
        return kappa1_value
        
    except Exception as e:
        print(f"[κ1参数错误] {e}")
        return None

def kappa1_critical(formula, temperature=300):
    """
    计算临界相竞争参数κ1^{cr}(T)
    公式：κ1^{cr}(T) = -TΔS^m/(ΔH^m)*(1-k2)+1
    
    参数:
        formula (str): 化学配方字符串
        temperature (float): 温度（K），默认为300K
        
    返回:
        float: κ1^{cr}(T)参数值
        None: 计算失败时返回None
    """
    try:
        from .entropy import mixing_entropy
        
        # 计算混合焓
        hmix = mixing_enthalpy(formula)
        
        # 计算混合熵
        smix = mixing_entropy(formula)
        if isinstance(smix, str):  # 如果返回的是错误信息
            raise ValueError(f"混合熵计算失败: {smix}")
        if smix is None:
            raise ValueError("混合熵计算失败，无法继续计算κ1^{cr}(T)")
        
        # 计算tsmix (kJ/mol)
        tsmix = temperature * smix / 1000
        
        # 计算κ1^{cr}(T)
        if hmix == 0:
            raise ValueError("混合焓为0，无法计算κ1^{cr}(T)")
        
        kappa1_critical_value = -tsmix / hmix * (1 - k2) + 1
        return round(kappa1_critical_value, 2)
        
    except Exception as e:
        print(f"[κ1^{{cr}}(T)参数错误] {e}")
        return None

if __name__ == "__main__":
    print("===== 相竞争参数κ1测试 =====")
    print("公式: κ1 = ΔH^{ic} / ΔH^m")
    print(f"κ1^{{cr}}(T) = -tsmix/(ΔH^m)*(1-{k2})+1")
    
    # 测试用例
    test_formulas = [
        "FeNiCoCrMn",     # 典型高熵合金
        "AlCuFeMnNi",     # 多元素合金
        "AgCd",           # 二元合金
        "CuZn",           # 二元黄铜
        "Fe",             # 单一元素
    ]
    
    # 测试不同温度
    temperatures = [300, 600, 900, 1200]
    
    for formula in test_formulas:
        print(f"\n{formula}:")
        
        # 计算κ1
        k1 = kappa1(formula)
        if k1 is not None:
            print(f"  κ1 = {k1:.4f}")
        else:
            print(f"  κ1 计算失败")
        
        # 计算不同温度下的κ1^{cr}(T)
        print("  κ1^{cr}(T):")
        for temp in temperatures:
            k1_cr = kappa1_critical(formula, temp)
            if k1_cr is not None:
                print(f"    T={temp}K: {k1_cr:.2f}")
            else:
                print(f"    T={temp}K: 计算失败")
    
    print("\n测试完成!")
