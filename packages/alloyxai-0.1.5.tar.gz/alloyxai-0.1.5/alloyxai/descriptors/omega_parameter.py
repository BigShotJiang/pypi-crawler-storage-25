﻿# -*- coding: utf-8 -*-
import sys
import os


# 导入所需模块
from .average_melting_point import average_melting_point_kelvin, average_melting_point_celsius, average_melting_point_fahrenheit
from .entropy import mixing_entropy
from .mixing_enthalpy import mixing_enthalpy

"""
Ω参数计算模块

功能：
    根据化学式计算Ω参数，公式为 Ω = T_mΔS_mix / |ΔH_mix|
    其中：
    - T_m 是合金的平均熔点（K）
    - ΔS_mix 是混合熵（J/(mol·K)）
    - ΔH_mix 是混合焓（J/mol），取绝对值

参数：
    formula (str): 化学配方，支持整数和小数系数，如 "FeNiCoCrMn"、"Al2Cu"、"Al0.2CoCrFeNi"

返回值：
    float: 计算得到的Ω参数值
    None: 当计算失败时返回None

应用：
    Ω参数用于评估高熵合金的形成能力，通常认为Ω > 1.1时倾向于形成单相固溶体
"""

def calculate_omega_kelvin(formula):
    """
    计算Ω参数 = T_mΔS_mix / |ΔH_mix|（使用开尔文温度）
    
    Args:
        formula (str): 化学配方字符串
        
    Returns:
        float or None: 计算得到的Ω参数值，计算失败时返回None
    """
    try:
        # 1. 计算平均熔点 T_m (K)
        Tm = average_melting_point_kelvin(formula)
        if Tm is None:
            print(f"[Ω参数错误-开尔文] 无法计算 '{formula}' 的平均熔点")
            return None
        
        # 2. 计算混合熵 ΔS_mix (J/(mol·K))
        Smix = mixing_entropy(formula)
        # 检查混合熵返回值是否有效
        if isinstance(Smix, str):  # 如果返回的是错误信息字符串
            print(f"[Ω参数错误-开尔文] 混合熵计算失败: {Smix}")
            return None
        if Smix is None:
            print(f"[Ω参数错误-开尔文] 无法计算 '{formula}' 的混合熵")
            return None
        
        # 3. 计算混合焓 ΔH_mix (J/mol)
        try:
            Hmix = mixing_enthalpy(formula)
        except Exception as e:
            print(f"[Ω参数错误-开尔文] 混合焓计算失败: {str(e)}")
            return None
        
        # 检查混合焓是否为零
        if Hmix == 0:
            print(f"[Ω参数提示-开尔文] 混合焓为零，返回Ω值为0")
            return 0
        
        # 4. 计算Ω参数
        omega = (Tm * Smix) / abs(Hmix)
        
        # 确保结果合理
        if not isinstance(omega, (int, float)) or omega < 0:
            print(f"[Ω参数错误-开尔文] 计算得到无效的Ω值: {omega}")
            return None
        
        return omega
        
    except Exception as e:
        print(f"[Ω参数错误-开尔文] 计算过程中发生异常: {str(e)}")
        return None


def calculate_omega_celsius(formula):
    """
    计算Ω参数 = T_mΔS_mix / |ΔH_mix|（使用摄氏温度）
    
    Args:
        formula (str): 化学配方字符串
        
    Returns:
        float or None: 计算得到的Ω参数值，计算失败时返回None
    """
    try:
        # 1. 计算平均熔点 T_m (°C)
        Tm = average_melting_point_celsius(formula)
        if Tm is None:
            print(f"[Ω参数错误-摄氏] 无法计算 '{formula}' 的平均熔点")
            return None
        
        # 2. 计算混合熵 ΔS_mix (J/(mol·K))
        Smix = mixing_entropy(formula)
        # 检查混合熵返回值是否有效
        if isinstance(Smix, str):  # 如果返回的是错误信息字符串
            print(f"[Ω参数错误-摄氏] 混合熵计算失败: {Smix}")
            return None
        if Smix is None:
            print(f"[Ω参数错误-摄氏] 无法计算 '{formula}' 的混合熵")
            return None
        
        # 3. 计算混合焓 ΔH_mix (J/mol)
        try:
            Hmix = mixing_enthalpy(formula)
        except Exception as e:
            print(f"[Ω参数错误-摄氏] 混合焓计算失败: {str(e)}")
            return None
        
        # 检查混合焓是否为零
        if Hmix == 0:
            print(f"[Ω参数提示-摄氏] 混合焓为零，返回Ω值为0")
            return 0
        
        # 4. 计算Ω参数
        omega = (Tm * Smix) / abs(Hmix)
        
        # 确保结果合理
        if not isinstance(omega, (int, float)) or omega < 0:
            print(f"[Ω参数错误-摄氏] 计算得到无效的Ω值: {omega}")
            return None
        
        return omega
        
    except Exception as e:
        print(f"[Ω参数错误-摄氏] 计算过程中发生异常: {str(e)}")
        return None


def calculate_omega_fahrenheit(formula):
    """
    计算Ω参数 = T_mΔS_mix / |ΔH_mix|（使用华氏温度）
    
    Args:
        formula (str): 化学配方字符串
        
    Returns:
        float or None: 计算得到的Ω参数值，计算失败时返回None
    """
    try:
        # 1. 计算平均熔点 T_m (°F)
        Tm = average_melting_point_fahrenheit(formula)
        if Tm is None:
            print(f"[Ω参数错误-华氏] 无法计算 '{formula}' 的平均熔点")
            return None
        
        # 2. 计算混合熵 ΔS_mix (J/(mol·K))
        Smix = mixing_entropy(formula)
        # 检查混合熵返回值是否有效
        if isinstance(Smix, str):  # 如果返回的是错误信息字符串
            print(f"[Ω参数错误-华氏] 混合熵计算失败: {Smix}")
            return None
        if Smix is None:
            print(f"[Ω参数错误-华氏] 无法计算 '{formula}' 的混合熵")
            return None
        
        # 3. 计算混合焓 ΔH_mix (J/mol)
        try:
            Hmix = mixing_enthalpy(formula)
        except Exception as e:
            print(f"[Ω参数错误-华氏] 混合焓计算失败: {str(e)}")
            return None
        
        # 检查混合焓是否为零
        if Hmix == 0:
            print(f"[Ω参数提示-华氏] 混合焓为零，返回Ω值为0")
            return 0
        
        # 4. 计算Ω参数
        omega = (Tm * Smix) / abs(Hmix)
        
        # 确保结果合理
        if not isinstance(omega, (int, float)) or omega < 0:
            print(f"[Ω参数错误-华氏] 计算得到无效的Ω值: {omega}")
            return None
        
        return omega
        
    except Exception as e:
        print(f"[Ω参数错误-华氏] 计算过程中发生异常: {str(e)}")
        return None


# def calculate_omega(formula):
#     """
#     计算Ω参数 = T_mΔS_mix / |ΔH_mix|（默认使用开尔文温度，保持向后兼容）
    
#     Args:
#         formula (str): 化学配方字符串
        
#     Returns:
#         float or None: 计算得到的Ω参数值，计算失败时返回None
#     """
#     # 调用开尔文版本，保持向后兼容性
#     return calculate_omega_kelvin(formula)


def get_omega_interpretation(omega):
    """
    获取Ω参数的解释说明
    
    Args:
        omega (float): Ω参数值
        
    Returns:
        str: 解释说明
    """
    if omega is None:
        return "无法计算Ω参数，无法评估形成能力"
    elif omega > 1.1:
        return f"Ω = {omega:.3f} > 1.1，倾向于形成单相固溶体"
    else:
        return f"Ω = {omega:.3f} ≤ 1.1，倾向于形成金属间化合物或多相结构"


if __name__ == "__main__":
    print("===== Ω参数计算测试 =====")
    print("公式: Ω = T_mΔS_mix / |ΔH_mix|")
    print("其中: T_m=平均熔点, ΔS_mix=混合熵, ΔH_mix=混合焓")
    print("================================\n")
    
    # 测试用例
    test_formulas = [
        "Hf0.5Ti2ZrVNb",
        "Al0.0HfNbZrTaTi",
        "Hf0.5Ti2ZrVNb",
        "FeNiCoCrMn",     # 典型高熵合金
        "AlCuFeMnNi",     # 多元素合金
        "AgCd",           # 二元合金
        "AgIn",           # 二元合金
        "CdIn",           # 二元合金
        "AgCdIn",         # 三元合金
        "Fe2Ni",          # 带系数的二元合金
        "CuZn",           # 二元黄铜
        "Fe",             # 单一元素（应返回None）
    ]
    
    print("标准测试用例 (开尔文温度):")
    print("-" * 80)
    for formula in test_formulas:
        omega = calculate_omega_kelvin(formula)
        interpretation = get_omega_interpretation(omega)
        print(f"{formula:<20} -> Ω(K) = {omega if omega is not None else 'None':<10} | {interpretation}")
    
    print("\n标准测试用例 (摄氏温度):")
    print("-" * 80)
    for formula in test_formulas:
        omega = calculate_omega_celsius(formula)
        interpretation = get_omega_interpretation(omega)
        print(f"{formula:<20} -> Ω(°C) = {omega if omega is not None else 'None':<10} | {interpretation}")
    
    print("\n标准测试用例 (华氏温度):")
    print("-" * 80)
    for formula in test_formulas:
        omega = calculate_omega_fahrenheit(formula)
        interpretation = get_omega_interpretation(omega)
        print(f"{formula:<20} -> Ω(°F) = {omega if omega is not None else 'None':<10} | {interpretation}")
    
    print("\n详细计算示例:")
    print("-" * 80)
    # 详细展示三个温度单位版本的计算过程
    sample_formula = "AgCd"
    print(f"\n计算 '{sample_formula}' 的Ω参数详细过程 (开尔文温度):")
    
    # 获取各组件值 (开尔文)
    Tm_k = average_melting_point_kelvin(sample_formula)
    Smix = mixing_entropy(sample_formula)
    try:
        Hmix = mixing_enthalpy(sample_formula)
    except Exception as e:
        Hmix = f"错误: {str(e)}"
    
    # 打印各组件值 (开尔文)
    print(f"1. 平均熔点 T_m = {Tm_k} K")
    print(f"2. 混合熵 ΔS_mix = {Smix} J/(mol·K)")
    print(f"3. 混合焓 ΔH_mix = {Hmix} J/mol")
    
    # 计算并打印最终结果
    if Tm_k is not None and Smix is not None and isinstance(Hmix, (int, float)) and Hmix != 0:
        omega_k = calculate_omega_kelvin(sample_formula)
        print(f"4. Ω = (Tm * Smix) / |ΔH_mix| = ({Tm_k} * {Smix}) / |{Hmix}| = {omega_k:.3f}")
        print(f"5. 解释: {get_omega_interpretation(omega_k)}")
    else:
        print("计算失败: 无法完成Ω参数的计算")
    
    # 摄氏温度版本
    Tm_c = average_melting_point_celsius(sample_formula)
    if Tm_c is not None and Smix is not None and isinstance(Hmix, (int, float)) and Hmix != 0:
        omega_c = calculate_omega_celsius(sample_formula)
        print(f"\n计算 '{sample_formula}' 的Ω参数详细过程 (摄氏温度):")
        print(f"1. 平均熔点 T_m = {Tm_c} °C")
        print(f"2. 混合熵 ΔS_mix = {Smix} J/(mol·K)")
        print(f"3. 混合焓 ΔH_mix = {Hmix} J/mol")
        print(f"4. Ω = (Tm * Smix) / |ΔH_mix| = ({Tm_c} * {Smix}) / |{Hmix}| = {omega_c:.3f}")
        print(f"5. 解释: {get_omega_interpretation(omega_c)}")
    
    # 华氏温度版本
    Tm_f = average_melting_point_fahrenheit(sample_formula)
    if Tm_f is not None and Smix is not None and isinstance(Hmix, (int, float)) and Hmix != 0:
        omega_f = calculate_omega_fahrenheit(sample_formula)
        print(f"\n计算 '{sample_formula}' 的Ω参数详细过程 (华氏温度):")
        print(f"1. 平均熔点 T_m = {Tm_f} °F")
        print(f"2. 混合熵 ΔS_mix = {Smix} J/(mol·K)")
        print(f"3. 混合焓 ΔH_mix = {Hmix} J/mol")
        print(f"4. Ω = (Tm * Smix) / |ΔH_mix| = ({Tm_f} * {Smix}) / |{Hmix}| = {omega_f:.3f}")
        print(f"5. 解释: {get_omega_interpretation(omega_f)}")
    
    print("\n===== 测试完成 =====")