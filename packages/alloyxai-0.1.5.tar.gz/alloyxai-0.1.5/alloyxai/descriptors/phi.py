﻿# -*- coding: utf-8 -*-
import sys
import os


# 导入所需模块
from .mixing_enthalpy import mixing_enthalpy
from .entropy import mixing_entropy, excess_entropy_bcc, excess_entropy_fcc
from .average_melting_point import average_melting_point_kelvin

# 理想气体常数
R = 8.314472  # J/(molK)

def calculate_phi(formula, structure='bcc'):
    """
    计算相竞争参数φ(ξ)
    公式：φ(ξ) = (ΔS^m - ΔH^m/T_m) / |S^{xs}(ξ)|
    
    参数:
        formula (str): 化学配方字符串
        structure (str): 晶体结构，可选 'bcc' 或 'fcc'
        
    返回:
        float: φ(ξ)参数值
        None: 计算失败时返回None
    """
    try:
        # 计算混合熵
        smix = mixing_entropy(formula)
        if isinstance(smix, str):  # 如果返回的是错误信息
            raise ValueError(f"混合熵计算失败: {smix}")
        if smix is None:
            raise ValueError("混合熵计算失败，无法继续计算φ(ξ)")
        
        # 计算混合焓
        hmix = mixing_enthalpy(formula)
        
        # 计算平均熔点
        tm = average_melting_point_kelvin(formula)
        if tm is None:
            raise ValueError("平均熔点计算失败，无法继续计算φ(ξ)")
        
        # 计算过剩组态熵
        if structure.lower() == 'bcc':
            sxs = excess_entropy_bcc(formula)
        elif structure.lower() == 'fcc':
            sxs = excess_entropy_fcc(formula)
        else:
            raise ValueError("晶体结构必须是 'bcc' 或 'fcc'")
        
        if sxs is None:
            raise ValueError("过剩组态熵计算失败，无法继续计算φ(ξ)")
        
        # 计算分子部分
        numerator = smix - hmix * 1000 / tm  # 注意单位转换，hmix是kJ/mol，smix是J/(molK)
        
        # 计算分母部分（绝对值）
        denominator = abs(sxs)
        
        # 计算φ(ξ)
        if denominator == 0:
            raise ValueError("过剩组态熵为0，无法计算φ(ξ)")
        
        phi = numerator / denominator
        return round(phi, 3)
        
    except Exception as e:
        print(f"[φ(ξ)参数错误] {e}")
        return None

def phi_bcc(formula):
    """
    计算BCC结构的相竞争参数φ(ξ)
    
    参数:
        formula (str): 化学配方字符串
        
    返回:
        float: φ(ξ)参数值
    """
    return calculate_phi(formula, 'bcc')

def phi_fcc(formula):
    """
    计算FCC结构的相竞争参数φ(ξ)
    
    参数:
        formula (str): 化学配方字符串
        
    返回:
        float: φ(ξ)参数值
    """
    return calculate_phi(formula, 'fcc')

if __name__ == "__main__":
    print("===== 相竞争参数φ(ξ)测试 =====")
    print("公式: φ(ξ) = (ΔS^m - ΔH^m/T_m) / |S^{xs}(ξ)|")
    
    # 测试用例
    test_formulas = [
        "FeNiCoCrMn",     # 典型高熵合金
        "AlCuFeMnNi",     # 多元素合金
        "AgCd",           # 二元合金
        "CuZn",           # 二元黄铜
        "Fe",             # 单一元素
    ]
    
    for formula in test_formulas:
        print(f"\n{formula}:")
        phi_bcc_val = phi_bcc(formula)
        phi_fcc_val = phi_fcc(formula)
        if phi_bcc_val is not None:
            print(f"  BCC结构 φ(ξ) = {phi_bcc_val:.3f}")
        else:
            print(f"  BCC结构 φ(ξ) 计算失败")
        if phi_fcc_val is not None:
            print(f"  FCC结构 φ(ξ) = {phi_fcc_val:.3f}")
        else:
            print(f"  FCC结构 φ(ξ) 计算失败")
    
    print("\n测试完成!")
