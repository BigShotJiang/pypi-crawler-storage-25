﻿# -*- coding: utf-8 -*-
import sys
import os


# 导入所需模块
from .entropy import mixing_entropy, excess_entropy_bcc, excess_entropy_fcc
from .mixing_enthalpy import mixing_enthalpy

# 理想气体常数
R = 8.314472  # J/(molK)

def mixing_gibbs_free_energy(formula, T=300):
    """
    计算混合吉布斯自由能 ΔG_mix = ΔH_mix - T * ΔS_mix
    
    Args:
        formula (str): 化学配方字符串
        T (float): 热力学温度（单位：K），默认为300K
        
    Returns:
        float: 混合吉布斯自由能值（单位：kJ/mol）
        str: 当输入无效时返回错误信息字符串
    """
    # 验证温度输入
    try:
        T_value = float(T)
        if T_value <= 0:
            return "错误: 温度必须为正值（单位：K）"
    except (ValueError, TypeError):
        return "错误: 温度必须是有效的数字"
    
    # 计算混合焓（单位：kJ/mol）
    try:
        delta_H_mix = mixing_enthalpy(formula)
        # 确保返回值是数字
        if isinstance(delta_H_mix, (int, float)):
            delta_H_mix = float(delta_H_mix)
        else:
            return f"计算混合焓时出错: {delta_H_mix}"
    except Exception as e:
        return f"计算混合焓时出错: {str(e)}"
    
    # 计算混合熵（单位：J/(mol·K)）
    try:
        delta_S_mix = mixing_entropy(formula)
        # 确保返回值是数字
        if isinstance(delta_S_mix, (int, float)):
            delta_S_mix = float(delta_S_mix)
        else:
            return f"计算混合熵时出错: {delta_S_mix}"
    except Exception as e:
        return f"计算混合熵时出错: {str(e)}"
    
    # 计算混合吉布斯自由能
    # 注意单位转换：混合熵从J/(mol·K)转换为kJ/(mol·K)
    delta_S_mix_kJ = delta_S_mix / 1000.0  # 转换为kJ/(mol·K)
    delta_G_mix = delta_H_mix - (T_value * delta_S_mix_kJ)  # 结果单位: kJ/mol
    
    return delta_G_mix

def gibbs_free_energy_temperature(formula, temperature=300, include_excess_entropy=False, structure='bcc'):
    """
    计算温度依赖的混合吉布斯自由能 ΔG^m(T)
    公式：ΔG^m(T) = ΔH^m - TΔS^m
    如果包含过剩熵：ΔG^m(T) = ΔH^m - T(ΔS^m + S^{xs})
    
    参数:
        formula (str): 化学配方字符串
        temperature (float): 温度（K），默认为300K
        include_excess_entropy (bool): 是否包含过剩组态熵，默认为False
        structure (str): 晶体结构，当include_excess_entropy为True时使用，可选 'bcc' 或 'fcc'
        
    返回:
        float: 混合吉布斯自由能值 (kJ/mol)
        None: 计算失败时返回None
    """
    try:
        # 计算混合焓
        hmix = mixing_enthalpy(formula)
        
        # 计算混合熵
        smix = mixing_entropy(formula)
        if isinstance(smix, str):  # 如果返回的是错误信息
            raise ValueError(f"混合熵计算失败: {smix}")
        if smix is None:
            raise ValueError("混合熵计算失败，无法继续计算ΔG^m(T)")
        
        # 如果包含过剩熵
        if include_excess_entropy:
            if structure.lower() == 'bcc':
                sxs = excess_entropy_bcc(formula)
            elif structure.lower() == 'fcc':
                sxs = excess_entropy_fcc(formula)
            else:
                raise ValueError("晶体结构必须是 'bcc' 或 'fcc'")
            
            if sxs is None:
                raise ValueError("过剩组态熵计算失败，无法继续计算ΔG^m(T)")
            
            # 总熵 = 混合熵 + 过剩熵
            total_entropy = smix + sxs
        else:
            total_entropy = smix
        
        # 计算TΔS (kJ/mol)
        tds = temperature * total_entropy / 1000
        
        # 计算ΔG^m
        gmix = round(hmix - tds, 2)
        return gmix
        
    except Exception as e:
        print(f"[混合吉布斯自由能错误] {e}")
        return None

def test_mixing_gibbs_free_energy():
    """
    测试混合吉布斯自由能计算函数
    """
    print("开始测试混合吉布斯自由能计算...")
    
    # 测试用例
    test_cases = [
        ("CuZn", 1000),    # 铜锌合金，高温
        ("CuZn", 300),     # 铜锌合金，室温
        ("FeNi", 1200),    # 铁镍合金，高温
        ("AlCu", 800),     # 铝铜合金
        ("FeNiCoCrMn", 1500)  # 高熵合金，高温
    ]
    
    for formula, temp in test_cases:
        try:
            # 计算混合焓和混合熵用于显示
            delta_H = mixing_enthalpy(formula)
            delta_S = mixing_entropy(formula)
            
            # 计算混合吉布斯自由能
            delta_G = mixing_gibbs_free_energy(formula, temp)
            
            print(f"\n化学式: {formula}, 温度: {temp} K")
            print(f"混合焓 (ΔH_mix): {delta_H:.4f} kJ/mol")
            print(f"混合熵 (ΔS_mix): {delta_S:.4f} J/(mol·K)")
            print(f"混合吉布斯自由能 (ΔG_mix): {delta_G:.4f} kJ/mol")
            
            # 判断混合过程自发性
            if isinstance(delta_G, (int, float)):
                if delta_G < 0:
                    print("结论: 该条件下混合过程可以自发进行")
                elif delta_G > 0:
                    print("结论: 该条件下混合过程不能自发进行")
                else:
                    print("结论: 该条件下系统处于平衡状态")
                    
        except Exception as e:
            print(f"测试 {formula} 时出错: {str(e)}")
    
    # 测试错误处理
    print("\n测试错误处理:")
    print(mixing_gibbs_free_energy("CuZn", -273))  # 负温度
    print(mixing_gibbs_free_energy("CuZn", "not_a_number"))  # 非数字温度
    print(mixing_gibbs_free_energy("InvalidElement", 300))  # 无效元素
    
    print("\n测试完成！")

if __name__ == "__main__":
    print("===== 温度依赖的混合吉布斯自由能测试 =====")
    print("公式: ΔG^m(T) = ΔH^m - TΔS^m")
    
    # 测试用例
    test_formulas = [
        "FeNiCoCrMn",     # 典型高熵合金
        "AlCuFeMnNi",     # 多元素合金
        "AgCd",           # 二元合金
        "CuZn",           # 二元黄铜
        "Fe",             # 单一元素
    ]
    
    # 测试不同温度
    temperatures = [300, 600, 900, 1200]
    
    for formula in test_formulas:
        print(f"\n{formula}:")
        for temp in temperatures:
            # 不包含过剩熵
            gmix = gibbs_free_energy_temperature(formula, temp)
            if gmix is not None:
                print(f"  T={temp}K: ΔG^m = {gmix:.2f} kJ/mol")
            else:
                print(f"  T={temp}K: 计算失败")
        
        # 包含过剩熵（BCC结构）
        print(f"\n  包含过剩熵 (BCC):")
        for temp in temperatures:
            gmix_bcc = gibbs_free_energy_temperature(formula, temp, True, 'bcc')
            if gmix_bcc is not None:
                print(f"  T={temp}K: ΔG^m (BCC) = {gmix_bcc:.2f} kJ/mol")
            else:
                print(f"  T={temp}K: 计算失败")
        
        # 包含过剩熵（FCC结构）
        print(f"\n  包含过剩熵 (FCC):")
        for temp in temperatures:
            gmix_fcc = gibbs_free_energy_temperature(formula, temp, True, 'fcc')
            if gmix_fcc is not None:
                print(f"  T={temp}K: ΔG^m (FCC) = {gmix_fcc:.2f} kJ/mol")
            else:
                print(f"  T={temp}K: 计算失败")
    
    print("\n===== 混合吉布斯自由能测试 =====")
    test_mixing_gibbs_free_energy()
    
    print("\n所有测试完成!")
