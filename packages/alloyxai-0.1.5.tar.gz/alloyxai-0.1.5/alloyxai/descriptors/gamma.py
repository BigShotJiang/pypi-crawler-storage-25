﻿# -*- coding: utf-8 -*-
import sys
import os
import math


# 导入所需模块
from ..config.radius_data import radius_empirical_dict
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions
from .average_radius import average_atomic_radius_empirical

def calculate_gamma(formula):
    """
    计算晶格畸变参数γ
    公式：γ = ws / wl
    其中：
    - ws = 1 - sqrt(((rs+r)^2 - r^2)/((rs+r)^2))
    - wl = 1 - sqrt(((rl+r)^2 - r^2)/((rl+r)^2))
    - rs是最小原子半径
    - rl是最大原子半径
    - r是平均原子半径
    
    参数:
        formula (str): 化学配方字符串
        
    返回:
        float: γ参数值
        None: 计算失败时返回None
    """
    try:
        # 解析化学式
        elements, counts = get_elements_and_counts(formula)
        
        # 检查是否只有单一元素
        if len(elements) == 1:
            return 1.0  # 单一元素的γ为1
        
        # 检查所有元素是否有有效经验半径数据
        for elem in elements:
            if elem not in radius_empirical_dict:
                raise ValueError(f"元素 {elem} 不在 radius_data 中")
            if radius_empirical_dict[elem] is None:
                raise ValueError(f"元素 {elem} 的经验半径数据缺失 (None)，无法计算晶格畸变参数")
        
        # 计算平均原子半径
        r = average_atomic_radius_empirical(formula)
        
        # 找到最小和最大原子半径
        rs = float('inf')  # 最小半径
        rl = 0.0  # 最大半径
        
        for elem in elements:
            current_radius = radius_empirical_dict[elem]
            if current_radius < rs:
                rs = current_radius
            if current_radius > rl:
                rl = current_radius
        
        # 计算ws
        numerator_ws = (rs + r) ** 2 - r ** 2
        denominator_ws = (rs + r) ** 2
        sqrt_term_ws = math.sqrt(numerator_ws / denominator_ws)
        ws = 1 - sqrt_term_ws
        
        # 计算wl
        numerator_wl = (rl + r) ** 2 - r ** 2
        denominator_wl = (rl + r) ** 2
        sqrt_term_wl = math.sqrt(numerator_wl / denominator_wl)
        wl = 1 - sqrt_term_wl
        
        # 计算gamma
        if wl == 0:
            raise ValueError("分母wl为0，无法计算gamma参数")
        
        gamma = ws / wl
        return round(gamma, 5)
        
    except Exception as e:
        print(f"[γ参数错误] {e}")
        return None

if __name__ == "__main__":
    print("===== 晶格畸变参数γ测试 =====")
    
    # 测试用例
    test_formulas = [
        "FeNiCoCrMn",     # 典型高熵合金
        "AlCuFeMnNi",     # 多元素合金
        "AgCd",           # 二元合金
        "CuZn",           # 二元黄铜
        "Fe",             # 单一元素
    ]
    
    for formula in test_formulas:
        gamma = calculate_gamma(formula)
        if gamma is not None:
            print(f"{formula:<20} γ = {gamma:.5f}")
        else:
            print(f"{formula:<20} 计算失败")
    
    print("\n测试完成!")
