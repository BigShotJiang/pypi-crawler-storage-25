﻿# -*- coding: utf-8 -*-
# 导入必要的模块
import sys
import os
import re


# 导入化学式解析模块
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

# 导电性数据 (10^6 S/m)
electric_conductivity_dict = {
    "H": None, "He": None, "Li": 11, "Be": 25, "B": 1.00e-10, "C": 0.1, "N": 0, "O": None,
    "F": None, "Ne": None, "Na": 21, "Mg": 23, "Al": 38, "Si": 0.001, "P": 10, "S": 1.00e-21,
    "Cl": 1.00e-08, "Ar": None, "K": 14, "Ca": 29, "Sc": 1.8, "Ti": 2.5, "V": 5, "Cr": 7.9,
    "Mn": 0.62, "Fe": 10, "Co": 17, "Ni": 14, "Cu": 59, "Zn": 17, "Ga": 7.1, "Ge": 0.002,
    "As": 3.3, "Se": None, "Br": 1.00e-16, "Kr": None, "Rb": 8.3, "Sr": 7.7, "Y": 1.8, "Zr": 2.4,
    "Nb": 6.7, "Mo": 20, "Tc": 5, "Ru": 14, "Rh": 23, "Pd": 10, "Ag": 62, "Cd": 14,
    "In": 12, "Sn": 9.1, "Sb": 2.5, "Te": 0.01, "I": 1.00e-13, "Xe": None, "Cs": 5, "Ba": 2.9,
    "La": 1.6, "Ce": 1.4, "Pr": 1.4, "Nd": 1.6, "Pm": 1.3, "Sm": 1.1, "Eu": 1.1, "Gd": 0.77,
    "Tb": 0.83, "Dy": 1.1, "Ho": 1.1, "Er": 1.2, "Tm": 1.4, "Yb": 3.6, "Lu": 1.8, "Hf": 3.3,
    "Ta": 7.7, "W": 20, "Re": 5.6, "Os": 12, "Ir": 21, "Pt": 9.4, "Au": 45, "Hg": 1,
    "Tl": 6.7, "Pb": 4.8, "Bi": 0.77, "Po": 2.3, "At": None, "Rn": None, "Fr": None, "Ra": 1,
    "Ac": None, "Th": 6.7, "Pa": 5.6, "U": 3.6, "Np": 0.83, "Pu": 0.67, "Am": None, "Cm": None,
    "Bk": None, "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None,
    "Rg": None, "Cn": None, "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# 导电性计算
def average_electric_conductivity(formula):
    """根据化学式计算合金的平均导电性（原子分数加权）"""
    try:
        # 使用导入的化学式解析模块获取元素列表
        elements, _ = get_elements_and_counts(formula)
        
        # 验证所有元素都有导电性数据
        for elem in elements:
            if electric_conductivity_dict is None or elem not in electric_conductivity_dict:
                raise ValueError(f"元素 {elem} 没有可用的导电性数据")
            ec = electric_conductivity_dict.get(elem)
            if ec is None:
                raise ValueError(f"元素 {elem} 的导电性数据为 None，此合金不适合计算平均导电性")
        
        # 使用formula_parser模块中的get_molar_fractions函数获取摩尔分数
        molar_fractions = get_molar_fractions(formula)
        
        # 提取对应的导电性值和摩尔分数
        ec_values = [electric_conductivity_dict[elem] for elem in elements]
        concentrations = [molar_fractions[elem] for elem in elements]

        # 加权平均计算：property = Σ(c_i × property_i)
        return sum(c * ec for c, ec in zip(concentrations, ec_values))

    except Exception as e:
        print(f"[electric_conductivity 出错] {e}")
        return None

# 测试部分
if __name__ == "__main__":
    # 测试用例
    test_formulas = ["Al", "Cu", "Fe", "Ni", "FeCu", "Al2CoCrFeNi"]
    
    print("=== 平均导电性测试 ===")
    for formula in test_formulas:
        try:
            avg_ec = average_electric_conductivity(formula)
            if avg_ec is not None:
                print(f"{formula}: {avg_ec:.4f} × 10^6 S/m")
        except Exception as e:
            print(f"{formula}: 计算失败 - {e}")
    
    print("\n所有测试完成！")
