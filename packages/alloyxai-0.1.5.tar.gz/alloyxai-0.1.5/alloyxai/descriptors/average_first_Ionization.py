﻿# -*- coding: utf-8 -*-
import re
import sys
import os


# 导入化学式解析模块
from ..utilities.formula_parser import get_elements_and_counts, get_molar_fractions

ionization_energy_kjmol_dict = {
    "H": 1312.0, "He": 2372.3,
    "Li": 520.2, "Be": 899.5, "B": 800.6, "C": 1086.5, "N": 1402.3, "O": 1313.9, "F": 1681.0, "Ne": 2080.7,
    "Na": 495.8, "Mg": 737.7, "Al": 577.5, "Si": 786.5, "P": 1011.8, "S": 999.6, "Cl": 1251.2, "Ar": 1520.6,
    "K": 418.8, "Ca": 589.8, "Sc": 633.1, "Ti": 658.8, "V": 650.9, "Cr": 652.9, "Mn": 717.3, "Fe": 762.5,
    "Co": 760.4, "Ni": 737.1, "Cu": 745.5, "Zn": 906.4,
    "Ga": 578.8, "Ge": 762.0, "As": 947.0, "Se": 941.0, "Br": 1139.9, "Kr": 1350.8,
    "Rb": 403.0, "Sr": 549.5, "Y": 600.0, "Zr": 640.1, "Nb": 652.1, "Mo": 684.3, "Tc": 702.0, "Ru": 710.2,
    "Rh": 719.7, "Pd": 804.4, "Ag": 731.0, "Cd": 867.8,
    "In": 558.3, "Sn": 708.6, "Sb": 834.0, "Te": 869.3, "I": 1008.4, "Xe": 1170.4,
    "Cs": 375.7, "Ba": 502.9,
    "La": 538.1, "Ce": 534.4, "Pr": 527.0, "Nd": 533.1, "Pm": 540.0, "Sm": 544.5, "Eu": 547.1, "Gd": 593.4,
    "Tb": 565.8, "Dy": 573.0, "Ho": 581.0, "Er": 589.3, "Tm": 596.7, "Yb": 603.4, "Lu": 523.5,
    "Hf": 658.5, "Ta": 761.0, "W": 770.0, "Re": 760.0, "Os": 840.0, "Ir": 880.0,
    "Pt": 870.0, "Au": 890.1, "Hg": 1007.1, "Tl": 589.4, "Pb": 715.6, "Bi": 703.0, "Po": 812.1, "At": 890.0,
    "Rn": 1037.0,
    "Fr": 380.0, "Ra": 509.3, "Ac": 499.0, "Th": 587.0, "Pa": 568.0, "U": 597.6, "Np": 604.5, "Pu": 584.7,
    "Am": 578.0, "Cm": 581.0, "Bk": 601.0, "Cf": 608.0, "Es": 619.0, "Fm": 627.0, "Md": 635.0, "No": 642.0,
    "Lr": 470.0, "Rf": 580.0,
    "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# 将kJ/mol转换为eV的系数
KJ_TO_EV = 0.0103642721

# 创建eV单位的电离能字典
ionization_energy_ev_dict = {}
for elem, value in ionization_energy_kjmol_dict.items():
    if value is not None:
        ionization_energy_ev_dict[elem] = value * KJ_TO_EV
    else:
        ionization_energy_ev_dict[elem] = None

def average_first_ionization_kjmol(formula):
    """根据化学式计算合金的平均第一电离能（kJ/mol，原子分数加权）"""
    try:
        # 使用导入的化学式解析模块获取元素列表
        elements, _ = get_elements_and_counts(formula)
        
        # 验证所有元素都有电离能数据
        for elem in elements:
            if ionization_energy_kjmol_dict is None or elem not in ionization_energy_kjmol_dict:
                raise ValueError(f"元素 {elem} 没有可用的第一电离能数据（kJ/mol）")
            ie = ionization_energy_kjmol_dict.get(elem)
            if ie is None:
                raise ValueError(f"元素 {elem} 的第一电离能数据（kJ/mol）为 None，此合金不适合计算平均第一电离能")
        
        # 使用formula_parser模块中的get_molar_fractions函数获取摩尔分数
        molar_fractions = get_molar_fractions(formula)
        
        # 提取对应的电离能值和摩尔分数
        ie_values = [ionization_energy_kjmol_dict[elem] for elem in elements]
        concentrations = [molar_fractions[elem] for elem in elements]

        # 加权平均计算
        return sum(c * ie for c, ie in zip(concentrations, ie_values))

    except Exception as e:
        print(f"[average_first_ionization_kjmol 出错] {e}")
        return None

def average_first_ionization_ev(formula):
    """根据化学式计算合金的平均第一电离能（eV，原子分数加权）"""
    try:
        # 使用导入的化学式解析模块获取元素列表
        elements, _ = get_elements_and_counts(formula)
        
        # 验证所有元素都有电离能数据
        for elem in elements:
            if ionization_energy_ev_dict is None or elem not in ionization_energy_ev_dict:
                raise ValueError(f"元素 {elem} 没有可用的第一电离能数据（eV）")
            ie = ionization_energy_ev_dict.get(elem)
            if ie is None:
                raise ValueError(f"元素 {elem} 的第一电离能数据（eV）为 None，此合金不适合计算平均第一电离能")
        
        # 使用formula_parser模块中的get_molar_fractions函数获取摩尔分数
        molar_fractions = get_molar_fractions(formula)
        
        # 提取对应的电离能值和摩尔分数
        ie_values = [ionization_energy_ev_dict[elem] for elem in elements]
        concentrations = [molar_fractions[elem] for elem in elements]

        # 加权平均计算
        return sum(c * ie for c, ie in zip(concentrations, ie_values))

    except Exception as e:
        print(f"[average_first_ionization_ev 出错] {e}")
        return None

if __name__ == "__main__":
    # 测试各种化学式格式
    test_formulas = [
        "Fe",             # 单元素
        "Fe2Ni",          # 简单的二元合金
        "Fe0.2Ni0.3",     # 带小数系数的合金
        "(FeNi)3",        # 带括号的合金
        "FeNiCr",         # 三元合金
        "Fe Ni",          # 带空格的合金
        "Fe(NiCr)2",      # 嵌套括号的复杂合金
        "Fe-10Ni",        # 带连字符的合金
        "CuZn5",          # 简单的二元合金
        "(TiAl)3V2",      # 带括号的复杂合金
    ]
    
    print("kJ/mol 测试:")
    print("=" * 50)
    for formula in test_formulas:
        result = average_first_ionization_kjmol(formula)
        print(f"{formula}: {result}")
    
    print("\neV 测试:")
    print("=" * 50)
    for formula in test_formulas:
        result = average_first_ionization_ev(formula)
        print(f"{formula}: {result}")
    
    # 验证带括号的化学式解析是否正确（使用formula_parser模块）
    print("\n化学式解析验证:")
    print("=" * 50)
    from ..utilities.formula_parser import parse_formula
    
    # 摩尔浓度测试
    print("\n摩尔浓度测试:")
    print("=" * 50)
    from ..utilities.formula_parser import get_molar_fractions
    for formula in test_formulas:
        molar_fractions = get_molar_fractions(formula)
        print(f"{formula}: {molar_fractions}")
        # 验证摩尔分数之和是否为1
        total = sum(molar_fractions.values())
        print(f"  总和: {total:.6f}, 是否接近1: {abs(total - 1.0) < 1e-10}")
    test_formula = "(FeNi)3"
    parsed = parse_formula(test_formula)
    print(f"{test_formula} 解析结果: {parsed}")  # 应该是 {'Fe': 3, 'Ni': 3}
    
    test_formula2 = "Fe(NiCr)2"
    parsed2 = parse_formula(test_formula2)
    print(f"{test_formula2} 解析结果: {parsed2}")  # 应该是 {'Fe': 1, 'Ni': 2, 'Cr': 2}


