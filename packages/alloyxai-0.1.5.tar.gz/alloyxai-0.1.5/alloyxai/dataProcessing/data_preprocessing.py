"""
数据预处理脚本

该脚本用于处理合金成分数据，将Excel文件中的合金成分从元素:百分比格式转换为化学式格式。

功能说明：
1. 读取Excel文件中的合金成分数据
2. 自动识别成分格式（化学式格式或元素:百分比格式）
3. 将元素:百分比格式转换为化学式格式
4. 预处理数据（去除空行等）
5. 保存处理后的数据到指定目录

使用方法: 
    # 传统方式（向后兼容）
    python data_preprocessing.py <excel_file> [column_name]
    
    # 新方式（推荐）
    python data_preprocessing.py -i <excel_file> [-o <output_directory>] [-c <column_name>]
    
参数说明：
    # 传统方式参数：
    <excel_file>           - 输入的Excel文件路径（必需）
    [column_name]          - 要处理的列名（可选，默认为 'alloy_composition'）
                           - 指定Excel文件中包含合金成分的列名
    
    # 新方式参数：
    -i, --input <excel_file>     - 输入的Excel文件路径（必需）
    -o, --output <output_directory> - 输出目录（可选，默认为 'results/data_pre-processing'）
    -c, --column <column_name>   - 要处理的列名（可选，默认为 'alloy_composition'）

示例：
    # 使用默认设置（默认列名 'alloy_composition'）
    python data_preprocessing.py three_columns.xlsx
    python data_preprocessing.py -i three_columns.xlsx
    
    # 指定自定义列名
    python data_preprocessing.py three_columns.xlsx alloy_composition_test
    python data_preprocessing.py -i three_columns.xlsx -c alloy_composition_test
    python data_preprocessing.py -i three_columns.xlsx -c "成分信息"
    
    # 指定输出目录
    python data_preprocessing.py -i three_columns.xlsx -o ./output
    python data_preprocessing.py -i three_columns.xlsx -o ./output -c alloy_composition_test

输入文件格式要求：
    - 合金成分格式可以是：
        * 化学式格式：如 "Fe2Ni" 或 "Al50Cu25Zr25"
        * 元素百分比格式：如 "Fe:50;Ni:50" 或 "Al:50;Cu:25;Zr:25"
        
输出说明：
    - 处理后的文件将保存在指定输出目录中
    - 文件名将添加 '_processed' 后缀
    - 输出文件包含原始数据及处理后的合金成分列 'alloy_composition_after_process'

注意事项：
    - 支持 .xlsx 文件格式
    - 如果输出文件已存在，将自动添加数字后缀以避免覆盖
    - 脚本会自动去除包含空值的行
    - Windows系统中，如果路径包含空格，建议使用双引号包围路径，例如: 
      python data_preprocessing.py input.xlsx "C:/path/with spaces/output"

python data_preprocessing.py -i ./three_columns.xlsx -o ./results/data_pre-processing/ -c alloy_composition

"""


import pandas as pd
import sys
import re
import argparse
import os


def is_chemical_formula(composition):
    """
    Determine if the composition is already in chemical formula format.
    
    Parameters:
    composition (str): Alloy composition string.
    
    Returns:
    bool: True if it's in chemical formula format, False otherwise.
    """
    if ':' in composition or ';' in composition:
        return False
    return True


def convert_composition_to_formula(composition):
    """
    Convert alloy composition from element:percentage format to chemical formula format.
    
    Parameters:
    composition (str): Alloy composition in element:percentage format.
    
    Returns:
    str: Alloy composition in chemical formula format.
    """
    elements = [elem.strip() for elem in composition.split(';')]
    
    element_dict = {}
    for element in elements:
        if ':' in element:
            elem, percent = element.split(':')
            elem = elem.strip()
            percent = float(percent.strip())
            element_dict[elem] = percent / 100.0
    
    formula_parts = []
    for elem, amount in element_dict.items():
        if amount < 0.00001:
            continue
        
        if abs(amount - 1.0) < 1e-10:
            formula_parts.append(elem)
        else:
            formatted_amount = f"{amount:.6f}".rstrip('0').rstrip('.')
            if not formatted_amount:
                formatted_amount = "0"
            formula_parts.append(f"{elem}{formatted_amount}")
    
    return "".join(formula_parts)


def process_alloy_composition(df, column_name='alloy_composition'):
    """
    Process alloy composition column to create a standardized format.
    
    Parameters:
    df (pd.DataFrame): DataFrame containing alloy composition data.
    column_name (str): Name of the column to process (default is 'alloy_composition').
    
    Returns:
    pd.DataFrame: DataFrame with processed alloy composition.
    """
    if column_name not in df.columns:
        raise ValueError(f"Column '{column_name}' not found in the DataFrame. Available columns: {list(df.columns)}")
    
    df['alloy_composition_after_process'] = df[column_name].apply(
        lambda x: x if is_chemical_formula(x) else convert_composition_to_formula(x)
    )
    
    return df


def load_and_preprocess_data(file_path, save_to_file=True, column_name='alloy_composition', output_dir=None, save_csv=True):
    """
    Load data from an Excel file, process alloy composition, and optionally save to a new file.
    
    Parameters:
    file_path (str): Path to the Excel file.
    save_to_file (bool): Whether to save the processed data to a new file.
    column_name (str): Name of the column to process (default is 'alloy_composition').
    output_dir (str): Directory to save the processed file (default is None, uses 'results/data pre-processing').
    save_csv (bool): Whether to also save as CSV format (default is False).
    
    Returns:
    pd.DataFrame: DataFrame with processed alloy composition.
    """
    try:
        df = pd.read_excel(file_path, engine='openpyxl')
    except Exception as e:
        print(f"Error reading Excel file: {e}")
        raise
    
    df = df.dropna(how='all')
    df = df.dropna(subset=[column_name])
    df = process_alloy_composition(df, column_name)
    
    if save_to_file:
        if file_path.endswith('.xlsx'):
            base_filename = file_path.replace('.xlsx', '_processed')
        else:
            base_filename = file_path + '_processed'
        
        base_filename = os.path.basename(base_filename)
        
        if output_dir is None:
            output_dir = os.path.join('results', 'data_pre-processing')
        output_dir = os.path.abspath(output_dir)
        os.makedirs(output_dir, exist_ok=True)
        base_output_file = os.path.join(output_dir, base_filename)
        
        output_file = base_output_file + '.xlsx'
        counter = 1
        final_base_output_file = base_output_file
        
        while True:
            try:
                while os.path.exists(output_file):
                    final_base_output_file = f"{base_output_file}_{counter}"
                    output_file = f"{final_base_output_file}.xlsx"
                    counter += 1
                
                df.to_excel(output_file, index=False, engine='openpyxl')
                print(f"Preprocessed data saved to Excel: {output_file}")
                
                if save_csv:
                    csv_output_file = f"{final_base_output_file}.csv"
                    df.to_csv(csv_output_file, index=False, encoding='utf-8-sig')
                    print(f"Preprocessed data saved to CSV: {csv_output_file}")
                
                break
            except PermissionError:
                final_base_output_file = f"{base_output_file}_{counter}"
                output_file = f"{final_base_output_file}.xlsx"
                counter += 1
                if counter > 100:
                    raise
            except Exception as e:
                print(f"Error saving file: {e}")
                raise
    
    return df


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Process alloy composition data from Excel files.')
    
    parser.add_argument('-i', '--input', dest='input_file', required=False,
                        help='Path to the input Excel file')
    parser.add_argument('-o', '--output', dest='output_dir', default=None,
                        help='Directory to save the processed file (default: results/data_pre-processing)')
    parser.add_argument('-c', '--column', dest='column_name', default='alloy_composition',
                        help='Name of the column containing alloy composition (default: alloy_composition)')
    parser.add_argument('--save-csv', action='store_true',
                        help='Also save the processed data as CSV format (default: only save Excel)')
    
    args = parser.parse_args()
    
    input_file = args.input_file
    output_dir = args.output_dir
    column_name = args.column_name
    
    if input_file is None:
        if len(sys.argv) >= 2:
            input_file = sys.argv[1]
            if len(sys.argv) == 3:
                column_name = sys.argv[2]
        else:
            parser.print_help()
            sys.exit(1)
    
    if not os.path.exists(input_file):
        print(f"Error: Input file '{input_file}' does not exist.")
        sys.exit(1)
    
    if not input_file.endswith('.xlsx'):
        print(f"Error: Input file must be an Excel file with .xlsx extension.")
        sys.exit(1)
    
    if output_dir is not None:
        if not os.path.exists(output_dir):
            try:
                os.makedirs(output_dir, exist_ok=True)
                print(f"Created output directory: {output_dir}")
            except Exception as e:
                print(f"Error creating output directory: {e}")
                sys.exit(1)
        if not os.path.isdir(output_dir):
            print(f"Error: Output path '{output_dir}' is not a directory.")
            sys.exit(1)
    
    try:
        load_and_preprocess_data(input_file, column_name=column_name, output_dir=output_dir, save_csv=True)
    except Exception as e:
        print(f"Error processing file: {e}")
        sys.exit(1)
