#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
查询策略实现

提供多种主动学习查询策略，包括不确定性采样等。
"""

import numpy as np


class UncertaintySampling:
    """
    不确定性采样策略
    
    基于模型对样本预测的不确定性来选择最有价值的样本。
    支持多种不确定性度量方法。
    """
    
    def __init__(self, method='entropy'):
        """
        初始化不确定性采样策略
        
        参数:
        method: 不确定性度量方法，可选值:
            'entropy': 熵（分类任务）
            'margin': 边际（分类任务）
            'least_confident': 最小置信度（分类任务）
            'variance': 方差（回归任务）
        """
        self.method = method
    
    def select(self, model, X_pool, X_train, n_instances=1):
        """
        选择最不确定的样本
        
        参数:
        model: 机器学习模型
        X_pool: 未标注数据池
        X_train: 已标注训练数据
        n_instances: 要选择的样本数量
        
        返回:
        选中样本的索引列表
        """
        if len(X_train) == 0:
            # 初始时随机选择
            return np.random.choice(len(X_pool), n_instances, replace=False)
        
        # 根据任务类型选择不确定性度量
        try:
            # 尝试分类任务的不确定性度量
            if hasattr(model, 'predict_proba'):
                return self._classification_uncertainty(model, X_pool, n_instances)
            else:
                # 回归任务的不确定性度量
                return self._regression_uncertainty(model, X_pool, n_instances)
        except Exception as e:
            # 如果出现错误，随机选择
            print(f"不确定性计算失败: {e}，将随机选择样本")
            return np.random.choice(len(X_pool), n_instances, replace=False)
    
    def _classification_uncertainty(self, model, X_pool, n_instances):
        """
        分类任务的不确定性计算
        """
        # 获取预测概率
        probs = model.predict_proba(X_pool)
        
        if self.method == 'entropy':
            # 熵：-sum(p * log(p))
            entropy = -np.sum(probs * np.log(probs + 1e-10), axis=1)
            uncertainties = entropy
        elif self.method == 'margin':
            # 边际：最大概率与第二大概率的差
            sorted_probs = np.sort(probs, axis=1)[:, ::-1]
            margin = sorted_probs[:, 0] - sorted_probs[:, 1]
            uncertainties = -margin  # 负值，以便与其他方法一致（值越大越不确定）
        elif self.method == 'least_confident':
            # 最小置信度：1 - 最大概率
            max_probs = np.max(probs, axis=1)
            uncertainties = 1 - max_probs
        else:
            # 默认使用熵
            entropy = -np.sum(probs * np.log(probs + 1e-10), axis=1)
            uncertainties = entropy
        
        # 选择不确定性最大的样本
        selected_indices = np.argsort(uncertainties)[-n_instances:]
        return selected_indices
    
    def _regression_uncertainty(self, model, X_pool, n_instances):
        """
        回归任务的不确定性计算
        """
        # 对于回归任务，使用预测方差作为不确定性度量
        # 注意：许多回归模型不直接提供预测方差
        # 这里使用一种简化方法：预测值的变化
        
        try:
            # 如果模型支持预测区间
            if hasattr(model, 'predict'):
                # 对于集成模型，可以使用成员预测的方差
                if hasattr(model, 'estimators_'):
                    # 集成模型（如随机森林）
                    predictions = np.array([estimator.predict(X_pool) for estimator in model.estimators_])
                    uncertainties = np.var(predictions, axis=0)
                else:
                    # 单个模型，使用简化方法
                    # 这里使用预测值的绝对值作为不确定性的近似
                    # 这是一种启发式方法，实际应用中可能需要更复杂的度量
                    predictions = model.predict(X_pool)
                    uncertainties = np.abs(predictions)
            else:
                # 如果模型没有predict方法，随机选择
                return np.random.choice(len(X_pool), n_instances, replace=False)
        except Exception:
            # 如果出现错误，随机选择
            return np.random.choice(len(X_pool), n_instances, replace=False)
        
        # 选择不确定性最大的样本
        selected_indices = np.argsort(uncertainties)[-n_instances:]
        return selected_indices


class RandomSampling:
    """
    随机采样策略
    
    作为基准策略，用于比较其他策略的性能。
    """
    
    def select(self, model, X_pool, X_train, n_instances=1):
        """
        随机选择样本
        
        参数:
        model: 机器学习模型
        X_pool: 未标注数据池
        X_train: 已标注训练数据
        n_instances: 要选择的样本数量
        
        返回:
        选中样本的索引列表
        """
        return np.random.choice(len(X_pool), n_instances, replace=False)
