#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
主动学习模块

提供合金材料机器学习的主动学习功能，
支持不确定性采样等基础查询策略。
"""

__version__ = "1.0.0"
__author__ = "AlloyXAI Team"
