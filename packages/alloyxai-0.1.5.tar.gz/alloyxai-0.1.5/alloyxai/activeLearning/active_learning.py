#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
主动学习核心功能

实现简化的主动学习器，支持与现有机器学习模型的集成。
"""

import numpy as np


class SimpleActiveLearner:
    """
    简化的主动学习器
    
    支持与现有机器学习模型的无缝集成，
    提供基本的查询-标注-更新流程。
    """
    
    def __init__(self, model, strategy, X_pool, y_pool=None):
        """
        初始化主动学习器
        
        参数:
        model: 机器学习模型，需实现 fit() 和 predict() 方法
        strategy: 查询策略，需实现 select() 方法
        X_pool: 未标注数据池，numpy数组或列表
        y_pool: 真实标签（可选），用于评估
        """
        self.model = model
        self.strategy = strategy
        self.X_pool = X_pool if isinstance(X_pool, np.ndarray) else np.array(X_pool)
        self.y_pool = y_pool if y_pool is None else (y_pool if isinstance(y_pool, np.ndarray) else np.array(y_pool))
        self.X_train = []  # 已标注训练数据
        self.y_train = []  # 已标注训练标签
        self.selected_indices = []  # 已选择的样本索引
    
    def query(self, n_instances=1):
        """
        查询最有价值的样本
        
        参数:
        n_instances: 要查询的样本数量
        
        返回:
        选中样本的索引列表
        """
        # 调用策略的选择方法
        indices = self.strategy.select(self.model, self.X_pool, self.X_train, n_instances)
        self.selected_indices.extend(indices)
        return indices
    
    def teach(self, indices, labels):
        """
        使用标注数据更新模型
        
        参数:
        indices: 已标注样本的索引
        labels: 对应样本的标签
        """
        # 将查询的样本从池转移到训练集
        for i, idx in enumerate(indices):
            self.X_train.append(self.X_pool[idx])
            self.y_train.append(labels[i])
        
        # 转换为numpy数组
        X_train_np = np.array(self.X_train)
        y_train_np = np.array(self.y_train)
        
        # 重新训练模型
        self.model.fit(X_train_np, y_train_np)
    
    def evaluate(self, X_test, y_test):
        """
        评估模型性能
        
        参数:
        X_test: 测试数据
        y_test: 测试标签
        
        返回:
        模型评分（如准确率、R²等）
        """
        return self.model.score(X_test, y_test)
    
    def get_selected_samples(self):
        """
        获取已选择的样本
        
        返回:
        已选择样本的数据和标签
        """
        selected_X = self.X_pool[self.selected_indices]
        selected_y = self.y_pool[self.selected_indices] if self.y_pool is not None else None
        return selected_X, selected_y
    
    def get_training_data(self):
        """
        获取当前训练数据
        
        返回:
        训练数据和标签
        """
        return np.array(self.X_train), np.array(self.y_train)
