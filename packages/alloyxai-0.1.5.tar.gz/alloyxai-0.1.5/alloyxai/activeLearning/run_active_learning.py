#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
运行主动学习示例

展示如何使用主动学习功能与现有合金材料机器学习流程集成。
"""

import os
import sys
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

def load_feature_data(data_path, target_column=None):
    """
    加载特征工程后的数据
    
    参数:
    data_path: 数据文件路径
    target_column: 目标变量列名
    
    返回:
    X: 特征数据
    y: 目标变量
    feature_names: 特征名称列表
    """
    print(f"加载数据: {data_path}")
    
    # 加载数据
    if data_path.endswith('.csv'):
        data = pd.read_csv(data_path)
    elif data_path.endswith('.xlsx'):
        data = pd.read_excel(data_path)
    else:
        raise ValueError(f"不支持的文件格式: {data_path}")
    
    print(f"数据加载成功！数据形状: {data.shape}")
    
    # 确定目标变量列
    if target_column is None:
        # 默认使用最后一列作为目标变量
        target_column = data.columns[-1]
        print(f"未指定目标变量，使用最后一列: {target_column}")
    
    # 分离特征和目标变量
    X = data.drop(columns=[target_column])
    y = data[target_column]
    
    # 只保留数值类型的特征
    numeric_columns = X.select_dtypes(include=['number']).columns.tolist()
    X = X[numeric_columns]
    feature_names = X.columns.tolist()
    
    print(f"原始特征数量: {len(data.columns) - 1}")
    print(f"数值特征数量: {X.shape[1]}")
    print(f"目标变量: {target_column}")
    
    return X.values, y.values, feature_names


def load_model(model_type='random_forest'):
    """
    加载机器学习模型
    
    参数:
    model_type: 模型类型
    
    返回:
    初始化的模型
    """
    print(f"加载模型: {model_type}")
    
    # 直接使用scikit-learn模型，确保稳定性
    try:
        if model_type == 'random_forest':
            from sklearn.ensemble import RandomForestRegressor
            return RandomForestRegressor(random_state=42)
        elif model_type == 'decision_tree':
            from sklearn.tree import DecisionTreeRegressor
            return DecisionTreeRegressor(random_state=42)
        elif model_type == 'svm':
            from sklearn.svm import SVR
            return SVR()
        else:
            from sklearn.ensemble import RandomForestRegressor
            return RandomForestRegressor(random_state=42)
    except Exception as e:
        print(f"模型加载失败: {e}，使用默认随机森林模型")
        from sklearn.ensemble import RandomForestRegressor
        return RandomForestRegressor(random_state=42)


def main():
    """
    主函数：运行主动学习示例
    """
    # 1. 配置参数
    data_path = "results/engineer/feature_engineering/three_columns_processed_processed_processed_standardized_engineered.csv"
    target_column = "Yield_Strength (MPa)"
    model_type = "random_forest"
    n_iterations = 5
    n_samples_per_iter = 5
    test_size = 0.2
    
    # 2. 加载数据
    try:
        X, y, feature_names = load_feature_data(data_path, target_column)
    except Exception as e:
        print(f"数据加载失败: {e}")
        sys.exit(1)
    
    # 3. 分割训练集和测试集
    X_train_initial, X_test, y_train_initial, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42
    )
    print(f"数据分割完成！初始训练集大小: {X_train_initial.shape[0]}, 测试集大小: {X_test.shape[0]}")
    
    # 4. 加载模型
    model = load_model(model_type)
    
    # 5. 初始化主动学习器
    from .active_learning import SimpleActiveLearner
    from .query_strategies import UncertaintySampling
    
    # 使用初始训练集训练模型
    model.fit(X_train_initial, y_train_initial)
    
    # 剩余数据作为未标注池
    X_pool = X_test.copy()
    y_pool = y_test.copy()
    
    # 初始化查询策略和主动学习器
    strategy = UncertaintySampling(method='entropy')
    learner = SimpleActiveLearner(model, strategy, X_pool, y_pool)
    
    # 6. 评估初始模型性能
    initial_performance = learner.evaluate(X_test, y_test)
    print(f"\n初始模型性能: {initial_performance:.4f}")
    
    # 7. 主动学习循环
    print("\n开始主动学习循环...")
    performance_history = [initial_performance]
    
    for i in range(n_iterations):
        print(f"\n迭代 {i+1}/{n_iterations}")
        
        # 查询最有价值的样本
        print(f"查询 {n_samples_per_iter} 个最有价值的样本...")
        indices = learner.query(n_instances=n_samples_per_iter)
        print(f"选中的样本索引: {indices}")
        
        # 假设这些样本被专家标注（这里直接使用真实标签模拟）
        labels = y_pool[indices]
        print(f"样本标签: {labels[:3]}...")  # 只显示前3个标签
        
        # 更新模型
        print("更新模型...")
        learner.teach(indices, labels)
        
        # 评估当前性能
        current_performance = learner.evaluate(X_test, y_test)
        performance_history.append(current_performance)
        print(f"当前模型性能 (R2): {current_performance:.4f}")
        
        # 计算性能提升
        if i > 0:
            improvement = current_performance - performance_history[i]
            print(f"性能提升: {improvement:.4f}")
    
    # 8. 总结
    print("\n" + "="*60)
    print("主动学习完成！")
    print("="*60)
    print(f"初始性能 (R2): {performance_history[0]:.4f}")
    print(f"最终性能 (R2): {performance_history[-1]:.4f}")
    print(f"性能变化: {performance_history[-1] - performance_history[0]:.4f}")
    print(f"总查询样本数: {len(learner.selected_indices)}")
    
    # 9. 保存结果
    # 创建输出目录
    output_dir = "results/active_learning"
    os.makedirs(output_dir, exist_ok=True)
    
    # 保存性能历史
    performance_df = pd.DataFrame({
        'iteration': list(range(len(performance_history))),
        'performance': performance_history
    })
    performance_path = os.path.join(output_dir, f"active_learning_performance_{model_type}.csv")
    performance_df.to_csv(performance_path, index=False)
    print(f"\n性能历史保存到: {performance_path}")
    
    # 保存选中的样本索引
    indices_df = pd.DataFrame({
        'selected_index': learner.selected_indices
    })
    indices_path = os.path.join(output_dir, f"active_learning_selected_indices_{model_type}.csv")
    indices_df.to_csv(indices_path, index=False)
    print(f"选中样本索引保存到: {indices_path}")
    
    # 保存选中的样本
    selected_X, selected_y = learner.get_selected_samples()
    selected_df = pd.DataFrame(selected_X, columns=feature_names)
    selected_df[target_column] = selected_y
    selected_path = os.path.join(output_dir, f"selected_samples_{model_type}.csv")
    selected_df.to_csv(selected_path, index=False)
    print(f"选中的样本保存到: {selected_path}")


if __name__ == '__main__':
    # 运行主动学习示例
    try:
        main()
    except Exception as e:
        print(f"运行失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
