"""
Alloy Data Processing Script
============================

该脚本用于处理合金数据，从Excel文件中提取化学式并计算各种物理性质参数。

功能说明：
- 从Excel文件中读取合金成分数据
- 解析化学式，提取元素组成及比例
- 计算各种物理性质参数，包括：
  * 平均沸点（摄氏度、开尔文、华氏度）
  * 平均密度（STP和液态条件下的kg/m³和g/cm³）
  * 平均电负性
  * 平均熔点（摄氏度、开尔文、华氏度）
  * 平均原子半径（计算值、经验值、共价半径、范德华半径）
  * 弹性模量（剪切模量、体积模量、杨氏模量）及标准差
  * 硬度（布氏、莫氏、维氏）及标准差
  * 导热性和导电性
  * 电负性差异
  * 混合熵和混合焓
  * 等效剪切模量偏差
  * 电负性标准偏差
  * 熔点分散度
  * 原子半径畸变量
  * λ参数
  * 平均价电子浓度
  * Ω参数
  * 平均原子序数
  * 平均第一电离能

使用方法：
1. 直接运行（自动处理data_pre-processing目录下最新的Excel文件）：
   python alloy_descriptor_calculator.py

2. 传统方式（向后兼容）：
   python alloy_descriptor_calculator.py your_file.xlsx
   python alloy_descriptor_calculator.py your_file.xlsx "custom_column_name"

3. 新方式（推荐）：
   python alloy_descriptor_calculator.py -i your_file.xlsx [-o output_directory] [-c column_name]

4. 处理包含空格的路径或列名时，使用双引号：
   python alloy_descriptor_calculator.py "path with spaces/your_file.xlsx" "custom column name"
   python alloy_descriptor_calculator.py -i "path with spaces/your_file.xlsx" -o "output directory" -c "custom column name"

参数说明：
- -i, --input <excel_file>：输入的Excel文件路径（必需）
- -o, --output <output_directory>：输出目录（可选，默认为 results/data_descriptors）
- -c, --column <column_name>：要处理的列名（可选，默认为 alloy_composition_after_process）

示例：
# 使用默认设置
python alloy_descriptor_calculator.py -i three_columns.xlsx

# 指定自定义列名
python alloy_descriptor_calculator.py -i three_columns.xlsx -c alloy_composition_test

# 指定输出目录
python alloy_descriptor_calculator.py -i three_columns.xlsx -o ./output

# 组合使用
python alloy_descriptor_calculator.py -i three_columns.xlsx -o ./output -c "成分信息"

注意：
- 默认处理的列名为 'alloy_composition_after_process'
- 如果指定的列名在Excel文件中不存在，程序将抛出错误
- 输出文件将保存在 'results/data_descriptors' 目录下
- 日志文件将保存在 'results/logs' 目录下，文件名为 'decriptors_时间戳.log'
- 确保运行脚本前已安装所有必要的依赖包
- 混合焓数据将从 descriptors/mixing_enthalpy.py 中获取
"""

# 检查当前工作目录
import os
import sys
import datetime
import io
import contextlib
import argparse
from importlib.resources import files


def _get_project_root():
    return os.getcwd()


# 设置日志文件
def setup_logging():
    # 创建results/logs目录
    script_dir = _get_project_root()
    logs_dir = os.path.join(script_dir, "results", "logs")
    os.makedirs(logs_dir, exist_ok=True)
    
    # 生成带时间戳的日志文件名
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = f"alloy_descriptor_calculator_{timestamp}.log"
    log_path = os.path.join(logs_dir, log_filename)
    
    return log_path

# 重定向print函数以同时输出到控制台和日志文件
class Logger:
    def __init__(self, log_path):
        self.terminal = sys.stdout
        self.log = open(log_path, 'w', encoding='utf-8')
    
    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()
    
    def flush(self):
        self.terminal.flush()
        self.log.flush()

# 设置日志
log_path = setup_logging()
sys.stdout = Logger(log_path)

print(f"当前工作目录: {os.getcwd()}")
print(f"日志文件路径: {log_path}")
# 确保在正确的目录下运行
json_path = str(files('alloyxai.config').joinpath('hij_pairs_improved.json'))
if not os.path.exists(json_path):
    print(f"警告: 未找到混合焓数据文件 '{json_path}'，某些计算可能无法完成")
import pandas as pd
from .utilities.formula_parser import parse_formula, get_elements_and_counts, get_molar_fractions
from .config.chemistry_elements import valid_elements
# 导入平均沸点计算函数
from .descriptors.average_boiling_point import average_boiling_point_celsius, average_boiling_point_kelvin, average_boiling_point_fahrenheit
# 导入平均密度计算函数
from .descriptors.average_density import average_density_stp_kg, average_density_stp_g, average_density_liquid_kg, average_density_liquid_g
# 导入平均电负性计算函数
from .descriptors.average_electronegativity import average_electronegativity
# 导入平均熔点计算函数
from .descriptors.average_melting_point import average_melting_point_celsius, average_melting_point_kelvin, average_melting_point_fahrenheit
# 导入平均原子半径计算函数
from .descriptors.average_radius import average_atomic_radius_calculated, average_atomic_radius_empirical, average_atomic_radius_covalent, average_atomic_radius_vanderWaals
# 导入弹性模量相关函数
from .descriptors.average_modulus import average_bulk_modulus, average_shear_modulus, average_young_modulus
from .descriptors.modulus_std import shear_modulus_std, bulk_modulus_std, young_modulus_std
# 导入硬度计算函数
from .descriptors.average_hardness import average_hardness_brinell, average_hardness_mohs, average_hardness_vickers
# 导入硬度标准差计算函数
from .descriptors.delta_hardness import sigma_hardness_brinell, sigma_hardness_mohs, sigma_hardness_vickers

# 导入导热性和导电性计算函数
from .descriptors.average_thermal_conductivity import average_thermal_conductivity
from .descriptors.average_electric_conductivity import average_electric_conductivity
from .descriptors.delta_thermal_conductivity import delta_thermal_conductivity
from .descriptors.delta_electric_conductivity import delta_electric_conductivity
# 导入电负性差异计算函数
from .descriptors.delta_chi import delta_chi
# 导入原子半径畸变量相关函数
from .descriptors.delta_r import delta_r_radius_empirical, delta_r_radius_calculated, delta_r_radius_covalent, delta_r_radius_vanderWaals
# 导入λ参数相关函数
from .descriptors.lambda_parameter import lambda_parameter_empirical, lambda_parameter_calculated, lambda_parameter_covalent, lambda_parameter_vanderWaals
# 导入平均原子序数计算函数
from .descriptors.average_atomic_number import average_atomic_number
# 导入平均第一电离能计算函数
from .descriptors.average_first_Ionization import average_first_ionization_ev, average_first_ionization_kjmol
from .descriptors.sigma_mixing_enthalpy import sigma_mixing_enthalpy
from .descriptors.sigma_vec import calculate_sigma_vec

# 混合焓计算使用descriptors.mixing_enthalpy中的函数
# 导入混合熵和混合焓计算函数
from .descriptors.entropy import mixing_entropy
from .descriptors.mixing_enthalpy import mixing_enthalpy
# 导入等效剪切模量偏差计算函数
from .descriptors.sigma_shear import sigma_shear
from .descriptors.std_electronegativity import std_electronegativity
# 导入熔点分散度计算函数
from .descriptors.sigma_Tm import sigma_Tm_kelvin, sigma_Tm_celsius, sigma_Tm_fahrenheit
# 导入平均价电子浓度计算函数
from .descriptors.vec import average_vec
from .descriptors.delta_vec import delta_vec
# 导入Ω参数计算函数
from .descriptors.omega_parameter import calculate_omega_kelvin, calculate_omega_celsius, calculate_omega_fahrenheit
# 导入新的描述符计算函数
from .descriptors.gamma import calculate_gamma
from .descriptors.phi import calculate_phi
from .descriptors.psfe import calculate_psfe
from .descriptors.intermetallic_gibbs import intermetallic_gibbs
from .descriptors.kappa1 import kappa1, kappa1_critical
print("成功导入所有descriptors模块")

def extract_elements_and_ratios(formula):
    """
    使用formula_parser从化学式中提取元素符号和比例
    使用更完善的化学式解析功能，支持带括号、空格、连字符的复杂化学式
    并验证元素符号的有效性
    """
    try:
        # 使用parse_formula解析化学式
        element_counts = parse_formula(formula)
        
        # 计算总原子数
        total_atoms = sum(element_counts.values())
        
        # 计算比例百分比（占比），只保留有效的元素符号
        elements_ratios = {}
        if total_atoms > 0:
            # 只保留在valid_elements集合中的元素
            elements_ratios = {elem: count / total_atoms for elem, count in element_counts.items() if elem in valid_elements}
        
        return elements_ratios
    except Exception as e:
        print(f"解析化学式 {formula} 时出错: {e}")
        return {}
    

def process_formulas_to_elements(formula_list):
    """
    处理化学式列表，提取所有元素并计算每行的元素比例
    使用formula_parser模块提供的函数进行解析，并验证元素符号的有效性
    """
    # 获取所有唯一的有效元素
    all_valid_elements = set()
    element_data = []
    
    # 处理每个化学式
    for formula in formula_list:
        if isinstance(formula, str):  # 确保是字符串
            try:
                # 使用formula_parser解析化学式
                element_counts = parse_formula(formula)
                total_atoms = sum(element_counts.values())
                
                # 计算比例，但只保留有效的元素符号
                elements_ratios = {}
                if total_atoms > 0:
                    # 只保留在valid_elements集合中的元素
                    elements_ratios = {elem: count / total_atoms for elem, count in element_counts.items() if elem in valid_elements}
                
                element_data.append(elements_ratios)
                # 添加到所有有效元素集合
                all_valid_elements.update(elements_ratios.keys())
            except Exception as e:
                print(f"处理化学式 {formula} 时出错: {e}")
                element_data.append({})
        else:
            element_data.append({})
    
    # 将元素集合转换为排序列表
    all_elements = sorted(list(all_valid_elements))
    
    # 创建结果DataFrame
    result_df = pd.DataFrame(index=range(len(formula_list)))
    
    # 为每个元素创建列，并填入比例值
    for element in all_elements:
        column_data = []
        for elements in element_data:
            # 如果元素存在则填入比例，否则填0
            column_data.append(elements.get(element, 0.0))
        result_df[element] = column_data
    
    # 添加原始化学式列
    result_df['Original_Formula'] = formula_list
    
    return result_df

def read_excel_file(file_path=None, column_name="alloy_composition_after_process"):
    """
    读取Excel文件并提取指定列的所有元素
    
    参数:
    file_path (str): Excel文件路径，如果为None则使用当前目录下的data_temp.xlsx
    column_name (str): 要提取的列名，默认为"alloy_composition_after_process"
    
    返回:
    tuple: (原始DataFrame, 指定列的数据列表)
    """
    # 获取脚本所在目录
    script_dir = _get_project_root()

    # 如果未指定文件路径，使用默认路径
    if file_path is None:
        file_path = os.path.join(script_dir, "data_temp.xlsx")
    else:
        # 处理相对路径
        if not os.path.isabs(file_path):
            # 先尝试在脚本所在目录查找
            script_relative_path = os.path.join(script_dir, file_path)
            if os.path.exists(script_relative_path):
                file_path = script_relative_path
            # 如果不存在，再尝试在当前工作目录查找
            current_dir_path = os.path.abspath(file_path)
            file_path = current_dir_path
    
    print(f"正在读取文件: {file_path}")
    
    # 直接读取Excel文件
    df = pd.read_excel(file_path)
    
    # 显示文件基本信息
    print(f"成功读取文件！")
    print(f"数据形状: {df.shape} (行, 列)")
    
    # 检查列名是否存在
    if column_name not in df.columns:
        raise ValueError(f"列名 '{column_name}' 不存在于文件中。可用的列名: {list(df.columns)}")
    
    print(f"\n处理的列名: {column_name}")
    
    # 获取指定列的所有元素
    column_data = df[column_name].tolist()
    
    print(f"\n指定列共有 {len(column_data)} 个元素")
    
    return df, column_data

def save_to_excel(df, file_path, overwrite=False, sheet_name='Sheet1', index=False):
    """
    将DataFrame保存到Excel文件
    
    参数:
    df (pd.DataFrame): 要保存的DataFrame
    file_path (str): 输出文件路径
    overwrite (bool): 是否覆盖已存在的文件
    sheet_name (str): Excel文件中的工作表名称，默认为'Sheet1'
    index (bool): 是否保存索引列，默认为False
    
    返回:
    bool: 保存是否成功
    """
    try:
        # 获取脚本所在目录
        script_dir = _get_project_root()

        # 处理相对路径
        if not os.path.isabs(file_path):
            file_path = os.path.join(script_dir, file_path)

        # 确保文件扩展名正确
        if not file_path.endswith(('.xlsx', '.xls')):
            file_path += '.xlsx'
        
        # 检查文件是否存在
        if os.path.exists(file_path) and not overwrite:
            # 创建新文件名，避免覆盖
            base_name, ext = os.path.splitext(file_path)
            counter = 1
            new_file_path = f"{base_name}_{counter}{ext}"
            while os.path.exists(new_file_path):
                counter += 1
                new_file_path = f"{base_name}_{counter}{ext}"
            file_path = new_file_path
            print(f"\n检测到文件已存在，将保存为新文件: {file_path}")
        
        # 确保目录存在
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        # 保存到Excel
        df.to_excel(file_path, sheet_name=sheet_name, index=index)
        print(f"\n成功保存到文件: {file_path}")
        print(f"  - 工作表名称: {sheet_name}")
        print(f"  - 数据形状: {df.shape} (行, 列)")
        
        # 同时保存为CSV文件
        csv_file_path = os.path.splitext(file_path)[0] + '.csv'
        df.to_csv(csv_file_path, index=index, encoding='utf-8-sig')
        print(f"成功保存到CSV文件: {csv_file_path}")
        
        return True
    except PermissionError:
        print(f"保存文件时出错: 没有写入权限到 {file_path}")
        print("尝试创建新的文件...")
        # 尝试创建新的文件
        try:
            base_name, ext = os.path.splitext(file_path)
            counter = 1
            new_file_path = f"{base_name}_new{counter}{ext}"
            while os.path.exists(new_file_path):
                counter += 1
                new_file_path = f"{base_name}_new{counter}{ext}"
            
            df.to_excel(new_file_path, sheet_name=sheet_name, index=index)
            print(f"成功保存到新文件: {new_file_path}")
            print(f"  - 工作表名称: {sheet_name}")
            print(f"  - 数据形状: {df.shape} (行, 列)")
            
            # 同时保存为CSV文件
            csv_file_path = os.path.splitext(new_file_path)[0] + '.csv'
            df.to_csv(csv_file_path, index=index, encoding='utf-8-sig')
            print(f"成功保存到CSV文件: {csv_file_path}")
            
            return True
        except Exception as inner_e:
            print(f"创建新文件时也出错: {str(inner_e)}")
            return False
    except ValueError as e:
        print(f"保存文件时出错: 数据格式问题 - {str(e)}")
        return False
    except Exception as e:
        print(f"保存文件时出错: {str(e)}")
        return False

def func(excel_file_path=None, column_name="alloy_composition_after_process", output_dir=None):
    print("读取Excel文件并提取指定列元素...")
    # 使用参数传入的excel文件路径，如果没有提供则使用默认值
    if excel_file_path is not None:
        # 定义局部变量以替代全局变量
        excel_file = excel_file_path
    else:
        # 如果没有提供参数，回退到全局变量（兼容原来的使用方式）
        excel_file = "exclude_non_metals_data.xlsx"  # 默认文件名

    try:
        # 读取原始数据
        df_original, formulas = read_excel_file(excel_file, column_name)
        
        # 移除测试化学式以避免生成不必要的列
        # 之前的代码会添加无效化学式，导致Excel中出现Element、Formula、Invalid、Nonexistent等列

        # 处理化学式，提取元素和比例
        print("\n开始处理化学式，提取元素和比例...")
        result_df = process_formulas_to_elements(formulas)

        # 显示处理结果信息
        element_columns = [col for col in result_df.columns if col != 'Original_Formula']
        print(f"\n成功提取了 {len(element_columns)} 种不同的元素:")
        print(", ".join(element_columns))

        # 删除旧的打印语句，将在final_df创建后添加

        # 确定输出文件路径
        script_dir = _get_project_root()
        
        # 使用指定的输出目录或默认目录
        if output_dir is None:
            results_dir = os.path.join(script_dir, "results", "data_descriptors")
        else:
            results_dir = output_dir
        os.makedirs(results_dir, exist_ok=True)
        
        if excel_file is None:
            output_path = os.path.join(results_dir, "data_temp.xlsx")
        else:
            # 为避免权限问题，总是创建新的输出文件名
            # 使用os.path.basename获取文件名，避免路径被包含在输出文件名中
            file_name = os.path.basename(excel_file)
            base_name, ext = os.path.splitext(file_name)
            output_path = os.path.join(results_dir, f"{base_name}_processed{ext}")
            # 确保文件名唯一
            counter = 1
            while os.path.exists(output_path):
                output_path = os.path.join(results_dir, f"{base_name}_processed_{counter}{ext}")
                counter += 1
            print(f"\n为避免权限问题，将输出保存到新文件: {os.path.basename(output_path)}")

        # 保留所有原始列，不覆盖
        final_df = df_original.copy()
        
        # 导入numpy用于处理NaN值
        import numpy as np
        
        # 添加elements列，存储每个化学式中包含的元素符号
        elements_list = []
        # 初始化平均沸点列表
        boiling_point_celsius_list = []
        boiling_point_kelvin_list = []
        boiling_point_fahrenheit_list = []
        # 初始化平均密度列表
        density_stp_kg_list = []
        density_stp_g_list = []
        density_liquid_kg_list = []
        density_liquid_g_list = []
        # 初始化平均电负性列表
        electronegativity_list = []
        # 初始化平均熔点列表
        melting_point_celsius_list = []
        melting_point_kelvin_list = []
        melting_point_fahrenheit_list = []
        # 初始化平均原子半径列表
        atomic_radius_calculated_list = []
        atomic_radius_empirical_list = []
        atomic_radius_covalent_list = []
        atomic_radius_vdw_list = []
        # 初始化硬度相关列表
        hardness_brinell_list = []
        hardness_mohs_list = []
        hardness_vickers_list = []
        # 初始化硬度标准差列表
        sigma_hardness_brinell_list = []
        sigma_hardness_mohs_list = []
        sigma_hardness_vickers_list = []
        # 初始化导热性和导电性列表
        thermal_conductivities_list = []
        electric_conductivities_list = []
        # 已删除导热性和导电性偏差列表初始化
        # 初始化平均剪切模量列表
        shear_modulus_list = []
        # 初始化剪切模量标准差列表
        shear_modulus_std_list = []
        # 初始化体积模量列表
        bulk_modulus_list = []
        # 初始化体积模量标准差列表
        bulk_modulus_std_list = []
        # 初始化杨氏模量列表
        young_modulus_list = []
        # 初始化杨氏模量标准差列表
        young_modulus_std_list = []
        # 初始化电负性差异列表
        delta_chi_list = []
        # 初始化混合熵列表
        mixing_entropy_list = []
        # 初始化混合焓列表
        mixing_enthalpy_list = []
        # 初始化混合焓标准差列表
        sigma_mixing_enthalpy_list = []
        # 初始化价电子浓度标准差列表
        sigma_vec_list = []
        # 初始化等效剪切模量偏差列表
        sigma_shear_list = []
        # 初始化电负性标准偏差列表
        std_electronegativity_list = []
        # 初始化熔点分散度列表
        sigma_Tm_list = []  # 开氏温度 (使用sigma_Tm_kelvin)
        sigma_Tm_celsius_list = []  # 摄氏温度
        sigma_Tm_fahrenheit_list = []  # 华氏温度
        # 初始化原子半径畸变量列表
        delta_r_empirical_list = []
        delta_r_calculated_list = []
        delta_r_covalent_list = []
        delta_r_vdw_list = []
        # 初始化λ参数列表
        lambda_empirical_list = []
        lambda_calculated_list = []
        lambda_covalent_list = []
        lambda_vdw_list = []
        # 新增lambda_descriptor相关列表
        lambda_descriptor_empirical_list = []
        lambda_descriptor_calculated_list = []
        lambda_descriptor_covalent_list = []
        lambda_descriptor_vdw_list = []
        # 初始化平均价电子浓度列表
        vec_list = []
        # 初始化价电子浓度加权偏差列表
        # 已删除delta_vec_list初始化
        # 初始化Ω参数列表（三个温度单位）
        omega_kelvin_list = []    # 开尔文温度
        omega_celsius_list = []   # 摄氏温度
        omega_fahrenheit_list = [] # 华氏温度
        # 初始化平均原子序数列表
        avg_atomic_number_list = []
        # 初始化平均第一电离能列表
        avg_first_ionization_ev_list = []
        avg_first_ionization_kjmol_list = []
        # 初始化新的描述符列表
        gamma_list = []
        phi_bcc_list = []
        phi_fcc_list = []
        psfe_list = []
        intermetallic_gibbs_list = []
        kappa1_list = []
        kappa1_critical_list = []
        
        for formula in formulas:
            if isinstance(formula, str):
                # 使用extract_elements_and_ratios函数提取元素
                elements = extract_elements_and_ratios(formula)
                # 获取元素符号列表并排序
                element_symbols = sorted(list(elements.keys()))
                # 格式化为用方括号括起来的逗号分隔字符串
                elements_str = '[' + ','.join(element_symbols) + ']'
                elements_list.append(elements_str)
                
                # 计算平均沸点（摄氏度）
                boiling_point_c = average_boiling_point_celsius(formula)
                boiling_point_celsius_list.append(boiling_point_c)
                
                # 计算平均沸点（开尔文）
                boiling_point_k = average_boiling_point_kelvin(formula)
                boiling_point_kelvin_list.append(boiling_point_k)
                
                # 计算平均沸点（华氏度）
                boiling_point_f = average_boiling_point_fahrenheit(formula)
                boiling_point_fahrenheit_list.append(boiling_point_f)
                
                # 计算平均密度（STP条件下，kg/m³）
                try:
                    density_stp_kg = average_density_stp_kg(formula)
                except Exception:
                    density_stp_kg = None
                density_stp_kg_list.append(density_stp_kg)
                
                # 计算平均密度（STP条件下，g/cm³）
                try:
                    density_stp_g = average_density_stp_g(formula)
                except Exception:
                    density_stp_g = None
                density_stp_g_list.append(density_stp_g)
                
                # 计算平均密度（液态下，kg/m³）
                try:
                    density_liquid_kg = average_density_liquid_kg(formula)
                except Exception:
                    density_liquid_kg = None
                density_liquid_kg_list.append(density_liquid_kg)
                
                # 计算平均密度（液态下，g/cm³）
                try:
                    density_liquid_g = average_density_liquid_g(formula)
                except Exception:
                    density_liquid_g = None
                density_liquid_g_list.append(density_liquid_g)
                
                # 计算平均电负性
                try:
                    electronegativity = average_electronegativity(formula)
                except Exception:
                    electronegativity = None
                electronegativity_list.append(electronegativity)
                
                # 计算平均熔点（摄氏度）
                try:
                    melting_point_c = average_melting_point_celsius(formula)
                except Exception:
                    melting_point_c = None
                melting_point_celsius_list.append(melting_point_c)
                
                # 计算平均熔点（开尔文）
                try:
                    melting_point_k = average_melting_point_kelvin(formula)
                except Exception:
                    melting_point_k = None
                melting_point_kelvin_list.append(melting_point_k)
                
                # 计算平均熔点（华氏度）
                try:
                    melting_point_f = average_melting_point_fahrenheit(formula)
                except Exception:
                    melting_point_f = None
                melting_point_fahrenheit_list.append(melting_point_f)
                
                # 计算平均原子半径（计算半径）
                try:
                    atomic_radius_calculated = average_atomic_radius_calculated(formula)
                except Exception:
                    atomic_radius_calculated = None
                atomic_radius_calculated_list.append(atomic_radius_calculated)
                
                # 计算平均原子半径（经验半径）
                try:
                    atomic_radius_empirical = average_atomic_radius_empirical(formula)
                except Exception:
                    atomic_radius_empirical = None
                atomic_radius_empirical_list.append(atomic_radius_empirical)
                
                # 计算平均原子半径（共价半径）
                try:
                    atomic_radius_covalent = average_atomic_radius_covalent(formula)
                except Exception:
                    atomic_radius_covalent = None
                atomic_radius_covalent_list.append(atomic_radius_covalent)
                
                # 计算平均原子半径（范德华半径）
                try:
                    atomic_radius_vdw = average_atomic_radius_vanderWaals(formula)
                except Exception:
                    atomic_radius_vdw = None
                atomic_radius_vdw_list.append(atomic_radius_vdw)
                
                # 计算平均剪切模量
                try:
                    shear_modulus = average_shear_modulus(formula)
                except Exception:
                    shear_modulus = None
                shear_modulus_list.append(shear_modulus)
                
                # 计算剪切模量标准差
                try:
                    shear_modulus_std_value = shear_modulus_std(formula)
                except Exception:
                    shear_modulus_std_value = None
                shear_modulus_std_list.append(shear_modulus_std_value)
                
                # 计算杨氏模量
                try:
                    young_modulus_value = average_young_modulus(formula)
                except Exception:
                    young_modulus_value = None
                young_modulus_list.append(young_modulus_value)
                
                # 计算杨氏模量标准差
                try:
                    young_modulus_std_value = young_modulus_std(formula)
                except Exception:
                    young_modulus_std_value = None
                young_modulus_std_list.append(young_modulus_std_value)
                
                # 计算体积模量标准差
                try:
                    # 计算平均体积模量
                    bulk_mod_value = average_bulk_modulus(formula)
                except Exception:
                    bulk_mod_value = None
                bulk_modulus_list.append(bulk_mod_value)
                
                try:
                    bulk_mod_std_value = bulk_modulus_std(formula)
                except Exception:
                    bulk_mod_std_value = None
                bulk_modulus_std_list.append(bulk_mod_std_value)
                
                # 计算混合熵
                try:
                    mixing_entropy_value = mixing_entropy(formula)
                    # 如果结果是字符串且以"错误: "开头，则设为None
                    if isinstance(mixing_entropy_value, str) and mixing_entropy_value.startswith('错误: '):
                        mixing_entropy_value = None
                    # 如果是数字，确保是浮点数
                    elif isinstance(mixing_entropy_value, (int, float)):
                        mixing_entropy_value = float(mixing_entropy_value)
                except Exception:
                    mixing_entropy_value = None
                mixing_entropy_list.append(mixing_entropy_value)
                
                # 计算混合焓
                try:
                    mixing_enthalpy_value = mixing_enthalpy(formula)
                    # 确保是浮点数
                    if isinstance(mixing_enthalpy_value, (int, float)):
                        mixing_enthalpy_value = float(mixing_enthalpy_value)
                except Exception:
                    mixing_enthalpy_value = None
                mixing_enthalpy_list.append(mixing_enthalpy_value)
                
                # 计算混合焓标准差
                try:
                    sigma_mixing_enthalpy_value = sigma_mixing_enthalpy(formula)
                    # 确保是浮点数
                    if isinstance(sigma_mixing_enthalpy_value, (int, float)):
                        sigma_mixing_enthalpy_value = float(sigma_mixing_enthalpy_value)
                except Exception:
                    sigma_mixing_enthalpy_value = None
                sigma_mixing_enthalpy_list.append(sigma_mixing_enthalpy_value)
                
                # 计算等效剪切模量偏差
                try:
                    sigma_shear_value = sigma_shear(formula)
                    # 如果结果是字符串且以"错误: "开头，则设为None
                    if isinstance(sigma_shear_value, str) and sigma_shear_value.startswith('错误: '):
                        sigma_shear_value = None
                    # 如果是数字，确保是浮点数
                    elif isinstance(sigma_shear_value, (int, float)):
                        sigma_shear_value = float(sigma_shear_value)
                except Exception:
                    sigma_shear_value = None
                sigma_shear_list.append(sigma_shear_value)
                
                # 计算电负性标准偏差
                try:
                    std_electronegativity_value = std_electronegativity(formula)
                except Exception:
                    std_electronegativity_value = None
                std_electronegativity_list.append(std_electronegativity_value)
                
                # 计算熔点分散度（开氏温度）
                try:
                    sigma_Tm_value = sigma_Tm_kelvin(formula)  # 直接使用开氏温度函数
                    # 如果结果是字符串且以"错误: "开头，则设为None
                    if isinstance(sigma_Tm_value, str) and sigma_Tm_value.startswith('错误: '):
                        sigma_Tm_value = None
                    # 如果是数字，确保是浮点数
                    elif isinstance(sigma_Tm_value, (int, float)):
                        sigma_Tm_value = float(sigma_Tm_value)
                except Exception:
                    sigma_Tm_value = None
                sigma_Tm_list.append(sigma_Tm_value)
                
                # 计算熔点分散度（摄氏温度）
                try:
                    sigma_Tm_c_value = sigma_Tm_celsius(formula)
                    # 如果结果是字符串且以"错误: "开头，则设为None
                    if isinstance(sigma_Tm_c_value, str) and sigma_Tm_c_value.startswith('错误: '):
                        sigma_Tm_c_value = None
                    # 如果是数字，确保是浮点数
                    elif isinstance(sigma_Tm_c_value, (int, float)):
                        sigma_Tm_c_value = float(sigma_Tm_c_value)
                except Exception:
                    sigma_Tm_c_value = None
                sigma_Tm_celsius_list.append(sigma_Tm_c_value)
                
                # 计算熔点分散度（华氏温度）
                try:
                    sigma_Tm_f_value = sigma_Tm_fahrenheit(formula)
                    # 如果结果是字符串且以"错误: "开头，则设为None
                    if isinstance(sigma_Tm_f_value, str) and sigma_Tm_f_value.startswith('错误: '):
                        sigma_Tm_f_value = None
                    # 如果是数字，确保是浮点数
                    elif isinstance(sigma_Tm_f_value, (int, float)):
                        sigma_Tm_f_value = float(sigma_Tm_f_value)
                except Exception:
                    sigma_Tm_f_value = None
                sigma_Tm_fahrenheit_list.append(sigma_Tm_f_value)
                
                try:
                    # 计算电负性差异
                    delta_chi_value = delta_chi(formula)
                    # 如果结果是字符串且以"[错误]"开头，则设为None
                    if isinstance(delta_chi_value, str) and delta_chi_value.startswith('[错误]'):
                        delta_chi_value = None
                    # 如果是数字字符串，尝试转换为浮点数
                    elif isinstance(delta_chi_value, str) and delta_chi_value.replace('.', '', 1).isdigit():
                        delta_chi_value = float(delta_chi_value)
                except Exception:
                    delta_chi_value = None
                delta_chi_list.append(delta_chi_value)
                
                # 计算原子半径畸变量(基于经验半径)
                try:
                    r_empirical_result = delta_r_radius_empirical(formula)
                    if isinstance(r_empirical_result, str) and r_empirical_result.startswith('[错误]'):
                        delta_r_empirical_value = None
                    else:
                        delta_r_empirical_value = float(r_empirical_result)
                except Exception:
                    delta_r_empirical_value = None
                delta_r_empirical_list.append(delta_r_empirical_value)
                
                # 计算原子半径畸变量(基于计算半径)
                try:
                    r_calculated_result = delta_r_radius_calculated(formula)
                    if isinstance(r_calculated_result, str) and r_calculated_result.startswith('[错误]'):
                        delta_r_calculated_value = None
                    else:
                        delta_r_calculated_value = float(r_calculated_result)
                except Exception:
                    delta_r_calculated_value = None
                delta_r_calculated_list.append(delta_r_calculated_value)
                
                # 计算原子半径畸变量(基于共价半径)
                try:
                    r_covalent_result = delta_r_radius_covalent(formula)
                    if isinstance(r_covalent_result, str) and r_covalent_result.startswith('[错误]'):
                        delta_r_covalent_value = None
                    else:
                        delta_r_covalent_value = float(r_covalent_result)
                except Exception:
                    delta_r_covalent_value = None
                delta_r_covalent_list.append(delta_r_covalent_value)
                
                # 计算原子半径畸变量(基于范德华半径)
                try:
                    r_vdw_result = delta_r_radius_vanderWaals(formula)
                    if isinstance(r_vdw_result, str) and r_vdw_result.startswith('[错误]'):
                        delta_r_vdw_value = None
                    else:
                        delta_r_vdw_value = float(r_vdw_result)
                except Exception:
                    delta_r_vdw_value = None
                delta_r_vdw_list.append(delta_r_vdw_value)
                
                # 计算λ参数(基于经验半径) - 使用lambda_parameter模块
                try:
                    lambda_empirical_value = lambda_parameter_empirical(formula)
                except Exception:
                    lambda_empirical_value = None
                lambda_empirical_list.append(lambda_empirical_value)
                
                # 计算λ参数(基于计算半径) - 使用lambda_parameter模块
                try:
                    lambda_calculated_value = lambda_parameter_calculated(formula)
                except Exception:
                    lambda_calculated_value = None
                lambda_calculated_list.append(lambda_calculated_value)
                
                # 计算λ参数(基于共价半径) - 使用lambda_parameter模块
                try:
                    lambda_covalent_value = lambda_parameter_covalent(formula)
                except Exception:
                    lambda_covalent_value = None
                lambda_covalent_list.append(lambda_covalent_value)
                
                # 计算λ参数(基于范德华半径) - 使用lambda_parameter模块
                try:
                    lambda_vdw_value = lambda_parameter_vanderWaals(formula)
                except Exception:
                    lambda_vdw_value = None
                lambda_vdw_list.append(lambda_vdw_value)
                
                # 计算lambda_descriptor参数(基于经验半径) - 使用lambda_parameter模块
                try:
                    lambda_descriptor_empirical_value = lambda_parameter_empirical(formula)
                except Exception:
                    lambda_descriptor_empirical_value = None
                lambda_descriptor_empirical_list.append(lambda_descriptor_empirical_value)
                
                # 计算lambda_descriptor参数(基于计算半径) - 使用lambda_parameter模块
                try:
                    lambda_descriptor_calculated_value = lambda_parameter_calculated(formula)
                except Exception:
                    lambda_descriptor_calculated_value = None
                lambda_descriptor_calculated_list.append(lambda_descriptor_calculated_value)
                
                # 计算lambda_descriptor参数(基于共价半径) - 使用lambda_parameter模块
                try:
                    lambda_descriptor_covalent_value = lambda_parameter_covalent(formula)
                except Exception:
                    lambda_descriptor_covalent_value = None
                lambda_descriptor_covalent_list.append(lambda_descriptor_covalent_value)
                
                # 计算lambda_descriptor参数(基于范德华半径) - 使用lambda_parameter模块
                try:
                    lambda_descriptor_vdw_value = lambda_parameter_vanderWaals(formula)
                except Exception:
                    lambda_descriptor_vdw_value = None
                lambda_descriptor_vdw_list.append(lambda_descriptor_vdw_value)
                
                # 计算布氏硬度
                try:
                    hardness_brinell_value = average_hardness_brinell(formula)
                except Exception:
                    hardness_brinell_value = None
                hardness_brinell_list.append(hardness_brinell_value)
                
                # 计算莫氏硬度
                try:
                    hardness_mohs_value = average_hardness_mohs(formula)
                except Exception:
                    hardness_mohs_value = None
                hardness_mohs_list.append(hardness_mohs_value)
                
                # 计算维氏硬度
                try:
                    hardness_vickers_value = average_hardness_vickers(formula)
                except Exception:
                    hardness_vickers_value = None
                hardness_vickers_list.append(hardness_vickers_value)
                
                # 计算布氏硬度加权偏差
                try:
                    sigma_brinell_value = sigma_hardness_brinell(formula)
                except Exception:
                    sigma_brinell_value = None
                sigma_hardness_brinell_list.append(sigma_brinell_value)
                
                # 计算莫氏硬度标准差
                try:
                    sigma_mohs_value = sigma_hardness_mohs(formula)
                except Exception:
                    sigma_mohs_value = None
                sigma_hardness_mohs_list.append(sigma_mohs_value)
                
                # 计算维氏硬度标准差
                try:
                    sigma_vickers_value = sigma_hardness_vickers(formula)
                except Exception:
                    sigma_vickers_value = None
                sigma_hardness_vickers_list.append(sigma_vickers_value)
                
                # 计算导热性
                try:
                    thermal_conductivity_value = average_thermal_conductivity(formula)
                except Exception:
                    thermal_conductivity_value = None
                thermal_conductivities_list.append(thermal_conductivity_value)
                
                # 计算导电性
                try:
                    electric_conductivity_value = average_electric_conductivity(formula)
                except Exception:
                    electric_conductivity_value = None
                electric_conductivities_list.append(electric_conductivity_value)
                
                # 已删除导热性和导电性偏差计算
                
                # 计算平均价电子浓度
                try:
                    vec_value = average_vec(formula)
                except Exception:
                    vec_value = None
                vec_list.append(vec_value)
                
                # 计算价电子浓度标准差
                try:
                    sigma_vec_value = calculate_sigma_vec(formula)
                    # 确保是浮点数
                    if isinstance(sigma_vec_value, (int, float)):
                        sigma_vec_value = float(sigma_vec_value)
                except Exception:
                    sigma_vec_value = None
                sigma_vec_list.append(sigma_vec_value)
                
                # 已删除价电子浓度加权偏差计算
                
                # 计算Ω参数（开尔文温度）
                try:
                    omega_kelvin_value = calculate_omega_kelvin(formula)
                except Exception:
                    omega_kelvin_value = None
                omega_kelvin_list.append(omega_kelvin_value)
                
                # 计算Ω参数（摄氏温度）
                try:
                    omega_celsius_value = calculate_omega_celsius(formula)
                except Exception:
                    omega_celsius_value = None
                omega_celsius_list.append(omega_celsius_value)
                
                # 计算Ω参数（华氏温度）
                try:
                    omega_fahrenheit_value = calculate_omega_fahrenheit(formula)
                except Exception:
                    omega_fahrenheit_value = None
                omega_fahrenheit_list.append(omega_fahrenheit_value)
                
                # 计算平均原子序数
                try:
                    avg_atomic_number_value = average_atomic_number(formula)
                except Exception:
                    avg_atomic_number_value = None
                avg_atomic_number_list.append(avg_atomic_number_value)
                
                # 计算平均第一电离能（eV）
                try:
                    avg_first_ionization_ev_value = average_first_ionization_ev(formula)
                except Exception:
                    avg_first_ionization_ev_value = None
                avg_first_ionization_ev_list.append(avg_first_ionization_ev_value)
                
                # 计算平均第一电离能（kJ/mol）
                try:
                    avg_first_ionization_kjmol_value = average_first_ionization_kjmol(formula)
                except Exception:
                    avg_first_ionization_kjmol_value = None
                avg_first_ionization_kjmol_list.append(avg_first_ionization_kjmol_value)
                
                # 计算新的描述符
                # 计算晶格畸变参数γ
                try:
                    gamma_value = calculate_gamma(formula)
                except Exception:
                    gamma_value = None
                gamma_list.append(gamma_value)
                
                # 计算相竞争参数φ(ξ)
                try:
                    phi_bcc_value = calculate_phi(formula, structure='bcc')
                except Exception:
                    phi_bcc_value = None
                phi_bcc_list.append(phi_bcc_value)
                
                try:
                    phi_fcc_value = calculate_phi(formula, structure='fcc')
                except Exception:
                    phi_fcc_value = None
                phi_fcc_list.append(phi_fcc_value)
                
                # 计算σ相形成对参数PSFE
                try:
                    psfe_value = calculate_psfe(formula)
                except Exception:
                    psfe_value = None
                psfe_list.append(psfe_value)
                
                # 计算金属间相形成吉布斯自由能ΔG^{ic}
                try:
                    intermetallic_gibbs_value = intermetallic_gibbs(formula)
                except Exception:
                    intermetallic_gibbs_value = None
                intermetallic_gibbs_list.append(intermetallic_gibbs_value)
                
                # 计算相竞争参数κ1和κ1^{cr}(T)
                try:
                    kappa1_value = kappa1(formula)
                except Exception:
                    kappa1_value = None
                kappa1_list.append(kappa1_value)
                
                try:
                    kappa1_critical_value = kappa1_critical(formula)
                except Exception:
                    kappa1_critical_value = None
                kappa1_critical_list.append(kappa1_critical_value)
            else:
                elements_list.append('')
                boiling_point_celsius_list.append(None)
                boiling_point_kelvin_list.append(None)
                boiling_point_fahrenheit_list.append(None)
                density_stp_kg_list.append(None)
                density_stp_g_list.append(None)
                density_liquid_kg_list.append(None)
                density_liquid_g_list.append(None)
                electronegativity_list.append(None)
                melting_point_celsius_list.append(None)
                melting_point_kelvin_list.append(None)
                melting_point_fahrenheit_list.append(None)
                atomic_radius_calculated_list.append(None)
                
                # 添加lambda_descriptor相关的None值
                lambda_descriptor_empirical_list.append(None)
                lambda_descriptor_calculated_list.append(None)
                lambda_descriptor_covalent_list.append(None)
                lambda_descriptor_vdw_list.append(None)
                atomic_radius_empirical_list.append(None)
                atomic_radius_covalent_list.append(None)
                atomic_radius_vdw_list.append(None)
                shear_modulus_list.append(None)
                shear_modulus_std_list.append(None)
                bulk_modulus_list.append(None)
                bulk_modulus_std_list.append(None)
                young_modulus_list.append(None)
                young_modulus_std_list.append(None)
                delta_chi_list.append(None)
                mixing_entropy_list.append(None)
                mixing_enthalpy_list.append(None)
                sigma_mixing_enthalpy_list.append(None)
                delta_r_empirical_list.append(None)
                delta_r_calculated_list.append(None)
                delta_r_covalent_list.append(None)
                delta_r_vdw_list.append(None)
                lambda_empirical_list.append(None)
                lambda_calculated_list.append(None)
                lambda_covalent_list.append(None)
                lambda_vdw_list.append(None)
                sigma_shear_list.append(None)
                std_electronegativity_list.append(None)
                sigma_Tm_list.append(None)
                hardness_brinell_list.append(None)
                hardness_mohs_list.append(None)
                hardness_vickers_list.append(None)
                # 添加硬度加权偏差的None值
                sigma_hardness_brinell_list.append(None)
                sigma_hardness_mohs_list.append(None)
                sigma_hardness_vickers_list.append(None)
                # 添加导热性和导电性的None值
                thermal_conductivities_list.append(None)
                electric_conductivities_list.append(None)
                # 添加平均价电子浓度的None值
                vec_list.append(None)
                sigma_vec_list.append(None)
                # 添加价电子浓度加权偏差的None值
                # delta_vec_list.append(None)
                # 添加Ω参数的None值（三个温度单位）
                omega_kelvin_list.append(None)
                omega_celsius_list.append(None)
                omega_fahrenheit_list.append(None)
                # 添加平均原子序数的None值
                avg_atomic_number_list.append(None)
                # 添加平均第一电离能的None值
                avg_first_ionization_ev_list.append(None)
                avg_first_ionization_kjmol_list.append(None)
                # 添加新描述符的None值
                gamma_list.append(None)
                phi_bcc_list.append(None)
                phi_fcc_list.append(None)
                psfe_list.append(None)
                intermetallic_gibbs_list.append(None)
                kappa1_list.append(None)
                kappa1_critical_list.append(None)
        
        # 保存其他原始列，稍后添加到末尾
        other_original_columns = df_original.columns[1:].tolist()  # 除了第一列外的其他原始列
        
        # 创建新的DataFrame，只包含指定的列（化学式列）
        first_column_name = column_name
        final_df = pd.DataFrame()
        final_df[first_column_name] = df_original[first_column_name]
        
        # 添加elements列到第一列后面
        final_df['elements'] = elements_list

        # 添加所有元素比例列
        for element in element_columns:
            final_df[element] = result_df[element]
        
        # 添加平均沸点列（移到后面）
        final_df['average_boiling_point_celsius'] = boiling_point_celsius_list
        final_df['average_boiling_point_kelvin'] = boiling_point_kelvin_list
        final_df['average_boiling_point_fahrenheit'] = boiling_point_fahrenheit_list
        
        # 添加平均密度列，并确保None值正确显示
        final_df['average_density_stp_kg_m3'] = density_stp_kg_list
        final_df['average_density_stp_g_cm3'] = density_stp_g_list
        final_df['average_density_liquid_kg_m3'] = density_liquid_kg_list
        final_df['average_density_liquid_g_cm3'] = density_liquid_g_list
        
        # 添加平均电负性列
        final_df['average_electronegativity'] = electronegativity_list
        
        # 添加平均熔点列
        final_df['average_melting_point_celsius'] = melting_point_celsius_list
        final_df['average_melting_point_kelvin'] = melting_point_kelvin_list
        final_df['average_melting_point_fahrenheit'] = melting_point_fahrenheit_list
        
        # 添加平均原子半径列
        final_df['average_atomic_radius_calculated'] = atomic_radius_calculated_list
        final_df['average_atomic_radius_empirical'] = atomic_radius_empirical_list
        final_df['average_atomic_radius_covalent'] = atomic_radius_covalent_list
        final_df['average_atomic_radius_vanderWaals'] = atomic_radius_vdw_list
        
        # 添加平均剪切模量列
        final_df['average_shear_modulus'] = shear_modulus_list
        # 添加剪切模量标准差列
        final_df['shear_modulus_std'] = shear_modulus_std_list
        # 添加平均体积模量列
        final_df['average_bulk_modulus'] = bulk_modulus_list
        # 添加体积模量标准差列
        final_df['bulk_modulus_std'] = bulk_modulus_std_list
        # 添加杨氏模量列
        final_df['average_young_modulus'] = young_modulus_list
        # 添加杨氏模量标准差列
        final_df['young_modulus_std'] = young_modulus_std_list
        # 添加电负性差异列
        final_df['delta_chi'] = delta_chi_list
        # 添加混合熵列
        final_df['mixing_entropy'] = mixing_entropy_list
        # 添加混合焓列
        final_df['mixing_enthalpy'] = mixing_enthalpy_list
        final_df['sigma_mixing_enthalpy'] = sigma_mixing_enthalpy_list
        # 添加等效剪切模量偏差列
        final_df['sigma_shear'] = sigma_shear_list
        # 添加电负性标准偏差列
        final_df['std_electronegativity'] = std_electronegativity_list
        # 添加熔点分散度列（三个温度单位）
        final_df['sigma_Tm_kelvin'] = sigma_Tm_list  # 开氏温度
        final_df['sigma_Tm_celsius'] = sigma_Tm_celsius_list  # 摄氏温度
        final_df['sigma_Tm_fahrenheit'] = sigma_Tm_fahrenheit_list  # 华氏温度
        # 添加原子半径畸变量列
        final_df['delta_r_empirical'] = delta_r_empirical_list
        final_df['delta_r_calculated'] = delta_r_calculated_list
        final_df['delta_r_covalent'] = delta_r_covalent_list
        final_df['delta_r_vdw'] = delta_r_vdw_list
        # 添加λ参数列
        final_df['lambda_empirical'] = lambda_empirical_list
        final_df['lambda_calculated'] = lambda_calculated_list
        final_df['lambda_covalent'] = lambda_covalent_list
        final_df['lambda_vdw'] = lambda_vdw_list

        # 添加硬度相关列
        final_df['average_hardness_brinell'] = hardness_brinell_list
        final_df['average_hardness_mohs'] = hardness_mohs_list
        final_df['average_hardness_vickers'] = hardness_vickers_list

        # 添加导热性和导电性列
        final_df['average_thermal_conductivity'] = thermal_conductivities_list
        final_df['average_electric_conductivity'] = electric_conductivities_list
        # 已删除导热性和导电性偏差列
        # 添加硬度标准差列
        final_df['sigma_hardness_brinell'] = sigma_hardness_brinell_list
        final_df['sigma_hardness_mohs'] = sigma_hardness_mohs_list
        final_df['sigma_hardness_vickers'] = sigma_hardness_vickers_list
        
        # 添加平均价电子浓度列
        final_df['average_vec'] = vec_list
        # 已删除价电子浓度加权偏差列
        final_df['sigma_vec'] = sigma_vec_list
        # 添加Ω参数列（三个温度单位）
        final_df['omega_parameter_kelvin'] = omega_kelvin_list
        final_df['omega_parameter_celsius'] = omega_celsius_list
        final_df['omega_parameter_fahrenheit'] = omega_fahrenheit_list
        # 添加平均原子序数列
        final_df['average_atomic_number'] = avg_atomic_number_list
        # 添加平均第一电离能列
        final_df['average_first_ionization_ev'] = avg_first_ionization_ev_list
        final_df['average_first_ionization_kjmol'] = avg_first_ionization_kjmol_list
        # 添加新的描述符列
        final_df['gamma'] = gamma_list
        final_df['phi_bcc'] = phi_bcc_list
        final_df['phi_fcc'] = phi_fcc_list
        final_df['psfe'] = psfe_list
        final_df['intermetallic_gibbs'] = intermetallic_gibbs_list
        final_df['kappa1'] = kappa1_list
        final_df['kappa1_critical'] = kappa1_critical_list
        
        # 将其他原始列添加到末尾
        for col in other_original_columns:
            final_df[col] = df_original[col]
        
        # 将None和NaN值转换为字符串"None"以确保在Excel中正确显示
        print("\n处理None和NaN值，转换为字符串'None'...")
        for col in final_df.columns:
            # 将列转换为object类型
            final_df[col] = final_df[col].astype(object)
            # 替换None和NaN为字符串"None"
            final_df[col] = final_df[col].apply(lambda x: "None" if x is None or (isinstance(x, float) and np.isnan(x)) else x)
        
        print("None值处理完成，所有计算失败的密度值将在Excel中显示为'None'")

        # 显示前几行结果作为示例
        print("\n处理结果示例 (前5行):")
        # 显示原始化学式、elements列和所有新增的物理性质列
        columns_to_display = [column_name, 'elements', 
                             'average_boiling_point_celsius', 'average_boiling_point_kelvin', 'average_boiling_point_fahrenheit',
                             'average_density_stp_kg_m3', 'average_density_stp_g_cm3', 'average_density_liquid_kg_m3', 'average_density_liquid_g_cm3',
                             'average_electronegativity', 'std_electronegativity',
                             'average_melting_point_celsius', 'average_melting_point_kelvin', 'average_melting_point_fahrenheit',
                             'average_atomic_radius_calculated', 'average_atomic_radius_empirical', 'average_atomic_radius_covalent', 'average_atomic_radius_vanderWaals',
                             'average_shear_modulus', 'shear_modulus_std',
                             'average_bulk_modulus', 'bulk_modulus_std',
                             'average_young_modulus', 'young_modulus_std',
                             'mixing_entropy',
                             'mixing_enthalpy',
                             'sigma_shear',
                             'sigma_Tm_kelvin', 'sigma_Tm_celsius', 'sigma_Tm_fahrenheit',
                             'average_hardness_brinell', 
                             'average_hardness_mohs', 
                             'average_hardness_vickers', 
                             'sigma_hardness_brinell',
                             'sigma_hardness_mohs',
                             'sigma_hardness_vickers',
                             'average_thermal_conductivity', 'average_electric_conductivity',

                             'average_vec',
                             'omega_parameter_kelvin',
                             'omega_parameter_celsius',
                             'omega_parameter_fahrenheit',
                             'average_atomic_number',
                             'average_first_ionization_ev',
                             'average_first_ionization_kjmol']
        print(final_df[columns_to_display].head())
        
        # 保存结果
        # 设置overwrite=True以覆盖已存在的文件，并指定更描述性的工作表名称
        save_to_excel(final_df, output_path, overwrite=True, sheet_name='元素分析结果')
        
        print("\n处理完成！")
        return final_df

    except Exception as e:
        print(f"\n处理过程中出错: {str(e)}")
        print("请确保输入文件存在，且指定的列包含有效的化学式数据。")
# 直接运行时执行
def find_latest_excel_file():
    """
    在data_pre-processing目录中查找时间戳最近的Excel文件
    """
    import glob
    
    # 获取脚本所在目录
    script_dir = _get_project_root()

    # 构建data_pre-processing目录路径
    data_preprocessing_dir = os.path.join(script_dir, "results", "data_pre-processing")
    
    # 检查目录是否存在
    if not os.path.exists(data_preprocessing_dir):
        print(f"错误: 未找到目录 {data_preprocessing_dir}")
        return None
    
    # 查找所有Excel文件
    excel_patterns = ["*.xlsx", "*.xls", "*.xlsm"]
    excel_files = []
    
    for pattern in excel_patterns:
        excel_files.extend(glob.glob(os.path.join(data_preprocessing_dir, pattern)))
    
    if not excel_files:
        print(f"在 {data_preprocessing_dir} 目录中未找到Excel文件")
        return None
    
    # 根据修改时间排序，获取最新的文件
    latest_file = max(excel_files, key=os.path.getmtime)
    print(f"找到最新的Excel文件: {latest_file}")
    return latest_file


def run(args=None):
    if args is None:
        parser = argparse.ArgumentParser(description='Process alloy composition data and calculate physical property parameters.')
        parser.add_argument('-i', '--input', dest='input_file', required=False,
                            help='Path to the input Excel file')
        parser.add_argument('-o', '--output', dest='output_dir', default=None,
                            help='Directory to save the processed file (default: results/data_descriptors)')
        parser.add_argument('-c', '--column', dest='column_name', default='alloy_composition_after_process',
                            help='Name of the column containing alloy composition (default: alloy_composition_after_process)')
        args = parser.parse_args()

    input_file = args.input_file
    output_dir = args.output_dir
    column_name = args.column_name

    if input_file is None:
        if len(sys.argv) >= 2:
            input_file = sys.argv[1]
            if len(sys.argv) == 3:
                column_name = sys.argv[2]
        else:
            print("未提供命令行参数，自动查找data_pre-processing目录下最新的Excel文件...")
            input_file = find_latest_excel_file()

            if input_file is None:
                print("无法找到Excel文件，请提供命令行参数或确保data_pre-processing目录中有Excel文件")
                sys.exit(1)

            print(f"使用默认列名: '{column_name}'")
    else:
        print(f"使用指定列名: '{column_name}'")

    if not os.path.exists(input_file):
        print(f"Error: Input file '{input_file}' does not exist.")
        sys.exit(1)

    if not input_file.endswith('.xlsx'):
        print(f"Error: Input file must be an Excel file with .xlsx extension.")
        sys.exit(1)

    if output_dir is not None:
        if not os.path.exists(output_dir):
            try:
                os.makedirs(output_dir, exist_ok=True)
                print(f"Created output directory: {output_dir}")
            except Exception as e:
                print(f"Error creating output directory: {e}")
                sys.exit(1)
        if not os.path.isdir(output_dir):
            print(f"Error: Output path '{output_dir}' is not a directory.")
            sys.exit(1)

    try:
        func(input_file, column_name, output_dir)
    except Exception as e:
        print(f"Error processing file: {e}")
        sys.exit(1)


if __name__ == "__main__":
    run()