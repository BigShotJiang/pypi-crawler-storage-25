# -*- coding: utf-8 -*-
"""
描述性数据清理和分析脚本
==========================

功能说明：
- 自动查找data_descriptors目录下最新的Excel文件
- 智能删除空行（基于数据完整性规则）
- 统计包含None/NaN值的列
- 分析可能存在单位换算关系的特征
- 三种特征列处理模型：自动化处理、确定必须保存的列、确定需要删除的列
- 化学元素列处理：默认保留化学元素列，可通过参数设置删除
- 实现符合科学研究的自动化处理流程，确保数据无缺失值
- 生成详细的描述性分析报告并保存到descript_data_clean目录
- 生成高质量的描述性数据可视化图片
- 同时保存数据为Excel和CSV格式

使用方法：
1. 直接运行（自动处理data_descriptors目录下最新的Excel文件）：
   python descript_data_clean.py

2. 删除化学元素列：
   python descript_data_clean.py --delete-elements

3. 指定输入文件：
   python descript_data_clean.py -i path/to/your/file.xlsx

4. 组合使用：
   python descript_data_clean.py -i path/to/file.xlsx --delete-elements

注意：
- 输入文件来自 'results/data_descriptors' 目录下最新的Excel文件
- 输出的日志文件将保存在 'results/logs' 目录下
- 清理后的数据将保存到 'results/descript_data_clean' 目录下（同时保存为Excel和CSV格式）
- 详细的统计信息将保存到 'results/descript_data_clean/analysis' 目录下（同时保存为Excel和CSV格式）
- 可视化图片将保存到 'results/descript_data_clean/visualization' 目录下
- 智能空行删除规则：删除所有列都是NaN的行，以及超过50%列是NaN的行
- 自动化处理流程将确保数据无缺失值，可直接用于机器学习模型
- 化学元素列默认保留，使用 --delete-elements 参数可删除
"""

import os
import sys
import argparse
import pandas as pd
import numpy as np
import datetime
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import rcParams

from .engineer.element_utils import get_element_columns, is_element_column


def _get_project_root():
    return os.getcwd()

plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.style.use('seaborn-v0_8-whitegrid')

rcParams['figure.figsize'] = 12, 8
rcParams['figure.dpi'] = 150

def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description='描述性数据清理和分析脚本',
        epilog='''
使用示例:
    # 运行默认设置（保留化学元素列）
    python descript_data_clean.py
    
    # 删除化学元素列
    python descript_data_clean.py --delete-elements
    
    # 指定输入文件
    python descript_data_clean.py -i path/to/your/file.xlsx
    
    # 组合使用
    python descript_data_clean.py -i path/to/file.xlsx --delete-elements
        ''',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument('-i', '--input', type=str,
                        help='输入的Excel文件路径（可选，默认自动查找最新文件）')
    parser.add_argument('--delete-elements', action='store_true',
                        help='删除化学元素列（默认保留）')
    
    return parser.parse_args()

def find_latest_excel_file():
    """
    查找时间戳最近的Excel文件，首先尝试在results/data_descriptors目录中查找，然后在data目录中查找
    """
    import glob

    project_root = _get_project_root()

    data_descriptors_dir = os.path.join(project_root, "results", "data_descriptors")
    excel_patterns = ["*.xlsx", "*.xls", "*.xlsm"]
    excel_files = []
    
    if os.path.exists(data_descriptors_dir):
        print(f"在 {data_descriptors_dir} 目录中查找Excel文件...")
        for pattern in excel_patterns:
            excel_files.extend(glob.glob(os.path.join(data_descriptors_dir, pattern)))
    else:
        print(f"目录 {data_descriptors_dir} 不存在，尝试在其他位置查找...")
    
    # 如果在data_descriptors目录中没有找到文件，尝试在项目根目录的data目录中查找
    if not excel_files:
        data_dir = os.path.join(project_root, "data")
        if os.path.exists(data_dir):
            print(f"在 {data_dir} 目录中查找Excel文件...")
            for pattern in excel_patterns:
                excel_files.extend(glob.glob(os.path.join(data_dir, pattern)))
        else:
            print(f"目录 {data_dir} 不存在...")
    
    if not excel_files:
        print("无法找到Excel文件，请确保results/data_descriptors目录或data目录中有Excel文件")
        return None
    
    latest_file = max(excel_files, key=os.path.getmtime)
    print(f"找到最新的Excel文件: {latest_file}")
    return latest_file

def setup_directories():
    """创建所需的目录结构"""
    project_root = _get_project_root()
    results_dir = os.path.join(project_root, "results")
    
    logs_dir = os.path.join(results_dir, "logs")
    os.makedirs(logs_dir, exist_ok=True)
    
    # 创建engineer目录及其子目录
    engineer_dir = os.path.join(results_dir, "engineer")
    os.makedirs(engineer_dir, exist_ok=True)
    
    # 创建descript_data_clean目录
    data_clean_dir = os.path.join(engineer_dir, "descript_data_clean")
    os.makedirs(data_clean_dir, exist_ok=True)
    
    analysis_dir = os.path.join(data_clean_dir, "analysis")
    os.makedirs(analysis_dir, exist_ok=True)
    
    visualization_dir = os.path.join(data_clean_dir, "visualization")
    os.makedirs(visualization_dir, exist_ok=True)
    
    return logs_dir, data_clean_dir, analysis_dir, visualization_dir

def setup_logging(logs_dir):
    """设置日志文件"""
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = f"descript_data_clean_{timestamp}.log"
    log_path = os.path.join(logs_dir, log_filename)
    return log_path

class Logger:
    def __init__(self, log_path):
        self.terminal = sys.stdout
        self.log = open(log_path, 'w', encoding='utf-8')
    
    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()
    
    def flush(self):
        self.terminal.flush()
        self.log.flush()

def plot_nan_distribution(df, none_counts, output_dir):
    """绘制NaN值分布图表"""
    nan_df = pd.DataFrame.from_dict(none_counts, orient='index', columns=['NaN_Count'])
    nan_df['NaN_Percentage'] = (nan_df['NaN_Count'] / len(df)) * 100
    nan_df = nan_df.sort_values('NaN_Count', ascending=False).head(20)
    
    plt.figure(figsize=(12, 8))
    sns.barplot(x=nan_df.index, y='NaN_Count', data=nan_df, palette='viridis')
    plt.title('各列NaN值数量分布（前20个）', fontsize=16, fontweight='bold')
    plt.xlabel('列名', fontsize=14)
    plt.ylabel('NaN值数量', fontsize=14)
    plt.xticks(rotation=90, fontsize=12)
    plt.tight_layout()
    
    output_path = os.path.join(output_dir, 'nan_distribution.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"NaN值分布图表已保存到: {output_path}")

def plot_data_distribution(df, output_dir):
    """绘制数据分布图表"""
    numeric_cols = df.select_dtypes(include=['number']).columns
    if len(numeric_cols) > 10:
        numeric_cols = numeric_cols[:10]
    
    n_cols = 2
    n_rows = (len(numeric_cols) + n_cols - 1) // n_cols
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 4 * n_rows))
    axes = axes.flatten()
    
    for i, col in enumerate(numeric_cols):
        if i < len(axes):
            data = df[col].dropna()
            if len(data) > 0:
                sns.histplot(data, kde=True, ax=axes[i], color='steelblue', bins=30)
                axes[i].set_title(f'{col} 数据分布', fontsize=12, fontweight='bold')
                axes[i].set_xlabel(col, fontsize=10)
                axes[i].set_ylabel('频率', fontsize=10)
            else:
                axes[i].set_title(f'{col} 无有效数据', fontsize=12, fontweight='bold')
                axes[i].set_xlabel(col, fontsize=10)
                axes[i].set_ylabel('频率', fontsize=10)
    
    for i in range(len(numeric_cols), len(axes)):
        axes[i].set_visible(False)
    
    plt.tight_layout()
    
    output_path = os.path.join(output_dir, 'data_distribution.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"数据分布图表已保存到: {output_path}")

def plot_correlation_heatmap(df, output_dir):
    """绘制相关性热力图"""
    numeric_cols = df.select_dtypes(include=['number']).columns
    if len(numeric_cols) > 15:
        numeric_cols = numeric_cols[:15]
    
    corr_matrix = df[numeric_cols].corr()
    
    plt.figure(figsize=(15, 12))
    sns.heatmap(corr_matrix, annot=False, cmap='coolwarm', square=True, 
                linewidths=0.5, cbar_kws={'shrink': 0.8})
    plt.title('数值型特征相关性热力图', fontsize=16, fontweight='bold')
    plt.xticks(fontsize=10, rotation=90)
    plt.yticks(fontsize=10)
    plt.tight_layout()
    
    output_path = os.path.join(output_dir, 'correlation_heatmap.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"相关性热力图已保存到: {output_path}")

def plot_feature_distribution_comparison(df_before, df_after, output_dir):
    """绘制特征分布对比图表"""
    numeric_cols = df_before.select_dtypes(include=['number']).columns
    if len(numeric_cols) > 6:
        numeric_cols = numeric_cols[:6]
    
    n_cols = 2
    n_rows = (len(numeric_cols) + n_cols - 1) // n_cols
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 5 * n_rows))
    axes = axes.flatten()
    
    for i, col in enumerate(numeric_cols):
        if i < len(axes):
            data_before = df_before[col].dropna()
            data_after = df_after[col].dropna()
            
            sns.histplot(data_before, kde=True, ax=axes[i], color='steelblue', bins=30, label='处理前')
            sns.histplot(data_after, kde=True, ax=axes[i], color='green', bins=30, label='处理后')
            axes[i].set_title(f'{col} 数据分布对比', fontsize=12, fontweight='bold')
            axes[i].set_xlabel(col, fontsize=10)
            axes[i].set_ylabel('频率', fontsize=10)
            axes[i].legend()
    
    for i in range(len(numeric_cols), len(axes)):
        axes[i].set_visible(False)
    
    plt.tight_layout()
    
    output_path = os.path.join(output_dir, 'feature_distribution_comparison.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"特征分布对比图表已保存到: {output_path}")

def plot_feature_importance(df, output_dir):
    """绘制特征重要性图表"""
    numeric_cols = df.select_dtypes(include=['number']).columns
    
    feature_importance = {}
    for col in numeric_cols:
        data = df[col].dropna()
        if len(data) > 0:
            mean = data.mean()
            std = data.std()
            if mean != 0:
                cv = std / mean
                feature_importance[col] = cv
    
    importance_df = pd.DataFrame.from_dict(feature_importance, orient='index', columns=['Coefficient_of_Variation'])
    importance_df = importance_df.sort_values('Coefficient_of_Variation', ascending=False).head(20)
    
    plt.figure(figsize=(12, 8))
    sns.barplot(x=importance_df.index, y='Coefficient_of_Variation', data=importance_df, palette='viridis')
    plt.title('特征重要性分布（基于变异系数，前20个）', fontsize=16, fontweight='bold')
    plt.xlabel('特征名', fontsize=14)
    plt.ylabel('变异系数', fontsize=14)
    plt.xticks(rotation=90, fontsize=12)
    plt.tight_layout()
    
    output_path = os.path.join(output_dir, 'feature_importance.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"特征重要性图表已保存到: {output_path}")

def get_mandatory_columns():
    """获取必须保存的列"""
    mandatory_columns = [
        'alloy_composition_after_process',
        'elements',
    ]
    return mandatory_columns

def get_columns_to_delete():
    """获取需要删除的列"""
    columns_to_delete = []
    return columns_to_delete

def get_processing_mode():
    """获取特征处理模式"""
    print("\n=== 选择特征处理模式 ===")
    print("1. 自动化处理 (默认): 自动删除缺失值过多的列，对重要特征进行均值填充，删除剩余缺失值的行")
    print("2. 确定必须保存的列: 只保留指定的必须保存列，对这些列进行均值填充")
    print("3. 确定需要删除的列: 删除指定的列，对剩余列按自动化处理流程处理")
    
    mode = 1
    print(f"\n选择的处理模式: {mode} (自动化处理)")
    return mode

def automated_feature_processing(df, none_counts, mode=1, mandatory_columns=None, columns_to_delete=None, keep_elements=True):
    """
    自动化特征处理流程
    
    参数:
    df: 输入数据框
    none_counts: 各列的NaN值数量
    mode: 处理模式，1-自动化处理，2-只保留必须保存的列，3-删除指定的列
    mandatory_columns: 必须保存的列，默认为None（使用默认值）
    columns_to_delete: 需要删除的列，默认为None（使用默认值）
    keep_elements: 是否保留化学元素列，默认为True
    """
    print("\n=== 自动化特征处理流程 ===")
    
    if mandatory_columns is None:
        mandatory_columns = get_mandatory_columns()
    print(f"必须保存的列: {mandatory_columns}")
    
    if columns_to_delete is None:
        columns_to_delete = get_columns_to_delete()
    print(f"需要删除的列: {columns_to_delete}")
    
    element_cols = get_element_columns(df)
    print(f"\n化学元素列 ({len(element_cols)}): {element_cols}")
    print(f"化学元素列处理: {'保留' if keep_elements else '删除'}")
    
    if keep_elements:
        mandatory_columns = list(set(mandatory_columns + element_cols))
        print(f"更新后的必须保存的列（包含化学元素）: {mandatory_columns}")
    else:
        columns_to_delete = list(set(columns_to_delete + element_cols))
        print(f"更新后的需要删除的列（包含化学元素）: {columns_to_delete}")
    
    if mode == 2:
        print("\n执行模式2: 确保必须保存的列存在，对所有列按自动化处理流程处理")
        df_processed = df.drop(columns=[col for col in columns_to_delete if col in df.columns])
        
        print("\n分析缺失值过多的特征列:")
        threshold = 0.3
        cols_to_drop_due_to_nan = []
        
        for col, count in none_counts.items():
            if col in df_processed.columns and col not in mandatory_columns:
                total_count = len(df_processed[col])
                missing_percentage = (count / total_count) * 100
                if missing_percentage > 30:
                    cols_to_drop_due_to_nan.append((col, missing_percentage))
        
        cols_to_drop_due_to_nan.sort(key=lambda x: x[1], reverse=True)
        
        if cols_to_drop_due_to_nan:
            print("\n删除缺失值过多的特征列:")
            for col, percentage in cols_to_drop_due_to_nan:
                print(f"- {col}: 缺失值比例 {percentage:.2f}%，删除该列")
                df_processed = df_processed.drop(columns=[col])
        else:
            print("\n未发现缺失值过多的特征列")
        
        important_features = [
            'mixing_entropy',
            'average_electronegativity',
            'average_atomic_radius_empirical',
        ]
        
        print("\n处理重要特征的缺失值:")
        important_cols_filled = []
        
        for col in important_features:
            if col in df_processed.columns:
                count = df_processed[col].isna().sum()
                if count > 0:
                    mean_value = df_processed[col].mean()
                    df_processed[col] = df_processed[col].fillna(mean_value)
                    print(f"- 重要特征 {col}: 用均值 {mean_value:.4f} 填充")
                    important_cols_filled.append(col)
        
        print("\n对必须保存的列进行均值填充:")
        for col in mandatory_columns:
            if col in df_processed.columns and pd.api.types.is_numeric_dtype(df_processed[col]):
                count = df_processed[col].isna().sum()
                if count > 0:
                    mean_value = df_processed[col].mean()
                    df_processed[col] = df_processed[col].fillna(mean_value)
                    print(f"- 必须保存列 {col}: 用均值 {mean_value:.4f} 填充")
                    if col not in important_cols_filled:
                        important_cols_filled.append(col)
        
        print("\n删除包含剩余缺失值的行:")
        original_rows = len(df_processed)
        df_processed = df_processed.dropna()
        rows_dropped = original_rows - len(df_processed)
        
        print(f"- 原始行数: {original_rows}")
        print(f"- 删除的行数: {rows_dropped}")
        print(f"- 处理后行数: {len(df_processed)}")
        
    elif mode == 3:
        print("\n执行模式3: 删除指定的列，对剩余列按自动化处理流程处理")
        df_processed = df.drop(columns=[col for col in columns_to_delete if col in df.columns])
        
        print("\n分析缺失值过多的特征列:")
        threshold = 0.3
        cols_to_drop_due_to_nan = []
        
        for col, count in none_counts.items():
            if col in df_processed.columns:
                total_count = len(df_processed[col])
                missing_percentage = (count / total_count) * 100
                if missing_percentage > 30:
                    cols_to_drop_due_to_nan.append((col, missing_percentage))
        
        cols_to_drop_due_to_nan.sort(key=lambda x: x[1], reverse=True)
        
        if cols_to_drop_due_to_nan:
            print("\n删除缺失值过多的特征列:")
            for col, percentage in cols_to_drop_due_to_nan:
                print(f"- {col}: 缺失值比例 {percentage:.2f}%，删除该列")
                df_processed = df_processed.drop(columns=[col])
        else:
            print("\n未发现缺失值过多的特征列")
        
        important_features = [
            'mixing_entropy',
            'average_electronegativity',
            'average_atomic_radius_empirical',
        ]
        
        print("\n处理重要特征的缺失值:")
        important_cols_filled = []
        
        for col in important_features:
            if col in df_processed.columns:
                count = df_processed[col].isna().sum()
                if count > 0:
                    mean_value = df_processed[col].mean()
                    df_processed[col] = df_processed[col].fillna(mean_value)
                    print(f"- 重要特征 {col}: 用均值 {mean_value:.4f} 填充")
                    important_cols_filled.append(col)
        
        print("\n对必须保存的列进行均值填充:")
        for col in mandatory_columns:
            if col in df_processed.columns and pd.api.types.is_numeric_dtype(df_processed[col]):
                count = df_processed[col].isna().sum()
                if count > 0:
                    mean_value = df_processed[col].mean()
                    df_processed[col] = df_processed[col].fillna(mean_value)
                    print(f"- 必须保存列 {col}: 用均值 {mean_value:.4f} 填充")
                    if col not in important_cols_filled:
                        important_cols_filled.append(col)
        
        if not important_cols_filled:
            print("- 没有重要特征需要填充")
        
        print("\n删除包含剩余缺失值的行:")
        original_rows = len(df_processed)
        df_processed = df_processed.dropna()
        rows_dropped = original_rows - len(df_processed)
        
        print(f"- 原始行数: {original_rows}")
        print(f"- 删除的行数: {rows_dropped}")
        print(f"- 处理后行数: {len(df_processed)}")
        
    else:
        print("\n执行模式1: 自动化处理")
        df_processed = df.drop(columns=[col for col in columns_to_delete if col in df.columns])
        
        print("\n分析缺失值过多的特征列:")
        threshold = 0.3
        cols_to_drop_due_to_nan = []
        
        for col, count in none_counts.items():
            if col in df_processed.columns and col not in mandatory_columns:
                total_count = len(df_processed[col])
                missing_percentage = (count / total_count) * 100
                if missing_percentage > 30:
                    cols_to_drop_due_to_nan.append((col, missing_percentage))
        
        cols_to_drop_due_to_nan.sort(key=lambda x: x[1], reverse=True)
        
        if cols_to_drop_due_to_nan:
            print("\n删除缺失值过多的特征列:")
            for col, percentage in cols_to_drop_due_to_nan:
                print(f"- {col}: 缺失值比例 {percentage:.2f}%，删除该列")
                df_processed = df_processed.drop(columns=[col])
        else:
            print("\n未发现缺失值过多的特征列")
        
        important_features = [
            'mixing_entropy',
            'average_electronegativity',
            'average_atomic_radius_empirical',
        ]
        
        print("\n处理重要特征的缺失值:")
        important_cols_filled = []
        
        for col in important_features:
            if col in df_processed.columns:
                count = df_processed[col].isna().sum()
                if count > 0:
                    mean_value = df_processed[col].mean()
                    df_processed[col] = df_processed[col].fillna(mean_value)
                    print(f"- 重要特征 {col}: 用均值 {mean_value:.4f} 填充")
                    important_cols_filled.append(col)
        
        print("\n对必须保存的列进行均值填充:")
        for col in mandatory_columns:
            if col in df_processed.columns and pd.api.types.is_numeric_dtype(df_processed[col]):
                count = df_processed[col].isna().sum()
                if count > 0:
                    mean_value = df_processed[col].mean()
                    df_processed[col] = df_processed[col].fillna(mean_value)
                    print(f"- 必须保存列 {col}: 用均值 {mean_value:.4f} 填充")
                    if col not in important_cols_filled:
                        important_cols_filled.append(col)
        
        if not important_cols_filled:
            print("- 没有重要特征需要填充")
        
        print("\n删除包含剩余缺失值的行:")
        original_rows = len(df_processed)
        df_processed = df_processed.dropna()
        rows_dropped = original_rows - len(df_processed)
        
        print(f"- 原始行数: {original_rows}")
        print(f"- 删除的行数: {rows_dropped}")
        print(f"- 处理后行数: {len(df_processed)}")
    
    print("\n分析缺失值原因:")
    elements_in_data = set()
    for elem_col in df.columns:
        if is_element_column(elem_col):
            elements_in_data.add(elem_col)
    
    print(f"- 数据中包含的元素: {sorted(list(elements_in_data))}")
    print(f"- 可能导致缺失值的原因: 部分元素的物理/化学属性数据缺失")
    
    print("\n验证处理结果:")
    remaining_nan = df_processed.isna().sum().sum()
    print(f"- 处理后剩余的NaN值数量: {remaining_nan}")
    
    if remaining_nan == 0:
        print("✓ 数据处理完成，无缺失值！")
    else:
        print("✗ 数据处理后仍有缺失值，请检查！")
    
    print("\n处理流程总结:")
    print(f"1. 处理模式: {mode} ({'自动化处理' if mode == 1 else '只保留必须保存的列' if mode == 2 else '删除指定的列'})")
    print(f"2. 化学元素列处理: {'保留' if keep_elements else '删除'}")
    print(f"3. 删除了 {len(columns_to_delete)} 个指定删除的列")
    print(f"4. 删除了 {len(cols_to_drop_due_to_nan)} 个缺失值过多的列")
    print(f"5. 填充了 {len(important_cols_filled)} 个重要特征的缺失值")
    print(f"6. 删除了 {rows_dropped} 个包含剩余缺失值的行")
    print(f"7. 处理后的数据形状: {df_processed.shape}")
    
    return df_processed

def analyze_excel(file_path, data_clean_dir, analysis_dir, visualization_dir, processing_mode=1, mandatory_columns=None, columns_to_delete=None, keep_elements=True):
    """
    分析Excel文件：智能删除空行，处理单位换算，统计特征信息，生成可视化
    
    参数:
    file_path: 输入文件路径
    data_clean_dir: 数据清理输出目录
    analysis_dir: 数据分析输出目录
    visualization_dir: 数据可视化输出目录
    processing_mode: 处理模式，1-自动化处理，2-只保留必须保存的列，3-删除指定的列
    mandatory_columns: 必须保存的列，默认为None（使用默认值）
    columns_to_delete: 需要删除的列，默认为None（使用默认值）
    keep_elements: 是否保留化学元素列，默认为True
    """
    print(f"开始分析文件: {file_path}")
    
    try:
        df = pd.read_excel(file_path)
        print(f"原始数据形状: {df.shape} (行, 列)")
        print(f"原始数据列名: {list(df.columns)}")
    except Exception as e:
        print(f"读取Excel文件时出错: {e}")
        return
    
    print(f"\n原始数据信息:")
    print(f"- 总行数: {len(df)}")
    print(f"- 总列数: {len(df.columns)}")
    
    print(f"\n各列None/NaN值统计:")
    none_counts = {}
    for col in df.columns:
        none_count = df[col].isna().sum()
        if none_count > 0:
            none_counts[col] = none_count
            print(f"- {col}: {none_count} 个")
    
    if not none_counts:
        print("- 没有发现None/NaN值")
    
    original_rows = len(df)
    original_cols = len(df.columns)
    
    original_row_indices = set(df.index)
    
    df_cleaned = df.dropna(how='all')
    
    threshold = len(df_cleaned.columns) * 0.5
    df_cleaned_before = df_cleaned.copy()
    df_cleaned = df_cleaned.dropna(thresh=threshold)
    
    rows_dropped_all_nan = original_rows - len(df_cleaned_before)
    rows_dropped_threshold = len(df_cleaned_before) - len(df_cleaned)
    rows_dropped = original_rows - len(df_cleaned)
    
    remaining_row_indices = set(df_cleaned.index)
    deleted_row_indices = original_row_indices - remaining_row_indices
    
    print(f"\n智能删除空行结果:")
    print(f"- 原始行数: {original_rows}")
    print(f"- 删除的全NaN行数: {rows_dropped_all_nan}")
    print(f"- 删除的超过50%NaN行数: {rows_dropped_threshold}")
    print(f"- 总共删除的行数: {rows_dropped}")
    print(f"- 清理后行数: {len(df_cleaned)}")
    print(f"- 删除的行索引: {sorted(list(deleted_row_indices))[:20]}..." if len(deleted_row_indices) > 20 else f"- 删除的行索引: {sorted(list(deleted_row_indices))}")
    
    print(f"\n清理后各列None/NaN值统计:")
    none_counts_after = {}
    for col in df_cleaned.columns:
        none_count = df_cleaned[col].isna().sum()
        if none_count > 0:
            none_counts_after[col] = none_count
            print(f"- {col}: {none_count} 个")
    
    if not none_counts_after:
        print("- 清理后没有发现None/NaN值")
    
    if none_counts:
        print(f"\n详细None/NaN值分析:")
        for col, count in none_counts.items():
            total_count = len(df[col])
            percentage = (count / total_count) * 100
            print(f"- {col}: {count}/{total_count} ({percentage:.2f}%)")
    
    print(f"\n单位换算特征分析:")
    
    unit_priority = {
        'kelvin': 1,
        'celsius': 2,
        'fahrenheit': 3,
        'kg_m3': 1,
        'g_cm3': 2,
        'm3': 1,
        'cm3': 2
    }
    
    attribute_columns = {}
    for col in df_cleaned.columns:
        if 'temperature' in col.lower() or 'boiling_point' in col.lower() or 'melting_point' in col.lower():
            if 'kelvin' in col.lower():
                attr_name = col.lower().replace('_kelvin', '')
                unit = 'kelvin'
            elif 'celsius' in col.lower():
                attr_name = col.lower().replace('_celsius', '')
                unit = 'celsius'
            elif 'fahrenheit' in col.lower():
                attr_name = col.lower().replace('_fahrenheit', '')
                unit = 'fahrenheit'
            else:
                continue
        elif 'density' in col.lower():
            if 'kg_m3' in col.lower() or 'kg/m3' in col.lower():
                attr_name = col.lower().replace('_kg_m3', '').replace('_kg/m3', '')
                unit = 'kg_m3'
            elif 'g_cm3' in col.lower() or 'g/cm3' in col.lower():
                attr_name = col.lower().replace('_g_cm3', '').replace('_g/cm3', '')
                unit = 'g_cm3'
            else:
                continue
        else:
            continue
        
        if attr_name not in attribute_columns:
            attribute_columns[attr_name] = []
        attribute_columns[attr_name].append((col, unit))
    
    columns_to_keep = set(df_cleaned.columns)
    unit_columns_to_delete = set()
    
    for attr_name, col_unit_pairs in attribute_columns.items():
        if len(col_unit_pairs) > 1:
            print(f"\n属性 '{attr_name}' 存在多个单位的列:")
            for col, unit in col_unit_pairs:
                print(f"- {col} (单位: {unit})")
            
            col_unit_pairs.sort(key=lambda x: unit_priority.get(x[1], 999))
            selected_col, selected_unit = col_unit_pairs[0]
            print(f"选择的标准单位列: {selected_col} (单位: {selected_unit})")
            
            for col, unit in col_unit_pairs[1:]:
                unit_columns_to_delete.add(col)
    
    if unit_columns_to_delete:
        print(f"\n删除多余的单位列: {sorted(list(unit_columns_to_delete))}")
        df_cleaned = df_cleaned.drop(columns=list(unit_columns_to_delete))
        
        cols_dropped = original_cols - len(df_cleaned.columns)
        print(f"- 原始列数: {original_cols}")
        print(f"- 删除的列数: {cols_dropped}")
        print(f"- 清理后列数: {len(df_cleaned.columns)}")
    else:
        print("\n未发现需要删除的多余单位列")
    
    print(f"\n选择的处理模式: {processing_mode} ({'自动化处理' if processing_mode == 1 else '只保留必须保存的列' if processing_mode == 2 else '删除指定的列'})")
    
    print(f"\n执行自动化特征处理...")
    df_processed = automated_feature_processing(df_cleaned, none_counts, processing_mode, mandatory_columns, columns_to_delete, keep_elements)
    
    print(f"\n生成数据可视化图表...")
    try:
        if none_counts:
            plot_nan_distribution(df, none_counts, visualization_dir)
        plot_data_distribution(df_processed, visualization_dir)
        plot_feature_distribution_comparison(df_cleaned, df_processed, visualization_dir)
        plot_feature_importance(df_processed, visualization_dir)
    except Exception as e:
        print(f"生成可视化图表时出错: {e}")
    
    print(f"\n保存详细统计信息...")
    try:
        stats_df = pd.DataFrame()
        for col in df_processed.columns:
            if pd.api.types.is_numeric_dtype(df_processed[col]):
                stats = {
                    'Column': col,
                    'Count': len(df_processed[col]),
                    'Non-Null Count': df_processed[col].count(),
                    'Null Count': df_processed[col].isna().sum(),
                    'Min': df_processed[col].min(),
                    'Max': df_processed[col].max(),
                    'Mean': df_processed[col].mean(),
                    'Std': df_processed[col].std(),
                    'Median': df_processed[col].median()
                }
                stats_df = pd.concat([stats_df, pd.DataFrame([stats])], ignore_index=True)
        
        stats_excel_path = os.path.join(analysis_dir, 'data_statistics.xlsx')
        stats_csv_path = os.path.join(analysis_dir, 'data_statistics.csv')
        stats_df.to_excel(stats_excel_path, index=False)
        stats_df.to_csv(stats_csv_path, index=False, encoding='utf-8-sig')
        print(f"详细统计信息已保存到: {stats_excel_path}")
        print(f"详细统计信息已保存到: {stats_csv_path}")
    except Exception as e:
        print(f"保存统计信息时出错: {e}")
    
    try:
        file_name = os.path.basename(file_path)
        base_name, ext = os.path.splitext(file_name)
        
        excel_output_path = os.path.join(data_clean_dir, f"{base_name}_processed{ext}")
        df_processed.to_excel(excel_output_path, index=False)
        print(f"\n处理后的数据已保存到: {excel_output_path}")
        
        csv_output_path = os.path.join(data_clean_dir, f"{base_name}_processed.csv")
        df_processed.to_csv(csv_output_path, index=False, encoding='utf-8-sig')
        print(f"处理后的数据已保存到: {csv_output_path}")
    except Exception as e:
        print(f"保存处理后的数据时出错: {e}")
    
    print(f"\n分析完成！")
    print(f"\n处理流程总结:")
    print(f"1. 智能删除空行: 删除了 {rows_dropped} 行")
    print(f"2. 单位换算处理: 删除了 {len(columns_to_delete) if columns_to_delete else 0} 个多余单位列")
    print(f"3. 特征处理模式: {processing_mode} ({'自动化处理' if processing_mode == 1 else '只保留必须保存的列' if processing_mode == 2 else '删除指定的列'})")
    print(f"4. 化学元素列处理: {'保留' if keep_elements else '删除'}")
    print(f"5. 自动化特征处理: 填充了所有缺失值，确保数据无缺失")
    print(f"6. 生成可视化图表: 包含NaN值分布、数据分布、特征分布对比和特征重要性图表")
    print(f"7. 保存结果: 同时保存为Excel和CSV格式")
    print(f"\n处理后的数据已准备就绪，可以直接用于机器学习模型！")


def run(args=None):
    if args is None:
        args = parse_arguments()

    logs_dir, data_clean_dir, analysis_dir, visualization_dir = setup_directories()

    log_path = setup_logging(logs_dir)
    sys.stdout = Logger(log_path)

    print(f"日志文件路径: {log_path}")
    print(f"数据清理输出目录: {data_clean_dir}")
    print(f"数据分析输出目录: {analysis_dir}")
    print(f"数据可视化输出目录: {visualization_dir}")

    if args.input:
        excel_file_path = args.input
        if not os.path.exists(excel_file_path):
            print(f"错误: 指定的输入文件不存在: {excel_file_path}")
            sys.exit(1)
        print(f"\n使用指定的输入文件: {excel_file_path}")
    else:
        print("\n自动查找data_descriptors目录下最新的Excel文件...")
        excel_file_path = find_latest_excel_file()

        if excel_file_path is None:
            print("无法找到Excel文件，请确保data_descriptors目录中有Excel文件")
            sys.exit(1)

    keep_elements = not args.delete_elements

    analyze_excel(
        excel_file_path,
        data_clean_dir,
        analysis_dir,
        visualization_dir,
        keep_elements=keep_elements
    )


if __name__ == "__main__":
    run()
