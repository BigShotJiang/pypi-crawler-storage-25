# -*- coding: utf-8 -*-
"""
化学元素处理工具模块
====================

提供化学元素列的识别和处理功能。
"""

# 完整的化学元素列表（元素符号）
CHEMICAL_ELEMENTS = [
    'H', 'He', 'Li', 'Be', 'B', 'C', 'N', 'O', 'F', 'Ne',
    'Na', 'Mg', 'Al', 'Si', 'P', 'S', 'Cl', 'Ar', 'K', 'Ca',
    'Sc', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn',
    'Ga', 'Ge', 'As', 'Se', 'Br', 'Kr', 'Rb', 'Sr', 'Y', 'Zr',
    'Nb', 'Mo', 'Tc', 'Ru', 'Rh', 'Pd', 'Ag', 'Cd', 'In', 'Sn',
    'Sb', 'Te', 'I', 'Xe', 'Cs', 'Ba', 'La', 'Ce', 'Pr', 'Nd',
    'Pm', 'Sm', 'Eu', 'Gd', 'Tb', 'Dy', 'Ho', 'Er', 'Tm', 'Yb',
    'Lu', 'Hf', 'Ta', 'W', 'Re', 'Os', 'Ir', 'Pt', 'Au', 'Hg',
    'Tl', 'Pb', 'Bi', 'Po', 'At', 'Rn', 'Fr', 'Ra', 'Ac', 'Th',
    'Pa', 'U', 'Np', 'Pu', 'Am', 'Cm', 'Bk', 'Cf', 'Es', 'Fm',
    'Md', 'No', 'Lr', 'Rf', 'Db', 'Sg', 'Bh', 'Hs', 'Mt', 'Ds',
    'Rg', 'Cn', 'Nh', 'Fl', 'Mc', 'Lv', 'Ts', 'Og'
]

def is_element_column(col_name):
    """
    判断列名是否为化学元素列
    
    参数:
    col_name: 列名
    
    返回:
    bool: 是否为化学元素列
    """
    # 精确匹配元素符号
    if col_name in CHEMICAL_ELEMENTS:
        return True
    
    # 匹配小写元素符号
    if col_name.lower() in [elem.lower() for elem in CHEMICAL_ELEMENTS]:
        return True
    
    return False

def get_element_columns(df):
    """
    从数据框中获取所有化学元素列
    
    参数:
    df: 数据框
    
    返回:
    list: 化学元素列名列表
    """
    element_cols = []
    for col in df.columns:
        if is_element_column(col):
            element_cols.append(col)
    return element_cols

def filter_element_columns(columns, keep_elements=True):
    """
    过滤化学元素列
    
    参数:
    columns: 列名列表
    keep_elements: 是否保留化学元素列，默认True
    
    返回:
    list: 过滤后的列名列表
    """
    if keep_elements:
        return columns
    else:
        return [col for col in columns if not is_element_column(col)]
