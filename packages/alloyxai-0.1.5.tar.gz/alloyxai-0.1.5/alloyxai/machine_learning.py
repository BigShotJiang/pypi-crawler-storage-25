#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
机器学习算法调用脚本

该脚本用于调用heaML文件夹中的各种机器学习算法，并支持生成算法效果对比的可视化图表。
"""

import os
import sys
import json
import argparse
import subprocess
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from datetime import datetime
import logging
import time


def _get_project_root():
    return os.getcwd()

# 设置日志记录
def setup_logging():
    """
    设置日志记录
    
    返回:
    logger: 配置好的日志记录器
    """
    # 日志目录
    log_dir = os.path.join(_get_project_root(), 'results', 'logs')
    os.makedirs(log_dir, exist_ok=True)
    
    # 日志文件名
    log_filename = f'machine_learning_{time.strftime("%Y%m%d_%H%M%S")}.log'
    log_path = os.path.join(log_dir, log_filename)
    
    # 配置日志
    logger = logging.getLogger('MachineLearning')
    logger.setLevel(logging.INFO)
    
    # 清除已有的处理器
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # 文件处理器
    file_handler = logging.FileHandler(log_path, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)
    
    # 控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(console_handler)
    
    return logger

# 创建日志记录器
logger = setup_logging()

# 设置Matplotlib全局样式
plt.rcParams.update({
    'font.size': 16,
    'axes.titlesize': 20,
    'axes.labelsize': 18,
    'xtick.labelsize': 16,
    'ytick.labelsize': 16,
    'legend.fontsize': 14,
    'figure.figsize': (12, 8),
    'figure.dpi': 100,
    'axes.linewidth': 2,
    'xtick.major.width': 2,
    'ytick.major.width': 2,
    'xtick.minor.width': 1.5,
    'ytick.minor.width': 1.5,
    'xtick.major.size': 8,
    'ytick.major.size': 8,
    'xtick.minor.size': 4,
    'ytick.minor.size': 4
})

# 定义支持的算法列表和对应的脚本名称
ALGORITHMS = {
    'linear_regression': 'linear_regression_ml.py',
    'random_forest': 'random_forest_ml.py',
    'neural_network': 'neural_network_ml.py',
    'xgb': 'xgb_ml.py',
    'gradient_boosting': 'gradient_boosting_ml.py',
    'bayesian': 'bayesian_ml.py',
    'svm': 'svm_ml.py',
    'knn': 'knn_ml.py',
    'decision_tree': 'decision_tree_ml.py'
}

# 算法名称的英文映射
ALGORITHM_NAMES = {
    'linear_regression': 'Linear Regression',
    'random_forest': 'Random Forest',
    'neural_network': 'Neural Network',
    'xgb': 'XGBoost',
    'gradient_boosting': 'Gradient Boosting',
    'bayesian': 'Bayesian',
    'svm': 'SVM',
    'knn': 'KNN',
    'decision_tree': 'Decision Tree'
}

# heaML 各脚本写入 results/alloy_machine_learning/<subdir>/；键名与目录名不一致时在此映射
ALGORITHM_OUTPUT_SUBDIR = {
    'xgb': 'xgboost',
}


def _algorithm_result_subdir(algorithm_name):
    """返回磁盘上该算法结果所在的子目录名（与 heaML 脚本中 join(args.output, ...) 一致）。"""
    return ALGORITHM_OUTPUT_SUBDIR.get(algorithm_name, algorithm_name)


def parse_arguments():
    """
    解析命令行参数
    
    返回:
    argparse.Namespace: 解析后的参数
    """
    parser = argparse.ArgumentParser(
        description='机器学习算法调用脚本',
        epilog='''
使用示例:
    # 运行所有算法
    python machine_learning.py
    
    # 运行指定的算法（可多次指定）
    python machine_learning.py -a linear_regression -a random_forest
    
    # 指定测试集大小
    python machine_learning.py --test-size 0.3
    
    # 指定输入数据文件
    python machine_learning.py -d path/to/data.csv
    
    # 指定目标变量
    python machine_learning.py -t target_column
    
    # 指定任务类型
    python machine_learning.py -T regression
    
    # 组合使用多个参数
    python machine_learning.py -a linear_regression -a xgb --test-size 0.25 -m hyperparameter
        ''',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    # 算法选择参数
    parser.add_argument('-a', '--algorithm', type=str, choices=ALGORITHMS.keys(), action='append',
                        help='指定使用的机器学习算法，默认使用所有算法，可多次指定')
    
    # 测试集大小参数
    parser.add_argument('--test-size', type=float, default=0.2,
                        help='测试集大小，默认0.2（20%%）')
    
    # 数据文件参数
    parser.add_argument('-d', '--data', type=str,
                        help='输入数据文件路径，默认使用最新的特征工程输出文件')
    
    # 目标变量参数
    parser.add_argument('-t', '--target', type=str,
                        help='目标变量名称，默认使用最后一列')
    
    # 任务类型参数
    parser.add_argument('-T', '--task', type=str, choices=['classification', 'regression'],
                        help='任务类型: classification (分类) 或 regression (回归)，默认自动检测')
    
    # 模式参数
    parser.add_argument('-m', '--mode', type=str, default='quick', choices=['quick', 'hyperparameter'],
                        help='模式: quick (快速模式) 或 hyperparameter (超参数模式)')
    
    # 输出目录参数
    default_output = os.path.join(_get_project_root(), 'results', 'alloy_machine_learning')
    parser.add_argument('-o', '--output', type=str, default=default_output,
                        help='输出目录，默认保存在 results/alloy_machine_learning')
    
    return parser.parse_args()

def run_algorithm(algorithm_name, args):
    """
    运行指定的算法
    
    参数:
    algorithm_name: 算法名称
    args: 命令行参数
    
    返回:
    dict: 算法运行结果
    """
    logger.info(f"\n=== 运行 {ALGORITHM_NAMES[algorithm_name]} 算法 ===")
    
    # 构建命令
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'heaML', ALGORITHMS[algorithm_name])
    
    cmd = [sys.executable, script_path, '--test-size', str(args.test_size)]
    
    # 添加其他参数
    if args.data:
        cmd.extend(['-d', args.data])
    if args.target:
        cmd.extend(['-t', args.target])
    if args.task:
        cmd.extend(['-T', args.task])
    if args.mode:
        cmd.extend(['-m', args.mode])
    if args.output:
        cmd.extend(['-o', args.output])
    
    # 执行命令
    try:
        # 使用capture_output=False，让算法直接输出到终端，避免编码错误
        result = subprocess.run(cmd, check=True)
        
        # 提取结果
        return extract_results(algorithm_name, args)
    except subprocess.CalledProcessError as e:
        logger.error(f"错误: 运行 {algorithm_name} 算法失败")
        return None
    except Exception as e:
        logger.error(f"错误: 运行 {algorithm_name} 算法时发生未知错误: {e}")
        return None

def extract_results(algorithm_name, args):
    """
    从算法输出目录中提取结果
    
    参数:
    algorithm_name: 算法名称
    args: 命令行参数
    
    返回:
    dict: 提取的结果
    """
    # 构建结果文件路径（xgb 脚本写入 xgboost/ 而非 xgb/）
    results_dir = os.path.join(args.output, _algorithm_result_subdir(algorithm_name), 'results')
    
    # 检查目录是否存在
    if not os.path.exists(results_dir):
        logger.warning(f"警告: {algorithm_name} 的结果目录不存在: {results_dir}")
        return None
    
    # 查找最新的结果文件
    result_files = []
    try:
        for file in os.listdir(results_dir):
            if file.endswith('.json'):
                file_path = os.path.join(results_dir, file)
                mtime = os.path.getmtime(file_path)
                result_files.append((mtime, file_path))
    except Exception as e:
        logger.warning(f"警告: 读取 {algorithm_name} 的结果目录时出错: {e}")
        return None
    
    if not result_files:
        logger.warning(f"警告: 未找到 {algorithm_name} 的结果文件")
        return None
    
    # 按修改时间排序，获取最新的文件
    result_files.sort(reverse=True)
    latest_result_file = result_files[0][1]
    
    # 读取结果文件
    try:
        with open(latest_result_file, 'r', encoding='utf-8') as f:
            results = json.load(f)
    except Exception as e:
        logger.warning(f"警告: 读取 {algorithm_name} 的结果文件时出错: {e}")
        return None
    
    # 确定任务类型
    task_type = 'regression'  # 默认任务类型
    if 'accuracy' in results or 'precision' in results:
        task_type = 'classification'
    
    return {
        'algorithm': algorithm_name,
        'name': ALGORITHM_NAMES[algorithm_name],
        'metrics': results,
        'task_type': task_type
    }

def generate_comparison_chart(results, output_dir):
    """
    生成算法效果对比图表
    
    参数:
    results: 算法运行结果列表
    output_dir: 输出目录
    """
    if not results:
        logger.warning("警告: 没有结果数据，无法生成对比图表")
        return
    
    # 创建输出目录
    chart_dir = os.path.join(output_dir, 'comparison')
    os.makedirs(chart_dir, exist_ok=True)
    
    # 确定任务类型
    task_type = results[0]['task_type']
    
    # 准备数据
    algorithms = [r['name'] for r in results]
    
    # 使用专业美观的配色方案
    # 自定义配色，选择更协调的颜色
    custom_colors = [
        '#1f77b4',  # 蓝色
        '#ff7f0e',  # 橙色
        '#2ca02c',  # 绿色
        '#d62728',  # 红色
        '#9467bd',  # 紫色
        '#8c564b',  # 棕色
        '#e377c2',  # 粉色
        '#7f7f7f',  # 灰色
        '#bcbd22',  # 橄榄绿
    ]
    # 如果算法数量超过颜色数量，循环使用
    colors = [custom_colors[i % len(custom_colors)] for i in range(len(algorithms))]
    
    if task_type == 'regression':
        # 回归任务指标
        metrics = ['rmse', 'mae', 'r2']
        metric_names = ['RMSE', 'MAE', 'R²']
        
        # 为每个指标生成单独的图表
        for i, (metric, metric_name) in enumerate(zip(metrics, metric_names)):
            values = []
            for r in results:
                if metric in r['metrics']:
                    values.append(r['metrics'][metric])
                else:
                    values.append(0)
            
            # 设置图表样式 - 仿照heaML/visualization_utils.py的期刊标准配置
            plt.figure(figsize=(12, 8), dpi=300)
            # 使用与heaML相同的字体配置，确保一致性
            plt.rcParams.update({
                'font.size': 24,
                'font.family': 'Times New Roman',  # 期刊常用字体
                'axes.titlesize': 28,
                'axes.labelsize': 24,
                'xtick.labelsize': 20,
                'ytick.labelsize': 20,
                'xtick.major.size': 10,  # 增大x轴主刻度线大小
                'xtick.major.width': 1.0,  # 增大x轴主刻度线宽度
                'ytick.major.size': 10,  # 增大y轴主刻度线大小
                'ytick.major.width': 1.0,  # 增大y轴主刻度线宽度
                'figure.dpi': 300,  # 高分辨率
                'savefig.dpi': 300,  # 保存时使用高分辨率
                'axes.linewidth': 1.2,  # 增大坐标轴线条宽度
                'grid.linewidth': 0.6,  # 增大网格线条宽度
                'lines.linewidth': 2.0,  # 线条宽度
            })
            
            # 绘制条形图
            bars = plt.bar(algorithms, values, color=colors, width=0.6)
            plt.title(f'{metric_name} Comparison', fontsize=28, fontweight='bold')
            plt.xlabel('Algorithm', fontsize=24)
            plt.ylabel(metric_name, fontsize=24)
            plt.xticks(rotation=45, ha='right', fontsize=20)
            plt.yticks(fontsize=20)
            plt.grid(axis='y', linestyle='--', alpha=0.7)
            
            # 调整y轴范围，确保条形图有足够高度
            if metric == 'r2':
                plt.ylim(0, 1)
            else:
                max_value = max(values) * 1.2
                plt.ylim(0, max_value)
            
            # 添加数据标签
            for bar, value in zip(bars, values):
                height = bar.get_height()
                if metric == 'r2':
                    plt.text(bar.get_x() + bar.get_width()/2., height + 0.03,
                           f'{value:.4f}', ha='center', va='bottom', fontsize=20)
                else:
                    plt.text(bar.get_x() + bar.get_width()/2., height + max_value * 0.02,
                           f'{value:.2f}', ha='center', va='bottom', fontsize=20)
            
            # 调整布局
            plt.tight_layout()
            
            # 保存图表
            chart_path = os.path.join(chart_dir, f'{task_type}_{metric}_comparison.png')
            plt.savefig(chart_path, bbox_inches='tight', dpi=300)
            logger.info(f"图表保存路径: {chart_path}")
            
            # 关闭图表
            plt.close()
        
    else:
        # 分类任务指标
        metrics = ['accuracy', 'precision', 'recall', 'f1']
        metric_names = ['Accuracy', 'Precision', 'Recall', 'F1 Score']
        
        # 为每个指标生成单独的图表
        for i, (metric, metric_name) in enumerate(zip(metrics, metric_names)):
            values = []
            for r in results:
                if metric in r['metrics']:
                    values.append(r['metrics'][metric])
                else:
                    values.append(0)
            
            # 设置图表样式 - 仿照heaML/visualization_utils.py的期刊标准配置
            plt.figure(figsize=(12, 8), dpi=300)
            # 使用与heaML相同的字体配置，确保一致性
            plt.rcParams.update({
                'font.size': 24,
                'font.family': 'Times New Roman',  # 期刊常用字体
                'axes.titlesize': 28,
                'axes.labelsize': 24,
                'xtick.labelsize': 20,
                'ytick.labelsize': 20,
                'xtick.major.size': 10,  # 增大x轴主刻度线大小
                'xtick.major.width': 1.0,  # 增大x轴主刻度线宽度
                'ytick.major.size': 10,  # 增大y轴主刻度线大小
                'ytick.major.width': 1.0,  # 增大y轴主刻度线宽度
                'figure.dpi': 300,  # 高分辨率
                'savefig.dpi': 300,  # 保存时使用高分辨率
                'axes.linewidth': 1.2,  # 增大坐标轴线条宽度
                'grid.linewidth': 0.6,  # 增大网格线条宽度
                'lines.linewidth': 2.0,  # 线条宽度
            })
            
            # 绘制条形图
            bars = plt.bar(algorithms, values, color=colors, width=0.6)
            plt.title(f'{metric_name} Comparison', fontsize=28, fontweight='bold')
            plt.xlabel('Algorithm', fontsize=24)
            plt.ylabel(metric_name, fontsize=24)
            plt.xticks(rotation=45, ha='right', fontsize=20)
            plt.yticks(fontsize=20)
            plt.grid(axis='y', linestyle='--', alpha=0.7)
            plt.ylim(0, 1.1)
            
            # 添加数据标签
            for bar, value in zip(bars, values):
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height + 0.02,
                       f'{value:.4f}', ha='center', va='bottom', fontsize=20)
            
            # 调整布局
            plt.tight_layout()
            
            # 保存图表
            chart_path = os.path.join(chart_dir, f'{task_type}_{metric}_comparison.png')
            plt.savefig(chart_path, bbox_inches='tight', dpi=300)
            logger.info(f"图表保存路径: {chart_path}")
            
            # 关闭图表
            plt.close()
    
    # 重置Matplotlib设置
    plt.rcParams.update(plt.rcParamsDefault)
    
    # 保存对比数据
    save_comparison_data(results, chart_dir, task_type)

def save_comparison_data(results, output_dir, task_type):
    """
    保存算法对比数据
    
    参数:
    results: 算法运行结果列表
    output_dir: 输出目录
    task_type: 任务类型
    """
    # 准备数据
    data = []
    for r in results:
        row = {'算法': r['name']}
        for metric, value in r['metrics'].items():
            row[metric.upper()] = value
        data.append(row)
    
    # 创建DataFrame
    df = pd.DataFrame(data)
    
    # 保存为CSV文件
    csv_path = os.path.join(output_dir, f'{task_type}_algorithm_comparison.csv')
    df.to_csv(csv_path, index=False, encoding='utf-8-sig')
    logger.info(f"对比数据保存路径: {csv_path}")

def run(args=None):
    """
    主函数
    """
    if args is None:
        args = parse_arguments()
    
    # 确定要运行的算法
    if args.algorithm:
        # 只运行指定的算法
        algorithms_to_run = args.algorithm
    else:
        # 运行所有算法
        algorithms_to_run = list(ALGORITHMS.keys())
    
    # 运行算法并收集结果
    results = []
    for algorithm in algorithms_to_run:
        result = run_algorithm(algorithm, args)
        if result:
            results.append(result)
    
    # 生成对比图表
    if len(results) > 1:
        generate_comparison_chart(results, args.output)
    
    logger.info(f"\n=== 任务完成 ===")
    logger.info(f"运行了 {len(results)} 个算法")
    
    if results:
        # 打印结果摘要
        logger.info("\n=== 结果摘要 ===")
        task_type = results[0]['task_type']
        
        if task_type == 'regression':
            logger.info(f"{'算法':<12} {'RMSE':<10} {'MAE':<10} {'R²':<10}")
            logger.info('-' * 50)
            for r in results:
                metrics = r['metrics']
                logger.info(f"{r['name']:<12} {metrics.get('rmse', 'N/A'):<10.4f} {metrics.get('mae', 'N/A'):<10.4f} {metrics.get('r2', 'N/A'):<10.4f}")
        else:
            logger.info(f"{'算法':<12} {'准确率':<10} {'精确率':<10} {'召回率':<10} {'F1值':<10}")
            logger.info('-' * 60)
            for r in results:
                metrics = r['metrics']
                logger.info(f"{r['name']:<12} {metrics.get('accuracy', 'N/A'):<10.4f} {metrics.get('precision', 'N/A'):<10.4f} {metrics.get('recall', 'N/A'):<10.4f} {metrics.get('f1', 'N/A'):<10.4f}")

if __name__ == '__main__':
    run()
