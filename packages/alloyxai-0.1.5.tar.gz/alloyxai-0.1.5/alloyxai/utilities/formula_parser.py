import re

"""
化学式解析模块
用于解析各种格式的化学表达式，支持带括号、空格、连字符的复杂化学式
"""

def parse_formula(formula):
    """
    解析化学式，支持带括号的复杂化学式
    
    参数:
        formula (str): 化学表达式字符串
        
    返回:
        dict: 元素及其原子数量的字典
        
    异常:
        ValueError: 当输入不是字符串类型时抛出
    """
    # 类型检查
    if not isinstance(formula, str): 
        raise ValueError("错误: 化学式必须是字符串类型")
        
    # 预处理：移除空格和连字符
    formula = formula.replace(' ', '').replace('-', '')
    
    # 存储元素及其数量
    element_counts = {}
    
    # 处理带括号的化学式的递归函数
    def parse_group(formula_segment, multiplier=1.0):
        i = 0
        while i < len(formula_segment):
            char = formula_segment[i]
            
            # 处理左括号
            if char == '(':
                # 找到匹配的右括号
                j = i + 1
                bracket_count = 1
                while j < len(formula_segment) and bracket_count > 0:
                    if formula_segment[j] == '(':
                        bracket_count += 1
                    elif formula_segment[j] == ')':
                        bracket_count -= 1
                    j += 1
                
                # 提取括号内的部分
                inner_segment = formula_segment[i+1:j-1]
                
                # 找到括号后的系数
                k = j
                coeff_str = ''
                while k < len(formula_segment) and (formula_segment[k].isdigit() or formula_segment[k] == '.'):
                    coeff_str += formula_segment[k]
                    k += 1
                
                # 计算系数
                coeff = float(coeff_str) if coeff_str else 1.0
                
                # 递归处理括号内的内容
                parse_group(inner_segment, multiplier * coeff)
                
                # 跳过已处理的部分
                i = k
            
            # 处理元素
            elif char.isupper():
                # 提取元素符号
                elem = char
                i += 1
                while i < len(formula_segment) and formula_segment[i].islower():
                    elem += formula_segment[i]
                    i += 1
                
                # 提取元素后的系数
                coeff_str = ''
                while i < len(formula_segment) and (formula_segment[i].isdigit() or formula_segment[i] == '.'):
                    coeff_str += formula_segment[i]
                    i += 1
                
                # 计算系数
                coeff = float(coeff_str) if coeff_str else 1.0
                
                # 更新元素计数
                if elem in element_counts:
                    element_counts[elem] += coeff * multiplier
                else:
                    element_counts[elem] = coeff * multiplier
            
            # 跳过其他字符
            else:
                i += 1
    
    # 开始解析
    parse_group(formula)
    
    # 过滤掉数量为0的元素
    filtered_element_counts = {elem: count for elem, count in element_counts.items() if count > 0}
    return filtered_element_counts


def get_elements_and_counts(formula):
    """
    获取元素列表和对应的原子数量列表
    
    参数:
        formula (str): 化学表达式字符串
        
    返回:
        tuple: (elements_list, counts_list)
    """
    element_counts = parse_formula(formula)
    elements = list(element_counts.keys())
    counts = list(element_counts.values())
    return elements, counts


def get_molar_fractions(formula):
    """
    计算元素的摩尔分数
    
    参数:
        formula (str): 化学表达式字符串
        
    返回:
        dict: 元素及其摩尔分数的字典
    """
    element_counts = parse_formula(formula)
    total_atoms = sum(element_counts.values())
    return {elem: count/total_atoms for elem, count in element_counts.items()}


if __name__ == "__main__":
    # 测试各种化学式格式
    test_formulas = [
        "(FeCoNi)86-Al7Ti7",
        "(FeCoNi)86-Al8Ti6",
        "Fe2Ni",          # 简单的二元合金
        "Fe0.2Ni0.3",     # 带小数系数的合金
        "(FeNi)3",        # 带括号的合金
        "FeNiCr",         # 三元合金
        "Fe Ni",          # 带空格的合金
        "Fe(NiCr)2",      # 嵌套括号的复杂合金
        "Fe-10Ni",        # 带连字符的合金
        "CuZn5",          # 简单的二元合金
        "(TiAl)3V2",      # 带括号的复杂合金
        "Al0.0HfNbZrTaTi"  # 测试零系数元素的过滤
    ]
    
    print("化学式解析测试")
    print("=" * 50)
    for formula in test_formulas:
        result = parse_formula(formula)
        print(f"{formula}: {result}")
    
    print("\n元素和原子数量测试")
    print("=" * 50)
    for formula in test_formulas:
        elements, counts = get_elements_and_counts(formula)
        print(f"{formula}: elements={elements}, counts={counts}")
    
    print("\n摩尔分数测试")
    print("=" * 50)
    for formula in test_formulas:
        fractions = get_molar_fractions(formula)
        print(f"{formula}: {fractions}")