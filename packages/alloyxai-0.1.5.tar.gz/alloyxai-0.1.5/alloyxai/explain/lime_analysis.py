﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LIME (Local Interpretable Model-agnostic Explanations) 分析工具

使用LIME库对机器学习模型进行可解释性分析，生成局部解释和可视化图表。
"""

import os
import argparse
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


import sys
import logging
import time

# 设置日志记录
def setup_logging():
    """
    设置日志记录
    
    返回:
    logger: 配置好的日志记录器
    """
    # 日志目录
    log_dir = os.path.join(os.getcwd(), 'results', 'logs')
    os.makedirs(log_dir, exist_ok=True)
    
    # 日志文件名
    log_filename = f'lime_analysis_{time.strftime("%Y%m%d_%H%M%S")}.log'
    log_path = os.path.join(log_dir, log_filename)
    
    # 配置日志
    logger = logging.getLogger('LIMEAnalysis')
    logger.setLevel(logging.INFO)
    
    # 清除已有的处理器
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # 文件处理器
    file_handler = logging.FileHandler(log_path, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)
    
    # 控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(console_handler)
    
    return logger

# 创建日志记录器
logger = setup_logging()
# 尝试导入LIME库
lime_available = False
try:
    from lime import lime_tabular
    lime_available = True
    logger.info("LIME库导入成功！")
except ImportError as e:
    logger.info(f"警告: LIME库导入失败: {e}")
    logger.info("LIME分析将不可用，请安装LIME库以启用此功能。")
    logger.info("安装命令: pip install lime")

# 设置Matplotlib全局样式
plt.rcParams.update({
    'font.size': 24,
    'font.family': 'Times New Roman',  # 期刊常用字体
    'axes.titlesize': 28,
    'axes.labelsize': 24,
    'xtick.labelsize': 20,
    'ytick.labelsize': 20,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'axes.linewidth': 1.2,
    'grid.linewidth': 0.6,
    'lines.linewidth': 2.0,
})

def load_model(model_path):
    """
    加载训练好的模型
    
    参数:
    model_path: 模型文件路径
    
    返回:
    model_info: 模型信息字典
    """
    logger.info(f"\n=== 加载模型 ===")
    logger.info(f"模型路径: {model_path}")
    
    try:
        model_info = joblib.load(model_path)
        logger.info(f"模型加载成功！")
        logger.info(f"任务类型: {model_info.get('task_type', '未知')}")
        logger.info(f"特征数量: {len(model_info.get('feature_names', []))}")
        return model_info
    except Exception as e:
        logger.error(f"错误: 模型加载失败: {e}")
        return None

def load_data(data_path, target_column=None):
    """
    加载数据
    
    参数:
    data_path: 数据文件路径
    target_column: 目标变量列名
    
    返回:
    X: 特征矩阵
    y: 目标变量（如果指定）
    feature_names: 特征名列表
    """
    logger.info(f"\n=== 加载数据 ===")
    logger.info(f"数据路径: {data_path}")
    
    try:
        # 根据文件扩展名选择读取方法
        if data_path.endswith('.csv'):
            df = pd.read_csv(data_path)
        elif data_path.endswith('.xlsx'):
            df = pd.read_excel(data_path)
        else:
            raise ValueError("不支持的文件格式，请使用CSV或Excel文件")
        
        logger.info(f"数据加载成功！")
        logger.info(f"样本数量: {df.shape[0]}")
        logger.info(f"总列数: {df.shape[1]}")
        
        # 确定目标变量
        if target_column:
            if target_column not in df.columns:
                raise ValueError(f"目标变量列 '{target_column}' 在数据中不存在")
        else:
            # 默认使用最后一列作为目标变量
            target_column = df.columns[-1]
        
        logger.info(f"目标变量: {target_column}")
        
        # 分离特征和目标变量
        X = df.drop(columns=[target_column])
        y = df[target_column]
        
        # 只保留数值型特征
        numeric_cols = X.select_dtypes(include=['number']).columns
        X = X[numeric_cols]
        
        feature_names = list(X.columns)
        logger.info(f"特征数量: {len(feature_names)}")
        
        return X, y, feature_names
    except Exception as e:
        logger.error(f"错误: 数据加载失败: {e}")
        return None, None, None

def get_lime_explainer(model, X, feature_names, task_type):
    """
    获取LIME解释器
    
    参数:
    model: 训练好的模型
    X: 特征矩阵
    feature_names: 特征名列表
    task_type: 任务类型
    
    返回:
    explainer: LIME解释器
    predict_fn: 预测函数
    """
    logger.info(f"\n=== 初始化LIME解释器 ===")
    
    try:
        # 转换为numpy数组
        X_np = np.array(X)
        
        # 根据任务类型确定预测函数
        if task_type == 'classification':
            # 分类任务使用predict_proba
            predict_fn = lambda x: model.predict_proba(x)
            mode = 'classification'
        else:
            # 回归任务使用predict
            predict_fn = lambda x: model.predict(x)
            mode = 'regression'
        
        # 创建LIME解释器
        explainer = lime_tabular.LimeTabularExplainer(
            training_data=X_np,
            feature_names=feature_names,
            class_names=['target'] if task_type == 'regression' else None,
            mode=mode
        )
        
        logger.info(f"LIME解释器初始化成功！")
        logger.info(f"任务类型: {task_type}")
        return explainer, predict_fn
    except Exception as e:
        logger.error(f"错误: LIME解释器初始化失败: {e}")
        return None, None

def explain_instance(explainer, predict_fn, instance, feature_names, output_dir, model_name, instance_idx):
    """
    解释单个实例
    
    参数:
    explainer: LIME解释器
    predict_fn: 预测函数
    instance: 要解释的实例
    feature_names: 特征名列表
    output_dir: 输出目录
    model_name: 模型名称
    instance_idx: 实例索引
    
    返回:
    explanation: LIME解释
    """
    logger.info(f"\n=== 解释实例 {instance_idx} ===")
    
    try:
        # 生成解释，限制特征数量以提高可读性
        max_features = min(15, len(feature_names))  # 最多显示15个特征
        explanation = explainer.explain_instance(
            data_row=instance,
            predict_fn=predict_fn,
            num_features=max_features
        )
        
        logger.info(f"实例解释成功！")
        
        # 保存解释结果
        explanation_path = os.path.join(output_dir, f"{model_name}_lime_explanation_{instance_idx}.html")
        explanation.save_to_file(explanation_path)
        logger.info(f"LIME解释HTML保存成功: {explanation_path}")
        
        # 绘制解释图 - 自定义实现以提高可读性
        plt.figure(figsize=(16, 12), dpi=300)
        
        # 获取解释数据
        exp_data = explanation.as_list()
        
        # 准备数据
        features = []
        values = []
        for feat, val in exp_data:
            features.append(feat)
            values.append(val)
        
        # 排序（按绝对值）
        sorted_indices = sorted(range(len(values)), key=lambda i: abs(values[i]), reverse=True)
        features = [features[i] for i in sorted_indices]
        values = [values[i] for i in sorted_indices]
        
        # 绘制水平条形图
        colors = ['red' if val < 0 else 'green' for val in values]
        y_pos = np.arange(len(features))
        
        plt.barh(y_pos, values, color=colors, height=0.6)
        plt.yticks(y_pos, features, fontsize=16)
        plt.xticks(fontsize=16)
        plt.xlabel('Impact on Prediction', fontsize=20)
        plt.ylabel('Feature', fontsize=20)
        plt.title(f'LIME Explanation for Instance {instance_idx}', fontsize=24, fontweight='bold')
        plt.grid(axis='x', linestyle='--', alpha=0.7)
        
        # 调整布局
        plt.tight_layout()
        
        # 保存图表
        plot_path = os.path.join(output_dir, f"{model_name}_lime_explanation_{instance_idx}.png")
        plt.savefig(plot_path, bbox_inches='tight', dpi=300)
        logger.info(f"LIME解释图保存成功: {plot_path}")
        plt.close()
        
        return explanation
    except Exception as e:
        logger.error(f"错误: 解释实例失败: {e}")
        return None

def explain_multiple_instances(explainer, predict_fn, X, feature_names, output_dir, model_name, num_instances=5):
    """
    解释多个实例
    
    参数:
    explainer: LIME解释器
    predict_fn: 预测函数
    X: 特征矩阵
    feature_names: 特征名列表
    output_dir: 输出目录
    model_name: 模型名称
    num_instances: 解释的实例数量
    
    返回:
    explanations: LIME解释列表
    """
    logger.info(f"\n=== 解释多个实例 ===")
    logger.info(f"将解释前 {num_instances} 个实例...")
    
    explanations = []
    
    try:
        # 限制实例数量
        num_instances = min(num_instances, len(X))
        
        for i in range(num_instances):
            instance = np.array(X.iloc[i])
            explanation = explain_instance(explainer, predict_fn, instance, feature_names, output_dir, model_name, i)
            if explanation:
                explanations.append(explanation)
        
        logger.info(f"成功解释 {len(explanations)} 个实例")
        return explanations
    except Exception as e:
        logger.error(f"错误: 解释多个实例失败: {e}")
        return []

def save_lime_summary(explanations, feature_names, output_dir, model_name):
    """
    保存LIME解释摘要
    
    参数:
    explanations: LIME解释列表
    feature_names: 特征名列表
    output_dir: 输出目录
    model_name: 模型名称
    """
    logger.info(f"\n=== 保存LIME解释摘要 ===")
    
    try:
        if not explanations:
            logger.info("警告: 没有解释结果可保存")
            return
        
        # 计算特征重要性
        feature_importance = {}
        for feature in feature_names:
            feature_importance[feature] = 0
        
        for explanation in explanations:
            for feature, weight in explanation.as_list():
                # 提取特征名
                for fname in feature_names:
                    if fname in feature:
                        feature_importance[fname] += abs(weight)
                        break
        
        # 转换为DataFrame
        importance_df = pd.DataFrame(
            list(feature_importance.items()),
            columns=['feature', 'importance']
        ).sort_values('importance', ascending=False)
        
        # 保存为CSV文件
        csv_path = os.path.join(output_dir, f"{model_name}_lime_feature_importance.csv")
        importance_df.to_csv(csv_path, index=False)
        logger.info(f"LIME特征重要性保存成功: {csv_path}")
        
        # 绘制特征重要性图
        plt.figure(figsize=(16, 12), dpi=300)
        plt.barh(importance_df['feature'][:10], importance_df['importance'][:10])
        plt.title('Top 10 Feature Importance (LIME)', fontsize=28, fontweight='bold')
        plt.xlabel('Importance', fontsize=24)
        plt.ylabel('Feature', fontsize=24)
        plt.xticks(fontsize=20)
        plt.yticks(fontsize=20)
        plt.grid(axis='x', linestyle='--', alpha=0.7)
        plt.tight_layout()
        
        # 保存图表
        plot_path = os.path.join(output_dir, f"{model_name}_lime_feature_importance.png")
        plt.savefig(plot_path, bbox_inches='tight', dpi=300)
        logger.info(f"LIME特征重要性图保存成功: {plot_path}")
        plt.close()
        
        return importance_df
    except Exception as e:
        logger.error(f"错误: 保存LIME解释摘要失败: {e}")
        return None

def main(args=None):
    """
    主函数
    
    参数:
    args: 参数对象，如果为None则从命令行解析
    """
    # 检查LIME库是否可用
    if not lime_available:
        logger.info("错误: LIME库不可用，无法执行LIME分析。")
        logger.info("请安装LIME库: pip install lime")
        return
    
    # 解析命令行参数
    if args is None:
        parser = argparse.ArgumentParser(
            description='LIME模型可解释性分析工具',
            epilog='''
使用示例:
    # 使用默认参数
    python lime_analysis.py -m path/to/model.joblib -d path/to/data.csv
    
    # 指定目标变量
    python lime_analysis.py -m path/to/model.joblib -d path/to/data.csv -t target_column
    
    # 指定输出目录
    python lime_analysis.py -m path/to/model.joblib -d path/to/data.csv -o path/to/output
        ''',
            formatter_class=argparse.RawDescriptionHelpFormatter
        )
        
        # 模型路径参数
        parser.add_argument('-m', '--model', type=str, required=True,
                            help='训练好的模型文件路径')
        
        # 数据文件路径参数
        parser.add_argument('-d', '--data', type=str, required=True,
                            help='数据文件路径')
        
        # 目标变量参数
        parser.add_argument('-t', '--target', type=str,
                            help='目标变量名称，默认使用最后一列')
        
        # 输出目录参数
        default_output = os.path.join(os.getcwd(), 'results', 'explanation', 'lime')
        parser.add_argument('-o', '--output', type=str, default=default_output,
                            help=f'输出目录，默认保存在 {default_output}')
        
        # 解析参数
        args = parser.parse_args()
    
    # 加载模型
    model_info = load_model(args.model)
    if not model_info:
        return
    
    # 加载数据
    X, y, feature_names = load_data(args.data, args.target)
    if X is None:
        return
    
    # 获取模型和任务类型
    model = model_info.get('model')
    task_type = model_info.get('task_type', 'regression')
    
    if not model:
        logger.info("错误: 模型信息中没有找到模型对象")
        return
    
    # 获取LIME解释器
    explainer, predict_fn = get_lime_explainer(model, X, feature_names, task_type)
    if not explainer:
        return
    
    # 创建输出目录
    os.makedirs(args.output, exist_ok=True)
    
    # 模型名称
    model_name = os.path.basename(args.model).split('.')[0]
    
    # 解释多个实例
    explanations = explain_multiple_instances(explainer, predict_fn, X, feature_names, args.output, model_name)
    
    # 保存LIME解释摘要
    importance_df = save_lime_summary(explanations, feature_names, args.output, model_name)
    
    # 打印结果摘要
    if importance_df is not None:
        logger.info(f"\n=== LIME特征重要性摘要 ===")
        logger.info(importance_df.head(10))
    
    logger.info(f"\n=== 分析完成 ===")
    logger.info(f"所有结果已保存到: {args.output}")

if __name__ == '__main__':
    main()
