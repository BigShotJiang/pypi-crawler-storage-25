﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
特征重要性分析工具

基于模型本身的特征重要性属性，对机器学习模型进行可解释性分析。
"""

import os
import argparse
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


import sys
import logging
import time

# 设置日志记录
def setup_logging():
    """
    设置日志记录
    
    返回:
    logger: 配置好的日志记录器
    """
    # 日志目录
    log_dir = os.path.join(os.getcwd(), 'results', 'logs')
    os.makedirs(log_dir, exist_ok=True)
    
    # 日志文件名
    log_filename = f'feature_importance_analysis_{time.strftime("%Y%m%d_%H%M%S")}.log'
    log_path = os.path.join(log_dir, log_filename)
    
    # 配置日志
    logger = logging.getLogger('FEATURE_IMPORTANCEAnalysis')
    logger.setLevel(logging.INFO)
    
    # 清除已有的处理器
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # 文件处理器
    file_handler = logging.FileHandler(log_path, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)
    
    # 控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(console_handler)
    
    return logger

# 创建日志记录器
logger = setup_logging()
# 设置Matplotlib全局样式
plt.rcParams.update({
    'font.size': 24,
    'font.family': 'Times New Roman',  # 期刊常用字体
    'axes.titlesize': 28,
    'axes.labelsize': 24,
    'xtick.labelsize': 20,
    'ytick.labelsize': 20,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'axes.linewidth': 1.2,
    'grid.linewidth': 0.6,
    'lines.linewidth': 2.0,
})

def load_model(model_path):
    """
    加载训练好的模型
    
    参数:
    model_path: 模型文件路径
    
    返回:
    model_info: 模型信息字典
    """
    logger.info(f"\n=== 加载模型 ===")
    logger.info(f"模型路径: {model_path}")
    
    try:
        model_info = joblib.load(model_path)
        logger.info(f"模型加载成功！")
        logger.info(f"任务类型: {model_info.get('task_type', '未知')}")
        logger.info(f"特征数量: {len(model_info.get('feature_names', []))}")
        return model_info
    except Exception as e:
        logger.error(f"错误: 模型加载失败: {e}")
        return None

def extract_feature_importance(model_info):
    """
    提取模型的特征重要性
    
    参数:
    model_info: 模型信息字典
    
    返回:
    feature_importance: 特征重要性字典
    """
    logger.info(f"\n=== 提取特征重要性 ===")
    
    try:
        model = model_info.get('model')
        feature_names = model_info.get('feature_names', [])
        
        if not model:
            logger.info("错误: 模型信息中没有找到模型对象")
            return None
        
        if not feature_names:
            logger.info("错误: 模型信息中没有找到特征名称")
            return None
        
        # 尝试从模型中提取特征重要性
        if hasattr(model, 'feature_importances_'):
            # 树模型的特征重要性
            importances = model.feature_importances_
            logger.info(f"成功提取特征重要性！")
            logger.info(f"特征重要性形状: {importances.shape}")
        elif hasattr(model, 'coef_'):
            # 线性模型的系数（绝对值作为重要性）
            importances = np.abs(model.coef_)
            # 如果是多分类问题，取平均值
            if len(importances.shape) > 1:
                importances = np.mean(importances, axis=0)
            logger.info(f"成功提取特征系数！")
            logger.info(f"特征系数形状: {importances.shape}")
        else:
            logger.info("警告: 模型不支持特征重要性提取")
            return None
        
        # 确保重要性数组与特征名称长度匹配
        if len(importances) != len(feature_names):
            logger.info("错误: 特征重要性长度与特征名称长度不匹配")
            return None
        
        # 创建特征重要性字典
        feature_importance = dict(zip(feature_names, importances))
        return feature_importance
    except Exception as e:
        logger.error(f"错误: 提取特征重要性失败: {e}")
        return None

def plot_feature_importance(feature_importance, output_dir, model_name, top_n=15):
    """
    绘制特征重要性图
    
    参数:
    feature_importance: 特征重要性字典
    output_dir: 输出目录
    model_name: 模型名称
    top_n: 绘制前N个重要特征
    """
    logger.info(f"\n=== 绘制特征重要性图 ===")
    
    try:
        # 转换为DataFrame并排序
        importance_df = pd.DataFrame(
            list(feature_importance.items()),
            columns=['feature', 'importance']
        ).sort_values('importance', ascending=False)
        
        # 取前N个重要特征
        top_features = importance_df.head(top_n)
        
        # 水平条形图
        plt.figure(figsize=(16, 12), dpi=300)
        plt.barh(top_features['feature'], top_features['importance'])
        plt.title(f'Top {top_n} Feature Importance', fontsize=28, fontweight='bold')
        plt.xlabel('Importance', fontsize=24)
        plt.ylabel('Feature', fontsize=24)
        plt.xticks(fontsize=20)
        plt.yticks(fontsize=20)
        plt.grid(axis='x', linestyle='--', alpha=0.7)
        plt.tight_layout()
        
        # 保存图表
        plot_path = os.path.join(output_dir, f"{model_name}_feature_importance.png")
        plt.savefig(plot_path, bbox_inches='tight', dpi=300)
        logger.info(f"特征重要性图保存成功: {plot_path}")
        
        # 垂直条形图
        plt.figure(figsize=(16, 12), dpi=300)
        plt.bar(top_features['feature'], top_features['importance'])
        plt.title(f'Top {top_n} Feature Importance', fontsize=28, fontweight='bold')
        plt.xlabel('Feature', fontsize=24)
        plt.ylabel('Importance', fontsize=24)
        plt.xticks(rotation=45, ha='right', fontsize=20)
        plt.yticks(fontsize=20)
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        
        # 保存图表
        plot_path = os.path.join(output_dir, f"{model_name}_feature_importance_vertical.png")
        plt.savefig(plot_path, bbox_inches='tight', dpi=300)
        logger.info(f"特征重要性垂直图保存成功: {plot_path}")
        
        plt.close('all')
        return importance_df
    except Exception as e:
        logger.error(f"错误: 绘制特征重要性图失败: {e}")
        return None

def save_feature_importance(feature_importance, output_dir, model_name):
    """
    保存特征重要性
    
    参数:
    feature_importance: 特征重要性字典
    output_dir: 输出目录
    model_name: 模型名称
    """
    logger.info(f"\n=== 保存特征重要性 ===")
    
    try:
        # 转换为DataFrame并排序
        importance_df = pd.DataFrame(
            list(feature_importance.items()),
            columns=['feature', 'importance']
        ).sort_values('importance', ascending=False)
        
        # 保存为CSV文件
        csv_path = os.path.join(output_dir, f"{model_name}_feature_importance.csv")
        importance_df.to_csv(csv_path, index=False)
        logger.info(f"特征重要性保存成功: {csv_path}")
        
        return importance_df
    except Exception as e:
        logger.error(f"错误: 保存特征重要性失败: {e}")
        return None

def analyze_permutation_importance(model_info, X, y, output_dir, model_name, n_repeats=10):
    """
    分析排列重要性
    
    参数:
    model_info: 模型信息字典
    X: 特征矩阵
    y: 目标变量
    output_dir: 输出目录
    model_name: 模型名称
    n_repeats: 重复次数
    
    返回:
    perm_importance_df: 排列重要性DataFrame
    """
    logger.info(f"\n=== 分析排列重要性 ===")
    
    try:
        from sklearn.inspection import permutation_importance
        
        model = model_info.get('model')
        feature_names = model_info.get('feature_names', [])
        task_type = model_info.get('task_type', 'regression')
        
        if not model:
            logger.info("错误: 模型信息中没有找到模型对象")
            return None
        
        logger.info(f"开始计算排列重要性...")
        logger.info(f"重复次数: {n_repeats}")
        
        # 计算排列重要性
        result = permutation_importance(
            model, X, y, n_repeats=n_repeats, random_state=42
        )
        
        # 整理结果
        perm_importance = result.importances_mean
        perm_importance_std = result.importances_std
        
        # 创建DataFrame
        perm_importance_df = pd.DataFrame({
            'feature': feature_names,
            'importance': perm_importance,
            'std': perm_importance_std
        }).sort_values('importance', ascending=False)
        
        logger.info(f"排列重要性计算成功！")
        
        # 保存为CSV文件
        csv_path = os.path.join(output_dir, f"{model_name}_permutation_importance.csv")
        perm_importance_df.to_csv(csv_path, index=False)
        logger.info(f"排列重要性保存成功: {csv_path}")
        
        # 绘制排列重要性图
        top_n = min(15, len(perm_importance_df))
        top_features = perm_importance_df.head(top_n)
        
        plt.figure(figsize=(16, 12), dpi=300)
        plt.barh(top_features['feature'], top_features['importance'], xerr=top_features['std'])
        plt.title(f'Top {top_n} Permutation Importance', fontsize=28, fontweight='bold')
        plt.xlabel('Importance', fontsize=24)
        plt.ylabel('Feature', fontsize=24)
        plt.xticks(fontsize=20)
        plt.yticks(fontsize=20)
        plt.grid(axis='x', linestyle='--', alpha=0.7)
        plt.tight_layout()
        
        # 保存图表
        plot_path = os.path.join(output_dir, f"{model_name}_permutation_importance.png")
        plt.savefig(plot_path, bbox_inches='tight', dpi=300)
        logger.info(f"排列重要性图保存成功: {plot_path}")
        
        plt.close()
        return perm_importance_df
    except ImportError:
        logger.info("警告: sklearn.inspection 模块不可用，无法计算排列重要性")
        return None
    except Exception as e:
        logger.error(f"错误: 分析排列重要性失败: {e}")
        return None

def load_data(data_path, target_column=None):
    """
    加载数据
    
    参数:
    data_path: 数据文件路径
    target_column: 目标变量列名
    
    返回:
    X: 特征矩阵
    y: 目标变量（如果指定）
    feature_names: 特征名列表
    """
    logger.info(f"\n=== 加载数据 ===")
    logger.info(f"数据路径: {data_path}")
    
    try:
        # 根据文件扩展名选择读取方法
        if data_path.endswith('.csv'):
            df = pd.read_csv(data_path)
        elif data_path.endswith('.xlsx'):
            df = pd.read_excel(data_path)
        else:
            raise ValueError("不支持的文件格式，请使用CSV或Excel文件")
        
        logger.info(f"数据加载成功！")
        logger.info(f"样本数量: {df.shape[0]}")
        logger.info(f"总列数: {df.shape[1]}")
        
        # 确定目标变量
        if target_column:
            if target_column not in df.columns:
                raise ValueError(f"目标变量列 '{target_column}' 在数据中不存在")
        else:
            # 默认使用最后一列作为目标变量
            target_column = df.columns[-1]
        
        logger.info(f"目标变量: {target_column}")
        
        # 分离特征和目标变量
        X = df.drop(columns=[target_column])
        y = df[target_column]
        
        # 只保留数值型特征
        numeric_cols = X.select_dtypes(include=['number']).columns
        X = X[numeric_cols]
        
        feature_names = list(X.columns)
        logger.info(f"特征数量: {len(feature_names)}")
        
        return X, y, feature_names
    except Exception as e:
        logger.error(f"错误: 数据加载失败: {e}")
        return None, None, None

def main(args=None):
    """
    主函数
    
    参数:
    args: 参数对象，如果为None则从命令行解析
    """
    # 解析命令行参数
    if args is None:
        parser = argparse.ArgumentParser(
            description='特征重要性分析工具',
            epilog='''
使用示例:
    # 使用默认参数
    python feature_importance_analysis.py -m path/to/model.joblib
    
    # 分析排列重要性
    python feature_importance_analysis.py -m path/to/model.joblib -d path/to/data.csv
        ''',
            formatter_class=argparse.RawDescriptionHelpFormatter
        )
        
        # 模型路径参数
        parser.add_argument('-m', '--model', type=str, required=True,
                            help='训练好的模型文件路径')
        
        # 数据文件路径参数（用于排列重要性分析）
        parser.add_argument('-d', '--data', type=str,
                            help='数据文件路径，用于排列重要性分析')
        
        # 目标变量参数
        parser.add_argument('-t', '--target', type=str,
                            help='目标变量名称，默认使用最后一列')
        
        # 输出目录参数
        default_output = os.path.join(os.getcwd(), 'results', 'explanation', 'feature_importance')
        parser.add_argument('-o', '--output', type=str, default=default_output,
                            help=f'输出目录，默认保存在 {default_output}')
        
        # 解析参数
        args = parser.parse_args()
    
    # 加载模型
    model_info = load_model(args.model)
    if not model_info:
        return
    
    # 提取特征重要性
    feature_importance = extract_feature_importance(model_info)
    if not feature_importance:
        return
    
    # 创建输出目录
    os.makedirs(args.output, exist_ok=True)
    
    # 模型名称
    model_name = os.path.basename(args.model).split('.')[0]
    
    # 绘制特征重要性图
    importance_df = plot_feature_importance(feature_importance, args.output, model_name)
    
    # 保存特征重要性
    save_feature_importance(feature_importance, args.output, model_name)
    
    # 如果提供了数据，分析排列重要性
    if args.data:
        X, y, feature_names = load_data(args.data, args.target)
        if X is not None:
            analyze_permutation_importance(model_info, X, y, args.output, model_name)
    
    # 打印结果摘要
    if importance_df is not None:
        logger.info(f"\n=== 特征重要性摘要 ===")
        logger.info(importance_df.head(10))
    
    logger.info(f"\n=== 分析完成 ===")
    logger.info(f"所有结果已保存到: {args.output}")

if __name__ == '__main__':
    main()
