﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDP (Partial Dependence Plot) 可解释性分析模块

实现PDP可解释性分析，生成PDP值和可视化图表。

使用说明:
==========
1. 单独运行 PDP 分析:
   python explanation/pdp_analysis.py -m <模型文件路径> -d <数据文件路径>

2. 指定输出目录:
   python explanation/pdp_analysis.py -m <模型文件路径> -d <数据文件路径> -o <输出目录>

3. 指定目标变量列名:
   python explanation/pdp_analysis.py -m <模型文件路径> -d <数据文件路径> -t <目标变量列名>

4. 完整示例 (使用项目中的模型和数据):
   python explanation/pdp_analysis.py -m results/alloy_machine_learning/decision_tree/models/regression_decision_tree_model_quick.joblib -d results/descript_data_clean/three_columns_processed_processed_1_cleaned_cleaned_processed.csv -t "Yield_Strength (MPa)" -o results/explanation/pdp

参数说明:
=========
-m, --model   : 训练好的模型文件路径 (必需)
-d, --data    : 数据文件路径 (CSV或Excel格式) (必需)
-t, --target  : 目标变量列名 (可选，默认使用最后一列)
-o, --output  : 输出目录 (可选，默认 results/pdp)

输出结果:
=========
1. 单个特征的 PDP 图: pdp_plot_<feature_name>.png
2. PDP 特征重要性摘要图: pdp_feature_importance_summary.png
3. PDP 特征重要性数据: pdp_feature_importance.csv
4. 各特征的 PDP 值: pdp_values_<feature_name>.csv
5. 执行日志: 保存到 results/logs/pdp_analysis_YYYYMMDD_HHMMSS.log

注意事项:
=========
- 模型文件需要是通过 machine_learning.py 或 heaML 目录下的算法训练得到的
- 数据文件需要包含与训练模型时相同的特征列
- 输出目录会自动创建，如果不存在的话
- 所有日志信息会同时输出到控制台和日志文件
"""

import os
import sys
import logging
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.inspection import PartialDependenceDisplay

# 设置日志记录
def setup_logging():
    """
    设置日志记录
    
    返回:
    logger: 配置好的日志记录器
    """
    # 日志目录
    log_dir = os.path.join(os.getcwd(), 'results', 'logs')
    os.makedirs(log_dir, exist_ok=True)
    
    # 日志文件名
    log_filename = f'pdp_analysis_{time.strftime("%Y%m%d_%H%M%S")}.log'
    log_path = os.path.join(log_dir, log_filename)
    
    # 配置日志
    logger = logging.getLogger('PDP_Analysis')
    logger.setLevel(logging.INFO)
    
    # 清除已有的处理器
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # 文件处理器
    file_handler = logging.FileHandler(log_path, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)
    
    # 控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(console_handler)
    
    return logger

# 创建日志记录器
logger = setup_logging()

# 设置Matplotlib全局样式
plt.rcParams.update({
    'font.size': 14,
    'font.family': 'Times New Roman',  # 期刊常用字体
    'axes.titlesize': 18,
    'axes.labelsize': 16,
    'xtick.labelsize': 14,
    'ytick.labelsize': 14,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'axes.linewidth': 1.2,
    'grid.linewidth': 0.6,
    'lines.linewidth': 2.0,
})

def load_model(model_path):
    """
    加载模型
    
    参数:
    model_path: 模型文件路径
    
    返回:
    model: 加载的模型
    """
    logger.info(f"\n=== 加载模型 ===")
    logger.info(f"模型路径: {model_path}")
    
    import joblib
    try:
        model = joblib.load(model_path)
        logger.info(f"模型加载成功！")
        logger.info(f"模型类型: {type(model).__name__}")
        return model
    except Exception as e:
        logger.error(f"错误: 模型加载失败: {e}")
        return None

def load_data(data_path, target_column=None):
    """
    加载数据
    
    参数:
    data_path: 数据文件路径
    target_column: 目标变量列名
    
    返回:
    X: 特征矩阵
    y: 目标变量
    feature_names: 特征名称列表
    """
    logger.info(f"\n=== 加载数据 ===")
    logger.info(f"数据路径: {data_path}")
    
    try:
        # 根据文件扩展名选择加载方法
        if data_path.endswith('.csv'):
            data = pd.read_csv(data_path)
        elif data_path.endswith('.xlsx'):
            data = pd.read_excel(data_path)
        else:
            logger.error(f"错误: 不支持的文件格式: {data_path}")
            return None, None, None
        
        logger.info(f"数据加载成功！")
        logger.info(f"数据形状: {data.shape}")
        
        # 处理目标变量
        if target_column:
            if target_column not in data.columns:
                logger.error(f"错误: 目标变量 '{target_column}' 不存在于数据中")
                return None, None, None
            y = data[target_column]
            X = data.drop(columns=[target_column])
        else:
            # 默认使用最后一列作为目标变量
            y = data.iloc[:, -1]
            X = data.iloc[:, :-1]
        
        feature_names = X.columns.tolist()
        logger.info(f"特征数量: {len(feature_names)}")
        logger.info(f"特征名称: {feature_names}")
        logger.info(f"目标变量: {y.name}")
        
        return X, y, feature_names
    except Exception as e:
        logger.error(f"错误: 数据加载失败: {e}")
        return None, None, None

def compute_pdp(model, X, feature_names, n_bins=10):
    """
    计算PDP值和ICE值
    
    参数:
    model: 训练好的模型
    X: 特征矩阵
    feature_names: 特征名称列表
    n_bins: 分箱数量
    
    返回:
    pdp_values: PDP值字典
    feature_bins: 特征分箱字典
    """
    logger.info(f"\n=== 计算PDP值和ICE值 ===")
    
    try:
        pdp_values = {}
        feature_bins = {}
        
        # 处理模型字典结构
        if isinstance(model, dict) and 'model' in model:
            logger.info("检测到模型字典结构，提取实际模型...")
            actual_model = model['model']
            # 提取模型使用的特征名称
            if 'feature_names' in model:
                model_feature_names = model['feature_names']
                logger.info(f"模型使用的特征: {model_feature_names}")
                # 只保留模型使用的特征中在数据中存在的特征
                existing_features = [feature for feature in model_feature_names if feature in X.columns]
                missing_features = [feature for feature in model_feature_names if feature not in X.columns]
                if missing_features:
                    logger.warning(f"警告: 以下特征在数据中不存在，将被跳过: {missing_features}")
                if existing_features:
                    X = X[existing_features]
                    feature_names = existing_features
                else:
                    logger.error("错误: 模型使用的特征在数据中都不存在")
                    return None, None
        else:
            actual_model = model
        
        # 转换为numpy数组
        X_np = X.values
        
        # 对每个特征计算PDP和ICE
        for i, feature_name in enumerate(feature_names):
            logger.info(f"计算特征 '{feature_name}' 的PDP值和ICE值...")
            
            try:
                # 使用PartialDependenceDisplay计算PDP和ICE
                # kind='both'表示同时计算PDP和ICE
                disp = PartialDependenceDisplay.from_estimator(
                    actual_model, X_np,
                    features=[i],
                    feature_names=feature_names,
                    kind='both',  # 'both'表示同时计算PDP和ICE
                    n_cols=1,
                    grid_resolution=n_bins,  # 在新版本中，n_bins改为grid_resolution
                    random_state=42
                )
                
                # 获取PDP值和分箱
                pdp_values[feature_name] = disp
                # 保存实际模型，以便后续使用
                disp.estimator_ = actual_model
                # 保存X和特征名称，以便后续使用
                disp.X_ = X_np
                disp.feature_names_ = feature_names
                
                plt.close()  # 关闭当前图表，避免内存占用
            except ValueError as e:
                if "percentiles are too close to each other" in str(e):
                    logger.warning(f"警告: 特征 '{feature_name}' 的percentiles太接近，无法计算PDP值，跳过该特征")
                    plt.close()
                    continue
                else:
                    raise
            except Exception as e:
                logger.error(f"错误: 计算特征 '{feature_name}' 的PDP值和ICE值失败: {e}")
                plt.close()
                continue
        
        logger.info(f"\nPDP值和ICE值计算完成！")
        return pdp_values, feature_bins
    except Exception as e:
        logger.error(f"错误: PDP值和ICE值计算失败: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return None, None

def plot_pdp(pdp_values, feature_names, output_dir):
    """
    绘制PDP-ICE图
    
    参数:
    pdp_values: PDP值字典
    feature_names: 特征名称列表
    output_dir: 输出目录
    """
    logger.info(f"\n=== 绘制PDP-ICE图 ===")
    
    try:
        # 为每个特征绘制PDP-ICE图
        for feature_name in pdp_values:
            logger.info(f"绘制特征 '{feature_name}' 的PDP-ICE图...")
            
            # 获取PDP显示对象
            disp = pdp_values[feature_name]
            
            # 创建图表
            fig, ax = plt.subplots(figsize=(10, 6))
            
            # 重新计算PDP和ICE并绘制
            from sklearn.inspection import PartialDependenceDisplay
            
            # 提取模型和数据
            model = disp.estimator_
            X = disp.X_
            # 使用过滤后的特征名称列表
            filtered_feature_names = disp.feature_names_
            
            try:
                feature_idx = filtered_feature_names.index(feature_name)
                
                # 绘制PDP-ICE图
                # 首先绘制ICE曲线（individual conditional expectations）
                PartialDependenceDisplay.from_estimator(
                    model, X,
                    features=[feature_idx],
                    feature_names=filtered_feature_names,
                    kind='individual',  # 只绘制ICE曲线
                    ax=ax,
                    random_state=42
                )
                
                # 然后计算并绘制PDP曲线（average）
                from sklearn.inspection import partial_dependence
                
                # 计算PDP值
                pdp_results = partial_dependence(
                    model, X,
                    features=[feature_idx],
                    feature_names=filtered_feature_names,
                    kind='average',  # 只计算PDP
                    grid_resolution=10
                )
                
                # 获取PDP值和特征值（勿用名 pdp_values，否则会覆盖外层 PDP 字典导致后续特征循环崩溃）
                feature_values = pdp_results['grid_values'][0]
                pdp_average = pdp_results['average'][0]
                
                # 绘制PDP曲线为橙色虚线
                ax.plot(feature_values, pdp_average, 'orange', linestyle='--', linewidth=2.5, label='average')
                
                # 更新图例
                ax.legend(['ICE curves', 'average'], loc='upper right')
                # 获取图例并修改线条样式
                legend = ax.get_legend()
                if legend and legend.legend_handles:
                    # 修改average图例
                    for i, handle in enumerate(legend.legend_handles):
                        if legend.get_texts()[i].get_text() == 'average':
                            handle.set_color('orange')
                            handle.set_linestyle('--')
                            handle.set_linewidth(2.5)
                
                # 设置图表标题和标签
                ax.set_title(f'PDP-ICE Plot for {feature_name}', fontsize=18, fontweight='bold')
                ax.set_xlabel(feature_name, fontsize=16)
                ax.set_ylabel('Partial Dependence', fontsize=16)
                
                # 保存图表，使用包含pdp-ice的文件名格式
                plot_path = os.path.join(output_dir, f'pdp-ice_plot_{feature_name}.png')
                plt.savefig(plot_path, bbox_inches='tight', dpi=300)
                logger.info(f"PDP-ICE图保存成功: {plot_path}")
            except ValueError as e:
                if "percentiles are too close to each other" in str(e):
                    logger.warning(f"警告: 特征 '{feature_name}' 的percentiles太接近，无法绘制PDP-ICE图，跳过该特征")
                else:
                    logger.error(f"错误: 绘制特征 '{feature_name}' 的PDP-ICE图失败: {e}")
            except Exception as e:
                logger.error(f"错误: 绘制特征 '{feature_name}' 的PDP-ICE图失败: {e}")
            finally:
                plt.close()
        
        logger.info(f"\n所有PDP-ICE图绘制完成！")
    except Exception as e:
        logger.error(f"错误: PDP-ICE图绘制失败: {e}")
        import traceback
        logger.error(traceback.format_exc())

def plot_pdp_summary(pdp_values, feature_names, output_dir):
    """
    绘制PDP摘要图
    
    参数:
    pdp_values: PDP值字典
    feature_names: 特征名称列表
    output_dir: 输出目录
    """
    logger.info(f"\n=== 绘制PDP摘要图 ===")
    
    try:
        # 计算每个特征的PDP范围（作为重要性指标）
        pdp_ranges = {}
        for feature_name in pdp_values:
            disp = pdp_values[feature_name]
            
            # 提取模型和数据
            model = disp.estimator_
            X = disp.X_
            # 使用过滤后的特征名称列表
            filtered_feature_names = disp.feature_names_
            
            try:
                feature_idx = filtered_feature_names.index(feature_name)
                
                # 使用特征值的范围作为重要性指标
                feature_values = X[:, feature_idx]
                feature_range = np.max(feature_values) - np.min(feature_values)
                pdp_ranges[feature_name] = feature_range
            except Exception as e:
                logger.warning(f"警告: 计算特征 '{feature_name}' 的重要性失败: {e}")
                continue
        
        if not pdp_ranges:
            logger.warning("警告: 没有成功计算任何特征的PDP重要性")
            return
        
        # 按PDP范围排序
        sorted_features = sorted(pdp_ranges.items(), key=lambda x: x[1], reverse=True)
        
        # 限制显示的特征数量，提高可读性
        max_features = min(20, len(sorted_features))
        sorted_features = sorted_features[:max_features]
        
        # 绘制摘要图
        # 根据特征数量调整图表大小
        fig_height = max(8, len(sorted_features) * 0.4)
        fig, ax = plt.subplots(figsize=(12, fig_height))
        
        features, ranges = zip(*sorted_features)
        y_pos = np.arange(len(features))
        
        # 使用更美观的颜色
        bars = ax.barh(y_pos, ranges, align='center', color='#4a7ba7')
        
        # 添加数据标签
        for i, (bar, value) in enumerate(zip(bars, ranges)):
            ax.text(bar.get_width() + 0.1, bar.get_y() + bar.get_height()/2, 
                    f'{value:.2f}', va='center', fontsize=12)
        
        ax.set_yticks(y_pos)
        # 确保特征名称完整显示
        ax.set_yticklabels(features, fontsize=12, ha='right')
        ax.invert_yaxis()  # 使最重要的特征在顶部
        ax.set_xlabel('PDP Range (Importance)', fontsize=16)
        ax.set_ylabel('Feature', fontsize=16)
        ax.set_title('PDP Feature Importance Summary', fontsize=18, fontweight='bold')
        
        # 添加网格线
        ax.grid(axis='x', linestyle='--', alpha=0.7)
        
        # 调整布局
        plt.tight_layout()
        
        # 保存图表
        summary_path = os.path.join(output_dir, 'pdp_feature_importance_summary.png')
        plt.savefig(summary_path, bbox_inches='tight', dpi=300)
        logger.info(f"PDP摘要图保存成功: {summary_path}")
        
        # 保存特征重要性数据
        importance_df = pd.DataFrame(sorted_features, columns=['feature', 'importance'])
        importance_csv_path = os.path.join(output_dir, 'pdp_feature_importance.csv')
        importance_df.to_csv(importance_csv_path, index=False)
        logger.info(f"PDP特征重要性数据保存成功: {importance_csv_path}")
        
        plt.close()
        logger.info(f"\nPDP摘要图绘制完成！")
    except Exception as e:
        logger.error(f"错误: PDP摘要图绘制失败: {e}")
        import traceback
        logger.error(traceback.format_exc())

def save_pdp_values(pdp_values, feature_names, output_dir):
    """
    保存PDP值
    
    参数:
    pdp_values: PDP值字典
    feature_names: 特征名称列表
    output_dir: 输出目录
    """
    logger.info(f"\n=== 保存PDP值 ===")
    
    try:
        # 为每个特征保存PDP值
        for feature_name in pdp_values:
            logger.info(f"保存特征 '{feature_name}' 的PDP值...")
            
            disp = pdp_values[feature_name]
            
            # 提取模型和数据
            model = disp.estimator_
            X = disp.X_
            # 使用过滤后的特征名称列表
            filtered_feature_names = disp.feature_names_
            
            try:
                feature_idx = filtered_feature_names.index(feature_name)
                
                # 保存特征值分布
                feature_values = X[:, feature_idx]
                # 创建DataFrame
                pdp_df = pd.DataFrame({
                    'feature_value': feature_values
                })
                
                # 保存到CSV
                pdp_csv_path = os.path.join(output_dir, f'pdp_values_{feature_name}.csv')
                pdp_df.to_csv(pdp_csv_path, index=False)
                logger.info(f"PDP值保存成功: {pdp_csv_path}")
            except Exception as e:
                logger.warning(f"警告: 保存特征 '{feature_name}' 的PDP值失败: {e}")
                continue
        
        logger.info(f"\n所有PDP值保存完成！")
    except Exception as e:
        logger.error(f"错误: PDP值保存失败: {e}")
        import traceback
        logger.error(traceback.format_exc())

def main(args):
    """
    主函数
    
    参数:
    args: 命令行参数对象
    """
    logger.info("\n=== PDP 可解释性分析 ===")
    logger.info("=" * 60)
    
    # 加载模型
    model = load_model(args.model)
    if not model:
        logger.error("错误: 无法加载模型")
        return
    
    # 加载数据
    X, y, feature_names = load_data(args.data, args.target)
    if X is None or y is None:
        logger.error("错误: 无法加载数据")
        return

    # 与训练一致：字典模型中若含已拟合 scaler（如 KNN），先标准化特征再算 PDP
    if isinstance(model, dict) and 'model' in model:
        scaler = model.get('scaler')
        if scaler is not None and hasattr(scaler, 'mean_'):
            cols = X.columns.tolist()
            X = pd.DataFrame(scaler.transform(X), columns=cols, index=X.index)
            logger.info("PDP: 已对特征矩阵应用模型自带的 StandardScaler")
        elif scaler is not None:
            logger.warning("PDP: 模型 scaler 未拟合，使用原始特征（建议重新训练 KNN 等以写入 scaler）")
    
    # 创建输出目录
    os.makedirs(args.output, exist_ok=True)
    logger.info(f"\n输出目录: {args.output}")
    
    # 计算PDP值
    pdp_values, feature_bins = compute_pdp(model, X, feature_names)
    if pdp_values is None:
        logger.error("错误: 无法计算PDP值")
        return
    
    # 绘制PDP图
    plot_pdp(pdp_values, feature_names, args.output)
    
    # 绘制PDP摘要图
    plot_pdp_summary(pdp_values, feature_names, args.output)
    
    # 保存PDP值
    save_pdp_values(pdp_values, feature_names, args.output)
    
    logger.info("\n=== 分析完成 ===")
    logger.info(f"所有结果已保存到: {args.output}")

if __name__ == '__main__':
    import argparse
    
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='PDP 可解释性分析工具')
    parser.add_argument('-m', '--model', type=str, required=True, help='模型文件路径')
    parser.add_argument('-d', '--data', type=str, required=True, help='数据文件路径')
    parser.add_argument('-t', '--target', type=str, help='目标变量名称')
    parser.add_argument('-o', '--output', type=str, default='results/explanation/pdp', help='输出目录')
    
    args = parser.parse_args()
    main(args)
