﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SHAP (SHapley Additive exPlanations) 分析工具

使用SHAP库对机器学习模型进行可解释性分析，生成SHAP值和可视化图表。
"""

import os
import argparse
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


import sys
import logging
import time

# 设置日志记录
def setup_logging():
    """
    设置日志记录
    
    返回:
    logger: 配置好的日志记录器
    """
    # 日志目录
    log_dir = os.path.join(os.getcwd(), 'results', 'logs')
    os.makedirs(log_dir, exist_ok=True)
    
    # 日志文件名
    log_filename = f'shap_analysis_{time.strftime("%Y%m%d_%H%M%S")}.log'
    log_path = os.path.join(log_dir, log_filename)
    
    # 配置日志
    logger = logging.getLogger('SHAPAnalysis')
    logger.setLevel(logging.INFO)
    
    # 清除已有的处理器
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # 文件处理器
    file_handler = logging.FileHandler(log_path, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)
    
    # 控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(console_handler)
    
    return logger

# 创建日志记录器
logger = setup_logging()
# 尝试导入SHAP库
shap_available = False
try:
    import shap
    shap_available = True
    logger.info("SHAP库导入成功！")
except ImportError as e:
    logger.info(f"警告: SHAP库导入失败: {e}")
    logger.info("SHAP分析将不可用，请安装SHAP库以启用此功能。")
    logger.info("安装命令: pip install shap")

# 设置Matplotlib全局样式
plt.rcParams.update({
    'font.size': 24,
    'font.family': 'Times New Roman',  # 期刊常用字体
    'axes.titlesize': 28,
    'axes.labelsize': 24,
    'xtick.labelsize': 20,
    'ytick.labelsize': 20,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'axes.linewidth': 1.2,
    'grid.linewidth': 0.6,
    'lines.linewidth': 2.0,
})

def load_model(model_path):
    """
    加载训练好的模型
    
    参数:
    model_path: 模型文件路径
    
    返回:
    model_info: 模型信息字典
    """
    logger.info(f"\n=== 加载模型 ===")
    logger.info(f"模型路径: {model_path}")
    
    try:
        model_info = joblib.load(model_path)
        logger.info(f"模型加载成功！")
        logger.info(f"任务类型: {model_info.get('task_type', '未知')}")
        logger.info(f"特征数量: {len(model_info.get('feature_names', []))}")
        return model_info
    except Exception as e:
        logger.error(f"错误: 模型加载失败: {e}")
        return None

def load_data(data_path, target_column=None):
    """
    加载数据
    
    参数:
    data_path: 数据文件路径
    target_column: 目标变量列名
    
    返回:
    X: 特征矩阵
    y: 目标变量（如果指定）
    feature_names: 特征名列表
    """
    logger.info(f"\n=== 加载数据 ===")
    logger.info(f"数据路径: {data_path}")
    
    try:
        # 根据文件扩展名选择读取方法
        if data_path.endswith('.csv'):
            df = pd.read_csv(data_path)
        elif data_path.endswith('.xlsx'):
            df = pd.read_excel(data_path)
        else:
            raise ValueError("不支持的文件格式，请使用CSV或Excel文件")
        
        logger.info(f"数据加载成功！")
        logger.info(f"样本数量: {df.shape[0]}")
        logger.info(f"总列数: {df.shape[1]}")
        
        # 确定目标变量
        if target_column:
            if target_column not in df.columns:
                raise ValueError(f"目标变量列 '{target_column}' 在数据中不存在")
        else:
            # 默认使用最后一列作为目标变量
            target_column = df.columns[-1]
        
        logger.info(f"目标变量: {target_column}")
        
        # 分离特征和目标变量
        X = df.drop(columns=[target_column])
        y = df[target_column]
        
        # 只保留数值型特征
        numeric_cols = X.select_dtypes(include=['number']).columns
        X = X[numeric_cols]
        
        feature_names = list(X.columns)
        logger.info(f"特征数量: {len(feature_names)}")
        
        return X, y, feature_names
    except Exception as e:
        logger.error(f"错误: 数据加载失败: {e}")
        return None, None, None

def get_shap_explainer(model, X):
    """
    获取SHAP解释器
    
    参数:
    model: 训练好的模型
    X: 特征矩阵
    
    返回:
    explainer: SHAP解释器
    """
    logger.info(f"\n=== 初始化SHAP解释器 ===")
    
    try:
        # 转换为numpy数组
        X_np = X.values if hasattr(X, 'values') else X
        
        # 树/线性等可直接传模型；KNN、SVR、MLP 等会报 TypeError，需用 predict 包装
        try:
            explainer = shap.Explainer(model, X_np)
        except TypeError as te:
            err = str(te).lower()
            if 'not callable' in err or 'analyzed directly' in err:
                logger.info("使用 model.predict 构造 Explainer（适用于 KNN、SVM、MLP 等）")
                explainer = shap.Explainer(model.predict, X_np)
            else:
                raise

        logger.info(f"SHAP解释器初始化成功！")
        return explainer
    except Exception as e:
        logger.error(f"错误: SHAP解释器初始化失败: {e}")
        return None

def generate_shap_values(explainer, X):
    """
    生成SHAP值
    
    参数:
    explainer: SHAP解释器
    X: 特征矩阵
    
    返回:
    shap_values: SHAP值
    """
    logger.info(f"\n=== 生成SHAP值 ===")
    
    try:
        # 转换为numpy数组
        X_np = X.values if hasattr(X, 'values') else X
        
        shap_values = explainer(X_np)
        logger.info(f"SHAP值生成成功！")
        logger.info(f"SHAP值类型: {type(shap_values)}")
        
        # 处理SHAP值格式
        if hasattr(shap_values, 'values'):
            logger.info(f"SHAP值形状: {shap_values.values.shape}")
            return shap_values
        else:
            logger.info(f"SHAP值形状: {shap_values.shape}")
            return shap_values
    except Exception as e:
        logger.error(f"错误: SHAP值生成失败: {e}")
        return None

def plot_shap_summary(shap_values, X, feature_names, output_dir, model_name):
    """
    绘制SHAP摘要图
    
    参数:
    shap_values: SHAP值
    X: 特征矩阵
    feature_names: 特征名列表
    output_dir: 输出目录
    model_name: 模型名称
    """
    logger.info(f"\n=== 绘制SHAP摘要图 ===")
    
    try:
        # 确保输出目录存在
        os.makedirs(output_dir, exist_ok=True)
        
        # 转换为numpy数组
        X_np = X.values if hasattr(X, 'values') else X
        
        # 处理SHAP值格式
        if hasattr(shap_values, 'values'):
            shap_values_np = shap_values.values
        else:
            shap_values_np = shap_values
        
        # 计算特征重要性并排序
        feature_importance = np.abs(shap_values_np).mean(0)
        sorted_indices = np.argsort(feature_importance)[::-1]
        sorted_features = [feature_names[i] for i in sorted_indices]
        sorted_shap_values = shap_values_np[:, sorted_indices]
        sorted_X = X_np[:, sorted_indices]
        
        # 限制特征数量以提高可读性
        # 图表中只显示前10个重要特征，使图表更加美观
        max_features_plot = min(10, len(sorted_features))
        top_features_plot = sorted_features[:max_features_plot]
        top_shap_values_plot = sorted_shap_values[:, :max_features_plot]
        top_X_plot = sorted_X[:, :max_features_plot]
        
        # 绘制优化的摘要图
        plt.figure(figsize=(18, 14), dpi=300)
        
        # 使用兼容的参数
        shap.summary_plot(
            top_shap_values_plot, 
            top_X_plot, 
            feature_names=top_features_plot, 
            show=False,
            cmap='coolwarm'  # 使用更美观的颜色映射
        )
        
        # 调整布局
        plt.tight_layout()
        
        # 保存图表
        plot_path = os.path.join(output_dir, f"{model_name}_shap_summary.png")
        plt.savefig(plot_path, bbox_inches='tight', dpi=300)
        logger.info(f"SHAP摘要图保存成功: {plot_path}")
        
        # 绘制优化的条形图
        plt.figure(figsize=(18, 14), dpi=300)
        
        shap.summary_plot(
            top_shap_values_plot, 
            top_X_plot, 
            feature_names=top_features_plot, 
            plot_type="bar", 
            show=False
        )
        
        # 调整布局
        plt.tight_layout()
        
        # 保存图表
        plot_path = os.path.join(output_dir, f"{model_name}_shap_bar.png")
        plt.savefig(plot_path, bbox_inches='tight', dpi=300)
        logger.info(f"SHAP条形图保存成功: {plot_path}")
        
        plt.close('all')
    except Exception as e:
        logger.error(f"错误: 绘制SHAP摘要图失败: {e}")

def plot_shap_dependence(shap_values, X, feature_names, output_dir, model_name, top_n=5):
    """
    绘制SHAP依赖图
    
    参数:
    shap_values: SHAP值
    X: 特征矩阵
    feature_names: 特征名列表
    output_dir: 输出目录
    model_name: 模型名称
    top_n: 绘制前N个重要特征的依赖图
    """
    logger.info(f"\n=== 绘制SHAP依赖图 ===")
    
    try:
        # 转换为numpy数组
        X_np = X.values if hasattr(X, 'values') else X
        
        # 处理SHAP值格式
        if hasattr(shap_values, 'values'):
            shap_values_np = shap_values.values
        else:
            shap_values_np = shap_values
        
        # 计算特征重要性
        feature_importance = np.abs(shap_values_np).mean(0)
        top_indices = np.argsort(feature_importance)[-top_n:]
        
        for i, idx in enumerate(top_indices):
            feature_name = feature_names[idx]
            logger.info(f"绘制特征 '{feature_name}' 的依赖图...")
            
            # 绘制依赖图
            plt.figure(figsize=(14, 10), dpi=300)
            
            # 使用自定义参数绘制依赖图
            shap.dependence_plot(
                idx, 
                shap_values_np, 
                X_np, 
                feature_names=feature_names, 
                show=False,
                interaction_index=None  # 不显示交互项，简化图表
            )
            
            # 调整y轴标签为一行
            plt.ylabel(f"SHAP value for {feature_name}", fontsize=22)
            plt.xlabel(feature_name, fontsize=22)
            plt.title(f"SHAP Dependence Plot for {feature_name}", fontsize=26, fontweight='bold')
            
            # 调整布局
            plt.tight_layout()
            
            # 保存图表 - 使用更合理的命名格式
            plot_path = os.path.join(output_dir, f"{model_name}_shap_dependence_{i+1}_{feature_name}.png")
            plt.savefig(plot_path, bbox_inches='tight', dpi=300)
            logger.info(f"SHAP依赖图保存成功: {plot_path}")
        
        plt.close('all')
    except Exception as e:
        logger.error(f"错误: 绘制SHAP依赖图失败: {e}")

def save_shap_values(shap_values, feature_names, output_dir, model_name):
    """
    保存SHAP值
    
    参数:
    shap_values: SHAP值
    feature_names: 特征名列表
    output_dir: 输出目录
    model_name: 模型名称
    """
    logger.info(f"\n=== 保存SHAP值 ===")
    
    try:
        # 确保输出目录存在
        os.makedirs(output_dir, exist_ok=True)
        
        # 处理SHAP值格式
        if hasattr(shap_values, 'values'):
            shap_values_np = shap_values.values
        else:
            shap_values_np = shap_values
        
        # 将SHAP值转换为DataFrame
        shap_df = pd.DataFrame(shap_values_np, columns=feature_names)
        
        # 保存为CSV文件
        csv_path = os.path.join(output_dir, f"{model_name}_shap_values.csv")
        shap_df.to_csv(csv_path, index=False)
        logger.info(f"SHAP值保存成功: {csv_path}")
        
        # 计算并保存特征重要性
        feature_importance = np.abs(shap_values_np).mean(0)
        importance_df = pd.DataFrame({
            'feature': feature_names,
            'importance': feature_importance
        }).sort_values('importance', ascending=False)
        
        # 保存为CSV文件
        importance_path = os.path.join(output_dir, f"{model_name}_feature_importance.csv")
        importance_df.to_csv(importance_path, index=False)
        logger.info(f"特征重要性保存成功: {importance_path}")
        
        return importance_df
    except Exception as e:
        logger.error(f"错误: 保存SHAP值失败: {e}")
        return None

def main(args=None):
    """
    主函数
    
    参数:
    args: 参数对象，如果为None则从命令行解析
    """
    # 检查SHAP库是否可用
    if not shap_available:
        logger.info("错误: SHAP库不可用，无法执行SHAP分析。")
        logger.info("请安装SHAP库: pip install shap")
        return
    
    # 解析命令行参数
    if args is None:
        parser = argparse.ArgumentParser(
            description='SHAP模型可解释性分析工具',
            epilog='''
使用示例:
    # 使用默认参数
    python shap_analysis.py -m path/to/model.joblib -d path/to/data.csv
    
    # 指定目标变量
    python shap_analysis.py -m path/to/model.joblib -d path/to/data.csv -t target_column
    
    # 指定输出目录
    python shap_analysis.py -m path/to/model.joblib -d path/to/data.csv -o path/to/output
        ''',
            formatter_class=argparse.RawDescriptionHelpFormatter
        )
        
        # 模型路径参数
        parser.add_argument('-m', '--model', type=str, required=True,
                            help='训练好的模型文件路径')
        
        # 数据文件路径参数
        parser.add_argument('-d', '--data', type=str, required=True,
                            help='数据文件路径')
        
        # 目标变量参数
        parser.add_argument('-t', '--target', type=str,
                            help='目标变量名称，默认使用最后一列')
        
        # 输出目录参数
        default_output = os.path.join(os.getcwd(), 'results', 'explanation', 'shap')
        parser.add_argument('-o', '--output', type=str, default=default_output,
                            help=f'输出目录，默认保存在 {default_output}')
        
        # 解析参数
        args = parser.parse_args()
    
    # 加载模型
    model_info = load_model(args.model)
    if not model_info:
        return
    
    # 加载数据
    X, y, feature_names = load_data(args.data, args.target)
    if X is None:
        return
    
    # 获取模型
    model = model_info.get('model')
    if not model:
        logger.info("错误: 模型信息中没有找到模型对象")
        return

    # 解释用数据必须与训练时的特征列及顺序一致，尤其是带 scaler 的 KNN/SVM/MLP。
    model_feature_names = model_info.get('feature_names')
    if model_feature_names:
        missing_features = [feature for feature in model_feature_names if feature not in X.columns]
        if missing_features:
            logger.error(f"错误: 解释数据缺少模型训练特征: {missing_features}")
            return
        X = X[model_feature_names]
        feature_names = list(model_feature_names)
        logger.info("已按模型训练时的 feature_names 重排解释用特征矩阵")

    # 与 heaML 训练一致：若 joblib 中保存了已拟合的 StandardScaler，先对 X 变换再解释
    scaler = model_info.get('scaler')
    if scaler is not None and hasattr(scaler, 'mean_'):
        X_arr = scaler.transform(X)
        X = pd.DataFrame(X_arr, columns=feature_names, index=X.index)
        logger.info("已对解释用特征矩阵应用模型自带的 StandardScaler")
    elif scaler is not None:
        logger.warning(
            "模型中的 scaler 未拟合（常见于旧版 KNN 保存逻辑），SHAP 仍用原始特征；"
            "建议重新运行 knn_ml 训练以写入已拟合 scaler。"
        )
    
    # 获取SHAP解释器
    explainer = get_shap_explainer(model, X)
    if not explainer:
        return
    
    # 生成SHAP值
    shap_values = generate_shap_values(explainer, X)
    if shap_values is None:
        return
    
    # 处理SHAP值格式
    if hasattr(shap_values, 'values'):
        shap_values = shap_values.values
    
    # 输出文件名前缀：与传入的 .joblib 文件名一致（随机森林则含 random_forest）
    model_name = os.path.splitext(os.path.basename(args.model))[0]
    logger.info(f"SHAP 输出文件前缀: {model_name}（来自模型路径）")
    
    # 创建输出目录
    os.makedirs(args.output, exist_ok=True)
    
    # 绘制SHAP摘要图
    plot_shap_summary(shap_values, X, feature_names, args.output, model_name)
    
    # 绘制SHAP依赖图
    plot_shap_dependence(shap_values, X, feature_names, args.output, model_name)
    
    # 保存SHAP值
    importance_df = save_shap_values(shap_values, feature_names, args.output, model_name)
    
    # 打印结果摘要
    if importance_df is not None:
        logger.info(f"\n=== 特征重要性摘要 ===")
        logger.info(importance_df.head(10))
    
    logger.info(f"\n=== 分析完成 ===")
    logger.info(f"所有结果已保存到: {args.output}")

if __name__ == '__main__':
    main()
