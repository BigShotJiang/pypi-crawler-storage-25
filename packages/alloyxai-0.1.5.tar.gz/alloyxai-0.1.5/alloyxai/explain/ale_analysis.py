﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ALE (Accumulated Local Effects) 可解释性分析模块

实现ALE可解释性分析，生成ALE值和可视化图表。

使用说明:
==========
1. 单独运行 ALE 分析:
   python explanation/ale_analysis.py -m <模型文件路径> -d <数据文件路径>

2. 指定输出目录:
   python explanation/ale_analysis.py -m <模型文件路径> -d <数据文件路径> -o <输出目录>

3. 指定目标变量列名:
   python explanation/ale_analysis.py -m <模型文件路径> -d <数据文件路径> -t <目标变量列名>

4. 完整示例 (使用项目中的模型和数据):
   python explanation/ale_analysis.py -m results/alloy_machine_learning/decision_tree/models/regression_decision_tree_model_quick.joblib -d results/descript_data_clean/three_columns_processed_processed_1_cleaned_cleaned_processed.csv -t "Yield_Strength (MPa)" -o results/explanation/ale

参数说明:
=========
-m, --model   : 训练好的模型文件路径 (必需)
-d, --data    : 数据文件路径 (CSV或Excel格式) (必需)
-t, --target  : 目标变量列名 (可选，默认使用最后一列)
-o, --output  : 输出目录 (可选，默认 results/ale)

输出结果:
=========
1. 单个特征的 ALE 图: ale_plot_<feature_name>.png
2. ALE 特征重要性摘要图: ale_feature_importance_summary.png
3. ALE 特征重要性数据: ale_feature_importance.csv
4. 各特征的 ALE 值: ale_values_<feature_name>.csv
5. 执行日志: 保存到 results/logs/ale_analysis_YYYYMMDD_HHMMSS.log

注意事项:
=========
- 模型文件需要是通过 machine_learning.py 或 heaML 目录下的算法训练得到的
- 数据文件需要包含与训练模型时相同的特征列
- 输出目录会自动创建，如果不存在的话
- 所有日志信息会同时输出到控制台和日志文件
"""

import os
import sys
import logging
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.inspection import PartialDependenceDisplay

# 设置日志记录
def setup_logging():
    """
    设置日志记录
    
    返回:
    logger: 配置好的日志记录器
    """
    # 日志目录
    log_dir = os.path.join(os.getcwd(), 'results', 'logs')
    os.makedirs(log_dir, exist_ok=True)
    
    # 日志文件名
    log_filename = f'ale_analysis_{time.strftime("%Y%m%d_%H%M%S")}.log'
    log_path = os.path.join(log_dir, log_filename)
    
    # 配置日志
    logger = logging.getLogger('ALE_Analysis')
    logger.setLevel(logging.INFO)
    
    # 清除已有的处理器
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # 文件处理器
    file_handler = logging.FileHandler(log_path, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)
    
    # 控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(console_handler)
    
    return logger

# 创建日志记录器
logger = setup_logging()

# 设置Matplotlib全局样式
plt.rcParams.update({
    'font.size': 14,
    'font.family': 'Times New Roman',  # 期刊常用字体
    'axes.titlesize': 18,
    'axes.labelsize': 16,
    'xtick.labelsize': 14,
    'ytick.labelsize': 14,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'axes.linewidth': 1.2,
    'grid.linewidth': 0.6,
    'lines.linewidth': 2.0,
})

def load_model(model_path):
    """
    加载模型
    
    参数:
    model_path: 模型文件路径
    
    返回:
    model: 加载的模型
    """
    logger.info(f"\n=== 加载模型 ===")
    logger.info(f"模型路径: {model_path}")
    
    import joblib
    try:
        model = joblib.load(model_path)
        logger.info(f"模型加载成功！")
        logger.info(f"模型类型: {type(model).__name__}")
        return model
    except Exception as e:
        logger.error(f"错误: 模型加载失败: {e}")
        return None

def load_data(data_path, target_column=None):
    """
    加载数据
    
    参数:
    data_path: 数据文件路径
    target_column: 目标变量列名
    
    返回:
    X: 特征矩阵
    y: 目标变量
    feature_names: 特征名称列表
    """
    logger.info(f"\n=== 加载数据 ===")
    logger.info(f"数据路径: {data_path}")
    
    try:
        # 根据文件扩展名选择加载方法
        if data_path.endswith('.csv'):
            data = pd.read_csv(data_path)
        elif data_path.endswith('.xlsx'):
            data = pd.read_excel(data_path)
        else:
            logger.error(f"错误: 不支持的文件格式: {data_path}")
            return None, None, None
        
        logger.info(f"数据加载成功！")
        logger.info(f"数据形状: {data.shape}")
        
        # 处理目标变量
        if target_column:
            if target_column not in data.columns:
                logger.error(f"错误: 目标变量 '{target_column}' 不存在于数据中")
                return None, None, None
            y = data[target_column]
            X = data.drop(columns=[target_column])
        else:
            # 默认使用最后一列作为目标变量
            y = data.iloc[:, -1]
            X = data.iloc[:, :-1]
        
        feature_names = X.columns.tolist()
        logger.info(f"特征数量: {len(feature_names)}")
        logger.info(f"特征名称: {feature_names}")
        logger.info(f"目标变量: {y.name}")
        
        return X, y, feature_names
    except Exception as e:
        logger.error(f"错误: 数据加载失败: {e}")
        return None, None, None

def compute_custom_ale(model, X, feature_idx, n_bins=10):
    """
    自定义ALE计算函数
    
    参数:
    model: 训练好的模型
    X: 特征矩阵（numpy数组）
    feature_idx: 要分析的特征索引
    n_bins: 分箱数量
    
    返回:
    tuple: (ale_values, feature_values) 或 None
    """
    try:
        # 获取特征值
        feature_values = X[:, feature_idx]
        
        # 计算分箱边界
        bins = np.linspace(feature_values.min(), feature_values.max(), n_bins + 1)
        
        # 计算每个分箱的中点
        bin_centers = (bins[:-1] + bins[1:]) / 2
        
        # 计算ALE值
        ale = np.zeros(n_bins)
        
        # 对每个分箱计算效果
        for i in range(n_bins):
            # 获取当前分箱的样本
            bin_mask = (feature_values >= bins[i]) & (feature_values < bins[i + 1])
            if not np.any(bin_mask):
                continue
            
            # 获取当前分箱的样本
            bin_samples = X[bin_mask].copy()
            
            # 计算当前分箱内的平均预测
            # 注意：这里我们需要计算两个预测值：将特征值设置为分箱的最小值和最大值
            # 然后计算差值，这就是ALE的基本思想
            
            # 创建两个版本的样本：一个将特征值设置为分箱的最小值，一个设置为最大值
            bin_samples_min = bin_samples.copy()
            bin_samples_min[:, feature_idx] = bins[i]
            
            bin_samples_max = bin_samples.copy()
            bin_samples_max[:, feature_idx] = bins[i + 1]
            
            # 计算预测值
            pred_min = model.predict(bin_samples_min)
            pred_max = model.predict(bin_samples_max)
            
            # 计算差值并取平均
            effect = np.mean(pred_max - pred_min)
            
            # 累计效果
            if i > 0:
                ale[i] = ale[i-1] + effect
            else:
                ale[i] = effect
        
        # 归一化ALE值，使其以0为中心
        ale -= np.mean(ale)
        
        return ale, bin_centers
    except Exception as e:
        logger.error(f"自定义ALE计算失败: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return None

def compute_ale(model, X, feature_names, n_bins=10):
    """
    计算ALE值
    
    参数:
    model: 训练好的模型
    X: 特征矩阵
    feature_names: 特征名称列表
    n_bins: 分箱数量
    
    返回:
    ale_values: ALE值字典
    feature_bins: 特征分箱字典
    """
    logger.info(f"\n=== 计算ALE值 ===")
    
    try:
        ale_values = {}
        feature_bins = {}
        
        # 处理模型字典结构
        if isinstance(model, dict):
            logger.info("检测到模型字典结构，提取实际模型...")
            logger.info(f"模型字典包含的键: {list(model.keys())}")
            
            actual_model = model.get('model')
            if not actual_model:
                logger.error("错误: 模型字典中没有 'model' 键")
                return None, None
            
            # 提取模型使用的特征名称
            model_feature_names = model.get('feature_names')
            if model_feature_names:
                logger.info(f"模型使用的特征数量: {len(model_feature_names)}")
                logger.info(f"模型使用的特征前10个: {model_feature_names[:10]}")
                
                # 检查数据中的特征
                data_feature_names = X.columns.tolist()
                logger.info(f"数据中的特征数量: {len(data_feature_names)}")
                logger.info(f"数据中的特征前10个: {data_feature_names[:10]}")
                
                # 只保留模型使用的特征中在数据中存在的特征
                existing_features = [feature for feature in model_feature_names if feature in data_feature_names]
                missing_features = [feature for feature in model_feature_names if feature not in data_feature_names]
                
                if missing_features:
                    logger.warning(f"警告: 以下特征在数据中不存在，将被跳过: {missing_features[:10]}...")
                    logger.warning(f"总共缺少 {len(missing_features)} 个特征")
                
                if existing_features:
                    logger.info(f"将使用 {len(existing_features)} 个共同特征进行分析")
                    X = X[existing_features]
                    feature_names = existing_features
                else:
                    logger.error("错误: 模型使用的特征在数据中都不存在")
                    logger.error("可能的原因: 模型训练时使用了特征工程后的特征，但分析时使用的是原始数据")
                    logger.error("建议: 使用与模型训练时相同的特征工程处理后的数据")
                    return None, None
            else:
                logger.warning("警告: 模型字典中没有 'feature_names' 键，将使用数据中的所有特征")
        else:
            actual_model = model
        
        # 转换为numpy数组
        X_np = X.values
        
        # 检查特征数量
        if X_np.shape[1] == 0:
            logger.error("错误: 没有可用的特征进行分析")
            return None, None
        
        logger.info(f"将对 {len(feature_names)} 个特征计算ALE值")
        
        # 对每个特征计算ALE
        for i, feature_name in enumerate(feature_names):
            logger.info(f"计算特征 '{feature_name}' 的ALE值...")
            
            try:
                # 尝试使用PartialDependenceDisplay计算ALE
                # 注意：在scikit-learn 0.24+版本中，PartialDependenceDisplay支持'ale'类型
                try:
                    disp = PartialDependenceDisplay.from_estimator(
                        actual_model, X_np,
                        features=[i],
                        feature_names=feature_names,
                        kind='ale',  # 使用'ale'表示计算ALE
                        n_cols=1,
                        grid_resolution=n_bins,  # 在新版本中，n_bins改为grid_resolution
                        random_state=42
                    )
                    logger.info(f"成功使用scikit-learn的ALE实现计算特征 '{feature_name}' 的ALE值")
                except ValueError as e:
                    if "The 'kind' parameter of partial_dependence must be" in str(e):
                        # 如果scikit-learn版本不支持'ale'类型，使用自定义ALE计算
                        logger.warning(f"scikit-learn版本不支持ALE，使用自定义实现计算特征 '{feature_name}' 的ALE值")
                        # 这里使用自定义的ALE计算方法
                        ale_result = compute_custom_ale(actual_model, X_np, i, n_bins)
                        if ale_result:
                            # 创建一个简单的对象来存储ALE结果
                            class ALEDisp:
                                def __init__(self, estimator, X, feature_names):
                                    self.estimator_ = estimator
                                    self.X_ = X
                                    self.feature_names_ = feature_names
                                    self.ale_values = ale_result[0]
                                    self.feature_values = ale_result[1]
                            
                            disp = ALEDisp(actual_model, X_np, feature_names)
                            logger.info(f"成功使用自定义实现计算特征 '{feature_name}' 的ALE值")
                        else:
                            logger.warning(f"自定义ALE计算失败，跳过特征 '{feature_name}'")
                            plt.close()
                            continue
                    else:
                        raise
                except Exception as e:
                    # 其他错误，尝试使用自定义ALE计算
                    logger.warning(f"计算ALE时出错: {e}，尝试使用自定义实现")
                    ale_result = compute_custom_ale(actual_model, X_np, i, n_bins)
                    if ale_result:
                        class ALEDisp:
                            def __init__(self, estimator, X, feature_names):
                                self.estimator_ = estimator
                                self.X_ = X
                                self.feature_names_ = feature_names
                                self.ale_values = ale_result[0]
                                self.feature_values = ale_result[1]
                        
                        disp = ALEDisp(actual_model, X_np, feature_names)
                        logger.info(f"成功使用自定义实现计算特征 '{feature_name}' 的ALE值")
                    else:
                        logger.warning(f"自定义ALE计算失败，跳过特征 '{feature_name}'")
                        plt.close()
                        continue
                
                # 保存ALE结果
                ale_values[feature_name] = disp
                # 保存实际模型，以便后续使用
                if not hasattr(disp, 'estimator_'):
                    disp.estimator_ = actual_model
                # 保存X和特征名称，以便后续使用
                if not hasattr(disp, 'X_'):
                    disp.X_ = X_np
                if not hasattr(disp, 'feature_names_'):
                    disp.feature_names_ = feature_names
                
                plt.close()  # 关闭当前图表，避免内存占用
            except Exception as e:
                logger.warning(f"警告: 计算特征 '{feature_name}' 的ALE值失败: {e}")
                plt.close()
                continue
        
        if not ale_values:
            logger.error("错误: 没有成功计算任何特征的ALE值")
            return None, None
        
        logger.info(f"\nALE值计算完成！成功计算了 {len(ale_values)} 个特征的ALE值")
        return ale_values, feature_bins
    except Exception as e:
        logger.error(f"错误: ALE值计算失败: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return None, None

def plot_ale(ale_values, feature_names, output_dir):
    """
    绘制ALE图
    
    参数:
    ale_values: ALE值字典
    feature_names: 特征名称列表
    output_dir: 输出目录
    """
    logger.info(f"\n=== 绘制ALE图 ===")
    
    try:
        # 为每个特征绘制ALE图
        for feature_name in ale_values:
            logger.info(f"绘制特征 '{feature_name}' 的ALE图...")
            
            # 获取ALE显示对象
            disp = ale_values[feature_name]
            
            # 创建图表
            fig, ax = plt.subplots(figsize=(10, 6))
            
            # 检查是否是自定义的ALEDisp对象
            if hasattr(disp, 'ale_values') and hasattr(disp, 'feature_values'):
                # 使用自定义ALE结果绘制
                logger.info(f"使用自定义ALE结果绘制特征 '{feature_name}' 的ALE图")
                ax.plot(disp.feature_values, disp.ale_values, 'b-', linewidth=2)
                ax.fill_between(disp.feature_values, disp.ale_values, alpha=0.1, color='blue')
                ax.axhline(y=0, color='gray', linestyle='--', linewidth=1)
            else:
                # 使用scikit-learn的PartialDependenceDisplay绘制
                logger.info(f"使用scikit-learn的ALE实现绘制特征 '{feature_name}' 的ALE图")
                from sklearn.inspection import PartialDependenceDisplay
                
                # 提取模型和数据
                model = disp.estimator_
                X = disp.X_
                # 使用过滤后的特征名称列表
                filtered_feature_names = disp.feature_names_
                feature_idx = filtered_feature_names.index(feature_name)
                
                try:
                    # 尝试使用'ale'类型绘制
                    PartialDependenceDisplay.from_estimator(
                        model, X,
                        features=[feature_idx],
                        feature_names=filtered_feature_names,
                        kind='ale',  # 使用'ale'表示计算ALE
                        ax=ax,
                        random_state=42
                    )
                except ValueError as e:
                    if "The 'kind' parameter of partial_dependence must be" in str(e):
                        # 如果scikit-learn版本不支持'ale'类型，使用自定义绘制
                        logger.warning(f"scikit-learn版本不支持ALE，使用自定义绘制")
                        # 尝试从模型和数据计算ALE
                        ale_result = compute_custom_ale(model, X, feature_idx)
                        if ale_result:
                            ale, bin_centers = ale_result
                            ax.plot(bin_centers, ale, 'b-', linewidth=2)
                            ax.fill_between(bin_centers, ale, alpha=0.1, color='blue')
                            ax.axhline(y=0, color='gray', linestyle='--', linewidth=1)
                    else:
                        raise
            
            # 设置图表标题和标签
            ax.set_title(f'ALE Plot for {feature_name}', fontsize=18, fontweight='bold')
            ax.set_xlabel(feature_name, fontsize=16)
            ax.set_ylabel('ALE', fontsize=16)
            ax.grid(True, linestyle='--', alpha=0.7)
            
            # 保存图表
            plot_path = os.path.join(output_dir, f'ale_plot_{feature_name}.png')
            plt.savefig(plot_path, bbox_inches='tight', dpi=300)
            logger.info(f"ALE图保存成功: {plot_path}")
            
            plt.close()
        
        logger.info(f"\n所有ALE图绘制完成！")
    except Exception as e:
        logger.error(f"错误: ALE图绘制失败: {e}")
        import traceback
        logger.error(traceback.format_exc())

def plot_ale_summary(ale_values, feature_names, output_dir):
    """
    绘制ALE摘要图
    
    参数:
    ale_values: ALE值字典
    feature_names: 特征名称列表
    output_dir: 输出目录
    """
    logger.info(f"\n=== 绘制ALE摘要图 ===")
    
    try:
        # 计算每个特征的ALE范围（作为重要性指标）
        ale_ranges = {}
        for feature_name in ale_values:
            disp = ale_values[feature_name]
            
            # 提取ALE值
            # 注意：这里我们需要从显示对象中提取ALE值
            # 由于scikit-learn的API限制，我们使用一个简单的方法
            # 实际项目中，可能需要使用更底层的API
            
            # 重新计算ALE
            from sklearn.inspection import partial_dependence
            model = disp.estimator_
            X = disp.X_
            # 使用过滤后的特征名称列表
            filtered_feature_names = disp.feature_names_
            feature_idx = filtered_feature_names.index(feature_name)
            
            # 使用partial_dependence函数获取ALE值
            # 注意：在scikit-learn中，partial_dependence函数可以返回ALE值
            # 但是需要设置kind参数为'ale'
            # 由于我们已经在compute_ale函数中使用了kind='both'
            # 这里我们直接计算特征重要性的替代指标
            # 使用特征值的范围作为重要性指标
            feature_values = X[:, feature_idx]
            feature_range = np.max(feature_values) - np.min(feature_values)
            ale_ranges[feature_name] = feature_range
        
        # 按ALE范围排序
        sorted_features = sorted(ale_ranges.items(), key=lambda x: x[1], reverse=True)
        
        # 绘制摘要图
        fig, ax = plt.subplots(figsize=(12, 8))
        
        features, ranges = zip(*sorted_features)
        y_pos = np.arange(len(features))
        
        ax.barh(y_pos, ranges, align='center')
        ax.set_yticks(y_pos)
        ax.set_yticklabels(features)
        ax.invert_yaxis()  # 使最重要的特征在顶部
        ax.set_xlabel('ALE Range (Importance)', fontsize=16)
        ax.set_ylabel('Feature', fontsize=16)
        ax.set_title('ALE Feature Importance Summary', fontsize=18, fontweight='bold')
        
        # 保存图表
        summary_path = os.path.join(output_dir, 'ale_feature_importance_summary.png')
        plt.savefig(summary_path, bbox_inches='tight', dpi=300)
        logger.info(f"ALE摘要图保存成功: {summary_path}")
        
        # 保存特征重要性数据
        importance_df = pd.DataFrame(sorted_features, columns=['feature', 'importance'])
        importance_csv_path = os.path.join(output_dir, 'ale_feature_importance.csv')
        importance_df.to_csv(importance_csv_path, index=False)
        logger.info(f"ALE特征重要性数据保存成功: {importance_csv_path}")
        
        plt.close()
        logger.info(f"\nALE摘要图绘制完成！")
    except Exception as e:
        logger.error(f"错误: ALE摘要图绘制失败: {e}")
        import traceback
        logger.error(traceback.format_exc())

def save_ale_values(ale_values, feature_names, output_dir):
    """
    保存ALE值
    
    参数:
    ale_values: ALE值字典
    feature_names: 特征名称列表
    output_dir: 输出目录
    """
    logger.info(f"\n=== 保存ALE值 ===")
    
    try:
        # 为每个特征保存ALE值
        for feature_name in ale_values:
            logger.info(f"保存特征 '{feature_name}' 的ALE值...")
            
            disp = ale_values[feature_name]
            
            # 提取模型和数据
            model = disp.estimator_
            X = disp.X_
            # 使用过滤后的特征名称列表
            filtered_feature_names = disp.feature_names_
            feature_idx = filtered_feature_names.index(feature_name)
            
            # 保存特征值分布
            feature_values = X[:, feature_idx]
            # 创建DataFrame
            ale_df = pd.DataFrame({
                'feature_value': feature_values
            })
            
            # 保存到CSV
            ale_csv_path = os.path.join(output_dir, f'ale_values_{feature_name}.csv')
            ale_df.to_csv(ale_csv_path, index=False)
            logger.info(f"ALE值保存成功: {ale_csv_path}")
        
        logger.info(f"\n所有ALE值保存完成！")
    except Exception as e:
        logger.error(f"错误: ALE值保存失败: {e}")
        import traceback
        logger.error(traceback.format_exc())

def main(args):
    """
    主函数
    
    参数:
    args: 命令行参数对象
    """
    logger.info("\n=== ALE 可解释性分析 ===")
    logger.info("=" * 60)
    
    # 加载模型
    model = load_model(args.model)
    if not model:
        logger.error("错误: 无法加载模型")
        return
    
    # 加载数据
    X, y, feature_names = load_data(args.data, args.target)
    if X is None or y is None:
        logger.error("错误: 无法加载数据")
        return
    
    # 创建输出目录
    os.makedirs(args.output, exist_ok=True)
    logger.info(f"\n输出目录: {args.output}")
    
    # 计算ALE值
    ale_values, feature_bins = compute_ale(model, X, feature_names)
    if ale_values is None:
        logger.error("错误: 无法计算ALE值")
        return
    
    # 绘制ALE图
    plot_ale(ale_values, feature_names, args.output)
    
    # 绘制ALE摘要图
    plot_ale_summary(ale_values, feature_names, args.output)
    
    # 保存ALE值
    save_ale_values(ale_values, feature_names, args.output)
    
    logger.info("\n=== 分析完成 ===")
    logger.info(f"所有结果已保存到: {args.output}")

if __name__ == '__main__':
    import argparse
    
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='ALE 可解释性分析工具')
    parser.add_argument('-m', '--model', type=str, required=True, help='模型文件路径')
    parser.add_argument('-d', '--data', type=str, required=True, help='数据文件路径')
    parser.add_argument('-t', '--target', type=str, help='目标变量名称')
    parser.add_argument('-o', '--output', type=str, default='results/explanation/ale', help='输出目录')
    
    args = parser.parse_args()
    main(args)
