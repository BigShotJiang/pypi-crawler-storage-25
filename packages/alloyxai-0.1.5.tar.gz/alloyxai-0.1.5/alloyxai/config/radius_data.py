# 计算半径（radius_calculated）
radius_calculated_dict = {
    "H": 0.53, "He": 0.31,
    "Li": 1.67, "Be": 1.12, "B": 0.87, "C": 0.67, "N": 0.56, "O": 0.48, "F": 0.42, "Ne": 0.38,
    "Na": 1.90, "Mg": 1.77, "Al": 1.18, "Si": 1.11, "P": 0.98, "S": 0.88, "Cl": 0.79, "Ar": 0.71,
    "K": 2.43, "Ca": 1.94, "Sc": 1.84, "Ti": 1.76, "V": 1.71, "Cr": 1.66, "Mn": 1.61, "Fe": 1.56, "Co": 1.52,
    "Ni": 1.49, "Cu": 1.41, "Zn": 1.42,
    "Ga": 1.36, "Ge": 1.25, "As": 1.14, "Se": 1.03, "Br": 0.94, "Kr": 0.88,
    "Rb": 2.65, "Sr": 2.19, "Y": 2.12, "Zr": 2.06, "Nb": 1.98, "Mo": 1.90, "Tc": 1.83, "Ru": 1.78, "Rh": 1.73,
    "Pd": 1.69, "Ag": 1.65, "Cd": 1.61,
    "In": 1.56, "Sn": 1.45, "Sb": 1.33, "Te": 1.23, "I": 1.15, "Xe": 1.08,
    "Cs": 2.98, "Ba": 2.53,
    "La": None, "Ce": None, "Pr": 2.47, "Nd": 2.06, "Pm": 2.05, "Sm": 2.38, "Eu": 2.31, "Gd": 2.33, "Tb": 2.25,
    "Dy": 2.28, "Ho": 2.26, "Er": 2.26, "Tm": 2.22, "Yb": 2.22, "Lu": 2.17,
    "Hf": 2.08, "Ta": 2.00, "W": 1.93, "Re": 1.88, "Os": 1.85, "Ir": 1.80, "Pt": 1.77, "Au": 1.74, "Hg": 1.71,
    "Tl": 1.56, "Pb": 1.54, "Bi": 1.43, "Po": 1.35, "At": 1.27, "Rn": 1.20,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": None, "Pa": None, "U": None, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# 经验原子半径（radius_empirical）
radius_empirical_dict = {
    "H": 0.25, "He": None,
    "Li": 1.45, "Be": 1.05, "B": 0.85, "C": 0.70, "N": 0.65, "O": 0.60, "F": 0.50, "Ne": None,
    "Na": 1.80, "Mg": 1.50, "Al": 1.25, "Si": 1.10, "P": 1.00, "S": 1.00, "Cl": 1.00, "Ar": 0.71,
    "K": 2.20, "Ca": 1.80, "Sc": 1.60, "Ti": 1.40, "V": 1.35, "Cr": 1.40, "Mn": 1.40, "Fe": 1.40, "Co": 1.25,
    "Ni": 1.24, "Cu": 1.35, "Zn": 1.35,
    "Ga": 1.30, "Ge": 1.25, "As": 1.15, "Se": 1.15, "Br": 1.15, "Kr": None,
    "Rb": 2.35, "Sr": 2.00, "Y": 1.80, "Zr": 1.55, "Nb": 1.45, "Mo": 1.45, "Tc": 1.35, "Ru": 1.30, "Rh": 1.35,
    "Pd": 1.40, "Ag": 1.60, "Cd": 1.55,
    "In": 1.55, "Sn": 1.45, "Sb": 1.45, "Te": 1.40, "I": 1.40, "Xe": None,
    "Cs": 2.60, "Ba": 2.15,
    "La": 1.95, "Ce": 1.85, "Pr": 1.85, "Nd": 1.85, "Pm": 1.85, "Sm": 1.85, "Eu": 1.85, "Gd": 1.80, "Tb": 1.75,
    "Dy": 1.75, "Ho": 1.75, "Er": 1.75, "Tm": 1.75, "Yb": 1.75, "Lu": 1.75,
    "Hf": 1.55, "Ta": 1.45, "W": 1.35, "Re": 1.35, "Os": 1.30, "Ir": 1.35, "Pt": 1.35, "Au": 1.35, "Hg": 1.50,
    "Tl": 1.90, "Pb": 1.80, "Bi": 1.60, "Po": 1.90, "At": None, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": None, "Pa": None, "U": None, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# 共价原子半径（radius_covalent）
radius_covalent_dict = {
    "H": 0.37, "He": 0.32,
    "Li": 1.34, "Be": 0.90, "B": 0.82, "C": 0.77, "N": 0.75, "O": 0.73, "F": 0.71, "Ne": 0.69,
    "Na": 1.54, "Mg": 1.30, "Al": 1.18, "Si": 1.11, "P": 1.06, "S": 1.02, "Cl": 0.99, "Ar": 0.97,
    "K": 1.96, "Ca": 1.74, "Sc": 1.44, "Ti": 1.36, "V": 1.25, "Cr": 1.27, "Mn": 1.39, "Fe": 1.25, "Co": 1.26,
    "Ni": 1.21, "Cu": 1.38, "Zn": 1.31,
    "Ga": 1.26, "Ge": 1.22, "As": 1.19, "Se": 1.16, "Br": 1.14, "Kr": 1.10,
    "Rb": 2.11, "Sr": 1.92, "Y": 1.62, "Zr": 1.48, "Nb": 1.37, "Mo": 1.45, "Tc": 1.56, "Ru": 1.26, "Rh": 1.35,
    "Pd": 1.31, "Ag": 1.53, "Cd": 1.48,
    "In": 1.44, "Sn": 1.41, "Sb": 1.38, "Te": 1.35, "I": 1.33, "Xe": 1.30,
    "Cs": 2.25, "Ba": 1.98,
    "La": 1.69, "Ce": None, "Pr": None, "Nd": None, "Pm": None, "Sm": None, "Eu": None, "Gd": None, "Tb": None,
    "Dy": None, "Ho": None, "Er": None, "Tm": None, "Yb": None, "Lu": None,
    "Hf": 1.50, "Ta": 1.38, "W": 1.46, "Re": 1.59, "Os": 1.28, "Ir": 1.37, "Pt": 1.28, "Au": 1.44, "Hg": 1.49,
    "Tl": 1.48, "Pb": 1.47, "Bi": 1.46, "Po": 1.45, "At": None, "Rn": None,
    "Fr": None, "Ra": None,
    "Ac": None, "Th": None, "Pa": None, "U": None, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}

# 范德华半径（radius_vdw）
radius_vdw_dict = {
    "H": 1.20, "He": 1.40,
    "Li": 1.82, "Be": None, "B": None, "C": 1.70, "N": 1.55, "O": 1.52, "F": 1.47, "Ne": 1.54,
    "Na": 2.27, "Mg": 1.73, "Al": None, "Si": 2.10, "P": 1.80, "S": 1.80, "Cl": 1.75, "Ar": 1.88,
    "K": 2.75, "Ca": None, "Sc": None, "Ti": None, "V": None, "Cr": None, "Mn": None, "Fe": None, "Co": None,
    "Ni": 1.63, "Cu": 1.40, "Zn": 1.39,
    "Ga": 1.87, "Ge": None, "As": 1.85, "Se": 1.90, "Br": 1.85, "Kr": 2.02,
    "Rb": None, "Sr": None, "Y": None, "Zr": None, "Nb": None, "Mo": None, "Tc": None, "Ru": None, "Rh": None,
    "Pd": 1.63, "Ag": 1.72, "Cd": 1.58,
    "In": 1.93, "Sn": 2.17, "Sb": None, "Te": 2.06, "I": 1.98, "Xe": 2.16,
    "Cs": None, "Ba": None,
    "La": None, "Ce": None, "Pr": None, "Nd": None, "Pm": None, "Sm": None, "Eu": None, "Gd": None, "Tb": None,
    "Dy": None, "Ho": None, "Er": None, "Tm": None, "Yb": None, "Lu": None,
    "Hf": None, "Ta": None, "W": 1.75, "Re": 1.66, "Os": 1.55, "Ir": 1.96, "Pt": 2.02, "Au": None, "Hg": None,
    "Tl": None, "Pb": None, "Bi": 1.75, "Po": 1.66, "At": 1.55, "Rn": 1.96,
    "Fr": 2.02, "Ra": None,
    "Ac": None, "Th": None, "Pa": None, "U": None, "Np": None, "Pu": None, "Am": None, "Cm": None, "Bk": None,
    "Cf": None, "Es": None, "Fm": None, "Md": None, "No": None, "Lr": None,
    "Rf": None, "Db": None, "Sg": None, "Bh": None, "Hs": None, "Mt": None, "Ds": None, "Rg": None, "Cn": None,
    "Nh": None, "Fl": None, "Mc": None, "Lv": None, "Ts": None, "Og": None
}
