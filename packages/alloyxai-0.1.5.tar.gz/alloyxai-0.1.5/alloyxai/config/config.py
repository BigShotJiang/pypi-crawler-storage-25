#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AlloyXAI 项目配置文件

统一管理项目的路径配置和默认参数。
"""

import os

BASE_DIR = os.getcwd()

PATHS = {
    'results': os.path.join(BASE_DIR, 'results'),
    'logs': os.path.join(BASE_DIR, 'results', 'logs'),
    'explanation': os.path.join(BASE_DIR, 'results', 'explanation'),
    'models': os.path.join(BASE_DIR, 'results', 'alloy_machine_learning'),
    'data_descriptors': os.path.join(BASE_DIR, 'results', 'data_descriptors'),
    'feature_engineering': os.path.join(BASE_DIR, 'results', 'feature_engineering'),
}

DEFAULT_PARAMS = {
    'test_size': 0.2,
    'random_state': 42,
}

def setup_logging_config(logger_name, log_prefix):
    """
    日志配置的通用函数
    
    参数:
    logger_name: logger名称
    log_prefix: 日志文件前缀
    
    返回:
    logger: 配置好的logger
    """
    import logging
    import time
    
    log_dir = PATHS['logs']
    os.makedirs(log_dir, exist_ok=True)
    
    log_filename = f'{log_prefix}_{time.strftime("%Y%m%d_%H%M%S")}.log'
    log_path = os.path.join(log_dir, log_filename)
    
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)
    
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    file_handler = logging.FileHandler(log_path, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(file_handler)
    
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(console_handler)
    
    return logger
