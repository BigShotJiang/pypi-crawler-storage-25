# -*- coding: utf-8 -*-
"""
特征工程处理脚本
================

功能说明：
- 自动查找descript_data_clean目录下最新的清洗后数据文件
- 实现两种特征工程模式：普通模式和增强模式
- 普通模式：基本特征处理，包括标准化、归一化等
- 增强模式：在普通模式基础上，增加交互特征和多项式特征，丰富特征数
- 实现科学的特征筛选方法，包括多重线性检测、相关性分析等
- 化学元素列保护：默认保护化学元素列不被特征筛选删除
- 生成详细的特征工程报告并保存到feature_engineering目录
- 生成高质量的特征工程可视化图片
- 同时保存处理后的数据为Excel和CSV格式

使用方法：
1. 直接运行（自动处理descript_data_clean目录下最新的清洗后数据文件）：
   python feature_engineering.py

2. 选择处理模式：
   python feature_engineering.py -m 1  # 普通模式（默认）
   python feature_engineering.py -m 2  # 增强模式

3. 指定目标变量：
   python feature_engineering.py -t target_column

4. 不保护化学元素列：
   python feature_engineering.py --no-protect-elements

注意：
- 输入文件来自 'results/descript_data_clean' 目录下最新的清洗后数据文件
- 输出的日志文件将保存在 'results/logs' 目录下
- 处理后的数据将保存到 'results/feature_engineering' 目录下（同时保存为Excel和CSV格式）
- 详细的统计信息将保存到 'results/feature_engineering/analysis' 目录下（同时保存为Excel和CSV格式）
- 可视化图片将保存到 'results/feature_engineering/visualization' 目录下
- 化学元素列默认保护不被特征筛选删除
"""

# 导入必要的库
import os
import sys
import argparse
import pandas as pd
import numpy as np
import datetime
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib import rcParams
from sklearn.preprocessing import StandardScaler, MinMaxScaler, PolynomialFeatures
from sklearn.feature_selection import VarianceThreshold, SelectKBest, f_regression
from sklearn.linear_model import LinearRegression
from sklearn.decomposition import PCA
from sklearn.metrics import r2_score

from .engineer.element_utils import get_element_columns, is_element_column


def _get_project_root():
    return os.getcwd()

# 设置中文字体和图表样式
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.style.use('seaborn-v0_8-whitegrid')

# 设置图表默认大小
rcParams['figure.figsize'] = 12, 8
rcParams['figure.dpi'] = 150

def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description='特征工程处理脚本',
        epilog='''
使用示例:
    # 运行默认设置（普通模式，保护化学元素列，使用标准化）
    python feature_engineering.py
    
    # 增强模式
    python feature_engineering.py -m 2
    
    # 指定目标变量
    python feature_engineering.py -t target_column
    
    # 不保护化学元素列
    python feature_engineering.py --no-protect-elements
    
    # 指定特征处理方法为归一化
    python feature_engineering.py --scaling normalize
    
    # 不使用任何特征处理
    python feature_engineering.py --scaling none
    
    # 组合使用
    python feature_engineering.py -m 2 -t target_column --scaling standardize --no-protect-elements
        ''',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument('-m', '--mode', type=int, choices=[1, 2], default=1,
                        help='特征工程处理模式 (1-普通模式, 2-增强模式), 默认1')
    parser.add_argument('-t', '--target', type=str,
                        help='目标变量列名（可选）')
    parser.add_argument('--no-protect-elements', action='store_true',
                        help='不保护化学元素列（默认保护）')
    parser.add_argument('--scaling', type=str, choices=['standardize', 'normalize', 'none'], default='standardize',
                        help='特征处理方法 (standardize-标准化, normalize-归一化, none-不处理), 默认standardize')
    
    return parser.parse_args()

def find_latest_cleaned_file():
    """
    在engineer/descript_data_clean目录中查找时间戳最近的清洗后数据文件
    """
    import glob

    project_root = _get_project_root()

    data_clean_dir = os.path.join(project_root, "results", "engineer", "descript_data_clean")
    
    # 检查目录是否存在
    if not os.path.exists(data_clean_dir):
        print(f"错误: 未找到目录 {data_clean_dir}")
        return None
    
    # 查找所有Excel和CSV文件
    data_patterns = ["*.xlsx", "*.csv"]
    data_files = []
    
    for pattern in data_patterns:
        data_files.extend(glob.glob(os.path.join(data_clean_dir, pattern)))
    
    if not data_files:
        print(f"在 {data_clean_dir} 目录中未找到数据文件")
        return None
    
    # 根据修改时间排序，获取最新的文件
    latest_file = max(data_files, key=os.path.getmtime)
    print(f"找到最新的清洗后数据文件: {latest_file}")
    return latest_file

def setup_directories():
    """创建所需的目录结构"""
    project_root = _get_project_root()
    results_dir = os.path.join(project_root, "results")
    
    # 创建logs目录
    logs_dir = os.path.join(results_dir, "logs")
    os.makedirs(logs_dir, exist_ok=True)
    
    # 创建engineer目录及其子目录
    engineer_dir = os.path.join(results_dir, "engineer")
    os.makedirs(engineer_dir, exist_ok=True)
    
    # 创建feature_engineering目录
    feature_engineering_dir = os.path.join(engineer_dir, "feature_engineering")
    os.makedirs(feature_engineering_dir, exist_ok=True)
    
    analysis_dir = os.path.join(feature_engineering_dir, "analysis")
    os.makedirs(analysis_dir, exist_ok=True)
    
    visualization_dir = os.path.join(feature_engineering_dir, "visualization")
    os.makedirs(visualization_dir, exist_ok=True)
    
    # 创建scalers目录
    scalers_dir = os.path.join(feature_engineering_dir, "scalers")
    os.makedirs(scalers_dir, exist_ok=True)
    
    return logs_dir, feature_engineering_dir, analysis_dir, visualization_dir

def setup_logging(logs_dir):
    """设置日志文件"""
    # 生成带时间戳的日志文件名
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = f"feature_engineering_{timestamp}.log"
    log_path = os.path.join(logs_dir, log_filename)
    
    return log_path

# 重定向print函数以同时输出到控制台和日志文件
class Logger:
    def __init__(self, log_path):
        self.terminal = sys.stdout
        self.log = open(log_path, 'w', encoding='utf-8')
    
    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()
    
    def flush(self):
        self.terminal.flush()
        self.log.flush()

def load_data(file_path):
    """加载数据文件"""
    print(f"\n加载数据文件: {file_path}")
    
    try:
        if file_path.endswith('.xlsx'):
            df = pd.read_excel(file_path)
        elif file_path.endswith('.csv'):
            df = pd.read_csv(file_path, encoding='utf-8-sig')
        else:
            print(f"不支持的文件格式: {file_path}")
            return None
        
        print(f"数据加载成功，形状: {df.shape}")
        return df
    except Exception as e:
        print(f"加载数据时出错: {e}")
        return None

def get_numeric_columns(df):
    """获取数值型列"""
    numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
    print(f"\n数值型列 ({len(numeric_cols)}): {numeric_cols}")
    return numeric_cols

def get_target_column(df, target_arg=None):
    """获取目标变量列名"""
    print("\n=== 选择目标变量列 ===")
    print(f"数据列 ({len(df.columns)}): {list(df.columns)}")
    
    # 从命令行参数获取目标变量列名，如果没有则默认使用最后一列
    target_col = None
    
    if target_arg:
        target_col = target_arg
        if target_col not in df.columns:
            print(f"指定的目标变量列 '{target_col}' 不存在，默认使用最后一列")
            target_col = df.columns[-1]
    else:
        # 默认使用最后一列作为目标变量
        target_col = df.columns[-1]
        print(f"默认使用最后一列作为目标变量: {target_col}")
    
    print(f"\n选择的目标变量列: {target_col}")
    return target_col

def basic_feature_processing(df, numeric_cols, target_col=None, scaling='standardize'):
    """基本特征处理"""
    print("\n=== 基本特征处理 ===")
    
    # 复制数据
    df_processed = df.copy()
    
    # 排除目标变量列，不进行特征处理
    feature_cols = [col for col in numeric_cols if col != target_col] if target_col else numeric_cols
    print(f"\n特征列（排除目标变量）: {feature_cols}")
    if target_col:
        print(f"目标变量（不参与特征工程）: {target_col}")
    
    # 保存使用的转换器
    scalers = {}
    
    # 根据参数选择特征处理方法
    if scaling == 'standardize':
        # 标准化处理
        print("\n1. 标准化处理:")
        scaler = StandardScaler()
        df_processed[feature_cols] = scaler.fit_transform(df_processed[feature_cols])
        print(f"- 标准化处理完成，{len(feature_cols)} 个特征已标准化")
        scalers['standardize'] = scaler
    elif scaling == 'normalize':
        # 归一化处理
        print("\n1. 归一化处理:")
        min_max_scaler = MinMaxScaler()
        df_processed[feature_cols] = min_max_scaler.fit_transform(df_processed[feature_cols])
        print(f"- 归一化处理完成，{len(feature_cols)} 个特征已归一化")
        scalers['normalize'] = min_max_scaler
    else:
        # 不进行特征处理
        print("\n1. 特征处理:")
        print("- 未进行特征处理，使用原始特征")
    
    return df_processed, scalers

def enhanced_feature_processing(df, numeric_cols, target_col=None, scaling='standardize'):
    """增强特征处理"""
    print("\n=== 增强特征处理 ===")
    
    # 先进行基本特征处理
    df_processed, scalers = basic_feature_processing(df, numeric_cols, target_col, scaling)
    
    # 获取处理后的特征列（包含缩放后的特征）
    processed_feature_cols = []
    for col in df_processed.columns:
        if col != target_col and pd.api.types.is_numeric_dtype(df_processed[col]):
            processed_feature_cols.append(col)
    
    # 多项式特征
    print("\n3. 多项式特征生成:")
    poly = PolynomialFeatures(degree=2, interaction_only=False, include_bias=False)
    poly_features = poly.fit_transform(df_processed[processed_feature_cols])
    poly_feature_names = poly.get_feature_names_out(processed_feature_cols)
    
    # 添加多项式特征到数据框
    for i, feature_name in enumerate(poly_feature_names):
        df_processed[feature_name] = poly_features[:, i]
    print(f"- 多项式特征生成完成，新增 {len(poly_feature_names)} 个多项式特征")
    
    # 交互特征（手动添加一些重要的交互特征）
    print("\n4. 交互特征生成:")
    interaction_count = 0
    
    # 生成重要特征之间的交互
    if len(processed_feature_cols) >= 2:
        for i in range(len(processed_feature_cols)):
            for j in range(i+1, len(processed_feature_cols)):
                col1 = processed_feature_cols[i]
                col2 = processed_feature_cols[j]
                interaction_col = f"{col1}_{col2}_interaction"
                df_processed[interaction_col] = df_processed[col1] * df_processed[col2]
                interaction_count += 1
    
    print(f"- 交互特征生成完成，新增 {interaction_count} 个交互特征")
    
    return df_processed, scalers

def determine_task_type(df, target_col):
    """
    确定任务类型（分类或回归）
    
    参数:
    df: 输入数据框
    target_col: 目标变量列名
    
    返回:
    task_type: 'classification' 或 'regression'
    """
    if target_col and target_col in df.columns:
        target_series = df[target_col]
        # 检查目标变量是否为数值型
        if pd.api.types.is_numeric_dtype(target_series):
            # 检查唯一值数量，如果唯一值数量较少且为整数，可能是分类任务
            unique_values = target_series.unique()
            unique_count = len(unique_values)
            # 如果唯一值数量小于数据量的10%且为整数，认为是分类任务
            if unique_count < len(target_series) * 0.1 and pd.api.types.is_integer_dtype(target_series):
                print(f"\n任务类型判断: 分类任务（目标变量唯一值数量: {unique_count}）")
                return 'classification'
            else:
                print(f"\n任务类型判断: 回归任务（目标变量为连续数值）")
                return 'regression'
        else:
            print(f"\n任务类型判断: 分类任务（目标变量为非数值型）")
            return 'classification'
    else:
        print(f"\n任务类型判断: 回归任务（未指定目标变量或目标变量不存在）")
        return 'regression'

def feature_selection(df, numeric_cols, target_col=None, protect_elements=True):
    """
    特征筛选 - 根据任务类型选择合适的筛选方法
    
    参数:
    df: 输入数据框
    numeric_cols: 数值型列列表
    target_col: 目标变量列名
    protect_elements: 是否保护化学元素列，默认为True
    """
    print("\n=== 特征处理 ===")
    
    # 复制数据
    df_processed = df.copy()
    
    # 识别化学元素列
    element_cols = get_element_columns(df_processed)
    print(f"\n化学元素列 ({len(element_cols)}): {element_cols}")
    print(f"化学元素列保护: {'是' if protect_elements else '否'}")
    
    # 排除目标变量列
    if target_col:
        print(f"\n目标变量（不参与特征工程）: {target_col}")
    
    # 确定任务类型
    task_type = determine_task_type(df_processed, target_col)
    
    # 准备特征列
    if target_col:
        feature_cols = [col for col in numeric_cols if col != target_col]
    else:
        feature_cols = numeric_cols
    
    # 应用特征筛选
    selected_feature_cols = []
    
    if feature_cols:
        # 1. 方差阈值筛选（去除低方差特征）
        print("\n1. 应用方差阈值筛选:")
        from sklearn.feature_selection import VarianceThreshold
        var_thresh = VarianceThreshold(threshold=0.01)  # 去除方差小于0.01的特征
        var_thresh.fit(df_processed[feature_cols])
        var_selected = [feature_cols[i] for i, selected in enumerate(var_thresh.get_support()) if selected]
        print(f"- 方差阈值筛选后保留: {len(var_selected)} 个特征")
        
        # 2. 相关性筛选（去除高相关性特征）
        print("\n2. 应用相关性筛选:")
        corr_selected = []
        if len(var_selected) > 1:
            corr_matrix = df_processed[var_selected].corr().abs()
            # 上三角矩阵
            upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
            # 找出相关性大于0.9的列对
            to_drop = [column for column in upper.columns if any(upper[column] > 0.9)]
            corr_selected = [col for col in var_selected if col not in to_drop]
            print(f"- 相关性筛选后保留: {len(corr_selected)} 个特征")
        else:
            corr_selected = var_selected
        
        # 3. 根据任务类型应用不同的特征选择方法
        print("\n3. 应用任务类型特定的特征选择:")
        if target_col and len(corr_selected) > 0:
            X = df_processed[corr_selected]
            y = df_processed[target_col]
            
            if task_type == 'regression':
                # 回归任务：使用F检验
                from sklearn.feature_selection import SelectKBest, f_regression
                # 选择前20个特征（或全部特征，如果少于20个）
                k = min(20, len(corr_selected))
                selector = SelectKBest(f_regression, k=k)
                selector.fit(X, y)
                task_selected = [corr_selected[i] for i, selected in enumerate(selector.get_support()) if selected]
                print(f"- 回归任务特征选择后保留: {len(task_selected)} 个特征")
            else:
                # 分类任务：使用卡方检验
                from sklearn.feature_selection import SelectKBest, chi2
                # 确保特征值为非负
                X_pos = X - X.min() if X.min().min() < 0 else X
                # 选择前20个特征（或全部特征，如果少于20个）
                k = min(20, len(corr_selected))
                selector = SelectKBest(chi2, k=k)
                selector.fit(X_pos, y)
                task_selected = [corr_selected[i] for i, selected in enumerate(selector.get_support()) if selected]
                print(f"- 分类任务特征选择后保留: {len(task_selected)} 个特征")
        else:
            task_selected = corr_selected
        
        selected_feature_cols = task_selected
    else:
        selected_feature_cols = feature_cols
    
    # 保护化学元素列
    if protect_elements:
        for col in element_cols:
            if col in df_processed.columns and col not in selected_feature_cols:
                selected_feature_cols.append(col)
                print(f"- 保护化学元素列: {col}")
    
    # 保留所有字符列并保持原始顺序
    categorical_cols = df_processed.select_dtypes(include=['object', 'category']).columns.tolist()
    print(f"\n字符列 ({len(categorical_cols)}): {categorical_cols}")
    
    # 保持原始列顺序，确保字符列位置不变
    original_cols = df_processed.columns.tolist()
    
    # 构建最终列列表，保持原始顺序
    final_cols = []
    
    # 首先添加原始列中的字符列
    for col in original_cols:
        if col in categorical_cols:
            final_cols.append(col)
            print(f"- 保留字符列: {col}")
    
    # 然后添加原始列中属于selected_feature_cols的列（排除目标变量）
    for col in original_cols:
        if col in selected_feature_cols and col not in final_cols:
            final_cols.append(col)
    
    # 最后添加目标变量列（如果不在列表中）
    if target_col and target_col in df_processed.columns and target_col not in final_cols:
        final_cols.append(target_col)
    
    # 去重，确保没有重复列
    final_cols = list(dict.fromkeys(final_cols))
    
    # 保留筛选后的特征
    df_selected = df_processed[final_cols]
    print(f"\n- 特征处理完成")
    print(f"- 处理后的数据形状: {df_selected.shape}")
    print(f"- 保留特征数: {len(selected_feature_cols)}")
    print(f"- 保留字符列数: {len(categorical_cols)}")
    
    return df_selected, selected_feature_cols

def plot_feature_correlation(df, numeric_cols, output_dir):
    """绘制特征相关性热力图"""
    print("\n绘制特征相关性热力图...")
    
    # 计算相关性矩阵
    corr_matrix = df[numeric_cols].corr()
    
    # 创建热力图
    plt.figure(figsize=(15, 12))
    
    # 使用seaborn绘制热力图
    sns.heatmap(corr_matrix, annot=False, cmap='coolwarm', square=True, 
                linewidths=0.5, cbar_kws={'shrink': 0.8})
    
    # 设置标题和标签 - 使用英文确保显示正常
    plt.title('Feature Correlation Heatmap', fontsize=16, fontweight='bold', 
              fontfamily='DejaVu Sans')
    plt.xticks(fontsize=10, rotation=90, fontfamily='DejaVu Sans')
    plt.yticks(fontsize=10, fontfamily='DejaVu Sans')
    plt.xlabel('Features', fontsize=12, fontfamily='DejaVu Sans')
    plt.ylabel('Features', fontsize=12, fontfamily='DejaVu Sans')
    
    plt.tight_layout()
    
    # 保存图表
    output_path = os.path.join(output_dir, 'feature_correlation_heatmap.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"特征相关性热力图已保存到: {output_path}")

def plot_feature_importance(df, numeric_cols, target_col, output_dir):
    """绘制特征重要性图表"""
    print("\n绘制特征重要性图表...")
    
    if target_col and target_col in df.columns:
        X = df[numeric_cols]
        y = df[target_col]
        
        # 使用线性回归模型计算特征重要性
        model = LinearRegression()
        model.fit(X, y)
        
        # 获取特征重要性
        feature_importance = pd.DataFrame()
        feature_importance['Feature'] = numeric_cols
        feature_importance['Importance'] = abs(model.coef_)
        feature_importance = feature_importance.sort_values('Importance', ascending=False)
        
        # 创建图表
        plt.figure(figsize=(12, 8))
        sns.barplot(x='Importance', y='Feature', data=feature_importance.head(20), palette='viridis')
        
        # 设置标题和标签 - 使用英文确保显示正常
        plt.title('Feature Importance Ranking (Top 20)', fontsize=16, fontweight='bold', 
                  fontfamily='DejaVu Sans')
        plt.xlabel('Importance', fontsize=14, fontfamily='DejaVu Sans')
        plt.ylabel('Feature', fontsize=14, fontfamily='DejaVu Sans')
        
        # 设置坐标轴标签字体
        plt.xticks(fontfamily='DejaVu Sans')
        plt.yticks(fontfamily='DejaVu Sans')
        
        plt.tight_layout()
        
        # 保存图表
        output_path = os.path.join(output_dir, 'feature_importance.png')
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"特征重要性图表已保存到: {output_path}")

def plot_feature_distribution(df, numeric_cols, output_dir):
    """绘制特征分布图表"""
    print("\n绘制特征分布图表...")
    
    # 选择前10个数值型列
    if len(numeric_cols) > 10:
        plot_cols = numeric_cols[:10]
    else:
        plot_cols = numeric_cols
    
    # 创建子图
    n_cols = 2
    n_rows = (len(plot_cols) + n_cols - 1) // n_cols
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 4 * n_rows))
    axes = axes.flatten()
    
    # 绘制每个数值型列的分布
    for i, col in enumerate(plot_cols):
        if i < len(axes):
            sns.histplot(df[col], kde=True, ax=axes[i], color='steelblue', bins=30)
            axes[i].set_title(f'{col} 分布', fontsize=12, fontweight='bold')
            axes[i].set_xlabel(col, fontsize=10)
            axes[i].set_ylabel('频率', fontsize=10)
    
    # 隐藏多余的子图
    for i in range(len(plot_cols), len(axes)):
        axes[i].set_visible(False)
    
    plt.tight_layout()
    
    # 保存图表
    output_path = os.path.join(output_dir, 'feature_distribution.png')
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"特征分布图表已保存到: {output_path}")

def save_statistics(df, analysis_dir):
    """保存统计信息"""
    print("\n保存详细统计信息...")
    
    try:
        # 生成统计信息DataFrame
        stats_df = pd.DataFrame()
        numeric_cols = df.select_dtypes(include=['number']).columns
        
        for col in numeric_cols:
            stats = {
                'Column': col,
                'Count': len(df[col]),
                'Non-Null Count': df[col].count(),
                'Null Count': df[col].isna().sum(),
                'Min': df[col].min(),
                'Max': df[col].max(),
                'Mean': df[col].mean(),
                'Std': df[col].std(),
                'Median': df[col].median()
            }
            stats_df = pd.concat([stats_df, pd.DataFrame([stats])], ignore_index=True)
        
        # 保存统计信息为Excel和CSV文件
        stats_excel_path = os.path.join(analysis_dir, 'feature_statistics.xlsx')
        stats_csv_path = os.path.join(analysis_dir, 'feature_statistics.csv')
        stats_df.to_excel(stats_excel_path, index=False)
        stats_df.to_csv(stats_csv_path, index=False, encoding='utf-8-sig')
        print(f"详细统计信息已保存到: {stats_excel_path}")
        print(f"详细统计信息已保存到: {stats_csv_path}")
    except Exception as e:
        print(f"保存统计信息时出错: {e}")

def analyze_data(file_path, feature_engineering_dir, analysis_dir, visualization_dir, mode=1, target_col=None, protect_elements=True, scaling='standardize'):
    """
    分析数据文件：执行特征工程处理，生成可视化
    
    参数:
    file_path: 输入文件路径
    feature_engineering_dir: 特征工程输出目录
    analysis_dir: 数据分析输出目录
    visualization_dir: 数据可视化输出目录
    mode: 处理模式，1-普通模式，2-增强模式
    target_col: 目标变量列名
    protect_elements: 是否保护化学元素列
    scaling: 特征处理方法，standardize-标准化, normalize-归一化, none-不处理
    """
    print(f"开始分析文件: {file_path}")
    
    # 加载数据
    df = load_data(file_path)
    if df is None:
        return
    
    # 获取数值型列
    numeric_cols = get_numeric_columns(df)
    if not numeric_cols:
        print("没有找到数值型列，无法进行特征工程")
        return
    
    # 获取目标变量列名
    if not target_col:
        target_col = get_target_column(df)
    elif target_col not in df.columns:
        print(f"指定的目标变量列 '{target_col}' 不存在，默认使用最后一列")
        target_col = df.columns[-1]
        print(f"选择的目标变量列: {target_col}")
    else:
        print(f"选择的目标变量列: {target_col}")
    
    # 根据模式执行特征工程
    if mode == 2:
        # 增强模式
        print("\n执行增强模式特征工程...")
        df_processed, scalers = enhanced_feature_processing(df, numeric_cols, target_col, scaling)
    else:
        # 普通模式
        print("\n执行普通模式特征工程...")
        df_processed, scalers = basic_feature_processing(df, numeric_cols, target_col, scaling)
    
    # 保存转换器
    if scalers:
        import joblib
        scaler_dir = os.path.join(feature_engineering_dir, 'scalers')
        os.makedirs(scaler_dir, exist_ok=True)
        for scaler_type, scaler in scalers.items():
            scaler_path = os.path.join(scaler_dir, f'{scaler_type}_scaler.joblib')
            joblib.dump(scaler, scaler_path)
            print(f"保存{scaler_type}转换器到: {scaler_path}")
    
    # 更新数值型列列表（包含新生成的特征）
    new_numeric_cols = get_numeric_columns(df_processed)
    
    # 特征筛选
    df_selected, selected_feature_cols = feature_selection(df_processed, new_numeric_cols, target_col, protect_elements)
    
    # 保存特征列表
    print(f"\n保存特征列表...")
    try:
        feature_list_path = os.path.join(feature_engineering_dir, f"feature_list.txt")
        with open(feature_list_path, 'w', encoding='utf-8') as f:
            f.write("# 特征列表\n")
            f.write("# 这些特征可用于后续的机器学习模型\n\n")
            f.write("# 选择的特征:\n")
            for feature in selected_feature_cols:
                f.write(f"{feature}\n")
            if target_col:
                f.write(f"\n# 目标变量:\n{target_col}\n")
        print(f"特征列表已保存到: {feature_list_path}")
    except Exception as e:
        print(f"保存特征列表时出错: {e}")
    
    # 生成可视化图表
    print(f"\n生成数据可视化图表...")
    try:
        plot_feature_correlation(df_selected, df_selected.select_dtypes(include=['number']).columns.tolist(), visualization_dir)
        if target_col:
            plot_feature_importance(df_selected, df_selected.select_dtypes(include=['number']).columns.tolist(), target_col, visualization_dir)
        plot_feature_distribution(df_selected, df_selected.select_dtypes(include=['number']).columns.tolist(), visualization_dir)
    except Exception as e:
        print(f"生成可视化图表时出错: {e}")
    
    # 保存详细统计信息
    save_statistics(df_selected, analysis_dir)
    
    # 保存处理后的数据
    try:
        # 获取文件名并创建新的输出路径
        file_name = os.path.basename(file_path)
        base_name, ext = os.path.splitext(file_name)
        
        # 根据处理方法修改输出文件名
        processing_suffix = ''
        if scaling == 'standardize':
            processing_suffix = '_standardized'
        elif scaling == 'normalize':
            processing_suffix = '_normalized'
        elif scaling == 'none':
            processing_suffix = '_original'
        
        # 保存为Excel文件
        excel_output_path = os.path.join(feature_engineering_dir, f"{base_name}{processing_suffix}_engineered.xlsx")
        df_selected.to_excel(excel_output_path, index=False)
        print(f"\n处理后的数据已保存到: {excel_output_path}")
        
        # 保存为CSV文件
        csv_output_path = os.path.join(feature_engineering_dir, f"{base_name}{processing_suffix}_engineered.csv")
        df_selected.to_csv(csv_output_path, index=False, encoding='utf-8-sig')
        print(f"处理后的数据已保存到: {csv_output_path}")
    except Exception as e:
        print(f"保存处理后的数据时出错: {e}")
    
    print(f"\n分析完成！")
    print(f"\n处理流程总结:")
    print(f"1. 特征工程模式: {'增强模式' if mode == 2 else '普通模式'}")
    print(f"2. 特征处理方法: {'标准化' if scaling == 'standardize' else '归一化' if scaling == 'normalize' else '原始特征'}")
    print(f"3. 原始特征数: {len(numeric_cols)}")
    print(f"4. 处理后特征数: {len(df_selected.select_dtypes(include=['number']).columns)}")
    print(f"5. 化学元素列保护: {'是' if protect_elements else '否'}")
    print(f"6. 生成可视化图表: 包含特征相关性、特征重要性、特征分布等")
    print(f"7. 保存结果: 同时保存为Excel和CSV格式")
    print(f"\n处理后的数据已准备就绪，可以直接用于机器学习模型！")


def run(args=None):
    if args is None:
        args = parse_arguments()

    logs_dir, feature_engineering_dir, analysis_dir, visualization_dir = setup_directories()

    log_path = setup_logging(logs_dir)
    sys.stdout = Logger(log_path)

    print(f"日志文件路径: {log_path}")
    print(f"特征工程输出目录: {feature_engineering_dir}")
    print(f"数据分析输出目录: {analysis_dir}")
    print(f"数据可视化输出目录: {visualization_dir}")
    print(f"特征处理方法: {'标准化' if args.scaling == 'standardize' else '归一化' if args.scaling == 'normalize' else '原始特征'}")

    print("\n自动查找descript_data_clean目录下最新的清洗后数据文件...")
    data_file_path = find_latest_cleaned_file()

    if data_file_path is None:
        print("无法找到清洗后的数据文件，请确保descript_data_clean目录中有数据文件")
        sys.exit(1)

    protect_elements = not args.no_protect_elements
    analyze_data(data_file_path, feature_engineering_dir, analysis_dir, visualization_dir,
                 args.mode, args.target, protect_elements, args.scaling)


if __name__ == "__main__":
    run()
