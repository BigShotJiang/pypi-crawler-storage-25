# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .v1 import (
    V1Resource,
    AsyncV1Resource,
    V1ResourceWithRawResponse,
    AsyncV1ResourceWithRawResponse,
    V1ResourceWithStreamingResponse,
    AsyncV1ResourceWithStreamingResponse,
)
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource

__all__ = ["SuperdocResource", "AsyncSuperdocResource"]


class SuperdocResource(SyncAPIResource):
    @cached_property
    def v1(self) -> V1Resource:
        """Document conversion and template automation"""
        return V1Resource(self._client)

    @cached_property
    def with_raw_response(self) -> SuperdocResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/CaseMark/casedev-python#accessing-raw-response-data-eg-headers
        """
        return SuperdocResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SuperdocResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/CaseMark/casedev-python#with_streaming_response
        """
        return SuperdocResourceWithStreamingResponse(self)


class AsyncSuperdocResource(AsyncAPIResource):
    @cached_property
    def v1(self) -> AsyncV1Resource:
        """Document conversion and template automation"""
        return AsyncV1Resource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncSuperdocResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/CaseMark/casedev-python#accessing-raw-response-data-eg-headers
        """
        return AsyncSuperdocResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSuperdocResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/CaseMark/casedev-python#with_streaming_response
        """
        return AsyncSuperdocResourceWithStreamingResponse(self)


class SuperdocResourceWithRawResponse:
    def __init__(self, superdoc: SuperdocResource) -> None:
        self._superdoc = superdoc

    @cached_property
    def v1(self) -> V1ResourceWithRawResponse:
        """Document conversion and template automation"""
        return V1ResourceWithRawResponse(self._superdoc.v1)


class AsyncSuperdocResourceWithRawResponse:
    def __init__(self, superdoc: AsyncSuperdocResource) -> None:
        self._superdoc = superdoc

    @cached_property
    def v1(self) -> AsyncV1ResourceWithRawResponse:
        """Document conversion and template automation"""
        return AsyncV1ResourceWithRawResponse(self._superdoc.v1)


class SuperdocResourceWithStreamingResponse:
    def __init__(self, superdoc: SuperdocResource) -> None:
        self._superdoc = superdoc

    @cached_property
    def v1(self) -> V1ResourceWithStreamingResponse:
        """Document conversion and template automation"""
        return V1ResourceWithStreamingResponse(self._superdoc.v1)


class AsyncSuperdocResourceWithStreamingResponse:
    def __init__(self, superdoc: AsyncSuperdocResource) -> None:
        self._superdoc = superdoc

    @cached_property
    def v1(self) -> AsyncV1ResourceWithStreamingResponse:
        """Document conversion and template automation"""
        return AsyncV1ResourceWithStreamingResponse(self._superdoc.v1)
