# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .secrets import (
    SecretsResource,
    AsyncSecretsResource,
    SecretsResourceWithRawResponse,
    AsyncSecretsResourceWithRawResponse,
    SecretsResourceWithStreamingResponse,
    AsyncSecretsResourceWithStreamingResponse,
)
from ...._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ...._utils import maybe_transform, async_maybe_transform
from .instances import (
    InstancesResource,
    AsyncInstancesResource,
    InstancesResourceWithRawResponse,
    AsyncInstancesResourceWithRawResponse,
    InstancesResourceWithStreamingResponse,
    AsyncInstancesResourceWithStreamingResponse,
)
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .environments import (
    EnvironmentsResource,
    AsyncEnvironmentsResource,
    EnvironmentsResourceWithRawResponse,
    AsyncEnvironmentsResourceWithRawResponse,
    EnvironmentsResourceWithStreamingResponse,
    AsyncEnvironmentsResourceWithStreamingResponse,
)
from .instance_types import (
    InstanceTypesResource,
    AsyncInstanceTypesResource,
    InstanceTypesResourceWithRawResponse,
    AsyncInstanceTypesResourceWithRawResponse,
    InstanceTypesResourceWithStreamingResponse,
    AsyncInstanceTypesResourceWithStreamingResponse,
)
from ...._base_client import make_request_options
from ....types.compute import v1_get_usage_params
from ....types.compute.v1_get_usage_response import V1GetUsageResponse

__all__ = ["V1Resource", "AsyncV1Resource"]


class V1Resource(SyncAPIResource):
    """Serverless GPU and CPU infrastructure"""

    @cached_property
    def environments(self) -> EnvironmentsResource:
        """Serverless GPU and CPU infrastructure"""
        return EnvironmentsResource(self._client)

    @cached_property
    def instance_types(self) -> InstanceTypesResource:
        """Serverless GPU and CPU infrastructure"""
        return InstanceTypesResource(self._client)

    @cached_property
    def instances(self) -> InstancesResource:
        """Serverless GPU and CPU infrastructure"""
        return InstancesResource(self._client)

    @cached_property
    def secrets(self) -> SecretsResource:
        """Serverless GPU and CPU infrastructure"""
        return SecretsResource(self._client)

    @cached_property
    def with_raw_response(self) -> V1ResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/CaseMark/casedev-python#accessing-raw-response-data-eg-headers
        """
        return V1ResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> V1ResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/CaseMark/casedev-python#with_streaming_response
        """
        return V1ResourceWithStreamingResponse(self)

    def get_pricing(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Returns current pricing for GPU instances.

        Prices are fetched in real-time and
        include a 20% platform fee. For detailed instance types and availability, use
        GET /compute/v1/instance-types.
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._get(
            "/compute/v1/pricing",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def get_usage(
        self,
        *,
        month: int | Omit = omit,
        year: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> V1GetUsageResponse:
        """
        Returns detailed compute usage statistics and billing information for your
        organization. Includes GPU and CPU hours, total runs, costs, and breakdowns by
        environment. Use optional query parameters to filter by specific year and month.

        Args:
          month: Month to filter usage data (1-12, defaults to current month)

          year: Year to filter usage data (defaults to current year)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/compute/v1/usage",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "month": month,
                        "year": year,
                    },
                    v1_get_usage_params.V1GetUsageParams,
                ),
            ),
            cast_to=V1GetUsageResponse,
        )


class AsyncV1Resource(AsyncAPIResource):
    """Serverless GPU and CPU infrastructure"""

    @cached_property
    def environments(self) -> AsyncEnvironmentsResource:
        """Serverless GPU and CPU infrastructure"""
        return AsyncEnvironmentsResource(self._client)

    @cached_property
    def instance_types(self) -> AsyncInstanceTypesResource:
        """Serverless GPU and CPU infrastructure"""
        return AsyncInstanceTypesResource(self._client)

    @cached_property
    def instances(self) -> AsyncInstancesResource:
        """Serverless GPU and CPU infrastructure"""
        return AsyncInstancesResource(self._client)

    @cached_property
    def secrets(self) -> AsyncSecretsResource:
        """Serverless GPU and CPU infrastructure"""
        return AsyncSecretsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncV1ResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/CaseMark/casedev-python#accessing-raw-response-data-eg-headers
        """
        return AsyncV1ResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncV1ResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/CaseMark/casedev-python#with_streaming_response
        """
        return AsyncV1ResourceWithStreamingResponse(self)

    async def get_pricing(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Returns current pricing for GPU instances.

        Prices are fetched in real-time and
        include a 20% platform fee. For detailed instance types and availability, use
        GET /compute/v1/instance-types.
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._get(
            "/compute/v1/pricing",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def get_usage(
        self,
        *,
        month: int | Omit = omit,
        year: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> V1GetUsageResponse:
        """
        Returns detailed compute usage statistics and billing information for your
        organization. Includes GPU and CPU hours, total runs, costs, and breakdowns by
        environment. Use optional query parameters to filter by specific year and month.

        Args:
          month: Month to filter usage data (1-12, defaults to current month)

          year: Year to filter usage data (defaults to current year)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/compute/v1/usage",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "month": month,
                        "year": year,
                    },
                    v1_get_usage_params.V1GetUsageParams,
                ),
            ),
            cast_to=V1GetUsageResponse,
        )


class V1ResourceWithRawResponse:
    def __init__(self, v1: V1Resource) -> None:
        self._v1 = v1

        self.get_pricing = to_raw_response_wrapper(
            v1.get_pricing,
        )
        self.get_usage = to_raw_response_wrapper(
            v1.get_usage,
        )

    @cached_property
    def environments(self) -> EnvironmentsResourceWithRawResponse:
        """Serverless GPU and CPU infrastructure"""
        return EnvironmentsResourceWithRawResponse(self._v1.environments)

    @cached_property
    def instance_types(self) -> InstanceTypesResourceWithRawResponse:
        """Serverless GPU and CPU infrastructure"""
        return InstanceTypesResourceWithRawResponse(self._v1.instance_types)

    @cached_property
    def instances(self) -> InstancesResourceWithRawResponse:
        """Serverless GPU and CPU infrastructure"""
        return InstancesResourceWithRawResponse(self._v1.instances)

    @cached_property
    def secrets(self) -> SecretsResourceWithRawResponse:
        """Serverless GPU and CPU infrastructure"""
        return SecretsResourceWithRawResponse(self._v1.secrets)


class AsyncV1ResourceWithRawResponse:
    def __init__(self, v1: AsyncV1Resource) -> None:
        self._v1 = v1

        self.get_pricing = async_to_raw_response_wrapper(
            v1.get_pricing,
        )
        self.get_usage = async_to_raw_response_wrapper(
            v1.get_usage,
        )

    @cached_property
    def environments(self) -> AsyncEnvironmentsResourceWithRawResponse:
        """Serverless GPU and CPU infrastructure"""
        return AsyncEnvironmentsResourceWithRawResponse(self._v1.environments)

    @cached_property
    def instance_types(self) -> AsyncInstanceTypesResourceWithRawResponse:
        """Serverless GPU and CPU infrastructure"""
        return AsyncInstanceTypesResourceWithRawResponse(self._v1.instance_types)

    @cached_property
    def instances(self) -> AsyncInstancesResourceWithRawResponse:
        """Serverless GPU and CPU infrastructure"""
        return AsyncInstancesResourceWithRawResponse(self._v1.instances)

    @cached_property
    def secrets(self) -> AsyncSecretsResourceWithRawResponse:
        """Serverless GPU and CPU infrastructure"""
        return AsyncSecretsResourceWithRawResponse(self._v1.secrets)


class V1ResourceWithStreamingResponse:
    def __init__(self, v1: V1Resource) -> None:
        self._v1 = v1

        self.get_pricing = to_streamed_response_wrapper(
            v1.get_pricing,
        )
        self.get_usage = to_streamed_response_wrapper(
            v1.get_usage,
        )

    @cached_property
    def environments(self) -> EnvironmentsResourceWithStreamingResponse:
        """Serverless GPU and CPU infrastructure"""
        return EnvironmentsResourceWithStreamingResponse(self._v1.environments)

    @cached_property
    def instance_types(self) -> InstanceTypesResourceWithStreamingResponse:
        """Serverless GPU and CPU infrastructure"""
        return InstanceTypesResourceWithStreamingResponse(self._v1.instance_types)

    @cached_property
    def instances(self) -> InstancesResourceWithStreamingResponse:
        """Serverless GPU and CPU infrastructure"""
        return InstancesResourceWithStreamingResponse(self._v1.instances)

    @cached_property
    def secrets(self) -> SecretsResourceWithStreamingResponse:
        """Serverless GPU and CPU infrastructure"""
        return SecretsResourceWithStreamingResponse(self._v1.secrets)


class AsyncV1ResourceWithStreamingResponse:
    def __init__(self, v1: AsyncV1Resource) -> None:
        self._v1 = v1

        self.get_pricing = async_to_streamed_response_wrapper(
            v1.get_pricing,
        )
        self.get_usage = async_to_streamed_response_wrapper(
            v1.get_usage,
        )

    @cached_property
    def environments(self) -> AsyncEnvironmentsResourceWithStreamingResponse:
        """Serverless GPU and CPU infrastructure"""
        return AsyncEnvironmentsResourceWithStreamingResponse(self._v1.environments)

    @cached_property
    def instance_types(self) -> AsyncInstanceTypesResourceWithStreamingResponse:
        """Serverless GPU and CPU infrastructure"""
        return AsyncInstanceTypesResourceWithStreamingResponse(self._v1.instance_types)

    @cached_property
    def instances(self) -> AsyncInstancesResourceWithStreamingResponse:
        """Serverless GPU and CPU infrastructure"""
        return AsyncInstancesResourceWithStreamingResponse(self._v1.instances)

    @cached_property
    def secrets(self) -> AsyncSecretsResourceWithStreamingResponse:
        """Serverless GPU and CPU infrastructure"""
        return AsyncSecretsResourceWithStreamingResponse(self._v1.secrets)
