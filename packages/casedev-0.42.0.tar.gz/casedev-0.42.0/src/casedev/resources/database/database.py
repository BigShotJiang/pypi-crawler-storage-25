# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .v1.v1 import (
    V1Resource,
    AsyncV1Resource,
    V1ResourceWithRawResponse,
    AsyncV1ResourceWithRawResponse,
    V1ResourceWithStreamingResponse,
    AsyncV1ResourceWithStreamingResponse,
)
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource

__all__ = ["DatabaseResource", "AsyncDatabaseResource"]


class DatabaseResource(SyncAPIResource):
    @cached_property
    def v1(self) -> V1Resource:
        """Serverless PostgreSQL databases with instant branching"""
        return V1Resource(self._client)

    @cached_property
    def with_raw_response(self) -> DatabaseResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/CaseMark/casedev-python#accessing-raw-response-data-eg-headers
        """
        return DatabaseResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> DatabaseResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/CaseMark/casedev-python#with_streaming_response
        """
        return DatabaseResourceWithStreamingResponse(self)


class AsyncDatabaseResource(AsyncAPIResource):
    @cached_property
    def v1(self) -> AsyncV1Resource:
        """Serverless PostgreSQL databases with instant branching"""
        return AsyncV1Resource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncDatabaseResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/CaseMark/casedev-python#accessing-raw-response-data-eg-headers
        """
        return AsyncDatabaseResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncDatabaseResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/CaseMark/casedev-python#with_streaming_response
        """
        return AsyncDatabaseResourceWithStreamingResponse(self)


class DatabaseResourceWithRawResponse:
    def __init__(self, database: DatabaseResource) -> None:
        self._database = database

    @cached_property
    def v1(self) -> V1ResourceWithRawResponse:
        """Serverless PostgreSQL databases with instant branching"""
        return V1ResourceWithRawResponse(self._database.v1)


class AsyncDatabaseResourceWithRawResponse:
    def __init__(self, database: AsyncDatabaseResource) -> None:
        self._database = database

    @cached_property
    def v1(self) -> AsyncV1ResourceWithRawResponse:
        """Serverless PostgreSQL databases with instant branching"""
        return AsyncV1ResourceWithRawResponse(self._database.v1)


class DatabaseResourceWithStreamingResponse:
    def __init__(self, database: DatabaseResource) -> None:
        self._database = database

    @cached_property
    def v1(self) -> V1ResourceWithStreamingResponse:
        """Serverless PostgreSQL databases with instant branching"""
        return V1ResourceWithStreamingResponse(self._database.v1)


class AsyncDatabaseResourceWithStreamingResponse:
    def __init__(self, database: AsyncDatabaseResource) -> None:
        self._database = database

    @cached_property
    def v1(self) -> AsyncV1ResourceWithStreamingResponse:
        """Serverless PostgreSQL databases with instant branching"""
        return AsyncV1ResourceWithStreamingResponse(self._database.v1)
