# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .projects import (
    ProjectsResource,
    AsyncProjectsResource,
    ProjectsResourceWithRawResponse,
    AsyncProjectsResourceWithRawResponse,
    ProjectsResourceWithStreamingResponse,
    AsyncProjectsResourceWithStreamingResponse,
)
from ...._types import Body, Query, Headers, NotGiven, not_given
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.database.v1_get_usage_response import V1GetUsageResponse

__all__ = ["V1Resource", "AsyncV1Resource"]


class V1Resource(SyncAPIResource):
    """Serverless PostgreSQL databases with instant branching"""

    @cached_property
    def projects(self) -> ProjectsResource:
        """Serverless PostgreSQL databases with instant branching"""
        return ProjectsResource(self._client)

    @cached_property
    def with_raw_response(self) -> V1ResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/CaseMark/casedev-python#accessing-raw-response-data-eg-headers
        """
        return V1ResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> V1ResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/CaseMark/casedev-python#with_streaming_response
        """
        return V1ResourceWithStreamingResponse(self)

    def get_usage(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> V1GetUsageResponse:
        """
        Returns detailed database usage statistics and billing information for the
        current billing period. Includes compute hours, storage, data transfer, and
        branch counts with associated costs broken down by project.
        """
        return self._get(
            "/database/v1/usage",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=V1GetUsageResponse,
        )


class AsyncV1Resource(AsyncAPIResource):
    """Serverless PostgreSQL databases with instant branching"""

    @cached_property
    def projects(self) -> AsyncProjectsResource:
        """Serverless PostgreSQL databases with instant branching"""
        return AsyncProjectsResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncV1ResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/CaseMark/casedev-python#accessing-raw-response-data-eg-headers
        """
        return AsyncV1ResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncV1ResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/CaseMark/casedev-python#with_streaming_response
        """
        return AsyncV1ResourceWithStreamingResponse(self)

    async def get_usage(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> V1GetUsageResponse:
        """
        Returns detailed database usage statistics and billing information for the
        current billing period. Includes compute hours, storage, data transfer, and
        branch counts with associated costs broken down by project.
        """
        return await self._get(
            "/database/v1/usage",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=V1GetUsageResponse,
        )


class V1ResourceWithRawResponse:
    def __init__(self, v1: V1Resource) -> None:
        self._v1 = v1

        self.get_usage = to_raw_response_wrapper(
            v1.get_usage,
        )

    @cached_property
    def projects(self) -> ProjectsResourceWithRawResponse:
        """Serverless PostgreSQL databases with instant branching"""
        return ProjectsResourceWithRawResponse(self._v1.projects)


class AsyncV1ResourceWithRawResponse:
    def __init__(self, v1: AsyncV1Resource) -> None:
        self._v1 = v1

        self.get_usage = async_to_raw_response_wrapper(
            v1.get_usage,
        )

    @cached_property
    def projects(self) -> AsyncProjectsResourceWithRawResponse:
        """Serverless PostgreSQL databases with instant branching"""
        return AsyncProjectsResourceWithRawResponse(self._v1.projects)


class V1ResourceWithStreamingResponse:
    def __init__(self, v1: V1Resource) -> None:
        self._v1 = v1

        self.get_usage = to_streamed_response_wrapper(
            v1.get_usage,
        )

    @cached_property
    def projects(self) -> ProjectsResourceWithStreamingResponse:
        """Serverless PostgreSQL databases with instant branching"""
        return ProjectsResourceWithStreamingResponse(self._v1.projects)


class AsyncV1ResourceWithStreamingResponse:
    def __init__(self, v1: AsyncV1Resource) -> None:
        self._v1 = v1

        self.get_usage = async_to_streamed_response_wrapper(
            v1.get_usage,
        )

    @cached_property
    def projects(self) -> AsyncProjectsResourceWithStreamingResponse:
        """Serverless PostgreSQL databases with instant branching"""
        return AsyncProjectsResourceWithStreamingResponse(self._v1.projects)
