# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from casedev import Casedev, AsyncCasedev
from tests.utils import assert_matches_type
from casedev.types import SystemListServicesResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSystem:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_list_services(self, client: Casedev) -> None:
        system = client.system.list_services()
        assert_matches_type(SystemListServicesResponse, system, path=["response"])

    @parametrize
    def test_raw_response_list_services(self, client: Casedev) -> None:
        response = client.system.with_raw_response.list_services()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        system = response.parse()
        assert_matches_type(SystemListServicesResponse, system, path=["response"])

    @parametrize
    def test_streaming_response_list_services(self, client: Casedev) -> None:
        with client.system.with_streaming_response.list_services() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            system = response.parse()
            assert_matches_type(SystemListServicesResponse, system, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncSystem:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_list_services(self, async_client: AsyncCasedev) -> None:
        system = await async_client.system.list_services()
        assert_matches_type(SystemListServicesResponse, system, path=["response"])

    @parametrize
    async def test_raw_response_list_services(self, async_client: AsyncCasedev) -> None:
        response = await async_client.system.with_raw_response.list_services()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        system = await response.parse()
        assert_matches_type(SystemListServicesResponse, system, path=["response"])

    @parametrize
    async def test_streaming_response_list_services(self, async_client: AsyncCasedev) -> None:
        async with async_client.system.with_streaming_response.list_services() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            system = await response.parse()
            assert_matches_type(SystemListServicesResponse, system, path=["response"])

        assert cast(Any, response.is_closed) is True
