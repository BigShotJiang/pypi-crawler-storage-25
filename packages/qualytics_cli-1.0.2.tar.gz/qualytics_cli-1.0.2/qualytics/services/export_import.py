"""Export/import service — hierarchical YAML config-as-code.

Folder structure produced by export::

    <output>/
        connections/
            <connection_name>.yaml
        datastores/
            <datastore_name>/
                _datastore.yaml
                containers/
                    <container_name>/
                        _container.yaml
                        computed_fields/
                            <field_name>.yaml
                checks/
                    <container_slug>/
                        <rule_type>__<fields>.yaml

Import reads the same structure in dependency order:
connections → datastores → containers → computed fields → quality checks.
"""

import re
from pathlib import Path

import yaml

from ..api.client import QualyticsClient
from ..api.computed_fields import (
    create_computed_field,
    update_computed_field,
)
from ..api.connections import (
    create_connection,
    update_connection,
)
from ..api.containers import (
    create_container,
    get_container,
    list_all_containers,
    update_container,
)
from ..api.datastores import (
    connect_enrichment,
    create_datastore,
    get_datastore,
    update_datastore,
)
from ..api.operations import run_operation, get_operation
from ..api.quality_checks import list_all_quality_checks
from ..services.connections import get_connection_by_name
from ..services.containers import get_container_by_name
from ..services.datastores import get_datastore_by_name
from ..services.quality_checks import (
    export_checks_to_directory,
    import_checks_to_datastore,
    load_checks_from_directory,
)
from ..utils.secrets import resolve_env_vars
from ..utils.serialization import _SafeStringLoader

# ── Helpers ──────────────────────────────────────────────────────────────


def _slugify(text: str) -> str:
    """Lowercase, replace non-alnum with underscores, collapse multiples."""
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return text.strip("_")


def _write_yaml(path: Path, data: dict) -> bool:
    """Write *data* as YAML to *path*.

    Returns True if the file was written (content changed or new),
    False if the file already had identical content.
    """
    content = yaml.safe_dump(
        data,
        default_flow_style=False,
        sort_keys=False,
        allow_unicode=True,
    )
    if path.exists() and path.read_text() == content:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return True


def _generate_env_var_name(connection_name: str, field: str) -> str:
    """Generate an env var placeholder: ``${CONN_NAME_FIELD}``."""
    prefix = _slugify(connection_name).upper()
    return f"${{{prefix}_{field.upper()}}}"


# ── Secrets fields to strip / placeholder ────────────────────────────────

_CONNECTION_SECRET_FIELDS = frozenset({"password", "secret_key", "credentials_payload"})

# Fields the API never returns (already masked), but we still want
# placeholder env vars in the export for documentation.
_CONNECTION_SENSITIVE_FIELDS = frozenset(
    {"password", "secret_key", "credentials_payload", "access_key"}
)

# Internal-only connection fields to strip on export
_CONNECTION_INTERNAL_FIELDS = frozenset(
    {
        "id",
        "created",
        "connection_type",
        "datastores",
        "product_name",
        "product_version",
        "driver_name",
        "driver_version",
    }
)

# Connection-level read-only fields (derived from the connection object,
# not accepted by the datastore PUT endpoint)
_DATASTORE_READONLY_FIELDS = frozenset(
    {
        "jdbc_url",
        "host",
        "port",
        "username",
        "parameters",
        "jdbc_fetch_size",
        "max_parallelization",
        "secrets_manager",
        "store_type",
        "type",
        "group",
        "linked_datastores",
        "has_scheduled_operations",
    }
)

# Internal-only datastore fields to strip on export
_DATASTORE_INTERNAL_FIELDS = (
    frozenset(
        {
            "id",
            "created",
            "connected",
            "favorite",
            "latest_operation",
            "metrics",
            "anomaly_count",
            "check_count",
            "container_count",
            "field_count",
            "record_count",
            "score",
            "overall_score",
            "completeness_score",
            "conformity_score",
            "consistency_score",
            "precision_score",
            "timeliness_score",
            "volume_score",
            "accuracy_score",
            "uniqueness_score",
            "containers",
            "connection",
            "connection_id",
            "product_name",
            "product_version",
            "driver_name",
            "driver_version",
        }
    )
    | _DATASTORE_READONLY_FIELDS
)

# Container internal fields to strip
_CONTAINER_INTERNAL_FIELDS = frozenset(
    {
        "id",
        "created",
        "status",
        "metrics",
        "computed_fields",
        "field_count",
        "anomaly_count",
        "check_count",
        "record_count",
        "score",
        "cataloged",
        "datastore",
        "favorite",
        "deleted_at",
        "last_editor",
        "latest_observability_measurement",
        "incremental_checkpoint",
    }
)

# Computed field internal fields to strip on export
_COMPUTED_FIELD_INTERNAL_FIELDS = frozenset(
    {"id", "container_id", "last_editor_id", "last_editor"}
)

# Computed container types
_COMPUTED_TYPES = frozenset({"computed_table", "computed_file", "computed_join"})

# ── Sync helper ──────────────────────────────────────────────────────────

# Default sync timeout for import (10 minutes)
_SYNC_TIMEOUT = 600
_SYNC_POLL_INTERVAL = 10


def _run_sync_for_import(
    client: QualyticsClient,
    datastore_id: int,
    *,
    timeout: int = _SYNC_TIMEOUT,
    poll_interval: int = _SYNC_POLL_INTERVAL,
) -> dict:
    """Run a sync operation for a datastore and wait for completion.

    Returns {success: bool, error: str | None}.
    """
    import time

    payload = {
        "datastore_id": datastore_id,
        "type": "sync",
        "prune": False,
        "recreate": False,
    }

    try:
        result = run_operation(client, payload)
        op_id = result["id"]
    except Exception as e:
        return {"success": False, "error": f"Failed to start sync: {e}"}

    start = time.monotonic()
    while True:
        elapsed = time.monotonic() - start
        if elapsed >= timeout:
            return {
                "success": False,
                "error": f"Sync timed out after {int(elapsed)}s",
            }

        response = get_operation(client, op_id)
        if response.get("end_time"):
            if response.get("result") == "success":
                return {"success": True, "error": None}
            msg = response.get("message") or response.get("result", "unknown error")
            return {"success": False, "error": f"Sync failed: {msg}"}

        time.sleep(poll_interval)


# ── Strip functions ──────────────────────────────────────────────────────


def strip_connection_for_export(conn: dict) -> dict:
    """Convert an API connection response into a portable YAML dict.

    Secret fields are replaced with ``${ENV_VAR}`` placeholders.
    """
    portable: dict = {}
    for key, value in conn.items():
        if key in _CONNECTION_INTERNAL_FIELDS:
            continue
        if key in _CONNECTION_SENSITIVE_FIELDS:
            # Replace with env-var placeholder
            conn_name = conn.get("name", "unknown")
            portable[key] = _generate_env_var_name(conn_name, key)
            continue
        portable[key] = value
    return portable


def strip_datastore_for_export(ds: dict) -> dict:
    """Convert an API datastore response into a portable YAML dict.

    Replaces ``connection`` object with ``connection_name`` string.
    Replaces ``enrich_datastore`` object with ``enrich_datastore_name``.
    """
    portable: dict = {}

    # Connection reference → name (with fallbacks)
    conn = ds.get("connection")
    if conn and isinstance(conn, dict):
        conn_name = conn.get("name")
        if conn_name:
            portable["connection_name"] = conn_name
        elif conn.get("id"):
            portable["connection_id"] = conn["id"]
    elif isinstance(conn, int):
        portable["connection_id"] = conn
    elif ds.get("connection_id"):
        portable["connection_id"] = ds["connection_id"]

    # Enrichment reference → name (API returns "enrich_datastore")
    enrichment = ds.get("enrich_datastore")
    if enrichment and isinstance(enrichment, dict):
        portable["enrich_datastore_name"] = enrichment.get("name", "")

    for key, value in ds.items():
        if key in _DATASTORE_INTERNAL_FIELDS:
            continue
        if key == "enrich_datastore":
            continue
        # Flatten object lists to name strings
        if key == "teams" and isinstance(value, list):
            portable[key] = [t["name"] if isinstance(t, dict) else t for t in value]
            continue
        if key == "global_tags" and isinstance(value, list):
            portable[key] = [t["name"] if isinstance(t, dict) else t for t in value]
            continue
        portable[key] = value

    return portable


def strip_container_for_export(container: dict, ds_name: str) -> dict:
    """Convert an API container response into a portable YAML dict.

    Only computed containers are exported (table/view/file are discovered by sync).
    Replaces ID references with name references.
    """
    portable: dict = {}

    for key, value in container.items():
        if key in _CONTAINER_INTERNAL_FIELDS:
            continue
        # Replace source_container_id → source_container_name
        if key == "source_container" and isinstance(value, dict):
            portable["source_container_name"] = value.get("name", "")
            continue
        if key == "left_container" and isinstance(value, dict):
            portable["left_container_name"] = value.get("name", "")
            continue
        if key == "right_container" and isinstance(value, dict):
            portable["right_container_name"] = value.get("name", "")
            continue
        # Skip raw ID fields (we use names instead)
        if key in (
            "source_container_id",
            "left_container_id",
            "right_container_id",
            "datastore_id",
        ):
            continue
        portable[key] = value

    portable["datastore_name"] = ds_name
    return portable


def strip_computed_field_for_export(cf: dict) -> dict:
    """Convert an API computed field into a portable YAML dict.

    Strips internal IDs and resolves ``ref_container_id`` /
    ``ref_datastore_id`` in properties to name-based references.
    """
    portable: dict = {}
    for key, value in cf.items():
        if key in _COMPUTED_FIELD_INTERNAL_FIELDS:
            continue
        # Normalize transformation key name
        if key == "transformation_type":
            portable["transformation"] = value
            continue
        portable[key] = value

    # Ensure key is "transformation" not "transformation_type"
    if "transformation" not in portable and "transformation_type" in cf:
        portable["transformation"] = cf["transformation_type"]

    return portable


# ── Export orchestrator ──────────────────────────────────────────────────


def export_config(
    client: QualyticsClient,
    datastore_ids: list[int],
    output_dir: str,
    *,
    include: set[str] | None = None,
) -> dict:
    """Export connections, datastores, containers, and checks to a folder tree.

    Args:
        client: Authenticated API client.
        datastore_ids: Datastore IDs to export.
        output_dir: Root output directory.
        include: Resource types to include. ``None`` = all.
            Valid values: ``{"connections", "datastores", "containers",
            "computed_fields", "checks"}``.

    Returns a summary dict with counts per resource type.
    """
    if include is None:
        include = {
            "connections",
            "datastores",
            "containers",
            "computed_fields",
            "checks",
        }

    base = Path(output_dir)
    summary: dict = {
        "connections": 0,
        "datastores": 0,
        "containers": 0,
        "computed_fields": 0,
        "checks": 0,
    }
    seen_connections: set[str] = set()

    for ds_id in datastore_ids:
        # Fetch datastore
        ds = get_datastore(client, ds_id)
        ds_name = ds.get("name", f"datastore_{ds_id}")
        ds_slug = _slugify(ds_name)

        # ── Connection ───────────────────────────────────────────────
        if "connections" in include:
            conn = ds.get("connection")
            if conn and isinstance(conn, dict):
                conn_name = conn.get("name", "")
                if conn_name and conn_name not in seen_connections:
                    seen_connections.add(conn_name)
                    portable_conn = strip_connection_for_export(conn)
                    conn_path = base / "connections" / f"{_slugify(conn_name)}.yaml"
                    _write_yaml(conn_path, portable_conn)
                    summary["connections"] += 1

            # Also export enrichment connection if present
            enrichment_ds = ds.get("enrich_datastore")
            if enrichment_ds and isinstance(enrichment_ds, dict):
                enr_conn = enrichment_ds.get("connection")
                if enr_conn and isinstance(enr_conn, dict):
                    enr_conn_name = enr_conn.get("name", "")
                    if enr_conn_name and enr_conn_name not in seen_connections:
                        seen_connections.add(enr_conn_name)
                        portable_enr = strip_connection_for_export(enr_conn)
                        enr_path = (
                            base / "connections" / f"{_slugify(enr_conn_name)}.yaml"
                        )
                        _write_yaml(enr_path, portable_enr)
                        summary["connections"] += 1

        # ── Datastore ────────────────────────────────────────────────
        if "datastores" in include:
            portable_ds = strip_datastore_for_export(ds)
            ds_path = base / "datastores" / ds_slug / "_datastore.yaml"
            _write_yaml(ds_path, portable_ds)
            summary["datastores"] += 1

        # ── Containers + computed fields ─────────────────────────────
        export_containers = "containers" in include
        export_cfields = "computed_fields" in include
        if export_containers or export_cfields:
            all_containers = list_all_containers(client, datastore=[ds_id])

            for container in all_containers:
                c_name = container.get("name", "")
                c_slug = (
                    _slugify(c_name) if c_name else f"container_{container.get('id')}"
                )
                ct = container.get("container_type", "")

                # Export computed container definition
                if export_containers and ct in _COMPUTED_TYPES:
                    portable_c = strip_container_for_export(container, ds_name)
                    c_path = (
                        base
                        / "datastores"
                        / ds_slug
                        / "containers"
                        / c_slug
                        / "_container.yaml"
                    )
                    _write_yaml(c_path, portable_c)
                    summary["containers"] += 1

                # Export computed fields (any container type)
                if export_cfields:
                    cfs = container.get("computed_fields") or []
                    if not cfs:
                        # List endpoint may not include full detail;
                        # fetch individual container to get computed_fields
                        detail = get_container(client, container["id"])
                        cfs = detail.get("computed_fields") or []
                    for cf in cfs:
                        portable_cf = strip_computed_field_for_export(cf)
                        cf_slug = _slugify(cf.get("name", "unknown"))
                        cf_path = (
                            base
                            / "datastores"
                            / ds_slug
                            / "containers"
                            / c_slug
                            / "computed_fields"
                            / f"{cf_slug}.yaml"
                        )
                        _write_yaml(cf_path, portable_cf)
                        summary["computed_fields"] += 1

        # ── Quality checks ───────────────────────────────────────────
        if "checks" in include:
            all_checks = list_all_quality_checks(client, ds_id)
            if all_checks:
                checks_dir = base / "datastores" / ds_slug / "checks"
                result = export_checks_to_directory(all_checks, str(checks_dir))
                summary["checks"] += result["exported"]

    return summary


# ── Import orchestrator ──────────────────────────────────────────────────


def _resolve_connection_secrets(portable: dict) -> dict:
    """Resolve ``${ENV_VAR}`` placeholders in connection sensitive fields.

    Returns a copy with resolved values.  Raises ``ValueError`` on
    unresolved env vars.
    """
    resolved = dict(portable)
    for field in _CONNECTION_SENSITIVE_FIELDS:
        if field in resolved and isinstance(resolved[field], str):
            resolved[field] = resolve_env_vars(resolved[field])
    return resolved


def _import_connections(
    client: QualyticsClient,
    connections_dir: Path,
    *,
    dry_run: bool = False,
) -> dict:
    """Import connections from ``connections/*.yaml``.

    Returns {created: N, updated: N, failed: N, errors: [...]}.
    """
    result: dict = {"created": 0, "updated": 0, "failed": 0, "errors": []}

    if not connections_dir.is_dir():
        return result

    for yaml_file in sorted(connections_dir.glob("*.yaml")):
        try:
            with open(yaml_file) as f:
                data = yaml.load(f, Loader=_SafeStringLoader)
            if not isinstance(data, dict) or "name" not in data:
                result["errors"].append(f"Skipped {yaml_file.name}: no 'name' field")
                result["failed"] += 1
                continue

            conn_name = data["name"]

            if dry_run:
                existing = get_connection_by_name(client, conn_name)
                if existing:
                    result["updated"] += 1
                else:
                    result["created"] += 1
                continue

            # Resolve env var placeholders in secret fields
            try:
                resolved = _resolve_connection_secrets(data)
            except ValueError as e:
                result["errors"].append(f"{yaml_file.name}: {e}")
                result["failed"] += 1
                continue

            # Upsert: find by name
            existing = get_connection_by_name(client, conn_name)
            if existing:
                update_connection(client, existing["id"], resolved)
                result["updated"] += 1
            else:
                create_connection(client, resolved)
                result["created"] += 1

        except Exception as e:
            result["errors"].append(f"{yaml_file.name}: {e}")
            result["failed"] += 1

    return result


def _import_datastore(
    client: QualyticsClient,
    ds_dir: Path,
    *,
    dry_run: bool = False,
) -> dict:
    """Import a single datastore from ``datastores/<name>/_datastore.yaml``.

    Returns {created: N, updated: N, failed: N, errors: [], datastore_id: int | None}.
    """
    result: dict = {
        "created": 0,
        "updated": 0,
        "failed": 0,
        "errors": [],
        "datastore_id": None,
    }

    ds_file = ds_dir / "_datastore.yaml"
    if not ds_file.exists():
        return result

    try:
        with open(ds_file) as f:
            data = yaml.load(f, Loader=_SafeStringLoader)
        if not isinstance(data, dict) or "name" not in data:
            result["errors"].append(f"Skipped {ds_file}: no 'name' field")
            result["failed"] += 1
            return result

        ds_name = data["name"]

        # Resolve connection_name → connection_id
        conn_name = data.pop("connection_name", None)
        enrichment_ds_name = data.pop("enrich_datastore_name", None)

        if conn_name and "connection_id" not in data:
            conn = get_connection_by_name(client, conn_name)
            if conn:
                data["connection_id"] = conn["id"]
            # Don't fail here — updates can fall back to existing connection

        if dry_run:
            existing = get_datastore_by_name(client, ds_name)
            if existing:
                result["updated"] += 1
                result["datastore_id"] = existing["id"]
            else:
                result["created"] += 1
            return result

        # Strip read-only connection-level fields (from older exports)
        for field in _DATASTORE_READONLY_FIELDS:
            data.pop(field, None)

        # Flatten teams/tags that may be stored as objects in older exports
        for list_key in ("teams", "global_tags"):
            if list_key in data and isinstance(data[list_key], list):
                data[list_key] = [
                    t["name"] if isinstance(t, dict) else t for t in data[list_key]
                ]

        # Upsert: find by name
        existing = get_datastore_by_name(client, ds_name)
        if existing:
            ds_id = existing["id"]
            # Fetch full datastore (list endpoint returns lightweight objects
            # missing the connection object needed for proper merging)
            full_existing = get_datastore(client, ds_id)
            # Don't send trigger_catalog on update
            data.pop("trigger_catalog", None)
            # PUT requires full payload — merge import data on top of current state
            from .datastores import flatten_datastore_for_put

            full_payload = {**flatten_datastore_for_put(full_existing), **data}
            # Strip read-only fields that flatten may have carried over
            for field in _DATASTORE_READONLY_FIELDS:
                full_payload.pop(field, None)
            update_datastore(client, ds_id, full_payload)
            result["updated"] += 1
            result["datastore_id"] = ds_id
        else:
            # Creating requires a connection reference
            if "connection_id" not in data:
                ref = conn_name or "(not specified)"
                result["errors"].append(
                    f"Connection '{ref}' not found for datastore '{ds_name}'"
                )
                result["failed"] += 1
                return result
            resp = create_datastore(client, data)
            ds_id = resp.get("id")
            result["created"] += 1
            result["datastore_id"] = ds_id

        # Link enrichment if specified
        if enrichment_ds_name and ds_id:
            enr_ds = get_datastore_by_name(client, enrichment_ds_name)
            if enr_ds:
                try:
                    connect_enrichment(client, ds_id, enr_ds["id"])
                except Exception as e:
                    result["errors"].append(
                        f"Failed to link enrichment '{enrichment_ds_name}': {e}"
                    )

    except Exception as e:
        result["errors"].append(f"{ds_dir.name}: {e}")
        result["failed"] += 1

    return result


def _import_containers(
    client: QualyticsClient,
    ds_dir: Path,
    datastore_id: int,
    *,
    dry_run: bool = False,
) -> dict:
    """Import computed containers from ``datastores/<name>/containers/``.

    Returns {created: N, updated: N, failed: N, errors: []}.
    """
    result: dict = {"created": 0, "updated": 0, "failed": 0, "errors": []}

    containers_dir = ds_dir / "containers"
    if not containers_dir.is_dir():
        return result

    for container_dir in sorted(containers_dir.iterdir()):
        if not container_dir.is_dir():
            continue
        yaml_file = container_dir / "_container.yaml"
        if not yaml_file.exists():
            continue

        try:
            with open(yaml_file) as f:
                data = yaml.load(f, Loader=_SafeStringLoader)
            if not isinstance(data, dict) or "name" not in data:
                result["errors"].append(f"Skipped {yaml_file}: no 'name' field")
                result["failed"] += 1
                continue

            c_name = data["name"]
            c_type = data.get("container_type", "")

            if c_type not in _COMPUTED_TYPES:
                continue

            # Strip non-API fields
            data.pop("datastore_name", None)

            # Resolve name references to IDs
            _resolve_container_refs(client, data, datastore_id)

            if dry_run:
                existing = get_container_by_name(client, datastore_id, c_name)
                if existing:
                    result["updated"] += 1
                else:
                    result["created"] += 1
                continue

            # Upsert
            existing = get_container_by_name(client, datastore_id, c_name)
            if existing:
                update_container(client, existing["id"], data)
                result["updated"] += 1
            else:
                data["datastore_id"] = datastore_id
                create_container(client, data)
                result["created"] += 1

        except Exception as e:
            result["errors"].append(f"{container_dir.name}: {e}")
            result["failed"] += 1

    return result


def _import_computed_fields(
    client: QualyticsClient,
    ds_dir: Path,
    datastore_id: int,
    *,
    dry_run: bool = False,
) -> dict:
    """Import computed fields from ``containers/<name>/computed_fields/*.yaml``.

    Returns {created: N, updated: N, failed: N, errors: []}.
    """
    result: dict = {"created": 0, "updated": 0, "failed": 0, "errors": []}

    containers_dir = ds_dir / "containers"
    if not containers_dir.is_dir():
        return result

    for container_dir in sorted(containers_dir.iterdir()):
        if not container_dir.is_dir():
            continue
        cf_dir = container_dir / "computed_fields"
        if not cf_dir.is_dir():
            continue

        # Resolve container name from _container.yaml or directory name
        c_name = container_dir.name
        yaml_file = container_dir / "_container.yaml"
        if yaml_file.exists():
            with open(yaml_file) as f:
                c_data = yaml.load(f, Loader=_SafeStringLoader)
            if isinstance(c_data, dict) and "name" in c_data:
                c_name = c_data["name"]

        container = get_container_by_name(client, datastore_id, c_name)
        if container is None:
            result["errors"].append(
                f"Container '{c_name}' not found — skipping computed fields"
            )
            result["failed"] += len(list(cf_dir.glob("*.yaml")))
            continue

        container_id = container["id"]

        # Build existing computed field name → id lookup
        detail = get_container(client, container_id)
        existing_cfs: dict[str, int] = {}
        for ecf in detail.get("computed_fields") or []:
            if ecf.get("name"):
                existing_cfs[ecf["name"]] = ecf["id"]

        for cf_file in sorted(cf_dir.glob("*.yaml")):
            try:
                with open(cf_file) as f:
                    data = yaml.load(f, Loader=_SafeStringLoader)
                if not isinstance(data, dict) or "name" not in data:
                    result["errors"].append(f"Skipped {cf_file.name}: no 'name'")
                    result["failed"] += 1
                    continue

                cf_name = data["name"]

                if dry_run:
                    if cf_name in existing_cfs:
                        result["updated"] += 1
                    else:
                        result["created"] += 1
                    continue

                if cf_name in existing_cfs:
                    # Update — don't send container_id
                    payload = {k: v for k, v in data.items() if k != "container_id"}
                    update_computed_field(client, existing_cfs[cf_name], payload)
                    result["updated"] += 1
                else:
                    # Create — needs container_id
                    data["container_id"] = container_id
                    create_computed_field(client, data)
                    result["created"] += 1

            except Exception as e:
                result["errors"].append(f"{cf_file.name}: {e}")
                result["failed"] += 1

    return result


def _resolve_container_refs(
    client: QualyticsClient, data: dict, datastore_id: int
) -> None:
    """Resolve container name references to IDs in-place.

    Handles ``source_container_name``, ``left_container_name``,
    ``right_container_name``.
    """
    for name_key, id_key in [
        ("source_container_name", "source_container_id"),
        ("left_container_name", "left_container_id"),
        ("right_container_name", "right_container_id"),
    ]:
        ref_name = data.pop(name_key, None)
        if ref_name and id_key not in data:
            ref = get_container_by_name(client, datastore_id, ref_name)
            if ref:
                data[id_key] = ref["id"]
            else:
                raise ValueError(
                    f"Referenced container '{ref_name}' not found in datastore"
                )


def import_config(
    client: QualyticsClient,
    input_dir: str,
    *,
    dry_run: bool = False,
    include: set[str] | None = None,
) -> dict:
    """Import config from a folder tree.

    Import order: connections → datastores → containers → computed fields
    → quality checks.

    Args:
        client: Authenticated API client.
        input_dir: Root input directory.
        dry_run: Preview only, no mutations.
        include: Resource types to include. ``None`` = all.

    Returns a summary dict with counts per resource type.
    """
    if include is None:
        include = {
            "connections",
            "datastores",
            "containers",
            "computed_fields",
            "checks",
        }

    base = Path(input_dir)

    # Auto-detect if the user pointed to a single datastore directory
    # (contains _datastore.yaml) or the datastores/ parent, and adjust
    # the base path so the standard layout discovery works.
    if (base / "_datastore.yaml").exists():
        # User pointed directly to a datastore dir, e.g. ./datastores/my_ds
        base = base.parent.parent
    elif not (base / "datastores").is_dir() and any(
        (d / "_datastore.yaml").exists() for d in base.iterdir() if d.is_dir()
    ):
        # User pointed to the datastores/ folder itself
        base = base.parent

    summary: dict = {
        "connections": {"created": 0, "updated": 0, "failed": 0, "errors": []},
        "datastores": {"created": 0, "updated": 0, "failed": 0, "errors": []},
        "sync": {"created": 0, "updated": 0, "failed": 0, "errors": []},
        "containers": {"created": 0, "updated": 0, "failed": 0, "errors": []},
        "computed_fields": {"created": 0, "updated": 0, "failed": 0, "errors": []},
        "checks": {"created": 0, "updated": 0, "failed": 0, "errors": []},
    }

    # 1. Connections
    if "connections" in include:
        conn_result = _import_connections(client, base / "connections", dry_run=dry_run)
        summary["connections"] = conn_result

    # 2. Datastores + 3. Containers + 4. Checks (per datastore directory)
    datastores_dir = base / "datastores"
    if not datastores_dir.is_dir():
        return summary

    for ds_dir in sorted(datastores_dir.iterdir()):
        if not ds_dir.is_dir():
            continue

        # Import datastore
        ds_id = None
        if "datastores" in include:
            ds_result = _import_datastore(client, ds_dir, dry_run=dry_run)
            summary["datastores"]["created"] += ds_result["created"]
            summary["datastores"]["updated"] += ds_result["updated"]
            summary["datastores"]["failed"] += ds_result["failed"]
            summary["datastores"]["errors"].extend(ds_result["errors"])
            ds_id = ds_result.get("datastore_id")
        else:
            # Still need to resolve the datastore ID for containers/checks
            ds_file = ds_dir / "_datastore.yaml"
            if ds_file.exists():
                with open(ds_file) as f:
                    ds_data = yaml.load(f, Loader=_SafeStringLoader)
                if isinstance(ds_data, dict) and "name" in ds_data:
                    existing = get_datastore_by_name(client, ds_data["name"])
                    if existing:
                        ds_id = existing["id"]

        if ds_id is None and not dry_run:
            summary["datastores"]["errors"].append(
                f"Could not resolve datastore ID for {ds_dir.name}"
            )
            continue

        # Run sync to discover tables/views before importing containers/checks
        if ds_id is not None and not dry_run:
            from rich import print as rprint

            rprint(
                f"[cyan]Syncing datastore {ds_dir.name} (ID: {ds_id})... "
                f"this may take a few minutes.[/cyan]"
            )
            sync_result = _run_sync_for_import(client, ds_id)
            if sync_result["success"]:
                summary["sync"]["created"] += 1
                rprint(f"[green]Sync completed for {ds_dir.name}.[/green]")
            else:
                summary["sync"]["failed"] += 1
                summary["sync"]["errors"].append(
                    f"{ds_dir.name}: {sync_result['error']}"
                )
                rprint(
                    f"[red]Sync failed for {ds_dir.name}: {sync_result['error']}[/red]"
                )

        # Import containers
        if "containers" in include and ds_id is not None:
            c_result = _import_containers(client, ds_dir, ds_id, dry_run=dry_run)
            summary["containers"]["created"] += c_result["created"]
            summary["containers"]["updated"] += c_result["updated"]
            summary["containers"]["failed"] += c_result["failed"]
            summary["containers"]["errors"].extend(c_result["errors"])

        # Import computed fields (after containers exist)
        if "computed_fields" in include and ds_id is not None:
            cf_result = _import_computed_fields(client, ds_dir, ds_id, dry_run=dry_run)
            summary["computed_fields"]["created"] += cf_result["created"]
            summary["computed_fields"]["updated"] += cf_result["updated"]
            summary["computed_fields"]["failed"] += cf_result["failed"]
            summary["computed_fields"]["errors"].extend(cf_result["errors"])

        # Import checks
        if "checks" in include and ds_id is not None:
            checks_dir = ds_dir / "checks"
            if checks_dir.is_dir():
                checks = load_checks_from_directory(str(checks_dir))
                if checks:
                    ck_result = import_checks_to_datastore(
                        client, ds_id, checks, dry_run=dry_run
                    )
                    summary["checks"]["created"] += ck_result["created"]
                    summary["checks"]["updated"] += ck_result["updated"]
                    summary["checks"]["failed"] += ck_result["failed"]
                    summary["checks"]["errors"].extend(ck_result["errors"])

    return summary
