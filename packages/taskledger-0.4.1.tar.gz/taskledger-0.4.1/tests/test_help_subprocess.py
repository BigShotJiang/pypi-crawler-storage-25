"""Subprocess tests for help command speed and non-logging."""

from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = str(Path(__file__).resolve().parent.parent)
_ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-9;]*m")


def _run_help(
    tmp_path: Path,
    *argv: str,
    timeout: int = 5,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "taskledger", *argv],
        cwd=str(tmp_path),
        env={**os.environ, "PYTHONPATH": ROOT, "TASKLEDGER_NO_LOG": "0"},
        text=True,
        capture_output=True,
        timeout=timeout,
    )


def _strip_ansi(text: str) -> str:
    return _ANSI_ESCAPE_RE.sub("", text)


@pytest.mark.parametrize(
    "argv",
    [
        ["--help"],
        ["task", "--help"],
        ["plan", "--help"],
        ["question", "--help"],
        ["implement", "--help"],
        ["validate", "--help"],
        ["todo", "--help"],
        ["doctor", "--help"],
        ["repair", "--help"],
        ["handoff", "--help"],
        ["ledger", "--help"],
        ["actor", "--help"],
        ["harness", "--help"],
    ],
)
def test_help_subprocess_exits_quickly(argv: list[str], tmp_path: Path) -> None:
    result = _run_help(tmp_path, *argv)
    assert result.returncode == 0, f"stderr: {result.stderr}"
    assert "Usage:" in result.stdout


def test_help_is_not_agent_logged(tmp_path: Path) -> None:
    _run_help(tmp_path, "plan", "--help")
    agent_logs = tmp_path / ".taskledger" / "agent-logs"
    assert not agent_logs.exists(), f"agent-logs dir exists: {agent_logs}"


def test_root_help_shows_completion_options(tmp_path: Path) -> None:
    result = _run_help(tmp_path, "--help")
    assert result.returncode == 0, f"stderr: {result.stderr}"
    normalized_help = _strip_ansi(result.stdout)
    if "--show-completion" in normalized_help:
        return
    # Some Typer/Click combinations keep completion flags available but omit
    # them from root help output.
    completion = _run_help(tmp_path, "--show-completion", "bash")
    assert completion.returncode == 0, f"stderr: {completion.stderr}"


def test_show_completion_exits_quickly_and_does_not_create_agent_logs(
    tmp_path: Path,
) -> None:
    result = _run_help(tmp_path, "--show-completion", "bash")
    assert result.returncode == 0, f"stderr: {result.stderr}"
    # Some Typer versions / environments may not support the detected shell,
    # so only assert stdout content when a completion script was produced.
    if "Shell" not in result.stderr:
        assert "taskledger" in result.stdout
    agent_logs = tmp_path / ".taskledger" / "agent-logs"
    assert not agent_logs.exists(), f"agent-logs dir exists: {agent_logs}"
