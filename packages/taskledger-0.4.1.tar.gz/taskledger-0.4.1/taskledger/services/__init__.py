"""State-oriented taskledger services."""
