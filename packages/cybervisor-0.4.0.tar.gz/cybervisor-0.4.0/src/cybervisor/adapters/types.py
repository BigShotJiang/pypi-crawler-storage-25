from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol, Self, runtime_checkable

from cybervisor.logging import CybervisorLogger
from cybervisor.stream_logging import CanonicalLogEvent

if TYPE_CHECKING:
    from cybervisor.logging import CybervisorLogger


class AdapterLifecycleState(str, Enum):
    PREPARED = "prepared"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


AdapterStatus = AdapterLifecycleState


class AdapterOutcome(str, Enum):
    STARTED = "started"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


@dataclass(frozen=True, slots=True)
class AdapterExecutionResult:
    lifecycle: AdapterLifecycleState
    outcome: AdapterOutcome
    exit_code: int | None = None
    output: str = ""
    error: str | None = None


@runtime_checkable
class AgentAdapter(Protocol):
    descriptor: AdapterDescriptor

    def start(self, request: LaunchRequest) -> RunningProcess:
        ...

    def prepare(self) -> AdapterExecutionResult:
        ...

    def running(self) -> AdapterExecutionResult:
        ...

    def complete(self, *, exit_code: int | None = None, output: str = "") -> AdapterExecutionResult | AdapterStatus:
        ...

    def fail(
        self,
        *,
        exit_code: int | None = None,
        output: str = "",
        error: str | None = None,
    ) -> AdapterExecutionResult | AdapterStatus:
        ...

    def complete_result(self, *, exit_code: int, output: str) -> AdapterExecutionResult:
        ...

    def fail_result(
        self,
        *,
        exit_code: int | None,
        output: str = "",
        error: str | None = None,
    ) -> AdapterExecutionResult:
        ...

    def supports_runtime_contract(self) -> bool:
        ...

    def upgrade_runtime_contract(self) -> Self:
        ...

    def run_result(self, exit_code: int, output: str, error: str | None = None) -> AdapterExecutionResult:
        ...

    def lifecycle_from_exit_code(self, exit_code: int) -> AdapterLifecycleState:
        ...

    def outcome_from_exit_code(self, exit_code: int) -> AdapterOutcome:
        ...

    def log_execution_result(
        self,
        logger: CybervisorLogger,
        stage_name: str,
        result: AdapterExecutionResult,
    ) -> None:
        ...

    def parse_output_line(self, line: str) -> list[CanonicalLogEvent]:
        ...

    def flush_pending_events(self) -> list[CanonicalLogEvent]:
        ...

    def should_suppress_event(self, event: CanonicalLogEvent, saw_hook_feedback: bool) -> bool:
        ...

    def preflight_requirements(self) -> PreflightRequirements:
        ...

    def settings_path(self) -> Path | None:
        ...

    def install_hook_settings(self, payload: dict[str, Any], runtime_config_path: Path) -> dict[str, Any]:
        ...

    def remove_hook_settings(self, payload: dict[str, Any], runtime_config_path: Path) -> dict[str, Any]:
        ...

    def lifecycle_status(self) -> AdapterStatus:
        ...

    def running_status(self) -> AdapterStatus:
        ...

    def completed_status(self) -> AdapterStatus:
        ...

    def failed_status(self) -> AdapterStatus:
        ...

    def start_outcome(self) -> AdapterOutcome:
        ...

    def success_outcome(self) -> AdapterOutcome:
        ...

    def failure_outcome(self) -> AdapterOutcome:
        ...

    def status(self) -> AdapterStatus:
        ...

    def run(self) -> AdapterStatus:
        ...

    def complete_status(self) -> AdapterStatus:
        ...

    def fail_status(self) -> AdapterStatus:
        ...


class RunningProcess(Protocol):
    pid: int | None
    process_group_id: int | None

    def wait(self) -> tuple[int, str]:
        ...


@dataclass(frozen=True, slots=True)
class AdapterCapabilities:
    supports_hooks: bool = False
    supports_structured_streams: bool = False


@dataclass(frozen=True, slots=True)
class AdapterDescriptor:
    name: str
    display_name: str
    directory: Path
    capabilities: AdapterCapabilities = field(default_factory=AdapterCapabilities)


@dataclass(frozen=True, slots=True)
class LaunchRequest:
    prompt: str
    stage_name: str
    log_file: str
    logger: CybervisorLogger


@dataclass(frozen=True, slots=True)
class PreflightRequirements:
    required_binaries: tuple[str, ...] = ()
    requires_verifier_config: bool = False
