from __future__ import annotations

import time
from pathlib import Path

from cybervisor.adapters.base import BaseAdapter, CompletedProcessHandle
from cybervisor.adapters.types import AdapterDescriptor, LaunchRequest, PreflightRequirements, RunningProcess
from cybervisor.stream_logging import CanonicalLogEvent


class MockAdapter(BaseAdapter):
    descriptor = AdapterDescriptor(
        name="mock",
        display_name="Mock Agent",
        directory=Path(__file__).resolve().parent,
    )

    def parse_output_line(self, line: str) -> list[CanonicalLogEvent]:
        if not line:
            return []
        return [CanonicalLogEvent(kind="plain_text", text=line)]

    def flush_pending_events(self) -> list[CanonicalLogEvent]:
        return []

    def should_suppress_event(self, event: CanonicalLogEvent, saw_hook_feedback: bool) -> bool:
        del event, saw_hook_feedback
        return False

    def preflight_requirements(self) -> PreflightRequirements:
        return PreflightRequirements()

    def start(self, request: LaunchRequest) -> RunningProcess:
        time.sleep(0.15)
        output = "Stage completed successfully"
        mock_payload = Path(".cybervisor/mock_artifact_payload.yaml")
        if mock_payload.exists():
            from cybervisor.config import contract_artifact_path

            artifact_path = Path(contract_artifact_path(request.stage_name))
            artifact_path.parent.mkdir(parents=True, exist_ok=True)
            artifact_path.write_text(mock_payload.read_text(encoding="utf-8"), encoding="utf-8")
        Path(request.log_file).parent.mkdir(parents=True, exist_ok=True)
        Path(request.log_file).write_text(output + "\n", encoding="utf-8")
        request.logger.log_to_stderr(f"[{request.stage_name}][mock] {output}")
        return CompletedProcessHandle(output=output, exit_code=0, delay_seconds=0.15)

