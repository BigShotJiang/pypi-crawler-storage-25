import sys
import argparse
import json
from pathlib import Path
from cybervisor.core_hooks.runner import run_hook

def main() -> None:
    """Entry point for cybervisor-agent-hook CLI."""
    parser = argparse.ArgumentParser(description="Standalone Agent Hook for Cybervisor")
    parser.add_argument("--config", required=True, help="Path to hook runtime configuration")
    
    args, unknown = parser.parse_known_args()
    
    config_path = Path(args.config)
    
    # Read stdin
    input_data = sys.stdin.read()
    
    try:
        output = run_hook(config_path, input_data)
        sys.stdout.write(json.dumps(output) + "\n")
    except Exception as exc:
        # Fallback if run_hook fails (though run_hook should handle most errors)
        error_fallback = {"decision": "block", "reason": f"cli_entrypoint_error:{exc}"}
        sys.stdout.write(json.dumps(error_fallback) + "\n")
        sys.exit(0) # Agents expect 0 for clean hook execution even if blocking

if __name__ == "__main__":
    main()
