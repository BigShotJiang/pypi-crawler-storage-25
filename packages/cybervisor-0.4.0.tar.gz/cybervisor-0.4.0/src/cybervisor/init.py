from __future__ import annotations

from dataclasses import dataclass
from importlib.resources import files
from importlib.resources.abc import Traversable
from pathlib import Path

from cybervisor.global_config import global_config_path
from cybervisor.logging import CybervisorLogger


@dataclass(frozen=True, slots=True)
class InitFile:
    path: Path
    contents: str


def _iter_scaffold_files(directory: Traversable, prefix: Path) -> list[InitFile]:
    init_files: list[InitFile] = []
    for child in directory.iterdir():
        child_prefix = prefix / child.name
        if child.is_dir():
            init_files.extend(_iter_scaffold_files(child, child_prefix))
            continue
        init_files.append(InitFile(path=child_prefix, contents=child.read_text(encoding="utf-8")))
    return init_files


def scaffold_init_files(base_dir: Path, scaffold_name: str) -> list[InitFile]:
    scaffold_dir = files("cybervisor.assets.init").joinpath(scaffold_name)
    return sorted(_iter_scaffold_files(scaffold_dir, base_dir), key=lambda item: str(item.path))


def _select_init_files(base_dir: Path) -> tuple[str, list[InitFile]]:
    if (base_dir / ".specify").is_dir():
        return "speckit", scaffold_init_files(base_dir, "speckit")
    return "simple", scaffold_init_files(base_dir, "simple")


def run_init(
    *,
    base_dir: Path | None = None,
    logger: CybervisorLogger | None = None,
) -> int:
    target_dir = base_dir or Path.cwd()
    resolved_dir = target_dir.resolve()
    init_logger = logger or CybervisorLogger()
    scaffold_kind, targets = _select_init_files(resolved_dir)
    conflicts = [item.path for item in targets if item.path.exists()]

    if conflicts:
        joined = "\n".join(str(path) for path in conflicts)
        init_logger.log_to_stderr(
            "Refusing to overwrite existing init files:\n" + joined,
            "error",
        )
        return 1

    for item in targets:
        item.path.parent.mkdir(parents=True, exist_ok=True)
        item.path.write_text(item.contents, encoding="utf-8")

    created = "\n".join(str(item.path.relative_to(resolved_dir)) for item in targets)
    init_logger.log_to_stderr(
        (
            f"Created {scaffold_kind} cybervisor scaffold:\n"
            f"{created}\n\n"
            f"Next steps:\n"
            f"- Set a global default agent with `cybervisor use <agent_tool>`\n"
            f"- Configure verifier settings in {global_config_path()}"
        ),
        "info",
    )
    return 0
