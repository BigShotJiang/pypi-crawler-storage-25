"""Registry watch application services."""
