"""CLI-related tests package."""
