"""Convert PDF to structured text using MinerU"""

__version__ = "1.6.3"
