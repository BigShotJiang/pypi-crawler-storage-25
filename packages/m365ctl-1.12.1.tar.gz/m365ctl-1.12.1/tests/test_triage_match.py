from __future__ import annotations

from datetime import datetime, timedelta, timezone

from m365ctl.mail.triage.dsl import (
    AgeP, BodyP, CategoriesP, CcP, FlaggedP, FocusP, FolderP, FromP,
    HasAttachmentsP, HeadersP, ImportanceP, Match, SubjectP, ThreadP, ToP,
    UnreadP,
)
from m365ctl.mail.triage.match import MatchContext, evaluate_match


_NOW = datetime(2026, 4, 25, tzinfo=timezone.utc)


def _row(**overrides):
    base = {
        "message_id": "m1",
        "subject": "Hello world",
        "from_address": "alice@example.com",
        "from_name": "Alice",
        "to_addresses": "me@example.com",
        "parent_folder_path": "Inbox",
        "received_at": _NOW - timedelta(days=2),
        "is_read": False,
        "flag_status": "notFlagged",
        "has_attachments": False,
        "importance": "normal",
        "categories": "",
        "inference_class": "focused",
    }
    base.update(overrides)
    return base


def test_match_empty_returns_true():
    assert evaluate_match(Match(), _row(), now=_NOW) is True


def test_from_address_in():
    m = Match(all_of=[FromP(address_in=["alice@example.com"])])
    assert evaluate_match(m, _row(), now=_NOW) is True
    assert evaluate_match(m, _row(from_address="bob@example.com"), now=_NOW) is False


def test_from_domain_in():
    m = Match(all_of=[FromP(domain_in=["example.com"])])
    assert evaluate_match(m, _row(), now=_NOW) is True
    assert evaluate_match(m, _row(from_address="x@other.com"), now=_NOW) is False


def test_subject_contains_case_insensitive():
    m = Match(all_of=[SubjectP(contains="HELLO")])
    assert evaluate_match(m, _row(), now=_NOW) is True


def test_subject_starts_with():
    m = Match(all_of=[SubjectP(starts_with="Hello")])
    assert evaluate_match(m, _row(), now=_NOW) is True
    assert evaluate_match(m, _row(subject="World hello"), now=_NOW) is False


def test_subject_regex():
    m = Match(all_of=[SubjectP(regex=r"^[A-Z][a-z]+\s")])
    assert evaluate_match(m, _row(), now=_NOW) is True


def test_folder_equals():
    m = Match(all_of=[FolderP(equals="Inbox")])
    assert evaluate_match(m, _row(), now=_NOW) is True
    assert evaluate_match(m, _row(parent_folder_path="Sent Items"), now=_NOW) is False


def test_folder_in():
    m = Match(all_of=[FolderP(in_=["Inbox", "Drafts"])])
    assert evaluate_match(m, _row(), now=_NOW) is True
    assert evaluate_match(m, _row(parent_folder_path="Sent Items"), now=_NOW) is False


def test_age_older_than_days():
    m = Match(all_of=[AgeP(older_than_days=1)])
    assert evaluate_match(m, _row(), now=_NOW) is True   # 2 days old
    assert evaluate_match(
        m, _row(received_at=_NOW - timedelta(hours=5)), now=_NOW
    ) is False


def test_age_newer_than_days():
    m = Match(all_of=[AgeP(newer_than_days=1)])
    assert evaluate_match(
        m, _row(received_at=_NOW - timedelta(hours=5)), now=_NOW
    ) is True
    assert evaluate_match(m, _row(), now=_NOW) is False


def test_unread_true():
    m = Match(all_of=[UnreadP(value=True)])
    assert evaluate_match(m, _row(is_read=False), now=_NOW) is True
    assert evaluate_match(m, _row(is_read=True), now=_NOW) is False


def test_is_flagged():
    m = Match(all_of=[FlaggedP(value=True)])
    assert evaluate_match(m, _row(flag_status="flagged"), now=_NOW) is True
    assert evaluate_match(m, _row(flag_status="notFlagged"), now=_NOW) is False


def test_has_attachments():
    m = Match(all_of=[HasAttachmentsP(value=True)])
    assert evaluate_match(m, _row(has_attachments=True), now=_NOW) is True
    assert evaluate_match(m, _row(has_attachments=False), now=_NOW) is False


def test_importance():
    m = Match(all_of=[ImportanceP(equals="high")])
    assert evaluate_match(m, _row(importance="high"), now=_NOW) is True
    assert evaluate_match(m, _row(importance="normal"), now=_NOW) is False


def test_focus():
    m = Match(all_of=[FocusP(equals="focused")])
    assert evaluate_match(m, _row(inference_class="focused"), now=_NOW) is True
    assert evaluate_match(m, _row(inference_class="other"), now=_NOW) is False


def test_categories_contains():
    m = Match(all_of=[CategoriesP(contains="Work")])
    assert evaluate_match(m, _row(categories="Work,Urgent"), now=_NOW) is True
    assert evaluate_match(m, _row(categories="Other"), now=_NOW) is False


def test_categories_in():
    m = Match(all_of=[CategoriesP(in_=["A", "B"])])
    assert evaluate_match(m, _row(categories="C,A"), now=_NOW) is True
    assert evaluate_match(m, _row(categories="X"), now=_NOW) is False


def test_to_address_in_to_addresses():
    m = Match(all_of=[ToP(address="bob@example.com")])
    assert evaluate_match(
        m, _row(to_addresses="alice@example.com,bob@example.com"), now=_NOW
    ) is True
    assert evaluate_match(
        m, _row(to_addresses="alice@example.com"), now=_NOW
    ) is False


def test_to_domain_in_matches_any_address():
    m = Match(all_of=[ToP(domain_in=["example.com"])])
    assert evaluate_match(
        m, _row(to_addresses="bob@other.com,carol@example.com"), now=_NOW
    ) is True
    assert evaluate_match(
        m, _row(to_addresses="bob@other.com"), now=_NOW
    ) is False


def test_body_contains_case_insensitive():
    m = Match(all_of=[BodyP(contains="INVOICE")])
    assert evaluate_match(
        m, _row(body_preview="Please find the invoice attached"), now=_NOW
    ) is True


def test_body_does_not_match_when_preview_empty_or_null():
    m = Match(all_of=[BodyP(contains="anything")])
    assert evaluate_match(m, _row(body_preview=""), now=_NOW) is False
    assert evaluate_match(m, _row(body_preview=None), now=_NOW) is False


def test_body_regex_starts_ends_with():
    assert evaluate_match(
        Match(all_of=[BodyP(regex=r"^[A-Z]")]),
        _row(body_preview="Hello body"),
        now=_NOW,
    ) is True
    assert evaluate_match(
        Match(all_of=[BodyP(starts_with="Hello")]),
        _row(body_preview="Hello body"),
        now=_NOW,
    ) is True
    assert evaluate_match(
        Match(all_of=[BodyP(ends_with="body")]),
        _row(body_preview="Hello body"),
        now=_NOW,
    ) is True


def test_cc_address_in_matches():
    m = Match(all_of=[CcP(address_in=["dan@example.com"])])
    assert evaluate_match(
        m, _row(cc_addresses="dan@example.com,eve@example.com"), now=_NOW
    ) is True
    assert evaluate_match(
        m, _row(cc_addresses="zoe@example.com"), now=_NOW
    ) is False


def test_cc_domain_in_matches():
    m = Match(all_of=[CcP(domain_in=["example.com"])])
    assert evaluate_match(
        m, _row(cc_addresses="dan@other.com,eve@example.com"), now=_NOW
    ) is True


def test_cc_against_null_cc_addresses_returns_false():
    m = Match(all_of=[CcP(address="anybody@anywhere.com")])
    # Pre-migration row: cc_addresses key absent / NULL.
    assert evaluate_match(m, _row(cc_addresses=None), now=_NOW) is False
    row_no_cc = _row()
    row_no_cc.pop("cc_addresses", None)
    assert evaluate_match(m, row_no_cc, now=_NOW) is False


def test_all_of_requires_all():
    m = Match(all_of=[
        FromP(domain_in=["example.com"]),
        UnreadP(value=True),
    ])
    assert evaluate_match(m, _row(), now=_NOW) is True
    assert evaluate_match(m, _row(is_read=True), now=_NOW) is False


def test_any_of_requires_one():
    m = Match(any_of=[
        FromP(address="never@nope.com"),
        SubjectP(contains="Hello"),
    ])
    assert evaluate_match(m, _row(), now=_NOW) is True


def test_none_of_must_not_match():
    m = Match(
        all_of=[FolderP(equals="Inbox")],
        none_of=[FromP(domain_in=["spam.com"])],
    )
    assert evaluate_match(m, _row(), now=_NOW) is True
    assert evaluate_match(
        m, _row(from_address="bot@spam.com"), now=_NOW
    ) is False


def test_thread_has_reply_false_when_not_in_set():
    m = Match(all_of=[ThreadP(has_reply=False)])
    ctx = MatchContext(replied_conversations=frozenset())
    row = _row(conversation_id="conv-1")
    assert evaluate_match(m, row, now=_NOW, context=ctx) is True


def test_thread_has_reply_false_returns_false_when_in_set():
    m = Match(all_of=[ThreadP(has_reply=False)])
    ctx = MatchContext(replied_conversations=frozenset({"conv-1"}))
    row = _row(conversation_id="conv-1")
    assert evaluate_match(m, row, now=_NOW, context=ctx) is False


def test_thread_has_reply_true_when_in_set():
    m = Match(all_of=[ThreadP(has_reply=True)])
    ctx = MatchContext(replied_conversations=frozenset({"conv-1"}))
    row = _row(conversation_id="conv-1")
    assert evaluate_match(m, row, now=_NOW, context=ctx) is True


def test_thread_empty_conversation_id_returns_false():
    m = Match(all_of=[ThreadP(has_reply=False)])
    ctx = MatchContext(replied_conversations=frozenset())
    row = _row(conversation_id="")
    assert evaluate_match(m, row, now=_NOW, context=ctx) is False
    row_missing = _row()
    row_missing.pop("conversation_id", None)
    assert evaluate_match(m, row_missing, now=_NOW, context=ctx) is False


def test_thread_default_context_evaluates_false():
    """No context passed -> default empty MatchContext; thread predicates don't crash."""
    m = Match(all_of=[ThreadP(has_reply=True)])
    row = _row(conversation_id="conv-1")
    # Without context kwarg, replied_conversations is empty, so has_reply=True is False.
    assert evaluate_match(m, row, now=_NOW) is False


def test_thread_combined_with_from_predicate():
    m = Match(all_of=[
        FromP(domain_in=["example.com"]),
        ThreadP(has_reply=False),
    ])
    ctx = MatchContext(replied_conversations=frozenset())
    row = _row(conversation_id="conv-99")
    assert evaluate_match(m, row, now=_NOW, context=ctx) is True
    # Same row but conv has reply -> fails on thread predicate.
    ctx2 = MatchContext(replied_conversations=frozenset({"conv-99"}))
    assert evaluate_match(m, row, now=_NOW, context=ctx2) is False
    # Same row, no reply, but wrong domain -> fails on from predicate.
    row_other = _row(conversation_id="conv-99", from_address="x@other.com")
    assert evaluate_match(m, row_other, now=_NOW, context=ctx) is False


def test_headers_match_contains_case_insensitive_name():
    fetched: list[str] = []

    def fetcher(msg_id: str) -> list[dict[str, str]]:
        fetched.append(msg_id)
        return [
            {"name": "List-Unsubscribe", "value": "<https://example.com/unsub>"},
            {"name": "Received", "value": "from foo by bar"},
        ]

    ctx = MatchContext(header_fetcher=fetcher)
    m = Match(all_of=[HeadersP(name="list-unsubscribe", contains="example.com")])
    row = _row(message_id="msg-1")
    assert evaluate_match(m, row, now=_NOW, context=ctx) is True


def test_headers_match_returns_false_when_header_missing():
    def fetcher(msg_id: str) -> list[dict[str, str]]:
        return [{"name": "Received", "value": "from foo by bar"}]

    ctx = MatchContext(header_fetcher=fetcher)
    m = Match(all_of=[HeadersP(name="X-Missing", contains="anything")])
    assert evaluate_match(m, _row(message_id="msg-2"), now=_NOW, context=ctx) is False


def test_headers_match_returns_false_when_no_fetcher():
    ctx = MatchContext()  # header_fetcher=None
    m = Match(all_of=[HeadersP(name="Foo")])
    assert evaluate_match(m, _row(message_id="msg-3"), now=_NOW, context=ctx) is False


def test_headers_caches_per_message():
    calls: list[str] = []

    def fetcher(msg_id: str) -> list[dict[str, str]]:
        calls.append(msg_id)
        return [{"name": "Foo", "value": "bar"}]

    ctx = MatchContext(header_fetcher=fetcher)
    m = Match(all_of=[HeadersP(name="Foo")])
    row = _row(message_id="msg-cache")
    assert evaluate_match(m, row, now=_NOW, context=ctx) is True
    assert evaluate_match(m, row, now=_NOW, context=ctx) is True
    assert calls == ["msg-cache"]


def test_headers_multiple_predicates_share_cache():
    calls: list[str] = []

    def fetcher(msg_id: str) -> list[dict[str, str]]:
        calls.append(msg_id)
        return [
            {"name": "List-Unsubscribe", "value": "<https://example.com/u>"},
            {"name": "X-Spam-Status", "value": "Yes"},
        ]

    ctx = MatchContext(header_fetcher=fetcher)
    m = Match(all_of=[
        HeadersP(name="List-Unsubscribe", contains="example.com"),
        HeadersP(name="X-Spam-Status", equals="Yes"),
    ])
    row = _row(message_id="msg-multi")
    assert evaluate_match(m, row, now=_NOW, context=ctx) is True
    assert calls == ["msg-multi"]


def test_headers_existence_only_matches_when_header_present():
    def fetcher(msg_id: str) -> list[dict[str, str]]:
        return [{"name": "List-Unsubscribe", "value": ""}]

    ctx = MatchContext(header_fetcher=fetcher)
    m = Match(all_of=[HeadersP(name="List-Unsubscribe")])
    assert evaluate_match(m, _row(message_id="msg-x"), now=_NOW, context=ctx) is True
    # Absent -> False.
    def fetcher_empty(msg_id: str) -> list[dict[str, str]]:
        return []
    ctx2 = MatchContext(header_fetcher=fetcher_empty)
    assert evaluate_match(m, _row(message_id="msg-y"), now=_NOW, context=ctx2) is False


def test_combined_all_any_none():
    m = Match(
        all_of=[FolderP(equals="Inbox")],
        any_of=[
            UnreadP(value=True),
            FlaggedP(value=True),
        ],
        none_of=[FromP(domain_in=["spam.com"])],
    )
    assert evaluate_match(m, _row(), now=_NOW) is True
    # in Inbox but read AND not flagged AND clean sender → any_of fails
    assert evaluate_match(
        m, _row(is_read=True, flag_status="notFlagged"), now=_NOW
    ) is False
