"""Mail local catalog (DuckDB)."""
