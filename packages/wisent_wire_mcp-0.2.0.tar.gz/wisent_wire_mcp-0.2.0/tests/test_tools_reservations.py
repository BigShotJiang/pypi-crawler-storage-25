"""Tests for reservation tools."""

from __future__ import annotations

from types import SimpleNamespace

from tests.helpers import ToolCapture
from wisentwire_mcp.tools_reservations import register


def _register(client, capture: ToolCapture) -> dict:
    register(capture, client)
    return capture.tools


def _make_reservation(
    *, id: int = 1, ww_id: int = 1, name: str = "dev-board",
    start: str = "2026-04-10T08:00", end: str = "2026-04-10T12:00",
    description: str | None = None,
) -> SimpleNamespace:
    return SimpleNamespace(
        id=id, wisent_wire_id=ww_id, wisent_wire_name=name,
        start_at=start, end_at=end, description=description,
    )


def test_list_reservations(mock_client, capture):
    mock_client.list_reservations.return_value = [
        _make_reservation(id=1, name="alpha"),
        _make_reservation(id=2, name="beta", description="flash test"),
    ]
    tools = _register(mock_client, capture)
    result = tools["list_reservations"](week_start="2026-04-06")

    assert "alpha" in result
    assert "beta" in result
    assert "flash test" in result


def test_list_reservations_empty(mock_client, capture):
    mock_client.list_reservations.return_value = []
    tools = _register(mock_client, capture)
    assert tools["list_reservations"](week_start="2026-04-06") == "No reservations for this week."


def test_get_reservation(mock_client, capture):
    mock_client.get_reservation.return_value = _make_reservation(description="nightly")
    tools = _register(mock_client, capture)

    result = tools["get_reservation"](reservation_id=1)
    assert "dev-board" in result
    assert "nightly" in result


def test_create_reservation(mock_client, capture):
    mock_client.create_reservation.return_value = _make_reservation(id=5)
    tools = _register(mock_client, capture)

    result = tools["create_reservation"](
        ww_id=1, start_at="2026-04-10T08:00", end_at="2026-04-10T12:00",
    )
    assert "id=5" in result
    mock_client.create_reservation.assert_called_once_with(
        1, "2026-04-10T08:00", "2026-04-10T12:00", None,
    )


def test_delete_reservation(mock_client, capture):
    tools = _register(mock_client, capture)
    result = tools["delete_reservation"](reservation_id=7)
    assert "7" in result
    mock_client.delete_reservation.assert_called_once_with(7)
