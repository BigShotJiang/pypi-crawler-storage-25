"""Tests for firmware flashing tools."""

from __future__ import annotations

from types import SimpleNamespace

from tests.helpers import ToolCapture
from wisentwire_mcp.tools_flash import register


def _register(client, capture: ToolCapture) -> dict:
    register(capture, client)
    return capture.tools


def test_flash_firmware(mock_client, capture):
    mock_client.flash.return_value = "job-42"
    mock_client.wait_flash_complete.return_value = SimpleNamespace(
        job_id="job-42", status="COMPLETED",
    )
    tools = _register(mock_client, capture)

    result = tools["flash_firmware"](ww_id=1, firmware_id=10)
    assert "job-42" in result
    assert "COMPLETED" in result
    mock_client.flash.assert_called_once_with(1, 10)


def test_get_flash_status(mock_client, capture):
    mock_client.get_flash_status.return_value = SimpleNamespace(
        job_id="job-99", status="IN_PROGRESS",
    )
    tools = _register(mock_client, capture)
    result = tools["get_flash_status"](ww_id=1, job_id="job-99")
    assert "job-99" in result
    assert "IN_PROGRESS" in result


def test_get_flasher_logs(mock_client, capture):
    mock_client.get_flasher_logs.return_value = [
        SimpleNamespace(timestamp=1, source="openocd", data="Programming..."),
        SimpleNamespace(timestamp=2, source="openocd", data="Done."),
    ]
    tools = _register(mock_client, capture)
    result = tools["get_flasher_logs"](ww_id=1)
    assert "Programming..." in result
    assert "[openocd]" in result


def test_get_flasher_logs_empty(mock_client, capture):
    mock_client.get_flasher_logs.return_value = []
    tools = _register(mock_client, capture)
    assert tools["get_flasher_logs"](ww_id=1) == "No flasher logs."


def test_delete_firmware(mock_client, capture):
    tools = _register(mock_client, capture)
    result = tools["delete_firmware"](firmware_id=10)
    assert "10" in result
    mock_client.delete_firmware.assert_called_once_with(10)


def test_upload_firmware(mock_client, capture, tmp_path):
    fw_file = tmp_path / "test.bin"
    fw_file.write_bytes(b"\x00\x01\x02")
    mock_client.upload_firmware.return_value = SimpleNamespace(
        id=7, filename="test.bin", status=SimpleNamespace(value="READY"),
    )
    tools = _register(mock_client, capture)
    result = tools["upload_firmware"](file_path=str(fw_file), target="stm32")
    assert "test.bin" in result
    assert "id=7" in result
    mock_client.upload_firmware.assert_called_once_with("test.bin", b"\x00\x01\x02", "stm32")


def test_list_firmware(mock_client, capture):
    mock_client.list_firmware.return_value = [
        SimpleNamespace(id=1, filename="fw-v1.bin", target="stm32", status="READY"),
        SimpleNamespace(id=2, filename="fw-v2.bin", target="nrf52", status="PENDING"),
    ]
    tools = _register(mock_client, capture)

    result = tools["list_firmware"]()
    assert "fw-v1.bin" in result
    assert "target=stm32" in result
    assert "fw-v2.bin" in result


def test_list_firmware_empty(mock_client, capture):
    mock_client.list_firmware.return_value = []
    tools = _register(mock_client, capture)

    assert tools["list_firmware"]() == "No firmware binaries found."
