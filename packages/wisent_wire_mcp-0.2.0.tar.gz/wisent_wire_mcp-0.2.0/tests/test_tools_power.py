"""Tests for power supply and telemetry tools."""

from __future__ import annotations

from types import SimpleNamespace

from tests.helpers import ToolCapture, make_shadow
from wisentwire_mcp.tools_power import register


def _register(client, capture: ToolCapture) -> dict:
    register(capture, client)
    return capture.tools


def test_power_on(mock_client, capture):
    mock_client.wait_shadow_state.return_value = make_shadow(voltage=3.3, current=0.5)
    tools = _register(mock_client, capture)

    result = tools["power_on"](ww_id=1, voltage=3.3, current_limit=0.5)
    assert "Power ON" in result
    assert "3.3V" in result
    mock_client.set_power_supply.assert_called_once_with(1, state="ON", voltage=3.3, current=0.5)


def test_power_off(mock_client, capture):
    mock_client.wait_shadow_state.return_value = make_shadow(state="OFF")
    tools = _register(mock_client, capture)

    result = tools["power_off"](ww_id=1)
    assert result == "Power OFF."
    mock_client.set_power_supply.assert_called_once_with(1, state="OFF")


def test_get_telemetry(mock_client, capture):
    mock_client.get_power_telemetry.return_value = [
        SimpleNamespace(timestamp=1, voltage=3.28, current=0.12),
        SimpleNamespace(timestamp=2, voltage=3.30, current=0.11),
    ]
    tools = _register(mock_client, capture)

    result = tools["get_telemetry"](ww_id=1)
    assert "3.3" in result
    assert "0.11" in result
    assert "Total readings: 2" in result


def test_get_telemetry_empty(mock_client, capture):
    mock_client.get_power_telemetry.return_value = []
    tools = _register(mock_client, capture)

    assert tools["get_telemetry"](ww_id=1) == "No telemetry data available."
