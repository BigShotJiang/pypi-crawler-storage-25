"""MCP server for the Wisent Wire hardware testing platform."""
