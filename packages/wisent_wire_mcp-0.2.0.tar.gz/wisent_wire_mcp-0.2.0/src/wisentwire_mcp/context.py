"""Client lifecycle — builds WisentWireClient from environment variables."""

from __future__ import annotations

import os

from wisentwire import WisentWireClient


def build_client() -> WisentWireClient:
    """Create a WisentWireClient from WISENT_WIRE_* env vars."""
    base_url = os.environ.get("WISENT_WIRE_URL", "https://int.wisent-wire.com")
    token = os.environ.get("WISENT_WIRE_TOKEN")
    if token:
        return WisentWireClient(base_url=base_url, token=token)

    email = os.environ.get("WISENT_WIRE_EMAIL")
    password = os.environ.get("WISENT_WIRE_PASSWORD")
    local = os.environ.get("WISENT_WIRE_LOCAL", "").lower() in ("1", "true")

    if local and email:
        return WisentWireClient(base_url=base_url, email=email, local=True)
    if email and password:
        return WisentWireClient(base_url=base_url, email=email, password=password)

    raise RuntimeError(
        "Set WISENT_WIRE_EMAIL + WISENT_WIRE_PASSWORD, "
        "WISENT_WIRE_EMAIL + WISENT_WIRE_LOCAL=1, "
        "or WISENT_WIRE_TOKEN."
    )
