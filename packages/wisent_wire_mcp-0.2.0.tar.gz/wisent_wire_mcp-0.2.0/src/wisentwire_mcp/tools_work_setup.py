"""MCP tools — work setup configuration."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mcp.server.fastmcp import FastMCP

if TYPE_CHECKING:
    from wisentwire import WisentWireClient


def register(mcp: FastMCP, client: WisentWireClient) -> None:
    """Register work setup tools on the MCP server."""

    @mcp.tool()
    def get_work_setup(ww_id: int) -> str:
        """Get the work setup for a WisentWire device."""
        ws = client.get_work_setup(ww_id)
        return _format_work_setup(ws)

    @mcp.tool()
    def create_work_setup(
        ww_id: int, name: str, target_mcu: str,
        description: str = "", power_supply_address: str = "",
        frame_definition_id: int = 0,
    ) -> str:
        """Create a work setup for a WisentWire device.
        target_mcu is the MCU identifier (e.g. 'STM32F407')."""
        kwargs = _build_kwargs(description, power_supply_address, frame_definition_id)
        ws = client.create_work_setup(ww_id, name, target_mcu, **kwargs)
        return f"Work setup created (id={ws.id}).\n{_format_work_setup(ws)}"

    @mcp.tool()
    def update_work_setup(
        ww_id: int, name: str, target_mcu: str,
        description: str = "", power_supply_address: str = "",
        frame_definition_id: int = 0,
    ) -> str:
        """Update the work setup for a WisentWire device."""
        kwargs = _build_kwargs(description, power_supply_address, frame_definition_id)
        ws = client.update_work_setup(ww_id, name, target_mcu, **kwargs)
        return f"Work setup updated.\n{_format_work_setup(ws)}"

    @mcp.tool()
    def delete_work_setup(ww_id: int) -> str:
        """Delete the work setup for a WisentWire device."""
        client.delete_work_setup(ww_id)
        return f"Work setup for WW {ww_id} deleted."


def _build_kwargs(
    description: str, power_supply_address: str, frame_definition_id: int,
) -> dict:
    kwargs: dict = {}
    if description:
        kwargs["description"] = description
    if power_supply_address:
        kwargs["power_supply_address"] = power_supply_address
    if frame_definition_id:
        kwargs["frame_definition_id"] = frame_definition_id
    return kwargs


def _format_work_setup(ws: object) -> str:
    lines = [
        f"Name: {ws.name}",  # type: ignore[attr-defined]
        f"Target MCU: {ws.target_mcu}",  # type: ignore[attr-defined]
    ]
    if ws.description:  # type: ignore[attr-defined]
        lines.append(f"Description: {ws.description}")  # type: ignore[attr-defined]
    if ws.power_supply_address:  # type: ignore[attr-defined]
        lines.append(f"Power supply: {ws.power_supply_address}")  # type: ignore[attr-defined]
    if ws.frame_definition_id:  # type: ignore[attr-defined]
        lines.append(f"Frame definition: {ws.frame_definition_id}")  # type: ignore[attr-defined]
    return "\n".join(lines)
