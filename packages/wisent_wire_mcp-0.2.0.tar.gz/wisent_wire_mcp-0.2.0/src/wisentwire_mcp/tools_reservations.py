"""MCP tools — reservations."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mcp.server.fastmcp import FastMCP

if TYPE_CHECKING:
    from wisentwire import WisentWireClient


def register(mcp: FastMCP, client: WisentWireClient) -> None:
    """Register reservation tools on the MCP server."""

    @mcp.tool()
    def list_reservations(week_start: str) -> str:
        """List reservations for a given week.
        week_start must be ISO date (e.g. '2026-04-06')."""
        reservations = client.list_reservations(week_start)
        if not reservations:
            return "No reservations for this week."
        return "\n".join(_format_reservation(r) for r in reservations)

    @mcp.tool()
    def get_reservation(reservation_id: int) -> str:
        """Get details of a single reservation."""
        r = client.get_reservation(reservation_id)
        return _format_reservation(r)

    @mcp.tool()
    def create_reservation(
        ww_id: int, start_at: str, end_at: str, description: str = "",
    ) -> str:
        """Create a reservation for a WisentWire device.
        start_at and end_at must be ISO datetime strings."""
        r = client.create_reservation(ww_id, start_at, end_at, description or None)
        return (
            f"Reservation created (id={r.id}) for WW {r.wisent_wire_name}: "
            f"{r.start_at} → {r.end_at}"
        )

    @mcp.tool()
    def delete_reservation(reservation_id: int) -> str:
        """Delete a reservation by ID."""
        client.delete_reservation(reservation_id)
        return f"Reservation {reservation_id} deleted."


def _format_reservation(r: object) -> str:
    return (
        f"- id={r.id} WW={r.wisent_wire_name} (ww_id={r.wisent_wire_id}) "  # type: ignore[attr-defined]
        f"{r.start_at} → {r.end_at}"  # type: ignore[attr-defined]
        f"{f' — {r.description}' if r.description else ''}"  # type: ignore[attr-defined]
    )
