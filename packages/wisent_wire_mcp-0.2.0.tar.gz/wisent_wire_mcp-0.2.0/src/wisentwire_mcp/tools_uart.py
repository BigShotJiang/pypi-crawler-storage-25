"""MCP tools — UART communication."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mcp.server.fastmcp import FastMCP

if TYPE_CHECKING:
    from wisentwire import WisentWireClient


def register(mcp: FastMCP, client: WisentWireClient) -> None:
    """Register UART tools on the MCP server."""

    @mcp.tool()
    def send_uart_command(ww_id: int, command: str) -> str:
        """Send a text command over UART and return the response.
        Appends newline if not present. Use for text-based device protocols."""
        if not command.endswith("\n"):
            command += "\n"
        client.send_uart_ascii(ww_id, command)
        msg = client.wait_for_uart_rx(ww_id, timeout=10)
        ascii_text = bytes.fromhex(msg.bytes_hex).decode("ascii", errors="replace")
        return f"Response (hex): {msg.bytes_hex}\nResponse (ASCII): {ascii_text}"

    @mcp.tool()
    def send_uart_hex(ww_id: int, hex_data: str) -> str:
        """Send raw hex bytes over UART. Use for binary protocols."""
        client.send_uart(ww_id, hex_data)
        msg = client.wait_for_uart_rx(ww_id, match_hex=hex_data, timeout=10)
        return f"Response (hex): {msg.bytes_hex}"

    @mcp.tool()
    def get_uart_log(ww_id: int, last_n: int = 20) -> str:
        """Get recent UART TX/RX message history.
        Use when the user wants to review communication log."""
        messages = client.get_uart_messages(ww_id)
        recent = messages[-last_n:]
        return _format_messages(recent)


def _format_messages(messages: list) -> str:
    if not messages:
        return "No UART messages."
    lines = []
    for m in messages:
        ascii_text = bytes.fromhex(m.bytes_hex).decode("ascii", errors="replace")
        lines.append(f"[{m.direction.value}] {m.bytes_hex}  ({ascii_text})")
    return "\n".join(lines)
