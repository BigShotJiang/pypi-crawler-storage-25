"""MCP tools — WisentWire listing and status."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mcp.server.fastmcp import FastMCP

if TYPE_CHECKING:
    from wisentwire import WisentWireClient


def register(mcp: FastMCP, client: WisentWireClient) -> None:
    """Register WisentWire tools on the MCP server."""

    @mcp.tool()
    def list_wisentwires() -> str:
        """List all WisentWire devices in your organization.
        Returns name, id, status, and whether virtual."""
        wws = client.list_wisentwires()
        if not wws:
            return "No WisentWire devices found."
        return "\n".join(
            f"- {ww.name} (id={ww.id}, status={ww.status.value}, virtual={ww.is_virtual})"
            for ww in wws
        )

    @mcp.tool()
    def check_ww_available(ww_id: int) -> str:
        """Check if a WisentWire device is currently available for use."""
        available = client.is_wisentwire_available(ww_id)
        return f"WisentWire {ww_id} is {'available' if available else 'not available'}."

    @mcp.tool()
    def get_ww_status(ww_id: int) -> str:
        """Get detailed status of a WisentWire: power state, availability, lab tools.
        Use when the user asks about a specific device."""
        ww = client.get_wisentwire(ww_id)
        lines = [
            f"Name: {ww.name}",
            f"Status: {ww.status.value}",
            f"Virtual: {ww.is_virtual}",
        ]
        if ww.is_virtual:
            return "\n".join(lines)
        shadow = client.get_shadow(ww_id)
        _append_shadow_info(lines, shadow)
        return "\n".join(lines)


def _append_shadow_info(lines: list[str], shadow: object) -> None:
    """Append power and lab-tool info to output lines."""
    if shadow.reported:  # type: ignore[union-attr]
        lines.append(f"Power: {shadow.reported.state}")  # type: ignore[union-attr]
        lines.append(f"Voltage: {shadow.reported.voltage_setpoint}V")  # type: ignore[union-attr]
        lines.append(f"Current limit: {shadow.reported.current_limit}A")  # type: ignore[union-attr]
    if shadow.available_lab_tools:  # type: ignore[union-attr]
        lines.append("Lab tools:")
        for tool in shadow.available_lab_tools:  # type: ignore[union-attr]
            lines.append(f"  - {tool.idn} at {tool.address}")
