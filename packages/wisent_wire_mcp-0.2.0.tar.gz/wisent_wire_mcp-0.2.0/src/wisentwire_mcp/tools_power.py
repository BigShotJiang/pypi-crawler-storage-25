"""MCP tools — power supply and telemetry."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mcp.server.fastmcp import FastMCP

if TYPE_CHECKING:
    from wisentwire import WisentWireClient


def register(mcp: FastMCP, client: WisentWireClient) -> None:
    """Register power supply tools on the MCP server."""

    @mcp.tool()
    def power_on(ww_id: int, voltage: float = 3.3, current_limit: float = 0.5) -> str:
        """Turn on the power supply with specified voltage and current limit.
        Default: 3.3V, 0.5A. Use when the user wants to power up a device."""
        client.set_power_supply(ww_id, state="ON", voltage=voltage, current=current_limit)
        shadow = client.wait_shadow_state(ww_id, "ON")
        reported = shadow.reported
        return (
            f"Power ON. Voltage: {reported.voltage_setpoint}V, "
            f"Current limit: {reported.current_limit}A"
        )

    @mcp.tool()
    def power_off(ww_id: int) -> str:
        """Turn off the power supply. Use when the user is done testing."""
        client.set_power_supply(ww_id, state="OFF")
        client.wait_shadow_state(ww_id, "OFF")
        return "Power OFF."

    @mcp.tool()
    def get_telemetry(ww_id: int) -> str:
        """Get recent voltage and current readings from the power supply.
        Use when the user asks about power consumption."""
        readings = client.get_power_telemetry(ww_id)
        if not readings:
            return "No telemetry data available."
        latest = readings[-1]
        return (
            f"Latest — Voltage: {latest.voltage}V, Current: {latest.current}A\n"
            f"Total readings: {len(readings)}"
        )
