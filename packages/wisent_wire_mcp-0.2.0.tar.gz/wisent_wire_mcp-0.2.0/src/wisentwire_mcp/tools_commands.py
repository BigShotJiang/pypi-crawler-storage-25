"""MCP tools — frame definition commands."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mcp.server.fastmcp import FastMCP

if TYPE_CHECKING:
    from wisentwire import WisentWireClient


def register(mcp: FastMCP, client: WisentWireClient) -> None:
    """Register command definition tools on the MCP server."""

    @mcp.tool()
    def list_commands(frame_def_id: int) -> str:
        """List commands for a frame definition."""
        cmds = client.list_commands(frame_def_id)
        if not cmds:
            return "No commands defined."
        return "\n".join(
            f"- {cmd.name} (id={cmd.id}, fields={len(cmd.field_values)})"
            for cmd in cmds
        )

    @mcp.tool()
    def create_command(
        frame_def_id: int, name: str, field_values_json: str = "[]",
    ) -> str:
        """Create a command for a frame definition.
        field_values_json is a JSON array of {fieldName, hexValue} objects."""
        import json
        field_values = json.loads(field_values_json) or None
        cmd = client.create_command(frame_def_id, name, field_values)
        return f"Command created: {cmd.name} (id={cmd.id})"

    @mcp.tool()
    def update_command(
        frame_def_id: int, command_id: int, name: str,
        field_values_json: str = "[]",
    ) -> str:
        """Update a command. field_values_json is a JSON array of {fieldName, hexValue} objects."""
        import json
        field_values = json.loads(field_values_json) or None
        cmd = client.update_command(frame_def_id, command_id, name, field_values)
        return f"Command updated: {cmd.name} (id={cmd.id})"

    @mcp.tool()
    def delete_command(frame_def_id: int, command_id: int) -> str:
        """Delete a command from a frame definition."""
        client.delete_command(frame_def_id, command_id)
        return f"Command {command_id} deleted."
