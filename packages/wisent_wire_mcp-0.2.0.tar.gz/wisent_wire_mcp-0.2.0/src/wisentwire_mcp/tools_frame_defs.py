"""MCP tools — frame definitions."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mcp.server.fastmcp import FastMCP

if TYPE_CHECKING:
    from wisentwire import WisentWireClient


def register(mcp: FastMCP, client: WisentWireClient) -> None:
    """Register frame definition tools on the MCP server."""

    @mcp.tool()
    def list_frame_definitions() -> str:
        """List all frame definitions in the organization."""
        defs = client.list_frame_definitions()
        if not defs:
            return "No frame definitions found."
        return "\n".join(
            f"- {fd.name} (id={fd.id}, type={fd.data_type.value}, fields={len(fd.fields)})"
            for fd in defs
        )

    @mcp.tool()
    def get_frame_definition(frame_def_id: int) -> str:
        """Get a frame definition with its fields."""
        fd = client.get_frame_definition(frame_def_id)
        lines = [f"Name: {fd.name}", f"Type: {fd.data_type.value}", "Fields:"]
        for f in fd.fields:
            lines.append(f"  {f.field_order}. {f.name} ({f.category.value}, size={f.size})")
        return "\n".join(lines)

    @mcp.tool()
    def create_frame_definition(
        name: str, fields_json: str, data_type: str = "HEX",
    ) -> str:
        """Create a frame definition.
        fields_json is a JSON array of field objects with keys:
        name, fieldOrder, category, size, constantValue, etc."""
        import json
        fields = json.loads(fields_json)
        fd = client.create_frame_definition(name, fields, data_type)
        return f"Frame definition created: {fd.name} (id={fd.id})"

    @mcp.tool()
    def update_frame_definition(
        frame_def_id: int, name: str, fields_json: str, data_type: str = "HEX",
    ) -> str:
        """Update a frame definition. fields_json is a JSON array of field objects."""
        import json
        fields = json.loads(fields_json)
        fd = client.update_frame_definition(frame_def_id, name, fields, data_type)
        return f"Frame definition updated: {fd.name} (id={fd.id})"

    @mcp.tool()
    def delete_frame_definition(frame_def_id: int) -> str:
        """Delete a frame definition by ID."""
        client.delete_frame_definition(frame_def_id)
        return f"Frame definition {frame_def_id} deleted."
