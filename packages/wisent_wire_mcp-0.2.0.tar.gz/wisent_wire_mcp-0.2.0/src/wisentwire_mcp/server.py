"""MCP server — creates the server instance and registers all tools."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from wisentwire_mcp import (
    tools_commands,
    tools_flash,
    tools_frame_defs,
    tools_power,
    tools_reservations,
    tools_uart,
    tools_work_setup,
    tools_ww,
)
from wisentwire_mcp.context import build_client


def create_server() -> FastMCP:
    """Build and return a fully configured MCP server."""
    client = build_client()
    mcp = FastMCP("wisent-wire")

    tools_ww.register(mcp, client)
    tools_power.register(mcp, client)
    tools_flash.register(mcp, client)
    tools_uart.register(mcp, client)
    tools_reservations.register(mcp, client)
    tools_work_setup.register(mcp, client)
    tools_frame_defs.register(mcp, client)
    tools_commands.register(mcp, client)

    return mcp


def main() -> None:
    """Run the MCP server (stdio transport)."""
    mcp = create_server()
    mcp.run()
