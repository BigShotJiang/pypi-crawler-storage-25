"""Entry point: python -m wisentwire_mcp"""

from wisentwire_mcp.server import main

if __name__ == "__main__":
    main()
