# wisent-wire-mcp

MCP (Model Context Protocol) server for the [Wisent Wire](https://wisent-wire.com) hardware testing platform. Lets AI assistants interact with WisentWire devices — power control, firmware flashing, and UART communication.

## Installation

```bash
pip install wisent-wire-mcp
```

## Usage

### Claude Code / Claude Desktop (stdio)

After installing, add to your MCP configuration:

```json
{
  "mcpServers": {
    "wisent-wire": {
      "command": "wisentwire-mcp",
      "env": {
        "WISENT_WIRE_URL": "https://int.wisent-wire.com",
        "WISENT_WIRE_EMAIL": "user@company.com",
        "WISENT_WIRE_PASSWORD": "..."
      }
    }
  }
}
```

### Environment variables

| Variable | Required | Description |
|----------|----------|-------------|
| `WISENT_WIRE_URL` | No | API base URL (default: `https://int.wisent-wire.com`) |
| `WISENT_WIRE_EMAIL` | Yes* | Account email |
| `WISENT_WIRE_PASSWORD` | Yes* | Account password |
| `WISENT_WIRE_TOKEN` | Yes* | API token (alternative to email/password) |
| `WISENT_WIRE_LOCAL` | No | Set to `1` for local development mode |

\* Provide either `TOKEN` or `EMAIL` + `PASSWORD`.

## Available tools

| Tool | Description |
|------|-------------|
| `list_wisentwires` | List all WisentWire devices in your organization |
| `get_ww_status` | Get detailed device status including power state and lab tools |
| `power_on` | Turn on power supply (configurable voltage and current limit) |
| `power_off` | Turn off power supply |
| `get_telemetry` | Get recent voltage and current readings |
| `flash_firmware` | Flash firmware to a device and wait for completion |
| `list_firmware` | List available firmware binaries |
| `send_uart_command` | Send a text command over UART and return the response |
| `send_uart_hex` | Send raw hex bytes over UART |
| `get_uart_log` | Get recent UART TX/RX message history |

## Development

```bash
pip install -e ".[dev]"
pytest tests/ -v
ruff check src/ tests/
```

## License

MIT
