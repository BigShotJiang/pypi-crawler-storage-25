from dataclasses import dataclass

@dataclass
class SegmenterConfig:
    min_width: int = 80
    min_height: int = 20
    min_subtree_depth: int = 3
    min_subtree_nodes: int = 10
    component_score_threshold: int = 4

# Groupings mapping page types (strings) to their logical families
PAGE_TYPE_FAMILIES = {
    "marketing": [
        "homepage",
        "landing_page",
        "pricing",
        "about_us",
        "contact_us",
    ],
    "commerce": [
        "product",
        "product_list",
        "service",
        "service_list",
        "checkout",
    ],
    "content": [
        "blog_post",
        "blog_list",
        "news_article",
        "content_page",
        "case_study",
    ],
    "docs_support": [
        "doc_page",
        "doc_index",
        "faq",
        "help_support",
        "changelog",
    ],
    "auth": [
        "login",
        "signup",
        "password_reset",
    ],
    "legal": [
        "privacy_policy",
        "terms",
        "cookie_policy",
    ],
    "special": [
        "search_results",
        "error_page",
        "profile",
        "job_listing",
    ],
}

def get_family_for_type(page_type: str) -> str:
    """Return the family name for a given page type string, or 'default' if not found."""
    page_type = page_type.lower()
    for family, types in PAGE_TYPE_FAMILIES.items():
        if page_type in types:
            return family
    return "default"

def get_config(page_type: str = "unknown") -> SegmenterConfig:
    """Return the appropriate SegmenterConfig based on the page type."""
    family = get_family_for_type(page_type)
    
    # Baseline configuration
    config = SegmenterConfig()
    
    if family == "commerce":
        # Product lists often have many small cards, we don't want to skip them
        # by requiring high node counts/depths.
        config.min_subtree_depth = 2
        config.min_subtree_nodes = 5
        
    elif family in ("content", "docs_support", "legal"):
        # Content pages (blogs, docs) are often very flat with paragraphs and headings.
        # They may lack hard visual boundaries (borders, shadows) between sections.
        config.min_subtree_depth = 2
        config.min_subtree_nodes = 5
        config.component_score_threshold = 3
        
    elif family == "marketing":
        # Marketing pages have large, visually distinct hero sections and banners.
        # We increase the node requirement to avoid splintering these large sections.
        config.min_subtree_nodes = 15
        
    # auth, special, and default fall back to the baseline config.
        
    return config
