"""Neurogebra test suite."""
