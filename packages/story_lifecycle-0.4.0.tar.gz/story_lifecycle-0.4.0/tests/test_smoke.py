"""Smoke tests — verify package imports and basic CLI registration."""


def test_package_imports():
    import story_lifecycle

    assert story_lifecycle is not None


def test_cli_module_imports():
    from story_lifecycle.cli.main import cli

    assert cli is not None
    assert cli.name in ("story", "cli")


def test_db_module_imports():
    from story_lifecycle.db.models import init_db

    assert callable(init_db)


def test_profiles_load():
    from story_lifecycle.orchestrator.nodes import load_profile

    profile = load_profile("minimal")
    assert "stages" in profile


def test_service_imports():
    from story_lifecycle.orchestrator.service import create_and_start_story

    assert callable(create_and_start_story)


def test_upsert_story():
    from story_lifecycle.db.models import init_db, upsert_story, get_story

    init_db()
    upsert_story("SMOKE-001", title="Smoke test", workspace="/tmp", status="active")
    s = get_story("SMOKE-001")
    assert s is not None
    assert s["story_key"] == "SMOKE-001"
