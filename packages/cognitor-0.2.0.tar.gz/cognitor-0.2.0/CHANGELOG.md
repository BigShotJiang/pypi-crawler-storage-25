## Release v0.2.0 - April 8, 2026

### Added

- Add support for monitoring training processes
- Monitor additional system and process metrics during inference

## Release v0.1.1 - April 6, 2026

### Fixed

- Fix bug causing library to error out when database isn't reachable

## Release v0.1.0 - April 5, 2026

First release.