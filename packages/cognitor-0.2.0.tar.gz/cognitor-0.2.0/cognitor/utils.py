import psutil
import time
import os
from datetime import datetime, timezone
from typing import Dict, Any, Optional
import torch


def get_resource_usage() -> Dict[str, float]:
    """
    Returns current CPU and RAM usage percentages.
    Returns:
        Dict[str, float]: A dictionary containing 'cpu_percent' and 'ram_usage_percent'.
    """

    process = psutil.Process(os.getpid())
    return {
        "cpu_percent": psutil.cpu_percent(interval=None),
        "ram_usage_percent": process.memory_percent()
    }

class Timer:
    """
    A context manager to measure duration and record a UTC timestamp.
    """

    def __init__(self) -> None:
        """
        Initializes the Timer instance.
        """

        self.start: float = 0.0
        self.end: float = 0.0
        self.duration: float = 0.0
        self.timestamp: str = ""

    def __enter__(self) -> 'Timer':
        """
        Starts the timer and records the current UTC timestamp.
        Returns:
            Timer: The timer instance.
        """

        self.start = time.perf_counter()
        self.timestamp = datetime.now(timezone.utc).isoformat()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """
        Stops the timer and calculates the duration.
        Args:
            exc_type (Any): The exception type if an error occurred.
            exc_val (Any): The exception value if an error occurred.
            exc_tb (Any): The traceback if an error occurred.
        """

        self.end = time.perf_counter()
        self.duration = self.end - self.start


def collect_gpu_metrics() -> Dict[str, Optional[float]]:
    """
    Collects GPU memory and utilization metrics if CUDA is available.
    Returns:
        Dict[str, Optional[float]]: gpu_usage_percent, gpu_memory_reserved_mb,
        gpu_memory_allocated_mb, gpu_utilization_percent. All None when no GPU.
    """

    if not torch.cuda.is_available():
        return {
            "gpu_usage_percent": None,
            "gpu_memory_reserved_mb": None,
            "gpu_memory_allocated_mb": None,
            "gpu_utilization_percent": None,
        }

    device_idx = torch.cuda.current_device()
    total_mem = torch.cuda.get_device_properties(device_idx).total_memory
    peak_mem = torch.cuda.max_memory_allocated(device_idx)
    gpu_memory_allocated_mb = peak_mem / (1024 * 1024)
    gpu_memory_reserved_mb = torch.cuda.memory_reserved(device_idx) / (1024 * 1024)
    gpu_usage_percent = (peak_mem / total_mem) * 100
    torch.cuda.reset_peak_memory_stats(device_idx)

    gpu_utilization_percent: Optional[float] = None
    try:
        import pynvml
        pynvml.nvmlInit()
        handle = pynvml.nvmlDeviceGetHandleByIndex(device_idx)
        util = pynvml.nvmlDeviceGetUtilizationRates(handle)
        gpu_utilization_percent = float(util.gpu)
    except Exception:
        pass

    return {
        "gpu_usage_percent": gpu_usage_percent,
        "gpu_memory_reserved_mb": gpu_memory_reserved_mb,
        "gpu_memory_allocated_mb": gpu_memory_allocated_mb,
        "gpu_utilization_percent": gpu_utilization_percent,
    }
