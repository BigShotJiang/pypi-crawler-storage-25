import logging
from typing import Any, Optional
from sqlalchemy import create_engine, Integer, String, Float, Text, ForeignKey
from sqlalchemy.orm import sessionmaker, DeclarativeBase, Mapped, mapped_column, relationship

logger = logging.getLogger(__name__)


class Base(DeclarativeBase):
    pass


class InferenceLog(Base):
    __tablename__ = 'inference_logs'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    model_name: Mapped[Optional[str]] = mapped_column(String)
    timestamp: Mapped[Optional[str]] = mapped_column(String)
    input_tokens: Mapped[Optional[int]] = mapped_column(Integer)
    output_tokens: Mapped[Optional[int]] = mapped_column(Integer)
    cpu_percent: Mapped[Optional[float]] = mapped_column(Float)
    ram_usage_percent: Mapped[Optional[float]] = mapped_column(Float)
    gpu_usage_percent: Mapped[Optional[float]] = mapped_column(Float)
    duration: Mapped[Optional[float]] = mapped_column(Float)
    pre_inference_duration: Mapped[Optional[float]] = mapped_column(Float)
    tokens_per_second: Mapped[Optional[float]] = mapped_column(Float)
    time_to_first_token: Mapped[Optional[float]] = mapped_column(Float)
    cpu_delta: Mapped[Optional[float]] = mapped_column(Float)
    ram_delta: Mapped[Optional[float]] = mapped_column(Float)
    gpu_memory_reserved_mb: Mapped[Optional[float]] = mapped_column(Float)
    gpu_memory_allocated_mb: Mapped[Optional[float]] = mapped_column(Float)
    gpu_utilization_percent: Mapped[Optional[float]] = mapped_column(Float)
    generation_params: Mapped[Optional[str]] = mapped_column(Text)
    stop_reason: Mapped[Optional[str]] = mapped_column(String)
    quantization: Mapped[Optional[str]] = mapped_column(String)
    device_name: Mapped[Optional[str]] = mapped_column(String)
    framework: Mapped[Optional[str]] = mapped_column(String)
    request_id: Mapped[Optional[str]] = mapped_column(String)
    session_id: Mapped[Optional[str]] = mapped_column(String)
    input: Mapped[Optional[str]] = mapped_column(Text)
    output: Mapped[Optional[str]] = mapped_column(Text)
    extra: Mapped[Optional[str]] = mapped_column(Text)

    error: Mapped[Optional["InferenceError"]] = relationship("InferenceError", back_populates="inference_log", uselist=False)


class InferenceError(Base):
    __tablename__ = 'inference_errors'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    inference_log_id: Mapped[int] = mapped_column(Integer, ForeignKey('inference_logs.id'), nullable=False, unique=True)
    error_message: Mapped[str] = mapped_column(Text, nullable=False)
    exception_type: Mapped[Optional[str]] = mapped_column(String)

    inference_log: Mapped["InferenceLog"] = relationship("InferenceLog", back_populates="error")


class TrainingLog(Base):
    __tablename__ = 'training_logs'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    model_name: Mapped[Optional[str]] = mapped_column(String)
    timestamp: Mapped[Optional[str]] = mapped_column(String)
    training_run_id: Mapped[Optional[str]] = mapped_column(String)
    epoch: Mapped[Optional[int]] = mapped_column(Integer)
    step: Mapped[Optional[int]] = mapped_column(Integer)
    train_loss: Mapped[Optional[float]] = mapped_column(Float)
    val_loss: Mapped[Optional[float]] = mapped_column(Float)
    learning_rate: Mapped[Optional[float]] = mapped_column(Float)
    gradient_norm: Mapped[Optional[float]] = mapped_column(Float)
    samples_per_second: Mapped[Optional[float]] = mapped_column(Float)
    duration: Mapped[Optional[float]] = mapped_column(Float)
    cpu_percent: Mapped[Optional[float]] = mapped_column(Float)
    ram_usage_percent: Mapped[Optional[float]] = mapped_column(Float)
    cpu_delta: Mapped[Optional[float]] = mapped_column(Float)
    ram_delta: Mapped[Optional[float]] = mapped_column(Float)
    gpu_usage_percent: Mapped[Optional[float]] = mapped_column(Float)
    gpu_memory_reserved_mb: Mapped[Optional[float]] = mapped_column(Float)
    gpu_memory_allocated_mb: Mapped[Optional[float]] = mapped_column(Float)
    gpu_utilization_percent: Mapped[Optional[float]] = mapped_column(Float)
    quantization: Mapped[Optional[str]] = mapped_column(String)
    device_name: Mapped[Optional[str]] = mapped_column(String)
    framework: Mapped[Optional[str]] = mapped_column(String)
    extra: Mapped[Optional[str]] = mapped_column(Text)


class DatabaseManager:
    """
    Manages the database connection and schema initialization using SQLAlchemy.
    """

    def __init__(self, host: str = "localhost", port: int = 5432, user: str = "postgres", password: str = "postgres", dbname: str = "cognitor") -> None:
        """
        Initializes the DatabaseManager with connection parameters.
        Args:
            host (str): The database host address.
            port (int): The database port number.
            user (str): The database username.
            password (str): The database password.
            dbname (str): The name of the database.
        """

        self.db_url: str = f"postgresql://{user}:{password}@{host}:{port}/{dbname}"
        self.engine: Any = create_engine(self.db_url)
        self.Session: Any = sessionmaker(self.engine)
        self._initialized: bool = False

    def init_db(self) -> None:
        """
        Initializes the database schema by creating all defined tables.
        Exits gracefully if the database is unreachable.
        """

        try:
            Base.metadata.create_all(self.engine)
            self._initialized = True
        except Exception as e:
            logger.error(f"ERROR: Database unreachable at {self.engine.url}. Error: {e}")
            logger.warning("WARNING: Unable to log traces to the database. Please check your database connection.")