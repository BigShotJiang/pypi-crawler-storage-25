import logging
import uuid
from typing import Any, Dict, Optional
import torch

from .config import config
from .database import DatabaseManager
from .models import InferenceMetadata, TrainingMetadata
from .service import LoggingService
from .utils import Timer, collect_gpu_metrics, get_resource_usage

logger = logging.getLogger(__name__)


class InferenceMonitor:
    """
    Context manager that monitors a single inference call, capturing timing,
    resource usage and token metrics.
    """

    def __init__(self, cognitor: 'Cognitor') -> None:
        self.cognitor: 'Cognitor' = cognitor
        self.input: Any = None
        self.output: Any = None
        self.error: Optional[str] = None
        self.start_usage: Optional[Dict[str, float]] = None
        self.full_timer: Timer = Timer()
        self.inference_timer: Timer = Timer()
        self.metadata: Optional[InferenceMetadata] = None
        self.generation_params: Dict[str, Any] = {}
        self.stop_reason: Optional[str] = None
        self.request_id: Optional[str] = None
        self.session_id: Optional[str] = None
        self.time_to_first_token: Optional[float] = None

    def __enter__(self) -> 'InferenceMonitor':
        self.start_usage = get_resource_usage()
        self.full_timer.__enter__()
        return self

    def track(self) -> Timer:
        """Returns a context manager to time the model call itself."""
        return self.inference_timer

    def capture(self, output: Any, input_data: Any = None) -> None:
        """Stores the inference input/output for metadata generation."""
        if input_data is not None:
            self.input = input_data
        self.output = output

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.full_timer.__exit__(exc_type, exc_val, exc_tb)
        if exc_type:
            self.error = str(exc_val)

        self.metadata = self.cognitor._build_inference_metadata(  # type: ignore[reportPrivateUsage]
            input_data=self.input,
            output=self.output,
            error=self.error,
            full_timer=self.full_timer,
            inference_timer=self.inference_timer,
            start_usage=self.start_usage or {},
            exception_type=exc_type.__name__ if exc_type else None,
            generation_params=self.generation_params,
            stop_reason=self.stop_reason,
            request_id=self.request_id,
            session_id=self.session_id,
            time_to_first_token=self.time_to_first_token,
        )
        self.cognitor._last_metadata = self.metadata  # type: ignore[reportPrivateUsage]

        if self.cognitor.logging_service:
            self.cognitor.logging_service.log_inference(self.metadata.model_dump())


class TrainingMonitor:
    """
    Context manager that monitors a single training step or epoch, capturing
    loss values, optimiser state, and resource metrics.
    """

    def __init__(self, cognitor: 'Cognitor') -> None:
        self.cognitor: 'Cognitor' = cognitor
        self.training_run_id: Optional[str] = cognitor._training_run_id
        self.epoch: Optional[int] = None
        self.step: Optional[int] = None
        self.train_loss: Optional[float] = None
        self.val_loss: Optional[float] = None
        self.learning_rate: Optional[float] = None
        self.gradient_norm: Optional[float] = None
        self.samples_per_second: Optional[float] = None
        self.extra: Dict[str, Any] = {}
        self.start_usage: Optional[Dict[str, float]] = None
        self.timer: Timer = Timer()
        self.metadata: Optional[TrainingMetadata] = None

    def __enter__(self) -> 'TrainingMonitor':
        self.start_usage = get_resource_usage()
        self.timer.__enter__()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.timer.__exit__(exc_type, exc_val, exc_tb)

        self.metadata = self.cognitor._build_training_metadata(  # type: ignore[reportPrivateUsage]
            timer=self.timer,
            start_usage=self.start_usage or {},
            training_run_id=self.training_run_id,
            epoch=self.epoch,
            step=self.step,
            train_loss=self.train_loss,
            val_loss=self.val_loss,
            learning_rate=self.learning_rate,
            gradient_norm=self.gradient_norm,
            samples_per_second=self.samples_per_second,
            extra=self.extra,
        )
        self.cognitor._last_training_metadata = self.metadata  # type: ignore[reportPrivateUsage]

        if self.cognitor.logging_service:
            self.cognitor.logging_service.log_training(self.metadata.model_dump())


class Cognitor:
    """
    Main SDK class for monitoring LLM inference and training runs.

    Usage — inference::

        cognitor = Cognitor(model_name="my-model", log_type="file")
        with cognitor.monitor() as m:
            with m.track():
                output = model.generate(input)
            m.capture(input_data=input, output=output)

    Usage — training::

        with cognitor.train() as t:
            loss = train_step(batch)
            t.train_loss = loss.item()
            t.epoch = epoch
    """

    def __init__(
        self,
        model_name: str,
        tokenizer: Any = None,
        log_type: str = config.LOG_TYPE,
        log_path: Optional[str] = None,
        training_log_path: Optional[str] = None,
        host: str = config.DB_HOST,
        port: int = config.DB_PORT,
        user: str = config.DB_USERNAME,
        password: str = config.DB_PASSWORD,
        dbname: str = config.DB_NAME,
        quantization: Optional[str] = None,
        device_name: Optional[str] = None,
        framework: Optional[str] = None,
    ) -> None:
        self.model_name: str = model_name
        self.tokenizer: Any = tokenizer
        self._last_metadata: Optional[InferenceMetadata] = None
        self._last_training_metadata: Optional[TrainingMetadata] = None
        self._training_run_id: Optional[str] = None
        self.quantization: Optional[str] = quantization
        self.framework: Optional[str] = framework

        if device_name is not None:
            self.device_name: Optional[str] = device_name
        elif torch.cuda.is_available():
            self.device_name = torch.cuda.get_device_name(torch.cuda.current_device())
        else:
            self.device_name = "cpu"

        self.db_manager: Optional[DatabaseManager] = None
        self.logging_service: Optional[LoggingService] = None

        if log_type == "database":
            self.db_manager = DatabaseManager(
                host=host, port=port, user=user, password=password, dbname=dbname
            )
            self.db_manager.init_db()
            self.logging_service = LoggingService(db_manager=self.db_manager)
        elif log_type == "file":
            if not log_path:
                log_path = f"{model_name}_inference_logs.jsonl"
            if not training_log_path:
                training_log_path = f"{model_name}_training_logs.jsonl"
            self.logging_service = LoggingService(
                log_file=log_path, training_log_file=training_log_path
            )
        else:
            raise ValueError(f"Invalid log_type: {log_type!r}. Must be 'database' or 'file'.")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def monitor(self) -> InferenceMonitor:
        """Returns a context manager to monitor a single inference call."""
        return InferenceMonitor(self)

    def new_training_run(self) -> str:
        """Generates a new training run ID and stores it for subsequent train() calls."""
        self._training_run_id = str(uuid.uuid4())
        return self._training_run_id

    def train(self) -> TrainingMonitor:
        """Returns a context manager to monitor a training step or epoch."""
        return TrainingMonitor(self)

    def monitor_inference(self, func: Any, *args: Any, **kwargs: Any) -> Dict[str, Any]:
        """
        Convenience wrapper: runs *func* inside a monitored inference context.

        Returns:
            Dict with keys ``output`` and ``metadata``.
        """
        input_data: Any = args[0] if args else kwargs
        with self.monitor() as m:
            try:
                with m.track():
                    output = func(*args, **kwargs)
                m.capture(input_data=input_data, output=output)
                return {"output": output, "metadata": m.metadata.model_dump() if m.metadata else {}}
            except Exception as e:
                raise e

    def get_last_metadata(self) -> Optional[Dict[str, Any]]:
        """Returns the metadata dict from the last monitored inference, or None."""
        return self._last_metadata.model_dump() if self._last_metadata else None

    def get_last_training_metadata(self) -> Optional[Dict[str, Any]]:
        """Returns the metadata dict from the last monitored training step, or None."""
        return self._last_training_metadata.model_dump() if self._last_training_metadata else None

    # ------------------------------------------------------------------
    # Internal builders (called by the monitor context managers)
    # ------------------------------------------------------------------

    def _build_inference_metadata(
        self,
        input_data: Any,
        output: Any,
        error: Optional[str],
        full_timer: Timer,
        inference_timer: Timer,
        start_usage: Dict[str, float],
        exception_type: Optional[str] = None,
        generation_params: Optional[Dict[str, Any]] = None,
        stop_reason: Optional[str] = None,
        request_id: Optional[str] = None,
        session_id: Optional[str] = None,
        time_to_first_token: Optional[float] = None,
    ) -> InferenceMetadata:
        end_usage = get_resource_usage()
        gpu = collect_gpu_metrics()

        input_tokens: int = 0
        output_tokens: int = 0
        if self.tokenizer:
            input_tokens, output_tokens = self._count_tokens(input_data, output)

        pre_inference_duration = full_timer.duration - inference_timer.duration
        tokens_per_second = (
            output_tokens / inference_timer.duration
            if inference_timer.duration > 0 and output_tokens > 0
            else None
        )
        cpu_delta = end_usage["cpu_percent"] - start_usage.get("cpu_percent", end_usage["cpu_percent"])
        ram_delta = end_usage["ram_usage_percent"] - start_usage.get("ram_usage_percent", end_usage["ram_usage_percent"])

        return InferenceMetadata(
            model_name=self.model_name,
            timestamp=full_timer.timestamp,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cpu_percent=end_usage["cpu_percent"],
            ram_usage_percent=end_usage["ram_usage_percent"],
            gpu_usage_percent=gpu["gpu_usage_percent"],
            duration=inference_timer.duration,
            pre_inference_duration=pre_inference_duration,
            tokens_per_second=tokens_per_second,
            time_to_first_token=time_to_first_token,
            cpu_delta=cpu_delta,
            ram_delta=ram_delta,
            gpu_memory_reserved_mb=gpu["gpu_memory_reserved_mb"],
            gpu_memory_allocated_mb=gpu["gpu_memory_allocated_mb"],
            gpu_utilization_percent=gpu["gpu_utilization_percent"],
            generation_params=generation_params or {},
            stop_reason=stop_reason,
            quantization=self.quantization,
            device_name=self.device_name,
            framework=self.framework,
            exception_type=exception_type,
            request_id=request_id,
            session_id=session_id,
            input=input_data,
            output=output,
            error=error,
        )

    def _build_training_metadata(
        self,
        timer: Timer,
        start_usage: Dict[str, float],
        training_run_id: Optional[str] = None,
        epoch: Optional[int] = None,
        step: Optional[int] = None,
        train_loss: Optional[float] = None,
        val_loss: Optional[float] = None,
        learning_rate: Optional[float] = None,
        gradient_norm: Optional[float] = None,
        samples_per_second: Optional[float] = None,
        extra: Optional[Dict[str, Any]] = None,
    ) -> TrainingMetadata:
        end_usage = get_resource_usage()
        gpu = collect_gpu_metrics()
        cpu_delta = end_usage["cpu_percent"] - start_usage.get("cpu_percent", end_usage["cpu_percent"])
        ram_delta = end_usage["ram_usage_percent"] - start_usage.get("ram_usage_percent", end_usage["ram_usage_percent"])

        return TrainingMetadata(
            model_name=self.model_name,
            timestamp=timer.timestamp,
            training_run_id=training_run_id,
            epoch=epoch,
            step=step,
            train_loss=train_loss,
            val_loss=val_loss,
            learning_rate=learning_rate,
            gradient_norm=gradient_norm,
            samples_per_second=samples_per_second,
            duration=timer.duration,
            cpu_percent=end_usage["cpu_percent"],
            ram_usage_percent=end_usage["ram_usage_percent"],
            cpu_delta=cpu_delta,
            ram_delta=ram_delta,
            gpu_usage_percent=gpu["gpu_usage_percent"],
            gpu_memory_reserved_mb=gpu["gpu_memory_reserved_mb"],
            gpu_memory_allocated_mb=gpu["gpu_memory_allocated_mb"],
            gpu_utilization_percent=gpu["gpu_utilization_percent"],
            quantization=self.quantization,
            device_name=self.device_name,
            framework=self.framework,
            extra=extra or {},
        )

    def _count_tokens(self, input_data: Any, output: Any) -> tuple[int, int]:
        """Counts input and output tokens using the tokenizer."""
        input_tokens = 0
        output_tokens = 0

        if isinstance(input_data, str):
            input_tokens = len(self.tokenizer.encode(input_data))
        elif isinstance(input_data, list):
            items: list[Any] = input_data
            if all(isinstance(i, str) for i in items):
                input_tokens = sum(len(self.tokenizer.encode(i)) for i in items)  # type: ignore[arg-type]
            elif all(isinstance(i, dict) for i in items):
                for msg in items:
                    if isinstance(msg, dict) and "content" in msg:
                        input_tokens += len(self.tokenizer.encode(msg["content"]))

        if output:
            if isinstance(output, list):
                output_list: list[Any] = output
                for item in output_list:
                    if isinstance(item, dict):
                        if "generated_text" in item:
                            output_tokens += len(self.tokenizer.encode(item["generated_text"]))
                        elif "summary_text" in item:
                            output_tokens += len(self.tokenizer.encode(item["summary_text"]))
                        elif "translation_text" in item:
                            output_tokens += len(self.tokenizer.encode(item["translation_text"]))
                    elif isinstance(item, str):
                        output_tokens += len(self.tokenizer.encode(item))
            elif isinstance(output, dict):
                if "generated_text" in output:
                    output_tokens = len(self.tokenizer.encode(output["generated_text"]))
            elif isinstance(output, str):
                output_tokens = len(self.tokenizer.encode(output))

        return input_tokens, output_tokens
