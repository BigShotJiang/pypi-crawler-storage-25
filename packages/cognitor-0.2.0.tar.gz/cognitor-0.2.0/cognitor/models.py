from typing import Any, Dict, Optional
from pydantic import BaseModel


class InferenceMetadata(BaseModel):
    model_name: str
    timestamp: str
    input_tokens: int
    output_tokens: int
    cpu_percent: float
    ram_usage_percent: float
    gpu_usage_percent: Optional[float] = None
    duration: float
    pre_inference_duration: float = 0.0
    tokens_per_second: Optional[float] = None
    time_to_first_token: Optional[float] = None
    cpu_delta: float = 0.0
    ram_delta: float = 0.0
    gpu_memory_reserved_mb: Optional[float] = None
    gpu_memory_allocated_mb: Optional[float] = None
    gpu_utilization_percent: Optional[float] = None
    generation_params: Dict[str, Any] = {}
    stop_reason: Optional[str] = None
    quantization: Optional[str] = None
    device_name: Optional[str] = None
    framework: Optional[str] = None
    exception_type: Optional[str] = None
    request_id: Optional[str] = None
    session_id: Optional[str] = None
    input: Any
    output: Any
    error: Optional[str] = None
    extra: Dict[str, Any] = {}


class TrainingMetadata(BaseModel):
    model_name: str
    timestamp: str
    training_run_id: Optional[str] = None
    epoch: Optional[int] = None
    step: Optional[int] = None
    train_loss: Optional[float] = None
    val_loss: Optional[float] = None
    learning_rate: Optional[float] = None
    gradient_norm: Optional[float] = None
    samples_per_second: Optional[float] = None
    duration: float
    cpu_percent: float
    ram_usage_percent: float
    cpu_delta: float = 0.0
    ram_delta: float = 0.0
    gpu_usage_percent: Optional[float] = None
    gpu_memory_reserved_mb: Optional[float] = None
    gpu_memory_allocated_mb: Optional[float] = None
    gpu_utilization_percent: Optional[float] = None
    quantization: Optional[str] = None
    device_name: Optional[str] = None
    framework: Optional[str] = None
    extra: Dict[str, Any] = {}
