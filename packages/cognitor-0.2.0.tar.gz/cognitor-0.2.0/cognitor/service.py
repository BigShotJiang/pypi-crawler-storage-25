import json
import logging
import os
from typing import Any, Dict, Optional
from .database import DatabaseManager, InferenceLog, InferenceError, TrainingLog


logger = logging.getLogger(__name__)

class LoggingService:
    """
    Service responsible for logging inference and training metadata to either a database or local files.
    Inference and training metrics are kept in separate storage (separate DB tables or separate files).
    """

    def __init__(
        self,
        db_manager: Optional[DatabaseManager] = None,
        log_file: Optional[str] = None,
        training_log_file: Optional[str] = None,
    ) -> None:
        """
        Initializes the LoggingService with a DatabaseManager and/or log file paths.
        Args:
            db_manager (Optional[DatabaseManager]): The database manager instance for DB logging.
            log_file (Optional[str]): The path to the local file for inference file-based logging.
            training_log_file (Optional[str]): The path to the local file for training file-based logging.
        """

        self.db_manager: Optional[DatabaseManager] = db_manager
        self.log_file: Optional[str] = log_file
        self.training_log_file: Optional[str] = training_log_file

    def log_inference(self, metadata: Dict[str, Any]) -> None:
        """
        Saves inference metadata to the configured target (database or file).
        Args:
            metadata (Dict[str, Any]): The inference metadata to be logged.
        """

        if self.db_manager and self.db_manager._initialized:
            self._log_to_db(metadata)
        
        if self.log_file:
            self._log_to_file(metadata)

    def _log_to_db(self, metadata: Dict[str, Any]) -> None:
        """
        Internal method to save inference metadata to the database using SQLAlchemy.
        Args:
            metadata (Dict[str, Any]): The inference metadata to be logged.
        """

        if not self.db_manager:
            return

        session: Any = self.db_manager.Session()
        try:
            log_entry = InferenceLog(
                model_name=metadata.get("model_name"),
                timestamp=metadata.get("timestamp"),
                input_tokens=metadata.get("input_tokens"),
                output_tokens=metadata.get("output_tokens"),
                cpu_percent=metadata.get("cpu_percent"),
                ram_usage_percent=metadata.get("ram_usage_percent"),
                gpu_usage_percent=metadata.get("gpu_usage_percent"),
                duration=metadata.get("duration"),
                pre_inference_duration=metadata.get("pre_inference_duration"),
                tokens_per_second=metadata.get("tokens_per_second"),
                time_to_first_token=metadata.get("time_to_first_token"),
                cpu_delta=metadata.get("cpu_delta"),
                ram_delta=metadata.get("ram_delta"),
                gpu_memory_reserved_mb=metadata.get("gpu_memory_reserved_mb"),
                gpu_memory_allocated_mb=metadata.get("gpu_memory_allocated_mb"),
                gpu_utilization_percent=metadata.get("gpu_utilization_percent"),
                generation_params=json.dumps(metadata.get("generation_params", {})),
                stop_reason=metadata.get("stop_reason"),
                quantization=metadata.get("quantization"),
                device_name=metadata.get("device_name"),
                framework=metadata.get("framework"),
                request_id=metadata.get("request_id"),
                session_id=metadata.get("session_id"),
                input=json.dumps(metadata.get("input")),
                output=json.dumps(metadata.get("output")),
                extra=json.dumps(metadata.get("extra", {}))
            )
            session.add(log_entry)
            session.flush()

            if metadata.get("error"):
                error_entry = InferenceError(
                    inference_log_id=log_entry.id,
                    error_message=metadata.get("error"),
                    exception_type=metadata.get("exception_type"),
                )
                session.add(error_entry)

            session.commit()
        except Exception as e:
            session.rollback()
            logger.warning(f"WARNING: Failed to log to database: {e}")
        finally:
            session.close()

    def _log_to_file(self, metadata: Dict[str, Any]) -> None:
        """
        Internal method to save inference metadata to a local file in JSON lines format.
        Args:
            metadata (Dict[str, Any]): The inference metadata to be logged.
        """

        if not self.log_file:
            return

        try:
            # Ensure the directory exists
            log_dir = os.path.dirname(self.log_file)
            if log_dir:
                os.makedirs(log_dir, exist_ok=True)

            with open(self.log_file, "a") as f:
                f.write(json.dumps(metadata) + "\n")
        except Exception as e:
            logger.warning(f"WARNING: Failed to log to file {self.log_file}: {e}")

    def log_training(self, metadata: Dict[str, Any]) -> None:
        """
        Saves training metadata to the configured target (database or file).
        Args:
            metadata (Dict[str, Any]): The training metadata to be logged.
        """

        if self.db_manager and self.db_manager._initialized:
            self._log_training_to_db(metadata)

        if self.training_log_file:
            self._log_training_to_file(metadata)

    def _log_training_to_db(self, metadata: Dict[str, Any]) -> None:
        """
        Internal method to save training metadata to the database using SQLAlchemy.
        Args:
            metadata (Dict[str, Any]): The training metadata to be logged.
        """

        if not self.db_manager:
            return

        session: Any = self.db_manager.Session()
        try:
            log_entry = TrainingLog(
                model_name=metadata.get("model_name"),
                timestamp=metadata.get("timestamp"),
                training_run_id=metadata.get("training_run_id"),
                epoch=metadata.get("epoch"),
                step=metadata.get("step"),
                train_loss=metadata.get("train_loss"),
                val_loss=metadata.get("val_loss"),
                learning_rate=metadata.get("learning_rate"),
                gradient_norm=metadata.get("gradient_norm"),
                samples_per_second=metadata.get("samples_per_second"),
                duration=metadata.get("duration"),
                cpu_percent=metadata.get("cpu_percent"),
                ram_usage_percent=metadata.get("ram_usage_percent"),
                cpu_delta=metadata.get("cpu_delta"),
                ram_delta=metadata.get("ram_delta"),
                gpu_usage_percent=metadata.get("gpu_usage_percent"),
                gpu_memory_reserved_mb=metadata.get("gpu_memory_reserved_mb"),
                gpu_memory_allocated_mb=metadata.get("gpu_memory_allocated_mb"),
                gpu_utilization_percent=metadata.get("gpu_utilization_percent"),
                quantization=metadata.get("quantization"),
                device_name=metadata.get("device_name"),
                framework=metadata.get("framework"),
                extra=json.dumps(metadata.get("extra", {})),
            )
            session.add(log_entry)
            session.commit()
        except Exception as e:
            session.rollback()
            logger.warning(f"WARNING: Failed to log training to database: {e}")
        finally:
            session.close()

    def _log_training_to_file(self, metadata: Dict[str, Any]) -> None:
        """
        Internal method to save training metadata to a local file in JSON lines format.
        Args:
            metadata (Dict[str, Any]): The training metadata to be logged.
        """

        if not self.training_log_file:
            return

        try:
            log_dir = os.path.dirname(self.training_log_file)
            if log_dir:
                os.makedirs(log_dir, exist_ok=True)

            with open(self.training_log_file, "a") as f:
                f.write(json.dumps(metadata) + "\n")
        except Exception as e:
            logger.warning(f"WARNING: Failed to log training to file {self.training_log_file}: {e}")
