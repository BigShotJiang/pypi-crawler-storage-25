from pydantic_settings import BaseSettings, SettingsConfigDict


class Config(BaseSettings):

    DB_HOST: str = "localhost"
    DB_PORT: int = 5432
    DB_USERNAME: str = "cognitoruser"
    DB_PASSWORD: str = "cognitorpassword"
    DB_NAME: str = "cognitor"
    LOG_TYPE: str = "database"
    LOG_PATH: str = "cognitor_inference.jsonl"
    TRAINING_LOG_PATH: str = "cognitor_training.jsonl"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_prefix="",
        extra="allow",
    )

config = Config()