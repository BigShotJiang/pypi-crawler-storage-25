import time
from typing import Any, Dict, Optional

try:
    from transformers import TrainerCallback, TrainerControl, TrainerState, TrainingArguments
except ImportError as exc:
    raise ImportError(
        "transformers is required to use cognitor.integrations.transformers. "
        "Install it with: pip install transformers"
    ) from exc

from cognitor.cognitor import Cognitor


class HFTrainingCallback(TrainerCallback):
    """
    A HuggingFace ``TrainerCallback`` that records per-step and per-epoch
    training metrics using Cognitor.

    Pass an instance to the ``callbacks`` argument of ``Trainer``::

        from cognitor import Cognitor
        from cognitor.integrations.transformers import HFTrainingCallback

        cognitor = Cognitor(
            model_name="my-model",
            log_type="database",          # or "file"
            training_log_path="train.jsonl",
        )

        trainer = Trainer(
            ...,
            callbacks=[HFTrainingCallback(cognitor)],
        )

    Metrics captured per logged step (``on_log``):
        - ``train_loss``      from ``logs["loss"]``
        - ``learning_rate``   from ``logs["learning_rate"]``
        - ``gradient_norm``   from ``logs["grad_norm"]``
        - ``samples_per_second``  derived from batch size and step duration
        - ``epoch``, ``step``

    Metrics captured per evaluation (``on_evaluate``):
        - ``val_loss``  from ``metrics["eval_loss"]``
        - ``epoch``, ``step``

    Resource metrics (CPU, RAM, GPU) are captured automatically for every call.
    """

    def __init__(self, cognitor_instance: Cognitor) -> None:
        self._cognitor: Cognitor = cognitor_instance
        self._step_start_time: Optional[float] = None
        self._last_step_duration: Optional[float] = None

    def on_step_begin(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        **kwargs: Any,
    ) -> None:
        self._step_start_time = time.time()

    def on_step_end(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        **kwargs: Any,
    ) -> None:
        if self._step_start_time is not None:
            self._last_step_duration = time.time() - self._step_start_time
            self._step_start_time = None

    def on_log(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        logs: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        if logs is None or "loss" not in logs:
            return

        samples_per_second: Optional[float] = None
        if self._last_step_duration and self._last_step_duration > 0:
            effective_batch_size = (
                args.per_device_train_batch_size * args.gradient_accumulation_steps
            )
            samples_per_second = effective_batch_size / self._last_step_duration

        with self._cognitor.train() as t:
            t.epoch = int(state.epoch) if state.epoch else None
            t.step = state.global_step
            t.train_loss = logs.get("loss")
            t.learning_rate = logs.get("learning_rate")
            t.gradient_norm = logs.get("grad_norm")
            t.samples_per_second = samples_per_second

    def on_evaluate(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        metrics: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        if metrics is None:
            return
        val_loss = metrics.get("eval_loss")
        if val_loss is None:
            return

        with self._cognitor.train() as t:
            t.epoch = int(state.epoch) if state.epoch else None
            t.step = state.global_step
            t.val_loss = val_loss
