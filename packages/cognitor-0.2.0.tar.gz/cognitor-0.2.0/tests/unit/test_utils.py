import time
import pytest
from cognitor.utils import get_resource_usage, Timer

def test_get_resource_usage():
    usage = get_resource_usage()
    assert "cpu_percent" in usage
    assert "ram_usage_percent" in usage
    assert isinstance(usage["cpu_percent"], float)
    assert isinstance(usage["ram_usage_percent"], float)

def test_timer_context_manager():
    with Timer() as t:
        time.sleep(0.1)
    
    assert t.duration >= 0.1
    assert t.timestamp != ""
    assert t.start > 0
    assert t.end > t.start

def test_timer_manual():
    t = Timer()
    with t:
        pass
    assert t.duration >= 0
