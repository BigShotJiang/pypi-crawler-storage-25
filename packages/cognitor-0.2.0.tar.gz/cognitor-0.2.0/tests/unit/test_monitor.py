import pytest
import json
from cognitor import Cognitor
from unittest.mock import MagicMock, patch

@patch("cognitor.cognitor.DatabaseManager")
def test_metrics_collection(mock_db_manager, tmp_path):
    cognitor = Cognitor(model_name="test-model")
    
    with cognitor.monitor() as m:
        input_val = 5
        with m.track():
            output = input_val * 2
        m.capture(input_data=input_val, output=output)
    
    assert output == 10
    metadata = cognitor.get_last_metadata()
    assert metadata["model_name"] == "test-model"
    assert "cpu_percent" in metadata
    assert "ram_usage_percent" in metadata
    assert "duration" in metadata
    assert metadata["input"] == 5
    assert metadata["pre_inference_duration"] >= 0
    assert "cpu_delta" in metadata
    assert "ram_delta" in metadata
    assert metadata["device_name"] is not None

@patch("cognitor.cognitor.DatabaseManager")
def test_token_counting(mock_db_manager, tmp_path):
    mock_tokenizer = MagicMock()
    mock_tokenizer.encode.side_effect = lambda x: [1] * len(x.split())
    
    cognitor = Cognitor(model_name="test-model", tokenizer=mock_tokenizer)
    
    input_text = "This is a test input"
    with cognitor.monitor() as m:
        with m.track():
            output = {"generated_text": "This is a test output"}
        m.capture(input_data=input_text, output=output)
    
    metadata = cognitor.get_last_metadata()
    assert metadata["input_tokens"] == 5 # "This is a test input" -> 5 words
    assert metadata["output_tokens"] == 5 # "This is a test output" -> 5 words
    assert metadata["tokens_per_second"] is not None
    assert metadata["tokens_per_second"] > 0

@patch("cognitor.cognitor.DatabaseManager")
def test_error_handling(mock_db_manager, tmp_path):
    cognitor = Cognitor(model_name="test-model")
    
    with pytest.raises(ValueError):
        with cognitor.monitor() as m:
            with m.track():
                m.capture(input_data=5, output=None)
                raise ValueError("Inference failed")
    
    metadata = cognitor.get_last_metadata()
    assert metadata["error"] == "Inference failed"
    assert metadata["exception_type"] == "ValueError"

def test_file_logging(tmp_path):
    log_file = tmp_path / "test_logs.jsonl"
    cognitor = Cognitor(model_name="test-model", log_type="file", log_path=str(log_file))
    
    with cognitor.monitor() as m:
        input_val = 5
        with m.track():
            output = input_val * 2
        m.capture(input_data=input_val, output=output)
    
    assert log_file.exists()
    with open(log_file, "r") as f:
        data = json.loads(f.readline())
        assert data["model_name"] == "test-model"
        assert data["input"] == 5
        assert data["output"] == 10
        assert "pre_inference_duration" in data
        assert "device_name" in data

@patch("cognitor.cognitor.DatabaseManager")
def test_generation_params(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")
    
    with cognitor.monitor() as m:
        m.generation_params = {"temperature": 0.7, "top_p": 0.9, "max_new_tokens": 128}
        with m.track():
            output = "result"
        m.capture(input_data="prompt", output=output)
    
    metadata = cognitor.get_last_metadata()
    assert metadata["generation_params"]["temperature"] == 0.7
    assert metadata["generation_params"]["top_p"] == 0.9
    assert metadata["generation_params"]["max_new_tokens"] == 128

@patch("cognitor.cognitor.DatabaseManager")
def test_stop_reason(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")
    
    with cognitor.monitor() as m:
        m.stop_reason = "eos_token"
        with m.track():
            output = "done"
        m.capture(input_data="input", output=output)
    
    metadata = cognitor.get_last_metadata()
    assert metadata["stop_reason"] == "eos_token"

@patch("cognitor.cognitor.DatabaseManager")
def test_request_and_session_tracking(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")
    
    with cognitor.monitor() as m:
        m.request_id = "req-abc-123"
        m.session_id = "sess-xyz-456"
        with m.track():
            output = "result"
        m.capture(input_data="input", output=output)
    
    metadata = cognitor.get_last_metadata()
    assert metadata["request_id"] == "req-abc-123"
    assert metadata["session_id"] == "sess-xyz-456"

@patch("cognitor.cognitor.DatabaseManager")
def test_time_to_first_token(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")
    
    with cognitor.monitor() as m:
        m.time_to_first_token = 0.042
        with m.track():
            output = "streamed output"
        m.capture(input_data="prompt", output=output)
    
    metadata = cognitor.get_last_metadata()
    assert metadata["time_to_first_token"] == pytest.approx(0.042)

@patch("cognitor.cognitor.DatabaseManager")
def test_hardware_context_auto_detect(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")
    # device_name should be auto-detected (either a GPU name or "cpu")
    assert cognitor.device_name is not None
    assert isinstance(cognitor.device_name, str)

@patch("cognitor.cognitor.DatabaseManager")
def test_hardware_context_explicit(mock_db_manager):
    cognitor = Cognitor(
        model_name="test-model",
        quantization="int4",
        device_name="NVIDIA RTX 3090",
        framework="transformers",
    )
    
    with cognitor.monitor() as m:
        with m.track():
            output = "result"
        m.capture(input_data="input", output=output)
    
    metadata = cognitor.get_last_metadata()
    assert metadata["quantization"] == "int4"
    assert metadata["device_name"] == "NVIDIA RTX 3090"
    assert metadata["framework"] == "transformers"

@patch("cognitor.cognitor.DatabaseManager")
def test_latency_breakdown(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")
    
    with cognitor.monitor() as m:
        with m.track():
            output = "result"
        m.capture(input_data="input", output=output)
    
    metadata = cognitor.get_last_metadata()
    assert metadata["pre_inference_duration"] >= 0
    assert metadata["duration"] >= 0
    # full duration >= inference duration
    assert metadata["pre_inference_duration"] + metadata["duration"] >= metadata["duration"]

@patch("cognitor.cognitor.DatabaseManager")
def test_no_exception_type_on_success(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")
    
    with cognitor.monitor() as m:
        with m.track():
            output = "ok"
        m.capture(input_data="input", output=output)
    
    metadata = cognitor.get_last_metadata()
    assert metadata["exception_type"] is None
    assert metadata["error"] is None
