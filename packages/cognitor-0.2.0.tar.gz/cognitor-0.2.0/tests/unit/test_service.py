import json
import os
import pytest
from unittest.mock import MagicMock, patch, call
from cognitor.service import LoggingService

SAMPLE_METADATA = {
    "model_name": "test-model",
    "timestamp": "2023-01-01T00:00:00Z",
    "input_tokens": 5,
    "output_tokens": 10,
    "cpu_percent": 20.0,
    "ram_usage_percent": 30.0,
    "gpu_usage_percent": None,
    "duration": 0.5,
    "pre_inference_duration": 0.01,
    "tokens_per_second": 20.0,
    "time_to_first_token": None,
    "cpu_delta": 1.0,
    "ram_delta": 0.5,
    "gpu_memory_reserved_mb": None,
    "gpu_memory_allocated_mb": None,
    "gpu_utilization_percent": None,
    "generation_params": {"temperature": 0.7},
    "stop_reason": "eos_token",
    "quantization": None,
    "device_name": "cpu",
    "framework": None,
    "exception_type": None,
    "request_id": "req-1",
    "session_id": "sess-1",
    "input": {"text": "hello"},
    "output": {"text": "world"},
    "error": None,
    "extra": {"key": "value"},
}

@patch("cognitor.service.InferenceError")
@patch("cognitor.service.InferenceLog")
def test_log_to_db_success(mock_inference_log, mock_inference_error):
    mock_db_manager = MagicMock()
    mock_db_manager._initialized = True
    mock_session = MagicMock()
    mock_db_manager.Session.return_value = mock_session
    
    service = LoggingService(db_manager=mock_db_manager)
    service.log_inference(SAMPLE_METADATA)
    
    mock_session.add.assert_called_once()
    mock_session.flush.assert_called_once()
    mock_session.commit.assert_called_once()
    mock_session.close.assert_called_once()
    mock_inference_error.assert_not_called()

@patch("cognitor.service.InferenceError")
@patch("cognitor.service.InferenceLog")
def test_log_to_db_new_fields_passed(mock_inference_log, mock_inference_error):
    mock_db_manager = MagicMock()
    mock_db_manager._initialized = True
    mock_session = MagicMock()
    mock_db_manager.Session.return_value = mock_session

    service = LoggingService(db_manager=mock_db_manager)
    service.log_inference(SAMPLE_METADATA)

    _, kwargs = mock_inference_log.call_args
    assert kwargs["pre_inference_duration"] == 0.01
    assert kwargs["tokens_per_second"] == 20.0
    assert kwargs["cpu_delta"] == 1.0
    assert kwargs["ram_delta"] == 0.5
    assert kwargs["stop_reason"] == "eos_token"
    assert kwargs["device_name"] == "cpu"
    assert kwargs["request_id"] == "req-1"
    assert kwargs["session_id"] == "sess-1"
    assert "error" not in kwargs
    assert "exception_type" not in kwargs
    assert json.loads(kwargs["generation_params"]) == {"temperature": 0.7}

@patch("cognitor.service.InferenceError")
@patch("cognitor.service.InferenceLog")
def test_log_to_db_error_creates_error_entity(mock_inference_log, mock_inference_error):
    mock_db_manager = MagicMock()
    mock_db_manager._initialized = True
    mock_session = MagicMock()
    mock_db_manager.Session.return_value = mock_session
    mock_log_instance = MagicMock()
    mock_log_instance.id = 42
    mock_inference_log.return_value = mock_log_instance

    service = LoggingService(db_manager=mock_db_manager)
    error_metadata = {**SAMPLE_METADATA, "error": "Something failed", "exception_type": "RuntimeError"}
    service.log_inference(error_metadata)

    mock_inference_log.assert_called_once()
    mock_inference_error.assert_called_once()
    _, error_kwargs = mock_inference_error.call_args
    assert error_kwargs["inference_log_id"] == 42
    assert error_kwargs["error_message"] == "Something failed"
    assert error_kwargs["exception_type"] == "RuntimeError"
    mock_session.flush.assert_called_once()
    assert mock_session.add.call_count == 2
    mock_session.commit.assert_called_once()

@patch("cognitor.service.InferenceError")
@patch("cognitor.service.InferenceLog")
def test_log_to_db_no_error_no_error_entity(mock_inference_log, mock_inference_error):
    mock_db_manager = MagicMock()
    mock_db_manager._initialized = True
    mock_session = MagicMock()
    mock_db_manager.Session.return_value = mock_session

    service = LoggingService(db_manager=mock_db_manager)
    service.log_inference(SAMPLE_METADATA)  # error is None

    mock_inference_error.assert_not_called()
    mock_session.add.assert_called_once()

@patch("cognitor.service.InferenceError")
@patch("cognitor.service.InferenceLog")
def test_log_to_db_failure(mock_inference_log, mock_inference_error):
    mock_db_manager = MagicMock()
    mock_db_manager._initialized = True
    mock_session = MagicMock()
    mock_db_manager.Session.return_value = mock_session
    mock_session.commit.side_effect = Exception("DB error")
    
    service = LoggingService(db_manager=mock_db_manager)
    service.log_inference({"model_name": "test-model"})
    
    mock_session.rollback.assert_called_once()
    mock_session.close.assert_called_once()

def test_log_to_file_success(tmp_path):
    log_file = tmp_path / "subdir" / "test_logs.jsonl"
    service = LoggingService(log_file=str(log_file))
    service.log_inference(SAMPLE_METADATA)
    
    assert log_file.exists()
    with open(log_file, "r") as f:
        data = json.loads(f.read())
        assert data["model_name"] == "test-model"
        assert data["stop_reason"] == "eos_token"
        assert data["request_id"] == "req-1"
        assert data["device_name"] == "cpu"

@patch("builtins.open")
def test_log_to_file_failure(mock_open):
    mock_open.side_effect = Exception("File error")
    service = LoggingService(log_file="test.jsonl")
    
    # Should not raise exception, just print warning
    service.log_inference({"model_name": "test-model"})
