import json
import pytest
from unittest.mock import MagicMock, patch
from cognitor import Cognitor, TrainingMetadata
from cognitor.service import LoggingService
from cognitor.database import TrainingLog

SAMPLE_TRAINING_METADATA = {
    "model_name": "test-model",
    "timestamp": "2026-01-01T00:00:00+00:00",
    "training_run_id": "abc123",
    "epoch": 1,
    "step": 100,
    "train_loss": 0.42,
    "val_loss": 0.55,
    "learning_rate": 1e-4,
    "gradient_norm": 0.9,
    "samples_per_second": 32.5,
    "duration": 1.5,
    "cpu_percent": 25.0,
    "ram_usage_percent": 40.0,
    "cpu_delta": 5.0,
    "ram_delta": 1.0,
    "gpu_usage_percent": None,
    "gpu_memory_reserved_mb": None,
    "gpu_memory_allocated_mb": None,
    "gpu_utilization_percent": None,
    "quantization": None,
    "device_name": "cpu",
    "framework": "transformers",
    "extra": {"note": "warmup"},
}


# --- TrainingMetadata pydantic model ---

def test_training_metadata_required_fields():
    meta = TrainingMetadata(
        model_name="my-model",
        timestamp="2026-01-01T00:00:00+00:00",
        duration=2.0,
        cpu_percent=10.0,
        ram_usage_percent=20.0,
    )
    assert meta.model_name == "my-model"
    assert meta.duration == 2.0
    assert meta.train_loss is None
    assert meta.extra == {}


def test_training_metadata_all_fields():
    meta = TrainingMetadata(**{k: v for k, v in SAMPLE_TRAINING_METADATA.items()})
    assert meta.epoch == 1
    assert meta.step == 100
    assert meta.train_loss == pytest.approx(0.42)
    assert meta.val_loss == pytest.approx(0.55)
    assert meta.learning_rate == pytest.approx(1e-4)
    assert meta.gradient_norm == pytest.approx(0.9)
    assert meta.samples_per_second == pytest.approx(32.5)
    assert meta.framework == "transformers"
    assert meta.extra == {"note": "warmup"}


# --- TrainingMonitor context manager ---

@patch("cognitor.cognitor.DatabaseManager")
def test_train_monitor_basic(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")

    with cognitor.train() as t:
        t.epoch = 1
        t.step = 10
        t.train_loss = 0.8

    metadata = cognitor.get_last_training_metadata()
    assert metadata is not None
    assert metadata["model_name"] == "test-model"
    assert metadata["epoch"] == 1
    assert metadata["step"] == 10
    assert metadata["train_loss"] == pytest.approx(0.8)
    assert metadata["duration"] >= 0
    assert "cpu_percent" in metadata
    assert "ram_usage_percent" in metadata


@patch("cognitor.cognitor.DatabaseManager")
def test_train_monitor_all_metrics(mock_db_manager):
    cognitor = Cognitor(model_name="test-model", framework="transformers")

    with cognitor.train() as t:
        t.epoch = 3
        t.step = 500
        t.train_loss = 0.25
        t.val_loss = 0.30
        t.learning_rate = 5e-5
        t.gradient_norm = 1.1
        t.samples_per_second = 64.0
        t.extra = {"optimizer": "adamw"}

    metadata = cognitor.get_last_training_metadata()
    assert metadata["val_loss"] == pytest.approx(0.30)
    assert metadata["learning_rate"] == pytest.approx(5e-5)
    assert metadata["gradient_norm"] == pytest.approx(1.1)
    assert metadata["samples_per_second"] == pytest.approx(64.0)
    assert metadata["framework"] == "transformers"
    assert metadata["extra"]["optimizer"] == "adamw"


@patch("cognitor.cognitor.DatabaseManager")
def test_train_monitor_resource_metrics(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")

    with cognitor.train() as t:
        t.step = 1

    metadata = cognitor.get_last_training_metadata()
    assert "cpu_delta" in metadata
    assert "ram_delta" in metadata
    assert metadata["device_name"] is not None


@patch("cognitor.cognitor.DatabaseManager")
def test_get_last_training_metadata_none_before_train(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")
    assert cognitor.get_last_training_metadata() is None


@patch("cognitor.cognitor.DatabaseManager")
def test_train_monitor_file_logging(mock_db_manager, tmp_path):
    inference_log = tmp_path / "inf.jsonl"
    training_log = tmp_path / "train.jsonl"
    cognitor = Cognitor(
        model_name="test-model",
        log_type="file",
        log_path=str(inference_log),
        training_log_path=str(training_log),
    )

    with cognitor.train() as t:
        t.epoch = 2
        t.train_loss = 0.5

    assert training_log.exists()
    assert not inference_log.exists()

    with open(training_log) as f:
        data = json.loads(f.readline())
    assert data["model_name"] == "test-model"
    assert data["epoch"] == 2
    assert data["train_loss"] == pytest.approx(0.5)


def test_file_logging_separates_inference_and_training(tmp_path):
    inference_log = tmp_path / "inf.jsonl"
    training_log = tmp_path / "train.jsonl"
    cognitor = Cognitor(
        model_name="test-model",
        log_type="file",
        log_path=str(inference_log),
        training_log_path=str(training_log),
    )

    with cognitor.monitor() as m:
        with m.track():
            pass
        m.capture(input_data="hello", output="world")

    with cognitor.train() as t:
        t.train_loss = 0.3

    assert inference_log.exists()
    assert training_log.exists()

    with open(inference_log) as f:
        inf_data = json.loads(f.readline())
    with open(training_log) as f:
        train_data = json.loads(f.readline())

    assert "input_tokens" in inf_data
    assert "train_loss" in train_data
    assert "input_tokens" not in train_data
    assert "train_loss" not in inf_data


# --- TrainingLog database model ---

def test_training_log_columns():
    columns = {col.name: col for col in TrainingLog.__table__.columns}
    required = {
        "id", "model_name", "timestamp", "training_run_id", "epoch", "step",
        "train_loss", "val_loss", "learning_rate", "gradient_norm",
        "samples_per_second", "duration", "cpu_percent", "ram_usage_percent",
        "cpu_delta", "ram_delta", "gpu_usage_percent", "gpu_memory_reserved_mb",
        "gpu_memory_allocated_mb", "gpu_utilization_percent",
        "quantization", "device_name", "framework", "extra",
    }
    assert required.issubset(columns.keys())


def test_training_log_id_is_primary_key():
    columns = {col.name: col for col in TrainingLog.__table__.columns}
    assert columns["id"].primary_key is True


# --- LoggingService training methods ---

@patch("cognitor.service.TrainingLog")
def test_log_training_to_db_success(mock_training_log):
    mock_db_manager = MagicMock()
    mock_db_manager._initialized = True
    mock_session = MagicMock()
    mock_db_manager.Session.return_value = mock_session

    service = LoggingService(db_manager=mock_db_manager)
    service.log_training(SAMPLE_TRAINING_METADATA)

    mock_training_log.assert_called_once()
    mock_session.add.assert_called_once()
    mock_session.commit.assert_called_once()
    mock_session.close.assert_called_once()


@patch("cognitor.service.TrainingLog")
def test_log_training_to_db_fields(mock_training_log):
    mock_db_manager = MagicMock()
    mock_db_manager._initialized = True
    mock_session = MagicMock()
    mock_db_manager.Session.return_value = mock_session

    service = LoggingService(db_manager=mock_db_manager)
    service.log_training(SAMPLE_TRAINING_METADATA)

    _, kwargs = mock_training_log.call_args
    assert kwargs["epoch"] == 1
    assert kwargs["step"] == 100
    assert kwargs["train_loss"] == pytest.approx(0.42)
    assert kwargs["val_loss"] == pytest.approx(0.55)
    assert kwargs["learning_rate"] == pytest.approx(1e-4)
    assert kwargs["gradient_norm"] == pytest.approx(0.9)
    assert kwargs["samples_per_second"] == pytest.approx(32.5)
    assert kwargs["framework"] == "transformers"
    assert json.loads(kwargs["extra"]) == {"note": "warmup"}


@patch("cognitor.service.TrainingLog")
def test_log_training_to_db_failure(mock_training_log):
    mock_db_manager = MagicMock()
    mock_db_manager._initialized = True
    mock_session = MagicMock()
    mock_db_manager.Session.return_value = mock_session
    mock_session.commit.side_effect = Exception("DB error")

    service = LoggingService(db_manager=mock_db_manager)
    service.log_training(SAMPLE_TRAINING_METADATA)

    mock_session.rollback.assert_called_once()
    mock_session.close.assert_called_once()


def test_log_training_to_file_success(tmp_path):
    training_log = tmp_path / "training.jsonl"
    service = LoggingService(training_log_file=str(training_log))
    service.log_training(SAMPLE_TRAINING_METADATA)

    assert training_log.exists()
    with open(training_log) as f:
        data = json.loads(f.read())
    assert data["model_name"] == "test-model"
    assert data["train_loss"] == pytest.approx(0.42)
    assert data["epoch"] == 1


def test_log_training_to_file_not_written_without_training_log_file(tmp_path):
    inference_log = tmp_path / "inf.jsonl"
    service = LoggingService(log_file=str(inference_log))
    service.log_training(SAMPLE_TRAINING_METADATA)
    # training_log_file not set — no training file should be created
    assert not list(tmp_path.glob("*.jsonl")) or not any(
        "train" in f.name for f in tmp_path.glob("*.jsonl")
    )


@patch("builtins.open")
def test_log_training_to_file_failure(mock_open):
    mock_open.side_effect = Exception("File error")
    service = LoggingService(training_log_file="train.jsonl")
    service.log_training(SAMPLE_TRAINING_METADATA)  # should not raise


# --- training_run_id grouping ---

@patch("cognitor.cognitor.DatabaseManager")
def test_new_training_run_returns_uuid(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")
    run_id = cognitor.new_training_run()
    import re
    assert re.match(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", run_id)


@patch("cognitor.cognitor.DatabaseManager")
def test_new_training_run_stored_on_cognitor(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")
    run_id = cognitor.new_training_run()
    assert cognitor._training_run_id == run_id


@patch("cognitor.cognitor.DatabaseManager")
def test_train_steps_share_training_run_id(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")
    run_id = cognitor.new_training_run()

    run_ids = []
    for epoch in range(3):
        with cognitor.train() as t:
            t.epoch = epoch
            t.train_loss = 0.5 - epoch * 0.1
        run_ids.append(cognitor.get_last_training_metadata()["training_run_id"])

    assert all(rid == run_id for rid in run_ids)


@patch("cognitor.cognitor.DatabaseManager")
def test_new_training_run_generates_different_ids(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")
    id1 = cognitor.new_training_run()
    id2 = cognitor.new_training_run()
    assert id1 != id2


@patch("cognitor.cognitor.DatabaseManager")
def test_training_run_id_none_without_new_training_run(mock_db_manager):
    cognitor = Cognitor(model_name="test-model")
    with cognitor.train() as t:
        t.epoch = 1
    metadata = cognitor.get_last_training_metadata()
    assert metadata["training_run_id"] is None


@patch("cognitor.service.TrainingLog")
def test_log_training_to_db_passes_training_run_id(mock_training_log):
    mock_db_manager = MagicMock()
    mock_db_manager._initialized = True
    mock_session = MagicMock()
    mock_db_manager.Session.return_value = mock_session

    service = LoggingService(db_manager=mock_db_manager)
    service.log_training(SAMPLE_TRAINING_METADATA)

    _, kwargs = mock_training_log.call_args
    assert kwargs["training_run_id"] == "abc123"
