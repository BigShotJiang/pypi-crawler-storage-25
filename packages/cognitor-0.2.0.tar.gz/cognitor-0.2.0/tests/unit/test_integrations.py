import pytest
from unittest.mock import MagicMock
from cognitor.integrations.transformers import HFTrainingCallback


def _make_args(batch_size: int = 16, grad_accum: int = 1) -> MagicMock:
    args = MagicMock()
    args.per_device_train_batch_size = batch_size
    args.gradient_accumulation_steps = grad_accum
    return args


def _make_state(epoch: float = 1.0, global_step: int = 100) -> MagicMock:
    state = MagicMock()
    state.epoch = epoch
    state.global_step = global_step
    return state


def _make_callback_with_ctx() -> tuple[HFTrainingCallback, MagicMock, MagicMock]:
    """Returns (callback, mock_cognitor, mock_train_ctx)."""
    mock_cognitor = MagicMock()
    mock_train_ctx = MagicMock()
    mock_cognitor.train.return_value.__enter__ = MagicMock(return_value=mock_train_ctx)
    mock_cognitor.train.return_value.__exit__ = MagicMock(return_value=False)
    return HFTrainingCallback(mock_cognitor), mock_cognitor, mock_train_ctx


# --- on_step_begin / on_step_end ---

def test_step_begin_records_start_time():
    callback, _, _ = _make_callback_with_ctx()
    assert callback._step_start_time is None
    callback.on_step_begin(_make_args(), _make_state(), MagicMock())
    assert callback._step_start_time is not None


def test_step_end_records_duration_and_clears_start():
    callback, _, _ = _make_callback_with_ctx()
    callback.on_step_begin(_make_args(), _make_state(), MagicMock())
    callback.on_step_end(_make_args(), _make_state(), MagicMock())
    assert callback._last_step_duration is not None
    assert callback._last_step_duration >= 0
    assert callback._step_start_time is None


def test_step_end_without_step_begin_is_safe():
    callback, _, _ = _make_callback_with_ctx()
    callback.on_step_end(_make_args(), _make_state(), MagicMock())
    assert callback._last_step_duration is None


# --- on_log ---

def test_on_log_records_all_metrics():
    callback, mock_cognitor, mock_train_ctx = _make_callback_with_ctx()
    callback._last_step_duration = 0.5

    logs = {"loss": 0.42, "learning_rate": 1e-4, "grad_norm": 0.9}
    callback.on_log(_make_args(batch_size=16, grad_accum=2), _make_state(epoch=2.0, global_step=200), MagicMock(), logs=logs)

    mock_cognitor.train.assert_called_once()
    assert mock_train_ctx.epoch == 2
    assert mock_train_ctx.step == 200
    assert mock_train_ctx.train_loss == pytest.approx(0.42)
    assert mock_train_ctx.learning_rate == pytest.approx(1e-4)
    assert mock_train_ctx.gradient_norm == pytest.approx(0.9)
    # effective_batch = 16 * 2 = 32; duration = 0.5 → 64.0 samples/s
    assert mock_train_ctx.samples_per_second == pytest.approx(64.0)


def test_on_log_skips_when_logs_is_none():
    callback, mock_cognitor, _ = _make_callback_with_ctx()
    callback.on_log(_make_args(), _make_state(), MagicMock(), logs=None)
    mock_cognitor.train.assert_not_called()


def test_on_log_skips_when_no_loss_key():
    callback, mock_cognitor, _ = _make_callback_with_ctx()
    callback.on_log(_make_args(), _make_state(), MagicMock(), logs={"eval_loss": 0.3})
    mock_cognitor.train.assert_not_called()


def test_on_log_samples_per_second_none_when_no_duration():
    callback, _, mock_train_ctx = _make_callback_with_ctx()
    # _last_step_duration is None
    callback.on_log(_make_args(), _make_state(), MagicMock(), logs={"loss": 0.5})
    assert mock_train_ctx.samples_per_second is None


def test_on_log_epoch_none_when_state_epoch_is_none():
    callback, _, mock_train_ctx = _make_callback_with_ctx()
    state = _make_state()
    state.epoch = None
    callback.on_log(_make_args(), state, MagicMock(), logs={"loss": 0.3})
    assert mock_train_ctx.epoch is None


def test_on_log_missing_optional_fields_are_none():
    callback, _, mock_train_ctx = _make_callback_with_ctx()
    # Only "loss" present, no learning_rate or grad_norm
    callback.on_log(_make_args(), _make_state(), MagicMock(), logs={"loss": 0.7})
    assert mock_train_ctx.learning_rate is None
    assert mock_train_ctx.gradient_norm is None


# --- on_evaluate ---

def test_on_evaluate_records_val_loss():
    callback, mock_cognitor, mock_train_ctx = _make_callback_with_ctx()
    metrics = {"eval_loss": 0.55, "eval_accuracy": 0.9}
    callback.on_evaluate(_make_args(), _make_state(epoch=3.0, global_step=300), MagicMock(), metrics=metrics)

    mock_cognitor.train.assert_called_once()
    assert mock_train_ctx.epoch == 3
    assert mock_train_ctx.step == 300
    assert mock_train_ctx.val_loss == pytest.approx(0.55)


def test_on_evaluate_skips_when_metrics_is_none():
    callback, mock_cognitor, _ = _make_callback_with_ctx()
    callback.on_evaluate(_make_args(), _make_state(), MagicMock(), metrics=None)
    mock_cognitor.train.assert_not_called()


def test_on_evaluate_skips_when_no_eval_loss():
    callback, mock_cognitor, _ = _make_callback_with_ctx()
    callback.on_evaluate(_make_args(), _make_state(), MagicMock(), metrics={"eval_accuracy": 0.9})
    mock_cognitor.train.assert_not_called()


def test_on_evaluate_epoch_none_when_state_epoch_is_none():
    callback, _, mock_train_ctx = _make_callback_with_ctx()
    state = _make_state()
    state.epoch = None
    callback.on_evaluate(_make_args(), state, MagicMock(), metrics={"eval_loss": 0.4})
    assert mock_train_ctx.epoch is None


# --- import alias ---

def test_importable_from_top_level():
    from cognitor import HFTrainingCallback as CB
    assert CB is HFTrainingCallback
