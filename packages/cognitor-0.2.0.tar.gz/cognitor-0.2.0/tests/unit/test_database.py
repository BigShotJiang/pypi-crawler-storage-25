import pytest
from unittest.mock import MagicMock, patch
from cognitor.database import DatabaseManager, InferenceLog, InferenceError

@patch("cognitor.database.create_engine")
@patch("cognitor.database.sessionmaker")
def test_database_manager_init(mock_sessionmaker, mock_create_engine):
    db_manager = DatabaseManager(
        host="test_host",
        port=9999,
        user="test_user",
        password="test_password",
        dbname="test_db"
    )
    
    assert db_manager.db_url == "postgresql://test_user:test_password@test_host:9999/test_db"
    mock_create_engine.assert_called_once_with(db_manager.db_url)
    mock_sessionmaker.assert_called_once_with(db_manager.engine)
    assert db_manager._initialized is False

@patch("cognitor.database.Base.metadata.create_all")
@patch("cognitor.database.create_engine")
@patch("cognitor.database.sessionmaker")
def test_init_db_success(mock_sessionmaker, mock_create_engine, mock_create_all):
    db_manager = DatabaseManager()
    db_manager.init_db()
    
    mock_create_all.assert_called_once_with(db_manager.engine)
    assert db_manager._initialized is True

@patch("cognitor.database.logger")
@patch("cognitor.database.Base.metadata.create_all")
@patch("cognitor.database.create_engine")
@patch("cognitor.database.sessionmaker")
def test_init_db_failure(mock_sessionmaker, mock_create_engine, mock_create_all, mock_logger):
    mock_create_all.side_effect = Exception("Connection failed")
    
    db_manager = DatabaseManager(password="secret_pass")
    
    # Should NOT raise SystemExit or any other exception
    db_manager.init_db()
    
    assert db_manager._initialized is False
    
    # Verify logger was called
    mock_logger.error.assert_called_once()
    mock_logger.warning.assert_called_once_with("WARNING: Unable to log traces to the database. Please check your database connection.")

def test_inference_error_model_columns():
    columns = {col.name: col for col in InferenceError.__table__.columns}
    assert "id" in columns
    assert "inference_log_id" in columns
    assert "error_message" in columns
    assert "exception_type" in columns
    assert columns["inference_log_id"].nullable is False
    assert columns["inference_log_id"].unique is True

def test_inference_error_fk_references_inference_logs():
    fk = next(iter(InferenceError.__table__.c.inference_log_id.foreign_keys))
    assert fk.target_fullname == "inference_logs.id"

def test_inference_log_has_no_error_columns():
    column_names = {col.name for col in InferenceLog.__table__.columns}
    assert "error" not in column_names
    assert "exception_type" not in column_names
