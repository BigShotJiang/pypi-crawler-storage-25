import pytest
from transformers import pipeline, AutoTokenizer
from cognitor import Cognitor
from unittest.mock import patch

@patch("cognitor.monitor.DatabaseManager")
def test_text_classification_pipeline(mock_db_manager, tmp_path):
    model_name = "distilbert-base-uncased-finetuned-sst-2-english"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    # Use 'text-classification' which is the standard name for sentiment-analysis
    pipe = pipeline("text-classification", model=model_name, tokenizer=tokenizer)
    
    cognitor = Cognitor(model_name=model_name, tokenizer=tokenizer)
    
    input_text = "I love this library!"
    with cognitor.monitor() as m:
        with m.track():
            output = pipe(input_text)
        m.capture(input_data=input_text, output=output)
    
    assert output is not None
    metadata = cognitor.get_last_metadata()
    assert metadata["model_name"] == model_name
    assert metadata["input_tokens"] > 0
    assert metadata["duration"] > 0

@patch("cognitor.monitor.DatabaseManager")
def test_text_generation_pipeline(mock_db_manager, tmp_path):
    model_name = "gpt2"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    pipe = pipeline("text-generation", model=model_name, tokenizer=tokenizer)
    
    cognitor = Cognitor(model_name=model_name, tokenizer=tokenizer)
    
    input_text = "Once upon a time,"
    with cognitor.monitor() as m:
        with m.track():
            output = pipe(input_text, max_length=10, do_sample=False)
        m.capture(input_data=input_text, output=output)
    
    assert output is not None
    metadata = cognitor.get_last_metadata()
    assert metadata["model_name"] == model_name
    assert metadata["input_tokens"] > 0
    assert metadata["output_tokens"] > 0
    assert metadata["duration"] > 0
