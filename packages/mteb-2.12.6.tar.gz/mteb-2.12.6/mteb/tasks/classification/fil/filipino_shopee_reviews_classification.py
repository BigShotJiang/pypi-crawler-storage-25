from mteb.abstasks.classification import AbsTaskClassification
from mteb.abstasks.task_metadata import TaskMetadata


class FilipinoShopeeReviewsClassification(AbsTaskClassification):
    metadata = TaskMetadata(
        name="FilipinoShopeeReviewsClassification",
        description="The Shopee reviews tl 15 dataset is constructed by randomly taking 2100 training samples and 450 samples for testing and validation for each review star from 1 to 5. In total, there are 10500 training samples and 2250 each in validation and testing samples.",
        reference="https://uijrt.com/articles/v4/i8/UIJRTV4I80009.pdf",
        dataset={
            "path": "mteb/FilipinoShopeeReviewsClassification",
            "revision": "c88a93f50ccbb36878cde3362cefd65e43bd6b75",
        },
        type="Classification",
        task_subtypes=["Sentiment/Hate speech"],
        category="t2c",
        modalities=["text"],
        eval_splits=["validation", "test"],
        eval_langs=["fil-Latn"],
        domains=["Social", "Written"],
        license="mpl-2.0",
        annotations_creators="human-annotated",
        dialect=[],
        sample_creation="found",
        date=("2022-05-13", "2023-05-13"),
        main_score="accuracy",
        bibtex_citation=r"""
@article{riegoenhancement,
  author = {Riego, Neil Christian R. and Villarba, Danny Bell and Sison, Ariel Antwaun Rolando C. and Pineda, Fernandez C. and Lagunzad, Herminiño C.},
  issue = {08},
  journal = {United International Journal for Research & Technology},
  pages = {72--82},
  title = {Enhancement to Low-Resource Text Classification via Sequential Transfer Learning},
  volume = {04},
}
""",
    )
