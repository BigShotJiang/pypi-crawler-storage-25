"""Host-level HiveFrame config (~/.hiveframe/config.yaml)."""

from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


_HOME_CONFIG = Path.home() / ".hiveframe" / "config.yaml"
_CWD_CONFIG = Path("config.yaml")  # evaluated at call time, not import time


class HiveframeSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="HIVEFRAME_",
        env_file=".env",
        extra="ignore",
    )

    proxmox_host: str = Field(..., description="Proxmox host IP or hostname")
    proxmox_user: str = Field(default="root@pam")
    proxmox_token_id: str = Field(..., description="API token ID (e.g. 'hiveframe')")
    proxmox_token_secret: SecretStr = Field(..., description="API token secret")
    proxmox_verify_ssl: bool = Field(default=False)

    @field_validator("proxmox_host")
    @classmethod
    def strip_scheme(cls, v: str) -> str:
        return v.removeprefix("https://").removeprefix("http://").rstrip("/")


def resolve_config_path(explicit: Path | None = None) -> Path:
    """Return the config path that will be used, in priority order:
    1. Explicit path passed by caller
    2. ~/.hiveframe/config.yaml
    3. ./config.yaml (CWD fallback)
    Returns the first path that exists, or the home path as the canonical
    missing-file target so error messages point somewhere useful.
    """
    if explicit is not None:
        return explicit
    if _HOME_CONFIG.exists():
        return _HOME_CONFIG
    cwd_cfg = Path.cwd() / "config.yaml"
    if cwd_cfg.exists():
        return cwd_cfg
    return _HOME_CONFIG


def load_settings(path: Path | None = None) -> HiveframeSettings:
    """Load settings from YAML, then layer env vars on top.

    Raises FileNotFoundError with a clear message if no config file is found
    and no env vars supply the required fields.
    """
    cfg_path = resolve_config_path(path)

    if not cfg_path.exists():
        raise FileNotFoundError(
            f"No config file found at {cfg_path}\n"
            f"Run: hiveframe config init\n"
            f"Or set HIVEFRAME_PROXMOX_HOST / HIVEFRAME_PROXMOX_TOKEN_ID / "
            f"HIVEFRAME_PROXMOX_TOKEN_SECRET environment variables."
        )

    with cfg_path.open() as fh:
        data: dict = yaml.safe_load(fh) or {}

    return HiveframeSettings(**data)


def write_default_config(path: Path | None = None) -> Path:
    """Write a template config file if none exists. Returns the path."""
    cfg_path = path or _HOME_CONFIG
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    if cfg_path.exists():
        return cfg_path
    template = {
        "proxmox_host": "10.0.20.1",
        "proxmox_user": "root@pam",
        "proxmox_token_id": "hiveframe",
        "proxmox_token_secret": "REPLACE_ME",
        "proxmox_verify_ssl": False,
    }
    with cfg_path.open("w") as fh:
        yaml.safe_dump(template, fh, sort_keys=False)
    return cfg_path
