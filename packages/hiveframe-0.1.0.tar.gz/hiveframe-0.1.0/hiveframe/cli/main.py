"""HiveFrame CLI entry point."""

from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

console = Console(legacy_windows=False)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_stack(file: str):
    from hiveframe.models import Stack
    try:
        return Stack.from_yaml(file)
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Failed to load {file}: {exc}")
        raise SystemExit(1) from exc


def _make_client(debug: bool = False):
    from hiveframe.api.client import ProxmoxClient
    from hiveframe.config.settings import load_settings, resolve_config_path
    try:
        cfg_path = resolve_config_path()
        if debug:
            console.print(f"[dim]config: {cfg_path.resolve()}[/dim]")
        settings = load_settings(cfg_path)
        return ProxmoxClient(settings)
    except FileNotFoundError as exc:
        console.print(f"[red]FAIL[/red] Config not found: {exc}")
        raise SystemExit(1) from exc
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Cannot connect to Proxmox: {exc}")
        raise SystemExit(1) from exc


def _vlan_table(title: str, rows: list) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("Action", style="bold")
    t.add_column("VLAN ID", justify="right")
    t.add_column("Bridge")
    t.add_column("CIDR")
    t.add_column("Detail", style="dim")
    for action, vlan_id, bridge, cidr, detail, colour in rows:
        t.add_row(
            f"[{colour}]{action}[/{colour}]",
            str(vlan_id), bridge, cidr, detail,
        )
    return t


def _vm_table(title: str, rows: list) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("Action", style="bold")
    t.add_column("VM Name")
    t.add_column("VMID", justify="right")
    t.add_column("VLAN")
    t.add_column("Detail", style="dim")
    for action, name, vmid, vlan, detail, colour in rows:
        t.add_row(
            f"[{colour}]{action}[/{colour}]",
            name, str(vmid) if vmid is not None else "-", vlan, detail,
        )
    return t


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------

@click.group()
@click.version_option(package_name="hiveframe")
@click.option("--debug", is_flag=True, default=False, help="Print config path and extra diagnostics")
@click.pass_context
def cli(ctx: click.Context, debug: bool) -> None:
    """HiveFrame -- Proxmox automation toolkit."""
    ctx.ensure_object(dict)
    ctx.obj["debug"] = debug


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--name", "-n", required=True, help="Stack name")
@click.option("--file", "-f", default="stack.yaml", show_default=True)
@click.option("--force", is_flag=True, help="Overwrite if file already exists")
def init(name: str, file: str, force: bool) -> None:
    """Scaffold a new stack.yaml in the current directory."""
    import yaml

    out = Path(file)
    if out.exists() and not force:
        console.print(f"[red]FAIL[/red] {file} already exists. Use [bold]--force[/bold] to overwrite.")
        raise SystemExit(1)

    template = {
        "name": name,
        "description": "",
        "node": "pve",
        "vlans": [
            {"name": "mgmt", "vlan_id": 10, "cidr": "192.168.10.0/24",
             "gateway": "192.168.10.1", "description": "Management"},
        ],
        "vms": [],
    }

    out.write_text(yaml.safe_dump(template, sort_keys=False, allow_unicode=True))
    console.print(f"[green]OK[/green] Created [bold]{file}[/bold] for stack [bold]{name}[/bold]")
    console.print(f"  Edit it, then run: [bold]hiveframe validate -f {file}[/bold]")


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True)
def validate(file: str) -> None:
    """Validate a stack.yaml against the schema."""
    stack = _load_stack(file)
    console.print(f"[green]OK[/green] {file} is valid -- stack [bold]{stack.name}[/bold]")
    console.print(f"  VLANs : {len(stack.vlans)}")
    console.print(f"  VMs   : {len(stack.vms)}")


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True)
@click.pass_context
def plan(ctx: click.Context, file: str) -> None:
    """Dry-run -- show what would be provisioned."""
    from hiveframe.provision.engine import ProvisionEngine

    stack = _load_stack(file)
    client = _make_client(debug=ctx.obj.get("debug", False))
    engine = ProvisionEngine(stack, client)

    try:
        vlan_actions = engine.plan_vlans()
        vm_actions = engine.plan_vms()
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Plan failed: {exc}")
        raise SystemExit(1) from exc

    # VLAN table
    vlan_rows = []
    for a in vlan_actions:
        colour = "green" if a.action == "CREATE" else "yellow"
        vlan_rows.append((a.action, a.vlan.vlan_id, a.bridge_name, a.vlan.cidr, a.reason, colour))
    console.print(_vlan_table(f"Plan -- VLANs ({stack.name})", vlan_rows))

    # VM table
    vm_rows = []
    for a in vm_actions:
        colour = "green" if a.action == "CREATE" else "yellow"
        vm_rows.append((a.action, a.vm.name, None, a.vm.vlan, a.reason, colour))
    if vm_rows:
        console.print(_vm_table(f"Plan -- VMs ({stack.name})", vm_rows))

    vlan_creates = sum(1 for a in vlan_actions if a.action == "CREATE")
    vm_creates = sum(1 for a in vm_actions if a.action == "CREATE")
    console.print(
        f"\n  VLANs: [bold]{vlan_creates}[/bold] to create, "
        f"[bold]{len(vlan_actions) - vlan_creates}[/bold] to skip"
    )
    console.print(
        f"  VMs:   [bold]{vm_creates}[/bold] to create, "
        f"[bold]{len(vm_actions) - vm_creates}[/bold] to skip"
    )


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True)
@click.pass_context
def apply(ctx: click.Context, file: str) -> None:
    """Provision the stack against the live Proxmox host."""
    from hiveframe.provision.engine import ProvisionEngine

    stack = _load_stack(file)
    client = _make_client(debug=ctx.obj.get("debug", False))
    engine = ProvisionEngine(stack, client)
    stack_yaml = Path(file)

    console.print(f"Applying stack [bold]{stack.name}[/bold]...")

    # --- VLANs ---
    try:
        vlan_results = engine.apply_vlans(stack_yaml)
    except Exception as exc:
        console.print(f"[red]FAIL[/red] VLAN apply failed: {exc}")
        raise SystemExit(1) from exc

    vlan_rows = []
    for r in vlan_results:
        colour = {"CREATED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
        vlan_rows.append((r.outcome, r.vlan.vlan_id, r.bridge_name, r.vlan.cidr, r.reason, colour))
    console.print(_vlan_table(f"Apply -- VLANs ({stack.name})", vlan_rows))

    if any(r.outcome == "FAILED" for r in vlan_results):
        console.print("[red]FAIL[/red] VLAN provisioning had failures -- skipping VMs.")
        raise SystemExit(1)

    # --- VMs ---
    if stack.vms:
        try:
            vm_results = engine.apply_vms(stack_yaml)
        except Exception as exc:
            console.print(f"[red]FAIL[/red] VM apply failed: {exc}")
            raise SystemExit(1) from exc

        vm_rows = []
        for r in vm_results:
            colour = {"CREATED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
            vm_rows.append((r.outcome, r.vm.name, r.vmid, r.vm.vlan, r.reason, colour))
        console.print(_vm_table(f"Apply -- VMs ({stack.name})", vm_rows))

        if any(r.outcome == "FAILED" for r in vm_results):
            console.print("[red]FAIL[/red] VM provisioning had failures.")
            raise SystemExit(1)

    console.print("\n[green]OK[/green] State written to .hiveframe-state.json")


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True)
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def destroy(ctx: click.Context, file: str, yes: bool) -> None:
    """Tear down a previously applied stack (VMs first, then VLANs)."""
    from hiveframe.provision.engine import ProvisionEngine

    stack = _load_stack(file)

    if not yes:
        click.confirm(f"Destroy all resources in stack '{stack.name}'?", abort=True)

    client = _make_client(debug=ctx.obj.get("debug", False))
    engine = ProvisionEngine(stack, client)
    stack_yaml = Path(file)

    # --- VMs first ---
    if stack.vms:
        try:
            vm_results = engine.destroy_vms(stack_yaml)
        except Exception as exc:
            console.print(f"[red]FAIL[/red] VM destroy failed: {exc}")
            raise SystemExit(1) from exc

        if vm_results:
            vm_rows = []
            for r in vm_results:
                colour = {"CREATED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
                label = "DELETED" if r.outcome == "CREATED" else r.outcome
                vm_rows.append((label, r.vm.name, r.vmid, r.vm.vlan, r.reason, colour))
            console.print(_vm_table(f"Destroy -- VMs ({stack.name})", vm_rows))

        if any(r.outcome == "FAILED" for r in vm_results):
            console.print("[red]FAIL[/red] VM destroy had failures -- skipping VLAN teardown.")
            raise SystemExit(1)

    # --- VLANs second ---
    try:
        vlan_results = engine.destroy_vlans(stack_yaml)
    except Exception as exc:
        console.print(f"[red]FAIL[/red] VLAN destroy failed: {exc}")
        raise SystemExit(1) from exc

    vlan_rows = []
    for r in vlan_results:
        colour = {"CREATED": "green", "SKIPPED": "yellow", "FAILED": "red"}[r.outcome]
        label = "DELETED" if r.outcome == "CREATED" else r.outcome
        vlan_rows.append((label, r.vlan.vlan_id, r.bridge_name, r.vlan.cidr, r.reason, colour))
    console.print(_vlan_table(f"Destroy -- VLANs ({stack.name})", vlan_rows))

    if any(r.outcome == "FAILED" for r in vlan_results):
        console.print("[red]FAIL[/red] VLAN destroy had failures.")
        raise SystemExit(1)


@cli.command()
@click.option("--file", "-f", default="stack.yaml", show_default=True)
@click.pass_context
def status(ctx: click.Context, file: str) -> None:
    """Show current stack state vs live Proxmox."""
    from hiveframe.provision.engine import ProvisionEngine
    from hiveframe.provision.state import load_state

    stack_yaml = Path(file)
    state = load_state(stack_yaml)
    if not state:
        console.print("[yellow]No state found -- run hiveframe apply first.[/yellow]")
        return

    stack = _load_stack(file)
    client = _make_client(debug=ctx.obj.get("debug", False))
    engine = ProvisionEngine(stack, client)

    try:
        vlan_results, vm_results = engine.check_status(stack_yaml)
    except Exception as exc:
        console.print(f"[red]FAIL[/red] Status check failed: {exc}")
        raise SystemExit(1) from exc

    # VLAN table
    vlan_table = Table(title=f"Status -- VLANs ({state.stack_name})", show_lines=False)
    vlan_table.add_column("VLAN ID", justify="right")
    vlan_table.add_column("Bridge")
    vlan_table.add_column("CIDR", style="dim")
    vlan_table.add_column("Status", style="bold")

    for r in vlan_results:
        vlan_cfg = next((v for v in stack.vlans if v.vlan_id == r.vlan_state.vlan_id), None)
        cidr = vlan_cfg.cidr if vlan_cfg else "-"
        colour = "green" if r.live_status == "OK" else "red"
        vlan_table.add_row(
            str(r.vlan_state.vlan_id),
            r.vlan_state.bridge,
            cidr,
            f"[{colour}]{r.live_status}[/{colour}]",
        )
    console.print(vlan_table)

    # VM table
    if vm_results:
        vm_table = Table(title=f"Status -- VMs ({state.stack_name})", show_lines=False)
        vm_table.add_column("VM Name")
        vm_table.add_column("VMID", justify="right")
        vm_table.add_column("VLAN")
        vm_table.add_column("Status", style="bold")

        for r in vm_results:
            colour = {"OK": "green", "STOPPED": "yellow", "MISSING": "red"}[r.live_status]
            vm_table.add_row(
                r.vm_state.name,
                str(r.vm_state.vmid),
                r.vm_state.vlan,
                f"[{colour}]{r.live_status}[/{colour}]",
            )
        console.print(vm_table)

    console.print(f"\n  Applied at: [dim]{state.applied_at}[/dim]")


@cli.command()
@click.option("--host", default="127.0.0.1", show_default=True, help="Bind address")
@click.option("--port", default=8080, show_default=True, type=int, help="Port")
def web(host: str, port: int) -> None:
    """Start the HiveFrame web dashboard."""
    import uvicorn
    from hiveframe.web.app import app as fastapi_app
    console.print(f"[green]OK[/green] Dashboard at [bold]http://{host}:{port}[/bold]")
    console.print("  Press Ctrl+C to stop.")
    uvicorn.run(fastapi_app, host=host, port=port, log_level="warning")
