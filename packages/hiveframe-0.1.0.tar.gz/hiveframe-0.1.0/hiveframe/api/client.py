"""Proxmox API client wrapper."""

from __future__ import annotations

import ipaddress
import time
from typing import Any
from urllib.parse import quote

from hiveframe.config.settings import HiveframeSettings
from hiveframe.models.vlan import VlanConfig
from hiveframe.models.vm import CloudInitConfig


class HiveframeAPIError(Exception):
    """Raised when a Proxmox API call fails."""

    def __init__(self, message: str, *, cause: BaseException | None = None) -> None:
        super().__init__(message)
        self.cause = cause


def _wrap(fn: Any, *args: Any, **kwargs: Any) -> Any:
    """Call a proxmoxer chain and re-raise as HiveframeAPIError on failure."""
    try:
        return fn(*args, **kwargs)
    except Exception as exc:
        raise HiveframeAPIError(str(exc), cause=exc) from exc


class ProxmoxClient:
    """Clean interface over proxmoxer.ProxmoxAPI.

    All callers (engine, CLI) must go through this class — never proxmoxer
    directly. Every method re-raises proxmoxer exceptions as HiveframeAPIError.
    """

    def __init__(self, settings: HiveframeSettings) -> None:
        self._settings = settings
        self._px = self._connect()

    def _connect(self) -> Any:
        try:
            from proxmoxer import ProxmoxAPI
        except ImportError as exc:
            raise RuntimeError("proxmoxer is not installed") from exc

        try:
            return ProxmoxAPI(
                self._settings.proxmox_host,
                user=self._settings.proxmox_user,
                token_name=self._settings.proxmox_token_id,
                token_value=self._settings.proxmox_token_secret.get_secret_value(),
                verify_ssl=self._settings.proxmox_verify_ssl,
            )
        except Exception as exc:
            raise HiveframeAPIError(
                f"Failed to connect to Proxmox at {self._settings.proxmox_host}: {exc}",
                cause=exc,
            ) from exc

    # ------------------------------------------------------------------
    # Node / cluster info
    # ------------------------------------------------------------------

    def get_nodes(self) -> list[dict]:
        return _wrap(self._px.nodes.get)

    def get_node_info(self, node: str) -> dict:
        return _wrap(self._px.nodes(node).status.get)

    # ------------------------------------------------------------------
    # Network
    # ------------------------------------------------------------------

    def get_network_config(self, node: str) -> list[dict]:
        return _wrap(self._px.nodes(node).network.get)

    def bridge_exists(self, node: str, bridge_name: str) -> bool:
        ifaces = self.get_network_config(node)
        return any(i.get("iface") == bridge_name for i in ifaces)

    def create_linux_bridge(self, node: str, vlan: VlanConfig) -> None:
        """Create a Linux bridge for the given VLAN (pending, not yet applied)."""
        net = ipaddress.ip_network(vlan.cidr, strict=False)
        netmask = str(net.netmask)

        params: dict[str, Any] = {
            "iface": vlan.bridge,
            "type": "bridge",
            "bridge_ports": "",
            "comments": vlan.description or f"HiveFrame VLAN {vlan.vlan_id}",
        }
        if vlan.gateway:
            params["address"] = vlan.gateway
            params["netmask"] = netmask

        _wrap(self._px.nodes(node).network.post, **params)

    def delete_network_iface(self, node: str, iface_name: str) -> None:
        _wrap(self._px.nodes(node).network(iface_name).delete)

    def apply_network_config(self, node: str) -> None:
        _wrap(self._px.nodes(node).network.put)

    # ------------------------------------------------------------------
    # VMs
    # ------------------------------------------------------------------

    def get_vms(self, node: str) -> list[dict]:
        """Return list of VMs on the node (each dict has vmid, name, status)."""
        return _wrap(self._px.nodes(node).qemu.get)

    def get_vm_status(self, node: str, vmid: int) -> str:
        """Return power state string ('running', 'stopped', 'paused').
        Raises HiveframeAPIError if the VM does not exist."""
        result = _wrap(self._px.nodes(node).qemu(vmid).status.current.get)
        return str(result.get("status", "unknown"))

    def get_next_vmid(self, node: str) -> int:
        """Return the next available VMID from the cluster."""
        result = _wrap(self._px.cluster.nextid.get)
        return int(result)

    def clone_vm(
        self, node: str, template_id: int, new_vmid: int, name: str
    ) -> str:
        """Clone a template VM. Returns the task UPID string."""
        result = _wrap(
            self._px.nodes(node).qemu(template_id).clone.post,
            newid=new_vmid,
            name=name,
            full=1,
        )
        return str(result)

    def resize_disk(self, node: str, vmid: int, disk: str, add_gb: int) -> None:
        """Expand a disk by add_gb gigabytes (uses '+' prefix)."""
        _wrap(
            self._px.nodes(node).qemu(vmid).resize.put,
            disk=disk,
            size=f"+{add_gb}G",
        )

    def set_cloud_init(
        self, node: str, vmid: int, cloud_init: CloudInitConfig, storage: str = "local-lvm"
    ) -> None:
        """Apply cloud-init settings to a VM. Adds ide2 cloudinit drive if absent."""
        config = _wrap(self._px.nodes(node).qemu(vmid).config.get)

        params: dict[str, Any] = {}

        if "ide2" not in config:
            params["ide2"] = f"{storage}:cloudinit"

        params["ciuser"] = cloud_init.user

        if cloud_init.password:
            params["cipassword"] = cloud_init.password

        if cloud_init.ssh_keys:
            # Proxmox requires SSH keys to be URL-encoded in the API param value
            params["sshkeys"] = quote("\n".join(cloud_init.ssh_keys), safe="")

        ipconfig = cloud_init.proxmox_ipconfig0
        if ipconfig:
            params["ipconfig0"] = ipconfig

        if cloud_init.nameservers:
            params["nameserver"] = " ".join(cloud_init.nameservers)

        if cloud_init.search_domain:
            params["searchdomain"] = cloud_init.search_domain

        _wrap(self._px.nodes(node).qemu(vmid).config.post, **params)

    def set_network(self, node: str, vmid: int, bridge: str, vlan_id: int) -> None:
        """Set net0 on a VM to the given bridge with VLAN tag."""
        _wrap(
            self._px.nodes(node).qemu(vmid).config.post,
            net0=f"virtio,bridge={bridge},tag={vlan_id}",
        )

    def start_vm(self, node: str, vmid: int) -> str:
        """Start a VM. Returns the task UPID."""
        result = _wrap(self._px.nodes(node).qemu(vmid).status.start.post)
        return str(result)

    def stop_vm(self, node: str, vmid: int) -> str:
        """Stop a VM. Returns the task UPID."""
        result = _wrap(self._px.nodes(node).qemu(vmid).status.stop.post)
        return str(result)

    def delete_vm(self, node: str, vmid: int) -> None:
        """Delete a VM permanently."""
        _wrap(self._px.nodes(node).qemu(vmid).delete)

    def wait_for_task(self, node: str, task_id: str, timeout: int = 300) -> None:
        """Poll task status every 2s until stopped or timeout. Raises on failure."""
        elapsed = 0
        while elapsed < timeout:
            status = _wrap(self._px.nodes(node).tasks(task_id).status.get)
            if status.get("status") == "stopped":
                exit_status = status.get("exitstatus", "")
                if exit_status != "OK":
                    raise HiveframeAPIError(
                        f"Task {task_id} failed with exitstatus '{exit_status}'"
                    )
                return
            time.sleep(2)
            elapsed += 2
        raise HiveframeAPIError(f"Task {task_id} timed out after {timeout}s")
