"""Provisioning engine — VLAN and VM layers."""

from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from hiveframe.api.client import HiveframeAPIError, ProxmoxClient
from hiveframe.models import Stack
from hiveframe.models.vlan import VlanConfig
from hiveframe.models.vm import VmConfig
from hiveframe.provision.state import (
    VlanState,
    VmState,
    load_state,
    merge_vlan_states,
    merge_vm_states,
    remove_vlan_states,
    remove_vm_states,
    save_state,
)

_TEMPLATE_DISK_GB = 20  # assumed template base disk size


# ---------------------------------------------------------------------------
# Status check types
# ---------------------------------------------------------------------------

@dataclass
class VlanStatusResult:
    vlan_state: VlanState
    live_status: Literal["OK", "MISSING"]


@dataclass
class VmStatusResult:
    vm_state: VmState
    live_status: Literal["OK", "STOPPED", "MISSING"]


# ---------------------------------------------------------------------------
# VLAN plan / result types
# ---------------------------------------------------------------------------

@dataclass
class PlanAction:
    action: Literal["CREATE", "SKIP"]
    vlan: VlanConfig
    bridge_name: str
    reason: str = ""


@dataclass
class ApplyResult:
    outcome: Literal["CREATED", "SKIPPED", "FAILED"]
    vlan: VlanConfig
    bridge_name: str
    reason: str = ""


# ---------------------------------------------------------------------------
# VM plan / result types
# ---------------------------------------------------------------------------

@dataclass
class VmPlanAction:
    action: Literal["CREATE", "SKIP"]
    vm: VmConfig
    reason: str = ""


@dataclass
class VmApplyResult:
    outcome: Literal["CREATED", "SKIPPED", "FAILED"]
    vm: VmConfig
    vmid: int | None = None
    reason: str = ""


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class ProvisionEngine:
    """Drives VLAN + VM provisioning against a live Proxmox node."""

    def __init__(self, stack: Stack, client: ProxmoxClient) -> None:
        self.stack = stack
        self.client = client

    def _resolve_node(self) -> str:
        if self.stack.node != "pve":
            return self.stack.node
        nodes = self.client.get_nodes()
        if not nodes:
            raise HiveframeAPIError("No nodes returned from Proxmox cluster")
        names = [n["node"] for n in nodes]
        return "pve" if "pve" in names else names[0]

    # ------------------------------------------------------------------
    # VLAN plan / apply / destroy
    # ------------------------------------------------------------------

    def plan_vlans(self, node: str | None = None) -> list[PlanAction]:
        target = node or self._resolve_node()
        actions: list[PlanAction] = []
        for vlan in self.stack.vlans:
            if self.client.bridge_exists(target, vlan.bridge):
                actions.append(PlanAction("SKIP", vlan, vlan.bridge, "bridge already exists"))
            else:
                actions.append(PlanAction("CREATE", vlan, vlan.bridge, "bridge not found"))
        return actions

    def apply_vlans(self, stack_yaml: Path, node: str | None = None) -> list[ApplyResult]:
        target = node or self._resolve_node()
        actions = self.plan_vlans(target)
        results: list[ApplyResult] = []
        created_any = False

        for action in actions:
            if action.action == "SKIP":
                results.append(ApplyResult("SKIPPED", action.vlan, action.bridge_name, action.reason))
                continue
            try:
                self.client.create_linux_bridge(target, action.vlan)
                results.append(ApplyResult("CREATED", action.vlan, action.bridge_name))
                created_any = True
            except HiveframeAPIError as exc:
                results.append(ApplyResult("FAILED", action.vlan, action.bridge_name, str(exc)))

        if created_any:
            self.client.apply_network_config(target)

        new_states = [
            VlanState(
                vlan_id=r.vlan.vlan_id,
                bridge=r.bridge_name,
                status="applied" if r.outcome in ("CREATED", "SKIPPED") else "failed",
            )
            for r in results
        ]
        existing = load_state(stack_yaml)
        save_state(stack_yaml, merge_vlan_states(existing, self.stack.name, new_states))
        return results

    def destroy_vlans(self, stack_yaml: Path, node: str | None = None) -> list[ApplyResult]:
        target = node or self._resolve_node()
        results: list[ApplyResult] = []
        deleted_any = False
        destroyed_ids: set[int] = set()

        for vlan in self.stack.vlans:
            if not self.client.bridge_exists(target, vlan.bridge):
                results.append(ApplyResult("SKIPPED", vlan, vlan.bridge, "bridge does not exist"))
                continue
            try:
                self.client.delete_network_iface(target, vlan.bridge)
                results.append(ApplyResult("CREATED", vlan, vlan.bridge, "queued for deletion"))
                deleted_any = True
                destroyed_ids.add(vlan.vlan_id)
            except HiveframeAPIError as exc:
                results.append(ApplyResult("FAILED", vlan, vlan.bridge, str(exc)))

        if deleted_any:
            self.client.apply_network_config(target)

        if destroyed_ids:
            existing = load_state(stack_yaml)
            if existing:
                save_state(stack_yaml, remove_vlan_states(existing, destroyed_ids))

        return results

    # ------------------------------------------------------------------
    # VM plan / apply / destroy
    # ------------------------------------------------------------------

    def plan_vms(self, node: str | None = None) -> list[VmPlanAction]:
        """Return what would be created/skipped for VMs — no mutations."""
        target = node or self._resolve_node()
        existing_names = {vm["name"] for vm in self.client.get_vms(target)}
        actions: list[VmPlanAction] = []
        for vm in self.stack.vms:
            if vm.name in existing_names:
                actions.append(VmPlanAction("SKIP", vm, "VM already exists"))
            else:
                actions.append(VmPlanAction("CREATE", vm, "VM not found"))
        return actions

    def apply_vms(self, stack_yaml: Path, node: str | None = None) -> list[VmApplyResult]:
        """Clone, configure, and optionally start VMs for all CREATE actions."""
        target = node or self._resolve_node()
        actions = self.plan_vms(target)
        results: list[VmApplyResult] = []

        for action in actions:
            if action.action == "SKIP":
                results.append(VmApplyResult("SKIPPED", action.vm, reason=action.reason))
                continue

            vm = action.vm
            vmid: int | None = None
            try:
                vmid = self.client.get_next_vmid(target)
                task = self.client.clone_vm(target, vm.template_id, vmid, vm.name)
                self.client.wait_for_task(target, task)

                if vm.disk_gb > _TEMPLATE_DISK_GB:
                    self.client.resize_disk(
                        target, vmid, "scsi0", vm.disk_gb - _TEMPLATE_DISK_GB
                    )

                self.client.set_cloud_init(target, vmid, vm.cloud_init, vm.storage)

                vlan = self.stack.vlan_by_name(vm.vlan)
                self.client.set_network(target, vmid, vlan.bridge, vlan.vlan_id)

                if vm.start_on_create:
                    start_task = self.client.start_vm(target, vmid)
                    self.client.wait_for_task(target, start_task)

                results.append(VmApplyResult("CREATED", vm, vmid=vmid))

            except (HiveframeAPIError, KeyError) as exc:
                results.append(VmApplyResult("FAILED", vm, vmid=vmid, reason=str(exc)))

        new_states = [
            VmState(
                name=r.vm.name,
                vmid=r.vmid or 0,
                vlan=r.vm.vlan,
                status="applied" if r.outcome == "CREATED" else "failed",
            )
            for r in results
            if r.outcome in ("CREATED", "FAILED") and r.vmid is not None
        ]
        if new_states:
            existing = load_state(stack_yaml)
            save_state(stack_yaml, merge_vm_states(existing, self.stack.name, new_states))

        return results

    def destroy_vms(self, stack_yaml: Path, node: str | None = None) -> list[VmApplyResult]:
        """Stop and delete VMs tracked in state. Reads vmids from state file."""
        target = node or self._resolve_node()
        existing = load_state(stack_yaml)

        if not existing or not existing.vms:
            return []

        stack_vm_names = {vm.name for vm in self.stack.vms}
        results: list[VmApplyResult] = []
        destroyed_names: set[str] = set()

        for vm_state in existing.vms:
            if vm_state.name not in stack_vm_names:
                continue

            vm_cfg = next((v for v in self.stack.vms if v.name == vm_state.name), None)
            if vm_cfg is None:
                continue

            try:
                try:
                    self.client.stop_vm(target, vm_state.vmid)
                except HiveframeAPIError:
                    pass  # already stopped or doesn't exist
                time.sleep(5)
                self.client.delete_vm(target, vm_state.vmid)
                results.append(VmApplyResult("CREATED", vm_cfg, vmid=vm_state.vmid))
                destroyed_names.add(vm_state.name)
            except HiveframeAPIError as exc:
                results.append(VmApplyResult("FAILED", vm_cfg, vmid=vm_state.vmid, reason=str(exc)))

        if destroyed_names:
            updated = remove_vm_states(existing, destroyed_names)
            save_state(stack_yaml, updated)

        return results

    # ------------------------------------------------------------------
    # Status check (read-only)
    # ------------------------------------------------------------------

    def check_status(
        self, stack_yaml: Path, node: str | None = None
    ) -> tuple[list[VlanStatusResult], list[VmStatusResult]]:
        """Compare state file against live Proxmox. Never mutates anything."""
        target = node or self._resolve_node()
        state = load_state(stack_yaml)

        if not state:
            return [], []

        vlan_results: list[VlanStatusResult] = []
        for vs in state.vlans:
            exists = self.client.bridge_exists(target, vs.bridge)
            vlan_results.append(VlanStatusResult(vs, "OK" if exists else "MISSING"))

        vm_results: list[VmStatusResult] = []
        for vs in state.vms:
            try:
                power = self.client.get_vm_status(target, vs.vmid)
                live = "OK" if power == "running" else "STOPPED"
            except HiveframeAPIError:
                live = "MISSING"
            vm_results.append(VmStatusResult(vs, live))

        return vlan_results, vm_results
