"""VM definition model."""

from __future__ import annotations

from pydantic import BaseModel, Field, field_validator

from hiveframe.models.firewall import FirewallRule


class CloudInitConfig(BaseModel):
    user: str = Field(default="ubuntu")
    password: str | None = Field(default=None)
    ssh_keys: list[str] = Field(default_factory=list)
    nameservers: list[str] = Field(default_factory=list)
    search_domain: str | None = Field(default=None)
    ip_config: str | None = Field(
        default=None,
        description="'dhcp', or Proxmox ipconfig0 format: 'ip=192.168.1.5/24,gw=192.168.1.1'",
    )

    @property
    def proxmox_ipconfig0(self) -> str | None:
        """Translate 'dhcp' shorthand to Proxmox ipconfig0 format."""
        if self.ip_config is None:
            return None
        if self.ip_config.strip().lower() == "dhcp":
            return "ip=dhcp"
        return self.ip_config


class VmConfig(BaseModel):
    name: str = Field(..., description="VM hostname / Proxmox VM name")
    template_id: int = Field(..., description="Proxmox VM ID of the template to clone")
    vlan: str = Field(..., description="Name of the VlanConfig to attach to")
    cores: int = Field(default=2, ge=1)
    memory_mb: int = Field(default=2048, ge=256)
    disk_gb: int = Field(default=20, ge=1, description="Total desired disk size in GB")
    storage: str = Field(default="local-lvm", description="Proxmox storage pool")
    cloud_init: CloudInitConfig = Field(default_factory=CloudInitConfig)
    firewall_rules: list[FirewallRule] = Field(default_factory=list)
    start_on_create: bool = Field(default=True)
    tags: list[str] = Field(default_factory=list)

    @field_validator("name")
    @classmethod
    def valid_hostname(cls, v: str) -> str:
        import re
        if not re.match(r"^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?$", v):
            raise ValueError(f"'{v}' is not a valid hostname")
        return v
