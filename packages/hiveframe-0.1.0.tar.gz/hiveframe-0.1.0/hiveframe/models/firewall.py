"""Firewall rule model."""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field


class RuleAction(StrEnum):
    ACCEPT = "ACCEPT"
    DROP = "DROP"
    REJECT = "REJECT"


class RuleDirection(StrEnum):
    IN = "in"
    OUT = "out"


class FirewallRule(BaseModel):
    action: RuleAction = Field(default=RuleAction.ACCEPT)
    direction: RuleDirection = Field(default=RuleDirection.IN)
    protocol: str | None = Field(default=None, description="tcp, udp, icmp, etc.")
    source: str | None = Field(default=None, description="Source IP/CIDR or alias")
    dest: str | None = Field(default=None, description="Destination IP/CIDR or alias")
    dport: str | None = Field(default=None, description="Destination port or range, e.g. '22' or '8000:8100'")
    comment: str = Field(default="")
