"""Top-level Stack model — the unit of provisioning."""

from __future__ import annotations

from enum import StrEnum
from pathlib import Path

import yaml
from pydantic import BaseModel, Field, model_validator

from hiveframe.models.vlan import VlanConfig
from hiveframe.models.vm import VmConfig


class StackStatus(StrEnum):
    PENDING = "pending"
    APPLIED = "applied"
    PARTIAL = "partial"
    DESTROYED = "destroyed"
    UNKNOWN = "unknown"


class Stack(BaseModel):
    name: str = Field(..., description="Unique stack identifier")
    description: str = Field(default="")
    node: str = Field(default="pve", description="Proxmox node name to provision on")
    vlans: list[VlanConfig] = Field(default_factory=list)
    vms: list[VmConfig] = Field(default_factory=list)

    @model_validator(mode="after")
    def vlan_refs_exist(self) -> Stack:
        defined = {v.name for v in self.vlans if v.name}
        for vm in self.vms:
            if vm.vlan not in defined:
                raise ValueError(
                    f"VM '{vm.name}' references vlan '{vm.vlan}' "
                    f"which is not defined in this stack"
                )
        return self

    @model_validator(mode="after")
    def unique_vm_names(self) -> Stack:
        names = [vm.name for vm in self.vms]
        dupes = {n for n in names if names.count(n) > 1}
        if dupes:
            raise ValueError(f"Duplicate VM names in stack: {dupes}")
        return self

    @model_validator(mode="after")
    def unique_vlan_ids(self) -> Stack:
        ids = [v.vlan_id for v in self.vlans]
        dupes = {i for i in ids if ids.count(i) > 1}
        if dupes:
            raise ValueError(f"Duplicate VLAN IDs in stack: {dupes}")
        return self

    def vlan_by_name(self, name: str) -> VlanConfig:
        for v in self.vlans:
            if v.name == name:
                return v
        raise KeyError(f"VLAN '{name}' not found in stack '{self.name}'")

    # ------------------------------------------------------------------
    # Serialisation helpers
    # ------------------------------------------------------------------

    @classmethod
    def from_yaml(cls, path: Path | str) -> Stack:
        with open(path) as fh:
            data = yaml.safe_load(fh)
        return cls.model_validate(data)

    def to_yaml(self, path: Path | str) -> None:
        with open(path, "w") as fh:
            yaml.safe_dump(self.model_dump(mode="json"), fh, sort_keys=False)
