"""Tests for VLAN provisioning — all API calls mocked."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from hiveframe.models import Stack
from hiveframe.provision.engine import ApplyResult, PlanAction, ProvisionEngine
from hiveframe.provision.state import load_state, state_path_for


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

STACK_DATA = {
    "name": "test-stack",
    "node": "pve",
    "vlans": [
        {"name": "mgmt", "vlan_id": 10, "cidr": "192.168.10.0/24", "gateway": "192.168.10.1", "description": "Mgmt"},
        {"name": "app",  "vlan_id": 20, "cidr": "192.168.20.0/24", "description": "App"},
    ],
    "vms": [],
}


@pytest.fixture()
def stack() -> Stack:
    return Stack.model_validate(STACK_DATA)


@pytest.fixture()
def mock_client() -> MagicMock:
    client = MagicMock()
    client.get_nodes.return_value = [{"node": "pve"}]
    return client


@pytest.fixture()
def engine(stack: Stack, mock_client: MagicMock) -> ProvisionEngine:
    return ProvisionEngine(stack, mock_client)


# ---------------------------------------------------------------------------
# plan_vlans
# ---------------------------------------------------------------------------

class TestPlanVlans:
    def test_create_when_bridge_missing(self, engine: ProvisionEngine, mock_client: MagicMock):
        mock_client.bridge_exists.return_value = False
        actions = engine.plan_vlans("pve")
        assert len(actions) == 2
        assert all(a.action == "CREATE" for a in actions)
        assert actions[0].bridge_name == "vmbr10"
        assert actions[1].bridge_name == "vmbr20"

    def test_skip_when_bridge_exists(self, engine: ProvisionEngine, mock_client: MagicMock):
        mock_client.bridge_exists.return_value = True
        assert all(a.action == "SKIP" for a in engine.plan_vlans("pve"))

    def test_mixed_existing_and_missing(self, engine: ProvisionEngine, mock_client: MagicMock):
        mock_client.bridge_exists.side_effect = lambda node, name: name == "vmbr10"
        actions = engine.plan_vlans("pve")
        assert actions[0].action == "SKIP" and actions[0].bridge_name == "vmbr10"
        assert actions[1].action == "CREATE" and actions[1].bridge_name == "vmbr20"

    def test_no_api_mutation_during_plan(self, engine: ProvisionEngine, mock_client: MagicMock):
        mock_client.bridge_exists.return_value = False
        engine.plan_vlans("pve")
        mock_client.create_linux_bridge.assert_not_called()
        mock_client.apply_network_config.assert_not_called()
        mock_client.delete_network_iface.assert_not_called()


# ---------------------------------------------------------------------------
# apply_vlans
# ---------------------------------------------------------------------------

class TestApplyVlans:
    def test_creates_only_missing_bridges(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        mock_client.bridge_exists.side_effect = lambda node, name: name == "vmbr10"
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()

        results = engine.apply_vlans(stack_yaml, "pve")

        skipped = [r for r in results if r.outcome == "SKIPPED"]
        created = [r for r in results if r.outcome == "CREATED"]
        assert len(skipped) == 1 and skipped[0].bridge_name == "vmbr10"
        assert len(created) == 1 and created[0].bridge_name == "vmbr20"

        mock_client.create_linux_bridge.assert_called_once()
        assert mock_client.create_linux_bridge.call_args[0][1].vlan_id == 20

    def test_apply_network_config_called_once_after_creates(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        mock_client.bridge_exists.return_value = False
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine.apply_vlans(stack_yaml, "pve")
        mock_client.apply_network_config.assert_called_once_with("pve")

    def test_apply_network_config_not_called_when_all_skipped(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        mock_client.bridge_exists.return_value = True
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine.apply_vlans(stack_yaml, "pve")
        mock_client.apply_network_config.assert_not_called()

    def test_failed_bridge_recorded_in_results(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        from hiveframe.api.client import HiveframeAPIError
        mock_client.bridge_exists.return_value = False
        mock_client.create_linux_bridge.side_effect = HiveframeAPIError("permission denied")
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        results = engine.apply_vlans(stack_yaml, "pve")
        assert all(r.outcome == "FAILED" for r in results)
        mock_client.apply_network_config.assert_not_called()


# ---------------------------------------------------------------------------
# destroy_vlans
# ---------------------------------------------------------------------------

class TestDestroyVlans:
    def test_skips_nonexistent_bridges(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        mock_client.bridge_exists.return_value = False
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        results = engine.destroy_vlans(stack_yaml, "pve")
        assert all(r.outcome == "SKIPPED" for r in results)
        mock_client.delete_network_iface.assert_not_called()
        mock_client.apply_network_config.assert_not_called()

    def test_deletes_existing_bridges(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        mock_client.bridge_exists.return_value = True
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        results = engine.destroy_vlans(stack_yaml, "pve")
        assert all(r.outcome == "CREATED" for r in results)
        assert mock_client.delete_network_iface.call_count == 2
        mock_client.apply_network_config.assert_called_once_with("pve")

    def test_partial_destroy(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        mock_client.bridge_exists.side_effect = lambda node, name: name == "vmbr10"
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        results = engine.destroy_vlans(stack_yaml, "pve")
        outcomes = {r.bridge_name: r.outcome for r in results}
        assert outcomes["vmbr10"] == "CREATED"
        assert outcomes["vmbr20"] == "SKIPPED"
        mock_client.apply_network_config.assert_called_once_with("pve")


# ---------------------------------------------------------------------------
# State sidecar
# ---------------------------------------------------------------------------

class TestStateSidecar:
    def test_state_written_after_apply(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        mock_client.bridge_exists.return_value = False
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine.apply_vlans(stack_yaml, "pve")

        state = load_state(stack_yaml)
        assert state is not None
        assert state.stack_name == "test-stack"
        assert len(state.vlans) == 2
        assert {v.vlan_id for v in state.vlans} == {10, 20}
        assert all(v.status == "applied" for v in state.vlans)

    def test_state_merges_on_second_apply(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        mock_client.bridge_exists.side_effect = lambda node, name: name == "vmbr20"
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine.apply_vlans(stack_yaml, "pve")
        mock_client.bridge_exists.return_value = False
        engine.apply_vlans(stack_yaml, "pve")
        assert len(load_state(stack_yaml).vlans) == 2

    def test_state_pruned_after_destroy(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        mock_client.bridge_exists.return_value = True
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine.apply_vlans(stack_yaml, "pve")
        engine.destroy_vlans(stack_yaml, "pve")
        assert load_state(stack_yaml).vlans == []

    def test_state_json_schema(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        mock_client.bridge_exists.return_value = False
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        engine.apply_vlans(stack_yaml, "pve")
        raw = json.loads(state_path_for(stack_yaml).read_text())
        assert {"stack_name", "applied_at", "vlans"} <= raw.keys()
        assert {"vlan_id", "bridge", "status"} <= raw["vlans"][0].keys()
