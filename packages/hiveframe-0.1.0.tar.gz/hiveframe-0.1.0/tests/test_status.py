"""Tests for hiveframe status (read-only, all API calls mocked)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from hiveframe.api.client import HiveframeAPIError
from hiveframe.models import Stack
from hiveframe.provision.engine import ProvisionEngine, VlanStatusResult, VmStatusResult
from hiveframe.provision.state import StackState, VlanState, VmState, save_state


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

STACK_DATA = {
    "name": "test-stack",
    "node": "pve",
    "vlans": [
        {"name": "mgmt", "vlan_id": 10, "cidr": "192.168.10.0/24", "gateway": "192.168.10.1"},
    ],
    "vms": [
        {"name": "vm-01", "template_id": 9000, "vlan": "mgmt", "start_on_create": False,
         "cloud_init": {"user": "ubuntu"}},
    ],
}


@pytest.fixture()
def stack() -> Stack:
    return Stack.model_validate(STACK_DATA)


@pytest.fixture()
def mock_client() -> MagicMock:
    client = MagicMock()
    client.get_nodes.return_value = [{"node": "pve"}]
    return client


@pytest.fixture()
def engine(stack: Stack, mock_client: MagicMock) -> ProvisionEngine:
    return ProvisionEngine(stack, mock_client)


def _seed_state(stack_yaml: Path, *, vlan_ids: list[int], vms: list[dict]) -> None:
    state = StackState(
        stack_name="test-stack",
        vlans=[VlanState(vlan_id=v, bridge=f"vmbr{v}", status="applied") for v in vlan_ids],
        vms=[VmState(name=v["name"], vmid=v["vmid"], vlan=v["vlan"], status="applied") for v in vms],
    )
    save_state(stack_yaml, state)


# ---------------------------------------------------------------------------
# No state file
# ---------------------------------------------------------------------------

class TestNoState:
    def test_returns_empty_when_no_state_file(
        self, engine: ProvisionEngine, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        stack_yaml.touch()
        vlan_results, vm_results = engine.check_status(stack_yaml, "pve")
        assert vlan_results == []
        assert vm_results == []


# ---------------------------------------------------------------------------
# VLAN status
# ---------------------------------------------------------------------------

class TestVlanStatus:
    def test_vlan_ok_when_bridge_exists(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml, vlan_ids=[10], vms=[])
        mock_client.bridge_exists.return_value = True

        vlan_results, _ = engine.check_status(stack_yaml, "pve")

        assert len(vlan_results) == 1
        assert vlan_results[0].live_status == "OK"
        assert vlan_results[0].vlan_state.vlan_id == 10

    def test_vlan_missing_when_bridge_gone(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml, vlan_ids=[10], vms=[])
        mock_client.bridge_exists.return_value = False

        vlan_results, _ = engine.check_status(stack_yaml, "pve")

        assert vlan_results[0].live_status == "MISSING"

    def test_multiple_vlans_mixed(
        self, tmp_path: Path
    ):
        data = {**STACK_DATA, "vlans": [
            {"name": "a", "vlan_id": 10, "cidr": "192.168.10.0/24"},
            {"name": "b", "vlan_id": 20, "cidr": "192.168.20.0/24"},
        ], "vms": []}
        stack = Stack.model_validate(data)
        client = MagicMock()
        client.get_nodes.return_value = [{"node": "pve"}]
        client.bridge_exists.side_effect = lambda node, name: name == "vmbr10"
        engine = ProvisionEngine(stack, client)

        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml, vlan_ids=[10, 20], vms=[])

        vlan_results, _ = engine.check_status(stack_yaml, "pve")

        statuses = {r.vlan_state.vlan_id: r.live_status for r in vlan_results}
        assert statuses[10] == "OK"
        assert statuses[20] == "MISSING"


# ---------------------------------------------------------------------------
# VM status
# ---------------------------------------------------------------------------

class TestVmStatus:
    def test_vm_ok_when_running(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml, vlan_ids=[10], vms=[{"name": "vm-01", "vmid": 101, "vlan": "mgmt"}])
        mock_client.bridge_exists.return_value = True
        mock_client.get_vm_status.return_value = "running"

        _, vm_results = engine.check_status(stack_yaml, "pve")

        assert vm_results[0].live_status == "OK"
        mock_client.get_vm_status.assert_called_once_with("pve", 101)

    def test_vm_stopped_when_powered_off(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml, vlan_ids=[10], vms=[{"name": "vm-01", "vmid": 101, "vlan": "mgmt"}])
        mock_client.bridge_exists.return_value = True
        mock_client.get_vm_status.return_value = "stopped"

        _, vm_results = engine.check_status(stack_yaml, "pve")

        assert vm_results[0].live_status == "STOPPED"

    def test_vm_missing_when_api_raises(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml, vlan_ids=[10], vms=[{"name": "vm-01", "vmid": 101, "vlan": "mgmt"}])
        mock_client.bridge_exists.return_value = True
        mock_client.get_vm_status.side_effect = HiveframeAPIError("500 not found")

        _, vm_results = engine.check_status(stack_yaml, "pve")

        assert vm_results[0].live_status == "MISSING"

    def test_check_status_never_mutates(
        self, engine: ProvisionEngine, mock_client: MagicMock, tmp_path: Path
    ):
        stack_yaml = tmp_path / "stack.yaml"
        _seed_state(stack_yaml, vlan_ids=[10], vms=[{"name": "vm-01", "vmid": 101, "vlan": "mgmt"}])
        mock_client.bridge_exists.return_value = False
        mock_client.get_vm_status.side_effect = HiveframeAPIError("not found")

        engine.check_status(stack_yaml, "pve")

        mock_client.create_linux_bridge.assert_not_called()
        mock_client.delete_network_iface.assert_not_called()
        mock_client.clone_vm.assert_not_called()
        mock_client.delete_vm.assert_not_called()
        mock_client.start_vm.assert_not_called()
        mock_client.stop_vm.assert_not_called()
