# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Grandfathered SoC violations — pre-existing files exempt from strict enforcement.
Remove entries here once the file is modularized.
"""

# Grandfathered files: pre-existing violations shown as WARN (not FAIL) in CI.
# Only 6 remain — all justified by design or Law 7 constraints.
GRANDFATHERED = {
    "pulse/brain/memory/working_memory.py",   # LAW 7: single coherent working memory model
    "pulse/mcp/server.py",                    # by design: 10 MCP tools + 1 resource + main (thin endpoints)
    "pulse/workers/worker_llm.py",            # LAW 7: single WorkerLLM class, 4 providers + sacred gates
    "pulse/api/pulse_api.py",                 # FastAPI: Pydantic models + route handlers = 12 (by design, API layer)
    "pulse/api/pulse_api_brain.py",           # FastAPI: 15 brain route endpoints (by design, API layer)
    "pulse/core/enums.py",                    # by design: 6 enum classes + 3 validators (canonical enum module)
}

# === FIXED (removed from GRANDFATHERED) ===
# Phase 4-A (earlier sessions):
#   pulse/admin/audit/soc_checker.py — extracted GRANDFATHERED set to soc_grandfathered.py
#   pulse/core/paths.py — extracted brain init to paths_brain_init.py
#   pulse/brain/integrity/gate_checks.py — extracted AP query helpers to gate_ap_query.py
#   pulse/brain/save_writers/jsonl_store.py — extracted build_jsonl_entry to jsonl_entry_builder.py
#   pulse/daemons/consolidation/stages/stage_maintenance.py — extracted homeostasis/deep/recency to stage_maintenance_homeostasis.py
#   pulse/admin/audit/metacognitive_audit.py — extracted schema/procedure audits to metacognitive_audit_schemas.py
#
# Phase 4-B (this session):
#   pulse/core/brain_analysis.py — counting -> brain_analysis_counting.py, neuro -> brain_analysis_neuro.py
#   pulse/tasks/task_ops.py — worker registry helpers -> task_ops_workers.py
#   pulse/workers/worker_tools.py — submit/salience/sign -> worker_tools_submit.py
#   pulse/admin/benchmarks/benchmark_tracker.py — lifecycle -> _ops.py, CLI -> _main.py
#   pulse/admin/benchmarks/benchmark_synthesizer.py — ops -> _ops.py, CLI -> _main.py
#   pulse/admin/brain_ops/brain_recommender.py — pipeline/CLI -> brain_recommender_main.py
#   pulse/core/brain_db.py — bulk_upsert + search -> brain_db_helpers.py
#   pulse/brain/brain_query/briefing_signals.py — render helpers -> briefing_signals_render.py
#   pulse/brain/workspace/specialists.py — oracle -> specialists_oracle.py, broadcast -> specialists_broadcast.py
#
# OK (compliant — never violated or fixed before audit):
#   pulse/admin/audit/brain_validators.py, wiring_check.py, pulse_api.py, pulse_api_brain.py
#   pulse/brain/capture/capture_routing.py, brain_query.py, boot/loaders.py
#   pulse/brain/brain_search/search_scoring.py, plasticity/stdp.py, plasticity/reconsolidation.py
#   pulse/brain/brain_query/briefing.py, brain_query/briefing_ext.py, brain_query/briefing_sections.py
#   pulse/brain/pulse_boot.py, core/enums.py
#   pulse/daemons/consolidation/consolidation_daemon.py, consolidation_stages.py
#   pulse/daemons/neural/prediction_feedback.py, prediction_daemon.py, gate_feedback.py
#   pulse/daemons/orchestrator/schedulers.py, daemons/synthesis/sleep/sleep_cycle.py
#   pulse/daemons/bridge/reflex_llm.py
#   pulse/graph/knowledge_graph_query.py
#   pulse/tasks/dispatcher_lifecycle.py, dispatcher_maintenance.py, dispatcher_routing.py
#   pulse/tasks/task_claiming.py, pulse_dispatcher.py
#   pulse/workers/worker_tools_ext.py
