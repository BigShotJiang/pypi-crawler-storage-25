# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Reward subpackage — RPE computation, credit assignment, propagation, momentum, regulation, volatility."""

from pulse.core.reward.reward_signal import (         # noqa: F401
    RewardSignal,
    compute_rpe,
    assign_credit,
    propagate_reward,
    record_task_outcome,
    REWARD_SIGNALS_FILE,
    CREDIT_LEDGER_FILE,
    REINFORCE_DELTA,
    CONTRADICT_DELTA,
    LOSS_AVERSION_RATIO,
    CREDIT_DECAY,
    MIN_CREDIT,
    MAX_SIGNALS,
    MAX_CREDIT_ITEMS,
)
from pulse.core.reward.reward_propagation import (    # noqa: F401
    propagate_reward as _propagate_reward_impl,
)
from pulse.core.reward.reward_momentum import (       # noqa: F401
    record_success_momentum,
    get_domain_streak,
    reset_domain_streak,
)
from pulse.core.reward.reward_regulation import (     # noqa: F401
    increment_regulation_count,
    get_regulation_count,
    reset_regulation_count,
    get_regulation_status,
)
from pulse.core.reward.volatility import (            # noqa: F401
    compute_volatility,
    get_volatility_multiplier,
    VOLATILITY_FILE,
    MIN_MULTIPLIER,
    MAX_MULTIPLIER,
    DEFAULT_MULTIPLIER,
)
