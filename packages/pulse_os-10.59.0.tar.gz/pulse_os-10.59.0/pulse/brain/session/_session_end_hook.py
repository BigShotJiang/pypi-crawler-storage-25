#!/usr/bin/env python3
"""Called by Claude Code SessionEnd hook to close the active session."""
import sys
import pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent.parent.parent))
try:
    from pulse.brain.session.session_lifecycle import end_session, get_active_session
    sid = get_active_session("claude")
    if sid:
        end_session(sid)
except Exception:
    pass
