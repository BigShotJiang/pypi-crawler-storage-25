"""Backward-compat shim — moved to pulse.brain.integrity.self_check."""
from pulse.brain.integrity.self_check import *  # noqa: F401,F403
from pulse.brain.integrity.self_check import _PULSE_FACTS, _CLAIM_PATTERNS
