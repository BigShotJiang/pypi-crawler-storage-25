"""Brain search sources — 16-source parallel search fan-out.

Subpackage created by Brain Fractal Refactor II (Commit 3B).
Re-exports all public search functions so callers continue to use:
    from pulse.brain.search_sources import search_wins, search_facts, ...
"""
from .search_sources import (  # noqa: F401 — facade / main dispatcher
    search_anti_patterns,
    search_predictions,
    search_wins,
    search_fails,
    search_domains,
    search_patterns,
    search_evidence,
    search_private,
    search_schemas,
    search_procedures,
    search_graph,
    search_facts,
    search_episodic,
    search_working_memory,
    search_decisions,
    search_meta_schemas,
    search_capture_log,
)
