#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""
Consolidation Daemon: Cross-session pattern mining + schema promotion.

Main orchestration loop. Stages are in consolidation_stages.py (Law 7 split).

22 main stages (plus 12 sub-stages):
  1.   Dedup: Text-similarity merging
  1b.  EchoRefine: Cross-ref golden paths + constraints
  2.   Pattern Mining: Find recurring sequences across past 7 days
  2b.  Register Discovered Procedures
  2c.  LTD Decay: Flag unretrieved old items
  2d.  Reconsolidation: Merge similar entries
  2e.  Cross-Domain Transfer Detection
  2f.  Cross-Region Mining
  3.   Schema Promotion: Promote high-confidence patterns to schemas.json
  3b.  Sequence → Schema Promotion
  3c.  Micro-Pattern Promotion
  3d.  Meta-Schema Build: Level 2 abstraction (cluster schemas → meta-schemas + principles)
  4.   Knowledge Graph Update
  4b.  Promote high-confidence lessons/failures to patterns
  4c.  Abstraction: Generalize recurring patterns
  5.   Metacognitive Audit: Flag vague/unused/contradicted items
  6.   Hierarchical Prune: Miller's Law 4±1 enforcement (Q8 Neural Hardening)
  6b.  Rebuild Search Index
  7.   Brain Health Check: Silent pipeline watchdog
  8.   Truth Verification: Contradiction detection + penalties
  9.   Decision Consolidation: Merge/deduplicate decision entries
  10.  Metamemory: Domain confidence map refresh
  10b. Synaptic Homeostasis (Tononi & Cirelli 2014)
  11.  Causal Graph Reasoning: Confounders + analogy scan
  12.  Goal Generation: Self-directed investigation
  13.  Prospective Memory: Deferred intentions check
  14.  Sentinel Health Checks
  15.  Autonomy Promotion Check
  16.  Pattern Evolution: Auto-generate regex patterns
  17.  Associative Replay: Dreaming (low-activity only)
  18.  Deep Consolidation: Promote permanent, archive dead
  19.  Session-Based Replay: Hippocampal retrieval sequence replay
  20.  Conflict Monitor: ACC contradiction detection (Botvinick 2001)
  21.  Spaced Retrieval: Testing + spacing effect (Dunlosky 2013)

Runs every 6 hours via orchestrator.

Dependencies: Python stdlib + brain_utils (internal)
"""
import io
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

if os.name == 'nt' and __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    if hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent.parent.parent

# When run directly, ensure pulse package is importable
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from pulse.core.brain_utils import HIPPOCAMPUS_DIR, save_json, now_iso as _now_iso
from pulse.daemons.consolidation.consolidation_stages import (
    stage_dedup,
    stage_pattern_mining,
    stage_schema_promotion,
    stage_schema_promotion_from_sequences,
    register_discovered_procedures,
    stage_ltd_decay,
    stage_graph_update,
    stage_reconsolidation,
    stage_cross_domain_transfer,
    stage_promote_to_patterns,
    stage_metacognitive_audit,
    stage_hierarchical_prune,
    stage_truth_verification,
    stage_recency_bonus,
    stage_schema_distortion_audit,
    stage_episodic_graduation,
)

CONSOLIDATION_LOG = HIPPOCAMPUS_DIR / "Evidence" / "Metrics" / "consolidation_log.json"
_STAGE_PROGRESS_FILE = HIPPOCAMPUS_DIR / "Evidence" / "Metrics" / "consolidation_stages.json"


def _save_stage_progress(stage_results: dict):
    """Item 99: Persist per-stage timing data to state/ for monitoring dashboards."""
    try:
        from pulse.core.brain_utils import now_iso as _ni99
        _STAGE_PROGRESS_FILE.parent.mkdir(parents=True, exist_ok=True)
        save_json(_STAGE_PROGRESS_FILE, {"timestamp": _ni99(), "stages": stage_results})
    except Exception:
        pass  # fail-open — never crash consolidation over monitoring



# === MAIN CONSOLIDATION ===

def run_consolidation(verbose=False):
    """Run full 22-stage consolidation pipeline.

    Orchestrates all consolidation stages via the stage runners.
    Logs results to consolidation_log.json.
    """
    print("[CONSOLIDATION] Starting 21-stage consolidation...")
    from pulse.daemons.consolidation.consolidation_stages_runner import run_early_stages
    from pulse.daemons.consolidation.consolidation_late_stages import run_late_stages
    early = run_early_stages(verbose=verbose)
    result = run_late_stages(verbose=verbose, early=early)
    _stage_results_99 = result if isinstance(result, dict) else {}
    # Stage 10: stage_10_metamemory — decay domain expertise after metamemory stage
    try:
        from pulse.brain.metacognition.metamemory import _decay_domain_expertise
        _decay_domain_expertise()
    except Exception:
        pass
    # Wire S2-1: Brain self-assessment — write brain_health.json
    try:
        from pulse.brain.monitoring.brain_self_assessment import get_brain_health_report
        _bhr = get_brain_health_report()
        from pulse.core.brain_utils import STATE_DIR
        import json as _json
        (_bhr_file := (STATE_DIR / "health" / "brain_health.json")).parent.mkdir(parents=True, exist_ok=True)
        _bhr_file.write_text(_json.dumps(_bhr, indent=2), encoding="utf-8")
    except Exception:
        pass
    # Wire S3: Record consolidation run for completeness tracking
    try:
        from pulse.brain.monitoring.consolidation_completeness import record_consolidation_run
        record_consolidation_run(list(_stage_results_99.keys()))
    except Exception:
        pass
    return result


if __name__ == "__main__":
    v = "--verbose" in __import__("sys").argv or "-v" in __import__("sys").argv
    run_consolidation(verbose=v)
