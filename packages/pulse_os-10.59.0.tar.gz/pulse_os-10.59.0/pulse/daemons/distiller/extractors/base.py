#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary.
"""Base extractor class for all distiller extractors."""


class BaseExtractor:
    """Base class for all knowledge extractors in the distiller pipeline."""

    def __init__(self, name: str, target_table: str):
        self.name = name
        self.target_table = target_table
        self.extracted_count = 0

    def extract(self, user_text: str, agent_text: str, metadata: dict) -> list:
        """Override: return list of extracted items."""
        raise NotImplementedError

    def write(self, items: list) -> int:
        """Write items to brain via insert_knowledge. Returns count written."""
        from pulse.core.brain_db import insert_knowledge
        written = 0
        for item in items:
            try:
                if insert_knowledge(self.target_table, item):
                    written += 1
            except Exception:
                pass
        self.extracted_count += written
        return written
