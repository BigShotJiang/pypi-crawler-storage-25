#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""
Compatibility shim — gate_feedback.py

The implementation has moved to the gate_feedback/ package.
This file re-exports the public API so existing imports continue to work.
"""
from pulse.daemons.neural.gate_feedback import (  # noqa: F401
    record_gate_failure,
    get_active_feedback,
    decay_old_feedback,
    record_perseveration_violation,
    check_perseveration,
    reset_perseveration,
)

__all__ = [
    "record_gate_failure",
    "get_active_feedback",
    "decay_old_feedback",
    "record_perseveration_violation",
    "check_perseveration",
    "reset_perseveration",
]
