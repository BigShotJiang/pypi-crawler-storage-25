"""Model Council MCP server package."""

__version__ = "0.1.1"
