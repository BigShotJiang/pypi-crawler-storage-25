"""Built-in authentication routes."""

from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, Request, Response, status

from aura_auth._core.schemas import AuthResponse, LoginRequest, RegisterRequest, SessionRead, UserRead
from aura_auth.dependencies import current_user, get_aura_auth
from aura_auth.manager import SessionContext

router = APIRouter(tags=["auth"])


def _session_context(request: Request) -> SessionContext:
    return SessionContext(
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
    )


@router.post("/register", status_code=status.HTTP_201_CREATED, response_model=AuthResponse)
async def register_user(
    payload: RegisterRequest,
    response: Response,
    request: Request,
    aura=Depends(get_aura_auth),
) -> AuthResponse:
    result = await aura.manager.register(payload, _session_context(request))
    aura.transport.set_token(response, result.session.token)
    return result


@router.post("/login", response_model=AuthResponse)
async def login_user(
    payload: LoginRequest,
    response: Response,
    request: Request,
    aura=Depends(get_aura_auth),
) -> AuthResponse:
    result = await aura.manager.login(payload, _session_context(request))
    aura.transport.set_token(response, result.session.token)
    return result


@router.post("/logout")
async def logout_user(request: Request, response: Response, aura=Depends(get_aura_auth)) -> dict[str, str]:
    token = await aura.transport.get_token(request)
    await aura.manager.revoke_session_token(token)
    aura.transport.remove_token(response)
    return {"detail": "logged out"}


@router.get("/me", response_model=UserRead)
async def read_me(user=Depends(current_user)) -> UserRead:
    return UserRead.model_validate(user)


@router.get("/sessions", response_model=list[SessionRead])
async def list_sessions(user=Depends(current_user), aura=Depends(get_aura_auth)) -> list[SessionRead]:
    sessions = await aura.manager.list_sessions(user.id)
    return [SessionRead.model_validate(s) for s in sessions]


@router.delete("/sessions/{session_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_one_session(
    session_id: uuid.UUID,
    user=Depends(current_user),
    aura=Depends(get_aura_auth),
) -> None:
    await aura.manager.delete_session_for_user(session_id, user.id)
