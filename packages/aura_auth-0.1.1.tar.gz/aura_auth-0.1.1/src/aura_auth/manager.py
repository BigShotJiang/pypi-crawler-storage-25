"""User manager orchestrating backend, password strategy, and sessions."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Generic

from aura_auth._core.exceptions import InvalidCredentialsError, InvalidTokenError, UserNotFoundError
from aura_auth._core.protocols import SessionProtocol, UserProtocol
from aura_auth._core.schemas import AuthResponse, LoginRequest, RegisterRequest, SessionRead, UserRead
from aura_auth._core.security import generate_random_token, generate_session_token
from aura_auth._core.types import ID
from aura_auth.backend.base import BaseBackend
from aura_auth.strategies.password import PasswordStrategy


def _as_utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt


@dataclass
class SessionContext:
    """Optional client metadata stored on a new session."""

    ip_address: str | None = None
    user_agent: str | None = None


class UserManager(Generic[ID]):
    """Orchestrates registration, login, and session-backed authentication."""

    def __init__(
        self,
        backend: BaseBackend[ID],
        password_strategy: PasswordStrategy[ID],
        session_lifetime_seconds: int,
        verification_ttl_seconds: int = 86_400,
    ) -> None:
        self._backend = backend
        self._password_strategy = password_strategy
        self._session_lifetime_seconds = session_lifetime_seconds
        self._verification_ttl_seconds = verification_ttl_seconds

    def _auth_response(self, user: UserProtocol[ID], session: SessionProtocol[ID]) -> AuthResponse[ID]:
        return AuthResponse[ID](
            user=UserRead[ID].model_validate(user),
            session=SessionRead[ID].model_validate(session),
        )

    async def _create_session(self, user: UserProtocol[ID], ctx: SessionContext | None) -> SessionProtocol[ID]:
        now = datetime.now(tz=UTC)
        return await self._backend.create_session(
            {
                "user_id": user.id,
                "token": generate_session_token(),
                "expires_at": now + timedelta(seconds=self._session_lifetime_seconds),
                "ip_address": ctx.ip_address if ctx else None,
                "user_agent": ctx.user_agent if ctx else None,
            },
        )

    async def register(self, data: RegisterRequest, ctx: SessionContext | None = None) -> AuthResponse[ID]:
        """Register and return the new user plus a fresh session."""
        user = await self._password_strategy.register(data, self._backend)
        session = await self._create_session(user, ctx)
        return self._auth_response(user, session)

    async def login(self, credentials: LoginRequest, ctx: SessionContext | None = None) -> AuthResponse[ID]:
        """Validate credentials, create a session, and return user + session."""
        user = await self._password_strategy.authenticate(
            {"email": str(credentials.email), "password": credentials.password},
            self._backend,
        )
        if user is None:
            raise InvalidCredentialsError("Invalid email or password")
        await self._password_strategy.on_after_login(user)
        session = await self._create_session(user, ctx)
        return self._auth_response(user, session)

    async def get_user(self, user_id: ID) -> UserProtocol[ID] | None:
        """Fetch a user by primary key."""
        return await self._backend.get_user_by_id(user_id)

    async def resolve_session_user(self, token: str) -> UserProtocol[ID] | None:
        """Load the user for an active session token, if any."""
        session = await self._backend.get_session_by_token(token)
        if session is None:
            return None
        return await self._backend.get_user_by_id(session.user_id)

    async def revoke_session_token(self, token: str | None) -> None:
        """Delete the session matching this token (logout)."""
        if not token:
            return
        await self._backend.delete_session_by_token(token)

    async def list_sessions(self, user_id: ID) -> list[SessionProtocol[ID]]:
        """Return non-expired sessions for a user (newest first)."""
        now = datetime.now(tz=UTC)
        rows = await self._backend.list_sessions_by_user(user_id)
        return [s for s in rows if _as_utc(s.expires_at) >= now]

    async def delete_session_for_user(self, session_id: ID, user_id: ID) -> None:
        """Delete one session if it belongs to the given user."""
        for sess in await self._backend.list_sessions_by_user(user_id):
            if sess.id == session_id:
                await self._backend.delete_session(session_id)
                return
        raise UserNotFoundError("Session not found")

    async def request_verify(self, user: UserProtocol[ID]) -> str:
        """Create an email verification row and return the secret value."""
        now = datetime.now(tz=UTC)
        value = generate_random_token(24)
        await self._backend.create_verification(
            {
                "identifier": user.email,
                "value": value,
                "expires_at": now + timedelta(seconds=self._verification_ttl_seconds),
            },
        )
        return value

    async def verify_email(self, identifier: str, value: str) -> UserProtocol[ID]:
        """Mark the user's email verified using a verification row."""
        row = await self._backend.get_verification(identifier, value)
        if row is None:
            raise InvalidTokenError("Invalid or expired verification")
        user = await self._backend.get_user_by_email(identifier)
        if user is None:
            raise UserNotFoundError("User not found")
        updated = await self._backend.update_user(user.id, {"email_verified": True})
        await self._backend.delete_verification(row.id)
        return updated
