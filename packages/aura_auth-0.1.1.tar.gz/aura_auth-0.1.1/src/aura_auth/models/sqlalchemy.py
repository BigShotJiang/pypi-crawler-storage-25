"""Default SQLAlchemy models for users, accounts, sessions, and verifications."""

from __future__ import annotations

import uuid

from sqlalchemy import UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from aura_auth.models.base import AccountMixin, SessionMixin, UserMixin, VerificationMixin


class Base(DeclarativeBase):
    """Declarative base for built-in models."""


class DefaultUser(UserMixin, Base):
    """Default identity model when you do not need extra columns."""

    __tablename__ = "users"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)


class DefaultAccount(AccountMixin, Base):
    """Default account row (credential, OAuth, …)."""

    __tablename__ = "accounts"
    __table_args__ = (UniqueConstraint("provider_id", "account_id", name="uq_provider_account"),)

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)


class DefaultSession(SessionMixin, Base):
    """Default server-side session."""

    __tablename__ = "sessions"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)


class DefaultVerification(VerificationMixin, Base):
    """Default verification / OTP storage."""

    __tablename__ = "verifications"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)


# Backwards-friendly alias
SQLAlchemyBaseUser = DefaultUser
