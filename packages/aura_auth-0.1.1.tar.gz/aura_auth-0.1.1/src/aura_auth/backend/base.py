"""Abstract database backend."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Generic

from aura_auth._core.protocols import AccountProtocol, SessionProtocol, UserProtocol, VerificationProtocol
from aura_auth._core.types import ID


class BaseBackend(ABC, Generic[ID]):
    """Abstract base for all database backends."""

    # --- User ---
    @abstractmethod
    async def get_user_by_id(self, user_id: ID) -> UserProtocol[ID] | None: ...

    @abstractmethod
    async def get_user_by_email(self, email: str) -> UserProtocol[ID] | None: ...

    @abstractmethod
    async def create_user(self, data: dict[str, Any]) -> UserProtocol[ID]: ...

    @abstractmethod
    async def update_user(self, user_id: ID, data: dict[str, Any]) -> UserProtocol[ID]: ...

    @abstractmethod
    async def delete_user(self, user_id: ID) -> None: ...

    # --- Account ---
    @abstractmethod
    async def get_account(self, provider_id: str, account_id: str) -> AccountProtocol[ID] | None: ...

    @abstractmethod
    async def get_accounts_by_user(self, user_id: ID) -> list[AccountProtocol[ID]]: ...

    @abstractmethod
    async def create_account(self, data: dict[str, Any]) -> AccountProtocol[ID]: ...

    @abstractmethod
    async def update_account(self, account_pk: ID, data: dict[str, Any]) -> AccountProtocol[ID]: ...

    @abstractmethod
    async def delete_account(self, account_pk: ID) -> None: ...

    # --- Session ---
    @abstractmethod
    async def create_session(self, data: dict[str, Any]) -> SessionProtocol[ID]: ...

    @abstractmethod
    async def get_session_by_token(self, token: str) -> SessionProtocol[ID] | None: ...

    @abstractmethod
    async def list_sessions_by_user(self, user_id: ID) -> list[SessionProtocol[ID]]: ...

    @abstractmethod
    async def delete_session(self, session_id: ID) -> None: ...

    @abstractmethod
    async def delete_session_by_token(self, token: str) -> None: ...

    @abstractmethod
    async def delete_sessions_by_user(self, user_id: ID) -> None: ...

    # --- Verification ---
    @abstractmethod
    async def create_verification(self, data: dict[str, Any]) -> VerificationProtocol[ID]: ...

    @abstractmethod
    async def get_verification(self, identifier: str, value: str) -> VerificationProtocol[ID] | None: ...

    @abstractmethod
    async def delete_verification(self, verification_id: ID) -> None: ...

    @abstractmethod
    async def delete_expired_verifications(self) -> None: ...
