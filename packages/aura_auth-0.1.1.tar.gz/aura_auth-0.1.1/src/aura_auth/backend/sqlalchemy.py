"""Async SQLAlchemy backend implementation."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Generic, cast

from sqlalchemy import delete, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from aura_auth._core.exceptions import UserAlreadyExistsError, UserNotFoundError
from aura_auth._core.protocols import AccountProtocol, SessionProtocol, UserProtocol, VerificationProtocol
from aura_auth._core.types import ID
from aura_auth.backend.base import BaseBackend
from aura_auth.models.sqlalchemy import DefaultAccount, DefaultSession, DefaultVerification


def _as_utc(dt: datetime) -> datetime:
    """Normalize DB datetimes (SQLite often returns naive UTC)."""
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt


class SQLAlchemyBackend(BaseBackend[ID], Generic[ID]):
    """CRUD backend using SQLAlchemy async sessions."""

    def __init__(
        self,
        session_factory: async_sessionmaker[AsyncSession],
        user_model: type[Any],
        account_model: type[Any] | None = None,
        session_model: type[Any] | None = None,
        verification_model: type[Any] | None = None,
    ) -> None:
        self._session_factory = session_factory
        self._user_model = user_model
        self._account_model = account_model or DefaultAccount
        self._session_model = session_model or DefaultSession
        self._verification_model = verification_model or DefaultVerification

    # --- User ---
    async def get_user_by_id(self, user_id: ID) -> UserProtocol[ID] | None:
        async with self._session_factory() as session:
            row = await session.get(self._user_model, user_id)
            return row  # type: ignore[return-value]

    async def get_user_by_email(self, email: str) -> UserProtocol[ID] | None:
        async with self._session_factory() as session:
            stmt = select(self._user_model).where(self._user_model.email == email)  # type: ignore[arg-type]
            res = await session.execute(stmt)
            return res.scalar_one_or_none()  # type: ignore[return-value]

    async def create_user(self, data: dict[str, Any]) -> UserProtocol[ID]:
        user = self._user_model(**data)
        async with self._session_factory() as session:
            session.add(user)
            try:
                await session.commit()
            except IntegrityError as exc:
                await session.rollback()
                raise UserAlreadyExistsError("User with this email already exists") from exc
            await session.refresh(user)
            return user  # type: ignore[return-value]

    async def update_user(self, user_id: ID, data: dict[str, Any]) -> UserProtocol[ID]:
        async with self._session_factory() as session:
            db_user = await session.get(self._user_model, user_id)
            if db_user is None:
                raise UserNotFoundError("User not found")
            for key, value in data.items():
                if value is None:
                    continue
                setattr(db_user, key, value)
            await session.commit()
            await session.refresh(db_user)
            return db_user  # type: ignore[return-value]

    async def delete_user(self, user_id: ID) -> None:
        async with self._session_factory() as session:
            db_user = await session.get(self._user_model, user_id)
            if db_user is None:
                return
            await session.delete(db_user)
            await session.commit()

    # --- Account ---
    async def get_account(self, provider_id: str, account_id: str) -> AccountProtocol[ID] | None:
        async with self._session_factory() as session:
            stmt = select(self._account_model).where(
                self._account_model.provider_id == provider_id,  # type: ignore[arg-type]
                self._account_model.account_id == account_id,  # type: ignore[arg-type]
            )
            res = await session.execute(stmt)
            return res.scalar_one_or_none()  # type: ignore[return-value]

    async def get_accounts_by_user(self, user_id: ID) -> list[AccountProtocol[ID]]:
        async with self._session_factory() as session:
            stmt = select(self._account_model).where(self._account_model.user_id == user_id)  # type: ignore[arg-type]
            res = await session.execute(stmt)
            return list(res.scalars().all())  # type: ignore[return-value]

    async def create_account(self, data: dict[str, Any]) -> AccountProtocol[ID]:
        account = self._account_model(**data)
        async with self._session_factory() as session:
            session.add(account)
            try:
                await session.commit()
            except IntegrityError as exc:
                await session.rollback()
                raise UserAlreadyExistsError("Account already exists for this provider") from exc
            await session.refresh(account)
            return cast(AccountProtocol[ID], account)

    async def update_account(self, account_pk: ID, data: dict[str, Any]) -> AccountProtocol[ID]:
        async with self._session_factory() as session:
            row = await session.get(self._account_model, account_pk)
            if row is None:
                raise UserNotFoundError("Account not found")
            for key, value in data.items():
                if value is None:
                    continue
                setattr(row, key, value)
            await session.commit()
            await session.refresh(row)
            return row  # type: ignore[return-value]

    async def delete_account(self, account_pk: ID) -> None:
        async with self._session_factory() as session:
            row = await session.get(self._account_model, account_pk)
            if row is None:
                return
            await session.delete(row)
            await session.commit()

    # --- Session ---
    async def create_session(self, data: dict[str, Any]) -> SessionProtocol[ID]:
        sess = self._session_model(**data)
        async with self._session_factory() as session:
            session.add(sess)
            await session.commit()
            await session.refresh(sess)
            return cast(SessionProtocol[ID], sess)

    async def get_session_by_token(self, token: str) -> SessionProtocol[ID] | None:
        async with self._session_factory() as session:
            stmt = select(self._session_model).where(self._session_model.token == token)  # type: ignore[arg-type]
            res = await session.execute(stmt)
            row = res.scalar_one_or_none()
            if row is None:
                return None
            if _as_utc(row.expires_at) < datetime.now(tz=UTC):  # type: ignore[arg-type]
                return None
            return row  # type: ignore[return-value]

    async def list_sessions_by_user(self, user_id: ID) -> list[SessionProtocol[ID]]:
        async with self._session_factory() as session:
            stmt = (
                select(self._session_model)
                .where(self._session_model.user_id == user_id)  # type: ignore[arg-type]
                .order_by(self._session_model.created_at.desc())  # type: ignore[arg-type]
            )
            res = await session.execute(stmt)
            return list(res.scalars().all())  # type: ignore[return-value]

    async def delete_session(self, session_id: ID) -> None:
        async with self._session_factory() as session:
            row = await session.get(self._session_model, session_id)
            if row is None:
                return
            await session.delete(row)
            await session.commit()

    async def delete_session_by_token(self, token: str) -> None:
        async with self._session_factory() as session:
            await session.execute(delete(self._session_model).where(self._session_model.token == token))  # type: ignore[arg-type]
            await session.commit()

    async def delete_sessions_by_user(self, user_id: ID) -> None:
        async with self._session_factory() as session:
            await session.execute(delete(self._session_model).where(self._session_model.user_id == user_id))  # type: ignore[arg-type]
            await session.commit()

    # --- Verification ---
    async def create_verification(self, data: dict[str, Any]) -> VerificationProtocol[ID]:
        row = self._verification_model(**data)
        async with self._session_factory() as session:
            session.add(row)
            await session.commit()
            await session.refresh(row)
            return cast(VerificationProtocol[ID], row)

    async def get_verification(self, identifier: str, value: str) -> VerificationProtocol[ID] | None:
        async with self._session_factory() as session:
            stmt = select(self._verification_model).where(
                self._verification_model.identifier == identifier,  # type: ignore[arg-type]
                self._verification_model.value == value,  # type: ignore[arg-type]
            )
            res = await session.execute(stmt)
            row = res.scalar_one_or_none()
            if row is None:
                return None
            if _as_utc(row.expires_at) < datetime.now(tz=UTC):  # type: ignore[arg-type]
                return None
            return row  # type: ignore[return-value]

    async def delete_verification(self, verification_id: ID) -> None:
        async with self._session_factory() as session:
            row = await session.get(self._verification_model, verification_id)
            if row is None:
                return
            await session.delete(row)
            await session.commit()

    async def delete_expired_verifications(self) -> None:
        async with self._session_factory() as session:
            now = datetime.now(tz=UTC)
            await session.execute(delete(self._verification_model).where(self._verification_model.expires_at < now))  # type: ignore[arg-type]
            await session.commit()
