"""Email + password authentication strategy."""

from __future__ import annotations

from typing import Any, Final, Generic

from aura_auth._core.exceptions import UserAlreadyExistsError
from aura_auth._core.protocols import BackendProtocol, UserProtocol
from aura_auth._core.schemas import RegisterRequest
from aura_auth._core.security import PasswordHelper
from aura_auth._core.types import ID
from aura_auth.strategies.base import BaseStrategy

CREDENTIAL_PROVIDER: Final[str] = "credential"


class PasswordStrategy(BaseStrategy[ID], Generic[ID]):
    """Authenticate users with bcrypt-hashed passwords on a credential account."""

    def __init__(self, password_helper: PasswordHelper) -> None:
        self._password_helper = password_helper

    async def authenticate(
        self,
        credentials: dict[str, Any],
        backend: BackendProtocol[ID],
    ) -> UserProtocol[ID] | None:
        """Authenticate with email + password. Returns user or None."""
        email = credentials.get("email")
        password = credentials.get("password")
        if not isinstance(email, str) or not isinstance(password, str):
            return None
        account_id = email.strip().lower()
        account = await backend.get_account(CREDENTIAL_PROVIDER, account_id)
        if account is None or not account.password:
            return None
        if not self._password_helper.verify(password, account.password):
            return None
        user = await backend.get_user_by_id(account.user_id)
        return user

    async def register(self, data: RegisterRequest, backend: BackendProtocol[ID]) -> UserProtocol[ID]:
        """Create a user row and a credential account with a hashed password."""
        email = str(data.email).strip().lower()
        if await backend.get_user_by_email(email):
            raise UserAlreadyExistsError("User with this email already exists")
        hashed = self._password_helper.hash(data.password)
        user = await backend.create_user(
            {
                "name": data.name.strip(),
                "email": email,
                "email_verified": False,
                "image": None,
            },
        )
        await backend.create_account(
            {
                "user_id": user.id,
                "account_id": email,
                "provider_id": CREDENTIAL_PROVIDER,
                "access_token": None,
                "refresh_token": None,
                "access_token_expires_at": None,
                "refresh_token_expires_at": None,
                "scope": None,
                "id_token": None,
                "password": hashed,
            },
        )
        await self.on_after_register(user)
        return user
