"""Core contracts and utilities."""

from aura_auth._core.config import AuraAuthConfig
from aura_auth._core.exceptions import AuraAuthError
from aura_auth._core.protocols import (
    AccountProtocol,
    BackendProtocol,
    SessionProtocol,
    StrategyProtocol,
    TransportProtocol,
    UserProtocol,
    VerificationProtocol,
)
from aura_auth._core.schemas import (
    AccountRead,
    AuthResponse,
    LoginRequest,
    RegisterRequest,
    SessionRead,
    UserRead,
    UserUpdate,
)
from aura_auth._core.security import PasswordHelper, TokenHelper, generate_random_token, generate_session_token
from aura_auth._core.types import ID

__all__ = [
    "ID",
    "AccountProtocol",
    "AccountRead",
    "AuraAuthConfig",
    "AuraAuthError",
    "AuthResponse",
    "BackendProtocol",
    "LoginRequest",
    "PasswordHelper",
    "RegisterRequest",
    "SessionProtocol",
    "SessionRead",
    "StrategyProtocol",
    "TokenHelper",
    "TransportProtocol",
    "UserProtocol",
    "UserRead",
    "UserUpdate",
    "VerificationProtocol",
    "generate_random_token",
    "generate_session_token",
]
