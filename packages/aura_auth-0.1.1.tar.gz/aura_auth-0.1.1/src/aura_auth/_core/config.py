"""Library configuration objects."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

CookieSameSite = Literal["lax", "strict", "none"]


@dataclass
class AuraAuthConfig:
    """Configuration for wiring AuraAuth components."""

    database_url: str
    secret: str
    route_prefix: str = "/auth"
    session_lifetime_seconds: int = 604_800
    verify_token_lifetime_seconds: int = 86_400
    cookie_transport: bool = False
    """When True, register/login set an HTTP-only session cookie and ``current_user`` reads it."""
    cookie_name: str = "aura_token"
    cookie_secure: bool = True
    """Set False for plain HTTP (e.g. local dev); browsers ignore Secure cookies on http://."""
    cookie_httponly: bool = True
    cookie_samesite: CookieSameSite = "lax"
    password_min_length: int = 8
    user_model: type[Any] | None = None
    account_model: type[Any] | None = None
    session_model: type[Any] | None = None
    verification_model: type[Any] | None = None
