"""Pydantic request/response schemas."""

from __future__ import annotations

from datetime import datetime
from typing import Generic

from pydantic import BaseModel, ConfigDict, EmailStr

from .types import ID

# --- Requests ---


class RegisterRequest(BaseModel):
    """Email + password registration."""

    name: str
    email: EmailStr
    password: str


class LoginRequest(BaseModel):
    """Email + password login."""

    email: EmailStr
    password: str


# --- Responses ---


class UserRead(BaseModel, Generic[ID]):
    """Public user returned from the API."""

    id: ID
    name: str
    email: str
    email_verified: bool
    image: str | None = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class SessionRead(BaseModel, Generic[ID]):
    """Opaque session handed to the client after login or register."""

    id: ID
    token: str
    expires_at: datetime

    model_config = ConfigDict(from_attributes=True)


class AuthResponse(BaseModel, Generic[ID]):
    """Login or register response: identity plus session."""

    user: UserRead[ID]
    session: SessionRead[ID]


class AccountRead(BaseModel, Generic[ID]):
    """Linked account (credential or OAuth) for listing."""

    id: ID
    provider_id: str
    account_id: str
    scope: str | None = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


# --- Updates ---


class UserUpdate(BaseModel):
    """Partial user profile update."""

    name: str | None = None
    email: EmailStr | None = None
    image: str | None = None
