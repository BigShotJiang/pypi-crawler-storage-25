"""Runtime-checkable protocols for backends, strategies, and transports."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Protocol, runtime_checkable

from .types import ID


@runtime_checkable
class UserProtocol(Protocol[ID]):
    """Identity only — no credentials on the user row."""

    id: ID
    name: str
    email: str
    email_verified: bool
    image: str | None
    created_at: datetime
    updated_at: datetime


@runtime_checkable
class AccountProtocol(Protocol[ID]):
    """One auth method linked to a user (credential, OAuth, phone, …)."""

    id: ID
    user_id: ID
    account_id: str
    provider_id: str
    access_token: str | None
    refresh_token: str | None
    access_token_expires_at: datetime | None
    refresh_token_expires_at: datetime | None
    scope: str | None
    id_token: str | None
    password: str | None
    created_at: datetime
    updated_at: datetime


@runtime_checkable
class SessionProtocol(Protocol[ID]):
    """Server-side session bound to a user and device context."""

    id: ID
    user_id: ID
    token: str
    expires_at: datetime
    ip_address: str | None
    user_agent: str | None
    created_at: datetime
    updated_at: datetime


@runtime_checkable
class VerificationProtocol(Protocol[ID]):
    """Email verification, password reset, OTP, magic link, etc."""

    id: ID
    identifier: str
    value: str
    expires_at: datetime
    created_at: datetime
    updated_at: datetime


@runtime_checkable
class BackendProtocol(Protocol[ID]):
    """Persistence for users, accounts, sessions, and verifications."""

    # --- User ---
    async def get_user_by_id(self, user_id: ID) -> UserProtocol[ID] | None: ...

    async def get_user_by_email(self, email: str) -> UserProtocol[ID] | None: ...

    async def create_user(self, data: dict[str, Any]) -> UserProtocol[ID]: ...

    async def update_user(self, user_id: ID, data: dict[str, Any]) -> UserProtocol[ID]: ...

    async def delete_user(self, user_id: ID) -> None: ...

    # --- Account ---
    async def get_account(self, provider_id: str, account_id: str) -> AccountProtocol[ID] | None: ...

    async def get_accounts_by_user(self, user_id: ID) -> list[AccountProtocol[ID]]: ...

    async def create_account(self, data: dict[str, Any]) -> AccountProtocol[ID]: ...

    async def update_account(self, account_pk: ID, data: dict[str, Any]) -> AccountProtocol[ID]: ...

    async def delete_account(self, account_pk: ID) -> None: ...

    # --- Session ---
    async def create_session(self, data: dict[str, Any]) -> SessionProtocol[ID]: ...

    async def get_session_by_token(self, token: str) -> SessionProtocol[ID] | None: ...

    async def list_sessions_by_user(self, user_id: ID) -> list[SessionProtocol[ID]]: ...

    async def delete_session(self, session_id: ID) -> None: ...

    async def delete_session_by_token(self, token: str) -> None: ...

    async def delete_sessions_by_user(self, user_id: ID) -> None: ...

    # --- Verification ---
    async def create_verification(self, data: dict[str, Any]) -> VerificationProtocol[ID]: ...

    async def get_verification(self, identifier: str, value: str) -> VerificationProtocol[ID] | None: ...

    async def delete_verification(self, verification_id: ID) -> None: ...

    async def delete_expired_verifications(self) -> None: ...


@runtime_checkable
class StrategyProtocol(Protocol[ID]):
    """Authentication strategy contract."""

    async def authenticate(
        self, credentials: dict[str, Any], backend: BackendProtocol[ID]
    ) -> UserProtocol[ID] | None: ...

    async def on_after_register(self, user: UserProtocol[ID]) -> None: ...

    async def on_after_login(self, user: UserProtocol[ID]) -> None: ...


@runtime_checkable
class TransportProtocol(Protocol):
    """How session tokens travel (bearer header, cookie, etc.)."""

    async def get_token(self, request: Any) -> str | None: ...

    def set_token(self, response: Any, token: str) -> None: ...

    def remove_token(self, response: Any) -> None: ...
