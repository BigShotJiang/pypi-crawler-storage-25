## v1.16.1 - 2026-05-20

- **bugfix**:  arreglo split de branch para armar correctamente el titulo del PR [[jteran](mailto:jteran@renatre.org.ar)] (a0d3028)

---


## v1.16.0 - 2026-05-20

- **feature**:  agrego soporte para especificar tickets en nombre e rama [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (f389118)

---


## v1.15.0 - 2026-05-17

- **feature**:  include revlist count in version tag when skipping bump [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (d275ac0)

---


## v1.14.0 - 2026-02-11

- **feature**:  actualizar nombre de proyecto en uv.lock [[jteran](mailto:jteran@renatre.org.ar)] (9cd0b25)

---


## v1.13.1 - 2026-02-11

- **bugfix**:  test pipeline change [[jteran](mailto:jteran@renatre.org.ar)] (f2eb5af)

---


## v1.13.0 - 2026-02-11

- **feature**:  actualizo nombre y descripcion del proyecto [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (41d6957)

---


## v1.12.3 - 2026-02-11

- **bugfix**:  taggeo todos los commits localmente, incluso en ci [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (5d23bb6)

---


## v1.12.2 - 2026-02-10

- **bugfix**:  test pipeline change [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (98bf7e7)

---


## v1.12.1 - 2026-02-10

- **bugfix**:  agrego paso de build al pipeline [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (ade86f1)

---


## v1.12.0 - 2026-02-10

- **feature**:  cambio pipelines para usar uv package manager [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (0f700b0)

---


## v1.11.0 - 2025-12-22

- **feature**:  al agrupar release, mergear cambios en rama group [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (726c73a)
- **feature**:  usar commit message cuando el pr solo tiene un commit [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (057b32a)
- **feature**:  eliminar prompt de ticket en creacion de rama [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (c0e2e59)
- **feature**:  deshacer rebase cuando este falla en el pasaje de cambios [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (77e338d)
- **bugfix**:  uso titulo personalizado de PR [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (1aa2263)

---


## v1.10.0 - 2025-12-15

- **feature**:  agrego opcion para cambiar a rama objetivo y obtener cambios [[jteran](mailto:jteran@renatre.org.ar)] (df8998a)
- **feature**:  agrego opcion para personalizar nombre de PR [[jteran](mailto:jteran@renatre.org.ar)] (c87b141)

---


## v1.9.1 - 2025-12-15

- **bugfix**:  uso rama actual cuando esta es un entorno [[jteran](mailto:jteran@renatre.org.ar)] (c54cb95)

---


## v1.9.0 - 2025-12-15

- **bugfix**:  uso env actual en vez de rama actual para listar ramas [[jteran](mailto:jteran@renatre.org.ar)] (5d33b29)
- **feature**:  listar ramas de todos los entornos con flag --all, y del entorno actual por defecto [[jteran](mailto:jteran@renatre.org.ar)] (104b321)
- **feature**:  agrego opcion para listar ramas wip [[jteran](mailto:jteran@renatre.org.ar)] (774cf9a)
- **refactor**:  cambio opcion para listar ramas trash [[jteran](mailto:jteran@renatre.org.ar)] (74c333a)
- **bugfix**:  elimino : extra de comando new [[jteran](mailto:jteran@renatre.org.ar)] (499babc)

---


## v1.8.0 - 2025-12-15

- **feature**:  agrego opcion para incluir ticket en nombre de rama [[jteran](mailto:jteran@renatre.org.ar)] (01e938e)
- **feature**:  mostrar warning si la rama actual no es un entorno configurado [[jteran](mailto:jteran@renatre.org.ar)] (97b4a56)
- **feature**:  hacer pull en rama actual antes de crear nueva rama [[jteran](mailto:jteran@renatre.org.ar)] (24be501)

---


## v1.7.5 - 2025-12-14

- **bugfix**:  verificar si la rama grupo trackea una rama remota antes de hacer pull [[jteran](mailto:jteran@renatre.org.ar)] (0d95a97)
- **bugfix**:  capturo interrupion por teclado para no mostrar stack trace [[jteran](mailto:jteran@renatre.org.ar)] (0af5102)

---


## v1.7.4 - 2025-12-14

- **bugfix**:  generación de PR de ramas release [[jteran](mailto:jteran@renatre.org.ar)] (b24b22a)

---


## v1.7.3 - 2025-12-14

- **bugfix**:  listado de ramas para elegir grupo release no devolvia resultados [[jteran](mailto:jteran@renatre.org.ar)] (5600e5e)

---


## v1.7.2 - 2025-12-11

- **bugfix**:  al hacer un release, cambio a la rama grupo si esta disponible [[jteran](mailto:jteran@renatre.org.ar)] (44b8efd)

---


## v1.7.1 - 2025-12-11

- **bugfix**:  cambio la forma en la que se obtiene el first fork point entre 2 ramas [[jteran](mailto:jteran@renatre.org.ar)] (7b4fb34)

---


## v1.7.0 - 2025-12-11

- **feature**:  muestro el listado de commits a pasar al siguiente entorno en release [[jteran](mailto:jteran@renatre.org.ar)] (2e65cb7)

---


## v1.6.4 - 2025-12-10

- **bugfix**:  cambio la lista de commits a mostrar en el merge [[jteran](mailto:jteran@renatre.org.ar)] (4e089dc)

---


## v1.6.3 - 2025-12-04

- **bugfix**:  revertir guion entre version y entorno, agregar guion a sufijo [[jteran](mailto:jteran@renatre.org.ar)] (7ce6add)
- **bugfix**:  agrego guion entre version y nombre de entorno [[jteran](mailto:jteran@renatre.org.ar)] (053b8b1)

---


## v1.6.3- - 2025-12-04

- **bugfix**:  agrego guion entre version y nombre de entorno [[jteran](mailto:jteran@renatre.org.ar)] (053b8b1)

---


## v1.6.2 - 2025-12-04

- **bugfix**:  crear changelog cuando no existe [[jteran](mailto:jteran@renatre.org.ar)] (0c8e7bb)

---


## v1.6.1 - 2025-11-29

### Commits

- **bugfix**:  arreglo mensaje de confirmacion de squash, muevo prompt de commit message antes del squash [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (f1f6e67)
- **bugfix**:  cambio default en confirmacion para agrupar release [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (83df7e9)

---


## v1.6.0 - 2025-11-29

### Commits

- **feature**:  agrego opcion para agrupar ramas release [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (c47afff)

---


## v1.5.2 - 2025-11-28

### Commits

- **bugfix**:  arreglo split de ramas de flow.branches [[jteran](mailto:jteran@renatre.org.ar)] (2ad7471)
- **bugfix**:  arreglo iteracion de items de flowconfig en set_config [[jteran](mailto:jteran@renatre.org.ar)] (5c3a317)
- **docs**:  agrego venv a lista de carpetas ignoradas [[jteran](mailto:jteran@renatre.org.ar)] (50979e2)

---


## v1.5.1 - 2025-11-27

### Commits

- **refactor**:  muevo constantes a modulo git_flow para centralizar uso [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (29757cc)
- **bugfix**:  ignorar carpetas generadas en build de lsp [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (7f857fd)

---


## v1.5.0 - 2025-11-27

### Commits

- **feature**:  modifico formato de listado de ramas [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (7177084)

---


## v1.4.0 - 2025-11-23

### Commits

- **feature**:  agrego comando branch para listar ramas [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (c74f1a3)
- **feature**:  agrego soporte para parametros repetidos en llamadas a Git [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (eafb3f1)

---


## v1.3.0 - 2025-11-23

### Commits

- **feature**:  agrego comando release, elimino codigo no utilizado [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (43d7e5a)

---


## v1.2.0 - 2025-11-22

### Commits

- **bugfix**:  deshabilito check en merge --abort al buscar conflictos [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (34aba71)
- **feature**:  agregando descripcion a ejecucion de comandos importantes en new, tag y merge [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (4135a78)
- **feature**:  agregando descripcion a ejecucion de comandos importantes en init y commit [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (faea8c2)
- **bugfix**:  cambiando tipo de print para agregar soporte de titulos [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (11e2a9d)
- **bugfix**:  descartar output cuando el comando git se ejecuta con _run [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (d133c48)
- **feature**:  muevo opciones para check y print a metodos para ejecutar git [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (7346cfd)

---


## v1.1.5 - 2025-11-21

### Commits

- **bugfix**:  creo tag en el commit que actualiza el changelog [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (222c819)
- **style**:  ignorar carpeta dist/ [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (0e75a8e)

---


## v1.1.4 - 2025-11-21

### Commits

- **bugfix**:  separar etapa de lectura y escritura de changelog [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (bf829a1)
- **bugfix**:  agrego http:// como protocolo soportado para pipelines [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (8f79a6a)

---


## Saturday,  8 de November de 2025, 00:28

- Autor: [bitbucket-pipelines](mailto:commits-noreply@bitbucket.org)
- Rama: `14beea150de16e06f7b4e54361584dae5d5ae713`

### Commits

- **bugfix**:  cambio el commit que se usa para generar las entradas del changelog [[jonathan.nerat](mailto:jonathan.nerat@gmail.com)] (14beea1)

---

## Viernes,  7 de Noviembre de 2025, 11:42

- Autor: [Jonathan Teran](mailto:jteran@renatre.org.ar)
- Rama: `bugfix/generate-changelog-on-version-bump`

### Commits

- **bugfix**:  muevo generacion de CHANGELOG.md a comando tag (4bccd20)
	- src/git_flow/git.py (M)
	- src/git_flow/main.py (M)
- **refactor**:  elimino seccion dev de bitbucket-pipelines.yml (71a5643)
	- bitbucket-pipelines.yml (M)
- **docs**:  elimino CHANGELOG.md (17eb6c2)
	- CHANGELOG.md (D)
- **ignore**:  ignoro archivos de build (90b420f)
	- .gitignore (M)

---

