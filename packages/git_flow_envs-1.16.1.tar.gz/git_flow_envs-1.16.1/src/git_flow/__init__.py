GitFlowError = ValueError

BRANCH_TYPES = [
    "feature",
    "refactor",
    "bugfix",
    "hotfix",
    "chore",
    "docs",
]

COMMIT_TYPES = [
    "feature",
    "bugfix",
    "hotfix",
    "refactor",
    "perf",
    "docs",
    "style",
    "test",
    "wip",
]

WIP_BRANCH_PREFIX = "wip/"
TRASH_BRANCH_PREFIX = "trash/"

# Commits con estos valores incrementan el componente correspondiente
SEMVER_MAJOR = 3
SEMVER_MINOR = 2
SEMVER_PATCH = 1

# Commits con estos tipos no alteran la versión
SEMVER_SKIP = 0

COMMIT_TYPE_INCREMENT = {
    "feature": SEMVER_MINOR,
    "bugfix": SEMVER_PATCH,
    "hotfix": SEMVER_PATCH,
    "refactor": SEMVER_SKIP,
    "perf": SEMVER_SKIP,
    "docs": SEMVER_SKIP,
    "style": SEMVER_SKIP,
    "test": SEMVER_SKIP,
}

SUPPORTED_REMOTE_APIS = [
    "bitbucket.org",
    "github.com",
]

REPOSITORY_TOKEN_FILENAME = ".repository-token"

FLOWCONFIG_FILENAME = ".flowconfig"
