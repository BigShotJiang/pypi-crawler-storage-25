from datetime import datetime
from os.path import isfile

from git_flow.git import Git


class Changelog:
    FILENAME = "CHANGELOG.md"
    COMMIT_MESSAGE = "chore: bump version and update CHANGELOG.md [skip ci]"

    def update(self, title: str, base: str, branch: str):
        self._prepend(self.generate_entry(title, base, branch))

    def generate_header(self, title):
        now = datetime.now()

        return f"""## {title} - {now.strftime("%F")}

"""

    def generate_content(self, base: str, branch: str):
        commits = Git(
            "log", base + ".." + branch, first_parent=True, format="%h", merges=False
        ).lines()
        content = ""

        for commit in commits:
            message = Git("show", commit, patch=False, format="%s").firstline()
            email = Git("show", commit, patch=False, format="%ae").firstline()
            username = email[: email.index("@")]
            index = message.index(":")
            commit_type = message[:index]
            commit_message = message[index + 1 :]

            content += f"- **{commit_type}**: {commit_message} [[{username}](mailto:{email})] ({commit})\n"

        return content

    def generate_footer(self):
        return """
---


"""

    def generate_entry(self, title: str, base: str, branch: str):
        return (
            self.generate_header(title)
            + self.generate_content(base, branch)
            + self.generate_footer()
        )

    def _prepend(self, content: str):
        if isfile(self.FILENAME):
            with open(self.FILENAME, "r") as f:
                content += f.read()

        with open(self.FILENAME, "w") as f:
            f.write(content)
