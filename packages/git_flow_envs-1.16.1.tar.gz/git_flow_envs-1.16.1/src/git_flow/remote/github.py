from git_flow import GitFlowError
from git_flow.remote.base import RemoteAPI


class GithubRemoteAPI(RemoteAPI):
    API_ENDPOINT = "https://github.com"

    def create_pull_request(
        self,
        source: str,
        destination: str,
        title: str | None = None,
        description: str | None = None,
    ) -> str:
        raise GitFlowError("not implemented yet!")

    def create_tag(self, tag: str, commit: str) -> str:
        raise GitFlowError("not implemented yet!")

    def get_endpoint(self, resource: str) -> str:
        return GithubRemoteAPI.API_ENDPOINT
