import requests
from git_flow import GitFlowError
from git_flow.remote.base import RemoteAPI


class BitbucketRemoteAPI(RemoteAPI):
    API_ENDPOINT = "https://api.bitbucket.org/2.0/repositories"

    def create_pull_request(
        self,
        source: str,
        destination: str,
        title: str | None = None,
        description: str | None = None,
    ):
        request = requests.post(
            self.get_endpoint("/pullrequests"),
            headers=self.get_headers(),
            json={
                "title": title,
                "description": description,
                "source": {"branch": {"name": source}},
                "destination": {"branch": {"name": destination}},
                "close_source_branch": True,
            },
        )

        if request.ok:
            json = request.json()
            return "PR creado exitosamente: " + json["links"]["html"]["href"]
        else:
            raise GitFlowError("Ocurrió un error al crear el PR: " + request.text)

    def create_tag(self, tag: str, commit: str):
        response = requests.post(
            self.get_endpoint("/refs/tags"),
            headers=self.get_headers(),
            json={"name": tag, "target": {"hash": commit}},
        )

        if response.ok:
            return "Tag creado exitosamente: " + tag
        else:
            raise GitFlowError("Ocurrió un error al crear el tag: " + response.text)

    def get_endpoint(self, resource: str) -> str:
        return f"{BitbucketRemoteAPI.API_ENDPOINT}/{self.repository}/{resource}"
