import typer
from git_flow import BRANCH_TYPES
from git_flow.command.base import *
from git_flow.git import Git
from typing import Optional

app = typer.Typer()


@app.command()
def new():
    """Crea una nueva rama siguiendo Conventional Branches"""

    ensure_initialized()
    branch = ensure_right_branch()
    envs = flowconfig["flow.branches"].split(",")

    if branch not in envs:
        warning("La rama actual no corresponde a un entorno configurado.")

    info("Se creará una nueva rama de trabajo sobre la rama actual.")
    info("Debe seleccionar el tipo de cambio a realizar.")

    branch_type = choice("Tipos de cambio", BRANCH_TYPES)
    ticket = _get_optional_ticket()
    new_branch = _get_unique_branch_name(branch_type, ticket)

    if "flow.remote" in flowconfig and Git.get_tracking_branch(branch):
        Git("pull").exec(print="Actualizando rama actual")

    if confirm(f"¿Crear rama '{new_branch}' sobre la rama actual?"):
        Git("switch", new_branch, create=True).exec(print="Creando nueva rama")

def _get_optional_ticket() -> Optional[str]:
    ticket = prompt("[Opcional] Ticket que respalda el cambio (en formato ABC-123)")

    if not ticket:
        return None
    if not is_valid_ticket(ticket):
        warning("Formato de ticket inválido, ignorando.")
        return None
    
    return ticket

def _get_unique_branch_name(branch_type: str, ticket: Optional[str]) -> str:
    info(f"Ingrese las palabras clave que describan el cambio de tipo '{branch_type}'.")
    branch = None
    branches = Git.get_branches()

    while branch is None:
        keywords = prompt(
            "Palabras clave del cambio (por ejemplo: 'create worker form')",
            persistent=True,
        )

        keywords = filter(lambda k: len(k) > 0, keywords.split(" "))
        branch = branch_type + "/" + (ticket + "-" if ticket else "") + "-".join(keywords)

        if branch in branches:
            error(
                f"La rama '{branch}' ya existe, cambie las palabras claves para generar otra"
            )
            branch = None

    return branch
