from git_flow import (
    BRANCH_TYPES,
    REPOSITORY_TOKEN_FILENAME,
    FLOWCONFIG_FILENAME,
    GitFlowError,
)
from git_flow.git import Git
from git_flow.remote.base import RemoteAPI
from git_flow.remote.bitbucket import BitbucketRemoteAPI
from git_flow.remote.github import GithubRemoteAPI
from git_flow.io import *
from os.path import isfile

TYPE_SUCCESS = 0
TYPE_WARNING = 1
TYPE_ERROR = 2
TYPE_INFO = 3


flowconfig = Git.get_config(FLOWCONFIG_FILENAME) if isfile(FLOWCONFIG_FILENAME) else {}


def ensure_initialized():
    initialized = flowconfig["flow.initialized"] if flowconfig else None

    if not initialized:
        raise GitFlowError(
            "El repositorio no fue inicializado, debe ejecutar el comando `init`."
        )
    elif initialized != "true":
        raise GitFlowError(
            f"El valor de `flow.initialized` ({initialized}) es inválido."
        )


def ensure_right_branch():
    branch = Git.get_current_branch()

    if branch == "HEAD":
        raise GitFlowError("No se encuentra parado sobre una rama.")
    elif confirm(f"Se encuentra sobre la rama '{branch}'. ¿Es correcto?"):
        return branch
    else:
        raise GitFlowError("Ejecución cancelada.")


def get_branch_env_and_type(branch: str) -> tuple[str, str]:
    components = branch.split("/")
    target_branches = flowconfig["flow.branches"].split(",")

    if len(components) == 2:
        if components[0] not in BRANCH_TYPES:
            raise GitFlowError(
                f"Branch inválida, el tipo '{components[0]}' no es válido."
            )

        return (target_branches[0], components[0])
    elif len(components) == 4:
        target_branches = target_branches[1:]

        if (
            components[0] != "release"
            or components[1] not in target_branches
            or components[2] not in BRANCH_TYPES
        ):
            raise GitFlowError(
                "Branch release inválido, debe tener el siguiente formato: "
                "release/<env>/<type>/<name>, pero es: " + branch
            )

        return (components[1], components[2])
    else:
        raise GitFlowError("Branch inválido: " + branch)


def ensure_repository_token():
    if not isfile(REPOSITORY_TOKEN_FILENAME):
        raise GitFlowError(
            "No existe un token para el repositorio en " + REPOSITORY_TOKEN_FILENAME
        )

    with open(REPOSITORY_TOKEN_FILENAME) as f:
        return f.readline().strip()


def ensure_clean_worktree(has_remote: bool):
    status = Git.status()

    if not status:
        return

    not_empty = any(map(lambda s: s.index != " " or s.worktree != " ", status))

    if not_empty:
        if not has_remote:
            warning("Existen cambios en tu entorno de trabajo sin commitear.")
        else:
            raise GitFlowError("No se puede continuar con cambios pendientes.")

        if not confirm("¿Desea continuar?", False):
            raise GitFlowError("Ejecución abortada")


def get_remote_api(token: str) -> RemoteAPI:
    if "flow.remote" not in flowconfig:
        raise GitFlowError("El repositorio no tiene configurado un remoto.")

    [host, repository] = RemoteAPI.parse(flowconfig["flow.remote"])

    if host == "bitbucket.org":
        return BitbucketRemoteAPI(repository, token)
    elif host == "github.com":
        return GithubRemoteAPI(repository, token)
    else:
        raise GitFlowError("El host del repositorio remoto es inválido")

def is_valid_ticket(ticket: str) -> bool:
    """Check if the specified string is a valid ticket number (ABC-123)"""
    components = ticket.split("-")

    if len(components) != 2:
        return False
    
    ticket_project = components[0]
    ticket_number = components[1]

    return ticket_project.isalpha() and ticket_project.isupper() and ticket_number.isnumeric()