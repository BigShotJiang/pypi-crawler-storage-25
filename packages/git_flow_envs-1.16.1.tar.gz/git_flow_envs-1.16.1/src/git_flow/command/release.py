from git_flow import COMMIT_TYPES, GitFlowError
from git_flow.command.base import *
from git_flow.git import Git
from typing import Optional
import typer

app = typer.Typer()


@app.command()
def release(group: Optional[str] = None):
    """Realiza el merge de la rama, o crea el PR para hacerlo si tiene un remoto configurado"""
    ensure_initialized()

    branch = ensure_right_branch()
    envs = flowconfig["flow.branches"].split(",")
    env, _ = get_branch_env_and_type(branch)

    if env == envs[-1]:
        raise GitFlowError(
            "No se puede hacer release de una rama en el ultimo entorno."
        )

    has_remote = "flow.remote" in flowconfig

    ensure_clean_worktree(has_remote)

    next_env = envs[envs.index(env) + 1]
    next_branch = (
        branch.replace(f"/{env}/", f"/{next_env}/")
        if branch.startswith("release/")
        else f"release/{next_env}/{branch}"
    )

    base = Git.get_first_fork_point(branch, env)
    commits = Git("log", base + "..", format="%s").lines()

    if not commits:
        raise GitFlowError("No hay cambios a mergear.")

    print("Cambios a pasar al proximo entorno:")

    for commit in commits:
        print("- " + commit)

    grouping = group is not None

    if not group:
        if confirm("¿Desea agrupar este release con otra rama?", False):
            grouping = True
            group = choice(
                "Grupo release: ", Git.get_branches("release/" + next_env + "/")
            )
        else:
            group = next_env

    if has_remote and Git.get_tracking_branch(group):
        Git("switch", group).exec(print="Cambiando a la rama objetivo")
        Git("pull").exec(print="Sincronizando cambios la rama objetivo")
        Git("switch", "-").exec(print="Volviendo a la rama original")

    if len(commits) > 1 and confirm(
        f"¿Desea reemplazar los {len(commits)} commits de la rama por uno solo?", False
    ):
        info("Debe ingresar el mensaje del commit a crear.")

        commit_type = choice("Tipo de commit", COMMIT_TYPES[:-1])
        commit_message = prompt(
            "Mensaje (máximo recomendado: 100 caracteres)", persistent=True
        )
        message = commit_type + ": " + commit_message

        Git("switch", next_branch, base, create=True).exec(
            print="Creando rama release en base"
        )
        Git("merge", branch, squash=True).exec(print="Squasheando commits en uno solo")
        Git("commit", m=message).exec(print="Creando commit único")
    else:
        Git("switch", next_branch, create=True).exec(print="Creando rama release")

    status = Git("rebase", base, next_branch, onto=group).code(
        print="Moviendo cambios hacia el siguiente ambiente"
    )

    if status:
        Git("rebase", abort=True).exec(print="Deshaciendo cambios por conflictos")
        raise GitFlowError("Error al realizar pasaje de cambios a rama objetivo")
    elif grouping:
        Git("switch", group).exec(print="Cambiando a rama objetivo")
        Git("merge", next_branch, ff_only=True).exec(
            print="Mergeando cambios de la nueva rama"
        )
