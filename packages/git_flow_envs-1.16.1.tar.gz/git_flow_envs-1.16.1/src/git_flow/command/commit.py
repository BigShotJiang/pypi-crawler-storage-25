import typer
from datetime import datetime
from git_flow import COMMIT_TYPES, TRASH_BRANCH_PREFIX, WIP_BRANCH_PREFIX, GitFlowError
from git_flow.git import Git
from git_flow.command.base import *

app = typer.Typer()


@app.command()
def commit():
    """Crea un commit siguiendo el formato de Conventional Commits"""
    ensure_initialized()
    branch = ensure_right_branch()

    if not _has_files_staged():
        warning("No hay cambios en el indice para commitear.")
        if confirm("¿Desea agregar la carpeta actual?"):
            Git("add", ".").exec(print="Agregando cambios")
        else:
            raise GitFlowError("Debe agregar algún cambio al indice para continuar.")

    commit_type = choice("Tipo de commit", COMMIT_TYPES)
    commit_message = prompt(
        "Mensaje (máximo recomendado: 100 caracteres)", persistent=True
    )
    message = commit_type + ": " + commit_message

    if branch.startswith(WIP_BRANCH_PREFIX):
        original_branch = branch.removeprefix(WIP_BRANCH_PREFIX)
        Git("commit", m=message).exec(print="Creando commit en rama WIP")

        if commit_type != "wip":
            suffix = datetime.now().strftime("%Y%m%dT%H%M")
            Git("switch", original_branch).exec(print="Volviendo a rama original")
            Git("merge", branch, squash=True).exec(
                print="Squasheando commits WIP en uno solo"
            )
            Git("commit", m=message).exec(print="Creando commit final de rama WIP")
            Git(
                "branch", branch, TRASH_BRANCH_PREFIX + branch + "/" + suffix, move=True
            ).exec(print="Backup de rama WIP")
    else:
        if commit_type == "wip":
            Git("switch", WIP_BRANCH_PREFIX + branch, create=True).exec(
                print="Creando nueva rama WIP"
            )

        Git("commit", m=message).exec(print="Creando commit")


def _has_files_staged():
    status = Git.status()

    if not status:
        raise GitFlowError("No hay cambios para commitear.")

    files_in_index = []

    for s in status:
        if s.worktree != "?" and s.worktree != " ":
            files_in_index.append(s.file)

    return len(files_in_index) > 0
