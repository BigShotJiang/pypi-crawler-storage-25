from git_flow import (
    TRASH_BRANCH_PREFIX,
    WIP_BRANCH_PREFIX,
    GitFlowError,
)
from git_flow.command.base import *
from git_flow.git import Git
from typing import Annotated
import typer

BRANCH_FORMAT = "%(refname:short)"

app = typer.Typer()


@app.command()
def branch(
    environment: Annotated[
        str | None,
        typer.Argument(
            help="Entorno de las ramas a listar. Por defecto, es el entorno actual."
        ),
    ] = None,
    trash: Annotated[
        bool,
        typer.Option(
            help=f"Listar ramas en la 'papelera de reciclaje' (ramas que empiezan con '{TRASH_BRANCH_PREFIX}')"
        ),
    ] = False,
    wip: Annotated[
        bool,
        typer.Option(
            help=f"Listar ramas 'en progreso' (ramas que empiezan con '{WIP_BRANCH_PREFIX}')"
        ),
    ] = False,
    all: Annotated[
        bool, typer.Option(help="Listar ramas de todos los entornos")
    ] = False,
):
    """Lista ramas del repositorio, agrupandolas por entorno objetivo"""
    ensure_initialized()

    current_branch = Git.get_current_branch()
    environments = flowconfig["flow.branches"].split(",")

    if current_branch in environments:
        current_environment = current_branch
    else:
        current_environment, _ = get_branch_env_and_type(current_branch)

    if trash:
        show_branches(TRASH_BRANCH_PREFIX, current_branch)
    elif wip:
        show_branches(WIP_BRANCH_PREFIX, current_branch)
    elif all:
        show_envs(environments, current_branch)
        show_all_branches(environments, current_branch)
    elif environment is None:
        show_envs(environments, current_branch)
        show_env_branches(current_environment, environments, current_branch)
    elif environment in environments:
        show_envs(environments, current_branch)
        show_env_branches(environment, environments, current_branch)
    else:
        raise GitFlowError(f"'{environment}' no es un entorno válido.")


def show_branches(branch_prefix: str, current_branch: str):
    branches = get_branches(branch_prefix)

    if not branches:
        print("No hay ramas a mostrar.")
        return

    for branch in branches:
        is_current = branch == current_branch
        prefix = "*" if is_current else " "
        console.print(prefix + " " + branch, style="green" if is_current else None)


def get_branches(branch_prefix: str):
    return Git("for-each-ref", "refs/heads/" + branch_prefix, format=BRANCH_FORMAT).lines()


def show_all_branches(environments: list[str], current_branch: str):
    for environment in environments:
        show_env_branches(
            environment, environments, current_branch, len(environments) > 1
        )

    trash = len(get_branches(TRASH_BRANCH_PREFIX))

    if trash:
        print()
        console.print(
            "[bold]Papelera:[/bold] "
            + str(trash)
            + " rama"
            + ("" if trash == 1 else "s")
        )


def show_envs(environments: list[str], current_branch: str):
    console.print("Entornos", style="bold")
    for environment in environments:
        is_current = environment == current_branch
        prefix = "*" if is_current else " "
        console.print(prefix + " " + environment, style="green" if is_current else None)
    print()


def show_env_branches(
    environment: str,
    environments: list[str],
    current_branch: str,
    show_env: bool = False,
):
    is_first_env = environment == environments[0]
    pattern = (
        "refs/heads/" if is_first_env else "refs/heads/release/" + environment + "/"
    )
    pattern += "*/*"
    exclude = (
        ["refs/heads/" + TRASH_BRANCH_PREFIX, "refs/heads/release/"]
        if is_first_env
        else []
    )
    branches = Git(
        "for-each-ref", pattern, exclude=exclude, format=BRANCH_FORMAT
    ).lines()

    console.print(environment if show_env else "Ramas", style="bold")

    if not branches:
        print("No hay ramas a mostrar.")
        return

    for branch in branches:
        is_current = branch == current_branch
        prefix = "*" if is_current else " "
        console.print(prefix + " " + branch, style="green" if is_current else None)
