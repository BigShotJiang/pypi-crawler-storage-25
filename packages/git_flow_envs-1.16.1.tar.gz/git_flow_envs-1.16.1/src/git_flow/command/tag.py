from git_flow import (
    COMMIT_TYPE_INCREMENT,
    SEMVER_MAJOR,
    SEMVER_MINOR,
    SEMVER_PATCH,
    SEMVER_SKIP,
    GitFlowError,
)
from git_flow.changelog import Changelog
from git_flow.command.base import *
from git_flow.git import Git
from typing import Optional
import typer

app = typer.Typer()


@app.command()
def tag(token: Optional[str] = None):
    """Crea un nuevo tag para el último merge."""
    ensure_initialized()

    envs = flowconfig["flow.branches"].split(",")
    target = Git.get_current_branch()

    if target not in envs:
        raise GitFlowError("Solo se pueden taggear commits en ramas principales.")

    branch = Git(
        "show", get_last_merge_commit() + "^2", patch=False, format="%h"
    ).firstline()
    base = Git.get_first_fork_point(branch, target)
    commits = Git("log", base + ".." + branch, format="%s").lines()
    next_tag = get_next_tag_from_commits(commits, target)

    if not next_tag:
        info(
            "Los cambios realizados no implican un salto de versión, se mantiene la anterior."
        )
        return

    token, ci = get_token_and_ci(token)

    if not token:
        raise GitFlowError("No hay token disponible")

    changelog = Changelog()

    changelog.update(next_tag, base, branch)
    Git("add", Changelog.FILENAME).exec(print="Agregando nuevo CHANGELOG.md")
    Git("commit", message=Changelog.COMMIT_MESSAGE).exec(print="Creando commit")
    tag_commit = Git("show", "HEAD", patch=False, format="%h").firstline()

    if ci:
        Git("push").exec(print="Subiendo commit al remoto para taggearlo")
        success(get_remote_api(token).create_tag(next_tag, tag_commit))

    Git("tag", next_tag, tag_commit).exec(print="Creando tag localmente")


def get_token_and_ci(token: Optional[str]):
    try:
        return (ensure_repository_token(), False)
    except GitFlowError:
        return (token, True)


def get_last_merge_commit():
    commit = Git(
        "log", first_parent=True, merges=True, max_count=1, format="%h"
    ).firstline()

    if not commit:
        raise GitFlowError("No hay merges a taggear.")

    return commit


def check_not_tagged(commit: str):
    tag = Git("describe", commit, tags=True, exact_match=True).firstline(check=False)

    if tag:
        raise GitFlowError("El commit a taggear ya tiene tag: " + tag)


def get_next_tag_from_commits(commits: list[str], branch: str) -> str | None:
    increment = SEMVER_SKIP
    for commit in commits:
        commit_type = commit[: commit.index(":")]
        increment = max(increment, COMMIT_TYPE_INCREMENT.get(commit_type, SEMVER_SKIP))

    tag = Git.get_current_tag() or f"v0.0.0-{branch}"

    until_dash = tag.index("-") if "-" in tag else None
    suffix = tag[until_dash:] if until_dash is not None else ""
    [major, minor, patch] = map(int, tag[1:until_dash].split("."))

    if increment == SEMVER_MAJOR:
        major += 1
        minor = 0
        patch = 0
    elif increment == SEMVER_MINOR:
        minor += 1
        patch = 0
    elif increment == SEMVER_PATCH:
        patch += 1
    elif increment == SEMVER_SKIP:
        suffix = "-r" + Git("rev-list", "HEAD", count=True).firstline()

    return None if increment == SEMVER_SKIP else f"v{major}.{minor}.{patch}{suffix}"
