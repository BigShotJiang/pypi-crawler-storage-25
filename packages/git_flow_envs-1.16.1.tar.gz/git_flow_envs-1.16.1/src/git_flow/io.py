from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.panel import Panel

console = Console(highlight=False)


def success(msg: str):
    console.print(f":white_check_mark: [green]{msg}[/green]")


def warning(msg: str):
    console.print(f":warning: [yellow]{msg}[/yellow]")


def error(msg: str):
    console.print(f":x: [red]{msg}[/red]")


def info(msg: str):
    console.print(f":information: [blue]{msg}[/blue]")


def panel(title: str, text: str):
    console.print(Panel(text, title=title, expand=False, title_align="left"))


def prompt(
    prompt: str,
    default: str | None = None,
    persistent: bool = False,
    strip: bool = True,
) -> str:
    onetime = not persistent

    while onetime or persistent:
        result = Prompt.ask(prompt)
        result = result.strip() if strip else result

        if result:
            return result
        elif default is not None:
            return default
        elif persistent:
            error("Debe ingresar un valor no vacío.")
        else:
            return result


def confirm(question: str, default: bool = True):
    return Confirm.ask(question, default=default)


def choice(prompt: str, options: list[str]):
    return Prompt.ask(prompt, choices=options)
