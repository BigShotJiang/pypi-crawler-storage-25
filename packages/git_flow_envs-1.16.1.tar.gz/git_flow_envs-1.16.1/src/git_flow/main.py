#!/usr/bin/env python3

import typer

from git_flow import GitFlowError
from git_flow.command.base import *
from git_flow.command import init, new, commit, merge, tag, release, branch

REPOSITORY_TOKEN_PATH = ".repository-token"
LOCALE = "es_AR.UTF-8"


app = typer.Typer()
app.add_typer(init.app)
app.add_typer(new.app)
app.add_typer(commit.app)
app.add_typer(merge.app)
app.add_typer(tag.app)
app.add_typer(release.app)
app.add_typer(branch.app)


def main():
    try:
        app()
    except GitFlowError as e:
        error(str(e))
    except Exception as e:
        error("Ocurrió un error inesperado: " + str(e))
    except KeyboardInterrupt as e:
        print()
        error("Ejecución abortada")
