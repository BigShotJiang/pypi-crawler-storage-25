import argparse
import asyncio

from lunatone_rest_api_client.discovery import (
    LunatoneDiscovery,
    LunatoneDiscoveryFeature,
    LunatoneDiscoveryFilters,
    LunatoneDiscoveryType,
)


parser = argparse.ArgumentParser(prog="Discovery")
parser.add_argument(
    "-i", "--ip", type=str, help="Specify the IP address of a network interface"
)
arguments = parser.parse_args()


FILTER_SETS = (
    LunatoneDiscoveryFilters(),
    LunatoneDiscoveryFilters(
        features=[LunatoneDiscoveryFeature.REST_API],
        types=[LunatoneDiscoveryType.DALI2_IOT4],
    ),
    LunatoneDiscoveryFilters(
        features=[LunatoneDiscoveryFeature.REST_API],
        types=[LunatoneDiscoveryType.AIR_WLAN_SWITCH],
    ),
    LunatoneDiscoveryFilters(features=[LunatoneDiscoveryFeature.REST_API]),
    LunatoneDiscoveryFilters(types=[LunatoneDiscoveryType.AIR_WLAN_SWITCH]),
)


async def main():
    loop = asyncio.get_running_loop()
    async with LunatoneDiscovery(loop) as discovery:
        for filter_set in FILTER_SETS:
            print(filter_set)
            async for dev in discovery.async_discover_devices_stream(
                timeout=4.0, local_ip=arguments.ip, filters=filter_set
            ):
                print(dev)

        devices = await discovery.async_discover_devices(
            timeout=4.0, local_ip=arguments.ip, filters=FILTER_SETS[0]
        )
        print(devices)


if __name__ == "__main__":
    asyncio.run(main())
