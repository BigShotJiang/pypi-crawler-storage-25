from typing import ClassVar, Final

from awesomeversion import AwesomeVersion

from lunatone_rest_api_client import Auth, Info
from lunatone_rest_api_client.base import Controllable
from lunatone_rest_api_client.models import (
    ControlData,
    DeviceData,
    DevicesData,
    DeviceUpdateData,
)

_PATH: Final[str] = "devices"


class Device(Controllable):
    """Class that represents a Device object in the API."""

    base_path: ClassVar[str] = _PATH[:-1]

    def __init__(self, info: Info, data: DeviceData) -> None:
        """Initialize a device object."""
        self.auth = info.auth
        self._info = info
        self._data = data

    @property
    def path(self) -> str:
        """Return the resource path."""
        return f"{self.base_path}/{self.id}"

    @property
    def data(self) -> DeviceData:
        """Return the raw device data."""
        return self._data

    @property
    def id(self) -> int:
        """Return the ID of the device."""
        return self.data.id

    @property
    def name(self) -> str:
        """Return the name of the device."""
        return self.data.name

    @property
    def is_on(self) -> bool:
        """Return if the light is on."""
        return (
            self.data.features.switchable.status
            if self.data.features.switchable
            else False
        )

    @property
    def brightness(self) -> float | None:
        """Return the brightness of the light."""
        return (
            self.data.features.dimmable.status if self.data.features.dimmable else None
        )

    @property
    def color_temperature(self) -> int | None:
        """Return the color temperature of the light in kelvin."""
        if self._info.version is None or AwesomeVersion(self._info.version) < "1.17.0":
            return None
        return (
            self.data.features.color_kelvin.status
            if self.data.features.color_kelvin
            else None
        )

    @property
    def rgb_color(self) -> tuple[float, float, float] | None:
        """Return the RGB color of the light as tuple."""
        if self._info.version is None or AwesomeVersion(self._info.version) < "1.17.0":
            return None
        return (
            (
                self.data.features.color_rgb.status.red or 0.0,
                self.data.features.color_rgb.status.green or 0.0,
                self.data.features.color_rgb.status.blue or 0.0,
            )
            if self.data.features.color_rgb
            else None
        )

    @property
    def rgbw_color(self) -> tuple[float, float, float, float] | None:
        """Return the RGBW color of the light as tuple."""
        if self._info.version is None or AwesomeVersion(self._info.version) < "1.17.0":
            return None
        return (
            (
                *self.rgb_color,
                self.data.features.color_waf.status.white or 0.0,
            )
            if self.data.features.color_waf
            else None
        )

    @property
    def xy_color(self) -> tuple[float, float] | None:
        """Return the XY color of the light as tuple."""
        if self._info.version is None or AwesomeVersion(self._info.version) < "1.17.0":
            return None
        if self.data.features.color_xy:
            return (
                self.data.features.color_xy.status.x or 0.0,
                self.data.features.color_xy.status.y or 0.0,
            )
        return None

    async def async_update(self, data: DeviceUpdateData | None = None) -> None:
        """Update the device data."""
        if data is not None:
            json_data = data.model_dump(by_alias=True, exclude_none=True)
            response = await self.auth.put(self.path, json=json_data)
        else:
            response = await self.auth.get(self.path)
        self._data = DeviceData.model_validate(await response.json())

    async def async_control(self, data: ControlData) -> None:
        """Control the device."""
        json_data = data.model_dump(by_alias=True, exclude_none=True)
        await self.auth.post(f"{self.path}/control", json=json_data)


class Devices:
    """Class that represents a Devices object in the API."""

    path: ClassVar[str] = _PATH

    def __init__(self, info: Info) -> None:
        """Initialize a Devices object."""
        self.auth = info.auth
        self._info = info
        self._data: DevicesData | None = None

    @property
    def data(self) -> DevicesData | None:
        """Return the raw devices data."""
        return self._data

    @property
    def devices(self) -> list[Device]:
        """Return a list of devices."""
        return (
            [Device(self._info, device) for device in self.data.devices]
            if self.data
            else []
        )

    async def async_update(self) -> None:
        """Update the devices data."""
        response = await self.auth.get(self.path)
        self._data = DevicesData.model_validate(await response.json())
