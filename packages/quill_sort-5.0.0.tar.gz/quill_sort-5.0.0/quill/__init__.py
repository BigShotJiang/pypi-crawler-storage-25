"""
quill — Adaptive Ultra-Sort  (v5)
==================================
High-performance, general-purpose sorting for Python.

    from quill import quill_sort, quill_sorted, register_plugin, analyze

QUICK REFERENCE
---------------
    quill_sort(data)                                  # in-place
    quill_sort(data, key=lambda x: x['score'])        # objects
    quill_sort(data, reverse=True)                    # descending
    quill_sort(data, inplace=False)                   # new list
    quill_sort(data, parallel=True)                   # multi-core
    quill_sort(data, stable=False)                    # max speed (unstable)
    quill_sort(data, high_performance_mode=True)      # skip auth prompt for external sort
    quill_sort(data, silent=True)                     # suppress all output

    result = quill_sorted(iterable)
    register_plugin(MyPlugin)
    info = analyze(data)                              # inspect profiling

v5 IMPROVEMENTS
---------------
  - Stability fix: stable=True (default) uses kind='stable' for ALL dtypes,
    matching Python's sorted() contract exactly.  stable=False gives
    benchmark-optimal unstable speed.
  - Float NaN handling: NaN values are stripped, sorted data placed before them.
  - Mixed int/float promotion: [1, 2.5, 3] routes through float64, not object.
  - Nearly-sorted fast path: asc_ratio > 0.90 → Timsort O(n) bypass.
  - Adaptive parallel threshold: scales with core count.
  - Cache-aware counting sort: range fits in L2 → counting sort always.
  - Thread-safe plugin registry and process pool.
  - analyze() API: inspect how Quill would profile and sort your data.
  - Parallel float sort path via shared-memory numpy.
  - Comprehensive test suite (120+ tests, hypothesis property-based).
"""

from __future__ import annotations
import time
from typing import Callable, Iterable, Optional

from ._core    import quill_sort_impl, _identity, _profile
from ._plugins import QuillPlugin, register_plugin, probe_plugins

__version__ = "5.0.0"
__author__  = "Isaiah Tucker"
__all__     = [
    "quill_sort", "quill_sorted", "QuillPlugin",
    "register_plugin", "analyze",
]


def quill_sort(
    data                 ,
    key                  : Optional[Callable] = None,
    reverse              : bool = False,
    inplace              : bool = True,
    parallel             : bool = False,
    high_performance_mode: bool = False,
    silent               : bool = False,
    stable               : bool = True,
    stats                : bool = False,
) -> list:
    """
    Sort `data` using Quill's adaptive ultra-sort engine.

    Parameters
    ----------
    data                  : list (or generator, range, ndarray, Series…)
    key                   : callable — sort key function
    reverse               : bool — descending order if True
    inplace               : bool — sort in-place (default True)
    parallel              : bool — use all CPU cores
                            (auto-enabled on 4+ core machines for large n)
    high_performance_mode : bool — skip the authorization prompt when the
                            external sort path is triggered. Use this in
                            production code where you don't want interactive
                            prompts. Default False.
    silent                : bool — suppress all Quill status output.
    stable                : bool — True (default) guarantees sort stability,
                            matching Python's sorted() exactly. False allows
                            unstable sorts for maximum speed on numeric data.
    stats                 : bool — if True, return (sorted_list, stats_dict)
                            instead of just sorted_list.

    Returns
    -------
    list — the sorted list.
    (list, dict) — if stats=True, also returns timing and strategy info.

    Notes
    -----
    Quill automatically detects when a dataset exceeds available RAM and
    switches to an external merge sort using the qWrite binary format.
    On a machine with psutil installed (pip install quill-sort[fast]),
    it uses real memory readings. Otherwise it assumes 2GB available.

    NaN values in float data are placed at the end (or beginning if
    reverse=True), consistent with numpy's convention.
    """
    t0 = time.perf_counter() if stats else 0

    if not isinstance(data, list):
        from ._plugins import probe_plugins
        result = probe_plugins(data, key, reverse)
        if result is not None:
            items, pk, postprocess = result
            if postprocess and not items:
                out = postprocess([])
                if stats:
                    return out, {"time_ms": (time.perf_counter() - t0) * 1000,
                                 "strategy": "plugin_empty"}
                return out
            sorted_items = quill_sort(items, key=pk, reverse=reverse,
                                      inplace=True,
                                      high_performance_mode=high_performance_mode,
                                      silent=silent, stable=stable)
            out = postprocess(sorted_items) if postprocess else sorted_items
            if stats:
                return out, {"time_ms": (time.perf_counter() - t0) * 1000,
                             "strategy": "plugin"}
            return out
        data = list(data)

    result = quill_sort_impl(data, key, reverse, inplace, parallel,
                             high_performance_mode=high_performance_mode,
                             silent=silent, stable=stable)

    if stats:
        elapsed = (time.perf_counter() - t0) * 1000
        return result, {"time_ms": round(elapsed, 3), "n": len(result)}

    return result


def quill_sorted(
    iterable             : Iterable,
    key                  : Optional[Callable] = None,
    reverse              : bool = False,
    inplace              : bool = False,   # accepted for API symmetry; always returns a copy
    parallel             : bool = False,
    high_performance_mode: bool = False,
    silent               : bool = False,
    stable               : bool = True,
    stats                : bool = False,
) -> list:
    """
    Non-mutating quill_sort — mirrors Python's built-in sorted().

        result = quill_sorted(range(10, 0, -1))
        result = quill_sorted(words, key=str.lower, reverse=True)
        result = quill_sorted(big_data, parallel=True)
    """
    return quill_sort(list(iterable), key=key, reverse=reverse,
                      inplace=True, parallel=parallel,
                      high_performance_mode=high_performance_mode,
                      silent=silent, stable=stable, stats=stats)


def analyze(data, key=None):
    """
    Profile *data* and return a dict describing its characteristics.

    Useful for understanding which algorithm Quill would choose and why.

        >>> from quill import analyze
        >>> analyze([3, 1, 4, 1, 5, 9])
        {'n': 6, 'dtype': 'int_pos', 'presorted': False, ...}
    """
    if not isinstance(data, list):
        data = list(data)
    key_fn = key if key is not None else _identity
    p = _profile(data, key_fn)
    p["n"] = len(data)
    return p
