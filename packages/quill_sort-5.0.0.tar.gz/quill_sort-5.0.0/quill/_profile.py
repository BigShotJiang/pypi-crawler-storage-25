"""
quill/_profile.py
-----------------
Single-pass data profiler.

Samples up to 512 elements uniformly across the dataset and classifies
dtype, pre-sortedness, density, uniqueness, and special values (None, NaN).
"""

from __future__ import annotations
import random as _random

_SAMPLE = 512


def profile(data: list, key_fn) -> dict:
    """
    Profile a dataset by sampling up to 512 elements.

    Returns a dict with keys:
      n            : int   -- dataset length
      dtype        : str   -- one of 'int_pos', 'int_neg', 'int_mixed',
                              'float', 'str', 'bytes', 'object'
      presorted    : bool  -- True if sample is non-decreasing
      reversed     : bool  -- True if sample is non-increasing
      all_same     : bool  -- True if all sampled values are equal
      asc_ratio    : float -- fraction of adjacent pairs that are non-decreasing
      desc_ratio   : float -- fraction of adjacent pairs that are non-increasing
      dense        : bool  -- True if range <= 2*n (counting sort candidate)
      sparse       : bool  -- True if range > 100*n
      min_key      : comparable or None
      max_key      : comparable or None
      has_none     : bool  -- True if any sampled value is None
      has_nan      : bool  -- True if any sampled float is NaN
      n_unique_est : int or None -- estimated unique count from sample (ints only)
    """
    n = len(data)
    p = {
        "n": n, "dtype": "object",
        "presorted": False, "reversed": False, "all_same": False,
        "sparse": False, "dense": False,
        "min_key": None, "max_key": None,
        "has_none": False, "has_nan": False, "n_unique_est": None,
    }
    if n == 0:
        return p

    # Anti-aliasing: add a small random offset to prevent sampling artefacts
    # with periodic data (e.g., alternating [0, 1, 0, 1, ...]).
    step   = max(1, n // _SAMPLE)
    offset = _random.randint(0, max(0, step - 1)) if step > 1 else 0
    raw    = [data[min(i * step + offset, n - 1)] for i in range(min(_SAMPLE, n))]
    p["has_none"] = any(v is None for v in raw)
    keys   = [key_fn(v) for v in raw if v is not None]
    if not keys:
        return p

    s = len(keys)

    # Pre-sortedness
    try:
        asc  = sum(1 for i in range(s-1) if keys[i] <= keys[i+1])
        desc = sum(1 for i in range(s-1) if keys[i] >= keys[i+1])
        p["presorted"]  = (asc  == s-1)
        p["reversed"]   = (desc == s-1)
        p["all_same"]   = (asc  == s-1 and desc == s-1)
        p["asc_ratio"]  = asc  / (s - 1) if s > 1 else 1.0
        p["desc_ratio"] = desc / (s - 1) if s > 1 else 1.0
    except TypeError:
        p["asc_ratio"]  = 0.0
        p["desc_ratio"] = 0.0

    # Type detection
    sample_types = set(type(k) for k in keys)

    if sample_types <= {int}:
        mn, mx = min(keys), max(keys)
        p["min_key"] = mn
        p["max_key"] = mx
        rng = mx - mn
        p["dtype"]  = "int_pos" if mn >= 0 else ("int_neg" if mx < 0 else "int_mixed")
        p["dense"]  = (rng <= 2 * n)
        p["sparse"] = (rng > 100 * n)
        p["n_unique_est"] = len(set(keys))

    elif sample_types <= {float}:
        p["dtype"]   = "float"
        p["min_key"] = min(keys)
        p["max_key"] = max(keys)
        # NaN detection: NaN != NaN
        p["has_nan"] = any(v != v for v in keys)

    elif sample_types <= {int, float}:
        # Mixed int/float → promote to float path (common in real data)
        p["dtype"]   = "float"
        p["min_key"] = min(keys)
        p["max_key"] = max(keys)
        p["has_nan"] = any(isinstance(v, float) and v != v for v in keys)

    elif sample_types <= {str}:
        p["dtype"] = "str"
    elif sample_types <= {bytes}:
        p["dtype"] = "bytes"

    return p
