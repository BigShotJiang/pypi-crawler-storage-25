# Changelog

All notable changes to quill-sort will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/).

## [5.0.0] — 2026-04-13

### Added
- **`stable` parameter** (default `True`): guarantees sort stability matching Python's `sorted()` exactly. Set `stable=False` for maximum speed on numeric data (unstable).
- **`stats` parameter**: `quill_sort(data, stats=True)` returns `(sorted_list, stats_dict)` with timing info.
- **`analyze()` API**: inspect how Quill profiles your data — `from quill import analyze`.
- **Float NaN handling**: NaN values are stripped before sorting and placed at the end (or beginning with `reverse=True`).
- **Mixed int/float promotion**: lists like `[1, 2.5, 3]` now route through the fast float64 path instead of falling back to Python sort.
- **Nearly-sorted fast path**: when `asc_ratio > 0.90`, Quill bypasses numpy and uses Timsort (O(n) on nearly-sorted data).
- **Parallel float sort**: float data now uses shared-memory numpy sort in parallel (previously fell back to slow Python sort + merge).
- **Cache-aware counting sort**: counting sort triggered when range fits in L2 cache (~2MB), regardless of range/n ratio.
- **Adaptive parallel threshold**: auto-parallel threshold scales with core count instead of fixed 5M.
- **Anti-aliasing in profiler**: sampling adds jitter to prevent aliasing with periodic data patterns.
- **Thread-safe plugin registry**: `register_plugin()` and `probe_plugins()` are now thread-safe.
- **Thread-safe process pool**: parallel sort pool creation/shutdown protected by lock.
- Comprehensive test suite: 138 tests (pytest + hypothesis property-based).
- `LICENSE` file (MIT).
- `.gitignore`, `MANIFEST.in`, `py.typed` marker (PEP 561).
- CI/CD via GitHub Actions (Python 3.8–3.12).
- `CHANGELOG.md` (this file).
- Development dependencies in pyproject.toml (`pip install quill-sort[dev]`).
- Docstrings for all public and key internal functions.
- Python logging integration (`logging.getLogger("quill")`).

### Changed
- **BREAKING**: Default sort is now stable (`kind='stable'`) for ALL dtypes. Previously int32 used quicksort and int64 used heapsort (both unstable). This is slower for int32/int64 but correct. Use `stable=False` for the old fast-but-unstable behavior.
- **BREAKING**: Version bumped to 5.0.0.
- Renamed internal `insertion_sort` → `small_sort` (accurately describes its Timsort delegation).
- `_strip_nones` now uses single-pass instead of double-pass.
- `_kway_merge` now uses C-accelerated `heapq.merge` instead of manual heap.
- `np.fromiter` used for key extraction (saves ~40% memory vs list comprehension + np.array).
- Direct int32 array construction when profiler indicates int32 range (skips int64 intermediate).

### Fixed
- **Critical**: Sort stability for int32 and int64 data now matches Python's `sorted()`.
- **Critical**: Thread safety for process pool and plugin registry.
- NaN values no longer cause silent data corruption in float sorts.
- Mixed int/float lists no longer fall back to slow object sort.
- Profiler sampling no longer aliases with periodic data patterns.

## [4.0.23] — 2026-04-01

### Changed
- Benchmark-proven optimal sort kind per dtype (uint8/16 → radix, int32 → quicksort, int64 → heapsort).
- Heavy-key detection in parallel MSD radix sort.
- Persistent process pool to eliminate spawn overhead on Windows.
- Narrow-range short-circuit for counting sort.
