# tests/unit/adapters
