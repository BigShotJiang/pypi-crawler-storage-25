"""Kernel messaging – message primitives and bus ports."""

from __future__ import annotations

import abc
import dataclasses
from datetime import UTC, datetime
from typing import Any, Generic, TypeVar
from uuid import uuid4

T = TypeVar("T")

type EventName = str
type EventVersion = int
type MessageId = str


@dataclasses.dataclass(frozen=True)
class MessageHeaders:
    """Envelope metadata propagated with every message."""

    correlation_id: str | None = None
    tenant_id: str | None = None
    causation_id: str | None = None
    trace_id: str | None = None
    content_type: str = "application/json"
    schema_version: int = 1
    extra: dict[str, str] = dataclasses.field(default_factory=dict)


@dataclasses.dataclass(frozen=True)
class Message(Generic[T]):
    """Transport-agnostic message envelope."""

    id: MessageId = dataclasses.field(default_factory=lambda: str(uuid4()))
    topic: str = ""
    payload: T | None = None
    headers: MessageHeaders = dataclasses.field(default_factory=MessageHeaders)
    occurred_at: datetime = dataclasses.field(default_factory=lambda: datetime.now(UTC))


class MessageSerializer(abc.ABC, Generic[T]):
    """Port: serialize / deserialize message payloads."""

    @abc.abstractmethod
    def serialize(self, payload: T) -> bytes:
        """Encode *payload* into a byte string for transport."""
        ...

    @abc.abstractmethod
    def deserialize(self, data: bytes, target_type: type[T]) -> T:
        """Decode *data* bytes back into an instance of *target_type*."""
        ...


class MessageBus(abc.ABC):
    """Port: publish messages to a transport (Kafka, NATS, Redis Streams…)."""

    @abc.abstractmethod
    async def publish(self, message: Message[Any]) -> None:
        """Deliver a single *message* to the underlying transport."""
        ...

    @abc.abstractmethod
    async def publish_batch(self, messages: list[Message[Any]]) -> None:
        """Deliver multiple *messages* atomically or as a batch where possible."""
        ...


class EventPublisher(abc.ABC):
    """Port: domain-event publisher with routing by event type."""

    @abc.abstractmethod
    async def publish(
        self, topic: str, payload: Any, headers: MessageHeaders | None = None
    ) -> None:
        """Publish *payload* to *topic*, attaching optional *headers*."""
        ...


@dataclasses.dataclass(frozen=True)
class MessageEnvelope:
    """Wraps a raw ``Message`` with routing and tracing metadata.

    Intended as the wire-level envelope that travels through brokers,
    carrying the original payload bytes together with all the headers
    needed for routing, deduplication, and observability.
    """

    message_id: MessageId = dataclasses.field(default_factory=lambda: str(uuid4()))
    topic: str = ""
    payload: bytes = b""
    headers: MessageHeaders = dataclasses.field(default_factory=MessageHeaders)
    occurred_at: datetime = dataclasses.field(default_factory=lambda: datetime.now(UTC))
    #: Stable identifier of the originating aggregate / source.
    source: str = ""
    #: Consumer group this envelope is targeted at (empty = broadcast).
    consumer_group: str = ""


class EventConsumer(abc.ABC):
    """Port: subscribe to domain events."""

    @abc.abstractmethod
    async def subscribe(self, topic: str) -> None:
        """Register interest in events from *topic*."""
        ...

    @abc.abstractmethod
    async def start(self) -> None:
        """Begin consuming messages from all subscribed topics."""
        ...

    @abc.abstractmethod
    async def stop(self) -> None:
        """Gracefully stop consuming and release transport resources."""
        ...


__all__ = [
    "EventConsumer",
    "EventName",
    "EventPublisher",
    "EventVersion",
    "Message",
    "MessageBus",
    "MessageEnvelope",
    "MessageHeaders",
    "MessageId",
    "MessageSerializer",
]
