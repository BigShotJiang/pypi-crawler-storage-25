"""Application inbox – InboxRecord, InboxStore port, and in-memory implementation."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, Protocol
import uuid

__all__ = [
    "InMemoryInboxStore",
    "InboxRecord",
    "InboxStatus",
    "InboxStore",
]


class InboxStatus(StrEnum):
    """Lifecycle states of an :class:`InboxRecord`."""

    PENDING = "PENDING"
    PROCESSED = "PROCESSED"
    FAILED = "FAILED"
    DUPLICATE = "DUPLICATE"


@dataclass
class InboxRecord:
    """Persisted inbound event for at-least-once / exactly-once processing."""

    source: str
    event_type: str
    payload: Any
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    received_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    processed_at: datetime | None = None
    status: InboxStatus = InboxStatus.PENDING
    error: str | None = None


class InboxStore(Protocol):
    """Port: persistence contract for the transactional inbox."""

    async def save(self, record: InboxRecord) -> None:
        """Persist or update *record* in the store."""
        ...

    async def load(self, record_id: str) -> InboxRecord | None:
        """Return the record with *record_id*, or ``None`` if not found."""
        ...

    async def is_duplicate(self, record_id: str) -> bool:
        """Return ``True`` if *record_id* has already been successfully processed."""
        ...


class InMemoryInboxStore:
    """In-memory implementation of :class:`InboxStore` — suitable for tests."""

    def __init__(self) -> None:
        self._records: dict[str, InboxRecord] = {}

    async def save(self, record: InboxRecord) -> None:
        """Upsert *record* into the in-memory store."""
        self._records[record.id] = record

    async def load(self, record_id: str) -> InboxRecord | None:
        """Return the record with *record_id*, or ``None`` if absent."""
        return self._records.get(record_id)

    async def is_duplicate(self, record_id: str) -> bool:
        """Return ``True`` when *record_id* exists and its status is ``PROCESSED``."""
        rec = self._records.get(record_id)
        return rec is not None and rec.status == InboxStatus.PROCESSED
