"""SQLAlchemy adapter – UoW, repositories, outbox/inbox/idempotency, audit."""

from mp_commons.adapters.sqlalchemy.audit import SQLAlchemyAuditStore
from mp_commons.adapters.sqlalchemy.event_store import SQLAlchemyEventStore
from mp_commons.adapters.sqlalchemy.idempotency import SqlAlchemyIdempotencyStore
from mp_commons.adapters.sqlalchemy.mixins import SoftDeleteMixin, TimestampMixin
from mp_commons.adapters.sqlalchemy.outbox import SqlAlchemyOutboxRepository
from mp_commons.adapters.sqlalchemy.repository import SqlAlchemyRepositoryBase
from mp_commons.adapters.sqlalchemy.session import SqlAlchemySessionFactory
from mp_commons.adapters.sqlalchemy.specification import (
    SQLAlchemyAndSpecification,
    SQLAlchemyNotSpecification,
    SQLAlchemyOrSpecification,
    SQLAlchemySpecification,
)
from mp_commons.adapters.sqlalchemy.tenant_filter import TenantFilter
from mp_commons.adapters.sqlalchemy.uow import SqlAlchemyUnitOfWork

__all__ = [
    "SQLAlchemyAndSpecification",
    "SQLAlchemyAuditStore",
    "SQLAlchemyEventStore",
    "SQLAlchemyNotSpecification",
    "SQLAlchemyOrSpecification",
    "SQLAlchemySpecification",
    "SoftDeleteMixin",
    "SqlAlchemyIdempotencyStore",
    "SqlAlchemyOutboxRepository",
    "SqlAlchemyRepositoryBase",
    "SqlAlchemySessionFactory",
    "SqlAlchemyUnitOfWork",
    "TenantFilter",
    "TimestampMixin",
]
