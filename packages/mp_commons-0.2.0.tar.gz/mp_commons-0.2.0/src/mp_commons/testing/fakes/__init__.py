"""Testing fakes – in-memory doubles for kernel ports."""

from mp_commons.kernel.time import FrozenClock
from mp_commons.testing.fakes.clock import FakeClock
from mp_commons.testing.fakes.feature_flags import FakeFeatureFlagProvider
from mp_commons.testing.fakes.idempotency import InMemoryIdempotencyStore
from mp_commons.testing.fakes.inbox import InMemoryInboxRepository
from mp_commons.testing.fakes.message_bus import InMemoryMessageBus
from mp_commons.testing.fakes.metrics import FakeMetricsRegistry
from mp_commons.testing.fakes.outbox import InMemoryOutboxRepository
from mp_commons.testing.fakes.policy import FakePolicyEngine
from mp_commons.testing.fakes.secrets import FakeSecretStore

__all__ = [
    "FakeClock",
    "FakeFeatureFlagProvider",
    "FakeMetricsRegistry",
    "FakePolicyEngine",
    "FakeSecretStore",
    "FrozenClock",
    "InMemoryIdempotencyStore",
    "InMemoryInboxRepository",
    "InMemoryMessageBus",
    "InMemoryOutboxRepository",
]
