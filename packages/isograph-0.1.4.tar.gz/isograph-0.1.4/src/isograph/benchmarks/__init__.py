"""Benchmark dataset generation."""
