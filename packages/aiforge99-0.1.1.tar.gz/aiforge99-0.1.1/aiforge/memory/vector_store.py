from aiforge.runtime.errors import NotImplementedFeatureError


class VectorStore:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("memory.vector_store (embedding-based vector storage)")
