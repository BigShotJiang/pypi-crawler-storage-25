from aiforge.runtime.errors import NotImplementedFeatureError


class Summarizer:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("memory.summarizer (LLM-based history summarization)")
