"""
Context window compression.

When session memory grows too large to fit in the model's context window,
this module compresses the oldest messages into a compact summary block,
preserving the most recent messages verbatim.

Strategy:
  1. Estimate token count from character length (approx 4 chars per token)
  2. If total estimated tokens > threshold, summarize the oldest half
  3. Replace summarized messages with a single "history summary" message
  4. Always keep the last N messages verbatim for fresh context
"""
from __future__ import annotations

import json
from typing import Any


# Conservative token estimate: 4 chars ≈ 1 token
_CHARS_PER_TOKEN = 4

# Compress when estimated tokens exceed this threshold
DEFAULT_MAX_TOKENS = 6000

# Always keep the most recent K messages uncompressed
MIN_KEEP_RECENT = 20


def estimate_tokens(messages: list[dict]) -> int:
    """Estimate token count for a list of message dicts."""
    total = 0
    for m in messages:
        content = m.get("content", "")
        total += len(content) // _CHARS_PER_TOKEN
    return total


def _summarize_messages(messages: list[dict]) -> str:
    """Build a compact plain-text summary of a block of messages."""
    lines = ["[Compressed history summary]"]
    for m in messages:
        role = m.get("role", "?")
        content = m.get("content", "")
        try:
            obj = json.loads(content)
            if "task" in obj:
                lines.append(f"USER TASK: {obj['task']}")
            elif "action" in obj and obj["action"] == "final":
                lines.append(f"COMPLETED: {obj.get('result', '')[:120]}")
            elif "action" in obj:
                args_preview = str(obj.get("args", {}))[:80]
                lines.append(f"  ACTION: {obj['action']} {args_preview}")
            elif "observation" in obj:
                obs = obj["observation"]
                ok = "ok" if obs.get("success") else "FAILED"
                out = str(obs.get("output", ""))[:80]
                lines.append(f"  RESULT({ok}): {out}")
            else:
                lines.append(f"  [{role}]: {str(obj)[:80]}")
        except (json.JSONDecodeError, TypeError):
            preview = str(content)[:80]
            lines.append(f"  [{role}]: {preview}")
    return "\n".join(lines)


def compress_messages(
    messages: list[dict],
    max_tokens: int = DEFAULT_MAX_TOKENS,
    min_keep_recent: int = MIN_KEEP_RECENT,
) -> list[dict]:
    """
    Compress messages if they exceed the token threshold.

    Returns a (possibly shorter) list where old messages are replaced
    by a single summary message. Always preserves the last min_keep_recent
    messages verbatim.

    :param messages:        Full message list (role/content dicts).
    :param max_tokens:      Token threshold above which compression triggers.
    :param min_keep_recent: Always keep this many recent messages uncompressed.
    :returns:               Compressed message list.
    """
    if estimate_tokens(messages) <= max_tokens:
        return messages

    if len(messages) <= min_keep_recent:
        return messages

    # Split: compress the old half, keep the recent part
    keep_count = max(min_keep_recent, len(messages) // 2)
    compress_count = len(messages) - keep_count

    to_compress = messages[:compress_count]
    to_keep = messages[compress_count:]

    summary_text = _summarize_messages(to_compress)
    summary_message = {
        "role": "user",
        "content": json.dumps({"history_summary": summary_text}),
    }

    result = [summary_message] + to_keep

    # Recurse if still too large
    if estimate_tokens(result) > max_tokens and len(result) > min_keep_recent + 1:
        return compress_messages(result, max_tokens, min_keep_recent)

    return result
