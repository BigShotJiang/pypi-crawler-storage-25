from aiforge.memory.long_term import LongTermMemory


class RecallEngine:
    def __init__(self, long_term: LongTermMemory):
        self.long_term = long_term

    def recall(self, query: str, limit: int = 10) -> list[dict]:
        results = self.long_term.search(query)
        return results[-limit:]
