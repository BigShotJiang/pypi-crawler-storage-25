import json
from pathlib import Path
from typing import Any

from aiforge.utils.time import utcnow_iso


def _memory_dir() -> Path:
    from aiforge.runtime.workspace import resolve_workspace
    return resolve_workspace() / ".aiforge" / "memory"


class LongTermMemory:
    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else _memory_dir() / "long_term.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.touch()

    def add(self, kind: str, content: Any, **metadata) -> None:
        record = {"ts": utcnow_iso(), "kind": kind, "content": content, "metadata": metadata}
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, default=str) + "\n")

    def all(self) -> list[dict]:
        records: list[dict] = []
        with self.path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return records

    def search(self, substring: str) -> list[dict]:
        s = substring.lower()
        return [r for r in self.all() if s in json.dumps(r, default=str).lower()]

    def clear(self) -> None:
        self.path.write_text("", encoding="utf-8")
