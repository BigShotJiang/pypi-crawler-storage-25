from pathlib import Path

from aiforge.utils.hashing import sha256_file


class FileIndex:
    def __init__(self, root: str | Path = "."):
        self.root = Path(root)
        self._hashes: dict[str, str] = {}

    def index(self, skip: set[str] | None = None) -> dict[str, str]:
        skip = skip or {".git", "__pycache__", "node_modules", ".venv", ".aiforge",
                        ".cache", ".pythonlibs", "aiforge.egg-info"}
        self._hashes.clear()
        for p in self.root.rglob("*"):
            if not p.is_file():
                continue
            if any(part in skip for part in p.parts):
                continue
            try:
                self._hashes[str(p)] = sha256_file(p)
            except Exception:
                continue
        return dict(self._hashes)

    def changed_since(self, previous: dict[str, str]) -> list[str]:
        current = self._hashes or self.index()
        changed = []
        for path, h in current.items():
            if previous.get(path) != h:
                changed.append(path)
        for path in previous:
            if path not in current:
                changed.append(path)
        return changed
