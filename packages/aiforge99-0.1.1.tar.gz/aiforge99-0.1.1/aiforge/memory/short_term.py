from collections import deque
from typing import Any


class ShortTermMemory:
    def __init__(self, max_items: int = 64):
        self._buf: deque = deque(maxlen=max_items)

    def add(self, item: Any) -> None:
        self._buf.append(item)

    def all(self) -> list[Any]:
        return list(self._buf)

    def clear(self) -> None:
        self._buf.clear()

    def __len__(self) -> int:
        return len(self._buf)
