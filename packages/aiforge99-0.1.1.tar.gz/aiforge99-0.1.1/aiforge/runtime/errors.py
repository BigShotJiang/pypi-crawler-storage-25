class AIForgeError(Exception):
    pass


class ConfigError(AIForgeError):
    pass


class ToolError(AIForgeError):
    pass


class ToolNotFoundError(ToolError):
    pass


class ToolPermissionError(ToolError):
    pass


class ToolTimeoutError(ToolError):
    pass


class ModelError(AIForgeError):
    pass


class ModelNotConfiguredError(ModelError):
    pass


class AgentError(AIForgeError):
    pass


class PlanError(AgentError):
    pass


class ExecutionError(AgentError):
    pass


class NotImplementedFeatureError(AIForgeError, NotImplementedError):
    def __init__(self, feature: str):
        super().__init__(f"NOT IMPLEMENTED: {feature}")
        self.feature = feature
