from collections import defaultdict
from typing import Callable


class HookRegistry:
    def __init__(self):
        self._hooks: dict[str, list[Callable]] = defaultdict(list)

    def register(self, event: str, fn: Callable) -> None:
        self._hooks[event].append(fn)

    def trigger(self, event: str, *args, **kwargs) -> list:
        return [fn(*args, **kwargs) for fn in self._hooks.get(event, [])]
