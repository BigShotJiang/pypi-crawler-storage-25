import signal
from contextlib import contextmanager


class Interrupted(Exception):
    pass


@contextmanager
def interruptible():
    triggered = {"v": False}

    def handler(signum, frame):
        triggered["v"] = True
        raise Interrupted("Interrupted by user")

    prev = signal.signal(signal.SIGINT, handler)
    try:
        yield triggered
    finally:
        signal.signal(signal.SIGINT, prev)
