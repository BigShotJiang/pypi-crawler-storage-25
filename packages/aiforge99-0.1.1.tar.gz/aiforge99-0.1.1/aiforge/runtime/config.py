import json
from pathlib import Path
from typing import Any

from aiforge.runtime.errors import ConfigError

DEFAULT_CONFIG_PATH = Path(".aiforge/config.json")

DEFAULT_SETTINGS: dict[str, Any] = {
    "default_provider": "",
    "providers": {
        "zapi": {"enabled": False, "model": "qwen-3-235b-a22b-instruct-2507"},
        "openai": {"enabled": False, "model": "gpt-4o-mini"},
        "openrouter": {"enabled": False, "model": ""},
        "ollama": {"enabled": False, "host": "http://localhost:11434", "model": "llama3.2"},
    },
}


class Config:
    def __init__(self, config_path: str | Path = DEFAULT_CONFIG_PATH):
        self.config_path = Path(config_path)
        self.settings: dict[str, Any] = {}
        self.load()

    def load(self) -> dict[str, Any]:
        if not self.config_path.exists():
            # First run — create a default config file instead of crashing.
            self.settings = json.loads(json.dumps(DEFAULT_SETTINGS))
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            with self.config_path.open("w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=2)
            return self.settings
        with self.config_path.open("r", encoding="utf-8") as f:
            try:
                self.settings = json.load(f)
            except json.JSONDecodeError as e:
                raise ConfigError(f"Invalid JSON in {self.config_path}: {e}") from e
        return self.settings

    def save(self) -> None:
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        with self.config_path.open("w", encoding="utf-8") as f:
            json.dump(self.settings, f, indent=2)

    def get(self, key: str, default: Any = None) -> Any:
        node: Any = self.settings
        for part in key.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    def set(self, key: str, value: Any) -> None:
        parts = key.split(".")
        node = self.settings
        for part in parts[:-1]:
            if part not in node or not isinstance(node[part], dict):
                node[part] = {}
            node = node[part]
        node[parts[-1]] = value
