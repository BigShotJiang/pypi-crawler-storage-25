from pathlib import Path

from aiforge.runtime.errors import ToolPermissionError


def assert_path_within(path: str | Path, root: str | Path) -> Path:
    p = Path(path).resolve()
    r = Path(root).resolve()
    try:
        p.relative_to(r)
    except ValueError as e:
        raise ToolPermissionError(f"Path '{p}' is outside allowed root '{r}'") from e
    return p
