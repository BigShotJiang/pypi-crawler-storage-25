from __future__ import annotations

import os
from pathlib import Path

from aiforge.runtime.config import Config
from aiforge.runtime.env import load_env


def _aiforge_home() -> Path:
    """
    Resolve the .aiforge home directory.

    If AIFORGE_HOME env var is set, use it directly (absolute).
    Otherwise, place .aiforge inside the resolved workspace root.
    This ensures the config dir moves with the workspace on all platforms.
    """
    env_home = os.environ.get("AIFORGE_HOME", "").strip()
    if env_home:
        return Path(env_home).expanduser().resolve()

    from aiforge.runtime.workspace import resolve_workspace
    return resolve_workspace() / ".aiforge"


# Lazy path properties — always computed from the current workspace so they
# work correctly after a WorkspaceSwitcher.switch() call or env-var change.
def _home() -> Path:
    return _aiforge_home()


AIFORGE_HOME: Path = _home()
SESSIONS_DIR: Path = AIFORGE_HOME / "sessions"
MEMORY_DIR: Path = AIFORGE_HOME / "memory"
LOGS_DIR: Path = AIFORGE_HOME / "logs"
CACHE_DIR: Path = AIFORGE_HOME / "cache"


def ensure_dirs() -> None:
    """Create all required runtime directories under the workspace's .aiforge home."""
    home = _aiforge_home()
    for d in (home, home / "sessions", home / "memory", home / "logs", home / "cache"):
        d.mkdir(parents=True, exist_ok=True)


class Runtime:
    def __init__(self, config_path: str | Path | None = None):
        load_env()
        ensure_dirs()
        home = _aiforge_home()
        cfg_path = config_path or (home / "config.json")
        self.config = Config(cfg_path)
