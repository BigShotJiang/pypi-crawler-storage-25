import os
from pathlib import Path
from dotenv import load_dotenv


def load_env(dotenv_path: str | Path = ".env") -> None:
    path = Path(dotenv_path)
    if path.exists():
        load_dotenv(dotenv_path=path, override=False)


def get(name: str, default: str | None = None) -> str | None:
    return os.environ.get(name, default)


def require(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        from aiforge.runtime.errors import ConfigError
        raise ConfigError(f"Required environment variable '{name}' is not set")
    return value
