"""
Portable workspace resolver.

Resolution priority (highest → lowest):
  1. AIFORGE_WORKSPACE environment variable
  2. "workspace" key in .aiforge/config.json
  3. Path.cwd()

Agent user workspace:
  All agent file operations are scoped to <workspace_root>/aiforge/user/
  This keeps sensitive project files safe and isolated.

Works identically on Replit, Termux, Linux, macOS, Windows, and any other platform.
No hardcoded paths anywhere.
"""
from __future__ import annotations

import os
from pathlib import Path


def resolve_workspace() -> Path:
    """Return the resolved, absolute workspace root for this session."""

    # 1. Environment variable override
    env_val = os.environ.get("AIFORGE_WORKSPACE", "").strip()
    if env_val:
        candidate = Path(env_val).expanduser().resolve()
        if candidate.exists() and candidate.is_dir():
            return candidate
        return candidate

    # 2. config.json "workspace" field
    try:
        from aiforge.runtime.config import Config
        cfg = Config()
        ws_cfg = cfg.get("workspace")
        if ws_cfg and isinstance(ws_cfg, str) and ws_cfg.strip():
            candidate = Path(ws_cfg.strip()).expanduser().resolve()
            return candidate
    except Exception:
        pass

    # 3. Current working directory (always works, always portable)
    return Path.cwd().resolve()


def workspace_str() -> str:
    """Convenience wrapper returning the workspace as a plain string."""
    return str(resolve_workspace())


def resolve_user_workspace() -> Path:
    """
    Return the agent's isolated working directory.

    This is <workspace_root>/aiforge/user/ — the sandbox where the agent
    creates and modifies files. Project source code and config files in the
    workspace root are never touched by the agent.

    The directory is created automatically on first access.
    """
    user_ws = resolve_workspace() / "aiforge" / "user"
    user_ws.mkdir(parents=True, exist_ok=True)
    return user_ws


def user_workspace_str() -> str:
    """Convenience wrapper returning the user workspace as a plain string."""
    return str(resolve_user_workspace())
