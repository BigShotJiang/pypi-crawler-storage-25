from aiforge.runtime.errors import NotImplementedFeatureError


def safe_exec(*args, **kwargs):
    raise NotImplementedFeatureError("utils.safe_exec (sandboxed Python execution)")
