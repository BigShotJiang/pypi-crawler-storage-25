from typing import Any

from aiforge.runtime.errors import ConfigError


def require_keys(d: dict, keys: list[str], context: str = "") -> None:
    missing = [k for k in keys if k not in d]
    if missing:
        prefix = f"{context}: " if context else ""
        raise ConfigError(f"{prefix}missing required keys {missing}")


def require_type(value: Any, expected: type, name: str = "value") -> None:
    if not isinstance(value, expected):
        raise ConfigError(f"{name} must be {expected.__name__}, got {type(value).__name__}")
