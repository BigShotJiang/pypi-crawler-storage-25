from pathlib import Path
from typing import Iterator


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def list_files(path: str | Path, pattern: str = "*") -> list[Path]:
    return sorted(Path(path).glob(pattern))


def walk(path: str | Path, skip: set[str] | None = None) -> Iterator[Path]:
    skip = skip or set()
    for p in Path(path).rglob("*"):
        if any(part in skip for part in p.parts):
            continue
        yield p
