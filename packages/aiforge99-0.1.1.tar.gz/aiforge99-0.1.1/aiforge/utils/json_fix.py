"""
Aggressive JSON extraction and repair utilities.

Handles all common model output problems:
- JSON wrapped in markdown code blocks
- Preamble text before the JSON
- Trailing commas
- Single quotes instead of double quotes
- Unescaped backslashes
- Truncated/partial JSON
"""
from __future__ import annotations

import json
import re
from typing import Any


def try_parse_json(text: str) -> Any | None:
    if not text:
        return None
    # Direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # Strip backticks and "json" label
    cleaned = text.strip().strip("`").strip()
    if cleaned.lower().startswith("json"):
        cleaned = cleaned[4:].lstrip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    return None


def _repair_json(text: str) -> str | None:
    """Apply heuristic repairs to malformed JSON strings."""
    s = text.strip()

    # Remove trailing commas before } or ]
    s = re.sub(r",\s*([}\]])", r"\1", s)

    # Replace single-quoted strings with double-quoted (simple cases)
    # Only do this if there are no double quotes already (to avoid breaking valid JSON)
    if '"' not in s and "'" in s:
        s = s.replace("'", '"')

    # Fix unescaped backslashes inside strings (common model mistake)
    # This is very conservative — only fix \n \t \r that aren't already escaped
    try:
        return s
    except Exception:
        return None


def extract_json(text: str) -> Any:
    """
    Extract and parse the first JSON object/array from model output.

    Tries in order:
      1. Content inside ``` or ```json fences
      2. Direct parse of full text
      3. Outermost { ... } block
      4. Outermost [ ... ] block
      5. After any preamble text (scan from first { or [)
      6. Repaired version of each above

    Raises ValueError if nothing works.
    """
    # 1. Fenced code block
    for m in re.finditer(r"```(?:json|JSON)?\s*(.*?)```", text, re.DOTALL):
        candidate = m.group(1).strip()
        parsed = try_parse_json(candidate)
        if parsed is not None:
            return parsed
        repaired = _repair_json(candidate)
        if repaired:
            parsed = try_parse_json(repaired)
            if parsed is not None:
                return parsed

    # 2. Full text direct parse
    parsed = try_parse_json(text)
    if parsed is not None:
        return parsed

    # 3. Scan for outermost { }
    brace_start = text.find("{")
    if brace_start != -1:
        # Find the matching closing brace
        depth = 0
        in_string = False
        escape_next = False
        for i in range(brace_start, len(text)):
            c = text[i]
            if escape_next:
                escape_next = False
                continue
            if c == "\\" and in_string:
                escape_next = True
                continue
            if c == '"':
                in_string = not in_string
            elif not in_string:
                if c == "{":
                    depth += 1
                elif c == "}":
                    depth -= 1
                    if depth == 0:
                        candidate = text[brace_start:i + 1]
                        parsed = try_parse_json(candidate)
                        if parsed is not None:
                            return parsed
                        repaired = _repair_json(candidate)
                        if repaired:
                            parsed = try_parse_json(repaired)
                            if parsed is not None:
                                return parsed
                        break

        # Fallback: rfind }
        brace_end = text.rfind("}")
        if brace_end > brace_start:
            candidate = text[brace_start:brace_end + 1]
            parsed = try_parse_json(candidate)
            if parsed is not None:
                return parsed
            repaired = _repair_json(candidate)
            if repaired:
                parsed = try_parse_json(repaired)
                if parsed is not None:
                    return parsed

    # 4. Outermost [ ]
    arr_start = text.find("[")
    arr_end = text.rfind("]")
    if arr_start != -1 and arr_end != -1 and arr_end > arr_start:
        candidate = text[arr_start:arr_end + 1]
        parsed = try_parse_json(candidate)
        if parsed is not None:
            return parsed

    # 5. Try repaired full text
    repaired = _repair_json(text)
    if repaired and repaired != text:
        parsed = try_parse_json(repaired)
        if parsed is not None:
            return parsed

    raise ValueError(f"No valid JSON found in model response (length={len(text)})")
