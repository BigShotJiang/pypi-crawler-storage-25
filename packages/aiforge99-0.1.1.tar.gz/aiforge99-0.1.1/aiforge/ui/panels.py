from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


def show_panel(title: str, body: str, style: str = "cyan") -> None:
    console.print(Panel(body, title=title, border_style=style))


def show_table(title: str, columns: list[str], rows: list[list[str]]) -> None:
    table = Table(title=title)
    for c in columns:
        table.add_column(c)
    for r in rows:
        table.add_row(*[str(x) for x in r])
    console.print(table)
