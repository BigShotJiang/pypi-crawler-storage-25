from rich.console import Console
from rich.syntax import Syntax

console = Console()


def show_diff(diff_text: str) -> None:
    if not diff_text.strip():
        console.print("[dim](no diff)[/]")
        return
    console.print(Syntax(diff_text, "diff", theme="ansi_dark", line_numbers=False))
