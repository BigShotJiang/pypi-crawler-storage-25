from contextlib import contextmanager

from rich.progress import Progress, SpinnerColumn, TextColumn


@contextmanager
def spinner(label: str):
    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), transient=True) as p:
        task = p.add_task(label, total=None)
        try:
            yield
        finally:
            p.remove_task(task)
