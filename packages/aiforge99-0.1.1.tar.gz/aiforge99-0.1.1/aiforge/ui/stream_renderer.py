from typing import Iterable

from rich.console import Console

console = Console()


def render_stream(chunks: Iterable[str]) -> str:
    out: list[str] = []
    for chunk in chunks:
        out.append(chunk)
        console.print(chunk, end="", soft_wrap=True, markup=False)
    console.print()
    return "".join(out)
