from rich.console import Console

from aiforge.ui import colors

console = Console()


def banner(version: str, model: str | None) -> None:
    console.rule(f"[{colors.SYSTEM}]AIForge {version}[/]")
    if model:
        console.print(f"[{colors.INFO}]model:[/] {model}")
    console.print("[dim]Type ':help' for commands, ':quit' to exit.[/]")


def user(message: str) -> None:
    console.print(f"[{colors.USER}]you[/]> {message}")


def agent(message: str) -> None:
    console.print(f"[{colors.AGENT}]agent[/]> {message}")


def thought(message: str) -> None:
    console.print(f"  [{colors.THOUGHT}]thought:[/] {message}")


def tool_call(name: str, args: dict) -> None:
    console.print(f"  [{colors.TOOL}]→ {name}[/] {args}")


def tool_result(success: bool, output: str) -> None:
    tag = colors.SUCCESS if success else colors.ERROR
    console.print(f"  [{tag}]← {'ok' if success else 'fail'}[/] {output}")
