from rich.console import Console

from aiforge.ui import colors

console = Console()


def info(message: str) -> None:
    console.print(f"[{colors.INFO}]i[/] {message}")


def success(message: str) -> None:
    console.print(f"[{colors.SUCCESS}]✓[/] {message}")


def warn(message: str) -> None:
    console.print(f"[{colors.WARN}]![/] {message}")


def error(message: str) -> None:
    console.print(f"[{colors.ERROR}]x[/] {message}")


def system(message: str) -> None:
    console.print(f"[{colors.SYSTEM}]{message}[/]")
