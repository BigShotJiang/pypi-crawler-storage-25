from aiforge.runtime.errors import NotImplementedFeatureError


class Scheduler:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("agent.scheduler (concurrent task scheduling)")
