from aiforge.runtime.errors import AgentError


class AgentStateMachine:
    STATES = ("idle", "planning", "executing", "observing", "verifying", "completed", "failed", "interrupted")
    TRANSITIONS = {
        "idle": {"planning"},
        "planning": {"executing", "failed", "interrupted"},
        "executing": {"observing", "failed", "interrupted"},
        "observing": {"planning", "verifying", "completed", "failed", "interrupted"},
        "verifying": {"completed", "planning", "failed"},
        "completed": {"idle"},
        "failed": {"idle"},
        "interrupted": {"idle"},
    }

    def __init__(self):
        self.state = "idle"
        self.history: list[str] = ["idle"]

    def transition(self, target: str) -> None:
        if target not in self.STATES:
            raise AgentError(f"Unknown state: {target}")
        if target not in self.TRANSITIONS.get(self.state, set()):
            raise AgentError(f"Illegal transition: {self.state} -> {target}")
        self.state = target
        self.history.append(target)
