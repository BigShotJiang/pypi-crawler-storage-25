import time
from typing import Callable, TypeVar

T = TypeVar("T")


class RetryEngine:
    def __init__(self, max_retries: int = 3, backoff: float = 0.5):
        self.max_retries = max_retries
        self.backoff = backoff

    def call(self, fn: Callable[[], T], retry_on: tuple[type[BaseException], ...] = (Exception,)) -> T:
        last_exc: BaseException | None = None
        for attempt in range(self.max_retries + 1):
            try:
                return fn()
            except retry_on as e:
                last_exc = e
                if attempt == self.max_retries:
                    raise
                time.sleep(self.backoff * (2 ** attempt))
        if last_exc:
            raise last_exc
        raise RuntimeError("retry loop exited without result")
