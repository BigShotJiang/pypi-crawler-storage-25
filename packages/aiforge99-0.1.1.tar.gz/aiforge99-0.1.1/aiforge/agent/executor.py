from aiforge.agent.planner import Step
from aiforge.tools.dispatcher import ToolDispatcher
from aiforge.tools.result import ToolResult


class Executor:
    def __init__(self, dispatcher: ToolDispatcher):
        self.dispatcher = dispatcher

    def execute(self, step: Step) -> ToolResult:
        if step.is_final:
            return ToolResult.ok(step.final_result, final=True)
        return self.dispatcher.dispatch(step.action, **step.args)
