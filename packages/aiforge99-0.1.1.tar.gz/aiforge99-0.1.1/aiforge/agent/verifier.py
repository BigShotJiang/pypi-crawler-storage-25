from aiforge.tools.result import ToolResult


class Verifier:
    def verify(self, result: ToolResult) -> bool:
        return bool(result.success)

    def is_final(self, result: ToolResult) -> bool:
        return bool(result.metadata.get("final"))
