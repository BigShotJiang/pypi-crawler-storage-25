from aiforge.runtime.errors import NotImplementedFeatureError


class TraceLinker:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("agent.trace_linker (cross-step trace correlation)")
