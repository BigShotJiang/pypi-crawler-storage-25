"""
AIForge Planner — converts LLM output into structured Steps.

Key improvements:
  - Planning phase: dedicated pre-execution call to outline all steps
  - Parse retry: when JSON extraction fails, sends a clarification prompt
    asking the model to try again (up to 3 retries)
  - Multi-action support: can parse array of actions for batch execution
  - Robust fallbacks at every level
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Callable

from aiforge.models.base import BaseModel, ChatRequest, Message
from aiforge.models.response_parser import extract_json
from aiforge.runtime.errors import PlanError


RETRY_PROMPT = """\
Your previous response could not be parsed as JSON. Please respond with ONLY a valid JSON object, nothing else.

Required format:
{"thought": "your reasoning here", "action": "tool_name", "args": {"param": "value"}}

Or if the task is complete:
{"thought": "your reasoning here", "action": "final", "result": "summary for user"}

No markdown, no explanation, no code blocks. Just the raw JSON object."""


PLAN_SYSTEM = """\
You are a planning assistant. Given a task, output a concise numbered plan of the steps an autonomous agent will take.
Be specific about which tools will be used. Keep it under 15 steps. Format as a simple numbered list, no JSON needed."""


@dataclass
class Step:
    thought: str
    action: str
    args: dict[str, Any]
    is_final: bool = False
    final_result: str = ""


@dataclass
class BatchStep:
    """Multiple actions to execute in parallel (one round)."""
    steps: list[Step] = field(default_factory=list)
    is_batch: bool = True


class Planner:
    def __init__(self, model: BaseModel):
        self.model = model

    # ── Planning phase ─────────────────────────────────────────────────────────

    def create_plan(self, task: str, tool_names: list[str]) -> str:
        """
        Generate a high-level execution plan for the task before starting the loop.
        Returns a plain-text plan string (not JSON). Returns empty string on failure.
        """
        tools_str = ", ".join(tool_names[:20])
        messages = [
            Message(role="system", content=PLAN_SYSTEM),
            Message(role="user", content=(
                f"Task: {task}\n\n"
                f"Available tools: {tools_str}\n\n"
                "Create a numbered plan for how to complete this task step by step."
            )),
        ]
        try:
            req = ChatRequest(messages=messages, temperature=0.1, max_tokens=500)
            return self.model.chat(req).strip()
        except Exception:
            return ""

    # ── Single step ────────────────────────────────────────────────────────────

    def next_step(self, messages: list[Message]) -> Step:
        request = ChatRequest(messages=messages, temperature=0.1)
        text = self.model.chat(request)
        return self._parse_with_retry(text, messages)

    def next_step_streaming(
        self,
        messages: list[Message],
        token_cb: Callable[[str], None] | None = None,
    ) -> Step:
        """
        Stream model response token-by-token, invoke token_cb per chunk, then parse.
        Retries with a clarification prompt on JSON parse failure.
        Falls back to blocking chat() if streaming is not supported.
        """
        request = ChatRequest(messages=messages, temperature=0.1)
        buffer: list[str] = []
        try:
            for chunk in self.model.stream(request):
                if chunk:
                    buffer.append(chunk)
                    if token_cb:
                        token_cb(chunk)
            text = "".join(buffer)
        except Exception as e:
            from aiforge.runtime.errors import ModelError, PlanError as _PE
            if isinstance(e, (_PE, ModelError)):
                raise
            if not buffer:
                text = self.model.chat(request)
                if token_cb:
                    token_cb(text)
            else:
                text = "".join(buffer)

        return self._parse_with_retry(text, messages, token_cb=token_cb)

    # ── Internals ──────────────────────────────────────────────────────────────

    def _parse_with_retry(
        self,
        text: str,
        original_messages: list[Message],
        token_cb: Callable[[str], None] | None = None,
        max_retries: int = 3,
    ) -> Step:
        """Try to parse text as a Step. On failure, send a retry prompt."""
        try:
            return self._parse(text)
        except PlanError as first_error:
            # Retry up to max_retries times with the clarification prompt
            retry_messages = list(original_messages) + [
                Message(role="assistant", content=text),
                Message(role="user", content=RETRY_PROMPT),
            ]
            last_error = first_error
            for attempt in range(max_retries):
                try:
                    req = ChatRequest(messages=retry_messages, temperature=0.05)
                    buffer: list[str] = []
                    try:
                        for chunk in self.model.stream(req):
                            if chunk:
                                buffer.append(chunk)
                        retry_text = "".join(buffer)
                    except Exception:
                        retry_text = self.model.chat(req)

                    if token_cb and retry_text:
                        token_cb(f"[retry {attempt + 1}] ")

                    return self._parse(retry_text)
                except PlanError as e:
                    last_error = e
                    continue

            raise PlanError(
                f"Model failed to return valid JSON after {max_retries + 1} attempts. "
                f"Last error: {last_error}. "
                f"Raw response (first 200 chars): {text[:200]}"
            ) from last_error

    def _parse(self, text: str) -> Step:
        """Parse a raw model response into a Step. Raises PlanError on failure."""
        text = text.strip()
        if not text:
            raise PlanError("Model returned empty response")

        try:
            data = extract_json(text)
        except ValueError as e:
            raise PlanError(f"No JSON in model response: {text[:200]}") from e

        # Handle array of actions (batch mode) — return first as single step
        if isinstance(data, list):
            if not data:
                raise PlanError("Model returned empty action array")
            data = data[0]

        if not isinstance(data, dict):
            raise PlanError(f"Plan must be a JSON object, got {type(data).__name__}: {str(data)[:100]}")

        thought = str(data.get("thought", ""))
        action = data.get("action")

        if not action:
            # Try 'tool' as alternate key (some models use it)
            action = data.get("tool") or data.get("name") or data.get("function")

        if not action:
            raise PlanError(f"Plan missing 'action' field: {json.dumps(data)[:200]}")

        action = str(action).strip()

        if action == "final":
            result = data.get("result") or data.get("output") or data.get("answer") or ""
            return Step(
                thought=thought, action="final", args={},
                is_final=True, final_result=str(result),
            )

        args = data.get("args") or data.get("parameters") or data.get("input") or {}
        if not isinstance(args, dict):
            raise PlanError(f"'args' must be an object, got {type(args).__name__}: {str(args)[:100]}")

        return Step(thought=thought, action=action, args=args)

    def parse_batch(self, text: str) -> list[Step]:
        """Parse a batch of actions from model output (array format)."""
        try:
            data = extract_json(text)
        except ValueError as e:
            raise PlanError(f"No JSON in batch response: {text[:200]}") from e

        if isinstance(data, dict):
            return [self._parse(text)]
        if not isinstance(data, list):
            raise PlanError(f"Batch must be JSON array, got {type(data).__name__}")

        steps = []
        for item in data:
            try:
                item_text = json.dumps(item)
                steps.append(self._parse(item_text))
            except (PlanError, ValueError):
                continue
        return steps
