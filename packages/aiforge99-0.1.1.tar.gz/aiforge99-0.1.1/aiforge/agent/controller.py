from __future__ import annotations

import json
import threading
from dataclasses import dataclass, field
from typing import Any

from aiforge.agent.executor import Executor
from aiforge.agent.planner import Planner
from aiforge.agent.state_machine import AgentStateMachine
from aiforge.agent.stop_policy import StopPolicy
from aiforge.agent.verifier import Verifier
from aiforge.context.builder import ContextBuilder
from aiforge.events.bus import EventBus
from aiforge.events.types import (
    AGENT_DONE, AGENT_FAILED, AGENT_OBSERVATION, AGENT_PLAN,
    AGENT_STEP, AGENT_STREAM,
    TOOL_CALL, TOOL_RESULT,
)
from aiforge.memory.long_term import LongTermMemory
from aiforge.memory.short_term import ShortTermMemory
from aiforge.models.base import Message
from aiforge.runtime.errors import AgentError, PlanError
from aiforge.tools.dispatcher import ToolDispatcher
from aiforge.tools.registry import ToolRegistry


@dataclass
class RunResult:
    success: bool
    final: str = ""
    reason: str = ""
    steps: list[dict] = field(default_factory=list)


class AgentController:
    """
    Orchestrates the plan → execute → observe agent loop.

    Memory model:
      - self._session_memory (ShortTermMemory) persists across ALL run() calls
        in the same session, giving the agent full conversation history.
      - self._long_term (LongTermMemory) persists across sessions (written to disk).
      - Call reset_session() to start a fresh memory slate (e.g. :new in TUI/REPL).

    Improvements over v1:
      - Planning phase: before the loop a dedicated plan call outlines steps
      - Context compression: old messages are summarized when window fills up
      - Smarter retry: parse failures use clarification prompt (in Planner)
      - Properly saves failed tasks to long-term memory
      - max_steps and max_consecutive_failures raised
    """

    def __init__(
        self,
        registry: ToolRegistry,
        planner: Planner,
        bus: EventBus | None = None,
        stop_policy: StopPolicy | None = None,
    ):
        self.registry = registry
        self.dispatcher = ToolDispatcher(registry)
        self.executor = Executor(self.dispatcher)
        self.planner = planner
        self.verifier = Verifier()
        self.bus = bus or EventBus()
        self.policy = stop_policy or StopPolicy()

        # Resolve workspace_root from registry permissions
        workspace_root = None
        tools = [t for t in registry.all() if hasattr(t, "permissions")]
        if tools:
            workspace_root = tools[0].permissions.workspace_root

        self.context = ContextBuilder(workspace_root=workspace_root)
        self.state = AgentStateMachine()

        # Persistent session memory — survives across run() calls
        self._session_memory: ShortTermMemory = ShortTermMemory(max_items=200)
        self._task_count: int = 0

        # Long-term memory (disk-backed, survives process restarts)
        self._long_term = LongTermMemory()

    # ── Public API ─────────────────────────────────────────────────────────────

    def reset_session(self) -> None:
        """Clear in-session memory to start fresh. Long-term memory is preserved."""
        self._session_memory.clear()
        self._task_count = 0

    @property
    def memory_size(self) -> int:
        """Number of messages currently in session memory."""
        return len(self._session_memory)

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _tool_descriptions(self) -> list[str]:
        return [f"{t.name}: {t.description}" for t in self.registry.all()]

    def _tool_names(self) -> list[str]:
        return [t.name for t in self.registry.all()]

    def _session_summary(self) -> str | None:
        """Build a compact summary of the last few tasks from long-term memory."""
        try:
            records = self._long_term.all()[-8:]
            if not records:
                return None
            lines = []
            for r in records:
                c = r.get("content", {})
                if isinstance(c, dict):
                    mark = "✓" if c.get("success") else "✗"
                    task = str(c.get("task", ""))[:80]
                    result = str(c.get("result", ""))[:100]
                    lines.append(f"  {mark} [{r.get('ts', '?')[:10]}] {task}")
                    if result:
                        lines.append(f"       → {result}")
            return "\n".join(lines) if lines else None
        except Exception:
            return None

    # ── Main run loop ──────────────────────────────────────────────────────────

    def run(self, task: str, cancel: threading.Event | None = None) -> RunResult:
        steps_log: list[dict] = []
        self._task_count += 1
        task_num = self._task_count

        # Reset state machine and stop policy for each new run
        if self.state.state != "idle":
            try:
                self.state.transition("idle")
            except AgentError:
                self.state.state = "idle"
                self.state.history.append("idle")

        self.policy = StopPolicy(
            max_steps=self.policy.max_steps,
            max_consecutive_failures=self.policy.max_consecutive_failures,
        )

        # ── Planning phase ─────────────────────────────────────────────────────
        self.state.transition("planning")
        self.bus.emit(AGENT_PLAN, task=task)

        task_plan: str = ""
        try:
            task_plan = self.planner.create_plan(task, self._tool_names())
            if task_plan:
                self.bus.emit(AGENT_STREAM, token=f"[Plan]\n{task_plan}\n\n")
        except Exception:
            pass  # Planning failure is non-fatal; continue without plan

        # Inject the current task as a user message into session memory
        self._session_memory.add({
            "role": "user",
            "content": json.dumps({"task": task, "task_num": task_num}),
        })

        # ── Execution loop ─────────────────────────────────────────────────────
        result_final: RunResult | None = None
        try:
            while True:
                # Check for external cancel request (e.g. Escape in TUI)
                if cancel and cancel.is_set():
                    if self.state.state not in ("idle", "completed", "failed"):
                        self.state.transition("interrupted")
                        self.state.transition("idle")
                    self.bus.emit(AGENT_FAILED, reason="cancelled by user")
                    result_final = RunResult(
                        success=False, reason="cancelled by user", steps=steps_log
                    )
                    break

                stop, reason = self.policy.should_stop()
                if stop:
                    self.state.transition("failed")
                    self.bus.emit(AGENT_FAILED, reason=reason)
                    self.state.transition("idle")
                    result_final = RunResult(success=False, reason=reason, steps=steps_log)
                    break

                # Build context with compression
                messages = self.context.build(
                    task,
                    self._session_memory,
                    self._tool_descriptions(),
                    session_summary=self._session_summary(),
                    task_plan=task_plan,
                )

                def _token_cb(token: str) -> None:
                    self.bus.emit(AGENT_STREAM, token=token)

                # Get next step from planner (with retry-on-parse-failure built in)
                try:
                    step = self.planner.next_step_streaming(messages, token_cb=_token_cb)
                    self.policy.reset_parse_failures()
                except PlanError as e:
                    self.policy.record_parse_failure()
                    # Record a soft observation error and continue if retries remain
                    err_msg = str(e)
                    self.bus.emit(AGENT_OBSERVATION, action="parse_error",
                                  args={}, success=False, output="", error=err_msg)
                    self._session_memory.add({"role": "user", "content": json.dumps({
                        "observation": {
                            "success": False,
                            "output": "",
                            "error": f"Parse error (attempt recovered): {err_msg[:200]}",
                        }
                    })})
                    self.state.transition("planning")
                    continue
                except AgentError as e:
                    self.state.transition("failed")
                    self.bus.emit(AGENT_FAILED, reason=str(e))
                    self.state.transition("idle")
                    result_final = RunResult(success=False, reason=str(e), steps=steps_log)
                    break

                self.policy.record_step()
                self.bus.emit(
                    AGENT_STEP,
                    thought=step.thought,
                    action=step.action,
                    args=step.args,
                )

                if step.is_final:
                    self.state.transition("executing")
                    self.state.transition("observing")
                    self.state.transition("verifying")
                    self.state.transition("completed")
                    self.bus.emit(AGENT_DONE, result=step.final_result)
                    steps_log.append({"action": "final", "result": step.final_result})
                    self.state.transition("idle")

                    # Add final response to session memory
                    self._session_memory.add({
                        "role": "assistant",
                        "content": json.dumps({
                            "thought": step.thought,
                            "action": "final",
                            "result": step.final_result,
                        }),
                    })

                    result_final = RunResult(
                        success=True, final=step.final_result, steps=steps_log
                    )
                    break

                # Execute tool
                self.state.transition("executing")
                self.bus.emit(TOOL_CALL, name=step.action, args=step.args)
                result = self.executor.execute(step)
                self.bus.emit(
                    TOOL_RESULT,
                    name=step.action,
                    success=result.success,
                    output=result.output,
                    error=result.error,
                )
                self.state.transition("observing")

                observation = {
                    "action": step.action,
                    "args": step.args,
                    "success": result.success,
                    "output": _truncate(result.output),
                    "error": result.error,
                }
                steps_log.append(observation)
                self.bus.emit(AGENT_OBSERVATION, **observation)

                if result.success:
                    self.policy.record_success()
                else:
                    self.policy.record_failure()

                # Append step + observation to persistent session memory
                self._session_memory.add({"role": "assistant", "content": json.dumps({
                    "thought": step.thought,
                    "action": step.action,
                    "args": step.args,
                })})
                self._session_memory.add({"role": "user", "content": json.dumps({
                    "observation": {
                        "success": result.success,
                        "output": _truncate(result.output),
                        "error": result.error or None,
                    }
                })})
                self.state.transition("planning")

        except Exception as unexpected:
            # Safety net: never leave the controller in a broken state
            try:
                self.state.transition("failed")
                self.state.transition("idle")
            except Exception:
                self.state.state = "idle"
            err = str(unexpected)
            self.bus.emit(AGENT_FAILED, reason=err)
            result_final = RunResult(success=False, reason=err, steps=steps_log)

        # ── Persist to long-term memory ────────────────────────────────────────
        final_result = result_final or RunResult(success=False, reason="unknown")
        self._long_term.add("task", {
            "task": task,
            "result": final_result.final,
            "success": final_result.success,
            "steps": len(steps_log),
            "plan": task_plan[:400] if task_plan else "",
        }, task_num=task_num)

        return final_result


def _truncate(value: Any, limit: int = 4000) -> str:
    """Serialize tool output to a clean JSON-compatible string the model can parse."""
    if value is None:
        return ""
    if isinstance(value, str):
        s = value
    else:
        try:
            s = json.dumps(value, ensure_ascii=False, default=str)
        except Exception:
            s = str(value)
    if len(s) > limit:
        return s[:limit] + f"... [truncated {len(s) - limit} chars]"
    return s
