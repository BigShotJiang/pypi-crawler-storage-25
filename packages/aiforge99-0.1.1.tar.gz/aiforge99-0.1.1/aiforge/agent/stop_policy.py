from dataclasses import dataclass, field


@dataclass
class StopPolicy:
    max_steps: int = 100                    # raised from 25 — real tasks need 60–150
    max_consecutive_failures: int = 5       # raised from 3, with smarter recovery
    max_parse_retries: int = 3              # retries specifically for JSON parse failures

    def __post_init__(self):
        self._steps = 0
        self._failures = 0
        self._parse_failures = 0
        self._total_failures = 0

    def record_step(self) -> None:
        self._steps += 1

    def record_success(self) -> None:
        self._failures = 0
        self._parse_failures = 0

    def record_failure(self) -> None:
        self._failures += 1
        self._total_failures += 1

    def record_parse_failure(self) -> None:
        self._parse_failures += 1
        self._failures += 1
        self._total_failures += 1

    def reset_parse_failures(self) -> None:
        self._parse_failures = 0

    def should_stop(self) -> tuple[bool, str]:
        if self._steps >= self.max_steps:
            return True, (
                f"Reached maximum steps ({self.max_steps}). "
                f"Task may be too complex — use :new and break it into smaller sub-tasks."
            )
        if self._failures >= self.max_consecutive_failures:
            return True, (
                f"Too many consecutive failures ({self._failures}). "
                f"Last errors prevented forward progress."
            )
        return False, ""

    def should_retry_parse(self) -> bool:
        """True if we should retry a parse failure with a clarification prompt."""
        return self._parse_failures < self.max_parse_retries

    @property
    def steps(self) -> int:
        return self._steps

    @property
    def consecutive_failures(self) -> int:
        return self._failures
