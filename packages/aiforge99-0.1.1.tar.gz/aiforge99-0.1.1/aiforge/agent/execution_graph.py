from dataclasses import dataclass, field


@dataclass
class ExecutionNode:
    step_id: str
    action: str
    args: dict
    parent: str | None = None
    success: bool | None = None
    output: str = ""
    error: str = ""


@dataclass
class ExecutionGraph:
    nodes: list[ExecutionNode] = field(default_factory=list)

    def add(self, node: ExecutionNode) -> None:
        self.nodes.append(node)

    def find(self, step_id: str) -> ExecutionNode | None:
        for n in self.nodes:
            if n.step_id == step_id:
                return n
        return None
