from dataclasses import dataclass, field


@dataclass
class TaskNode:
    id: str
    description: str
    depends_on: list[str] = field(default_factory=list)


@dataclass
class TaskGraph:
    nodes: dict[str, TaskNode] = field(default_factory=dict)

    def add(self, node: TaskNode) -> None:
        if node.id in self.nodes:
            raise ValueError(f"duplicate task id: {node.id}")
        self.nodes[node.id] = node

    def topological_order(self) -> list[str]:
        in_degree = {nid: 0 for nid in self.nodes}
        for node in self.nodes.values():
            for dep in node.depends_on:
                if dep not in self.nodes:
                    raise ValueError(f"unknown dependency: {dep}")
                in_degree[node.id] += 1
        ready = [nid for nid, d in in_degree.items() if d == 0]
        order: list[str] = []
        while ready:
            current = ready.pop(0)
            order.append(current)
            for node in self.nodes.values():
                if current in node.depends_on:
                    in_degree[node.id] -= 1
                    if in_degree[node.id] == 0:
                        ready.append(node.id)
        if len(order) != len(self.nodes):
            raise ValueError("cycle detected in task graph")
        return order
