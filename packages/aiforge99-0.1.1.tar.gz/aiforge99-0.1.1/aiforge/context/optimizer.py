from aiforge.runtime.errors import NotImplementedFeatureError


class ContextOptimizer:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("context.optimizer (token-budget aware compaction)")
