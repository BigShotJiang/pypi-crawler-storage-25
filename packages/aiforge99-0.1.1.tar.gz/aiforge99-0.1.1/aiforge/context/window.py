from aiforge.models.base import Message


def trim_messages(messages: list[Message], max_chars: int) -> list[Message]:
    if max_chars <= 0:
        return messages
    total = sum(len(m.content) for m in messages)
    if total <= max_chars:
        return messages
    out: list[Message] = []
    if messages and messages[0].role == "system":
        out.append(messages[0])
        rest = messages[1:]
    else:
        rest = messages
    used = sum(len(m.content) for m in out)
    for m in reversed(rest):
        if used + len(m.content) > max_chars:
            break
        out.insert(1 if out and out[0].role == "system" else 0, m)
        used += len(m.content)
    return out
