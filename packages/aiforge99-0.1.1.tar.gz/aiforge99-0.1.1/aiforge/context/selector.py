from aiforge.runtime.errors import NotImplementedFeatureError


class ContextSelector:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("context.selector (relevance-based item selection)")
