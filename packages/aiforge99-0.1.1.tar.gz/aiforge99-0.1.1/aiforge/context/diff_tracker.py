from aiforge.memory.file_index import FileIndex


class DiffTracker:
    def __init__(self, root: str = "."):
        self.index = FileIndex(root=root)
        self._snapshot: dict[str, str] = {}

    def snapshot(self) -> dict[str, str]:
        self._snapshot = self.index.index()
        return self._snapshot

    def changed(self) -> list[str]:
        previous = self._snapshot
        self.index.index()
        return self.index.changed_since(previous)
