from __future__ import annotations

import json
from pathlib import Path

from aiforge.memory.compression import compress_messages
from aiforge.memory.short_term import ShortTermMemory
from aiforge.models.base import Message


SYSTEM_PROMPT_TEMPLATE = """\
You are AIForge, an autonomous coding agent with persistent memory.

SANDBOX WORKSPACE: {workspace_root}
All file paths are relative to this directory. This is your isolated workspace — you have
full read/write/shell access here. Never use absolute paths. Never access paths outside
this workspace without explicit user permission.

MEMORY:
- You have a conversation history below. Each past task is included so you remember what
  files you already created, what code you wrote, and what the user asked previously.
- When the user says "update X" or "add feature to Y", use file.read first to see the
  current state of that file, then edit it.
- Use memory.recall to search older tasks not in the current history window.

RULES:
1. ALWAYS use project.workspace first to check what files already exist.
2. file.create = new file (fails if exists). file.write = overwrite. file.edit = patch.
   file.append = add to end. Never guess what's in a file — read it first.
3. For multi-step tasks, do one action per step and observe the result before continuing.
4. When a shell command is needed (install, run, test, build), use shell.run.
5. Before editing a file, use file.read to get the current content.
6. Stop with "final" action only when the task is FULLY complete and verified.
7. If you see a file you created in a previous task, read it before modifying.
8. If a tool fails, diagnose the error and try an alternative approach. Do not give up.
9. When writing code, always verify it runs correctly with shell.run after creating it.

RESPONSE FORMAT — always reply with exactly one JSON object, never plain prose:

  {{"thought": "<your reasoning>", "action": "tool_name", "args": {{...}}}}

When the task is fully complete:

  {{"thought": "<your reasoning>", "action": "final", "result": "<summary for the user>"}}

Only use tools listed below. Never invent tool names or argument keys.
{session_context}{plan_context}"""


def _build_session_context(session_summary: str | None) -> str:
    if not session_summary:
        return ""
    return f"\nSESSION HISTORY (recent tasks):\n{session_summary}\n"


def _build_plan_context(task_plan: str | None) -> str:
    if not task_plan:
        return ""
    return f"\nEXECUTION PLAN (follow this outline):\n{task_plan}\n"


def _scan_workspace(workspace_root: str) -> str:
    """
    Recursively scan the user workspace up to 2 levels deep and produce
    a compact file tree the agent can orient itself with.
    """
    try:
        root = Path(workspace_root)
        if not root.exists():
            return ""

        lines: list[str] = []
        skip = {".git", "__pycache__", "node_modules", ".venv", ".pythonlibs",
                ".cache", "aiforge.egg-info", ".aiforge"}

        def _walk(path: Path, prefix: str, depth: int) -> None:
            if depth > 2:
                return
            try:
                children = sorted(path.iterdir(), key=lambda c: (not c.is_dir(), c.name.lower()))
            except PermissionError:
                return
            for child in children:
                if child.name.startswith(".") and child.name not in {".env", ".gitignore"}:
                    continue
                if child.name in skip:
                    continue
                if child.is_dir():
                    lines.append(f"{prefix}{child.name}/")
                    _walk(child, prefix + "  ", depth + 1)
                else:
                    size = child.stat().st_size
                    sz = (f"{size}B" if size < 1024
                          else f"{size // 1024}KB" if size < 1024 * 1024
                          else f"{size // (1024 * 1024)}MB")
                    lines.append(f"{prefix}{child.name} ({sz})")

        _walk(root, "  ", 1)
        if not lines:
            return "\nWORKSPACE FILES: (empty — no files created yet)\n"
        return "\nWORKSPACE FILES (current snapshot):\n" + "\n".join(lines) + "\n"
    except Exception:
        return ""


class ContextBuilder:
    def __init__(self, workspace_root: str | None = None) -> None:
        if workspace_root:
            self.workspace_root = str(Path(workspace_root).expanduser().resolve())
        else:
            from aiforge.runtime.workspace import user_workspace_str
            self.workspace_root = user_workspace_str()

    def build(
        self,
        task: str,
        short_term: ShortTermMemory,
        tool_descriptions: list[str],
        session_summary: str | None = None,
        task_plan: str | None = None,
        max_context_tokens: int = 8000,
    ) -> list[Message]:
        tools_block = "\n".join(f"- {d}" for d in tool_descriptions)
        workspace_snapshot = _scan_workspace(self.workspace_root)
        session_ctx = _build_session_context(session_summary)
        plan_ctx = _build_plan_context(task_plan)

        system = (
            SYSTEM_PROMPT_TEMPLATE.format(
                workspace_root=self.workspace_root,
                session_context=session_ctx,
                plan_context=plan_ctx,
            )
            + workspace_snapshot
            + "\nAvailable tools:\n"
            + tools_block
            + f"\n\nCurrent task: {task}"
        )

        # Compress session memory if the context is growing too large
        raw_messages = [
            {"role": item.get("role", "user"), "content": item.get("content", "")}
            for item in short_term.all()
        ]
        compressed = compress_messages(raw_messages, max_tokens=max_context_tokens)

        messages: list[Message] = [Message(role="system", content=system)]
        for item in compressed:
            messages.append(Message(
                role=item.get("role", "user"),
                content=item.get("content", ""),
            ))
        return messages
