from collections import defaultdict
from typing import Callable

from aiforge.events.types import Event


class EventBus:
    def __init__(self):
        self._subscribers: dict[str, list[Callable[[Event], None]]] = defaultdict(list)
        self._wildcard: list[Callable[[Event], None]] = []

    def subscribe(self, event_type: str, handler: Callable[[Event], None]) -> None:
        if event_type == "*":
            self._wildcard.append(handler)
        else:
            self._subscribers[event_type].append(handler)

    def publish(self, event: Event) -> None:
        for h in self._subscribers.get(event.type, []):
            h(event)
        for h in self._wildcard:
            h(event)

    def emit(self, event_type: str, **payload) -> None:
        self.publish(Event(type=event_type, payload=payload))
