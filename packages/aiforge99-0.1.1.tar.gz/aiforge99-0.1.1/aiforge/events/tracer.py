from aiforge.events.bus import EventBus
from aiforge.events.types import Event
from aiforge.observability.traces import Tracer


def attach_tracer(bus: EventBus, tracer: Tracer) -> None:
    def handler(event: Event) -> None:
        tracer.event(event.type, **event.payload)
    bus.subscribe("*", handler)
