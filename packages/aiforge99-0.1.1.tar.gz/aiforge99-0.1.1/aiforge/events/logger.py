from aiforge.events.bus import EventBus
from aiforge.events.types import Event
from aiforge.observability.logger import get_logger


def attach_console_logger(bus: EventBus, level: str = "INFO") -> None:
    log = get_logger("aiforge.events", level=level)

    def handler(event: Event) -> None:
        log.info("%s %s", event.type, event.payload)

    bus.subscribe("*", handler)
