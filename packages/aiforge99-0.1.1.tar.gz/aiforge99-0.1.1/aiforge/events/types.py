from dataclasses import dataclass, field
from typing import Any

from aiforge.utils.time import utcnow_iso


@dataclass
class Event:
    type: str
    payload: dict[str, Any] = field(default_factory=dict)
    ts: str = field(default_factory=utcnow_iso)


AGENT_PLAN = "agent.plan"
AGENT_STEP = "agent.step"
AGENT_STREAM = "agent.stream"
AGENT_OBSERVATION = "agent.observation"
AGENT_DONE = "agent.done"
AGENT_FAILED = "agent.failed"
TOOL_CALL = "tool.call"
TOOL_RESULT = "tool.result"
MODEL_CALL = "model.call"
MODEL_RESPONSE = "model.response"
