from aiforge.events.bus import EventBus
from aiforge.events.types import Event


def collect_to_list(bus: EventBus, sink: list[Event]) -> None:
    def handler(event: Event) -> None:
        sink.append(event)
    bus.subscribe("*", handler)
