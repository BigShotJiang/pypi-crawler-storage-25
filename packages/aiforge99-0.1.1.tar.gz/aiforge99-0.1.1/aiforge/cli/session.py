"""
AIForge session persistence.

Tracks tasks AND supports full memory save/restore so the user can
resume the agent with its conversation history after a restart.
"""
from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from aiforge.utils.time import utcnow_iso


def _sessions_dir() -> Path:
    from aiforge.runtime.workspace import resolve_workspace
    return resolve_workspace() / ".aiforge" / "sessions"


@dataclass
class SessionRecord:
    id: str
    created_at: str
    tasks: list[dict[str, Any]] = field(default_factory=list)
    # Serialised session memory messages (for restore)
    messages: list[dict[str, Any]] = field(default_factory=list)
    task_count: int = 0


class Session:
    def __init__(self, session_id: str | None = None):
        self.id = session_id or uuid.uuid4().hex[:12]
        self.path = _sessions_dir() / f"{self.id}.json"
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text(encoding="utf-8"))
                # Migrate old format (no messages/task_count)
                data.setdefault("messages", [])
                data.setdefault("task_count", 0)
                self.record = SessionRecord(**data)
            except Exception:
                self.record = SessionRecord(id=self.id, created_at=utcnow_iso())
                self._save()
        else:
            self.record = SessionRecord(id=self.id, created_at=utcnow_iso())
            self._save()

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(asdict(self.record), indent=2), encoding="utf-8")

    def append_task(
        self,
        task: str,
        success: bool,
        final: str,
        reason: str,
        steps: list[dict],
    ) -> None:
        self.record.tasks.append({
            "ts": utcnow_iso(),
            "task": task,
            "success": success,
            "final": final,
            "reason": reason,
            "steps": steps,
        })
        self._save()

    # ── Memory persistence ─────────────────────────────────────────────────────

    def save_memory(self, controller) -> None:
        """Snapshot the controller's session memory into this session record."""
        self.record.messages = list(controller._session_memory.all())
        self.record.task_count = controller._task_count
        self._save()

    def restore_memory(self, controller) -> int:
        """
        Restore saved memory into the controller.
        Returns number of messages restored (0 if nothing to restore).
        """
        if not self.record.messages:
            return 0
        controller.reset_session()
        controller._task_count = self.record.task_count
        for msg in self.record.messages:
            controller._session_memory.add(msg)
        return len(self.record.messages)

    @property
    def task_count(self) -> int:
        return self.record.task_count

    @property
    def message_count(self) -> int:
        return len(self.record.messages)

    # ── Class methods ──────────────────────────────────────────────────────────

    @classmethod
    def list_all(cls) -> list[str]:
        d = _sessions_dir()
        if not d.exists():
            return []
        return sorted(p.stem for p in d.glob("*.json"))

    @classmethod
    def list_with_meta(cls) -> list[dict]:
        """Return metadata for all sessions."""
        result = []
        d = _sessions_dir()
        if not d.exists():
            return result
        for p in sorted(d.glob("*.json")):
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                result.append({
                    "id": data.get("id", p.stem),
                    "created_at": data.get("created_at", "?"),
                    "tasks": len(data.get("tasks", [])),
                    "messages": len(data.get("messages", [])),
                })
            except Exception:
                continue
        return result
