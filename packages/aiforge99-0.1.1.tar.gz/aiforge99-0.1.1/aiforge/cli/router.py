from typing import Callable

from aiforge.runtime.errors import AIForgeError


class CommandRouter:
    def __init__(self):
        self._routes: dict[str, Callable] = {}

    def register(self, name: str, fn: Callable) -> None:
        self._routes[name] = fn

    def dispatch(self, name: str, *args, **kwargs):
        if name not in self._routes:
            raise AIForgeError(f"Unknown command: {name}")
        return self._routes[name](*args, **kwargs)

    def names(self) -> list[str]:
        return sorted(self._routes.keys())
