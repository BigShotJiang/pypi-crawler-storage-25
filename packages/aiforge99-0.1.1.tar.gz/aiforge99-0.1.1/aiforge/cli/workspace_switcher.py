import os
from pathlib import Path

from aiforge.runtime.errors import AIForgeError
from aiforge.runtime.lifecycle import ensure_dirs


class WorkspaceSwitcher:
    def __init__(self):
        self.original_cwd = Path.cwd()

    def switch(self, target: str | Path) -> Path:
        path = Path(target).expanduser().resolve()
        if not path.exists():
            raise AIForgeError(f"Workspace does not exist: {path}")
        if not path.is_dir():
            raise AIForgeError(f"Workspace is not a directory: {path}")
        os.chdir(path)
        ensure_dirs()
        return path

    def current(self) -> Path:
        return Path.cwd()

    def restore(self) -> Path:
        os.chdir(self.original_cwd)
        return self.original_cwd
