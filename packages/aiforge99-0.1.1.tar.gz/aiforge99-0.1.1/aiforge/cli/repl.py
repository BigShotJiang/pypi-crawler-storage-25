from pathlib import Path

from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory

from aiforge import __version__ as VERSION
from aiforge.cli.commands import (
    build_controller, cmd_models_list, cmd_providers_list,
    cmd_providers_test, cmd_session_show, cmd_sessions_list, cmd_setup,
    cmd_workspace_set, cmd_workspace_show,
)
from aiforge.cli.session import Session
from aiforge.runtime.env import load_env
from aiforge.runtime.errors import AIForgeError, ModelNotConfiguredError
from aiforge.runtime.lifecycle import ensure_dirs
from aiforge.runtime.workspace import resolve_workspace, resolve_user_workspace
from aiforge.ui import repl_ui
from aiforge.ui.console import console, error, info, success, system, warn
from aiforge.ui.panels import show_table


HELP = """\
─── AIForge REPL Commands ────────────────────────────────────────────
  :help                  show this help
  :tools                 list registered tools with parameters
  :memory                show session + long-term memory stats
  :history               show recent session memory (last 20 messages)
  :new                   clear session memory — start a fresh conversation
  :save                  save current session memory to disk
  :load <id>             restore a saved session (alias: :resume)
  :resume <id>           restore a saved session
  :model                 show active model name
  :providers             list providers and their status
  :models                list known models per provider
  :workspace             show current sandbox workspace path
  :workspace set <path>  change workspace (persisted to config, restart to apply)
  :sessions              list saved sessions
  :session <id>          show full task log for a session (prefix match ok)
  :setup                 run interactive setup (providers / keys / model)
  :test [name]           send a tiny test message to verify a provider works
  :clear                 clear the screen
  :quit / :q             exit the REPL
──────────────────────────────────────────────────────────────────────
Anything else is sent to the agent as a task.
Memory persists across tasks — use :new to start a fresh session."""


def _try_build():
    return build_controller(verbose=True)


def run_repl() -> int:
    ensure_dirs()
    controller = None
    model_name = ""
    try:
        controller, model_name = _try_build()
    except ModelNotConfiguredError as e:
        warn(str(e))
        info("Opening setup wizard…")
        cmd_setup()
        load_env()
        try:
            controller, model_name = _try_build()
        except AIForgeError as e2:
            error(str(e2))
            warn("REPL cannot start. Re-run `aiforge setup` once a provider is ready.")
            return 1
    except AIForgeError as e:
        error(str(e))
        return 1

    repl_ui.banner(VERSION, model_name)
    sess = Session()
    user_ws = resolve_user_workspace()
    info(f"session: {sess.id}")
    info(f"sandbox: {user_ws}")
    info("Memory persists across tasks. Type ':help' for commands, ':new' for fresh session.")

    history_path = resolve_workspace() / ".aiforge" / "sessions" / "repl_history"
    history_path.parent.mkdir(parents=True, exist_ok=True)
    pt = PromptSession(history=FileHistory(str(history_path)))

    while True:
        mem_size = controller.memory_size
        prompt = f"aiforge({mem_size}m)> " if mem_size > 0 else "aiforge> "
        try:
            line = pt.prompt(prompt)
        except (EOFError, KeyboardInterrupt):
            console.print()
            break

        line = line.strip()
        if not line:
            continue

        if line in (":quit", ":q", "exit", "quit"):
            break

        if line == ":help":
            system(HELP)
            continue

        if line == ":tools":
            import inspect
            rows = []
            for t in controller.registry.all():
                try:
                    sig = inspect.signature(t.run)
                    params = ", ".join(
                        p.name + ("" if p.default is inspect.Parameter.empty else "?")
                        for p in sig.parameters.values()
                        if p.name != "self"
                    )
                except (TypeError, ValueError):
                    params = ""
                rows.append([t.name, params, t.description[:60]])
            show_table("Registered tools", ["name", "params (?=optional)", "description"], rows)
            continue

        if line == ":memory":
            mem = controller.memory_size
            tasks = controller._task_count
            info(f"Session memory: {mem} messages across {tasks} task(s).")
            try:
                records = controller._long_term.all()
                info(f"Long-term memory: {len(records)} task(s) on disk.")
                for r in records[-5:]:
                    c_data = r.get("content", {})
                    if isinstance(c_data, dict):
                        mark = "✓" if c_data.get("success") else "✗"
                        task_text = str(c_data.get("task", ""))[:70]
                        ts = r.get("ts", "?")[:16]
                        system(f"  {mark} [{ts}] {task_text}")
            except Exception as ex:
                warn(f"Long-term memory read error: {ex}")
            continue

        if line == ":history":
            import json as _json
            mem_items = controller._session_memory.all()
            if not mem_items:
                info("Session memory is empty.")
            else:
                info(f"Session memory ({len(mem_items)} messages):")
                for i, msg in enumerate(mem_items[-20:], 1):
                    role = msg.get("role", "?")
                    content = msg.get("content", "")
                    try:
                        obj = _json.loads(content)
                        if "task" in obj:
                            preview = f"task: {str(obj['task'])[:70]}"
                        elif "action" in obj:
                            preview = f"→ {obj['action']}"
                        elif "observation" in obj:
                            obs = obj["observation"]
                            ok = "✓" if obs.get("success") else "✗"
                            preview = f"obs: {ok} {str(obs.get('output', ''))[:50]}"
                        else:
                            preview = str(obj)[:70]
                    except Exception:
                        preview = str(content)[:70]
                    system(f"  [{i:2}] {role:<10} {preview}")
            continue

        if line in (":new", ":new-session"):
            controller.reset_session()
            success("Session memory cleared. Starting fresh.")
            continue

        # Session save/load
        if line in (":save", ":save-session"):
            try:
                s = Session()
                s.save_memory(controller)
                success(f"Session saved — id: {s.id}  (use ':load {s.id}' to restore)")
            except Exception as ex:
                error(f"Save failed: {ex}")
            continue

        if line.startswith(":load ") or line.startswith(":resume "):
            sid = line.split(" ", 1)[1].strip()
            if not sid:
                error("usage: :load <session-id>")
            else:
                try:
                    s = Session(session_id=sid)
                    n = s.restore_memory(controller)
                    if n:
                        success(f"Restored {n} messages from session '{sid}'.")
                    else:
                        warn(f"Session '{sid}' exists but has no saved memory.")
                except Exception as ex:
                    error(f"Load failed: {ex}")
            continue

        if line == ":sessions":
            cmd_sessions_list()
            try:
                meta = Session.list_with_meta()
                if meta:
                    for m in meta[-8:]:
                        system(
                            f"  {m['id']}  tasks={m['tasks']}  msgs={m['messages']}  "
                            f"created={m['created_at'][:10]}"
                        )
            except Exception:
                pass
            continue

        if line == ":session" or line.startswith(":session "):
            parts = line.split(maxsplit=1)
            if len(parts) < 2:
                error("usage: :session <id>  (run :sessions to list ids)")
            else:
                cmd_session_show(parts[1].strip())
            continue

        if line == ":model":
            info(f"model: {model_name}")
            continue

        if line == ":providers":
            cmd_providers_list()
            continue

        if line == ":models":
            cmd_models_list()
            continue

        if line == ":workspace":
            cmd_workspace_show()
            info(f"sandbox: {user_ws}")
            continue

        if line.startswith(":workspace set "):
            target = line[len(":workspace set "):].strip()
            if not target:
                error("usage: :workspace set <path>")
            else:
                cmd_workspace_set(target)
            continue

        if line == ":test" or line.startswith(":test "):
            target = line.split(maxsplit=1)[1].strip() if " " in line else None
            cmd_providers_test(target)
            continue

        if line == ":setup":
            cmd_setup()
            load_env()
            try:
                controller, model_name = _try_build()
                success(f"reloaded model: {model_name}")
            except AIForgeError as e:
                error(str(e))
            continue

        if line == ":clear":
            console.clear()
            continue

        repl_ui.user(line)
        try:
            result = controller.run(line)
        except AIForgeError as e:
            error(str(e))
            sess.append_task(line, False, "", str(e), [])
            continue
        sess.append_task(line, result.success, result.final, result.reason, result.steps)
        if result.success:
            repl_ui.agent(result.final or "(done)")
            success(f"ok  (memory: {controller.memory_size} messages)")
        else:
            error(f"failed: {result.reason}")

    info("bye.")
    return 0
