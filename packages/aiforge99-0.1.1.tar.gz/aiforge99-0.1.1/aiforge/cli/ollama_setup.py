"""Fully automatic Ollama installer, server manager, and AIForge configurator."""
from __future__ import annotations

import platform
import shutil
import subprocess
import sys
import time

OLLAMA_DEFAULT_MODEL = "phi3:mini"
_OLLAMA_HOST = "http://localhost:11434"


def _ollama_installed() -> bool:
    return bool(shutil.which("ollama"))


def _ollama_running() -> bool:
    try:
        import httpx
        r = httpx.get(f"{_OLLAMA_HOST}/api/tags", timeout=5)
        return r.status_code == 200
    except Exception:
        return False


def _print(msg: str, level: str = "info") -> None:
    colors = {"ok": "\033[32m✓", "warn": "\033[33m⚠", "error": "\033[31m✗", "info": "\033[36m·"}
    prefix = colors.get(level, "·")
    print(f"  {prefix} {msg}\033[0m")


def install_ollama() -> bool:
    """Download and install Ollama if not already present. Returns True on success."""
    if _ollama_installed():
        _print("ollama already installed", "ok")
        return True

    system = platform.system()
    _print(f"Installing Ollama on {system}…")

    if system == "Linux":
        result = subprocess.run(
            "curl -fsSL https://ollama.ai/install.sh | sh",
            shell=True,
            check=False,
        )
        if result.returncode == 0:
            _print("Ollama installed", "ok")
            return True
        _print("Installation script failed", "error")
        return False

    if system == "Darwin":
        if shutil.which("brew"):
            result = subprocess.run(["brew", "install", "ollama"], check=False)
            if result.returncode == 0:
                _print("Ollama installed via Homebrew", "ok")
                return True
        _print("Install Homebrew then run: brew install ollama", "warn")
        _print("Or download from: https://ollama.ai/download", "warn")
        return False

    if system == "Windows":
        _print("Download the Ollama installer from: https://ollama.ai/download", "warn")
        return False

    _print(f"Unsupported platform: {system}. Install manually: https://ollama.ai", "warn")
    return False


def start_ollama_server() -> bool:
    """Start 'ollama serve' in background. Waits up to 20 s. Returns True if reachable."""
    if _ollama_running():
        _print("Ollama server already running", "ok")
        return True

    if not _ollama_installed():
        _print("ollama binary not found — install first", "error")
        return False

    _print("Starting Ollama server in background…")
    subprocess.Popen(
        ["ollama", "serve"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )

    for i in range(20):
        time.sleep(1)
        if _ollama_running():
            _print(f"Ollama server ready (took {i + 1}s)", "ok")
            return True

    _print("Ollama server did not start in 20 s — try: ollama serve", "error")
    return False


def pull_model(model: str) -> bool:
    """Pull an Ollama model. Streams output to terminal. Returns True on success."""
    _print(f"Pulling model: {model}  (this may take several minutes, please wait…)")
    result = subprocess.run(["ollama", "pull", model], check=False)
    if result.returncode == 0:
        _print(f"Model ready: {model}", "ok")
        return True
    _print(f"Failed to pull {model}", "error")
    return False


def list_local_models() -> list[str]:
    """Return names of locally downloaded Ollama models."""
    try:
        import httpx
        r = httpx.get(f"{_OLLAMA_HOST}/api/tags", timeout=10)
        if r.status_code == 200:
            return [m["name"] for m in r.json().get("models", [])]
    except Exception:
        pass
    return []


def configure_aiforge_ollama(model: str) -> None:
    """Persist ollama as default provider in AIForge config."""
    from aiforge.runtime.config import Config
    from aiforge.runtime.workspace import resolve_workspace

    ws = resolve_workspace()
    cfg_path = ws / ".aiforge" / "config.json"
    cfg_path.parent.mkdir(parents=True, exist_ok=True)
    config = Config(cfg_path)
    config.set("providers.ollama.enabled", True)
    config.set("providers.ollama.host", _OLLAMA_HOST)
    config.set("providers.ollama.model", model)
    config.set("default_provider", "ollama")
    config.save()
    _print(f"AIForge configured: ollama:{model} (default provider)", "ok")


def run_ollama_install(model: str = OLLAMA_DEFAULT_MODEL) -> int:
    """Full automatic Ollama setup: install → start server → pull model → configure AIForge."""
    print("\n\033[1;34m═══ Ollama Auto-Setup ═══\033[0m\n")

    # 1. Install
    _print("Step 1/4 — Install Ollama")
    if not install_ollama():
        _print("Ollama installation failed. Visit: https://ollama.ai", "error")
        return 1

    # 2. Start server
    _print("Step 2/4 — Start Ollama server")
    if not start_ollama_server():
        _print("Could not start Ollama server. Run manually: ollama serve", "error")
        return 1

    # 3. Pull model
    _print(f"Step 3/4 — Pull model: {model}")
    if not pull_model(model):
        _print(f"Model pull failed. Try manually: ollama pull {model}", "warn")
        # Non-fatal: server is running, user can pull later
        _print("Skipping model pull — configure manually with: aiforge ollama pull <model>", "warn")

    # 4. Configure AIForge
    _print("Step 4/4 — Configure AIForge")
    configure_aiforge_ollama(model)

    print("\n\033[1;32m✓ Setup complete!\033[0m")
    print(f"  Model : ollama:{model}")
    print("  Launch: aiforge tui")
    print()
    return 0
