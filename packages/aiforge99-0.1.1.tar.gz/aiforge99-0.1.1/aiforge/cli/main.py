import json
import sys

import click

from aiforge import __version__ as VERSION
from aiforge.runtime.env import load_env

load_env()


@click.group(invoke_without_command=True, context_settings={"help_option_names": ["-h", "--help"]})
@click.pass_context
def main(ctx):
    """AIFORGE — local AI agent + CLI IDE + autonomous code executor."""
    if ctx.invoked_subcommand is None:
        from aiforge.cli.repl import run_repl
        sys.exit(run_repl())


@main.command()
def version():
    """Print version and exit."""
    click.echo(VERSION)


@main.command()
def doctor():
    """Run environment diagnostics."""
    from aiforge.cli.commands import cmd_doctor
    sys.exit(cmd_doctor())


@main.command("run")
@click.argument("task", nargs=-1, required=True)
def run_cmd(task):
    """Run a single agent task and exit."""
    from aiforge.cli.commands import cmd_run
    sys.exit(cmd_run(" ".join(task)))


@main.group("tools")
def tools_group():
    """Tool registry inspection."""


@tools_group.command("list")
def tools_list_cmd():
    """List registered tools."""
    from aiforge.cli.commands import cmd_tools_list
    sys.exit(cmd_tools_list())


@main.command("tool")
@click.argument("name")
@click.argument("kv", nargs=-1)
def tool_call_cmd(name, kv):
    """Invoke a tool directly. Example: aiforge tool file.read path=README.md"""
    args: dict = {}
    for item in kv:
        if "=" not in item:
            click.echo(f"invalid argument (need key=value): {item}", err=True)
            sys.exit(2)
        k, v = item.split("=", 1)
        try:
            args[k] = json.loads(v)
        except Exception:
            args[k] = v
    from aiforge.cli.commands import cmd_tool_call
    sys.exit(cmd_tool_call(name, args))


@main.group("config")
def config_group():
    """Configuration management."""


@config_group.command("get")
@click.argument("key", required=False)
def config_get_cmd(key):
    """Get a config value (dotted key) or print full config."""
    from aiforge.cli.commands import cmd_config_get
    sys.exit(cmd_config_get(key))


@config_group.command("set")
@click.argument("key")
@click.argument("value")
def config_set_cmd(key, value):
    """Set a config value (dotted key). Value is parsed as JSON when possible."""
    from aiforge.cli.commands import cmd_config_set
    sys.exit(cmd_config_set(key, value))


@main.group("sessions")
@click.pass_context
def sessions_group(ctx):
    """List and inspect recorded sessions."""
    if ctx.invoked_subcommand is None:
        from aiforge.cli.commands import cmd_sessions_list
        sys.exit(cmd_sessions_list())


@sessions_group.command("list")
def sessions_list_cmd():
    """List all recorded sessions."""
    from aiforge.cli.commands import cmd_sessions_list
    sys.exit(cmd_sessions_list())


@sessions_group.command("show")
@click.argument("session_id")
def session_show_cmd(session_id):
    """Show full task log for a session (prefix match supported)."""
    from aiforge.cli.commands import cmd_session_show
    sys.exit(cmd_session_show(session_id))


@main.command()
def setup():
    """Interactive setup: enable providers, save API keys, choose models."""
    from aiforge.cli.commands import cmd_setup
    sys.exit(cmd_setup())


@main.group("providers")
def providers_group():
    """Manage model providers."""


@providers_group.command("list")
def providers_list_cmd():
    """Show provider status, endpoints, and key state."""
    from aiforge.cli.commands import cmd_providers_list
    sys.exit(cmd_providers_list())


@providers_group.command("enable")
@click.argument("name")
def providers_enable_cmd(name):
    """Enable a provider."""
    from aiforge.cli.commands import cmd_providers_enable
    sys.exit(cmd_providers_enable(name))


@providers_group.command("disable")
@click.argument("name")
def providers_disable_cmd(name):
    """Disable a provider."""
    from aiforge.cli.commands import cmd_providers_disable
    sys.exit(cmd_providers_disable(name))


@providers_group.command("test")
@click.argument("name", required=False)
def providers_test_cmd(name):
    """Send a small request to verify the provider really works."""
    from aiforge.cli.commands import cmd_providers_test
    sys.exit(cmd_providers_test(name))


@main.group("models")
def models_group():
    """Inspect and select models."""


@models_group.command("list")
def models_list_cmd():
    """List known/configured models per provider."""
    from aiforge.cli.commands import cmd_models_list
    sys.exit(cmd_models_list())


@models_group.command("use")
@click.argument("provider")
@click.argument("model")
def models_use_cmd(provider, model):
    """Select <provider> <model> as the default."""
    from aiforge.cli.commands import cmd_models_use
    sys.exit(cmd_models_use(provider, model))


@main.command("tui")
def tui_cmd():
    """Launch the interactive TUI (chat + files + status)."""
    from aiforge.runtime.lifecycle import ensure_dirs
    from aiforge.runtime.errors import AIForgeError, ModelNotConfiguredError
    from aiforge.cli.commands import build_controller, cmd_setup
    from aiforge.runtime.env import load_env

    ensure_dirs()
    try:
        controller, model_name = build_controller(verbose=False)
    except ModelNotConfiguredError as e:
        click.echo(str(e), err=True)
        click.echo("Running setup wizard first…")
        cmd_setup()
        load_env()
        try:
            controller, model_name = build_controller(verbose=False)
        except AIForgeError as e2:
            click.echo(str(e2), err=True)
            sys.exit(1)
    except AIForgeError as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    from aiforge.tui.app import AIForgeTUI
    app = AIForgeTUI(controller=controller, model_name=model_name)
    app.run()


@main.group("workspace")
def workspace_group():
    """Show and configure the active workspace."""


@workspace_group.command("show")
def workspace_show_cmd():
    """Print the active workspace path and how it was resolved."""
    from aiforge.cli.commands import cmd_workspace_show
    sys.exit(cmd_workspace_show())


@workspace_group.command("set")
@click.argument("path")
def workspace_set_cmd(path):
    """Persist PATH as the workspace in config.json (takes effect on next run)."""
    from aiforge.cli.commands import cmd_workspace_set
    sys.exit(cmd_workspace_set(path))


@main.group("keys")
def keys_group():
    """Manage provider API keys (.env)."""


@keys_group.command("set")
@click.argument("provider")
@click.argument("key")
def keys_set_cmd(provider, key):
    """Persist <provider>'s API key to .env."""
    from aiforge.cli.commands import cmd_keys_set
    sys.exit(cmd_keys_set(provider, key))


# ── Ollama local LLM management ───────────────────────────────────────────────

@main.group("ollama")
def ollama_group():
    """Local Ollama LLM management (install, start, pull models)."""


@ollama_group.command("install")
@click.option(
    "--model", default="phi3:mini", show_default=True,
    help="Model to download after installing Ollama.",
)
def ollama_install_cmd(model):
    """Install Ollama, start server, download a model, configure AIForge. Fully automatic."""
    from aiforge.cli.ollama_setup import run_ollama_install
    sys.exit(run_ollama_install(model=model))


@ollama_group.command("pull")
@click.argument("model")
def ollama_pull_cmd(model):
    """Pull (download) an Ollama model and set it as the AIForge default."""
    from aiforge.cli.ollama_setup import start_ollama_server, pull_model, configure_aiforge_ollama
    if not start_ollama_server():
        sys.exit(1)
    ok = pull_model(model)
    configure_aiforge_ollama(model)
    sys.exit(0 if ok else 1)


@ollama_group.command("start")
def ollama_start_cmd():
    """Start the Ollama server in the background."""
    from aiforge.cli.ollama_setup import start_ollama_server
    sys.exit(0 if start_ollama_server() else 1)


@ollama_group.command("models")
def ollama_models_cmd():
    """List locally downloaded Ollama models."""
    from aiforge.cli.ollama_setup import list_local_models, _ollama_running
    if not _ollama_running():
        click.echo("Ollama server is not running. Start with: aiforge ollama start", err=True)
        sys.exit(1)
    models = list_local_models()
    if not models:
        click.echo("No models downloaded yet. Pull one with: aiforge ollama pull <model>")
    else:
        click.echo(f"Downloaded models ({len(models)}):")
        for m in models:
            click.echo(f"  • {m}")


if __name__ == "__main__":
    main()
