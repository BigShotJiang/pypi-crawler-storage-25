import json
import os
import platform
import sys
from pathlib import Path
from typing import Any

from aiforge import __version__ as VERSION
from aiforge.agent.controller import AgentController
from aiforge.agent.planner import Planner
from aiforge.cli.session import Session
from aiforge.events.bus import EventBus
from aiforge.events.types import AGENT_FAILED, AGENT_STEP, TOOL_CALL, TOOL_RESULT
from aiforge.models.router import ModelRouter
from aiforge.runtime.config import Config
from aiforge.runtime.errors import AIForgeError, ConfigError, ModelNotConfiguredError
from aiforge.runtime.lifecycle import ensure_dirs
from aiforge.runtime.workspace import resolve_workspace, resolve_user_workspace
from aiforge.tools import build_default_registry
from aiforge.tools.dispatcher import ToolDispatcher
from aiforge.ui import repl_ui
from aiforge.ui.console import console, error, info, success, system, warn
from aiforge.ui.panels import show_table

PROVIDER_ENV: dict[str, str | None] = {
    "zapi": "ZAPI_API_KEY",
    "openai": "OPENAI_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "ollama": None,
}


def _cfg_path() -> Path:
    """Return the resolved config.json path for the current workspace."""
    return resolve_workspace() / ".aiforge" / "config.json"


def _config() -> Config:
    """Load Config from the current workspace."""
    return Config(_cfg_path())


def attach_console_handlers(bus: EventBus) -> None:
    import sys as _sys
    from aiforge.events.types import AGENT_STREAM

    # Mutable cell to track whether we're mid-stream (so we clear the line before thought).
    _streaming: list[int] = [0]

    def on_stream(event):
        token = event.payload.get("token", "")
        if token:
            _streaming[0] += 1
            _sys.stdout.write(f"\r  ⟳ {_streaming[0]} token(s)…   ")
            _sys.stdout.flush()

    def on_step(event):
        if _streaming[0] > 0:
            _sys.stdout.write("\r" + " " * 30 + "\r")
            _sys.stdout.flush()
            _streaming[0] = 0
        thought = event.payload.get("thought") or ""
        if thought:
            repl_ui.thought(thought)

    def on_tool_call(event):
        repl_ui.tool_call(event.payload.get("name", ""), event.payload.get("args", {}))

    def on_tool_result(event):
        ok = bool(event.payload.get("success"))
        out = event.payload.get("output") or event.payload.get("error") or ""
        s = out if isinstance(out, str) else str(out)
        if len(s) > 500:
            s = s[:500] + "…"
        repl_ui.tool_result(ok, s)

    def on_failed(event):
        if _streaming[0] > 0:
            _sys.stdout.write("\r" + " " * 30 + "\r")
            _sys.stdout.flush()
            _streaming[0] = 0
        error(f"agent failed: {event.payload.get('reason', '')}")

    bus.subscribe(AGENT_STREAM, on_stream)
    bus.subscribe(AGENT_STEP, on_step)
    bus.subscribe(TOOL_CALL, on_tool_call)
    bus.subscribe(TOOL_RESULT, on_tool_result)
    bus.subscribe(AGENT_FAILED, on_failed)


def build_controller(verbose: bool = True) -> tuple[AgentController, str]:
    ensure_dirs()
    ws = resolve_workspace()
    # Ensure the agent user workspace exists
    user_ws = resolve_user_workspace()
    cfg_path = ws / ".aiforge" / "config.json"
    try:
        config = Config(cfg_path)
    except ConfigError as e:
        raise AIForgeError(str(e))
    from aiforge.tools.permissions import Permissions
    perms = Permissions(workspace_root=str(user_ws))
    registry = build_default_registry(permissions=perms)
    bus = EventBus()
    if verbose:
        attach_console_handlers(bus)
    router = ModelRouter.from_config(config)
    if not router.names():
        raise ModelNotConfiguredError(
            "No model providers configured. Run `aiforge setup` to enable a provider "
            "(zapi/openai/openrouter/ollama) and add its API key."
        )
    model = router.get()
    planner = Planner(model)
    controller = AgentController(registry=registry, planner=planner, bus=bus)
    return controller, getattr(model, "name", router._default or "unknown")


def cmd_doctor() -> int:
    rc = 0
    info(f"AIForge {VERSION}")
    info(f"Python {platform.python_version()} on {platform.platform()}")
    py_ok = sys.version_info >= (3, 11)
    (success if py_ok else error)(f"python>=3.11: {py_ok}")
    if not py_ok:
        rc = 1

    ws = resolve_workspace()
    user_ws = resolve_user_workspace()
    info(f"workspace root: {ws}")
    info(f"sandbox (agent workspace): {user_ws}")
    home = ws / ".aiforge"
    dirs_ok = True
    for d in (home, home / "sessions", home / "memory", home / "logs", home / "cache"):
        if d.exists():
            success(f"dir exists: {d.relative_to(ws)}")
        else:
            warn(f"dir missing (will create): {d.relative_to(ws)}")
            dirs_ok = False
    if user_ws.exists():
        success(f"sandbox dir exists: {user_ws}")
    else:
        warn(f"sandbox dir missing (will create): {user_ws}")
        dirs_ok = False
    ensure_dirs()
    if not dirs_ok:
        success("dirs created")

    cfg_path = home / "config.json"
    cfg_existed = cfg_path.exists()
    try:
        Config(cfg_path)
        if cfg_existed:
            success(f"config loaded: {cfg_path}")
        else:
            warn(f"config created with defaults: {cfg_path}")
    except AIForgeError as e:
        error(f"config invalid: {e}"); rc = 1

    try:
        registry = build_default_registry()
        success(f"tools registered: {len(registry.all())}")
    except Exception as e:
        error(f"tool registry failed: {e}"); rc = 1

    try:
        cfg = _config()
        router = ModelRouter.from_config(cfg)
        names = router.names()
        if names:
            success(f"models configured: {', '.join(names)} (default: {router._default})")
        else:
            warn("no model providers configured. Run `aiforge setup`.")
    except Exception as e:
        error(f"model router failed: {e}"); rc = 1

    if rc == 0:
        success("doctor: ok")
    else:
        error(f"doctor: {rc} issue(s) found")
    return rc


def cmd_run(task: str) -> int:
    if not task.strip():
        error("empty task"); return 2
    try:
        controller, model_name = build_controller(verbose=True)
    except AIForgeError as e:
        error(str(e)); return 1
    info(f"model: {model_name}")
    system(f"task: {task}")
    sess = Session()
    try:
        result = controller.run(task)
    except AIForgeError as e:
        error(str(e))
        sess.append_task(task, False, "", str(e), [])
        return 1
    sess.append_task(task, result.success, result.final, result.reason, result.steps)
    if result.success:
        success("done")
        if result.final:
            console.print(result.final)
        return 0
    error(f"failed: {result.reason}")
    return 1


def cmd_tools_list() -> int:
    import inspect
    registry = build_default_registry()
    rows = []
    for t in registry.all():
        try:
            sig = inspect.signature(t.run)
            params = ", ".join(
                p.name + ("" if p.default is inspect.Parameter.empty else "?")
                for p in sig.parameters.values()
                if p.name != "self"
            )
        except (TypeError, ValueError):
            params = ""
        rows.append([t.name, params, t.description])
    show_table("Registered tools", ["name", "params (?=optional)", "description"], rows)
    info("call a tool with: aiforge tool <name> key=value …")
    return 0


def cmd_tool_call(name: str, args: dict[str, Any]) -> int:
    registry = build_default_registry()
    disp = ToolDispatcher(registry)
    try:
        result = disp.dispatch(name, **args)
    except AIForgeError as e:
        error(str(e)); return 1
    if result.success:
        success("ok")
        if result.output:
            console.print(str(result.output))
        return 0
    error(f"failed: {result.error}")
    return 1


def cmd_config_get(key: str | None) -> int:
    try:
        cfg = _config()
    except ConfigError as e:
        error(str(e)); return 1
    if key:
        value = cfg.get(key)
        console.print(json.dumps(value, indent=2))
    else:
        console.print(json.dumps(cfg.settings, indent=2))
    return 0


def cmd_config_set(key: str, value: str) -> int:
    try:
        cfg = _config()
    except ConfigError as e:
        error(str(e)); return 1
    try:
        parsed = json.loads(value)
    except Exception:
        parsed = value
    cfg.set(key, parsed)
    cfg.save()
    success(f"set {key} = {json.dumps(parsed)}")
    return 0


def cmd_sessions_list() -> int:
    ids = Session.list_all()
    if not ids:
        info("no sessions yet"); return 0
    sessions_dir = resolve_workspace() / ".aiforge" / "sessions"
    rows = [[sid, str(sessions_dir / f"{sid}.json")] for sid in ids]
    show_table("Sessions", ["id", "path"], rows)
    return 0


def cmd_session_show(session_id: str) -> int:
    import json as _json
    sessions_dir = resolve_workspace() / ".aiforge" / "sessions"
    path = sessions_dir / f"{session_id}.json"
    if not path.exists():
        ids = Session.list_all()
        # Allow prefix match.
        matches = [i for i in ids if i.startswith(session_id)]
        if len(matches) == 1:
            path = sessions_dir / f"{matches[0]}.json"
            session_id = matches[0]
        elif len(matches) > 1:
            error(f"ambiguous id prefix '{session_id}' — matches: {', '.join(matches)}")
            return 2
        else:
            error(f"session not found: {session_id}")
            info("run `aiforge sessions` to list available sessions")
            return 1
    try:
        data = _json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        error(f"could not read session: {e}"); return 1

    info(f"session: {data.get('id', session_id)}   created: {data.get('created_at', '?')}")
    tasks = data.get("tasks", [])
    if not tasks:
        info("no tasks recorded in this session"); return 0

    for i, t in enumerate(tasks, 1):
        mark = "[green]✓[/green]" if t.get("success") else "[red]✗[/red]"
        console.print(f"\n[bold]{i}.[/bold] {mark} [cyan]{t.get('task', '')}[/cyan]")
        console.print(f"   [dim]{t.get('ts', '')}[/dim]")
        steps = t.get("steps", [])
        console.print(f"   steps: {len(steps)}")
        if t.get("final"):
            console.print(f"   result: {t['final'][:200]}")
        if t.get("reason") and not t.get("success"):
            console.print(f"   [red]reason: {t['reason'][:200]}[/red]")
        if steps:
            rows = []
            for s in steps:
                action = s.get("action", "?")
                ok = "✓" if s.get("success", True) else "✗"
                out = str(s.get("output") or s.get("result") or "")[:60]
                rows.append([ok, action, out])
            show_table(f"Steps for task {i}", ["ok", "action", "output"], rows)
    return 0


def cmd_workspace_show() -> int:
    ws = resolve_workspace()
    info(f"workspace: {ws}")
    cfg = _config()
    stored = cfg.get("workspace")
    if stored:
        info(f"stored in config: {stored}")
    env = __import__("os").environ.get("AIFORGE_WORKSPACE", "")
    if env:
        info(f"AIFORGE_WORKSPACE env: {env} (highest priority)")
    return 0


def cmd_workspace_set(path: str) -> int:
    from pathlib import Path as _Path
    target = _Path(path).expanduser().resolve()
    if not target.exists():
        error(f"path does not exist: {target}"); return 1
    if not target.is_dir():
        error(f"path is not a directory: {target}"); return 1
    cfg = _config()
    cfg.set("workspace", str(target))
    cfg.save()
    success(f"workspace set to: {target}")
    info("takes effect on next aiforge command (or restart TUI)")
    return 0


def cmd_setup() -> int:
    from aiforge.cli.setup import run_setup
    return run_setup()


def cmd_providers_list() -> int:
    try:
        cfg = _config()
    except ConfigError as e:
        error(str(e)); return 1
    providers = cfg.get("providers", {}) or {}
    default = cfg.get("default_provider") or ""
    rows = []
    for name in PROVIDER_ENV:
        p = providers.get(name, {}) or {}
        env_key = PROVIDER_ENV.get(name)
        if env_key is None:
            key_state = "n/a"
        else:
            key_state = "set" if (os.environ.get(env_key) or "").strip() else "missing"
        rows.append([
            name + (" *" if name == default else ""),
            "yes" if p.get("enabled") else "no",
            p.get("model") or "",
            p.get("url") or p.get("base_url") or p.get("host") or "",
            key_state,
        ])
    show_table("Providers", ["name", "enabled", "model", "endpoint", "key"], rows)
    info("'*' marks the default provider")
    return 0


def cmd_providers_enable(name: str) -> int:
    if name not in PROVIDER_ENV:
        error(f"unknown provider: {name} (choose: {', '.join(PROVIDER_ENV)})"); return 2
    cfg = _config()
    cfg.set(f"providers.{name}.enabled", True)
    cfg.save()
    success(f"enabled: {name}")
    return 0


def cmd_providers_disable(name: str) -> int:
    if name not in PROVIDER_ENV:
        error(f"unknown provider: {name} (choose: {', '.join(PROVIDER_ENV)})"); return 2
    cfg = _config()
    cfg.set(f"providers.{name}.enabled", False)
    cfg.save()
    warn(f"disabled: {name}")
    return 0


def cmd_models_list() -> int:
    from aiforge.models.providers.zapi import KNOWN_MODELS as ZAPI_MODELS
    cfg = _config()
    providers = cfg.get("providers", {}) or {}
    default = cfg.get("default_provider") or ""
    rows = []
    for slug, label in ZAPI_MODELS.items():
        is_def = (default == "zapi" and providers.get("zapi", {}).get("model") == slug)
        rows.append(["zapi", slug, label, "*" if is_def else ""])
    for name in ("openai", "openrouter", "ollama"):
        p = providers.get(name, {}) or {}
        if p.get("model"):
            rows.append([name, p["model"], "", "*" if default == name else ""])
    show_table("Models", ["provider", "model", "label", "default"], rows)
    info("'*' marks the active model on the default provider")
    return 0


def cmd_models_use(provider: str, model: str) -> int:
    if provider not in PROVIDER_ENV:
        error(f"unknown provider: {provider} (choose: {', '.join(PROVIDER_ENV)})"); return 2
    cfg = _config()
    cfg.set(f"providers.{provider}.model", model)
    cfg.set(f"providers.{provider}.enabled", True)
    cfg.set("default_provider", provider)
    cfg.save()
    success(f"using {provider}:{model} as default")
    return 0


def cmd_keys_set(provider: str, key: str) -> int:
    env_key = PROVIDER_ENV.get(provider)
    if not env_key:
        error(f"provider '{provider}' has no API key (or unknown)"); return 2
    from aiforge.cli.setup import write_env_key
    write_env_key(env_key, key)
    success(f"saved {env_key} to .env")
    return 0


def cmd_providers_test(name: str | None = None) -> int:
    """Send a tiny chat request to verify a provider really works."""
    from aiforge.models.base import ChatRequest, Message
    try:
        cfg = _config()
    except ConfigError as e:
        error(str(e)); return 1
    try:
        router = ModelRouter.from_config(cfg)
    except AIForgeError as e:
        error(str(e)); return 1
    if not router.names():
        error("no providers configured. Run `aiforge setup` first.")
        return 1
    targets = [name] if name else router.names()
    rc = 0
    for t in targets:
        try:
            model = router.get(t)
        except AIForgeError as e:
            error(f"{t}: {e}"); rc = 1; continue
        info(f"testing {t} ({getattr(model, 'name', t)})…")
        try:
            reply = model.chat(ChatRequest(
                messages=[Message(role="user", content="Reply with the single word OK.")],
                temperature=0.0,
                max_tokens=8,
            ))
        except AIForgeError as e:
            error(f"{t}: {e}"); rc = 1; continue
        except Exception as e:
            error(f"{t}: {type(e).__name__}: {str(e)[:300]}"); rc = 1; continue
        snippet = (reply or "").strip().splitlines()[0][:120] if reply else "(empty reply)"
        success(f"{t}: ok → {snippet}")
    return rc
