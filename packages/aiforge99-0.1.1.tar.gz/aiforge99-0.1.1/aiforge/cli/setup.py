import os
from pathlib import Path
from typing import Any

from dotenv import set_key
from prompt_toolkit import prompt

from aiforge.models.providers.zapi import KNOWN_MODELS as ZAPI_MODELS
from aiforge.runtime.config import Config
from aiforge.runtime.env import load_env
from aiforge.ui.console import console, info, success, system, warn

ENV_PATH = Path(".env")

PROVIDER_SPECS: list[dict[str, Any]] = [
    {
        "name": "zapi",
        "label": "ZAPI (z.os7.site)",
        "env_key": "ZAPI_API_KEY",
        "models": list(ZAPI_MODELS.keys()),
        "default_model": next(iter(ZAPI_MODELS)),
        "url_key": "url",
        "default_url": "https://z.os7.site",
    },
    {
        "name": "openai",
        "label": "OpenAI",
        "env_key": "OPENAI_API_KEY",
        "models": [],
        "default_model": "gpt-4o-mini",
        "url_key": None,
        "default_url": None,
    },
    {
        "name": "openrouter",
        "label": "OpenRouter",
        "env_key": "OPENROUTER_API_KEY",
        "models": [],
        "default_model": "openai/gpt-4o-mini",
        "url_key": None,
        "default_url": None,
    },
    {
        "name": "ollama",
        "label": "Ollama (local)",
        "env_key": None,
        "models": [],
        "default_model": "llama3",
        "url_key": "host",
        "default_url": "http://localhost:11434",
    },
]


def _ensure_env_file() -> None:
    if not ENV_PATH.exists():
        ENV_PATH.write_text("# AIForge environment\n", encoding="utf-8")


def write_env_key(key: str, value: str) -> None:
    _ensure_env_file()
    set_key(str(ENV_PATH), key, value)
    os.environ[key] = value


def _has_key(env_key: str | None) -> bool:
    if not env_key:
        return True
    return bool((os.environ.get(env_key) or "").strip())


def _ask(prompt_text: str) -> str:
    try:
        return prompt(prompt_text).strip()
    except (EOFError, KeyboardInterrupt):
        console.print()
        return ""


def _ask_secret(prompt_text: str) -> str:
    try:
        return prompt(prompt_text, is_password=True).strip()
    except (EOFError, KeyboardInterrupt):
        console.print()
        return ""


def run_setup() -> int:
    """Interactive provider/key/model setup. Persists to .aiforge/config.json and .env."""
    load_env()
    cfg = Config()

    system("=" * 60)
    system(" AIForge setup — providers, keys, models")
    system("=" * 60)

    for spec in PROVIDER_SPECS:
        provider_cfg = cfg.get(f"providers.{spec['name']}", {}) or {}
        enabled = bool(provider_cfg.get("enabled"))
        info(f"\n[{spec['label']}]")
        info(f"  enabled  : {enabled}")
        if spec["env_key"]:
            info(f"  api key  : {'set' if _has_key(spec['env_key']) else 'missing'} ({spec['env_key']})")
        if spec["url_key"]:
            info(f"  endpoint : {provider_cfg.get(spec['url_key'], spec['default_url'])}")
        if provider_cfg.get("model"):
            info(f"  model    : {provider_cfg['model']}")

        ans = _ask("  Action [e]nable / [d]isable / [k]ey / [m]odel / [u]rl / [s]kip > ").lower()
        if not ans or ans == "s":
            continue

        if ans == "e":
            cfg.set(f"providers.{spec['name']}.enabled", True)
            if not provider_cfg.get("model") and spec["default_model"]:
                cfg.set(f"providers.{spec['name']}.model", spec["default_model"])
            success(f"enabled: {spec['name']}")
        elif ans == "d":
            cfg.set(f"providers.{spec['name']}.enabled", False)
            warn(f"disabled: {spec['name']}")
        elif ans == "k":
            if not spec["env_key"]:
                warn("this provider has no API key"); continue
            key = _ask_secret(f"  Enter {spec['env_key']}: ")
            if key:
                write_env_key(spec["env_key"], key)
                success(f"saved {spec['env_key']} to .env")
        elif ans == "m":
            if spec["models"]:
                for i, m in enumerate(spec["models"], 1):
                    label = ZAPI_MODELS.get(m, "") if spec["name"] == "zapi" else ""
                    suffix = f"   {label}" if label else ""
                    console.print(f"    {i}) {m}{suffix}")
            pick = _ask("  Choose model number or type a name: ")
            chosen = ""
            if pick.isdigit() and spec["models"]:
                idx = int(pick) - 1
                if 0 <= idx < len(spec["models"]):
                    chosen = spec["models"][idx]
            elif pick:
                chosen = pick
            if chosen:
                cfg.set(f"providers.{spec['name']}.model", chosen)
                success(f"model: {chosen}")
        elif ans == "u":
            if not spec["url_key"]:
                warn("this provider has no endpoint"); continue
            current = provider_cfg.get(spec["url_key"], spec["default_url"])
            new = _ask(f"  Endpoint [{current}]: ")
            if new:
                cfg.set(f"providers.{spec['name']}.{spec['url_key']}", new)
                success(f"endpoint: {new}")
        else:
            warn(f"unknown action: {ans}")

    enabled_names = [
        s["name"] for s in PROVIDER_SPECS
        if cfg.get(f"providers.{s['name']}.enabled")
    ]
    if enabled_names:
        system("\nDefault provider")
        info(f"  enabled: {', '.join(enabled_names)}")
        current = cfg.get("default_provider") or enabled_names[0]
        ans = _ask(f"  Default provider [{current}]: ")
        chosen = ans if ans in enabled_names else current
        if chosen in enabled_names:
            cfg.set("default_provider", chosen)
            success(f"default provider: {chosen}")
    else:
        warn("\nNo providers enabled — agent cannot run yet.")

    cfg.save()
    success("setup saved to .aiforge/config.json")
    return 0
