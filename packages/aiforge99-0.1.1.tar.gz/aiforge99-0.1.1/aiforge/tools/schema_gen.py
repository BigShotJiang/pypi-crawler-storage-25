"""
Generate OpenAI-compatible tool schemas from the AIForge ToolRegistry.

These schemas are used when calling models that support native function calling
(OpenAI, OpenRouter, Anthropic, etc.) — which produces far more reliable
structured output than free-form JSON prompting.
"""
from __future__ import annotations

import inspect
from typing import Any

from aiforge.tools.registry import ToolRegistry


def _python_type_to_json_schema(annotation: Any) -> dict:
    """Convert a Python type annotation to a JSON Schema dict."""
    if annotation is inspect.Parameter.empty:
        return {"type": "string"}

    origin = getattr(annotation, "__origin__", None)

    # Optional[X] → same as X
    if origin is type(None):
        return {"type": "null"}

    # Handle Union / Optional
    if origin is getattr(__import__("typing"), "Union", None):
        args = [a for a in annotation.__args__ if a is not type(None)]
        if len(args) == 1:
            return _python_type_to_json_schema(args[0])

    if annotation in (str, "str"):
        return {"type": "string"}
    if annotation in (int, "int"):
        return {"type": "integer"}
    if annotation in (float, "float"):
        return {"type": "number"}
    if annotation in (bool, "bool"):
        return {"type": "boolean"}
    if origin is list:
        inner = annotation.__args__[0] if hasattr(annotation, "__args__") else str
        return {"type": "array", "items": _python_type_to_json_schema(inner)}
    if origin is dict:
        return {"type": "object"}

    # Fallback — try annotation name as hint
    try:
        name = annotation.__name__.lower()
        if "str" in name or "path" in name or "url" in name:
            return {"type": "string"}
        if "int" in name:
            return {"type": "integer"}
        if "bool" in name or "flag" in name:
            return {"type": "boolean"}
    except AttributeError:
        pass

    return {"type": "string"}


def build_openai_tools(registry: ToolRegistry) -> list[dict[str, Any]]:
    """
    Convert the tool registry into OpenAI-compatible tool schemas.

    Each tool must have a `run(**kwargs)` method with proper type annotations.
    Parameters named `self` and `permissions` are skipped.
    """
    tools_list = []

    for tool in registry.all():
        try:
            sig = inspect.signature(tool.run)
        except (ValueError, TypeError):
            continue

        properties: dict[str, Any] = {}
        required: list[str] = []

        for param_name, param in sig.parameters.items():
            if param_name in ("self",):
                continue

            annotation = param.annotation
            schema = _python_type_to_json_schema(annotation)

            # Add description from docstring if available
            doc = inspect.getdoc(tool.run) or ""
            if param_name in doc:
                # Try to extract inline description (naive)
                schema["description"] = param_name.replace("_", " ")

            properties[param_name] = schema

            # Required if no default value
            if param.default is inspect.Parameter.empty:
                required.append(param_name)

        # Sanitize tool name: OpenAI doesn't allow dots
        safe_name = tool.name.replace(".", "__")

        tools_list.append({
            "type": "function",
            "function": {
                "name": safe_name,
                "description": tool.description[:300],
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            },
        })

    return tools_list
