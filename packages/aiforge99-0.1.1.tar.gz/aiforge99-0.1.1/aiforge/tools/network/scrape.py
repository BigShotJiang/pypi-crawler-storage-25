from aiforge.runtime.errors import NotImplementedFeatureError


class NetworkScrapeTool:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("tools.network.scrape (HTML structured scraping)")
