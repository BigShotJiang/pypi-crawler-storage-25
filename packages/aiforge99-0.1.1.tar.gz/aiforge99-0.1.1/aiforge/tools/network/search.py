from __future__ import annotations

from html import unescape
from html.parser import HTMLParser
from urllib.parse import parse_qs, urlparse

import httpx

from aiforge.tools.base import BaseTool
from aiforge.tools.permissions import Permissions
from aiforge.tools.result import ToolResult


_DDG_HTML_ENDPOINT = "https://html.duckduckgo.com/html/"
_USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
)


class _DDGResultsParser(HTMLParser):
    """Pulls (title, url, snippet) tuples out of DuckDuckGo's HTML results page."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.results: list[dict[str, str]] = []
        self._mode: str | None = None
        self._depth = 0
        self._current_href: str | None = None
        self._current_title_parts: list[str] = []
        self._current_snippet_parts: list[str] = []

    @staticmethod
    def _has_class(attrs: list[tuple[str, str | None]], cls: str) -> bool:
        for name, value in attrs:
            if name == "class" and value:
                if cls in value.split():
                    return True
        return False

    @staticmethod
    def _attr(attrs: list[tuple[str, str | None]], name: str) -> str | None:
        for k, v in attrs:
            if k == name:
                return v
        return None

    @staticmethod
    def _clean_url(href: str) -> str:
        if href.startswith("//duckduckgo.com/l/") or href.startswith("/l/"):
            parsed = urlparse(href if href.startswith("http") else "https:" + href.lstrip("/"))
            qs = parse_qs(parsed.query)
            uddg = qs.get("uddg")
            if uddg:
                return uddg[0]
        return href

    def handle_starttag(self, tag, attrs):
        if tag == "a" and self._has_class(attrs, "result__a"):
            self._mode = "title"
            self._depth = 1
            self._current_href = self._clean_url(self._attr(attrs, "href") or "")
            self._current_title_parts = []
            return
        if tag == "a" and self._has_class(attrs, "result__snippet"):
            self._mode = "snippet"
            self._depth = 1
            self._current_snippet_parts = []
            return
        if self._mode == "snippet" and self._has_class(attrs, "result__snippet"):
            self._depth += 1
            return
        if self._mode in ("title", "snippet"):
            self._depth += 1

    def handle_endtag(self, tag):
        if self._mode is None:
            return
        self._depth -= 1
        if self._depth > 0:
            return
        if self._mode == "title":
            title = unescape("".join(self._current_title_parts)).strip()
            url = self._current_href or ""
            if title and url:
                self.results.append({"title": title, "url": url, "snippet": ""})
        elif self._mode == "snippet":
            snippet = unescape("".join(self._current_snippet_parts)).strip()
            if self.results and not self.results[-1]["snippet"]:
                self.results[-1]["snippet"] = snippet
        self._mode = None
        self._current_href = None

    def handle_data(self, data):
        if self._mode == "title":
            self._current_title_parts.append(data)
        elif self._mode == "snippet":
            self._current_snippet_parts.append(data)


class NetworkSearchTool(BaseTool):
    """Real web search via DuckDuckGo's HTML endpoint. No API key required."""

    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "network.search"

    @property
    def description(self) -> str:
        return "Search the web (DuckDuckGo) and return ranked results: title, url, snippet."

    def run(self, query: str, max_results: int = 10, timeout: int = 20) -> ToolResult:
        self.permissions.check_network()
        q = (query or "").strip()
        if not q:
            return ToolResult.fail("query must not be empty")
        try:
            limit = max(1, min(int(max_results), 50))
        except (TypeError, ValueError):
            return ToolResult.fail("max_results must be an integer")

        try:
            resp = httpx.post(
                _DDG_HTML_ENDPOINT,
                data={"q": q, "kl": "us-en"},
                headers={
                    "User-Agent": _USER_AGENT,
                    "Accept": "text/html,application/xhtml+xml",
                    "Accept-Language": "en-US,en;q=0.9",
                },
                timeout=timeout,
                follow_redirects=True,
            )
        except httpx.HTTPError as e:
            return ToolResult.fail(f"{type(e).__name__}: {e}")

        if not (200 <= resp.status_code < 300):
            return ToolResult.fail(f"HTTP {resp.status_code} from DuckDuckGo")

        parser = _DDGResultsParser()
        parser.feed(resp.text)
        results = parser.results[:limit]

        if not results:
            return ToolResult(
                success=True,
                output=[],
                error=None,
                metadata={"query": q, "count": 0, "source": "duckduckgo"},
            )

        return ToolResult(
            success=True,
            output=results,
            error=None,
            metadata={"query": q, "count": len(results), "source": "duckduckgo"},
        )
