import httpx

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions


class NetworkFetchTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "network.fetch"

    @property
    def description(self) -> str:
        return "HTTP GET a URL and return the response body."

    def run(self, url: str, timeout: int = 30, headers: dict | None = None) -> ToolResult:
        self.permissions.check_network()
        try:
            resp = httpx.get(url, timeout=timeout, headers=headers or {}, follow_redirects=True)
        except httpx.HTTPError as e:
            return ToolResult.fail(f"{type(e).__name__}: {e}")
        ok = 200 <= resp.status_code < 300
        return ToolResult(
            success=ok,
            output=resp.text if ok else None,
            error=None if ok else f"HTTP {resp.status_code}",
            metadata={"status": resp.status_code, "url": str(resp.url), "bytes": len(resp.content)},
        )
