from aiforge.runtime.errors import NotImplementedFeatureError


class ProjectIndex:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("tools.project.index (symbol/AST indexing)")
