"""
Test runner tool for AIForge.

Auto-detects the test framework (pytest, unittest, jest, mocha, cargo test, go test, etc.)
and runs tests, returning structured pass/fail counts with failure summaries.
"""
from __future__ import annotations

import re
from pathlib import Path

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.tools.sandbox import Sandbox


# Detection patterns: (file/pattern to check, command to run, framework name)
_FRAMEWORK_DETECTORS = [
    # Python
    ("pytest.ini",        "python -m pytest -v --tb=short 2>&1", "pytest"),
    ("setup.cfg",         "python -m pytest -v --tb=short 2>&1", "pytest"),
    ("pyproject.toml",    "python -m pytest -v --tb=short 2>&1", "pytest"),
    ("tests/",            "python -m pytest -v --tb=short 2>&1", "pytest"),
    ("test/",             "python -m pytest -v --tb=short 2>&1", "pytest"),
    # JavaScript / Node
    ("package.json",      "npm test 2>&1", "npm test"),
    ("jest.config.js",    "npx jest --no-coverage 2>&1", "jest"),
    ("jest.config.ts",    "npx jest --no-coverage 2>&1", "jest"),
    # Rust
    ("Cargo.toml",        "cargo test 2>&1", "cargo test"),
    # Go
    ("go.mod",            "go test ./... 2>&1", "go test"),
    # Java / Gradle
    ("build.gradle",      "./gradlew test 2>&1", "gradle test"),
    ("pom.xml",           "mvn test -B 2>&1", "maven test"),
]


def _detect_framework(workspace: str) -> tuple[str, str] | None:
    """Return (command, framework_name) for the first detected framework."""
    root = Path(workspace)
    for marker, cmd, name in _FRAMEWORK_DETECTORS:
        if (root / marker).exists():
            # For package.json, verify there is a test script
            if marker == "package.json":
                try:
                    import json
                    pkg = json.loads((root / "package.json").read_text())
                    if "test" not in pkg.get("scripts", {}):
                        continue
                except Exception:
                    continue
            return cmd, name
    return None


def _parse_pytest_summary(output: str) -> dict:
    """Extract pass/fail counts from pytest output."""
    summary = {}
    # E.g. "5 passed, 2 failed, 1 error in 1.23s"
    m = re.search(
        r"(\d+) passed(?:, (\d+) failed)?(?:, (\d+) error)?",
        output, re.IGNORECASE
    )
    if m:
        summary["passed"] = int(m.group(1) or 0)
        summary["failed"] = int(m.group(2) or 0)
        summary["errors"] = int(m.group(3) or 0)

    # Grab FAILED lines
    failures = re.findall(r"FAILED (.+)", output)
    if failures:
        summary["failing_tests"] = failures[:10]
    return summary


def _parse_jest_summary(output: str) -> dict:
    """Extract pass/fail counts from Jest output."""
    summary = {}
    m = re.search(r"Tests:\s+(\d+) passed", output)
    if m:
        summary["passed"] = int(m.group(1))
    m2 = re.search(r"(\d+) failed", output)
    if m2:
        summary["failed"] = int(m2.group(1))
    return summary


class TestRunnerTool(BaseTool):
    """
    Automatically detect and run the project's test suite.

    Supports: pytest, jest, cargo test, go test, gradle test, maven test.
    """

    def __init__(self, permissions: Permissions):
        self.permissions = permissions
        self._sandbox = Sandbox(sandbox_root=permissions.workspace_root)

    @property
    def name(self) -> str:
        return "project.test"

    @property
    def description(self) -> str:
        return (
            "Run the project's test suite. Auto-detects pytest, jest, cargo, go test, etc. "
            "Optional args: command (override auto-detected command), "
            "timeout (default 120 seconds), path (specific test file or directory). "
            "Returns pass/fail counts and failure details."
        )

    def run(
        self,
        command: str | None = None,
        path: str | None = None,
        timeout: int = 120,
    ) -> ToolResult:
        self.permissions.check_shell("")
        workspace = self.permissions.workspace_root

        # Detect or use provided command
        if command:
            cmd = command
            framework = "custom"
        else:
            detected = _detect_framework(workspace)
            if not detected:
                return ToolResult.fail(
                    "No test framework detected. Common markers not found: "
                    "pytest.ini, package.json with test script, Cargo.toml, go.mod, etc. "
                    "Use the 'command' argument to specify the test command directly."
                )
            cmd, framework = detected

        # Append specific path if requested
        if path:
            cmd = f"{cmd} {path}"

        result = self._sandbox.run(cmd, timeout=timeout)
        output = result.combined

        # Parse summary
        summary: dict = {"framework": framework, "command": cmd}
        if "pytest" in framework:
            summary.update(_parse_pytest_summary(output))
        elif "jest" in framework or "npm" in framework:
            summary.update(_parse_jest_summary(output))

        passed = summary.get("passed", "?")
        failed = summary.get("failed", 0)

        if result.timed_out:
            return ToolResult.fail(
                f"Tests timed out after {timeout}s\n{output[:1000]}",
                **summary,
            )

        if result.returncode == 0 or (isinstance(failed, int) and failed == 0 and passed != "?"):
            return ToolResult.ok(
                f"Tests passed ({framework}): {passed} passed, {failed} failed\n\n{output[-2000:]}",
                **summary,
            )

        return ToolResult(
            success=False,
            output=f"Tests FAILED ({framework}): {passed} passed, {failed} failed",
            error=output[-2000:],
            metadata=summary,
        )
