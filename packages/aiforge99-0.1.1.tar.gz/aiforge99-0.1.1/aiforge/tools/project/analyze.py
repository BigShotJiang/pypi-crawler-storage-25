from collections import Counter
from pathlib import Path

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.runtime.guardrails import assert_path_within

SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", ".pytest_cache",
             ".aiforge", ".cache", ".pythonlibs", ".upm", ".local", ".agents",
             "aiforge.egg-info", "dist", "build"}


class ProjectAnalyzeTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "project.analyze"

    @property
    def description(self) -> str:
        return "Count files by extension and total LOC under a path."

    def run(self, path: str = ".") -> ToolResult:
        root = assert_path_within(path, self.permissions.workspace_root)
        if not root.exists() or not root.is_dir():
            return ToolResult.fail(f"Not a directory: {root}")
        ext_counts: Counter = Counter()
        total_files = 0
        total_lines = 0
        total_bytes = 0
        for p in root.rglob("*"):
            if any(part in SKIP_DIRS for part in p.parts):
                continue
            if not p.is_file():
                continue
            total_files += 1
            total_bytes += p.stat().st_size
            ext = p.suffix or "<none>"
            ext_counts[ext] += 1
            try:
                total_lines += sum(1 for _ in p.open("rb"))
            except Exception:
                pass
        return ToolResult.ok({
            "files": total_files,
            "lines": total_lines,
            "bytes": total_bytes,
            "by_extension": dict(ext_counts.most_common()),
        }, path=str(root))
