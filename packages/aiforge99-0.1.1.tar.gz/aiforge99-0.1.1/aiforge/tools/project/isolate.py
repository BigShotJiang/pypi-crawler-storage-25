from aiforge.runtime.errors import NotImplementedFeatureError


class ProjectIsolate:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("tools.project.isolate (sub-workspace isolation)")
