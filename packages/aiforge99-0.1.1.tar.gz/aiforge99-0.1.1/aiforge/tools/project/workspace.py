from pathlib import Path

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.runtime.guardrails import assert_path_within


class ProjectWorkspaceTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "project.workspace"

    @property
    def description(self) -> str:
        return (
            f"List files and directories under workspace root {self.permissions.workspace_root}. "
            "Use path='.' for the root or a subdirectory like 'src'. "
            "Call this FIRST to understand what files already exist before creating or editing."
        )

    def run(self, path: str = ".", show_hidden: bool = False) -> ToolResult:
        p = assert_path_within(path, self.permissions.workspace_root)
        if not p.exists():
            return ToolResult.fail(f"Path not found: {p}")
        if not p.is_dir():
            return ToolResult.fail(f"Not a directory: {p}")
        entries = []
        for child in sorted(p.iterdir(), key=lambda c: (not c.is_dir(), c.name.lower())):
            if not show_hidden and child.name.startswith("."):
                continue
            entries.append({
                "name": child.name,
                "type": "dir" if child.is_dir() else "file",
                "size": child.stat().st_size if child.is_file() else None,
            })
        return ToolResult.ok(entries, path=str(p), count=len(entries))
