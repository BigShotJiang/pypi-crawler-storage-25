from pathlib import Path

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.runtime.guardrails import assert_path_within


class ProjectScaffoldTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "project.scaffold"

    @property
    def description(self) -> str:
        return "Create a directory tree from a list of relative paths (dirs end with '/')."

    def run(self, root: str, paths: list[str]) -> ToolResult:
        self.permissions.check_write()
        base = assert_path_within(root, self.permissions.workspace_root)
        base.mkdir(parents=True, exist_ok=True)
        created = []
        for rel in paths:
            target = (base / rel).resolve()
            assert_path_within(target, base)
            if rel.endswith("/"):
                target.mkdir(parents=True, exist_ok=True)
                created.append(f"dir:{target}")
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                if not target.exists():
                    target.touch()
                created.append(f"file:{target}")
        return ToolResult.ok(created, root=str(base), count=len(created))
