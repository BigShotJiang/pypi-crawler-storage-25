"""
AIForge Process Sandbox.

Provides isolated shell execution scoped to the agent user workspace.
Commands run in <workspace>/aiforge/user/ with:
  - Strict working directory confinement
  - Environment filtering — keeps tools (PATH, Python, Node…) but strips API secrets
  - Configurable timeouts with SIGTERM → SIGKILL process group kill
  - Separate stdout/stderr capture
  - Exit-code tracking and rich error reporting
"""
from __future__ import annotations

import os
import signal
import subprocess
from pathlib import Path
from typing import NamedTuple


class SandboxResult(NamedTuple):
    returncode: int
    stdout: str
    stderr: str
    timed_out: bool
    cwd: str

    @property
    def success(self) -> bool:
        return self.returncode == 0 and not self.timed_out

    @property
    def combined(self) -> str:
        parts = []
        if self.stdout.strip():
            parts.append(self.stdout.rstrip())
        if self.stderr.strip():
            parts.append(f"[stderr]\n{self.stderr.rstrip()}")
        return "\n".join(parts) if parts else "(no output)"


# Keys whose values are safe to pass through to child processes
_SAFE_ENV_PREFIXES = (
    "AIFORGE_",
    "VIRTUAL_ENV",
    "CONDA_",
    "PYENV_",
    "NVM_",
    "GOENV_",
    "CARGO_",
    "RUSTUP_",
    "NODE_",
    "NPM_CONFIG",
    "YARN_",
    "PNPM_",
)
_SAFE_ENV_KEYS = {
    "PATH", "HOME", "USER", "LOGNAME", "SHELL", "TERM", "COLORTERM",
    "LANG", "LC_ALL", "LC_CTYPE", "LC_MESSAGES", "LANGUAGE",
    "COLUMNS", "LINES", "TERM_PROGRAM",
    "TMPDIR", "TMP", "TEMP", "XDG_RUNTIME_DIR", "XDG_CACHE_HOME", "XDG_CONFIG_HOME",
    "PYTHONPATH", "PYTHONIOENCODING", "PYTHONDONTWRITEBYTECODE",
    "GOPATH", "GOROOT",
    "JAVA_HOME",
    "GIT_AUTHOR_NAME", "GIT_AUTHOR_EMAIL", "GIT_COMMITTER_NAME", "GIT_COMMITTER_EMAIL",
    "CI", "REPL_ID", "REPLIT_DB_URL",
}
# Keys that MUST be blocked even if they match prefixes (contain secrets)
_BLOCKED_KEYS = {
    "ZAPI_API_KEY", "OPENAI_API_KEY", "OPENROUTER_API_KEY",
    "BYTEZ_API_KEY", "ANTHROPIC_API_KEY", "GOOGLE_API_KEY",
    "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN",
    "GITHUB_TOKEN", "GITLAB_TOKEN",
    "DATABASE_URL", "POSTGRES_URL", "MONGO_URL", "REDIS_URL",
}


def _filtered_env() -> dict[str, str]:
    """
    Build a clean environment that:
    - Preserves the full system PATH (so npm, python, pip, node, git all work)
    - Blocks API keys and secrets
    - Keeps standard tool variables
    """
    env: dict[str, str] = {}
    host_env = os.environ

    for key, val in host_env.items():
        if key in _BLOCKED_KEYS:
            continue
        if key in _SAFE_ENV_KEYS:
            env[key] = val
            continue
        if any(key.startswith(p) for p in _SAFE_ENV_PREFIXES):
            env[key] = val
            continue

    # Always ensure PATH is comprehensive — include all nix store paths + user paths
    if "PATH" not in env:
        env["PATH"] = host_env.get("PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin")

    # Ensure HOME is set (needed by npm, pip, etc.)
    if "HOME" not in env:
        env["HOME"] = host_env.get("HOME", "/home/runner")

    return env


class Sandbox:
    """
    Lightweight process sandbox for running shell commands in the agent workspace.

    All commands execute with cwd=<sandbox_root> unless an explicit sub-path
    inside the sandbox is provided. Paths outside the sandbox root are rejected.
    """

    def __init__(self, sandbox_root: str | Path | None = None) -> None:
        if sandbox_root is None:
            from aiforge.runtime.workspace import resolve_user_workspace
            sandbox_root = resolve_user_workspace()
        self.root = Path(sandbox_root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # public API
    # ------------------------------------------------------------------

    def run(
        self,
        command: str,
        cwd: str | None = None,
        timeout: int = 60,
        env_extra: dict[str, str] | None = None,
    ) -> SandboxResult:
        """
        Execute *command* inside the sandbox.

        :param command:   Shell command string (run via /bin/sh -c).
        :param cwd:       Working directory relative to sandbox root, or None for root.
        :param timeout:   Hard wall-clock timeout in seconds.
        :param env_extra: Additional env vars merged on top of the filtered env.
        :returns:         SandboxResult with returncode, stdout, stderr, timed_out.
        :raises PermissionError: if *cwd* escapes the sandbox root.
        """
        run_dir = self._resolve_cwd(cwd)
        env = _filtered_env()
        if env_extra:
            env.update(env_extra)

        proc: subprocess.Popen | None = None
        timed_out = False
        try:
            proc = subprocess.Popen(
                command,
                shell=True,
                executable="/bin/sh",
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                cwd=str(run_dir),
                env=env,
                start_new_session=True,  # separate process group for clean kill
            )
            stdout, stderr = proc.communicate(timeout=timeout)
            returncode = proc.returncode
        except subprocess.TimeoutExpired:
            timed_out = True
            returncode = -1
            stdout = ""
            stderr = f"Command timed out after {timeout}s"
            if proc is not None:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                except Exception:
                    pass
                try:
                    proc.wait(timeout=3)
                except Exception:
                    try:
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    except Exception:
                        pass

        return SandboxResult(
            returncode=returncode,
            stdout=stdout,
            stderr=stderr,
            timed_out=timed_out,
            cwd=str(run_dir),
        )

    def write_file(self, rel_path: str, content: str, encoding: str = "utf-8") -> Path:
        """Write *content* to a file inside the sandbox, creating parent dirs."""
        p = self._resolve_path(rel_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding=encoding)
        return p

    def read_file(self, rel_path: str, encoding: str = "utf-8") -> str:
        """Read a file inside the sandbox."""
        p = self._resolve_path(rel_path)
        return p.read_text(encoding=encoding)

    def exists(self, rel_path: str) -> bool:
        try:
            return self._resolve_path(rel_path).exists()
        except PermissionError:
            return False

    # ------------------------------------------------------------------
    # internals
    # ------------------------------------------------------------------

    def _resolve_path(self, rel_path: str) -> Path:
        p = (self.root / rel_path).resolve()
        if not str(p).startswith(str(self.root)):
            raise PermissionError(
                f"Path '{rel_path}' escapes the sandbox root '{self.root}'"
            )
        return p

    def _resolve_cwd(self, cwd: str | None) -> Path:
        if not cwd:
            return self.root
        return self._resolve_path(cwd)
