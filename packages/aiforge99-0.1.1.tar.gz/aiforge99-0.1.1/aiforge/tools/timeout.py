import signal
from contextlib import contextmanager

from aiforge.runtime.errors import ToolTimeoutError


@contextmanager
def time_limit(seconds: int):
    if seconds <= 0:
        yield
        return

    def handler(signum, frame):
        raise ToolTimeoutError(f"Operation exceeded {seconds}s timeout")

    prev = signal.signal(signal.SIGALRM, handler)
    signal.alarm(seconds)
    try:
        yield
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, prev)
