from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


def _default_workspace() -> str:
    from aiforge.runtime.workspace import workspace_str
    return workspace_str()


@dataclass
class Permissions:
    allow_shell: bool = True
    allow_network: bool = True
    allow_write: bool = True
    allow_delete: bool = True
    workspace_root: str = field(default_factory=_default_workspace)
    shell_denylist: list[str] = field(default_factory=lambda: ["rm -rf /", ":(){:|:&};:"])

    def __post_init__(self) -> None:
        self.workspace_root = str(Path(self.workspace_root).expanduser().resolve())

    def check_shell(self, command: str) -> None:
        from aiforge.runtime.errors import ToolPermissionError
        if not self.allow_shell:
            raise ToolPermissionError("Shell execution is disabled")
        for bad in self.shell_denylist:
            if bad in command:
                raise ToolPermissionError(f"Denied shell pattern: {bad}")

    def check_write(self) -> None:
        from aiforge.runtime.errors import ToolPermissionError
        if not self.allow_write:
            raise ToolPermissionError("Write operations are disabled")

    def check_delete(self) -> None:
        from aiforge.runtime.errors import ToolPermissionError
        if not self.allow_delete:
            raise ToolPermissionError("Delete operations are disabled")

    def check_network(self) -> None:
        from aiforge.runtime.errors import ToolPermissionError
        if not self.allow_network:
            raise ToolPermissionError("Network access is disabled")
