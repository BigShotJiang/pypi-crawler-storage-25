"""
memory.recall — lets the agent search its own long-term memory.

The agent can use this to find what it did in previous tasks:
  memory.recall query="index.html"   → returns tasks that mention index.html
  memory.recall query=""             → returns the last N task summaries
"""
from __future__ import annotations

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult


class MemoryRecallTool(BaseTool):
    @property
    def name(self) -> str:
        return "memory.recall"

    @property
    def description(self) -> str:
        return (
            "Search long-term memory for past tasks and observations. "
            "Use query='' to get recent task history, or query='<keyword>' to find "
            "tasks mentioning a specific file or topic. Returns task summaries with timestamps. "
            "Call this when the user references something you may have done before."
        )

    def run(self, query: str = "", limit: int = 10) -> ToolResult:
        from aiforge.memory.long_term import LongTermMemory
        ltm = LongTermMemory()
        if query.strip():
            records = ltm.search(query.strip())
        else:
            records = ltm.all()

        # Keep only the last N records
        records = records[-limit:]

        if not records:
            return ToolResult.ok(
                "No memory records found." + (f" (searched: '{query}')" if query else ""),
                count=0,
            )

        results = []
        for r in records:
            entry = {
                "ts": r.get("ts", "?"),
                "kind": r.get("kind", "?"),
            }
            content = r.get("content", "")
            if isinstance(content, str):
                entry["summary"] = content[:200]
            elif isinstance(content, dict):
                entry["task"] = str(content.get("task", ""))[:100]
                entry["result"] = str(content.get("result", ""))[:100]
                entry["success"] = content.get("success", "?")
                entry["steps"] = content.get("steps", 0)
            else:
                entry["summary"] = str(content)[:200]
            results.append(entry)

        return ToolResult.ok(results, count=len(results), query=query)
