from typing import Any

from aiforge.tools.registry import ToolRegistry
from aiforge.tools.result import ToolResult
from aiforge.runtime.errors import ToolError


class ToolDispatcher:
    def __init__(self, registry: ToolRegistry):
        self.registry = registry

    def dispatch(self, name: str, **kwargs: Any) -> ToolResult:
        tool = self.registry.get(name)
        try:
            result = tool.run(**kwargs)
        except ToolError as e:
            return ToolResult.fail(str(e), tool=name)
        except Exception as e:
            return ToolResult.fail(f"{type(e).__name__}: {e}", tool=name)
        if not isinstance(result, ToolResult):
            return ToolResult.fail(
                f"Tool '{name}' returned {type(result).__name__}, expected ToolResult"
            )
        result.metadata.setdefault("tool", name)
        return result
