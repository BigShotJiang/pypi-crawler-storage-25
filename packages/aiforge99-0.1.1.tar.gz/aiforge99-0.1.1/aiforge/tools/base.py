from abc import ABC, abstractmethod
from typing import Any

from aiforge.tools.result import ToolResult


class BaseTool(ABC):
    @property
    @abstractmethod
    def name(self) -> str: ...

    @property
    @abstractmethod
    def description(self) -> str: ...

    @property
    def parameters(self) -> dict:
        return {}

    @abstractmethod
    def run(self, **kwargs: Any) -> ToolResult: ...
