from __future__ import annotations

from pathlib import Path

from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.widget import Widget
from textual.widgets import Static


_ICONS: dict[str, str] = {
    ".py": "🐍", ".json": "📋", ".md": "📝", ".txt": "📄",
    ".sh": "⚡", ".toml": "⚙", ".yaml": "⚙", ".yml": "⚙",
    ".env": "🔑", ".lock": "🔒", ".ts": "📘", ".js": "📜",
    ".html": "🌐", ".css": "🎨", ".rs": "🦀", ".go": "🐹",
    ".c": "©", ".cpp": "©", ".h": "©", ".java": "☕",
    ".rb": "💎", ".php": "🐘", ".swift": "🐦",
}
_DIR_ICON = "📁"
_FILE_ICON = "📄"

_SKIP_DIRS: set[str] = {
    ".git", "__pycache__", ".cache", "node_modules", ".pythonlibs",
    "aiforge.egg-info", ".agents", ".upm", ".local", "dist", "build",
    ".pytest_cache", ".ruff_cache", ".mypy_cache", ".venv", "venv",
    ".tox", "*.egg-info",
}

_COLLAPSE_DIRS: set[str] = {"sessions", "logs", "memory", "cache"}


def _human_size(n: int) -> str:
    if n < 1024:
        return f"{n}B"
    if n < 1024 * 1024:
        return f"{n // 1024}KB"
    return f"{n // (1024 * 1024)}MB"


def _build_tree(root: Path, indent: int = 0, max_depth: int = 4) -> list[str]:
    if indent >= max_depth:
        return []
    lines: list[str] = []
    try:
        entries = sorted(root.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))
    except PermissionError:
        return []
    for entry in entries:
        if entry.name in _SKIP_DIRS:
            continue
        if entry.name.startswith(".") and entry.name not in (".aiforge", ".env", ".gitignore"):
            continue
        pad = "  " * indent
        connector = "└─ " if indent > 0 else ""
        if entry.is_dir():
            if entry.name in _COLLAPSE_DIRS:
                try:
                    count = sum(1 for _ in entry.iterdir())
                except Exception:
                    count = 0
                lines.append(
                    f"{pad}{connector}[bold #e3b341]{_DIR_ICON}[/] [dim]{entry.name}/[/] "
                    f"[dim #8b949e]({count})[/]"
                )
            else:
                lines.append(
                    f"{pad}{connector}[bold #e3b341]{_DIR_ICON}[/] [bold #e6edf3]{entry.name}/[/]"
                )
                lines.extend(_build_tree(entry, indent + 1, max_depth))
        else:
            icon = _ICONS.get(entry.suffix, _FILE_ICON)
            size_str = _human_size(entry.stat().st_size)
            lines.append(
                f"{pad}{connector}[#58a6ff]{icon}[/] [#e6edf3]{entry.name}[/] "
                f"[dim #8b949e]{size_str}[/]"
            )
    return lines


class FileSystemPanel(Widget):
    DEFAULT_CSS = """
    FileSystemPanel {
        height: 1fr;
        width: 26;
    }
    FileSystemPanel VerticalScroll {
        height: 1fr;
        padding: 0 1;
        background: #0d1117;
    }
    FileSystemPanel Static {
        height: auto;
    }
    """

    def __init__(self, workspace_root: str = ".", **kwargs) -> None:
        super().__init__(**kwargs)
        self._root = str(Path(workspace_root).resolve())

    def compose(self) -> ComposeResult:
        yield VerticalScroll(id="fs-scroll")

    def on_mount(self) -> None:
        self.border_title = " Files "
        self.refresh_tree()

    def set_workspace(self, root: str) -> None:
        self._root = str(Path(root).resolve())
        self.refresh_tree()

    def refresh_tree(self) -> None:
        scroll = self.query_one("#fs-scroll", VerticalScroll)
        scroll.remove_children()
        root = Path(self._root)
        name = root.name or str(root)
        lines = [
            f"[bold #e3b341]{_DIR_ICON} {name}/[/]",
            f"[dim #8b949e]{self._root}[/]",
            "",
        ]
        lines.extend(_build_tree(root))
        for line in lines:
            scroll.mount(Static(line, markup=True))
