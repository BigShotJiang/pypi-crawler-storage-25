from __future__ import annotations

from pathlib import Path

from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.widget import Widget
from textual.widgets import Static


class StatusPanel(Widget):
    """Right sidebar — shows workspace, model, tool count, memory, and current agent status."""

    DEFAULT_CSS = """
    StatusPanel {
        height: 1fr;
        width: 32;
    }
    StatusPanel VerticalScroll {
        height: 1fr;
        padding: 0 1;
        background: #0d1117;
    }
    StatusPanel Static {
        height: auto;
    }
    """

    def compose(self) -> ComposeResult:
        yield VerticalScroll(id="st-scroll")

    def on_mount(self) -> None:
        self.border_title = " Status "
        self._model: str = ""
        self._tools: int = 0
        self._workspace: str = ""
        self._status: str = "idle"
        self._steps: int = 0
        self._memory: int = 0
        self._rebuild()

    def set_info(self, model_name: str, tool_count: int, workspace: str) -> None:
        self._model = model_name
        self._tools = tool_count
        self._workspace = workspace
        self._rebuild()

    def set_status(self, status: str, steps: int = 0, memory: int = 0) -> None:
        self._status = status
        self._steps = steps
        if memory >= 0:
            self._memory = memory
        self._rebuild()

    def _rebuild(self) -> None:
        scroll = self.query_one("#st-scroll", VerticalScroll)
        scroll.remove_children()

        ws_path = Path(self._workspace)
        # Show last 2 path segments so user can orient themselves
        try:
            parts = ws_path.parts
            ws_display = "/".join(parts[-2:]) if len(parts) >= 2 else ws_path.name
        except Exception:
            ws_display = self._workspace

        safe_ws = self._workspace.replace("[", "\\[")
        safe_model = self._model.replace("[", "\\[")
        safe_ws_display = ws_display.replace("[", "\\[")

        status_color = "#3fb950" if self._status in ("idle", "done ✓", "✓ ok") else (
            "#f85149" if "fail" in self._status or "✗" in self._status else "#e3b341"
        )

        lines = [
            "[bold #8b949e]Sandbox[/]",
            f"[bold #e3b341]{safe_ws_display}[/]",
            f"[dim #6e7681]{safe_ws[:30]}[/]",
            "",
            "[bold #8b949e]Model[/]",
            f"[#58a6ff]{safe_model}[/]",
            "",
            f"[bold #8b949e]Tools[/]  [dim #c9d1d9]{self._tools}[/]",
            "",
            "[bold #8b949e]Memory[/]",
            f"[dim #c9d1d9]{self._memory} msg in session[/]",
            "",
            "[bold #8b949e]Status[/]",
            f"[bold {status_color}]{self._status}[/]",
        ]
        if self._steps > 0:
            lines.append(f"[dim #8b949e]steps this task: {self._steps}[/]")

        for line in lines:
            scroll.mount(Static(line, markup=True))
