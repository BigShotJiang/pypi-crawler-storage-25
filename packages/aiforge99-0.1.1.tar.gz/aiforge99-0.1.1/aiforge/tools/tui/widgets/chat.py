from __future__ import annotations

from datetime import datetime

from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.widget import Widget
from textual.widgets import Static


def _ts() -> str:
    return datetime.now().strftime("%H:%M:%S")


def _esc(text: str) -> str:
    """Escape Rich markup brackets so content is displayed literally."""
    return text.replace("[", "\\[").replace("]", "\\]")


class ChatPanel(Widget):
    DEFAULT_CSS = """
    ChatPanel {
        height: 1fr;
        width: 1fr;
    }
    ChatPanel VerticalScroll {
        height: 1fr;
        padding: 0 1;
        background: #0d1117;
    }
    ChatPanel Static {
        height: auto;
        margin-bottom: 0;
    }
    """

    def compose(self) -> ComposeResult:
        yield VerticalScroll(id="chat-scroll")

    def on_mount(self) -> None:
        self.border_title = " Chat "
        self._stream_static: Static | None = None
        self._stream_text: str = ""
        self.add_system("AIForge ready — type a task below, or :help for commands.")

    # ── streaming API ──────────────────────────────────────────────────────────

    def start_stream(self) -> None:
        """Mount a live streaming bubble before the first token arrives."""
        self._stream_text = ""
        s = Static("[dim #8b949e]  ≫ …[/]", markup=True)
        self._stream_static = s
        scroll = self.query_one("#chat-scroll", VerticalScroll)
        scroll.mount(s)
        scroll.scroll_end(animate=False)

    def append_stream(self, token: str) -> None:
        """Append a token chunk to the live stream bubble."""
        if self._stream_static is None:
            return
        self._stream_text += token
        display = self._stream_text[-500:] if len(self._stream_text) > 500 else self._stream_text
        self._stream_static.update(
            f"[dim #8b949e]  ≫ [/][dim #c9d1d9]{_esc(display)}[/]"
        )
        self.query_one("#chat-scroll", VerticalScroll).scroll_end(animate=False)

    def finish_stream(self) -> None:
        """Remove the streaming bubble (thought has been parsed)."""
        if self._stream_static is not None:
            try:
                self._stream_static.remove()
            except Exception:
                pass
        self._stream_static = None
        self._stream_text = ""

    # ── message API ───────────────────────────────────────────────────────────

    def add_user(self, text: str) -> None:
        self._push(
            f"[bold #58a6ff]  you  [/][dim #8b949e]{_ts()}[/]\n"
            f"  [#e6edf3]{_esc(text)}[/]"
        )

    def add_message(self, role: str, text: str) -> None:
        self._push(
            f"[bold #3fb950]  agent[/] [dim #8b949e]{_ts()}[/]\n"
            f"  [#e6edf3]{_esc(text)}[/]"
        )

    def add_thought(self, text: str) -> None:
        self._push(
            f"[dim #8b949e]  ✦ {_ts()} thought:[/]\n"
            f"  [italic dim #8b949e]{_esc(text[:300])}[/]"
        )

    def add_tool_call(self, name: str, args: dict) -> None:
        arg_parts = [f"{k}={str(v)[:30]}" for k, v in list(args.items())[:3]]
        arg_str = _esc(", ".join(arg_parts))
        self._push(
            f"  [bold #e3b341]⚙ {_esc(name)}[/][dim #8b949e]({arg_str})[/]"
        )

    def add_tool_result(self, ok: bool, summary: str) -> None:
        if ok:
            self._push(f"  [#3fb950]✓[/] [dim #8b949e]{_esc(summary[:120])}[/]")
        else:
            self._push(f"  [#f85149]✗[/] [dim #8b949e]{_esc(summary[:120])}[/]")

    def add_error(self, text: str) -> None:
        self._push(
            f"[bold #f85149]  ✗ error  {_ts()}[/]\n"
            f"  [#f85149]{_esc(text[:300])}[/]"
        )

    def add_system(self, text: str) -> None:
        self._push(f"[dim #8b949e]  · {_esc(text)}[/]")

    def clear(self) -> None:
        self.finish_stream()
        scroll = self.query_one("#chat-scroll", VerticalScroll)
        scroll.remove_children()
        self.add_system("Chat cleared.")

    # ── internal ──────────────────────────────────────────────────────────────

    def _push(self, markup: str) -> None:
        scroll = self.query_one("#chat-scroll", VerticalScroll)
        scroll.mount(Static(markup, markup=True))
        scroll.scroll_end(animate=False)
