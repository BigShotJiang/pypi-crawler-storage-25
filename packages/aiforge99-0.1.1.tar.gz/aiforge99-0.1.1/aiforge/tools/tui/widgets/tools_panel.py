from pathlib import Path

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import Static
from textual.containers import VerticalScroll


class ToolsPanel(Widget):
    DEFAULT_CSS = """
    ToolsPanel {
        border: solid $accent;
        border-title-color: $accent;
        width: 32;
        height: 1fr;
    }
    ToolsPanel VerticalScroll {
        height: 1fr;
        padding: 0 1;
    }
    ToolsPanel Static {
        height: auto;
    }
    """

    def compose(self) -> ComposeResult:
        yield VerticalScroll(id="tools-scroll")

    def on_mount(self) -> None:
        self.border_title = " Tools & Model "
        self._model_label: str = ""
        self._tool_count: int = 0
        self._workspace: str = str(Path(".").resolve())

    def set_info(self, model_name: str, tool_count: int, workspace: str) -> None:
        self._model_label = model_name
        self._tool_count = tool_count
        self._workspace = workspace
        self._rebuild_header()

    def _rebuild_header(self) -> None:
        scroll = self.query_one("#tools-scroll", VerticalScroll)
        scroll.remove_children()

        safe_model = self._model_label.replace("[", "\\[")
        ws_name = Path(self._workspace).name or self._workspace
        safe_ws = self._workspace.replace("[", "\\[")

        scroll.mount(Static("[bold]Workspace[/bold]", markup=True))
        scroll.mount(Static(f"[green]{ws_name}[/green]", markup=True))
        scroll.mount(Static(f"[dim]{safe_ws}[/dim]", markup=True))
        scroll.mount(Static("", markup=False))
        scroll.mount(Static("[bold]Model[/bold]", markup=True))
        scroll.mount(Static(f"[cyan]{safe_model}[/cyan]", markup=True))
        scroll.mount(Static("", markup=False))
        scroll.mount(Static(f"[bold]Tools ({self._tool_count})[/bold]", markup=True))
        scroll.mount(Static("─" * 28, markup=False))
        scroll.mount(Static("[dim]Activity:[/dim]", markup=True))

    def log_tool_call(self, name: str, args: dict) -> None:
        scroll = self.query_one("#tools-scroll", VerticalScroll)
        safe_name = name.replace("[", "\\[")
        arg_parts = []
        for k, v in list(args.items())[:2]:
            val = str(v)
            if len(val) > 25:
                val = val[:22] + "..."
            arg_parts.append(f"{k}={val}")
        arg_str = ", ".join(arg_parts)
        scroll.mount(Static(f"[yellow]⚙ {safe_name}[/yellow] [dim]({arg_str})[/dim]", markup=True))
        scroll.scroll_end(animate=False)

    def log_tool_result(self, ok: bool, summary: str) -> None:
        scroll = self.query_one("#tools-scroll", VerticalScroll)
        safe_summary = summary.replace("[", "\\[")[:55]
        if ok:
            scroll.mount(Static(f"  [green]✓[/green] [dim]{safe_summary}[/dim]", markup=True))
        else:
            scroll.mount(Static(f"  [red]✗[/red] [dim]{safe_summary}[/dim]", markup=True))
        scroll.scroll_end(animate=False)

    def log_agent_status(self, status: str) -> None:
        scroll = self.query_one("#tools-scroll", VerticalScroll)
        safe = status.replace("[", "\\[")
        scroll.mount(Static(f"[dim]  · {safe}[/dim]", markup=True))
        scroll.scroll_end(animate=False)
