from __future__ import annotations

import threading
from pathlib import Path
from typing import TYPE_CHECKING

from textual import on
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal
from textual.widgets import Footer, Header, Input

from aiforge.tui.widgets.chat import ChatPanel
from aiforge.tui.widgets.filesystem import FileSystemPanel
from aiforge.tui.widgets.status import StatusPanel

if TYPE_CHECKING:
    from aiforge.agent.controller import AgentController


CSS = """
Screen {
    background: #0d1117;
    layout: vertical;
}

Header {
    background: #161b22;
    color: #58a6ff;
    height: 1;
    dock: top;
}

#body {
    layout: horizontal;
    height: 1fr;
}

#fs-panel {
    display: block;
}

#fs-panel.hidden {
    display: none;
}

ChatPanel {
    border: solid #30363d;
    border-title-color: #58a6ff;
    height: 1fr;
    width: 1fr;
    background: #0d1117;
}

StatusPanel {
    border: solid #30363d;
    border-title-color: #3fb950;
    width: 32;
    height: 1fr;
    background: #0d1117;
}

FileSystemPanel {
    border: solid #30363d;
    border-title-color: #e3b341;
    width: 28;
    height: 1fr;
    background: #0d1117;
}

#input-row {
    height: 3;
    layout: horizontal;
    background: #161b22;
    border: solid #30363d;
    border-title-color: #58a6ff;
    padding: 0 1;
}

Input {
    border: none;
    height: 1;
    background: transparent;
    color: #e6edf3;
}

Footer {
    background: #161b22;
    color: #8b949e;
    height: 1;
}
"""


class AIForgeTUI(App):
    TITLE = "AIForge"
    CSS = CSS
    BINDINGS = [
        Binding("ctrl+q", "quit", "Quit", show=True),
        Binding("ctrl+f", "toggle_files", "Files", show=True),
        Binding("ctrl+l", "clear_chat", "Clear", show=True),
        Binding("ctrl+r", "refresh_fs", "Refresh", show=True),
        Binding("ctrl+n", "new_session", "New Session", show=True),
        Binding("escape", "cancel_task", "Cancel", show=False),
    ]

    def __init__(self, controller: "AgentController", model_name: str) -> None:
        super().__init__()
        self._controller = controller
        self._model_name = model_name
        self._busy = False
        self._step_count = 0
        self._cancel_event = threading.Event()
        from aiforge.runtime.workspace import user_workspace_str
        self._workspace = user_workspace_str()
        self._fs_visible = True

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal(id="body"):
            yield FileSystemPanel(workspace_root=self._workspace, id="fs-panel")
            yield ChatPanel(id="chat-panel")
            yield StatusPanel(id="status-panel")
        inp = Input(
            placeholder="Type a task and press Enter…  (or :help for commands)",
            id="task-input",
        )
        inp.border_title = " ▸ Task "
        yield inp
        yield Footer()

    def on_mount(self) -> None:
        ws_name = Path(self._workspace).name or "user"
        self.title = f"AIForge  ✦  {self._model_name}  ✦  {ws_name}"
        tool_count = len(self._controller.registry.all())
        self.query_one(StatusPanel).set_info(self._model_name, tool_count, self._workspace)
        self._subscribe_events()
        chat = self.query_one(ChatPanel)
        chat.add_system(f"Sandbox workspace: {self._workspace}")
        chat.add_system("Memory persists across tasks — use :new to start a fresh session.")
        chat.add_system("Type a task or :help for commands.")
        self.query_one("#task-input", Input).focus()

    def _subscribe_events(self) -> None:
        from aiforge.events.types import (
            AGENT_DONE, AGENT_FAILED, AGENT_STEP, AGENT_STREAM, TOOL_CALL, TOOL_RESULT,
        )
        bus = self._controller.bus

        def _stream(ev):
            token = ev.payload.get("token", "")
            if token:
                self.call_from_thread(self._on_stream_token, token)

        def _step(ev):
            thought = ev.payload.get("thought", "")
            self.call_from_thread(self._on_thought, thought)

        def _tool_call(ev):
            name = ev.payload.get("name", "")
            args = ev.payload.get("args", {})
            self.call_from_thread(self._on_tool_call, name, args)

        def _tool_result(ev):
            ok = bool(ev.payload.get("success"))
            out = ev.payload.get("output") or ev.payload.get("error") or ""
            s = out if isinstance(out, str) else str(out)
            self.call_from_thread(self._on_tool_result, ok, s[:200])

        def _done(ev):
            self.call_from_thread(self._on_done, ev.payload.get("result", ""))

        def _failed(ev):
            self.call_from_thread(self._on_failed, ev.payload.get("reason", "unknown error"))

        bus.subscribe(AGENT_STREAM, _stream)
        bus.subscribe(AGENT_STEP, _step)
        bus.subscribe(TOOL_CALL, _tool_call)
        bus.subscribe(TOOL_RESULT, _tool_result)
        bus.subscribe(AGENT_DONE, _done)
        bus.subscribe(AGENT_FAILED, _failed)

    # ── streaming ──────────────────────────────────────────────────────────────

    def _on_stream_token(self, token: str) -> None:
        chat = self.query_one(ChatPanel)
        if chat._stream_static is None:
            chat.start_stream()
        chat.append_stream(token)

    # ── agent events ──────────────────────────────────────────────────────────

    def _on_thought(self, thought: str) -> None:
        self._step_count += 1
        chat = self.query_one(ChatPanel)
        chat.finish_stream()
        if thought:
            chat.add_thought(thought)
        mem_size = self._controller.memory_size
        self.query_one(StatusPanel).set_status("thinking", self._step_count, mem_size)

    def _on_tool_call(self, name: str, args: dict) -> None:
        chat = self.query_one(ChatPanel)
        chat.add_tool_call(name, args)
        mem_size = self._controller.memory_size
        self.query_one(StatusPanel).set_status(f"▶ {name}", self._step_count, mem_size)

        # Diff preview for file writes / edits
        if name in ("file.write", "file.create"):
            path = args.get("path", "")
            content = args.get("content", "")
            if path and content:
                preview = content[:300] + ("…" if len(content) > 300 else "")
                chat.add_system(f"  📄 Writing {path} ({len(content)} chars):\n{preview}")

        elif name == "file.edit":
            path = args.get("path", "")
            old_s = args.get("old", "")
            new_s = args.get("new", "")
            if path:
                chat.add_system(
                    f"  ✏️  Editing {path}\n"
                    f"  - {old_s[:120]}\n"
                    f"  + {new_s[:120]}"
                )

    def _on_tool_result(self, ok: bool, summary: str) -> None:
        self.query_one(ChatPanel).add_tool_result(ok, summary)
        status = "✓ ok" if ok else "✗ failed"
        self.query_one(StatusPanel).set_status(status, self._step_count)

    def _on_done(self, result: str) -> None:
        self._busy = False
        chat = self.query_one(ChatPanel)
        chat.finish_stream()
        if result:
            chat.add_message("agent", result)
        chat.add_system("✓  Task complete.  Memory saved — next task will remember this.")
        mem_size = self._controller.memory_size
        self.query_one(StatusPanel).set_status("idle", self._step_count, mem_size)
        self.query_one(FileSystemPanel).refresh_tree()
        self._reset_input()

    def _on_failed(self, reason: str) -> None:
        self._busy = False
        chat = self.query_one(ChatPanel)
        chat.finish_stream()
        chat.add_error(reason)
        self.query_one(StatusPanel).set_status("✗ failed", self._step_count)
        self._reset_input()

    def _reset_input(self) -> None:
        inp = self.query_one("#task-input", Input)
        inp.border_title = " ▸ Task "
        inp.focus()

    @on(Input.Submitted, "#task-input")
    def handle_input(self, event: Input.Submitted) -> None:
        task = event.value.strip()
        event.input.clear()
        if not task:
            return
        if task.startswith(":"):
            self._handle_command(task)
            return
        if self._busy:
            self.query_one(ChatPanel).add_system(
                "Agent is busy — press Escape to cancel, or wait."
            )
            return
        self._busy = True
        self._step_count = 0
        self._cancel_event.clear()
        inp = self.query_one("#task-input", Input)
        inp.border_title = " ⟳ Running… "
        self.query_one(ChatPanel).add_user(task)
        self.query_one(StatusPanel).set_status("starting…", 0)
        threading.Thread(target=self._run_agent, args=(task,), daemon=True).start()

    def _run_agent(self, task: str) -> None:
        from aiforge.runtime.errors import AIForgeError
        try:
            self._controller.run(task, cancel=self._cancel_event)
        except AIForgeError as e:
            self.call_from_thread(self._on_failed, str(e))
        except Exception as e:
            self.call_from_thread(self._on_failed, f"{type(e).__name__}: {e}")

    def _handle_command(self, cmd: str) -> None:
        chat = self.query_one(ChatPanel)
        c = cmd.strip()

        if c in (":quit", ":q"):
            self.exit()

        elif c == ":clear":
            self.action_clear_chat()

        elif c in (":refresh", ":r"):
            self.query_one(FileSystemPanel).refresh_tree()
            chat.add_system("File tree refreshed.")

        elif c in (":new", ":new-session"):
            self._controller.reset_session()
            chat.add_system("Session memory cleared. Starting fresh — previous tasks forgotten.")
            self.query_one(StatusPanel).set_status("idle", 0, 0)

        elif c == ":memory":
            mem_size = self._controller.memory_size
            task_count = self._controller._task_count
            chat.add_system(f"Session memory: {mem_size} messages across {task_count} task(s).")
            try:
                ltm = self._controller._long_term
                records = ltm.all()
                if records:
                    chat.add_system(f"Long-term memory: {len(records)} task(s) on disk.")
                    for r in records[-5:]:
                        c_data = r.get("content", {})
                        if isinstance(c_data, dict):
                            mark = "✓" if c_data.get("success") else "✗"
                            task_text = str(c_data.get("task", ""))[:60]
                            ts = r.get("ts", "?")[:16]
                            chat.add_system(f"  {mark} [{ts}] {task_text}")
                else:
                    chat.add_system("Long-term memory: empty (no completed tasks yet).")
            except Exception as ex:
                chat.add_system(f"Long-term memory: (error reading — {ex})")

        elif c == ":history":
            mem = self._controller._session_memory.all()
            if not mem:
                chat.add_system("Session memory is empty.")
            else:
                chat.add_system(f"Session memory ({len(mem)} messages):")
                import json as _json
                for i, msg in enumerate(mem[-20:], 1):
                    role = msg.get("role", "?")
                    content = msg.get("content", "")
                    try:
                        obj = _json.loads(content)
                        if "task" in obj:
                            preview = f"task: {str(obj['task'])[:60]}"
                        elif "action" in obj:
                            preview = f"action: {obj['action']}"
                        elif "observation" in obj:
                            obs = obj["observation"]
                            ok = "✓" if obs.get("success") else "✗"
                            preview = f"observation: {ok} {str(obs.get('output', ''))[:40]}"
                        else:
                            preview = str(obj)[:60]
                    except Exception:
                        preview = str(content)[:60]
                    chat.add_system(f"  [{role}] {preview}")

        elif c == ":model":
            chat.add_system(f"Model: {self._model_name}")

        elif c in (":ws", ":workspace"):
            chat.add_system(f"Sandbox workspace: {self._workspace}")

        elif c.startswith(":workspace set "):
            target = c[len(":workspace set "):].strip()
            if not target:
                chat.add_system("usage: :workspace set <path>")
            else:
                from aiforge.cli.commands import cmd_workspace_set
                rc = cmd_workspace_set(target)
                if rc == 0:
                    chat.add_system(f"Workspace saved: {target}  (restart TUI to apply)")
                else:
                    chat.add_error(f"Failed to set workspace: {target}")

        elif c in (":save", ":save-session"):
            try:
                from aiforge.cli.session import Session
                s = Session()
                s.save_memory(self._controller)
                chat.add_system(f"Session saved (id={s.id}). Use ':load {s.id}' to restore.")
            except Exception as ex:
                chat.add_error(f"Save failed: {ex}")

        elif c.startswith(":load ") or c.startswith(":resume "):
            sid = c.split(" ", 1)[1].strip()
            try:
                from aiforge.cli.session import Session
                s = Session(session_id=sid)
                n = s.restore_memory(self._controller)
                if n:
                    chat.add_system(f"Restored {n} messages from session '{sid}'.")
                else:
                    chat.add_system(f"Session '{sid}' exists but has no saved memory.")
            except Exception as ex:
                chat.add_error(f"Load failed: {ex}")

        elif c == ":sessions":
            from aiforge.cli.session import Session
            meta = Session.list_with_meta()
            if not meta:
                chat.add_system("No sessions yet. Use ':save' to save the current session.")
            else:
                chat.add_system(f"{len(meta)} session(s):")
                for m in meta[-10:]:
                    chat.add_system(
                        f"  • {m['id']}  tasks={m['tasks']}  msgs={m['messages']}  {m['created_at'][:10]}"
                    )

        elif c.startswith(":session "):
            sid = c[len(":session "):].strip()
            if sid:
                self._show_session(sid, chat)
            else:
                chat.add_system("usage: :session <id>   (use :sessions to list)")

        elif c == ":session":
            chat.add_system("usage: :session <id>   (use :sessions to list)")

        elif c == ":tools":
            tools = self._controller.registry.all()
            chat.add_system(f"{len(tools)} tools:")
            for t in tools:
                chat.add_system(f"  • {t.name}: {t.description[:70]}")

        elif c in (":files", ":f"):
            self.action_toggle_files()

        elif c == ":help":
            for line in [
                "─── AIForge Commands ───────────────────────────────────",
                "  :help                     show this help",
                "  :tools                    list all tools with descriptions",
                "  :model                    show active model",
                "  :workspace                show sandbox workspace path",
                "  :workspace set <path>     change workspace (restart to apply)",
                "  :memory                   show session + long-term memory stats",
                "  :history                  show recent session memory messages",
                "  :new                      clear session memory (fresh start)",
                "  :save                     save current session to disk",
                "  :load <id>                restore a saved session",
                "  :resume <id>              alias for :load",
                "  :sessions                 list saved sessions",
                "  :session <id>             inspect a saved session's task history",
                "  :files / :f               toggle file panel",
                "  :refresh / :r             refresh file tree",
                "  :clear                    clear chat display",
                "  :quit / :q                exit AIForge",
                "─── Keybindings ────────────────────────────────────────",
                "  Ctrl+Q  quit   Ctrl+F  toggle files   Ctrl+L  clear",
                "  Ctrl+R  refresh        Ctrl+N  new session",
                "  Escape  cancel running task",
            ]:
                chat.add_system(line)

        else:
            chat.add_system(f"Unknown command: {c}  (type :help for commands)")

    def _show_session(self, session_id: str, chat) -> None:
        import json
        from aiforge.runtime.workspace import resolve_workspace
        d = resolve_workspace() / ".aiforge" / "sessions"
        path = d / f"{session_id}.json"
        if not path.exists():
            ids = sorted(p.stem for p in d.glob("*.json")) if d.exists() else []
            matches = [i for i in ids if i.startswith(session_id)]
            if len(matches) == 1:
                path = d / f"{matches[0]}.json"
                session_id = matches[0]
            elif len(matches) > 1:
                chat.add_error(f"Ambiguous prefix — matches: {', '.join(matches)}")
                return
            else:
                chat.add_error(f"Session not found: {session_id}")
                return
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            chat.add_error(f"Error reading session: {e}")
            return
        tasks = data.get("tasks", [])
        chat.add_system(
            f"Session {data.get('id', session_id)}  "
            f"created: {data.get('created_at', '?')}  "
            f"tasks: {len(tasks)}"
        )
        for i, t in enumerate(tasks, 1):
            mark = "✓" if t.get("success") else "✗"
            steps = t.get("steps", [])
            chat.add_system(f"  {i}. {mark} {t.get('task', '')[:80]}  ({len(steps)} steps)")
            if t.get("final"):
                chat.add_system(f"     → {t['final'][:120]}")
            if t.get("reason") and not t.get("success"):
                chat.add_system(f"     reason: {t['reason'][:100]}")

    def action_toggle_files(self) -> None:
        fs = self.query_one("#fs-panel", FileSystemPanel)
        if self._fs_visible:
            fs.add_class("hidden")
            self._fs_visible = False
        else:
            fs.remove_class("hidden")
            self._fs_visible = True

    def action_refresh_fs(self) -> None:
        self.query_one(FileSystemPanel).refresh_tree()

    def action_clear_chat(self) -> None:
        self.query_one(ChatPanel).clear()

    def action_new_session(self) -> None:
        self._controller.reset_session()
        chat = self.query_one(ChatPanel)
        chat.add_system("Session memory cleared (Ctrl+N). Starting fresh.")
        self.query_one(StatusPanel).set_status("idle", 0, 0)

    def action_cancel_task(self) -> None:
        if self._busy:
            self._cancel_event.set()
            self.query_one(ChatPanel).add_system(
                "Cancelling… (agent stops after the current step)."
            )
        else:
            self.query_one(ChatPanel).add_system("No task running.")
