from collections import defaultdict
from typing import Callable

from aiforge.tools.result import ToolResult


class ToolHooks:
    def __init__(self):
        self._before: dict[str, list[Callable]] = defaultdict(list)
        self._after: dict[str, list[Callable]] = defaultdict(list)

    def before(self, tool_name: str, fn: Callable) -> None:
        self._before[tool_name].append(fn)

    def after(self, tool_name: str, fn: Callable) -> None:
        self._after[tool_name].append(fn)

    def run_before(self, tool_name: str, kwargs: dict) -> None:
        for fn in self._before.get(tool_name, []):
            fn(kwargs)

    def run_after(self, tool_name: str, result: ToolResult) -> None:
        for fn in self._after.get(tool_name, []):
            fn(result)
