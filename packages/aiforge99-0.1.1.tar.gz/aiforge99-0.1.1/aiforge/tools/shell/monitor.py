from aiforge.runtime.errors import NotImplementedFeatureError


class ShellMonitor:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("tools.shell.monitor (long-running process monitoring)")
