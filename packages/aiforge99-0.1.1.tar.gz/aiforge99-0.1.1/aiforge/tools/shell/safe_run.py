import shlex
import subprocess

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.runtime.errors import ToolPermissionError

ALLOWED_COMMANDS = {
    "ls", "pwd", "cat", "head", "tail", "wc", "echo", "stat", "file",
    "find", "grep", "rg", "git", "python", "python3", "pip", "pytest",
    "node", "npm", "npx", "which", "env", "uname", "date", "whoami",
}


class ShellSafeRunTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "shell.safe_run"

    @property
    def description(self) -> str:
        return (
            f"Run a read-only or safe shell command in workspace {self.permissions.workspace_root}. "
            f"Allowed binaries: {', '.join(sorted(ALLOWED_COMMANDS))}. "
            "Use shell.run for arbitrary commands."
        )

    def run(self, command: str, cwd: str | None = None, timeout: int = 60) -> ToolResult:
        self.permissions.check_shell(command)
        try:
            argv = shlex.split(command)
        except ValueError as e:
            return ToolResult.fail(f"Invalid command: {e}")
        if not argv:
            return ToolResult.fail("Empty command")
        binary = argv[0].rsplit("/", 1)[-1]
        if binary not in ALLOWED_COMMANDS:
            return ToolResult.fail(
                f"Command '{binary}' is not in the safe allowlist. Use shell.run for unrestricted commands."
            )
        run_cwd = cwd or self.permissions.workspace_root
        try:
            proc = subprocess.run(
                argv,
                capture_output=True,
                text=True,
                cwd=run_cwd,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            return ToolResult.fail(f"Timeout after {timeout}s", command=command)
        return ToolResult(
            success=(proc.returncode == 0),
            output=proc.stdout,
            error=proc.stderr if proc.returncode != 0 else None,
            metadata={"command": command, "returncode": proc.returncode, "cwd": run_cwd},
        )
