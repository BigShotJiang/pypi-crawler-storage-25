from aiforge.runtime.errors import NotImplementedFeatureError


class ShellStream:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("tools.shell.stream (streaming command output)")
