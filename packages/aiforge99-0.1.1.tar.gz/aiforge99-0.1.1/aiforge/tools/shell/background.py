"""
Background shell process management for AIForge.

Allows the agent to start long-running processes (dev servers, file watchers,
build daemons, etc.) and query/stop them by handle ID.

Process state is stored in a module-level registry so it persists across
tool calls within the same agent session.
"""
from __future__ import annotations

import os
import signal
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import ClassVar

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.tools.sandbox import _filtered_env


@dataclass
class _BgProcess:
    handle: str
    command: str
    proc: subprocess.Popen
    cwd: str
    started_at: float
    _output_lines: list[str] = field(default_factory=list)
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def is_running(self) -> bool:
        return self.proc.poll() is None

    def tail(self, n: int = 20) -> str:
        with self._lock:
            return "\n".join(self._output_lines[-n:])

    def _collect(self) -> None:
        """Background thread that drains stdout+stderr into _output_lines."""
        try:
            for line in self.proc.stdout:
                with self._lock:
                    self._output_lines.append(line.rstrip())
                    if len(self._output_lines) > 1000:
                        self._output_lines = self._output_lines[-500:]
        except Exception:
            pass

    def start_collector(self) -> None:
        t = threading.Thread(target=self._collect, daemon=True)
        t.start()


# Module-level registry: handle -> _BgProcess
_registry: dict[str, _BgProcess] = {}
_registry_lock = threading.Lock()


def _next_handle() -> str:
    with _registry_lock:
        n = len(_registry) + 1
        return f"bg{n}"


class ShellBackgroundTool(BaseTool):
    """Start a command in the background and return a handle to monitor/stop it."""

    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "shell.bg"

    @property
    def description(self) -> str:
        return (
            "Start a shell command in the background (non-blocking). "
            "Returns a handle to check status or stop it later. "
            "Use for: dev servers (npm run dev), build watchers, long-running scripts. "
            "Args: command (string), cwd (optional path in workspace), timeout_start (seconds to wait for startup, default 2)."
        )

    def run(
        self,
        command: str,
        cwd: str | None = None,
        timeout_start: int = 2,
    ) -> ToolResult:
        self.permissions.check_shell(command)
        workspace = self.permissions.workspace_root

        run_dir = Path(workspace)
        if cwd:
            run_dir = (run_dir / cwd).resolve()
            if not str(run_dir).startswith(workspace):
                return ToolResult.fail(f"cwd '{cwd}' escapes workspace")

        env = _filtered_env()

        try:
            proc = subprocess.Popen(
                command,
                shell=True,
                executable="/bin/sh",
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                cwd=str(run_dir),
                env=env,
                start_new_session=True,
            )
        except Exception as e:
            return ToolResult.fail(f"Failed to start background process: {e}")

        handle = _next_handle()
        bg = _BgProcess(
            handle=handle,
            command=command,
            proc=proc,
            cwd=str(run_dir),
            started_at=time.time(),
        )
        bg.start_collector()

        with _registry_lock:
            _registry[handle] = bg

        # Wait briefly to detect immediate crash
        time.sleep(min(timeout_start, 3))
        if not bg.is_running():
            tail = bg.tail(10)
            with _registry_lock:
                del _registry[handle]
            return ToolResult.fail(
                f"Process exited immediately (exit {proc.returncode}). "
                f"Output:\n{tail or '(none)'}"
            )

        return ToolResult.ok(
            f"Started background process [{handle}]: {command}",
            handle=handle,
            pid=proc.pid,
            cwd=str(run_dir),
        )


class ShellBgStatusTool(BaseTool):
    """Check the status of a background process and read its recent output."""

    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "shell.bg.status"

    @property
    def description(self) -> str:
        return (
            "Check the status of a background process. "
            "Args: handle (from shell.bg, e.g. 'bg1'), tail (number of output lines to return, default 20)."
        )

    def run(self, handle: str, tail: int = 20) -> ToolResult:
        with _registry_lock:
            bg = _registry.get(handle)
        if not bg:
            handles = list(_registry.keys())
            return ToolResult.fail(
                f"Unknown handle '{handle}'. Active handles: {handles or 'none'}"
            )
        status = "running" if bg.is_running() else f"stopped (exit {bg.proc.returncode})"
        elapsed = int(time.time() - bg.started_at)
        output = bg.tail(tail)
        return ToolResult.ok(
            f"[{handle}] {status} — {elapsed}s elapsed\nCommand: {bg.command}\n\n{output or '(no output yet)'}",
            handle=handle,
            status=status,
            elapsed_s=elapsed,
            pid=bg.proc.pid,
        )


class ShellBgStopTool(BaseTool):
    """Stop a background process by handle."""

    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "shell.bg.stop"

    @property
    def description(self) -> str:
        return "Stop a background process. Args: handle (from shell.bg, e.g. 'bg1')."

    def run(self, handle: str) -> ToolResult:
        with _registry_lock:
            bg = _registry.get(handle)
        if not bg:
            return ToolResult.fail(f"Unknown handle '{handle}'")
        if not bg.is_running():
            with _registry_lock:
                del _registry[handle]
            return ToolResult.ok(f"Process [{handle}] was already stopped")
        try:
            os.killpg(os.getpgid(bg.proc.pid), signal.SIGTERM)
            bg.proc.wait(timeout=5)
        except Exception:
            try:
                os.killpg(os.getpgid(bg.proc.pid), signal.SIGKILL)
            except Exception:
                pass
        with _registry_lock:
            del _registry[handle]
        return ToolResult.ok(f"Stopped background process [{handle}]: {bg.command}")
