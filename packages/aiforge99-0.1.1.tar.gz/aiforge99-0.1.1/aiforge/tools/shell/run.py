from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.tools.sandbox import Sandbox


class ShellRunTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions
        self._sandbox = Sandbox(sandbox_root=permissions.workspace_root)

    @property
    def name(self) -> str:
        return "shell.run"

    @property
    def description(self) -> str:
        return (
            f"Run a shell command inside the sandbox workspace {self.permissions.workspace_root}. "
            "Captures stdout and stderr separately. Use for installing packages, running scripts, "
            "compiling code, or any OS command. Default cwd is the sandbox root. "
            "Commands are isolated — they cannot access files outside the sandbox."
        )

    def run(self, command: str, cwd: str | None = None, timeout: int = 60) -> ToolResult:
        self.permissions.check_shell(command)
        result = self._sandbox.run(command, cwd=cwd, timeout=timeout)
        if result.timed_out:
            return ToolResult.fail(
                f"Command timed out after {timeout}s: {command}",
                command=command,
                cwd=result.cwd,
            )
        output = result.stdout.rstrip() or ""
        error_text = result.stderr.rstrip() or None
        return ToolResult(
            success=result.success,
            output=output if output else (error_text or "(no output)"),
            error=error_text if not result.success else None,
            metadata={
                "command": command,
                "returncode": result.returncode,
                "cwd": result.cwd,
                "stderr": result.stderr,
                "stdout": result.stdout,
            },
        )
