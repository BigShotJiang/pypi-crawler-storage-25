from aiforge.tools.base import BaseTool
from aiforge.tools.registry import ToolRegistry
from aiforge.tools.dispatcher import ToolDispatcher
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.tools.schema import ToolSchema, ToolParameter

__all__ = [
    "BaseTool",
    "ToolRegistry",
    "ToolDispatcher",
    "ToolResult",
    "Permissions",
    "ToolSchema",
    "ToolParameter",
]


def build_default_registry(permissions: Permissions | None = None) -> ToolRegistry:
    """
    Build the default tool registry with all built-in tools.

    All file and shell tools are scoped to the agent's isolated user workspace
    (<workspace_root>/aiforge/user/) so the agent cannot touch sensitive project
    files in the workspace root.
    """
    if permissions is None:
        from aiforge.runtime.workspace import user_workspace_str
        permissions = Permissions(workspace_root=user_workspace_str())

    registry = ToolRegistry()

    # File tools
    from aiforge.tools.file.read import FileReadTool
    from aiforge.tools.file.write import FileWriteTool
    from aiforge.tools.file.create import FileCreateTool
    from aiforge.tools.file.delete import FileDeleteTool
    from aiforge.tools.file.edit import FileEditTool
    from aiforge.tools.file.search import FileSearchTool
    from aiforge.tools.file.append import FileAppendTool

    # Shell tools
    from aiforge.tools.shell.run import ShellRunTool
    from aiforge.tools.shell.safe_run import ShellSafeRunTool
    from aiforge.tools.shell.background import (
        ShellBackgroundTool,
        ShellBgStatusTool,
        ShellBgStopTool,
    )

    # Project tools
    from aiforge.tools.project.workspace import ProjectWorkspaceTool
    from aiforge.tools.project.analyze import ProjectAnalyzeTool
    from aiforge.tools.project.scaffold import ProjectScaffoldTool
    from aiforge.tools.project.test_runner import TestRunnerTool

    # Git tools
    from aiforge.tools.git.commit import GitCommitTool
    from aiforge.tools.git.diff import GitDiffTool
    from aiforge.tools.git.rollback import GitRollbackTool
    from aiforge.tools.git.branch import (
        GitBranchCreateTool,
        GitBranchListTool,
        GitBranchSwitchTool,
        GitPushTool,
    )

    # Network tools
    from aiforge.tools.network.fetch import NetworkFetchTool
    from aiforge.tools.network.search import NetworkSearchTool

    # Memory tools
    from aiforge.tools.memory.recall import MemoryRecallTool

    for tool in [
        # File I/O
        FileReadTool(permissions),
        FileWriteTool(permissions),
        FileCreateTool(permissions),
        FileDeleteTool(permissions),
        FileEditTool(permissions),
        FileSearchTool(permissions),
        FileAppendTool(permissions),

        # Shell — blocking and background
        ShellRunTool(permissions),
        ShellSafeRunTool(permissions),
        ShellBackgroundTool(permissions),
        ShellBgStatusTool(permissions),
        ShellBgStopTool(permissions),

        # Project analysis + testing
        ProjectWorkspaceTool(permissions),
        ProjectAnalyzeTool(permissions),
        ProjectScaffoldTool(permissions),
        TestRunnerTool(permissions),

        # Git — commit, diff, rollback, branches, push
        GitCommitTool(permissions),
        GitDiffTool(permissions),
        GitRollbackTool(permissions),
        GitBranchCreateTool(permissions),
        GitBranchListTool(permissions),
        GitBranchSwitchTool(permissions),
        GitPushTool(permissions),

        # Network
        NetworkFetchTool(permissions),
        NetworkSearchTool(permissions),

        # Memory
        MemoryRecallTool(),
    ]:
        registry.register(tool)

    return registry
