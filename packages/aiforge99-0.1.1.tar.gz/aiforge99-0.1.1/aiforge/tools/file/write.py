from pathlib import Path

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.runtime.guardrails import assert_path_within


class FileWriteTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "file.write"

    @property
    def description(self) -> str:
        return (
            f"Overwrite a file at path (relative to workspace root {self.permissions.workspace_root}) "
            "with new content. Creates parent directories automatically."
        )

    def run(self, path: str, content: str, encoding: str = "utf-8") -> ToolResult:
        self.permissions.check_write()
        p = assert_path_within(path, self.permissions.workspace_root)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding=encoding)
        return ToolResult.ok(f"Wrote {len(content)} chars to {p}", path=str(p))
