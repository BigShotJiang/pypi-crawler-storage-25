from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.runtime.guardrails import assert_path_within


class FileAppendTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "file.append"

    @property
    def description(self) -> str:
        return (
            f"Append text to an existing file at path (relative to workspace root "
            f"{self.permissions.workspace_root}). Does NOT overwrite — content is added at the end. "
            "Creates the file if it does not exist. Useful for adding lines to logs, configs, or code."
        )

    def run(self, path: str, content: str, newline: bool = True) -> ToolResult:
        self.permissions.check_write()
        p = assert_path_within(path, self.permissions.workspace_root)
        p.parent.mkdir(parents=True, exist_ok=True)
        prefix = "\n" if newline and p.exists() and p.stat().st_size > 0 else ""
        with p.open("a", encoding="utf-8") as f:
            f.write(prefix + content)
        size = p.stat().st_size
        return ToolResult.ok(
            f"Appended {len(content)} chars to {p} (total size: {size}B)",
            path=str(p),
            appended_bytes=len(content),
            total_size=size,
        )
