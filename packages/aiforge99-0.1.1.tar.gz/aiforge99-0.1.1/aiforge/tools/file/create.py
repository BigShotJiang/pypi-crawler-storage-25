from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.runtime.guardrails import assert_path_within


class FileCreateTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "file.create"

    @property
    def description(self) -> str:
        return (
            f"Create a new file at path (relative to workspace root {self.permissions.workspace_root}). "
            "Fails if the file already exists. Use file.write to overwrite."
        )

    def run(self, path: str, content: str = "", encoding: str = "utf-8") -> ToolResult:
        self.permissions.check_write()
        p = assert_path_within(path, self.permissions.workspace_root)
        if p.exists():
            return ToolResult.fail(f"File already exists: {p}. Use file.write to overwrite.")
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding=encoding)
        return ToolResult.ok(f"Created {p}", path=str(p))
