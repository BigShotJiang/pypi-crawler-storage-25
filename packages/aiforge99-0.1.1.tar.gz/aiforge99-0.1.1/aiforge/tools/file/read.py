from pathlib import Path

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.runtime.guardrails import assert_path_within


class FileReadTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "file.read"

    @property
    def description(self) -> str:
        return (
            f"Read the contents of a file at path "
            f"(relative to workspace root {self.permissions.workspace_root})."
        )

    def run(self, path: str, encoding: str = "utf-8") -> ToolResult:
        p = assert_path_within(path, self.permissions.workspace_root)
        if not p.exists():
            return ToolResult.fail(f"File not found: {p}")
        if not p.is_file():
            return ToolResult.fail(f"Not a file: {p}")
        content = p.read_text(encoding=encoding)
        return ToolResult.ok(content, path=str(p), bytes=p.stat().st_size)
