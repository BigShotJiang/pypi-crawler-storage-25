import difflib
from pathlib import Path

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.runtime.guardrails import assert_path_within


class FileDiffTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "file.diff"

    @property
    def description(self) -> str:
        return "Show a unified diff between two files."

    def run(self, a: str, b: str) -> ToolResult:
        pa = assert_path_within(a, self.permissions.workspace_root)
        pb = assert_path_within(b, self.permissions.workspace_root)
        if not pa.exists() or not pb.exists():
            return ToolResult.fail("One or both files do not exist")
        ta = pa.read_text(encoding="utf-8").splitlines(keepends=True)
        tb = pb.read_text(encoding="utf-8").splitlines(keepends=True)
        diff = "".join(difflib.unified_diff(ta, tb, fromfile=str(pa), tofile=str(pb)))
        return ToolResult.ok(diff)
