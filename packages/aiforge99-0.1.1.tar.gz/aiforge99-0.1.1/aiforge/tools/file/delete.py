from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.runtime.guardrails import assert_path_within


class FileDeleteTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "file.delete"

    @property
    def description(self) -> str:
        return (
            f"Delete a file at path "
            f"(relative to workspace root {self.permissions.workspace_root}). "
            "Refuses to delete directories."
        )

    def run(self, path: str) -> ToolResult:
        self.permissions.check_delete()
        p = assert_path_within(path, self.permissions.workspace_root)
        if not p.exists():
            return ToolResult.fail(f"File not found: {p}")
        if p.is_dir():
            return ToolResult.fail(f"Refusing to delete directory: {p}. Delete files individually.")
        p.unlink()
        return ToolResult.ok(f"Deleted {p}", path=str(p))
