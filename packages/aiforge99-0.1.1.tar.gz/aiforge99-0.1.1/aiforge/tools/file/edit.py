from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.runtime.guardrails import assert_path_within


class FileEditTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "file.edit"

    @property
    def description(self) -> str:
        return (
            f"Edit a file at path (relative to workspace root {self.permissions.workspace_root}) "
            "by replacing exact occurrences of 'old' string with 'new'. "
            "Fails if 'old' is not found in the file."
        )

    def run(self, path: str, old: str, new: str, count: int = -1) -> ToolResult:
        self.permissions.check_write()
        p = assert_path_within(path, self.permissions.workspace_root)
        if not p.exists():
            return ToolResult.fail(f"File not found: {p}")
        text = p.read_text(encoding="utf-8")
        if old not in text:
            return ToolResult.fail(f"String not found in {p}. Cannot edit.")
        replaced = text.replace(old, new) if count < 0 else text.replace(old, new, count)
        p.write_text(replaced, encoding="utf-8")
        n = text.count(old) if count < 0 else min(count, text.count(old))
        return ToolResult.ok(f"Replaced {n} occurrence(s) in {p}", path=str(p), replacements=n)
