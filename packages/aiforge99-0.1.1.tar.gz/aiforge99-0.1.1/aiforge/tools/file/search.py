import re
from pathlib import Path

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions
from aiforge.runtime.guardrails import assert_path_within


_SKIP_DIRS = {
    ".git", "__pycache__", "node_modules", ".venv", "venv", "env",
    ".pytest_cache", ".mypy_cache", ".ruff_cache", "dist", "build",
    ".next", ".turbo", ".cache", ".pythonlibs", ".aiforge",
    "egg-info",
}
_BINARY_EXTS = {
    ".pyc", ".pyo", ".so", ".dll", ".dylib", ".exe", ".bin",
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".svg",
    ".pdf", ".zip", ".tar", ".gz", ".tgz", ".bz2", ".xz", ".7z",
    ".mp3", ".mp4", ".wav", ".mov", ".avi", ".webm",
    ".woff", ".woff2", ".ttf", ".otf", ".eot",
    ".db", ".sqlite", ".sqlite3", ".lock",
}


def _is_binary_sample(p: Path) -> bool:
    try:
        with p.open("rb") as f:
            chunk = f.read(2048)
    except OSError:
        return True
    if b"\x00" in chunk:
        return True
    return False


def _skipped(p: Path) -> bool:
    if p.suffix.lower() in _BINARY_EXTS:
        return True
    for part in p.parts:
        if part in _SKIP_DIRS or part.endswith(".egg-info"):
            return True
    return False


class FileSearchTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "file.search"

    @property
    def description(self) -> str:
        return "Search text files under a path for a regex pattern (skips binaries, .git, caches, build dirs)."

    def run(self, pattern: str, path: str = ".", glob: str = "**/*", max_matches: int = 200) -> ToolResult:
        root = assert_path_within(path, self.permissions.workspace_root)
        if not root.exists():
            return ToolResult.fail(f"Path not found: {root}")
        try:
            rx = re.compile(pattern)
        except re.error as e:
            return ToolResult.fail(f"Invalid regex: {e}")
        matches = []
        scanned = 0
        for p in root.glob(glob):
            if not p.is_file() or _skipped(p) or _is_binary_sample(p):
                continue
            try:
                text = p.read_text(encoding="utf-8", errors="strict")
            except (UnicodeDecodeError, OSError):
                continue
            scanned += 1
            for i, line in enumerate(text.splitlines(), 1):
                if rx.search(line):
                    matches.append({"path": str(p), "line": i, "text": line[:500]})
                    if len(matches) >= max_matches:
                        return ToolResult.ok(
                            matches, count=len(matches), truncated=True, scanned=scanned
                        )
        return ToolResult.ok(matches, count=len(matches), truncated=False, scanned=scanned)
