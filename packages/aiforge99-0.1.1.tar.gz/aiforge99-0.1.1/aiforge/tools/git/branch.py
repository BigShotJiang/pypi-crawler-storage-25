"""
Git branch management tools for AIForge.

Provides:
  - git.branch.create  — create and switch to a new branch per task
  - git.branch.list    — list branches and show current
  - git.branch.switch  — switch to an existing branch
  - git.push           — push current branch to origin
"""
from __future__ import annotations

import subprocess
from pathlib import Path

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions


def _git(cmd: str, cwd: str) -> tuple[int, str, str]:
    """Run a git command, return (returncode, stdout, stderr)."""
    result = subprocess.run(
        f"git {cmd}",
        shell=True,
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    return result.returncode, result.stdout.strip(), result.stderr.strip()


class GitBranchCreateTool(BaseTool):
    """Create a new git branch (and switch to it) for the current task."""

    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "git.branch.create"

    @property
    def description(self) -> str:
        return (
            "Create a new git branch and switch to it. "
            "Use at the start of any task that touches multiple files. "
            "Args: name (string, e.g. 'feat/add-auth'). "
            "Best practice: one branch per task."
        )

    def run(self, name: str) -> ToolResult:
        self.permissions.check_shell("")
        cwd = self.permissions.workspace_root
        # Sanitize branch name
        safe_name = name.replace(" ", "-").replace("/", "-")[:60].strip("-")
        if not safe_name:
            return ToolResult.fail("Branch name cannot be empty")
        rc, out, err = _git(f"checkout -b {safe_name}", cwd)
        if rc != 0:
            # Branch might already exist — try switching
            rc2, out2, err2 = _git(f"checkout {safe_name}", cwd)
            if rc2 != 0:
                return ToolResult.fail(f"Failed to create branch '{safe_name}': {err or err2}")
            return ToolResult.ok(f"Switched to existing branch '{safe_name}'", branch=safe_name)
        return ToolResult.ok(f"Created and switched to branch '{safe_name}'", branch=safe_name)


class GitBranchListTool(BaseTool):
    """List all git branches and show the current one."""

    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "git.branch.list"

    @property
    def description(self) -> str:
        return "List all git branches. The current branch is marked with '*'. No args required."

    def run(self) -> ToolResult:
        cwd = self.permissions.workspace_root
        rc, out, err = _git("branch -a", cwd)
        if rc != 0:
            return ToolResult.fail(f"git branch failed: {err}")
        return ToolResult.ok(out or "(no branches)", branches=out)


class GitBranchSwitchTool(BaseTool):
    """Switch to an existing branch."""

    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "git.branch.switch"

    @property
    def description(self) -> str:
        return "Switch to an existing git branch. Args: name (string)."

    def run(self, name: str) -> ToolResult:
        self.permissions.check_shell("")
        cwd = self.permissions.workspace_root
        rc, out, err = _git(f"checkout {name}", cwd)
        if rc != 0:
            return ToolResult.fail(f"Cannot switch to '{name}': {err}")
        return ToolResult.ok(f"Switched to branch '{name}'", branch=name)


class GitPushTool(BaseTool):
    """Push the current branch to the remote origin."""

    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "git.push"

    @property
    def description(self) -> str:
        return (
            "Push the current branch to origin. "
            "Args: remote (optional, default 'origin'), set_upstream (optional bool, default true)."
        )

    def run(
        self,
        remote: str = "origin",
        set_upstream: bool = True,
    ) -> ToolResult:
        self.permissions.check_shell("")
        cwd = self.permissions.workspace_root

        # Get current branch name
        rc, branch, _ = _git("rev-parse --abbrev-ref HEAD", cwd)
        if rc != 0 or not branch:
            return ToolResult.fail("Could not determine current branch")

        flag = f"-u {remote}" if set_upstream else remote
        rc2, out, err = _git(f"push {flag} {branch}", cwd)
        if rc2 != 0:
            return ToolResult.fail(f"git push failed: {err}")
        return ToolResult.ok(
            f"Pushed '{branch}' to {remote}", branch=branch, remote=remote
        )
