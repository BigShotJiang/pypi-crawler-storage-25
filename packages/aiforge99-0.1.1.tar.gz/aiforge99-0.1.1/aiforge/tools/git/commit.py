import subprocess

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions


class GitCommitTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "git.commit"

    @property
    def description(self) -> str:
        return "Stage all changes and create a git commit."

    def run(self, message: str, cwd: str | None = None) -> ToolResult:
        cwd = cwd or self.permissions.workspace_root
        add = subprocess.run(["git", "add", "-A"], cwd=cwd, capture_output=True, text=True)
        if add.returncode != 0:
            return ToolResult.fail(add.stderr.strip() or "git add failed")
        commit = subprocess.run(
            ["git", "commit", "-m", message], cwd=cwd, capture_output=True, text=True
        )
        if commit.returncode != 0:
            return ToolResult.fail(commit.stderr.strip() or commit.stdout.strip() or "git commit failed")
        return ToolResult.ok(commit.stdout.strip())
