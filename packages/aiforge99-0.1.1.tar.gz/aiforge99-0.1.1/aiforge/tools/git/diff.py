import subprocess

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions


class GitDiffTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "git.diff"

    @property
    def description(self) -> str:
        return "Show git diff for the workspace (optionally for a specific path)."

    def run(self, path: str | None = None, staged: bool = False, cwd: str | None = None) -> ToolResult:
        cwd = cwd or self.permissions.workspace_root
        argv = ["git", "diff"]
        if staged:
            argv.append("--cached")
        if path:
            argv += ["--", path]
        proc = subprocess.run(argv, cwd=cwd, capture_output=True, text=True)
        if proc.returncode != 0:
            return ToolResult.fail(proc.stderr.strip() or "git diff failed")
        return ToolResult.ok(proc.stdout)
