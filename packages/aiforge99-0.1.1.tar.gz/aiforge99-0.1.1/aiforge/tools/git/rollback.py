import subprocess

from aiforge.tools.base import BaseTool
from aiforge.tools.result import ToolResult
from aiforge.tools.permissions import Permissions


class GitRollbackTool(BaseTool):
    def __init__(self, permissions: Permissions):
        self.permissions = permissions

    @property
    def name(self) -> str:
        return "git.rollback"

    @property
    def description(self) -> str:
        return "Discard uncommitted changes (git checkout -- <path>) or reset to a commit."

    def run(self, path: str | None = None, commit: str | None = None, cwd: str | None = None) -> ToolResult:
        self.permissions.check_delete()
        cwd = cwd or self.permissions.workspace_root
        if commit:
            argv = ["git", "reset", "--hard", commit]
        elif path:
            argv = ["git", "checkout", "--", path]
        else:
            return ToolResult.fail("Provide either 'path' or 'commit'")
        proc = subprocess.run(argv, cwd=cwd, capture_output=True, text=True)
        if proc.returncode != 0:
            return ToolResult.fail(proc.stderr.strip() or "git rollback failed")
        return ToolResult.ok(proc.stdout.strip() or "rolled back")
