"""
OpenAI-compatible model client.

Supports both:
  1. Native tool/function calling (preferred when tools are provided)
  2. JSON-prompt mode (fallback, works with all OpenAI-compatible APIs)
"""
from __future__ import annotations

import json
import os
from typing import Any, Iterator

from aiforge.models.base import BaseModel, ChatRequest
from aiforge.runtime.errors import ModelError, ModelNotConfiguredError

try:
    from openai import OpenAI, OpenAIError
    _openai_available = True
except ImportError:
    _openai_available = False


class OpenAIModel(BaseModel):
    def __init__(
        self,
        model: str = "gpt-4o-mini",
        api_key: str | None = None,
        base_url: str | None = None,
    ):
        if not _openai_available:
            raise ModelError(
                "openai package not installed. Run: pip install openai"
            )
        key = api_key or os.environ.get("OPENAI_API_KEY")
        if not key:
            raise ModelNotConfiguredError("OPENAI_API_KEY is not set")
        self.client = OpenAI(api_key=key, base_url=base_url)
        self.model = model
        self.name = f"openai:{model}"

    # ── Standard text completion ────────────────────────────────────────────────

    def chat(self, request: ChatRequest) -> str:
        try:
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": m.role, "content": m.content} for m in request.messages],
                temperature=request.temperature,
                max_tokens=request.max_tokens,
                stop=request.stop,
            )
        except OpenAIError as e:
            raise ModelError(f"OpenAI API error: {_short_err(e)}") from e
        return resp.choices[0].message.content or ""

    def stream(self, request: ChatRequest) -> Iterator[str]:
        try:
            stream = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": m.role, "content": m.content} for m in request.messages],
                temperature=request.temperature,
                max_tokens=request.max_tokens,
                stop=request.stop,
                stream=True,
            )
        except OpenAIError as e:
            raise ModelError(f"OpenAI API error: {_short_err(e)}") from e
        for chunk in stream:
            delta = chunk.choices[0].delta.content
            if delta:
                yield delta

    # ── Native function/tool calling ───────────────────────────────────────────

    def chat_with_tools(
        self,
        request: ChatRequest,
        tools: list[dict[str, Any]],
    ) -> dict[str, Any] | None:
        """
        Use OpenAI native function calling.

        Returns a dict like:
          {"tool": "tool_name", "args": {...}}
        or None if the model returned a plain text response (fallback to JSON mode).
        """
        try:
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": m.role, "content": m.content} for m in request.messages],
                tools=tools,
                tool_choice="auto",
                temperature=request.temperature,
                max_tokens=request.max_tokens,
            )
        except OpenAIError as e:
            raise ModelError(f"OpenAI tool-call API error: {_short_err(e)}") from e

        choice = resp.choices[0]
        msg = choice.message

        # Native tool call returned
        if msg.tool_calls:
            tc = msg.tool_calls[0]
            try:
                args = json.loads(tc.function.arguments) if tc.function.arguments else {}
            except json.JSONDecodeError:
                args = {}
            return {"tool": tc.function.name, "args": args}

        # Model returned plain text — caller should fall back to JSON parsing
        return None

    def supports_tool_calling(self) -> bool:
        """True for OpenAI and OpenRouter models that support the tools API."""
        return True


def _short_err(e: Exception, limit: int = 300) -> str:
    s = str(e)
    low = s.lstrip()[:200].lower()
    if low.startswith("<!doctype") or low.startswith("<html") or "<head" in low[:50]:
        return (
            "provider returned HTML (likely 404 / wrong endpoint). "
            "Check that the base_url points to an OpenAI-compatible API ending with /v1."
        )
    return s if len(s) <= limit else s[:limit] + "…"
