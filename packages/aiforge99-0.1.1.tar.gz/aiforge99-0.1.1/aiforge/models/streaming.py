from typing import Iterable


class StreamCollector:
    def __init__(self):
        self._chunks: list[str] = []

    def feed(self, chunk: str) -> None:
        self._chunks.append(chunk)

    def text(self) -> str:
        return "".join(self._chunks)


def collect(stream: Iterable[str]) -> str:
    return "".join(stream)
