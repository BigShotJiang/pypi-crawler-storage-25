from aiforge.runtime.errors import NotImplementedFeatureError


class LlamaCppModel:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("models.llama_cpp (llama.cpp local inference)")
