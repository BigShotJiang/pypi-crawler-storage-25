import os
from typing import Iterator

import httpx

from aiforge.models.base import BaseModel, ChatRequest
from aiforge.runtime.errors import ModelError


class OllamaModel(BaseModel):
    def __init__(self, model: str = "llama3", host: str | None = None, timeout: int = 120):
        self.model = model
        self.host = (host or os.environ.get("OLLAMA_HOST") or "http://localhost:11434").rstrip("/")
        self.timeout = timeout
        self.name = f"ollama:{model}"

    def chat(self, request: ChatRequest) -> str:
        payload = {
            "model": self.model,
            "messages": [{"role": m.role, "content": m.content} for m in request.messages],
            "stream": False,
            "options": {"temperature": request.temperature},
        }
        try:
            resp = httpx.post(f"{self.host}/api/chat", json=payload, timeout=self.timeout)
        except httpx.HTTPError as e:
            raise ModelError(f"Ollama request failed: {e}") from e
        if resp.status_code != 200:
            raise ModelError(f"Ollama HTTP {resp.status_code}: {resp.text[:200]}")
        data = resp.json()
        return data.get("message", {}).get("content", "")

    def stream(self, request: ChatRequest) -> Iterator[str]:
        payload = {
            "model": self.model,
            "messages": [{"role": m.role, "content": m.content} for m in request.messages],
            "stream": True,
            "options": {"temperature": request.temperature},
        }
        try:
            with httpx.stream("POST", f"{self.host}/api/chat", json=payload, timeout=self.timeout) as resp:
                if resp.status_code != 200:
                    raise ModelError(f"Ollama HTTP {resp.status_code}")
                import json
                for line in resp.iter_lines():
                    if not line:
                        continue
                    try:
                        chunk = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    piece = chunk.get("message", {}).get("content", "")
                    if piece:
                        yield piece
                    if chunk.get("done"):
                        break
        except httpx.HTTPError as e:
            raise ModelError(f"Ollama stream failed: {e}") from e
