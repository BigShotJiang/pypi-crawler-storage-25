from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Iterator


@dataclass
class Message:
    role: str
    content: str


@dataclass
class ChatRequest:
    messages: list[Message]
    temperature: float = 0.2
    max_tokens: int | None = None
    stop: list[str] | None = None


class BaseModel(ABC):
    name: str = "base"

    @abstractmethod
    def chat(self, request: ChatRequest) -> str: ...

    def stream(self, request: ChatRequest) -> Iterator[str]:
        from aiforge.runtime.errors import NotImplementedFeatureError
        raise NotImplementedFeatureError(f"streaming for model '{self.name}'")
