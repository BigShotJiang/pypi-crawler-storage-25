import os
from typing import Iterator

import httpx

from aiforge.models.base import BaseModel, ChatRequest
from aiforge.runtime.errors import ModelError, ModelNotConfiguredError


class CustomModel(BaseModel):
    def __init__(self, base_url: str, model: str, api_key: str | None = None, timeout: int = 120):
        if not base_url:
            raise ModelNotConfiguredError("CustomModel requires base_url")
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout = timeout
        self.name = f"custom:{model}"

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def chat(self, request: ChatRequest) -> str:
        payload = {
            "model": self.model,
            "messages": [{"role": m.role, "content": m.content} for m in request.messages],
            "temperature": request.temperature,
        }
        try:
            resp = httpx.post(
                f"{self.base_url}/chat/completions",
                json=payload, headers=self._headers(), timeout=self.timeout,
            )
        except httpx.HTTPError as e:
            raise ModelError(f"Custom model request failed: {e}") from e
        if resp.status_code != 200:
            raise ModelError(f"Custom model HTTP {resp.status_code}: {resp.text[:200]}")
        data = resp.json()
        return data["choices"][0]["message"]["content"]
