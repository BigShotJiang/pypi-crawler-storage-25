from __future__ import annotations

import os
import threading
import time
from typing import Iterator

import httpx

from aiforge.models.base import BaseModel, ChatRequest
from aiforge.runtime.errors import ModelError, ModelNotConfiguredError

ZAPI_DEFAULT_BASE_URL = "https://z.os7.site"
ZAPI_DEFAULT_MODEL = "qwen-3-235b-a22b-instruct-2507"

KNOWN_MODELS: dict[str, str] = {
    "qwen-3-235b-a22b-instruct-2507": "Qwen 3 235B A22B Instruct (2507)",
    "llama-3.3-70b-versatile": "Llama 3.3 70B Versatile",
    "llama-4-scout-17b-16e-instruct": "Llama 4 Scout 17B 16E Instruct",
    "kimi-k2-instruct-0905": "Kimi K2 Instruct (0905)",
    "gpt-oss-20b": "GPT OSS 20B",
}

_RETRY_STATUSES = {500, 502, 503, 504}
_MAX_RETRIES = 3
_RETRY_BACKOFF = (2.0, 4.0, 8.0)


def _looks_like_html(s: str) -> bool:
    head = s.lstrip()[:200].lower()
    return head.startswith("<!doctype") or head.startswith("<html") or "<head" in head[:50]


def _messages_to_prompt(request: ChatRequest) -> str:
    """Flatten OpenAI-style chat messages into a single prompt for ZAPI's /api/llm/<model>."""
    parts: list[str] = []
    for m in request.messages:
        role = (m.role or "user").upper()
        if role == "SYSTEM":
            parts.append(f"[SYSTEM]\n{m.content}")
        elif role == "ASSISTANT":
            parts.append(f"[ASSISTANT]\n{m.content}")
        else:
            parts.append(f"[USER]\n{m.content}")
    parts.append("[ASSISTANT]\n")
    return "\n\n".join(parts)


class ZapiModel(BaseModel):
    """Native client for ZAPI (https://z.os7.site).

    Endpoint: POST {base_url}/api/llm/<model>
    Body:     {"apikey": "<key>", "prompt": "<text>"}
    Response: {"status": 200, "data": {"text": "...", "model": "..."}}

    Retries up to 3 times on 5xx errors with exponential backoff.
    stream() emits periodic elapsed-time ticks while waiting so the TUI
    shows progress rather than a blank spinner.
    """

    def __init__(
        self,
        model: str = ZAPI_DEFAULT_MODEL,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: int = 120,
        max_retries: int = _MAX_RETRIES,
    ):
        key = (api_key or os.environ.get("ZAPI_API_KEY") or "").strip()
        if not key:
            raise ModelNotConfiguredError(
                "ZAPI_API_KEY is not set. Run `aiforge setup` or `aiforge keys set zapi <key>`."
            )
        self.api_key = key
        url = (base_url or ZAPI_DEFAULT_BASE_URL).rstrip("/")
        if url.endswith("/v1"):
            url = url[:-3]
        self.base_url = url
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries
        self.name = f"zapi:{model}"

    def _endpoint(self) -> str:
        return f"{self.base_url}/api/llm/{self.model}"

    def _post_once(self, prompt: str) -> dict:
        try:
            resp = httpx.post(
                self._endpoint(),
                json={"apikey": self.api_key, "prompt": prompt},
                headers={"Content-Type": "application/json"},
                timeout=self.timeout,
            )
        except httpx.HTTPError as e:
            raise ModelError(f"ZAPI network error: {type(e).__name__}: {e}") from e

        body = resp.text or ""
        ctype = resp.headers.get("content-type", "")

        if resp.status_code in _RETRY_STATUSES:
            raise _RetryableError(f"ZAPI HTTP {resp.status_code}: {body[:120]}")

        if "application/json" not in ctype.lower():
            if _looks_like_html(body):
                raise ModelError(
                    f"ZAPI returned HTML (HTTP {resp.status_code}) from {self._endpoint()} "
                    "— check `aiforge config get providers.zapi.url`."
                )
            raise ModelError(f"ZAPI returned non-JSON (HTTP {resp.status_code}): {body[:200]}")

        try:
            data = resp.json()
        except ValueError as e:
            raise ModelError(f"ZAPI returned invalid JSON: {body[:200]}") from e

        if isinstance(data, dict) and data.get("status") and int(data["status"]) >= 400:
            err = data.get("error") or data.get("message") or "unknown error"
            raise ModelError(f"ZAPI error {data['status']} for model '{self.model}': {err}")

        if not isinstance(data, dict):
            raise ModelError(f"ZAPI response was not an object: {str(data)[:200]}")
        return data

    def _post(self, prompt: str) -> dict:
        last_err: Exception | None = None
        for attempt in range(self.max_retries):
            try:
                return self._post_once(prompt)
            except _RetryableError as e:
                last_err = e
                if attempt < self.max_retries - 1:
                    delay = _RETRY_BACKOFF[min(attempt, len(_RETRY_BACKOFF) - 1)]
                    time.sleep(delay)
            except ModelError:
                raise
        raise ModelError(f"ZAPI failed after {self.max_retries} attempts: {last_err}")

    def chat(self, request: ChatRequest) -> str:
        prompt = _messages_to_prompt(request)
        data = self._post(prompt)
        payload = data.get("data") if isinstance(data.get("data"), dict) else {}
        text = payload.get("text") or data.get("text") or ""
        if not isinstance(text, str):
            text = str(text)
        return text

    def stream(self, request: ChatRequest) -> Iterator[str]:
        """
        ZAPI doesn't support streaming. We run the HTTP call in a thread
        and emit elapsed-time ticks every second so the TUI shows progress.

        Yields:
          - One tick per second: "⠋ waiting (Ns)…"  (overwritten by next tick)
          - Then the full response text when it arrives.
        """
        result_holder: list[str | BaseException] = []

        def _worker():
            try:
                text = self.chat(request)
                result_holder.append(text)
            except BaseException as exc:
                result_holder.append(exc)

        t = threading.Thread(target=_worker, daemon=True)
        t.start()

        _TICK = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        start = time.time()
        i = 0
        while not result_holder:
            elapsed = int(time.time() - start)
            spinner = _TICK[i % len(_TICK)]
            yield f"\r{spinner} thinking… ({elapsed}s)"
            i += 1
            time.sleep(1.0)
            if not result_holder and elapsed > self.timeout + 5:
                break

        t.join(timeout=5)

        if not result_holder:
            raise ModelError("ZAPI stream timed out waiting for response")

        outcome = result_holder[0]
        if isinstance(outcome, BaseException):
            raise outcome

        # Emit a carriage-return to wipe the spinner line, then the real response
        yield f"\r{outcome}"


class _RetryableError(Exception):
    """Internal signal for retryable HTTP errors (5xx)."""


def list_known_models() -> dict[str, str]:
    return dict(KNOWN_MODELS)
