from aiforge.runtime.errors import NotImplementedFeatureError


class BytezModel:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("models.providers.bytez")
