try:
    from aiforge.models.providers.openrouter import OpenRouterModel
    __all__ = ["OpenRouterModel", "CustomModel"]
except ImportError:
    __all__ = ["CustomModel"]

from aiforge.models.providers.custom import CustomModel
