import os

from aiforge.models.openai import OpenAIModel
from aiforge.runtime.errors import ModelNotConfiguredError


class OpenRouterModel(OpenAIModel):
    def __init__(self, model: str = "openai/gpt-4o-mini", api_key: str | None = None):
        key = api_key or os.environ.get("OPENROUTER_API_KEY")
        if not key:
            raise ModelNotConfiguredError("OPENROUTER_API_KEY is not set")
        super().__init__(model=model, api_key=key, base_url="https://openrouter.ai/api/v1")
        self.name = f"openrouter:{model}"
