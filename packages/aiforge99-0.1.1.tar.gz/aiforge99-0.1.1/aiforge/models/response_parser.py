from typing import Any

from aiforge.utils.json_fix import extract_json as _extract_json_impl

# Re-export the improved implementation
extract_json = _extract_json_impl
