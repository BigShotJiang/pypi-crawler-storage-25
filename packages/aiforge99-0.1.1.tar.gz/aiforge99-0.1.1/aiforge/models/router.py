import os

from aiforge.models.base import BaseModel
from aiforge.runtime.errors import ModelError, ModelNotConfiguredError


class ModelRouter:
    def __init__(self):
        self._models: dict[str, BaseModel] = {}
        self._default: str | None = None

    def register(self, name: str, model: BaseModel, default: bool = False) -> None:
        self._models[name] = model
        if default or self._default is None:
            self._default = name

    def get(self, name: str | None = None) -> BaseModel:
        key = name or self._default
        if not key:
            raise ModelNotConfiguredError("No models registered")
        if key not in self._models:
            raise ModelError(f"Model not registered: {key}")
        return self._models[key]

    def names(self) -> list[str]:
        return sorted(self._models.keys())

    @classmethod
    def from_config(cls, config) -> "ModelRouter":
        router = cls()
        providers = config.get("providers", {}) or {}

        if providers.get("openai", {}).get("enabled") and os.environ.get("OPENAI_API_KEY"):
            from aiforge.models.openai import OpenAIModel
            model_name = providers["openai"].get("model") or config.get("default_model", "gpt-4o-mini")
            router.register("openai", OpenAIModel(model=model_name), default=True)

        if providers.get("ollama", {}).get("enabled"):
            from aiforge.models.ollama import OllamaModel
            host = providers["ollama"].get("host")
            model_name = providers["ollama"].get("model", "llama3")
            router.register("ollama", OllamaModel(model=model_name, host=host),
                            default=router._default is None)

        if providers.get("openrouter", {}).get("enabled") and os.environ.get("OPENROUTER_API_KEY"):
            from aiforge.models.providers.openrouter import OpenRouterModel
            model_name = providers["openrouter"].get("model", "openai/gpt-4o-mini")
            router.register("openrouter", OpenRouterModel(model=model_name),
                            default=router._default is None)

        if providers.get("zapi", {}).get("enabled") and (os.environ.get("ZAPI_API_KEY") or "").strip():
            from aiforge.models.providers.zapi import ZAPI_DEFAULT_MODEL, ZapiModel
            zcfg = providers["zapi"]
            model_name = zcfg.get("model", ZAPI_DEFAULT_MODEL)
            base_url = zcfg.get("base_url") or zcfg.get("url")
            router.register("zapi", ZapiModel(model=model_name, base_url=base_url),
                            default=router._default is None)

        preferred = config.get("default_provider")
        if preferred and preferred in router._models:
            router._default = preferred

        return router
