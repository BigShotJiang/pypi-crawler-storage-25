from aiforge.runtime.errors import NotImplementedFeatureError


class Profiler:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("observability.profiler (CPU/memory profiling)")
