from collections import Counter, defaultdict


class Metrics:
    def __init__(self):
        self.counters: Counter = Counter()
        self.timings: dict[str, list[int]] = defaultdict(list)

    def inc(self, name: str, value: int = 1) -> None:
        self.counters[name] += value

    def record_timing(self, name: str, ms: int) -> None:
        self.timings[name].append(ms)

    def snapshot(self) -> dict:
        return {
            "counters": dict(self.counters),
            "timings": {k: {"count": len(v), "total_ms": sum(v)} for k, v in self.timings.items()},
        }
