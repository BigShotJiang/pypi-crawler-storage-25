from aiforge.runtime.errors import NotImplementedFeatureError


class Debugger:
    def __init__(self, *args, **kwargs):
        raise NotImplementedFeatureError("observability.debugger (interactive debugger attach)")
