import json
import uuid
from pathlib import Path

from aiforge.utils.time import utcnow_iso


def _logs_dir() -> Path:
    from aiforge.runtime.workspace import resolve_workspace
    return resolve_workspace() / ".aiforge" / "logs"


class Tracer:
    def __init__(self, run_id: str | None = None):
        self.run_id = run_id or uuid.uuid4().hex[:12]
        logs = _logs_dir()
        logs.mkdir(parents=True, exist_ok=True)
        self.path = logs / f"trace-{self.run_id}.jsonl"

    def event(self, kind: str, **data) -> None:
        record = {"ts": utcnow_iso(), "run_id": self.run_id, "kind": kind, **data}
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, default=str) + "\n")
