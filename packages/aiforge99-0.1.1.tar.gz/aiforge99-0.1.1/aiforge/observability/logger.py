import logging
from pathlib import Path


def _logs_dir() -> Path:
    from aiforge.runtime.workspace import resolve_workspace
    return resolve_workspace() / ".aiforge" / "logs"


def get_logger(name: str = "aiforge", level: str = "INFO") -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    fmt = logging.Formatter("%(asctime)s %(levelname)s [%(name)s] %(message)s")
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)
    logs = _logs_dir()
    logs.mkdir(parents=True, exist_ok=True)
    fh = logging.FileHandler(logs / "aiforge.log")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    logger.propagate = False
    return logger
