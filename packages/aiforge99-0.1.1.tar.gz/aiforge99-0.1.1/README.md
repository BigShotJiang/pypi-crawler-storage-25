# AIForge

**AIForge** is a terminal-based autonomous AI agent with an interactive TUI and full CLI — designed for developers who want an AI coding assistant that runs locally, talks to any LLM, and operates directly on their file system.

```
aiforge tui       # launch full TUI (chat + file browser + status)
aiforge run "create a Flask REST API"   # one-shot task
aiforge           # interactive REPL
```

---

## Features

- **Interactive TUI** — 3-panel layout: file browser, chat, live status. Press `Ctrl+F` to toggle the file panel, `Escape` to cancel a running task.
- **CLI REPL** — persistent prompt-toolkit shell with session history, built-in commands (`:help`, `:tools`, `:sessions`, `:workspace`, …)
- **Autonomous agent** — plan → execute → observe loop with stop policy, retry logic, and proper JSON memory
- **15 built-in tools** — file read/write/edit/create/delete/search, shell.run, git commit/diff/rollback, project.workspace/analyze, network.fetch/scrape/search
- **Multi-provider** — ZAPI, OpenAI, OpenRouter, Ollama (local), with automatic retry on 5xx errors
- **Session history** — every task logged; inspect with `aiforge sessions show <id>`
- **Portable workspace** — resolves via `AIFORGE_WORKSPACE` env → config → cwd; no hardcoded paths

---

## Installation

```bash
pip install aiforge
```

Requires Python 3.11+.

---

## Quick Start

### 1. Configure a provider

```bash
aiforge setup          # interactive wizard
# or directly:
aiforge keys set zapi YOUR_API_KEY
aiforge models use zapi qwen-3-235b-a22b-instruct-2507
```

Supported providers: **ZAPI**, **OpenAI**, **OpenRouter**, **Ollama** (no key needed).

### 2. Launch

```bash
# Full TUI (recommended)
aiforge tui

# One-shot task
aiforge run "write a Python web scraper for example.com"

# Interactive REPL
aiforge
```

### 3. Set your workspace

```bash
aiforge workspace set /path/to/your/project
# or
export AIFORGE_WORKSPACE=/path/to/your/project
```

---

## TUI Keybindings

| Key | Action |
|-----|--------|
| `Ctrl+Q` | Quit |
| `Ctrl+F` | Toggle file panel |
| `Ctrl+L` | Clear chat |
| `Ctrl+R` | Refresh file tree |
| `Escape` | Cancel running task |

---

## CLI Commands

```
aiforge doctor              check environment health
aiforge run <task>          run a one-shot agent task
aiforge tools list          show all available tools
aiforge tool <name> k=v     invoke a tool directly
aiforge sessions            list sessions
aiforge sessions show <id>  inspect a session's task log
aiforge workspace show      print active workspace
aiforge workspace set <p>   persist workspace path
aiforge providers list      show provider status
aiforge providers test      send a test request to verify provider
aiforge models list         list known models per provider
aiforge models use <p> <m>  select active model
aiforge keys set <p> <key>  save provider API key to .env
aiforge config get [key]    read config value
aiforge config set key val  write config value
```

---

## REPL Commands

In the REPL (plain `aiforge`) or TUI input, prefix with `:`:

```
:help              built-in commands
:tools             list registered tools
:sessions          list sessions
:session <id>      inspect session (prefix match ok)
:workspace         show workspace
:workspace set <p> change workspace
:model             active model
:providers         provider status
:test [name]       test a provider
:clear             clear screen/chat
:quit              exit
```

---

## Configuration

Config lives at `<workspace>/.aiforge/config.json`. Use `aiforge config set` to edit, or directly:

```json
{
  "default_provider": "zapi",
  "providers": {
    "zapi": {
      "enabled": true,
      "model": "qwen-3-235b-a22b-instruct-2507"
    }
  }
}
```

API keys go in `.env`:

```
ZAPI_API_KEY=your_key
OPENAI_API_KEY=your_key
OPENROUTER_API_KEY=your_key
```

---

## License

MIT
