from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Any, TypeAlias, cast, final

from result import Err, Ok, Result

from .exceptions import CrossandraTokenizationError
from .rule import Ignored, NotApplied, Rule, RuleGroup

if TYPE_CHECKING:
    from collections.abc import Iterable


def invert_enum(enum: type[Enum]) -> dict[str, Enum]:
    out = {}
    for v in enum.__members__.values():
        if isinstance(v.value, tuple):
            for i in v.value:
                out[i] = v
        else:
            out[v.value] = v
    return out


Tree: TypeAlias = "dict[str, Enum | Tree]"


def empty_handler(string: str) -> tuple[Result[Enum, str], int]:
    return Err(string[0]), 1


def generate_tree(inp: Iterable[tuple[str, Enum]]) -> Tree:
    inp = sorted(inp, key=lambda v: len(v[0]), reverse=True)
    result: Tree = {}
    for k, v in inp:
        curr = result
        for c in k[:-1]:
            curr = cast("Tree", curr.setdefault(c, {}))
        if dct := curr.get(k[-1]):
            assert isinstance(dct, dict)  # noqa: S101  (needed for mypyc)
            dct[""] = v
        else:
            curr[k[-1]] = v
    return result


class Empty(Enum):
    """An empty enum. Used by Crossandra if no enum is supplied."""


@final
class Crossandra:
    """
    A Crossandra tokenizer. Takes the following arguments:
    - `token_source`: an enum containing all possible tokens (defaults
      to an empty enum)
    - `convert_crlf`: whether `\\r\\n` should be converted to `\\n` before tokenization
    - `ignored_characters`: a string of characters to ignore (defaults to "")
    - `ignore_whitespace`: whether spaces, tabs, newlines etc. should
      be ignored (defaults to False)
    - `suppress_unknown`: whether unknown token errors should be suppressed
      (defaults to False)
    - `rules`: a list of additional rules to use

    The enum takes priority over the rule list.\\
    The list of rules is ordered by priority (descending).
    """

    __slots__ = (
        "__conv_crlf",
        "__fast",
        "__ignored",
        "__keys",
        "__maxlen",
        "__rules",
        "__suppress",
        "__tokens",
        "__tree",
    )

    def __init__(
        self,
        token_source: type[Enum] = Empty,
        *,
        convert_crlf: bool = True,
        ignore_whitespace: bool = False,
        ignored_characters: str = "",
        rules: list[Rule[Any] | RuleGroup] | None = None,
        suppress_unknown: bool = False,
    ) -> None:
        self.__rules: list[Rule[Any]] = []
        for r in rules or []:
            if isinstance(r, RuleGroup):
                self.__rules.extend(r)
            else:
                self.__rules.append(r)
        self.__conv_crlf = convert_crlf
        self.__tokens = invert_enum(token_source)
        self.__fast = all(len(k) == 1 for k in self.__tokens) and not rules
        self.__ignored = " \f\t\v\r\n" * ignore_whitespace + ignored_characters
        self.__keys = sorted(self.__tokens, key=len, reverse=True)
        self.__maxlen = max(map(len, self.__keys or ["1"]))
        self.__suppress = suppress_unknown
        self.__tree = generate_tree(self.__tokens.items())

    def tokenize(
        self, code: str, *, with_positions: bool = False
    ) -> list[Any] | list[tuple[int, Any]]:
        """
        Tokenizes the input string. Returns a list of tokens.
        """
        if self.__conv_crlf:
            code = code.replace("\r\n", "\n")
        if " " in self.__ignored:
            code += " "

        if self.__fast:
            toks = self.__tokenize_fast(code, with_positions=with_positions)
            if toks.is_ok():
                return toks.unwrap()
            msg = f"invalid token: {toks.unwrap_err()!r}"
            raise CrossandraTokenizationError(msg)

        original_size = len(code)
        tokens: list[Any] = []
        maxlen = self.__maxlen
        ignored = self.__ignored
        t_append = tokens.append
        handle = self.__handle if self.__tokens else empty_handler
        while code := code.lstrip(ignored):
            token, length = handle(code[:maxlen])
            if token.is_ok():
                t_append(
                    (original_size - len(code), token.unwrap())
                    if with_positions
                    else token.unwrap()
                )
                code = code[length:]
                continue
            for rule in self.__rules:
                tok = rule.apply(code)
                if not isinstance(tok, NotApplied):
                    token_, length = tok
                    if not isinstance(token_, Ignored):
                        t_append(
                            (original_size - len(code), token_)
                            if with_positions
                            else token_
                        )
                    code = code[length:]
                    break
            else:
                if not self.__suppress:
                    msg = f"invalid token: {token.unwrap_err()!r}"
                    raise CrossandraTokenizationError(msg)
                code = code[1:]

        return tokens

    def tokenize_lines(
        self, code: str, *, with_positions: bool = False
    ) -> list[list[Any]] | list[list[tuple[int, Any]]]:
        """
        Tokenizes the input string line by line. Returns a nested list
        of tokens, where each inner list corresponds to a consecutive
        line of the input string. Equivalent to
        `[foo.tokenize(line) for line in source.splitlines()]`.
        """
        return [
            self.tokenize(line, with_positions=with_positions)
            for line in code.splitlines()
        ]

    def __handle(self, string: str) -> tuple[Result[Enum, str], int]:
        tree = self.__tree
        break_path: tuple[Enum, int] | None = None

        for i, v in enumerate(string):
            if "" in tree:
                break_path = (cast("Enum", tree[""]), i)

            c = tree.get(v)
            if c is None:
                if "" not in tree:
                    break
                return Ok(cast("Enum", tree[""])), i
            if isinstance(c, Enum):
                return Ok(c), i + 1
            tree = c

        if break_path:
            return Ok(break_path[0]), break_path[1]

        return Err(string[0]), 0

    def __tokenize_fast(
        self, code: str, *, with_positions: bool = False
    ) -> Result[list[Enum], str] | Result[list[tuple[int, Enum]], tuple[int, str]]:
        tokens: list[Any] = []
        append = tokens.append
        ignored = self.__ignored
        suppress = self.__suppress
        source = self.__tokens
        for i, char in enumerate(code):
            if char in ignored:
                continue
            if (t := source.get(char)) is None:
                if suppress:
                    continue
                return Err((i, char)) if with_positions else Err(char)
            append((i, t) if with_positions else t)
        return Ok(tokens)
