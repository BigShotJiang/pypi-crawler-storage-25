"""
encode_2d (alias: encode_640) — reference Python implementation of
the 640-dim spectral chess encoder that the C17 port mirrors.

The function name ``encode_2d`` is the 1.9.0+ recommended public
name; ``encode_640`` is preserved as a permanent alias. New
consumer code should prefer ``encode_2d`` and query
``chess_spectral.ENCODING_DIM`` (or ``enc.shape[0]``) rather than
hardcoding 640 — the dim count is not a stable contract per
notebook §19.11 (sheets bumped 640 → 651 already; future channel
embiggening or bit-serialized variants may move it again).

Channel layout (10 channels × 64 dims = 640):
    A1, A2, B1, B2, E         — D4 irreps (via Serre's character formula)
    F1, F2, F3                — symmetric fiber (per-piece local Laplacians
                                 projected onto a 3D fiber basis)
    FA                         — antisymmetric fiber / pawn directional flow.
                                 Built from A_anti = (A_white - A_white.T)/2,
                                 in the grid eigenbasis.
    FD                         — diagonal deviation / rook's shadow.
                                 diag(EVECS.T @ L_piece @ EVECS) - EVALS_GRID,
                                 weighted by signed piece value.

All precomputed tables (eigenbasis, fiber basis, local fibers, PAWN_ANTI_FIBER,
DIAG_DEV) live in chess_spectral.tables — which caches them to disk on first
import. This module consumes them; the math derivation is over there.

The 640-dim output matches the C encoder's byte-for-byte for dims 0-511
(identical math on top of the same tables) and matches within float32
precision for dims 512-639 (where the C side stores the values as f32).

Position format (`pos`):
    dict mapping square index (0..63, row-major from a8=0) to piece
    character ("P","N","B","R","Q","K" white, lowercase black).

    Convenience: int keys can also be passed as str — NDJSON payloads
    use `{"0":"R", ...}`. normalize_pos() handles both.

Optional kwargs:
    ``sheets`` (1.9.0+) — append the 11-dim non-Markovian aux block
    (castling rights, EP target, halfmove clock, side-to-move,
    repetition count). See ``chess_spectral.SheetState``. Default
    ``None`` keeps the 640-dim output bit-for-bit compatible with
    pre-1.9.0 versions and the C side.

Adjacent encoders / hybrid forms (1.10.0+):
    * ``chess_spectral.encode_2d_bip_hybrid(pos, magnitude_bits=8)``
      — sign × magnitude factoring; ~3.4× compression at 8-bit
      (notebook §20.18).
    * ``chess_spectral.SheetStateBIP`` and
      ``chess_spectral.encode_sheet_state_bip(state)`` —
      integer-native sheet block (3 bytes vs 88 bytes float64).
"""
from __future__ import annotations

# Guard against direct-script execution (`python encoder.py`). The
# relative import below will fail because there's no parent package in
# that context, and the user will see a cryptic ImportError rather than
# the usage message. Detect + print help + exit cleanly.
if __name__ == "__main__" and __package__ in (None, ""):
    import sys
    print(
        "chess_spectral.encoder is a library module, not a CLI.\n"
        "\n"
        "Command-line use — run the sibling driver:\n"
        "    python spectral_py.py csv        game.spectralz -o game.csv\n"
        "    python spectral_py.py encode     -i game.ndjson -o game.spectral -z\n"
        "    python spectral_py.py encode-fen --fen \"...\" -o single.spectral\n"
        "    python spectral_py.py version\n"
        "\n"
        "Programmatic use:\n"
        "    >>> from chess_spectral import encode_2d, channel_energies, fen_to_pos\n"
        "    >>> enc = encode_2d(fen_to_pos(\"...\"))   # shape (640,)\n",
        file=sys.stderr,
    )
    sys.exit(2)

import numpy as np

from .tables import (
    BOARD_DIM,
    SHORT_PFNS, SPECTRAL_VALS, VALS,
    LOCAL_FIBER_3D, LOCAL_ADJ_ROWS,
    PAWN_ANTI_FIBER, DIAG_DEV,
    board_signal, project_irrep,
)

ENCODING_DIM = 640
N_CHANNELS   = 10

# Channel name → (start_dim) and ordered list for iteration.
CHANNELS = [
    ("A1",   0), ("A2",  64), ("B1", 128), ("B2", 192), ("E",  256),
    ("F1", 320), ("F2", 384), ("F3", 448), ("FA", 512), ("FD", 576),
]

# Piece-char → DIAG_DEV row index (FD channel).
_PIECE_IDX = {'P': 0, 'N': 1, 'B': 2, 'R': 3, 'Q': 4, 'K': 5}

# Piece-char → LOCAL_FIBER_3D / LOCAL_ADJ_ROWS first-axis index.
# Matches tables.py construction order ['N', 'B', 'R', 'Q', 'K'].
_FIBER_IDX = {'N': 0, 'B': 1, 'R': 2, 'Q': 3, 'K': 4}


# ─── Position normalization ─────────────────────────────────────────────

def normalize_pos(pos) -> dict[int, str]:
    """Accept either int-keyed dict (native) or str-keyed dict (NDJSON).
    Returns a fresh int-keyed dict."""
    if not pos:
        return {}
    first = next(iter(pos))
    if isinstance(first, int):
        return dict(pos)
    return {int(k): v for k, v in pos.items()}


# ─── The encoder ────────────────────────────────────────────────────────

def _fiber_antisymmetric(pos: dict[int, str]) -> np.ndarray:
    """Channel FA (dims 512-575). Only pawns contribute.

        out[k] = Σ_{pawn at s} sign(color) · val_P · PAWN_ANTI_FIBER[s, k]

    PAWN_ANTI_FIBER is already in the grid eigenbasis, so there's no
    runtime eigenvector multiply — just a weighted sum of rows.
    """
    out = np.zeros(BOARD_DIM)
    val_P = SPECTRAL_VALS['P']
    for s, pchar in pos.items():
        if pchar.upper() != 'P':
            continue
        w = val_P if pchar == 'P' else -val_P
        out += w * PAWN_ANTI_FIBER[s]
    return out


def _fiber_diagonal(pos: dict[int, str], sig: np.ndarray) -> np.ndarray:
    """Channel FD (dims 576-639). Every occupied square contributes,
    weighted by its signed piece value (already encoded in `sig`):

        out[k] = Σ_{occupied s} sig[s] · DIAG_DEV[piece_type(s), k]
    """
    out = np.zeros(BOARD_DIM)
    for s, pchar in pos.items():
        t = _PIECE_IDX[pchar.upper()]
        out += sig[s] * DIAG_DEV[t]
    return out


def encode_640(pos, *, vals=None, sheets=None) -> np.ndarray:
    """Encode a position to a 640-dim spectral vector.

    Parameters
    ----------
    pos : dict[int|str, str]
        Square-index → piece-char. See module docstring.
    vals : dict[str, float] or None
        Piece-value table. Defaults to SPECTRAL_VALS (mean-degree
        normalization), matching the C encoder. Pass VALS for the
        traditional {P=1, Q=9, K=100} heuristic.
    sheets : SheetState or None, optional (1.9.0+)
        If supplied, append the 11-dim non-Markovian aux block (see
        :mod:`chess_spectral.sheets`) to the 640-dim base, producing a
        651-dim output. The base 640 dims are byte-identical to the
        legacy output and to the C encoder; the aux block carries
        castling rights, EP target, side-to-move, halfmove clock, and
        repetition count for downstream consumers of saved/transmitted
        vectors. Default ``None`` keeps the legacy 640-dim output bit-
        for-bit compatible with pre-1.9.0 versions and the C side.

    Returns
    -------
    np.ndarray, dtype float64
        Shape ``(640,)`` if ``sheets`` is None (default), else ``(651,)``.
    """
    pos = normalize_pos(pos)
    if vals is None:
        vals = SPECTRAL_VALS

    sig = board_signal(pos, vals=vals)

    # Allocate base 640 dims; concatenated aux is appended below if
    # sheets is supplied. Allocating up-front and writing in-place
    # avoids a second allocation+copy on the hot path.
    if sheets is None:
        out = np.empty(ENCODING_DIM, dtype=np.float64)
    else:
        from .sheets import SHEET_AUX_DIM, encode_aux_block
        out = np.empty(ENCODING_DIM + SHEET_AUX_DIM, dtype=np.float64)

    # Channels 0-4: D4 irreps
    for i, name in enumerate(['A1', 'A2', 'B1', 'B2', 'E']):
        out[i * BOARD_DIM:(i + 1) * BOARD_DIM] = project_irrep(sig, name)

    # Channels 5-7: symmetric fiber. Non-pawn pieces only.
    for d in range(3):
        fc = np.zeros(BOARD_DIM)
        for si, pchar in pos.items():
            pkey = pchar.upper()
            if pkey not in _FIBER_IDX:
                continue  # pawn: no symmetric Laplacian used here
            pidx    = _FIBER_IDX[pkey]
            fib_d   = LOCAL_FIBER_3D[pidx, si, d]
            adj_row = LOCAL_ADJ_ROWS[pidx, si]
            gradient = float(adj_row @ sig)
            fc += gradient * fib_d * adj_row
        out[320 + d * BOARD_DIM:320 + (d + 1) * BOARD_DIM] = fc

    # Channel 8: antisymmetric pawn fiber
    out[512:576] = _fiber_antisymmetric(pos)

    # Channel 9: diagonal deviation
    out[576:640] = _fiber_diagonal(pos, sig)

    if sheets is not None:
        out[ENCODING_DIM:ENCODING_DIM + SHEET_AUX_DIM] = encode_aux_block(sheets)

    return out


# 1.9.0 — future-proof alias.
#
# ``encode_640`` couples the function name to a specific output
# dimension (10 channels × 64 board cells = 640). That coupling is
# fine for the v1.x line but it pins downstream consumers to assume
# the dim count is stable. Two cases where it might not be:
#
#   1. A future `embiggening` for richer non-Markovian or sheet data,
#      analogous to the Z_101 halfmove Fourier carrier — we may want
#      to extend channel granularity beyond the current 10 × 64.
#   2. The bit-serialized HDC / resonant-object spike (notebook §20)
#      found in the antikythera-spectral / DE441 work that bit-
#      serialization can ENRICH the data set after a basis change
#      (from 3.3 GB raw → 1 MB physics → 256 KB bit-serialized,
#      with >300x speedup and ~0.01% precision loss). It is uncertain
#      whether that result translates to a discrete board game with
#      a non-Markovian sheet, but the §19 sheet block is itself a
#      concrete example of why the dim count is not a stable
#      contract — adding sheets bumped 640 → 651.
#
# ``encode_2d`` is the recommended name going forward; it mirrors
# the 4D path's ``encode_4d`` naming. ``encode_640`` is preserved as
# a permanent alias for backward compatibility but new code should
# prefer ``encode_2d`` and query :data:`ENCODING_DIM` (or check the
# returned array's ``shape``) rather than hardcoding 640. See
# notebook §19.11 for the future-work plan.
encode_2d = encode_640


def channel_energies(enc: np.ndarray) -> dict[str, float]:
    """||channel||² for each of the 10 channels, keyed by name."""
    return {name: float(np.dot(enc[start:start + BOARD_DIM],
                                enc[start:start + BOARD_DIM]))
            for name, start in CHANNELS}


# ─── CLI usage hint ─────────────────────────────────────────────────────

_USAGE = """\
chess_spectral.encoder — 640-dim spectral chess encoder (Python reference).

This module is a library, not a CLI. For command-line use, run the
sibling driver:

    python spectral_py.py csv        game.spectralz -o game.csv
    python spectral_py.py encode     -i game.ndjson -o game.spectral -z
    python spectral_py.py encode-fen --fen "..." -o single.spectral
    python spectral_py.py version

Programmatic use:

    >>> from chess_spectral import encode_640, channel_energies, fen_to_pos
    >>> pos = fen_to_pos("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
    >>> enc = encode_640(pos)          # shape (640,)
    >>> channel_energies(enc)
    {'A1': 0.0, 'A2': 19.845, ...}

Cache inspection:

    >>> from chess_spectral.tables import cache_info, cache_rebuild
    >>> cache_info()
    {'version': '1.0.0', 'source': 'cache', 'path': '...', ...}
"""


def _print_usage() -> None:
    import sys
    print(_USAGE, file=sys.stderr)


if __name__ == "__main__":
    _print_usage()
