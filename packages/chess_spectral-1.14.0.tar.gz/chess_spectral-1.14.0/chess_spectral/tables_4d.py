"""4D extension tables for the chess-spectral encoder.

Mirrors the shape of [tables.py] but operates on the Z_8^4 hypercubic
lattice (4096 squares) under the B_4 hyperoctahedral symmetry group.
Paired with [../chess_spectral_4d/cli.py], which exposes the phase-N
validation gates used to check each implementation stage.

Piece movement definitions follow Oana & Chiru, "On a Four-Dimensional
Chess Model," AppliedMath 6(3):48, 2026 — see section 3.

Status (v1.1.1+): all encoder tables are real and tested. P8
eigenbasis, B_4 group action / irrep projection, and the rank-3
fiber bundle are all implemented and pass C↔Python parity at
TOL=1e-10 (see python/tests/test_c_py_parity_4d.py). The phase
gates remain as the validation entry-point for any future schema
revision.
"""
from __future__ import annotations

from itertools import product
from typing import Iterator, Tuple, Callable, List

import numpy as np
from scipy.sparse import csr_matrix, lil_matrix, diags
from scipy.sparse.csgraph import connected_components

BOARD_SIDE = 8
N_DIMS = 4
N_SQUARES = BOARD_SIDE ** N_DIMS          # 4096

Coord = Tuple[int, int, int, int]


# ─── Geometry ──────────────────────────────────────────────────────────

def sq4(x: int, y: int, z: int, w: int) -> int:
    """Row-major linear index of square (x,y,z,w) on Z_8^4. x is the
    slowest-varying axis, w the fastest — matches `arr[x,y,z,w]` under
    numpy C-order ravel."""
    return ((x * BOARD_SIDE + y) * BOARD_SIDE + z) * BOARD_SIDE + w


def rc4(s: int) -> Coord:
    """Inverse of sq4."""
    w = s & 7
    s >>= 3
    z = s & 7
    s >>= 3
    y = s & 7
    x = s >> 3
    return x, y, z, w


def _in_bounds(v: int) -> bool:
    return 0 <= v < BOARD_SIDE


# ─── Piece target generators ───────────────────────────────────────────
#
# Each function yields Coord tuples reachable from (x,y,z,w) for that
# piece on an otherwise-empty Z_8^4 board. Used to build undirected
# adjacency (directed for pawns).
#
# Mobility (Oana & Chiru section 3):
#   rook:   28 at every square (K_8 along each of 4 axes)
#   king:   80 at interior (3^4 - 1), fewer at boundaries
#   knight: 48 at deep interior (C(4,2) * 2 * 2 * 2), fewer at boundaries
#   bishop: 2 connected components partitioned by sum(coords) mod 2
#   queen:  union of rook + bishop
#   pawn:   directed single-step on +w axis

def grid4_targets(x: int, y: int, z: int, w: int) -> Iterator[Coord]:
    """4D grid graph: Cartesian product P_8 [] P_8 [] P_8 [] P_8. Each
    square adjacent to <=8 neighbors (+-1 along each of 4 axes). This
    is the 'empty-board' graph whose Laplacian eigenbasis is the
    tensor-DCT basis used by the encoder."""
    coords = [x, y, z, w]
    for axis in range(N_DIMS):
        for sign in (-1, +1):
            out = coords.copy()
            out[axis] = coords[axis] + sign
            if _in_bounds(out[axis]):
                yield (out[0], out[1], out[2], out[3])


def rook4_targets(x: int, y: int, z: int, w: int) -> Iterator[Coord]:
    """4D rook: all other squares differing in exactly one coordinate.
    Graph = K_8 □ K_8 □ K_8 □ K_8 (Hamming H(4,8))."""
    coords = [x, y, z, w]
    for axis in range(N_DIMS):
        fixed = coords[axis]
        for v in range(BOARD_SIDE):
            if v == fixed:
                continue
            out = coords.copy()
            out[axis] = v
            yield (out[0], out[1], out[2], out[3])


def bishop4_targets(x: int, y: int, z: int, w: int) -> Iterator[Coord]:
    """4D bishop: slide along diagonals of any 2-face. Choose 2 axes
    from 4, step by ±k in each with independent signs, k in 1..7.
    Preserves parity of coordinate sum ⇒ 2 connected components."""
    coords = [x, y, z, w]
    for i in range(N_DIMS):
        for j in range(i + 1, N_DIMS):
            for si in (-1, +1):
                for sj in (-1, +1):
                    for k in range(1, BOARD_SIDE):
                        ni, nj = coords[i] + si * k, coords[j] + sj * k
                        if not (_in_bounds(ni) and _in_bounds(nj)):
                            break
                        out = coords.copy()
                        out[i], out[j] = ni, nj
                        yield (out[0], out[1], out[2], out[3])


def knight4_targets(x: int, y: int, z: int, w: int) -> Iterator[Coord]:
    """4D knight: (2,1)-leaper. One axis shifts by ±2, a different axis
    by ±1, the other two unchanged. Interior degree = 4·3·2·2 = 48."""
    coords = [x, y, z, w]
    for a2 in range(N_DIMS):
        for a1 in range(N_DIMS):
            if a1 == a2:
                continue
            for s2 in (-2, +2):
                for s1 in (-1, +1):
                    out = coords.copy()
                    out[a2] = coords[a2] + s2
                    out[a1] = coords[a1] + s1
                    if _in_bounds(out[a2]) and _in_bounds(out[a1]):
                        yield (out[0], out[1], out[2], out[3])


def king4_targets(x: int, y: int, z: int, w: int) -> Iterator[Coord]:
    """4D king: Chebyshev-1. Each coord shifts by -1/0/+1, not all zero.
    Graph = P_8 ⊠ P_8 ⊠ P_8 ⊠ P_8 (strong product). Interior deg = 80."""
    coords = (x, y, z, w)
    for d in product((-1, 0, 1), repeat=N_DIMS):
        if d == (0, 0, 0, 0):
            continue
        out = tuple(coords[i] + d[i] for i in range(N_DIMS))
        if all(_in_bounds(v) for v in out):
            yield out


def queen4_targets(x: int, y: int, z: int, w: int) -> Iterator[Coord]:
    """Queen = rook U bishop (disjoint supports; rook moves along single
    axis, bishop along 2-face diagonals)."""
    yield from rook4_targets(x, y, z, w)
    yield from bishop4_targets(x, y, z, w)


def white_pawn4_targets(x: int, y: int, z: int, w: int) -> Iterator[Coord]:
    """4D white pawn: single-step push on +w axis (w is the 'forward'
    axis by convention). Directed edge only. Captures deferred to a
    follow-up until Oana & Chiru's exact diagonal-capture rule is
    pinned down — the encoder's antisymmetric pawn fiber depends only
    on forward push for Z_2 breaking."""
    if w + 1 < BOARD_SIDE:
        yield (x, y, z, w + 1)


def white_pawn4_y_targets(x: int, y: int, z: int, w: int) -> Iterator[Coord]:
    """4D white pawn on Y axis: single-step push on +y. Oana & Chiru
    (AppliedMath 6(3):48, 2026) Definition 11 allows pawns to be
    oriented along y OR w (never z); section 3.11 makes y<->w a
    ruleset-preserving symmetry. Same structural role as
    white_pawn4_targets but on a different tensor factor — feeds
    pawn_anti_y_4d() as the W-axis generator feeds pawn_anti_w_4d()."""
    if y + 1 < BOARD_SIDE:
        yield (x, y + 1, z, w)


# ─── Adjacency construction ────────────────────────────────────────────

def build_adjacency_4d(
    target_fn: Callable[[int, int, int, int], Iterator[Coord]],
    directed: bool = False,
) -> csr_matrix:
    """Build a 4096×4096 sparse adjacency matrix from a target generator.

    Undirected (default): for symmetric pieces the generator already
    emits edges both ways under iteration over all start squares, but
    we explicitly symmetrize to be safe.

    Directed: leave as-is; pawn is the only current caller."""
    A = lil_matrix((N_SQUARES, N_SQUARES), dtype=np.int8)
    for s in range(N_SQUARES):
        x, y, z, w = rc4(s)
        for t in target_fn(x, y, z, w):
            A[s, sq4(*t)] = 1
    A = A.tocsr()
    if not directed:
        # Symmetrize in case a generator emits edges asymmetrically
        # near boundaries. Undirected pieces should already be symmetric;
        # this is a belt-and-braces check that does nothing in steady
        # state.
        A = A.maximum(A.T)
    return A


def degree_vector(A: csr_matrix) -> np.ndarray:
    """Row-sum degree as a flat (N_SQUARES,) int array."""
    return np.asarray(A.sum(axis=1)).ravel().astype(np.int64)


def laplacian_4d(A: csr_matrix) -> csr_matrix:
    """Graph Laplacian L = D - A from a (possibly directed) adjacency.
    For symmetric undirected graphs this is the standard combinatorial
    Laplacian; for directed graphs, D uses row sums (out-degree)."""
    deg = degree_vector(A).astype(np.float64)
    D = diags(deg)
    return (D - A.astype(np.float64)).tocsr()


# ---- Path-graph eigenbasis (1D building block for the 4D tensor DCT)

def p8_laplacian() -> np.ndarray:
    """8x8 Laplacian of the path graph P_8. Tridiagonal: -1 on
    super/subdiagonals, degree on the diagonal (1 at endpoints,
    2 interior)."""
    n = BOARD_SIDE
    A = np.zeros((n, n), dtype=np.float64)
    for i in range(n - 1):
        A[i, i + 1] = 1.0
        A[i + 1, i] = 1.0
    D = np.diag(A.sum(axis=1))
    return D - A


def eig_p8() -> Tuple[np.ndarray, np.ndarray]:
    """Return (evecs[8,8], evals[8]) of the P_8 Laplacian, sorted by
    eigenvalue ascending. Eigenvectors form the DCT-II basis. Cheap
    enough (8x8) to recompute on demand — no caching needed."""
    L = p8_laplacian()
    evals, evecs = np.linalg.eigh(L)
    return evecs, evals


def kron_sum4_eigvals(evals_1d: np.ndarray) -> np.ndarray:
    """All 4096 eigenvalues of the 4D grid Laplacian as the Kronecker
    sum `evals_1d[i] + evals_1d[j] + evals_1d[k] + evals_1d[l]`,
    indexed by sq4(i,j,k,l). Matches the C-order ravel of the
    (8,8,8,8) tensor of tensor-product eigenvectors."""
    out = np.empty(N_SQUARES, dtype=np.float64)
    for x in range(BOARD_SIDE):
        for y in range(BOARD_SIDE):
            for z in range(BOARD_SIDE):
                for w in range(BOARD_SIDE):
                    out[sq4(x, y, z, w)] = (
                        evals_1d[x] + evals_1d[y]
                        + evals_1d[z] + evals_1d[w]
                    )
    return out


def tensor_eigvec_4d(evecs_1d: np.ndarray,
                     i: int, j: int, k: int, l: int) -> np.ndarray:
    """Build the 4096-vector `e_i (x) e_j (x) e_k (x) e_l` for the
    4D grid, indexed by sq4. Column `i` of `evecs_1d` is the i-th P_8
    eigenvector."""
    v = np.einsum(
        'a,b,c,d->abcd',
        evecs_1d[:, i], evecs_1d[:, j],
        evecs_1d[:, k], evecs_1d[:, l],
    )
    return v.ravel()


# ─── Phase 1 gate ──────────────────────────────────────────────────────

def _deep_interior_squares() -> List[Coord]:
    """Squares with every coord in 2..5 — far enough from the boundary
    that knight and king reach their maximum interior degree (knight
    needs ≥2 margin in the ±2 axis; king needs ≥1). 4^4 = 256 squares."""
    return [(x, y, z, w)
            for x in range(2, 6) for y in range(2, 6)
            for z in range(2, 6) for w in range(2, 6)]


def verify_phase1(verbose: bool = False, seed: int = 42,
                  n_sample: int = 100) -> List[str]:
    """Phase 1 mobility + connectivity gate. Raises AssertionError on
    any mismatch. Returns a list of human-readable report lines
    describing what was checked."""
    report: List[str] = []
    rng = np.random.default_rng(seed)

    interior = _deep_interior_squares()
    if n_sample > len(interior):
        n_sample = len(interior)
    sample_idx = rng.choice(len(interior), size=n_sample, replace=False)
    sample = [interior[int(i)] for i in sample_idx]

    if verbose:
        report.append(
            f"(verbose) sampled {n_sample} of {len(interior)} deep-interior "
            f"squares with seed={seed}"
        )

    # Rook: degree 28 everywhere (K_8 on each of 4 axes, boundary-invariant).
    A_rook = build_adjacency_4d(rook4_targets)
    deg_rook = degree_vector(A_rook)
    assert np.all(deg_rook == 28), (
        f"rook: expected deg=28 at all {N_SQUARES} squares, "
        f"got min={deg_rook.min()}, max={deg_rook.max()}"
    )
    report.append(
        f"rook:   deg=28 at all {N_SQUARES} squares "
        f"(Oana-Chiru: 28 everywhere) OK"
    )

    # King: deep-interior deg = 3^4 - 1 = 80.
    A_king = build_adjacency_4d(king4_targets)
    deg_king = degree_vector(A_king)
    for (x, y, z, w) in sample:
        s = sq4(x, y, z, w)
        assert deg_king[s] == 80, (
            f"king at {(x, y, z, w)}: expected deg=80, got {deg_king[s]}"
        )
    report.append(
        f"king:   deg=80 at {n_sample} deep-interior squares "
        f"(Oana-Chiru: 80 interior) OK"
    )

    # Knight: deep-interior deg = C(4,2) * 2 * 2 * 2 = 48.
    A_kn = build_adjacency_4d(knight4_targets)
    deg_kn = degree_vector(A_kn)
    for (x, y, z, w) in sample:
        s = sq4(x, y, z, w)
        assert deg_kn[s] == 48, (
            f"knight at {(x, y, z, w)}: expected deg=48, got {deg_kn[s]}"
        )
    report.append(
        f"knight: deg=48 at {n_sample} deep-interior squares "
        f"(Oana-Chiru: 48 interior) OK"
    )

    # Bishop: exactly 2 connected components, split by parity of coord sum.
    A_bi = build_adjacency_4d(bishop4_targets)
    n_comp, labels = connected_components(A_bi, directed=False)
    assert n_comp == 2, f"bishop: expected 2 components, got {n_comp}"
    parity = np.array([sum(rc4(s)) & 1 for s in range(N_SQUARES)])
    matches_parity = np.array_equal(labels, parity) or \
                     np.array_equal(labels, 1 - parity)
    assert matches_parity, (
        "bishop: 2 components but partition does not match coord-sum parity"
    )
    c0 = int((parity == 0).sum())
    c1 = int((parity == 1).sum())
    report.append(
        f"bishop: 2 components ({c0}/{c1} by coord-sum parity) OK"
    )

    # Queen: superset of rook.
    A_q = build_adjacency_4d(queen4_targets)
    deg_q = degree_vector(A_q)
    assert np.all(deg_q >= 28), (
        f"queen: expected deg >= 28 (rook subset), "
        f"got min={deg_q.min()}"
    )
    # Also: queen = rook U bishop ⇒ A_q should equal A_rook.maximum(A_bi).
    A_union = A_rook.maximum(A_bi)
    diff = (A_q != A_union).nnz
    assert diff == 0, (
        f"queen: adjacency does not match rook U bishop "
        f"(differing entries={diff})"
    )
    report.append("queen:  A_queen == A_rook U A_bishop (union identity) OK")

    # Pawn (directed): out-degree 1 for w < 7, 0 for w == 7.
    A_pw = build_adjacency_4d(white_pawn4_targets, directed=True)
    deg_pw = degree_vector(A_pw)
    for s in range(N_SQUARES):
        x, y, z, w = rc4(s)
        expected = 1 if w < BOARD_SIDE - 1 else 0
        assert deg_pw[s] == expected, (
            f"pawn at {(x, y, z, w)}: expected out-deg={expected}, "
            f"got {deg_pw[s]}"
        )
    report.append(
        "pawn:   directed +w push, out-deg=1 for w<7, 0 for w=7 OK"
    )

    return report


# ---- Phase 2 gate -----------------------------------------------------

def verify_phase2(verbose: bool = False, seed: int = 42,
                  n_sample: int = 20, tol: float = 1e-10) -> List[str]:
    """Phase 2 gate: verify the 4D grid Laplacian has eigenvalues equal
    to the Kronecker sum of four copies of the P_8 spectrum, with
    tensor-DCT eigenvectors. We do NOT build the 4096x4096 dense
    eigensystem; instead we check `L_grid @ v = lambda * v` on
    `n_sample` random tensor-product eigenvectors."""
    report: List[str] = []
    rng = np.random.default_rng(seed)

    # 4D grid Laplacian (sparse, 4096x4096)
    A_grid = build_adjacency_4d(grid4_targets)
    L_grid = laplacian_4d(A_grid)

    # P_8 eigenbasis
    evecs, evals = eig_p8()
    report.append(
        "P_8 eigenvalues: [" +
        ", ".join(f"{v:.4f}" for v in evals) + "]"
    )

    # Kronecker-sum spectrum of the 4D grid
    kron_evals = kron_sum4_eigvals(evals)
    report.append(
        f"4D grid spectrum: lambda_min={kron_evals.min():.6f}, "
        f"lambda_max={kron_evals.max():.6f}, "
        f"unique={len(np.unique(np.round(kron_evals, 9)))}"
    )

    # Trace identity: sum of Kronecker eigvals == trace(L_grid) == sum of degrees
    trace_L = float(degree_vector(A_grid).sum())
    trace_sum = float(kron_evals.sum())
    assert abs(trace_L - trace_sum) < 1e-8, (
        f"trace mismatch: trace(L_grid)={trace_L}, "
        f"sum(kronecker)={trace_sum}"
    )
    report.append(
        f"trace identity: trace(L)={trace_L:.1f} == "
        f"sum(kron eigvals) {trace_sum:.6f} OK"
    )

    # Sample random (i,j,k,l) and verify L v = lambda v
    max_err = 0.0
    sample_tuples = []
    for _ in range(n_sample):
        i, j, k, l = (int(rng.integers(0, BOARD_SIDE)) for _ in range(4))
        sample_tuples.append((i, j, k, l))
        v = tensor_eigvec_4d(evecs, i, j, k, l)
        lam = evals[i] + evals[j] + evals[k] + evals[l]
        residual = L_grid @ v - lam * v
        err = float(np.max(np.abs(residual)))
        if err > max_err:
            max_err = err
        assert err < tol, (
            f"eigenvector (i,j,k,l)={(i, j, k, l)}: "
            f"||L v - lambda v||_inf = {err:.3e} > tol={tol:.1e}"
        )

    report.append(
        f"eigvec identity: L v == lambda v for {n_sample} random "
        f"tensor products (max ||r||_inf = {max_err:.2e}, tol={tol:.0e}) OK"
    )

    if verbose:
        report.append("(verbose) sampled tuples: " + str(sample_tuples[:5])
                      + (" ..." if len(sample_tuples) > 5 else ""))

    return report


# ---- B_4 hyperoctahedral group ----------------------------------------
#
# B_4 = (Z_2)^4 >| S_4 acts on Z^4 by signed permutations. |B_4| = 2^4 * 4! = 384.
# A group element g is encoded as a pair (perm, signs):
#   perm:  length-4 tuple, a permutation of (0,1,2,3) telling which input
#          axis maps to which output axis. Convention: (g.x)[perm[i]] = signs[i] * x[i]
#   signs: length-4 tuple of +1 / -1
# Composition: (p2,s2) * (p1,s1) applied to x gives p2(s2 * p1(s1 * x)).
# We carry the action on the centered lattice {-7/2, -5/2, ..., +7/2} (equivalently
# coords 0..7 with reflection w -> 7-w on sign flip) so translations stay on-board.

Perm = Tuple[int, int, int, int]
Signs = Tuple[int, int, int, int]
GroupElem = Tuple[Perm, Signs]


def _b4_identity() -> GroupElem:
    return ((0, 1, 2, 3), (1, 1, 1, 1))


def _b4_generators() -> List[GroupElem]:
    """8 generators: 4 single-axis sign flips + 3 adjacent S_4 transpositions
    (minimal set; 3 adjacent transpositions generate S_4). We include all 4
    adjacent + wrap-around transpositions for redundant coverage, total 7 perm
    generators, but 3 suffice; keep it tight: 4 flips + 3 transpositions = 7.
    With identity appended implicitly via closure we hit all 384."""
    gens: List[GroupElem] = []
    # Sign flips on each axis
    for axis in range(N_DIMS):
        signs = [1, 1, 1, 1]
        signs[axis] = -1
        gens.append(((0, 1, 2, 3), tuple(signs)))  # type: ignore[arg-type]
    # Adjacent transpositions: (0 1), (1 2), (2 3) generate S_4
    for i in range(N_DIMS - 1):
        perm = [0, 1, 2, 3]
        perm[i], perm[i + 1] = perm[i + 1], perm[i]
        gens.append((tuple(perm), (1, 1, 1, 1)))  # type: ignore[arg-type]
    return gens


def _compose(g2: GroupElem, g1: GroupElem) -> GroupElem:
    """Apply g1 first, then g2. In our convention a GroupElem acts on x by
    y[perm[i]] = signs[i] * x[i], equivalently y = P diag(s) x where P is
    the permutation matrix with P[perm[i], i] = 1.

    Composition: let A_k = P_k D_k. Then A_2 A_1 = P_2 D_2 P_1 D_1
    = P_2 (D_2 P_1) D_1. Since D_2 P_1 = P_1 (P_1^{-1} D_2 P_1), and for a
    permutation matrix P P^{-1} D P has entry (i,i) = D[perm(i), perm(i)],
    we get A_2 A_1 = (P_2 P_1) diag(D_1 . permuted_D_2)
    => perm_out[i] = perm2[perm1[i]],
       signs_out[i] = signs1[i] * signs2[perm1[i]]."""
    p2, s2 = g2
    p1, s1 = g1
    perm_out = tuple(p2[p1[i]] for i in range(N_DIMS))
    signs_out = tuple(s1[i] * s2[p1[i]] for i in range(N_DIMS))
    return perm_out, signs_out  # type: ignore[return-value]


def b4_closure(gens: List[GroupElem] | None = None) -> List[GroupElem]:
    """BFS closure over B_4 from the given generators + identity. Returns
    the list of all |B_4| = 384 signed permutations. Order is BFS-deterministic
    (useful for reproducible projector construction)."""
    if gens is None:
        gens = _b4_generators()
    seen = {_b4_identity()}
    order = [_b4_identity()]
    frontier = [_b4_identity()]
    # Fixed upper bound to satisfy JPL-style bounded loop
    for _ in range(10):  # 10 BFS layers is more than enough for |B_4|=384
        if not frontier:
            break
        nxt: List[GroupElem] = []
        for g in frontier:
            for h in gens:
                g_new = _compose(h, g)
                if g_new not in seen:
                    seen.add(g_new)
                    order.append(g_new)
                    nxt.append(g_new)
        frontier = nxt
    return order


def _apply_b4_to_square(g: GroupElem, x: int, y: int, z: int, w: int
                        ) -> Coord:
    """Apply a signed-permutation to a lattice coord, using the centered
    action. Input coords 0..7 map to centered c = coord - 3.5; after flip
    we get 3.5 - coord (reflection). In integer form: sign=+1 leaves coord,
    sign=-1 maps coord -> 7 - coord. Then permute axes."""
    perm, signs = g
    src = (x, y, z, w)
    # Apply signs in input-axis order (reflect in place)
    flipped = tuple((BOARD_SIDE - 1 - src[i]) if signs[i] == -1 else src[i]
                    for i in range(N_DIMS))
    # Permute: output[perm[i]] = flipped[i]
    out = [0, 0, 0, 0]
    for i in range(N_DIMS):
        out[perm[i]] = flipped[i]
    return out[0], out[1], out[2], out[3]


def b4_permutation_matrix(g: GroupElem) -> csr_matrix:
    """Sparse 4096x4096 permutation matrix P_g such that (P_g f)[s] =
    f[g^{-1} . s]. Built by mapping s -> g . s and placing 1 at
    (g.s, s)."""
    rows = np.empty(N_SQUARES, dtype=np.int64)
    cols = np.empty(N_SQUARES, dtype=np.int64)
    for s in range(N_SQUARES):
        x, y, z, w = rc4(s)
        t = sq4(*_apply_b4_to_square(g, x, y, z, w))
        rows[s] = t
        cols[s] = s
    data = np.ones(N_SQUARES, dtype=np.float64)
    return csr_matrix((data, (rows, cols)), shape=(N_SQUARES, N_SQUARES))


def b4_a1_orbit_projector(closure: List[GroupElem] | None = None
                          ) -> csr_matrix:
    """A_1 (trivial-irrep) projector on the 4096-dim lattice signal space:
        P_A1 = (1/|B_4|) sum_{g in B_4} Pi(g)
    Pi is the signed-permutation action; for A_1 we average the full
    permutation action (no sign twist), so (P_A1 f)[s] = mean over the
    B_4-orbit of s. Returns a sparse CSR matrix."""
    if closure is None:
        closure = b4_closure()
    order = len(closure)
    assert order == 384, f"closure size {order} != 384"
    # Compute the orbit labeling: two squares s,t are in the same orbit
    # iff some g in B_4 maps s to t. We just need the orbit partition.
    orbit_of = -np.ones(N_SQUARES, dtype=np.int64)
    orbits: List[List[int]] = []
    for s in range(N_SQUARES):
        if orbit_of[s] >= 0:
            continue
        # Enumerate orbit of s
        x, y, z, w = rc4(s)
        orb_set = set()
        for g in closure:
            orb_set.add(sq4(*_apply_b4_to_square(g, x, y, z, w)))
        orb_id = len(orbits)
        for t in orb_set:
            orbit_of[t] = orb_id
        orbits.append(sorted(orb_set))
    # Build the orbit-averaging projector: P[i,j] = 1/|orbit(i)| if orbit(i)==orbit(j) else 0
    rows: List[int] = []
    cols: List[int] = []
    data: List[float] = []
    for orb in orbits:
        inv = 1.0 / len(orb)
        for i in orb:
            for j in orb:
                rows.append(i)
                cols.append(j)
                data.append(inv)
    P = csr_matrix(
        (np.asarray(data, dtype=np.float64),
         (np.asarray(rows, dtype=np.int64),
          np.asarray(cols, dtype=np.int64))),
        shape=(N_SQUARES, N_SQUARES),
    )
    return P


# ---- Standard 4D representation (closed form) ------------------------

def std4_projector_coords() -> np.ndarray:
    """Projector onto the 4D standard representation of B_4, acting on the
    coordinate channels R^4. Standard rep = orthogonal complement of the
    trivial sum-over-axes vector, so
        P_std = I_4 - (1/4) J_4
    where J_4 is the 4x4 all-ones matrix. Trace = 3 (standard of B_4
    restricted-from-S_4 is 3-dim; with sign flips the direct decomposition
    is slightly different, so we treat `std4` here as the 4-dim defining
    rep minus the trivial axis-sum, which matches the usual bottom-up
    'coordinate residual' channels used in the encoder)."""
    return np.eye(N_DIMS) - np.ones((N_DIMS, N_DIMS)) / N_DIMS


def std4_character(g: GroupElem) -> float:
    """Character chi_std(g) = trace of the signed-permutation 4x4 matrix
    of g, in the defining (coordinate) representation. For the 4D
    'standard' used by the encoder (I-(1/4)J projection), the character
    is the defining-rep trace minus 1 (the trivial axis-sum has trace 1
    on every element). Used only for unit-test character-value checks."""
    perm, signs = g
    # Defining-rep matrix: M[perm[i], i] = signs[i]
    # trace = sum_i M[i, i] = sum over i s.t. perm[i] == i of signs[i]
    return float(sum(signs[i] for i in range(N_DIMS) if perm[i] == i))


# ---- Phase 3 gate ----------------------------------------------------

def verify_phase3(verbose: bool = False, seed: int = 42,
                  tol: float = 1e-12) -> List[str]:
    """Phase 3 gate.

    1. Closure of 7 B_4 generators (4 sign flips + 3 adjacent S_4 trans-
       positions) has exactly 384 elements.
    2. Standard-4D character values match known values of B_4 defining rep
       minus trivial: chi(e)=4, chi(sign-flip on one axis)=2,
       chi(axis transposition)=2.
    3. A_1 orbit projector is idempotent and symmetric, and commutes with
       every group generator (equivalently: it is B_4-invariant).
    4. std4 coordinate projector satisfies P^2 = P, P = P^T, and
       P . (1,1,1,1) = 0."""
    report: List[str] = []

    # 1. Closure size
    gens = _b4_generators()
    closure = b4_closure(gens)
    assert len(closure) == 384, (
        f"|B_4 closure from {len(gens)} generators| = {len(closure)}, "
        f"expected 384"
    )
    report.append(
        f"B_4 closure: {len(gens)} generators -> 384 elements "
        f"(= 2^4 * 4! = 16 * 24) OK"
    )

    # 2. Standard-4D character spot-checks.
    #    defining-rep character = sum of signs at fixed points of perm.
    e = _b4_identity()
    chi_e = std4_character(e)
    assert chi_e == 4, f"chi_std(e) = {chi_e} != 4"

    # Pick the first sign flip (axis 0) and first transposition (0<->1)
    flip0 = gens[0]
    assert flip0 == ((0, 1, 2, 3), (-1, 1, 1, 1)), f"unexpected gen: {flip0}"
    chi_flip = std4_character(flip0)
    # Defining rep: fixed points = all 4 axes, sum of signs = -1+1+1+1 = 2
    assert chi_flip == 2, f"chi_std(flip axis 0) = {chi_flip} != 2"

    transp01 = gens[4]  # first perm gen
    assert transp01 == ((1, 0, 2, 3), (1, 1, 1, 1)), (
        f"unexpected gen: {transp01}"
    )
    chi_tr = std4_character(transp01)
    # Defining rep: fixed points = {2, 3}, signs=(+1,+1), trace = 2
    assert chi_tr == 2, f"chi_std(transp 0<->1) = {chi_tr} != 2"

    report.append(
        "std4 characters: chi(e)=4, chi(sign-flip)=2, chi(transp)=2 "
        "(defining rep of B_4) OK"
    )

    # 3. A_1 orbit projector
    P_a1 = b4_a1_orbit_projector(closure)
    # Idempotence
    PP = P_a1 @ P_a1
    err_idem = float(np.max(np.abs((PP - P_a1).toarray())))
    assert err_idem < tol, (
        f"P_A1^2 != P_A1: max |diff| = {err_idem:.3e} > {tol:.1e}"
    )
    # Symmetry
    err_sym = float(np.max(np.abs((P_a1 - P_a1.T).toarray())))
    assert err_sym < tol, (
        f"P_A1 not symmetric: max |P - P^T| = {err_sym:.3e} > {tol:.1e}"
    )
    # Commutes with generators: Pi(g) P = P Pi(g) = P (for a trivial-irrep
    # projector, P commutes with every group action and Pi(g) P = P).
    rng = np.random.default_rng(seed)
    chk_err = 0.0
    for g in rng.choice(len(closure), size=5, replace=False):
        Pi_g = b4_permutation_matrix(closure[int(g)])
        diff = (Pi_g @ P_a1 - P_a1).toarray()
        chk_err = max(chk_err, float(np.max(np.abs(diff))))
    assert chk_err < tol, (
        f"A_1 projector not B_4-invariant: max |Pi(g) P - P| = "
        f"{chk_err:.3e} > {tol:.1e}"
    )
    # Orbit count (sanity): number of distinct orbits = rank of P_A1
    n_orbits = int(round(np.trace(P_a1.toarray())))
    # Trace of an orbit-average projector equals the number of orbits:
    # each orbit contributes 1/|orb| * |orb| = 1 to the trace.
    report.append(
        f"A_1 projector: P^2=P, P=P^T, Pi(g) P = P over 5 random g; "
        f"rank = #orbits = {n_orbits} OK"
    )

    # 4. std4 coordinate projector
    P_std = std4_projector_coords()
    err = float(np.max(np.abs(P_std @ P_std - P_std)))
    assert err < tol, f"P_std^2 != P_std: {err:.3e}"
    err_sym2 = float(np.max(np.abs(P_std - P_std.T)))
    assert err_sym2 < tol, f"P_std not symmetric: {err_sym2:.3e}"
    ones = np.ones(N_DIMS)
    err_null = float(np.max(np.abs(P_std @ ones)))
    assert err_null < tol, (
        f"P_std . (1,1,1,1) != 0: residual {err_null:.3e}"
    )
    tr = float(np.trace(P_std))
    assert abs(tr - 3.0) < tol, f"trace(P_std) = {tr} != 3"
    report.append(
        "std4 coord projector: P^2=P, P=P^T, P.1=0, trace=3 "
        "(I - (1/4)J on R^4) OK"
    )

    if verbose:
        report.append(
            f"(verbose) closure sample: identity={_b4_identity()}, "
            f"first gen={gens[0]}, last closure elem={closure[-1]}"
        )
        report.append(
            f"(verbose) A_1 projector shape={P_a1.shape}, "
            f"nnz={P_a1.nnz}, #orbits={n_orbits}"
        )

    return report


# ---- 4D fiber bundle (Phase 4) ---------------------------------------
#
# The "fiber" at each square encodes per-piece deviation from the pure
# grid Laplacian. In 2D (see [tables.py]) the bundle is rank 5:
#   3 symmetric fiber subspaces (from SVD of piece Laplacians in the
#       grid eigenbasis),
#   1 pawn antisymmetric fiber (directed pawn push breaks Z_2),
#   1 diagonal deviation (rook-shadow: diag(U^T L_rook U) - lambda_grid
#       is nonzero because the K_8 rook Laplacian does not commute with
#       the P_8 grid Laplacian).
# Phase 4 verifies the same structure survives in 4D and the algebraic
# identities (queen = rook + bishop, pawn antisym lives only on w-axis,
# rook diag-dev nonzero) hold on Z_8^4.

def build_u_tensor_4d(evecs_1d: np.ndarray | None = None) -> np.ndarray:
    """Build the dense 4096x4096 tensor-DCT basis U as a double Kronecker
    product of the 8x8 P_8 eigenvectors. ~128 MB float64. Call on demand;
    caller is responsible for holding the reference and freeing.

    U[sq4(a,b,c,d), sq4(i,j,k,l)] = evecs[a,i] * evecs[b,j] * evecs[c,k]
                                   * evecs[d,l]
    Verified against tensor_eigvec_4d to < 1e-17.
    """
    if evecs_1d is None:
        evecs_1d, _ = eig_p8()
    U_pair = np.kron(evecs_1d, evecs_1d)          # 64x64
    return np.kron(U_pair, U_pair)                # 4096x4096


def _dense_laplacian(target_fn: Callable[[int, int, int, int], Iterator[Coord]],
                     directed: bool = False) -> np.ndarray:
    """Build L_piece as a dense 4096x4096 float64 matrix. Convenience
    helper for Phase 4 transforms where we also multiply by a dense U."""
    A = build_adjacency_4d(target_fn, directed=directed)
    L = laplacian_4d(A)
    return L.toarray().astype(np.float64)


def _axis_anti_8x8() -> np.ndarray:
    """Shared 8x8 antisymmetric axis-push generator: 0.5 * (S_+ - S_+^T)
    where S_+ is the 8x8 +1 shift matrix (boundary-aware: no push from
    index 7). Used as the single-axis 8x8 block lifted to a different
    tensor factor for each pawn axis: w-axis pawns see it as the
    rightmost factor, y-axis pawns as the second factor."""
    S = np.zeros((BOARD_SIDE, BOARD_SIDE), dtype=np.float64)
    for i in range(BOARD_SIDE - 1):
        S[i, i + 1] = 1.0
    return 0.5 * (S - S.T)


def pawn_anti_w_4d() -> np.ndarray:
    """Antisymmetric W-axis pawn adjacency: A_anti = (A_pawn - A_pawn^T)/2.
    Shape (4096, 4096) dense float64. The directed +w pawn push means
    A_pawn = I (x) I (x) I (x) S_+, where S_+ is the 8x8 +1 shift matrix,
    so A_anti = I (x) I (x) I (x) A_w_anti with A_w_anti 8x8 antisymmetric.
    This 'only w mixes' structure is the key Phase 4 algebraic claim."""
    A = build_adjacency_4d(white_pawn4_targets, directed=True).toarray()
    A = A.astype(np.float64)
    return 0.5 * (A - A.T)


def pawn_anti_y_4d() -> np.ndarray:
    """Antisymmetric Y-axis pawn adjacency. Y-axis analog of
    pawn_anti_w_4d: A_pawn_y = I (x) S_+ (x) I (x) I, so
    A_anti_y = I (x) A_y_anti (x) I (x) I with A_y_anti the same 8x8
    antisymmetric generator as A_w_anti but on a different tensor
    factor. Because A_y_anti is antisymmetric, tr(A_y_anti) = 0, which
    combined with tr(A_w_anti) = 0 makes the y- and w-axis pawn
    antisymmetric adjacencies Frobenius-orthogonal by construction (see
    test_pawn_axis_factorization_structural). v1.1.1 feasibility basis."""
    A = build_adjacency_4d(white_pawn4_y_targets, directed=True).toarray()
    A = A.astype(np.float64)
    return 0.5 * (A - A.T)


# Backward-compat alias: the v1.0 encoder and phase-4 gate referenced
# `pawn_anti_4d()`. v1.1.1 splits the pawn antisym channel into two
# axes (W and Y); the legacy name continues to return the W-axis form.
pawn_anti_4d = pawn_anti_w_4d


def w_anti_dct_block() -> np.ndarray:
    """Factored 8x8 W-axis pawn antisymmetric fiber in the DCT basis.

    Since A_anti = I (x) I (x) I (x) A_w_anti with A_w_anti the 8x8
    antisymmetrized +w shift (boundary-aware: no push from w=7), and the
    tensor-DCT basis is U = U_P8 (x) U_P8 (x) U_P8 (x) U_P8, by Kronecker
    product rules

        U^T A_anti U = I (x) I (x) I (x) (U_P8^T A_w_anti U_P8)

    i.e. the 4096x4096 DCT-basis PAWN_ANTI_FIB is block-diagonal over
    (x,y,z) with a single 8x8 block on the w-axis. This function returns
    that block. Storing it instead of the full dense matrix saves 128 MB
    and — because it exactly zeros out the off-w entries that the dense
    form carries at < 1e-8 FP noise — gives the C port a clean parity
    target at 1e-10 tolerance. See encoder_4d.encode_4d channel 8.
    """
    A_w_anti = _axis_anti_8x8()
    U_P8, _ = eig_p8()
    return U_P8.T @ A_w_anti @ U_P8


def y_anti_dct_block() -> np.ndarray:
    """Factored 8x8 Y-axis pawn antisymmetric fiber in the DCT basis.

    Y-axis analog of w_anti_dct_block. The 8x8 generator is identical
    (see _axis_anti_8x8) and U_P8 is shared, so numerically this
    returns the same 8x8 matrix as w_anti_dct_block. The distinction
    between Y- and W-axis pawn channels is WHICH tensor factor the 8x8
    block inhabits in the 4096x4096 DCT-basis form:

        PAWN_ANTI_FIB_w = I (x) I (x) I (x) W_ANTI_DCT   (w-axis, slot 4)
        PAWN_ANTI_FIB_y = I (x) Y_ANTI_DCT (x) I (x) I   (y-axis, slot 2)

    The encoder uses this block to scatter 8 modes per pawn along the
    relevant axis at encode time, rather than materializing the
    128 MB dense DCT-basis matrix. See encoder_4d.encode_4d (v1.1.1)."""
    A_y_anti = _axis_anti_8x8()
    U_P8, _ = eig_p8()
    return U_P8.T @ A_y_anti @ U_P8


def diag_dev_4d(
    U: np.ndarray | None = None,
    evals_1d: np.ndarray | None = None,
) -> np.ndarray:
    """Per-piece diagonal deviation diag(U^T L_piece U) - lambda_grid,
    shape (6, 4096). Row order: [pawn_sym, knight, bishop, rook, queen,
    king]. A piece whose Laplacian commutes with the 4D grid Laplacian
    would produce an all-zero row; rook is the canonical nonzero example
    (its single-axis K_8 structure does not commute with the grid P_8)."""
    if U is None:
        U = build_u_tensor_4d()
    if evals_1d is None:
        _, evals_1d = eig_p8()
    lambda_grid = kron_sum4_eigvals(evals_1d)

    # Pawn symmetric Laplacian: (A + A^T) / 2 of the directed push
    A_pw = build_adjacency_4d(white_pawn4_targets, directed=True).toarray()
    A_pw = A_pw.astype(np.float64)
    A_sym = 0.5 * (A_pw + A_pw.T)
    L_pawn_sym = np.diag(A_sym.sum(axis=1)) - A_sym

    laplacians = [
        ('pawn_sym', L_pawn_sym),
        ('knight',   _dense_laplacian(knight4_targets)),
        ('bishop',   _dense_laplacian(bishop4_targets)),
        ('rook',     _dense_laplacian(rook4_targets)),
        ('queen',    _dense_laplacian(queen4_targets)),
        ('king',     _dense_laplacian(king4_targets)),
    ]
    DIAG_DEV = np.zeros((6, N_SQUARES), dtype=np.float64)
    for idx, (_, L) in enumerate(laplacians):
        # Diagonal of U^T L U without materializing the full transform:
        # (U^T L U)[p, p] = sum_i U[i, p] * (L @ U[:, p])[i]
        LU = L @ U
        diag_p = np.einsum('ij,ij->j', U, LU)
        DIAG_DEV[idx] = diag_p - lambda_grid
    return DIAG_DEV


def fiber_sym_4d(U: np.ndarray | None = None, k_top: int = 3,
                 zero_tol: float = 1e-6,
                 ) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    """Global symmetric fiber basis via SVD of per-piece off-diagonal
    C = U^T L_piece U blocks. Pieces: knight, bishop, rook, queen, king.
    Each piece contributes a flattened upper-triangle vector; the kept
    rows form a matrix that is SVD'd, and the top `k_top` right-singular
    directions form the fiber basis.

    Zero-norm handling. The 4D rook is a Kronecker sum of four K_8
    Laplacians, which is exactly diagonal in the P_8-tensor-DCT basis.
    Its off-diagonal fiber vector is structurally zero up to round-off
    (||C_off||_F ~ 1e-13). Normalizing such a row divides by the round-
    off norm and inflates float64 noise into a spurious unit direction
    that then pollutes the SVD as a phantom rank-4 mode. We therefore
    drop any piece whose off-diagonal norm is below
    `zero_tol * max(||C_off||_F)` before normalization and SVD.

    Returns (sv, fiber_dirs, dropped) where `sv` is the vector of
    singular values (one per KEPT piece), `fiber_dirs` has shape
    (k_top, M) with M = 4096*4095/2, and `dropped` lists the piece
    names whose off-diagonal was treated as structural zero.

    Memory: holds one C_piece at a time (128 MB) plus a 5xM float32
    buffer (~170 MB)."""
    if U is None:
        U = build_u_tensor_4d()
    upper_idx = np.triu_indices(N_SQUARES, k=1)
    m = upper_idx[0].shape[0]  # 4096*4095/2 = 8_382_720
    piece_fns = [
        ('knight', knight4_targets),
        ('bishop', bishop4_targets),
        ('rook',   rook4_targets),
        ('queen',  queen4_targets),
        ('king',   king4_targets),
    ]
    raw_rows: List[Tuple[str, np.ndarray, float]] = []
    raw_norms: List[float] = []
    for name, fn in piece_fns:
        L = _dense_laplacian(fn)
        C = U.T @ L @ U
        np.fill_diagonal(C, 0.0)
        v = C[upper_idx]
        nv = float(np.linalg.norm(v))
        raw_rows.append((name, v, nv))
        raw_norms.append(nv)
        del L, C

    n_max = max(raw_norms) if raw_norms else 0.0
    threshold = zero_tol * n_max
    kept = [(name, v, nv) for name, v, nv in raw_rows if nv > threshold]
    dropped = [name for name, _, nv in raw_rows if nv <= threshold]

    rows = np.zeros((len(kept), m), dtype=np.float32)
    for idx, (_, v, nv) in enumerate(kept):
        rows[idx] = (v / nv).astype(np.float32)
    del raw_rows

    _, s, Vt = np.linalg.svd(rows, full_matrices=False)
    k = min(k_top, Vt.shape[0])
    return s, Vt[:k].astype(np.float32), dropped


# ---- Piece adjacency rows for encoder ---------------------------------
#
# The fiber channels at encode time need, for each occupied (piece,
# square), the adjacency row of that piece at that square. Per piece,
# this is a 4096x4096 sparse binary matrix. Build once, keep CSR.

_PIECE_TARGETS_4D: List[Tuple[str, Callable[[int, int, int, int],
                                            Iterator[Coord]]]] = [
    ('N', knight4_targets),
    ('B', bishop4_targets),
    ('R', rook4_targets),
    ('Q', queen4_targets),
    ('K', king4_targets),
]


def piece_adjacencies_4d() -> List[csr_matrix]:
    """Sparse CSR adjacencies for knight, bishop, rook, queen, king
    (in that order; same order as LOCAL_FIBER_3D_4D's first axis)."""
    return [build_adjacency_4d(fn) for _, fn in _PIECE_TARGETS_4D]


def local_fiber_4d(
    fiber_dirs: np.ndarray | None = None,
    U: np.ndarray | None = None,
    k_top: int = 3,
    dtype: type = np.float32,
    dropped: List[str] | None = None,
) -> np.ndarray:
    """Per-(piece, square) fiber coordinates in the rank-3 cross-piece
    fiber basis. Shape (5, 4096, k_top), mirroring 2D's
    LOCAL_FIBER_3D[piece_idx, square, direction].

    For each piece p and source square s, let A_loc = e_s e_t^T +
    e_t e_s^T summed over the piece's edges from s. The d-th local
    fiber coordinate is the projection of off-diag(U^T A_loc U) onto
    the d-th fiber direction of `fiber_dirs`. By the trace identity,

        fib_d(p, s) = <C_loc_offdiag_uppertri, fiber_dirs[d]>
                    = sum over targets t of K_d[s, t]

    where K_d = U @ F_d_sym @ U^T and F_d_sym reconstructs the d-th
    fiber direction as a (4096, 4096) symmetric zero-diagonal matrix.
    We build K_d once, walk piece edges to accumulate, then discard.

    Pieces dropped from the SVD input (``dropped`` list from
    ``fiber_sym_4d``) are treated as zero in this basis and their rows
    are left zero-filled. This is the structural fact that a piece
    whose global off-diag is zero contributes no shared-structure fiber
    coord — any per-square nonzero is a local artifact of the per-
    square decomposition, not a genuine fiber participation.

    Peak memory: U (128 MB) + one K_d (64 MB float32) at a time.
    Runtime output size: 5 * 4096 * k_top * 4 bytes = ~240 KB.
    """
    if U is None:
        U = build_u_tensor_4d()
    if fiber_dirs is None:
        _, fiber_dirs, dropped = fiber_sym_4d(U=U, k_top=k_top)
    if fiber_dirs.ndim != 2 or fiber_dirs.shape[1] != N_SQUARES * (N_SQUARES - 1) // 2:
        raise ValueError(
            f"fiber_dirs shape {fiber_dirs.shape} is not "
            f"(k_top, {N_SQUARES * (N_SQUARES - 1) // 2})"
        )
    # dropped is reported by fiber_sym_4d as lowercase piece names
    # ('knight', 'bishop', 'rook', 'queen', 'king') while
    # _PIECE_TARGETS_4D iterates over single-char codes ('N','B','R',
    # 'Q','K'). Normalize to chars so the membership test below actually
    # fires; without this, dropped pieces kept nonzero float32 rows full
    # of SVD round-off noise, breaking the 1e-10 C-parity target (the
    # rook-structural-zero analog of the P0 pawn-antisym cleanup).
    _NAME_TO_CHAR = {
        'knight': 'N', 'bishop': 'B', 'rook': 'R', 'queen': 'Q', 'king': 'K',
    }
    dropped_set = {_NAME_TO_CHAR.get(x, x) for x in dropped} if dropped else set()

    upper_idx = np.triu_indices(N_SQUARES, k=1)
    adjacencies = piece_adjacencies_4d()

    n_kept = fiber_dirs.shape[0]
    out = np.zeros((len(adjacencies), N_SQUARES, n_kept), dtype=dtype)

    U_f32 = U.astype(np.float32, copy=False)

    for d in range(n_kept):
        # Reconstruct F_d_sym (symmetric, zero-diagonal) from upper-tri.
        F = np.zeros((N_SQUARES, N_SQUARES), dtype=np.float32)
        F[upper_idx] = fiber_dirs[d]
        F = F + F.T
        # K_d = U @ F @ U^T, signal-space representation of fiber dir d.
        # Done in float32 to keep memory at 64 MB. Precision is ample for
        # encoder use (outputs are float32 anyway).
        K = U_f32 @ F @ U_f32.T
        del F
        # Walk each piece's edges and accumulate per-source-square sums.
        for p_idx, (pchar, _fn) in enumerate(_PIECE_TARGETS_4D):
            if pchar in dropped_set:
                continue  # leave row zero; piece is orthogonal to fiber basis
            A = adjacencies[p_idx]
            # A is CSR; iterate rows to pull (s, targets) without a full
            # dense pass. indptr/indices let us find row s's columns.
            indptr = A.indptr
            indices = A.indices
            for s in range(N_SQUARES):
                start, end = indptr[s], indptr[s + 1]
                if start == end:
                    continue
                targets = indices[start:end]
                out[p_idx, s, d] = K[s, targets].sum()
        del K

    return out

def verify_phase4(verbose: bool = False, tol: float = 1e-10
                  ) -> List[str]:
    """Phase 4 gate.

    1. Adjacency identity: A_queen == A_rook + A_bishop (disjoint support).
    2. Laplacian identity in DCT basis: C_Q == C_R + C_B.
    3. Rook diagonal deviation is finite and has nonzero norm (proves the
       rook Laplacian does NOT commute with the grid Laplacian).
    4. Pawn antisymmetric fiber is block-diagonal over (x,y,z): only the
       w-axis mixes modes. Computed as U^T A_anti U; off-w entries should
       be < 1e-8.
    5. Full 6-piece diag_dev table is finite.
    """
    report: List[str] = []
    U = build_u_tensor_4d()
    _, evals = eig_p8()

    # 1. Adjacency identity
    A_R = build_adjacency_4d(rook4_targets).toarray().astype(np.float64)
    A_B = build_adjacency_4d(bishop4_targets).toarray().astype(np.float64)
    A_Q = build_adjacency_4d(queen4_targets).toarray().astype(np.float64)
    diff_adj = float(np.max(np.abs(A_Q - A_R - A_B)))
    assert diff_adj < tol, (
        f"adjacency: A_Q - A_R - A_B max|.| = {diff_adj:.3e}"
    )
    report.append(
        "adjacency: A_queen == A_rook + A_bishop (disjoint support) OK"
    )

    # 2. Laplacian identity in tensor-DCT basis
    L_R = np.diag(A_R.sum(axis=1)) - A_R
    L_B = np.diag(A_B.sum(axis=1)) - A_B
    L_Q = np.diag(A_Q.sum(axis=1)) - A_Q
    C_R = U.T @ L_R @ U
    C_B = U.T @ L_B @ U
    C_Q = U.T @ L_Q @ U
    diff_L = float(np.max(np.abs(C_Q - C_R - C_B)))
    # Numerical tolerance on 128MB dense matmul is looser than sparse
    assert diff_L < 1e-6, (
        f"DCT-basis identity: C_Q - C_R - C_B max|.| = {diff_L:.3e}"
    )
    report.append(
        f"DCT basis: C_queen == C_rook + C_bishop "
        f"(max |diff| = {diff_L:.3e}, tol=1e-6) OK"
    )

    # 3. Rook diagonal deviation (shadow)
    lambda_grid = kron_sum4_eigvals(evals)
    rook_dd = np.diag(C_R) - lambda_grid
    rook_norm = float(np.linalg.norm(rook_dd))
    assert np.isfinite(rook_norm) and rook_norm > 1.0, (
        f"rook diag-dev norm = {rook_norm} (expected finite > 1)"
    )
    report.append(
        f"rook diag-dev: finite, ||.||_2 = {rook_norm:.4f} (nonzero) OK"
    )

    # 4. Pawn antisymmetric fiber lives only on w-axis
    A_anti = pawn_anti_4d()
    asym_err = float(np.max(np.abs(A_anti + A_anti.T)))
    assert asym_err < tol, (
        f"A_anti not antisymmetric: ||A + A^T||_inf = {asym_err:.3e}"
    )
    C_anti = U.T @ A_anti @ U
    C_tensor = C_anti.reshape(
        BOARD_SIDE, BOARD_SIDE, BOARD_SIDE, BOARD_SIDE,
        BOARD_SIDE, BOARD_SIDE, BOARD_SIDE, BOARD_SIDE,
    )
    # "on-w" mask: (i,j,k) == (i',j',k'); mixing is only over (l, l')
    mask = np.zeros_like(C_tensor, dtype=bool)
    for i in range(BOARD_SIDE):
        for j in range(BOARD_SIDE):
            for k in range(BOARD_SIDE):
                mask[i, j, k, :, i, j, k, :] = True
    off_w_norm = float(np.linalg.norm(C_tensor[~mask]))
    on_w_norm = float(np.linalg.norm(C_tensor[mask]))
    assert off_w_norm < 1e-8, (
        f"pawn antisym has off-w mixing: off-w ||.||_F = {off_w_norm:.3e}"
    )
    assert on_w_norm > 1.0, (
        f"pawn antisym on-w norm = {on_w_norm} (expected > 1)"
    )
    report.append(
        f"pawn antisym: on-w ||.||_F = {on_w_norm:.4f}, "
        f"off-w ||.||_F = {off_w_norm:.3e} < 1e-8 OK"
    )

    # 5. 6-piece diag_dev table
    DIAG_DEV = diag_dev_4d(U=U, evals_1d=evals)
    piece_names = ['pawn_sym', 'knight', 'bishop', 'rook', 'queen', 'king']
    norms = np.linalg.norm(DIAG_DEV, axis=1)
    assert np.all(np.isfinite(norms)), "diag_dev has non-finite entries"
    report.append(
        "diag-dev (6-piece): "
        + ", ".join(f"{n}={v:.2f}" for n, v in zip(piece_names, norms))
        + " OK"
    )

    if verbose:
        report.append(
            f"(verbose) U_tensor dense: shape={U.shape}, "
            f"mem={U.nbytes / 1e6:.1f} MB"
        )
        # Sanity: rook diag_dev (idx 3) should match rook_norm from step 3
        report.append(
            f"(verbose) rook_dd via step 3 = {rook_norm:.4f}, "
            f"via diag_dev_4d row[3] = {norms[3]:.4f}"
        )

    return report


# ---- Phase 5 gate ----------------------------------------------------

def verify_phase5(verbose: bool = False, seed: int = 42) -> List[str]:
    """Phase 5 gate: end-to-end encoder + spectralz v4 round-trip with
    v3 backward-read.

    1. encode_4d on a small synthetic position produces a 45056-float32
       vector (v1.1.1); channel ranges match CHANNELS_4D layout; channel
       energies are finite. Both split pawn axis channels (W + Y) carry
       signal when a Y-axis and a W-axis pawn are both present.
    2. spectralz v4 write->read of 10 random frames is byte-identical
       (encoding + all metadata).
    3. spectralz v3 backward-read still works on a legacy-dim blob.
    4. Unknown-magic file correctly raises in read_header_any.
    """
    import os
    import tempfile
    from chess_spectral import encoder_4d as enc_mod
    from chess_spectral import frame_4d as frm

    report: List[str] = []
    rng = np.random.default_rng(seed)

    # 1. Encoder smoke-test: 5-piece mini-position exercising both pawn
    #    axes (W and Y) plus a rook and a king so A_1, FD_DIAG and both
    #    pawn axis channels all carry signal.
    pos4 = {
        sq4(0, 0, 0, 1): ('P', 'w'),   # white W-axis pawn
        sq4(7, 7, 7, 6): ('p', 'w'),   # black W-axis pawn
        sq4(2, 1, 4, 5): ('P', 'y'),   # white Y-axis pawn
        sq4(3, 3, 3, 3): 'R',          # white rook centered
        sq4(4, 4, 4, 4): 'k',          # black king centered-offset
    }
    v = enc_mod.encode_4d(pos4)
    assert v.shape == (enc_mod.ENCODING_DIM_4D,), (
        f"encoding shape {v.shape} != ({enc_mod.ENCODING_DIM_4D},)"
    )
    assert v.dtype == np.float32, f"encoding dtype {v.dtype} != float32"
    energies = enc_mod.channel_energies_4d(v)
    for name, e in energies.items():
        assert np.isfinite(e), f"channel {name} energy non-finite: {e}"
    # A_1 and at least one mode-space channel should be nonzero
    assert energies["A1"] > 0, "A_1 channel unexpectedly zero"
    assert energies["FD_DIAG"] > 0, "FD diag-dev channel unexpectedly zero"
    assert energies["FA_PAWN_W"] > 0, (
        "FA_PAWN_W channel unexpectedly zero with W-axis pawns present"
    )
    assert energies["FA_PAWN_Y"] > 0, (
        "FA_PAWN_Y channel unexpectedly zero with a Y-axis pawn present"
    )
    fib_sum = sum(energies[n] for n in ("FIB_SYM_1", "FIB_SYM_2", "FIB_SYM_3"))
    assert fib_sum > 0, (
        "fiber-sym channels all zero; non-pawn pieces should drive signal"
    )
    report.append(
        f"encode_4d: shape=({enc_mod.ENCODING_DIM_4D},) float32, energies "
        f"finite; A1={energies['A1']:.2f}, "
        f"FA_W={energies['FA_PAWN_W']:.2f}, "
        f"FA_Y={energies['FA_PAWN_Y']:.2f}, "
        f"FD={energies['FD_DIAG']:.2f}, "
        f"FIB_SYM_sum={fib_sum:.2f} OK"
    )

    # 2. spectralz v4 round-trip
    n_frames = 10
    frames_in: List[frm.Frame4D] = []
    for p in range(n_frames):
        enc = rng.standard_normal(frm.ENCODING_DIM_4D).astype(np.float32)
        from_sq = tuple(int(x) for x in rng.integers(0, 8, size=4))
        to_sq = tuple(int(x) for x in rng.integers(0, 8, size=4))
        promo = int(rng.integers(0, 256))
        flags = int(rng.integers(0, 256))
        frames_in.append(frm.Frame4D(
            encoding=enc, ply=p,
            from_sq=from_sq, to_sq=to_sq,  # type: ignore[arg-type]
            promo=promo, flags=flags,
        ))

    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".spectralz")
    tmp_path = tmp.name
    tmp.close()
    try:
        n_bytes = frm.write_spectralz_v4(tmp_path, frames_in)
        header, frames_out = frm.read_spectralz_v4(tmp_path)
    finally:
        os.remove(tmp_path)

    assert header.magic == frm.SPECTRALZ_MAGIC, (
        f"magic {header.magic!r} != {frm.SPECTRALZ_MAGIC!r}"
    )
    assert header.version == frm.SPECTRALZ_VERSION == 4
    assert header.encoding_dim == frm.ENCODING_DIM_4D
    assert header.frame_bytes == frm.ENCODING_DIM_4D * 4 + frm.FRAME_TAIL_BYTES
    assert header.n_plies == n_frames
    assert header.board_dim_side == 8
    assert header.n_dimensions == 4

    # Frame-by-frame identity
    max_enc_err = 0.0
    for i, (fin, fout) in enumerate(zip(frames_in, frames_out)):
        # float32 round-trip must be bit-exact
        err = float(np.max(np.abs(fin.encoding - fout.encoding)))
        max_enc_err = max(max_enc_err, err)
        assert err == 0.0, f"frame {i}: encoding not bit-exact, max|d|={err}"
        assert fin.ply == fout.ply, f"frame {i} ply mismatch"
        assert fin.from_sq == fout.from_sq, f"frame {i} from_sq mismatch"
        assert fin.to_sq == fout.to_sq, f"frame {i} to_sq mismatch"
        assert fin.promo == fout.promo, f"frame {i} promo mismatch"
        assert fin.flags == fout.flags, f"frame {i} flags mismatch"

    report.append(
        f"spectralz v4 round-trip: {n_frames} frames, "
        f"{n_bytes} bytes written, all metadata + encoding byte-identical "
        f"(max|d|={max_enc_err}) OK"
    )

    # 3. spectralz v3 backward-read: a legacy-dim blob remains readable
    v3_frames: List[frm.Frame4D] = []
    for p in range(3):
        enc = rng.standard_normal(frm.ENCODING_DIM_4D_V3).astype(np.float32)
        v3_frames.append(frm.Frame4D(
            encoding=enc, ply=p,
            from_sq=(0, 0, 0, 0), to_sq=(0, 0, 0, 0),
            promo=0, flags=0,
        ))
    tmp_v3 = tempfile.NamedTemporaryFile(delete=False, suffix=".spectralz")
    tmp_v3.close()
    try:
        frm.write_spectralz_v3(tmp_v3.name, v3_frames)
        with open(tmp_v3.name, "rb") as f:
            hdr_v3, kind = frm.read_header_any(f)
        assert kind == "v3", f"expected kind='v3', got {kind!r}"
        assert hdr_v3.version == frm.SPECTRALZ_VERSION_V3 == 3
        assert hdr_v3.encoding_dim == frm.ENCODING_DIM_4D_V3 == 40960
        _, v3_out = frm.read_spectralz_v3(tmp_v3.name)
        for fin, fout in zip(v3_frames, v3_out):
            assert np.array_equal(fin.encoding, fout.encoding)
    finally:
        os.remove(tmp_v3.name)
    report.append(
        "spectralz v3 backward-read: legacy 40960-dim blob detected as v3 "
        "and decoded byte-identical OK"
    )

    # 4. Unknown magic -> error
    import io
    bad = io.BytesIO(b"\x00" * 256)
    try:
        frm.read_header_any(bad)
        assertion = False
    except ValueError:
        assertion = True
    assert assertion, "read_header_any(garbage) should raise ValueError"
    report.append("read_header_any(garbage bytes) -> ValueError OK")

    if verbose:
        report.append(
            f"(verbose) v4 header size = {frm.HEADER_SIZE}, "
            f"frame_bytes = {header.frame_bytes}, "
            f"total bytes written = {n_bytes}"
        )
        ch_names = [name for name, _ in enc_mod.CHANNELS_4D]
        report.append("(verbose) channel energies: "
                      + ", ".join(f"{n}={energies[n]:.2f}" for n in ch_names))

    return report


# ---- v1.1.1 pawn-axis gate ------------------------------------------

def verify_pawn_axis(verbose: bool = False) -> List[str]:
    """v1.1.1 pawn-axis feasibility gate.

    Confirms that the split of the v1.0 FA_PAWN channel into
    FA_PAWN_W (slot 8) and FA_PAWN_Y (slot 9) is numerically sound:
    the two sub-channels' DCT-basis adjacencies sit on independent
    tensor factors, hence are Frobenius-orthogonal by construction.

    Checks (all via the factored 8x8 Kronecker form, not the 128 MB
    dense U^T A U):
    - W-axis block support: off-w-axis mass < 1e-13
    - Y-axis block support: off-y-axis mass < 1e-13
    - On-axis Frobenius norms agree (same 8x8 generator, different leg)
    - Cross-channel inner product |<C_w, C_y>_F| < 1e-13

    The last line is the v1.1.1 feasibility signal: it follows exactly
    from tr(A_w_anti) = tr(A_y_anti) = 0 via the Kronecker trace
    identity, so any nonzero value here means the independent-tensor-
    factor argument doesn't hold and the channel split is unsafe.
    """
    from scipy.sparse import kron as skron, eye as seye, csr_matrix

    report: List[str] = []
    B = BOARD_SIDE
    I8 = seye(B, format='csr')
    W = csr_matrix(w_anti_dct_block())
    Y = csr_matrix(y_anti_dct_block())

    # W-axis: I (x) I (x) I (x) W    Y-axis: I (x) Y (x) I (x) I
    C_w = skron(skron(skron(I8, I8), I8), W, format='csr')
    C_y = skron(skron(skron(I8, Y), I8), I8, format='csr')

    T_w = C_w.toarray().reshape(B, B, B, B, B, B, B, B)
    T_y = C_y.toarray().reshape(B, B, B, B, B, B, B, B)

    mask_w = np.zeros_like(T_w, dtype=bool)
    for i in range(B):
        for j in range(B):
            for k in range(B):
                mask_w[i, j, k, :, i, j, k, :] = True
    mask_y = np.zeros_like(T_y, dtype=bool)
    for i in range(B):
        for k in range(B):
            for l in range(B):
                mask_y[i, :, k, l, i, :, k, l] = True

    on_w = float(np.linalg.norm(T_w[mask_w]))
    off_w = float(np.linalg.norm(T_w[~mask_w]))
    on_y = float(np.linalg.norm(T_y[mask_y]))
    off_y = float(np.linalg.norm(T_y[~mask_y]))

    assert off_w < 1e-13, (
        f"W-axis pawn antisym leaked off-w energy: {off_w:.3e}"
    )
    assert off_y < 1e-13, (
        f"Y-axis pawn antisym leaked off-y energy: {off_y:.3e}"
    )
    report.append(
        f"W-axis support: on-w-block ||.||_F={on_w:.4f}, off={off_w:.2e} OK"
    )
    report.append(
        f"Y-axis support: on-y-block ||.||_F={on_y:.4f}, off={off_y:.2e} OK"
    )

    assert abs(on_w - on_y) < 1e-10, (
        f"on-axis norms disagree: w={on_w:.10f} y={on_y:.10f}"
    )
    assert on_w > 1.0, f"on-w norm unexpectedly small: {on_w}"
    report.append(
        f"on-axis Frobenius norms agree: |w-y|={abs(on_w - on_y):.2e} "
        f"(< 1e-10) OK"
    )

    inner = float((C_w.multiply(C_y)).sum())
    assert abs(inner) < 1e-13, (
        f"cross-channel <C_anti_w, C_anti_y>_F = {inner:.3e} "
        f"(expected < 1e-13); v1.1.1 feasibility premise fails"
    )
    report.append(
        f"cross-channel <C_w, C_y>_F = {inner:+.3e} "
        f"(< 1e-13; v1.1.1 feasibility signal) OK"
    )

    if verbose:
        report.append(
            f"(verbose) 8x8 W_ANTI_DCT Frobenius = "
            f"{float(np.linalg.norm(w_anti_dct_block())):.6f}"
        )
        report.append(
            f"(verbose) 8x8 Y_ANTI_DCT Frobenius = "
            f"{float(np.linalg.norm(y_anti_dct_block())):.6f}"
        )
        report.append(
            f"(verbose) |W_ANTI_DCT - Y_ANTI_DCT|_max = "
            f"{float(np.max(np.abs(w_anti_dct_block() - y_anti_dct_block()))):.2e}"
        )

    return report
