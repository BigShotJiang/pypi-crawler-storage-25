class DriftgardError(Exception):
    def __init__(self, message: str, status: int = 0, code: str = "unknown"):
        super().__init__(message)
        self.status = status
        self.code = code


class AuthError(DriftgardError):
    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, status=401, code="unauthorized")


class RateLimitError(DriftgardError):
    def __init__(self, message: str = "Rate limit exceeded"):
        super().__init__(message, status=429, code="rate_limited")


class FeatureNotAvailableError(DriftgardError):
    def __init__(self, message: str = "Feature not available on your current plan", tier: str = "unknown"):
        super().__init__(message, status=403, code="feature_not_available")
        self.tier = tier
