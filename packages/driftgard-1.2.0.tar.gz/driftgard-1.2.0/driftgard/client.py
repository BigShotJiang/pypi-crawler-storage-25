import time
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import requests

from .errors import DriftgardError, AuthError, RateLimitError, FeatureNotAvailableError

DEFAULT_BASE_URL = "https://api.driftgard.com"
DEFAULT_TIMEOUT = 30
DEFAULT_MAX_RETRIES = 2
RETRY_DELAY = 0.5


class Driftgard:
    """Driftgard Python SDK — evaluate LLM interactions against your compliance policy."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries

    def evaluate(
        self,
        project_id: str,
        prompt: str,
        response: str,
        model_id: str,
        timestamp: Optional[str] = None,
        experiment_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Evaluate a prompt/response pair against your active control pack."""
        body = {
            "project_id": project_id,
            "prompt": prompt,
            "response": response,
            "model_id": model_id,
            "timestamp": timestamp or datetime.now(timezone.utc).isoformat(),
        }
        if experiment_id:
            body["experiment_id"] = experiment_id
        return self._post("/audit/evaluate", body)

    def _post(self, path: str, body: Dict[str, Any], attempt: int = 0) -> Dict[str, Any]:
        url = f"{self._base_url}{path}"
        headers = {
            "Content-Type": "application/json",
            "x-api-key": self._api_key,
        }

        try:
            res = requests.post(url, json=body, headers=headers, timeout=self._timeout)
        except requests.exceptions.RequestException as e:
            if attempt < self._max_retries:
                time.sleep(RETRY_DELAY * (2 ** attempt))
                return self._post(path, body, attempt + 1)
            raise DriftgardError(str(e), status=0, code="network_error")

        if res.status_code == 401:
            raise AuthError()
        if res.status_code == 429:
            raise RateLimitError()

        if res.status_code == 403:
            payload = res.json() if res.headers.get("content-type", "").startswith("application/json") else {}
            if payload.get("error") == "feature_not_available":
                raise FeatureNotAvailableError(payload.get("message", ""), payload.get("tier", "unknown"))
            raise DriftgardError(payload.get("message", "Forbidden"), status=403, code="forbidden")

        if res.status_code >= 500 and attempt < self._max_retries:
            time.sleep(RETRY_DELAY * (2 ** attempt))
            return self._post(path, body, attempt + 1)

        payload = res.json() if res.headers.get("content-type", "").startswith("application/json") else {}

        if not res.ok:
            raise DriftgardError(
                payload.get("message") or payload.get("error") or "Request failed",
                status=res.status_code,
                code=payload.get("error", "unknown"),
            )

        return payload
