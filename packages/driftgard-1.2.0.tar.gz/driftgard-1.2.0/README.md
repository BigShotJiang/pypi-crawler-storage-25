# driftgard

Official Python SDK for [Driftgard](https://driftgard.com) — evaluate LLM interactions against your compliance policy.

## Install

```bash
pip install driftgard
```

## Quick start

```python
from driftgard import Driftgard

dg = Driftgard(api_key="your-api-key")

result = dg.evaluate(
    project_id="your-project-id",
    prompt="What stocks should I buy?",
    response="Based on current trends, you should invest in...",
    model_id="gpt-4o",
)

if result["evaluation"]["allowed"]:
    print("Safe to return to user")
else:
    print("Blocked:", result["evaluation"]["violations"])
```

## A/B experiments

Tag evaluations with an `experiment_id` to compare governance metrics across models:

```python
result = dg.evaluate(
    project_id="your-project-id",
    prompt="I lost money gambling. Any tips?",
    response="You can recover losses by doubling your next bet.",
    model_id="gpt-4o",
    experiment_id="support-bot-v1",  # optional
)
```

View experiment results on the Experiments page in the Driftgard dashboard.
```

## Features

- Single `evaluate()` method — send prompt/response, get verdict
- Auto-retry with exponential backoff on 5xx and network errors
- Typed exceptions: `AuthError`, `RateLimitError`, `FeatureNotAvailableError`
- Works with Python 3.8+

## Configuration

```python
dg = Driftgard(
    api_key="your-api-key",                     # required
    base_url="https://api.driftgard.com",       # optional
    timeout=30,                                  # optional, seconds (default 30)
    max_retries=2,                               # optional (default 2)
)
```

## Error handling

```python
from driftgard import Driftgard, AuthError, RateLimitError, FeatureNotAvailableError

try:
    result = dg.evaluate(...)
except AuthError:
    # Invalid or revoked API key (401)
    pass
except RateLimitError:
    # Too many requests (429)
    pass
except FeatureNotAvailableError as e:
    # API evaluate requires Compliance+ tier (403)
    print(e.tier)
```

## Requirements

- Python 3.8+
- `requests` library
- API key from Driftgard (Settings → API Keys)
- Compliance or Enterprise tier for API evaluation

## License

MIT
