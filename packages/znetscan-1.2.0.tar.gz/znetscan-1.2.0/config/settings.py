"""
Configurações globais do scanner
"""

class ScannerConfig:
    """Configurações do scanner"""
    
    # Configurações de rede
    DEFAULT_NETWORK = "192.168.1.0/24"
    TIMEOUT = 2  # segundos
    MAX_THREADS = 100
    
    # Configurações de scan
    SCAN_METHODS = ['arp', 'ping']
    PING_COUNT = 1
    PING_WAIT = 1  # segundos
    
    # Formatação
    TABLE_STYLE = 'rounded'  # 'simple', 'rounded', 'markdown'
    
    # Exportação
    EXPORT_FORMATS = ['json', 'csv', 'txt']
    
    # Logging
    LOG_LEVEL = 'INFO'
    SAVE_LOGS = True

# Database de fabricantes (OUI)
OUI_DATABASE = {
    '00:00:0C': 'Cisco',
    '00:01:42': 'Juniper',
    '00:03:93': 'Apple',
    '00:04:75': 'Google',
    '00:05:5E': 'Samsung',
    '00:06:25': 'Nintendo',
    '00:08:22': 'IBM',
    '00:0A:95': 'Sony',
    '00:0C:29': 'VMware',
    '00:14:22': 'Dell',
    '00:16:CB': 'HP',
    '00:1A:6B': 'Microsoft',
    '00:1E:67': 'Intel',
    '00:21:5A': 'Nokia',
    '00:23:12': 'Amazon',
    '00:25:9C': 'Facebook',
    '00:50:56': 'VMware',
    '08:00:27': 'VirtualBox',
    '28:D2:44': 'TP-Link',
    '50:E5:49': 'Aruba',
    '70:1C:E7': 'Ubiquiti',
    'B8:27:EB': 'Raspberry Pi',
    'DC:A6:32': 'Intel',
    'E0:D5:5E': 'Espressif',  # ESP8266/ESP32
}