from waitress import serve
import subprocess
import argparse
import sys
import os

def main():
  parser = argparse.ArgumentParser()
  parser.add_argument("command", default=None, nargs="?")
  args = parser.parse_args()
  
  if args.command is None:
    print("Quokko is a nice little search engine and web crawler framework. See more here: https://codeberg.org/splot-dev/quokko")
    sys.exit()
  
  if args.command == "crawl":
    
    try:
      print("🌐 Crawling the Internet!")
      from ..crawler.crawler import QuokkoBot
      
      user_agent = os.environ.get("QUOKKO_CRAWL_USER_AGENT", "QuokkoBot/1.0 (an instance of QuokkoBot; find source code at https://codeberg.org/splot-dev/quokko)")
      seed = os.environ.get("QUOKKO_CRAWL_SEED_URL", "https://news.ycombinator.com")
      regex = os.environ.get("QUOKKO_CRAWL_REGEX_FILTER", "https://.{1,32}")
      db_file = os.environ.get("QUOKKO_CRAWL_DB_FILE", None)
      snapshot_db_file = os.environ.get("QUOKKO_CRAWL_SNAPSHOT_DB_FILE", None)
      no_crawl = os.environ.get("QUOKKO_CRAWL_NO_CRAWL", None)
      
      if not no_crawl:
        no_crawl = [
          "linkedin.com", 
          "google.com", 
          "bbc.com", 
          "reddit.com", 
          "nytimes.com", 
          "instagram.com",
          "facebook.com",
          "whatsapp.com",
          "yahoo.com",
          "bing.com",
          "github.com",
          "duckduckgo.com",
          "quora.com"
        ]
      else:
        no_crawl = no_crawl.split()
      
      if db_file is None:
        print("QUOKKO_CRAWL_DB_FILE is an environment variable that is required, and does not currently exist.")
        sys.exit()
        
      if snapshot_db_file is None:
        print("QUOKKO_CRAWL_SNAPSHOT_DB_FILE is an environment variable that is required, and does not currently exist.")
        sys.exit()
      
      qb = QuokkoBot(user_agent, db_file, snapshot_db_file, seed, regex)
      qb.crawl(log=True, no_crawl=no_crawl)
      
    except KeyboardInterrupt:
      sys.exit()
    except OSError as e:
      print(f"An operating system related issue happened while crawling:\n{e}")
      sys.exit()
    except Exception as e:
      print(f"Something unexpected happened while crawling:\n{e}")
      sys.exit()
    
  elif args.command == "webapp":
    host = os.environ.get("QUOKKO_WEBAPP_HOST", "127.0.0.1")
    port = os.environ.get("QUOKKO_WEBAPP_PORT", "8080")
    log_name = os.environ.get("QUOKKO_WEBAPP_LOG_FILE", None)
    db_search_file = os.environ.get("QUOKKO_WEBAPP_SNAPSHOT_DB_FILE", None)
    if log_name is None:
      print("QUOKKO_WEBAPP_LOG_FILE is an environment variable that is required, and does not currently exist.")
      sys.exit()
    if db_search_file is None:
      print("QUOKKO_WEBAPP_SNAPSHOT_DB_FILE is an environment variable that is required, and does not currently exist.")
      sys.exit()
    
    try:
      from ..interface.main import app
      print("✅ Serving on:")
      print(f"Host: {host}, Port: {port}")
      print("🚀 Blast off!")
      serve(app, host=host, port=int(port))
      sys.exit()
    except KeyboardInterrupt:
      sys.exit()
    except OSError as e:
      print(f"An operating system related issue happened running webapp:\n{e}")
      sys.exit()
    except Exception as e:
      print(f"Something unexpected happened while running webapp:\n{e}")
      sys.exit()

  else:
    print("Invalid command.")
    sys.exit()

if __name__ == "__main__":
  main()