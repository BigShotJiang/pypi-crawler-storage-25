# QuokkoBot
# by splot.dev

# Notes:
  # This is a single threaded web scraper.
  # Attempts to follow Robots Exclusion Protocol (RFC 9309).
  # All dates are stored as Unix time.

from urllib.parse import urlsplit, urljoin
from bs4 import BeautifulSoup
import urllib.robotparser
from pathlib import Path
import tldextract
import traceback
import requests
import sqlite3
import random
import time
import uuid
import re
import os

class QuokkoBot:
  
  def __init__(self, user_agent: str, db_file: str, snapshot_db_file: str, seed: str, regex=r"[\S]+"):
    
    if not isinstance(regex, str):
      raise TypeError("Cannot have regex argument as non-string.")
      
    self.user_agent = user_agent
    self.db_file = Path("/") / db_file
    self.snapshot_db_file = Path("/") / snapshot_db_file
    self.seed = seed
    self.regex = regex

    if self.db_file.is_dir():
      raise RuntimeError("The provided database path is a directory, and a file is required.")

    if self.snapshot_db_file.is_dir():
      raise RuntimeError("The provided snapshot database path is a directory, and a file is required.")
      
  def _scrape(self, blocked: list, cur):
    """
    Scrapes page.
    
    Process:
    Add seed to database if database is empty.
    Find a page in the pages database.
    If it has been scraped in the interval, return failure.
    If its not an HTTPS URL, end.
    If the limits data needs an update, scrape the robots.txt and update the database. 
    If the robots.txt file does not allow for fetching to the URL, end.
    If the next allowed scrape date from a URL in the netloc has not been reached, wait until it is.
    Send a request to the URL, and reset the next allowed scrape date.
    Respect meta tags like nofollow or noindex.
    Based on the request data, add to the pages database.
    Find all HTTPS URLs in request data, add the new ones in that match the regex.
    Return with success.

    The 'end' command in this documentation means that the page will be marked as scraped in the database; it will be dealt with later. Then, it returns.
    
    This function returns a (True/False, more information, link) tuple.
    """

    SCRAPE_UPDATE_INTERVAL = 60 * 60 * 24 * 7 * 2
    DEFAULT_REQ_PER_SEC = (1, 3)
    DEFAULT_CRAWL_DELAY = 1

    # Add seed to database if database is empty.
    page_count_sql = cur.execute("""
    SELECT COUNT(*) FROM pages
    """)

    if page_count_sql.fetchone()[0] == 0:
      cur.execute("""
      INSERT INTO pages (url, description, date_scraped)
      VALUES(?, ?, ?);
      """, (self.seed, "", 0.0))

    # Find a page in the pages database.
    page_dice = random.randint(1, 4)
    if page_dice == 1:
      chosen_page_sql = cur.execute("""
      SELECT url, date_scraped FROM pages ORDER BY date_scraped ASC LIMIT 1;
      """)
      chosen_page_data = chosen_page_sql.fetchone()
    elif page_dice == 2:
      chosen_page_sql = cur.execute("""
      SELECT url, date_scraped FROM pages ORDER BY RANDOM() LIMIT 1;
      """)
      chosen_page_data = chosen_page_sql.fetchone()
    elif page_dice == 3 or page_dice == 4:
      chosen_page_sql = cur.execute("""
      SELECT url, date_scraped FROM pages WHERE date_scraped = 0 LIMIT 1;
      """)
      chosen_page_data = chosen_page_sql.fetchone()
      if chosen_page_data is None:
        chosen_page_sql = cur.execute("""
        SELECT url, date_scraped FROM pages ORDER BY RANDOM() LIMIT 1;
        """)
        chosen_page_data = chosen_page_sql.fetchone()
    
    assert chosen_page_data is not None

    chosen_page_urlsplit = urlsplit(chosen_page_data[0])
    ext = tldextract.extract(chosen_page_data[0])

    if (not chosen_page_urlsplit.hostname) or (not chosen_page_urlsplit.netloc) or (not ext.top_domain_under_public_suffix):
      cur.execute("UPDATE pages SET date_scraped = ? WHERE url = ?;", (time.time(), chosen_page_data[0]))
      return (False, f"This URL is invalid.", chosen_page_data[0])
    
    if ext.top_domain_under_public_suffix in blocked:
      cur.execute("UPDATE pages SET date_scraped = ? WHERE url = ?;", (time.time(), chosen_page_data[0]))
      return (False, f"This URL was blocked by the user.", chosen_page_data[0])

    # If it has been scraped in the interval, return failure.
    if chosen_page_data[1] + SCRAPE_UPDATE_INTERVAL > time.time():
      return (False, f"No need to re-scrape yet. You have not reached the update Unix time { chosen_page_data[1] + SCRAPE_UPDATE_INTERVAL }.", chosen_page_data[0])

    # If its not an HTTPS URL, end
    if chosen_page_urlsplit.scheme != "https":
      cur.execute("UPDATE pages SET date_scraped = ? WHERE url = ?;", (time.time(), chosen_page_data[0]))
      return (False, "Non-HTTPS URLS cannot be scraped.", chosen_page_data[0])

    # If the limits data needs an update, scrape the robots.txt and update the database.
    rp1 = urllib.robotparser.RobotFileParser()
    
    next_db_update_sql = cur.execute("""
    SELECT next_db_update FROM limits WHERE netloc=?;
    """, (chosen_page_urlsplit.netloc,))
    next_db_update_data = next_db_update_sql.fetchone()

    update = False
    if next_db_update_data is None:
      update = True
    else:
      if time.time() >= next_db_update_data[0]:
        update = True
        
    if update:
      try:
        robots_txt_response = requests.get(f"https://{chosen_page_urlsplit.netloc}/robots.txt", headers={"User-Agent": self.user_agent}, timeout=5)
      except Exception as e:
        cur.execute("UPDATE pages SET date_scraped = ? WHERE url = ?;", (time.time(), chosen_page_data[0]))
        return (False, f"Robots.txt could not be fetched: {e}", chosen_page_data[0])

      if robots_txt_response.status_code == 404:
        scraping_interval = DEFAULT_REQ_PER_SEC[1] / DEFAULT_REQ_PER_SEC[0] + DEFAULT_CRAWL_DELAY
        cur.execute("""
        INSERT INTO limits(netloc, file, scraping_interval, next_scrape, next_db_update)
        VALUES(?, ?, ?, ?, ?)
        ON CONFLICT(netloc)
        DO
          UPDATE SET file = excluded.file,
          scraping_interval = excluded.scraping_interval,
          next_scrape = excluded.next_scrape,
          next_db_update = excluded.next_db_update;
        """, (chosen_page_urlsplit.netloc, "", scraping_interval, time.time()+scraping_interval, time.time()+(60*60*24)))
      else:
        if not (200 <= robots_txt_response.status_code <= 299):
          cur.execute("UPDATE pages SET date_scraped = ? WHERE url = ?;", (time.time(), chosen_page_data[0]))
          return (False, f"Robots.txt returns bad code: {robots_txt_response.status_code}", chosen_page_data[0])

        if len(robots_txt_response.text) > 512000:
          cur.execute("UPDATE pages SET date_scraped = ? WHERE url = ?;", (time.time(), chosen_page_data[0]))
          return (False, f"Robots.txt is too large.", chosen_page_data[0])
          
        req_per_sec = list(DEFAULT_REQ_PER_SEC)
        
        rp1.parse(robots_txt_response.text.splitlines())
        
        crawl_delay = rp1.crawl_delay(self.user_agent)
        if crawl_delay is None:
          crawl_delay = DEFAULT_CRAWL_DELAY
        
        rrate = rp1.request_rate(self.user_agent)
        if rrate:
          if rrate.requests > 0:
            req_per_sec[0] = rrate.requests
          if rrate.seconds > 0:
            req_per_sec[1] = rrate.seconds
          
        scraping_interval = (req_per_sec[1] / req_per_sec[0]) + crawl_delay
        
        cur.execute("""
        INSERT INTO limits(netloc, file, scraping_interval, next_scrape, next_db_update)
        VALUES(?, ?, ?, ?, ?)
        ON CONFLICT(netloc)
        DO
          UPDATE SET file = excluded.file,
          scraping_interval = excluded.scraping_interval,
          next_scrape = excluded.next_scrape,
          next_db_update = excluded.next_db_update;
        """, (chosen_page_urlsplit.netloc, robots_txt_response.text, scraping_interval, time.time()+scraping_interval, time.time()+(60*60*24)))

    # If the robots.txt file does not allow for fetching to the URL, end.
    url_limits_sql = cur.execute("""
    SELECT next_scrape, file FROM limits WHERE netloc=?;
    """, (chosen_page_urlsplit.netloc,))
    url_limits_data = url_limits_sql.fetchone()

    assert url_limits_data is not None
    
    rp2 = urllib.robotparser.RobotFileParser()
    rp2.parse(url_limits_data[1].splitlines())
    if not rp2.can_fetch(self.user_agent, chosen_page_data[0]):
      cur.execute("UPDATE pages SET date_scraped = ? WHERE url = ?;", (time.time(), chosen_page_data[0]))
      return (False, "Robots.txt does not allow fetching here.", chosen_page_data[0])
    
    # If the next allowed scrape date from a URL in the netloc has not been reached, wait until it is.
    if time.time() < url_limits_data[0]:
      time_difference = url_limits_data[0] - time.time()
      if time_difference > 35:
        cur.execute("UPDATE pages SET date_scraped = ? WHERE url = ?;", (time.time(), chosen_page_data[0]))
        return (False, "Cannot wait that long to comply for robots.txt; try again later.", chosen_page_data[0])
      time.sleep(time_difference)

    # Send a request to the URL, and reset the next allowed scrape date.
    try:
      url_response = requests.get(chosen_page_data[0], headers={"User-Agent": self.user_agent}, timeout=5)
      if len(url_response.text) > 7e+6:
        raise RuntimeError("URL response text is way too large.")
    except Exception as e:
      cur.execute("UPDATE pages SET date_scraped = ? WHERE url = ?;", (time.time(), chosen_page_data[0]))
      return (False, f"Could not fetch page due to network errors: {e}", chosen_page_data[0])
    finally: 
      cur.execute("""
      UPDATE limits
      SET next_scrape = ? + scraping_interval
      WHERE netloc = ?;
      """, (time.time(), chosen_page_urlsplit.netloc))

    if not (200 <= url_response.status_code <= 299):
      cur.execute("UPDATE pages SET date_scraped = ? WHERE url = ?;", (time.time(), chosen_page_data[0]))
      return (False, f"Could not fetch page due to errors: {url_response.text[:200]}", chosen_page_data[0])

    if "text/html" not in url_response.headers.get("Content-Type", ""):
      cur.execute("UPDATE pages SET date_scraped = ? WHERE url = ?;", (time.time(), chosen_page_data[0]))
      return (False, f"Cannot parse non-html file.", chosen_page_data[0])

    # Respect meta tags like nofollow or noindex.
    robots_meta_tag_soup = BeautifulSoup(url_response.text, "html.parser")
    robots_meta_tag = robots_meta_tag_soup.find("meta", attrs={"name": "robots"})
    if robots_meta_tag is not None:
      if robots_meta_tag.get("content", None) in ["noindex", "nofollow", "none", "nosnippet"]:
        cur.execute("UPDATE pages SET date_scraped = ? WHERE url = ?;", (time.time(), chosen_page_data[0]))
        return (False, f"Cannot crawl a site that does not allow for indexing, following and/or displaying it's data through meta tags.", chosen_page_data[0])
      
    # Based on the request data, add to the pages database.
    soup = BeautifulSoup(url_response.text, "html.parser")
    meta_desc = soup.find("meta", attrs={"name": "description"})
    if meta_desc is None:
      meta_desc = ""
    else:
      meta_desc = meta_desc.get("content", False)
    title_desc = soup.title
    if title_desc is None:
      title_desc = ""
    else:
      title_desc = title_desc.string
      if title_desc is None:
        title_desc = ""

    if meta_desc:
      desc = meta_desc
    else:
      if title_desc:
        desc = title_desc
      else:
        desc = ""

    if desc is None:
      desc = ""
    
    desc = desc[:200]

    cur.execute("""
    INSERT INTO pages(url, description, date_scraped)
      VALUES(?, ?, ?)
      ON CONFLICT(url)
      DO
        UPDATE SET description = excluded.description,
        date_scraped = excluded.date_scraped;
    """, (chosen_page_data[0], desc, time.time()))
    
    # Find all HTTPS URLs in request data, add the new ones in that match the regex.
    
    # nevermind, don't do this: found_urls = re.findall(r"https:\/\/[a-zA-Z0-9_~:#@!$&',;=\.\-\(\)\*\+\[\]\/\?]+", url_response.text)
    found_urls = []
    found_netlocs = []
    
    a_tags = soup.find_all("a")
    random.shuffle(a_tags)
    for a_tag in a_tags:
      a_tag_href = a_tag.get("href", "")
      if a_tag_href:
        try:
          parsed_found_a_tag_href = urlsplit(urljoin(chosen_page_data[0], a_tag_href))
        except:
          continue
        if parsed_found_a_tag_href.scheme != "https" and parsed_found_a_tag_href.scheme != "":
          continue
        
      joined_a_tag_href = urljoin(chosen_page_data[0], a_tag_href)
      if joined_a_tag_href not in found_urls:
        joined_a_tag_href_urlsplit = urlsplit(joined_a_tag_href)
        if found_netlocs.count(joined_a_tag_href_urlsplit.netloc) > 3: # too much of one link is bad
          continue
        found_urls.append(joined_a_tag_href)
        found_netlocs.append(joined_a_tag_href_urlsplit.netloc)
    
    safe_found_urls = []
    for found_url in found_urls:
      parsed_found_url = urlsplit(found_url)
      if parsed_found_url.netloc and len(found_url) < 500:
        safe_found_urls.append(parsed_found_url._replace(fragment="").geturl())

    for safe_found_url in safe_found_urls:
      if re.fullmatch(self.regex, safe_found_url):
        
        num_count = 0
        for char in safe_found_url:
          if char.isdigit():
            num_count += 1

        if num_count <= 2:
          cur.execute("""
          INSERT INTO pages(url, description, date_scraped)
          VALUES(?, ?, ?)
          ON CONFLICT(url)
          DO NOTHING;
          """, (safe_found_url.rstrip("/"), "", 0))
        
    # End with success.
    return (True, "", chosen_page_data[0])
    
  def crawl(self, log=False, seconds=None, no_crawl=[]):
    try:
      with sqlite3.connect(self.db_file, timeout=7) as con:
        cur = con.cursor()
        con.isolation_level = "EXCLUSIVE"
        
        cur.execute("""
        CREATE TABLE IF NOT EXISTS pages (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          url TEXT UNIQUE,
          description TEXT,
          date_scraped FLOAT -- if it is 0, that means it has not been scraped yet
        );
        """)
  
        cur.execute("""
        CREATE TABLE IF NOT EXISTS limits (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          netloc TEXT UNIQUE,
          
          file TEXT, -- only use for seeing which pages allow for scraping
          scraping_interval FLOAT, -- seconds / GCD(requests, seconds) + crawl_delay
          next_scrape FLOAT, -- time + scraping_interval
          
          next_db_update FLOAT -- every 24h
        );
        """)
  
        cur.execute("""
        CREATE VIRTUAL TABLE IF NOT EXISTS _search USING fts5(url, description, date_scraped);
        """)
  
        cur.execute("""
        CREATE TRIGGER IF NOT EXISTS db_insert 
           AFTER INSERT
           ON pages
        BEGIN
           INSERT INTO _search (url, description, date_scraped)
           VALUES (NEW.url, NEW.description, NEW.date_scraped);
        END;
        """)
  
        cur.execute("""
        CREATE TRIGGER IF NOT EXISTS db_update
           AFTER UPDATE
           ON pages
        BEGIN
           UPDATE _search
           SET url = NEW.url,
           description = NEW.description,
           date_scraped = NEW.date_scraped
           WHERE url=OLD.url;
        END;
        """)
  
        cur.execute("""
        CREATE TRIGGER IF NOT EXISTS db_delete 
           AFTER DELETE
           ON pages
        BEGIN
           DELETE FROM _search
           WHERE url=OLD.url;
        END;
        """)
        
        seconds_good = (seconds == None) or isinstance(seconds, float) or isinstance(seconds, int)
        log_good = (log == True) or (log == False)
        no_crawl_good = isinstance(no_crawl, list)
    
        if not(seconds_good and log_good and no_crawl_good):
          raise TypeError("One of arguments do not match logical type.")
        
        start_time = time.time()
        next_snapshot = time.time() + 900
        first_iter = True
        
        while True:
          scraped_result = self._scrape(blocked=no_crawl, cur=cur)
          if log:
            if scraped_result[0] is True:
              print(f"Successful crawl ({scraped_result[2]}).")
            else:
              print(f"\tUnsuccessful crawl ({scraped_result[2]}): {scraped_result[1]}")

          con.commit()
          
          if scraped_result[0] is False:
            time.sleep(1)
            
          if seconds is not None:
            if start_time + seconds <= time.time():
              if log:
                print("Crawling ended.")
              break
  
          if time.time() >= next_snapshot or first_iter:
            temp_file_name = str(self.snapshot_db_file) + str(uuid.uuid4()) + ".tmp"
            cur.execute("VACUUM INTO ?;", (temp_file_name,))
            os.replace(temp_file_name, str(self.snapshot_db_file))
            next_snapshot = time.time() + 900
            
          first_iter = False
            
    except Exception as e:
      raise RuntimeError(f"FULL TRACEBACK:\n {traceback.format_exc()}")
    except KeyboardInterrupt:
      pass
    except OSError as e:
      raise RuntimeError(f"FULL TRACEBACK:\n {traceback.format_exc()}")
    finally:
      temp_file_name = str(self.snapshot_db_file) + str(uuid.uuid4()) + ".tmp"
      cur.execute("VACUUM INTO ?;", (temp_file_name,))
      os.replace(temp_file_name, str(self.snapshot_db_file))