# Ozekai GPU CLI

Attach to your Ozekai GPU machines from the terminal.

## Install

```bash
pip install ozekai
```

Requires Python 3.10+ and SSH client installed.

## Commands

### `connect-gpu`

Attach to an existing GPU session that is already running.

```bash
connect-gpu --name training
```

Options:
- `--name` (required) — VM name (e.g. `training`, `inference`)

JupyterLab auto-starts at `http://localhost:8888`.

> Session start, stop, and terminate are web-dashboard-only operations. Use the dashboard to deploy/stop/terminate VMs.

## Configuration

| Variable | Default | Description |
|---|---|---|
| `OZEKAI_API_URL` | `https://ozekai.com` | Backend API URL |
| `OZEKAI_SSH_USER` | `$USER` | SSH username |

## Links

- [Getting Started](https://ozekai.com/getting-started.html)
- [Help & Reference](https://ozekai.com/help.html)
- [Support](mailto:ozekai.support@gmail.com)
