import click
from .commands.connect import connect_command

# ── User-facing standalone entry points ─────────────────────────

@click.command()
@click.option("--name", required=True, help="VM name (e.g. 'training', 'inference')")
def connect_gpu(name):
    """Bind to an already-running GPU session"""
    connect_command(vm_name=name)
