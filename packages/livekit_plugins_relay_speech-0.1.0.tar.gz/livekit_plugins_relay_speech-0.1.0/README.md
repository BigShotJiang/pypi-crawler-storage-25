# livekit-plugins-relay-speech

LiveKit Agents plugin for Relay Speech — universal TTS adapter with sentence-level caching.
