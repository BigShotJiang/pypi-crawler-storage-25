# Copyright 2025 LiveKit, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
LiveKit Agents plugin for Relay Speech.

Relay Speech is a universal TTS adapter that routes synthesis requests through
Cartesia, ElevenLabs, Sarvam, and other providers behind a single API,
with built-in sentence-level LRU caching.

Usage::

    from livekit.plugins import relay_speech

    session = AgentSession(
        tts=relay_speech.TTS(
            base_url="http://localhost:8000",
            provider="cartesia",
            voice_id="YOUR_VOICE_ID",
            model="sonic-3",
            language="en",
            api_key="YOUR_CARTESIA_KEY",
            relay_speech_api_key="YOUR_RELAY_SPEECH_KEY",  # required — used for auth + usage logging
        )
    )
"""

from livekit.agents import Plugin

from .tts import TTS, ChunkedStream, SynthesizeStream
from .version import __version__


class RelaySpeechPlugin(Plugin):
    def __init__(self) -> None:
        super().__init__("relay_speech", __version__, __package__)


Plugin.register_plugin(RelaySpeechPlugin())

# Hide internal implementation details from public docs
__all__ = ["TTS", "SynthesizeStream", "ChunkedStream"]

# keep the namespace package intact
del Plugin
