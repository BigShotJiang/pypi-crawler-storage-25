# Copyright 2025 LiveKit, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import asyncio
import json
import os
import re
import weakref
from dataclasses import dataclass, replace

import aiohttp

from livekit.agents import (
    APIConnectionError,
    APIConnectOptions,
    APIStatusError,
    APITimeoutError,
    tts,
    utils,
)
from livekit.agents.types import DEFAULT_API_CONNECT_OPTIONS

from .log import logger

# ---------------------------------------------------------------------------
# Sentence boundary detector
# Mirrors Relay Speech's SentenceBuffer regex — supports Latin, Devanagari (।),
# Arabic (؟), and CJK full-width punctuation. Sentence buffering lives here
# at the plugin level so that complete sentences reach Relay Speech in one message,
# enabling an immediate cache lookup before any provider call is made.
# ---------------------------------------------------------------------------
_BOUNDARY_RE = re.compile(
    r"[.?!।؟？！。]+"  # one-or-more terminal punctuation across all supported scripts
    r"(?=\s|$)"         # must be followed by whitespace or end-of-string
)


class _SentenceBuffer:
    """Accumulate streaming LLM tokens and emit complete sentences."""

    __slots__ = ("_buf",)

    def __init__(self) -> None:
        self._buf: str = ""

    def push(self, text: str) -> list[str]:
        """Append text and return any complete sentences detected."""
        self._buf += text
        return self._drain()

    def flush(self) -> str:
        """Force-return remaining buffered text regardless of punctuation."""
        remaining = self._buf.strip()
        self._buf = ""
        return remaining

    def reset(self) -> None:
        self._buf = ""

    def _drain(self) -> list[str]:
        sentences: list[str] = []
        while True:
            m = _BOUNDARY_RE.search(self._buf)
            if not m:
                break
            sentence = self._buf[: m.end()].strip()
            self._buf = self._buf[m.end() :].lstrip()
            if sentence:
                sentences.append(sentence)
        return sentences


# ---------------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------------


@dataclass
class _TTSOptions:
    base_url: str
    provider: str
    voice_id: str
    model: str
    language: str
    speed: float
    volume: float
    sample_rate: int
    api_key: str
    relay_speech_api_key: str | None
    enable_cache: bool = False

    @property
    def ws_url(self) -> str:
        base = self.base_url.rstrip("/")
        base_ws = base.replace("https://", "wss://").replace("http://", "ws://")
        return (
            f"{base_ws}/v1/tts/ws"
            f"?provider={self.provider}"
            f"&api_key={self.api_key}"
            f"&relay_speech_key={self.relay_speech_api_key}"
        )

    @property
    def rest_url(self) -> str:
        return f"{self.base_url.rstrip('/')}/v1/tts"


# ---------------------------------------------------------------------------
# TTS
# ---------------------------------------------------------------------------


class TTS(tts.TTS):
    """
    LiveKit TTS plugin that routes synthesis through an Relay Speech server.

    Sentence buffering is performed **in the plugin** (not on the server),
    so each WebSocket message carries a complete sentence. This allows
    Relay Speech to do a cache lookup before making any provider API call.

    Args:
        base_url: URL of the running Relay Speech server (default: http://localhost:8000).
        provider: Underlying TTS provider ("cartesia", "elevenlabs", "sarvam", …).
        voice_id: Provider-specific voice identifier.
        model: TTS model name (e.g. "sonic-3" for Cartesia).
        language: BCP-47 language code (e.g. "en", "hi-IN").
        speed: Speech speed — -1.0 (slowest) to 1.0 (fastest), 0.0 = normal.
        volume: Volume multiplier — 0.5 to 2.0, 1.0 = normal.
        sample_rate: PCM sample rate in Hz. Must match Relay Speech server config.
        api_key: Provider API key. Falls back to ``{PROVIDER_UPPER}_API_KEY`` env var.
        relay_speech_api_key: Relay Speech server auth key sent as ``X-Relay Speech-Key`` (REST) and
                         ``relay_speech_key`` query param (WebSocket). Required — falls back to
                         ``RELAY_SPEECH_API_KEY`` env var. Every request is authenticated and
                         logged against this key in the Relay Speech backend.
        http_session: Existing aiohttp session to reuse (optional).
    """

    def __init__(
        self,
        *,
        base_url: str = "http://localhost:8000",
        provider: str = "cartesia",
        voice_id: str,
        model: str = "sonic-3",
        language: str = "en",
        speed: float = 0.0,
        volume: float = 1.0,
        sample_rate: int = 24000,
        api_key: str | None = None,
        relay_speech_api_key: str | None = None,
        enable_cache: bool = False,
        http_session: aiohttp.ClientSession | None = None,
    ) -> None:
        super().__init__(
            capabilities=tts.TTSCapabilities(streaming=True),
            sample_rate=sample_rate,
            num_channels=1,
        )

        provider_api_key = api_key or os.environ.get(f"{provider.upper()}_API_KEY")
        if not provider_api_key:
            raise ValueError(
                f"Provider API key required — pass api_key or set {provider.upper()}_API_KEY env var"
            )

        resolved_relay_speech_key = relay_speech_api_key or os.environ.get("RELAY_SPEECH_API_KEY")
        if not resolved_relay_speech_key:
            raise ValueError(
                "Relay Speech API key required — pass relay_speech_api_key or set RELAY_SPEECH_API_KEY env var"
            )

        if not model:
            raise ValueError("model must be a non-empty string (e.g. 'sonic-3' for Cartesia)")
        if not voice_id:
            raise ValueError("voice_id must be a non-empty string")

        self._opts = _TTSOptions(
            base_url=base_url,
            provider=provider,
            voice_id=voice_id,
            model=model,
            language=language,
            speed=speed,
            volume=volume,
            sample_rate=sample_rate,
            api_key=provider_api_key,
            relay_speech_api_key=resolved_relay_speech_key,
            enable_cache=enable_cache,
        )
        self._session = http_session
        self._pool = utils.ConnectionPool[aiohttp.ClientWebSocketResponse](
            connect_cb=self._connect_ws,
            close_cb=self._close_ws,
            max_session_duration=300,
            mark_refreshed_on_get=True,
        )
        self._streams: weakref.WeakSet[SynthesizeStream] = weakref.WeakSet()

    @property
    def provider(self) -> str:
        return f"Relay Speech/{self._opts.provider}"

    def _ensure_session(self) -> aiohttp.ClientSession:
        if not self._session:
            self._session = utils.http_context.http_session()
        return self._session

    async def _connect_ws(self, timeout: float) -> aiohttp.ClientWebSocketResponse:
        # relay_speech_key is passed as a query param in ws_url (WS connections don't
        # support custom headers in browsers; query param is the standard pattern).
        ws = await asyncio.wait_for(
            self._ensure_session().ws_connect(self._opts.ws_url),
            timeout=timeout,
        )
        logger.debug("Connected to Relay Speech WebSocket at %s", self._opts.ws_url)
        return ws

    async def _close_ws(self, ws: aiohttp.ClientWebSocketResponse) -> None:
        await ws.close()

    def prewarm(self) -> None:
        """Open a WS connection in advance to eliminate first-turn latency."""
        self._pool.prewarm()

    def update_options(
        self,
        *,
        voice_id: str | None = None,
        model: str | None = None,
        language: str | None = None,
        speed: float | None = None,
        volume: float | None = None,
    ) -> None:
        if voice_id is not None:
            self._opts.voice_id = voice_id
        if model is not None:
            self._opts.model = model
        if language is not None:
            self._opts.language = language
        if speed is not None:
            self._opts.speed = speed
        if volume is not None:
            self._opts.volume = volume

    def synthesize(
        self,
        text: str,
        *,
        conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS,
    ) -> "ChunkedStream":
        return ChunkedStream(tts=self, input_text=text, conn_options=conn_options)

    def stream(
        self,
        *,
        conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS,
    ) -> "SynthesizeStream":
        stream = SynthesizeStream(tts=self, conn_options=conn_options)
        self._streams.add(stream)
        return stream

    async def aclose(self) -> None:
        for stream in list(self._streams):
            await stream.aclose()
        self._streams.clear()
        await self._pool.aclose()


# ---------------------------------------------------------------------------
# ChunkedStream — one-shot HTTP synthesis
# ---------------------------------------------------------------------------


class ChunkedStream(tts.ChunkedStream):
    """
    Synthesizes a complete text string via a single HTTP POST to Relay Speech.
    Used when ``tts.synthesize(text)`` is called directly (non-streaming path).
    """

    def __init__(
        self, *, tts: TTS, input_text: str, conn_options: APIConnectOptions
    ) -> None:
        super().__init__(tts=tts, input_text=input_text, conn_options=conn_options)
        self._tts: TTS = tts
        self._opts = tts._opts

    def _headers(self) -> dict[str, str]:
        return {
            "X-Provider-Api-Key": self._opts.api_key,
            "X-Relay Speech-Key": self._opts.relay_speech_api_key,
        }

    def _payload(self, text: str) -> dict:
        return {
            "text": text,
            "voice_id": self._opts.voice_id,
            "model": self._opts.model,
            "provider": self._opts.provider,
            "language": self._opts.language,
            "speed": self._opts.speed,
            "volume": self._opts.volume,
            "stream": False,
            "enable_cache": self._opts.enable_cache,
            "output_format": {
                "container": "raw",
                "encoding": "pcm_s16le",
                "sample_rate": self._opts.sample_rate,
            },
        }

    async def _run(self, output_emitter: tts.AudioEmitter) -> None:
        output_emitter.initialize(
            request_id=utils.shortuuid(),
            sample_rate=self._opts.sample_rate,
            num_channels=1,
            mime_type="audio/pcm",
        )
        try:
            async with self._tts._ensure_session().post(
                self._opts.rest_url,
                headers=self._headers(),
                json=self._payload(self._input_text),
                timeout=aiohttp.ClientTimeout(
                    total=60, sock_connect=self._conn_options.timeout
                ),
            ) as resp:
                if resp.status >= 400:
                    body = await resp.text()
                    raise APIStatusError(
                        message=body,
                        status_code=resp.status,
                        request_id=None,
                        body=body,
                    )
                async for data, _ in resp.content.iter_chunks():
                    output_emitter.push(data)
                output_emitter.flush()
        except asyncio.TimeoutError:
            raise APITimeoutError() from None
        except aiohttp.ClientResponseError as e:
            raise APIStatusError(
                message=e.message, status_code=e.status, request_id=None, body=None
            ) from e
        except APIStatusError:
            raise
        except Exception as e:
            raise APIConnectionError() from e


# ---------------------------------------------------------------------------
# SynthesizeStream — real-time WebSocket streaming
# ---------------------------------------------------------------------------


class SynthesizeStream(tts.SynthesizeStream):
    """
    Streams LLM token output to Relay Speech over a persistent WebSocket.

    Token flow
    ----------
    1. LLM tokens arrive via ``push_text()`` (called by the LiveKit framework).
    2. A plugin-level ``_SentenceBuffer`` accumulates them and emits complete
       sentences — supporting ``. ? ! । ؟ ？ ！ 。`` across all scripts.
    3. Each complete sentence is sent to Relay Speech as one ``WSTextMessage``
       (``continue_context=True``).
    4. On ``FlushSentinel`` (end of LLM turn), any remaining text is flushed
       with ``continue_context=False``.
    5. Relay Speech performs a cache lookup on the complete sentence immediately.
       Cache hits return audio with zero provider API calls.
    6. Binary audio frames (PCM S16LE) stream back from Relay Speech and are
       forwarded to the LiveKit room via ``output_emitter``.
    7. A JSON ``{"type": "done"}`` frame from Relay Speech signals the end of each
       sentence's audio. When all sentences are acked, the stream closes.
    """

    def __init__(self, *, tts: TTS, conn_options: APIConnectOptions) -> None:
        super().__init__(tts=tts, conn_options=conn_options)
        self._tts: TTS = tts
        self._opts = tts._opts

    def _ws_message(self, text: str, context_id: str, *, continue_context: bool) -> str:
        return json.dumps(
            {
                "text": text,
                "voice_id": self._opts.voice_id,
                "model": self._opts.model,
                "language": self._opts.language,
                "speed": self._opts.speed,
                "volume": self._opts.volume,
                "output_format": {
                    "container": "raw",
                    "encoding": "pcm_s16le",
                    "sample_rate": self._opts.sample_rate,
                },
                "enable_cache": self._opts.enable_cache,
                "context_id": context_id,
                "continue_context": continue_context,
            }
        )

    async def _run(self, output_emitter: tts.AudioEmitter) -> None:
        request_id = utils.shortuuid()
        context_id = utils.shortuuid()

        output_emitter.initialize(
            request_id=request_id,
            sample_rate=self._opts.sample_rate,
            num_channels=1,
            mime_type="audio/pcm",
            stream=True,
        )

        buf = _SentenceBuffer()

        # Shared state between send and recv tasks (dicts avoid nonlocal issues)
        state = {"sentences_sent": 0, "done_received": 0}
        input_done = asyncio.Event()
        all_audio_done = asyncio.Event()

        async def _send_loop(ws: aiohttp.ClientWebSocketResponse) -> None:
            async for data in self._input_ch:
                if ws.closed:
                    raise APIConnectionError()
                if isinstance(data, self._FlushSentinel):
                    # End of LLM turn — flush any remaining partial sentence
                    remaining = buf.flush()
                    if remaining:
                        await ws.send_str(
                            self._ws_message(remaining, context_id, continue_context=False)
                        )
                        state["sentences_sent"] += 1
                        self._mark_started()
                else:
                    for sentence in buf.push(data):
                        await ws.send_str(
                            self._ws_message(sentence, context_id, continue_context=True)
                        )
                        state["sentences_sent"] += 1
                        self._mark_started()

            input_done.set()
            # If recv_loop already collected all done messages, unblock it now
            if state["done_received"] >= state["sentences_sent"]:
                all_audio_done.set()

        async def _recv_loop(ws: aiohttp.ClientWebSocketResponse) -> None:
            # One segment for the entire stream — livekit expects exactly 1 segment
            # per SynthesizeStream._run() invocation regardless of sentence count.
            output_emitter.start_segment(segment_id=utils.shortuuid())

            while True:
                # Race ws.receive() against all_audio_done so we exit immediately
                # when the send loop signals done (e.g. empty/whitespace-only input)
                # without blocking until the per-message timeout fires.
                recv_task = asyncio.ensure_future(ws.receive())
                done_task = asyncio.ensure_future(all_audio_done.wait())
                try:
                    finished, pending = await asyncio.wait(
                        {recv_task, done_task},
                        timeout=self._conn_options.timeout,
                        return_when=asyncio.FIRST_COMPLETED,
                    )
                finally:
                    for t in (recv_task, done_task):
                        if not t.done():
                            t.cancel()

                if not finished:
                    raise APITimeoutError()

                if done_task in finished:
                    # all_audio_done was set by _send_loop (0 sentences) — nothing to receive
                    break

                msg = recv_task.result()

                if msg.type in (
                    aiohttp.WSMsgType.CLOSED,
                    aiohttp.WSMsgType.CLOSE,
                    aiohttp.WSMsgType.CLOSING,
                ):
                    logger.warning("Relay Speech WebSocket closed unexpectedly")
                    raise APIConnectionError()

                if msg.type == aiohttp.WSMsgType.BINARY:
                    output_emitter.push(msg.data)

                elif msg.type == aiohttp.WSMsgType.TEXT:
                    ctrl = json.loads(msg.data)
                    msg_type = ctrl.get("type")

                    if msg_type == "done":
                        state["done_received"] += 1
                        logger.debug(
                            "Relay Speech done [cached=%s] sentence %d/%s",
                            ctrl.get("cached"),
                            state["done_received"],
                            state["sentences_sent"] if input_done.is_set() else "?",
                        )
                        if (
                            input_done.is_set()
                            and state["done_received"] >= state["sentences_sent"]
                        ):
                            all_audio_done.set()
                            break  # exit immediately — no more messages expected

                    elif msg_type == "error":
                        raise APIStatusError(
                            message=ctrl.get("error", "Relay Speech synthesis error"),
                            status_code=500,
                            request_id=request_id,
                            body=str(ctrl),
                        )

                    elif msg_type == "heartbeat":
                        pass  # keepalive — resets per-message timeout, no action needed

                    elif msg_type == "cancelled":
                        logger.debug("Relay Speech cancelled context %s", ctrl.get("context_id"))
                        break

            output_emitter.end_segment()
            output_emitter.end_input()

        try:
            async with self._tts._pool.connection(timeout=self._conn_options.timeout) as ws:
                tasks = [
                    asyncio.create_task(_send_loop(ws)),
                    asyncio.create_task(_recv_loop(ws)),
                ]
                try:
                    await asyncio.gather(*tasks)
                finally:
                    await utils.aio.gracefully_cancel(*tasks)
        except asyncio.TimeoutError:
            raise APITimeoutError() from None
        except aiohttp.ClientResponseError as e:
            raise APIStatusError(
                message=e.message, status_code=e.status, request_id=None, body=None
            ) from e
        except APIStatusError:
            raise
        except Exception as e:
            logger.exception("Relay Speech connection error (context_id=%s)", context_id)
            raise APIConnectionError() from e
