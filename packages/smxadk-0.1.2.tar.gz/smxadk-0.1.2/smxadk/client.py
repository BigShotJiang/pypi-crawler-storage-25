from collections.abc import Iterator
from typing import Any

import httpx

from smxadk.schemas import ChatResponse, HealthResponse


class SMXAgentClient:
    """
    Client SDK for calling a deployed SyntaxMatrix Agent Service.
    """

    def __init__(
        self,
        base_url: str,
        timeout: float = 600.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout


    @classmethod
    def from_env(
        cls,
        env_var: str = "SMX_AGENT_URL",
        timeout: float = 600.0,
    ) -> "SMXAgentClient":
        """
        Create an SMXAgentClient from an environment variable.

        Default:
            SMX_AGENT_URL=https://customer-owned-agent-service-url
        """
        import os

        base_url = os.getenv(env_var, "").strip()

        if not base_url:
            raise ValueError(
                f"{env_var} is not configured. "
                f"Set {env_var}=https://your-agent-service-url"
            )
            
        return cls(base_url=base_url, timeout=timeout)
    

    def health(self) -> HealthResponse:
        response = httpx.get(
            f"{self.base_url}/health",
            timeout=self.timeout,
        )
        response.raise_for_status()
        return HealthResponse.model_validate(response.json())
        

    def supported_modes(self) -> list[str]:
        """
        Return the model routes currently supported by the deployed Agent Service.
        """
        return self.health().supported_modes
    

    def chat(
        self,
        *,
        message: str,
        mode: str,
        system_prompt: str | None = None,
        max_tokens: int = 512,
        temperature: float = 0.2,
    ) -> ChatResponse:
        payload: dict[str, Any] = {
            "message": message,
            "mode": mode,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        if system_prompt:
            payload["system_prompt"] = system_prompt

        response = httpx.post(
            f"{self.base_url}/chat",
            json=payload,
            timeout=self.timeout,
        )
        response.raise_for_status()

        return ChatResponse.model_validate(response.json())


    def stream_chat_events(
        self,
        *,
        message: str,
        mode: str,
        system_prompt: str | None = None,
        max_tokens: int = 512,
        temperature: float = 0.2,
    ) -> Iterator[str]:
        """
        Stream raw Server-Sent Event formatted lines from the Agent Service.

        Use this when a web framework or browser client expects SSE-style output.
        """
        payload: dict[str, Any] = {
            "message": message,
            "mode": mode,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        if system_prompt:
            payload["system_prompt"] = system_prompt

        with httpx.stream(
            "POST",
            f"{self.base_url}/chat/stream",
            json=payload,
            timeout=None,
        ) as response:
            response.raise_for_status()

            for line in response.iter_lines():
                if not line:
                    continue

                yield line

                if line.strip() == "data: [DONE]":
                    break

    
    def stream_chat_text(
        self,
        *,
        message: str,
        mode: str,
        system_prompt: str | None = None,
        max_tokens: int = 512,
        temperature: float = 0.2,
    ) -> Iterator[str]:
        """
        Stream clean text chunks from the Agent Service.

        Preserves newline chunks so Markdown tables, headings, and bullet lists
        render correctly instead of collapsing into one long line.
        """
        for line in self.stream_chat_events(
            message=message,
            mode=mode,
            system_prompt=system_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
        ):
            if line.startswith("event: done"):
                break

            if not line.startswith("data:"):
                continue

            data = line.removeprefix("data:")

            if data.startswith(" "):
                data = data[1:]

            if data.strip() == "[DONE]":
                break

            # A blank SSE data line usually represents a newline token from the model.
            if data == "":
                yield "\n"
            else:
                yield data


    def stream_chat(
        self,
        *,
        message: str,
        mode: str,
        system_prompt: str | None = None,
        max_tokens: int = 512,
        temperature: float = 0.2,
    ) -> Iterator[str]:
        """
        Backwards-compatible alias for clean text streaming.
        """
        yield from self.stream_chat_text(
            message=message,
            mode=mode,
            system_prompt=system_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
        )


