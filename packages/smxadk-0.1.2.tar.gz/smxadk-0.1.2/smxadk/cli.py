import argparse
from pathlib import Path

from smxadk.deployment import write_litellm_config, write_supported_modes
from smxadk.templates import DEFAULT_DEPLOYMENT_TEMPLATE


def init_project(output_path: str = "smx_deployment.yaml", force: bool = False) -> Path:
    output = Path(output_path)

    if output.exists() and not force:
        raise FileExistsError(
            f"{output} already exists. Use --force to overwrite it."
        )

    output.write_text(DEFAULT_DEPLOYMENT_TEMPLATE, encoding="utf-8")
    return output


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="smxadk",
        description="SyntaxMatrix Agent Development Kit CLI",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser(
        "init",
        help="Create a starter smx_deployment.yaml in the current project.",
    )

    init_parser.add_argument(
        "--output",
        default="smx_deployment.yaml",
        help="Where to write the starter deployment config.",
    )

    init_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite the file if it already exists.",
    )

    generate_parser = subparsers.add_parser(
        "generate",
        help="Generate deployment files from smx_deployment.yaml",
    )

    generate_parser.add_argument(
        "--config",
        default="smx_deployment.yaml",
        help="Path to the SyntaxMatrix deployment config.",
    )

    generate_parser.add_argument(
        "--litellm-output",
        required=True,
        help="Output path for generated LiteLLM config.yaml.",
    )

    generate_parser.add_argument(
        "--modes-output",
        required=True,
        help="Output path for generated supported modes text file.",
    )

    args = parser.parse_args()

    if args.command == "init":
        output = init_project(
            output_path=args.output,
            force=args.force,
        )
        print(f"Created deployment config: {output}")

    elif args.command == "generate":
        litellm_path = write_litellm_config(
            config_path=args.config,
            output_path=args.litellm_output,
        )

        modes_path = write_supported_modes(
            config_path=args.config,
            output_path=args.modes_output,
        )

        print(f"Generated LiteLLM config: {litellm_path}")
        print(f"Generated supported modes: {modes_path}")


if __name__ == "__main__":
    main()