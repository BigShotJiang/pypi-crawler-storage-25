"""
Python bindings for the libepctofcam library
"""
from __future__ import annotations
import logging
import typing
__all__: list[str] = ['ACQUISITION_MODE', 'AMPLITUDE', 'AcquisitionMode', 'DCS', 'DCS4', 'DISTANCE', 'DIST_AMP', 'DIST_AMP_HDR', 'ENABLE_GRAYSCALE_DSNU_COMPENSATION', 'ENABLE_PHASE_ERROR_COMPENSATION', 'ENABLE_PHASE_OFFSET_COMPENSATION', 'ENABLE_TEMPERATURE_COMPENSATION', 'EXPOSURE_US', 'FrameType', 'GAIN', 'GRAYSCALE', 'HDR_INTEGRATION_TIME1_US', 'HDR_INTEGRATION_TIME2_US', 'HDR_INTEGRATION_TIME3_US', 'LED_DELAY_STEP', 'MIN_AMPLITUDE', 'MODULATION_FREQUENCY_HZ', 'PHASE', 'TOFCam', 'TOFControl', 'TOFFrame', 'TOFMetadata', 'TOFSensor', 'autodetect', 'epc670', 'logger']
class AcquisitionMode:
    """
    Supported acquisition modes.
    
    Members:
    
      DIST_AMP : Distance and amplitude mode (standard 4-DCS).
    
      GRAYSCALE : Grayscale mode.
    
      DIST_AMP_HDR : Distance and amplitude in HDR mode (multiple integration times).
    
      DCS4 : Raw 4-DCS frame output mode.
    """
    DCS4: typing.ClassVar[AcquisitionMode]  # value = <AcquisitionMode.DCS4: 4>
    DIST_AMP: typing.ClassVar[AcquisitionMode]  # value = <AcquisitionMode.DIST_AMP: 0>
    DIST_AMP_HDR: typing.ClassVar[AcquisitionMode]  # value = <AcquisitionMode.DIST_AMP_HDR: 2>
    GRAYSCALE: typing.ClassVar[AcquisitionMode]  # value = <AcquisitionMode.GRAYSCALE: 1>
    __members__: typing.ClassVar[dict[str, AcquisitionMode]]  # value = {'DIST_AMP': <AcquisitionMode.DIST_AMP: 0>, 'GRAYSCALE': <AcquisitionMode.GRAYSCALE: 1>, 'DIST_AMP_HDR': <AcquisitionMode.DIST_AMP_HDR: 2>, 'DCS4': <AcquisitionMode.DCS4: 4>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class FrameType:
    """
    Frame data type selector for TOFFrame.get().
    
    Members:
    
      DCS : Raw DCS image. Use the index argument to select the DCS channel (0-3).
    
      AMPLITUDE : Amplitude image
    
      DISTANCE : Computed distance image in mm.
    
      GRAYSCALE : Grayscale image
    
      PHASE : Phase image in radians.
    """
    AMPLITUDE: typing.ClassVar[FrameType]  # value = <FrameType.AMPLITUDE: 1>
    DCS: typing.ClassVar[FrameType]  # value = <FrameType.DCS: 0>
    DISTANCE: typing.ClassVar[FrameType]  # value = <FrameType.DISTANCE: 2>
    GRAYSCALE: typing.ClassVar[FrameType]  # value = <FrameType.GRAYSCALE: 4>
    PHASE: typing.ClassVar[FrameType]  # value = <FrameType.PHASE: 3>
    __members__: typing.ClassVar[dict[str, FrameType]]  # value = {'DCS': <FrameType.DCS: 0>, 'AMPLITUDE': <FrameType.AMPLITUDE: 1>, 'DISTANCE': <FrameType.DISTANCE: 2>, 'GRAYSCALE': <FrameType.GRAYSCALE: 4>, 'PHASE': <FrameType.PHASE: 3>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class TOFCam:
    """
    Interface for controlling an EPC TOF camera module.
    """
    def __init__(self, sensor: TOFSensor = ...) -> None:
        """
        Initialize the TOFCam.
        
        :param sensor: Sensor model to connect to (default: autodetect).
        """
    def captureFrame(self) -> TOFFrame:
        """
        Capture the next frame.
        
        If streaming is active, retrieves the latest frame from the stream.
        If streaming is not active, triggers a single-shot capture.
        :returns: TOFFrame instance containing the captured data.
        """
    def close(self) -> None:
        """
        Close the connection to the camera and release all resources.
        """
    def getControl(self, control: TOFControl) -> int:
        """
        Get the current value of a camera control parameter.
        
        :param control: TOFControl identifier.
        :returns: Current integer value of the control.
        """
    def open(self) -> None:
        """
        Open the connection to the camera. Must be called before any other method.
        """
    def setControl(self, control: TOFControl, value: typing.Any) -> None:
        """
        Set a camera control parameter.
        
        :param control: TOFControl identifier.
        :param value: Integer value or enum (e.g. AcquisitionMode) to set.
        """
    def startStream(self) -> None:
        """
        Start continuous frame acquisition. Enables the maximum frame rate.
        """
    def stopStream(self) -> None:
        """
        Stop continuous frame acquisition.
        """
class TOFControl:
    """
    TOFCam Control ID's.
    
    Members:
    
      EXPOSURE_US : Integration time in microseconds.
    
      MODULATION_FREQUENCY_HZ : Modulation frequency in Hz.
    
      ENABLE_PHASE_OFFSET_COMPENSATION : Enable/disable phase offset compensation (1=on, 0=off).
    
      ENABLE_PHASE_ERROR_COMPENSATION : Enable/disable phase error (DRNU) compensation (1=on, 0=off).
    
      ENABLE_TEMPERATURE_COMPENSATION : Enable/disable temperature compensation (1=on, 0=off).
    
      ENABLE_GRAYSCALE_DSNU_COMPENSATION : Enable/disable grayscale DSNU compensation (1=on, 0=off).
    
      ACQUISITION_MODE : Acquisition mode (see AcquisitionMode enum).
    
      HDR_INTEGRATION_TIME1_US : First HDR integration time in microseconds.
    
      HDR_INTEGRATION_TIME2_US : Second HDR integration time in microseconds.
    
      HDR_INTEGRATION_TIME3_US : Third HDR integration time in microseconds.
    
      GAIN : Analog gain setting.
    
      LED_DELAY_STEP : LED delay step. Only useful for calibration and testing.
    
      MIN_AMPLITUDE : Minimum amplitude threshold.
    """
    ACQUISITION_MODE: typing.ClassVar[TOFControl]  # value = <TOFControl.ACQUISITION_MODE: 1>
    ENABLE_GRAYSCALE_DSNU_COMPENSATION: typing.ClassVar[TOFControl]  # value = <TOFControl.ENABLE_GRAYSCALE_DSNU_COMPENSATION: 11>
    ENABLE_PHASE_ERROR_COMPENSATION: typing.ClassVar[TOFControl]  # value = <TOFControl.ENABLE_PHASE_ERROR_COMPENSATION: 9>
    ENABLE_PHASE_OFFSET_COMPENSATION: typing.ClassVar[TOFControl]  # value = <TOFControl.ENABLE_PHASE_OFFSET_COMPENSATION: 8>
    ENABLE_TEMPERATURE_COMPENSATION: typing.ClassVar[TOFControl]  # value = <TOFControl.ENABLE_TEMPERATURE_COMPENSATION: 10>
    EXPOSURE_US: typing.ClassVar[TOFControl]  # value = <TOFControl.EXPOSURE_US: 4>
    GAIN: typing.ClassVar[TOFControl]  # value = <TOFControl.GAIN: 0>
    HDR_INTEGRATION_TIME1_US: typing.ClassVar[TOFControl]  # value = <TOFControl.HDR_INTEGRATION_TIME1_US: 5>
    HDR_INTEGRATION_TIME2_US: typing.ClassVar[TOFControl]  # value = <TOFControl.HDR_INTEGRATION_TIME2_US: 6>
    HDR_INTEGRATION_TIME3_US: typing.ClassVar[TOFControl]  # value = <TOFControl.HDR_INTEGRATION_TIME3_US: 7>
    LED_DELAY_STEP: typing.ClassVar[TOFControl]  # value = <TOFControl.LED_DELAY_STEP: 12>
    MIN_AMPLITUDE: typing.ClassVar[TOFControl]  # value = <TOFControl.MIN_AMPLITUDE: 13>
    MODULATION_FREQUENCY_HZ: typing.ClassVar[TOFControl]  # value = <TOFControl.MODULATION_FREQUENCY_HZ: 2>
    __members__: typing.ClassVar[dict[str, TOFControl]]  # value = {'EXPOSURE_US': <TOFControl.EXPOSURE_US: 4>, 'MODULATION_FREQUENCY_HZ': <TOFControl.MODULATION_FREQUENCY_HZ: 2>, 'ENABLE_PHASE_OFFSET_COMPENSATION': <TOFControl.ENABLE_PHASE_OFFSET_COMPENSATION: 8>, 'ENABLE_PHASE_ERROR_COMPENSATION': <TOFControl.ENABLE_PHASE_ERROR_COMPENSATION: 9>, 'ENABLE_TEMPERATURE_COMPENSATION': <TOFControl.ENABLE_TEMPERATURE_COMPENSATION: 10>, 'ENABLE_GRAYSCALE_DSNU_COMPENSATION': <TOFControl.ENABLE_GRAYSCALE_DSNU_COMPENSATION: 11>, 'ACQUISITION_MODE': <TOFControl.ACQUISITION_MODE: 1>, 'HDR_INTEGRATION_TIME1_US': <TOFControl.HDR_INTEGRATION_TIME1_US: 5>, 'HDR_INTEGRATION_TIME2_US': <TOFControl.HDR_INTEGRATION_TIME2_US: 6>, 'HDR_INTEGRATION_TIME3_US': <TOFControl.HDR_INTEGRATION_TIME3_US: 7>, 'GAIN': <TOFControl.GAIN: 0>, 'LED_DELAY_STEP': <TOFControl.LED_DELAY_STEP: 12>, 'MIN_AMPLITUDE': <TOFControl.MIN_AMPLITUDE: 13>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class TOFFrame:
    """
    A single captured TOF frame. Holds image data and metadata.
    """
    def get(self, type: FrameType, index: typing.SupportsInt | typing.SupportsIndex = 0) -> numpy.ndarray:
        """
        Return a 2D numpy array for the requested frame type.
        
        :param type: FrameType selector (DCS, AMPLITUDE, DISTANCE, PHASE).
        :param index: DCS channel index (only used for FrameType.DCS).
        :returns: numpy.ndarray of shape (height, width). dtype is uint16 for DCS/AMPLITUDE/DISTANCE, float32 for PHASE.
        :raises RuntimeError: if the requested data is not available in the current acquisition mode.
        """
    def getMetadata(self) -> TOFMetadata:
        """
        Return the TOFMetadata for this frame.
        """
    @property
    def height(self) -> int:
        """
        Image height in pixels.
        """
    @property
    def width(self) -> int:
        """
        Image width in pixels.
        """
class TOFMetadata:
    """
    Metadata associated with a captured TOF frame.
    """
    @property
    def frameNumber(self) -> int:
        """
        Sequential frame number since stream start.
        """
    @property
    def timestamp(self) -> int:
        """
        Frame timestamp in microseconds.
        """
class TOFSensor:
    """
    Supported TOF camera sensor models.
    
    Members:
    
      autodetect : Automatically detect the connected sensor.
    
      epc670 : EPC670 TOF sensor.
    """
    __members__: typing.ClassVar[dict[str, TOFSensor]]  # value = {'autodetect': <TOFSensor.autodetect: 0>, 'epc670': <TOFSensor.epc670: 1>}
    autodetect: typing.ClassVar[TOFSensor]  # value = <TOFSensor.autodetect: 0>
    epc670: typing.ClassVar[TOFSensor]  # value = <TOFSensor.epc670: 1>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt | typing.SupportsIndex) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
ACQUISITION_MODE: TOFControl  # value = <TOFControl.ACQUISITION_MODE: 1>
AMPLITUDE: FrameType  # value = <FrameType.AMPLITUDE: 1>
DCS: FrameType  # value = <FrameType.DCS: 0>
DCS4: AcquisitionMode  # value = <AcquisitionMode.DCS4: 4>
DISTANCE: FrameType  # value = <FrameType.DISTANCE: 2>
DIST_AMP: AcquisitionMode  # value = <AcquisitionMode.DIST_AMP: 0>
DIST_AMP_HDR: AcquisitionMode  # value = <AcquisitionMode.DIST_AMP_HDR: 2>
ENABLE_GRAYSCALE_DSNU_COMPENSATION: TOFControl  # value = <TOFControl.ENABLE_GRAYSCALE_DSNU_COMPENSATION: 11>
ENABLE_PHASE_ERROR_COMPENSATION: TOFControl  # value = <TOFControl.ENABLE_PHASE_ERROR_COMPENSATION: 9>
ENABLE_PHASE_OFFSET_COMPENSATION: TOFControl  # value = <TOFControl.ENABLE_PHASE_OFFSET_COMPENSATION: 8>
ENABLE_TEMPERATURE_COMPENSATION: TOFControl  # value = <TOFControl.ENABLE_TEMPERATURE_COMPENSATION: 10>
EXPOSURE_US: TOFControl  # value = <TOFControl.EXPOSURE_US: 4>
GAIN: TOFControl  # value = <TOFControl.GAIN: 0>
GRAYSCALE: FrameType  # value = <FrameType.GRAYSCALE: 4>
HDR_INTEGRATION_TIME1_US: TOFControl  # value = <TOFControl.HDR_INTEGRATION_TIME1_US: 5>
HDR_INTEGRATION_TIME2_US: TOFControl  # value = <TOFControl.HDR_INTEGRATION_TIME2_US: 6>
HDR_INTEGRATION_TIME3_US: TOFControl  # value = <TOFControl.HDR_INTEGRATION_TIME3_US: 7>
LED_DELAY_STEP: TOFControl  # value = <TOFControl.LED_DELAY_STEP: 12>
MIN_AMPLITUDE: TOFControl  # value = <TOFControl.MIN_AMPLITUDE: 13>
MODULATION_FREQUENCY_HZ: TOFControl  # value = <TOFControl.MODULATION_FREQUENCY_HZ: 2>
PHASE: FrameType  # value = <FrameType.PHASE: 3>
autodetect: TOFSensor  # value = <TOFSensor.autodetect: 0>
epc670: TOFSensor  # value = <TOFSensor.epc670: 1>
logger: logging.Logger  # value = <Logger epc_tofcam_native (INFO)>
