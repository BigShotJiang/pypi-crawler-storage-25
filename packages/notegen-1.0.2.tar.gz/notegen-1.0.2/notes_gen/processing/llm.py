from __future__ import annotations

import random
import re
import time

import litellm
from rich.console import Console

from notes_gen.config import Config

_console = Console(stderr=True)

# Per-key cooldown: key → monotonic time when it becomes available again
_key_cooldowns: dict[str, float] = {}

_SYSTEM_PROMPT = """\
You are an expert note-taker converting transcripts and articles into structured Obsidian notes.

Rules:
- Use Obsidian-flavored markdown: YAML frontmatter (omit here — added externally),
  ## and ### headings only
- Use `> [!TIP]` and `> [!WARNING]` callouts for important insights
- Use mermaid diagrams for flows and architectures when appropriate
- Use [[wikilinks]] for cross-references to related concepts
- Be comprehensive — never truncate to hit a length limit
- Auto-infer relevant tags from content
- Write for a technical audience learning the subject
"""

_USER_PROMPT_TEMPLATE = """\
Convert the following content into structured Obsidian notes:

<content>
{chunk}
</content>

Produce well-organized markdown notes with clear headings, key concepts,
code examples where relevant, and callouts for important points.
"""


def _provider(model: str) -> str:
    return model.split("/")[0] if "/" in model else model


def _is_rate_limit_error(exc: Exception) -> bool:
    name = type(exc).__name__.lower()
    msg = str(exc).lower()
    return (
        "ratelimit" in name
        or "rate_limit" in name
        or " 429" in msg
        or "too many requests" in msg
        or "rate limit" in msg
    )


def _available_keys(cfg: Config) -> list[str]:
    now = time.monotonic()
    provider = _provider(cfg.model)
    return [
        k
        for k in cfg.api_keys.get(provider, [])
        if k and not k.startswith("#") and _key_cooldowns.get(k, 0) <= now
    ]


def _cooldown_key(key: str | None, seconds: float) -> None:
    if key:
        _key_cooldowns[key] = time.monotonic() + seconds


def _parse_retry_after(exc: Exception) -> float | None:
    m = re.search(
        r"(?:retry.{0,15}after|retry_after|please\s+wait)[:\s]+(\d+(?:\.\d+)?)",
        str(exc),
        re.IGNORECASE,
    )
    return float(m.group(1)) if m else None


def _call_with_retry(cfg: Config, messages: list[dict]) -> str:
    for attempt in range(cfg.max_retries + 1):
        available = _available_keys(cfg)
        api_key = random.choice(available) if available else cfg.pick_api_key()

        try:
            kwargs: dict = {"model": cfg.model, "messages": messages, "temperature": 0.3}
            if api_key:
                kwargs["api_key"] = api_key
            response = litellm.completion(**kwargs)
            return response.choices[0].message.content

        except Exception as exc:
            if not _is_rate_limit_error(exc) or attempt >= cfg.max_retries:
                raise

            backoff = cfg.retry_base_delay * (2**attempt)
            _cooldown_key(api_key, backoff)

            still_available = _available_keys(cfg)
            if still_available:
                _console.print(
                    f"[yellow]Rate limited — rotating to another key "
                    f"(attempt {attempt + 1}/{cfg.max_retries})...[/yellow]"
                )
                continue

            wait = _parse_retry_after(exc) or backoff
            _console.print(
                f"[yellow]Rate limited on {_provider(cfg.model)} — "
                f"waiting {wait:.0f}s (attempt {attempt + 1}/{cfg.max_retries})...[/yellow]"
            )
            time.sleep(wait)

    raise RuntimeError("Max retries exceeded")  # pragma: no cover


def generate_notes(chunks: list[str], cfg: Config) -> str:
    results: list[str] = []
    for chunk in chunks:
        messages = [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": _USER_PROMPT_TEMPLATE.format(chunk=chunk)},
        ]
        results.append(_call_with_retry(cfg, messages))
    return "\n\n".join(results)
