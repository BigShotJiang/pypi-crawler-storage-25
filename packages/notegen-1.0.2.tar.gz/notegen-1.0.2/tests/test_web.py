from pathlib import Path
from unittest.mock import MagicMock, patch

from notes_gen.config import Config
from notes_gen.sources.web import (
    _same_domain_links,
    extract_content,
    fetch_page,
    run_web_crawl_pipeline,
    run_web_pipeline,
)

FIXTURE_HTML = (Path(__file__).parent / "fixtures" / "sample_html.html").read_text()


def test_extract_content_from_html():
    content = extract_content(FIXTURE_HTML, "https://example.com/asyncio")
    assert "asyncio" in content.lower() or "Asyncio" in content
    assert len(content) > 50


def test_extract_content_strips_nav_footer():
    content = extract_content(FIXTURE_HTML, "https://example.com/asyncio")
    assert "Copyright" not in content or content.count("Copyright") == 0


def test_extract_content_empty_html_returns_empty():
    result = extract_content("", "https://example.com")
    assert result == "" or result is not None


@patch("notes_gen.sources.web.httpx")
def test_fetch_page_returns_html(mock_httpx):
    mock_response = MagicMock()
    mock_response.text = FIXTURE_HTML
    mock_response.raise_for_status = MagicMock()
    mock_httpx.get.return_value = mock_response

    html = fetch_page("https://example.com/asyncio")
    assert "asyncio" in html.lower() or "Asyncio" in html


@patch("notes_gen.sources.web.httpx")
def test_fetch_page_sets_user_agent(mock_httpx):
    mock_response = MagicMock()
    mock_response.text = "<html><body>content</body></html>"
    mock_response.raise_for_status = MagicMock()
    mock_httpx.get.return_value = mock_response

    fetch_page("https://example.com")
    call_kwargs = mock_httpx.get.call_args
    headers = call_kwargs.kwargs.get("headers", {}) or (
        call_kwargs.args[1] if len(call_kwargs.args) > 1 else {}
    )
    if not headers and hasattr(call_kwargs, "kwargs"):
        headers = call_kwargs.kwargs.get("headers", {})
    # Just verify it was called
    mock_httpx.get.assert_called_once()


@patch("notes_gen.sources.web.httpx")
def test_run_web_pipeline_creates_file(mock_httpx, tmp_path):
    mock_response = MagicMock()
    mock_response.text = FIXTURE_HTML
    mock_response.raise_for_status = MagicMock()
    mock_httpx.get.return_value = mock_response

    cfg = Config(output_dir=tmp_path)
    notes_content = "## Asyncio Guide\n\nEvent loop and coroutines."

    with patch("notes_gen.sources.web.generate_notes", return_value=notes_content):
        output_path = run_web_pipeline("https://example.com/asyncio", cfg)

    assert output_path.exists()
    content = output_path.read_text()
    assert "---" in content
    assert "type: article" in content


@patch("notes_gen.sources.web.httpx")
def test_run_web_pipeline_frontmatter_has_source_url(mock_httpx, tmp_path):
    mock_response = MagicMock()
    mock_response.text = FIXTURE_HTML
    mock_response.raise_for_status = MagicMock()
    mock_httpx.get.return_value = mock_response

    cfg = Config(output_dir=tmp_path)

    with patch("notes_gen.sources.web.generate_notes", return_value="## Notes\n\nContent."):
        output_path = run_web_pipeline("https://example.com/asyncio", cfg)

    content = output_path.read_text()
    assert "example.com" in content


# --- Crawl tests ---


def test_same_domain_links_filters_external():
    html = """
    <html><body>
    <a href="/internal">Internal</a>
    <a href="https://example.com/page2">Same domain</a>
    <a href="https://external.com/page">External</a>
    </body></html>
    """
    links = _same_domain_links(html, "https://example.com/start")
    for link in links:
        assert "example.com" in link
    assert not any("external.com" in lnk for lnk in links)


def test_same_domain_links_deduplicates():
    html = """
    <html><body>
    <a href="/page">Page</a>
    <a href="/page">Page again</a>
    <a href="https://example.com/page">Full URL same</a>
    </body></html>
    """
    links = _same_domain_links(html, "https://example.com/start")
    assert len(links) == len(set(links))


@patch("notes_gen.sources.web.httpx")
def test_run_web_crawl_single_page(mock_httpx, tmp_path):
    mock_response = MagicMock()
    mock_response.text = FIXTURE_HTML
    mock_response.raise_for_status = MagicMock()
    mock_httpx.get.return_value = mock_response

    cfg = Config(output_dir=tmp_path, web_max_pages=1, web_max_depth=0)

    with patch("notes_gen.sources.web.generate_notes", return_value="## Notes\n\nContent."):
        output_path = run_web_crawl_pipeline("https://example.com/asyncio", cfg)

    assert output_path.exists()


@patch("notes_gen.sources.web.httpx")
def test_run_web_crawl_respects_max_pages(mock_httpx, tmp_path):
    mock_response = MagicMock()
    mock_response.text = FIXTURE_HTML
    mock_response.raise_for_status = MagicMock()
    mock_httpx.get.return_value = mock_response

    cfg = Config(output_dir=tmp_path, web_max_pages=2, web_max_depth=1)

    with patch("notes_gen.sources.web.generate_notes", return_value="## Notes\n\nContent."):
        run_web_crawl_pipeline("https://example.com/", cfg)

    # Should not visit more than max_pages
    assert mock_httpx.get.call_count <= cfg.web_max_pages
