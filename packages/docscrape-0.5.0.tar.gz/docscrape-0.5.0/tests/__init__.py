"""Tests for docscrape."""
