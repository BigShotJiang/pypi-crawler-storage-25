"""Tests for fileio."""

import importlib.util
import json
import tempfile
import unittest
import warnings
from pathlib import Path
from unittest.mock import patch

from pycinante import fileio
from pycinante.fileio import Path as IOPath


class TestNoImplementedHandlers(unittest.TestCase):
    def test_no_implemented_reader_raises(self):
        with self.assertRaises(NotImplementedError):
            fileio.no_implemented_reader("missing.bin")

    def test_no_implemented_writer_raises(self):
        with self.assertRaises(NotImplementedError):
            fileio.no_implemented_writer({}, "missing.bin")


class TestJsonIO(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.root = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_read_write_json_roundtrip(self):
        payload = {"a": 1, "b": [1, 2, 3], "nested": {"ok": True}}
        path = self.root / "sample.json"

        fileio.save_json(payload, path)
        loaded = fileio.read_json(path)

        self.assertEqual(loaded, payload)

    def test_read_json_invalid(self):
        path = self.root / "bad.json"
        path.write_text("{not json}")

        with self.assertRaises(json.JSONDecodeError):
            fileio.read_json(path)

    def test_read_json_kwargs(self):
        payload = {"x": 1.5}
        path = self.root / "kwargs.json"
        fileio.save_json(payload, path)

        loaded = fileio.read_json(path, parse_float=float)

        self.assertEqual(loaded, payload)

    def test_save_json_with_encoding(self):
        payload = {"text": "hello"}
        path = self.root / "enc.json"

        fileio.save_json(payload, path, encoding="utf-8", ensure_ascii=False)
        loaded = fileio.read_json(path, encoding="utf-8")

        self.assertEqual(loaded, payload)


class TestPickleIO(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.root = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_read_write_pickle_roundtrip(self):
        payload = {"a": 1, "b": [1, 2, 3], "nested": {"ok": True}}
        path = self.root / "sample.pkl"

        fileio.save_pickle(payload, path)
        loaded = fileio.read_pickle(path)

        self.assertEqual(loaded, payload)


class TestTextBytesIO(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.root = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_text_roundtrip(self):
        payload = "hello world"
        path = self.root / "sample.txt"

        fileio.save_text(payload, path)
        loaded = fileio.read_text(path)

        self.assertEqual(loaded, payload)

    def test_text_mode_warning(self):
        path = self.root / "sample.txt"
        fileio.save_text("data", path)

        with warnings.catch_warnings(record=True) as records:
            warnings.simplefilter("always")
            _ = fileio.read_text(path, mode="rb")

        self.assertTrue(any("mode other than 'r'" in str(r.message) for r in records))

    def test_bytes_roundtrip(self):
        payload = b"\x00\x01binary"
        path = self.root / "sample.bin"

        fileio.save_bytes(payload, path)
        loaded = fileio.read_bytes(path)

        self.assertEqual(loaded, payload)

    def test_bytes_mode_warning(self):
        path = self.root / "sample.bin"
        fileio.save_bytes(b"data", path)

        with warnings.catch_warnings(record=True) as records:
            warnings.simplefilter("always")
            _ = fileio.read_bytes(path, mode="r")

        self.assertTrue(any("mode other than 'rb'" in str(r.message) for r in records))

    def test_save_text_and_save_bytes_warning_branches(self):
        txt = self.root / "a.txt"
        blob = self.root / "a.bin"

        with warnings.catch_warnings(record=True) as records:
            warnings.simplefilter("always")
            fileio.save_text("hello", txt, mode="a")
            fileio.save_bytes(b"x", blob, mode="ab")

        messages = [str(item.message) for item in records]
        self.assertTrue(any("mode other than 'w'" in m for m in messages))
        self.assertTrue(any("mode other than 'wb'" in m for m in messages))


class TestFindFileIO(unittest.TestCase):
    def test_find_by_name(self):
        handler = fileio.find_fileio(name="json")
        self.assertIs(handler.reader, fileio.read_json)
        self.assertIs(handler.writer, fileio.save_json)

    def test_find_by_path_suffix(self):
        handler = fileio.find_fileio(path="data.json")
        self.assertIs(handler.reader, fileio.read_json)

    def test_find_by_path_regex(self):
        handler = fileio.find_fileio(path="anything.bin")
        self.assertIs(handler.reader, fileio.read_bytes)

    def test_find_by_path_pathlike(self):
        handler = fileio.find_fileio(path=Path("data.json"))
        self.assertIs(handler.reader, fileio.read_json)

    def test_find_errors(self):
        with self.assertRaises(ValueError):
            fileio.find_fileio()
        with self.assertRaises(ValueError):
            fileio.find_fileio(name="json", path="data.json")
        with self.assertRaises(KeyError):
            fileio.find_fileio(name="missing")
        handler = fileio.find_fileio(path="data.unknown")
        self.assertIs(handler.reader, fileio.read_bytes)

    def test_find_fileio_invalid_regex_fallback_and_no_match(self):
        original = dict(fileio.FILEIO2EXTS)
        try:
            fileio.register_fileio(
                "invalid_regex", reader=fileio.read_text, exts=[".bad["], order=20
            )
            handler = fileio.find_fileio(path="demo.bad[")
            self.assertIs(handler.reader, fileio.read_text)

            fileio.FILEIO2EXTS.pop("bytes", None)
            with self.assertRaises(KeyError):
                fileio.find_fileio(path="no_match.unknown")
        finally:
            fileio.FILEIO2EXTS.clear()
            fileio.FILEIO2EXTS.update(original)


class TestRegisterFileIO(unittest.TestCase):
    def setUp(self):
        self.original = {k: v.copy() for k, v in fileio.FILEIO2EXTS.items()}

    def tearDown(self):
        fileio.FILEIO2EXTS.clear()
        fileio.FILEIO2EXTS.update(self.original)

    def test_register_new_handler(self):
        def _reader(path, **kwargs):
            return "ok"

        def _writer(obj, path, **kwargs):
            return None

        fileio.register_fileio("custom", reader=_reader, writer=_writer, exts=[".cstm"], order=5)
        handler = fileio.find_fileio(name="custom")

        self.assertIs(handler.reader, _reader)
        self.assertIs(handler.writer, _writer)
        self.assertEqual(_reader("x"), "ok")
        self.assertIsNone(_writer({}, "x"))

    def test_update_handler_exts(self):
        fileio.register_fileio("json", exts=[".jsn"])
        self.assertIn(".jsn", fileio.FILEIO2EXTS["json"]["exts"])

    def test_order_priority(self):
        def _reader(path, **kwargs):
            return "custom"

        fileio.register_fileio("custom_json", reader=_reader, exts=[".json"], order=10)
        handler = fileio.find_fileio(path="data.json")

        self.assertIs(handler.reader, _reader)
        self.assertEqual(_reader("x"), "custom")

    def test_register_update_reader_writer_and_order(self):
        def _reader(path, **kwargs):
            return "r"

        def _writer(obj, path, **kwargs):
            return "w"

        fileio.register_fileio("json", reader=_reader, writer=_writer, order=99)

        self.assertIs(fileio.FILEIO2EXTS["json"]["reader"], _reader)
        self.assertIs(fileio.FILEIO2EXTS["json"]["writer"], _writer)
        self.assertEqual(fileio.FILEIO2EXTS["json"]["order"], 99)
        self.assertEqual(fileio.FILEIO2EXTS["json"]["reader"]("x"), "r")
        self.assertEqual(fileio.FILEIO2EXTS["json"]["writer"]({}, "x"), "w")


class TestOptionalDependencies(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.root = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_numpy_optional(self):
        if importlib.util.find_spec("numpy") is None:
            with self.assertRaises(NotImplementedError):
                fileio.read_numpy(self.root / "sample.npy")
            return

        import numpy as np

        path = self.root / "sample.npy"
        payload = np.array([1, 2, 3])
        fileio.save_numpy(payload, path)
        loaded = fileio.read_numpy(path)

        self.assertTrue(np.array_equal(loaded, payload))

    def test_numpy_optional_missing_dependency(self):
        real_import = __import__

        def _fake_import(name, *args, **kwargs):
            if name == "numpy":
                raise ImportError("numpy missing")
            return real_import(name, *args, **kwargs)

        with patch("importlib.util.find_spec", return_value=None):
            with patch("builtins.__import__", side_effect=_fake_import):
                with self.assertRaises(NotImplementedError):
                    fileio.read_numpy(self.root / "sample.npy")

    def test_numpy_npz_optional(self):
        if importlib.util.find_spec("numpy") is None:
            with self.assertRaises(NotImplementedError):
                fileio.save_numpy({"a": [1, 2, 3]}, self.root / "sample.npz")
            return

        import numpy as np

        path = self.root / "sample.npz"
        payload = {"a": np.array([1, 2, 3])}
        fileio.save_numpy(payload, path)
        loaded = fileio.read_numpy(path)

        self.assertIn("a", loaded.files)
        self.assertTrue(np.array_equal(loaded["a"], payload["a"]))

    def test_numpy_npz_optional_missing_dependency(self):
        real_import = __import__

        def _fake_import(name, *args, **kwargs):
            if name == "numpy":
                raise ImportError("numpy missing")
            return real_import(name, *args, **kwargs)

        with patch("importlib.util.find_spec", return_value=None):
            with patch("builtins.__import__", side_effect=_fake_import):
                with self.assertRaises(NotImplementedError):
                    fileio.save_numpy({"a": [1, 2, 3]}, self.root / "sample.npz")

    def test_pandas_csv_optional(self):
        if importlib.util.find_spec("pandas") is None:
            with self.assertRaises(NotImplementedError):
                fileio.read_csv(self.root / "sample.csv")
            return

        import pandas as pd

        path = self.root / "sample.csv"
        payload = pd.DataFrame({"a": [1, 2], "b": ["x", "y"]})
        fileio.save_csv(payload, path, index=False)
        loaded = fileio.read_csv(path)

        self.assertEqual(list(loaded.columns), ["a", "b"])
        self.assertEqual(loaded.shape, (2, 2))

    def test_pandas_csv_optional_missing_dependency(self):
        real_import = __import__

        def _fake_import(name, *args, **kwargs):
            if name == "pandas":
                raise ImportError("pandas missing")
            return real_import(name, *args, **kwargs)

        with patch("importlib.util.find_spec", return_value=None):
            with patch("builtins.__import__", side_effect=_fake_import):
                with self.assertRaises(NotImplementedError):
                    fileio.read_csv(self.root / "sample.csv")

    def test_pandas_excel_optional(self):
        if importlib.util.find_spec("pandas") is None:
            with self.assertRaises(NotImplementedError):
                fileio.read_excel(self.root / "sample.xlsx")
            return

        import pandas as pd

        path = self.root / "sample.xlsx"
        payload = pd.DataFrame({"a": [1, 2], "b": ["x", "y"]})
        fileio.save_excel(payload, path, index=False)
        loaded = fileio.read_excel(path)

        self.assertEqual(list(loaded.columns), ["a", "b"])
        self.assertEqual(loaded.shape, (2, 2))

    def test_pandas_excel_optional_missing_dependency(self):
        real_import = __import__

        def _fake_import(name, *args, **kwargs):
            if name == "pandas":
                raise ImportError("pandas missing")
            return real_import(name, *args, **kwargs)

        with patch("importlib.util.find_spec", return_value=None):
            with patch("builtins.__import__", side_effect=_fake_import):
                with self.assertRaises(NotImplementedError):
                    fileio.read_excel(self.root / "sample.xlsx")

    def test_dependency_importerror_paths_raise_notimplemented(self):
        real_import = __import__

        def _raise_for(target):
            def _fake_import(name, *args, **kwargs):
                if name == target:
                    raise ImportError(f"{target} missing")
                return real_import(name, *args, **kwargs)

            return _fake_import

        with patch("builtins.__import__", side_effect=_raise_for("pandas")):
            with self.assertRaises(NotImplementedError):
                fileio.read_csv(self.root / "a.csv")
            with self.assertRaises(NotImplementedError):
                fileio.save_csv({"a": [1]}, self.root / "a.csv")
            with self.assertRaises(NotImplementedError):
                fileio.read_excel(self.root / "a.xlsx")
            with self.assertRaises(NotImplementedError):
                fileio.save_excel({"a": [1]}, self.root / "a.xlsx")

        with patch("builtins.__import__", side_effect=_raise_for("numpy")):
            with self.assertRaises(NotImplementedError):
                fileio.read_numpy(self.root / "a.npy")
            with self.assertRaises(NotImplementedError):
                fileio.save_numpy([1, 2], self.root / "a.npy")

        with patch("builtins.__import__", side_effect=_raise_for("nibabel")):
            with self.assertRaises(NotImplementedError):
                fileio.read_nibabel(self.root / "a.nii")

        with patch("builtins.__import__", side_effect=_raise_for("h5py")):
            with self.assertRaises(NotImplementedError):
                fileio.read_hdf5(self.root / "a.h5")

    def test_pandas_runtime_importerror_paths_raise_notimplemented(self):
        real_import = __import__

        class _PandasRuntimeFail:
            @staticmethod
            def read_csv(path, **kwargs):
                raise ImportError("csv parser missing")

            @staticmethod
            def read_excel(path, **kwargs):
                raise ImportError("openpyxl missing")

            class DataFrame:
                def __init__(self, obj):
                    self.obj = obj

                def to_csv(self, path, **kwargs):
                    raise ImportError("csv writer missing")

                def to_excel(self, path, **kwargs):
                    raise ImportError("openpyxl missing")

        def _fake_import(name, *args, **kwargs):
            if name == "pandas":
                return _PandasRuntimeFail
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=_fake_import):
            with self.assertRaises(NotImplementedError):
                fileio.read_csv(self.root / "runtime.csv")
            with self.assertRaises(NotImplementedError):
                fileio.save_csv({"a": [1]}, self.root / "runtime.csv")
            with self.assertRaises(NotImplementedError):
                fileio.read_excel(self.root / "runtime.xlsx")
            with self.assertRaises(NotImplementedError):
                fileio.save_excel({"a": [1]}, self.root / "runtime.xlsx")

    def test_read_nibabel_and_hdf5_success_paths(self):
        real_import = __import__

        class _NibStub:
            @staticmethod
            def load(path, **kwargs):
                return {"kind": "nib", "path": str(path), "kwargs": kwargs}

        class _H5Stub:
            @staticmethod
            def File(path, mode, **kwargs):
                return {"kind": "h5", "path": str(path), "mode": mode, "kwargs": kwargs}

        def _fake_import(name, *args, **kwargs):
            if name == "nibabel":
                return _NibStub
            if name == "h5py":
                return _H5Stub
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=_fake_import):
            nib = fileio.read_nibabel(self.root / "sample.nii", force=True)
            h5 = fileio.read_hdf5(self.root / "sample.h5", swmr=True)

        self.assertEqual(nib["kind"], "nib")
        self.assertEqual(h5["mode"], "r")


class TestPathIO(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.root = IOPath(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_read_save_by_suffix(self):
        payload = {"name": "alice", "skills": ["python", "testing"]}
        path = self.root / "sample.json"

        path.save(payload, ensure_ascii=False, indent=2)
        loaded = path.read()

        self.assertEqual(loaded, payload)

    def test_read_save_with_name_override(self):
        payload = {"ok": True}
        path = self.root / "sample.unknown"

        path.save(payload, name="json", ensure_ascii=False)
        loaded = path.read(name="json")

        self.assertEqual(loaded, payload)

    def test_path_read_and_save_notimplemented_branches(self):
        original = dict(fileio.FILEIO2EXTS)
        path = self.root / "x.custom"
        try:
            fileio.register_fileio(
                "custom_reader_missing", writer=fileio.save_text, exts=[".custom"]
            )
            with self.assertRaises(NotImplementedError):
                path.read(name="custom_reader_missing")

            fileio.register_fileio(
                "custom_writer_missing", reader=fileio.read_text, exts=[".custom2"]
            )
            with self.assertRaises(NotImplementedError):
                (self.root / "x.custom2").save("ok", name="custom_writer_missing")
        finally:
            fileio.FILEIO2EXTS.clear()
            fileio.FILEIO2EXTS.update(original)

    def test_non_dataframe_paths_for_csv_and_excel(self):
        data = [{"a": 1, "b": "x"}, {"a": 2, "b": "y"}]
        csv_path = self.root / "data.csv"
        xlsx_path = self.root / "data.xlsx"

        if importlib.util.find_spec("pandas") is None:
            with self.assertRaises(NotImplementedError):
                fileio.save_csv(data, csv_path, index=False)
            with self.assertRaises(NotImplementedError):
                fileio.save_excel(data, xlsx_path, index=False)
            return

        fileio.save_csv(data, csv_path, index=False)
        fileio.save_excel(data, xlsx_path, index=False)

        self.assertTrue(csv_path.exists())
        self.assertTrue(xlsx_path.exists())


if __name__ == "__main__":
    unittest.main()
