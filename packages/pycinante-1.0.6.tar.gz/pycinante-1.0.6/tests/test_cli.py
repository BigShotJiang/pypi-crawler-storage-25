"""Tests for CLI commands."""

import json
import os
import runpy
import tempfile
import unittest
from io import StringIO
from pathlib import Path
from unittest.mock import patch

from pycinante.cli import pjson_command


class TestPjsonCommand(unittest.TestCase):
    """Test cases for pjson command."""

    def setUp(self):
        """Set up test fixtures."""
        self.test_data = {
            "name": "Alice",
            "age": 30,
            "city": "New York",
            "hobbies": ["reading", "coding", "gaming"],
            "address": {"street": "123 Main St", "zip": "10001"},
        }
        self.temp_dir = tempfile.mkdtemp()
        self.test_file = os.path.join(self.temp_dir, "test.json")

        # Create test JSON file
        with open(self.test_file, "w") as f:
            json.dump(self.test_data, f)

    def tearDown(self):
        """Clean up test fixtures."""
        import shutil

        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def test_basic_pretty_print(self):
        """Test basic pretty print functionality."""
        with patch("sys.argv", ["pjson", self.test_file]):
            with patch("sys.stdout", new=StringIO()) as fake_out:
                result = pjson_command()
                output = fake_out.getvalue()

                self.assertEqual(result, 0)
                self.assertIn('"name"', output)
                self.assertIn('"Alice"', output)
                # Check it's formatted (has newlines)
                self.assertGreater(output.count("\n"), 1)

    def test_custom_indent(self):
        """Test custom indentation."""
        with patch("sys.argv", ["pjson", self.test_file, "-i", "4"]):
            with patch("sys.stdout", new=StringIO()) as fake_out:
                result = pjson_command()
                output = fake_out.getvalue()

                self.assertEqual(result, 0)
                # Check for 4-space indentation
                self.assertIn("    ", output)

    def test_file_not_found(self):
        """Test handling of non-existent file."""
        fake_file = os.path.join(self.temp_dir, "nonexistent.json")

        with patch("sys.argv", ["pjson", fake_file]):
            with patch("sys.stderr", new=StringIO()) as fake_err:
                result = pjson_command()
                error_output = fake_err.getvalue()

                self.assertEqual(result, 1)
                self.assertIn("not found", error_output)

    def test_invalid_json(self):
        """Test handling of invalid JSON."""
        invalid_file = os.path.join(self.temp_dir, "invalid.json")
        with open(invalid_file, "w") as f:
            f.write("{invalid json content")

        with patch("sys.argv", ["pjson", invalid_file]):
            with patch("sys.stderr", new=StringIO()) as fake_err:
                result = pjson_command()
                error_output = fake_err.getvalue()

                self.assertEqual(result, 1)
                self.assertIn("Invalid JSON", error_output)

    def test_unicode_support(self):
        """Test handling of Unicode characters."""
        unicode_data = {
            "name": "李明",
            "city": "北京",
            "emoji": "😀🎉",
        }
        unicode_file = os.path.join(self.temp_dir, "unicode.json")
        with open(unicode_file, "w", encoding="utf-8") as f:
            json.dump(unicode_data, f, ensure_ascii=False)

        with patch("sys.argv", ["pjson", unicode_file]):
            with patch("sys.stdout", new=StringIO()) as fake_out:
                result = pjson_command()
                output = fake_out.getvalue()

                self.assertEqual(result, 0)
                self.assertIn("李明", output)
                self.assertIn("北京", output)
                self.assertIn("😀", output)

    def test_generic_exception_branch(self):
        with patch("sys.argv", ["pjson", "fake.json"]):
            with patch("pycinante.cli.read_json", side_effect=RuntimeError("boom")):
                with patch("sys.stderr") as fake_err:
                    result = pjson_command()

        self.assertEqual(result, 1)
        self.assertIn("boom", "".join(str(c.args[0]) for c in fake_err.write.call_args_list))


class TestMainGuards(unittest.TestCase):
    def test_test_modules_main_guards(self):
        root = Path(__file__).parent
        with patch("unittest.main", return_value=None):
            runpy.run_path(str(root / "test_cli.py"), run_name="__main__")
            runpy.run_path(str(root / "test_fileio.py"), run_name="__main__")
            runpy.run_path(str(root / "test_edict.py"), run_name="__main__")


if __name__ == "__main__":
    unittest.main()
