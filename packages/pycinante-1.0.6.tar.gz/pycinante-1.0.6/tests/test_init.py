"""Tests for package-level helpers in pycinante.__init__."""

import unittest
import warnings
from types import SimpleNamespace
from unittest.mock import patch

import pycinante


class TestObjprint(unittest.TestCase):
    def test_objprint_prefers_objprint_when_available(self):
        calls = []

        def _op(obj, **kwargs):
            calls.append((obj, kwargs))

        real_import = __import__

        def _fake_import(name, *args, **kwargs):
            if name == "objprint":
                return SimpleNamespace(op=_op)
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=_fake_import):
            pycinante.objprint({"x": 1}, compact=True)

        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0][0], {"x": 1})
        self.assertEqual(calls[1][1], {"compact": True})

    def test_objprint_falls_back_to_pprint_when_missing(self):
        pprint_calls = []

        def _pprint(obj, **kwargs):
            pprint_calls.append((obj, kwargs))

        real_import = __import__

        def _fake_import(name, *args, **kwargs):
            if name == "objprint":
                raise ImportError("objprint missing")
            if name == "pprint":
                return SimpleNamespace(pprint=_pprint)
            return real_import(name, *args, **kwargs)

        with warnings.catch_warnings(record=True) as records:
            warnings.simplefilter("always")
            with patch("builtins.__import__", side_effect=_fake_import):
                pycinante.objprint({"y": 2}, width=80)

        self.assertEqual(len(pprint_calls), 2)
        self.assertEqual(len(records), 2)


if __name__ == "__main__":
    unittest.main()
