"""Comprehensive tests for edict based on edict-features.v1.md spec."""

import json
import pickle
import tempfile
import unittest
import warnings
from io import StringIO
from pathlib import Path
from unittest.mock import patch

from pycinante.edict import edict


class TempDirMixin:
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.root = Path(self.tmpdir.name)

    def tearDown(self):
        self.tmpdir.cleanup()


class TestEdictConstruction(TempDirMixin, unittest.TestCase):
    def test_construct_empty(self):
        self.assertEqual(edict(), {})
        self.assertEqual(edict({}), {})

    def test_construct_from_mapping_coerces_nested_mapping(self):
        data = edict({"a": {"b": 2}})
        self.assertIsInstance(data.a, edict)
        self.assertEqual(data.a.b, 2)

    def test_construct_from_mapping_coerces_nested_list_elements(self):
        data = edict({"x": [{"y": 1}]})
        self.assertIsInstance(data.x[0], edict)
        self.assertEqual(data.x[0].y, 1)

    def test_construct_from_kwargs(self):
        data = edict(a=1, b=2)
        self.assertEqual(data.a, 1)
        self.assertEqual(data.b, 2)

    def test_construct_from_pairs_iterables(self):
        data1 = edict([["a", 1], ["b", 2]])
        data2 = edict((("a", 1), ("b", 2)))
        self.assertEqual(data1, {"a": 1, "b": 2})
        self.assertEqual(data2, {"a": 1, "b": 2})

    def test_construct_invalid_pairs_raises_valueerror(self):
        with self.assertRaises(ValueError):
            edict([1, 2, 3])

    def test_construct_from_json_string_mapping(self):
        data = edict('{"a": 1, "b": {"c": 2}}')
        self.assertEqual(data.a, 1)
        self.assertIsInstance(data.b, edict)
        self.assertEqual(data.b.c, 2)

    def test_construct_from_json_string_non_mapping_raises(self):
        with self.assertRaises(TypeError):
            edict("[1, 2, 3]")

    def test_construct_from_json_file(self):
        path = self.root / "data.json"
        path.write_text('{"a": 1, "b": {"c": 2}}', encoding="utf-8")
        data = edict(path)
        self.assertEqual(data.a, 1)
        self.assertEqual(data.b.c, 2)

    def test_construct_from_pickle_file(self):
        path = self.root / "data.pkl"
        with open(path, "wb") as fp:
            pickle.dump({"a": 1, "b": [1, 2]}, fp)
        data = edict(path)
        self.assertEqual(data.a, 1)
        self.assertEqual(data.b[1], 2)

    def test_construct_nonexistent_file_raises_filenotfound(self):
        with self.assertRaises(FileNotFoundError):
            edict("/tmp/does-not-exist-edict.json")

    def test_construct_unknown_suffix_file_falls_back_to_json_with_warning(self):
        path = self.root / "data.abc"
        path.write_text('{"a": 1}', encoding="utf-8")
        with warnings.catch_warnings(record=True) as records:
            warnings.simplefilter("always")
            data = edict(path)
        self.assertEqual(data.a, 1)
        self.assertTrue(any("Unknown file format" in str(x.message) for x in records))

    def test_construct_file_must_decode_to_mapping(self):
        path = self.root / "not_mapping.json"
        path.write_text("[1, 2, 3]", encoding="utf-8")
        with self.assertRaises(TypeError):
            edict(path)

    def test_construct_too_many_positional_args_raises(self):
        with self.assertRaises(TypeError):
            edict({"a": 1}, {"b": 2})

    def test_construct_positional_mapping_wins_over_kwargs(self):
        data = edict({"a": 1}, b=2)
        self.assertEqual(data, {"a": 1})
        self.assertNotIn("b", data)

    def test_construct_with_global_default_value(self):
        data = edict({"a": 1}, default=0)
        self.assertEqual(data["missing"], 0)

    def test_construct_with_global_default_callable_one_arg(self):
        data = edict({"a": 1}, default=lambda self: self.a)
        self.assertEqual(data["missing"], 1)

    def test_construct_with_global_default_callable_zero_args(self):
        data = edict({"a": 1}, default=lambda: 42)
        self.assertEqual(data["missing"], 42)

    def test_construct_strict_true_only_dict_list_converted(self):
        obj = object()
        data = edict({"a": obj, "b": (1, 2, 3)}, strict=True)
        self.assertIs(data.a, obj)
        self.assertEqual(data.b, (1, 2, 3))

    def test_construct_strict_true_with_non_mapping_raises(self):
        with self.assertRaises(TypeError):
            edict(object(), strict=True)

    def test_construct_strict_false_converts_iterable_to_list(self):
        data = edict({"a": (1, 2, 3)}, strict=False)
        self.assertEqual(data.a, [1, 2, 3])

    def test_construct_with_reserved_key_name_warns(self):
        with warnings.catch_warnings(record=True) as records:
            warnings.simplefilter("always")
            _ = edict(keys="value", pop="value2")
        self.assertTrue(any("keys" in str(x.message) or "pop" in str(x.message) for x in records))

    def test_construct_nested_pairs_not_converted(self):
        # Only top-level pairs are converted to dict; nested pairs stay as-is
        data = edict({"a": [["x", 1], ["y", 2]]})
        self.assertIsInstance(data.a, list)
        self.assertEqual(data.a[0], ["x", 1])


class TestEdictAccess(unittest.TestCase):
    def setUp(self):
        self.d = edict({"a": {"b": [10, 20, {"c": 30}]}})

    def test_attribute_access_nested(self):
        self.assertEqual(self.d.a.b[1], 20)

    def test_key_expr_call_access(self):
        self.assertEqual(self.d("a.b.@1"), 20)

    def test_key_expr_bracket_access(self):
        self.assertEqual(self.d["a.b.@1"], 20)

    def test_mixed_access(self):
        self.assertEqual(self.d["a"]("b.@2").c, 30)

    def test_key_expr_deep_nested(self):
        self.assertEqual(self.d("a.b.@2.c"), 30)
        self.assertEqual(self.d["a.b.@2.c"], 30)

    def test_negative_index_access(self):
        d = edict({"a": [1, 2, 3]})
        self.assertEqual(d("a.@-1"), 3)
        self.assertEqual(d["a.@-1"], 3)

    def test_slice_access(self):
        d = edict({"a": [1, 2, 3, 4, 5]})
        self.assertEqual(d("a.@1:4"), [2, 3, 4])
        self.assertEqual(d["a.@1:4"], [2, 3, 4])

    def test_missing_key_expr_raises_keyerror_with_detail(self):
        with self.assertRaisesRegex(KeyError, "no_such"):
            _ = self.d("a.no_such")

    def test_missing_index_raises_indexerror(self):
        d = edict({"a": [1]})
        with self.assertRaises(IndexError):
            _ = d("a.@9")

    def test_type_mismatch_dot_on_int_raises_typeerror(self):
        d = edict({"a": 1})
        with self.assertRaises(TypeError):
            _ = d("a.b")

    def test_type_mismatch_at_on_int_raises_typeerror(self):
        d = edict({"a": 1})
        with self.assertRaises(TypeError):
            _ = d("a.@0")

    def test_dot_on_non_mapping_tries_getattr_then_typeerror(self):
        class Obj:
            x = 10

        d = edict({"a": Obj()})
        self.assertEqual(d("a.x"), 10)
        with self.assertRaises(TypeError):
            _ = d("a.y")

    def test_at_on_non_list_tries_getitem_then_typeerror(self):
        class Seq:
            def __getitem__(self, idx):
                if idx == 0:
                    return 99
                raise IndexError

        d = edict({"a": Seq()})
        self.assertEqual(d("a.@0"), 99)
        with self.assertRaises(IndexError):
            _ = d("a.@1")

    def test_getattr_missing_raises_keyerror(self):
        d = edict({"a": 1})
        with self.assertRaises(KeyError):
            _ = d.x

    def test_getattr_private_name_raises_keyerror(self):
        d = edict({"a": 1})
        with self.assertRaises(KeyError):
            _ = d._private

    def test_dict_methods_not_overridden_by_keys(self):
        d = edict(keys="value", items="value2")
        self.assertTrue(callable(d.keys))
        self.assertTrue(callable(d.items))
        self.assertEqual(d["keys"], "value")
        self.assertEqual(d["items"], "value2")

    def test_get_returns_default_on_missing(self):
        d = edict({"a": 1})
        self.assertIsNone(d.get("missing"))
        self.assertEqual(d.get("missing", default=9), 9)

    def test_call_missing_raises_keyerror(self):
        d = edict({"a": 1})
        with self.assertRaises(KeyError):
            d("missing")
        self.assertEqual(d("missing", default=9), 9)

    def test_bracket_raises_keyerror_on_missing_no_default(self):
        d = edict({"a": 1})
        with self.assertRaises(KeyError):
            _ = d["missing"]

    def test_bracket_with_init_default_uses_it(self):
        d = edict({"a": 1}, default=0)
        self.assertEqual(d["missing"], 0)

    def test_call_with_init_default_uses_it(self):
        d = edict({"a": 1}, default=0)
        self.assertEqual(d("missing"), 0)


class TestEdictAssignment(unittest.TestCase):
    def test_basic_key_assignment(self):
        d = edict()
        d["a"] = 1
        self.assertEqual(d.a, 1)

    def test_key_expr_assignment_creates_nested_mapping(self):
        d = edict()
        d["a.b"] = 3
        self.assertEqual(d.a, {"b": 3})

    def test_key_expr_assignment_creates_list_with_gap(self):
        d = edict()
        d["x.@0"] = "first"
        d["x.@2"] = "third"
        self.assertEqual(d.x, ["first", None, "third"])

    def test_key_expr_assignment_coerces_value(self):
        d = edict()
        d["a.b"] = {"c": 1}
        self.assertIsInstance(d.a.b, edict)

    def test_key_expr_on_existing_path(self):
        d = edict({"a": {"b": 1}})
        d["a.b"] = 3
        self.assertEqual(d.a.b, 3)

    def test_attribute_assignment_on_existing_path(self):
        d = edict()
        d.a.b = 3
        self.assertEqual(d.a.b, 3)

    def test_attribute_assignment_on_existing_path_list(self):
        d = edict()
        d.a.b[1] = 3
        self.assertEqual(d.a.b, [None, 3])

    def test_key_expr_assignment_type_conflict_raises(self):
        d = edict({"a": 1})
        with self.assertRaises(TypeError):
            d["a.b"] = 3

    def test_key_expr_list_index_on_non_sequence_raises(self):
        d = edict({"a": 1})
        with self.assertRaises(TypeError):
            d["a.@0"] = 3


class TestEdictUpdate(unittest.TestCase):
    def test_update_returns_self_for_chaining(self):
        d = edict({"a": 1})
        out = d.update(a=2)
        self.assertIs(out, d)
        self.assertEqual(d.a, 2)

    def test_update_plain_key_replaces_value(self):
        d = edict({"a": 1})
        d.update({"a": 2})
        self.assertEqual(d.a, 2)

    def test_update_patch_existing_mapping(self):
        d = edict({"a": {"b": 1, "c": 2}})
        d.update({"a": {"b": 9}})
        self.assertEqual(d.a.b, 9)
        self.assertEqual(d.a.c, 2)

    def test_update_patch_existing_list(self):
        d = edict({"a": [1, 2, 3]})
        d.update({"a": {"@1": 9}})
        self.assertEqual(d.a, [1, 9, 3])

    def test_update_key_expr_for_nested_mapping(self):
        d = edict({"a": {"b": 2}})
        d.update({"a.b": 3})
        self.assertEqual(d.a.b, 3)

    def test_update_key_expr_for_nested_list(self):
        d = edict({"a": {"b": [1, 2]}})
        d.update({"a.b.@1": 3})
        self.assertEqual(d.a.b, [1, 3])

    def test_update_raises_when_too_many_positional_args(self):
        d = edict({"a": 1})
        with self.assertRaises(TypeError):
            d.update({"a": 2}, {"b": 3})

    def test_update_kwargs_override_positional_payload(self):
        d = edict({"a": 1})
        d.update({"a": 2}, a=3)
        self.assertEqual(d.a, 3)


class TestEdictDeletion(unittest.TestCase):
    def test_delitem_existing_key(self):
        d = edict({"a": 1})
        del d["a"]
        self.assertNotIn("a", d)

    def test_delitem_missing_key_raises_keyerror(self):
        d = edict({"a": 1})
        with self.assertRaises(KeyError):
            del d["missing"]

    def test_delattr_existing_key(self):
        d = edict({"a": 1})
        del d.a
        self.assertNotIn("a", d)

    def test_delattr_missing_key_raises_keyerror(self):
        d = edict({"a": 1})
        with self.assertRaises(KeyError):
            del d.missing

    def test_pop_plain_key(self):
        d = edict({"a": 1})
        self.assertEqual(d.pop("a"), 1)
        self.assertNotIn("a", d)

    def test_pop_plain_key_missing_returns_default(self):
        d = edict({"a": 1})
        self.assertIsNone(d.pop("x"))
        self.assertEqual(d.pop("x", 9), 9)

    def test_pop_key_expr_from_mapping(self):
        d = edict({"a": {"b": 2}})
        self.assertEqual(d.pop("a.b"), 2)
        self.assertEqual(d.a, {})

    def test_pop_key_expr_from_list(self):
        d = edict({"a": [0, 1, 2]})
        self.assertEqual(d.pop("a.@1"), 1)
        self.assertEqual(d.a, [0, 2])

    def test_pop_key_expr_parent_missing_returns_default(self):
        d = edict({"a": {"b": 1}})
        self.assertEqual(d.pop("a.x", "fallback"), "fallback")

    def test_pop_key_expr_non_sequence_parent_raises(self):
        d = edict({"a": {"b": 1}})
        with self.assertRaises(TypeError):
            d.pop("a.b.@0")

    def test_pop_key_expr_non_mapping_parent_raises(self):
        d = edict({"a": [1, 2]})
        with self.assertRaises(TypeError):
            d.pop("a.x")

    def test_popitem_and_clear(self):
        d = edict({"a": 1, "b": 2})
        k, v = d.popitem()
        self.assertIn(k, {"a", "b"})
        d.clear()
        self.assertEqual(d, {})


class TestEdictDefault(unittest.TestCase):
    def test_get_default_callable_one_arg(self):
        d = edict({"a": 1})
        self.assertEqual(d.get("missing", default=lambda self: self.a + 1), 2)

    def test_get_default_callable_zero_args(self):
        d = edict({"a": 1})
        self.assertEqual(d.get("missing", default=lambda: 99), 99)

    def test_global_default_value(self):
        d = edict({"a": 1}, default=0)
        self.assertEqual(d("missing"), 0)
        self.assertEqual(d["missing"], 0)

    def test_global_default_callable_zero_args(self):
        d = edict({"a": 1}, default=lambda: 42)
        self.assertEqual(d("missing"), 42)

    def test_method_default_overrides_global(self):
        d = edict({"a": 1}, default=0)
        self.assertEqual(d.get("missing", default=9), 9)

    def test_missing_without_any_default_raises_keyerror(self):
        d = edict({"a": 1})
        with self.assertRaises(KeyError):
            _ = d["missing"]


class TestEdictSerialization(TempDirMixin, unittest.TestCase):
    def test_dump_and_load_json_by_explicit_format(self):
        d = edict({"a": 1, "b": {"c": 2}})
        path = self.root / "data.json"
        out = d.dump(path, format="json", indent=2)
        loaded = edict(path)
        self.assertEqual(out, path)
        self.assertEqual(loaded.b.c, 2)

    def test_dump_and_load_json_by_suffix(self):
        d = edict({"a": 1})
        path = self.root / "data.json"
        d.dump(path)
        loaded = edict(path)
        self.assertEqual(loaded.a, 1)

    def test_dump_and_load_pickle(self):
        d = edict({"a": 1, "b": [1, 2]})
        path = self.root / "data.pkl"
        d.dump(path, format="pickle")
        loaded = edict(path)
        self.assertEqual(loaded.b[1], 2)

    def test_dump_pickle_with_encoding_warns(self):
        d = edict({"a": 1})
        path = self.root / "data.pkl"
        with warnings.catch_warnings(record=True) as records:
            warnings.simplefilter("always")
            d.dump(path, format="pickle", encoding="utf-8")
        self.assertTrue(any("ignored for pickle" in str(x.message) for x in records))

    def test_dump_unsupported_format_raises(self):
        d = edict({"a": 1})
        with self.assertRaises(ValueError):
            d.dump(self.root / "data.bin", format="yaml")

    def test_dumps_returns_valid_json(self):
        d = edict({"a": 1, "b": 2})
        self.assertEqual(json.loads(d.dumps(sort_keys=True)), {"a": 1, "b": 2})

    def test_repr_returns_pretty_structure(self):
        d = edict({"a": 1, "b": {"c": 2}})
        r = repr(d)
        self.assertIn("\n", r)
        self.assertIn("'a': 1", r)
        self.assertIn("'c': 2", r)

    def test_pretty_prints_to_stdout(self):
        d = edict({"a": 1})
        with patch("sys.stdout", new=StringIO()) as fake_out:
            d.pretty(color=False)
            self.assertEqual(json.loads(fake_out.getvalue()), {"a": 1})

    def test_pretty_supports_custom_file(self):
        d = edict({"a": 1})
        buf = StringIO()
        d.pretty(file=buf, color=False)
        self.assertEqual(json.loads(buf.getvalue()), {"a": 1})

    def test_pretty_with_color_contains_ansi(self):
        d = edict({"a": {"b": 1}})
        with patch("sys.stdout", new=StringIO()) as fake_out:
            d.pretty()
            self.assertIn("\033[", fake_out.getvalue())

    def test_pretty_length_truncates(self):
        d = edict({"a": [0, 1, 2, 3, 4, 5]})
        with patch("sys.stdout", new=StringIO()) as fake_out:
            d.pretty(length=4, color=False)
            self.assertEqual(json.loads(fake_out.getvalue())["a"], [0, "...", 4, 5])

    def test_pretty_depth_abridges(self):
        d = edict(a=2, b={"c": 3})
        with patch("sys.stdout", new=StringIO()) as fake_out:
            d.pretty(depth=1, sort_keys=True, color=False)
            self.assertEqual(json.loads(fake_out.getvalue()), {"a": 2, "b": "..."})

    def test_pretty_negative_length_raises(self):
        d = edict({"a": 1})
        with self.assertRaises(ValueError):
            d.pretty(length=-1)

    def test_str_returns_summary(self):
        d = edict({"a": {"b": 2}})
        text = str(d)
        self.assertIn("keys=", text)
        self.assertIn("depth=", text)
        self.assertIn("size=", text)
        self.assertIn("frozen=", text)


class TestEdictFreezeAndLite(unittest.TestCase):
    def test_lite_returns_builtin_containers_recursively(self):
        d = edict({"a": {"b": [1, {"c": 2}]}})
        out = d.lite()
        self.assertIsInstance(out, dict)
        self.assertIsInstance(out["a"], dict)
        self.assertIsInstance(out["a"]["b"], list)
        self.assertIsInstance(out["a"]["b"][1], dict)

    def test_freeze_is_idempotent(self):
        d = edict({"a": 1})
        out1 = d.freeze()
        out2 = d.freeze()
        self.assertIs(out1, d)
        self.assertIs(out2, d)
        self.assertTrue(d.frozen)

    def test_freeze_converts_list_to_tuple(self):
        d = edict({"a": [1, 2]}).freeze()
        self.assertIsInstance(d.a, tuple)

    def test_freeze_blocks_mutation(self):
        d = edict({"a": {"b": [1, 2]}, "x": 1}).freeze()
        with self.assertRaises(TypeError):
            d["k"] = 1
        with self.assertRaises(TypeError):
            del d["x"]
        with self.assertRaises(TypeError):
            d.update(a=2)
        with self.assertRaises(TypeError):
            d.pop("x")
        with self.assertRaises(TypeError):
            d.popitem()
        with self.assertRaises(TypeError):
            d.clear()
        with self.assertRaises(TypeError):
            d.setdefault("y", 1)
        with self.assertRaises(TypeError):
            d.a = 3
        with self.assertRaises(TypeError):
            del d.a


class TestEdictSetDefault(unittest.TestCase):
    def test_setdefault_plain_key(self):
        d = edict({"a": 1})
        self.assertEqual(d.setdefault("a", 9), 1)
        self.assertEqual(d.setdefault("b", 9), 9)
        self.assertEqual(d.b, 9)

    def test_setdefault_key_expr_create_mapping_path(self):
        d = edict()
        self.assertEqual(d.setdefault("a.b", 3), 3)
        self.assertEqual(d.a.b, 3)

    def test_setdefault_key_expr_preserve_existing(self):
        d = edict({"a": {"b": 2}})
        self.assertEqual(d.setdefault("a.b", 9), 2)
        self.assertEqual(d.a.b, 2)

    def test_setdefault_terminal_list_index(self):
        d = edict({"a": [1]})
        self.assertEqual(d.setdefault("a.@1", 9), 9)
        self.assertEqual(d.a, [1, 9])

    def test_setdefault_terminal_list_index_extends_list(self):
        d = edict({"a": [1]})
        self.assertEqual(d.setdefault("a.@3", 9), 9)
        self.assertEqual(d.a, [1, None, None, 9])

    def test_setdefault_intermediate_list_index(self):
        d = edict({"a": [{"b": 1}]})
        self.assertEqual(d.setdefault("a.@0.c", 9), 9)
        self.assertEqual(d.a[0].c, 9)


class TestEdictInternalProtection(unittest.TestCase):
    def test_frozen_property_is_read_only(self):
        d = edict({"a": 1})
        with self.assertRaises(AttributeError):
            d.frozen = True

    def test_internal_freeze_flag_is_protected(self):
        d = edict({"a": 1})
        with self.assertRaises(AttributeError):
            d._41996764d3df18cd = True

    def test_delattr_internal_freeze_flag_is_protected(self):
        d = edict({"a": 1})
        with self.assertRaises(AttributeError):
            del d._41996764d3df18cd


class TestEdictCompatibility(unittest.TestCase):
    def test_underscore_keys_accessible_via_bracket(self):
        d = edict(_a=1)
        self.assertEqual(d["_a"], 1)

    def test_key_expr_preferred_over_attribute_chain(self):
        # d['a.@0'] = 1 is valid; d.a.@0 = 1 is invalid Python syntax
        d = edict()
        d["a.@0"] = 1
        self.assertEqual(d.a, [1])


class TestMy(unittest.TestCase):
    def test_case1(self):
        d = edict({1: 2, 3: {"a": "b"}})
        d._a = 10
        self.assertIn("_a", d)
        d.a = 20
        self.assertEqual(d.__repr__(), edict({1: 2, 3: {"a": "b"}, "_a": 10, "a": 20}).__repr__())


if __name__ == "__main__":
    unittest.main()
