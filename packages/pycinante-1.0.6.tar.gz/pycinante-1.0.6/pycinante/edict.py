"""Enhanced dictionary with attribute/path access and convenient I/O helpers."""

from __future__ import annotations

import dis
import inspect
import json
import os
import sys
import warnings
from collections.abc import Mapping, MutableMapping, MutableSequence, Sequence
from pathlib import Path

from .fileio import find_fileio

_MISSING_SENTINEL = object()  # sentinel for missing default value


def _is_in_assignment_chain(frame):
    """Check if *frame* is executing a ``LOAD_ATTR`` that is part of a
    chained assignment such as ``d.a.b = 3`` or ``d.a[0] = 3``.

    The heuristic scans the bytecode forward from the current instruction.
    It allows ``LOAD_ATTR``, ``LOAD_CONST`` and ``BINARY_SUBSCR`` as
    intermediate operations and succeeds when it finds ``STORE_ATTR`` or
    ``STORE_SUBSCR``.
    """
    if frame is None:
        return False
    instructions = list(dis.get_instructions(frame.f_code))
    lasti = frame.f_lasti

    # Locate the instruction at / after f_lasti.
    idx = 0
    for i, instr in enumerate(instructions):
        if instr.offset >= lasti:
            idx = i
            break

    for instr in instructions[idx + 1 :]:
        if instr.opname in ("STORE_ATTR", "STORE_SUBSCR"):
            return True
        if instr.opname in ("LOAD_ATTR", "LOAD_CONST", "BINARY_SUBSCR"):
            continue
        break
    return False


class _EdictNode:
    """Placeholder node for chained attribute/index assignment on missing paths.

    When an intermediate key in a chain like ``d.a.b = 3`` does not yet
    exist, :meth:`edict.__getattr__` returns an ``_EdictNode`` instead of
    raising :class:`KeyError`.  The node records the path from the root
    ``edict`` and flushes the assignment back when it is finally written
    to via ``__setattr__`` or ``__setitem__``.
    """

    __slots__ = ("_root", "_tokens")

    def __init__(self, root, tokens):
        object.__setattr__(self, "_root", root)
        object.__setattr__(self, "_tokens", tokens)

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return _EdictNode(self._root, self._tokens + [name])

    def __getitem__(self, key):
        token = f"@{key}" if isinstance(key, int) else str(key)
        return _EdictNode(self._root, self._tokens + [token])

    def __setattr__(self, name, value):
        if name.startswith("_"):
            object.__setattr__(self, name, value)
            return
        key_expr = ".".join(self._tokens + [name])
        self._root[key_expr] = value

    def __setitem__(self, key, value):
        token = f"@{key}" if isinstance(key, int) else str(key)
        key_expr = ".".join(self._tokens + [token])
        self._root[key_expr] = value

    def _resolve(self):
        key_expr = ".".join(self._tokens)
        return self._root._resolve_key_expr_strict(key_expr)

    def __repr__(self):
        try:
            return repr(self._resolve())
        except KeyError:
            return f"_EdictNode({'.'.join(self._tokens)!r})"

    def __str__(self):
        return str(self._resolve())

    def __eq__(self, other):
        if isinstance(other, _EdictNode):
            return self._tokens == other._tokens and self._root is other._root
        return self._resolve() == other

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(self._resolve())

    def __bool__(self):
        return bool(self._resolve())

    def __len__(self):
        return len(self._resolve())

    def __iter__(self):
        return iter(self._resolve())

    def __contains__(self, item):
        return item in self._resolve()

    def __add__(self, other):
        return self._resolve() + other

    def __radd__(self, other):
        return other + self._resolve()

    def __sub__(self, other):
        return self._resolve() - other

    def __rsub__(self, other):
        return other - self._resolve()

    def __mul__(self, other):
        return self._resolve() * other

    def __rmul__(self, other):
        return other * self._resolve()

    def __truediv__(self, other):
        return self._resolve() / other

    def __rtruediv__(self, other):
        return other / self._resolve()

    def __floordiv__(self, other):
        return self._resolve() // other

    def __rfloordiv__(self, other):
        return other // self._resolve()

    def __mod__(self, other):
        return self._resolve() % other

    def __rmod__(self, other):
        return other % self._resolve()

    def __pow__(self, other):
        return self._resolve() ** other

    def __rpow__(self, other):
        return other ** self._resolve()

    def __lt__(self, other):
        return self._resolve() < other

    def __le__(self, other):
        return self._resolve() <= other

    def __gt__(self, other):
        return self._resolve() > other

    def __ge__(self, other):
        return self._resolve() >= other

    def __int__(self):
        return int(self._resolve())

    def __float__(self):
        return float(self._resolve())

    def __index__(self):
        return self._resolve().__index__()

    def __call__(self, *args, **kwargs):
        return self._resolve()(*args, **kwargs)


class edict(dict):
    """Enhanced dictionary with attribute access, key-path access, and file I/O helpers.

    `edict` is a dict subclass that supports:
        - Attribute-style access (e.g., `obj.a`)
        - Dot-path and list-index key expressions (e.g., `"a.b.@1"`)
        - Nested patch updates via `update`
        - Global/per-call default fallback values
        - JSON/pickle load and dump helpers
        - Freeze mode to prevent later mutation

    Args:
        value (optional): One of the following:
            - Mapping object
            - Key-value pairs iterable (e.g., `[("a", 1), ("b", 2)]`)
            - JSON string
            - Local `.json` / `.pkl` / `.pickle` file path
        default (optional): Fallback value for missing keys. If callable,
            it receives the current `edict` instance as the first argument.
        **kwargs: Additional key-value pairs for initialization. If `value`
            is a file/JSON input, extra kwargs are forwarded to the loader.

    Raises:
        TypeError: For unsupported input types, invalid key-path traversal,
            or mutation after `freeze()`.
        ValueError: For malformed key expressions or unsupported dump format.
        KeyError: When key lookup fails and no effective default is available.

    Examples:
        # Basic construction and path access.
        >>> d = edict({"a": {"b": [1, 2]}})
        >>> d.a.b[1]
        2
        >>> d("a.b.@1")
        2

        # Nested update with key expression.
        >>> d.update({"a.b.@1": 3})
        >>> d.a.b
        [1, 3]

        # Missing-key fallback with setdefault and callable default.
        >>> d.setdefault("a.c", 9)
        9
        >>> d.get("missing", default=lambda self: self.a.c)
        9

        # Freeze to prevent mutation.
        >>> frozen = edict({"x": 1}).freeze()
        >>> frozen.frozen
        True

        # Dump to JSON and load back from file path.
        >>> _ = d.dump("data.json", format="json", indent=2)
        >>> loaded = edict("data.json")
        >>> loaded.a.b[1]
        3
    """

    def get(self, key, default=None):
        try:
            if edict._is_key_expr(key):
                return self._resolve_key_expr_strict(key)
            if key in self:
                return self[key]
        except (KeyError, IndexError, TypeError):
            pass
        if callable(default):
            sig = inspect.signature(default)
            if len(sig.parameters) == 0:
                return default()
            return default(self)
        return default

    def update(self, *args, **kwargs):  # pyright: ignore[reportIncompatibleMethodOverride]
        self._assert_mutable()
        payload = {}

        if len(args) > 1:
            raise TypeError(f"Update expected at most 1 positional argument, got {len(args)}")
        if args:
            arg0 = args[0]
            payload.update(arg0 if isinstance(arg0, Mapping) else dict(arg0))

        if kwargs:
            payload.update(kwargs)

        for key, value in payload.items():
            if key in _RESERVED_KEYS:
                warnings.warn(f"Key {key!r} conflicts with internal name")
            if edict._is_key_expr(key):
                # mapping value with key_expr, patch the component at key_expr with the mapping
                # e.g. a.b = {c: v} (a.b.c = v), a.b.@i = {c: v} (a.b[i] = {c: v}),
                # a.b = {@i: v} (a.b[i] = v)
                if edict._is_rtype_mapping(value):
                    try:
                        target = self._resolve_key_expr_strict(key)  # a.b component
                    except (KeyError, IndexError, ValueError, TypeError):
                        target = None

                    # a.b exists (mapping or container), then patch value into a.b
                    if edict._is_mapping_or_container(target):
                        edict._patch_component(target, value)
                        continue

                    # a.b does not exist, but value is a mapping with key_expr,
                    # e.g. a.b = {c.d: v}, then create a.b as a dict,
                    # patch the value into it with key_expr in patch,
                    # then assign a.b to the path of key_expr.
                    if any(edict._is_key_expr(k) for k in value.keys()):
                        component = []
                        if not all(isinstance(k, str) and k.startswith("@") for k in value.keys()):
                            component = edict()
                        edict._assign_by_key_tokens(self, edict._tokenize_key_expr(key), component)
                        edict._patch_component(self._resolve_key_expr_strict(key), value)
                        continue

                # non-mapping value with key_expr, directly assign to the path,
                # e.g. a.b.c = v, a.b.@i = v
                edict._assign_by_key_tokens(self, edict._tokenize_key_expr(key), value)
                continue

            if (
                isinstance(value, Mapping)
                and key in self
                and edict._is_mapping_or_container(self[key])
            ):
                # key is not a key_expr, but value is a mapping with key_expr,
                # patch the component at key with the mapping
                edict._patch_component(self[key], value)
                continue

            # otherwise directly assign value to key, if value is a mapping with key_expr,
            # it will be processed in the next loop with key_expr in patch
            if edict._is_rtype_mapping(value) and any(edict._is_key_expr(k) for k in value.keys()):
                if key not in self:
                    if all(isinstance(k, str) and k.startswith("@") for k in value.keys()):
                        self[key] = []
                    else:
                        self[key] = edict()
                edict._patch_component(self[key], value)
                continue

            # most common case, directly assign value to key
            self[key] = value

        # return self for chaining, even though dict.update returns None,
        # but it's more convenient to return self for edict.update
        return self

    def pop(self, key, default=None):
        self._assert_mutable()
        if not edict._is_key_expr(key):
            out = super().pop(key, _MISSING_SENTINEL)
            if out is _MISSING_SENTINEL:
                return self._resolve_default(default, key=key)
            return out

        tokens = self._tokenize_key_expr(key)
        parent = self
        if len(tokens) > 1:
            parent_expr = ".".join(tokens[:-1])
            try:
                parent = self._resolve_key_expr_strict(parent_expr)
            except (KeyError, IndexError, ValueError, TypeError):
                return self._resolve_default(default, key=key)

        last_token = tokens[-1]
        if last_token.startswith("@"):
            if not edict._is_rtype_container(parent):
                raise TypeError(f"Key expression {key} points to a non-sequence parent")

            index = edict._parse_at_index(last_token)
            try:
                return parent.pop(index)
            except IndexError:
                return self._resolve_default(default, key=key)

        if not edict._is_wtype_mapping(parent):
            raise TypeError(f"Key expression {key} points to a non-mapping parent")

        out = dict.pop(parent, last_token, _MISSING_SENTINEL)
        if out is _MISSING_SENTINEL:
            return self._resolve_default(default, key=key)
        return out

    def popitem(self):
        self._assert_mutable()
        return super().popitem()

    def clear(self):
        self._assert_mutable()
        return super().clear()

    def setdefault(self, key, default=None):
        self._assert_mutable()
        coerced_default = self._coerce_value(default)
        if not edict._is_key_expr(key):
            return super().setdefault(key, coerced_default)

        tokens = self._tokenize_key_expr(key)
        current = self
        for i, token in enumerate(tokens[:-1]):
            if token.startswith("@"):
                if not edict._is_rtype_container(current):
                    raise TypeError(f"Token {token} requires a readable container")
                index = edict._parse_at_index(token)
                try:
                    current = edict._resolve_at_container(current, index)
                except (IndexError, KeyError, TypeError) as exc:
                    raise TypeError(f"Cannot descend through non-container at {token}") from exc
                continue

            if not edict._is_rtype_mapping(current):
                raise TypeError(f"Token {token} requires a writable mapping container")
            if token not in current:
                current[token] = edict._new_component_for(tokens[i + 1])
            elif not edict._is_mapping_or_container(current[token]):
                raise TypeError(f"Cannot descend through non-mapping at {token}")

            current = current[token]

        leaf_key = tokens[-1]
        if leaf_key.startswith("@"):
            index = edict._parse_at_index(leaf_key)
            if not edict._is_rtype_container(current):
                raise TypeError(f"Key expression {key} points to a non-sequence parent")
            if not edict._is_wtype_container(current):
                raise TypeError(f"Key expression {key} points to a non-writable container")
            while len(current) <= index:
                current.append(None)
            if current[index] is None:
                current[index] = coerced_default
            return current[index]

        if not edict._is_rtype_mapping(current):
            raise TypeError(f"Key expression {key} points to a non-mapping parent")

        return current.setdefault(leaf_key, coerced_default)

    def freeze(self):
        if self.frozen:
            return self
        keys = list(self.keys())
        for key in keys:
            super().__setitem__(key, self._freeze_component(self[key]))
        self._41996764d3df18cd = True
        return self

    def lite(self):
        return {k: edict._materialize_builtin(v) for k, v in self.items()}

    def dump(self, path, format=None, encoding=None, **kwargs):
        if format not in ("json", "pickle", None):
            raise ValueError(f"Unsupported dump format {format}, expected 'json' or 'pickle'")

        try:
            handler = find_fileio(name=format) if format is not None else find_fileio(path=path)
        except (ValueError, KeyError) as exc:
            raise ValueError(
                f"Failed to detect file format from {path}, specify it explicitly"
            ) from exc

        if handler is None:
            raise ValueError(f"Failed to detect file format from {path}, specify it explicitly")

        target = Path(path)
        if format == "json" or target.suffix == ".json":
            handler.writer(self.lite(), target, encoding=encoding, **kwargs)
            return path

        # for pickle format, saving edict directly without converting to builtin dict
        if encoding is not None:
            warnings.warn("Encoding parameter is ignored for pickle formats")
        handler.writer(self, target, **kwargs)
        return path

    def dumps(self, **kwargs):
        data = self.lite()
        if kwargs.get("sort_keys"):
            try:
                return json.dumps(data, **kwargs)
            except TypeError:
                # Mixed key types can't be sorted; drop sort_keys and retry
                kwargs = {k: v for k, v in kwargs.items() if k != "sort_keys"}
                return json.dumps(data, **kwargs)
        return json.dumps(data, **kwargs)

    @staticmethod
    def _repr_pretty(obj, indent=2, current=0):
        spaces = " " * current
        next_spaces = " " * (current + indent)

        if isinstance(obj, dict) and not isinstance(obj, (str, bytes)):
            if not obj:
                return "{}"
            items = []
            for k, v in obj.items():
                key_str = repr(k)
                val_str = edict._repr_pretty(v, indent, current + indent)
                items.append(f"{next_spaces}{key_str}: {val_str}")
            return "{\n" + ",\n".join(items) + "\n" + spaces + "}"

        if isinstance(obj, list):
            if not obj:
                return "[]"
            items = []
            for v in obj:
                val_str = edict._repr_pretty(v, indent, current + indent)
                items.append(f"{next_spaces}{val_str}")
            return "[\n" + ",\n".join(items) + f"\n{spaces}]"

        if isinstance(obj, tuple):
            if not obj:
                return "()"
            items = []
            for v in obj:
                val_str = edict._repr_pretty(v, indent, current + indent)
                items.append(f"{next_spaces}{val_str}")
            return "(\n" + ",\n".join(items) + f"\n{spaces})"

        return repr(obj)

    def pretty(self, indent=2, depth=None, length=None, color=True, **kwargs):
        file = kwargs.pop("file", sys.stdout)
        data = self._abridge_for_display(self.lite(), depth, length=length)
        text = json.dumps(data, indent=indent, ensure_ascii=False, **kwargs)
        rendered = self._render_ansi_depth_colors(text) if color else text
        print(rendered, file=file)

    @property
    def frozen(self):
        return self.__dict__.get("_41996764d3df18cd", False)

    @classmethod
    def _resolve_input_source(cls, value, **kwargs):
        if isinstance(value, Mapping):
            return value

        if isinstance(value, (str, os.PathLike, Path)):
            if isinstance(value, str):
                text = value.strip()
                if text.startswith(("{", "[")):
                    parsed = json.loads(text, **kwargs)
                    if not isinstance(parsed, Mapping):
                        raise TypeError("JSON input for edict must decode to a mapping")
                    return parsed

            path = Path(value)
            if not path.exists():
                raise FileNotFoundError(f"File not found: {path}")
            if not path.is_file():
                raise TypeError(f"Path is not a file: {path}")
            if path.suffix in (".json", ".pkl", ".pickle"):
                handler = find_fileio(path=path)
            else:
                warnings.warn(f"Unknown file format for {path.suffix}, default to JSON")
                handler = find_fileio(name="json")

            data = handler.reader(path, **kwargs)
            if not isinstance(data, Mapping):
                raise TypeError(f"Data loaded from {path} must be a mapping")
            return data

        if isinstance(value, (list, tuple)):
            try:
                return dict(value)
            except Exception as exc:
                raise ValueError("Expected key-value pairs like [[k, v], ...]") from exc

        raise TypeError(
            f"Unsupported edict input type {type(value).__name__}, "
            f"expected a mapping, key-value pairs, or a local JSON/pickle file"
        )

    @classmethod
    def _coerce_value(cls, value, strict=False):
        if isinstance(value, edict):
            return value
        if isinstance(value, Mapping):
            return cls(value, strict=strict)
        if isinstance(value, (list, tuple)):
            if strict and not isinstance(value, list):
                return value
            return [cls._coerce_value(x, strict=strict) for x in value]
        return value

    @staticmethod
    def _is_key_expr(key):
        return isinstance(key, str) and ("." in key or key.startswith("@"))

    @staticmethod
    def _tokenize_key_expr(key_expr):
        if not isinstance(key_expr, str) or not key_expr:
            raise ValueError("Key expression must be a non-empty string")
        return key_expr.split(".")

    @staticmethod
    def _parse_at_index(token):
        if not token.startswith("@"):
            raise ValueError(f"Invalid list token {token}")
        body = token[1:]
        if ":" in body:
            parts = body.split(":", 1)
            start = int(parts[0]) if parts[0] else None
            stop = int(parts[1]) if parts[1] else None
            return slice(start, stop)
        return int(body)

    @staticmethod
    def _new_component_for(next_token):
        if isinstance(next_token, str) and next_token.startswith("@"):
            return []
        return edict()

    @staticmethod
    def _is_wtype_container(obj):
        return isinstance(obj, MutableSequence)

    @staticmethod
    def _is_rtype_container(obj):
        return isinstance(obj, Sequence) and not isinstance(obj, (str, bytes, bytearray))

    @staticmethod
    def _is_container(obj):
        return edict._is_wtype_container(obj) and edict._is_rtype_container(obj)

    @staticmethod
    def _assign_at_container(seq, index, value):
        if edict._is_wtype_container(seq):
            if isinstance(seq, list):
                if isinstance(index, slice):
                    raise TypeError("Slice assignment not supported in key_expr")
                while len(seq) <= index:
                    seq.append(None)
            getattr(seq, "__setitem__")(index, edict._coerce_value(value))
        else:
            raise TypeError(f"Cannot assign to index {index} in object of type {type(seq)}")

    @staticmethod
    def _resolve_at_container(seq, index):
        if edict._is_rtype_container(seq):
            try:
                return getattr(seq, "__getitem__")(index)
            except (IndexError, KeyError, TypeError) as exc:
                raise type(exc)(f"Index {index} not found in container") from exc
        else:
            raise TypeError(f"Cannot resolve index {index} in object of type {type(seq)}")

    @staticmethod
    def _is_wtype_mapping(obj):
        return isinstance(obj, MutableMapping)

    @staticmethod
    def _is_rtype_mapping(obj):
        return isinstance(obj, Mapping)

    @staticmethod
    def _is_mapping(obj):
        return edict._is_wtype_mapping(obj) and edict._is_rtype_mapping(obj)

    @staticmethod
    def _is_mapping_or_container(obj):
        return edict._is_mapping(obj) or edict._is_container(obj)

    @staticmethod
    def _assign_in_mapping(mapping, key, value):
        if hasattr(mapping, "__setitem__"):
            getattr(mapping, "__setitem__")(key, edict._coerce_value(value))
        elif hasattr(mapping, "__setattr__"):
            getattr(mapping, "__setattr__")(key, edict._coerce_value(value))
        else:
            raise TypeError(f"Cannot assign key {key} in object of type {type(mapping)}")

    @staticmethod
    def _resolve_in_mapping(mapping, key):
        if hasattr(mapping, "__getitem__"):
            return getattr(mapping, "__getitem__")(key)
        elif hasattr(mapping, "__getattr__"):
            return getattr(mapping, "__getattr__")(key)
        else:
            raise TypeError(f"Cannot resolve key {key} in object of type {type(mapping)}")

    @staticmethod
    def _assign_by_key_tokens(component, tokens, value):
        current = component
        for i, token in enumerate(tokens):
            is_last_token = i == len(tokens) - 1

            if token.startswith("@"):
                index = edict._parse_at_index(token)
                if is_last_token:
                    edict._assign_at_container(current, index, value)
                    return None

                if not edict._is_rtype_container(current):
                    raise TypeError(f"Token {token} requires a readable container")
                try:
                    cv = edict._resolve_at_container(current, index)
                except (IndexError, KeyError, TypeError) as exc:
                    if isinstance(current, list) and isinstance(index, int) and index >= 0:
                        while len(current) <= index:
                            current.append(None)
                        cv = current[index]
                    else:
                        raise TypeError(f"Cannot descend through non-container at {token}") from exc

                if cv is None:
                    if not edict._is_wtype_container(current):
                        raise TypeError(f"Token {token} requires a writable container")
                    getattr(current, "__setitem__")(
                        index, (cv := edict._new_component_for(tokens[i + 1]))
                    )
                elif not (edict._is_container(cv) or edict._is_mapping(cv)):
                    raise TypeError(f"Cannot descend through non-container at {token}")

                current = cv
                continue

            if is_last_token:
                edict._assign_in_mapping(current, token, value)
                return None

            if not edict._is_rtype_mapping(current):
                raise TypeError(f"Token {token} requires a readable mapping container")

            if token not in current:
                if not edict._is_wtype_mapping(current):
                    raise TypeError(f"Token {token} requires a writable mapping container")
                new_component = edict._new_component_for(tokens[i + 1])
                edict._assign_in_mapping(current, token, new_component)
                current = edict._resolve_in_mapping(current, token)
            else:
                cv = edict._resolve_in_mapping(current, token)
                if not (edict._is_container(cv) or edict._is_mapping(cv)):
                    raise TypeError(f"Cannot descend through non-container at {token}")
                current = cv

    @staticmethod
    def _patch_component(component, patch):
        if not isinstance(patch, Mapping):
            raise TypeError(f"Patch must be a mapping, got {type(patch)}")

        # a.b = {@i: v}, patch the list b with index i and value v, a.b[i] = v
        if edict._is_container(component):
            for key, value in patch.items():
                if not isinstance(key, str) or not key.startswith("@"):
                    raise TypeError("List patches must use '@<index>' keys")
                edict._assign_by_key_tokens(component, edict._tokenize_key_expr(key), value)
            return component

        # a.b = {c: v}, patch the dict b with key c and value v,
        # also support nested patch like a.b = {c: {d: v}}, a.b = {c: {@i: v}},
        # or a.b = {'c.d': v} and a.b = {'c.@i': v} with key_expr in patch
        if edict._is_mapping(component):
            for key, value in patch.items():
                if edict._is_key_expr(key):
                    edict._assign_by_key_tokens(component, edict._tokenize_key_expr(key), value)
                    continue

                if (
                    isinstance(value, Mapping)
                    and key in component
                    and edict._is_mapping_or_container(component[key])
                ):
                    # a.b = {c: v}, c exists in b and b[c] is a mapping or container,
                    # then patch value into b[c], otherwise directly assign b[c] = v
                    edict._patch_component(component[key], value)
                else:
                    # otherwise directly assign b[c] = v, if value is a mapping with key_expr,
                    # it will be processed in the next loop with key_expr in patch
                    edict._assign_in_mapping(component, key, edict._coerce_value(value))
            return component

    @staticmethod
    def _freeze_component(component):
        if isinstance(component, edict):
            return component.freeze()
        if isinstance(component, Mapping):
            return edict(component).freeze()
        if isinstance(component, list):
            return tuple(edict._freeze_component(x) for x in component)
        return component

    @staticmethod
    def _materialize_builtin(component):
        if isinstance(component, Mapping):
            return {k: edict._materialize_builtin(v) for k, v in component.items()}
        if isinstance(component, (list, tuple)):
            return type(component)((edict._materialize_builtin(v) for v in component))
        return component

    @staticmethod
    def _abridge_for_display(component, depth, length=None, current=0):
        if length is not None and length < 0:
            raise ValueError("length must be >= 0")
        if depth is not None and current >= depth:
            if edict._is_rtype_mapping(component) or edict._is_rtype_container(component):
                return "..."
            return component

        next_level = current + 1
        if edict._is_rtype_mapping(component):
            items = list(component.items())
            if length is not None and len(items) > length:
                if length == 0:
                    return {}
                if length == 1:
                    return {"...": "..."}

                head_count = (length - 1) // 2
                tail_count = length - 1 - head_count

                out = {
                    k: edict._abridge_for_display(v, depth, length, next_level)
                    for k, v in items[:head_count]
                }
                out["..."] = "..."
                for k, v in items[-tail_count:]:
                    out[k] = edict._abridge_for_display(v, depth, length, next_level)
                return out

            return {
                k: edict._abridge_for_display(v, depth, length, current=next_level)
                for k, v in items
            }

        if edict._is_rtype_container(component):
            values = list(component)
            if length is not None and len(values) > length:
                if length == 0:
                    return []
                if length == 1:
                    return ["..."]

                head_count = (length - 1) // 2
                tail_count = length - 1 - head_count

                # fmt: off
                return [
                    *[edict._abridge_for_display(v, depth, length, next_level)
                      for v in values[:head_count]],
                    "...",
                    *[edict._abridge_for_display(v, depth, length, next_level)
                      for v in values[-tail_count:]]]
                # fmt: on

            return [
                edict._abridge_for_display(v, depth, length=length, current=next_level)
                for v in values
            ]

        return component

    @staticmethod
    def _render_ansi_depth_colors(text):
        palette = ["\033[36m", "\033[33m", "\033[32m", "\033[35m"]
        reset = "\033[0m"
        lines = text.splitlines()
        colored = []
        for line in lines:
            stripped = line.lstrip()
            indent = (len(line) - len(stripped)) // 2
            color = palette[indent % len(palette)]
            colored.append(f"{color}{line}{reset}" if stripped else line)
        return "\n".join(colored)

    @staticmethod
    def _count_keys(value):
        if edict._is_rtype_mapping(value):
            return len(value) + sum(edict._count_keys(v) for v in value.values())
        if edict._is_rtype_container(value):
            return sum(edict._count_keys(v) for v in value)
        return 0

    @staticmethod
    def _trace_max_depth(value, current=1):
        if edict._is_rtype_mapping(value) and value:
            return max(edict._trace_max_depth(v, current + 1) for v in value.values())
        if edict._is_rtype_container(value) and value:
            return max(edict._trace_max_depth(v, current + 1) for v in value)
        return current

    def _assert_mutable(self):
        if self.frozen:
            raise TypeError("edict is frozen and cannot be modified")

    def _populate_from_mapping(self, mapping, strict=False):
        for key, value in mapping.items():
            if key in _RESERVED_KEYS:
                warnings.warn(f"Key {key!r} conflicts with internal attribute/method name")
            super().__setitem__(key, self._coerce_value(value, strict=strict))

    def _resolve_default(self, default, key):
        target = (
            self.__dict__.get("_default", _MISSING_SENTINEL)
            if default is _MISSING_SENTINEL
            else default
        )
        if target is _MISSING_SENTINEL:
            raise KeyError(f"No default value set for key {key}")
        if callable(target):
            sig = inspect.signature(target)
            if len(sig.parameters) == 0:
                return target()
            return target(self)
        return target

    def _resolve_key_expr(self, key_expr, default=None):
        tokens = self._tokenize_key_expr(key_expr)
        current = self
        for token in tokens:
            if token.startswith("@"):
                try:
                    index = self._parse_at_index(token)
                    current = current[index]
                except (ValueError, TypeError, IndexError, KeyError):
                    return self._resolve_default(default, key=key_expr)
                continue

            if edict._is_rtype_mapping(current) and token in current:
                current = current[token]
            else:
                return self._resolve_default(default, key=key_expr)

        return current

    def _resolve_key_expr_strict(self, key_expr):
        tokens = edict._tokenize_key_expr(key_expr)
        current = self
        for token in tokens:
            if token.startswith("@"):
                index = edict._parse_at_index(token)
                if edict._is_rtype_container(current):
                    current = edict._resolve_at_container(current, index)
                else:
                    # try __getitem__ fallback for non-list sequences
                    try:
                        current = getattr(current, "__getitem__")(index)
                    except (IndexError, KeyError):
                        raise
                    except Exception:
                        raise TypeError(
                            f"Cannot resolve index {index} in object of type {type(current)}"
                        )
            else:
                if isinstance(current, Mapping) and token in current:
                    current = edict._resolve_in_mapping(current, token)
                else:
                    # try getattr fallback for non-mapping objects
                    try:
                        current = getattr(current, token)
                    except KeyError:
                        raise
                    except Exception:
                        raise TypeError(
                            f"Cannot resolve key {token!r} in object of type {type(current)}"
                        )
        return current

    def __init__(self, *args, default=_MISSING_SENTINEL, strict=True, **kwargs):
        super().__init__()
        object.__setattr__(self, "_default", default)

        if len(args) > 1:
            raise TypeError(f"edict expected at most 1 positional argument, got {len(args)}")

        if args:
            data = self._resolve_input_source(args[0], **kwargs)
            if not isinstance(data, Mapping):
                raise TypeError(f"edict data must be a mapping, got {type(data).__name__}")
            self._populate_from_mapping(data, strict=strict)
            kwargs = {}  # avoid double processing kwargs if input is dict-like

        if kwargs:
            self.update(kwargs)

    def __missing__(self, key):
        # called by dict.__getitem__ when key is not found
        return self._resolve_default(self._default, key=key)

    def __getattr__(self, key_expr):
        try:
            return self.__getitem__(key_expr)
        except KeyError:
            caller = inspect.currentframe().f_back
            if caller is not None and _is_in_assignment_chain(caller):
                return _EdictNode(self, [key_expr])
            raise KeyError(key_expr)

    def __setattr__(self, name, value):
        if name == "_41996764d3df18cd":
            # Also it can be modified by such as __dict__['_41996764d3df18cd'],
            # we only detect direct assignment to _41996764d3df18cd,
            # other indirect modification is not prevented and users should be careful about it.
            caller = inspect.currentframe().f_back  # type: ignore
            if caller is None or caller.f_code is not edict.freeze.__code__:
                raise AttributeError("_41996764d3df18cd is read-only and managed by freeze()")
            super().__setattr__(name, value)
            return None

        # Keep descriptor semantics for properties; read-only properties cannot be assigned.
        descriptor = getattr(type(self), name, None)
        if isinstance(descriptor, property):
            if descriptor.fset is None:
                raise AttributeError(f"property '{name}' of '{type(self)}' object has no setter")
            descriptor.__set__(self, value)
            return None

        if name == "_default":
            super().__setattr__(name, value)
            return None

        self[name] = value  # checked in __setitem__

    def __delattr__(self, name):
        if name == "_41996764d3df18cd":
            raise AttributeError("_41996764d3df18cd is read-only and managed by freeze()")
        if name == "_default":
            super().__delattr__(name)
            return None

        del self[name]  # checked in __delitem__

    def __setitem__(self, key, value):
        self._assert_mutable()
        if edict._is_key_expr(key):
            edict._assign_by_key_tokens(self, edict._tokenize_key_expr(key), value)
        else:
            super().__setitem__(key, self._coerce_value(value))

    def __getitem__(self, key):
        if edict._is_key_expr(key):
            return self._resolve_key_expr_strict(key)
        return super().__getitem__(key)

    def __delitem__(self, key):
        self._assert_mutable()
        super().__delitem__(key)

    def __call__(self, key, default=_MISSING_SENTINEL):
        try:
            if edict._is_key_expr(key):
                return self._resolve_key_expr_strict(key)
            return self[key]
        except (KeyError, IndexError):
            target = (
                self.__dict__.get("_default", _MISSING_SENTINEL)
                if default is _MISSING_SENTINEL
                else default
            )
            if target is _MISSING_SENTINEL:
                raise
            if callable(target):
                sig = inspect.signature(target)
                if len(sig.parameters) == 0:
                    return target()
                return target(self)
            return target

    def __repr__(self):
        return self._repr_pretty(self, indent=2)

    def __reduce__(self):
        return (
            _reconstruct_edict,
            (dict(self), self.__dict__.get("_default", _MISSING_SENTINEL), self.frozen),
        )

    def __str__(self):
        size = len(self.dumps().encode("utf-8"))
        keys = self._count_keys(self)
        depth = self._trace_max_depth(self)
        return f"edict(keys={keys}, depth={depth}, size={size}B, frozen={self.frozen})"


def _reconstruct_edict(data, default, frozen):
    obj = edict(data, default=default)
    if frozen:
        obj.freeze()
    return obj


_EMPTY_SENTINEL = edict()  # sentinel for empty value
# reserved keys that may conflict with internal attributes/methods
_RESERVED_KEYS = dir(_EMPTY_SENTINEL)
