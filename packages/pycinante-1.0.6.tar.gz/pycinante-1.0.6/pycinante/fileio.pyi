"""File I/O handlers for various file formats."""

from __future__ import annotations

from os import PathLike
from pathlib import Path as _Path
from typing import Any, Callable, Dict, Iterable, List, NamedTuple, Optional, Tuple, Union

StrPath = Union[str, PathLike[str], PathLike[bytes]]

class FileIO(NamedTuple):
    reader: Callable[..., Any]
    writer: Callable[..., Any]

def no_implemented_reader(path: StrPath, **kwargs: Any) -> Any: ...
def no_implemented_writer(obj: Any, path: StrPath, **kwargs: Any) -> Any: ...
def read_json(
    path: StrPath,
    encoding: Optional[str] = ...,
    *,
    cls: Optional[type[Any]] = ...,
    object_hook: Optional[Callable[[Dict[str, Any]], Any]] = ...,
    parse_float: Optional[Callable[[str], Any]] = ...,
    parse_int: Optional[Callable[[str], Any]] = ...,
    parse_constant: Optional[Callable[[str], Any]] = ...,
    object_pairs_hook: Optional[Callable[[List[Tuple[str, Any]]], Any]] = ...,
    strict: bool = ...,
) -> Any: ...
def save_json(
    obj: Any,
    path: StrPath,
    encoding: Optional[str] = ...,
    *,
    skipkeys: bool = ...,
    ensure_ascii: bool = ...,
    check_circular: bool = ...,
    allow_nan: bool = ...,
    cls: Optional[type[Any]] = ...,
    indent: Optional[int] = ...,
    separators: Optional[Tuple[str, str]] = ...,
    default: Optional[Callable[[Any], Any]] = ...,
    sort_keys: bool = ...,
) -> None: ...
def read_pickle(
    path: StrPath,
    *,
    fix_imports: bool = ...,
    encoding: str = ...,
    errors: str = ...,
    buffers: Optional[Iterable[Any]] = ...,
) -> Any: ...
def save_pickle(
    obj: Any,
    path: StrPath,
    *,
    protocol: Optional[int] = ...,
    fix_imports: bool = ...,
    buffer_callback: Optional[Callable[[Any], Any]] = ...,
) -> None: ...
def read_csv(
    path: StrPath,
    *,
    sep: Optional[str] = ...,
    delimiter: Optional[str] = ...,
    header: Optional[Union[int, List[int], str]] = ...,
    names: Optional[List[str]] = ...,
    index_col: Optional[Union[int, str, List[Union[int, str]]]] = ...,
    usecols: Optional[Union[List[int], List[str], Callable[[str], bool]]] = ...,
    dtype: Optional[Union[str, Dict[str, Any]]] = ...,
    engine: Optional[str] = ...,
    converters: Optional[Dict[str, Callable[[Any], Any]]] = ...,
    true_values: Optional[List[str]] = ...,
    false_values: Optional[List[str]] = ...,
    skipinitialspace: bool = ...,
    skiprows: Optional[Union[int, List[int], Callable[[int], bool]]] = ...,
    skipfooter: int = ...,
    nrows: Optional[int] = ...,
    na_values: Optional[Union[str, List[str], Dict[str, List[str]]]] = ...,
    keep_default_na: bool = ...,
    na_filter: bool = ...,
    verbose: bool = ...,
    skip_blank_lines: bool = ...,
    parse_dates: Optional[Union[bool, List[int], List[str], Dict[str, List[str]]]] = ...,
    infer_datetime_format: bool = ...,
    keep_date_col: bool = ...,
    date_parser: Optional[Callable[..., Any]] = ...,
    date_format: Optional[Union[str, Dict[str, str]]] = ...,
    dayfirst: bool = ...,
    cache_dates: bool = ...,
    iterator: bool = ...,
    chunksize: Optional[int] = ...,
    compression: Optional[Union[str, Dict[str, Any]]] = ...,
    thousands: Optional[str] = ...,
    decimal: str = ...,
    lineterminator: Optional[str] = ...,
    quotechar: Optional[str] = ...,
    quoting: Optional[int] = ...,
    doublequote: bool = ...,
    escapechar: Optional[str] = ...,
    comment: Optional[str] = ...,
    encoding: Optional[str] = ...,
    encoding_errors: Optional[str] = ...,
    dialect: Optional[str] = ...,
    on_bad_lines: Optional[Union[str, Callable[[List[str]], Optional[List[str]]]]] = ...,
    delim_whitespace: bool = ...,
    low_memory: bool = ...,
    memory_map: bool = ...,
    float_precision: Optional[str] = ...,
    storage_options: Optional[Dict[str, Any]] = ...,
    dtype_backend: Optional[str] = ...,
) -> Any: ...
def save_csv(
    obj: Any,
    path: StrPath,
    *,
    sep: str = ...,
    na_rep: str = ...,
    float_format: Optional[str] = ...,
    columns: Optional[List[str]] = ...,
    header: Union[bool, List[str]] = ...,
    index: bool = ...,
    index_label: Optional[Union[str, List[str]]] = ...,
    mode: str = ...,
    encoding: Optional[str] = ...,
    compression: Optional[Union[str, Dict[str, Any]]] = ...,
    quoting: Optional[int] = ...,
    quotechar: str = ...,
    lineterminator: Optional[str] = ...,
    chunksize: Optional[int] = ...,
    date_format: Optional[str] = ...,
    doublequote: bool = ...,
    escapechar: Optional[str] = ...,
    decimal: str = ...,
    errors: Optional[str] = ...,
    storage_options: Optional[Dict[str, Any]] = ...,
) -> None: ...
def read_numpy(
    path: StrPath,
    *,
    mmap_mode: Optional[str] = ...,
    allow_pickle: bool = ...,
    fix_imports: bool = ...,
    encoding: str = ...,
    max_header_size: int = ...,
) -> Any: ...
def save_numpy(
    obj: Any,
    path: StrPath,
    *,
    allow_pickle: bool = ...,
    fix_imports: bool = ...,
) -> None: ...
def read_excel(
    path: StrPath,
    *,
    sheet_name: Optional[Union[str, int, List[Union[str, int]]]] = ...,
    header: Optional[Union[int, List[int]]] = ...,
    names: Optional[List[str]] = ...,
    index_col: Optional[Union[int, str, List[Union[int, str]]]] = ...,
    usecols: Optional[Union[str, List[int], List[str], Callable[[str], bool]]] = ...,
    dtype: Optional[Union[str, Dict[str, Any]]] = ...,
    engine: Optional[str] = ...,
    converters: Optional[Dict[str, Callable[[Any], Any]]] = ...,
    true_values: Optional[List[str]] = ...,
    false_values: Optional[List[str]] = ...,
    skiprows: Optional[Union[int, List[int]]] = ...,
    nrows: Optional[int] = ...,
    na_values: Optional[Union[str, List[str], Dict[str, List[str]]]] = ...,
    keep_default_na: bool = ...,
    na_filter: bool = ...,
    verbose: bool = ...,
    parse_dates: Optional[Union[bool, List[int], List[str], Dict[str, List[str]]]] = ...,
    date_parser: Optional[Callable[..., Any]] = ...,
    date_format: Optional[Union[str, Dict[str, str]]] = ...,
    thousands: Optional[str] = ...,
    decimal: str = ...,
    comment: Optional[str] = ...,
    skipfooter: int = ...,
    storage_options: Optional[Dict[str, Any]] = ...,
    dtype_backend: Optional[str] = ...,
) -> Any: ...
def save_excel(
    obj: Any,
    path: StrPath,
    *,
    sheet_name: str = ...,
    na_rep: str = ...,
    float_format: Optional[str] = ...,
    columns: Optional[List[str]] = ...,
    header: Union[bool, List[str]] = ...,
    index: bool = ...,
    index_label: Optional[Union[str, List[str]]] = ...,
    startrow: int = ...,
    startcol: int = ...,
    engine: Optional[str] = ...,
    merge_cells: bool = ...,
    encoding: Optional[str] = ...,
    inf_rep: str = ...,
    verbose: bool = ...,
    freeze_panes: Optional[Tuple[int, int]] = ...,
    storage_options: Optional[Dict[str, Any]] = ...,
) -> None: ...
def read_nibabel(path: StrPath, **kwargs: Any) -> Any: ...
def read_hdf5(
    path: StrPath,
    *,
    driver: Optional[str] = ...,
    libver: Optional[str] = ...,
    userblock_size: Optional[int] = ...,
    swmr: bool = ...,
    rdcc_nslots: Optional[int] = ...,
    rdcc_nbytes: Optional[int] = ...,
    rdcc_w0: Optional[float] = ...,
    track_order: Optional[bool] = ...,
    fs_strategy: Optional[str] = ...,
    fs_persist: bool = ...,
    fs_threshold: Optional[int] = ...,
    fs_page_size: Optional[int] = ...,
    page_buf_size: Optional[int] = ...,
    min_meta_keep: Optional[int] = ...,
    min_raw_keep: Optional[int] = ...,
    locking: Optional[Union[bool, str]] = ...,
    alignment_threshold: Optional[int] = ...,
    alignment_interval: Optional[int] = ...,
    meta_block_size: Optional[int] = ...,
    file_image: Optional[bytes] = ...,
    efile_prefix: Optional[str] = ...,
    virtual_prefix: Optional[str] = ...,
    metadata_cache_size: Optional[int] = ...,
) -> Any: ...
def read_text(
    path: StrPath,
    encoding: str = ...,
    *,
    mode: str = ...,
    buffering: int = ...,
    errors: Optional[str] = ...,
    newline: Optional[str] = ...,
    closefd: bool = ...,
    opener: Optional[Callable[..., Any]] = ...,
) -> str: ...
def save_text(
    obj: Any,
    path: StrPath,
    encoding: str = ...,
    *,
    mode: str = ...,
    buffering: int = ...,
    errors: Optional[str] = ...,
    newline: Optional[str] = ...,
    closefd: bool = ...,
    opener: Optional[Callable[..., Any]] = ...,
) -> None: ...
def read_bytes(
    path: StrPath,
    *,
    mode: str = ...,
    buffering: int = ...,
    closefd: bool = ...,
    opener: Optional[Callable[..., Any]] = ...,
) -> bytes: ...
def save_bytes(
    obj: bytes,
    path: StrPath,
    *,
    mode: str = ...,
    buffering: int = ...,
    closefd: bool = ...,
    opener: Optional[Callable[..., Any]] = ...,
) -> None: ...

FILEIO2EXTS: Dict[str, Dict[str, Any]]

def find_fileio(name: Optional[str] = ..., path: Optional[StrPath] = ...) -> FileIO: ...
def register_fileio(
    name: str,
    reader: Optional[Callable[..., Any]] = ...,
    writer: Optional[Callable[..., Any]] = ...,
    exts: Optional[List[str]] = ...,
    order: Optional[int] = ...,
) -> None: ...

class Path(_Path):
    def __new__(cls, *args: Any, **kwargs: Any) -> Path: ...
    def read(self, name: Optional[str] = ..., **kwargs: Any) -> Any: ...
    def save(self, obj: Any, name: Optional[str] = ..., **kwargs: Any) -> Any: ...
