"""File I/O handlers for various file formats."""

import warnings
from pathlib import Path as _Path


def no_implemented_reader(path, **kwargs):
    raise NotImplementedError(f"No reader implemented for {path}")


def no_implemented_writer(obj, path, **kwargs):
    raise NotImplementedError(f"No writer implemented for {path}")


def read_json(path, encoding=None, **kwargs):
    json = __import__("json")
    with open(path, "r", encoding=encoding) as fp:
        return json.load(fp, **kwargs)


def save_json(obj, path, encoding=None, **kwargs):
    json = __import__("json")
    with open(path, "w", encoding=encoding) as fp:
        json.dump(obj, fp, **kwargs)


def read_pickle(path, **kwargs):
    pickle = __import__("pickle")
    with open(path, "rb") as fp:
        return pickle.load(fp, **kwargs)


def save_pickle(obj, path, **kwargs):
    pickle = __import__("pickle")
    with open(path, "wb") as fp:
        pickle.dump(obj, fp, **kwargs)


def read_csv(path, **kwargs):
    try:
        pd = __import__("pandas")
        return pd.read_csv(path, **kwargs)
    except ImportError:
        raise NotImplementedError(f"pandas not installed for reading {path}")


def save_csv(obj, path, **kwargs):
    try:
        pd = __import__("pandas")
        if hasattr(obj, "to_csv"):
            obj.to_csv(path, **kwargs)
        else:
            pd.DataFrame(obj).to_csv(path, **kwargs)
    except ImportError:
        raise NotImplementedError(f"pandas not installed for writing {path}")


def read_numpy(path, **kwargs):
    try:
        np = __import__("numpy")
        return np.load(path, **kwargs)
    except ImportError:
        raise NotImplementedError(f"numpy not installed for reading {path}")


def save_numpy(obj, path, **kwargs):
    try:
        np = __import__("numpy")
        ext = str(path).split(".")[-1].lower()
        if ext == "npz":
            np.savez(path, **obj if isinstance(obj, dict) else {"arr_0": obj})
        else:
            np.save(path, obj, **kwargs)
    except ImportError:
        raise NotImplementedError(f"numpy not installed for writing {path}")


def read_excel(path, **kwargs):
    try:
        pd = __import__("pandas")
        return pd.read_excel(path, **kwargs)
    except ImportError:
        raise NotImplementedError(f"pandas or openpyxl not installed for reading {path}")


def save_excel(obj, path, **kwargs):
    try:
        pd = __import__("pandas")
        if hasattr(obj, "to_excel"):
            obj.to_excel(path, **kwargs)
        else:
            pd.DataFrame(obj).to_excel(path, **kwargs)
    except ImportError:
        raise NotImplementedError(f"pandas or openpyxl not installed for writing {path}")


def read_nibabel(path, **kwargs):
    try:
        nib = __import__("nibabel")
        return nib.load(path, **kwargs)
    except ImportError:
        raise NotImplementedError(f"nibabel not installed for reading {path}")


def read_hdf5(path, **kwargs):
    try:
        h5py = __import__("h5py")
        return h5py.File(path, "r", **kwargs)
    except ImportError:
        raise NotImplementedError(f"h5py not installed for reading {path}")


def read_text(path, encoding="utf-8", **kwargs):
    if kwargs.pop("mode", "r") != "r":
        warnings.warn("Reading text files with mode other than 'r' is not supported")

    with open(path, "r", encoding=encoding, **kwargs) as fp:
        return fp.read()


def save_text(obj, path, encoding="utf-8", **kwargs):
    if kwargs.pop("mode", "w") != "w":
        warnings.warn("Writing text files with mode other than 'w' is not supported")

    with open(path, "w", encoding=encoding, **kwargs) as fp:
        fp.write(str(obj))


def read_bytes(path, **kwargs):
    if kwargs.pop("mode", "rb") != "rb":
        warnings.warn("Reading bytes files with mode other than 'rb' is not supported")

    with open(path, "rb", **kwargs) as fp:
        return fp.read()


def save_bytes(obj, path, **kwargs):
    if kwargs.pop("mode", "wb") != "wb":
        warnings.warn("Writing bytes files with mode other than 'wb' is not supported")

    with open(path, "wb", **kwargs) as fp:
        fp.write(obj)


FILEIO2EXTS = {
    "json": {
        "reader": read_json,
        "writer": save_json,
        "exts": [".json"],
        "order": 0,
    },
    "pickle": {
        "reader": read_pickle,
        "writer": save_pickle,
        "exts": [".pkl"],
        "order": 0,
    },
    "csv": {
        "reader": read_csv,
        "writer": save_csv,
        "exts": [".csv"],
        "order": 0,
    },
    "numpy": {
        "reader": read_numpy,
        "writer": save_numpy,
        "exts": [".npy", ".npz"],
        "order": 0,
    },
    "excel": {
        "reader": read_excel,
        "writer": save_excel,
        "exts": [".xls", ".xlsx"],
        "order": 0,
    },
    "nibabel": {
        "reader": read_nibabel,
        "writer": no_implemented_writer,
        "exts": [".nii", ".nii.gz"],
        "order": 0,
    },
    "hdf5": {
        "reader": read_hdf5,
        "writer": no_implemented_writer,
        "exts": [".h5", ".hdf5"],
        "order": 0,
    },
    "text": {
        "reader": read_text,
        "writer": save_text,
        "exts": [".txt", ".md", ".rst", ".log"],
        "order": 0,
    },
    "bytes": {
        "reader": read_bytes,
        "writer": save_bytes,
        "exts": [".*"],
        "order": -1,
    },
}


def find_fileio(name=None, path=None):
    """Find file I/O handlers by name or file path extension.

    The extension matching supports both simple string matching and regex patterns.
    Patterns starting with '.' are treated as simple suffix matches (e.g., '.json').
    Other patterns are treated as regex patterns (e.g., '.*', '.tar.(gz|bz2)$').

    When multiple handlers match the same path, the one with the highest order
    value is selected. This allows for priority-based handler selection.

    Args:
        name (str, optional): The name of the file I/O handler (e.g., 'json', 'pickle').
        path (str, optional): The file path to match against registered extensions.
            Extensions can be simple strings (e.g., '.json') or regex patterns.

    Returns:
        tuple: A tuple of (reader, writer) functions for the matched file type.

    Raises:
        ValueError: If neither name nor path is provided, or if both are provided.
        KeyError: If no matching file I/O handler is found.

    Examples:
        >>> reader, writer = find_fileio(name='json')
        >>> reader, writer = find_fileio(path='data.json')
        >>> reader, writer = find_fileio(path='archive.tar.gz')  # matches regex pattern
        >>> # Higher order handlers take precedence over lower order ones
        >>> register_fileio('custom_json', reader=my_reader, exts=['.json'], order=10)
        >>> reader, writer = find_fileio(path='data.json')  # uses custom_json (order=10)
    """
    import os
    import re
    from collections import namedtuple

    if name is None and path is None:
        raise ValueError("Either name or path must be provided")
    if name is not None and path is not None:
        raise ValueError("Only one of name or path should be provided")

    FileIO = namedtuple("FileIO", ["reader", "writer"])

    if name is not None:
        if name not in FILEIO2EXTS:
            raise KeyError(f"File I/O handler '{name}' not found")
        handler = FILEIO2EXTS[name]
        return FileIO(reader=handler["reader"], writer=handler["writer"])

    path = os.fspath(path)  # type: ignore

    # Collect all matching handlers with their order
    matches = []
    for handler_name, handler_info in FILEIO2EXTS.items():
        for ext in handler_info["exts"]:
            matched = False
            # Simple string matching for extensions starting with '.'
            if ext.startswith(".") and not any(c in ext for c in r"*+?[]{}()|\^$"):
                if path.endswith(ext):  # type: ignore
                    matched = True
            else:
                # Regex pattern matching
                try:
                    if re.search(ext, path):  # type: ignore
                        matched = True
                except re.error:
                    # If regex is invalid, fall back to simple string matching
                    if path.endswith(ext):  # type: ignore
                        matched = True

            if matched:
                order = handler_info.get("order", 0)
                matches.append((order, handler_info))
                break  # Only need one match per handler

    if not matches:
        raise KeyError(f"No file I/O handler found for path: {path}")

    # Select the handler with the highest order
    matches.sort(key=lambda x: x[0], reverse=True)
    best_handler = matches[0][1]

    return FileIO(reader=best_handler["reader"], writer=best_handler["writer"])


def register_fileio(name, reader=None, writer=None, exts=None, order=None):
    """Register or update a file I/O handler.

    This function can be used to:
        - Register a new file I/O handler with reader, writer, extensions and order
        - Update an existing handler by adding/replacing reader, writer, extensions or order

    Args:
        name (str): The name of the file I/O handler (e.g., 'json', 'pickle').
        reader (callable, optional): A function to read files of this type.
            If None and registering a new handler, uses no_implemented_reader.
        writer (callable, optional): A function to write files of this type.
            If None and registering a new handler, uses no_implemented_writer.
        exts (list, optional): List of file extensions (e.g., ['.json', '.jsn']).
            Can include simple strings or regex patterns.
            If provided for an existing handler, extends the current extensions list.
        order (int, optional): Priority order for this handler. When multiple handlers
            match the same file path, the one with the highest order is selected.
            Default is 0. Higher values = higher priority.

    Examples:
        >>> # Register a new file I/O handler
        >>> register_fileio('yaml', reader=read_yaml, writer=save_yaml, exts=['.yaml', '.yml'])

        >>> # Update an existing handler with a reader
        >>> register_fileio('csv', reader=read_csv)

        >>> # Add more extensions to an existing handler
        >>> register_fileio('json', exts=['.jsn'])

        >>> # Register a high-priority custom handler for .json files
        >>> register_fileio('custom_json', reader=my_json_reader, exts=['.json'], order=10)

        >>> # Update the order of an existing handler
        >>> register_fileio('pickle', order=5)
    """
    if name in FILEIO2EXTS:
        # Update existing handler
        handler = FILEIO2EXTS[name]
        if reader is not None:
            handler["reader"] = reader
        if writer is not None:
            handler["writer"] = writer
        if exts is not None:
            # Extend the existing extensions list
            handler["exts"].extend([ext for ext in exts if ext not in handler["exts"]])
        if order is not None:
            handler["order"] = order
    else:
        # Register new handler
        FILEIO2EXTS[name] = {
            "reader": reader if reader is not None else no_implemented_reader,
            "writer": writer if writer is not None else no_implemented_writer,
            "exts": exts if exts is not None else [],
            "order": order if order is not None else 0,
        }


class Path(type(_Path())):
    """Path helper with read/save based on registered file handlers.

    The handler resolution follows find_fileio: by default it matches the
    file suffix, or you can override it with name.
    """

    def __new__(cls, *args, **kwargs):
        return super().__new__(cls, *args, **kwargs)

    def read(self, name=None, **kwargs):
        """Read using a matched handler.

        Args:
            name (str, optional): The name of the file I/O handler to use.
                If not provided, selects a handler by the file suffix.
            **kwargs: Forwarded to the matched reader implementation.

        Returns:
            Any: The object returned by the matched reader.

        Raises:
            NotImplementedError: If the matched handler has no reader.

        Examples:
            >>> Path("data.json").read()
            >>> Path("data.unknown").read(name="json")
        """
        handler = find_fileio(path=self) if name is None else find_fileio(name=name)
        if handler.reader is no_implemented_reader:
            raise NotImplementedError(f"No reader implemented for {self}")
        return handler.reader(self, **kwargs)

    def save(self, obj, name=None, **kwargs):
        """Save using a matched handler.

        Args:
            obj (Any): The object to write.
            name (str, optional): The name of the file I/O handler to use.
                If not provided, selects a handler by the file suffix.
            **kwargs: Forwarded to the matched writer implementation.

        Returns:
            Any: The object returned by the matched writer.

        Raises:
            NotImplementedError: If the matched handler has no writer.

        Examples:
            >>> Path("data.json").save({"ok": True}, indent=2)
            >>> Path("data.unknown").save({"ok": True}, name="json")
        """
        handler = find_fileio(path=self) if name is None else find_fileio(name=name)
        if handler.writer is no_implemented_writer:
            raise NotImplementedError(f"No writer implemented for {self}")
        return handler.writer(obj, self, **kwargs)
