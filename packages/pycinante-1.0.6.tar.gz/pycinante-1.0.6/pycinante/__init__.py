"""Pycinante for easily programming in Python."""

import os.path as osp
import warnings

from .edict import edict  # noqa: F401
from .fileio import (  # noqa: F401
    Path,
    read_json,
    read_pickle,
    register_fileio,
    save_json,
    save_pickle,
)

__version__ = "1.0.6"

osp = osp


def objprint(obj, **kwargs):
    try:
        __import__("objprint").op(obj, **kwargs)
    except ImportError:
        warnings.warn("objprint not installed, using pprint instead")
        __import__("pprint").pprint(obj, **kwargs)
    try:
        __import__("objprint").op(obj, **kwargs)
    except ImportError:
        warnings.warn("objprint not installed, using pprint instead")
        __import__("pprint").pprint(obj, **kwargs)
