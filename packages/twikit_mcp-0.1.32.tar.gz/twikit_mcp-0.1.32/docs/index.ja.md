# twikit-mcp

**Twitter/X MCP サーバー + CLI — API キー不要。**

[![PyPI](https://img.shields.io/pypi/v/twikit-mcp)](https://pypi.org/project/twikit-mcp/)
[![CI](https://github.com/tangivis/twitter-mcp/actions/workflows/ci.yml/badge.svg)](https://github.com/tangivis/twitter-mcp/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://github.com/tangivis/twitter-mcp/blob/main/LICENSE)

[MCP](https://modelcontextprotocol.io/) サーバー — Claude(や MCP 対応の AI エージェント)がブラウザ cookies で Twitter/X を操作できます。同じ `twikit-mcp` バイナリは CLI としてもシェルスクリプトやデバッグに使えます。

## 0.1.32 の新機能

- **ツイート返信の取得** — 新規 `get_tweet_replies(tweet_id, cursor=None)` ツールでツイートへのコメント / リプライを取得。vendored twikit 経由で X の TweetDetail GraphQL を使用、1 ページごとに `next_cursor` で次ページ。リプライアイテムは `get_user_tweets` / `get_timeline` と同じコンパクト形式。(closes #94)

アップグレード:`uv tool upgrade twikit-mcp`(または `pip install --upgrade twikit-mcp`)。

## 0.1.31 の新機能

- **クライアント別インストール手順を文書化** — 新規[インストールページ](install.md)で Claude Code / Claude Desktop / Cursor / Windsurf / Cline / opencode 6 クライアントへの登録手順を整理(クライアントあたり ≤ 12 行、設定ファイルパス + JSON スニペットのみ)。インストールコマンドは `uv tool install twikit-mcp` 統一、JSON の形はどのクライアントでも共通。(closes #92)

## 0.1.30 の新機能

- **API ドキュメントページのローカライズ** — `/zh/api/` と `/ja/api/` で中国語 / 日本語の chrome(タイトル、イントロ、テーブルヘッダ、セクション名)を表示するようになりました。英語へフォールバックしません。ツールの docstring は Python ソースのまま(`mkdocstrings` と同じトレードオフ)。(closes #90)

## 0.1.29 の新機能

- **Community と article-preview の信頼性向上** — `get_community` / `get_community_tweets` / `get_community_members` / `get_community_moderators` / `search_community_tweet` が `KeyError: 'rest_id'` / `IndexError` でクラッシュしなくなりました。`get_article_preview` は syndication エンドポイントが 404(X が古い記事を削除)を返した場合、`HTTPStatusError` のスタックトレースを漏らさずクリーンな `ToolError` を返します。`_vendor/twikit/community.py` + `client.py` の全面 `.get()` 防御化。**Issue #76 完了** — `T_DRIFT` は空集合になりました。(issue #76 parts 2 + 3)

## 0.1.28 の新機能

- **List ツールの信頼性向上** — `get_list` / `get_list_tweets` / `get_list_members` / `get_list_subscribers` がバーナー識別子で X にゲートされたレスポンス上で `KeyError: 'created_at'` / `IndexError` / `Invalid list id` でクラッシュしなくなりました。`_vendor/twikit/list.py` + `client.py` の全面 `.get()` 防御化:欠損フィールドは `None`/`""`/`0`、空 entries は空の `Result` を返します。live-smoke の `T_LIST` から `T_DRIFT` フォールバックも除去 — このクラスの再発を即座に検知できます。(issue #76 part 1)

## 0.1.27 の新機能

- **ツイート動画のダウンロード(yt-dlp)** — 新規 MCP ツール `download_tweet_video` と人間向け CLI `twikit-mcp video <id>` を追加。デフォルトでは `~/Downloads/twikit-mcp/` に保存し、既存の `cookies.json` で認証します。PATH に [`yt-dlp`](https://github.com/yt-dlp/yt-dlp) が必要(`uv tool install yt-dlp`)。`ffmpeg` は `bestvideo+bestaudio` のような複数ストリームのマージが必要な format を渡したときだけ必要です。(closes #84)

## 0.1.26 の新機能

- **`get_tweet` で引用ツイートを公開** — レスポンスに `is_quote_status` / `quoted_id` / `quoted_author` / `quoted_text` が含まれるようになりました。引用リツイートの場合、引用元の作者と本文を即座に確認でき、エージェントが追加で `get_tweet` を呼ぶ必要がありません。これらは元から同じ GraphQL レスポンスに含まれていたものを取り出して公開しただけ。(closes #82)

## 0.1.25 の新機能

- **`get_tweet` に会話コンテキストを追加** — レスポンスに `in_reply_to`(リプライ元ツイートID)と `conversation_id`(スレッドのルートツイートID)が含まれるようになりました。エージェントは1つのリプライから親リンクをユーザーに尋ねることなくスレッド全体を遡れます。(closes #77)

## 0.1.24 の新機能

- **Rich レンダリングのカード** — 0.1.23 のターミナルカードを [Rich](https://github.com/Textualize/rich) が描画するようになりました。emoji と CJK の**列幅計測が正確**(`❤ 🔁` 行で右ボーダーがずれない)、ツイート / プロフィール / bio URL は **OSC 8 でクリッカブル**(iTerm2 / kitty / WezTerm / Windows Terminal / gnome-terminal ≥ 3.36 で cmd-クリックで開きます)。トレンドは真の Table レイアウトに。
- プレーンテキスト出力(非 TTY)は無変更:`| jq` / `> file` / `NO_COLOR=1` の消費者にとってバイト安定が保たれます。

## 0.1.23 の新機能

- **ASCII Twitter カード UI** — `twikit-mcp tweet` / `user` / `tl` / `search` / `trends` がターミナルで box-drawing のカード表示になりました(太字の作者名、薄い表示の作成日時、本文 / カウント / URL の区切り線)。ファイルやパイプへリダイレクト、または `NO_COLOR=1` を設定すると、従来通りのバイト安定なプレーンテキストへ自動フォールバック。出力例は [CLI モード](cli.md)。

## 0.1.22 の新機能

- **ヒューマン CLI サブコマンド** — シェルから直接ツイート / プロフィール / タイムライン / 検索 / トレンドを読めます:

  ```bash
  twikit-mcp tweet 20
  twikit-mcp user elonmusk
  twikit-mcp tl 10
  ```

  プレーンテキスト出力、ネイティブ Unicode、ちょうどいいデフォルト値。詳細は [CLI モード](cli.md)。
- **エンドツーエンド UTF-8 出力** — `\uXXXX` エスケープはもうありません。中文 / 日本語 / Ελληνικά / emoji はすべて読める形でツール出力されます。
- **三言語ドキュメントサイト** — 今ご覧のこのページ。上部で言語を切り替えてください。

## 得られるもの

- **57 ツール** — ツイート、ユーザー、リスト、コミュニティ、予約投稿+投票、DM、記事、検索、トレンド、通知。
- **ブラウザ cookie 認証** — X セッションから `ct0` と `auth_token` をコピーするだけ。
- **2 つのトランスポート、1 つのバイナリ** — デフォルトは MCP サーバー(AI エージェント向け)、`twikit-mcp call <tool>` は CLI(シェル向け)。
- **vendored 版 [twikit](https://github.com/d60/twikit)** — プロジェクト固有の防御パッチ付き。

## ドキュメント

- **[CLI モード](cli.md)** — サブコマンド、型変換、終了コード、例。
- **[MCP ツール API](api.md)** — 自動生成のリファレンス:各ツールのシグネチャ、docstring、CLI 例(コードと同期)。
- **[技術設計](TECHNICAL.md)** — 内部実装(現在は中国語のみ — 翻訳歓迎)。
- **[twikit のベンダリング](VENDORING.md)** — すべてのパッチと対応する issue(現在は中国語のみ)。
- **[GitHub リポジトリ](https://github.com/tangivis/twitter-mcp)** — README に三言語のフルインストール手順。

## クイックインストール

```bash
# 1. X cookies を ~/.config/twitter-mcp/cookies.json に保存
mkdir -p ~/.config/twitter-mcp
cat > ~/.config/twitter-mcp/cookies.json <<'EOF'
{"ct0": "...", "auth_token": "..."}
EOF
chmod 600 ~/.config/twitter-mcp/cookies.json

# 2. インストール(日常利用に推奨)
uv tool install twikit-mcp

# 3. Claude Code に登録
claude mcp add twitter -s user \
  -e "TWITTER_COOKIES=$HOME/.config/twitter-mcp/cookies.json" \
  -- twikit-mcp
```

アップグレードは `uv tool upgrade twikit-mcp`;その他のオプション(uvx / pip / pipx)は [GitHub README](https://github.com/tangivis/twitter-mcp#readme) を参照。
