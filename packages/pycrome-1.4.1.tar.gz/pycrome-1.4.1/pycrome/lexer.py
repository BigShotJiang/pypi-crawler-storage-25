# pycrome/lexer.py

import re
import os
from dataclasses import dataclass
from enum import Enum, auto
from typing import List, Optional


class TokenType(Enum):
    # Structure
    COMPONENT     = auto()  # Window, Sidebar, Button, Table etc
    ATTRIBUTE     = auto()  # title="Students", width=220
    STRING        = auto()  # "any string value"
    NUMBER        = auto()  # 220, 800, 14
    BOOLEAN       = auto()  # true, false
    INDENT        = auto()  # increased indentation
    DEDENT        = auto()  # decreased indentation
    NEWLINE       = auto()  # end of line
    SCREEN        = auto()  # Screen keyword
    IDENTIFIER    = auto()  # variable names, function refs
    INCLUDE       = auto()  # include directive
    EOF           = auto()  # end of file


@dataclass
class Token:
    type: TokenType
    value: str | int | float | bool | None
    line: int  # track line number for error messages

    def __repr__(self):
        return f"Token({self.type.name}, {self.value!r}, line={self.line})"


# All valid PyCrome components
COMPONENTS = {
    # Layout
    "Window", "Screen", "Sidebar", "MainPanel",
    "Row", "Col", "Card", "Spacer", "Divider",

    # Navigation
    "NavItem", "ThemeSwitcher", "Breadcrumb", "BreadcrumbItem",
    "Tabs", "Tab", "Navbar", "Footer",

    # Data display
    "Table", "Column", "DataGrid", "GridColumn",
    "StatCard", "Badge", "ProgressBar", "Chart",

    # Inputs
    "Input", "SearchBar", "Select", "Option",
    "Textarea", "DatePicker", "FileUpload", "Toggle",
    "Checkbox", "Radio",

    # Actions
    "Button", "Toolbar", "ToolbarItem", "Dropdown",
    "DropdownItem", "ContextMenu", "ContextMenuItem",

    # Feedback
    "Modal", "Alert", "Tooltip", "Spinner",
    "NotificationBell", "Stepper", "StepperItem",

    # Form
    "Form", "FormField", "FormActions",

    # Misc
    "Header", "Label", "Image", "Icon",
    "Accordion", "AccordionItem",

    "TopNav", "TopNavItem",
    "CollapsibleSidebar", "SidebarItem",
    "StatusBar", "StatusItem",
    "AppLayout", "AppBody", "ContentArea",
    "Tree", "TreeGroup", "TreeItem",
}


class Lexer:
    def __init__(self, source: str, source_path: str = None):
        self.source = source
        self.source_path = source_path  # Path to the source file for resolving includes
        self.tokens = []
        self.lines = source.splitlines()
        self.indent_stack = [0]  # track indentation levels

    def tokenise(self) -> list[Token]:
        # Pre-process: resolve include directives
        self.lines = self._resolve_includes(self.lines)
        
        for line_num, line in enumerate(self.lines, start=1):
            # Skip empty lines and comments
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue

            self._handle_indentation(line, line_num)
            self._tokenise_line(stripped, line_num)

        # Close any remaining indentation blocks
        while len(self.indent_stack) > 1:
            self.indent_stack.pop()
            self.tokens.append(Token(TokenType.DEDENT, None, -1))

        self.tokens.append(Token(TokenType.EOF, None, -1))
        return self.tokens

    def _resolve_includes(self, lines: list[str]) -> list[str]:
        """Recursively resolve include directives."""
        resolved = []
        
        for line in lines:
            stripped = line.strip()
            
            # Check for include directive
            if stripped.startswith('include '):
                # Extract path: include "ui/dashboard.pycrome"
                # Handle both double and single quotes
                path_part = stripped[8:].strip()
                if path_part.startswith('"') and path_part.endswith('"'):
                    path_part = path_part[1:-1]
                elif path_part.startswith("'") and path_part.endswith("'"):
                    path_part = path_part[1:-1]
                
                # Resolve relative to the source file
                if self.source_path:
                    base_dir = os.path.dirname(self.source_path)
                    full_path = os.path.join(base_dir, path_part)
                else:
                    full_path = path_part

                try:
                    with open(full_path, "r", encoding="utf-8") as f:
                        included_lines = f.read().splitlines()
                    
                    # Get the indentation of the include line
                    indent = len(line) - len(line.lstrip())
                    indent_str = " " * indent
                    
                    # Add indentation to all included lines
                    indented_lines = []
                    for l in included_lines:
                        if l.strip():  # Non-empty line
                            indented_lines.append(indent_str + l)
                        else:  # Empty line
                            indented_lines.append(l)
                    
                    # Recursively resolve nested includes
                    resolved.extend(self._resolve_includes(indented_lines))
                    
                except FileNotFoundError:
                    print(f"[PyCrome] Include not found: {full_path}")
                    # Add a comment line to indicate missing include
                    resolved.append(f"{' ' * indent}# ERROR: Include not found: {path_part}")
                except Exception as e:
                    print(f"[PyCrome] Include error {full_path}: {e}")
                    resolved.append(f"{' ' * indent}# ERROR: Failed to include: {path_part}")
            else:
                resolved.append(line)
        
        return resolved

    def _handle_indentation(self, line: str, line_num: int):
        # Count leading spaces
        indent = len(line) - len(line.lstrip())
        current = self.indent_stack[-1]

        if indent > current:
            self.indent_stack.append(indent)
            self.tokens.append(Token(TokenType.INDENT, indent, line_num))

        elif indent < current:
            while self.indent_stack[-1] > indent:
                self.indent_stack.pop()
                self.tokens.append(Token(TokenType.DEDENT, indent, line_num))

    def _tokenise_line(self, line: str, line_num: int):
        # Attribute pattern: key="value" or key=123 or key=true
        attr_pattern = re.compile(
            r'(\w+)='
            r'(?:"([^"]*)"'   # string value
            r'|(\d+\.?\d*)'   # number value
            r'|(true|false))'  # boolean value
        )

        # Extract the component name (first word on the line)
        parts = line.split()
        if not parts:
            return
            
        component_name = parts[0]

        if component_name in COMPONENTS:
            token_type = (
                TokenType.SCREEN
                if component_name == "Screen"
                else TokenType.COMPONENT
            )
            self.tokens.append(Token(token_type, component_name, line_num))
        else:
            # Check if it's an include directive (already handled, but just in case)
            if component_name == "include":
                self.tokens.append(Token(TokenType.INCLUDE, "include", line_num))
            else:
                self.tokens.append(Token(TokenType.IDENTIFIER, component_name, line_num))

        # Extract all attributes from the rest of the line
        rest = line[len(component_name):]
        for match in attr_pattern.finditer(rest):
            key = match.group(1)
            if match.group(2) is not None:
                value = match.group(2)
                self.tokens.append(Token(TokenType.ATTRIBUTE, (key, value), line_num))
            elif match.group(3) is not None:
                value = float(match.group(3)) if '.' in match.group(3) else int(match.group(3))
                self.tokens.append(Token(TokenType.ATTRIBUTE, (key, value), line_num))
            elif match.group(4) is not None:
                value = match.group(4) == "true"
                self.tokens.append(Token(TokenType.ATTRIBUTE, (key, value), line_num))

        self.tokens.append(Token(TokenType.NEWLINE, None, line_num))