# pycrome/theme.py

THEMES = {
    "dark": {
        "bg_primary":       "#0f0f1a",
        "bg_surface":       "#1a1a2e",
        "bg_elevated":      "#252540",
        "primary":          "#4f46e5",
        "primary_hover":    "#4338ca",
        "danger":           "#ef4444",
        "danger_hover":     "#dc2626",
        "success":          "#10b981",
        "warning":          "#f59e0b",
        "text_primary":     "#e2e8f0",
        "text_secondary":   "#94a3b8",
        "text_muted":       "#64748b",
        "border":           "#2d2d44",
        "sidebar_width":    "220px",
        "font":             "Inter, Segoe UI, sans-serif",
        "radius":           "8px",
        "radius_sm":        "4px",
        "radius_lg":        "12px",
    },
    "light": {
        "bg_primary":       "#f8fafc",
        "bg_surface":       "#ffffff",
        "bg_elevated":      "#f1f5f9",
        "primary":          "#4f46e5",
        "primary_hover":    "#4338ca",
        "danger":           "#ef4444",
        "danger_hover":     "#dc2626",
        "success":          "#10b981",
        "warning":          "#f59e0b",
        "text_primary":     "#1e293b",
        "text_secondary":   "#64748b",
        "text_muted":       "#94a3b8",
        "border":           "#e2e8f0",
        "sidebar_width":    "220px",
        "font":             "Inter, Segoe UI, sans-serif",
        "radius":           "8px",
        "radius_sm":        "4px",
        "radius_lg":        "12px",
    },
    "blue": {
        "bg_primary":       "#0f172a",
        "bg_surface":       "#1e3a5f",
        "bg_elevated":      "#1e40af",
        "primary":          "#3b82f6",
        "primary_hover":    "#2563eb",
        "danger":           "#ef4444",
        "danger_hover":     "#dc2626",
        "success":          "#10b981",
        "warning":          "#f59e0b",
        "text_primary":     "#e2e8f0",
        "text_secondary":   "#94a3b8",
        "text_muted":       "#64748b",
        "border":           "#1e3a5f",
        "sidebar_width":    "220px",
        "font":             "Inter, Segoe UI, sans-serif",
        "radius":           "8px",
        "radius_sm":        "4px",
        "radius_lg":        "12px",
    },
    "green": {
        "bg_primary":       "#0a1f0a",
        "bg_surface":       "#1a3a1a",
        "bg_elevated":      "#14532d",
        "primary":          "#10b981",
        "primary_hover":    "#059669",
        "danger":           "#ef4444",
        "danger_hover":     "#dc2626",
        "success":          "#10b981",
        "warning":          "#f59e0b",
        "text_primary":     "#e2e8f0",
        "text_secondary":   "#94a3b8",
        "text_muted":       "#64748b",
        "border":           "#1a3a1a",
        "sidebar_width":    "220px",
        "font":             "Inter, Segoe UI, sans-serif",
        "radius":           "8px",
        "radius_sm":        "4px",
        "radius_lg":        "12px",
    },
    "purple": {
        "bg_primary":       "#0f0a1f",
        "bg_surface":       "#1a1040",
        "bg_elevated":      "#2d1b69",
        "primary":          "#8b5cf6",
        "primary_hover":    "#7c3aed",
        "danger":           "#ef4444",
        "danger_hover":     "#dc2626",
        "success":          "#10b981",
        "warning":          "#f59e0b",
        "text_primary":     "#e2e8f0",
        "text_secondary":   "#94a3b8",
        "text_muted":       "#64748b",
        "border":           "#2d1b69",
        "sidebar_width":    "220px",
        "font":             "Inter, Segoe UI, sans-serif",
        "radius":           "8px",
        "radius_sm":        "4px",
        "radius_lg":        "12px",
    }
}

# Attributes in Window tag that map to theme keys
COLOUR_OVERRIDES = {
    "primary":      "primary",
    "background":   "bg_primary",
    "surface":      "bg_surface",
    "sidebar":      "bg_surface",
    "border":       "border",
    "text":         "text_primary",
    "danger":       "danger",
    "success":      "success",
}


def get_theme(name: str) -> dict:
    return THEMES.get(name, THEMES["dark"]).copy()


def apply_overrides(theme: dict, attrs: dict) -> dict:
    """Apply colour overrides from Window attributes onto the theme."""
    for attr_key, theme_key in COLOUR_OVERRIDES.items():
        if attr_key in attrs:
            theme[theme_key] = attrs[attr_key]
            # Auto-generate hover colour by darkening (simple approach)
            if theme_key == "primary":
                theme["primary_hover"] = attrs[attr_key]
    return theme


def generate_css_variables(theme: dict) -> str:
    vars_ = "\n".join(
        f"    --{key.replace('_', '-')}: {value};"
        for key, value in theme.items()
    )
    return f":root {{\n{vars_}\n}}"


def generate_runtime_theme_js(themes: dict) -> str:
    """Generate JS object containing all themes for runtime switching."""
    js_themes = {}
    for theme_name, theme_dict in themes.items():
        js_themes[theme_name] = {
            f"--{k.replace('_', '-')}": v
            for k, v in theme_dict.items()
        }

    import json
    return f"const PYCROME_THEMES = {json.dumps(js_themes, indent=2)};"