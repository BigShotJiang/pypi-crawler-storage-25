# pycrome/cli.py

import argparse
import sys
import os
import json
import time
import shutil
import subprocess
import webbrowser
import threading
from pathlib import Path
from pycrome import __version__


# ─────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────

def print_success(msg): print(f"\033[92m✔ {msg}\033[0m")
def print_error(msg):   print(f"\033[91m✘ {msg}\033[0m")
def print_info(msg):    print(f"\033[94mℹ {msg}\033[0m")
def print_warn(msg):    print(f"\033[93m⚠ {msg}\033[0m")


def load_config(project_dir: Path) -> dict:
    config_file = project_dir / "pycrome.config.json"
    if config_file.exists():
        with open(config_file, "r") as f:
            return json.load(f)
    return {}


def find_entry_file(project_dir: Path, config: dict) -> Path | None:
    entry = config.get("entry")
    if entry:
        p = project_dir / entry
        if p.exists():
            return p
    for candidate in ["app.pycrome", "main.pycrome", "index.pycrome"]:
        p = project_dir / candidate
        if p.exists():
            return p
    return None


def find_backend(project_dir: Path, config: dict) -> object | None:
    backend_module = config.get("backend", "backend")
    backend_class  = config.get("backend_class", "Backend")
    backend_file   = project_dir / f"{backend_module}.py"

    if not backend_file.exists():
        return None

    sys.path.insert(0, str(project_dir))
    try:
        import importlib
        mod = importlib.import_module(backend_module)
        cls = getattr(mod, backend_class, None)
        if cls:
            return cls()
    except Exception as e:
        print_warn(f"Could not load backend: {e}")
    return None


def parse_pycrome(pycrome_file: Path):
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from pycrome.lexer    import Lexer
    from pycrome.parser   import Parser
    from pycrome.renderer import Renderer

    with open(pycrome_file, "r", encoding="utf-8") as f:
        source = f.read()

    # CHANGE THIS LINE:
    # FROM: lexer = Lexer(source)
    # TO:   lexer = Lexer(source, source_path=str(pycrome_file))
    lexer  = Lexer(source, source_path=str(pycrome_file))  # ← Only this line changes
    tokens = lexer.tokenise()
    parser = Parser(tokens)
    tree   = parser.parse()

    return tree


def render_to_html(pycrome_file: Path, tree) -> str:
    from pycrome.renderer import Renderer
    window_attrs = tree[0].attrs if tree else {}
    theme_name   = window_attrs.get("theme", "dark")
    renderer     = Renderer(theme_name=theme_name, window_attrs=window_attrs)
    return renderer.render(tree)


# ─────────────────────────────────────────
# Command: run
# ─────────────────────────────────────────

def cmd_run(args):
    pycrome_file = Path(args.file).resolve()

    if not pycrome_file.exists():
        print_error(f"File not found: {pycrome_file}")
        sys.exit(1)

    project_dir = pycrome_file.parent
    config      = load_config(project_dir)
    backend     = find_backend(project_dir, config)

    print_info(f"Launching {pycrome_file.name}...")

    sys.path.insert(0, str(Path(__file__).parent.parent))
    from pycrome.engine import Engine

    theme = config.get("theme", "dark")
    engine = Engine(backend=backend, theme=theme)

    if args.debug:
        import webview
        # Monkey-patch to enable debug
        original_start = webview.start
        def debug_start(*a, **kw):
            kw["debug"] = True
            original_start(*a, **kw)
        webview.start = debug_start

    engine.load(str(pycrome_file))


# ─────────────────────────────────────────
# Command: new
# ─────────────────────────────────────────

STARTER_PYCROME = '''# {name} - PyCrome Application
Window title="{name}" width=1200 height=800 theme="dark"
    Sidebar width=220
        NavItem label="Dashboard" icon="home" route="dashboard"
        NavItem label="About" icon="info" route="about"
        ThemeSwitcher
    MainPanel
        Screen id="dashboard" default="true"
            Header title="Dashboard" subtitle="Welcome to {name}"
            Card
                Label text="Your app is ready."
                Label text="Edit app.pycrome to get started."
            Spacer size=16
            Button label="Learn More" style="primary" onclick="get_message()"
        Screen id="about"
            Header title="About" subtitle="About this application"
            Card
                Label text="Built with PyCrome"
                Label text=f"Version {__version__}"
'''

STARTER_BACKEND = '''# backend.py - {name} Backend

class Backend:
    def get_message(self):
        return {{"message": "Hello from PyCrome!", "success": True}}
'''

STARTER_MAIN = '''# main.py - Entry point
import sys
sys.path.insert(0, "{pycrome_root}")

from pycrome.engine import Engine
from backend import Backend

backend = Backend()
engine  = Engine(backend=backend, theme="dark")
engine.load("app.pycrome")
'''

STARTER_CONFIG = '''{{
    "name": "{name}",
    "version": __version__,
    "entry": "app.pycrome",
    "backend": "backend",
    "backend_class": "Backend",
    "theme": "dark",
    "window": {{
        "width": 1200,
        "height": 800,
        "resizable": true
    }}
}}
'''

STARTER_GITIGNORE = '''__pycache__/
*.pyc
*.pyo
dist/
build/
*.spec
.pycrome_cache/
'''


def cmd_new(args):
    name        = args.name
    project_dir = Path(args.name).resolve()

    if project_dir.exists():
        print_error(f"Directory already exists: {project_dir}")
        sys.exit(1)

    pycrome_root = str(Path(__file__).parent.parent).replace("\\", "/")

    project_dir.mkdir(parents=True)

    files = {
        "app.pycrome":           STARTER_PYCROME.format(name=name),
        "backend.py":            STARTER_BACKEND.format(name=name),
        "main.py":               STARTER_MAIN.format(name=name, pycrome_root=pycrome_root),
        "pycrome.config.json":   STARTER_CONFIG.format(name=name),
        ".gitignore":            STARTER_GITIGNORE,
        "README.md":             f"# {name}\n\nBuilt with PyCrome.\n\n## Run\n\n```bash\npycrome run app.pycrome\n```\n",
    }

    for filename, content in files.items():
        (project_dir / filename).write_text(content, encoding="utf-8")

    print_success(f"Project created: {project_dir}")
    print_info(f"  cd {name}")
    print_info(f"  pycrome run app.pycrome")


# ─────────────────────────────────────────
# Command: check
# ─────────────────────────────────────────

def cmd_check(args):
    pycrome_file = Path(args.file).resolve()

    if not pycrome_file.exists():
        print_error(f"File not found: {pycrome_file}")
        sys.exit(1)

    print_info(f"Checking {pycrome_file.name}...")

    try:
        tree = parse_pycrome(pycrome_file)

        if not tree:
            print_warn("File parsed but produced no components.")
            sys.exit(1)

        root = tree[0]
        if root.component != "Window":
            print_warn(f"Root component should be 'Window', got '{root.component}'")

        # Count components
        def count_nodes(nodes):
            total = len(nodes)
            for n in nodes:
                total += count_nodes(n.children)
            return total

        total = count_nodes(tree)
        print_success(f"Valid. {total} components found.")

        # Check for common issues
        issues = []
        def check_node(node):
            if node.component == "Table" and "source" not in node.attrs:
                issues.append(f"Table missing 'source' attribute")
            if node.component == "NavItem" and "label" not in node.attrs:
                issues.append(f"NavItem missing 'label' attribute")
            if node.component == "Button" and "label" not in node.attrs:
                issues.append(f"Button missing 'label' attribute")
            for child in node.children:
                check_node(child)

        for node in tree:
            check_node(node)

        if issues:
            print_warn(f"{len(issues)} warning(s):")
            for issue in issues:
                print_warn(f"  - {issue}")
        else:
            print_success("No issues found.")

    except Exception as e:
        print_error(f"Parse error: {e}")
        sys.exit(1)


# ─────────────────────────────────────────
# Command: preview
# ─────────────────────────────────────────

def cmd_preview(args):
    pycrome_file = Path(args.file).resolve()

    if not pycrome_file.exists():
        print_error(f"File not found: {pycrome_file}")
        sys.exit(1)

    print_info(f"Generating preview for {pycrome_file.name}...")

    try:
        tree = parse_pycrome(pycrome_file)
        html = render_to_html(pycrome_file, tree)

        output_dir  = Path(".pycrome_cache")
        output_dir.mkdir(exist_ok=True)
        output_file = output_dir / "preview.html"

        output_file.write_text(html, encoding="utf-8")

        print_success(f"Preview written to {output_file}")
        webbrowser.open(output_file.resolve().as_uri())

    except Exception as e:
        print_error(f"Preview failed: {e}")
        sys.exit(1)


# ─────────────────────────────────────────
# Command: watch (hot reload)
# ─────────────────────────────────────────

def cmd_watch(args):
    pycrome_file = Path(args.file).resolve()

    if not pycrome_file.exists():
        print_error(f"File not found: {pycrome_file}")
        sys.exit(1)

    project_dir = pycrome_file.parent
    config      = load_config(project_dir)

    print_info(f"Watching {pycrome_file.name} for changes...")
    print_info("Press Ctrl+C to stop.")

    last_modified = pycrome_file.stat().st_mtime
    process       = None

    def launch():
        nonlocal process
        if process:
            process.terminate()
            process.wait()
        print_info("Starting app...")
        process = subprocess.Popen(
            [sys.executable, "-c",
             f"import sys; sys.path.insert(0, r'{Path(__file__).parent.parent}'); "
             f"from pycrome.engine import Engine; "
             f"e = Engine(theme='{config.get('theme', 'dark')}'); "
             f"e.load(r'{pycrome_file}')"]
        )

    launch()

    try:
        while True:
            time.sleep(1)
            current_modified = pycrome_file.stat().st_mtime
            if current_modified != last_modified:
                last_modified = current_modified
                print_info("Change detected. Reloading...")
                launch()
    except KeyboardInterrupt:
        if process:
            process.terminate()
        print_info("Watch stopped.")


# ─────────────────────────────────────────
# Command: build
# ─────────────────────────────────────────

def cmd_build(args):
    pycrome_file = Path(args.file).resolve()
    project_dir  = pycrome_file.parent
    config       = load_config(project_dir)
    name         = config.get("name", pycrome_file.stem)

    print_info(f"Building {name}...")

    # Check PyInstaller is available
    try:
        import PyInstaller
    except ImportError:
        print_error("PyInstaller not found. Install it with: pip install pyinstaller")
        sys.exit(1)

    main_py = project_dir / "main.py"
    if not main_py.exists():
        print_error("main.py not found in project directory.")
        sys.exit(1)

    dist_dir = project_dir / "dist"
    build_dir = project_dir / "build"

    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--onefile",
        "--windowed",
        f"--name={name}",
        f"--distpath={dist_dir}",
        f"--workpath={build_dir}",
        "--noconfirm",
        str(main_py)
    ]

    # Add pycrome as hidden import
    cmd += ["--hidden-import=pycrome"]

    # Add .pycrome files as data
    for f in project_dir.glob("*.pycrome"):
        cmd += [f"--add-data={f};."]

    print_info(f"Running PyInstaller...")
    result = subprocess.run(cmd, cwd=project_dir)

    if result.returncode == 0:
        exe = dist_dir / f"{name}.exe"
        print_success(f"Build complete: {exe}")
    else:
        print_error("Build failed. Check output above.")
        sys.exit(1)


# ─────────────────────────────────────────
# Command: init
# ─────────────────────────────────────────

def cmd_init(args):
    project_dir = Path(".").resolve()
    config_file = project_dir / "pycrome.config.json"

    if config_file.exists():
        print_warn("pycrome.config.json already exists.")
        return

    name = project_dir.name
    config = STARTER_CONFIG.format(name=name)
    config_file.write_text(config, encoding="utf-8")
    print_success(f"Created pycrome.config.json for '{name}'")


# ─────────────────────────────────────────
# Command: list-components
# ─────────────────────────────────────────

COMPONENT_DOCS = {
    # Layout
    "Window":          "Root container. Attrs: title, width, height, theme",
    "Screen":          "Navigable view. Attrs: id, default",
    "Sidebar":         "Left navigation panel. Attrs: width",
    "MainPanel":       "Main content area. No attrs.",
    "Row":             "Horizontal flex row. Attrs: gap, wrap, align",
    "Col":             "Flex column. Attrs: span, gap",
    "Card":            "Surface container. No attrs.",
    "Spacer":          "Vertical space. Attrs: size",
    "Divider":         "Horizontal rule. No attrs.",

    # Navigation
    "NavItem":         "Sidebar navigation link. Attrs: label, icon, route",
    "ThemeSwitcher":   "Theme dot switcher. No attrs.",
    "Navbar":          "Top navigation bar. Attrs: brand, icon",
    "Breadcrumb":      "Navigation trail container. No attrs.",
    "BreadcrumbItem":  "Breadcrumb step. Attrs: label, route",
    "Tabs":            "Tab container. Attrs: id",
    "Tab":             "Individual tab panel. Attrs: id, label, icon",
    "Footer":          "Footer bar. No attrs.",

    # Data Display
    "Table":           "Data table. Attrs: source, id, selectable, sticky_first, on_row_click, paginate, page_size",
    "Column":          "Table column. Attrs: field, label, type",
    "DataGrid":        "Editable data grid. Attrs: id, source, onsave",
    "GridColumn":      "DataGrid column. Attrs: field, label, editable",
    "StatCard":        "Metric card. Attrs: label, value, icon, color, trend, trend_up, source, id",
    "Badge":           "Status badge. Attrs: text, style",
    "ProgressBar":     "Progress indicator. Attrs: label, value, max, color, source, id",
    "Chart":           "Chart component. Attrs: title, type, source, id, height",

    # Inputs
    "Input":           "Text input. Attrs: id, placeholder, onchange, icon",
    "SearchBar":       "Live search input. Attrs: id, placeholder, target, onchange",
    "Select":          "Dropdown select. Attrs: id, label, required",
    "Option":          "Select option. Attrs: value, label, selected",
    "Textarea":        "Multi-line input. Attrs: id, label, placeholder, rows, required",
    "DatePicker":      "Date selector. Attrs: id, label, placeholder, required, value",
    "FileUpload":      "File upload zone. Attrs: id, accept, hint, label",
    "Toggle":          "On/off switch. Attrs: id, label, checked, onchange",
    "Checkbox":        "Checkbox input. Attrs: id, label, checked, onchange",
    "Radio":           "Radio input. Attrs: id, label, name, value, checked",

    # Actions
    "Button":          "Clickable button. Attrs: label, style, icon, onclick, type",
    "Toolbar":         "Button row above tables. No attrs.",
    "ToolbarItem":     "Toolbar button or separator. Attrs: label, icon, onclick, style, separator",
    "Dropdown":        "Button with dropdown menu. Attrs: id, label, icon, style",
    "DropdownItem":    "Dropdown menu item. Attrs: label, icon, onclick, style, separator",
    "ContextMenu":     "Right-click menu. Attrs: id, target",
    "ContextMenuItem": "Context menu item. Attrs: label, icon, onclick, style, separator",

    # Feedback
    "Modal":           "Dialog overlay. Attrs: id, title, width, show_close",
    "Alert":           "Alert message. Attrs: text, style",
    "Tooltip":         "Hover hint wrapper. Attrs: text",
    "Spinner":         "Loading spinner. No attrs.",
    "NotificationBell":"Alert bell with badge. Attrs: id, count, source",
    "Accordion":       "Collapsible sections container. No attrs.",
    "AccordionItem":   "Accordion section. Attrs: title, open",
    "Stepper":         "Step progress indicator. Attrs: active",
    "StepperItem":     "Stepper step. Attrs: label",

    # Form
    "Form":            "Form container. Attrs: id, onsubmit",
    "FormField":       "Labelled input field. Attrs: id, label, type, placeholder, required, value, readonly",
    "FormActions":     "Form button row. No attrs.",

    # Misc
    "Header":          "Page heading. Attrs: title, subtitle",
    "Label":           "Text label. Attrs: text, icon",
    "Image":           "Image element. Attrs: src, alt, width, height",
    "Icon":            "Standalone icon. Attrs: name",
    "Navbar":          "Top bar. Attrs: brand, icon",
    "Tabs":            "Tab container. Attrs: id",
    "Tab":             "Tab panel. Attrs: id, label, icon",

    "TopNav":             "Horizontal primary tab bar. Attrs: brand, icon",
    "TopNavItem":         "Top nav tab. Attrs: label, icon, module, tooltip",
    "CollapsibleSidebar": "Collapsible sub-module sidebar. No attrs.",
    "SidebarItem":        "Sub-module nav item. Attrs: label, icon, route, module, onclick",
    "StatusBar":          "Bottom status bar. No attrs.",
    "StatusItem":         "Status bar item. Attrs: text, icon, id, dot, source",
    "AppLayout":          "Full app layout wrapper. No attrs.",
    "AppBody":            "Horizontal body container. No attrs.",
    "ContentArea":        "Scrollable main content area. No attrs.",

    "Tree":      "Expandable tree navigation container. Attrs: id",
    "TreeGroup": "Expandable group in a Tree. Attrs: label, icon, badge, open, module, id",
    "TreeItem":  "Leaf item in a Tree. Attrs: label, icon, route, onclick, badge",
}


def cmd_list_components(args):
    print("\n\033[94mPyCrome Components\033[0m")
    print("─" * 60)
    for component, doc in sorted(COMPONENT_DOCS.items()):
        print(f"\033[92m{component:<18}\033[0m {doc}")
    print("─" * 60)
    print(f"Total: {len(COMPONENT_DOCS)} components\n")


# ─────────────────────────────────────────
# Command: version
# ─────────────────────────────────────────

def cmd_version(args):
    print(f"PyCrome {__version__}")
    print("Python UI language for desktop applications")
    print("Built by Centra Holdings SMC Ltd")


# ─────────────────────────────────────────
# Main entry point
# ─────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="pycrome",
        description="PyCrome - Python UI language for desktop applications",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Commands:
  run       Launch a .pycrome app
  new       Scaffold a new project
  check     Validate a .pycrome file
  preview   Render to HTML and open in browser
  watch     Run with hot reload
  build     Package as standalone .exe
  init      Create pycrome.config.json
  list      List all available components
  version   Show PyCrome version
        """
    )

    subparsers = parser.add_subparsers(dest="command")

    # run
    p_run = subparsers.add_parser("run", help="Launch a .pycrome app")
    p_run.add_argument("file", help=".pycrome file to run")
    p_run.add_argument("--debug", action="store_true", help="Open dev tools")
    p_run.set_defaults(func=cmd_run)

    # new
    p_new = subparsers.add_parser("new", help="Scaffold a new project")
    p_new.add_argument("name", help="Project name")
    p_new.set_defaults(func=cmd_new)

    # check
    p_check = subparsers.add_parser("check", help="Validate a .pycrome file")
    p_check.add_argument("file", help=".pycrome file to check")
    p_check.set_defaults(func=cmd_check)

    # preview
    p_preview = subparsers.add_parser("preview", help="Preview in browser")
    p_preview.add_argument("file", help=".pycrome file to preview")
    p_preview.set_defaults(func=cmd_preview)

    # watch
    p_watch = subparsers.add_parser("watch", help="Run with hot reload")
    p_watch.add_argument("file", help=".pycrome file to watch")
    p_watch.set_defaults(func=cmd_watch)

    # build
    p_build = subparsers.add_parser("build", help="Package as .exe")
    p_build.add_argument("file", help=".pycrome entry file")
    p_build.set_defaults(func=cmd_build)

    # init
    p_init = subparsers.add_parser("init", help="Create pycrome.config.json")
    p_init.set_defaults(func=cmd_init)

    # list
    p_list = subparsers.add_parser("list", help="List all components")
    p_list.set_defaults(func=cmd_list_components)

    # version
    p_version = subparsers.add_parser("version", help="Show version")
    p_version.set_defaults(func=cmd_version)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    main()