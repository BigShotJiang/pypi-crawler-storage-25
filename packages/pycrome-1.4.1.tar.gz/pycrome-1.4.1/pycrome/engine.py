# pycrome/engine.py

import webview
from pycrome.lexer    import Lexer
from pycrome.parser   import Parser
from pycrome.renderer import Renderer


ERROR_HTML = """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
      background: #0f0f1a;
      color: #e2e8f0;
      font-family: Inter, Segoe UI, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      padding: 40px;
  }}
  .box {{
      text-align: center;
      max-width: 600px;
      width: 100%;
  }}
  .icon {{
      width: 64px; height: 64px;
      border-radius: 50%;
      background: rgba(239,68,68,0.1);
      display: flex; align-items: center;
      justify-content: center;
      margin: 0 auto 24px;
      font-size: 28px;
  }}
  h1 {{ font-size: 22px; margin-bottom: 12px; color: #ef4444; }}
  p  {{ font-size: 14px; color: #94a3b8; margin-bottom: 20px; }}
  pre {{
      background: #1a1a2e;
      border: 1px solid #2d2d44;
      border-radius: 8px;
      padding: 16px;
      font-size: 13px;
      text-align: left;
      white-space: pre-wrap;
      word-break: break-all;
      color: #ef4444;
      max-height: 300px;
      overflow-y: auto;
  }}
</style>
</head>
<body>
<div class="box">
  <div class="icon">⚠</div>
  <h1>PyCrome Error</h1>
  <p>{message}</p>
  <pre>{detail}</pre>
</div>
</body>
</html>"""


class Engine:
    def __init__(self, backend=None, theme: str = "dark"):
        self.backend = backend
        self.theme   = theme
        self.window  = None

    def load(self, pycrome_file: str):
        html  = self._build_html(pycrome_file)
        title, width, height = self._get_window_props(pycrome_file)

        self.window = webview.create_window(
            title=title,
            html=html,
            width=width,
            height=height,
            resizable=True,
            js_api=self._make_safe_backend()
        )

        webview.start(debug=True)

    # ──────────────────────────────────────
    # Internal
    # ──────────────────────────────────────

    def _build_html(self, pycrome_file: str) -> str:
        try:
            with open(pycrome_file, "r", encoding="utf-8") as f:
                source = f.read()

            # Pass the source file path to Lexer for include resolution
            lexer    = Lexer(source, source_path=pycrome_file)
            tokens   = lexer.tokenise()
            parser   = Parser(tokens)
            tree     = parser.parse()

            if not tree:
                return ERROR_HTML.format(
                    message="The .pycrome file produced no components.",
                    detail=f"File: {pycrome_file}\n\nCheck that your file starts with a Window component."
                )

            window_attrs = tree[0].attrs
            theme_name   = window_attrs.get("theme", self.theme)
            renderer     = Renderer(theme_name=theme_name, window_attrs=window_attrs)
            return renderer.render(tree)

        except FileNotFoundError:
            return ERROR_HTML.format(
                message="File not found.",
                detail=f"Could not open: {pycrome_file}"
            )
        except Exception as e:
            import traceback
            return ERROR_HTML.format(
                message="Failed to parse or render the .pycrome file.",
                detail=traceback.format_exc()
            )

    def _get_window_props(self, pycrome_file: str):
        try:
            with open(pycrome_file, "r", encoding="utf-8") as f:
                source = f.read()
            
            # Pass the source file path to Lexer for include resolution
            lexer  = Lexer(source, source_path=pycrome_file)
            tokens = lexer.tokenise()
            parser = Parser(tokens)
            tree   = parser.parse()
            
            if tree:
                attrs  = tree[0].attrs
                return (
                    attrs.get("title", "PyCrome App"),
                    int(attrs.get("width", 1200)),
                    int(attrs.get("height", 800))
                )
        except Exception:
            pass
        return "PyCrome App", 1200, 800

    def _make_safe_backend(self):
        """Wrap backend methods with try/catch so exceptions return JSON errors."""
        if not self.backend:
            return None

        import json
        import traceback

        backend = self.backend

        class SafeBackend:
            pass

        safe = SafeBackend()

        for name in dir(backend):
            if name.startswith("_"):
                continue
            method = getattr(backend, name)
            if not callable(method):
                continue

            def make_wrapper(m):
                def wrapper(*args, **kwargs):
                    try:
                        result = m(*args, **kwargs)
                        if result is None:
                            return json.dumps({"success": True})
                        # Convert result to JSON if it's a dict/list
                        if isinstance(result, (dict, list)):
                            return json.dumps(result, default=str)
                        return result
                    except Exception as e:
                        tb = traceback.format_exc()
                        print(f"[PyCrome] Backend error in '{m.__name__}': {e}")
                        return json.dumps({
                            "success": False,
                            "message": str(e),
                            "traceback": tb
                        })
                wrapper.__name__ = m.__name__
                return wrapper

            setattr(safe, name, make_wrapper(method))

        return safe