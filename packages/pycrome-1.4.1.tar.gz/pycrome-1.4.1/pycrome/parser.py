# pycrome/parser.py

from dataclasses import dataclass, field
from typing import Any
from pycrome.lexer import Lexer, TokenType, Token


@dataclass
class UINode:
    """Represents a single UI component in the tree."""
    component: str
    attrs: dict[str, Any] = field(default_factory=dict)
    children: list["UINode"] = field(default_factory=list)

    def __repr__(self, level=0):
        indent = "  " * level
        attrs = ", ".join(f"{k}={v!r}" for k, v in self.attrs.items())
        result = f"{indent}<{self.component} {attrs}>\n"
        for child in self.children:
            result += child.__repr__(level + 1)
        return result


class Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.pos = 0

    def current(self) -> Token:
        return self.tokens[self.pos]

    def advance(self) -> Token:
        token = self.tokens[self.pos]
        self.pos += 1
        return token

    def peek(self) -> Token | None:
        if self.pos + 1 < len(self.tokens):
            return self.tokens[self.pos + 1]
        return None

    def parse(self) -> list[UINode]:
        nodes = []
        while self.current().type != TokenType.EOF:
            node = self._parse_node()
            if node:
                nodes.append(node)
        return nodes

    def _parse_node(self) -> UINode | None:
        token = self.current()

        # Skip newlines and indentation at top level
        if token.type in (TokenType.NEWLINE, TokenType.INDENT, TokenType.DEDENT):
            self.advance()
            return None

        if token.type not in (TokenType.COMPONENT, TokenType.SCREEN):
            self.advance()
            return None

        # Build the node
        self.advance()
        node = UINode(component=token.value)

        # Collect attributes on the same line
        while self.current().type == TokenType.ATTRIBUTE:
            key, value = self.current().value
            node.attrs[key] = value
            self.advance()

        # Skip newline after component declaration
        if self.current().type == TokenType.NEWLINE:
            self.advance()

        # If next token is INDENT, parse children
        if self.current().type == TokenType.INDENT:
            self.advance()  # consume INDENT
            node.children = self._parse_children()

        return node

    def _parse_children(self) -> list[UINode]:
        children = []

        while self.current().type != TokenType.EOF:
            token = self.current()

            if token.type == TokenType.DEDENT:
                self.advance()
                break

            if token.type in (TokenType.NEWLINE, TokenType.INDENT):
                self.advance()
                continue

            # Accept COMPONENT, SCREEN, and IDENTIFIER as valid nodes
            if token.type in (TokenType.COMPONENT, TokenType.SCREEN, TokenType.IDENTIFIER):
                self.advance()
                node = UINode(component=token.value)

                # Collect attributes
                while self.current().type == TokenType.ATTRIBUTE:
                    key, value = self.current().value
                    node.attrs[key] = value
                    self.advance()

                # Skip newline
                if self.current().type == TokenType.NEWLINE:
                    self.advance()

                # Parse nested children
                if self.current().type == TokenType.INDENT:
                    self.advance()
                    node.children = self._parse_children()

                children.append(node)
            else:
                self.advance()

        return children