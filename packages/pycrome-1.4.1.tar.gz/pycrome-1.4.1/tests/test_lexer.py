# tests/test_lexer.py
import sys
sys.path.insert(0, "F:/PROJECTS/PyCrome")

from pycrome.lexer import Lexer
from pycrome.parser import Parser
from pycrome.renderer import Renderer

sample = """
# PyCrome test file
Window title="Students" width=1200 height=800
    Sidebar width=220
        NavItem label="Dashboard" icon="grid"
        NavItem label="Students" icon="users"
    MainPanel
        Table source="get_students()" id="students_table"
            Column field="name" label="Full Name"
            Column field="class" label="Class"
        Button label="Add Student" onclick="add_student()"
"""

lexer = Lexer(sample)
tokens = lexer.tokenise()

for token in tokens:
    print(token)

print("\n--- AST ---\n")
lexer2 = Lexer(sample)
tokens = lexer2.tokenise()
parser = Parser(tokens)
tree = parser.parse()

for node in tree:
    print(node)


print("\n--- HTML OUTPUT ---\n")
lexer3 = Lexer(sample)
tokens3 = lexer3.tokenise()
parser3 = Parser(tokens3)
tree3 = parser3.parse()

renderer = Renderer(theme_name="dark")
html = renderer.render(tree3)

# Save to file so you can open it in a browser
with open("tests/output.html", "w", encoding="utf-8") as f:
    f.write(html)

print("HTML written to tests/output.html")
print(f"Total HTML size: {len(html)} characters")