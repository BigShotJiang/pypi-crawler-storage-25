# setup.py

# Clean
#Remove-Item -Recurse -Force dist, build, pycrome.egg-info -ErrorAction SilentlyContinue

# Build
#python -m build

# Check
#dir dist

#twine upload dist/*


import re
from setuptools import setup, find_packages

# Read version from __init__.py
with open("pycrome/__init__.py", "r", encoding="utf-8") as f:
    content = f.read()
    version_match = re.search(r"__version__\s*=\s*['\"]([^'\"]+)['\"]", content)
    if version_match:
        version = version_match.group(1)
    else:
        raise RuntimeError("Unable to find version string in __init__.py")

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="pycrome",
    version=version,
    author="Centra Holdings SMC Ltd",
    author_email="bewoku14@outlook.com",
    description="Python UI language for desktop applications",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/BenEwoku/Pycrome",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: User Interfaces",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.12",
    install_requires=[
        "pywebview>=4.0.0",
    ],
    entry_points={
        "console_scripts": [
            "pycrome=pycrome.cli:main",
        ],
    },
    include_package_data=True,
)