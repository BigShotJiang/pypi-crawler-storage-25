# -*- coding: utf-8 -*-
"""
AtendentePro - Sistema de Atendimento Inteligente com Múltiplos Agentes IA

Uma biblioteca Python modular para criar sistemas de atendimento automatizado
usando múltiplos agentes de IA especializados.

⚠️ ATIVAÇÃO NECESSÁRIA:

    Esta biblioteca requer um token de licença para funcionar.

    Opção 1 - Ativar programaticamente:

        from atendentepro import activate
        activate("seu-token-de-acesso")

    Opção 2 - Variável de ambiente:

        export ATENDENTEPRO_LICENSE_KEY="seu-token-de-acesso"

Exemplo de uso básico:

    from atendentepro import activate, create_standard_network, configure
    from pathlib import Path

    # 1. Ativar a biblioteca
    activate("seu-token-de-acesso")

    # 2. Configurar a biblioteca (OpenAI, Azure ou custom)
    configure(provider="openai", openai_api_key="sua-chave")
    # Ou: configure(provider="custom", custom_api_key="sk-...", custom_base_url="https://api.deepseek.com/v1", default_model="deepseek-chat")

    # 3. Criar rede de agentes
    network = create_standard_network(
        templates_root=Path("./client_templates"),
        client="standard"
    )

    # 4. Usar o agente de triagem como ponto de entrada
    triage_agent = network.triage

Para obter um token de licença, entre em contato: contato@monkai.com.br
Para mais informações, consulte a documentação.
"""

__version__ = "0.13.1"
__author__ = "BeMonkAI"
__email__ = "contato@monkai.com.br"
__license__ = "Proprietary"

# Agents
from atendentepro.agents import (
    ESCALATION_TOOLS,
    FEEDBACK_TOOLS,
    AnswerAgent,
    ConfirmationAgent,
    EscalationAgent,
    FeedbackAgent,
    FlowAgent,
    InterviewAgent,
    KnowledgeAgent,
    OnboardingAgent,
    TriageAgent,
    UsageAgent,
    configure_feedback_storage,
    create_answer_agent,
    create_confirmation_agent,
    create_escalation_agent,
    create_feedback_agent,
    create_flow_agent,
    create_interview_agent,
    create_knowledge_agent,
    create_onboarding_agent,
    create_triage_agent,
    create_usage_agent,
    go_to_rag,
    make_go_to_rag,
    set_agent_instructions,
)

# Configuration
from atendentepro.config import (
    DEFAULT_MODEL,
    KNOWN_PROVIDERS,
    RECOMMENDED_PROMPT_PREFIX,
    AtendenteProConfig,
    AtendentProConfig,
    ProviderConfig,
    configure,
    get_config,
)

# Guardrails
from atendentepro.guardrails import (
    GuardrailManager,
    get_guardrails_for_agent,
    get_out_of_scope_message,
    set_guardrails_client,
)

# License (deve ser importado primeiro)
from atendentepro.license import (
    InvalidTokenError,
    LicenseError,
    LicenseExpiredError,
    LicenseInfo,
    LicenseNotActivatedError,
    activate,
    deactivate,
    get_license_info,
    has_feature,
    is_activated,
    require_activation,
)

# Models
from atendentepro.models import (  # Access filtering
    AccessFilter,
    AccessFilterResolver,
    ContextNote,
    FilteredPromptSection,
    FilteredTool,
    FlowOutput,
    FlowTopic,
    GuardrailValidationOutput,
    InterviewOutput,
    KnowledgeToolResult,
    UserContext,
)

# Network
from atendentepro.network import (
    AgentNetwork,
    AgentStyle,
    NetworkConfig,
    create_custom_network,
    create_standard_network,
)

# Providers
from atendentepro.providers import (
    PROVIDER_CAPABILITIES,
    AdapterClient,
    get_provider_capabilities,
    register_adapter,
    resolve_client_for_provider,
)

# Setup Copilot (para usuários PyPI)
# Setup Copilot (PyPI users)
from atendentepro.setup_copilot import setup

# Templates
from atendentepro.templates import (
    ClientTemplate,
    ProviderTemplateConfig,
    TemplateManager,
    configure_client,
    get_template_folder,
    load_confirmation_config,
    load_flow_config,
    load_interview_config,
    load_knowledge_config,
    load_onboarding_config,
    load_provider_config,
    load_triage_config,
)

# Utils
from atendentepro.utils import (  # MonkAI Trace; Application Insights; User Loader; Rate Limiter; Logging
    JSONFormatter,
    RateLimiter,
    RateLimitExceededError,
    clear_client_cache,
    configure_application_insights,
    configure_logging,
    configure_monkai_trace,
    configure_tracing,
    create_user_loader,
    extract_email_from_messages,
    extract_phone_from_messages,
    extract_user_id_from_messages,
    get_async_client,
    get_monkai_hooks,
    get_provider,
    load_user_from_csv,
    run_with_monkai_tracking,
    run_with_user_context,
    set_monkai_input,
    set_monkai_user,
)

# generate_license_token foi movida para scripts/license_admin.py (uso administrativo interno).
# Nao faz parte da API publica do pacote distribuido.


__all__ = [
    # Version
    "__version__",
    # Setup Copilot
    "setup",
    "__author__",
    # License
    "activate",
    "deactivate",
    "is_activated",
    "get_license_info",
    "require_activation",
    "has_feature",
    "LicenseInfo",
    "LicenseError",
    "LicenseNotActivatedError",
    "LicenseExpiredError",
    "InvalidTokenError",
    # Configuration
    "AtendenteProConfig",
    "AtendentProConfig",
    "get_config",
    "configure",
    "RECOMMENDED_PROMPT_PREFIX",
    "DEFAULT_MODEL",
    "KNOWN_PROVIDERS",
    "ProviderConfig",
    # Models
    "ContextNote",
    "FlowTopic",
    "FlowOutput",
    "InterviewOutput",
    "KnowledgeToolResult",
    "GuardrailValidationOutput",
    # Access filtering
    "UserContext",
    "AccessFilter",
    "AccessFilterResolver",
    "FilteredPromptSection",
    "FilteredTool",
    # Agents
    "create_triage_agent",
    "create_flow_agent",
    "create_interview_agent",
    "create_answer_agent",
    "create_knowledge_agent",
    "create_confirmation_agent",
    "create_usage_agent",
    "create_onboarding_agent",
    "create_escalation_agent",
    "create_feedback_agent",
    "TriageAgent",
    "FlowAgent",
    "InterviewAgent",
    "AnswerAgent",
    "KnowledgeAgent",
    "ConfirmationAgent",
    "UsageAgent",
    "OnboardingAgent",
    "EscalationAgent",
    "FeedbackAgent",
    "go_to_rag",
    "make_go_to_rag",
    "ESCALATION_TOOLS",
    "FEEDBACK_TOOLS",
    "configure_feedback_storage",
    "set_agent_instructions",
    # Setup Copilot
    "setup",
    # Network
    "AgentNetwork",
    "AgentStyle",
    "NetworkConfig",
    "create_standard_network",
    "create_custom_network",
    # Templates
    "TemplateManager",
    "ClientTemplate",
    "configure_client",
    "get_template_folder",
    "load_flow_config",
    "load_interview_config",
    "load_triage_config",
    "load_knowledge_config",
    "load_confirmation_config",
    "load_onboarding_config",
    "load_provider_config",
    "ProviderTemplateConfig",
    # Providers
    "AdapterClient",
    "PROVIDER_CAPABILITIES",
    "get_provider_capabilities",
    "register_adapter",
    "resolve_client_for_provider",
    # Guardrails
    "GuardrailManager",
    "get_guardrails_for_agent",
    "get_out_of_scope_message",
    "set_guardrails_client",
    # Utils
    "get_async_client",
    "get_provider",
    "clear_client_cache",
    "configure_tracing",
    # MonkAI Trace
    "configure_monkai_trace",
    "get_monkai_hooks",
    "set_monkai_user",
    "set_monkai_input",
    "run_with_monkai_tracking",
    # Application Insights
    "configure_application_insights",
    # User Loader
    "create_user_loader",
    "run_with_user_context",
    "extract_phone_from_messages",
    "extract_email_from_messages",
    "extract_user_id_from_messages",
    "load_user_from_csv",
    # Rate Limiter
    "RateLimiter",
    "RateLimitExceededError",
    # Logging
    "configure_logging",
    "JSONFormatter",
    "setup",
]
