"""
Jira built-in tools for the AgenticWerx MCP client.

These tools are registered directly on the Python client (not from the
Lambda MCP server). They show up alongside Lambda tools seamlessly.

The tool description nudges the AI to follow up with query_rule
so that coding standards are applied to whatever Jira task is retrieved.
"""

import json
import logging
from typing import Any

from mcp.types import TextContent, Tool

from .jira_client import JiraAPIError, JiraClient, JiraConfigError, load_jira_config

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Tool definitions
# ---------------------------------------------------------------------------

JIRA_TOOLS: list[Tool] = [
    Tool(
        name="get_jira_issue",
        description=(
            "Fetch a Jira issue by key (e.g. ENG-1234). Returns summary, "
            "description, status, assignee, acceptance criteria, labels, "
            "priority, and story points. "
            "IMPORTANT: After retrieving the issue, immediately call "
            "query_rule with a question derived from the task requirements "
            "to get relevant coding standards and patterns before starting work."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "issue_key": {
                    "type": "string",
                    "description": "Jira issue key, e.g. ENG-1234",
                },
            },
            "required": ["issue_key"],
        },
    ),
]

# Set of tool names for quick lookup
JIRA_TOOL_NAMES: set[str] = {t.name for t in JIRA_TOOLS}


# ---------------------------------------------------------------------------
# Tool handler
# ---------------------------------------------------------------------------


class JiraToolHandler:
    """Handles execution of Jira built-in tools."""

    def __init__(self) -> None:
        self._client: JiraClient | None = None
        self._config: dict[str, Any] | None = None
        self._initialized = False

    @property
    def available(self) -> bool:
        """True if Jira config is present and valid."""
        if not self._initialized:
            self._config = load_jira_config()
            self._initialized = True
        return self._config is not None

    async def _get_client(self) -> JiraClient:
        """Lazy-init the Jira client."""
        if self._client is None:
            if not self.available or self._config is None:
                raise JiraConfigError(
                    "Jira is not configured. Create ~/.agenticwerx/config.json "
                    "(or set AGENTICWERX_CONFIG env var) with a 'jira' section "
                    "containing baseUrl, apiToken, and email (for Cloud)."
                )
            self._client = JiraClient(self._config)
        return self._client

    async def close(self) -> None:
        """Shut down the HTTP client."""
        if self._client is not None:
            await self._client.close()
            self._client = None

    def get_tools(self) -> list[Tool]:
        """Return the list of Jira tools if config is present."""
        if self.available:
            return list(JIRA_TOOLS)
        logger.debug("Jira tools not registered — config missing or incomplete")
        return []

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
    ) -> list[TextContent]:
        """Dispatch a tool call to the appropriate handler."""
        try:
            client = await self._get_client()

            if name == "get_jira_issue":
                return await self._handle_get_issue(client, arguments)
            else:
                return [
                    TextContent(
                        type="text",
                        text=json.dumps({"error": f"Unknown Jira tool: {name}"}),
                    )
                ]

        except JiraConfigError as exc:
            return [TextContent(type="text", text=json.dumps({"error": str(exc)}))]
        except JiraAPIError as exc:
            return [
                TextContent(
                    type="text",
                    text=json.dumps(
                        {
                            "error": str(exc),
                            "status_code": exc.status_code,
                        }
                    ),
                )
            ]
        except Exception as exc:
            logger.error(f"Unexpected error in Jira tool {name}: {exc}")
            return [
                TextContent(
                    type="text",
                    text=json.dumps({"error": f"Jira tool error: {exc}"}),
                )
            ]

    # -- handler -----------------------------------------------------------

    async def _handle_get_issue(
        self,
        client: JiraClient,
        args: dict[str, Any],
    ) -> list[TextContent]:
        issue_key = args["issue_key"]
        issue = await client.get_issue(issue_key)

        # Build a hint for the AI to query rules next
        issue["_next_step"] = (
            "Now call query_rule with a question based on this task's "
            "requirements to retrieve relevant coding standards and patterns. "
            "For example: query_rule(question='What are the coding standards "
            f"for {issue.get('summary', 'this type of work')}?')"
        )

        return [TextContent(type="text", text=json.dumps(issue, indent=2))]
