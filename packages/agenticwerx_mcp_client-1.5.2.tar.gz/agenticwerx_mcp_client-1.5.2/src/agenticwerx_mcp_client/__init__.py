"""
AgenticWerx MCP Client

A Model Context Protocol (MCP) client for AgenticWerx rule packages.
Provides universal code analysis across all IDEs and programming languages.
"""

__version__ = "1.5.2"
__author__ = "AgenticWerx"
__email__ = "support@agenticwerx.com"

from .api import AgenticWerxAPI
from .client import AgenticWerxMCPClient
from .jira_client import JiraClient
from .jira_tools import JiraToolHandler
from .mcp_connection_manager import MCPConnectionManager, MCPServerConnection

__all__ = [
    "AgenticWerxMCPClient",
    "AgenticWerxAPI",
    "JiraClient",
    "JiraToolHandler",
    "MCPConnectionManager",
    "MCPServerConnection",
]
