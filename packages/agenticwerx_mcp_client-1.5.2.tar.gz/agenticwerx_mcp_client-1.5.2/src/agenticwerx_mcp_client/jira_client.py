"""
Jira API client with v2/v3 adapter pattern.

Loads config from ~/.agenticwerx/config.json and provides a unified
interface for Jira Cloud (v3) and Jira Server/Data Center (v2).
"""

import asyncio
import json
import logging
import os
from base64 import b64encode
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger(__name__)

DEFAULT_CONFIG_PATH = Path.home() / ".agenticwerx" / "config.json"


def _resolve_config_path() -> Path:
    """Resolve the config file path.

    Priority:
      1. AGENTICWERX_CONFIG env var (explicit override, any path)
      2. .agenticwerx/config.json in the current working directory (workspace-level)
      3. ~/.agenticwerx/config.json (user-level default)
    """
    env_path = os.environ.get("AGENTICWERX_CONFIG")
    if env_path:
        return Path(env_path).expanduser().resolve()

    workspace_path = Path.cwd() / ".agenticwerx" / "config.json"
    if workspace_path.exists():
        return workspace_path

    return DEFAULT_CONFIG_PATH


class JiraConfigError(Exception):
    """Raised when Jira configuration is missing or invalid."""


class JiraAPIError(Exception):
    """Raised when a Jira API call fails."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        self.status_code = status_code
        super().__init__(message)


# ---------------------------------------------------------------------------
# ADF (Atlassian Document Format) → plain text
# ---------------------------------------------------------------------------


def adf_to_text(node: Any) -> str:
    """Recursively extract plain text from an ADF document (Jira Cloud v3)."""
    if isinstance(node, str):
        return node
    if not isinstance(node, dict):
        return ""

    parts: list[str] = []

    # Text node
    if node.get("type") == "text":
        parts.append(node.get("text", ""))

    # Mention node — render as display text
    if node.get("type") == "mention":
        attrs = node.get("attrs", {})
        parts.append(f"@{attrs.get('text', attrs.get('id', ''))}")

    # Recurse into children
    for child in node.get("content", []):
        parts.append(adf_to_text(child))

    # Block-level nodes get trailing newlines
    block_types = {
        "paragraph",
        "heading",
        "bulletList",
        "orderedList",
        "listItem",
        "blockquote",
        "codeBlock",
        "rule",
        "table",
        "tableRow",
        "tableCell",
        "tableHeader",
    }
    text = "".join(parts)
    if node.get("type") in block_types and text:
        text = text.rstrip() + "\n"

    return text


# ---------------------------------------------------------------------------
# Config loader
# ---------------------------------------------------------------------------


def load_jira_config() -> dict[str, Any] | None:
    """Load Jira config from the resolved config file path.

    Resolution order:
      1. AGENTICWERX_CONFIG env var
      2. .agenticwerx/config.json in cwd (workspace-level)
      3. ~/.agenticwerx/config.json (user-level)

    Returns None if no config file is found or the jira section is missing/incomplete.
    """
    config_path = _resolve_config_path()

    if not config_path.exists():
        logger.debug(f"Config file not found: {config_path}")
        return None

    logger.debug(f"Loading config from: {config_path}")

    try:
        data = json.loads(config_path.read_text())
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning(f"Failed to read config file: {exc}")
        return None

    jira_cfg = data.get("jira")
    if not isinstance(jira_cfg, dict):
        return None

    # Minimum required fields
    required = {"baseUrl", "apiToken"}
    if not required.issubset(jira_cfg):
        logger.debug("Jira config missing required fields (baseUrl, apiToken)")
        return None

    # Default apiVersion
    jira_cfg.setdefault("apiVersion", "v3")
    return jira_cfg


# ---------------------------------------------------------------------------
# Jira client
# ---------------------------------------------------------------------------


class JiraClient:
    """Unified Jira client that adapts to v2 (Server) or v3 (Cloud)."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.base_url: str = config["baseUrl"].rstrip("/")
        self.api_version: str = config.get("apiVersion", "v3")
        self.email: str | None = config.get("email")
        self.api_token: str = config["apiToken"]

        # Build base REST path
        version_num = "3" if self.api_version == "v3" else "2"
        self.rest_base = f"{self.base_url}/rest/api/{version_num}"

        # Auth header
        if self.api_version == "v3" and self.email:
            # Jira Cloud: Basic auth with email:token
            creds = b64encode(f"{self.email}:{self.api_token}".encode()).decode()
            self._auth_header = f"Basic {creds}"
        else:
            # Jira Server/DC: Bearer token or Basic with token only
            self._auth_header = f"Bearer {self.api_token}"

        self._client = httpx.AsyncClient(
            headers={
                "Authorization": self._auth_header,
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    # -- low-level request helper ------------------------------------------

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        _max_retries: int = 3,
    ) -> Any:
        url = f"{self.rest_base}{path}"
        backoff = 1.0

        for attempt in range(_max_retries + 1):
            try:
                resp = await self._client.request(
                    method,
                    url,
                    params=params,
                    json=json_body,
                )
            except httpx.HTTPError as exc:
                raise JiraAPIError(f"HTTP error contacting Jira: {exc}") from exc

            # Rate limited — retry with backoff
            if resp.status_code == 429 and attempt < _max_retries:
                retry_after = resp.headers.get("Retry-After")
                delay = float(retry_after) if retry_after else backoff
                logger.warning(
                    f"Jira rate limit hit (429). Retrying in {delay}s "
                    f"(attempt {attempt + 1}/{_max_retries})"
                )
                await asyncio.sleep(delay)
                backoff *= 2
                continue

            break

        if resp.status_code == 429:
            raise JiraAPIError(
                f"Jira rate limit exceeded after {_max_retries} retries",
                status_code=429,
            )
        if resp.status_code == 401:
            raise JiraAPIError(
                "Jira authentication failed — check your apiToken "
                f"(and email for Cloud) in {_resolve_config_path()}",
                status_code=401,
            )
        if resp.status_code == 404:
            raise JiraAPIError(
                f"Jira resource not found: {path}",
                status_code=404,
            )
        if resp.status_code >= 400:
            body = resp.text[:500]
            raise JiraAPIError(
                f"Jira API error ({resp.status_code}): {body}",
                status_code=resp.status_code,
            )

        return resp.json()

    # -- description normalizer --------------------------------------------

    def _normalize_description(self, raw: Any) -> str:
        """Convert a description field to plain text regardless of format."""
        if raw is None:
            return ""
        if isinstance(raw, str):
            return raw
        if isinstance(raw, dict):
            # ADF document (v3)
            return adf_to_text(raw).strip()
        return str(raw)

    # -- issue field extractor ---------------------------------------------

    def _extract_issue(self, data: dict[str, Any]) -> dict[str, Any]:
        """Pull the fields we care about from a raw Jira issue response."""
        fields = data.get("fields", {})

        assignee_raw = fields.get("assignee")
        assignee = (
            assignee_raw.get("displayName", assignee_raw.get("name", ""))
            if isinstance(assignee_raw, dict)
            else None
        )

        priority_raw = fields.get("priority")
        priority = priority_raw.get("name") if isinstance(priority_raw, dict) else None

        status_raw = fields.get("status")
        status = status_raw.get("name") if isinstance(status_raw, dict) else None

        story_points = fields.get("story_points") or fields.get("customfield_10016")

        # Acceptance criteria — common custom field names
        acceptance_criteria = (
            fields.get("acceptance_criteria")
            or fields.get("customfield_10035")
            or fields.get("customfield_10028")
        )
        if acceptance_criteria:
            acceptance_criteria = self._normalize_description(acceptance_criteria)

        return {
            "key": data.get("key", ""),
            "summary": fields.get("summary", ""),
            "description": self._normalize_description(fields.get("description")),
            "status": status,
            "assignee": assignee,
            "priority": priority,
            "labels": fields.get("labels", []),
            "story_points": story_points,
            "acceptance_criteria": acceptance_criteria,
            "issue_type": (
                fields.get("issuetype", {}).get("name")
                if isinstance(fields.get("issuetype"), dict)
                else None
            ),
        }

    # -- public API --------------------------------------------------------

    async def get_issue(self, issue_key: str) -> dict[str, Any]:
        """Fetch a single issue by key (e.g. ENG-1234)."""
        data = await self._request("GET", f"/issue/{issue_key}")
        return self._extract_issue(data)

    async def search_issues(
        self,
        jql: str,
        max_results: int = 10,
    ) -> list[dict[str, Any]]:
        """Search issues using JQL."""
        data = await self._request(
            "GET",
            "/search",
            params={"jql": jql, "maxResults": max_results},
        )
        return [self._extract_issue(issue) for issue in data.get("issues", [])]

    async def get_comments(self, issue_key: str) -> list[dict[str, Any]]:
        """Get comments on an issue."""
        data = await self._request("GET", f"/issue/{issue_key}/comment")
        comments: list[dict[str, Any]] = []
        for c in data.get("comments", []):
            author_raw = c.get("author", {})
            comments.append(
                {
                    "author": author_raw.get("displayName", author_raw.get("name", "")),
                    "body": self._normalize_description(c.get("body")),
                    "created": c.get("created", ""),
                    "updated": c.get("updated", ""),
                }
            )
        return comments

    async def get_transitions(self, issue_key: str) -> list[dict[str, Any]]:
        """Get available transitions for an issue."""
        data = await self._request("GET", f"/issue/{issue_key}/transitions")
        return [{"id": t["id"], "name": t["name"]} for t in data.get("transitions", [])]

    async def transition_issue(self, issue_key: str, transition_id: str) -> None:
        """Transition an issue to a new status."""
        await self._request(
            "POST",
            f"/issue/{issue_key}/transitions",
            json_body={"transition": {"id": transition_id}},
        )

    async def create_issue(self, fields: dict[str, Any]) -> dict[str, Any]:
        """Create a new Jira issue. Returns the created issue data."""
        data = await self._request("POST", "/issue", json_body={"fields": fields})
        # Fetch the full issue so we return normalized fields
        return await self.get_issue(data["key"])
