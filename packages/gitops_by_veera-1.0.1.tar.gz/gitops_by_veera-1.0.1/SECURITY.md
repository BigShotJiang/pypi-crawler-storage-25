# Security Policy — gitops-by-veera

## Overview

GitOps is designed with a security-first architecture at every layer. This document describes the protective mechanisms in place and how to report vulnerabilities responsibly.

---

## Credential Protection

### Storage
- Credentials are stored in `~/.gitops_by_veera_config.json` with `chmod 600` permissions (owner read/write only).
- The file contains only `github_token` and `groq_api_key`. No other data is persisted.

### Priority & Environment Variables
- Credentials are loaded in priority order: environment variables (`GITHUB_TOKEN`, `GROQ_API_KEY`) first, then the config file.
- Environment variables are never written to disk by GitOps.

### Secret Redaction
- A `SecretRedactionFilter` is applied to all log handlers. It scrubs:
  - Known token patterns (`ghp_...`, `github_pat_...`, `ghs_...`, `gho_...`, `ghu_...`, `gsk_...`)
  - `Authorization: Bearer ...` header content
  - Exact runtime values of loaded credentials
- Credentials never appear in log files, stack traces, standard error, or console output.

---

## Command Injection Prevention

### Shell Execution Policy
- `shell=True` is **never used** in any subprocess call. All commands are executed via `subprocess.run(..., shell=False)` with an explicit argument list.
- The `cd` shell state mutation is never executed as a process. Directory context is passed exclusively via the `cwd` parameter of `subprocess.run`.

### Binary Whitelist
Only these executables are permitted: `git`, `pwd`, `mkdir`, `ls`. Any other binary is immediately rejected with a `ForbiddenBinaryError`.

### Prohibited Token Detection
The following characters and strings are blocked in all arguments:
```
; && || | > >> < $ ` $( sudo rm chmod chown curl wget python bash sh zsh powershell cmd.exe
```
Any argument containing these tokens raises a `CommandInjectionError` before execution.

### Path Traversal Protection
All arguments containing `..` are resolved and verified to remain within the detected repository root or current working directory. Escape attempts raise a `PathTraversalError`.

---

## Prompt Injection Defense

### Untrusted Context Separation
The system prompt explicitly instructs the LLM to treat all local workspace context — repository files, commit messages, issue bodies, README content, CI configuration, branch names — as **untrusted input**.

### Policy Sovereignty
The system enforces an absolute security boundary. The LLM is instructed to completely reject any directive that conflicts with the established execution policy, regardless of origin. No repository artifact can override the system's security constraints.

### Structured Output Enforcement
All LLM outputs are parsed into strict Pydantic models. Free-form text responses, markdown-wrapped JSON, and schema-mismatched outputs are rejected immediately, triggering model cascade fallback. No unvalidated loose dictionary parsing is performed.

---

## GitHub API Security

### Endpoint Whitelist
Only the following GitHub REST API endpoints are permitted:
- `GET/POST /user/repos`
- `POST /orgs/{org}/repos`
- `GET/POST/PATCH /repos/{owner}/{repo}/issues[/{number}]`
- `GET/POST/PATCH /repos/{owner}/{repo}/pulls[/{number}]`
- `POST /repos/{owner}/{repo}/pulls/{number}/reviews`
- `PUT /repos/{owner}/{repo}/pulls/{number}/merge`
- `POST /repos/{owner}/{repo}/actions/workflows/{id}/dispatches`
- `GET/POST /repos/{owner}/{repo}/git/refs[/{ref}]`

Any endpoint not matching this whitelist raises a `CloudEndpointViolationError`.

### DELETE Method Block
All `DELETE` HTTP requests are unconditionally rejected with a `SecurityViolationError`. Repository deletion and any other destructive resource removal is impossible.

### Payload Sanitization
Cloud operation payloads are sanitized against per-endpoint field allowlists. Unknown, suspicious, or excessively nested keys are stripped before transmission. This prevents parameter injection via LLM-generated payloads.

---

## Git History Rewrite Safeguards

The following operations are **strictly blocked** and cannot be executed under any circumstances:
- `git filter-branch`
- `git reflog expire`
- `git gc --prune=now`

The following operations require **explicit user confirmation** at runtime:
- `git reset --hard`
- `git clean -fd`
- `git branch -D`
- `git push --force` / `git push -f`
- `git rebase`
- `git cherry-pick`
- `git stash clear`

---

## Concurrency Safety

A PID-based lockfile prevents multiple simultaneous GitOps instances from running in the same repository. Stale locks (from crashed processes) are detected via OS-level PID existence checks and cleaned up automatically.

---

## Token Requirements

GitOps requires **fine-grained Personal Access Tokens** only. Classic admin tokens are explicitly prohibited in documentation and enforced through user-facing warnings during setup. Fine-grained tokens should be scoped to:
- Specific repositories (not all repositories)
- Minimum required permissions (Contents: Read & Write, Pull Requests: Read & Write, Issues: Read & Write, Actions: Read & Write)

---

## Responsible Disclosure

If you discover a security vulnerability, please report it privately by opening a [GitHub Security Advisory](https://docs.github.com/en/code-security/security-advisories) on this repository rather than filing a public issue. Do not include proof-of-concept exploit code in the initial report.

We will acknowledge receipt within 72 hours and aim to release a patch within 14 days for critical vulnerabilities.
