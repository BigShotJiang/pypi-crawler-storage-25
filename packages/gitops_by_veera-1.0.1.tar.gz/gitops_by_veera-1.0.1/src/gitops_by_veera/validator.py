"""Multi-stage validation engine for local and cloud operations."""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Union

from gitops_by_veera.constants import (
    ALLOWED_BINARIES,
    ALLOWED_GITHUB_ENDPOINTS,
    ALLOWED_HTTP_METHODS,
    ALLOWED_PAYLOAD_FIELDS,
    BLOCKED_GIT_OPERATIONS,
    DANGEROUS_BINARIES,
    DESTRUCTIVE_ENDPOINT_PATTERN,
    PROHIBITED_TOKENS,
    SHELL_OPERATORS,
    WARNING_GIT_OPERATIONS,
)
from gitops_by_veera.exceptions import (
    CloudEndpointViolationError,
    CommandInjectionError,
    ForbiddenBinaryError,
    ForbiddenOperationError,
    PathTraversalError,
    SecurityViolationError,
)
from gitops_by_veera.logger import get_logger
from gitops_by_veera.models import CloudOperation, ExecutionPlan, LocalOperation

logger = get_logger("gitops.validator")


# ---------------------------------------------------------------------------
# Local operation validation
# ---------------------------------------------------------------------------


def validate_local_operation(op: LocalOperation, repo_root: Path) -> None:
    """Run all security checks against a local git operation.

    Raises SecurityViolationError subclasses on any violation.
    """
    _check_binary(op.binary)
    _check_blocked_operations(op.binary, op.args)
    _check_injection_tokens(op.args)
    _check_path_traversal(op.args, repo_root)


def _check_binary(binary: str) -> None:
    if binary not in ALLOWED_BINARIES:
        raise ForbiddenBinaryError(
            f"Binary '{binary}' is not permitted.",
            detail=f"Allowed binaries: {sorted(ALLOWED_BINARIES)}",
        )


def _check_blocked_operations(binary: str, args: list[str]) -> None:
    for blocked_binary, blocked_prefix in BLOCKED_GIT_OPERATIONS:
        if binary == blocked_binary and _args_start_with(args, blocked_prefix):
            raise ForbiddenOperationError(
                f"Operation '{binary} {' '.join(blocked_prefix)}' is strictly blocked.",
                detail="This command can permanently destroy Git history.",
            )


def _check_injection_tokens(args: list[str]) -> None:
    for arg in args:
        # Check for shell operators (substring match - they're dangerous anywhere)
        for operator in SHELL_OPERATORS:
            if operator in arg:
                raise CommandInjectionError(
                    f"Shell operator '{operator}' detected in argument '{arg}'.",
                    detail="Possible shell injection attempt.",
                )
        
        # Check for dangerous binaries (exact match on tokens only)
        # Split the argument to check individual tokens
        tokens = arg.split()
        for token in tokens:
            if token in DANGEROUS_BINARIES:
                raise CommandInjectionError(
                    f"Prohibited binary '{token}' detected in argument '{arg}'.",
                    detail="Possible shell injection attempt.",
                )
        
        if arg.strip() == "cd":
            raise CommandInjectionError(
                "The 'cd' command is not executable via subprocess. "
                "Directory context must be passed via cwd parameter.",
                detail="Shell state mutations are not allowed.",
            )


def _check_path_traversal(args: list[str], repo_root: Path) -> None:
    for arg in args:
        if ".." in arg:
            try:
                resolved = (repo_root / arg).resolve()
                root_resolved = repo_root.resolve()
                if not str(resolved).startswith(str(root_resolved)):
                    raise PathTraversalError(
                        f"Path traversal detected in argument '{arg}'.",
                        detail=f"Resolved path '{resolved}' escapes repo root '{root_resolved}'.",
                    )
            except (OSError, ValueError) as exc:
                raise PathTraversalError(
                    f"Cannot resolve path '{arg}': {exc}",
                    detail="Path traversal protection triggered.",
                ) from exc


def _args_start_with(args: list[str], prefix: list[str]) -> bool:
    return args[: len(prefix)] == prefix


def is_warning_operation(op: LocalOperation) -> bool:
    """Return True if this operation requires user confirmation before execution."""
    for warn_binary, warn_prefix in WARNING_GIT_OPERATIONS:
        if op.binary == warn_binary and _args_start_with(op.args, warn_prefix):
            return True
    return False


# ---------------------------------------------------------------------------
# Cloud operation validation
# ---------------------------------------------------------------------------


def validate_cloud_operation(op: CloudOperation) -> None:
    """Validate a cloud GitHub API operation against the endpoint whitelist and policies."""
    _check_http_method(op.method)
    _check_destructive_endpoint(op.endpoint, op.method)
    _check_endpoint_whitelist(op.endpoint)
    _sanitize_payload(op)


def _check_http_method(method: str) -> None:
    if method not in ALLOWED_HTTP_METHODS:
        raise CloudEndpointViolationError(
            f"HTTP method '{method}' is not permitted.",
            detail=f"Allowed methods: {sorted(ALLOWED_HTTP_METHODS)}",
        )


def _check_destructive_endpoint(endpoint: str, method: str) -> None:
    if method == "DELETE":
        raise SecurityViolationError(
            "DELETE requests are strictly prohibited.",
            detail="No destructive cloud operations are allowed.",
        )
    if DESTRUCTIVE_ENDPOINT_PATTERN.match(endpoint) and method not in ("GET",):
        raise CloudEndpointViolationError(
            f"Endpoint '{endpoint}' targets a repository-level resource with method '{method}'. "
            "Repository deletion or modification at root level is blocked.",
            detail="Only safe, scoped API endpoints are permitted.",
        )


def _check_endpoint_whitelist(endpoint: str) -> None:
    for pattern in ALLOWED_GITHUB_ENDPOINTS:
        if pattern.match(endpoint):
            return
    raise CloudEndpointViolationError(
        f"Endpoint '{endpoint}' is not in the allowed endpoint whitelist.",
        detail="Only explicitly whitelisted GitHub REST API endpoints are allowed.",
    )


def _sanitize_payload(op: CloudOperation) -> None:
    """Strip any payload fields that are not in the known safe allowlist for this endpoint type."""
    endpoint_key = _detect_endpoint_key(op.endpoint)
    allowed = ALLOWED_PAYLOAD_FIELDS.get(endpoint_key)
    if allowed is None:
        return
    unknown_keys = set(op.payload.keys()) - allowed
    if unknown_keys:
        logger.warning(
            "Stripping unknown payload fields %s from endpoint '%s'.", unknown_keys, op.endpoint
        )
        for key in unknown_keys:
            del op.payload[key]


def _detect_endpoint_key(endpoint: str) -> str:
    """Map an endpoint path to a payload-field allowlist key."""
    mapping = {
        "pulls": "pulls",
        "issues": "issues",
        "repos": "repos",
        "merge": "merge",
        "refs": "refs",
        "dispatches": "dispatches",
        "reviews": "reviews",
    }
    for segment, key in mapping.items():
        if segment in endpoint:
            return key
    return ""


# ---------------------------------------------------------------------------
# Full plan validation
# ---------------------------------------------------------------------------


def validate_plan(plan: ExecutionPlan, repo_root: Path) -> list[str]:
    """Validate every operation in the plan.

    Returns a list of warning messages for operations requiring user confirmation.
    Raises on any security violation.
    """
    warnings: list[str] = []

    for idx, op in enumerate(plan.operations):
        logger.debug("Validating operation %d: type=%s", idx, op.type)

        if op.risk_level == "blocked":
            raise ForbiddenOperationError(
                f"Operation {idx} is classified as 'blocked' by the model. Aborting.",
                detail=f"Reason: {op.reason}",
            )

        if isinstance(op, LocalOperation):
            validate_local_operation(op, repo_root)
            if is_warning_operation(op):
                warnings.append(
                    f"Operation {idx} ({op.binary} {' '.join(op.args)}): {op.reason}"
                )

        elif isinstance(op, CloudOperation):
            validate_cloud_operation(op)

    return warnings
