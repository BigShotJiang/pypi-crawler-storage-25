"""Credential management, environment detection, and PID lock handling."""

from __future__ import annotations

import json
import os
import stat
import subprocess
import time
from pathlib import Path
from typing import Optional

from gitops_by_veera.exceptions import (
    ConfigurationError,
    CredentialError,
    LockAcquisitionError,
    RepositoryNotFoundError,
)
from gitops_by_veera.logger import get_logger, register_secret
from gitops_by_veera.models import CredentialConfig, LockMetadata

CONFIG_PATH = Path.home() / ".gitops_by_veera_config.json"
FALLBACK_LOCK_PATH = Path.home() / ".gitops_by_veera.lock"

logger = get_logger("gitops.config")


# ---------------------------------------------------------------------------
# Repository discovery
# ---------------------------------------------------------------------------


def find_repo_root(start: Optional[Path] = None) -> Optional[Path]:
    """Walk up from start directory searching for a .git folder.

    Returns the repository root path or None if not inside a git repo.
    """
    cwd = start or Path.cwd()
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            shell=False,
            timeout=10,
        )
        if result.returncode == 0:
            return Path(result.stdout.strip())
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    current = cwd
    while True:
        if (current / ".git").is_dir():
            return current
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def require_repo_root() -> Path:
    """Return the git repository root or raise RepositoryNotFoundError."""
    root = find_repo_root()
    if root is None:
        raise RepositoryNotFoundError(
            "Git repository not found. Initialize one? (y/n) — run `git init` if desired."
        )
    return root


# ---------------------------------------------------------------------------
# Credentials
# ---------------------------------------------------------------------------


def _apply_secure_permissions(path: Path) -> None:
    """Apply chmod 600 (owner read/write only) to a file if on a POSIX system."""
    try:
        path.chmod(stat.S_IRUSR | stat.S_IWUSR)
    except NotImplementedError:
        pass


def load_credentials() -> CredentialConfig:
    """Load credentials using priority: env vars → config file.

    Registers loaded secret values with the logger redaction filter.
    Raises CredentialError if credentials cannot be located.
    """
    github_token = os.environ.get("GITHUB_TOKEN", "")
    groq_api_key = os.environ.get("GROQ_API_KEY", "")

    if github_token and groq_api_key:
        logger.debug("Credentials loaded from environment variables.")
        _register_secrets(github_token, groq_api_key)
        try:
            return CredentialConfig(github_token=github_token, groq_api_key=groq_api_key)
        except Exception as exc:
            raise CredentialError(f"Environment credential validation failed: {exc}") from exc

    if CONFIG_PATH.exists():
        try:
            raw = CONFIG_PATH.read_text(encoding="utf-8")
            data = json.loads(raw)
            cfg = CredentialConfig(**data)
            if not github_token:
                github_token = cfg.github_token
            if not groq_api_key:
                groq_api_key = cfg.groq_api_key
            full_cfg = CredentialConfig(github_token=github_token, groq_api_key=groq_api_key)
            _register_secrets(full_cfg.github_token, full_cfg.groq_api_key)
            logger.debug("Credentials loaded from config file.")
            return full_cfg
        except (json.JSONDecodeError, TypeError, ValueError) as exc:
            raise ConfigurationError(f"Config file is malformed: {exc}") from exc

    raise CredentialError(
        "No credentials found. Run `git-ops setup` to configure your API keys, "
        "or set GITHUB_TOKEN and GROQ_API_KEY environment variables."
    )


def _register_secrets(github_token: str, groq_api_key: str) -> None:
    register_secret(github_token)
    register_secret(groq_api_key)


def save_credentials(github_token: str, groq_api_key: str) -> None:
    """Persist credentials to the config file with secure permissions."""
    try:
        cfg = CredentialConfig(github_token=github_token, groq_api_key=groq_api_key)
    except Exception as exc:
        raise CredentialError(f"Credential validation failed: {exc}") from exc

    payload = {"github_token": cfg.github_token, "groq_api_key": cfg.groq_api_key}
    CONFIG_PATH.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    _apply_secure_permissions(CONFIG_PATH)
    _register_secrets(cfg.github_token, cfg.groq_api_key)
    logger.info("Credentials saved to %s", CONFIG_PATH)


# ---------------------------------------------------------------------------
# PID lock
# ---------------------------------------------------------------------------


def _lock_path() -> Path:
    """Determine the appropriate lock file path."""
    repo_root = find_repo_root()
    if repo_root is not None:
        return repo_root / ".git" / ".gitops.lock"
    return FALLBACK_LOCK_PATH


def _is_pid_running(pid: int) -> bool:
    """Return True if a process with the given PID is currently running."""
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def acquire_lock() -> Path:
    """Acquire a PID-based lock file.

    If a stale lock (from a dead process) is detected, it is cleaned up
    automatically. Raises LockAcquisitionError if a live lock exists.
    """
    lock = _lock_path()

    if lock.exists():
        try:
            data = json.loads(lock.read_text(encoding="utf-8"))
            meta = LockMetadata(**data)
            if _is_pid_running(meta.pid):
                raise LockAcquisitionError(
                    f"GitOps is already running (PID {meta.pid}). "
                    "Only one instance may run per repository at a time."
                )
            logger.warning(
                "Stale lock file found (PID %s is not running). Removing.", meta.pid
            )
            lock.unlink(missing_ok=True)
        except (json.JSONDecodeError, TypeError, ValueError, KeyError):
            logger.warning("Unreadable lock file found. Removing stale lock.")
            lock.unlink(missing_ok=True)

    meta = LockMetadata(pid=os.getpid(), timestamp=time.time())
    lock.write_text(meta.model_dump_json(), encoding="utf-8")
    logger.debug("Lock acquired at %s (PID %s).", lock, os.getpid())
    return lock


def release_lock(lock: Path) -> None:
    """Release the PID lock file if it belongs to the current process."""
    if not lock.exists():
        return
    try:
        data = json.loads(lock.read_text(encoding="utf-8"))
        meta = LockMetadata(**data)
        if meta.pid == os.getpid():
            lock.unlink(missing_ok=True)
            logger.debug("Lock released at %s.", lock)
    except (json.JSONDecodeError, TypeError, ValueError):
        lock.unlink(missing_ok=True)
