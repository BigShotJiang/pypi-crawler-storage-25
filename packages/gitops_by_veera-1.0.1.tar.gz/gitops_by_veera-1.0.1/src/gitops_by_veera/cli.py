"""Click-based CLI entry point for git-ops."""

from __future__ import annotations

import getpass
import sys
from pathlib import Path
from typing import Optional

import click

from gitops_by_veera.config import (
    acquire_lock,
    find_repo_root,
    load_credentials,
    release_lock,
    require_repo_root,
    save_credentials,
)
from gitops_by_veera.constants import WARNING_MESSAGE
from gitops_by_veera.exceptions import (
    ConfigurationError,
    CredentialError,
    GitOpsError,
    LockAcquisitionError,
    RemediationLimitError,
    RepositoryNotFoundError,
    SecurityViolationError,
)
from gitops_by_veera.logger import enable_debug, get_logger
from gitops_by_veera.models import ExecutionPlan, OperationResult


def _prompt(message: str) -> str:
    """Prompt the user for input; works in terminal, Colab, and Jupyter."""
    try:
        return input(message).strip()
    except EOFError:
        return ""


def _confirm(message: str, default: bool = False) -> bool:
    answer = _prompt(message).lower()
    if answer in ("y", "yes"):
        return True
    if answer in ("n", "no"):
        return False
    return default


def _display_plan(plan: ExecutionPlan) -> None:
    click.echo("\n─── Execution Plan ──────────────────────────────────")
    for idx, op in enumerate(plan.operations):
        risk_color = {"safe": "green", "warning": "yellow", "blocked": "red"}.get(
            op.risk_level, "white"
        )
        click.echo(f"\n  [{idx + 1}] Type       : {op.type.upper()}")
        click.echo(
            f"      Risk       : " + click.style(op.risk_level.upper(), fg=risk_color, bold=True)
        )
        if op.type == "local":
            click.echo(f"      Command    : {op.binary} {' '.join(op.args)}")  # type: ignore[union-attr]
        else:
            click.echo(f"      Endpoint   : {op.method} {op.endpoint}")  # type: ignore[union-attr]
            if op.payload:  # type: ignore[union-attr]
                click.echo(f"      Payload    : {op.payload}")  # type: ignore[union-attr]
        click.echo(f"      Reason     : {op.reason}")
    click.echo("\n─────────────────────────────────────────────────────\n")


def _display_results(results: list[OperationResult]) -> None:
    click.echo("\n─── Execution Results ───────────────────────────────")
    for r in results:
        status = click.style("✓ SUCCESS", fg="green") if r.success else click.style("✗ FAILED", fg="red")
        click.echo(f"\n  [{r.operation_index + 1}] {r.operation_type.upper()} — {status}")
        if r.stdout:
            click.echo(f"      Output:\n{_indent(r.stdout)}")
        if r.stderr and not r.success:
            click.echo(click.style(f"      Error:\n{_indent(r.stderr)}", fg="red"))
    click.echo("\n─────────────────────────────────────────────────────\n")


def _indent(text: str, spaces: int = 8) -> str:
    pad = " " * spaces
    return "\n".join(pad + line for line in text.splitlines())


@click.group()
def cli() -> None:
    """GitOps — conversational Git and GitHub operations coordinator."""


@cli.command("setup")
def setup_cmd() -> None:
    """Interactively configure Groq API key and GitHub token."""
    click.echo(click.style("\n  GitOps Setup\n", bold=True))
    click.echo(
        "  Provide your credentials below. They are stored in ~/.gitops_by_veera_config.json\n"
        "  with restricted file permissions (chmod 600).\n\n"
        "  IMPORTANT: Use fine-grained GitHub Personal Access Tokens only.\n"
        "  Classic admin tokens are strictly prohibited.\n"
    )

    try:
        groq_api_key = getpass.getpass("  Groq API Key: ").strip()
        github_token = getpass.getpass("  GitHub Token (fine-grained PAT): ").strip()
    except (KeyboardInterrupt, EOFError):
        click.echo("\nSetup cancelled.")
        sys.exit(0)

    if not groq_api_key or not github_token:
        click.echo(click.style("\n  Error: Both credentials are required.\n", fg="red"))
        sys.exit(1)

    try:
        save_credentials(github_token=github_token, groq_api_key=groq_api_key)
        click.echo(
            click.style("\n  Credentials saved successfully.\n", fg="green")
            + "  Run `git-ops run \"<your request>\"` to get started.\n"
        )
    except CredentialError as exc:
        click.echo(click.style(f"\n  Credential error: {exc}\n", fg="red"))
        sys.exit(1)


@cli.command("run")
@click.argument("prompt")
@click.option("--debug", is_flag=True, default=False, help="Enable verbose tracing and telemetry.")
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Plan and validate without executing operations.",
)
def run_cmd(prompt: str, debug: bool, dry_run: bool) -> None:
    """Execute a natural language Git/GitHub operation pipeline."""
    from gitops_by_veera.agent import GitOpsAgent, MAX_REMEDIATION_CYCLES

    logger = get_logger("gitops.cli", debug=debug)
    if debug:
        enable_debug(logger)

    lock: Optional[Path] = None

    try:
        creds = load_credentials()
    except (CredentialError, ConfigurationError) as exc:
        click.echo(click.style(f"\n  {exc}\n", fg="red"))
        sys.exit(1)

    try:
        lock = acquire_lock()
    except LockAcquisitionError as exc:
        click.echo(click.style(f"\n  {exc}\n", fg="red"))
        sys.exit(1)

    try:
        repo_root = find_repo_root() or Path.cwd()

        if dry_run:
            click.echo(click.style("\n  [DRY-RUN MODE] No operations will be executed.\n", fg="yellow"))

        agent = GitOpsAgent(
            groq_api_key=creds.groq_api_key,
            github_token=creds.github_token,
            repo_root=repo_root,
            debug=debug,
        )

        click.echo(f"\n  Planning: {click.style(prompt, bold=True)}\n")

        try:
            plan = agent.build_plan(prompt)
        except GitOpsError as exc:
            click.echo(click.style(f"\n  Planning failed: {exc}\n", fg="red"))
            sys.exit(1)

        _display_plan(plan)

        try:
            warnings = agent.validate(plan)
        except SecurityViolationError as exc:
            click.echo(click.style(f"\n  Security violation: {exc}\n", fg="red"))
            if debug and exc.detail:
                click.echo(click.style(f"  Detail: {exc.detail}\n", fg="red"))
            sys.exit(1)

        for warning in warnings:
            click.echo(click.style(f"  ⚠  {warning}", fg="yellow"))

        if warnings:
            if not _confirm(WARNING_MESSAGE):
                click.echo("  Aborted by user.")
                sys.exit(0)

        if not dry_run:
            if not _confirm("  Proceed with execution? (y/n): "):
                click.echo("  Aborted by user.")
                sys.exit(0)

        remediation_cycles = 0
        all_results: list[OperationResult] = []

        while True:
            results = agent.execute(plan, dry_run=dry_run)
            all_results.extend(results)

            failed = [r for r in results if not r.success]
            if not failed or dry_run:
                break

            if remediation_cycles >= MAX_REMEDIATION_CYCLES:
                click.echo(
                    click.style(
                        f"\n  Remediation limit ({MAX_REMEDIATION_CYCLES}) reached. "
                        "Please resolve the issue manually.\n",
                        fg="red",
                    )
                )
                break

            failed_result = failed[0]
            click.echo(
                click.style(
                    f"\n  Operation {failed_result.operation_index + 1} failed. "
                    "Generating remediation plan...\n",
                    fg="yellow",
                )
            )

            try:
                remediation_plan = agent.remediate(failed_result)
            except GitOpsError as exc:
                click.echo(click.style(f"\n  Remediation planning failed: {exc}\n", fg="red"))
                break

            _display_plan(remediation_plan)

            try:
                agent.validate(remediation_plan)
            except SecurityViolationError as exc:
                click.echo(
                    click.style(f"\n  Remediation plan failed security check: {exc}\n", fg="red")
                )
                break

            if not _confirm("  Apply remediation? (y/n): "):
                click.echo("  Remediation declined. Stopping.")
                break

            plan = remediation_plan
            remediation_cycles += 1

        if not dry_run:
            _display_results(all_results)

        agent.metrics.finalize()

        if debug:
            click.echo("\n")
            for line in agent.metrics.summary_lines():
                click.echo("  " + line)
            click.echo()

        failed_count = sum(1 for r in all_results if not r.success)
        if failed_count:
            click.echo(click.style(f"\n  {failed_count} operation(s) failed.\n", fg="red"))
            sys.exit(1)
        elif not dry_run:
            click.echo(click.style("\n  All operations completed successfully.\n", fg="green"))
        else:
            click.echo(click.style("\n  Dry-run complete. No changes were made.\n", fg="cyan"))

    except KeyboardInterrupt:
        click.echo("\n\n  Interrupted by user.")
        sys.exit(130)
    except GitOpsError as exc:
        click.echo(click.style(f"\n  Error: {exc}\n", fg="red"))
        sys.exit(1)
    finally:
        if lock is not None:
            release_lock(lock)


def main() -> None:
    """Package entry point."""
    cli()
