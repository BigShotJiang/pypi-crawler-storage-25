"""Custom exception hierarchy for gitops-by-veera."""

from __future__ import annotations


class GitOpsError(Exception):
    """Base exception for all gitops errors."""


class ConfigurationError(GitOpsError):
    """Raised when configuration is missing or invalid."""


class CredentialError(ConfigurationError):
    """Raised when credentials are missing or malformed."""


class LockAcquisitionError(GitOpsError):
    """Raised when the process lock cannot be acquired."""


class ValidationError(GitOpsError):
    """Raised when an operation fails multi-stage validation."""


class SecurityViolationError(ValidationError):
    """Raised when a security policy is violated."""

    def __init__(self, message: str, detail: str = "") -> None:
        super().__init__(message)
        self.detail = detail


class CommandInjectionError(SecurityViolationError):
    """Raised when a shell injection attempt is detected."""


class PathTraversalError(SecurityViolationError):
    """Raised when a path traversal attack is detected."""


class ForbiddenBinaryError(SecurityViolationError):
    """Raised when a disallowed executable binary is requested."""


class ForbiddenOperationError(SecurityViolationError):
    """Raised when a strictly blocked Git operation is requested."""


class CloudEndpointViolationError(SecurityViolationError):
    """Raised when a disallowed GitHub API endpoint is requested."""


class GroqAPIError(GitOpsError):
    """Raised when the Groq API returns an unrecoverable error."""

    def __init__(self, message: str, status_code: int = 0) -> None:
        super().__init__(message)
        self.status_code = status_code


class GroqRateLimitError(GroqAPIError):
    """Raised when Groq rate limits are exhausted across all retries."""


class GroqTimeoutError(GroqAPIError):
    """Raised when Groq API calls time out across all retries."""


class ModelCascadeExhaustedError(GroqAPIError):
    """Raised when all model tiers fail to produce a valid response."""


class GitHubAPIError(GitOpsError):
    """Raised when the GitHub REST API returns an error."""

    def __init__(self, message: str, status_code: int = 0) -> None:
        super().__init__(message)
        self.status_code = status_code


class GitHubRateLimitError(GitHubAPIError):
    """Raised when GitHub rate limits are exhausted."""


class ExecutionError(GitOpsError):
    """Raised when a local git command returns a non-zero exit code."""

    def __init__(self, message: str, stderr: str = "", returncode: int = 1) -> None:
        super().__init__(message)
        self.stderr = stderr
        self.returncode = returncode


class RemediationLimitError(GitOpsError):
    """Raised when the maximum remediation cycle count is exceeded."""


class RepositoryNotFoundError(GitOpsError):
    """Raised when no git repository can be found in the directory tree."""


class ParseError(GitOpsError):
    """Raised when LLM output cannot be parsed into valid structured data."""
