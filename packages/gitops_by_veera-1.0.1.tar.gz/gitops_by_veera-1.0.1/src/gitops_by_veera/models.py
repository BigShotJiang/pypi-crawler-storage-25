"""Pydantic models for structured execution payloads, lock metadata, and session metrics."""

from __future__ import annotations

import time
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


class LocalOperation(BaseModel):
    """Represents a local Git command to execute via subprocess."""

    type: Literal["local"]
    binary: str
    args: list[str] = Field(default_factory=list)
    risk_level: Literal["safe", "warning", "blocked"]
    reason: str

    @field_validator("args")
    @classmethod
    def args_must_be_strings(cls, v: list[str]) -> list[str]:
        for item in v:
            if not isinstance(item, str):
                raise ValueError(f"All args must be strings, got: {type(item)}")
        return v


class CloudOperation(BaseModel):
    """Represents a GitHub REST API call."""

    type: Literal["cloud"]
    endpoint: str
    method: str
    payload: dict[str, Any] = Field(default_factory=dict)
    risk_level: Literal["safe", "warning", "blocked"]
    reason: str


class ExecutionPlan(BaseModel):
    """The top-level structured execution plan returned by the LLM."""

    operations: list[LocalOperation | CloudOperation] = Field(default_factory=list)

    @model_validator(mode="after")
    def must_have_operations(self) -> "ExecutionPlan":
        if not self.operations:
            raise ValueError("Execution plan must contain at least one operation.")
        return self


class LockMetadata(BaseModel):
    """Schema for the PID lock file."""

    pid: int
    timestamp: float = Field(default_factory=time.time)


class OperationResult(BaseModel):
    """Result of executing a single operation."""

    operation_index: int
    operation_type: Literal["local", "cloud"]
    success: bool
    stdout: str = ""
    stderr: str = ""
    returncode: int = 0
    status_code: int = 0
    error_message: str = ""


class SessionMetrics(BaseModel):
    """Telemetry ledger compiled during an agent session."""

    total_commands_executed: int = 0
    successful_operations_count: int = 0
    failed_operations_count: int = 0
    total_llm_calls: int = 0
    model_fallback_transmutation_events: int = 0
    remediation_loop_attempts: int = 0
    total_execution_duration_seconds: float = 0.0
    start_time: float = Field(default_factory=time.time)
    active_model: str = ""

    def record_success(self) -> None:
        self.total_commands_executed += 1
        self.successful_operations_count += 1

    def record_failure(self) -> None:
        self.total_commands_executed += 1
        self.failed_operations_count += 1

    def record_llm_call(self, model: str) -> None:
        self.total_llm_calls += 1
        self.active_model = model

    def record_fallback(self) -> None:
        self.model_fallback_transmutation_events += 1

    def record_remediation(self) -> None:
        self.remediation_loop_attempts += 1

    def finalize(self) -> None:
        self.total_execution_duration_seconds = time.time() - self.start_time

    def summary_lines(self) -> list[str]:
        return [
            "┌─────────────────────────────────────────┐",
            "│         Session Telemetry Summary        │",
            "├─────────────────────────────────────────┤",
            f"│  Total commands executed  : {self.total_commands_executed:<12}│",
            f"│  Successful operations    : {self.successful_operations_count:<12}│",
            f"│  Failed operations        : {self.failed_operations_count:<12}│",
            f"│  Total LLM calls          : {self.total_llm_calls:<12}│",
            f"│  Model fallback events    : {self.model_fallback_transmutation_events:<12}│",
            f"│  Remediation attempts     : {self.remediation_loop_attempts:<12}│",
            f"│  Duration (seconds)       : {self.total_execution_duration_seconds:<12.2f}│",
            f"│  Final model used         : {self.active_model[:12]:<12}│",
            "└─────────────────────────────────────────┘",
        ]


class CredentialConfig(BaseModel):
    """Schema for the JSON configuration file."""

    github_token: str
    groq_api_key: str

    @field_validator("github_token", "groq_api_key")
    @classmethod
    def must_not_be_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("Credential value must not be empty.")
        return v.strip()
