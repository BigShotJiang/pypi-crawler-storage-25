"""gitops-by-veera — conversational autonomous Git and GitHub operations coordinator."""

from __future__ import annotations

__version__ = "1.0.0"
__author__ = "Veera"
__license__ = "MIT"

from gitops_by_veera.agent import GitOpsAgent
from gitops_by_veera.exceptions import GitOpsError

__all__ = ["GitOpsAgent", "GitOpsError", "__version__"]
