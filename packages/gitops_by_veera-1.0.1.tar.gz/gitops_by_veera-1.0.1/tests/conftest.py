"""Shared pytest fixtures for gitops-by-veera test suite."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Generator
from unittest.mock import MagicMock, patch

import pytest

from gitops_by_veera.models import (
    CloudOperation,
    CredentialConfig,
    ExecutionPlan,
    LocalOperation,
    OperationResult,
    SessionMetrics,
)


# ---------------------------------------------------------------------------
# Temporary directories and fake repos
# ---------------------------------------------------------------------------


@pytest.fixture
def tmp_dir(tmp_path: Path) -> Path:
    """A temporary directory guaranteed clean per test."""
    return tmp_path


@pytest.fixture
def fake_repo(tmp_path: Path) -> Path:
    """A temporary directory with a minimal .git structure to simulate a repo root."""
    git_dir = tmp_path / ".git"
    git_dir.mkdir()
    (git_dir / "HEAD").write_text("ref: refs/heads/main\n")
    return tmp_path


# ---------------------------------------------------------------------------
# Credential fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def valid_creds() -> CredentialConfig:
    return CredentialConfig(
        github_token="github_pat_validtoken1234567890abcdefghijklmnopqrstuvwxyz",
        groq_api_key="gsk_validgroqkey1234567890abcdefghijklmnopqrstuvwxyz",
    )


@pytest.fixture
def config_file(tmp_path: Path, valid_creds: CredentialConfig) -> Path:
    """Write a valid credential config JSON to a temp path."""
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(
        json.dumps(
            {
                "github_token": valid_creds.github_token,
                "groq_api_key": valid_creds.groq_api_key,
            }
        )
    )
    return cfg_path


# ---------------------------------------------------------------------------
# Operation and plan fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def safe_local_op() -> LocalOperation:
    return LocalOperation(
        type="local",
        binary="git",
        args=["status"],
        risk_level="safe",
        reason="Check working tree status.",
    )


@pytest.fixture
def safe_cloud_op() -> CloudOperation:
    return CloudOperation(
        type="cloud",
        endpoint="/repos/owner/repo/pulls",
        method="POST",
        payload={"title": "My PR", "head": "feature", "base": "main"},
        risk_level="safe",
        reason="Open a pull request.",
    )


@pytest.fixture
def simple_plan(safe_local_op: LocalOperation) -> ExecutionPlan:
    return ExecutionPlan(operations=[safe_local_op])


@pytest.fixture
def mixed_plan(safe_local_op: LocalOperation, safe_cloud_op: CloudOperation) -> ExecutionPlan:
    return ExecutionPlan(operations=[safe_local_op, safe_cloud_op])


# ---------------------------------------------------------------------------
# Mock Groq response factory
# ---------------------------------------------------------------------------


def make_groq_response(plan_dict: dict) -> dict:
    """Build a fake Groq API response wrapping a plan dict."""
    return {
        "choices": [
            {
                "message": {
                    "content": json.dumps(plan_dict),
                }
            }
        ]
    }


VALID_PLAN_DICT = {
    "operations": [
        {
            "type": "local",
            "binary": "git",
            "args": ["status"],
            "risk_level": "safe",
            "reason": "Check status.",
        }
    ]
}


@pytest.fixture
def mock_groq_success() -> dict:
    return make_groq_response(VALID_PLAN_DICT)


@pytest.fixture
def mock_groq_response_obj(mock_groq_success: dict) -> MagicMock:
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = mock_groq_success
    return resp
