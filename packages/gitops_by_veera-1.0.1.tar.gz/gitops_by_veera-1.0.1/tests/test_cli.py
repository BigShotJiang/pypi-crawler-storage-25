"""Tests for the Click CLI interface."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from gitops_by_veera.cli import cli
from gitops_by_veera.exceptions import (
    CredentialError,
    LockAcquisitionError,
    ModelCascadeExhaustedError,
    SecurityViolationError,
)
from gitops_by_veera.models import ExecutionPlan, LocalOperation, OperationResult
from tests.conftest import VALID_PLAN_DICT


FAKE_CREDS_DICT = {
    "github_token": "github_pat_faketoken1234567890abcdefghijklmnopqrstuvwxyz",
    "groq_api_key": "gsk_fakekey1234567890abcdefghijklmnopqrstuvwxyz",
}


def fake_plan() -> ExecutionPlan:
    return ExecutionPlan(
        operations=[
            LocalOperation(
                type="local",
                binary="git",
                args=["status"],
                risk_level="safe",
                reason="Test status check.",
            )
        ]
    )


def fake_success_result() -> list[OperationResult]:
    return [
        OperationResult(
            operation_index=0,
            operation_type="local",
            success=True,
            stdout="On branch main",
            returncode=0,
        )
    ]


def fake_failed_result() -> list[OperationResult]:
    return [
        OperationResult(
            operation_index=0,
            operation_type="local",
            success=False,
            stderr="fatal error",
            returncode=1,
            error_message="fatal error",
        )
    ]


# ---------------------------------------------------------------------------
# Setup command
# ---------------------------------------------------------------------------


def test_setup_saves_credentials(tmp_path: Path) -> None:
    runner = CliRunner()
    cfg_path = tmp_path / "creds.json"

    with patch("gitops_by_veera.cli.save_credentials") as mock_save:
        with patch("getpass.getpass", side_effect=["gsk_testkey123", "github_pat_testtoken123"]):
            result = runner.invoke(cli, ["setup"])

    assert result.exit_code == 0
    mock_save.assert_called_once()


def test_setup_exits_on_empty_credentials() -> None:
    runner = CliRunner()
    with patch("getpass.getpass", side_effect=["", ""]):
        result = runner.invoke(cli, ["setup"])
    assert result.exit_code != 0


# ---------------------------------------------------------------------------
# run command — credential loading
# ---------------------------------------------------------------------------


def test_run_exits_when_credentials_missing() -> None:
    runner = CliRunner()
    with patch("gitops_by_veera.cli.load_credentials", side_effect=CredentialError("no creds")):
        result = runner.invoke(cli, ["run", "git status"])
    assert result.exit_code != 0
    assert "no creds" in result.output


def test_run_exits_when_lock_unavailable() -> None:
    runner = CliRunner()
    with patch("gitops_by_veera.cli.load_credentials") as mock_load:
        mock_load.return_value = MagicMock(**FAKE_CREDS_DICT)
        with patch(
            "gitops_by_veera.cli.acquire_lock",
            side_effect=LockAcquisitionError("locked"),
        ):
            result = runner.invoke(cli, ["run", "git status"])
    assert result.exit_code != 0


# ---------------------------------------------------------------------------
# run command — dry-run
# ---------------------------------------------------------------------------


def test_run_dry_run_does_not_execute(fake_repo: Path) -> None:
    runner = CliRunner()

    with patch("gitops_by_veera.cli.load_credentials") as mock_creds:
        mock_creds.return_value = MagicMock(
            groq_api_key=FAKE_CREDS_DICT["groq_api_key"],
            github_token=FAKE_CREDS_DICT["github_token"],
        )
        with patch("gitops_by_veera.cli.acquire_lock", return_value=Path("/tmp/fake.lock")):
            with patch("gitops_by_veera.cli.release_lock"):
                with patch("gitops_by_veera.cli.find_repo_root", return_value=fake_repo):
                    with patch(
                        "gitops_by_veera.agent.GitOpsAgent.build_plan",
                        return_value=fake_plan(),
                    ):
                        with patch(
                            "gitops_by_veera.agent.GitOpsAgent.validate", return_value=[]
                        ):
                            with patch(
                                "gitops_by_veera.agent.GitOpsAgent.execute",
                                return_value=[],
                            ) as mock_exec:
                                result = runner.invoke(cli, ["run", "show status", "--dry-run"])

    assert result.exit_code == 0
    assert "DRY-RUN" in result.output


# ---------------------------------------------------------------------------
# run command — successful execution
# ---------------------------------------------------------------------------


def test_run_executes_plan_on_user_approval(fake_repo: Path) -> None:
    runner = CliRunner()

    with patch("gitops_by_veera.cli.load_credentials") as mock_creds:
        mock_creds.return_value = MagicMock(
            groq_api_key=FAKE_CREDS_DICT["groq_api_key"],
            github_token=FAKE_CREDS_DICT["github_token"],
        )
        with patch("gitops_by_veera.cli.acquire_lock", return_value=Path("/tmp/fake.lock")):
            with patch("gitops_by_veera.cli.release_lock"):
                with patch("gitops_by_veera.cli.find_repo_root", return_value=fake_repo):
                    with patch(
                        "gitops_by_veera.agent.GitOpsAgent.build_plan",
                        return_value=fake_plan(),
                    ):
                        with patch(
                            "gitops_by_veera.agent.GitOpsAgent.validate", return_value=[]
                        ):
                            with patch(
                                "gitops_by_veera.agent.GitOpsAgent.execute",
                                return_value=fake_success_result(),
                            ):
                                result = runner.invoke(
                                    cli, ["run", "show status"], input="y\n"
                                )

    assert result.exit_code == 0
    assert "completed successfully" in result.output


# ---------------------------------------------------------------------------
# run command — security violation
# ---------------------------------------------------------------------------


def test_run_exits_on_security_violation(fake_repo: Path) -> None:
    runner = CliRunner()

    with patch("gitops_by_veera.cli.load_credentials") as mock_creds:
        mock_creds.return_value = MagicMock(
            groq_api_key=FAKE_CREDS_DICT["groq_api_key"],
            github_token=FAKE_CREDS_DICT["github_token"],
        )
        with patch("gitops_by_veera.cli.acquire_lock", return_value=Path("/tmp/fake.lock")):
            with patch("gitops_by_veera.cli.release_lock"):
                with patch("gitops_by_veera.cli.find_repo_root", return_value=fake_repo):
                    with patch(
                        "gitops_by_veera.agent.GitOpsAgent.build_plan",
                        return_value=fake_plan(),
                    ):
                        with patch(
                            "gitops_by_veera.agent.GitOpsAgent.validate",
                            side_effect=SecurityViolationError("injection detected", "detail"),
                        ):
                            result = runner.invoke(cli, ["run", "bad prompt"])

    assert result.exit_code != 0
    assert "Security violation" in result.output


# ---------------------------------------------------------------------------
# run command — aborted by user
# ---------------------------------------------------------------------------


def test_run_aborts_on_user_rejection(fake_repo: Path) -> None:
    runner = CliRunner()

    with patch("gitops_by_veera.cli.load_credentials") as mock_creds:
        mock_creds.return_value = MagicMock(
            groq_api_key=FAKE_CREDS_DICT["groq_api_key"],
            github_token=FAKE_CREDS_DICT["github_token"],
        )
        with patch("gitops_by_veera.cli.acquire_lock", return_value=Path("/tmp/fake.lock")):
            with patch("gitops_by_veera.cli.release_lock"):
                with patch("gitops_by_veera.cli.find_repo_root", return_value=fake_repo):
                    with patch(
                        "gitops_by_veera.agent.GitOpsAgent.build_plan",
                        return_value=fake_plan(),
                    ):
                        with patch(
                            "gitops_by_veera.agent.GitOpsAgent.validate", return_value=[]
                        ):
                            result = runner.invoke(cli, ["run", "show status"], input="n\n")

    assert result.exit_code == 0
    assert "Aborted" in result.output


# ---------------------------------------------------------------------------
# run command — failed operation with remediation decline
# ---------------------------------------------------------------------------


def test_run_remediation_declined_stops_execution(fake_repo: Path) -> None:
    runner = CliRunner()

    with patch("gitops_by_veera.cli.load_credentials") as mock_creds:
        mock_creds.return_value = MagicMock(
            groq_api_key=FAKE_CREDS_DICT["groq_api_key"],
            github_token=FAKE_CREDS_DICT["github_token"],
        )
        with patch("gitops_by_veera.cli.acquire_lock", return_value=Path("/tmp/fake.lock")):
            with patch("gitops_by_veera.cli.release_lock"):
                with patch("gitops_by_veera.cli.find_repo_root", return_value=fake_repo):
                    with patch(
                        "gitops_by_veera.agent.GitOpsAgent.build_plan",
                        return_value=fake_plan(),
                    ):
                        with patch(
                            "gitops_by_veera.agent.GitOpsAgent.validate", return_value=[]
                        ):
                            with patch(
                                "gitops_by_veera.agent.GitOpsAgent.execute",
                                return_value=fake_failed_result(),
                            ):
                                with patch(
                                    "gitops_by_veera.agent.GitOpsAgent.remediate",
                                    return_value=fake_plan(),
                                ):
                                    result = runner.invoke(
                                        cli,
                                        ["run", "push to origin"],
                                        input="y\nn\n",
                                    )

    assert "Remediation declined" in result.output or result.exit_code != 0


# ---------------------------------------------------------------------------
# run command — debug mode shows telemetry
# ---------------------------------------------------------------------------


def test_run_debug_shows_telemetry(fake_repo: Path) -> None:
    runner = CliRunner()

    with patch("gitops_by_veera.cli.load_credentials") as mock_creds:
        mock_creds.return_value = MagicMock(
            groq_api_key=FAKE_CREDS_DICT["groq_api_key"],
            github_token=FAKE_CREDS_DICT["github_token"],
        )
        with patch("gitops_by_veera.cli.acquire_lock", return_value=Path("/tmp/fake.lock")):
            with patch("gitops_by_veera.cli.release_lock"):
                with patch("gitops_by_veera.cli.find_repo_root", return_value=fake_repo):
                    with patch(
                        "gitops_by_veera.agent.GitOpsAgent.build_plan",
                        return_value=fake_plan(),
                    ):
                        with patch(
                            "gitops_by_veera.agent.GitOpsAgent.validate", return_value=[]
                        ):
                            with patch(
                                "gitops_by_veera.agent.GitOpsAgent.execute",
                                return_value=fake_success_result(),
                            ):
                                result = runner.invoke(
                                    cli,
                                    ["run", "show status", "--debug"],
                                    input="y\n",
                                )

    assert "Session Telemetry" in result.output
