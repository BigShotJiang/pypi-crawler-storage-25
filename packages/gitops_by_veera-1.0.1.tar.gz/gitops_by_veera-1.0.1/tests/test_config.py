"""Tests for credential management, config loading, and PID lock handling."""

from __future__ import annotations

import json
import os
import stat
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from gitops_by_veera.config import (
    _apply_secure_permissions,
    _is_pid_running,
    _lock_path,
    acquire_lock,
    find_repo_root,
    load_credentials,
    release_lock,
    save_credentials,
)
from gitops_by_veera.exceptions import (
    ConfigurationError,
    CredentialError,
    LockAcquisitionError,
)
from gitops_by_veera.models import CredentialConfig, LockMetadata


# ---------------------------------------------------------------------------
# find_repo_root
# ---------------------------------------------------------------------------


def test_find_repo_root_returns_path_inside_repo(fake_repo: Path) -> None:
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout=str(fake_repo) + "\n")
        result = find_repo_root(fake_repo)
    assert result == fake_repo


def test_find_repo_root_fallback_walks_git_dir(fake_repo: Path) -> None:
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=1, stdout="")
        result = find_repo_root(fake_repo)
    assert result == fake_repo


def test_find_repo_root_returns_none_outside_repo(tmp_path: Path) -> None:
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=1, stdout="")
        result = find_repo_root(tmp_path)
    assert result is None


# ---------------------------------------------------------------------------
# load_credentials — environment variable precedence
# ---------------------------------------------------------------------------


def test_load_credentials_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GITHUB_TOKEN", "github_pat_envtoken1234567890abcdefghijklmnopqrstuvwxyz")
    monkeypatch.setenv("GROQ_API_KEY", "gsk_envgroqkey1234567890abcdefghijklmnopqrstuvwxyz")
    creds = load_credentials()
    assert creds.github_token.startswith("github_pat_")
    assert creds.groq_api_key.startswith("gsk_")


def test_load_credentials_from_config_file(
    config_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("GITHUB_TOKEN", raising=False)
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    with patch("gitops_by_veera.config.CONFIG_PATH", config_file):
        creds = load_credentials()
    assert "github_pat_" in creds.github_token


def test_load_credentials_raises_when_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("GITHUB_TOKEN", raising=False)
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    non_existent = Path("/tmp/nonexistent_gitops_config.json")
    with patch("gitops_by_veera.config.CONFIG_PATH", non_existent):
        with pytest.raises(CredentialError):
            load_credentials()


def test_load_credentials_raises_on_malformed_json(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    bad_cfg = tmp_path / "bad.json"
    bad_cfg.write_text("{invalid json}")
    monkeypatch.delenv("GITHUB_TOKEN", raising=False)
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    with patch("gitops_by_veera.config.CONFIG_PATH", bad_cfg):
        with pytest.raises(ConfigurationError):
            load_credentials()


# ---------------------------------------------------------------------------
# save_credentials
# ---------------------------------------------------------------------------


def test_save_credentials_creates_file_with_correct_content(tmp_path: Path) -> None:
    cfg_path = tmp_path / "creds.json"
    with patch("gitops_by_veera.config.CONFIG_PATH", cfg_path):
        save_credentials(
            github_token="github_pat_savedtoken1234567890abcdefghijklmnopqrstuvwxyz",
            groq_api_key="gsk_savedkey1234567890abcdefghijklmnopqrstuvwxyz",
        )
    assert cfg_path.exists()
    data = json.loads(cfg_path.read_text())
    assert "github_token" in data
    assert "groq_api_key" in data


def test_save_credentials_applies_chmod_600(tmp_path: Path) -> None:
    cfg_path = tmp_path / "creds.json"
    with patch("gitops_by_veera.config.CONFIG_PATH", cfg_path):
        save_credentials(
            github_token="github_pat_permstoken1234567890abcdefghijklmnopqrstuvwxyz",
            groq_api_key="gsk_permskey1234567890abcdefghijklmnopqrstuvwxyz",
        )
    file_mode = stat.S_IMODE(cfg_path.stat().st_mode)
    assert file_mode == 0o600


def test_save_credentials_raises_on_empty_token(tmp_path: Path) -> None:
    with pytest.raises(CredentialError):
        save_credentials(github_token="", groq_api_key="gsk_validkey")


# ---------------------------------------------------------------------------
# PID locking
# ---------------------------------------------------------------------------


def test_acquire_lock_creates_lockfile(fake_repo: Path) -> None:
    with patch("gitops_by_veera.config.find_repo_root", return_value=fake_repo):
        lock = acquire_lock()
        try:
            assert lock.exists()
            meta = LockMetadata(**json.loads(lock.read_text()))
            assert meta.pid == os.getpid()
        finally:
            release_lock(lock)


def test_acquire_lock_removes_stale_lock(fake_repo: Path) -> None:
    stale_lock = fake_repo / ".git" / ".gitops.lock"
    stale_meta = LockMetadata(pid=999999999, timestamp=0.0)
    stale_lock.write_text(stale_meta.model_dump_json())

    with patch("gitops_by_veera.config.find_repo_root", return_value=fake_repo):
        with patch("gitops_by_veera.config._is_pid_running", return_value=False):
            lock = acquire_lock()
            try:
                assert lock.exists()
            finally:
                release_lock(lock)


def test_acquire_lock_raises_if_live_process_holds_lock(fake_repo: Path) -> None:
    live_lock = fake_repo / ".git" / ".gitops.lock"
    live_meta = LockMetadata(pid=os.getpid(), timestamp=0.0)
    live_lock.write_text(live_meta.model_dump_json())

    with patch("gitops_by_veera.config.find_repo_root", return_value=fake_repo):
        with patch("gitops_by_veera.config._is_pid_running", return_value=True):
            with pytest.raises(LockAcquisitionError):
                acquire_lock()
    live_lock.unlink(missing_ok=True)


def test_release_lock_only_removes_own_lock(fake_repo: Path) -> None:
    lock_path = fake_repo / ".git" / ".gitops.lock"
    meta = LockMetadata(pid=os.getpid())
    lock_path.write_text(meta.model_dump_json())
    release_lock(lock_path)
    assert not lock_path.exists()


def test_release_lock_ignores_missing_file(tmp_path: Path) -> None:
    non_existent = tmp_path / "nope.lock"
    release_lock(non_existent)


def test_is_pid_running_current_process() -> None:
    assert _is_pid_running(os.getpid()) is True


def test_is_pid_running_dead_process() -> None:
    assert _is_pid_running(999999999) is False
