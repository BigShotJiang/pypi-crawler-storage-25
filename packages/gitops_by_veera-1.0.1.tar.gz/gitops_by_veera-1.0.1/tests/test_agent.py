"""Tests for the orchestration agent: LLM calling, cascading, direct eval, and execution."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import requests

from gitops_by_veera.agent import GitOpsAgent
from gitops_by_veera.exceptions import (
    GroqRateLimitError,
    ModelCascadeExhaustedError,
    ParseError,
    RemediationLimitError,
)
from gitops_by_veera.models import ExecutionPlan, LocalOperation, OperationResult
from tests.conftest import VALID_PLAN_DICT, make_groq_response


FAKE_GROQ_KEY = "gsk_fakekey1234567890abcdefghijklmnopqrstuvwxyz"
FAKE_GITHUB_TOKEN = "github_pat_faketoken1234567890abcdefghijklmnopqrstuvwxyz"


def make_agent(fake_repo: Path) -> GitOpsAgent:
    return GitOpsAgent(
        groq_api_key=FAKE_GROQ_KEY,
        github_token=FAKE_GITHUB_TOKEN,
        repo_root=fake_repo,
    )


# ---------------------------------------------------------------------------
# Direct evaluation bypass
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "prompt",
    [
        "git status",
        "status",
        "show status",
        "git diff",
        "show diff",
        "diff",
        "git log",
        "view history",
        "log",
    ],
)
def test_direct_eval_bypasses_llm(fake_repo: Path, prompt: str) -> None:
    agent = make_agent(fake_repo)
    with patch("requests.post") as mock_post:
        plan = agent.build_plan(prompt)
        mock_post.assert_not_called()
    assert len(plan.operations) == 1
    op = plan.operations[0]
    assert op.type == "local"


def test_direct_eval_status_uses_status_args(fake_repo: Path) -> None:
    agent = make_agent(fake_repo)
    plan = agent.build_plan("git status")
    op = plan.operations[0]
    assert op.binary == "git"  # type: ignore[union-attr]
    assert op.args[0] == "status"  # type: ignore[union-attr]


def test_direct_eval_diff_uses_diff_args(fake_repo: Path) -> None:
    agent = make_agent(fake_repo)
    plan = agent.build_plan("git diff")
    op = plan.operations[0]
    assert op.args[0] == "diff"  # type: ignore[union-attr]


def test_direct_eval_log_uses_log_args(fake_repo: Path) -> None:
    agent = make_agent(fake_repo)
    plan = agent.build_plan("view history")
    op = plan.operations[0]
    assert op.args[0] == "log"  # type: ignore[union-attr]


# ---------------------------------------------------------------------------
# Prompt caching
# ---------------------------------------------------------------------------


def test_prompt_cache_prevents_duplicate_llm_calls(
    fake_repo: Path, mock_groq_response_obj: MagicMock
) -> None:
    agent = make_agent(fake_repo)
    with patch("requests.post", return_value=mock_groq_response_obj) as mock_post:
        agent.build_plan("commit my staged changes")
        agent.build_plan("commit my staged changes")
        assert mock_post.call_count == 1


# ---------------------------------------------------------------------------
# LLM cascade — success path
# ---------------------------------------------------------------------------


def test_build_plan_calls_groq_and_returns_plan(
    fake_repo: Path, mock_groq_response_obj: MagicMock
) -> None:
    agent = make_agent(fake_repo)
    with patch("requests.post", return_value=mock_groq_response_obj):
        plan = agent.build_plan("commit my staged changes")
    assert isinstance(plan, ExecutionPlan)
    assert len(plan.operations) >= 1


# ---------------------------------------------------------------------------
# LLM cascade — retry and fallback
# ---------------------------------------------------------------------------


def test_groq_429_triggers_retry_then_success(
    fake_repo: Path, mock_groq_response_obj: MagicMock
) -> None:
    rate_limited = MagicMock()
    rate_limited.status_code = 429

    agent = make_agent(fake_repo)
    with patch("requests.post", side_effect=[rate_limited, rate_limited, mock_groq_response_obj]):
        with patch("time.sleep"):
            plan = agent.build_plan("push current branch")
    assert isinstance(plan, ExecutionPlan)


def test_groq_all_retries_exhausted_cascades_to_next_model(fake_repo: Path) -> None:
    rate_limited = MagicMock()
    rate_limited.status_code = 429

    success = MagicMock()
    success.status_code = 200
    success.json.return_value = make_groq_response(VALID_PLAN_DICT)

    agent = make_agent(fake_repo)
    with patch("requests.post", side_effect=[rate_limited, rate_limited, rate_limited, success]):
        with patch("time.sleep"):
            plan = agent.build_plan("push current branch")
    assert isinstance(plan, ExecutionPlan)
    assert agent.metrics.model_fallback_transmutation_events >= 1


def test_all_model_tiers_exhausted_raises(fake_repo: Path) -> None:
    rate_limited = MagicMock()
    rate_limited.status_code = 429

    agent = make_agent(fake_repo)
    with patch("requests.post", return_value=rate_limited):
        with patch("time.sleep"):
            with pytest.raises(ModelCascadeExhaustedError):
                agent.build_plan("push current branch")


# ---------------------------------------------------------------------------
# Parse failures → cascade
# ---------------------------------------------------------------------------


def test_malformed_json_triggers_cascade(
    fake_repo: Path, mock_groq_response_obj: MagicMock
) -> None:
    bad_resp = MagicMock()
    bad_resp.status_code = 200
    bad_resp.json.return_value = {
        "choices": [{"message": {"content": "not json at all {{"}}]
    }

    agent = make_agent(fake_repo)
    with patch("requests.post", side_effect=[bad_resp, mock_groq_response_obj]):
        plan = agent.build_plan("make a commit")
    assert isinstance(plan, ExecutionPlan)
    assert agent.metrics.model_fallback_transmutation_events >= 1


def test_pydantic_mismatch_triggers_cascade(
    fake_repo: Path, mock_groq_response_obj: MagicMock
) -> None:
    wrong_schema = MagicMock()
    wrong_schema.status_code = 200
    wrong_schema.json.return_value = {
        "choices": [{"message": {"content": json.dumps({"wrong_key": []})}}]
    }

    agent = make_agent(fake_repo)
    with patch("requests.post", side_effect=[wrong_schema, mock_groq_response_obj]):
        plan = agent.build_plan("make a commit")
    assert isinstance(plan, ExecutionPlan)


# ---------------------------------------------------------------------------
# Local execution
# ---------------------------------------------------------------------------


def test_execute_local_success(fake_repo: Path, simple_plan: ExecutionPlan) -> None:
    agent = make_agent(fake_repo)
    mock_proc = MagicMock()
    mock_proc.returncode = 0
    mock_proc.stdout = "On branch main\n"
    mock_proc.stderr = ""

    with patch("subprocess.run", return_value=mock_proc):
        results = agent.execute(simple_plan)

    assert len(results) == 1
    assert results[0].success is True
    assert agent.metrics.successful_operations_count == 1


def test_execute_local_failure_recorded(fake_repo: Path, simple_plan: ExecutionPlan) -> None:
    agent = make_agent(fake_repo)
    mock_proc = MagicMock()
    mock_proc.returncode = 1
    mock_proc.stdout = ""
    mock_proc.stderr = "fatal: not a git repo"

    with patch("subprocess.run", return_value=mock_proc):
        results = agent.execute(simple_plan)

    assert results[0].success is False
    assert agent.metrics.failed_operations_count == 1


def test_execute_dry_run_skips_subprocess(
    fake_repo: Path, simple_plan: ExecutionPlan
) -> None:
    agent = make_agent(fake_repo)
    with patch("subprocess.run") as mock_run:
        agent.execute(simple_plan, dry_run=True)
        mock_run.assert_not_called()


def test_execute_local_timeout_returns_failure(fake_repo: Path, simple_plan: ExecutionPlan) -> None:
    agent = make_agent(fake_repo)
    with patch("subprocess.run", side_effect=subprocess.TimeoutExpired(cmd="git", timeout=60)):
        results = agent.execute(simple_plan)
    assert results[0].success is False
    assert "timed out" in results[0].error_message.lower()


# ---------------------------------------------------------------------------
# Cloud execution
# ---------------------------------------------------------------------------


def test_execute_cloud_success(fake_repo: Path, mixed_plan: ExecutionPlan) -> None:
    agent = make_agent(fake_repo)

    local_proc = MagicMock()
    local_proc.returncode = 0
    local_proc.stdout = "On branch main"
    local_proc.stderr = ""

    cloud_resp = MagicMock()
    cloud_resp.status_code = 201
    cloud_resp.json.return_value = {"number": 42, "html_url": "https://github.com/o/r/pull/42"}

    with patch("subprocess.run", return_value=local_proc):
        with patch("requests.request", return_value=cloud_resp):
            results = agent.execute(mixed_plan)

    assert results[1].success is True
    assert results[1].status_code == 201


def test_execute_cloud_rate_limit_retries(fake_repo: Path, mixed_plan: ExecutionPlan) -> None:
    agent = make_agent(fake_repo)

    local_proc = MagicMock()
    local_proc.returncode = 0
    local_proc.stdout = ""
    local_proc.stderr = ""

    rate_resp = MagicMock()
    rate_resp.status_code = 429
    rate_resp.headers = {"X-RateLimit-Remaining": "5"}

    success_resp = MagicMock()
    success_resp.status_code = 200
    success_resp.json.return_value = {}

    with patch("subprocess.run", return_value=local_proc):
        with patch("requests.request", side_effect=[rate_resp, rate_resp, success_resp]):
            with patch("time.sleep"):
                results = agent.execute(mixed_plan)

    assert results[1].success is True


# ---------------------------------------------------------------------------
# Remediation
# ---------------------------------------------------------------------------


def test_remediate_calls_tier3_model(fake_repo: Path, mock_groq_response_obj: MagicMock) -> None:
    agent = make_agent(fake_repo)
    failed = OperationResult(
        operation_index=0,
        operation_type="local",
        success=False,
        stderr="Push rejected: non-fast-forward",
        returncode=1,
        error_message="Push rejected.",
    )
    with patch("requests.post", return_value=mock_groq_response_obj):
        plan = agent.remediate(failed)
    assert isinstance(plan, ExecutionPlan)
    assert agent.metrics.remediation_loop_attempts == 1


# ---------------------------------------------------------------------------
# Session metrics
# ---------------------------------------------------------------------------


def test_metrics_accumulate_correctly(fake_repo: Path, simple_plan: ExecutionPlan) -> None:
    agent = make_agent(fake_repo)
    mock_proc = MagicMock()
    mock_proc.returncode = 0
    mock_proc.stdout = ""
    mock_proc.stderr = ""

    with patch("subprocess.run", return_value=mock_proc):
        agent.execute(simple_plan)

    assert agent.metrics.total_commands_executed == 1
    assert agent.metrics.successful_operations_count == 1
    assert agent.metrics.failed_operations_count == 0


def test_metrics_summary_lines_have_correct_format(fake_repo: Path) -> None:
    agent = make_agent(fake_repo)
    agent.metrics.record_llm_call("test-model")
    agent.metrics.finalize()
    lines = agent.metrics.summary_lines()
    assert any("Session Telemetry" in line for line in lines)
    assert any("Total commands" in line for line in lines)
