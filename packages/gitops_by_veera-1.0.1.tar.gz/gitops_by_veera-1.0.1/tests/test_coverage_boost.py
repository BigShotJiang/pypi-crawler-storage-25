"""Additional tests to boost coverage for agent.py, cli.py, config.py, and logger.py."""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import requests
from click.testing import CliRunner

from gitops_by_veera.agent import GitOpsAgent
from gitops_by_veera.cli import cli
from gitops_by_veera.config import find_repo_root, require_repo_root, save_credentials
from gitops_by_veera.exceptions import (
    GroqAPIError,
    GroqTimeoutError,
    ModelCascadeExhaustedError,
    RepositoryNotFoundError,
)
from gitops_by_veera.logger import enable_debug, get_logger, register_secret
from gitops_by_veera.models import ExecutionPlan, LocalOperation, CloudOperation, SessionMetrics
from tests.conftest import VALID_PLAN_DICT, make_groq_response


FAKE_GROQ_KEY = "gsk_fakekey1234567890abcdefghijklmnopqrstuvwxyz"
FAKE_GITHUB_TOKEN = "github_pat_faketoken1234567890abcdefghijklmnopqrstuvwxyz"


def make_agent(fake_repo: Path) -> GitOpsAgent:
    return GitOpsAgent(
        groq_api_key=FAKE_GROQ_KEY,
        github_token=FAKE_GITHUB_TOKEN,
        repo_root=fake_repo,
    )


# ---------------------------------------------------------------------------
# logger.py additional coverage
# ---------------------------------------------------------------------------


def test_register_secret_and_redaction() -> None:
    register_secret("super_secret_value_12345")
    logger = get_logger("test_redact")
    with patch.object(logger, "info") as mock_info:
        logger.info("token is super_secret_value_12345")
    mock_info.assert_called_once()


def test_enable_debug_switches_level() -> None:
    logger = get_logger("test_debug_switch")
    enable_debug(logger)
    assert logger.level == logging.DEBUG


def test_get_logger_returns_same_instance() -> None:
    a = get_logger("shared_logger")
    b = get_logger("shared_logger")
    assert a is b


def test_secret_redaction_filter_scrubs_token() -> None:
    from gitops_by_veera.logger import SecretRedactionFilter
    import logging

    filt = SecretRedactionFilter(extra_secrets=["mysecret"])
    record = logging.LogRecord(
        name="test", level=logging.INFO, pathname="", lineno=0,
        msg="header: mysecret", args=None, exc_info=None
    )
    filt.filter(record)
    assert "mysecret" not in record.msg
    assert "[REDACTED]" in record.msg


def test_secret_redaction_filter_handles_dict_args() -> None:
    from gitops_by_veera.logger import SecretRedactionFilter
    import logging

    filt = SecretRedactionFilter(extra_secrets=["topsecret"])
    record = logging.LogRecord(
        name="test", level=logging.INFO, pathname="", lineno=0,
        msg="value: %(k)s %(j)s", args={"k": "topsecret", "j": "other"}, exc_info=None
    )
    filt.filter(record)
    assert "topsecret" not in str(record.args)


def test_secret_redaction_filter_handles_tuple_args() -> None:
    from gitops_by_veera.logger import SecretRedactionFilter
    import logging

    filt = SecretRedactionFilter(extra_secrets=["hideme"])
    record = logging.LogRecord(
        name="test", level=logging.INFO, pathname="", lineno=0,
        msg="val: %s", args=("hideme_value",), exc_info=None
    )
    filt.filter(record)
    assert "hideme" not in str(record.args)


# ---------------------------------------------------------------------------
# config.py additional coverage
# ---------------------------------------------------------------------------


def test_require_repo_root_raises_when_no_repo(tmp_path: Path) -> None:
    with patch("gitops_by_veera.config.find_repo_root", return_value=None):
        with pytest.raises(RepositoryNotFoundError):
            require_repo_root()


def test_require_repo_root_returns_path(fake_repo: Path) -> None:
    with patch("gitops_by_veera.config.find_repo_root", return_value=fake_repo):
        result = require_repo_root()
    assert result == fake_repo


def test_find_repo_root_subprocess_timeout(tmp_path: Path) -> None:
    import subprocess as sp
    with patch("subprocess.run", side_effect=sp.TimeoutExpired(cmd="git", timeout=10)):
        result = find_repo_root(tmp_path)
    assert result is None or isinstance(result, Path)


def test_save_credentials_raises_on_empty_groq_key(tmp_path: Path) -> None:
    from gitops_by_veera.exceptions import CredentialError
    with pytest.raises(CredentialError):
        save_credentials(github_token="github_pat_valid123456789012345678901234567890123456", groq_api_key="")


# ---------------------------------------------------------------------------
# models.py — SessionMetrics helpers
# ---------------------------------------------------------------------------


def test_session_metrics_record_methods() -> None:
    m = SessionMetrics()
    m.record_success()
    m.record_failure()
    m.record_llm_call("test-model")
    m.record_fallback()
    m.record_remediation()
    m.finalize()

    assert m.total_commands_executed == 2
    assert m.successful_operations_count == 1
    assert m.failed_operations_count == 1
    assert m.total_llm_calls == 1
    assert m.model_fallback_transmutation_events == 1
    assert m.remediation_loop_attempts == 1
    assert m.total_execution_duration_seconds >= 0
    assert m.active_model == "test-model"


def test_session_metrics_summary_lines_count() -> None:
    m = SessionMetrics()
    m.finalize()
    lines = m.summary_lines()
    assert len(lines) == 12


# ---------------------------------------------------------------------------
# agent.py — additional branch coverage
# ---------------------------------------------------------------------------


def test_groq_network_error_raises_groq_api_error(fake_repo: Path) -> None:
    agent = make_agent(fake_repo)
    with patch("requests.post", side_effect=requests.RequestException("network down")):
        with pytest.raises((GroqAPIError, ModelCascadeExhaustedError)):
            agent.build_plan("commit everything")


def test_groq_timeout_triggers_retry_and_eventually_raises(fake_repo: Path) -> None:
    agent = make_agent(fake_repo)
    with patch("requests.post", side_effect=requests.Timeout()):
        with patch("time.sleep"):
            with pytest.raises((GroqTimeoutError, ModelCascadeExhaustedError)):
                agent.build_plan("commit everything")


def test_groq_502_retries_and_cascades(fake_repo: Path, mock_groq_response_obj: MagicMock) -> None:
    bad = MagicMock()
    bad.status_code = 502

    agent = make_agent(fake_repo)
    with patch("requests.post", side_effect=[bad, bad, bad, mock_groq_response_obj]):
        with patch("time.sleep"):
            plan = agent.build_plan("do a commit")
    assert isinstance(plan, ExecutionPlan)


def test_groq_unexpected_status_raises(fake_repo: Path) -> None:
    bad = MagicMock()
    bad.status_code = 500
    bad.text = "Internal Server Error"

    agent = make_agent(fake_repo)
    with patch("requests.post", return_value=bad):
        with pytest.raises((GroqAPIError, ModelCascadeExhaustedError)):
            agent.build_plan("do something")


def test_build_plan_with_dict_groq_response(fake_repo: Path) -> None:
    agent = make_agent(fake_repo)
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.json.return_value = {
        "choices": [{"message": {"content": VALID_PLAN_DICT}}]
    }
    with patch("requests.post", return_value=mock_resp):
        plan = agent.build_plan("make a commit now")
    assert isinstance(plan, ExecutionPlan)


def test_execute_cloud_all_rate_limits_exhausted(fake_repo: Path) -> None:
    cloud_op = CloudOperation(
        type="cloud",
        endpoint="/repos/owner/repo/pulls",
        method="POST",
        payload={"title": "PR", "head": "feat", "base": "main"},
        risk_level="safe",
        reason="ok",
    )
    plan = ExecutionPlan(operations=[cloud_op])
    agent = make_agent(fake_repo)

    rate_resp = MagicMock()
    rate_resp.status_code = 429
    rate_resp.headers = {"X-RateLimit-Remaining": "5"}

    with patch("requests.request", return_value=rate_resp):
        with patch("time.sleep"):
            results = agent.execute(plan)

    assert results[0].success is False
    assert "rate limit" in results[0].error_message.lower()


def test_execute_cloud_rate_limit_with_reset_header(fake_repo: Path) -> None:
    import time as _time
    cloud_op = CloudOperation(
        type="cloud",
        endpoint="/repos/owner/repo/git/refs",
        method="GET",
        payload={},
        risk_level="safe",
        reason="ok",
    )
    plan = ExecutionPlan(operations=[cloud_op])
    agent = make_agent(fake_repo)

    rate_resp = MagicMock()
    rate_resp.status_code = 429
    rate_resp.headers = {
        "X-RateLimit-Remaining": "0",
        "X-RateLimit-Reset": str(int(_time.time()) + 1),
    }
    success_resp = MagicMock()
    success_resp.status_code = 200
    success_resp.json.return_value = []

    with patch("requests.request", side_effect=[rate_resp, success_resp]):
        with patch("time.sleep"):
            results = agent.execute(plan)

    assert results[0].success is True


def test_execute_cloud_network_exception(fake_repo: Path) -> None:
    cloud_op = CloudOperation(
        type="cloud",
        endpoint="/user/repos",
        method="GET",
        payload={},
        risk_level="safe",
        reason="ok",
    )
    plan = ExecutionPlan(operations=[cloud_op])
    agent = make_agent(fake_repo)

    with patch("requests.request", side_effect=requests.Timeout()):
        results = agent.execute(plan)

    assert results[0].success is False
    assert "timed out" in results[0].error_message.lower()


def test_execute_cloud_request_exception(fake_repo: Path) -> None:
    cloud_op = CloudOperation(
        type="cloud",
        endpoint="/user/repos",
        method="GET",
        payload={},
        risk_level="safe",
        reason="ok",
    )
    plan = ExecutionPlan(operations=[cloud_op])
    agent = make_agent(fake_repo)

    with patch("requests.request", side_effect=requests.RequestException("dns error")):
        results = agent.execute(plan)

    assert results[0].success is False


def test_execute_local_file_not_found(fake_repo: Path) -> None:
    op = LocalOperation(
        type="local", binary="ls", args=["/nonexistent"], risk_level="safe", reason="test"
    )
    plan = ExecutionPlan(operations=[op])
    agent = make_agent(fake_repo)
    with patch("subprocess.run", side_effect=FileNotFoundError("not found")):
        results = agent.execute(plan)
    assert results[0].success is False


def test_agent_uses_cwd_when_no_repo_found() -> None:
    with patch("gitops_by_veera.agent.find_repo_root", return_value=None):
        agent = GitOpsAgent(
            groq_api_key=FAKE_GROQ_KEY,
            github_token=FAKE_GITHUB_TOKEN,
        )
    assert agent._repo_root == Path.cwd()


def test_plan_cache_clears_different_prompts(
    fake_repo: Path, mock_groq_response_obj: MagicMock
) -> None:
    agent = make_agent(fake_repo)
    with patch("requests.post", return_value=mock_groq_response_obj) as mock_post:
        agent.build_plan("first unique prompt abc123")
        agent.build_plan("second unique prompt xyz456")
        assert mock_post.call_count == 2


# ---------------------------------------------------------------------------
# exceptions.py branch coverage
# ---------------------------------------------------------------------------


def test_execution_error_attributes() -> None:
    from gitops_by_veera.exceptions import ExecutionError
    exc = ExecutionError("msg", stderr="err output", returncode=2)
    assert exc.stderr == "err output"
    assert exc.returncode == 2


def test_groq_api_error_status_code() -> None:
    from gitops_by_veera.exceptions import GroqAPIError
    exc = GroqAPIError("failed", status_code=503)
    assert exc.status_code == 503


def test_github_api_error_status_code() -> None:
    from gitops_by_veera.exceptions import GitHubAPIError
    exc = GitHubAPIError("gh failed", status_code=404)
    assert exc.status_code == 404


def test_security_violation_error_detail() -> None:
    from gitops_by_veera.exceptions import SecurityViolationError
    exc = SecurityViolationError("blocked", detail="extra context")
    assert exc.detail == "extra context"


# ---------------------------------------------------------------------------
# cli.py edge cases
# ---------------------------------------------------------------------------


def test_run_model_cascade_exhausted(fake_repo: Path) -> None:
    runner = CliRunner()

    with patch("gitops_by_veera.cli.load_credentials") as mock_creds:
        mock_creds.return_value = MagicMock(
            groq_api_key=FAKE_GROQ_KEY, github_token=FAKE_GITHUB_TOKEN
        )
        with patch("gitops_by_veera.cli.acquire_lock", return_value=Path("/tmp/fake.lock")):
            with patch("gitops_by_veera.cli.release_lock"):
                with patch("gitops_by_veera.cli.find_repo_root", return_value=fake_repo):
                    with patch(
                        "gitops_by_veera.agent.GitOpsAgent.build_plan",
                        side_effect=ModelCascadeExhaustedError("all tiers failed"),
                    ):
                        result = runner.invoke(cli, ["run", "push everything"])

    assert result.exit_code != 0


def test_run_with_warning_operation_confirmed(fake_repo: Path) -> None:
    runner = CliRunner()
    from gitops_by_veera.models import OperationResult

    warn_plan = ExecutionPlan(
        operations=[
            LocalOperation(
                type="local",
                binary="git",
                args=["reset", "--hard"],
                risk_level="warning",
                reason="Reset the working tree.",
            )
        ]
    )

    with patch("gitops_by_veera.cli.load_credentials") as mock_creds:
        mock_creds.return_value = MagicMock(
            groq_api_key=FAKE_GROQ_KEY, github_token=FAKE_GITHUB_TOKEN
        )
        with patch("gitops_by_veera.cli.acquire_lock", return_value=Path("/tmp/fake.lock")):
            with patch("gitops_by_veera.cli.release_lock"):
                with patch("gitops_by_veera.cli.find_repo_root", return_value=fake_repo):
                    with patch(
                        "gitops_by_veera.agent.GitOpsAgent.build_plan",
                        return_value=warn_plan,
                    ):
                        with patch(
                            "gitops_by_veera.agent.GitOpsAgent.validate",
                            return_value=["reset --hard is risky"],
                        ):
                            with patch(
                                "gitops_by_veera.agent.GitOpsAgent.execute",
                                return_value=[
                                    OperationResult(
                                        operation_index=0,
                                        operation_type="local",
                                        success=True,
                                        stdout="HEAD is now at abc",
                                        returncode=0,
                                    )
                                ],
                            ):
                                result = runner.invoke(
                                    cli, ["run", "reset hard"], input="y\ny\n"
                                )

    assert result.exit_code == 0
