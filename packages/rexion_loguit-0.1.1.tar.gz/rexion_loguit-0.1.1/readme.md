# Loguit

Loguit is a Python-first, code-first runtime for building agents without LangChain's abstraction bloat. It's designed for complicated, out-there products where hidden layers get in the way.

Core principles:
- Explicit model and tool calls
- Framework-owned run state
- Run-level and step-level middleware
- Bounded state growth via pruning
- Basic structured logging

## Quickstart

```python
from loguit import Agent, init_model, tool


@tool
def add(a: int, b: int) -> int:
    return a + b


model = init_model("openai:o3-mini")
agent = Agent(model, tools=[add])

result = agent.invoke("Use add to sum 2 and 3, then answer.")
print(result.content)
```

`agent.invoke(...)` runs a single prompt through the full model→tool→model loop.
`agent.repl(...)` launches an interactive REPL (type `exit` or `quit` to leave).
Use `tool_execution="parallel"` when you want tool calls from a single model step to execute concurrently.
Use `agent.as_tool(...)` to wrap a sub-agent as a normal tool.

## Middleware (Run + Step)

```python
from time import time

from loguit import BaseRunMiddleware, BaseStepMiddleware


class RunLogger(BaseRunMiddleware):
    def before_run(self, context, state):  # noqa: ANN001
        print("run start", context.run_id)


class StepTimer(BaseStepMiddleware):
    def before_step(self, context, state, step):  # noqa: ANN001
        step._started_at = time()
    def after_step(self, context, state, step, result):  # noqa: ANN001
        print(step.step_type, time() - step._started_at)
```

## Examples

See `examples/` for organized demos:
- `examples/agents/`
- `examples/coding/`
- `examples/models/`
- `examples/mcp/`
- `examples/observability/`
- `examples/tools/`

## Anti-goals

Loguit is intentionally narrow in V1:
- No LangChain API compatibility
- No graph DSLs or chain abstractions
- No RAG or vector store framework
- No durable state persistence
- No multi-agent orchestration

## Why Loguit?

Because you should be able to build complex products without being chained to bloatware.
