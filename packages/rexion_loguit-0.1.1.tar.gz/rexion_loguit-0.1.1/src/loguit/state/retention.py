from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from loguit.state.run_state import RunState, ToolCallRecord


@dataclass(frozen=True)
class ToolCallPruningPolicy:
    keep_latest_tool_calls: int = 3
    max_pruned_output_chars: int = 200
    max_pruned_error_chars: int = 200


def prune_tool_call_history(state: RunState, policy: ToolCallPruningPolicy) -> None:
    if policy.keep_latest_tool_calls <= 0:
        tool_calls_to_prune = list(state.tool_calls)
    else:
        tool_calls_to_prune = state.tool_calls[:-policy.keep_latest_tool_calls]

    pruned_count = 0
    for tool_call_record in tool_calls_to_prune:
        if _prune_tool_call_record(tool_call_record, policy):
            pruned_count += 1

    if pruned_count:
        state.record_event(
            "tool_call_history_pruned",
            pruned_count=pruned_count,
            kept_latest_tool_calls=policy.keep_latest_tool_calls,
        )


def _prune_tool_call_record(tool_call_record: ToolCallRecord, policy: ToolCallPruningPolicy) -> bool:
    was_pruned = False
    if tool_call_record.output is not None:
        tool_call_record.output_summary = _summarize_text(
            tool_call_record.output,
            policy.max_pruned_output_chars,
        )
        tool_call_record.output = None
        was_pruned = True
    if tool_call_record.error is not None:
        tool_call_record.error_summary = _summarize_text(
            tool_call_record.error,
            policy.max_pruned_error_chars,
        )
        tool_call_record.error = None
        was_pruned = True
    if was_pruned:
        tool_call_record.pruned = True
    return was_pruned


def _summarize_text(text: str, max_summary_chars: int) -> Optional[str]:
    if max_summary_chars <= 0:
        return None
    if len(text) <= max_summary_chars:
        return text
    if max_summary_chars <= 3:
        return "..."[:max_summary_chars]
    return text[: max_summary_chars - 3] + "..."
