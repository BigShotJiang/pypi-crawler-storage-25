from __future__ import annotations

from dataclasses import dataclass, field
from time import time
from typing import Any, Dict, List, Optional
from uuid import uuid4

from loguit.core_types import Message
from loguit.logging.schema import EVENT_SCHEMA_VERSION, validate_event


@dataclass
class ExecutionEvent:
    type: str
    timestamp: float
    run_id: str = ""
    trace_id: str = ""
    correlation_id: Optional[str] = None
    project_id: Optional[str] = None
    tenant_id: Optional[str] = None
    step_id: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)
    schema_version: str = EVENT_SCHEMA_VERSION


@dataclass
class StepRecord:
    step_id: str
    step_type: str
    name: str
    status: str
    started_at: float
    ended_at: Optional[float] = None
    error: Optional[str] = None
    message_index: Optional[int] = None


@dataclass
class ToolCallRecord:
    step_id: str
    tool_name: str
    call_id: Optional[str]
    args: Dict[str, Any]
    output: Optional[str] = None
    error: Optional[str] = None
    output_summary: Optional[str] = None
    error_summary: Optional[str] = None
    pruned: bool = False


@dataclass
class ErrorRecord:
    error_type: str
    message: str
    step_id: Optional[str] = None
    tool_name: Optional[str] = None


@dataclass(frozen=True)
class CheckpointRecord:
    step_id: str
    step_type: str
    name: str
    message_index: Optional[int] = None
    reason: str = "step_completed"


@dataclass
class RunState:
    run_id: str
    trace_id: Optional[str] = None
    correlation_id: Optional[str] = None
    project_id: Optional[str] = None
    tenant_id: Optional[str] = None
    messages: List[Message] = field(default_factory=list)
    steps: List[StepRecord] = field(default_factory=list)
    tool_calls: List[ToolCallRecord] = field(default_factory=list)
    errors: List[ErrorRecord] = field(default_factory=list)
    events: List[ExecutionEvent] = field(default_factory=list)
    termination: Optional[str] = None
    checkpoint: Optional[CheckpointRecord] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.trace_id is None:
            self.trace_id = self.run_id

    def record_event(
        self,
        event_type: str,
        *,
        step_id: Optional[str] = None,
        **details: Any,
    ) -> ExecutionEvent:
        validate_event(event_type, details, step_id)
        execution_event = ExecutionEvent(
            type=event_type,
            timestamp=time(),
            run_id=self.run_id,
            trace_id=self.trace_id or self.run_id,
            correlation_id=self.correlation_id,
            project_id=self.project_id,
            tenant_id=self.tenant_id,
            step_id=step_id,
            details=dict(details),
        )
        self.events.append(execution_event)
        return execution_event

    def start_step(self, step_type: str, name: str, *, message_index: Optional[int] = None) -> StepRecord:
        record = StepRecord(
            step_id=str(uuid4()),
            step_type=step_type,
            name=name,
            status="started",
            started_at=time(),
            message_index=message_index,
        )
        self.steps.append(record)
        return record

    def end_step(self, record: StepRecord, *, status: str = "completed", error: Optional[str] = None) -> None:
        record.status = status
        record.ended_at = time()
        record.error = error

    def set_checkpoint(self, record: StepRecord, *, reason: str = "step_completed") -> CheckpointRecord:
        checkpoint_record = CheckpointRecord(
            step_id=record.step_id,
            step_type=record.step_type,
            name=record.name,
            message_index=record.message_index,
            reason=reason,
        )
        self.checkpoint = checkpoint_record
        return checkpoint_record
