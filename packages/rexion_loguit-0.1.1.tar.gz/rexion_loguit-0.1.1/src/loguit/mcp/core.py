from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Mapping, Protocol

from ..core_types import RunContext, ToolResult
from ..tools import Tool, ToolSpec


class MCPClient(Protocol):
    def list_tools(self) -> Iterable[Dict[str, Any]]: ...

    def call_tool(self, name: str, arguments: Dict[str, Any]) -> Any: ...


@dataclass(frozen=True)
class MCPToolOverride:
    name: str | None = None
    description: str | None = None
    args_schema: Dict[str, Any] | None = None


class MCPTool(Tool):
    def __init__(self, client: MCPClient, *, server_name: str, spec: ToolSpec) -> None:
        self._client = client
        self._server_name = server_name
        self.spec = spec

    def invoke(self, args: Dict[str, Any] | str | None, context: RunContext) -> ToolResult:
        _ = context
        payload = args if isinstance(args, dict) else {}
        try:
            result = self._client.call_tool(self._server_name, payload)
        except Exception as exc:  # noqa: BLE001
            return ToolResult(output=None, error=str(exc), raw=exc)
        return _normalize_mcp_result(result)


def _normalize_mcp_result(result: Any) -> ToolResult:
    if isinstance(result, dict):
        is_error = result.get("is_error") or result.get("isError")
        if is_error:
            error_message_text = result.get("error") or result.get("message") or str(result)
            return ToolResult(output=None, error=str(error_message_text), raw=result)
        if "content" in result:
            return ToolResult(output=result["content"], raw=result)
    return ToolResult(output=result, raw=result)


def _normalize_mcp_schema(schema: Any) -> Dict[str, Any]:
    if not isinstance(schema, dict):
        return {"type": "object", "properties": {}}
    if "type" not in schema:
        normalized = dict(schema)
        normalized.setdefault("properties", {})
        normalized["type"] = "object"
        return normalized
    return schema


def tools_from_mcp(
    client: MCPClient,
    *,
    overrides: Mapping[str, MCPToolOverride | Mapping[str, Any]] | None = None,
) -> list[Tool]:
    mcp_tools: list[Tool] = []
    for listed_tool_definition in client.list_tools():
        if not isinstance(listed_tool_definition, dict):
            continue
        tool_name = listed_tool_definition.get("name")
        if not isinstance(tool_name, str) or not tool_name:
            continue
        tool_description = listed_tool_definition.get("description") or ""
        tool_argument_schema = listed_tool_definition.get("inputSchema") or listed_tool_definition.get("parameters") or {}
        tool_override = overrides.get(tool_name) if overrides else None
        if tool_override is not None:
            if isinstance(tool_override, MCPToolOverride):
                tool_override = {
                    "name": tool_override.name,
                    "description": tool_override.description,
                    "args_schema": tool_override.args_schema,
                }
            if tool_override.get("name"):
                tool_name = tool_override["name"]
            if tool_override.get("description") is not None:
                tool_description = tool_override["description"]
            if tool_override.get("args_schema") is not None:
                tool_argument_schema = tool_override["args_schema"]
        tool_spec = ToolSpec(
            name=tool_name,
            description=tool_description,
            args_schema=_normalize_mcp_schema(tool_argument_schema),
        )
        mcp_tools.append(MCPTool(client, server_name=listed_tool_definition["name"], spec=tool_spec))
    return mcp_tools


__all__ = ["MCPClient", "MCPToolOverride", "MCPTool", "tools_from_mcp"]
