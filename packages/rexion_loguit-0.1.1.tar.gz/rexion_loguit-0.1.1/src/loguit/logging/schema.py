from __future__ import annotations

from typing import Mapping

EVENT_SCHEMA_VERSION = "v2"

CANONICAL_EVENT_TYPES = frozenset(
    {
        "run_started",
        "run_completed",
        "run_checkpointed",
        "run_resumed",
        "run_terminated",
        "policy_check_blocked",
        "retry_scheduled",
        "retry_succeeded",
        "retry_exhausted",
        "model_call_started",
        "model_call_succeeded",
        "model_call_failed",
        "tool_call_started",
        "tool_call_succeeded",
        "tool_call_failed",
        "tool_call_history_pruned",
        "human_in_the_loop_requested",
        "human_in_the_loop_decided",
        "compacted",
    }
)

REQUIRED_EVENT_DETAILS: dict[str, tuple[str, ...]] = {
    "run_started": ("started_at",),
    "run_completed": ("started_at", "ended_at", "duration_ms", "completed_step_count"),
    "run_checkpointed": ("reason", "step_type", "name", "checkpointed_at"),
    "run_resumed": ("resume_step_id", "resumed_at"),
    "run_terminated": ("reason",),
    "policy_check_blocked": ("policy_name", "scope", "reason"),
    "retry_scheduled": ("attempt_number", "max_attempts", "delay_seconds", "error"),
    "retry_succeeded": ("attempt_number", "max_attempts", "retries_used"),
    "retry_exhausted": ("attempt_number", "max_attempts", "error"),
    "model_call_started": ("model", "step_type", "name", "status", "started_at"),
    "model_call_succeeded": ("model", "step_type", "name", "status", "started_at", "ended_at", "duration_ms"),
    "model_call_failed": ("model", "error", "step_type", "name", "status", "started_at", "ended_at", "duration_ms"),
    "tool_call_started": ("tool", "step_type", "name", "status", "started_at"),
    "tool_call_succeeded": ("tool", "step_type", "name", "status", "started_at", "ended_at", "duration_ms"),
    "tool_call_failed": ("tool", "error", "step_type", "name", "status", "started_at", "ended_at", "duration_ms"),
    "tool_call_history_pruned": ("pruned_count", "kept_latest_tool_calls"),
    "human_in_the_loop_requested": ("tool", "call_id"),
    "human_in_the_loop_decided": ("tool", "decision_type"),
    "compacted": ("dropped", "kept", "max_chars"),
}

REQUIRED_STEP_ID = {
    "model_call_started",
    "model_call_succeeded",
    "model_call_failed",
    "tool_call_started",
    "tool_call_succeeded",
    "tool_call_failed",
    "run_checkpointed",
    "retry_scheduled",
    "retry_succeeded",
    "retry_exhausted",
    "human_in_the_loop_requested",
    "human_in_the_loop_decided",
}


def validate_event(event_type: str, details: Mapping[str, object], step_id: str | None) -> None:
    if event_type not in CANONICAL_EVENT_TYPES:
        return
    required_detail_keys = REQUIRED_EVENT_DETAILS.get(event_type, ())
    missing_required_detail_keys = [required_key for required_key in required_detail_keys if required_key not in details]
    if missing_required_detail_keys:
        missing_keys = ", ".join(missing_required_detail_keys)
        raise ValueError(f"Event '{event_type}' missing required detail(s): {missing_keys}")
    if event_type in REQUIRED_STEP_ID and step_id is None:
        raise ValueError(f"Event '{event_type}' requires step_id")
