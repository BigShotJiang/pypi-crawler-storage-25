from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol, TYPE_CHECKING

from loguit.core_types import RunContext

if TYPE_CHECKING:
    from loguit.state import ExecutionEvent, RunState


class TraceStorage(Protocol):
    def store_event(self, event: ExecutionEvent, *, context: RunContext, state: RunState) -> None: ...

    def finalize_trace(self, *, context: RunContext, state: RunState) -> None: ...


@dataclass
class FileTraceStorage:
    path: str | Path

    def store_event(self, event: ExecutionEvent, *, context: RunContext, state: RunState) -> None:  # noqa: ARG002
        target = Path(self.path)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(_event_payload(event)) + "\n")

    def finalize_trace(self, *, context: RunContext, state: RunState) -> None:
        target = Path(self.path)
        summary_path = target.with_suffix(".summary.json")
        summary_path.parent.mkdir(parents=True, exist_ok=True)
        summary = {
            "run_id": state.run_id,
            "trace_id": state.trace_id,
            "correlation_id": state.correlation_id,
            "project_id": state.project_id,
            "tenant_id": state.tenant_id,
            "termination": state.termination,
            "event_count": len(state.events),
            "metadata": dict(state.metadata),
        }
        summary_path.write_text(json.dumps(summary), encoding="utf-8")


@dataclass
class InMemoryTraceStorage:
    events: list[ExecutionEvent] = field(default_factory=list)
    finalized: bool = False

    def store_event(self, event: ExecutionEvent, *, context: RunContext, state: RunState) -> None:  # noqa: ARG002
        self.events.append(event)

    def finalize_trace(self, *, context: RunContext, state: RunState) -> None:  # noqa: ARG002
        self.finalized = True


def _event_payload(event: ExecutionEvent) -> dict:
    return {
        "schema_version": event.schema_version,
        "type": event.type,
        "timestamp": event.timestamp,
        "run_id": event.run_id,
        "trace_id": event.trace_id,
        "correlation_id": event.correlation_id,
        "project_id": event.project_id,
        "tenant_id": event.tenant_id,
        "step_id": event.step_id,
        "details": event.details,
    }


__all__ = ["TraceStorage", "FileTraceStorage", "InMemoryTraceStorage"]
