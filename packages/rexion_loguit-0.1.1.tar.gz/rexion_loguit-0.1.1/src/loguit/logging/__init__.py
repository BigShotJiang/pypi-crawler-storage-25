from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Iterable, Protocol, TextIO

from loguit.callbacks import dispatch_recorded_event_to_trace_callback_manager
from loguit.core_types import RunContext
from loguit.logging.storage import TraceStorage

if TYPE_CHECKING:
    from loguit.state import ExecutionEvent, RunState


class EventSink(Protocol):
    def handle(self, event: "ExecutionEvent", *, context: RunContext, state: "RunState") -> None: ...


def _event_payload(event: "ExecutionEvent") -> dict:
    return {
        "schema_version": event.schema_version,
        "type": event.type,
        "timestamp": event.timestamp,
        "run_id": event.run_id,
        "trace_id": event.trace_id,
        "correlation_id": event.correlation_id,
        "project_id": event.project_id,
        "tenant_id": event.tenant_id,
        "step_id": event.step_id,
        "details": event.details,
    }


@dataclass
class ConsoleSink:
    stream: TextIO = sys.stdout

    def handle(self, event: "ExecutionEvent", *, context: RunContext, state: "RunState") -> None:  # noqa: ARG002
        payload = _event_payload(event)
        self.stream.write(json.dumps(payload) + "\n")
        self.stream.flush()


@dataclass
class HumanReadableSink:
    stream: TextIO = sys.stdout
    include_details: bool = True

    def handle(self, event: "ExecutionEvent", *, context: RunContext, state: "RunState") -> None:  # noqa: ARG002
        base = f"{event.timestamp:.3f} {event.type} run={event.run_id}"
        if event.step_id:
            base = f"{base} step={event.step_id}"
        if self.include_details and event.details:
            detail_items = ", ".join(f"{key}={value}" for key, value in event.details.items())
            base = f"{base} {detail_items}"
        self.stream.write(base + "\n")
        self.stream.flush()


@dataclass
class FileSink:
    path: str | Path

    def handle(self, event: "ExecutionEvent", *, context: RunContext, state: "RunState") -> None:  # noqa: ARG002
        payload = _event_payload(event)
        target = Path(self.path)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload) + "\n")


def emit_event(
    state: "RunState",
    context: RunContext,
    sinks: Iterable[EventSink] | None,
    event_type: str,
    *,
    step_id: str | None = None,
    **details: object,
) -> "ExecutionEvent":
    event = state.record_event(event_type, step_id=step_id, **details)
    redaction_pipeline = context.redaction_pipeline
    event_for_sinks = redaction_pipeline.apply(event, context=context, state=state) if redaction_pipeline else event
    dispatch_recorded_event_to_trace_callback_manager(event, context=context, state=state)
    for sink in sinks or []:
        sink.handle(event_for_sinks, context=context, state=state)
    trace_storage = context.trace_storage
    if trace_storage is not None:
        trace_storage.store_event(event_for_sinks, context=context, state=state)
    return event


__all__ = [
    "EventSink",
    "ConsoleSink",
    "HumanReadableSink",
    "FileSink",
    "emit_event",
    "TraceStorage",
]
