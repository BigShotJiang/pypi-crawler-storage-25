from __future__ import annotations

from dataclasses import dataclass
from time import sleep
import asyncio
import random
from typing import Callable, Optional, TypeVar


T = TypeVar("T")


@dataclass(frozen=True)
class RetryPolicy:
    max_attempts: int = 1
    initial_delay_seconds: float = 0.0
    max_delay_seconds: float = 0.0
    backoff_multiplier: float = 2.0
    jitter_seconds: float = 0.0
    retry_on_exceptions: tuple[type[BaseException], ...] = (Exception,)

    def __post_init__(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("max_attempts must be >= 1")
        if self.initial_delay_seconds < 0:
            raise ValueError("initial_delay_seconds must be >= 0")
        if self.max_delay_seconds < 0:
            raise ValueError("max_delay_seconds must be >= 0")
        if self.backoff_multiplier < 1:
            raise ValueError("backoff_multiplier must be >= 1")
        if self.jitter_seconds < 0:
            raise ValueError("jitter_seconds must be >= 0")

    def should_retry(self, error: BaseException) -> bool:
        return isinstance(error, self.retry_on_exceptions)

    def calculate_delay_seconds(self, retry_number: int) -> float:
        if retry_number < 1:
            raise ValueError("retry_number must be >= 1")
        if self.initial_delay_seconds == 0:
            return 0.0
        delay = self.initial_delay_seconds * (self.backoff_multiplier ** (retry_number - 1))
        if self.max_delay_seconds:
            delay = min(delay, self.max_delay_seconds)
        if self.jitter_seconds:
            delay += random.uniform(0.0, self.jitter_seconds)
        return delay


def run_with_retry(
    callable_to_retry: Callable[[], T],
    *,
    retry_policy: RetryPolicy,
    on_retry_event: Optional[Callable[[str, dict[str, object]], None]] = None,
) -> T:
    attempt_number = 1
    retry_number = 0
    while True:
        try:
            result = callable_to_retry()
        except Exception as exc:  # noqa: BLE001
            if not retry_policy.should_retry(exc) or attempt_number >= retry_policy.max_attempts:
                if on_retry_event is not None and retry_policy.max_attempts > 1:
                    on_retry_event(
                        "retry_exhausted",
                        {
                            "attempt_number": attempt_number,
                            "max_attempts": retry_policy.max_attempts,
                            "error": str(exc),
                        },
                    )
                raise
            retry_number += 1
            delay_seconds = retry_policy.calculate_delay_seconds(retry_number)
            if on_retry_event is not None:
                on_retry_event(
                    "retry_scheduled",
                    {
                        "attempt_number": attempt_number + 1,
                        "max_attempts": retry_policy.max_attempts,
                        "delay_seconds": delay_seconds,
                        "error": str(exc),
                    },
                )
            if delay_seconds > 0:
                sleep(delay_seconds)
            attempt_number += 1
            continue
        if on_retry_event is not None and attempt_number > 1:
            on_retry_event(
                "retry_succeeded",
                {
                    "attempt_number": attempt_number,
                    "max_attempts": retry_policy.max_attempts,
                    "retries_used": attempt_number - 1,
                },
            )
        return result


async def run_with_retry_async(
    callable_to_retry: Callable[[], T],
    *,
    retry_policy: RetryPolicy,
    on_retry_event: Optional[Callable[[str, dict[str, object]], None]] = None,
) -> T:
    attempt_number = 1
    retry_number = 0
    while True:
        try:
            result = callable_to_retry()
            if asyncio.iscoroutine(result):
                result = await result
        except Exception as exc:  # noqa: BLE001
            if not retry_policy.should_retry(exc) or attempt_number >= retry_policy.max_attempts:
                if on_retry_event is not None and retry_policy.max_attempts > 1:
                    on_retry_event(
                        "retry_exhausted",
                        {
                            "attempt_number": attempt_number,
                            "max_attempts": retry_policy.max_attempts,
                            "error": str(exc),
                        },
                    )
                raise
            retry_number += 1
            delay_seconds = retry_policy.calculate_delay_seconds(retry_number)
            if on_retry_event is not None:
                on_retry_event(
                    "retry_scheduled",
                    {
                        "attempt_number": attempt_number + 1,
                        "max_attempts": retry_policy.max_attempts,
                        "delay_seconds": delay_seconds,
                        "error": str(exc),
                    },
                )
            if delay_seconds > 0:
                await asyncio.sleep(delay_seconds)
            attempt_number += 1
            continue
        if on_retry_event is not None and attempt_number > 1:
            on_retry_event(
                "retry_succeeded",
                {
                    "attempt_number": attempt_number,
                    "max_attempts": retry_policy.max_attempts,
                    "retries_used": attempt_number - 1,
                },
            )
        return result


__all__ = [
    "RetryPolicy",
    "run_with_retry",
    "run_with_retry_async",
]
