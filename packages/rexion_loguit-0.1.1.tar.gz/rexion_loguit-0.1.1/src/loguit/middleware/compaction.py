from __future__ import annotations

from dataclasses import dataclass

from loguit.core_types import Role, RunContext
from loguit.state import RunState, StepRecord


@dataclass(frozen=True)
class SimpleCompactionConfig:
    max_chars: int = 8000
    keep_last: int = 10
    keep_system: bool = True


class SimpleCompactionMiddleware:
    def __init__(self, config: SimpleCompactionConfig | None = None) -> None:
        self._config = config or SimpleCompactionConfig()

    def before_step(self, context: RunContext, state: RunState, step: StepRecord) -> None:
        _ = context
        if step.step_type != "model_call":
            return

        messages = state.messages
        if not messages:
            return

        max_chars = self._config.max_chars
        if max_chars <= 0:
            return

        total_chars = sum(len(message.message_content) for message in messages)
        if total_chars <= max_chars:
            return

        keep_last = max(self._config.keep_last, 0)
        mandatory_keep = set(range(max(0, len(messages) - keep_last), len(messages)))
        if self._config.keep_system:
            for idx, message in enumerate(messages):
                if message.role == Role.SYSTEM:
                    mandatory_keep.add(idx)

        droppable = [idx for idx in range(len(messages)) if idx not in mandatory_keep]
        drop_indices = set()
        for idx in droppable:
            if total_chars <= max_chars:
                break
            total_chars -= len(messages[idx].message_content)
            drop_indices.add(idx)

        if not drop_indices:
            return

        state.messages[:] = [
            message for idx, message in enumerate(messages) if idx not in drop_indices
        ]
        state.record_event(
            "compacted",
            dropped=len(drop_indices),
            kept=len(state.messages),
            max_chars=max_chars,
        )

    def after_step(self, context: RunContext, state: RunState, step: StepRecord, result: object) -> None:
        _ = context
        _ = state
        _ = step
        _ = result
        return None

    def on_step_error(self, context: RunContext, state: RunState, step: StepRecord, error: Exception) -> None:
        _ = context
        _ = state
        _ = step
        _ = error
        return None

    def around_step(self, context: RunContext, state: RunState, step: StepRecord, call_next):  # noqa: ANN001
        self.before_step(context, state, step)
        try:
            result = call_next()
        except Exception as exc:  # noqa: BLE001
            self.on_step_error(context, state, step, exc)
            raise
        self.after_step(context, state, step, result)
        return result


__all__ = ["SimpleCompactionConfig", "SimpleCompactionMiddleware"]
