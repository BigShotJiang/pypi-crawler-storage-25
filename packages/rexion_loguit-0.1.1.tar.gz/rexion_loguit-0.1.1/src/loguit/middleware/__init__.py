from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import Any, Callable, Iterable, List, Protocol, TypeVar

from loguit.core_types import Message, ModelResult, ModelSettings, RunContext, ToolResult
from loguit.middleware.compaction import SimpleCompactionConfig, SimpleCompactionMiddleware
from loguit.state import RunState, StepRecord

T = TypeVar("T")


def _wrap_generator(
    gen: Any,
    *,
    on_after: Callable[[Any], None],
    on_error: Callable[[Exception], None],
) -> Any:
    try:
        while True:
            try:
                item = next(gen)
            except StopIteration as stop:
                final = stop.value
                on_after(final)
                return final
            else:
                yield item
    except Exception as exc:  # noqa: BLE001
        on_error(exc)
        raise


def _consume_generator_result(gen: Any) -> Any:
    while True:
        try:
            next(gen)
        except StopIteration as stop:
            return stop.value


class RunMiddleware(Protocol):
    def before_run(self, context: RunContext, state: RunState) -> None: ...
    def after_run(self, context: RunContext, state: RunState, result: T) -> None: ...
    def on_run_error(self, context: RunContext, state: RunState, error: Exception) -> None: ...
    def around_run(self, context: RunContext, state: RunState, call_next: Callable[[], T]) -> T: ...


class StepMiddleware(Protocol):
    def before_step(self, context: RunContext, state: RunState, step: StepRecord) -> None: ...
    def after_step(self, context: RunContext, state: RunState, step: StepRecord, result: Any) -> None: ...
    def on_step_error(self, context: RunContext, state: RunState, step: StepRecord, error: Exception) -> None: ...
    def around_step(self, context: RunContext, state: RunState, step: StepRecord, call_next: Callable[[], T]) -> T: ...


@dataclass
class ModelMiddlewareCall:
    model: Any
    messages: list[Message]
    context: RunContext
    settings: ModelSettings | None = None
    tools: Iterable[Any] | None = None
    tool_choice: str | dict | None = None
    parallel_tool_calls: bool | None = None
    strict: bool | None = None
    response_schema: type | dict[str, Any] | None = None


@dataclass
class ToolMiddlewareCall:
    tool: Any
    normalized_tool_arguments: dict[str, Any]
    context: RunContext
    state: RunState
    step: StepRecord


@dataclass
class HumanInTheLoopMiddlewareCall:
    human_in_the_loop_request: Any
    context: RunContext
    state: RunState
    step: StepRecord
    human_in_the_loop_decision: Any = None


class ModelMiddleware(Protocol):
    def before_model_call(self, model_call: ModelMiddlewareCall) -> None: ...
    def after_model_call(self, model_call: ModelMiddlewareCall, result: ModelResult) -> None: ...
    def on_model_call_error(self, model_call: ModelMiddlewareCall, error: Exception) -> None: ...
    def around_model_call(self, model_call: ModelMiddlewareCall, call_next: Callable[[], ModelResult]) -> ModelResult: ...


class ToolMiddleware(Protocol):
    def before_tool_call(self, tool_call: ToolMiddlewareCall) -> None: ...
    def after_tool_call(self, tool_call: ToolMiddlewareCall, result: ToolResult | Any) -> None: ...
    def on_tool_call_error(self, tool_call: ToolMiddlewareCall, error: Exception) -> None: ...
    def around_tool_call(self, tool_call: ToolMiddlewareCall, call_next: Callable[[], T]) -> T: ...


class HumanInTheLoopMiddleware(Protocol):
    def before_human_in_the_loop_request(self, human_in_the_loop_call: HumanInTheLoopMiddlewareCall) -> None: ...
    def after_human_in_the_loop_decision(self, human_in_the_loop_call: HumanInTheLoopMiddlewareCall) -> None: ...
    def around_human_in_the_loop_request(
        self,
        human_in_the_loop_call: HumanInTheLoopMiddlewareCall,
        call_next: Callable[[], T],
    ) -> T: ...


class BaseRunMiddleware:
    def before_run(self, context: RunContext, state: RunState) -> None:  # noqa: ARG002
        return None

    def after_run(self, context: RunContext, state: RunState, result: Any) -> None:  # noqa: ARG002
        return None

    def on_run_error(self, context: RunContext, state: RunState, error: Exception) -> None:  # noqa: ARG002
        return None

    def around_run(self, context: RunContext, state: RunState, call_next: Callable[[], T]) -> T:
        self.before_run(context, state)
        try:
            result = call_next()
        except Exception as exc:  # noqa: BLE001
            self.on_run_error(context, state, exc)
            raise
        if inspect.isgenerator(result):
            return _wrap_generator(
                result,
                on_after=lambda final: self.after_run(context, state, final),
                on_error=lambda exc: self.on_run_error(context, state, exc),
            )
        self.after_run(context, state, result)
        return result


class BaseStepMiddleware:
    def before_step(self, context: RunContext, state: RunState, step: StepRecord) -> None:  # noqa: ARG002
        return None

    def after_step(self, context: RunContext, state: RunState, step: StepRecord, result: Any) -> None:  # noqa: ARG002
        return None

    def on_step_error(self, context: RunContext, state: RunState, step: StepRecord, error: Exception) -> None:  # noqa: ARG002
        return None

    def around_step(self, context: RunContext, state: RunState, step: StepRecord, call_next: Callable[[], T]) -> T:
        self.before_step(context, state, step)
        try:
            result = call_next()
        except Exception as exc:  # noqa: BLE001
            self.on_step_error(context, state, step, exc)
            raise
        if inspect.isgenerator(result):
            return _wrap_generator(
                result,
                on_after=lambda final: self.after_step(context, state, step, final),
                on_error=lambda exc: self.on_step_error(context, state, step, exc),
            )
        self.after_step(context, state, step, result)
        return result


class BaseModelMiddleware:
    def before_model_call(self, model_call: ModelMiddlewareCall) -> None:  # noqa: ARG002
        return None

    def after_model_call(self, model_call: ModelMiddlewareCall, result: ModelResult) -> None:  # noqa: ARG002
        return None

    def on_model_call_error(self, model_call: ModelMiddlewareCall, error: Exception) -> None:  # noqa: ARG002
        return None

    def around_model_call(self, model_call: ModelMiddlewareCall, call_next: Callable[[], ModelResult]) -> ModelResult:
        self.before_model_call(model_call)
        try:
            result = call_next()
        except Exception as exc:  # noqa: BLE001
            self.on_model_call_error(model_call, exc)
            raise
        self.after_model_call(model_call, result)
        return result


class BaseToolMiddleware:
    def before_tool_call(self, tool_call: ToolMiddlewareCall) -> None:  # noqa: ARG002
        return None

    def after_tool_call(self, tool_call: ToolMiddlewareCall, result: ToolResult | Any) -> None:  # noqa: ARG002
        return None

    def on_tool_call_error(self, tool_call: ToolMiddlewareCall, error: Exception) -> None:  # noqa: ARG002
        return None

    def around_tool_call(self, tool_call: ToolMiddlewareCall, call_next: Callable[[], T]) -> T:
        self.before_tool_call(tool_call)
        try:
            result = call_next()
        except Exception as exc:  # noqa: BLE001
            self.on_tool_call_error(tool_call, exc)
            raise
        self.after_tool_call(tool_call, result)
        return result


class BaseHumanInTheLoopMiddleware:
    def before_human_in_the_loop_request(self, human_in_the_loop_call: HumanInTheLoopMiddlewareCall) -> None:  # noqa: ARG002
        return None

    def after_human_in_the_loop_decision(self, human_in_the_loop_call: HumanInTheLoopMiddlewareCall) -> None:  # noqa: ARG002
        return None

    def around_human_in_the_loop_request(
        self,
        human_in_the_loop_call: HumanInTheLoopMiddlewareCall,
        call_next: Callable[[], T],
    ) -> T:
        self.before_human_in_the_loop_request(human_in_the_loop_call)
        return call_next()


class ModelFallbackMiddleware(BaseModelMiddleware):
    def __init__(self, fallback_model: Any, *, fallback_on_exceptions: tuple[type[BaseException], ...] = (Exception,)) -> None:
        self._fallback_model = fallback_model
        self._fallback_on_exceptions = fallback_on_exceptions

    def around_model_call(self, model_call: ModelMiddlewareCall, call_next: Callable[[], ModelResult]) -> ModelResult:
        original_model = model_call.model
        try:
            return call_next()
        except self._fallback_on_exceptions:
            model_call.model = self._fallback_model
            try:
                return call_next()
            finally:
                model_call.model = original_model


class ToolLoggingMiddleware(BaseToolMiddleware):
    def __init__(self) -> None:
        self.records: list[tuple[str, str]] = []

    def before_tool_call(self, tool_call: ToolMiddlewareCall) -> None:
        self.records.append(("before_tool_call", tool_call.step.step_id))

    def after_tool_call(self, tool_call: ToolMiddlewareCall, result: ToolResult | Any) -> None:  # noqa: ARG002
        self.records.append(("after_tool_call", tool_call.step.step_id))


def run_with_run_middleware(
    middleware: Iterable[RunMiddleware],
    context: RunContext,
    state: RunState,
    call_next: Callable[[], T],
) -> T:
    chain: List[RunMiddleware] = list(middleware)

    def invoke(index: int) -> T:
        if index >= len(chain):
            return call_next()
        return chain[index].around_run(context, state, lambda: invoke(index + 1))

    return invoke(0)


def run_step_with_middleware(
    middleware: Iterable[StepMiddleware],
    context: RunContext,
    state: RunState,
    step: StepRecord,
    call_next: Callable[[], T],
) -> T:
    chain: List[StepMiddleware] = list(middleware)

    def invoke(index: int) -> T:
        if index >= len(chain):
            return call_next()
        return chain[index].around_step(context, state, step, lambda: invoke(index + 1))

    return invoke(0)


def run_model_with_middleware(
    middleware: Iterable[ModelMiddleware],
    model_call: ModelMiddlewareCall,
    call_next: Callable[[], ModelResult],
) -> ModelResult:
    chain: List[ModelMiddleware] = list(middleware)

    def invoke(index: int) -> ModelResult:
        if index >= len(chain):
            return call_next()
        return chain[index].around_model_call(model_call, lambda: invoke(index + 1))

    return invoke(0)


def run_tool_with_middleware(
    middleware: Iterable[ToolMiddleware],
    tool_call: ToolMiddlewareCall,
    call_next: Callable[[], T],
) -> T:
    chain: List[ToolMiddleware] = list(middleware)

    def invoke(index: int) -> T:
        if index >= len(chain):
            return call_next()
        return chain[index].around_tool_call(tool_call, lambda: invoke(index + 1))

    return invoke(0)


def run_human_in_the_loop_with_middleware(
    middleware: Iterable[HumanInTheLoopMiddleware],
    human_in_the_loop_call: HumanInTheLoopMiddlewareCall,
    call_next: Callable[[], T],
) -> T:
    chain: List[HumanInTheLoopMiddleware] = list(middleware)

    def invoke(index: int) -> T:
        if index >= len(chain):
            return call_next()
        return chain[index].around_human_in_the_loop_request(human_in_the_loop_call, lambda: invoke(index + 1))

    return invoke(0)


async def run_step_with_middleware_async(
    middleware: Iterable[StepMiddleware],
    context: RunContext,
    state: RunState,
    step: StepRecord,
    call_next: Callable[[], Any],
) -> Any:
    result = run_step_with_middleware(middleware, context, state, step, call_next)
    if inspect.isawaitable(result):
        return await result
    if inspect.isgenerator(result):
        return _consume_generator_result(result)
    return result


__all__ = [
    "RunMiddleware",
    "StepMiddleware",
    "ModelMiddleware",
    "ToolMiddleware",
    "HumanInTheLoopMiddleware",
    "BaseRunMiddleware",
    "BaseStepMiddleware",
    "BaseModelMiddleware",
    "BaseToolMiddleware",
    "BaseHumanInTheLoopMiddleware",
    "ModelMiddlewareCall",
    "ToolMiddlewareCall",
    "HumanInTheLoopMiddlewareCall",
    "ModelFallbackMiddleware",
    "ToolLoggingMiddleware",
    "run_with_run_middleware",
    "run_step_with_middleware",
    "run_model_with_middleware",
    "run_tool_with_middleware",
    "run_human_in_the_loop_with_middleware",
    "run_step_with_middleware_async",
    "SimpleCompactionConfig",
    "SimpleCompactionMiddleware",
]
