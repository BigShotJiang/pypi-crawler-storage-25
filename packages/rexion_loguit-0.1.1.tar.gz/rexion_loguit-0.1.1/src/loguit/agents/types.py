from __future__ import annotations

from dataclasses import dataclass
from typing import Any, List, Optional

from ..core_types import Message
from ..hitl import HumanInTheLoopRequest
from ..state import CheckpointRecord, RunState


@dataclass(frozen=True)
class AgentResult:
    content: Optional[str]
    messages: List[Message]
    steps: int
    termination: str
    state: RunState
    structured_output: Any = None
    checkpoint: CheckpointRecord | None = None
    human_in_the_loop_request: HumanInTheLoopRequest | None = None

    @property
    def text(self) -> Optional[str]:
        return self.content

    @property
    def checkpoint_step_id(self) -> str | None:
        if self.checkpoint is None:
            return None
        return self.checkpoint.step_id
