from __future__ import annotations

from typing import Optional, Tuple


def resolve_tool_execution(
    *,
    tool_execution: str,
    parallel_tool_calls: bool | None,
) -> Tuple[bool, bool]:
    if tool_execution not in {"sequential", "parallel"}:
        raise ValueError("tool_execution must be 'sequential' or 'parallel'")

    runtime_parallel = tool_execution == "parallel"
    provider_parallel = parallel_tool_calls if parallel_tool_calls is not None else runtime_parallel
    return runtime_parallel, provider_parallel
