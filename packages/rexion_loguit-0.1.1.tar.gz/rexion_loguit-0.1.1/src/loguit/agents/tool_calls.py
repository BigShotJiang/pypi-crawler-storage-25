from __future__ import annotations

import json
from typing import Any, List, Optional, Tuple

from ..core_types import ToolCall


def _get_attr(attribute_source: Any, attribute_name: str, default_value: Any = None) -> Any:
    if isinstance(attribute_source, dict):
        return attribute_source.get(attribute_name, default_value)
    return getattr(attribute_source, attribute_name, default_value)


def _extract_tool_calls_from_response(response: Any) -> List[ToolCall]:
    response_output_entries = _get_attr(response, "output") or []
    if isinstance(response_output_entries, dict):
        response_output_entries = [response_output_entries]
    if not isinstance(response_output_entries, list):
        return []
    extracted_tool_calls: List[ToolCall] = []
    for response_output_entry in response_output_entries:
        if _get_attr(response_output_entry, "type") != "function_call":
            continue
        tool_name = _get_attr(response_output_entry, "name")
        if not tool_name:
            continue
        raw_tool_arguments = _get_attr(response_output_entry, "arguments") or {}
        if isinstance(raw_tool_arguments, str):
            try:
                parsed_tool_arguments = json.loads(raw_tool_arguments)
            except json.JSONDecodeError:
                parsed_tool_arguments = {"_raw": raw_tool_arguments}
        elif isinstance(raw_tool_arguments, dict):
            parsed_tool_arguments = raw_tool_arguments
        else:
            parsed_tool_arguments = {"_raw": raw_tool_arguments}
        tool_call_identifier = _get_attr(response_output_entry, "call_id")
        extracted_tool_calls.append(
            ToolCall(name=tool_name, args=parsed_tool_arguments, call_id=tool_call_identifier)
        )
    return extracted_tool_calls


def _extract_tool_calls_from_stream_events(events: List[Any]) -> List[ToolCall]:
    for stream_event in reversed(events):
        response_object = _get_attr(stream_event, "response")
        if response_object is not None:
            extracted_tool_calls = _extract_tool_calls_from_response(response_object)
            if extracted_tool_calls:
                return extracted_tool_calls
        if _get_attr(stream_event, "output") is not None:
            extracted_tool_calls = _extract_tool_calls_from_response(stream_event)
            if extracted_tool_calls:
                return extracted_tool_calls
    return []


def _parse_prompt_tool_calls(text: str) -> Tuple[List[ToolCall], Optional[str]]:
    stripped_text_payload = text.strip()
    try:
        parsed_prompt_payload = json.loads(stripped_text_payload)
    except json.JSONDecodeError:
        return [], None

    if not isinstance(parsed_prompt_payload, dict):
        return [], None

    raw_tool_call_entries = parsed_prompt_payload.get("tool_calls", [])
    parsed_tool_calls: List[ToolCall] = []
    if isinstance(raw_tool_call_entries, list):
        for tool_call_entry in raw_tool_call_entries:
            if not isinstance(tool_call_entry, dict):
                continue
            tool_name = tool_call_entry.get("name")
            parsed_tool_arguments = tool_call_entry.get("args", {})
            tool_call_identifier = tool_call_entry.get("call_id")
            if isinstance(tool_name, str):
                parsed_tool_calls.append(
                    ToolCall(
                        name=tool_name,
                        args=parsed_tool_arguments if isinstance(parsed_tool_arguments, dict) else {},
                        call_id=tool_call_identifier,
                    )
                )

    final_text_response = parsed_prompt_payload.get("final") or parsed_prompt_payload.get("content")
    if final_text_response is not None and not isinstance(final_text_response, str):
        final_text_response = None

    return parsed_tool_calls, final_text_response
