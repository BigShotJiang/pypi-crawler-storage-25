from __future__ import annotations

from typing import Dict, Iterable

from ..tools import Tool


def _build_tool_registry(tools: Iterable[Tool]) -> Dict[str, Tool]:
    registry: Dict[str, Tool] = {}
    for tool in tools:
        name = tool.spec.name
        if name in registry:
            raise ValueError(f"Duplicate tool name: {name}")
        registry[name] = tool
    return registry
