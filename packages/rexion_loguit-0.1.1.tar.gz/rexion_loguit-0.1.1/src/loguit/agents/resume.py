from __future__ import annotations

from typing import List, Optional

from ..core_types import Message
from ..state import RunState, StepRecord


def _prepare_state_for_resume(state: RunState, resume_step_id: Optional[str]) -> List[Message]:
    history = list(state.messages)
    state.messages = history
    if resume_step_id is None:
        state.termination = None
        state.checkpoint = None
        return history

    step_index = None
    step_record: Optional[StepRecord] = None
    for idx, step in enumerate(state.steps):
        if step.step_id == resume_step_id:
            step_index = idx
            step_record = step
            break

    if step_index is None or step_record is None:
        raise ValueError(f"Unknown step_id for resume: {resume_step_id}")
    if step_record.message_index is None:
        raise ValueError(f"Step {resume_step_id} does not include a message_index")

    state.steps = state.steps[:step_index]
    kept_step_ids = {step.step_id for step in state.steps}
    state.tool_calls = [record for record in state.tool_calls if record.step_id in kept_step_ids]
    state.errors = [record for record in state.errors if record.step_id in kept_step_ids]

    history = history[: step_record.message_index]
    state.messages = history
    state.termination = None
    state.checkpoint = None
    return history
