from __future__ import annotations

import asyncio
import inspect
from time import time
from typing import Any, Callable, Iterable, Iterator, List, Optional, Tuple

from ..core_types import AgentStreamEvent, Message, ModelResult, ModelSettings, Role, RunContext, ToolCall
from ..callbacks import dispatch_recorded_event_to_trace_callback_manager
from ..hitl import (
    HumanInTheLoopDecision,
    HumanInTheLoopPolicy,
    HumanInTheLoopRequest,
    deserialize_human_in_the_loop_request,
    serialize_human_in_the_loop_request,
)
from ..logging import EventSink, emit_event
from ..middleware import (
    HumanInTheLoopMiddleware,
    HumanInTheLoopMiddlewareCall,
    ModelMiddleware,
    StepMiddleware,
    ToolMiddleware,
    ToolMiddlewareCall,
    run_human_in_the_loop_with_middleware,
    run_step_with_middleware,
    run_step_with_middleware_async,
    run_tool_with_middleware,
)
from ..model import Model
from ..runtime import call_model
from ..retry import RetryPolicy, run_with_retry, run_with_retry_async
from ..state import ErrorRecord, RunState, StepRecord, ToolCallRecord, ToolCallPruningPolicy, prune_tool_call_history
from ..structured_output import StructuredOutputValidationError, validate_structured_output_value
from ..tools import Tool, normalize_tool_args, validate_tool_args
from ..policies import PolicyEngine, PolicyViolationError
from .stream import _consume_tool_step_generator
from .tool_calls import _extract_tool_calls_from_stream_events, _parse_prompt_tool_calls
from .types import AgentResult


def _clone_run_context_without_trace_callback_manager(run_context: RunContext) -> RunContext:
    return RunContext(
        run_id=run_context.run_id,
        trace_id=run_context.trace_id,
        correlation_id=run_context.correlation_id,
        project_id=run_context.project_id,
        tenant_id=run_context.tenant_id,
        metadata=dict(run_context.metadata),
        policy_engine=run_context.policy_engine,
        redaction_pipeline=run_context.redaction_pipeline,
        trace_storage=run_context.trace_storage,
        trace_callback_manager=None,
    )


def _invoke_tool_with_validation(tool: Tool, raw_args: dict, context: RunContext):  # noqa: ANN001
    normalized = normalize_tool_args(tool.spec.args_schema, raw_args)
    validate_tool_args(tool.spec.args_schema, normalized)
    return tool.invoke(normalized, context=context)


def _normalize_tool_arguments_for_call(tool: Tool, raw_args: dict) -> dict[str, Any]:
    normalized_tool_arguments = normalize_tool_args(tool.spec.args_schema, raw_args)
    validate_tool_args(tool.spec.args_schema, normalized_tool_arguments)
    return normalized_tool_arguments


async def _run_tools_parallel(
    calls: List[ToolCall],
    registry: dict[str, Tool],
    context: RunContext,
    state: RunState,
    steps: List[StepRecord],
    step_middleware: Iterable[StepMiddleware],
    tool_middleware: Iterable[ToolMiddleware],
    retry_policy: RetryPolicy | None,
    event_sinks: Iterable[EventSink],
) -> List[Tuple[ToolCall, str, bool]]:
    tasks = []
    for call, step in zip(calls, steps):
        tool = registry.get(call.name)
        if tool is None:
            tasks.append(_return_exception(RuntimeError(f"Tool not found: {call.name}")))
            continue
        try:
            normalized = _normalize_tool_arguments_for_call(tool, call.args)
        except Exception as exc:  # noqa: BLE001
            tasks.append(_return_exception(exc))
            continue

        async def _invoke_tool(  # noqa: ANN001
            _tool=tool, _norm=normalized, _step=step
        ):
            tool_middleware_call = ToolMiddlewareCall(
                tool=_tool,
                normalized_tool_arguments=_norm,
                context=context,
                state=state,
                step=_step,
            )

            async def _call_tool():  # noqa: ANN001
                return await run_step_with_middleware_async(
                    step_middleware,
                    context,
                    state,
                    _step,
                    lambda: run_tool_with_middleware(
                        tool_middleware,
                        tool_middleware_call,
                        lambda: _tool.ainvoke(_norm, context=context),
                    ),
                )

            if retry_policy is None:
                return await _call_tool()

            def _emit_retry(event_type: str, details: dict[str, object]) -> None:
                emit_event(
                    state,
                    context,
                    event_sinks,
                    event_type,
                    step_id=_step.step_id,
                    step_type=_step.step_type,
                    name=_step.name,
                    **details,
                )

            return await run_with_retry_async(
                _call_tool,
                retry_policy=retry_policy,
                on_retry_event=_emit_retry,
            )

        tasks.append(_invoke_tool())

    results = await asyncio.gather(*tasks, return_exceptions=True)
    outputs: List[Tuple[ToolCall, str, bool]] = []
    for call, result in zip(calls, results):
        if isinstance(result, Exception):
            outputs.append((call, str(result), True))
        else:
            output = result.error if result.error else result.output
            outputs.append((call, str(output), bool(result.error)))
    return outputs


async def _return_exception(exc: Exception) -> Exception:
    return exc


def _calculate_step_duration_ms(step_record: StepRecord) -> Optional[float]:
    if step_record.ended_at is None:
        return None
    step_duration_seconds = step_record.ended_at - step_record.started_at
    if step_duration_seconds < 0:
        return 0.0
    return step_duration_seconds * 1000.0


def _build_step_start_event_details(step_record: StepRecord) -> dict[str, object]:
    return {
        "step_type": step_record.step_type,
        "name": step_record.name,
        "status": step_record.status,
        "message_index": step_record.message_index,
        "started_at": step_record.started_at,
    }


def _build_step_end_event_details(step_record: StepRecord) -> dict[str, object]:
    step_duration_ms = _calculate_step_duration_ms(step_record)
    return {
        "step_type": step_record.step_type,
        "name": step_record.name,
        "status": step_record.status,
        "message_index": step_record.message_index,
        "started_at": step_record.started_at,
        "ended_at": step_record.ended_at,
        "duration_ms": step_duration_ms,
    }


def _build_run_started_event_details(started_at: float) -> dict[str, object]:
    return {"started_at": started_at}


def _build_run_end_event_details(started_at: float, completed_step_count: int) -> dict[str, object]:
    ended_at = time()
    run_duration_seconds = ended_at - started_at
    if run_duration_seconds < 0:
        run_duration_ms = 0.0
    else:
        run_duration_ms = run_duration_seconds * 1000.0
    return {
        "started_at": started_at,
        "ended_at": ended_at,
        "duration_ms": run_duration_ms,
        "completed_step_count": completed_step_count,
    }


def _append_tool_result_to_state_and_history(
    *,
    state: RunState,
    history: List[Message],
    step: StepRecord,
    call: ToolCall,
    output: Any,
    tool_error_message: str | None,
) -> None:
    state.tool_calls.append(
        ToolCallRecord(
            step_id=step.step_id,
            tool_name=call.name,
            call_id=call.call_id,
            args=call.args,
            output=str(output),
            error=tool_error_message,
        )
    )
    if tool_error_message is not None:
        state.errors.append(
            ErrorRecord(
                error_type="tool_error",
                message=tool_error_message,
                step_id=step.step_id,
                tool_name=call.name,
            )
        )
    history.append(
        Message(
            role=Role.TOOL,
            name=call.name,
            message_content=str(output),
            metadata={"tool_call_id": call.call_id},
        )
    )


def _run_agent_loop(
    model: Model,
    registry: dict[str, Tool],
    input_text: str,
    *,
    history: List[Message],
    context: RunContext,
    state: RunState,
    settings: Optional[ModelSettings],
    max_steps: int,
    parallel_tools: bool,
    tool_choice: str | dict | None,
    parallel_tool_calls: bool | None,
    strict: bool | None,
    retention_policy: ToolCallPruningPolicy,
    step_middleware: Iterable[StepMiddleware],
    model_middleware: Iterable[ModelMiddleware],
    tool_middleware: Iterable[ToolMiddleware],
    human_in_the_loop_middleware: Iterable[HumanInTheLoopMiddleware],
    event_sinks: Iterable[EventSink],
    stream_model: bool,
    enable_tool_usage: bool,
    stop_after_step: bool,
    timeout_seconds: Optional[float],
    cancel_check: Optional[Callable[[], bool]],
    max_consecutive_failures: Optional[int],
    tool_error_handling: str,
    retry_policy: RetryPolicy | None,
    policy_engine: PolicyEngine | None,
    response_schema: type | dict[str, Any] | None,
    human_in_the_loop_policy: HumanInTheLoopPolicy | None,
    human_in_the_loop_decision: HumanInTheLoopDecision | None,
    append_input_message: bool = True,
) -> Iterator[AgentStreamEvent]:
    steps = 0
    consecutive_failures = 0
    started_at = time()
    if append_input_message:
        history.append(Message(role=Role.USER, message_content=input_text))
    if human_in_the_loop_policy is not None:
        parallel_tools = False

    def _emit(event_type: str, *, step_id: Optional[str] = None, **data: Any) -> Iterator[AgentStreamEvent]:
        event = emit_event(state, context, event_sinks, event_type, step_id=step_id, **data)
        redaction_pipeline = context.redaction_pipeline
        event_for_stream = (
            redaction_pipeline.apply(event, context=context, state=state) if redaction_pipeline else event
        )
        yield AgentStreamEvent(
            type=event_for_stream.type,
            step_id=event_for_stream.step_id,
            data=event_for_stream.details,
        )

    def _emit_pruned_if_any() -> Iterator[AgentStreamEvent]:
        if not state.events:
            return iter(())
        last = state.events[-1]
        if last.type != "tool_call_history_pruned":
            return iter(())
        redaction_pipeline = context.redaction_pipeline
        event_for_sinks = (
            redaction_pipeline.apply(last, context=context, state=state) if redaction_pipeline else last
        )
        dispatch_recorded_event_to_trace_callback_manager(last, context=context, state=state)
        for sink in event_sinks:
            sink.handle(event_for_sinks, context=context, state=state)
        trace_storage = context.trace_storage
        if trace_storage is not None:
            trace_storage.store_event(event_for_sinks, context=context, state=state)
        return iter(
            (AgentStreamEvent(type=event_for_sinks.type, step_id=event_for_sinks.step_id, data=event_for_sinks.details),)
        )

    def _emit_policy_blocked(violation: PolicyViolationError, *, step_id: Optional[str] = None) -> None:
        emit_event(
            state,
            context,
            event_sinks,
            "policy_check_blocked",
            step_id=step_id,
            policy_name=violation.policy_name,
            scope=violation.scope,
            reason=violation.reason or "policy_blocked",
            metadata=violation.metadata,
        )

    if tool_error_handling not in {"continue", "fail_fast"}:
        raise ValueError("tool_error_handling must be 'continue' or 'fail_fast'")

    def _terminate(reason: str) -> Iterator[AgentStreamEvent]:
        state.checkpoint = None
        state.termination = reason
        run_end_event_details = _build_run_end_event_details(started_at, steps)
        yield from _emit("run_terminated", reason=reason, **run_end_event_details)
        trace_storage = context.trace_storage
        if trace_storage is not None:
            trace_storage.finalize_trace(context=context, state=state)
        return AgentResult(
            content=None,
            messages=history,
            steps=steps,
            termination=reason,
            state=state,
        )

    def _checkpoint(record: StepRecord, *, reason: str = "step_completed") -> Iterator[AgentStreamEvent]:
        checkpoint_record = state.set_checkpoint(record, reason=reason)
        state.termination = "checkpoint"
        checkpointed_at = time()
        yield from _emit(
            "run_checkpointed",
            step_id=record.step_id,
            reason=reason,
            step_type=record.step_type,
            name=record.name,
            checkpointed_at=checkpointed_at,
        )
        return AgentResult(
            content=None,
            messages=history,
            steps=steps,
            termination="checkpoint",
            state=state,
            checkpoint=checkpoint_record,
        )

    def _stop_if_needed() -> Iterator[AgentStreamEvent]:
        if cancel_check is not None and cancel_check():
            return (yield from _terminate("cancelled"))
        if timeout_seconds is not None and (time() - started_at) > timeout_seconds:
            return (yield from _terminate("timeout"))
        return None

    if policy_engine is not None:
        try:
            policy_engine.evaluate_run(context, state)
        except PolicyViolationError as exc:
            state.termination = "policy_blocked"
            _emit_policy_blocked(exc)
            return (yield from _terminate("policy_blocked"))

    yield from _emit("run_started", **_build_run_started_event_details(started_at))

    pending_human_in_the_loop_request = deserialize_human_in_the_loop_request(
        state.metadata.get("pending_human_in_the_loop_request")
    )
    if pending_human_in_the_loop_request is not None:
        if human_in_the_loop_decision is None:
            raise ValueError("human_in_the_loop_decision is required when resuming a HITL checkpoint")
        pending_step = next(
            (step for step in state.steps if step.step_id == pending_human_in_the_loop_request.step_id),
            None,
        )
        if pending_step is None:
            raise ValueError("Pending HITL step was not found in state")
        hitl_decision_call = HumanInTheLoopMiddlewareCall(
            human_in_the_loop_request=pending_human_in_the_loop_request,
            context=context,
            state=state,
            step=pending_step,
            human_in_the_loop_decision=human_in_the_loop_decision,
        )
        for middleware_item in human_in_the_loop_middleware:
            middleware_item.after_human_in_the_loop_decision(hitl_decision_call)
        emit_event(
            state,
            context,
            event_sinks,
            "human_in_the_loop_decided",
            step_id=pending_step.step_id,
            tool=pending_human_in_the_loop_request.tool_name,
            decision_type=human_in_the_loop_decision.decision_type,
        )
        tool_call = ToolCall(
            name=pending_human_in_the_loop_request.tool_name,
            args=(
                human_in_the_loop_decision.edited_arguments
                if human_in_the_loop_decision.decision_type == "edit_arguments"
                and human_in_the_loop_decision.edited_arguments is not None
                else pending_human_in_the_loop_request.tool_arguments
            ),
            call_id=pending_human_in_the_loop_request.call_id,
        )
        if human_in_the_loop_decision.decision_type == "reject":
            output = human_in_the_loop_decision.rejection_reason or "Tool execution rejected by human review"
            _append_tool_result_to_state_and_history(
                state=state,
                history=history,
                step=pending_step,
                call=tool_call,
                output=output,
                tool_error_message=str(output),
            )
            state.end_step(pending_step, status="error", error=str(output))
            pending_step_details = _build_step_end_event_details(pending_step)
            yield from _emit(
                "tool_call_failed",
                step_id=pending_step.step_id,
                tool=tool_call.name,
                error=str(output),
                **pending_step_details,
            )
        else:
            tool = registry.get(tool_call.name)
            if tool is None:
                raise RuntimeError(f"Tool not found: {tool_call.name}")
            normalized_tool_arguments = _normalize_tool_arguments_for_call(tool, tool_call.args)
            tool_middleware_call = ToolMiddlewareCall(
                tool=tool,
                normalized_tool_arguments=normalized_tool_arguments,
                context=context,
                state=state,
                step=pending_step,
            )

            def _execute_pending_tool():  # noqa: ANN001
                return run_step_with_middleware(
                    step_middleware,
                    context,
                    state,
                    pending_step,
                    lambda: run_tool_with_middleware(
                        tool_middleware,
                        tool_middleware_call,
                        lambda: tool.invoke(normalized_tool_arguments, context=context),
                    ),
                )

            pending_tool_result = _execute_pending_tool()
            if inspect.isgenerator(pending_tool_result):
                pending_tool_result = yield from _consume_tool_step_generator(
                    pending_tool_result,
                    step_id=pending_step.step_id,
                    tool_name=tool_call.name,
                )
            pending_output = pending_tool_result.error if pending_tool_result.error else pending_tool_result.output
            _append_tool_result_to_state_and_history(
                state=state,
                history=history,
                step=pending_step,
                call=tool_call,
                output=pending_output,
                tool_error_message=pending_tool_result.error,
            )
            if pending_tool_result.error:
                state.end_step(pending_step, status="error", error=str(pending_tool_result.error))
                pending_step_details = _build_step_end_event_details(pending_step)
                yield from _emit(
                    "tool_call_failed",
                    step_id=pending_step.step_id,
                    tool=tool_call.name,
                    error=str(pending_tool_result.error),
                    **pending_step_details,
                )
            else:
                state.end_step(pending_step, status="completed")
                pending_step_details = _build_step_end_event_details(pending_step)
                yield from _emit(
                    "tool_call_succeeded",
                    step_id=pending_step.step_id,
                    tool=tool_call.name,
                    **pending_step_details,
                )
            yield AgentStreamEvent(
                type="tool_result",
                step_id=pending_step.step_id,
                data={
                    "tool": tool_call.name,
                    "output": str(pending_output),
                    "error": pending_tool_result.error if hasattr(pending_tool_result, "error") else None,
                },
            )
        state.metadata.pop("pending_human_in_the_loop_request", None)
        prune_tool_call_history(state, retention_policy)
        yield from _emit_pruned_if_any()

    while steps < max_steps:
        stop_result = yield from _stop_if_needed()
        if stop_result is not None:
            return stop_result
        steps += 1
        model_step = state.start_step("model_call", model.name, message_index=len(history))
        if policy_engine is not None:
            try:
                policy_engine.evaluate_step(context, state, model_step)
            except PolicyViolationError as exc:
                state.end_step(model_step, status="blocked", error=str(exc))
                state.errors.append(
                    ErrorRecord(error_type="policy_blocked", message=str(exc), step_id=model_step.step_id)
                )
                _emit_policy_blocked(exc, step_id=model_step.step_id)
                return (yield from _terminate("policy_blocked"))
        model_step_start_details = _build_step_start_event_details(model_step)
        yield from _emit(
            "model_call_started",
            step_id=model_step.step_id,
            model=model.name,
            **model_step_start_details,
        )
        try:
            use_stream_model = stream_model and model.__class__.stream is not Model.stream
            tools_for_model = (
                registry.values() if model.tool_calling == "native" and enable_tool_usage else None
            )

            def _stream_call() -> Iterator[AgentStreamEvent]:
                chunks: List[str] = []
                raw_events: List[Any] = []
                for event in model.stream(
                    history,
                    context=context,
                    settings=settings,
                    tools=tools_for_model,
                    tool_choice=tool_choice,
                    parallel_tool_calls=parallel_tool_calls,
                    strict=strict,
                ):
                    if event.raw is not None:
                        raw_events.append(event.raw)
                    if event.delta:
                        chunks.append(event.delta)
                        yield AgentStreamEvent(
                            type="model_delta",
                            delta=event.delta,
                            step_id=model_step.step_id,
                            data={"event_type": event.type},
                            raw=event.raw,
                        )
                    else:
                        yield AgentStreamEvent(
                            type="model_event",
                            step_id=model_step.step_id,
                            data={"event_type": event.type},
                            raw=event.raw,
                        )
                tool_calls = _extract_tool_calls_from_stream_events(raw_events)
                content = "".join(chunks) if chunks else None
                if content is None and not tool_calls:
                    raise ValueError("Model stream did not return content or tool calls")
                return ModelResult(content=content, tool_calls=tool_calls)

            def _call_model():  # noqa: ANN001
                if use_stream_model:
                    return _stream_call()
                return call_model(
                    model,
                    history,
                    context=_clone_run_context_without_trace_callback_manager(context),
                    settings=settings,
                    tools=tools_for_model,
                    tool_choice=tool_choice,
                    parallel_tool_calls=parallel_tool_calls,
                    strict=strict,
                    response_schema=response_schema,
                    model_middleware=model_middleware,
                )

            def _call_model_with_retry():  # noqa: ANN001
                if retry_policy is None:
                    return _call_model()

                def _emit_retry(event_type: str, details: dict[str, object]) -> None:
                    emit_event(
                        state,
                        context,
                        event_sinks,
                        event_type,
                        step_id=model_step.step_id,
                        step_type=model_step.step_type,
                        name=model_step.name,
                        **details,
                    )

                return run_with_retry(_call_model, retry_policy=retry_policy, on_retry_event=_emit_retry)

            result_or_stream = run_step_with_middleware(
                step_middleware,
                context,
                state,
                model_step,
                _call_model_with_retry,
            )
            if inspect.isgenerator(result_or_stream):
                result = yield from result_or_stream
            else:
                result = result_or_stream
        except Exception as exc:  # noqa: BLE001
            state.end_step(model_step, status="error", error=str(exc))
            state.errors.append(
                ErrorRecord(error_type="model_error", message=str(exc), step_id=model_step.step_id)
            )
            model_step_end_details = _build_step_end_event_details(model_step)
            yield from _emit(
                "model_call_failed",
                step_id=model_step.step_id,
                model=model.name,
                error=str(exc),
                **model_step_end_details,
            )
            state.termination = "error"
            run_end_event_details = _build_run_end_event_details(started_at, steps)
            yield from _emit("run_terminated", reason="model_error", **run_end_event_details)
            trace_storage = context.trace_storage
            if trace_storage is not None:
                trace_storage.finalize_trace(context=context, state=state)
            raise
        state.end_step(model_step, status="completed")
        consecutive_failures = 0
        model_step_end_details = _build_step_end_event_details(model_step)
        yield from _emit(
            "model_call_succeeded",
            step_id=model_step.step_id,
            model=model.name,
            **model_step_end_details,
        )
        if result.content is not None:
            yield AgentStreamEvent(
                type="model_output",
                step_id=model_step.step_id,
                data={"content": result.content, "tool_calls": result.tool_calls},
            )
        tool_calls = result.tool_calls
        final_override: Optional[str] = None

        if model.tool_calling == "prompt" and result.content:
            prompt_calls, final_override = _parse_prompt_tool_calls(result.content)
            if prompt_calls:
                tool_calls = prompt_calls

        stop_result = yield from _stop_if_needed()
        if stop_result is not None:
            return stop_result

        if tool_calls and not enable_tool_usage:
            history.append(
                Message(
                    role=Role.ASSISTANT,
                    message_content=result.content or "",
                    metadata={"tool_calls": tool_calls},
                )
            )
            state.termination = "tool_usage_disabled"
            run_end_event_details = _build_run_end_event_details(started_at, steps)
            yield from _emit("run_terminated", reason="tool_usage_disabled", **run_end_event_details)
            trace_storage = context.trace_storage
            if trace_storage is not None:
                trace_storage.finalize_trace(context=context, state=state)
            return AgentResult(
                content=final_override or result.content,
                messages=history,
                steps=steps,
                termination="tool_usage_disabled",
                state=state,
            )

        if tool_calls:
            use_parallel_tools = parallel_tools
            history.append(
                Message(
                    role=Role.ASSISTANT,
                    message_content=result.content or "",
                    metadata={"tool_calls": tool_calls},
                )
            )
            if use_parallel_tools and tool_calls:
                try:
                    asyncio.get_running_loop()
                    use_parallel_tools = False
                except RuntimeError:
                    pass

            if use_parallel_tools:
                tool_steps: List[StepRecord] = []
                for call in tool_calls:
                    step = state.start_step("tool_call", call.name, message_index=len(history))
                    if policy_engine is not None:
                        try:
                            policy_engine.evaluate_step(context, state, step)
                        except PolicyViolationError as exc:
                            state.end_step(step, status="blocked", error=str(exc))
                            state.errors.append(
                                ErrorRecord(
                                    error_type="policy_blocked",
                                    message=str(exc),
                                    step_id=step.step_id,
                                    tool_name=call.name,
                                )
                            )
                            _emit_policy_blocked(exc, step_id=step.step_id)
                            return (yield from _terminate("policy_blocked"))
                    tool_steps.append(step)
                    tool_step_start_details = _build_step_start_event_details(step)
                    yield from _emit(
                        "tool_call_started",
                        step_id=step.step_id,
                        tool=call.name,
                        **tool_step_start_details,
                    )
                    yield AgentStreamEvent(
                        type="tool_call",
                        step_id=step.step_id,
                        data={"tool": call.name, "args": call.args, "call_id": call.call_id},
                    )
                outputs = asyncio.run(
                    _run_tools_parallel(
                        tool_calls,
                        registry,
                        context,
                        state,
                        tool_steps,
                        step_middleware,
                        tool_middleware,
                        retry_policy,
                        event_sinks,
                    )
                )
                error_count = 0
                for (call, output, is_error), step in zip(outputs, tool_steps):
                    state.tool_calls.append(
                        ToolCallRecord(
                            step_id=step.step_id,
                            tool_name=call.name,
                            call_id=call.call_id,
                            args=call.args,
                            output=str(output),
                            error=str(output) if is_error else None,
                        )
                    )
                    if is_error:
                        error_count += 1
                        state.errors.append(
                            ErrorRecord(
                                error_type="tool_error",
                                message=str(output),
                                step_id=step.step_id,
                                tool_name=call.name,
                            )
                        )
                        state.end_step(step, status="error", error=str(output))
                        tool_step_end_details = _build_step_end_event_details(step)
                        yield from _emit(
                            "tool_call_failed",
                            step_id=step.step_id,
                            tool=call.name,
                            error=str(output),
                            **tool_step_end_details,
                        )
                        consecutive_failures += 1
                        if (
                            max_consecutive_failures is not None
                            and consecutive_failures >= max_consecutive_failures
                        ):
                            return (yield from _terminate("max_consecutive_failures"))
                    else:
                        state.end_step(step, status="completed")
                        tool_step_end_details = _build_step_end_event_details(step)
                        yield from _emit(
                            "tool_call_succeeded",
                            step_id=step.step_id,
                            tool=call.name,
                            **tool_step_end_details,
                        )
                        consecutive_failures = 0
                    history.append(
                        Message(
                            role=Role.TOOL,
                            name=call.name,
                            message_content=str(output),
                            metadata={"tool_call_id": call.call_id},
                        )
                    )
                    yield AgentStreamEvent(
                        type="tool_result",
                        step_id=step.step_id,
                        data={
                            "tool": call.name,
                            "output": str(output),
                            "error": str(output) if is_error else None,
                        },
                    )
                prune_tool_call_history(state, retention_policy)
                yield from _emit_pruned_if_any()
                if error_count and tool_error_handling == "fail_fast":
                    return (yield from _terminate("tool_error"))
                stop_result = yield from _stop_if_needed()
                if stop_result is not None:
                    return stop_result
                if stop_after_step:
                    return (yield from _checkpoint(tool_steps[-1]))
            else:
                for call in tool_calls:
                    step = state.start_step("tool_call", call.name, message_index=len(history))
                    if policy_engine is not None:
                        try:
                            policy_engine.evaluate_step(context, state, step)
                        except PolicyViolationError as exc:
                            state.end_step(step, status="blocked", error=str(exc))
                            state.errors.append(
                                ErrorRecord(
                                    error_type="policy_blocked",
                                    message=str(exc),
                                    step_id=step.step_id,
                                    tool_name=call.name,
                                )
                            )
                            _emit_policy_blocked(exc, step_id=step.step_id)
                            return (yield from _terminate("policy_blocked"))
                    tool_step_start_details = _build_step_start_event_details(step)
                    yield from _emit(
                        "tool_call_started",
                        step_id=step.step_id,
                        tool=call.name,
                        **tool_step_start_details,
                    )
                    yield AgentStreamEvent(
                        type="tool_call",
                        step_id=step.step_id,
                        data={"tool": call.name, "args": call.args, "call_id": call.call_id},
                    )
                    tool = registry.get(call.name)
                    if tool is None:
                        error_message = f"Tool not found: {call.name}"
                        output = error_message
                        state.tool_calls.append(
                            ToolCallRecord(
                                step_id=step.step_id,
                                tool_name=call.name,
                                call_id=call.call_id,
                                args=call.args,
                                output=str(output),
                                error=error_message,
                            )
                        )
                        state.errors.append(
                            ErrorRecord(
                                error_type="tool_error",
                                message=error_message,
                                step_id=step.step_id,
                                tool_name=call.name,
                            )
                        )
                        state.end_step(step, status="error", error=error_message)
                        tool_step_end_details = _build_step_end_event_details(step)
                        yield from _emit(
                            "tool_call_failed",
                            step_id=step.step_id,
                            tool=call.name,
                            error=error_message,
                            **tool_step_end_details,
                        )
                        history.append(
                            Message(
                                role=Role.TOOL,
                                name=call.name,
                                message_content=str(output),
                                metadata={"tool_call_id": call.call_id},
                            )
                        )
                        yield AgentStreamEvent(
                            type="tool_result",
                            step_id=step.step_id,
                            data={
                                "tool": call.name,
                                "output": str(output),
                                "error": error_message,
                            },
                        )
                        prune_tool_call_history(state, retention_policy)
                        yield from _emit_pruned_if_any()
                        consecutive_failures += 1
                        if (
                            max_consecutive_failures is not None
                            and consecutive_failures >= max_consecutive_failures
                        ):
                            return (yield from _terminate("max_consecutive_failures"))
                        if tool_error_handling == "fail_fast":
                            return (yield from _terminate("tool_error"))
                        continue
                    try:
                        normalized_tool_arguments = _normalize_tool_arguments_for_call(tool, call.args)
                    except Exception as exc:  # noqa: BLE001
                        output = str(exc)
                        _append_tool_result_to_state_and_history(
                            state=state,
                            history=history,
                            step=step,
                            call=call,
                            output=output,
                            tool_error_message=str(exc),
                        )
                        state.end_step(step, status="error", error=str(exc))
                        tool_step_end_details = _build_step_end_event_details(step)
                        yield from _emit(
                            "tool_call_failed",
                            step_id=step.step_id,
                            tool=call.name,
                            error=str(exc),
                            **tool_step_end_details,
                        )
                        yield AgentStreamEvent(
                            type="tool_result",
                            step_id=step.step_id,
                            data={"tool": call.name, "output": str(output), "error": str(exc)},
                        )
                        prune_tool_call_history(state, retention_policy)
                        yield from _emit_pruned_if_any()
                        consecutive_failures += 1
                        if max_consecutive_failures is not None and consecutive_failures >= max_consecutive_failures:
                            return (yield from _terminate("max_consecutive_failures"))
                        if tool_error_handling == "fail_fast":
                            return (yield from _terminate("tool_error"))
                        continue
                    if (
                        human_in_the_loop_policy is not None
                        and human_in_the_loop_policy.should_request_approval(
                            tool_name=call.name,
                            normalized_tool_arguments=normalized_tool_arguments,
                            context=context,
                        )
                    ):
                        human_in_the_loop_request = HumanInTheLoopRequest(
                            step_id=step.step_id,
                            tool_name=call.name,
                            tool_arguments=dict(normalized_tool_arguments),
                            call_id=call.call_id,
                        )
                        human_in_the_loop_call = HumanInTheLoopMiddlewareCall(
                            human_in_the_loop_request=human_in_the_loop_request,
                            context=context,
                            state=state,
                            step=step,
                        )
                        run_human_in_the_loop_with_middleware(
                            human_in_the_loop_middleware,
                            human_in_the_loop_call,
                            lambda: None,
                        )
                        state.metadata["pending_human_in_the_loop_request"] = serialize_human_in_the_loop_request(
                            human_in_the_loop_request
                        )
                        state.end_step(step, status="pending")
                        emit_event(
                            state,
                            context,
                            event_sinks,
                            "human_in_the_loop_requested",
                            step_id=step.step_id,
                            tool=call.name,
                            call_id=call.call_id,
                        )
                        checkpoint_record = state.set_checkpoint(step, reason="human_in_the_loop")
                        state.termination = "checkpoint"
                        checkpointed_at = time()
                        yield from _emit(
                            "run_checkpointed",
                            step_id=step.step_id,
                            reason="human_in_the_loop",
                            step_type=step.step_type,
                            name=step.name,
                            checkpointed_at=checkpointed_at,
                        )
                        return AgentResult(
                            content=None,
                            messages=history,
                            steps=steps,
                            termination="checkpoint",
                            state=state,
                            checkpoint=checkpoint_record,
                            human_in_the_loop_request=human_in_the_loop_request,
                        )
                    try:
                        tool_middleware_call = ToolMiddlewareCall(
                            tool=tool,
                            normalized_tool_arguments=normalized_tool_arguments,
                            context=context,
                            state=state,
                            step=step,
                        )

                        def _call_tool():  # noqa: ANN001
                            return run_step_with_middleware(
                                step_middleware,
                                context,
                                state,
                                step,
                                lambda: run_tool_with_middleware(
                                    tool_middleware,
                                    tool_middleware_call,
                                    lambda: tool.invoke(normalized_tool_arguments, context=context),
                                ),
                            )

                        if retry_policy is None:
                            tool_result = _call_tool()
                        else:
                            def _emit_retry(event_type: str, details: dict[str, object]) -> None:
                                emit_event(
                                    state,
                                    context,
                                    event_sinks,
                                    event_type,
                                    step_id=step.step_id,
                                    step_type=step.step_type,
                                    name=step.name,
                                    **details,
                                )

                            tool_result = run_with_retry(
                                _call_tool,
                                retry_policy=retry_policy,
                                on_retry_event=_emit_retry,
                            )
                        if inspect.isgenerator(tool_result):
                            tool_result = yield from _consume_tool_step_generator(
                                tool_result,
                                step_id=step.step_id,
                                tool_name=call.name,
                            )
                    except Exception as exc:  # noqa: BLE001
                        output = str(exc)
                        state.tool_calls.append(
                            ToolCallRecord(
                                step_id=step.step_id,
                                tool_name=call.name,
                                call_id=call.call_id,
                                args=call.args,
                                output=str(output),
                                error=str(exc),
                            )
                        )
                        state.errors.append(
                            ErrorRecord(
                                error_type="tool_error",
                                message=str(exc),
                                step_id=step.step_id,
                                tool_name=call.name,
                            )
                        )
                        state.end_step(step, status="error", error=str(exc))
                        tool_step_end_details = _build_step_end_event_details(step)
                        yield from _emit(
                            "tool_call_failed",
                            step_id=step.step_id,
                            tool=call.name,
                            error=str(exc),
                            **tool_step_end_details,
                        )
                        history.append(
                            Message(
                                role=Role.TOOL,
                                name=call.name,
                                message_content=str(output),
                                metadata={"tool_call_id": call.call_id},
                            )
                        )
                        yield AgentStreamEvent(
                            type="tool_result",
                            step_id=step.step_id,
                            data={
                                "tool": call.name,
                                "output": str(output),
                                "error": str(exc),
                            },
                        )
                        prune_tool_call_history(state, retention_policy)
                        yield from _emit_pruned_if_any()
                        consecutive_failures += 1
                        if (
                            max_consecutive_failures is not None
                            and consecutive_failures >= max_consecutive_failures
                        ):
                            return (yield from _terminate("max_consecutive_failures"))
                        if tool_error_handling == "fail_fast":
                            return (yield from _terminate("tool_error"))
                        continue
                    output = tool_result.error if tool_result.error else tool_result.output
                    state.tool_calls.append(
                        ToolCallRecord(
                            step_id=step.step_id,
                            tool_name=call.name,
                            call_id=call.call_id,
                            args=call.args,
                            output=str(output),
                            error=tool_result.error,
                        )
                    )
                    if tool_result.error:
                        state.errors.append(
                            ErrorRecord(
                                error_type="tool_error",
                                message=str(tool_result.error),
                                step_id=step.step_id,
                                tool_name=call.name,
                            )
                        )
                        state.end_step(step, status="error", error=str(tool_result.error))
                        tool_step_end_details = _build_step_end_event_details(step)
                        yield from _emit(
                            "tool_call_failed",
                            step_id=step.step_id,
                            tool=call.name,
                            error=str(tool_result.error),
                            **tool_step_end_details,
                        )
                        consecutive_failures += 1
                        if (
                            max_consecutive_failures is not None
                            and consecutive_failures >= max_consecutive_failures
                        ):
                            return (yield from _terminate("max_consecutive_failures"))
                    else:
                        state.end_step(step, status="completed")
                        tool_step_end_details = _build_step_end_event_details(step)
                        yield from _emit(
                            "tool_call_succeeded",
                            step_id=step.step_id,
                            tool=call.name,
                            **tool_step_end_details,
                        )
                        consecutive_failures = 0
                    history.append(
                        Message(
                            role=Role.TOOL,
                            name=call.name,
                            message_content=str(output),
                            metadata={"tool_call_id": call.call_id},
                        )
                    )
                    yield AgentStreamEvent(
                        type="tool_result",
                        step_id=step.step_id,
                        data={
                            "tool": call.name,
                            "output": str(output),
                            "error": tool_result.error,
                        },
                    )
                    prune_tool_call_history(state, retention_policy)
                    yield from _emit_pruned_if_any()
                    if tool_result.error and tool_error_handling == "fail_fast":
                        return (yield from _terminate("tool_error"))
                    stop_result = yield from _stop_if_needed()
                    if stop_result is not None:
                        return stop_result
                    if stop_after_step:
                        return (yield from _checkpoint(step))
                if stop_after_step:
                    return (yield from _checkpoint(step))
            continue

        if result.content is not None or result.structured_output is not None:
            content = final_override or result.content
            structured_output = result.structured_output
            if response_schema is not None and structured_output is None and content is not None:
                structured_output = validate_structured_output_value(content, response_schema=response_schema)
            history.append(Message(role=Role.ASSISTANT, message_content=content or ""))
            finalize_step = state.start_step("finalize", "final", message_index=len(history))
            state.end_step(finalize_step, status="completed")
            state.checkpoint = None
            state.termination = "completed"
            run_end_event_details = _build_run_end_event_details(started_at, steps)
            yield from _emit("run_completed", step_id=finalize_step.step_id, **run_end_event_details)
            trace_storage = context.trace_storage
            if trace_storage is not None:
                trace_storage.finalize_trace(context=context, state=state)
            return AgentResult(
                content=content,
                messages=history,
                steps=steps,
                termination="completed",
                state=state,
                structured_output=structured_output,
            )

    state.checkpoint = None
    state.termination = "max_steps"
    run_end_event_details = _build_run_end_event_details(started_at, steps)
    yield from _emit("run_terminated", reason="max_steps", **run_end_event_details)
    return AgentResult(
        content=None,
        messages=history,
        steps=steps,
        termination="max_steps",
        state=state,
    )
