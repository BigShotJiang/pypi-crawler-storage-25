from __future__ import annotations

from typing import Any, Iterator

from ..core_types import AgentStreamEvent, ToolResult, ToolStreamEvent
from .types import AgentResult


def _consume_generator(stream: Iterator[AgentStreamEvent]) -> AgentResult:
    while True:
        try:
            next(stream)
        except StopIteration as stop:
            return stop.value


def _consume_step_generator(stream: Iterator[Any]) -> Any:
    yielded = False
    while True:
        try:
            next(stream)
            yielded = True
        except StopIteration as stop:
            if yielded:
                raise RuntimeError("Streamed step did not return a final value")
            return stop.value


def _iter_agent_stream(stream: Iterator[AgentStreamEvent]) -> Iterator[AgentStreamEvent]:
    while True:
        try:
            event = next(stream)
        except StopIteration as stop:
            yield AgentStreamEvent(type="run_result", data={"result": stop.value})
            return
        else:
            yield event


def _normalize_tool_stream_item(item: Any, *, step_id: str, tool_name: str) -> AgentStreamEvent:
    if isinstance(item, AgentStreamEvent):
        if item.step_id is not None:
            return item
        data = dict(item.data)
        data.setdefault("tool", tool_name)
        return AgentStreamEvent(
            type=item.type,
            delta=item.delta,
            step_id=step_id,
            data=data,
            raw=item.raw,
        )

    if isinstance(item, ToolStreamEvent):
        data = dict(item.data)
        data["tool"] = tool_name
        data["event_type"] = item.type
        return AgentStreamEvent(
            type="tool_delta" if item.delta is not None else "tool_event",
            delta=item.delta,
            step_id=step_id,
            data=data,
            raw=item.raw,
        )

    if isinstance(item, str):
        return AgentStreamEvent(
            type="tool_delta",
            delta=item,
            step_id=step_id,
            data={"tool": tool_name, "event_type": "tool.output_text.delta"},
            raw=item,
        )

    return AgentStreamEvent(
        type="tool_event",
        step_id=step_id,
        data={"tool": tool_name, "event_type": "tool.output", "value": item},
        raw=item,
    )


def _consume_tool_step_generator(
    stream: Iterator[Any],
    *,
    step_id: str,
    tool_name: str,
) -> Iterator[AgentStreamEvent]:
    deltas: list[str] = []
    while True:
        try:
            item = next(stream)
        except StopIteration as stop:
            final = stop.value
            if isinstance(final, ToolResult):
                return final
            if final is None and deltas:
                text = "".join(deltas)
                return ToolResult(output=text, raw=text)
            return ToolResult(output=final, raw=final)
        else:
            if isinstance(item, ToolStreamEvent) and item.delta is not None:
                deltas.append(item.delta)
            elif isinstance(item, str):
                deltas.append(item)
            yield _normalize_tool_stream_item(item, step_id=step_id, tool_name=tool_name)
