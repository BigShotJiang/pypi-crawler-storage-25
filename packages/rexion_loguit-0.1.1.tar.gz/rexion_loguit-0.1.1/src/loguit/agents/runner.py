from __future__ import annotations

from time import time
from typing import Callable, Iterable, Iterator, Optional
from uuid import uuid4

from ..callbacks import (
    TraceCallbackFailureMode,
    TraceCallbackHandler,
    resolve_trace_callback_manager,
)
from ..core_types import AgentStreamEvent, Message, ModelSettings, RunContext
from ..hitl import HumanInTheLoopDecision, HumanInTheLoopPolicy
from ..logging import EventSink, emit_event
from ..middleware import (
    HumanInTheLoopMiddleware,
    ModelMiddleware,
    RunMiddleware,
    StepMiddleware,
    ToolMiddleware,
    run_with_run_middleware,
)
from ..model import Model
from ..policies import PolicyEngine, RedactionPipeline, PolicyViolationError
from ..retry import RetryPolicy
from ..logging.storage import TraceStorage
from ..state import RunState, ToolCallPruningPolicy
from ..tools import Tool
from .execution import resolve_tool_execution
from .loop import _run_agent_loop
from .registry import _build_tool_registry
from .resume import _prepare_state_for_resume
from .stream import _consume_generator, _iter_agent_stream
from .types import AgentResult


def _build_run_state_from_context(run_context: RunContext) -> RunState:
    return RunState(
        run_id=run_context.run_id,
        trace_id=run_context.trace_id,
        correlation_id=run_context.correlation_id,
        project_id=run_context.project_id,
        tenant_id=run_context.tenant_id,
        metadata=dict(run_context.metadata),
    )


def _sync_run_state_identity_from_context(state: RunState, run_context: RunContext) -> None:
    state.run_id = run_context.run_id
    state.trace_id = run_context.trace_id or run_context.run_id
    state.correlation_id = run_context.correlation_id
    state.project_id = run_context.project_id
    state.tenant_id = run_context.tenant_id
    state.metadata.update(run_context.metadata)


def _configure_run_context(
    run_context: RunContext,
    *,
    policy_engine: PolicyEngine | None,
    redaction_pipeline: RedactionPipeline | None,
    trace_storage: TraceStorage | None,
    trace_callback_handlers: Iterable[TraceCallbackHandler] | None,
    trace_callback_failure_mode: TraceCallbackFailureMode | str,
) -> RunContext:
    if policy_engine is not None:
        run_context.policy_engine = policy_engine
    if redaction_pipeline is not None:
        run_context.redaction_pipeline = redaction_pipeline
    if trace_storage is not None:
        run_context.trace_storage = trace_storage
    run_context.trace_callback_manager = resolve_trace_callback_manager(
        run_context,
        trace_callback_handlers,
        trace_callback_failure_mode,
    )
    return run_context


def run_agent(
    model: Model,
    tools: Iterable[Tool],
    input_text: str,
    *,
    messages: Optional[Iterable[Message]] = None,
    context: Optional[RunContext] = None,
    settings: Optional[ModelSettings] = None,
    max_steps: int = 10,
    timeout_seconds: float | None = None,
    cancel_check: Callable[[], bool] | None = None,
    max_consecutive_failures: int | None = None,
    tool_error_handling: str = "continue",
    enable_tool_usage: bool = True,
    tool_execution: str = "sequential",
    tool_choice: str | dict | None = None,
    parallel_tool_calls: bool | None = None,
    strict: bool | None = None,
    retention_policy: ToolCallPruningPolicy | None = None,
    run_middleware: Optional[Iterable[RunMiddleware]] = None,
    step_middleware: Optional[Iterable[StepMiddleware]] = None,
    model_middleware: Optional[Iterable[ModelMiddleware]] = None,
    tool_middleware: Optional[Iterable[ToolMiddleware]] = None,
    human_in_the_loop_middleware: Optional[Iterable[HumanInTheLoopMiddleware]] = None,
    event_sinks: Optional[Iterable[EventSink]] = None,
    retry_policy: RetryPolicy | None = None,
    response_schema: type | dict | None = None,
    human_in_the_loop_policy: HumanInTheLoopPolicy | None = None,
    policy_engine: PolicyEngine | None = None,
    redaction_pipeline: RedactionPipeline | None = None,
    trace_storage: TraceStorage | None = None,
    trace_callback_handlers: Iterable[TraceCallbackHandler] | None = None,
    trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
) -> AgentResult:
    runtime_parallel_tools, provider_parallel_tool_calls = resolve_tool_execution(
        tool_execution=tool_execution,
        parallel_tool_calls=parallel_tool_calls,
    )
    run_context = _configure_run_context(
        context or RunContext(run_id=str(uuid4())),
        policy_engine=policy_engine,
        redaction_pipeline=redaction_pipeline,
        trace_storage=trace_storage,
        trace_callback_handlers=trace_callback_handlers,
        trace_callback_failure_mode=trace_callback_failure_mode,
    )
    policy_engine = run_context.policy_engine
    registry = _build_tool_registry(tools)
    policy = retention_policy or ToolCallPruningPolicy()
    run_mw = list(run_middleware or [])
    step_mw = list(step_middleware or [])
    model_mw = list(model_middleware or [])
    tool_mw = list(tool_middleware or [])
    human_in_the_loop_mw = list(human_in_the_loop_middleware or [])
    sinks = list(event_sinks or [])

    state = _build_run_state_from_context(run_context)
    history: list[Message] = list(messages) if messages else []
    state.messages = history

    stream = run_with_run_middleware(
        run_mw,
        run_context,
        state,
        lambda: _run_agent_loop(
            model,
            registry,
            input_text,
            history=history,
            context=run_context,
            state=state,
            settings=settings,
            max_steps=max_steps,
            parallel_tools=runtime_parallel_tools,
            tool_choice=tool_choice,
            parallel_tool_calls=provider_parallel_tool_calls,
            strict=strict,
            retention_policy=policy,
            step_middleware=step_mw,
            model_middleware=model_mw,
            tool_middleware=tool_mw,
            human_in_the_loop_middleware=human_in_the_loop_mw,
            event_sinks=sinks,
            stream_model=False,
            enable_tool_usage=enable_tool_usage,
            stop_after_step=False,
            timeout_seconds=timeout_seconds,
            cancel_check=cancel_check,
            max_consecutive_failures=max_consecutive_failures,
            tool_error_handling=tool_error_handling,
            retry_policy=retry_policy,
            policy_engine=policy_engine,
            response_schema=response_schema,
            human_in_the_loop_policy=human_in_the_loop_policy,
            human_in_the_loop_decision=None,
        ),
    )
    try:
        return _consume_generator(stream)
    except PolicyViolationError as exc:
        if state.termination is None:
            state.termination = "policy_blocked"
            emit_event(
                state,
                run_context,
                sinks,
                "policy_check_blocked",
                step_id=exc.metadata.get("step_id") if isinstance(exc.metadata, dict) else None,
                policy_name=exc.policy_name,
                scope=exc.scope,
                reason=exc.reason or "policy_blocked",
                metadata=exc.metadata,
            )
            emit_event(state, run_context, sinks, "run_terminated", reason="policy_blocked")
        if run_context.trace_storage is not None:
            run_context.trace_storage.finalize_trace(context=run_context, state=state)
        return AgentResult(
            content=None,
            messages=history,
            steps=len(state.steps),
            termination="policy_blocked",
            state=state,
        )
    except Exception:  # noqa: BLE001
        if state.termination is None:
            state.termination = "error"
            emit_event(state, run_context, sinks, "run_terminated", reason="run_error")
        if run_context.trace_storage is not None:
            run_context.trace_storage.finalize_trace(context=run_context, state=state)
        raise


def invoke_agent(
    model: Model,
    tools: Iterable[Tool],
    input_text: str,
    *,
    messages: Optional[Iterable[Message]] = None,
    context: Optional[RunContext] = None,
    settings: Optional[ModelSettings] = None,
    max_steps: int = 10,
    timeout_seconds: float | None = None,
    cancel_check: Callable[[], bool] | None = None,
    max_consecutive_failures: int | None = None,
    tool_error_handling: str = "continue",
    enable_tool_usage: bool = True,
    tool_execution: str = "sequential",
    tool_choice: str | dict | None = None,
    parallel_tool_calls: bool | None = None,
    strict: bool | None = None,
    retention_policy: ToolCallPruningPolicy | None = None,
    run_middleware: Optional[Iterable[RunMiddleware]] = None,
    step_middleware: Optional[Iterable[StepMiddleware]] = None,
    model_middleware: Optional[Iterable[ModelMiddleware]] = None,
    tool_middleware: Optional[Iterable[ToolMiddleware]] = None,
    human_in_the_loop_middleware: Optional[Iterable[HumanInTheLoopMiddleware]] = None,
    event_sinks: Optional[Iterable[EventSink]] = None,
    retry_policy: RetryPolicy | None = None,
    response_schema: type | dict | None = None,
    human_in_the_loop_policy: HumanInTheLoopPolicy | None = None,
    policy_engine: PolicyEngine | None = None,
    redaction_pipeline: RedactionPipeline | None = None,
    trace_storage: TraceStorage | None = None,
    trace_callback_handlers: Iterable[TraceCallbackHandler] | None = None,
    trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
) -> AgentResult:
    return run_agent(
        model,
        tools,
        input_text,
        messages=messages,
        context=context,
        settings=settings,
        max_steps=max_steps,
        timeout_seconds=timeout_seconds,
        cancel_check=cancel_check,
        max_consecutive_failures=max_consecutive_failures,
        tool_error_handling=tool_error_handling,
        enable_tool_usage=enable_tool_usage,
        tool_execution=tool_execution,
        tool_choice=tool_choice,
        parallel_tool_calls=parallel_tool_calls,
        strict=strict,
        retention_policy=retention_policy,
        run_middleware=run_middleware,
        step_middleware=step_middleware,
        model_middleware=model_middleware,
        tool_middleware=tool_middleware,
        human_in_the_loop_middleware=human_in_the_loop_middleware,
        event_sinks=event_sinks,
        retry_policy=retry_policy,
        response_schema=response_schema,
        human_in_the_loop_policy=human_in_the_loop_policy,
        policy_engine=policy_engine,
        redaction_pipeline=redaction_pipeline,
        trace_storage=trace_storage,
        trace_callback_handlers=trace_callback_handlers,
        trace_callback_failure_mode=trace_callback_failure_mode,
    )


def run_agent_stream(
    model: Model,
    tools: Iterable[Tool],
    input_text: str,
    *,
    messages: Optional[Iterable[Message]] = None,
    context: Optional[RunContext] = None,
    settings: Optional[ModelSettings] = None,
    max_steps: int = 10,
    timeout_seconds: float | None = None,
    cancel_check: Callable[[], bool] | None = None,
    max_consecutive_failures: int | None = None,
    tool_error_handling: str = "continue",
    enable_tool_usage: bool = True,
    tool_execution: str = "sequential",
    tool_choice: str | dict | None = None,
    parallel_tool_calls: bool | None = None,
    strict: bool | None = None,
    retention_policy: ToolCallPruningPolicy | None = None,
    run_middleware: Optional[Iterable[RunMiddleware]] = None,
    step_middleware: Optional[Iterable[StepMiddleware]] = None,
    model_middleware: Optional[Iterable[ModelMiddleware]] = None,
    tool_middleware: Optional[Iterable[ToolMiddleware]] = None,
    human_in_the_loop_middleware: Optional[Iterable[HumanInTheLoopMiddleware]] = None,
    event_sinks: Optional[Iterable[EventSink]] = None,
    stream_model: bool = False,
    retry_policy: RetryPolicy | None = None,
    response_schema: type | dict | None = None,
    human_in_the_loop_policy: HumanInTheLoopPolicy | None = None,
    policy_engine: PolicyEngine | None = None,
    redaction_pipeline: RedactionPipeline | None = None,
    trace_storage: TraceStorage | None = None,
    trace_callback_handlers: Iterable[TraceCallbackHandler] | None = None,
    trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
) -> Iterator[AgentStreamEvent]:
    runtime_parallel_tools, provider_parallel_tool_calls = resolve_tool_execution(
        tool_execution=tool_execution,
        parallel_tool_calls=parallel_tool_calls,
    )
    run_context = _configure_run_context(
        context or RunContext(run_id=str(uuid4())),
        policy_engine=policy_engine,
        redaction_pipeline=redaction_pipeline,
        trace_storage=trace_storage,
        trace_callback_handlers=trace_callback_handlers,
        trace_callback_failure_mode=trace_callback_failure_mode,
    )
    policy_engine = run_context.policy_engine
    registry = _build_tool_registry(tools)
    policy = retention_policy or ToolCallPruningPolicy()
    run_mw = list(run_middleware or [])
    step_mw = list(step_middleware or [])
    model_mw = list(model_middleware or [])
    tool_mw = list(tool_middleware or [])
    human_in_the_loop_mw = list(human_in_the_loop_middleware or [])
    sinks = list(event_sinks or [])

    state = _build_run_state_from_context(run_context)
    history: list[Message] = list(messages) if messages else []
    state.messages = history

    stream = run_with_run_middleware(
        run_mw,
        run_context,
        state,
        lambda: _run_agent_loop(
            model,
            registry,
            input_text,
            history=history,
            context=run_context,
            state=state,
            settings=settings,
            max_steps=max_steps,
            parallel_tools=runtime_parallel_tools,
            tool_choice=tool_choice,
            parallel_tool_calls=provider_parallel_tool_calls,
            strict=strict,
            retention_policy=policy,
            step_middleware=step_mw,
            model_middleware=model_mw,
            tool_middleware=tool_mw,
            human_in_the_loop_middleware=human_in_the_loop_mw,
            event_sinks=sinks,
            stream_model=stream_model,
            enable_tool_usage=enable_tool_usage,
            stop_after_step=False,
            timeout_seconds=timeout_seconds,
            cancel_check=cancel_check,
            max_consecutive_failures=max_consecutive_failures,
            tool_error_handling=tool_error_handling,
            retry_policy=retry_policy,
            policy_engine=policy_engine,
            response_schema=response_schema,
            human_in_the_loop_policy=human_in_the_loop_policy,
            human_in_the_loop_decision=None,
        ),
    )
    return _iter_agent_stream(stream)


def stream_agent(
    model: Model,
    tools: Iterable[Tool],
    input_text: str,
    *,
    messages: Optional[Iterable[Message]] = None,
    context: Optional[RunContext] = None,
    settings: Optional[ModelSettings] = None,
    max_steps: int = 10,
    timeout_seconds: float | None = None,
    cancel_check: Callable[[], bool] | None = None,
    max_consecutive_failures: int | None = None,
    tool_error_handling: str = "continue",
    enable_tool_usage: bool = True,
    tool_execution: str = "sequential",
    tool_choice: str | dict | None = None,
    parallel_tool_calls: bool | None = None,
    strict: bool | None = None,
    retention_policy: ToolCallPruningPolicy | None = None,
    run_middleware: Optional[Iterable[RunMiddleware]] = None,
    step_middleware: Optional[Iterable[StepMiddleware]] = None,
    model_middleware: Optional[Iterable[ModelMiddleware]] = None,
    tool_middleware: Optional[Iterable[ToolMiddleware]] = None,
    human_in_the_loop_middleware: Optional[Iterable[HumanInTheLoopMiddleware]] = None,
    event_sinks: Optional[Iterable[EventSink]] = None,
    stream_model: bool = False,
    retry_policy: RetryPolicy | None = None,
    response_schema: type | dict | None = None,
    human_in_the_loop_policy: HumanInTheLoopPolicy | None = None,
    policy_engine: PolicyEngine | None = None,
    redaction_pipeline: RedactionPipeline | None = None,
    trace_storage: TraceStorage | None = None,
    trace_callback_handlers: Iterable[TraceCallbackHandler] | None = None,
    trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
) -> Iterator[AgentStreamEvent]:
    return run_agent_stream(
        model,
        tools,
        input_text,
        messages=messages,
        context=context,
        settings=settings,
        max_steps=max_steps,
        timeout_seconds=timeout_seconds,
        cancel_check=cancel_check,
        max_consecutive_failures=max_consecutive_failures,
        tool_error_handling=tool_error_handling,
        enable_tool_usage=enable_tool_usage,
        tool_execution=tool_execution,
        tool_choice=tool_choice,
        parallel_tool_calls=parallel_tool_calls,
        strict=strict,
        retention_policy=retention_policy,
        run_middleware=run_middleware,
        step_middleware=step_middleware,
        model_middleware=model_middleware,
        tool_middleware=tool_middleware,
        human_in_the_loop_middleware=human_in_the_loop_middleware,
        event_sinks=event_sinks,
        stream_model=stream_model,
        retry_policy=retry_policy,
        response_schema=response_schema,
        human_in_the_loop_policy=human_in_the_loop_policy,
        policy_engine=policy_engine,
        redaction_pipeline=redaction_pipeline,
        trace_storage=trace_storage,
        trace_callback_handlers=trace_callback_handlers,
        trace_callback_failure_mode=trace_callback_failure_mode,
    )


def checkpoint_agent(
    model: Model,
    tools: Iterable[Tool],
    input_text: str,
    *,
    messages: Optional[Iterable[Message]] = None,
    context: Optional[RunContext] = None,
    settings: Optional[ModelSettings] = None,
    max_steps: int = 10,
    timeout_seconds: float | None = None,
    cancel_check: Callable[[], bool] | None = None,
    max_consecutive_failures: int | None = None,
    tool_error_handling: str = "continue",
    enable_tool_usage: bool = True,
    tool_execution: str = "sequential",
    tool_choice: str | dict | None = None,
    parallel_tool_calls: bool | None = None,
    strict: bool | None = None,
    retention_policy: ToolCallPruningPolicy | None = None,
    run_middleware: Optional[Iterable[RunMiddleware]] = None,
    step_middleware: Optional[Iterable[StepMiddleware]] = None,
    model_middleware: Optional[Iterable[ModelMiddleware]] = None,
    tool_middleware: Optional[Iterable[ToolMiddleware]] = None,
    human_in_the_loop_middleware: Optional[Iterable[HumanInTheLoopMiddleware]] = None,
    event_sinks: Optional[Iterable[EventSink]] = None,
    retry_policy: RetryPolicy | None = None,
    response_schema: type | dict | None = None,
    human_in_the_loop_policy: HumanInTheLoopPolicy | None = None,
    policy_engine: PolicyEngine | None = None,
    redaction_pipeline: RedactionPipeline | None = None,
    trace_storage: TraceStorage | None = None,
    trace_callback_handlers: Iterable[TraceCallbackHandler] | None = None,
    trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
) -> AgentResult:
    runtime_parallel_tools, provider_parallel_tool_calls = resolve_tool_execution(
        tool_execution=tool_execution,
        parallel_tool_calls=parallel_tool_calls,
    )
    run_context = _configure_run_context(
        context or RunContext(run_id=str(uuid4())),
        policy_engine=policy_engine,
        redaction_pipeline=redaction_pipeline,
        trace_storage=trace_storage,
        trace_callback_handlers=trace_callback_handlers,
        trace_callback_failure_mode=trace_callback_failure_mode,
    )
    policy_engine = run_context.policy_engine
    registry = _build_tool_registry(tools)
    policy = retention_policy or ToolCallPruningPolicy()
    run_mw = list(run_middleware or [])
    step_mw = list(step_middleware or [])
    model_mw = list(model_middleware or [])
    tool_mw = list(tool_middleware or [])
    human_in_the_loop_mw = list(human_in_the_loop_middleware or [])
    sinks = list(event_sinks or [])

    state = _build_run_state_from_context(run_context)
    history: list[Message] = list(messages) if messages else []
    state.messages = history

    stream = run_with_run_middleware(
        run_mw,
        run_context,
        state,
        lambda: _run_agent_loop(
            model,
            registry,
            input_text,
            history=history,
            context=run_context,
            state=state,
            settings=settings,
            max_steps=max_steps,
            parallel_tools=runtime_parallel_tools,
            tool_choice=tool_choice,
            parallel_tool_calls=provider_parallel_tool_calls,
            strict=strict,
            retention_policy=policy,
            step_middleware=step_mw,
            model_middleware=model_mw,
            tool_middleware=tool_mw,
            human_in_the_loop_middleware=human_in_the_loop_mw,
            event_sinks=sinks,
            stream_model=False,
            enable_tool_usage=enable_tool_usage,
            stop_after_step=True,
            timeout_seconds=timeout_seconds,
            cancel_check=cancel_check,
            max_consecutive_failures=max_consecutive_failures,
            tool_error_handling=tool_error_handling,
            retry_policy=retry_policy,
            policy_engine=policy_engine,
            response_schema=response_schema,
            human_in_the_loop_policy=human_in_the_loop_policy,
            human_in_the_loop_decision=None,
        ),
    )
    try:
        return _consume_generator(stream)
    except PolicyViolationError as exc:
        if state.termination is None:
            state.termination = "policy_blocked"
            emit_event(
                state,
                run_context,
                sinks,
                "policy_check_blocked",
                step_id=exc.metadata.get("step_id") if isinstance(exc.metadata, dict) else None,
                policy_name=exc.policy_name,
                scope=exc.scope,
                reason=exc.reason or "policy_blocked",
                metadata=exc.metadata,
            )
            emit_event(state, run_context, sinks, "run_terminated", reason="policy_blocked")
        if run_context.trace_storage is not None:
            run_context.trace_storage.finalize_trace(context=run_context, state=state)
        return AgentResult(
            content=None,
            messages=history,
            steps=len(state.steps),
            termination="policy_blocked",
            state=state,
        )
    except Exception:  # noqa: BLE001
        if state.termination is None:
            state.termination = "error"
            emit_event(state, run_context, sinks, "run_terminated", reason="run_error")
        if run_context.trace_storage is not None:
            run_context.trace_storage.finalize_trace(context=run_context, state=state)
        raise


def checkpoint_agent_stream(
    model: Model,
    tools: Iterable[Tool],
    input_text: str,
    *,
    messages: Optional[Iterable[Message]] = None,
    context: Optional[RunContext] = None,
    settings: Optional[ModelSettings] = None,
    max_steps: int = 10,
    timeout_seconds: float | None = None,
    cancel_check: Callable[[], bool] | None = None,
    max_consecutive_failures: int | None = None,
    tool_error_handling: str = "continue",
    enable_tool_usage: bool = True,
    tool_execution: str = "sequential",
    tool_choice: str | dict | None = None,
    parallel_tool_calls: bool | None = None,
    strict: bool | None = None,
    retention_policy: ToolCallPruningPolicy | None = None,
    run_middleware: Optional[Iterable[RunMiddleware]] = None,
    step_middleware: Optional[Iterable[StepMiddleware]] = None,
    model_middleware: Optional[Iterable[ModelMiddleware]] = None,
    tool_middleware: Optional[Iterable[ToolMiddleware]] = None,
    human_in_the_loop_middleware: Optional[Iterable[HumanInTheLoopMiddleware]] = None,
    event_sinks: Optional[Iterable[EventSink]] = None,
    stream_model: bool = False,
    retry_policy: RetryPolicy | None = None,
    response_schema: type | dict | None = None,
    human_in_the_loop_policy: HumanInTheLoopPolicy | None = None,
    policy_engine: PolicyEngine | None = None,
    redaction_pipeline: RedactionPipeline | None = None,
    trace_storage: TraceStorage | None = None,
    trace_callback_handlers: Iterable[TraceCallbackHandler] | None = None,
    trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
) -> Iterator[AgentStreamEvent]:
    runtime_parallel_tools, provider_parallel_tool_calls = resolve_tool_execution(
        tool_execution=tool_execution,
        parallel_tool_calls=parallel_tool_calls,
    )
    run_context = _configure_run_context(
        context or RunContext(run_id=str(uuid4())),
        policy_engine=policy_engine,
        redaction_pipeline=redaction_pipeline,
        trace_storage=trace_storage,
        trace_callback_handlers=trace_callback_handlers,
        trace_callback_failure_mode=trace_callback_failure_mode,
    )
    policy_engine = run_context.policy_engine
    registry = _build_tool_registry(tools)
    policy = retention_policy or ToolCallPruningPolicy()
    run_mw = list(run_middleware or [])
    step_mw = list(step_middleware or [])
    model_mw = list(model_middleware or [])
    tool_mw = list(tool_middleware or [])
    human_in_the_loop_mw = list(human_in_the_loop_middleware or [])
    sinks = list(event_sinks or [])

    state = _build_run_state_from_context(run_context)
    history: list[Message] = list(messages) if messages else []
    state.messages = history

    stream = run_with_run_middleware(
        run_mw,
        run_context,
        state,
        lambda: _run_agent_loop(
            model,
            registry,
            input_text,
            history=history,
            context=run_context,
            state=state,
            settings=settings,
            max_steps=max_steps,
            parallel_tools=runtime_parallel_tools,
            tool_choice=tool_choice,
            parallel_tool_calls=provider_parallel_tool_calls,
            strict=strict,
            retention_policy=policy,
            step_middleware=step_mw,
            model_middleware=model_mw,
            tool_middleware=tool_mw,
            human_in_the_loop_middleware=human_in_the_loop_mw,
            event_sinks=sinks,
            stream_model=stream_model,
            enable_tool_usage=enable_tool_usage,
            stop_after_step=True,
            timeout_seconds=timeout_seconds,
            cancel_check=cancel_check,
            max_consecutive_failures=max_consecutive_failures,
            tool_error_handling=tool_error_handling,
            retry_policy=retry_policy,
            policy_engine=policy_engine,
            response_schema=response_schema,
            human_in_the_loop_policy=human_in_the_loop_policy,
            human_in_the_loop_decision=None,
        ),
    )
    return _iter_agent_stream(stream)


def resume_agent(
    model: Model,
    tools: Iterable[Tool],
    input_text: str,
    *,
    state: RunState,
    resume_step_id: str | None = None,
    context: Optional[RunContext] = None,
    settings: Optional[ModelSettings] = None,
    max_steps: int = 10,
    timeout_seconds: float | None = None,
    cancel_check: Callable[[], bool] | None = None,
    max_consecutive_failures: int | None = None,
    tool_error_handling: str = "continue",
    enable_tool_usage: bool = True,
    tool_execution: str = "sequential",
    tool_choice: str | dict | None = None,
    parallel_tool_calls: bool | None = None,
    strict: bool | None = None,
    retention_policy: ToolCallPruningPolicy | None = None,
    run_middleware: Optional[Iterable[RunMiddleware]] = None,
    step_middleware: Optional[Iterable[StepMiddleware]] = None,
    model_middleware: Optional[Iterable[ModelMiddleware]] = None,
    tool_middleware: Optional[Iterable[ToolMiddleware]] = None,
    human_in_the_loop_middleware: Optional[Iterable[HumanInTheLoopMiddleware]] = None,
    event_sinks: Optional[Iterable[EventSink]] = None,
    retry_policy: RetryPolicy | None = None,
    response_schema: type | dict | None = None,
    human_in_the_loop_policy: HumanInTheLoopPolicy | None = None,
    human_in_the_loop_decision: HumanInTheLoopDecision | None = None,
    policy_engine: PolicyEngine | None = None,
    redaction_pipeline: RedactionPipeline | None = None,
    trace_storage: TraceStorage | None = None,
    trace_callback_handlers: Iterable[TraceCallbackHandler] | None = None,
    trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
) -> AgentResult:
    runtime_parallel_tools, provider_parallel_tool_calls = resolve_tool_execution(
        tool_execution=tool_execution,
        parallel_tool_calls=parallel_tool_calls,
    )
    checkpoint_record = state.checkpoint
    run_context = _configure_run_context(
        context
        or RunContext(
            run_id=state.run_id,
            trace_id=state.trace_id,
            correlation_id=state.correlation_id,
            project_id=state.project_id,
            tenant_id=state.tenant_id,
            metadata=dict(state.metadata),
        ),
        policy_engine=policy_engine,
        redaction_pipeline=redaction_pipeline,
        trace_storage=trace_storage,
        trace_callback_handlers=trace_callback_handlers,
        trace_callback_failure_mode=trace_callback_failure_mode,
    )
    policy_engine = run_context.policy_engine
    registry = _build_tool_registry(tools)
    policy = retention_policy or ToolCallPruningPolicy()
    run_mw = list(run_middleware or [])
    step_mw = list(step_middleware or [])
    model_mw = list(model_middleware or [])
    tool_mw = list(tool_middleware or [])
    human_in_the_loop_mw = list(human_in_the_loop_middleware or [])
    sinks = list(event_sinks or [])

    _sync_run_state_identity_from_context(state, run_context)
    history = _prepare_state_for_resume(state, resume_step_id)
    resumed_at = time()
    emit_event(
        state,
        run_context,
        sinks,
        "run_resumed",
        resume_step_id=resume_step_id or (checkpoint_record.step_id if checkpoint_record is not None else None),
        resumed_at=resumed_at,
    )

    stream = run_with_run_middleware(
        run_mw,
        run_context,
        state,
        lambda: _run_agent_loop(
            model,
            registry,
            input_text,
            history=history,
            context=run_context,
            state=state,
            settings=settings,
            max_steps=max_steps,
            parallel_tools=runtime_parallel_tools,
            tool_choice=tool_choice,
            parallel_tool_calls=provider_parallel_tool_calls,
            strict=strict,
            retention_policy=policy,
            step_middleware=step_mw,
            model_middleware=model_mw,
            tool_middleware=tool_mw,
            human_in_the_loop_middleware=human_in_the_loop_mw,
            event_sinks=sinks,
            stream_model=False,
            enable_tool_usage=enable_tool_usage,
            stop_after_step=False,
            timeout_seconds=timeout_seconds,
            cancel_check=cancel_check,
            max_consecutive_failures=max_consecutive_failures,
            tool_error_handling=tool_error_handling,
            retry_policy=retry_policy,
            policy_engine=policy_engine,
            response_schema=response_schema,
            human_in_the_loop_policy=human_in_the_loop_policy,
            human_in_the_loop_decision=human_in_the_loop_decision,
            append_input_message=human_in_the_loop_decision is None,
        ),
    )
    try:
        return _consume_generator(stream)
    except PolicyViolationError as exc:
        if state.termination is None:
            state.termination = "policy_blocked"
            emit_event(
                state,
                run_context,
                sinks,
                "policy_check_blocked",
                step_id=exc.metadata.get("step_id") if isinstance(exc.metadata, dict) else None,
                policy_name=exc.policy_name,
                scope=exc.scope,
                reason=exc.reason or "policy_blocked",
                metadata=exc.metadata,
            )
            emit_event(state, run_context, sinks, "run_terminated", reason="policy_blocked")
        if run_context.trace_storage is not None:
            run_context.trace_storage.finalize_trace(context=run_context, state=state)
        return AgentResult(
            content=None,
            messages=history,
            steps=len(state.steps),
            termination="policy_blocked",
            state=state,
        )
    except Exception:  # noqa: BLE001
        if state.termination is None:
            state.termination = "error"
            emit_event(state, run_context, sinks, "run_terminated", reason="run_error")
        if run_context.trace_storage is not None:
            run_context.trace_storage.finalize_trace(context=run_context, state=state)
        raise


def resume_agent_stream(
    model: Model,
    tools: Iterable[Tool],
    input_text: str,
    *,
    state: RunState,
    resume_step_id: str | None = None,
    context: Optional[RunContext] = None,
    settings: Optional[ModelSettings] = None,
    max_steps: int = 10,
    timeout_seconds: float | None = None,
    cancel_check: Callable[[], bool] | None = None,
    max_consecutive_failures: int | None = None,
    tool_error_handling: str = "continue",
    enable_tool_usage: bool = True,
    tool_execution: str = "sequential",
    tool_choice: str | dict | None = None,
    parallel_tool_calls: bool | None = None,
    strict: bool | None = None,
    retention_policy: ToolCallPruningPolicy | None = None,
    run_middleware: Optional[Iterable[RunMiddleware]] = None,
    step_middleware: Optional[Iterable[StepMiddleware]] = None,
    model_middleware: Optional[Iterable[ModelMiddleware]] = None,
    tool_middleware: Optional[Iterable[ToolMiddleware]] = None,
    human_in_the_loop_middleware: Optional[Iterable[HumanInTheLoopMiddleware]] = None,
    event_sinks: Optional[Iterable[EventSink]] = None,
    stream_model: bool = False,
    retry_policy: RetryPolicy | None = None,
    response_schema: type | dict | None = None,
    human_in_the_loop_policy: HumanInTheLoopPolicy | None = None,
    human_in_the_loop_decision: HumanInTheLoopDecision | None = None,
    policy_engine: PolicyEngine | None = None,
    redaction_pipeline: RedactionPipeline | None = None,
    trace_storage: TraceStorage | None = None,
    trace_callback_handlers: Iterable[TraceCallbackHandler] | None = None,
    trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
) -> Iterator[AgentStreamEvent]:
    runtime_parallel_tools, provider_parallel_tool_calls = resolve_tool_execution(
        tool_execution=tool_execution,
        parallel_tool_calls=parallel_tool_calls,
    )
    checkpoint_record = state.checkpoint
    run_context = _configure_run_context(
        context
        or RunContext(
            run_id=state.run_id,
            trace_id=state.trace_id,
            correlation_id=state.correlation_id,
            project_id=state.project_id,
            tenant_id=state.tenant_id,
            metadata=dict(state.metadata),
        ),
        policy_engine=policy_engine,
        redaction_pipeline=redaction_pipeline,
        trace_storage=trace_storage,
        trace_callback_handlers=trace_callback_handlers,
        trace_callback_failure_mode=trace_callback_failure_mode,
    )
    policy_engine = run_context.policy_engine
    registry = _build_tool_registry(tools)
    policy = retention_policy or ToolCallPruningPolicy()
    run_mw = list(run_middleware or [])
    step_mw = list(step_middleware or [])
    model_mw = list(model_middleware or [])
    tool_mw = list(tool_middleware or [])
    human_in_the_loop_mw = list(human_in_the_loop_middleware or [])
    sinks = list(event_sinks or [])

    _sync_run_state_identity_from_context(state, run_context)
    history = _prepare_state_for_resume(state, resume_step_id)
    resumed_at = time()
    emit_event(
        state,
        run_context,
        sinks,
        "run_resumed",
        resume_step_id=resume_step_id or (checkpoint_record.step_id if checkpoint_record is not None else None),
        resumed_at=resumed_at,
    )

    stream = run_with_run_middleware(
        run_mw,
        run_context,
        state,
        lambda: _run_agent_loop(
            model,
            registry,
            input_text,
            history=history,
            context=run_context,
            state=state,
            settings=settings,
            max_steps=max_steps,
            parallel_tools=runtime_parallel_tools,
            tool_choice=tool_choice,
            parallel_tool_calls=provider_parallel_tool_calls,
            strict=strict,
            retention_policy=policy,
            step_middleware=step_mw,
            model_middleware=model_mw,
            tool_middleware=tool_mw,
            human_in_the_loop_middleware=human_in_the_loop_mw,
            event_sinks=sinks,
            stream_model=stream_model,
            enable_tool_usage=enable_tool_usage,
            stop_after_step=False,
            timeout_seconds=timeout_seconds,
            cancel_check=cancel_check,
            max_consecutive_failures=max_consecutive_failures,
            tool_error_handling=tool_error_handling,
            retry_policy=retry_policy,
            policy_engine=policy_engine,
            response_schema=response_schema,
            human_in_the_loop_policy=human_in_the_loop_policy,
            human_in_the_loop_decision=human_in_the_loop_decision,
            append_input_message=human_in_the_loop_decision is None,
        ),
    )
    return _iter_agent_stream(stream)
