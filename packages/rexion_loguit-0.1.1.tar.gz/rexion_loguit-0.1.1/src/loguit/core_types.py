from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Sequence, TypedDict, TYPE_CHECKING

if TYPE_CHECKING:
    from loguit.callbacks import TraceCallbackManager
    from loguit.logging.storage import TraceStorage
    from loguit.policies import PolicyEngine, RedactionPipeline


class Role(str, Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


@dataclass(frozen=True)
class Message:
    role: Role
    message_content: str
    name: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ToolCall:
    name: str
    args: Dict[str, Any]
    call_id: Optional[str] = None


@dataclass(frozen=True)
class ModelResult:
    content: Optional[str] = None
    tool_calls: List[ToolCall] = field(default_factory=list)
    structured_output: Any = None
    raw: Any = None


@dataclass(frozen=True)
class ToolResult:
    output: Any = None
    error: Optional[str] = None
    raw: Any = None


@dataclass(frozen=True)
class ToolStreamEvent:
    type: str
    delta: Optional[str] = None
    data: Dict[str, Any] = field(default_factory=dict)
    raw: Any = None


@dataclass
class RunContext:
    run_id: str
    trace_id: Optional[str] = None
    correlation_id: Optional[str] = None
    project_id: Optional[str] = None
    tenant_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    policy_engine: Optional["PolicyEngine"] = None
    redaction_pipeline: Optional["RedactionPipeline"] = None
    trace_storage: Optional["TraceStorage"] = None
    trace_callback_manager: Optional["TraceCallbackManager"] = None

    def __post_init__(self) -> None:
        if self.trace_id is None:
            self.trace_id = self.run_id


@dataclass
class ModelSettings:
    temperature: Optional[float] = None
    max_output_tokens: Optional[int] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ModelStreamEvent:
    type: str
    delta: Optional[str] = None
    raw: Any = None


@dataclass(frozen=True)
class AgentStreamEvent:
    type: str
    delta: Optional[str] = None
    step_id: Optional[str] = None
    data: Dict[str, Any] = field(default_factory=dict)
    raw: Any = None


class ModelConfig(TypedDict, total=False):
    model: str
    model_provider: str
    tool_calling: str
    settings: Dict[str, Any]
    client: Dict[str, Any]
    extra: Dict[str, Any]


def normalize_messages(messages: Sequence[Message]) -> List[Message]:
    normalized_messages: List[Message] = []
    for message_candidate in messages:
        if not isinstance(message_candidate, Message):
            raise TypeError("All messages must be Message instances")
        if not isinstance(message_candidate.message_content, str):
            raise TypeError("Message content must be a string")
        normalized_messages.append(message_candidate)
    return normalized_messages


def validate_model_result(model_result: ModelResult) -> None:
    if model_result.content is None and model_result.structured_output is None and not model_result.tool_calls:
        raise ValueError("ModelResult must include content or tool_calls")
