from __future__ import annotations

from time import time
from typing import Iterable, Optional, Sequence
from uuid import uuid4

from ..callbacks import (
    TraceCallbackFailureMode,
    TraceCallbackHandler,
    dispatch_recorded_event_to_trace_callback_manager,
    resolve_trace_callback_manager,
)
from ..core_types import Message, ModelResult, ModelSettings, RunContext, normalize_messages, validate_model_result
from ..middleware import ModelMiddleware, ModelMiddlewareCall, run_model_with_middleware
from ..model import Model
from ..retry import RetryPolicy, run_with_retry
from ..state import ErrorRecord, RunState
from ..structured_output import (
    StructuredOutputValidationError,
    build_native_structured_output_payload,
    normalize_structured_output_schema,
    validate_structured_output_value,
)
from ..tools import Tool


def _apply_native_structured_output_settings(
    model: Model,
    settings: ModelSettings | None,
    *,
    response_schema: type | dict[str, object] | None,
) -> ModelSettings | None:
    if response_schema is None:
        return settings
    active_settings = settings or ModelSettings()
    copied_extra_settings = dict(active_settings.extra)
    provider_module_name = model.__class__.__module__
    native_payload = build_native_structured_output_payload(response_schema)
    if provider_module_name.endswith("openai_chat"):
        copied_extra_settings["response_format"] = native_payload
    elif provider_module_name.endswith("openai_responses"):
        copied_extra_settings["text"] = {"format": native_payload["json_schema"] | {"type": "json_schema"}}
    return ModelSettings(
        temperature=active_settings.temperature,
        max_output_tokens=active_settings.max_output_tokens,
        extra=copied_extra_settings,
    )


def _resolve_structured_model_result(
    model_result: ModelResult,
    *,
    response_schema: type | dict[str, object] | None,
) -> ModelResult:
    if response_schema is None or model_result.tool_calls:
        return model_result
    raw_structured_output = model_result.structured_output if model_result.structured_output is not None else model_result.content
    if raw_structured_output is None:
        raise StructuredOutputValidationError("Structured output requires a final model response")
    validated_structured_output = validate_structured_output_value(
        raw_structured_output,
        response_schema=response_schema,
    )
    return ModelResult(
        content=model_result.content,
        tool_calls=model_result.tool_calls,
        structured_output=validated_structured_output,
        raw=model_result.raw,
    )


def call_model(
    model: Model,
    messages: Sequence[Message],
    *,
    context: Optional[RunContext] = None,
    settings: Optional[ModelSettings] = None,
    tools: Optional[Iterable[Tool]] = None,
    tool_choice: str | dict | None = None,
    parallel_tool_calls: bool | None = None,
    strict: bool | None = None,
    retry_policy: RetryPolicy | None = None,
    response_schema: type | dict[str, object] | None = None,
    model_middleware: Iterable[ModelMiddleware] | None = None,
    trace_callback_handlers: Iterable[TraceCallbackHandler] | None = None,
    trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
) -> ModelResult:
    run_context = context or RunContext(run_id=str(uuid4()))
    run_context.trace_callback_manager = resolve_trace_callback_manager(
        run_context,
        trace_callback_handlers,
        trace_callback_failure_mode,
    )
    normalized_messages = normalize_messages(messages)
    state = RunState(
        run_id=run_context.run_id,
        trace_id=run_context.trace_id,
        correlation_id=run_context.correlation_id,
        project_id=run_context.project_id,
        tenant_id=run_context.tenant_id,
        metadata=dict(run_context.metadata),
    )
    model_step = state.start_step("model_call", model.name, message_index=len(normalized_messages))
    started_event = state.record_event(
        "model_call_started",
        step_id=model_step.step_id,
        model=model.name,
        step_type=model_step.step_type,
        name=model_step.name,
        status=model_step.status,
        message_index=model_step.message_index,
        started_at=model_step.started_at,
    )
    dispatch_recorded_event_to_trace_callback_manager(started_event, context=run_context, state=state)
    normalized_response_schema = normalize_structured_output_schema(response_schema)
    structured_settings = _apply_native_structured_output_settings(
        model,
        settings,
        response_schema=normalized_response_schema,
    )
    model_call = ModelMiddlewareCall(
        model=model,
        messages=list(normalized_messages),
        context=run_context,
        settings=structured_settings,
        tools=tools,
        tool_choice=tool_choice,
        parallel_tool_calls=parallel_tool_calls,
        strict=strict,
        response_schema=normalized_response_schema,
    )

    def _call_model() -> ModelResult:
        return run_model_with_middleware(
            model_middleware or [],
            model_call,
            lambda: model_call.model.generate(
                model_call.messages,
                model_call.context,
                model_call.settings,
                tools=model_call.tools,
                tool_choice=model_call.tool_choice,
                parallel_tool_calls=model_call.parallel_tool_calls,
                strict=model_call.strict,
            ),
        )

    def _emit_retry(event_type: str, details: dict[str, object]) -> None:
        retry_event = state.record_event(
            event_type,
            step_id=model_step.step_id,
            step_type=model_step.step_type,
            name=model_step.name,
            **details,
        )
        dispatch_recorded_event_to_trace_callback_manager(retry_event, context=run_context, state=state)

    try:
        model_result = (
            _call_model()
            if retry_policy is None
            else run_with_retry(_call_model, retry_policy=retry_policy, on_retry_event=_emit_retry)
        )
        model_result = _resolve_structured_model_result(
            model_result,
            response_schema=normalized_response_schema,
        )
        validate_model_result(model_result)
    except Exception as exc:  # noqa: BLE001
        state.end_step(model_step, status="error", error=str(exc))
        state.errors.append(ErrorRecord(error_type="model_error", message=str(exc), step_id=model_step.step_id))
        failed_event = state.record_event(
            "model_call_failed",
            step_id=model_step.step_id,
            model=model.name,
            error=str(exc),
            step_type=model_step.step_type,
            name=model_step.name,
            status=model_step.status,
            message_index=model_step.message_index,
            started_at=model_step.started_at,
            ended_at=model_step.ended_at,
            duration_ms=max(0.0, (model_step.ended_at or time()) - model_step.started_at) * 1000.0,
        )
        dispatch_recorded_event_to_trace_callback_manager(failed_event, context=run_context, state=state)
        raise
    state.end_step(model_step, status="completed")
    succeeded_event = state.record_event(
        "model_call_succeeded",
        step_id=model_step.step_id,
        model=model.name,
        step_type=model_step.step_type,
        name=model_step.name,
        status=model_step.status,
        message_index=model_step.message_index,
        started_at=model_step.started_at,
        ended_at=model_step.ended_at,
        duration_ms=max(0.0, (model_step.ended_at or time()) - model_step.started_at) * 1000.0,
    )
    dispatch_recorded_event_to_trace_callback_manager(succeeded_event, context=run_context, state=state)
    return model_result
