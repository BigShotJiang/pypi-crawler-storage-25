from .call import call_model

__all__ = ["call_model"]
