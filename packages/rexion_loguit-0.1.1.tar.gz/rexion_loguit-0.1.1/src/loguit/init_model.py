from __future__ import annotations

from .model import init_model, init_model_from_config

__all__ = ["init_model", "init_model_from_config"]
