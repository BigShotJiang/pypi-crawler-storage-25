from __future__ import annotations

from dataclasses import dataclass, field
from time import time
from typing import Any, Callable, Iterable
from uuid import UUID

from ..callbacks import TraceCallbackFailureMode, TraceCallbackHandler, resolve_trace_callback_manager
from ..core_types import RunContext
from ..logging import EventSink, emit_event
from ..state import RunState, StepRecord


def _safe_serialize(value: Any) -> Any:
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    if isinstance(value, dict):
        return {key: _safe_serialize(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_safe_serialize(item) for item in value]
    if hasattr(value, "model_dump"):
        return _safe_serialize(value.model_dump())
    if hasattr(value, "dict"):
        return _safe_serialize(value.dict())
    return str(value)


def _stringify_run_id(run_id: UUID | str | None) -> str | None:
    if run_id is None:
        return None
    return str(run_id)


def _extract_model_name(invocation_params: dict[str, Any] | None) -> str | None:
    if not invocation_params:
        return None
    return (
        invocation_params.get("model_name")
        or invocation_params.get("model")
        or invocation_params.get("model_id")
    )


def _extract_model_parameters(invocation_params: dict[str, Any] | None) -> dict[str, Any]:
    if not invocation_params:
        return {}
    return {
        key: value
        for key, value in invocation_params.items()
        if key not in ("model_name", "model", "model_id", "api_key", "_type", "stop")
    }


def _extract_llm_response_payload(response: Any) -> tuple[Any, dict[str, Any], str | None]:
    llm_output = getattr(response, "llm_output", None) or {}
    token_usage = llm_output.get("token_usage") or llm_output.get("usage") or {}

    output = None
    model_name = None
    generations = getattr(response, "generations", None) or []
    if generations and generations[0]:
        first_generation = generations[0][0]
        if hasattr(first_generation, "message"):
            output = _safe_serialize(first_generation.message)
            response_metadata = getattr(first_generation.message, "response_metadata", {}) or {}
            model_name = response_metadata.get("model_id") or response_metadata.get("model_name")
        else:
            output = getattr(first_generation, "text", None)

    usage = {
        "input": token_usage.get("prompt_tokens") or token_usage.get("input_tokens"),
        "output": token_usage.get("completion_tokens") or token_usage.get("output_tokens"),
        "total": token_usage.get("total_tokens"),
    }
    return output, usage, model_name


@dataclass
class _InvocationRecord:
    trace_id: str
    kind: str
    name: str
    started_at: float
    parent_run_id: str | None = None
    step: StepRecord | None = None


@dataclass
class _TraceSession:
    trace_id: str
    context: RunContext
    state: RunState
    started_at: float
    root_run_id: str
    root_name: str
    root_input: Any = None
    active_run_ids: set[str] = field(default_factory=set)


class BaseLangChainCallbackHandler:
    def on_chain_start(  # noqa: PLR0913
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: UUID | str,
        parent_run_id: UUID | str | None = None,
        **kwargs: Any,
    ) -> None:
        return None

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID | str,
        **kwargs: Any,
    ) -> None:
        return None

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID | str,
        **kwargs: Any,
    ) -> None:
        return None

    def on_llm_start(  # noqa: PLR0913
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID | str,
        parent_run_id: UUID | str | None = None,
        **kwargs: Any,
    ) -> None:
        return None

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: UUID | str,
        **kwargs: Any,
    ) -> None:
        return None

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID | str,
        **kwargs: Any,
    ) -> None:
        return None

    def on_tool_start(  # noqa: PLR0913
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID | str,
        parent_run_id: UUID | str | None = None,
        **kwargs: Any,
    ) -> None:
        return None

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID | str,
        **kwargs: Any,
    ) -> None:
        return None

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID | str,
        **kwargs: Any,
    ) -> None:
        return None


class LangChainTraceCallbackAdapter(BaseLangChainCallbackHandler):
    def __init__(
        self,
        *,
        trace_callback_handlers: Iterable[TraceCallbackHandler] | None = None,
        trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
        event_sinks: Iterable[EventSink] | None = None,
        context_factory: Callable[[str], RunContext] | None = None,
    ) -> None:
        self._trace_callback_handlers = list(trace_callback_handlers or [])
        self._trace_callback_failure_mode = trace_callback_failure_mode
        self._event_sinks = list(event_sinks or [])
        self._context_factory = context_factory
        self._sessions: dict[str, _TraceSession] = {}
        self._records: dict[str, _InvocationRecord] = {}

    def _resolve_name(self, serialized: dict[str, Any] | None, *, fallback: str, **kwargs: Any) -> str:
        return kwargs.get("name") or (serialized or {}).get("name") or fallback

    def _build_context(self, trace_id: str) -> RunContext:
        context = self._context_factory(trace_id) if self._context_factory is not None else RunContext(run_id=trace_id)
        context.trace_callback_manager = resolve_trace_callback_manager(
            context,
            self._trace_callback_handlers,
            self._trace_callback_failure_mode,
        )
        return context

    def _create_session(
        self,
        *,
        trace_id: str,
        root_run_id: str,
        root_name: str,
        root_input: Any,
    ) -> _TraceSession:
        context = self._build_context(trace_id)
        state = RunState(
            run_id=context.run_id,
            trace_id=context.trace_id,
            correlation_id=context.correlation_id,
            project_id=context.project_id,
            tenant_id=context.tenant_id,
            metadata=dict(context.metadata),
        )
        session = _TraceSession(
            trace_id=trace_id,
            context=context,
            state=state,
            started_at=time(),
            root_run_id=root_run_id,
            root_name=root_name,
            root_input=root_input,
        )
        self._sessions[trace_id] = session
        return session

    def _get_or_create_session(
        self,
        *,
        run_id: str,
        parent_run_id: str | None,
        default_name: str,
        default_input: Any,
    ) -> tuple[_TraceSession, bool]:
        if run_id in self._records:
            existing_record = self._records[run_id]
            return self._sessions[existing_record.trace_id], False
        trace_id = run_id
        if parent_run_id is not None and parent_run_id in self._records:
            trace_id = self._records[parent_run_id].trace_id
        if trace_id in self._sessions:
            return self._sessions[trace_id], False
        session = self._create_session(
            trace_id=trace_id,
            root_run_id=run_id,
            root_name=default_name,
            root_input=default_input,
        )
        self._records[run_id] = _InvocationRecord(
            trace_id=trace_id,
            kind="root",
            name=default_name,
            started_at=session.started_at,
            parent_run_id=parent_run_id,
        )
        session.active_run_ids.add(run_id)
        emit_event(
            session.state,
            session.context,
            self._event_sinks,
            "run_started",
            started_at=session.started_at,
            source="langchain",
            name=default_name,
            input=_safe_serialize(default_input),
            langchain_run_id=run_id,
            parent_langchain_run_id=parent_run_id,
            implicit_root=True,
        )
        return session, True

    def _record_for(self, run_id: str) -> _InvocationRecord | None:
        return self._records.get(run_id)

    def _session_for(self, run_id: str) -> _TraceSession | None:
        record = self._record_for(run_id)
        if record is None:
            return None
        return self._sessions.get(record.trace_id)

    def _cleanup_trace(self, trace_id: str) -> None:
        session = self._sessions.pop(trace_id, None)
        if session is None:
            return
        for run_id in session.active_run_ids:
            self._records.pop(run_id, None)

    def on_chain_start(  # noqa: PLR0913
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: UUID | str,
        parent_run_id: UUID | str | None = None,
        **kwargs: Any,
    ) -> None:
        run_id_str = _stringify_run_id(run_id)
        parent_run_id_str = _stringify_run_id(parent_run_id)
        if run_id_str is None:
            return
        name = self._resolve_name(serialized, fallback="chain", **kwargs)

        if parent_run_id_str is None:
            session = self._create_session(
                trace_id=run_id_str,
                root_run_id=run_id_str,
                root_name=name,
                root_input=inputs,
            )
            self._records[run_id_str] = _InvocationRecord(
                trace_id=run_id_str,
                kind="root",
                name=name,
                started_at=session.started_at,
            )
            session.active_run_ids.add(run_id_str)
            emit_event(
                session.state,
                session.context,
                self._event_sinks,
                "run_started",
                started_at=session.started_at,
                source="langchain",
                name=name,
                input=_safe_serialize(inputs),
                serialized=_safe_serialize(serialized),
                langchain_run_id=run_id_str,
                parent_langchain_run_id=None,
            )
            return

        session, _ = self._get_or_create_session(
            run_id=run_id_str,
            parent_run_id=parent_run_id_str,
            default_name=name,
            default_input=inputs,
        )
        chain_step = session.state.start_step("chain_call", name)
        self._records[run_id_str] = _InvocationRecord(
            trace_id=session.trace_id,
            kind="chain",
            name=name,
            started_at=chain_step.started_at,
            parent_run_id=parent_run_id_str,
            step=chain_step,
        )
        session.active_run_ids.add(run_id_str)
        emit_event(
            session.state,
            session.context,
            self._event_sinks,
            "chain_started",
            step_id=chain_step.step_id,
            source="langchain",
            name=name,
            input=_safe_serialize(inputs),
            serialized=_safe_serialize(serialized),
            step_type=chain_step.step_type,
            status=chain_step.status,
            started_at=chain_step.started_at,
            langchain_run_id=run_id_str,
            parent_langchain_run_id=parent_run_id_str,
        )

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID | str,
        **kwargs: Any,
    ) -> None:
        _ = kwargs
        run_id_str = _stringify_run_id(run_id)
        if run_id_str is None:
            return
        record = self._record_for(run_id_str)
        session = self._session_for(run_id_str)
        if record is None or session is None:
            return

        ended_at = time()
        if record.kind == "root":
            emit_event(
                session.state,
                session.context,
                self._event_sinks,
                "run_completed",
                started_at=record.started_at,
                ended_at=ended_at,
                duration_ms=max(0.0, ended_at - record.started_at) * 1000.0,
                completed_step_count=sum(1 for step in session.state.steps if step.status == "completed"),
                source="langchain",
                name=record.name,
                output=_safe_serialize(outputs),
                langchain_run_id=run_id_str,
            )
            self._cleanup_trace(record.trace_id)
            return

        if record.step is None:
            return
        session.state.end_step(record.step, status="completed")
        emit_event(
            session.state,
            session.context,
            self._event_sinks,
            "chain_succeeded",
            step_id=record.step.step_id,
            source="langchain",
            name=record.name,
            output=_safe_serialize(outputs),
            step_type=record.step.step_type,
            status=record.step.status,
            started_at=record.step.started_at,
            ended_at=record.step.ended_at,
            duration_ms=max(0.0, (record.step.ended_at or ended_at) - record.step.started_at) * 1000.0,
            langchain_run_id=run_id_str,
            parent_langchain_run_id=record.parent_run_id,
        )

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID | str,
        **kwargs: Any,
    ) -> None:
        _ = kwargs
        run_id_str = _stringify_run_id(run_id)
        if run_id_str is None:
            return
        record = self._record_for(run_id_str)
        session = self._session_for(run_id_str)
        if record is None or session is None:
            return

        ended_at = time()
        if record.kind == "root":
            emit_event(
                session.state,
                session.context,
                self._event_sinks,
                "run_terminated",
                reason=str(error),
                source="langchain",
                error=str(error),
                name=record.name,
                started_at=record.started_at,
                ended_at=ended_at,
                duration_ms=max(0.0, ended_at - record.started_at) * 1000.0,
                langchain_run_id=run_id_str,
            )
            self._cleanup_trace(record.trace_id)
            return

        if record.step is None:
            return
        session.state.end_step(record.step, status="error", error=str(error))
        emit_event(
            session.state,
            session.context,
            self._event_sinks,
            "chain_failed",
            step_id=record.step.step_id,
            source="langchain",
            error=str(error),
            name=record.name,
            step_type=record.step.step_type,
            status=record.step.status,
            started_at=record.step.started_at,
            ended_at=record.step.ended_at,
            duration_ms=max(0.0, (record.step.ended_at or ended_at) - record.step.started_at) * 1000.0,
            langchain_run_id=run_id_str,
            parent_langchain_run_id=record.parent_run_id,
        )

    def on_llm_start(  # noqa: PLR0913
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID | str,
        parent_run_id: UUID | str | None = None,
        **kwargs: Any,
    ) -> None:
        run_id_str = _stringify_run_id(run_id)
        parent_run_id_str = _stringify_run_id(parent_run_id)
        if run_id_str is None:
            return
        name = self._resolve_name(serialized, fallback="llm", **kwargs)
        session, _ = self._get_or_create_session(
            run_id=run_id_str,
            parent_run_id=parent_run_id_str,
            default_name=name,
            default_input=prompts,
        )
        model_step = session.state.start_step("model_call", name)
        self._records[run_id_str] = _InvocationRecord(
            trace_id=session.trace_id,
            kind="llm",
            name=name,
            started_at=model_step.started_at,
            parent_run_id=parent_run_id_str,
            step=model_step,
        )
        session.active_run_ids.add(run_id_str)
        invocation_params = kwargs.get("invocation_params", {})
        emit_event(
            session.state,
            session.context,
            self._event_sinks,
            "model_call_started",
            step_id=model_step.step_id,
            model=_extract_model_name(invocation_params) or name,
            step_type=model_step.step_type,
            name=model_step.name,
            status=model_step.status,
            message_index=model_step.message_index,
            started_at=model_step.started_at,
            source="langchain",
            prompts=_safe_serialize(prompts),
            serialized=_safe_serialize(serialized),
            invocation_params=_safe_serialize(invocation_params),
            model_parameters=_safe_serialize(_extract_model_parameters(invocation_params)),
            langchain_run_id=run_id_str,
            parent_langchain_run_id=parent_run_id_str,
        )

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: UUID | str,
        **kwargs: Any,
    ) -> None:
        _ = kwargs
        run_id_str = _stringify_run_id(run_id)
        if run_id_str is None:
            return
        record = self._record_for(run_id_str)
        session = self._session_for(run_id_str)
        if record is None or record.step is None or session is None:
            return

        output, usage, model_name = _extract_llm_response_payload(response)
        session.state.end_step(record.step, status="completed")
        ended_at = record.step.ended_at or time()
        emit_event(
            session.state,
            session.context,
            self._event_sinks,
            "model_call_succeeded",
            step_id=record.step.step_id,
            model=model_name or record.name,
            step_type=record.step.step_type,
            name=record.step.name,
            status=record.step.status,
            message_index=record.step.message_index,
            started_at=record.step.started_at,
            ended_at=record.step.ended_at,
            duration_ms=max(0.0, ended_at - record.step.started_at) * 1000.0,
            source="langchain",
            output=_safe_serialize(output),
            usage=_safe_serialize(usage),
            langchain_run_id=run_id_str,
            parent_langchain_run_id=record.parent_run_id,
        )

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID | str,
        **kwargs: Any,
    ) -> None:
        _ = kwargs
        run_id_str = _stringify_run_id(run_id)
        if run_id_str is None:
            return
        record = self._record_for(run_id_str)
        session = self._session_for(run_id_str)
        if record is None or record.step is None or session is None:
            return

        session.state.end_step(record.step, status="error", error=str(error))
        ended_at = record.step.ended_at or time()
        emit_event(
            session.state,
            session.context,
            self._event_sinks,
            "model_call_failed",
            step_id=record.step.step_id,
            model=record.name,
            error=str(error),
            step_type=record.step.step_type,
            name=record.step.name,
            status=record.step.status,
            message_index=record.step.message_index,
            started_at=record.step.started_at,
            ended_at=record.step.ended_at,
            duration_ms=max(0.0, ended_at - record.step.started_at) * 1000.0,
            source="langchain",
            langchain_run_id=run_id_str,
            parent_langchain_run_id=record.parent_run_id,
        )

    def on_tool_start(  # noqa: PLR0913
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID | str,
        parent_run_id: UUID | str | None = None,
        **kwargs: Any,
    ) -> None:
        run_id_str = _stringify_run_id(run_id)
        parent_run_id_str = _stringify_run_id(parent_run_id)
        if run_id_str is None:
            return
        name = self._resolve_name(serialized, fallback="tool", **kwargs)
        session, _ = self._get_or_create_session(
            run_id=run_id_str,
            parent_run_id=parent_run_id_str,
            default_name=name,
            default_input=input_str,
        )
        tool_step = session.state.start_step("tool_call", name)
        self._records[run_id_str] = _InvocationRecord(
            trace_id=session.trace_id,
            kind="tool",
            name=name,
            started_at=tool_step.started_at,
            parent_run_id=parent_run_id_str,
            step=tool_step,
        )
        session.active_run_ids.add(run_id_str)
        emit_event(
            session.state,
            session.context,
            self._event_sinks,
            "tool_call_started",
            step_id=tool_step.step_id,
            tool=name,
            step_type=tool_step.step_type,
            name=tool_step.name,
            status=tool_step.status,
            message_index=tool_step.message_index,
            started_at=tool_step.started_at,
            source="langchain",
            input=_safe_serialize(input_str),
            serialized=_safe_serialize(serialized),
            langchain_run_id=run_id_str,
            parent_langchain_run_id=parent_run_id_str,
        )

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID | str,
        **kwargs: Any,
    ) -> None:
        _ = kwargs
        run_id_str = _stringify_run_id(run_id)
        if run_id_str is None:
            return
        record = self._record_for(run_id_str)
        session = self._session_for(run_id_str)
        if record is None or record.step is None or session is None:
            return

        session.state.end_step(record.step, status="completed")
        ended_at = record.step.ended_at or time()
        emit_event(
            session.state,
            session.context,
            self._event_sinks,
            "tool_call_succeeded",
            step_id=record.step.step_id,
            tool=record.name,
            step_type=record.step.step_type,
            name=record.step.name,
            status=record.step.status,
            message_index=record.step.message_index,
            started_at=record.step.started_at,
            ended_at=record.step.ended_at,
            duration_ms=max(0.0, ended_at - record.step.started_at) * 1000.0,
            source="langchain",
            output=_safe_serialize(output),
            langchain_run_id=run_id_str,
            parent_langchain_run_id=record.parent_run_id,
        )

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID | str,
        **kwargs: Any,
    ) -> None:
        _ = kwargs
        run_id_str = _stringify_run_id(run_id)
        if run_id_str is None:
            return
        record = self._record_for(run_id_str)
        session = self._session_for(run_id_str)
        if record is None or record.step is None or session is None:
            return

        session.state.end_step(record.step, status="error", error=str(error))
        ended_at = record.step.ended_at or time()
        emit_event(
            session.state,
            session.context,
            self._event_sinks,
            "tool_call_failed",
            step_id=record.step.step_id,
            tool=record.name,
            error=str(error),
            step_type=record.step.step_type,
            name=record.step.name,
            status=record.step.status,
            message_index=record.step.message_index,
            started_at=record.step.started_at,
            ended_at=record.step.ended_at,
            duration_ms=max(0.0, ended_at - record.step.started_at) * 1000.0,
            source="langchain",
            langchain_run_id=run_id_str,
            parent_langchain_run_id=record.parent_run_id,
        )


__all__ = [
    "BaseLangChainCallbackHandler",
    "LangChainTraceCallbackAdapter",
]
