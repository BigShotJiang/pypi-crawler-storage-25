from __future__ import annotations

from typing import Any, Dict


def validate_tool_args(tool_schema: Dict[str, Any], args: Dict[str, Any]) -> None:
    if tool_schema.get("type") != "object":
        raise ValueError("Tool schema must be an object schema")

    required_tool_args = tool_schema.get("required", [])
    for key in required_tool_args:
        if key not in args:
            raise ValueError(f"Missing required argument: {key}")

    properties = tool_schema.get("properties", {})
    for argument_name, provided_argument_value in args.items():
        property_schema = properties.get(argument_name)
        if property_schema is None:
            continue
        expected_json_schema_type = property_schema.get("type")
        if expected_json_schema_type is None:
            continue
        if not _matches_type(expected_json_schema_type, provided_argument_value):
            raise ValueError(f"Invalid type for '{argument_name}': expected {expected_json_schema_type}")


_TYPE_VALIDATORS = {
    "string": lambda value: isinstance(value, str),
    "number": lambda value: isinstance(value, (int, float)) and not isinstance(value, bool),
    "integer": lambda value: isinstance(value, int) and not isinstance(value, bool),
    "boolean": lambda value: isinstance(value, bool),
    "object": lambda value: isinstance(value, dict),
    "array": lambda value: isinstance(value, list),
}

def _matches_type(expected_type: str, value: Any) -> bool:
    type_validation_callable = _TYPE_VALIDATORS.get(expected_type)
    if type_validation_callable is None:
        return True
    return type_validation_callable(value)


def normalize_tool_args(tool_schema: Dict[str, Any], args: Dict[str, Any] | str | None) -> Dict[str, Any]:
    if args is None:
        return {}
    if isinstance(args, dict):
        return args
    properties = tool_schema.get("properties", {})
    if "input" in properties:
        return {"input": args}
    if len(properties) == 1:
        only_key = next(iter(properties.keys()))
        return {only_key: args}
    raise ValueError("Tool expects structured arguments")
