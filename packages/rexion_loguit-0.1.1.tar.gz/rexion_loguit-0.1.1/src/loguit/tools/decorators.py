from __future__ import annotations

from typing import Any, Callable, Optional

from .base import ToolSpec
from .function import ToolFunction
from .schema import schema_from_callable


def tool(func: Optional[Callable[..., Any]] = None, *, name: Optional[str] = None, description: Optional[str] = None):
    def wrap(target: Callable[..., Any]) -> ToolFunction:
        spec = ToolSpec(
            name=name or target.__name__,
            description=description or (target.__doc__ or "").strip(),
            args_schema=schema_from_callable(target),
        )
        return ToolFunction(target, spec)

    if func is None:
        return wrap
    return wrap(func)
