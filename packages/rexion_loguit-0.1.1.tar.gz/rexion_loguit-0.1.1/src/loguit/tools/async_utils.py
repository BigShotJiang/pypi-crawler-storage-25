from __future__ import annotations

import asyncio
import threading
from typing import Any


def _run_coroutine_sync(coroutine):  # noqa: ANN001
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coroutine)

    coroutine_execution_results: list[Any] = []
    coroutine_execution_errors: list[BaseException] = []

    def _runner() -> None:
        try:
            coroutine_execution_results.append(asyncio.run(coroutine))
        except BaseException as exception:  # noqa: BLE001
            coroutine_execution_errors.append(exception)

    thread = threading.Thread(target=_runner, daemon=True)
    thread.start()
    thread.join()
    if coroutine_execution_errors:
        raise coroutine_execution_errors[0]
    return coroutine_execution_results[0]
