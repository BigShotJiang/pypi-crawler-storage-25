from __future__ import annotations

import asyncio
import inspect
from abc import ABC, abstractmethod
from dataclasses import dataclass
from time import time
from typing import Any, Dict, Iterator
from uuid import uuid4

from ..callbacks import (
    TraceCallbackFailureMode,
    TraceCallbackHandler,
    dispatch_recorded_event_to_trace_callback_manager,
    resolve_trace_callback_manager,
)
from ..core_types import RunContext, ToolResult
from ..state import ErrorRecord, RunState


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    args_schema: Dict[str, Any]


class Tool(ABC):
    spec: ToolSpec

    @abstractmethod
    def invoke(self, args: Dict[str, Any] | str | None, context: RunContext) -> ToolResult | Iterator[Any]:
        raise NotImplementedError

    async def ainvoke(self, args: Dict[str, Any] | str | None, context: RunContext) -> ToolResult | Iterator[Any]:
        return await asyncio.to_thread(self.invoke, args, context)

    async def async_invoke(self, args: Dict[str, Any] | str | None, context: RunContext) -> ToolResult | Iterator[Any]:
        return await self.ainvoke(args, context)

    def invoke_with_callbacks(
        self,
        args: Dict[str, Any] | str | None,
        *,
        context: RunContext | None = None,
        trace_callback_handlers: list[TraceCallbackHandler] | None = None,
        trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
    ) -> ToolResult | Iterator[Any]:
        run_context = context or RunContext(run_id=str(uuid4()))
        run_context.trace_callback_manager = resolve_trace_callback_manager(
            run_context,
            trace_callback_handlers,
            trace_callback_failure_mode,
        )
        state = RunState(
            run_id=run_context.run_id,
            trace_id=run_context.trace_id,
            correlation_id=run_context.correlation_id,
            project_id=run_context.project_id,
            tenant_id=run_context.tenant_id,
            metadata=dict(run_context.metadata),
        )
        tool_step = state.start_step("tool_call", self.spec.name)
        started_event = state.record_event(
            "tool_call_started",
            step_id=tool_step.step_id,
            tool=self.spec.name,
            step_type=tool_step.step_type,
            name=tool_step.name,
            status=tool_step.status,
            message_index=tool_step.message_index,
            started_at=tool_step.started_at,
        )
        dispatch_recorded_event_to_trace_callback_manager(started_event, context=run_context, state=state)
        try:
            tool_result = self.invoke(args, run_context)
        except Exception as exc:  # noqa: BLE001
            state.end_step(tool_step, status="error", error=str(exc))
            state.errors.append(ErrorRecord(error_type="tool_error", message=str(exc), step_id=tool_step.step_id))
            failed_event = state.record_event(
                "tool_call_failed",
                step_id=tool_step.step_id,
                tool=self.spec.name,
                error=str(exc),
                step_type=tool_step.step_type,
                name=tool_step.name,
                status=tool_step.status,
                message_index=tool_step.message_index,
                started_at=tool_step.started_at,
                ended_at=tool_step.ended_at,
                duration_ms=max(0.0, (tool_step.ended_at or time()) - tool_step.started_at) * 1000.0,
            )
            dispatch_recorded_event_to_trace_callback_manager(failed_event, context=run_context, state=state)
            raise
        if inspect.isgenerator(tool_result):
            return tool_result
        if tool_result.error:
            state.errors.append(
                ErrorRecord(error_type="tool_error", message=str(tool_result.error), step_id=tool_step.step_id)
            )
            state.end_step(tool_step, status="error", error=str(tool_result.error))
            failed_event = state.record_event(
                "tool_call_failed",
                step_id=tool_step.step_id,
                tool=self.spec.name,
                error=str(tool_result.error),
                step_type=tool_step.step_type,
                name=tool_step.name,
                status=tool_step.status,
                message_index=tool_step.message_index,
                started_at=tool_step.started_at,
                ended_at=tool_step.ended_at,
                duration_ms=max(0.0, (tool_step.ended_at or time()) - tool_step.started_at) * 1000.0,
            )
            dispatch_recorded_event_to_trace_callback_manager(failed_event, context=run_context, state=state)
            return tool_result
        state.end_step(tool_step, status="completed")
        succeeded_event = state.record_event(
            "tool_call_succeeded",
            step_id=tool_step.step_id,
            tool=self.spec.name,
            step_type=tool_step.step_type,
            name=tool_step.name,
            status=tool_step.status,
            message_index=tool_step.message_index,
            started_at=tool_step.started_at,
            ended_at=tool_step.ended_at,
            duration_ms=max(0.0, (tool_step.ended_at or time()) - tool_step.started_at) * 1000.0,
        )
        dispatch_recorded_event_to_trace_callback_manager(succeeded_event, context=run_context, state=state)
        return tool_result
