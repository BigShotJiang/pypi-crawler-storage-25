from __future__ import annotations

import inspect
from typing import Any, Callable, Dict, get_args, get_origin, get_type_hints


def schema_from_callable(func: Callable[..., Any]) -> Dict[str, Any]:
    callable_signature = inspect.signature(func)
    type_hints = get_type_hints(func)
    properties: Dict[str, Any] = {}
    required_tool_args: list[str] = []
    for name, param in callable_signature.parameters.items():
        if param.default is inspect._empty:
            required_tool_args.append(name)
        annotation = type_hints.get(name, param.annotation)
        properties[name] = _annotation_to_schema(annotation)
    schema: Dict[str, Any] = {"type": "object", "properties": properties}
    if required_tool_args:
        schema["required"] = required_tool_args
    return schema


_SCALAR_TYPE_SCHEMAS: Dict[Any, Dict[str, str]] = {
    str: {"type": "string"},
    int: {"type": "integer"},
    float: {"type": "number"},
    bool: {"type": "boolean"},
}

_ORIGIN_TYPE_SCHEMAS: Dict[Any, Dict[str, str]] = {
    list: {"type": "array"},
    dict: {"type": "object"},
}


def _annotation_to_schema(annotation: Any) -> Dict[str, Any]:
    if annotation is inspect._empty:
        return {}
    origin = get_origin(annotation)
    if type(None) in get_args(annotation):
        annotation = next((arg for arg in get_args(annotation) if arg is not type(None)), annotation)
    if annotation in _SCALAR_TYPE_SCHEMAS:
        return _SCALAR_TYPE_SCHEMAS[annotation]
    if origin in _ORIGIN_TYPE_SCHEMAS:
        return _ORIGIN_TYPE_SCHEMAS[origin]
    return {}
