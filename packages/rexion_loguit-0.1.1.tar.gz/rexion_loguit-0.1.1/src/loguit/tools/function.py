from __future__ import annotations

import asyncio
import inspect
from typing import Any, Callable, Dict, Iterator

from ..callbacks import TraceCallbackFailureMode, TraceCallbackHandler
from ..core_types import RunContext, ToolResult, ToolStreamEvent
from .args import normalize_tool_args, validate_tool_args
from .async_utils import _run_coroutine_sync
from .base import Tool, ToolSpec


def _finalize_stream_output(final: Any, deltas: list[str]) -> ToolResult:
    if isinstance(final, ToolResult):
        return final
    if final is None and deltas:
        text = "".join(deltas)
        return ToolResult(output=text, raw=text)
    return ToolResult(output=final, raw=final)


def _consume_stream_output_sync(stream: Any) -> ToolResult:
    deltas: list[str] = []
    while True:
        try:
            item = next(stream)
        except StopIteration as stop:
            return _finalize_stream_output(stop.value, deltas)
        else:
            if isinstance(item, ToolStreamEvent) and item.delta is not None:
                deltas.append(item.delta)
            elif isinstance(item, str):
                deltas.append(item)


async def _consume_stream_output_async(stream: Any) -> ToolResult:
    deltas: list[str] = []
    async for item in stream:
        if isinstance(item, ToolStreamEvent) and item.delta is not None:
            deltas.append(item.delta)
        elif isinstance(item, str):
            deltas.append(item)
    return _finalize_stream_output(None, deltas)


class ToolFunction(Tool):
    def __init__(self, func: Callable[..., Any], spec: ToolSpec) -> None:
        self._func = func
        self.spec = spec

    def invoke(
        self,
        args: Dict[str, Any] | str | None,
        context: RunContext,
        *,
        trace_callback_handlers: list[TraceCallbackHandler] | None = None,
        trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
    ) -> ToolResult | Iterator[Any]:
        if trace_callback_handlers is not None:
            return self.invoke_with_callbacks(
                args,
                context=context,
                trace_callback_handlers=trace_callback_handlers,
                trace_callback_failure_mode=trace_callback_failure_mode,
            )
        normalized_tool_args = normalize_tool_args(self.spec.args_schema, args)
        validate_tool_args(self.spec.args_schema, normalized_tool_args)
        try:
            if inspect.iscoroutinefunction(self._func):
                output = _run_coroutine_sync(self._func(**normalized_tool_args))
            else:
                output = self._func(**normalized_tool_args)
            if inspect.isgenerator(output):
                return output
            if inspect.isasyncgen(output):
                return ToolResult(
                    output=None,
                    error="Async generator tools require async invocation",
                    raw=output,
                )
            return ToolResult(output=output, raw=output)
        except Exception as exc:  # noqa: BLE001
            return ToolResult(output=None, error=str(exc), raw=exc)

    async def ainvoke(
        self,
        args: Dict[str, Any] | str | None,
        context: RunContext,
        *,
        trace_callback_handlers: list[TraceCallbackHandler] | None = None,
        trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
    ) -> ToolResult | Iterator[Any]:
        if trace_callback_handlers is not None:
            return await self.ainvoke_with_callbacks(
                args,
                context=context,
                trace_callback_handlers=trace_callback_handlers,
                trace_callback_failure_mode=trace_callback_failure_mode,
            )
        _ = context
        normalized_tool_args = normalize_tool_args(self.spec.args_schema, args)
        validate_tool_args(self.spec.args_schema, normalized_tool_args)
        try:
            if inspect.isasyncgenfunction(self._func):
                return await _consume_stream_output_async(self._func(**normalized_tool_args))
            if inspect.iscoroutinefunction(self._func):
                output = await self._func(**normalized_tool_args)
            else:
                output = await asyncio.to_thread(self._func, **normalized_tool_args)
            if inspect.isgenerator(output):
                return _consume_stream_output_sync(output)
            return ToolResult(output=output, raw=output)
        except Exception as exc:  # noqa: BLE001
            return ToolResult(output=None, error=str(exc), raw=exc)

    async def async_invoke(self, args: Dict[str, Any] | str | None, context: RunContext) -> ToolResult | Iterator[Any]:
        return await self.ainvoke(args, context)

    async def ainvoke_with_callbacks(
        self,
        args: Dict[str, Any] | str | None,
        *,
        context: RunContext | None = None,
        trace_callback_handlers: list[TraceCallbackHandler] | None = None,
        trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
    ) -> ToolResult | Iterator[Any]:
        return await asyncio.to_thread(
            self.invoke_with_callbacks,
            args,
            context=context,
            trace_callback_handlers=trace_callback_handlers,
            trace_callback_failure_mode=trace_callback_failure_mode,
        )
