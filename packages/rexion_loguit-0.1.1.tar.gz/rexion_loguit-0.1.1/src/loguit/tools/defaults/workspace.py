from __future__ import annotations

import os
import shlex
import subprocess
from pathlib import Path

from ..decorators import tool

BASE_DIR = Path(os.environ.get("LOGUIT_WORKSPACE_DIR", str(Path.cwd() / "workspace"))).resolve()
MAX_OUTPUT_CHARS = 4000
COMMAND_TIMEOUT_SECONDS = 20
ALLOWED_COMMANDS = {
    "ls",
    "rg",
    "cat",
    "mkdir",
    "touch",
    "echo",
}


def _resolve_path(relative_path: str) -> Path:
    base = BASE_DIR
    base.mkdir(parents=True, exist_ok=True)
    target = (base / relative_path).resolve()
    if base not in target.parents and target != base:
        raise ValueError("Path escapes workspace")
    return target


def _reject_unsafe_args(args: list[str]) -> None:
    for arg in args:
        if arg.startswith(("/", "~")) or ".." in arg:
            raise ValueError("Unsafe path argument")


@tool
def list_dir(relative_path: str = ".") -> list[str]:
    """List files under the workspace. relative_path must stay inside the workspace."""
    target = _resolve_path(relative_path)
    if not target.exists():
        raise ValueError("Path does not exist")
    if not target.is_dir():
        raise ValueError("Path is not a directory")
    return sorted(p.name for p in target.iterdir())


@tool
def read_text_file(relative_path: str) -> str:
    """Read a text file under the workspace."""
    target = _resolve_path(relative_path)
    if not target.exists():
        raise ValueError("File does not exist")
    if target.is_dir():
        raise ValueError("Path is a directory")
    return target.read_text(encoding="utf-8")


@tool
def write_text_file(relative_path: str, content: str) -> str:
    """Write a text file under the workspace and return the path."""
    target = _resolve_path(relative_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return str(target)


@tool
def make_dir(relative_path: str) -> str:
    """Create a directory under the workspace and return the path."""
    target = _resolve_path(relative_path)
    target.mkdir(parents=True, exist_ok=True)
    return str(target)


@tool
def mkdir(path: str) -> str:
    """Alias for make_dir using a path argument name."""
    return make_dir(path)


@tool
def touch(path: str) -> str:
    """Create an empty file under the workspace."""
    return write_text_file(path, "")


@tool
def run_shell(command: str) -> str:
    """Run a shell command in the workspace with a small allowlist."""
    parts = shlex.split(command)
    if not parts:
        raise ValueError("Command is empty")
    if parts[0] not in ALLOWED_COMMANDS:
        raise ValueError(f"Command not allowed: {parts[0]}")
    _reject_unsafe_args(parts[1:])
    try:
        result = subprocess.run(
            parts,
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            timeout=COMMAND_TIMEOUT_SECONDS,
            check=False,
        )
    except FileNotFoundError as exc:
        raise ValueError(str(exc)) from exc

    output = (result.stdout + result.stderr).strip()
    if not output:
        output = f"(exit {result.returncode}, no output)"
    if len(output) > MAX_OUTPUT_CHARS:
        output = output[:MAX_OUTPUT_CHARS] + "\n...truncated..."
    return output


__all__ = [
    "BASE_DIR",
    "MAX_OUTPUT_CHARS",
    "COMMAND_TIMEOUT_SECONDS",
    "ALLOWED_COMMANDS",
    "list_dir",
    "read_text_file",
    "write_text_file",
    "make_dir",
    "mkdir",
    "touch",
    "run_shell",
]
