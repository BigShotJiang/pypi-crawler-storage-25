from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Protocol, Sequence

from loguit.core_types import RunContext
from loguit.state import ExecutionEvent, RunState, StepRecord


@dataclass(frozen=True)
class PolicyDecision:
    allowed: bool
    reason: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class RunPolicy(Protocol):
    name: str

    def evaluate(self, context: RunContext, state: RunState) -> PolicyDecision: ...


class StepPolicy(Protocol):
    name: str

    def evaluate(self, context: RunContext, state: RunState, step: StepRecord) -> PolicyDecision: ...


class PolicyViolationError(RuntimeError):
    def __init__(
        self,
        *,
        policy_name: str,
        reason: str | None,
        scope: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.policy_name = policy_name
        self.reason = reason
        self.scope = scope
        self.metadata = metadata or {}
        message = f"Policy '{policy_name}' blocked {scope}"
        if reason:
            message = f"{message}: {reason}"
        super().__init__(message)


@dataclass
class PolicyEngine:
    run_policies: Sequence[RunPolicy] = field(default_factory=list)
    step_policies: Sequence[StepPolicy] = field(default_factory=list)

    def evaluate_run(self, context: RunContext, state: RunState) -> None:
        for policy in self.run_policies:
            decision = policy.evaluate(context, state)
            if not decision.allowed:
                raise PolicyViolationError(
                    policy_name=policy.name,
                    reason=decision.reason,
                    scope="run",
                    metadata=decision.metadata,
                )

    def evaluate_step(self, context: RunContext, state: RunState, step: StepRecord) -> None:
        for policy in self.step_policies:
            decision = policy.evaluate(context, state, step)
            if not decision.allowed:
                raise PolicyViolationError(
                    policy_name=policy.name,
                    reason=decision.reason,
                    scope="step",
                    metadata=decision.metadata,
                )


class RedactionRule(Protocol):
    name: str

    def redact_event(self, event: ExecutionEvent, *, context: RunContext, state: RunState) -> ExecutionEvent: ...


@dataclass
class RedactionPipeline:
    rules: Sequence[RedactionRule] = field(default_factory=list)

    def apply(self, event: ExecutionEvent, *, context: RunContext, state: RunState) -> ExecutionEvent:
        redacted_event = event
        for rule in self.rules:
            redacted_event = rule.redact_event(redacted_event, context=context, state=state)
        return redacted_event


@dataclass(frozen=True)
class DropDetailsRedactionRule:
    name: str = "drop_details"

    def redact_event(self, event: ExecutionEvent, *, context: RunContext, state: RunState) -> ExecutionEvent:  # noqa: ARG002
        return replace(event, details={})


__all__ = [
    "PolicyDecision",
    "RunPolicy",
    "StepPolicy",
    "PolicyViolationError",
    "PolicyEngine",
    "RedactionRule",
    "RedactionPipeline",
    "DropDetailsRedactionRule",
]
