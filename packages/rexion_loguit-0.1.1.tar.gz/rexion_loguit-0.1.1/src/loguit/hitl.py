from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Mapping

from .core_types import RunContext


@dataclass(frozen=True)
class HumanInTheLoopRequest:
    step_id: str
    tool_name: str
    tool_arguments: dict[str, Any]
    call_id: str | None = None


@dataclass(frozen=True)
class HumanInTheLoopDecision:
    decision_type: str
    edited_arguments: dict[str, Any] | None = None
    rejection_reason: str | None = None

    @classmethod
    def approve(cls) -> "HumanInTheLoopDecision":
        return cls(decision_type="approve")

    @classmethod
    def reject(cls, *, rejection_reason: str | None = None) -> "HumanInTheLoopDecision":
        return cls(decision_type="reject", rejection_reason=rejection_reason)

    @classmethod
    def edit_arguments(cls, edited_arguments: dict[str, Any]) -> "HumanInTheLoopDecision":
        return cls(decision_type="edit_arguments", edited_arguments=dict(edited_arguments))


@dataclass
class HumanInTheLoopPolicy:
    tool_names_requiring_approval: set[str] = field(default_factory=set)
    require_human_approval_for_tool_call: Callable[[str, dict[str, Any], RunContext], bool] | None = None

    def should_request_approval(
        self,
        *,
        tool_name: str,
        normalized_tool_arguments: dict[str, Any],
        context: RunContext,
    ) -> bool:
        if tool_name in self.tool_names_requiring_approval:
            return True
        if self.require_human_approval_for_tool_call is None:
            return False
        return bool(
            self.require_human_approval_for_tool_call(tool_name, dict(normalized_tool_arguments), context)
        )


def serialize_human_in_the_loop_request(human_in_the_loop_request: HumanInTheLoopRequest) -> dict[str, Any]:
    return asdict(human_in_the_loop_request)


def deserialize_human_in_the_loop_request(raw_value: Mapping[str, Any] | None) -> HumanInTheLoopRequest | None:
    if raw_value is None:
        return None
    return HumanInTheLoopRequest(
        step_id=str(raw_value["step_id"]),
        tool_name=str(raw_value["tool_name"]),
        tool_arguments=dict(raw_value.get("tool_arguments", {})),
        call_id=str(raw_value["call_id"]) if raw_value.get("call_id") is not None else None,
    )


__all__ = [
    "HumanInTheLoopDecision",
    "HumanInTheLoopPolicy",
    "HumanInTheLoopRequest",
    "deserialize_human_in_the_loop_request",
    "serialize_human_in_the_loop_request",
]
