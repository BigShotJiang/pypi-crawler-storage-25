from __future__ import annotations

import json
import types
from dataclasses import MISSING, fields, is_dataclass
from typing import Any, Mapping, Union, get_args, get_origin, get_type_hints


class StructuredOutputValidationError(ValueError):
    pass


def normalize_structured_output_schema(response_schema: type | dict[str, Any] | None) -> type | dict[str, Any] | None:
    if response_schema is None:
        return None
    if isinstance(response_schema, dict):
        return dict(response_schema)
    if isinstance(response_schema, type):
        return response_schema
    raise TypeError("response_schema must be a type, JSON Schema dict, or None")


def build_json_schema_from_response_schema(response_schema: type | dict[str, Any]) -> dict[str, Any]:
    if isinstance(response_schema, dict):
        return dict(response_schema)
    if _is_pydantic_model_type(response_schema):
        if hasattr(response_schema, "model_json_schema"):
            return response_schema.model_json_schema()
        return response_schema.schema()  # type: ignore[no-any-return]
    if is_dataclass(response_schema):
        properties: dict[str, Any] = {}
        required_property_names: list[str] = []
        resolved_type_hints = get_type_hints(response_schema)
        for dataclass_field in fields(response_schema):
            properties[dataclass_field.name] = _type_hint_to_json_schema(
                resolved_type_hints.get(dataclass_field.name, dataclass_field.type)
            )
            if dataclass_field.default is MISSING and dataclass_field.default_factory is MISSING:
                required_property_names.append(dataclass_field.name)
        schema: dict[str, Any] = {"type": "object", "properties": properties}
        if required_property_names:
            schema["required"] = required_property_names
        return schema
    raise TypeError("response_schema type is not supported")


def build_native_structured_output_payload(response_schema: type | dict[str, Any]) -> dict[str, Any]:
    json_schema = build_json_schema_from_response_schema(response_schema)
    schema_name = getattr(response_schema, "__name__", "structured_output")
    return {
        "type": "json_schema",
        "json_schema": {
            "name": schema_name,
            "schema": json_schema,
            "strict": True,
        },
    }


def validate_structured_output_value(
    output_value: Any,
    *,
    response_schema: type | dict[str, Any],
) -> Any:
    if isinstance(output_value, str):
        try:
            output_value = json.loads(output_value)
        except json.JSONDecodeError as exc:
            raise StructuredOutputValidationError(
                "Structured output must be valid JSON when returned as text"
            ) from exc

    if isinstance(response_schema, dict):
        _validate_json_schema_value(output_value, response_schema, path="$")
        return output_value

    if _is_pydantic_model_type(response_schema):
        if hasattr(response_schema, "model_validate"):
            return response_schema.model_validate(output_value)
        return response_schema.parse_obj(output_value)

    if is_dataclass(response_schema):
        if not isinstance(output_value, Mapping):
            raise StructuredOutputValidationError("Dataclass structured output requires an object value")
        return _coerce_dataclass_value(response_schema, dict(output_value))

    raise TypeError("response_schema type is not supported")


def _is_pydantic_model_type(response_schema: type) -> bool:
    try:
        from pydantic import BaseModel  # type: ignore
    except Exception:  # noqa: BLE001
        return False
    return issubclass(response_schema, BaseModel)


def _coerce_dataclass_value(dataclass_type: type, raw_value: dict[str, Any]) -> Any:
    resolved_type_hints = get_type_hints(dataclass_type)
    constructor_kwargs: dict[str, Any] = {}
    for dataclass_field in fields(dataclass_type):
        field_name = dataclass_field.name
        if field_name not in raw_value:
            if dataclass_field.default is MISSING and dataclass_field.default_factory is MISSING:
                raise StructuredOutputValidationError(f"Missing required field '{field_name}'")
            continue
        field_type = resolved_type_hints.get(field_name, dataclass_field.type)
        constructor_kwargs[field_name] = _coerce_typed_value(raw_value[field_name], field_type, path=field_name)
    return dataclass_type(**constructor_kwargs)


def _coerce_typed_value(raw_value: Any, expected_type: Any, *, path: str) -> Any:
    origin = get_origin(expected_type)
    args = get_args(expected_type)

    if expected_type is Any:
        return raw_value
    if origin is None:
        if is_dataclass(expected_type):
            if not isinstance(raw_value, Mapping):
                raise StructuredOutputValidationError(f"Field '{path}' must be an object")
            return _coerce_dataclass_value(expected_type, dict(raw_value))
        if expected_type in {str, int, float, bool}:
            if not isinstance(raw_value, expected_type):
                raise StructuredOutputValidationError(
                    f"Field '{path}' must be of type {expected_type.__name__}"
                )
            return raw_value
        return raw_value
    if origin in {list, tuple}:
        if not isinstance(raw_value, list):
            raise StructuredOutputValidationError(f"Field '{path}' must be a list")
        item_type = args[0] if args else Any
        return [_coerce_typed_value(item, item_type, path=path) for item in raw_value]
    if origin is dict:
        if not isinstance(raw_value, dict):
            raise StructuredOutputValidationError(f"Field '{path}' must be an object")
        value_type = args[1] if len(args) > 1 else Any
        return {key: _coerce_typed_value(value, value_type, path=f"{path}.{key}") for key, value in raw_value.items()}
    if origin is set:
        if not isinstance(raw_value, list):
            raise StructuredOutputValidationError(f"Field '{path}' must be a list")
        item_type = args[0] if args else Any
        return {_coerce_typed_value(item, item_type, path=path) for item in raw_value}
    if origin in {Union, types.UnionType}:
        for union_member_type in args:
            if union_member_type is type(None) and raw_value is None:
                return None
            try:
                return _coerce_typed_value(raw_value, union_member_type, path=path)
            except StructuredOutputValidationError:
                continue
        raise StructuredOutputValidationError(f"Field '{path}' does not match any allowed type")
    return raw_value


def _type_hint_to_json_schema(type_hint: Any) -> dict[str, Any]:
    origin = get_origin(type_hint)
    args = get_args(type_hint)
    if type_hint is str:
        return {"type": "string"}
    if type_hint is int:
        return {"type": "integer"}
    if type_hint is float:
        return {"type": "number"}
    if type_hint is bool:
        return {"type": "boolean"}
    if origin in {list, tuple, set}:
        item_type = args[0] if args else Any
        return {"type": "array", "items": _type_hint_to_json_schema(item_type)}
    if origin is dict:
        return {"type": "object"}
    if is_dataclass(type_hint):
        return build_json_schema_from_response_schema(type_hint)
    return {"type": "object"}


def _validate_json_schema_value(value: Any, schema: Mapping[str, Any], *, path: str) -> None:
    schema_type = schema.get("type")
    if schema_type == "object":
        if not isinstance(value, dict):
            raise StructuredOutputValidationError(f"{path} must be an object")
        required_property_names = schema.get("required", [])
        for required_property_name in required_property_names:
            if required_property_name not in value:
                raise StructuredOutputValidationError(f"{path}.{required_property_name} is required")
        properties = schema.get("properties", {})
        if isinstance(properties, Mapping):
            for property_name, property_schema in properties.items():
                if property_name in value and isinstance(property_schema, Mapping):
                    _validate_json_schema_value(value[property_name], property_schema, path=f"{path}.{property_name}")
        return
    if schema_type == "array":
        if not isinstance(value, list):
            raise StructuredOutputValidationError(f"{path} must be an array")
        item_schema = schema.get("items")
        if isinstance(item_schema, Mapping):
            for index, item_value in enumerate(value):
                _validate_json_schema_value(item_value, item_schema, path=f"{path}[{index}]")
        return
    if schema_type == "string" and not isinstance(value, str):
        raise StructuredOutputValidationError(f"{path} must be a string")
    if schema_type == "integer" and not isinstance(value, int):
        raise StructuredOutputValidationError(f"{path} must be an integer")
    if schema_type == "number" and not isinstance(value, (int, float)):
        raise StructuredOutputValidationError(f"{path} must be a number")
    if schema_type == "boolean" and not isinstance(value, bool):
        raise StructuredOutputValidationError(f"{path} must be a boolean")


__all__ = [
    "StructuredOutputValidationError",
    "normalize_structured_output_schema",
    "build_json_schema_from_response_schema",
    "build_native_structured_output_payload",
    "validate_structured_output_value",
]
