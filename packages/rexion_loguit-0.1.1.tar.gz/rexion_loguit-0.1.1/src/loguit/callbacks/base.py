from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from loguit.core_types import RunContext
    from loguit.state import ExecutionEvent, RunState


class TraceCallbackFailureMode(str, Enum):
    BEST_EFFORT = "best_effort"
    FAIL_FAST = "fail_fast"


@runtime_checkable
class TraceCallbackHandler(Protocol):
    def on_event(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...

    def on_run_started(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...

    def on_run_completed(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...

    def on_run_checkpointed(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...

    def on_run_resumed(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...

    def on_run_terminated(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...

    def on_policy_check_blocked(
        self,
        event: "ExecutionEvent",
        *,
        context: "RunContext",
        state: "RunState",
    ) -> None: ...

    def on_retry_scheduled(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...

    def on_retry_succeeded(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...

    def on_retry_exhausted(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...

    def on_model_call_started(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...

    def on_model_call_succeeded(
        self,
        event: "ExecutionEvent",
        *,
        context: "RunContext",
        state: "RunState",
    ) -> None: ...

    def on_model_call_failed(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...

    def on_tool_call_started(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...

    def on_tool_call_succeeded(
        self,
        event: "ExecutionEvent",
        *,
        context: "RunContext",
        state: "RunState",
    ) -> None: ...

    def on_tool_call_failed(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...

    def on_tool_call_history_pruned(
        self,
        event: "ExecutionEvent",
        *,
        context: "RunContext",
        state: "RunState",
    ) -> None: ...

    def on_compacted(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None: ...


class BaseTraceCallbackHandler:
    def on_event(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_run_started(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_run_completed(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_run_checkpointed(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_run_resumed(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_run_terminated(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_policy_check_blocked(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_retry_scheduled(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_retry_succeeded(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_retry_exhausted(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_model_call_started(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_model_call_succeeded(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_model_call_failed(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_tool_call_started(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_tool_call_succeeded(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_tool_call_failed(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_tool_call_history_pruned(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None

    def on_compacted(self, event, *, context, state) -> None:  # noqa: ANN001, ARG002
        return None


@dataclass
class InMemoryTraceCallbackHandler(BaseTraceCallbackHandler):
    recorded_events: list["ExecutionEvent"] = field(default_factory=list)

    def on_event(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None:  # noqa: ARG002
        self.recorded_events.append(event)

    def list_recorded_events(
        self,
        *,
        run_id: str | None = None,
        step_id: str | None = None,
        event_type: str | None = None,
    ) -> list["ExecutionEvent"]:
        return [
            recorded_event
            for recorded_event in self.recorded_events
            if (run_id is None or recorded_event.run_id == run_id)
            and (step_id is None or recorded_event.step_id == step_id)
            and (event_type is None or recorded_event.type == event_type)
        ]

    def list_serializable_recorded_events(self) -> list[dict[str, object]]:
        return [
            {
                "schema_version": recorded_event.schema_version,
                "type": recorded_event.type,
                "timestamp": recorded_event.timestamp,
                "run_id": recorded_event.run_id,
                "trace_id": recorded_event.trace_id,
                "correlation_id": recorded_event.correlation_id,
                "project_id": recorded_event.project_id,
                "tenant_id": recorded_event.tenant_id,
                "step_id": recorded_event.step_id,
                "details": dict(recorded_event.details),
            }
            for recorded_event in self.recorded_events
        ]
