from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Iterable

from .base import TraceCallbackFailureMode, TraceCallbackHandler

if TYPE_CHECKING:
    from loguit.core_types import RunContext
    from loguit.state import ExecutionEvent, RunState


EVENT_TYPE_TO_TRACE_CALLBACK_HANDLER_METHOD_NAME = {
    "run_started": "on_run_started",
    "run_completed": "on_run_completed",
    "run_checkpointed": "on_run_checkpointed",
    "run_resumed": "on_run_resumed",
    "run_terminated": "on_run_terminated",
    "policy_check_blocked": "on_policy_check_blocked",
    "retry_scheduled": "on_retry_scheduled",
    "retry_succeeded": "on_retry_succeeded",
    "retry_exhausted": "on_retry_exhausted",
    "model_call_started": "on_model_call_started",
    "model_call_succeeded": "on_model_call_succeeded",
    "model_call_failed": "on_model_call_failed",
    "tool_call_started": "on_tool_call_started",
    "tool_call_succeeded": "on_tool_call_succeeded",
    "tool_call_failed": "on_tool_call_failed",
    "tool_call_history_pruned": "on_tool_call_history_pruned",
    "compacted": "on_compacted",
}


def normalize_trace_callback_failure_mode(
    trace_callback_failure_mode: TraceCallbackFailureMode | str,
) -> TraceCallbackFailureMode:
    if isinstance(trace_callback_failure_mode, TraceCallbackFailureMode):
        return trace_callback_failure_mode
    return TraceCallbackFailureMode(trace_callback_failure_mode)


@dataclass
class TraceCallbackManager:
    trace_callback_handlers: list[TraceCallbackHandler] = field(default_factory=list)
    trace_callback_failure_mode: TraceCallbackFailureMode = TraceCallbackFailureMode.BEST_EFFORT

    def handle_event(self, event: "ExecutionEvent", *, context: "RunContext", state: "RunState") -> None:
        for trace_callback_handler in self.trace_callback_handlers:
            try:
                self._dispatch_event_to_handler(trace_callback_handler, event, context=context, state=state)
            except Exception as exc:  # noqa: BLE001
                if self.trace_callback_failure_mode is TraceCallbackFailureMode.FAIL_FAST:
                    raise
                self._record_trace_callback_handler_error(
                    trace_callback_handler,
                    event,
                    exc,
                    context=context,
                    state=state,
                )

    def _dispatch_event_to_handler(
        self,
        trace_callback_handler: TraceCallbackHandler,
        event: "ExecutionEvent",
        *,
        context: "RunContext",
        state: "RunState",
    ) -> None:
        method_name = EVENT_TYPE_TO_TRACE_CALLBACK_HANDLER_METHOD_NAME.get(event.type)
        if method_name is not None:
            specialized_callback_method = getattr(trace_callback_handler, method_name, None)
            if callable(specialized_callback_method):
                specialized_callback_method(event, context=context, state=state)
        generic_callback_method = getattr(trace_callback_handler, "on_event", None)
        if callable(generic_callback_method):
            generic_callback_method(event, context=context, state=state)

    def _record_trace_callback_handler_error(
        self,
        trace_callback_handler: TraceCallbackHandler,
        event: "ExecutionEvent",
        callback_error: Exception,
        *,
        context: "RunContext",
        state: "RunState",
    ) -> None:
        _ = context
        from loguit.state import ErrorRecord

        handler_name = trace_callback_handler.__class__.__name__
        error_message = (
            f"Trace callback handler '{handler_name}' failed while handling event '{event.type}': {callback_error}"
        )
        state.errors.append(
            ErrorRecord(
                error_type="trace_callback_handler_error",
                message=error_message,
                step_id=event.step_id,
            )
        )


def resolve_trace_callback_manager(
    context: "RunContext",
    trace_callback_handlers: Iterable[TraceCallbackHandler] | None = None,
    trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
) -> TraceCallbackManager | None:
    existing_trace_callback_manager = context.trace_callback_manager
    if trace_callback_handlers is None:
        return existing_trace_callback_manager
    combined_trace_callback_handlers = list(trace_callback_handlers)
    if existing_trace_callback_manager is not None:
        combined_trace_callback_handlers = (
            list(existing_trace_callback_manager.trace_callback_handlers) + combined_trace_callback_handlers
        )
    return TraceCallbackManager(
        trace_callback_handlers=combined_trace_callback_handlers,
        trace_callback_failure_mode=normalize_trace_callback_failure_mode(trace_callback_failure_mode),
    )


def dispatch_recorded_event_to_trace_callback_manager(
    event: "ExecutionEvent",
    *,
    context: "RunContext",
    state: "RunState",
) -> None:
    trace_callback_manager = context.trace_callback_manager
    if trace_callback_manager is None:
        return
    trace_callback_manager.handle_event(event, context=context, state=state)
