from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Iterable, Sequence

from ..callbacks import TraceCallbackFailureMode, TraceCallbackHandler
from ..core_types import Message, ModelResult, ModelSettings, ModelStreamEvent, RunContext
from ..tools import Tool


class Model(ABC):
    name: str
    tool_calling: str = "off"

    @abstractmethod
    def generate(
        self,
        messages: Sequence[Message],
        context: RunContext,
        settings: ModelSettings | None = None,
        tools: Iterable[Tool] | None = None,
        tool_choice: str | dict | None = None,
        parallel_tool_calls: bool | None = None,
        strict: bool | None = None,
    ) -> ModelResult:
        raise NotImplementedError

    def invoke(
        self,
        input_text: str,
        *,
        context: RunContext | None = None,
        settings: ModelSettings | None = None,
        trace_callback_handlers: Iterable[TraceCallbackHandler] | None = None,
        trace_callback_failure_mode: TraceCallbackFailureMode | str = TraceCallbackFailureMode.BEST_EFFORT,
    ) -> str:
        from ..core_types import Message, Role
        from ..runtime import call_model

        model_result = call_model(
            self,
            [Message(role=Role.USER, message_content=input_text)],
            context=context,
            settings=settings,
            trace_callback_handlers=trace_callback_handlers,
            trace_callback_failure_mode=trace_callback_failure_mode,
        )
        if model_result.content is None:
            raise ValueError("Model did not return text content")
        return model_result.content

    def stream(
        self,
        messages: Sequence[Message],
        context: RunContext | None,
        settings: ModelSettings | None = None,
        tools: Iterable[Tool] | None = None,
        tool_choice: str | dict | None = None,
        parallel_tool_calls: bool | None = None,
        strict: bool | None = None,
    ) -> Iterable[ModelStreamEvent]:
        _ = messages
        _ = context
        _ = settings
        _ = tools
        _ = tool_choice
        _ = parallel_tool_calls
        _ = strict
        raise NotImplementedError("Streaming is not supported for this model")
