from __future__ import annotations

import json
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from ..core_types import Message, Role, ToolCall
from ..tools import Tool
from .utils import get_attr


def encode_tool_args(args: Any) -> str:
    if isinstance(args, str):
        return args
    try:
        return json.dumps(args)
    except TypeError:
        return json.dumps({"_raw": str(args)})


def coerce_tool_calls(raw_calls: Any) -> List[ToolCall]:
    normalized_tool_calls: List[ToolCall] = []
    if isinstance(raw_calls, list):
        for tool_call_entry in raw_calls:
            if isinstance(tool_call_entry, ToolCall):
                normalized_tool_calls.append(tool_call_entry)
                continue
            if isinstance(tool_call_entry, dict):
                tool_name = tool_call_entry.get("name")
                parsed_tool_arguments = tool_call_entry.get("args", {})
                tool_call_identifier = tool_call_entry.get("call_id")
                if isinstance(tool_name, str):
                    normalized_tool_calls.append(
                        ToolCall(
                            name=tool_name,
                            args=parsed_tool_arguments if isinstance(parsed_tool_arguments, dict) else {},
                            call_id=tool_call_identifier,
                        )
                    )
    return normalized_tool_calls


def extract_chat_content(response: Any) -> Optional[str]:
    choices = get_attr(response, "choices") or []
    if isinstance(choices, dict):
        choices = [choices]
    if not choices:
        return None
    message = get_attr(choices[0], "message") or get_attr(choices[0], "delta") or choices[0]
    return get_attr(message, "content")


def extract_chat_tool_calls(response: Any) -> List[ToolCall]:
    choices = get_attr(response, "choices") or []
    if isinstance(choices, dict):
        choices = [choices]
    if not choices:
        return []
    message = get_attr(choices[0], "message") or get_attr(choices[0], "delta") or choices[0]
    tool_calls = get_attr(message, "tool_calls") or []
    calls: List[ToolCall] = []
    if isinstance(tool_calls, dict):
        tool_calls = [tool_calls]
    if isinstance(tool_calls, list):
        for call in tool_calls:
            name = get_attr(get_attr(call, "function"), "name") or get_attr(call, "name")
            if not name:
                continue
            args_raw = get_attr(get_attr(call, "function"), "arguments") or get_attr(call, "arguments") or {}
            if isinstance(args_raw, str):
                try:
                    args = json.loads(args_raw)
                except json.JSONDecodeError:
                    args = {"_raw": args_raw}
            elif isinstance(args_raw, dict):
                args = args_raw
            else:
                args = {"_raw": args_raw}
            call_id = get_attr(call, "id") or get_attr(call, "call_id")
            calls.append(ToolCall(name=name, args=args, call_id=call_id))
    function_call = get_attr(message, "function_call")
    if not calls and function_call:
        name = get_attr(function_call, "name")
        if name:
            args_raw = get_attr(function_call, "arguments") or {}
            if isinstance(args_raw, str):
                try:
                    args = json.loads(args_raw)
                except json.JSONDecodeError:
                    args = {"_raw": args_raw}
            elif isinstance(args_raw, dict):
                args = args_raw
            else:
                args = {"_raw": args_raw}
            calls.append(ToolCall(name=name, args=args))
    return calls


def extract_anthropic_text(response: Any) -> Optional[str]:
    content = get_attr(response, "content") or []
    text_content_segments: List[str] = []
    for content_block in content:
        if get_attr(content_block, "type") != "text":
            continue
        extracted_text_segment = get_attr(content_block, "text")
        if extracted_text_segment:
            text_content_segments.append(extracted_text_segment)
    if not text_content_segments:
        return None
    return "".join(text_content_segments)


def extract_anthropic_tool_calls(response: Any) -> List[ToolCall]:
    content = get_attr(response, "content") or []
    extracted_tool_calls: List[ToolCall] = []
    for content_block in content:
        if get_attr(content_block, "type") != "tool_use":
            continue
        tool_name = get_attr(content_block, "name")
        if not tool_name:
            continue
        raw_tool_arguments = get_attr(content_block, "input") or {}
        if isinstance(raw_tool_arguments, dict):
            parsed_tool_arguments = raw_tool_arguments
        else:
            parsed_tool_arguments = {"_raw": raw_tool_arguments}
        tool_call_identifier = get_attr(content_block, "id") or get_attr(content_block, "tool_use_id")
        extracted_tool_calls.append(
            ToolCall(name=tool_name, args=parsed_tool_arguments, call_id=tool_call_identifier)
        )
    return extracted_tool_calls


def extract_output_text(response: Any) -> Optional[str]:
    output = get_attr(response, "output")
    if not output:
        return None

    output_text_segments: List[str] = []
    for output_entry in output:
        if get_attr(output_entry, "type") != "message":
            continue
        message_content_entries = get_attr(output_entry, "content") or []
        for message_content_entry in message_content_entries:
            if get_attr(message_content_entry, "type") == "output_text":
                extracted_text_segment = get_attr(message_content_entry, "text")
                if extracted_text_segment:
                    output_text_segments.append(extracted_text_segment)
    if not output_text_segments:
        return None
    return "".join(output_text_segments)


def extract_tool_calls(response: Any) -> List[ToolCall]:
    output = get_attr(response, "output") or []
    extracted_tool_calls: List[ToolCall] = []
    for output_entry in output:
        if get_attr(output_entry, "type") != "function_call":
            continue
        tool_name = get_attr(output_entry, "name")
        if not tool_name:
            continue
        raw_tool_arguments = get_attr(output_entry, "arguments") or {}
        if isinstance(raw_tool_arguments, str):
            try:
                parsed_tool_arguments = json.loads(raw_tool_arguments)
            except json.JSONDecodeError:
                parsed_tool_arguments = {"_raw": raw_tool_arguments}
        elif isinstance(raw_tool_arguments, dict):
            parsed_tool_arguments = raw_tool_arguments
        else:
            parsed_tool_arguments = {"_raw": raw_tool_arguments}
        tool_call_identifier = get_attr(output_entry, "call_id")
        extracted_tool_calls.append(
            ToolCall(name=tool_name, args=parsed_tool_arguments, call_id=tool_call_identifier)
        )
    return extracted_tool_calls


def tools_payload(tools: Iterable[Tool], *, strict: bool | None = None) -> List[Dict[str, Any]]:
    payload: List[Dict[str, Any]] = []
    for tool in tools:
        spec = tool.spec
        function_obj: Dict[str, Any] = {
            "name": spec.name,
            "description": spec.description,
            "parameters": spec.args_schema,
        }
        if strict is not None:
            function_obj["strict"] = strict
        payload.append({"type": "function", "function": function_obj})
    return payload


def tools_payload_anthropic(tools: Iterable[Tool]) -> List[Dict[str, Any]]:
    payload: List[Dict[str, Any]] = []
    for tool in tools:
        spec = tool.spec
        payload.append(
            {
                "name": spec.name,
                "description": spec.description,
                "input_schema": spec.args_schema,
            }
        )
    return payload


def messages_to_chat_payload(messages: Sequence[Message]) -> List[Dict[str, Any]]:
    payload: List[Dict[str, Any]] = []
    for message in messages:
        message_payload_entry: Dict[str, Any] = {
            "role": message.role.value,
            "content": message.message_content,
        }
        if message.name:
            message_payload_entry["name"] = message.name
        if message.role == Role.ASSISTANT:
            tool_calls = coerce_tool_calls(message.metadata.get("tool_calls"))
            if tool_calls:
                call_payloads: List[Dict[str, Any]] = []
                for tool_call in tool_calls:
                    call_payload = {
                        "type": "function",
                        "function": {"name": tool_call.name, "arguments": encode_tool_args(tool_call.args)},
                    }
                    if tool_call.call_id:
                        call_payload["id"] = tool_call.call_id
                    call_payloads.append(call_payload)
                message_payload_entry["tool_calls"] = call_payloads
        if message.role == Role.TOOL:
            tool_call_id = message.metadata.get("tool_call_id")
            if tool_call_id:
                message_payload_entry["tool_call_id"] = tool_call_id
        payload.append(message_payload_entry)
    return payload


def messages_to_responses_payload(messages: Sequence[Message]) -> List[Dict[str, Any]]:
    payload: List[Dict[str, Any]] = []
    for message in messages:
        message_payload_entry: Dict[str, Any] = {
            "role": message.role.value,
            "content": message.message_content,
        }
        if message.name:
            message_payload_entry["name"] = message.name
        if message.role == Role.ASSISTANT:
            tool_calls = coerce_tool_calls(message.metadata.get("tool_calls"))
            if tool_calls:
                message_payload_entry["tool_calls"] = [
                    {
                        "id": tool_call.call_id,
                        "type": "function",
                        "function": {"name": tool_call.name, "arguments": encode_tool_args(tool_call.args)},
                    }
                    for tool_call in tool_calls
                ]
        if message.role == Role.TOOL:
            tool_call_id = message.metadata.get("tool_call_id")
            if tool_call_id:
                message_payload_entry["tool_call_id"] = tool_call_id
        payload.append(message_payload_entry)
    return payload


def normalize_anthropic_tool_choice(tool_choice: str | dict) -> dict:
    if isinstance(tool_choice, dict):
        return tool_choice
    lowered = tool_choice.lower()
    if lowered in {"auto", "any", "none"}:
        return {"type": lowered}
    return {"type": "tool", "name": tool_choice}


def messages_to_anthropic_payload(messages: Sequence[Message]) -> Tuple[Optional[str], List[Dict[str, Any]]]:
    system_parts: List[str] = []
    payload: List[Dict[str, Any]] = []
    for message in messages:
        if message.role == Role.SYSTEM:
            system_parts.append(message.message_content)
            continue
        if message.role == Role.TOOL:
            tool_call_id = message.metadata.get("tool_call_id")
            if tool_call_id:
                payload.append(
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "tool_result",
                                "tool_use_id": tool_call_id,
                                "content": message.message_content,
                            }
                        ],
                    }
                )
            else:
                payload.append({"role": "user", "content": message.message_content})
            continue
        if message.role == Role.ASSISTANT:
            tool_calls = coerce_tool_calls(message.metadata.get("tool_calls"))
            if tool_calls:
                content_blocks: List[Dict[str, Any]] = []
                if message.message_content:
                    content_blocks.append({"type": "text", "text": message.message_content})
                for tool_call in tool_calls:
                    if tool_call.call_id is None:
                        continue
                    content_blocks.append(
                        {
                            "type": "tool_use",
                            "id": tool_call.call_id,
                            "name": tool_call.name,
                            "input": tool_call.args,
                        }
                    )
                if content_blocks:
                    payload.append({"role": "assistant", "content": content_blocks})
                    continue
        payload.append({"role": message.role.value, "content": message.message_content})
    system = "\n\n".join(system_parts) if system_parts else None
    return system, payload
