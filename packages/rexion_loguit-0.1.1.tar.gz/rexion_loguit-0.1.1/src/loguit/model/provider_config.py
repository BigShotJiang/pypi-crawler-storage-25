from __future__ import annotations

import os
from typing import Any, Dict, Iterable, Optional, Tuple


def _is_url(candidate_url: str) -> bool:
    return candidate_url.startswith("http://") or candidate_url.startswith("https://")


_PROVIDER_ALIASES: Dict[str, str] = {
    "openai": "openai",
    "openrouter": "openrouter",
    "anthropic": "anthropic",
    "claude": "anthropic",
    "nim": "nvidia_nim",
    "nvidia": "nvidia_nim",
    "nvidia_nim": "nvidia_nim",
    "glm": "glm",
    "zhipu": "glm",
}

_PROVIDER_DEFAULTS: Dict[str, Dict[str, Any]] = {
    "openrouter": {
        "base_url": "https://openrouter.ai/api/v1",
        "api_key_envs": ["OPENROUTER_API_KEY"],
    },
    "anthropic": {"api_key_envs": ["ANTHROPIC_API_KEY"]},
    "nvidia_nim": {
        "base_url": "https://integrate.api.nvidia.com/v1",
        "api_key_envs": ["NVIDIA_API_KEY"],
        "base_url_envs": ["NVIDIA_BASE_URL", "NVIDIA_NIM_BASE_URL"],
    },
    "glm": {
        "base_url": "https://open.bigmodel.cn/api/paas/v4",
        "api_key_envs": ["GLM_API_KEY", "ZHIPUAI_API_KEY"],
    },
}

_PROVIDER_PREFIXES: Tuple[Tuple[str, Tuple[str, ...]], ...] = (
    ("openai", ("gpt-", "o1", "o3")),
    ("anthropic", ("claude",)),
    ("glm", ("glm-", "glm_", "glm/")),
    ("nvidia_nim", ("nim-", "nim/", "nvidia-", "nvidia/")),
)


def _normalize_provider(provider: str) -> str:
    return _PROVIDER_ALIASES.get(provider, provider)


def _get_env_value(keys: Iterable[str]) -> Optional[str]:
    for environment_variable_name in keys:
        environment_variable_value = os.getenv(environment_variable_name)
        if environment_variable_value:
            return environment_variable_value
    return None


def _strip_provider_prefix(provider: str, model_name: str) -> str:
    for alias, canonical in _PROVIDER_ALIASES.items():
        if canonical != provider:
            continue
        prefix = f"{alias}:"
        if model_name.startswith(prefix):
            return model_name[len(prefix):]
    return model_name


def _apply_provider_override(model: str, model_provider: str) -> Tuple[str, str]:
    return _normalize_provider(model_provider), model


def _split_provider_model(model: str) -> Tuple[Optional[str], str]:
    if ":" in model:
        provider, model_name = model.split(":", 1)
        if provider in _PROVIDER_ALIASES or provider in {"openai", "openrouter"} or _is_url(provider):
            return _normalize_provider(provider), model_name
    return None, model


def _split_provider(model: str, model_provider: Optional[str]) -> Tuple[Optional[str], str]:
    if model_provider is not None:
        return _apply_provider_override(model, model_provider)
    return _split_provider_model(model)


def _infer_provider(model_name: str) -> Optional[str]:
    lower = model_name.lower()
    for provider, prefixes in _PROVIDER_PREFIXES:
        if lower.startswith(prefixes):
            return provider
    if "/" in model_name:
        return "openrouter"
    return None


def _pop_keys(kwargs: dict[str, Any], keys: Iterable[str]) -> dict[str, Any]:
    extracted_keyword_arguments: dict[str, Any] = {}
    for keyword_name in keys:
        if keyword_name in kwargs:
            extracted_keyword_arguments[keyword_name] = kwargs.pop(keyword_name)
    return extracted_keyword_arguments
