from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple, Union

from ..core_types import ModelConfig, ModelSettings
from .base import Model
from . import provider_config
from .providers import AnthropicModel, OpenAIChatCompletionsModel, OpenAIResponsesModel


def init_model(
    model: str | None = None,
    *,
    model_provider: str | None = None,
    configurable_fields: str | List[str] | Tuple[str, ...] | None = None,
    config_prefix: str | None = None,
    tool_calling: str | None = None,
    **kwargs: Any,
) -> Model:
    if model is None:
        raise ValueError("init_model requires a model name in V1")

    if configurable_fields is not None or config_prefix is not None:
        raise NotImplementedError("Configurable models are not supported in V1")

    split_provider_model = getattr(
        provider_config,
        "_split_provider_model_by_colon",
        provider_config._split_provider,
    )
    provider, model_name = split_provider_model(model, model_provider)
    provider_value = provider
    provider_is_url = provider is not None and provider_config._is_url(provider)
    if provider_is_url:
        provider = "openai_compatible"
    if provider is None and model_provider is not None and provider_config._is_url(model_provider):
        provider = "openai_compatible"
    if provider is None:
        provider = provider_config._infer_provider(model_name)

    if provider is None:
        raise ValueError("Could not infer model provider; pass model_provider explicitly")

    provider = provider_config._normalize_provider(provider)
    if provider not in {"openai", "openrouter", "openai_compatible", "anthropic", "nvidia_nim", "glm"}:
        raise ValueError(
            "Only model_provider in {'openai','openrouter','anthropic','nvidia_nim','glm'} "
            "or a provider base URL is supported in V1"
        )

    if provider in {"openai", "openrouter", "anthropic", "nvidia_nim", "glm"}:
        model_name = provider_config._strip_provider_prefix(provider, model_name)

    if tool_calling is None:
        if provider in {"openai", "anthropic", "nvidia_nim", "glm"}:
            tool_calling = "native"
        else:
            tool_calling = "off"

    temperature = kwargs.pop("temperature", None)
    max_output_tokens = kwargs.pop("max_output_tokens", None)
    extra_body = kwargs.pop("extra_body", None)

    client_kwargs = provider_config._pop_keys(kwargs, ["api_key", "base_url", "organization"])

    defaults = provider_config._PROVIDER_DEFAULTS.get(provider, {})
    if "base_url" not in client_kwargs:
        base_url_envs = defaults.get("base_url_envs", [])
        if base_url_envs:
            env_base = provider_config._get_env_value(base_url_envs)
            if env_base:
                client_kwargs["base_url"] = env_base
        if "base_url" not in client_kwargs and defaults.get("base_url"):
            client_kwargs["base_url"] = defaults["base_url"]

    if "api_key" not in client_kwargs:
        env_keys = defaults.get("api_key_envs", [])
        if env_keys:
            env_key = provider_config._get_env_value(env_keys)
            if env_key:
                client_kwargs["api_key"] = env_key

    if provider == "openrouter" and "api_key" not in client_kwargs:
        raise ValueError("Openrouter API key is not set!")
    if provider in {"anthropic", "nvidia_nim", "glm"} and "api_key" not in client_kwargs:
        raise ValueError(f"{provider} API key is not set!")
    if provider == "openai_compatible":
        if "base_url" not in client_kwargs:
            if model_provider is not None and provider_config._is_url(model_provider):
                client_kwargs["base_url"] = model_provider
            elif provider_is_url and provider_value is not None:
                client_kwargs["base_url"] = provider_value
        if "base_url" not in client_kwargs:
            raise ValueError("model_provider URL must be provided for openai-compatible providers")

    if provider == "nvidia_nim":
        if not isinstance(extra_body, dict):
            extra_body = {}
        extra_body.setdefault("enable_auto_tool_choice", True)
        extra_body.setdefault("tool_call_parser", "llama3_json")

    model_settings = ModelSettings(
        temperature=temperature,
        max_output_tokens=max_output_tokens,
        extra=kwargs,
    )

    if provider == "openai":
        return OpenAIResponsesModel(
            model_name,
            client_kwargs=client_kwargs,
            default_settings=model_settings,
            tool_calling=tool_calling,
        )
    if provider == "anthropic":
        return AnthropicModel(
            model_name,
            client_kwargs=client_kwargs,
            default_settings=model_settings,
            tool_calling=tool_calling,
        )
    return OpenAIChatCompletionsModel(
        model_name,
        client_kwargs=client_kwargs,
        default_settings=model_settings,
        tool_calling=tool_calling,
        extra_body=extra_body,
    )


def _load_config(config: Union[ModelConfig, str, Path]) -> ModelConfig:
    if isinstance(config, Path):
        return json.loads(config.read_text())
    if isinstance(config, str):
        path = Path(config)
        if path.exists():
            return json.loads(path.read_text())
        return json.loads(config)
    return config


def init_model_from_config(config: Union[ModelConfig, str, Path]) -> Model:
    cfg = _load_config(config)
    model = cfg.get("model")
    model_provider = cfg.get("model_provider")
    tool_calling = cfg.get("tool_calling")
    settings = cfg.get("settings", {})
    client = cfg.get("client", {})
    extra = cfg.get("extra", {})

    kwargs: Dict[str, Any] = {}
    kwargs.update(client)
    kwargs.update(extra)
    if "temperature" in settings:
        kwargs["temperature"] = settings["temperature"]
    if "max_output_tokens" in settings:
        kwargs["max_output_tokens"] = settings["max_output_tokens"]

    return init_model(model, model_provider=model_provider, tool_calling=tool_calling, **kwargs)
