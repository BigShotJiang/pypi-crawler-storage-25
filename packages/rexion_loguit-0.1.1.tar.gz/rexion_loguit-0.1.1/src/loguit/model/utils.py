from __future__ import annotations

from typing import Any


def get_attr(attribute_source: Any, attribute_name: str, default_value: Any = None) -> Any:
    if isinstance(attribute_source, dict):
        return attribute_source.get(attribute_name, default_value)
    return getattr(attribute_source, attribute_name, default_value)
