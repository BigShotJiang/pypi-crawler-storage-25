from __future__ import annotations

from typing import Any, Dict, Optional

try:
    from openai import OpenAI
except ImportError:  # pragma: no cover - handled for test environments without openai
    OpenAI = None  # type: ignore[assignment]


class _MissingOpenAIResponses:
    def create(self, *args: Any, **kwargs: Any) -> None:  # noqa: ANN401
        raise RuntimeError("openai package is required to use OpenAI providers")


class _MissingOpenAIChatCompletions:
    def create(self, *args: Any, **kwargs: Any) -> None:  # noqa: ANN401
        raise RuntimeError("openai package is required to use OpenAI providers")


class _MissingOpenAIChat:
    def __init__(self) -> None:
        self.completions = _MissingOpenAIChatCompletions()


class _MissingOpenAIClient:
    def __init__(self) -> None:
        self.responses = _MissingOpenAIResponses()
        self.chat = _MissingOpenAIChat()


def build_openai_client(client_kwargs: Optional[Dict[str, Any]] = None):  # noqa: ANN001
    if OpenAI is None:
        return _MissingOpenAIClient()
    return OpenAI(**(client_kwargs or {}))
