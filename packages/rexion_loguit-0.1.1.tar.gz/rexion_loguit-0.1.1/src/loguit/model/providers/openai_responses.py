from __future__ import annotations

from typing import Any, Dict, Iterable, Optional, Sequence
from uuid import uuid4

from ..base import Model
from ...core_types import Message, ModelResult, ModelSettings, ModelStreamEvent, RunContext
from ...tools import Tool
from ..payloads import extract_output_text, extract_tool_calls, messages_to_responses_payload, tools_payload
from ..utils import get_attr
from .openai_shared import build_openai_client


class OpenAIResponsesModel(Model):
    def __init__(
        self,
        model: str,
        *,
        client=None,  # noqa: ANN001
        client_kwargs: Optional[Dict[str, Any]] = None,
        default_settings: Optional[ModelSettings] = None,
        tool_calling: str = "off",
    ) -> None:
        self.name = model
        self.tool_calling = tool_calling
        if client is None:
            client = build_openai_client(client_kwargs)
        self._client = client
        self._default_settings = default_settings

    def generate(
        self,
        messages: Sequence[Message],
        context: RunContext,
        settings: ModelSettings | None = None,
        tools: Iterable[Tool] | None = None,
        tool_choice: str | dict | None = None,
        parallel_tool_calls: bool | None = None,
        strict: bool | None = None,
    ) -> ModelResult:
        _ = context
        input_items = messages_to_responses_payload(messages)

        payload: Dict[str, Any] = {
            "model": self.name,
            "input": input_items,
        }

        if tools is not None and self.tool_calling == "native":
            payload["tools"] = tools_payload(tools, strict=strict)
            if tool_choice is not None:
                payload["tool_choice"] = tool_choice
            if parallel_tool_calls is not None:
                payload["parallel_tool_calls"] = parallel_tool_calls

        active_settings = settings or self._default_settings
        if active_settings is not None:
            if active_settings.temperature is not None:
                payload["temperature"] = active_settings.temperature
            if active_settings.max_output_tokens is not None:
                payload["max_output_tokens"] = active_settings.max_output_tokens
            if active_settings.extra:
                payload.update(active_settings.extra)

        response = self._client.responses.create(**payload)
        output_text = get_attr(response, "output_text")
        if output_text is None:
            output_text = extract_output_text(response)

        tool_calls = extract_tool_calls(response)
        if output_text is None and not tool_calls:
            raise ValueError("OpenAI response did not include text output")

        return ModelResult(content=output_text, tool_calls=tool_calls, raw=response)

    def stream(
        self,
        messages: Sequence[Message],
        context: RunContext | None,
        settings: ModelSettings | None = None,
        tools: Iterable[Tool] | None = None,
        tool_choice: str | dict | None = None,
        parallel_tool_calls: bool | None = None,
        strict: bool | None = None,
    ) -> Iterable[ModelStreamEvent]:
        _ = context or RunContext(run_id=str(uuid4()))
        input_items = messages_to_responses_payload(messages)

        payload: Dict[str, Any] = {
            "model": self.name,
            "input": input_items,
            "stream": True,
        }

        if tools is not None and self.tool_calling == "native":
            payload["tools"] = tools_payload(tools, strict=strict)
            if tool_choice is not None:
                payload["tool_choice"] = tool_choice
            if parallel_tool_calls is not None:
                payload["parallel_tool_calls"] = parallel_tool_calls

        active_settings = settings or self._default_settings
        if active_settings is not None:
            if active_settings.temperature is not None:
                payload["temperature"] = active_settings.temperature
            if active_settings.max_output_tokens is not None:
                payload["max_output_tokens"] = active_settings.max_output_tokens
            if active_settings.extra:
                payload.update(active_settings.extra)

        stream = self._client.responses.create(**payload)
        for event in stream:
            event_type = get_attr(event, "type") or "unknown"
            delta = None
            if event_type == "response.output_text.delta":
                delta = get_attr(event, "delta") or get_attr(event, "text")
            yield ModelStreamEvent(type=event_type, delta=delta, raw=event)
