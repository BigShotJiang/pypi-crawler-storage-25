from __future__ import annotations

from typing import Any, Dict, Iterable, Optional, Sequence

from ..base import Model
from ...core_types import Message, ModelResult, ModelSettings, RunContext
from ...tools import Tool
from ..payloads import extract_chat_content, extract_chat_tool_calls, messages_to_chat_payload, tools_payload
from .openai_shared import build_openai_client


class OpenAIChatCompletionsModel(Model):
    def __init__(
        self,
        model: str,
        *,
        client=None,  # noqa: ANN001
        client_kwargs: Optional[Dict[str, Any]] = None,
        default_settings: Optional[ModelSettings] = None,
        tool_calling: str = "off",
        extra_body: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.name = model
        self.tool_calling = tool_calling
        if client is None:
            client = build_openai_client(client_kwargs)
        self._client = client
        self._default_settings = default_settings
        self._extra_body = extra_body or {}

    def generate(
        self,
        messages: Sequence[Message],
        context: RunContext,
        settings: ModelSettings | None = None,
        tools: Iterable[Tool] | None = None,
        tool_choice: str | dict | None = None,
        parallel_tool_calls: bool | None = None,
        strict: bool | None = None,
    ) -> ModelResult:
        _ = context
        payload: Dict[str, Any] = {
            "model": self.name,
            "messages": messages_to_chat_payload(messages),
        }

        if tools is not None and self.tool_calling == "native":
            payload["tools"] = tools_payload(tools, strict=strict)
            if tool_choice is not None:
                payload["tool_choice"] = tool_choice
            if parallel_tool_calls is not None:
                payload["parallel_tool_calls"] = parallel_tool_calls

        active_settings = settings or self._default_settings
        extra_body = dict(self._extra_body) if self._extra_body else None
        if active_settings is not None:
            if active_settings.temperature is not None:
                payload["temperature"] = active_settings.temperature
            if active_settings.max_output_tokens is not None:
                payload["max_tokens"] = active_settings.max_output_tokens
            if active_settings.extra:
                extra = dict(active_settings.extra)
                if "extra_body" in extra:
                    extra_body_value = extra.pop("extra_body")
                    if isinstance(extra_body_value, dict):
                        if extra_body is None:
                            extra_body = {}
                        extra_body.update(extra_body_value)
                payload.update(extra)

        if extra_body:
            response = self._client.chat.completions.create(**payload, extra_body=extra_body)
        else:
            response = self._client.chat.completions.create(**payload)
        content = extract_chat_content(response)
        tool_calls = extract_chat_tool_calls(response)
        if content is None and not tool_calls:
            raise ValueError("Chat completion did not include text output")

        return ModelResult(content=content, tool_calls=tool_calls, raw=response)
