from __future__ import annotations

from typing import Any, Dict, Iterable, Optional, Sequence

from ..base import Model
from ...core_types import Message, ModelResult, ModelSettings, RunContext
from ...tools import Tool
from ..payloads import (
    extract_anthropic_text,
    extract_anthropic_tool_calls,
    messages_to_anthropic_payload,
    normalize_anthropic_tool_choice,
    tools_payload_anthropic,
)


class AnthropicModel(Model):
    def __init__(
        self,
        model: str,
        *,
        client: Any = None,
        client_kwargs: Optional[Dict[str, Any]] = None,
        default_settings: Optional[ModelSettings] = None,
        tool_calling: str = "off",
    ) -> None:
        self.name = model
        self.tool_calling = tool_calling
        if client is None:
            try:
                from anthropic import Anthropic  # type: ignore
            except ImportError as exc:  # pragma: no cover - exercised in integration
                raise RuntimeError("anthropic package is required for Anthropic models") from exc
            client = Anthropic(**(client_kwargs or {}))
        self._client = client
        self._default_settings = default_settings

    def generate(
        self,
        messages: Sequence[Message],
        context: RunContext,
        settings: ModelSettings | None = None,
        tools: Iterable[Tool] | None = None,
        tool_choice: str | dict | None = None,
        parallel_tool_calls: bool | None = None,
        strict: bool | None = None,
    ) -> ModelResult:
        _ = context
        _ = parallel_tool_calls
        _ = strict
        system, payload_messages = messages_to_anthropic_payload(messages)
        payload: Dict[str, Any] = {
            "model": self.name,
            "messages": payload_messages,
        }
        if system:
            payload["system"] = system

        if tools is not None and self.tool_calling == "native":
            payload["tools"] = tools_payload_anthropic(tools)
            if tool_choice is not None:
                payload["tool_choice"] = normalize_anthropic_tool_choice(tool_choice)

        active_settings = settings or self._default_settings
        max_tokens = 1024
        if active_settings is not None:
            if active_settings.temperature is not None:
                payload["temperature"] = active_settings.temperature
            if active_settings.max_output_tokens is not None:
                max_tokens = active_settings.max_output_tokens
            if active_settings.extra:
                payload.update(active_settings.extra)
        payload["max_tokens"] = max_tokens

        response = self._client.messages.create(**payload)
        content = extract_anthropic_text(response)
        tool_calls = extract_anthropic_tool_calls(response)
        if content is None and not tool_calls:
            raise ValueError("Anthropic response did not include text output")

        return ModelResult(content=content, tool_calls=tool_calls, raw=response)
