"""Top-level operator dashboard launcher for local Aegis checkouts."""

from __future__ import annotations

from argparse import SUPPRESS, ArgumentParser
from dataclasses import dataclass
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import webbrowser

from apps.cli.cli_main_support import CliCardSection, _print_cli_card


REPO_ROOT = Path(__file__).resolve().parents[1]
DASHBOARD_APP_DIR = REPO_ROOT / "apps" / "dashboard"
DASHBOARD_PACKAGE_PATH = DASHBOARD_APP_DIR / "package.json"
DASHBOARD_NODE_MODULES = DASHBOARD_APP_DIR / "node_modules"
DASHBOARD_DIST_INDEX = DASHBOARD_APP_DIR / "dist" / "index.html"


@dataclass(frozen=True, slots=True)
class DashboardLaunchPlan:
    state_dir: Path
    profile_dir: Path
    api_database: Path
    api_host: str
    api_port: int
    ui_host: str
    ui_port: int
    ui_mode: str
    dashboard_assets_present: bool
    frontend_dependencies_present: bool
    preview_bundle_present: bool
    npm_available: bool

    @property
    def api_url(self) -> str:
        return f"http://{self.api_host}:{self.api_port}"

    @property
    def ui_url(self) -> str:
        return f"http://{self.ui_host}:{self.ui_port}"


def _build_parser(
    *,
    default_state_dir: Path | None = None,
    default_profile_dir: Path | None = None,
) -> ArgumentParser:
    parser = ArgumentParser(
        prog="aegis dashboard",
        description="Launch the local operator dashboard when frontend assets are present.",
    )
    parser.add_argument("--state-dir", default=default_state_dir, type=Path, help=SUPPRESS)
    parser.add_argument("--profile-dir", default=default_profile_dir, type=Path, help=SUPPRESS)
    parser.add_argument("--api-database", default=None, type=Path, help="Override the API database path.")
    parser.add_argument("--api-host", default="127.0.0.1")
    parser.add_argument("--api-port", default=8000, type=int)
    parser.add_argument("--host", dest="ui_host", default="127.0.0.1")
    parser.add_argument("--port", dest="ui_port", default=4174, type=int)
    parser.add_argument("--ui-mode", choices=("dev", "preview"), default="dev")
    parser.add_argument("--open", action="store_true", help="Open the dashboard URL in the default browser.")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the launch plan and readiness notes without starting any processes.",
    )
    return parser


def _build_plan(args) -> DashboardLaunchPlan:
    state_dir = Path(args.state_dir).expanduser()
    profile_dir = Path(args.profile_dir).expanduser()
    api_database = (
        Path(args.api_database).expanduser()
        if args.api_database is not None
        else state_dir / "aegis.sqlite3"
    )
    return DashboardLaunchPlan(
        state_dir=state_dir,
        profile_dir=profile_dir,
        api_database=api_database,
        api_host=str(args.api_host),
        api_port=int(args.api_port),
        ui_host=str(args.ui_host),
        ui_port=int(args.ui_port),
        ui_mode=str(args.ui_mode),
        dashboard_assets_present=DASHBOARD_PACKAGE_PATH.exists(),
        frontend_dependencies_present=DASHBOARD_NODE_MODULES.exists(),
        preview_bundle_present=DASHBOARD_DIST_INDEX.exists(),
        npm_available=shutil.which("npm") is not None,
    )


def _print_plan(plan: DashboardLaunchPlan, *, ready_to_launch: bool) -> None:
    dependency_state = "ready" if plan.frontend_dependencies_present else "missing"
    asset_state = "present" if plan.dashboard_assets_present else "missing"
    preview_state = "present" if plan.preview_bundle_present else "missing"
    npm_state = "ready" if plan.npm_available else "missing"
    sections = [
        CliCardSection(
            "Launch plan",
            (
                f"state_dir · {plan.state_dir}",
                f"profile_dir · {plan.profile_dir}",
                f"api_database · {plan.api_database}",
                f"api_url · {plan.api_url}",
                f"ui_url · {plan.ui_url}",
                f"ui_mode · {plan.ui_mode}",
            ),
        ),
        CliCardSection(
            "Readiness",
            (
                f"dashboard_assets · {asset_state}",
                f"npm · {npm_state}",
                f"frontend_dependencies · {dependency_state}",
                f"preview_bundle · {preview_state}",
                f"ready_to_launch · {'yes' if ready_to_launch else 'no'}",
            ),
        ),
    ]
    next_commands: tuple[str, ...] = ()
    if not plan.dashboard_assets_present:
        sections.append(
            CliCardSection(
                "Recovery",
                (
                    "This install does not include apps/dashboard frontend assets.",
                    "Use a local repo checkout and its launcher when you need the operator web surface.",
                ),
            )
        )
    elif not plan.frontend_dependencies_present:
        sections.append(
            CliCardSection(
                "Recovery",
                (
                    "Install the dashboard frontend dependencies first:",
                    "npm --prefix apps/dashboard ci",
                ),
            )
        )
        next_commands = ("npm --prefix apps/dashboard ci", "aegis dashboard")
    elif plan.ui_mode == "preview" and not plan.preview_bundle_present:
        sections.append(
            CliCardSection(
                "Recovery",
                (
                    "Preview mode needs a built frontend bundle first:",
                    "npm --prefix apps/dashboard run build",
                ),
            )
        )
        next_commands = ("npm --prefix apps/dashboard run build", "aegis dashboard --ui-mode preview")
    _print_cli_card(
        "Aegis dashboard",
        "Operator dashboard launch plan over the live CLI state database.",
        sections=tuple(sections),
        next_commands=next_commands,
    )


def _terminate_process(process: subprocess.Popen[str] | None) -> None:
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def _ui_command(plan: DashboardLaunchPlan) -> list[str]:
    command = ["npm", "--prefix", str(DASHBOARD_APP_DIR), "run", plan.ui_mode]
    if plan.ui_mode == "dev":
        command.extend(["--", "--host", plan.ui_host, "--port", str(plan.ui_port)])
    else:
        command.extend(["--", "--host", plan.ui_host, "--port", str(plan.ui_port)])
    return command


def _run_dashboard(plan: DashboardLaunchPlan, *, open_browser: bool) -> int:
    if not plan.dashboard_assets_present:
        _print_plan(plan, ready_to_launch=False)
        return 1
    if not plan.npm_available:
        _print_cli_card(
            "Aegis dashboard",
            "npm is required to launch the dashboard frontend.",
            sections=(CliCardSection("Recovery", ("Install Node.js and npm, then rerun `aegis dashboard`.",)),),
        )
        return 1
    if not plan.frontend_dependencies_present:
        _print_plan(plan, ready_to_launch=False)
        return 1
    if plan.ui_mode == "preview" and not plan.preview_bundle_present:
        _print_plan(plan, ready_to_launch=False)
        return 1

    api_command = [
        sys.executable,
        "-m",
        "apps.api",
        "--host",
        plan.api_host,
        "--port",
        str(plan.api_port),
        "--database",
        str(plan.api_database),
    ]
    ui_env = os.environ.copy()
    ui_env["VITE_AEGIS_API_BASE_URL"] = plan.api_url

    _print_cli_card(
        "Aegis dashboard",
        "Launching the operator dashboard against the live CLI state database.",
        sections=(
            CliCardSection(
                "Endpoints",
                (
                    f"api_url · {plan.api_url}",
                    f"ui_url · {plan.ui_url}",
                    f"api_database · {plan.api_database}",
                ),
            ),
        ),
    )

    api_process: subprocess.Popen[str] | None = None
    ui_process: subprocess.Popen[str] | None = None
    try:
        api_process = subprocess.Popen(api_command, cwd=REPO_ROOT, text=True)
        time.sleep(0.5)
        if api_process.poll() is not None:
            return api_process.returncode or 1
        ui_process = subprocess.Popen(_ui_command(plan), cwd=REPO_ROOT, env=ui_env, text=True)
        time.sleep(0.8)
        if ui_process.poll() is not None:
            return ui_process.returncode or 1
        if open_browser:
            webbrowser.open(plan.ui_url)
        while True:
            if api_process.poll() is not None:
                return api_process.returncode or 1
            if ui_process.poll() is not None:
                return ui_process.returncode or 1
            time.sleep(0.5)
    except KeyboardInterrupt:
        print("\nStopping Aegis dashboard...")
        return 0
    finally:
        _terminate_process(ui_process)
        _terminate_process(api_process)


def command_main(
    argv: list[str] | None = None,
    *,
    default_state_dir: Path | None = None,
    default_profile_dir: Path | None = None,
) -> int:
    parser = _build_parser(
        default_state_dir=default_state_dir,
        default_profile_dir=default_profile_dir,
    )
    args = parser.parse_args(argv)
    plan = _build_plan(args)
    ready_to_launch = (
        plan.dashboard_assets_present
        and plan.npm_available
        and plan.frontend_dependencies_present
        and (plan.ui_mode != "preview" or plan.preview_bundle_present)
    )
    if args.dry_run:
        _print_plan(plan, ready_to_launch=ready_to_launch)
        return 0
    return _run_dashboard(plan, open_browser=bool(args.open))


__all__ = ["command_main"]
