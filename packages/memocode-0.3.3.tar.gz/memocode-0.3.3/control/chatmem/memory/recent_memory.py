"""
Recent memory: compressed summaries from past sessions.
Grows unboundedly — entries are never re-compressed or deleted.
Newest entries injected into context (4k cap); full history searchable via memory_search tool.
"""

import sqlite3
import time
from datetime import datetime

from ..token_counter import count_tokens
from ..compressor import Compressor


class RecentMemory:
    """
    Stores LLM-compressed session summaries.
    - Context injection: newest entries up to INJECT_TOKEN_CAP per turn
    - Full recall: via memory_search tool (searches all entries)
    - No storage limit: entries accumulate indefinitely
    """

    INJECT_TOKEN_CAP = 4000

    def __init__(
        self,
        db_path: str,
        compressor: Compressor,
        inject_token_cap: int | None = None,
        token_budget: int | None = None,  # ignored, kept for API compatibility
    ):
        self.db_path = db_path
        self.compressor = compressor
        self._inject_token_cap = inject_token_cap or self.INJECT_TOKEN_CAP
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS recent_memory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    turn_id INTEGER NOT NULL,
                    content TEXT NOT NULL,
                    original_content TEXT,
                    compression_level INTEGER DEFAULT 1,
                    token_count INTEGER NOT NULL,
                    created_at REAL NOT NULL
                )
            """)
            # Add original_content column if upgrading from old schema
            try:
                conn.execute("ALTER TABLE recent_memory ADD COLUMN original_content TEXT")
            except Exception:
                pass
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_turn ON recent_memory(turn_id)"
            )

    def add(self, turn_id: int, compressed_content: str, original_content: str | None = None):
        """Add a compressed session summary. Entries accumulate indefinitely."""
        tokens = count_tokens(compressed_content)
        now = time.time()
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO recent_memory
                   (turn_id, content, original_content, compression_level, token_count, created_at)
                   VALUES (?, ?, ?, 1, ?, ?)""",
                (turn_id, compressed_content, original_content, tokens, now),
            )

    def get_entries_for_context(self) -> list[str]:
        """Return individual recent memory entries, newest-first, up to INJECT_TOKEN_CAP."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT content, created_at FROM recent_memory ORDER BY turn_id DESC"
            ).fetchall()
        kept = []
        budget = self._inject_token_cap
        for r in rows:
            tok = count_tokens(r["content"])
            if tok <= budget:
                date_str = datetime.fromtimestamp(r["created_at"]).strftime("%Y-%m-%d %H:%M")
                kept.append(f"[{date_str}]\n{r['content']}")
                budget -= tok
            if budget <= 0:
                break
        return list(reversed(kept))

    def get_for_context(self) -> str:
        """
        Return recent memory content for context injection, newest-first up to INJECT_TOKEN_CAP.
        Newest sessions are most relevant, so we prioritise them within the token budget.
        """
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT content, created_at FROM recent_memory ORDER BY turn_id DESC"
            ).fetchall()
        if not rows:
            return ""
        kept = []
        budget = self._inject_token_cap
        for r in rows:
            tok = count_tokens(r["content"])
            if tok <= budget:
                date_str = datetime.fromtimestamp(r["created_at"]).strftime("%Y-%m-%d %H:%M")
                kept.append(f"[{date_str}]\n{r['content']}")
                budget -= tok
            if budget <= 0:
                break
        # Restore chronological order for the model
        return "\n".join(reversed(kept))

    def search(self, query: str, top_k: int = 5, min_score: float = 0.0) -> list[str]:
        """
        Search recent memory for entries relevant to the query.
        Returns up to top_k entries sorted by relevance (then recency).
        Supports both Chinese (bigram) and English (word) tokenization.
        """
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT content, turn_id, created_at FROM recent_memory ORDER BY turn_id DESC"
            ).fetchall()
        if not rows:
            return []

        query_lower = query.lower()
        # Hybrid: Chinese bigrams + English words (both always applied)
        tokens: set[str] = set()
        if any('\u4e00' <= c <= '\u9fff' for c in query):
            tokens.update(query_lower[i:i+2] for i in range(len(query_lower) - 1))
        tokens.update(w for w in query_lower.split() if len(w) > 2)
        if not tokens:
            return []

        scored = []
        for row in rows:
            content_lower = row["content"].lower()
            hits = sum(1 for t in tokens if t in content_lower)
            if hits > 0:
                scored.append((hits / len(tokens), row["turn_id"], row["created_at"], row["content"]))

        scored.sort(key=lambda x: (-x[0], -x[1]))
        results = []
        for score, _, created_at, content in scored[:top_k]:
            if score >= min_score:
                date_str = datetime.fromtimestamp(created_at).strftime("%Y-%m-%d %H:%M")
                results.append(f"[{date_str}]\n{content}")
        return results

    def get_recent_entries(self, limit: int = 20) -> list[str]:
        """Return the most recent N entries in chronological order. Used by consolidation."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT content FROM recent_memory ORDER BY turn_id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [r["content"] for r in reversed(rows)]

    def remove(self, entry_id: int):
        with self._conn() as conn:
            conn.execute("DELETE FROM recent_memory WHERE id = ?", (entry_id,))
