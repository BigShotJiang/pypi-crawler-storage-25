"""
API routes — thin HTTP layer over orchestration.
"""

import logging
import os

import json as json_mod

from fastapi import APIRouter, Form, HTTPException, Request, UploadFile, File, Query

from latent_insights.api.schemas import (
    CreateThreadRequest,
    PostMessageRequest,
    SessionConfig,
    SessionResponse,
    SessionSummary,
    SessionUrls,
    StepEvent,
    StepResponse,
    SystemStats,
    ThreadResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter()


def _base_url(request: Request) -> str:
    return str(request.base_url).rstrip("/")


def _get_state(request: Request):
    """Get app state from request.app.state (set during lifespan)."""
    s = request.app.state
    if not hasattr(s, "config") or not s.config:
        raise HTTPException(status_code=503, detail="Service not initialized")
    return s.config, s.llm, s.db, s.queue, s.state_store, s.trace_store


def _steps_from_trace(trace_store, thread) -> list[StepResponse]:
    """Convert TraceStore spans to StepResponse list for API."""
    spans = trace_store.get_step_spans(thread.id)
    if not spans:
        trace_store.load_trace(thread.id, thread.session_id)
        spans = trace_store.get_step_spans(thread.id)

    # Only include completed steps (in-progress spans have no attributes yet)
    spans = [s for s in spans if s.end_time is not None]

    steps = []
    for i, span in enumerate(spans, 1):
        attrs = span.attributes
        duration_ms = None
        if span.end_time and span.start_time:
            duration_ms = round((span.end_time - span.start_time) * 1000)

        # Build interleaved event timeline from span events
        step_events = []
        for event in span.events:
            event_attrs = event.get("attributes", {})
            step_events.append(StepEvent(
                type=event["name"],
                timestamp=event.get("timestamp", 0),
                agent=event_attrs.get("agent"),
                model=event_attrs.get("model"),
                duration_ms=event_attrs.get("duration_ms"),
                input_tokens=event_attrs.get("input_tokens"),
                output_tokens=event_attrs.get("output_tokens"),
                sql=event_attrs.get("sql"),
                tool_result=event_attrs.get("tool_result"),
                response=event_attrs.get("response"),
            ))
        step_events.sort(key=lambda e: e.timestamp)

        steps.append(StepResponse(
            step_number=i,
            move=attrs.get("move", ""),
            instruction=attrs.get("instruction", ""),
            result=attrs.get("result", ""),
            view_created=attrs.get("view_created"),
            duration_ms=duration_ms,
            events=step_events,
        ))
    return steps


# --- Sessions ---


@router.post("/sessions")
def create_session(
    request: Request,
    file: UploadFile | None = File(None),
    dataset_path: str | None = Query(None),
    config_json: str | None = Form(None, alias="config"),
):
    """Create a new analysis session from file upload or existing dataset path."""
    config, llm, db, queue, state, trace_store = _get_state(request)

    # Parse per-session config overrides
    session_config = config
    if config_json:
        try:
            raw = json_mod.loads(config_json)
        except json_mod.JSONDecodeError:
            raise HTTPException(status_code=400, detail="Invalid JSON in config field")
        parsed = SessionConfig(**raw)
        session_config = config.with_overrides(parsed.model_dump())

    if file and file.filename:
        if not file.filename.endswith(".csv"):
            raise HTTPException(status_code=400, detail="Only CSV files are supported")

        upload_dir = os.path.join(session_config.data_dir, "uploads")
        os.makedirs(upload_dir, exist_ok=True)
        resolved_path = os.path.join(upload_dir, file.filename)
        content = file.file.read()
        with open(resolved_path, "wb") as f:
            f.write(content)
    elif dataset_path:
        if not os.path.exists(dataset_path):
            raise HTTPException(status_code=404, detail=f"Dataset not found: {dataset_path}")
        resolved_path = dataset_path
    else:
        raise HTTPException(status_code=400, detail="Provide either a file upload or dataset_path")

    from latent_insights.db.connection import table_name_from_path
    from latent_insights.orchestration.session import SessionFlow

    table_name = table_name_from_path(resolved_path)
    session = state.create_session(resolved_path, table_name)

    flow = SessionFlow(session_config, llm, db, queue, state, trace_store)
    queue.schedule(
        fn=flow.create,
        args=(session.id, resolved_path),
        task_id=f"session-{session.id}",
        session_id=session.id,
        description=f"Session setup: {os.path.basename(resolved_path)}",
    )

    base = _base_url(request)
    return {
        "session_id": session.id,
        "status": "created",
        "urls": {
            "self": f"{base}/api/sessions/{session.id}",
            "events": f"{base}/api/sessions/{session.id}/events",
            "threads": f"{base}/api/sessions/{session.id}/threads",
        },
    }


@router.get("/sessions/{session_id}/saved")
def get_saved_session(session_id: str, request: Request):
    """Return a previously saved session from data/sessions/."""
    config, *_ = _get_state(request)
    stored = os.path.join(config.data_dir, "sessions", f"{session_id}.json")
    if not os.path.exists(stored):
        raise HTTPException(status_code=404, detail="Saved session not found")
    with open(stored) as f:
        return json_mod.load(f)


@router.get("/sessions/{session_id}")
def get_session(session_id: str, request: Request):
    """Get full session state with threads and steps."""
    _, _, _, _, state, trace_store = _get_state(request)

    session = state.get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")

    threads = state.get_threads(session_id)

    thread_responses = []
    for t in threads:
        steps = _steps_from_trace(trace_store, t)
        thread_responses.append(ThreadResponse(
            id=t.id,
            seed_question=t.seed_question,
            motivation=t.motivation,
            status=t.status.value,
            summary=t.summary,
            running_summary=t.running_summary,
            error=t.error,
            steps=steps,
            updated_at=t.updated_at.isoformat() if t.updated_at else "",
        ))

    return SessionResponse(
        id=session.id,
        dataset_path=session.dataset_path,
        schema_summary=session.schema_summary,
        scout_questions=session.scout_output.get("questions") if session.scout_output else None,
        threads=thread_responses,
        urls=SessionUrls(
            self=f"{_base_url(request)}/api/sessions/{session_id}",
            events=f"{_base_url(request)}/api/sessions/{session_id}/events",
            threads=f"{_base_url(request)}/api/sessions/{session_id}/threads",
        ),
        created_at=session.created_at.isoformat() if session.created_at else "",
    )


@router.post("/sessions/{session_id}/threads")
def create_thread(session_id: str, request: Request, body: CreateThreadRequest):
    """Create a user-initiated thread with a custom question."""
    config, llm, db, queue, state, trace_store = _get_state(request)
    from latent_insights.orchestration.thread import ThreadRunner

    session = state.get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    if session.schema_summary is None:
        raise HTTPException(status_code=400, detail="Session profiling not complete yet")

    thread = state.create_thread(
        session_id, body.question, body.motivation or "", "",
    )

    thread_db = db.open_session_connection(session_id)

    runner = ThreadRunner(
        config=config,
        llm=llm,
        session_db=thread_db,
        queue=queue,
        state=state,
        trace_store=trace_store,
        thread=thread,
        schema_summary=session.schema_summary,
    )
    runner.start()

    return ThreadResponse(
        id=thread.id,
        seed_question=thread.seed_question,
        motivation=thread.motivation,
        status=thread.status.value,
        updated_at=thread.updated_at.isoformat() if thread.updated_at else "",
    )


@router.post("/sessions/{session_id}/continue")
def continue_session(session_id: str, request: Request):
    """Continue a session: resume stuck threads + scout new questions."""
    config, llm, db, queue, state, trace_store = _get_state(request)
    from latent_insights.orchestration.session import SessionFlow

    session = state.get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    if session.schema_summary is None:
        raise HTTPException(status_code=400, detail="Session profiling not complete yet")

    flow = SessionFlow(config, llm, db, queue, state, trace_store)
    queue.schedule(
        fn=flow.continue_,
        args=(session_id,),
        task_id=f"continue-{session_id}",
        session_id=session_id,
        description=f"Continue session {session_id}",
    )

    threads = state.get_threads(session_id)
    resumable = [t for t in threads if t.status.value in ("waiting", "complete")]

    return {
        "status": "continuing",
        "session_id": session_id,
        "threads_resumed": len(resumable),
    }


@router.post("/threads/{thread_id}/messages")
def post_message(thread_id: str, request: Request, body: PostMessageRequest):
    """Post a human message to a stuck thread, resuming it."""
    config, llm, db, queue, state, trace_store = _get_state(request)
    from latent_insights.orchestration.thread import ThreadRunner

    thread = state.get_thread(thread_id)
    if thread is None:
        raise HTTPException(status_code=404, detail="Thread not found")
    if thread.status.value not in ("waiting", "complete"):
        raise HTTPException(status_code=400, detail="Thread is not waiting or complete")

    session = state.get_session(thread.session_id)
    thread_db = db.open_session_connection(thread.session_id)

    runner = ThreadRunner(
        config=config,
        llm=llm,
        session_db=thread_db,
        queue=queue,
        state=state,
        trace_store=trace_store,
        thread=thread,
        schema_summary=session.schema_summary or "",
    )
    runner.resume(human_messages=[body.content])

    return {"status": "resumed", "thread_id": thread_id}


@router.get("/sessions")
def list_sessions(request: Request):
    """List all sessions with metadata."""
    _, _, _, _, state, _ = _get_state(request)

    sessions = state.get_all_sessions()
    summaries = []
    for s in sessions:
        threads = state.get_threads(s.id)
        status_counts: dict[str, int] = {}
        for t in threads:
            status_counts[t.status.value] = status_counts.get(t.status.value, 0) + 1
        summaries.append(SessionSummary(
            id=s.id,
            dataset_path=s.dataset_path,
            table_name=s.table_name,
            thread_count=len(threads),
            status_counts=status_counts,
            created_at=s.created_at.isoformat() if s.created_at else "",
        ))

    return summaries


@router.get("/threads/{thread_id}")
def get_thread(thread_id: str, request: Request):
    """Get a single thread with its steps."""
    _, _, _, _, state, trace_store = _get_state(request)

    thread = state.get_thread(thread_id)
    if thread is None:
        raise HTTPException(status_code=404, detail="Thread not found")

    steps = _steps_from_trace(trace_store, thread)
    return ThreadResponse(
        id=thread.id,
        seed_question=thread.seed_question,
        motivation=thread.motivation,
        status=thread.status.value,
        summary=thread.summary,
        running_summary=thread.running_summary,
        error=thread.error,
        steps=steps,
        updated_at=thread.updated_at.isoformat() if thread.updated_at else "",
    )


# --- System ---


@router.get("/system/stats")
def system_stats(request: Request) -> SystemStats:
    """Session and thread counts."""
    _, _, _, _, state, _ = _get_state(request)

    return SystemStats(
        session_count=state.session_count,
        thread_count=state.thread_count,
    )
