from copy import deepcopy

import pytest

from cidc_schemas.migrations import (
    _ENCRYPTED_FIELD_LEN,
    _follow_path,
    MigrationError,
    MigrationResult,
    v0_10_0_to_v0_10_2,
    v0_10_2_to_v0_11_0,
    v0_15_2_to_v0_15_3,
    v0_21_1_to_v0_22_0,
    v0_23_0_to_v0_23_1,
    v0_23_18_to_v0_24_0,
    v0_25_41_to_v0_25_42,
    v0_25_54_to_v0_26_0,
    v0_28_25_to_v0_28_26,
    v0_28_27_to_v0_28_28,
    v0_28_28_to_v0_29_0,
    v0_29_0_to_v0_30_0,
)


def test_follow_path():
    """Test _follow_path utility for extracting values from dict"""
    # Existing path
    val = "foo"
    d = {"a": {"b": [{}, {"c": val}]}}
    assert _follow_path(d, "a", "b", 1, "c") == val

    # Non-existing paths
    d = {"a": {"buzz": val}}
    assert _follow_path(d, "a", "b") is None
    d = {"a": [val]}
    assert _follow_path(d, 1) is None


def test_v0_15_2_to_v0_15_3():
    assert v0_15_2_to_v0_15_3.downgrade(
        v0_15_2_to_v0_15_3.upgrade({"foo": "bar"}).result
    ).result == {"foo": "bar"}

    ct = {"participants": [{"cohort_name": "Not reported"}, {"cohort_name": "foo"}]}

    upgraded_ct = v0_15_2_to_v0_15_3.upgrade(ct).result
    assert upgraded_ct["participants"][0]["cohort_name"] == "Not_reported"
    assert upgraded_ct["participants"][1]["cohort_name"] == "foo"

    assert ct == v0_15_2_to_v0_15_3.downgrade(upgraded_ct).result


def test_v0_10_2_to_v0_11_0():

    empty_ct = {}

    assert v0_10_2_to_v0_11_0.upgrade(empty_ct).result == {
        "allowed_collection_event_names": [],
        "allowed_cohort_names": [],
    }

    ct_2 = {
        "participants": [
            {"cohort_name": "cohort_1"},
            {
                "cohort_name": "cohort_2",
                "samples": [
                    {"collection_event_name": "event_1"},
                    {"collection_event_name": "event_2"},
                ],
            },
        ]
    }

    upgraded = v0_10_2_to_v0_11_0.upgrade(ct_2).result
    assert sorted(upgraded["allowed_collection_event_names"]) == ["event_1", "event_2"]
    assert sorted(upgraded["allowed_cohort_names"]) == ["cohort_1", "cohort_2"]


def test_v0_21_1_to_v0_22_0(monkeypatch):
    monkeypatch.setattr(
        "cidc_schemas.migrations._encrypt", lambda x: f"test_encrypted({str(x)!r})"
    )
    monkeypatch.setattr("cidc_schemas.prism.core._check_encrypt_init", lambda: None)

    empty_ct = {}

    assert v0_21_1_to_v0_22_0.upgrade(empty_ct).result == {}

    ct_2 = {
        "participants": [
            {"participant_id": "pid1", "samples": []},
            {
                "participant_id": "pid2",
                "samples": [
                    {
                        "parent_sample_id": "PARENT_sid_1",
                        "processed_sample_id": "PROCESSED_sid_1",
                    },
                    {"parent_sample_id": "X", "processed_sample_id": "PROCESSED_sid_2"},
                    {
                        "parent_sample_id": "PARENT_sid_3",
                        "processed_sample_id": "test_encrypted('Not reported')",
                    },
                    {
                        "parent_sample_id": "4" * _ENCRYPTED_FIELD_LEN,
                        "processed_sample_id": "4" * _ENCRYPTED_FIELD_LEN,
                    },
                    {"parent_sample_id": "PARENT_sid_5"},
                ],
            },
        ]
    }

    upgraded = v0_21_1_to_v0_22_0.upgrade(ct_2).result
    assert upgraded == {
        "participants": [
            {"participant_id": "test_encrypted('pid1')", "samples": []},
            {
                "participant_id": "test_encrypted('pid2')",
                "samples": [
                    {
                        "parent_sample_id": "test_encrypted('PARENT_sid_1')",
                        "processed_sample_id": "test_encrypted('PROCESSED_sid_1')",
                    },
                    {
                        "parent_sample_id": "test_encrypted('PROCESSED_sid_2')",
                        "processed_sample_id": "test_encrypted('PROCESSED_sid_2')",
                    },
                    {
                        "parent_sample_id": "test_encrypted('PARENT_sid_3')",
                        "processed_sample_id": "test_encrypted('PARENT_sid_3')",
                    },
                    {
                        "parent_sample_id": "4" * _ENCRYPTED_FIELD_LEN,
                        "processed_sample_id": "4" * _ENCRYPTED_FIELD_LEN,
                    },
                    {
                        "parent_sample_id": "test_encrypted('PARENT_sid_5')",
                        "processed_sample_id": "test_encrypted('PARENT_sid_5')",
                    },
                ],
            },
        ]
    }


def test_v0_10_0_to_v0_10_2():

    # Check that upgrade doesn't modify a CT example with no olink data
    ct_no_olink = {"assays": {"wes": {"records": []}}}
    assert v0_10_0_to_v0_10_2.upgrade(ct_no_olink).result == ct_no_olink

    # Check that upgrade throws an error if unexpected olink structure is encountered
    ct_bad_olink = {"assays": {"olink": {"records": [{"files": {}}]}}}
    with pytest.raises(MigrationError, match="Olink record has unexpected structure"):
        v0_10_0_to_v0_10_2.upgrade(ct_bad_olink)

    # Check that the migration treats a well-behaved CT example as expected
    urls = ["tid/olink/chip_1/assay_raw_ct.xlsx", "tid/olink/chip_2/assay_raw_ct.xlsx"]
    old_ct = {
        "assays": {
            "olink": {
                "records": [
                    {
                        "files": {
                            "assay_raw_ct": {
                                "data_format": "XLSX",
                                "object_url": urls[0],
                            }
                        }
                    },
                    {
                        "files": {
                            "assay_raw_ct": {
                                "data_format": "XLSX",
                                "object_url": urls[1],
                            }
                        }
                    },
                ]
            }
        }
    }

    res: MigrationResult = v0_10_0_to_v0_10_2.upgrade(old_ct)

    def get_artifact_path(record_idx):
        return _follow_path(
            res.result,
            "assays",
            "olink",
            "records",
            record_idx,
            "files",
            "assay_raw_ct",
        )

    # Check that artifacts were successfully upgraded and
    # that file_updates track updates as expected
    for i in range(2):
        artifact = get_artifact_path(i)
        assert artifact["data_format"] == "CSV"
        assert artifact["object_url"].endswith(".csv")

        assert urls[i] in res.file_updates
        assert res.file_updates[urls[i]] == artifact

    # Check upgrade/downgrade inverse
    assert v0_10_0_to_v0_10_2.downgrade(res.result).result == old_ct


def test_v0_23_0_to_v0_23_1():
    assert v0_23_0_to_v0_23_1.downgrade(
        v0_23_0_to_v0_23_1.upgrade({"foo": "bar"}).result
    ).result == {"foo": "bar"}

    ct = {
        "participants": [
            {"arbitrary_trial_specific_clinical_annotations": {"foo": "bar"}},
            {"arbitrary_trial_specific_clinical_annotations": {"foo": "baz"}},
        ],
        "analysis": {"rnaseq_analysis": "qux"},
    }

    upgraded_ct = v0_23_0_to_v0_23_1.upgrade(ct).result
    assert (
        "clinical" in upgraded_ct["participants"][0]
        and "arbitrary_trial_specific_clinical_annotations"
        not in upgraded_ct["participants"][0]
    )
    assert (
        "clinical" in upgraded_ct["participants"][1]
        and "arbitrary_trial_specific_clinical_annotations"
        not in upgraded_ct["participants"][1]
    )
    assert (
        "foo" in upgraded_ct["participants"][0]["clinical"]
        and upgraded_ct["participants"][0]["clinical"]["foo"] == "bar"
    )
    assert (
        "foo" in upgraded_ct["participants"][1]["clinical"]
        and upgraded_ct["participants"][1]["clinical"]["foo"] == "baz"
    )
    assert "rnaseq_analysis" not in upgraded_ct["analysis"]
    assert (
        "rna_analysis" in upgraded_ct["analysis"]
        and upgraded_ct["analysis"]["rna_analysis"] == "qux"
    )

    assert ct == v0_23_0_to_v0_23_1.downgrade(upgraded_ct).result


def test_v0_23_18_to_v0_24_0():
    # Unrelated data is unchanged
    assert v0_23_18_to_v0_24_0.downgrade(
        v0_23_18_to_v0_24_0.upgrade({"foo": "bar"}).result
    ).result == {"foo": "bar"}

    ct = {
        "assays": {
            "olink": {
                "study": {
                    "npx_manager_version": "ol_npx_v1",
                    "study_npx": {"foo": "bar"},
                },
                "assay_creator": "Mount Sinai",
                "panel": "ol_panel_1",
                "records": [
                    {
                        "files": {
                            "assay_npx": {
                                "object_url": "test-trial/chip_1234/assay_npx.xlsx",
                                "foo": "bar",
                            },
                            "assay_raw_ct": {
                                "object_url": "test-trial/chip_1234/assay_raw_ct.xlsx",
                                "foo": "bar",
                            },
                        }
                    },
                    {
                        "files": {
                            "assay_npx": {"upload_placeholder": "asdf"},
                            "assay_raw_ct": {"upload_placeholder": "asdf"},
                        }
                    },
                ],
            }
        }
    }

    target_ct = {
        "assays": {
            "olink": {
                "study": {
                    "npx_manager_version": "ol_npx_v1",
                    "npx_file": {"foo": "bar"},
                },
                "batches": [
                    {
                        "batch_id": "1",
                        "assay_creator": "Mount Sinai",
                        "panel": "ol_panel_1",
                        "records": [
                            {
                                "files": {
                                    "assay_npx": {
                                        "object_url": "test-trial/batch_1/chip_1234/assay_npx.xlsx",
                                        "foo": "bar",
                                    },
                                    "assay_raw_ct": {
                                        "object_url": "test-trial/batch_1/chip_1234/assay_raw_ct.xlsx",
                                        "foo": "bar",
                                    },
                                }
                            },
                            {
                                "files": {
                                    "assay_npx": {"upload_placeholder": "asdf"},
                                    "assay_raw_ct": {"upload_placeholder": "asdf"},
                                }
                            },
                        ],
                    }
                ],
            }
        }
    }

    result: MigrationResult = v0_23_18_to_v0_24_0.upgrade(ct)
    assert result.result == target_ct
    assert result.file_updates == {
        "test-trial/chip_1234/assay_npx.xlsx": {
            "object_url": "test-trial/batch_1/chip_1234/assay_npx.xlsx",
            "foo": "bar",
        },
        "test-trial/chip_1234/assay_raw_ct.xlsx": {
            "object_url": "test-trial/batch_1/chip_1234/assay_raw_ct.xlsx",
            "foo": "bar",
        },
    }

    # downgrade is a noop for this migration
    assert v0_23_18_to_v0_24_0.downgrade(target_ct).result == target_ct


def test_v0_25_41_to_v0_25_42():
    # Unrelated data is unchanged
    assert v0_25_41_to_v0_25_42.downgrade(
        v0_25_41_to_v0_25_42.upgrade({"foo": "bar"}).result
    ).result == {"foo": "bar"}

    ct = {
        "analyses": {
            "wes_analysis": {"foo": "bar"},
            "wes_tumor_only_analysis": {"biz": "baz"},
        }
    }

    target_ct = {
        "analyses": {
            "wes_analysis_old": {"foo": "bar"},
            "wes_tumor_only_analysis_old": {"biz": "baz"},
        }
    }

    result: MigrationResult = v0_25_41_to_v0_25_42.upgrade(deepcopy(ct))
    assert result.result == target_ct
    assert result.file_updates == {}

    assert v0_25_41_to_v0_25_42.downgrade(target_ct).result == ct


def test_v0_25_54_to_v0_26_0():
    # Unrelated data is unchanged
    assert v0_25_54_to_v0_26_0.downgrade(
        v0_25_54_to_v0_26_0.upgrade({"foo": "bar"}).result
    ).result == {"foo": "bar"}

    ct = {
        "collection_event_list": ["foo"],
        "participants": [
            {
                "cidc_participant_id": "cidc-partic",
                "clinical": {"foo": "bar"},
                "samples": [
                    {
                        "cidc_id": "cidc-sample",
                        "aliquots": ["bar"],
                    },
                    {},  # doesn't fail without them
                ],
            },
            {
                # doesn't fail without them
                "samples": [  # samples required
                    {},  # doesn't fail without them
                ],
            },
        ],
        "assays": {
            "cytof": [
                {
                    "records": [
                        {
                            "input_files": {},  # required
                            "concatenation_version": "foo",
                            "normalization_version": "bar",
                        },
                        {
                            "input_files": {},  # required
                        },
                    ],
                }
            ],
            "micsss": {},
            "misc_data": [
                {
                    "files": [
                        {"description": "foo"},
                        {},  # doesn't fail without them
                    ],
                }
            ],
        },
    }

    target_ct = {
        "participants": [
            {
                "samples": [{}, {}],
            },
            {
                "samples": [{}],
            },
        ],
        "assays": {
            "cytof": [
                {
                    "records": [
                        {
                            "input_files": {
                                "concatenation_version": "foo",
                                "normalization_version": "bar",
                            },
                        },
                        {
                            "input_files": {},
                        },
                    ],
                }
            ],
            "misc_data": [
                {
                    "files": [
                        {"file_description": "foo"},
                        {},  # doesn't fail without them
                    ],
                }
            ],
        },
    }

    reset_ct = {
        "participants": [
            {
                "samples": [{}, {}],
            },
            {
                "samples": [{}],
            },
        ],
        "assays": {
            "cytof": [
                {
                    "records": [
                        {
                            "input_files": {},  # required
                            "concatenation_version": "foo",
                            "normalization_version": "bar",
                        },
                        {
                            "input_files": {},
                        },
                    ],
                }
            ],
            "misc_data": [
                {
                    "files": [
                        {"description": "foo"},
                        {},
                    ],
                }
            ],
        },
    }

    result: MigrationResult = v0_25_54_to_v0_26_0.upgrade(deepcopy(ct))
    assert result.result == target_ct
    assert result.file_updates == {}

    assert v0_25_54_to_v0_26_0.downgrade(target_ct).result == reset_ct


def test_v0_28_25_to_v0_28_26():
    """Test v0_28_25_to_v0_28_26 migration."""
    # Test that unrelated data is unchanged
    assert v0_28_25_to_v0_28_26.upgrade({"foo": "bar"}).result == {"foo": "bar"}

    ct = {
        "protocol_identifier": "test_trial_123",
        "assays": {
            # An assay that needs batch_id added
            "ihc": [
                {
                    "some_ihc_prop": "value1"
                    # batch_id is missing
                },
                {"batch_id": "existing_id", "some_ihc_prop": "value2"},
            ],
            # An assay that is not in the check list
            "some_other_assay": [{"some_prop": "value3"}],
            # ELISA assay for special handling
            "elisa": [
                {
                    # This batch has assay_run_id, which should be moved to batch_id
                    "assay_run_id": "run_id_abc"
                },
                {
                    # This batch is missing batch_id and assay_run_id, so batch_id should be added
                    "records": []
                },
                {
                    # This batch has an existing batch_id, which should be overwritten by assay_run_id
                    "batch_id": "old_batch_id",
                    "assay_run_id": "new_run_id_def",
                },
            ],
        },
    }

    # Define the expected structure after the upgrade
    target_ct = {
        "protocol_identifier": "test_trial_123",
        "assays": {
            "ihc": [
                {"batch_id": "Retroactively Added", "some_ihc_prop": "value1"},
                {"batch_id": "existing_id", "some_ihc_prop": "value2"},
            ],
            "some_other_assay": [{"some_prop": "value3"}],
            "elisa": [
                {"batch_id": "run_id_abc"},
                {"batch_id": "Retroactively Added", "records": []},
                {"batch_id": "new_run_id_def"},
            ],
        },
    }

    # Perform the upgrade
    result: MigrationResult = v0_28_25_to_v0_28_26.upgrade(deepcopy(ct))

    # Assert that the result matches the target
    assert result.result == target_ct
    assert result.file_updates == {}

    # Check that downgrade is a no-op (doesn't change the data)
    assert v0_28_25_to_v0_28_26.downgrade(deepcopy(target_ct)).result == target_ct


def test_v0_28_27_to_v0_28_28():
    # Test that unrelated data is unchanged
    assert v0_28_27_to_v0_28_28.upgrade({"foo": "bar"}).result == {"foo": "bar"}

    ct = {
        "assays": {
            # ATACseq: special cases (1, 0) plus boundaries at 10 and >20
            "atacseq": [
                {
                    "records": [
                        {"quality_flag": 1},  # special case
                        {"quality_flag": 0},  # special case
                        {"quality_flag": 5},  # <10
                        {"quality_flag": 10},  # boundary 10-20
                        {"quality_flag": 15},  # 10-20
                        {"quality_flag": 25},  # >20
                        {"cimac_id": "CTTTPPPSA.00"},  # no quality_flag
                    ]
                }
            ],
            # RNA: special cases (1, 0) plus boundaries at 15 and >20
            "rna": [
                {
                    "records": [
                        {"quality_flag": 1},  # special case
                        {"quality_flag": 0},  # special case
                        {"quality_flag": 10},  # <15
                        {"quality_flag": 15},  # boundary 15-20
                        {"quality_flag": 17},  # 15-20
                        {"quality_flag": 21},  # >20
                        {"cimac_id": "CTTTPPPSA.00"},  # no quality_flag
                    ]
                }
            ],
            # WES: boundaries at 20 and 30
            "wes": [
                {
                    "records": [
                        {"quality_flag": 30},  # boundary >=30
                        {"quality_flag": 25},  # 20-29
                        {"quality_flag": 20},  # boundary 20-29
                        {"quality_flag": 10},  # <20
                        {"cimac_id": "CTTTPPPSA.00"},  # no quality_flag
                    ]
                }
            ],
        }
    }

    target_ct = {
        "assays": {
            "atacseq": [
                {
                    "records": [
                        {"quality_flag": "Pass"},  # 1
                        {"quality_flag": "Fail"},  # 0
                        {"quality_flag": "Fail"},  # 5
                        {"quality_flag": "Warning"},  # 10
                        {"quality_flag": "Warning"},  # 15
                        {"quality_flag": "Pass"},  # 25
                        {"cimac_id": "CTTTPPPSA.00"},
                    ]
                }
            ],
            "rna": [
                {
                    "records": [
                        {"quality_flag": "Pass"},  # 1
                        {"quality_flag": "Fail"},  # 0
                        {"quality_flag": "Fail"},  # 10
                        {"quality_flag": "Warning"},  # 15
                        {"quality_flag": "Warning"},  # 17
                        {"quality_flag": "Pass"},  # 21
                        {"cimac_id": "CTTTPPPSA.00"},
                    ]
                }
            ],
            "wes": [
                {
                    "records": [
                        {"quality_flag": "Pass"},  # 30
                        {"quality_flag": "Warning"},  # 25
                        {"quality_flag": "Warning"},  # 20
                        {"quality_flag": "Fail"},  # 10
                        {"cimac_id": "CTTTPPPSA.00"},
                    ]
                }
            ],
        }
    }

    result: MigrationResult = v0_28_27_to_v0_28_28.upgrade(deepcopy(ct))
    assert result.result == target_ct
    assert result.file_updates == {}

    # downgrade is a no-op
    assert v0_28_27_to_v0_28_28.downgrade(deepcopy(target_ct)).result == target_ct


def test_v0_28_28_to_v0_29_0():
    """Test migration test_v0_28_28_to_v0_29_0 - renaming of 'comment' and fastq fields."""
    # Test that unrelated data is unchanged
    assert v0_28_28_to_v0_29_0.upgrade({"foo": "bar"}).result == {"foo": "bar"}

    ct = {
        "protocol_identifier": "test_trial_123",
        "clinical_data": {
            "records": [
                {"comment": "clinical comment."},
                {"some_other_field": "value"},
            ]
        },
        "assays": {
            # Assay with standard comment rename
            "hande": [{"records": [{"comment": "A hande comment."}]}],
            # MIBI assay with special 'files' comment rename
            "mibi": [{"records": [{"files": {"comment": "A mibi file comment."}}]}],
            # Assay that should be unaffected
            "unaffected": [{"records": [{"comment": "An unaffected comment."}]}],
            # Assay with fastq renames
            "microbiome": [
                {
                    "forward_fastq": "path/to/file1.fastq.gz",
                    "reverse_fastq": "path/to/file2.fastq.gz",
                }
            ],
        },
    }

    # Define the expected structure after the upgrade
    target_ct = {
        "protocol_identifier": "test_trial_123",
        "clinical_data": {
            "records": [
                {"comments": "clinical comment."},
                {"some_other_field": "value"},
            ]
        },
        "assays": {
            "hande": [{"records": [{"comments": "A hande comment."}]}],
            "mibi": [{"records": [{"files": {"comments": "A mibi file comment."}}]}],
            # Should be unchanged
            "unaffected": [{"records": [{"comment": "An unaffected comment."}]}],
            "microbiome": [
                {
                    "read_1_fastq": "path/to/file1.fastq.gz",
                    "read_2_fastq": "path/to/file2.fastq.gz",
                }
            ],
        },
    }

    # Perform the upgrade and assert correctness
    upgraded_result = v0_28_28_to_v0_29_0.upgrade(deepcopy(ct))
    assert upgraded_result.result == target_ct
    assert upgraded_result.file_updates == {}

    # Perform the downgrade and assert it reverts to the original state
    downgraded_result = v0_28_28_to_v0_29_0.downgrade(deepcopy(target_ct))
    assert downgraded_result.result == ct
    assert downgraded_result.file_updates == {}


def test_v0_29_0_to_v0_30_0():
    """Test backfill of read_length=-1 and quality_flag=N/A for legacy data."""
    # Unrelated data is unchanged
    assert v0_29_0_to_v0_30_0.upgrade({"foo": "bar"}).result == {"foo": "bar"}

    ct = {
        "protocol_identifier": "test_trial_123",
        "assays": {
            # Batch missing read_length; record missing quality_flag
            "microbiome": [
                {
                    "batch_id": "b1",
                    "records": [
                        {"cimac_id": "C1"},
                        {"cimac_id": "C2", "quality_flag": "Pass"},
                    ],
                }
            ],
            # Batch already has read_length; should be left alone
            "atacseq": [
                {
                    "batch_id": "b2",
                    "read_length": 150,
                    "records": [
                        {"cimac_id": "C3"},
                    ],
                }
            ],
            # quality_flag lives inside record.details for these assays
            "scrnaseq": [
                {
                    "batch_id": "b3",
                    "records": [
                        {"cimac_id": "C4", "details": {}},
                        {"cimac_id": "C5", "details": {"quality_flag": "Warning"}},
                    ],
                }
            ],
            "visium": [
                {
                    "batch_id": "b4",
                    "records": [
                        {"cimac_id": "C6"},
                    ],
                }
            ],
            # Unaffected assay
            "elisa": [{"batch_id": "b5", "antigens": [{"antigen": "X"}]}],
        },
    }

    target_ct = {
        "protocol_identifier": "test_trial_123",
        "assays": {
            "microbiome": [
                {
                    "batch_id": "b1",
                    "read_length": -1,
                    "records": [
                        {"cimac_id": "C1", "quality_flag": "N/A"},
                        {"cimac_id": "C2", "quality_flag": "Pass"},
                    ],
                }
            ],
            "atacseq": [
                {
                    "batch_id": "b2",
                    "read_length": 150,
                    "records": [
                        {"cimac_id": "C3", "quality_flag": "N/A"},
                    ],
                }
            ],
            "scrnaseq": [
                {
                    "batch_id": "b3",
                    "read_length": -1,
                    "records": [
                        {"cimac_id": "C4", "details": {"quality_flag": "N/A"}},
                        {"cimac_id": "C5", "details": {"quality_flag": "Warning"}},
                    ],
                }
            ],
            "visium": [
                {
                    "batch_id": "b4",
                    "read_length": -1,
                    "records": [
                        {"cimac_id": "C6", "details": {"quality_flag": "N/A"}},
                    ],
                }
            ],
            "elisa": [{"batch_id": "b5", "antigens": [{"antigen": "X"}]}],
        },
    }

    upgraded = v0_29_0_to_v0_30_0.upgrade(deepcopy(ct))
    assert upgraded.result == target_ct
    assert upgraded.file_updates == {}

    # downgrade is a no-op deep copy
    downgraded = v0_29_0_to_v0_30_0.downgrade(deepcopy(target_ct))
    assert downgraded.result == target_ct
    assert downgraded.file_updates == {}
