from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from wexample_helpers.decorator.base_class import base_class

from .abstract_php_file_content_option import AbstractPhpFileContentOption

if TYPE_CHECKING:
    from wexample_filestate.const.types_state_items import TargetFileOrDirectoryType


@base_class
class PhpcsFixerOption(AbstractPhpFileContentOption):
    def get_description(self) -> str:
        return "Fix PHP code style using PHP-CS-Fixer."

    def _apply_content_change(self, target: TargetFileOrDirectoryType) -> str:
        """Fix PHP code style using PHP-CS-Fixer via Docker."""
        # Get the file path inside the container
        container_file_path = self._get_container_file_path(target)

        # Prefer project config if present inside the container
        project_config = target.get_root().get_path() / Path(".php-cs-fixer.dist.php")

        config_path = (
            "/var/www/html/.php-cs-fixer.dist.php"
            if project_config.exists()
            else "/home/appuser/.php-cs-fixer.dist.php"
        )

        self._execute_in_docker(
            target=target,
            command=[
                "php-cs-fixer",
                "fix",
                f"--config={config_path}",
                "--path-mode=intersection",
                container_file_path,
            ],
        )

        # Read the fixed content from the file (it was modified in place)
        return target.read_text()
