# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.62.0] - 2026-05-13

> Note: a 0.61.1 release was published to PyPI between 0.61.0 and 0.62.0
> with this same content. It was bumped as a patch by mistake; the new-
> CLI-subcommand addition is backwards-compatible-additive, which is
> textbook minor-version territory. 0.61.1 stays on PyPI for posterity;
> 0.62.0 is the version to install. Bytes are identical apart from the
> version string.

### Added
- **`Body.iter_constants()`** — generator yielding `(field_name,
  Constant)` for every Constant-bearing field on a body. Skips `None`
  fields and non-`Constant` values (metadata like `body_class` /
  `naif_id` / `dwarf_planet`, polynomial-coefficient tuples, scalar
  floats like `flattening`). Useful for tabular display, introspection,
  and CLI completions without callers needing to know the dataclass
  schema. Both the `plp constants` table-rendering and tab-completion
  paths now route through this method instead of duplicating the
  filter-by-isinstance loop — keeps the CLI a thin wrapper.
- **`plp constants` CLI subcommand.** Two forms:
  - `plp constants Mars` — Rich-rendered table of every scalar `Constant`
    attached to the body, with a *source* column (PCK kernel filename or
    NSSDC capture stamp per field). Filters out non-Constant metadata
    like `body_class` / `dwarf_planet` / `naif_id` so the table only
    contains actual quantities.
  - `plp constants Mars.GM` — value on **stdout**, provenance lines
    (`# source: pck00011.tpc`, `# reference: IAU 2015 — Archinal et
    al.…`) on **stderr**, so `plp constants Mars.GM | awk '{print $1}'`
    Just Works.
  Body matching is case-insensitive (`mars` == `Mars` == `MARS`). Misspelt
  bodies and unknown fields each exit non-zero with `difflib`-driven
  close-match suggestions on stderr (e.g. `'jupier'` → "did you mean:
  Jupiter, Juliet?"; `Mars.gravity` → "did you mean: surface_gravity?").
  Carries the time-travel facility through to the CLI via `--at`/`-t`:
  `plp constants Mars.pole_dec --at 2012` returns 52.886° (sourced from
  `pck00010.tpc`/IAU 2009), demonstrating the PCK-edition swap from a
  shell. Tab completion offers body names before the dot and
  Constant-bearing field names after it (gas-giant `Jupiter.surface_<TAB>`
  correctly returns nothing since those fields are unset). 13 new tests
  in `tests/test_cli_constants.py` pin the contract.

### Changed
- **Bare invocation now prints `--help` for every top-level CLI command.**
  Previously, `plp catalog` / `plp indexes` (sub-app groups) showed full
  help on bare invocation (typer's free `no_args_is_help=True` for
  groups), but the eight individual commands with required positionals
  — `fetch`, `hibrowse`, `hiedr`, `himos`, `ctxqv`, `spicer`,
  `example_pid`, `meta` — instead emitted typer's terse `Missing
  argument 'KEY'.` error (exit 2). Now every top-level command exits 0
  with the full help block when invoked without arguments. Two-positional
  commands (`fetch`, `meta`) still error on partial invocation with a
  clear `Error: missing PRODUCT_ID argument.` message and exit 2, so the
  "give me a hint, I have the first arg" flow is preserved. Pattern:
  added `ctx: typer.Context` parameter, defaulted the first positional
  to `None`, and inserted an `if x is None: typer.echo(ctx.get_help());
  raise typer.Exit()` block at the top of each function body. Cheap and
  consistent.

## [0.61.0] - 2026-05-12

### Added
- **`planetarypy.constants` — a one-stop constants subsystem.** Three layers in a single namespace:
  1. **Fundamental physics constants** re-exported from `astropy.constants`: `G`, `c`, `h`, `k_B`, `N_A`, `sigma_sb`, `m_e`, `m_p`, `M_sun`, `R_sun`, `L_sun`, `M_earth`, `R_earth`, `M_jup`, `R_jup`, `au`, `pc`, `kpc`, and ~15 more — so one import covers fundamental + per-body without managing two parallel imports. CODATA-versioned via astropy; nothing repackaged.
  2. **Per-body PCK constants** for ~145 solar-system bodies — triaxial radii, GMs, pole RA/Dec, prime meridian, rotation rate, plus polynomial coefficients — sourced from NAIF SPICE PCK kernels and versioned by IAU report edition (2009, 2015). Generated at build time from upstream kernels via `scripts/regenerate_constants.py` so the runtime never depends on spiceypy; the bare `Mars`, `Saturn`, … etc. resolve to the current IAU 2015 edition.
  3. **NSSDC fact-sheet parameters** for the Sun, eight planets, the Moon, and Pluto — bond albedo, surface pressure, scale height, satellite count, semimajor axis, sidereal period, ~25 more fields — merged transparently into each Body at build time. NSSDC = NASA's National Space Science Data Center at Goddard Space Flight Center; D. R. Williams has maintained the canonical per-body fact sheets there since 1996. Resolution rule: PCK wins for cartographic/orientation fields when both have a value; NSSDC fills in everything PCK doesn't carry. Every value returns as a `Constant` (an `astropy.units.Quantity` subclass) with `.source`, `.reference`, `.description`, and `.iau_year` metadata — `Mars.GM.source == "pck00011.tpc"`, `Mars.bond_albedo.source == "NSSDC marsfact.html updated 2025-05-19"`. Discovery helpers (`planets()`, `moons(of="Saturn")`, `asteroids()`, `mission_visited()`, `find_body("Bennu")`) for browsing the registry by class.
- **Time-travel: `Body.at_time(date)`** returns a snapshot of any body with all fields resolved as of `date`. Picks the right IAU PCK edition for the date (IAU 2009 PCK published 2010-10-21; IAU 2015 PCK published 2018-09-20) AND the right NSSDC capture (most recent revision at or before the date). `Mars.at_time('2012').pole_dec` returns 52.8865° (IAU 2009), `Mars.at_time('2024').pole_dec` returns 54.4325° (IAU 2015). A 2012 paper's calculation is reproducible without the reader knowing the submodule name `iau2009` exists. Adding a future IAU edition is a one-line append to `_PCK_EDITION_DATES`. Module-level `at_time(body, field, date)` provides the function-form alternative.
- **`planetarypy.constants.nssdc` opt-in namespace** for users who want NSSDC-only data deliberately — `nssdc.Mars.GM` returns NSSDC's own GM solution (which may differ from PCK's), not the PCK-wins-merged value. `nssdc.history(body, field)` returns the full publication history as `(date, value, capture_url)` tuples — useful for science-history studies and drift audits. `nssdc.at_time(body, field, date)` for NSSDC-only date lookup.
- **NSSDC longitudinal archive deposited at Zenodo: [10.5281/zenodo.20122987](https://doi.org/10.5281/zenodo.20122987).** 913 distinct content versions of NSSDC's 13 fact sheets (Sun, Mercury, Venus, Earth, Moon, Mars, Jupiter, Saturn, Uranus, Neptune, Pluto, asteroid summary, comet summary) captured via the Internet Archive's Wayback Machine, spanning December 1996 to May 2025. Bundle includes the canonical parsed JSON, a long-format CSV mirror, the original raw HTML corpus, CDX provenance manifest, and the stdlib-only Python scripts that re-derive everything from public sources. Each capture indexed by NSSDC's own "Last Updated" footer date (with Wayback timestamp as fallback for pre-2003 captures where the footer didn't exist yet). The parsed archive auto-downloads from Zenodo on first use when not already in the user's local cache — same lazy pattern as PDS index parquets. MIT-licensed (matches the planetarypy library license).
- **Constants tutorial:** `docs/tutorials/constants_tutorial.ipynb` walks through everyday access, provenance, discovery helpers, time-travel, paper-reproducibility, the explicit `nssdc` namespace, and visualizing per-field drift with matplotlib (Saturn's satellite count from 18 in 1996 to 274 in 2025 as the headline example).
- **Acronym tooltips in HTML docs** via a small Lua filter (`docs/_abbreviations.lua`) + matching CSS (`docs/_styles-abbr.css`). Hovering NSSDC, NAIF, PCK, SPICE, IAU, GM, JPL, etc. shows a styled tooltip with the spelled-out form. Word-boundary safe; HTML-only (skipped for PDF/LaTeX); `aria-label` (not `title`) so screen readers get the expansion without the tiny native browser tooltip overlapping the styled one.

### Fixed
- **`Constant.__repr__` now shows source provenance for NSSDC-sourced fields.** Before, the rich repr (`<Constant Mars.GM = … (IAU 2015)>`) required `iau_year` to be truthy, and NSSDC constants set `iau_year=0` since NSSDC isn't IAU-edition-versioned. NSSDC constants therefore fell back to plain Quantity repr, hiding the source. Now uses the source string as the provenance tag when no IAU year is set: `<Constant Mars.bond_albedo = 0.25 (NSSDC marsfact.html updated 2025-05-19)>`. The metadata-empty fallback to plain Quantity repr is preserved for un-annotated Constants.

## [0.60.0] - 2026-05-04

### Added
- **`plp catalog samples <key>`** — print the sample products in the catalog DB for a `mission.instrument.product_key` triple. Wraps `planetarypy.catalog.example_products()` in a Rich table with `--phase` (filter to one mission phase) and `-n / --limit` (cap rows; 0 = all). Useful for inspecting what's actually catalogued for archives without a registered fetch resolver, where these samples are the only available products.
- **`plp indexes peek <key>`** — inspect a registered PDS index's schema and a few random rows. Output is transposed (one row of the index per column of the table) so it stays readable whether the index has 4 columns (`cassini.cda.index`) or 71 (`mro.hirise.edr`). Default 3 random rows; `-n / --rows N` to vary. Motivated by discovering that `cassini.cda.index` has `FILE_SPECIFICATION_NAME` / `DATA_SET_ID` instead of the usual `PRODUCT_ID` column — peek surfaces the schema before you have to guess which column to use.

## [0.59.5] - 2026-05-04

### Fixed
- **`Index.convert_to_parquet` no longer swallows conversion errors.** Previously, any exception during parsing or parquet writing was caught, logged at ERROR level, and dropped. With loguru disabled-by-default in this library, that error never reached the user — the downstream `pd.read_parquet(self.local_parq_path)` then raised `FileNotFoundError: …/CUMINDEX.parq` from a totally unrelated code path. Two real bugs (LAMP mixed-format times in v0.59.4, cassini.cda.index label/table mismatch below) both manifested as this misleading FileNotFoundError. `convert_to_parquet` now re-raises as `RuntimeError` with the index_key in the message and the original parser exception chained as `__cause__`.
- **`IndexLabel.index_path` raises a descriptive label/table mismatch error.** When a label's `^TABLE` pointer names a file that doesn't exist on disk (under either case), the previous code logged ERROR and returned a phantom path; downstream `pd.read_csv` then raised an unhelpful *"No such file or directory: index.tab"*. Now raises a `FileNotFoundError` that names the label, the declared table filename, what files ARE present in the directory, and labels the situation as a *publishing inconsistency in the source archive* — not auto-fixable in the local cache. `cassini.cda.index` is the canonical case: SETI publishes the cumulative table as `CUMINDEX.TAB` but the included `CUMINDEX.LBL` declares `^INDEX_TABLE = "INDEX.TAB"` (the per-volume convention). Combined with the `convert_to_parquet` re-raise, users of `plp meta cassini.cda.index <pid>` now see exactly what went wrong on the first try.

## [0.59.4] - 2026-05-04

### Changed
- **`plp catalog list <mission>` now distinguishes three states per instrument** instead of collapsing two of them into a blank cell. The previous two-column view ("instrument" + "fetchable product types") couldn't tell apart (a) instruments with no PDS index registered at all from (b) instruments that *are* indexed but lack a fetch resolver (e.g. `lro.lamp` — its index has no VOLUME_ID column, and the archive splits across `LROLAM_<N>` volume directories that can't be derived from row data). New "registered indexes" column lists the index names from the static config; the fetchable cell now shows `(no fetch resolver)` when at least one index exists but no `INDEX_REGISTRY` entry maps it. The second state matters because `plp meta lro.lamp.edr <pid>` works for those instruments — only `plp fetch` doesn't — and there was no way to discover that asymmetry from the catalog browse before.

### Fixed
- **`get_index()` / `plp meta` / `plp example_pid` now work on indexes with mixed-format time columns (LAMP).** `_convert_times` previously tried up to four format-detection strategies (auto / mixed / ISO 8601 / DOY) but each had to handle the *whole column* — fine for homogeneous columns, broken for indexes that mix per-row formats. LAMP's `START_TIME` has ISO calendar (`2009-07-06T12:47:18.250`), PDS DOY (`YYYY-DDDTHH:MM:SS`), and the occasional garbage value (`'0'`) all in one column. The chain failed at the strict-ISO step, the DOY fallback raised on the first non-DOY row, and the broad `except` in `convert_to_parquet` swallowed the error — symptom was `FileNotFoundError: …/CUMINDEX.parq` from `plp example_pid lro.lamp.edr` later, with the real cause hidden. Switched to a row-wise approach: `pd.to_datetime(errors="coerce", format="mixed")` parses what pandas can (turning unparseable rows to NaT), then a row-wise `_safe_doy` fills the NaTs with the DOY converter (NaT-tolerant — garbage that neither parser handles becomes NaT instead of aborting the whole conversion). Standard parser covers >99% of indexes; DOY is the targeted fallback for what's left.

## [0.59.3] - 2026-05-03

### Fixed
- **Stale catalog DB now fails fast with an actionable message.** When `~/planetarypy_data/catalog/<db>.duckdb` was built with planetarypy ≤ 0.52 (pre-PDS-catalog rewrite), its `product_types` table lacks the `normalized_type` column added in v0.53. Queries like `example_products` / `list_products(include_phases=True)` / `search` / `ambiguous_mappings` failed opaquely with `DuckDB Binder Error: Table 'pt' does not have a column named 'normalized_type'`. `get_catalog()` now runs `PRAGMA table_info(product_types)` after opening the connection and, if `normalized_type` is missing, raises:
  > `Stale catalog DB schema (built with planetarypy ≤ 0.52). Run `plp catalog build --force` to rebuild — the source-of-truth (pdr-tests + INDEX_REGISTRY) is unchanged, so no data is lost.`

  One gate covers every catalog query (every public function routes through `get_catalog()`).

## [0.59.2] - 2026-05-03

### Fixed
- **Reverts the v0.59.1 `fetch_product` index_key fallback.** That patch made `plp fetch lro.diviner.edr1 <pid>` succeed by mapping the index_key back to its catalog triple, but it hid a real ambiguity: `edr1`, `edr2`, and `edr` all returned the same row for the same `product_id` because `_load_index_df` already concatenates the two parquets and searches across both. The product physically lives in only one parquet; silently returning a "match" for the wrong index_key was incorrect. Restored the strict catalog-product_key contract for fetch.
- **Improved error when an index_key is passed where a catalog product_key was expected.** Replaces the misleading *"variable URL paths … no PDS index is available"* message (an index *was* available, just at the catalog product_key) with a direct pointer at the right key:
  > `'lro.diviner.edr1'` is an index_key (used by `plp meta` and `plp indexes`), not a catalog product_key. For fetching use `'lro.diviner.edr'`. See `plp indexes list lro.diviner` for the full index → catalog mapping.

  Inspection commands (`plp meta`, `plp indexes`, `plp example_pid`) keep their per-parquet index_keys; fetch operates on the catalog product_key. Different scopes = different keys, by design.

## [0.59.1] - 2026-05-03

### Fixed
- **`plp fetch` now accepts both index_keys and catalog product_keys.** The round-trip `plp fetch (plp example_pid <key>) <pid>` worked for instruments where the registered index_key equals the catalog product_key (`mro.ctx.edr`, `mro.hirise.edr`, …) but broke when one catalog product type was split across multiple parquets — Diviner's catalog `edr` triple maps to indexes `edr1` + `edr2`. `plp example_pid lro.diviner.edr1` would emit a valid PID but `plp fetch lro.diviner.edr1` failed with *"This product type has variable URL paths … no PDS index is available"* because `INDEX_REGISTRY` is keyed by catalog triple, not by index_key. New `_resolve_fetch_triple()` looks the dotted key up first as a catalog triple, then (if absent) as an `index_key` on every `IndexConfig.index_key` / `extra_index_keys` field. Both `catalog.fetch_product()` and `catalog.get_product_urls()` route through it.

## [0.59.0] - 2026-05-03

### Added
- **`plp catalog` browsing subcommands** — bring the (until now build-only) `plp catalog` namespace into parity with the API by exposing the existing `planetarypy.catalog.*` browse functions as CLI verbs. Each one renders a Rich table; the catalog browse cross-references the index registry so users can see at a glance which entries are fetchable.
    - `plp catalog list [KEY]` — three-level drill-down: no arg lists all 65 missions with per-mission counts and a `✓ fetchable` flag (set when at least one product type has an `INDEX_REGISTRY` entry); `KEY=mission` lists instruments with their fetchable variants; `KEY=mission.instrument` lists product types with their `index_key` mappings.
    - `plp catalog show <KEY>` — full info for a `mission.instrument.product_key` triple, including index_key / archive / SETI volume group / completion column / prefix-strip rule when fetchable, plus the catalog DB sample-products count.
    - `plp catalog search <QUERY>` — wraps `catalog.search()`.
    - `plp catalog summary` — wraps `catalog.summary()`.
    - `plp catalog ambiguous` — wraps `catalog.ambiguous_mappings()` (a tripwire surfacing pdr-tests folder names whose `(mission, instrument)` resolution falls through to the bare-name fallback at `_mission_map.py:1083` — empty today is the *healthy* signal).
- **`plp indexes` subtree** — new top-level namespace for browsing the *operational fetch surface* (the 78 registered PDS cumulative indexes from `~/.planetarypy_index_urls.toml`), kept visually separate from the `plp catalog` inventory tree to avoid confusing "what exists in PDS" with "what we can actually fetch".
    - `plp indexes list [KEY]` — three-level drill-down matching `plp catalog list`: missions → instruments → indexes. The `mission.instrument` level surfaces which indexes are cached locally with on-disk size and which have a catalog `product_key` entry. `--tree` falls back to the legacy `print_available_indexes()` tree.
    - `plp indexes info <KEY>` — `IndexConfig` + cache status for a single registered index, including remote URL, completion column, prefix-strip rule, archive base, and reverse-lookup catalog entries that map to this index.
    - `plp indexes refresh [--config|--cache <KEY>]` — explicit force-refresh of either the upstream `planetarypy_index_urls.toml` (normally auto-refreshed once per day) or a single index's cumulative `.lbl`/`.tab` + parquet rebuild.

### Fixed
- **`plp catalog` and `plp indexes` (bare invocation) now print help instead of erroring.** Both subapps lacked `no_args_is_help=True`, so `plp catalog` and `plp indexes` exited 2 with a "Missing argument" message rather than the subcommand list. Now mirrors the parent `app`'s behavior.

## [0.58.1] - 2026-05-01

### Fixed
- **`get_example_pid()` now returns the canonical user-facing PID form** (the same shape `complete_pid` caches and `get_meta` accepts), instead of stopping at `_bare_pid` (path/extension and version-suffix only). Indexes with an `IndexConfig.pid_strip_prefix_re` — currently the two cassini.iss variants — were emitting the un-stripped form: `plp example_pid cassini.iss.index` returned `1_N1454725799` while the canonical form is `N1454725799`, so the natural round-trip `plp meta cassini.iss.index (plp example_pid cassini.iss.index)` carried a stale prefix into the meta query. CTX, HiRISE, UVIS, etc. unchanged because they have no prefix-strip rule.

### Changed
- **Follow [planetarypy_configs#1](https://github.com/planetarypy/planetarypy_configs/pull/1) — Cassini canonical-key rename.** Three sections in the upstream `planetarypy_index_urls.toml` previously violated the `mission.instrument.indexname` dotted-key shape by encoding mission phase or activity mode in the instrument slot. After upstream merge, `INDEX_REGISTRY`'s `("cassini", "iss", "edr_evj")` entry now points at `cassini.iss.cruise_index` instead of `cassini.iss_cruise.index`. UVIS and VIMS occultation variants (`uvis_occ`, `vims_occ`) had no `INDEX_REGISTRY` entries to update — they were only reachable through the static-index registry — so they get the canonical key shape (`cassini.uvis.occ_index`, `cassini.vims.occ_profile_index`, etc.) for free on the next config refresh. Local users with cached parquets at `{storage_root}/cassini/{iss_cruise,uvis_occ,vims_occ}/...` will harmlessly orphan them and re-download under the new paths on first access (~50 MB across all three).

## [0.58.0] - 2026-04-30

### Added
- **`plp meta <key> <product_id>` and `planetarypy.pds.get_meta()`** — print the metadata row for a product from any registered PDS cumulative index, rendered as a Rich two-column table. Identifier (`*_ID`, `FILE_NAME`, `PATH_NAME`) fields are surfaced first, then `*ANGLE*` fields, then everything else. Matching is tolerant of case differences and PDS path/extension/version-suffix decoration. HiRISE EDR/RDR is special-cased via a per-instrument display registry: a bare obsid yields a short per-color summary across the observation (RED / BG / IR rows for `IMAGE_LINES`, `LINE_SAMPLES`, `SCALED_PIXEL_WIDTH`); `--long` returns the RED3_1 channel's full row; a channel-suffixed PRODUCT_ID returns that exact row. Non-instrument-specific indexes go through the generic path, so any registered index works out of the box.
- **`planetarypy.pds.read_index_slice(index_key, filters=None, columns=None)`** — column-projected, predicate-pushed-down parquet read for any registered index. Use this instead of `get_index()` when you need a few columns or rows: a per-obsid HiRISE EDR lookup goes from ~3.3 s (load all 86 MB / 2.6 M rows) to ~0.03 s (28 rows via row-group skipping) — a ~100× speedup. The HiRISE meta path uses this internally; full `plp meta` calls on HiRISE EDR drop from ~4 s to ~0.2 s (CTX `plp meta` unchanged at ~0.4 s).
- **`planetarypy.pds.complete_pid(incomplete, index_key)`** — generic shell tab-completion for any registered PDS index. Backed by a sorted text cache built lazily on first use from the index's configured completion column, with `_bare_pid` normalization (strips PDS path/extension and trailing `.NNN` version suffixes) and per-index prefix stripping (see `pid_strip_prefix_re` below). Replaces the per-instrument `complete_obsid()` / `complete_ctx_pid()` functions; CTX, HiRISE EDR/RDR, UVIS, ISS, and every other registered index now tab-complete uniformly. Lookups are sub-millisecond after the one-time cache build.
- **`planetarypy.instruments.mro.hirise.browse_url(product_id, annotated=True)`** — single source of truth for HiRISE EXTRAS browse-JPEG URL construction. `get_browse()` now calls it, removing duplicated URL formatting that previously lived in the `plp hibrowse` CLI command.
- **`planetarypy.instruments.mro.hirise.create_mosaics(obsid, colors=("red",), ccds=None, ...)`** — plural orchestrator that owns the per-color loop and the "ccds applies only to RED" rule. `plp himos` collapses to flag-mapping plus a single API call.
- **`local_dir` kwarg on `planetarypy.catalog.fetch_product()`** — overrides the storage path. The `plp fetch --here` / `-H` flag now maps cleanly through the public API instead of reaching into private resolver internals.
- **`IndexConfig.completion_id_col`** — column to surface for tab completion when it differs from `product_id_col`. HiRISE EDR/RDR/DTM set it to `OBSERVATION_ID` so users complete a 15-char obsid instead of one of the 28 channel-level PIDs per observation.
- **`IndexConfig.pid_strip_prefix_re`** — regex applied after `_bare_pid` to strip a per-index leading housekeeping prefix from both stored values and user input. cassini.iss / cassini.iss_cruise set it to `r"^.{1}_"` so the stored `1_N1454725799.122` and the typed `N1454725799` both normalize to the same canonical form.
- **Per-instrument meta-display registry** at `planetarypy.pds.meta_display.get_handler(index_key)` — routes `get_meta` to a custom shaping function when an index needs more than the generic two-column dump. Currently HiRISE EDR/RDR; the registry is the extension point for future instrument-specific summaries.

### Changed
- **`get_example_pid()` skips CRU-prefixed cruise PIDs.** Cruise-phase product IDs (e.g. CTX EDR's `CRU_000001_9999_XN_99N999W`) aren't representative examples of an instrument's typical mapping output. They're now treated like the existing `UNK` placeholder skip — preferred non-CRU rows, with fallback if every row is CRU. `plp example_pid mro.ctx.edr` now returns `MOI_000009_0186_XI_18S051W` instead of `CRU_000001_9999_XN_99N999W`.
- **CLI commands moved behind public APIs.** `plp fetch`, `plp hibrowse`, and `plp himos` no longer import private resolver/instrument symbols. CLI body is purely flag-to-API mapping plus output formatting; everything `plp` can do, the API can do directly. Per-instrument completion code (`complete_obsid`, `rebuild_obsid_cache`, `_obsid_cache_path` in `hirise.py`; `complete_ctx_pid`, `rebuild_pid_cache`, `_pid_cache_path` in `ctx_edr.py`) is removed in favor of the generic registry-driven path.

### Fixed
- **Eager-tuple performance bug in the generic `get_meta` matcher.** The three matching passes (exact / case-insensitive / bare-PID) were built as a tuple literal, so all three were always evaluated even when the cheapest one would have won — the per-row Python `apply(_bare_pid)` pass burned ~4 s per column on the 2.6 M-row HiRISE EDR index for nothing. Replaced with short-circuit if/elif and a sample-based "skip the apply pass entirely if neither side is decorated" probe.
- **HiRISE RDR meta queries no longer crash.** RDR has a different schema than EDR (post-mapping with `MAP_*` and `MINIMUM/MAXIMUM_LAT/LON` instead of `IMAGE_CENTER_*`; merged-color rows with no `CCD_NAME` / `CHANNEL_NUMBER` / `SCALED_PIXEL_WIDTH`), so the EDR-shaped column projection raised `ArrowInvalid: No match for FieldRef.Name(IMAGE_CENTER_LATITUDE)`. `format_meta` now routes EDR and RDR separately: RDR matches color-suffixed PIDs (`..._RED` / `..._COLOR` / `..._IRB`) directly and falls back to the obsid's `_RED` row for bare-obsid input.

## [0.57.0] - 2026-04-27

### Added
- **`list_products(<key>, include_phases=True)` now returns a `source` column** carrying the pdr-tests definition folder (e.g. `dawn__vir` vs `dawn_certified__vir`). Some instruments have parallel archive provenances for the same logical product type — the previous DataFrame projected only `normalized_type / phase / format / product_key`, so those rows looked like exact duplicates even though they pointed at different URL paths. Calling `list_products("dawn.vir", include_phases=True)` now plainly shows e.g. `edr / dawn__vir` and `edr / dawn_certified__vir` as the two distinct sources of an `edr` row.

## [0.56.0] - 2026-04-27

### Added
- **`plp fetch --folder` / `-d`** flag prints the local folder on stdout (single line) instead of the per-file absolute paths. Composes with shell `cd`:

    ```fish
    cd (plp fetch --folder mro.ctx.edr P02_001916_2221_XI_42N027W)
    ```

  Default behavior is unchanged — without the flag, `plp fetch` still emits one absolute file path per line, so `qgis (plp fetch …)` style multi-arg command substitution keeps working.

## [0.55.0] - 2026-04-27

### Changed
- **`planetarypy.catalog.fetch_product()` now returns a `DownloadedProduct` dataclass** instead of a bare `Path`. The CLI already printed absolute file paths to stdout (so `qgis (plp fetch …)` shell substitution worked) but the API silently discarded the file list and gave callers only the directory. The new bundle plumbs both pieces through:
    - `result.product_id` — canonical PID the resolver matched (post bare-PID normalization).
    - `result.local_dir` — `Path` to the folder.
    - `result.files` — `list[Path]` of every file actually written by this call (subset when `label_only=True` or an explicit `files=` filter is passed).
    - `result.label_file` — convenience pointer to the PDS `.LBL` / `.XML` if it was among the downloaded files, else `None`.
  
  **Migration**: callers that previously did `path = fetch_product(...)` should switch to `result.local_dir`. The new dataclass is also re-exported as `from planetarypy.catalog import DownloadedProduct` for type hints / `isinstance` checks.

## [0.54.0] - 2026-04-27

### Added
- **`planetarypy.pds.get_example_pid(instr_key)`** — generic helper that returns a sample product ID for any index registered in `~/.planetarypy_index_urls.toml` (or the dynamic handler registry). Useful as a seed for `plp fetch` demos, notebook examples, smoke tests, and tab-completion fixtures — previously each instrument module had to ship its own ad-hoc example PID. Resolves the product-id column via the catalog `INDEX_REGISTRY` when available (so non-standard cases like `cassini.uvis` using `FILE_NAME` as the PID column are handled correctly), then falls back to `PRODUCT_ID` / `FILE_NAME` / `IMAGE_ID` / `OBSERVATION_ID`. Skips `"UNK"` placeholder rows (e.g. early Galileo SSI cruise frames whose `PRODUCT_ID` is literally `"UNK"`) but degrades gracefully if every row is UNK. Raises `ValueError` on unknown index keys.
- **`plp example_pid <key>`** — CLI surface for the same. Prints the PID to stdout (so it composes with `plp fetch`), exits non-zero on unknown keys, and supports tab-completion over the registered dotted index keys.

### Changed
- **PIDs are now normalized to a bare canonical form** at both ends of the round trip. `get_example_pid` and the catalog `_find_product_in_index` / `resolve_from_index` go through a shared `_bare_pid` normalizer so `plp example_pid <key>` output composes directly with `plp fetch <key> <pid>`. Two-step rule:
    1. If the value's basename ends in a known PDS file extension (`.LBL .IMG .TAB .DAT .FIT .JP2 .QUB .XML`), strip path + extension. (e.g. `cassini.uvis.index` `FILE_NAME` of `/COUVIS_0001/.../EUV1999_007_17_05.LBL` → `EUV1999_007_17_05`.)
    2. Else strip a trailing `.<digits>` version suffix only. (e.g. `cassini.iss.index` PRODUCT_ID `1_N1454725799.122`, where `.122` is the FLIGHT_SOFTWARE_VERSION_ID, → `1_N1454725799`.)
    3. Else preserve the value verbatim — keeps slashes intact when they're PID separators rather than paths (e.g. `mgs.moc.edr` `FHA/00435`, `cassini.vims.index` `1/1294638283_1`). An earlier naïve form mishandled this and would have collapsed 7677 distinct MGS MOC PIDs into a single bare form.
- `ResolvedProduct.product_id` returned from `resolve_from_index` is now also the bare form, so the per-product storage folder created by `_local_product_dir` no longer contains nested archive paths for indexes whose PID column stores a full FILE_NAME.

### Fixed
- **`src/planetarypy/__init__.py.__version__`** was stuck at `0.41.2` because no `[[tool.bumpversion.files]]` entries existed in the existing `[tool.bumpversion]` config; recent releases (0.53.5–0.53.7) bumped only `pyproject.toml`. Resynced and now wired so future `bump-my-version bump <part>` runs keep both files in sync.

## [0.53.7] - 2026-04-24

### Fixed
- **Race-safe parquet/csv cache writes.** When parallel test workers (pytest-xdist) both triggered a first-time PDS index download (e.g. `get_index("mro.hirise.rdr")` from `test_spicer.TestSolarAzimuth`), two workers would finish downloading the `.lbl` + `.tab` files and simultaneously call `df.to_parquet(path)` into the same file. The non-atomic write produced a torn parquet, with the next reader hitting `OSError: Couldn't deserialize thrift: TProtocolException: Invalid data`. Same class of race existed for the SPICE archived-kernels `datasets.csv` cache via `df.to_csv(path)`. Both are now routed through a new `planetarypy.utils.atomic_write` context manager: each writer writes to a per-PID scratch file and atomically renames into place; the first concurrent finisher wins, later finishers silently drop their copy. Verified under an 8-thread stress test.

### Added
- `planetarypy.utils.atomic_write(path)` — context manager yielding a per-PID scratch `Path`; on clean exit, atomically renames it onto `path`. Reusable for any library-level cache write that can race.

## [0.53.6] - 2026-04-24

### Fixed
- `plp ctx-migrate` now walks each `mrox_*` volume recursively, so files already nested in `<pid>/` subfolders are counted as "already in place" instead of being silently skipped. Before this fix, a post-migration re-run reported `already in place: 0`, which looked alarming even though no moves were needed. After: the summary reflects the actual number of pid-matching files found.

## [0.53.5] - 2026-04-24

### Added
- **Separate mirror/local config for CTX EDR in `~/.planetarypy_mro_ctx.toml`.** The old single `[edr]` section conflated three things (mirror layout, local layout, download URL) under one set of `with_volume` / `with_pid` toggles, so users couldn't e.g. keep the shared read-only mirror in canonical PDS layout while storing new downloads next to their calib outputs. Two new optional sub-tables decouple them:

  ```toml
  [edr]
  url = "https://pds-imaging.jpl.nasa.gov/data/mro/ctx"

  [edr.mirror]                              # read-only; may be unmounted
  path = "/Volumes/planet/Mars/CTX/pds"
  with_volume = true
  with_pid = false
  with_data_segment = false                 # PDS canonical "<vol>/data/<pid>.IMG"

  [edr.local]                               # writeable; where new downloads go
  path = ""                                 # "" → {storage_root}/mro/ctx
  with_volume = true
  with_pid = true                           # co-locate raw EDR with calib outputs
  ```

  The legacy flat shape (`local_mirror`, `local_storage`, top-level `with_volume` / `with_pid`) is still read transparently — no user TOML edit is required. Opt in by adding the sub-tables when ready.

- **`plp ctx-migrate [--dry-run]`** — one-shot utility that walks each `mrox_*` volume folder under the configured EDR local root and relocates any file named `<pid>.<ext>` (26-char CTX product_id, so `.IMG`, `.cub`, `.lev1.cub`, `.lev2.cub`, `.lev2.tif`, `.lev1.gml`, `.csm2map.tif`, etc.) to whatever layout the active config dictates. Idempotent; conflicts are skipped with a warning rather than overwriting.

### Changed
- Internal CTX path helpers refactored from `ctx_storage_folder(level, …)` + `_level_base(level)` into three small readers `_edr_mirror_folder` / `_edr_local_folder` / `_calib_folder` plus a 7-line `_apply_toggles` helper. No external API change for `EDR` / `Calib` callers.

## [0.53.4] - 2026-04-24

### Fixed
- **`url_retrieve` is now concurrency-safe.** Previously two processes (e.g. parallel pytest-xdist workers hitting `load_generic_kernels()` via `Spicer("MARS")` / `Spicer("MOON")`) could clobber each other's `.part` scratch file and race on the final `rename()`, producing `FileNotFoundError`. The scratch file now includes the writer's PID (`{name}.{pid}.part`), and when a concurrent winner has already moved the final file into place the loser silently drops its scratch copy instead of raising. This was the root cause of intermittent CI failures in `test_spicer`.

### Changed
- CI workflow `test.yaml` now prefetches the SPICE generic kernels in a single-writer step before invoking `pytest`, so parallel test workers see cached files and never trigger the download path simultaneously. Complements the `url_retrieve` fix; either alone would green CI, both together harden the library for any concurrent caller.

## [0.53.3] - 2026-04-24

### Fixed
- **`plp fetch` and `plp hibrowse` now emit only the resolved file path on stdout.** Diagnostic lines ("Resolving…", "URL:…", "Fetching…") and the "Browse:" prefix previously mixed with the final path on stdout, which made shell command substitution clumsy (e.g. `qgis (plp fetch mro.ctx.edr <pid>)` captured all of it as arguments). Diagnostics now go to stderr; only the payload path hits stdout.

## [0.53.2] - 2026-04-24

### Fixed
- **CTX storage path mismatch between `plp fetch` and `ctxqv`/`EDR`.** `plp fetch mro.ctx.edr <pid>` previously wrote to `{storage_root}/mro/ctx/edr/<pid>/` (the catalog's generic layout), while `EDR(pid).local_storage_folder` (used by `plp ctxqv` and programmatic access) wrote to `{storage_root}/mro/ctx/<volume>/…` per `~/.planetarypy_mro_ctx.toml`. Downloads from one code path were invisible to the other, causing redundant re-downloads. Both paths now resolve through the single `ctx_storage_folder(level, volume, pid)` helper and land in the same directory.

### Changed
- CTX storage layout for `plp fetch mro.ctx.edr` now follows `~/.planetarypy_mro_ctx.toml` (`[edr].local_storage`, `[edr].with_volume`, `[edr].with_pid`) instead of the generic catalog fallback. A new `_ctx_local_product_dir` resolver is registered in `planetarypy.catalog._resolver._STORAGE_RESOLVER_MODULES`.
- CTX config (`CTXCONFIG`, mirror reachability) is now read lazily on each access rather than snapshotted at import — mounting or unmounting the local mirror mid-session is reflected immediately, and `with_volume` / `with_pid` config edits take effect without re-importing.
- `EDR.with_volume`, `EDR.with_pid`, `Calib.with_volume`, `Calib.with_pid` are now `@property` reads of `CTXCONFIG` (previously snapshotted in `__init__`).

### Removed
- Shadow duplicate `EDR` class in `planetarypy.instruments.mro.ctx.ctx_calib` (leftover from the original module split). `EDR` is now defined once in `ctx_edr.py` and imported from there.
- Module-level globals `STORAGE_ROOT`, `EDR_LOCAL_STORAGE`, `EDR_LOCAL_MIRROR`, `MIRROR_READABLE`, `MIRROR_WRITEABLE` in `ctx_edr.py` and their lowercase counterparts in `ctx_calib.py`. Replaced by lazy accessors (`_storage_root`, `_edr_local_mirror`, `_mirror_readable`, `_level_base`).

### Migration notes
- If you previously ran `plp fetch mro.ctx.edr <pid>` and have existing downloads under `{storage_root}/mro/ctx/edr/<pid>/`, they will **not** be picked up by the new layout. Either move them to `{storage_root}/mro/ctx/<volume>/[<pid>/]` (per your `[edr].with_volume` / `[edr].with_pid` toggles), delete them, or re-run `plp fetch` to download into the new location.

## [0.52.2] - 2026-04-13

### Fixed
- Only show satellite ephemeris download message when actually downloading (not when loading from cache)

## [0.52.1] - 2026-04-13

### Fixed
- Spicer now works for outer solar system bodies (Jupiter, Saturn, Neptune, Pluto systems) — satellite ephemeris SPKs are downloaded on demand when needed
- Graceful fallback in CLI when SPICE ephemeris data is missing (shows what it can instead of crashing)
- Suppress pvl PendingDeprecationWarning (pvl#109)

## [0.52.0] - 2026-04-13

> *Dedicated to the memory of Candice J. Hansen — scientist, mentor, and friend. This release was built in a single long push fueled by the urgency that reminds us our time to contribute is finite.*

### Added
- **Spicer class** (`planetarypy.spice.spicer`): surface illumination calculator for any solar system body
  - `Spicer("MARS").illumination(lon, lat, time)` — solar incidence, flux, L_s, local time
  - `slope` and `aspect` parameters for tilted surface flux (south-facing slopes etc.)
  - `solar_azimuth_at(lon, lat, time)` — SPICE-computed solar azimuth, validated to <1° against HiRISE index
  - `.Ls` property for current solar longitude
  - `sun_direction_at()` for azimuth calculation via Point class
  - `illumination_at(point)` integration with `planetarypy.geo.Point`
  - `supported_bodies()` — discover all bodies available from loaded kernels (79 from generic PCK)
  - `units=True` toggle for astropy Quantity output
  - Rotation via scipy (matching SPICE right-hand convention)
- **CLI**: `plp spicer Mars` — current L_s, subsolar point, solar constant; add `--lon --lat` for surface illumination
- Spicer tutorial with diurnal flux curve, slope/aspect comparison, multi-body demo, and HiRISE index validation

## [0.51.0] - 2026-04-13

### Added
- **Geospatial module** (`planetarypy.geo`): GDAL-free coordinate transforms built on rasterio + pyproj
  - `pixel_to_xy`, `xy_to_pixel`, `pixel_to_lonlat`, `lonlat_to_pixel`, `xy_to_lonlat`, `lonlat_to_xy`
  - `is_within(source, lon, lat)`: check if coordinates fall within an image
  - `image_azimuth`: clockwise from north (standard planetary science)
  - `image_azimuth_cw_from_right`: clockwise from 3 o'clock (HiRISE convention)
  - `pixel_resolution`: pixel size from affine transform
  - Works with IAU 2015 planetary CRS codes (Mars, Moon, any solar system body)
- **Point class** (`planetarypy.geo.Point`): CRS-aware geographic point
  - Create from lon/lat, pixel coordinates, or projected coordinates
  - `.to_xy()`, `.to_pixel()`, `.is_within()`, `.azimuth_to()`, `.to_shapely()`
  - Auto-resolves pixel↔lonlat when source DataArray is provided
- **Plotting module** (`planetarypy.plotting`): visualization helpers
  - `imshow_gray`: grayscale image display with percentile stretch
  - `percentile_stretch`: reusable stretch calculation
  - `add_sun_indicator`: sun direction overlay on any axes
  - `imshow_with_sun`: combined image display + sun indicator
- **HiRISE instrument module** (`planetarypy.instruments.mro.hirise`)
  - `get_browse(pid, annotated=True)`: download browse JPEG (annotated or clean)
  - `get_metadata(pid)`: look up index metadata
  - `sun_azimuth_from_top(pid)`: convert HiRISE CW-from-right to CW-from-top
- **CLI**: `plp hibrowse --annotated/--clean` option for browse variant
- **Geospatial tutorial**: pixel↔lonlat transforms, IAU CRS codes, Point class, sun indicator verification with real HiRISE data (ESP_013807_2035)
- `rasterio`, `pyproj`, `rioxarray` added to core dependencies

### Changed
- `plp hibrowse` and `plp hifetch` now use `planetarypy.instruments.mro.hirise` module instead of inline CLI helpers
- `plp ctxqv` uses `planetarypy.plotting.imshow_gray` instead of duplicating stretch logic

## [0.50.1] - 2026-04-13

### Fixed
- Move duckdb from optional `[catalog]` extra to core dependency (was breaking installs)
- Pandas 2.x compatibility: datetime64 resolution (ns→us) and string dtype (object→StringDtype) in test assertions
- Mock catalog DB in tests that hit `get_catalog()` (fixes CI without a built catalog)
- Stale docs: rewrite pds_index_config explanation, update landing page, fix tutorial tier numbering

### Added
- Logo in docs navbar and browser favicon

## [0.50.0] - 2026-04-13

> **Breaking change:** This is a ground-up rewrite with a new API.
> The previous version (0.32.x) based on nbplanetary remains at
> [github.com/michaelaye/nbplanetary](https://github.com/michaelaye/nbplanetary).

### Added
- **PDS Catalog module** (`planetarypy.catalog`): comprehensive index of ~2000 product types across 200+ instruments from the entire PDS archive, built from MillionConcepts pdr-tests repository into a local DuckDB database
  - `build_catalog()` to clone pdr-tests and populate the database
  - Query API: `list_missions()`, `list_instruments()`, `list_products()`, `example_products()`, `search()`, `summary()`
  - Dotted key access: `list_products("mro.hirise")`, `example_products("cassini.iss.edr_sat")`
  - 150+ manual mission/instrument mappings for pdr-tests folder names
  - AST-based parser for selection_rules.py (no code execution)
  - Multi-instrument folder splitting: folders like `mro` correctly split into `ctx`, `hirise`, `marci`, `mcs` instruments based on product key prefixes; infix matching for Rosetta-style `EDR_instrument` keys
  - Product key normalization: decompose keys like `edr_sat`, `sat_rdr_asc` into 3 dimensions — `normalized_type` (data type), `phase` (target body/mission phase), `format` (ascii/binary/coordinate system). Recognized phases include planets (saturn, jupiter, neptune, uranus, earth, pluto), minor bodies (ceres, vesta, gaspra, ida, arrokoth, phobos, halley), and mission phases (cruise, launch, kem_cruise)
  - `Mission` and `Instrument` objects with human-readable full names for all 65 missions and ~180 instruments (e.g. `Mission("mro").full_name` → "Mars Reconnaissance Orbiter", `mro["ctx"]` → "Context Camera")
  - Rosetta Lander (Philae) as separate mission entry with 8 properly split instruments
  - Voyager POS ephemeris override: standalone body keys normalized to `"ephemeris"` for pre-SPICE position data
  - Generic instrument groupings (spectrometers, particles, plasma, probe, dust, lander) decomposed into real instrument names across Galileo, NEAR, Rosetta, Voyager, Dawn, Deep Impact
  - `_misc` instruments hidden from `list_instruments()` by default; accessible via `include_misc=True` or `Mission.misc`
  - URL rewrite for broken USGS Imaging Node URLs (60 of 69 rewritten to SETI Rings and JPL Planetary Data mirrors)
  - Product download API: `fetch_product("mission.instrument.type", product_id)` downloads files and returns local path, `get_product_url()` returns remote URL, `list_product_files()` returns file-to-URL mapping
  - Index-backed resolution (Tier 2): 58 product types across 29 instruments on 15 missions — arbitrary product IDs resolved via PDS cumulative indexes for CTX, HiRISE, Cassini ISS, Galileo SSI, LROC, Diviner, CRISM, LOLA, Cassini UVIS/VIMS/CIRS, Voyager 1&2 ISS, Juno JunoCam, New Horizons LORRI, MER Pancam, MGS MOC, Viking VIS, MESSENGER MDIS, Cassini RSS, Phoenix MECA instruments (WCL/AFM/TECP/ELEC), and MSL (APXS, ChemCam, CheMin, SAM)
  - Pattern-based URL resolution (Tier 3): for product types with fixed `url_stem`, resolve arbitrary product IDs without needing a PDS index
  - Per-archive URL construction: `IndexConfig` supports `path_name_col` (for FILE_NAME + PATH_NAME split indexes), `lowercase_paths`/`lowercase_files` flags, `volume_id_col=""` to skip volume in URL, and `seti_volume_group="auto"` to derive SETI volume groups dynamically
  - Verified HTTP 200 for all 50 testable registry entries (7 indexes not yet downloaded, 1 removed)
  - Explanation doc: `docs/explanation/product_url_resolution.qmd` with full direct data access status table
  - Tutorial notebook in `docs/tutorials/pds_catalog_tutorial.ipynb`
- **Unified CLI** (`plp`): single entry point built on typer
  - `plp fetch mro.ctx.edr PRODUCT_ID` — download any product by dotted key
  - `plp fetch --here` — download into current directory
  - `plp hibrowse PSP_003092_0985_RED` — fetch HiRISE browse JPEG from EXTRAS, opens in Preview on macOS
  - `plp hifetch PSP_003092_0985_RED` — fetch full HiRISE data product
  - `plp ctxqv J05_046771_1950` — CTX quickview with strided memmap
  - `plp catalog build` — build/rebuild the catalog database
- **CTX quickview** (`EDR.quickview`, `Calib.quickview`): memory-mapped strided reads for fast previews
- Dynamic URL handlers for LRO LAMP EDR and RDR indexes (volume-based URLs at JPL)
- Backup URL fallback for CTX index (pdsimage2.wr.usgs.gov)
- Quarto documentation with Diátaxis framework structure
- New how-to guides: CTX calibration, CTX EDR, ISIS autoseed
- Comprehensive API reference documentation
- `slow` pytest marker for test filtering
- SPICE datasets daily caching system
- Case-insensitive mission name resolution for SPICE

### Changed
- Renamed `list_product_types()` → `list_products()` in catalog API
- Restructured catalog internals: `_download.py` → `_resolver.py`, `_index_bridge.py` → `_index_resolver.py`, `_url_patterns.py` + `_url_examiner.py` → `_pattern_resolver.py`
- Replaced click with typer for CLI; single `plp` entry point replaces `plp_update_indexes`, `plp_build_catalog`, `ctxqv`
- Migrated documentation from Sphinx to Quarto
- Split ctx.py into separate EDR and calibration modules
- Renamed HISTORY.md to CHANGELOG.md
- Adopted Keep a Changelog format

### Removed
- Dead code: `exceptions.py` (unused), `pds/cli.py` (broken imports), `scripts/` package, old Click-based CLIs

### Fixed
- Index bridge URL construction: correct case handling per archive server (lowercase paths for JPL/WUSTL, preserve case for SETI Rings/HiRISE), proper volume_id/path_name column support, and use actual filenames from index instead of guessing extensions
- Ambiguous product resolution: raises `MultipleProductsError` when an ID matches multiple products (e.g. HiRISE observation matching both RED and COLOR)
- Canonical PID casing: local storage paths use the index's canonical case, not the user's input
- Removed LRO LAMP from index registry (index lacks volume mapping needed for URL construction)
- Cloudflare 403 errors via User-Agent header in remote timestamp checks
- Repeated Index instantiations in dynamic handler
- Test failures from outdated DataFrame schema

## [0.41.2] - 2025-01-26

### Added
- pooch dependency for data downloads

## [0.41.1] - 2025-01-26

### Fixed
- Repeated Index instantiations in dynamic index handler

## [0.1.0] - 2020-10-20

### Added
- First release on PyPI
- PDS index management system
- SPICE kernel utilities
- Basic configuration management

---

## Historical Versions (Previous Project Incarnations)

> **Note:** The following versions are from predecessor projects that evolved into
> the current planetarypy. They are included for historical reference and are not
> installable from this repository.

### nbplanetary era (2021-2025)

Using nbdev (notebook-driven development) for a complete rewrite.

- **v0.27.0** (2023-06) - BepiColombo SPICE kernels, PDW2023 tutorials
- **v0.26.0** (2023-03) - CRISM and LROC index handlers
- **v0.25.0** (2023-02) - Spicer class, ISIS integration via kalasiris
- **v0.21.x** (2022-02) - Full instrument modules: CTX, HiRISE, UVIS, CISS, Diviner

### Original planetarypy era (2015-2020)

Private collection of planetary science tools, inspired by astropy's organization.

- **v0.9.0** (2020-07) - North azimuth and sun angle calculations
- **v0.8.0** (2020-07) - GeoTools module from pymars (coordinate transforms)
- **v0.7.0** (2020-06) - url_retrieve with progress bar and timeout
- **v0.6.0** (2020-05) - Powerful Index class, config system
- **v0.5.0** (2019-07) - Renamed to planetarypy (from planetpy)
- **v0.4.0** (2019-03) - PDS index download CLI, Cassini ISS indices
- **v0.1** (2015-04) - NASA factsheet planetary constants parser
