"""PDS index label handling and processing.

This module provides classes and functions for working with PDS index labels,
parsing index files, and converting them to convenient data structures.
"""

__all__ = [
    "PVLColumn",
    "IndexLabel",
    "index_to_df",
    "decode_line",
    "find_mixed_type_cols",
]
# Temporarily suppress PendingDeprecationWarning from pvl.collections.Units
# This can be removed once pvl version > 1.3.2 is used
import warnings

import warnings

import numpy as np
import pandas as pd

# pvl 1.3.2 triggers its own PendingDeprecationWarning on import
# (pvl internally uses Units instead of Quantity). Fixed in pvl main
# but not yet released. Remove this filter when pvl > 1.3.2 is out.
# See: https://github.com/planetarypy/pvl/issues/109
with warnings.catch_warnings():
    warnings.filterwarnings("ignore", message=".*pvl.collections.Units.*")
    import pvl
from fastcore.utils import Path
from loguru import logger
from tqdm.auto import tqdm

from .. import datetime_format_converters as tformats

warnings.filterwarnings("ignore", category=PendingDeprecationWarning, module="pvl")


class PVLColumn:
    """Manages just one of the columns in a table that is described via PVL.

    Parameters
    ----------
    
    pvlobj :
    """

    def __init__(self, pvlobj):
        self.pvlobj = pvlobj

    @property
    def name(self):
        return self.pvlobj["NAME"]

    @property
    def name_as_list(self):
        "needs to return a list for consistency for cases when it's an array."
        if self.items is None:
            return [self.name]
        else:
            return [self.name + "_" + str(i + 1) for i in range(self.items)]

    @property
    def start(self):
        "Decrease by one as Python is 0-indexed."
        return self.pvlobj["START_BYTE"] - 1

    @property
    def stop(self):
        return self.start + self.pvlobj["BYTES"]

    @property
    def items(self):
        return self.pvlobj.get("ITEMS")

    @property
    def item_bytes(self):
        return self.pvlobj.get("ITEM_BYTES")

    @property
    def item_offset(self):
        return self.pvlobj.get("ITEM_OFFSET")

    @property
    def colspecs(self):
        if self.items is None:
            return (self.start, self.stop)
        else:
            i = 0
            bucket = []
            for _ in range(self.items):
                off = self.start + self.item_offset * i
                bucket.append((off, off + self.item_bytes))
                i += 1
            return bucket

    def decode(self, linedata):
        if self.items is None:
            start, stop = self.colspecs
            return linedata[start:stop]
        else:
            bucket = []
            for start, stop in self.colspecs:
                bucket.append(linedata[start:stop])
            return bucket

    def __repr__(self):
        return self.pvlobj.__repr__()


class IndexLabel:
    "Support working with label files of PDS Index tables."

    def __init__(
        self,
        # Path to the labelfile for a PDS Indexfile.
        # The actual table should reside in the same folder to be automatically parsed
        # when calling the `read_index_data` method.
        labelpath: str | Path,
        index_key: str | None = None,
    ):
        self.path = Path(labelpath)
        self.index_key = index_key
        "search for table name pointer and store key and fpath."
        tuple = [i for i in self.pvl_lbl if i[0].startswith("^")][0]
        self.tablename = tuple[0][1:]
        self.index_name = tuple[1]

    @property
    def index_path(self):
        # Try the label-pointed name verbatim, then a lowercase fallback
        # (some archives publish lowercase filenames despite an uppercase
        # label pointer — a benign PDS quirk).
        for candidate in (self.index_name, self.index_name.lower()):
            p = self.path.parent / candidate
            if p.exists():
                return p

        # Neither variant exists — the label's ^TABLE pointer doesn't
        # match anything on disk. This is a real publishing inconsistency:
        # the cumulative table was downloaded under one name (typically
        # the .LBL stem, e.g. CUMINDEX.TAB) but the label declares a
        # per-volume canonical name (e.g. INDEX.TAB) that the archive
        # didn't actually publish at this path.
        present = sorted(
            f.name for f in self.path.parent.iterdir() if f.is_file()
        )
        raise FileNotFoundError(
            f"PDS label/table mismatch in {self.path.parent}: "
            f"the label {self.path.name!r} declares its data table as "
            f"{self.index_name!r} (^{self.tablename}), but no file with "
            f"that name (or its lowercase variant) exists in the directory. "
            f"Files present: {present}. "
            f"This is a publishing inconsistency in the source archive — "
            f"the label points at a filename that doesn't match the actual "
            f"downloaded data table. Not auto-fixable: the alternate file "
            f"would have to be obtained from the source archive separately."
        )

    @property
    def pvl_lbl(self):
        return pvl.load(str(self.path))

    @property
    def table(self):
        return self.pvl_lbl[self.tablename]

    @property
    def pvl_columns(self):
        return self.table.getlist("COLUMN")

    @property
    def columns_dic(self):
        return {col["NAME"]: col for col in self.pvl_columns}

    @property
    def colnames(self):
        """Read the columns in an PDS index label file.

        The label file for the PDS indices describes the content
        of the index files.
        """
        colnames = []
        for col in self.pvl_columns:
            colnames.extend(PVLColumn(col).name_as_list)
        return colnames

    @property
    def colspecs(self):
        colspecs = []
        columns = self.table.getlist("COLUMN")
        for column in columns:
            pvlcol = PVLColumn(column)
            if pvlcol.items is None:
                colspecs.append(pvlcol.colspecs)
            else:
                colspecs.extend(pvlcol.colspecs)
        return colspecs

    def read_index_data(self, convert_times=True):
        return index_to_df(self.index_path, self, convert_times=convert_times)


def _convert_times(df):
    missing_strings = [r"^UNK\s*$", r"^NULL\s*$", r"^N/A\s*$", r"^NA\s*$", r"^NONE\s*$"]
    for column in [col for col in df.columns if "TIME" in col]:
        if column in ["LOCAL_TIME", "DWELL_TIME"] or column.startswith("NTV"):
            continue
        logger.debug(f"Trying to convert {column} column to datetime type.")
        # Replace all known missing value strings with np.nan
        col_data = df[column]
        for miss in missing_strings:
            col_data = col_data.replace(miss, np.nan, regex=True)
        # Standard pandas parser first (handles ISO 8601, naive datetimes,
        # most common shapes via dateutil under the hood). errors="coerce"
        # turns the unparseable rows into NaT instead of aborting on the
        # first one — important for indexes that mix formats per-row (LAMP
        # has both ISO calendar 'YYYY-MM-DDTHH:MM:SS.fff' and PDS DOY
        # 'YYYY-DDDTHH:MM:SS' values in the same START_TIME column,
        # plus the occasional garbage like '0').
        parsed = pd.to_datetime(col_data, errors="coerce", format="mixed")
        # Anywhere the standard parser gave up but the source had a value,
        # fall back to our DOY-aware converter row by row, also tolerantly:
        # garbage that neither the standard parser nor DOY can read becomes NaT.
        def _safe_doy(value):
            try:
                return tformats.fromdoyformat(value)
            except (ValueError, TypeError):
                return pd.NaT

        needs_fallback = parsed.isna() & col_data.notna()
        if needs_fallback.any():
            n = int(needs_fallback.sum())
            logger.debug(
                f"{column}: standard parser handled {len(parsed) - n} rows; "
                f"applying DOY fallback to {n} remaining."
            )
            parsed.loc[needs_fallback] = (
                col_data.loc[needs_fallback].apply(_safe_doy)
            )
        df[column] = parsed
    logger.info("Converted time strings to datetime objects.")
    return df


def index_to_df(
    # Path to the index TAB file
    indexpath: str | Path,
    # Label object that has both the column names and the columns widths as attributes
    # 'colnames' and 'colspecs'
    label: IndexLabel,
    # Switch to control if to convert columns with "TIME" in name (unless COUNT is as well in name) to datetime
    convert_times: bool = True,
):
    """The main reader function for PDS Index files.

    In conjunction with an IndexLabel object that figures out the column widths,
    this reader should work for all PDS TAB files.
    """
    from .index_fixes import apply_file_fixer, apply_pre_time_df_fixer

    indexpath = Path(indexpath)
    # Apply any file-level fixers before parsing (if index_key known)
    if getattr(label, "index_key", None):
        apply_file_fixer(label.index_key, indexpath)
    # get n_lines fast for progress bar
    with open(indexpath, "rb") as f:  # courtesy of https://stackoverflow.com/a/1019572
        num_lines = sum(1 for _ in f)
    chunksize = 5000
    df = pd.concat(
        [
            chunk
            for chunk in tqdm(
                pd.read_csv(
                    indexpath,
                    header=None,
                    names=label.colnames,
                    chunksize=chunksize,
                    quotechar='"',
                    skipinitialspace=True,
                ),
                total=int(num_lines / chunksize),
                desc="Loading index in chunks",
            )
        ]
    )
    logger.info(f"Collected {len(df)} rows from {indexpath}")
    df = df.convert_dtypes()
    for col in df.select_dtypes(include=["string"]).columns:
        logger.debug(f"Stripping whitespace from string column {col}")
        df[col] = df[col].str.strip()
    # Apply any DataFrame-level pre-time fixers before converting times (if index_key known)
    if getattr(label, "index_key", None):
        df = apply_pre_time_df_fixer(label.index_key, df)
    if convert_times:
        df = _convert_times(df)
    return df


def decode_line(
    linedata: str,  # One line of a .tab data file
    labelpath: str | Path,  # Path to the appropriate label that describes the data.
):
    "Decode one line of tabbed data with the appropriate label file."
    label = IndexLabel(labelpath)
    for column in label.pvl_columns:
        pvlcol = PVLColumn(column)
        print(pvlcol.name, pvlcol.decode(linedata))


def find_mixed_type_cols(
    # Dataframe to be searched for mixed data-types
    df: pd.DataFrame,
    # Switch to control if NaN values in these problem columns should be replaced by the string 'UNKNOWN'
    fix: bool = True,
) -> list:  # List of column names that have data type changes within themselves.
    """For a given dataframe, find the columns that are of mixed type.

    Tool to help with the performance warning when trying to save a pandas DataFrame as a HDF.
    When a column changes datatype somewhere, pickling occurs, slowing down the reading process of the HDF file.
    """
    result = []
    for col in df.columns:
        weird = (df[[col]].map(type) != df[[col]].iloc[0].apply(type)).any(axis=1)
        if len(df[weird]) > 0:
            result.append(col)
            print(col)
            for i, t in df[weird][col].items():
                print(i, type(t))
    if fix:
        for col in result:
            df[col] = df[col].astype(str)
            # df[col] = df[col].fillna("UNKNOWN")
    return result
