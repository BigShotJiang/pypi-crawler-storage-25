# Premier Padel Python SDK

Typed Python SDK for Premier Padel public sports-data APIs.

## Installation

```bash
pip install premier-padel
```

For local development:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

## Quickstart

```python
from premier_padel import Gender, PremierPadelClient, ResultsDrawType

with PremierPadelClient() as client:
    players = client.players.list(Gender.MALE)
    top_player = players[0]

    profile = client.players.get(top_player.slug)
    tournaments = client.tournaments.list("March", 2026)
    results = client.tournaments.results("gijon-p2-2", "2026-03-07", ResultsDrawType.WOMEN)

    live_matches = client.matches.live("gijon-p2-2")
```

## Common Workflows

List and search players:

```python
from premier_padel import Gender, PremierPadelClient

with PremierPadelClient() as client:
    rankings = client.players.list(Gender.FEMALE)
    matches = client.players.search("tapia")
```

Paginate through video results:

```python
with PremierPadelClient() as client:
    first_page = client.media.videos()
    for item in first_page.iter_all():
        print(item.title)
```

Handle errors:

```python
from premier_padel import NotFoundError, PremierPadelClient

with PremierPadelClient() as client:
    try:
        player = client.players.get("missing-player")
    except NotFoundError:
        print("Player not found")
```

## Package Layout

- `src/premier_padel/client.py`: public client entrypoint
- `src/premier_padel/services/`: resource-oriented service layer
- `src/premier_padel/models/`: typed dataclasses for API resources
- `src/premier_padel/parsers/`: defensive response normalization
- `src/premier_padel/transport.py`: shared HTTP execution and envelope parsing

## Contributor Notes

Run checks locally with:

```bash
./.venv/bin/python -m pytest
./.venv/bin/python -m mypy src
./.venv/bin/python -m ruff check src tests
```

Optional live smoke tests are available behind `PREMIER_PADEL_LIVE_TESTS=1`.
