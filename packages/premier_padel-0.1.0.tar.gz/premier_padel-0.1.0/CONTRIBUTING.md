# Contributing

Thanks for contributing to `premier-padel`.

## Development Setup

```bash
python3.12 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

## Local Checks

Run the full validation suite before opening a pull request:

```bash
./.venv/bin/python -m pytest
./.venv/bin/python -m mypy src
./.venv/bin/python -m ruff check src tests
```

## Project Structure

- `src/premier_padel/client.py`: public client entrypoint
- `src/premier_padel/services/`: resource-oriented service layer
- `src/premier_padel/models/`: typed dataclasses exposed to users
- `src/premier_padel/parsers/`: defensive API payload normalization
- `src/premier_padel/transport.py`: shared HTTP execution and envelope parsing
- `tests/fixtures/`: captured payloads used for parser and service tests

## Contribution Guidelines

- Keep the public API small and predictable.
- Prefer typed models over raw dictionaries.
- Reuse existing parsers and transport helpers instead of duplicating request logic.
- Add or update tests for every behavior change.
- Preserve backward compatibility where practical, especially for public client methods.

## Adding New Endpoints

When adding a new API domain:

1. Add or extend typed models under `src/premier_padel/models/`.
2. Add parsers under `src/premier_padel/parsers/`.
3. Add resource methods under `src/premier_padel/services/`.
4. Add fixture-driven tests under `tests/`.
5. Update `README.md` if the change affects the public usage story.

## Release Notes

- Update `CHANGELOG.md` for user-visible changes.
- Keep packaging metadata in `pyproject.toml` aligned with the published release.
- GitHub Actions handles CI and package publishing workflows. Configure trusted publishing
  for the `testpypi` and `pypi` environments before using the release workflow.
