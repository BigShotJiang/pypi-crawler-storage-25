# Premier Padel SDK — Guida Completa alla Codebase

> Documento tecnico per chi vuole diventare owner di ogni dettaglio del progetto.

---

## Indice

1. [Panoramica del progetto](#1-panoramica-del-progetto)
2. [Struttura delle cartelle](#2-struttura-delle-cartelle)
3. [Dipendenze e tooling](#3-dipendenze-e-tooling)
4. [Architettura generale e flusso di una chiamata](#4-architettura-generale-e-flusso-di-una-chiamata)
5. [Modulo: `config.py`](#5-modulo-configpy)
6. [Modulo: `transport.py`](#6-modulo-transportpy)
7. [Modulo: `exceptions.py`](#7-modulo-exceptionspy)
8. [Modulo: `enums.py`](#8-modulo-enumspy)
9. [Modulo: `pagination.py`](#9-modulo-paginationpy)
10. [Modulo: `client.py`](#10-modulo-clientpy)
11. [Layer Models](#11-layer-models)
12. [Layer Parsers](#12-layer-parsers)
13. [Layer Services](#13-layer-services)
14. [Modulo `__init__.py` — public API](#14-modulo-__init__py--public-api)
15. [Scelte implementative e design rationale](#15-scelte-implementative-e-design-rationale)
16. [Testing](#16-testing)
17. [Flusso end-to-end: esempio completo](#17-flusso-end-to-end-esempio-completo)
18. [Estendere la SDK: checklist per un nuovo endpoint](#18-estendere-la-sdk-checklist-per-un-nuovo-endpoint)

---

## 1. Panoramica del progetto

`premier-padel` è una SDK Python **sincrona** che espone gli endpoint pubblici del sito Premier Padel in un'interfaccia tipizzata. Non richiede autenticazione (tutti gli endpoint sono sotto `/beforeauth/`).

- **Versione**: 0.1.0
- **Python**: ≥ 3.10
- **Unica dipendenza runtime**: `httpx` (≥ 0.27)
- **Build backend**: `hatchling`

---

## 2. Struttura delle cartelle

```
src/premier_padel/
├── __init__.py          ← public surface: re-esporta tutto ciò che l'utente deve usare
├── client.py            ← entrypoint principale: PremierPadelClient
├── config.py            ← configurazione immutabile del client
├── enums.py             ← enum typed per parametri API
├── exceptions.py        ← gerarchia di eccezioni custom
├── pagination.py        ← Page[T] generico e lazy iteration
├── transport.py         ← HTTP layer + parsing dell'envelope generico
├── models/              ← dataclass frozen (value objects)
│   ├── common.py
│   ├── matches.py
│   ├── media.py
│   ├── news.py
│   ├── players.py
│   ├── tournaments.py
│   └── watch.py
├── parsers/             ← funzioni pure: dict → model
│   ├── common.py
│   ├── matches.py
│   ├── media.py
│   ├── news.py
│   ├── players.py
│   ├── tournaments.py
│   └── watch.py
└── services/            ← orchestrazione: chiamata HTTP + parsing + cache
    ├── base.py
    ├── matches.py
    ├── media.py
    ├── news.py
    ├── players.py
    ├── rankings.py
    ├── tournaments.py
    └── watch.py
```

---

## 3. Dipendenze e tooling

| Tool | Scopo | Config |
|------|-------|--------|
| `httpx` | HTTP client sincrono | via `Transport` |
| `hatchling` | build e packaging | `pyproject.toml` |
| `pytest` | test runner | `testpaths = ["tests"]` |
| `ruff` | linting + formatting | target Python 3.10, line-length 100 |
| `mypy` | type checking **strict** | `mypy_path = "src"` |

Il progetto usa `from __future__ import annotations` ovunque per compatibilità con Python 3.10 senza costi a runtime (il forward reference evaluation diventa lazy).

---

## 4. Architettura generale e flusso di una chiamata

```
Utente
  │
  ▼
PremierPadelClient        (client.py)
  │  detiene referenze a tutti i servizi
  │
  ├─► Service (es. MatchService)   (services/*.py)
  │     │  risolve slug/id, chiama Transport, chiama Parser
  │     │
  │     ├─► Transport.post_form()  (transport.py)
  │     │     │  esegue HTTP POST multipart, gestisce retry/errori
  │     │     └─► ApiEnvelope  (struttura dati normalizzata dell'envelope)
  │     │
  │     └─► Parser (parsers/*.py)
  │           │  funzioni pure: dict → Model
  │           └─► Model frozen dataclass  (models/*.py)
  │
  └─► ritorna Model all'utente
```

**Ogni layer ha una sola responsabilità:**

- `Transport` non sa nulla di modelli o business logic
- I `Parser` non fanno HTTP
- I `Service` non costruiscono direttamente modelli
- I `Model` non hanno metodi, solo dati

---

## 5. Modulo: `config.py`

```python
@dataclass(frozen=True)
class ClientConfig:
    base_url: str   # default: https://premierpadel.com/premierpadel/api
    lang: str       # default: "en"
    timeout: float  # default: 10.0 secondi
    retries: int    # default: 2
    user_agent: str # default: "premier-padel-python/0.1.0"
```

**Perché `frozen=True`?** La configurazione viene creata una volta e condivisa tra Transport e Services. Il freezing garantisce che nessun codice la modifichi dopo l'inizializzazione, eliminando bug di race condition e side effect.

---

## 6. Modulo: `transport.py`

Questo è il cuore del networking. Contiene due classi:

### `ApiEnvelope`

```python
@dataclass(frozen=True)
class ApiEnvelope:
    status: int              # 1 = successo, altro = errore applicativo
    message: str | None      # messaggio testuale dall'API
    data: Any                # payload effettivo (lista o dict)
    current_page: int | None
    total_page: int | None
    total_jobs: int | None
    is_next_page: bool | None   # "Y"/"N" → True/False
    is_live_match: bool | None  # "Yes"/"No" → True/False
    raw: Mapping[str, Any]      # risposta grezza, usata per debug/errors
```

L'API Premier Padel restituisce sempre un envelope JSON con questa forma. L'`ApiEnvelope` normalizza tutti i tipi: ad esempio `is_next_page` arriva come stringa `"Y"` o `"N"` e viene convertita in `bool`.

### `Transport`

Il client `httpx.Client` viene creato una volta sola nel costruttore e riusato (connection pooling). Utilizza una base URL prefissata.

**Meccanismo di retry:**
```
for attempt in range(retries + 1):
    try:
        response = POST(...)
    except TimeoutException → riprova
    except TransportError   → riprova
    if status >= 500        → riprova (server error)
    else                    → break
```

I client error (4xx) non vengono ritentati perché rifare la stessa richiesta non cambierebbe l'esito.

**Perché multipart form invece di JSON?**
L'API del sito accetta solo `multipart/form-data` (non JSON body) quindi ogni parametro viene serializzato come stringa in un campo del form. I valori `None` vengono filtrati via.

**`_coerce_*` methods:** piccoli helper statici che gestiscono le inconsistenze dei tipi restituiti dall'API (numeri come stringhe, flag booleani come "Y"/"N"/"Yes"/"No").

---

## 7. Modulo: `exceptions.py`

Gerarchia completa:

```
PremierPadelError           ← base
├── NetworkError            ← API irraggiungibile
│   └── TimeoutError        ← timeout specifico
├── HTTPStatusError         ← risposta HTTP non 2xx
│   └── RateLimitError      ← 429
├── ApiResponseError        ← status!=1 nell'envelope applicativo
│   └── NotFoundError       ← risorsa non trovabile (slug/id sconosciuto)
└── ValidationError         ← shape inattesa nella risposta (bug dell'API o della SDK)
```

**Perché una gerarchia così granulare?** Permette all'utente di catturare solo ciò che gli interessa:
- `except NetworkError` → problemi di rete
- `except NotFoundError` → slug sbagliato
- `except PremierPadelError` → qualsiasi errore della SDK

`HTTPStatusError` e `ApiResponseError` includono `status_code`/`status` e `body`/`payload` per facilitare il debugging.

---

## 8. Modulo: `enums.py`

Tutti gli enum ereditano da `_StrEnum(str, Enum)`. Questo significa che ogni valore è anche una stringa Python normale, quindi può essere passato direttamente dove l'API si aspetta una stringa senza bisogno di `.value`.

```python
class Gender(_StrEnum):
    MALE = "Male"
    FEMALE = "Female"

class RankingScope(_StrEnum):
    OVERALL = "No"       # "No" = non filtrare per anno
    THIS_YEAR = "Yes"    # "Yes" = solo quest'anno

class BracketDrawType(_StrEnum):
    MEN_MAIN = "MD"
    WOMEN_MAIN = "WD"
    MEN_QUALIFYING = "MQ"
    WOMEN_QUALIFYING = "WQ"

class ResultsDrawType(_StrEnum):
    MEN = "Men"
    WOMEN = "Women"

class NewsSort(_StrEnum):
    NEWEST = "Newest"
    OLDEST = "Oldest"
```

I valori raw dell'API sono stati incapsulati in nomi semantici (`OVERALL` invece di `"No"`) per proteggere il codice utente da stringhe magiche.

---

## 9. Modulo: `pagination.py`

```python
@dataclass
class Page(Generic[T]):
    items: list[T]
    current_page: int
    total_pages: int | None
    has_next_page: bool
    _fetch_page: FetchPage[T] | None   # closure privata
```

`Page` è un **lazy cursor**:
- `page.next_page()` → richiama l'API per la pagina successiva
- `page.iter_all()` → generator che attraversa tutte le pagine in modo lazy

La closure `_fetch_page` viene iniettata dai servizi al momento della costruzione — ad esempio `lambda next_page: self.videos(page=next_page, lang=lang)`. Questo permette la pagination senza che `Page` sappia nulla di HTTP o servizi.

`Page` implementa `__iter__`, `__len__` e `__getitem__` quindi si comporta come una sequenza standard.

---

## 10. Modulo: `client.py`

`PremierPadelClient` è l'**unico punto di ingresso pubblico** per l'utente. Aggrega tutti i servizi:

```python
client = PremierPadelClient(lang="en", timeout=10.0, retries=2)
client.players      # PlayerService
client.rankings     # RankingService
client.tournaments  # TournamentService
client.matches      # MatchService
client.watch        # WatchService
client.media        # MediaService
client.news         # NewsService
```

### Context manager

Il client supporta `with PremierPadelClient() as client:` che garantisce la chiusura del pool HTTP anche in caso di eccezioni.

### Cache in-memory dei tornei e giocatori

Il client mantiene internamente:
- `_players_by_id`, `_players_by_slug` → cache dei giocatori già visti
- `_tournaments_by_id`, `_tournaments_by_slug` → cache dei tornei già visti

**Perché?** Molti endpoint ricevono come parametro un `TournamentArg = Tournament | int | str`. Se si passa uno slug stringa (es. `"wpt-marbella-master-2025"`) invece dell'ID numerico, il sistema deve risolvere lo slug. Invece di fare un'API call ogni volta, la cache permette di riutilizzare i dati.

### `_prime_tournament_cache()`

Quando si richiede un torneo per slug o ID sconosciuto, questo metodo scarica **l'intero calendario** (anno corrente ± 1, tutti i mesi) per popolare la cache. È costoso la prima volta ma poi tutte le lookup sono istantanee.

### `transport` injectable

Il costruttore accetta `transport: httpx.BaseTransport | None`. Questo permette di iniettare un transport mock nei test senza fare HTTP reale.

---

## 11. Layer Models

Tutti i modelli sono `@dataclass(frozen=True)`: immutabili e hashable. Non contengono logica, solo struttura dati.

### `models/common.py`

| Modello | Descrizione |
|---------|-------------|
| `Competitor` | Giocatore/partner con nome, immagine, bandiera, id opzionale |
| `StatisticValue` | Un lato di una statistica (won, played, percentage, is_winner) |
| `Statistic` | Riga statistica: titolo + team_1 + team_2 |

`Competitor` è condiviso da match, draw, tornei e giocatori — è il "tipo comune" per qualunque persona citata in un payload.

### `models/matches.py`

```
MatchScore      → set1-5, tie1-5, current_points
MatchTeam       → player (Competitor), partner (Competitor|None), score (MatchScore)
MatchCard       → summary di un match (live, upcoming, results) — ≈30 campi
MatchStats      → statistiche raggruppate: service, return, total_points, extra_sections
MatchDetail     → match (MatchCard) + stats (MatchStats|None)
LiveMatchDetail → wrapper per payload live non ancora stabilizzato (contiene il raw dict)
```

`LiveMatchDetail` è volutamente opaco: l'API live non ha uno schema stabile, quindi viene preservata come `Mapping[str, Any]` invece di essere modellata.

### `models/players.py`

```
PlayerSummary         → record leggero da ranking/search (14 campi)
PlayerTournamentResult → risultato di torneo embedded nel profilo
PlayerDetail          → profilo completo (≈35 campi, include tournaments[])
PlayerMoment          → sottoclasse di ShortReel (video del giocatore)
```

`PlayerSummary` e `PlayerDetail` hanno campi comuni (`id`, `slug`, `full_name`...) ma `PlayerDetail` è molto più ricco. La progettazione permette di usare `PlayerArg = PlayerSummary | PlayerDetail | int | str` ovunque.

### `models/tournaments.py`

```
Tournament            → entry del calendario (≈40 campi, flag is_live/is_result_available...)
TournamentDate        → data disponibile per i risultati
TournamentEntry       → coppia iscritta (player + partner, punti, rank)
TournamentEntrants    → grouped: men_main, women_main, men_q, women_q
DrawRound             → nome di un round nel tabellone
DrawContestant        → coppia nel tabellone (id stringa + players[])
DrawSide              → un lato di un match nel tabellone (chi è, punteggi, winner)
DrawMatch             → singolo match nel tabellone (round_index, order, sides[])
TournamentDraw        → tabellone completo: rounds + contestants dict + matches[]
TournamentResults     → risultati di un giorno: main_draw, qualify_draw, live, upcoming
```

### `models/media.py`

```
Video           → video generico (id, title, url, duration, tournament...)
ShortReel       → reel corto (≈25 campi, include likes, comments, tags...)
VideoPageMeta   → SEO metadata della pagina video
VideoPageHero   → hero media section
VideoPageSection → sezione della pagina (tipo + video[])
VideoPage       → meta + hero + sections[]
```

### `models/news.py`

```
NewsArticleSummary → record leggero dal listing (slug, titoli, immagini, date)
NewsArticle        → articolo completo: summary + html + meta + related_article
```

### `models/watch.py`

```
Broadcaster            → singolo broadcaster (tipo, url, immagine)
CountryBroadcasters    → paese + lista broadcaster
WatchInfo              → blocco informativo "dove guardare"
WatchTournamentOption  → torneo nel dropdown della sezione watch
```

---

## 12. Layer Parsers

I parser sono **funzioni pure** che trasformano un `dict` (payload JSON) in un modello tipizzato. Non fanno I/O né side effect.

### `parsers/common.py`

Questo modulo è il kit di attrezzi condiviso da tutti gli altri parser.

| Funzione | Scopo |
|----------|-------|
| `as_mapping(value, field_name)` | Forza un valore ad essere un dict, altrimenti `ValidationError` |
| `as_list(value, field_name)` | Forza un valore ad essere una lista, tratta `None`/`""` come lista vuota |
| `optional_str(value)` | Stringa o `None` (normalizza `""` a `None`) |
| `optional_int(value)` | Intero o `None`, tollera stringhe numeriche |
| `optional_bool(value)` | Parsa `"Yes"/"No"/"Y"/"N"/"1"/"0"` → `bool` o `None` |
| `optional_date(value)` | Parsa i due formati data usado dall'API: `"%Y-%m-%d"` e `"%d %B %Y"` |
| `optional_datetime(value)` | Parsa `"%Y-%m-%d %H:%M:%S"` e `"%m/%d/%Y %I:%M:%S %p"` |
| `enum_or_none(enum_type, value)` | Mappa una stringa a un enum senza eccezioni |
| `parse_competitor(...)` | Costruisce un `Competitor` |
| `parse_statistic_value(payload)` | Costruisce un `StatisticValue` |
| `parse_statistic(payload)` | Costruisce una `Statistic` |

**Design key:** `optional_*` functions trattano sia `None` che `""` come "assente". Questo è fondamentale perché l'API Premier Padel usa indiscriminatamente sia `null` JSON che stringhe vuote.

### `parsers/matches.py`

- `parse_match_score(payload)` → index `set1`…`set5`, `tie1`…`tie5`, `points`
- `parse_match_card(payload)` → costruisce `MatchTeam` x2 + tutti i metadati del match
- `parse_match_stats(payload)` → raggruppa le statistiche nelle sezioni note + `extra_sections` per quelle future
- `parse_match_detail(payload)` → naviga la chiave `match_score` per il match e `match_state` per le stats
- `parse_live_match_cards(data)` → itera una lista di match card
- `parse_upcoming_matches(payload)` → naviga la chiave `tournaments_match` nested
- `parse_live_match_detail(payload)` → ritorna `None` per liste vuote, `LiveMatchDetail` per dict

### `parsers/tournaments.py`

- `parse_tournament(payload)` → ≈40 campi, con boolean normalizzati come `is_live`, `is_result_available`
- `parse_tournament_date(payload)` → converte la data disponibile per i risultati
- `parse_tournament_entrant(payload)` → coppia iscritta con player/partner
- `parse_tournament_entrants(payload)` → raggruppa per draw type usando le chiavi `MD`, `WD`, `MQ`, `WQ`
- `parse_draw(payload, slug, draw_type)` → costruisce il tabellone: rounds, contestants dict, matches
- `parse_tournament_results(payload, ...)` → raggruppa i match per sezione

### `parsers/players.py`

- `parse_player_summary(payload)` → record leggero
- `parse_player_detail(payload)` → profilo completo con `tournaments[]`
- `parse_player_moment(payload)` → reel del giocatore

### `parsers/media.py`, `parsers/news.py`, `parsers/watch.py`

Seguono tutti lo stesso schema: un parser per ogni model del corrispondente modulo `models/`.

---

## 13. Layer Services

I servizi orchestrano: ricevono parametri tipizzati dall'utente, li risolvono, chiamano `Transport`, passano il payload al parser, restituiscono il modello.

### `services/base.py` — `BaseService`

Classe base che tutti i servizi ereditano. Contiene:

#### Type aliases per argomenti flessibili

```python
PlayerArg     = PlayerSummary | PlayerDetail | int | str
TournamentArg = Tournament | int | str
MatchArg      = MatchCard | int | str
```

Questo permette all'utente di passare sia oggetti già ottenuti dalla SDK che ID raw.

#### `_lang(lang)`
Risolve la lingua: usa quella passata esplicitamente, altrimenti quella del client.

#### `_unwrap(envelope)`
Punto centralizzato per il controllo `status == 1`. Se il server risponde con status applicativo ≠ 1, viene sollevata `NotFoundError` o `ApiResponseError`.

#### Resolver: da argomento flessibile a ID/slug concreto

| Metodo | Input | Output |
|--------|-------|--------|
| `_resolve_player_id(player)` | `PlayerArg` | `int` |
| `_resolve_match_id(match)` | `MatchArg` | `int` |
| `_resolve_tournament_slug(tournament)` | `TournamentArg` | `str` |
| `_resolve_tournament_id(tournament)` | `TournamentArg` | `int` |

I resolver usano la cache del client prima di fare ulteriori API call. Se necessario, scatenano il `_prime_tournament_cache()`.

### `services/players.py` — `PlayerService`

| Metodo | Endpoint | Restituisce |
|--------|----------|-------------|
| `list(gender, page, scope)` | `getplayerrankingv2` | `Page[PlayerSummary]` |
| `search(query, gender, page, scope)` | `getplayerrankingv2` | `Page[PlayerSummary]` |
| `iter_all(gender, scope, query)` | — | `Iterator[PlayerSummary]` |
| `get(slug)` | `getplayerdetails` | `PlayerDetail` |
| `moments(player, page, page_size)` | `getplayervideos` | `Page[PlayerMoment]` |

`search()` senza `gender` esegue due chiamate in parallelo (maschile + femminile) e combina i risultati in una singola `Page`. Tutti i giocatori trovati vengono salvati in cache via `_remember_player`.

### `services/rankings.py` — `RankingService`

Wrapper puro over `PlayerService`: `rankings.list(...)` delega a `players.list(...)`. Esiste solo come alias semantico per uso tipo `client.rankings.list(Gender.MALE)`.

### `services/tournaments.py` — `TournamentService`

| Metodo | Endpoint | Restituisce |
|--------|----------|-------------|
| `list(month, year, page, page_size)` | `getfanapptournaments` | `list[Tournament]` o `Page[Tournament]` |
| `iter_all(month, year, page_size)` | — | `Iterator[Tournament]` |
| `players(tournament)` | `gettournamentsplayer` | `TournamentEntrants` |
| `draw(tournament, draw_type)` | `gettournamentsmatchdraw` | `TournamentDraw` |
| `result_dates(tournament)` | `gettournamentsdate` | `tuple[TournamentDate, ...]` |
| `results(tournament, date, draw)` | `gettournamentsmatchlistnew` | `TournamentResults` |

`list()` ha un comportamento duale: senza `page` restituisce una lista flat, con `page` restituisce una `Page[Tournament]`. Ogni torneo listato viene salvato in cache.

### `services/matches.py` — `MatchService`

| Metodo | Endpoint | Restituisce |
|--------|----------|-------------|
| `live(tournament)` | `gettournamentslivematch` | `tuple[MatchCard, ...]` |
| `upcoming(tournament)` | `gettournamnetupcomingmatches` | `tuple[MatchCard, ...]` |
| `detail(match)` | `gettournamentsmatchdetail` | `MatchDetail` |
| `live_detail(match)` | `getlivematchdetail` | `LiveMatchDetail \| None` |

`live_detail` restituisce `None` quando non c'è un live disponibile (l'API restituisce una lista vuota in quel caso).

### `services/media.py` — `MediaService`

| Metodo | Endpoint | Restituisce |
|--------|----------|-------------|
| `videos(page)` | `getvideo` | `Page[Video]` |
| `reels(short_id, page, page_size)` | `getshortsreels` | `Page[ShortReel]` |
| `video_page(year, tournament, search)` | `getvideopage` | `VideoPage` |

### `services/news.py` — `NewsService`

| Metodo | Endpoint | Restituisce |
|--------|----------|-------------|
| `list(sort, page_size)` | `getnewsletter` | `tuple[NewsArticleSummary, ...]` |
| `get(slug)` | `getnewsdetails` | `NewsArticle` |

`list()` non è paginata: restituisce tutti gli articoli in una sola chiamata (`pagesize=-1`).

### `services/watch.py` — `WatchService`

| Metodo | Endpoint | Restituisce |
|--------|----------|-------------|
| `broadcasters(tournament)` | `getwheretowatch` | `tuple[CountryBroadcasters, ...]` |
| `tournaments()` | `gettournamentsdropdown` | `tuple[WatchTournamentOption, ...]` |
| `info()` | `getwheretowatchinfo` | `tuple[WatchInfo, ...]` |

---

## 14. Modulo `__init__.py` — public API

Esporta esplicitamente solo ciò che serve all'utente finale:

```python
from premier_padel import (
    PremierPadelClient,     # client
    Gender, RankingScope, BracketDrawType, ResultsDrawType, NewsSort,  # enums
    PremierPadelError, NetworkError, TimeoutError, HTTPStatusError,
    RateLimitError, ApiResponseError, NotFoundError, ValidationError,  # exceptions
    Page,                   # pagination
)
```

Tutto il resto (Transport, parsers, modelli interni) è considerato implementazione privata. L'utente non dovrebbe importare nulla da sotto-moduli.

---

## 15. Scelte implementative e design rationale

### Sincrono vs Asincrono

La SDK è **solo sincrona**. La scelta è deliberata: `httpx` supporta anche async ma aggiungere `async/await` avrebbe richiesto un'API duale o la duplicazione del codice. Per la maggior parte degli use case (script di analisi, bot, data ingestion), il sincrono è sufficiente e più semplice da usare.

### `frozen=True` su tutti i modelli

I modelli sono value objects: non ha senso modificarli dopo la creazione. `frozen=True` fornisce:
- Immutabilità garantita
- `__hash__` automatico (i modelli possono essere usati in set/dict key)
- Migliore chiarezza semantica

### Gerarchia di `PlayerArg` / `TournamentArg`

```python
PlayerArg = PlayerSummary | PlayerDetail | int | str
```

Permette massima flessibilità nell'uso:
```python
# tutte e quattro queste chiamate sono valide:
client.players.moments(some_player_detail)
client.players.moments(some_player_summary)
client.players.moments(12345)
client.players.moments("juan-lebron")
```

### Cache client-level

La cache in `PremierPadelClient` è a livello di istanza, non globale. Questo significa che ogni client ha la sua cache → nessun problema di thread safety tra client diversi. La cache non ha TTL: è pensata per sessioni di breve durata (script, task singoli).

### Parsers come funzioni pure

I parser non sono classi né metodi di modello: sono semplici funzioni nel loro modulo. Questo li rende:
- Facilmente testabili in isolamento con un dict fixture
- Riutilizzabili tra servizi diversi (es. `parse_match_card` è usato sia in `matches`, sia in `tournaments`)
- Privi di stato → nessun side effect

### `ValidationError` vs errori silenziosi

Quando la shape del payload è inattesa, la SDK solleva `ValidationError` invece di ignorare il campo. Questo è un trade-off conservativo: meglio fallire rumorosamente in sviluppo/test che ritornare dati silenziosi sbagliati in produzione.

### `LiveMatchDetail` opaco

Il modello `LiveMatchDetail` espone solo `payload: Mapping[str, Any]` invece di campi tipizzati. Motivazione esplicita nel docstring: *"the schema is not yet stable enough to normalize"*. Questo è un anti-pattern intenzionale per evitare breaking change ogni volta che l'API cambia la struttura del live.

---

## 16. Testing

```
tests/
├── conftest.py              ← fixtures condivise (client mock, fixture loader)
├── fixtures/                ← JSON reali salvati dall'API, usati come mock response
├── test_client.py
├── test_transport.py
├── test_live_smoke.py       ← smoke test che fanno HTTP reale (opzionale)
├── test_matches.py
├── test_media.py
├── test_news.py
├── test_players.py
├── test_tournaments.py
└── test_watch.py
```

La strategia di test si basa su:
1. **Fixture JSON**: file nella cartella `tests/fixtures/` catturati da risposte reali dell'API. I test unitari li iniettano tramite il transport mock invece di fare HTTP.
2. **Transport injectable**: il `PremierPadelClient` accetta `transport=` nel costruttore → si può passare un `httpx.MockTransport` per rispondere con i JSON delle fixture.
3. **`test_live_smoke.py`**: test che fanno HTTP reale verso l'API pubblica, usati manualmente o in CI con flag speciali.

---

## 17. Flusso end-to-end: esempio completo

**Scenario**: ottenere la lista di match live di un torneo passando il suo slug.

```python
client = PremierPadelClient()
matches = client.matches.live("wpt-marbella-master-2025")
```

**Passo 1 — `MatchService.live("wpt-marbella-master-2025")`**
- Chiama `_resolve_tournament_slug("wpt-marbella-master-2025")`
- Lo slug è già una stringa non numerica → viene restituito as-is (nessuna API call per la lookup)

**Passo 2 — `Transport.post_form("/beforeauth/gettournamentslivematch", {"slug": "wpt-..."})`**
- Serializza `slug` come campo form multipart
- Esegue `POST https://premierpadel.com/premierpadel/api/beforeauth/gettournamentslivematch`
- In caso di 5xx: ritenta (max 2 volte)
- Parsa il JSON → `ApiEnvelope(status=1, data=[{...}, {...}], ...)`

**Passo 3 — `_unwrap(envelope)`**
- `status == 1` → restituisce `envelope.data` (lista di dict)

**Passo 4 — `parse_live_match_cards(data)`**
- Itera la lista
- Per ogni dict chiama `parse_match_card(payload)`
- Costruisce `MatchTeam` x2, `MatchScore` x2, `MatchCard` completo
- Restituisce `tuple[MatchCard, ...]`

**Passo 5 — Utente riceve** `(MatchCard(...), MatchCard(...))`

---

## 18. Estendere la SDK: checklist per un nuovo endpoint

Supponiamo di voler aggiungere l'endpoint `/beforeauth/getplayerheadtohead`:

1. **Model** (`src/premier_padel/models/players.py`)
   - Aggiungere `@dataclass(frozen=True) class HeadToHead: ...` con tutti i campi

2. **Parser** (`src/premier_padel/parsers/players.py`)
   - Aggiungere `def parse_head_to_head(payload: Mapping[str, Any]) -> HeadToHead: ...`
   - Usare i helpers di `parsers/common.py`

3. **Service** (`src/premier_padel/services/players.py`)
   - Aggiungere il metodo in `PlayerService`:
     ```python
     def head_to_head(self, player_a: PlayerArg, player_b: PlayerArg) -> HeadToHead:
         ...
         envelope = self._client._transport.post_form("/beforeauth/getplayerheadtohead", {...})
         payload = self._unwrap(envelope)
         return parse_head_to_head(as_mapping(payload, "data"))
     ```

4. **Export** (`src/premier_padel/__init__.py`)
   - Se `HeadToHead` è un tipo che l'utente deve annotare, aggiungerlo a `__all__`

5. **Test** (`tests/`)
   - Salvare una fixture JSON reale in `tests/fixtures/`
   - Scrivere un test in `tests/test_players.py` usando il mock transport

6. **Type check**: eseguire `mypy src/` — lo strict mode forza la completezza di tutte le annotazioni

---

*Documento generato il 8 marzo 2026 — Premier Padel SDK v0.1.0*
