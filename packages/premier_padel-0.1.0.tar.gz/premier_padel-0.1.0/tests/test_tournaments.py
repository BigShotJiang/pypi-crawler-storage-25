from __future__ import annotations

from datetime import date

from premier_padel import BracketDrawType, ResultsDrawType

from .conftest import load_fixture


def test_tournament_list_and_related_resources(client_factory) -> None:
    routes = {
        "/beforeauth/getfanapptournaments": load_fixture("tournaments_list.json"),
        "/beforeauth/gettournamentsplayer": load_fixture("tournament_players.json"),
        "/beforeauth/gettournamentsdate": load_fixture("tournament_dates.json"),
        "/beforeauth/gettournamentsmatchlistnew": load_fixture("tournament_results.json"),
        "/beforeauth/gettournamentsmatchdraw": load_fixture("tournament_draw.json"),
    }
    client = client_factory(routes)

    tournaments = client.tournaments.list("March", 2026)
    entrants = client.tournaments.players("gijon-p2-2")
    result_dates = client.tournaments.result_dates("gijon-p2-2")
    results = client.tournaments.results("gijon-p2-2", date(2026, 3, 7), ResultsDrawType.WOMEN)
    draw = client.tournaments.draw("gijon-p2-2", BracketDrawType.WOMEN_MAIN)

    assert tournaments[0].id == 259
    assert entrants.men_main[0].player.name == "Agustin Tapia"
    assert result_dates[0].date.isoformat() == "2026-03-07"
    assert results.main_draw[0].id == 6004
    assert draw.rounds[0].name == "R32"
    assert "P200002" in draw.contestants


def test_tournament_list_paged_returns_page(client_factory) -> None:
    routes = {
        "/beforeauth/getfanapptournaments": load_fixture("tournaments_list.json"),
    }
    client = client_factory(routes)

    page = client.tournaments.list("March", 2026, page=1, page_size=10)

    assert page.current_page == 1
    assert page.total_pages == 1
    assert len(page.items) == 2
