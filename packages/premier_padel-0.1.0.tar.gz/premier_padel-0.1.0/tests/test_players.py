from __future__ import annotations

import pytest

from premier_padel import Gender, NotFoundError, RankingScope

from .conftest import load_fixture


def test_players_list_and_search(client_factory) -> None:
    routes = {
        "/beforeauth/getplayerrankingv2": load_fixture("rankings_page.json"),
    }
    client = client_factory(routes)

    page = client.players.list(Gender.MALE)
    search_page = client.players.search("tapia", gender=Gender.MALE, scope=RankingScope.OVERALL)

    assert page[0].slug == "agustin-tapia"
    assert page.has_next_page is True
    assert search_page[1].id == 12


def test_players_search_without_gender_combines_pages(client_factory) -> None:
    calls = {"count": 0}

    def handler(request):
        calls["count"] += 1
        return httpx.Response(200, json=load_fixture("rankings_page.json"))

    import httpx

    client = client_factory(handler)
    page = client.players.search("tapia")

    assert calls["count"] == 2
    assert len(page.items) == 4


def test_player_detail_and_moments_with_slug_resolution(client_factory) -> None:
    routes = {
        "/beforeauth/getplayerdetails": load_fixture("player_detail.json"),
        "/beforeauth/getplayervideos": load_fixture("player_moments_page.json"),
    }
    client = client_factory(routes)

    detail = client.players.get("agustin-tapia")
    moments = client.players.moments("agustin-tapia")

    assert detail.partner_player_name == "Arturo Coello"
    assert moments[0].id == 7866
    assert moments.has_next_page is True


def test_player_detail_invalid_slug_maps_to_not_found(client_factory) -> None:
    routes = {
        "/beforeauth/getplayerdetails": load_fixture("api_invalid_player.json"),
    }
    client = client_factory(routes)

    with pytest.raises(NotFoundError):
        client.players.get("missing-player")
