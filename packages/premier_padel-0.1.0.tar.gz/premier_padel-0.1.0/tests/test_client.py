from __future__ import annotations

import httpx

from premier_padel import Gender, PremierPadelClient

from .conftest import load_fixture


def test_client_context_manager_closes_transport() -> None:
    routes = {
        "/beforeauth/getplayerrankingv2": load_fixture("rankings_page.json"),
    }

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=routes["/beforeauth/getplayerrankingv2"])

    with PremierPadelClient(transport=httpx.MockTransport(handler)) as client:
        page = client.players.list(Gender.MALE)

    assert page[0].full_name == "Agustin Tapia"


def test_slug_resolution_uses_tournament_cache() -> None:
    routes = {
        "/beforeauth/getfanapptournaments": load_fixture("tournaments_list.json"),
        "/beforeauth/gettournamnetupcomingmatches": load_fixture("upcoming_matches.json"),
    }
    calls: dict[str, int] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path.replace("/premierpadel/api", "", 1)
        calls[path] = calls.get(path, 0) + 1
        return httpx.Response(200, json=routes[path])

    client = PremierPadelClient(transport=httpx.MockTransport(handler))

    first = client.matches.upcoming("gijon-p2-2")
    second = client.matches.upcoming("gijon-p2-2")
    cached = client._lookup_tournament_by_slug("miami-p1")

    assert first[0].tournament_id == 259
    assert second[0].tournament_id == 259
    assert cached.id == 261
    assert calls["/beforeauth/getfanapptournaments"] == 1
    assert calls["/beforeauth/gettournamnetupcomingmatches"] == 2
    assert set(client._tournaments_by_slug) == {"gijon-p2-2", "miami-p1"}
    assert set(client._tournaments_by_id) == {259, 261}
