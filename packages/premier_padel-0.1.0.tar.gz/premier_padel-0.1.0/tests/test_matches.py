from __future__ import annotations

from .conftest import load_fixture


def test_matches_live_upcoming_detail_and_live_detail(client_factory) -> None:
    routes = {
        "/beforeauth/getfanapptournaments": load_fixture("tournaments_list.json"),
        "/beforeauth/gettournamentslivematch": load_fixture("live_matches_empty.json"),
        "/beforeauth/gettournamnetupcomingmatches": load_fixture("upcoming_matches.json"),
        "/beforeauth/gettournamentsmatchdetail": load_fixture("match_detail.json"),
        "/beforeauth/getlivematchdetail": load_fixture("live_detail.json"),
    }
    client = client_factory(routes)

    live = client.matches.live("gijon-p2-2")
    upcoming = client.matches.upcoming("gijon-p2-2")
    detail = client.matches.detail(6004)
    live_detail = client.matches.live_detail(6004)

    assert live == ()
    assert upcoming[0].match_code == "WD001"
    assert detail.stats is not None
    assert detail.stats.service[0].title == "Aces"
    assert live_detail is not None
    assert live_detail.match_code == "MD001"
    assert live_detail.server == 3
    assert live_detail.team_1.score.current_points == "40"
    assert live_detail.team_2.score.current_points == "40"


def test_matches_live_detail_empty_response_returns_none(client_factory) -> None:
    client = client_factory(
        {"/beforeauth/getlivematchdetail": load_fixture("live_detail_empty.json")}
    )

    assert client.matches.live_detail(6004) is None
