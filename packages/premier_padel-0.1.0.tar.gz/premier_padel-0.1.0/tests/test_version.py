from __future__ import annotations

from importlib.metadata import PackageNotFoundError

from premier_padel._version import build_user_agent, get_installed_version


def test_build_user_agent_uses_supplied_version() -> None:
    assert build_user_agent("1.2.3") == "premier-padel-python/1.2.3"


def test_get_installed_version_falls_back_when_package_metadata_is_missing(
    monkeypatch,
) -> None:
    def raise_not_found(_: str) -> str:
        raise PackageNotFoundError

    monkeypatch.setattr("premier_padel._version.version", raise_not_found)

    assert get_installed_version("premier-padel") == "0+unknown"
