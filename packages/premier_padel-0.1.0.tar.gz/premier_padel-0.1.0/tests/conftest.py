from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path
from typing import Any

import httpx
import pytest

from premier_padel import PremierPadelClient

FIXTURES_DIR = Path(__file__).parent / "fixtures"
Routes = dict[str, Any] | Callable[[httpx.Request], httpx.Response]


def load_fixture(name: str) -> Any:
    return json.loads((FIXTURES_DIR / name).read_text())


def make_transport(routes: Routes) -> httpx.MockTransport:
    if callable(routes):
        return httpx.MockTransport(routes)

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path.replace("/premierpadel/api", "", 1)
        payload = routes[path]
        if isinstance(payload, httpx.Response):
            return payload
        return httpx.Response(200, json=payload)

    return httpx.MockTransport(handler)


@pytest.fixture
def client_factory():
    def factory(routes: Routes) -> PremierPadelClient:
        return PremierPadelClient(transport=make_transport(routes))

    return factory
