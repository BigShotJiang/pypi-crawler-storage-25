from __future__ import annotations

import httpx
import pytest

from premier_padel.config import ClientConfig
from premier_padel.exceptions import ApiResponseError, HTTPStatusError, NetworkError
from premier_padel.transport import Transport


def test_transport_sends_multipart_and_parses_envelope() -> None:
    seen: dict[str, str] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["content_type"] = request.headers["content-type"]
        seen["body"] = request.read().decode()
        return httpx.Response(
            200,
            json={
                "status": 1,
                "message": None,
                "data": [{"id": 1}],
                "current_page": 1,
                "total_page": 2,
                "is_next_page": "Y",
            },
        )

    transport = Transport(ClientConfig(), transport=httpx.MockTransport(handler))
    envelope = transport.post_form("/beforeauth/test", {"page": 1, "lang": "en"})

    assert "multipart/form-data" in seen["content_type"]
    assert 'name="page"' in seen["body"]
    assert envelope.status == 1
    assert envelope.current_page == 1
    assert envelope.total_page == 2
    assert envelope.is_next_page is True


def test_transport_retries_server_errors() -> None:
    attempts = {"count": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        attempts["count"] += 1
        if attempts["count"] == 1:
            return httpx.Response(503, text="busy")
        return httpx.Response(200, json={"status": 1, "data": []})

    transport = Transport(ClientConfig(retries=1), transport=httpx.MockTransport(handler))
    envelope = transport.post_form("/beforeauth/test", {"lang": "en"})

    assert attempts["count"] == 2
    assert envelope.status == 1


def test_transport_raises_on_invalid_json() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text="not-json")

    transport = Transport(ClientConfig(), transport=httpx.MockTransport(handler))
    with pytest.raises(ApiResponseError):
        transport.post_form("/beforeauth/test", {"lang": "en"})


def test_transport_raises_on_http_errors() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, text="missing")

    transport = Transport(ClientConfig(), transport=httpx.MockTransport(handler))
    with pytest.raises(HTTPStatusError):
        transport.post_form("/beforeauth/test", {"lang": "en"})


def test_transport_raises_on_network_errors() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("boom")

    transport = Transport(ClientConfig(retries=0), transport=httpx.MockTransport(handler))
    with pytest.raises(NetworkError):
        transport.post_form("/beforeauth/test", {"lang": "en"})
