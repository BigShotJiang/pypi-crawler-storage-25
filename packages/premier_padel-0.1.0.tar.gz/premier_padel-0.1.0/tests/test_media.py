from __future__ import annotations

from .conftest import load_fixture


def test_media_resources(client_factory) -> None:
    routes = {
        "/beforeauth/getvideo": load_fixture("videos_page.json"),
        "/beforeauth/getvideopage": load_fixture("video_page.json"),
        "/beforeauth/getshortsreels": load_fixture("reels_page.json"),
    }
    client = client_factory(routes)

    videos = client.media.videos()
    page = client.media.video_page(2026)
    reels = client.media.reels(7495)

    assert videos[0].id == 119994
    assert page.sections[0].videos[0].slug == "entrance-sanchez-and-ustero-2"
    assert reels[0].id == 7495
