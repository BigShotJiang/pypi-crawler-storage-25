from __future__ import annotations

import os

import pytest

from premier_padel import Gender, PremierPadelClient

pytestmark = pytest.mark.skipif(
    os.environ.get("PREMIER_PADEL_LIVE_TESTS") != "1",
    reason="Live Premier Padel smoke tests are disabled.",
)


def test_live_smoke_rankings_and_tournaments() -> None:
    with PremierPadelClient() as client:
        players = client.players.list(Gender.MALE)
        tournaments = client.tournaments.list("March", 2026)

    assert len(players.items) > 0
    assert len(tournaments) > 0
