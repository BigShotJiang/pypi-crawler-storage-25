from __future__ import annotations

from .conftest import load_fixture


def test_news_resources(client_factory) -> None:
    routes = {
        "/beforeauth/getnewsletter": load_fixture("news_list.json"),
        "/beforeauth/getnewsdetails": load_fixture("news_detail.json"),
    }
    client = client_factory(routes)

    articles = client.news.list()
    article = client.news.get("riyadh-rematches-set-the-stage-for-gijon-premier-padel-p2-finals")

    assert articles[0].slug == "riyadh-rematches-set-the-stage-for-gijon-premier-padel-p2-finals"
    assert article.summary.id == 293
    assert article.related_article is not None
