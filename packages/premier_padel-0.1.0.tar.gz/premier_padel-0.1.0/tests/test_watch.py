from __future__ import annotations

from .conftest import load_fixture


def test_watch_resources(client_factory) -> None:
    routes = {
        "/beforeauth/getwheretowatch": load_fixture("watch_broadcasters.json"),
        "/beforeauth/getwheretowatchinfo": load_fixture("watch_info.json"),
        "/beforeauth/gettournamentsdropdown": load_fixture("watch_tournaments.json"),
    }
    client = client_factory(routes)

    broadcasters = client.watch.broadcasters()
    info = client.watch.info()
    tournaments = client.watch.tournaments()

    assert broadcasters[0].country_name == "Afghanistan"
    assert broadcasters[0].broadcasters[0].id == 17
    assert info[0].title.startswith("Worldwide")
    assert tournaments[0].full_name == "All"
