# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2026-03-10

### Added

- Initial public release of the sync Premier Padel Python SDK.
- Typed models and resource services for players, tournaments, matches, watch, media, and news.
- Defensive transport layer with custom exceptions and pagination helpers.
- Test suite, contributor documentation, CI workflow, and release workflows.
