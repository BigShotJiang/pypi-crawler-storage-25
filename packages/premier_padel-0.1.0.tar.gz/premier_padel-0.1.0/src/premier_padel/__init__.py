"""Premier Padel public sports-data SDK."""

from ._version import __version__
from .client import PremierPadelClient
from .enums import BracketDrawType, Gender, NewsSort, RankingScope, ResultsDrawType
from .exceptions import (
    ApiResponseError,
    HTTPStatusError,
    NetworkError,
    NotFoundError,
    PremierPadelError,
    RateLimitError,
    TimeoutError,
    ValidationError,
)
from .pagination import Page

__all__ = [
    "__version__",
    "ApiResponseError",
    "BracketDrawType",
    "Gender",
    "HTTPStatusError",
    "NetworkError",
    "NewsSort",
    "NotFoundError",
    "Page",
    "PremierPadelClient",
    "PremierPadelError",
    "RankingScope",
    "RateLimitError",
    "ResultsDrawType",
    "TimeoutError",
    "ValidationError",
]
