"""Tournament models."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime

from ..enums import BracketDrawType, ResultsDrawType
from .common import Competitor
from .matches import MatchCard


@dataclass(frozen=True)
class Tournament:
    """A tournament listing entry."""

    id: int
    slug: str
    event_code: str | None
    name: str | None
    full_name: str | None
    city: str | None
    country: str | None
    country_code: str | None
    gender: str | None
    currency: str | None
    prize_money: str | None
    tournament_type: str | None
    display_date: str | None
    entry_list_opens: datetime | None
    entry_list_closes: datetime | None
    start_date: date | None
    end_date: date | None
    deadline_for_registration: str | None
    qualification_date: str | None
    main_draw_date: str | None
    image_url: str | None
    club: str | None
    ticket_url: str | None
    where_to_watch_url: str | None
    deadline_for_registration_url: str | None
    external_url: str | None
    watch_now_url: str | None
    status: str | None
    tournaments_type: str | None
    year: int | None
    is_registration_open: bool | None
    is_live: bool | None
    is_show_order_of_play: bool | None
    is_show_draw_dates: bool | None
    is_live_match: bool | None
    is_all_match_completed: bool | None
    is_result_available: bool | None
    is_draw_available: bool | None
    created_at: datetime | None
    updated_at: datetime | None


@dataclass(frozen=True)
class TournamentDate:
    """A result-date option for a tournament."""

    tournament_id: int
    date: date
    display_date: str


@dataclass(frozen=True)
class TournamentEntry:
    """A doubles pair entry in a tournament entry list."""

    id: int
    tournament_id: int
    draw_type: str
    player: Competitor
    partner: Competitor | None
    player_points: int | None
    partner_points: int | None
    total_points: int | None
    rank: int | None
    created_at: datetime | None
    updated_at: datetime | None


@dataclass(frozen=True)
class TournamentEntrants:
    """Grouped entrant lists for a tournament."""

    men_main: tuple[TournamentEntry, ...] = field(default_factory=tuple)
    women_main: tuple[TournamentEntry, ...] = field(default_factory=tuple)
    men_qualifying: tuple[TournamentEntry, ...] = field(default_factory=tuple)
    women_qualifying: tuple[TournamentEntry, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class DrawRound:
    """A named round from a tournament bracket."""

    name: str


@dataclass(frozen=True)
class DrawContestant:
    """A draw contestant keyed by the API's contestant identifier."""

    id: str
    entry_status: str | None
    players: tuple[Competitor, ...]


@dataclass(frozen=True)
class DrawSide:
    """One side of a bracket match."""

    contestant_id: str | None
    is_winner: bool | None
    scores: tuple[str, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class DrawMatch:
    """A single match inside a tournament bracket."""

    round_index: int
    order: int
    sides: tuple[DrawSide, ...]


@dataclass(frozen=True)
class TournamentDraw:
    """A normalized bracket draw."""

    slug: str
    draw_type: BracketDrawType
    rounds: tuple[DrawRound, ...]
    contestants: dict[str, DrawContestant]
    matches: tuple[DrawMatch, ...]


@dataclass(frozen=True)
class TournamentResults:
    """Normalized tournament results grouped by section."""

    tournament_id: int
    date: date
    draw_type: ResultsDrawType
    main_draw: tuple[MatchCard, ...] = field(default_factory=tuple)
    qualify_draw: tuple[MatchCard, ...] = field(default_factory=tuple)
    live: tuple[MatchCard, ...] = field(default_factory=tuple)
    upcoming: tuple[MatchCard, ...] = field(default_factory=tuple)
