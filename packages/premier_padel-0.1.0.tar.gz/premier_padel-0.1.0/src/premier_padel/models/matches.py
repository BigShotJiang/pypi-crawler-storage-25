"""Match models."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import date, datetime

from .common import Competitor, Statistic


@dataclass(frozen=True)
class MatchScore:
    """A match score line with up to five sets plus tie-break metadata."""

    sets: tuple[int | None, ...]
    tiebreaks: tuple[int | None, ...]
    current_points: str | None


@dataclass(frozen=True)
class MatchTeam:
    """One side of a match card or match detail."""

    player: Competitor
    partner: Competitor | None
    score: MatchScore


@dataclass(frozen=True)
class MatchCard:
    """A match summary as shown in live, upcoming, and results endpoints."""

    id: int
    tournament_id: int | None
    tournament_name: str | None
    court_name: str | None
    scheduled_on: date | None
    start_time: str | None
    day: int | None
    match_code: str | None
    draw_type: str | None
    round_code: str | None
    round_name: str | None
    winner_id: str | None
    status: str | None
    server: int | None
    header: str | None
    to_be_finished: str | None
    is_bye: bool | None
    live_match_url: str | None
    match_centre_powered_by_image_url: str | None
    created_at: datetime | None
    updated_at: datetime | None
    team_1: MatchTeam
    team_2: MatchTeam


@dataclass(frozen=True)
class MatchStats:
    """Grouped statistics from the match detail endpoint."""

    title: str | None
    service: tuple[Statistic, ...] = field(default_factory=tuple)
    return_stats: tuple[Statistic, ...] = field(default_factory=tuple)
    total_points: tuple[Statistic, ...] = field(default_factory=tuple)
    extra_sections: Mapping[str, tuple[Statistic, ...]] = field(default_factory=dict)


@dataclass(frozen=True)
class MatchDetail:
    """Full match-centre payload for a match."""

    match: MatchCard
    stats: MatchStats | None


@dataclass(frozen=True)
class LiveMatchDetail(MatchCard):
    """Typed live scoreboard snapshot.

    The live-detail endpoint currently exposes the same normalized match fields
    as the live match list, but it remains a dedicated model because it comes
    from a separate endpoint and may gain live-only fields later.
    """

    @classmethod
    def from_match_card(cls, match: MatchCard) -> LiveMatchDetail:
        """Build a live-detail model from a normalized match snapshot."""

        return cls(
            id=match.id,
            tournament_id=match.tournament_id,
            tournament_name=match.tournament_name,
            court_name=match.court_name,
            scheduled_on=match.scheduled_on,
            start_time=match.start_time,
            day=match.day,
            match_code=match.match_code,
            draw_type=match.draw_type,
            round_code=match.round_code,
            round_name=match.round_name,
            winner_id=match.winner_id,
            status=match.status,
            server=match.server,
            header=match.header,
            to_be_finished=match.to_be_finished,
            is_bye=match.is_bye,
            live_match_url=match.live_match_url,
            match_centre_powered_by_image_url=match.match_centre_powered_by_image_url,
            created_at=match.created_at,
            updated_at=match.updated_at,
            team_1=match.team_1,
            team_2=match.team_2,
        )
