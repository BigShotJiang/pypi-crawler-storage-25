"""Player models."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime

from ..enums import Gender, RankingScope
from .media import ShortReel


@dataclass(frozen=True)
class PlayerSummary:
    """A lightweight player record from rankings and search endpoints."""

    id: int
    slug: str
    first_name: str
    last_name: str
    full_name: str
    image_url: str | None
    thumbnail_url: str | None
    country_flag_url: str | None
    status: str | None
    gender: Gender | None
    scope: RankingScope | None
    created_at: datetime | None
    updated_at: datetime | None


@dataclass(frozen=True)
class PlayerTournamentResult:
    """A tournament result entry embedded inside a player detail payload."""

    id: int
    player_id: int
    key_name: str | None
    name: str | None
    category_name: str | None
    category_id: str | None
    tournament_type: str | None
    played_on: date | None
    round_name: str | None
    points: int | None
    created_at: datetime | None
    updated_at: datetime | None


@dataclass(frozen=True)
class PlayerDetail:
    """A full player profile returned by the player detail endpoint."""

    id: int
    slug: str
    first_name: str
    last_name: str
    full_name: str
    nickname: str | None
    image_url: str | None
    thumbnail_url: str | None
    sponsor_image_url: str | None
    gender: Gender | None
    player_code: str | None
    country_code: str | None
    country_code_iso2: str | None
    country_flag_url: str | None
    ranking: int | None
    points: int | None
    quote: str | None
    bio: str | None
    birth_date: date | None
    height: str | None
    play_hand: str | None
    facebook_url: str | None
    instagram_url: str | None
    youtube_url: str | None
    twitter_url: str | None
    partner_player_id: int | None
    partner_player_code: str | None
    partner_player_name: str | None
    partner_player_image_url: str | None
    partner_player_thumbnail_url: str | None
    is_favourite: bool | None
    status: str | None
    created_at: datetime | None
    updated_at: datetime | None
    tournaments: tuple[PlayerTournamentResult, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class PlayerMoment(ShortReel):
    """A short-form video attached to a player profile."""
