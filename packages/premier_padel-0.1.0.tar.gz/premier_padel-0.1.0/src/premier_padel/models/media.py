"""Media models."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime


@dataclass(frozen=True)
class Video:
    """A generic video item returned by the videos feed."""

    id: int
    title: str
    published_on: date | None
    video_url: str | None
    image_url: str | None
    duration: str | None
    tournament_name: str | None
    round_name: str | None
    slug: str | None
    status: str | None
    created_at: datetime | None
    updated_at: datetime | None


@dataclass(frozen=True)
class ShortReel:
    """A short-form reel returned by the reels and player moments endpoints."""

    id: int
    title: str
    api_video_id: int | None
    published_on: date | None
    season_year: str | None
    video_url: str | None
    image_url: str | None
    duration: str | None
    scenes: str | None
    media_type: str | None
    is_top_10_moments: bool | None
    tournament_id: int | None
    tournament_name: str | None
    round_name: str | None
    rating: int | None
    views: int | None
    slug: str | None
    match_name: str | None
    is_featured: bool | None
    status: str | None
    created_at: datetime | None
    updated_at: datetime | None
    share_url: str | None
    likes_count: int | None
    comments_count: int | None
    share_count: int | None
    is_user_like: bool | None
    tags: tuple[str, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class VideoPageMeta:
    """Metadata attached to the video landing page."""

    title: str | None
    meta_title: str | None
    meta_tag: str | None
    meta_description: str | None
    slug: str | None


@dataclass(frozen=True)
class VideoPageHero:
    """Hero media section on the video landing page."""

    media_type: str | None
    title: str | None
    subtitle: str | None
    video_url: str | None
    mobile_video_url: str | None
    image_url: str | None
    mobile_image_url: str | None


@dataclass(frozen=True)
class VideoPageSection:
    """A content section on the video landing page."""

    id: int | None
    title: str | None
    section_type: str | None
    display_order: int | None
    videos: tuple[Video, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class VideoPage:
    """The top-level payload returned by the video landing page endpoint."""

    meta: VideoPageMeta
    hero: VideoPageHero
    sections: tuple[VideoPageSection, ...] = field(default_factory=tuple)
