"""Common model primitives shared across resource domains."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Competitor:
    """A player or team member shown in match, draw, and entrant payloads."""

    name: str
    image_url: str | None = None
    country_flag_url: str | None = None
    id: int | None = None
    external_id: str | None = None


@dataclass(frozen=True)
class StatisticValue:
    """A single side's value inside a match statistic row."""

    title: str | None
    won: int | None
    played: int | None
    percentage: int | None
    is_winner: bool | None


@dataclass(frozen=True)
class Statistic:
    """A single match-statistics row comparing both teams."""

    title: str
    team_1: StatisticValue
    team_2: StatisticValue
