"""Where-to-watch models."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass(frozen=True)
class Broadcaster:
    """A broadcaster entry for a specific tournament and country."""

    id: int
    tournament_id: int | None
    broadcaster_type: str | None
    image_url: str | None
    broadcast_url: str | None
    status: str | None
    created_at: datetime | None
    updated_at: datetime | None


@dataclass(frozen=True)
class CountryBroadcasters:
    """A country grouped with its available broadcaster entries."""

    country_id: int
    country_name: str
    country_flag_url: str | None
    created_at: datetime | None
    broadcasters: tuple[Broadcaster, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class WatchInfo:
    """Informational block returned by the where-to-watch info endpoint."""

    id: int
    title: str
    image_url: str | None
    description: str | None
    broadcast_url: str | None
    display_order: int | None
    status: str | None
    created_at: datetime | None
    updated_at: datetime | None


@dataclass(frozen=True)
class WatchTournamentOption:
    """A tournament selector option used by the where-to-watch area."""

    id: int
    full_name: str
    accommodation_start_date: str | None
    accommodation_end_date: str | None
    is_live: bool | None
    is_recent_tournament: bool | None
