"""News models."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime


@dataclass(frozen=True)
class NewsArticleSummary:
    """A lightweight news record from the news list endpoint."""

    id: int
    title: str
    subtitle: str | None
    image_url: str | None
    image_height: int | None
    image_width: int | None
    thumbnail_url: str | None
    thumbnail_height: int | None
    thumbnail_width: int | None
    published_on: date | None
    is_featured: bool | None
    slug: str
    status: str | None
    created_at: datetime | None


@dataclass(frozen=True)
class NewsArticle:
    """A full news article plus one related article when present."""

    summary: NewsArticleSummary
    description_html: str | None
    meta_title: str | None
    meta_tag: str | None
    meta_description: str | None
    share_url: str | None
    related_article: NewsArticleSummary | None
