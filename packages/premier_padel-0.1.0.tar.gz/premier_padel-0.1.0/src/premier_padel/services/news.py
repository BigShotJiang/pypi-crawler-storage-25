"""News service."""

from __future__ import annotations

from ..enums import NewsSort
from ..models.news import NewsArticle, NewsArticleSummary
from ..parsers.common import as_list, as_mapping
from ..parsers.news import parse_news_article, parse_news_summary
from .base import BaseService


class NewsService(BaseService):
    """Access news listing and article detail endpoints."""

    def list(
        self,
        sort: NewsSort = NewsSort.NEWEST,
        page_size: int | None = None,
        *,
        lang: str | None = None,
    ) -> tuple[NewsArticleSummary, ...]:
        """List news items ordered by the requested sort."""

        envelope = self._client._transport.post_form(
            "/beforeauth/getnewsletter",
            {
                "pagesize": -1 if page_size is None else page_size,
                "sort_by": sort.value,
                "lang": self._lang(lang),
            },
        )
        payload = self._unwrap(envelope)
        return tuple(
            parse_news_summary(as_mapping(item, "news summary"))
            for item in as_list(payload, "data")
        )

    def get(self, slug: str, *, lang: str | None = None) -> NewsArticle:
        """Fetch a news article by slug."""

        envelope = self._client._transport.post_form(
            "/beforeauth/getnewsdetails",
            {"slug": slug, "lang": self._lang(lang)},
        )
        payload = self._unwrap(envelope, not_found=True)
        return parse_news_article(as_mapping(payload, "data"))
