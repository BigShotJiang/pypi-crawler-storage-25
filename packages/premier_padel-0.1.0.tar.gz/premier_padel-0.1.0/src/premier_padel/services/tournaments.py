"""Tournaments service."""

from __future__ import annotations

from collections.abc import Iterator
from datetime import date

from ..enums import BracketDrawType, ResultsDrawType
from ..models.tournaments import (
    Tournament,
    TournamentDate,
    TournamentDraw,
    TournamentEntrants,
    TournamentResults,
)
from ..pagination import Page
from ..parsers.common import as_list, as_mapping
from ..parsers.tournaments import (
    parse_draw,
    parse_tournament,
    parse_tournament_date,
    parse_tournament_entrants,
    parse_tournament_results,
)
from .base import BaseService, TournamentArg


class TournamentService(BaseService):
    """Access tournament calendars, draws, entrants, and results."""

    def list(
        self,
        month: str,
        year: int,
        page: int | None = None,
        page_size: int = -1,
        *,
        lang: str | None = None,
    ) -> list[Tournament] | Page[Tournament]:
        """List tournaments for a month, optionally as a paginated response."""

        envelope = self._client._transport.post_form(
            "/beforeauth/getfanapptournaments",
            {
                "page": "" if page is None else page,
                "pagesize": page_size,
                "month_name": month,
                "year": year,
                "lang": self._lang(lang),
            },
        )
        payload = self._unwrap(envelope)
        tournaments = [
            parse_tournament(as_mapping(item, "tournament")) for item in as_list(payload, "data")
        ]
        for tournament in tournaments:
            self._client._remember_tournament(tournament)
        if page is None:
            return tournaments
        return Page(
            items=tournaments,
            current_page=envelope.current_page or page,
            total_pages=envelope.total_page,
            has_next_page=bool(envelope.is_next_page),
            _fetch_page=lambda next_page: self._list_page(
                month,
                year,
                page=next_page,
                page_size=page_size,
                lang=lang,
            ),
        )

    def iter_all(
        self, month: str, year: int, *, page_size: int = 50, lang: str | None = None
    ) -> Iterator[Tournament]:
        """Iterate through paginated tournament pages lazily."""

        page = self.list(month, year, page=1, page_size=page_size, lang=lang)
        if not isinstance(page, Page):
            raise TypeError("Expected a paginated tournament page.")
        return page.iter_all()

    def _list_page(
        self,
        month: str,
        year: int,
        *,
        page: int,
        page_size: int,
        lang: str | None = None,
    ) -> Page[Tournament]:
        result = self.list(month, year, page=page, page_size=page_size, lang=lang)
        if not isinstance(result, Page):
            raise TypeError("Expected a paginated tournament page.")
        return result

    def players(
        self,
        tournament: TournamentArg,
        *,
        lang: str | None = None,
    ) -> TournamentEntrants:
        """Fetch grouped tournament entrants."""

        slug = self._resolve_tournament_slug(tournament, lang=lang)
        envelope = self._client._transport.post_form(
            "/beforeauth/gettournamentsplayer",
            {"slug": slug, "lang": self._lang(lang)},
        )
        payload = self._unwrap(envelope)
        return parse_tournament_entrants(as_mapping(payload, "data"))

    def draw(
        self,
        tournament: TournamentArg,
        draw_type: BracketDrawType,
        *,
        lang: str | None = None,
    ) -> TournamentDraw:
        """Fetch a tournament bracket draw."""

        slug = self._resolve_tournament_slug(tournament, lang=lang)
        envelope = self._client._transport.post_form(
            "/beforeauth/gettournamentsmatchdraw",
            {"slug": slug, "draw_type": draw_type.value},
        )
        payload = self._unwrap(envelope)
        return parse_draw(as_mapping(payload, "data"), slug=slug, draw_type=draw_type)

    def result_dates(
        self,
        tournament: TournamentArg,
        *,
        lang: str | None = None,
    ) -> tuple[TournamentDate, ...]:
        """Fetch available result dates for a tournament."""

        slug = self._resolve_tournament_slug(tournament, lang=lang)
        envelope = self._client._transport.post_form(
            "/beforeauth/gettournamentsdate",
            {"slug": slug, "lang": self._lang(lang)},
        )
        payload = self._unwrap(envelope)
        return tuple(
            parse_tournament_date(as_mapping(item, "result date"))
            for item in as_list(payload, "data")
        )

    def results(
        self,
        tournament: TournamentArg,
        date: date | str,
        draw: ResultsDrawType,
        *,
        lang: str | None = None,
    ) -> TournamentResults:
        """Fetch grouped tournament results for one date and draw."""

        tournament_id = self._resolve_tournament_id(tournament, lang=lang)
        scheduled_on = self._coerce_date(date)
        envelope = self._client._transport.post_form(
            "/beforeauth/gettournamentsmatchlistnew",
            {
                "date": scheduled_on.isoformat(),
                "tournaments_id": tournament_id,
                "draw_type": draw.value,
                "lang": self._lang(lang),
            },
        )
        payload = self._unwrap(envelope)
        return parse_tournament_results(
            as_mapping(payload, "data"),
            tournament_id=tournament_id,
            scheduled_on=scheduled_on,
            draw_type=draw,
        )
