"""Where-to-watch service."""

from __future__ import annotations

from ..models.watch import CountryBroadcasters, WatchInfo, WatchTournamentOption
from ..parsers.common import as_list, as_mapping
from ..parsers.watch import (
    parse_country_broadcasters,
    parse_watch_info,
    parse_watch_tournament_option,
)
from .base import BaseService, TournamentArg


class WatchService(BaseService):
    """Access broadcaster and watch-info endpoints."""

    def broadcasters(
        self,
        tournament: TournamentArg | None = None,
        *,
        lang: str | None = None,
    ) -> tuple[CountryBroadcasters, ...]:
        """List broadcasters, globally or for one tournament."""

        tournament_id = (
            "" if tournament is None else self._resolve_tournament_id(tournament, lang=lang)
        )
        envelope = self._client._transport.post_form(
            "/beforeauth/getwheretowatch",
            {"tournaments_id": tournament_id, "lang": self._lang(lang)},
        )
        payload = self._unwrap(envelope)
        return tuple(
            parse_country_broadcasters(as_mapping(item, "country broadcasters"))
            for item in as_list(payload, "data")
        )

    def tournaments(self, *, lang: str | None = None) -> tuple[WatchTournamentOption, ...]:
        """List tournament selector options used by the watch area."""

        envelope = self._client._transport.post_form(
            "/beforeauth/gettournamentsdropdown",
            {"lang": self._lang(lang)},
        )
        payload = self._unwrap(envelope)
        return tuple(
            parse_watch_tournament_option(as_mapping(item, "watch tournament option"))
            for item in as_list(payload, "data")
        )

    def info(self, *, lang: str | None = None) -> tuple[WatchInfo, ...]:
        """List where-to-watch informational blocks."""

        envelope = self._client._transport.post_form(
            "/beforeauth/getwheretowatchinfo",
            {"lang": self._lang(lang)},
        )
        payload = self._unwrap(envelope)
        return tuple(
            parse_watch_info(as_mapping(item, "watch info")) for item in as_list(payload, "data")
        )
