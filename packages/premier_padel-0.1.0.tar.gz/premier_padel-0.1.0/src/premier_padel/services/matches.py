"""Matches service."""

from __future__ import annotations

from ..models.matches import LiveMatchDetail, MatchCard, MatchDetail
from ..parsers.common import as_mapping
from ..parsers.matches import (
    parse_live_match_cards,
    parse_live_match_detail,
    parse_match_detail,
    parse_upcoming_matches,
)
from .base import BaseService, MatchArg, TournamentArg


class MatchService(BaseService):
    """Access live, upcoming, and detailed match data."""

    def live(
        self,
        tournament: TournamentArg,
        *,
        lang: str | None = None,
    ) -> tuple[MatchCard, ...]:
        """List current live matches for a tournament."""

        slug = self._resolve_tournament_slug(tournament, lang=lang)
        envelope = self._client._transport.post_form(
            "/beforeauth/gettournamentslivematch",
            {"slug": slug},
        )
        payload = self._unwrap(envelope)
        return parse_live_match_cards(payload)

    def upcoming(
        self,
        tournament: TournamentArg,
        *,
        lang: str | None = None,
    ) -> tuple[MatchCard, ...]:
        """List upcoming matches for a tournament."""

        tournament_id = self._resolve_tournament_id(tournament, lang=lang)
        envelope = self._client._transport.post_form(
            "/beforeauth/gettournamnetupcomingmatches",
            {"tournaments_id": tournament_id},
        )
        payload = self._unwrap(envelope)
        return parse_upcoming_matches(payload)

    def detail(self, match: MatchArg, *, lang: str | None = None) -> MatchDetail:
        """Fetch match-centre detail for a match."""

        match_id = self._resolve_match_id(match)
        envelope = self._client._transport.post_form(
            "/beforeauth/gettournamentsmatchdetail",
            {"tournaments_match_id": match_id, "lang": self._lang(lang)},
        )
        payload = self._unwrap(envelope)
        return parse_match_detail(as_mapping(payload, "data"))

    def live_detail(
        self,
        match: MatchArg,
        *,
        lang: str | None = None,
    ) -> LiveMatchDetail | None:
        """Fetch live scoreboard detail for a match, if available."""

        match_id = self._resolve_match_id(match)
        envelope = self._client._transport.post_form(
            "/beforeauth/getlivematchdetail",
            {"tournaments_match_id": match_id, "lang": self._lang(lang)},
        )
        payload = self._unwrap(envelope)
        return parse_live_match_detail(payload)
