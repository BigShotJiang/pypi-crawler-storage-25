"""Media service."""

from __future__ import annotations

from ..models.media import ShortReel, Video, VideoPage
from ..pagination import Page
from ..parsers.common import as_list, as_mapping
from ..parsers.media import parse_short_reel, parse_video, parse_video_page
from .base import BaseService, TournamentArg


class MediaService(BaseService):
    """Access generic videos, reels, and video landing-page payloads."""

    def videos(self, page: int = 1, *, lang: str | None = None) -> Page[Video]:
        """Fetch one page from the generic videos feed."""

        envelope = self._client._transport.post_form(
            "/beforeauth/getvideo",
            {"page": page, "lang": self._lang(lang)},
        )
        payload = self._unwrap(envelope)
        items = [parse_video(as_mapping(item, "video")) for item in as_list(payload, "data")]
        return Page(
            items=items,
            current_page=envelope.current_page or page,
            total_pages=envelope.total_page,
            has_next_page=bool(envelope.is_next_page),
            _fetch_page=lambda next_page: self.videos(page=next_page, lang=lang),
        )

    def reels(
        self,
        short_id: int | str,
        page: int = 1,
        page_size: int = 20,
        *,
        lang: str | None = None,
    ) -> Page[ShortReel]:
        """Fetch a paginated reels feed anchored on a short id."""

        envelope = self._client._transport.post_form(
            "/beforeauth/getshortsreels",
            {
                "short_id": short_id,
                "lang": self._lang(lang),
                "page": page,
                "pagesize": page_size,
            },
        )
        payload = self._unwrap(envelope)
        items = [parse_short_reel(as_mapping(item, "reel")) for item in as_list(payload, "data")]
        return Page(
            items=items,
            current_page=envelope.current_page or page,
            total_pages=envelope.total_page,
            has_next_page=bool(envelope.is_next_page),
            _fetch_page=lambda next_page: self.reels(
                short_id, page=next_page, page_size=page_size, lang=lang
            ),
        )

    def video_page(
        self,
        year: int,
        tournament: TournamentArg | None = None,
        search: str | None = None,
        *,
        lang: str | None = None,
    ) -> VideoPage:
        """Fetch the videos landing-page payload."""

        tournament_id = (
            "" if tournament is None else self._resolve_tournament_id(tournament, lang=lang)
        )
        envelope = self._client._transport.post_form(
            "/beforeauth/getvideopage",
            {
                "lang": self._lang(lang),
                "year": year,
                "tournaments_id": tournament_id,
                "search": search or "",
            },
        )
        payload = self._unwrap(envelope)
        return parse_video_page(as_mapping(payload, "data"))
