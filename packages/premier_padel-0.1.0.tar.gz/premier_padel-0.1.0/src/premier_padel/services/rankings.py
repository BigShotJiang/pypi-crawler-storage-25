"""Rankings service."""

from __future__ import annotations

from collections.abc import Iterator

from ..enums import Gender, RankingScope
from ..models.players import PlayerSummary
from ..pagination import Page
from .base import BaseService


class RankingService(BaseService):
    """Internal ranking-focused alias over player ranking endpoints."""

    def list(
        self, gender: Gender, page: int = 1, scope: RankingScope = RankingScope.OVERALL
    ) -> Page[PlayerSummary]:
        """Return a page of ranking entries."""

        return self._client.players.list(gender=gender, page=page, scope=scope)

    def iter_all(
        self,
        gender: Gender,
        *,
        scope: RankingScope = RankingScope.OVERALL,
    ) -> Iterator[PlayerSummary]:
        """Iterate through all ranking pages lazily."""

        return self._client.players.iter_all(gender=gender, scope=scope)
