"""Player and rankings services."""

from __future__ import annotations

from collections.abc import Iterator

from ..enums import Gender, RankingScope
from ..models.players import PlayerDetail, PlayerMoment, PlayerSummary
from ..pagination import Page
from ..parsers.common import as_list, as_mapping
from ..parsers.players import parse_player_detail, parse_player_moment, parse_player_summary
from ..services.base import BaseService, PlayerArg


class PlayerService(BaseService):
    """Access player discovery, detail, and player moments."""

    def list(
        self, gender: Gender, page: int = 1, scope: RankingScope = RankingScope.OVERALL
    ) -> Page[PlayerSummary]:
        """Return a page of ranked players for a gender."""

        return self._ranking_page(gender=gender, page=page, scope=scope, search="")

    def search(
        self,
        query: str,
        gender: Gender | None = None,
        page: int = 1,
        scope: RankingScope = RankingScope.OVERALL,
    ) -> Page[PlayerSummary]:
        """Search players by name across one or both ranking lists."""

        if gender is not None:
            return self._ranking_page(gender=gender, page=page, scope=scope, search=query)

        male = self._ranking_page(gender=Gender.MALE, page=page, scope=scope, search=query)
        female = self._ranking_page(gender=Gender.FEMALE, page=page, scope=scope, search=query)
        combined_items = [*male.items, *female.items]
        for item in combined_items:
            self._client._remember_player(item)
        return Page(
            items=combined_items,
            current_page=page,
            total_pages=max(filter(None, [male.total_pages, female.total_pages]), default=None),
            has_next_page=male.has_next_page or female.has_next_page,
            _fetch_page=lambda next_page: self.search(
                query, gender=None, page=next_page, scope=scope
            ),
        )

    def iter_all(
        self,
        gender: Gender,
        *,
        scope: RankingScope = RankingScope.OVERALL,
        query: str = "",
    ) -> Iterator[PlayerSummary]:
        """Iterate through all ranking pages lazily."""

        page = self._ranking_page(gender=gender, page=1, scope=scope, search=query)
        return page.iter_all()

    def get(self, slug: str, *, lang: str | None = None) -> PlayerDetail:
        """Fetch a full player profile by slug."""

        envelope = self._client._transport.post_form(
            "/beforeauth/getplayerdetails",
            {"slug": slug, "lang": self._lang(lang)},
        )
        payload = self._unwrap(envelope, not_found=True)
        player = parse_player_detail(as_mapping(payload, "data"))
        self._client._remember_player(player)
        return player

    def moments(
        self,
        player: PlayerArg,
        page: int = 1,
        page_size: int = 8,
        *,
        lang: str | None = None,
    ) -> Page[PlayerMoment]:
        """Fetch paginated player moments for a player slug, id, or model."""

        player_id = self._resolve_player_id(player, lang=lang)
        envelope = self._client._transport.post_form(
            "/beforeauth/getplayervideos",
            {
                "player_id": player_id,
                "lang": self._lang(lang),
                "page": page,
                "pagesize": page_size,
            },
        )
        payload = self._unwrap(envelope)
        items = [
            parse_player_moment(as_mapping(item, "player moment"))
            for item in as_list(payload, "data")
        ]
        return Page(
            items=items,
            current_page=envelope.current_page or page,
            total_pages=envelope.total_page,
            has_next_page=bool(envelope.is_next_page),
            _fetch_page=lambda next_page: self.moments(
                player, page=next_page, page_size=page_size, lang=lang
            ),
        )

    def _ranking_page(
        self,
        *,
        gender: Gender,
        page: int,
        scope: RankingScope,
        search: str,
    ) -> Page[PlayerSummary]:
        envelope = self._client._transport.post_form(
            "/beforeauth/getplayerrankingv2",
            {
                "page": page,
                "gender": gender.value,
                "this_year_ranking": scope.value,
                "search": search,
            },
        )
        payload = self._unwrap(envelope)
        items = [
            parse_player_summary(as_mapping(item, "player summary"), gender=gender, scope=scope)
            for item in as_list(payload, "data")
        ]
        for item in items:
            self._client._remember_player(item)
        return Page(
            items=items,
            current_page=envelope.current_page or page,
            total_pages=envelope.total_page,
            has_next_page=bool(envelope.is_next_page),
            _fetch_page=lambda next_page: self._ranking_page(
                gender=gender,
                page=next_page,
                scope=scope,
                search=search,
            ),
        )
