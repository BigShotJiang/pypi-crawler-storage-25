"""Parsers for where-to-watch payloads."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..models.watch import Broadcaster, CountryBroadcasters, WatchInfo, WatchTournamentOption
from .common import (
    as_list,
    as_mapping,
    optional_bool,
    optional_datetime,
    optional_int,
    optional_str,
)


def parse_broadcaster(payload: Mapping[str, Any]) -> Broadcaster:
    """Parse a broadcaster entry."""

    return Broadcaster(
        id=optional_int(payload.get("where_to_watch_id")) or 0,
        tournament_id=optional_int(payload.get("tournaments_id")),
        broadcaster_type=optional_str(payload.get("type")),
        image_url=optional_str(payload.get("image")),
        broadcast_url=optional_str(payload.get("broadcast_url")),
        status=optional_str(payload.get("status")),
        created_at=optional_datetime(payload.get("created_at")),
        updated_at=optional_datetime(payload.get("updated_at")),
    )


def parse_country_broadcasters(payload: Mapping[str, Any]) -> CountryBroadcasters:
    """Parse a country plus its broadcasters."""

    return CountryBroadcasters(
        country_id=optional_int(payload.get("countries_id")) or 0,
        country_name=optional_str(payload.get("countries_name")) or "",
        country_flag_url=optional_str(payload.get("countries_image")),
        created_at=optional_datetime(payload.get("created_at")),
        broadcasters=tuple(
            parse_broadcaster(as_mapping(item, "where_to_watch item"))
            for item in as_list(payload.get("where_to_watch"), "where_to_watch")
        ),
    )


def parse_watch_info(payload: Mapping[str, Any]) -> WatchInfo:
    """Parse a watch-info block."""

    return WatchInfo(
        id=optional_int(payload.get("where_to_watch_info_id")) or 0,
        title=optional_str(payload.get("title")) or "",
        image_url=optional_str(payload.get("image")),
        description=optional_str(payload.get("description")),
        broadcast_url=optional_str(payload.get("broadcast_url")),
        display_order=optional_int(payload.get("display_order")),
        status=optional_str(payload.get("status")),
        created_at=optional_datetime(payload.get("created_at")),
        updated_at=optional_datetime(payload.get("updated_at")),
    )


def parse_watch_tournament_option(payload: Mapping[str, Any]) -> WatchTournamentOption:
    """Parse a where-to-watch tournament selector option."""

    return WatchTournamentOption(
        id=optional_int(payload.get("tournaments_id")) or 0,
        full_name=optional_str(payload.get("full_name")) or "",
        accommodation_start_date=optional_str(payload.get("accommodation_start_date")),
        accommodation_end_date=optional_str(payload.get("accommodation_end_date")),
        is_live=optional_bool(payload.get("is_live")),
        is_recent_tournament=optional_bool(payload.get("is_recent_tournament")),
    )
