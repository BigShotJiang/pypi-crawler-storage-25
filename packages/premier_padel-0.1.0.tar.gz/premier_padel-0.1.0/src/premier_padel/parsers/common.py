"""Shared parsing helpers."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import date, datetime
from enum import Enum
from typing import Any, TypeVar

from ..exceptions import ValidationError
from ..models.common import Competitor, Statistic, StatisticValue

EnumT = TypeVar("EnumT", bound=Enum)

DATETIME_FORMATS = ("%Y-%m-%d %H:%M:%S", "%m/%d/%Y %I:%M:%S %p")
DATE_FORMATS = ("%Y-%m-%d", "%d %B %Y")


def as_mapping(value: Any, field_name: str) -> Mapping[str, Any]:
    """Require a mapping payload."""

    if not isinstance(value, Mapping):
        raise ValidationError(f"Expected '{field_name}' to be an object.")
    return value


def as_list(value: Any, field_name: str) -> list[Any]:
    """Require a list payload, treating null and empty strings as empty lists."""

    if value in (None, ""):
        return []
    if not isinstance(value, list):
        raise ValidationError(f"Expected '{field_name}' to be a list.")
    return value


def optional_str(value: Any) -> str | None:
    """Return a normalized string or None."""

    if value in (None, ""):
        return None
    return str(value)


def optional_int(value: Any) -> int | None:
    """Return a normalized integer or None."""

    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def optional_bool(value: Any) -> bool | None:
    """Parse common yes/no style flags used by the API."""

    if value is None:
        return None
    text = str(value)
    mapping = {
        "Yes": True,
        "No": False,
        "Y": True,
        "N": False,
        "1": True,
        "0": False,
    }
    return mapping.get(text)


def optional_date(value: Any) -> date | None:
    """Parse known date representations used by the API."""

    text = optional_str(value)
    if text is None:
        return None
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    for fmt in DATETIME_FORMATS:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def optional_datetime(value: Any) -> datetime | None:
    """Parse known datetime representations used by the API."""

    text = optional_str(value)
    if text is None:
        return None
    for fmt in DATETIME_FORMATS:
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return None


def enum_or_none(enum_type: type[EnumT], value: Any) -> EnumT | None:
    """Map a string value to an enum member when possible."""

    text = optional_str(value)
    if text is None:
        return None
    try:
        return enum_type(text)
    except ValueError:
        return None


def parse_competitor(
    *,
    name: Any,
    image_url: Any = None,
    country_flag_url: Any = None,
    identifier: Any = None,
    external_id: Any = None,
) -> Competitor:
    """Build a shared competitor model."""

    return Competitor(
        name=optional_str(name) or "",
        image_url=optional_str(image_url),
        country_flag_url=optional_str(country_flag_url),
        id=optional_int(identifier),
        external_id=optional_str(external_id),
    )


def parse_statistic_value(payload: Mapping[str, Any]) -> StatisticValue:
    """Parse one side of a match-statistics row."""

    return StatisticValue(
        title=optional_str(payload.get("title")),
        won=optional_int(payload.get("won")),
        played=optional_int(payload.get("played")),
        percentage=optional_int(payload.get("percentage")),
        is_winner=optional_bool(payload.get("is_winner")),
    )


def parse_statistic(payload: Mapping[str, Any]) -> Statistic:
    """Parse a match-statistics row."""

    return Statistic(
        title=optional_str(payload.get("title")) or "",
        team_1=parse_statistic_value(as_mapping(payload.get("team_1"), "team_1")),
        team_2=parse_statistic_value(as_mapping(payload.get("team_2"), "team_2")),
    )
