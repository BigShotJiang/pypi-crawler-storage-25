"""Parsers for news payloads."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..models.news import NewsArticle, NewsArticleSummary
from .common import (
    as_mapping,
    optional_bool,
    optional_date,
    optional_datetime,
    optional_int,
    optional_str,
)


def parse_news_summary(payload: Mapping[str, Any]) -> NewsArticleSummary:
    """Parse a lightweight news article record."""

    return NewsArticleSummary(
        id=optional_int(payload.get("newsletter_id")) or 0,
        title=optional_str(payload.get("title")) or "",
        subtitle=optional_str(payload.get("sub_title")),
        image_url=optional_str(payload.get("image")),
        image_height=optional_int(payload.get("image_height")),
        image_width=optional_int(payload.get("image_width")),
        thumbnail_url=optional_str(payload.get("thumbnail_image")),
        thumbnail_height=optional_int(payload.get("thumbnail_height")),
        thumbnail_width=optional_int(payload.get("thumbnail_width")),
        published_on=optional_date(payload.get("date")),
        is_featured=optional_bool(payload.get("is_features")),
        slug=optional_str(payload.get("slug")) or "",
        status=optional_str(payload.get("status")),
        created_at=optional_datetime(payload.get("created_at")),
    )


def parse_news_article(payload: Mapping[str, Any]) -> NewsArticle:
    """Parse a full news article payload."""

    related_raw = payload.get("news")
    related = (
        parse_news_summary(as_mapping(related_raw, "news"))
        if isinstance(related_raw, Mapping)
        else None
    )
    summary = parse_news_summary(payload)
    return NewsArticle(
        summary=summary,
        description_html=optional_str(payload.get("description")),
        meta_title=optional_str(payload.get("meta_title")),
        meta_tag=optional_str(payload.get("meta_tag")),
        meta_description=optional_str(payload.get("meta_description")),
        share_url=optional_str(payload.get("share_url")),
        related_article=related,
    )
