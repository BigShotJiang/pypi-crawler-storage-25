"""Parsers for match payloads."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..exceptions import ValidationError
from ..models.common import Statistic
from ..models.matches import (
    LiveMatchDetail,
    MatchCard,
    MatchDetail,
    MatchScore,
    MatchStats,
    MatchTeam,
)
from .common import (
    as_list,
    as_mapping,
    optional_bool,
    optional_date,
    optional_datetime,
    optional_int,
    optional_str,
    parse_competitor,
    parse_statistic,
)


def parse_match_score(payload: Mapping[str, Any]) -> MatchScore:
    """Parse a match score object."""

    return MatchScore(
        sets=tuple(optional_int(payload.get(f"set{index}")) for index in range(1, 6)),
        tiebreaks=tuple(optional_int(payload.get(f"tie{index}")) for index in range(1, 6)),
        current_points=optional_str(payload.get("points")),
    )


def parse_match_card(payload: Mapping[str, Any]) -> MatchCard:
    """Parse a match summary card used across multiple endpoints."""

    team_1 = MatchTeam(
        player=parse_competitor(
            name=payload.get("team1_player_name"),
            image_url=payload.get("team1_player_image"),
            country_flag_url=payload.get("team1_player_countries_image"),
        ),
        partner=parse_competitor(
            name=payload.get("team1_partner_name"),
            image_url=payload.get("team1_partner_image"),
            country_flag_url=payload.get("team1_partner_countries_image"),
        )
        if optional_str(payload.get("team1_partner_name")) is not None
        else None,
        score=parse_match_score(as_mapping(payload.get("team1_score"), "team1_score")),
    )
    team_2 = MatchTeam(
        player=parse_competitor(
            name=payload.get("team2_player_name"),
            image_url=payload.get("team2_player_image"),
            country_flag_url=payload.get("team2_player_countries_image"),
        ),
        partner=parse_competitor(
            name=payload.get("team2_partner_player_name"),
            image_url=payload.get("team2_partner_player_image"),
            country_flag_url=payload.get("team2_partner_player_countries_image"),
        )
        if optional_str(payload.get("team2_partner_player_name")) is not None
        else None,
        score=parse_match_score(as_mapping(payload.get("team2_score"), "team2_score")),
    )
    return MatchCard(
        id=optional_int(payload.get("tournaments_match_id")) or 0,
        tournament_id=optional_int(payload.get("tournaments_id")),
        tournament_name=optional_str(payload.get("tournament_name")),
        court_name=optional_str(payload.get("court_name")),
        scheduled_on=optional_date(payload.get("date")),
        start_time=optional_str(payload.get("start_time")),
        day=optional_int(payload.get("day")),
        match_code=optional_str(payload.get("matchId")),
        draw_type=optional_str(payload.get("draw_type")),
        round_code=optional_str(payload.get("round")),
        round_name=optional_str(payload.get("round_name")),
        winner_id=optional_str(payload.get("winner_id")),
        status=optional_str(payload.get("status")),
        server=optional_int(payload.get("server")),
        header=optional_str(payload.get("header")),
        to_be_finished=optional_str(payload.get("to_be_finished")),
        is_bye=optional_bool(payload.get("is_bye")),
        live_match_url=optional_str(payload.get("live_match_url")),
        match_centre_powered_by_image_url=optional_str(
            payload.get("match_centre_powered_by_image")
        ),
        created_at=optional_datetime(payload.get("created_at")),
        updated_at=optional_datetime(payload.get("updated_at")),
        team_1=team_1,
        team_2=team_2,
    )


def parse_match_stats(payload: Mapping[str, Any]) -> MatchStats:
    """Parse grouped match statistics."""

    service = tuple(
        parse_statistic(as_mapping(item, "service item"))
        for item in as_list(payload.get("service"), "service")
    )
    return_stats = tuple(
        parse_statistic(as_mapping(item, "return item"))
        for item in as_list(payload.get("return"), "return")
    )
    total_points = tuple(
        parse_statistic(as_mapping(item, "total_points item"))
        for item in as_list(payload.get("total_points"), "total_points")
    )

    extra_sections: dict[str, tuple[Statistic, ...]] = {}
    for key, value in payload.items():
        if key in {"title", "service", "return", "total_points"}:
            continue
        if isinstance(value, list):
            extra_sections[key] = tuple(
                parse_statistic(as_mapping(item, key)) for item in as_list(value, key)
            )

    return MatchStats(
        title=optional_str(payload.get("title")),
        service=service,
        return_stats=return_stats,
        total_points=total_points,
        extra_sections=extra_sections,
    )


def parse_match_detail(payload: Mapping[str, Any]) -> MatchDetail:
    """Parse the full match detail payload."""

    match_payload = as_mapping(payload.get("match_score"), "match_score")
    stats_payload = payload.get("match_state")
    stats = (
        parse_match_stats(as_mapping(stats_payload, "match_state"))
        if isinstance(stats_payload, Mapping)
        else None
    )
    return MatchDetail(match=parse_match_card(match_payload), stats=stats)


def parse_live_match_cards(data: Any) -> tuple[MatchCard, ...]:
    """Parse a list of live match cards."""

    return tuple(
        parse_match_card(as_mapping(item, "live match item")) for item in as_list(data, "data")
    )


def parse_upcoming_matches(payload: Any) -> tuple[MatchCard, ...]:
    """Parse the nested upcoming match payload."""

    if payload in (None, "", []):
        return ()
    mapping = as_mapping(payload, "data")
    return tuple(
        parse_match_card(as_mapping(item, "tournaments_match item"))
        for item in as_list(mapping.get("tournaments_match"), "tournaments_match")
    )


def parse_live_match_detail(payload: Any) -> LiveMatchDetail | None:
    """Parse the live detail payload or return None for an empty response."""

    if payload in (None, "", []):
        return None
    if not isinstance(payload, Mapping):
        raise ValidationError("Expected live match detail to be an object or an empty list.")
    return LiveMatchDetail.from_match_card(parse_match_card(payload))
