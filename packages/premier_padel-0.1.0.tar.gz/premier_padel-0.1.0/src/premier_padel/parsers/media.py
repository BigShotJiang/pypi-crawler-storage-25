"""Parsers for video and reel payloads."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..models.media import (
    ShortReel,
    Video,
    VideoPage,
    VideoPageHero,
    VideoPageMeta,
    VideoPageSection,
)
from .common import (
    as_list,
    as_mapping,
    optional_bool,
    optional_date,
    optional_datetime,
    optional_int,
    optional_str,
)


def parse_video(payload: Mapping[str, Any]) -> Video:
    """Parse a generic video item."""

    return Video(
        id=optional_int(payload.get("video_id")) or 0,
        title=optional_str(payload.get("title")) or "",
        published_on=optional_date(payload.get("date")),
        video_url=optional_str(payload.get("video")),
        image_url=optional_str(payload.get("image")),
        duration=optional_str(payload.get("duration")),
        tournament_name=optional_str(payload.get("tournament")),
        round_name=optional_str(payload.get("round")),
        slug=optional_str(payload.get("slug")),
        status=optional_str(payload.get("status")),
        created_at=optional_datetime(payload.get("created_at")),
        updated_at=optional_datetime(payload.get("updated_at")),
    )


def parse_short_reel(payload: Mapping[str, Any]) -> ShortReel:
    """Parse a reel-style short video item."""

    return ShortReel(
        id=optional_int(payload.get("short_id")) or 0,
        title=optional_str(payload.get("title")) or "",
        api_video_id=optional_int(payload.get("api_video_id")),
        published_on=optional_date(payload.get("date")),
        season_year=optional_str(payload.get("year")),
        video_url=optional_str(payload.get("video")),
        image_url=optional_str(payload.get("image")),
        duration=optional_str(payload.get("duration")),
        scenes=optional_str(payload.get("scenes")),
        media_type=optional_str(payload.get("type")),
        is_top_10_moments=optional_bool(payload.get("is_top_10_moments")),
        tournament_id=optional_int(payload.get("tournaments_id")),
        tournament_name=optional_str(payload.get("tournament")),
        round_name=optional_str(payload.get("round")),
        rating=optional_int(payload.get("rating")),
        views=optional_int(payload.get("views")),
        slug=optional_str(payload.get("slug")),
        match_name=optional_str(payload.get("name")),
        is_featured=optional_bool(payload.get("is_features")),
        status=optional_str(payload.get("status")),
        created_at=optional_datetime(payload.get("created_at")),
        updated_at=optional_datetime(payload.get("updated_at")),
        share_url=optional_str(payload.get("share_url")),
        likes_count=optional_int(payload.get("likes_count")),
        comments_count=optional_int(payload.get("comments_count")),
        share_count=optional_int(payload.get("share_count")),
        is_user_like=optional_bool(payload.get("is_user_like")),
        tags=tuple(str(item) for item in as_list(payload.get("tags"), "tags")),
    )


def parse_video_page(payload: Mapping[str, Any]) -> VideoPage:
    """Parse the video landing page payload."""

    meta_payload = as_mapping(payload.get("meta_data"), "meta_data")
    hero_payload = as_mapping(payload.get("home_screen_data"), "home_screen_data")
    sections_raw = payload.get("video_page")
    if isinstance(sections_raw, Mapping):
        sections_iterable = [sections_raw]
    else:
        sections_iterable = as_list(sections_raw, "video_page")

    sections = tuple(
        parse_video_page_section(as_mapping(item, "video_page item")) for item in sections_iterable
    )
    return VideoPage(
        meta=VideoPageMeta(
            title=optional_str(meta_payload.get("title")),
            meta_title=optional_str(meta_payload.get("meta_title")),
            meta_tag=optional_str(meta_payload.get("meta_tag")),
            meta_description=optional_str(meta_payload.get("meta_description")),
            slug=optional_str(meta_payload.get("slug")),
        ),
        hero=VideoPageHero(
            media_type=optional_str(hero_payload.get("media_type")),
            title=optional_str(hero_payload.get("title")),
            subtitle=optional_str(hero_payload.get("sub_title")),
            video_url=optional_str(hero_payload.get("video")),
            mobile_video_url=optional_str(hero_payload.get("mobile_video")),
            image_url=optional_str(hero_payload.get("image")),
            mobile_image_url=optional_str(hero_payload.get("mobile_image")),
        ),
        sections=sections,
    )


def parse_video_page_section(payload: Mapping[str, Any]) -> VideoPageSection:
    """Parse a single video-page section."""

    videos = tuple(
        parse_video(as_mapping(item, "videos item"))
        for item in as_list(payload.get("videos"), "videos")
    )
    return VideoPageSection(
        id=optional_int(payload.get("video_page_id")),
        title=optional_str(payload.get("title")),
        section_type=optional_str(payload.get("type")),
        display_order=optional_int(payload.get("display_order")),
        videos=videos,
    )
