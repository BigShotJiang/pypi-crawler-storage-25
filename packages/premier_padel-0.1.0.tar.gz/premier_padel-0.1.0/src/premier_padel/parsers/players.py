"""Parsers for player payloads."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..enums import Gender, RankingScope
from ..models.players import PlayerDetail, PlayerMoment, PlayerSummary, PlayerTournamentResult
from .common import (
    as_list,
    as_mapping,
    enum_or_none,
    optional_bool,
    optional_date,
    optional_datetime,
    optional_int,
    optional_str,
)
from .media import parse_short_reel


def parse_player_summary(
    payload: Mapping[str, Any],
    *,
    gender: Gender | None,
    scope: RankingScope | None,
) -> PlayerSummary:
    """Parse a ranking/search player summary."""

    return PlayerSummary(
        id=optional_int(payload.get("player_id")) or 0,
        slug=optional_str(payload.get("slug")) or "",
        first_name=optional_str(payload.get("first_name")) or "",
        last_name=optional_str(payload.get("last_name")) or "",
        full_name=optional_str(payload.get("full_name")) or "",
        image_url=optional_str(payload.get("image")),
        thumbnail_url=optional_str(payload.get("thumbnail_image")),
        country_flag_url=optional_str(payload.get("countries_image")),
        status=optional_str(payload.get("status")),
        gender=gender,
        scope=scope,
        created_at=optional_datetime(payload.get("created_at")),
        updated_at=optional_datetime(payload.get("updated_at")),
    )


def parse_player_tournament_result(payload: Mapping[str, Any]) -> PlayerTournamentResult:
    """Parse a player tournament-result record."""

    return PlayerTournamentResult(
        id=optional_int(payload.get("player_tournaments_id")) or 0,
        player_id=optional_int(payload.get("player_id")) or 0,
        key_name=optional_str(payload.get("key_name")),
        name=optional_str(payload.get("name")),
        category_name=optional_str(payload.get("category_name")),
        category_id=optional_str(payload.get("category_id")),
        tournament_type=optional_str(payload.get("type")),
        played_on=optional_date(payload.get("date")),
        round_name=optional_str(payload.get("round_name")),
        points=optional_int(payload.get("points")),
        created_at=optional_datetime(payload.get("created_at")),
        updated_at=optional_datetime(payload.get("updated_at")),
    )


def parse_player_detail(payload: Mapping[str, Any]) -> PlayerDetail:
    """Parse a full player profile payload."""

    tournaments = tuple(
        parse_player_tournament_result(as_mapping(item, "player_tournaments item"))
        for item in as_list(payload.get("player_tournaments"), "player_tournaments")
    )
    return PlayerDetail(
        id=optional_int(payload.get("player_id")) or 0,
        slug=optional_str(payload.get("slug")) or "",
        first_name=optional_str(payload.get("first_name")) or "",
        last_name=optional_str(payload.get("last_name")) or "",
        full_name=optional_str(payload.get("full_name")) or "",
        nickname=optional_str(payload.get("nick_name")),
        image_url=optional_str(payload.get("image")),
        thumbnail_url=optional_str(payload.get("thumbnail_image")),
        sponsor_image_url=optional_str(payload.get("sponsor_image")),
        gender=enum_or_none(Gender, payload.get("gender")),
        player_code=optional_str(payload.get("playerId")),
        country_code=optional_str(payload.get("country_code")),
        country_code_iso2=optional_str(payload.get("country_code_iso_2")),
        country_flag_url=optional_str(payload.get("countries_image")),
        ranking=optional_int(payload.get("ranking")),
        points=optional_int(payload.get("points")),
        quote=optional_str(payload.get("quote")),
        bio=optional_str(payload.get("bio")),
        birth_date=optional_date(payload.get("birth_date")),
        height=optional_str(payload.get("height")),
        play_hand=optional_str(payload.get("play_hand")),
        facebook_url=optional_str(payload.get("facebook_url")),
        instagram_url=optional_str(payload.get("instagram_url")),
        youtube_url=optional_str(payload.get("youtube_url")),
        twitter_url=optional_str(payload.get("twitter_url")),
        partner_player_id=optional_int(payload.get("partner_player_id")),
        partner_player_code=optional_str(payload.get("partnerplayerId")),
        partner_player_name=optional_str(payload.get("partner_player_name")),
        partner_player_image_url=optional_str(payload.get("partner_player_image")),
        partner_player_thumbnail_url=optional_str(payload.get("partner_player_thumbnail_image")),
        is_favourite=optional_bool(payload.get("is_favourite")),
        status=optional_str(payload.get("status")),
        created_at=optional_datetime(payload.get("created_at")),
        updated_at=optional_datetime(payload.get("updated_at")),
        tournaments=tournaments,
    )


def parse_player_moment(payload: Mapping[str, Any]) -> PlayerMoment:
    """Parse a player moment item."""

    reel = parse_short_reel(payload)
    return PlayerMoment(**reel.__dict__)
