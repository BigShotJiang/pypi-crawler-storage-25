"""Parsers for tournament payloads."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import date
from typing import Any

from ..enums import BracketDrawType, ResultsDrawType
from ..exceptions import ValidationError
from ..models.tournaments import (
    DrawContestant,
    DrawMatch,
    DrawRound,
    DrawSide,
    Tournament,
    TournamentDate,
    TournamentDraw,
    TournamentEntrants,
    TournamentEntry,
    TournamentResults,
)
from .common import (
    as_list,
    as_mapping,
    optional_bool,
    optional_date,
    optional_datetime,
    optional_int,
    optional_str,
    parse_competitor,
)
from .matches import parse_match_card


def parse_tournament(payload: Mapping[str, Any]) -> Tournament:
    """Parse a tournament list item."""

    return Tournament(
        id=optional_int(payload.get("tournaments_id")) or 0,
        slug=optional_str(payload.get("slug")) or "",
        event_code=optional_str(payload.get("event_code")),
        name=optional_str(payload.get("name")),
        full_name=optional_str(payload.get("full_name")),
        city=optional_str(payload.get("city")),
        country=optional_str(payload.get("country")),
        country_code=optional_str(payload.get("country_code")),
        gender=optional_str(payload.get("gender")),
        currency=optional_str(payload.get("currency")),
        prize_money=optional_str(payload.get("prize_money")),
        tournament_type=optional_str(payload.get("type")),
        display_date=optional_str(payload.get("display_date")),
        entry_list_opens=optional_datetime(
            payload.get("entry_list_opens_utc") or payload.get("entry_list_opens")
        ),
        entry_list_closes=optional_datetime(
            payload.get("entry_list_closes_utc") or payload.get("entry_list_closes")
        ),
        start_date=optional_date(payload.get("start_date_utc") or payload.get("start_date")),
        end_date=optional_date(payload.get("end_date_utc") or payload.get("end_date")),
        deadline_for_registration=optional_str(payload.get("deadline_for_registration")),
        qualification_date=optional_str(payload.get("qualification_date")),
        main_draw_date=optional_str(payload.get("main_draw_date")),
        image_url=optional_str(payload.get("image")),
        club=optional_str(payload.get("club")),
        ticket_url=optional_str(payload.get("ticket_url")),
        where_to_watch_url=optional_str(payload.get("where_to_watch")),
        deadline_for_registration_url=optional_str(payload.get("deadline_for_registration_url")),
        external_url=optional_str(payload.get("external_url")),
        watch_now_url=optional_str(payload.get("watch_now_url")),
        status=optional_str(payload.get("status")),
        tournaments_type=optional_str(payload.get("tournaments_type")),
        year=optional_int(payload.get("year")),
        is_registration_open=optional_bool(payload.get("is_registration")),
        is_live=optional_bool(payload.get("is_live")),
        is_show_order_of_play=optional_bool(payload.get("is_show_order_of_play")),
        is_show_draw_dates=optional_bool(payload.get("is_show_draw_dates")),
        is_live_match=optional_bool(payload.get("is_live_match")),
        is_all_match_completed=optional_bool(payload.get("is_all_match_completed")),
        is_result_available=optional_bool(payload.get("is_result_available")),
        is_draw_available=optional_bool(payload.get("is_draw_available")),
        created_at=optional_datetime(payload.get("created_at")),
        updated_at=optional_datetime(payload.get("updated_at")),
    )


def parse_tournament_date(payload: Mapping[str, Any]) -> TournamentDate:
    """Parse a tournament result-date item."""

    parsed_date = optional_date(payload.get("date"))
    if parsed_date is None:
        raise ValidationError("Tournament date payload did not contain a valid ISO date.")
    return TournamentDate(
        tournament_id=optional_int(payload.get("tournaments_id")) or 0,
        date=parsed_date,
        display_date=optional_str(payload.get("display_date")) or "",
    )


def parse_tournament_entry(payload: Mapping[str, Any]) -> TournamentEntry:
    """Parse a tournament entrant pair."""

    return TournamentEntry(
        id=optional_int(payload.get("tournaments_player_id")) or 0,
        tournament_id=optional_int(payload.get("tournaments_id")) or 0,
        draw_type=optional_str(payload.get("type")) or "",
        player=parse_competitor(
            name=payload.get("player_name"),
            image_url=payload.get("player_image"),
            country_flag_url=payload.get("player_countries_image"),
            identifier=payload.get("player_id"),
            external_id=payload.get("playerId"),
        ),
        partner=parse_competitor(
            name=payload.get("partner_player_name"),
            image_url=payload.get("partner_player_image"),
            country_flag_url=payload.get("partner_player_countries_image"),
            identifier=payload.get("partner_player_id"),
            external_id=payload.get("partnerplayerId"),
        )
        if optional_str(payload.get("partner_player_name")) is not None
        else None,
        player_points=optional_int(payload.get("player_point")),
        partner_points=optional_int(payload.get("partner_player_point")),
        total_points=optional_int(payload.get("total_point")),
        rank=optional_int(payload.get("rank")),
        created_at=optional_datetime(payload.get("created_at")),
        updated_at=optional_datetime(payload.get("updated_at")),
    )


def parse_tournament_entrants(payload: Mapping[str, Any]) -> TournamentEntrants:
    """Parse grouped tournament entrant lists."""

    return TournamentEntrants(
        men_main=tuple(
            parse_tournament_entry(as_mapping(item, "player_md item"))
            for item in as_list(payload.get("player_md"), "player_md")
        ),
        women_main=tuple(
            parse_tournament_entry(as_mapping(item, "player_wd item"))
            for item in as_list(payload.get("player_wd"), "player_wd")
        ),
        men_qualifying=tuple(
            parse_tournament_entry(as_mapping(item, "player_mq item"))
            for item in as_list(payload.get("player_mq"), "player_mq")
        ),
        women_qualifying=tuple(
            parse_tournament_entry(as_mapping(item, "player_wq item"))
            for item in as_list(payload.get("player_wq"), "player_wq")
        ),
    )


def parse_draw(
    payload: Mapping[str, Any], *, slug: str, draw_type: BracketDrawType
) -> TournamentDraw:
    """Parse a tournament bracket payload."""

    contestants_payload = as_mapping(payload.get("contestants"), "contestants")
    contestants = {
        str(contestant_id): DrawContestant(
            id=str(contestant_id),
            entry_status=optional_str(as_mapping(item, "contestant").get("entryStatus")),
            players=tuple(
                parse_competitor(
                    name=player_payload.get("title"),
                    country_flag_url=player_payload.get("nationality"),
                )
                for player_payload in (
                    as_mapping(player_item, "contestant player")
                    for player_item in as_list(
                        as_mapping(item, "contestant").get("players"), "players"
                    )
                )
            ),
        )
        for contestant_id, item in contestants_payload.items()
    }

    matches = []
    for item in as_list(payload.get("matches"), "matches"):
        match_payload = as_mapping(item, "matches item")
        sides = tuple(
            DrawSide(
                contestant_id=optional_str(side_payload.get("contestantId")),
                is_winner=optional_bool(side_payload.get("isWinner")),
                scores=tuple(
                    optional_str(as_mapping(score_payload, "score").get("mainScore")) or ""
                    for score_payload in as_list(side_payload.get("scores"), "scores")
                ),
            )
            for side_payload in (
                as_mapping(side_item, "side")
                for side_item in as_list(match_payload.get("sides"), "sides")
            )
        )
        matches.append(
            DrawMatch(
                round_index=optional_int(match_payload.get("roundIndex")) or 0,
                order=optional_int(match_payload.get("order")) or 0,
                sides=sides,
            )
        )

    rounds = tuple(
        DrawRound(name=optional_str(as_mapping(item, "rounds item").get("name")) or "")
        for item in as_list(payload.get("rounds"), "rounds")
    )
    return TournamentDraw(
        slug=slug,
        draw_type=draw_type,
        rounds=rounds,
        contestants=contestants,
        matches=tuple(matches),
    )


def parse_tournament_results(
    payload: Mapping[str, Any],
    *,
    tournament_id: int,
    scheduled_on: date,
    draw_type: ResultsDrawType,
) -> TournamentResults:
    """Parse grouped tournament result sections."""

    return TournamentResults(
        tournament_id=tournament_id,
        date=scheduled_on,
        draw_type=draw_type,
        main_draw=tuple(
            parse_match_card(as_mapping(item, "main_draw item"))
            for item in as_list(payload.get("main_draw"), "main_draw")
        ),
        qualify_draw=tuple(
            parse_match_card(as_mapping(item, "qualify_draw item"))
            for item in as_list(payload.get("qualify_draw"), "qualify_draw")
        ),
        live=tuple(
            parse_match_card(as_mapping(item, "live item"))
            for item in as_list(payload.get("live"), "live")
        ),
        upcoming=tuple(
            parse_match_card(as_mapping(item, "upcoming item"))
            for item in as_list(payload.get("upcoming"), "upcoming")
        ),
    )
