"""Client configuration primitives."""

from __future__ import annotations

from dataclasses import dataclass

from ._version import build_user_agent

DEFAULT_BASE_URL = "https://premierpadel.com/premierpadel/api"
DEFAULT_USER_AGENT = build_user_agent()


@dataclass(frozen=True)
class ClientConfig:
    """Immutable configuration shared across the SDK."""

    base_url: str = DEFAULT_BASE_URL
    lang: str = "en"
    timeout: float = 10.0
    retries: int = 2
    user_agent: str = DEFAULT_USER_AGENT
