"""Internal HTTP transport for the Premier Padel SDK."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any

import httpx

from .config import ClientConfig
from .exceptions import (
    ApiResponseError,
    HTTPStatusError,
    NetworkError,
    RateLimitError,
    TimeoutError,
)


@dataclass(frozen=True)
class ApiEnvelope:
    """Normalized representation of the API's generic response envelope."""

    status: int
    message: str | None
    data: Any
    current_page: int | None = None
    total_page: int | None = None
    total_jobs: int | None = None
    is_next_page: bool | None = None
    is_live_match: bool | None = None
    raw: Mapping[str, Any] = field(default_factory=dict, repr=False)


class Transport:
    """HTTP client wrapper that centralizes request execution and envelope parsing."""

    def __init__(
        self,
        config: ClientConfig,
        *,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self._config = config
        self._client = httpx.Client(
            base_url=config.base_url.rstrip("/") + "/",
            timeout=config.timeout,
            follow_redirects=True,
            headers={
                "Accept": "application/json",
                "User-Agent": config.user_agent,
            },
            transport=transport,
        )

    def close(self) -> None:
        """Close the underlying HTTP client."""

        self._client.close()

    def post_form(self, endpoint: str, data: Mapping[str, object | None]) -> ApiEnvelope:
        """Send a multipart form POST request and parse the generic API envelope."""

        files = [
            (key, (None, self._serialize_value(value)))
            for key, value in data.items()
            if value is not None
        ]

        attempts = self._config.retries + 1
        last_error: Exception | None = None
        response: httpx.Response | None = None

        for attempt in range(attempts):
            try:
                response = self._client.post(endpoint.lstrip("/"), files=files)
            except httpx.TimeoutException as exc:
                last_error = TimeoutError(f"Request to {endpoint} timed out.")
                if attempt + 1 >= attempts:
                    raise last_error from exc
                continue
            except httpx.TransportError as exc:
                last_error = NetworkError(f"Request to {endpoint} failed due to a network error.")
                if attempt + 1 >= attempts:
                    raise last_error from exc
                continue

            if response.status_code >= 500 and attempt + 1 < attempts:
                continue

            break

        if response is None:
            if last_error is not None:
                raise last_error
            raise NetworkError(f"Request to {endpoint} did not produce a response.")

        if response.status_code == 429:
            raise RateLimitError(
                response.status_code,
                f"Premier Padel rate-limited the request to {endpoint}.",
                body=response.text,
            )
        if response.status_code >= 400:
            raise HTTPStatusError(
                response.status_code,
                f"Premier Padel returned HTTP {response.status_code} for {endpoint}.",
                body=response.text,
            )

        try:
            payload = response.json()
        except ValueError as exc:
            raise ApiResponseError(
                f"Premier Padel returned invalid JSON for {endpoint}.",
                payload=response.text,
            ) from exc

        if not isinstance(payload, dict):
            raise ApiResponseError(
                f"Premier Padel returned an unexpected response envelope for {endpoint}.",
                payload=payload,
            )

        return ApiEnvelope(
            status=self._coerce_int(payload.get("status"), default=0),
            message=self._coerce_str(payload.get("message")),
            data=payload.get("data"),
            current_page=self._coerce_optional_int(payload.get("current_page")),
            total_page=self._coerce_optional_int(payload.get("total_page")),
            total_jobs=self._coerce_optional_int(payload.get("total_jobs")),
            is_next_page=self._coerce_flag(payload.get("is_next_page"), {"Y": True, "N": False}),
            is_live_match=self._coerce_flag(
                payload.get("is_live_match"),
                {"Yes": True, "No": False},
            ),
            raw=payload,
        )

    @staticmethod
    def _serialize_value(value: object) -> str:
        return str(value)

    @staticmethod
    def _coerce_str(value: object) -> str | None:
        if value in (None, ""):
            return None
        return str(value)

    @staticmethod
    def _coerce_int(value: object, *, default: int) -> int:
        text = Transport._coerce_str(value)
        if text is None:
            return default
        try:
            return int(text)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _coerce_optional_int(value: object) -> int | None:
        text = Transport._coerce_str(value)
        if text is None:
            return None
        try:
            return int(text)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _coerce_flag(value: object, mapping: Mapping[str, bool]) -> bool | None:
        if value is None:
            return None
        return mapping.get(str(value))
