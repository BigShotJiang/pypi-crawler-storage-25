"""Custom exception hierarchy for the SDK."""

from __future__ import annotations

from typing import Any


class PremierPadelError(Exception):
    """Base class for all SDK errors."""


class NetworkError(PremierPadelError):
    """Raised when the API cannot be reached."""


class TimeoutError(NetworkError):
    """Raised when a request exceeds the configured timeout."""


class HTTPStatusError(PremierPadelError):
    """Raised for non-success HTTP responses."""

    def __init__(self, status_code: int, message: str, *, body: str | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class RateLimitError(HTTPStatusError):
    """Raised when the API rate-limits the client."""


class ApiResponseError(PremierPadelError):
    """Raised when the API reports an application-level failure."""

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        payload: Any | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.payload = payload


class NotFoundError(ApiResponseError):
    """Raised when the requested resource cannot be resolved."""


class ValidationError(PremierPadelError):
    """Raised when the API response shape is not compatible with the SDK models."""
