"""Public enums used by the SDK."""

from __future__ import annotations

from enum import Enum


class _StrEnum(str, Enum):
    def __str__(self) -> str:
        return str(self.value)


class Gender(_StrEnum):
    """Gender selector supported by ranking endpoints."""

    MALE = "Male"
    FEMALE = "Female"


class RankingScope(_StrEnum):
    """Ranking window selector used by player ranking endpoints."""

    OVERALL = "No"
    THIS_YEAR = "Yes"


class BracketDrawType(_StrEnum):
    """Draw selector used by tournament bracket endpoints."""

    MEN_MAIN = "MD"
    WOMEN_MAIN = "WD"
    MEN_QUALIFYING = "MQ"
    WOMEN_QUALIFYING = "WQ"


class ResultsDrawType(_StrEnum):
    """Draw selector used by tournament results endpoints."""

    MEN = "Men"
    WOMEN = "Women"


class NewsSort(_StrEnum):
    """Sort selector used by the news list endpoint."""

    NEWEST = "Newest"
    OLDEST = "Oldest"
