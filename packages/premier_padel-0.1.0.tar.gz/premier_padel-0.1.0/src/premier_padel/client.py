"""Public client entrypoint."""

from __future__ import annotations

from calendar import month_name
from datetime import datetime, timezone
from typing import TYPE_CHECKING

import httpx

from .config import DEFAULT_BASE_URL, DEFAULT_USER_AGENT, ClientConfig
from .exceptions import ApiResponseError, NotFoundError
from .models.players import PlayerDetail, PlayerSummary
from .models.tournaments import Tournament
from .parsers.common import as_list, as_mapping
from .parsers.tournaments import parse_tournament
from .services.matches import MatchService
from .services.media import MediaService
from .services.news import NewsService
from .services.players import PlayerService
from .services.rankings import RankingService
from .services.tournaments import TournamentService
from .services.watch import WatchService
from .transport import Transport

if TYPE_CHECKING:
    from .models.players import PlayerDetail as PlayerDetailModel
    from .models.players import PlayerSummary as PlayerSummaryModel


class PremierPadelClient:
    """Sync client for Premier Padel public sports-data APIs."""

    def __init__(
        self,
        *,
        base_url: str = DEFAULT_BASE_URL,
        lang: str = "en",
        timeout: float = 10.0,
        retries: int = 2,
        user_agent: str = DEFAULT_USER_AGENT,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self._config = ClientConfig(
            base_url=base_url,
            lang=lang,
            timeout=timeout,
            retries=retries,
            user_agent=user_agent,
        )
        self._transport = Transport(self._config, transport=transport)
        self._players_by_id: dict[int, PlayerSummaryModel | PlayerDetailModel] = {}
        self._players_by_slug: dict[str, PlayerSummaryModel | PlayerDetailModel] = {}
        self._tournaments_by_id: dict[int, Tournament] = {}
        self._tournaments_by_slug: dict[str, Tournament] = {}
        self._rankings = RankingService(self)

        self.players = PlayerService(self)
        self.tournaments = TournamentService(self)
        self.matches = MatchService(self)
        self.watch = WatchService(self)
        self.media = MediaService(self)
        self.news = NewsService(self)

    def close(self) -> None:
        """Close the underlying HTTP client."""

        self._transport.close()

    def __enter__(self) -> PremierPadelClient:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: object | None,
    ) -> None:
        self.close()

    def _remember_player(self, player: PlayerSummary | PlayerDetail) -> None:
        self._players_by_id[player.id] = player
        self._players_by_slug[player.slug] = player

    def _remember_tournament(self, tournament: Tournament) -> None:
        self._tournaments_by_id[tournament.id] = tournament
        self._tournaments_by_slug[tournament.slug] = tournament

    def _lookup_tournament_by_slug(self, slug: str, *, lang: str | None = None) -> Tournament:
        cached = self._tournaments_by_slug.get(slug)
        if cached is not None:
            return cached
        resolved = self._find_tournament(slug=slug, lang=lang)
        if resolved is None:
            raise NotFoundError(f"Could not resolve tournament slug {slug!r}.")
        self._remember_tournament(resolved)
        return resolved

    def _lookup_tournament_by_id(
        self, tournament_id: int, *, lang: str | None = None
    ) -> Tournament:
        cached = self._tournaments_by_id.get(tournament_id)
        if cached is not None:
            return cached
        resolved = self._find_tournament(tournament_id=tournament_id, lang=lang)
        if resolved is None:
            raise NotFoundError(f"Could not resolve tournament id {tournament_id!r}.")
        self._remember_tournament(resolved)
        return resolved

    def _find_tournament(
        self,
        *,
        slug: str | None = None,
        tournament_id: int | None = None,
        lang: str | None = None,
    ) -> Tournament | None:
        for month, year in self._iter_tournament_lookup_windows():
            for tournament in self._fetch_tournaments_for_month(month, year, lang=lang):
                if slug is not None and tournament.slug == slug:
                    return tournament
                if tournament_id is not None and tournament.id == tournament_id:
                    return tournament
        return None

    def _fetch_tournaments_for_month(
        self,
        month: str,
        year: int,
        *,
        lang: str | None = None,
    ) -> tuple[Tournament, ...]:
        envelope = self._transport.post_form(
            "/beforeauth/getfanapptournaments",
            {
                "page": "",
                "pagesize": -1,
                "month_name": month,
                "year": year,
                "lang": lang or self._config.lang,
            },
        )
        if envelope.status != 1:
            message = envelope.message or "Premier Padel API request failed."
            raise ApiResponseError(message, status=envelope.status, payload=envelope.raw)
        tournaments = tuple(
            parse_tournament(as_mapping(item, "tournament"))
            for item in as_list(envelope.data, "data")
        )
        for tournament in tournaments:
            self._remember_tournament(tournament)
        return tournaments

    @staticmethod
    def _iter_tournament_lookup_windows() -> tuple[tuple[str, int], ...]:
        today = datetime.now(timezone.utc)
        month_indexes = sorted(range(1, 13), key=lambda value: abs(value - today.month))
        years = (today.year, today.year - 1, today.year + 1)
        return tuple((month_name[index], year) for year in years for index in month_indexes)
