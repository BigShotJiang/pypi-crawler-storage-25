"""Package version helpers."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

PACKAGE_NAME = "premier-padel"
FALLBACK_VERSION = "0+unknown"


def get_installed_version(package_name: str = PACKAGE_NAME) -> str:
    """Return the installed package version or a safe fallback for local sources."""

    try:
        return version(package_name)
    except PackageNotFoundError:
        return FALLBACK_VERSION


def build_user_agent(package_version: str | None = None) -> str:
    """Build the default SDK user agent string."""

    resolved_version = package_version or get_installed_version()
    return f"premier-padel-python/{resolved_version}"


__version__ = get_installed_version()
