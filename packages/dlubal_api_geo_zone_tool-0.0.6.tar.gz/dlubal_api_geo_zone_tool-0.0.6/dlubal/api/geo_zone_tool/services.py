from __future__ import annotations

import asyncio
import json
import inspect
from enum import Enum
from collections.abc import Iterator
from typing import Any

import requests
import websockets

from dlubal.api.geo_zone_tool.config import (
    GEO_ZONE_GRAPHQL_URL,
    AUTHORIZATION_HEADER,
)
from dlubal.api.geo_zone_tool.gql import (
    GET_ASCE722_QUERY,
    GET_GEO_LOCATIONS_QUERY,
    GET_LOAD_ZONE_SCREENSHOT_QUERY,
    GET_LOAD_ZONE_STANDARDS_QUERY,
    GET_PDF_SUBSCRIPTION,
    GET_USER_DATA_QUERY,
    GET_ZONE_CHARACTERISTICS_QUERY,
)
from dlubal.api.geo_zone_tool.models import (
    Asce722ResponseType,
    CharacteristicsResponseMiaType,
    GeoLocation,
    GeoLocations,
    LoadZoneTypes,
    LoadZoneGroupType,
    PdfProgressType,
    PdfResultType,
    Screenshot,
    UserData,
)


GRAPHQL_TIMEOUT_SECONDS = 30


class Language(Enum):
    """
    Language enum for GeoZone requests.
    Values must match GraphQL LanguageEnum.
    """

    EN = "EN"
    DE = "DE"
    IT = "IT"
    CS = "CS"
    FR = "FR"
    ES = "ES"
    PT = "PT"
    PL = "PL"
    RU = "RU"
    ZH = "ZH"


class LoadZoneType(Enum):
    """
    Load zone type enum for GeoZone requests.
    Values must match GraphQL LoadzoneTypeEnum.
    """

    SNOW = "SNOW"
    WIND = "WIND"
    EARTHQUAKE = "EARTHQUAKE"
    TORNADO = "TORNADO"


class ScreenshotType(Enum):
    """
    Screenshot type enum for GeoZone requests.
    Values must match GraphQL ScreenshotTypeEnum.
    """

    PNG = "PNG"
    JPEG = "JPEG"


class RiskCategory(Enum):
    """
    Risk category enum for ASCE 7-22 requests.
    Values must match GraphQL RiskCategoryEnum.
    """

    I = "I"
    II = "II"
    III = "III"
    IV = "IV"


class SiteClass(Enum):
    """
    Site class enum for ASCE 7-22 requests.
    Values must match GraphQL SiteClassEnum.
    """

    DEFAULT = "DEFAULT"
    A = "A"
    B = "B"
    BC = "BC"
    C = "C"
    CD = "CD"
    D = "D"
    DE = "DE"
    E = "E"


def _require_non_empty(name: str, value: str) -> None:
    """Fast, client-side validation for required non-empty strings."""
    if value is None or not str(value).strip():
        raise ValueError(f"{name} must not be empty")


def _require_int_min(name: str, value: int, minimum: int = 0) -> None:
    """Fast, client-side validation for integer params with obvious bounds."""
    if value < minimum:
        raise ValueError(f"{name} must be >= {minimum}")


def _require_enum(name: str, value: Enum, enum_cls: type[Enum]) -> None:
    """Fast, client-side validation for enum params."""
    if not isinstance(value, enum_cls):
        raise TypeError(f"{name} must be {enum_cls.__name__}")


def _graphql_post(
    token: str,
    query: str,
    variables: dict[str, Any] | None = None,
) -> dict[str, Any]:
    _require_non_empty("token", token)
    payload = {
        "query": query,
        "variables": variables or {},
    }
    headers = {
        "Content-Type": "application/json",
        AUTHORIZATION_HEADER: f"Bearer {token}",
    }
    response = requests.post(
        GEO_ZONE_GRAPHQL_URL,
        json=payload,
        headers=headers,
        timeout=GRAPHQL_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    data = response.json()
    if "errors" in data:
        messages = "; ".join(
            err.get("message", "Unknown error") for err in data["errors"]
        )
        raise RuntimeError(f"GraphQL error: {messages}")

    return data.get("data") or {}


def _graphql_ws_url(http_url: str) -> str:
    if http_url.startswith("https://"):
        return "wss://" + http_url.removeprefix("https://")
    if http_url.startswith("http://"):
        return "ws://" + http_url.removeprefix("http://")
    return http_url


def _graphql_subscribe(
    token: str,
    query: str,
    variables: dict[str, Any],
) -> list[dict[str, Any]]:
    _require_non_empty("token", token)
    ws_url = _graphql_ws_url(GEO_ZONE_GRAPHQL_URL)

    async def _run() -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        connect_kwargs: dict[str, Any] = {
            "subprotocols": ["graphql-transport-ws", "graphql-ws"],
        }
        header_param = (
            "additional_headers"
            if "additional_headers"
            in inspect.signature(websockets.connect).parameters
            else "extra_headers"
        )
        connect_kwargs[header_param] = [
            (AUTHORIZATION_HEADER, f"Bearer {token}")
        ]
        async with websockets.connect(ws_url, **connect_kwargs) as ws:
            await ws.send(
                json.dumps({"type": "connection_init", "payload": {}})
            )

            while True:
                raw = await ws.recv()
                message = json.loads(raw)
                msg_type = message.get("type")
                if msg_type == "connection_ack":
                    break
                if msg_type in ("ka", "connection_keep_alive"):
                    continue
                if msg_type == "connection_error":
                    raise RuntimeError(
                        f"GraphQL WS connection error: {message.get('payload')}"
                    )

            op_type = "start" if ws.subprotocol == "graphql-ws" else "subscribe"
            await ws.send(
                json.dumps(
                    {
                        "id": "1",
                        "type": op_type,
                        "payload": {"query": query, "variables": variables},
                    }
                )
            )

            while True:
                raw = await ws.recv()
                message = json.loads(raw)
                msg_type = message.get("type")
                if msg_type in ("next", "data"):
                    payload = message.get("payload") or {}
                    if "errors" in payload:
                        messages = "; ".join(
                            err.get("message", "Unknown error")
                            for err in payload["errors"]
                        )
                        raise RuntimeError(f"GraphQL error: {messages}")
                    if "data" in payload:
                        results.append(payload["data"])
                elif msg_type == "error":
                    raise RuntimeError(
                        f"GraphQL WS error: {message.get('payload')}"
                    )
                elif msg_type == "complete":
                    break
                elif msg_type in ("ka", "connection_keep_alive"):
                    continue

        return results

    return asyncio.run(_run())


class GeoZoneTool:
    """
    Token-bound wrapper around all public GeoZone services.
    """

    def __init__(self, token: str):
        """Initialize the GeoZone wrapper with an access token."""
        _require_non_empty("token", token)
        self._token = token

    @property
    def token(self) -> str:
        """Return the currently configured bearer token."""
        return self._token

    def get_geo_locations(
        self,
        address: str,
        language: Language = Language.EN,
        sort_country_code: str | None = None,
    ) -> GeoLocations:
        """Get geo locations for an address or coordinates string."""
        _require_non_empty("address", address)
        _require_enum("language", language, Language)

        variables = {
            "address": address,
            "sortCountryCode": sort_country_code,
            "language": language.value,
        }
        data = _graphql_post(self._token, GET_GEO_LOCATIONS_QUERY, variables)
        locations = [
            GeoLocation.from_dict(item)
            for item in data.get("getGeoLocations", [])
        ]
        return GeoLocations(locations=locations)

    def get_user_data(self) -> UserData:
        """Get profile/usage data for the authorized user."""
        data = _graphql_post(self._token, GET_USER_DATA_QUERY)
        return UserData.from_dict(data.get("getUserData") or {})

    def get_load_zone_standards(
        self,
        country_code: str,
        language: Language = Language.EN,
    ) -> LoadZoneTypes:
        """Get available load zone standards for a country."""
        _require_non_empty("country_code", country_code)
        _require_enum("language", language, Language)

        data = _graphql_post(
            self._token,
            GET_LOAD_ZONE_STANDARDS_QUERY,
            {
                "countryCode": country_code.strip().upper(),
                "language": language.value,
            },
        )
        groups = [
            LoadZoneGroupType.from_dict(group)
            for group in data.get("getLoadZoneStandards", [])
        ]
        return LoadZoneTypes(types=groups)

    def get_load_zone_characteristics(
        self,
        address: str,
        load_zone_type: LoadZoneType,
        standard: str,
        annex: str,
        layer_id: int,
        language: Language = Language.EN,
    ) -> CharacteristicsResponseMiaType:
        """Get load zone characteristics for a selected standard/annex/layer."""
        _require_non_empty("address", address)
        _require_non_empty("standard", standard)
        _require_non_empty("annex", annex)
        _require_int_min("layer_id", layer_id)
        _require_enum("load_zone_type", load_zone_type, LoadZoneType)
        _require_enum("language", language, Language)

        variables = {
            "input": {
                "address": address,
                "type": load_zone_type.value,
                "standard": standard,
                "annex": annex,
                "layerId": layer_id,
            },
            "language": language.value,
        }
        data = _graphql_post(self._token, GET_ZONE_CHARACTERISTICS_QUERY, variables)
        return CharacteristicsResponseMiaType.from_dict(
            data.get("getLoadZoneCharacteristics") or {}
        )

    def get_load_zone_screenshot(
        self,
        address: str,
        load_zone_type: LoadZoneType,
        standard: str,
        annex: str,
        layer_id: int,
        zoom: int,
        language: Language = Language.EN,
        layer_order: int | None = None,
        screenshot_type: ScreenshotType | None = None,
        screenshot_quality: int | None = None,
    ) -> Screenshot:
        """Get a Base64-encoded map screenshot for the selected load zone."""
        _require_non_empty("address", address)
        _require_non_empty("standard", standard)
        _require_non_empty("annex", annex)
        _require_int_min("layer_id", layer_id)
        _require_int_min("zoom", zoom)
        _require_enum("load_zone_type", load_zone_type, LoadZoneType)
        _require_enum("language", language, Language)
        if layer_order is not None:
            _require_int_min("layer_order", layer_order)
        if screenshot_quality is not None:
            _require_int_min("screenshot_quality", screenshot_quality)

        screenshot_input: dict[str, Any] | None = None
        if screenshot_type is not None or screenshot_quality is not None:
            screenshot_input = {
                "type": (screenshot_type or ScreenshotType.PNG).value,
                "quality": 0
                if screenshot_quality is None
                else screenshot_quality,
            }

        input_payload: dict[str, Any] = {
            "address": address,
            "type": load_zone_type.value,
            "standard": standard,
            "annex": annex,
            "layerId": layer_id,
            "zoom": zoom,
        }
        if layer_order is not None:
            input_payload["layerOrder"] = layer_order
        if screenshot_input is not None:
            input_payload["screenshotType"] = screenshot_input

        variables = {
            "input": input_payload,
            "language": language.value,
        }

        data = _graphql_post(
            self._token,
            GET_LOAD_ZONE_SCREENSHOT_QUERY,
            variables,
        )
        return Screenshot(screenshot=str(data.get("getLoadZoneScreenshot", "")))

    def get_load_zone_pdf(
        self,
        address: str,
        standard: str,
        annex: str,
        layer_id: int,
        language: Language = Language.EN,
    ) -> Iterator[PdfProgressType]:
        """Stream PDF generation progress messages via GraphQL subscription."""
        _require_non_empty("address", address)
        _require_non_empty("standard", standard)
        _require_non_empty("annex", annex)
        _require_int_min("layer_id", layer_id)
        _require_enum("language", language, Language)

        variables = {
            "pdfInput": {
                "address": address,
                "standard": standard,
                "annex": annex,
                "layerId": layer_id,
            },
            "language": language.value,
        }

        results = _graphql_subscribe(self._token, GET_PDF_SUBSCRIPTION, variables)
        items = [
            PdfProgressType.from_dict(item.get("getPdf") or {})
            for item in results
            if item.get("getPdf")
        ]
        return iter(items)

    def get_asce722(
        self,
        latitude: float,
        longitude: float,
        risk_category: RiskCategory,
        site_class: SiteClass,
    ) -> Asce722ResponseType:
        """Get ASCE 7-22 seismic design map parameters from USGS."""
        if not isinstance(latitude, (int, float)):
            raise TypeError("latitude must be a number")
        if not isinstance(longitude, (int, float)):
            raise TypeError("longitude must be a number")
        if not -90.0 <= latitude <= 90.0:
            raise ValueError("latitude must be between -90 and 90")
        if not -180.0 <= longitude <= 180.0:
            raise ValueError("longitude must be between -180 and 180")
        _require_enum("risk_category", risk_category, RiskCategory)
        _require_enum("site_class", site_class, SiteClass)

        variables = {
            "latitude": float(latitude),
            "longitude": float(longitude),
            "riskCategory": risk_category.value,
            "siteClass": site_class.value,
        }
        data = _graphql_post(self._token, GET_ASCE722_QUERY, variables)
        return Asce722ResponseType.from_dict(data.get("getAsce722") or {})

    def get_load_zone_pdf_result(
        self,
        address: str,
        standard: str,
        annex: str,
        layer_id: int,
        language: Language = Language.EN,
    ) -> PdfResultType | None:
        """Return the final PDF result by consuming the full progress stream."""
        last: PdfProgressType | None = None
        for msg in self.get_load_zone_pdf(
            address=address,
            standard=standard,
            annex=annex,
            layer_id=layer_id,
            language=language,
        ):
            last = msg

        return None if last is None else last.pdf_result
