# GraphQL connection settings
GEO_ZONE_GRAPHQL_URL = "https://team-w.dlubal.com/api/geo-zone/pub/graphql"

# Service metadata
AUTHORIZATION_HEADER = "Authorization"
