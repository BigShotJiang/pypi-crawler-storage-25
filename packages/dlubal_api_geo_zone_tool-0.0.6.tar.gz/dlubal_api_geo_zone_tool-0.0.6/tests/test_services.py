import pytest

from dlubal.api import geo_zone_tool
from dlubal.api.geo_zone_tool import services

from tests import testdata


@pytest.mark.integration
class TestGetGeoLocations:
    @pytest.mark.parametrize("address", testdata.ADDRESS_CASES)
    def test_get_geo_locations_returns_locations(self, geo_zone_client, address):
        """Get geo locations for a given address or coordinates."""
        result = geo_zone_client.get_geo_locations(
            address=address,
            language=testdata.LANGUAGE_EN,
        )

        assert result is not None
        assert result.locations is not None
        assert len(result.locations) > 0

    def test_get_geo_locations_for_coords_returns_location_with_valid_lat_lon(
        self,
        geo_zone_client,
    ):
        """Geo locations for '52.0 13.0' should return at least one location."""
        result = geo_zone_client.get_geo_locations(
            address=testdata.COORDS_52_13,
            language=testdata.LANGUAGE_EN,
        )

        assert result is not None
        assert result.locations is not None
        assert len(result.locations) > 0

        loc = result.locations[0]

        assert getattr(loc, "display_name", "")  # non-empty-ish
        assert getattr(loc, "country", "") or getattr(loc, "country_code", "")

        lat = float(loc.latitude)
        lon = float(loc.longitude)
        assert -90.0 <= lat <= 90.0
        assert -180.0 <= lon <= 180.0


class TestGetUserData:
    def test_geo_zone_tool_empty_token_raises_value_error(self):
        with pytest.raises(ValueError, match="token must not be empty"):
            geo_zone_tool.GeoZoneTool("")

    @pytest.mark.integration
    def test_get_user_data_returns_email_and_clicks(self, geo_zone_client):
        result = geo_zone_client.get_user_data()

        assert result is not None
        assert getattr(result, "email", "")
        assert int(getattr(result, "clicks", 0)) >= 0


class TestGeoZoneTool:
    def test_geo_zone_tool_empty_token_raises_value_error(self):
        with pytest.raises(ValueError, match="token must not be empty"):
            geo_zone_tool.GeoZoneTool("")

    def test_client_get_user_data_forwards_bound_token(self, monkeypatch):
        captured = {}
        expected_data = {"getUserData": {"email": "a@b.c", "clicks": 1}}

        def fake_graphql_post(token, query, variables=None):
            captured["token"] = token
            return expected_data

        monkeypatch.setattr(
            services,
            "_graphql_post",
            fake_graphql_post,
        )

        client = geo_zone_tool.GeoZoneTool("bound-token")
        result = client.get_user_data()

        assert captured["token"] == "bound-token"
        assert getattr(result, "email", "") == "a@b.c"


@pytest.mark.integration
class TestGetLoadZoneStandards:
    def test_get_load_zone_standards_returns_types_standards_and_annexes(
        self,
        geo_zone_client,
    ):
        """Verify types -> standards -> annexes structure is present and non-empty."""
        result = geo_zone_client.get_load_zone_standards(
            country_code=testdata.COUNTRY_CODE_DE,
            language=testdata.LANGUAGE_EN,
        )

        assert result is not None
        assert result.types is not None
        assert len(result.types) > 0

        group = result.types[0]
        assert getattr(group, "name", "")
        assert group.standards is not None
        assert len(group.standards) > 0

        std_group = group.standards[0]
        assert getattr(std_group, "name", "")
        assert std_group.annexes is not None
        assert len(std_group.annexes) > 0

    def test_get_load_zone_standards_cz_it_returns_layers_with_id_and_name(
        self,
        geo_zone_client,
    ):
        """For CZ/IT we should get at least one layer with a positive id and non-empty name."""
        result = geo_zone_client.get_load_zone_standards(
            country_code=testdata.COUNTRY_CODE_CZ,
            language=testdata.LANGUAGE_IT,
        )

        assert result is not None
        assert result.types is not None
        assert len(result.types) > 0

        # Walk the nested response to find the first available layer.
        found_layer = None
        for loadzone_group in result.types:
            for std_group in loadzone_group.standards:
                for annex_group in std_group.annexes:
                    if annex_group.layers:
                        found_layer = annex_group.layers[0]
                        break
                if found_layer:
                    break
            if found_layer:
                break

        assert found_layer is not None, "Expected at least one layer in response"

        # Validate the layer has a positive id and a non-empty name.
        assert int(found_layer.id) > 0
        assert getattr(found_layer, "name", "")


@pytest.mark.integration
class TestGetLoadZoneCharacteristics:
    def test_get_load_zone_characteristics_de_returns_characteristics(
        self,
        geo_zone_client,
    ):
        """Get load zone characteristics for DE and validate key response fields."""
        result = geo_zone_client.get_load_zone_characteristics(
            address=testdata.COORDS_52_13,
            load_zone_type=testdata.LOAD_ZONE_SNOW,
            standard=testdata.STANDARD_EN_1991_1_3,
            annex=testdata.ANNEX_DIN_EN_1991_1_3,
            layer_id=testdata.LAYER_ID_1,
            language=testdata.LANGUAGE_EN,
        )

        assert result is not None
        assert result.code == "OK"
        assert result.characteristics is not None
        assert len(result.characteristics) > 0

        item = result.characteristics[0]
        assert item.standard == testdata.STANDARD_EN_1991_1_3
        assert item.annex == testdata.ANNEX_DIN_EN_1991_1_3

        zone = item.zone_characteristics
        assert zone is not None
        if hasattr(zone, "characteristics") and len(zone.characteristics) > 0:
            characteristic = zone.characteristics[0]
            assert getattr(characteristic, "calculated_value", "") or getattr(
                characteristic, "name_html", ""
            )

        geo = result.geo_location
        assert getattr(geo, "latitude", "")
        assert getattr(geo, "longitude", "")


class TestGetLoadZoneScreenshot:
    @pytest.mark.parametrize(
        "override_kwargs, expected_message",
        testdata.SCREENSHOT_INVALID_CASES,
    )
    def test_get_load_zone_screenshot_invalid_inputs_raise_value_error(
        self,
        override_kwargs,
        expected_message,
    ):
        """Client-side validation rejects invalid inputs before GraphQL is called."""
        client = geo_zone_tool.GeoZoneTool("test-token")
        base_kwargs = testdata._screenshot_invalid_base_kwargs(**override_kwargs)

        with pytest.raises(ValueError, match=expected_message):
            client.get_load_zone_screenshot(**base_kwargs)

    @pytest.mark.integration
    @pytest.mark.parametrize("extra_kwargs", testdata.SCREENSHOT_EXTRA_KWARGS)
    def test_get_load_zone_screenshot_returns_non_empty_screenshot(
        self,
        geo_zone_client,
        extra_kwargs,
    ):
        """Get load zone screenshot and ensure it returns a non-empty payload."""
        base_kwargs = testdata._screenshot_base_kwargs()
        base_kwargs.update(extra_kwargs)

        result = geo_zone_client.get_load_zone_screenshot(**base_kwargs)

        assert result is not None
        assert getattr(result, "screenshot", "")


class TestGetLoadZonePdf:
    @pytest.mark.parametrize(
        "override_kwargs, expected_message",
        testdata.PDF_INVALID_CASES,
    )
    def test_get_load_zone_pdf_invalid_inputs_raise_value_error(
        self,
        override_kwargs,
        expected_message,
    ):
        """Client-side validation rejects invalid inputs before GraphQL is called."""
        client = geo_zone_tool.GeoZoneTool("test-token")
        base_kwargs = testdata._pdf_invalid_base_kwargs(**override_kwargs)

        with pytest.raises(ValueError, match=expected_message):
            client.get_load_zone_pdf(**base_kwargs)

    @pytest.mark.integration
    def test_get_load_zone_pdf_stream_returns_progress_messages(self, geo_zone_client):
        """Consume the progress stream and ensure it yields progress messages."""
        stream = geo_zone_client.get_load_zone_pdf(**testdata._pdf_base_kwargs())

        messages = list(stream)

        assert len(messages) > 0
        first = messages[0]
        assert getattr(first, "message", "") or getattr(first, "current_step", 0) >= 0


class TestGetAsce722:
    @pytest.mark.parametrize(
        "override_kwargs, expected_message",
        testdata.ASCE722_INVALID_CASES,
    )
    def test_get_asce722_invalid_inputs_raise_error(
        self,
        override_kwargs,
        expected_message,
    ):
        """Client-side validation rejects invalid inputs before GraphQL is called."""
        client = geo_zone_tool.GeoZoneTool("test-token")
        kwargs = {
            "latitude": testdata.ASCE722_LATITUDE,
            "longitude": testdata.ASCE722_LONGITUDE,
            "risk_category": testdata.ASCE722_RISK_CATEGORY,
            "site_class": testdata.ASCE722_SITE_CLASS,
        }
        kwargs.update(override_kwargs)

        with pytest.raises((ValueError, TypeError), match=expected_message):
            client.get_asce722(**kwargs)

    def test_get_asce722_forwards_bound_token(self, monkeypatch):
        """get_asce722 uses the token bound to the client instance."""
        captured = {}
        fake_response = {
            "getAsce722": {
                "code": "OK",
                "message": None,
                "referenceDocument": None,
                "data": None,
            }
        }

        def fake_graphql_post(token, query, variables=None):  # noqa: ARG001
            captured["token"] = token
            captured["variables"] = variables
            return fake_response

        monkeypatch.setattr(services, "_graphql_post", fake_graphql_post)

        client = geo_zone_tool.GeoZoneTool("asce-token")
        result = client.get_asce722(
            latitude=testdata.ASCE722_LATITUDE,
            longitude=testdata.ASCE722_LONGITUDE,
            risk_category=testdata.ASCE722_RISK_CATEGORY,
            site_class=testdata.ASCE722_SITE_CLASS,
        )

        assert captured["token"] == "asce-token"
        assert captured["variables"]["riskCategory"] == "II"
        assert captured["variables"]["siteClass"] == "D"
        assert result.code == "OK"

    @pytest.mark.integration
    def test_get_asce722_returns_seismic_parameters(self, geo_zone_client):
        """get_asce722 returns ASCE 7-22 data with expected seismic fields."""
        result = geo_zone_client.get_asce722(
            latitude=testdata.ASCE722_LATITUDE,
            longitude=testdata.ASCE722_LONGITUDE,
            risk_category=testdata.ASCE722_RISK_CATEGORY,
            site_class=testdata.ASCE722_SITE_CLASS,
        )

        assert result is not None
        assert result.code == "success"
        assert result.data is not None

        data = result.data
        assert data.sds is not None and data.sds > 0
        assert data.sd1 is not None and data.sd1 > 0
        assert data.sdc is not None and len(data.sdc) > 0


@pytest.mark.integration
class TestGetLoadZonePdfResult:
    def test_get_load_zone_pdf_result_returns_pdf(self, geo_zone_client):
        """Return final PDF result from the progress stream."""
        result = geo_zone_client.get_load_zone_pdf_result(
            **testdata._pdf_base_kwargs()
        )

        assert result is not None
        assert getattr(result, "pdf", "")
        assert getattr(result, "name", "")
