"""Central test data and small helpers used by multiple test modules.

Keep hardcoded values and request-building defaults here so test modules stay
focused on behavior. This avoids importing conftest.py for data (pytest
side-effects) and makes it obvious where to update values.
"""

from dataclasses import dataclass, replace
from typing import Any

import pytest

from dlubal.api import geo_zone_tool

# Base inputs and defaults.
ADDRESS_DE_FLUGPLATZWEG_6 = "Flugplatzweg 6, 14913, Germany"
COORDS_52_13 = "52.0 13.0"
COUNTRY_CODE_DE = "de"
COUNTRY_CODE_CZ = "cz"
LANGUAGE_EN = geo_zone_tool.Language.EN
LANGUAGE_IT = geo_zone_tool.Language.IT
STANDARD_EN_1991_1_3 = "EN 1991-1-3"
ANNEX_DIN_EN_1991_1_3 = "DIN EN 1991-1-3"
LAYER_ID_1 = 1
ZOOM_6 = 6
LOAD_ZONE_SNOW = geo_zone_tool.LoadZoneType.SNOW

# ASCE 7-22 test inputs (San Francisco, CA - seismically active US location).
ASCE722_LATITUDE = 37.7749
ASCE722_LONGITUDE = -122.4194
ASCE722_RISK_CATEGORY = geo_zone_tool.RiskCategory.II
ASCE722_SITE_CLASS = geo_zone_tool.SiteClass.D

ASCE722_INVALID_CASES = [
    pytest.param(
        {"latitude": 91.0},
        "latitude must be between -90 and 90",
        id="latitude-out-of-range",
    ),
    pytest.param(
        {"longitude": 181.0},
        "longitude must be between -180 and 180",
        id="longitude-out-of-range",
    ),
    pytest.param(
        {"risk_category": "II"},
        "risk_category must be RiskCategory",
        id="risk-category-wrong-type",
    ),
    pytest.param(
        {"site_class": "D"},
        "site_class must be SiteClass",
        id="site-class-wrong-type",
    ),
]

# Parametrize cases.
ADDRESS_CASES = [
    pytest.param(ADDRESS_DE_FLUGPLATZWEG_6, id="address"),
    pytest.param(COORDS_52_13, id="coords-52-13"),
]

SCREENSHOT_INVALID_CASES = [
    pytest.param({"annex": ""}, "annex must not be empty", id="empty-annex"),
    pytest.param({"zoom": -1}, "zoom must be >= 0", id="invalid-zoom"),
]

SCREENSHOT_EXTRA_KWARGS = [
    pytest.param(
        {"load_zone_type": geo_zone_tool.LoadZoneType.EARTHQUAKE},
        id="default",
    ),
    pytest.param(
        {
            "load_zone_type": geo_zone_tool.LoadZoneType.SNOW,
            "screenshot_type": geo_zone_tool.ScreenshotType.JPEG,
            "screenshot_quality": 80,
        },
        id="jpeg-quality",
    ),
]

PDF_INVALID_CASES = [
    pytest.param(
        {"standard": ""},
        "standard must not be empty",
        id="empty-standard",
    ),
    pytest.param(
        {"layer_id": -1},
        "layer_id must be >= 0",
        id="invalid-layer",
    ),
]


@dataclass(frozen=True)
class LoadZoneRequestArgs:
    address: str
    standard: str = STANDARD_EN_1991_1_3
    annex: str = ANNEX_DIN_EN_1991_1_3
    layer_id: int = LAYER_ID_1
    language: geo_zone_tool.Language = LANGUAGE_EN
    zoom: int | None = None
    load_zone_type: geo_zone_tool.LoadZoneType | None = None

    def with_overrides(self, **overrides: Any) -> "LoadZoneRequestArgs":
        """Note: overrides must match LoadZoneRequestArgs fields or raise TypeError."""
        return replace(self, **overrides)

    def as_kwargs(self) -> dict:
        """Return kwargs for services.* calls, omitting fields set to None."""
        kwargs = {
            "address": self.address,
            "standard": self.standard,
            "annex": self.annex,
            "layer_id": self.layer_id,
            "language": self.language,
        }
        if self.zoom is not None:
            kwargs["zoom"] = self.zoom
        if self.load_zone_type is not None:
            kwargs["load_zone_type"] = self.load_zone_type
        return kwargs


def _screenshot_base_kwargs() -> dict:
    return LoadZoneRequestArgs(
        address=ADDRESS_DE_FLUGPLATZWEG_6,
        zoom=ZOOM_6,
    ).as_kwargs()


def _screenshot_invalid_base_kwargs(**overrides: Any) -> dict:
    return LoadZoneRequestArgs(
        address=COORDS_52_13,
        load_zone_type=LOAD_ZONE_SNOW,
        zoom=ZOOM_6,
    ).with_overrides(**overrides).as_kwargs()


def _pdf_base_kwargs() -> dict:
    return LoadZoneRequestArgs(
        address=ADDRESS_DE_FLUGPLATZWEG_6,
    ).as_kwargs()


def _pdf_invalid_base_kwargs(**overrides: Any) -> dict:
    return LoadZoneRequestArgs(
        address=COORDS_52_13,
    ).with_overrides(**overrides).as_kwargs()
