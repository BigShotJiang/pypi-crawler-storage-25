import random
from dataclasses import dataclass
from typing import Optional, Sequence

from typing_extensions import TypeVar

from marlenv.models import Space

from .rlenv_wrapper import MARLEnv, RLEnvWrapper

ActionSpaceType = TypeVar("ActionSpaceType", bound=Space, default=Space)


@dataclass
class EnvPool(RLEnvWrapper[ActionSpaceType]):
    envs: Sequence[MARLEnv[ActionSpaceType]]

    def __init__(self, envs: Sequence[MARLEnv[ActionSpaceType]]):
        assert len(envs) > 0, "EnvPool must contain at least one environment"
        self.envs = envs
        for env in envs[1:]:
            assert env.has_same_inouts(self.envs[0]), "All environments must have the same inputs and outputs"
        super().__init__(self.envs[0])

    def seed(self, seed_value: int):
        random.seed(seed_value)
        for env in self.envs:
            env.seed(seed_value)

    def reset(self, *, seed: Optional[int] = None):
        self.wrapped = random.choice(self.envs)
        return super().reset()
