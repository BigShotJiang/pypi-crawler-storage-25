cdef class ScoringOracle:

    pass