# Field Attributes

フィールド属性は、データクラスのフィールドの（デ）シリアライズ動作をカスタマイズするためのオプションです。ワイヤ形式の調整や、特定のフィールドだけ特別扱いしたい場合に使います。

## dataclassesによって提供される属性

### **`default`** と **`default_factory`**

dataclassesの `default` と `default_factory` は期待通りに動作します。  
フィールドが `default` または `default_factory` 属性を持つ場合、そのフィールドはオプショナルフィールドのように振る舞います。  
フィールドがデータ内に存在する場合、当該フィールドの値がデシリアライズされたオブジェクトに設定されます。  
フィールドがデータ内に存在しない場合、指定されたデフォルト値がデシリアライズされたオブジェクトに設定されます。

```python
class Foo:
    a: int = 10
    b: int = field(default=10)  # field "a"と同じ
    c: dict[str, int] = field(default_factory=dict)

print(from_dict(Foo, {}))  # Foo(a=10, b=10, c={}) を出力
```

完全な例については、[examples/default.py](https://github.com/yukinarit/pyserde/blob/main/examples/default.py)を参照してください。

### **`ClassVar`**

`dataclasses.ClassVar` はデータクラスのクラス変数であり、dataclassはClassVarを擬似的なフィールドとして扱います。  
`dataclasses.field` はクラス変数を含まないため、pyserdeはデフォルトの動作として `ClassVar` フィールドを（デ）シリアライズしません。  
ClassVarフィールドをシリアライズする場合は、[serialize_class_var](class-attributes.md#serialize_class_var)クラス属性の使用を検討してください。

完全な例については、[examples/class_var.py](https://github.com/yukinarit/pyserde/blob/main/examples/class_var.py)を参照してください。

## pyserdeによって提供される属性

フィールド属性は `serde.field` または `dataclasses.field` を通じて指定することができます。  
型チェックが機能するため、 `serde.field` の使用を推奨します。

以下は、`rename` 属性を `serde.field` と `dataclasses.field` の両方で指定する例です。

```python
@serde.serde
class Foo:
    a: str = serde.field(rename="A")
    b: str = dataclasses.field(metadata={"serde_rename": "B"})
```

### **`rename`**

`rename` は（デ）シリアライズ中にフィールド名を変更するために使用されます。  
この属性は、フィールド名にPythonのキーワード（予約語）を使用したい場合に便利です。

以下のコードはフィールド名 `id` を `ID` に変更する例です。

```python
@serde
class Foo:
    id: int = field(rename="ID")
```

完全な例については、[examples/rename.py](https://github.com/yukinarit/pyserde/blob/main/examples/rename.py)を参照してください。

### **`skip`**

`skip` はこの属性を持つフィールドの（デ）シリアライズをスキップします。

```python
@serde
class Resource:
    name: str
    hash: str
    metadata: dict[str, str] = field(default_factory=dict, skip=True)
```

完全な例については、[examples/skip.py](https://github.com/yukinarit/pyserde/blob/main/examples/skip.py)を参照してください。

### **`skip_serializing`**

`skip_serializing` はシリアライズ時のみフィールドを省きます。入力では通常通り受け取ります。

```python
@serde
class Credentials:
    user: str
    token: str = field(skip_serializing=True)
```

完全な例については、[examples/skip_serializing_deserializing.py](https://github.com/yukinarit/pyserde/blob/main/examples/skip_serializing_deserializing.py)を参照してください。

### **`skip_deserializing`**

`skip_deserializing` はデシリアライズ時に入力値を無視し、デフォルト（または default_factory）の値を保持します。`__init__` に含まれるフィールドではデフォルトが必須です。

```python
@serde
class Profile:
    username: str
    session_id: str = field(default="generated", skip_deserializing=True)
```

完全な例については、[examples/skip_serializing_deserializing.py](https://github.com/yukinarit/pyserde/blob/main/examples/skip_serializing_deserializing.py)を参照してください。

### **`skip_if`**

`skip_if` は条件関数が `True` を返す場合にフィールドの（デ）シリアライズをスキップします。

```python
@serde
class World:
    buddy: str = field(default='', skip_if=lambda v: v == 'Pikachu')
```

完全な例については、[examples/skip.py](https://github.com/yukinarit/pyserde/blob/main/examples/skip.py)を参照してください。

!!! note
    `skip`、`skip_if`、`skip_if_false`、`skip_if_none`、`skip_if_default` はシリアライズ/デシリアライズの両方に適用されます。方向ごとに制御したい場合は `skip_serializing` / `skip_deserializing` を使用してください。

### **`skip_if_false`**

`skip_if_false` はフィールドが `False` と評価される場合にフィールドの（デ）シリアライズをスキップします。

例えば、以下のコードは `enemies` が空であれば（デ）シリアライズをスキップします。

```python
@serde
class World:
    enemies: list[str] = field(default_factory=list, skip_if_false=True)
```

完全な例については、[examples/skip.py](https://github.com/yukinarit/pyserde/blob/main/examples/skip.py)を参照してください。

### **`skip_if_none`**

`skip_if_none` は値が `None` のときにそのフィールドの（デ）シリアライズをスキップします。

```python
@serde
class Profile:
    nickname: str | None = field(default=None, skip_if_none=True)
```

クラス全体に適用する方法は [クラス属性: skip_if_none](class-attributes.md#skip_if_none) を参照してください。
実行例は [examples/skip_if_none.py](https://github.com/yukinarit/pyserde/blob/main/examples/skip_if_none.py) を参照してください。

### **`skip_if_default`**

`skip_if_default` はフィールドがデフォルト値とイコールである場合にフィールドの（デ）シリアライズをスキップします。

例えば、以下のコードは `town` が `Masara Town` であれば（デ）シリアライズをスキップします。

```python
@serde
class World:
    town: str = field(default='Masara Town', skip_if_default=True)
```

クラス全体に一括で適用することもできます。

```python
@serde(skip_if_default=True)
class Settings:
    theme: str = \"light\"
    retries: int = 3
```

クラスで有効にしても、フィールド側で `skip_if_default=False` と設定すればそのフィールドは保持されます。

クラス全体に適用する設定については [クラス属性: skip_if_default](class-attributes.md#skip_if_default) を参照してください。完全な例は [examples/skip.py](https://github.com/yukinarit/pyserde/blob/main/examples/skip.py) と [examples/skip_if_default_class.py](https://github.com/yukinarit/pyserde/blob/main/examples/skip_if_default_class.py) にあります。

### **`alias`**

フィールド名に別名を設定できます。エイリアスはデシリアライズ時にのみ機能します。

```python
@serde
class Foo:
    a: str = field(alias=["b", "c"])
```

上記の例では、 `Foo` は `{"a": "..."}` , `{"b": "..."}` 、または `{"c": "..."}` のいずれかからデシリアライズできます。

完全な例については、[examples/alias.py](https://github.com/yukinarit/pyserde/blob/main/examples/alias.py)を参照してください。

## **`serializer`** と **`deserializer`**

特定のフィールドに対してカスタム（デ）シリアライザを使用したい場合があります。

例えば、以下のようなケースです。
* datetimeを異なる形式でシリアライズしたい。
* サードパーティパッケージの型をシリアライズしたい。

以下の例では、フィールド `a` はデフォルトのシリアライザで `"2021-01-01T00:00:00"` にシリアライズされますが、フィールド `b` はカスタムシリアライザで `"01/01/21"` にシリアライズされます。

```python
@serde
class Foo:
    a: datetime
    b: datetime = field(serializer=lambda x: x.strftime('%d/%m/%y'), deserializer=lambda x: datetime.strptime(x, '%d/%m/%y'))
```

完全な例については、[examples/custom_field_serializer.py](https://github.com/yukinarit/pyserde/blob/main/examples/custom_field_serializer.py)を参照してください。

## **`flatten`**

`flatten` 属性は2つの方法で使用できます。

### ネストされたdataclassのフラット化

ネストされたdataclass構造のフィールドをフラットにできます。

```python
@serde
class Bar:
    c: float
    d: bool

@serde
class Foo:
    a: int
    b: str
    bar: Bar = field(flatten=True)
```

上記の例では、`Bar` の `c` および `d` フィールドが `Foo` で定義されているかのようにデシリアライズされます。
`Foo` をJSON形式にシリアライズすると `{"a":10,"b":"foo","c":100.0,"d":true}` を取得します。

完全な例については、[examples/flatten.py](https://github.com/yukinarit/pyserde/blob/main/examples/flatten.py)を参照してください。

### dictで追加フィールドをキャプチャ

`dict[str, Any]` または `dict` と `flatten=True` を使用して、デシリアライズ時にすべての未知/追加フィールドをキャプチャできます。Rust serdeの `HashMap<String, Value>` に対する `#[serde(flatten)]` と同様の機能です。

```python
@serde
class User:
    id: int
    name: str
    extra: dict[str, Any] = field(flatten=True, default_factory=dict)

# デシリアライズ - 追加フィールドがキャプチャされる
user = from_json(User, '{"id": 1, "name": "Alice", "role": "admin", "active": true}')
# user.extra == {"role": "admin", "active": True}

# シリアライズ - 追加フィールドがマージされる
user2 = User(id=2, name="Bob", extra={"department": "Engineering"})
to_json(user2)  # '{"id": 2, "name": "Bob", "department": "Engineering"}'
```

**主な機能:**
- デシリアライズ時、宣言されたフィールドに一致しないフィールドがdictにキャプチャされます
- シリアライズ時、dictの内容が出力にマージされます（宣言されたフィールドが優先されます）
- すべてのデータ形式（JSON、YAML、TOML、MessagePackなど）で動作します
- フラット化されたdataclassフィールドと組み合わせることができます

完全な例については、[examples/flatten_dict.py](https://github.com/yukinarit/pyserde/blob/main/examples/flatten_dict.py)を参照してください。
