from __future__ import annotations

import json
from pathlib import Path

# Project configs are read from/written to the main tool's config file
PROJECT_CONFIG = Path.home() / ".link-project-to-chat" / "config.json"


def _load_json(path: Path) -> dict:
    if path.exists():
        try:
            return json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def load_project_configs(path: Path = PROJECT_CONFIG) -> dict[str, dict]:
    return _load_json(path).get("projects", {})


def save_project_configs(projects: dict[str, dict], path: Path = PROJECT_CONFIG) -> None:
    existing = _load_json(path)
    existing["projects"] = projects
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(existing, indent=2) + "\n")
    path.chmod(0o600)


def set_project_autostart(project_name: str, value: bool, path: Path = PROJECT_CONFIG) -> None:
    existing = _load_json(path)
    existing.setdefault("projects", {}).setdefault(project_name, {})["autostart"] = value
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(existing, indent=2) + "\n")
    path.chmod(0o600)
