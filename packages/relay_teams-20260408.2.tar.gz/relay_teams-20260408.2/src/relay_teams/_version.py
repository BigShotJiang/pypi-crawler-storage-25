# -*- coding: utf-8 -*-
from __future__ import annotations

__all__ = ["__version__"]

__version__ = "20260408.2"

