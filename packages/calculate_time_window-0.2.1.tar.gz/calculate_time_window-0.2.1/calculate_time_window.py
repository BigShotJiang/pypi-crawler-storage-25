import json
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional, Union


class CalculateTimeWindow:
	start_weeks_ago: int
	end_weeks_ago: int
	start_days_ago: int
	end_days_ago: int
	start_hours_ago: int
	end_hours_ago: int
	start_minutes_ago: int
	end_minutes_ago: int
	start_seconds: int
	end_seconds: int
	start_milliseconds: int
	end_milliseconds: int
	start_microseconds: int
	end_microseconds: int
	expires_in: int
	expires_only: bool
	now: datetime

	def __init__(self,
				start_weeks_ago: Optional[int] = 0,
				end_weeks_ago: Optional[int] = 0,
				start_days_ago: Optional[int] = 0,
				end_days_ago: Optional[int] = 0,
				start_hours_ago: Optional[int] = 0,
				end_hours_ago: Optional[int] = 0,
				start_minutes_ago: Optional[int] = 0,
				end_minutes_ago: Optional[int] = 0,
				start_seconds: Optional[int] = 0,
				end_seconds: Optional[int] = 59,
				start_milliseconds: Optional[int] = 0,
				end_milliseconds: Optional[int] = 999,
				start_microseconds: Optional[int] = 0,
				end_microseconds: Optional[int] = 999999,
				expires_in: Optional[int] = 0,
				expires_only: Optional[bool] = False,
				now: Optional[datetime] = None
				) -> None:
		"""Create the lookback window. "Now" is calculated at instance creation, or if provided.

		Creates start and end timestamps in multiple formats. Provide start "minutes ago",
		ending "minutes ago" (0 for "now"), and seconds for each as part of the respective
		starting or ending minute. Providing "5 minutes ago, 5 seconds" will be 5 minutes
		ago, 5 seconds into that minute. Defaults: 59 ending seconds, 999 ending millisecond,
		and 999999 ending microseconds.

		Args:
			int: start_weeks_ago - x weeks "ago", the relative early time passed to timedelta()
			int: end_weeks_ago - x weeks "ago" or 0 for now; relative late time passed to timedelta()
			int: start_days_ago - x days "ago", the relative early time passed to timedelta()
			int: end_days_ago - x days "ago" or 0 for now; relative late time passed to timedelta()
			int: start_hours_ago - x hours "ago", the relative early time passed to timedelta()
			int: end_hours_ago - x hours "ago" or 0 for now; relative late time passed to timedelta()
			int: start_minutes_ago - x minutes "ago", the relative early time passed to timedelta()
			int: end_minutes_ago - x minutes "ago" or 0 for now; relative late time passed to timedelta()
			int: start_seconds - the exact seconds within the start minute; not passed to timedelta()
			int: end_seconds - the exact seconds within the end minute; not passed to timedelta()
			int: start_milliseconds - the exact milliseconds within the start minute; not passed to timedelta()
			int: end_milliseconds - the exact milliseconds within the end minute; not passed to timedelta()
			int: start_microseconds - the exact microseconds within the start minute; not passed to timedelta()
			int: end_microseconds - the exact microseconds within the end minute; not passed to timedelta()
			int: expires_in - number of seconds to calculate until something expires
			bool: expires_only - True to only include "exp" values; default False
			datetime: now - a datetime.datetime() object, for defining your own "now" timestamp

		Returns a dictionary of various UTC timestamps, for now, start, and end.
			str: x_iso - ISO8601 using the datetime.isoformat()
			str: x_ms - "year-month-day hour:min:second.x" with up to 3 digits of precision (millisecond)
			str: x_tms - "year-month-dayThour:min:second.x" with up to 3 digits of precision (millisecond)
			str: x_us - "year-month-day hour:min:second.x" with up to 6 digits of precision (microsecond)
			str: x_tus - "year-month-dayThour:min:second.x" with up to 6 digits of precision (microsecond)
			float: x_epoch - epoch with up to 6 digits of precision (microsecond)
			int: x_epochint - epoch as integer (no microseconds)
			int: x_epochms - epoch as integer in milliseconds (x_epochint * 1000)
		"""
		self.start_weeks_ago = start_weeks_ago
		self.end_weeks_ago = end_weeks_ago
		self.start_days_ago = start_days_ago
		self.end_days_ago = end_days_ago
		self.start_hours_ago = start_hours_ago
		self.end_hours_ago = end_hours_ago
		self.start_minutes_ago = start_minutes_ago
		self.end_minutes_ago = end_minutes_ago
		self.start_seconds = start_seconds
		self.end_seconds = end_seconds
		self.start_microseconds = start_microseconds
		self.end_microseconds = end_microseconds
		self.expires_in = expires_in
		self.expires_only = expires_only
		self.now = now if now is not None else datetime.now(timezone.utc)

	def calculate(self):
		"""Calculate the time window. Returns a dictionary of now, start, and end timestamps, and optional expires (exp) timestamps."""

		now: datetime = self.now
		s: datetime = now - timedelta(
				weeks = int(self.start_weeks_ago),
				days = int(self.start_days_ago),
				hours = int(self.start_hours_ago),
				minutes = int(self.start_minutes_ago)
			)
		e: datetime = now - timedelta(
				weeks = int(self.end_weeks_ago),
				days = int(self.end_days_ago),
				hours = int(self.end_hours_ago),
				minutes = int(self.end_minutes_ago)
			)

		# seconds are not set using timedelta(), but are specifically what the user provides
		s: datetime = s.replace(second = self.start_seconds, microsecond = self.start_microseconds)
		e: datetime = e.replace(second = self.end_seconds, microsecond = self.end_microseconds)

		out: Dict[str, Union[str, float, int]] = {
			"now_iso": now.isoformat(),
			"now_ms": now.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3],
			"now_us": now.strftime('%Y-%m-%d %H:%M:%S.%f'),
			"now_tms": now.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3],
			"now_tus": now.strftime('%Y-%m-%dT%H:%M:%S.%f'),
			"now_epoch": now.timestamp(),
			"now_epochint": int(now.timestamp()),
			"now_epochms": int(now.timestamp()*1000),
			"start_iso": s.isoformat(),
			"end_iso": e.isoformat(),
			"start_ms": s.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3],
			"end_ms": e.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3],
			"start_us": s.strftime('%Y-%m-%d %H:%M:%S.%f'),
			"end_us": e.strftime('%Y-%m-%d %H:%M:%S.%f'),
			"start_tms": s.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3],
			"end_tms": e.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3],
			"start_tus": s.strftime('%Y-%m-%dT%H:%M:%S.%f'),
			"end_tus": e.strftime('%Y-%m-%dT%H:%M:%S.%f'),
			"start_epoch": s.timestamp(),
			"end_epoch": e.timestamp(),
			"start_epochint": int(s.timestamp()),
			"end_epochint": int(e.timestamp()),
			"start_epochms": int(s.timestamp()*1000),
			"end_epochms": int(e.timestamp()*1000),
		}
		if self.expires_in > 0:
			exp = now + timedelta(seconds=int(self.expires_in))
			out["exp_iso"] = exp.isoformat()
			out["exp_ms"] = exp.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
			out["exp_us"] = exp.strftime('%Y-%m-%d %H:%M:%S.%f')
			out["exp_tms"] = exp.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
			out["exp_tus"] = exp.strftime('%Y-%m-%dT%H:%M:%S.%f')
			out["exp_epoch"] = exp.timestamp()
			out["exp_epochint"] = int(exp.timestamp())
			out["exp_epochms"] = int(exp.timestamp()*1000)
		# keep only expiration data
		if self.expires_only:
			out = {k: v for k, v in out.items() if k.startswith("exp")}
		return out


if __name__ == "__main__":

	print(" start 5 minutes go, until now ".center(60, "-"))
	calc1 = CalculateTimeWindow(start_minutes_ago=5)
	print(json.dumps(calc1.calculate(), indent=4))

	print(" minutes, seconds ".center(60, "-"))
	calc2 = CalculateTimeWindow(start_minutes_ago=3, end_minutes_ago=1, start_seconds=7, end_seconds=13)
	print(json.dumps(calc2.calculate(), indent=4))

	print(" weeks, days, hours, minutes, seconds ".center(60, "-"))
	calc3 = CalculateTimeWindow(start_weeks_ago=2, start_days_ago=1, start_hours_ago=2, start_minutes_ago=3, end_weeks_ago=1, end_days_ago=2, end_hours_ago=3, end_minutes_ago=1, start_seconds=7, end_seconds=13)
	print(json.dumps(calc3.calculate(), indent=4))

	print(" expires in 600 seconds ".center(60, "-"))
	calc4 = CalculateTimeWindow(expires_in=600)
	print(json.dumps(calc4.calculate(), indent=4))

	print(" expires in 600 seconds, expires_only=True ".center(60, "-"))
	calc5 = CalculateTimeWindow(expires_in=600, expires_only=True)
	print(json.dumps(calc5.calculate(), indent=4))

	print(' with "now" set one day in the past '.center(60, "-"))
	past_time = datetime.now() - timedelta(days=1)
	calc6 = CalculateTimeWindow(start_minutes_ago=3, now=past_time)
	print(f"{past_time=}")
	print(json.dumps(calc6.calculate(), indent=4))

	print(" minutes only ".center(60, "-"))
	calc7 = CalculateTimeWindow(start_minutes_ago=3, end_minutes_ago=1)
	print(json.dumps(calc7.calculate(), indent=4))
