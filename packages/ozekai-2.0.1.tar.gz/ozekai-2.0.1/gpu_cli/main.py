import os
import click
import requests
from .commands.connect import connect_command
from .commands.disconnect import disconnect_command
from .commands.upload import upload_command
from .config import API_URL

# ── User-facing standalone entry points ─────────────────────────

@click.command()
@click.option("--name", required=True, help="VM name (e.g. 'training', 'inference')")
@click.option("--plan", "plan_id", required=True, type=click.Choice(["l40", "a100", "h100"], case_sensitive=False), help="GPU plan")
def connect_gpu(name, plan_id):
    """Connect to your GPU container"""
    connect_command(vm_name=name, plan_id=plan_id)

@click.command()
@click.option("--terminate", is_flag=True, help="Destroy VM and all data (stops all billing)")
@click.option("--name", required=True, help="VM name")
def disconnect_gpu(terminate, name):
    """Stop your GPU session (VM hibernates, storage billing continues)"""
    disconnect_command(terminate=terminate, vm_name=name)

@click.command()
def list_gpus():
    """List all your GPU VMs"""
    username = click.prompt("Username (or email)")
    password = click.prompt("Password", hide_input=True)
    try:
        resp = requests.post(
            f"{API_URL}/api/auth/login",
            json={"username": username, "password": password},
            timeout=10,
        )
    except requests.ConnectionError:
        click.echo(f"Error: cannot reach API at {API_URL}", err=True)
        raise SystemExit(1)
    if resp.status_code == 401:
        click.echo("Authentication failed", err=True)
        raise SystemExit(1)
    if not resp.ok:
        click.echo("Error: could not authenticate.", err=True)
        raise SystemExit(1)
    token = resp.json()["access_token"]
    try:
        resp = requests.get(
            f"{API_URL}/api/auth/me/vms",
            headers={"Authorization": f"Bearer {token}"},
            timeout=15,
        )
    except requests.ConnectionError:
        click.echo("Error: lost connection to API", err=True)
        raise SystemExit(1)
    if not resp.ok:
        click.echo("Error: could not list VMs.", err=True)
        raise SystemExit(1)
    vms = resp.json().get("vms", [])
    if not vms:
        click.echo("No GPU VMs found.")
        return
    click.echo(f"{'Name':<20} {'Status':<15} {'GPU Host':<25} {'Port':<8}")
    click.echo("-" * 68)
    for vm in vms:
        click.echo(f"{vm.get('vm_name','?'):<20} {vm.get('status','?'):<15} {vm.get('gpu_host','—'):<25} {vm.get('host_port','—'):<8}")

@click.command()
@click.option("--name", required=True, help="VM name")
@click.argument("args", nargs=-1, required=True)
def upload_gpu(name, args):
    """Upload files to your GPU container.

    \b
    Usage (scp-like):
      upload-gpu --name training file.py                  → /workspace/file.py
      upload-gpu --name training file.py models/          → /workspace/models/file.py
      upload-gpu --name training *.py src/ models/        → /workspace/models/{files}
    """
    if len(args) >= 2 and not os.path.exists(args[-1]):
        sources, dest = args[:-1], args[-1]
    else:
        sources, dest = args, ""
    upload_command(sources, dest, vm_name=name)
