import os

API_URL = os.getenv("OZEKAI_API_URL", "https://ozekai.com")
SSH_USER = os.getenv("OZEKAI_SSH_USER", os.getenv("USER", "gpu"))
