"""Client-side disconnect-gpu command."""

import click
import requests
from ..config import API_URL


def disconnect_command(terminate: bool = False, vm_name: str = "default"):
    username = click.prompt("Username (or email)")
    password = click.prompt("Password", hide_input=True)

    # Step 1: Login to get JWT
    try:
        resp = requests.post(
            f"{API_URL}/api/auth/login",
            json={"username": username, "password": password},
            timeout=10,
        )
    except requests.ConnectionError:
        click.echo(f"Error: cannot reach API at {API_URL}", err=True)
        raise SystemExit(1)

    if resp.status_code == 401:
        click.echo("Authentication failed", err=True)
        raise SystemExit(1)
    if not resp.ok:
        click.echo("Error: could not disconnect. Please try again later.", err=True)
        raise SystemExit(1)

    token = resp.json()["access_token"]

    # Step 2: Stop or terminate
    if terminate:
        if not click.confirm("This will DESTROY your VM and all data. Continue?"):
            raise SystemExit(0)
        endpoint = f"{API_URL}/api/auth/me/terminate"
    else:
        endpoint = f"{API_URL}/api/auth/me/stop-session"

    try:
        resp = requests.post(
            endpoint,
            headers={"Authorization": f"Bearer {token}"},
            params={"vm_name": vm_name},
            timeout=30,
        )
    except requests.ConnectionError:
        click.echo("Error: lost connection to API", err=True)
        raise SystemExit(1)

    if not resp.ok:
        click.echo("Error: could not stop session. Please try again later.", err=True)
        raise SystemExit(1)

    data = resp.json()
    status = data.get("status", "unknown")

    if status == "stopped":
        secs = data.get("total_seconds", 0)
        click.echo(f"Session stopped (VM hibernated). Usage: {secs} seconds.")
        click.echo("Storage billing continues. Use --terminate to destroy the VM.")
    elif status == "terminated":
        secs = data.get("total_seconds", 0)
        click.echo(f"VM destroyed. Final usage: {secs} seconds.")
    else:
        click.echo("No active session found.")
