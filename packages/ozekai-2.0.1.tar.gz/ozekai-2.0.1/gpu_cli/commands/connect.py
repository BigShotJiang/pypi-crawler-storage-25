"""Client-side connect-gpu command."""

import os
import shlex
import signal
import socket
import subprocess
import sys
import time
import click
import requests
from ..config import API_URL, SSH_USER


def _find_free_port(start, count):
    """Return the first local port where `count` consecutive ports are all free."""
    port = start
    while port < 65536 - count:
        if all(_port_free(port + i) for i in range(count)):
            return port
        port += 1
    return start  # fallback


def _port_free(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def _poll_vm_ready(token: str, vm_name: str = "default", timeout: int = 600, interval: int = 8) -> dict:
    """Poll /api/auth/me/vm-status until VM is ready or timeout."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            resp = requests.get(
                f"{API_URL}/api/auth/me/vm-status",
                headers={"Authorization": f"Bearer {token}"},
                params={"vm_name": vm_name},
                timeout=30,
            )
            if resp.ok:
                data = resp.json()
                if data.get("status") == "ready":
                    return data
                if data.get("status") == "terminated":
                    click.echo("\nError: VM was terminated.", err=True)
                    raise SystemExit(1)
        except (requests.ConnectionError, requests.Timeout):
            pass
        click.echo(".", nl=False)
        time.sleep(interval)
    click.echo()
    click.echo("Error: VM provisioning timed out. Please try again later.", err=True)
    raise SystemExit(1)


def _ensure_local_container(container_id, gpu_image, workspace_dir, host_port, display_plan):
    """Ensure a local Docker container exists and is running. Create if needed."""
    os.makedirs(workspace_dir, exist_ok=True)

    ret = subprocess.run(
        ["docker", "inspect", container_id],
        capture_output=True,
    )
    if ret.returncode != 0:
        click.echo(f"Creating local GPU container ({gpu_image})...")
        run_args = [
            "docker", "run", "-d",
            "--name", container_id,
            "--gpus", "all",
            "--restart", "unless-stopped",
            "-p", f"{host_port}:8888",
            "-v", f"{workspace_dir}:/workspace",
            "-e", f"GPU_PLAN_ID={shlex.quote(display_plan)}",
            "--user", "gpuuser",
            "--security-opt", "no-new-privileges:true",
            "--cap-drop", "ALL",
            "--cap-add", "SYS_PTRACE",
            "--cap-add", "CHOWN",
            "--pids-limit", "512",
            "--tmpfs", "/tmp:size=2g,noexec,nosuid,nodev",
            gpu_image,
            "sleep", "infinity",
        ]
        ret = subprocess.run(run_args, capture_output=True, text=True)
        if ret.returncode != 0:
            # Retry without --gpus if no NVIDIA runtime
            run_args = [a for a in run_args if a != "--gpus" and a != "all"]
            ret = subprocess.run(run_args, capture_output=True, text=True)
            if ret.returncode != 0:
                click.echo(f"Error creating container: {ret.stderr.strip()}", err=True)
                raise SystemExit(1)
        # Fix workspace ownership
        subprocess.run(
            ["docker", "exec", "-u", "root", container_id, "chown", "1000:1000", "/workspace"],
            capture_output=True,
        )
    else:
        # Container exists but may be stopped — start it
        subprocess.run(["docker", "start", container_id], capture_output=True)


def connect_command(vm_name: str = "default", plan_id: str = None):
    username = click.prompt("Username (or email)")
    password = click.prompt("Password", hide_input=True)

    # ── Step 1: Authenticate & provision ──
    click.echo(f"Authenticating as {username}...")
    try:
        params = {"vm_name": vm_name}
        if plan_id:
            params["plan_id"] = plan_id
        resp = requests.post(
            f"{API_URL}/api/auth/connect",
            json={"username": username, "password": password},
            params=params,
            timeout=30,
        )
    except requests.ConnectionError:
        click.echo(f"Error: cannot reach API at {API_URL}", err=True)
        raise SystemExit(1)

    if resp.status_code == 401:
        click.echo("Authentication failed: invalid username/email or password", err=True)
        raise SystemExit(1)
    if not resp.ok:
        click.echo("Error: could not connect. Please try again later.", err=True)
        raise SystemExit(1)

    data = resp.json()
    actual_username = data.get("username", username)
    plan_id = data.get("plan_id", "gpu")
    status = data.get("status", "ready")

    # ── Step 2: If VM is provisioning, get a token and poll ──
    if status in ("provisioning", "restoring"):
        click.echo("GPU VM is starting up. This may take a few minutes...")

        # Get JWT for polling
        login_resp = requests.post(
            f"{API_URL}/api/auth/login",
            json={"username": username, "password": password},
            timeout=10,
        )
        if not login_resp.ok:
            click.echo("Error: could not authenticate for status polling.", err=True)
            raise SystemExit(1)
        token = login_resp.json()["access_token"]

        data = _poll_vm_ready(token, vm_name=vm_name)
        click.echo(" Ready!")

    container_id = data.get("session_id") or data.get("container_id") or f"user-{actual_username}"
    gpu_host = data.get("gpu_host")
    host_port = data.get("host_port", 8888)
    jupyter_port_count = data.get("port_count", 5)
    gpu_image = data.get("gpu_image", os.getenv("GPU_IMAGE", "gpu-base"))

    if not gpu_host:
        click.echo("Error: no GPU host available.", err=True)
        raise SystemExit(1)

    click.echo("Session ready.")
    display_plan = (plan_id or "gpu").strip() or "gpu"
    prompt = f"{vm_name}@{display_plan}:\\w$ "

    # ── Local dev GPU — docker exec directly, no SSH ──
    if gpu_host == "localhost":
        # Per-VM workspace: each container gets its own /workspace
        workspace_dir = os.path.join(
            os.getenv("WORKSPACE_BASE_DIR", "/tmp/gpu-workspaces"),
            actual_username, vm_name,
        )
        _ensure_local_container(container_id, gpu_image, workspace_dir, host_port, display_plan)

        local_base = _find_free_port(8888, jupyter_port_count)
        click.echo(f"Jupyter: http://localhost:{local_base}")
        click.echo("Connecting... (type 'exit' to disconnect)")

        try:
            ret = subprocess.call([
                "docker", "exec", "-it",
                "-e", f"GPU_PLAN_ID={display_plan}",
                "-e", f"PS1={prompt}",
                "-w", "/workspace",
                container_id,
                "/bin/bash", "--noprofile", "--norc", "-i",
            ])
        except KeyboardInterrupt:
            ret = 130
        raise SystemExit(ret)

    # ── Remote GPU — SSH tunnel + docker exec ──

    local_base = _find_free_port(8888, jupyter_port_count)
    port_forward_args = []
    for i in range(jupyter_port_count):
        local_port = local_base + i
        remote_port = host_port + i
        port_forward_args.extend(["-L", f"{local_port}:localhost:{remote_port}"])

    click.echo(f"Jupyter: http://localhost:{local_base}")
    click.echo("Connecting... (type 'exit' to disconnect)")

    control_path = f"/tmp/gpu-ssh-{os.getpid()}-{os.urandom(4).hex()}"
    ssh_user = data.get("ssh_user", SSH_USER)
    ssh_common = ["-o", "StrictHostKeyChecking=accept-new"]
    ssh_dest = f"{ssh_user}@{gpu_host}"

    # Start SSH master connection with port forwarding
    subprocess.run(
        ["ssh", "-fNM", "-S", control_path, *port_forward_args,
         *ssh_common, ssh_dest],
        check=False,
    )

    def _cleanup_master(*_args):
        subprocess.run(
            ["ssh", "-S", control_path, "-O", "exit", ssh_dest],
            capture_output=True,
        )

    signal.signal(signal.SIGTERM, lambda *a: (_cleanup_master(), sys.exit(1)))

    # Interactive docker exec via SSH
    remote_cmd = (
        f"exec docker exec -it"
        f" -e GPU_PLAN_ID={shlex.quote(display_plan)}"
        f" -e PS1={shlex.quote(prompt)}"
        f" -w /workspace"
        f" {shlex.quote(container_id)}"
        f" /bin/bash --noprofile --norc -i"
    )

    try:
        ret = subprocess.call([
            "ssh", "-t",
            "-S", control_path,
            *ssh_common,
            ssh_dest,
            remote_cmd,
        ])
    except KeyboardInterrupt:
        ret = 130
    finally:
        _cleanup_master()

    raise SystemExit(ret)
