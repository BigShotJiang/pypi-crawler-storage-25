# Ozekai GPU CLI

Connect, manage, and upload files to your Ozekai GPU machines.

## Install

```bash
pip install ozekai
```

Requires Python 3.10+ and SSH client installed.

## Commands

### `connect-gpu`

Connect to a GPU machine. Creates one if it doesn't exist.

```bash
connect-gpu --name training --plan a100
```

Options:
- `--name` (required) — VM name (e.g. `training`, `inference`)
- `--plan` (required) — GPU plan: `l40`, `a100`, or `h100`

JupyterLab auto-starts at `http://localhost:8888`.

### `disconnect-gpu`

Stop your GPU session. VM hibernates, storage billing continues.

```bash
disconnect-gpu --name training
```

To permanently destroy the VM and all data (stops all billing):

```bash
disconnect-gpu --name training --terminate
```

Options:
- `--name` (required) — VM name
- `--terminate` — Destroy VM and all data

> **Important:** Typing `exit` in the shell disconnects your terminal but does **not** stop billing. Always run `disconnect-gpu` when done, or use the stop button on your [Dashboard](https://ozekai.com/dashboard.html).

### `list-gpus`

List all your GPU VMs and their status.

```bash
list-gpus
```

### `upload-gpu`

Upload files to your GPU container's `/workspace`.

```bash
upload-gpu --name training file.py                  # → /workspace/file.py
upload-gpu --name training file.py models/          # → /workspace/models/file.py
upload-gpu --name training *.py src/ experiments/   # → /workspace/experiments/{files}
```

Options:
- `--name` (required) — VM name

## Configuration

| Variable | Default | Description |
|---|---|---|
| `OZEKAI_API_URL` | `https://ozekai.com` | Backend API URL |
| `OZEKAI_SSH_USER` | `$USER` | SSH username |

## Links

- [Getting Started](https://ozekai.com/getting-started.html)
- [Help & Reference](https://ozekai.com/help.html)
- [Support](mailto:ozekai.support@gmail.com)
