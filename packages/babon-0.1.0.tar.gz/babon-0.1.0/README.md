# babon

Kinematics-as-a-service client. Video in, movement data out.

```bash
pip install babon
```

```python
from babon import Babon

Babon("bk_...").analyze("trial.mp4").save("out.zip")
```

That's it.

## A bit more

```python
from babon import Babon

bb = Babon("bk_...")

# get the clinical_report.json dict directly
report = bb.analyze("trial.mp4").data
print(report["gait_parameters"]["gait_velocity_m_s"])

# batch
bb.analyze(["a.mp4", "b.mp4", "c.mp4"]).save("./results/")

# tag with your own identifier
bb.analyze("trial.mp4", label="cohort-3-day-7").save("out.zip")
```

## What's in the bundle

`clinical_report.json` (gait params, GRF, symmetry), 14 per-joint angle CSVs (ISB convention), raw rotation matrices, 3D joint positions, `bodymodel.npz`, `grf_waveform.json`, `manifest.json` with SHA-256 per file.

## Errors

The client raises typed exceptions:

- `BabonAuthError` — bad key, wrong environment, DPA not accepted.
- `BabonQuotaExceeded` — monthly limit, concurrent limit, or rate-limited.
- `BabonInvalidVideo` — file is not a recognised container.
- `BabonInvalidLabel` — label looks like a real name (ADR-0002).
- `BabonRunFailed` — pipeline failed.
- `BabonTimeout` — `wait()` exceeded its timeout.

All carry `.code` (the API error code) and `.request_id` (the support handle).

## What we are and are not

- Measurement only. Output is kinematics; clinical interpretation is yours.
- EU-cloud (Scaleway fr-par). Videos never leave the EU.
- Don't put real patient names in `label` or in your filenames. We reject name-shaped labels server-side.

## Contact

daan@babon.eu — onboarding, quota, bugs.
