"""Babon CLI — `babon <command>`.

Installed as a console_scripts entry point, so `pip install babon` puts
a `babon` binary on the user's PATH. The customer never writes glue
scripts; they just run:

    babon analyze trial.mp4
    babon analyze ./videos/
    babon status <run_id>
    babon download <run_id>
    babon resume

The key comes from `BABON_KEY` in the environment (or `--key`).
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from babon import Babon, Run, BabonError


def _key(args) -> str:
    key = args.key or os.environ.get("BABON_KEY", "")
    if not key:
        print("set BABON_KEY=bk_... or pass --key", file=sys.stderr)
        sys.exit(2)
    return key


def _collect_videos(target: Path) -> list[Path]:
    if target.is_file():
        return [target]
    if target.is_dir():
        return sorted(p for p in target.glob("*.mp4") if p.is_file())
    print(f"not found: {target}", file=sys.stderr)
    sys.exit(2)


def cmd_analyze(args) -> int:
    bb = Babon(_key(args))
    videos = _collect_videos(Path(args.path))
    if not videos:
        print(f"no .mp4 files in {args.path}", file=sys.stderr)
        return 2

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"submitting {len(videos)} video(s)...", flush=True)
    runs = bb.analyze([str(v) for v in videos], label=args.label)
    if isinstance(runs, Run):
        runs_list = [runs]
    else:
        runs_list = list(runs)

    for run, video in zip(runs_list, videos):
        print(f"  {video.name:30s} -> {run.id}", flush=True)

    print("waiting for completion, then downloading...", flush=True)
    for run, video in zip(runs_list, videos):
        out_path = out_dir / f"{video.stem}_{run.id}.zip"
        print(f"  {run.id}: polling ...", flush=True, end="")
        run.save(str(out_path), include_preview=args.include_preview)
        size_mb = out_path.stat().st_size / 1e6
        print(f" saved {out_path.name} ({size_mb:.1f} MB)", flush=True)
    return 0


def cmd_status(args) -> int:
    bb = Babon(_key(args))
    body = bb._get(f"/api/v1/runs/{args.run_id}")
    for k in ("run_id", "status", "stage", "progress", "created_at", "last_update"):
        if k in body:
            print(f"{k:14s} {body[k]}")
    if body.get("status") == "failed" and body.get("error"):
        print(f"error          {body['error']}")
    return 0


def cmd_download(args) -> int:
    bb = Babon(_key(args))
    out = Path(args.out or f"{args.run_id}.zip")
    run = Run(id=args.run_id, _client=bb)
    run.save(str(out), include_preview=args.include_preview)
    print(f"saved {out} ({out.stat().st_size / 1e6:.1f} MB)")
    return 0


def cmd_resume(args) -> int:
    """Pick up any non-terminal runs for this tenant and wait+download them.

    Reads the usage endpoint to find the org id, then walks recent
    submitted runs. For the pilot tier with low volume this is fine; a
    cohort-volume tenant would page through /v1/runs (list endpoint, to
    be added) instead.
    """
    print("usage endpoint provides totals but not run ids; ask Babon for the list endpoint", file=sys.stderr)
    return 3


def _add_key(p: argparse.ArgumentParser) -> None:
    p.add_argument("--key", help="API key (or set BABON_KEY env)")


def main() -> int:
    parser = argparse.ArgumentParser(prog="babon")
    _add_key(parser)
    sub = parser.add_subparsers(dest="command", required=True)

    p_analyze = sub.add_parser("analyze", help="submit one video or all .mp4 in a directory, wait, download")
    _add_key(p_analyze)
    p_analyze.add_argument("path", help="path to a .mp4 file or a directory of them")
    p_analyze.add_argument("--out", default="./out", help="output directory (default ./out)")
    p_analyze.add_argument("--label", default=None, help="optional opaque identifier")
    p_analyze.add_argument("--include-preview", action="store_true", help="include rendered preview mp4 in the bundle")
    p_analyze.set_defaults(fn=cmd_analyze)

    p_status = sub.add_parser("status", help="print lifecycle state for one run")
    _add_key(p_status)
    p_status.add_argument("run_id")
    p_status.set_defaults(fn=cmd_status)

    p_download = sub.add_parser("download", help="download the bundle for a completed run")
    _add_key(p_download)
    p_download.add_argument("run_id")
    p_download.add_argument("--out", default=None, help="output file (default <run_id>.zip)")
    p_download.add_argument("--include-preview", action="store_true")
    p_download.set_defaults(fn=cmd_download)

    p_resume = sub.add_parser("resume", help="wait + download any in-flight runs for this tenant")
    _add_key(p_resume)
    p_resume.set_defaults(fn=cmd_resume)

    args = parser.parse_args()
    try:
        return args.fn(args)
    except BabonError as exc:
        print(f"ERROR: {type(exc).__name__}: {exc} (code={exc.code} req={exc.request_id})",
              file=sys.stderr)
        return 4


if __name__ == "__main__":
    sys.exit(main())
