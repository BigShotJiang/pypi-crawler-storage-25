from typing import Dict, Iterable

import numpy as np


def aggregate_patient_probability_mean(probabilities: Iterable[float]) -> float:
    values = np.asarray(list(probabilities), dtype=np.float32)
    if values.size == 0:
        return 0.0
    return float(values.mean())


def aggregate_patient_feature_mean(features: Iterable[np.ndarray]) -> np.ndarray:
    rows = [np.asarray(feature, dtype=np.float32) for feature in features]
    if not rows:
        return np.empty((0,), dtype=np.float32)
    return np.stack(rows, axis=0).mean(axis=0)


def weighted_vote_patient_probability(axis_probabilities: Dict[str, float]) -> float:
    if not axis_probabilities:
        return 0.0

    return aggregate_patient_probability_mean(axis_probabilities.values())
