"""预测相关模块。"""

from .patient_predictor import PatientPredictor

__all__ = ["PatientPredictor"]
