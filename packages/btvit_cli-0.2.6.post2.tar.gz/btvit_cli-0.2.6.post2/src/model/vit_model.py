import torch
from torch import nn, arange, cat, stack, Tensor
from torch.nn import Module, ModuleList
import torch.nn.functional as F
import math

from einops import rearrange, repeat, reduce, pack, unpack
from einops.layers.torch import Rearrange

import sys
import os
from typing import Dict, List, Optional
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'doc'))

# 修复相对导入问题
try:
    from .vit_nd_rotary import GoldenGateRoPENd, Attention, FeedForward, Transformer
except ImportError:
    # 如果相对导入失败，尝试绝对导入
    from vit_nd_rotary import GoldenGateRoPENd, Attention, FeedForward, Transformer


class MedicalViT(Module):
    def __init__(
        self,
        *,
        input_shape: tuple = (16, 368),
        patch_size: tuple = (16, 16),
        num_classes: int = 1,
        dim: int = 512,
        depth: int = 6,
        heads: int = 8,
        mlp_dim: int = 2048,
        channels: int = 1,
        dim_head: int = 64,
        dropout: float = 0.1,
        emb_dropout: float = 0.1,
        rope_min_freq: float = 1.0,
        rope_max_freq: float = 10000.0,
        rope_p_zero_freqs: float = 0.0,
        use_rotary: bool = True
    ):
        super().__init__()

        self.input_shape = tuple(input_shape)
        self.patch_size = tuple(patch_size)
        self.num_classes = num_classes
        self.dim = dim
        self.depth = depth
        self.heads = heads
        self.mlp_dim = mlp_dim
        self.channels = channels
        self.dim_head = dim_head
        self.dropout_rate = dropout
        self.emb_dropout_rate = emb_dropout
        self.use_rotary = use_rotary
        self.rope_min_freq = rope_min_freq
        self.rope_max_freq = rope_max_freq
        self.rope_p_zero_freqs = rope_p_zero_freqs

        self.num_patches_h = math.ceil(self.input_shape[0] / self.patch_size[0])
        self.num_patches_w = math.ceil(self.input_shape[1] / self.patch_size[1])
        self.num_patches = self.num_patches_h * self.num_patches_w
        self.padded_input_shape = (
            self.num_patches_h * self.patch_size[0],
            self.num_patches_w * self.patch_size[1],
        )
        self.needs_padding = self.padded_input_shape != self.input_shape

        patch_dim = channels * self.patch_size[0] * self.patch_size[1]

        self.patch_embedding = nn.Sequential(
            Rearrange('b c (h p1) (w p2) -> b (h w) (p1 p2 c)',
                     p1=self.patch_size[0], p2=self.patch_size[1]),
            nn.LayerNorm(patch_dim),
            nn.Linear(patch_dim, dim),
            nn.LayerNorm(dim),
        )

        self.pos_embedding = nn.Parameter(torch.randn(1, self.num_patches, dim))
        self.dropout = nn.Dropout(emb_dropout)

        if use_rotary:
            self.rotary_emb = GoldenGateRoPENd(
                dim_pos=2,
                heads=heads,
                dim_head=dim_head,
                rope_min_freq=rope_min_freq,
                rope_max_freq=rope_max_freq,
                rope_p_zero_freqs=rope_p_zero_freqs,
                max_seq_length=self.num_patches,
            )
        else:
            self.rotary_emb = None

        self.transformer = Transformer(
            dim, depth, heads, dim_head, mlp_dim, dropout,
            rotary_emb=self.rotary_emb
        )

        self.to_latent = nn.Identity()
        self.mlp_head = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, num_classes)
        )

        self.apply(self._init_weights)
        # 单独初始化输出层，确保生效
        self._init_output_layer()

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            torch.nn.init.trunc_normal_(m.weight, std=0.02)
            if m.bias is not None:
                torch.nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            torch.nn.init.constant_(m.bias, 0)
            torch.nn.init.constant_(m.weight, 1.0)

    def _init_output_layer(self):
        """单独初始化输出层，确保合理的初始偏置"""
        if hasattr(self, 'mlp_head') and len(self.mlp_head) > 0:
            # 最后一层是线性层
            final_layer = self.mlp_head[-1]
            if isinstance(final_layer, nn.Linear):
                # 输出层使用标准权重初始化，但稍小一些
                torch.nn.init.xavier_normal_(final_layer.weight, gain=0.5)  # 适中的gain
                # 设置初始偏置为0，让模型从平衡点开始学习
                initial_bias = 0.0  # 从0开始，sigmoid(0)=0.5
                if final_layer.bias is not None:
                    nn.init.constant_(final_layer.bias, initial_bias)

    def get_initialization_info(self):
        """获取模型初始化信息"""
        init_info = {}

        if hasattr(self, 'mlp_head') and len(self.mlp_head) > 0:
            final_layer = self.mlp_head[-1]
            if isinstance(final_layer, nn.Linear):
                init_info['output_layer'] = {
                    'weight_mean': final_layer.weight.mean().item(),
                    'weight_std': final_layer.weight.std().item(),
                    'bias_mean': final_layer.bias.item() if final_layer.bias is not None else None,
                    'weight_shape': list(final_layer.weight.shape),
                    'bias_shape': list(final_layer.bias.shape) if final_layer.bias is not None else None
                }

        # 添加位置编码信息
        init_info['pos_embedding'] = {
            'shape': list(self.pos_embedding.shape),
            'mean': self.pos_embedding.mean().item(),
            'std': self.pos_embedding.std().item()
        }

        return init_info

    def save_initialization(self, save_path: str, verbose: bool = False):
        """保存模型初始化参数"""
        init_info = self.get_initialization_info()

        # 保存初始状态字典
        init_state = {
            'model_state_dict': self.state_dict(),
            'initialization_info': init_info,
            'model_config': {
                'input_shape': tuple(self.input_shape),
                'patch_size': tuple(self.patch_size),
                'num_classes': self.num_classes,
                'dim': self.dim,
                'depth': self.depth,
                'heads': self.heads,
                'mlp_dim': self.mlp_dim,
                'channels': self.channels,
                'dim_head': self.dim_head,
                'dropout': self.dropout_rate,
                'emb_dropout': self.emb_dropout_rate,
                'use_rotary': self.use_rotary,
            }
        }

        torch.save(init_state, save_path)
        if verbose:
            print(f"模型初始化参数已保存到: {save_path}")
            self._log_initialization_info(init_info)

        return init_info

    def load_initialization(self, load_path: str, verbose: bool = False):
        """加载模型初始化参数"""
        init_state = torch.load(load_path, map_location='cpu')

        # 加载模型状态
        self.load_state_dict(init_state['model_state_dict'])

        if verbose:
            print(f"模型初始化参数已从 {load_path} 加载")
        if 'initialization_info' in init_state and verbose:
            self._log_initialization_info(init_state['initialization_info'])

        return init_state.get('initialization_info')

    def _log_initialization_info(self, init_info):
        """记录初始化信息到日志"""
        print("模型输出层初始化检查:")
        if 'output_layer' in init_info:
            output_info = init_info['output_layer']
            print(f"  权重均值: {output_info['weight_mean']:.6f}")
            print(f"  权重标准差: {output_info['weight_std']:.6f}")
            print(f"  偏置值: {output_info['bias_mean']:.6f}")

        if 'pos_embedding' in init_info:
            pos_info = init_info['pos_embedding']
            print(f"  位置编码形状: {pos_info['shape']}")
            print(f"  位置编码均值: {pos_info['mean']:.6f}")
            print(f"  位置编码标准差: {pos_info['std']:.6f}")

    def generate_position_coordinates(self, batch_size: int, device: torch.device) -> Tensor:
        h_coords = arange(self.num_patches_h, device=device, dtype=torch.float32)
        w_coords = arange(self.num_patches_w, device=device, dtype=torch.float32)

        h_grid, w_grid = torch.meshgrid(h_coords, w_coords, indexing='ij')

        pos_coords = stack([h_grid, w_grid], dim=-1)
        pos_coords = rearrange(pos_coords, 'h w c -> (h w) c')

        pos_coords = repeat(pos_coords, 'n c -> b n c', b=batch_size)

        return pos_coords

    def _pad_to_patch_multiple(self, x: Tensor) -> Tensor:
        _, _, height, width = x.shape
        patch_h, patch_w = self.patch_size
        pad_h = (patch_h - height % patch_h) % patch_h
        pad_w = (patch_w - width % patch_w) % patch_w
        if pad_h == 0 and pad_w == 0:
            return x
        return F.pad(x, (0, pad_w, 0, pad_h))

    def forward(self, x):
        if x.dim() == 5:
            x = x.squeeze(1)
        x = self._pad_to_patch_multiple(x)

        x = self.patch_embedding(x)

        batch_size, num_patches, dim = x.shape

        if self.rotary_emb is not None:
            pos_coords = self.generate_position_coordinates(batch_size, x.device)
            x = x + self.pos_embedding[:, :num_patches]
            x = self.dropout(x)

            embed = self.transformer(x, pos_coords)
        else:
            x = x + self.pos_embedding[:, :num_patches]
            x = self.dropout(x)

            embed = self.transformer(x)

        pooled = reduce(embed, 'b n d -> b d', 'mean')

        pooled = self.to_latent(pooled)
        return self.mlp_head(pooled)

    def get_embedding(self, x):
        if x.dim() == 5:
            x = x.squeeze(1)
        x = self._pad_to_patch_multiple(x)

        x = self.patch_embedding(x)

        batch_size, num_patches, dim = x.shape

        if self.rotary_emb is not None:
            pos_coords = self.generate_position_coordinates(batch_size, x.device)
            x = x + self.pos_embedding[:, :num_patches]
            x = self.dropout(x)
            embed = self.transformer(x, pos_coords)
        else:
            x = x + self.pos_embedding[:, :num_patches]
            x = self.dropout(x)
            embed = self.transformer(x)

        return embed


class MultiAxisMedicalViT(Module):
    """多轴ViT包装器，为每个轴维护一个MedicalViT编码器。"""

    def __init__(self,
                 active_axes: Optional[List[str]] = None,
                 shared_encoder: bool = False,
                 **encoder_kwargs):
        super().__init__()
        self.active_axes = active_axes or ["x", "y", "z"]
        self.shared_encoder = shared_encoder

        if shared_encoder:
            self.shared_axis_encoder = MedicalViT(**encoder_kwargs)
            self.encoders = None
        else:
            self.shared_axis_encoder = None
            self.encoders = nn.ModuleDict({
                axis: MedicalViT(**encoder_kwargs)
                for axis in self.active_axes
            })

    def _get_encoder(self, axis: str) -> MedicalViT:
        if self.shared_encoder:
            return self.shared_axis_encoder
        return self.encoders[axis]

    def forward(self, axis_images: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        return {
            axis: self._get_encoder(axis)(axis_images[axis])
            for axis in self.active_axes
            if axis in axis_images
        }

    def extract_features(self, axis_images: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        axis_features = {}
        for axis in self.active_axes:
            if axis not in axis_images:
                continue
            embedding = self._get_encoder(axis).get_embedding(axis_images[axis])
            axis_features[axis] = embedding.mean(dim=1)
        return axis_features


def create_vit_model(config):
    return MedicalViT(
        input_shape=tuple(config.model.input_shape),
        patch_size=tuple(config.model.patch_size),
        num_classes=config.model.num_classes,
        dim=config.model.dim,
        depth=config.model.depth,
        heads=config.model.heads,
        mlp_dim=config.model.mlp_dim,
        channels=config.model.channels,
        dim_head=config.model.dim_head,
        dropout=config.model.dropout,
        emb_dropout=config.model.emb_dropout,
        rope_min_freq=config.model.rope_min_freq,
        rope_max_freq=config.model.rope_max_freq,
        rope_p_zero_freqs=config.model.rope_p_zero_freqs,
        use_rotary=True
    )


def test_vit_model():
    batch_size = 4
    channels = 1
    height, width = 16, 368  # 修正为正确的尺寸
    patch_h, patch_w = 16, 16

    model = MedicalViT(
        input_shape=(height, width),
        patch_size=(patch_h, patch_w),
        num_classes=1,
        dim=512,
        depth=6,
        heads=8,
        mlp_dim=2048,
        channels=channels,
        dropout=0.1,
        use_rotary=True
    )

    x = torch.randn(batch_size, channels, height, width)
    output = model(x)

    print(f"输入形状: {x.shape}")
    print(f"输出形状: {output.shape}")

    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

    print(f"总参数量: {total_params:,}")
    print(f"可训练参数量: {trainable_params:,}")

    return model


if __name__ == "__main__":
    model = test_vit_model()
