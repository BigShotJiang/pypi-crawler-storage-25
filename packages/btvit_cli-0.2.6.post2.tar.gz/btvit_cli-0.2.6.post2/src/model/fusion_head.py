from typing import Iterable

import torch
from torch import nn


def normalize_fusion_mode(fusion_mode: str | None) -> str:
    mode = str(fusion_mode or "concat").strip().lower()
    if mode not in {"concat", "sum"}:
        raise ValueError(f"unsupported fusion mode: {fusion_mode}")
    return mode


def resolve_fusion_input_dim(feature_dim: int, axis_count: int, fusion_mode: str | None) -> int:
    mode = normalize_fusion_mode(fusion_mode)
    base_dim = int(feature_dim)
    if mode == "concat":
        return base_dim * int(axis_count)
    return base_dim


def merge_patient_features(feature_parts: Iterable[torch.Tensor], fusion_mode: str | None) -> torch.Tensor:
    parts = [part for part in feature_parts]
    if not parts:
        raise ValueError("feature_parts must not be empty")

    mode = normalize_fusion_mode(fusion_mode)
    if mode == "concat":
        return torch.cat(parts, dim=0)
    return torch.stack(parts, dim=0).sum(dim=0)


class PatientFusionHead(nn.Module):
    def __init__(self, input_dim: int, head_type: str = "linear", hidden_dim: int = 256, dropout: float = 0.2):
        super().__init__()
        self.input_dim = int(input_dim)
        self.head_type = str(head_type)

        if self.head_type == "linear":
            self.head = nn.Sequential(
                nn.LayerNorm(self.input_dim),
                nn.Linear(self.input_dim, 1),
            )
        elif self.head_type == "mlp":
            self.head = nn.Sequential(
                nn.LayerNorm(self.input_dim),
                nn.Linear(self.input_dim, int(hidden_dim)),
                nn.GELU(),
                nn.Dropout(float(dropout)),
                nn.Linear(int(hidden_dim), 1),
            )
        else:
            raise ValueError(f"unsupported fusion head type: {head_type}")

    def forward(self, x):
        return self.head(x)
