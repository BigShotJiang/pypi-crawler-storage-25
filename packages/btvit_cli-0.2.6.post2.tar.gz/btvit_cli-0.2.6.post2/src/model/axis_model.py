from .vit_model import MedicalViT


class AxisViTModel(MedicalViT):
    """Single-axis ViT model exposing logits and pooled encoder features."""

    def extract_features(self, x):
        embedding = self.get_embedding(x)
        return embedding.mean(dim=1)
