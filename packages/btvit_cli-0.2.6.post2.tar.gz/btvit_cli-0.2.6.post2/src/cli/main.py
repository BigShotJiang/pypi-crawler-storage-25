"""Typer entrypoint for the vit CLI."""

import typer

from src import __version__
from src.cli.predict_cmd import predict_command
from src.cli.train_cmd import train_command
from src.cli.utils import export_cli_templates


app = typer.Typer(
    name="vit",
    help="ViT medical image classification CLI.",
    add_completion=False,
)


@app.callback(invoke_without_command=True)
def app_callback(
    version: bool = typer.Option(
        False,
        "--version",
        help="Show package version and exit.",
        is_eager=True,
    ),
):
    if version:
        typer.echo(f"vit {__version__}")
        raise typer.Exit()


app.command("train")(train_command)
app.command("pred")(predict_command)

@app.command("get")
def get_command(
    path: str = typer.Option(
        ".",
        "--path",
        help="导出 YAML 配置模板和 USAGE.md 的目标目录。默认值为当前命令执行目录。",
    ),
):
    """导出完整注释版 YAML 模板和 USAGE.md。"""
    output_dir = export_cli_templates(path)
    typer.echo(f"templates exported to {output_dir}")


@app.command("version")
def version_command():
    """Show package version."""
    typer.echo(f"vit {__version__}")


def run():
    app()


if __name__ == "__main__":
    run()
