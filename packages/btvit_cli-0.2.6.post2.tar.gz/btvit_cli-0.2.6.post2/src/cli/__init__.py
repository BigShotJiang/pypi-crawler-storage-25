"""Typer CLI package for the vit command."""

