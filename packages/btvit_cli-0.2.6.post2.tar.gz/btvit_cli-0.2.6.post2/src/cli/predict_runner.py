"""Package-safe prediction execution wrapper."""

from src.cli.predict_impl import execute_predict_args as execute_packaged_predict_args


def execute_predict_args(raw_args):
    return execute_packaged_predict_args(raw_args)
