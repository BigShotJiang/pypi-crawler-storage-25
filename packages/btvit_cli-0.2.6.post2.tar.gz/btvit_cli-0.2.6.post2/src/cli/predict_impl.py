"""Packaged prediction implementation shared by the CLI and legacy script."""

import argparse
import csv
import json
import os
from pathlib import Path
from typing import Dict, Iterable, List, Optional

os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib")

import matplotlib.pyplot as plt
import numpy as np

from src.cli.utils import normalize_prediction_data_layout
from src.prediction.patient_predictor import PatientPredictor
from src.training.fusion_trainer import resolve_axis_checkpoints
from src.utils.config import load_config
from src.utils.logger import get_logger


def build_parser():
    parser = argparse.ArgumentParser(
        description="ViT患者级预测脚本。支持 weighted_vote、fusion_nn 和 both 三种输出模式。",
    )
    parser.add_argument("--mode", default=None, help="预测模式: weighted_vote | fusion_nn | both")
    parser.add_argument("--model", default=None, help="用于推导实验目录或覆盖 fusion checkpoint 的模型路径。")
    parser.add_argument("--config", default=None, help="配置文件目录路径，用于自动解析实验输出。")
    parser.add_argument("--data", default=None, help="预测数据根目录。支持 data-x/y/z 或平铺 PNG 目录。")
    parser.add_argument("--output", default="output", help="预测结果输出目录。")
    parser.add_argument("--label", default=None, help="可选标签 CSV，支持 patient_id,label 或 0,1 表头。")
    parser.add_argument("--verbose", action="store_true", help="显示实时预测进度条。")
    parser.add_argument("--fusion", choices=["sum", "concat"], default=None, help="覆盖 fusion 特征合并方式。")
    parser.add_argument("--fusion-threshold", dest="fusion_threshold", type=float, default=None)
    parser.add_argument("--axis-checkpoint-x", dest="axis_checkpoint_x", default=None)
    parser.add_argument("--axis-checkpoint-y", dest="axis_checkpoint_y", default=None)
    parser.add_argument("--axis-checkpoint-z", dest="axis_checkpoint_z", default=None)
    parser.add_argument("--fusion-checkpoint", dest="fusion_checkpoint", default=None)
    parser.add_argument("--tta", action="store_true", help="启用 Test-Time Augmentation 预测。")
    parser.add_argument("--tta-augmentations", dest="tta_augmentations", type=int, default=None)
    return parser


def parse_args(argv=None):
    normalized_argv = []
    if argv is None:
        import sys

        argv = sys.argv[1:]
    else:
        argv = list(argv)

    index = 0
    while index < len(argv):
        token = argv[index]
        if token == "--checkpoint" and index + 1 < len(argv):
            normalized_argv.extend(["--model", argv[index + 1]])
            index += 2
            continue
        normalized_argv.append(token)
        index += 1

    return build_parser().parse_args(normalized_argv)


def normalize_args(raw_args):
    if isinstance(raw_args, argparse.Namespace):
        return raw_args
    if isinstance(raw_args, dict):
        defaults = vars(parse_args([]))
        defaults.update(raw_args)
        return argparse.Namespace(**defaults)
    if raw_args is None:
        return parse_args()
    return parse_args(raw_args)


def resolve_output_dir(path: str) -> Path:
    output_dir = Path(path).expanduser()
    if not output_dir.is_absolute():
        output_dir = Path.cwd() / output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir.resolve()


def _resolve_fusion_checkpoint(experiment_dir: str) -> str:
    fusion_checkpoint_path = os.path.join(experiment_dir, "fusion", "checkpoints", "best_model.pth")
    if not os.path.exists(fusion_checkpoint_path):
        raise FileNotFoundError(f"未找到 fusion checkpoint: {fusion_checkpoint_path}")
    return os.path.abspath(fusion_checkpoint_path)


def resolve_paths_from_config(config_dir: str) -> dict:
    config = load_config(config_dir)
    experiment_dir = os.path.join(config.experiment.save_dir, config.experiment.name)
    active_axes = list(getattr(config.multi_axis, "active_axes", ["x", "y", "z"]))

    axis_checkpoint_paths = resolve_axis_checkpoints(
        save_dir=config.experiment.save_dir,
        experiment_name=config.experiment.name,
        active_axes=active_axes,
    )
    fusion_checkpoint_path = _resolve_fusion_checkpoint(experiment_dir)

    data_path = os.path.join(experiment_dir, "testset")
    label_path = os.path.join(experiment_dir, "testset", "label.csv")

    return {
        "axis_checkpoint_paths": {axis: os.path.abspath(path) for axis, path in axis_checkpoint_paths.items()},
        "fusion_checkpoint_path": fusion_checkpoint_path,
        "data_path": os.path.abspath(data_path) if os.path.isdir(data_path) else None,
        "label_path": os.path.abspath(label_path) if os.path.isfile(label_path) else None,
        "experiment_dir": os.path.abspath(experiment_dir),
        "active_axes": active_axes,
    }


def _infer_experiment_root_from_model(model_path: str) -> tuple[Optional[str], Optional[str]]:
    checkpoint_path = Path(model_path).expanduser().resolve()
    if checkpoint_path.parent.name != "checkpoints":
        return None, None

    stage_dir = checkpoint_path.parent.parent
    stage_name = stage_dir.name
    if stage_name == "fusion" or stage_name.startswith("axis-"):
        return str(stage_dir.parent), stage_name
    return None, None


def _resolve_paths_from_model_anchor(model_path: str, active_axes: List[str], mode: str) -> dict:
    experiment_root, stage_name = _infer_experiment_root_from_model(model_path)
    axis_checkpoint_paths: Dict[str, str] = {}
    fusion_checkpoint_path: Optional[str] = None

    if experiment_root:
        for axis in active_axes:
            candidate = os.path.join(experiment_root, f"axis-{axis}", "checkpoints", "best_model.pth")
            if os.path.exists(candidate):
                axis_checkpoint_paths[axis] = os.path.abspath(candidate)
        candidate = os.path.join(experiment_root, "fusion", "checkpoints", "best_model.pth")
        if os.path.exists(candidate):
            fusion_checkpoint_path = os.path.abspath(candidate)

    if stage_name == "fusion":
        fusion_checkpoint_path = os.path.abspath(model_path)
    elif stage_name and stage_name.startswith("axis-"):
        axis = stage_name.split("-", 1)[1]
        axis_checkpoint_paths[axis] = os.path.abspath(model_path)
    elif mode in {"fusion_nn", "both"}:
        fusion_checkpoint_path = os.path.abspath(model_path)

    return {
        "axis_checkpoint_paths": axis_checkpoint_paths,
        "fusion_checkpoint_path": fusion_checkpoint_path,
        "experiment_dir": experiment_root,
    }


def resolve_axis_data_paths(data_root: str, workspace_dir: Path) -> Dict[str, str]:
    return normalize_prediction_data_layout(data_root, workspace_dir)


def collect_patient_ids(axis_data_paths: Dict[str, str]) -> List[str]:
    patient_sets = []
    for axis_path in axis_data_paths.values():
        patient_ids = set()
        for png_path in Path(axis_path).glob("*.png"):
            parts = png_path.stem.split("_")
            if parts:
                patient_ids.add(parts[0])
        patient_sets.append(patient_ids)

    if not patient_sets:
        return []
    return sorted(set.intersection(*patient_sets))


def load_label_map(label_path: Optional[str]) -> Dict[str, int]:
    if not label_path:
        return {}
    csv_path = Path(label_path).expanduser().resolve()
    if not csv_path.exists():
        raise FileNotFoundError(f"标签文件不存在: {csv_path}")

    with csv_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        header = next(reader, None)
        if header is None:
            return {}

        normalized_header = [cell.strip() for cell in header[:2]]
        if normalized_header == ["patient_id", "label"]:
            label_map = {}
            for row in reader:
                if len(row) < 2:
                    continue
                patient_id = row[0].strip()
                label = row[1].strip()
                if patient_id and label:
                    label_map[patient_id] = int(label)
            return label_map

        if normalized_header == ["0", "1"]:
            label_map = {}
            for row in reader:
                if row and row[0].strip():
                    label_map[row[0].strip()] = 0
                if len(row) > 1 and row[1].strip():
                    label_map[row[1].strip()] = 1
            return label_map

    raise ValueError("标签 CSV 表头必须为 patient_id,label 或 0,1")


def build_prediction_rows(results: Iterable[Dict[str, object]], label_map: Dict[str, int]) -> List[Dict[str, object]]:
    rows = []
    with_labels = bool(label_map)
    for result in results:
        row = {
            "patient_id": result["patient_id"],
        }
        if "weighted_vote_prob" in result:
            row["weighted_vote_prob"] = round(float(result["weighted_vote_prob"]), 6)
            row["weighted_vote_pred"] = int(result["weighted_vote_pred"])
        if "fusion_nn_prob" in result:
            row["fusion_nn_prob"] = round(float(result["fusion_nn_prob"]), 6)
            row["fusion_nn_pred"] = int(result["fusion_nn_pred"])

        if with_labels and result["patient_id"] in label_map:
            label = int(label_map[result["patient_id"]])
            row["label"] = label
            if "weighted_vote_pred" in row:
                row["weighted_vote_pass"] = bool(label == row["weighted_vote_pred"])
            if "fusion_nn_pred" in row:
                row["fusion_nn_pass"] = bool(label == row["fusion_nn_pred"])

        rows.append(row)
    return rows


def _save_confusion_matrix(rows: List[Dict[str, object]], output_dir: Path, mode: str) -> Optional[str]:
    pred_key = f"{mode}_pred"
    pass_key = f"{mode}_pass"
    labeled_rows = [row for row in rows if "label" in row and pred_key in row]
    if not labeled_rows:
        return None

    matrix = np.zeros((2, 2), dtype=int)
    for row in labeled_rows:
        matrix[int(row["label"]), int(row[pred_key])] += 1

    figure, axis = plt.subplots(figsize=(4, 4))
    axis.imshow(matrix, cmap="Blues")
    axis.set_title(f"Confusion Matrix ({mode})")
    axis.set_xlabel("Predicted")
    axis.set_ylabel("True")
    axis.set_xticks([0, 1], labels=["0", "1"])
    axis.set_yticks([0, 1], labels=["0", "1"])

    for row_index in range(2):
        for col_index in range(2):
            axis.text(col_index, row_index, str(matrix[row_index, col_index]), ha="center", va="center", color="black")

    figure.tight_layout()
    output_path = output_dir / f"confusion_matrix_{mode}.png"
    figure.savefig(output_path, dpi=150)
    plt.close(figure)
    return str(output_path.resolve())


def save_prediction_outputs(
    rows: List[Dict[str, object]],
    summary: Dict[str, object],
    output_dir: Path,
) -> Dict[str, str]:
    csv_path = output_dir / "predictions.csv"
    json_path = output_dir / "prediction_summary.json"

    fieldnames = list(rows[0].keys()) if rows else ["patient_id"]
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    with json_path.open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False, default=str)

    output_paths = {
        "prediction_csv": str(csv_path.resolve()),
        "summary_json": str(json_path.resolve()),
    }
    for mode in ("weighted_vote", "fusion_nn"):
        matrix_path = _save_confusion_matrix(rows, output_dir, mode)
        if matrix_path is not None:
            output_paths[f"confusion_matrix_{mode}_png"] = matrix_path
    return output_paths


def _merge_prediction_sources(args):
    mode = str(args.mode or "").strip().lower()
    if not mode:
        raise ValueError("必须提供 --mode。")
    if mode not in {"weighted_vote", "fusion_nn", "both"}:
        raise ValueError("--mode 必须为 weighted_vote、fusion_nn 或 both")

    if not args.model and not args.config:
        raise ValueError("必须提供 --model 或 --config 至少其一。")

    derived = {}
    if args.config:
        derived = resolve_paths_from_config(args.config)

    active_axes = list(derived.get("active_axes", ["x", "y", "z"]))
    model_derived = _resolve_paths_from_model_anchor(args.model, active_axes, mode) if args.model else {}

    axis_checkpoint_paths = dict(derived.get("axis_checkpoint_paths", {}))
    axis_checkpoint_paths.update(model_derived.get("axis_checkpoint_paths", {}))
    for axis in active_axes:
        override = getattr(args, f"axis_checkpoint_{axis}", None)
        if override:
            axis_checkpoint_paths[axis] = os.path.abspath(override)

    fusion_checkpoint_path = args.fusion_checkpoint or model_derived.get("fusion_checkpoint_path") or derived.get("fusion_checkpoint_path")
    if fusion_checkpoint_path:
        fusion_checkpoint_path = os.path.abspath(fusion_checkpoint_path)

    data_path = args.data or derived.get("data_path")
    label_path = args.label or derived.get("label_path")

    missing_axis_checkpoints = [axis for axis in active_axes if axis not in axis_checkpoint_paths]
    if missing_axis_checkpoints:
        raise FileNotFoundError(
            "未找到以下轴的 checkpoint: " + ", ".join(missing_axis_checkpoints)
        )
    for axis, checkpoint_path in axis_checkpoint_paths.items():
        if not os.path.exists(checkpoint_path):
            raise FileNotFoundError(f"轴 checkpoint 不存在: {axis} -> {checkpoint_path}")

    if mode in {"fusion_nn", "both"}:
        if not fusion_checkpoint_path:
            raise FileNotFoundError("fusion_nn 模式需要 fusion checkpoint。请提供 --fusion-checkpoint 或 --config。")
        if not os.path.exists(fusion_checkpoint_path):
            raise FileNotFoundError(f"fusion checkpoint 不存在: {fusion_checkpoint_path}")

    if not data_path:
        raise ValueError("必须提供 --data，或通过 --config 自动推导 testset 路径。")

    fusion_threshold = args.fusion_threshold

    return {
        "mode": mode,
        "axis_checkpoint_paths": axis_checkpoint_paths,
        "fusion_checkpoint_path": fusion_checkpoint_path,
        "data_path": data_path,
        "label_path": label_path,
        "fusion": args.fusion,
        "fusion_threshold": fusion_threshold,
    }


def execute_predict_args(raw_args):
    args = normalize_args(raw_args)
    resolved = _merge_prediction_sources(args)

    output_dir = resolve_output_dir(args.output)
    log_dir = output_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    logger = get_logger("predict", str(log_dir), console=False)

    predictor = PatientPredictor(
        axis_checkpoint_paths=resolved["axis_checkpoint_paths"],
        fusion_checkpoint_path=resolved["fusion_checkpoint_path"],
        mode=resolved["mode"],
        config_path=args.config,
        fusion=resolved["fusion"],
        fusion_nn_threshold=resolved["fusion_threshold"],
        verbose=bool(args.verbose),
        tta=bool(getattr(args, "tta", False)),
        tta_augmentations=getattr(args, "tta_augmentations", None),
    )
    axis_data_paths = resolve_axis_data_paths(resolved["data_path"], output_dir / "_normalized_axes")
    patient_ids = collect_patient_ids(axis_data_paths)
    label_map = load_label_map(resolved["label_path"])

    results, summary = predictor.predict_batch(
        patient_ids=patient_ids,
        axis_data_paths=axis_data_paths,
        label_path=resolved["label_path"],
    )
    rows = build_prediction_rows(results, label_map)
    output_paths = save_prediction_outputs(rows, summary, output_dir)

    logger.info("prediction completed")
    logger.info(f"prediction_csv={output_paths['prediction_csv']}")
    logger.info(f"summary_json={output_paths['summary_json']}")

    print("Prediction completed.")
    print(f"mode: {resolved['mode']}")
    print(f"patients: {summary.get('patient_count', 0)}")
    if "weighted_vote_accuracy" in summary:
        print(f"weighted_vote_accuracy: {summary['weighted_vote_accuracy']:.6f}")
    if "fusion_nn_accuracy" in summary:
        print(f"fusion_nn_accuracy: {summary['fusion_nn_accuracy']:.6f}")
    print(f"prediction_csv: {output_paths['prediction_csv']}")
    print(f"summary_json: {output_paths['summary_json']}")
    return 0


def main(argv=None):
    try:
        return execute_predict_args(parse_args(argv))
    except Exception as exc:
        print(f"预测过程中发生错误: {exc}")
        import traceback

        traceback.print_exc()
        return 1
