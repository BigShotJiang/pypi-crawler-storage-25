"""Shared helpers for CLI commands."""

import shutil
from pathlib import Path


def resolve_output_dir(path: str | None) -> Path:
    if path:
        return Path(path).resolve()
    return Path.cwd().resolve()


def parse_axis_filename(filename: str) -> tuple[str, str, str, str]:
    stem = Path(filename).stem
    parts = stem.split("_")
    if len(parts) < 4:
        raise ValueError(f"invalid png filename: {filename}")
    patient_id = "_".join(parts[:-3])
    z_index, y_index, x_index = parts[-3:]
    if not patient_id:
        raise ValueError(f"invalid patient id in filename: {filename}")
    return patient_id, z_index, y_index, x_index


def infer_axis_from_filename(filename: str) -> str:
    _, z_index, y_index, x_index = parse_axis_filename(filename)
    axis_flags = {
        "z": int(z_index) != 0,
        "y": int(y_index) != 0,
        "x": int(x_index) != 0,
    }
    active_axes = [axis for axis, active in axis_flags.items() if active]
    if len(active_axes) != 1:
        raise ValueError(
            f"cannot infer axis from filename {filename}; exactly one of Z/Y/X indices must be non-zero"
        )
    return active_axes[0]


def normalize_prediction_data_layout(data_root: str, workspace_dir: Path) -> dict[str, str]:
    root = Path(data_root).expanduser().resolve()
    direct_axis_paths = {
        "x": root / "data-x",
        "y": root / "data-y",
        "z": root / "data-z",
    }
    if all(path.is_dir() for path in direct_axis_paths.values()):
        return {axis: str(path) for axis, path in direct_axis_paths.items()}

    png_files = sorted(root.glob("*.png"))
    if not png_files:
        raise FileNotFoundError(f"no png files found under prediction data path: {root}")

    normalized_root = workspace_dir.expanduser().resolve()
    axis_paths = {
        "x": normalized_root / "data-x",
        "y": normalized_root / "data-y",
        "z": normalized_root / "data-z",
    }
    if normalized_root.exists():
        shutil.rmtree(normalized_root)
    for path in axis_paths.values():
        path.mkdir(parents=True, exist_ok=True)

    for png_file in png_files:
        axis = infer_axis_from_filename(png_file.name)
        shutil.copy2(png_file, axis_paths[axis] / png_file.name)

    return {axis: str(path) for axis, path in axis_paths.items()}


MODEL_CONFIG_TEMPLATE = """# model_config.yaml
# Vision Transformer model structure configuration.
model:
  # Model identifier used in logs and reports.
  name: ViTND
  # Input dimensionality. Keep 2 for PNG inputs shaped as 368x16.
  ndim: 2
  # Input image shape as [height, width].
  input_shape: [16, 368]
  # Patch size as [height, width]. Keep aligned with preprocessing.
  patch_size: [16, 16]
  # Binary classification output.
  num_classes: 1
  # Transformer embedding dimension.
  dim: 512
  # Number of transformer encoder blocks.
  depth: 6
  # Number of attention heads.
  heads: 8
  # Hidden dimension inside the MLP block.
  mlp_dim: 2048
  # PNG grayscale channel count.
  channels: 1
  # Per-head hidden size.
  dim_head: 64
  # Dropout applied in transformer blocks.
  dropout: 0.1
  # Dropout applied after patch embedding.
  emb_dropout: 0.1
  # Rotary embedding minimum frequency.
  rope_min_freq: 1.0
  # Rotary embedding maximum frequency.
  rope_max_freq: 10000.0
  # Fraction of rotary frequencies forced to zero.
  rope_p_zero_freqs: 0.0
"""


DATA_CONFIG_TEMPLATE = """# data_config.yaml
# Data loading and memory preload configuration.
data:
  # Pin CPU memory before GPU transfer.
  pin_memory: true
  # Enable memory preload by default. Disable from CLI with --disable-memory-preload.
  enable_memory_preload: true
  # Optional chunk size for staged preload. Null means preload everything at once.
  preload_batch_size: null
  # Whether preload should log detailed progress information.
  preload_verbose: true
"""


TRAINING_CONFIG_TEMPLATE = """# training_config.yaml
# Stage-aware training configuration.
random_seed: 42

init:
  # same: deterministic initialization and deterministic train-loader shuffle.
  # random: random initialization without deterministic runtime guarantees.
  init_mode: same
  # Optional explicit seed for model initialization. Null falls back to random_seed.
  init_seed: null

training:
  common:
    # Training device.
    # Supported: cuda, cpu, auto, cuda:0, cuda:1.
    device: cuda
    # Number of dataloader worker processes.
    num_workers: 8
    # Enable mixed-precision training on supported hardware.
    mixed_precision: true
    # Maximum gradient norm. Set 0.0 to disable clipping.
    gradient_clip_val: 1.0
    # Number of mini-batches accumulated before optimizer.step().
    accumulate_grad_batches: 1
    # Emit extra batch-level debug logs during training.
    debug_logging: false

  # Test-Time Augmentation settings for validation / evaluation / prediction.
  tta:
    # Enable TTA. CLI --tta overrides this field to true.
    enabled: false
    # Number of variants per image including the original.
    num_augmentations: 7
    transforms:
      horizontal_flip:
        enabled: true
      brightness_contrast:
        enabled: true
        brightness_range: [0.9, 1.1]
        contrast_range: [0.9, 1.1]
      gaussian_noise:
        enabled: true
        std_min: 0.01
        std_max: 0.03

  axis:
    # Axis-stage epochs.
    epochs: 100
    # Axis-stage batch size. Samples are single images from one axis.
    batch_size: 32
    # Axis-stage learning rate.
    learning_rate: 0.001
    # Axis-stage weight decay.
    weight_decay: 0.01
    # Optimizer for axis training. Supported: AdamW, Adam, SGD.
    optimizer: AdamW
    # Scheduler for axis training.
    scheduler: CosineAnnealingLR
    # Scheduler keyword arguments.
    scheduler_params: {T_max: 100, eta_min: 1.0e-6}
    # Optional checkpoint path for warm start.
    # Example: checkpoints/best_model.pth
    pretrained_model_path: ""
    # When true, only model weights are loaded from pretrained_model_path.
    load_weights_only: false
    # Require checkpoint keys to match the current model exactly.
    strict_load: false
    # Freezing strategy for transfer learning. Supported: none, layers, ratio.
    freeze_method: none
    # Layer selector used when freeze_method=layers.
    # Example: patch_embedding,transformer:0-2
    freeze_layers: ""
    # Fraction of encoder layers frozen when freeze_method=ratio.
    freeze_ratio: 0.0
    # Learning-rate multiplier applied during fine-tuning.
    finetune_lr_scale: 1.0
    # Enable separate learning rates for different parameter groups.
    use_differential_lr: false
    # Enable class-balanced image-level sampling for axis training.
    balanced_sampling: false
    # Hard Example Mining settings.
    hard_example_mining:
      enabled: false
      start_epoch: 30
      weight_factor: 2.0
      update_interval: 10
      top_percentile: 80.0
    # Axis-stage loss configuration.
    # Supported types: bce, focal, bce_label_smoothing, weighted_bce, dice, tversky, focal_tversky, combined.
    loss:
      type: "bce"
      focal_alpha: 0.25
      focal_gamma: 2.0
      label_smoothing: 0.1
      pos_weight: -1
      # Weighted BCE parameters (type: weighted_bce).
      weighted_bce_pos_weight: 2.0
      weighted_bce_neg_weight: 1.0
      # Dice loss parameters (type: dice).
      dice_loss_smooth: 1.0
      # Tversky loss parameters (type: tversky).
      tversky_alpha: 0.7
      tversky_beta: 0.3
      tversky_smooth: 1.0
      # Focal Tversky parameters (type: focal_tversky).
      focal_tversky_gamma: 2.0
      focal_tversky_alpha: 0.5
      focal_tversky_beta: 0.5
      focal_tversky_smooth: 1.0
      # Combined loss weights (type: combined). Keys must be registered loss names.
      combined_loss_weights:
        bce: 0.5
        tversky: 0.5
    # Per-axis overrides (optional).
    # Each key overrides shared defaults for the named axis.
    # Deep merge: nested dicts (e.g. loss, scheduler_params) merge key-by-key.
    # Empty dict or absent key = use all shared defaults.
    # Example:
    #   x:
    #     learning_rate: 0.0005
    #     loss:
    #       type: focal
    #       focal_alpha: 0.75
    #   y:
    #     epochs: 150
    x: {}
    y: {}
    z: {}

  fusion:
    # Fusion-stage epochs.
    epochs: 50
    # Fusion-stage batch size. Samples are patient-level multi-axis groups.
    batch_size: 8
    # Fusion-stage learning rate.
    learning_rate: 0.001
    # Fusion-stage weight decay.
    weight_decay: 0.0
    # Optimizer for fusion-head training.
    optimizer: AdamW
    # Scheduler for fusion-head training.
    scheduler: CosineAnnealingLR
    # Scheduler keyword arguments.
    scheduler_params: {T_max: 50, eta_min: 1.0e-6}
    # Main ablation path freezes the three axis encoders.
    freeze_encoders: true

train_split:
  # Split method.
  # Supported: stratified (recommended, CLI default), random, cv, csv_direct, csv_resplit.
  method: stratified
  train_ratio: 0.75
  val_ratio: 0.15
  test_ratio: 0.10
  train_split_random_seed: 42
  export_split_info: true
  split_filename: train_split.csv
  # Example: exports/train_split.csv
  train_split_csv_path: ""
  csv_split_random_seed: 42
  use_csv_direct: false
"""


EXPERIMENT_CONFIG_TEMPLATE = """# experiment_config.yaml
# Experiment output and logging configuration.
# Experiment name used to create experiments/{name}/.
name: vit_experiment
# Human-readable version tag.
version: "0.2.0-2"
# Root directory that contains logs/, checkpoints/, and results/.
save_dir: experiments
# These directory fields are auto-expanded inside save_dir/name during runtime.
log_dir: experiments/logs
checkpoint_dir: experiments/checkpoints
result_dir: experiments/results
# Logging frequency by step.
log_every_n_steps: 10
# Validation interval in epochs.
val_check_interval: 1.0
# Reserved compatibility field for legacy single-axis flow.
save_top_k: 1
"""


MULTI_AXIS_CONFIG_TEMPLATE = """# multi_axis_config.yaml
# Shared three-axis encoder coordination and patient-level output configuration.
multi_axis:
  # Default training axis directories.
  axis_data_paths:
    x: dataset/data-x
    y: dataset/data-y
    z: dataset/data-z
  # Optional original-width axis directories used by --dataset origin.
  origin_axis_data_paths:
    x: dataset/origin-data-x
    y: dataset/origin-data-y
    z: dataset/origin-data-z
  # Axes used by the project. Must be a subset of [x, y, z].
  active_axes: [x, y, z]

  patient_pooling:
    # Pooling rule for image features within the same patient and axis.
    image_feature_pooling: mean
    # Pooling rule for image probabilities within the same patient and axis.
    image_probability_pooling: mean

  weighted_vote:
    # Enable the patient-level weighted-vote branch.
    # The rule is fixed: use the mean of x/y/z patient probabilities and predict positive when mean > 2/3.
    enabled: true

  fusion_head:
    # Enable the patient-level fusion-NN branch.
    enabled: true
    # Supported axis-feature merge modes before the fusion head.
    # concat: [x, y, z] -> dim * 3
    # sum:    x + y + z -> dim
    fusion: concat
    # Supported: linear, mlp.
    type: linear
    # Hidden dimension used when type=mlp.
    hidden_dim: 256
    # Dropout used by the fusion head.
    dropout: 0.2
"""


MONITORING_CONFIG_TEMPLATE = """# monitoring_config.yaml
# Stage-aware monitoring and prediction threshold configuration.
monitoring:
  axis:
    early_stopping:
      enabled: true
      metric: val_auc
      mode: max
      patience: 10
      min_delta: 0.001
    model_selection:
      metric: val_auc
      mode: max

  fusion:
    early_stopping:
      enabled: true
      metric: val_auc
      mode: max
      patience: 10
      min_delta: 0.001
    model_selection:
      metric: val_auc
      mode: max

  prediction:
    fusion_nn_threshold: 0.5

  # When true, CLI commands can show tqdm progress.
  verbose: true
"""


USAGE_TEMPLATE = """# vit CLI Usage

## Commands

`vit train --config <yaml_dir> --stage axis --axis <x|y|z> [--data <dir>] [--dataset processed|origin] [--label <csv>] [--verbose]`

- Axis-stage training uses single-image samples from one axis.
- Patient splitting is still done at patient level before image expansion.
- Output is stored under `experiments/<name>/axis-<axis>/`.
- New reproducibility flags:
  - `--init same|random`
  - `--init-seed <int>`
  - `--random-seed <int>`
  - `--train-split-seed <int>`
- Dataset selector:
  - `--dataset processed|origin`
- Default `--init same` enables deterministic model initialization and deterministic train-loader shuffle.
- `--init random` keeps random initialization behavior.
- `same` mode may be slightly slower because it disables `cudnn.benchmark`.

`vit train --config <yaml_dir> --stage fusion [--fusion <sum|concat>] [--label <csv>] [--verbose]`

- Fusion-stage training uses patient-level samples containing multi-image inputs from `x/y/z`.
- The main ablation path reuses the trained three axis encoders and freezes them by default.
- Output is stored under `experiments/<name>/fusion/`.

`vit pred --mode weighted_vote|fusion_nn|both [--config <yaml_dir> | --model <checkpoint>] --data <png_dir> [--fusion <sum|concat>] [--output <dir>] [--label <csv>] [--verbose]`

- `weighted_vote`: per-image axis probabilities -> per-axis patient means -> three-axis mean -> positive when mean > 2/3.
- `fusion_nn`: per-image axis features -> per-axis patient means -> `concat` or `sum` -> fusion head.
- `both`: compute both patient-level outputs on the same patient input set.
- Supported `--data` layouts:
  - One root directory that contains `data-x/`, `data-y/`, and `data-z/`
  - One flat directory containing mixed-axis PNG files named `{patient_id}_{Z}_{Y}_{X}.png`

`vit get [--path <dir>]`

- Exports the full commented YAML template set and this usage guide to the target directory.

`vit version`

- Prints the package version from `src.__version__`

## YAML Variable Reference

### model_config.yaml
- Defines the shared ViT encoder structure used by all three axis models.

### data_config.yaml
- Defines shared data-loading behavior such as memory preload and pin-memory.

### training_config.yaml
- Top-level reproducibility fields:
  - `random_seed`
  - `init.init_mode`
  - `init.init_seed`
- Defines stage-aware training sections:
  - `training.common`
  - `training.axis`
  - `training.fusion`
- `train_split` remains patient-level.
- `train_split.train_split_random_seed` controls patient split reproducibility.
- `train_split.csv_split_random_seed` controls CSV resplitting reproducibility.

### experiment_config.yaml
- Defines experiment naming, output roots, and logging-related fields.

### multi_axis_config.yaml
- Defines axis directories, patient pooling rules, weighted-vote settings, and fusion-head settings.

### monitoring_config.yaml
- Defines stage-aware early stopping/model selection and prediction thresholds for both output modes.

Author: SuShuHeng
Repository: https://github.com/SuShuHeng/Vit-cli
License: Apache2.0
"""


def export_cli_templates(output_dir: str | None) -> Path:
    target_dir = resolve_output_dir(output_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    templates = {
        "model_config.yaml": MODEL_CONFIG_TEMPLATE,
        "data_config.yaml": DATA_CONFIG_TEMPLATE,
        "training_config.yaml": TRAINING_CONFIG_TEMPLATE,
        "experiment_config.yaml": EXPERIMENT_CONFIG_TEMPLATE,
        "multi_axis_config.yaml": MULTI_AXIS_CONFIG_TEMPLATE,
        "monitoring_config.yaml": MONITORING_CONFIG_TEMPLATE,
        "USAGE.md": USAGE_TEMPLATE,
    }
    for filename, content in templates.items():
        (target_dir / filename).write_text(content, encoding="utf-8")
    return target_dir
