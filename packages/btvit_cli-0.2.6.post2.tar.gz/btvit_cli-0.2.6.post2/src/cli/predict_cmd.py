"""Typer command for patient-level dual-output prediction."""

from typing import Optional

import typer

from src.cli import predict_runner


PRED_HELP = (
    "执行患者级三轴预测。\n\n"
    "必选参数:\n"
    "  vit pred --mode weighted_vote|fusion_nn|both [--config <yaml_dir> | --model <checkpoint>] --data <png_dir> [--fusion <sum|concat>]\n\n"
    "模式说明:\n"
    "  weighted_vote: 三轴单图概率 -> 轴内患者均值 -> 三轴均值，大于 2/3 判阳性\n"
    "  fusion_nn:     三轴单图特征 -> 轴内患者均值 -> fusion(sum|concat) -> fusion head\n"
    "  both:          同时输出 weighted_vote 与 fusion_nn\n\n"
    "checkpoint 解析:\n"
    "  - 优先使用 --config 自动解析 experiments/<name>/axis-x|y|z 与 fusion 的 checkpoint\n"
    "  - 可用 --axis-checkpoint-x/y/z 和 --fusion-checkpoint 显式覆盖\n"
    "  - --model 可作为实验目录锚点，或直接作为 fusion checkpoint 使用\n"
)


def predict_command(
    mode: str = typer.Option(
        ...,
        "--mode",
        help="预测模式：weighted_vote、fusion_nn 或 both。",
    ),
    model: Optional[str] = typer.Option(
        None,
        "--model",
        help="用于推导实验目录或覆盖 fusion checkpoint 的模型路径。",
    ),
    config: Optional[str] = typer.Option(
        None,
        "--config",
        help="配置文件目录路径。提供后可自动解析 axis/fusion checkpoint 及 testset。",
    ),
    data: Optional[str] = typer.Option(
        None,
        "--data",
        help="预测数据目录。支持 data-x/data-y/data-z 根目录，或平铺 PNG 目录。",
    ),
    output: str = typer.Option(
        "output",
        "--output",
        help="预测结果输出目录。",
    ),
    label: Optional[str] = typer.Option(
        None,
        "--label",
        help="可选标签 CSV 路径。未提供且有 --config 时将自动解析 testset/label.csv。",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        help="显示实时预测进度条。",
    ),
    fusion: Optional[str] = typer.Option(
        None,
        "--fusion",
        help="覆盖 fusion 特征合并方式：sum 或 concat。",
    ),
    fusion_threshold: Optional[float] = typer.Option(
        None,
        "--fusion-threshold",
        help="覆盖 fusion_nn 阈值。",
    ),
    axis_checkpoint_x: Optional[str] = typer.Option(None, "--axis-checkpoint-x", help="x 轴 checkpoint 覆盖项。"),
    axis_checkpoint_y: Optional[str] = typer.Option(None, "--axis-checkpoint-y", help="y 轴 checkpoint 覆盖项。"),
    axis_checkpoint_z: Optional[str] = typer.Option(None, "--axis-checkpoint-z", help="z 轴 checkpoint 覆盖项。"),
    fusion_checkpoint: Optional[str] = typer.Option(None, "--fusion-checkpoint", help="fusion checkpoint 覆盖项。"),
    tta: bool = typer.Option(
        False,
        "--tta",
        help="启用 Test-Time Augmentation 预测。",
    ),
    tta_augmentations: Optional[int] = typer.Option(
        None,
        "--tta-augmentations",
        help="每张图像的 TTA 变体数量（包含原图）。未提供时使用配置值，默认配置为 7。",
    ),
):
    """执行患者级双输出预测。"""
    normalized_mode = mode.strip().lower()
    if normalized_mode not in {"weighted_vote", "fusion_nn", "both"}:
        typer.echo("Error: --mode must be one of: weighted_vote, fusion_nn, both")
        raise typer.Exit(code=2)

    if not model and not config:
        typer.echo("Error: one of --model or --config is required")
        raise typer.Exit(code=2)

    predict_runner.execute_predict_args(
        {
            "mode": normalized_mode,
            "model": model,
            "config": config,
            "data": data,
            "output": output,
            "label": label,
            "verbose": verbose,
            "fusion": fusion,
            "fusion_threshold": fusion_threshold,
            "axis_checkpoint_x": axis_checkpoint_x,
            "axis_checkpoint_y": axis_checkpoint_y,
            "axis_checkpoint_z": axis_checkpoint_z,
            "fusion_checkpoint": fusion_checkpoint,
            "tta": tta,
            "tta_augmentations": tta_augmentations,
        }
    )


predict_command.__doc__ = PRED_HELP
