"""Helpers for loading legacy root scripts from the packaged CLI."""

import importlib.util
from pathlib import Path


def load_root_script(module_name: str, filename: str):
    root_path = Path(__file__).resolve().parents[2] / filename
    spec = importlib.util.spec_from_file_location(module_name, root_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"unable to load root script: {root_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
