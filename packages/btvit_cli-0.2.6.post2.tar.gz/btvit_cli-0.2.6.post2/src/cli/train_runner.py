"""Package-safe training execution wrapper."""

from src.cli import train_impl


def execute_train_args(raw_args=None, **kwargs):
    if raw_args is not None and kwargs:
        raise TypeError("Pass either raw_args or keyword overrides, not both")
    if raw_args is None:
        raw_args = kwargs
    return train_impl.execute_train_args(raw_args)
