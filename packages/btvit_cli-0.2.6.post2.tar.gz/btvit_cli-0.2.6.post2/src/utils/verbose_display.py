"""Rich Live display for verbose training: progress bar on top, log panel below."""

import logging
import re
import threading

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    TextColumn,
    TimeElapsedColumn,
)
from rich.text import Text

# Module-level active display singleton.
_active_display = None


def get_active_display():
    return _active_display


def set_active_display(display):
    global _active_display
    _active_display = display


def strip_rich_markup(text):
    """Remove Rich-style markup tags from a string."""
    return re.sub(r"\[/?[^\]]*\]", "", text)


class LiveDisplayLogHandler(logging.Handler):
    """Custom logging handler that feeds messages into the VerboseLiveDisplay."""

    def __init__(self, display):
        super().__init__()
        self.display = display

    def emit(self, record):
        try:
            msg = self.format(record)
            clean = strip_rich_markup(msg)
            self.display.add_log(clean)
        except Exception:
            pass


class VerboseLiveDisplay:
    """Rich Live display with progress bar on top and a scrollable log panel below.

    Layout:
    +---------------------------------------------+
    | [Progress Bar - Epoch Tracking]              |  <- 3 rows
    +---------------------------------------------+
    | Training Log                                 |
    | ... log lines ...                            |  <- 30 rows (scrollable)
    |                                              |
    +---------------------------------------------+
    """

    def __init__(self, max_log_lines=30):
        self.max_log_lines = max_log_lines
        self.log_lines = []
        self._lock = threading.Lock()

        self.progress = Progress(
            TextColumn("[bold blue]{task.description}", justify="right"),
            BarColumn(bar_width=None),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("({task.completed}/{task.total})", justify="right"),
            "  ",
            TextColumn("{task.fields[postfix]}", style="cyan"),
            "  ",
            TimeElapsedColumn(),
            console=Console(stderr=True),
        )
        self.task_id = None
        self.live = None

    # -- lifecycle --

    def start(self, total_epochs, initial=0):
        self.task_id = self.progress.add_task(
            "Epochs", total=total_epochs, completed=initial, postfix=""
        )
        self.live = Live(
            self._build_renderable(),
            refresh_per_second=4,
            console=Console(stderr=True),
            vertical_overflow="visible",
        )
        self.live.start()

    def stop(self):
        if self.live:
            self.live.stop()
            self.live = None

    # -- log panel --

    def add_log(self, message):
        with self._lock:
            self.log_lines.append(message)
            if len(self.log_lines) > self.max_log_lines * 3:
                self.log_lines = self.log_lines[-self.max_log_lines * 2:]
        self._refresh()

    # -- progress bar --

    def update_progress(self, advance=0, postfix="", **kwargs):
        if self.task_id is not None:
            update_kwargs = {}
            if advance:
                update_kwargs["advance"] = advance
            if postfix:
                update_kwargs["postfix"] = postfix
            update_kwargs.update(kwargs)
            self.progress.update(self.task_id, **update_kwargs)
        self._refresh()

    def set_postfix(self, text):
        self.update_progress(postfix=text)

    # -- rendering --

    def _refresh(self):
        if self.live:
            self.live.update(self._build_renderable())

    def _build_renderable(self):
        from rich.console import Group
        panel = self._build_log_panel()
        group = Group(self.progress, panel)
        return group

    def _build_log_panel(self):
        with self._lock:
            visible = self.log_lines[-self.max_log_lines:]
        content = Text("\n".join(visible), style="white")
        return Panel(
            content,
            title="[bold]Training Log[/]",
            border_style="blue",
            height=self.max_log_lines + 2,
            padding=(0, 1),
        )
