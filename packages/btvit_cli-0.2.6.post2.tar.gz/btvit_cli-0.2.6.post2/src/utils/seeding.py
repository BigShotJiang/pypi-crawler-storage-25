import os
import random
from dataclasses import dataclass
from typing import Any

import numpy as np
import torch


@dataclass
class ResolvedTrainingSeeds:
    global_seed: int
    init_mode: str
    init_seed: int
    train_split_seed: int
    csv_split_seed: int


def _get_arg(args: Any, name: str, default=None):
    return getattr(args, name, default) if args is not None else default


def normalize_init_mode(value: Any) -> str:
    normalized = str(value or "same").strip().lower()
    if normalized not in {"same", "random"}:
        raise ValueError("--init must be one of: same, random")
    return normalized


def resolve_training_seeds(config, args=None) -> ResolvedTrainingSeeds:
    training_config = getattr(config, "training", None)
    init_config = getattr(training_config, "init", None)
    split_config = getattr(config, "train_split", None)

    global_seed = _get_arg(args, "random_seed", None)
    if global_seed is None:
        global_seed = getattr(training_config, "random_seed", 42)
    global_seed = int(global_seed if global_seed is not None else 42)

    init_seed = _get_arg(args, "init_seed", None)
    if init_seed is None:
        init_seed = getattr(init_config, "init_seed", None)
    init_seed = int(init_seed if init_seed is not None else global_seed)

    train_split_seed = _get_arg(args, "train_split_seed", None)
    if train_split_seed is None:
        train_split_seed = getattr(split_config, "train_split_random_seed", getattr(split_config, "random_seed", None))
    train_split_seed = int(train_split_seed if train_split_seed is not None else global_seed)

    csv_split_seed = _get_arg(args, "csv_split_seed", None)
    if csv_split_seed is None:
        csv_split_seed = getattr(split_config, "csv_split_random_seed", None)
    csv_split_seed = int(csv_split_seed if csv_split_seed is not None else global_seed)

    init_mode = normalize_init_mode(_get_arg(args, "init", getattr(init_config, "init_mode", "same")))
    return ResolvedTrainingSeeds(
        global_seed=global_seed,
        init_mode=init_mode,
        init_seed=init_seed,
        train_split_seed=train_split_seed,
        csv_split_seed=csv_split_seed,
    )


def apply_runtime_seeding(init_mode: str, seed: int) -> None:
    if normalize_init_mode(init_mode) != "same":
        torch.backends.cudnn.deterministic = False
        torch.backends.cudnn.benchmark = True
        return

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")


def seed_worker(worker_id: int) -> None:
    del worker_id
    worker_seed = torch.initial_seed() % (2 ** 32)
    np.random.seed(worker_seed)
    random.seed(worker_seed)


def make_dataloader_generator(init_mode: str, seed: int) -> torch.Generator | None:
    if normalize_init_mode(init_mode) != "same":
        return None
    generator = torch.Generator()
    generator.manual_seed(seed)
    return generator
