"""Rich-enhanced logger with box-drawing file format and RichHandler console output."""

import logging
import os
import textwrap
from datetime import datetime
from typing import Optional

from rich.console import Console
from rich.logging import RichHandler

from .config import runtime_config_display_sections
from .verbose_display import LiveDisplayLogHandler, get_active_display


class Logger:
    def __init__(self,
                 name: str = "ViT",
                 log_dir: str = "experiments/logs",
                 level: int = logging.INFO,
                 console: bool = True):
        self.name = name
        self.log_dir = log_dir
        self.level = level

        os.makedirs(log_dir, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = os.path.join(log_dir, f"{name}_{timestamp}.log")
        self.log_file = log_file

        logger_name = f"{name}:{os.path.abspath(log_dir)}"
        self.logger = logging.getLogger(logger_name)
        self.logger.setLevel(level)
        self.logger.propagate = False

        for handler in list(self.logger.handlers):
            self.logger.removeHandler(handler)
            handler.close()

        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )

        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        self.logger.addHandler(file_handler)

        self._live_handler: LiveDisplayLogHandler | None = None
        if console:
            display = get_active_display()
            if display is not None:
                self._live_handler = LiveDisplayLogHandler(display)
                self._live_handler.setLevel(level)
                self.logger.addHandler(self._live_handler)
            else:
                rich_handler = RichHandler(
                    console=Console(stderr=True),
                    show_time=True,
                    show_path=False,
                    markup=True,
                )
                rich_handler.setLevel(level)
                self.logger.addHandler(rich_handler)

    def info(self, message: str):
        self.logger.info(message)

    def debug(self, message: str):
        self.logger.debug(message)

    def warning(self, message: str):
        self.logger.warning(message)

    def error(self, message: str):
        self.logger.error(message)

    def critical(self, message: str):
        self.logger.critical(message)

    def flush(self):
        """Flush all file handlers to ensure log content is written to disk."""
        for handler in self.logger.handlers:
            if isinstance(handler, logging.FileHandler):
                handler.flush()

    def close(self):
        """Flush and close all handlers."""
        for handler in list(self.logger.handlers):
            handler.flush()
            handler.close()
            self.logger.removeHandler(handler)

    def log_config(self, config):
        sections = runtime_config_display_sections(config)

        console_handlers = [
            h for h in self.logger.handlers
            if isinstance(h, (RichHandler, LiveDisplayLogHandler))
        ]
        for h in console_handlers:
            h.setLevel(logging.CRITICAL + 1)

        width = 60
        hline = "+" + "-" * (width - 2) + "+"

        self.info(hline)
        self.info("| {:<{w}} |".format("ViT Training Configuration", w=width - 4))
        self.info(hline)

        first = True
        for section_name, items in sections.items():
            if not first:
                self.info(hline)
            first = False
            self.info("| {:<{w}} |".format(section_name, w=width - 4))

            if isinstance(items, dict):
                for key, value in items.items():
                    for line in self._wrap_box_lines(key, value, width):
                        self.info(line)

        self.info(hline)
        self.flush()

        for h in console_handlers:
            h.setLevel(self.level)

    @staticmethod
    def _wrap_box_lines(key: str, value: object, width: int) -> list:
        """Wrap a key-value pair into box-formatted lines without truncation."""
        inner_w = width - 4
        val_str = str(value)
        key_part = f"  {key}: "
        if len(key_part) + len(val_str) <= inner_w:
            pad = " " * (inner_w - len(key_part) - len(val_str))
            return ["| " + key_part + val_str + pad + " |"]
        pad1 = " " * (inner_w - len(key_part))
        lines = ["| " + key_part + pad1 + " |"]
        wrap_w = max(20, inner_w - 2)
        for wl in textwrap.wrap(val_str, width=wrap_w):
            pad2 = " " * max(0, inner_w - 3 - len(wl))
            lines.append("|   " + wl + pad2 + " |")
        return lines

    def log_metrics(self, metrics: dict, step: Optional[int] = None):
        prefix = f"[Step {step}] " if step is not None else ""
        parts = []
        for key, value in metrics.items():
            if isinstance(value, float):
                parts.append(f"{key}={value:.4f}")
            else:
                parts.append(f"{key}={value}")
        self.info(prefix + " | ".join(parts))

    def log_model_summary(self, model):
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

        self.info("+" + "-" * 56 + "+")
        self.info("| {:<{w}} |".format("Model Summary", w=56))
        self.info("+" + "-" * 56 + "+")
        self.info("| {:<{w}} |".format(f"  Type:            {type(model).__name__}", w=56))
        self.info("| {:<{w}} |".format(f"  Total params:    {total_params:,}", w=56))
        self.info("| {:<{w}} |".format(f"  Trainable:       {trainable_params:,}", w=56))
        self.info("| {:<{w}} |".format(f"  Size:            {total_params * 4 / 1024 / 1024:.2f} MB", w=56))
        self.info("+" + "-" * 56 + "+")


def get_logger(name: str = "ViT",
               log_dir: str = "experiments/logs",
               level: int = logging.INFO,
               console: bool = True) -> Logger:
    return Logger(name, log_dir, level, console)
