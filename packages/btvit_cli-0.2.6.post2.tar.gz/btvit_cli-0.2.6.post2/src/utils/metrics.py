import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
import numpy as np
from typing import Dict, List, Tuple, Optional


class MetricsCalculator:
    def __init__(self):
        self.reset()

    def reset(self):
        self.predictions = []
        self.targets = []
        self.probabilities = []

    def update(self, outputs: torch.Tensor, targets: torch.Tensor):
        # 确保targets是正确的形状 [batch_size, 1] -> [batch_size]
        original_targets_shape = targets.shape
        if targets.dim() > 1:
            targets = targets.squeeze()
            if targets.dim() == 0:  # 处理单个样本的情况
                targets = targets.unsqueeze(0)

        # 确保outputs是正确的形状
        if outputs.dim() > 1:
            outputs = outputs.squeeze()
            if outputs.dim() == 0:  # 处理单个样本的情况
                outputs = outputs.unsqueeze(0)

        # 计算概率和预测
        probs = torch.sigmoid(outputs)
        preds = (probs > 0.5).float()

        # 确保targets是float类型
        targets = targets.float()

  
        self.predictions.extend(preds.detach().cpu().numpy())
        self.targets.extend(targets.detach().cpu().numpy())
        self.probabilities.extend(probs.detach().cpu().numpy())

    def compute(self) -> Dict[str, float]:
        if len(self.targets) == 0:
            return {}

        predictions = np.array(self.predictions)
        targets = np.array(self.targets)
        probabilities = np.array(self.probabilities)

        if probabilities.ndim == 2:
            probabilities = probabilities[:, 1] if probabilities.shape[1] > 1 else probabilities[:, 0]

        metrics = {}

        try:
            metrics['accuracy'] = accuracy_score(targets, predictions)
        except:
            metrics['accuracy'] = 0.0

        try:
            metrics['precision'] = precision_score(targets, predictions, zero_division=0)
        except:
            metrics['precision'] = 0.0

        try:
            metrics['recall'] = recall_score(targets, predictions, zero_division=0)
        except:
            metrics['recall'] = 0.0

        try:
            metrics['f1'] = f1_score(targets, predictions, zero_division=0)
        except:
            metrics['f1'] = 0.0

        try:
            metrics['auc'] = roc_auc_score(targets, probabilities)
        except:
            metrics['auc'] = 0.5

        try:
            tn, fp, fn, tp = confusion_matrix(targets, predictions, labels=[0, 1]).ravel()
            metrics['true_negative'] = int(tn)
            metrics['false_positive'] = int(fp)
            metrics['false_negative'] = int(fn)
            metrics['true_positive'] = int(tp)

            specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
            sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0.0
            metrics['specificity'] = specificity
            metrics['sensitivity'] = sensitivity
        except:
            metrics['true_negative'] = 0
            metrics['false_positive'] = 0
            metrics['false_negative'] = 0
            metrics['true_positive'] = 0
            metrics['specificity'] = 0.0
            metrics['sensitivity'] = 0.0

        return metrics

    def get_confusion_matrix(self) -> Optional[np.ndarray]:
        if len(self.targets) == 0:
            return None
        return confusion_matrix(self.targets, self.predictions)


class BinaryLoss(nn.Module):
    def __init__(self, loss_type: str = "bce", pos_weight: Optional[float] = None):
        super().__init__()
        self.loss_type = loss_type

        if loss_type == "bce":
            if pos_weight is not None:
                pos_weight_tensor = torch.tensor(pos_weight)
                self.criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight_tensor)
            else:
                self.criterion = nn.BCEWithLogitsLoss()
        elif loss_type == "focal":
            self.criterion = FocalLoss()
        elif loss_type == "weighted_bce":
            self.criterion = WeightedBCELoss()
        else:
            raise ValueError(f"不支持的损失函数类型: {loss_type}")

    def forward(self, outputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        return self.criterion(outputs, targets)

    def __call__(self, outputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        return self.forward(outputs, targets)


class FocalLoss(nn.Module):
    def __init__(self, alpha: float = 1.0, gamma: float = 2.0, reduction: str = 'mean'):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        bce_loss = F.binary_cross_entropy_with_logits(inputs, targets, reduction='none')
        pt = torch.exp(-bce_loss)
        focal_loss = self.alpha * (1 - pt) ** self.gamma * bce_loss

        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        else:
            return focal_loss


class WeightedBCELoss(nn.Module):
    def __init__(self, pos_weight: float = 2.0, neg_weight: float = 1.0):
        super().__init__()
        self.pos_weight = pos_weight
        self.neg_weight = neg_weight

    def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        bce_loss = F.binary_cross_entropy_with_logits(inputs, targets, reduction='none')

        weights = torch.where(targets == 1, self.pos_weight, self.neg_weight)
        weighted_loss = bce_loss * weights

        return weighted_loss.mean()


def calculate_class_weights(targets: torch.Tensor) -> torch.Tensor:
    unique, counts = torch.unique(targets, return_counts=True)
    total = len(targets)

    weights = torch.zeros_like(unique, dtype=torch.float)
    for i, (label, count) in enumerate(zip(unique, counts)):
        weights[i] = total / (2 * count)

    return weights


def get_pos_weight(targets: torch.Tensor) -> float:
    pos_count = (targets == 1).sum().item()
    neg_count = (targets == 0).sum().item()

    if pos_count == 0:
        return 1.0

    return neg_count / pos_count