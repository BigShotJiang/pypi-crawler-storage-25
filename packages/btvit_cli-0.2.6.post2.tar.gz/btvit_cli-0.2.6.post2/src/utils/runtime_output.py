from typing import Dict

from tqdm import tqdm


_SHORT_NAMES = {
    "val_auc": "val_auc",
    "val_loss": "val_loss",
    "val_accuracy": "val_acc",
    "val_f1": "val_f1",
    "predict_accuracy": "predict_acc",
}


def _mode_arrow(mode: str) -> str:
    if mode == "max":
        return "\u2191"
    return "\u2193"


def _short_metric_name(name: str) -> str:
    return _SHORT_NAMES.get(name, name)


def create_prediction_progress(total_steps: int, verbose: bool):
    return tqdm(total=total_steps, disable=not verbose, dynamic_ncols=True)


def format_final_summary(summary: Dict[str, object], paths: Dict[str, str]) -> str:
    summary_parts = [f"{key}={value}" for key, value in summary.items()]
    path_parts = [f"{key}: {value}" for key, value in paths.items()]
    return "\n".join(summary_parts + path_parts)
