"""Rich-formatted terminal output for training config and results."""

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .config import runtime_config_display_sections


def _format_duration(seconds: float) -> str:
    """Format duration as Xh Ym Zs."""
    total = int(seconds)
    hours, remainder = divmod(total, 3600)
    minutes, secs = divmod(remainder, 60)
    parts = []
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    parts.append(f"{secs}s")
    return " ".join(parts)


def print_rich_training_config(config):
    """Print Rich-formatted training configuration panel."""
    console = Console()
    sections = runtime_config_display_sections(config)

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column(style="cyan", justify="right")
    table.add_column()

    first = True
    for section_name, items in sections.items():
        if not first:
            table.add_row()
        first = False
        table.add_row(Text(section_name, style="bold yellow"))
        if isinstance(items, dict):
            for key, value in items.items():
                table.add_row(f"  {key}", str(value))
        else:
            table.add_row(f"  {items}")

    console.print(Panel(table, title="ViT Training Configuration", border_style="blue"))


def print_rich_training_results(config, results, duration_seconds):
    """Print Rich-formatted training results panel."""
    console = Console()

    # Build content lines
    lines = []

    # Duration
    lines.append(("Duration", _format_duration(duration_seconds)))

    # Best model info
    val_history = results.get("val_history", []) or []
    model_selection = getattr(config, "monitoring", None)
    if model_selection is not None:
        ms = getattr(model_selection, "model_selection", {})
        if not isinstance(ms, dict):
            ms = dict(ms or {})
        selection_metric = ms.get("metric", "predict_accuracy")
        selection_mode = ms.get("mode", "max")
    else:
        selection_metric = "predict_accuracy"
        selection_mode = "max"

    best_epoch = None
    best_value = None
    for epoch_index, metrics in enumerate(val_history, start=1):
        if not isinstance(metrics, dict):
            continue
        alias_map = {
            "val_auc": "auc", "val_loss": "loss", "val_accuracy": "accuracy",
            "val_f1": "f1", "predict_accuracy": "predict_accuracy",
        }
        current = metrics.get(selection_metric, metrics.get(alias_map.get(selection_metric, selection_metric)))
        if current is None or not isinstance(current, (int, float)):
            continue
        if best_value is None:
            best_epoch = epoch_index
            best_value = float(current)
        elif selection_mode == "min" and float(current) < best_value:
            best_epoch = epoch_index
            best_value = float(current)
        elif selection_mode != "min" and float(current) > best_value:
            best_epoch = epoch_index
            best_value = float(current)

    if best_value is not None and best_epoch is not None:
        arrow = "\u2191" if selection_mode != "min" else "\u2193"
        lines.append(("Best Model", f"Epoch {best_epoch}, {selection_metric}{arrow}={best_value:.4f}"))

    # Test metrics
    test_metrics = results.get("test_metrics", {}) or {}
    metric_parts = []
    for name in ("predict_accuracy", "accuracy", "precision", "recall", "f1", "auc", "loss"):
        val = test_metrics.get(name)
        if val is not None and isinstance(val, (int, float)):
            import math
            if math.isfinite(float(val)):
                metric_parts.append(f"{name}={float(val):.4f}")
    if metric_parts:
        lines.append(("Test Metrics", ", ".join(metric_parts)))

    # Result directory
    experiment = getattr(config, "experiment", None)
    if experiment is not None:
        result_dir = getattr(experiment, "result_dir", None)
        if result_dir:
            lines.append(("Results", result_dir))

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column(style="cyan", justify="right")
    table.add_column()
    for label, value in lines:
        table.add_row(f"{label}:", str(value))

    console.print(Panel(table, title="Training Results", border_style="green"))
