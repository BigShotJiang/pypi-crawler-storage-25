import yaml
import os
import torch
from typing import Dict, Any, Optional
from dataclasses import dataclass, asdict, field, fields, is_dataclass


@dataclass
class ModelConfig:
    """ViT模型配置类

    包含Vision Transformer的所有结构和超参数设置。
    基于N维Rotary Position Embedding的ViT实现。
    """

    # 基本模型信息
    name: str = "ViTND"  # 模型名称，用于标识不同的ViT变体
    ndim: int = 2  # 数据维度，2D表示图像数据

    # 输入和补丁配置
    input_shape: list = None  # 输入图像尺寸 [高度, 宽度]，默认[16, 368]
    patch_size: list = None  # 补丁尺寸 [高度, 宽度]，默认[16, 16]

    # 模型结构参数
    num_classes: int = 1  # 输出类别数，1表示二分类（输出概率）
    dim: int = 512  # Transformer模型的隐藏层维度
    depth: int = 6  # Transformer编码器的层数
    heads: int = 8  # 多头注意力机制的头数
    mlp_dim: int = 2048  # 前馈神经网络层的维度

    # 数据处理参数
    channels: int = 1  # 输入通道数，1表示灰度图像
    dim_head: int = 64  # 每个注意力头的维度

    # 正则化参数
    dropout: float = 0.1  # Dropout层丢弃概率
    emb_dropout: float = 0.1  # 嵌入层丢弃概率

    # Rotary位置编码参数
    rope_min_freq: float = 1.0  # Rotary位置编码的最小频率
    rope_max_freq: float = 10000.0  # Rotary位置编码的最大频率
    rope_p_zero_freqs: float = 0.0  # 设置为零频率的比例

    def __post_init__(self):
        if self.input_shape is None:
            self.input_shape = [16, 368]
        if self.patch_size is None:
            self.patch_size = [16, 16]


@dataclass
class DataConfig:
    """数据配置类

    包含数据路径、数据加载参数和内存预加载设置。
    控制数据的读取、预处理和加载器行为。
    """

    # 数据路径配置
    data_path: str = "dataset/data"  # 图像数据根目录路径
    label_path: str = "dataset/label.csv"  # 标签文件路径（CSV格式）

    # 数据加载配置
    batch_size: int = 32  # 批次大小，每个批次包含的样本数量
    num_workers: int = 8  # 数据加载器工作进程数，用于并行数据加载
    pin_memory: bool = True  # 是否将数据锁定在内存中，提高GPU传输效率
    shuffle: bool = True  # 是否打乱数据顺序，训练时启用以提高泛化能力

    # 内存预加载配置
    enable_memory_preload: bool = True  # 是否启用内存预加载，将所有数据预加载到内存中
    preload_batch_size: Optional[int] = None  # 分批预加载的大小，None表示一次性加载所有数据
    preload_verbose: bool = True  # 是否显示预加载过程的详细信息


@dataclass
class PatientPoolingConfig:
    image_feature_pooling: str = "mean"
    image_probability_pooling: str = "mean"


@dataclass
class WeightedVoteConfig:
    enabled: bool = True


@dataclass
class FusionHeadConfig:
    enabled: bool = True
    fusion: str = "concat"
    type: str = "linear"
    hidden_dim: int = 256
    dropout: float = 0.2


@dataclass
class MultiAxisConfig:
    """多轴配置类"""

    enabled: bool = False
    axis_data_paths: Dict[str, str] = field(default_factory=lambda: {
        "x": "dataset/data-x",
        "y": "dataset/data-y",
        "z": "dataset/data-z",
    })
    origin_axis_data_paths: Dict[str, str] = field(default_factory=lambda: {
        "x": "dataset/origin-data-x",
        "y": "dataset/origin-data-y",
        "z": "dataset/origin-data-z",
    })
    active_axes: list = field(default_factory=lambda: ["x", "y", "z"])
    patient_pooling: PatientPoolingConfig = field(default_factory=PatientPoolingConfig)
    weighted_vote: WeightedVoteConfig = field(default_factory=WeightedVoteConfig)
    fusion_head: FusionHeadConfig = field(default_factory=FusionHeadConfig)


def _get_default_scheduler_params(scheduler: str, epochs: int) -> Dict[str, Any]:
    defaults = {
        "CosineAnnealingLR": {
            "T_max": epochs,
            "eta_min": 1e-7,
        },
        "CosineAnnealingWarmRestarts": {
            "T_0": 10,
            "T_mult": 2,
            "eta_min": 1e-7,
        },
        "StepLR": {
            "step_size": max(1, epochs // 3),
            "gamma": 0.1,
        },
    }
    return defaults.get(scheduler, {})


@dataclass
class TrainingCommonConfig:
    device: str = "cuda"
    num_workers: int = 8
    mixed_precision: bool = True
    gradient_clip_val: float = 1.0
    accumulate_grad_batches: int = 1
    debug_logging: bool = False

    def refresh_runtime_defaults(self):
        if self.device == "auto":
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        elif str(self.device).startswith("cuda") and not torch.cuda.is_available():
            self.device = "cpu"


@dataclass
class InitConfig:
    init_mode: str = "same"
    init_seed: Optional[int] = None


@dataclass
class MixUpConfig:
    enabled: bool = False
    alpha: float = 0.2


@dataclass
class TTAConfig:
    enabled: bool = False
    num_augmentations: int = 7
    transforms: Dict[str, Any] = field(default_factory=lambda: {
        "horizontal_flip": {"enabled": True},
        "brightness_contrast": {
            "enabled": True,
            "brightness_range": [0.9, 1.1],
            "contrast_range": [0.9, 1.1],
        },
        "gaussian_noise": {
            "enabled": True,
            "std_min": 0.01,
            "std_max": 0.03,
        },
    })


@dataclass
class HardExampleMiningConfig:
    enabled: bool = False
    start_epoch: int = 30
    weight_factor: float = 2.0
    update_interval: int = 10
    top_percentile: float = 80.0


@dataclass
class AxisTrainingStageConfig:
    epochs: int = 10
    learning_rate: float = 1e-4
    weight_decay: float = 0.01
    optimizer: str = "AdamW"
    scheduler: str = "CosineAnnealingLR"
    scheduler_params: Dict[str, Any] = field(default_factory=dict)
    batch_size: int = 32
    pretrained_model_path: str = ""
    load_weights_only: bool = False
    strict_load: bool = False
    freeze_method: str = "none"
    freeze_layers: str = ""
    freeze_ratio: float = 0.0
    finetune_lr_scale: float = 1.0
    use_differential_lr: bool = False
    balanced_sampling: bool = False
    hard_example_mining: HardExampleMiningConfig = field(default_factory=HardExampleMiningConfig)
    loss: Dict[str, Any] = field(default_factory=dict)
    augmentation: Dict[str, Any] = field(default_factory=dict)
    # Per-axis override dicts (populated from YAML x/y/z keys)
    x: Dict[str, Any] = field(default_factory=dict)
    y: Dict[str, Any] = field(default_factory=dict)
    z: Dict[str, Any] = field(default_factory=dict)

    def refresh_runtime_defaults(self):
        if not self.scheduler:
            self.scheduler_params = {}
        elif not self.scheduler_params:
            self.scheduler_params = _get_default_scheduler_params(self.scheduler, self.epochs)


# Per-axis override key set
AXIS_OVERRIDE_KEYS = {"x", "y", "z"}


def deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base dict (mutates base)."""
    for key, value in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def merge_axis_config(axis_defaults: dict, axis_name: str) -> dict:
    """Merge axis shared defaults with per-axis overrides (operates on raw dicts)."""
    shared = {k: v for k, v in axis_defaults.items() if k not in AXIS_OVERRIDE_KEYS}
    overrides = axis_defaults.get(axis_name, {})
    if not overrides:
        return dict(shared)
    result = dict(shared)
    deep_merge(result, overrides)
    return result


def apply_axis_overrides(config, axis: str):
    """Apply per-axis overrides to the live config object.

    Reads x/y/z override dicts from AxisTrainingStageConfig,
    deep-merges with shared defaults, and writes merged values back.
    Called from train_axis() before CLI overrides.
    """
    stage_cfg = config.training.axis

    # Build shared defaults dict from current dataclass values
    shared = {}
    for fld in fields(stage_cfg):
        if fld.name not in AXIS_OVERRIDE_KEYS:
            shared[fld.name] = getattr(stage_cfg, fld.name)

    # Get overrides for target axis
    overrides = getattr(stage_cfg, axis, {})
    if not overrides:
        return

    # Deep-merge
    merged = deep_merge(dict(shared), overrides)

    # When scheduler type is overridden, do NOT inherit default scheduler_params
    # (e.g. CosineAnnealing's T_max/eta_min would crash OneCycleLR/ReduceLROnPlateau)
    if 'scheduler' in overrides and overrides.get('scheduler') != shared.get('scheduler'):
        if 'scheduler_params' in overrides:
            merged['scheduler_params'] = overrides['scheduler_params']
        else:
            merged['scheduler_params'] = {}

    # Write merged values back
    for key, value in merged.items():
        if hasattr(stage_cfg, key) and key not in AXIS_OVERRIDE_KEYS:
            setattr(stage_cfg, key, value)

    # Clear override dicts
    for ax in AXIS_OVERRIDE_KEYS:
        setattr(stage_cfg, ax, {})

    # Refresh runtime defaults
    stage_cfg.refresh_runtime_defaults()


@dataclass
class FusionTrainingStageConfig:
    epochs: int = 50
    learning_rate: float = 1e-3
    weight_decay: float = 0.0
    optimizer: str = "AdamW"
    scheduler: str = "CosineAnnealingLR"
    scheduler_params: Dict[str, Any] = field(default_factory=dict)
    batch_size: int = 8
    freeze_encoders: bool = True

    def refresh_runtime_defaults(self):
        if not self.scheduler:
            self.scheduler_params = {}
        elif not self.scheduler_params:
            self.scheduler_params = _get_default_scheduler_params(self.scheduler, self.epochs)


@dataclass
class TrainingConfig:
    """训练配置类

    包含训练过程的所有参数设置，包括优化器、学习率调度器、
    早停机制等。控制模型的训练流程和性能优化。
    """

    random_seed: int = 42
    init: InitConfig = field(default_factory=InitConfig)
    tta: TTAConfig = field(default_factory=TTAConfig)
    mixup: MixUpConfig = field(default_factory=MixUpConfig)
    common: TrainingCommonConfig = field(default_factory=TrainingCommonConfig)
    axis: AxisTrainingStageConfig = field(default_factory=AxisTrainingStageConfig)
    fusion: FusionTrainingStageConfig = field(default_factory=FusionTrainingStageConfig)

    _COMMON_PROXY_FIELDS = {
        "device",
        "num_workers",
        "mixed_precision",
        "gradient_clip_val",
        "accumulate_grad_batches",
        "debug_logging",
    }
    _STAGE_PROXY_FIELDS = {
        "epochs",
        "learning_rate",
        "weight_decay",
        "optimizer",
        "scheduler",
        "scheduler_params",
        "batch_size",
        "pretrained_model_path",
        "load_weights_only",
        "strict_load",
        "freeze_method",
        "freeze_layers",
        "freeze_ratio",
        "finetune_lr_scale",
        "use_differential_lr",
        "balanced_sampling",
        "hard_example_mining",
        "loss",
    }

    def __post_init__(self):
        self.refresh_runtime_defaults()

    def _runtime_stage(self) -> str:
        parent_config = getattr(self, "_parent_config", None)
        experiment = getattr(parent_config, "experiment", None)
        stage = getattr(experiment, "runtime_stage", "axis")
        return "fusion" if stage == "fusion" else "axis"

    def _runtime_stage_config(self):
        return self.fusion if self._runtime_stage() == "fusion" else self.axis

    def __getattr__(self, name: str):
        if name in self._COMMON_PROXY_FIELDS:
            return getattr(self.common, name)
        if name in self._STAGE_PROXY_FIELDS:
            return getattr(self._runtime_stage_config(), name)
        raise AttributeError(f"{type(self).__name__!s} object has no attribute {name!r}")

    def __setattr__(self, name: str, value):
        if name in {"common", "axis", "fusion", "tta"}:
            object.__setattr__(self, name, value)
            return
        if "common" in self.__dict__ and name in self._COMMON_PROXY_FIELDS:
            setattr(self.common, name, value)
            return
        if "axis" in self.__dict__ and name in self._STAGE_PROXY_FIELDS:
            setattr(self._runtime_stage_config(), name, value)
            return
        object.__setattr__(self, name, value)

    def refresh_runtime_defaults(self):
        self.common.refresh_runtime_defaults()
        self.axis.refresh_runtime_defaults()
        self.fusion.refresh_runtime_defaults()


@dataclass
class ExperimentConfig:
    """实验配置类

    包含实验的基本信息、监控设置、保存配置等。
    控制实验的组织、结果记录和模型监控。
    """

    # 基本实验信息
    name: str = "vit_experiment"  # 实验名称，用于标识不同的实验
    version: str = "1.0"  # 实验版本号
    save_dir: str = "experiments"  # 实验根目录

    # 目录配置
    log_dir: str = "experiments/logs"  # 训练日志保存目录
    checkpoint_dir: str = "experiments/checkpoints"  # 模型检查点保存目录
    result_dir: str = "experiments/results"  # 实验结果保存目录

    # 日志和监控配置
    log_every_n_steps: int = 10  # 日志记录间隔，每多少步记录一次日志
    val_check_interval: float = 1.0  # 验证检查间隔，每多少轮验证一次

    # 模型保存配置
    save_top_k: int = 1  # 保存最佳模型的数量
    save_latest: bool = False  # 每轮保存 latest_model.pth（用于 resume）



@dataclass
class MonitoringStageConfig:
    early_stopping: Dict[str, Any] = field(default_factory=lambda: {
        "enabled": True,
        "metric": "val_loss",
        "mode": "min",
        "patience": 10,
        "min_delta": 0.001,
    })
    model_selection: Dict[str, Any] = field(default_factory=lambda: {
        "metric": "predict_accuracy",
        "mode": "max",
    })


@dataclass
class PredictionMonitoringConfig:
    fusion_nn_threshold: float = 0.5


@dataclass
class MonitoringConfig:
    """训练监控配置类"""

    axis: MonitoringStageConfig = field(default_factory=MonitoringStageConfig)
    fusion: MonitoringStageConfig = field(default_factory=lambda: MonitoringStageConfig(
        early_stopping={
            "enabled": True,
            "metric": "val_auc",
            "mode": "max",
            "patience": 10,
            "min_delta": 0.001,
        },
        model_selection={
            "metric": "val_auc",
            "mode": "max",
        },
    ))
    prediction: PredictionMonitoringConfig = field(default_factory=PredictionMonitoringConfig)
    verbose: bool = False

    def _runtime_stage(self) -> str:
        parent_config = getattr(self, "_parent_config", None)
        experiment = getattr(parent_config, "experiment", None)
        stage = getattr(experiment, "runtime_stage", "axis")
        return "fusion" if stage == "fusion" else "axis"

    def _runtime_stage_config(self) -> MonitoringStageConfig:
        return self.fusion if self._runtime_stage() == "fusion" else self.axis

    @property
    def early_stopping(self) -> Dict[str, Any]:
        return self._runtime_stage_config().early_stopping

    @early_stopping.setter
    def early_stopping(self, value: Dict[str, Any]):
        self._runtime_stage_config().early_stopping = dict(value or {})

    @property
    def model_selection(self) -> Dict[str, Any]:
        return self._runtime_stage_config().model_selection

    @model_selection.setter
    def model_selection(self, value: Dict[str, Any]):
        self._runtime_stage_config().model_selection = dict(value or {})

    @property
    def predict_threshold(self) -> float:
        return float(self.prediction.fusion_nn_threshold)

    @predict_threshold.setter
    def predict_threshold(self, value: float):
        self.prediction.fusion_nn_threshold = float(value)


class TrainSplitConfig:
    """训练集分割配置类

    控制数据集如何分割为训练集、验证集和测试集。支持多种分割策略，
    包括分层分割、随机分割和交叉验证。根据选择的分割方法，
    某些参数可能不会被使用。

    分割方法说明：
    - stratified: 按标签比例分层分割，确保各类别在训练/验证/测试集中的比例一致
    - random: 完全随机分割，不考虑标签分布
    - cv: K折交叉验证，将数据分为K个子集，轮流使用其中一个作为验证集，其余作为训练集
    """

    def __init__(self):
        # 数据集分割策略
        # 可选值: "stratified"(分层分割), "random"(随机分割), "cv"(交叉验证)
        # 默认使用交叉验证方法，能更充分利用数据进行模型评估
        self.method = "cv"

        # 训练集比例 (仅用于stratified和random模式)
        # 表示训练集占总数据集的比例，范围应在0.0-1.0之间
        # 在交叉验证模式下，此参数用于确定每折中训练集的比例
        self.train_ratio = 0.75

        # 验证集比例 (仅用于stratified和random模式)
        # 表示验证集占总数据集的比例，范围应在0.0-1.0之间
        # 在交叉验证模式下，验证集比例 = 1.0 - train_ratio
        self.val_ratio = 0.07

        # 测试集比例 (仅用于random模式)
        # 表示测试集占总数据集的比例，范围应在0.0-1.0之间
        # 在stratified和cv模式下，测试集比例通常设为0，因为验证集已足够用于模型选择
        self.test_ratio = 0.18

        # 随机种子
        # 用于确保数据分割的可重现性
        # 设置相同的种子值可以保证每次运行得到相同的数据分割结果
        # 这对于实验的可重现性和结果对比非常重要
        self.train_split_random_seed = 42

        # 导出与CSV复用配置
        self.export_split_info = True
        self.split_filename = "train_split.csv"
        self.train_split_csv_path = ""
        self.csv_split_random_seed = 42
        self.use_csv_direct = False

        # 交叉验证折数 (仅用于cv模式)
        # 表示将数据集分成多少个子集进行交叉验证
        # 常用值: 5折或10折交叉验证
        # 折数越多，每个验证集越小，但评估结果越稳定
        self.cv_folds = 5

    @property
    def random_seed(self) -> int:
        return self.train_split_random_seed

    @random_seed.setter
    def random_seed(self, value: int):
        self.train_split_random_seed = value

    def get_effective_split_ratios(self):
        """获取有效的分割比例

        根据不同的分割方法计算实际使用的训练、验证、测试集比例。
        特别处理交叉验证模式，自动将测试集比例合并到验证集中，
        以充分利用数据资源。

        Returns:
            dict: 包含 'train', 'val', 'test' 三个键的字典，值为对应的比例

        分割逻辑说明:
        - 交叉验证(cv)模式: 将test_ratio合并到val_ratio中，不保留独立的测试集
        - 分层(stratified)和随机(random)模式: 保持原始比例设置
        - 所有模式的最终比例都会标准化，确保总和为1.0
        """
        if self.method == "cv":
            # 交叉验证模式：将test_ratio合并到val_ratio
            # 这样做可以更充分利用数据，因为交叉验证本身已经提供了可靠的评估
            effective_train_ratio = self.train_ratio
            effective_val_ratio = self.val_ratio + self.test_ratio
            effective_test_ratio = 0.0  # 交叉验证不需要独立的测试集

            # 确保比例总和为1.0，进行标准化处理
            total = effective_train_ratio + effective_val_ratio
            if total != 1.0:
                effective_train_ratio = effective_train_ratio / total
                effective_val_ratio = effective_val_ratio / total

            return {
                'train': effective_train_ratio,
                'val': effective_val_ratio,
                'test': effective_test_ratio
            }
        else:
            # 单次分割模式：保持原比例设置
            # stratified和random模式会按照设定的比例进行分割
            return {
                'train': self.train_ratio,
                'val': self.val_ratio,
                'test': self.test_ratio
            }

    def __str__(self):
        """返回配置的字符串表示

        根据分割方法的不同，返回包含关键配置信息的格式化字符串。
        便于日志记录、调试和配置展示。

        Returns:
            str: 格式化的配置信息字符串
        """
        effective_ratios = self.get_effective_split_ratios()
        if self.method == "cv":
            # 交叉验证模式显示折数和有效分割比例
            return f"TrainSplitConfig(method={self.method}, cv_folds={self.cv_folds}, " \
                   f"train={effective_ratios['train']:.2f}, val={effective_ratios['val']:.2f}, " \
                   f"train_split_random_seed={self.train_split_random_seed})"
        else:
            # 单次分割模式显示原始比例设置
            return f"TrainSplitConfig(method={self.method}, train={self.train_ratio:.2f}, " \
                   f"val={self.val_ratio:.2f}, test={self.test_ratio:.2f}, " \
                   f"train_split_random_seed={self.train_split_random_seed})"


class Config:
    """总配置类

    统一管理项目的所有配置参数，包括模型、数据、训练、实验和数据分割配置。
    支持从YAML文件加载配置，也支持使用默认配置。
    提供配置的保存、更新、字符串化等便利方法。

    Attributes:
        model (ModelConfig): 模型结构配置
        data (DataConfig): 数据处理配置
        training (TrainingConfig): 训练过程配置
        experiment (ExperimentConfig): 实验设置配置
        train_split (TrainSplitConfig): 数据分割配置
    """

    def __init__(self, config_path: Optional[str] = None):
        """初始化配置对象

        Args:
            config_path (Optional[str]): 配置文件路径。
                - 如果为None，使用默认配置
                - 如果是文件路径，从该YAML文件加载配置
                - 如果是目录路径，从该目录下的所有配置文件加载
        """
        # 初始化各个配置模块，使用默认值
        self.model = ModelConfig()        # 模型结构配置
        self.data = DataConfig()          # 数据处理配置
        self.multi_axis = MultiAxisConfig()  # 多轴配置
        self.training = TrainingConfig()  # 训练过程配置
        self.experiment = ExperimentConfig()  # 实验设置配置
        self.monitoring = MonitoringConfig()  # 训练监控配置
        self.train_split = TrainSplitConfig()  # 数据分割配置
        self._attach_runtime_context()

        # 如果提供了配置路径，从文件加载配置
        if config_path:
            self.load_from_yaml(config_path)
        else:
            # 尝试从默认配置目录加载配置文件
            default_config_dir = "configs"
            if os.path.exists(default_config_dir):
                self.load_from_yaml(default_config_dir)

    def _attach_runtime_context(self):
        self.training._parent_config = self
        self.monitoring._parent_config = self

    def load_from_yaml(self, config_path: str):
        """从YAML文件加载配置

        支持从单个YAML文件或目录加载配置。如果是目录，会自动读取目录中的
        所有配置文件并合并到对应的配置模块中。

        Args:
            config_path (str): YAML文件路径或包含配置文件的目录路径
        """
        # 如果传入的是目录，从目录中的所有配置文件加载
        if os.path.isdir(config_path):
            config_files = []
            # 按顺序查找标准配置文件
            for config_name in [
                'model_config.yaml',
                'data_config.yaml',
                'training_config.yaml',
                'experiment_config.yaml',
                'multi_axis_config.yaml',
                'monitoring_config.yaml',
            ]:
                config_file = os.path.join(config_path, config_name)
                if os.path.exists(config_file):
                    config_files.append(config_file)

            # 从每个配置文件加载对应的部分
            for config_file in config_files:
                config_name = os.path.basename(config_file)
                with open(config_file, 'r', encoding='utf-8') as f:
                    config_dict = yaml.safe_load(f) or {}

                # 根据文件名将配置加载到对应的配置模块
                if config_name == 'model_config.yaml' and 'model' in config_dict:
                    self._update_dataclass(self.model, config_dict['model'])
                elif config_name == 'data_config.yaml' and 'data' in config_dict:
                    self._update_dataclass(self.data, config_dict['data'])
                elif config_name == 'multi_axis_config.yaml' and 'multi_axis' in config_dict:
                    self._update_dataclass(self.multi_axis, config_dict['multi_axis'])
                elif config_name == 'monitoring_config.yaml' and 'monitoring' in config_dict:
                    self._update_dataclass(self.monitoring, config_dict['monitoring'])
                elif config_name == 'training_config.yaml':
                    training_source = dict(config_dict)
                    nested_training = training_source.pop('training', {})
                    if isinstance(nested_training, dict):
                        training_source.update(nested_training)
                    if 'train_split' in config_dict:
                        self._update_dataclass(self.train_split, config_dict['train_split'])
                    self._update_dataclass(self.training, training_source)
                    self.training.refresh_runtime_defaults()
                elif config_name == 'experiment_config.yaml':
                    # 直接使用实验配置文件的字段，不需要嵌套结构
                    self._update_dataclass(self.experiment, config_dict)
                elif 'experiment' in config_dict:
                    # 兼容嵌套的experiment结构
                    self._update_dataclass(self.experiment, config_dict['experiment'])
        else:
            # 单个配置文件处理
            with open(config_path, 'r', encoding='utf-8') as f:
                config_dict = yaml.safe_load(f) or {}

            # 加载模型配置
            if 'model' in config_dict:
                self._update_dataclass(self.model, config_dict['model'])

            # 加载数据配置
            if 'data' in config_dict:
                self._update_dataclass(self.data, config_dict['data'])

            if 'multi_axis' in config_dict:
                self._update_dataclass(self.multi_axis, config_dict['multi_axis'])

            if 'monitoring' in config_dict:
                self._update_dataclass(self.monitoring, config_dict['monitoring'])

            # 处理training相关的字段（支持混合结构）
            merged_training = dict(config_dict)
            nested_training = merged_training.pop('training', {})
            if isinstance(nested_training, dict):
                merged_training.update(nested_training)
            for key, value in merged_training.items():
                if key == 'train_split':
                    self._update_dataclass(self.train_split, value)
                elif hasattr(self.training, key):
                    current_value = getattr(self.training, key)
                    if isinstance(value, dict) and is_dataclass(current_value):
                        self._update_dataclass(current_value, value)
                    else:
                        setattr(self.training, key, value)
            self.training.refresh_runtime_defaults()

            # 加载实验配置
            if 'experiment' in config_dict:
                self._update_dataclass(self.experiment, config_dict['experiment'])


    def _update_dataclass(self, dataclass_instance, data_dict: Dict[str, Any]):
        """更新数据类实例的属性

        使用字典中的值更新数据类实例的对应属性。只有当数据类实例
        具有某个属性时才会进行更新，避免了意外的属性添加。

        Args:
            dataclass_instance: 要更新的数据类实例
            data_dict (Dict[str, Any]): 包含更新值的字典
        """
        for key, value in data_dict.items():
            if hasattr(dataclass_instance, key):
                current_value = getattr(dataclass_instance, key)
                if isinstance(value, dict) and is_dataclass(current_value):
                    self._update_dataclass(current_value, value)
                else:
                    setattr(dataclass_instance, key, value)

    def save_to_yaml(self, config_path: str):
        """将配置保存到YAML文件

        将所有配置模块的内容保存到一个YAML文件中，包含嵌套的
        model、data、training、experiment结构。

        Args:
            config_path (str): 输出YAML文件的路径
        """
        config_dict = {
            'model': asdict(self.model),
            'data': asdict(self.data),
            'multi_axis': asdict(self.multi_axis),
            'training': asdict(self.training),
            'experiment': asdict(self.experiment),
            'monitoring': asdict(self.monitoring)
        }

        # 确保输出目录存在
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        # 写入YAML文件，使用UTF-8编码确保中文注释正常显示
        with open(config_path, 'w', encoding='utf-8') as f:
            yaml.dump(config_dict, f, default_flow_style=False, allow_unicode=True)

    def update(self, **kwargs):
        """批量更新配置

        支持通过关键字参数批量更新配置模块。参数名应该对应
        配置模块的名称（model、data、training、experiment等），
        参数值应该是对应的配置字典。

        Args:
            **kwargs: 配置更新参数，格式为 section_name=config_dict
        """
        for section_name, section_dict in kwargs.items():
            if hasattr(self, section_name) and isinstance(section_dict, dict):
                section = getattr(self, section_name)
                self._update_dataclass(section, section_dict)

    def __str__(self) -> str:
        """返回配置的字符串表示

        提供配置关键信息的简洁摘要，便于快速了解当前配置状态。
        包含模型名称、输入形状、批次大小、学习率和设备等核心参数。

        Returns:
            str: 配置信息的格式化字符串
        """
        return f"Config:\n" \
               f"  Model: {self.model.name}\n" \
               f"  Input Shape: {self.model.input_shape}\n" \
               f"  Patch Size: {self.model.patch_size}\n" \
               f"  Batch Size: {self.data.batch_size}\n" \
               f"  Learning Rate: {self.training.learning_rate}\n" \
               f"  Device: {self.training.device}"


def load_config(config_path: str) -> Config:
    """加载配置文件的便利函数

    提供一个简单的接口来加载配置文件，自动判断是目录还是单个文件。
    如果文件不存在会抛出FileError异常。

    Args:
        config_path (str): 配置文件路径或包含配置文件的目录路径

    Returns:
        Config: 初始化完成的配置对象

    Raises:
        FileNotFoundError: 当配置文件不存在时抛出
    """
    # 如果传入的是目录，直接传递目录路径给Config构造函数
    if os.path.isdir(config_path):
        return Config(config_path)
    else:
        # 单个配置文件处理
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"配置文件不存在: {config_path}")
        return Config(config_path)


def _flatten_nested(obj, prefix: str = "") -> Dict[str, Any]:
    """Flatten a dataclass or dict into dotted keys."""
    result = {}
    if isinstance(obj, dict):
        items = obj.items()
    elif hasattr(obj, "__dataclass_fields__"):
        items = {k: v for k, v in vars(obj).items() if not k.startswith("_")}.items()
    else:
        return {prefix: obj} if prefix else {}
    for key, value in items:
        full_key = f"{prefix}.{key}" if prefix else key
        if hasattr(value, "__dataclass_fields__") and not isinstance(value, (str, list, tuple)):
            result.update(_flatten_nested(value, full_key))
        elif isinstance(value, dict):
            result[full_key] = value
        else:
            result[full_key] = value
    return result


# Whitelists mirror vit get templates exactly
_MODEL_FIELDS = {
    "name", "ndim", "input_shape", "patch_size", "num_classes",
    "dim", "depth", "heads", "mlp_dim", "channels", "dim_head",
    "dropout", "emb_dropout", "rope_min_freq", "rope_max_freq", "rope_p_zero_freqs",
}
_DATA_FIELDS = {"pin_memory", "enable_memory_preload", "preload_batch_size", "preload_verbose"}
_TRAINING_COMMON_FIELDS = {
    "device", "num_workers", "mixed_precision", "gradient_clip_val",
    "accumulate_grad_batches", "debug_logging",
}
_TRAINING_TOP_LEVEL_FIELDS = {"random_seed"}
_TRAINING_AXIS_FIELDS = {
    "epochs", "learning_rate", "weight_decay", "optimizer", "scheduler",
    "scheduler_params", "batch_size", "pretrained_model_path",
    "load_weights_only", "strict_load", "freeze_method", "freeze_layers",
    "freeze_ratio", "finetune_lr_scale", "use_differential_lr",
    "balanced_sampling", "hard_example_mining", "loss", "augmentation",
}
_TRAINING_FUSION_FIELDS = {
    "epochs", "learning_rate", "weight_decay", "optimizer", "scheduler",
    "scheduler_params", "batch_size", "freeze_encoders",
}
_EXPERIMENT_FIELDS = {
    "name", "version", "save_dir", "log_dir", "checkpoint_dir", "result_dir",
    "log_every_n_steps", "val_check_interval", "save_top_k", "save_latest",
}
_MULTI_AXIS_TOP_FIELDS = {"enabled", "axis_data_paths", "origin_axis_data_paths", "active_axes"}
_MULTI_AXIS_FLATTEN_KEYS = {
    "patient_pooling.image_feature_pooling", "patient_pooling.image_probability_pooling",
    "weighted_vote.enabled",
    "fusion_head.enabled", "fusion_head.fusion", "fusion_head.type", "fusion_head.hidden_dim", "fusion_head.dropout",
}
_SPLIT_FIELDS = {
    "method", "train_ratio", "val_ratio", "test_ratio", "train_split_random_seed",
    "export_split_info", "split_filename", "train_split_csv_path",
    "csv_split_random_seed", "use_csv_direct",
}


def _filtered_attrs(obj, allowed: set) -> Dict[str, Any]:
    """Return public attrs filtered by whitelist."""
    return {
        k: v for k, v in vars(obj).items()
        if not k.startswith("_") and k in allowed
    }


def runtime_config_display_sections(config) -> Dict[str, Dict[str, Any]]:
    runtime_stage = getattr(getattr(config, "experiment", None), "runtime_stage", "axis")
    stage_training = getattr(getattr(config, "training", None), runtime_stage, getattr(config, "training", None))

    # Build training config: merge common + stage-specific
    training_section = {}
    training_section.update(_filtered_attrs(config.training, _TRAINING_TOP_LEVEL_FIELDS))
    training_section["init.init_mode"] = getattr(getattr(config.training, "init", None), "init_mode", "same")
    training_section["init.init_seed"] = getattr(getattr(config.training, "init", None), "init_seed", None)
    training_section["tta.enabled"] = bool(getattr(getattr(config.training, "tta", None), "enabled", False))
    training_section["tta.num_augmentations"] = int(
        getattr(getattr(config.training, "tta", None), "num_augmentations", 7)
    )
    training_section.update(_filtered_attrs(config.training.common, _TRAINING_COMMON_FIELDS))
    stage_fields = _TRAINING_FUSION_FIELDS if runtime_stage == "fusion" else _TRAINING_AXIS_FIELDS
    training_section.update(_filtered_attrs(stage_training, stage_fields))

    # Build multi-axis config: top-level + flattened nested
    ma_top = _filtered_attrs(config.multi_axis, _MULTI_AXIS_TOP_FIELDS)
    ma_flat = {}
    for key, value in _flatten_nested(config.multi_axis).items():
        if key in _MULTI_AXIS_FLATTEN_KEYS:
            ma_flat[key] = value

    return {
        "MODEL CONFIG": _filtered_attrs(config.model, _MODEL_FIELDS),
        "DATA CONFIG": _filtered_attrs(config.data, _DATA_FIELDS),
        "TRAINING CONFIG": training_section,
        "TRAIN SPLIT CONFIG": _filtered_attrs(config.train_split, _SPLIT_FIELDS),
        "EXPERIMENT CONFIG": _filtered_attrs(config.experiment, _EXPERIMENT_FIELDS),
        "MULTI-AXIS CONFIG": {**ma_top, **ma_flat},
        "MONITORING CONFIG": {
            "early_stopping": dict(getattr(config.monitoring, "early_stopping", {}) or {}),
            "model_selection": dict(getattr(config.monitoring, "model_selection", {}) or {}),
            "prediction": {
                "fusion_nn_threshold": float(getattr(config.monitoring.prediction, "fusion_nn_threshold", 0.5)),
            },
            "verbose": bool(getattr(config.monitoring, "verbose", False)),
        },
    }


def create_default_configs():
    """创建默认配置文件

    在configs目录下创建四个标准的配置文件：
    - model_config.yaml: 模型结构配置
    - data_config.yaml: 数据处理配置
    - training_config.yaml: 训练过程配置
    - experiment_config.yaml: 实验设置配置

    每个文件都包含详细的中文注释和合理的默认值。
    """
    from src.cli.utils import export_cli_templates

    export_cli_templates("configs")
    return

    # 创建默认配置对象
    config = Config()

    # 确保配置目录存在
    os.makedirs("configs", exist_ok=True)

    # 定义各配置文件的路径
    model_config_path = "configs/model_config.yaml"
    data_config_path = "configs/data_config.yaml"
    training_config_path = "configs/training_config.yaml"
    experiment_config_path = "configs/experiment_config.yaml"

    # 创建模型配置文件
    with open(model_config_path, 'w', encoding='utf-8') as f:
        f.write("# 模型配置文件 (model_config.yaml)\n")
        f.write("# 用于配置ViT模型的结构参数\n")
        f.write("# 包括输入输出尺寸、Transformer架构参数、正则化设置等\n\n")
        f.write("# ============================================================================\n")
        f.write("# ViT模型配置\n")
        f.write("# ============================================================================\n\n")
        f.write("model:\n")

        # 手动写入每个模型参数并添加详细注释
        f.write("  # 模型名称\n")
        f.write("  # 用于标识不同的ViT模型变体\n")
        f.write(f"  name: \"{config.model.name}\"\n\n")

        f.write("  # 数据维度\n")
        f.write("  # 2D表示图像数据，支持二维空间关系\n")
        f.write(f"  ndim: {config.model.ndim}\n\n")

        f.write("  # 输入图像尺寸\n")
        f.write("  # [高度, 宽度]，当前为16x368像素的医学图像\n")
        f.write("  input_shape:\n")
        f.write(f"    - {config.model.input_shape[0]}\n")
        f.write(f"    - {config.model.input_shape[1]}\n\n")

        f.write("  # 补丁尺寸\n")
        f.write("  # [高度, 宽度]，将输入图像分割为16x16的小块\n")
        f.write("  patch_size:\n")
        f.write(f"    - {config.model.patch_size[0]}\n")
        f.write(f"    - {config.model.patch_size[1]}\n\n")

        f.write("  # 输出类别数\n")
        f.write("  # 1表示二分类，输出阳性概率值\n")
        f.write(f"  num_classes: {config.model.num_classes}\n\n")

        f.write("  # Transformer隐藏层维度\n")
        f.write("  # 控制模型的表达能力，建议值：256-1024\n")
        f.write(f"  dim: {config.model.dim}\n\n")

        f.write("  # Transformer编码器层数\n")
        f.write("  # 模型深度，层数越多表达能力越强但计算量越大\n")
        f.write(f"  depth: {config.model.depth}\n\n")

        f.write("  # 多头注意力机制的头数\n")
        f.write("  # 并行注意力头的数量，建议能被dim整除\n")
        f.write(f"  heads: {config.model.heads}\n\n")

        f.write("  # 前馈神经网络层维度\n")
        f.write("  # 通常设为dim的4倍，即2048\n")
        f.write(f"  mlp_dim: {config.model.mlp_dim}\n\n")

        f.write("  # 输入通道数\n")
        f.write("  # 1表示灰度图像，3表示RGB彩色图像\n")
        f.write(f"  channels: {config.model.channels}\n\n")

        f.write("  # 每个注意力头的维度\n")
        f.write("  # dim // heads，建议值：32-128\n")
        f.write(f"  dim_head: {config.model.dim_head}\n\n")

        f.write("  # Dropout层丢弃概率\n")
        f.write("  # 防止过拟合，建议值：0.1-0.3\n")
        f.write(f"  dropout: {config.model.dropout}\n\n")

        f.write("  # 嵌入层丢弃概率\n")
        f.write("  # 对位置编码进行dropout，建议值：0.1-0.2\n")
        f.write(f"  emb_dropout: {config.model.emb_dropout}\n\n")

        f.write("  # Rotary位置编码最小频率\n")
        f.write("  # 控制位置编码的频率范围下限\n")
        f.write(f"  rope_min_freq: {config.model.rope_min_freq}\n\n")

        f.write("  # Rotary位置编码最大频率\n")
        f.write("  # 控制位置编码的频率范围上限\n")
        f.write(f"  rope_max_freq: {config.model.rope_max_freq}\n\n")

        f.write("  # 设置为零频率的比例\n")
        f.write("  # 用于控制位置编码的分布特性\n")
        f.write(f"  rope_p_zero_freqs: {config.model.rope_p_zero_freqs}\n")

    # 创建数据配置文件
    with open(data_config_path, 'w', encoding='utf-8') as f:
        f.write("# 数据配置文件 (data_config.yaml)\n")
        f.write("# 用于配置数据加载辅助选项\n")
        f.write("# 包括内存预加载、pin_memory 等共享数据管线参数\n\n")
        f.write("# ============================================================================\n")
        f.write("# 数据配置\n")
        f.write("# ============================================================================\n\n")
        f.write("data:\n")

        f.write("  # 是否将数据锁定在内存中\n")
        f.write("  # 启用后可以提高GPU数据传输效率\n")
        f.write(f"  pin_memory: {config.data.pin_memory}\n\n")

        f.write("  # ============================================================================\n")
        f.write("  # 内存预加载配置\n")
        f.write("  # ============================================================================\n\n")

        f.write("  # 是否启用内存预加载\n")
        f.write("  # 启用后将所有数据预加载到内存中，大幅提高训练速度\n")
        f.write("  # 建议数据集不大时（<10GB）启用\n")
        f.write(f"  enable_memory_preload: {config.data.enable_memory_preload}\n\n")

        f.write("  # 分批预加载的大小\n")
        f.write("  # 每次预加载的样本数量，None表示一次性加载所有数据\n")
        f.write("  # 内存不足时可以设置较小值（如1000）\n")
        f.write(f"  preload_batch_size: {config.data.preload_batch_size}\n\n")

        f.write("  # 是否显示预加载过程的详细信息\n")
        f.write("  # 启用后会显示预加载进度和统计信息\n")
        f.write(f"  preload_verbose: {config.data.preload_verbose}\n")

    # 创建训练配置文件
    with open(training_config_path, 'w', encoding='utf-8') as f:
        # 训练配置需要特殊处理，因为它包含train_split嵌套结构
        training_dict = asdict(config.training)
        train_split_dict = {
            'method': config.train_split.method,
            'random_seed': config.train_split.random_seed,
            'train_ratio': config.train_split.train_ratio,
            'val_ratio': config.train_split.val_ratio,
            'test_ratio': config.train_split.test_ratio
        }

        f.write("# 训练配置文件 (training_config.yaml)\n")
        f.write("# 用于配置监督训练参数、优化器和 stratified 数据集划分\n")
        f.write("# 包括基本训练参数、设备配置和当前主线使用的数据划分设置\n\n")

        # 写入训练参数
        f.write("# ============================================================================\n")
        f.write("# 基本训练参数\n")
        f.write("# ============================================================================\n\n")

        # 手动格式化主要训练参数，并添加详细注释
        f.write(f"# 训练设备\n")
        f.write(f"# 可选值：cuda(推荐GPU), cpu(CPU训练), auto(自动检测)\n")
        f.write(f"device: {training_dict['device']}\n\n")
        f.write(f"# 训练轮数\n")
        f.write(f"# 完整遍历数据集的次数\n")
        f.write(f"epochs: {training_dict['epochs']}\n\n")
        f.write(f"# 学习率\n")
        f.write(f"# 控制参数更新步长，ViT模型建议使用较小值(如1e-4到1e-5)\n")
        f.write(f"learning_rate: {training_dict['learning_rate']}\n\n")
        f.write(f"# 权重衰减（L2正则化）\n")
        f.write(f"# 防止过拟合，建议值：0.01到0.1之间\n")
        f.write(f"weight_decay: {training_dict['weight_decay']}\n\n")
        f.write(f"# 优化器类型\n")
        f.write(f"# 可选值：AdamW(推荐), Adam, SGD\n")
        f.write(f"optimizer: {training_dict['optimizer']}\n\n")
        f.write(f"# 学习率调度器\n")
        f.write(f"# 可选值：CosineAnnealingLR(推荐), StepLR, ExponentialLR\n")
        f.write(f"scheduler: {training_dict['scheduler']}\n\n")
        f.write(f"# 批次大小\n")
        f.write(f"# 根据GPU内存调整，12GB显存建议8-32\n")
        f.write(f"batch_size: {training_dict['batch_size']}\n\n")
        f.write(f"# 数据加载器工作进程数\n")
        f.write(f"# 并行数据加载的进程数，建议设置为CPU核心数的一半\n")
        f.write(f"num_workers: {training_dict['num_workers']}\n\n")
        f.write(f"# 梯度累积批次数\n")
        f.write(f"# 模拟大批次训练，当GPU内存不足时可以增加此值\n")
        f.write(f"accumulate_grad_batches: {training_dict['accumulate_grad_batches']}\n\n")
        f.write(f"# 梯度裁剪阈值\n")
        f.write(f"# 防止梯度爆炸，建议值：0.5到2.0之间\n")
        f.write(f"gradient_clip_val: {training_dict['gradient_clip_val']}\n\n")
        f.write(f"# 混合精度训练\n")
        f.write(f"# 启用后可以减少显存使用并加速训练\n")
        f.write(f"mixed_precision: {training_dict['mixed_precision']}\n\n")
        f.write(f"# 是否启用调试日志输出\n")
        f.write(f"# 启用后会输出详细的训练过程信息\n")
        f.write(f"debug_logging: false\n\n")

        # 写入数据分割配置
        f.write("# ============================================================================\n")
        f.write("# 数据集分割参数（统一配置）\n")
        f.write("# ============================================================================\n\n")
        f.write("train_split:\n")
        f.write(f"  # 数据集分割方法\n")
        f.write(f"  # 当前主线固定为 stratified\n")
        f.write(f"  method: \"{train_split_dict['method']}\"\n\n")
        f.write(f"  # 随机种子\n")
        f.write(f"  # 确保数据分割的可重现性，固定种子可以获得一致的分割结果\n")
        f.write(f"  random_seed: {train_split_dict['random_seed']}\n\n")
        f.write(f"  # 训练集比例\n")
        f.write(f"  # stratified 模式下的训练集比例\n")
        f.write(f"  train_ratio: {train_split_dict['train_ratio']}\n\n")
        f.write(f"  # 验证集比例\n")
        f.write(f"  # stratified 模式下的验证集比例\n")
        f.write(f"  val_ratio: {train_split_dict['val_ratio']}\n\n")
        f.write(f"  # 测试集比例\n")
        f.write(f"  # stratified 模式下的测试集比例\n")
        f.write(f"  test_ratio: {train_split_dict['test_ratio']}\n")

    # 创建实验配置文件
    with open(experiment_config_path, 'w', encoding='utf-8') as f:
        f.write("# 实验配置文件 (experiment_config.yaml)\n")
        f.write("# 用于配置实验名称、输出目录和日志相关设置\n")
        f.write("# 包括实验基本信息、目录配置和日志记录策略\n\n")
        f.write("# ============================================================================\n")
        f.write("# 基本信息\n")
        f.write("# ============================================================================\n\n")
        f.write(f"# 实验名称\n")
        f.write(f"# 用于标识不同的实验，建议使用有意义的名称\n")
        f.write(f"name: \"{config.experiment.name}\"\n\n")
        f.write(f"# 实验版本\n")
        f.write(f"# 用于版本控制和管理\n")
        f.write(f"version: \"{config.experiment.version}\"\n\n")
        f.write("# ============================================================================\n")
        f.write("# 目录配置\n")
        f.write("# ============================================================================\n\n")
        f.write(f"# 保存目录\n")
        f.write(f"# 实验文件的根目录，所有子目录都会在此目录下创建\n")
        f.write(f"save_dir: \"{config.experiment.save_dir}\"\n\n")
        f.write(f"# 日志目录\n")
        f.write(f"# 训练日志和TensorBoard文件的保存目录\n")
        f.write(f"log_dir: \"{config.experiment.log_dir}\"\n\n")
        f.write(f"# 检查点目录\n")
        f.write(f"# 模型权重文件的保存目录\n")
        f.write(f"checkpoint_dir: \"{config.experiment.checkpoint_dir}\"\n\n")
        f.write(f"# 结果目录\n")
        f.write(f"# 实验结果、CSV文件、评估报告等的保存目录\n")
        f.write(f"result_dir: \"{config.experiment.result_dir}\"\n\n")
        f.write("# ============================================================================\n")
        f.write("# 日志记录配置\n")
        f.write("# ============================================================================\n\n")
        f.write(f"# 日志记录间隔\n")
        f.write(f"# 每隔多少步记录一次训练指标到日志文件\n")
        f.write(f"log_every_n_steps: {config.experiment.log_every_n_steps}\n\n")
        f.write(f"# 验证检查间隔\n")
        f.write(f"# 每隔多少轮进行一次验证评估\n")
        f.write(f"val_check_interval: {config.experiment.val_check_interval}\n\n")
        f.write("# ============================================================================\n")
        f.write("# 模型保存配置\n")
        f.write("# ============================================================================\n\n")
        f.write(f"# 保存最佳模型的数量（兼容保留字段）\n")
        f.write(f"save_top_k: {config.experiment.save_top_k}\n\n")
        f.write(f"# 是否每轮保存 latest_model.pth（用于 --resume 恢复训练）\n")
        f.write(f"# 设为 false 可减少磁盘 IO，仅保存 best_model.pth\n")
        f.write(f"save_latest: {'true' if config.experiment.save_latest else 'false'}\n")

    # 输出创建结果
    print(f"默认配置文件已创建在 configs/ 目录下:")
    print(f"  - {model_config_path}")
    print(f"  - {data_config_path}")
    print(f"  - {training_config_path}")
    print(f"  - {experiment_config_path}")


if __name__ == "__main__":
    create_default_configs()
