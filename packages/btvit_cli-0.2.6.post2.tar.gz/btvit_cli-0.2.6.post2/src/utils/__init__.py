"""工具函数模块"""

from .config import Config, ModelConfig, DataConfig, TrainingConfig, ExperimentConfig
from .logger import Logger
from .metrics import MetricsCalculator


def __getattr__(name):
    if name in {"TrainingMonitor", "EvaluationVisualizer", "TensorBoardLogger"}:
        from .monitor import TrainingMonitor, EvaluationVisualizer, TensorBoardLogger

        return {
            "TrainingMonitor": TrainingMonitor,
            "EvaluationVisualizer": EvaluationVisualizer,
            "TensorBoardLogger": TensorBoardLogger,
        }[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "Config",
    "ModelConfig",
    "DataConfig",
    "TrainingConfig",
    "ExperimentConfig",
    "Logger",
    "MetricsCalculator",
    "TrainingMonitor",
    "EvaluationVisualizer",
    "TensorBoardLogger"
]
