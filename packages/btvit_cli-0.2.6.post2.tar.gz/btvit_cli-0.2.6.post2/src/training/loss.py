"""Configurable loss functions for multi-axis ViT training.

Provides a factory function ``create_criterion()`` that reads loss configuration
from the config object and returns the appropriate loss module.

Supported loss types:
    - bce: Binary Cross-Entropy
    - focal: Focal Loss
    - bce_label_smoothing: BCE with Label Smoothing
    - weighted_bce: Weighted BCE with separate pos/neg weights
    - dice: Dice Loss
    - tversky: Tversky Loss
    - focal_tversky: Focal Tversky Loss
    - combined: Dynamic combination of any registered losses via combined_loss_weights
"""

from typing import Any, Callable, Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..utils.metrics import FocalLoss


# ---------------------------------------------------------------------------
# Loss components
# ---------------------------------------------------------------------------


class LabelSmoothingBCEWithLogits(nn.Module):
    """Binary cross-entropy with label smoothing, operating on raw logits.

    Smoothed labels: ``y_smooth = y * (1 - smoothing) + (1 - y) * smoothing``
    Prevents the model from becoming overconfident.
    """

    def __init__(self, smoothing: float = 0.1, pos_weight: Optional[float] = None):
        super().__init__()
        self.smoothing = smoothing
        self.pos_weight = pos_weight

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        targets_smooth = targets * (1.0 - self.smoothing) + (1.0 - targets) * self.smoothing
        kwargs: Dict[str, Any] = {"reduction": "mean"}
        if self.pos_weight is not None and self.pos_weight > 0:
            kwargs["pos_weight"] = torch.tensor(self.pos_weight, device=logits.device, dtype=logits.dtype)
        return F.binary_cross_entropy_with_logits(logits, targets_smooth, **kwargs)


class WeightedBCELoss(nn.Module):
    """BCE with separate positive / negative sample weights."""

    def __init__(self, pos_weight: float = 2.0, neg_weight: float = 1.0):
        super().__init__()
        self.pos_weight = pos_weight
        self.neg_weight = neg_weight

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        bce = F.binary_cross_entropy_with_logits(logits, targets, reduction="none")
        weights = torch.where(targets == 1, self.pos_weight, self.neg_weight)
        return (bce * weights).mean()


class DiceLoss(nn.Module):
    """Differentiable Dice loss for binary segmentation / classification.

    Uses the smooth parameter to avoid division by zero.
    Operates on raw logits (applies sigmoid internally).
    """

    def __init__(self, smooth: float = 1.0):
        super().__init__()
        self.smooth = smooth

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        probs = torch.sigmoid(logits)
        probs = probs.view(-1)
        targets = targets.view(-1).float()
        intersection = (probs * targets).sum()
        return 1.0 - (2.0 * intersection + self.smooth) / (
            probs.sum() + targets.sum() + self.smooth
        )


class TverskyLoss(nn.Module):
    """Tversky loss — generalisation of Dice with separate FP / FN penalties.

    ``alpha`` controls FN penalty, ``beta`` controls FP penalty.
    """

    def __init__(self, alpha: float = 0.7, beta: float = 0.3, smooth: float = 1.0):
        super().__init__()
        self.alpha = alpha
        self.beta = beta
        self.smooth = smooth

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        probs = torch.sigmoid(logits)
        probs = probs.view(-1)
        targets = targets.view(-1).float()
        tp = (probs * targets).sum()
        fp = ((1 - targets) * probs).sum()
        fn = (targets * (1 - probs)).sum()
        tversky_index = (tp + self.smooth) / (
            tp + self.alpha * fp + self.beta * fn + self.smooth
        )
        return 1.0 - tversky_index


class FocalTverskyLoss(nn.Module):
    """Focal Tversky loss — applies focal modulation to the Tversky index.

    ``gamma`` > 1 increases focus on hard examples.
    """

    def __init__(
        self,
        alpha: float = 0.5,
        beta: float = 0.5,
        gamma: float = 2.0,
        smooth: float = 1.0,
    ):
        super().__init__()
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
        self.smooth = smooth

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        probs = torch.sigmoid(logits)
        probs = probs.view(-1)
        targets = targets.view(-1).float()
        tp = (probs * targets).sum()
        fp = ((1 - targets) * probs).sum()
        fn = (targets * (1 - probs)).sum()
        tversky_index = (tp + self.smooth) / (
            tp + self.alpha * fp + self.beta * fn + self.smooth
        )
        return (1.0 - tversky_index) ** self.gamma


# ---------------------------------------------------------------------------
# Combined loss
# ---------------------------------------------------------------------------


class CombinedLoss(nn.Module):
    """Weighted combination of multiple loss components.

    ``components`` maps loss type names to ``(module, weight)`` pairs.
    Weights are normalised to sum to 1.0 during ``__init__``.
    """

    def __init__(self, components: List[Tuple[nn.Module, float]]):
        super().__init__()
        total_w = sum(w for _, w in components)
        if total_w <= 0:
            raise ValueError("combined_loss_weights must sum to a positive value")
        self.components: List[Tuple[nn.Module, float]] = []
        for mod, w in components:
            normalised = w / total_w
            self.add_module(f"_component_{len(self.components)}", mod)
            self.components.append((mod, normalised))

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        return sum(w * loss(logits, targets) for loss, w in self.components)


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

# Each factory: (loss_config dict, pos_weight float|None) -> nn.Module
_LossFactory = Callable[[Dict[str, Any], Optional[float]], nn.Module]

_LOSS_REGISTRY: Dict[str, _LossFactory] = {}


def _register(name: str) -> Callable[[_LossFactory], _LossFactory]:
    """Decorator to register a loss factory under *name*."""

    def wrapper(fn: _LossFactory) -> _LossFactory:
        _LOSS_REGISTRY[name] = fn
        return fn

    return wrapper


@_register("bce")
def _make_bce(cfg: Dict[str, Any], pos_weight: Optional[float]) -> nn.Module:
    kwargs: Dict[str, Any] = {}
    if pos_weight is not None and pos_weight > 0:
        kwargs["pos_weight"] = torch.tensor([pos_weight])
    return nn.BCEWithLogitsLoss(**kwargs)


@_register("focal")
def _make_focal(cfg: Dict[str, Any], pos_weight: Optional[float]) -> nn.Module:
    return FocalLoss(
        alpha=float(cfg.get("focal_alpha", 1.0)),
        gamma=float(cfg.get("focal_gamma", 2.0)),
    )


@_register("bce_label_smoothing")
def _make_label_smoothing(cfg: Dict[str, Any], pos_weight: Optional[float]) -> nn.Module:
    return LabelSmoothingBCEWithLogits(
        smoothing=float(cfg.get("label_smoothing", 0.1)),
        pos_weight=pos_weight,
    )


@_register("weighted_bce")
def _make_weighted_bce(cfg: Dict[str, Any], pos_weight: Optional[float]) -> nn.Module:
    return WeightedBCELoss(
        pos_weight=float(cfg.get("weighted_bce_pos_weight", 2.0)),
        neg_weight=float(cfg.get("weighted_bce_neg_weight", 1.0)),
    )


@_register("dice")
def _make_dice(cfg: Dict[str, Any], pos_weight: Optional[float]) -> nn.Module:
    return DiceLoss(smooth=float(cfg.get("dice_loss_smooth", 1.0)))


@_register("tversky")
def _make_tversky(cfg: Dict[str, Any], pos_weight: Optional[float]) -> nn.Module:
    return TverskyLoss(
        alpha=float(cfg.get("tversky_alpha", 0.7)),
        beta=float(cfg.get("tversky_beta", 0.3)),
        smooth=float(cfg.get("tversky_smooth", 1.0)),
    )


@_register("focal_tversky")
def _make_focal_tversky(cfg: Dict[str, Any], pos_weight: Optional[float]) -> nn.Module:
    return FocalTverskyLoss(
        alpha=float(cfg.get("focal_tversky_alpha", 0.5)),
        beta=float(cfg.get("focal_tversky_beta", 0.5)),
        gamma=float(cfg.get("focal_tversky_gamma", 2.0)),
        smooth=float(cfg.get("focal_tversky_smooth", 1.0)),
    )


# ---------------------------------------------------------------------------
# Public factory
# ---------------------------------------------------------------------------


def create_criterion(config, pos_weight: Optional[float] = None) -> nn.Module:
    """Factory: create the loss function based on ``config.training.loss`` dict.

    Args:
        config: Config object with ``config.training.loss`` dict.
        pos_weight: Explicit positive class weight. When provided and > 0,
            used for BCE-based losses.

    Returns:
        ``nn.Module`` loss function accepting ``(logits, targets) -> scalar loss``.

    Raises:
        ValueError: If ``loss.type`` is not a supported value.
    """
    loss_config = getattr(getattr(config, "training", None), "loss", None) or {}
    loss_type = loss_config.get("type", "bce")

    # --- combined: dynamic mix of any registered losses ---
    if loss_type == "combined":
        weights_map = loss_config.get("combined_loss_weights", {})
        if not weights_map:
            raise ValueError("combined loss requires 'combined_loss_weights' in loss config")
        components: List[Tuple[nn.Module, float]] = []
        for name, weight in weights_map.items():
            if name not in _LOSS_REGISTRY:
                raise ValueError(
                    f"Unknown loss component '{name}' in combined_loss_weights. "
                    f"Available: {sorted(_LOSS_REGISTRY.keys())}"
                )
            factory = _LOSS_REGISTRY[name]
            components.append((factory(loss_config, pos_weight), float(weight)))
        return CombinedLoss(components)

    # --- single loss type ---
    if loss_type in _LOSS_REGISTRY:
        return _LOSS_REGISTRY[loss_type](loss_config, pos_weight)

    raise ValueError(
        f"Unsupported loss type: {loss_type!r}. "
        f"Supported: {', '.join(sorted(_LOSS_REGISTRY.keys()))}, combined"
    )
