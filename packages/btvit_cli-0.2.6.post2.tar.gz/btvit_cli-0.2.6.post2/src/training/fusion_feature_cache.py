from typing import Mapping

import numpy as np

import torch

from src.prediction.aggregation import aggregate_patient_feature_mean


def build_patient_feature_cache(dataset, encoders: Mapping[str, torch.nn.Module], device: str = "cpu", tta_pipeline=None):
    device_obj = torch.device(device)
    feature_rows = {}

    for encoder in encoders.values():
        encoder.to(device_obj)
        encoder.eval()

    with torch.no_grad():
        for sample in dataset:
            patient_id = sample["patient_id"]
            label = int(sample["label"].item())
            row = {"label": label}

            for axis, images in sample["axis_images"].items():
                encoder = encoders[axis]
                if tta_pipeline is not None:
                    features = []
                    image_paths = list(sample.get("axis_image_paths", {}).get(axis, []))
                    for image_index, image_tensor in enumerate(images):
                        image = np.asarray(image_tensor.squeeze(0).detach().cpu().numpy(), dtype=np.float32)
                        image_id = image_paths[image_index] if image_index < len(image_paths) else None
                        features.append(
                            tta_pipeline.extract_features_with_tta(
                                encoder,
                                image,
                                device_obj,
                                image_id=image_id,
                            )
                        )
                    row[axis] = aggregate_patient_feature_mean(features)
                    continue

                image_batch = images.to(device_obj)
                features = encoder.extract_features(image_batch).detach().cpu().numpy()
                row[axis] = aggregate_patient_feature_mean(features)

            feature_rows[patient_id] = row

    return feature_rows
