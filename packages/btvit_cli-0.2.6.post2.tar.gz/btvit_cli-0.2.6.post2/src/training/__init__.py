"""训练模块"""

from .axis_trainer import AxisTrainer
from .trainer import Trainer

__all__ = ["Trainer", "AxisTrainer"]
