from collections import defaultdict
import os
from typing import Dict, List

import numpy as np
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from .trainer import Trainer
from ..utils.metrics import MetricsCalculator


class AxisTrainer(Trainer):
    """Single-axis trainer using mean patient probability aggregation."""

    def _calculate_patient_level_metrics(
        self,
        probabilities: List[float],
        targets: List[float],
        image_paths: List[str],
    ) -> Dict[str, float]:
        patient_probabilities = defaultdict(list)
        patient_targets = {}

        for probability, target, image_path in zip(probabilities, targets, image_paths):
            patient_id = self._extract_patient_id(image_path)
            patient_probabilities[patient_id].append(float(probability))
            patient_targets[patient_id] = int(target)

        threshold = 0.5
        patient_level_correct = 0
        patient_level_total = 0
        patient_level_details = []

        for patient_id, probs in patient_probabilities.items():
            mean_probability = float(np.mean(probs))
            patient_prediction = 1 if mean_probability >= threshold else 0
            true_label = patient_targets[patient_id]
            is_correct = patient_prediction == true_label

            if is_correct:
                patient_level_correct += 1
            patient_level_total += 1
            patient_level_details.append(
                {
                    "patient_id": patient_id,
                    "prediction": patient_prediction,
                    "true_label": true_label,
                    "correct": is_correct,
                    "mean_probability": mean_probability,
                    "total_samples": len(probs),
                }
            )

        patient_accuracy = patient_level_correct / patient_level_total if patient_level_total > 0 else 0.0
        return {
            "predict_accuracy": patient_accuracy,
            "patient_total": patient_level_total,
            "patient_correct": patient_level_correct,
            "patient_details": patient_level_details,
        }

    def _load_normalized_image_for_tta(self, dataset, image_path: str) -> np.ndarray:
        image_processor = getattr(dataset, "image_processor", None)
        if image_processor is None:
            raise ValueError("dataset.image_processor is required for TTA evaluation")
        image = image_processor.load_image(image_path)
        return np.asarray(image_processor.normalize_image(image), dtype=np.float32)

    def _evaluate_loader_with_patient_mean(
        self,
        data_loader: DataLoader,
        description: str,
        tracker=None,
        tta_pipeline=None,
    ) -> Dict[str, float]:
        self.model.eval()
        metrics_calculator = MetricsCalculator()
        total_loss = 0.0
        num_batches = len(data_loader)
        all_probabilities: List[float] = []
        all_targets: List[float] = []
        all_image_paths: List[str] = []

        with torch.no_grad():
            sample_cursor = 0

            for batch_idx, (data, targets) in enumerate(data_loader):
                targets = targets.to(self.device).unsqueeze(1)

                if tracker is not None:
                    tracker.update_val_progress(batch_idx, num_batches, total_loss / (batch_idx + 1))

                batch_samples, sample_cursor = self._consume_batch_samples(
                    data_loader.dataset, sample_cursor, data.size(0)
                )
                if tta_pipeline is None:
                    data = data.to(self.device)
                    outputs = self.model(data)
                    loss = self.criterion(outputs, targets)
                    probabilities = torch.sigmoid(outputs)

                    total_loss += loss.item()
                    metrics_calculator.update(outputs, targets)

                    for sample_offset, (image_path, _) in enumerate(batch_samples):
                        all_probabilities.append(float(probabilities[sample_offset].item()))
                        all_targets.append(float(targets[sample_offset].item()))
                        all_image_paths.append(image_path)
                    continue

                batch_loss = 0.0
                for sample_offset, (image_path, _) in enumerate(batch_samples):
                    image = self._load_normalized_image_for_tta(data_loader.dataset, image_path)
                    probability = float(
                        tta_pipeline.predict_with_tta(
                            self.model,
                            image,
                            self.device,
                            image_id=image_path,
                        )
                    )
                    probability_tensor = torch.tensor(
                        [[min(max(probability, 1e-6), 1.0 - 1e-6)]],
                        dtype=torch.float32,
                        device=self.device,
                    )
                    averaged_logits = torch.logit(probability_tensor)
                    target_tensor = targets[sample_offset:sample_offset + 1]
                    batch_loss += float(self.criterion(averaged_logits, target_tensor).item())
                    metrics_calculator.update(averaged_logits, target_tensor)
                    all_probabilities.append(probability)
                    all_targets.append(float(target_tensor.item()))
                    all_image_paths.append(image_path)

                if batch_samples:
                    total_loss += batch_loss / len(batch_samples)

        avg_loss = total_loss / num_batches if num_batches else 0.0
        metrics = metrics_calculator.compute()
        metrics["loss"] = avg_loss

        if all_probabilities and all_targets and all_image_paths:
            metrics.update(self._calculate_patient_level_metrics(all_probabilities, all_targets, all_image_paths))
        else:
            metrics["predict_accuracy"] = 0.0
            metrics["patient_total"] = 0
            metrics["patient_correct"] = 0

        return metrics

    def validate_epoch(self, val_loader: DataLoader, tracker=None) -> Dict[str, float]:
        return self._evaluate_loader_with_patient_mean(
            val_loader,
            "验证中",
            tracker=tracker,
            tta_pipeline=getattr(self, "tta_pipeline", None),
        )

    def evaluate(self, test_loader: DataLoader) -> Dict[str, float]:
        self.logger.info("开始测试评估...")
        test_metrics = self._evaluate_loader_with_patient_mean(
            test_loader,
            "测试中",
            tta_pipeline=getattr(self, "tta_pipeline", None),
        )

        self._print_test_results_rich(test_metrics)

        return test_metrics
