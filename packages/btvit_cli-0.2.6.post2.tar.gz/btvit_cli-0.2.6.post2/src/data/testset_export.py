"""Export split test patients into a prediction-ready directory layout."""

import csv
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Iterable, Sequence

from src.cli.utils import infer_axis_from_filename


def _has_multi_axis_api(organizer) -> bool:
    return hasattr(organizer, "get_patient_all_axis_images")


def _copy_file(src: str, dst_dir: Path) -> str:
    src_path = Path(src)
    dst_dir.mkdir(parents=True, exist_ok=True)
    target_path = dst_dir / src_path.name
    shutil.copy2(src_path, target_path)
    return src_path.name


def export_prediction_ready_testset(
    *,
    experiment_dir: str,
    experiment_name: str,
    test_patients: Sequence[str],
    labels: dict[str, int],
    organizer,
    source_data_path: str,
    active_axes: Iterable[str] | None = None,
    logger=None,
) -> str:
    output_axes = ["x", "y", "z"]
    required_axes = list(active_axes or output_axes)
    export_root = Path(experiment_dir) / "testset"
    axis_dirs = {axis: export_root / f"data-{axis}" for axis in output_axes}

    if export_root.exists():
        shutil.rmtree(export_root)
    export_root.mkdir(parents=True, exist_ok=True)
    for axis_dir in axis_dirs.values():
        axis_dir.mkdir(parents=True, exist_ok=True)

    counts = {axis: 0 for axis in output_axes}
    exported_patients: list[str] = []
    skipped_patients: list[dict[str, str]] = []

    for patient_id in test_patients:
        label = labels.get(patient_id)
        if label is None:
            skipped_patients.append({"patient_id": patient_id, "reason": "missing_label"})
            continue

        copied_any = False
        if _has_multi_axis_api(organizer):
            patient_axis_images = organizer.get_patient_all_axis_images(patient_id)
            missing_axes = [axis for axis in required_axes if not patient_axis_images.get(axis)]
            if missing_axes:
                reason = f"missing_axes:{','.join(missing_axes)}"
                skipped_patients.append({"patient_id": patient_id, "reason": reason})
                if logger is not None:
                    logger.warning(f"skip testset export patient {patient_id}: {reason}")
                continue

            for axis in required_axes:
                for image_path in patient_axis_images[axis]:
                    _copy_file(image_path, axis_dirs[axis])
                    counts[axis] += 1
                    copied_any = True
        else:
            for image_path in organizer.get_patient_images(patient_id):
                try:
                    axis = infer_axis_from_filename(Path(image_path).name)
                except ValueError:
                    continue
                if axis not in axis_dirs:
                    continue
                _copy_file(image_path, axis_dirs[axis])
                counts[axis] += 1
                copied_any = True

        if copied_any:
            exported_patients.append(patient_id)
        else:
            skipped_patients.append({"patient_id": patient_id, "reason": "no_valid_axis_images"})

    with (export_root / "label.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["patient_id", "label"])
        for patient_id in exported_patients:
            writer.writerow([patient_id, labels[patient_id]])

    metadata = {
        "experiment_name": experiment_name,
        "source_data_path": source_data_path,
        "export_dir": str(export_root),
        "test_patients": list(test_patients),
        "exported_patients": exported_patients,
        "skipped_patients": skipped_patients,
        "counts": counts,
        "created_at": datetime.now().isoformat(),
    }
    with (export_root / "split_info.json").open("w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2, ensure_ascii=False)

    return str(export_root)
