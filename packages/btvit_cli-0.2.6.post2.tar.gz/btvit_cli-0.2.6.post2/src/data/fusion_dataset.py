from typing import Dict, List, Optional

import numpy as np
import torch
from torch.utils.data import Dataset

from .preprocessing import ImageProcessor, LabelProcessor, MultiAxisDatasetOrganizer


class FusionPatientDataset(Dataset):
    def __init__(
        self,
        patient_ids: List[str],
        axis_data_paths: Dict[str, str],
        label_path: str,
        active_axes: Optional[List[str]] = None,
        image_processor: Optional[ImageProcessor] = None,
        images_per_axis: Optional[int] = None,
    ):
        self.active_axes = list(active_axes or sorted(axis_data_paths.keys()))
        self.label_processor = LabelProcessor(label_path)
        self.organizer = MultiAxisDatasetOrganizer(
            axis_data_paths=axis_data_paths,
            label_processor=self.label_processor,
            active_axes=self.active_axes,
            images_per_axis=images_per_axis,
        )
        self.image_processor = image_processor or ImageProcessor(patch_size=(16, 16))
        valid_patients = set(self.organizer.get_all_patients())
        self.patient_ids = [patient_id for patient_id in patient_ids if patient_id in valid_patients]

    def __len__(self) -> int:
        return len(self.patient_ids)

    def _load_axis_images(self, patient_id: str, axis: str) -> tuple[torch.Tensor, List[str]]:
        image_paths = list(self.organizer.get_patient_axis_images(patient_id, axis))
        image_tensors: List[torch.Tensor] = []

        for image_path in image_paths:
            image = self.image_processor.load_image(image_path)
            image = self.image_processor.normalize_image(image)
            image_tensors.append(
                torch.from_numpy(
                    np.asarray(image, dtype=np.float32).reshape(1, image.shape[0], image.shape[1])
                )
            )

        if not image_tensors:
            return torch.empty(0, 1, 16, 368), []

        return torch.stack(image_tensors, dim=0), image_paths

    def __getitem__(self, idx: int):
        patient_id = self.patient_ids[idx]
        label = self.label_processor.get_label(patient_id)

        axis_images = {}
        axis_image_paths = {}
        for axis in self.active_axes:
            images, image_paths = self._load_axis_images(patient_id, axis)
            axis_images[axis] = images
            axis_image_paths[axis] = image_paths

        return {
            "patient_id": patient_id,
            "label": torch.tensor(float(label), dtype=torch.float32),
            "axis_images": axis_images,
            "axis_image_paths": axis_image_paths,
        }


def fusion_patient_collate(batch):
    if not batch:
        return {
            "patient_ids": [],
            "labels": torch.empty(0, dtype=torch.float32),
            "axis_images": {},
            "axis_image_paths": {},
        }

    active_axes = list(batch[0]["axis_images"].keys())
    return {
        "patient_ids": [sample["patient_id"] for sample in batch],
        "labels": torch.stack([sample["label"] for sample in batch], dim=0),
        "axis_images": {axis: [sample["axis_images"][axis] for sample in batch] for axis in active_axes},
        "axis_image_paths": {axis: [sample["axis_image_paths"][axis] for sample in batch] for axis in active_axes},
    }
