import torch
from torch.utils.data import DataLoader
import numpy as np
from typing import List, Tuple, Optional, Dict, Union
import os

try:
    from .dataset import ViTDataset, ViTCollator
    from .preprocessing import ImageProcessor, LabelProcessor, DatasetOrganizer
    from .advanced_splitting import StratifiedDataSplitter, CrossValidationSplitter
except ImportError:
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from dataset import ViTDataset, ViTCollator
    from preprocessing import ImageProcessor, LabelProcessor, DatasetOrganizer
    from advanced_splitting import StratifiedDataSplitter, CrossValidationSplitter


class ImprovedDataLoaderManager:
    """
    改进的数据加载器管理器，支持分层分割和交叉验证
    """

    def __init__(self,
                 data_path: str,
                 label_path: str,
                 batch_size: int = 32,
                 num_workers: int = 4,
                 pin_memory: bool = True,
                 patch_size: Tuple[int, int] = (16, 16),
                 train_ratio: float = 0.8,
                 val_ratio: float = 0.1,
                 test_ratio: float = 0.1,
                 random_seed: int = 42,
                 use_stratified_split: bool = True):

        self.batch_size = batch_size
        self.num_workers = num_workers
        self.pin_memory = pin_memory
        self.patch_size = patch_size
        self.random_seed = random_seed
        self.use_stratified_split = use_stratified_split

        # 初始化处理器
        self.label_processor = LabelProcessor(label_path)
        self.organizer = DatasetOrganizer(data_path, self.label_processor)
        self.image_processor = ImageProcessor(patch_size=patch_size)

        # 获取所有患者
        self.all_patients = self.organizer.get_all_patients()
        self.labels = {pid: self.label_processor.get_label(pid) for pid in self.all_patients}

        # 初始化分割器
        self.stratified_splitter = StratifiedDataSplitter(random_seed=random_seed)
        self.cv_splitter = CrossValidationSplitter(random_seed=random_seed)

        # 初始化collator
        self.collator = ViTCollator(max_patches=23)

        # 进行数据分割
        self._split_data(train_ratio, val_ratio, test_ratio)

    def _split_data(self, train_ratio: float, val_ratio: float, test_ratio: float):
        """分割数据集"""
        if self.use_stratified_split:
            # 使用分层分割
            self.train_patients, self.val_patients, self.test_patients = self.stratified_splitter.stratified_split_patients(
                self.all_patients, self.labels, train_ratio, val_ratio, test_ratio
            )
        else:
            # 使用随机分割
            np.random.seed(self.random_seed)
            np.random.shuffle(self.all_patients)

            n_patients = len(self.all_patients)
            n_train = int(n_patients * train_ratio)
            n_val = int(n_patients * val_ratio)

            self.train_patients = self.all_patients[:n_train]
            self.val_patients = self.all_patients[n_train:n_train + n_val]
            self.test_patients = self.all_patients[n_train + n_val:]

    def get_train_dataloader(self) -> DataLoader:
        """获取训练数据加载器"""
        dataset = ViTDataset(
            patient_ids=self.train_patients,
            organizer=self.organizer,
            image_processor=self.image_processor,
            label_processor=self.label_processor,
            patch_size=self.patch_size,
            mode="train"
        )
        return DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            collate_fn=self.collator,
            drop_last=True
        )

    def get_val_dataloader(self) -> DataLoader:
        """获取验证数据加载器"""
        dataset = ViTDataset(
            patient_ids=self.val_patients,
            organizer=self.organizer,
            image_processor=self.image_processor,
            label_processor=self.label_processor,
            patch_size=self.patch_size,
            mode="val"
        )
        return DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            collate_fn=self.collator,
            drop_last=False
        )

    def get_test_dataloader(self) -> DataLoader:
        """获取测试数据加载器"""
        dataset = ViTDataset(
            patient_ids=self.test_patients,
            organizer=self.organizer,
            image_processor=self.image_processor,
            label_processor=self.label_processor,
            patch_size=self.patch_size,
            mode="test"
        )
        return DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            collate_fn=self.collator,
            drop_last=False
        )

    def get_split_statistics(self) -> Dict:
        """获取分割统计信息"""
        if self.use_stratified_split:
            return self.stratified_splitter.get_split_statistics(
                self.train_patients, self.val_patients, self.test_patients, self.labels
            )
        else:
            # 简单统计
            def get_stats(patients, name):
                patient_labels = [self.labels[pid] for pid in patients]
                pos_count = sum(patient_labels)
                neg_count = len(patient_labels) - pos_count
                pos_ratio = pos_count / len(patient_labels) if len(patient_labels) > 0 else 0
                return {
                    'total_patients': len(patients),
                    'positive_patients': pos_count,
                    'negative_patients': neg_count,
                    'positive_ratio': pos_ratio,
                    'negative_ratio': 1 - pos_ratio
                }

            return {
                'train': get_stats(self.train_patients, 'train'),
                'val': get_stats(self.val_patients, 'val'),
                'test': get_stats(self.test_patients, 'test'),
                'overall': get_stats(self.all_patients, 'overall')
            }

    def get_dataset_info(self) -> Dict:
        """获取数据集详细信息（包括样本数量）"""
        train_dataset = ViTDataset(
            patient_ids=self.train_patients,
            organizer=self.organizer,
            image_processor=self.image_processor,
            label_processor=self.label_processor,
            patch_size=self.patch_size,
            mode="train"
        )
        val_dataset = ViTDataset(
            patient_ids=self.val_patients,
            organizer=self.organizer,
            image_processor=self.image_processor,
            label_processor=self.label_processor,
            patch_size=self.patch_size,
            mode="val"
        )
        test_dataset = ViTDataset(
            patient_ids=self.test_patients,
            organizer=self.organizer,
            image_processor=self.image_processor,
            label_processor=self.label_processor,
            patch_size=self.patch_size,
            mode="test"
        )

        train_labels = [sample[1] for sample in train_dataset.samples]
        val_labels = [sample[1] for sample in val_dataset.samples]
        test_labels = [sample[1] for sample in test_dataset.samples]

        return {
            'train': {
                'patients': len(self.train_patients),
                'samples': len(train_dataset),
                'positive_samples': sum(train_labels),
                'negative_samples': len(train_labels) - sum(train_labels)
            },
            'val': {
                'patients': len(self.val_patients),
                'samples': len(val_dataset),
                'positive_samples': sum(val_labels),
                'negative_samples': len(val_labels) - sum(val_labels)
            },
            'test': {
                'patients': len(self.test_patients),
                'samples': len(test_dataset),
                'positive_samples': sum(test_labels),
                'negative_samples': len(test_labels) - sum(test_labels)
            }
        }


class CrossValidationTrainer:
    """
    交叉验证训练器
    """

    def __init__(self,
                 data_path: str,
                 label_path: str,
                 batch_size: int = 32,
                 num_workers: int = 4,
                 pin_memory: bool = True,
                 patch_size: Tuple[int, int] = (16, 16),
                 n_folds: int = 5,
                 random_seed: int = 42,
                 memory_preloader=None):

        # 保存所有参数
        self.data_path = data_path
        self.label_path = label_path
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.pin_memory = pin_memory
        self.patch_size = patch_size
        self.n_folds = n_folds
        self.random_seed = random_seed
        self.memory_preloader = memory_preloader

        # 初始化处理器
        self.label_processor = LabelProcessor(label_path)
        self.organizer = DatasetOrganizer(data_path, self.label_processor)
        self.image_processor = ImageProcessor(patch_size=patch_size)

        # 获取所有患者和标签
        self.all_patients = self.organizer.get_all_patients()
        self.labels = {pid: self.label_processor.get_label(pid) for pid in self.all_patients}

        # 创建交叉验证分割
        self.cv_splitter = CrossValidationSplitter(n_folds=n_folds, random_seed=random_seed)
        self.cv_splits = self.cv_splitter.create_cv_splits(self.all_patients, self.labels)

        # 初始化collator
        self.collator = ViTCollator(max_patches=23)

    def get_fold_dataloaders(self, fold_idx: int) -> Tuple[DataLoader, DataLoader]:
        """
        获取指定折的训练和验证数据加载器
        """
        if fold_idx < 0 or fold_idx >= len(self.cv_splits):
            raise ValueError(f"fold_idx must be between 0 and {len(self.cv_splits)-1}")

        train_patients, val_patients = self.cv_splits[fold_idx]

        # 如果启用内存预加载，调整worker数量
        effective_num_workers = 0 if self.memory_preloader else self.num_workers

        # 创建训练数据加载器
        train_dataset = ViTDataset(
            patient_ids=train_patients,
            organizer=self.organizer,
            image_processor=self.image_processor,
            label_processor=self.label_processor,
            patch_size=(16, 16),
            mode="train",
            memory_preloader=self.memory_preloader
        )
        train_loader = DataLoader(
            train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=effective_num_workers,
            pin_memory=self.pin_memory,
            collate_fn=self.collator,
            drop_last=True
        )

        # 创建验证数据加载器
        val_dataset = ViTDataset(
            patient_ids=val_patients,
            organizer=self.organizer,
            image_processor=self.image_processor,
            label_processor=self.label_processor,
            patch_size=(16, 16),
            mode="val",
            memory_preloader=self.memory_preloader
        )
        val_loader = DataLoader(
            val_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=effective_num_workers,
            pin_memory=self.pin_memory,
            collate_fn=self.collator,
            drop_last=False
        )

        return train_loader, val_loader

    def get_cv_statistics(self) -> Dict:
        """获取交叉验证统计信息"""
        return self.cv_splitter.get_cv_statistics(self.cv_splits, self.labels)


if __name__ == "__main__":
    # 测试改进的数据加载器
    print("=== 测试改进的数据加载器 ===")

    # 1. 测试分层分割
    print("\n--- 分层分割模式 ---")
    stratified_manager = ImprovedDataLoaderManager(
        data_path="dataset/data",
        label_path="dataset/label.csv",
        batch_size=8,
        num_workers=0,
        use_stratified_split=True,
        random_seed=42
    )

    stratified_stats = stratified_manager.get_split_statistics()
    print("分层分割统计:")
    for split_name, stats in stratified_stats.items():
        if split_name != 'overall':
            print(f"  {split_name}: {stats['total_patients']} 患者, "
                  f"阳性 {stats['positive_patients']} ({stats['positive_ratio']:.2%}), "
                  f"阴性 {stats['negative_patients']} ({stats['negative_ratio']:.2%})")

    # 2. 测试随机分割
    print("\n--- 随机分割模式 ---")
    random_manager = ImprovedDataLoaderManager(
        data_path="dataset/data",
        label_path="dataset/label.csv",
        batch_size=8,
        num_workers=0,
        use_stratified_split=False,
        random_seed=42
    )

    random_stats = random_manager.get_split_statistics()
    print("随机分割统计:")
    for split_name, stats in random_stats.items():
        if split_name != 'overall':
            print(f"  {split_name}: {stats['total_patients']} 患者, "
                  f"阳性 {stats['positive_patients']} ({stats['positive_ratio']:.2%}), "
                  f"阴性 {stats['negative_patients']} ({stats['negative_ratio']:.2%})")

    # 3. 测试交叉验证
    print("\n--- 5折交叉验证 ---")
    cv_trainer = CrossValidationTrainer(
        data_path="dataset/data",
        label_path="dataset/label.csv",
        n_folds=5,
        random_seed=42
    )

    cv_stats = cv_trainer.get_cv_statistics()
    print("交叉验证统计:")
    for fold_name, stats in cv_stats.items():
        train_stats = stats['train']
        val_stats = stats['val']
        print(f"  {fold_name}: 训练集 {train_stats['total']} 患者 (阳性 {train_stats['positive_ratio']:.2%}), "
              f"验证集 {val_stats['total']} 患者 (阳性 {val_stats['positive_ratio']:.2%})")