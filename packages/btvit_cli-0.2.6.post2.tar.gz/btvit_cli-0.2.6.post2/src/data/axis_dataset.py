from typing import List, Optional, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset

from .preprocessing import DatasetOrganizer, ImageProcessor, LabelProcessor


class AxisImageDataset(Dataset):
    def __init__(
        self,
        axis: str,
        patient_ids: List[str],
        axis_data_path: str,
        label_path: str,
        image_processor: Optional[ImageProcessor] = None,
    ):
        self.axis = axis
        self.patient_ids = list(patient_ids)
        self.axis_data_path = axis_data_path
        self.label_processor = LabelProcessor(label_path)
        self.organizer = DatasetOrganizer(axis_data_path, self.label_processor)
        self.image_processor = image_processor or ImageProcessor(patch_size=(16, 16))
        self.samples = self._prepare_samples()

    def _prepare_samples(self) -> List[Tuple[str, int, str]]:
        samples = []
        for patient_id in self.patient_ids:
            label = self.label_processor.get_label(patient_id)
            if label is None:
                continue
            for image_path in sorted(self.organizer.get_patient_images(patient_id)):
                samples.append((image_path, int(label), patient_id))
        return samples

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int):
        image_path, label, patient_id = self.samples[idx]
        image = self.image_processor.load_image(image_path)
        image = self.image_processor.normalize_image(image)
        image_tensor = torch.from_numpy(np.asarray(image, dtype=np.float32).reshape(1, image.shape[0], image.shape[1]))
        label_tensor = torch.tensor(float(label), dtype=torch.float32)
        return image_tensor, label_tensor, patient_id, image_path
