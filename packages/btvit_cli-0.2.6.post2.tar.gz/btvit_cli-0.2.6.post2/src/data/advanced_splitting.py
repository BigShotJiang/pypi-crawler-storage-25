import numpy as np
from typing import List, Tuple, Dict
from sklearn.model_selection import StratifiedShuffleSplit, StratifiedKFold
import pandas as pd
import sys
import os

try:
    from .preprocessing import LabelProcessor, DatasetOrganizer
except ImportError:
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from preprocessing import LabelProcessor, DatasetOrganizer


class StratifiedDataSplitter:
    """
    分层数据集分割器，确保阳性和阴性样本在训练/验证/测试集中的比例一致
    """

    def __init__(self, random_seed: int = 42):
        self.random_seed = random_seed
        np.random.seed(random_seed)

    def stratified_split_patients(self,
                                 patient_ids: List[str],
                                 labels: Dict[str, int],
                                 train_ratio: float = 0.8,
                                 val_ratio: float = 0.1,
                                 test_ratio: float = 0.1) -> Tuple[List[str], List[str], List[str]]:
        """
        分层分割患者，确保阳性/阴性比例一致
        """
        assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6, "分割比例之和必须为1"

        # 准备患者标签
        patient_labels = [labels[pid] for pid in patient_ids]

        # 第一次分割：训练集 vs (验证集+测试集)
        splitter1 = StratifiedShuffleSplit(
            n_splits=1,
            test_size=(val_ratio + test_ratio),
            random_state=self.random_seed
        )

        train_idx, temp_idx = next(splitter1.split(patient_ids, patient_labels))

        # 获取训练集患者
        train_patients = [patient_ids[i] for i in train_idx]

        # 处理验证集和测试集
        temp_patients = [patient_ids[i] for i in temp_idx]
        temp_labels = [patient_labels[i] for i in temp_idx]

        if test_ratio == 0.0:
            # 如果没有测试集，所有剩余数据作为验证集
            val_patients = temp_patients
            test_patients = []
        elif val_ratio == 0.0:
            # 如果没有验证集，所有剩余数据作为测试集
            val_patients = []
            test_patients = temp_patients
        else:
            # 第二次分割：验证集 vs 测试集
            val_size_adjusted = val_ratio / (val_ratio + test_ratio)
            splitter2 = StratifiedShuffleSplit(
                n_splits=1,
                test_size=(1 - val_size_adjusted),
                random_state=self.random_seed
            )

            val_idx, test_idx = next(splitter2.split(temp_patients, temp_labels))

            val_patients = [temp_patients[i] for i in val_idx]
            test_patients = [temp_patients[i] for i in test_idx]

        return train_patients, val_patients, test_patients

    def get_split_statistics(self,
                           train_patients: List[str],
                           val_patients: List[str],
                           test_patients: List[str],
                           labels: Dict[str, int]) -> Dict:
        """
        获取分割后的统计信息
        """
        def get_stats(patients, name):
            patient_labels = [labels[pid] for pid in patients]
            pos_count = sum(patient_labels)
            neg_count = len(patient_labels) - pos_count
            pos_ratio = pos_count / len(patient_labels) if len(patient_labels) > 0 else 0

            return {
                'total_patients': len(patients),
                'positive_patients': pos_count,
                'negative_patients': neg_count,
                'positive_ratio': pos_ratio,
                'negative_ratio': 1 - pos_ratio
            }

        return {
            'train': get_stats(train_patients, 'train'),
            'val': get_stats(val_patients, 'val'),
            'test': get_stats(test_patients, 'test'),
            'overall': get_stats(train_patients + val_patients + test_patients, 'overall')
        }


class CrossValidationSplitter:
    """
    K折交叉验证分割器
    """

    def __init__(self, n_folds: int = 5, random_seed: int = 42):
        self.n_folds = n_folds
        self.random_seed = random_seed
        np.random.seed(random_seed)

    def create_cv_splits(self,
                        patient_ids: List[str],
                        labels: Dict[str, int]) -> List[Tuple[List[str], List[str]]]:
        """
        创建K折交叉验证分割
        返回：[(fold1_train, fold1_val), (fold2_train, fold2_val), ...]
        """
        # 准备患者标签
        patient_labels = [labels[pid] for pid in patient_ids]

        # 使用分层K折分割
        skf = StratifiedKFold(n_splits=self.n_folds, shuffle=True, random_state=self.random_seed)

        cv_splits = []
        for fold_idx, (train_idx, val_idx) in enumerate(skf.split(patient_ids, patient_labels)):
            train_patients = [patient_ids[i] for i in train_idx]
            val_patients = [patient_ids[i] for i in val_idx]
            cv_splits.append((train_patients, val_patients))

            print(f"Fold {fold_idx + 1}: 训练集 {len(train_patients)} 患者, 验证集 {len(val_patients)} 患者")

        return cv_splits

    def get_cv_statistics(self,
                         cv_splits: List[Tuple[List[str], List[str]]],
                         labels: Dict[str, int]) -> Dict:
        """
        获取交叉验证的统计信息
        """
        stats = {}
        for fold_idx, (train_patients, val_patients) in enumerate(cv_splits):
            train_labels = [labels[pid] for pid in train_patients]
            val_labels = [labels[pid] for pid in val_patients]

            train_pos = sum(train_labels)
            train_neg = len(train_labels) - train_pos
            val_pos = sum(val_labels)
            val_neg = len(val_labels) - val_pos

            stats[f'fold_{fold_idx + 1}'] = {
                'train': {
                    'total': len(train_patients),
                    'positive': train_pos,
                    'negative': train_neg,
                    'positive_ratio': train_pos / len(train_labels)
                },
                'val': {
                    'total': len(val_patients),
                    'positive': val_pos,
                    'negative': val_neg,
                    'positive_ratio': val_pos / len(val_labels)
                }
            }

        return stats


def analyze_current_splitting(data_path: str, label_path: str, random_seed: int = 42) -> Dict:
    """
    分析当前的数据集划分情况
    """
    label_processor = LabelProcessor(label_path)
    organizer = DatasetOrganizer(data_path, label_processor)

    all_patients = organizer.get_all_patients()

    # 使用当前的随机分割方法
    np.random.seed(random_seed)
    np.random.shuffle(all_patients)

    n_patients = len(all_patients)
    n_train = int(n_patients * 0.8)
    n_val = int(n_patients * 0.1)

    train_patients = all_patients[:n_train]
    val_patients = all_patients[n_train:n_train + n_val]
    test_patients = all_patients[n_train + n_val:]

    # 获取统计信息
    def get_split_stats(patients, name):
        patient_labels = [label_processor.get_label(pid) for pid in patients]
        pos_count = sum(patient_labels)
        neg_count = len(patient_labels) - pos_count

        return {
            'name': name,
            'total_patients': len(patients),
            'positive_patients': pos_count,
            'negative_patients': neg_count,
            'positive_ratio': pos_count / len(patient_labels) if len(patient_labels) > 0 else 0,
            'negative_ratio': neg_count / len(patient_labels) if len(patient_labels) > 0 else 0
        }

    return {
        'current_splitting': {
            'train': get_split_stats(train_patients, 'train'),
            'val': get_split_stats(val_patients, 'val'),
            'test': get_split_stats(test_patients, 'test')
        },
        'overall_stats': {
            'total_patients': len(all_patients),
            'total_positive': sum(1 for pid in all_patients if label_processor.get_label(pid) == 1),
            'total_negative': sum(1 for pid in all_patients if label_processor.get_label(pid) == 0)
        }
    }


if __name__ == "__main__":
    # 分析当前划分情况
    print("=== 当前数据集划分分析 ===")
    current_stats = analyze_current_splitting("dataset/data", "dataset/label.csv")

    print(f"总患者数: {current_stats['overall_stats']['total_patients']}")
    print(f"总阳性: {current_stats['overall_stats']['total_positive']}")
    print(f"总阴性: {current_stats['overall_stats']['total_negative']}")
    print()

    for split_name, stats in current_stats['current_splitting'].items():
        print(f"{split_name.upper()}集:")
        print(f"  患者数: {stats['total_patients']}")
        print(f"  阳性: {stats['positive_patients']} ({stats['positive_ratio']:.2%})")
        print(f"  阴性: {stats['negative_patients']} ({stats['negative_ratio']:.2%})")
    print()

    # 测试分层分割
    print("=== 分层分割测试 ===")
    label_processor = LabelProcessor("dataset/label.csv")
    organizer = DatasetOrganizer("dataset/data", label_processor)
    all_patients = organizer.get_all_patients()
    labels = {pid: label_processor.get_label(pid) for pid in all_patients}

    splitter = StratifiedDataSplitter(random_seed=42)
    train_patients, val_patients, test_patients = splitter.stratified_split_patients(
        all_patients, labels, 0.8, 0.1, 0.1
    )

    stratified_stats = splitter.get_split_statistics(train_patients, val_patients, test_patients, labels)

    for split_name, stats in stratified_stats.items():
        if split_name != 'overall':
            print(f"{split_name.upper()}集:")
            print(f"  患者数: {stats['total_patients']}")
            print(f"  阳性: {stats['positive_patients']} ({stats['positive_ratio']:.2%})")
            print(f"  阴性: {stats['negative_patients']} ({stats['negative_ratio']:.2%})")

    # 测试交叉验证
    print("\n=== 5折交叉验证测试 ===")
    cv_splitter = CrossValidationSplitter(n_folds=5, random_seed=42)
    cv_splits = cv_splitter.create_cv_splits(all_patients, labels)
    cv_stats = cv_splitter.get_cv_statistics(cv_splits, labels)

    for fold_name, stats in cv_stats.items():
        train_stats = stats['train']
        val_stats = stats['val']
        print(f"{fold_name}: 训练集阳性比 {train_stats['positive_ratio']:.2%}, 验证集阳性比 {val_stats['positive_ratio']:.2%}")