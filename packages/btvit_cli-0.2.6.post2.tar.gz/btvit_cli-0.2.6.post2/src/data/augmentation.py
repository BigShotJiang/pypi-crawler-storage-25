"""Configurable image augmentation pipeline for axis training.

Operates on full grayscale images (H x W float32 ndarray) BEFORE
patch cropping. Only active in train mode; val/test pass through unchanged.
"""

import logging
import hashlib
from typing import Any, Callable, Dict, List, Optional

import numpy as np
from scipy.ndimage import rotate as scipy_rotate
import torch

logger = logging.getLogger(__name__)


class HorizontalFlip:
    """Stochastic horizontal flip."""

    def __init__(self, config: dict):
        self.probability = float(config.get("probability", 0.5))

    def __call__(self, image: np.ndarray, rng: np.random.RandomState) -> np.ndarray:
        if rng.random() < self.probability:
            return np.fliplr(image).copy()
        return image


class BrightnessContrast:
    """Random brightness and contrast adjustment."""

    def __init__(self, config: dict):
        self.probability = float(config.get("probability", 0.5))
        b_range = config.get("brightness_range", [0.8, 1.2])
        c_range = config.get("contrast_range", [0.8, 1.2])
        self.brightness_range = self._clamp_range(b_range, 0.1, 3.0)
        self.contrast_range = self._clamp_range(c_range, 0.1, 3.0)

    @staticmethod
    def _clamp_range(rng: list, lo: float, hi: float) -> tuple:
        a, b = float(rng[0]), float(rng[1])
        if abs(a - b) < 1e-9:
            raise ValueError(
                f"Degenerate range [{a}, {b}] rejected. "
                f"Provide two distinct values."
            )
        a, b = max(lo, min(a, hi)), max(lo, min(b, hi))
        return (min(a, b), max(a, b))

    def __call__(self, image: np.ndarray, rng: np.random.RandomState) -> np.ndarray:
        if rng.random() >= self.probability:
            return image
        brightness = rng.uniform(*self.brightness_range)
        contrast = rng.uniform(*self.contrast_range)
        mean = image.mean()
        adjusted = (image - mean) * contrast + mean * brightness
        return np.clip(adjusted, -3.0, 3.0).astype(np.float32)


class Rotation:
    """Small-angle rotation.

    Designed for extreme-aspect-ratio images (e.g. 16x368).  Even tiny
    angles cause large pixel shifts on the long axis, so the default
    range is conservatively set to [-3, 3] degrees.
    """

    def __init__(self, config: dict):
        self.probability = float(config.get("probability", 0.5))
        angle_range = config.get("angle_range", [-3, 3])
        self.angle_range = (float(angle_range[0]), float(angle_range[1]))
        self.mode = str(config.get("padding_mode", "constant"))
        self.order = int(config.get("interpolation_order", 1))

    def __call__(self, image: np.ndarray, rng: np.random.RandomState) -> np.ndarray:
        if rng.random() >= self.probability:
            return image
        angle = rng.uniform(*self.angle_range)
        rotated = scipy_rotate(
            image,
            angle,
            reshape=False,
            mode=self.mode,
            cval=0.0,
            order=self.order,
        )
        return rotated.astype(np.float32)


class GaussianNoise:
    """Additive Gaussian noise for robustness."""

    def __init__(self, config: dict):
        self.probability = float(config.get("probability", 0.5))
        self.std_range = (
            float(config.get("std_min", 0.01)),
            float(config.get("std_max", 0.05)),
        )

    def __call__(self, image: np.ndarray, rng: np.random.RandomState) -> np.ndarray:
        if rng.random() >= self.probability:
            return image
        std = rng.uniform(*self.std_range)
        noise = rng.randn(*image.shape).astype(np.float32) * std
        return np.clip(image + noise, -3.0, 3.0).astype(np.float32)


class RandomErasing:
    """Randomly erase a rectangular region of the image.

    Particularly effective for extreme-aspect-ratio images (e.g. 16x368)
    as it forces the model to not rely on any single local region.
    """

    def __init__(self, config: dict):
        self.probability = float(config.get("probability", 0.5))
        self.scale_range = (
            float(config.get("scale_min", 0.02)),
            float(config.get("scale_max", 0.2)),
        )
        self.value_range = (
            float(config.get("value_min", 0.0)),
            float(config.get("value_max", 0.0)),
        )

    def __call__(self, image: np.ndarray, rng: np.random.RandomState) -> np.ndarray:
        if rng.random() >= self.probability:
            return image
        h, w = image.shape
        area = h * w
        target_area = rng.uniform(*self.scale_range) * area
        aspect_ratio = rng.uniform(0.3, 1.0 / 0.3)
        erase_h = int(round(np.sqrt(target_area * aspect_ratio)))
        erase_w = int(round(np.sqrt(target_area / aspect_ratio)))
        erase_h = min(erase_h, h)
        erase_w = min(erase_w, w)
        if erase_h < 1 or erase_w < 1:
            return image
        top = rng.randint(0, h - erase_h + 1)
        left = rng.randint(0, w - erase_w + 1)
        value = rng.uniform(*self.value_range)
        image = image.copy()
        image[top:top + erase_h, left:left + erase_w] = value
        return image


# Registry mapping config keys to transform classes
_TRANSFORM_REGISTRY: Dict[str, type] = {
    "horizontal_flip": HorizontalFlip,
    "brightness_contrast": BrightnessContrast,
    "rotation": Rotation,
    "gaussian_noise": GaussianNoise,
    "random_erasing": RandomErasing,
}


class AugmentationPipeline:
    """Configurable augmentation pipeline.

    Parameters
    ----------
    config : dict
        Parsed training.axis.augmentation dictionary.
    mode : str
        "train", "val", or "test". Only "train" activates augmentation.
    """

    def __init__(self, config: Optional[dict] = None, mode: str = "train"):
        config = config or {}
        self.enabled = bool(config.get("enabled", False)) and mode == "train"
        seed = config.get("random_seed")
        self.rng = np.random.RandomState(seed)
        self.transforms: List[Callable] = []
        if self.enabled:
            self.transforms = self._build_transforms(config)
            names = [t.__class__.__name__ for t in self.transforms]
            logger.info("Augmentation enabled (mode=%s): %s", mode, names)

    def _build_transforms(self, config: dict) -> list:
        transforms = []
        for key, cls in _TRANSFORM_REGISTRY.items():
            sub_cfg = config.get(key, {})
            if isinstance(sub_cfg, dict) and sub_cfg.get("enabled", False):
                transforms.append(cls(sub_cfg))
        return transforms

    def __call__(self, image: np.ndarray) -> np.ndarray:
        if not self.enabled or not self.transforms:
            return image
        for transform in self.transforms:
            image = transform(image, self.rng)
        return image


class TTAPipeline:
    """Test-Time Augmentation pipeline for inference."""

    _DEFAULT_CONFIG: Dict[str, Any] = {
        "transforms": {
            "horizontal_flip": {
                "enabled": True,
            },
            "brightness_contrast": {
                "enabled": True,
                "brightness_range": [0.9, 1.1],
                "contrast_range": [0.9, 1.1],
            },
            "gaussian_noise": {
                "enabled": True,
                "std_min": 0.01,
                "std_max": 0.03,
            },
        }
    }

    def __init__(
        self,
        num_augmentations: int = 7,
        config: Optional[dict] = None,
        random_seed: Optional[int] = None,
    ):
        self.num_augmentations = max(1, int(num_augmentations))
        self.config = config or {}
        self.random_seed = int(
            self.config.get("random_seed", 0) if random_seed is None else random_seed
        )
        self.transforms = self._build_tta_transforms(self.config)

    def _build_tta_transforms(self, config: Optional[dict]) -> list:
        resolved = dict(self._DEFAULT_CONFIG)
        transforms_config = dict(self._DEFAULT_CONFIG["transforms"])

        if isinstance(config, dict):
            if isinstance(config.get("transforms"), dict):
                transforms_config.update(config["transforms"])
            else:
                transforms_config.update(config)
            resolved.update(config)

        transforms = []
        for key, cls in _TRANSFORM_REGISTRY.items():
            sub_cfg = transforms_config.get(key, {})
            if isinstance(sub_cfg, dict) and sub_cfg.get("enabled", False):
                sub_cfg = dict(sub_cfg)
                sub_cfg["probability"] = 1.0
                transforms.append(cls(sub_cfg))
        return transforms

    def _make_rng(self, image_id: Optional[str] = None) -> np.random.RandomState:
        if not image_id:
            return np.random.RandomState(self.random_seed)
        digest = hashlib.sha256(f"{self.random_seed}:{image_id}".encode("utf-8")).hexdigest()
        seed = int(digest[:8], 16)
        return np.random.RandomState(seed)

    def __call__(self, image: np.ndarray, image_id: Optional[str] = None) -> List[np.ndarray]:
        variants = [np.asarray(image, dtype=np.float32).copy()]
        if self.num_augmentations == 1:
            return variants

        rng = self._make_rng(image_id)
        for _ in range(self.num_augmentations - 1):
            aug_image = np.asarray(image, dtype=np.float32).copy()
            for transform in self.transforms:
                aug_image = transform(aug_image, rng)
            variants.append(np.asarray(aug_image, dtype=np.float32))
        return variants

    def predict_with_tta(self, model, image: np.ndarray, device, image_id: Optional[str] = None) -> float:
        device_obj = torch.device(device)
        probabilities: List[float] = []
        variants = self.__call__(image, image_id=image_id)

        with torch.no_grad():
            for variant in variants:
                tensor = torch.from_numpy(np.asarray(variant, dtype=np.float32)).unsqueeze(0).unsqueeze(0).to(device_obj)
                logits = model(tensor)
                probabilities.append(float(torch.sigmoid(logits.reshape(-1)[0]).item()))

        return float(np.mean(probabilities)) if probabilities else 0.0

    def extract_features_with_tta(self, model, image: np.ndarray, device, image_id: Optional[str] = None) -> np.ndarray:
        device_obj = torch.device(device)
        features: List[np.ndarray] = []
        variants = self.__call__(image, image_id=image_id)

        with torch.no_grad():
            for variant in variants:
                tensor = torch.from_numpy(np.asarray(variant, dtype=np.float32)).unsqueeze(0).unsqueeze(0).to(device_obj)
                feature = model.extract_features(tensor).detach().cpu().numpy().reshape(-1)
                features.append(feature.astype(np.float32))

        if not features:
            return np.empty((0,), dtype=np.float32)
        return np.stack(features, axis=0).mean(axis=0).astype(np.float32)
