from __future__ import annotations

from types import SimpleNamespace

import numpy as np
import pytest
import torch

from src.data.augmentation import TTAPipeline
from src.prediction.patient_predictor import PatientPredictor
from src.training.axis_trainer import AxisTrainer
from src.training.fusion_feature_cache import build_patient_feature_cache
from src.training.trainer import Trainer


class DummyAxisModel(torch.nn.Module):
    def forward(self, x):
        return x.mean(dim=(1, 2, 3), keepdim=True)

    def extract_features(self, x):
        means = x.mean(dim=(1, 2, 3))
        max_values = x.amax(dim=(1, 2, 3))
        return torch.stack([means, max_values], dim=1)


def test_tta_pipeline_is_deterministic_per_image_id_and_keeps_original_first():
    image = np.arange(16, dtype=np.float32).reshape(4, 4)
    pipeline = TTAPipeline(
        num_augmentations=3,
        random_seed=123,
        config={
            "transforms": {
                "gaussian_noise": {
                    "enabled": True,
                    "std_min": 0.01,
                    "std_max": 0.02,
                }
            }
        },
    )

    variants_a = pipeline(image, image_id="patient-a/image-1.png")
    variants_b = pipeline(image, image_id="patient-a/image-1.png")
    variants_c = pipeline(image, image_id="patient-b/image-1.png")

    assert len(variants_a) == 3
    np.testing.assert_array_equal(variants_a[0], image)
    assert pipeline.transforms[0].probability == 1.0
    np.testing.assert_allclose(variants_a[1], variants_b[1])
    assert not np.allclose(variants_a[1], variants_c[1])


def test_tta_pipeline_predict_and_extract_average_outputs():
    image = np.array([[0.0, 1.0], [2.0, 3.0]], dtype=np.float32)
    pipeline = TTAPipeline(num_augmentations=2, random_seed=7)
    pipeline.__call__ = lambda img, image_id=None: [img, img + 1.0]
    model = DummyAxisModel()

    probability = pipeline.predict_with_tta(model, image, "cpu", image_id="img-1")
    features = pipeline.extract_features_with_tta(model, image, "cpu", image_id="img-1")

    expected_probability = np.mean(
        [
            torch.sigmoid(torch.tensor(image.mean(), dtype=torch.float32)).item(),
            torch.sigmoid(torch.tensor((image + 1.0).mean(), dtype=torch.float32)).item(),
        ]
    )
    expected_features = np.array(
        [
            np.mean([image.mean(), (image + 1.0).mean()]),
            np.mean([image.max(), (image + 1.0).max()]),
        ],
        dtype=np.float32,
    )

    assert probability == pytest.approx(expected_probability)
    np.testing.assert_allclose(features, expected_features)


def test_axis_trainer_evaluate_loader_uses_image_path_as_tta_id():
    class FakeImageProcessor:
        def load_image(self, image_path):
            assert image_path == "patient-1_0_0_1.png"
            return np.array([[1.0, 2.0], [3.0, 4.0]], dtype=np.float32)

        def normalize_image(self, image):
            return image.astype(np.float32)

    class FakeDataset:
        samples = [("patient-1_0_0_1.png", 1.0)]
        image_processor = FakeImageProcessor()

    class FakeLoader:
        dataset = FakeDataset()

        def __iter__(self):
            batch = torch.zeros((1, 1, 2, 2), dtype=torch.float32)
            labels = torch.tensor([1.0], dtype=torch.float32)
            yield batch, labels

        def __len__(self):
            return 1

    class FakeTTA:
        def __init__(self):
            self.image_ids = []

        def predict_with_tta(self, model, image, device, image_id=None):
            self.image_ids.append(image_id)
            return 0.8

    trainer = AxisTrainer.__new__(AxisTrainer)
    trainer.model = SimpleNamespace(eval=lambda: None)
    trainer.device = torch.device("cpu")
    trainer.criterion = torch.nn.BCEWithLogitsLoss()
    trainer._consume_batch_samples = Trainer._consume_batch_samples

    tta = FakeTTA()
    metrics = AxisTrainer._evaluate_loader_with_patient_mean(
        trainer,
        FakeLoader(),
        "验证中",
        tracker=None,
        tta_pipeline=tta,
    )

    assert tta.image_ids == ["patient-1_0_0_1.png"]
    assert metrics["accuracy"] == pytest.approx(1.0)
    assert metrics["predict_accuracy"] == pytest.approx(1.0)


def test_patient_predictor_predict_axis_outputs_uses_tta_for_probabilities_and_features():
    class FakeTTA:
        def __init__(self):
            self.predict_ids = []
            self.feature_ids = []

        def predict_with_tta(self, model, image, device, image_id=None):
            self.predict_ids.append(image_id)
            return float(image.mean())

        def extract_features_with_tta(self, model, image, device, image_id=None):
            self.feature_ids.append(image_id)
            return np.array([float(image.mean()), float(image.max())], dtype=np.float32)

    predictor = PatientPredictor.__new__(PatientPredictor)
    predictor.device = torch.device("cpu")
    predictor.axis_models = {"x": object()}

    image_map = {
        "img-a.png": np.array([[1.0, 3.0]], dtype=np.float32),
        "img-b.png": np.array([[2.0, 4.0]], dtype=np.float32),
    }
    predictor._load_axis_image_numpy = lambda image_path: image_map[image_path]

    tta = FakeTTA()
    probability, feature = PatientPredictor._predict_axis_outputs(
        predictor,
        ["img-a.png", "img-b.png"],
        "x",
        tta_pipeline=tta,
    )

    assert probability == pytest.approx(2.5)
    np.testing.assert_allclose(feature, np.array([2.5, 3.5], dtype=np.float32))
    assert tta.predict_ids == ["img-a.png", "img-b.png"]
    assert tta.feature_ids == ["img-a.png", "img-b.png"]


def test_build_patient_feature_cache_supports_tta():
    class FakeEncoder:
        def to(self, device):
            return self

        def eval(self):
            return self

    class FakeTTA:
        def __init__(self):
            self.image_ids = []

        def extract_features_with_tta(self, model, image, device, image_id=None):
            self.image_ids.append(image_id)
            return np.array([float(image.mean()), float(image.max())], dtype=np.float32)

    dataset = [
        {
            "patient_id": "P1",
            "label": torch.tensor(1.0),
            "axis_images": {
                "x": torch.tensor(
                    [
                        [[[1.0, 3.0]]],
                        [[[2.0, 4.0]]],
                    ],
                    dtype=torch.float32,
                )
            },
            "axis_image_paths": {
                "x": ["img-a.png", "img-b.png"]
            },
        }
    ]

    tta = FakeTTA()
    rows = build_patient_feature_cache(
        dataset,
        {"x": FakeEncoder()},
        device="cpu",
        tta_pipeline=tta,
    )

    np.testing.assert_allclose(rows["P1"]["x"], np.array([2.5, 3.5], dtype=np.float32))
    assert tta.image_ids == ["img-a.png", "img-b.png"]
