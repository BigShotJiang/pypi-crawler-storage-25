import subprocess
import unittest


class LegacyEntrypointsTest(unittest.TestCase):
    def test_train_py_help_still_works_with_simplified_options(self):
        result = subprocess.run(
            ["conda", "run", "-n", "Vit", "python", "train.py", "--help"],
            capture_output=True,
            text=True,
            check=False,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("--config_path", result.stdout)
        self.assertIn("--disable_memory_preload", result.stdout)
        self.assertNotIn("--mode", result.stdout)
        self.assertNotIn("--cv_folds", result.stdout)
        self.assertNotIn("--enable_memory_preload", result.stdout)

    def test_predict_py_help_still_works_with_dual_output_options(self):
        result = subprocess.run(
            ["conda", "run", "-n", "Vit", "python", "predict.py", "--help"],
            capture_output=True,
            text=True,
            check=False,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("--model", result.stdout)
        self.assertIn("--data", result.stdout)
        self.assertIn("--fusion", result.stdout)
        self.assertNotIn("--thresholds", result.stdout)
        option_tokens = {token for token in result.stdout.split() if token.startswith("--")}
        self.assertIn("--config", option_tokens)
        self.assertIn("--mode", option_tokens)
        self.assertIn("--fusion-checkpoint", option_tokens)
        self.assertNotIn("--feature", option_tokens)
        self.assertNotIn("--threshold_optimization", option_tokens)


if __name__ == "__main__":
    unittest.main()
