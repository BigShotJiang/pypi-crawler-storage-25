from __future__ import annotations

from types import SimpleNamespace

import pytest
import torch
from torch.utils.data import Dataset, WeightedRandomSampler

from src.data.dataset import DataLoaderManager
from src.training.trainer import Trainer


class DummyDataset(Dataset):
    def __init__(self):
        self.samples = [
            ("img-0.png", 0),
            ("img-1.png", 0),
            ("img-2.png", 0),
            ("img-3.png", 1),
        ]

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        return torch.zeros(1, 16, 16), torch.tensor(float(self.samples[index][1]))


def test_dataloader_manager_uses_weighted_random_sampler_for_balanced_sampling():
    manager = DataLoaderManager.__new__(DataLoaderManager)
    manager.batch_size = 2
    manager.num_workers = 0
    manager.pin_memory = False
    manager.enable_memory_preload = False
    manager.collator = lambda batch: batch
    manager.memory_preloader = None
    manager.get_train_dataset = lambda memory_preloader=None: DummyDataset()

    loader = DataLoaderManager.get_train_dataloader(manager, balanced=True)

    assert isinstance(loader.sampler, WeightedRandomSampler)
    weights = loader.sampler.weights.tolist()
    assert weights == pytest.approx([1 / 3, 1 / 3, 1 / 3, 1.0])


def test_trainer_merges_balanced_and_hard_example_weights_multiplicatively():
    trainer = Trainer.__new__(Trainer)

    merged = Trainer._merge_sample_weights(
        trainer,
        torch.tensor([0.5, 0.5, 1.0, 1.0], dtype=torch.float32),
        hard_indices=[1, 3],
        weight_factor=2.0,
    )

    assert merged.tolist() == pytest.approx([0.5, 1.0, 1.0, 2.0])


def test_trainer_rebuild_loader_with_weights_uses_weighted_random_sampler():
    trainer = Trainer.__new__(Trainer)
    dataset = DummyDataset()
    base_loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=2,
        shuffle=False,
        num_workers=0,
        pin_memory=False,
        collate_fn=lambda batch: batch,
        drop_last=True,
    )

    rebuilt = Trainer._rebuild_loader_with_weights(
        trainer,
        base_loader,
        torch.tensor([1.0, 2.0, 3.0, 4.0], dtype=torch.float32),
    )

    assert isinstance(rebuilt.sampler, WeightedRandomSampler)
    assert rebuilt.batch_size == 2
    assert rebuilt.drop_last is True
