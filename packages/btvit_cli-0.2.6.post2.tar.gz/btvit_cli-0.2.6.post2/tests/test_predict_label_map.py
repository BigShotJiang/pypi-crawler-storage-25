import importlib
import sys
import tempfile
import types
import unittest
from unittest import mock
from pathlib import Path


class PredictLabelMapTest(unittest.TestCase):
    def test_load_label_map_supports_patient_id_label_header(self):
        csv_content = "\n".join(
            [
                "patient_id,label",
                "MR201201050173,0",
                "MR201201030297,1",
            ]
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            csv_path = Path(tmpdir) / "label.csv"
            csv_path.write_text(csv_content, encoding="utf-8")

            label_map = self._load_label_map()(str(csv_path))

        self.assertEqual(
            label_map,
            {
                "MR201201050173": 0,
                "MR201201030297": 1,
            },
        )

    def test_load_label_map_supports_bucketed_zero_one_header(self):
        csv_content = "\n".join(
            [
                "0,1",
                "MR201201050173,MR201201030297",
                "MR201202080233,MR201201060564",
            ]
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            csv_path = Path(tmpdir) / "label.csv"
            csv_path.write_text(csv_content, encoding="utf-8")

            label_map = self._load_label_map()(str(csv_path))

        self.assertEqual(
            label_map,
            {
                "MR201201050173": 0,
                "MR201202080233": 0,
                "MR201201030297": 1,
                "MR201201060564": 1,
            },
        )

    def test_load_label_map_rejects_unsupported_headers(self):
        csv_content = "\n".join(
            [
                "negative,positive",
                "MR201201050173,MR201201030297",
            ]
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            csv_path = Path(tmpdir) / "label.csv"
            csv_path.write_text(csv_content, encoding="utf-8")

            with self.assertRaisesRegex(ValueError, "patient_id,label 或 0,1"):
                self._load_label_map()(str(csv_path))

    def _load_label_map(self):
        fake_matplotlib = types.ModuleType("matplotlib")
        fake_pyplot = types.ModuleType("matplotlib.pyplot")
        fake_numpy = types.ModuleType("numpy")
        fake_torch = types.ModuleType("torch")
        fake_utils_package = types.ModuleType("src.utils")
        fake_utils_package.__path__ = []
        fake_logger_module = types.ModuleType("src.utils.logger")
        fake_logger_module.get_logger = lambda *args, **kwargs: None
        fake_prediction_package = types.ModuleType("src.prediction")
        fake_prediction_package.__path__ = []
        fake_predictor_module = types.ModuleType("src.prediction.multi_axis_predictor")
        fake_predictor_module.MultiAxisPredictor = object

        with mock.patch.dict(
            sys.modules,
            {
                "matplotlib": fake_matplotlib,
                "matplotlib.pyplot": fake_pyplot,
                "numpy": fake_numpy,
                "torch": fake_torch,
                "src.utils": fake_utils_package,
                "src.utils.logger": fake_logger_module,
                "src.prediction": fake_prediction_package,
                "src.prediction.multi_axis_predictor": fake_predictor_module,
            },
        ):
            sys.modules.pop("src.cli.predict_impl", None)
            predict_impl = importlib.import_module("src.cli.predict_impl")
        return predict_impl.load_label_map


if __name__ == "__main__":
    unittest.main()
