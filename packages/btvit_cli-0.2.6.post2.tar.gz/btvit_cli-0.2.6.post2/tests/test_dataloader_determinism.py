from src.data.dataset import DataLoaderManager


def test_train_dataloader_accepts_same_mode_seeded_generator():
    manager = DataLoaderManager.__new__(DataLoaderManager)
    manager.batch_size = 2
    manager.num_workers = 0
    manager.pin_memory = False
    manager.collator = lambda batch: batch
    manager.enable_memory_preload = False
    manager.memory_preloader = None
    manager.get_train_dataset = lambda memory_preloader=None: [1, 2, 3, 4]

    loader = manager.get_train_dataloader(init_mode="same", seed=123)

    assert loader.generator is not None
    assert loader.worker_init_fn is not None

