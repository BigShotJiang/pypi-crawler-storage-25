import unittest

from typer.testing import CliRunner

from src import __version__


class CliMainTest(unittest.TestCase):
    def test_typer_app_exposes_expected_top_level_commands(self):
        from src.cli.main import app

        command_names = {command.name for command in app.registered_commands}

        self.assertIn("train", command_names)
        self.assertIn("pred", command_names)
        self.assertIn("get", command_names)
        self.assertIn("version", command_names)

    def test_version_command_uses_package_version(self):
        from src.cli.main import app

        runner = CliRunner()
        result = runner.invoke(app, ["version"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn(__version__, result.stdout)

    def test_train_help_mentions_stage_aware_options(self):
        from src.cli.main import app

        runner = CliRunner()
        result = runner.invoke(app, ["train", "--help"])

        self.assertEqual(result.exit_code, 0, result.stdout)
        self.assertIn("--stage", result.stdout)
        self.assertIn("--axis", result.stdout)


if __name__ == "__main__":
    unittest.main()
