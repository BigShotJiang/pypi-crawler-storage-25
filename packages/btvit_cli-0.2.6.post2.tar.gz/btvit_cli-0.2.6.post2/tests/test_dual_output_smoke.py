import tempfile
import unittest
from pathlib import Path
from unittest import mock

from typer.testing import CliRunner

from src.cli.main import app
from src.cli.utils import export_cli_templates


class DualOutputCliSmokeTest(unittest.TestCase):
    def test_axis_then_fusion_then_prediction_smoke(self):
        runner = CliRunner()

        with mock.patch("src.cli.train_cmd.execute_train") as execute_train, mock.patch(
            "src.cli.predict_cmd.execute_predict_args"
        ) as execute_predict:
            axis_result = runner.invoke(app, ["train", "--config", "cfg", "--stage", "axis", "--axis", "x"])
            fusion_result = runner.invoke(app, ["train", "--config", "cfg", "--stage", "fusion"])
            pred_result = runner.invoke(app, ["pred", "--mode", "both", "--config", "cfg", "--data", "dataset"])

        self.assertEqual(axis_result.exit_code, 0, axis_result.output)
        self.assertEqual(fusion_result.exit_code, 0, fusion_result.output)
        self.assertEqual(pred_result.exit_code, 0, pred_result.output)
        self.assertEqual(execute_train.call_count, 2)
        self.assertEqual(execute_predict.call_count, 1)

    def test_generated_usage_mentions_stage_and_mode(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = export_cli_templates(str(tmpdir))
            usage = (Path(output_dir) / "USAGE.md").read_text(encoding="utf-8")

        self.assertIn("--stage axis", usage)
        self.assertIn("--stage fusion", usage)
        self.assertIn("--mode weighted_vote|fusion_nn|both", usage)

    def test_docs_describe_axis_fusion_and_dual_mode_prediction(self):
        readme = Path("README.md").read_text(encoding="utf-8")
        predict_usage = Path("predict_usage.md").read_text(encoding="utf-8")

        self.assertIn("--stage axis", readme)
        self.assertIn("--stage fusion", readme)
        self.assertIn("fusion_nn", readme)
        self.assertIn("--mode weighted_vote|fusion_nn|both", predict_usage)
        self.assertNotIn("KNN", readme)
        self.assertNotIn("feature store", predict_usage.lower())


if __name__ == "__main__":
    unittest.main()
