from pathlib import Path

import cv2
import numpy as np

from src.data.fusion_dataset import FusionPatientDataset


def _make_png(path: Path, value: int) -> None:
    image = np.full((16, 368), value, dtype=np.uint8)
    cv2.imwrite(str(path), image)


def test_fusion_dataset_returns_patient_level_multi_axis_sample(tmp_path):
    label_path = tmp_path / "label.csv"
    label_path.write_text("patient_id,label\nP001,1\n", encoding="utf-8")

    axis_paths = {}
    for axis, value in (("x", 64), ("y", 128), ("z", 192)):
        axis_dir = tmp_path / f"data-{axis}"
        axis_dir.mkdir()
        axis_paths[axis] = str(axis_dir)

        for index in range(4):
            if axis == "x":
                filename = f"P001_{index}_0_0.png"
            elif axis == "y":
                filename = f"P001_0_{index}_0.png"
            else:
                filename = f"P001_0_0_{index}.png"
            _make_png(axis_dir / filename, value)

    dataset = FusionPatientDataset(
        patient_ids=["P001"],
        axis_data_paths=axis_paths,
        label_path=str(label_path),
        active_axes=["x", "y", "z"],
    )

    sample = dataset[0]

    assert sample["patient_id"] == "P001"
    assert sample["label"].item() == 1.0
    assert len(sample["axis_images"]["x"]) == 4
    assert len(sample["axis_images"]["y"]) == 4
    assert len(sample["axis_images"]["z"]) == 4
    assert sample["axis_images"]["x"].shape == (4, 1, 16, 368)
