import unittest

from typer.testing import CliRunner

from src.cli.main import app


class CliPredHelpTest(unittest.TestCase):
    def test_vit_pred_help_describes_dual_output_modes_and_checkpoints(self):
        runner = CliRunner()
        result = runner.invoke(app, ["pred", "--help"])

        self.assertEqual(result.exit_code, 0, result.stdout)
        self.assertIn("--mode", result.stdout)
        self.assertIn("weighted_vote", result.stdout)
        self.assertIn("fusion_nn", result.stdout)
        self.assertIn("both", result.stdout)
        self.assertIn("--config", result.stdout)
        self.assertIn("--model", result.stdout)
        self.assertIn("--axis-checkpoint-x", result.stdout)
        self.assertIn("--axis-checkpoint-y", result.stdout)
        self.assertIn("--axis-checkpoint-z", result.stdout)
        self.assertIn("--fusion-checkpoint", result.stdout)
        self.assertRegex(result.stdout, r"--fusion\s+TEXT")
        self.assertNotIn("--weighted-vote-threshold", result.stdout)
        self.assertNotIn("--thresholds", result.stdout)

    def test_predict_cli_requires_mode(self):
        runner = CliRunner()
        result = runner.invoke(app, ["pred", "--model", "m.pth", "--data", "dataset"])

        self.assertNotEqual(result.exit_code, 0)
        self.assertIn("--mode", result.output)


if __name__ == "__main__":
    unittest.main()
