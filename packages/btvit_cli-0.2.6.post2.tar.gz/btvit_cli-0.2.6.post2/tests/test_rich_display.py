import io
import types
import unittest
from unittest.mock import patch

from src.utils.rich_display import print_rich_training_config, print_rich_training_results, _format_duration


class RichDurationFormatTest(unittest.TestCase):
    def test_format_duration_under_one_minute(self):
        self.assertEqual(_format_duration(45), "45s")

    def test_format_duration_with_minutes(self):
        self.assertEqual(_format_duration(754), "12m 34s")

    def test_format_duration_with_hours(self):
        self.assertEqual(_format_duration(3723), "1h 2m 3s")


class RichTrainingConfigTest(unittest.TestCase):
    @patch("src.utils.rich_display.runtime_config_display_sections")
    def test_print_rich_config_outputs_panel(self, mock_sections):
        mock_sections.return_value = {
            "MODEL CONFIG": {"dim": 512, "depth": 6},
            "DATA CONFIG": {"batch_size": 32},
        }
        with patch("src.utils.rich_display.Console") as mock_console_cls:
            mock_console = mock_console_cls.return_value
            print_rich_training_config(types.SimpleNamespace())
            mock_console.print.assert_called_once()

    @patch("src.utils.rich_display.runtime_config_display_sections")
    def test_print_rich_config_contains_section_headers(self, mock_sections):
        mock_sections.return_value = {
            "MODEL CONFIG": {"dim": 512},
            "TRAINING CONFIG": {"epochs": 200},
        }
        print_rich_training_config(types.SimpleNamespace())


class RichTrainingResultsTest(unittest.TestCase):
    def test_print_rich_results_outputs_panel(self):
        results = {
            "val_history": [{"loss": 0.3, "predict_accuracy": 0.85}],
            "test_metrics": {"accuracy": 0.82, "auc": 0.91},
        }
        with patch("src.utils.rich_display.Console") as mock_console_cls:
            mock_console = mock_console_cls.return_value
            print_rich_training_results(types.SimpleNamespace(), results, 754.0)
            mock_console.print.assert_called_once()


if __name__ == "__main__":
    unittest.main()
