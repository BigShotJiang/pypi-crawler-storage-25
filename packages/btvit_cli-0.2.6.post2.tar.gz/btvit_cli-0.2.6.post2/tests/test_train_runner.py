import unittest
from unittest.mock import patch

from typer.testing import CliRunner


class TrainRunnerTest(unittest.TestCase):
    def test_vit_train_help_hides_removed_flags_and_keeps_disable_memory_preload(self):
        from src.cli.main import app

        runner = CliRunner()
        result = runner.invoke(app, ["train", "--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("--config", result.stdout)
        self.assertIn("--stage", result.stdout)
        self.assertIn("--disable-memory-preload", result.stdout)
        self.assertNotIn("会覆盖配置文件中的 data_path", result.stdout)
        self.assertIn("patient_id,label", result.stdout)
        self.assertIn("--init", result.stdout)
        self.assertIn("--init-seed", result.stdout)
        self.assertIn("--train-split-seed", result.stdout)
        self.assertNotIn("--mode", result.stdout)
        self.assertNotIn("--cv-folds", result.stdout)
        self.assertNotIn("--enable-memory-preload", result.stdout)

    @patch("src.cli.train_cmd.execute_train")
    def test_vit_train_maps_cli_overrides_into_shared_execution(self, execute_train_mock):
        from src.cli.main import app

        runner = CliRunner()
        result = runner.invoke(
            app,
            [
                "train",
                "--config", "configs/base",
                "--stage", "axis",
                "--axis", "x",
                "--data", "dataset/data",
                "--label", "dataset/label.csv",
                "--init", "random",
                "--init-seed", "123",
                "--random-seed", "456",
                "--train-split-seed", "789",
                "--verbose",
                "--disable-memory-preload",
                "--resume",
            ],
        )

        self.assertEqual(result.exit_code, 0)
        execute_train_mock.assert_called_once()
        kwargs = execute_train_mock.call_args.kwargs
        self.assertEqual(kwargs["config_path"], "configs/base")
        self.assertEqual(kwargs["stage"], "axis")
        self.assertEqual(kwargs["axis"], "x")
        self.assertEqual(kwargs["data_path"], "dataset/data")
        self.assertEqual(kwargs["label_path"], "dataset/label.csv")
        self.assertEqual(kwargs["init"], "random")
        self.assertEqual(kwargs["init_seed"], 123)
        self.assertEqual(kwargs["random_seed"], 456)
        self.assertEqual(kwargs["train_split_seed"], 789)
        self.assertTrue(kwargs["verbose"])
        self.assertTrue(kwargs["disable_memory_preload"])
        self.assertEqual(kwargs["resume"], "latest")


if __name__ == "__main__":
    unittest.main()
