import tempfile
import unittest
from pathlib import Path


class PredictionConfusionMatrixTest(unittest.TestCase):
    def test_labeled_predictions_generate_confusion_matrix_png(self):
        from predict import save_prediction_outputs

        rows = [
            {
                "patient_id": "PAT001",
                "weighted_vote_prob": 0.91,
                "weighted_vote_pred": 1,
                "label": 1,
                "weighted_vote_pass": True,
            },
            {
                "patient_id": "PAT002",
                "weighted_vote_prob": 0.12,
                "weighted_vote_pred": 0,
                "label": 1,
                "weighted_vote_pass": False,
            },
        ]

        with tempfile.TemporaryDirectory() as tmpdir:
            output_paths = save_prediction_outputs(rows=rows, summary={"patient_count": 2}, output_dir=Path(tmpdir))

            self.assertIn("confusion_matrix_weighted_vote_png", output_paths)
            self.assertTrue(Path(output_paths["confusion_matrix_weighted_vote_png"]).exists())

    def test_unlabeled_predictions_skip_confusion_matrix_png(self):
        from predict import save_prediction_outputs

        rows = [
            {
                "patient_id": "PAT001",
                "weighted_vote_prob": 0.91,
                "weighted_vote_pred": 1,
            },
        ]

        with tempfile.TemporaryDirectory() as tmpdir:
            output_paths = save_prediction_outputs(rows=rows, summary={"patient_count": 1}, output_dir=Path(tmpdir))

            self.assertNotIn("confusion_matrix_weighted_vote_png", output_paths)
            self.assertFalse((Path(tmpdir) / "confusion_matrix_weighted_vote.png").exists())


if __name__ == "__main__":
    unittest.main()
