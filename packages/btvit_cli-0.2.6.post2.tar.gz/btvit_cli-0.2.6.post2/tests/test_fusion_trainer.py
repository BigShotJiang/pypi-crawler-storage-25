from pathlib import Path
from types import SimpleNamespace

import pytest
import torch

from src.model.axis_model import AxisViTModel
from src.training.fusion_trainer import FusionTrainer, resolve_axis_checkpoints


def _make_fusion_config(tmp_path: Path, freeze_encoders: bool = True, fusion_mode: str = "concat"):
    fusion_root = tmp_path / "fusion"
    return SimpleNamespace(
        model=SimpleNamespace(
            input_shape=[16, 368],
            patch_size=[16, 16],
            num_classes=1,
            dim=32,
            depth=1,
            heads=1,
            mlp_dim=64,
            channels=1,
            dim_head=32,
            dropout=0.1,
            emb_dropout=0.1,
            rope_min_freq=1.0,
            rope_max_freq=10000.0,
            rope_p_zero_freqs=0.0,
        ),
        training=SimpleNamespace(
            common=SimpleNamespace(device="cpu"),
            fusion=SimpleNamespace(
                epochs=2,
                learning_rate=1e-3,
                weight_decay=0.0,
                optimizer="AdamW",
                scheduler="",
                scheduler_params={},
                batch_size=2,
                freeze_encoders=freeze_encoders,
            ),
        ),
        multi_axis=SimpleNamespace(
            active_axes=["x", "y", "z"],
            fusion_head=SimpleNamespace(fusion=fusion_mode, type="linear", hidden_dim=32, dropout=0.1),
        ),
        monitoring=SimpleNamespace(
            fusion=SimpleNamespace(
                early_stopping={"enabled": False},
                model_selection={"metric": "val_auc", "mode": "max"},
            ),
            verbose=False,
        ),
        experiment=SimpleNamespace(
            name="exp",
            save_dir=str(tmp_path),
            checkpoint_dir=str(fusion_root / "checkpoints"),
            result_dir=str(fusion_root / "results"),
            log_dir=str(fusion_root / "logs"),
        ),
    )


def _save_axis_checkpoint(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    model = AxisViTModel(
        input_shape=(16, 368),
        patch_size=(16, 16),
        dim=32,
        depth=1,
        heads=1,
        mlp_dim=64,
        channels=1,
        dim_head=32,
        dropout=0.1,
        emb_dropout=0.1,
        rope_min_freq=1.0,
        rope_max_freq=10000.0,
        rope_p_zero_freqs=0.0,
    )
    torch.save({"model_state_dict": model.state_dict()}, path)


def test_fusion_stage_loads_axis_checkpoints_and_freezes_encoders(tmp_path):
    config = _make_fusion_config(tmp_path, freeze_encoders=True)
    checkpoint_paths = {}
    for axis in ("x", "y", "z"):
        checkpoint_path = tmp_path / f"axis-{axis}.pth"
        _save_axis_checkpoint(checkpoint_path)
        checkpoint_paths[axis] = str(checkpoint_path)

    trainer = FusionTrainer(config, axis_checkpoint_paths=checkpoint_paths)

    assert all(not parameter.requires_grad for parameter in trainer.encoders["x"].parameters())
    assert all(not parameter.requires_grad for parameter in trainer.encoders["y"].parameters())
    assert all(not parameter.requires_grad for parameter in trainer.encoders["z"].parameters())


def test_fusion_stage_maps_val_auc_to_auc_metric(tmp_path):
    config = _make_fusion_config(tmp_path, freeze_encoders=True)
    checkpoint_paths = {}
    for axis in ("x", "y", "z"):
        checkpoint_path = tmp_path / f"axis-{axis}.pth"
        _save_axis_checkpoint(checkpoint_path)
        checkpoint_paths[axis] = str(checkpoint_path)

    trainer = FusionTrainer(config, axis_checkpoint_paths=checkpoint_paths)

    assert trainer._metric_value({"auc": 0.7817}, "val_auc") == pytest.approx(0.7817)


def test_fusion_stage_uses_sum_mode_for_input_dim_and_feature_rows(tmp_path):
    config = _make_fusion_config(tmp_path, freeze_encoders=True, fusion_mode="sum")
    checkpoint_paths = {}
    for axis in ("x", "y", "z"):
        checkpoint_path = tmp_path / f"{axis}.pth"
        _save_axis_checkpoint(checkpoint_path)
        checkpoint_paths[axis] = str(checkpoint_path)

    trainer = FusionTrainer(config, axis_checkpoint_paths=checkpoint_paths)
    dataset = trainer._feature_rows_to_dataset(
        {
            "P001": {"x": [0.1] * 32, "y": [0.2] * 32, "z": [0.3] * 32, "label": 1},
        }
    )

    feature_tensor, label_tensor = dataset[0]

    assert trainer.model.input_dim == 32
    assert feature_tensor.shape == (32,)
    assert label_tensor.item() == pytest.approx(1.0)


def test_fusion_stage_train_uses_val_auc_alias_for_best_metric(tmp_path, monkeypatch):
    config = _make_fusion_config(tmp_path, freeze_encoders=True)
    checkpoint_paths = {}
    for axis in ("x", "y", "z"):
        checkpoint_path = tmp_path / f"axis-{axis}.pth"
        _save_axis_checkpoint(checkpoint_path)
        checkpoint_paths[axis] = str(checkpoint_path)

    trainer = FusionTrainer(config, axis_checkpoint_paths=checkpoint_paths)

    feature_rows = {
        "P001": {"x": [0.1] * 32, "y": [0.2] * 32, "z": [0.3] * 32, "label": 1},
        "P002": {"x": [0.4] * 32, "y": [0.5] * 32, "z": [0.6] * 32, "label": 0},
    }

    monkeypatch.setattr("src.training.fusion_trainer.build_patient_feature_cache", lambda dataset, encoders, device='cpu': feature_rows)
    monkeypatch.setattr(trainer, "_evaluate_loader", lambda data_loader, tracker=None: {"auc": 0.7817, "loss": 0.5})

    saved = []
    monkeypatch.setattr(trainer, "save_checkpoint", lambda epoch, metric, is_best=False: saved.append((epoch, metric, is_best)))

    trainer.train(train_dataset=object(), val_dataset=object())

    assert trainer.best_metric == pytest.approx(0.7817)
    assert any(is_best and metric == pytest.approx(0.7817) for _, metric, is_best in saved)


def test_fusion_stage_train_uses_seeded_generator_in_same_mode(tmp_path, monkeypatch):
    config = _make_fusion_config(tmp_path, freeze_encoders=True)
    config.training.random_seed = 17
    config.training.init = SimpleNamespace(init_mode="same", init_seed=23)
    checkpoint_paths = {}
    for axis in ("x", "y", "z"):
        checkpoint_path = tmp_path / f"axis-{axis}.pth"
        _save_axis_checkpoint(checkpoint_path)
        checkpoint_paths[axis] = str(checkpoint_path)

    trainer = FusionTrainer(config, axis_checkpoint_paths=checkpoint_paths)
    feature_rows = {
        "P001": {"x": [0.1] * 32, "y": [0.2] * 32, "z": [0.3] * 32, "label": 1},
        "P002": {"x": [0.4] * 32, "y": [0.5] * 32, "z": [0.6] * 32, "label": 0},
    }

    monkeypatch.setattr("src.training.fusion_trainer.build_patient_feature_cache", lambda dataset, encoders, device='cpu': feature_rows)
    monkeypatch.setattr(trainer, "_evaluate_loader", lambda data_loader, tracker=None: {"auc": 0.8, "loss": 0.5})
    monkeypatch.setattr(trainer, "save_checkpoint", lambda epoch, metric, is_best=False: None)

    real_dataloader = torch.utils.data.DataLoader
    captured_kwargs = []

    def recording_dataloader(*args, **kwargs):
        captured_kwargs.append(kwargs.copy())
        return real_dataloader(*args, **kwargs)

    monkeypatch.setattr("src.training.fusion_trainer.DataLoader", recording_dataloader)

    trainer.train(train_dataset=object(), val_dataset=object())

    train_loader_kwargs = captured_kwargs[0]
    assert train_loader_kwargs["shuffle"] is True
    assert train_loader_kwargs["generator"] is not None
    assert callable(train_loader_kwargs["worker_init_fn"])


def test_fusion_stage_fails_when_axis_checkpoint_missing(tmp_path):
    with pytest.raises(FileNotFoundError):
        resolve_axis_checkpoints(str(tmp_path), experiment_name="exp")
