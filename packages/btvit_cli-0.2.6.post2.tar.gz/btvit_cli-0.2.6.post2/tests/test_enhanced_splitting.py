import tempfile
import unittest
from pathlib import Path

from src.data.enhanced_splitting import EnhancedDataSplitter


class EnhancedSplittingTest(unittest.TestCase):
    def test_stratified_split_preserves_configured_test_ratio(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            data_dir = root / "data"
            data_dir.mkdir()
            label_path = root / "label.csv"

            label_lines = ["patient_id,label"]
            for index in range(10):
                patient_id = f"NEG{index:02d}"
                (data_dir / f"{patient_id}_001_0_0.png").write_bytes(b"png")
                label_lines.append(f"{patient_id},0")
            for index in range(10):
                patient_id = f"POS{index:02d}"
                (data_dir / f"{patient_id}_001_0_0.png").write_bytes(b"png")
                label_lines.append(f"{patient_id},1")

            label_path.write_text("\n".join(label_lines) + "\n", encoding="utf-8")

            splitter = EnhancedDataSplitter(str(data_dir), str(label_path))
            splitter.split_data(method="stratified", train_ratio=0.6, val_ratio=0.2, test_ratio=0.2, random_seed=42)

            self.assertEqual(len(splitter.train_patients), 12)
            self.assertEqual(len(splitter.val_patients), 4)
            self.assertEqual(len(splitter.test_patients), 4)
            self.assertEqual(
                len(splitter.train_patients) + len(splitter.val_patients) + len(splitter.test_patients),
                20,
            )


if __name__ == "__main__":
    unittest.main()
