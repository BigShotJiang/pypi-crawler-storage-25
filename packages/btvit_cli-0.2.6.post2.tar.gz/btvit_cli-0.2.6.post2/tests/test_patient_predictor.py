from pathlib import Path

import cv2
import numpy as np
import torch

from src.prediction.patient_predictor import PatientPredictor


def _make_png(path: Path, value: int) -> None:
    image = np.full((16, 368), value, dtype=np.uint8)
    cv2.imwrite(str(path), image)


class DummyAxisModel(torch.nn.Module):
    def forward(self, images):
        values = images.reshape(images.shape[0], -1).mean(dim=1, keepdim=True)
        return (values - 0.25) * 4.0

    def extract_features(self, images):
        values = images.reshape(images.shape[0], -1).mean(dim=1, keepdim=True)
        return values.repeat(1, 4)


class DummyFusionHead(torch.nn.Module):
    def forward(self, features):
        return features.mean(dim=1, keepdim=True) * 2.0 - 0.5


class StrictDimFusionHead(torch.nn.Module):
    def __init__(self, expected_dim: int):
        super().__init__()
        self.expected_dim = expected_dim

    def forward(self, features):
        assert features.shape[1] == self.expected_dim
        return features.mean(dim=1, keepdim=True)


def test_patient_predictor_outputs_weighted_vote_and_fusion_probabilities(tmp_path):
    axis_paths = {}
    for axis, value in (("x", 96), ("y", 160), ("z", 224)):
        axis_dir = tmp_path / f"data-{axis}"
        axis_dir.mkdir()
        axis_paths[axis] = str(axis_dir)

        for index in range(2):
            if axis == "x":
                filename = f"P001_{index}_0_0.png"
            elif axis == "y":
                filename = f"P001_0_{index}_0.png"
            else:
                filename = f"P001_0_0_{index}.png"
            _make_png(axis_dir / filename, value)

    predictor = PatientPredictor.__new__(PatientPredictor)
    predictor.mode = "both"
    predictor.active_axes = ["x", "y", "z"]
    predictor.fusion = "concat"
    predictor.fusion_nn_threshold = 0.5
    predictor.device = torch.device("cpu")
    predictor.verbose = False
    predictor.axis_models = {axis: DummyAxisModel() for axis in predictor.active_axes}
    predictor.fusion_head = DummyFusionHead()
    predictor.image_processor = type("ImageProcessorProxy", (), {})()
    predictor.image_processor.load_image = lambda image_path: cv2.imread(str(image_path), cv2.IMREAD_GRAYSCALE)
    predictor.image_processor.normalize_image = (
        lambda image: image.astype(np.float32) / 255.0
    )

    result = PatientPredictor.predict_patient(predictor, "P001", axis_data_paths=axis_paths)

    assert "weighted_vote_prob" in result
    assert "fusion_nn_prob" in result
    assert "weighted_vote_pred" in result
    assert "fusion_nn_pred" in result
    assert result["weighted_vote_prob"] > (2.0 / 3.0)
    assert result["weighted_vote_pred"] == 1
    assert result["fusion_nn_prob"] > 0.5


def test_patient_predictor_uses_sum_fusion_mode_for_patient_features(tmp_path):
    axis_paths = {}
    for axis, value in (("x", 96), ("y", 160), ("z", 224)):
        axis_dir = tmp_path / f"data-{axis}"
        axis_dir.mkdir()
        axis_paths[axis] = str(axis_dir)

        for index in range(2):
            if axis == "x":
                filename = f"P001_{index}_0_0.png"
            elif axis == "y":
                filename = f"P001_0_{index}_0.png"
            else:
                filename = f"P001_0_0_{index}.png"
            _make_png(axis_dir / filename, value)

    predictor = PatientPredictor.__new__(PatientPredictor)
    predictor.mode = "fusion_nn"
    predictor.active_axes = ["x", "y", "z"]
    predictor.fusion = "sum"
    predictor.fusion_nn_threshold = 0.5
    predictor.device = torch.device("cpu")
    predictor.verbose = False
    predictor.axis_models = {axis: DummyAxisModel() for axis in predictor.active_axes}
    predictor.fusion_head = StrictDimFusionHead(expected_dim=4)
    predictor.image_processor = type("ImageProcessorProxy", (), {})()
    predictor.image_processor.load_image = lambda image_path: cv2.imread(str(image_path), cv2.IMREAD_GRAYSCALE)
    predictor.image_processor.normalize_image = (
        lambda image: image.astype(np.float32) / 255.0
    )

    result = PatientPredictor.predict_patient(predictor, "P001", axis_data_paths=axis_paths)

    assert "fusion_nn_prob" in result
    assert "fusion_nn_pred" in result


def test_patient_predictor_requires_three_axis_vote_sum_above_two_for_positive(tmp_path):
    axis_paths = {}
    for axis, value in (("x", 64), ("y", 96), ("z", 128)):
        axis_dir = tmp_path / f"data-{axis}"
        axis_dir.mkdir()
        axis_paths[axis] = str(axis_dir)

        for index in range(2):
            if axis == "x":
                filename = f"P001_{index}_0_0.png"
            elif axis == "y":
                filename = f"P001_0_{index}_0.png"
            else:
                filename = f"P001_0_0_{index}.png"
            _make_png(axis_dir / filename, value)

    predictor = PatientPredictor.__new__(PatientPredictor)
    predictor.mode = "weighted_vote"
    predictor.active_axes = ["x", "y", "z"]
    predictor.device = torch.device("cpu")
    predictor.verbose = False
    predictor.axis_models = {axis: DummyAxisModel() for axis in predictor.active_axes}
    predictor.image_processor = type("ImageProcessorProxy", (), {})()
    predictor.image_processor.load_image = lambda image_path: cv2.imread(str(image_path), cv2.IMREAD_GRAYSCALE)
    predictor.image_processor.normalize_image = (
        lambda image: image.astype(np.float32) / 255.0
    )

    result = PatientPredictor.predict_patient(predictor, "P001", axis_data_paths=axis_paths)

    assert result["weighted_vote_prob"] < (2.0 / 3.0)
    assert result["weighted_vote_pred"] == 0
