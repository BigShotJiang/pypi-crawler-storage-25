from pathlib import Path

import cv2
import numpy as np

from src.data.axis_dataset import AxisImageDataset


def _make_png(path: Path) -> None:
    image = np.full((16, 368), 127, dtype=np.uint8)
    cv2.imwrite(str(path), image)


def test_axis_dataset_expands_patient_split_into_image_samples(tmp_path):
    axis_dir = tmp_path / "data-x"
    axis_dir.mkdir()
    label_path = tmp_path / "label.csv"
    label_path.write_text("patient_id,label\nP001,1\n", encoding="utf-8")

    for index in range(4):
        _make_png(axis_dir / f"P001_{index}_0_0.png")

    dataset = AxisImageDataset(
        axis="x",
        patient_ids=["P001"],
        axis_data_path=str(axis_dir),
        label_path=str(label_path),
    )

    assert len(dataset) == 4

    image, label, patient_id, image_path = dataset[0]

    assert image.shape == (1, 16, 368)
    assert label.item() == 1.0
    assert patient_id == "P001"
    assert image_path.endswith(".png")
