import argparse
import contextlib
import io
import tempfile
import types
import unittest
from unittest.mock import MagicMock, patch

import numpy as np

from src.cli.train_impl import (
    configure_stage_runtime,
    execute_train_args,
    print_training_config_snapshot,
    resolve_freeze_settings,
    resolve_runtime_output_settings,
)
from src.training.trainer import Trainer
from src.utils.config import load_config
from src.utils.monitor import TensorBoardLogger


def _make_config(*, monitoring_verbose=True, preload_verbose=True, pin_memory=True, device="cpu"):
    return types.SimpleNamespace(
        monitoring=types.SimpleNamespace(verbose=monitoring_verbose),
        data=types.SimpleNamespace(preload_verbose=preload_verbose, pin_memory=pin_memory),
        training=types.SimpleNamespace(common=types.SimpleNamespace(device=device)),
    )


class RuntimeOutputSettingsTests(unittest.TestCase):
    def test_non_verbose_cli_keeps_progress_and_disables_console_details(self):
        config = _make_config(monitoring_verbose=True, preload_verbose=True)
        args = argparse.Namespace(verbose=False)

        progress_enabled, console_verbose = resolve_runtime_output_settings(config, args)

        self.assertTrue(progress_enabled)
        self.assertFalse(console_verbose)
        self.assertFalse(config.monitoring.console_verbose)
        self.assertFalse(config.data.preload_verbose)

    def test_verbose_cli_enables_console_details_and_progress(self):
        config = _make_config(monitoring_verbose=False, preload_verbose=False)
        args = argparse.Namespace(verbose=True)

        progress_enabled, console_verbose = resolve_runtime_output_settings(config, args)

        self.assertTrue(progress_enabled)
        self.assertTrue(console_verbose)
        self.assertTrue(config.monitoring.verbose)
        self.assertTrue(config.monitoring.console_verbose)
        self.assertTrue(config.data.preload_verbose)

    def test_cpu_runtime_disables_pin_memory(self):
        config = _make_config(pin_memory=True, device="cpu")
        args = argparse.Namespace(verbose=False)

        resolve_runtime_output_settings(config, args)

        self.assertFalse(config.data.pin_memory)


class FreezeResolutionTests(unittest.TestCase):
    def test_none_freeze_method_does_not_forward_zero_ratio(self):
        config = types.SimpleNamespace(
            training=types.SimpleNamespace(
                freeze_method="none",
                freeze_layers="",
                freeze_ratio=0.0,
            )
        )
        args = argparse.Namespace(freeze_layers=None, freeze_ratio=None)

        freeze_layers, freeze_ratio = resolve_freeze_settings(config, args)

        self.assertIsNone(freeze_layers)
        self.assertIsNone(freeze_ratio)


class RuntimeStageConfigTests(unittest.TestCase):
    def test_monitoring_proxy_switches_to_fusion_stage(self):
        config = load_config("configs/test")

        configure_stage_runtime(config, argparse.Namespace(stage="fusion", axis=None))

        self.assertEqual(config.monitoring.early_stopping["metric"], "val_auc")
        self.assertEqual(config.monitoring.model_selection["metric"], "val_auc")

    def test_training_proxy_switches_to_fusion_stage(self):
        config = load_config("configs/test")

        configure_stage_runtime(config, argparse.Namespace(stage="fusion", axis=None))

        self.assertEqual(config.training.batch_size, config.training.fusion.batch_size)
        self.assertEqual(config.training.epochs, config.training.fusion.epochs)


class TrainerSummaryCompatibilityTests(unittest.TestCase):
    def test_patient_detail_line_accepts_mean_probability_schema(self):
        trainer = Trainer.__new__(Trainer)

        line = trainer._format_patient_detail_line(
            {
                "patient_id": "P001",
                "prediction": 1,
                "true_label": 0,
                "correct": False,
                "mean_probability": 0.7234,
                "total_samples": 4,
            }
        )

        self.assertIn("患者P001", line)
        self.assertIn("预测=1", line)
        self.assertIn("真实=0", line)
        self.assertIn("平均概率=0.7234", line)


class FinalSummaryOutputTests(unittest.TestCase):
    def test_execute_train_args_prints_compact_metric_summary(self):
        config = load_config("configs/test")
        fake_logger = MagicMock()
        results = {
            "type": "axis_split",
            "axis": "x",
            "train_history": [{"loss": 0.8}, {"loss": 0.6}],
            "val_history": [
                {"loss": 0.55, "predict_accuracy": 0.50, "accuracy": 0.61},
                {"loss": 0.41, "predict_accuracy": 0.75, "accuracy": 0.82},
            ],
            "test_metrics": {
                "loss": 0.38,
                "accuracy": 0.81,
                "f1": 0.74,
                "auc": 0.92,
                "predict_accuracy": 0.75,
            },
        }

        with tempfile.TemporaryDirectory() as tmpdir:
            config.experiment.save_dir = tmpdir

            with (
                patch("src.cli.train_impl.load_config", return_value=config),
                patch("src.cli.train_impl.dispatch_training", return_value=results),
                patch("src.cli.train_impl.get_logger", return_value=fake_logger),
            ):
                stdout = io.StringIO()
                with contextlib.redirect_stdout(stdout):
                    exit_code = execute_train_args(
                        {
                            "config_path": "configs/test",
                            "stage": "axis",
                            "axis": "x",
                            "verbose": False,
                        }
                    )

        output = stdout.getvalue()
        self.assertEqual(exit_code, 0)
        # Rich panel output contains these metrics
        self.assertIn("predict_accuracy", output)
        self.assertIn("accuracy", output)
        self.assertIn("auc", output)


class ConfigSnapshotOutputTests(unittest.TestCase):
    def test_print_training_config_snapshot_shows_effective_stage_monitoring(self):
        config = load_config("configs/test")
        configure_stage_runtime(config, argparse.Namespace(stage="axis", axis="x"))

        stdout = io.StringIO()
        with contextlib.redirect_stdout(stdout):
            print_training_config_snapshot(config)

        output = stdout.getvalue()
        self.assertIn("epochs:", output)
        self.assertIn("batch_size:", output)
        self.assertIn("early_stopping:", output)
        self.assertIn("model_selection:", output)


class TensorBoardLoggerTests(unittest.TestCase):
    def test_log_scalars_filters_non_scalar_values(self):
        writer = MagicMock()
        logger = TensorBoardLogger.__new__(TensorBoardLogger)
        logger.enabled = True
        logger.writer = writer

        logger.log_scalars(
            "Validation/Epoch",
            {
                "loss": 0.72,
                "patient_total": 32,
                "predict_accuracy": np.float64(0.4375),
                "patient_details": [{"patient_id": "p1"}],
            },
            1,
        )

        writer.add_scalars.assert_called_once()
        main_tag, scalar_dict, step = writer.add_scalars.call_args.args
        self.assertEqual(main_tag, "Validation/Epoch")
        self.assertEqual(step, 1)
        self.assertEqual(
            scalar_dict,
            {
                "loss": 0.72,
                "patient_total": 32.0,
                "predict_accuracy": 0.4375,
            },
        )


if __name__ == "__main__":
    unittest.main()
