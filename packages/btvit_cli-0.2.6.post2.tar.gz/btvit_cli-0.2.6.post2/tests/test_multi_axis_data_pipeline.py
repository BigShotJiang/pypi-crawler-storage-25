import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import cv2
import numpy as np
import torch

from src.data.enhanced_splitting import EnhancedDataSplitter
from src.data.preprocessing import LabelProcessor, MultiAxisDatasetOrganizer
from src.data.dataset import MultiAxisCombinationDataset, MultiAxisCollator
from src.data.memory_preloader import MemoryPreloader


class MultiAxisOrganizerTest(unittest.TestCase):
    def make_png(self, path: Path) -> None:
        image = np.full((16, 368), 127, dtype=np.uint8)
        cv2.imwrite(str(path), image)

    def test_organizer_filters_incomplete_patients_and_builds_64_combinations(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            label_path = root / "label.csv"
            label_path.write_text("patient_id,label\nP001,1\nP002,0\n", encoding="utf-8")

            axis_paths = {}
            for axis in ("x", "y", "z"):
                axis_dir = root / f"data-{axis}"
                axis_dir.mkdir()
                axis_paths[axis] = str(axis_dir)

            for index in range(4):
                self.make_png(root / "data-x" / f"P001_{index}_0_0.png")
                self.make_png(root / "data-y" / f"P001_0_{index}_0.png")
                self.make_png(root / "data-z" / f"P001_0_0_{index}.png")

            for index in range(4):
                self.make_png(root / "data-x" / f"P002_{index}_0_0.png")
                self.make_png(root / "data-y" / f"P002_0_{index}_0.png")

            label_processor = LabelProcessor(str(label_path))
            organizer = MultiAxisDatasetOrganizer(
                axis_paths,
                label_processor,
                active_axes=["x", "y", "z"],
                images_per_axis=4,
            )
            dataset = MultiAxisCombinationDataset(
                patient_ids=organizer.get_all_patients(),
                organizer=organizer,
                label_processor=label_processor,
                active_axes=["x", "y", "z"],
            )

        self.assertEqual(organizer.get_all_patients(), ["P001"])
        self.assertEqual(len(dataset), 64)

    def test_organizer_keeps_patient_when_one_axis_has_fewer_images_than_cap(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            label_path = root / "label.csv"
            label_path.write_text("patient_id,label\nP001,1\n", encoding="utf-8")

            axis_paths = {}
            for axis in ("x", "y", "z"):
                axis_dir = root / f"data-{axis}"
                axis_dir.mkdir()
                axis_paths[axis] = str(axis_dir)

            for index in range(4):
                self.make_png(root / "data-x" / f"P001_{index}_0_0.png")
                self.make_png(root / "data-y" / f"P001_0_{index}_0.png")
            for index in range(3):
                self.make_png(root / "data-z" / f"P001_0_0_{index}.png")

            label_processor = LabelProcessor(str(label_path))
            organizer = MultiAxisDatasetOrganizer(
                axis_paths,
                label_processor,
                active_axes=["x", "y", "z"],
                images_per_axis=4,
            )
            dataset = MultiAxisCombinationDataset(
                patient_ids=organizer.get_all_patients(),
                organizer=organizer,
                label_processor=label_processor,
                active_axes=["x", "y", "z"],
            )

        self.assertEqual(organizer.get_all_patients(), ["P001"])
        self.assertEqual(len(dataset), 48)


class MultiAxisSplitterTest(unittest.TestCase):
    def make_png(self, path: Path) -> None:
        image = np.full((16, 368), 127, dtype=np.uint8)
        cv2.imwrite(str(path), image)

    def test_enhanced_splitter_uses_multi_axis_directories_under_data_root(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            data_root = root / "data"
            data_root.mkdir()
            label_path = root / "label.csv"
            label_path.write_text(
                "patient_id,label\nP001,1\nP002,0\nP003,1\nP004,0\n",
                encoding="utf-8",
            )

            for axis in ("x", "y", "z"):
                axis_dir = data_root / f"data-{axis}"
                axis_dir.mkdir()
                for patient_id in ("P001", "P002", "P003", "P004"):
                    for index in range(4):
                        self.make_png(axis_dir / f"{patient_id}_{index}_0_0.png")

            config = SimpleNamespace(
                multi_axis=SimpleNamespace(
                    enabled=True,
                    axis_data_paths={
                        "x": str(root / "data-x"),
                        "y": str(root / "data-y"),
                        "z": str(root / "data-z"),
                    },
                    active_axes=["x", "y", "z"],
                    images_per_axis=4,
                )
            )

            splitter = EnhancedDataSplitter(str(data_root), str(label_path), config)

        self.assertEqual(splitter.all_patients, ["P001", "P002", "P003", "P004"])
        self.assertEqual(config.multi_axis.axis_data_paths["x"], str(data_root / "data-x"))


class MultiAxisLoaderTest(unittest.TestCase):
    def test_collator_stacks_axis_batches_and_preserves_patient_ids(self):
        sample = (
            {
                "x": torch.zeros(1, 16, 368),
                "y": torch.ones(1, 16, 368),
                "z": torch.full((1, 16, 368), 2.0),
            },
            torch.tensor(1.0),
            "P001",
            (0, 0, 0),
            {"x": "x0", "y": "y0", "z": "z0"},
        )
        batch = [sample, sample]

        axis_batches, labels, patient_ids, combo_indices, image_paths = MultiAxisCollator()(batch)

        self.assertEqual(axis_batches["x"].shape, (2, 1, 16, 368))
        self.assertEqual(labels.shape[0], 2)
        self.assertEqual(patient_ids, ["P001", "P001"])
        self.assertEqual(combo_indices[0], (0, 0, 0))

    def test_memory_preloader_returns_cached_processed_images_for_reused_paths(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            image_path = root / "P001_0_0_0.png"
            label_path = root / "label.csv"
            cv2.imwrite(str(image_path), np.full((16, 368), 127, dtype=np.uint8))
            label_path.write_text("patient_id,label\nP001,1\n", encoding="utf-8")

            preloader = MemoryPreloader(
                data_path=str(root),
                label_path=str(label_path),
                patch_size=(16, 16),
                enable_preload=True,
                verbose=False,
            )
            preloader.preload_images(["P001"])

            image_a = preloader.get_preloaded_image(str(image_path))
            image_b = preloader.get_preloaded_image(str(image_path))

        self.assertIsNotNone(image_a)
        self.assertEqual(image_a.shape, (1, 16, 368))
        self.assertIs(image_a, image_b)


if __name__ == "__main__":
    unittest.main()
