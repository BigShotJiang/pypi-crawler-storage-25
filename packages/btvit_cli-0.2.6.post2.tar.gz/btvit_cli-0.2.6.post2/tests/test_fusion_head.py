import torch

from src.model.fusion_head import (
    PatientFusionHead,
    merge_patient_features,
    resolve_fusion_input_dim,
)


def test_patient_fusion_head_supports_linear_and_mlp():
    linear = PatientFusionHead(input_dim=96, head_type="linear")
    mlp = PatientFusionHead(input_dim=96, head_type="mlp", hidden_dim=32, dropout=0.1)
    x = torch.randn(4, 96)

    assert linear(x).shape == (4, 1)
    assert mlp(x).shape == (4, 1)


def test_fusion_helpers_support_concat_and_sum():
    x = torch.tensor([1.0, 2.0])
    y = torch.tensor([3.0, 4.0])
    z = torch.tensor([5.0, 6.0])

    assert resolve_fusion_input_dim(feature_dim=2, axis_count=3, fusion_mode="concat") == 6
    assert resolve_fusion_input_dim(feature_dim=2, axis_count=3, fusion_mode="sum") == 2
    torch.testing.assert_close(
        merge_patient_features([x, y, z], fusion_mode="concat"),
        torch.tensor([1.0, 2.0, 3.0, 4.0, 5.0, 6.0]),
    )
    torch.testing.assert_close(
        merge_patient_features([x, y, z], fusion_mode="sum"),
        torch.tensor([9.0, 12.0]),
    )
