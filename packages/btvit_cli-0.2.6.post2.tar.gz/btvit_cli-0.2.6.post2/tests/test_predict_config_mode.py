import os
import tempfile
import unittest
from pathlib import Path

from src.cli.predict_impl import resolve_paths_from_config


class ResolvePathsFromConfigTest(unittest.TestCase):
    def test_derives_axis_and_fusion_checkpoints_from_experiment_config(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir) / "configs" / "my_exp"
            config_dir.mkdir(parents=True)
            (config_dir / "experiment_config.yaml").write_text(
                "name: my_exp\nsave_dir: experiments\n",
                encoding="utf-8",
            )
            (config_dir / "model_config.yaml").write_text("dim: 512\n", encoding="utf-8")
            (config_dir / "training_config.yaml").write_text("training:\n  common:\n    device: cpu\n", encoding="utf-8")

            experiment_dir = Path(tmpdir) / "experiments" / "my_exp"
            for stage in ("axis-x", "axis-y", "axis-z", "fusion"):
                (experiment_dir / stage / "checkpoints").mkdir(parents=True)
                (experiment_dir / stage / "checkpoints" / "best_model.pth").write_text("fake", encoding="utf-8")
            (experiment_dir / "testset").mkdir(parents=True)
            (experiment_dir / "testset" / "data-x").mkdir()
            (experiment_dir / "testset" / "data-y").mkdir()
            (experiment_dir / "testset" / "data-z").mkdir()
            (experiment_dir / "testset" / "label.csv").write_text("patient_id,label\n", encoding="utf-8")

            original_cwd = os.getcwd()
            try:
                os.chdir(tmpdir)
                result = resolve_paths_from_config(str(config_dir))
            finally:
                os.chdir(original_cwd)

            self.assertTrue(result["axis_checkpoint_paths"]["x"].endswith("axis-x/checkpoints/best_model.pth"))
            self.assertTrue(result["axis_checkpoint_paths"]["y"].endswith("axis-y/checkpoints/best_model.pth"))
            self.assertTrue(result["axis_checkpoint_paths"]["z"].endswith("axis-z/checkpoints/best_model.pth"))
            self.assertTrue(result["fusion_checkpoint_path"].endswith("fusion/checkpoints/best_model.pth"))
            self.assertIn("testset", result["data_path"])
            self.assertTrue(result["label_path"].endswith("testset/label.csv"))

    def test_raises_when_axis_checkpoint_not_found(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir) / "configs"
            config_dir.mkdir()
            (config_dir / "experiment_config.yaml").write_text(
                "name: missing_exp\nsave_dir: experiments\n",
                encoding="utf-8",
            )

            original_cwd = os.getcwd()
            try:
                os.chdir(tmpdir)
                with self.assertRaises(FileNotFoundError) as ctx:
                    resolve_paths_from_config(str(config_dir))
            finally:
                os.chdir(original_cwd)

            self.assertIn("axis-x", str(ctx.exception))

    def test_data_path_none_when_testset_missing(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir) / "configs"
            config_dir.mkdir()
            (config_dir / "experiment_config.yaml").write_text(
                "name: no_testset\nsave_dir: experiments\n",
                encoding="utf-8",
            )

            experiment_dir = Path(tmpdir) / "experiments" / "no_testset"
            for stage in ("axis-x", "axis-y", "axis-z", "fusion"):
                (experiment_dir / stage / "checkpoints").mkdir(parents=True)
                (experiment_dir / stage / "checkpoints" / "best_model.pth").write_text("fake", encoding="utf-8")

            original_cwd = os.getcwd()
            try:
                os.chdir(tmpdir)
                result = resolve_paths_from_config(str(config_dir))
            finally:
                os.chdir(original_cwd)

            self.assertIsNone(result["data_path"])
            self.assertIsNone(result["label_path"])


if __name__ == "__main__":
    unittest.main()
