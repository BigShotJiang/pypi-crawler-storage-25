import tempfile
import unittest
from pathlib import Path


class PredictDataLayoutTest(unittest.TestCase):
    def test_fixed_axis_directories_are_used_directly(self):
        from src.cli.utils import normalize_prediction_data_layout

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            for axis in ("x", "y", "z"):
                axis_dir = root / f"data-{axis}"
                axis_dir.mkdir()
                (axis_dir / f"PAT001_0_0_001.png").write_bytes(b"")

            normalized = normalize_prediction_data_layout(str(root), root / "normalized")

            self.assertEqual(Path(normalized["x"]), root / "data-x")
            self.assertEqual(Path(normalized["y"]), root / "data-y")
            self.assertEqual(Path(normalized["z"]), root / "data-z")

    def test_flat_directory_is_normalized_by_axis_from_filename_indices(self):
        from src.cli.utils import normalize_prediction_data_layout

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir) / "flat"
            workspace = Path(tmpdir) / "normalized"
            root.mkdir()
            (root / "MR201201030297_0_0_251.png").write_bytes(b"")
            (root / "MR201201030297_0_261_0.png").write_bytes(b"")
            (root / "MR201201030297_015_0_0.png").write_bytes(b"")

            normalized = normalize_prediction_data_layout(str(root), workspace)

            self.assertTrue((Path(normalized["x"]) / "MR201201030297_0_0_251.png").exists())
            self.assertTrue((Path(normalized["y"]) / "MR201201030297_0_261_0.png").exists())
            self.assertTrue((Path(normalized["z"]) / "MR201201030297_015_0_0.png").exists())

    def test_flat_directory_rejects_ambiguous_axis_filename(self):
        from src.cli.utils import normalize_prediction_data_layout

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir) / "flat"
            workspace = Path(tmpdir) / "normalized"
            root.mkdir()
            (root / "MR201201030297_1_2_0.png").write_bytes(b"")

            with self.assertRaises(ValueError):
                normalize_prediction_data_layout(str(root), workspace)


if __name__ == "__main__":
    unittest.main()
