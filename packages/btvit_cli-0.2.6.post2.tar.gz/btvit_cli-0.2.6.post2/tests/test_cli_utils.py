import tempfile
import unittest
from pathlib import Path

from src.cli.utils import export_cli_templates


class ExportCliTemplatesTests(unittest.TestCase):
    def test_training_config_fields_have_explanatory_comments(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            export_cli_templates(tmp_dir)
            content = (Path(tmp_dir) / "training_config.yaml").read_text(encoding="utf-8")

        lines = content.splitlines()
        fields = [
            "device",
            "num_workers",
            "mixed_precision",
            "gradient_clip_val",
            "accumulate_grad_batches",
            "debug_logging",
            "epochs",
            "batch_size",
            "learning_rate",
            "weight_decay",
            "optimizer",
            "scheduler",
            "scheduler_params",
            "pretrained_model_path",
            "load_weights_only",
            "strict_load",
            "freeze_method",
            "freeze_layers",
            "freeze_ratio",
            "finetune_lr_scale",
            "use_differential_lr",
            "freeze_encoders",
            "train_split_csv_path",
        ]

        for field in fields:
            field_index = next(
                index for index, line in enumerate(lines) if line.lstrip().startswith(f"{field}:")
            )
            previous_non_empty = next(
                line.strip() for line in reversed(lines[:field_index]) if line.strip()
            )
            self.assertTrue(
                previous_non_empty.startswith("#"),
                msg=f"{field} should be documented by a preceding comment",
            )

    def test_training_config_includes_complete_examples(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            export_cli_templates(tmp_dir)
            content = (Path(tmp_dir) / "training_config.yaml").read_text(encoding="utf-8")

        self.assertIn("training:\n  common:", content)
        self.assertIn("\n  axis:\n", content)
        self.assertIn("\n  fusion:\n", content)
        self.assertIn("scheduler_params: {T_max: 100, eta_min: 1.0e-6}", content)
        self.assertIn("Example: checkpoints/best_model.pth", content)
        self.assertIn("Example: patch_embedding,transformer:0-2", content)
        self.assertIn("Example: exports/train_split.csv", content)

    def test_training_templates_document_init_mode_and_usage(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            export_cli_templates(tmp_dir)
            training_content = (Path(tmp_dir) / "training_config.yaml").read_text(encoding="utf-8")
            multi_axis_content = (Path(tmp_dir) / "multi_axis_config.yaml").read_text(encoding="utf-8")
            usage_content = (Path(tmp_dir) / "USAGE.md").read_text(encoding="utf-8")

        self.assertIn("init_mode: same", training_content)
        self.assertIn("init_seed: null", training_content)
        self.assertIn("train_split_random_seed: 42", training_content)
        self.assertIn("origin_axis_data_paths", multi_axis_content)
        self.assertIn("--init same|random", usage_content)
        self.assertIn("--train-split-seed <int>", usage_content)
        self.assertIn("--dataset processed|origin", usage_content)


if __name__ == "__main__":
    unittest.main()
