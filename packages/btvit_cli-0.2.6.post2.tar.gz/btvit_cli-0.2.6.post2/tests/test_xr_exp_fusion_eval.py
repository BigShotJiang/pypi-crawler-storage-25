from pathlib import Path

import cv2
import numpy as np

from src.data.preprocessing import ImageProcessor
from xr_exp.scripts import fusion_eval


def test_load_normalized_image_matches_training_pipeline_for_16bit_png(tmp_path: Path):
    image = np.linspace(0, 970, num=16 * 368, dtype=np.uint16).reshape(16, 368)
    image_path = tmp_path / "sample16.png"
    cv2.imwrite(str(image_path), image)

    image_processor = ImageProcessor(patch_size=(16, 16))
    expected = image_processor.normalize_image(image_processor.load_image(str(image_path)))
    actual = fusion_eval.load_normalized_image(str(image_path))

    assert actual.shape == (16, 368)
    assert np.allclose(actual, expected, atol=1e-6)
