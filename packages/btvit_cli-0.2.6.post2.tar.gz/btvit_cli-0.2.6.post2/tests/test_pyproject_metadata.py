import tomllib
import unittest
from pathlib import Path

from src import __version__


class PyprojectMetadataTest(unittest.TestCase):
    def test_pyproject_declares_expected_cli_metadata(self):
        pyproject_path = Path("pyproject.toml")
        self.assertTrue(pyproject_path.exists())

        data = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
        project = data["project"]

        self.assertEqual(project["name"], "btvit-cli")
        self.assertEqual(project["dynamic"], ["version"])
        self.assertEqual(project["license"]["text"], "Apache-2.0")
        self.assertEqual(project["authors"][0]["name"], "SuShuHeng")
        self.assertEqual(project["urls"]["Repository"], "https://github.com/SuShuHeng/Vit-cli")
        self.assertEqual(project["scripts"]["vit"], "src.cli.main:run")
        self.assertEqual(data["tool"]["setuptools"]["dynamic"]["version"]["attr"], "src.__version__")
        self.assertRegex(__version__, r"^\d+\.\d+\.\d+")


if __name__ == "__main__":
    unittest.main()
