import unittest

from typer.testing import CliRunner


class CliSmokeTest(unittest.TestCase):
    def test_top_level_help_commands_work(self):
        from src.cli.main import app

        runner = CliRunner()

        for args in (["--help"], ["train", "--help"], ["pred", "--help"], ["get", "--help"]):
            with self.subTest(args=args):
                result = runner.invoke(app, args)
                self.assertEqual(result.exit_code, 0, result.stdout)

    def test_top_level_version_option_and_command_work(self):
        from src import __version__
        from src.cli.main import app

        runner = CliRunner()

        version_option = runner.invoke(app, ["--version"])
        version_command = runner.invoke(app, ["version"])

        self.assertEqual(version_option.exit_code, 0, version_option.stdout)
        self.assertEqual(version_command.exit_code, 0, version_command.stdout)
        self.assertIn(__version__, version_option.stdout)
        self.assertIn(__version__, version_command.stdout)

    def test_train_help_describes_axis_and_fusion_stages(self):
        from src.cli.main import app

        runner = CliRunner()
        result = runner.invoke(app, ["train", "--help"])

        self.assertEqual(result.exit_code, 0, result.stdout)
        self.assertIn("axis", result.stdout)
        self.assertIn("fusion", result.stdout)


if __name__ == "__main__":
    unittest.main()
