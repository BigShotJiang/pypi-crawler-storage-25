import torch

from src.model.axis_model import AxisViTModel


def test_axis_vit_model_returns_logits_and_features():
    model = AxisViTModel(
        input_shape=(16, 368),
        patch_size=(16, 16),
        dim=32,
        depth=1,
        heads=1,
        mlp_dim=64,
        dim_head=32,
    )
    x = torch.randn(2, 1, 16, 368)

    logits = model(x)
    features = model.extract_features(x)

    assert logits.shape == (2, 1)
    assert features.shape == (2, 32)
