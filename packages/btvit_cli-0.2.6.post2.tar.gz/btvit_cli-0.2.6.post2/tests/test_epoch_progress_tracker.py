import unittest

from src.training.epoch_progress_tracker import EpochProgressTracker


class EpochProgressTrackerInitTest(unittest.TestCase):
    def test_bar_disabled_when_not_verbose(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        self.assertTrue(tracker.bar.disable)
        tracker.close()

    def test_bar_enabled_when_verbose(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=True)
        self.assertFalse(tracker.bar.disable)
        tracker.close()

    def test_initial_state_is_idle(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        self.assertEqual(tracker._state, "idle")
        tracker.close()

    def test_initial_param_sets_bar_position(self):
        tracker = EpochProgressTracker(total_epochs=100, initial=50, verbose=False)
        self.assertEqual(tracker.bar.n, 50)
        tracker.close()


class EarlyStoppingFieldTest(unittest.TestCase):
    def test_esp_fields_present_when_enabled(self):
        es_config = {"enabled": True, "metric": "val_auc", "mode": "max", "patience": 20, "min_delta": 0.001}
        tracker = EpochProgressTracker(
            total_epochs=10, verbose=False,
            early_stopping_config=es_config,
            model_selection_config={"metric": "val_loss", "mode": "min"},
        )
        self.assertTrue(tracker._early_stopping_enabled)
        self.assertEqual(tracker._esp_patience, 20)
        self.assertEqual(tracker._esp_metric_name, "val_auc")
        self.assertEqual(tracker._esp_direction, "\u2191")  # up arrow
        tracker.close()

    def test_esp_fields_absent_when_disabled(self):
        es_config = {"enabled": False, "metric": "val_loss", "mode": "min", "patience": 10, "min_delta": 0.001}
        tracker = EpochProgressTracker(
            total_epochs=10, verbose=False,
            early_stopping_config=es_config,
        )
        self.assertFalse(tracker._early_stopping_enabled)
        tracker.close()

    def test_esp_fields_absent_when_config_none(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        self.assertFalse(tracker._early_stopping_enabled)
        tracker.close()

    def test_direction_arrow_min(self):
        es_config = {"enabled": True, "metric": "val_loss", "mode": "min", "patience": 10, "min_delta": 0.001}
        tracker = EpochProgressTracker(total_epochs=10, verbose=False, early_stopping_config=es_config)
        self.assertEqual(tracker._esp_direction, "\u2193")  # down arrow
        tracker.close()


class DecimalPlacesTest(unittest.TestCase):
    def test_min_delta_001_gives_3_places(self):
        self.assertEqual(EpochProgressTracker._compute_decimal_places(0.001), 3)

    def test_min_delta_0001_gives_4_places(self):
        self.assertEqual(EpochProgressTracker._compute_decimal_places(0.0001), 4)

    def test_min_delta_01_gives_2_places(self):
        self.assertEqual(EpochProgressTracker._compute_decimal_places(0.01), 2)

    def test_min_delta_zero_fallback(self):
        self.assertEqual(EpochProgressTracker._compute_decimal_places(0), 4)


class UpdateProgressTest(unittest.TestCase):
    def test_update_train_progress_sets_state(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        tracker.update_train_progress(5, 10, 0.5)
        self.assertEqual(tracker._state, "train")
        self.assertAlmostEqual(tracker._train_progress, 60.0)
        self.assertEqual(tracker._current_loss, 0.5)
        tracker.close()

    def test_update_val_progress_sets_state(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        tracker.update_val_progress(2, 5, 0.3)
        self.assertEqual(tracker._state, "val")
        self.assertAlmostEqual(tracker._val_progress, 60.0)
        self.assertEqual(tracker._val_loss, 0.3)
        tracker.close()


class FinishEpochTest(unittest.TestCase):
    def test_finish_epoch_advances_bar(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        tracker.finish_epoch(1, lr=0.001, best_epoch=1, best_metric=0.8)
        self.assertEqual(tracker._epochs_completed, 1)
        self.assertEqual(tracker._best_epoch, 1)
        self.assertEqual(tracker._best_metric, 0.8)
        self.assertEqual(tracker._state, "idle")
        tracker.close()

    def test_finish_epoch_without_validation_skips_best_update(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        tracker._best_epoch = 5
        tracker._best_metric = 0.9
        tracker.finish_epoch(3, lr=0.001, validated=False)
        self.assertEqual(tracker._best_epoch, 5)  # unchanged
        self.assertEqual(tracker._best_metric, 0.9)  # unchanged
        tracker.close()


class PostfixFormatTest(unittest.TestCase):
    def test_postfix_contains_esp_when_enabled(self):
        es_config = {"enabled": True, "metric": "val_auc", "mode": "max", "patience": 20, "min_delta": 0.001}
        ms_config = {"metric": "predict_accuracy", "mode": "max"}
        tracker = EpochProgressTracker(
            total_epochs=10, verbose=False,
            early_stopping_config=es_config,
            model_selection_config=ms_config,
        )
        tracker.update_train_progress(0, 10, 0.5)
        postfix = tracker.bar.postfix
        self.assertIn("esp", postfix)
        self.assertIn("val_auc", postfix)
        tracker.close()

    def test_postfix_omits_esp_when_disabled(self):
        ms_config = {"metric": "predict_accuracy", "mode": "max"}
        tracker = EpochProgressTracker(
            total_epochs=10, verbose=False,
            model_selection_config=ms_config,
        )
        tracker.update_train_progress(0, 10, 0.5)
        postfix = tracker.bar.postfix
        self.assertNotIn("esp", postfix)
        tracker.close()

    def test_postfix_shows_MS_field(self):
        ms_config = {"metric": "predict_accuracy", "mode": "max"}
        tracker = EpochProgressTracker(
            total_epochs=10, verbose=False,
            model_selection_config=ms_config,
        )
        tracker.finish_epoch(1, lr=0.001, best_epoch=1, best_metric=0.85)
        postfix = tracker.bar.postfix
        self.assertIn("predict_accuracy", postfix)
        tracker.close()

    def test_lr_scientific_notation_for_small_values(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        tracker.finish_epoch(1, lr=0.0001)
        postfix = tracker.bar.postfix
        self.assertIn("1.0e-04", postfix)
        tracker.close()

    def test_lr_decimal_for_larger_values(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        tracker.finish_epoch(1, lr=0.01)
        postfix = tracker.bar.postfix
        self.assertIn("0.0100", postfix)
        tracker.close()

    def test_state_shows_train_with_progress(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        tracker.update_train_progress(4, 10, 0.5)
        postfix = tracker.bar.postfix
        self.assertIn("state:train", postfix)
        self.assertIn("train:50%", postfix)
        tracker.close()

    def test_state_shows_val_with_progress(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        tracker.update_val_progress(1, 4, 0.3)
        postfix = tracker.bar.postfix
        self.assertIn("state:val", postfix)
        self.assertIn("val:50%", postfix)
        tracker.close()

    def test_state_shows_idle(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        tracker._refresh_postfix()
        postfix = tracker.bar.postfix
        self.assertIn("state:idle", postfix)
        tracker.close()


class EarlyStoppedTest(unittest.TestCase):
    def test_mark_early_stopped_appends_STOPPED(self):
        tracker = EpochProgressTracker(total_epochs=10, verbose=False)
        tracker.update_train_progress(0, 10, 0.5)
        tracker.mark_early_stopped(5, "patience exhausted")
        postfix = tracker.bar.postfix
        self.assertIn("STOPPED", postfix)
        tracker.close()


if __name__ == "__main__":
    unittest.main()
