from __future__ import annotations

from pathlib import Path

import numpy as np
import torch

from src.data.dataset import ViTCollator
from src.data.preprocessing import ImageProcessor
from src.model.vit_model import MedicalViT


def test_image_processor_pads_to_patch_multiple_before_cropping():
    processor = ImageProcessor(patch_size=(16, 32))
    image = np.ones((16, 368), dtype=np.float32)

    padded = processor.pad_to_patch_multiple(image)
    patches = processor.crop_to_patches(padded)

    assert padded.shape == (16, 384)
    assert len(patches) == 12
    assert patches[0].shape == (16, 32)


def test_medical_vit_default_patch_size_keeps_23_patches():
    model = MedicalViT(
        input_shape=(16, 368),
        patch_size=(16, 16),
        num_classes=1,
        dim=32,
        depth=1,
        heads=1,
        mlp_dim=64,
        dim_head=32,
    )

    assert model.num_patches == 23
    assert tuple(model.pos_embedding.shape) == (1, 23, 32)


def test_medical_vit_non_divisible_patch_size_uses_padding():
    model = MedicalViT(
        input_shape=(16, 368),
        patch_size=(16, 32),
        num_classes=1,
        dim=32,
        depth=1,
        heads=1,
        mlp_dim=64,
        dim_head=32,
    )
    inputs = torch.randn(2, 1, 16, 368)

    outputs = model(inputs)
    embedding = model.get_embedding(inputs)

    assert model.needs_padding is True
    assert model.padded_input_shape == (16, 384)
    assert model.num_patches == 12
    assert tuple(model.pos_embedding.shape) == (1, 12, 32)
    assert tuple(outputs.shape) == (2, 1)
    assert tuple(embedding.shape) == (2, 12, 32)


def test_save_initialization_uses_dynamic_model_config(tmp_path: Path):
    model = MedicalViT(
        input_shape=(16, 368),
        patch_size=(16, 32),
        num_classes=1,
        dim=32,
        depth=2,
        heads=2,
        mlp_dim=96,
        dim_head=16,
        dropout=0.2,
        emb_dropout=0.3,
    )
    save_path = tmp_path / "init.pth"

    model.save_initialization(str(save_path))
    init_state = torch.load(save_path, map_location="cpu")

    assert init_state["model_config"]["input_shape"] == (16, 368)
    assert init_state["model_config"]["patch_size"] == (16, 32)
    assert init_state["model_config"]["dim"] == 32
    assert init_state["model_config"]["depth"] == 2
    assert init_state["model_config"]["heads"] == 2
    assert init_state["model_config"]["mlp_dim"] == 96
    assert init_state["model_config"]["dim_head"] == 16
    assert init_state["model_config"]["dropout"] == 0.2
    assert init_state["model_config"]["emb_dropout"] == 0.3


def test_vit_collator_supports_dynamic_grid_shape():
    collator = ViTCollator(max_patches=12, grid_shape=(1, 12), patch_size=(16, 32))
    patches = torch.arange(11 * 16 * 32, dtype=torch.float32).reshape(11, 16, 32)
    labels = torch.tensor(1.0, dtype=torch.float32)

    images, labels_batch = collator([(patches, labels)])

    assert tuple(images.shape) == (1, 1, 16, 384)
    assert tuple(labels_batch.shape) == (1,)


def test_vit_collator_keeps_backward_compatible_max_patches_mode():
    collator = ViTCollator(max_patches=23)
    patches = torch.arange(23 * 16 * 16, dtype=torch.float32).reshape(23, 16, 16)
    labels = torch.tensor(0.0, dtype=torch.float32)

    images, labels_batch = collator([(patches, labels)])

    assert tuple(images.shape) == (1, 1, 16, 368)
    assert tuple(labels_batch.shape) == (1,)
