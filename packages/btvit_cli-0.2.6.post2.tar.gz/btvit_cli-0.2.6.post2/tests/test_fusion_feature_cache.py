from pathlib import Path

import cv2
import numpy as np
import torch

from src.data.fusion_dataset import FusionPatientDataset
from src.training.fusion_feature_cache import build_patient_feature_cache


def _make_png(path: Path, value: int) -> None:
    image = np.full((16, 368), value, dtype=np.uint8)
    cv2.imwrite(str(path), image)


class DummyEncoder(torch.nn.Module):
    def __init__(self, feature_dim: int = 32):
        super().__init__()
        self.feature_dim = feature_dim

    def extract_features(self, images):
        base = images.reshape(images.shape[0], -1).mean(dim=1, keepdim=True)
        return base.repeat(1, self.feature_dim)


def test_build_patient_feature_cache_means_features_within_axis(tmp_path):
    label_path = tmp_path / "label.csv"
    label_path.write_text("patient_id,label\nP001,1\n", encoding="utf-8")

    axis_paths = {}
    for axis, value in (("x", 32), ("y", 96), ("z", 160)):
        axis_dir = tmp_path / f"data-{axis}"
        axis_dir.mkdir()
        axis_paths[axis] = str(axis_dir)

        for index in range(4):
            if axis == "x":
                filename = f"P001_{index}_0_0.png"
            elif axis == "y":
                filename = f"P001_0_{index}_0.png"
            else:
                filename = f"P001_0_0_{index}.png"
            _make_png(axis_dir / filename, value)

    dataset = FusionPatientDataset(
        patient_ids=["P001"],
        axis_data_paths=axis_paths,
        label_path=str(label_path),
        active_axes=["x", "y", "z"],
    )
    encoders = {axis: DummyEncoder(feature_dim=32) for axis in ("x", "y", "z")}

    rows = build_patient_feature_cache(dataset, encoders, device="cpu")

    assert rows["P001"]["x"].shape == (32,)
    assert rows["P001"]["y"].shape == (32,)
    assert rows["P001"]["z"].shape == (32,)
    assert rows["P001"]["label"] == 1
    assert rows["P001"]["x"].mean() < rows["P001"]["y"].mean() < rows["P001"]["z"].mean()
