import json
import tempfile
import unittest
from pathlib import Path

from src.data.preprocessing import LabelProcessor, MultiAxisDatasetOrganizer


class TestsetExportTest(unittest.TestCase):
    def _write_label_csv(self, path: Path) -> None:
        path.write_text(
            "patient_id,label\n"
            "PAT001,1\n"
            "PAT002,0\n",
            encoding="utf-8",
        )

    def _write_multi_axis_pngs(self, root: Path, patient_id: str, axes: tuple[str, ...]) -> None:
        names = {
            "x": f"{patient_id}_0_0_101.png",
            "y": f"{patient_id}_0_101_0.png",
            "z": f"{patient_id}_101_0_0.png",
        }
        for axis in axes:
            axis_dir = root / f"data-{axis}"
            axis_dir.mkdir(parents=True, exist_ok=True)
            (axis_dir / names[axis]).write_bytes(b"png")

    def test_export_multi_axis_testset_creates_prediction_layout(self):
        from src.data.testset_export import export_prediction_ready_testset

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            label_path = root / "label.csv"
            experiment_dir = root / "experiments" / "exp1"
            axis_paths = {axis: str(root / f"data-{axis}") for axis in ("x", "y", "z")}

            self._write_label_csv(label_path)
            self._write_multi_axis_pngs(root, "PAT001", ("x", "y", "z"))
            self._write_multi_axis_pngs(root, "PAT002", ("x", "y", "z"))

            organizer = MultiAxisDatasetOrganizer(axis_paths, LabelProcessor(str(label_path)))

            export_dir = export_prediction_ready_testset(
                experiment_dir=str(experiment_dir),
                experiment_name="exp1",
                test_patients=["PAT001"],
                labels={"PAT001": 1, "PAT002": 0},
                organizer=organizer,
                source_data_path=str(root),
                active_axes=["x", "y", "z"],
            )

            export_root = Path(export_dir)
            self.assertTrue((export_root / "data-x" / "PAT001_0_0_101.png").exists())
            self.assertTrue((export_root / "data-y" / "PAT001_0_101_0.png").exists())
            self.assertTrue((export_root / "data-z" / "PAT001_101_0_0.png").exists())
            self.assertFalse((export_root / "data-x" / "PAT002_0_0_101.png").exists())

            label_lines = (export_root / "label.csv").read_text(encoding="utf-8").splitlines()
            self.assertEqual(label_lines, ["patient_id,label", "PAT001,1"])

            metadata = json.loads((export_root / "split_info.json").read_text(encoding="utf-8"))
            self.assertEqual(metadata["exported_patients"], ["PAT001"])
            self.assertEqual(metadata["counts"]["x"], 1)
            self.assertEqual(metadata["counts"]["y"], 1)
            self.assertEqual(metadata["counts"]["z"], 1)

    def test_export_multi_axis_skips_patient_missing_axis(self):
        from src.data.testset_export import export_prediction_ready_testset

        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            label_path = root / "label.csv"
            experiment_dir = root / "experiments" / "exp1"
            axis_paths = {axis: str(root / f"data-{axis}") for axis in ("x", "y", "z")}

            self._write_label_csv(label_path)
            self._write_multi_axis_pngs(root, "PAT001", ("x", "y"))

            organizer = MultiAxisDatasetOrganizer(axis_paths, LabelProcessor(str(label_path)))

            export_dir = export_prediction_ready_testset(
                experiment_dir=str(experiment_dir),
                experiment_name="exp1",
                test_patients=["PAT001"],
                labels={"PAT001": 1},
                organizer=organizer,
                source_data_path=str(root),
                active_axes=["x", "y", "z"],
            )

            export_root = Path(export_dir)
            self.assertTrue((export_root / "data-x").exists())
            self.assertEqual((export_root / "label.csv").read_text(encoding="utf-8").splitlines(), ["patient_id,label"])

            metadata = json.loads((export_root / "split_info.json").read_text(encoding="utf-8"))
            self.assertEqual(metadata["exported_patients"], [])
            self.assertEqual(metadata["skipped_patients"][0]["patient_id"], "PAT001")
            self.assertIn("missing_axes", metadata["skipped_patients"][0]["reason"])


if __name__ == "__main__":
    unittest.main()
