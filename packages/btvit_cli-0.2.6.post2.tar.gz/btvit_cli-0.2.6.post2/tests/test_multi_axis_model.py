import unittest

import torch

from src.model.vit_model import MultiAxisMedicalViT


class MultiAxisMedicalViTTest(unittest.TestCase):
    def test_forward_returns_logits_per_axis(self):
        model = MultiAxisMedicalViT(active_axes=["x", "y", "z"], input_shape=(16, 368), patch_size=(16, 16))
        batch = {
            "x": torch.randn(2, 1, 16, 368),
            "y": torch.randn(2, 1, 16, 368),
            "z": torch.randn(2, 1, 16, 368),
        }

        outputs = model(batch)

        self.assertEqual(set(outputs.keys()), {"x", "y", "z"})
        self.assertEqual(outputs["x"].shape, (2, 1))

    def test_extract_features_returns_512_dim_per_axis(self):
        model = MultiAxisMedicalViT(active_axes=["x", "y", "z"], input_shape=(16, 368), patch_size=(16, 16), dim=512)
        batch = {
            "x": torch.randn(1, 1, 16, 368),
            "y": torch.randn(1, 1, 16, 368),
            "z": torch.randn(1, 1, 16, 368),
        }

        features = model.extract_features(batch)

        self.assertEqual(features["x"].shape, (1, 512))
        self.assertEqual(features["y"].shape, (1, 512))
        self.assertEqual(features["z"].shape, (1, 512))


if __name__ == "__main__":
    unittest.main()
