from pathlib import Path

import numpy as np
from PIL import Image

from visualize_axis_feature_vectors import (
    build_output_path,
    save_feature_heatmap,
    select_patient_id,
)


def _make_png(path: Path) -> None:
    path.write_bytes(b"fake-png")


def test_select_patient_id_uses_sorted_common_patient_ids(tmp_path):
    axis_paths = {}
    for axis in ("x", "y", "z"):
        axis_dir = tmp_path / f"data-{axis}"
        axis_dir.mkdir()
        axis_paths[axis] = str(axis_dir)

    for axis in ("x", "y", "z"):
        _make_png(Path(axis_paths[axis]) / f"P002_{axis}.png")
        _make_png(Path(axis_paths[axis]) / f"P001_{axis}.png")

    _make_png(Path(axis_paths["x"]) / "ONLY_X_0.png")
    _make_png(Path(axis_paths["y"]) / "ONLY_Y_0.png")

    assert select_patient_id(axis_paths) == "P001"


def test_build_output_path_uses_expected_jpg_name(tmp_path):
    output_path = build_output_path(tmp_path, axis="z", patient_id="PAT001")

    assert output_path == tmp_path / "axis_feature_z_PAT001.jpg"


def test_save_feature_heatmap_writes_non_empty_jpg(tmp_path):
    output_path = tmp_path / "axis_feature_x_PAT001.jpg"
    feature_vector = np.linspace(-1.0, 1.0, 8, dtype=np.float32)

    save_feature_heatmap(
        feature_vector=feature_vector,
        output_path=output_path,
        patient_id="PAT001",
        axis="x",
        image_count=4,
        vmin=-1.0,
        vmax=1.0,
    )

    assert output_path.exists()
    assert output_path.stat().st_size > 0


def test_save_feature_heatmap_renders_plain_image_without_chart_canvas(tmp_path):
    output_path = tmp_path / "axis_feature_y_PAT001.jpg"
    feature_vector = np.linspace(-1.0, 1.0, 10, dtype=np.float32)

    save_feature_heatmap(
        feature_vector=feature_vector,
        output_path=output_path,
        patient_id="PAT001",
        axis="y",
        image_count=4,
        vmin=-1.0,
        vmax=1.0,
    )

    image = Image.open(output_path)

    assert image.size == (10 * 24, 96)
