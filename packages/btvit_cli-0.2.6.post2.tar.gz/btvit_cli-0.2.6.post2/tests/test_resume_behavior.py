import unittest
from unittest.mock import patch

from typer.testing import CliRunner

from src.cli.main import app


class ResumeBehaviorTests(unittest.TestCase):
    def test_cli_resume_flag_defaults_to_latest_checkpoint(self):
        runner = CliRunner()

        with patch("src.cli.train_cmd.execute_train") as execute_train:
            result = runner.invoke(
                app,
                ["train", "--config", "configs/base", "--stage", "axis", "--axis", "x", "--resume"],
            )

        self.assertEqual(result.exit_code, 0, msg=result.output)
        self.assertEqual(execute_train.call_args.kwargs["resume"], "latest")
        self.assertEqual(execute_train.call_args.kwargs["stage"], "axis")
        self.assertEqual(execute_train.call_args.kwargs["axis"], "x")


if __name__ == "__main__":
    unittest.main()
