import tempfile
import unittest
from pathlib import Path

from typer.testing import CliRunner


class CliGetTest(unittest.TestCase):
    def test_vit_get_exports_yaml_templates_and_usage_guide(self):
        from src.cli.main import app

        runner = CliRunner()
        with tempfile.TemporaryDirectory() as tmpdir:
            result = runner.invoke(app, ["get", "--path", tmpdir])

            self.assertEqual(result.exit_code, 0)

            output_dir = Path(tmpdir)
            expected_files = [
                "model_config.yaml",
                "data_config.yaml",
                "training_config.yaml",
                "experiment_config.yaml",
                "multi_axis_config.yaml",
                "monitoring_config.yaml",
                "USAGE.md",
            ]
            for filename in expected_files:
                self.assertTrue((output_dir / filename).exists(), filename)

            self.assertIn("#", (output_dir / "model_config.yaml").read_text(encoding="utf-8"))
            data_config = (output_dir / "data_config.yaml").read_text(encoding="utf-8")
            training_config = (output_dir / "training_config.yaml").read_text(encoding="utf-8")
            experiment_config = (output_dir / "experiment_config.yaml").read_text(encoding="utf-8")
            multi_axis_config = (output_dir / "multi_axis_config.yaml").read_text(encoding="utf-8")
            data_lines = data_config.splitlines()
            training_lines = training_config.splitlines()
            experiment_lines = experiment_config.splitlines()
            multi_axis_lines = multi_axis_config.splitlines()

            self.assertNotIn("  data_path: dataset/data", data_lines)
            self.assertNotIn("  label_path: dataset/label.csv", data_lines)
            self.assertNotIn("  batch_size: 32", data_lines)
            self.assertNotIn("  num_workers: 4", data_lines)
            self.assertNotIn("  shuffle: true", data_lines)
            self.assertTrue(any("  common:" in line for line in training_lines))
            self.assertTrue(any("  axis:" in line for line in training_lines))
            self.assertTrue(any("  fusion:" in line for line in training_lines))
            self.assertNotIn('monitor_metric: predict_accuracy', experiment_lines)
            self.assertNotIn('monitor_mode: max', experiment_lines)
            self.assertTrue(any("  patient_pooling:" in line for line in multi_axis_lines))
            self.assertTrue(any("  weighted_vote:" in line for line in multi_axis_lines))
            self.assertTrue(any("  fusion_head:" in line for line in multi_axis_lines))
            self.assertTrue(any("    fusion: " in line for line in multi_axis_lines))
            self.assertFalse(any("    weights:" in line for line in multi_axis_lines))
            self.assertFalse(any("  knn_k" in line for line in multi_axis_lines))
            self.assertFalse(any("  knn_metric" in line for line in multi_axis_lines))
            self.assertFalse(any("  save_features" in line for line in multi_axis_lines))
            self.assertFalse(any("  feature_dir" in line for line in multi_axis_lines))
            self.assertFalse(any("  axis_loss_weights" in line for line in multi_axis_lines))

            usage = (output_dir / "USAGE.md").read_text(encoding="utf-8")
            self.assertIn("vit CLI Usage", usage)
            self.assertIn("YAML Variable Reference", usage)
            self.assertIn("--stage axis", usage)
            self.assertIn("--stage fusion", usage)
            self.assertIn("--mode weighted_vote|fusion_nn|both", usage)
            self.assertIn("--fusion", usage)
            self.assertNotIn("--weighted-vote-threshold", usage)
            self.assertNotIn("--thresholds", usage)
            self.assertIn("SuShuHeng", usage)
            self.assertIn("https://github.com/SuShuHeng/Vit-cli", usage)
            self.assertIn("Apache2.0", usage)


if __name__ == "__main__":
    unittest.main()
