import importlib.util
from pathlib import Path
from types import SimpleNamespace


def _load_configs_runner_module():
    module_path = Path(__file__).resolve().parents[1] / ".claude/skills/configs-runner/scripts/configs_runner.py"
    spec = importlib.util.spec_from_file_location("configs_runner_script", module_path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def test_configs_runner_parser_defaults_to_same_init():
    module = _load_configs_runner_module()

    parser = module.build_parser()
    args = parser.parse_args(["--file", "batch.txt"])

    assert args.init == "same"


def test_configs_runner_passes_seed_args_to_train_commands(monkeypatch):
    module = _load_configs_runner_module()
    commands = []

    def fake_run_command(cmd, timeout=7200):
        commands.append(cmd)
        return True, "", 0.1

    monkeypatch.setattr(module, "run_command", fake_run_command)

    args = SimpleNamespace(
        init="random",
        init_seed=11,
        random_seed=22,
        train_split_seed=33,
        data_dir="dataset/data",
        label_path=None,
        verbose=False,
    )

    module.run_single_experiment("configs/base", "exp_name", "dataset/data", None, args=args)

    axis_cmd = commands[0]
    assert "--init" in axis_cmd
    assert "random" in axis_cmd
    assert "--init-seed" in axis_cmd
    assert "11" in axis_cmd
    assert "--random-seed" in axis_cmd
    assert "22" in axis_cmd
    assert "--train-split-seed" in axis_cmd
    assert "33" in axis_cmd
