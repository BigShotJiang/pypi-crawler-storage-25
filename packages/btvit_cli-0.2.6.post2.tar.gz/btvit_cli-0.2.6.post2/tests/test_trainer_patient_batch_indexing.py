import types

import torch
from torch.utils.data import DataLoader, Dataset

from src.training.axis_trainer import AxisTrainer
from src.training.trainer import Trainer


class _PatientBatchDataset(Dataset):
    def __init__(self, patient_count: int = 9):
        self.samples = []
        self._items = []

        for patient_idx in range(patient_count):
            patient_id = f"P{patient_idx:02d}"
            label = float(patient_idx % 2)
            logit = 6.0 if label == 1.0 else -6.0
            image_path = f"/tmp/{patient_id}_{patient_idx:03d}.png"
            self.samples.append((image_path, int(label)))
            self._items.append(
                (
                    torch.tensor([logit], dtype=torch.float32),
                    torch.tensor(label, dtype=torch.float32),
                )
            )

    def __len__(self):
        return len(self._items)

    def __getitem__(self, idx):
        return self._items[idx]


def _make_loader(batch_size: int = 4) -> DataLoader:
    return DataLoader(_PatientBatchDataset(), batch_size=batch_size, shuffle=False)


def _make_config():
    return types.SimpleNamespace(
        monitoring=types.SimpleNamespace(verbose=False),
        training=types.SimpleNamespace(debug_logging=False),
    )


def _make_axis_trainer() -> AxisTrainer:
    trainer = AxisTrainer.__new__(AxisTrainer)
    trainer.model = torch.nn.Identity()
    trainer.criterion = torch.nn.BCEWithLogitsLoss()
    trainer.device = torch.device("cpu")
    trainer.config = _make_config()
    return trainer


def _make_base_trainer() -> Trainer:
    trainer = Trainer.__new__(Trainer)
    trainer.model = torch.nn.Identity()
    trainer.criterion = torch.nn.BCEWithLogitsLoss()
    trainer.device = torch.device("cpu")
    trainer.config = _make_config()
    return trainer


def test_axis_trainer_patient_metrics_include_patients_from_short_final_batch():
    loader = _make_loader(batch_size=4)
    trainer = _make_axis_trainer()

    metrics = trainer._evaluate_loader_with_patient_mean(loader, "测试中")

    assert metrics["patient_total"] == 9
    assert metrics["patient_correct"] == 9
    assert [detail["patient_id"] for detail in metrics["patient_details"]] == [
        "P00",
        "P01",
        "P02",
        "P03",
        "P04",
        "P05",
        "P06",
        "P07",
        "P08",
    ]


def test_validate_epoch_patient_metrics_include_patients_from_short_final_batch():
    loader = _make_loader(batch_size=4)
    trainer = _make_base_trainer()

    metrics = trainer.validate_epoch(loader)

    assert metrics["patient_total"] == 9
    assert metrics["patient_correct"] == 9
