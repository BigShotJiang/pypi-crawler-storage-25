import io
import os
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

from src.cli import predict_impl, predict_runner


class PredictRunnerTests(unittest.TestCase):
    def test_execute_predict_args_uses_packaged_implementation(self):
        raw_args = {"config": "configs/base", "mode": "both", "data": "dataset/data"}

        with mock.patch.object(
            predict_runner,
            "execute_packaged_predict_args",
            return_value=123,
            create=True,
        ) as execute_packaged_predict_args:
            result = predict_runner.execute_predict_args(raw_args)

        self.assertEqual(result, 123)
        execute_packaged_predict_args.assert_called_once_with(raw_args)

    def test_execute_predict_args_logs_prediction_output_paths(self):
        results = [
            {
                "patient_id": "PAT001",
                "weighted_vote_prob": 0.75,
                "weighted_vote_pred": 1,
                "fusion_nn_prob": 0.8,
                "fusion_nn_pred": 1,
            }
        ]
        summary = {"patient_count": 1}

        with tempfile.TemporaryDirectory() as tmpdir:
            axis_paths = {}
            for axis in ("x", "y", "z"):
                checkpoint_path = Path(tmpdir) / f"{axis}.pth"
                checkpoint_path.write_text("fake", encoding="utf-8")
                axis_paths[axis] = str(checkpoint_path)
            fusion_path = Path(tmpdir) / "fusion.pth"
            fusion_path.write_text("fake", encoding="utf-8")

            raw_args = {
                "config": "configs/base",
                "mode": "both",
                "data": "dataset/data",
                "output": tmpdir,
                "label": None,
                "verbose": False,
                "model": None,
            }
            with mock.patch.object(
                predict_impl,
                "resolve_paths_from_config",
                return_value={
                    "axis_checkpoint_paths": axis_paths,
                    "fusion_checkpoint_path": str(fusion_path),
                    "data_path": "dataset/data",
                    "label_path": None,
                },
            ):
                with mock.patch.object(
                    predict_impl,
                    "resolve_axis_data_paths",
                    return_value={"x": "data-x", "y": "data-y", "z": "data-z"},
                ):
                    with mock.patch.object(predict_impl, "collect_patient_ids", return_value=["PAT001"]):
                        with mock.patch.object(predict_impl, "load_label_map", return_value={}):
                            with mock.patch.object(predict_impl, "PatientPredictor") as predictor_cls:
                                predictor_cls.return_value.predict_batch.return_value = (results, summary)

                                with redirect_stdout(io.StringIO()):
                                    result = predict_impl.execute_predict_args(raw_args)

            self.assertEqual(result, 0)

            log_files = list((Path(tmpdir) / "logs").glob("predict_*.log"))
            self.assertEqual(len(log_files), 1)

            log_contents = log_files[0].read_text(encoding="utf-8")
            self.assertIn("prediction completed", log_contents)
            self.assertIn("prediction_csv=", log_contents)
            self.assertIn("summary_json=", log_contents)

    def test_predict_normalize_args_accepts_tta_switches(self):
        args = predict_impl.normalize_args(
            {
                "config": "configs/base",
                "mode": "both",
                "data": "dataset/data",
                "tta": True,
                "tta_augmentations": 7,
            }
        )

        self.assertTrue(args.tta)
        self.assertEqual(args.tta_augmentations, 7)

    def test_execute_predict_args_forwards_tta_options_to_predictor(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            axis_paths = {}
            for axis in ("x", "y", "z"):
                checkpoint_path = Path(tmpdir) / f"{axis}.pth"
                checkpoint_path.write_text("fake", encoding="utf-8")
                axis_paths[axis] = str(checkpoint_path)
            fusion_path = Path(tmpdir) / "fusion.pth"
            fusion_path.write_text("fake", encoding="utf-8")

            raw_args = {
                "config": "configs/base",
                "mode": "both",
                "data": "dataset/data",
                "output": tmpdir,
                "label": None,
                "verbose": False,
                "model": None,
                "tta": True,
                "tta_augmentations": 9,
            }

            with mock.patch.object(
                predict_impl,
                "resolve_paths_from_config",
                return_value={
                    "axis_checkpoint_paths": axis_paths,
                    "fusion_checkpoint_path": str(fusion_path),
                    "data_path": "dataset/data",
                    "label_path": None,
                },
            ):
                with mock.patch.object(
                    predict_impl,
                    "resolve_axis_data_paths",
                    return_value={"x": "data-x", "y": "data-y", "z": "data-z"},
                ):
                    with mock.patch.object(predict_impl, "collect_patient_ids", return_value=[]):
                        with mock.patch.object(predict_impl, "load_label_map", return_value={}):
                            with mock.patch.object(predict_impl, "PatientPredictor") as predictor_cls:
                                predictor_cls.return_value.predict_batch.return_value = ([], {"patient_count": 0})

                                with redirect_stdout(io.StringIO()):
                                    result = predict_impl.execute_predict_args(raw_args)

        self.assertEqual(result, 0)
        forwarded = predictor_cls.call_args.kwargs
        self.assertTrue(forwarded["tta"])
        self.assertEqual(forwarded["tta_augmentations"], 9)


class PredictConfigMergeTest(unittest.TestCase):
    def test_config_fills_missing_data_and_label(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir) / "configs"
            config_dir.mkdir()
            (config_dir / "experiment_config.yaml").write_text(
                "name: exp1\nsave_dir: experiments\n",
                encoding="utf-8",
            )
            experiment_dir = Path(tmpdir) / "experiments" / "exp1"
            (experiment_dir / "axis-x" / "checkpoints").mkdir(parents=True)
            (experiment_dir / "axis-y" / "checkpoints").mkdir(parents=True)
            (experiment_dir / "axis-z" / "checkpoints").mkdir(parents=True)
            (experiment_dir / "fusion" / "checkpoints").mkdir(parents=True)
            (experiment_dir / "testset").mkdir(parents=True)
            (experiment_dir / "testset" / "data-x").mkdir()
            (experiment_dir / "testset" / "data-y").mkdir()
            (experiment_dir / "testset" / "data-z").mkdir()
            (experiment_dir / "testset" / "label.csv").write_text("patient_id,label\n", encoding="utf-8")
            for stage in ("axis-x", "axis-y", "axis-z", "fusion"):
                (experiment_dir / stage / "checkpoints" / "best_model.pth").write_text("fake", encoding="utf-8")

            raw_args = {
                "model": None,
                "config": str(config_dir),
                "mode": "weighted_vote",
                "data": None,
                "output": tmpdir,
                "label": None,
                "verbose": False,
            }

            original_cwd = os.getcwd()
            try:
                os.chdir(tmpdir)
                with mock.patch.object(
                    predict_impl,
                    "resolve_axis_data_paths",
                    return_value={"x": "dx", "y": "dy", "z": "dz"},
                ):
                    with mock.patch.object(predict_impl, "collect_patient_ids", return_value=[]):
                        with mock.patch.object(predict_impl, "load_label_map", return_value={}):
                            with mock.patch.object(predict_impl, "PatientPredictor") as cls:
                                cls.return_value.predict_batch.return_value = ([], {"patient_count": 0})
                                with redirect_stdout(io.StringIO()):
                                    result = predict_impl.execute_predict_args(raw_args)
            finally:
                os.chdir(original_cwd)

            self.assertEqual(result, 0)

    def test_raises_when_neither_model_nor_config(self):
        raw_args = {
            "model": None,
            "config": None,
            "mode": "both",
            "data": "some/data",
            "output": "output",
            "label": None,
            "verbose": False,
        }
        with self.assertRaises(ValueError) as ctx:
            predict_impl.execute_predict_args(raw_args)
        self.assertIn("--model", str(ctx.exception))
        self.assertIn("--config", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
