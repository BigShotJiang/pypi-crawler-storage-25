# plcc-ng

PLCC is designed for teaching and learning programming language concepts.
plcc-ng is a reimagining and reimplementation of PLCC.

This is currently under development.

## Install

```bash
pip install plcc-ng
```

> This package has a separate identity from the original `plcc` package.
> `plcc-ng` is experimental — no compatibility guarantees with `plcc` until a stable 1.0 release.

## Licensing

Developers license contributions under [AGPL-3.0-or-later](LICENSES/AGPL-3.0-or-later.txt) and sign off on the
[DCO-1.1](DCO-1.1.txt)

## Community

- [Code of conduct](CODE_OF_CONDUCT.md)
- [Discord server]((https://discord.gg/EVtNSxS9E2))

## Development

- Python
- PDM
- Codespaces
- Dev Containers
- Clean code
- TDD
- Open Source Values
- Continuously run unit tests (^C to stop)

    ```bash
    pdm ctest
    ```
