"""Errors the agent might encounter when calling pay()."""


class VetoError(Exception):
    """Base class for veto-pay errors."""


class VetoDenied(VetoError):
    """Veto denied the spend. Read .reason_codes for the why."""

    def __init__(self, message: str, *, reason_codes: list[str] | None = None,
                 receipt: str | None = None, decision_layer: str | None = None) -> None:
        super().__init__(message)
        self.reason_codes = reason_codes or []
        self.receipt = receipt
        self.decision_layer = decision_layer


class RailNotSupported(VetoError):
    """The detected rail isn't supported by this build (e.g. the [solana]
    extra wasn't installed and you tried a Solana payment)."""


class ConfigError(VetoError):
    """Missing or malformed configuration — typically VETO_API_KEY,
    VETO_AGENT_ID, or wallet credentials."""
