"""Solana settlement — call veto_guarded_program::execute_with_mandate.

The program expects two instructions in the same transaction:
  ix[0] = Ed25519Program.verify(signer=veto_signer, msg=mandate_digest, sig=ed25519_sig)
  ix[1] = veto_guarded_program::execute_with_mandate(Mandate borsh, amount)

The dispatch dict from Veto's authorize endpoint carries everything we need to
build both instructions:
    rail = "solana"
    vault, jti, exp, recipient, max_amount, token,
    digest, ed25519_sig, veto_signer

Dependencies are imported lazily — only when this rail is used.
"""
from __future__ import annotations

import os
from typing import Any


async def settle(
    *,
    mandate: str | None,
    dispatch: dict[str, Any],
    payload: dict[str, Any],
    body: dict[str, Any],
) -> str:
    """Build the two-instruction tx and submit it to the Solana RPC."""
    try:
        from solders.pubkey import Pubkey
        from solders.keypair import Keypair
        from solders.transaction import Transaction
        from solders.system_program import ID as SYSTEM_PROGRAM_ID
        from solders.instruction import Instruction, AccountMeta
        from solana.rpc.async_api import AsyncClient
        import base58
    except ImportError as e:
        raise ImportError(
            "Solana settlement requires the [solana] extra. "
            "Install with: pip install veto-pay[solana]"
        ) from e

    rpc_url = os.environ.get("SOLANA_RPC_URL") or _default_rpc(dispatch.get("chain") or payload.get("chain"))
    program_id_b58 = os.environ.get("VETO_GUARDED_PROGRAM_ID") or dispatch.get("program_id")
    payer_secret = os.environ.get("WALLET_PRIVATE_KEY")
    if not program_id_b58:
        raise RuntimeError("VETO_GUARDED_PROGRAM_ID not set and dispatch.program_id missing.")
    if not payer_secret:
        raise RuntimeError("WALLET_PRIVATE_KEY not set — needed to sign the Solana tx.")

    # Decode payer keypair (base58-encoded Solana private key).
    payer = Keypair.from_base58_string(payer_secret)
    program_id = Pubkey.from_string(program_id_b58)
    vault_pk = Pubkey.from_string(dispatch["vault"])
    recipient_pk = Pubkey.from_string(dispatch["recipient"])
    veto_signer_pk = Pubkey.from_string(dispatch["veto_signer"])

    digest = bytes.fromhex(dispatch["digest"])
    ed25519_sig = bytes.fromhex(dispatch["ed25519_sig"])
    veto_signer_raw = bytes(veto_signer_pk)

    # Derive the SpentJti PDA so anchor's #[account(init)] can claim it.
    jti_bytes = bytes.fromhex(dispatch["jti"])
    spent_jti_pda, _ = Pubkey.find_program_address(
        [b"spent", bytes(vault_pk), jti_bytes],
        program_id,
    )
    instructions_sysvar = Pubkey.from_string("Sysvar1nstructions1111111111111111111111111")

    # Instruction 0: Ed25519 verify.
    ed25519_ix = _ed25519_verify_ix(veto_signer_raw, digest, ed25519_sig)

    # Instruction 1: execute_with_mandate.
    exec_ix = _execute_with_mandate_ix(
        program_id=program_id,
        vault=vault_pk,
        spent_jti=spent_jti_pda,
        recipient=recipient_pk,
        instructions_sysvar=instructions_sysvar,
        caller=payer.pubkey(),
        system_program=SYSTEM_PROGRAM_ID,
        mandate=dispatch,
        amount=int(dispatch.get("amount") or dispatch["max_amount"]),
    )

    # Send tx.
    async with AsyncClient(rpc_url) as client:
        latest = (await client.get_latest_blockhash()).value.blockhash
        tx = Transaction.new_signed_with_payer(
            [ed25519_ix, exec_ix], payer.pubkey(), [payer], latest
        )
        sig = (await client.send_raw_transaction(bytes(tx))).value
    return str(sig)


def _ed25519_verify_ix(pubkey: bytes, message: bytes, signature: bytes):
    """Construct the Ed25519Program verify instruction (single signature)."""
    from solders.pubkey import Pubkey
    from solders.instruction import Instruction
    ED25519_PROGRAM_ID = Pubkey.from_string("Ed25519SigVerify111111111111111111111111111")

    # Layout — single signature:
    #   u8  num_signatures (1)
    #   u8  padding (0)
    #   Ed25519SignatureOffsets [14 bytes]:
    #     u16 signature_offset
    #     u16 signature_instruction_index (0xFFFF = same ix)
    #     u16 public_key_offset
    #     u16 public_key_instruction_index (0xFFFF)
    #     u16 message_data_offset
    #     u16 message_data_size
    #     u16 message_instruction_index (0xFFFF)
    #   bytes signature (64)
    #   bytes pubkey (32)
    #   bytes message
    SAME_IX = 0xFFFF
    header_len = 2 + 14
    sig_off = header_len
    pk_off = sig_off + 64
    msg_off = pk_off + 32

    data = bytearray()
    data += bytes([1, 0])
    data += sig_off.to_bytes(2, "little")
    data += SAME_IX.to_bytes(2, "little")
    data += pk_off.to_bytes(2, "little")
    data += SAME_IX.to_bytes(2, "little")
    data += msg_off.to_bytes(2, "little")
    data += len(message).to_bytes(2, "little")
    data += SAME_IX.to_bytes(2, "little")
    data += signature
    data += pubkey
    data += message

    return Instruction(program_id=ED25519_PROGRAM_ID, accounts=[], data=bytes(data))


def _execute_with_mandate_ix(
    *,
    program_id,
    vault,
    spent_jti,
    recipient,
    instructions_sysvar,
    caller,
    system_program,
    mandate,
    amount: int,
):
    """Build the veto_guarded_program::execute_with_mandate instruction."""
    from solders.instruction import Instruction, AccountMeta
    try:
        from borsh_construct import CStruct, U8, U64, I64
        from borsh_construct import HashMap  # noqa: F401  (just to confirm import)
    except ImportError as e:
        raise ImportError(
            "borsh-construct missing — install with: pip install veto-pay[solana]"
        ) from e

    # Anchor instruction discriminator: sha256("global:execute_with_mandate")[:8].
    # We hard-code the bytes from the program's IDL once known. Until then,
    # compute at request time from the canonical method name.
    import hashlib
    discriminator = hashlib.sha256(b"global:execute_with_mandate").digest()[:8]

    # Borsh-encode (Mandate, amount: u64).
    # Layout: jti[32] || exp(i64 LE) || recipient(Pubkey 32) || max_amount(u64 LE) || token(Pubkey 32) || amount(u64 LE)
    from solders.pubkey import Pubkey
    jti_bytes = bytes.fromhex(mandate["jti"])
    exp_int = int(mandate["exp"])
    recipient_b = bytes(Pubkey.from_string(mandate["recipient"]))
    max_amt = int(mandate["max_amount"])
    token_b = bytes(Pubkey.from_string(mandate["token"]))

    body = bytearray()
    body += jti_bytes.rjust(32, b"\x00")[:32]
    body += exp_int.to_bytes(8, "little", signed=True)
    body += recipient_b
    body += max_amt.to_bytes(8, "little", signed=False)
    body += token_b
    body += amount.to_bytes(8, "little", signed=False)

    data = discriminator + bytes(body)

    accounts = [
        AccountMeta(pubkey=vault,                is_signer=False, is_writable=True),
        AccountMeta(pubkey=spent_jti,            is_signer=False, is_writable=True),
        AccountMeta(pubkey=recipient,            is_signer=False, is_writable=True),
        AccountMeta(pubkey=instructions_sysvar,  is_signer=False, is_writable=False),
        AccountMeta(pubkey=caller,               is_signer=True,  is_writable=True),
        AccountMeta(pubkey=system_program,       is_signer=False, is_writable=False),
    ]
    return Instruction(program_id=program_id, accounts=accounts, data=data)


def _default_rpc(chain: str | None) -> str:
    if not chain:
        return "https://api.devnet.solana.com"
    c = chain.lower()
    if "mainnet" in c:
        return "https://api.mainnet-beta.solana.com"
    return "https://api.devnet.solana.com"
