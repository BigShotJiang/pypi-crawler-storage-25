"""EVM settlement — call VetoGuardedAccount.executeWithMandate(...) on whatever
EVM chain the agent's wallet is configured for.

The mandate Veto returns is a JWT (off-chain) PLUS a paired secp256k1 EIP-712
signature (`dispatch.eip712_sig`) that the contract verifies via ecrecover.
We submit one tx: VetoGuardedAccount.executeWithMandate(struct, sig, amount).

Dependencies are imported lazily so the package's base path stays light.
"""
from __future__ import annotations

import os
from typing import Any


async def settle(
    *,
    mandate: str | None,
    dispatch: dict[str, Any],
    payload: dict[str, Any],
    body: dict[str, Any],
) -> str:
    """Submit an executeWithMandate tx and return the on-chain tx hash."""
    try:
        from eth_account import Account
        from eth_account.messages import encode_typed_data
        from web3 import Web3
    except ImportError as e:
        raise ImportError(
            "EVM settlement requires the [evm] extra. "
            "Install with: pip install veto-pay[evm]"
        ) from e

    private_key = os.environ.get("WALLET_PRIVATE_KEY")
    if not private_key:
        raise RuntimeError("WALLET_PRIVATE_KEY not set — needed for EVM settlement.")

    rpc_url = os.environ.get("RPC_URL") or _default_rpc(dispatch.get("chain") or payload.get("chain"))
    contract_addr = os.environ.get("WALLET_CONTRACT") or dispatch.get("contract_address")
    if not contract_addr:
        raise RuntimeError("WALLET_CONTRACT not set and dispatch.contract_address missing.")

    w3 = Web3(Web3.HTTPProvider(rpc_url))
    acct = Account.from_key(private_key)

    # Mandate struct, signature, and amount come from the dispatch field.
    # Fields the contract expects: jti (bytes32), exp (uint256), recipient (address),
    # max_amount (uint256), token (address), and the secp256k1 sig.
    mandate_struct = dispatch.get("mandate_struct")
    eip712_sig = dispatch.get("eip712_sig")
    amount_wei = int(dispatch.get("amount_wei") or 0)
    if not mandate_struct or not eip712_sig:
        raise RuntimeError("dispatch.mandate_struct or dispatch.eip712_sig missing — server didn't return EVM dispatch bytes.")

    # Build the contract call — ABI is bundled with the CLI; the SDK uses the
    # minimal selectors directly to stay light.
    # Function selector: keccak("executeWithMandate((bytes32,uint256,address,uint256,address),bytes,uint256)")[:4]
    # See contracts/src/VetoGuardedAccount.sol for the canonical ABI.
    contract = w3.eth.contract(address=Web3.to_checksum_address(contract_addr), abi=_MINIMAL_ABI)

    tx = contract.functions.executeWithMandate(
        (
            bytes.fromhex(mandate_struct["jti"].removeprefix("0x")),
            int(mandate_struct["exp"]),
            Web3.to_checksum_address(mandate_struct["recipient"]),
            int(mandate_struct["max_amount"]),
            Web3.to_checksum_address(mandate_struct["token"]),
        ),
        bytes.fromhex(eip712_sig.removeprefix("0x")),
        amount_wei,
    ).build_transaction({
        "from": acct.address,
        "nonce": w3.eth.get_transaction_count(acct.address),
        "chainId": int(dispatch.get("chain_id") or w3.eth.chain_id),
        "gasPrice": w3.eth.gas_price * 2,
        "gas": 300_000,
    })
    signed = acct.sign_transaction(tx)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction).hex()
    return tx_hash if tx_hash.startswith("0x") else f"0x{tx_hash}"


def _default_rpc(chain: str | None) -> str:
    if not chain:
        return "https://sepolia.base.org"
    c = chain.lower()
    return {
        "base-sepolia":     "https://sepolia.base.org",
        "base-mainnet":     "https://mainnet.base.org",
        "optimism-sepolia": "https://sepolia.optimism.io",
        "optimism-mainnet": "https://mainnet.optimism.io",
        "arbitrum-sepolia": "https://sepolia-rollup.arbitrum.io/rpc",
        "arbitrum-mainnet": "https://arb1.arbitrum.io/rpc",
        "ethereum-sepolia": "https://ethereum-sepolia-rpc.publicnode.com",
        "ethereum-mainnet": "https://eth.llamarpc.com",
        "polygon-amoy":     "https://rpc-amoy.polygon.technology",
        "polygon-mainnet":  "https://polygon-rpc.com",
    }.get(c, "https://sepolia.base.org")


# Minimal ABI — only what's needed to call executeWithMandate.
_MINIMAL_ABI = [
    {
        "inputs": [
            {
                "components": [
                    {"name": "jti",        "type": "bytes32"},
                    {"name": "exp",        "type": "uint256"},
                    {"name": "recipient",  "type": "address"},
                    {"name": "maxAmount",  "type": "uint256"},
                    {"name": "token",      "type": "address"},
                ],
                "name": "m",
                "type": "tuple",
            },
            {"name": "signature", "type": "bytes"},
            {"name": "amount",    "type": "uint256"},
        ],
        "name": "executeWithMandate",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function",
    },
]
