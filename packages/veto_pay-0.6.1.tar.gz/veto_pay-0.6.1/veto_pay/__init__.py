"""veto-pay — one-line agent payments with Veto enforcement.

Quick start:

    from veto_pay import pay

    result = await pay(
        url="https://api.weather.x402.io/forecast",
        max_amount="$0.05",
        rail="auto",          # auto | evm | solana
    )
    print(result.tx_hash)     # on-chain tx hash on success
    print(result.receipt)     # signed Veto receipt

The function:
    1. Calls Veto's authorize endpoint with the spend intent.
    2. If denied, raises VetoDenied with the reason code.
    3. If approved, signs a fresh mandate, dispatches to the right rail,
       and returns the receipt + tx hash.
"""

from .core import pay, PayResult
from .errors import VetoDenied, VetoError, RailNotSupported, ConfigError

__version__ = "0.6.0"

__all__ = [
    "pay",
    "PayResult",
    "VetoDenied",
    "VetoError",
    "RailNotSupported",
    "ConfigError",
]
