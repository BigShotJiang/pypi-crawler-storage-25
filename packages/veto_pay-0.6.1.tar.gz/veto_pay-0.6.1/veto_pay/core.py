"""Core pay() function — the one-liner.

Flow:
    1. Read config (VETO_API_KEY, VETO_AGENT_ID, wallet creds, rail) from env or args.
    2. POST /api/v1/authorize with the spend intent.
    3. Veto returns {decision, receipt, mandate?, dispatch?}.
       - decision == "deny"     → raise VetoDenied
       - decision == "escalate" → raise VetoDenied (escalation is human-required)
       - decision == "allow"    → mandate + dispatch present, settle on the rail.
    4. Dispatch to the rail-specific settler (evm or solana).
    5. Return PayResult(receipt, tx_hash, decision, ...).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urlparse

import httpx

from .errors import ConfigError, RailNotSupported, VetoDenied, VetoError


VETO_API_BASE_DEFAULT = "https://veto-ai.com"


@dataclass
class PayResult:
    decision: str                       # "allow" | "escalate"
    receipt: str                        # JWS compact signed receipt
    tx_hash: str | None = None          # on-chain tx hash if settled
    rail: str = "evm"                   # rail used
    mandate: str | None = None          # JWS compact mandate (if any)
    raw: dict[str, Any] = field(default_factory=dict)  # full authorize response


async def pay(
    *,
    url: str | None = None,
    merchant: str | None = None,
    recipient: str | None = None,
    max_amount: str | float | int,
    currency: str = "USD",
    rail: str = "auto",
    chain: str | None = None,
    action: str = "payment",
    veto_base_url: str | None = None,
    api_key: str | None = None,
    agent_id: str | None = None,
    decision_only: bool = False,
    timeout: float = 30.0,
    extra_context: dict[str, Any] | None = None,
) -> PayResult:
    """Authorize + settle an agent spend in one call.

    Args:
        url: Target URL of the call. Used as merchant + extracted into a host.
            (Use this for x402 / pay.sh / generic API pay-walls.)
        merchant: Merchant identifier (mutually exclusive with `url`).
        recipient: On-chain recipient (Pubkey for Solana, 0x address for EVM).
            For URL-based x402 calls, leave None — the rail's facilitator
            decodes the recipient from the 402 challenge response.
        max_amount: Cap. "$0.05", 0.05, or "0.05 USDC". Parsed to float USD
            for the policy check; on-chain settlement uses the rail's units.
        currency: ISO 4217 (default "USD"). For SPL tokens use "USDC", "USDT".
        rail: "auto" (default) | "evm" | "solana". When "auto", inferred from
            chain or wallet env.
        chain: Optional explicit chain hint ("base-sepolia", "solana-devnet").
        action: "payment" | "crypto_transfer" | "subscribe".
        veto_base_url: Override the Veto API base (default: VETO_BASE_URL env or
            https://veto-ai.com).
        api_key: Override VETO_API_KEY.
        agent_id: Override VETO_AGENT_ID.
        decision_only: If True, don't settle — just return the verdict + receipt.
            Useful for cooperative-mode integrations and dry runs.
        timeout: HTTP timeout for the authorize call.
        extra_context: Free-form bag merged into the authorize request payload's
            `context` field (used by the engine for prompt-injection / intent).

    Returns:
        PayResult with .decision, .receipt, .tx_hash, .mandate.

    Raises:
        VetoDenied: Veto denied or escalated the spend.
        RailNotSupported: rail is solana but the [solana] extra isn't installed.
        ConfigError: missing API key / agent ID / wallet config.
    """
    # ── Config resolution ─────────────────────────────────────────
    base = veto_base_url or os.environ.get("VETO_BASE_URL") or VETO_API_BASE_DEFAULT
    api_key = api_key or os.environ.get("VETO_API_KEY")
    agent_id = agent_id or os.environ.get("VETO_AGENT_ID")
    if not api_key:
        raise ConfigError("VETO_API_KEY is not set (env or argument).")
    if not agent_id:
        raise ConfigError("VETO_AGENT_ID is not set (env or argument).")

    # ── Resolve rail ──────────────────────────────────────────────
    resolved_rail = _resolve_rail(rail, chain)

    # ── Build authorize payload ───────────────────────────────────
    if not url and not merchant:
        raise ConfigError("Pass either url= or merchant=.")
    parsed_merchant = merchant or _host_from_url(url or "")
    amount_float = _coerce_amount(max_amount)

    payload: dict[str, Any] = {
        "agent_id": agent_id,
        "amount": amount_float,
        "merchant": parsed_merchant,
        "currency": currency,
        "action": action,
    }
    if recipient:
        payload["to_address"] = recipient
    if chain:
        payload["chain"] = chain
    if url:
        payload.setdefault("context", {})["call_url"] = url
    if extra_context:
        payload.setdefault("context", {}).update(extra_context)

    # ── Call Veto authorize ──────────────────────────────────────
    headers = {
        "X-Veto-API-Key": api_key,
        "Content-Type": "application/json",
    }
    async with httpx.AsyncClient(timeout=timeout) as client:
        resp = await client.post(f"{base}/api/v1/authorize/", headers=headers, json=payload)
    if resp.status_code >= 500:
        raise VetoError(f"Veto authorize 5xx: {resp.status_code} {resp.text[:300]}")
    if resp.status_code == 401:
        raise ConfigError("VETO_API_KEY rejected by server (401).")
    body = resp.json()

    decision = (body.get("decision") or body.get("status") or "").lower()
    receipt = body.get("receipt") or ""
    mandate = body.get("mandate")
    dispatch = body.get("dispatch") or {}
    reason_codes = body.get("reason_codes") or []

    if decision == "deny":
        raise VetoDenied(
            "Veto denied this spend.",
            reason_codes=reason_codes,
            receipt=receipt,
            decision_layer=body.get("decision_layer"),
        )
    if decision == "escalate":
        raise VetoDenied(
            "Veto escalated this spend — human review required before it can settle.",
            reason_codes=reason_codes,
            receipt=receipt,
            decision_layer=body.get("decision_layer"),
        )

    if decision_only:
        return PayResult(decision="allow", receipt=receipt, mandate=mandate, rail=resolved_rail, raw=body)

    # ── Settle ───────────────────────────────────────────────────
    if resolved_rail == "evm":
        from .rails import evm
        tx_hash = await evm.settle(
            mandate=mandate, dispatch=dispatch, payload=payload, body=body,
        )
    elif resolved_rail == "solana":
        try:
            from .rails import solana
        except ImportError as e:
            raise RailNotSupported(
                "Solana support requires the [solana] extra. "
                "Install with: pip install veto-pay[solana]"
            ) from e
        tx_hash = await solana.settle(
            mandate=mandate, dispatch=dispatch, payload=payload, body=body,
        )
    else:
        raise RailNotSupported(f"rail '{resolved_rail}' is not supported in this build.")

    return PayResult(
        decision="allow",
        receipt=receipt,
        tx_hash=tx_hash,
        mandate=mandate,
        rail=resolved_rail,
        raw=body,
    )


# ── Helpers ───────────────────────────────────────────────────────

def _resolve_rail(rail: str, chain: str | None) -> str:
    if rail and rail != "auto":
        return rail.lower()
    if chain:
        c = chain.lower()
        if c.startswith("solana"):
            return "solana"
        return "evm"
    # Fall back to env
    env_rail = (os.environ.get("VETO_RAIL") or "").lower()
    if env_rail in {"evm", "solana"}:
        return env_rail
    # Default: evm
    return "evm"


def _host_from_url(url: str) -> str:
    try:
        parsed = urlparse(url)
        return parsed.netloc or url
    except Exception:
        return url


def _coerce_amount(amount: str | float | int) -> float:
    if isinstance(amount, (int, float)):
        return float(amount)
    s = str(amount).strip().lstrip("$")
    # Strip optional currency suffix like "0.05 USDC"
    parts = s.split()
    return float(parts[0])
