"""TFT display renderer using pygame."""

import threading
from typing import List

from emulator import get_state
from emulator.display.base import BaseDisplay, draw_memory_bar, safe_font

# Lazy import pygame to allow headless operation
pygame = None

# Lazy import sensor panel
_sensor_panel_class = None


def _get_sensor_panel_class():
    global _sensor_panel_class
    if _sensor_panel_class is None:
        from emulator.hardware.sensor_panel import SensorPanel
        _sensor_panel_class = SensorPanel
    return _sensor_panel_class


def _init_pygame():
    global pygame
    if pygame is None:
        import pygame as pg
        pygame = pg


class TFTDisplay(BaseDisplay):
    """Renderer for TFT/IPS displays (Tufty, Presto)."""

    def __init__(self, device, headless: bool = False):
        super().__init__(device, headless)
        self._pygame_surface = None
        self._display_surface = None   # Back buffer: only app thread writes
        self._ready_surface = None     # Front buffer: only main thread reads
        self._dirty = False
        self._render_lock = threading.Lock()
        self._clock = None
        self._sensor_panel = None

    def init(self):
        """Initialize pygame window."""
        if self.headless:
            # In headless mode, we just use PIL
            return

        _init_pygame()

        # Initialize pygame
        pygame.init()

        # Create window
        win_size = self.device.get_window_size()
        self._window = pygame.display.set_mode(win_size)
        pygame.display.set_caption(f"Pimoroni Emulator - {self.device.name}")

        # Create surface for the display content (native resolution)
        self._display_surface = pygame.Surface(
            (self.device.display_width, self.device.display_height)
        )

        self._clock = pygame.time.Clock()

        # Create sensor panel on right side of window
        SensorPanel = _get_sensor_panel_class()
        panel_width = 120
        self._sensor_panel = SensorPanel(
            x=win_size[0] - panel_width - 5,
            y=35,
            width=panel_width
        )

        if get_state().get("trace"):
            print(f"[TFTDisplay] Initialized {win_size[0]}x{win_size[1]} window")

    def render(self, buffer: List[List[int]]):
        """Render framebuffer to back buffer (called from app thread).

        Does NOT touch the pygame window. The main thread picks up the
        new frame via tick().
        """
        self._last_buffer = buffer
        self._frame_count += 1

        if self.headless:
            self._autosave_frame()
            return

        if not self._display_surface:
            return

        _init_pygame()

        # Draw buffer to back surface (only app thread touches this)
        height = len(buffer)
        width = len(buffer[0]) if height > 0 else 0

        for y in range(min(height, self.device.display_height)):
            for x in range(min(width, self.device.display_width)):
                color = buffer[y][x]
                r = (color >> 16) & 0xFF
                g = (color >> 8) & 0xFF
                b = color & 0xFF
                self._display_surface.set_at((x, y), (r, g, b))

        # Publish completed frame to front buffer
        with self._render_lock:
            self._ready_surface = self._display_surface.copy()
            self._dirty = True

        # Autosave if enabled
        self._autosave_frame()

    def _draw_window(self):
        """Draw the full emulator window (must be called from main thread)."""
        if not self._window:
            return

        # Grab front buffer snapshot
        with self._render_lock:
            surface = self._ready_surface

        if not surface:
            return

        # Clear window
        self._window.fill((30, 30, 30))

        # Get display position
        disp_rect = self.device.get_display_rect()

        # Scale display surface using nearest-neighbor (pixel-perfect, no smoothing)
        # display_scale is always an integer, ensuring pixel-perfect rendering
        scaled = pygame.transform.scale(
            surface,
            (disp_rect[2], disp_rect[3])
        )

        # Draw display with border
        border_rect = (disp_rect[0] - 2, disp_rect[1] - 2,
                       disp_rect[2] + 4, disp_rect[3] + 4)
        pygame.draw.rect(self._window, (60, 60, 60), border_rect)
        self._window.blit(scaled, (disp_rect[0], disp_rect[1]))

        # Draw status bar
        self._draw_status_bar()

        # Draw RGB LEDs if device has them
        if self.device.num_rgb_leds > 0:
            self._draw_rgb_leds()

        # Draw button indicators
        self._draw_buttons()

        # Draw buzzer indicator
        self._draw_buzzer()

        # Draw QwSTPad gamepad widget if registered
        self._draw_qwstpad()

        # Draw sensor panel if sensors are active
        if self._sensor_panel:
            self._sensor_panel.update()
            if self._sensor_panel.has_sensors():
                self._sensor_panel.render(self._window)

        # Update display
        pygame.display.flip()

        # Cap frame rate
        if self._clock:
            self._clock.tick(60)

    def _draw_status_bar(self):
        """Draw status bar at top of window."""
        font = safe_font(pygame, "monospace", 14)
        if not font:
            return

        # Device name
        text = font.render(f"{self.device.name}", True, (200, 200, 200))
        self._window.blit(text, (10, 10))

        # Frame count
        text = font.render(f"Frame: {self._frame_count}", True, (150, 150, 150))
        win_w = self.device.get_window_size()[0]
        self._window.blit(text, (win_w - 120, 10))

        # Memory bar
        mem = self._get_memory_info()
        if mem:
            draw_memory_bar(pygame, self._window, 10, 28, 150, mem[0], mem[1])

    def _draw_rgb_leds(self):
        """Draw RGB LED indicators."""
        state = get_state()
        presto = state.get("presto")

        if not presto:
            return

        leds = presto.get_leds()
        disp_rect = self.device.get_display_rect()
        center_x = disp_rect[0] + disp_rect[2] // 2
        center_y = disp_rect[1] + disp_rect[3] // 2

        for i, (r, g, b) in enumerate(leds):
            if i < len(self.device.rgb_led_positions):
                dx, dy = self.device.rgb_led_positions[i]
                # LED positions are in base coordinates, scale them with display
                scale = self.device.display_scale
                x = center_x + dx * scale
                y = center_y + dy * scale

                # Draw LED glow
                if r > 0 or g > 0 or b > 0:
                    glow_surf = pygame.Surface((30, 30), pygame.SRCALPHA)
                    pygame.draw.circle(glow_surf, (r, g, b, 100), (15, 15), 15)
                    self._window.blit(glow_surf, (x - 15, y - 15))

                # Draw LED
                pygame.draw.circle(self._window, (r, g, b), (x, y), 8)
                pygame.draw.circle(self._window, (100, 100, 100), (x, y), 8, 1)

    def _draw_buttons(self):
        """Draw button state indicators."""
        state = get_state()
        buttons = state.get("buttons", {})

        if not self.device.buttons:
            return

        win_h = self.device.get_window_size()[1]
        font = safe_font(pygame, "monospace", 12)

        x = 10
        for btn_config in self.device.buttons:
            # Check if button is pressed
            btn = buttons.get(btn_config.pin)
            pressed = btn._pressed if btn else False

            color = (100, 200, 100) if pressed else (80, 80, 80)
            pygame.draw.rect(self._window, color, (x, win_h - 30, 40, 20), border_radius=3)

            if font:
                text = font.render(btn_config.name, True, (255, 255, 255))
                text_rect = text.get_rect(center=(x + 20, win_h - 20))
                self._window.blit(text, text_rect)

            x += 50

    def _draw_buzzer(self):
        """Draw buzzer frequency indicator if active."""
        state = get_state()
        buzzer = state.get("buzzer")
        if not buzzer or buzzer._freq <= 0:
            return

        font = safe_font(pygame, "monospace", 12)
        if not font:
            return
        win_w = self.device.get_window_size()[0]

        # Draw speaker icon and frequency
        freq = buzzer._freq
        note = f"{freq}Hz"
        color = (255, 200, 50)
        text = font.render(f"♪ {note}", True, color)
        self._window.blit(text, (win_w - 120, 28))

    def get_surface(self):
        """Get pygame surface or PIL Image."""
        if self.headless:
            if self._last_buffer:
                return self._buffer_to_image(self._last_buffer)
            return None
        with self._render_lock:
            return self._ready_surface

    def tick(self):
        """Redraw window if a new frame is ready (call from main thread)."""
        if self._dirty:
            self._dirty = False
            self._draw_window()

    def refresh_ui(self):
        """Redraw the window using the last rendered frame.

        Called by the main event loop to update UI elements (sensor panel,
        buttons) without waiting for the app to call render().
        """
        if not self.headless and self._ready_surface:
            self._draw_window()

    def get_button_at(self, x: int, y: int) -> str | None:
        """Return the key name of the button indicator at (x, y), or None."""
        if not self.device.buttons:
            return None
        win_h = self.device.get_window_size()[1]
        bx = 10
        for btn_config in self.device.buttons:
            if bx <= x < bx + 40 and win_h - 30 <= y < win_h - 10:
                return btn_config.key
            bx += 50
        return None

    def _get_qwstpad_layout(self):
        """Compute QwSTPad widget button positions.

        Returns a list of (key_name, rect, label) tuples where rect is
        (x, y, w, h) in window coordinates, or None if no QwSTPad is active.
        """
        state = get_state()
        if "qwstpad" not in state:
            return None

        win_w, win_h = self.device.get_window_size()
        disp_rect = self.device.get_display_rect()

        btn_size = 28
        gap = 4
        # Position gamepad below the display area
        base_y = disp_rect[1] + disp_rect[3] + 15
        center_x = disp_rect[0] + disp_rect[2] // 2

        # Expand window if needed (store for window resize check)
        needed_h = base_y + btn_size * 3 + gap * 2 + 30
        if needed_h > win_h:
            self._qwstpad_extra_h = needed_h - win_h
        else:
            self._qwstpad_extra_h = 0

        buttons = []
        # D-pad (left cluster)
        dpad_cx = center_x - 80
        dpad_cy = base_y + btn_size + gap
        buttons.append(("up",    (dpad_cx, dpad_cy - btn_size - gap, btn_size, btn_size), "U"))
        buttons.append(("down",  (dpad_cx, dpad_cy + btn_size + gap, btn_size, btn_size), "D"))
        buttons.append(("left",  (dpad_cx - btn_size - gap, dpad_cy, btn_size, btn_size), "L"))
        buttons.append(("right", (dpad_cx + btn_size + gap, dpad_cy, btn_size, btn_size), "R"))

        # Face buttons (right cluster) - diamond layout like SNES
        face_cx = center_x + 80
        face_cy = dpad_cy
        buttons.append(("z", (face_cx, face_cy + btn_size + gap, btn_size, btn_size), "A"))
        buttons.append(("x", (face_cx + btn_size + gap, face_cy, btn_size, btn_size), "B"))
        buttons.append(("c", (face_cx, face_cy - btn_size - gap, btn_size, btn_size), "X"))
        buttons.append(("v", (face_cx - btn_size - gap, face_cy, btn_size, btn_size), "Y"))

        # +/- buttons (center)
        buttons.append(("=", (center_x + 10, dpad_cy - 5, btn_size, btn_size // 2 + 4), "+"))
        buttons.append(("-", (center_x - 10 - btn_size, dpad_cy - 5, btn_size, btn_size // 2 + 4), "-"))

        return buttons

    def _draw_qwstpad(self):
        """Draw QwSTPad gamepad widget if registered."""
        layout = self._get_qwstpad_layout()
        if not layout:
            return

        # Resize window if the gamepad doesn't fit
        extra = getattr(self, '_qwstpad_extra_h', 0)
        if extra > 0 and not getattr(self, '_qwstpad_resized', False):
            self._qwstpad_resized = True
            win_w, win_h = self._window.get_size()
            self._window = pygame.display.set_mode((win_w, win_h + extra))
            return  # will redraw next tick

        state = get_state()
        bitmask = state.get("qwstpad_buttons", 0)
        qwstpad = state.get("qwstpad")

        from emulator.mocks.qwstpad import KEY_TO_BUTTON

        font = safe_font(pygame, "monospace", 13, bold=True)

        for key_name, rect, label in layout:
            x, y, w, h = rect
            mask = KEY_TO_BUTTON.get(key_name, 0)
            pressed = bool(bitmask & mask)

            # Draw button
            if pressed:
                bg_color = (80, 200, 80)
                text_color = (0, 0, 0)
            else:
                bg_color = (70, 70, 75)
                text_color = (200, 200, 200)

            pygame.draw.rect(self._window, bg_color, (x, y, w, h), border_radius=4)
            pygame.draw.rect(self._window, (100, 100, 105), (x, y, w, h), 1, border_radius=4)

            if font:
                text = font.render(label, True, text_color)
                text_rect = text.get_rect(center=(x + w // 2, y + h // 2))
                self._window.blit(text, text_rect)

        # Draw LED indicators
        if qwstpad:
            led_states = qwstpad._led_states
            led_y = layout[0][1][1] - 20  # Above the D-pad
            win_w = self.device.get_window_size()[0]
            led_start_x = win_w // 2 - 30
            for i in range(4):
                lx = led_start_x + i * 16
                lit = bool(led_states & (1 << i))
                color = (0, 255, 100) if lit else (40, 40, 45)
                pygame.draw.circle(self._window, color, (lx + 4, led_y + 4), 5)
                pygame.draw.circle(self._window, (80, 80, 85), (lx + 4, led_y + 4), 5, 1)

    def get_qwstpad_button_at(self, x: int, y: int) -> str | None:
        """Return the key name of the QwSTPad button at (x, y), or None."""
        layout = self._get_qwstpad_layout()
        if not layout:
            return None
        for key_name, rect, _label in layout:
            bx, by, bw, bh = rect
            if bx <= x < bx + bw and by <= y < by + bh:
                return key_name
        return None

    def handle_mouse(self, x: int, y: int, pressed: bool) -> bool:
        """Handle mouse events. Returns True if event was consumed by UI."""
        if self._sensor_panel and self._sensor_panel.has_sensors():
            if self._sensor_panel.handle_mouse(x, y, pressed):
                self.refresh_ui()
                return True
        return False

    def close(self):
        """Close pygame window."""
        if not self.headless and pygame:
            pygame.quit()
