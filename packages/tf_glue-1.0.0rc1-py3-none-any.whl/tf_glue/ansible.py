from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import IO, TYPE_CHECKING, Any

if TYPE_CHECKING:
    from tf_glue.incus import Incus

_logger = logging.getLogger(__name__)


def generate_inventory(
    path: str | os.PathLike, args: dict[str, Any] = {}, incus: Incus | None = None, *, out: IO = sys.stdout
) -> str:
    """
    Generate a dynamic Ansible inventory from a YAML template.

    :params path: Path to the YAML template.
    """
    # (dependencies of extra 'template', cf. pyproject.toml)
    import yaml  # pyright: ignore[reportMissingModuleSource]
    from jinja2 import Environment, FileSystemLoader  # pyright: ignore[reportMissingImports]

    path = Path(path)

    if incus:
        if not "ansible_incus_remote" in args:
            args["ansible_incus_remote"] = incus.remote
        if not "ansible_incus_project" in args:
            args["ansible_incus_project"] = incus.project
        if not "ansible_incus_pool" in args:
            args["ansible_incus_pool"] = incus.pool
        if not "ansible_incus_network" in args:
            args["ansible_incus_network"] = incus.network

    jinja2_env = Environment(loader=FileSystemLoader(path.parent))
    inventory_template = jinja2_env.get_template("inventory.yml").render(args)
    inventory_dict = yaml.safe_load(inventory_template)

    # Move vars from all.hosts to _meta.hostvars:
    inventory_dict["_meta"] = {"hostvars": inventory_dict["all"]["hosts"]}
    inventory_dict["all"]["hosts"] = list(inventory_dict["all"]["hosts"].keys())

    # Move groups from all.children to top-level groups
    if "children" in inventory_dict["all"]:
        group_names = []
        for group_name, group_data in inventory_dict["all"]["children"].items():
            inventory_dict[group_name] = group_data
            group_names.append(group_name)
        inventory_dict["all"]["children"] = group_names

    # Replace null hostvars with empty dicts
    for host in list(inventory_dict["_meta"]["hostvars"].keys()):
        value = inventory_dict["_meta"]["hostvars"][host]
        if value is None:
            inventory_dict["_meta"]["hostvars"][host] = {}

    result = json.dumps(inventory_dict, indent=2) + "\n"
    out.write(result)
    return result


def build_incus_from_inventory(path: str | os.PathLike | None = None) -> Incus:
    """
    Build an Incus client instance from an Ansible inventory that uses the "community.general.incus" connection plugin.

    :param path: Path to the Ansible inventory file or directory. If None, the default inventory (typically configured in `ansible.cfg`) will be used.
    """
    from tf_glue.incus import Incus

    args = ["ansible-inventory", "--list"]
    if path:
        args += ["-i", path]
    _logger.debug("Run command: %s", args)
    output = subprocess.check_output(args, text=True)

    data = json.loads(output)
    remote = None
    project = None
    pool = None
    network = None
    for host, host_vars in data["_meta"]["hostvars"].items():
        if host_vars.get("ansible_connection") != "community.general.incus":
            raise ValueError("Host %r does not use the incus connection plugin" % (host,))

        host_remote = host_vars.get("ansible_incus_remote") or "local"
        if not remote:
            remote = host_remote
        elif remote != host_remote:
            raise ValueError("Host %r has a different 'ansible_incus_remote' value than previous hosts" % (host,))

        host_project = host_vars.get("ansible_incus_project") or "default"
        if not project:
            project = host_project
        elif project != host_project:
            raise ValueError("Host %r has a different 'ansible_incus_project' value than previous hosts" % (host,))

        host_pool = host_vars.get("ansible_incus_pool")
        if host_pool:
            if not pool:
                pool = host_pool
            elif pool != host_pool:
                raise ValueError("Host %r has a different 'ansible_incus_pool' value than previous hosts" % (host,))

        host_network = host_vars.get("ansible_incus_network")
        if host_network:
            if not network:
                network = host_network
            elif network != host_network:
                raise ValueError("Host %r has a different 'ansible_incus_network' value than previous hosts" % (host,))

    if not remote or not project:
        raise ValueError("No host in the Ansible inventory")

    return Incus(
        remote=remote,
        project=project,
        pool=pool,
        network=network,
    )
