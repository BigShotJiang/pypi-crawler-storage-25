from __future__ import annotations

import inspect
import logging
import logging.config
import os
import re
import subprocess
import sys
import textwrap
from argparse import ArgumentParser, RawDescriptionHelpFormatter, _HelpAction, _SubParsersAction
from typing import Any, Callable, Literal, Union, get_args, get_origin

# region Terminal


class Color:
    """
    ANSI escape sequences for terminal colors.

    Disabled (replaced by an empty string) if environment variable NO_COLOR is set to true, or if neither sys.stderr or sys.stdout are TTYs.
    """

    RESET = "\033[0m"

    BLACK = "\033[0;30m"
    RED = "\033[0;31m"
    GREEN = "\033[0;32m"
    YELLOW = "\033[0;33m"
    BLUE = "\033[0;34m"
    PURPLE = "\033[0;35m"
    CYAN = "\033[0;36m"
    WHITE = "\033[0;37m"
    GRAY = GREY = LIGHT_BLACK = "\033[0;90m"
    BG_RED = "\033[0;41m"

    # Disable coloring if environment variable NO_COLOR is set to 1 or if stderr is piped/redirected
    NO_COLOR = False
    if os.environ.get("NO_COLOR", "").lower() in {"1", "true", "yes", "on"} or not (
        sys.stdout.isatty() or sys.stderr.isatty()
    ):
        NO_COLOR = True
        for _ in dir():
            if isinstance(_, str) and _[0] != "_" and _ not in ["NO_COLOR"]:
                locals()[_] = ""

    # Set Windows console in VT mode
    if not NO_COLOR and sys.platform == "win32":
        import ctypes

        _kernel32 = ctypes.windll.kernel32
        _kernel32.SetConsoleMode(_kernel32.GetStdHandle(-11), 7)
        del _kernel32


# endregion

# region Logging


def configure_logging(
    *,
    level: str | int = "INFO",
    color: bool = True,
    name: bool = False,
):
    level = os.environ.get("LOG_LEVEL", "").upper() or level
    if isinstance(level, int):
        level = logging.getLevelName(level)

    if not sys.stderr.isatty() or Color.NO_COLOR:
        color = False
    else:
        value = os.environ.get("LOG_COLOR", "").lower()
        if value in {"0", "false", "no", "off"}:
            color = False
        elif value in {"1", "true", "yes", "on"}:
            color = True

    value = os.environ.get("LOG_NAME", "").lower()
    if value in {"0", "false", "no", "off"}:
        name = False
    elif value in {"1", "true", "yes", "on"}:
        name = True

    console_formatter = {}
    if color:
        console_formatter["()"] = ColoredFormatter.__module__ + "." + ColoredFormatter.__qualname__
        if name:
            format = "%(log_color)s%(levelname)-8s%(reset)s %(light_black)s[%(name)s]%(reset)s %(message)s"
        else:
            format = "%(log_color)s%(levelname)-8s%(reset)s %(message)s"
    else:
        if name:
            format = "%(levelname)s [%(name)s] %(message)s"
        else:
            format = "%(levelname)-8s %(message)s"
    console_formatter["format"] = format

    config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "console": console_formatter,
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "formatter": "console",
                "level": level,
            },
        },
        "root": {
            "handlers": ["console"],
            "level": level,
        },
    }
    logging.config.dictConfig(config)


class ColoredRecord:
    LOG_COLORS = {
        logging.DEBUG: Color.GRAY,
        logging.INFO: Color.CYAN,
        logging.WARNING: Color.YELLOW,
        logging.ERROR: Color.RED,
        logging.CRITICAL: Color.BG_RED,
    }

    def __init__(self, record: logging.LogRecord):
        # The internal dict is used by Python logging library when formatting the message.
        # (inspired from library "colorlog").
        self.__dict__.update(record.__dict__)

        self.log_color = self.LOG_COLORS.get(record.levelno, "")

        for attname, value in Color.__dict__.items():
            if attname == "NO_COLOR" or attname.startswith("_"):
                continue
            setattr(self, attname.lower(), value)


class ColoredFormatter(logging.Formatter):
    def formatMessage(self, record: logging.LogRecord) -> str:
        """Format a message from a record object."""
        wrapper = ColoredRecord(record)
        message = super().formatMessage(wrapper)  # type: ignore
        return message


# endregion

# region Errors


class SimpleError(RuntimeError):
    """
    An simple error message expected to be printed on the console without a stack trace.
    """


class InvalidContent(RuntimeError):
    pass


class DetailedCalledProcessError(subprocess.CalledProcessError):
    def __str__(self):
        message = super().__str__()
        stderr = self.stderr.strip() if self.stderr else ""
        if stderr:
            message += f"\n[stderr] {stderr}"
        stdout = self.stdout.strip() if self.stdout else ""
        if stdout:
            message += f"\n[stdout] {stdout}"
        return message


# endregion

# region Commands

HELP_HELP = "Show this help message and exit."
VERSION_HELP = "Show program's version number and exit."


def add_command(
    subparsers: _SubParsersAction[ArgumentParser],
    handle: Callable,
    *,
    name: str | None = None,
    add_arguments: Callable[[ArgumentParser], Any] | None = None,
    **defaults,
):
    if not name:
        name = handle.__name__.replace("_", "-")

    if add_arguments is None:
        add_arguments = getattr(handle, "add_arguments", None)

    help, description, epilog, param_helps = parse_doc(handle.__doc__)

    cmdparser = subparsers.add_parser(
        name, help=help, description=description, epilog=epilog, formatter_class=RawDescriptionHelpFormatter
    )

    if add_arguments is not None:
        setattr(cmdparser, "param_helps", param_helps)
        add_arguments(cmdparser)
    else:
        for param in inspect.signature(handle, eval_str=True).parameters.values():
            if param.name in defaults or param.name in {"self", "cls"}:
                continue

            if param.kind in (param.VAR_POSITIONAL, param.VAR_KEYWORD):
                raise ValueError("Unsupported parameter kind for command handler: %r" % (param.kind,))

            arg_name = param.name.replace("_", "-")
            arg_help = param_helps.get(param.name, "")

            if m := re.match(r"^\[(\-[a-z])\](.+)", arg_help):
                name_or_flags = [m[1]]
                arg_help = m[2].strip()
            else:
                name_or_flags = []

            arg_type = get_argument_type(param)

            if param.default is False and arg_type == bool:
                # boolean option
                name_or_flags.append("--" + arg_name)
                cmdparser.add_argument(*name_or_flags, action="store_true", default=False, help=arg_help)
            elif param.kind == param.KEYWORD_ONLY or name_or_flags:
                # option
                if param.default is not param.empty:
                    default = param.default
                else:
                    default = None

                name_or_flags.append("--" + arg_name)
                cmdparser.add_argument(*name_or_flags, type=arg_type, default=default, help=arg_help)
            else:
                # positional argument
                if param.default is not param.empty:
                    nargs = "?"
                    default = param.default
                else:
                    nargs = None
                    default = None

                name_or_flags.append(arg_name)
                cmdparser.add_argument(*name_or_flags, nargs=nargs, type=arg_type, default=default, help=arg_help)

    cmdparser.set_defaults(handle=handle, **defaults)

    # Uniformize --help character case with the rest of the program.
    for action in cmdparser._actions:
        if isinstance(action, _HelpAction):
            if action.help == "show this help message and exit":
                action.help = HELP_HELP

    return cmdparser


def get_argument_type(param: inspect.Parameter) -> type:
    if param.annotation is bool or (param.annotation is param.empty and param.default is False):
        return bool

    if param.annotation is param.empty:
        return str

    # Handle "Optional" (Union with NoneType)
    origin = get_origin(param.annotation)
    args = get_args(param.annotation)

    if origin is Union:
        base_type = args[0]
    else:
        base_type = param.annotation

    # Handle "Literal"
    origin = get_origin(base_type)
    args = get_args(base_type)

    if origin is Literal:
        first_type = type(args[0])
        if all(isinstance(v, first_type) for v in args):
            return first_type

    # Handle general case
    if isinstance(base_type, type):
        return base_type

    return str


def parse_doc(doc: str | None) -> tuple[str | None, str | None, str | None, dict[str, str]]:
    """
    Parse a function or module docstring into a `help, description, epilog, param_helps` tuple.

    :return: Tuple (help, description, epilog, param_helps).
    """
    if doc is None:
        return None, None, None, {}

    param_regex = re.compile(r"^\s*:param (?P<dest>[a-zA_Z0-9]+):\s*(?P<help>[^\s].*)$")
    help = None
    description = None
    epilog = None
    param_helps: dict[str, str] = {}
    param_pos = None
    for line in doc.splitlines():
        line_stripped = line.strip()

        if epilog is not None:
            epilog += "\n" + line
            continue

        m = param_regex.match(line)
        if m:
            param_helps[m["dest"]] = m["help"].strip() or ""
            param_pos = line.index(":param")

        elif param_pos is not None:
            if line_stripped == "" or line.find(line_stripped) > param_pos:
                # This is the continuation of the previous param help (we ignore it as we assume they are details)
                continue
            else:
                # This is the beginning of the epilog
                epilog = line

        else:
            if help is None and line_stripped:
                help = line_stripped

            if line_stripped or description is not None:
                description = (f"{description}\n" if description else "") + line

    if description is not None:
        description = textwrap.dedent(description)

    if epilog is not None:
        epilog = textwrap.dedent(epilog)

    return help, description, epilog, param_helps


def get_exit_code(code: Any) -> int:
    if isinstance(code, int):
        return code
    elif isinstance(code, bool):
        return 0 if code is True else 1
    else:
        return 0


# endregion

# region Network

_unset = object()
_proxy_url: str | None = _unset  # pyright: ignore[reportAssignmentType]


def get_proxy_url() -> str | None:
    global _proxy_url

    if _proxy_url is _unset:
        for key in ["HTTPS_PROXY", "HTTP_PROXY", "https_proxy", "http_proxy"]:
            if key in os.environ:
                value = os.environ.get(key)
                if value:
                    _proxy_url = value
                    break

        if _proxy_url is _unset:
            _proxy_url = None
            # ROADMAP: Use WPAD

    return _proxy_url


# endregion
