from __future__ import annotations

import logging
import os
import re
import subprocess
from functools import cached_property
from pathlib import Path
from shutil import which
from typing import TYPE_CHECKING, Any, Literal, Sequence

from tf_glue.utils import InvalidContent, get_proxy_url

if TYPE_CHECKING:
    from tf_glue.incus import BucketInfo, Incus

default_tfvars_filename = "variables.auto.tfvars"
default_tfbackend_filename = "backend.tfbackend"

_logger = logging.getLogger(__name__)
_lock_filename = ".terraform.lock.hcl"


def init_tf(
    dir: str | os.PathLike | None = None,
    *,
    incus: "Incus | None" = None,
    bucket: "BucketInfo | str | bool | None" = None,
    fix=False,
) -> int:
    """
    Initialize OpenTofu.

    :param incus: Create "variables.auto.tfvars" (if it does not already exist) to configure access to the given Incus client.
    :param bucket: [-b] Create "backend.tfbackend" (if it does not already exist) to configure access to the given Incus S3 bucket. The bucket is created if it does not exist.
    :param fix: [-f] Fix tfvars and tfbackend file if they do not match the expected content.
    """
    if not dir:
        dir = Path.cwd()
    else:
        dir = Path(dir)

    if incus:
        declared_vars = list_declared_vars(dir)

        tfvars = {}
        if "incus_remote" in declared_vars:
            tfvars["incus_remote"] = incus.remote
        if "incus_project" in declared_vars:
            tfvars["incus_project"] = incus.project
        if "incus_pool" in declared_vars:
            tfvars["incus_pool"] = incus.pool
        if "incus_network" in declared_vars:
            tfvars["incus_network"] = incus.network

        if tfvars:
            try:
                write_tfvars(tfvars, dir, verify="fix" if fix else True)
            except InvalidContent as err:
                _logger.error(err)

    if bucket is None:
        pass  # ROADMAP: detect if "default_tfbackend_filename" exists and/or if backend is configured to be S3

    if bucket:
        from tf_glue.incus import BucketInfo

        if not incus:
            raise ValueError("Argument 'bucket' cannot be used without argument 'incus'")

        if bucket is True:
            bucket = dir.name
        if isinstance(bucket, BucketInfo):
            if bucket.s3_endpoint != incus.s3_endpoint:
                raise ValueError(
                    "Invalid S3 endpoint for bucket: %s (expected Incus S3 endpoint: %s)"
                    % (bucket.s3_endpoint, incus.s3_endpoint)
                )
            bucket = incus.bucket(bucket.name)
        else:
            bucket = incus.bucket(bucket, create=True)

        try:
            write_tfbackend(bucket, dir, verify="fix" if fix else True)
        except InvalidContent as err:
            _logger.error(err)

    # Run tofu init if necessary
    if dir.joinpath(_lock_filename).exists():
        _logger.info("OpenTofu is already initialized")
        return 0

    if proxy_url := get_proxy_url():
        env = {**os.environ, "HTTPS_PROXY": proxy_url}
    else:
        env = os.environ

    _logger.info("Initialize OpenTofu")
    cmd = [get_tf_exe(), f"-chdir={dir}", "init"]
    if bucket or dir.joinpath(default_tfbackend_filename).exists():
        cmd.append(f"-backend-config={default_tfbackend_filename}")
    _logger.debug("Run command: %s", cmd)
    cp = subprocess.run(cmd, env=env)
    return cp.returncode


_unset = object()
_tf_exe: str | None = _unset  # pyright: ignore[reportAssignmentType]


def get_tf_exe() -> str:
    global _tf_exe
    if _tf_exe is _unset:
        _tf_exe = which("tofu") or which("terraform")
    if _tf_exe is None:
        raise FileNotFoundError("No 'tofu' or 'terraform' executable found")
    return _tf_exe


def list_declared_vars(paths: Sequence[str | os.PathLike] | str | os.PathLike | None = None) -> list[str]:
    if not paths:
        paths = [Path.cwd()]
    elif not isinstance(paths, Sequence):
        paths = [paths]

    files: list[Path] = []
    for path in paths:
        path = Path(path)
        if path.is_dir():
            for file in sorted(path.iterdir()):
                if file.name.endswith(".tf") and file.is_file():
                    files.append(file)
        else:
            files.append(path)

    results = []
    for file in files:
        text = file.read_text(encoding="utf-8")
        for line in text.splitlines():
            if m := re.match(r'^\s*variable\s+"([^"]+)"', line):
                name = m[1]
                if name not in results:
                    results.append(name)

    return results


def get_tfvars_path(file: str | os.PathLike | None = None) -> Path:
    if not file:
        file = Path.cwd().joinpath(default_tfvars_filename)
    else:
        file = Path(file)
        if file.is_dir():
            file = file.joinpath(default_tfvars_filename)
    return file


def get_tfbackend_path(file: str | os.PathLike | None = None) -> Path:
    if not file:
        file = Path.cwd().joinpath(default_tfbackend_filename)
    else:
        file = Path(file)
        if file.is_dir():
            file = file.joinpath(default_tfbackend_filename)
    return file


def read_tfvars(file: str | os.PathLike | None = None) -> dict[str, Any]:
    file = get_tfvars_path(file)

    results = {}

    _logger.debug("Read tfvars file: %s", file)
    with open(file) as f:
        for line_num, line in enumerate(f, start=1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if not (m := re.match(r"^([^=]+)=(.*)$", line)):
                _logger.warning(f"Ignore invalid line {line_num} in tfvars: {line}")
                continue

            key = m[1].strip()
            value = m[2].strip()
            results[key] = parse_tfvar(value)

    return results


def write_tfvars(
    tfvars: dict[str, Any], file: str | os.PathLike | None = None, *, verify: bool | Literal["fix"] = False
):
    file = get_tfvars_path(file)

    if file.exists():
        if not verify:
            raise FileExistsError("File already exists: %s" % file)

        existing_tfvars = read_tfvars(file)

        differences = ""
        for key, value in tfvars.items():
            existing_value = existing_tfvars.get(key)
            if existing_value != value:
                differences += ("\n" if differences else "") + f"- {key}: {existing_value} (expected {value})"

        if not differences:
            _logger.debug("Verified tfvars file: %s", file)
            return

        if verify == "fix":
            _logger.info("Remove invalid tfvars file: %s", file)
            for key, value in existing_tfvars.items():
                if not key in tfvars:
                    tfvars[key] = value
            file.unlink()
        else:
            raise InvalidContent("Existing tfvars file (%s) does not match expected content:\n%s" % (file, differences))

    _logger.info("Create tfvars file: %s", file)
    file.parent.mkdir(parents=True, exist_ok=True)
    with open(file, "w") as f:
        for key, value in tfvars.items():
            print(f"{key} = {escape_tfvar(value)}", file=f)


def write_tfbackend(
    bucket: BucketInfo, file: str | os.PathLike | None = None, *, verify: bool | Literal["fix"] = False
):
    file = get_tfbackend_path(file)

    content = ""
    content += f"bucket                      = {escape_tfvar(bucket.name)}\n"
    content += f"key                         = {escape_tfvar('tfstate')}\n"
    content += f'region                      = "local"\n'
    content += f"endpoints                   = {{ s3 = {escape_tfvar(bucket.s3_endpoint)} }}\n"
    content += f"\n"
    content += f"access_key                  = {escape_tfvar(bucket.access_key)}\n"
    content += f"secret_key                  = {escape_tfvar(bucket.secret_key)}\n"
    content += f"\n"
    content += f"insecure                    = true\n"
    content += f"skip_credentials_validation = true\n"
    content += f"skip_region_validation      = true\n"
    content += f"skip_metadata_api_check     = true\n"
    content += f"use_path_style              = true\n"

    if file.exists():
        if not verify:
            raise FileExistsError("File already exists: %s" % file)

        actual_content = file.read_text()
        if actual_content == content:
            _logger.debug("Verified tfbackend file: %s", file)
            return

        if verify == "fix":
            _logger.info("Remove invalid tfbackend file: %s", file)
            file.unlink()
        else:
            raise InvalidContent("Existing tfbackend file (%s) does not match expected content:\n%s" % (file, content))

    _logger.info("Create tfbackend file: %s", file)
    file.parent.mkdir(parents=True, exist_ok=True)
    with open(file, "w") as f:
        f.write(content)


def parse_tfvar(value: str) -> Any:
    if value == "false":
        return False
    elif value == "true":
        return True
    elif re.match(r"^\d+$", value):
        return int(value)
    elif re.match(r"^\d+\.\d+$", value):
        return float(value)
    elif m := re.match(r'^"(.*)"$', value):
        return m[1].replace('\\"', '"').replace("\\n", "\n").replace("\\t", "\t").replace("\\\\", "\\")
    else:
        return value


def escape_tfvar(value: Any) -> str:
    if isinstance(value, bool):
        return str(value).lower()
    elif isinstance(value, (int, float)):
        return str(value)
    else:
        return (
            '"' + str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\t", "\\t") + '"'
        )
