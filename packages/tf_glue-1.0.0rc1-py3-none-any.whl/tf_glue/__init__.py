"""
Orchestrate OpenTofu (or Terraform) initialization and interactions with Ansible and Incus (including Incus S3 bucket as state backend).
"""

from __future__ import annotations

__prog__ = "tf-glue"

__version__: str
__version_tuple__: tuple
try:
    from tf_glue._version import __version__, __version_tuple__  # pyright: ignore[reportMissingImports]
except ModuleNotFoundError:
    __version__ = ""
    __version_tuple__ = ()
