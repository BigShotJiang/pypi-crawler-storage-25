from __future__ import annotations

import logging
import sys
import textwrap
from argparse import ArgumentParser, RawDescriptionHelpFormatter
from pathlib import Path
from typing import Any

from tf_glue import __doc__, __prog__, __version__
from tf_glue.incus import Incus
from tf_glue.tofu import init_tf
from tf_glue.utils import HELP_HELP, VERSION_HELP, SimpleError, add_command, configure_logging, get_exit_code


def main():
    configure_logging()
    logger = logging.getLogger(__name__)

    parser = ArgumentParser(
        __prog__,
        description=textwrap.dedent(__doc__ or ""),
        formatter_class=RawDescriptionHelpFormatter,
        add_help=False,
    )
    parser.add_argument("-h", "--help", action="help", help=HELP_HELP)
    parser.add_argument("--version", action="version", version=__version__, help=VERSION_HELP)
    parser.add_argument("-C", "--chdir", dest="cwd", metavar="DIR", help="Change to directory DIR.")

    subparsers = parser.add_subparsers(title="commands")
    add_command(subparsers, init_tf, name="init", incus="__incus__", dir="__cwd__")
    add_command(subparsers, Incus.print, name="incus", __self__="__incus__", out=sys.stdout)
    add_command(subparsers, Incus.bucket, name="bucket", __self__="__incus__", out=sys.stdout)
    add_command(subparsers, Incus.address, name="address", __self__="__incus__", out=sys.stdout)

    kwargs = vars(parser.parse_args())

    handle = kwargs.pop("handle", None)
    if handle is None:
        parser.print_help()
        exit(0)

    cwd = kwargs.pop("cwd") or Path.cwd()

    if __self__ := kwargs.pop("__self__", None):
        kwargs["self"] = __self__

    update_kwargs(kwargs, "__cwd__", cwd)

    if key := get_kwargs_key(kwargs, "__incus__"):
        kwargs[key] = Incus(cwd=cwd)

    try:
        r = get_exit_code(handle(**kwargs))
        logger.debug("Exit with return code %d", r)
    except SimpleError as err:
        logger.error(str(err))
        r = 1
    except KeyboardInterrupt:
        logger.error("Exit on keyboard interrupt")
        r = 1
    except BaseException as err:
        message = str(err)
        logger.exception(f"Exit on {type(err).__name__}{f': {message}' if message else ''}")
        r = 1

    exit(r)


def update_kwargs(kwargs: dict, placeholder: str, value: Any):
    for key, val in kwargs.items():
        if val == placeholder:
            kwargs[key] = value


def get_kwargs_key(kwargs: dict, placeholder: str) -> str | None:
    for key in ["self", placeholder.strip("_")]:
        if kwargs.get(key) == placeholder:
            return key

    # Not found
    return None


if __name__ == "__main__":
    main()
