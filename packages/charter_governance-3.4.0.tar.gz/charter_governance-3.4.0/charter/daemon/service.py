"""Charter daemon service.

Runs as a background process that:
1. Periodically scans for AI tools on the machine
2. Logs detected tools to the hash chain
3. Serves the web dashboard on localhost
4. Can be installed as a system service (launchd/systemd)
5. Runs scheduled audits per Layer C frequency
6. Dispatches alerts on governance events
7. Applies chain retention policy after audits
"""

import json
import os
import platform
import shutil
import sys
import threading
import time

from charter.config import load_config
from charter.daemon.detector import detect_ai_tools, get_summary
from charter.identity import load_identity, append_to_chain, get_chain_path
from charter.alerting import AlertDispatcher, load_alerting_config
from charter.audit import (
    generate_audit_report,
    is_audit_overdue,
    FREQUENCY_SECONDS,
)
from charter.retention import apply_retention_policy

DEFAULT_PORT = 8374
SCAN_INTERVAL = 60
AUDIT_CHECK_INTERVAL = 300  # check every 5 minutes
SESSION_WATCHDOG_INTERVAL = 120  # check every 2 minutes


class CharterDaemon:
    """Main daemon process. Combines detection loop with web server."""

    def __init__(self, port=DEFAULT_PORT, scan_interval=SCAN_INTERVAL,
                 config=None):
        self.port = port
        self.scan_interval = scan_interval
        self.running = False
        self._detection_log = []
        self._last_scan = None
        self._lock = threading.Lock()

        # Load config and alerting dispatcher
        self._config = config or load_config() or {}
        alerting_cfg = load_alerting_config(self._config)
        self._dispatcher = AlertDispatcher(alerting_cfg)

        # Parse audit frequency from Layer C config
        gov = self._config.get("governance", {})
        layer_c = gov.get("layer_c", {})
        freq_label = layer_c.get("frequency", "weekly")
        self._audit_interval = FREQUENCY_SECONDS.get(freq_label, 604800)
        self._audit_freq_label = freq_label

    def start(self):
        """Start the daemon. Blocks until stopped."""
        self.running = True

        detector = threading.Thread(
            target=self._detection_loop, daemon=True,
        )
        detector.start()

        auditor = threading.Thread(
            target=self._audit_loop, daemon=True,
        )
        auditor.start()

        watchdog = threading.Thread(
            target=self._session_watchdog, daemon=True,
        )
        watchdog.start()

        self._start_web()

    def stop(self):
        """Signal the daemon to stop."""
        self.running = False

    def get_status(self):
        """Get current daemon state (thread-safe)."""
        with self._lock:
            return {
                "running": self.running,
                "port": self.port,
                "last_scan": self._last_scan,
                "detection_log": list(self._detection_log),
                "total_detected": len(self._detection_log),
                "audit_frequency": self._audit_freq_label,
            }

    def _detection_loop(self):
        """Background thread: scan for AI tools on interval."""
        while self.running:
            try:
                tools = detect_ai_tools()
                now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

                with self._lock:
                    self._last_scan = {
                        "tools": tools,
                        "scanned_at": now,
                    }

                    for tool in tools:
                        already_logged = any(
                            d["tool_id"] == tool["tool_id"]
                            for d in self._detection_log
                        )
                        if not already_logged:
                            self._detection_log.append(tool)
                            try:
                                append_to_chain("ai_tool_detected", {
                                    "tool": tool["name"],
                                    "vendor": tool["vendor"],
                                    "governable": tool["governable"],
                                }, actor="ai")
                            except Exception:
                                pass

                            # Alert on ungoverned AI tools
                            if not tool.get("governable"):
                                try:
                                    self._dispatcher.dispatch(
                                        "ai_tool_ungoverned",
                                        {
                                            "tool": tool["name"],
                                            "vendor": tool["vendor"],
                                            "detected_at": now,
                                        },
                                    )
                                except Exception:
                                    pass
            except Exception:
                pass

            time.sleep(self.scan_interval)

    def _audit_loop(self):
        """Background thread: run scheduled audits per Layer C frequency."""
        while self.running:
            try:
                if is_audit_overdue(self._config):
                    result = generate_audit_report(config=self._config)
                    if result and result.get("report"):
                        # Dispatch audit_generated alert
                        try:
                            self._dispatcher.dispatch("audit_generated", {
                                "chain_intact": result["chain_intact"],
                                "chain_entries": result["chain_entries"],
                                "report_path": result["report_path"],
                            })
                        except Exception:
                            pass

                        # Alert on chain integrity failure
                        if not result["chain_intact"]:
                            try:
                                self._dispatcher.dispatch(
                                    "chain_integrity_failure",
                                    {
                                        "chain_entries": result["chain_entries"],
                                        "report_path": result["report_path"],
                                    },
                                )
                            except Exception:
                                pass

                    # Apply retention policy after audit
                    try:
                        apply_retention_policy(self._config)
                    except Exception:
                        pass
            except Exception:
                pass

            time.sleep(AUDIT_CHECK_INTERVAL)

    def _session_watchdog(self):
        """v3.1.1 Layer 0 enforcement: detect work without hashing.

        Checks whether AI tools are running but no chain entries
        have been created recently. If a gap is detected, logs a
        chain_gap_detected event — the gap itself becomes evidence.
        """
        chain_path = get_chain_path()
        last_known_count = 0
        if os.path.isfile(chain_path):
            with open(chain_path) as f:
                last_known_count = sum(
                    1 for line in f if line.strip()
                )

        while self.running:
            try:
                # Check if AI tools are active
                tools = detect_ai_tools()
                ai_active = len(tools) > 0

                # Check chain growth
                current_count = 0
                if os.path.isfile(chain_path):
                    with open(chain_path) as f:
                        current_count = sum(
                            1 for line in f if line.strip()
                        )

                chain_grew = current_count > last_known_count

                if ai_active and not chain_grew:
                    # AI tools running but chain is silent
                    try:
                        append_to_chain(
                            "chain_gap_detected",
                            {
                                "active_tools": len(tools),
                                "chain_entries": current_count,
                                "invariant": (
                                    "Layer 0 #8: Chain gaps "
                                    "during active sessions "
                                    "are violations"
                                ),
                            },
                            actor="ai",
                        )
                        # Alert on gap
                        try:
                            self._dispatcher.dispatch(
                                "chain_gap_detected",
                                {
                                    "tools": len(tools),
                                    "entries": current_count,
                                },
                            )
                        except Exception:
                            pass
                    except Exception:
                        pass

                last_known_count = current_count
            except Exception:
                pass

            time.sleep(SESSION_WATCHDOG_INTERVAL)

    def _start_web(self):
        """Start the Flask web server."""
        try:
            from charter.web.app import create_app
            app = create_app(self)
            app.run(host="127.0.0.1", port=self.port, debug=False)
        except ImportError:
            print(
                "Flask not installed. Install with: "
                "pip install charter-governance[daemon]"
            )
            print("Daemon running without web UI. Detection loop active.")
            try:
                while self.running:
                    time.sleep(1)
            except KeyboardInterrupt:
                self.stop()


def run_serve(args):
    """CLI entry point for charter serve."""
    from charter import __version__

    port = getattr(args, "port", DEFAULT_PORT) or DEFAULT_PORT
    interval = getattr(args, "interval", SCAN_INTERVAL) or SCAN_INTERVAL

    identity = load_identity()
    if not identity:
        print("No identity found. Run 'charter init' first.")
        return

    config = load_config()
    daemon = CharterDaemon(port=port, scan_interval=interval, config=config)

    # Retention status
    retention_cfg = (config or {}).get("retention")
    retention_status = "enabled" if retention_cfg else "disabled"

    print(f"Charter Daemon v{__version__}")
    print(f"  Dashboard:  http://127.0.0.1:{port}")
    print(f"  Detection:  every {interval}s")
    print(f"  Audit:      {daemon._audit_freq_label} (check every {AUDIT_CHECK_INTERVAL}s)")
    print(f"  Retention:  {retention_status}")
    print(f"  Identity:   {identity['alias']} ({identity['public_id'][:16]}...)")
    print()
    print("Press Ctrl+C to stop.")
    print()

    try:
        append_to_chain("daemon_started", {
            "port": port,
            "scan_interval": interval,
            "audit_frequency": daemon._audit_freq_label,
            "retention": retention_status,
        }, actor="ai")
    except Exception:
        pass

    try:
        daemon.start()
    except KeyboardInterrupt:
        daemon.stop()
        try:
            append_to_chain("daemon_stopped", {}, actor="ai")
        except Exception:
            pass
        print("\nDaemon stopped.")


def run_detect(args):
    """CLI entry point for charter detect (one-shot scan)."""
    summary = get_summary()

    if not summary["tools"]:
        print("No AI tools detected on this machine.")
        return

    print(f"AI Tools Detected: {summary['total']}")
    print(f"  Governed:   {summary['governed']}")
    print(f"  Ungoverned: {summary['ungoverned']}")
    print()

    for tool in summary["tools"]:
        status = "GOVERNED" if tool["governable"] else "DETECTED"
        print(f"  [{status}] {tool['name']} ({tool['vendor']})")
        print(f"           PID: {tool['pid']}, Process: {tool['process_name']}")

    print(f"\nScanned at: {summary['scanned_at']}")


def run_install(args):
    """CLI entry point for charter install (system service)."""
    system = platform.system()

    if system == "Darwin":
        path = _install_launchd()
        if path:
            print(f"launchd plist written to: {path}")
            print()
            print("To start the service:")
            print(f"  launchctl load {path}")
            print()
            print("To stop the service:")
            print(f"  launchctl unload {path}")

    elif system == "Linux":
        path = _install_systemd()
        if path:
            print(f"systemd unit written to: {path}")
            print()
            print("To start the service:")
            print("  systemctl --user enable charter-daemon")
            print("  systemctl --user start charter-daemon")
            print()
            print("To stop the service:")
            print("  systemctl --user stop charter-daemon")

    else:
        print(f"Service installation not yet supported on {system}.")
        print("Run 'charter serve' manually instead.")


def _install_launchd():
    """Write macOS launchd plist."""
    charter_path = shutil.which("charter") or "/usr/local/bin/charter"

    plist = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" \
"http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>org.charter.daemon</string>
    <key>ProgramArguments</key>
    <array>
        <string>{charter_path}</string>
        <string>serve</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>/tmp/charter-daemon.log</string>
    <key>StandardErrorPath</key>
    <string>/tmp/charter-daemon.err</string>
</dict>
</plist>
"""

    plist_dir = os.path.expanduser("~/Library/LaunchAgents")
    os.makedirs(plist_dir, exist_ok=True)
    plist_path = os.path.join(plist_dir, "org.charter.daemon.plist")

    with open(plist_path, "w") as f:
        f.write(plist)

    return plist_path


def _install_systemd():
    """Write Linux systemd user unit file."""
    charter_path = shutil.which("charter") or "/usr/local/bin/charter"

    unit = f"""[Unit]
Description=Charter Governance Daemon
After=network.target

[Service]
ExecStart={charter_path} serve
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
"""

    unit_dir = os.path.expanduser("~/.config/systemd/user")
    os.makedirs(unit_dir, exist_ok=True)
    unit_path = os.path.join(unit_dir, "charter-daemon.service")

    with open(unit_path, "w") as f:
        f.write(unit)

    return unit_path
