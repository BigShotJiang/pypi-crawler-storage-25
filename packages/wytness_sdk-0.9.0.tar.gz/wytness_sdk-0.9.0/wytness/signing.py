from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey, Ed25519PublicKey
)
from cryptography.hazmat.primitives.serialization import (
    Encoding, PublicFormat, PrivateFormat, NoEncryption,
    load_pem_private_key, load_pem_public_key
)
from cryptography.exceptions import InvalidSignature
import base64, json
from pathlib import Path


def generate_keypair():
    private_key = Ed25519PrivateKey.generate()
    return private_key, private_key.public_key()


def save_private_key(key, path):
    pem = key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption())
    Path(path).write_bytes(pem)


def load_private_key(path):
    pem = Path(path).read_bytes()
    return load_pem_private_key(pem, password=None)


def load_private_key_from_base64(b64_string):
    """Load an Ed25519 private key from base64, auto-detecting format.

    Accepted formats:
      - base64(PEM text)          — Python SDK default (double-encoded)
      - base64(PKCS8 DER)        — 48+ bytes, ASN.1 SEQUENCE
      - base64(64-byte NaCl key) — TS SDK default (seed ∥ public)
      - base64(32-byte seed)     — raw Ed25519 seed
    """
    raw = base64.b64decode(b64_string)
    if len(raw) == 32:
        return Ed25519PrivateKey.from_private_bytes(raw)
    if len(raw) == 64:
        # NaCl secretKey = seed (first 32 bytes) ∥ public key (last 32 bytes)
        return Ed25519PrivateKey.from_private_bytes(raw[:32])
    if raw[:5] == b'-----':
        # base64(PEM text) — the original Python SDK format
        return load_pem_private_key(raw, password=None)
    if len(raw) >= 48 and raw[0] == 0x30:
        # PKCS8 DER — load directly
        from cryptography.hazmat.primitives.serialization import load_der_private_key
        return load_der_private_key(raw, password=None)
    raise ValueError(
        f"Unrecognised signing key format. Expected PEM, PKCS8 DER, "
        f"64-byte NaCl secretKey, or 32-byte seed. Got {len(raw)} bytes."
    )


def sign_event(event_dict, private_key):
    payload = {k: v for k, v in event_dict.items() if k != "signature"}
    message = json.dumps(payload, sort_keys=True, default=str).encode("utf-8")
    return base64.b64encode(private_key.sign(message)).decode("utf-8")


def verify_event(event_dict, public_key):
    sig_b64 = event_dict.get("signature", "")
    if not sig_b64:
        return False
    payload = {k: v for k, v in event_dict.items() if k != "signature"}
    message = json.dumps(payload, sort_keys=True, default=str).encode("utf-8")
    try:
        public_key.verify(base64.b64decode(sig_b64), message)
        return True
    except Exception:
        return False
