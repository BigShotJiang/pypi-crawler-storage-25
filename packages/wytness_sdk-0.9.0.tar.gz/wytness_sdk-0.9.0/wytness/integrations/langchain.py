"""Wytness integration for LangChain.

Automatically captures prompts and tool calls from LangChain agents.

Usage:
    from wytness import AuditClient
    from wytness.integrations.langchain import WytnessCallbackHandler

    client = AuditClient(agent_id="my-agent", http_api_key="wyt_api_live_...")
    handler = WytnessCallbackHandler(client)

    agent.invoke({"input": "..."}, config={"callbacks": [handler]})
"""

try:
    from langchain_core.callbacks.base import BaseCallbackHandler
except ImportError:
    raise ImportError(
        "langchain-core is required for the LangChain integration. "
        "Install it with: pip install wytness-sdk[langchain]"
    )

import logging
import time
from typing import Any
from uuid import UUID

from ..decorator import AuditClient, _sanitise, hash_value, _redact_pii, RESPONSE_MAX_CHARS
from ..models import AuditEvent

logger = logging.getLogger(__name__)


def _extract_prompt(inputs: Any) -> str:
    """Extract the user prompt from chain inputs."""
    if isinstance(inputs, str):
        return inputs[:2000]
    if isinstance(inputs, dict):
        for key in ("input", "question", "query", "human_input"):
            if key in inputs and isinstance(inputs[key], str):
                return inputs[key][:2000]
        # Fall back to first string value
        for v in inputs.values():
            if isinstance(v, str) and len(v) > 0:
                return v[:2000]
    return ""


class WytnessCallbackHandler(BaseCallbackHandler):
    """LangChain callback handler that records audit events to Wytness.

    Captures the user prompt (from on_chain_start) and correlates it with
    subsequent tool calls (on_tool_start/on_tool_end). Every method is
    wrapped in try/except — this handler will never crash your agent.
    """

    def __init__(self, client: AuditClient, task_id: str = "default"):
        self._client = client
        self._task_id = task_id
        # run_id -> prompt string
        self._prompts: dict[str, str] = {}
        # run_id -> parent_run_id (for walking nested chains)
        self._parents: dict[str, str] = {}
        # run_id -> (tool_name, tool_params_str, start_time)
        self._tool_runs: dict[str, tuple[str, str, float]] = {}

    def _resolve_prompt(self, run_id: str, parent_run_id: str | None) -> str:
        """Walk up the parent chain to find the originating prompt."""
        current = str(parent_run_id) if parent_run_id else run_id
        for _ in range(10):
            if current in self._prompts:
                return self._prompts[current]
            current = self._parents.get(current, "")
            if not current:
                break
        return ""

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            rid = str(run_id)
            prompt = _extract_prompt(inputs)
            if prompt:
                self._prompts[rid] = prompt
            if parent_run_id:
                self._parents[rid] = str(parent_run_id)
        except Exception as e:
            logger.debug(f"wytness: on_chain_start error: {e}")

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        try:
            rid = str(run_id)
            self._prompts.pop(rid, None)
            self._parents.pop(rid, None)
        except Exception as e:
            logger.debug(f"wytness: on_chain_end error: {e}")

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        try:
            rid = str(run_id)
            self._prompts.pop(rid, None)
            self._parents.pop(rid, None)
        except Exception as e:
            logger.debug(f"wytness: on_chain_error error: {e}")

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            rid = str(run_id)
            tool_name = serialized.get("name") or serialized.get("id", ["unknown"])[-1]
            if parent_run_id:
                self._parents[rid] = str(parent_run_id)
            self._tool_runs[rid] = (str(tool_name), input_str or "", time.monotonic())
        except Exception as e:
            logger.debug(f"wytness: on_tool_start error: {e}")

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            rid = str(run_id)
            tool_data = self._tool_runs.pop(rid, None)
            if not tool_data:
                return
            tool_name, input_str, start_time = tool_data
            prompt = self._resolve_prompt(rid, parent_run_id)
            duration_ms = int((time.monotonic() - start_time) * 1000)

            params = {"input": input_str} if input_str else {}
            # Capture response: hash full output, then truncate + redact for storage
            outputs_hash = hash_value(str(output)) if output else ""
            response = ""
            if output is not None:
                response = _redact_pii(str(output)[:RESPONSE_MAX_CHARS])
            self._client.record(AuditEvent(
                agent_id=self._client.agent_id,
                agent_version=self._client.agent_version,
                human_operator_id=self._client.human_operator_id,
                task_id=self._task_id,
                session_id=self._client.session_id,
                tool_name=tool_name,
                tool_parameters=_sanitise(params),
                prompt=prompt,
                inputs_hash=hash_value(input_str) if input_str else "",
                outputs_hash=outputs_hash,
                response=response,
                status="success",
                duration_ms=duration_ms,
            ))
            self._parents.pop(rid, None)
        except Exception as e:
            logger.error(f"wytness: on_tool_end error: {e}")

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            rid = str(run_id)
            tool_data = self._tool_runs.pop(rid, None)
            if not tool_data:
                return
            tool_name, input_str, start_time = tool_data
            prompt = self._resolve_prompt(rid, parent_run_id)
            duration_ms = int((time.monotonic() - start_time) * 1000)

            params = {"input": input_str} if input_str else {}
            self._client.record(AuditEvent(
                agent_id=self._client.agent_id,
                agent_version=self._client.agent_version,
                human_operator_id=self._client.human_operator_id,
                task_id=self._task_id,
                session_id=self._client.session_id,
                tool_name=tool_name,
                tool_parameters=_sanitise(params),
                prompt=prompt,
                inputs_hash=hash_value(input_str) if input_str else "",
                status="failure",
                error_code=type(error).__name__,
                duration_ms=duration_ms,
            ))
            self._parents.pop(rid, None)
        except Exception as e:
            logger.error(f"wytness: on_tool_error error: {e}")
