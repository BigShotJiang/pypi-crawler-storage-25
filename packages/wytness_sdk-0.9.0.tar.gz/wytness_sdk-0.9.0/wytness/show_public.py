"""Print the Ed25519 public key PEM matching a local signing.key file.

Run as a module to extract the public key the Wytness SDK has been signing
with, so you can paste it into the Signing Key section of the Wytness portal:

    python -m wytness.show_public                  # default ./keys/signing.key
    python -m wytness.show_public ./other/key      # custom path

Without a registered public key, the Wytness API rejects /ingest with 412.
"""

import sys
from pathlib import Path

from cryptography.hazmat.primitives.serialization import (
    Encoding,
    PublicFormat,
    load_pem_private_key,
)


def main(argv: list[str] | None = None) -> int:
    args = list(argv if argv is not None else sys.argv[1:])
    key_path = Path(args[0]) if args else Path("./keys/signing.key")
    if not key_path.exists():
        sys.stderr.write(f"No signing key at {key_path}\n")
        sys.stderr.write(
            "If you haven't run the SDK yet, the key is generated on first use. "
            "Otherwise pass the correct path as an argument.\n"
        )
        return 1
    private_key = load_pem_private_key(key_path.read_bytes(), password=None)
    public_pem = private_key.public_key().public_bytes(
        Encoding.PEM, PublicFormat.SubjectPublicKeyInfo
    )
    sys.stdout.write(public_pem.decode())
    return 0


if __name__ == "__main__":
    sys.exit(main())
