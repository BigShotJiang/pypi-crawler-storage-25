"""Zero-knowledge PII pseudonymization with encrypted token map.

Replaces PII with deterministic HMAC-based pseudonyms and encrypts the
original-to-pseudonym mapping with the customer's X25519 public key.
Wytness never sees the real PII — only the customer can decrypt the map.
"""

import base64
import hashlib
import hmac
import json
import os
import re
from typing import Optional

from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

SECRET_PATTERNS = re.compile(
    r"(key|secret|token|password|passwd|pwd|credential|auth)", re.IGNORECASE
)

# Same patterns as decorator.py but we generate pseudonyms instead of [REDACTED]
PII_PATTERNS = [
    (re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"), "EMAIL"),
    (re.compile(r"\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b"), "SSN"),
    (re.compile(r"\b\d{3}[-.\s]?\d{3}[-.\s]?\d{3}\b"), "TFN"),
    (re.compile(r"\b(?:\d{4}[-\s]?){3}\d{4}\b"), "CARD"),
    (
        re.compile(
            r"\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"
        ),
        "PHONE",
    ),
]


def _hmac_pseudonym(value: str, secret: bytes, pii_type: str = "PII") -> str:
    """Generate a deterministic pseudonym using HMAC-SHA256."""
    digest = hmac.new(secret, value.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"{pii_type}_{digest[:8]}"


class SessionTokenizer:
    """Pseudonymizes PII with HMAC-based tokens and encrypts the mapping.

    Args:
        hmac_secret: 32-byte secret for deterministic pseudonyms (base64-decoded).
        encryption_public_key: X25519 public key bytes for encrypting the token map.
        pii_fields: List of parameter names whose values should be fully pseudonymized
                    (e.g. ["customer_name", "address"]). Values from declared fields
                    are also detected when they appear in free text.
    """

    def __init__(
        self,
        hmac_secret: bytes,
        encryption_public_key: bytes,
        pii_fields: Optional[list[str]] = None,
    ):
        self._hmac_secret = hmac_secret
        self._encryption_pub = X25519PublicKey.from_public_bytes(encryption_public_key)
        self._pii_fields: list[str] = pii_fields or []
        self._token_map: dict[str, str] = {}  # pseudonym → original
        self._reverse_map: dict[str, str] = {}  # original → pseudonym

    @property
    def token_map(self) -> dict[str, str]:
        """Read-only access to the current pseudonym → original mapping."""
        return dict(self._token_map)

    def _add_mapping(self, original: str, pseudonym: str) -> None:
        self._token_map[pseudonym] = original
        self._reverse_map[original] = pseudonym

    def pseudonymize_value(self, value: str, field_path: str = "") -> str:
        """Replace a single value with its pseudonym if it's a declared PII field.

        field_path may include dot notation and array indices (e.g.
        "fields.abn", "entities[0].name"). Both exact matches and
        index-stripped matches ("entities.name", "entities[].name") work.
        """
        if not value or not value.strip():
            return value
        if self._match_pii_field(field_path):
            if value in self._reverse_map:
                return self._reverse_map[value]
            pseudonym = _hmac_pseudonym(value, self._hmac_secret)
            self._add_mapping(value, pseudonym)
            return pseudonym
        return value

    def pseudonymize_text(self, text: str) -> str:
        """Replace PII in free text using reverse map propagation + regex patterns."""
        if not text:
            return text

        # Phase 1: Replace known values from reverse map (longest match first)
        known = sorted(self._reverse_map.keys(), key=len, reverse=True)
        for original in known:
            if original in text:
                text = text.replace(original, self._reverse_map[original])

        # Phase 2: Apply regex patterns for structured PII
        for pattern, pii_type in PII_PATTERNS:
            def _replacer(match, pt=pii_type):
                matched = match.group(0)
                if matched in self._reverse_map:
                    return self._reverse_map[matched]
                pseudonym = _hmac_pseudonym(matched, self._hmac_secret, pt)
                self._add_mapping(matched, pseudonym)
                return pseudonym

            text = pattern.sub(_replacer, text)

        return text

    def pseudonymize_params(self, params):
        """Pseudonymize tool parameters, preserving nested structure.

        Walks objects and arrays recursively. Keys whose names match
        SECRET_PATTERNS are replaced with "[REDACTED]". Primitive values
        at paths listed in self._pii_fields are fully pseudonymized; other
        strings are scanned with regex patterns.

        Paths use dot notation for nested keys (e.g. "fields.abn") and
        [index] for array items (e.g. "entities[0].name"). The path is
        checked against pii_fields without any array index, so
        "entities[].name" or "entities.name" as a pii_fields entry will
        match "entities[0].name", "entities[1].name", etc.

        Non-dict/non-list inputs at the top level are returned wrapped
        through the same walker so simple scalars still get scanned.
        """
        return self._walk(params, path="")

    def _match_pii_field(self, path: str) -> bool:
        if not path:
            return False
        if path in self._pii_fields:
            return True
        # Normalise away array indices so "items[0].name" matches "items.name" or "items[].name"
        stripped = re.sub(r"\[\d+\]", "", path)
        if stripped in self._pii_fields:
            return True
        wildcarded = re.sub(r"\[\d+\]", "[]", path)
        if wildcarded in self._pii_fields:
            return True
        return False

    def _walk(self, value, path: str):
        if isinstance(value, dict):
            out = {}
            for k, v in value.items():
                if SECRET_PATTERNS.search(str(k)):
                    out[k] = "[REDACTED]"
                    continue
                child_path = f"{path}.{k}" if path else str(k)
                out[k] = self._walk(v, child_path)
            return out
        if isinstance(value, list):
            return [self._walk(item, f"{path}[{i}]") for i, item in enumerate(value)]
        if isinstance(value, tuple):
            return tuple(self._walk(item, f"{path}[{i}]") for i, item in enumerate(value))
        if value is None or isinstance(value, (bool, int, float)):
            return value
        # String or other scalar — truncate then pseudonymize
        text = str(value)[:500]
        if self._match_pii_field(path):
            return self.pseudonymize_value(text, path)
        return self.pseudonymize_text(text)

    def encrypt_token_map(self) -> str:
        """Encrypt the token map with the customer's X25519 public key.

        Format: base64([ephemeral_pub 32B][nonce 12B][ciphertext])
        Uses X25519 ECDH + ChaCha20-Poly1305 (NaCl-compatible).
        """
        plaintext = json.dumps(self._token_map, ensure_ascii=False).encode("utf-8")

        # Generate ephemeral X25519 keypair
        ephemeral_private = X25519PrivateKey.generate()
        ephemeral_public = ephemeral_private.public_key()

        # Derive shared secret via ECDH
        shared_secret = ephemeral_private.exchange(self._encryption_pub)
        # Use SHA-256 of the shared secret as the symmetric key (32 bytes)
        symmetric_key = hashlib.sha256(shared_secret).digest()

        # Encrypt with ChaCha20-Poly1305
        nonce = os.urandom(12)
        cipher = ChaCha20Poly1305(symmetric_key)
        ciphertext = cipher.encrypt(nonce, plaintext, None)

        # Pack: ephemeral_public (32) + nonce (12) + ciphertext
        ephemeral_pub_bytes = ephemeral_public.public_bytes_raw()
        packed = ephemeral_pub_bytes + nonce + ciphertext

        return base64.b64encode(packed).decode("ascii")

    @staticmethod
    def decrypt_token_map(encrypted_b64: str, private_key_bytes: bytes) -> dict:
        """Decrypt a token map using the customer's X25519 private key.

        Args:
            encrypted_b64: Base64-encoded encrypted blob from encrypt_token_map().
            private_key_bytes: Raw 32-byte X25519 private key.

        Returns:
            The token map dict (pseudonym → original).
        """
        packed = base64.b64decode(encrypted_b64)
        ephemeral_pub_bytes = packed[:32]
        nonce = packed[32:44]
        ciphertext = packed[44:]

        # Reconstruct keys
        private_key = X25519PrivateKey.from_private_bytes(private_key_bytes)
        ephemeral_pub = X25519PublicKey.from_public_bytes(ephemeral_pub_bytes)

        # Derive shared secret
        shared_secret = private_key.exchange(ephemeral_pub)
        symmetric_key = hashlib.sha256(shared_secret).digest()

        # Decrypt
        cipher = ChaCha20Poly1305(symmetric_key)
        plaintext = cipher.decrypt(nonce, ciphertext, None)

        return json.loads(plaintext.decode("utf-8"))
