"""Cross-SDK hash vector tests.

Tests that compute_event_hash produces the exact same SHA256 for a set of
fixed event dicts.  The TypeScript SDK has an identical test against the
same fixture file — if either SDK changes serialisation, these tests break.
"""
import json
from pathlib import Path
import pytest
from wytness.chain import compute_event_hash

VECTORS_PATH = Path(__file__).resolve().parent.parent.parent / "tests" / "fixtures" / "hash_vectors.json"


@pytest.fixture(scope="module")
def vectors():
    return json.loads(VECTORS_PATH.read_text())


def test_vectors_file_exists():
    assert VECTORS_PATH.exists(), f"Missing fixture: {VECTORS_PATH}"


def test_all_vectors_match(vectors):
    for v in vectors:
        actual = compute_event_hash(v["event"])
        assert actual == v["expected_hash"], (
            f"Hash mismatch for '{v['description']}': "
            f"expected {v['expected_hash'][:16]}..., got {actual[:16]}..."
        )


def test_minimum_vector_count(vectors):
    assert len(vectors) >= 5, f"Expected at least 5 vectors, got {len(vectors)}"
