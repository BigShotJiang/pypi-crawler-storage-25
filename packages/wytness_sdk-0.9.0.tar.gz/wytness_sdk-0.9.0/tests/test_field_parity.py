"""Field parity tests — catch field additions that aren't propagated.

Asserts that every field in the SDK's AuditEvent model exists in the
ingest API's IngestEvent model.  Catches the case where someone adds
a field to the SDK but forgets the API (or vice versa).
"""
import json, sys
from pathlib import Path
import pytest
from wytness.models import AuditEvent

api_path = str(Path(__file__).resolve().parent.parent.parent / "api")
sys.path.insert(0, api_path)


def test_sdk_fields_subset_of_ingest():
    """Every SDK model field must exist in IngestEvent."""
    try:
        from app.routes.ingest import IngestEvent
    except ImportError:
        pytest.skip("FastAPI not available — cannot import IngestEvent")

    sdk_fields = set(AuditEvent.model_fields.keys())
    ingest_fields = set(IngestEvent.model_fields.keys())
    missing = sdk_fields - ingest_fields
    assert not missing, (
        f"SDK fields missing from IngestEvent: {missing}. "
        f"Add them to api/app/routes/ingest.py:IngestEvent"
    )


def test_ingest_fields_subset_of_sdk():
    """Every IngestEvent field should exist in the SDK model too."""
    try:
        from app.routes.ingest import IngestEvent
    except ImportError:
        pytest.skip("FastAPI not available — cannot import IngestEvent")

    sdk_fields = set(AuditEvent.model_fields.keys())
    ingest_fields = set(IngestEvent.model_fields.keys())
    extra = ingest_fields - sdk_fields
    assert not extra, (
        f"IngestEvent has fields not in SDK: {extra}. "
        f"Add them to sdk-python/wytness/models.py:AuditEvent"
    )


def test_sdk_fields_match_hash_vectors():
    """Hash vector fixture events must have exactly the SDK's field set."""
    vectors_path = Path(__file__).resolve().parent.parent.parent / "tests" / "fixtures" / "hash_vectors.json"
    if not vectors_path.exists():
        pytest.skip("Hash vectors fixture not found")

    sdk_fields = set(AuditEvent.model_fields.keys())
    vectors = json.loads(vectors_path.read_text())
    for v in vectors:
        event_fields = set(v["event"].keys())
        missing = sdk_fields - event_fields
        extra = event_fields - sdk_fields
        assert not missing and not extra, (
            f"Vector '{v['description']}' field mismatch: "
            f"missing={missing}, extra={extra}"
        )
