"""Roundtrip hash test — proves the full pipeline preserves hash integrity.

Simulates: SDK dict → HTTP JSON → pydantic IngestEvent → model_dump →
add org_id → json.dumps (raw_event) → json.loads → strip org_id → hash.

This is the test that would have caught the verify endpoint bug where
ClickHouse type conversions (DateTime64, JSON-as-string, missing fields)
caused every event to show as a chain break.
"""
import json, sys
from pathlib import Path

import pytest
from wytness.models import AuditEvent
from wytness.chain import compute_event_hash
from wytness.signing import generate_keypair, sign_event

# Import IngestEvent from the API
api_path = str(Path(__file__).resolve().parent.parent.parent / "api")
sys.path.insert(0, api_path)


@pytest.fixture(scope="module")
def keypair():
    return generate_keypair()


def _make_sdk_event(private_key, prev_hash="", **overrides):
    """Create an event dict exactly as the SDK's record() method does."""
    defaults = dict(
        agent_id="roundtrip-agent",
        agent_version="1.0.0",
        human_operator_id="operator-1",
        task_id="task-1",
        session_id="sess-001",
        tool_name="test_tool",
        tool_parameters={"key": "value", "nested": {"a": 1}},
        reasoning_summary="testing",
        prompt="do something",
        response="done",
        status="success",
        duration_ms=100,
    )
    defaults.update(overrides)
    event = AuditEvent(**defaults)
    d = event.model_dump(mode="json")
    d["prev_event_hash"] = prev_hash
    d["signature"] = sign_event(d, private_key)
    sdk_hash = compute_event_hash(d)
    return d, sdk_hash


def _simulate_pipeline(sdk_dict):
    """Simulate ingest API → ledger → raw_event storage → verify readback."""
    # 1. SDK sends JSON over HTTP
    http_json = json.dumps(sdk_dict, default=str)

    # 2. Ingest API parses into pydantic model, re-serialises
    try:
        from app.routes.ingest import IngestEvent
        ingest_event = IngestEvent(**json.loads(http_json))
        payload = ingest_event.model_dump(mode="json")
    except ImportError:
        # If FastAPI not available, simulate with plain json round-trip
        # (this still catches most serialisation issues)
        payload = json.loads(http_json)

    # 3. Ingest adds org_id
    payload["org_id"] = "org-test-123"

    # 4. Ledger pops signing_public_keys (if present), stores raw_event
    payload.pop("signing_public_keys", None)
    raw_event = json.dumps(payload, default=str)

    # 5. Verify endpoint reads raw_event, strips org_id, hashes
    recovered = json.loads(raw_event)
    recovered.pop("org_id", None)
    verify_hash = compute_event_hash(recovered)

    return verify_hash


def test_single_event_roundtrip(keypair):
    private_key, _ = keypair
    sdk_dict, sdk_hash = _make_sdk_event(private_key)
    verify_hash = _simulate_pipeline(sdk_dict)
    assert verify_hash == sdk_hash, (
        f"Roundtrip hash mismatch: SDK={sdk_hash[:16]}... verify={verify_hash[:16]}..."
    )


def test_chain_of_three_roundtrip(keypair):
    """Build a 3-event chain and verify each link survives the pipeline."""
    private_key, _ = keypair
    prev_hash = ""
    for i in range(3):
        sdk_dict, sdk_hash = _make_sdk_event(
            private_key,
            prev_hash=prev_hash,
            tool_name=f"tool_{i}",
        )
        verify_hash = _simulate_pipeline(sdk_dict)
        assert verify_hash == sdk_hash, (
            f"Chain event {i}: roundtrip hash mismatch"
        )
        prev_hash = sdk_hash


def test_event_with_pseudonymization_roundtrip(keypair):
    private_key, _ = keypair
    sdk_dict, sdk_hash = _make_sdk_event(
        private_key,
        encrypted_token_map="base64data==",
        pseudonymization_version="1.0",
    )
    verify_hash = _simulate_pipeline(sdk_dict)
    assert verify_hash == sdk_hash


def test_event_with_null_error_code_roundtrip(keypair):
    private_key, _ = keypair
    sdk_dict, sdk_hash = _make_sdk_event(
        private_key,
        status="failure",
        error_code="ValueError",
    )
    verify_hash = _simulate_pipeline(sdk_dict)
    assert verify_hash == sdk_hash


def test_event_with_empty_fields_roundtrip(keypair):
    private_key, _ = keypair
    sdk_dict, sdk_hash = _make_sdk_event(
        private_key,
        tool_parameters={},
        prompt="",
        response="",
        reasoning_summary="",
    )
    verify_hash = _simulate_pipeline(sdk_dict)
    assert verify_hash == sdk_hash
