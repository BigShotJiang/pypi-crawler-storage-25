"""Configuration loading and parsing for AgentLint."""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from agentlint.detector import detect_stack
from agentlint.models import Severity
from agentlint.packs import PACK_MODULES

logger = logging.getLogger("agentlint")

CONFIG_FILENAMES = ["agentlint.yml", "agentlint.yaml", ".agentlint.yml"]

VALID_SEVERITY_MODES = {"strict", "standard", "relaxed"}

# Rules that are disabled unless explicitly enabled in config.
_DISABLED_BY_DEFAULT = {"git-checkpoint"}


@dataclass
class AgentLintConfig:
    """Parsed AgentLint configuration."""
    severity: str = "standard"
    packs: list[str] = field(default_factory=lambda: ["universal"])
    rules: dict[str, dict] = field(default_factory=dict)
    custom_rules_dir: str | None = None
    circuit_breaker: dict = field(default_factory=dict)
    recording: dict = field(default_factory=dict)
    agentchute: dict = field(default_factory=dict)
    projects: dict[str, dict] = field(default_factory=dict)

    @property
    def is_recording_enabled(self) -> bool:
        return self.recording.get("enabled", False)

    def is_rule_enabled(self, rule_id: str) -> bool:
        rule_cfg = self.rules.get(rule_id, {})
        if not isinstance(rule_cfg, dict):
            # Treat bare boolean/scalar as enabled shorthand: `no-secrets: false`
            return bool(rule_cfg) if rule_cfg is not None else (rule_id not in _DISABLED_BY_DEFAULT)
        default = rule_id not in _DISABLED_BY_DEFAULT
        return rule_cfg.get("enabled", default)

    def get_rule_config(self, rule_id: str) -> dict:
        return self.rules.get(rule_id, {})

    def effective_severity(self, base: Severity) -> Severity:
        if self.severity == "strict":
            if base == Severity.WARNING:
                return Severity.ERROR
            if base == Severity.INFO:
                return Severity.WARNING
        elif self.severity == "relaxed":
            if base == Severity.WARNING:
                return Severity.INFO
        return base

    def resolve_packs_for_file(self, file_path: str, project_dir: str) -> list[str]:
        """Resolve effective packs for a file, checking project overrides."""
        if not self.projects or not file_path:
            return self.packs
        try:
            relative = os.path.relpath(file_path, project_dir)
        except ValueError:
            return self.packs

        best_match = ""
        best_packs = None
        for prefix, project_config in self.projects.items():
            clean = prefix.rstrip("/")
            if relative.startswith(clean + "/") or relative.startswith(clean + os.sep):
                if len(clean) > len(best_match):
                    best_match = clean
                    best_packs = project_config.get("packs")
        return best_packs if best_packs else self.packs

    def with_packs(self, packs: list[str]) -> AgentLintConfig:
        """Return a copy with different packs."""
        return AgentLintConfig(
            severity=self.severity,
            packs=packs,
            rules=self.rules,
            custom_rules_dir=self.custom_rules_dir,
            circuit_breaker=self.circuit_breaker,
            recording=self.recording,
            agentchute=self.agentchute,
            projects=self.projects,
        )


def get_rule_setting(rules_dict: dict, rule_id: str, key: str, default=None):
    """Get config value with cascade: per-rule → global → default.

    Allows users to set global defaults in the ``rules:`` block and
    override them per-rule:

        rules:
          strict_mode: true          # global default
          no-secrets:
            strict_mode: false       # per-rule override
    """
    rule_cfg = rules_dict.get(rule_id, {})
    if isinstance(rule_cfg, dict) and key in rule_cfg:
        return rule_cfg[key]
    if key in rules_dict:
        return rules_dict[key]
    return default


def load_config(project_dir: str) -> AgentLintConfig:
    """Load config from agentlint.yml or auto-detect defaults."""
    root = Path(project_dir)

    raw = {}
    for filename in CONFIG_FILENAMES:
        config_path = root / filename
        if config_path.exists():
            try:
                raw = yaml.safe_load(config_path.read_text()) or {}
            except yaml.YAMLError:
                logger.warning("Invalid YAML in %s, using defaults", config_path)
                raw = {}
            break

    # Validate severity
    severity = raw.get("severity", "standard")
    if severity not in VALID_SEVERITY_MODES:
        logger.warning("Invalid severity '%s', falling back to 'standard'", severity)
        severity = "standard"

    # Determine packs
    stack_mode = raw.get("stack", "auto")
    explicit_packs = raw.get("packs")

    if explicit_packs:
        packs = explicit_packs
        custom_dir = raw.get("custom_rules_dir")
        for p in packs:
            if p not in PACK_MODULES and not custom_dir:
                logger.warning("Unknown pack '%s' — set custom_rules_dir to use custom packs", p)
    elif stack_mode == "auto":
        packs = detect_stack(project_dir)
    else:
        packs = ["universal"]

    return AgentLintConfig(
        severity=severity,
        packs=packs,
        rules=raw.get("rules", {}),
        custom_rules_dir=raw.get("custom_rules_dir"),
        circuit_breaker=raw.get("circuit_breaker", {}),
        recording=raw.get("recording", {}),
        agentchute=raw.get("agentchute", {}),
        projects=raw.get("projects", {}),
    )
