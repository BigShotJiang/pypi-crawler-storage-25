from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import datetime
import hashlib
import hmac
import json
from pathlib import Path
import re
from typing import Any
from xml.sax.saxutils import escape, quoteattr

from flask import Flask, Response, current_app, request, stream_with_context
from werkzeug.datastructures import MultiDict

from ._compat import UTC
from .app_metadata import kukicha_version
from .models import ALBUM_ARTWORK_HEIGHT, TRACK_ARTWORK_HEIGHT
from .player_common import ARTWORK_CACHE_CONTROL
from .player_config import PlayerServerOptions, read_open_subsonic_secret
from .player_errors import PlayerConfigError, PlayerNotFoundError
from .media_resources import AudioResource, local_audio_resource
from .player_media import audio_mime_type, audio_resource_head, iter_audio_resource_bytes
from .player_runtime import PlayerRuntime
from .use_case import (
    ALBUM_LIST_SORT_ALBUMS,
    ALBUM_LIST_SORT_ARTIST,
    ALBUM_LIST_SORT_FREQUENT,
    ALBUM_LIST_SORT_RECENT,
    ALBUM_LIST_SORT_RECENTLY_ADDED,
    ALBUM_LIST_SORT_STARRED,
    AlbumNotFoundError,
    AlbumListQuery,
    AlbumSummary,
    ArtistNotFoundError,
    GenreStyleFilter,
    LibraryArtistDetails,
    LibraryArtistSummary,
    LibraryGenre,
    LibraryQueries,
    TrackNotFoundError,
    record_opensubsonic_client,
    record_playback,
    track_artwork,
    track_audio_path,
    track_audio_resource,
    update_album_star,
)
from .use_case.queries.library import album_artist_display_text


OPEN_SUBSONIC_CONTEXT_KEY = "kukicha_open_subsonic_context"
OPEN_SUBSONIC_PROTOCOL_VERSION = "1.16.1"
OPEN_SUBSONIC_TYPE = "kukicha"
BYTE_RANGE_RE = re.compile(r"bytes=(\d*)-(\d*)$")
ERROR_GENERIC = 0
ERROR_REQUIRED_PARAMETER_MISSING = 10
ERROR_WRONG_USERNAME_OR_PASSWORD = 40
ERROR_UNSUPPORTED_AUTHENTICATION = 42
ERROR_CONFLICTING_AUTHENTICATION = 43
ERROR_NOT_FOUND = 70
IGNORED_ARTICLES = ("The", "An", "A", "Die", "Das", "Ein", "Eine", "Les", "Le", "La")
IGNORED_ARTICLES_TEXT = " ".join(IGNORED_ARTICLES)


@dataclass(frozen=True, slots=True)
class OpenSubsonicWebContext:
    options: PlayerServerOptions
    runtime: PlayerRuntime
    database: Path


class OpenSubsonicApiError(Exception):
    def __init__(self, code: int, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def open_subsonic_rest_prefix(mount_prefix: str) -> str:
    if mount_prefix == "/":
        return "/rest"
    return f"{mount_prefix}/rest"


def mount_open_subsonic(
    app: Flask,
    *,
    options: PlayerServerOptions,
    runtime: PlayerRuntime,
    database: Path,
) -> None:
    if options.opensubsonic is None:
        return

    app.extensions[OPEN_SUBSONIC_CONTEXT_KEY] = OpenSubsonicWebContext(
        options=options,
        runtime=runtime,
        database=database,
    )
    rest_prefix = open_subsonic_rest_prefix(options.opensubsonic.mount_prefix)

    def service_root() -> Response:
        return Response(
            "kukicha OpenSubsonic\n",
            content_type="text/plain; charset=utf-8",
        )

    def open_subsonic_endpoint(endpoint: str) -> Response:
        endpoint_name = normalized_endpoint_name(endpoint)
        params = request_parameters()
        format_error = response_format_error(params)
        if format_error is not None:
            return subsonic_error_response(format_error.code, format_error.message)

        endpoint_key = endpoint_name.casefold()
        handler = open_subsonic_handlers().get(endpoint_key)
        if endpoint_key != "getopensubsonicextensions":
            auth_error = authentication_error(open_subsonic_context().options, params)
            if auth_error is not None:
                return subsonic_error_response(auth_error.code, auth_error.message)
            record_authenticated_opensubsonic_client(params)
        elif has_opensubsonic_auth_params(params):
            auth_error = authentication_error(open_subsonic_context().options, params)
            if auth_error is None:
                record_authenticated_opensubsonic_client(params)

        if handler is None:
            return subsonic_error_response(ERROR_GENERIC, "Endpoint not implemented")

        try:
            result = handler(params)
        except OpenSubsonicApiError as error:
            return subsonic_error_response(error.code, error.message)
        except (
            AlbumNotFoundError,
            ArtistNotFoundError,
            PlayerNotFoundError,
            TrackNotFoundError,
            FileNotFoundError,
        ):
            return subsonic_error_response(ERROR_NOT_FOUND, "The requested data was not found.")
        if isinstance(result, Response):
            return result
        return subsonic_success_response(result)

    endpoint_base = f"opensubsonic_{rest_prefix.strip('/').replace('/', '_') or 'root'}"
    app.add_url_rule(
        rest_prefix,
        f"{endpoint_base}_service_root",
        service_root,
        methods=["GET"],
    )
    app.add_url_rule(
        f"{rest_prefix}/",
        f"{endpoint_base}_service_root_slash",
        service_root,
        methods=["GET"],
    )
    app.add_url_rule(
        f"{rest_prefix}/<path:endpoint>",
        f"{endpoint_base}_endpoint",
        open_subsonic_endpoint,
        methods=["GET", "POST"],
    )


def open_subsonic_handlers() -> dict[str, Any]:
    return {
        "ping": handle_ping,
        "getlicense": handle_get_license,
        "getopensubsonicextensions": handle_get_open_subsonic_extensions,
        "getmusicfolders": handle_get_music_folders,
        "getgenres": handle_get_genres,
        "getartists": handle_get_artists,
        "getartist": handle_get_artist,
        "getalbumlist2": handle_get_album_list2,
        "getalbum": handle_get_album,
        "getsong": handle_get_song,
        "stream": handle_stream,
        "download": handle_download,
        "getcoverart": handle_get_cover_art,
        "scrobble": handle_scrobble,
        "star": handle_star,
        "unstar": handle_unstar,
    }


def open_subsonic_context() -> OpenSubsonicWebContext:
    return current_app.extensions[OPEN_SUBSONIC_CONTEXT_KEY]


def normalized_endpoint_name(endpoint: str) -> str:
    if endpoint.endswith(".view"):
        return endpoint[: -len(".view")]
    return endpoint


def request_parameters() -> dict[str, list[str]]:
    values: dict[str, list[str]] = {}
    for source in (request.args, request.form if request.method == "POST" else MultiDict()):
        for key, items in source.lists():
            values.setdefault(key, []).extend(str(item) for item in items)
    return values


def first_param(params: Mapping[str, list[str]], key: str) -> str | None:
    values = params.get(key)
    if not values:
        return None
    return values[0]


def has_opensubsonic_auth_params(params: Mapping[str, list[str]]) -> bool:
    return first_param(params, "u") is not None and any(
        first_param(params, key) is not None for key in ("p", "t", "s")
    )


def record_authenticated_opensubsonic_client(params: Mapping[str, list[str]]) -> None:
    record_opensubsonic_client(
        open_subsonic_context().database,
        first_param(params, "c") or "",
    )


def require_param(params: Mapping[str, list[str]], key: str) -> str:
    value = first_param(params, key)
    if value is None or not value:
        raise OpenSubsonicApiError(
            ERROR_REQUIRED_PARAMETER_MISSING,
            f"Required parameter is missing: {key}",
        )
    return value


def response_format_error(
    params: Mapping[str, list[str]],
) -> OpenSubsonicApiError | None:
    response_format = first_param(params, "f")
    if response_format is None or response_format.casefold() in {"json", "xml"}:
        return None
    return OpenSubsonicApiError(
        ERROR_GENERIC,
        "Response format is not supported",
    )


def authentication_error(
    options: PlayerServerOptions,
    params: Mapping[str, list[str]],
) -> OpenSubsonicApiError | None:
    if any(key.casefold() == "apikey" for key in params):
        return OpenSubsonicApiError(
            ERROR_UNSUPPORTED_AUTHENTICATION,
            "API key authentication is not supported",
        )

    username = first_param(params, "u")
    client_version = first_param(params, "v")
    client_name = first_param(params, "c")
    password = first_param(params, "p")
    token = first_param(params, "t")
    salt = first_param(params, "s")
    has_password_auth = password is not None
    has_token_auth = token is not None or salt is not None

    for value in (username, client_version, client_name):
        if value is None or not value:
            return OpenSubsonicApiError(
                ERROR_REQUIRED_PARAMETER_MISSING,
                "Required authentication parameter is missing",
            )
    if has_password_auth and has_token_auth:
        return OpenSubsonicApiError(
            ERROR_CONFLICTING_AUTHENTICATION,
            "Multiple authentication mechanisms were provided",
        )
    if not has_password_auth and not has_token_auth:
        return OpenSubsonicApiError(
            ERROR_REQUIRED_PARAMETER_MISSING,
            "Required authentication parameter is missing",
        )

    if options.auth is None or options.opensubsonic is None:
        return OpenSubsonicApiError(
            ERROR_GENERIC,
            "OpenSubsonic is not configured",
        )

    if not hmac.compare_digest(str(username), options.auth.username):
        return OpenSubsonicApiError(
            ERROR_WRONG_USERNAME_OR_PASSWORD,
            "Wrong username or password",
        )

    try:
        open_subsonic_secret = read_open_subsonic_secret(options.opensubsonic.secret_file)
    except PlayerConfigError:
        return OpenSubsonicApiError(
            ERROR_GENERIC,
            "OpenSubsonic secret is not available",
        )

    if has_password_auth:
        if password is None or not hmac.compare_digest(password, open_subsonic_secret):
            return OpenSubsonicApiError(
                ERROR_WRONG_USERNAME_OR_PASSWORD,
                "Wrong username or password",
            )
        return None

    if token is None or salt is None or not token or not salt:
        return OpenSubsonicApiError(
            ERROR_REQUIRED_PARAMETER_MISSING,
            "Required authentication parameter is missing",
        )
    expected = hashlib.md5(
        f"{open_subsonic_secret}{salt}".encode("utf-8")
    ).hexdigest()
    if not hmac.compare_digest(token.casefold(), expected):
        return OpenSubsonicApiError(
            ERROR_WRONG_USERNAME_OR_PASSWORD,
            "Wrong username or password",
        )
    return None


def handle_ping(params: Mapping[str, list[str]]) -> dict[str, object]:
    return {}


def handle_get_license(params: Mapping[str, list[str]]) -> dict[str, object]:
    return {"license": {"valid": True}}


def handle_get_open_subsonic_extensions(
    params: Mapping[str, list[str]],
) -> dict[str, object]:
    return {"openSubsonicExtensions": [{"name": "formPost", "versions": [1]}]}


def handle_get_music_folders(params: Mapping[str, list[str]]) -> dict[str, object]:
    folders = [
        {
            "id": str(root.position),
            "name": root.label if root.kind == "s3" else music_folder_name(root.path),
        }
        for root in LibraryQueries(open_subsonic_context().database).library_roots()
    ]
    return {"musicFolders": {"musicFolder": folders}}


def handle_get_genres(params: Mapping[str, list[str]]) -> dict[str, object]:
    genres = LibraryQueries(open_subsonic_context().database).list_genres()
    return {"genres": {"genre": genre_payloads(genres)}}


def handle_get_artists(params: Mapping[str, list[str]]) -> dict[str, object]:
    root_position = optional_int_param(params, "musicFolderId")
    artists = artist_stats_payloads(
        open_subsonic_context().database,
        root_position=root_position,
    )
    return {"artists": {"ignoredArticles": IGNORED_ARTICLES_TEXT, "index": artists}}


def handle_get_artist(params: Mapping[str, list[str]]) -> dict[str, object]:
    artist = require_param(params, "id")
    return {"artist": artist_payload(open_subsonic_context().database, artist)}


def handle_get_album_list2(params: Mapping[str, list[str]]) -> dict[str, object]:
    album_list_type = require_param(params, "type")
    size = int_param(params, "size", default=10, minimum=0, maximum=500)
    offset = int_param(params, "offset", default=0, minimum=0)
    if size == 0:
        return {"albumList2": {"album": []}}
    query = album_list2_query_from_params(
        params,
        album_list_type=album_list_type,
        offset=offset,
    )
    if query is None:
        albums: list[dict[str, object]] = []
    else:
        albums = album_list2_payloads(
            album_list2_summaries(
                open_subsonic_context().database,
                query=query,
                size=size,
            )
        )
    return {"albumList2": {"album": albums}}


def handle_get_album(params: Mapping[str, list[str]]) -> dict[str, object]:
    album_id = require_param(params, "id")
    album = LibraryQueries(open_subsonic_context().database).get_album(album_id)
    return {"album": album_payload(album, include_songs=True)}


def handle_get_song(params: Mapping[str, list[str]]) -> dict[str, object]:
    track_id = int_required_param(params, "id")
    song = LibraryQueries(open_subsonic_context().database).get_track(track_id)
    return {"song": song_payload(song)}


def handle_stream(params: Mapping[str, list[str]]) -> Response:
    track_id = int_required_param(params, "id")
    try:
        resource = track_audio_resource(open_subsonic_context().runtime, track_id)
    except TrackNotFoundError:
        path = track_audio_path(open_subsonic_context().runtime, track_id)
        return audio_file_response(path)
    return audio_resource_response(resource)


def handle_download(params: Mapping[str, list[str]]) -> Response:
    track_id = int_required_param(params, "id")
    try:
        resource = track_audio_resource(open_subsonic_context().runtime, track_id)
    except TrackNotFoundError:
        path = track_audio_path(open_subsonic_context().runtime, track_id)
        response = audio_file_response(path)
        response.headers["Content-Disposition"] = (
            f'attachment; filename="{content_disposition_filename(path.name)}"'
        )
        return response
    response = audio_resource_response(resource)
    response.headers["Content-Disposition"] = (
        f'attachment; filename="{content_disposition_filename(resource.name)}"'
    )
    return response


def handle_get_cover_art(params: Mapping[str, list[str]]) -> Response:
    cover_id = require_param(params, "id")
    context = open_subsonic_context()
    track_ids = cover_art_track_ids(context.database, cover_id)
    for track_id in track_ids:
        artwork = track_artwork(context.runtime, ALBUM_ARTWORK_HEIGHT, track_id)
        if artwork is None:
            artwork = track_artwork(context.runtime, TRACK_ARTWORK_HEIGHT, track_id)
        if artwork is not None:
            response = Response(artwork.data, content_type=artwork.mime_type)
            response.headers["Cache-Control"] = ARTWORK_CACHE_CONTROL
            return response
    raise OpenSubsonicApiError(ERROR_NOT_FOUND, "The requested data was not found.")


def handle_scrobble(params: Mapping[str, list[str]]) -> dict[str, object]:
    id_values = params.get("id") or []
    if not id_values:
        raise OpenSubsonicApiError(
            ERROR_REQUIRED_PARAMETER_MISSING,
            "Required parameter is missing: id",
        )
    time_values = params.get("time") or []
    submission = bool_param(params, "submission", default=True)
    client_name = first_param(params, "c") or ""
    for index, id_value in enumerate(id_values):
        try:
            track_id = int(id_value)
        except ValueError as error:
            raise OpenSubsonicApiError(
                ERROR_REQUIRED_PARAMETER_MISSING,
                "Required parameter is invalid: id",
            ) from error
        played_at = (
            scrobble_time_from_epoch_millis(time_values[index])
            if index < len(time_values)
            else None
        )
        record_playback(
            open_subsonic_context().database,
            track_id,
            submission=submission,
            played_at=played_at,
            source=client_name,
        )
    return {}


def handle_star(params: Mapping[str, list[str]]) -> dict[str, object]:
    return handle_album_star_update(params, starred=True)


def handle_unstar(params: Mapping[str, list[str]]) -> dict[str, object]:
    return handle_album_star_update(params, starred=False)


def handle_album_star_update(
    params: Mapping[str, list[str]],
    *,
    starred: bool,
) -> dict[str, object]:
    for unsupported_param in ("id", "artistId"):
        if unsupported_param in params:
            raise OpenSubsonicApiError(
                ERROR_GENERIC,
                f"Parameter is not implemented: {unsupported_param}",
            )

    album_ids = params.get("albumId") or []
    if not album_ids or any(not album_id for album_id in album_ids):
        raise OpenSubsonicApiError(
            ERROR_REQUIRED_PARAMETER_MISSING,
            "Required parameter is missing: albumId",
        )

    context = open_subsonic_context()
    for album_id in album_ids:
        update_album_star(context.runtime, album_id, {"starred": starred})
    return {}


def int_required_param(params: Mapping[str, list[str]], key: str) -> int:
    value = require_param(params, key)
    try:
        return int(value)
    except ValueError as error:
        raise OpenSubsonicApiError(
            ERROR_REQUIRED_PARAMETER_MISSING,
            f"Required parameter is invalid: {key}",
        ) from error


def int_param(
    params: Mapping[str, list[str]],
    key: str,
    *,
    default: int,
    minimum: int | None = None,
    maximum: int | None = None,
) -> int:
    value = first_param(params, key)
    if value is None or value == "":
        parsed = default
    else:
        try:
            parsed = int(value)
        except ValueError as error:
            raise OpenSubsonicApiError(
                ERROR_REQUIRED_PARAMETER_MISSING,
                f"Required parameter is invalid: {key}",
            ) from error
    if minimum is not None:
        parsed = max(minimum, parsed)
    if maximum is not None:
        parsed = min(maximum, parsed)
    return parsed


def optional_int_param(params: Mapping[str, list[str]], key: str) -> int | None:
    value = first_param(params, key)
    if value is None or value == "":
        return None
    try:
        return int(value)
    except ValueError as error:
        raise OpenSubsonicApiError(
            ERROR_REQUIRED_PARAMETER_MISSING,
            f"Required parameter is invalid: {key}",
        ) from error


def bool_param(
    params: Mapping[str, list[str]],
    key: str,
    *,
    default: bool,
) -> bool:
    value = first_param(params, key)
    if value is None or value == "":
        return default
    folded = value.casefold()
    if folded in {"1", "true", "yes"}:
        return True
    if folded in {"0", "false", "no"}:
        return False
    raise OpenSubsonicApiError(
        ERROR_REQUIRED_PARAMETER_MISSING,
        f"Required parameter is invalid: {key}",
    )


def scrobble_time_from_epoch_millis(value: str) -> datetime:
    try:
        millis = int(value)
    except ValueError as error:
        raise OpenSubsonicApiError(
            ERROR_REQUIRED_PARAMETER_MISSING,
            "Required parameter is invalid: time",
        ) from error
    return datetime.fromtimestamp(millis / 1000, tz=UTC)


def artist_stats_payloads(
    database: Path,
    *,
    root_position: int | None = None,
) -> list[dict[str, object]]:
    artists = [
        artist_summary_payload(artist)
        for artist in LibraryQueries(database).list_album_artists(
            root_position=root_position,
        )
    ]
    return artist_indexes(artists)


def artist_payload(database: Path, artist_id_value: str) -> dict[str, object]:
    requested_artist = artist_name_from_id(artist_id_value)
    artist = LibraryQueries(database).get_album_artist(requested_artist)
    payload = artist_summary_payload(artist)
    payload["album"] = artist_album_payloads(artist)
    return payload


def artist_album_payloads(artist: LibraryArtistDetails) -> list[dict[str, object]]:
    parent = artist_id(artist.artist)
    albums: list[dict[str, object]] = []
    for row in artist.albums:
        album = album_summary_payload(
            album_id=row.album_id,
            name=row.album,
            artist=row.artist,
            song_count=row.track_count,
            year=row.year,
            created=row.file_created_at,
            has_cover=row.has_cover,
            art_track_id=row.art_track_id,
        )
        album.update(
            without_none(
                {
                    "parent": parent,
                    "album": row.album,
                    "title": row.album,
                    "isDir": True,
                    "duration": row.duration_seconds,
                    "genre": row.genre,
                }
            )
        )
        albums.append(album)
    return albums


def artist_summary_payload(artist: LibraryArtistSummary) -> dict[str, object]:
    return without_none(
        {
            "id": artist_id(artist.artist),
            "name": artist.artist,
            "coverArt": album_cover_art_id(artist.cover_album_id),
            "albumCount": artist.album_count,
            "roles": ["albumartist"],
        }
    )


def artist_indexes(artists: Iterable[dict[str, object]]) -> list[dict[str, object]]:
    groups: dict[str, list[dict[str, object]]] = {}
    for artist in sorted(
        artists,
        key=lambda item: artist_sort_key(str(item.get("name", ""))),
    ):
        groups.setdefault(artist_index_name(str(artist.get("name", ""))), []).append(artist)
    return [
        {"name": name, "artist": groups[name]}
        for name in sorted(groups, key=artist_index_sort_key)
    ]


def artist_index_name(artist: str) -> str:
    key = artist_sort_key(artist)
    if not key:
        return "#"
    first = key[0].upper()
    if not first.isalpha():
        return "#"
    return first


def artist_index_sort_key(value: str) -> tuple[int, str]:
    return (1, value) if value == "#" else (0, value)


def artist_sort_key(artist: str) -> str:
    sortable = artist.strip()
    casefolded_articles = {article.casefold() for article in IGNORED_ARTICLES}
    while True:
        words = sortable.split(maxsplit=1)
        if not words or words[0].casefold() not in casefolded_articles:
            break
        sortable = words[1] if len(words) > 1 else ""
    return sortable.casefold()


def artist_name_from_id(value: str) -> str:
    if value.startswith("artist:"):
        return value[len("artist:") :]
    return value


def genre_payloads(genres: Iterable[LibraryGenre]) -> list[dict[str, object]]:
    return [
        {
            "value": genre.value,
            "songCount": genre.song_count,
            "albumCount": genre.album_count,
        }
        for genre in genres
    ]


def album_list2_query_from_params(
    params: Mapping[str, list[str]],
    *,
    album_list_type: str,
    offset: int,
) -> AlbumListQuery | None:
    folded_type = album_list_type.casefold()
    if folded_type == "bygenre":
        return AlbumListQuery(
            genre_filters=(GenreStyleFilter(genre=require_param(params, "genre")),),
            offset=offset,
        )
    if folded_type == "starred":
        return AlbumListQuery(sort=ALBUM_LIST_SORT_STARRED, offset=offset)
    if folded_type == "alphabeticalbyname":
        return AlbumListQuery(sort=ALBUM_LIST_SORT_ALBUMS, offset=offset)
    if folded_type == "alphabeticalbyartist":
        return AlbumListQuery(sort=ALBUM_LIST_SORT_ARTIST, offset=offset)
    if folded_type == "newest":
        return AlbumListQuery(sort=ALBUM_LIST_SORT_RECENTLY_ADDED, offset=offset)
    if folded_type == "recent":
        return AlbumListQuery(sort=ALBUM_LIST_SORT_RECENT, offset=offset)
    if folded_type == "frequent":
        return AlbumListQuery(sort=ALBUM_LIST_SORT_FREQUENT, offset=offset)
    return None


def album_list2_summaries(
    database: Path,
    *,
    query: AlbumListQuery,
    size: int,
) -> list[AlbumSummary]:
    api = LibraryQueries(database)
    requested_size = size
    albums: list[AlbumSummary] = []
    offset = query.offset
    while len(albums) < requested_size:
        page_size = min(200, requested_size - len(albums))
        page = api.list_album_page(
            AlbumListQuery(
                artists=query.artists,
                album=query.album,
                root_positions=query.root_positions,
                genres=query.genres,
                styles=query.styles,
                genre_filters=query.genre_filters,
                is_playlist=query.is_playlist,
                size=page_size,
                offset=offset,
                search=query.search,
                sort=query.sort,
            )
        )
        albums.extend(page.items)
        if not page.has_next or not page.items:
            break
        offset += len(page.items)
    return albums


def album_list2_payloads(albums: Iterable[AlbumSummary]) -> list[dict[str, object]]:
    return [
        album_summary_payload(
            album_id=album.album_id,
            name=album.album,
            artist=album.artist,
            song_count=album.track_count,
            year=album.year,
            created=album.file_created_at,
            has_cover=False,
            art_track_id=album.art_track_id,
            genre=album.sort_genre,
        )
        for album in albums
    ]


def album_summary_payload(
    *,
    album_id: str,
    name: str,
    artist: str,
    song_count: int,
    year: int | None,
    created: object,
    has_cover: bool,
    art_track_id: int | None,
    genre: str | None = None,
) -> dict[str, object]:
    return without_none(
        {
            "id": album_id,
            "name": name,
            "artist": artist,
            "artistId": artist_id(artist),
            "coverArt": album_cover_art_id(album_id) if has_cover or art_track_id else None,
            "songCount": song_count,
            "created": str(created) if created else None,
            "year": year,
            "genre": genre,
        }
    )


def album_payload(album: Any, *, include_songs: bool = False) -> dict[str, object]:
    duration = sum(int(track.duration_seconds or 0) for track in album.tracks)
    payload = album_summary_payload(
        album_id=album.album_id,
        name=album.album,
        artist=album.artist,
        song_count=album.track_count,
        year=album.year,
        created=album.file_created_at,
        has_cover=album.has_cover,
        art_track_id=album.art_track_id,
    )
    payload.update(
        without_none(
            {
                "duration": duration,
                "genre": album.genres[0] if album.genres else None,
            }
        )
    )
    if include_songs:
        payload["song"] = [song_payload(track) for track in album.tracks]
    return payload


def song_payload(track: Any) -> dict[str, object]:
    track_id = int(track.track_id) if track.track_id is not None else None
    artist = track.artist or track.album_artist or album_artist_display_text(track.album_artists)
    album_artist = album_artist_display_text(track.album_artists)
    path = Path(track.path)
    return without_none(
        {
            "id": str(track_id) if track_id is not None else None,
            "parent": track.album_id,
            "isDir": False,
            "title": track.title or path.stem,
            "album": track.album,
            "artist": artist,
            "artistId": artist_id(artist),
            "albumArtist": album_artist,
            "albumArtistId": artist_id(album_artist),
            "albumId": track.album_id,
            "coverArt": (
                str(track_id)
                if track_id is not None and track.has_cover
                else album_cover_art_id(track.album_id)
                if track.album_id and track.has_cover
                else None
            ),
            "track": first_number(track.track_number),
            "discNumber": first_number(track.disc_number),
            "year": first_number(track.date),
            "genre": track.genres[0] if track.genres else None,
            "created": None,
            "duration": int(track.duration_seconds) if track.duration_seconds else None,
            "bitRate": bit_rate_kbps(track.bitrate),
            "size": file_size(path),
            "suffix": audio_suffix(track.file_type, path),
            "contentType": audio_mime_type(path),
            "path": track.path,
            "type": "music",
            "isVideo": False,
        }
    )


def cover_art_track_ids(database: Path, cover_id: str) -> tuple[int, ...]:
    if cover_id.startswith("album:"):
        album = LibraryQueries(database).get_album(cover_id[len("album:") :])
        return tuple(
            track_id
            for track_id in (
                album.art_track_id,
                *(track.track_id for track in album.tracks),
            )
            if track_id is not None
        )
    try:
        return (int(cover_id),)
    except ValueError as error:
        raise OpenSubsonicApiError(
            ERROR_NOT_FOUND,
            "The requested data was not found.",
        ) from error


def parse_byte_range(header: str | None, file_size: int) -> tuple[int, int] | None:
    if not header:
        return None
    match = BYTE_RANGE_RE.fullmatch(header.strip())
    if not match:
        return None
    start_text, end_text = match.groups()
    if not start_text and not end_text:
        return None
    if start_text:
        start = int(start_text)
        end = int(end_text) if end_text else file_size - 1
    else:
        suffix_length = int(end_text)
        if suffix_length <= 0:
            return None
        start = max(file_size - suffix_length, 0)
        end = file_size - 1
    end = min(end, file_size - 1)
    if start < 0 or start > end or start >= file_size:
        return None
    return start, end


def audio_file_response(path: Path) -> Response:
    return audio_resource_response(local_audio_resource(path))


def audio_resource_response(resource: AudioResource) -> Response:
    file_size, content_type = audio_resource_head(resource)
    byte_range = parse_byte_range(request.headers.get("Range"), file_size)
    if byte_range is None:
        start, end = 0, file_size - 1
        status = 200
    else:
        start, end = byte_range
        status = 206

    length = end - start + 1
    headers = {
        "Accept-Ranges": "bytes",
        "Content-Length": str(length),
    }
    if status == 206:
        headers["Content-Range"] = f"bytes {start}-{end}/{file_size}"

    if request.method == "HEAD":
        return Response(status=status, headers=headers, content_type=content_type)

    def stream_resource() -> Iterable[bytes]:
        try:
            yield from iter_audio_resource_bytes(resource, start=start, length=length)
        except (BrokenPipeError, ConnectionResetError):
            return

    return Response(
        stream_with_context(stream_resource()),
        status=status,
        headers=headers,
        content_type=content_type,
        direct_passthrough=True,
    )


def subsonic_success_response(payload: Mapping[str, object]) -> Response:
    return subsonic_response("ok", payload)


def subsonic_error_response(code: int, message: str) -> Response:
    return subsonic_response(
        "failed",
        {"error": {"code": code, "message": message}},
    )


def subsonic_response(status: str, payload: Mapping[str, object]) -> Response:
    if requested_response_format() == "json":
        return subsonic_json_response(status, payload)
    return subsonic_xml_response(status, payload)


def requested_response_format() -> str:
    response_format = first_param(request_parameters(), "f")
    if response_format is not None and response_format.casefold() != "xml":
        return "json"
    return "xml"


def subsonic_json_response(status: str, payload: Mapping[str, object]) -> Response:
    body = {
        "subsonic-response": {
            "status": status,
            "version": OPEN_SUBSONIC_PROTOCOL_VERSION,
            "type": OPEN_SUBSONIC_TYPE,
            "serverVersion": kukicha_server_version(),
            "openSubsonic": True,
            **payload,
        }
    }
    return Response(
        json.dumps(body, sort_keys=True),
        content_type="application/json; charset=utf-8",
    )


def subsonic_xml_response(status: str, payload: Mapping[str, object]) -> Response:
    attributes = {
        "xmlns": "http://subsonic.org/restapi",
        "status": status,
        "version": OPEN_SUBSONIC_PROTOCOL_VERSION,
        "type": OPEN_SUBSONIC_TYPE,
        "serverVersion": kukicha_server_version(),
        "openSubsonic": "true",
    }
    body = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f"<subsonic-response{xml_attributes(attributes)}>"
        f"{xml_children(payload)}"
        "</subsonic-response>"
    )
    return Response(body, content_type="text/xml; charset=utf-8")


def xml_children(value: object) -> str:
    if isinstance(value, Mapping):
        return "".join(xml_element(key, item) for key, item in value.items())
    if isinstance(value, list | tuple):
        return "".join(xml_children(item) for item in value)
    if value is None:
        return ""
    return escape(str(value))


def xml_element(name: str, value: object) -> str:
    if isinstance(value, Mapping):
        attributes: dict[str, object] = {}
        children: list[tuple[str, object]] = []
        for key, item in value.items():
            if item is None:
                continue
            if isinstance(item, Mapping) or isinstance(item, list | tuple):
                children.append((key, item))
            else:
                attributes[key] = xml_attribute_value(item)
        child_xml = "".join(xml_element(key, item) for key, item in children)
        if child_xml:
            return f"<{name}{xml_attributes(attributes)}>{child_xml}</{name}>"
        return f"<{name}{xml_attributes(attributes)}/>"
    if isinstance(value, list | tuple):
        return "".join(xml_element(name, item) for item in value)
    if value is None:
        return ""
    return f"<{name}>{escape(str(value))}</{name}>"


def xml_attributes(values: Mapping[str, object]) -> str:
    if not values:
        return ""
    return "".join(
        f" {name}={quoteattr(str(value))}"
        for name, value in values.items()
        if value is not None
    )


def xml_attribute_value(value: object) -> object:
    if isinstance(value, bool):
        return "true" if value else "false"
    return value


def kukicha_server_version() -> str:
    return kukicha_version()


def music_folder_name(path: str) -> str:
    name = Path(path).name
    return name or path


def artist_id(artist: str | None) -> str | None:
    return f"artist:{artist}" if artist else None


def album_cover_art_id(album_id: str | None) -> str | None:
    return f"album:{album_id}" if album_id else None


def first_number(value: str | None) -> int | None:
    if not value:
        return None
    match = re.search(r"\d+", value)
    return int(match.group(0)) if match else None


def bit_rate_kbps(value: int | None) -> int | None:
    if value is None:
        return None
    if value >= 1000:
        return int(value / 1000)
    return value


def file_size(path: Path) -> int | None:
    try:
        return path.stat().st_size
    except OSError:
        return None


def audio_suffix(file_type: str | None, path: Path) -> str | None:
    if file_type:
        return file_type.removeprefix(".")
    suffix = path.suffix.removeprefix(".")
    return suffix or None


def content_disposition_filename(value: str) -> str:
    return value.replace("\\", "_").replace('"', "_")


def without_none(values: Mapping[str, object | None]) -> dict[str, object]:
    return {key: value for key, value in values.items() if value is not None}
