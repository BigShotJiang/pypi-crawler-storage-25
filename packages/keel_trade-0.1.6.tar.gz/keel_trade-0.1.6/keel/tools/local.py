"""Local tool implementations using DSL subset + bundled data.

All functions in this module work without an API key. They use the bundled
registry.json to populate the ComponentRegistry, then call the same DSL
parser/validator/emitter that chat-api and keel-api use.
"""

from __future__ import annotations

from typing import Any

from keel.data.registry import (
    _ensure_loaded,
    get_component_detail as _get_detail,
    get_components_after as _get_after,
    get_components_before as _get_before,
    get_components_dump as _get_dump,
    search_components as _search,
)


def _ensure_registry():
    """Ensure the component registry is loaded from bundled JSON."""
    _ensure_loaded()


# ═══════════════════════════════════════════════════════════════════════════════
# COMPONENT TOOLS
# ═══════════════════════════════════════════════════════════════════════════════


def strategy_components_search(**kwargs) -> list[dict[str, Any]]:
    """Search components by criteria."""
    _ensure_registry()
    return _search(**kwargs)


def strategy_component_detail(name: str, component_lock: dict[str, int] | None = None) -> dict[str, Any]:
    """Get full specification for a component."""
    _ensure_registry()
    return _get_detail(name, component_lock)


def strategy_components_after(name: str) -> list[dict[str, Any]]:
    """Find components that can follow a given component."""
    _ensure_registry()
    return _get_after(name)


def strategy_components_before(name: str) -> list[dict[str, Any]]:
    """Find components that can precede a given component."""
    _ensure_registry()
    return _get_before(name)


def strategy_components_dump() -> list[dict[str, Any]]:
    """Bulk dump of all components."""
    _ensure_registry()
    return _get_dump()


def dsl_reference(topic: str | None = None) -> dict[str, Any]:
    """Load DSL reference documentation."""
    from keel.data.reference import load_reference

    return load_reference(topic)


# ═══════════════════════════════════════════════════════════════════════════════
# STRATEGY TOOLS
# ═══════════════════════════════════════════════════════════════════════════════


def strategy_validate(
    source: str,
    component_lock: dict[str, int] | None = None,
    **kwargs,
) -> dict[str, Any]:
    """Validate a strategy source — full 9-pass validation."""
    _ensure_registry()

    from pipeline_engine.dsl import parse_strategy, validate_strategy
    from pipeline_engine.dsl.parser import DSLParseError

    try:
        parsed = parse_strategy(source)
    except DSLParseError as e:
        return {
            "valid": False,
            "issues": [{"severity": "error", "message": str(e)}],
            "errors": [{"severity": "error", "message": str(e)}],
            "warnings": [],
            "type_flow": [],
        }

    result = validate_strategy(parsed, lock=component_lock)

    errors = [i.to_dict() for i in result.errors]
    warnings = [i.to_dict() for i in result.warnings]
    info = [i.to_dict() for i in result.info]

    # Build globals dict
    globals_dict: dict[str, Any] | None = None
    if parsed.globals_:
        globals_dict = {
            k: v
            for k, v in vars(parsed.globals_).items()
            if k != "location" and v is not None
        }

    # Build universe dict
    universe_dict: dict[str, Any] | None = None
    if parsed.universe:
        universe_dict = _universe_to_dict(parsed.universe)

    return {
        "valid": result.valid,
        "issues": errors + warnings,
        "errors": errors,
        "warnings": warnings,
        "info": info,
        "type_flow": [e.to_dict() for e in result.type_flow],
        "pipeline_summary": result.pipeline_summary,
        "component_lock": component_lock,
        "globals": globals_dict,
        "universe": universe_dict,
    }


def strategy_explain(
    source: str,
    component_lock: dict[str, int] | None = None,
    **kwargs,
) -> dict[str, Any]:
    """Explain a strategy's structure — lightweight version using parser + registry.

    This is a reimplementation of pipeline_engine.dsl.explainer without
    the describe_step/registry_loader/introspection imports.
    """
    _ensure_registry()

    from pipeline_engine.base.registry import get_latest, get_version
    from pipeline_engine.dsl import parse_strategy, validate_strategy
    from pipeline_engine.dsl.parser import DSLParseError
    from pipeline_engine.dsl.spec import (
        ComponentRef,
        FactoryCallSpec,
        ParallelSpec,
        PipelineSpec,
        SlotLoadSpec,
        SlotStoreSpec,
        SlotStoreValueSpec,
        VariableRef,
    )
    from pipeline_engine.validation_shared import type_name

    try:
        parsed = parse_strategy(source)
    except DSLParseError as e:
        return {
            "strategy_name": None,
            "step_count": 0,
            "valid": False,
            "issues": [{"severity": "error", "message": str(e)}],
            "type_flow": [],
            "slot_usage": {"stores": [], "loads": []},
            "factories": [],
            "variables": [],
            "steps": [],
            "summary": f"Parse error: {e}",
        }

    result = validate_strategy(parsed, lock=component_lock)

    def _serialize_args(args):
        out = {}
        for k, v in args.items():
            if isinstance(v, VariableRef):
                out[k] = f"${v.name}"
            else:
                out[k] = v
        return out

    def _explain_step(step):
        if isinstance(step, ComponentRef):
            info = {
                "type": "component",
                "name": step.name,
                "params": _serialize_args(step.params),
            }
            lock = component_lock or {}
            if step.name in lock:
                sig = get_version(step.name, lock[step.name])
                if sig is None:
                    sig = get_latest(step.name)
            else:
                sig = get_latest(step.name)
            if sig:
                info["category"] = sig.category.value
                info["input_type"] = type_name(sig.input_type)
                info["output_type"] = type_name(sig.output_type)
                info["description"] = (sig.description or "").strip().split("\n\n")[0].strip()
            else:
                info["category"] = "unknown"
                info["description"] = f"Component '{step.name}' not found"
            return info
        elif isinstance(step, ParallelSpec):
            return {
                "type": "parallel",
                "branch_count": len(step.branches),
                "branches": {
                    n: [_explain_step(s) for s in steps]
                    for n, steps in step.branches.items()
                },
            }
        elif isinstance(step, PipelineSpec):
            return {
                "type": "pipeline",
                "name": step.name,
                "steps": [_explain_step(s) for s in step.steps],
            }
        elif isinstance(step, SlotStoreSpec):
            return {"type": "store", "slot_name": step.slot_name}
        elif isinstance(step, SlotStoreValueSpec):
            return {"type": "store_value", "slot_name": step.slot_name, "value": step.value}
        elif isinstance(step, SlotLoadSpec):
            return {"type": "load", "slot_name": step.slot_name}
        elif isinstance(step, FactoryCallSpec):
            return {"type": "factory_call", "name": step.name, "args": _serialize_args(step.args)}
        elif isinstance(step, VariableRef):
            return {"type": "variable_ref", "name": step.name}
        else:
            return {"type": "unknown"}

    def _count_steps(steps):
        count = 0
        for step in steps:
            count += 1
            if isinstance(step, ParallelSpec):
                for bs in step.branches.values():
                    count += _count_steps(bs)
            elif isinstance(step, PipelineSpec):
                count += _count_steps(step.steps)
        return count

    stores, loads = [], []

    def _collect_slots(steps):
        for step in steps:
            if isinstance(step, SlotStoreSpec):
                stores.append(step.slot_name)
            elif isinstance(step, SlotStoreValueSpec):
                stores.append(step.slot_name)
            elif isinstance(step, SlotLoadSpec):
                loads.append(step.slot_name)
            elif isinstance(step, ParallelSpec):
                for bs in step.branches.values():
                    _collect_slots(bs)
            elif isinstance(step, PipelineSpec):
                _collect_slots(step.steps)

    _collect_slots(parsed.pipeline.steps)
    steps_explained = [_explain_step(s) for s in parsed.pipeline.steps]
    step_count = _count_steps(parsed.pipeline.steps)
    strategy_name = parsed.metadata.get("name")

    factories = [
        {
            "name": f.name,
            "params": [{"name": p.name, "default": p.default} for p in f.params],
            "step_count": _count_steps(f.body.steps),
        }
        for f in parsed.factories
    ]

    variables = [
        {"name": v.name, "is_pipeline": isinstance(v.value, PipelineSpec)}
        for v in parsed.variables
    ]

    summary_parts = [f"Strategy '{strategy_name or 'unnamed'}': {step_count} steps"]
    if factories:
        summary_parts.append(f"{len(factories)} factories")
    if variables:
        summary_parts.append(f"{len(variables)} variables")
    if stores:
        summary_parts.append(f"stores: {', '.join(sorted(set(stores)))}")
    if loads:
        summary_parts.append(f"loads: {', '.join(sorted(set(loads)))}")
    summary_parts.append("valid" if result.valid else f"{len(result.errors)} errors")

    return {
        "strategy_name": strategy_name,
        "step_count": step_count,
        "valid": result.valid,
        "issues": [i.to_dict() for i in result.errors + result.warnings],
        "type_flow": [e.to_dict() for e in result.type_flow],
        "slot_usage": {"stores": sorted(set(stores)), "loads": sorted(set(loads))},
        "factories": factories,
        "variables": variables,
        "steps": steps_explained,
        "summary": " | ".join(summary_parts),
    }


def strategy_diff(source_a: str, source_b: str) -> dict[str, Any]:
    """Structural diff between two strategies."""
    _ensure_registry()

    from pipeline_engine.dsl.differ import diff_strategies

    return diff_strategies(source_a=source_a, source_b=source_b)


def pipeline_stage(source: str) -> dict[str, Any]:
    """Assess pipeline completeness toward backtest readiness.

    Lightweight reimplementation: parse + validate type flow,
    then map each step's output type to a readiness stage.
    """
    _ensure_registry()

    from pipeline_engine.dsl import parse_strategy, validate_strategy
    from pipeline_engine.dsl.parser import DSLParseError

    try:
        parsed = parse_strategy(source)
    except DSLParseError as e:
        return {"stage": "unparseable", "error": str(e)}

    result = validate_strategy(parsed)

    if not result.valid:
        return {
            "stage": "invalid",
            "errors": [i.to_dict() for i in result.errors],
        }

    # Map the final output type to a readiness stage
    stage_map = {
        "OHLCVDict": "data",
        "StreamSeries": "data",
        "SignalSeries": "signal",
        "NormalizedSignal": "signal",
        "BinarySignal": "signal",
        "RankSignal": "signal",
        "ForecastSeries": "forecast",
        "WeightSeries": "portfolio",
        "OrderSeries": "execution",
    }

    final_type = "unknown"
    if result.type_flow:
        final_type = result.type_flow[-1].output_type

    stage = stage_map.get(final_type, "unknown")
    backtest_ready = stage in ("portfolio", "execution")

    return {
        "stage": stage,
        "final_output_type": final_type,
        "backtest_ready": backtest_ready,
        "step_count": len(result.type_flow),
        "type_flow": [e.to_dict() for e in result.type_flow],
    }


def strategy_examples(**kwargs) -> dict[str, Any]:
    """Browse or search strategy examples."""
    from keel.data.examples import strategy_examples as _examples

    return _examples(**kwargs)


def composition_patterns(query: str) -> dict[str, Any]:
    """Search composition patterns by query."""
    from keel.data.patterns import search_patterns

    patterns = search_patterns(query)
    return {"patterns": patterns, "query": query, "match_count": len(patterns)}


def strategy_new_inline(
    name: str,
    template: str = "basic",
    strategy_dir: str | None = None,
) -> dict[str, Any]:
    """Create a new strategy from a template."""
    from keel.data.templates import create_from_template

    return create_from_template(name, template, strategy_dir)


# ═══════════════════════════════════════════════════════════════════════════════
# UNIVERSE TOOLS
# ═══════════════════════════════════════════════════════════════════════════════


def universe_set(
    source: str,
    mode: str,
    market: str = "perp",
    symbols: list[str] | None = None,
    categories: list[str] | None = None,
    top_n: int | None = None,
    exclusions: list[str] | None = None,
    inclusions: list[str] | None = None,
) -> dict[str, Any]:
    """Set or replace universe criteria on a strategy."""
    _ensure_registry()

    from pipeline_engine.dsl import parse_strategy
    from pipeline_engine.dsl.emitter import spec_to_dsl
    from pipeline_engine.dsl.spec import UniverseSpec

    parsed = parse_strategy(source)

    parsed.universe = UniverseSpec(
        mode=mode,
        market=market,
        symbols=symbols or [],
        categories=categories or [],
        top_n=top_n,
        exclusions=exclusions or [],
        inclusions=inclusions or [],
    )

    new_source = spec_to_dsl(parsed)
    return {"source": new_source, "universe": _universe_to_dict(parsed.universe)}


def universe_get(source: str) -> dict[str, Any]:
    """Read universe configuration from a strategy."""
    _ensure_registry()

    from pipeline_engine.dsl import parse_strategy

    parsed = parse_strategy(source)
    if parsed.universe is None:
        return {"universe": None}
    return {"universe": _universe_to_dict(parsed.universe)}


def universe_add_group(
    source: str,
    name: str,
    symbols: list[str] | None = None,
) -> dict[str, Any]:
    """Add a named group to the universe."""
    _ensure_registry()

    from pipeline_engine.dsl import parse_strategy
    from pipeline_engine.dsl.emitter import spec_to_dsl

    parsed = parse_strategy(source)
    if parsed.universe is None:
        from pipeline_engine.dsl.spec import UniverseSpec

        parsed.universe = UniverseSpec(mode="manual", market="perp")

    if parsed.universe.groups is None:
        parsed.universe.groups = {}

    if name in parsed.universe.groups:
        raise ValueError(f"Group '{name}' already exists")

    parsed.universe.groups[name] = symbols or []

    new_source = spec_to_dsl(parsed)
    return {"source": new_source, "universe": _universe_to_dict(parsed.universe)}


def universe_modify_group(
    source: str,
    name: str,
    add: list[str] | None = None,
    remove: list[str] | None = None,
) -> dict[str, Any]:
    """Modify an existing universe group."""
    _ensure_registry()

    from pipeline_engine.dsl import parse_strategy
    from pipeline_engine.dsl.emitter import spec_to_dsl

    parsed = parse_strategy(source)
    if parsed.universe is None or parsed.universe.groups is None:
        raise ValueError("No universe groups defined")
    if name not in parsed.universe.groups:
        raise ValueError(f"Group '{name}' not found")

    current = list(parsed.universe.groups[name])
    if add:
        current.extend(s for s in add if s not in current)
    if remove:
        current = [s for s in current if s not in remove]
    parsed.universe.groups[name] = current

    new_source = spec_to_dsl(parsed)
    return {"source": new_source, "universe": _universe_to_dict(parsed.universe)}


def universe_remove_group(source: str, name: str) -> dict[str, Any]:
    """Remove a named group from the universe."""
    _ensure_registry()

    from pipeline_engine.dsl import parse_strategy
    from pipeline_engine.dsl.emitter import spec_to_dsl

    parsed = parse_strategy(source)
    if parsed.universe is None or parsed.universe.groups is None:
        raise ValueError("No universe groups defined")
    if name not in parsed.universe.groups:
        raise ValueError(f"Group '{name}' not found")

    del parsed.universe.groups[name]

    new_source = spec_to_dsl(parsed)
    return {"source": new_source, "universe": _universe_to_dict(parsed.universe)}


def _universe_to_dict(uni) -> dict[str, Any]:
    """Convert UniverseSpec to a serializable dict."""
    d: dict[str, Any] = {"mode": uni.mode, "market": uni.market}
    if uni.symbols:
        d["symbols"] = uni.symbols
    if uni.categories:
        d["categories"] = uni.categories
    if uni.top_n is not None:
        d["top_n"] = uni.top_n
    if uni.exclusions:
        d["exclusions"] = uni.exclusions
    if uni.inclusions:
        d["inclusions"] = uni.inclusions
    if getattr(uni, "resolved", None):
        d["resolved"] = uni.resolved
    if getattr(uni, "resolved_at", None):
        d["resolved_at"] = uni.resolved_at
    if uni.groups:
        d["groups"] = uni.groups
    return d


# ═══════════════════════════════════════════════════════════════════════════════
# LOCK TOOLS (local — generate lock from bundled registry)
# ═══════════════════════════════════════════════════════════════════════════════


def strategy_lock_generate(source: str) -> dict[str, Any]:
    """Generate a component lock from a strategy source."""
    _ensure_registry()

    from pipeline_engine.base.registry import get_latest
    from pipeline_engine.dsl import parse_strategy
    from pipeline_engine.dsl.spec import ComponentRef, ParallelSpec, PipelineSpec

    parsed = parse_strategy(source)
    lock: dict[str, int] = {}

    def _walk(steps):
        for step in steps:
            if isinstance(step, ComponentRef):
                sig = get_latest(step.name)
                if sig:
                    lock[step.name] = sig.version
            elif isinstance(step, ParallelSpec):
                for branch_steps in step.branches.values():
                    _walk(branch_steps)
            elif isinstance(step, PipelineSpec):
                _walk(step.steps)

    _walk(parsed.pipeline.steps)
    for factory in parsed.factories:
        _walk(factory.body.steps)

    return {"component_lock": lock}


def strategy_lock_status(
    source: str, component_lock: dict[str, int] | None = None
) -> dict[str, Any]:
    """Check component version drift against current registry."""
    _ensure_registry()

    if component_lock is None:
        return {"status": "unknown", "message": "No component lock provided"}

    from pipeline_engine.base.registry import get_latest

    drift = []
    for name, locked_version in component_lock.items():
        sig = get_latest(name)
        if sig is None:
            drift.append({"name": name, "locked": locked_version, "latest": None, "status": "unknown"})
        elif sig.version != locked_version:
            drift.append({
                "name": name,
                "locked": locked_version,
                "latest": sig.version,
                "status": "drift",
            })

    status = "current" if not drift else "drift"
    return {"status": status, "drift": drift, "component_lock": component_lock}


def strategy_lock_upgrade(
    source: str,
    component_lock: dict[str, int] | None = None,
    components: list[str] | None = None,
) -> dict[str, Any]:
    """Upgrade component versions in a lock."""
    _ensure_registry()

    if component_lock is None:
        result = strategy_lock_generate(source)
        return {
            "component_lock": result["component_lock"],
            "upgraded": list(result["component_lock"].keys()),
        }

    from pipeline_engine.base.registry import get_latest

    new_lock = dict(component_lock)
    upgraded = []
    targets = components or list(component_lock.keys())

    for name in targets:
        if name not in new_lock:
            continue
        sig = get_latest(name)
        if sig and sig.version != new_lock[name]:
            new_lock[name] = sig.version
            upgraded.append(name)

    return {"component_lock": new_lock, "upgraded": upgraded}


# ═══════════════════════════════════════════════════════════════════════════════
# WORKSPACE TOOLS
# ═══════════════════════════════════════════════════════════════════════════════


def strategy_checkout(strategy_id: str) -> dict[str, Any]:
    """Check out a platform strategy for local editing."""
    from keel.workspace import checkout

    return checkout(strategy_id)


def strategy_push(
    strategy_id: str | None = None,
    message: str | None = None,
    force: bool = False,
) -> dict[str, Any]:
    """Push local changes to the platform."""
    from keel.workspace import push

    return push(strategy_id=strategy_id, message=message, force=force)


def strategy_pull(strategy_id: str | None = None) -> dict[str, Any]:
    """Pull latest source from the platform."""
    from keel.workspace import pull

    return pull(strategy_id=strategy_id)


def strategy_status(strategy_id: str | None = None) -> dict[str, Any]:
    """Show local vs remote sync state."""
    from keel.workspace import status

    return status(strategy_id=strategy_id)


def strategy_workspaces() -> dict[str, Any]:
    """List all checked-out strategies."""
    from keel.workspace import list_workspaces

    workspaces = list_workspaces()
    return {
        "workspaces": [
            {
                "strategy_id": ws.strategy_id,
                "name": ws.name,
                "source_hash": ws.source_hash[:12],
                "checked_out_at": ws.checked_out_at,
            }
            for ws in workspaces
        ],
        "count": len(workspaces),
    }


def strategy_discard(strategy_id: str | None = None) -> dict[str, Any]:
    """Remove a local workspace."""
    from keel.workspace import discard

    return discard(strategy_id=strategy_id)


def strategy_find_local(directory: str | None = None) -> dict[str, Any]:
    """Find local strategy files and list checked-out workspaces.

    Scans ~/.keel/strategies/ (where 'keel strategy new' writes files),
    the current working directory, and an optional extra directory for .py
    and .strategy files that contain Pipeline definitions. Also lists any
    strategies checked out to ~/.keel/workspace/.

    Call this FIRST when looking for strategies — before strategy_list
    which requires authentication.
    """
    from pathlib import Path

    keel_strategies_dir = Path.home() / ".keel" / "strategies"
    cwd = Path.cwd()

    # Collect unique directories to scan
    scan_dirs: list[Path] = []
    if keel_strategies_dir.is_dir():
        scan_dirs.append(keel_strategies_dir)
    if cwd != keel_strategies_dir:
        scan_dirs.append(cwd)
    if directory:
        extra = Path(directory)
        if extra.is_dir() and extra not in scan_dirs:
            scan_dirs.append(extra)

    local_files = []
    seen_paths: set[str] = set()

    for search_dir in scan_dirs:
        for pattern in ("*.py", "*.strategy"):
            for f in sorted(search_dir.glob(pattern)):
                path_str = str(f.resolve())
                if path_str in seen_paths:
                    continue
                seen_paths.add(path_str)
                try:
                    content = f.read_text(errors="ignore")
                    if "Pipeline(" in content or "pipeline" in content.lower():
                        local_files.append({
                            "path": str(f),
                            "name": f.stem,
                            "size": f.stat().st_size,
                            "location": str(search_dir),
                        })
                except OSError:
                    continue

    # Also check workspaces
    workspaces = []
    try:
        from keel.workspace import list_workspaces

        for ws in list_workspaces():
            workspaces.append({
                "strategy_id": ws.strategy_id,
                "name": ws.name,
                "source_hash": ws.source_hash[:12],
            })
    except Exception:
        pass

    return {
        "local_files": local_files,
        "workspaces": workspaces,
        "scanned_directories": [str(d) for d in scan_dirs],
    }
