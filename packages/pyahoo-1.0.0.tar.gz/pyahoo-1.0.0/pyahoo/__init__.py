"""
pyahoo - A full-featured Python wrapper for Yahoo Finance APIs.

Example
-------
Sync::
>>> from pyahoo import YahooFinance
>>> with YahooFinance as yf:
...     quotes = yf.quote("AAPL", "NVDA")
...     for q in quotes:
...         print(f"{q.symbol}: ${q.regular_market_price}")

Async::
>>> from pyahoo import AsyncYahooFinance
>>> async with AsyncYahooFinance() as yf:   
...     quotes = await yf.quote("AAPL", "NVDA")
"""

from __future__ import annotations

__version__ = "1.0.0"

from pyahoo._types import TrackedList
from pyahoo.async_client import AsyncYahooFinance
from pyahoo.async_websocket import AsyncWebSocket
from pyahoo.client import YahooFinance
from pyahoo.enums import (CalendarModule, ChartEvent, Interval, MarketState,
                          PredictionSortKey, QueryOperator, QuoteSummaryModule,
                          QuoteType, Range, ScreenerId, SortType,
                          StreamingMarketHours, StreamingOptionType,
                          StreamingQuoteType)
from pyahoo.exceptions import (APIError, AuthenticationError, NotFoundError,
                               PyahooError, RateLimitError, StreamingError)
from pyahoo.models import (OHLCV, AnalystRating, CalendarEvent, ChartMeta,
                           ChartResult, CompanySnapshot, DividendEvent,
                           FormattedValue, InsightResult, KeyTechnicals,
                           OptionContract, OptionsChain, PredictionEvent,
                           PredictionOutcome, PricingData, Quote,
                           QuoteSummaryResult, QuoteTypeResult, RatingResult,
                           RecommendedSymbol, ResearchReport, ScreenerQuote,
                           ScreenerResult, SearchNewsResult, SearchQuoteResult,
                           SearchResult, Sector, SectorReturns, SparkResult,
                           SplitEvent, TechnicalOutlook, TimeseriesDataPoint,
                           TimeseriesResult, TrendingQuote, TrendingResult,
                           Valuation, YahooModel)
from pyahoo.websocket import WebSocket

__all__ = [
    # Clients
    "YahooFinance",
    "AsyncYahooFinance",
    # Streaming
    "AsyncWebSocket",
    "WebSocket",
    # Types
    "TrackedList",
    # Enums
    "CalendarModule",
    "ChartEvent",
    "Interval",
    "MarketState",
    "PredictionSortKey",
    "QueryOperator",
    "QuoteSummaryModule",
    "QuoteType",
    "Range",
    "ScreenerId",
    "SortType",
    "StreamingMarketHours",
    "StreamingOptionType",
    "StreamingQuoteType",
    # Exceptions
    "APIError",
    "AuthenticationError",
    "NotFoundError",
    "PyahooError",
    "RateLimitError",
    "StreamingError",
    # Models
    "AnalystRating",
    "CalendarEvent",
    "ChartMeta",
    "ChartResult",
    "CompanySnapshot",
    "DividendEvent",
    "FormattedValue",
    "InsightResult",
    "KeyTechnicals",
    "OHLCV",
    "OptionContract",
    "OptionsChain",
    "PredictionEvent",
    "PredictionOutcome",
    "PricingData",
    "Quote",
    "QuoteSummaryResult",
    "QuoteTypeResult",
    "RatingResult",
    "RecommendedSymbol",
    "ResearchReport",
    "ScreenerQuote",
    "ScreenerResult",
    "SearchNewsResult",
    "SearchQuoteResult",
    "SearchResult",
    "Sector",
    "SectorReturns",
    "SparkResult",
    "SplitEvent",
    "TechnicalOutlook",
    "TimeseriesDataPoint",
    "TimeseriesResult",
    "TrendingQuote",
    "TrendingResult",
    "Valuation",
    "YahooModel"
]