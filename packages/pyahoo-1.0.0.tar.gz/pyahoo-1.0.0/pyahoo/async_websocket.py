"""
Asynchronous Yahoo Finance WebSocket client.

Connects to Yahoo Finance WebSocket and yields real-time `pyahoo.models.
streaming.PricingData` ticks as an async iterator.

Example
-------
>>> import asyncio
>>> from pyahoo import AsyncWebSocket
>>> async def main():
...     async with AsyncWebSocket() as ws:
...         await ws.subscribe("AAPL", "MSFT", "NVDA")
...         async for tick in ws:
...             print(tick)
>>> asyncio.run(main())
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Callable

from pyahoo._constants import (FINANCE_HOME, STREAMER_RECONNECT_BASE,
                               STREAMER_RECONNECT_MAX, STREAMER_URL,
                               STREAMER_VERSION, _random_user_agent)
from pyahoo.exceptions import StreamingError
from pyahoo.models.streaming import PricingData

logger = logging.getLogger(__name__)

TickCallback = Callable[[PricingData], Any]
ErrorCallback = Callable[[Exception], Any]
LifecycleCallback = Callable[[], Any]


class AsyncWebSocket:
    """
    Asynchronous Yahoo Finance WebSocket client.

    Connects to the Yahoo Finance WebSocket and streams decoded
    `PricingData` ticks. Supports async iteration, callbacks,
    dynamic subscribe/unsubscribe, and automatic reconnection.

    Parameters
    ----------
    url : str, optional
        WebSocket URL, by default `STREAMER_URL`.
    version : int, optional
        API version parameter, by default `STREAMER_VERSION`.
    reconnect : bool, optional
        Whether to auto-reconnect on disconnection, by default True.
    reconnect_base : float, optional
        Base delay for exponential backoff (seconds), by default `STREAMER_RECONNECT_BASE`.
    reconnect_max : float, optional
        Maximum reconnect delay (seconds), by default `STREAMER_RECONNECT_MAX`.
    max_reconnect_attempts : int | None, optional
        Maximum reconnection attempts, or `None` for unlimited.
    proxy : str | None, optional
        Proxy URL.
    queue_size : int, optional
        Maximum number of ticks buffered for iteration, by default `10_000`.

    Example
    -------
    >>> async with AsyncWebSocket() as ws:
    ...     await ws.subscribe("AAPL", "MSFT")
    ...     async for tick in ws:
    ...         print(tick)
    """

    def __init__(
        self,
        *,
        url: str = STREAMER_URL,
        version: int = STREAMER_VERSION,
        reconnect: bool = True,
        reconnect_base: float = STREAMER_RECONNECT_BASE,
        reconnect_max: float = STREAMER_RECONNECT_MAX,
        max_reconnect_attempts: int | None = None,
        proxy: str | None = None,
        queue_size: int = 10_000
    ) -> None:
        self._url = f"{url}?version={version}"
        self._proxy = proxy
        self._reconnect = reconnect
        self._reconnect_base = reconnect_base
        self._reconnect_max = reconnect_max
        self._max_reconnect_attempts = max_reconnect_attempts

        self._ws: Any = None
        self._running = False
        self._closed = False
        self._symbols: set[str] = set()
        self._reconnect_attempts = 0

        self._tick_callbacks: list[tuple[TickCallback, set[str] | None]] = []
        self._error_callbacks: list[tuple[ErrorCallback, tuple[type[Exception], ...] | None]] = []
        self._connect_callbacks: list[LifecycleCallback] = []
        self._disconnect_callbacks: list[LifecycleCallback] = []

        self._queue: asyncio.Queue[PricingData | None] = asyncio.Queue(maxsize=queue_size)
        self._run_task: asyncio.Task[None] | None = None

    def __repr__(self) -> str:
        status = "connected" if self.connected else "disconnected"
        return f"AsyncWebSocket({status}, {len(self._symbols)} symbols)"

    async def __aenter__(self) -> AsyncWebSocket:
        await self.connect()
        return self
    
    async def __aexit__(self, *exc: object) -> None:
        await self.close()

    def __aiter__(self) -> AsyncWebSocket:
        if self._run_task is None or self._run_task.done():
            self._run_task = asyncio.ensure_future(self.run())
        return self
    
    async def __anext__(self) -> PricingData:
        tick = await self._queue.get()
        if tick is None:
            raise StopAsyncIteration
        return tick
    
    @staticmethod
    def _matches_exception_filter(
        error: Exception,
        exc_filter: tuple[type[Exception], ...] | None
    ) -> bool:
        """
        Return True if *error* passes *exc_filter*.

        Parameters
        ----------
        error : Exception
            The exception to check.
        exc_filter : tuple[type[Exception], ...] | None
            The exception filter.
        
        Returns
        -------
        bool
            True if *error* passes *exc_filter*, False otherwise.
        """
        if exc_filter is None:
            return True
        for entry in exc_filter:
            if isinstance(entry, type) and isinstance(error, entry):
                return True
            if isinstance(entry, str) and entry == type(error).__name__:
                return True
        return False

    @staticmethod
    def _resolve_exception_filter(
        exceptions: type[Exception] | list[type[Exception]] | str | list[str] | None
    ) -> tuple[type[Exception], ...] | None:
        """
        Normalize the *exception* parameter into a tuple of types or `None`.

        Parameters
        ----------
        exceptions : type[Exception] | list[type[Exception]] | str | list[str] | None
            Exception types to filter by. Accepts a single exception class, a
            list of exception classes, a single class name as a string, or a 
            list of class name strings. If `None` (default), the callback
            receives **all** exceptions.

        Returns
        -------
        tuple[type[Exception], ...] | None
            A tuple of exception types, or `None` if no filter is applied.
        """
        if exceptions is None:
            return None
        if isinstance(exceptions, type) and issubclass(exceptions, BaseException):
            return (exceptions,)
        if isinstance(exceptions, str):
            return (exceptions,)
        if isinstance(exceptions, list):
            resolved: list[type[Exception] | str] = []
            for item in exceptions:
                if isinstance(item, type) and issubclass(item, BaseException):
                    resolved.append(item)
                elif isinstance(item, str):
                    resolved.append(item)
                else:
                    raise TypeError(
                        f"Expected an exception class or string, got {type(item).__name__}"
                    )
            return tuple(resolved)
        raise TypeError(
            f"Expected an exception class, string, or list thereof, got {type(exceptions).__name__}"
        )
    
    @staticmethod
    def _decode_message(message: str | bytes) -> PricingData | None:
        """
        Decode a Yahoo WebSocket message into a `PricingData` tick.

        Messages arrive as JSON strings:

            {"type": "pricing", "message": "<base64-encoded-protobuf>"}

        Parameters
        ----------
        message : str | bytes
            The message to decode.

        Returns
        -------
        PricingData | None
            The decoded `PricingData` tick, or None if the message is not a pricing message.
        """
        if isinstance(message, bytes):
            message = message.decode("utf-8")

        data = json.loads(message)
        if data.get("type") != "pricing":
            logger.debug(f"Ignoring non-pricing message: {data.get('type')}")
            return None
        
        b64_payload = data.get("message")
        if not b64_payload:
            return None
        
        return PricingData.from_base64(b64_payload)

    @property
    def symbols(self) -> frozenset[str]:
        """Currently subscribed symbols."""
        return frozenset(self._symbols)
    
    @property
    def connected(self) -> bool:
        """Whether the WebSocket is currently connected."""
        return self._ws is not None and not self._closed
    
    async def _fire_error(self, error: Exception) -> None:
        """
        Fire an error event to all registered callbacks.

        Parameters
        ----------
        error : Exception
            The error to fire.
        """
        for cb, exc_filter in self._error_callbacks:
            if not self._matches_exception_filter(error, exc_filter):
                continue
            try:
                result = cb(error)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as exc:
                logger.warning(f"Error callback raised exception: {exc}")

    async def _do_reconnect(self) -> None:
        """Reconnect with WebSocket."""
        while self._running and not self._closed:
            self._reconnect_attempts += 1
            if (
                self._max_reconnect_attempts is not None
                and self._reconnect_attempts > self._max_reconnect_attempts
            ):
                logger.error("Max reconnect attempts exceeded")
                self._running = False
                await self._queue.put(None)
                return
            delay = min(
                self._reconnect_base * (2 ** (self._reconnect_attempts - 1)),
                self._reconnect_max
            )
            logger.info(f"Reconnecting in {delay:.1f}s (attempt {self._reconnect_attempts})...")
            await asyncio.sleep(delay)
            try:
                await self.connect()
                return
            except Exception as exc:
                await self._fire_error(exc)

    async def _fire_lifecycle(self, callbacks: list[LifecycleCallback]) -> None:
        """
        Fire a lifecycle event to all registered callbacks.

        Parameters
        ----------
        callbacks : list[LifecycleCallback]
            The callbacks to fire.
        """
        for cb in callbacks:
            try:
                result = cb()
                if asyncio.iscoroutine(result):
                    await result
            except Exception as exc:
                await self._fire_error(exc)

    async def _send_subscribe(self, symbols: list[str]) -> None:
        """
        Send a subscribe message to the WebSocket.

        Parameters
        ----------
        symbols : list[str]
            The symbols to subscribe to.

        Raises
        ------
        StreamingError
            If sending the subscribe message fails.
        """
        msg = json.dumps({"subscribe": symbols})
        try:
            await self._ws.send(msg)
        except Exception as exc:
            raise StreamingError(f"Failed to send subscribe message: {exc}") from exc
        
    async def _send_unsubscribe(self, symbols: list[str]) -> None:
        """
        Send an unsubscribe message to the WebSocket.

        Parameters
        ----------
        symbols : list[str]
            The symbols to unsubscribe from.

        Raises
        ------
        StreamingError
            If sending the unsubscribe message fails.
        """
        msg = json.dumps({"subscribe": symbols})
        try:
            await self._ws.send(msg)
        except Exception as exc:
            raise StreamingError(f"Failed to send unsubscribe message: {exc}") from exc

    async def _dispatch_tick(self, tick: PricingData) -> None:
        """
        Dispatch a tick to all registered callbacks.

        Parameters
        ----------
        tick : PricingData
            The tick to dispatch.
        """
        await self._queue.put(tick)
        for cb, sym_filter in self._tick_callbacks:
            if sym_filter is not None and tick.id not in sym_filter:
                continue
            try:
                result = cb(tick)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as exc:
                await self._fire_error(exc)

    async def _receive_loop(self) -> None:
        """Receive messages from the WebSocket and dispatch them."""
        if self._ws is None:
            raise StreamingError("WebSocket is not connected")
        async for message in self._ws:
            if not self._running:
                break
            try:
                tick = self._decode_message(message)
                if tick is not None:
                    await self._dispatch_tick(tick)
            except Exception as exc:
                logger.debug(f"Failed to decode message: {exc}")
                await self._fire_error(exc)

    def on_tick(
        self,
        callback: TickCallback | None = None,
        *,
        symbols: list[str] | str | None = None
    ) -> TickCallback | Callable[[TickCallback], TickCallback]:
        """
        Register a callback for price ticks.

        Parameters
        ----------
        callback : TickCallback | None, optional
            The callback to register. May be either async or sync.
            If None, a decorator is returned.
        symbols : list[str] | str | None, optional
            Symbols to filter ticks by. If None, all ticks are processed.

        Returns
        -------
        TickCallback | Callable[[TickCallback], TickCallback]
            If callback is provided, returns the callback. If None, returns a
            decorator that can be used to register the callback.

        Example
        -------
        >>> @ws.on_tick
        ... async def handle_tick(tick): ...
        ...
        >>> @ws.on_tick(symbols=["AAPL", "NVDA"])
        ... async def handle_indices(tick: PricingData): ...
        ...
        >>> @ws.on_tick(symbols="AAPL")
        ... async def handle_aapl(tick: PricingData): ...
        ...
        >>> async def handle_all(tick: PricingData): ...
        >>> ws.on_tick(handle_all)
        """
        sym_filter: set[str] | None = None
        if symbols is not None:
            if isinstance(symbols, str):
                sym_filter = {symbols.upper()}
            else:
                sym_filter = {s.upper() for s in symbols}

        def _register(cb: TickCallback) -> TickCallback:
            self._tick_callbacks.append((cb, sym_filter))
            return cb
        
        if callback is not None:
            return _register(callback)
        return _register
    
    def on_error(
        self,
        callback: ErrorCallback | None = None,
        *,
        exceptions: type[Exception] | list[type[Exception]] | str | list[str] | None = None
    ) -> ErrorCallback | Callable[[ErrorCallback], ErrorCallback]:
        """
        Register a callback invoked on errors.

        Parameters
        ----------
        callback : ErrorCallback | None, optional
            The callback to register. May be either async or sync.
            If None, a decorator is returned.
        exceptions : type[Exception] | list[type[Exception]] | str | list[str] | None, optional
            Exception types to filter by. Accepts a single exception class, a
            list of exception classes, a single class name as a string, or a
            list of class name strings. If None (default), the callback receives
            **all** exceptions.

        Returns
        -------
        ErrorCallback | Callable[[ErrorCallback], ErrorCallback]
            If *callback* is provided, returns the callback. Otherwise returns
            a decorator.

        Example
        -------
        >>> @ws.on_error
        ... async def handle_all(error): ...
        ...
        >>> @ws.on_error(exceptions=ConnectionError)
        ... async def handle_connection(error): ...
        ...
        >>> @ws.on_error(exceptions=[ConnectionError, TimeoutError])
        ... async def handle_network(error): ...
        ...
        >>> @ws.on_error(exceptions="StreamingError")
        ... async def handle_streaming(error): ...
        ...
        >>> @ws.on_error(exceptions=["StreamingError", "ConnectionError"])
        ... async def handle_specific(error): ...
        """
        exc_filter = self._resolve_exception_filter(exceptions)

        def _register(cb: ErrorCallback) -> ErrorCallback:
            self._error_callbacks.append((cb, exc_filter))
            return cb
        
        if callback is not None:
            return _register(callback)
        return _register
    
    def on_connect(
        self,
        callback: LifecycleCallback | None = None
    ) -> LifecycleCallback | Callable[[LifecycleCallback], LifecycleCallback]:
        """
        Register a callback invoked when the WebSocket connects.

        Parameters
        ----------
        callback : LifecycleCallback | None, optional
            Callback function to register. If None, a decorator is returned.

        Returns
        -------
        LifecycleCallback | Callable[[LifecycleCallback], LifecycleCallback]
            If *callback* is provided, returns the callback. Otherwise returns
            a decorator.
        """
        def _register(cb: LifecycleCallback) -> LifecycleCallback:
            self._connect_callbacks.append(cb)
            return cb
        
        if callback is not None:
            return _register(callback)
        return _register
    
    def on_disconnect(
        self,
        callback: LifecycleCallback | None = None
    ) -> LifecycleCallback | Callable[[LifecycleCallback], LifecycleCallback]:
        """
        Register a callback invoked when the WebSocket disconects.

        Parameters
        ----------
        callback : LifecycleCallback | None, optional
            Callback function to register. If None, a decorator is returned.

        Returns
        -------
        LifecycleCallback | Callable[[LifecycleCallback], LifecycleCallback]
            If *callback* is provided, returns the callback. Otherwise returns
            a decorator.
        """
        def _register(cb: LifecycleCallback) -> LifecycleCallback:
            self._disconnect_callbacks.append(cb)
            return cb

        if callback is not None:
            return _register(callback)
        return _register

    async def subscribe(self, *symbols: str) -> None:
        """
        Subscribe to real-time updates for the given symbol.

        Parameters
        ----------
        *symbols : str
            The symbols to subscribe to.
        
        Examples
        --------
        >>> await ws.subscribe("AAPL", "NVDA", "googl")
        """
        if not symbols:
            return
        new_symbols = [s.upper() for s in symbols]
        self._symbols.update(new_symbols)
        if self._ws is not None:
            await self._send_subscribe(new_symbols)

    async def unsubscribe(self, *symbols: str) -> None:
        """
        Unsubscribe from the given symbols.

        Parameters
        ----------
        *symbols : str
            The symbols to unsubscribe from.

        Examples
        --------
        >>> await ws.unsubscribe("AAPL", "NVDA", "googl")
        """
        if not symbols:
            return
        remove_symbols = [s.upper() for s in symbols]
        self._symbols -= set(remove_symbols)
        if self._ws is not None:
            await self._send_unsubscribe(remove_symbols)

    async def connect(self) -> None:
        """
        Establish the WebSocket connection.

        Raises
        ------
        StreamingError
            If the connection cannot be established
        """
        try:
            import websockets
        except ImportError:
            raise ImportError(
                "The 'websockets' package is required for websocket. "
                "Install it with: pip install pyahoo[websocket]"
            ) from None
        
        try:
            connect_kwargs: dict[str, Any] = {
                "user_agent_header": _random_user_agent(),
                "origin": FINANCE_HOME
            }
            if self._proxy:
                connect_kwargs["proxy"] = self._proxy
            self._ws = await websockets.connect(self._url, **connect_kwargs)
            self._running = True
            self._closed = False
            self._reconnect_attempts = 0
            await self._fire_lifecycle(self._connect_callbacks)

            if self._symbols:
                await self._send_subscribe(list(self._symbols))
        except Exception as exc:
            raise StreamingError(f"WebSocket connection failed: {exc}") from exc
    
    async def run(self) -> None:
        """Start the streaming loop until `close()` is called."""
        while self._running:
            try:
                await self._receive_loop()
            except Exception as exc:
                if self._closed:
                    break
                await self._fire_lifecycle(self._disconnect_callbacks)
                await self._fire_error(exc)
                if self._reconnect and not self._closed:
                    await self._do_reconnect()
                else:
                    self._running = False
                    await self._queue.put(None)

    async def close(self) -> None:
        """
        Close the WebSocket connection.

        Raises
        ------
        StreamingError
            If an error occurs while closing the connection.
        """
        self._running = False
        self._closed = True
        if self._run_task is not None and not self._run_task.done():
            self._run_task.cancel()
            try:
                await self._run_task
            except (asyncio.CancelledError, Exception):
                pass
            self._run_task = None
        try:
            if self._ws is not None:
                try:
                    await self._ws.close()
                except Exception:
                    pass
                self._ws = None
                await self._fire_lifecycle(self._disconnect_callbacks)
        finally:
            await self._queue.put(None)
        await self._queue.put(None)