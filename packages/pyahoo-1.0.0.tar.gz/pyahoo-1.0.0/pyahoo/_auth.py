"""Session and crumb authentication management for Yahoo Finance APIs."""

from __future__ import annotations

import logging
from typing import Any

import httpx

from pyahoo._constants import DEFAULT_TIMEOUT, FINANCE_HOME, _random_user_agent
from pyahoo._types import JSON
from pyahoo.exceptions import (AuthenticationError, NotFoundError,
                               RateLimitError)

logger = logging.getLogger("pyahoo")


class SessionManager:
    """
    Synchronous session manager that handles cookies and crumb lifecycle.

    Acquires session cookies from `finance.yahoo.com`, then fetches a crumb.
    Cookies are persisted and sent with every subsequent request. On HTTP 401
    the session is automatically refreshed.

    Parameters
    ----------
    base_url : str
        Base API URL.
    user_agent : str | None, optional
        User agent string to use, by default a random Chrome UA.
    timeout : float, optional
        Request timeout in seconds, by default `DEFAULT_TIMEOUT`
    proxy : str | None, optional
        SOCKS5 or HTTP proxy URL. 

    Example
    -------
    >>> sm = SessionManager()
    >>> sm.ensure_session()
    >>> crumb = sm.crumb
    >>> response = sm.client.get(url, params={"crumb": crumb})
    """

    def __init__(
        self,
        *,
        base_url: str,
        user_agent: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        proxy: str | None = None
    ) -> None:
        self._base_url = base_url
        self._crumb: str | None = None
        ua = user_agent or _random_user_agent()
        self.client = httpx.Client(
            headers={"User-Agent": ua},
            timeout=timeout,
            proxy=proxy
        )
    
    @property
    def crumb_url(self) -> str:
        """Return the crumb URL."""
        return f"{self._base_url}/v1/test/getcrumb"

    @property
    def crumb(self) -> str:
        """Return the cached crumb (may be None)."""
        return self._crumb
    
    def ensure_session(self) -> None:
        """
        Visit Yahoo Finance to obtain session cookies, then fetch a crumb.

        Raises
        ------
        AuthenticationError
            If the session establishment or crumb retrieval fails.
        """
        logger.debug("Establishing Yahoo Finance session...")

        try:
            resp = self.client.get(
                FINANCE_HOME,
                headers={"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}
            )
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            raise AuthenticationError(
                f"Failed to load Yahoo Finance homepage: {exc}"
            ) from exc

        try:
            resp = self.client.get(self.crumb_url)
            resp.raise_for_status()
            self._crumb = resp.text.strip()
            logger.debug(f"Obtained crumb: {self._crumb}")
        except httpx.HTTPError as exc:
            raise AuthenticationError(
                f"Failed to fetch crumb: {exc}"
            ) from exc
        
        if not self._crumb:
            raise AuthenticationError("Received empty crumb from Yahoo Finance")
        
    def refresh(self) -> None:
        """Force-refresh session cookies and crumb."""
        self._crumb = None
        self.client.cookies.clear()
        self.ensure_session()

    def request(
        self,
        method: str,
        url: str,
        *,
        params: JSON | None = None,
        json: JSON | None = None,
        **kwargs: Any,
    ) -> httpx.Response:
        """
        Make an authenticated request with auto-retry on 401.

        Parameters
        ----------
        method : str
            HTTP method (e.g. "GET", "POST").
        url : str
            The URL to request.
        params : JSON | None, optional
            Query parameters.
        json : JSON | None, optional
            JSON body.
        **kwargs : Any
            Additional arguments passed to the underlying httpx client.

        Returns
        -------
        httpx.Response
            The HTTP response.

        Raises
        ------
        NotFoundError
            If the resource is not found (HTTP 404).
        RateLimitError
            If the rate limit is exceeded (HTTP 429).
        """
        params = dict(params) if params else {}
        params.setdefault("crumb", self.crumb)

        resp = self.client.request(method, url, params=params, json=json, **kwargs)
        
        if resp.status_code == 401:
            logger.debug("Got 401 - refreshing session and retrying...")
            self.refresh()
            params["crumb"] = self.crumb
            resp = self.client.request(method, url, params=params, json=json, **kwargs)
        
        if resp.status_code == 404:
            raise NotFoundError(f"Resource not found (HTTP 404): {url}")

        if resp.status_code == 429:
            raise RateLimitError("Yahoo Finance rate limit exceeded (HTTP 429)")
        
        return resp
    
    def close(self) -> None:
        """Close the session"""
        self.client.close()

    
class AsyncSessionManager:
    """
    Asynchronous session manager that handles cookies and crumb lifecycle.

    Same behaviour as `SessionManager but for async usage.

    Parameters
    ----------
    base_url : str
        Base API URL.
    user_agent : str | None, optional
        User agent string to use, by default a random Chrome UA.
    timeout : float, optional
        Request timeout in seconds, by default `DEFAULT_TIMEOUT`
    proxy : str | None, optional
        SOCKS5 or HTTP proxy URL. 

    Example
    -------
    >>> sm = AsyncSessionManager()
    >>> await sm.ensure_session()
    >>> crumb = sm.crumb
    >>> response = await sm.client.get(url, params={"crumb": crumb})
    """

    def __init__(
        self,
        *,
        base_url: str,
        user_agent: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        proxy: str | None = None
    ) -> None:
        self._base_url = base_url
        self._crumb: str | None = None
        ua = user_agent or _random_user_agent()
        self.client = httpx.AsyncClient(
            headers={"User-Agent": ua},
            timeout=timeout,
            proxy=proxy
        )

    @property
    def crumb_url(self) -> str:
        """Return the crumb URL."""
        return f"{self._base_url}/v1/test/getcrumb"
    
    @property
    def crumb(self) -> str | None:
        """Return the cached crumb (may be `None`)."""
        return self._crumb
    
    async def get_crumb(self) -> str:
        """
        Return the crumb, fetching a new session if needed.
        
        Returns
        -------
        str
            The crumb string.
        """
        if self._crumb is None:
            await self.ensure_session()
        assert self._crumb is not None
        return self._crumb

    async def ensure_session(self) -> None:
        """Visit Yahoo Finance to obtain session cookies, then fetch a crumb."""
        logger.debug("Establishing Yahoo Finance session...")

        try:
            resp = await self.client.get(
                FINANCE_HOME,
                headers={"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}
            )
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            raise AuthenticationError(
                f"Failed to load Yahoo Finance homepage: {exc}"
            ) from exc

        try:
            resp = await self.client.get(self.crumb_url)
            resp.raise_for_status()
            self._crumb = resp.text.strip()
            logger.debug(f"Obtained crumb: {self._crumb}")
        except httpx.HTTPError as exc:
            raise AuthenticationError(
                f"Failed to fetch crumb: {exc}"
            ) from exc
        
        if not self._crumb:
            raise AuthenticationError("Received empty crumb from Yahoo Finance")
        
    async def refresh(self) -> None:
        """Force-refresh session cookies and crumb."""
        self._crumb = None
        self.client.cookies.clear()
        await self.ensure_session()

    async def request(
        self,
        method: str,
        url: str,
        *,
        params: JSON | None = None,
        json: Any | None = None,
        **kwargs: Any
    ) -> httpx.Response:
        """
        Make an authenticated request with auto-retry on 401.

        Parameters
        ----------
        method : str
            HTTP method (e.g. "GET", "POST").
        url : str
            The URL to request.
        params : JSON | None, optional
            Query parameters.
        json : Any | None, optional
            JSON body.
        **kwargs : Any
            Additional arguments passed to the underlying httpx client.

        Returns
        -------
        httpx.Response
            The HTTP response.

        Raises
        ------
        NotFoundError
            If the resource is not found (HTTP 404).
        RateLimitError
            If the rate limit is exceeded (HTTP 429).
        """
        params = dict(params) if params else {}
        params.setdefault("crumb", await self.get_crumb())

        resp = await self.client.request(method, url, params=params, json=json, **kwargs)

        if resp.status_code == 401:
            logger.debug("Got 401 — refreshing session and retrying (async)...")
            await self.refresh()
            params["crumb"] = await self.get_crumb()
            resp = await self.client.request(method, url, params=params, json=json, **kwargs)

        if resp.status_code == 404:
            raise NotFoundError(f"Resource not found (HTTP 404): {url}")

        if resp.status_code == 429:
            raise RateLimitError("Yahoo Finance rate limit exceeded (HTTP 429)")
        
        return resp
    
    async def close(self) -> None:
        await self.client.aclose()