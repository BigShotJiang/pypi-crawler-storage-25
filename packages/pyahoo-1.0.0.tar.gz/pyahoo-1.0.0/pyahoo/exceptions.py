"""Exception hierarchy for pyahoo."""

from __future__ import annotations


class PyahooError(Exception):
    """Base exception for all pyahoo errors."""


class AuthenticationError(PyahooError):
    """Raised when session or crumb authentication fails."""


class APIError(PyahooError):
    """Raised when the Yahoo Finance API returns an error in the response body."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response_body: dict | None = None
    ) -> None:
        self.status_code = status_code
        self.response_body = response_body
        if status_code is not None:
            message = f"[HTTP {status_code}] {message}"
        super().__init__(message)


class RateLimitError(PyahooError):
    """Raised on HTTP 429 Too Many Requests."""

    def __init__(
        self,
        message: str = "Yahoo Finance rate limit exceeded (HTTP 429)."
    ) -> None:
        self.status_code = 429
        super().__init__(message)


class NotFoundError(PyahooError):
    """Raised on HTTP 404 or when a symbol/resource is not found."""

    def __init__(
        self,
        message: str = "Resource not found (HTTP 404)."
    ) -> None:
        self.status_code = 404
        super().__init__(message)

class StreamingError(PyahooError):
    """
    Raised when a WebSocket streaming error occurs.
    
    Covers connection failures, unexpected disconnections, and
    protobuf decoding errors.
    """