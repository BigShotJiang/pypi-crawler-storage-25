"""Shared type aliases."""

from __future__ import annotations

from typing import Any, Generic, TypeVar

JSON = dict[str, Any]
"""A type alias representing a generic JSON dictionary."""

T = TypeVar("T")
"""Generic type variable used for inner items of collections."""


class TrackedList(list[T], Generic[T]):
    """
    A list of results with metadata about missing items.

    `TrackedList` is a full `list` subclass, so all existing list operations
    (indexing, iteration, `len()`, `bool()`, etc.) work unchanged. It also
    carries two extra attributes that describe which items were requested and
    which ones could not resolve.

    Attributes
    ----------
    requested : list[str]
        The items that were originally requested.
    missing : list[str]
        Items that were requested but absent.

    Example
    -------
    >>> quotes = yf.quote("AAPL", "SOMETHINGWRONG")
    >>> len(quotes)      # only AAPL came back
    1
    >>> quotes.missing   # ['SOMETHINGWRONG']
    >>> quotes.requested # ['AAPL', 'SOMETHINGWRONG']
    >>> if quotes.missing:
    ...     print(f"WARNING: {quotes.missing} not found")
    """

    requested: list[str]
    missing: list[str]

    def __init__(
        self,
        items: list[T],
        *,
        requested: list[str] | None = None,
        missing: list[str] | None = None
    ) -> None:
        super().__init__(items)
        self.requested = requested or []
        self.missing = missing or []

    def __repr__(self):
        base = super().__repr__()
        if self.missing:
            return f"TrackedList({base}, missing={self.missing!r})"
        return f"TrackedList({base})"
    
    def __str__(self) -> str:
        count = len(self)
        total = len(self.requested)
        if self.missing:
            return (
                f"TrackedList({count}/{total} results, "
                f"missing: {', '.join(self.missing)})"
            )
        return f"TrackedList({count} results)"