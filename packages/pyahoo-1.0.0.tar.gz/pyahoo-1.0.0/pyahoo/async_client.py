"""Asynchronous Yahoo Finance API client."""

from __future__ import annotations

from typing import Any, Sequence, overload

from pyahoo._auth import AsyncSessionManager
from pyahoo._constants import BASE_URL, DEFAULT_TIMEOUT
from pyahoo._types import JSON, TrackedList
from pyahoo.enums import QuoteSummaryModule
from pyahoo.exceptions import APIError, NotFoundError
from pyahoo.models.chart import ChartResult
from pyahoo.models.common import RecommendedSymbol
from pyahoo.models.fundamentals import (InsightResult, RatingResult,
                                        TimeseriesResult)
from pyahoo.models.market import (CalendarEvent, PredictionEvent,
                                  QuoteTypeResult, Sector, TrendingResult)
from pyahoo.models.options import OptionsChain
from pyahoo.models.quote import Quote, SparkResult
from pyahoo.models.screener import ScreenerResult
from pyahoo.models.search import SearchResult
from pyahoo.models.summary import QuoteSummaryResult


def _bind_list(items: Sequence[Any], client: AsyncYahooFinance) -> None:
    """Bind a client back-reference to every item that supports it."""
    for item in items:
        if hasattr(item, "_bind"):
            item._bind(client)


class AsyncYahooFinance:
    """
    Asynchronous Yahoo Finance API client.

    Parameters
    ----------
    base_url : str, optional
        Base API URL, by default `BASE_URL`.
    lang : str, optional
        Language code, by default `"en-US"`.
    region : str, optional
        Region code, by default `"US"`.
    timeout : float, optional
        Request timeout in seconds, by default `DEFAULT_TIMEOUT`.
    proxy : str | None, optional
        SOCKS5 or HTTP proxy URL.

    Example
    -------
    >>> import asyncio
    >>> from pyahoo import AsyncYahooFinance
    >>> async def main():
    ...     async with AsyncYahooFinance() as yf:
    ...         quotes = await yf.quote("AAPL", "NVDA")
    ...         chart = await yf.chart("AAPL", range="1mo", interval="1d")
    >>> asyncio.run(main())
    """

    def __init__(
        self,
        *,
        base_url: str = BASE_URL,
        lang: str = "en-US",
        region: str = "US",
        timeout: float = DEFAULT_TIMEOUT,
        proxy: str | None = None
    ) -> None:
        self.lang = lang
        self.region = region
        self._base_url = base_url
        self._session = AsyncSessionManager(base_url=base_url, timeout=timeout, proxy=proxy)
    
    async def __aenter__(self) -> AsyncYahooFinance:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()

    @staticmethod
    def _unwrap(data: JSON, *path: str) -> JSON:
        """
        Unwrap nested API response data by following a path of keys.
        
        Parameters
        ----------
        data : JSON
            The raw API response.
        *path : str
            Sequence of keys to follow to reach the desired data.

        Returns
        -------
        Any
            The unwrapped data at the end of the path, or an empty
            list if any key is missing.
        """
        node: Any = data
        for key in path:
            if isinstance(node, dict):
                node = node.get(key, {})
            else:
                return []
        return node if node != {} else []
    
    @staticmethod
    def _check_error(
        data: JSON,
        wrapper_key: str,
        status_code: int
    ) -> None:
        """
        Raise APIError if the response contains an error payload or
        if the HTTP status code indicates a failure.

        Parameters
        ----------
        data : JSON
            The raw API response.
        wrapper_key : str
            The key containing the result wrapper.
        status_code : int
            The HTTP status code of the response.

        Raises
        ------
        APIError
            If an error is detected in the response data or status code.
        """
        wrapper = data.get(wrapper_key, data)
        if isinstance(wrapper, dict):
            err = wrapper.get("error")
            if err:
                raise APIError(
                    f"Yahoo Finance API error: {err}",
                    status_code=status_code,
                    response_body=data
                )
        if status_code >= 400:
            raise APIError(
                "Yahoo Finance API request failed",
                status_code=status_code,
                response_body=data
            )

    def _params(self, **extra: Any) -> JSON:
        """
        Generate common query parameters for API requests.

        Parameters
        ----------
        **kwargs : Any
            Additional query parameters.

        Returns
        -------
        JSON
            A dict of query parameters including common ones.
        """
        params: JSON = {"lang": self.lang, "region": self.region}
        params.update({k: v for k, v in extra.items() if v is not None})
        return params
    
    async def _get(
        self,
        url: str,
        params: JSON | None = None
    ) -> tuple[JSON, int]:
        """
        Perform an authenticated GET request.

        Parameters
        ----------
        url : str
            The URL to request.
        params : JSON | None, optional
            Query parameters.
        
        Returns
        -------
        tuple[JSON, int]
            Parsed JSON body and HTTP status code.
        """
        resp = await self._session.request("GET", url, params=params)
        try:
            data = resp.json()
        except Exception:
            if resp.status_code >= 400:
                raise APIError(
                    "Yahoo Finance API request failed",
                    status_code=resp.status_code
                )
            return {}, resp.status_code
        return data, resp.status_code
    
    async def _post(
        self,
        url: str,
        params: JSON | None = None,
        json: JSON | None = None
    ) -> tuple[JSON, int]:
        """
        Perform an authenticated POST request.

        Parameters
        ----------
        url : str
            The URL to request.
        params : JSON | None, optional
            Query parameters.
        json : JSON, optional

        Returns
        -------
        tuple[JSON, int]
            Parsed JSON body and HTTP status code.
        """
        resp = await self._session.request("POST", url, params=params, json=json)
        try:
            data = resp.json()
        except Exception:
            if resp.status_code >= 400:
                raise APIError(
                    "Yahoo Finance API request failed",
                    status_code=resp.status_code
                )
            return {}, resp.status_code
        return data, resp.status_code

    @overload
    async def quote(
        self,
        symbols: str,
        /,
        *,
        fields: list[str] | None = ...,
        formatted: bool = ...
    ) -> Quote: ...

    @overload
    async def quote(
        self,
        *symbols: str,
        fields: list[str] | None = ...,
        formatted: bool = ...
    ) -> TrackedList[Quote]: ...

    async def quote(
        self,
        *symbols: str,
        fields: list[str] | None = None,
        formatted: bool = False
    ) -> Quote | TrackedList[Quote]:
        """
        Fetch real-time quote data for one or more symbols.

        When a **single** symbol is requested, returns a `Quote` object directly.
        When **multiple** symbols are requested, returns a `TrackedList` with
        `Quote` objects.

        Parameters
        ----------
        *symbols : str
            One or more ticker symbols (e.g. `"AAPL"`, `"NVDA"`).
        fields : list[str] | None, optional
            Optional list of specific fields to return.
        formatted : bool, optional
            Whether to return formatted values, by default False.

        Returns
        -------
        Quote | TrackedList[Quote]
            A single `Quote` object or a `TrackedList` of `Quote` objects.

        Raises
        ------
        NotFoundError
            If a single symbol is requested but not found.
        """
        params = self._params(
            symbols=",".join(symbols),
            formatted=str(formatted).lower()
        )
        if fields:
            params["fields"] = ",".join(fields)

        data, status = await self._get(f"{self._base_url}/v7/finance/quote", params)
        self._check_error(data, "quoteResponse", status)
        results = self._unwrap(data, "quoteResponse", "result")
        quotes = [Quote.from_dict(r) for r in results]
        _bind_list(quotes, self)

        if len(symbols) == 1:
            if not quotes:
                raise NotFoundError(f"Symbol not found: {symbols[0]}")
            return quotes[0]
        
        returned = {q.symbol.upper() for q in quotes}
        requested = list(symbols)
        missing = [s for s in requested if s.upper() not in returned]
        return TrackedList(quotes, requested=requested, missing=missing)

    @overload
    async def spark(
        self,
        symbol: str,
        /,
        *,
        range: str = ...,
        interval: str = ...,
        indicators: str = ...,
        include_timestamps: bool = ...,
        include_pre_post: bool = ...
    ) -> SparkResult: ...

    @overload
    async def spark(
        self,
        *symbols: str,
        range: str = ...,
        interval: str = ...,
        indicators: str = ...,
        include_timestamps: bool = ...,
        include_pre_post: bool = ...
    ) -> TrackedList[SparkResult]: ...

    async def spark(
        self,
        *symbols: str,
        range: str = "1d",
        interval: str = "5m",
        indicators: str = "close",
        include_timestamps: bool = False,
        include_pre_post: bool = False
    ) -> SparkResult | TrackedList[SparkResult]:
        """
        Fetch lightweight sparkline chart data for one or more symbols.

        When a **single** symbol is requested, returns a SparkResult object directly.
        When **multiple** symbols are requested, returns a TrackedList with
        SparkResult objects.

        Parameters
        ----------
        *symbols : str
            Ticker symbols.
        range : str, optional
            Time range (e.g. `"1d"`, `"5d"`), by default `"1d"`.
        interval : str, optional
            Data interval (e.g. `"5m"`), by default `"5m"`.
        indicators : str, optional
            Which indicators to return, by default `"close"`.
        include_timestamps : bool, optional
            Whether to include timestamp array, by default False.
        include_pre_post : bool, optional
            Whether to include pre/post market data, by default False.

        Returns
        -------
        SparkResult | TrackedList[SparkResult]
            A single `SparkResult` object or a TrackedList of SparkResult objects.

        Raises
        ------
        NotFoundError
            If a single symbol is requested but not found.
        """
        params = self._params(
            symbols=",".join(symbols),
            range=str(range),
            interval=str(interval),
            indicators=indicators,
            includeTimestamps=str(include_timestamps).lower(),
            includePrePost=str(include_pre_post).lower()
        )
        data, status = await self._get(f"{self._base_url}/v7/finance/spark", params)
        self._check_error(data, "spark", status)
        results = self._unwrap(data, "spark", "result")
        sparks = [SparkResult.from_dict(r) for r in results]

        if len(symbols) == 1:
            if not sparks:
                raise NotFoundError(f"Symbol not found: {symbols[0]}")
            return sparks[0]
        
        returned = {s.symbol.upper() for s in sparks}
        requested = list(symbols)
        missing = [s for s in requested if s.upper() not in returned]
        return TrackedList(sparks, requested=requested, missing=missing)
    
    async def chart(
        self,
        symbol: str,
        *,
        range: str | None = None,
        interval: str = "1d",
        period1: int | None = None,
        period2: int | None = None,
        include_pre_post: bool = False,
        events: list[str] | None = None,
        include_adjusted_close: bool = True
    ) -> ChartResult:
        """
        Fetch historical OHLCV chart data for a symbol.

        Must provide either `range` **or** `period1`/`period2`.

        Parameters
        ----------    
        symbol : str
            Ticker symbol.
        range : str | None, optional
            Predefined range (e.g. `"1mo"`, `"1y"`).
        interval : str, optional
            Data granularity (e.g. `"1d"`, `"5m"`), by default `"1d"`.
        period1 : int | None, optional
            Start UNIX timestamp.
        period2 : int | None, optional
            End UNIX timestamp.
        include_pre_post : bool, optional
            Whether to include pre/post market data, by default False.
        events : list[str] | None, optional
            Event types to include (`["div", "split", "earn"]`).
        include_adjusted_close : bool, optional
            Whether to include adjusted close prices, by default True.

        Returns
        -------
        ChartResult
            A `ChartResult` containing bars and events.
        
        Raises
        ------
        NotFoundError
            If no chart data is found for the symbol.
        """
        params = self._params(
            interval=str(interval),
            includePrePost=str(include_pre_post).lower(),
            includeAdjustedClose=str(include_adjusted_close).lower(),
            range=range,
            period1=period1,
            period2=period2
        )
        if events:
            params["events"] = "|".join(str(e) for e in events)

        data, status = await self._get(f"{self._base_url}/v8/finance/chart/{symbol}", params)
        self._check_error(data, "chart", status)
        result = ChartResult.from_dict(data)
        if not result:
            raise NotFoundError(f"No chart data for symbol: {symbol}")
        result._bind(self)
        return result

    async def trending(
        self,
        region: str | None = None,
        *,
        count: int = 20
    ) -> TrendingResult:
        """
        Fetch currently trending symbols for a region.

        Parameters
        ----------
        region : str | None, optional
            Region code (default uses client region).
        count : int, optional
            Number of trending symbols to return, by default 20.

        Returns
        -------
        TrendingResult
            A `TrendingResult` with trending symbols.
        """
        params = self._params(count=count)
        data, _ = await self._get(
            f"{self._base_url}/v1/finance/trending/{region or self.region}", params
        )
        return TrendingResult.from_dict(data)

    async def sectors(
        self,
        *,
        formatted: bool = False,
        with_returns: bool = True
    ) -> list[Sector]:
        """
        Fetch market sector data with performance returns

        Parameters
        ----------
        formatted : bool, optional
            Whether to return formatted values, by default True.
        with_returns : bool, optional
            Whether to include performance returns, by default True.

        Returns
        -------
        list[Sector]
            List of `Sector` objects.
        """
        params = self._params(
            formatted=str(formatted).lower(),
            withReturns=str(with_returns).lower()
        )
        data, _ = await self._get(f"{self._base_url}/v1/finance/sectors", params)
        results = self._unwrap(data, "finance", "result")
        if not results:
            return []
        return [Sector.from_dict(s) for s in results[0].get("sectors", [])]

    async def quote_summary(
        self,
        symbol: str,
        *modules: str
    ) -> QuoteSummaryResult:
        """
        Fetch detailed financial data organised into modules.

        Parameters
        ----------
        symbol : str
            Ticker symbol.
        *modules : str
            One or more `QuoteSummaryModule` values or strings.

        Returns
        -------
        QuoteSummaryResult
            A `QuoteSummaryResult` containing the requested modules.

        Raises
        ------
        NotFoundError
            If the symbol is not found or no data is returned.
        """
        if not modules:
            modules = (QuoteSummaryModule.FINANCIAL_DATA, QuoteSummaryModule.SUMMARY_PROFILE)
        
        params = self._params(modules=",".join(str(m) for m in modules))
        data, status = await self._get(
            f"{self._base_url}/v10/finance/quoteSummary/{symbol}", params
        )
        self._check_error(data, "quoteSummary", status)
        result = QuoteSummaryResult.from_dict(data, symbol=symbol)
        if not result:
            raise NotFoundError(f"No summary data for symbol: {symbol}")
        return result
    
    async def quote_type(self, symbol: str) -> QuoteTypeResult:
        """
        Fetch basic metadata about a ticker symbol.

        Parameters
        ----------
        symbol : str
            Ticker symbol.

        Returns
        -------
        QuoteTypeResult
            A `QuoteTypeResult`.

        Raises
        ------
        NotFoundError
            If the symbol is not found.
        """
        params = self._params()
        data, _ = await self._get(
            f"{self._base_url}/v1/finance/quoteType/{symbol}", params
        )
        result = QuoteTypeResult.from_dict(data)
        if not result.symbol:
            raise NotFoundError(f"Symbol not found: {symbol}")
        return result
    
    async def recommendations(self, symbol: str) -> list[RecommendedSymbol]:
        """
        Fetch similar/recommended symbols for a given ticker.

        Parameters
        ---------
        symbol : str
            Ticker symbol.
        
        Returns
        -------
        list[RecommendedSymbol]
            List of `RecommendedSymbol` objects.
        """
        params = self._params()
        data, _ = await self._get(
            f"{self._base_url}/v6/finance/recommendationsbysymbol/{symbol}", params
        )
        results = self._unwrap(data, "finance", "result")
        if not results:
            return []
        return [RecommendedSymbol.from_dict(r) for r in results[0].get("recommendedSymbols", [])]

    async def fundamentals(
        self,
        symbol: str,
        *types: str,
        period1: int = 0,
        period2: int = 9_999_999_999
    ) -> list[TimeseriesResult]:
        """
        Fetch fundamental timeseries data.

        Parameters
        ----------
        symbol : str
            Ticker symbol.
        *types : str
            Metric types (e.g. `"annualTotalRevenue"`).
        period1 : int, optional
            Start UNIX timestamp, by default 0.
        period2: int, optional
            End UNIX timestamp, by default 9_999_999_999.

        Returns
        -------
        list[TimeseriesResult]
            List of `TimeseriesResult` objects per metric.
        """
        params = self._params(
            type=",".join(str(t) for t in types),
            period1=period1,
            period2=period2
        )
        data, _ = await self._get(
            f"{self._base_url}/ws/fundamentals-timeseries/v1/finance/timeseries/{symbol}",
            params
        )
        results = self._unwrap(data, "timeseries", "result")
        return [TimeseriesResult.from_dict(r) for r in results]

    async def price_insights(
        self,
        symbol: str,
        *,
        modules: str = "ai"
    ) -> InsightResult:
        """
        Fetch AI-driven price movement insights.

        Parameters
        ----------
        symbol : str
            Ticker symbol.
        modules : str, optional
            Selected insight modules, by default `"ai"`.

        Returns
        -------
        InsightResult
            An `InsightResult`.
        """
        params = self._params(symbols=symbol, modules=modules)
        data, _ = await self._get(
            f"{self._base_url}/ws/company-fundamentals/v1/finance/price-insights",
            params
        )
        return InsightResult.from_dict(data)
    
    async def insights(
        self,
        symbol: str,
        *,
        reports_count: int = 4
    ) -> InsightResult:
        """
        Fetch research reports, technical analysis, and company insights.

        Parameters
        ----------
        symbol : str
            Ticker symbol.
        reports_count : int, optional
            Number of research reports to return, by default 4.

        Returns
        -------
        InsightResult
            An `InsightResult`.
        """
        params = self._params(symbols=symbol, reportsCount=reports_count)
        data, _ = await self._get(
            f"{self._base_url}/ws/insights/v3/finance/insights", params
        )
        return InsightResult.from_dict(data)
    
    async def ratings(
        self,
        symbol: str,
        *,
        exclude_noncurrent: bool = True
    ) -> RatingResult:
        """
        Fetch analyst ratings and price targets.

        Parameters
        ----------
        symbol : str
            Ticker symbol.
        exclude_noncurrent : bool, optional
            Whether to exclude non-current ratings, by default True.

        Returns
        -------
        RatingResult
            A `RatingResult`.
        """
        params = self._params(exclude_noncurrent=str(exclude_noncurrent).lower())
        data, _ = await self._get(f"{self._base_url}/v2/ratings/top/{symbol}", params)
        return RatingResult.from_dict(data)

    async def screener(
        self,
        screener_id: str,
        *,
        count: int = 25,
        start: int = 0,
        formatted: bool = True,
        sort_field: str | None = None,
        sort_type: str | None = None
    ) -> ScreenerResult:
        """
        Fetch results from a predefined stock screener.

        Parameters
        ----------
        screener_id : str
            A :class:`ScreenerId` value or string.
        count : int, optional
            Number of results, by default 25.
        start : int, optional
            Pagination offset, by default 0.
        formatted : bool, optional
            Whether to return formatted values, by default True.
        sort_field : str | None, optional
            Field to sort by.
        sort_type : str | None, optional
            `"ASC"` or `"DESC"`.

        Returns
        -------
        ScreenerResult
            A `ScreenerResult`.
        """
        params = self._params(
            scrIds=str(screener_id),
            count=count,
            start=start,
            formatted=str(formatted).lower(),
            sortField=sort_field,
            sortType=str(sort_type) if sort_type else None
        )
        data, status = await self._get(
            f"{self._base_url}/v1/finance/screener/predefined/saved", params
        )
        self._check_error(data, "finance", status)
        results = self._unwrap(data, "finance", "result")
        if not results:
            return ScreenerResult()
        return ScreenerResult.from_dict(results[0])
    
    async def screener_discover(
        self,
        *,
        modules: str = "markets_hub",
        count: int = 6,
        formatted: bool = True
    ) -> list[ScreenerResult]:
        """
        Fetch screener discovery/hub data.

        Parameters
        ----------
        modules : str, optional
            Discovery modules, by default `"markets_hub"`.
        count : int, optional
            Number of screeners to return, by default 6.
        formatted : bool, optional
            Whether to return formatted values, by default True.

        Returns
        -------
        list[ScreenerResult]
            List of `ScreenerResult` objects.
        """
        params = self._params(
            modules=modules,
            count=count,
            formatted=str(formatted).lower()
        )
        data, _ = await self._get(
            f"{self._base_url}/ws/screeners/v1/finance/screener/discover",
            params
        )
        results = self._unwrap(data, "finance", "result")
        return [
            ScreenerResult.from_dict(s)
            for r in results
            for s in r.get("screeners", [])
        ]
    
    async def visualization(
        self,
        query: JSON,
        *,
        sort_type: str = "DESC",
        sort_field: str = "intradaymarketcap",
        offset: int = 0,
        size: int = 25
    ) -> list[JSON]:
        """
        Execute a structured visualization query (POST).

        Parameters
        ----------
        query : JSON
            Query object with operators and operands.
        sort_type : str, optional
            Sort direction, by default `"DESC"`.
        sort_field : str, optional
            Field to sort by, by default `"intradaymarketcap"`.
        offset : int, optional
            Pagination offset, by default 0.
        size : int, optional
            Page size, by default 25.

        Returns
        -------
        list[JSON]
            List of result dicts.
        """
        params = self._params()
        body: JSON = {
            "sortType": str(sort_type),
            "sortField": sort_field,
            "offset": offset,
            "size": size,
            "query": query
        }
        data, status = await self._post(
            f"{self._base_url}/v1/finance/visualization", params=params, json=body
        )
        self._check_error(data, "finance", status)
        results = self._unwrap(data, "finance", "result")
        if results:
            return results[0].get("data", [])
        return []

    async def options(
        self,
        symbol: str,
        *,
        date: int | None = None,
        formatted: bool = True,
        straddle: bool = False
    ) -> OptionsChain:
        """
        Fetch the options chain for a symbol.

        Parameters
        ----------
        symbol : str
            Ticker symbol.
        data : int | None, optional
            Expiration date as UNIX timestamp. Omit for nearest.
        formatted : bool, optional
            Whether to return formatted values, by default True.
        straddle : bool, optional
            Whether to return straddle view, by default False.
        
        Returns
        -------
        OptionChain
            An `OptionsChain`.

        Raises
        ------
        NotFoundError
            If no options data is found for the symbol.
        """
        params = self._params(
            formatted=str(formatted).lower(),
            straddle=str(straddle).lower(),
            date=date
        )
        data, status = await self._get(
            f"{self._base_url}/v7/finance/options/{symbol}", params
        )
        self._check_error(data, "optionChain", status)
        result = OptionsChain.from_dict(data)
        if not result.underlying_symbol:
            raise NotFoundError(f"No options data for symbol: {symbol}")
        return result

    async def search(
        self,
        query: str,
        *,
        quotes_count: int = 6,
        news_count: int = 3,
        enable_fuzzy_query: bool = False,
        enable_logo_url: bool = True,
    ) -> SearchResult:
        """
        Search for tickers, companies, and news.

        Parameters
        ----------
        query : str
            Search string.
        quotes_count : int, optional
            Max quote results, by defailt 6.
        news_count : int, optional
            Max news results, by default 3.
        enable_fuzzy_query : bool, optional
            Whether to enable fuzzy matching, by default False.
        enable_logo_url : bool, optional
            Whether to include logo URLs, by default True.

        Returns
        -------
        SearchResult
            A `SearchResult`.
        """
        params = self._params(
            q=query,
            quotesCount=quotes_count,
            newsCount=news_count,
            enableFuzzyQuery=str(enable_fuzzy_query).lower(),
            enableLogoUrl=str(enable_logo_url).lower()
        )
        data, _ = await self._get(f"{self._base_url}/v1/finance/search", params)
        result = SearchResult.from_dict(data)
        _bind_list(result.quotes, self)
        return result

    async def calendar_events(
        self,
        modules: str = "earnings",
        *,
        start_date: int | None = None,
        end_date: int | None = None,
        count_per_day: int = 25,
        tickers_filter: str | None = None,
        high_importance_only: bool = False,
        events_region: str | None = None
    ) -> list[CalendarEvent]:
        """
        Fetch calender events (earnings, economic events splits, IPOs).

        Parameters
        ----------
        modules : str, optional
            Event module (e.g. `"earnings"`, `"economicEvents"`), by default `"earnings"`.
        start_date : int | None, optional
            Start date in **milliseconds**.
        end_date : int | None, optional
            End date in **milliseconds**.
        count_per_day : int, optional
            Max events per day, by default 25.
        ticker_filter : str | None, optional
            Filter by ticker symbol.
        high_importance_only : bool, optional
            Whether to return only high-importnce economic events, by default False.
        events_region : str | None, optional
            Filter by region.

        Returns
        -------
        list[CalendarEvent]
            List of `CalendarEvent` objects.
        """
        params = self._params(
            modules=str(modules),
            countPerDay=count_per_day,
            startDate=start_date,
            endDate=end_date,
            tickersFilter=tickers_filter
        )
        if high_importance_only:
            params["economicEventsHighImportanceOnly"] = "true"
        if events_region:
            params["economicEventsRegionFilter"] = events_region

        data, _ = await self._get(
            f"{self._base_url}/ws/screeners/v1/finance/calendar-events",
            params
        )
        results = self._unwrap(data, "finance", "result")
        return [
            CalendarEvent.from_dict(ev, module=r.get("module", ""))
            for r in results
            for ev in r.get("events", [])
        ]
    
    async def prediction_market(
        self,
        *,
        count: int = 10,
        featured: bool = False,
        tag_slug: str | None = None,
        sort_key: str | None = None
    ) -> list[PredictionEvent]:
        """
        Fetch prediction market events.

        Parameters
        ----------
        count : int, optional
            Number of events, by default 10.
        featured : bool, optional
            Whether to return only featured events, by default False.
        tag_slug : str | None, optional
            Filter by tag (e.g. `"trending"`).
        sort_key : str | None, optional
            Sort key (e.g. `"VOLUME24HR_DESC"`).

        Returns
        -------
        list[PredictionEvent]
            List of `PredictionEvent` objects.
        """
        params = self._params(
            count=count,
            tagSlug=tag_slug,
            sortKey=str(sort_key) if sort_key else None
        )
        if featured:
            params["featured"] = "true"

        data, _ = await self._get(
            f"{self._base_url}/v1/finance/prediction-market/events",
            params
        )
        result = self._unwrap(data, "finance", "result")
        events_data = result.get("events", []) if isinstance(result, dict) else []
        return [PredictionEvent.from_dict(e) for e in events_data]

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._session.close()