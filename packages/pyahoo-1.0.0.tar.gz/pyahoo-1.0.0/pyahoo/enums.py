"""Enumerations for most Yahoo Finance API constants."""

from __future__ import annotations

from enum import Enum


class _StrEnum(str, Enum):
    """String enum base that serializes to its value."""

    def __str__(self) -> str:
        return self.value
    

class Interval(_StrEnum):
    """Data granularity intervals for chart and spark endpoints."""

    M1 = "1m"
    M2 = "2m"
    M5 = "5m"
    M15 = "15m"
    M30 = "30m"
    H1 = "1h"
    D1 = "1d"
    D5 = "5d"
    WK1 = "1wk"
    MO1 = "1mo"
    MO3 = "3mo"


class Range(_StrEnum):
    """Predefined date ranges for chart and spark endpoints."""

    D1 = "1d"
    D5 = "5d"
    MO1 = "1mo"
    MO3 = "3mo"
    MO6 = "6mo"
    Y1 = "1y"
    Y2 = "2y"
    Y5 = "5y"
    Y10 = "10y"
    YTD = "ytd"
    MAX = "max"


class ChartEvent(_StrEnum):
    """Event types that can be included in chart data."""

    DIV = "div"
    SPLIT = "split"
    EARN = "earn"


class QuoteType(_StrEnum):
    """Asset type classification returned by Yahoo Finance."""

    EQUITY = "EQUITY"
    ETF = "ETF"
    INDEX = "INDEX"
    MUTUALFUND = "MUTUALFUND"
    CRYPTOCURRENCY = "CRYPTOCURRENCY"
    CURRENCY = "CURRENCY"
    FUTURE = "FUTURE"
    OPTION = "OPTION"


class MarketState(_StrEnum):
    """Current market trading state."""

    PRE = "PRE"
    PREPRE = "PREPRE"
    REGULAR = "REGULAR"
    POST = "POST"
    POSTPOST = "POSTPOST"
    CLOSED = "CLOSED"


class QuoteSummaryModule(_StrEnum):
    """Available modules for the quoteSummary endpoint."""

    ASSET_PROFILE = "assetProfile"
    SUMMARY_PROFILE = "summaryProfile"
    SUMMARY_DETAIL = "summaryDetail"

    INCOME_STATEMENT_HISTORY = "incomeStatementHistory"
    INCOME_STATEMENT_HISTORY_QUARTERLY = "incomeStatementHistoryQuarterly"
    BALANCE_SHEET_HISTORY = "balanceSheetHistory"
    BALANCE_SHEET_HISTORY_QUARTERLY = "balanceSheetHistoryQuarterly"
    CASHFLOW_STATEMENT_HISTORY = "cashflowStatementHistory"
    CASHFLOW_STATEMENT_HISTORY_QUARTERLY = "cashflowStatementHistoryQuarterly"

    FINANCIAL_DATA = "financialData"
    DEFAULT_KEY_STATISTICS = "defaultKeyStatistics"
    PRICE = "price"

    EARNINGS = "earnings"
    EARNINGS_HISTORY = "earningsHistory"
    EARNINGS_TREND = "earningsTrend"
    INDEX_TREND = "indexTrend"
    INDUSTRY_TREND = "industryTrend"
    SECTOR_TREND = "sectorTrend"

    RECOMMENDATION_TREND = "recommendationTrend"
    UPGRADE_DOWNGRADE_HISTORY = "upgradeDowngradeHistory"

    INSTITUTION_OWNERSHIP = "institutionOwnership"
    FUND_OWNERSHIP = "fundOwnership"
    INSIDER_HOLDERS = "insiderHolders"
    INSIDER_TRANSACTIONS = "insiderTransactions"
    MAJOR_DIRECT_HOLDERS = "majorDirectHolders"
    MAJOR_HOLDERS_BREAKDOWN = "majorHoldersBreakdown"
    NET_SHARE_PURCHASE_ACTIVITY = "netSharePurchaseActivity"

    ESG_SCORES = "esgScores"

    FUND_PROFILE = "fundProfile"
    FUND_PERFORMANCE = "fundPerformance"
    TOP_HOLDINGS = "topHoldings"

    CALENDAR_EVENTS = "calendarEvents"
    SEC_FILINGS = "secFilings"


class ScreenerId(_StrEnum):
    """Pre-defined screener identifiers."""

    MOST_ACTIVES = "MOST_ACTIVES"
    DAY_GAINERS = "DAY_GAINERS"
    DAY_LOSERS = "DAY_LOSERS"
    MOST_SHORTED_STOCKS = "MOST_SHORTED_STOCKS"
    UNDERVALUED_GROWTH_STOCKS = "UNDERVALUED_GROWTH_STOCKS"
    GROWTH_TECHNOLOGY_STOCKS = "GROWTH_TECHNOLOGY_STOCKS"
    UNDERVALUED_LARGE_CAPS = "UNDERVALUED_LARGE_CAPS"
    AGGRESSIVE_SMALL_CAPS = "AGGRESSIVE_SMALL_CAPS"
    SMALL_CAP_GAINERS = "SMALL_CAP_GAINERS"
    ALL_CRYPTOCURRENCIES_US = "ALL_CRYPTOCURRENCIES_US"
    HIGHEST_VALUATION_PRIVATE_COMPANY = "HIGHEST_VALUATION_PRIVATE_COMPANY"
    TOP_MUTUAL_FUNDS = "TOP_MUTUAL_FUNDS"
    PORTFOLIO_ANCHORS = "PORTFOLIO_ANCHORS"
    SOLID_LARGE_GROWTH_FUNDS = "SOLID_LARGE_GROWTH_FUNDS"
    SOLID_MIDCAP_GROWTH_FUNDS = "SOLID_MIDCAP_GROWTH_FUNDS"
    CONSERVATIVE_FOREIGN_FUNDS = "CONSERVATIVE_FOREIGN_FUNDS"
    HIGH_YIELD_BOND = "HIGH_YIELD_BOND"
    TOP_ETFS = "TOP_ETFS"


class CalendarModule(_StrEnum):
    """Event modules for the calendar-events endpoint."""

    EARNINGS = "earnings"
    ECONOMIC_EVENTS = "economicEvents"
    SPLITS = "splits"
    IPO_INFO = "ipo_info"


class PredictionSortKey(_StrEnum):
    """Sort keys for prediction market events."""

    VOLUME24HR_DESC = "VOLUME24HR_DESC"
    VOLUME24HR_ASC = "VOLUME24HR_ASC"
    END_DATE_ASC = "END_DATE_ASC"
    END_DATE_DESC = "END_DATE_DESC"


class SortType(_StrEnum):
    """Sort direction for visualization queries."""

    ASC = "ASC"
    DESC = "DESC"


class QueryOperator(_StrEnum):
    """Operators for visualization query filters."""

    AND = "AND"
    OR = "OR"
    EQ = "EQ"
    GT = "GT"
    LT = "LT"
    GTE = "GTE"
    LTE = "LTE"
    BTWN = "BTWN"


class StreamingQuoteType(int, Enum):
    """
    Quote type codes used in WebSocket `PricingData` messages.

    These are **integer** codes used by the protobuf stream, different
    from the string-based `QuoteType` used by REST endpoints.
    """

    NONE = 0
    ALTSYMBOL = 5
    HEARTBEAT = 7
    EQUITY = 8
    INDEX = 9
    MUTUALFUND = 11
    MONEYMARKET = 12
    OPTION = 13
    CURRENCY = 14
    WARRANT = 15
    BOND = 17
    FUTURE = 18
    ETF = 20
    COMMODITY = 23
    ECNQUOTE = 28
    CRYPTOCURRENCY = 41
    INDICATOR = 42
    INDUSTRY = 1000


class StreamingMarketHours(int, Enum):
    """Market session codes used in WebSocket `PricingData` messages."""

    PRE_MARKET = 0
    REGULAR_MARKET = 1
    POST_MARKET = 2
    EXTENDED_HOURS_MARKET = 3


class StreamingOptionType(int, Enum):
    """Option type codes used in WebSocket `PricingData` messages."""

    CALL = 0
    PUT = 1