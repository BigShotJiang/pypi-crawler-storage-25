"""Pure-Python Protocol Buffer decoder for Yahoo Finance streaming data."""

from __future__ import annotations

import struct
from typing import Any

WIRETYPE_VARINT = 0
WIRETYPE_FIXED64 = 1
WIRETYPE_LENGTH_DELIMITED = 2
WIRETYPE_FIXED32 = 5


def _decode_varint(buf: bytes, pos: int) -> tuple[int, int]:
    """
    Decode a base-128 varint starting at *pos*.

    Parameters
    ----------
    buf : bytes
        Buffer containing the varint.
    pos : int
        Starting position in the buffer.

    Returns
    -------
    tuple[int, int]
        The decoded integer and the new position after the varint.
    """
    result = 0
    shift = 0
    while True:
        if pos >= len(buf):
            raise ValueError("Truncated varint")
        b = buf[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if (b & 0x80) == 0:
            break
        shift += 7
    return result, pos


def _zigzag_decode(n: int) -> int:
    """
    Decode a ZigZag-encoded signed integer.

    Parameters
    ----------
    n : int
        ZigZag-encoded integer.
    
    Returns
    -------
    int
        Decoded signed integer
    """
    return (n >> 1) ^ -(n & 1)


def _decode_fixed32(buf: bytes, pos: int) -> tuple[bytes, int]:
    """
    Read 4 bytes from *buf* at *pos*.

    Parameters
    ----------
    buf : bytes
        Buffer containing the fixed32.
    pos : int
        Starting position in the buffer.
    
    Returns
    -------
    tuple[bytes, int]
        The decoded fixed32 and the new position after the fixed32.
    """
    return buf[pos : pos + 4], pos + 4


def _decode_fixed64(buf: bytes, pos: int) -> tuple[bytes, int]:
    """
    Read 8 bytes from *buf at *pos*.

    Parameters
    ----------
    buf : bytes
        Buffer containing the fixed64.
    pos : int
        Starting position in the buffer.

    Returns
    -------
    tuple[bytes, int]
        The decoded fixed64 and the new position after the fixed64.
    """
    return buf[pos : pos + 8], pos + 8


STRING = "string"
FLOAT = "float"
DOUBLE = "double"
SINT64 = "sint64"
INT32 = "int32"


PRICING_DATA_SCHEMA: dict[int, tuple[str, str]] = {
    1: ("id", STRING),
    2: ("price", FLOAT),
    3: ("time", SINT64),
    4: ("currency", STRING),
    5: ("exchange", STRING),
    6: ("quote_type", INT32),
    7: ("market_hours", INT32),
    8: ("change_percent", FLOAT),
    9: ("day_volume", SINT64),
    10: ("day_high", FLOAT),
    11: ("day_low", FLOAT),
    12: ("change", FLOAT),
    13: ("short_name", STRING),
    14: ("expire_date", SINT64),
    15: ("open_price", FLOAT),
    16: ("previous_close", FLOAT),
    17: ("strike_price", FLOAT),
    18: ("underlying_symbol", STRING),
    19: ("open_interest", SINT64),
    20: ("options_type", INT32),
    21: ("mini_option", SINT64),
    22: ("last_size", SINT64),
    23: ("bid", FLOAT),
    24: ("bid_size", SINT64),
    25: ("ask", FLOAT),
    26: ("ask_size", SINT64),
    27: ("price_hint", SINT64),
    28: ("vol_24hr", SINT64),
    29: ("vol_all_currencies", SINT64),
    30: ("from_currency", STRING),
    31: ("last_market", STRING),
    32: ("circulating_supply", DOUBLE),
    33: ("marketcap", DOUBLE)
}


def decode_pricing_data(buf: bytes) -> dict[str, Any]:
    """
    Decode a raw protobuf `PricingData` message into a dict.

    Parameters
    ----------
    buf : bytes
        Raw protobuf bytes (after base64 decoding).

    Returns
    -------
    dict[str, Any]
        Mapping of field names to their decoded values. Only fields
        actually present in *buf* are included.
    """
    result: dict[str, Any] = {}
    pos = 0
    length = len(buf)

    while pos < length:
        tag, pos = _decode_varint(buf, pos)
        field_number = tag >> 3
        wire_type = tag & 0x07

        schema_entry = PRICING_DATA_SCHEMA.get(field_number)

        if wire_type == WIRETYPE_VARINT:
            value, pos = _decode_varint(buf, pos)
            if schema_entry is not None:
                name, ftype = schema_entry
                if ftype == SINT64:
                    result[name] = _zigzag_decode(value)
                else:
                    result[name] = value
        
        elif wire_type == WIRETYPE_FIXED64:
            raw, pos = _decode_fixed64(buf, pos)
            if schema_entry is not None:
                name, ftype = schema_entry
                if ftype == DOUBLE:
                    result[name] = struct.unpack("<d", raw)[0]
                else:
                    result[name] = struct.unpack("<q", raw)[0]
        
        elif wire_type == WIRETYPE_LENGTH_DELIMITED:
            data_len, pos = _decode_varint(buf, pos)
            data = buf[pos : pos + data_len]
            pos += data_len
            if schema_entry is not None:
                name, ftype = schema_entry
                if ftype == STRING:
                    result[name] = data.decode("utf-8")
                else:
                    result[name] = data

        elif wire_type == WIRETYPE_FIXED32:
            raw, pos = _decode_fixed32(buf, pos)
            if schema_entry is not None:
                name, ftype = schema_entry
                if ftype == FLOAT:
                    result[name] = struct.unpack("<f", raw)[0]
                else:
                    result[name] = struct.unpack("<i", raw)[0]

        else:
            raise ValueError(
                f"Unknown wire type {wire_type} at position {pos} "
                f"for field {field_number}"
            )
    
    return result