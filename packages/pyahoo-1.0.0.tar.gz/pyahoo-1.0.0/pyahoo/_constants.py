"""Internal constants used across the library."""

from __future__ import annotations

import random

BASE_URL: str = "https://query1.finance.yahoo.com"
FINANCE_HOME: str = "https://finance.yahoo.com"

DEFAULT_LANG: str = "en-US"
DEFAULT_REGION: str = "US"
DEFAULT_TIMEOUT: float = 30.0

STREAMER_URL: str = "wss://streamer.finance.yahoo.com/"
STREAMER_VERSION: int = 2
STREAMER_RECONNECT_BASE: float = 1.0
STREAMER_RECONNECT_MAX: float = 60.0

_CHROME_VERSION_RANGE: tuple[int, int] = (130, 146)


def _random_user_agent() -> str:
    """Generate a User-Agent string with a random Chrome version."""
    ver = random.randint(*_CHROME_VERSION_RANGE)
    return (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        f"Chrome/{ver}.0.0.0 Safari/537.36"
    )