"""Common small dataclasses shared across models."""

from __future__ import annotations

from dataclasses import dataclass

from pyahoo._types import JSON


@dataclass(slots=True)
class FormattedValue:
    """
    Represents Yahoo's `{"raw": ..., "fmt": ...}` pattern.

    Attributes
    ----------
    raw : float | int | None
        The unformatted raw numeric value.
    fmt : str | None
        The formatted string representation of the value.
    """

    def __float__(self) -> float:
        return float(self.raw) if self.raw is not None else 0.0

    def __int__(self) -> int:
        return int(self.raw) if self.raw is not None else 0

    def __str__(self) -> str:
        return self.fmt or str(self.raw) if self.raw is not None else ""

    @classmethod
    def from_dict(cls, data: JSON) -> FormattedValue:
        """
        Create a `FormattedValue` instance from a dict.

        Attributes
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        FormattedValue
            The parsed `FormattedValue` instance.
        """
        return cls(raw=data.get("raw"), fmt=data.get("fmt"))
    

@dataclass(slots=True)
class RecommendedSymbol:
    """
    A recommended/similar symbol with relevance score.

    Attributes
    ----------
    symbol : str
        The ticker symbol of the recommended asset
    score : float
        The relevance score of the recommendation (higher is more relevant).
    """

    symbol: str
    score: float

    def __str__(self) -> str:
        return f"{self.symbol} (score={self.score:.2f})"

    @classmethod
    def from_dict(cls, data: JSON) -> RecommendedSymbol:
        """
        Create a `RecommendedSymbol` instance from a dict.

        Attributes
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        RecommendedSymbol
            The parsed recommended symbol instance.
        """
        return cls(symbol=data["symbol"], score=data.get("score", 0.0))