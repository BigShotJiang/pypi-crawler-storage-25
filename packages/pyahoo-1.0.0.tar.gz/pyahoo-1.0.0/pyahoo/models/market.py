"""Market-level models: trending, sectors, calendar events, prediction market."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pyahoo._types import JSON
from pyahoo.models.common import FormattedValue


@dataclass(slots=True)
class TrendingQuote:
    """
    A trending symbol.

    Attributes
    ----------
    symbol : str
        The ticker symbol of the trending quote.
    """

    symbol: str = ""

    def __str__(self) -> str:
        return self.symbol

    @classmethod
    def from_dict(cls, data: JSON) -> TrendingQuote:
        """
        Create a `TrendingQuote` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        TrendingQuote
            The parsed `TrendingQuote` instance.
        """
        return cls(symbol=data.get("symbol", ""))
    

@dataclass(slots=True)
class TrendingResult:
    """
    Trending symbols for a region.
    
    Attributes
    ----------
    count : int
        The total count of trending symbols.
    job_timestamp : int | None
        The timestamp of the trending job.
    quotes : list[TrendingQuote]
        The list of trending quotes.
    """

    count: int = 0
    job_timestamp: int | None = None
    quotes: list[TrendingQuote] = field(default_factory=list)

    def __str__(self) -> str:
        syms = ", ".join(self.symbols[:5])
        extra = f" +{len(self.quotes) - 5} more" if len(self.quotes) > 5 else ""
        return f"Trending({self.count} symbols: {syms}{extra})"
    
    def __len__(self) -> int:
        return len(self.quotes)

    def __iter__(self):
        return iter(self.quotes)

    def __bool__(self) -> bool:
        return bool(self.quotes)

    @classmethod
    def from_dict(cls, data: JSON) -> TrendingResult:
        """
        Create a `TrendingResult` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        TrendingResult
            The parsed `TrendingResult` instance.

        """
        results = data.get("finance", {}).get("result", [])
        if not results:
            return cls()
        r = results[0]
        quotes = [TrendingQuote.from_dict(q) for q in r.get("quotes", [])]
        return cls(
            count=r.get("count", len(quotes)),
            job_timestamp=r.get("jobTimestamp"),
            quotes=quotes
        )

    @property
    def symbols(self) -> list[str]:
        return [q.symbol for q in self.quotes]
    

@dataclass(slots=True)
class SectorReturns:
    """
    Performance returns for a sector across time periods.
    
    Attributes
    ----------
    d1 : FormattedValue | None
        1-day returns.
    w1 : FormattedValue | None
        1-week returns.
    mo1 : FormattedValue | None
        1-month returns.
    mo3 : FormattedValue | None
        3-month returns.
    ytd : FormattedValue | None
        Year-to-date returns.
    y1 : FormattedValue | None
        1-year returns.
    """

    d1: FormattedValue | None = None
    w1: FormattedValue | None = None
    mo1: FormattedValue | None = None
    mo3: FormattedValue | None = None
    ytd: FormattedValue | None = None
    y1: FormattedValue | None = None

    def __str__(self) -> str:
        parts = []
        if self.d1:
            parts.append(f"1d={self.d1}")
        if self.ytd:
            parts.append(f"ytd={self.ytd}")
        if self.y1:
            parts.append(f"1y={self.y1}")
        return f"Returns({', '.join(parts)})" if parts else "Returns(N/A)"

    @classmethod
    def from_dict(cls, data: JSON) -> SectorReturns:
        """
        Create a `SectorReturns` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        
        Returns
        -------
        SectorReturns
            The parsed `SectorReturns` instance.
        """
        return cls(
            d1=FormattedValue.from_dict(data.get("1d")),
            w1=FormattedValue.from_dict(data.get("1w")),
            mo1=FormattedValue.from_dict(data.get("1m")),
            mo3=FormattedValue.from_dict(data.get("3m")),
            ytd=FormattedValue.from_dict(data.get("ytd")),
            y1=FormattedValue.from_dict(data.get("1y"))
        )
    

@dataclass(slots=True)
class Sector:
    """
    A market sector with optional performance returns.

    Attributes
    ----------
    name : str
        The name of the sector.
    slug : str
        The sector slug.
    returns : SectorReturns | None
        The performance returns for the sector.
    """

    name: str = ""
    slug: str = ""
    returns: SectorReturns | None = None

    def __str__(self) -> str:
        ret = f" {self.returns.d1}" if self.returns and self.returns.d1 else ""
        return f"{self.name}{ret}"

    @classmethod
    def from_dict(cls, data: JSON) -> Sector:
        """
        Create a `Sector` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        
        Returns
        -------
        Sector
            The parsed `Sector` instance.
        """
        returns = data.get("returns")
        return cls(
            name=data.get("name", ""),
            slug=data.get("slug", ""),
            returns=SectorReturns.from_dict(returns) if returns else None
        )
    

@dataclass(slots=True)
class QuoteTypeResult:
    """
    Result from the quoteType endpoint.
    
    Attributes
    ----------
    symbol : str
        The ticker symbol.
    short_name : str | None
        Short name of the entity.
    long_name : str | None
        Long name of the entity.
    quote_type : str | None
        Type of quote.
    exchange : str | None
        Exchange name.
    market : str | None
        Market name.
    exchange_timezone_name : str | None
        Exchange timezone name.
    exchange_timezone_short_name : str | None
        Exchange timezone short name.
    gmt_offset_milliseconds : int | None
        GMT offset in milliseconds.
    """

    symbol: str = ""
    short_name: str | None = None
    long_name: str | None = None
    quote_type: str | None = None
    exchange: str | None = None
    market: str | None = None
    exchange_timezone_name: str | None = None
    exchange_timezone_short_name: str | None = None
    gmt_offset_milliseconds: int | None = None

    def __str__(self) -> str:
        name = self.long_name or self.short_name or self.symbol
        qt = f" ({self.quote_type})" if self.quote_type else ""
        return f"{name}{qt}"

    @classmethod
    def from_dict(cls, data: JSON) -> QuoteTypeResult:
        """
        Create a `QuoteTypeResult` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        QuoteTypeResult
            The parsed `QuoteTypeResult` instance.
        """
        results = data.get("quoteType", {}).get("result", [])
        if not results:
            return cls()
        r = results[0]
        return cls(
            symbol=r.get("symbol", ""),
            short_name=r.get("shortName"),
            long_name=r.get("longName"),
            quote_type=r.get("quoteType"),
            exchange=r.get("exchange"),
            market=r.get("market"),
            exchange_timezone_name=r.get("exchangeTimezoneName"),
            exchange_timezone_short_name=r.get("exchangeTimezoneShortName"),
            gmt_offset_milliseconds=r.get("gmtOffSetMilliseconds")
        )
    

@dataclass(slots=True)
class CalendarEvent:
    """
    A single calendar event (earnings, economic, split, IPO).

    Attributes
    ----------
    module : str
        The type of module.
    symbol : str | None
        Ticker symbol.
    short_name : str | None
        Short name.
    event_name : str
        Name of the event.
    event_date : int | None
        Date of the event as a timestamp.
    start_date_time : str | None
        Start date and time as a string.
    eps_estimate : float | None
        Estimated EPS.
    eps_actual : float | None
        Actual EPS.
    eps_surprise : float | None
        EPS surprise percentage.
    revenue_estimate : float | None
        Estimated revenue.
    call_time : str | None
        Earnings call time.
    importance : str | None
        Economic event importance.
    region : str | None
        Economic event region.
    actual : float | None
        Actual economic figure.
    estimate : float | None
        Estimated economic figure.
    prior : float | None
        Prior economic figure.
    raw : JSON
        Raw response data.
    """

    module: str = ""
    symbol: str | None = None
    short_name: str | None = None
    event_name: str = ""
    event_date: int | None = None
    start_date_time: str | None = None

    eps_estimate: float | None = None
    eps_actual: float | None = None
    eps_surprise: float | None = None
    revenue_estimate: float | None = None
    call_time: str | None = None

    importance: str | None = None
    region: str | None = None
    actual: float | None = None
    estimate: float | None = None
    prior: float | None = None

    raw: JSON = field(default_factory=dict, repr=False)

    def __str__(self) -> str:
        label = self.symbol or self.event_name or self.module
        return f"CalendarEvent({label} [{self.module}])"

    @classmethod
    def from_dict(cls, data: JSON, module: str = "") -> CalendarEvent:
        """
        Create a `CalendarEvent` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        module : str, optional
            The module name.

        Returns
        -------
        CalendarEvent
            The parsed `CalendarEvent` instance.
        """
        def _raw(key: str) -> Any:
            v = data.get(key)
            return v.get("raw") if isinstance(v, dict) else v

        return cls(
            module=module,
            symbol=data.get("symbol"),
            short_name=data.get("shortName"),
            event_name=data.get("eventName", ""),
            event_date=data.get("eventDate"),
            start_date_time=data.get("startDateTime"),
            eps_estimate=_raw("epsEstimate"),
            eps_actual=_raw("epsActual"),
            eps_surprise=_raw("epsSurprise"),
            revenue_estimate=_raw("revenueEstimate"),
            call_time=data.get("callTime"),
            importance=data.get("importance"),
            region=data.get("region"),
            actual=_raw("actual"),
            estimate=_raw("estimate"),
            prior=_raw("prior"),
            raw=data
        )
    

@dataclass(slots=True)
class PredictionOutcome:
    """
    Outcome for a prediction market event.

    Attributes
    ----------
    id : str
        Outcome ID.
    name : str
        Outcome name.
    price : float
        Current price.
    percent_change : float
        Percent change in price.
    """

    id: str = ""
    name: str = ""
    price: float = 0.0
    percent_change: float = 0.0

    def __str__(self) -> str:
        return f"{self.name}: ${self.price:.2f} ({self.percent_change:+.1f}%)"

    @classmethod
    def from_dict(cls, data: JSON) -> PredictionOutcome:
        """
        Create a `PredictionOutcome` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        PredictionOutcome
            The parsed `PredictionOutcome` instance.
        """
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            price=data.get("price", 0.0),
            percent_change=data.get("percentChange", 0.0)
        )
    

@dataclass(slots=True)
class PredictionEvent:
    """
    A prediction market event.
    
    Attributes
    ----------
    id : str
        Event ID.
    title : str
        Event title.
    description : str
        Event description.
    category : str
        Event category.
    status : str
        Event status.
    outcomes : list[PredictionOutcome]
        List of possible outcomes.
    volume_24hr : int
        24-hour volume.
    end_date : str | None
        Event end date.
    featured : bool
        Whether the event is featured.
    tags : list[str]
        List of tags.
    """

    id: str = ""
    title: str = ""
    description: str = ""
    category: str = ""
    status: str = ""
    outcomes: list[PredictionOutcome] = field(default_factory=list)
    volume_24hr: int = 0
    end_date: str | None = None
    featured: bool = False
    tags: list[str] = field(default_factory=list)

    def __str__(self) -> str:
        return f"Prediction({self.title} [{self.status}] {len(self.outcomes)} outcomes)"

    def __len__(self) -> int:
        return len(self.outcomes)

    def __iter__(self):
        return iter(self.outcomes)

    @classmethod
    def from_dict(cls, data: JSON) -> PredictionEvent:
        """
        Create a `PredictionEvent` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        PredictionEvent
            The parsed `PredictionEvent` instance.
        """
        outcomes = [PredictionOutcome.from_dict(o) for o in data.get("outcomes", [])]
        return cls(
            id=data.get("id", ""),
            title=data.get("title", ""),
            description=data.get("description", ""),
            category=data.get("category", ""),
            status=data.get("status", ""),
            outcomes=outcomes,
            volume_24hr=data.get("volume24hr", 0),
            end_date=data.get("endDate"),
            featured=data.get("featured", False),
            tags=data.get("tags", [])
        )