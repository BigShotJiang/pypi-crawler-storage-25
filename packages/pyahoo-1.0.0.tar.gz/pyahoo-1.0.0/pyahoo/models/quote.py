"""Quote and Spark response models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from pyahoo._types import JSON
from pyahoo.models.base import YahooModel

if TYPE_CHECKING:
    from pyahoo.enums import ChartEvent, Interval, QuoteSummaryModule, Range
    from pyahoo.models.chart import ChartResult
    from pyahoo.models.common import RecommendedSymbol
    from pyahoo.models.fundamentals import InsightResult
    from pyahoo.models.options import OptionsChain
    from pyahoo.models.summary import QuoteSummaryResult


@dataclass
class Quote(YahooModel):
    """
    Real-time (or delayed) quote data for a single symbol.
    
    Attributes
    ----------
    symbol : str
        Ticker symbol.
    short_name : str | None
        Short name.
    long_name : str | None
        Long name.
    quote_type : str | None
        Quote type (e.g. 'EQUITY').
    currency : str | None
        Currency code.
    exchange : str | None
        Exchange name.
    full_exchange_name : str | None
        Full exchange name.
    market : str | None
        Market.
    market_state : str | None
        Market state.
    regular_market_price : float | None
        Regular market price.
    regular_market_change : float | None
        Regular market change.
    regular_market_change_percent : float | None
        Regular market change percent.
    regular_market_volume : int | None
        Regular market volume.
    regular_market_day_high : float | None
        Regular market day high.
    regular_market_day_low : float | None
        Regular market day low.
    regular_market_open : float | None
        Regular market open.
    regular_market_previous_close : float | None
        Regular market previous close.
    regular_market_time : int | None
        Regular market time.
    pre_market_price : float | None
        Pre-market price.
    pre_market_change : float | None
        Pre-market change.
    pre_market_change_percent : float | None
        Pre-market change percent.
    post_market_price : float | None
        Post-market price.
    post_market_change : float | None
        Post-market change.
    post_market_change_percent : float | None
        Post-market change percent.
    market_cap : int | None
        Market capitalization.
    trailing_pe : float | None
        Trailing PE ratio.
    forward_pe : float | None
        Forward PE ratio.
    eps_trailing_twelve_months : float | None
        Trailing twelve months EPS.
    eps_forward : float | None
        Forward EPS.
    dividend_yield : float | None
        Dividend yield.
    trailing_annual_dividend_rate : float | None
        Trailing annual dividend rate.
    trailing_annual_dividend_yield : float | None
        Trailing annual dividend yield.
    book_value : float | None
        Book value.
    price_to_book : float | None
        Price to book ratio.
    fifty_two_week_low : float | None
        Fifty-two week low.
    fifty_two_week_high : float | None
        Fifty-two week high.
    fifty_day_average : float | None
        Fifty-day moving average.
    two_hundred_day_average : float | None
        Two-hundred-day moving average.
    average_daily_volume_3month : int | None
        Average daily volume over 3 months.
    average_daily_volume_10day : int | None
        Average daily volume over 10 days.
    shares_outstanding : int | None
        Number of shares outstanding.
    logo_url : str | None
        Logo URL.
    display_name : str | None
        Display name.
    financial_currency : str | None
        Financial currency.
    region : str | None
        Region code.
    language : str | None
        Language code.
    raw : JSON
        Raw response data for any fields not explicitly modelled.
    """

    symbol: str = ""
    short_name: str | None = None
    long_name: str | None = None
    quote_type: str | None = None
    currency: str | None = None
    exchange: str | None = None
    full_exchange_name: str | None = None
    market: str | None = None
    market_state: str | None = None

    regular_market_price: float | None = None
    regular_market_change: float | None = None
    regular_market_change_percent: float | None = None
    regular_market_volume: int | None = None
    regular_market_day_high: float | None = None
    regular_market_day_low: float | None = None
    regular_market_open: float | None = None
    regular_market_previous_close: float | None = None
    regular_market_time: int | None = None

    pre_market_price: float | None = None
    pre_market_change: float | None = None
    pre_market_change_percent: float | None = None
    post_market_price: float | None = None
    post_market_change: float | None = None
    post_market_change_percent: float | None = None

    market_cap: int | None = None
    trailing_pe: float | None = None
    forward_pe: float | None = None
    eps_trailing_twelve_months: float | None = None
    eps_forward: float | None = None
    dividend_yield: float | None = None
    trailing_annual_dividend_rate: float | None = None
    trailing_annual_dividend_yield: float | None = None
    book_value: float | None = None
    price_to_book: float | None = None
    fifty_two_week_low: float | None = None
    fifty_two_week_high: float | None = None
    fifty_day_average: float | None = None
    two_hundred_day_average: float | None = None
    average_daily_volume_3month: int | None = None
    average_daily_volume_10day: int | None = None
    shares_outstanding: int | None = None

    logo_url: str | None = None
    display_name: str | None = None
    financial_currency: str | None = None
    region: str | None = None
    language: str | None = None

    raw: JSON = field(default_factory=dict, repr=False)

    def __str__(self) -> str:
        name = self.short_name or self.symbol
        price = f"${self.regular_market_price:,.2f}" if self.regular_market_price is not None else "N/A"
        pct = f"{self.regular_market_change_percent:+.2f}%" if self.regular_market_change_percent is not None else ""
        state = f" [{self.market_state}]" if self.market_state else ""
        return f"{name} ({self.symbol}) {price} {pct}{state}".strip()

    @classmethod
    def from_dict(cls, data: JSON) -> Quote:
        """
        Create a `Quote` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        Quote
            The parsed `Quote` instance.
        """
        return cls(
            symbol=data.get("symbol", ""),
            short_name=data.get("shortName"),
            long_name=data.get("longName"),
            quote_type=data.get("quoteType"),
            currency=data.get("currency"),
            exchange=data.get("exchange"),
            full_exchange_name=data.get("fullExchangeName"),
            market=data.get("market"),
            market_state=data.get("marketState"),
            regular_market_price=data.get("regularMarketPrice"),
            regular_market_change=data.get("regularMarketChange"),
            regular_market_change_percent=data.get("regularMarketChangePercent"),
            regular_market_volume=data.get("regularMarketVolume"),
            regular_market_day_high=data.get("regularMarketDayHigh"),
            regular_market_day_low=data.get("regularMarketDayLow"),
            regular_market_open=data.get("regularMarketOpen"),
            regular_market_previous_close=data.get("regularMarketPreviousClose"),
            regular_market_time=data.get("regularMarketTime"),
            pre_market_price=data.get("preMarketPrice"),
            pre_market_change=data.get("preMarketChange"),
            pre_market_change_percent=data.get("preMarketChangePercent"),
            post_market_price=data.get("postMarketPrice"),
            post_market_change=data.get("postMarketChange"),
            post_market_change_percent=data.get("postMarketChangePercent"),
            market_cap=data.get("marketCap"),
            trailing_pe=data.get("trailingPE"),
            forward_pe=data.get("forwardPE"),
            eps_trailing_twelve_months=data.get("epsTrailingTwelveMonths"),
            eps_forward=data.get("epsForward"),
            dividend_yield=data.get("dividendYield"),
            trailing_annual_dividend_rate=data.get("trailingAnnualDividendRate"),
            trailing_annual_dividend_yield=data.get("trailingAnnualDividendYield"),
            book_value=data.get("bookValue"),
            price_to_book=data.get("priceToBook"),
            fifty_two_week_low=data.get("fiftyTwoWeekLow"),
            fifty_two_week_high=data.get("fiftyTwoWeekHigh"),
            fifty_day_average=data.get("fiftyDayAverage"),
            two_hundred_day_average=data.get("twoHundredDayAverage"),
            average_daily_volume_3month=data.get("averageDailyVolume3Month"),
            average_daily_volume_10day=data.get("averageDailyVolume10Day"),
            shares_outstanding=data.get("sharesOutstanding"),
            logo_url=data.get("logoUrl"),
            display_name=data.get("displayName"),
            financial_currency=data.get("financialCurrency"),
            region=data.get("region"),
            language=data.get("language"),
            raw=data
        )
    
    def chart(
        self,
        *,
        range: Range | str | None = None,
        interval: Interval | str = "1d",
        period1: int | None = None,
        period2: int | None = None,
        include_pre_post: bool = False,
        events: list[ChartEvent | str] | None = None
    ) -> ChartResult:
        """
        Fetch chart data for this quote's symbol.
        
        Parameters
        ----------
        range : Range | str | None, optional
            The time range for the chart.
        interval : Interval | str, optional
            Data interval (e.g., '1d'), by default "1d".
        period1 : int | None, optional
            Start timestamp.
        period2 : int | None, optional
            End timestamp.
        include_pre_post : bool, optional
            Include pre/post market data, by default False.
        events : list[ChartEvent | str] | None, optional
            List of events to include (e.g. dividends).

        Returns
        -------
        ChartResult
            The chart data result.
        """
        client = self._require_sync_client()
        return client.chart(
            self.symbol,
            range=range,
            interval=interval,
            period1=period1,
            period2=period2,
            include_pre_post=include_pre_post,
            events=events
        )
    
    async def async_chart(
        self,
        *,
        range: Range | str | None = None,
        interval: Interval | str = "1d",
        period1: int | None = None,
        period2: int | None = None,
        include_pre_post: bool = False,
        events: list[ChartEvent | str] | None = None
    ) -> ChartResult:
        """
        Fetch chart data for this quote's symbol (async).

        Parameters
        ----------
        range : Range | str | None, optional
            The time range for the chart.
        interval : Interval | str, optional
            Data interval (e.g., '1d'), by default "1d".
        period1 : int | None, optional
            Start timestamp.
        period2 : int | None, optional
            End timestamp.
        include_pre_post : bool, optional
            Include pre/post market data, by default False.
        events : list[ChartEvent | str] | None, optional
            List of events to include (e.g. dividends).

        Returns
        -------
        ChartResult
            The chart data result.
        """
        client = self._require_async_client()
        return await client.chart(
            self.symbol,
            range=range,
            interval=interval,
            period1=period1,
            period2=period2,
            include_pre_post=include_pre_post,
            events=events
        )
    
    def summary(self, *modules: QuoteSummaryModule | str) -> QuoteSummaryResult:
        """
        Fetch quote summary for this symbol.
        
        Parameters
        ----------
        modules : QuoteSummaryModule | str, optional
            The summary modules to request.
        
        Returns
        -------
        QuoteSummaryResult
            The quote summary data.
        """
        client = self._require_sync_client()
        return client.quote_summary(self.symbol, *modules)
    
    async def async_summary(self, *modules: QuoteSummaryModule | str) -> QuoteSummaryResult:
        """
        Fetch quote summary for this symbol (async).
        
        Parameters
        ----------
        modules : QuoteSummaryModule | str, optional
            The summary modules to request.
        
        Returns
        -------
        QuoteSummaryResult
            The returned summary data.
        """
        client = self._require_async_client()
        return await client.quote_summary(self.symbol, *modules)
    
    def options(self, *, date: int | None = None) -> OptionsChain:
        """
        Fetch options chain for this symbol.

        Parameters
        ----------
        date : int | None, optional
            The expiration timestamp.
        
        Returns
        -------
        OptionsChain
            The requested options chain.
        """
        client = self._require_sync_client()
        return client.options(self.symbol, date=date)
    
    async def async_options(self, *, date: int | None = None) -> OptionsChain:
        """
        Fetch options chain for this symbol (async).
        
        Parameters
        ----------
        date : int | None, optional
            The expiration timestamp.
        
        Returns
        -------
        OptionsChain
            The requested options chain.
        """
        client = self._require_async_client()
        return await client.options(self.symbol, date=date)
    
    def recommendations(self) -> list[RecommendedSymbol]:
        """
        Fetch similar/recommended symbols.

        Returns
        -------
        list[RecommendedSymbol]
             List of recommended symbols.
        """
        client = self._require_sync_client()
        return client.recommendations(self.symbol)
    
    async def async_recommendations(self) -> list[RecommendedSymbol]:
        """
        Fetch similar/recommended symbols (async).
        
        Returns
        -------
        list[RecommendedSymbol]
             List of recommended symbols.
        """
        client = self._require_async_client()
        return await client.recommendations(self.symbol)
    
    def insights(self, *, reports_count: int = 4) -> InsightResult:
        """
        Fetch research insights for this symbol.
        
        Parameters
        ----------
        reports_count : int, optional
            Number of research reports to retrieve, by default 4.

        Returns
        -------
        InsightResult
            The insights and research data.
        """
        client = self._require_sync_client()
        return client.insights(self.symbol, reports_count=reports_count)
    
    async def async_insights(self, *, reports_count: int = 4) -> InsightResult:
        """
        Fetch research insights for this symbol (async).
        
        Parameters
        ----------
        reports_count : int, optional
            Number of research reports to retrieve, by default 4.

        Returns
        -------
        InsightResult
            The insights and research data.
        """
        client = self._require_async_client()
        return await client.insights(self.symbol, reports_count=reports_count)
    

@dataclass(slots=True)
class SparkResult:
    """
    Lightweight sparkline chart data for a single symbol.
    
    Attributes
    ----------
    symbol : str
        Ticker symbol.
    currency : str | None
        Currency code.
    regular_market_price : float | None
        Regular market price.
    previous_close : float | None
        Previous close.
    timestamps : list[int]
        List of timestamps.
    close : list[float | None]
        List of close prices.
    """

    symbol: str = ""
    currency: str | None = None
    regular_market_price: float | None = None
    previous_close: float | None = None
    timestamps: list[int] = field(default_factory=list)
    close: list[float | None] = field(default_factory=list)

    def __str__(self) -> str:
        price = f"${self.regular_market_price:,.2f}" if self.regular_market_price is not None else "N/A"
        return f"Spark({self.symbol} {price}, {len(self.close)} points)"

    def __len__(self) -> int:
        return len(self.close)

    @classmethod
    def from_dict(cls, data: JSON) -> SparkResult:
        """
        Create a `SparkResult` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        SparkResult
            The parsed `SparkResult` instance.
        """
        symbol = data.get("symbol", "")
        response = data.get("response", [{}])
        r = response[0] if response else {}
        meta = r.get("meta", {})
        timestamps = r.get("timestamp", []) or []
        indicators = r.get("indicators", {})
        quote = indicators.get("quote", [{}])
        close = quote[0].get("close", []) if quote else []
        return cls(
            symbol=symbol,
            currency=meta.get("currency"),
            regular_market_price=meta.get("regularMarketPrice"),
            previous_close=meta.get("previousClose"),
            timestamps=timestamps,
            close=close
        )