"""Fundamentals, insights, and ratings models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterator

from pyahoo._types import JSON


@dataclass(slots=True)
class TimeseriesDataPoint:
    """
    A single data point in a fundamental timeseries.

    Attributes
    ----------
    as_of_date : str
        The date of the data point.
    period_type : str
        The period type (e.g., "12M", "3M", "TTM").
    currency_code : str | None
        The currency code.
    raw : float | None
        The raw numeric value.
    fmt : str | None
        The formatted string value.
    """

    as_of_date: str = ""
    period_type: str = ""
    currency_code: str | None = None
    raw: float | None = None
    fmt: str | None = None

    def __str__(self) -> str:
        val = self.fmt or str(self.raw) if self.raw is not None else "N/A"
        return f"{self.as_of_date} ({self.period_type}): {val}"

    @classmethod
    def from_dict(cls, data: JSON) -> TimeseriesDataPoint:
        """
        Create a `TimeseriesDataPoint` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        
        Returns
        -------
        TimeseriesDataPoint
            The parsed `TimeseriesDataPoint` instance.
        """
        rv = data.get("reportedValue", {})
        return cls(
            as_of_date=data.get("asOfDate", ""),
            period_type=data.get("periodType", ""),
            currency_code=data.get("currencyCode"),
            raw=rv.get("raw") if rv else None,
            fmt=rv.get("fmt") if rv else None
        )
    

@dataclass(slots=True)
class TimeseriesResult:
    """
    Timeseries data for a single metric type.

    Attributes
    ----------
    metric_type : str
        The type of metric
    symbol : str
        The ticker symbol
    timestamps : list[int]
        List of timestamps.
    data_points : list[TimeseriesDataPoint]
        List of timeseries data points.
    """

    metric_type: str = ""
    symbol: str = ""
    timestamps: list[int] = field(default_factory=list)
    data_points: list[TimeseriesDataPoint] = field(default_factory=list)

    def __str__(self) -> str:
        return f"Timeseries({self.metric_type} [{self.symbol}] {len(self.data_points)} points)"
    
    def __len__(self) -> int:
        return len(self.data_points)

    def __iter__(self):
        return iter(self.data_points)

    @classmethod
    def from_dict(cls, data: JSON) -> TimeseriesResult:
        """
        Create a `TimeseriesResult` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        
        Returns
        -------
        TimeseriesResult
            The parsed `TimeseriesResult` instance.
        """
        meta = data.get("meta", {})
        symbols = meta.get("symbol", [])
        types = meta.get("type", [])
        metric_type = types[0] if types else ""
        symbol = symbols[0] if symbols else ""
        timestamps = data.get("timestamp", []) or []

        points: list[TimeseriesDataPoint] = []
        if metric_type and metric_type in data:
            for dp in data[metric_type] or []:
                if dp is not None:
                    points.append(TimeseriesDataPoint.from_dict(dp))

        return cls(
            metric_type=metric_type,
            symbol=symbol,
            timestamps=timestamps,
            data_points=points
        )
    

@dataclass(slots=True)
class TechnicalOutlook:
    """
    Short/intermediate/long-term technical outlook.

    Attributes
    ----------
    state_description : str
        Description of the state.
    direction : str
        The direction outlook.
    score : int
        The technical score.
    score_description : str
        Description of the score.
    """

    state_description: str = ""
    direction: str = ""
    score: int = 0
    score_description: str = ""

    def __str__(self) -> str:
        return f"{self.direction} ({self.score_description})"

    @classmethod
    def from_dict(cls, data: JSON) -> TechnicalOutlook:
        """
        Create a `TechnicalOutlook` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        TechnicalOutlook
            The parsed `TechnicalOutlook` instance.
        """
        return cls(
            state_description=data.get("stateDescription", ""),
            direction=data.get("direction", ""),
            score=data.get("score", 0),
            score_description=data.get("scoreDescription", "")
        )
    

@dataclass(slots=True)
class KeyTechnicals:
    """
    Key technical levels.

    Attributes
    ----------
    support : float | None
        Support level.
    resistance : float | None
        Resistance level.
    stop_loss : float | None
        Stop loss level.
    provider : str
        Data provider.
    """

    support: float | None = None
    resistance: float | None = None
    stop_loss: float | None = None
    provider: str = ""

    def __str__(self) -> str:
        parts = []
        if self.support is not None:
            parts.append(f"S={self.support}")
        if self.resistance is not None:
            parts.append(f"R={self.resistance}")
        return f"KeyTechnicals({', '.join(parts)})"

    @classmethod
    def from_dict(cls, data: JSON) -> KeyTechnicals:
        """
        Create a `KeyTechnicals` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        KeyTechnicals
            The parsed `KeyTechnicals` instance.
        """
        return cls(
            support=data.get("support"),
            resistance=data.get("resistance"),
            stop_loss=data.get("stopLoss"),
            provider=data.get("provider", "")
        )
    

@dataclass(slots=True)
class Valuation:
    """
    Valuation assessment.

    Attributes
    ----------
    description : str
        Valuation description.
    discount : str
        Discount assessment.
    provider : str
        Data provider.
    relative_value : str | None
        Relative value assessment.
    color : float | None
        Valuation color score.
    """

    description: str = ""
    discount: str = ""
    provider: str = ""
    relative_value: str | None = None
    color: float | None = None

    def __str__(self) -> str:
        return f"{self.description} ({self.discount})"

    @classmethod
    def from_dict(cls, data: JSON) -> Valuation:
        """
        Create a `Valuation` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        Valuation
            The parsed `Valuation` instance.
        """
        return cls(
            description=data.get("description", ""),
            discount=data.get("discount", ""),
            provider=data.get("provider", ""),
            relative_value=data.get("relativeValue"),
            color=data.get("color")
        )


@dataclass(slots=True)
class CompanySnapshot:
    """
    Company vs. sector scores.

    Attributes
    ----------
    sector_info : str
        Sector information.
    company : dict[str, float]
        Company scores.
    sector : dict[str, float]
        Sector scores.
    """

    sector_info: str = ""
    company: dict[str, float] = field(default_factory=dict)
    sector: dict[str, float] = field(default_factory=dict)

    def __str__(self) -> str:
        return f"CompanySnapshot(sector={self.sector_info})"

    @classmethod
    def from_dict(cls, data: JSON) -> CompanySnapshot:
        """
        Create a `CompanySnapshot` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        
        Returns
        -------
        CompanySnapshot
            The parsed `CompanySnapshot` instance.
        """
        return cls(
            sector_info=data.get("sectorInfo", ""),
            company=data.get("company", {}),
            sector=data.get("sector", {})
        )
    

@dataclass(slots=True)
class ResearchReport:
    """
    A research report from an insight.

    Attributes
    ----------
    id : str
        Report ID.
    head_html : str
        Report headline as HTML.
    provider : str
        Report provider.
    published_on : str
        Publish date string.
    summary : str
        Report summary.
    report_type : str
        Type of the report.
    """

    id: str = ""
    head_html: str = ""
    provider: str = ""
    published_on: str = ""
    summary: str = ""
    report_type: str = ""

    def __str__(self) -> str:
        return f"[{self.report_type}] {self.head_html} ({self.provider})"

    @classmethod
    def from_dict(cls, data: JSON) -> ResearchReport:
        """
        Create a `ResearchReport` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        
        Returns
        -------
        ResearchReport
            The parsed `ResearchReport` instance.
        """
        return cls(
            id=data.get("id", ""),
            head_html=data.get("headHtml", ""),
            provider=data.get("provider", ""),
            published_on=data.get("publishedOn", ""),
            summary=data.get("summary", ""),
            report_type=data.get("reportType", "")
        )
    

@dataclass(slots=True)
class InsightResult:
    """
    Full insights result for a symbol.

    Attributes
    ----------
    symbol : str
        The ticker symbol.
    short_term_outlook : TechnicalOutlook | None
        Short-term technical outlook.
    intermediate_term_outlook : TechnicalOutlook | None
        Intermediate-term technical outlook.
    long_term_outlook : TechnicalOutlook | None
        Long-term technical outlook.
    key_technicals : KeyTechnicals | None
        Key technical levels.
    valuation : Valuation | None
        Valuation assessment.
    company_snapshot : CompanySnapshot | None
        Company vs. sector snapshot.
    recommendation_rating : str | None
        Analyst recommendation rating.
    recommendation_target_price : float | None
        Analyst target price.
    recommendation_provider : str | None
        Recommendation provider.
    ai_summary : str | None
        AI-generated summary.
    reports : list[ResearchReport]
        List of related research reports.
    significant_developments : list[JSON]
        List of significant developments.
    """

    symbol: str = ""
    short_term_outlook: TechnicalOutlook | None = None
    intermediate_term_outlook: TechnicalOutlook | None = None
    long_term_outlook: TechnicalOutlook | None = None
    key_technicals: KeyTechnicals | None = None
    valuation: Valuation | None = None
    company_snapshot: CompanySnapshot | None = None
    recommendation_rating: str | None = None
    recommendation_target_price: float | None = None
    recommendation_provider: str | None = None
    ai_summary: str | None = None
    reports: list[ResearchReport] = field(default_factory=list)
    significant_developments: list[JSON] = field(default_factory=list)

    def __str__(self) -> str:
        parts = [f"Insight({self.symbol}"]
        if self.recommendation_rating:
            parts.append(f" rating={self.recommendation_rating}")
        if self.recommendation_target_price is not None:
            parts.append(f" target=${self.recommendation_target_price:,.2f}")
        if self.short_term_outlook:
            parts.append(f" short={self.short_term_outlook.direction}")
        parts.append(f" {len(self.reports)} reports)")
        return "".join(parts)

    @classmethod
    def from_dict(cls, data: JSON) -> InsightResult:
        """
        Create an `InsightResult` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        
        Returns
        -------
        InsightResult
            The parsed `InsightResult` instance.
        """
        finance = data.get("finance", {})
        result = finance.get("result", {})

        if isinstance(result, list):
            result = result[0] if result else {}
            insights = result.get("insights", result)
            symbol = result.get("symbol", "")
        else:
            insights = result
            symbol = result.get("symbol", "")

        instrument_info = insights.get("instrumentInfo", {})
        tech_events = instrument_info.get("technicalEvents", {})

        snapshot_data = insights.get("companySnapshot")
        rec = insights.get("recommendation", {})

        reports = [ResearchReport.from_dict(r) for r in insights.get("reports", [])]
        sig_devs = insights.get("sigDevs", [])
        ai_summary_data = insights.get("aiSummary", {})

        return cls(
            symbol=symbol,
            short_term_outlook=TechnicalOutlook.from_dict(tech_events.get("shortTermOutlook", {}))
            if tech_events.get("shortTermOutlook")
            else None,
            intermediate_term_outlook=TechnicalOutlook.from_dict(tech_events.get("intermediateTermOutlook", {}))
            if tech_events.get("intermediateTermOutlook")
            else None,
            long_term_outlook=TechnicalOutlook.from_dict(tech_events.get("longTermOutlook", {}))
            if tech_events.get("longTermOutlook")
            else None,
            key_technicals=KeyTechnicals.from_dict(instrument_info["keyTechnicals"])
            if "keyTechnicals" in instrument_info
            else None,
            valuation=Valuation.from_dict(instrument_info["valuation"])
            if "valuation" in instrument_info
            else None,
            company_snapshot=CompanySnapshot.from_dict(snapshot_data) if snapshot_data else None,
            recommendation_rating=rec.get("rating"),
            recommendation_target_price=rec.get("targetPrice"),
            recommendation_provider=rec.get("provider"),
            ai_summary=ai_summary_data.get("text") if ai_summary_data else None,
            reports=reports,
            significant_developments=sig_devs
        )
    

@dataclass(slots=True)
class AnalystRating:
    """
    An individual analyst rating.

    Attributes
    ----------
    firm : str
        The analyst firm.
    rating : str
        The assigned rating.
    price_target : float | None
        The price target.
    date : str
        The date of the rating.
    action : str
        The rating action.
    """

    firm: str = ""
    rating: str = ""
    price_target: float | None = None
    date: str = ""
    action: str = ""

    def __str__(self) -> str:
        pt = f" PT=${self.price_target:,.2f}" if self.price_target is not None else ""
        return f"{self.firm} {self.rating}{pt} ({self.action})"

    @classmethod
    def from_dict(cls, data: JSON) -> AnalystRating:
        """
        Create an `AnalystRating` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        AnalystRating
            The parsed `AnalystRating` instance.
        """
        pt = data.get("priceTarget", {})
        return cls(
            firm=data.get("firm", ""),
            rating=data.get("rating", ""),
            price_target=pt.get("raw") if isinstance(pt, dict) else pt,
            date=data.get("date", ""),
            action=data.get("action", "")
        )
    

@dataclass(slots=True)
class RatingResult:
    """
    Analyst ratings summary for a symbol.

    Attributes
    ----------
    symbol : str
        The ticker symbol.
    ratings : list[AnalystRating]
        List of analyst ratings.
    consensus_rating : str | None
        The overall consensus rating.
    average_target_price : float | None
        Average price target.
    high_target_price : float | None
        High price target.
    low_target_price : float | None
        Low price target.
    number_of_analysts : int
        Number of analysts providing ratings.
    """

    symbol: str = ""
    ratings: list[AnalystRating] = field(default_factory=list)
    consensus_rating: str | None = None
    average_target_price: float | None = None
    high_target_price: float | None = None
    low_target_price: float | None = None
    number_of_analysts: int = 0

    def __str__(self) -> str:
        avg = f"${self.average_target_price:,.2f}" if self.average_target_price is not None else "N/A"
        return (
            f"Ratings({self.symbol} {self.consensus_rating or 'N/A'} "
            f"avg_target={avg} analysts={self.number_of_analysts})"
        )

    def __len__(self) -> int:
        return len(self.ratings)
    
    def __iter__(self) -> Iterator[AnalystRating]:
        return iter(self.ratings)
    
    def __bool__(self) -> bool:
        return bool(self.ratings)

    @classmethod
    def from_dict(cls, data: JSON) -> RatingResult:
        """
        Create a `RatingResult` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        
        Returns
        -------
        RatingResult
            The parsed `RatingResult` instance.
        """
        result = data.get("finance", {}).get("result", {})
        if not result:
            return cls()

        ratings = [AnalystRating.from_dict(r) for r in result.get("ratings", [])]
        avg = result.get("averageTargetPrice", {})
        high = result.get("highTargetPrice", {})
        low = result.get("lowTargetPrice", {})

        return cls(
            symbol=result.get("symbol", ""),
            ratings=ratings,
            consensus_rating=result.get("consensusRating"),
            average_target_price=avg.get("raw") if isinstance(avg, dict) else avg,
            high_target_price=high.get("raw") if isinstance(high, dict) else high,
            low_target_price=low.get("raw") if isinstance(low, dict) else low,
            number_of_analysts=result.get("numberOfAnalysts", 0)
        )