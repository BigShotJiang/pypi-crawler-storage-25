"""Data model for Yahoo Finance real-time streaming (WebSocket) updates."""

from __future__ import annotations

import base64
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from pyahoo._protobuf import decode_pricing_data


def _normalize_symbol(symbol: str) -> str:
    """
    Strip the leading `^` from index symbols for clean display.

    Parameters
    ----------
    symbol : str
        Symbol to normalize.

    Returns
    -------
    str
        Normalized symbol.
    """
    return symbol.lstrip("^") if symbol else symbol


@dataclass
class PricingData:
    """
    A single real-time price tick received from the Yahoo Finance WebSocket.

    Each tick represents a snapshot of pricing data for a single symbol.
    Not every field is populated on every tick, only fields that changed
    since the last update are included by the server.

    Attributes
    ----------
    id : str
        Ticker symbol.
    price : float
        Current price.
    time : int
        Unix timestamp of the update (milliseconds).
    currency : str
        Currency code.
    exchange : str
        Exchange code.
    quote_type : int
        Type of quote (see `pyahoo.enums.StreamingQuoteType`).
    market_hours : int
        Market session (see `pyahoo.enums.StreamingMarketHours`).
    change_percent : float
        Percentage change from the previous close.
    day_volume : int
        Total trading volume for the day.
    day_high : float
        Highest price of the day.
    day_low : float
        Lowest price of the day.
    change : float
        Absolute price change from previous close.
    short_name : str
        Short company/ticker name.
    expire_date : int
        Options expiration date (Unix timestamp).
    open_price : float
        Opening price for the session.
    previous_close : float
        Previous session's closing price.
    strike_price : float
        Options strike price.
    underlying_symbol : str
        Underlying symbol for options/derivatives.
    open_interest : int
        Open interest for options.
    options_type : int
        Options type (see `pyahoo.enums.StreamingOptionType`).
    mini_option : int
        Mini option flag.
    last_size : int
        Size of the last trade.
    bid : float
        Current bid price.
    bid_size : int
        Current bid size.
    ask : float
        Current ask price.
    ask_size : int
        Current ask size.
    price_hint : int
        Number of decimal places for price display.
    vol_24hr : int
        24-hour trading volume (crypto).
    vol_all_currencies : int
        Volume across all currencies (crypto).
    from_currency : str
        Source currency for crypto pairs.
    last_market : str
        Last market where the instrument traded.
    circulating_supply : float
        Circulating supply (crypto).
    marketcap : float
        Market capitalisation.
    """

    id: str = ""
    short_name: str = ""
    exchange: str = ""
    currency: str = ""
    quote_type: int = 0
    market_hours: int = 0

    price: float = 0.0
    change: float = 0.0
    change_percent: float = 0.0
    previous_close: float = 0.0
    open_price: float = 0.0
    day_high: float = 0.0
    day_low: float = 0.0
    bid: float = 0.0
    bid_size: int = 0
    ask: float = 0.0
    ask_size: int = 0

    day_volume: int = 0
    last_size: int = 0

    time: int = 0

    expire_date: int = 0
    strike_price: float = 0.0
    underlying_symbol: str = ""
    open_interest: int = 0
    options_type: int = 0
    mini_option: int = 0

    vol_24hr: int = 0
    vol_all_currencies: int = 0
    from_currency: str = ""
    last_market: str = ""
    circulating_supply: float = 0.0
    marketcap: float = 0.0

    price_hint: int = 0

    _raw: dict[str, Any] = field(default_factory=dict, init=False, repr=False, compare=False)

    def __str__(self) -> str:
        parts = []
        if self.id:
            parts.append(self.id)
        if self.price:
            parts.append(f"${self.price:,.2f}")
        if self.change_percent:
            parts.append(f"{self.change_percent:+.2f}%")
        if self.day_volume:
            vol = self.day_volume
            if vol >= 1_000_000_000:
                parts.append(f"vol={vol / 1_000_000_000:.1f}B")
            elif vol >= 1_000_000:
                parts.append(f"vol={vol / 1_000_000:.1f}M")
            elif vol >= 1_000:
                parts.append(f"vol={vol / 1_000:.1f}K")
            else:
                parts.append(f"vol={vol}")
        if self.market_hours or self.id:
            parts.append(f"[{self.market_hours_name}]")
        return " ".join(parts) if parts else "PricingData(empty)"

    def __repr__(self) -> str:
        fields = []
        if self.id:
            fields.append(f"id={self.id!r}")
        if self.price:
            fields.append(f"price={self.price}")
        if self.change_percent:
            fields.append(f"change_percent={self.change_percent}")
        if self.time:
            fields.append(f"time={self.time}")
        return f"PricingData({', '.join(fields)})"

    @classmethod
    def from_bytes(cls, data: bytes) -> PricingData:
        """
        Decode a raw protobuf `PricingData` message.

        Parameters
        ----------
        data : bytes
            Raw protobuf bytes.
        
        Returns
        -------
        PricingData
            Decoded pricing data object.
        """
        decoded = decode_pricing_data(data)
        if "id" in decoded:
            decoded["_raw_id"] = decoded["id"]
            decoded["id"] = _normalize_symbol(decoded["id"])
        obj = cls(**{k: v for k, v in decoded.items() if k in cls.__dataclass_fields__})
        obj._raw = decoded
        return obj
    
    @classmethod
    def from_base64(cls, data: str) -> PricingData:
        """
        Decode a base64-encoded protobuf `PricingData` message.

        Parameters
        ----------
        data : str
            Base64-encoded string as received from the WebSocket.

        Returns
        -------
        PricingData
            Decoded pricing data object.
        """
        return cls.from_bytes(base64.b64decode(data))
    
    @property
    def datetime(self) -> datetime | None:
        """
        Return the tick timestamp as a timezone-aware `datetime`, or None.

        Returns
        -------
        datatime | None
            UTC datetime of the tick, or `None` if no time was provided.
        """
        if not self.time:
            return None
        ts = self.time if self.time < 1e12 else self.time / 1000
        return datetime.fromtimestamp(ts, tz=timezone.utc)
    
    @property
    def market_hours_name(self) -> str:
        """
        Return a human-readable name for the current market hours.

        Returns
        -------
        str
            E.g. `"REGULAR"`, `"PRE_MARKET"`, `"POST_MARKET"`.
        """
        _names = {0: "PRE_MARKET", 1: "REGULAR", 2: "POST_MARKET", 3: "EXTENDED"}
        return _names.get(self.market_hours, f"UNKNOWN({self.market_hours})")
    
    @property
    def quote_type_name(self) -> str:
        """
        Return a human-readable name for the quote type.

        Returns
        -------
        str
            E.g. `"EQUITY"`, `"ETF"`, `"CRYPTOCURRENCY"`.
        """
        _names = {
            0: "NONE", 5: "ALTSYMBOL", 7: "HEARTBEAT", 8: "EQUITY",
            9: "INDEX", 11: "MUTUALFUND", 12: "MONEYMARKET", 13: "OPTION",
            14: "CURRENCY", 15: "WARRANT", 17: "BOND", 18: "FUTURE",
            20: "ETF", 23: "COMMODITY", 28: "ECNQUOTE", 41: "CRYPTOCURRENCY",
            42: "INDICATOR", 1000: "INDUSTRY"
        }
        return _names.get(self.quote_type, f"UNKNOWN({self.quote_type})")
    
    @property
    def raw_id(self) -> str:
        """
        Return the original symbol as received from Yahoo (with `^` prefix).

        Returns
        -------
        str
            Original symbol.
        """
        return self._raw.get("_raw_id", self.id)
    
    def to_dict(self) -> dict[str, Any]:
        """
        Return all non-default fields as a dict.

        Returns
        -------
        dict[str, Any]
            Dictionary of field names to values, excluding default/zero values.
        """
        result: dict[str, Any] = {}
        defaults = PricingData()
        for fname in self.__dataclass_fields__:
            if fname.startswith("_"):
                continue
            val = getattr(self, fname)
            default_val = getattr(defaults, fname)
            if val != default_val:
                result[fname] = val
        return result