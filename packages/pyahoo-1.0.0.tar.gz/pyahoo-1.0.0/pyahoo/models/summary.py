"""Quote Summary response model - wraps arbitrary module dicts."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterator

from pyahoo._types import JSON


@dataclass(slots=True)
class QuoteSummaryResult:
    """
    Result of a quoteSummary call.

    Each requested module is stored as a key in `modules`
    with its raw dictionary value. There are also typed convenience
    properties for the most commonly used modules.

    Attributes
    ----------
    symbol : str
        The ticker symbol.
    modules : JSON
        The raw dictionary containing the requested modules.
    """

    symbol: str = ""
    modules: JSON = field(default_factory=dict)

    def __getitem__(self, module: str) -> Any:
        return self.modules[module]

    def __contains__(self, module: str) -> bool:
        return module in self.modules

    def __str__(self) -> str:
        names = ", ".join(self.modules.keys())
        return f"QuoteSummary({self.symbol}: {len(self.modules)} modules [{names}])"

    def __len__(self) -> int:
        return len(self.modules)

    def __bool__(self) -> bool:
        return bool(self.modules)

    def __iter__(self) -> Iterator[str]:
        return iter(self.modules)

    @classmethod
    def from_dict(cls, data: JSON, symbol: str = "") -> QuoteSummaryResult:
        """
        Create a `QuoteSummaryResult` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        symbol : str, optional
            The ticker symbol.

        Returns
        -------
        QuoteSummaryResult
            The parsed `QuoteSummaryResult` instance.
        """
        results = data.get("quoteSummary", {}).get("result", [])
        if not results:
            return cls(symbol=symbol)
        modules = results[0]
        return cls(symbol=symbol, modules=modules)

    @property
    def financial_data(self) -> JSON | None:
        """
        Get the financialData module if available.

        Returns
        -------
        JSON | None
            The financialData module if available.
        """
        return self.modules.get("financialData")

    @property
    def summary_profile(self) -> JSON | None:
        """
        Get the summaryProfile module if available.
        
        Returns
        -------
        JSON | None
            The summaryProfile module if available.
        """
        return self.modules.get("summaryProfile")

    @property
    def summary_detail(self) -> JSON | None:
        """
        Get the summaryDetail module if available.
        
        Returns
        -------
        JSON | None
            The summaryDetail module if available.
        """
        return self.modules.get("summaryDetail")

    @property
    def asset_profile(self) -> JSON | None:
        """
        Get the assetProfile module if available.
        
        Returns
        -------
        JSON | None
            The assetProfile module if available.
        """
        return self.modules.get("assetProfile")

    @property
    def default_key_statistics(self) -> JSON | None:
        """
        Get the defaultKeyStatistics module if available.

        Returns
        -------
        JSON | None
            The defaultKeyStatistics module if available.
        """
        return self.modules.get("defaultKeyStatistics")

    @property
    def price(self) -> JSON | None:
        """
        Get the price module if available.

        Returns
        -------
        JSON | None
            The price module if available.
        """
        return self.modules.get("price")

    @property
    def earnings(self) -> JSON | None:
        """
        Get the earnings module if available.

        Returns
        -------
        JSON | None
            The earnings module if available.
        """
        return self.modules.get("earnings")

    @property
    def recommendation_trend(self) -> JSON | None:
        """
        Get the recommendationTrend module if available.

        Returns
        -------
        JSON | None
            The recommendationTrend module if available.
        """
        return self.modules.get("recommendationTrend")

    @property
    def institution_ownership(self) -> JSON | None:
        """
        Get the institutionOwnership module if available.

        Returns
        -------
        JSON | None
            The institutionOwnership module if available.
        """
        return self.modules.get("institutionOwnership")

    @property
    def esg_scores(self) -> JSON | None:
        """
        Get the esgScores module if available.

        Returns
        -------
        JSON | None
            The esgScores module if available.
        """
        return self.modules.get("esgScores")

    @property
    def calendar_events(self) -> JSON | None:
        """
        Get the calendarEvents module if available.

        Returns
        -------
        JSON | None
            The calendarEvents module if available.
        """
        return self.modules.get("calendarEvents")

    def get(self, module: str, default: Any = None) -> Any:
        """
        Get the module dictionary safely, returning `default` if not found.

        Parameters
        ----------
        module : str
            The name of the module to retrieve.
        default : Any, optional
            The default value to return if the module is not found.

        Returns
        -------
        Any
            The module dictionary if found, otherwise the default value.
        """
        return self.modules.get(module, default)

    