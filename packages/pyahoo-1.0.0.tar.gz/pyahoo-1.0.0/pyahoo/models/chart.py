"""Chart / Historical data models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Iterator

from pyahoo._types import JSON
from pyahoo.models.base import YahooModel

if TYPE_CHECKING:
    from pyahoo.models.quote import Quote


@dataclass(slots=True)
class OHLCV:
    """
    A single price bar (Open, High, Low, Close, Volume).

    Attributes
    ----------
    timestamp : int
        Bar timestamp.
    open : float | None
        Open price.
    high : float | None
        High price.
    low : float | None
        Low price.
    close : float | None
        Close price.
    volume : int | None
        Trading volume.
    adj_close : float | None
        Adjusted close price.
    """

    timestamp: int = 0
    open: float | None = None
    high: float | None = None
    low: float | None = None
    close: float | None = None
    volume: int | None = None
    adj_close: float | None = None

    def __str__(self) -> str:
        return (
            f"OHLCV(ts={self.timestamp} O={self.open} H={self.high} "
            f"L={self.low} C={self.close} V={self.volume})"
        )


@dataclass(slots=True)
class DividendEvent:
    """
    A dividend event.

    Attributes
    ----------
    data : int
        Event timestamp.
    amount : float
        Dividend amount.
    """

    date: int = 0
    amount: float = 0.0

    def __str__(self) -> str:
        return f"Dividend({self.amount} on {self.date})"


@dataclass(slots=True)
class SplitEvent:
    """
    A stock split event.

    Attributes
    ----------
    date : int
        Event timestamp.
    numerator : int
        Split numerator.
    denominator : int
        Split denominator.
    ration : str
        Split ratio as a string.
    """

    date: int = 0
    numerator: int = 0
    denominator: int = 0
    ratio: str = ""

    def __str__(self) -> str:
        return f"Split({self.ratio} on {self.date})"


@dataclass(slots=True)
class ChartMeta:
    """
    Metadata from the chart response.

    Attributes
    ----------
    currency : str | None
        Currency code.
    symbol : str
        Ticker symbol.
    exchange_name : str | None
        Exchange name.
    full_exchange_name : str | None
        Full exchange name.
    instrument_type : str | None
        Instrument type.
    first_trade_date : int | None
        First trade date.
    regular_market_time : int | None
        Regular market time.
    regular_market_price : float | None
        Regular merket price.
    chart_previous_close : float | None
        Chart previous close.
    previous_close : float | None
        Previous close.
    data_granularity : str | None
        Data granularity.
    range : str | None
        Time range.
    valid_ranges : list[str]
        List of valid ranges.
    """

    currency: str | None = None
    symbol: str = ""
    exchange_name: str | None = None
    full_exchange_name: str | None = None
    instrument_type: str | None = None
    first_trade_date: int | None = None
    regular_market_time: int | None = None
    regular_market_price: float | None = None
    chart_previous_close: float | None = None
    previous_close: float | None = None
    data_granularity: str | None = None
    range: str | None = None
    valid_ranges: list[str] = field(default_factory=list)

    def __str__(self) -> str:
        return f"ChartMeta({self.symbol} {self.data_granularity} range={self.range})"

    @classmethod
    def from_dict(cls, data: JSON) -> ChartMeta:
        """
        Create a `ChartMeta` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        ChartMeta
            The parsed metadata instance.
        """
        return cls(
            currency=data.get("currency"),
            symbol=data.get("symbol", ""),
            exchange_name=data.get("exchangeName"),
            full_exchange_name=data.get("fullExchangeName"),
            instrument_type=data.get("instrumentType"),
            first_trade_date=data.get("firstTradeDate"),
            regular_market_time=data.get("regularMarketTime"),
            regular_market_price=data.get("regularMarketPrice"),
            chart_previous_close=data.get("chartPreviousClose"),
            previous_close=data.get("previousClose"),
            data_granularity=data.get("dataGranularity"),
            range=data.get("range"),
            valid_ranges=data.get("validRanges", [])
        )
    

@dataclass
class ChartResult(YahooModel):
    """
    Full chart result with OHLCV bars, events, and metadata.

    Attributes
    ----------
    meta : ChartMeta
        Chart metadata.
    bars : list[OHLCV]
        List of OHLCV bars.
    dividends : list[DividendEvent]
        List of dividend events.
    splits : list[SplitEvent]
        List of split events
    symbol : str
        Ticker symbol.
    """

    meta: ChartMeta = field(default_factory=ChartMeta)
    bars: list[OHLCV] = field(default_factory=list)
    dividends: list[DividendEvent] = field(default_factory=list)
    splits: list[SplitEvent] = field(default_factory=list)

    def __str__(self) -> str:
        return (
            f"ChartResult({self.symbol} {len(self.bars)} bars, "
            f"{len(self.dividends)} divs, {len(self.splits)} splits)"
        )
    
    def __len__(self) -> int:
        return len(self.bars)
    
    def __iter__(self) -> Iterator[OHLCV]:
        return iter(self.bars)
    
    def __bool__(self) -> bool:
        return bool(self.bars)

    @classmethod
    def from_dict(cls, data: JSON) -> ChartResult:
        """
        Create a `ChartResult` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        ChartResult
            The parsed chart result instance.
        """
        results = data.get("chart", {}).get("result", [])
        if not results:
            return cls()
        r = results[0]

        meta = ChartMeta.from_dict(r.get("meta", {}))
        timestamps = r.get("timestamp") or []
        indicators = r.get("indicators", {})
        quote = indicators.get("quote", [{}])
        q = quote[0] if quote else {}
        adjclose_list = indicators.get("adjclose", [{}])
        adj = adjclose_list[0].get("adjclose", []) if adjclose_list else []

        opens = q.get("open", [])
        highs = q.get("high", [])
        lows = q.get("low", [])
        closes = q.get("close", [])
        volumes = q.get("volume", [])

        bars: list[OHLCV] = []
        for i, ts in enumerate(timestamps):
            bars.append(
                OHLCV(
                    timestamp=ts,
                    open=opens[i] if i < len(opens) else None,
                    high=highs[i] if i < len(highs) else None,
                    low=lows[i] if i < len(lows) else None,
                    close=closes[i] if i < len(closes) else None,
                    volume=volumes[i] if i < len(volumes) else None,
                    adj_close=adj[i] if i < len(adj) else None
                )
            )

        events = r.get("events", {})
        dividends: list[DividendEvent] = []
        for d in (events.get("dividends") or {}).values():
            dividends.append(DividendEvent(date=d.get("date", 0), amount=d.get("amount", 0.0)))

        splits: list[SplitEvent] = []
        for s in (events.get("splits") or {}).values():
            splits.append(
                SplitEvent(
                    date=s.get("date", 0),
                    numerator=s.get("numerator", 0),
                    denominator=s.get("denominator", 0),
                    ratio=s.get("splitRatio", "")
                )
            )

        return cls(meta=meta, bars=bars, dividends=dividends, splits=splits)

    @property
    def symbol(self) -> str:
        return self.meta.symbol
    
    def quote(self) -> Quote:
        """Fetch the full quote for this chart's symbol."""
        client = self._require_sync_client()
        result = client.quote(self.symbol)
        return result[0] if result else Quote(symbol=self.symbol)
    
    async def async_quote(self) -> Quote:
        """Fetch the full quote for this chart's symbol (async)."""
        client = self._require_async_client()
        result = await client.quote(self.symbol)
        return result[0] if result else Quote(symbol=self.symbol)