"""Screener response models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterator

from pyahoo._types import JSON


@dataclass(slots=True)
class ScreenerQuote:
    """
    A single quote result from a screener.
    
    Attributes
    ----------
    symbol : str
        The ticker symbol.
    short_name : str | None
        Short name of the entity.
    regular_market_price : float | None
        Regular market price.
    regular_market_change : float | None
        Regular market change.
    regular_market_change_percent : float | None
        Regular market change percentage.
    regular_market_volume : int | None
        Regular market volume.
    market_cap : int | None
        Market capitalization.
    raw : JSON
        Raw response data.
    """

    symbol: str = ""
    short_name: str | None = None
    regular_market_price: float | None = None
    regular_market_change: float | None = None
    regular_market_change_percent: float | None = None
    regular_market_volume: int | None = None
    market_cap: int | None = None
    raw: JSON = field(default_factory=dict, repr=False)

    def __str__(self) -> str:
        price = f"${self.regular_market_price:,.2f}" if self.regular_market_price is not None else "N/A"
        pct = f" {self.regular_market_change_percent:+.2f}%" if self.regular_market_change_percent is not None else ""
        return f"{self.symbol} {price}{pct}"

    @classmethod
    def from_dict(cls, data: JSON) -> ScreenerQuote:
        """
        Create a `ScreenerQuote` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        ScreenerQuote
            The parsed `ScreenerQuote` instance.
        """
        def _raw(key: str) -> Any:
            v = data.get(key)
            return v.get("raw") if isinstance(v, dict) else v

        return cls(
            symbol=data.get("symbol", ""),
            short_name=data.get("shortName"),
            regular_market_price=_raw("regularMarketPrice"),
            regular_market_change=_raw("regularMarketChange"),
            regular_market_change_percent=_raw("regularMarketChangePercent"),
            regular_market_volume=_raw("regularMarketVolume"),
            market_cap=_raw("marketCap"),
            raw=data
        )
    

@dataclass(slots=True)
class ScreenerResult:
    """
    Result set from a predefined or discover screener.
    
    Attributes
    ----------
    id : str
        The screener ID.
    title : str
        Title of the screener.
    description : str
        Description of the screener.
    total : int
        Total number of results available.
    quotes : list[ScreenerQuote]
        List of returned quote results.
    """

    id: str = ""
    title: str = ""
    description: str = ""
    total: int = 0
    quotes: list[ScreenerQuote] = field(default_factory=list)

    def __str__(self) -> str:
        return f"Screener({self.title or self.id}: {len(self.quotes)}/{self.total} quotes)"

    def __len__(self) -> int:
        return len(self.quotes)

    def __iter__(self) -> Iterator[ScreenerQuote]:
        return iter(self.quotes)

    def __bool__(self) -> bool:
        return bool(self.quotes)

    @classmethod
    def from_dict(cls, data: JSON) -> ScreenerResult:
        """
        Create a `ScreenerResult` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        
        Returns
        -------
        ScreenerResult
            The parsed `ScreenerResult` instance.
        """
        quotes = [ScreenerQuote.from_dict(q) for q in data.get("quotes", [])]
        return cls(
            id=data.get("id", data.get("canonicalName", "")),
            title=data.get("title", ""),
            description=data.get("description", ""),
            total=data.get("total", 0),
            quotes=quotes
        )