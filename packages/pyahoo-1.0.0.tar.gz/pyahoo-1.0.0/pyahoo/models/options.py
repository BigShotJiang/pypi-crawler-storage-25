"""Options chain response models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pyahoo._types import JSON


@dataclass(slots=True)
class OptionContract:
    """
    A single option contract (call or put).
    
    Attributes
    ----------
    contract_symbol : str
        The full contract symbol.
    strike : float | None
        The strike price.
    currency : str | None
        The currency code.
    last_price : float | None
        The last traded price.
    change : float | None
        Price change.
    percent_change : float | None
        Percentage price change.
    volume : int | None
        Trading volume.
    open_interest : int | None
        Open interest value.
    bid : float | None
        Current bid price.
    ask : float | None
        Current ask price.
    implied_volatility : float | None
        Implied volatility.
    in_the_money : bool
        Whether the option is in the money.
    contract_size : str | None
        Contract size type (e.g., REGULAR).
    last_trade_date : int | None
        Timestamp of the last trade.
    expiration : int | None
        Expiration timestamp.
    """

    contract_symbol: str = ""
    strike: float | None = None
    currency: str | None = None
    last_price: float | None = None
    change: float | None = None
    percent_change: float | None = None
    volume: int | None = None
    open_interest: int | None = None
    bid: float | None = None
    ask: float | None = None
    implied_volatility: float | None = None
    in_the_money: bool = False
    contract_size: str | None = None
    last_trade_date: int | None = None
    expiration: int | None = None

    def __str__(self) -> str:
        strike = f"${self.strike:,.2f}" if self.strike is not None else "N/A"
        bid = f"${self.bid:,.2f}" if self.bid is not None else "N/A"
        ask = f"${self.ask:,.2f}" if self.ask is not None else "N/A"
        itm = " ITM" if self.in_the_money else ""
        return f"{self.contract_symbol} strike={strike} bid={bid} ask={ask}{itm}"

    @classmethod
    def from_dict(cls, data: JSON) -> OptionContract:
        """
        Create an `OptionContract` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        OptionContract
            The parsed `OptionContract` instance.
        """
        def _raw(key: str) -> Any:
            v = data.get(key)
            return v.get("raw") if isinstance(v, dict) else v

        return cls(
            contract_symbol=data.get("contractSymbol", ""),
            strike=_raw("strike"),
            currency=data.get("currency"),
            last_price=_raw("lastPrice"),
            change=_raw("change"),
            percent_change=_raw("percentChange"),
            volume=_raw("volume"),
            open_interest=_raw("openInterest"),
            bid=_raw("bid"),
            ask=_raw("ask"),
            implied_volatility=_raw("impliedVolatility"),
            in_the_money=data.get("inTheMoney", False),
            contract_size=data.get("contractSize"),
            last_trade_date=_raw("lastTradeDate"),
            expiration=_raw("expiration")
        )
    

@dataclass(slots=True)
class OptionsChain:
    """
    Options chain for a symbol including calls, puts, and metadata.

    Attributes
    ----------
    underlying_symbol : str
        The underlying asset's ticker symbol.
    expiration_dates : list[int]
        List of available expiration timestamps.
    strikes : list[float]
        List of all strike prices.
    has_mini_options : bool
        Whether the chain contains mini options.
    calls : list[OptionContract]
        List of call OptionContracts.
    puts : list[OptionContract]
        List of put OptionContracts.
    underlying_price : float | None
        The regular market price of the underlying symbol.
    underlying_change : float | None
        The regular market change of the underlying symbol.
    """

    underlying_symbol: str = ""
    expiration_dates: list[int] = field(default_factory=list)
    strikes: list[float] = field(default_factory=list)
    has_mini_options: bool = False
    calls: list[OptionContract] = field(default_factory=list)
    puts: list[OptionContract] = field(default_factory=list)
    underlying_price: float | None = None
    underlying_change: float | None = None

    def __str__(self) -> str:
        price = f"${self.underlying_price:,.2f}" if self.underlying_price is not None else "N/A"
        return (
            f"OptionsChain({self.underlying_symbol} {price} "
            f"{len(self.calls)} calls, {len(self.puts)} puts, "
            f"{len(self.expiration_dates)} expirations)"
        )

    def __len__(self) -> int:
        return len(self.calls) + len(self.puts)

    def __bool__(self) -> bool:
        return bool(self.calls or self.puts)

    @classmethod
    def from_dict(cls, data: JSON) -> OptionsChain:
        """
        Create an `OptionsChain` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        
        Returns
        -------
        OptionsChain
            The parsed `OptionsChain` instance.
        """
        results = data.get("optionChain", {}).get("result", [])
        if not results:
            return cls()
        r = results[0]

        quote = r.get("quote", {})
        options_list = r.get("options", [])
        opt = options_list[0] if options_list else {}

        calls = [OptionContract.from_dict(c) for c in opt.get("calls", [])]
        puts = [OptionContract.from_dict(p) for p in opt.get("puts", [])]

        return cls(
            underlying_symbol=r.get("underlyingSymbol", ""),
            expiration_dates=r.get("expirationDates", []),
            strikes=r.get("strikes", []),
            has_mini_options=r.get("hasMiniOptions", False),
            calls=calls,
            puts=puts,
            underlying_price=quote.get("regularMarketPrice"),
            underlying_change=quote.get("regularMarketChange")
        )