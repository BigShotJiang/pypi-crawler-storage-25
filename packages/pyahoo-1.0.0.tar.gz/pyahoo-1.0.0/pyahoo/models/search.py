"""Search / Autocomplete response models."""

from __future__ import annotations

from dataclasses import dataclass, field

from pyahoo._types import JSON
from pyahoo.models.base import YahooModel
from pyahoo.models.quote import Quote


@dataclass
class SearchQuoteResult(YahooModel):
    """
    A single symbol match from a search query.
    
    Attributes
    ----------
    symbol : str
        The matched ticker symbol.
    short_name : str | None
        Short name of the entity.
    long_name : str | None
        Long name of the entity.
    quote_type : str | None
        Type of quote (e.g., EQUITY).
    exchange : str | None
        Exchange name.
    exchange_display : str | None
        Exchange display name.
    sector : str | None
        Sector name.
    industry : str | None
        Industry name.
    score : int
        Relevance score of the match.
    logo_url : str | None
        URL to the entity's logo.
    is_yahoo_finance : bool
        Whether the result is a Yahoo Finance entity.
    """

    symbol: str = ""
    short_name: str | None = None
    long_name: str | None = None
    quote_type: str | None = None
    exchange: str | None = None
    exchange_display: str | None = None
    sector: str | None = None
    industry: str | None = None
    score: int = 0
    logo_url: str | None = None
    is_yahoo_finance: bool = False

    def __str__(self) -> str:
        name = self.long_name or self.short_name or self.symbol
        qt = f" ({self.quote_type})" if self.quote_type else ""
        return f"{self.symbol}: {name}{qt}"

    @classmethod
    def from_dict(cls, data: JSON) -> SearchQuoteResult:
        """
        Create a `SearchQuoteResult` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.

        Returns
        -------
        SearchQuoteResult
            The parsed `SearchQuoteResult` instance.
        """
        return cls(
            symbol=data.get("symbol", ""),
            short_name=data.get("shortname"),
            long_name=data.get("longname"),
            quote_type=data.get("quoteType"),
            exchange=data.get("exchange"),
            exchange_display=data.get("exchDisp"),
            sector=data.get("sector"),
            industry=data.get("industry"),
            score=data.get("score", 0),
            logo_url=data.get("logoUrl"),
            is_yahoo_finance=data.get("isYahooFinance", False)
        )
    
    def quote(self) -> Quote:
        """
        Fetch full quote data for this search result's symbol.
        
        Returns
        -------
        Quote
            The full quote data for the symbol.
        """
        client = self._require_sync_client()
        result = client.quote(self.symbol)

        return result[0] if result else Quote(symbol=self.symbol)
    
    async def async_quote(self) -> Quote:
        """
        Fetch full quote data for this search result's symbol (async).
        
        Returns
        -------
        Quote
            The full quote data for the symbol.
        """
        client = self._require_async_client()
        result = await client.quote(self.symbol)

        return result[0] if result else Quote(symbol=self.symbol)
    

@dataclass(slots=True)
class SearchNewsResult:
    """
    A news article from a search query.
    
    Attributes
    ----------
    uuid : str
        Article UUID.
    title : str
        Article title.
    publisher : str | None
        Publisher name.
    link : str | None
        URL to the article.
    publish_time : int | None
        Publish timestamp.
    content_type : str | None
        Content type (e.g., STORY).
    """

    uuid: str = ""
    title: str = ""
    publisher: str | None = None
    link: str | None = None
    publish_time: int | None = None
    content_type: str | None = None

    def __str__(self) -> str:
        return f"{self.title} ({self.publisher})"

    @classmethod
    def from_dict(cls, data: JSON) -> SearchNewsResult:
        """
        Create a `SearchNewsResult` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        
        Returns
        -------
        SearchNewsResult
            The parsed `SearchNewsResult` instance.
        """
        return cls(
            uuid=data.get("uuid", ""),
            title=data.get("title", ""),
            publisher=data.get("publisher"),
            link=data.get("link"),
            publish_time=data.get("providerPublishTime"),
            content_type=data.get("type")
        )
    

@dataclass(slots=True)
class SearchResult:
    """
    Top-level search response containing quotes and news.
    
    Attributes
    ----------
    quotes : list[SearchQuoteResult]
        List of matched symbols.
    news : list[SearchNewsResult]
        List of matching news articles.
    total_count : int
        Total number of quote results.
    """

    quotes: list[SearchQuoteResult] = field(default_factory=list)
    news: list[SearchNewsResult] = field(default_factory=list)
    total_count: int = 0

    def __str__(self) -> str:
        return f"SearchResult({len(self.quotes)} quotes, {len(self.news)} news)"

    def __len__(self) -> int:
        return len(self.quotes)

    def __bool__(self) -> bool:
        return bool(self.quotes or self.news)

    @classmethod
    def from_dict(cls, data: JSON) -> SearchResult:
        """
        Create a `SearchResult` instance from a dict.

        Parameters
        ----------
        data : JSON
            The raw JSON dictionary.
        
        Returns
        -------
        SearchResult
            The parsed `SearchResult` instance.
        """
        quotes = [SearchQuoteResult.from_dict(q) for q in data.get("quotes", [])]
        news = [SearchNewsResult.from_dict(n) for n in data.get("news", [])]
        return cls(quotes=quotes, news=news, total_count=data.get("count", 0))