"""Base model."""

from __future__ import annotations

import weakref
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyahoo.async_client import AsyncYahooFinance
    from pyahoo.client import YahooFinance


@dataclass
class YahooModel:
    """
    Base class for all pyahoo response models.

    Holds an optional weak reference to the client that produced
    this object, enabling bound convenience methods like
    `quote.chart()`.
    """

    _client_ref: Any = field(default=None, init=False, repr=False, compare=False)

    @property
    def _client(self) -> YahooFinance | AsyncYahooFinance | None:
        """
        Resolve the weak reference to the client.

        Returns
        -------
        YahooFinance | AsyncYahooFinance | None
            The client instance, or None if not bound.
        """
        if self._client_ref is None:
            return None
        return self._client_ref()

    def _bind(self, client: YahooFinance | AsyncYahooFinance) -> None:
        """
        Attach a weak reference to the originating client.

        Parameters
        ----------
        client : YahooFinance | AsyncYahooFinance
            The client instance to bind.
        """
        try:
            self._client_ref = weakref.ref(client)
        except TypeError:
            self._client_ref = lambda: client
    
    def _require_client(self) -> YahooFinance | AsyncYahooFinance:
        """
        Return the client or raise RuntimeError if not bound.

        Returns
        -------
        YahooFinance | AsyncYahooFinance
            The bound client instance.

        Raises
        ------
        RuntimeError
            If the model is not bound to a client.
        """
        c = self._client
        if c is None:
            raise RuntimeError(
                "This model is not bound to a client. "
                "Use a model returned by a YahooFinance / AsyncYahooFinance method."
            )
        return c
    
    def _require_sync_client(self) -> YahooFinance:
        """
        Return the sync client or raise TypeError if bound to an async client.

        Returns
        -------
        YahooFinance
            The bound synchronous client instance.
        
        Raises
        ------
        TypeError
            If the model is bound to an async client.
        """
        c = self._require_client()
        if type(c).__name__ != "YahooFinance":
            raise TypeError("This model is bound to an async client. Use the async variant.")
        return c
    
    def _require_async_client(self) -> AsyncYahooFinance:
        """
        Return the async client or raise TypeError if bound to an sync client.

        Returns
        -------
        AsyncYahooFinance
            The bound asynchronous client instance.

        Raises
        ------
        TypeError
            If the model is bound to a sync client.
        """
        c = self._require_client()
        if type(c).__name__ != "AsyncYahooFinance":
            raise TypeError("This model is bound to a sync client. Use the sync variant.")
        return c