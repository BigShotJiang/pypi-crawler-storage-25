# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Multi-valued array implementation.

Provides the MultiValuedArray class for efficiently storing variable-length
arrays where each element can map to multiple values (CSR-like storage).

Each element in the domain can map to zero, one, or more values in the codomain.
Data is stored compactly using counts/offsets and a flat values array.

Note:
    MultiValuedArray instances are not thread-safe. Do not share across
    threads without external synchronization.
"""

from __future__ import annotations

import copy
import inspect
from collections.abc import Iterator, Sequence

import numpy as np
from numba import njit
from vcti.nputils import position_array

__all__ = ["MultiValuedArray"]


def _to_ndarray(array: object) -> np.ndarray | None:
    """Convert list/tuple to ndarray, pass through ndarray and None unchanged."""
    if array is None:
        return None
    if isinstance(array, np.ndarray):
        return array
    if isinstance(array, (list, tuple)):
        return np.array(array)
    raise TypeError(f"Expected ndarray, list, tuple, or None, got {type(array).__name__}")


def _arrays_equal(a: np.ndarray | None, b: np.ndarray | None) -> bool:
    """Compare two optional ndarrays for element-wise equality."""
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    return bool(np.array_equal(a, b))


class MultiValuedArray:
    """Multi-valued array using CSR-like storage format.

    Efficiently stores variable-length arrays where each element in the domain
    can have multiple values. Can represent A->B mappings.

    The data is stored using either:
    - counts: Number of values for each element
    - offsets: Cumulative positions in the values array

    Only one of counts or offsets needs to be provided; the other is computed lazily.

    Note:
        Instances are not thread-safe. The lazy caching of counts, offsets,
        and value_indices is unsynchronized.

    Example:
        >>> mva = MultiValuedArray(counts=[2, 1, 3], values=[10, 20, 30, 40, 50, 60])
        >>> mva.offsets()  # array([0, 2, 3, 6])
        >>> len(mva)       # 3
        >>> mva[0]         # array([10, 20])
        >>> list(mva)      # [array([10, 20]), array([30]), array([40, 50, 60])]
    """

    __slots__ = ("_counts", "_offsets", "_values", "_domain", "_codomain", "_value_indices")
    __hash__: None  # type: ignore[assignment]  # mutable + __eq__ → unhashable

    def __init__(
        self,
        counts: np.ndarray | Sequence | None = None,
        offsets: np.ndarray | Sequence | None = None,
        values: np.ndarray | Sequence | None = None,
        domain: np.ndarray | Sequence | None = None,
        codomain: np.ndarray | Sequence | None = None,
        counts_offsets_prechecked: bool = False,
    ) -> None:
        """Initialize a MultiValuedArray.

        Args:
            counts: Array of counts for each element.
            offsets: Cumulative offsets into the values array (length = n+1).
            values: Flat array containing all values.
            domain: Optional domain element identifiers.
            codomain: Optional codomain element identifiers.
            counts_offsets_prechecked: If True, allows both counts and offsets
                to be provided when known consistent.

        Raises:
            ValueError: If neither counts nor offsets specified, or both
                without prechecked flag, or domain dimensions mismatch.
        """
        counts = _to_ndarray(counts)
        offsets = _to_ndarray(offsets)
        values = _to_ndarray(values)
        domain = _to_ndarray(domain)
        codomain = _to_ndarray(codomain)

        if counts is None and offsets is None:
            raise ValueError("Neither counts nor offsets specified")
        if counts is not None and offsets is not None and not counts_offsets_prechecked:
            raise ValueError(
                f"Both counts (shape {counts.shape}) and offsets (shape {offsets.shape}) "
                f"are specified; provide only one, or set counts_offsets_prechecked=True"
            )
        if domain is not None:
            if counts is not None and domain.shape[0] != counts.shape[0]:
                raise ValueError(
                    f"Domain length {domain.shape[0]} does not match "
                    f"counts length {counts.shape[0]}"
                )
            if offsets is not None and domain.shape[0] != offsets.shape[0] - 1:
                raise ValueError(
                    f"Domain length {domain.shape[0]} does not match "
                    f"element count from offsets ({offsets.shape[0] - 1})"
                )

        self._counts: np.ndarray | None = counts
        self._offsets: np.ndarray | None = offsets
        self._domain: np.ndarray | None = domain
        self._codomain: np.ndarray | None = codomain
        self._value_indices: np.ndarray | None = None
        self._values: np.ndarray | None = None
        if values is not None:
            self.set_values(values)

    def set_values(self, values: np.ndarray | None) -> None:
        """Set the values array and invalidate cached computations.

        Args:
            values: Flat array of values, or None to clear.

        Raises:
            ValueError: If values size doesn't match offsets.
        """
        if values is not None:
            offsets = self.offsets()
            if offsets is None:
                raise ValueError("Cannot set values when offsets cannot be computed")
            if values.shape[0] != offsets[-1]:
                raise ValueError(
                    f"Values array size {values.shape[0]} does not match "
                    f"expected size {offsets[-1]} (from offsets)"
                )
        self._values = values
        self._value_indices = None

    def offsets(self) -> np.ndarray | None:
        """Get offsets array, computing from counts if needed.

        Returns:
            Cumulative offsets of shape (n+1,), or None if unavailable.
        """
        if self._offsets is not None:
            return self._offsets
        if self._counts is None:
            return None

        self._offsets = position_array(self._counts)
        return self._offsets

    def counts(self) -> np.ndarray | None:
        """Get counts array, computing from offsets if needed.

        Returns:
            Array of counts of shape (n,), or None if unavailable.
        """
        if self._counts is not None:
            return self._counts
        if self._offsets is None:
            return None

        self._counts = self._offsets[1:] - self._offsets[:-1]
        return self._counts

    def values(self) -> np.ndarray | None:
        """Get the flat values array."""
        return self._values

    def value_indices(self) -> np.ndarray | None:
        """Get array mapping each value to its domain element index.

        Returns:
            Array where value_indices[j] = i means values[j] belongs to element i.
            Returns None if values is None.
        """
        if self._value_indices is not None:
            return self._value_indices
        if self._values is None:
            return None

        counts = self.counts()
        offsets = self.offsets()
        assert offsets is not None
        assert counts is not None

        self._value_indices = np.empty(self._values.shape, np.uint32)
        _fill_value_indices(offsets, counts, self._value_indices)
        return self._value_indices

    def domain(self) -> np.ndarray | None:
        """Get the domain array (element identifiers)."""
        return self._domain

    def codomain(self) -> np.ndarray | None:
        """Get the codomain array (value space identifiers)."""
        return self._codomain

    def __len__(self) -> int:
        """Return the number of elements (domain size)."""
        if self._counts is not None:
            return len(self._counts)
        if self._offsets is not None:
            return len(self._offsets) - 1
        return 0  # pragma: no cover

    def __getitem__(self, index: int) -> np.ndarray | None:
        """Return the values for element at *index*.

        Args:
            index: Element index (supports negative indexing).

        Returns:
            Slice of the values array for that element, or None if values not set.

        Raises:
            IndexError: If index is out of range.
        """
        n = len(self)
        if index < 0:
            index += n
        if index < 0 or index >= n:
            raise IndexError(f"index {index} is out of range for size {n}")
        if self._values is None:
            return None
        offsets = self.offsets()
        assert offsets is not None
        return self._values[offsets[index] : offsets[index + 1]]

    def __iter__(self) -> Iterator[np.ndarray | None]:
        """Iterate over elements, yielding each element's values slice.

        Yields:
            numpy array slice for each element, or None per element if
            values are not set.
        """
        for i in range(len(self)):
            yield self[i]

    def __eq__(self, other: object) -> bool:
        """Check structural equality of two MultiValuedArrays.

        Two instances are equal when their counts, values, domain,
        and codomain arrays are element-wise equal.
        """
        if not isinstance(other, MultiValuedArray):
            return NotImplemented
        if not _arrays_equal(self.counts(), other.counts()):
            return False
        if not _arrays_equal(self.values(), other.values()):
            return False
        if not _arrays_equal(self.domain(), other.domain()):
            return False
        if not _arrays_equal(self.codomain(), other.codomain()):
            return False
        return True

    def __copy__(self) -> MultiValuedArray:
        """Shallow copy — arrays are shared with the original."""
        return MultiValuedArray(
            counts=self._counts,
            offsets=self._offsets,
            values=self._values,
            domain=self._domain,
            codomain=self._codomain,
            counts_offsets_prechecked=True,
        )

    def __deepcopy__(self, memo: dict) -> MultiValuedArray:  # type: ignore[type-arg]
        """Deep copy — all arrays are independently copied."""
        return MultiValuedArray(
            counts=copy.deepcopy(self._counts, memo),
            offsets=copy.deepcopy(self._offsets, memo),
            values=copy.deepcopy(self._values, memo),
            domain=copy.deepcopy(self._domain, memo),
            codomain=copy.deepcopy(self._codomain, memo),
            counts_offsets_prechecked=True,
        )

    def __repr__(self) -> str:
        n_elements = len(self)
        n_values = len(self._values) if self._values is not None else 0
        dtype = self._values.dtype if self._values is not None else None
        if dtype is not None:
            return f"MultiValuedArray(n={n_elements}, nnz={n_values}, dtype={dtype})"
        return f"MultiValuedArray(n={n_elements}, nnz={n_values})"

    def __str__(self) -> str:
        parts = ["MultiValuedArray:"]

        if self._counts is not None:
            parts.append(f"  counts: {self._counts.shape} {self._counts.dtype}")
        else:
            parts.append("  counts: not computed")

        if self._offsets is not None:
            parts.append(f"  offsets: {self._offsets.shape} {self._offsets.dtype}")
        else:
            parts.append("  offsets: not computed")

        if self._values is not None:
            parts.append(f"  values: {self._values.shape} {self._values.dtype}")
        else:
            parts.append("  values: None")

        if self._domain is not None:
            parts.append(f"  domain: {self._domain.shape}")

        if self._codomain is not None:
            parts.append(f"  codomain: {self._codomain.shape}")

        return "\n".join(parts)

    def debug_info(self) -> str:
        """Detailed string with full array contents.

        Warning: triggers computation of all lazy-evaluated fields.
        """
        return inspect.cleandoc(f"""
            MultiValuedArray Debug Info:
            Counts:
                {self.counts()}
            Offsets:
                {self.offsets()}
            Values:
                {self.values()}
            Value Indices:
                {self.value_indices()}
            Domain:
                {self.domain()}
            Codomain:
                {self.codomain()}
        """)


@njit
def _fill_value_indices(offsets: np.ndarray, counts: np.ndarray, value_indices: np.ndarray):
    """Fill value_indices: value_indices[j] = i means values[j] belongs to element i."""
    for ind in range(counts.shape[0]):
        value_indices[offsets[ind] : offsets[ind + 1]] = ind
