# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""vcti.multivalued — Variable-length array for multivalued mappings."""

from importlib.metadata import version

from .multi_valued import MultiValuedArray
from .utils import (
    cascade,
    concatenate,
    from_joint_counts_and_values_array,
    get_chunk,
    get_counts_values_array,
    non_negative_array,
    reverse,
    sort_and_unique,
)

__version__ = version("vcti-multi-valued-array")

__all__ = [
    "__version__",
    "MultiValuedArray",
    "cascade",
    "concatenate",
    "from_joint_counts_and_values_array",
    "get_chunk",
    "get_counts_values_array",
    "non_negative_array",
    "reverse",
    "sort_and_unique",
]
