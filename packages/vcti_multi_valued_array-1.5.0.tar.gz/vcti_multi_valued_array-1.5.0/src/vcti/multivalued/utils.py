# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Utility functions for MultiValuedArray operations.

Provides reverse, cascade, concatenate, sort_and_unique, and other
operations on multivalued mappings.
"""

from __future__ import annotations

import numpy as np
from numba import njit

from .multi_valued import MultiValuedArray, _arrays_equal, _to_ndarray

__all__ = [
    "reverse",
    "cascade",
    "concatenate",
    "sort_and_unique",
    "non_negative_array",
    "from_joint_counts_and_values_array",
    "get_counts_values_array",
    "get_chunk",
]


def reverse(forward_map: MultiValuedArray) -> MultiValuedArray:
    """Reverse a mapping (A->B becomes B->A).

    Args:
        forward_map: MultiValuedArray representing A->B mapping.
            Values must be non-negative integers indexing into the codomain.

    Returns:
        MultiValuedArray representing the reversed B->A mapping.

    Raises:
        TypeError: If values are not integer type.
        ValueError: If values array is not set, or contains negative values,
            or values exceed codomain bounds.
    """
    fwd_values = forward_map.values()
    if fwd_values is None:
        raise ValueError("Cannot reverse: values array is not set")
    if not np.issubdtype(fwd_values.dtype, np.integer):
        raise TypeError(f"reverse requires integer values, got dtype {fwd_values.dtype}")

    # Bounds checking
    if fwd_values.shape[0] > 0:
        min_val = int(np.min(fwd_values))
        max_val = int(np.max(fwd_values))
        if min_val < 0:
            raise ValueError(
                f"reverse requires non-negative values, but found minimum value {min_val}"
            )
        codomain = forward_map.codomain()
        if codomain is not None and max_val >= codomain.shape[0]:
            raise ValueError(
                f"Value {max_val} exceeds codomain size {codomain.shape[0]}; "
                f"values must be in range [0, {codomain.shape[0] - 1}]"
            )

    codomain = forward_map.codomain()
    minlen = codomain.shape[0] if codomain is not None else None

    if minlen is not None:
        rev_counts = np.bincount(fwd_values, minlength=minlen)
    else:
        rev_counts = np.bincount(fwd_values)

    reverse_map = MultiValuedArray(
        counts=rev_counts, domain=forward_map.codomain(), codomain=forward_map.domain()
    )
    rev_offsets = reverse_map.offsets()
    assert rev_offsets is not None
    rev_values = np.empty((rev_offsets[-1],), dtype=fwd_values.dtype)
    next_pos = rev_offsets[:-1].copy()
    fwd_vi = forward_map.value_indices()
    assert fwd_vi is not None
    _fill_reverse_map_values(rev_values, fwd_values, fwd_vi, next_pos)
    reverse_map.set_values(rev_values)
    return reverse_map


@njit
def _fill_reverse_map_values(inv_values, values, value_indices, next_pos):
    for ind in range(values.shape[0]):
        inv_ind = values[ind]
        inv_pos = next_pos[inv_ind]
        inv_values[inv_pos] = value_indices[ind]
        next_pos[inv_ind] += 1


def from_joint_counts_and_values_array(
    counts_and_values_array: np.ndarray | None,
    domain: np.ndarray | None = None,
    codomain: np.ndarray | None = None,
) -> MultiValuedArray | None:
    """Create from an interleaved counts-and-values array.

    Format: [count1, val1_1, val1_2, ..., count2, val2_1, ...]

    Args:
        counts_and_values_array: Interleaved array, or None.
        domain: Optional domain array.
        codomain: Optional codomain array.

    Returns:
        MultiValuedArray, or None if input is None.
    """
    arr = _to_ndarray(counts_and_values_array)
    if arr is None:
        return None
    empty_array = np.empty((0,), dtype=arr.dtype)
    if arr.shape[0] == 0:
        return MultiValuedArray(counts=empty_array, values=empty_array)

    is_count = _extract_is_count_array(arr)
    return MultiValuedArray(
        counts=arr[np.nonzero(is_count)[0]],
        values=arr[np.nonzero(np.logical_not(is_count))[0]],
        domain=domain,
        codomain=codomain,
    )


@njit
def _extract_is_count_array(counts_and_values_array):
    is_count = np.zeros(counts_and_values_array.shape, dtype=np.bool_)
    idx = 0
    while idx < counts_and_values_array.shape[0]:
        is_count[idx] = True
        idx += counts_and_values_array[idx] + 1
    return is_count


def non_negative_array(
    src_vals: np.ndarray,
    domain: np.ndarray | None = None,
    codomain: np.ndarray | None = None,
) -> MultiValuedArray:
    """Extract non-negative values from a 2D array.

    Args:
        src_vals: 2D array where negative values should be filtered out.
        domain: Optional domain array.
        codomain: Optional codomain array.

    Returns:
        MultiValuedArray containing only non-negative values from each row.
    """
    src = _to_ndarray(src_vals)
    assert src is not None
    non_neg_count = np.sum((src >= 0).astype(np.uint32), axis=1)
    non_negs = MultiValuedArray(counts=non_neg_count, domain=domain, codomain=codomain)
    offsets = non_negs.offsets()
    assert offsets is not None
    num_non_negs = offsets[-1]
    non_neg_values = np.empty((num_non_negs,), dtype=src.dtype)
    next_pos = offsets[:-1].copy()
    _fill_non_neg_values(non_neg_values, src, next_pos)
    non_negs.set_values(non_neg_values)
    return non_negs


@njit
def _fill_non_neg_values(non_negs, src_vals, next_pos):
    for ind in range(src_vals.shape[0]):
        for axis in range(src_vals.shape[1]):
            if src_vals[ind][axis] >= 0:
                non_negs[next_pos[ind]] = src_vals[ind][axis]
                next_pos[ind] += 1


def sort_and_unique(dup: MultiValuedArray) -> MultiValuedArray:
    """Sort and remove duplicate values from each element.

    .. warning::

        **Destructive**: this function modifies the values array of *dup*
        in place during sorting. The caller should treat *dup* as consumed
        after this call. Copy the input first if you need to preserve it::

            result = sort_and_unique(copy.deepcopy(mva))

    Args:
        dup: MultiValuedArray that may contain duplicate values.

    Returns:
        New MultiValuedArray with sorted, unique values per element.

    Raises:
        ValueError: If values array is not set.
    """
    dup_values = dup.values()
    dup_counts = dup.counts()
    dup_offsets = dup.offsets()
    if dup_values is None:
        raise ValueError("Cannot sort_and_unique: values array is not set")
    assert dup_counts is not None
    assert dup_offsets is not None

    unq_counts = _sort_values(dup_counts, dup_offsets, dup_values)
    unq = MultiValuedArray(counts=unq_counts, domain=dup.domain(), codomain=dup.codomain())
    unq_offsets = unq.offsets()
    unq_counts_arr = unq.counts()
    assert unq_offsets is not None
    assert unq_counts_arr is not None
    unq_vals = np.empty((unq_offsets[-1],), dup_values.dtype)
    _fill_unique_values(unq_counts_arr, unq_offsets, unq_vals, dup_offsets, dup_values)
    unq.set_values(unq_vals)
    return unq


@njit
def _sort_values(counts, offsets, values):
    unq_counts = np.empty(counts.shape, counts.dtype)
    for ind in range(counts.shape[0]):
        unq_vals = np.unique(values[offsets[ind] : offsets[ind + 1]])
        unq_counts[ind] = unq_vals.shape[0]
        values[offsets[ind] : offsets[ind] + unq_counts[ind]] = unq_vals
    return unq_counts


@njit
def _fill_unique_values(unq_counts, unq_offsets, unq_vals, dup_offsets, dup_vals):
    for ind in range(unq_counts.shape[0]):
        unq_vals[unq_offsets[ind] : unq_offsets[ind + 1]] = dup_vals[
            dup_offsets[ind] : dup_offsets[ind] + unq_counts[ind]
        ]


def cascade(
    ab: MultiValuedArray,
    bc: MultiValuedArray,
    verify: bool = False,
    unique: bool = False,
) -> MultiValuedArray:
    """Compose two mappings (A->B and B->C to produce A->C).

    Args:
        ab: A->B mapping. Values must be valid indices into bc's domain.
        bc: B->C mapping.
        verify: If True, validate that all ab values are within bc's domain
            bounds. Defaults to False for performance.
        unique: If True, sort and deduplicate result.

    Returns:
        A->C mapping.

    Raises:
        ValueError: If domains don't match, verification fails, or values missing.
    """
    ab_values = ab.values()
    bc_values = bc.values()
    if ab_values is None:
        raise ValueError("Cannot cascade: ab has no values")
    if bc_values is None:
        raise ValueError("Cannot cascade: bc has no values")

    ab_codomain = ab.codomain()
    bc_domain = bc.domain()
    if ab_codomain is not None and bc_domain is not None:
        if not _arrays_equal(ab_codomain, bc_domain):
            raise ValueError(
                f"Codomain of ab (shape {ab_codomain.shape}) does not match "
                f"domain of bc (shape {bc_domain.shape})"
            )

    ab_counts = ab.counts()
    ab_offsets = ab.offsets()
    bc_counts = bc.counts()
    bc_offsets = bc.offsets()
    assert ab_counts is not None
    assert ab_offsets is not None
    assert bc_counts is not None
    assert bc_offsets is not None

    # Always check bounds — an out-of-bounds index would cause a silent
    # buffer overread or crash in the @njit kernel.
    if ab_values.shape[0] > 0:
        max_ab = int(np.max(ab_values))
        if max_ab >= bc_counts.shape[0]:
            raise ValueError(
                f"ab contains value {max_ab} which exceeds bc domain size "
                f"{bc_counts.shape[0]}; ab values must be in range "
                f"[0, {bc_counts.shape[0] - 1}]"
            )
        if int(np.min(ab_values)) < 0:
            raise ValueError(
                f"ab contains negative value {int(np.min(ab_values))}; "
                f"cascade requires non-negative integer indices"
            )

    abvc_counts = bc_counts[ab_values]
    ac_counts = np.empty(ab_counts.shape, ab_counts.dtype)
    _fill_ac_counts(ac_counts, ab_offsets, abvc_counts)

    ac_map = MultiValuedArray(counts=ac_counts, domain=ab.domain(), codomain=bc.codomain())
    ac_offsets = ac_map.offsets()
    assert ac_offsets is not None
    ac_map_vals = np.empty((ac_offsets[-1],), bc_values.dtype)
    ac_map_pos = ac_offsets[:-1].copy()
    _fill_ac_map_vals_and_pos(
        ac_map_vals, ac_map_pos, ab_counts, ab_offsets, ab_values, bc_offsets, bc_values
    )
    ac_map.set_values(ac_map_vals)
    if unique:
        return sort_and_unique(ac_map)
    return ac_map


@njit
def _fill_ac_counts(ac_counts, ab_offsets, abvc_counts):
    for ind in range(ac_counts.shape[0]):
        ac_counts[ind] = np.sum(abvc_counts[ab_offsets[ind] : ab_offsets[ind + 1]])


@njit
def _fill_ac_map_vals_and_pos(
    ac_dup_vals, ac_dup_pos, ab_counts, ab_offsets, ab_values, bc_offsets, bc_values
):
    for aind in range(ab_counts.shape[0]):
        for abv_ind in range(ab_offsets[aind], ab_offsets[aind + 1]):
            bval = ab_values[abv_ind]
            for bc_ind in range(bc_offsets[bval], bc_offsets[bval + 1]):
                ac_dup_vals[ac_dup_pos[aind]] = bc_values[bc_ind]
                ac_dup_pos[aind] += 1


def concatenate(mva_a: MultiValuedArray, mva_b: MultiValuedArray) -> MultiValuedArray:
    """Concatenate two MultiValuedArrays vertically.

    Args:
        mva_a: First MultiValuedArray.
        mva_b: Second MultiValuedArray.

    Returns:
        New MultiValuedArray containing elements from both.

    Raises:
        ValueError: If codomains don't match, or values missing.
    """
    values_a = mva_a.values()
    values_b = mva_b.values()
    if values_a is None:
        raise ValueError("Cannot concatenate: first array has no values")
    if values_b is None:
        raise ValueError("Cannot concatenate: second array has no values")

    codomain_a = mva_a.codomain()
    codomain_b = mva_b.codomain()
    if codomain_a is not None and codomain_b is not None:
        if not _arrays_equal(codomain_a, codomain_b):
            raise ValueError(
                f"Codomains do not match: first has shape {codomain_a.shape}, "
                f"second has shape {codomain_b.shape}"
            )

    counts_a = mva_a.counts()
    counts_b = mva_b.counts()
    assert counts_a is not None
    assert counts_b is not None
    counts = np.hstack((counts_a, counts_b))

    # Merge domains: concatenate when both present, drop when only one side has it
    # (a partial domain would mismatch the combined counts dimension).
    domain_a = mva_a.domain()
    domain_b = mva_b.domain()
    if domain_a is not None and domain_b is not None:
        domain: np.ndarray | None = np.hstack((domain_a, domain_b))
    else:
        domain = None

    codomain = codomain_a if codomain_a is not None else codomain_b

    mva_ab = MultiValuedArray(counts=counts, domain=domain, codomain=codomain)
    values = np.hstack((values_a, values_b))
    mva_ab.set_values(values)
    return mva_ab


def get_counts_values_array(mva: MultiValuedArray) -> np.ndarray:
    """Convert to an interleaved counts-and-values array.

    Format: [count1, val1_1, val1_2, ..., count2, ...]

    Args:
        mva: MultiValuedArray to convert.

    Returns:
        Interleaved array. Dtype matches the values array.

    Raises:
        ValueError: If values array is not set.
    """
    values = mva.values()
    if values is None:
        raise ValueError("Cannot convert to counts-values array: values not set")

    counts = mva.counts()
    offsets = mva.offsets()
    assert counts is not None
    assert offsets is not None

    size = counts.shape[0] + values.shape[0]
    counts_values_array = np.empty(size, dtype=values.dtype)

    _fill_counts_values_array(counts_values_array, counts, values, offsets)
    return counts_values_array


@njit
def _fill_counts_values_array(out, counts, values, offsets):
    pos = 0
    for i in range(counts.shape[0]):
        out[pos] = counts[i]
        for j in range(offsets[i], offsets[i + 1]):
            out[pos + 1 + j - offsets[i]] = values[j]
        pos = pos + 1 + counts[i]


def get_chunk(mva: MultiValuedArray, a: int, b: int) -> MultiValuedArray:
    """Extract a slice of a MultiValuedArray.

    The returned MultiValuedArray shares memory with the original via
    numpy views. Mutating the chunk's arrays will mutate the source.
    Copy the result if you need independent data.

    Args:
        mva: Source MultiValuedArray.
        a: Start index (inclusive).
        b: End index (exclusive).

    Returns:
        New MultiValuedArray containing elements [a:b] (views, not copies).
    """
    counts = mva.counts()
    offsets = mva.offsets()
    assert counts is not None
    assert offsets is not None

    chunk_counts = counts[a:b]
    mva_values = mva.values()
    chunk_values = mva_values[offsets[a] : offsets[b]] if mva_values is not None else None
    mva_domain = mva.domain()
    chunk_domain = mva_domain[a:b] if mva_domain is not None else None
    return MultiValuedArray(
        counts=chunk_counts,
        values=chunk_values,
        domain=chunk_domain,
        codomain=mva.codomain(),
    )
