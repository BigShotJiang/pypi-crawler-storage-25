# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Version and packaging tests for vcti-multi-valued-array."""

import re
from pathlib import Path

import vcti.multivalued


class TestVersion:
    def test_version_exists(self):
        assert hasattr(vcti.multivalued, "__version__")

    def test_version_is_valid_semver(self):
        assert re.match(r"^\d+\.\d+\.\d+", vcti.multivalued.__version__)


class TestPackaging:
    def test_py_typed_marker_exists(self):
        """PEP 561 py.typed marker must be present next to __init__.py."""
        init_path = Path(vcti.multivalued.__file__)
        py_typed = init_path.parent / "py.typed"
        assert py_typed.exists(), f"py.typed not found at {py_typed}"
