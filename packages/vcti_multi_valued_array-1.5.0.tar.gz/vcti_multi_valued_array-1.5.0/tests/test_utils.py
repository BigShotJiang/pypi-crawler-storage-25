# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for utils module."""

import numpy as np
import pytest

from vcti.multivalued import (
    MultiValuedArray,
    cascade,
    concatenate,
    from_joint_counts_and_values_array,
    get_chunk,
    get_counts_values_array,
    non_negative_array,
    reverse,
    sort_and_unique,
)


class TestReverse:
    def test_basic(self):
        forward = MultiValuedArray(counts=np.array([2, 1, 1]), values=np.array([1, 2, 2, 3]))
        backward = reverse(forward)
        assert backward.counts()[0] == 0
        assert backward.counts()[1] == 1
        assert backward.counts()[2] == 2
        assert backward.counts()[3] == 1

    def test_with_codomain(self):
        forward = MultiValuedArray(
            counts=np.array([2, 1]),
            values=np.array([0, 1, 1]),
            codomain=np.array([0, 1, 2, 3, 4]),
        )
        backward = reverse(forward)
        assert backward.counts().shape[0] == 5

    def test_non_integer_raises(self):
        forward = MultiValuedArray(counts=np.array([2, 1]), values=np.array([1.5, 2.5, 3.5]))
        with pytest.raises(TypeError, match="integer values"):
            reverse(forward)

    def test_negative_values_raises(self):
        forward = MultiValuedArray(counts=np.array([2]), values=np.array([0, -1]))
        with pytest.raises(ValueError, match="non-negative"):
            reverse(forward)

    def test_out_of_bounds_codomain_raises(self):
        forward = MultiValuedArray(
            counts=np.array([2]),
            values=np.array([0, 5]),
            codomain=np.array([0, 1, 2]),
        )
        with pytest.raises(ValueError, match="exceeds codomain size 3"):
            reverse(forward)

    def test_domain_codomain_swap(self):
        domain = np.array([100, 101])
        codomain = np.array([0, 1, 2])
        forward = MultiValuedArray(
            counts=np.array([2, 1]), values=np.array([0, 1, 2]), domain=domain, codomain=codomain
        )
        backward = reverse(forward)
        assert np.array_equal(backward.domain(), codomain)
        assert np.array_equal(backward.codomain(), domain)

    def test_no_values_raises(self):
        forward = MultiValuedArray(counts=np.array([2, 1]))
        with pytest.raises(ValueError, match="values array is not set"):
            reverse(forward)

    def test_empty_values(self):
        forward = MultiValuedArray(
            counts=np.array([], dtype=np.int32), values=np.array([], dtype=np.int32)
        )
        backward = reverse(forward)
        assert backward.counts().shape[0] == 0

    def test_structured_dtype_domain_codomain(self):
        face_dt = np.dtype([("id", "u4"), ("type", "u4")])
        vert_dt = np.dtype([("id", "u4"), ("x", "f4")])
        domain = np.array([(1, 1), (2, 2)], dtype=face_dt)
        codomain = np.array([(1, 0.0), (2, 1.0), (3, 2.0)], dtype=vert_dt)
        forward = MultiValuedArray(
            counts=np.array([2, 1]),
            values=np.array([0, 1, 2]),
            domain=domain,
            codomain=codomain,
        )
        backward = reverse(forward)
        # Domain and codomain should swap
        assert np.array_equal(backward.domain(), codomain)
        assert np.array_equal(backward.codomain(), domain)


class TestFromJoint:
    def test_basic(self):
        joint = np.array([2, 10, 20, 1, 30, 3, 40, 50, 60])
        mva = from_joint_counts_and_values_array(joint)
        assert np.array_equal(mva.counts(), [2, 1, 3])
        assert np.array_equal(mva.values(), [10, 20, 30, 40, 50, 60])

    def test_empty(self):
        mva = from_joint_counts_and_values_array(np.array([], dtype=np.int32))
        assert mva.counts().shape[0] == 0

    def test_none(self):
        assert from_joint_counts_and_values_array(None) is None

    def test_with_domain_codomain(self):
        mva = from_joint_counts_and_values_array(
            np.array([2, 10, 20, 1, 30]),
            domain=np.array([100, 101]),
            codomain=np.array([10, 20, 30]),
        )
        assert np.array_equal(mva.domain(), [100, 101])


class TestNonNegativeArray:
    def test_basic(self):
        src = np.array([[1, -1, 2], [3, 4, -5], [-1, -1, 5]])
        result = non_negative_array(src)
        assert np.array_equal(result.counts(), [2, 2, 1])
        assert np.array_equal(result.values(), [1, 2, 3, 4, 5])

    def test_all_positive(self):
        result = non_negative_array(np.array([[1, 2], [3, 4]]))
        assert np.array_equal(result.counts(), [2, 2])

    def test_all_negative(self):
        result = non_negative_array(np.array([[-1, -2], [-3, -4]]))
        assert np.array_equal(result.counts(), [0, 0])

    def test_includes_zero(self):
        result = non_negative_array(np.array([[0, -1], [0, 0]]))
        assert np.array_equal(result.counts(), [1, 2])


class TestSortAndUnique:
    def test_basic(self):
        dup = MultiValuedArray(counts=np.array([4, 2, 1]), values=np.array([3, 1, 3, 2, 5, 5, 7]))
        result = sort_and_unique(dup)
        assert np.array_equal(result.counts(), [3, 1, 1])
        assert np.array_equal(result.values(), [1, 2, 3, 5, 7])

    def test_no_duplicates(self):
        dup = MultiValuedArray(counts=np.array([3, 2]), values=np.array([1, 2, 3, 4, 5]))
        result = sort_and_unique(dup)
        assert np.array_equal(result.counts(), [3, 2])

    def test_all_duplicates(self):
        dup = MultiValuedArray(counts=np.array([5, 3]), values=np.array([1, 1, 1, 1, 1, 2, 2, 2]))
        result = sort_and_unique(dup)
        assert np.array_equal(result.counts(), [1, 1])

    def test_preserves_domain_codomain(self):
        dup = MultiValuedArray(
            counts=np.array([2]),
            values=np.array([3, 1]),
            domain=np.array([100]),
            codomain=np.array([1, 3]),
        )
        result = sort_and_unique(dup)
        assert np.array_equal(result.domain(), [100])

    def test_no_values_raises(self):
        dup = MultiValuedArray(counts=np.array([2, 1]))
        with pytest.raises(ValueError, match="values array is not set"):
            sort_and_unique(dup)

    def test_with_zero_count_elements(self):
        dup = MultiValuedArray(counts=np.array([3, 0, 2]), values=np.array([2, 1, 2, 5, 5]))
        result = sort_and_unique(dup)
        assert np.array_equal(result.counts(), [2, 0, 1])
        assert np.array_equal(result.values(), [1, 2, 5])


class TestCascade:
    def test_basic(self):
        ab = MultiValuedArray(counts=np.array([2, 1]), values=np.array([1, 2, 2]))
        bc = MultiValuedArray(counts=np.array([1, 1, 2]), values=np.array([10, 20, 30, 40]))
        ac = cascade(ab, bc)
        assert np.array_equal(ac.counts(), [3, 2])
        assert np.array_equal(ac.values(), [20, 30, 40, 30, 40])

    def test_with_unique(self):
        ab = MultiValuedArray(counts=np.array([2, 1]), values=np.array([1, 1, 2]))
        bc = MultiValuedArray(counts=np.array([1, 1, 1]), values=np.array([10, 20, 30]))
        ac = cascade(ab, bc, unique=True)
        assert np.array_equal(ac.counts(), [1, 1])

    def test_domain_mismatch_raises(self):
        ab = MultiValuedArray(counts=np.array([1]), values=np.array([0]), codomain=np.array([0]))
        bc = MultiValuedArray(counts=np.array([1]), values=np.array([0]), domain=np.array([1]))
        with pytest.raises(ValueError, match="Codomain of ab .* does not match"):
            cascade(ab, bc)

    def test_preserves_domain_codomain(self):
        domain_a = np.array([100, 101])
        codomain_c = np.array([10, 20, 30])
        ab = MultiValuedArray(counts=np.array([1, 1]), values=np.array([0, 1]), domain=domain_a)
        bc = MultiValuedArray(
            counts=np.array([1, 1]), values=np.array([0, 1]), codomain=codomain_c
        )
        ac = cascade(ab, bc)
        assert np.array_equal(ac.domain(), domain_a)
        assert np.array_equal(ac.codomain(), codomain_c)

    def test_verify_success(self):
        ab = MultiValuedArray(counts=np.array([2, 1]), values=np.array([0, 1, 1]))
        bc = MultiValuedArray(counts=np.array([1, 1]), values=np.array([10, 20]))
        ac = cascade(ab, bc, verify=True)
        assert np.array_equal(ac.counts(), [2, 1])

    def test_out_of_bounds_raises(self):
        ab = MultiValuedArray(counts=np.array([1]), values=np.array([5]))
        bc = MultiValuedArray(counts=np.array([1, 1]), values=np.array([10, 20]))
        with pytest.raises(ValueError, match="exceeds bc domain size"):
            cascade(ab, bc)

    def test_negative_values_raises(self):
        ab = MultiValuedArray(counts=np.array([1]), values=np.array([-1]))
        bc = MultiValuedArray(counts=np.array([1]), values=np.array([10]))
        with pytest.raises(ValueError, match="negative value"):
            cascade(ab, bc)

    def test_no_values_raises(self):
        ab = MultiValuedArray(counts=np.array([1]))
        bc = MultiValuedArray(counts=np.array([1]), values=np.array([0]))
        with pytest.raises(ValueError, match="ab has no values"):
            cascade(ab, bc)


class TestConcatenate:
    def test_basic(self):
        a = MultiValuedArray(counts=np.array([2, 1]), values=np.array([1, 2, 3]))
        b = MultiValuedArray(counts=np.array([1, 2]), values=np.array([4, 5, 6]))
        result = concatenate(a, b)
        assert np.array_equal(result.counts(), [2, 1, 1, 2])
        assert np.array_equal(result.values(), [1, 2, 3, 4, 5, 6])

    def test_codomain_mismatch_raises(self):
        a = MultiValuedArray(counts=np.array([1]), values=np.array([0]), codomain=np.array([0]))
        b = MultiValuedArray(counts=np.array([1]), values=np.array([0]), codomain=np.array([1]))
        with pytest.raises(ValueError, match="Codomains do not match:"):
            concatenate(a, b)

    def test_empty_arrays(self):
        a = MultiValuedArray(
            counts=np.array([], dtype=np.int32), values=np.array([], dtype=np.int32)
        )
        b = MultiValuedArray(
            counts=np.array([], dtype=np.int32), values=np.array([], dtype=np.int32)
        )
        result = concatenate(a, b)
        assert result.counts().shape[0] == 0

    def test_merges_domains(self):
        a = MultiValuedArray(
            counts=np.array([2, 1]), values=np.array([1, 2, 3]), domain=np.array([100, 101])
        )
        b = MultiValuedArray(counts=np.array([1]), values=np.array([4]), domain=np.array([102]))
        result = concatenate(a, b)
        assert np.array_equal(result.domain(), [100, 101, 102])

    def test_preserves_codomain_from_either(self):
        codomain = np.array([1, 2, 3, 4])
        a = MultiValuedArray(counts=np.array([2]), values=np.array([1, 2]))
        b = MultiValuedArray(counts=np.array([1]), values=np.array([3]), codomain=codomain)
        result = concatenate(a, b)
        assert np.array_equal(result.codomain(), codomain)

    def test_one_sided_domain_dropped(self):
        """When only one side has a domain, it's dropped (dimension mismatch)."""
        a = MultiValuedArray(counts=np.array([2]), values=np.array([1, 2]), domain=np.array([100]))
        b = MultiValuedArray(counts=np.array([1]), values=np.array([3]))
        result = concatenate(a, b)
        assert result.domain() is None
        assert np.array_equal(result.counts(), [2, 1])

    def test_structured_dtype_domains_merged(self):
        dt = np.dtype([("id", "u4"), ("type", "u4")])
        a = MultiValuedArray(
            counts=np.array([2]),
            values=np.array([1, 2]),
            domain=np.array([(1, 1)], dtype=dt),
        )
        b = MultiValuedArray(
            counts=np.array([1]),
            values=np.array([3]),
            domain=np.array([(2, 2)], dtype=dt),
        )
        result = concatenate(a, b)
        assert result.domain().shape[0] == 2
        assert result.domain()["id"][0] == 1
        assert result.domain()["id"][1] == 2

    def test_no_values_raises(self):
        a = MultiValuedArray(counts=np.array([1]))
        b = MultiValuedArray(counts=np.array([1]), values=np.array([0]))
        with pytest.raises(ValueError, match="first array has no values"):
            concatenate(a, b)


class TestGetCountsValuesArray:
    def test_basic(self):
        mva = MultiValuedArray(
            counts=np.array([2, 1, 3]), values=np.array([10, 20, 30, 40, 50, 60])
        )
        result = get_counts_values_array(mva)
        expected = np.array([2, 10, 20, 1, 30, 3, 40, 50, 60])
        assert np.array_equal(result, expected)

    def test_roundtrip(self):
        original = np.array([2, 10, 20, 1, 30, 3, 40, 50, 60])
        mva = from_joint_counts_and_values_array(original)
        result = get_counts_values_array(mva)
        assert np.array_equal(result, original)

    def test_preserves_dtype(self):
        mva = MultiValuedArray(
            counts=np.array([2, 1], dtype=np.int64),
            values=np.array([10, 20, 30], dtype=np.int64),
        )
        result = get_counts_values_array(mva)
        assert result.dtype == np.int64

    def test_empty(self):
        mva = MultiValuedArray(
            counts=np.array([], dtype=np.int32), values=np.array([], dtype=np.int32)
        )
        result = get_counts_values_array(mva)
        assert result.shape[0] == 0

    def test_no_values_raises(self):
        mva = MultiValuedArray(counts=np.array([2, 1]))
        with pytest.raises(ValueError, match="values not set"):
            get_counts_values_array(mva)


class TestGetChunk:
    def test_basic(self):
        mva = MultiValuedArray(counts=np.array([2, 1, 2, 1]), values=np.array([1, 2, 3, 4, 5, 6]))
        chunk = get_chunk(mva, 1, 3)
        assert np.array_equal(chunk.counts(), [1, 2])
        assert np.array_equal(chunk.values(), [3, 4, 5])

    def test_with_domain(self):
        mva = MultiValuedArray(
            counts=np.array([2, 1, 2]),
            values=np.array([1, 2, 3, 4, 5]),
            domain=np.array([100, 101, 102]),
        )
        chunk = get_chunk(mva, 1, 3)
        assert np.array_equal(chunk.domain(), [101, 102])

    def test_preserves_codomain(self):
        codomain = np.array([1, 2, 3, 4, 5])
        mva = MultiValuedArray(
            counts=np.array([2, 1]), values=np.array([1, 2, 3]), codomain=codomain
        )
        chunk = get_chunk(mva, 0, 1)
        assert np.array_equal(chunk.codomain(), codomain)

    def test_empty_chunk(self):
        mva = MultiValuedArray(counts=np.array([2, 1, 3]), values=np.array([1, 2, 3, 4, 5, 6]))
        chunk = get_chunk(mva, 1, 1)
        assert len(chunk) == 0

    def test_full_range(self):
        mva = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 30]))
        chunk = get_chunk(mva, 0, 2)
        assert chunk == mva

    def test_single_element(self):
        mva = MultiValuedArray(counts=np.array([2, 3, 1]), values=np.array([1, 2, 3, 4, 5, 6]))
        chunk = get_chunk(mva, 1, 2)
        assert np.array_equal(chunk.counts(), [3])
        assert np.array_equal(chunk.values(), [3, 4, 5])

    def test_no_values(self):
        mva = MultiValuedArray(counts=np.array([2, 1, 3]))
        chunk = get_chunk(mva, 0, 2)
        assert chunk.values() is None
        assert np.array_equal(chunk.counts(), [2, 1])
