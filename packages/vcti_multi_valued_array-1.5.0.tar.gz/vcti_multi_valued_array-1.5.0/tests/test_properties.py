# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Property-based tests using Hypothesis."""

import numpy as np
from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st
from hypothesis.extra.numpy import arrays

from vcti.multivalued import (
    MultiValuedArray,
    concatenate,
    from_joint_counts_and_values_array,
    get_chunk,
    get_counts_values_array,
    reverse,
    sort_and_unique,
)

# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------


def mva_strategy(
    max_elements: int = 20,
    max_count: int = 10,
    max_value: int = 50,
):
    """Generate a random MultiValuedArray with integer values."""

    @st.composite
    def _build(draw):
        n = draw(st.integers(min_value=0, max_value=max_elements))
        counts = draw(arrays(np.int32, shape=(n,), elements=st.integers(0, max_count)))
        total = int(np.sum(counts))
        values = draw(arrays(np.int32, shape=(total,), elements=st.integers(0, max_value)))
        return MultiValuedArray(counts=counts, values=values)

    return _build()


# ---------------------------------------------------------------------------
# Roundtrip properties
# ---------------------------------------------------------------------------


class TestRoundtrip:
    @given(mva=mva_strategy())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_joint_roundtrip(self, mva: MultiValuedArray):
        """from_joint(get_counts_values(mva)) reconstructs the original."""
        joint = get_counts_values_array(mva)
        rebuilt = from_joint_counts_and_values_array(joint)
        assert rebuilt is not None
        assert np.array_equal(rebuilt.counts(), mva.counts())
        assert np.array_equal(rebuilt.values(), mva.values())

    @given(mva=mva_strategy())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_chunk_full_range_equals_original(self, mva: MultiValuedArray):
        """get_chunk(mva, 0, len(mva)) == mva."""
        chunk = get_chunk(mva, 0, len(mva))
        assert chunk == mva


# ---------------------------------------------------------------------------
# Invariant properties
# ---------------------------------------------------------------------------


class TestInvariants:
    @given(mva=mva_strategy())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_offsets_len_is_counts_plus_one(self, mva: MultiValuedArray):
        offsets = mva.offsets()
        counts = mva.counts()
        assert offsets is not None and counts is not None
        assert len(offsets) == len(counts) + 1

    @given(mva=mva_strategy())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_offsets_last_equals_values_len(self, mva: MultiValuedArray):
        offsets = mva.offsets()
        values = mva.values()
        assert offsets is not None and values is not None
        assert offsets[-1] == len(values)

    @given(mva=mva_strategy())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_value_indices_shape_matches_values(self, mva: MultiValuedArray):
        vi = mva.value_indices()
        values = mva.values()
        assert values is not None and vi is not None
        assert vi.shape == values.shape

    @given(mva=mva_strategy())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_value_indices_in_range(self, mva: MultiValuedArray):
        vi = mva.value_indices()
        if vi is not None and len(vi) > 0:
            assert np.all(vi >= 0)
            assert np.all(vi < len(mva))

    @given(mva=mva_strategy())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_len_matches_counts(self, mva: MultiValuedArray):
        counts = mva.counts()
        assert counts is not None
        assert len(mva) == len(counts)

    @given(mva=mva_strategy())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_iter_length(self, mva: MultiValuedArray):
        elements = list(mva)
        assert len(elements) == len(mva)

    @given(mva=mva_strategy())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_getitem_consistent_with_iter(self, mva: MultiValuedArray):
        for i, elem in enumerate(mva):
            assert np.array_equal(mva[i], elem)

    @given(mva=mva_strategy())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_equality_is_reflexive(self, mva: MultiValuedArray):
        assert mva == mva


# ---------------------------------------------------------------------------
# Operation properties
# ---------------------------------------------------------------------------


class TestOperationProperties:
    @given(mva=mva_strategy(max_value=15))
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_reverse_preserves_total_values(self, mva: MultiValuedArray):
        """Reversing preserves the total number of values."""
        values = mva.values()
        assert values is not None
        if not np.issubdtype(values.dtype, np.integer):
            return
        backward = reverse(mva)
        bwd_values = backward.values()
        assert bwd_values is not None
        assert len(values) == len(bwd_values)

    @given(mva=mva_strategy(max_value=15))
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_reverse_reverse_roundtrip_counts(self, mva: MultiValuedArray):
        """reverse(reverse(mva)) has same total element count."""
        values = mva.values()
        assert values is not None
        if not np.issubdtype(values.dtype, np.integer) or len(values) == 0:
            return
        backward = reverse(mva)
        forward_again = reverse(backward)
        # Element counts should match original
        assert int(np.sum(forward_again.counts())) == int(np.sum(mva.counts()))

    @given(mva=mva_strategy())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_sort_and_unique_idempotent(self, mva: MultiValuedArray):
        """Applying sort_and_unique twice gives the same result."""
        first = sort_and_unique(mva)
        # Need fresh copy since sort_and_unique is destructive
        first_copy = MultiValuedArray(counts=first.counts().copy(), values=first.values().copy())
        second = sort_and_unique(first_copy)
        assert first == second

    @given(mva=mva_strategy())
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_sort_and_unique_reduces_or_preserves_count(self, mva: MultiValuedArray):
        """sort_and_unique never increases per-element count."""
        result = sort_and_unique(mva)
        orig_counts = mva.counts()
        result_counts = result.counts()
        assert orig_counts is not None and result_counts is not None
        assert np.all(result_counts <= orig_counts)

    @given(
        mva_a=mva_strategy(max_elements=10),
        mva_b=mva_strategy(max_elements=10),
    )
    @settings(max_examples=50, suppress_health_check=[HealthCheck.too_slow], deadline=None)
    def test_concatenate_preserves_total(self, mva_a, mva_b):
        """Concatenation preserves total element and value counts."""
        result = concatenate(mva_a, mva_b)
        assert len(result) == len(mva_a) + len(mva_b)
        vals_a = mva_a.values()
        vals_b = mva_b.values()
        vals_r = result.values()
        assert vals_a is not None and vals_b is not None and vals_r is not None
        assert len(vals_r) == len(vals_a) + len(vals_b)
