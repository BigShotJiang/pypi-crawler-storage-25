# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for multi_valued module."""

import numpy as np
import pytest

from vcti.multivalued import MultiValuedArray


class TestInitialization:
    def test_with_counts(self):
        mva = MultiValuedArray(counts=np.array([2, 1, 3]))
        assert np.array_equal(mva.counts(), [2, 1, 3])
        assert mva.offsets() is not None

    def test_with_offsets(self):
        mva = MultiValuedArray(offsets=np.array([0, 2, 3, 6]))
        assert np.array_equal(mva.counts(), [2, 1, 3])

    def test_with_counts_and_values(self):
        mva = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 30]))
        assert np.array_equal(mva.values(), [10, 20, 30])

    def test_with_lists(self):
        mva = MultiValuedArray(counts=[2, 1], values=[10, 20, 30])
        assert np.array_equal(mva.counts(), [2, 1])

    def test_with_domain_codomain(self):
        mva = MultiValuedArray(
            counts=np.array([2, 1]),
            domain=np.array([100, 101]),
            codomain=np.array([0, 1, 2]),
        )
        assert np.array_equal(mva.domain(), [100, 101])
        assert np.array_equal(mva.codomain(), [0, 1, 2])

    def test_neither_raises(self):
        with pytest.raises(ValueError, match="Neither"):
            MultiValuedArray()

    def test_both_raises(self):
        with pytest.raises(ValueError, match="Both"):
            MultiValuedArray(counts=np.array([2]), offsets=np.array([0, 2]))

    def test_both_prechecked(self):
        mva = MultiValuedArray(
            counts=np.array([2, 1]),
            offsets=np.array([0, 2, 3]),
            counts_offsets_prechecked=True,
        )
        assert np.array_equal(mva.counts(), [2, 1])

    def test_domain_counts_mismatch(self):
        with pytest.raises(ValueError, match="Domain length 3 does not match counts length 2"):
            MultiValuedArray(counts=np.array([2, 1]), domain=np.array([1, 2, 3]))

    def test_domain_offsets_mismatch(self):
        with pytest.raises(ValueError, match="Domain length 1 does not match"):
            MultiValuedArray(offsets=np.array([0, 2, 3]), domain=np.array([1]))


class TestLazyComputation:
    def test_offsets_from_counts(self):
        mva = MultiValuedArray(counts=np.array([2, 1, 3]))
        assert np.array_equal(mva.offsets(), [0, 2, 3, 6])

    def test_counts_from_offsets(self):
        mva = MultiValuedArray(offsets=np.array([0, 2, 3, 6]))
        assert np.array_equal(mva.counts(), [2, 1, 3])

    def test_offsets_cached(self):
        mva = MultiValuedArray(counts=np.array([2, 1]))
        o1 = mva.offsets()
        o2 = mva.offsets()
        assert o1 is o2


class TestSetValues:
    def test_valid(self):
        mva = MultiValuedArray(counts=np.array([2, 1]))
        mva.set_values(np.array([10, 20, 30]))
        assert np.array_equal(mva.values(), [10, 20, 30])

    def test_invalid_size(self):
        mva = MultiValuedArray(counts=np.array([2, 1]))
        with pytest.raises(ValueError, match="Values array size 2 does not match expected size 3"):
            mva.set_values(np.array([10, 20]))

    def test_invalidates_cache(self):
        mva = MultiValuedArray(counts=np.array([2, 1]), values=np.array([1, 2, 3]))
        vi1 = mva.value_indices()
        mva.set_values(np.array([4, 5, 6]))
        vi2 = mva.value_indices()
        assert vi2 is not vi1

    def test_none_clears(self):
        mva = MultiValuedArray(counts=np.array([2]), values=np.array([1, 2]))
        mva.set_values(None)
        assert mva.values() is None

    def test_from_offsets_only(self):
        mva = MultiValuedArray(offsets=np.array([0, 2, 3]))
        mva.set_values(np.array([10, 20, 30]))
        assert np.array_equal(mva.values(), [10, 20, 30])


class TestValueIndices:
    def test_basic(self):
        mva = MultiValuedArray(
            counts=np.array([2, 1, 3]), values=np.array([10, 20, 30, 40, 50, 60])
        )
        expected = np.array([0, 0, 1, 2, 2, 2], dtype=np.uint32)
        assert np.array_equal(mva.value_indices(), expected)

    def test_none_without_values(self):
        mva = MultiValuedArray(counts=np.array([2, 1]))
        assert mva.value_indices() is None

    def test_with_zero_counts(self):
        mva = MultiValuedArray(
            counts=np.array([2, 0, 1, 0, 3]), values=np.array([10, 20, 30, 40, 50, 60])
        )
        expected = np.array([0, 0, 2, 4, 4, 4], dtype=np.uint32)
        assert np.array_equal(mva.value_indices(), expected)

    def test_cached_after_recompute(self):
        mva = MultiValuedArray(counts=np.array([2, 1]), values=np.array([1, 2, 3]))
        vi1 = mva.value_indices()
        vi2 = mva.value_indices()
        assert vi1 is vi2


class TestLen:
    def test_from_counts(self):
        mva = MultiValuedArray(counts=np.array([2, 1, 3]))
        assert len(mva) == 3

    def test_from_offsets(self):
        mva = MultiValuedArray(offsets=np.array([0, 2, 3, 6]))
        assert len(mva) == 3

    def test_empty(self):
        mva = MultiValuedArray(counts=np.array([], dtype=np.int32))
        assert len(mva) == 0


class TestGetItem:
    def test_basic(self):
        mva = MultiValuedArray(
            counts=np.array([2, 1, 3]), values=np.array([10, 20, 30, 40, 50, 60])
        )
        assert np.array_equal(mva[0], [10, 20])
        assert np.array_equal(mva[1], [30])
        assert np.array_equal(mva[2], [40, 50, 60])

    def test_negative_index(self):
        mva = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 30]))
        assert np.array_equal(mva[-1], [30])
        assert np.array_equal(mva[-2], [10, 20])

    def test_out_of_range(self):
        mva = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 30]))
        with pytest.raises(IndexError):
            mva[2]
        with pytest.raises(IndexError):
            mva[-3]

    def test_no_values(self):
        mva = MultiValuedArray(counts=np.array([2, 1]))
        assert mva[0] is None

    def test_zero_count_element(self):
        mva = MultiValuedArray(counts=np.array([2, 0, 1]), values=np.array([10, 20, 30]))
        assert np.array_equal(mva[1], [])


class TestEquality:
    def test_equal(self):
        a = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 30]))
        b = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 30]))
        assert a == b

    def test_not_equal_values(self):
        a = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 30]))
        b = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 99]))
        assert a != b

    def test_not_equal_counts(self):
        a = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 30]))
        b = MultiValuedArray(counts=np.array([1, 2]), values=np.array([10, 20, 30]))
        assert a != b

    def test_with_domain_codomain(self):
        a = MultiValuedArray(
            counts=np.array([2]),
            values=np.array([1, 2]),
            domain=np.array([10]),
            codomain=np.array([1, 2]),
        )
        b = MultiValuedArray(
            counts=np.array([2]),
            values=np.array([1, 2]),
            domain=np.array([10]),
            codomain=np.array([1, 2]),
        )
        assert a == b

    def test_not_equal_domain(self):
        a = MultiValuedArray(counts=np.array([2]), values=np.array([1, 2]), domain=np.array([10]))
        b = MultiValuedArray(counts=np.array([2]), values=np.array([1, 2]), domain=np.array([20]))
        assert a != b

    def test_not_implemented_for_other_types(self):
        a = MultiValuedArray(counts=np.array([2]), values=np.array([1, 2]))
        assert a.__eq__("not an mva") is NotImplemented

    def test_none_values_equal(self):
        a = MultiValuedArray(counts=np.array([2, 1]))
        b = MultiValuedArray(counts=np.array([2, 1]))
        assert a == b


class TestStringRepresentations:
    def test_repr(self):
        mva = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 30]))
        r = repr(mva)
        assert "n=2" in r
        assert "nnz=3" in r
        assert "dtype=" in r

    def test_repr_no_values(self):
        mva = MultiValuedArray(counts=np.array([2, 1]))
        r = repr(mva)
        assert "n=2" in r
        assert "nnz=0" in r
        assert "dtype=" not in r

    def test_str(self):
        mva = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 30]))
        s = str(mva)
        assert "counts:" in s
        assert "values:" in s

    def test_debug_info(self):
        mva = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 30]))
        d = mva.debug_info()
        assert "Counts:" in d
        assert "Offsets:" in d
        assert "Value Indices:" in d


class TestToNdarray:
    def test_invalid_type_raises(self):
        from vcti.multivalued.multi_valued import _to_ndarray

        with pytest.raises(TypeError, match="Expected ndarray"):
            _to_ndarray("invalid")

    def test_tuple_accepted(self):
        mva = MultiValuedArray(counts=(2, 1), values=(10, 20, 30))
        assert np.array_equal(mva.counts(), [2, 1])
        assert np.array_equal(mva.values(), [10, 20, 30])


class TestOffsetsOnlyPaths:
    def test_repr_offsets_only(self):
        mva = MultiValuedArray(offsets=np.array([0, 2, 3]))
        r = repr(mva)
        assert "n=2" in r

    def test_str_not_computed(self):
        mva = MultiValuedArray(offsets=np.array([0, 2, 3]))
        s = str(mva)
        assert "counts: not computed" in s

    def test_str_offsets_not_computed(self):
        mva = MultiValuedArray(counts=np.array([2, 1]))
        s = str(mva)
        assert "offsets: not computed" in s

    def test_str_values_none(self):
        mva = MultiValuedArray(counts=np.array([2, 1]))
        s = str(mva)
        assert "values: None" in s

    def test_str_with_domain_codomain(self):
        mva = MultiValuedArray(
            counts=np.array([2, 1]),
            values=np.array([1, 2, 3]),
            domain=np.array([10, 20]),
            codomain=np.array([1, 2, 3]),
        )
        s = str(mva)
        assert "domain:" in s
        assert "codomain:" in s

    def test_value_indices_from_offsets(self):
        mva = MultiValuedArray(offsets=np.array([0, 2, 3]))
        mva.set_values(np.array([10, 20, 30]))
        expected = np.array([0, 0, 1], dtype=np.uint32)
        assert np.array_equal(mva.value_indices(), expected)


class TestEdgeCases:
    def test_empty(self):
        mva = MultiValuedArray(
            counts=np.array([], dtype=np.int32), values=np.array([], dtype=np.int32)
        )
        assert mva.counts().shape[0] == 0

    def test_single_element(self):
        mva = MultiValuedArray(counts=np.array([3]), values=np.array([10, 20, 30]))
        assert np.array_equal(mva.value_indices(), [0, 0, 0])

    def test_all_zero_counts(self):
        mva = MultiValuedArray(counts=np.array([0, 0, 0]), values=np.array([], dtype=np.int32))
        assert mva.values().shape[0] == 0

    def test_large_counts(self):
        counts = np.array([100, 50, 200])
        values = np.arange(350)
        mva = MultiValuedArray(counts=counts, values=values)
        vi = mva.value_indices()
        assert np.all(vi[:100] == 0)
        assert np.all(vi[100:150] == 1)
        assert np.all(vi[150:350] == 2)


class TestIter:
    def test_basic(self):
        mva = MultiValuedArray(
            counts=np.array([2, 1, 3]), values=np.array([10, 20, 30, 40, 50, 60])
        )
        elements = list(mva)
        assert len(elements) == 3
        assert np.array_equal(elements[0], [10, 20])
        assert np.array_equal(elements[1], [30])
        assert np.array_equal(elements[2], [40, 50, 60])

    def test_empty(self):
        mva = MultiValuedArray(
            counts=np.array([], dtype=np.int32), values=np.array([], dtype=np.int32)
        )
        assert list(mva) == []

    def test_no_values(self):
        mva = MultiValuedArray(counts=np.array([2, 1]))
        elements = list(mva)
        assert len(elements) == 2
        assert elements[0] is None
        assert elements[1] is None

    def test_zero_count_elements(self):
        mva = MultiValuedArray(counts=np.array([2, 0, 1]), values=np.array([10, 20, 30]))
        elements = list(mva)
        assert len(elements) == 3
        assert np.array_equal(elements[0], [10, 20])
        assert np.array_equal(elements[1], [])
        assert np.array_equal(elements[2], [30])


class TestHash:
    def test_unhashable(self):
        mva = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 30]))
        with pytest.raises(TypeError):
            hash(mva)


class TestCopy:
    def test_shallow_copy(self):
        import copy

        mva = MultiValuedArray(counts=np.array([2, 1]), values=np.array([10, 20, 30]))
        shallow = copy.copy(mva)
        assert shallow == mva
        # Shallow copy shares arrays
        assert shallow.values() is mva.values()
        assert shallow.counts() is mva.counts()

    def test_deep_copy(self):
        import copy

        mva = MultiValuedArray(
            counts=np.array([2, 1]),
            values=np.array([10, 20, 30]),
            domain=np.array([100, 101]),
        )
        deep = copy.deepcopy(mva)
        assert deep == mva
        # Deep copy has independent arrays
        assert deep.values() is not mva.values()
        assert deep.counts() is not mva.counts()
        assert deep.domain() is not mva.domain()
        # Mutating deep copy doesn't affect original
        deep.values()[0] = 999
        assert mva.values()[0] == 10
