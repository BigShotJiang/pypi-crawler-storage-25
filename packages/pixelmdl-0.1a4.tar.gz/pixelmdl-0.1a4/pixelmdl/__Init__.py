import time
def hello():
    print("Hello World!")

def sprint():
    print("What should be printed")
    text = input()

    print("How many times would you like to repeat")
    amount = int(input())  

    for i in range(amount):
        time.sleep(0.05)
        print(text)