#!/usr/bin/env python
"""
Ejemplo completo de uso de pysage50e

Este script demuestra cómo usar la API de pysage50e para:
- Conectarse a una base de datos Sage50
- Ejecutar consultas SQL simples
- Usar query builder avanzado
- Manejar errores correctamente
- Usar diferentes métodos de transformación de datos

Autor: Pablo Malo
Email: pysage50e@pablomalo.es
Versión: 0.1.0
"""

import sys
import webbrowser
# Reconfigurar stdout para UTF-8 (necesario para emojis en Windows)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from pysage50e import (
    apiSAGE50,
    handle_error,
    log_debug,
    log_info,
    log_warning,
    Sage50AuthenticationError,
    Sage50ConfigurationError,
    Sage50ConnectionError,
    Sage50Error,
    Sage50QueryError,
    Sage50ValidationError,
)


def ejemplo_consulta_comunes():
    """Ejemplo 1: Conexión Comunes"""
    log_info("Ejemplo 1: Conexión Comunes", context="ejemplo_comunes")

    try:
        api = apiSAGE50()

        # Consultar artículos
        query=api.build_query("SELECT top 5 * FROM COMUNES!ejercici")
        ejercici = api.sql_to_list(query)

        print(f"📦 Encontrados {len(ejercici)} artículos")
        print("\n📋 Ejercicios:")
        for art in ejercici:
            print(f"  {art['ANY']} | {art['RUTA']}")

    except Sage50ConnectionError as e:
        log_error(f"Error de conexión: {e}", context="ejemplo_1")
        print(f"❌ No se pudo conectar: {e}")

    except Sage50Error as e:
        log_error(f"Error Sage50: {e}", context="ejemplo_1")
        print(f"❌ Error: {e}")



def ejemplo_conexion_simple():
    """Ejemplo 1: Conexión simple"""
    log_info("Ejemplo 1: Conexión simple", context="ejemplo_1")

    try:
        api = apiSAGE50()

        if api.lconecto:
            print(f"✅ Conectado a {api.NomEmpresa}")
            print(f"📅 Ejercicio actual: {api.year_activo[-1]}")
            print(f"📊 Comunes: {api.comunes}")
        else:
            print(f"❌ Error de conexión: {api.lasterror}")

    except Sage50ConnectionError as e:
        log_error(f"Error de conexión: {e}", context="ejemplo_1")
        print(f"❌ No se pudo conectar: {e}")

    except Sage50Error as e:
        log_error(f"Error Sage50: {e}", context="ejemplo_1")
        print(f"❌ Error: {e}")


def ejemplo_consulta_simple():
    """Ejemplo 2: Consulta SQL simple"""
    print("\n" + "=" * 60)
    log_info("Ejemplo 2: Consulta SQL simple", context="ejemplo_2")

    try:
        api = apiSAGE50()

        if not api.lconecto:
            log_error("No conectado", context="ejemplo_2")
            return

        # Consultar artículos
        query=api.build_query("SELECT top 5 * FROM #articulo")
        articulos = api.sql_to_list(query)

        print(f"📦 Encontrados {len(articulos)} artículos")
        print("\n📋 Artículos:")
        for art in articulos:
            print(f"  {art['CODIGO']:10s} | {art['NOMBRE'][:40]}")

    except Sage50QueryError as e:
        log_error(f"Error en query: {e}", context="ejemplo_2")
        print(f"❌ Error en consulta: {e}")

    except Sage50Error as e:
        log_error(f"Error Sage50: {e}", context="ejemplo_2")
        print(f"❌ Error: {e}")


def ejemplo_consulta_con_filtro():
    """Ejemplo 3: Consulta con filtro"""
    print("\n" + "=" * 60)
    log_info("Ejemplo 3: Consulta con filtro", context="ejemplo_3")

    try:
        api = apiSAGE50()

        if not api.lconecto:
            log_error("No conectado", context="ejemplo_3")
            return

        # Consultar cliente específico
        codcli='43000000'
        query=api.build_query(f"SELECT * FROM #clientes WHERE CODIGO = {codcli}")
        cliente = api.sql_to_dict(query)

        if cliente:
            cli = cliente[codcli]
            print("👤 Cliente encontrado:")
            print(f"   Código: {cli['CODIGO']}")
            print(f"   Nombre: {cli['NOMBRE']}")
            print(f"   Dirección: {cli['DIRECCION']}")
            print(f"   CP:  {cli['CODPOST']}")
        else:
            print("❌ Cliente no encontrado")

    except Sage50Error as e:
        log_error(f"Error: {e}", context="ejemplo_3")
        print(f"❌ Error: {e}")


def ejemplo_consulta_lista():
    """Ejemplo 4: Consulta como lista"""
    print("\n" + "=" * 60)
    log_info("Ejemplo 4: Consulta como lista", context="ejemplo_4")

    try:
        api = apiSAGE50()

        if not api.lconecto:
            log_error("No conectado", context="ejemplo_4")
            return

        # Obtener solo IDs de albaranes
        query=api.build_query("SELECT NUMERO FROM #c_albven")
        ids = api.sql_to_list(query)

        print(f"📋 {len(ids)} albaranes:")
        print(f"IDs: {ids}")

    except Sage50Error as e:
        log_error(f"Error: {e}", context="ejemplo_4")
        print(f"❌ Error: {e}")


def ejemplo_consulta_namespace():
    """Ejemplo 5: Consulta como namespace"""
    print("\n" + "=" * 60)
    log_info("Ejemplo 5: Consulta como namespace", context="ejemplo_5")

    try:
        api = apiSAGE50()

        if not api.lconecto:
            log_error("No conectado", context="ejemplo_5")
            return

        # Consultar un producto
        query=api.build_query("SELECT TOP 1 CODIGO,NOMBRE FROM #articulo ")
        producto = api.sql_to_namespace(query)

        if producto:
            print("📦 Producto:")
            print(f"   Código: {producto.CODIGO}")
            print(f"   Nombre: {producto.NOMBRE}")
        else:
            print("❌ Producto no encontrado")

    except Sage50Error as e:
        log_error(f"Error: {e}", context="ejemplo_5")
        print(f"❌ Error: {e}")




def ejemplo_especificacion_anios():
    """Ejemplo 7: Especificación de años (+, -, list)"""
    print("\n" + "=" * 60)
    log_info("Ejemplo 7: Especificación de años", context="ejemplo_7")

    try:
        api = apiSAGE50()

        if not api.lconecto:
            log_error("No conectado", context="ejemplo_7")
            return

        # Ejercicios >= 2023
        print("📊 Ejercicios >= 2023:")
        aprocesar=api.SAGE50year("+2023")
        print("Años Proceso:",aprocesar)
        if len(aprocesar)>0:
            query=api.build_query("SELECT TOP 1 CODIGO,NOMBRE FROM #articulo ",years=aprocesar)
            datos = api.sql_to_list(query)
            for d in datos:
                print(f"  {d['CODIGO']} | {d['NOMBRE']}")

        # Ejercicios <= 2022
        print("\n📋 Ejercicios <= 2022:")
        aprocesar=api.SAGE50year("-2022")
        print("Años Proceso:",aprocesar)
        if len(aprocesar)>0:
            query=api.build_query("SELECT TOP 1 CODIGO,NOMBRE FROM #articulo ",years=aprocesar)
            datos = api.sql_to_list(query)
            for d in datos:
                print(f"  {d['CODIGO']} | {d['NOMBRE']}")

        # Lista de años específicos [2020, 2021, 2022]
        print("\n📅 Ejercicios [2020, 2021, 2022]:")
        aprocesar=api.SAGE50year(["2020",2021, "2022"])
        print("Años Proceso:",aprocesar)
        if len(aprocesar)>0:
            query=api.build_query("SELECT TOP 1 CODIGO,NOMBRE FROM #articulo ",years=aprocesar)
            datos = api.sql_to_list(query)
            for d in datos:
                print(f"  {d['CODIGO']} | {d['NOMBRE']}")

    except Sage50Error as e:
        log_error(f"Error: {e}", context="ejemplo_7")
        print(f"❌ Error: {e}")


def ejemplo_manejo_errores():
    """Ejemplo 8: Manejo completo de errores"""
    print("\n" + "=" * 60)
    log_info("Ejemplo 8: Manejo de errores", context="ejemplo_8")

    try:
        api = apiSAGE50()

        if not api.lconecto:
            log_error("No conectado", context="ejemplo_8")
            return

        # Intentar consulta a tabla inexistente
        print("🔍 Intentando consulta a tabla inexistente...")
        resultados = api.sql_to_dict("SELECT * FROM #tabla_inexistente")

    except Sage50ConnectionError as e:
        log_error(f"Error de conexión: {e}", context="ejemplo_8")
        print(f"❌ Error de conexión: {e}")
        print("💡 Verifica tu configuración de SQL Server")

    except Sage50QueryError as e:
        log_error(f"Error en query: {e}", context="ejemplo_8")
        print(f"❌ Error en consulta SQL: {e}")

    except Sage50ValidationError as e:
        log_error(f"Error de validación: {e}", context="ejemplo_8")
        print(f"❌ Error en los datos: {e}")

    except Sage50AuthenticationError as e:
        log_error(f"Error de autenticación: {e}", context="ejemplo_8")
        print(f"❌ Error de autenticación: {e}")
        print("💡 Verifica usuario y contraseña")

    except Sage50Error as e:
        log_error(f"Error Sage50: {e}", context="ejemplo_8")
        print(f"❌ Error genérico: {e}")


def ejemplo_recargar_conexion():
    """Ejemplo 9: Recargar conexión"""
    print("\n" + "=" * 60)
    log_info("Ejemplo 9: Recargar conexión", context="ejemplo_9")

    try:
        api = apiSAGE50()

        if not api.lconecto:
            log_error("No conectado", context="ejemplo_9")
            return

        print(f"Ejercicio actual: {api.year_activo[-1]}")

        # Recargar para cambiar de ejercicio
        print("🔄 Recargando conexión...")
        api.recargar(comunes="COMU0001", empresa="02")

        print(f"Nuevo ejercicio: {api.year_activo[-1]}")
        print(f"Empresa: {api.codigo_empresa}")
        print(f"Comunes: {api.comunes}")

    except Sage50Error as e:
        log_error(f"Error: {e}", context="ejemplo_9")
        print(f"❌ Error: {e}")


def ejemplo_debug():
    """Ejemplo 10: Debug y logging"""
    print("\n" + "=" * 60)
    log_info("Ejemplo 10: Debug y logging", context="ejemplo_10")

    try:
        api = apiSAGE50()

        if not api.lconecto:
            log_error("No conectado", context="ejemplo_10")
            return

        # Usar logs con contexto
        log_debug("Este es un mensaje de debug", context="ejemplo_10")
        log_info("Información importante", context="ejemplo_10")
        log_warning("Advertencia", context="ejemplo_10")


    except Sage50Error as e:
        log_error(f"Error: {e}", context="ejemplo_10")
        print(f"❌ Error: {e}")


def main():
    """Función principal - Ejecuta todos los ejemplos"""
    print("=" * 60)
    print("🐍 Ejemplos de Uso de pysage50e")
    print("=" * 60)
    print("Autor: Pablo Malo")
    print("Email: pysage50e@pablomalo.es")
    print("Versión: 0.1.0")
    print("=" * 60)

    # Ejecutar ejemplos
    ejemplo_conexion_simple()
    ejemplo_consulta_simple()
    ejemplo_consulta_con_filtro()
    ejemplo_consulta_lista()
    ejemplo_consulta_namespace()
    ejemplo_consulta_comunes()



    ejemplo_especificacion_anios()
    ejemplo_manejo_errores()
    ejemplo_recargar_conexion()
    ejemplo_debug()

    print("\n" + "=" * 60)
    print("✅ Todos los ejemplos completados")
    print("=" * 60)
    print("\n💡 Para más información, consulta:")
    print("   - README.md (documentación completa)")
    print("   - Documentación en: https://pablomalo.es/pysage50e")
    print("   - Soporte: pysage50e@pablomalo.es")
    webbrowser.open("https://pablomalo.es/pysage50e")


def log_error(message: str, context: str = "general"):
    """
    Wrapper simple para log_error usando el logger directamente.
    Mantiene compatibilidad con el código existente.
    """
    import logging

    logger = logging.getLogger("sage50")
    logger.error(f"[{context}] {message}")
    print(f"ERROR [{context}] {message}", file=__import__("sys").stderr)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️ Proceso interrumpido por el usuario")
    except Exception as e:
        print(f"\n\n❌ Error inesperado: {e}")
