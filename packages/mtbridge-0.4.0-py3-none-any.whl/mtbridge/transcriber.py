"""Voice message transcription using faster-whisper.

Loads the model once at startup and transcribes audio files on demand.
Runs on CPU with int8 quantization for reasonable speed without GPU.
"""

import asyncio
import logging
import time
from functools import partial

logger = logging.getLogger(__name__)

# Model is loaded lazily on first use
_model = None
_model_name = "medium"


def _get_model():
    """Get or lazily load the Whisper model."""
    global _model
    if _model is None:
        from faster_whisper import WhisperModel
        logger.info("Loading Whisper model '%s' (CPU, int8)...", _model_name)
        start = time.time()
        _model = WhisperModel(_model_name, device="cpu", compute_type="int8")
        logger.info("Whisper model loaded in %.1fs", time.time() - start)
    return _model


def _transcribe_sync(audio_path: str) -> str:
    """Synchronous transcription (runs in thread pool)."""
    model = _get_model()
    start = time.time()

    segments, info = model.transcribe(
        audio_path,
        beam_size=5,
        language=None,  # auto-detect
        vad_filter=True,  # skip silence
    )

    # Collect all segments
    text_parts = []
    for segment in segments:
        text_parts.append(segment.text.strip())

    full_text = " ".join(text_parts)
    duration = time.time() - start

    logger.info(
        "Transcribed %.1fs audio in %.1fs (lang=%s, prob=%.2f): %.80s...",
        info.duration, duration,
        info.language, info.language_probability,
        full_text,
    )

    return full_text


async def transcribe(audio_path: str) -> str:
    """Transcribe an audio file asynchronously.

    Runs the CPU-intensive transcription in a thread pool
    to avoid blocking the asyncio event loop.
    """
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, partial(_transcribe_sync, audio_path))
