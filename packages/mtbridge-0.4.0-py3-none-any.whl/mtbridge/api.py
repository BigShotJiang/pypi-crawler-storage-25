"""HTTP API for RBAC management.

Runs on a separate port (default 8800) inside the agent container.
IDE server proxies requests from the web UI to this API.

Endpoints:
    GET  /tg/status          — bridge status
    GET  /tg/users           — list users
    POST /tg/users           — add user
    PATCH /tg/users/:id      — update user
    DELETE /tg/users/:id     — delete user
    GET  /tg/roles           — list roles
    POST /tg/roles           — add role
    PATCH /tg/roles/:name    — update role
    DELETE /tg/roles/:name   — delete role
    GET  /tg/chats           — list chat-project bindings
    POST /tg/chats           — bind chat to project
    DELETE /tg/chats/:id     — unbind chat
    GET  /tg/hidden          — list hidden paths
    POST /tg/hidden          — add hidden path
    DELETE /tg/hidden/:id    — remove hidden path
"""

import json
import logging
from http.server import HTTPServer, BaseHTTPRequestHandler
from dataclasses import asdict
from typing import Optional

from .access import AccessManager

logger = logging.getLogger(__name__)


class APIHandler(BaseHTTPRequestHandler):
    """Simple HTTP handler for RBAC API."""

    access_mgr: Optional[AccessManager] = None
    bridge_status: dict = {}

    def log_message(self, format, *args):
        logger.debug("API: %s", format % args)

    def _json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        return json.loads(self.rfile.read(length))

    def do_OPTIONS(self):
        self._json({})

    def do_GET(self):
        mgr = self.__class__.access_mgr
        path = self.path.split("?")[0]

        if path == "/tg/status":
            self._json(self.__class__.bridge_status)

        elif path == "/tg/users":
            if not mgr:
                self._json({"error": "Access control disabled"}, 503)
                return
            users = mgr.list_users()
            self._json([{
                "telegram_id": u.telegram_id,
                "username": u.username,
                "display_name": u.display_name,
                "role_name": u.role_name,
                "allowed_projects": u.allowed_projects,
                "is_active": u.is_active,
            } for u in users])

        elif path == "/tg/roles":
            if not mgr:
                self._json({"error": "Access control disabled"}, 503)
                return
            roles = mgr.list_roles()
            self._json([{
                "name": r.name,
                "allowed_models": r.allowed_models,
                "can_bash": r.can_bash,
                "can_write": r.can_write,
                "can_push": r.can_push,
                "can_creds": r.can_creds,
                "budget_limit": r.budget_limit,
            } for r in roles])

        elif path == "/tg/chats":
            if not mgr:
                self._json({"error": "Access control disabled"}, 503)
                return
            chats = mgr.list_chat_projects()
            self._json([{"chat_id": c[0], "project_name": c[1]} for c in chats])

        elif path == "/tg/hidden":
            if not mgr:
                self._json({"error": "Access control disabled"}, 503)
                return
            project = self.path.split("project=")[1] if "project=" in self.path else None
            hidden = mgr.list_hidden_paths(project)
            self._json(hidden)

        else:
            self._json({"error": "Not found"}, 404)

    def do_POST(self):
        mgr = self.__class__.access_mgr
        if not mgr:
            self._json({"error": "Access control disabled"}, 503)
            return

        path = self.path.split("?")[0]
        body = self._body()

        if path == "/tg/users":
            mgr.add_user(
                telegram_id=int(body["telegram_id"]),
                username=body.get("username", ""),
                display_name=body.get("display_name", ""),
                role_name=body.get("role_name", "viewer"),
                allowed_projects=body.get("allowed_projects", "*"),
            )
            self._json({"ok": True})

        elif path == "/tg/roles":
            mgr.add_role(
                name=body["name"],
                allowed_models=body.get("allowed_models", "haiku"),
                can_bash=body.get("can_bash", False),
                can_write=body.get("can_write", False),
                can_push=body.get("can_push", False),
                can_creds=body.get("can_creds", False),
                budget_limit=body.get("budget_limit", 0.0),
            )
            self._json({"ok": True})

        elif path == "/tg/chats":
            mgr.set_chat_project(int(body["chat_id"]), body["project_name"])
            self._json({"ok": True})

        elif path == "/tg/hidden":
            mgr.add_hidden_path(
                project_name=body["project_name"],
                path=body["path"],
                require_flag=body.get("require_flag", "can_creds"),
            )
            self._json({"ok": True})

        else:
            self._json({"error": "Not found"}, 404)

    def do_PATCH(self):
        mgr = self.__class__.access_mgr
        if not mgr:
            self._json({"error": "Access control disabled"}, 503)
            return

        path = self.path.split("?")[0]
        body = self._body()

        if path.startswith("/tg/users/"):
            tid = int(path.split("/")[-1])
            ok = mgr.update_user(tid, **body)
            self._json({"ok": ok})

        elif path.startswith("/tg/roles/"):
            name = path.split("/")[-1]
            ok = mgr.update_role(name, **body)
            self._json({"ok": ok})

        else:
            self._json({"error": "Not found"}, 404)

    def do_DELETE(self):
        mgr = self.__class__.access_mgr
        if not mgr:
            self._json({"error": "Access control disabled"}, 503)
            return

        path = self.path.split("?")[0]

        if path.startswith("/tg/users/"):
            tid = int(path.split("/")[-1])
            ok = mgr.delete_user(tid)
            self._json({"ok": ok})

        elif path.startswith("/tg/roles/"):
            name = path.split("/")[-1]
            ok, msg = mgr.delete_role(name)
            if ok:
                self._json({"ok": True})
            else:
                self._json({"error": msg}, 400)

        elif path.startswith("/tg/chats/"):
            cid = int(path.split("/")[-1])
            ok = mgr.remove_chat_project(cid)
            self._json({"ok": ok})

        elif path.startswith("/tg/hidden/"):
            rid = int(path.split("/")[-1])
            ok = mgr.remove_hidden_path(rid)
            self._json({"ok": ok})

        else:
            self._json({"error": "Not found"}, 404)


def start_api_server(access_mgr: Optional[AccessManager], port: int = 8800, status: dict = None):
    """Start API server in a background thread."""
    import threading

    APIHandler.access_mgr = access_mgr
    APIHandler.bridge_status = status or {}

    server = HTTPServer(("0.0.0.0", port), APIHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    logger.info("RBAC API server started on port %d", port)
    return server
