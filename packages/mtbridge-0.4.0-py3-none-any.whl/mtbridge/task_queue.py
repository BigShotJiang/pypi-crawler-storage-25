"""SQLite-based task queue for managing multiple concurrent tasks.

Replaces the in-memory dict[chat_id -> RunningTask] with a persistent
queue that supports multiple tasks per chat, task history, and session storage.
"""

import sqlite3
import time
import logging
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

logger = logging.getLogger(__name__)


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"
    CANCELLED = "cancelled"
    NEEDS_RECOVERY = "needs_recovery"


@dataclass
class QueuedTask:
    """A task record from the database."""
    id: int
    chat_id: int
    message_id: int
    sender_name: str
    prompt: str
    project_dir: str | None
    status: TaskStatus
    created_at: float
    started_at: float | None
    finished_at: float | None
    result_text: str | None
    error: str | None
    cost_usd: float
    progress: str
    progress_at: float | None
    pid: int | None
    model: str | None = None       # haiku / sonnet / opus
    thinking: bool = False          # extended thinking mode
    task_type: str | None = None   # review / commit / investigate / analyze / refactor
    team: bool = False             # agent teams mode
    fork_session: bool = False     # start parallel session (fork from current)
    sender_id: int | None = None   # telegram user ID (for access control)


class TaskQueue:
    """SQLite-backed task queue with session storage.

    Thread-safe via SQLite WAL mode. All operations are synchronous
    (fine for our async code — SQLite ops are fast, no I/O wait).
    """

    def __init__(self, db_path: Path):
        self._db_path = db_path
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._create_tables()
        self._migrate()
        # Recover any tasks stuck in RUNNING state (e.g. after crash)
        self._recover_stuck_tasks()

    def _create_tables(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                message_id INTEGER NOT NULL,
                sender_name TEXT NOT NULL DEFAULT '',
                prompt TEXT NOT NULL,
                project_dir TEXT,
                status TEXT NOT NULL DEFAULT 'pending',
                created_at REAL NOT NULL,
                started_at REAL,
                finished_at REAL,
                result_text TEXT,
                error TEXT,
                cost_usd REAL NOT NULL DEFAULT 0.0,
                progress TEXT NOT NULL DEFAULT '',
                progress_at REAL
            );

            CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
            CREATE INDEX IF NOT EXISTS idx_tasks_chat_id ON tasks(chat_id);
            CREATE INDEX IF NOT EXISTS idx_tasks_chat_status ON tasks(chat_id, status);

            CREATE TABLE IF NOT EXISTS sessions (
                chat_id INTEGER PRIMARY KEY,
                session_id TEXT NOT NULL,
                updated_at REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS task_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                event_data TEXT NOT NULL DEFAULT '',
                created_at REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_events_task ON task_events(task_id);
        """)
        self._conn.commit()

    def _migrate(self) -> None:
        """Add columns that may not exist in older databases."""
        cursor = self._conn.execute("PRAGMA table_info(tasks)")
        columns = {row[1] for row in cursor.fetchall()}
        if "progress" not in columns:
            self._conn.execute("ALTER TABLE tasks ADD COLUMN progress TEXT NOT NULL DEFAULT ''")
            self._conn.execute("ALTER TABLE tasks ADD COLUMN progress_at REAL")
            self._conn.commit()
            logger.info("Migrated tasks table: added progress columns")
        if "pid" not in columns:
            self._conn.execute("ALTER TABLE tasks ADD COLUMN pid INTEGER")
            self._conn.commit()
            logger.info("Migrated tasks table: added pid column")
        if "model" not in columns:
            self._conn.execute("ALTER TABLE tasks ADD COLUMN model TEXT")
            self._conn.execute("ALTER TABLE tasks ADD COLUMN thinking INTEGER NOT NULL DEFAULT 0")
            self._conn.commit()
            logger.info("Migrated tasks table: added model/thinking columns")
        if "task_type" not in columns:
            self._conn.execute("ALTER TABLE tasks ADD COLUMN task_type TEXT")
            self._conn.commit()
            logger.info("Migrated tasks table: added task_type column")
        if "team" not in columns:
            self._conn.execute("ALTER TABLE tasks ADD COLUMN team INTEGER NOT NULL DEFAULT 0")
            self._conn.commit()
            logger.info("Migrated tasks table: added team column")
        if "fork_session" not in columns:
            self._conn.execute("ALTER TABLE tasks ADD COLUMN fork_session INTEGER NOT NULL DEFAULT 0")
            self._conn.commit()
            logger.info("Migrated tasks table: added fork_session column")
        if "sender_id" not in columns:
            self._conn.execute("ALTER TABLE tasks ADD COLUMN sender_id INTEGER")
            self._conn.commit()
            logger.info("Migrated tasks table: added sender_id column")
        # Ensure task_events table exists (for DBs created before this feature)
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS task_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                event_data TEXT NOT NULL DEFAULT '',
                created_at REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_events_task ON task_events(task_id);
        """)
        self._conn.commit()

    def _recover_stuck_tasks(self) -> None:
        """Mark tasks stuck in RUNNING as NEEDS_RECOVERY (after crash/restart)."""
        cur = self._conn.execute(
            "UPDATE tasks SET status = ? WHERE status = ?",
            (TaskStatus.NEEDS_RECOVERY.value, TaskStatus.RUNNING.value),
        )
        if cur.rowcount > 0:
            self._conn.commit()
            logger.warning("Marked %d stuck tasks as needs_recovery", cur.rowcount)

    # ── Task operations ──────────────────────────────────────────────

    def enqueue(
        self,
        chat_id: int,
        message_id: int,
        sender_name: str,
        prompt: str,
        project_dir: str | None = None,
        model: str | None = None,
        thinking: bool = False,
        task_type: str | None = None,
        team: bool = False,
        fork_session: bool = False,
        sender_id: int | None = None,
    ) -> int:
        """Add a new task to the queue. Returns task ID."""
        cur = self._conn.execute(
            "INSERT INTO tasks (chat_id, message_id, sender_name, prompt, project_dir, status, created_at, model, thinking, task_type, team, fork_session, sender_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (chat_id, message_id, sender_name, prompt, project_dir,
             TaskStatus.PENDING.value, time.time(), model, int(thinking), task_type, int(team), int(fork_session), sender_id),
        )
        self._conn.commit()
        task_id = cur.lastrowid
        logger.info("Enqueued task #%d for chat %s sender=%s (model=%s, thinking=%s, type=%s, team=%s, fork=%s)",
                     task_id, chat_id, sender_id, model, thinking, task_type, team, fork_session)
        return task_id

    def take_next(self, chat_id: int | None = None) -> QueuedTask | None:
        """Take the next pending task (optionally for a specific chat).

        Atomically moves it to RUNNING status. Returns None if no pending tasks.
        """
        if chat_id is not None:
            row = self._conn.execute(
                "SELECT * FROM tasks WHERE status = ? AND chat_id = ? ORDER BY created_at ASC LIMIT 1",
                (TaskStatus.PENDING.value, chat_id),
            ).fetchone()
        else:
            row = self._conn.execute(
                "SELECT * FROM tasks WHERE status = ? ORDER BY created_at ASC LIMIT 1",
                (TaskStatus.PENDING.value,),
            ).fetchone()

        if not row:
            return None

        now = time.time()
        self._conn.execute(
            "UPDATE tasks SET status = ?, started_at = ? WHERE id = ?",
            (TaskStatus.RUNNING.value, now, row["id"]),
        )
        self._conn.commit()

        return self._row_to_task(row, status_override=TaskStatus.RUNNING, started_at_override=now)

    def take_by_id(self, task_id: int) -> QueuedTask | None:
        """Take a specific pending task by ID. Atomically sets it to RUNNING.

        Returns None if the task doesn't exist or is no longer pending.
        Uses UPDATE-first approach to avoid race conditions.
        """
        now = time.time()
        cur = self._conn.execute(
            "UPDATE tasks SET status = ?, started_at = ? WHERE id = ? AND status = ?",
            (TaskStatus.RUNNING.value, now, task_id, TaskStatus.PENDING.value),
        )
        self._conn.commit()

        if cur.rowcount == 0:
            return None

        row = self._conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        if not row:
            return None

        return self._row_to_task(row)

    def complete(self, task_id: int, result_text: str, cost_usd: float = 0.0) -> None:
        """Mark a task as completed successfully."""
        self._conn.execute(
            "UPDATE tasks SET status = ?, finished_at = ?, result_text = ?, cost_usd = ? WHERE id = ?",
            (TaskStatus.DONE.value, time.time(), result_text, cost_usd, task_id),
        )
        self._conn.commit()

    def fail(self, task_id: int, error: str, result_text: str = "") -> None:
        """Mark a task as failed."""
        self._conn.execute(
            "UPDATE tasks SET status = ?, finished_at = ?, error = ?, result_text = ? WHERE id = ?",
            (TaskStatus.FAILED.value, time.time(), error, result_text, task_id),
        )
        self._conn.commit()

    def update_progress(self, task_id: int, progress: str) -> None:
        """Update the progress text for a running task."""
        self._conn.execute(
            "UPDATE tasks SET progress = ?, progress_at = ? WHERE id = ?",
            (progress, time.time(), task_id),
        )
        self._conn.commit()

    def cancel(self, task_id: int) -> None:
        """Mark a task as cancelled."""
        self._conn.execute(
            "UPDATE tasks SET status = ?, finished_at = ? WHERE id = ?",
            (TaskStatus.CANCELLED.value, time.time(), task_id),
        )
        self._conn.commit()

    def cancel_pending_for_chat(self, chat_id: int) -> int:
        """Cancel all pending tasks for a chat. Returns count of cancelled tasks."""
        cur = self._conn.execute(
            "UPDATE tasks SET status = ?, finished_at = ? WHERE chat_id = ? AND status = ?",
            (TaskStatus.CANCELLED.value, time.time(), chat_id, TaskStatus.PENDING.value),
        )
        self._conn.commit()
        return cur.rowcount

    def set_pid(self, task_id: int, pid: int) -> None:
        """Store the subprocess PID for a running task."""
        self._conn.execute("UPDATE tasks SET pid = ? WHERE id = ?", (pid, task_id))
        self._conn.commit()

    # ── Event logging ────────────────────────────────────────────────

    def log_event(self, task_id: int, event_type: str, event_data: str) -> None:
        """Log a task event (tool call, text block, system prompt, etc.)."""
        # Truncate large event data to keep DB reasonable
        if len(event_data) > 5000:
            event_data = event_data[:5000] + "\n... (truncated)"
        try:
            self._conn.execute(
                "INSERT INTO task_events (task_id, event_type, event_data, created_at) VALUES (?, ?, ?, ?)",
                (task_id, event_type, event_data, time.time()),
            )
            self._conn.commit()
        except Exception:
            logger.debug("Failed to log event for task #%d", task_id, exc_info=True)

    def get_events(self, task_id: int) -> list[dict]:
        """Get all events for a task, ordered chronologically."""
        rows = self._conn.execute(
            "SELECT id, task_id, event_type, event_data, created_at FROM task_events WHERE task_id = ? ORDER BY id ASC",
            (task_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def is_cancelled(self, task_id: int) -> bool:
        """Check if a task has been cancelled (e.g. by admin panel)."""
        row = self._conn.execute(
            "SELECT status FROM tasks WHERE id = ?", (task_id,)
        ).fetchone()
        return row is not None and row["status"] == TaskStatus.CANCELLED.value

    def get_needs_recovery(self) -> list[QueuedTask]:
        """Get all tasks that need recovery after restart."""
        rows = self._conn.execute(
            "SELECT * FROM tasks WHERE status = ? ORDER BY started_at ASC",
            (TaskStatus.NEEDS_RECOVERY.value,),
        ).fetchall()
        return [self._row_to_task(r) for r in rows]

    def mark_running(self, task_id: int) -> None:
        """Set a task back to RUNNING (used during recovery)."""
        self._conn.execute(
            "UPDATE tasks SET status = ?, started_at = ? WHERE id = ?",
            (TaskStatus.RUNNING.value, time.time(), task_id),
        )
        self._conn.commit()

    # ── Queries ──────────────────────────────────────────────────────

    def get_task(self, task_id: int) -> QueuedTask | None:
        """Get a task by ID."""
        row = self._conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        return self._row_to_task(row) if row else None

    def get_running_for_chat(self, chat_id: int) -> list[QueuedTask]:
        """Get all running tasks for a chat."""
        rows = self._conn.execute(
            "SELECT * FROM tasks WHERE chat_id = ? AND status = ? ORDER BY started_at ASC",
            (chat_id, TaskStatus.RUNNING.value),
        ).fetchall()
        return [self._row_to_task(r) for r in rows]

    def get_pending_for_chat(self, chat_id: int) -> list[QueuedTask]:
        """Get all pending tasks for a chat."""
        rows = self._conn.execute(
            "SELECT * FROM tasks WHERE chat_id = ? AND status = ? ORDER BY created_at ASC",
            (chat_id, TaskStatus.PENDING.value),
        ).fetchall()
        return [self._row_to_task(r) for r in rows]

    def get_active_for_chat(self, chat_id: int) -> list[QueuedTask]:
        """Get running + pending tasks for a chat."""
        rows = self._conn.execute(
            "SELECT * FROM tasks WHERE chat_id = ? AND status IN (?, ?) ORDER BY created_at ASC",
            (chat_id, TaskStatus.RUNNING.value, TaskStatus.PENDING.value),
        ).fetchall()
        return [self._row_to_task(r) for r in rows]

    def get_all_pending(self) -> list[QueuedTask]:
        """Get all pending tasks across all chats."""
        rows = self._conn.execute(
            "SELECT * FROM tasks WHERE status = ? ORDER BY created_at ASC",
            (TaskStatus.PENDING.value,),
        ).fetchall()
        return [self._row_to_task(r) for r in rows]

    def get_running_count(self) -> int:
        """Get total number of running tasks."""
        row = self._conn.execute(
            "SELECT COUNT(*) as cnt FROM tasks WHERE status = ?",
            (TaskStatus.RUNNING.value,),
        ).fetchone()
        return row["cnt"] if row else 0

    def get_running_count_for_chat(self, chat_id: int) -> int:
        """Get number of running tasks for a specific chat."""
        row = self._conn.execute(
            "SELECT COUNT(*) as cnt FROM tasks WHERE chat_id = ? AND status = ?",
            (chat_id, TaskStatus.RUNNING.value),
        ).fetchone()
        return row["cnt"] if row else 0

    # ── Session storage ──────────────────────────────────────────────

    def get_session(self, chat_id: int) -> str | None:
        """Get Claude session ID for a chat."""
        row = self._conn.execute(
            "SELECT session_id FROM sessions WHERE chat_id = ?", (chat_id,)
        ).fetchone()
        return row["session_id"] if row else None

    def set_session(self, chat_id: int, session_id: str) -> None:
        """Store Claude session ID for a chat."""
        self._conn.execute(
            "INSERT INTO sessions (chat_id, session_id, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(chat_id) DO UPDATE SET session_id = ?, updated_at = ?",
            (chat_id, session_id, time.time(), session_id, time.time()),
        )
        self._conn.commit()

    def clear_session(self, chat_id: int) -> bool:
        """Clear Claude session for a chat. Returns True if session existed."""
        cur = self._conn.execute("DELETE FROM sessions WHERE chat_id = ?", (chat_id,))
        self._conn.commit()
        return cur.rowcount > 0

    # ── Cleanup ──────────────────────────────────────────────────────

    def cleanup_old_tasks(self, max_age_days: int = 30) -> int:
        """Remove completed/failed/cancelled tasks older than max_age_days."""
        cutoff = time.time() - (max_age_days * 86400)
        cur = self._conn.execute(
            "DELETE FROM tasks WHERE status IN (?, ?, ?) AND created_at < ?",
            (TaskStatus.DONE.value, TaskStatus.FAILED.value, TaskStatus.CANCELLED.value, cutoff),
        )
        self._conn.commit()
        if cur.rowcount > 0:
            logger.info("Cleaned up %d old tasks", cur.rowcount)
        return cur.rowcount

    # ── Internal ─────────────────────────────────────────────────────

    def _row_to_task(
        self,
        row: sqlite3.Row,
        status_override: TaskStatus | None = None,
        started_at_override: float | None = None,
    ) -> QueuedTask:
        return QueuedTask(
            id=row["id"],
            chat_id=row["chat_id"],
            message_id=row["message_id"],
            sender_name=row["sender_name"],
            prompt=row["prompt"],
            project_dir=row["project_dir"],
            status=status_override or TaskStatus(row["status"]),
            created_at=row["created_at"],
            started_at=started_at_override or row["started_at"],
            finished_at=row["finished_at"],
            result_text=row["result_text"],
            error=row["error"],
            cost_usd=row["cost_usd"],
            progress=row["progress"] if "progress" in row.keys() else "",
            progress_at=row["progress_at"] if "progress_at" in row.keys() else None,
            pid=row["pid"] if "pid" in row.keys() else None,
            model=row["model"] if "model" in row.keys() else None,
            thinking=bool(row["thinking"]) if "thinking" in row.keys() else False,
            task_type=row["task_type"] if "task_type" in row.keys() else None,
            team=bool(row["team"]) if "team" in row.keys() else False,
            fork_session=bool(row["fork_session"]) if "fork_session" in row.keys() else False,
            sender_id=row["sender_id"] if "sender_id" in row.keys() else None,
        )

    def close(self) -> None:
        self._conn.close()
