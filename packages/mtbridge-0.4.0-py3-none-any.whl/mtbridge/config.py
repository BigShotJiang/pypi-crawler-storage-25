"""Configuration loaded from environment variables."""

import os
import logging
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

# System prompt appended to Claude's default system prompt.
# Instructs Claude on how to behave in the Telegram chat context.
CLAUDE_SYSTEM_PROMPT = """You are working as an assistant in a Telegram group chat. Users send you tasks via messages.

IMPORTANT RULES:
1. You have full access to the filesystem, tools, bash, and can run any commands.
2. You can spawn sub-agents for parallel work — use them freely for complex tasks.
3. When context gets too long, you WILL automatically summarize and continue — this is expected behavior.
4. For long-running tasks (investigations, code analysis, log parsing):
   - Start with a brief assessment of what you'll do
   - Work through it systematically
   - Provide a clear, structured final answer
5. Always respond in the same language the user writes to you.
6. Be concise but thorough. Structure complex answers with headers and bullet points.
7. When working with code repos, explore the codebase first (tree, git log, etc.) before making changes.
8. If a task requires multiple steps, do them all — don't ask for confirmation between steps.

TELEGRAM INTERACTION:
- Each message includes context: who sent it and who else is in the chat.
- To MENTION someone in your reply, use their @username (e.g. @vadim).
- To send a PRIVATE MESSAGE (DM) to someone, wrap it like this:
    [DM @username]Текст личного сообщения[/DM]
  The bridge will intercept this and deliver it as a private Telegram message.
  You can combine a chat reply with DMs — DM blocks will be extracted and sent separately.
- If someone asks you to "write to X" or "message X", use the DM directive.
- If someone asks you to "tag X" or "ping X", mention them with @username in your reply.

FILE SENDING (Telegram upload):
  ONLY use when the user EXPLICITLY asks to send/share/deliver a file. NEVER send files on your own initiative. NEVER repeat the same [FILE] directive twice.
  Syntax: [FILE /absolute/path]  or  [FILE /absolute/path caption text]
  Rules:
  - The file MUST exist on disk before you use this directive. Verify with ls or Read if unsure.
  - Use each [FILE ...] directive EXACTLY ONCE per file. The bridge delivers it — do not retry or repeat.
  - By default, [FILE] sends to the CURRENT CHAT.
  - To send a file into a DM, put [FILE] INSIDE a [DM] block:
      [DM @username][FILE /path/to/file][/DM]
  - To send a file to the current chat, put [FILE] OUTSIDE any [DM] block:
      Вот файл: [FILE /path/to/file]
  - Max 50 MB. Path MUST be absolute.

PLAN MODE:
For complex tasks (multi-file changes, refactors, new features), use plan mode:
call EnterPlanMode, explore the codebase, write your plan, then call ExitPlanMode.
The user will be asked to approve your plan via Telegram before execution proceeds.
For simple tasks (single file edits, reading, analysis), proceed directly without plan mode.
"""


@dataclass(frozen=True)
class Config:
    # Telegram
    api_id: int
    api_hash: str
    session: str

    # Claude
    claude_cli: str

    # Bot API (optional — enables inline buttons, plan approval, queue choice)
    bot_token: str = ""
    default_model: str = "sonnet"
    system_prompt: str = CLAUDE_SYSTEM_PROMPT

    # Directories
    work_dir: Path = field(default_factory=lambda: Path("/home/claude/projects"))
    # Chats
    allowed_chats: list[int] = field(default_factory=list)

    # Triggers
    triggers: list[str] = field(default_factory=lambda: ["@claude", "@клод", "клод", "claude"])

    # Timing
    progress_interval: int = 30
    max_execution_time: int = 10800  # 3 hours — long experiments (H1, training, etc.)

    # Budget
    max_budget_usd: float = 0  # 0 = no limit

    # Access control
    access_control_enabled: bool = False   # env: ACCESS_CONTROL=1
    sandbox_enabled: bool = False          # env: SANDBOX_ENABLED=1
    sandbox_script: str = ""               # path to sandbox-claude.sh

    # Logging
    log_level: str = "INFO"

    @classmethod
    def from_env(cls) -> "Config":
        api_id_raw = os.getenv("TG_API_ID")
        api_hash = os.getenv("TG_API_HASH")
        session = os.getenv("TG_SESSION")
        claude_cli = os.getenv("CLAUDE_CLI", "/home/claude/.local/bin/claude")
        default_model = os.getenv("DEFAULT_MODEL", "sonnet")
        work_dir = os.getenv("WORK_DIR", "/home/claude/projects")

        if not api_id_raw or not api_hash:
            raise ValueError(
                "TG_API_ID and TG_API_HASH are required. "
                "Get them from https://my.telegram.org"
            )

        if not session:
            raise ValueError(
                "TG_SESSION is required. Generate it with: python -m mtbridge.auth"
            )

        allowed_chats_raw = os.getenv("ALLOWED_CHATS", "")
        allowed_chats = []
        if allowed_chats_raw.strip():
            allowed_chats = [int(c.strip()) for c in allowed_chats_raw.split(",") if c.strip()]

        triggers_raw = os.getenv("TRIGGERS", "@claude,@клод,клод,claude")
        triggers = [t.strip().lower() for t in triggers_raw.split(",") if t.strip()]

        progress_interval = int(os.getenv("PROGRESS_INTERVAL", "30"))
        max_execution_time = int(os.getenv("MAX_EXECUTION_TIME", "10800"))
        max_budget_usd = float(os.getenv("MAX_BUDGET_USD", "0"))
        log_level = os.getenv("LOG_LEVEL", "INFO")

        system_prompt = os.getenv("CLAUDE_SYSTEM_PROMPT", CLAUDE_SYSTEM_PROMPT)
        bot_token = os.getenv("BOT_TOKEN", "")

        access_control_enabled = os.getenv("ACCESS_CONTROL", "0") == "1"
        sandbox_enabled = os.getenv("SANDBOX_ENABLED", "0") == "1"
        sandbox_script = os.getenv("SANDBOX_SCRIPT", "")

        return cls(
            api_id=int(api_id_raw),
            api_hash=api_hash,
            session=session,
            bot_token=bot_token,
            claude_cli=claude_cli,
            default_model=default_model,
            system_prompt=system_prompt,
            work_dir=Path(work_dir),
            allowed_chats=allowed_chats,
            triggers=triggers,
            progress_interval=progress_interval,
            max_execution_time=max_execution_time,
            max_budget_usd=max_budget_usd,
            access_control_enabled=access_control_enabled,
            sandbox_enabled=sandbox_enabled,
            sandbox_script=sandbox_script,
            log_level=log_level,
        )
