"""Magic prompt router — selects specialized system prompts by task type.

Detects task type from explicit modifiers ([review], [commit], etc.)
and loads the appropriate prompt template.

Metadata (aliases, default_model) comes from two sources:
1. TASK_TYPES dict below (built-in prompts)
2. prompts/prompts_meta.json (prompts created via admin panel)
Admin-created metadata takes precedence on conflict.
"""

import json
import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)

# Directory containing prompt templates
PROMPTS_DIR = Path(__file__).parent / "prompts"
PROMPTS_META_FILE = PROMPTS_DIR / "prompts_meta.json"

# Built-in task types with their modifier aliases
TASK_TYPES: dict[str, dict] = {
    "review": {
        "aliases": {"review", "ревью", "ревьюхни", "проревьюй"},
        "default_model": "haiku",  # Reviews can be fast
    },
    "commit": {
        "aliases": {"commit", "коммит", "закоммить"},
        "default_model": "haiku",
    },
    "investigate": {
        "aliases": {"investigate", "расследуй", "debug", "дебаг", "найди.баг"},
        "default_model": None,  # Use default (usually opus/sonnet)
    },
    "analyze": {
        "aliases": {"analyze", "анализ", "проанализируй"},
        "default_model": None,
    },
    "refactor": {
        "aliases": {"refactor", "рефактор", "отрефактори"},
        "default_model": None,
    },
}

# Static alias map from built-in TASK_TYPES
_ALIAS_MAP: dict[str, str] = {}
for task_type, config in TASK_TYPES.items():
    for alias in config["aliases"]:
        _ALIAS_MAP[alias] = task_type


def _load_meta() -> dict[str, dict]:
    """Load prompt metadata from JSON file (hot-reload on every call).

    Returns dict like: {"deploy": {"aliases": ["деплой"], "default_model": "haiku"}}
    """
    try:
        if PROMPTS_META_FILE.exists():
            data = json.loads(PROMPTS_META_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
    except Exception:
        logger.warning("Could not read prompts_meta.json", exc_info=True)
    return {}


def _save_meta(meta: dict[str, dict]) -> None:
    """Save prompt metadata to JSON file."""
    PROMPTS_META_FILE.write_text(
        json.dumps(meta, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def resolve_alias(tag: str) -> str | None:
    """Resolve a modifier tag to a task_type name.

    Checks in order:
    1. Built-in _ALIAS_MAP (from TASK_TYPES)
    2. Aliases from prompts_meta.json
    3. Direct .md file existence (prompt name == tag)
    """
    # 1. Built-in aliases
    if tag in _ALIAS_MAP:
        return _ALIAS_MAP[tag]

    # 2. Dynamic aliases from JSON meta
    meta = _load_meta()
    for name, cfg in meta.items():
        aliases = cfg.get("aliases", [])
        if tag in aliases or tag == name:
            return name

    # 3. Fallback: .md file exists with this exact name
    if (PROMPTS_DIR / f"{tag}.md").exists():
        return tag

    return None


def get_all_meta() -> dict[str, dict]:
    """Get merged metadata: built-in TASK_TYPES + JSON meta.

    Returns dict like: {"review": {"aliases": [...], "default_model": "haiku"}, ...}
    Used by admin panel to display full prompt info.
    """
    result = {}
    # Start with built-in
    for name, cfg in TASK_TYPES.items():
        result[name] = {
            "aliases": sorted(cfg.get("aliases", set())),
            "default_model": cfg.get("default_model"),
            "source": "built-in",
        }
    # Merge/override with JSON meta
    meta = _load_meta()
    for name, cfg in meta.items():
        if name in result:
            # Merge: JSON overrides built-in
            result[name]["aliases"] = sorted(set(
                result[name]["aliases"] + cfg.get("aliases", [])
            ))
            if cfg.get("default_model") is not None:
                result[name]["default_model"] = cfg["default_model"]
            result[name]["source"] = "merged"
        else:
            result[name] = {
                "aliases": sorted(cfg.get("aliases", [])),
                "default_model": cfg.get("default_model"),
                "source": "admin",
            }
    return result


def extract_task_modifier(prompt: str) -> tuple[str | None, str]:
    """Extract explicit task type modifier from prompt.

    Format: [review] do the thing → ("review", "do the thing")
    Returns (task_type, remaining_prompt).
    """
    match = re.match(r'^\[([a-zA-Zа-яА-ЯёЁ._]+)\]\s*(.*)', prompt, re.DOTALL)
    if match:
        tag = match.group(1).lower()
        resolved = resolve_alias(tag)
        if resolved:
            return resolved, match.group(2).strip()
    return None, prompt


def load_prompt(task_type: str) -> str | None:
    """Load a prompt template by task type name.

    Reads from mtbridge/prompts/{task_type}.md.
    Returns None if file doesn't exist.
    """
    prompt_file = PROMPTS_DIR / f"{task_type}.md"
    try:
        if prompt_file.exists():
            content = prompt_file.read_text(encoding="utf-8").strip()
            if content:
                logger.debug("Loaded magic prompt: %s (%d chars)", task_type, len(content))
                return content
    except Exception:
        logger.warning("Could not read prompt template %s", prompt_file, exc_info=True)
    return None


def get_magic_prompt(prompt: str) -> tuple[str | None, str | None, str]:
    """Main entry point: detect task type, load magic prompt, clean up prompt.

    Only explicit [modifier] syntax triggers magic prompts.
    Returns (task_type, magic_prompt_text, cleaned_prompt).
    """
    task_type, cleaned = extract_task_modifier(prompt)

    magic_prompt = None
    if task_type:
        magic_prompt = load_prompt(task_type)

    return task_type, magic_prompt, cleaned


def get_default_model(task_type: str | None) -> str | None:
    """Get the default model for a task type (if any).

    Checks built-in TASK_TYPES first, then JSON meta.
    """
    if not task_type:
        return None
    if task_type in TASK_TYPES:
        m = TASK_TYPES[task_type].get("default_model")
        if m:
            return m
    # Check JSON meta
    meta = _load_meta()
    if task_type in meta:
        return meta[task_type].get("default_model")
    return None
