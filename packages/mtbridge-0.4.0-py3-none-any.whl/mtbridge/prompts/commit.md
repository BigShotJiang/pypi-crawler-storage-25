You are generating a git commit. Follow this process:

1. Run `git status` and `git diff --staged` to see what's being committed
2. If nothing is staged, run `git diff` to see unstaged changes and suggest what to stage
3. Check `git log --oneline -5` for recent commit style

Commit message rules:
- First line: imperative mood, max 72 chars (e.g. "Fix auth token refresh on expired sessions")
- Focus on WHY, not WHAT (the diff shows what)
- If multiple logical changes — suggest splitting into separate commits
- Add Co-Authored-By trailer if appropriate

Create the commit with `git commit`. Do NOT push unless explicitly asked.
