"""Telegram message handler — the bridge between Telegram and Claude.

Detects when someone addresses Claude in a group chat,
enqueues the task into SQLite, and a background worker picks it up.
Supports multiple concurrent tasks per chat.
Claude can mention users (@username) and send DMs via [DM @user]...[/DM].
"""

import asyncio
import collections
import json
import logging
import os
import re
import sqlite3
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

from telethon import TelegramClient, events, Button
from telethon.tl.types import (
    User,
    MessageMediaPhoto,
    MessageMediaDocument,
    DocumentAttributeAudio,
    DocumentAttributeVideo,
    DocumentAttributeSticker,
)

from .config import Config
from .sdk_runner import SDKRunner, RunningTask, TaskResult
from .task_queue import TaskQueue, TaskStatus
from . import transcriber

logger = logging.getLogger(__name__)

# Max Telegram message length
TG_MAX_LEN = 4096

# Commands
CMD_CANCEL = "/cancel"
CMD_STATUS = "/status"
CMD_HELP = "/help"
CMD_NEW = "/new"

# DM directive pattern: [DM @username] message text [/DM]
DM_PATTERN = re.compile(
    r'\[DM\s+@?(\S+?)\]\s*(.*?)\s*\[/DM\]',
    re.DOTALL,
)

# FILE directive pattern: [FILE /path/to/file] or [FILE /path/to/file caption text][/FILE]
FILE_PATTERN = re.compile(
    r'\[FILE\s+(/\S+?)(?:\s+(.*?))?\]\s*(?:\[/FILE\])?',
    re.DOTALL,
)

# Max file size for Telegram upload (50 MB for bots, but we use user account)
MAX_UPLOAD_SIZE_MB = 50

# Cache TTL for chat participants (5 minutes)
PARTICIPANTS_CACHE_TTL = 300

# How often the queue worker checks for new tasks (seconds)
QUEUE_POLL_INTERVAL = 1.0

# Scheduled tasks: memory DB path and poll interval
MEMORY_DB_PATH = Path("/home/claude/projects/.mtbridge_memory.db")
SCHEDULED_POLL_INTERVAL = 30.0

# Max concurrent tasks (Claude subprocesses) across all chats
MAX_CONCURRENT_TASKS = 3

# Media handling
MEDIA_DIR = Path(tempfile.gettempdir()) / "mtbridge_media"
MAX_MEDIA_SIZE_MB = 20  # Skip files larger than this
SUPPORTED_IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}
SUPPORTED_DOC_EXTS = {".txt", ".py", ".js", ".ts", ".json", ".yaml", ".yml", ".toml",
                      ".md", ".csv", ".xml", ".html", ".css", ".sh", ".sql", ".log",
                      ".cfg", ".ini", ".conf", ".env", ".pdf"}


def truncate_for_telegram(text: str, max_len: int = TG_MAX_LEN) -> str:
    """Truncate text to fit Telegram message limit."""
    if len(text) <= max_len:
        return text
    # Leave room for truncation notice
    cutoff = max_len - 50
    return text[:cutoff] + "\n\n... [truncated, full output too long]"


def split_for_telegram(text: str, max_len: int = TG_MAX_LEN) -> list[str]:
    """Split long text into multiple Telegram messages."""
    if len(text) <= max_len:
        return [text]

    chunks = []
    while text:
        if len(text) <= max_len:
            chunks.append(text)
            break

        # Try to split at a newline
        split_at = text.rfind("\n", 0, max_len)
        if split_at < max_len // 2:
            # No good newline, split at max_len
            split_at = max_len

        chunks.append(text[:split_at])
        text = text[split_at:].lstrip("\n")

    return chunks


@dataclass
class ChatParticipant:
    """Cached Telegram user info."""
    user_id: int
    first_name: str
    last_name: str
    username: str  # empty if no username

    @property
    def display_name(self) -> str:
        name = self.first_name
        if self.last_name:
            name += f" {self.last_name}"
        return name

    @property
    def mention_str(self) -> str:
        """How Claude should mention this user."""
        if self.username:
            return f"@{self.username}"
        return f'<a href="tg://user?id={self.user_id}">{self.display_name}</a>'


@dataclass
class CachedParticipants:
    """Cached participant list with TTL."""
    participants: list[ChatParticipant]
    fetched_at: float


class TelegramHandler:
    """Handles Telegram events and bridges them to Claude.

    New architecture:
    - Messages are enqueued into SQLite immediately (never lost)
    - A background worker picks up pending tasks and runs them
    - Multiple tasks can run concurrently (up to MAX_CONCURRENT_TASKS)
    - Progress messages are reply-linked to the original message
    """

    def __init__(
        self,
        client: TelegramClient,
        config: Config,
        runner: SDKRunner,
        task_queue: TaskQueue,
        bot_client: TelegramClient | None = None,
        access_mgr: "AccessManager | None" = None,
    ):
        self.client = client
        self.bot_client = bot_client
        self.config = config
        self.runner = runner
        self.task_queue = task_queue
        self.access_mgr = access_mgr
        self._my_id: int | None = None
        self._my_name: str = ""
        self._my_username: str = ""
        # task_id -> progress_msg_id (each task has its own progress message)
        self._progress_messages: dict[int, int] = {}
        # task_id -> intermediate_text_msg_id (one editable msg per task)
        self._intermediate_messages: dict[int, int] = {}
        self._my_sent_messages: collections.deque[tuple[int, int]] = collections.deque(maxlen=1000)
        self._participants_cache: dict[int, CachedParticipants] = {}  # chat_id -> cached
        self._worker_task: asyncio.Task | None = None
        self._scheduled_worker_task: asyncio.Task | None = None
        # task_id -> (event, participants) for sending results
        self._task_context: dict[int, tuple[events.NewMessage.Event, list[ChatParticipant]]] = {}
        # Bot callback infrastructure
        self._callback_futures: dict[str, asyncio.Future] = {}
        self._pending_queue_choices: dict[str, dict] = {}
        self._queue_choice_timeouts: dict[str, asyncio.TimerHandle] = {}
        # Access control results per task (task_id -> AccessResult)
        self._task_access: dict[int, "AccessResult"] = {}

    async def setup(self) -> None:
        """Initialize handler — get own user info."""
        me = await self.client.get_me()
        assert isinstance(me, User)
        self._my_id = me.id
        self._my_name = (me.first_name or "") + " " + (me.last_name or "")
        self._my_name = self._my_name.strip()
        self._my_username = (me.username or "").lower()
        logger.info("Logged in as: %s (@%s, id=%s)", self._my_name, self._my_username, self._my_id)

    def register(self) -> None:
        """Register event handlers on the client."""
        self.client.add_event_handler(self._on_new_message, events.NewMessage)
        if self.bot_client:
            self.bot_client.add_event_handler(self._on_callback_query, events.CallbackQuery)
            logger.info("Bot callback handler registered")

    def start_worker(self) -> None:
        """Start the background queue worker and scheduled tasks worker."""
        self._worker_task = asyncio.create_task(self._queue_worker())
        logger.info("Queue worker started (max concurrent tasks: %d)", MAX_CONCURRENT_TASKS)
        self._scheduled_worker_task = asyncio.create_task(self._scheduled_tasks_worker())
        logger.info("Scheduled tasks worker started (interval: %ds)", int(SCHEDULED_POLL_INTERVAL))

    async def stop_worker(self) -> None:
        """Stop the background queue worker and scheduled tasks worker."""
        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
        if self._scheduled_worker_task:
            self._scheduled_worker_task.cancel()
            try:
                await self._scheduled_worker_task
            except asyncio.CancelledError:
                pass

    # ── Scheduled tasks worker ──────────────────────────────────────

    async def _scheduled_tasks_worker(self) -> None:
        """Background worker that executes scheduled tasks (delayed DMs, etc.)."""
        logger.info("Scheduled tasks worker loop started")
        while True:
            try:
                await self._process_scheduled_tasks()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("Scheduled tasks worker error")
            await asyncio.sleep(SCHEDULED_POLL_INTERVAL)

    async def _process_scheduled_tasks(self) -> None:
        """Check for pending scheduled tasks and execute them."""
        if not MEMORY_DB_PATH.exists():
            return

        now = time.time()
        try:
            conn = sqlite3.connect(str(MEMORY_DB_PATH))
            conn.row_factory = sqlite3.Row
            # Get tasks that are due
            rows = conn.execute(
                "SELECT task_id, action_type, payload, notes "
                "FROM scheduled_tasks "
                "WHERE status = 'pending' AND scheduled_at <= ? "
                "ORDER BY scheduled_at LIMIT 10",
                (now,),
            ).fetchall()

            for row in rows:
                task_id = row["task_id"]
                # Mark as executing
                conn.execute(
                    "UPDATE scheduled_tasks SET status = 'executing' WHERE task_id = ?",
                    (task_id,),
                )
                conn.commit()

                try:
                    payload = json.loads(row["payload"])
                    action_type = row["action_type"]

                    if action_type == "dm":
                        await self._execute_scheduled_dm(payload)
                        result_msg = "DM sent via Telethon"
                    elif action_type == "chat_message":
                        await self._execute_scheduled_chat_message(payload)
                        result_msg = "Chat message sent"
                    else:
                        result_msg = f"Unsupported action type: {action_type}"

                    conn.execute(
                        "UPDATE scheduled_tasks SET status = 'completed', "
                        "executed_at = ?, result = ? WHERE task_id = ?",
                        (time.time(), result_msg, task_id),
                    )
                    conn.commit()
                    logger.info("Scheduled task #%d (%s) completed", task_id, action_type)

                except Exception as e:
                    conn.execute(
                        "UPDATE scheduled_tasks SET status = 'failed', "
                        "executed_at = ?, result = ? WHERE task_id = ?",
                        (time.time(), str(e)[:500], task_id),
                    )
                    conn.commit()
                    logger.exception("Scheduled task #%d failed", task_id)

            conn.close()
        except Exception:
            logger.exception("Error accessing scheduled tasks DB")

    async def _execute_scheduled_dm(self, payload: dict) -> None:
        """Send a scheduled DM via Telethon."""
        recipient = payload.get("recipient", "")
        message = payload.get("message", "")
        if not recipient or not message:
            raise ValueError(f"Invalid DM payload: {payload}")

        username = recipient.lstrip("@")
        target_id = await self._resolve_user(username)
        if not target_id:
            raise ValueError(f"Could not resolve user @{username}")

        await self.client.send_message(target_id, message)
        logger.info("Scheduled DM sent to @%s", username)

    async def _execute_scheduled_chat_message(self, payload: dict) -> None:
        """Send a scheduled message to a chat."""
        chat_id = payload.get("chat_id")
        message = payload.get("message", "")
        if not chat_id or not message:
            raise ValueError(f"Invalid chat_message payload: {payload}")

        await self.client.send_message(int(chat_id), message)
        logger.info("Scheduled chat message sent to %s", chat_id)

    # ── Bot callback handlers ────────────────────────────────────────

    async def _on_callback_query(self, event: events.CallbackQuery.Event) -> None:
        """Central dispatcher for inline button presses."""
        data = event.data.decode("utf-8") if event.data else ""
        logger.debug("Callback query: data=%s from user=%s", data, event.sender_id)

        try:
            if data.startswith("cancel:"):
                task_id = int(data.split(":")[1])
                await self._handle_cancel_callback(event, task_id)
            elif data.startswith("approve:") or data.startswith("reject:"):
                await self._handle_plan_callback(event, data)
            elif data.startswith("queue:") or data.startswith("newsess:"):
                await self._handle_queue_choice_callback(event, data)
            else:
                await event.answer("Unknown action")
        except Exception:
            logger.exception("Error handling callback query: %s", data)
            await event.answer("Error")

    async def _handle_cancel_callback(self, event: events.CallbackQuery.Event, task_id: int) -> None:
        """Handle cancel button press on progress message."""
        task = self.runner.get_active_task_by_id(task_id)
        if task:
            await self.runner.cancel_task_by_id(task_id)
            await self._cleanup_progress(task_id, task.chat_id)
            await event.answer("🛑 Cancelled")
            try:
                await event.edit(f"🛑 Task #{task_id} cancelled")
            except Exception:
                pass
        else:
            await event.answer("Task already finished")

    async def _handle_plan_callback(self, event: events.CallbackQuery.Event, data: str) -> None:
        """Handle plan approval/rejection button press."""
        parts = data.split(":")
        action = parts[0]  # "approve" or "reject"
        task_id = int(parts[1])
        approval_key = f"plan:{task_id}"

        future = self._callback_futures.pop(approval_key, None)
        if future and not future.done():
            approved = (action == "approve")
            future.set_result(approved)
            status = "✅ Approved" if approved else "❌ Rejected"
            await event.answer(status)
            try:
                await event.edit(event.text + f"\n\n{status}")
            except Exception:
                pass
        else:
            await event.answer("Already handled or expired")

    async def _handle_queue_choice_callback(self, event: events.CallbackQuery.Event, data: str) -> None:
        """Handle queue/new-session button press."""
        parts = data.split(":")
        action = parts[0]  # "queue" or "newsess"
        chat_id = int(parts[1])
        msg_id = int(parts[2])

        pending_key = f"qchoice:{chat_id}:{msg_id}"
        choice_data = self._pending_queue_choices.pop(pending_key, None)

        # Cancel the timeout
        timeout_handle = self._queue_choice_timeouts.pop(pending_key, None)
        if timeout_handle:
            timeout_handle.cancel()

        if not choice_data:
            await event.answer("Expired or already handled")
            return

        fork = (action == "newsess")
        task_id = self.task_queue.enqueue(
            chat_id=chat_id,
            message_id=msg_id,
            sender_name=choice_data["sender_name"],
            prompt=choice_data["prompt"],
            project_dir=choice_data["project_dir"],
            model=choice_data["model"],
            thinking=choice_data["thinking"],
            task_type=choice_data["task_type"],
            team=choice_data["team"],
            fork_session=fork,
            sender_id=choice_data.get("sender_id"),
        )

        self._task_context[task_id] = (choice_data["event"], choice_data["participants"])

        if fork:
            await event.answer("🆕 New session")
            try:
                await event.edit(f"🆕 Task #{task_id} — parallel session")
            except Exception:
                pass
        else:
            await event.answer("📥 Queued")
            try:
                await event.edit(f"📥 Task #{task_id} — in queue")
            except Exception:
                pass

    async def _send_plan_approval(self, task: RunningTask, plan_text: str) -> "asyncio.Future[bool]":
        """Send plan with Approve/Reject buttons via bot. Returns Future resolved by button click."""
        future: asyncio.Future[bool] = asyncio.get_running_loop().create_future()
        approval_key = f"plan:{task.task_id}"
        self._callback_futures[approval_key] = future

        send_client = self.bot_client or self.client
        plan_display = truncate_for_telegram(f"📋 Plan for Task #{task.task_id}:\n\n{plan_text}", max_len=3800)

        buttons = None
        if self.bot_client:
            buttons = [[
                Button.inline("✅ Approve", f"approve:{task.task_id}".encode()),
                Button.inline("❌ Reject", f"reject:{task.task_id}".encode()),
            ]]

        await send_client.send_message(
            task.chat_id,
            plan_display,
            reply_to=task.message_id,
            buttons=buttons,
        )

        return future

    # ── Recovery ─────────────────────────────────────────────────────

    async def recover_tasks(self) -> None:
        """Attempt to recover tasks interrupted by restart."""
        tasks = self.task_queue.get_needs_recovery()
        if not tasks:
            return
        logger.info("Found %d tasks needing recovery", len(tasks))
        for task in tasks:
            logger.info("Recovering task #%d for chat %d (pid=%s)", task.id, task.chat_id, task.pid)
            asyncio.create_task(self._recover_single_task(task))

    async def _recover_single_task(self, task) -> None:
        """Recover a single interrupted task and deliver the result."""
        # Notify user
        try:
            await self.client.send_message(
                task.chat_id,
                f"Восстанавливаю задачу #{task.id} после перезапуска сервиса...",
                reply_to=task.message_id,
            )
        except Exception:
            logger.debug("Could not send recovery notification for task #%d", task.id)

        self.task_queue.mark_running(task.id)

        try:
            result = await self.runner.recover_task(
                task_id=task.id,
                chat_id=task.chat_id,
                message_id=task.message_id,
                pid=task.pid,
                project_dir=task.project_dir,
                on_progress=self._send_progress,
            )

            if result.success:
                self.task_queue.complete(task.id, result.output, result.cost_usd)
            else:
                self.task_queue.fail(task.id, result.error, result.output)

            # Deliver result to chat
            participants = await self._get_participants(task.chat_id)
            await self._send_result_to_chat(
                task.chat_id, task.message_id, result, participants, task.id,
            )

        except Exception:
            logger.exception("Failed to recover task #%d", task.id)
            self.task_queue.fail(task.id, "Recovery failed")

    # ── Queue worker ─────────────────────────────────────────────────

    async def _queue_worker(self) -> None:
        """Background worker that picks tasks from the queue and runs them."""
        logger.info("Queue worker loop started")
        while True:
            try:
                await self._process_queue()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("Queue worker error")
            await asyncio.sleep(QUEUE_POLL_INTERVAL)

    async def _process_queue(self) -> None:
        """Check for pending tasks and start them if capacity allows."""
        running_count = self.runner.active_task_count
        if running_count >= MAX_CONCURRENT_TASKS:
            return

        pending = self.task_queue.get_all_pending()
        if not pending:
            return

        # Track which chats already have a task starting in this iteration
        chats_starting = set()

        for queued in pending:
            if self.runner.active_task_count >= MAX_CONCURRENT_TASKS:
                break

            # Only one task per chat at a time — unless fork_session is set
            if (self.runner.get_running_tasks_for_chat(queued.chat_id)
                    or queued.chat_id in chats_starting):
                if not getattr(queued, 'fork_session', False):
                    continue

            # Take this specific task (atomically set to RUNNING in DB)
            taken = self.task_queue.take_by_id(queued.id)
            if not taken:
                continue

            chats_starting.add(taken.chat_id)

            logger.info(
                "Worker picked up task #%d for chat %s: %.80s",
                taken.id, taken.chat_id, taken.prompt,
            )

            # Launch as async task (fire-and-forget, but tracked)
            asyncio.create_task(self._run_task(
                taken.id, taken.chat_id, taken.message_id, taken.prompt,
                taken.project_dir, taken.model, taken.thinking, taken.task_type,
                taken.team, getattr(taken, 'fork_session', False),
            ))

    async def _run_task(
        self,
        task_id: int,
        chat_id: int,
        message_id: int,
        prompt: str,
        project_dir: str | None,
        model: str | None = None,
        thinking: bool = False,
        task_type: str | None = None,
        team: bool = False,
        fork_session: bool = False,
    ) -> None:
        """Execute a single task and send result back to Telegram."""
        context = self._task_context.pop(task_id, None)
        event = context[0] if context else None
        participants = context[1] if context else []
        access_result = self._task_access.pop(task_id, None)

        # Show typing while working
        await self._set_typing(chat_id)

        on_plan = self._send_plan_approval if self.bot_client else None

        try:
            result = await self.runner.run(
                task_id=task_id,
                chat_id=chat_id,
                message_id=message_id,
                prompt=prompt,
                on_progress=self._send_progress,
                on_text=self._send_intermediate_text,
                project_dir=project_dir,
                model=model,
                thinking=thinking,
                task_type=task_type,
                team=team,
                fork_session=fork_session,
                on_plan=on_plan,
                access=access_result,
            )

            # Update DB with result
            if result.success:
                self.task_queue.complete(task_id, result.output, result.cost_usd)
            elif result.was_timeout:
                self.task_queue.fail(task_id, f"Timeout after {int(result.duration)}s", result.output)
            else:
                self.task_queue.fail(task_id, result.error, result.output)

            # Clean up progress message
            await self._cleanup_progress(task_id, chat_id)

            # Send result
            if event:
                await self._send_result(event, result, participants, task_id)
            else:
                # No event context (shouldn't happen normally, but safe fallback)
                await self._send_result_to_chat(chat_id, message_id, result, participants, task_id)

        except Exception:
            logger.exception("Error running task #%d", task_id)
            self.task_queue.fail(task_id, "Internal error")
            await self._cleanup_progress(task_id, chat_id)

    # ── Chat participants & context ──────────────────────────────────

    async def _get_participants(self, chat_id: int) -> list[ChatParticipant]:
        """Get chat participants with caching."""
        cached = self._participants_cache.get(chat_id)
        if cached and (time.time() - cached.fetched_at) < PARTICIPANTS_CACHE_TTL:
            return cached.participants

        participants: list[ChatParticipant] = []
        try:
            async for user in self.client.iter_participants(chat_id, limit=200):
                if user.bot or user.id == self._my_id:
                    continue
                participants.append(ChatParticipant(
                    user_id=user.id,
                    first_name=user.first_name or "",
                    last_name=user.last_name or "",
                    username=(user.username or "").lower(),
                ))
            self._participants_cache[chat_id] = CachedParticipants(
                participants=participants,
                fetched_at=time.time(),
            )
            logger.debug("Cached %d participants for chat %s", len(participants), chat_id)
        except Exception:
            logger.debug("Could not fetch participants for chat %s", chat_id, exc_info=True)
            if cached:
                return cached.participants

        return participants

    def _build_chat_context(self, participants: list[ChatParticipant], is_private: bool) -> str:
        """Build a context string about chat participants for the prompt."""
        if is_private or not participants:
            return ""

        lines = ["Участники чата:"]
        for p in participants:
            tag = f"@{p.username}" if p.username else f"(нет username, id:{p.user_id})"
            lines.append(f"  - {p.display_name} {tag}")

        lines.append("")
        lines.append(
            "Чтобы упомянуть человека, используй @username. "
            "Чтобы написать кому-то в ЛС, оберни текст: [DM @username]текст[/DM] — "
            "бридж перехватит и отправит личное сообщение."
        )
        return "\n".join(lines)

    def _find_participant(
        self, query: str, participants: list[ChatParticipant]
    ) -> ChatParticipant | None:
        """Find a participant by username or first name (fuzzy)."""
        query_lower = query.lower().lstrip("@")
        # Exact username match
        for p in participants:
            if p.username and p.username == query_lower:
                return p
        # First name match
        for p in participants:
            if p.first_name.lower() == query_lower:
                return p
        # Partial name match
        for p in participants:
            if query_lower in p.display_name.lower():
                return p
        return None

    # ── DM processing ────────────────────────────────────────────────

    async def _resolve_user(self, username: str) -> int | None:
        """Resolve a username to a user ID via Telethon API (fallback when not in participants cache)."""
        try:
            entity = await self.client.get_entity(username if username.startswith("@") else f"@{username}")
            if isinstance(entity, User):
                logger.info("Resolved @%s to user_id=%s via get_entity", username, entity.id)
                return entity.id
        except Exception:
            logger.debug("Could not resolve @%s via get_entity", username, exc_info=True)
        return None

    async def _send_file_to_chat(
        self,
        chat_id: int,
        file_path: str,
        caption: str | None = None,
        reply_to_msg_id: int | None = None,
    ) -> bool:
        """Send a file to Telegram chat. Returns True on success."""
        path = Path(file_path)
        if not path.exists():
            logger.warning("File not found for sending: %s", file_path)
            return False

        if not path.is_file():
            logger.warning("Not a file: %s", file_path)
            return False

        # Check file size
        size_mb = path.stat().st_size / (1024 * 1024)
        if size_mb > MAX_UPLOAD_SIZE_MB:
            logger.warning("File too large to upload (%d MB): %s", int(size_mb), file_path)
            return False

        try:
            await self.client.send_file(
                chat_id,
                file=str(path),
                caption=caption or None,
                reply_to=reply_to_msg_id,
                parse_mode="html",
            )
            logger.info("Sent file to chat %s: %s (%.1f MB)", chat_id, file_path, size_mb)
            return True
        except Exception:
            logger.exception("Failed to send file %s to chat %s", file_path, chat_id)
            return False

    async def _send_dm_with_files(
        self,
        target_id: int,
        target_display: str,
        dm_body: str,
    ) -> str | None:
        """Send a DM that may contain [FILE] directives. Returns error string or None."""
        dm_files = FILE_PATTERN.findall(dm_body)
        dm_text = FILE_PATTERN.sub("", dm_body).strip()

        try:
            if dm_text:
                await self.client.send_message(target_id, dm_text)
                logger.info("Sent DM text to %s (%s)", target_display, target_id)

            for file_path, caption in dm_files:
                file_path = file_path.strip()
                caption = caption.strip() if caption else None
                success = await self._send_file_to_chat(
                    target_id, file_path, caption=caption,
                )
                if not success:
                    return f"⚠️ Не удалось отправить файл {file_path} для {target_display}"

            return None
        except Exception:
            logger.exception("Failed to send DM to %s", target_display)
            return f"⚠️ Не удалось отправить ЛС для {target_display}"

    async def _process_and_send_response(
        self,
        chat_id: int,
        reply_to_msg_id: int,
        text: str,
        participants: list[ChatParticipant],
    ) -> None:
        """Process Claude's response: extract DM and FILE directives, then send the rest to chat."""
        # Extract DM blocks
        dm_blocks = DM_PATTERN.findall(text)
        clean_text = DM_PATTERN.sub("", text).strip()

        # Extract file directives (strip [FILE] from DM bodies too — files only go to chat)
        file_blocks = FILE_PATTERN.findall(clean_text)
        clean_text = FILE_PATTERN.sub("", clean_text).strip()

        # Deduplicate files by path (Claude sometimes repeats the same directive)
        seen_paths: set[str] = set()
        unique_files: list[tuple[str, str]] = []
        for file_path, caption in file_blocks:
            fp = file_path.strip()
            if fp not in seen_paths:
                seen_paths.add(fp)
                unique_files.append((fp, caption))

        # Process DMs (may contain [FILE] directives inside)
        dm_status: list[str] = []
        for target_name, dm_body in dm_blocks:
            dm_body = dm_body.strip()
            if not dm_body:
                continue
            participant = self._find_participant(target_name, participants)
            if participant:
                target_id = participant.user_id
                target_display = participant.display_name
            else:
                target_id = await self._resolve_user(target_name)
                target_display = f"@{target_name.lstrip('@')}"

            if target_id:
                has_files = bool(FILE_PATTERN.search(dm_body))
                error = await self._send_dm_with_files(target_id, target_display, dm_body)
                if error:
                    dm_status.append(error)
                else:
                    what = "файл отправлен" if has_files else "ЛС отправлено"
                    dm_status.append(f"✅ {what} {target_display}")
            else:
                logger.warning("Could not find user '%s' for DM", target_name)
                dm_status.append(f"⚠️ Не нашёл пользователя {target_name} для ЛС")

        if dm_status:
            clean_text += ("\n\n" if clean_text else "") + "\n".join(dm_status)

        if not clean_text:
            if unique_files:
                pass  # Only files, no text needed
            else:
                clean_text = "(пустой ответ)"

        # Send main text response to chat
        if clean_text:
            await self._set_typing(chat_id)
            parts = split_for_telegram(clean_text)
            for i, part in enumerate(parts):
                sent = await self.client.send_message(
                    chat_id,
                    part,
                    reply_to=reply_to_msg_id if i == 0 else None,
                    parse_mode="html",
                )
                if i > 0:
                    await asyncio.sleep(0.5)
                if sent:
                    self._my_sent_messages.append((chat_id, sent.id))

        # Send files to chat (deduplicated, never to DMs)
        for file_path, caption in unique_files:
            caption = caption.strip() if caption else None
            success = await self._send_file_to_chat(
                chat_id, file_path, caption=caption, reply_to_msg_id=reply_to_msg_id,
            )
            if not success:
                err_msg = f"⚠️ Не удалось отправить файл: {file_path}"
                sent = await self.client.send_message(
                    chat_id, err_msg, reply_to=reply_to_msg_id,
                )
                if sent:
                    self._my_sent_messages.append((chat_id, sent.id))

    async def _mark_read(self, event: events.NewMessage.Event) -> None:
        """Mark message as read."""
        try:
            await self.client.send_read_acknowledge(event.chat_id, event.message)
        except Exception:
            logger.debug("Could not mark message as read", exc_info=True)

    async def _set_typing(self, chat_id: int) -> None:
        """Send 'typing' action to chat."""
        try:
            from telethon.tl.functions.messages import SetTypingRequest
            from telethon.tl.types import SendMessageTypingAction
            await self.client(SetTypingRequest(
                peer=chat_id,
                action=SendMessageTypingAction(),
            ))
        except Exception:
            logger.debug("Could not set typing action", exc_info=True)

    async def _on_new_message(self, event: events.NewMessage.Event) -> None:
        """Handle incoming messages."""
        # Ignore own messages
        if event.sender_id == self._my_id:
            return

        # Check allowed chats (if configured)
        if self.config.allowed_chats and event.chat_id not in self.config.allowed_chats:
            return

        # Mark message as read
        await self._mark_read(event)

        text = (event.raw_text or "").strip()

        # Download media attachments (before text check — media-only messages are valid)
        media_files = await self._download_media(event)

        # Transcribe voice messages
        voice_transcript = None
        if media_files and self._is_voice_message(event):
            voice_transcript = await self._transcribe_voice(media_files[0])
            if voice_transcript:
                # Voice becomes text — don't pass audio file to Claude
                media_files = []
                if text:
                    text = text + "\n\n[Голосовое сообщение]: " + voice_transcript
                else:
                    text = "[Голосовое сообщение]: " + voice_transcript
                logger.info("Voice transcribed: %.100s", voice_transcript)

        if not text and not media_files:
            return

        if not text:
            text = "(see attached file)"

        # Handle commands
        if text.lower().startswith(CMD_CANCEL):
            await self._handle_cancel(event, text)
            return
        if text.lower() == CMD_STATUS:
            await self._handle_status(event)
            return
        if text.lower() == CMD_HELP:
            await self._handle_help(event)
            return
        if text.lower() == CMD_NEW:
            await self._handle_new(event)
            return

        # In private chats — respond to everything, no trigger needed
        # In group chats — only respond when addressed
        if not event.is_private and not await self._is_addressed_to_me(event, text):
            return

        # Extract the actual prompt (remove trigger word in groups, raw text in DMs)
        prompt = text if event.is_private else self._extract_prompt(text)
        if not prompt:
            return

        # Check for modifiers: /model, /think, /task_type
        model, thinking, task_type, team, prompt = self._extract_modifiers(prompt)

        # Team mode incompatible with Kimi (no internal team orchestration)
        if team and model == "kimi":
            team = False

        # If task type has a default model and user didn't specify one, use it
        if task_type and not model:
            from .prompt_router import get_default_model
            auto_model = get_default_model(task_type)
            if auto_model:
                model = auto_model

        # ── RESOLVE PROJECT FROM CHAT BINDING ────────────────────────
        project_dir = None
        if self.access_mgr:
            project_dir = self.access_mgr.get_chat_project(event.chat_id)
            # Treat "*" binding as "all projects" (no specific project)
            if project_dir == "*":
                project_dir = None
            if not project_dir:
                # Users with wildcard access can work without project binding
                user = self.access_mgr.get_user(event.sender_id)
                if not user or "*" not in user.allowed_projects:
                    await event.reply(
                        "⚠️ Этот чат не привязан к проекту. "
                        "Обратитесь к администратору для настройки."
                    )
                    return
                # project_dir stays None → cwd = work_dir (all projects visible)
        # ─────────────────────────────────────────────────────────────

        # ── ACCESS CONTROL GATE ──────────────────────────────────────
        access_result = None
        if self.access_mgr:
            access_result = self.access_mgr.check_access(
                telegram_id=event.sender_id,
                project=project_dir,
                model=model,
            )
            if not access_result.allowed:
                await event.reply(f"⛔ {access_result.reason}")
                logger.warning(
                    "Access denied: user=%s chat=%s reason=%s",
                    event.sender_id, event.chat_id, access_result.reason,
                )
                return
            # Downgrade model if role doesn't allow it
            if access_result.effective_model and access_result.effective_model != model:
                logger.info("Model downgrade: %s → %s for user %s",
                            model, access_result.effective_model, event.sender_id)
                model = access_result.effective_model
        # ─────────────────────────────────────────────────────────────

        # Fetch chat participants for context & DM resolution
        participants = await self._get_participants(event.chat_id) if not event.is_private else []

        # Enrich prompt with chat context so Claude knows who's in the chat
        chat_context = self._build_chat_context(participants, event.is_private)

        # Get sender info
        sender = await event.get_sender()
        sender_name = ""
        if isinstance(sender, User):
            sender_name = (sender.first_name or "") + (" " + (sender.last_name or "")).rstrip()

        # Build media context
        media_context = self._build_media_context(media_files)

        # In group chats, fetch recent messages to capture other participants' context
        # (In private chats Claude's session already has the full conversation)
        recent_context = await self._get_recent_chat_messages(event) if not event.is_private else ""

        # Build full prompt with context
        context_parts = []
        if sender_name:
            context_parts.append(f"Сообщение от: {sender_name}")
        if chat_context:
            context_parts.append(chat_context)
        if recent_context:
            context_parts.append(recent_context)
        if media_context:
            context_parts.append(media_context)

        if context_parts:
            full_prompt = "\n".join(context_parts) + "\n\nЗапрос: " + prompt
        else:
            full_prompt = prompt

        logger.info(
            "Task from chat=%s user=%s project=%s: %.100s",
            event.chat_id,
            event.sender_id,
            project_dir or "(default)",
            prompt,
        )

        # Check if chat already has running tasks — offer queue vs new session
        running = self.runner.get_running_tasks_for_chat(event.chat_id)
        if running and self.bot_client:
            await self._ask_queue_or_new_session(
                event, full_prompt, project_dir, model, thinking,
                task_type, team, sender_name, participants,
            )
            return

        # Enqueue the task into SQLite
        task_id = self.task_queue.enqueue(
            chat_id=event.chat_id,
            message_id=event.id,
            sender_name=sender_name,
            prompt=full_prompt,
            project_dir=project_dir,
            model=model,
            thinking=thinking,
            task_type=task_type,
            team=team,
            sender_id=event.sender_id,
        )

        # Store context for when the worker picks it up
        self._task_context[task_id] = (event, participants)
        if access_result:
            self._task_access[task_id] = access_result

        # Notify user
        pending = self.task_queue.get_pending_for_chat(event.chat_id)
        running = self.runner.get_running_tasks_for_chat(event.chat_id)

        if not running and len(pending) <= 1:
            # Will be picked up immediately — no need for queue notification
            logger.info("Task #%d will be picked up shortly", task_id)
        else:
            # There are other tasks — let user know about the queue
            queue_pos = len(pending)
            running_count = len(running)
            parts = [f"📥 Задача #{task_id} в очереди."]
            if running_count > 0:
                parts.append(f"Сейчас выполняется: {running_count}")
            if queue_pos > 1:
                parts.append(f"В очереди перед вами: {queue_pos - 1}")
            await event.reply("\n".join(parts))

    async def _ask_queue_or_new_session(
        self,
        event: events.NewMessage.Event,
        prompt: str,
        project_dir: str | None,
        model: str | None,
        thinking: bool,
        task_type: str | None,
        team: bool,
        sender_name: str,
        participants: list[ChatParticipant],
    ) -> None:
        """Ask user whether to queue or start a parallel session via bot buttons."""
        pending_key = f"qchoice:{event.chat_id}:{event.id}"
        self._pending_queue_choices[pending_key] = {
            "event": event,
            "prompt": prompt,
            "project_dir": project_dir,
            "model": model,
            "thinking": thinking,
            "task_type": task_type,
            "team": team,
            "sender_name": sender_name,
            "participants": participants,
            "sender_id": event.sender_id,
        }

        running = self.runner.get_running_tasks_for_chat(event.chat_id)
        running_info = ", ".join(f"#{t.task_id}" for t in running)

        buttons = [[
            Button.inline("📥 В очередь", f"queue:{event.chat_id}:{event.id}".encode()),
            Button.inline("🆕 Новая сессия", f"newsess:{event.chat_id}:{event.id}".encode()),
        ]]

        await self.bot_client.send_message(
            event.chat_id,
            f"⏳ Выполняется: {running_info}\n"
            f"Поставить в очередь или запустить параллельно?",
            reply_to=event.id,
            buttons=buttons,
        )

        # Auto-queue after 2 minutes if no choice made
        loop = asyncio.get_running_loop()

        def _auto_queue():
            choice_data = self._pending_queue_choices.pop(pending_key, None)
            self._queue_choice_timeouts.pop(pending_key, None)
            if choice_data:
                asyncio.ensure_future(self._auto_queue_task(choice_data, event))

        handle = loop.call_later(120, _auto_queue)
        self._queue_choice_timeouts[pending_key] = handle

    async def _auto_queue_task(self, choice_data: dict, event: events.NewMessage.Event) -> None:
        """Auto-queue a task after timeout (user didn't click a button)."""
        task_id = self.task_queue.enqueue(
            chat_id=event.chat_id,
            message_id=event.id,
            sender_name=choice_data["sender_name"],
            prompt=choice_data["prompt"],
            project_dir=choice_data["project_dir"],
            model=choice_data["model"],
            thinking=choice_data["thinking"],
            task_type=choice_data["task_type"],
            team=choice_data["team"],
            sender_id=choice_data.get("sender_id"),
        )
        self._task_context[task_id] = (choice_data["event"], choice_data["participants"])
        logger.info("Auto-queued task #%d after timeout", task_id)

    async def _is_addressed_to_me(self, event: events.NewMessage.Event, text: str) -> bool:
        """Check if the message is addressed to Claude."""
        # 1. Reply to one of my messages
        if event.is_reply:
            try:
                reply_msg = await event.get_reply_message()
                if reply_msg and reply_msg.sender_id == self._my_id:
                    return True
                # Also check our tracked messages
                if event.reply_to and hasattr(event.reply_to, 'reply_to_msg_id'):
                    key = (event.chat_id, event.reply_to.reply_to_msg_id)
                    if key in self._my_sent_messages:
                        return True
            except Exception:
                logger.debug("Could not fetch reply message", exc_info=True)

        # 2. Starts with a /model or /team shortcut (acts as implicit trigger)
        _MODEL_TRIGGERS = {"/o ", "/s ", "/h ", "/k ", "/t ",
                           "/opus ", "/sonnet ", "/haiku ", "/kimi ", "/team ",
                           "/o\n", "/s\n", "/h\n", "/k\n", "/t\n",
                           "/opus\n", "/sonnet\n", "/haiku\n", "/kimi\n", "/team\n"}
        cleaned = re.sub(r'^[,.\s!?]+', '', text.lower())
        for mt in _MODEL_TRIGGERS:
            if cleaned.startswith(mt):
                return True

        # 3. Contains a trigger word at the start
        text_lower = text.lower()
        for trigger in self.config.triggers:
            # Check if message starts with trigger (possibly after punctuation)
            cleaned = re.sub(r'^[,.\s!?]+', '', text_lower)
            if cleaned.startswith(trigger):
                return True

        # 3. Mentions by @username
        if self._my_username and f"@{self._my_username}" in text_lower:
            return True

        # 4. Mentions by display name
        if self._my_name and self._my_name.lower() in text_lower:
            return True

        return False

    def _extract_prompt(self, text: str) -> str:
        """Remove trigger word from the beginning and return the actual prompt."""
        text_lower = text.lower()
        for trigger in self.config.triggers:
            cleaned_lower = re.sub(r'^[,.\s!?]+', '', text_lower)
            if cleaned_lower.startswith(trigger):
                # Find the trigger in original text (case-insensitive)
                idx = text_lower.find(trigger)
                if idx >= 0:
                    after = text[idx + len(trigger):]
                    # Strip common separators: ", ", ": ", " - ", etc.
                    after = re.sub(r'^[\s,:\-!?]+', '', after)
                    return after.strip()

        # No trigger found — return as-is (message may have been triggered by /model shortcut)
        return text.strip()

    def _extract_modifiers(self, prompt: str) -> tuple[str | None, bool, str | None, bool, str]:
        """Extract modifiers from prompt: model, thinking, task type, team.

        Syntax: /modifier at the start of the prompt.
          /haiku / /sonnet / /opus                         — model selection
          /думай / /think                                  — enable extended thinking
          /review / /commit / /investigate / /analyze / /refactor  — magic prompt

        Project is resolved from chat→project binding (not from prompt).

        Returns: (model, thinking, task_type, team, cleaned_prompt)
        """
        from .prompt_router import resolve_alias

        MODEL_ALIASES = {
            "haiku": "haiku", "h": "haiku",
            "sonnet": "sonnet", "s": "sonnet",
            "opus": "opus", "o": "opus",
            "kimi": "kimi", "k": "kimi",
        }
        THINKING_KEYWORDS = {"думай", "think"}
        TEAM_KEYWORDS = {"team", "t", "команда"}

        model = None
        thinking = False
        task_type = None
        team = False

        # Parse /slash modifiers from the start of prompt
        while True:
            prompt = prompt.lstrip()

            # /modifier
            slash_match = re.match(r'^/([a-zA-Zа-яА-ЯёЁ0-9_]+)\s*(.*)', prompt, re.DOTALL)
            if slash_match:
                tag = slash_match.group(1).lower()
                if tag in MODEL_ALIASES:
                    model = MODEL_ALIASES[tag]
                    prompt = slash_match.group(2)
                    continue
                elif tag in THINKING_KEYWORDS:
                    thinking = True
                    prompt = slash_match.group(2)
                    continue
                elif tag in TEAM_KEYWORDS:
                    team = True
                    prompt = slash_match.group(2)
                    continue
                else:
                    resolved = resolve_alias(tag)
                    if resolved:
                        task_type = resolved
                        prompt = slash_match.group(2)
                        continue
                # Unknown /slash — don't consume, it's part of the prompt

            break

        return model, thinking, task_type, team, prompt.strip()

    # ── Media handling ─────────────────────────────────────────────────

    async def _download_media(self, event: events.NewMessage.Event) -> list[str]:
        """Download media attachments from a message. Returns list of file paths."""
        if not event.media:
            return []

        # Skip unsupported media types
        if isinstance(event.media, MessageMediaPhoto):
            # Photos are always supported (screenshots, images)
            pass
        elif isinstance(event.media, MessageMediaDocument):
            doc = event.media.document
            if not doc:
                return []

            # Skip stickers and video circles (voice messages are handled via transcription)
            for attr in doc.attributes:
                if isinstance(attr, DocumentAttributeSticker):
                    logger.debug("Skipping sticker")
                    return []
                if isinstance(attr, DocumentAttributeVideo) and attr.round_message:
                    logger.debug("Skipping video circle")
                    return []

            # Check file size
            if doc.size and doc.size > MAX_MEDIA_SIZE_MB * 1024 * 1024:
                logger.info("Skipping large file (%d MB)", doc.size // (1024 * 1024))
                return []
        else:
            # Other media types (geo, contact, etc.) — skip
            return []

        # Ensure media directory exists
        MEDIA_DIR.mkdir(parents=True, exist_ok=True)

        try:
            # Download the file
            path = await self.client.download_media(
                event.media,
                file=str(MEDIA_DIR) + "/",
            )
            if path:
                logger.info("Downloaded media: %s", path)
                return [path]
        except Exception:
            logger.exception("Failed to download media from message %s", event.id)

        return []

    def _is_voice_message(self, event: events.NewMessage.Event) -> bool:
        """Check if the message contains a voice message or audio."""
        if not isinstance(event.media, MessageMediaDocument):
            return False
        doc = event.media.document
        if not doc:
            return False
        for attr in doc.attributes:
            if isinstance(attr, DocumentAttributeAudio) and attr.voice:
                return True
        return False

    async def _transcribe_voice(self, audio_path: str) -> str | None:
        """Transcribe a voice message. Returns text or None on failure."""
        try:
            text = await transcriber.transcribe(audio_path)
            return text if text.strip() else None
        except Exception:
            logger.exception("Failed to transcribe voice message: %s", audio_path)
            return None

    async def _get_recent_chat_messages(self, event: events.NewMessage.Event) -> str:
        """Fetch last N messages from the chat for context.

        Gives Claude awareness of the full conversation including messages
        from other participants that weren't addressed to Claude.
        """
        RECENT_MSG_LIMIT = 50
        MAX_MSG_LEN = 400

        try:
            # Fetch recent messages (before current), newest first
            messages = await self.client.get_messages(
                event.chat_id,
                limit=RECENT_MSG_LIMIT,
                max_id=event.id,
            )

            if not messages:
                return ""

            lines: list[str] = []
            for msg in reversed(messages):  # chronological order
                text = (msg.raw_text or "").strip()

                # Describe media-only messages
                if not text and msg.media:
                    if isinstance(msg.media, MessageMediaDocument):
                        text = "(файл)"
                    elif isinstance(msg.media, MessageMediaPhoto):
                        text = "(фото)"
                    else:
                        text = "(медиа)"

                if not text:
                    continue

                if len(text) > MAX_MSG_LEN:
                    text = text[:MAX_MSG_LEN] + "..."

                # Author
                sender = await msg.get_sender()
                author = ""
                if isinstance(sender, User):
                    if sender.id == self._my_id:
                        author = "Claude"
                    elif sender.username:
                        author = f"@{sender.username}"
                    else:
                        author = (sender.first_name or "?")

                lines.append(f"{author}: {text}" if author else text)

            if not lines:
                return ""

            return f"Последние сообщения в чате ({len(lines)}):\n" + "\n".join(lines)

        except Exception:
            logger.debug("Could not fetch recent chat messages", exc_info=True)
            return ""

    def _build_media_context(self, file_paths: list[str]) -> str:
        """Build prompt context describing attached files."""
        if not file_paths:
            return ""

        lines = []
        for fp in file_paths:
            p = Path(fp)
            ext = p.suffix.lower()

            if ext in SUPPORTED_IMAGE_EXTS:
                lines.append(
                    f"К сообщению прикреплено изображение: {fp}\n"
                    f"Используй Read tool чтобы посмотреть его."
                )
            elif ext == ".pdf":
                lines.append(
                    f"К сообщению прикреплён PDF: {fp}\n"
                    f"Используй Read tool чтобы прочитать его."
                )
            elif ext in SUPPORTED_DOC_EXTS:
                lines.append(
                    f"К сообщению прикреплён файл: {fp}\n"
                    f"Используй Read tool чтобы прочитать его."
                )
            else:
                lines.append(
                    f"К сообщению прикреплён файл: {fp}\n"
                    f"Попробуй прочитать его через Read tool если формат поддерживается."
                )

        return "\n".join(lines)

    # ── Progress (per task, reply-linked) ────────────────────────────

    async def _send_intermediate_text(self, task: RunningTask, text: str) -> None:
        """Send or edit the intermediate text message (one per task, keeps updating)."""
        try:
            content = truncate_for_telegram(f"💬 {text}")
            existing_msg_id = self._intermediate_messages.get(task.task_id)
            if existing_msg_id:
                # Edit existing message
                await self.client.edit_message(
                    task.chat_id,
                    existing_msg_id,
                    content,
                )
            else:
                # Send first intermediate message (reply to original)
                msg = await self.client.send_message(
                    task.chat_id,
                    content,
                    reply_to=task.message_id,
                )
                self._intermediate_messages[task.task_id] = msg.id
        except Exception:
            logger.debug("Failed to send intermediate text for task #%d", task.task_id)

    async def _send_progress(self, task: RunningTask, progress_text: str) -> None:
        """Send or update a progress message for a specific task."""
        # Keep typing indicator alive
        await self._set_typing(task.chat_id)

        # Use bot client with cancel button if available
        send_client = self.bot_client or self.client
        buttons = None
        if self.bot_client:
            buttons = [Button.inline("🛑 Cancel", f"cancel:{task.task_id}".encode())]

        try:
            existing_msg_id = self._progress_messages.get(task.task_id)
            if existing_msg_id:
                # Edit existing progress message
                await send_client.edit_message(
                    task.chat_id,
                    existing_msg_id,
                    truncate_for_telegram(progress_text),
                    buttons=buttons,
                )
            else:
                # Send new progress message (reply to original)
                msg = await send_client.send_message(
                    task.chat_id,
                    truncate_for_telegram(progress_text),
                    reply_to=task.message_id,
                    buttons=buttons,
                )
                self._progress_messages[task.task_id] = msg.id
        except Exception:
            logger.exception("Failed to send progress for task #%d", task.task_id)

    async def _cleanup_progress(self, task_id: int, chat_id: int) -> None:
        """Delete progress and intermediate text messages after task completion."""
        # Progress messages may have been sent by bot_client
        progress_client = self.bot_client or self.client
        msg_id = self._progress_messages.pop(task_id, None)
        if msg_id:
            try:
                await progress_client.delete_messages(chat_id, [msg_id])
            except Exception:
                logger.debug("Could not delete progress message %s for task #%d", msg_id, task_id)
        # Intermediate text messages are always sent by userbot
        imsg_id = self._intermediate_messages.pop(task_id, None)
        if imsg_id:
            try:
                await self.client.delete_messages(chat_id, [imsg_id])
            except Exception:
                logger.debug("Could not delete intermediate message %s for task #%d", imsg_id, task_id)

    # ── Results ──────────────────────────────────────────────────────

    async def _send_result(
        self,
        event: events.NewMessage.Event,
        result: TaskResult,
        participants: list[ChatParticipant],
        task_id: int,
    ) -> None:
        """Send the final result to the chat with DM and mention support."""
        body = self._format_result(result, task_id)
        await self._process_and_send_response(event.chat_id, event.id, body, participants)

    async def _send_result_to_chat(
        self,
        chat_id: int,
        message_id: int,
        result: TaskResult,
        participants: list[ChatParticipant],
        task_id: int,
    ) -> None:
        """Send result when we don't have the original event (fallback)."""
        body = self._format_result(result, task_id)
        await self._process_and_send_response(chat_id, message_id, body, participants)

    def _format_result(self, result: TaskResult, task_id: int) -> str:
        """Format a TaskResult into a message body."""
        if result.success:
            body = result.output or "(пустой ответ)"
        elif result.was_timeout:
            elapsed = int(result.duration)
            body = result.output or ""
            body += f"\n\n⏰ Таймаут ({elapsed}s)"
            if result.error:
                body += f"\n⚠️ {result.error}"
        else:
            body = ""
            if result.output:
                body += result.output
            if result.error:
                if body:
                    body += "\n\n"
                body += f"⚠️ {result.error}"
            if not body.strip():
                body = "⚠️ Что-то пошло не так, попробуй ещё раз."

        # Model badge
        if result.model:
            MODEL_BADGES = {
                "opus": "⚡ opus",
                "sonnet": "🟢 sonnet",
                "haiku": "🔵 haiku",
                "kimi": "🟠 kimi",
            }
            badge = MODEL_BADGES.get(result.model, f"🤖 {result.model}")
            body = body.strip() + f"\n\n{badge}"

        return body.strip()

    # ── Commands ──────────────────────────────────────────────────────

    async def _handle_cancel(self, event: events.NewMessage.Event, text: str = "") -> None:
        """Handle /cancel command.

        /cancel — cancel all tasks in this chat
        /cancel <id> — cancel a specific task by ID
        """
        parts = text.strip().split()
        # /cancel <id> — cancel specific task
        if len(parts) >= 2 and parts[1].isdigit():
            task_id = int(parts[1])
            # Try in-memory first (running task — instant cancel)
            task = self.runner.get_active_task_by_id(task_id)
            if task and task.chat_id == event.chat_id:
                await self.runner.cancel_task_by_id(task_id)
                await self._cleanup_progress(task_id, event.chat_id)
                await event.reply(f"🛑 Задача #{task_id} остановлена")
                return
            # Try pending task in DB
            queued = self.task_queue.get_task(task_id)
            if queued and queued.chat_id == event.chat_id and queued.status.value == "pending":
                self.task_queue.cancel(task_id)
                await event.reply(f"🛑 Задача #{task_id} убрана из очереди")
                return
            await event.reply(f"Задача #{task_id} не найдена или уже завершена.")
            return

        # /cancel — cancel all tasks in this chat
        cancelled = await self.runner.cancel_all_for_chat(event.chat_id)
        if cancelled > 0:
            # Clean up progress messages for all tasks in this chat
            task_ids_to_clean = [
                tid for tid, mid in list(self._progress_messages.items())
            ]
            for tid in task_ids_to_clean:
                await self._cleanup_progress(tid, event.chat_id)
            await event.reply(f"🛑 Отменено задач: {cancelled}")
        else:
            await event.reply("Нет активных задач в этом чате.")

    async def _handle_status(self, event: events.NewMessage.Event) -> None:
        """Handle /status command — shows all active tasks for this chat."""
        running = self.runner.get_running_tasks_for_chat(event.chat_id)
        pending = self.task_queue.get_pending_for_chat(event.chat_id)

        if not running and not pending:
            await event.reply("Нет активных задач.")
            return

        lines = []

        if running:
            lines.append(f"🔄 Выполняется ({len(running)}):")
            for task in running:
                elapsed = int(task.elapsed)
                minutes = elapsed // 60
                seconds = elapsed % 60
                time_str = f"{minutes}m {seconds}s" if minutes > 0 else f"{seconds}s"
                prompt_short = task.prompt[:80] + "..." if len(task.prompt) > 80 else task.prompt
                # Strip context prefix for display
                if "Запрос: " in prompt_short:
                    prompt_short = prompt_short.split("Запрос: ", 1)[1]
                lines.append(f"  #{task.task_id} — {time_str}, шаг {task.turn_count}")
                lines.append(f"  📝 {prompt_short}")
                if task.recent_events:
                    lines.append(f"  └ {task.recent_events[-1]}")
                lines.append("")

        if pending:
            lines.append(f"📥 В очереди ({len(pending)}):")
            for qt in pending:
                prompt_short = qt.prompt[:80] + "..." if len(qt.prompt) > 80 else qt.prompt
                if "Запрос: " in prompt_short:
                    prompt_short = prompt_short.split("Запрос: ", 1)[1]
                wait = int(time.time() - qt.created_at)
                lines.append(f"  #{qt.id} — ждёт {wait}s")
                lines.append(f"  📝 {prompt_short}")
                lines.append("")

        lines.append("/cancel — отменить всё, /cancel <id> — конкретную")
        await event.reply("\n".join(lines).rstrip())

    async def _handle_new(self, event: events.NewMessage.Event) -> None:
        """Handle /new command — reset conversation session."""
        had = self.runner.clear_session(event.chat_id)
        if had:
            await event.reply("🔄 Сессия сброшена. Следующее сообщение начнёт новый разговор.")
        else:
            await event.reply("Активной сессии нет — и так начнём с чистого листа.")

    async def _handle_help(self, event: events.NewMessage.Event) -> None:
        """Handle /help command."""
        triggers = ", ".join(f"`{t}`" for t in self.config.triggers)
        await event.reply(
            "Claude в чате\n\n"
            f"Обращение: {triggers}\n"
            "В личке — отвечает на всё без триггера.\n\n"
            "-- Модификаторы (в начале запроса) --\n\n"
            "Модель:\n"
            "  /haiku /sonnet /opus\n\n"
            "Мышление:\n"
            "  /думай или /think — extended thinking\n\n"
            "Magic prompts (спец. системные инструкции):\n"
            "  /review (ревью, проревьюй) — code review, авто haiku\n"
            "  /commit (коммит, закоммить) — коммит, авто haiku\n"
            "  /investigate (расследуй, debug, дебаг) — расследование\n"
            "  /analyze (анализ, проанализируй) — анализ кода\n"
            "  /refactor (рефактор, отрефактори) — рефакторинг\n"
            "  Можно использовать любой алиас: /ревью = /review\n"
            "  Промпты настраиваются через админку (hot-reload).\n\n"
            "Проект:\n"
            "  Чат привязан к проекту администратором.\n"
            "  Все запросы выполняются в проекте чата.\n\n"
            "Комбинирование:\n"
            "  claude /opus /think /review проверь handler.py\n\n"
            "-- Команды --\n"
            "  /status — статус задач (с ID)\n"
            "  /cancel — отменить все задачи\n"
            "  /cancel <id> — отменить конкретную задачу\n"
            "  /new — сбросить сессию (новый разговор)\n"
            "  /help — эта справка\n\n"
            "-- Прочее --\n"
            "Сессия сохраняется — Claude помнит контекст (/new для сброса).\n"
            "Медиа: фото, документы, PDF, голосовые.\n"
            "Claude может упоминать @username и писать в ЛС.\n"
            "Файлы: попросите Claude отправить файл — он загрузит в чат.\n\n"
            "Примеры:\n"
            "  claude /opus /думай почему падает CI\n"
            "  claude /ревью проверь handler.py\n"
            "  @клод напиши @vadim в ЛС что готово"
        )
