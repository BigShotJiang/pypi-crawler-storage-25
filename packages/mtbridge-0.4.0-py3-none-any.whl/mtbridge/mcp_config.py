"""MCP server configuration — load/save/manage MCP servers.

Configuration stored as JSON file. Each server entry has:
- name: unique identifier
- type: "stdio" | "sse" | "http"
- command: executable path (for stdio)
- args: list of arguments (for stdio)
- env: environment variables dict (for stdio)
- url: endpoint URL (for sse/http)
- headers: HTTP headers dict (for sse/http)
- enabled: whether to include in SDK options
- always_on: if True, cannot be disabled (e.g. memory MCP)

Hot-reload: config is re-read on every build_mcp_servers() call,
so changes via admin panel take effect on the next task.
"""

import json
import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

CONFIG_PATH = Path(os.environ.get("WORK_DIR", "/home/claude")) / ".mtbridge_mcp_servers.json"

# Default configuration — memory MCP is always on
_DEFAULT_CONFIG: list[dict[str, Any]] = [
    {
        "name": "memory",
        "type": "stdio",
        "command": "python3",
        "args": [
            "/home/claude/memory-mcp/server.py",
            "/home/claude/projects/.mtbridge_memory.db",
            "/home/claude/.claude/projects/-home-claude-projects/memory",
        ],
        "env": {},
        "enabled": True,
        "always_on": True,
        "description": "Memory MCP — FTS5 search/add/delete/list/categories/sql",
    },
]


def _ensure_config() -> None:
    """Create default config file if it doesn't exist."""
    if not CONFIG_PATH.exists():
        CONFIG_PATH.write_text(
            json.dumps(_DEFAULT_CONFIG, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        logger.info("Created default MCP config at %s", CONFIG_PATH)


def load_servers() -> list[dict[str, Any]]:
    """Load all MCP server configs from JSON file.

    Re-reads file every time (hot-reload friendly).
    Returns default config on any error.
    """
    _ensure_config()
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            logger.warning("MCP config is not a list, using defaults")
            return list(_DEFAULT_CONFIG)
        return data
    except Exception:
        logger.exception("Failed to load MCP config from %s", CONFIG_PATH)
        return list(_DEFAULT_CONFIG)


def save_servers(servers: list[dict[str, Any]]) -> None:
    """Save MCP server configs to JSON file."""
    CONFIG_PATH.write_text(
        json.dumps(servers, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    logger.info("Saved %d MCP servers to %s", len(servers), CONFIG_PATH)


def get_enabled_servers() -> list[dict[str, Any]]:
    """Get only enabled servers."""
    return [s for s in load_servers() if s.get("enabled", True)]


def build_mcp_servers_dict() -> dict[str, dict[str, Any]]:
    """Build mcp_servers dict for ClaudeAgentOptions.

    Returns format expected by SDK:
    {
        "server_name": {
            "type": "stdio",
            "command": "...",
            "args": [...],
            "env": {...}
        },
        ...
    }
    """
    result = {}
    for server in get_enabled_servers():
        name = server.get("name", "")
        if not name:
            continue

        stype = server.get("type", "stdio")
        if stype == "stdio":
            entry: dict[str, Any] = {
                "command": server.get("command", ""),
                "args": server.get("args", []),
            }
            if server.get("env"):
                entry["env"] = server["env"]
        elif stype in ("sse", "http"):
            entry = {
                "type": stype,
                "url": server.get("url", ""),
            }
            if server.get("headers"):
                entry["headers"] = server["headers"]
        else:
            logger.warning("Unknown MCP server type: %s for %s", stype, name)
            continue

        result[name] = entry

    return result


def add_server(server: dict[str, Any]) -> None:
    """Add a new MCP server to config."""
    servers = load_servers()
    # Check for duplicate name
    name = server.get("name", "")
    for existing in servers:
        if existing.get("name") == name:
            raise ValueError(f"Server '{name}' already exists")
    servers.append(server)
    save_servers(servers)


def update_server(name: str, updates: dict[str, Any]) -> bool:
    """Update an existing MCP server. Returns True if found."""
    servers = load_servers()
    for server in servers:
        if server.get("name") == name:
            server.update(updates)
            save_servers(servers)
            return True
    return False


def delete_server(name: str) -> bool:
    """Delete an MCP server by name. Cannot delete always_on servers."""
    servers = load_servers()
    for server in servers:
        if server.get("name") == name:
            if server.get("always_on"):
                raise ValueError(f"Cannot delete always_on server '{name}'")
            servers.remove(server)
            save_servers(servers)
            return True
    return False


def toggle_server(name: str, enabled: bool) -> bool:
    """Enable or disable a server. Cannot disable always_on servers."""
    servers = load_servers()
    for server in servers:
        if server.get("name") == name:
            if server.get("always_on") and not enabled:
                raise ValueError(f"Cannot disable always_on server '{name}'")
            server["enabled"] = enabled
            save_servers(servers)
            return True
    return False


def health_check(name: str) -> dict[str, Any]:
    """Basic health check for a server — verify command/URL exists."""
    servers = load_servers()
    for server in servers:
        if server.get("name") != name:
            continue

        stype = server.get("type", "stdio")
        if stype == "stdio":
            cmd = server.get("command", "")
            args = server.get("args", [])
            # Check if command exists
            import shutil
            if not shutil.which(cmd):
                return {"status": "error", "message": f"Command not found: {cmd}"}
            # Check if script file exists (first arg that looks like a path)
            for arg in args:
                if arg.startswith("/") and not Path(arg).exists():
                    return {"status": "warning", "message": f"File not found: {arg}"}
            return {"status": "ok", "message": f"Command '{cmd}' found"}

        elif stype in ("sse", "http"):
            url = server.get("url", "")
            if not url:
                return {"status": "error", "message": "No URL configured"}
            return {"status": "ok", "message": f"URL configured: {url}"}

    return {"status": "error", "message": f"Server '{name}' not found"}
