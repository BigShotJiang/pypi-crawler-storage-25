"""TG Claude — Telegram ↔ Claude Code bridge.

Usage:
    python -m mtbridge          # Run the bot
    python -m mtbridge.auth     # Generate session string
"""

import asyncio
import logging
import os
import signal
import sys
from pathlib import Path

# Remove CLAUDECODE env var to prevent "nested session" errors
# (happens when bot is restarted from within a Claude Code session)
os.environ.pop("CLAUDECODE", None)
os.environ.pop("CLAUDE_CODE_ENTRYPOINT", None)

from telethon import TelegramClient
from telethon.sessions import StringSession

from .config import Config
from .sdk_runner import SDKRunner
from .handler import TelegramHandler
from .task_queue import TaskQueue
from .access import AccessManager
from .api import start_api_server


def setup_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    # Quiet noisy loggers
    logging.getLogger("telethon").setLevel(logging.WARNING)


async def main() -> None:
    try:
        config = Config.from_env()
    except ValueError as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        sys.exit(1)

    setup_logging(config.log_level)
    logger = logging.getLogger("mtbridge")
    logger.info("Starting TG Claude bridge...")
    logger.info("Work directory: %s", config.work_dir)
    logger.info("Claude CLI: %s", config.claude_cli)
    logger.info("Triggers: %s", config.triggers)
    if config.allowed_chats:
        logger.info("Allowed chats: %s", config.allowed_chats)
    else:
        logger.info("Allowed chats: ALL")

    # Ensure work directory exists
    config.work_dir.mkdir(parents=True, exist_ok=True)

    # Initialize SQLite task queue
    db_path = config.work_dir / ".mtbridge_tasks.db"
    task_queue = TaskQueue(db_path)
    logger.info("Task queue: %s", db_path)

    # Migrate sessions from old JSON file if it exists
    old_sessions_file = config.work_dir / ".mtbridge_sessions.json"
    if old_sessions_file.exists():
        _migrate_sessions(old_sessions_file, task_queue, logger)

    # Clean up old tasks
    task_queue.cleanup_old_tasks(max_age_days=30)

    # Create Telethon client with StringSession
    client = TelegramClient(
        StringSession(config.session),
        config.api_id,
        config.api_hash,
    )

    # Initialize access control (if enabled)
    access_mgr = None
    if config.access_control_enabled:
        access_mgr = AccessManager(task_queue._conn, projects_dir=str(config.work_dir))
        logger.info("Access control: ENABLED (users: %d, roles: %d)",
                     len(access_mgr.list_users()), len(access_mgr.list_roles()))
    else:
        logger.info("Access control: DISABLED (all users have full access)")

    if config.sandbox_enabled:
        script = config.sandbox_script or str(
            Path(__file__).resolve().parent / "scripts" / "sandbox-claude.sh"
        )
        logger.info("Sandbox: ENABLED (script: %s)", script)
    else:
        script = ""
        logger.info("Sandbox: DISABLED")

    # Create Claude SDK runner with full autonomy
    runner = SDKRunner(
        claude_cli=config.claude_cli,
        work_dir=config.work_dir,
        task_queue=task_queue,
        max_execution_time=config.max_execution_time,
        progress_interval=config.progress_interval,
        system_prompt=config.system_prompt,
        max_budget_usd=config.max_budget_usd,
        default_model=config.default_model,
        sandbox_enabled=config.sandbox_enabled,
        sandbox_script=script,
        access_mgr=access_mgr,
    )
    logger.info("Default model: %s", config.default_model)
    logger.info("Max execution time: %ds", config.max_execution_time)
    logger.info("Permission mode: bypassPermissions (SDK full autonomy)")

    # Create optional bot client for inline buttons
    bot_client = None
    if config.bot_token:
        bot_client = TelegramClient("bot", config.api_id, config.api_hash)
        logger.info("Bot client configured (inline buttons enabled)")

    # Create and setup handler
    handler = TelegramHandler(client, config, runner, task_queue, bot_client=bot_client, access_mgr=access_mgr)

    await client.start()
    if bot_client:
        await bot_client.start(bot_token=config.bot_token)
        me = await bot_client.get_me()
        logger.info("Bot client started as @%s", me.username)

    await handler.setup()
    handler.register()
    handler.start_worker()

    # Start RBAC API server
    api_port = int(os.environ.get("MTBRIDGE_API_PORT", "8800"))
    start_api_server(access_mgr, port=api_port, status={
        "agent": "mtbridge",
        "access_control": config.access_control_enabled,
        "sandbox": config.sandbox_enabled,
        "allowed_chats": config.allowed_chats,
        "triggers": config.triggers,
    })

    logger.info("TG Claude is running. Listening for messages...")

    # Recover tasks interrupted by previous crash/restart
    await handler.recover_tasks()

    # Graceful shutdown on SIGTERM/SIGINT
    shutdown_event = asyncio.Event()

    def _on_signal():
        logger.info("Received shutdown signal, stopping gracefully...")
        shutdown_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, _on_signal)

    # Run until disconnect or shutdown signal
    wait_tasks = [
        asyncio.create_task(client.run_until_disconnected()),
        asyncio.create_task(shutdown_event.wait()),
    ]
    if bot_client:
        wait_tasks.append(asyncio.create_task(bot_client.run_until_disconnected()))

    done, pending = await asyncio.wait(
        wait_tasks,
        return_when=asyncio.FIRST_COMPLETED,
    )

    # Graceful shutdown
    logger.info("Shutting down...")
    await handler.stop_worker()
    for p in pending:
        p.cancel()
    try:
        await client.disconnect()
    except Exception:
        pass
    if bot_client:
        try:
            await bot_client.disconnect()
        except Exception:
            pass
    task_queue.close()
    logger.info("Shutdown complete")


def _migrate_sessions(old_file, task_queue, logger):
    """One-time migration from old JSON sessions file to SQLite."""
    import json
    try:
        data = json.loads(old_file.read_text())
        migrated = 0
        for chat_id_str, session_id in data.items():
            task_queue.set_session(int(chat_id_str), session_id)
            migrated += 1
        old_file.rename(old_file.with_suffix(".json.bak"))
        logger.info("Migrated %d sessions from %s to SQLite", migrated, old_file)
    except Exception:
        logger.warning("Could not migrate old sessions file %s", old_file, exc_info=True)


def cli():
    """Entry point for console_scripts."""
    asyncio.run(main())


if __name__ == "__main__":
    cli()
