"""Generate a Telethon StringSession for the user account.

Usage:
    python -m mtbridge.auth

This will prompt for phone number and verification code,
then print the session string to paste into .env as TG_SESSION.
"""

import os
import sys

from dotenv import load_dotenv
from telethon.sync import TelegramClient
from telethon.sessions import StringSession

load_dotenv()


def main() -> None:
    api_id_raw = os.getenv("TG_API_ID")
    api_hash = os.getenv("TG_API_HASH")

    if not api_id_raw or not api_hash:
        print("ERROR: Set TG_API_ID and TG_API_HASH in .env first.")
        print("Get them from https://my.telegram.org")
        sys.exit(1)

    api_id = int(api_id_raw)

    print("Generating Telethon session string...")
    print("You will be prompted for your phone number and verification code.\n")

    with TelegramClient(StringSession(), api_id, api_hash) as client:
        session_string = client.session.save()
        print("\n" + "=" * 60)
        print("SUCCESS! Your session string:")
        print("=" * 60)
        print(session_string)
        print("=" * 60)
        print("\nPaste this into your .env file as TG_SESSION=<string>")
        print("KEEP IT SECRET — it grants full access to your account!")


if __name__ == "__main__":
    main()

