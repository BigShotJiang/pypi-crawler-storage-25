"""Package entrypoint for :mod:`sheetah-gui`.

The top-level ``main`` function is simply routed to the command‑line
implementation so installing the package and invoking ``sheetah-gui`` will
launch the interactive search UI.  Helper classes are re-exported here as a
convenience for programmatic use.
"""

from __future__ import annotations

from sheetah import Document, Segment
from . import gui

__all__ = ["Document", "Segment", "gui", "main"]


def main() -> None:
    """Run the graphical interface."""
    gui.main()