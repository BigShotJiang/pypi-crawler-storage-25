"""Graphical interface for searching documents created from Markdown."""

from __future__ import annotations
import sys
from pathlib import Path
from nicegui import app, events, native, ui
from sheetah.sheetah import Document, Segment

class DocSearchUI():
    def __init__(self, document: Document):
        self.document = document
        self.results: list[Segment] = document.items
        self.page = ui.page(path="/", title="sheetah")
        self.openfiledialog = ui.dialog().classes('w-1/2')
        with ui.header():
            with ui.row(wrap=False, align_items='stretch').classes('w-full'):
                with ui.button(icon='menu'):
                    with ui.menu() as menu:
                        ui.menu_item("Open File", self.openfiledialog.open)
                        ui.menu_item("Save File", self._download_document)
                        ui.menu_item("Clear List", self._clear_list)
                self.search_field = ui.input(label='Search', on_change=self._on_search_change, placeholder='Type to search...').classes('w-full')
        self.result_area = ui.column().classes('w-full').style('overflow-y: auto; padding: 10px; gap: 10px')
        with ui.footer():
            self.status_bar = ui.label("Ready.").classes('w-full text-left')
        with self.openfiledialog:
            with ui.card():
                ui.label("Upload a Markdown file to append to the current document.").classes('text-center')
                ui.upload(label="Choose File", on_upload=self._handle_file_upload).props('accept=.md').classes('w-full')
                ui.button("Close", on_click=lambda: self.openfiledialog.close()).classes('w-full')
        self._update_results()

    def _on_search_change(self, event):
        text = event.value
        self.results = self.document.search(text)
        self._update_results()
    
    def _update_results(self):
        self.result_area.clear()
        for element in self.results:
            with self.result_area.classes('h-100%'):
                with ui.card().classes('w-full'):
                    ui.label(element.name).style('font-size: 130%; font-weight: bold')
                    ui.markdown(element.markdown()).classes('whitespace-pre-wrap')
                    ui.button(icon='content_copy', on_click=lambda e, t=element.text(): self._copy_current(e, t)).classes('absolute bottom-2 right-2')

    def _copy_current(self, event, copytext: str):
        if self.results:
            ui.clipboard.write(copytext)  # copy the specified text
            self.status_bar.text = "Copied to clipboard!"

    async def _handle_file_upload(self, event: events.UploadEventArguments, append=False):
        file = event.file
        text = await file.text()
        other = Document.from_markdown(text)
        for seg in other.items:
            self.document.append(seg.name, seg._markdown)
        self.results = self.document.items
        self.search_field.value = ""  # clear search field to show all results
        self._update_results()
        self.status_bar.text = f"File '{file.name}' uploaded and added to Document."
        self.openfiledialog.close()

    def _download_document(self):
        markdown_content = self.document.to_markdown()
        ui.download.content(markdown_content, filename="sheetah_document.md")
        self.status_bar.text = "Document downloaded as 'sheetah_document.md'."
    
    def _clear_list(self):
        self.document.items.clear()
        self.results.clear()
        self._update_results()
        self.status_bar.text = "Document cleared."
    
doc = Document(items=[], description="sheetah + " + str(Path.cwd()))
for file in Path.cwd().glob("*.md"):
    text = open(file, encoding="utf-8").read()
                # append segments from subsequent files to the same document
    other = Document.from_markdown(text)
    for seg in other.items:
        doc.append(seg.name, seg._markdown)
searchUI = DocSearchUI(doc)


def main() -> None:
    """Start the NiceGUI application."""
    ui.run(
        searchUI.page,
        title="sheetah",
        favicon="https://i.ibb.co/tPCktPtz/sheetah256.png",
        reload=False,
    )


if __name__ == "__main__":
    main()

