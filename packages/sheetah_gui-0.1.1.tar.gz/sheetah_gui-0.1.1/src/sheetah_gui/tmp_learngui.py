from nicegui import ui

def on_search(e):
    resultarea.clear()
    for i in range(10):
        with resultarea.classes('h-100%'):
            with ui.card().classes('w-full'):
                ui.label(f"Result {i+1}").style('font-size: 130%; font-weight: bold')
                ui.label("Lorem ipsum dolor sit amet, consectetur adipiscing elit. alkdlskdas asdasdakl daslk dalksd aslkd aslkd aslkd aslkd alskd laskd alsk dlaskd laskd alsk dalksd alkd alsk dalsk dalskd alskd ").style('font-size: 90%')
                ui.button(icon='content_copy', on_click=lambda: ui.notify("Copied to clipboard!")).classes('absolute bottom-2 right-2')

ui.page(path="/", title="sheetah",)
with ui.header():
    ui.input(label='Search', on_change=on_search, placeholder='Type to search...').classes('w-full')
resultarea = ui.column().classes('w-full').style('overflow-y: auto; padding: 10px; gap: 10px')

ui.run(native=True, window_size=(800, 600), fullscreen=False, title="sheetah", favicon="https://drive.google.com/file/d/1MxEEg6wsrJ84uhoyJj_ti-ekqIwFw2EV/view?usp=sharing", )