"""
tracker.py — Auto-track a lit screen in camera view and update region warp corners.

Three tracking strategies (selectable, combinable):

  1. CONTOUR  — threshold the bright screen against darker surroundings,
                find the largest quadrilateral contour. Best for lit screens.
  2. ARUCO   — detect ArUco markers stuck on screen bezel corners.
                Most precise & robust, requires printed marker tags.
  3. OPTICAL — Lucas-Kanade optical flow tracks existing corners frame-to-frame.
                Fast, smooth, but drifts. Used as inter-frame smoother.

Typical hybrid pipeline:
  - Every N frames: run CONTOUR (or ARUCO) to get fresh screen corners.
  - Between detections: OPTICAL flow to keep corners smooth.
  - Exponential moving average to reject jitter.

Usage:
    tracker = ScreenTracker(method="contour")  # or "aruco", "optical", "hybrid"
    tracker.calibrate(initial_corners)          # from warp picker or auto-detect

    # In the capture loop:
    new_corners = tracker.update(frame)
    if new_corners is not None:
        region.src_pts = new_corners
        region.compute_homography()
"""

from __future__ import annotations
import logging
import time
from typing import Optional
import numpy as np

try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Contour-based screen detector
# ---------------------------------------------------------------------------

class ContourDetector:
    """
    Finds the largest bright quadrilateral in the frame.
    Works well for lit screens (CDJ, laptop, mixer display) against a
    darker background.
    """

    def __init__(self, brightness_thresh: int = 80, blur_ksize: int = 5,
                 min_area_ratio: float = 0.01, max_area_ratio: float = 0.95,
                 approx_epsilon: float = 0.02):
        self.brightness_thresh = brightness_thresh
        self.blur_ksize = blur_ksize
        self.min_area_ratio = min_area_ratio
        self.max_area_ratio = max_area_ratio
        self.approx_epsilon = approx_epsilon

    def detect(self, frame: np.ndarray) -> Optional[np.ndarray]:
        """
        Returns 4 corner points [[x,y], ...] clockwise TL→TR→BR→BL,
        or None if no screen quad found.
        """
        if not HAS_CV2:
            return None

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (self.blur_ksize, self.blur_ksize), 0)

        # Adaptive threshold works better than fixed for varying ambient light
        # But we also try a fixed threshold and take the best quad from either
        quads = []
        for thresh_method in ("adaptive", "fixed"):
            mask = self._threshold(blurred, thresh_method)
            quad = self._find_quad(mask, frame.shape)
            if quad is not None:
                quads.append(quad)

        if not quads:
            return None

        # Pick the quad with the largest area
        best = max(quads, key=lambda q: cv2.contourArea(q))
        ordered = self._order_corners(best)
        return ordered

    def _threshold(self, gray: np.ndarray, method: str) -> np.ndarray:
        if method == "adaptive":
            mask = cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY, 51, -10)
        else:
            _, mask = cv2.threshold(gray, self.brightness_thresh, 255, cv2.THRESH_BINARY)

        # Morphological close to fill gaps in screen edges
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (7, 7))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
        return mask

    def _find_quad(self, mask: np.ndarray, frame_shape: tuple) -> Optional[np.ndarray]:
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return None

        h, w = frame_shape[:2]
        total_area = h * w
        min_area = total_area * self.min_area_ratio
        max_area = total_area * self.max_area_ratio

        # Filter and sort by area
        candidates = []
        for c in contours:
            area = cv2.contourArea(c)
            if area < min_area or area > max_area:
                continue
            peri = cv2.arcLength(c, True)
            approx = cv2.approxPolyDP(c, self.approx_epsilon * peri, True)
            if len(approx) == 4:
                candidates.append(approx.reshape(4, 2))

        if not candidates:
            return None

        # Return largest quadrilateral
        return max(candidates, key=lambda c: cv2.contourArea(c))

    def _order_corners(self, pts: np.ndarray) -> np.ndarray:
        """Order 4 points as TL, TR, BR, BL (clockwise from top-left)."""
        pts = pts.astype(np.float32)
        # Sort by sum (TL has smallest x+y, BR has largest)
        s = pts.sum(axis=1)
        d = np.diff(pts, axis=1).flatten()

        ordered = np.zeros((4, 2), dtype=np.float32)
        ordered[0] = pts[np.argmin(s)]    # TL
        ordered[2] = pts[np.argmax(s)]    # BR
        ordered[1] = pts[np.argmin(d)]    # TR (smallest x-y difference)
        ordered[3] = pts[np.argmax(d)]    # BL (largest x-y difference)
        return ordered


# ---------------------------------------------------------------------------
# ArUco marker detector
# ---------------------------------------------------------------------------

class ArucoDetector:
    """
    Detect 4 ArUco markers placed at screen corners.
    Marker IDs 0=TL, 1=TR, 2=BR, 3=BL by default.

    Print markers from: https://chev.me/arucogen/
    Dictionary: DICT_4X4_50 (small markers, fast detection)
    Size: ~15-25mm works well for DJ displays.
    """

    # Which corner of each marker to use as the screen corner point
    # Marker corner indices: 0=TL, 1=TR, 2=BR, 3=BL of the marker itself
    # For screen TL marker, use its inner corner (BR=2), etc.
    MARKER_CORNER_MAP = {
        0: 2,  # TL marker → use its bottom-right corner (inner)
        1: 3,  # TR marker → use its bottom-left corner (inner)
        2: 0,  # BR marker → use its top-left corner (inner)
        3: 1,  # BL marker → use its top-right corner (inner)
    }

    def __init__(self, marker_ids: tuple = (0, 1, 2, 3),
                 dictionary: int = None):
        self.marker_ids = marker_ids
        if dictionary is None and HAS_CV2:
            self._dict_type = cv2.aruco.DICT_4X4_50
        else:
            self._dict_type = dictionary

        self._aruco_dict = None
        self._aruco_params = None
        self._detector = None
        if HAS_CV2:
            self._init_aruco()

    def _init_aruco(self):
        self._aruco_dict = cv2.aruco.getPredefinedDictionary(self._dict_type)
        self._aruco_params = cv2.aruco.DetectorParameters()
        # Tune for small markers / low resolution Pi Camera
        self._aruco_params.adaptiveThreshWinSizeMin = 3
        self._aruco_params.adaptiveThreshWinSizeMax = 23
        self._aruco_params.adaptiveThreshWinSizeStep = 4
        self._aruco_params.minMarkerPerimeterRate = 0.01
        try:
            self._detector = cv2.aruco.ArucoDetector(
                self._aruco_dict, self._aruco_params)
        except AttributeError:
            # Older OpenCV — use deprecated API
            self._detector = None

    def detect(self, frame: np.ndarray) -> Optional[np.ndarray]:
        """
        Returns 4 corner points [[x,y], ...] TL→TR→BR→BL,
        or None if not all 4 markers found.
        """
        if not HAS_CV2 or self._aruco_dict is None:
            return None

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        if self._detector is not None:
            corners, ids, _ = self._detector.detectMarkers(gray)
        else:
            corners, ids, _ = cv2.aruco.detectMarkers(
                gray, self._aruco_dict, parameters=self._aruco_params)

        if ids is None:
            return None

        ids = ids.flatten()
        found = {}
        for i, marker_id in enumerate(ids):
            if marker_id in self.marker_ids:
                marker_corners = corners[i].reshape(4, 2)
                # Pick the inner corner of this marker
                idx = self.marker_ids.index(marker_id)
                corner_idx = self.MARKER_CORNER_MAP.get(marker_id, 0)
                found[idx] = marker_corners[corner_idx]

        if len(found) != 4:
            return None

        result = np.array([found[i] for i in range(4)], dtype=np.float32)
        return result

    @staticmethod
    def generate_markers(output_dir: str = ".", size_px: int = 200):
        """Helper: generate printable ArUco marker PNGs for IDs 0-3."""
        if not HAS_CV2:
            log.error("OpenCV required to generate markers")
            return
        import os
        aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
        labels = ["TL", "TR", "BR", "BL"]
        for i in range(4):
            img = cv2.aruco.generateImageMarker(aruco_dict, i, size_px)
            path = os.path.join(output_dir, f"aruco_{labels[i]}_id{i}.png")
            cv2.imwrite(path, img)
            log.info("Saved marker: %s", path)


# ---------------------------------------------------------------------------
# Optical flow tracker
# ---------------------------------------------------------------------------

class OpticalFlowTracker:
    """
    Track 4 corner points between frames using Lucas-Kanade optical flow.
    Very fast, provides smooth inter-frame tracking, but drifts over time —
    needs periodic re-anchoring from contour or ArUco detection.
    """

    LK_PARAMS = dict(
        winSize=(31, 31),
        maxLevel=3,
        criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01),
    )

    def __init__(self):
        self._prev_gray: Optional[np.ndarray] = None
        self._prev_pts: Optional[np.ndarray] = None

    def reset(self, frame: np.ndarray, corners: np.ndarray):
        """Set initial tracking state."""
        self._prev_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        self._prev_pts = corners.astype(np.float32).reshape(-1, 1, 2)

    def track(self, frame: np.ndarray) -> Optional[np.ndarray]:
        """
        Track corners into new frame.
        Returns updated 4 corners or None if tracking lost.
        """
        if not HAS_CV2 or self._prev_gray is None or self._prev_pts is None:
            return None

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        new_pts, status, err = cv2.calcOpticalFlowPyrLK(
            self._prev_gray, gray, self._prev_pts, None, **self.LK_PARAMS)

        if new_pts is None or status is None:
            return None

        # Check all 4 points tracked successfully
        if not np.all(status.flatten() == 1):
            log.debug("Optical flow lost %d/%d points",
                      4 - int(status.sum()), 4)
            return None

        self._prev_gray = gray
        self._prev_pts = new_pts
        return new_pts.reshape(4, 2)

    @property
    def has_state(self) -> bool:
        return self._prev_pts is not None


# ---------------------------------------------------------------------------
# EMA smoother — reduces jitter from noisy detections
# ---------------------------------------------------------------------------

class CornerSmoother:
    """Exponential moving average filter for 4 corner points."""

    def __init__(self, alpha: float = 0.3, max_jump: float = 50.0):
        """
        alpha: smoothing factor (0=max smooth, 1=no smooth).
        max_jump: if any corner moves more than this many pixels in one
                  update, treat it as a new detection and snap immediately
                  (prevents the EMA from slowly dragging to a wrong position).
        """
        self.alpha = alpha
        self.max_jump = max_jump
        self._smoothed: Optional[np.ndarray] = None

    def update(self, corners: np.ndarray) -> np.ndarray:
        corners = corners.astype(np.float32)
        if self._smoothed is None:
            self._smoothed = corners.copy()
            return self._smoothed.copy()

        # Check for large jumps
        diffs = np.linalg.norm(corners - self._smoothed, axis=1)
        if np.any(diffs > self.max_jump):
            # Snap to new position — probably a re-detection after losing track
            self._smoothed = corners.copy()
            log.debug("Corner jump detected (%.1fpx), snapping", diffs.max())
        else:
            self._smoothed = (self.alpha * corners +
                              (1 - self.alpha) * self._smoothed)

        return self._smoothed.copy()

    def reset(self):
        self._smoothed = None


# ---------------------------------------------------------------------------
# Main ScreenTracker — orchestrates the three methods
# ---------------------------------------------------------------------------

class ScreenTracker:
    """
    High-level screen tracker that manages detection + tracking + smoothing.

    Methods:
      "contour"  — contour detection only
      "aruco"    — ArUco markers only
      "optical"  — optical flow only (needs manual calibrate())
      "hybrid"   — contour detection every N frames + optical flow between

    Usage:
        tracker = ScreenTracker(method="hybrid")
        tracker.calibrate(initial_corners)   # optional, from warp picker

        # Each frame:
        corners = tracker.update(frame)
        if corners is not None:
            region.src_pts = corners.tolist()
            region.compute_homography()
    """

    def __init__(self, method: str = "hybrid",
                 detect_interval: int = 15,
                 smooth_alpha: float = 0.3,
                 smooth_max_jump: float = 50.0,
                 brightness_thresh: int = 80,
                 aruco_ids: tuple = (0, 1, 2, 3)):
        self.method = method
        self.detect_interval = detect_interval
        self._frame_count = 0
        self._enabled = False
        self._calibrated = False

        # Sub-components
        self._contour = ContourDetector(brightness_thresh=brightness_thresh)
        self._aruco = ArucoDetector(marker_ids=aruco_ids)
        self._optical = OpticalFlowTracker()
        self._smoother = CornerSmoother(alpha=smooth_alpha,
                                        max_jump=smooth_max_jump)

        # Reference corners from calibration (used for sanity checks)
        self._ref_corners: Optional[np.ndarray] = None

        # Last known good corners
        self._last_corners: Optional[np.ndarray] = None

        # Stats for status display
        self.last_detect_method: str = "none"
        self.last_detect_time: float = 0.0
        self.tracking_confidence: float = 0.0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, val: bool):
        self._enabled = val
        if not val:
            self._reset_tracking()

    def calibrate(self, corners: list | np.ndarray, frame: Optional[np.ndarray] = None):
        """
        Set initial reference corners (from warp picker or manual config).
        If frame is provided, initialises optical flow state.
        """
        pts = np.array(corners, dtype=np.float32)
        self._ref_corners = pts.copy()
        self._last_corners = pts.copy()
        self._smoother.reset()
        self._smoother.update(pts)
        self._calibrated = True

        if frame is not None and HAS_CV2:
            self._optical.reset(frame, pts)

        log.info("Tracker calibrated with corners: %s", pts.tolist())

    def update(self, frame: np.ndarray) -> Optional[list]:
        """
        Process one frame. Returns updated [[x,y],...] corners as a list
        (ready to assign to region.src_pts), or None if tracking is off
        or no corners found.
        """
        if not self._enabled or not HAS_CV2:
            return None

        self._frame_count += 1
        corners = None

        if self.method == "contour":
            corners = self._detect_contour(frame)

        elif self.method == "aruco":
            corners = self._detect_aruco(frame)

        elif self.method == "optical":
            corners = self._track_optical(frame)

        elif self.method == "hybrid":
            corners = self._hybrid_update(frame)

        if corners is not None:
            smoothed = self._smoother.update(corners)
            self._last_corners = smoothed
            self.tracking_confidence = self._calc_confidence(smoothed)
            return [[int(round(x)), int(round(y))] for x, y in smoothed]

        return None

    # ------------------------------------------------------------------
    # Detection methods
    # ------------------------------------------------------------------

    def _detect_contour(self, frame: np.ndarray) -> Optional[np.ndarray]:
        t0 = time.monotonic()
        corners = self._contour.detect(frame)
        if corners is not None:
            # Sanity check: if we have reference, reject if shape is wildly different
            if self._ref_corners is not None:
                if not self._shape_sanity_check(corners):
                    return None
            self.last_detect_method = "contour"
            self.last_detect_time = time.monotonic() - t0
        return corners

    def _detect_aruco(self, frame: np.ndarray) -> Optional[np.ndarray]:
        t0 = time.monotonic()
        corners = self._aruco.detect(frame)
        if corners is not None:
            self.last_detect_method = "aruco"
            self.last_detect_time = time.monotonic() - t0
        return corners

    def _track_optical(self, frame: np.ndarray) -> Optional[np.ndarray]:
        if not self._optical.has_state:
            if self._last_corners is not None:
                self._optical.reset(frame, self._last_corners)
                return self._last_corners
            return None
        corners = self._optical.track(frame)
        if corners is not None:
            self.last_detect_method = "optical"
        return corners

    def _hybrid_update(self, frame: np.ndarray) -> Optional[np.ndarray]:
        """
        Hybrid strategy:
        - Every detect_interval frames: run contour (or ArUco) detection
        - Between detections: use optical flow
        - If contour fails, try ArUco as fallback
        - If optical flow fails, force a detection
        """
        is_detect_frame = (self._frame_count % self.detect_interval == 0)
        corners = None

        if is_detect_frame or not self._optical.has_state:
            # Try contour first
            corners = self._detect_contour(frame)
            # Fall back to ArUco
            if corners is None:
                corners = self._detect_aruco(frame)
            # Re-anchor optical flow with fresh detection
            if corners is not None:
                self._optical.reset(frame, corners)
        else:
            # Inter-frame: optical flow
            corners = self._track_optical(frame)
            if corners is None:
                # Flow lost — force detection
                corners = self._detect_contour(frame)
                if corners is None:
                    corners = self._detect_aruco(frame)
                if corners is not None:
                    self._optical.reset(frame, corners)

        return corners

    # ------------------------------------------------------------------
    # Sanity checks
    # ------------------------------------------------------------------

    def _shape_sanity_check(self, corners: np.ndarray) -> bool:
        """
        Reject detected corners if they're wildly different from reference.
        Compares aspect ratio and area ratio to the calibration.
        """
        if self._ref_corners is None:
            return True

        ref_area = cv2.contourArea(self._ref_corners)
        new_area = cv2.contourArea(corners)
        if ref_area == 0:
            return True

        area_ratio = new_area / ref_area
        # Allow area to vary by 50% (camera can shift closer/further)
        if area_ratio < 0.5 or area_ratio > 2.0:
            log.debug("Rejected contour: area ratio %.2f outside bounds", area_ratio)
            return False

        return True

    def _calc_confidence(self, corners: np.ndarray) -> float:
        """0.0–1.0 confidence score based on how close to reference shape."""
        if self._ref_corners is None:
            return 0.5
        ref_area = cv2.contourArea(self._ref_corners)
        cur_area = cv2.contourArea(corners)
        if ref_area == 0:
            return 0.5
        ratio = cur_area / ref_area
        # 1.0 when ratio==1, drops as it diverges
        return max(0.0, 1.0 - abs(1.0 - ratio))

    def _reset_tracking(self):
        self._optical = OpticalFlowTracker()
        self._smoother.reset()
        self._frame_count = 0
        self.last_detect_method = "none"
        self.tracking_confidence = 0.0

    # ------------------------------------------------------------------
    # Serialisation (for config persistence)
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "method": self.method,
            "enabled": self._enabled,
            "detect_interval": self.detect_interval,
            "smooth_alpha": self._smoother.alpha,
            "smooth_max_jump": self._smoother.max_jump,
            "brightness_thresh": self._contour.brightness_thresh,
            "ref_corners": self._ref_corners.tolist() if self._ref_corners is not None else None,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ScreenTracker":
        t = cls(
            method=d.get("method", "hybrid"),
            detect_interval=d.get("detect_interval", 15),
            smooth_alpha=d.get("smooth_alpha", 0.3),
            smooth_max_jump=d.get("smooth_max_jump", 50.0),
            brightness_thresh=d.get("brightness_thresh", 80),
        )
        t._enabled = d.get("enabled", False)
        ref = d.get("ref_corners")
        if ref is not None:
            t._ref_corners = np.array(ref, dtype=np.float32)
            t._last_corners = t._ref_corners.copy()
            t._calibrated = True
            t._smoother.update(t._ref_corners)
        return t
