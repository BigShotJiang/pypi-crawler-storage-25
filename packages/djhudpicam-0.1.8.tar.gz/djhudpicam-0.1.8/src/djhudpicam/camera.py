"""
camera.py — picamera2 wrapper for djhud-pi.

Provides a thread-safe frame grabber with configurable resolution and FPS.
Falls back to OpenCV VideoCapture (for testing on non-Pi hardware).
"""

import threading
import time
import numpy as np

# Try picamera2 first, fall back to OpenCV
try:
    from picamera2 import Picamera2
    HAS_PICAMERA2 = True
except ImportError:
    HAS_PICAMERA2 = False

try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False


RESOLUTIONS = [
    (640, 480),
    (800, 600),
    (1280, 720),
    (1920, 1080),
    (2592, 1944),   # Pi Camera v2 full res
    (4608, 2592),   # Pi Camera v3 full res
]


class CameraCapture:
    """
    Thread-safe camera frame source.

    Usage:
        cam = CameraCapture(width=1280, height=720, fps=30)
        cam.start()
        frame = cam.get_frame()   # numpy BGR array or None
        cam.stop()
    """

    def __init__(self, width=1280, height=720, fps=30, device_index=0):
        self.width = width
        self.height = height
        self.fps = fps
        self.device_index = device_index

        self._frame: np.ndarray | None = None
        self._lock = threading.Lock()
        self._running = False
        self._thread: threading.Thread | None = None
        self._backend = None   # "picamera2" | "opencv" | None

        # picamera2 handle
        self._picam: "Picamera2 | None" = None
        # opencv handle
        self._cap = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self) -> str:
        """Start capture thread. Returns backend name."""
        if self._running:
            return self._backend

        if HAS_PICAMERA2:
            self._start_picamera2()
        elif HAS_CV2:
            self._start_opencv()
        else:
            raise RuntimeError("No camera backend available. Install picamera2 or opencv-python.")

        self._running = True
        self._thread = threading.Thread(target=self._capture_loop, daemon=True)
        self._thread.start()
        return self._backend

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=3)
        if self._picam:
            try:
                self._picam.stop()
                self._picam.close()
            except Exception:
                pass
            self._picam = None
        if self._cap:
            try:
                self._cap.release()
            except Exception:
                pass
            self._cap = None

    def get_frame(self) -> np.ndarray | None:
        """Return latest BGR frame as numpy array, or None if not ready."""
        with self._lock:
            return self._frame.copy() if self._frame is not None else None

    def set_resolution(self, width: int, height: int):
        """Change resolution — restarts the camera."""
        was_running = self._running
        if was_running:
            self.stop()
        self.width = width
        self.height = height
        if was_running:
            self.start()

    # ------------------------------------------------------------------
    # Backend init
    # ------------------------------------------------------------------

    def _start_picamera2(self):
        self._picam = Picamera2()
        config = self._picam.create_video_configuration(
            main={"size": (self.width, self.height), "format": "BGR888"},
            controls={"FrameRate": float(self.fps)},
        )
        self._picam.configure(config)
        self._picam.start()
        self._backend = "picamera2"

    def _start_opencv(self):
        self._cap = cv2.VideoCapture(self.device_index)
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
        self._cap.set(cv2.CAP_PROP_FPS, self.fps)
        self._backend = "opencv"

    # ------------------------------------------------------------------
    # Capture loop
    # ------------------------------------------------------------------

    def _capture_loop(self):
        interval = 1.0 / self.fps
        while self._running:
            t0 = time.monotonic()
            frame = self._grab()
            if frame is not None:
                with self._lock:
                    self._frame = frame
            elapsed = time.monotonic() - t0
            sleep = interval - elapsed
            if sleep > 0:
                time.sleep(sleep)

    def _grab(self) -> np.ndarray | None:
        if self._backend == "picamera2" and self._picam:
            try:
                return self._picam.capture_array("main")
            except Exception:
                return None
        elif self._backend == "opencv" and self._cap:
            ret, frame = self._cap.read()
            return frame if ret else None
        return None
