from setuptools import setup
setup(
    name="kruxos",
    version="0.0.1",
    description="The operating system for AI agents — coming soon",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://kruxos.com",
    author="samelldev",
    py_modules=["kruxos"],
)
