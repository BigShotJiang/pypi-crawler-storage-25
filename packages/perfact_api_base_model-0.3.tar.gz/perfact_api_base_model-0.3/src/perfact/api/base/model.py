from datetime import datetime

from pydantic import BaseModel, ConfigDict
from sqlalchemy import BigInteger, DateTime, ForeignKey, String, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

# Re-export for easier use
ForeignKey = ForeignKey
relationship = relationship


class Base(DeclarativeBase):
    """
    Base class for table mappings. Allows declaring fields without their table prefix,
    the subclass hook will automatically rewrite them.
    """

    type_annotation_map = {str: String(), int: BigInteger()}

    id: Mapped[int] = mapped_column(primary_key=True)
    modtime: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    author: Mapped[str | None] = mapped_column(server_default=func.db_username())

    def __init_subclass__(cls, **kw):
        """
        Automatically add __tablename__ and prefix mapped columns with table name
        """
        # 1. Ensure tablename exists before mapping
        if "__tablename__" not in cls.__dict__:
            cls.__tablename__ = cls.__name__.lower()

        # 2. Let SQLAlchemy build the mapper, table, columns, etc.
        super().__init_subclass__(**kw)

        # 3. Now we have cls.__table__ and real Column objects. Adjust these so they
        # map to the prefixed column names on the database
        if hasattr(cls, "__table__"):
            prefix = cls.__tablename__ + "_"

            for col in cls.__table__.columns:
                # Only touch columns that still use their key as name
                # (i.e., no explicit name was given)
                if col.name == col.key:
                    new_name = prefix + col.key
                    col.name = new_name
                    col.key = new_name  # keep ORM key in sync


class View(DeclarativeBase):
    """
    Separate base for view definitions, so they are not created as tables but
    can be used like tables
    """

    type_annotation_map = {str: String(), int: BigInteger()}


class PydanticBase(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    author: str | None
    modtime: datetime
