# perfact-api-base-model

SQLAlchemy declarative base for all PerFact API models. Part of the `perfact.api.base` namespace.

## What it provides

### `Base`

Declarative base for all ORM table mappings. Subclasses automatically get:

- `id` — `BigInteger` primary key
- `modtime` — `DateTime` with timezone, defaults to `now()`
- `author` — set from the DB session user via `db_username()`
- Column names are automatically prefixed with the table name (e.g. a field `name` on `AppUser` becomes the DB column `appuser_name`)
- `__tablename__` is derived from the class name in lowercase if not set explicitly

### `View`

Separate declarative base for SQL view definitions. Views are not created as tables during schema generation. Columns must be declared with explicit names matching the view definition.

### Re-exports

`ForeignKey`, `relationship`, `Mapped`, `mapped_column` are re-exported so model packages only need to import from this module.

## Usage

```python
from perfact.api.base.model import Base, ForeignKey, Mapped, mapped_column, relationship

class MyEntity(Base):
    name: Mapped[str]
    parent_id: Mapped[int | None] = mapped_column(ForeignKey("myentity.myentity_id"))
```

## Dependencies

- `sqlalchemy`
- `psycopg[c]`
- `pydantic-settings`

## Maintainers

- Viktor Dick <viktor.dick@perfact.de>
- Alexander Rolfes <alexander.rolfes@perfact.de>
