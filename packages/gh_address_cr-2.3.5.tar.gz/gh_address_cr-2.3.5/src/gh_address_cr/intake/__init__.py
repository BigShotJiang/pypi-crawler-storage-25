"""Findings intake adapters."""
