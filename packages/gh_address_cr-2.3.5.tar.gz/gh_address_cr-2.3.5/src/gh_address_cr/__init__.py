"""Deterministic runtime package for the gh-address-cr control plane."""

__version__ = "2.3.5"
PROTOCOL_VERSION = "1.0"
SUPPORTED_PROTOCOL_VERSIONS = ("1.0",)
SUPPORTED_SKILL_CONTRACT_VERSIONS = ("1.0",)
