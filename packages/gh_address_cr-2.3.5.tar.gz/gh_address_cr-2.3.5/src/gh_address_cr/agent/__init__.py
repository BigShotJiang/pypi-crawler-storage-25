"""Agent protocol helpers."""
