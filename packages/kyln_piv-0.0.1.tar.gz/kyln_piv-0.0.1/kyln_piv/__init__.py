"""kyln-piv — placeholder package, name reserved for the kyln project.

See https://github.com/hartsock/kyln-scm for the real release once shipped.
This stub does nothing; importing it issues a warning so anyone who
installs by mistake knows it is not the published release.
"""
import warnings

__version__ = "0.0.1"

warnings.warn(
    "kyln-piv 0.0.1 is a name-reservation placeholder. The real release is "
    "not yet on PyPI. See https://github.com/hartsock/kyln-scm",
    stacklevel=2,
)
