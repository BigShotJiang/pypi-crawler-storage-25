"""Lectura NLP — Modele unifie G2P+POS+Morpho+Liaison pour le francais.

Architecture : BiLSTM char-level + multi-tete (2.0M params, ONNX INT8 = 2.0 Mo)

Copyright (C) 2025 Max Carriere
Licence : AGPL-3.0-or-later — voir LICENCE.txt
Licence commerciale disponible — voir LICENCE-COMMERCIALE.md

Quatre backends d'inference au choix :
  - ONNX Runtime  (rapide, ~2ms/phrase)   — necessite modeles locaux
  - NumPy         (leger, ~50ms/phrase)    — necessite modeles locaux
  - Pure Python   (zero dependance)        — necessite modeles locaux
  - API           (serveur Lectura)        — mode par defaut (Niveau 1)

Exemple rapide (mode API, zero config)::

    from lectura_nlp import creer_engine
    engine = creer_engine()
    result = engine.analyser(["bonjour", "monde"])

Exemple avec backend local::

    from lectura_nlp import creer_engine
    engine = creer_engine(mode="local")
    result = engine.analyser(["bonjour", "monde"])
"""

import os
from pathlib import Path

__version__ = "3.3.0"

_MODELES_DIR = Path(__file__).parent / "modeles"


def get_model_path(filename: str) -> Path:
    """Retourne le chemin absolu vers un fichier modele embarque."""
    return _MODELES_DIR / filename


def _resoudre_modeles_dir(models_dir: str | Path | None = None) -> Path | None:
    """Cascade de resolution du dossier modeles.

    Ordre de priorite :
    1. Parametre explicite ``models_dir``
    2. Variable d'environnement ``LECTURA_MODELS_DIR`` / g2p
    3. Dossier utilisateur ``~/.lectura/models/g2p/``
    4. Site-packages (dossier ``modeles/`` du package installe)
    """
    candidats: list[Path] = []
    if models_dir is not None:
        candidats.append(Path(models_dir))
    env = os.environ.get("LECTURA_MODELS_DIR")
    if env:
        candidats.append(Path(env) / "g2p")
    candidats.append(Path.home() / ".lectura" / "models" / "g2p")
    candidats.append(_MODELES_DIR)

    for d in candidats:
        if (d / "unifie_v2_int8.onnx").exists():
            return d
    return None


def _resoudre_lexique(
    lexicon_path: str | Path | None,
    models_dir: Path | None,
) -> str | Path | dict | None:
    """Cascade de resolution du lexique pour les lex_features.

    1. Chemin explicite (si passe)
    2. Fichier JSON dans le dossier modeles resolu
    3. lectura_lexique installe -> generer le dict
    4. None (pas de lexique -> lex_features = zeros)
    """
    if lexicon_path is not None:
        return lexicon_path
    if models_dir is not None:
        json_path = models_dir / "lexique_pos_candidates.json"
        if json_path.exists():
            return json_path
    try:
        from lectura_lexique import Lexique
        lex = Lexique()
        result: dict[str, list[str]] = {}
        for mot, entrees in lex._index.items():
            pos_set: set[str] = set()
            for e in entrees:
                if hasattr(e, "pos") and e.pos:
                    pos_set.add(e.pos)
            if pos_set:
                result[mot] = sorted(pos_set)
        return result
    except (ImportError, Exception):
        pass
    return None


class _EngineAvecCorrections:
    """Wrapper qui applique le post-traitement (corrections, homographes,
    regles) automatiquement apres l'inference."""

    def __init__(self, engine: object) -> None:
        self._engine = engine
        self._loaded = False

    def _charger_tables(self) -> None:
        if self._loaded:
            return
        from lectura_nlp.posttraitement import charger_corrections, charger_homographes
        data_dir = Path(__file__).parent / "data"
        corr = data_dir / "g2p_corrections_unifie.json"
        homo = data_dir / "homographes.json"
        if corr.exists():
            charger_corrections(corr)
        if homo.exists():
            charger_homographes(homo)
        self._loaded = True

    def analyser(self, tokens: list[str]) -> dict:
        self._charger_tables()
        result = self._engine.analyser(tokens)
        from lectura_nlp.posttraitement import corriger_g2p
        g2p_list = result.get("g2p", [])
        pos_list = result.get("pos", [])
        result["g2p"] = [
            corriger_g2p(tok, ipa, pos)
            for tok, ipa, pos in zip(tokens, g2p_list, pos_list)
        ]
        return result

    def __getattr__(self, name: str):
        return getattr(self._engine, name)


def creer_engine(
    mode: str = "auto",
    models_dir: str | Path | None = None,
    api_url: str | None = None,
    api_key: str | None = None,
    lexicon_path: str | Path | None = None,
):
    """Factory pour creer un engine d'inference G2P.

    Le post-traitement (corrections, homographes, regles) est applique
    automatiquement sur les resultats de ``analyser()``.

    Parameters
    ----------
    mode : str
        "auto" (defaut) : local si modeles presents, sinon API
        "local" : force le mode local (ONNX > NumPy > Pure)
        "api" : force le mode API
        "onnx", "numpy", "pure" : force un backend local specifique
    models_dir : str | Path | None
        Chemin vers le dossier contenant les modeles. Si None, cascade
        automatique : LECTURA_MODELS_DIR → ~/.lectura/models/g2p/ → site-packages.
    api_url : str | None
        URL du serveur Lectura (pour mode API)
    api_key : str | None
        Cle API (pour mode API)
    lexicon_path : str | Path | None
        Chemin vers le fichier lexique POS (JSON).
        Si None, resolution automatique (cascade).
    """
    if mode == "api":
        from lectura_nlp.inference_api import ApiInferenceEngine
        return ApiInferenceEngine(api_url=api_url, api_key=api_key)

    resolved_dir = _resoudre_modeles_dir(models_dir)

    if mode == "auto" and resolved_dir is None:
        from lectura_nlp.inference_api import ApiInferenceEngine
        return ApiInferenceEngine(api_url=api_url, api_key=api_key)

    # Mode local — essayer les backends dans l'ordre de preference
    model_onnx = resolved_dir / "unifie_v2_int8.onnx" if resolved_dir else _MODELES_DIR / "unifie_v2_int8.onnx"
    model_vocab = resolved_dir / "unifie_v2_vocab.json" if resolved_dir else _MODELES_DIR / "unifie_v2_vocab.json"
    resolved_lexicon = _resoudre_lexique(lexicon_path, resolved_dir)

    engine = None

    if mode in ("auto", "local", "onnx"):
        try:
            from lectura_nlp.inference_onnx_v2 import OnnxInferenceEngineV2
            if isinstance(resolved_lexicon, dict):
                engine = OnnxInferenceEngineV2(
                    str(model_onnx), str(model_vocab),
                    lexicon=resolved_lexicon,
                )
            else:
                engine = OnnxInferenceEngineV2(
                    str(model_onnx), str(model_vocab),
                    lexicon_path=str(resolved_lexicon) if resolved_lexicon else None,
                )
        except (ImportError, FileNotFoundError, Exception):
            if mode == "onnx":
                raise

    if engine is None and mode in ("auto", "local", "numpy"):
        try:
            from lectura_nlp.inference_numpy import NumpyInferenceEngine
            weights_dir = Path(__file__).parent / "modeles_numpy"
            if not weights_dir.exists():
                weights_dir = resolved_dir if resolved_dir else _MODELES_DIR
            engine = NumpyInferenceEngine(
                str(weights_dir), str(model_vocab),
                lexicon_path=str(resolved_lexicon) if isinstance(resolved_lexicon, Path) else None,
                lexicon=resolved_lexicon if isinstance(resolved_lexicon, dict) else None,
            )
        except (ImportError, FileNotFoundError, Exception):
            if mode == "numpy":
                raise

    if engine is None and mode in ("auto", "local", "pure"):
        try:
            from lectura_nlp.inference_pure import PureInferenceEngine
            weights_dir = Path(__file__).parent / "modeles_numpy"
            if not weights_dir.exists():
                weights_dir = resolved_dir if resolved_dir else _MODELES_DIR
            engine = PureInferenceEngine(
                str(weights_dir), str(model_vocab),
                lexicon_path=str(resolved_lexicon) if isinstance(resolved_lexicon, Path) else None,
                lexicon=resolved_lexicon if isinstance(resolved_lexicon, dict) else None,
            )
        except (ImportError, FileNotFoundError, Exception):
            if mode == "pure":
                raise

    if engine is None:
        raise RuntimeError(
            f"Aucun backend d'inference disponible (mode={mode!r}). "
            "Verifiez que les modeles sont installes ou utilisez mode='api'."
        )

    return _EngineAvecCorrections(engine)


# API publique
from lectura_nlp.tokeniseur import tokeniser, phrase_vers_chars
from lectura_nlp.posttraitement import (
    appliquer_liaison,
    appliquer_regles_g2p,
    charger_corrections,
    charger_homographes,
    corriger_g2p,
)
try:
    from lectura_nlp.pipeline_formules import (
        analyser_phrase_complete,
        ResultatPhraseG2P,
        MotAnalyseG2P,
    )
except ImportError:
    pass  # lectura_formules non disponible — pipeline_formules desactive
