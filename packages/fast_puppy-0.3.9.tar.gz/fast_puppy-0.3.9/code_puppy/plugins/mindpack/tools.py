"""MindPack tools — ask_mindpack tool and orchestrator wiring.

Initialises a singleton MindPackOrchestrator with the five default
experts and registers the advisory deep-solve tool via the plugin
hook system.  Data models live in ``schemas.py`` to avoid circular
imports between this module and ``orchestration.py``.
"""

import logging
from typing import List, Literal

from pydantic_ai import RunContext

from code_puppy.plugins.mindpack.orchestration import MindPackOrchestrator
from code_puppy.plugins.mindpack.schemas import (
    AskMindPackInput,
    AskMindPackOutput,
    ExpertDescriptor,
    MindPackRankedOption,
)

# Backward-compatible re-exports — external code importing from
# ``tools`` still works, but canonical location is ``schemas``.
__all__ = [
    "AskMindPackInput",
    "AskMindPackOutput",
    "ExpertDescriptor",
    "MindPackRankedOption",
    "register_ask_mindpack",
]

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Singleton orchestrator + default expert registration
# ---------------------------------------------------------------------------

orchestrator = MindPackOrchestrator()

_DEFAULT_EXPERTS: List[ExpertDescriptor] = [
    ExpertDescriptor(
        name="Scout",
        speciality="codebase exploration & context gathering",
        model="fast",
        system_prompt_fragment=(
            "You are Scout, the codebase explorer. Your job is to quickly "
            "scan relevant files, trace dependencies, and surface the "
            "context needed to understand a problem. Focus on what exists "
            "and how it connects."
        ),
    ),
    ExpertDescriptor(
        name="Architect",
        speciality="design & architecture decisions",
        model="strong",
        system_prompt_fragment=(
            "You are Architect, the design thinker. Your job is to "
            "propose clean structural solutions, weigh trade-offs, "
            "and ensure the plan fits the existing codebase architecture."
        ),
    ),
    ExpertDescriptor(
        name="Watchdog",
        speciality="risk assessment & edge-case analysis",
        model="medium",
        system_prompt_fragment=(
            "You are Watchdog, the risk analyst. Your job is to "
            "identify failure modes, security concerns, edge cases, "
            "and anything that could go wrong with a proposed plan."
        ),
    ),
    ExpertDescriptor(
        name="Test Planner",
        speciality="validation strategy & test design",
        model="medium",
        system_prompt_fragment=(
            "You are Test Planner, the validation strategist. Your job is "
            "to design the smallest effective test suite that confirms "
            "the plan works and catches regressions."
        ),
    ),
    ExpertDescriptor(
        name="Challenger",
        speciality="adversarial review & assumption questioning",
        model="strong",
        system_prompt_fragment=(
            "You are Challenger, the adversarial reviewer. Your job is "
            "to poke holes in every proposal, question assumptions, "
            "and argue for simpler alternatives when they exist."
        ),
    ),
]

orchestrator.register_experts(_DEFAULT_EXPERTS)

logger.info(
    "MindPack orchestrator initialised with %d default expert(s): %s",
    len(_DEFAULT_EXPERTS),
    [e.name for e in _DEFAULT_EXPERTS],
)

# ---------------------------------------------------------------------------
# Tool registration
# ---------------------------------------------------------------------------


def register_ask_mindpack(agent):
    """Register the ask_mindpack tool on the given agent."""

    @agent.tool
    async def ask_mindpack(
        context: RunContext,
        problem_statement: str,
        current_goal: str,
        current_plan: str | None = None,
        what_has_been_tried: list[str] | None = None,
        relevant_files: list[str] | None = None,
        observed_errors: list[str] | None = None,
        uncertainty: str | None = None,
        desired_output: Literal[
            "plan",
            "review",
            "debug_strategy",
            "architecture_decision",
            "test_strategy",
            "compare_options",
        ] = "plan",
        max_experts: int | None = None,
    ) -> AskMindPackOutput:
        """Request a deep advisory analysis from the MindPack expert pool.

        Use this tool when you encounter a problem that needs deeper
        reasoning, multiple expert perspectives, or comparison of
        approaches.  MindPack runs in nested advisory mode: experts
        are read-only, make no file edits, and cannot call ask_mindpack
        recursively.

        Do NOT call this for simple edits or direct user requests
        that require only a single obvious action.

        Args:
            problem_statement: The specific problem to solve.
            current_goal: What you are currently trying to achieve.
            current_plan: Your current plan, if any.
            what_has_been_tried: Approaches already attempted.
            relevant_files: File paths relevant to the problem.
            observed_errors: Error messages or unexpected behaviours.
            uncertainty: What you are uncertain about.
            desired_output: Kind of advisory output you want.
            max_experts: Cap on number of experts to consult.
        """
        logger.info(
            "ask_mindpack invoked: desired_output=%s, problem=%s",
            desired_output,
            problem_statement[:120],
        )

        request = AskMindPackInput(
            problem_statement=problem_statement,
            current_goal=current_goal,
            current_plan=current_plan,
            what_has_been_tried=what_has_been_tried or [],
            relevant_files=relevant_files or [],
            observed_errors=observed_errors or [],
            uncertainty=uncertainty,
            desired_output=desired_output,
            max_experts=max_experts,
        )

        return await orchestrator.consult(request)

    return ask_mindpack
