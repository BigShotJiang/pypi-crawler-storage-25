"""Callback registration for the MindPack plugin.

Registers the 'register_tools' hook to expose the ask_mindpack tool
to Code Puppy agents.
"""

import logging
from typing import Any, Dict, List

from code_puppy.callbacks import register_callback

logger = logging.getLogger(__name__)


def _register_mindpack_tools() -> List[Dict[str, Any]]:
    """Callback for the 'register_tools' hook.

    Returns tool definitions that the core tool loader will merge
    into TOOL_REGISTRY.
    """
    from code_puppy.plugins.mindpack.tools import register_ask_mindpack

    return [
        {"name": "ask_mindpack", "register_func": register_ask_mindpack},
    ]


register_callback("register_tools", _register_mindpack_tools)

logger.debug("MindPack plugin callbacks registered")
