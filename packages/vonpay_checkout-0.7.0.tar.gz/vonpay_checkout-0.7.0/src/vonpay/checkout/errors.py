"""Error types for Von Payments Checkout SDK."""

from __future__ import annotations

import re
from typing import FrozenSet, Optional, TypeVar

from vonpay.checkout.error_help import NextAction, help_for
from vonpay.checkout.types import (
    ErrorCode,
    PaymentIntentStatus,
    RateLimitInfo,
    RejectReason,
)

_T = TypeVar("_T", bound=str)

# Reject log-forging characters (CR/LF, ANSI escapes, NUL) on payment_intent.
# A server that can influence error responses (MITM, rogue staging endpoint)
# could otherwise inject newlines + ANSI codes that tamper with downstream
# log aggregators. Match the resource-ID allowlist used at the request side
# in client.py — every real `vpi_*` ID is alphanumeric + underscore + hyphen.
_PAYMENT_INTENT_ID_PATTERN = re.compile(r"^[A-Za-z0-9_\-]+$")

# Strip control chars + ANSI CSI sequences from server-controlled free-text
# fields (`error`, `fix`, `docs`, `code`, `request_id`) before they reach
# log aggregators. Server-side rendering does not require these chars; an
# attacker who can influence response bodies (MITM, rogue staging endpoint)
# could otherwise forge separate log records by embedding `\n` + ANSI escapes.
_LOG_INJECT_CHARS = re.compile(r"[\x00-\x1f\x7f]")


def _scrub_log(value: object, max_len: Optional[int] = None) -> str:
    """Return ``value`` cast to str, stripped of control chars + ANSI escapes.

    When ``max_len`` is None (default), no truncation — useful for ``code``,
    where downstream telemetry has its own size cap that depends on seeing
    the full value to decide whether to drop the event. When ``max_len`` is
    set, truncate after sanitisation — used for ``error`` / ``fix`` / ``docs``,
    where unbounded server text could itself exhaust log buffers.
    """
    s = "" if value is None else str(value)
    cleaned = _LOG_INJECT_CHARS.sub("", s)
    return cleaned if max_len is None else cleaned[:max_len]


_PAYMENT_INTENT_STATUS_VALUES: FrozenSet[PaymentIntentStatus] = frozenset({
    "requires_action",
    "authorized",
    "captured",
    "succeeded",
    "voided",
    "failed",
})


_REJECT_REASON_VALUES: FrozenSet[RejectReason] = frozenset({
    "terminal_state",
    "not_authorized",
    "already_captured",
    "already_voided",
    "already_refunded",
    "amount_exceeds_remaining",
})


def _pick_enum(value: object, allowed: FrozenSet[_T]) -> Optional[_T]:
    """Return ``value`` only if it's a known string in ``allowed``.

    Server-controlled fields are typed as enums but the wire is untrusted —
    a misbehaving server (or an attacker who can influence error responses)
    could send strings outside the union. Validate before assignment so
    downstream ``err.current_status == "authorized"`` branches are safe; an
    unknown value becomes ``None`` rather than silently violating the type.

    Uses ``type(value) is str`` (not ``isinstance``) to reject ``str``
    subclasses with custom ``__eq__`` semantics — the JSON parser always
    produces native ``str``, so a subclass here would only arise from a
    non-JSON path and shouldn't be admitted into an enum field.

    The ``TypeVar`` bound on ``allowed`` lets mypy narrow the result to the
    specific Literal subtype (``PaymentIntentStatus`` / ``RejectReason``)
    without an ``# type: ignore`` at the call site.
    """
    if type(value) is str and value in allowed:
        return value  # type: ignore[return-value]
    return None


class VonPayError(Exception):
    """API error with structured error code, fix suggestion, and docs link.

    In addition to the server-emitted ``error`` / ``code`` / ``fix`` / ``docs``,
    this exception carries three SDK-synthesized self-heal helpers derived from
    ``code`` — useful for AI / LLM agents branching on the error:

    * ``retryable``   — ``True`` when retrying may succeed (network / 429 / 5xx).
    * ``next_action`` — programmatic decision-helper:
      ``"fix_input"`` | ``"rotate_key"`` | ``"wait_and_retry"`` |
      ``"contact_support"`` | ``"ignore"``.
    * ``llm_hint``    — 1-3 sentence LLM-friendly diagnostic specific to ``code``.

    Lifecycle endpoints (capture/void/refund) emit a richer error envelope.
    These three optional fields are populated when present:

    * ``payment_intent``  — ID of the intent the operation targeted.
    * ``current_status``  — intent's current status at rejection time, validated
      against ``PaymentIntentStatus``; out-of-enum values become ``None``.
    * ``reject_reason``   — server-canonical reason (``"terminal_state"``,
      ``"already_captured"``, etc.), validated against ``RejectReason``.
    """

    def __init__(
        self,
        status: int,
        error: str,
        code: ErrorCode,
        fix: str,
        docs: str,
        request_id: Optional[str] = None,
        rate_limit: Optional[RateLimitInfo] = None,
        payment_intent: Optional[str] = None,
        current_status: Optional[str] = None,
        reject_reason: Optional[str] = None,
    ) -> None:
        # Server-controlled free-text fields go through _scrub_log to defend
        # against log-injection (CR/LF/NUL/ANSI). The exception message
        # (str(err) → Exception.args[0]) is the highest-leverage path because
        # it lands in every integrator's log aggregator unchanged.
        # error / fix / docs get strip + truncation. code keeps its full
        # length (control chars stripped) so the downstream telemetry size
        # cap can still fire on oversized values from a misbehaving server.
        clean_error = _scrub_log(error, max_len=1024)
        super().__init__(clean_error)
        self.status = status
        self.code = _scrub_log(code)  # type: ignore[assignment]
        self.fix = _scrub_log(fix, max_len=1024)
        self.docs = _scrub_log(docs, max_len=512)
        # request_id comes from X-Request-Id and is used for correlation;
        # bound it to alphanumeric + dash + underscore to defeat injection
        # without full sanitisation.
        self.request_id = (
            request_id
            if isinstance(request_id, str)
            and 0 < len(request_id) <= 128
            and _PAYMENT_INTENT_ID_PATTERN.match(request_id) is not None
            else None
        )
        self.rate_limit = rate_limit
        help_entry = help_for(code)
        self.retryable: bool = help_entry.retryable
        self.next_action: NextAction = help_entry.next_action
        self.llm_hint: str = help_entry.llm_hint
        # payment_intent is server-issued; cap at 256 chars + reject any
        # character outside [A-Za-z0-9_-:] so a server cannot inject CR/LF,
        # ANSI escapes, or NUL into log aggregators that consume this field.
        self.payment_intent: Optional[str] = (
            payment_intent
            if isinstance(payment_intent, str)
            and 0 < len(payment_intent) <= 256
            and _PAYMENT_INTENT_ID_PATTERN.match(payment_intent) is not None
            else None
        )
        self.current_status: Optional[PaymentIntentStatus] = _pick_enum(
            current_status, _PAYMENT_INTENT_STATUS_VALUES
        )
        self.reject_reason: Optional[RejectReason] = _pick_enum(
            reject_reason, _REJECT_REASON_VALUES
        )
