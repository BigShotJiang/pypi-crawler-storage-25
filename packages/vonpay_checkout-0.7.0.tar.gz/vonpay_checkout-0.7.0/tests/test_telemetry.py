"""Tests for vonpay.checkout.telemetry — Phase 3 SDK telemetry.

Mirrors packages/checkout-node/src/telemetry.test.ts where the contract is
shared. Covers opt-in gate, scrub blocklist, operation mapping, body
construction, and status handling.
"""

from __future__ import annotations

import hashlib
import json
import time
import threading
from typing import Any, Dict, List, Optional, Tuple
from unittest.mock import MagicMock, patch

import httpx
import pytest

from vonpay.checkout import (
    Telemetry,
    VonPayCheckout,
    VonPayError,
    contains_sensitive,
    map_operation,
)


SECRET = "vp_sk_test_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"


def _make_error(code: str = "validation_error", request_id: Optional[str] = None) -> VonPayError:
    return VonPayError(
        status=400,
        error="Test error",
        code=code,  # type: ignore[arg-type]
        fix="x",
        docs="y",
        request_id=request_id,
    )


def _wait_for_threads(timeout: float = 1.0) -> None:
    """Telemetry runs on daemon threads. Wait briefly for them to finish."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        active = [t for t in threading.enumerate() if t.daemon and not t.name.startswith("Main")]
        # Filter to threads that are actually waiting on I/O (telemetry _send)
        # Just sleep a tick and let the daemon threads complete.
        time.sleep(0.05)
        # Heuristic: if we waited 200ms and no recent thread spawn, done.
        if len(active) <= 5:  # leave some margin for pytest threads
            return


class TestMapOperation:
    def test_direct_enum_entries(self):
        assert map_operation("sessions.create") == "sessions.create"
        assert map_operation("webhooks.construct_event") == "webhooks.constructEvent"

    def test_aliases(self):
        assert map_operation("sessions.get") == "sessions.retrieve"
        assert map_operation("webhooks.construct_event_v2") == "webhooks.constructEvent"

    def test_verify_signature_is_reserved_no_op(self):
        assert map_operation("webhooks.verify_signature") is None

    def test_non_enum_returns_none(self):
        assert map_operation("sessions.validate") is None
        assert map_operation("health") is None
        assert map_operation("anything-else") is None


class TestContainsSensitive:
    """Blocklist regex parity with vonpay-checkout/src/lib/validation.ts."""

    def test_vp_sk(self):
        assert contains_sensitive("vp_sk_live_abc123") is True
        assert contains_sensitive("vp_sk_test_xyz") is True

    def test_vp_pk(self):
        assert contains_sensitive("vp_pk_test_y") is True

    def test_ss(self):
        assert contains_sensitive("ss_live_z") is True
        assert contains_sensitive("ss_test_secret") is True

    def test_whsec(self):
        assert contains_sensitive("whsec_abc123") is True

    def test_stripe_sk(self):
        assert contains_sensitive("sk_test_a") is True
        assert contains_sensitive("sk_live_x") is True

    def test_stripe_pk(self):
        assert contains_sensitive("pk_live_b") is True

    def test_stripe_rk(self):
        assert contains_sensitive("rk_live_abc123") is True
        assert contains_sensitive("rk_test_xyz") is True
        assert contains_sensitive("bearer rk_live_abc123 in header") is True

    def test_email(self):
        assert contains_sensitive("user@example.com") is True

    def test_case_insensitive(self):
        assert contains_sensitive("VP_SK_LIVE_X") is True

    def test_embedded_match(self):
        assert contains_sensitive("error msg: vp_sk_live_X happened") is True

    def test_legitimate_values_pass(self):
        assert contains_sensitive("python-3.11.2") is False
        assert contains_sensitive("auth_invalid_key") is False
        assert contains_sensitive("0.4.0") is False
        assert contains_sensitive("sessions.create") is False


class TestTelemetryConstructorOptInGate:
    def test_explicit_true_activates(self):
        client = VonPayCheckout(SECRET, telemetry={"enabled": True})
        assert client._telemetry is not None  # type: ignore[attr-defined]

    def test_explicit_false_does_not_activate(self):
        client = VonPayCheckout(SECRET, telemetry={"enabled": False})
        assert client._telemetry is None  # type: ignore[attr-defined]

    def test_test_key_defaults_on_when_no_telemetry_kwarg(self):
        # v0.7.0+ (Heimdall vonpay coverage Phase 1): test keys default-on.
        # Original test "no kwarg → no telemetry" inverted because that was
        # the OLD privacy posture.
        client = VonPayCheckout(SECRET)
        assert client._telemetry is not None  # type: ignore[attr-defined]

    def test_live_key_defaults_off_when_no_telemetry_kwarg(self):
        client = VonPayCheckout("vp_sk_live_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
        assert client._telemetry is None  # type: ignore[attr-defined]

    def test_typeerror_on_int(self):
        with pytest.raises(TypeError):
            VonPayCheckout(SECRET, telemetry={"enabled": 1})

    def test_typeerror_on_string(self):
        with pytest.raises(TypeError):
            VonPayCheckout(SECRET, telemetry={"enabled": "true"})

    def test_typeerror_on_dict(self):
        with pytest.raises(TypeError):
            VonPayCheckout(SECRET, telemetry={"enabled": {}})


class TestTelemetryConstructionTimeValidation:
    def test_self_disables_on_bad_sdk_version(self):
        t = Telemetry(
            api_key=SECRET,
            base_url="https://checkout.vonpay.com",
            sdk_version="0.4.0-RC.1",  # uppercase RC; server requires lowercase
        )
        assert t.enabled is False

    def test_activates_with_valid_version(self):
        t = Telemetry(
            api_key=SECRET,
            base_url="https://checkout.vonpay.com",
            sdk_version="0.4.0",
        )
        assert t.enabled is True


class TestTelemetryRecord:
    """Core record() contract — body construction + scrub + send."""

    def _make_telemetry(self) -> Tuple[Telemetry, MagicMock]:
        mock_client = MagicMock(spec=httpx.Client)
        mock_client.post.return_value = MagicMock(status_code=204)
        t = Telemetry(
            api_key=SECRET,
            base_url="https://checkout.vonpay.com",
            sdk_version="0.4.0",
            http_client=mock_client,
        )
        return t, mock_client

    def test_posts_body_with_required_fields(self):
        t, mock_client = self._make_telemetry()
        err = _make_error("validation_invalid_amount", "req_xyz123")
        t.record(err, "sessions.create", 0, 400)
        # Wait for background thread to finish
        time.sleep(0.2)
        assert mock_client.post.called
        call = mock_client.post.call_args
        url = call.args[0]
        assert url == "https://checkout.vonpay.com/v1/sdk-telemetry"
        body = json.loads(call.kwargs["content"])
        assert body["sdk_name"] == "checkout-python"
        assert body["sdk_version"] == "0.4.0"
        assert body["runtime"].startswith("python-")
        assert body["error_code"] == "validation_invalid_amount"
        assert body["operation"] == "sessions.create"
        # SHA-256 of "req_xyz123"
        expected_hash = hashlib.sha256(b"req_xyz123").hexdigest()
        assert body["request_id_hash"] == expected_hash
        assert body["context"]["retry_count"] == 0
        assert body["context"]["http_status"] == 400

    def test_omits_request_id_hash_when_none(self):
        t, mock_client = self._make_telemetry()
        err = _make_error("webhook_invalid_signature", None)
        t.record(err, "webhooks.construct_event", None, None)
        time.sleep(0.2)
        body = json.loads(mock_client.post.call_args.kwargs["content"])
        assert "request_id_hash" not in body

    def test_aliases_sessions_get_to_retrieve_in_wire_body(self):
        t, mock_client = self._make_telemetry()
        t.record(_make_error(), "sessions.get", 0, 400)
        time.sleep(0.2)
        body = json.loads(mock_client.post.call_args.kwargs["content"])
        assert body["operation"] == "sessions.retrieve"

    def test_skips_silently_for_non_enum_operation(self):
        t, mock_client = self._make_telemetry()
        t.record(_make_error(), "sessions.validate", 0, 400)
        t.record(_make_error(), "health", 0, 400)
        t.record(_make_error(), "webhooks.verify_signature", 0, 400)
        time.sleep(0.2)
        assert not mock_client.post.called

    def test_skips_when_err_is_not_vonpay_error(self):
        t, mock_client = self._make_telemetry()
        t.record(Exception("plain"), "sessions.create", 0, 400)
        time.sleep(0.2)
        assert not mock_client.post.called

    def test_drops_silently_when_body_over_2048(self):
        t, mock_client = self._make_telemetry()
        long_code = "X" * 2100
        t.record(_make_error(long_code, "req_x"), "sessions.create", 0, 400)
        time.sleep(0.2)
        assert not mock_client.post.called

    def test_body_cap_boundary_2048_is_allowed(self):
        # Spec §9 (qa M-3): locks `> 2048` vs `>= 2048` fence-post.
        t, mock_client = self._make_telemetry()
        # Baseline body to measure header overhead, then pad error_code
        # to land the body at exactly 2048 bytes.
        t.record(_make_error("X", "req_xyz"), "sessions.create", 0, 400)
        time.sleep(0.2)
        baseline = mock_client.post.call_args.kwargs["content"]
        baseline_bytes = len(baseline.encode("utf-8"))
        mock_client.reset_mock()
        mock_client.post.return_value = MagicMock(status_code=204)

        pad_needed = 2048 - baseline_bytes
        assert pad_needed > 0  # sanity: baseline must be under cap
        long_code = "X" + "Y" * pad_needed
        t.record(_make_error(long_code, "req_xyz"), "sessions.create", 0, 400)
        time.sleep(0.2)
        assert mock_client.post.called
        actual_bytes = len(mock_client.post.call_args.kwargs["content"].encode("utf-8"))
        assert actual_bytes == 2048

    def test_body_cap_boundary_2049_is_dropped(self):
        # Spec §9 (qa M-3): one byte over cap → drop.
        t, mock_client = self._make_telemetry()
        t.record(_make_error("X", "req_xyz"), "sessions.create", 0, 400)
        time.sleep(0.2)
        baseline_bytes = len(mock_client.post.call_args.kwargs["content"].encode("utf-8"))
        mock_client.reset_mock()
        mock_client.post.return_value = MagicMock(status_code=204)

        pad_needed = 2049 - baseline_bytes
        long_code = "X" + "Y" * pad_needed
        t.record(_make_error(long_code, "req_xyz"), "sessions.create", 0, 400)
        time.sleep(0.2)
        assert not mock_client.post.called

    def test_drops_silently_on_sensitive_shape_in_field(self):
        t, mock_client = self._make_telemetry()
        # error_code containing a key shape (defense-in-depth)
        err = _make_error("vp_sk_live_LEAKED", "req_x")
        t.record(err, "sessions.create", 0, 400)
        time.sleep(0.2)
        assert not mock_client.post.called

    def test_sends_authorization_bearer(self):
        t, mock_client = self._make_telemetry()
        t.record(_make_error(), "sessions.create", 0, 400)
        time.sleep(0.2)
        headers = mock_client.post.call_args.kwargs["headers"]
        assert headers["Authorization"] == f"Bearer {SECRET}"
        assert headers["Von-Pay-Version"] == "2026-04-14"
        assert headers["Content-Type"] == "application/json"
        assert headers["User-Agent"].startswith("checkout-python/0.4.0")

    def test_never_includes_api_key_in_body(self):
        t, mock_client = self._make_telemetry()
        t.record(_make_error(), "sessions.create", 0, 400)
        time.sleep(0.2)
        content = mock_client.post.call_args.kwargs["content"]
        assert SECRET not in content
        assert "vp_sk_test_" not in content
        assert "Bearer" not in content


class TestTelemetryStatusHandling:
    def _make_telemetry_with_response(self, status: int) -> Tuple[Telemetry, MagicMock]:
        mock_client = MagicMock(spec=httpx.Client)
        mock_client.post.return_value = MagicMock(status_code=status)
        t = Telemetry(
            api_key=SECRET,
            base_url="https://checkout.vonpay.com",
            sdk_version="0.4.0",
            http_client=mock_client,
        )
        return t, mock_client

    def test_204_succeeds_silently(self, caplog):
        t, _ = self._make_telemetry_with_response(204)
        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            t.record(_make_error(), "sessions.create", 0, 400)
            time.sleep(0.2)
        assert not any("400 from server" in r.message for r in caplog.records)

    def test_400_fires_clock_skew_warn_once(self, caplog):
        t, _ = self._make_telemetry_with_response(400)
        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            t.record(_make_error(), "sessions.create", 0, 400)
            time.sleep(0.2)
            t.record(_make_error(), "sessions.create", 0, 400)
            time.sleep(0.2)
        warns_400 = [r for r in caplog.records if "400 from server" in r.message]
        assert len(warns_400) == 1
        assert "clock skew" in warns_400[0].message
        assert "NTP" in warns_400[0].message

    def test_401_fires_warn_once(self, caplog):
        t, _ = self._make_telemetry_with_response(401)
        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            t.record(_make_error(), "sessions.create", 0, 400)
            time.sleep(0.2)
            t.record(_make_error(), "sessions.create", 0, 400)
            time.sleep(0.2)
        warns_401 = [r for r in caplog.records if "401 unauthorized" in r.message]
        assert len(warns_401) == 1

    def test_5xx_fires_server_error_warn_once(self, caplog):
        t, _ = self._make_telemetry_with_response(503)
        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            t.record(_make_error(), "sessions.create", 0, 400)
            time.sleep(0.2)
            t.record(_make_error(), "sessions.create", 0, 400)
            time.sleep(0.2)
        warns_5xx = [r for r in caplog.records if "server unavailable" in r.message]
        assert len(warns_5xx) == 1

    def test_network_error_fires_firewall_hint_once(self, caplog):
        mock_client = MagicMock(spec=httpx.Client)
        mock_client.post.side_effect = httpx.ConnectError("connection refused")
        t = Telemetry(
            api_key=SECRET,
            base_url="https://checkout.vonpay.com",
            sdk_version="0.4.0",
            http_client=mock_client,
        )
        with caplog.at_level("WARNING", logger="vonpay.checkout"):
            t.record(_make_error(), "sessions.create", 0, 400)
            time.sleep(0.2)
            t.record(_make_error(), "sessions.create", 0, 400)
            time.sleep(0.2)
        warns_net = [r for r in caplog.records if "network/timeout" in r.message]
        assert len(warns_net) == 1


class TestTelemetryPauseSemantics:
    """Locks the dropCount + pausedUntil atomic-clear behavior."""

    def test_429_pauses_then_clears_atomically(self):
        mock_client = MagicMock(spec=httpx.Client)
        # First call → 429
        mock_client.post.return_value = MagicMock(status_code=429)

        now = [1_000_000.0]

        def now_fn():
            return now[0]

        t = Telemetry(
            api_key=SECRET,
            base_url="https://checkout.vonpay.com",
            sdk_version="0.4.0",
            http_client=mock_client,
            now_fn=now_fn,
        )

        # Hit the 429
        t.record(_make_error(), "sessions.create", 0, 400)
        time.sleep(0.2)
        assert mock_client.post.call_count == 1

        # While paused → no further calls
        mock_client.post.return_value = MagicMock(status_code=204)
        t.record(_make_error(), "sessions.create", 0, 400)
        time.sleep(0.2)
        assert mock_client.post.call_count == 1  # paused

        # Advance past pause window → next event flows
        now[0] += 60.001
        t.record(_make_error(), "sessions.create", 0, 400)
        time.sleep(0.2)
        assert mock_client.post.call_count == 2  # pause cleared

    def test_31st_event_after_pause_flows(self):
        # Spec §9: locks `dropCount = 0` on pause-clear; without that, a
        # residual counter would skip event 31.
        mock_client = MagicMock(spec=httpx.Client)
        mock_client.post.return_value = MagicMock(status_code=429)

        now = [1_000_000.0]

        def now_fn():
            return now[0]

        t = Telemetry(
            api_key=SECRET,
            base_url="https://checkout.vonpay.com",
            sdk_version="0.4.0",
            http_client=mock_client,
            now_fn=now_fn,
        )

        # Trip the 429
        t.record(_make_error(), "sessions.create", 0, 400)
        time.sleep(0.2)
        assert mock_client.post.call_count == 1

        # 30 events while paused — all dropped
        mock_client.post.return_value = MagicMock(status_code=204)
        for _ in range(30):
            t.record(_make_error(), "sessions.create", 0, 400)
        time.sleep(0.2)
        assert mock_client.post.call_count == 1  # still only the original 429

        # Advance past pause; fire 1 more — must flow (proves dropCount=0)
        now[0] += 60.001
        t.record(_make_error(), "sessions.create", 0, 400)
        time.sleep(0.2)
        assert mock_client.post.call_count == 2


class TestTelemetryIntegration:
    """End-to-end: VonPayCheckout with telemetry enabled triggers record() on errors."""

    def test_telemetry_fires_on_construct_event_failure(self, caplog):
        client = VonPayCheckout(SECRET, telemetry={"enabled": True})
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        # Patch the telemetry's post so we don't hit real network
        with patch.object(client._telemetry._client, "post") as mock_post:  # type: ignore[attr-defined]
            mock_post.return_value = MagicMock(status_code=204)
            with pytest.raises(VonPayError):
                client.webhooks.construct_event(body, "deadbeef" * 8, SECRET, ts)
            time.sleep(0.3)
            assert mock_post.called
            url = mock_post.call_args.args[0]
            assert "/v1/sdk-telemetry" in url
            wire = json.loads(mock_post.call_args.kwargs["content"])
            assert wire["operation"] == "webhooks.constructEvent"
            assert wire["error_code"] == "webhook_invalid_signature"

    def test_telemetry_off_no_post(self, caplog):
        # v0.7.0+: explicit opt-out required since test-key default-on.
        client = VonPayCheckout(SECRET, telemetry={"enabled": False})
        assert client._telemetry is None  # type: ignore[attr-defined]

    def test_telemetry_on_with_custom_reporter_both_fire(self):
        # Spec §7: telemetry must fire AFTER the custom reporter, not be
        # short-circuited by the reporter's branch. Locks the code-reviewer
        # blocker (telemetry call hoisted out of early-return).
        reporter_calls = []

        def reporter(err, ctx):
            reporter_calls.append((err, ctx))

        client = VonPayCheckout(
            SECRET,
            error_reporter=reporter,
            telemetry={"enabled": True},
        )
        body = json.dumps({"event": "session.succeeded"})
        ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

        with patch.object(client._telemetry._client, "post") as mock_post:  # type: ignore[attr-defined]
            mock_post.return_value = MagicMock(status_code=204)
            with pytest.raises(VonPayError):
                client.webhooks.construct_event(body, "deadbeef" * 8, SECRET, ts)
            time.sleep(0.3)

        # Both surfaces fired
        assert len(reporter_calls) == 1
        assert mock_post.called
        url = mock_post.call_args.args[0]
        assert "/v1/sdk-telemetry" in url


class TestTelemetryPrivacyInvariants:
    def test_VONPAY_TELEMETRY_env_does_not_activate(self, monkeypatch):
        # v0.7.0+: env var still doesn't flip telemetry on. We now use a
        # LIVE key here (default-off) to isolate the env-var-doesn't-work
        # invariant from the test-key-default-on behavior.
        monkeypatch.setenv("VONPAY_TELEMETRY", "1")
        client = VonPayCheckout("vp_sk_live_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
        assert client._telemetry is None  # type: ignore[attr-defined]
