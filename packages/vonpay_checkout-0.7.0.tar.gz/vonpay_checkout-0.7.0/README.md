# vonpay-checkout

Python SDK for the [Von Payments Checkout API](https://docs.vonpay.com). Create hosted checkout sessions, verify webhook signatures, and validate signed return redirects.

## Install

```bash
pip install vonpay-checkout
```

**Requires:** Python 3.9+, httpx 0.27+

## Quick start

```python
from vonpay.checkout import VonPayCheckout, VonPayError

client = VonPayCheckout("vp_sk_test_...")

session = client.sessions.create(
    amount=1499,
    currency="USD",
    country="US",
    success_url="https://example.com/order/123/confirm",
)

print(session.checkout_url)
# https://checkout.vonpay.com/checkout?session=vp_cs_test_...
```

### Discrete-lifecycle API

The `payment_intents`, `refunds`, `tokens`, and `capabilities` namespaces give server-side control over payment intents, alongside the existing hosted-checkout `sessions` flow.

```python
# Create a payment intent (auth + capture)
intent = client.payment_intents.create(
    amount=1499,
    currency="usd",
    capture_method="automatic",
    metadata={"order_id": "ord_42"},
    idempotency_key="ord_42-charge-1",
)
print(intent.id, intent.status)  # "vpi_live_…", "succeeded"

# Auth-only + later capture (fulfillment-on-ship)
auth = client.payment_intents.create(amount=1499, currency="usd", capture_method="manual")
client.payment_intents.capture(auth.id, amount_to_capture=1499)

# Refund a captured intent (partial or full)
refund = client.refunds.create(payment_intent=intent.id, amount=500)

# Create a reusable token for save-card / MIT flows
token = client.tokens.create(buyer_id="buyer_42", setup_for_future_use="off_session")

# Read the merchant's processor capability matrix before invoking optional ops
caps = client.capabilities.get()
if caps.supported_operations.partial_refund:
    # partial refunds supported — safe to offer partial-refund UI
    ...
```

## Features

- **Typed session / webhook / error objects** — full `CheckoutSession`, `SessionStatus`, `WebhookEvent`, `VonPayError` types.
- **Webhook verification** — HMAC-SHA256 with ±5 minute timestamp replay protection.
- **Signed return URL verification (v1 + v2)** — `verify_return_signature()` supports both legacy v1 signatures and v2 signatures that bind `successUrl`, `keyMode`, and `iat` freshness.
- **Auto-retry** — exponential backoff on 429 / 5xx with `Retry-After` header support.
- **Request ID tracing** — every response includes `X-Request-Id` for support tickets.

## Documentation

- [Python SDK reference](https://docs.vonpay.com/sdks/python-sdk)
- [API reference](https://docs.vonpay.com/reference/api)
- [Quickstart](https://docs.vonpay.com/quickstart)

## License

MIT
