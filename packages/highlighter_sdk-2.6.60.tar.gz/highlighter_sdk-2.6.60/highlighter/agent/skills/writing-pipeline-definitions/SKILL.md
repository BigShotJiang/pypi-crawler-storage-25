---
name: writing-pipeline-definitions
description: Creates Highlighter agent pipeline definition JSON files. Use when building new pipelines, configuring processing elements, or setting up data flow between sources, detectors, classifiers, and output targets.
---

# Writing Pipeline Definitions

Pipeline definitions are JSON files describing a directed graph of processing elements, executed via `hl agent start`. The inner runtime is the **Aiko pipeline runtime** (`github.com/geekscape/aiko_services`).

## Pipeline Definition Schema

```json
{
  "version": 0,
  "name": "p_my_pipeline",
  "runtime": "python",
  "graph": ["(Element1 Element2 Element3)"],
  "parameters": {},
  "elements": [...]
}
```

### Top-level fields

| Field | Required | Description |
|-------|----------|-------------|
| `version` | yes | Always `0` (validated against `PipelineDefinitionSchema.version`) |
| `name` | yes | Pipeline name (convention: `p_` prefix) |
| `runtime` | yes | Always `"python"` (validated — only "python" is currently supported) |
| `graph` | yes | Array of graph path strings — parsed as S-expressions by the Aiko parser |
| `parameters` | no | Top-level parameters (map of string/boolean/int/null values). Defaults to `{}` |
| `elements` | yes | Array of element definitions |

### Comments

Any key named `"#"` is stripped during loading at both pipeline and element level. This is useful for ASCII diagrams or documentation:

```json
{
  "#": "    A --> B --> C",
  "#": "    |         ^",
  "#": "    +----D----+",
  "graph": ["(A B (A B) C (B C) D (A D D C))"]
}
```

Note: duplicate `"#"` keys in JSON means only the last one survives in the parsed dict, but they're all discarded anyway. They're purely for human readers of the JSON file.

### Graph syntax

The `graph` field is an array of strings, each parsed as an S-expression by the Aiko `parse()` function. Each string defines a **graph path** (subgraph). The first element name in each path becomes a **head node**.

**Linear pipeline** — elements chained left to right:
```
"(A B C)"       →  A -> B -> C
```

**Branching** — nested lists create branches:
```
"(A (B D) (C D))"   →  A -> B -> D, A -> C -> D
```

**Multiple graph paths** — separate subgraphs, selectable via `--graph_path` CLI flag:
```
["(PathA_Start PathA_End)", "(PathB_Start PathB_End)"]
```

**Custom edge mapping** — when an element's output names don't match the next element's input names, use dict syntax to map them. Properties are attached to the *successor* node:
```
"(A B (a_out: b_in))"
```

This tells the runtime that output `a_out` from A should be passed as input `b_in` to B. For multiple mappings:
```
"(A B (a_out_1: b_in_1 a_out_2: b_in_2))"
```

More complex example with an ASCII diagram:
```json
{
  "#": "    A -----> B -----> C",
  "#": "    |                 ^",
  "#": "    +-----------------+",
  "graph": ["(A B (A.a_out_1: b_in_1 A.a_out_2: b_in_2) C (A.a_out_1: c_in_1 B.b_out_1: c_in_2 A.a_out_2: c_in_3))"]
}
```

**Important**: In most simple linear pipelines, explicit edge mapping is not needed — the runtime passes the full frame data dict through, and each element's `process_frame` picks the arguments it needs by name.

### Element definition

```json
{
  "name": "ElementName",
  "parameters": {},
  "input": [{"name": "port_name", "type": "port_type"}],
  "output": [{"name": "port_name", "type": "port_type"}],
  "deploy": {
    "local": {
      "module": "python.module.path",
      "class_name": "OptionalClassName"
    }
  }
}
```

| Field | Required | Description |
|-------|----------|-------------|
| `name` | yes | Element identifier — must match the name used in the `graph` string. **Must use simple names**: no spaces, no special characters, use PascalCase or snake_case (e.g. `XarmDetector`, not `Xarm Detector`). The graph S-expression parser splits on whitespace, so spaces in names will break parsing. When creating elements from Highlighter capabilities whose titles contain spaces, convert them to PascalCase (e.g. "Xarm Detector" → `XarmDetector`, "Stock Code Classifier" → `StockCodeClassifier`) |
| `parameters` | no | Element-specific config. Defaults to `{}`. Passed to the element's `StreamParameters` Pydantic model |
| `input` | yes | Array of `{name, type}` objects. **`name` is functional** — the runtime uses it to select which keys from the frame data to pass to `process_frame()`. `type` is documentation only |
| `output` | yes | Array of `{name, type}` objects. **`name` is functional** — the runtime creates qualified aliases (`ElementName.output_name`) in the frame data for edge mapping. `type` is documentation only |
| `deploy.local.module` | yes | Python module path. Loaded via `importlib`. Can be a dotted module path or a file path |
| `deploy.local.class_name` | no | Class name to load from the module. **Defaults to `name`** if not specified |

**Key rules for input/output names**:

- `input` `name` fields are functional: the runtime passes only matching keys from the frame data as kwargs to `process_frame()`. Empty `input: []` means no kwargs beyond `stream`.
- `output` `name` fields are functional: the runtime creates qualified aliases (`ElementName.output_name`) for edge mapping.
- `type` is documentation only — the runtime ignores it.

For detailed runtime internals (element loading, stream/frame lifecycle, data flow mechanics), see [aiko-pipeline-runtime-reference.md](aiko-pipeline-runtime-reference.md).

## Finding Capability Implementations

Rather than memorizing all available capabilities, look them up in the source:

- **Data sources and core capabilities**: `highlighter/agent/capabilities/sources.py` — `ImageDataSource`, `VideoDataSource`, `TextDataSource`, `JsonArrayDataSource`
- **Output targets**: `highlighter/agent/capabilities/targets.py` — `EntityWriteFile`, `EntityWriteJsonl`, `WriteStdOut`, `ImageWrite`, `Print`, `FrameDataWriteJson`
- **Aiko compatibility wrappers**: `highlighter/agent/capabilities/aiko_compat.py` — `PackDataSamples`, `UnpackDataSamples`
- **Detection/classification**: `highlighter/agent/capabilities/image_to_enum/` — `OnnxYoloV8`, `YoloBoxClassifier`
- **Mock elements for testing**: `highlighter/agent/capabilities/mock_detector.py`, `mock_classifier.py`
- **Other**: `highlighter/agent/capabilities/` — browse for `match_template.py`, `tracker.py`, `create_case.py`, `select_nth_sample.py`, `llm.py`, etc.

To find the class name and `process_frame` signature for any capability, read the source file.

## Highlighter Task Processing: AssessmentRead and AssessmentWrite

When a pipeline needs to process **Highlighter tasks** (assessments from the platform) rather than local files, use the special `AssessmentRead` and `AssessmentWrite` elements:

- **`AssessmentRead`** (`highlighter.agent.capabilities.assessment_read`) — reads tasks from a Highlighter step. Used as the data source instead of `ImageDataSource`/etc. Requires `--step-id` to be passed on the CLI. Outputs both `data_samples` and `entities` (any existing annotations on the task).
- **`AssessmentWrite`** (`highlighter.agent.capabilities.assessment_write`) — writes results back to the Highlighter platform. Used as the final element instead of file/stdout targets.

### AssessmentWrite data requirements

`AssessmentWrite.process_frame` needs two things:

1. **`data_samples`** — the original data samples from `AssessmentRead`. These provide the `data_file_ids` that link the submission back to the source files.
2. **Entity dicts (via `**kwargs`)** — all other named inputs are collected as entity dictionaries and submitted as annotations/observations.

This means the graph edges to `AssessmentWrite` must route:
- `data_samples` from `AssessmentRead` (not from a detector/classifier, which doesn't output `data_samples`)
- `entities` from each processing element that produces them
- Source `entities` from `AssessmentRead` if existing annotations should be preserved in the submission

A typical Highlighter task pipeline:
```json
{
  "version": 0,
  "name": "p_hl_task_processor",
  "runtime": "python",
  "#": "  AssessmentRead --> Detector --> AssessmentWrite",
  "#": "  |                              ^",
  "#": "  +--- data_samples, entities ---+",
  "graph": ["(AssessmentRead Detector (AssessmentRead.data_samples: data_samples) AssessmentWrite (AssessmentRead.data_samples: data_samples AssessmentRead.entities: source_entities Detector.entities: entities))"],
  "elements": [
    {
      "name": "AssessmentRead",
      "parameters": {"source_inputs": []},
      "input": [{"name": "data_samples", "type": "List[DataSample]"},
                {"name": "entities", "type": "dict"}],
      "output": [{"name": "data_samples", "type": "List[DataSample]"},
                 {"name": "entities", "type": "dict"}],
      "deploy": {"local": {"module": "highlighter.agent.capabilities.assessment_read"}}
    },
    {
      "name": "Detector",
      "parameters": {},
      "input": [{"name": "data_samples", "type": "List[DataSample]"}],
      "output": [{"name": "entities", "type": "dict"}],
      "deploy": {"local": {"module": "my_project.detector"}}
    },
    {
      "name": "AssessmentWrite",
      "parameters": {},
      "input": [{"name": "data_samples", "type": "List[DataSample]"},
                {"name": "source_entities", "type": "dict"},
                {"name": "entities", "type": "dict"}],
      "output": [],
      "deploy": {"local": {"module": "highlighter.agent.capabilities.assessment_write"}}
    }
  ]
}
```

Run with: `hl agent start pipeline.json --step-id "$STEP_UUID"`

Note: When using `AssessmentRead`/`AssessmentWrite`, use a GraphQL API key specific to the agent (created via `hl agent create-token`).

## Step 1: Gather Requirements

Ask the user what they want the pipeline to do. Key questions:

1. **What data will it process?** — local images/video/text, JSON, or Highlighter tasks?
2. **What processing should happen?** — detection, classification, custom logic, etc.
3. **What output is needed?** — write to file, stdout, back to Highlighter, or just observe?
4. **Any custom elements?** — does the user have their own `Capability` subclasses?

## Step 2: Write the Definition

Based on requirements, compose the JSON definition:

1. Choose the right data source element as the first element
2. Chain processing elements in the graph
3. Add an output target as the last element (if needed)
4. Set appropriate parameters
5. Write to `.pipelines/<name>.json` in the project directory

### Conventions

- Pipeline names start with `p_` (e.g. `p_image_detector`)
- For local-only pipelines, `ImageDataSource` is the most common starting point
- When `class_name` matches the element `name`, you can omit `class_name` from the deploy config
- When in doubt about a capability's interface, read its source file to check the `process_frame` signature
- Test with: `hl agent start .pipelines/<name>.json <input-file-or-glob>`

## Step 3: Validate

After writing the definition, run it:

```bash
# Single image
hl agent start .pipelines/<name>.json path/to/image.jpg

# Multiple images
hl agent start .pipelines/<name>.json path/to/images/*.jpg

# Keep running after inputs are processed (server mode)
hl agent start .pipelines/<name>.json --server path/to/image.jpg
```

## Examples

### Minimal: Read images and print frame data

```json
{
  "version": 0,
  "name": "p_image_print",
  "runtime": "python",
  "graph": ["(ImageDataSource Print)"],
  "elements": [
    {
      "name": "ImageDataSource",
      "parameters": {},
      "input": [{"name": "data_samples", "type": "List[DataSample]"}],
      "output": [{"name": "data_samples", "type": "List[DataSample]"}],
      "deploy": {"local": {"module": "highlighter.agent.capabilities"}}
    },
    {
      "name": "Print",
      "parameters": {},
      "input": [],
      "output": [],
      "deploy": {"local": {"module": "highlighter.agent.capabilities.targets"}}
    }
  ]
}
```

### Detection pipeline with file output

```json
{
  "version": 0,
  "name": "p_detect_and_save",
  "runtime": "python",
  "graph": ["(ImageDataSource MockDetector EntityWriteFile)"],
  "elements": [
    {
      "name": "ImageDataSource",
      "parameters": {},
      "input": [{"name": "data_samples", "type": "List[DataSample]"}],
      "output": [{"name": "data_samples", "type": "List[DataSample]"}],
      "deploy": {"local": {"module": "highlighter.agent.capabilities"}}
    },
    {
      "name": "MockDetector",
      "parameters": {},
      "input": [{"name": "data_samples", "type": "List[DataSample]"}],
      "output": [{"name": "entities", "type": "dict"}],
      "deploy": {"local": {"module": "highlighter.agent.capabilities.mock_detector"}}
    },
    {
      "name": "EntityWriteFile",
      "parameters": {"output_path": ".pipelines/output.json"},
      "input": [{"name": "entities", "type": "dict"}],
      "output": [],
      "deploy": {"local": {"module": "highlighter.agent.capabilities.targets"}}
    }
  ]
}
```

### Custom edge mapping (branching graph)

```json
{
  "version": 0,
  "name": "p_branching",
  "runtime": "python",
  "#": "  A ----> B ----> D",
  "#": "  +----> C ------^",
  "graph": ["(A (B D) (C D))"],
  "elements": [
    {"name": "A", "input": [], "output": [], "deploy": {"local": {"module": "my_project.elements"}}},
    {"name": "B", "input": [], "output": [], "deploy": {"local": {"module": "my_project.elements"}}},
    {"name": "C", "input": [], "output": [], "deploy": {"local": {"module": "my_project.elements"}}},
    {"name": "D", "input": [], "output": [], "deploy": {"local": {"module": "my_project.elements"}}}
  ]
}
```
