# Aiko Runtime Reference

Detailed internals of how the Aiko pipeline runtime loads elements, creates streams/frames, and routes data between elements.

## How input/output names are used

- **Inputs** (`_process_map_in`): The runtime iterates over the element's `input` array and looks up each `input["name"]` in the accumulated frame data ("swag"). Only matching keys are passed as keyword arguments to `process_frame()`. Missing keys are silently skipped. Edge definitions can remap predecessor outputs to input names.
- **Outputs** (`_process_map_out`): For each declared output name found in the return dict, the runtime adds `ElementName.output_name` as a qualified alias in the frame data, enabling explicit edge mapping.

## How element loading works

1. The runtime reads `deploy.local.module` and loads it via `importlib`
2. It does `getattr(module, class_name)` where `class_name` defaults to the element `name`
3. The class must be a `PipelineElement` subclass (typically `Capability` from the Highlighter SDK)
4. Elements not referenced in the `graph` are skipped with a warning

## How streams and frames are created

1. `create_stream()` walks graph nodes calling `element.start_stream()` on each
2. The data source's `start_stream()` resolves `data_sources` (file paths, URLs, etc.) and spawns a frame generator thread
3. The generator loops calling `frame_generator(stream, frame_id)` which loads data into a frame dict (e.g. `{"data_samples": [...], "entities": {}}`) and returns `(StreamEvent, frame_data)`
4. Each frame triggers `process_frame()` on the full pipeline graph
5. Continues until `StreamEvent.STOP` or error

The `rate` parameter controls frame generation speed (FPS). Default: as fast as possible with back-pressure via mailbox queue. The `batch_size` parameter controls how many data samples per frame.

## How data flows between elements

The runtime maintains a frame data dict ("swag") that accumulates through the pipeline:

1. Data source creates initial frame data
2. For each element: `_process_map_in` filters swag to matching `input` names, passes as kwargs to `process_frame(self, stream, **inputs)`
3. `process_frame` returns `(StreamEvent, output_dict)`
4. `_process_map_out` creates qualified aliases (`ElementName.output_name`) in frame data
5. `output_dict` merges into swag
6. Next element's inputs resolve from updated swag
