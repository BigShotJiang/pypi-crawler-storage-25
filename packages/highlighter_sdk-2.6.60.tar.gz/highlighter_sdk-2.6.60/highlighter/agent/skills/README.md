Skills used by Highlighter Agents

---
name: writing-pipeline-definitions
file: ./writing-pipeline-definitions/SKILL.md
description: Creates Highlighter agent pipeline definition JSON files. Use when building new pipelines, configuring processing elements, or setting up data flow between sources, detectors, classifiers, and output targets.
---


