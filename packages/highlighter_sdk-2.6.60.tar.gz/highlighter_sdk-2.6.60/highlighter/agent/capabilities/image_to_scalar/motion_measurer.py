"""Motion measurement using optical flow."""

import logging
import warnings
from collections import deque
from pathlib import Path
from typing import Dict, List, Literal, Optional, Tuple, TypeAlias, Union
from uuid import UUID

from highlighter.core.exceptions import require_package

try:
    import matplotlib.pyplot as plt
except ModuleNotFoundError as _:
    plt = None

import cv2
import numpy as np
from pydantic import BaseModel, PrivateAttr, model_validator

from highlighter.agent.capabilities import Capability, StreamEvent
from highlighter.agent.capabilities.image_to_scalar._neuflowv2 import (
    NeuFlowV2,
    flow_to_image,
)
from highlighter.client.base_models.annotation import Annotation
from highlighter.client.base_models.entity import Entity
from highlighter.client.base_models.observation import Observation
from highlighter.core import LabeledUUID
from highlighter.core.data_models import DataSample

__all__ = ["MotionMeasurer", "OpticalFlow", "MotionMeasurerCapability"]


DEFAULT_MODEL_PATH = Path.home() / ".cache" / "highlighter" / "models" / "neuflow_sintel.onnx"

VALID_SCORE_TYPES = ("mean", "median", "sum")
SCORE_TYPE: TypeAlias = Literal["mean", "median", "sum"]


class OpticalFlow(BaseModel):
    """
    A standalone optical flow class that calculates motion between consecutive frames.

    All preprocessing (Gaussian blur, resize) is handled inside the ONNX model,
    making this class a thin wrapper around NeuFlowV2.

    Args:
        model_path: Path to the optical flow model file.
        use_gpu: Whether to use GPU for inference.
        blur_kernel_size: Size of Gaussian blur kernel (3, 5, 7) or None to disable blur.
        resize_input_to_model_shape: Whether preprocessing resizes inputs to model resolution.
        resize_output_to_input_shape: Whether postprocessing resizes flow back to input resolution.
    """

    model_path: Union[str, Path]
    use_gpu: bool
    blur_kernel_size: Optional[int]
    resize_input_to_model_shape: bool
    resize_output_to_input_shape: bool

    @model_validator(mode="after")
    def init(self):
        self._logger = logging.getLogger(__name__)
        self._estimator = self._load_model()
        self._logger.info(f"Initialized OpticalFlow (use_gpu={self.use_gpu}, blur={self.blur_kernel_size})")

        return self

    def _load_model(self) -> NeuFlowV2:
        """Load the NeuFlowV2 optical flow model."""

        return NeuFlowV2(
            str(self.model_path),
            use_gpu=self.use_gpu,
            blur_kernel_size=self.blur_kernel_size,
            resize_input_to_model_shape=self.resize_input_to_model_shape,
            resize_output_to_input_shape=self.resize_output_to_input_shape,
        )

    def update(
        self, prev_image: Optional[np.ndarray], curr_image: np.ndarray
    ) -> Tuple[Optional[np.ndarray], np.ndarray]:
        """
        Compute optical flow against the previously prepared frame.

        `curr_image` is normalized into the format expected by the NeuFlow model
        and returned so the caller can store it and pass it back as
        `prev_image` on the next call. `prev_image` is assumed to already be in
        that prepared form; this method does not reprocess it.

        Passing `prev_image=None` indicates the first frame in a sequence. In
        that case no flow can be computed yet, so the method returns
        `(None, prepared_curr_image)`.

        Args:
            prev_image: The previously returned prepared frame, or `None` for
                the first frame in a sequence.
            curr_image: The current raw image frame.

        Returns:
            A tuple of `(flow_vectors, prepared_curr_image)`, where
            `flow_vectors` is `None` on the first frame and otherwise contains
            the dense optical flow from `prev_image` to `curr_image`.
        """
        # Ensure uint8
        if curr_image.dtype != np.uint8:
            curr_image = (
                (curr_image * 255).astype(np.uint8)
                if curr_image.max() <= 1.0
                else curr_image.astype(np.uint8)
            )

        if not self.resize_input_to_model_shape:
            curr_image = cv2.resize(curr_image, self._estimator._original_wh, interpolation=cv2.INTER_LINEAR)

        if prev_image is None:
            return None, curr_image

        flow_vectors = self._estimator(prev_image, curr_image)

        return flow_vectors, curr_image

    @staticmethod
    def draw_flow(curr_frame: np.ndarray, flow: np.ndarray, step: int = 10) -> np.ndarray:
        """
        Draw optical flow vectors on a frame.

        Uses the Middlebury color scheme via flow_to_image and overlays on the frame.

        Args:
            curr_frame: Current frame (H, W, 3) uint8 array.
            flow: Optical flow (H, W, 2) float32 array.
            step: Grid step for sampling flow vectors.

        Returns:
            Frame with flow visualization (H, W, 3) uint8 array.
        """
        # Create flow color image
        flow_img = flow_to_image(flow)

        # Blend with original frame
        alpha = 0.6
        blended = (alpha * flow_img + (1 - alpha) * curr_frame).astype(np.uint8)

        return blended


class MotionMeasurer(BaseModel):
    """
    Compute motion measurement from video frames via optical flow.

    Usage:
        mm = MotionMeasurer(score_type=["mean", "median"], window_size=10)
        for idx, frame in enumerate(frame_generator):
            scores = mm.update(frame, idx)
            # {'mean': 0.23, 'median': 0.19}
    """

    score_type: List[SCORE_TYPE] = ["mean"]
    window_size: int = 20
    history_size: int = 40
    optical_flow: OpticalFlow

    @model_validator(mode="after")
    def init(self):
        self._optical_flow_model = self.optical_flow

        self._score_names = VALID_SCORE_TYPES

        _score_fns = {
            "sum": lambda vals: float(np.sum(vals)),
            "mean": lambda vals: float(np.mean(vals)),
            "median": lambda vals: float(np.median(vals)),
        }
        self._score_fns = {t: _score_fns[t] for t in self.score_type}
        self._motion_averages = {t: MovingAverage(self.window_size) for t in self.score_type}
        self._frame_idxs = deque(maxlen=self.history_size)
        self._motion_averages_history = {t: deque(maxlen=self.history_size) for t in self.score_type}
        self._flow_vectors = None
        self._logger = logging.getLogger(__name__)
        self._logger.info(
            f"MotionMeasurer init with: id(OpticalFlow)={id(self.optical_flow)}, score_fns: {self._score_fns.keys()}"
        )
        return self

    def _update_motion_scores(self, flow_vectors: np.ndarray):
        u, v = flow_vectors[..., 0], flow_vectors[..., 1]
        magnitude = np.sqrt(u**2 + v**2)
        motion_scores = {t: self._score_fns[t](magnitude) for t in self.score_type}

        for t in self.score_type:
            self._motion_averages[t].update(motion_scores[t])

        for k, v in self._motion_averages.items():
            self._motion_averages_history[k].append(v.get_average())

    def get_latest_flow_vectors(self):
        return self._flow_vectors

    def update(
        self, prev_image: Optional[np.ndarray], curr_image: np.ndarray, frame_idx: int
    ) -> Tuple[Dict[str, float], np.ndarray]:
        """
        Update motion scores for a frame and return the next cached image.

        This wraps `OpticalFlow.update()` and preserves the same prepared-frame
        contract: callers should keep the returned image and pass it back as
        `prev_image` on the next frame. Motion scores are only updated once
        optical flow is available, so the first frame returns zeros for every
        configured score type.

        Args:
            prev_image: The prepared previous frame returned by the prior call,
                or `None` for the first frame.
            curr_image: The current raw image frame.
            frame_idx: Frame index associated with `curr_image`.

        Returns:
            A tuple of `(scores, prepared_curr_image)`. `scores` contains the
            latest moving-average value for each configured score type, or
            zeros when no previous frame is available yet.
        """
        flow_vectors, new_prev_image = self._optical_flow_model.update(prev_image, curr_image)
        self._flow_vectors = flow_vectors

        if flow_vectors is None:
            return {k: 0.0 for k in self.score_type}, new_prev_image

        self._frame_idxs.append(frame_idx)
        self._update_motion_scores(flow_vectors)

        return {k: v[-1] for k, v in self._motion_averages_history.items()}, new_prev_image

    @require_package(plt, "matplotlib", "matplotlib")
    def get_motion_score_fig(self, select: Optional[List[str]] = None, width: int = 600, height: int = 550):
        plt.style.use("dark_background")

        if select is None:
            select = list(self._motion_averages.keys())

        assert all([s in self._motion_averages for s in select])

        fig, axies = plt.subplots(len(select), 1, figsize=(width / 100, height / 100), dpi=100)
        if not isinstance(axies, np.ndarray):
            axies = [axies]

        plot_colors = {
            "sum": "#00BFFF",
            "mean": "#00FF7F",
            "median": "#FFD700",
        }
        plot_colors = {k: plot_colors[k] for k in select}

        for i, (key, color) in enumerate(plot_colors.items()):
            ax = axies[i]
            scores = self._motion_averages_history[key]

            ax.plot(self._frame_idxs, scores, color=color, linewidth=2, alpha=0.9)
            ax.fill_between(self._frame_idxs, scores, alpha=0.3, color=color)

            ax.set_title(
                f"Movement Score ({key.title()})",
                fontsize=20,
                color="white",
                fontweight="bold",
            )
            ax.set_ylabel(key.title(), fontsize=20, color="white")
            ax.grid(True, alpha=0.4, color="gray", linestyle="-", linewidth=0.8)
            ax.set_facecolor("black")
            ax.tick_params(colors="white", labelsize=20)

        axies[-1].set_xlabel("Frame", fontsize=7, color="white")

        fig.patch.set_facecolor("black")
        fig.patch.set_alpha(0.9)
        plt.tight_layout()
        return fig


class MovingAverage:
    def __init__(self, window_size):
        if window_size <= 0:
            raise ValueError("Window size must be positive")
        self.window_size = window_size
        self.values = []
        self.sum = 0.0

    def update(self, value):
        self.values.append(value)
        self.sum += value

        if len(self.values) > self.window_size:
            self.sum -= self.values.pop(0)

        return self.get_average()

    def get_average(self):
        if not self.values:
            return 0.0
        return self.sum / len(self.values)


class MotionMeasurerCapability(Capability):
    class InitParameters(Capability.InitParameters):
        attribute_id: UUID
        object_class_id: UUID | str

        class OpticalFlowArgs(BaseModel):
            model_path: Union[str, Path] = DEFAULT_MODEL_PATH
            use_gpu: bool = True
            blur_kernel_size: Optional[int] = 3
            resize_input_to_model_shape: bool = True
            resize_output_to_input_shape: bool = True

        optical_flow: OpticalFlowArgs = OpticalFlowArgs()

        score_type: SCORE_TYPE = "mean"
        window_size: int = 20

    class StreamParameters(InitParameters):
        entity_id: UUID
        crop: Optional[Tuple[float, float, float, float]] = None

    def __init__(self, context):
        super().__init__(context)

        if "|" in self.init_parameters.object_class_id:
            self.object_class_id = LabeledUUID.from_str(self.init_parameters.object_class_id)
        else:
            self.object_class_id = LabeledUUID.from_str(f"{self.init_parameters.object_class_id}|-")
        self._optical_flow_model = OpticalFlow(**self.init_parameters.optical_flow.model_dump())

    def start_stream(self, stream, stream_id, use_create_frame=True):
        kwargs = {
            "score_type": [self.init_parameters.score_type],
            "window_size": self.init_parameters.window_size,
            "optical_flow": self._optical_flow_model,
        }
        stream.variables["_motion_score_model"] = MotionMeasurer(**kwargs)
        stream.variables["optical_flow_prev_image"] = None
        return super().start_stream(stream, stream_id, use_create_frame=use_create_frame)

    def stop_stream(self, stream, stream_id):
        return super().stop_stream(stream, stream_id)

    def process_frame(
        self, stream, data_samples: List[DataSample], **kwargs
    ) -> Tuple[StreamEvent, Union[Dict, str]]:
        parameters = self.stream_parameters(stream.stream_id)
        if len(data_samples) > 1:
            self.logger.warning(
                f"Expected only a single DataFile, got {len(data_samples)}. Processing data_samples[0] only."
            )

        ds = data_samples[0]
        w, h = ds.wh

        if parameters.crop is not None:
            if isinstance(parameters.crop[0], float):
                x0 = int(parameters.crop[0] * w)
                y0 = int(parameters.crop[1] * h)
                x1 = int(parameters.crop[2] * w)
                y1 = int(parameters.crop[3] * h)
                anno_tuple = (x0, y0, x1, y1)
            else:
                anno_tuple = parameters.crop
            curr_image = ds.crop_content([parameters.crop])[0]
        else:
            anno_tuple = (0, 0, w, h)
            curr_image = ds.content

        prev_image = stream.variables["optical_flow_prev_image"]
        scores, new_prev_image = stream.variables["_motion_score_model"].update(
            prev_image, curr_image, ds.media_frame_index
        )
        score = scores[parameters.score_type]
        stream.variables["optical_flow_prev_image"] = new_prev_image

        # Label the attribute with the score_type so different score variants
        # (mean / median / sum) don't collide and so RuleTrigger expressions
        # can target a specific variant via `attribute.motion_score_<score_type>.value`.
        attribute_label = f"motion_score_{parameters.score_type}"
        attribute_id = LabeledUUID.from_str(f"{parameters.attribute_id}|{attribute_label}")
        score_obs = Observation.make_scalar_observation(
            score,
            attribute_id,
            occurred_at=ds.recorded_at,
            pipeline_element_name=self.name,
            frame_id=ds.media_frame_index,
        )
        obj_obs = Observation.make_object_class_observation(
            object_class_uuid=self.object_class_id,
            object_class_value=self.object_class_id.label,
            confidence=1.0,
            occurred_at=ds.recorded_at,
            pipeline_element_name=self.name,
            frame_id=ds.media_frame_index,
        )
        a = Annotation.from_left_top_right_bottom_box(
            anno_tuple,
            1.0,
            data_sample=ds,
            observations=[score_obs, obj_obs],
        )

        entity = Entity(id=parameters.entity_id, annotations=[a])
        entities = {parameters.entity_id: entity}

        for entity_id, entity in entities.items():
            for anno in entity.annotations:
                for obs in anno.observations:
                    if hasattr(obs, "attribute_id") and attribute_label in str(obs.attribute_id):
                        self.logger.verbose(
                            f"motion_measurer output: entity={entity_id}, frame={obs.datum_source.frame_id}, attr={obs.attribute_id}, value={obs.value}, type={type(obs.value)}"
                        )

        return StreamEvent.OKAY, {"entities": entities}
