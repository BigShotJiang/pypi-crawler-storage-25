"""Rolling observation store used by agent triggers and prompt-building code.

This file is the canonical reference for how observation rows are created,
merged, purged, and queried with CEL.

Population
----------
- The runtime agent owns one long-lived ``ObservationsTable`` per agent run.
- During frame completion the agent calls ``add_entity(entity, data_sample,
  stream_id)`` for every entity emitted by upstream capabilities.
- If a frame produces no entities, the agent calls ``add_data_sample(...)`` so
  CEL expressions that only reference ``data_sample`` can still evaluate.
- ``add_entity`` converts every annotation/global observation on the entity into
  one or more ``Row`` objects via ``row_data_from_entity``.

Snapshot semantics
------------------
- ``_rows`` stores the current queryable rows keyed by ``snapshot_id``.
- Rows for the same logical entity are merged when their timestamps are within
  ``merge_window_seconds`` of an existing snapshot for that entity.
- A merged snapshot keeps the newest contributing row as the representative
  ``data_sample``/timestamp while attributes are merged field-by-field.
- Snapshot rows can therefore contain attributes contributed by multiple
  streams, and ``row.stream`` is a list of every contributing stream id.

Purging
-------
- The runtime agent periodically calls ``prune_before(cutoff)`` using the
  newest frame timestamp minus the configured observation window.
- Purging removes snapshot rows whose representative ``occurred_at`` is older
  than ``cutoff`` and rebuilds the internal indexes from the surviving rows.
- ``clear()`` is stronger than pruning: it drops every row, compiled CEL
  program, and snapshot index.

Query semantics
---------------
- CEL queries run against the latest snapshot per entity, not every historical
  contribution stored before merging.
- The row shape exposed to CEL is:
  ``id``, ``entity.id``, ``stream.id``, ``occurred_at``, ``content_type``,
  ``data_sample.*``, and ``attribute.<name>.{value, occurred_at, confidence}``.
- Missing attributes are materialized as ``None`` values for every row, so
  expressions like ``attribute.speed.value > 2`` work consistently across
  heterogeneous rows.
- ``filter(expr)`` returns the matching ``Row`` objects.
- ``any(expr)`` returns ``True`` on the first matching row.
- ``all(expr)`` returns ``False`` on the first non-match or CEL evaluation
  error.
- For ``filter`` and ``any``, CEL evaluation errors are treated as non-matches
  for that row. This lets queries tolerate sparse data.

Practical guidance for CEL authors
----------------------------------
- Prefer row-local predicates such as
  ``attribute.object_class.value.name == 'person'`` or
  ``data_sample.media_frame_index >= 100``.
- When querying optional attributes, guard comparisons with null checks if the
  operator is not naturally tolerant of ``None``.
- Remember that queries see the latest merged snapshot per entity, so they are
  best for "what is true about each entity now?" rather than historical scans.
"""

import logging
from datetime import UTC, datetime
from typing import Dict, List, Optional, Set, Union
from uuid import UUID, uuid4

import celpy
from pydantic import BaseModel, Field, computed_field, field_validator

from highlighter.core.enums import ContentTypeEnum
from highlighter.core.labeled_uuid import LabeledUUID

# ToDo: Consolidate this work with the data layer
# ToDo: Consolidate this work with the Entities object and Agents
# ToDo: Consolidate this work with Datasets

__all__ = ["ObservationsTable"]

logger = logging.getLogger(__name__)


class DotDict(dict):
    """
    Dictionary with dot notation access and recursive conversion.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def __getattr__(self, key):
        if key in self:
            return self[key]
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{key}'")

    def __setattr__(self, key, value):
        self[key] = value

    def __delattr__(self, key):
        if key in self:
            del self[key]
        else:
            raise AttributeError(f"'{type(self).__name__}' object has no attribute '{key}'")

    def __repr__(self):
        return f"Attribtues({dict.__repr__(self)})"


class ObservationsTable:
    """Mutable rolling table of merged observation snapshots.

    The table acts like a per-agent sliding window over entity observations.
    Runtime code continuously appends new entity data, prunes old snapshots, and
    then evaluates CEL expressions against the latest row for each entity.
    """

    class Row(BaseModel):
        model_config = {"arbitrary_types_allowed": True}

        class DataSample(BaseModel):
            recorded_at: datetime
            stream_frame_index: int
            media_frame_index: int
            width: Optional[int] = None
            height: Optional[int] = None

        class Attribute(BaseModel):
            class Category(BaseModel):
                id: UUID
                name: str

            value: Union[int, float, str, Category]
            occurred_at: Optional[datetime] = None
            confidence: Optional[float] = None

            @field_validator("value", mode="before")
            def handel_labeled_uuid(cls, v):
                if isinstance(v, LabeledUUID):
                    return cls.Category(id=v, name=v.label)
                if isinstance(v, UUID):
                    return cls.Category(id=v, name="__UNDEFINED__")
                return v

        stream: List[str]
        entity_id: UUID
        occurred_at: datetime
        content_type: ContentTypeEnum
        data_sample: DataSample
        attribute: DotDict
        snapshot_id: Optional[str] = None
        data_source_uuids: List[UUID] = Field(default_factory=list)

        @computed_field
        @property
        def id(self) -> str:
            if self.snapshot_id is not None:
                return self.snapshot_id
            data_source_uuid = self.data_source_uuids[0] if self.data_source_uuids else UUID(int=0)
            return f"{self.entity_id}-{data_source_uuid}-{self.occurred_at.isoformat()}"

        @field_validator("attribute", mode="before")
        @classmethod
        def convert_attribute_dict(cls, v):
            # ToDo: Check this still works
            if isinstance(v, dict) or isinstance(v, DotDict):
                converted = {}
                for key, value in v.items():
                    converted[key] = value if isinstance(value, cls.Attribute) else cls.Attribute(**value)
                return DotDict(**converted)
            return v

        def to_cel_ctx_dict(self, all_attr_keys: Set[str]):
            attributes = {k: {"value": None, "occurred_at": None, "confidence": None} for k in all_attr_keys}
            for k, v in self.attribute.items():
                attributes[k] = v.model_dump(mode="json")

            return {
                "id": str(self.id),
                "entity": {"id": str(self.entity_id)},
                "stream": {"id": self.stream},
                "occurred_at": self.occurred_at.isoformat(),
                "content_type": self.content_type,
                "data_sample": self.data_sample.model_dump(mode="json"),
                "attribute": attributes,
            }

    class EntitySnapshot(BaseModel):
        snapshot_id: str
        entity_id: UUID
        anchor_time: datetime
        contributions_by_stream: Dict[str, "ObservationsTable.Row"] = Field(default_factory=dict)

    def __init__(self, rows: Optional[Dict[str, Row]] = None, merge_window_seconds: float = 2.5):
        """Create a table.

        Args:
            rows: Optional prebuilt snapshot rows keyed by snapshot id.
            merge_window_seconds: Maximum time delta for merging observations
                for the same entity into one queryable snapshot.
        """
        self._rows = rows or {}
        self._merge_window_seconds = merge_window_seconds
        self._program_cache = {}
        self._entity_stream_ids_by_entity: Dict[str, set[str]] = {}
        self._snapshot_ids_by_entity: Dict[str, List[str]] = {}
        self._snapshots_by_id: Dict[str, ObservationsTable.EntitySnapshot] = {}
        self._rebuild_entity_stream_index()

    def __getitem__(self, key):
        """Support indexing for CEL"""
        return self._rows[key]

    def __iter__(self):
        """Support iteration for CEL"""
        return iter(self._rows)

    def __len__(self):
        """Support len() for CEL"""
        return len(self._rows)

    def clear(self):
        """Remove all rows, compiled CEL programs, and merge indexes."""
        self._rows.clear()
        self._program_cache.clear()
        self._entity_stream_ids_by_entity.clear()
        self._snapshot_ids_by_entity.clear()
        self._snapshots_by_id.clear()

    def prune_before(self, cutoff: datetime):
        """Drop snapshots older than the rolling-window cutoff.

        The runtime agent usually calls this once per frame using the newest
        observed timestamp minus the configured observation window. Pruning is
        based on the snapshot row's representative ``occurred_at`` timestamp.
        """
        self._rows = {row_id: row for row_id, row in self._rows.items() if row.occurred_at >= cutoff}
        self._snapshots_by_id = {
            snapshot_id: snapshot
            for snapshot_id, snapshot in self._snapshots_by_id.items()
            if snapshot_id in self._rows
        }
        self._snapshot_ids_by_entity = {}
        for snapshot_id, row in self._rows.items():
            self._snapshot_ids_by_entity.setdefault(str(row.entity_id), []).append(snapshot_id)
        self._rebuild_entity_stream_index()

    def has_values_for_attributes(self, attribute_names: Set[str]) -> bool:
        """Return True once every required attribute has at least one non-null value."""
        if not attribute_names:
            return True

        available = set()
        for row in self._rows.values():
            for name in attribute_names:
                attr = row.attribute.get(name)
                if attr is not None and attr.value is not None:
                    available.add(name)

        return attribute_names.issubset(available)

    def add_data_sample(self, data_sample, stream_id):
        """Add a placeholder row for frames with no entities.

        This keeps ``data_sample.*`` CEL queries evaluable even when upstream
        capabilities emitted nothing for the frame.
        """
        data_sample_row = ObservationsTable.Row(
            stream=[stream_id if stream_id else "unknown"],
            entity_id=UUID(int=0),
            occurred_at=data_sample.recorded_at,
            content_type=data_sample.content_type,
            data_sample=ObservationsTable.Row.DataSample(
                recorded_at=data_sample.recorded_at,
                stream_frame_index=data_sample.stream_frame_index,
                media_frame_index=data_sample.media_frame_index,
            ),
            attribute={},
            data_source_uuids=[getattr(data_sample, "data_file_id", None) or UUID(int=0)],
        )
        self._rows[str(data_sample_row.id)] = data_sample_row

    @classmethod
    def from_row_records(cls, records):
        table = cls()
        for r in records:
            row = ObservationsTable.Row(**r)
            snapshot_id = row.snapshot_id or str(row.id)
            row.snapshot_id = snapshot_id
            table._rows[snapshot_id] = row
            table._snapshots_by_id[snapshot_id] = ObservationsTable.EntitySnapshot(
                snapshot_id=snapshot_id,
                entity_id=row.entity_id,
                anchor_time=row.occurred_at,
                contributions_by_stream={stream_id: row for stream_id in row.stream},
            )
            table._snapshot_ids_by_entity.setdefault(str(row.entity_id), []).append(snapshot_id)
        table._rebuild_entity_stream_index()
        return table

    def get_cel_ctx_rows(self):
        # Collect all attribute keys across all rows
        all_attr_keys = set()
        for r in self._rows.values():
            all_attr_keys.update(r.attribute.keys())

        for r in self._rows.values():
            yield celpy.json_to_cel(r.to_cel_ctx_dict(all_attr_keys))

    def _rebuild_entity_stream_index(self):
        self._entity_stream_ids_by_entity = {}
        for row in self._rows.values():
            self._update_entity_stream_index(row)

    def _update_entity_stream_index(self, row):
        entity_id = str(row.entity_id)
        stream_ids = self._entity_stream_ids_by_entity.setdefault(entity_id, set())
        stream_ids.update(row.stream)

    def _find_matching_snapshot_id(self, incoming: Row) -> Optional[str]:
        entity_id = str(incoming.entity_id)
        candidate_ids = self._snapshot_ids_by_entity.get(entity_id, [])
        best_snapshot_id = None
        best_delta = None

        for snapshot_id in candidate_ids:
            snapshot = self._snapshots_by_id.get(snapshot_id)
            if snapshot is None:
                continue
            delta = abs((incoming.occurred_at - snapshot.anchor_time).total_seconds())
            if delta > self._merge_window_seconds:
                continue
            if best_delta is None or delta < best_delta:
                best_snapshot_id = snapshot_id
                best_delta = delta

        return best_snapshot_id

    @staticmethod
    def _row_data_source_uuids(row: Row) -> List[UUID]:
        return row.data_source_uuids

    def _rebuild_snapshot_row(self, snapshot_id: str):
        snapshot = self._snapshots_by_id[snapshot_id]
        contributions = list(snapshot.contributions_by_stream.values())
        representative = sorted(contributions, key=lambda row: row.occurred_at)[-1]

        merged_attributes = DotDict()
        merged_streams: Set[str] = set()
        merged_data_source_uuids: Set[UUID] = set()

        for contribution in sorted(contributions, key=lambda row: row.occurred_at):
            merged_streams.update(contribution.stream)
            merged_data_source_uuids.update(self._row_data_source_uuids(contribution))

            for attr_key, incoming_attr in contribution.attribute.items():
                existing_attr = merged_attributes.get(attr_key)
                if existing_attr is None:
                    merged_attributes[attr_key] = incoming_attr
                    continue
                try:
                    merged_attributes[attr_key] = self._merge_attribute_value(existing_attr, incoming_attr)
                except ValueError:
                    logger.warning(
                        "Conflicting attribute '%s' for entity snapshot %s. Overriding existing value with incoming value. existing_value=%r incoming_value=%r winner_streams=%s",
                        attr_key,
                        snapshot_id,
                        existing_attr.value,
                        incoming_attr.value,
                        contribution.stream,
                    )
                    merged_attributes[attr_key] = incoming_attr

        self._rows[snapshot_id] = ObservationsTable.Row(
            snapshot_id=snapshot_id,
            stream=sorted(merged_streams),
            entity_id=snapshot.entity_id,
            occurred_at=representative.occurred_at,
            content_type=representative.content_type,
            data_sample=representative.data_sample,
            attribute=merged_attributes,
            data_source_uuids=sorted(merged_data_source_uuids, key=str),
        )
        self._update_entity_stream_index(self._rows[snapshot_id])

    def get_entity_stream_ids(self, entity_id: Optional[str]) -> list[str]:
        if entity_id is None:
            return []
        return sorted(self._entity_stream_ids_by_entity.get(entity_id, set()))

    def _get_latest_entity_rows(self):
        if not self._rows:
            return []

        latest_rows: Dict[str, ObservationsTable.Row] = {}

        for row in self._rows.values():
            key = str(row.entity_id)
            current = latest_rows.get(key)

            if current is None or row.occurred_at >= current.occurred_at:
                latest_rows[key] = row

        return list(latest_rows.values())

    def _iter_latest_entity_rows_with_ctx(self):
        latest_rows = self._get_latest_entity_rows()
        all_attr_keys = set()
        for row in latest_rows:
            all_attr_keys.update(row.attribute.keys())

        for row in latest_rows:
            yield row, celpy.json_to_cel(row.to_cel_ctx_dict(all_attr_keys))

    def _get_compiled_program(self, expr):
        program = self._program_cache.get(expr)
        if program is not None:
            return program

        env = celpy.Environment()
        ast = env.compile(expr)
        program = env.program(ast)
        self._program_cache[expr] = program
        return program

    def filter(self, expr):
        """Return the latest entity rows whose CEL expression evaluates truthy.

        CEL runs against one merged snapshot per entity. Evaluation errors on a
        row are treated as a non-match for that row.
        """
        program = self._get_compiled_program(expr)

        # Evaluate each row individually and catch errors
        result = []
        for row, row_ctx in self._iter_latest_entity_rows_with_ctx():
            try:
                # Evaluate expression with row fields directly in context
                matches = program.evaluate(row_ctx)
                if matches:
                    result.append(row)
            except (celpy.evaluation.CELEvalError, TypeError):
                # If evaluation fails (e.g., None comparison), treat as non-matching
                pass

        return result

    def any(self, expr):
        """
        Return ``True`` if any latest entity row matches the CEL expression.

        Args:
            expr: A CEL expression to evaluate against each latest entity row.

        Returns:
            bool: True if at least one row matches, False otherwise
        """
        program = self._get_compiled_program(expr)

        for _, row_ctx in self._iter_latest_entity_rows_with_ctx():
            try:
                matches = program.evaluate(row_ctx)
                if matches:
                    return True
            except (celpy.evaluation.CELEvalError, TypeError):
                # If evaluation fails, treat as non-matching
                pass

        return False

    def all(self, expr):
        """
        Return ``True`` if all latest entity rows match the CEL expression.

        Args:
            expr: A CEL expression to evaluate against each latest entity row.

        Returns:
            bool: True if all rows match, False otherwise
        """
        program = self._get_compiled_program(expr)

        for _, row_ctx in self._iter_latest_entity_rows_with_ctx():
            try:
                matches = program.evaluate(row_ctx)
                if not matches:
                    return False
            except (celpy.evaluation.CELEvalError, TypeError) as e:
                # If evaluation fails, treat as non-matching
                logger.warning("CEL evaluation failed: %s", e)
                return False

        return True

    def show(self, latest=True, log_extra=None):
        """Log a tabular representation of the rows"""
        if not self._rows:
            logger.info("Empty Observations Table", extra=log_extra)
            return
        if latest:
            rows = self._get_latest_entity_rows()
        else:
            rows = list(self._rows.values())
        rows = list(rows)

        # Collect all attribute keys across all rows
        all_attr_keys = sorted(set(key for row in rows for key in row.attribute.keys()))

        # Define columns: id, entity_id, stream_id, recorded_at, then attributes
        columns = ["id", "entity_id", "stream_id", "recorded_at"] + all_attr_keys

        # Calculate column widths
        col_widths = {col: len(col) for col in columns}

        def get_attr_value_str(attr) -> str:
            attr_val = attr["value"] if isinstance(attr, dict) else attr.value

            if isinstance(attr_val, float):
                value_str = f"{attr_val:.3f}"
            else:
                value_str = str(attr_val)
            return value_str

        # Update widths based on data
        for row in rows:
            col_widths["id"] = max(col_widths["id"], len(str(row.id)[:8]))
            entity_id_str = str(row.entity_id)[:8]
            col_widths["entity_id"] = max(col_widths["entity_id"], len(entity_id_str))
            col_widths["stream_id"] = max(col_widths["stream_id"], len(",".join(row.stream)))
            col_widths["recorded_at"] = max(
                col_widths["recorded_at"], len(row.occurred_at.strftime("%Y-%m-%d %H:%M"))
            )

            for attr_key in all_attr_keys:
                attr = row.attribute.get(attr_key)
                if attr:
                    value_str = get_attr_value_str(attr)

                    col_widths[attr_key] = max(col_widths[attr_key], len(value_str))

        # Build header
        header = " | ".join(col.ljust(col_widths[col]) for col in columns)
        separator = "-" * len(header)

        # Build all rows
        rows_output = []
        for row in rows:
            row_data = []
            row_data.append(str(row.id)[:8].ljust(col_widths["id"]))
            entity_id_str = str(row.entity_id)[:8]
            row_data.append(entity_id_str.ljust(col_widths["entity_id"]))
            row_data.append(",".join(row.stream).ljust(col_widths["stream_id"]))
            row_data.append(row.occurred_at.strftime("%Y-%m-%d %H:%M").ljust(col_widths["recorded_at"]))

            for attr_key in all_attr_keys:
                attr = row.attribute.get(attr_key)
                if attr:
                    value_str = get_attr_value_str(attr)
                    row_data.append(value_str.ljust(col_widths[attr_key]))
                else:
                    row_data.append("".ljust(col_widths[attr_key]))

            rows_output.append(" | ".join(row_data))

        # Log the entire table as a single message
        table_output = "\n".join([header, separator] + rows_output[-15:])
        logger.info(f"Observations Table (tail 15 of {len(rows)}):\n{table_output}", extra=log_extra)

    def add_entity(self, entity, data_sample, stream_id):
        """Populate the table from one entity emitted for one frame.

        Each entity can expand into multiple candidate rows. Candidates for the
        same entity are merged into an existing snapshot when their timestamps
        fall within ``merge_window_seconds`` of that snapshot's anchor time;
        otherwise a new snapshot is created.
        """
        new_rows = [
            ObservationsTable.Row(**r)
            for r in ObservationsTable.row_data_from_entity(entity, data_sample, stream_id)
        ]
        for row in new_rows:
            snapshot_id = self._find_matching_snapshot_id(row)
            if snapshot_id is not None:
                self._merge_row_into(snapshot_id, row)
            else:
                snapshot_id = str(uuid4())
                row.snapshot_id = snapshot_id
                self._rows[snapshot_id] = row
                self._snapshots_by_id[snapshot_id] = ObservationsTable.EntitySnapshot(
                    snapshot_id=snapshot_id,
                    entity_id=row.entity_id,
                    anchor_time=row.occurred_at,
                    contributions_by_stream={stream_id: row for stream_id in row.stream},
                )
                self._snapshot_ids_by_entity.setdefault(str(row.entity_id), []).append(snapshot_id)
                self._update_entity_stream_index(row)
                logger.info(
                    "Created entity snapshot %s entity_id=%s anchor_time=%s stream=%s",
                    snapshot_id,
                    row.entity_id,
                    row.occurred_at.isoformat(),
                    row.stream,
                )

    @staticmethod
    def _attribute_values_equal(left, right):
        left_value = left.value.model_dump(mode="json") if isinstance(left.value, BaseModel) else left.value
        right_value = (
            right.value.model_dump(mode="json") if isinstance(right.value, BaseModel) else right.value
        )
        return left_value == right_value

    @staticmethod
    def _is_placeholder_attribute_value(value):
        if isinstance(value, ObservationsTable.Row.Attribute.Category):
            return value.name in {"-", "__UNDEFINED__"}
        return value in {"-", "__UNDEFINED__"}

    def _merge_attribute_value(self, existing_attr, incoming_attr):
        if self._attribute_values_equal(existing_attr, incoming_attr):
            return existing_attr

        existing_value = existing_attr.value
        incoming_value = incoming_attr.value

        if (
            isinstance(existing_value, ObservationsTable.Row.Attribute.Category)
            and isinstance(incoming_value, ObservationsTable.Row.Attribute.Category)
            and existing_value.id == incoming_value.id
        ):
            if self._is_placeholder_attribute_value(
                existing_value
            ) and not self._is_placeholder_attribute_value(incoming_value):
                return incoming_attr
            if self._is_placeholder_attribute_value(incoming_value):
                return existing_attr

        raise ValueError

    def _merge_contribution_rows(self, snapshot_id, existing, incoming):
        merged_attributes = DotDict()

        for contribution in (existing, incoming):
            for attr_key, incoming_attr in contribution.attribute.items():
                existing_attr = merged_attributes.get(attr_key)
                if existing_attr is None:
                    merged_attributes[attr_key] = incoming_attr
                    continue
                try:
                    merged_attributes[attr_key] = self._merge_attribute_value(existing_attr, incoming_attr)
                except ValueError:
                    logger.warning(
                        "Conflicting attribute '%s' for entity snapshot %s. Overriding existing value with incoming value. existing_value=%r incoming_value=%r winner_streams=%s",
                        attr_key,
                        snapshot_id,
                        existing_attr.value,
                        incoming_attr.value,
                        incoming.stream,
                    )
                    merged_attributes[attr_key] = incoming_attr

        return ObservationsTable.Row(
            snapshot_id=existing.snapshot_id or incoming.snapshot_id,
            stream=sorted(set(existing.stream) | set(incoming.stream)),
            entity_id=existing.entity_id,
            occurred_at=max(existing.occurred_at, incoming.occurred_at),
            content_type=incoming.content_type or existing.content_type,
            data_sample=incoming.data_sample or existing.data_sample,
            attribute=merged_attributes,
            data_source_uuids=sorted(
                set(existing.data_source_uuids or []) | set(incoming.data_source_uuids or []),
                key=str,
            ),
        )

    def _merge_row_into(self, row_id, incoming):
        snapshot = self._snapshots_by_id[row_id]
        incoming_stream_id = incoming.stream[0] if incoming.stream else "unknown"
        existing = snapshot.contributions_by_stream.get(incoming_stream_id)

        logger.info(
            "Merging entity snapshot %s entity_id=%s incoming_stream=%s incoming_occurred_at=%s",
            row_id,
            snapshot.entity_id,
            incoming_stream_id,
            incoming.occurred_at.isoformat(),
        )

        if existing is not None and existing.occurred_at == incoming.occurred_at:
            logger.info(
                "Merging same-stream contribution entity_snapshot=%s stream=%s occurred_at=%s action=merge_attributes",
                row_id,
                incoming_stream_id,
                incoming.occurred_at.isoformat(),
            )
            snapshot.contributions_by_stream[incoming_stream_id] = self._merge_contribution_rows(
                row_id, existing, incoming
            )
            self._rebuild_snapshot_row(row_id)
            return

        if existing is not None and existing.occurred_at > incoming.occurred_at:
            logger.info(
                "Keeping existing stream contribution entity_snapshot=%s stream=%s existing_occurred_at=%s incoming_occurred_at=%s action=keep_existing",
                row_id,
                incoming_stream_id,
                existing.occurred_at.isoformat(),
                incoming.occurred_at.isoformat(),
            )
            return

        if existing is not None:
            logger.info(
                "Replacing stream contribution entity_snapshot=%s stream=%s existing_occurred_at=%s incoming_occurred_at=%s action=replace_with_incoming",
                row_id,
                incoming_stream_id,
                existing.occurred_at.isoformat(),
                incoming.occurred_at.isoformat(),
            )

        snapshot.contributions_by_stream[incoming_stream_id] = incoming
        self._rebuild_snapshot_row(row_id)

    @staticmethod
    def row_data_from_entity(entity, data_sample, stream_id):
        rows = []
        # Process each annotation as a separate row
        if len(entity.annotations) > 0:
            for annotation in entity.annotations:
                # Build attribute dict from annotation observations
                attributes = {}
                for obs in annotation.observations:
                    attr_label = (
                        obs.attribute_id.label
                        if hasattr(obs.attribute_id, "label")
                        else str(obs.attribute_id)
                    )
                    attributes[attr_label] = {
                        "value": obs.value,
                        "occurred_at": obs.occurred_at,
                        "confidence": obs.datum_source.confidence,
                    }

                # Add global observations to attributes
                for obs in entity.global_observations:
                    attr_label = (
                        obs.attribute_id.label
                        if hasattr(obs.attribute_id, "label")
                        else str(obs.attribute_id)
                    )
                    attributes[attr_label] = {
                        "value": obs.value,
                        "occurred_at": obs.occurred_at,
                        "confidence": obs.datum_source.confidence,
                    }

                # Build row data
                row_data = {
                    "stream": [stream_id if stream_id else "unknown"],
                    "entity_id": entity.id,
                    "occurred_at": data_sample.recorded_at,
                    "content_type": data_sample.content_type,
                    "data_sample": {
                        "recorded_at": data_sample.recorded_at,
                        "stream_frame_index": data_sample.stream_frame_index,
                        "media_frame_index": data_sample.media_frame_index,
                    },
                    "attribute": attributes,
                    "data_source_uuids": [
                        annotation.data_source_uuid
                        or getattr(data_sample, "data_file_id", None)
                        or UUID(int=0)
                    ],
                }

                rows.append(row_data)

        # If entity has no annotations but has global observations, create a row
        elif len(entity.global_observations) > 0:
            # Build attribute dict from global observations only
            attributes = {}
            for obs in entity.global_observations:
                attr_label = (
                    obs.attribute_id.label if hasattr(obs.attribute_id, "label") else str(obs.attribute_id)
                )
                attributes[attr_label] = {
                    "value": obs.value,
                    "occurred_at": obs.occurred_at,
                    "confidence": obs.datum_source.confidence,
                }

            # Build row data without annotation location
            row_data = {
                "stream": [stream_id if stream_id else "unknown"],
                "entity_id": entity.id,
                "occurred_at": data_sample.recorded_at,
                "content_type": data_sample.content_type,
                "data_sample": {
                    "recorded_at": data_sample.recorded_at,
                    "stream_frame_index": data_sample.stream_frame_index,
                    "media_frame_index": data_sample.media_frame_index,
                },
                "attribute": attributes,
                "data_source_uuids": [data_sample.data_file_id or UUID(int=0)],
            }

            rows.append(row_data)

        # Note: We no longer create placeholder rows here.
        # Empty entity cases are handled at the ObservationsTable level
        # to allow data_sample expression evaluation without fake entities.
        return rows
