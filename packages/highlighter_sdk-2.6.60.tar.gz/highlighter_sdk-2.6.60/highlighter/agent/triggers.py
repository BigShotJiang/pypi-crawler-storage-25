from __future__ import annotations

import logging
import time
from abc import abstractmethod
from collections import defaultdict
from datetime import UTC, datetime
from typing import Annotated, Any, Dict, List, Literal, Optional, Tuple, Union
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, field_validator

from highlighter.agent.observations_table import ObservationsTable
from highlighter.client.base_models.entities import Entities, Entity

logger = logging.getLogger(__name__)

__all__ = [
    "Trigger",
    "PeriodicTrigger",
    "OnCaseTrigger",
    "RuleTrigger",
    "TriggerUnion",
    "describe_trigger_firing",
]


class Trigger(BaseModel):
    capability_name: Optional[str] = None
    model_config = ConfigDict(extra="ignore")
    callbacks: Optional[List[Any]] = None
    _prev_state_by_stream: Dict[Any, bool] = PrivateAttr(default_factory=dict)

    @abstractmethod
    def get_state(self, stream, **kwargs) -> Tuple[bool, Optional[Any]]:
        """Returns True if trigger is in 'on' state, False if in 'off' state."""
        raise NotImplementedError()

    def run_callbacks(self, callback_name, *args, **kwargs):
        if self.callbacks is not None:
            for c in self.callbacks:
                callback = getattr(c, callback_name, None)
                if callback is not None:
                    callback(*args, **kwargs)

    def _should_evaluate_now(self, stream, **kwargs) -> bool:
        return True

    def evaluate(self, stream, **kwargs):
        if not self._should_evaluate_now(stream, **kwargs):
            return self._prev_state_by_stream.get(stream.stream_id, False)

        self.run_callbacks("on_evaluate", stream=stream, trigger=self, **kwargs)

        state, result_rows = self.get_state(stream, **kwargs)
        prev_state = self._prev_state_by_stream.get(stream.stream_id, False)

        if (not prev_state) and state:
            self.run_callbacks("on_trigger_on", stream=stream, rows=result_rows, trigger=self, **kwargs)
        elif prev_state and (not state):
            self.run_callbacks("on_trigger_off", stream=stream, rows=result_rows, trigger=self, **kwargs)
        self._prev_state_by_stream[stream.stream_id] = state
        return state


class PeriodicTrigger(Trigger):
    type: Literal["PeriodicTrigger"] = "PeriodicTrigger"
    on_period: float = 30.0  # sec
    off_period: float = 300.0  # sec

    _start_time: Optional[float] = None

    model_config = ConfigDict(arbitrary_types_allowed=True)

    def _is_on_period(self) -> bool:
        """Determines if the current time is within an 'on' period."""
        current_time = time.time()

        if self._start_time is None:
            self._start_time = current_time

        elapsed = current_time - self._start_time
        cycle_time = self.on_period + self.off_period

        if cycle_time <= 0:
            # Avoid division by zero; default to 'on' if periods are non-positive.
            return True

        cycle_position = elapsed % cycle_time
        return cycle_position < self.on_period

    def get_state(self, *args, **kwargs) -> Tuple[bool, Optional[Any]]:
        """Returns True if in 'on' period, False if in 'off' period."""
        return self._is_on_period(), None


class OnCaseTrigger(Trigger):
    """Return true when a case is active, false when it's not"""

    type: Literal["OnCaseTrigger"] = "OnCaseTrigger"

    def get_state(self, stream, **kwargs) -> Tuple[bool, Optional[Any]]:
        return ("create_case_task_context" in stream.variables), None


class RuleTrigger(Trigger):
    """Evaluate a CEL expression against the available trigger context."""

    type: Literal["RuleTrigger"] = "RuleTrigger"

    oporation: Literal["all", "any", "filter"] = "any"
    expression: str
    expected_entities: List[str] = Field(default_factory=list)
    expected_attributes: Optional[List[str]] = None
    observations_window_minutes: float = 1.0
    merge_window_seconds: float = 2.5
    evaluation_interval_seconds: float = 0.0
    patience: Tuple[int, int] = (0, 0)  # sec - time of consistent state before changing state (debounce)
    default_state: bool = False
    log_errors_every_n_frames: int = 100  # Log evaluation errors once every N frames (0 = always log)

    _evaluation_error_count: defaultdict = PrivateAttr(default_factory=lambda: defaultdict(int))
    _program_cache: dict = PrivateAttr(default_factory=dict)
    _current_state_by_stream: Dict[Any, bool] = PrivateAttr(default_factory=dict)
    _raw_state_by_stream: Dict[Any, bool] = PrivateAttr(default_factory=dict)
    _raw_state_since_by_stream: Dict[Any, Optional[float]] = PrivateAttr(default_factory=dict)
    _last_evaluated_at_by_stream: Dict[Any, float] = PrivateAttr(default_factory=dict)

    @field_validator("patience", mode="before")
    @classmethod
    def _coerce_patience(cls, value):
        if isinstance(value, (int, float)):
            return (value, value)
        return value

    def __init__(self, **data):
        super().__init__(**data)
        # State is tracked per stream so one stream cannot leak a debounced
        # transition or callback edge into another stream.

    def _init_stream_state(self, stream_id):
        self._current_state_by_stream.setdefault(stream_id, self.default_state)
        self._raw_state_by_stream.setdefault(stream_id, self.default_state)
        self._raw_state_since_by_stream.setdefault(stream_id, None)

    def _should_evaluate_now(self, stream, **kwargs) -> bool:
        if self.evaluation_interval_seconds <= 0:
            return True

        now = time.perf_counter()
        stream_id = stream.stream_id
        last_evaluated_at = self._last_evaluated_at_by_stream.get(stream_id)
        if last_evaluated_at is not None and (now - last_evaluated_at) < self.evaluation_interval_seconds:
            logger.debug(
                "Skipping trigger evaluation due to interval gate",
                extra={
                    "stream_id": stream_id,
                    "capability_name": self.capability_name or "RuleTrigger",
                    "color": "green",
                },
            )
            return False

        self._last_evaluated_at_by_stream[stream_id] = now
        return True

    @property
    def required_attributes(self) -> List[str]:
        """Return the columns that must exist in the rolling table before evaluation starts."""
        return self.expected_attributes or []

    def _build_local_observations_table(self, stream, data_sample, **kwargs) -> Optional[ObservationsTable]:
        """Fallback for call sites that still invoke RuleTrigger directly in tests."""
        if data_sample is None:
            return None

        is_entities = lambda x: (
            isinstance(x, Entities) or (isinstance(x, dict) and x and isinstance(x[list(x)[0]], Entity))
        )
        entity_kwargs = {k: v for k, v in kwargs.items() if is_entities(v)}

        observations_table = ObservationsTable()
        for ents in entity_kwargs.values():
            for entity in ents.values():
                observations_table.add_entity(entity, data_sample, stream.stream_id)

        if len(observations_table) == 0:
            observations_table.add_data_sample(data_sample, stream.stream_id)

        return observations_table

    def get_state(
        self, stream, *, data_sample=None, observations_table=None, **kwargs
    ) -> Tuple[bool, Optional[Any]]:
        """Return the debounced trigger state for this frame.

        `raw_state` is the immediate CEL result from the current observations.
        `_current_state` is the published state returned to callers. When those
        differ, the transition is held until `raw_state` has remained unchanged
        for the configured patience window for that direction.
        """
        # Log entry with stream info
        log_extra = {
            "stream_id": stream.stream_id,
            "capability_name": self.capability_name or "RuleTrigger",
            "color": "green",
        }
        self._init_stream_state(stream.stream_id)
        current_state = self._current_state_by_stream[stream.stream_id]
        logger.debug(
            "=== get_state() called ===",
            extra=log_extra,
        )

        # Keep a local fallback for existing direct-call sites and unit tests.
        observations_table = observations_table or self._build_local_observations_table(
            stream, data_sample, **kwargs
        )
        if observations_table is None or len(observations_table) == 0:
            logger.debug(f"s:{stream.stream_id} - no observations available", extra=log_extra)
            return current_state, None

        required_attributes = set(self.required_attributes)
        if required_attributes and not observations_table.has_values_for_attributes(required_attributes):
            logger.debug(
                f"s:{stream.stream_id} - waiting for required attributes {sorted(required_attributes)}",
                extra=log_extra,
            )
            return current_state, None

        logger.debug(f"s:{stream.stream_id} - evaluating trigger", extra=log_extra)
        logger.info(
            "Evaluating '%s' interval=%ss",
            self.expression,
            self.evaluation_interval_seconds,
            extra=log_extra,
        )

        result_rows = None
        try:
            now = time.perf_counter()
            operation_result = getattr(observations_table, self.oporation)(self.expression)
            if self.oporation == "filter":
                result_rows = [
                    row
                    for row in operation_result
                    if getattr(row, "stream", None) is None or stream.stream_id in row.stream
                ]
                new_raw_state = bool(result_rows)
            else:
                new_raw_state = bool(operation_result)

            new_debounced_state = self._debounce_state(
                stream_id=stream.stream_id,
                current_state=current_state,
                new_raw_state=new_raw_state,
                now=now,
            )
            self._log_expression_state(
                stream=stream, raw_state=new_raw_state, debounced_state=new_debounced_state
            )

        except Exception as exc:
            new_debounced_state = current_state

            # Rate-limit error logging to avoid spam
            stream_id = getattr(stream, "stream_id", "unknown")
            error_key = f"{stream_id}:{type(exc).__name__}"
            self._evaluation_error_count[error_key] += 1

            # Log on first occurrence, then every Nth frame (if configured)
            # When log_errors_every_n_frames=0, always log
            should_log = (
                self.log_errors_every_n_frames == 0
                or self._evaluation_error_count[error_key] == 1
                or self._evaluation_error_count[error_key] % self.log_errors_every_n_frames == 0
            )

            if should_log:
                logger.warning(
                    "RuleTrigger evaluation failed for '%s' (count: %d): %s",
                    self.expression,
                    self._evaluation_error_count[error_key],
                    exc,
                )

        return new_debounced_state, result_rows

    def _log_expression_state(self, *, stream, raw_state, debounced_state):
        capability_label = self.capability_name or self.__class__.__name__

        # Get current frame_id from stream
        frame_id = None
        if stream.frames and len(stream.frames) > 0:
            frame_ids = list(stream.frames.keys())
            if frame_ids:
                frame_id = frame_ids[-1]
        if raw_state:
            logger.info(
                "%s ---> evaluates to %s. debounced_state = %s",
                self.expression,
                raw_state,
                debounced_state,
                extra={
                    "stream_id": stream.stream_id,
                    "capability_name": capability_label,
                    "frame_id": frame_id,
                },
            )

    def _debounce_state(self, *, stream_id, current_state, new_raw_state, now):
        # Detect a new candidate state and start a fresh debounce window.
        prev_raw_state = self._raw_state_by_stream[stream_id]
        if new_raw_state != prev_raw_state:
            self._raw_state_by_stream[stream_id] = new_raw_state
            self._raw_state_since_by_stream[stream_id] = now

        # Once the raw state matches the published state again, there is no
        # pending transition. Reset the debounce window anchor to "now".
        debounce_state = current_state
        if new_raw_state == current_state:
            self._raw_state_since_by_stream[stream_id] = now
        else:
            patience_index = 0 if new_raw_state else 1
            patience_seconds = self.patience[patience_index]
            raw_state_since = self._raw_state_since_by_stream[stream_id]
            raw_state_since = raw_state_since if raw_state_since is not None else now

            # Commit the transition only after the raw state has stayed
            # stable long enough for this edge direction.
            if (now - raw_state_since) >= patience_seconds:
                debounce_state = new_raw_state

        self._current_state_by_stream[stream_id] = debounce_state
        return debounce_state


TriggerUnion = Annotated[Union[PeriodicTrigger, RuleTrigger], Field(discriminator="type")]


class CreateCaseTriggerCallback(BaseModel):
    new_case_workflow_order_id: UUID
    case_title_template: str = "{timestamp}_{stream_id}"
    record_all_streams: bool = False

    model_config = ConfigDict(arbitrary_types_allowed=True)
    _group_task_contexts: Dict[str, Any] = PrivateAttr(default_factory=dict)
    _active_streams_by_group: Dict[str, set[Any]] = PrivateAttr(default_factory=dict)
    _group_key_by_stream: Dict[Any, str] = PrivateAttr(default_factory=dict)
    _entity_id_by_group: Dict[str, str] = PrivateAttr(default_factory=dict)

    def _resolve_group_stream(self, agent, group_key: str):
        if not group_key.startswith("stream:"):
            return None
        stream_id = group_key.split(":", 1)[1]
        pipeline = getattr(agent, "pipeline", None)
        stream_leases = getattr(pipeline, "stream_leases", None)
        if stream_leases is None:
            return None
        lease = stream_leases.get(stream_id)
        return getattr(lease, "stream", None) if lease is not None else None

    def _cleanup_group(self, agent, group_key: str, task_context):
        self._group_task_contexts.pop(group_key, None)
        self._active_streams_by_group.pop(group_key, None)
        self._entity_id_by_group.pop(group_key, None)

        stale_stream_ids = [
            stream_id
            for stream_id, mapped_group_key in list(self._group_key_by_stream.items())
            if mapped_group_key == group_key
        ]
        for stream_id in stale_stream_ids:
            self._group_key_by_stream.pop(stream_id, None)

        group_stream = self._resolve_group_stream(agent, group_key)
        if (
            group_stream is not None
            and group_stream.variables.get("create_case_task_context") is task_context
            and not getattr(task_context, "_recording", None)
        ):
            group_stream.variables.pop("create_case_task_context", None)

    def cleanup_stream(self, agent, stream_id):
        group_key = self._group_key_by_stream.pop(stream_id, None)
        if group_key is None:
            return

        active_streams = self._active_streams_by_group.get(group_key)
        if active_streams is not None:
            active_streams.discard(stream_id)
            if active_streams:
                return
            self._active_streams_by_group.pop(group_key, None)

        task_context = self._group_task_contexts.get(group_key)
        if task_context is not None:
            task_context.stop_recording()

    def on_evaluate(self, *, stream, agent=None, **kwargs):
        if agent is None or not self._group_task_contexts:
            return

        for group_key, task_context in list(self._group_task_contexts.items()):
            try:
                task_context.finalise_submissions_on_recording_state_off()
            except Exception:
                logger.exception(
                    "CreateCaseTriggerCallback failed while finalising stopped recording",
                    extra={"stream_id": stream.stream_id, "capability_name": "CreateCaseTriggerCallback"},
                )
                continue

            if self._active_streams_by_group.get(group_key):
                continue
            if getattr(task_context, "_recording", None):
                continue

            self._cleanup_group(agent, group_key, task_context)

    def _group_key(self, stream, entity_id: Optional[str] = None) -> str:
        if self.record_all_streams:
            return "__all_streams__"
        if entity_id is not None:
            return f"entity:{entity_id}"
        return f"stream:{stream.stream_id}"

    def _get_task_context(self, stream, group_key: str):
        task_context = self._group_task_contexts.get(group_key)
        if task_context is not None:
            return task_context

        if group_key.startswith("stream:"):
            task_context = stream.variables.get("create_case_task_context")
            if task_context is not None:
                self._group_task_contexts[group_key] = task_context
                return task_context

            task_context = stream.variables.get("task")
            if task_context is None:
                from highlighter.client.tasks import TaskContext

                task_context = TaskContext()

            stream.variables["create_case_task_context"] = task_context
            self._group_task_contexts[group_key] = task_context
            return task_context

        from highlighter.client.tasks import TaskContext

        task_context = TaskContext()
        self._group_task_contexts[group_key] = task_context
        return task_context

    @staticmethod
    def _get_entity_id(rows=None, entities=None) -> Optional[str]:
        if rows:
            for row in rows:
                if getattr(row, "entity_id", None) is not None:
                    return str(row.entity_id)
        if isinstance(entities, dict) and entities:
            return str(next(iter(entities.keys())))
        return None

    def _get_case_title(self, stream, entities, rows=None):
        timestamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        entity_id = self._get_entity_id(rows=rows, entities=entities)

        return self.case_title_template.format(
            timestamp=timestamp,
            stream_id=stream.stream_id,
            entity_id=entity_id,
        )

    @staticmethod
    def _deduplicate_recorders(recorders):
        deduped = []
        seen = set()
        for recorder in recorders:
            marker = id(recorder)
            if marker in seen:
                continue
            seen.add(marker)
            deduped.append(recorder)
        return deduped

    def _entity_stream_ids(self, entity_id: Optional[str], observations_table, rows=None):
        stream_ids = set()
        if rows:
            for row in rows:
                if getattr(row, "stream", None) is not None:
                    stream_ids.update(row.stream)

        if entity_id is None or observations_table is None:
            return sorted(stream_ids)

        stream_ids.update(observations_table.get_entity_stream_ids(entity_id))

        return sorted(stream_ids)

    def _get_recorders(
        self,
        agent,
        stream,
        rows=None,
        observations_table=None,
        entity_id: Optional[str] = None,
    ):
        capability_names = [
            node.name
            for node in agent.pipeline.pipeline_graph.nodes()
            if hasattr(getattr(node, "element", None), "recording_enabled")
        ]
        if self.record_all_streams:
            return self._deduplicate_recorders(agent.get_all_recorders_for_capabilities(capability_names))

        stream_ids = self._entity_stream_ids(entity_id, observations_table, rows=rows)
        if not stream_ids:
            stream_ids = [stream.stream_id]

        recorders = []
        for stream_id in stream_ids:
            for recorder in agent.get_recorders_for_capabilities(stream_id, capability_names):
                recorders.append(recorder)
        return self._deduplicate_recorders(recorders)

    def on_trigger_on(self, *, stream, agent, rows=None, entities=None, **kwargs):
        """Start case recording for trigger rising edge.

        Block-by-block semantics:

        1. Resolve logical entity.
           `rows` has priority. If any matched row has `row.entity`, first row entity id wins.
           If `rows` is absent or has no entity, fallback is first key from `entities` dict.
           This resolved `entity_id` is later used for:
           - grouping/deduplication
           - case-name formatting
           - recorder scoping when `record_all_streams=False`

        2. Resolve logical recording group.
           Group decides whether this edge should create new case or join existing case state.
           - `record_all_streams=True` -> one global group: `__all_streams__`
           - `record_all_streams=False` and entity found -> `entity:<entity_id>`
           - `record_all_streams=False` and no entity -> fallback `stream:<stream_id>`

        3. Resolve task context for that group.
           One group owns one `TaskContext`. Multiple `on_trigger_on` edges for same group reuse
           same task context, so duplicate rising edges do not create duplicate cases.

        4. Mark current stream active in group before start attempt.
           `_active_streams_by_group[group_key]` tracks which streams are currently contributing
           "on" state to this group. `_group_key_by_stream[stream_id]` lets `on_trigger_off`
           map future falling edge back to same group.

        5. Deduplicate starts.
           If task context already has `_recording`, callback exits early. This means another
           stream in same group already started the case.

        6. Select recorders.
           `rows` affects recorder scope. `entities` does not directly select recorders.
           - `record_all_streams=True`:
             `_get_recorders()` returns all recorders for all recording-enabled capabilities.
             `rows`, `entities`, and `observations_table` do not narrow scope.
           - `record_all_streams=False`:
             `_get_recorders()` uses `entity_id` plus `observations_table` to widen from matched
             rows to all streams currently known for same entity.
             Example: triggering row from stream `0`, same entity also present in table on stream
             `2` -> recorder set becomes streams `0` and `2`.
             If no entity/rows resolve stream scope, fallback is current stream only.

        7. Start recording.
           `TaskContext.start_recording(...)` creates case/submission and binds selected recorders
           to that submission. `case_title` may include resolved `entity_id`.

        8. Failure rollback.
           If start fails, callback removes stream/group state added earlier so future rising edge
           can retry cleanly. For per-stream fallback groups, temporary context on stream vars is
           also removed when unused.
        """
        logger.info(
            f"CreateCaseTriggerCallback on_trigger_on, frame_id: {stream.frame_id}",
            extra={"stream_id": stream.stream_id, "capability_name": "CreateCaseTriggerCallback"},
        )
        # Resolve entity before any grouping/state mutation. `rows` wins over `entities`.
        entity_id = self._get_entity_id(rows=rows, entities=entities)
        # Convert trigger context into stable recording-group key.
        group_key = self._group_key(stream, entity_id=entity_id)
        if entity_id is not None:
            self._entity_id_by_group[group_key] = entity_id
        # Reuse existing group task context if this group already started or is about to start.
        task_context = self._get_task_context(stream, group_key)
        # Register this stream as active for the group so matching off-edge can find same group.
        active_streams = self._active_streams_by_group.setdefault(group_key, set())
        active_streams.add(stream.stream_id)
        self._group_key_by_stream[stream.stream_id] = group_key

        # Another stream in same group already started recording. Do not create second case.
        if getattr(task_context, "_recording", None):
            return

        # Recorder scope depends on `record_all_streams`, matched `rows`, and `observations_table`.
        recorders = self._get_recorders(
            agent,
            stream,
            rows=rows,
            observations_table=kwargs.get("observations_table"),
            entity_id=entity_id,
        )
        if not recorders:
            raise ValueError("No recorders found for CreateCaseTriggerCallback. Ensure recording is enabled.")

        try:
            # Start case/submission for resolved recorder set.
            task_context.start_recording(
                recorders,
                self.new_case_workflow_order_id,
                case_title=self._get_case_title(stream, entities, rows=rows),
                trigger_reason=describe_trigger_firing(kwargs.get("trigger")),
                # ToDo: Reinstate when prod db is fixed (jp: 2026-04-23)
                # entity_id=UUID(entity_id) if entity_id is not None else None,
            )
        except Exception:
            # Roll back group membership added above so later rising edge can retry cleanly.
            active_streams.discard(stream.stream_id)
            self._group_key_by_stream.pop(stream.stream_id, None)
            if not active_streams:
                self._active_streams_by_group.pop(group_key, None)
                self._group_task_contexts.pop(group_key, None)
            # Only per-stream fallback groups store temporary context on stream variables.
            if (
                group_key.startswith("stream:")
                and stream.variables.get("create_case_task_context") is task_context
                and not getattr(task_context, "_recording", None)
            ):
                stream.variables.pop("create_case_task_context", None)

            logger.exception(
                "CreateCaseTriggerCallback failed to start recording",
                extra={"stream_id": stream.stream_id, "capability_name": "CreateCaseTriggerCallback"},
            )
            return

    def on_trigger_off(self, *, stream, rows=None, **kwargs):

        logger.info(
            f"CreateCaseTriggerCallback on_trigger_off, frame_id: {stream.frame_id}",
            extra={"stream_id": stream.stream_id, "capability_name": "CreateCaseTriggerCallback"},
        )
        group_key = self._group_key_by_stream.get(stream.stream_id)
        entity_id = self._get_entity_id(rows=rows)
        if group_key is None:
            group_key = self._group_key(stream, entity_id=entity_id)
        entity_id = entity_id or self._entity_id_by_group.get(group_key)

        active_streams = self._active_streams_by_group.get(group_key)
        if active_streams is not None:
            active_streams.discard(stream.stream_id)
            if active_streams:
                self._group_key_by_stream.pop(stream.stream_id, None)
                return
            self._active_streams_by_group.pop(group_key, None)

        self._group_key_by_stream.pop(stream.stream_id, None)
        task_context = self._group_task_contexts.get(group_key)
        if task_context is None and group_key.startswith("stream:"):
            task_context = stream.variables.get("create_case_task_context")
        if task_context is None:
            return

        task_context.stop_recording()


def describe_trigger_firing(trigger: Optional[Trigger]) -> str:
    if isinstance(trigger, RuleTrigger):
        return f'Rule trigger matched expression: "{trigger.expression}"'
    if isinstance(trigger, PeriodicTrigger):
        return (
            "Periodic trigger entered its on-period "
            f"(on_period={trigger.on_period}s, off_period={trigger.off_period}s)"
        )
    if isinstance(trigger, OnCaseTrigger):
        return "On-case trigger detected an active case context"
    if trigger is None:
        return "An unknown trigger fired"
    return f"{type(trigger).__name__} fired"
