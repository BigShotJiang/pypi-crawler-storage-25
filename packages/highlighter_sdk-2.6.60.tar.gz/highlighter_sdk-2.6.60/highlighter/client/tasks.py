from __future__ import annotations

import json
import logging
from collections import deque
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Iterator, List, Optional, Tuple, Union
from uuid import UUID, uuid4

from highlighter.client.assessments import finalise
from highlighter.client.base_models.base_models import (
    CaseMessageConnection,
    CaseType,
    CreateCaseMessagePayload,
    MessageType,
    TaskType,
)
from highlighter.client.base_models.page_info import PageInfo
from highlighter.client.gql_client import HLClient, get_threadsafe_hlclient
from highlighter.client.io import download_files
from highlighter.client.json_tools import HLJSONEncoder
from highlighter.core.gql_base_model import GQLBaseModel

from ..core import paginate

if TYPE_CHECKING:
    from highlighter.agent.capabilities.recorder import Recorder

logger = logging.getLogger(__name__)

__all__ = [
    "update_task_status",
    "update_task",
    "lease_task",
    "lease_tasks_from_steps",
    "add_files_to_order",
    "export_case",
    "TaskTypeConnection",
    "iter_tasks",
]


class TaskTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[TaskType]


def _get_all_case_messages(client: HLClient, case_id: str, page_size: int = 200) -> List[MessageType]:
    return list(paginate(client.caseMessages, CaseMessageConnection, page_size=page_size, caseId=case_id))


def _iter_files_for_window(
    client: HLClient,
    *,
    data_source_uuids: List[str],
    recorded_from: Optional[datetime],
    recorded_to: Optional[datetime],
    page_size: int = 200,
) -> Iterator[GQLBaseModel]:
    class ExportWindowFileType(GQLBaseModel):
        id: str
        uuid: UUID
        original_source_url: Optional[str] = None
        file_url_original: str
        filename: Optional[str] = None
        recorded_at: Optional[datetime] = None
        recorded_until: Optional[datetime] = None
        data_source_uuid: Optional[UUID] = None

    class ExportWindowFileConnection(GQLBaseModel):
        page_info: PageInfo
        nodes: List[ExportWindowFileType]

    kwargs: Dict[str, Any] = {"dataSourceUuid": data_source_uuids}
    if recorded_from is not None:
        kwargs["recordedFrom"] = recorded_from.isoformat()
    if recorded_to is not None:
        kwargs["recordedTo"] = recorded_to.isoformat()

    return paginate(client.files, ExportWindowFileConnection, page_size=page_size, **kwargs)


def export_case(
    client: HLClient,
    case_id: str,
    output_dir: Path,
    *,
    include_messages: bool = True,
    file_structure: str = "filename",
    before_seconds: float = 0.0,
    after_seconds: float = 0.0,
) -> Path:
    class CaseExportFileType(GQLBaseModel):
        id: str
        uuid: UUID
        recorded_at: Optional[datetime] = None
        recorded_until: Optional[datetime] = None
        data_source_uuid: Optional[UUID] = None

    class CaseExportSubmissionType(GQLBaseModel):
        data_files: List[CaseExportFileType]

    class CaseExportType(GQLBaseModel):
        id: str
        name: Optional[str] = None
        created_at: str
        updated_at: str
        state: str
        sort_order: Optional[str] = None
        short_id: str
        workflow_id: str
        workflow_name: str
        workflow_order_id: Optional[str] = None
        workflow_order_name: str
        entity_id: Optional[str] = None
        entity_title: str
        external_id: Optional[str] = None
        external_id_type: Optional[str] = None
        latest_submission: Optional[CaseExportSubmissionType] = None

    case = client.case(return_type=CaseExportType, id=case_id)
    if case is None:
        raise ValueError(f"Case {case_id} not found")

    latest_submission = case.latest_submission
    data_files = latest_submission.data_files if latest_submission is not None else []
    recorded_at_values = [
        data_file.recorded_at for data_file in data_files if data_file.recorded_at is not None
    ]
    recorded_until_values = [
        data_file.recorded_until for data_file in data_files if data_file.recorded_until is not None
    ]
    recorded_at_start = min(recorded_at_values) if recorded_at_values else None
    recorded_at_end = max(recorded_until_values) if recorded_until_values else None
    data_source_uuids = sorted(
        {
            str(data_file.data_source_uuid)
            for data_file in data_files
            if data_file.data_source_uuid is not None
        }
    )
    window_recorded_from = (
        recorded_at_start - timedelta(seconds=before_seconds) if recorded_at_start is not None else None
    )
    window_recorded_to = (
        recorded_at_end + timedelta(seconds=after_seconds) if recorded_at_end is not None else None
    )

    case_dir = Path(output_dir) / case.id
    case_dir.mkdir(parents=True, exist_ok=True)

    case_path = case_dir / "case.json"
    case_path.write_text(json.dumps(case.gql_dict(), indent=2, cls=HLJSONEncoder), encoding="utf-8")

    files_to_download = (
        list(
            _iter_files_for_window(
                client,
                data_source_uuids=data_source_uuids,
                recorded_from=window_recorded_from,
                recorded_to=window_recorded_to,
            )
        )
        if data_source_uuids
        else []
    )
    download_map = download_files(
        client=client,
        files=files_to_download,
        output_dir=case_dir / "data_files",
        structure=file_structure,
    )
    failed_downloads = [str(file_id) for file_id, path in download_map.items() if path is None]
    if failed_downloads:
        raise ValueError(f"Failed to download case files: {', '.join(failed_downloads)}")

    messages: List[MessageType] = []
    if include_messages:
        messages = _get_all_case_messages(client, case.id)
        messages_path = case_dir / "messages.json"
        messages_path.write_text(
            json.dumps([message.gql_dict() for message in messages], indent=2, cls=HLJSONEncoder),
            encoding="utf-8",
        )

    manifest = {
        "caseId": case.id,
        "exportedAt": datetime.now(UTC).isoformat(),
        "messagesIncluded": include_messages,
        "messageCount": len(messages),
        "dataFileCount": len(files_to_download),
        "recorded_at_start": recorded_at_start,
        "recorded_at_end": recorded_at_end,
        "window_recorded_from": window_recorded_from,
        "window_recorded_to": window_recorded_to,
        "dataSourceUuids": data_source_uuids,
        "fileStructure": file_structure,
        "downloadedFiles": {
            str(file_id): str(path.relative_to(case_dir))
            for file_id, path in download_map.items()
            if path is not None
        },
    }
    manifest_path = case_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, cls=HLJSONEncoder), encoding="utf-8")

    return case_dir


def iter_tasks(
    client,
    *,
    pipeline_id: object,
    task_id: Optional[object] = None,
    page_size: int = 200,
):
    if pipeline_id is None:
        raise TypeError("pipeline_id is required")
    kwargs = {"pipelineId": pipeline_id, "taskId": task_id}
    kwargs = {k: v for k, v in kwargs.items() if v is not None}
    return paginate(
        client.tasks,
        TaskTypeConnection,
        page_size=page_size,
        **kwargs,
    )


class TaskStatus(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    FAILED = "FAILED"
    SUCCESS = "SUCCESS"

    @staticmethod
    def validate_str(s) -> bool:
        return s in [s.value for s in TaskStatus]


class UpdateTaskResultPayload(GQLBaseModel):
    submission: CreateSubmissionNotFinalisedPayload.SubmissionType
    errors: List[Any]


class DataFile(GQLBaseModel):
    id: Optional[str] = None
    uuid: Optional[str] = None
    original_source_url: Optional[str] = None
    file_url_original: Optional[str] = None
    content_type: Optional[str] = None


class Case(GQLBaseModel):
    class CaseSubmission(GQLBaseModel):
        id: str
        uuid: UUID
        data_files: List[DataFile]

    id: str
    latest_submission: Optional[CaseSubmission] = None
    entity_id: Optional[str] = None
    data_files: Optional[List[DataFile]] = None


class Task(GQLBaseModel):
    id: str
    status: Optional[TaskStatus] = None
    case: Optional[Case] = None
    leased_until: Optional[datetime] = None
    parameters: Optional[Dict[str, Any]] = None


def update_task_status(
    client: HLClient,
    task_id: str,
    status: Union[str, TaskStatus],
    message: Optional[str] = None,
):
    assert isinstance(status, TaskStatus) or TaskStatus.validate_str(status), f"Got: {status}"

    class UpdateTaskStatusResponse(GQLBaseModel):
        errors: List[Any]

    kwargs = {
        "id": task_id,
        "status": status,
    }
    if message is not None:
        kwargs["message"] = message

    response = client.update_task_status(return_type=UpdateTaskStatusResponse, **kwargs)
    if response.errors:
        raise ValueError(f"{response.errors}")

    return response


def update_task(
    client: HLClient,
    task_id: Union[UUID, str],
    status: Optional[Union[str, TaskStatus]] = None,
    leased_until: Optional[Union[datetime, str]] = None,
    lease_sec: Optional[int] = None,
    **kwargs,
) -> Task:
    if lease_sec:
        assert leased_until is None, "Cannot use both leased_until and lease_sec"
        leased_until = (datetime.now(UTC) + timedelta(seconds=lease_sec)).isoformat()

    if isinstance(leased_until, datetime):
        leased_until = leased_until.isoformat()

    class TaskResponse(GQLBaseModel):
        task: Task
        errors: Any

    kwargs = dict(
        id=str(task_id),
        status=status,
        leasedUntil=leased_until,
        **kwargs,
    )

    kwargs = {k: v for k, v in kwargs.items() if v is not None}

    response = client.updateTask(return_type=TaskResponse, **kwargs)

    if response.errors:
        raise ValueError(f"Errors: {response.errors}")

    return response.task


def lease_task(
    client: HLClient,
    task_id: Union[UUID, str],
    set_status_to: Optional[Union[str, TaskStatus]] = None,
    leased_until: Optional[Union[datetime, str]] = None,
    lease_sec: Optional[float] = None,
) -> Task:
    if lease_sec:
        assert leased_until is None, "Cannot use both leased_until and lease_sec"
        leased_until = (datetime.now(UTC) + timedelta(seconds=lease_sec)).isoformat()

    if isinstance(leased_until, datetime):
        leased_until = leased_until.isoformat()

    class TaskResponse(GQLBaseModel):
        task: Task
        errors: Any

    update_task_args = {"id": str(task_id), "leasedUntil": leased_until}
    if set_status_to is not None:
        update_task_args["status"] = set_status_to
    response = client.updateTask(return_type=TaskResponse, **update_task_args)
    if response.errors:
        raise ValueError(f"Errors: {response.errors}")
    return response.task


def lease_tasks_from_steps(
    client: HLClient,
    step_ids: List[Union[UUID, str]],
    count: int = 1,
    filter_by_status: Optional[Union[str, TaskStatus]] = None,
    set_status_to: Optional[Union[str, TaskStatus]] = None,
    leased_until: Optional[Union[datetime, str]] = None,
    lease_sec: Optional[float] = None,
    filter_by_task_id: Optional[List[UUID]] = None,
) -> List[Task]:
    if filter_by_status:
        assert isinstance(filter_by_status, TaskStatus) or TaskStatus.validate_str(filter_by_status)

    if set_status_to:
        assert isinstance(set_status_to, TaskStatus) or TaskStatus.validate_str(set_status_to)

    if lease_sec:
        assert leased_until is None, "Cannot use both leased_until and lease_sec"
        leased_until = (datetime.now(UTC) + timedelta(seconds=lease_sec)).isoformat()

    if isinstance(leased_until, datetime):
        leased_until = leased_until.isoformat()

    class TaskResponse(GQLBaseModel):
        errors: List[Any]
        tasks: List[Task]

    response = client.leaseTasksFromSteps(
        return_type=TaskResponse,
        stepIds=[str(s) for s in step_ids],
        count=count,
        leasedUntil=leased_until,
    )

    if len(response.errors) > 0:
        raise ValueError(response.errors)

    if filter_by_status:
        tasks = [t for t in response.tasks if t.status == filter_by_status]
    else:
        tasks = response.tasks

    if filter_by_task_id:
        task_ids = []

        for i in filter_by_task_id:
            if isinstance(i, str):
                task_ids.append(i)
            elif isinstance(i, UUID):
                task_ids.append(str(i))
            else:
                raise ValueError()

        tasks = [t for t in tasks if t.id in task_ids]

    if set_status_to:
        for task in tasks:
            _ = update_task_status(client, task.id, set_status_to)
    return tasks


def add_files_to_order(client: HLClient, order_id: str, file_ids: List[str]) -> Dict[str, str]:
    """
    add files to a workflow order, creating tasks for them.
    returns a dictionary mapping data_file_id to task_id.
    """

    class AddFilesResponse(GQLBaseModel):
        tasks: List[Task]
        errors: List[Any]

    # this mutation is dynamically dispatched by HLClient
    res = client.addFilesToWorkflowOrder(
        return_type=AddFilesResponse, workflowOrderId=order_id, fileIds=file_ids
    )

    if res.errors:
        raise ValueError(f"Failed to add files to order: {res.errors}.")

    file_to_task = {}
    if res.tasks:
        for t in res.tasks:
            if t.case and t.case.data_files:
                for df in t.case.data_files:
                    # map the file id (not uuid) to the task id
                    file_to_task[str(df.id)] = t.id

    return file_to_task


# FIXME: (Josh). Should the be merged with TaskType? We have 2 modes of using Task
# one for Gql and the other for Agents. I think they should be one-in-the-same.


@dataclass
class ProcessorState:
    """Lock-free coordination record shared between TaskContext and Recorder workers."""

    processor: "Recorder"  # forward-declared to avoid import cycle
    submission: CreateSubmissionNotFinalisedPayload.SubmissionType
    case_id: Optional[str] = None  # Case ID for logging and tracking
    pending_chunks: int = 0
    stopping: bool = False
    finished: bool = False
    error: Optional[BaseException] = None


@dataclass
class RecordingSession:
    """Tracks the processors contributing to a submission and their progress."""

    submission: CreateSubmissionNotFinalisedPayload.SubmissionType
    case_id: str
    processors: List[ProcessorState] = field(default_factory=list)

    def all_finished(self) -> bool:
        return all(p.finished for p in self.processors)

    def has_error(self) -> bool:
        return any(p.error is not None for p in self.processors)

    def iter_errors(self):
        for state in self.processors:
            if state.error is not None:
                yield state


class TaskContext:
    def __init__(
        self,
    ):
        self._recording = deque()
        self.logger = logging.getLogger(__name__)
        self._hl_credentials: Optional[Tuple[str, str]] = None

    def _get_threadsafe_hl_client(self) -> HLClient:
        """Lazily capture credentials and return a thread-local HLClient."""
        if self._hl_credentials is None:
            base_client = HLClient.get_client()
            self._hl_credentials = (base_client.api_token, base_client.endpoint_url)

        api_token, endpoint_url = self._hl_credentials
        return get_threadsafe_hlclient(api_token, endpoint_url)

    def start_recording(
        self,
        dsps_to_record,
        workflow_order_id: UUID,
        case_title: Optional[str] = None,
        entity_id: Optional[UUID] = None,
        trigger_reason: Optional[str] = None,
        *,
        log_context: Optional[str] = None,
    ):
        client = self._get_threadsafe_hl_client()
        case, sub = create_empty_case_with_not_finalized_submission(
            client,
            workflow_order_id,
            case_title=case_title,
            entity_id=entity_id,
            trigger_reason=trigger_reason,
            log_context=log_context,
        )
        session = RecordingSession(submission=sub, case_id=case.id)
        recording_streams = []
        for dsp in dsps_to_record:
            processor_state = ProcessorState(processor=dsp, submission=sub, case_id=case.id)
            session.processors.append(processor_state)
            dsp.start_recording(sub, processor_state)
            recording_streams.append(dsp._stream_id)

        prefix = f"{log_context} " if log_context else ""
        logger.info(
            f"{prefix}Start Recording: not_finalised_submission: {sub.id}, case: {case.id}, streams: {recording_streams}",
            extra={"color": "green"},
        )

        self._recording.append(session)

    def finalise_submissions_on_recording_state_off(self):
        """Check for completed recordings and finalize their submissions.

        This method polls the shared ProcessorState records for the oldest recording session.
        Once every Recorder reports finished=True the submission is finalized.
        """
        if not self._recording:
            return

        recording_session = self._recording[0]

        # Surface any worker-thread errors to the runtime loop.
        for state in recording_session.iter_errors():
            self.logger.error(
                "Recording processor %s failed while handling submission %s: %s",
                state.processor,
                recording_session.submission.id,
                state.error,
            )
            # Propagate the first failure.
            raise state.error

        if not recording_session.all_finished():
            return

        submission = recording_session.submission
        self.logger.info(f"Finalized not_finalised_submission: {submission.id}", extra={"color": "blue"})
        client = self._get_threadsafe_hl_client()
        finalise(client, submission)

        # Let each processor clear any per-submission state.
        for state in list(recording_session.processors):
            try:
                state.processor.clear_completed_recording(state)
            except Exception as exc:  # pragma: no cover - defensive
                self.logger.warning(
                    "Failed to clear recording state for processor %s (%s): %s",
                    state.processor,
                    submission.id,
                    exc,
                )

        self._recording.popleft()

    def stop_recording(self):
        if not self._recording:
            return

        recording_session = self._recording[0]

        for state in list(recording_session.processors):
            dsp = state.processor
            self.logger.info(
                f"Stop Recording: not_finalised_submission: {recording_session.submission.id}, case: {recording_session.case_id}",
                extra={
                    "stream_id": getattr(dsp, "_stream_id", None),
                    "capability_name": getattr(dsp, "_capability_name", None),
                    "color": "blue",
                },
            )
            dsp.stop_recording(state)


from highlighter.core.gql_base_model import GQLBaseModel


class CreateCasePayload(GQLBaseModel):
    errors: Any
    case: Optional[CaseType] = None


class CreateSubmissionNotFinalisedPayload(GQLBaseModel):
    class SubmissionType(GQLBaseModel):
        id: str
        case_id: Optional[str] = None
        task_id: Optional[str] = None

    submission: Optional[SubmissionType] = None
    errors: List[str]


class CreateTaskPayload(GQLBaseModel):
    errors: List[str]
    task: Optional[TaskType] = None


def create_empty_case_with_not_finalized_submission(
    client: HLClient,
    workflow_order_id: UUID,
    case_title: Optional[str] = None,
    entity_id: Optional[UUID] = None,
    trigger_reason: Optional[str] = None,
    *,
    log_context: Optional[str] = None,
) -> Tuple[CaseType, CreateSubmissionNotFinalisedPayload.SubmissionType]:
    """Creates an empty Case

    Args:
        client: HLClient instance
        workflow_order_id: Target workflow order ID
        case_title: Optional title for the case
        entity_id: Optional entity ID

    Returns:
        Case object

    Raises:
        RuntimeError: If case creation fails
    """
    # Create the case
    case_result = client.createCase(
        return_type=CreateCasePayload,
        workflowOrderId=workflow_order_id,
        title=case_title,
        entityId=entity_id,
        state="ready",
    )

    if case_result.errors:
        raise RuntimeError(f"Error in createCase: {case_result.errors}")

    if not case_result.case:
        raise RuntimeError("createCase succeeded but no CaseType returned")

    prefix = f"{log_context} " if log_context else ""
    logger.info(f"{prefix}Created case {case_result.case.id}", extra={"color": "green"})
    case = case_result.case

    if trigger_reason:
        _create_case_trigger_message(client, case.id, trigger_reason, log_context=log_context)

    sub_result = client.createSubmissionNotFinalised(
        return_type=CreateSubmissionNotFinalisedPayload,
        caseId=case.id,
    )

    if sub_result.errors:
        raise RuntimeError(f"Error in createSubmissionNotFinalised: {sub_result.errors}")

    if not sub_result.submission:
        raise RuntimeError(
            "createSubmissionNotFinalised succeeded but no CreateSubmissionNotFinalisedPayload.SubmissionType returned"
        )

    sub = sub_result.submission

    return case, sub


def _create_case_trigger_message(
    client: HLClient,
    case_id: str,
    trigger_reason: str,
    *,
    log_context: Optional[str] = None,
) -> None:
    prefix = f"{log_context} " if log_context else ""
    content = f"Case created automatically because trigger fired: {trigger_reason}"
    try:
        result = client.createCaseMessage(
            return_type=CreateCaseMessagePayload,
            caseId=case_id,
            content=content,
        )
    except Exception as exc:
        logger.warning("%sFailed to create trigger message for case %s: %s", prefix, case_id, exc)
        return

    if result.errors:
        logger.warning(
            "%sFailed to create trigger message for case %s: %s",
            prefix,
            case_id,
            result.errors,
        )
