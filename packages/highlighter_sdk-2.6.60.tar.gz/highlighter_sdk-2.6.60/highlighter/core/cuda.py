"""CUDA availability helpers shared across predictors and telemetry."""

import functools
import importlib
import logging
import os
from typing import Optional

LOGGER = logging.getLogger(__name__)

_LOGGED_NVML_FAILURES: set[str] = set()


def _log_nvml_failure(kind: str, message: str, *args, level: int = logging.WARNING) -> None:
    """Log each recurring NVML failure mode once to avoid noisy telemetry loops."""
    if kind in _LOGGED_NVML_FAILURES:
        return
    _LOGGED_NVML_FAILURES.add(kind)
    LOGGER.log(level, message, *args)


def _import_pynvml():
    try:
        return importlib.import_module("pynvml")
    except ImportError as exc:
        _log_nvml_failure(
            "import",
            "CUDA VRAM telemetry requires nvidia-ml-py; install highlighter-sdk[telemetry]: %s",
            exc,
        )
        return None


@functools.lru_cache(maxsize=1)
def is_nvml_available() -> bool:
    """Return True if NVML is importable and initializes successfully."""
    pynvml = _import_pynvml()
    if pynvml is None:
        return False
    try:
        pynvml.nvmlInit()
    except Exception as exc:
        _log_nvml_failure("init", "Unable to initialize NVML for CUDA telemetry: %s", exc)
        return False
    try:
        pynvml.nvmlShutdown()
    except Exception as exc:
        _log_nvml_failure(
            "shutdown",
            "Unable to shutdown NVML after availability check: %s",
            exc,
            level=logging.DEBUG,
        )
    return True


@functools.lru_cache(maxsize=1)
def is_nvidia_smi_available() -> bool:
    """Return True if NVML is available.

    Kept for compatibility with older callers; this no longer shells out to
    nvidia-smi.
    """
    return is_nvml_available()


def resolve_device_id(env_var: str = "HL_GPU_DEVICE_ID", default: int = 0) -> int:
    """Return an integer device id from an env var, falling back to default on errors."""
    raw = os.environ.get(env_var, default)
    try:
        return int(raw)
    except (TypeError, ValueError):
        return int(default)


def current_process_vram_bytes() -> Optional[int]:
    """Return GPU memory used by this process according to NVML."""
    pynvml = _import_pynvml()
    if pynvml is None:
        return None

    initialized = False
    try:
        pynvml.nvmlInit()
        initialized = True
    except Exception as exc:
        _log_nvml_failure("init", "Unable to initialize NVML for CUDA VRAM telemetry: %s", exc)
        return None

    try:
        device_count = pynvml.nvmlDeviceGetCount()
    except Exception as exc:
        _log_nvml_failure("device_count", "Unable to enumerate NVML devices for CUDA VRAM telemetry: %s", exc)
        if initialized:
            try:
                pynvml.nvmlShutdown()
            except Exception as shutdown_exc:
                _log_nvml_failure(
                    "shutdown",
                    "Unable to shutdown NVML after CUDA VRAM telemetry collection: %s",
                    shutdown_exc,
                    level=logging.DEBUG,
                )
        return None

    total_bytes = 0
    found = False
    current_pid = os.getpid()

    try:
        for device_index in range(device_count):
            try:
                handle = pynvml.nvmlDeviceGetHandleByIndex(device_index)
                processes = pynvml.nvmlDeviceGetComputeRunningProcesses(handle)
            except Exception as exc:
                _log_nvml_failure(
                    f"device_processes_{device_index}",
                    "Unable to query NVML compute processes for device %s: %s",
                    device_index,
                    exc,
                )
                continue

            for process in processes:
                if getattr(process, "pid", None) != current_pid:
                    continue
                used_gpu_memory = getattr(process, "usedGpuMemory", None)
                if used_gpu_memory is None:
                    _log_nvml_failure(
                        "unavailable_memory",
                        "NVML reported unavailable GPU memory for current process",
                    )
                    continue
                total_bytes += int(used_gpu_memory)
                found = True
    except Exception as exc:
        _log_nvml_failure(
            "collection",
            "Unexpected NVML error while collecting CUDA VRAM telemetry: %s",
            exc,
        )
        return None
    finally:
        try:
            pynvml.nvmlShutdown()
        except Exception as exc:
            _log_nvml_failure(
                "shutdown",
                "Unable to shutdown NVML after CUDA VRAM telemetry collection: %s",
                exc,
                level=logging.DEBUG,
            )

    if not found:
        return None
    return total_bytes
