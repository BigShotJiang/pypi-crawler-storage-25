import json
import logging
import platform
from typing import Any, Optional

import click
import psutil

from highlighter.version import __version__

LOGGER = logging.getLogger(__name__)


def _decode(value: Any) -> Any:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


def _bytes_to_gib(value: Optional[int]) -> str:
    if value is None:
        return "unknown"
    return f"{value / (1024**3):.1f} GiB"


def _mhz(value: Optional[float]) -> str:
    if value is None:
        return "unknown"
    return f"{value:.0f} MHz"


def _optional_call(fn, *args):
    try:
        return fn(*args)
    except Exception:
        return None


def _collect_system_info() -> dict[str, Any]:
    return {
        "os": platform.system() or "unknown",
        "os_version": platform.release() or "unknown",
        "platform": platform.platform() or "unknown",
        "architecture": platform.machine() or "unknown",
        "python_version": platform.python_version(),
        "sdk_version": __version__,
    }


def _collect_cpu_info() -> dict[str, Any]:
    freq = _optional_call(psutil.cpu_freq)
    return {
        "physical_cores": psutil.cpu_count(logical=False),
        "logical_cores": psutil.cpu_count(logical=True),
        "processor": platform.processor() or "unknown",
        "frequency_mhz": None if freq is None else freq.current,
        "min_frequency_mhz": None if freq is None else freq.min,
        "max_frequency_mhz": None if freq is None else freq.max,
    }


def _collect_memory_info() -> dict[str, Any]:
    memory = psutil.virtual_memory()
    return {
        "total_bytes": int(memory.total),
        "available_bytes": int(memory.available),
        "used_bytes": int(memory.used),
        "percent_used": float(memory.percent),
    }


def _collect_gpu_info() -> dict[str, Any]:
    try:
        import pynvml
    except ImportError as exc:
        return {
            "status": "dependency_missing",
            "message": f"nvidia-ml-py is not installed: {exc}",
            "install_hint": "Install highlighter-sdk[telemetry] to enable NVIDIA GPU diagnostics.",
            "driver_version": None,
            "devices": [],
        }

    initialized = False
    try:
        pynvml.nvmlInit()
        initialized = True
    except Exception as exc:
        return {
            "status": "driver_unavailable",
            "message": f"Unable to initialize NVML: {exc}",
            "install_hint": None,
            "driver_version": None,
            "devices": [],
        }

    try:
        driver_version = _decode(_optional_call(pynvml.nvmlSystemGetDriverVersion))
        device_count = pynvml.nvmlDeviceGetCount()
        if device_count == 0:
            return {
                "status": "no_devices",
                "message": "NVML initialized, but no NVIDIA GPUs were found.",
                "install_hint": None,
                "driver_version": driver_version,
                "devices": [],
            }

        devices = []
        for index in range(device_count):
            try:
                handle = pynvml.nvmlDeviceGetHandleByIndex(index)
                memory = _optional_call(pynvml.nvmlDeviceGetMemoryInfo, handle)
                utilization = _optional_call(pynvml.nvmlDeviceGetUtilizationRates, handle)
                devices.append(
                    {
                        "index": index,
                        "name": _decode(_optional_call(pynvml.nvmlDeviceGetName, handle)) or "unknown",
                        "uuid": _decode(_optional_call(pynvml.nvmlDeviceGetUUID, handle)),
                        "vram_total_bytes": None if memory is None else int(memory.total),
                        "vram_free_bytes": None if memory is None else int(memory.free),
                        "vram_used_bytes": None if memory is None else int(memory.used),
                        "gpu_utilization_percent": None if utilization is None else int(utilization.gpu),
                        "memory_utilization_percent": None
                        if utilization is None
                        else int(utilization.memory),
                        "status": "ok",
                        "message": None,
                    }
                )
            except Exception as exc:
                devices.append(
                    {
                        "index": index,
                        "name": "unknown",
                        "uuid": None,
                        "vram_total_bytes": None,
                        "vram_free_bytes": None,
                        "vram_used_bytes": None,
                        "gpu_utilization_percent": None,
                        "memory_utilization_percent": None,
                        "status": "error",
                        "message": str(exc),
                    }
                )

        return {
            "status": "ok",
            "message": None,
            "install_hint": None,
            "driver_version": driver_version,
            "devices": devices,
        }
    except Exception as exc:
        return {
            "status": "error",
            "message": f"Unable to collect NVIDIA GPU information: {exc}",
            "install_hint": None,
            "driver_version": None,
            "devices": [],
        }
    finally:
        if initialized:
            try:
                pynvml.nvmlShutdown()
            except Exception as exc:
                LOGGER.debug("Unable to shutdown NVML after doctor GPU diagnostics: %s", exc)


def collect_doctor_info() -> dict[str, Any]:
    return {
        "system": _collect_system_info(),
        "cpu": _collect_cpu_info(),
        "memory": _collect_memory_info(),
        "gpu": _collect_gpu_info(),
    }


def _render_table(info: dict[str, Any]) -> str:
    system = info["system"]
    cpu = info["cpu"]
    memory = info["memory"]
    gpu = info["gpu"]

    lines = [
        "System",
        f"  OS:           {system['platform']}",
        f"  Architecture: {system['architecture']}",
        f"  Python:       {system['python_version']}",
        f"  SDK:          {system['sdk_version']}",
        "",
        "CPU",
        f"  Processor:    {cpu['processor']}",
        f"  Cores:        {cpu['physical_cores'] or 'unknown'} physical / {cpu['logical_cores'] or 'unknown'} logical",
        f"  Frequency:    {_mhz(cpu['frequency_mhz'])}",
        "",
        "Memory",
        f"  Total:        {_bytes_to_gib(memory['total_bytes'])}",
        f"  Available:    {_bytes_to_gib(memory['available_bytes'])}",
        f"  Used:         {_bytes_to_gib(memory['used_bytes'])} ({memory['percent_used']:.1f}%)",
        "",
        "GPU",
        f"  Status:       {gpu['status']}",
    ]
    if gpu.get("driver_version"):
        lines.append(f"  Driver:       {gpu['driver_version']}")
    if gpu.get("message"):
        lines.append(f"  Message:      {gpu['message']}")
    if gpu.get("install_hint"):
        lines.append(f"  Hint:         {gpu['install_hint']}")
    if not gpu["devices"]:
        lines.append("  Devices:      none")
    for device in gpu["devices"]:
        lines.extend(
            [
                f"  Device {device['index']}:     {device['name']}",
                f"    UUID:       {device['uuid'] or 'unknown'}",
                f"    VRAM:       {_bytes_to_gib(device['vram_used_bytes'])} used / {_bytes_to_gib(device['vram_total_bytes'])} total",
                f"    Utilization: GPU {device['gpu_utilization_percent'] if device['gpu_utilization_percent'] is not None else 'unknown'}%, memory {device['memory_utilization_percent'] if device['memory_utilization_percent'] is not None else 'unknown'}%",
            ]
        )
        if device.get("status") != "ok" and device.get("message"):
            lines.append(f"    Message:    {device['message']}")

    return "\n".join(lines)


@click.command("doctor")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    show_default=True,
    help="Output format",
)
def doctor_command(output_format):
    """Show local CPU, RAM, GPU, and VRAM diagnostics."""
    info = collect_doctor_info()
    if output_format == "json":
        click.echo(json.dumps(info, indent=2))
        return
    click.echo(_render_table(info))
