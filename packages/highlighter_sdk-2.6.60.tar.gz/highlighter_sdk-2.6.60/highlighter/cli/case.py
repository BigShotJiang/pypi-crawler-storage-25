import json
from typing import List, Optional

import click

from ..cli.common import _to_pathlib_make_dir
from ..client import HLJSONEncoder
from ..client.base_models.base_models import (
    CaseMessageConnection,
    CaseType,
    CreateCaseMessagePayload,
    DeleteCaseMessagePayload,
    MessageType,
    UpdateCaseMessagePayload,
)
from ..client.tasks import export_case
from ..core import GQLBaseModel


class CreateCasePayload(GQLBaseModel):
    errors: List[str]
    case: Optional[CaseType] = None


def _parse_hhmmss_to_seconds(ctx, param, value):
    if value is None:
        return 0.0

    parts = value.split(":")
    if len(parts) != 3:
        raise click.BadParameter("must be in hh:mm:ss format")

    try:
        hours, minutes, seconds = [int(part) for part in parts]
    except ValueError as exc:
        raise click.BadParameter("must be in hh:mm:ss format") from exc

    if hours < 0 or minutes < 0 or seconds < 0 or minutes >= 60 or seconds >= 60:
        raise click.BadParameter("must be in hh:mm:ss format")

    return float(hours * 3600 + minutes * 60 + seconds)


@click.group("case")
@click.pass_context
def case_group(ctx):
    pass


@case_group.command("create")
@click.option(
    "-w",
    "--workflow-order-id",
    type=str,
    required=True,
    help="Workflow order ID",
)
@click.option(
    "-t",
    "--title",
    type=str,
    required=False,
    help="Case title",
)
@click.option(
    "-e",
    "--entity-id",
    type=str,
    required=False,
    help="Entity ID",
)
@click.option(
    "-f",
    "--initial-data-file-ids",
    type=str,
    required=False,
    help="Initial data file IDs (comma-separated)",
    multiple=True,
)
@click.pass_context
def create(ctx, workflow_order_id, title, entity_id, initial_data_file_ids):
    """Create a new case"""
    client = ctx.obj["client"]

    # Flatten, split, and filter comma-separated IDs
    file_ids = [
        fid.strip() for id_group in initial_data_file_ids for fid in id_group.split(",") if fid.strip()
    ]

    result = client.createCase(
        return_type=CreateCasePayload,
        workflowOrderId=workflow_order_id,
        title=title,
        entityId=entity_id,
        initialDataFileIds=file_ids if file_ids else None,
    ).gql_dict()

    click.echo(json.dumps(result, cls=HLJSONEncoder))

    # Exit with non-zero code if there are errors
    if result.get("errors"):
        raise click.ClickException("Case creation failed")


@case_group.command("export")
@click.option("-i", "--id", type=str, required=True, help="Case ID")
@click.option(
    "-o",
    "--output-dir",
    type=click.Path(dir_okay=True, file_okay=False),
    required=True,
    callback=_to_pathlib_make_dir,
    help="Files saved at output_dir/CASE_ID/",
)
@click.option(
    "--include-messages/--no-include-messages",
    default=True,
    show_default=True,
    help="Download case messages",
)
@click.option(
    "--file-structure",
    type=click.Choice(["uuid", "filename", "source-url", "flat"]),
    default="filename",
    show_default=True,
    help="How to name and organize downloaded data files",
)
@click.option(
    "-B",
    "--before",
    "before_seconds",
    type=str,
    default="00:00:00",
    show_default=True,
    callback=_parse_hhmmss_to_seconds,
    help="Time to extend the download window before the inferred start time (hh:mm:ss)",
)
@click.option(
    "-A",
    "--after",
    "after_seconds",
    type=str,
    default="00:00:00",
    show_default=True,
    callback=_parse_hhmmss_to_seconds,
    help="Time to extend the download window after the inferred end time (hh:mm:ss)",
)
@click.pass_context
def export_case_command(ctx, id, output_dir, include_messages, file_structure, before_seconds, after_seconds):
    """Download a case export under output_dir/CASE_ID."""
    client = ctx.obj["client"]
    try:
        case_dir = export_case(
            client,
            id,
            output_dir,
            include_messages=include_messages,
            file_structure=file_structure,
            before_seconds=before_seconds,
            after_seconds=after_seconds,
        )
    except ValueError as exc:
        raise click.ClickException(str(exc)) from exc

    click.echo(
        json.dumps(
            {
                "case_id": id,
                "output_dir": str(case_dir),
                "messages_included": include_messages,
                "file_structure": file_structure,
                "before_seconds": before_seconds,
                "after_seconds": after_seconds,
            },
            cls=HLJSONEncoder,
        )
    )


@case_group.command("delete")
@click.option("-i", "--id", type=str, required=True, help="The ID of the case to delete")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def delete(ctx, id, yes):
    """Delete a case"""
    if not yes:
        if not click.confirm(f"Are you sure you want to delete case {id}?"):
            click.echo("Aborted.")
            return
    client = ctx.obj["client"]

    class DeleteCasePayload(GQLBaseModel):
        errors: List[str]
        case: Optional[CaseType] = None

    result = client.deleteCase(return_type=DeleteCasePayload, id=id).gql_dict()
    click.echo(json.dumps(result, cls=HLJSONEncoder))


@case_group.group("message")
@click.pass_context
def message_group(ctx):
    """Commands for managing case messages"""
    pass


@message_group.command("create")
@click.option(
    "-c",
    "--case-id",
    type=str,
    required=True,
    help="Case ID to send the message to",
)
@click.option(
    "-m",
    "--content",
    type=str,
    required=True,
    help="Message content. Use @ai to trigger an AI response.",
)
@click.pass_context
def create_message(ctx, case_id, content):
    """Create a message in a case"""
    client = ctx.obj["client"]

    result = client.createCaseMessage(
        return_type=CreateCaseMessagePayload,
        caseId=case_id,
        content=content,
    ).gql_dict()

    click.echo(json.dumps(result, cls=HLJSONEncoder))

    # Exit with non-zero code if there are errors
    if result.get("errors"):
        raise click.ClickException("Message creation failed")


@message_group.command("get")
@click.option("-i", "--id", type=str, required=True, help="Message ID")
@click.pass_context
def get_message(ctx, id):
    """Get a single message by ID"""
    client = ctx.obj["client"]
    result = client.message(return_type=MessageType, id=id)
    if result is None:
        raise click.ClickException(f"Message {id} not found")
    result = result.gql_dict()
    click.echo(json.dumps(result, cls=HLJSONEncoder))


@message_group.command("list")
@click.option("-c", "--case-id", type=str, required=True, help="Case ID")
@click.option("-l", "--limit", type=int, default=100, help="Max messages to return")
@click.option("--after-id", type=str, required=False, help="List messages after this ID")
@click.pass_context
def list_messages(ctx, case_id, limit, after_id):
    """List messages in a case"""
    client = ctx.obj["client"]
    kwargs = {
        "caseId": case_id,
        "first": limit,
    }
    if after_id:
        kwargs["afterId"] = after_id

    result = client.caseMessages(return_type=CaseMessageConnection, **kwargs).gql_dict()
    click.echo(json.dumps(result, cls=HLJSONEncoder))


@message_group.command("update")
@click.option("-i", "--id", type=str, required=True, help="Message ID to update")
@click.option("-c", "--content", type=str, required=True, help="New message content")
@click.pass_context
def update_message(ctx, id, content):
    """Update an existing case message"""
    client = ctx.obj["client"]
    result = client.updateCaseMessage(
        return_type=UpdateCaseMessagePayload,
        id=id,
        content=content,
    ).gql_dict()
    click.echo(json.dumps(result, cls=HLJSONEncoder))

    if result.get("errors"):
        raise click.ClickException("Message update failed")


@message_group.command("delete")
@click.option("-i", "--id", type=str, required=True, help="Message ID to delete")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def delete_message(ctx, id, yes):
    """Delete a case message"""
    if not yes and not click.confirm(f"Are you sure you want to delete message {id}?"):
        click.echo("Aborted.")
        return

    client = ctx.obj["client"]
    result = client.deleteCaseMessage(return_type=DeleteCaseMessagePayload, id=id).gql_dict()
    click.echo(json.dumps(result, cls=HLJSONEncoder))

    if result.get("errors"):
        raise click.ClickException("Message deletion failed")
