import json
from itertools import islice
from typing import List, Optional

import click

from ..client import HLJSONEncoder
from ..client.base_models.page_info import PageInfo
from ..core import GQLBaseModel, paginate


@click.group("entity")
@click.pass_context
def entity_group(ctx):
    pass


class EntityListType(GQLBaseModel):
    id: str
    name: Optional[str] = None
    external_id: Optional[str] = None
    external_id_type: Optional[str] = None
    object_class_uuid: Optional[str] = None
    created_at: Optional[str] = None


class EntityTypeConnection(GQLBaseModel):
    page_info: PageInfo
    nodes: List[EntityListType]


@entity_group.command("list")
@click.option("--object-class-uuid", type=str, multiple=True, help="Filter by object class UUID")
@click.option("--external-id-type", type=str, multiple=True, help="Filter by external ID type")
@click.option("--query", type=str, default=None, help="Search by name or external ID")
@click.option(
    "--format",
    type=click.Choice(["table", "json"]),
    default="table",
    show_default=True,
    help="Output format",
)
@click.option("--limit", type=int, default=100, show_default=True, help="Maximum number of results")
@click.pass_context
def list_command(ctx, object_class_uuid, external_id_type, query, format, limit):
    """List entities for the account."""
    client = ctx.obj["client"]

    kwargs = {}
    if object_class_uuid:
        kwargs["objectClassUuids"] = list(object_class_uuid)
    if external_id_type:
        kwargs["externalIdType"] = list(external_id_type)
    if query:
        kwargs["query"] = query

    items_iter = paginate(client.entities, EntityTypeConnection, page_size=min(limit, 200), **kwargs)
    items = list(islice(items_iter, limit))

    if format == "json":
        click.echo(json.dumps([item.model_dump(mode="json") for item in items], indent=2, cls=HLJSONEncoder))
        return

    if not items:
        click.echo("No entities found.")
        return

    click.echo(f"Entities ({len(items)} shown):")
    click.echo()
    for item in items:
        oc = f"  oc:{item.object_class_uuid}" if item.object_class_uuid else ""
        click.echo(f"  {item.id}  {item.name or '—'}  ext:{item.external_id}  [{item.external_id_type}]{oc}")
    click.echo()


@entity_group.command("create")
@click.option("-n", "--name", type=str, required=True, help="Entity name")
@click.option("--object-class-uuid", type=str, required=False, help="Object class UUID")
@click.option("--external-id", type=str, required=False, help="External ID")
@click.option("--external-id-type", type=str, required=False, help="External ID type")
@click.option("--parent-id", type=str, required=False, help="Parent entity ID")
@click.option("--coordinates", type=str, required=False, help="WKT geometry (e.g. POINT(153.0 -27.5))")
@click.option("--active-from", type=str, required=False, help="Active from (ISO8601 datetime)")
@click.option("--active-until", type=str, required=False, help="Active until (ISO8601 datetime)")
@click.pass_context
def create(
    ctx,
    name,
    object_class_uuid,
    external_id,
    external_id_type,
    parent_id,
    coordinates,
    active_from,
    active_until,
):
    """Create a new entity"""
    client = ctx.obj["client"]

    class CreateEntityPayload(GQLBaseModel):
        errors: List[str]
        entity: Optional[EntityListType] = None

    kwargs = dict(name=name)
    if object_class_uuid:
        kwargs["objectClassUuid"] = object_class_uuid
    if external_id:
        kwargs["externalId"] = external_id
    if external_id_type:
        kwargs["externalIdType"] = external_id_type
    if parent_id:
        kwargs["parentId"] = parent_id
    if coordinates:
        kwargs["coordinates"] = coordinates
    if active_from:
        kwargs["activeFrom"] = active_from
    if active_until:
        kwargs["activeUntil"] = active_until

    result = client.createEntity(return_type=CreateEntityPayload, **kwargs).gql_dict()
    click.echo(json.dumps(result, cls=HLJSONEncoder))

    if result.get("errors"):
        raise click.ClickException("Entity creation failed")


@entity_group.command("update")
@click.option("-i", "--id", type=str, required=True, help="Entity ID")
@click.option("-n", "--name", type=str, required=False, help="New name")
@click.option("--object-class-uuid", type=str, required=False, help="Object class UUID")
@click.option("--external-id", type=str, required=False, help="External ID")
@click.option("--external-id-type", type=str, required=False, help="External ID type")
@click.option("--parent-id", type=str, required=False, help="Parent entity ID")
@click.option("--coordinates", type=str, required=False, help="WKT geometry (e.g. POINT(153.0 -27.5))")
@click.option("--active-from", type=str, required=False, help="Active from (ISO8601 datetime)")
@click.option("--active-until", type=str, required=False, help="Active until (ISO8601 datetime)")
@click.pass_context
def update(
    ctx,
    id,
    name,
    object_class_uuid,
    external_id,
    external_id_type,
    parent_id,
    coordinates,
    active_from,
    active_until,
):
    """Update an existing entity"""
    client = ctx.obj["client"]

    class UpdateEntityPayload(GQLBaseModel):
        errors: List[str]
        entity: Optional[EntityListType] = None

    kwargs = dict(id=id)
    if name:
        kwargs["name"] = name
    if object_class_uuid:
        kwargs["objectClassUuid"] = object_class_uuid
    if external_id:
        kwargs["externalId"] = external_id
    if external_id_type:
        kwargs["externalIdType"] = external_id_type
    if parent_id:
        kwargs["parentId"] = parent_id
    if coordinates:
        kwargs["coordinates"] = coordinates
    if active_from:
        kwargs["activeFrom"] = active_from
    if active_until:
        kwargs["activeUntil"] = active_until

    result = client.updateEntity(return_type=UpdateEntityPayload, **kwargs).gql_dict()
    click.echo(json.dumps(result, cls=HLJSONEncoder))

    if result.get("errors"):
        raise click.ClickException("Entity update failed")


@entity_group.command("count")
@click.option("--object-class-uuid", type=str, multiple=True, help="Filter by object class UUID")
@click.option("--external-id-type", type=str, multiple=True, help="Filter by external ID type")
@click.option("--query", type=str, default=None, help="Search by name or external ID")
@click.pass_context
def count_command(ctx, object_class_uuid, external_id_type, query):
    """Count entities matching given filters."""
    client = ctx.obj["client"]

    kwargs = {}
    if object_class_uuid:
        kwargs["objectClassUuids"] = list(object_class_uuid)
    if external_id_type:
        kwargs["externalIdType"] = list(external_id_type)
    if query:
        kwargs["query"] = query

    class EntityStatsType(GQLBaseModel):
        count: int

    result = client.entityStats(return_type=EntityStatsType, **kwargs)
    click.echo(result.count)


@entity_group.command("delete")
@click.option("-i", "--id", type=str, required=True, help="The ID of the entity to delete")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def delete(ctx, id, yes):
    """Delete an entity"""
    if not yes:
        if not click.confirm(f"Are you sure you want to delete entity {id}?"):
            click.echo("Aborted.")
            return
    client = ctx.obj["client"]

    class EntityType(GQLBaseModel):
        id: Optional[str] = None

    class DeleteEntityPayload(GQLBaseModel):
        errors: List[str]
        entity: Optional[EntityType] = None

    result = client.deleteEntity(return_type=DeleteEntityPayload, id=id).gql_dict()
    click.echo(json.dumps(result, cls=HLJSONEncoder))
