# Changelog

## [0.4.2] - 2026-05-03

### Fixes
- **executor**: preExec {{var}} substitution includes VariableConfig values (#88)

### Changes
- **plan**: add Issue #84 preExec render order implementation plan
- **spec**: add Issue #84 preExec render order fix design

[0.4.2]: https://github.com/zhuxixi/zima-blue-cli/compare/v0.4.1...v0.4.2

## [0.4.1] - 2026-05-03

### Fixes
- **bundle**: inject_dynamic_vars priority when variable is None (#86)
- **executor**: run preExec before template rendering for dynamic vars (#85)

### Changes
- **plan**: add Issue #84 preExec render order implementation plan
- **spec**: add Issue #84 preExec render order fix design

[0.4.1]: https://github.com/zhuxixi/zima-blue-cli/compare/v0.4.0...v0.4.1

## [0.4.0] - 2026-05-03

### Features
- **pjob**: CLI support for postExec actions configuration (#73)
- **scenes**: add default_actions to Scene for postExec label transitions
- **pjob**: add actions parameter to PJobConfig.create()
- PR code review automation with preExec actions and label management (#35)
- PJob 运行时状态追踪与生命周期管理 (#70) (#72)

### Fixes
- **pjob**: improve actions_remove empty list message and refactor tests (#81)
- **scenes**: deserialize default_actions dict from user scenes.yaml
- **quickstart**: pass scene default_actions to generated PJob (#74)
- **actions_runner**: inject pr_diff via fetch_diff in preExec scan_pr (#75 follow-up)
- **agent**: do not pass --work-dir or --cwd to Claude CLI (#64) (#71)
- **agent**: use --cwd for Claude agent instead of --work-dir (#69)

### Changes
- Merge pull request #78 from zhuxixi/fix/74-quickstart-actions
- add implementation plan for PJob actions CLI (#73)
- add design spec for PJob actions CLI (#73)

[0.4.0]: https://github.com/zhuxixi/zima-blue-cli/compare/v0.3.1...v0.4.0

## [0.3.1] - 2026-04-27

### Features
- plugin-based Action Provider architecture (#63) (#65)

### Fixes
- **scenes**: change code-review template to use stable trigger keyword (#67)

### Changes
- add implementation plan for issue #60 (remove gemini agent type)
- add spec for issue #60 (remove gemini agent type)

[0.3.1]: https://github.com/zhuxixi/zima-blue-cli/compare/v0.3.0...v0.3.1

## [0.3.0] - 2026-04-24

### Features
- add zima quickstart interactive wizard (#54) (#59)
- **serialization**: add core serialization module for snake_case/camelCase mapping (#14)
- PR CR automation with postExec actions (#56)
- **templates**: add reviewer PJob and variable configs
- **templates**: add reviewer-cr workflow template
- **executor**: integrate postExec actions after agent execution
- **execution**: add ActionsRunner for postExec automation
- **pjob**: add actions field to PJobSpec for post-exec automation
- **models**: add PostExecAction and ActionsConfig for PJob automation
- **github**: add GitHubOps wrapper for gh CLI
- **review**: add ReviewParser for structured review output
- **review**: add ReviewResult and ReviewIssue dataclasses
- **agent**: omit --model flag by default for all agent types (#55)

### Fixes
- allow list deserialization to handle non-dict items via from_dict()
- **serialization**: address round-1 CR feedback on PR #58
- address round-4 CR feedback + lint
- address round-3 CR feedback
- address round-2 CR feedback
- address CR feedback on PR CR automation
- **commands**: avoid list builtin shadowing in --example flag handlers

### Changes
- add implementation plan for issue #60 (remove gemini agent type)
- add spec for issue #60 (remove gemini agent type)
- type: ExtendDef.from_dict accepts dict | str
- convert serialization.py docstrings to Google style
- style: remove unused omit_empty import from pjob.py
- migrate package management from pip to uv (#51)
- test: add round-trip tests for all models with auto serialization (#14) (#14)
- migrate Schedule models to YamlSerializable with auto mapping (#14)
- migrate Actions models to YamlSerializable with auto mapping (#14)
- migrate PJob nested classes to YamlSerializable with auto mapping (#14)
- migrate Env/Variable/PMG/Workflow/Agent configs to auto spec mapping (#14)
- BaseConfig and Metadata use YamlSerializable with auto spec mapping (#14)
- implementation plan for issue #14 - unified camelCase/snake_case serialization
- design spec for issue #14 - unified camelCase/snake_case serialization
- style: black formatting
- test(integration): add end-to-end reviewer flow test

[0.3.0]: https://github.com/zhuxixi/zima-blue-cli/compare/v0.2.0...v0.3.0

## [0.2.0] - 2026-04-22

### Features
- add release skill for version bump and GitHub Release automation
- **executor**: move PJob temp dir from system temp to ZIMA_HOME (#47)
- automated verification suite for issue #38 (#44)

### Fixes
- **release-skill**: use uv run and add uv.lock to bump workflow
- update AGENTS.md temp path, use temp_dir fixture in tests (#47)
- **pjob**: background log dir respects ZIMA_HOME (#48)
- add --version/-v flag to zima CLI (#46)
- **daemon**: error handling improvements in daemon commands (#41)

### Changes
- Merge pull request #50 from zhuxixi/fix/issue-47-pjob-temp-dir
- update CLAUDE.md Data Layout with temp/pjobs/ directory (#47)
- update session history
- fix data layout docs to match actual implementation (Issue #43)
- style: fix black formatting in mock_agent.py (#45) (#45)

[0.2.0]: https://github.com/zhuxixi/zima-blue-cli/compare/v0.1.1...v0.2.0
