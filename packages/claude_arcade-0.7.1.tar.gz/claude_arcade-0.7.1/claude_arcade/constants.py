"""Shared runtime constants for claude-arcade."""

# Used by hook integration (start / stop game process)
PID_FILE  = "/tmp/.claude-arcade.pid"
STOP_FILE = "/tmp/.claude-arcade-stop"
