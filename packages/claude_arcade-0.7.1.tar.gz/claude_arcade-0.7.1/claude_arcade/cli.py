"""CLI entry point for claude-arcade."""

import argparse
import curses
import os
import sys
import time


DESCRIPTION = """\
claude-arcade — play games while Claude thinks

Play a mini-game automatically every time Claude Code runs a tool,
or launch one manually whenever you feel like it.
"""

EPILOG = """\
examples:
  claude-arcade setup        configure Claude Code hooks (one-time setup)
  claude-arcade play         open the game menu
  claude-arcade play bird    jump straight into Bird Hunt
  claude-arcade play pong    jump straight into Pong
  claude-arcade unsetup      remove hooks from Claude Code settings
"""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _show_countdown(stdscr) -> None:
    """Animated 3-2-1-START countdown shown before each game."""
    h, w = stdscr.getmaxyx()

    if curses.has_colors():
        curses.init_pair(10, curses.COLOR_WHITE, -1)
        curses.init_pair(11, curses.COLOR_GREEN, -1)
        C_DIM  = curses.color_pair(10) | curses.A_DIM
        C_NUM  = curses.color_pair(10) | curses.A_BOLD
        C_GO   = curses.color_pair(11) | curses.A_BOLD
    else:
        C_DIM  = curses.A_DIM
        C_NUM  = curses.A_BOLD
        C_GO   = curses.A_BOLD | curses.A_REVERSE

    # 5-row block-font digits (same style as splash title)
    DIGITS = {
        '3': ["▀███▀", "   ██", " ████", "   ██", "▀███▀"],
        '2': ["▀███▀", "   ██", " ████", "██   ", "█████"],
        '1': ["  █  ", " ██  ", "  █  ", "  █  ", "▀███▀"],
    }

    for ch in ('3', '2', '1'):
        rows = DIGITS[ch]
        bh, bw = len(rows), len(rows[0])
        sy = max(0, (h - bh) // 2)
        sx = max(0, (w - bw) // 2)

        # Fade in: dim flash → bold
        for attr, delay in ((C_DIM, 0.12), (C_NUM, 0.65)):
            stdscr.erase()
            for dy, line in enumerate(rows):
                try:
                    stdscr.addstr(sy + dy, sx, line, attr)
                except curses.error:
                    pass
            stdscr.refresh()
            time.sleep(delay)

    # START
    stdscr.erase()
    msg = "  START!  "
    sy  = h // 2
    sx  = max(0, (w - len(msg)) // 2)
    try:
        stdscr.addstr(sy, sx, msg, C_GO)
    except curses.error:
        pass
    stdscr.refresh()
    try:
        curses.beep()
    except Exception:
        pass
    time.sleep(0.45)


def _game_fn(game_key: str):
    """Return the game function for a given key (no curses.wrapper — caller owns the session)."""
    if game_key == "bird":
        from .games.bird import bird_game
        return bird_game
    elif game_key == "pong":
        from .games.pong import pong_game
        return pong_game
    elif game_key == "race":
        from .games.race import race_game
        return race_game
    return None


def _run_menu_then_game() -> None:
    """Show splash + menu, then launch the chosen game — single curses session."""
    from .splash import show_menu

    def _inner(stdscr):
        game_key = show_menu(stdscr)
        if game_key is None:
            return
        fn = _game_fn(game_key)
        if fn is None:
            return
        # Countdown, then launch — all in the same curses session
        _show_countdown(stdscr)
        stdscr.clear()
        stdscr.refresh()
        fn(stdscr)

    try:
        curses.wrapper(_inner)
    except KeyboardInterrupt:
        pass


def _open_new_terminal(cmd: str) -> bool:
    """Open a new OS terminal window running cmd. Returns True on success."""
    import subprocess, shutil

    if sys.platform == "darwin":
        if shutil.which("osascript"):
            for app, script in [
                ("iTerm2",   f'tell application "iTerm2" to create window with default profile command "{cmd}"'),
                ("Terminal", f'tell application "Terminal" to do script "{cmd}"'),
            ]:
                try:
                    r = subprocess.run(["osascript", "-e", f'tell application "{app}" to activate'],
                                       capture_output=True, timeout=2)
                    if r.returncode == 0:
                        subprocess.Popen(["osascript", "-e", script])
                        return True
                except Exception:
                    continue
    else:
        for term, flag in [("gnome-terminal", "--"), ("xterm", "-e"),
                            ("konsole", "-e"), ("xfce4-terminal", "-e")]:
            if shutil.which(term):
                try:
                    subprocess.Popen([term, flag] + cmd.split())
                    return True
                except Exception:
                    continue
    return False


def _has_real_tty() -> bool:
    try:
        fd = os.open("/dev/tty", os.O_RDWR)
        os.close(fd)
        return True
    except OSError:
        return False


def _redirect_to_tty() -> None:
    tty_fd = os.open("/dev/tty", os.O_RDWR)
    for fd in (0, 1, 2):
        os.dup2(tty_fd, fd)
    if tty_fd > 2:
        os.close(tty_fd)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:  # noqa: C901
    if sys.platform == "win32":
        print("claude-arcade requires a Unix-like terminal (macOS / Linux).")
        sys.exit(1)

    # ── hidden internal commands (called by hooks / new-window launcher) ──
    if len(sys.argv) >= 2 and sys.argv[1] == "_play_direct":
        # Running inside a fresh terminal window — redirect to /dev/tty then
        # show menu (or jump to specific game if a key was passed as argv[2]).
        _redirect_to_tty()
        if len(sys.argv) >= 3:
            fn = _game_fn(sys.argv[2])
            if fn:
                try:
                    def _direct(stdscr):
                        _show_countdown(stdscr)
                        stdscr.clear()
                        stdscr.refresh()
                        fn(stdscr)
                    curses.wrapper(_direct)
                except KeyboardInterrupt:
                    pass
        else:
            _run_menu_then_game()
        return

    if len(sys.argv) == 2 and sys.argv[1] in ("start", "stop"):
        if sys.argv[1] == "start":
            from .games.bird import start_background
            start_background()
        else:
            from .games.bird import stop_background
            stop_background()
        return

    # ── normal CLI ───────────────────────────────────────────────────────────
    parser = argparse.ArgumentParser(
        prog="claude-arcade",
        description=DESCRIPTION,
        epilog=EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="cmd", metavar="<command>")

    sub.add_parser("setup",   help="Configure Claude Code hooks (one-time setup)")
    sub.add_parser("unsetup", help="Remove Claude Code hooks")

    play_p = sub.add_parser("play", help="Open the game menu (or pass a game name)")
    play_p.add_argument(
        "game",
        nargs="?",
        default=None,
        choices=["bird", "pong", "race"],
        help="Game to jump straight into: bird | pong | race",
    )

    args = parser.parse_args()

    if args.cmd == "setup":
        from .setup_hooks import setup
        setup()

    elif args.cmd == "unsetup":
        from .setup_hooks import unsetup
        unsetup()

    elif args.cmd == "play":
        import shutil
        bin_path = shutil.which("claude-arcade") or "claude-arcade"

        if _has_real_tty():
            _redirect_to_tty()
            if args.game:
                fn = _game_fn(args.game)
                if fn:
                    try:
                        def _with_countdown(stdscr):
                            _show_countdown(stdscr)
                            stdscr.clear()
                            stdscr.refresh()
                            fn(stdscr)
                        curses.wrapper(_with_countdown)
                    except KeyboardInterrupt:
                        pass
            else:
                _run_menu_then_game()
        else:
            # No tty — open a new terminal window
            print("Opening claude-arcade in a new terminal window...")
            extra = f" {args.game}" if args.game else ""
            if not _open_new_terminal(f"{bin_path} _play_direct{extra}"):
                print("Could not open a terminal window automatically.")
                print(f"Please open a new terminal and run:  claude-arcade play")

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
