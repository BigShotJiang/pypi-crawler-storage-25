"""claude-arcade game modules."""
