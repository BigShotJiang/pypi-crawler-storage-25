# Pong

Classic paddle battle against a CPU opponent. First to 5 points wins.

## How to play

```bash
claude-arcade play pong
```

## Controls

| Key | Action |
|-----|--------|
| `W` / `↑` | Move paddle up (hold for continuous movement) |
| `S` / `↓` | Move paddle down (hold for continuous movement) |
| `Q` | Quit |

## Scoring

- Score a point when the ball passes the CPU's paddle
- CPU scores when the ball passes yours
- First to **5 points** wins

## How to beat the CPU

The CPU is intentionally imperfect:

- **Reaction delay** — re-evaluates where to move every ~280ms, not every frame. A quick shot catches it mid-decision.
- **Positional error** — aims slightly off-target. The faster the ball gets, the larger the error.
- **Blind spot** — when the ball moves away from the CPU, it drifts toward centre rather than tracking.
- **Speed gap** — CPU moves at 12 ch/s; you move at 22 ch/s. Sharp angled shots win.

**Strategy:** Hit the ball toward the edges of the playfield. The extreme angles force the CPU to travel further than it can in time.

## Adjusting difficulty

In `game.py`, tune these constants at the top of the file:

```python
PADDLE_SPD = 22.0    # player speed (chars/sec)
CPU_SPEED  = 12.0    # cpu speed   (chars/sec) — lower = easier
CPU_REACT  = 0.28    # seconds between cpu decisions — higher = easier
CPU_ERROR  = 2.5     # positional error scale — higher = easier
```
