"""Pong game."""
from .game import pong_game

__all__ = ["pong_game"]
