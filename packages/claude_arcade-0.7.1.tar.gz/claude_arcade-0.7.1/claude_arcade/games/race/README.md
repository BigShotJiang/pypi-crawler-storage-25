# Road Racer

Top-down traffic dodger. Stay on the road, avoid the cars, go as far as you can.

## How to play

```bash
claude-arcade play race
```

## Controls

| Key | Action |
|-----|--------|
| `←` / `A` | Move left one lane |
| `→` / `D` | Move right one lane |
| `Q` | Quit |

Lane changes are animated — your car smoothly slides across rather than teleporting.

## HUD

```
♥♥♥   87 km/h   1.4 km   Score: 1420
```

| Element | Meaning |
|---------|---------|
| `♥♥♥` | Lives remaining (starts at 3) |
| `km/h` | Current speed (increases over time) |
| `km` | Distance travelled |
| Score | Distance × 10 |

## Traffic

Three enemy types, each a different colour:

| Sprite | Type | Colour |
|--------|------|--------|
| `▐▄▓▄▌` | Sedan | Red |
| `▐███▌` | Truck | Yellow |
| `▐▄▄▄▌` | Sports car | White |

## Difficulty

- Speed increases continuously — no upper limit on difficulty
- Enemy spawn rate increases with speed
- After a crash you get 2 seconds of invincibility (car flashes)

## Road layout

```
▓▓▓▓║    lane 0    ┊    lane 1    ┊    lane 2    ║▓▓▓▓
```

- `▓` = grass with scrolling trees (`▲`)
- `║` = road edge
- `┊` = scrolling lane dividers (scroll speed reflects your speed)
