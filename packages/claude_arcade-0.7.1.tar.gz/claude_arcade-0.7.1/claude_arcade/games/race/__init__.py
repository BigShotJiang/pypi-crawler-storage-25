"""Road Racer game."""
from .game import race_game

__all__ = ["race_game"]
