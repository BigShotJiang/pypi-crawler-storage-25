"""Bird Hunt game."""
from .game import bird_game, start_background, stop_background

__all__ = ["bird_game", "start_background", "stop_background"]
