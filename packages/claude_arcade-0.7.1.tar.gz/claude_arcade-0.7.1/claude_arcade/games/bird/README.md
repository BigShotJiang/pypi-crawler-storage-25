# Bird Hunt

Shoot birds flying across your terminal before they escape.

## How to play

```bash
claude-arcade play bird
```

## Controls

| Key | Action |
|-----|--------|
| Arrow keys / WASD | Move crosshair |
| `Space` | Shoot |
| `Q` | Quit |

## Birds

| Sprite | Name | Speed | Points |
|--------|------|-------|--------|
| `▄▀` / `*██>` | Sparrow | Fast | 3 |
| `▄▀▀▀▀▀` / `*████>` | Seagull | Normal | 1 |
| `▄▀▀▀▀▀▀▀` / `*██████▄>` | Pterodactyl | Slow | 2 |

Birds fly in from both sides and flap their wings as they move. Hit them anywhere — bullet hits the full height of the sprite.

## Difficulty

Spawn rate increases over time — the longer you play, the more birds appear simultaneously.

## Adding a new bird type

Bird types are defined in `game.py` under `Bird.TYPES`. Each type needs:

```python
{
    "frames_r": [  # Two animation frames, flying right
        ["row0_frame0", "row1_frame0"],
        ["row0_frame1", "row1_frame1"],
    ],
    "frames_l": [  # Same, flying left (mirrored)
        ...
    ],
    "speed":      1.0,   # chars/sec multiplier
    "points":     1,     # score on hit
    "anim_rate":  8,     # ticks between wing flaps
}
```

All rows within a type must be the same width (pad with spaces).
