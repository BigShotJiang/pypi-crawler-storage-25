# Contributing to claude-arcade

Thanks for wanting to add a game or improve the project!

## Adding a new game

Each game lives in its own folder under `src/claude_arcade/games/`. Here's everything you need to do — no other files require changes except registering the game in two places.

### 1. Create the game folder

```
src/claude_arcade/games/<your-game>/
├── __init__.py
├── game.py
└── README.md
```

### 2. Write the game function

`game.py` must expose a single entry-point function:

```python
def your_game(stdscr) -> None:
    """
    stdscr is a curses window passed in by curses.wrapper().
    The function should block until the player quits.
    """
    ...
```

Useful patterns already in the codebase:

```python
from ...constants import STOP_FILE   # check this file to stop when called by hooks
import os, time, curses, signal

def your_game(stdscr):
    curses.curs_set(0)
    stdscr.nodelay(True)
    stdscr.keypad(True)

    running = True

    def on_signal(sig, frame):
        nonlocal running
        running = False

    signal.signal(signal.SIGTERM, on_signal)
    signal.signal(signal.SIGINT,  on_signal)

    while running:
        # stop-file check (hook integration)
        if os.path.exists(STOP_FILE):
            try:
                os.unlink(STOP_FILE)
            except OSError:
                pass
            break

        h, w = stdscr.getmaxyx()
        # ... game logic ...

        stdscr.refresh()
        time.sleep(1 / 30)   # ~30 fps
```

### 3. Export from `__init__.py`

```python
from .game import your_game
__all__ = ["your_game"]
```

### 4. Write `README.md`

Include: description, controls table, scoring, tips for players, and a brief note for contributors on how to extend it.

### 5. Register the game in two places

**`src/claude_arcade/splash.py`** — add to the `GAMES` list:

```python
GAMES = [
    {"name": "Bird Hunt", "key": "bird", "desc": "..."},
    {"name": "Pong",      "key": "pong", "desc": "..."},
    {"name": "Your Game", "key": "your-game", "desc": "One-line description"},  # add this
]
```

**`src/claude_arcade/cli.py`** — add to `_game_fn()`:

```python
def _game_fn(game_key: str):
    if game_key == "bird":
        from .games.bird import bird_game
        return bird_game
    elif game_key == "pong":
        from .games.pong import pong_game
        return pong_game
    elif game_key == "your-game":              # add this
        from .games.your_game import your_game
        return your_game
    return None
```

Also add `"your-game"` to the `choices` list in the `play` subparser.

### 6. Test it

```bash
pip install -e .
claude-arcade play your-game
```

## Code style

- No external dependencies — stdlib + curses only
- Games must handle `SIGTERM` cleanly (for hook stop)
- Games must check `STOP_FILE` in their main loop
- Keep each game fully self-contained in its folder

## Submitting a PR

1. Fork the repo
2. Create a branch: `git checkout -b add-snake`
3. Make your changes
4. Open a pull request with a short description and a screenshot/recording of the game

## Reporting bugs

Open an issue at [github.com/anshuman-dev/claude-arcade/issues](https://github.com/anshuman-dev/claude-arcade/issues).
