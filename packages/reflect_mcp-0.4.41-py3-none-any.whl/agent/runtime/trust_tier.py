# @scry.entry
# id: code.trust-tier~bd6bd477
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:trust", "trust",
#        "topic:tier", "tier", "topic:S2b", "S2b", "kind:code", "code",
#        "substrate-evolution", "trust-tier", "admission-control",
#        "scrutiny", "AssignTier", "ScrutinyLevel", "AdmissionCheck",
#        "TrustTier", "FR6", "FR7"]
# summary: >
#   S2b implementation — trust-tier Python module. Maps verified sender
#   identity to TrustTier (ORIGINATOR, SIBLING, UNKNOWN) per
#   spec.trust-tier~1445aaf7. AssignTier consumes sender_identity from
#   S2a's VerifyProvenance; UNTRUSTED sentinel yields UNKNOWN directly
#   without calling AssignTier (INV-1). ScrutinyLevel returns a
#   ScrutinySpec per tier (scrutiny is monotone with tier: INV-3).
#   AdmissionCheck gates on declared mandatory-core principles (FR7).
#   Registry is a plain dict — deployment concern, not spec concern.
#   Also: trust-tier, TrustTier, AssignTier, ScrutinyLevel, ScrutinySpec,
#   AdmissionCheck, originator tier, sibling tier, unknown tier, admission,
#   scrutiny level, S2b, substrate-evolution, trust_tier.py.
# rationale: >
#   Missing this means S2d (trust-score) and S5d (remediation) have no
#   TrustTier input type to import; graduated scrutiny cannot be applied
#   to inter-node messages.
# applies: >
#   implementing trust-tier assignment, designing admission control,
#   auditing inter-node message scrutiny, reviewing specs that consume
#   TrustTier, building routing with tier differentiation
# seeded_questions:
#   - "What are the trust tiers?"
#   - "How does AssignTier work?"
#   - "What is AdmissionCheck?"
#   - "What scrutiny applies to each tier?"
#   - "trust_tier.py S2b substrate-evolution"
#   - "TrustTier ORIGINATOR SIBLING UNKNOWN scrutiny"
# @scry.entry.end

"""
S2b — Trust Tier (spec.trust-tier~1445aaf7)

Maps a verified sender identity to a trust tier and defines scrutiny
levels per tier, including an admission-control mechanism that gates
communication on declared mandatory-core principles.

Requirements satisfied:
- FR6: Three-tier minimum taxonomy (ORIGINATOR, SIBLING, UNKNOWN);
       scrutiny monotone with tier (INV-3).
- FR7: AdmissionCheck gates on declared mandatory-core principles
       without bilateral negotiation (INV-5).
- INV-1: UNTRUSTED sentinel from S2a yields UNKNOWN directly; it
         MUST NOT be passed into AssignTier (no identity to look up).
- INV-3: Scrutiny is monotone: ORIGINATOR >= SIBLING > UNKNOWN.
- INV-4: Admission does not verify behavioral conformance — only
         declared intent (that is S2c/S2d's concern).
- INV-5: AdmissionCheck is unilateral; no round-trip required.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import FrozenSet, List, Optional, Set


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

class TrustTier(str, Enum):
    """
    Three-tier minimum taxonomy for sender identity trust (FR6).

    ORIGINATOR: Human originator or an entity with originator-level
                authority (provably signed by originator key). Highest
                trust; least restrictive scrutiny.
    SIBLING:    A known peer in the substrate — provisioned, registered,
                previously exchanged keys. Moderate trust.
    UNKNOWN:    Not in the known-sibling registry, or identity could not
                be matched to a provisioned peer. Also assigned when
                VerifyProvenance returned UNTRUSTED (INV-1). Lowest
                trust; most restrictive scrutiny.

    Implementations may add sub-tiers (e.g. SIBLING_PROBATIONARY) but
    may not reduce below these three. Scrutiny MUST be monotone with tier.
    """
    ORIGINATOR = "originator"
    SIBLING = "sibling"
    UNKNOWN = "unknown"


class ActionScope(str, Enum):
    """
    The class of actions a consumer may take in response to a message
    at a given trust tier, without further verification (FR6).

    Ordered from most to least restrictive:
    READ_ONLY     < LOCAL_WRITE < NETWORK_WRITE < SPAWN < WIND_DOWN
    """
    READ_ONLY = "read_only"
    LOCAL_WRITE = "local_write"
    NETWORK_WRITE = "network_write"
    SPAWN = "spawn"
    WIND_DOWN = "wind_down"


@dataclass(frozen=True)
class ScrutinySpec:
    """
    Structured scrutiny requirements for a message at a given tier (FR6).

    max_action_scope:            The highest action class a consumer may
                                 execute in response without further check.
    requires_quorum_confirmation: Must this message's effect be confirmed
                                 by quorum before execution? True for
                                 UNKNOWN; False for SIBLING and ORIGINATOR
                                 on non-quorum-required operations (C-3:
                                 ORIGINATOR does not bypass AR1).
    require_conformance_check:  Must this sender's conformance be probed
                                 before acting on the message?
    """
    max_action_scope: ActionScope
    requires_quorum_confirmation: bool
    require_conformance_check: bool


# Normative ScrutinySpec per tier (INV-3: monotone with tier).
_SCRUTINY: dict[TrustTier, ScrutinySpec] = {
    TrustTier.UNKNOWN: ScrutinySpec(
        max_action_scope=ActionScope.LOCAL_WRITE,
        requires_quorum_confirmation=True,
        require_conformance_check=True,
    ),
    TrustTier.SIBLING: ScrutinySpec(
        max_action_scope=ActionScope.NETWORK_WRITE,
        requires_quorum_confirmation=False,
        require_conformance_check=False,
    ),
    TrustTier.ORIGINATOR: ScrutinySpec(
        max_action_scope=ActionScope.WIND_DOWN,
        requires_quorum_confirmation=False,   # C-3: AR1 still applies
        require_conformance_check=False,
    ),
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def AssignTier(
    sender_identity: str,
    originator_identity: Optional[str] = None,
    sibling_registry: Optional[Set[str]] = None,
) -> TrustTier:
    """
    Map a verified sender identity to a TrustTier (FR6, INV-1, INV-2).

    Callers MUST NOT pass the UNTRUSTED sentinel (None) from S2a here.
    When VerifyProvenance returns UNTRUSTED, the caller MUST return
    TrustTier.UNKNOWN directly — there is no identity to look up.

    Args:
        sender_identity:    The verified identity string from S2a's
                            VerifyProvenance. MUST NOT be None.
        originator_identity: The locally known originator key/identity.
                            If None, ORIGINATOR tier is never assigned.
        sibling_registry:  Set of known-sibling identities. If None,
                            SIBLING tier is never assigned.
    Returns:
        TrustTier — ORIGINATOR, SIBLING, or UNKNOWN.
    Raises:
        ValueError if sender_identity is None (caller violated INV-1).
    """
    if sender_identity is None:
        raise ValueError(
            "AssignTier received None — caller must handle UNTRUSTED "
            "sentinel from VerifyProvenance by returning UNKNOWN directly "
            "(INV-1: UNTRUSTED must not flow into AssignTier)."
        )
    if originator_identity and sender_identity == originator_identity:
        return TrustTier.ORIGINATOR
    if sibling_registry and sender_identity in sibling_registry:
        return TrustTier.SIBLING
    return TrustTier.UNKNOWN


def ScrutinyLevel(tier: TrustTier) -> ScrutinySpec:
    """
    Return the ScrutinySpec for a given TrustTier (FR6, INV-3).

    Scrutiny is monotone with tier: ORIGINATOR is at least as permissive
    as SIBLING; SIBLING is strictly more permissive than UNKNOWN.

    Args:
        tier: The TrustTier to look up.
    Returns:
        ScrutinySpec describing max_action_scope and confirmation flags.
    """
    return _SCRUTINY[tier]


def AdmissionCheck(
    declaration: FrozenSet[str],
    required_principles: FrozenSet[str],
) -> bool:
    """
    Gate communication on declared mandatory-core principles (FR7).

    Returns True iff the declaration contains every ID in
    required_principles. The check is unilateral: no round-trip
    to the sender; no behavioral conformance testing (INV-4, INV-5).

    required_principles MUST include all mandatory-core principle IDs
    from the local principles.md (per S1). It MAY additionally include
    locally configured extended principles.

    Args:
        declaration:         FrozenSet of principle IDs the sender declares.
        required_principles: FrozenSet of IDs that must all be present.
    Returns:
        True if all required IDs are declared; False otherwise.
    """
    return required_principles.issubset(declaration)


# ---------------------------------------------------------------------------
# Convenience: tier from UNTRUSTED-aware call result
# ---------------------------------------------------------------------------

def tier_from_verify_result(
    verify_result: Optional[str],
    originator_identity: Optional[str] = None,
    sibling_registry: Optional[Set[str]] = None,
) -> TrustTier:
    """
    Convenience wrapper: handle the full VerifyProvenance return path.

    VerifyProvenance returns either a sender_identity string or the
    UNTRUSTED sentinel (None). This wrapper applies INV-1 — if the
    result is None, it returns UNKNOWN without calling AssignTier.

    Args:
        verify_result:       The return value of VerifyProvenance (S2a).
        originator_identity: Passed through to AssignTier if not None.
        sibling_registry:    Passed through to AssignTier if not None.
    Returns:
        TrustTier — always UNKNOWN when verify_result is None.
    """
    if verify_result is None:
        # INV-1: UNTRUSTED → UNKNOWN; do not call AssignTier.
        return TrustTier.UNKNOWN
    return AssignTier(
        sender_identity=verify_result,
        originator_identity=originator_identity,
        sibling_registry=sibling_registry,
    )
