from xian_linter.server import run_server

if __name__ == "__main__":
    run_server()
