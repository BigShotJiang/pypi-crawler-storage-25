# AI Agent Wrapper Design

**Date:** 2026-04-15
**Project:** net_alpha
**Status:** Approved

---

## Overview

Add an interactive AI agent to `net-alpha` that wraps the existing CLI commands with natural language understanding and proactive tax insights. The agent launches as `net-alpha agent` and runs a terminal REPL backed by Claude's tool-use API. It can answer complex multi-step questions by chaining commands, surface proactive insights at session start, and answer conceptual tax questions from baked-in domain knowledge.

Web UI is deferred to V2.

---

## Goals

- Let users ask natural language questions ("should I sell my AAPL position?") and get synthesized answers that draw on multiple CLI commands
- Surface proactive insights at session start without the user having to ask
- Answer conceptual questions about wash sale rules, tax treatment, ETF pairs, etc.
- Keep simple queries (status, help) instant with no API call
- Reuse existing API key config with an optional per-agent override

---

## Architecture

### Interaction Model

`net-alpha agent` starts an interactive terminal REPL. The session lifecycle:

1. **Session-start scan** — silently run `status` + `check --quiet`, inject results into the system prompt, print a brief summary of any urgent items (violations, stale accounts)
2. **REPL loop** — print Rich-styled prompt, read user input, route it
3. **Routing tier** — local fast-path for trivial inputs; everything else goes to the ReAct loop
4. **ReAct loop** — Claude API with tool use; Claude chains tool calls until it has enough to answer, then produces a final text response

### ReAct Loop

Each turn:
1. Build messages list: system prompt + conversation history + new user message
2. Call Claude API with tool definitions
3. If response contains `tool_use` blocks: execute tools, append results, loop back to step 2
4. If response contains `text` block: print to terminal, end turn, append to history
5. Cap at 10 tool calls per turn — if exceeded, send Claude a `max_iterations` signal message asking it to summarize what it has

### Local Fast-Path

Intercepts trivial inputs before any API call:

| Input | Handling |
|---|---|
| Empty input | Re-prompt silently |
| `exit` / `quit` / `q` | End session |
| `help` | Print static help card |
| `!<command>` | Passthrough: run raw CLI command, print output |

---

## Tools

Each tool calls the underlying Python function directly (not subprocess) using a `Console(file=StringIO())` to capture Rich output as plain text. Claude never receives ANSI escape codes.

| Tool name | Underlying function | Parameters |
|---|---|---|
| `run_check` | check command logic | `ticker` (optional), `type` (optional), `year` (optional) |
| `run_simulate_sell` | sell command logic | `ticker`, `qty`, `price` (optional) |
| `run_rebuys` | rebuys command | — |
| `run_report` | report command | `year` (optional), `csv` (bool) |
| `run_tax_position` | tax-position command | — |
| `run_status` | status command | — |

`run_import` is intentionally excluded — file imports are a deliberate user action that must not be triggered by the agent.

Tool execution errors (e.g. no trades imported, unknown ticker) are returned to Claude as an error string so Claude can produce a user-friendly explanation rather than a traceback.

---

## System Prompt

Assembled at session start from three parts:

**1. Static role + domain knowledge**

Claude is a tax-aware trading assistant for `net-alpha`. It has built-in knowledge of:
- Wash sale rules (IRS Pub 550) and the 30-day window
- Substantially-identical securities and ETF pair treatment
- Short-term vs long-term capital gains classification
- The 3-tier confidence labels (Confirmed / Probable / Unclear)
- FIFO / HIFO / LIFO lot selection and their tax implications

Behavioral constraints baked into the prompt:
- Always end responses with the standard disclaimer
- Never recommend specific tax actions — surface data and flag for CPA review
- When tool output is ambiguous, say so rather than guess

**2. Current state snapshot (injected at start)**

Output of the session-start scan formatted as a brief context block. Example:
```
Current state (as of 2026-04-15):
- 3 confirmed wash sale violations, $1,240 disallowed [2026]
- Accounts: Schwab (current), Robinhood (stale — 45 days)
```

**3. Conversation history**

Full turn history (user + assistant messages) appended as the session progresses, enabling follow-up questions with context.

---

## API Key Config

Resolution order:
1. `agent_api_key` in `~/.net_alpha/config.toml` (new optional field)
2. `anthropic_api_key` in `~/.net_alpha/config.toml` (existing field)
3. `ANTHROPIC_API_KEY` environment variable

If none is set: print a clear error with setup instructions and exit. No wizard prompt.

Model: `claude-3-5-haiku-latest` (matches existing LLM usage in the project for cost efficiency). Can be overridden via `agent_model` in config.

---

## Module Structure

### New files

- `src/net_alpha/cli/agent.py` — REPL loop, routing tier, session-start scan, Rich UI, `agent_command` entry point
- `src/net_alpha/agent/tools.py` — tool JSON schema definitions and tool executor functions (each wraps an existing CLI function, captures output as string)
- `src/net_alpha/agent/react.py` — ReAct loop: message construction, Claude API call, tool dispatch, iteration cap, error handling
- `src/net_alpha/agent/prompt.py` — system prompt assembly: static role text + current state snapshot + history management

### Modified files

- `src/net_alpha/cli/app.py` — add `app.command(name="agent")(agent_command)`
- `src/net_alpha/config.py` — add optional `agent_api_key: str | None` and `agent_model: str` fields to `Settings`

---

## Error Handling

| Scenario | Handling |
|---|---|
| Tool raises exception | Caught, returned to Claude as error string; Claude explains to user |
| Claude API rate limit / network error | Printed directly with retry suggestion; turn aborted cleanly |
| Max tool iterations exceeded | Claude sent `max_iterations` signal, asked to summarize what it has |
| API key missing | Clear error message with setup instructions, exit before REPL starts |

---

## Testing

- **`react.py`** — pure logic, Claude client mocked. Covers: single tool call, multi-tool chain, max iterations cap, tool error passthrough, text-only response (no tools called).
- **`tools.py`** — each tool executor tested independently with a real in-memory DB (same pattern as existing CLI tests).
- **`agent.py` REPL** — not unit tested (I/O loop); covered by one integration smoke test with a fake Claude client verifying a full session turn end-to-end.

---

## Out of Scope (V2)

- Web UI / browser-based chat interface
- Persistent agent memory across sessions
- Streaming responses
- Multi-agent orchestration

---

## Disclaimer

Every agent response ends with:

> ⚠ This is informational only. Consult a tax professional before filing.
