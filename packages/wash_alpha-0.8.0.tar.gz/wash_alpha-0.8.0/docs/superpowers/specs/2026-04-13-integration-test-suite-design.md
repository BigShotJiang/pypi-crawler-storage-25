# Integration Test Suite Design

**Date:** 2026-04-13
**Status:** Approved

## Context

`net_alpha` has strong unit test coverage across individual components (matcher, detector, schema detection, option parser, dedup, repositories, domain models). What's missing is end-to-end integration coverage — tests that wire the full pipeline (CSV import → SQLite → wash sale detection → CLI output) through a real temp database.

The goal is a two-tier integration suite that catches regressions in the critical user flows (import, check, simulate sell, rebuys, report) and in the wash sale engine's edge cases (cross-year windows, multi-account matching, partial FIFO allocation, ETF substantially-identical logic).

---

## Structure

```
tests/
  integration/
    conftest.py                      # shared fixtures (temp_db, seeded_session, mock_llm, etf_pairs)
    cli/
      conftest.py                    # CliRunner, app, cli_env (temp data dir, ANTHROPIC_API_KEY)
      test_import.py
      test_check.py
      test_simulate.py
      test_rebuys.py
      test_report.py
    engine/
      test_import_pipeline.py        # CSV → Trade → DB, dedup, schema cache
      test_wash_sale_engine.py       # engine edge cases with real DB
```

Mirror of `src/net_alpha/` layout: `cli/` tier for full-stack user-facing tests, `engine/` tier for logic edge cases without parsing Rich output.

---

## Shared Fixtures (`tests/integration/conftest.py`)

| Fixture | Signature | What it provides |
|---|---|---|
| `temp_db` | `(tmp_path)` | Fresh SQLite engine + session in temp dir; `init_db()` + `run_migrations()` called; yields `(engine, session, db_path)` |
| `seeded_session` | `(temp_db, trades: list[Trade])` | Extends `temp_db`; saves trades via `TradeRepository`; returns session |
| `mock_llm` | `(monkeypatch)` | Patches `anthropic.Anthropic` with `MagicMock`; `.messages.create()` returns pre-baked `SchemaMapping` JSON for both Schwab and Robinhood formats |
| `schwab_csv` | — | `Path` to `tests/fixtures/schwab_sample.csv` |
| `robinhood_csv` | — | `Path` to `tests/fixtures/robinhood_sample.csv` |
| `etf_pairs` | — | Bundled `etf_pairs.yaml` loaded as `dict[str, list[str]]` |

**CLI fixtures** (`tests/integration/cli/conftest.py`):

| Fixture | What it provides |
|---|---|
| `runner` | `typer.testing.CliRunner(mix_stderr=False)` |
| `app` | Typer app from `src/net_alpha/cli/app.py` |
| `cli_env` | Dict of env vars: `NET_ALPHA_DATA_DIR=<tmp_path>`, `ANTHROPIC_API_KEY=test-key`; `_bootstrap()` patched to use temp DB |

---

## CLI Tests (`tests/integration/cli/`)

Invoke commands via `CliRunner.invoke(app, [...args], env=cli_env)`. Assert `result.exit_code == 0` and key strings in `result.output`. Every test asserts the disclaimer is present.

**Interactive prompt handling:** The `import` command uses `questionary` to ask the user to confirm the detected schema. In CLI tests, pass `input="y\n"` to `CliRunner.invoke()` to simulate confirmation. For cache-hit tests (no confirmation prompt), pass no input.

### `test_import.py`

| Test | Scenario | Key assertions |
|---|---|---|
| `test_schwab_import_llm_path` | Fresh DB, no schema cache → LLM called, user confirms | "4 trades imported"; `mock_llm` called once; trades in DB |
| `test_schwab_import_cache_hit` | Pre-seeded schema cache → LLM skipped | "4 trades imported"; `mock_llm` never called |
| `test_robinhood_import_llm_path` | Robinhood CSV, LLM path | "4 trades imported" |
| `test_duplicate_import_skips` | Import same CSV twice | Second run: "0 new, 4 skipped" |
| `test_cross_account_same_ticker` | Schwab CSV then Robinhood CSV (both have TSLA) | Both exit 0; DB has 8 trades across 2 accounts |

### `test_check.py`

| Test | Scenario | Key assertions |
|---|---|---|
| `test_check_with_violations` | DB seeded with confirmed equity wash sale | "Confirmed" in output; disclaimer present |
| `test_check_ticker_filter` | TSLA + AAPL violations; `--ticker TSLA` | Only TSLA rows in output |
| `test_check_year_filter` | 2024 + 2025 violations; `--year 2024` | Only 2024 loss sales shown |
| `test_check_no_data` | Empty DB | Graceful "no trades" message; exit 0 |
| `test_check_staleness_warning` | Trades exist but check never run (no lots/violations rows) | Staleness warning in output |

### `test_simulate.py`

| Test | Scenario | Key assertions |
|---|---|---|
| `test_simulate_safe` | No TSLA buys in last 30 days | "Safe to sell" in output |
| `test_simulate_risky_no_price` | TSLA buy 5 days ago | Safe rebuy date shown; risk level in output |
| `test_simulate_risky_with_price` | TSLA buy 5 days ago + `--price 250` | Estimated disallowed loss dollar amount shown |
| `test_simulate_etf_risky` | VOO buy 10 days ago, simulating SPY sell | "Unclear" risk; ETF pair referenced |

### `test_rebuys.py`

| Test | Scenario | Key assertions |
|---|---|---|
| `test_rebuys_open_window` | Loss sale 10 days ago, no replacement buy | Ticker shown; days remaining shown |
| `test_rebuys_cleared_window` | Loss sale 35 days ago | Not in output (window closed) |
| `test_rebuys_partial_match` | Loss of 10 shares, 4 matched → 6 open | "6/10" open qty shown |
| `test_rebuys_empty` | No loss sales | Graceful "no open windows" message |

### `test_report.py`

| Test | Scenario | Key assertions |
|---|---|---|
| `test_report_summary` | 2 confirmed + 1 probable violation in 2024 | Counts correct; total disallowed loss correct |
| `test_report_year_filter` | 2023 + 2024 violations; `--year 2024` | Only 2024 violations |
| `test_report_csv_export` | `--csv` flag | CSV file created; headers present; row count matches |
| `test_report_empty` | No violations | "No wash sales detected" |

---

## Engine Integration Tests (`tests/integration/engine/`)

Call functions directly with real temp SQLite DB. Assert on domain objects and DB state. No Rich output parsing.

### `test_import_pipeline.py`

| Test | Scenario | Key assertions |
|---|---|---|
| `test_schwab_full_pipeline` | `run_import()` with mock LLM, Schwab CSV | 4 `Trade` objects in DB; option trade fields correct (strike, expiry, call_put) |
| `test_robinhood_full_pipeline` | Same for Robinhood CSV | 4 trades; option_format "robinhood_human" cached |
| `test_schema_cache_written` | First import → schema_cache row created | `SchemaCacheRepository.find_by_broker_and_hash()` returns row |
| `test_schema_cache_hit_skips_llm` | Second import same broker → LLM not called | `mock_llm.messages.create` call count == 1 total |
| `test_dedup_hash_match` | Import same CSV twice | Second import: 0 new trades, 4 skipped |
| `test_dedup_semantic_match` | Row hash differs (column reorder) but same trade semantics | Still deduplicated via semantic key |
| `test_cross_account_no_dedup` | Same ticker+date in Schwab and Robinhood | Both stored (different accounts = distinct trades) |

### `test_wash_sale_engine.py`

| Test | Scenario | Key assertions |
|---|---|---|
| `test_equity_confirmed` | TSLA sell loss Jan 10, TSLA buy Jan 15 (same account) | 1 violation; confidence="Confirmed"; disallowed_loss == loss_amount |
| `test_equity_confirmed_cross_account` | TSLA sell Schwab, TSLA buy Robinhood, 5 days apart | 1 violation; confidence="Confirmed" |
| `test_equity_to_call_probable` | TSLA equity sell loss, TSLA call buy 10 days later | confidence="Probable" |
| `test_sold_put_unclear` | TSLA equity sell loss, TSLA put sell 5 days later | confidence="Unclear" |
| `test_etf_substantially_identical` | SPY sell loss, VOO buy 7 days later | confidence="Unclear"; both in sp500 group |
| `test_cross_year_window` | Sell Dec 15 2024 at loss, buy Jan 5 2025 (21 days later) | Violation detected across year boundary |
| `test_day_30_boundary_inclusive` | Sell Jan 1, buy Jan 31 (30 days) | Violation detected (day 30 inclusive) |
| `test_day_31_boundary_exclusive` | Sell Jan 1, buy Feb 1 (31 days) | No violation |
| `test_partial_fifo_allocation` | Loss 10 shares; lot A=4 shares, lot B=10 shares | 2 violations; lot A fully consumed (4 shares), lot B partial (6 shares); adjusted_basis updated on both |
| `test_no_violation_profit_sale` | TSLA sell at profit, TSLA buy same week | No violations |
| `test_basis_unknown_not_matched` | Sell with `basis_unknown=True`, buy same week | No violation |
| `test_multiple_loss_sales_fifo` | Two loss sales, shared buy lot pool | FIFO order respected; no double-allocation |
| `test_lot_adjusted_basis_updated` | Confirmed wash sale, $500 disallowed loss | `lot.adjusted_basis == original_cost_basis + 500` |

---

## Key Files to Create / Modify

| Action | File |
|---|---|
| Create | `tests/integration/__init__.py` |
| Create | `tests/integration/conftest.py` |
| Create | `tests/integration/cli/__init__.py` |
| Create | `tests/integration/cli/conftest.py` |
| Create | `tests/integration/cli/test_import.py` |
| Create | `tests/integration/cli/test_check.py` |
| Create | `tests/integration/cli/test_simulate.py` |
| Create | `tests/integration/cli/test_rebuys.py` |
| Create | `tests/integration/cli/test_report.py` |
| Create | `tests/integration/engine/__init__.py` |
| Create | `tests/integration/engine/test_import_pipeline.py` |
| Create | `tests/integration/engine/test_wash_sale_engine.py` |
| Reuse | `tests/fixtures/schwab_sample.csv` |
| Reuse | `tests/fixtures/robinhood_sample.csv` |
| Reuse | `tests/conftest.py` factories (`TradeFactory`, `LossSaleFactory`, etc.) |

---

## Existing Code to Reuse

| Symbol | Location |
|---|---|
| `run_import()` | `src/net_alpha/import_/importer.py` |
| `detect_wash_sales()` | `src/net_alpha/engine/detector.py` |
| `get_engine()`, `init_db()`, `run_migrations()` | `src/net_alpha/db/connection.py` |
| `TradeRepository`, `SchemaCacheRepository`, `LotRepository`, `ViolationRepository` | `src/net_alpha/db/repository.py` |
| `TradeFactory`, `LossSaleFactory`, `OptionTradeFactory`, `LotFactory` | `tests/conftest.py` |
| `SchemaMapping` | `src/net_alpha/import_/schema_detection.py` |
| `_bootstrap()` (to patch in CLI tests) | `src/net_alpha/cli/app.py` |

---

## Verification

```bash
# Run full integration suite
uv run pytest tests/integration/ -v

# Run CLI tier only
uv run pytest tests/integration/cli/ -v

# Run engine tier only
uv run pytest tests/integration/engine/ -v

# Run with coverage
uv run pytest tests/integration/ --cov=src/net_alpha --cov-report=term-missing

# Run a specific scenario
uv run pytest tests/integration/engine/test_wash_sale_engine.py::test_cross_year_window -v
```

All tests must pass with no `ANTHROPIC_API_KEY` set in the environment (LLM is always mocked).
