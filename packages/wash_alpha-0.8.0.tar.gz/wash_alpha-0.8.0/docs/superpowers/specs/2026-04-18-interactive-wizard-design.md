# net-alpha — Interactive CLI Wizard Design

**Date:** 2026-04-18
**Topic:** CLI UX Improvements for Non-Technical Users (Hybrid Guided TUI)

## 1. Goal
Broaden the adoption of `net-alpha` (targeting higher GitHub stars and non-technical user onboarding) by introducing a frictionless, interactive, menu-driven terminal interface. This will bridge the gap between a raw command-line tool and a full graphical application, allowing users to navigate complex tax logic without memorizing CLI arguments.

## 2. Approach: The Hybrid "Guided" CLI
We will retain the existing Typer-based CLI for power users and CI/CD pipelines, but introduce an interactive wizard mode powered by `questionary` (or Typer's built-in prompt tools) and `Rich`. 

If a user runs the base command `net-alpha` (or `net-alpha wizard`) without arguments, they will be dropped into the interactive loop.

## 3. Core Components

### 3.1. Main Entry Menu
A clear, arrow-key navigable menu presented on startup:
*   Import new trade data (CSV)
*   Check for wash sales
*   Simulate a trade
*   Generate tax report
*   Ask the AI Assistant
*   Exit

**Educational Feature ("Teaching"):** After any wizard flow completes, the application will print the equivalent CLI command (e.g., `Tip: Next time, run: net-alpha simulate sell TSLA 10 --price 185.50`) to help users transition to power users over time.

### 3.2. Guided Import Flow
Resolves the "blank canvas" and file-path friction points:
1.  **Broker Selection:** Interactive list of supported brokers (Schwab, Robinhood, Other/Auto-detect).
2.  **File Pathing:** Prompts for the file path, potentially utilizing terminal auto-completion or simple drag-and-drop terminal instructions.
3.  **AI Schema Confirmation:** Formats the Claude schema detection output into a beautiful `Rich` table, clearly explaining *why* the AI is doing this (privacy/accuracy), and requests a simple `[Y/n]` confirmation.
4.  **Next Steps:** Upon successful import, immediately prompts the user with logical next actions (e.g., "Check portfolio for wash sales") instead of dropping them back to an empty shell.

### 3.3. Check & Report Workflows
Rather than dumping massive data tables immediately, the wizard scopes the data:
1.  **Executive Summary:** A color-coded `Rich` dashboard card showing total wash sales (Confirmed/Probable/Clear) and total disallowed losses.
2.  **Drill-down:** Asks the user if they want to view the detailed list, filter by ticker, or filter by account.

### 3.4. Trade Simulation Flow
Walks the user through a planned trade sequentially:
*   Action (Buy/Sell)
*   Ticker symbol
*   Quantity
*   Estimated Price
*   **Output:** Actionable, human-readable advice. E.g., "⚠️ WARNING: Selling 10 TSLA today will trigger a wash sale against your Robinhood account. Recommendation: Wait 19 more days (until Nov 14)."

## 4. Technical Implementation Notes
*   **Dependencies:** Introduce `questionary` (or use existing `rich.prompt`) for interactive menus.
*   **Architecture:** The interactive wizard functions will wrap existing core engine functions and Typer commands, ensuring no duplication of business logic.
*   **Testing:** Wizard flows must be modular enough to be tested independently of standard input.

## 5. Scope & Phasing
This design represents a single cohesive implementation phase. It does not include building a local web dashboard (`net-alpha serve`) or a graphical desktop application, staying strictly within the terminal environment.
