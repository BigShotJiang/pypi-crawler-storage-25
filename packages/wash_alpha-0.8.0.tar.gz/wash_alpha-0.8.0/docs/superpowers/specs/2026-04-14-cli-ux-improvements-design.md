# CLI UX Improvements — Design Spec

**Date:** 2026-04-14
**Status:** Approved
**Scope:** Option B — Full UX pass (no structural CLI changes, no TUI, disclaimer mandatory)

---

## 1. Goals

Polish the full CLI for two user types simultaneously:

- **User A (accidental victim):** Needs guidance, discoverability, and "what to do next" orientation.
- **User B (active harvester):** Needs efficiency, faster orientation, and a way to quiet verbose output.

All existing command names and flags are preserved. The disclaimer (`⚠ This is informational only. Consult a tax professional before filing.`) remains mandatory on every command output.

---

## 2. Section 1 — Progress Indicators & Visual Polish

### 2.1 Spinners

Add `rich.console.Console` spinners (via `console.status(...)`) to all commands that do slow work silently:

| Command | Spinner text |
|---------|--------------|
| `import` | "Detecting schema…" (wraps LLM call), then "Importing trades…" (wraps DB write) |
| `check` | "Scanning for wash sales…" (wraps `detect_wash_sales()`) |
| `report` | "Scanning for wash sales…" (wraps `detect_wash_sales()`) |

Spinners use `rich`'s default spinner style. No new dependencies required.

### 2.2 Color-coded monetary values in `tax-position`

All monetary lines in `_render_tax_position` get contextual color:
- Positive gains: `green`
- Losses / negative values: `red`
- Net lines: green if > 0, red if < 0, default if 0

Currently all lines render in default white.

### 2.3 Urgency coloring in `rebuys`

The "Days Remaining" column in the rebuys table gets color based on urgency:
- ≤ 7 days: `bold red`
- ≤ 14 days: `yellow`
- > 14 days: default

---

## 3. Section 2 — `net-alpha status` Dashboard Command

### 3.1 New command

`net-alpha status` — a single-screen overview. Registered in `app.py` alongside existing commands.

### 3.2 Output layout

```
  DATA FRESHNESS
  ──────────────────────────────────────────────────
  schwab          847 trades    last import: 2026-04-10  (4 days ago)
  robinhood       312 trades    last import: 2026-03-15  ⚠ 30 days ago

  WASH SALE SUMMARY — 2026 (last check: 2026-04-12)
  ──────────────────────────────────────────────────
  Confirmed         4 violations    $(2,340.00) disallowed
  Probable          2 violations      $(890.00) disallowed
  Total disallowed loss:            $(3,230.00)

  OPEN REBUY WINDOWS
  ──────────────────────────────────────────────────
  3 positions still in 30-day window — run net-alpha rebuys

  ──────────────────────────────────────────────────
  Run net-alpha check to re-scan with latest data.

  ⚠ This is informational only. Consult a tax professional before filing.
```

### 3.3 Edge cases

| State | Behavior |
|-------|----------|
| No trades imported | Print "No trades imported. Run `net-alpha import` to get started." then exit |
| Trades exist but `check` never run | Show data freshness section, then "No scan results yet. Run `net-alpha check`." |
| No rebuy windows open | Omit the rebuy section entirely |

### 3.4 Replaces current no-args fallback

Currently `net-alpha` (no args, trades exist) falls through to printing `--help`. Replace this with `status` output instead.

### 3.5 Data sourcing

- Account trade counts and last import dates: `TradeRepository` (already has `list_accounts()` and `latest_trade_date_by_account()`)
- Violation summary: `ViolationRepository.list_all()` (reads last persisted check results — does not re-run detection)
- Last check date: derived from the most recent `WashSaleViolation` record's created/updated timestamp, or from a new `meta` table entry `last_check_at` (preferred — add one row to `meta` table when `check` runs)
- Open rebuy windows: same logic as `rebuys_command`, just count not detail

---

## 4. Section 3 — Wizard Improvements

### 4.1 Broker autocomplete

Replace the free-text `questionary.text` broker prompt with `questionary.autocomplete`. Built-in suggestion list:

```python
KNOWN_BROKERS = [
    "schwab", "robinhood", "fidelity", "etrade",
    "td_ameritrade", "interactive_brokers", "webull", "tastytrade",
]
```

Unknown names are still accepted — autocomplete is advisory. The list lives as a module-level constant in `wizard.py`.

### 4.2 Schema confirmation shows example values

Extend `_confirm_schema` in `import_cmd.py` to pass a `examples: dict[str, str]` argument alongside `SchemaMapping`. The importer extracts the first non-empty cell value for each mapped column from the CSV sample rows (already read during schema detection). The confirmation table gains a third column:

```
date       "Date"          2026-01-15
ticker     "Symbol"        AAPL
action     "Action"        Buy to Open
quantity   "Quantity"      10
```

No LLM change required — example values come from the already-loaded sample rows.

### 4.3 "What to do next" panel at wizard end

After the first `check` runs inside the wizard, print:

```
  ✓ You're set up. Here's what to run next:

    net-alpha check              Re-scan for wash sales anytime
    net-alpha simulate sell      Check a trade before you make it
    net-alpha status             See your full picture at a glance
    net-alpha report --csv       Export for your tax preparer
```

This replaces the current bare `Run net-alpha check anytime to re-scan.` line.

### 4.4 Post-import nudge (standalone import)

After a successful `net-alpha import` (outside the wizard), append before the disclaimer:

```
  → Run net-alpha check to scan for wash sales with your latest data.
```

---

## 5. Section 4 — Validation & Error Handling

### 5.1 `check --type` validation

Validate the `type` option against `["equities", "options"]` before running detection. On invalid input:

```
Error: --type must be 'equities' or 'options'. Got: 'option'
```

Exit with code 1. No detection run.

### 5.2 `simulate sell` ticker validation

If no open lots exist for the given ticker:
1. Compute edit distance (one substitution/insertion/deletion) against all DB-known tickers.
2. If a close match exists, print:
   ```
   No open lots for 'APPL'. Did you mean: AAPL?
   Run net-alpha tax-position to see all open positions.
   ```
3. If no close match, print:
   ```
   No open lots for 'XYZ'.
   Run net-alpha tax-position to see all open positions.
   ```

Edit distance implementation: stdlib `difflib.get_close_matches` (no new dependency).

### 5.3 Consistent error style

Standardize all user-facing errors to:

```
[red]Error:[/red] <message>
→ <actionable suggestion>   (optional, when helpful)
```

Audit all CLI commands for bare `console.print(f"[red]...")` or raw exception messages and normalize. No behavioral changes — formatting only.

---

## 6. Section 5 — Power-User Flags & Cross-Command Hints

### 6.1 `--quiet` flag

Add `quiet: bool = typer.Option(False, "--quiet", help="Print summary line only")` to `check` and `report`. Both follow the same pattern: suppress all tables/panels, print one summary line, disclaimer still prints.

When `--quiet`:
- Suppress all table/panel output
- Print one summary line:
  ```
  3 violations  $(2,340.00) disallowed  [2026]
  ```
  Or if no violations:
  ```
  0 violations  [2026]
  ```
- Disclaimer still prints (mandatory)
- Exit code: 0 always (violations are informational, not errors)

### 6.2 Cross-command hints

One contextual nudge line printed before the disclaimer, only when the condition is met:

| Command | Condition | Hint |
|---------|-----------|------|
| `check` | violations found | `→ Run net-alpha report --csv to export for your tax preparer` |
| `check` | any violations | `→ Run net-alpha tax-position to see your YTD gain/loss picture` |
| `check` | rebuy windows open | `→ {n} positions safe to rebuy — run net-alpha rebuys` (already exists — keep, don't duplicate) |
| `import` | always | `→ Run net-alpha check to scan with latest data` |
| `rebuys` | entries shown | `→ Run net-alpha simulate sell <ticker> before you trade` |
| `tax-position` | ST gains > 0 | `→ Run net-alpha simulate sell to check loss harvesting options` |

When multiple hints would fire for `check`, print both (violations hint first, then tax-position hint).

---

## 7. Files Changed

| File | Change |
|------|--------|
| `cli/app.py` | Register `status` command; replace no-args fallback with `status` |
| `cli/status.py` | New file — `status_command` |
| `cli/check.py` | Add spinner, `--quiet` flag, cross-command hints, `--type` validation |
| `cli/report.py` | Add spinner, `--quiet` flag |
| `cli/import_cmd.py` | Add spinners, post-import nudge, example values in schema confirmation |
| `cli/simulate.py` | Ticker validation with `difflib` suggestion |
| `cli/rebuys.py` | Urgency coloring on days remaining, cross-command hint |
| `cli/tax_position.py` | Color-coded monetary values, cross-command hint |
| `cli/wizard.py` | Broker autocomplete, example values passthrough, "what to do next" panel |
| `cli/output.py` | Shared `hint()` helper for consistent hint line formatting |
| `db/migrations.py` | Add `last_check_at` entry to `meta` table |
| `db/repository.py` | Method to read/write `last_check_at` |

---

## 8. Out of Scope

- TUI (Textual) — deferred to v2
- Merging `check` and `report` — deferred (breaking change)
- Result caching / skipping re-detection — deferred (engine concern)
- `--ticker` autocomplete from DB — deferred
- `--year` on additional commands — deferred
- Any changes to disclaimer text or placement logic
