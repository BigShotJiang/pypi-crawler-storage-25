# Tax Optimization Suite Design

**Date:** 2026-04-14
**Project:** net_alpha
**Status:** Approved

---

## Overview

Add two tax optimization features to the net_alpha CLI, both working entirely from local trade history:

1. **`net-alpha tax-position`** — a new command giving a YTD snapshot of realized short/long-term gains and losses, net capital position, how much loss still needs to be harvested, and an open-lots holding period tracker (which positions are approaching the 1-year long-term threshold).

2. **Enhanced `net-alpha simulate sell`** — extends the existing command (currently only checks wash sale risk) to show a lot selection comparison table (FIFO vs HIFO vs LIFO), with a recommendation based on the user's current YTD tax position.

---

## Goals

- Help traders understand their YTD realized tax position at any point in the year
- Surface open lots approaching the 1-year long-term capital gains threshold
- At the point of selling, show which lot selection method minimizes tax impact given current YTD position
- Work entirely from imported trade history — no live prices, no broker API

---

## Architecture

### New Module: `src/net_alpha/engine/tax_position.py`

Pure functions, no DB access. Takes a list of `Trade` objects and returns structured data consumed by both new/enhanced commands. No changes to existing domain models or DB schema.

**Key functions:**

- `_allocate_lots(trades, as_of) -> AllocationResult` — shared core that replays per-(account, ticker) FIFO allocation. Returns both realized pairs (sell + matched buy lot + quantity consumed) and remaining open lots. Tracks `remaining_qty` and `remaining_basis` per lot to handle partial consumption and wash-sale-adjusted basis correctly. This is the most complex function in the module.
- `compute_tax_position(trades, year) -> TaxPosition` — calls `_allocate_lots`, aggregates YTD realized gains/losses with ST/LT classification. Option trades are included in the tax position. Realized pairs where the buy lot is `basis_unknown` are excluded from ST/LT totals and counted separately for a warning.
- `identify_open_lots(trades, as_of) -> list[OpenLot]` — calls `_allocate_lots`, returns remaining open lots. Options and `basis_unknown` lots are included but marked accordingly. `as_of` parameter enables testability (CLI passes `date.today()`).
- `select_lots(open_lots, ticker, qty, method) -> LotSelection` — applies FIFO/HIFO/LIFO to choose which lots cover a sell quantity. Pools across accounts (advisory view). Returns `wash_sale_risk=False` by default — risk assessment is composed by the caller. Does not take trade list or ETF pairs as input.
- `recommend_lot_method(lot_selections, tax_position) -> LotRecommendation` — rule-based decision tree. Returns structured `LotRecommendation` with reason codes; CLI layer formats prose.

#### Allocation Details

- **Scope:** Per `(account, ticker)` FIFO — matches how brokers report cost basis.
- **Lot selection (simulate sell)** pools open lots across all accounts after allocation — this is advisory, not an execution instruction.
- **Same-date ordering:** Trades on the same date are sorted by `(date, id)` for determinism. Intraday ordering is not preserved (known limitation — `Trade` has no time-of-day field).
- **Partial consumption:** When a sell partially consumes a lot, both `remaining_qty` and `remaining_basis` are updated. `remaining_basis` is decremented by `N * (remaining_basis / remaining_qty)` before quantity is decremented. This ensures `adjusted_basis_per_share = remaining_basis / remaining_qty` is always correct, even with wash sale adjustments.

#### Recommendation Decision Tree

Ranked preference order:
1. If any method produces a ST loss and user has net ST gains → prefer that method (offset high-tax gains)
2. If preferred method has wash sale risk → flag it, suggest wait date, fall through to fallback
3. Prefer LT gain over ST gain (lower tax rate)
4. Prefer smaller gain over larger gain (less tax)
5. Tie-break: FIFO (matches broker default)

Each branch produces a structured `LotRecommendation` with reason codes — the CLI layer maps these to human-readable sentences.

### New Domain Types (in `models/domain.py`)

All new types are Pydantic `BaseModel`, consistent with the existing `Trade`, `Lot`, etc.

```python
class TaxPosition(BaseModel):
    st_gains: float
    st_losses: float
    lt_gains: float
    lt_losses: float
    year: int
    basis_unknown_count: int  # sells excluded due to unknown cost basis

    @property
    def net_st(self) -> float: ...
    @property
    def net_lt(self) -> float: ...
    @property
    def net_capital_gain(self) -> float: ...
    @property
    def loss_needed_to_zero_st(self) -> float: ...
    @property
    def carryforward(self) -> float: ...  # max(0, -net_capital_gain - 3000)
    # $3,000 cap is hardcoded (covers single / married filing jointly)


class OpenLot(BaseModel):
    ticker: str
    account: str
    quantity: float
    adjusted_basis_per_share: float  # remaining_basis / remaining_qty
    purchase_date: date
    days_held: int          # relative to as_of parameter
    days_to_long_term: int  # 0 if already long-term
    basis_unknown: bool     # True if original lot had unknown cost basis
    is_option: bool         # True if lot has option_details


class LotSelection(BaseModel):
    method: str                # "FIFO", "HIFO", "LIFO"
    lots_used: list[OpenLot]
    st_gain_loss: float        # short-term component
    lt_gain_loss: float        # long-term component
    total_gain_loss: float
    wash_sale_risk: bool       # set by caller, not by select_lots


class LotRecommendation(BaseModel):
    preferred_method: str           # "LIFO", "FIFO", "HIFO"
    reason: str                     # "st_loss_offset", "lt_lower_rate", "least_gain"
    has_wash_risk: bool
    safe_sell_date: date | None     # if wash risk, when it clears
    fallback_method: str | None     # best clean option if preferred has wash risk
    fallback_reason: str | None


class AllocationResult(BaseModel):
    """Output of _allocate_lots — shared by tax position and open lots."""
    realized_pairs: list[RealizedPair]
    open_lots: list[OpenLot]


class RealizedPair(BaseModel):
    """A sell matched to a specific buy lot with quantity consumed."""
    sell_trade: Trade
    buy_lot_date: date
    buy_lot_account: str
    quantity: float
    proceeds: float
    basis: float
    basis_unknown: bool
    is_long_term: bool   # holding period > 365 days
```

### Holding Period Classification

- Short-term: held <= 365 calendar days
- Long-term: held > 365 calendar days
- Holding period uses per-account FIFO (consistent with broker cost basis reporting)
- Open lot basis uses `adjusted_basis` (wash-sale-adjusted, not original cost basis)
- `days_held` and `days_to_long_term` are computed relative to caller-supplied `as_of` date (CLI passes `date.today()`)

### Options Handling

- **Included in `compute_tax_position`:** option gains/losses are real realized taxable events and count toward YTD ST/LT totals.
- **Excluded from `identify_open_lots`:** options are not shown in the holding period tracker.
- **Excluded from `select_lots`:** options are not eligible for lot selection.
- If a ticker has option trades, a note is shown: "Note: {TICKER} has option trades not shown in lot selection."

### `basis_unknown` Handling

- **`compute_tax_position`:** realized pairs with unknown basis are excluded from ST/LT totals. A warning is shown: "X sells excluded due to unknown cost basis."
- **`identify_open_lots`:** `basis_unknown` lots appear in the holding period tracker with basis shown as "Unknown."
- **`select_lots`:** lots with unknown basis show "N/A" for gain/loss in the selection table.

---

## Commands

### `net-alpha tax-position [--year YYYY]`

Defaults to current year. Loads all trades, computes `TaxPosition` and open lots, renders output. Registered as a simple command via `app.command(name="tax-position")` — same pattern as `check`, `report`, `rebuys`.

No `--account` flag. The all-accounts view is the correct tax view; open lots table shows account column for per-position visibility.

**Output:**

```
  TAX POSITION — 2026 (all accounts)
  ──────────────────────────────────────────────────────
  Short-term gains:          $12,400.00
  Short-term losses:         ($3,200.00)
  Net short-term:             $9,200.00   (taxed at ordinary income rates)

  Long-term gains:            $8,100.00
  Long-term losses:            ($500.00)
  Net long-term:              $7,600.00   (taxed at preferential rates)

  ──────────────────────────────────────────────────────
  Net capital gain:          $16,800.00
  Loss still needed to zero short-term:  $9,200.00

  OPEN LOTS — Holding Period Tracker
  ──────────────────────────────────────────────────────
  Ticker  Account    Qty   Adj.Basis/sh  Held   Days to Long-Term
  AAPL    Schwab      50      $145.00    315d   50 days
  TSLA    Robinhood   20      $210.00    390d   Long-term ✓
  MSFT    Schwab      15      $290.00     45d   320 days

  ⚠ This is informational only. Consult a tax professional before filing.
```

Open lots sorted by: `days_to_long_term` ascending (lots closest to 1-year threshold first), then ticker alphabetically. Already-long-term lots appear last.

Loss carryforward line is shown only when net capital loss exceeds $3,000:

```
  Loss carryforward (above $3,000 cap):  $1,800.00
```

### Enhanced `net-alpha simulate sell TICKER QTY --price P`

Existing wash sale check is preserved unchanged. When `--price` is provided, a lot selection table is appended after the wash sale block. Lot selection logic is encapsulated in a private helper function within `simulate.py` (called when `price is not None`).

The helper:
1. Calls `identify_open_lots` to get open lots for the ticker
2. Runs `select_lots` for each method (FIFO, HIFO, LIFO)
3. Checks wash sale risk: if a method produces a loss AND look-back triggers exist (reusing `_find_lookback_triggers`), sets `wash_sale_risk=True`
4. Calls `recommend_lot_method` with selections and YTD tax position
5. Renders table and recommendation via Rich

**Additional output (price provided):**

```
  LOT SELECTION — AAPL 50 shares @ $180.00
  ──────────────────────────────────────────────────────
  Method  Lot Date    Qty  Basis/sh  Gain/Loss   Treatment   Wash Sale
  FIFO    2025-08-15   50   $145.00   +$1,750     Short-term  None
  HIFO    2025-01-10   50   $112.00   +$3,400     Long-term   None
  LIFO    2025-11-20   50   $195.00   ($750)      Short-term  ⚠ Risk

  Recommendation (given your 2026 YTD position):
    You have $9,200 net short-term gains to offset.
    → LIFO produces a $750 short-term loss — but wash sale risk detected.
      Wait until 2026-01-15 to sell cleanly using LIFO.
    → Best clean option: FIFO — adds $1,750 short-term gain (least harm).
    → HIFO adds $3,400 but as long-term gain (lower rate).

  ⚠ This is informational only. Consult a tax professional before filing.
```

If `--price` is absent, lot selection table is skipped — no change to current behavior.

---

## Edge Cases

| Case | Behavior |
|------|----------|
| `basis_unknown=True` lots | Included in open lots (basis shown as "Unknown"), excluded from gain/loss totals, count shown as warning |
| Partial lot consumption | Open lot shows remaining unconsumed quantity and correctly prorated remaining basis |
| Wash-sale-adjusted basis | Open lots use `adjusted_basis`, not original cost basis. `remaining_basis` tracks adjustments through partial consumption |
| Cross-account FIFO | Allocation is per-(account, ticker). Lot selection pools across accounts (advisory) |
| `simulate sell` with no price | Lot selection table skipped; existing wash sale check only |
| `simulate sell` before `check` | Works directly from trade history — `net-alpha check` is not required for lot selection |
| Options | Included in YTD tax position. Excluded from holding period tracker and lot selection; note shown if ticker has option trades |
| Quantity exceeds available open lots | Graceful message: "Only X shares available across open lots" |
| Zero open lots for ticker | Short-circuit: "No open lots for {TICKER}. Nothing to select." Lot selection table and recommendation skipped. Wash sale check still runs above |
| No trades imported | "No trades imported yet. Run net-alpha import first." |
| Net capital loss <= $3,000 | No carryforward line shown |
| Same-date trades | Ordered by `(date, id)` for determinism. Intraday ordering not preserved (known limitation) |
| Multiple buys partially consumed by a single sell | Each buy lot tracks `remaining_qty` and `remaining_basis` independently |
| Sell produces both ST and LT components | `LotSelection` reports `st_gain_loss` and `lt_gain_loss` separately |
| All lot methods have wash sale risk | Recommendation reports this; no clean option available |

---

## Testing Strategy

All tests use `factory_boy` fixtures, pure functions, no mocks. All engine functions accept `as_of: date` parameter — tests pass fixed dates, no date mocking needed.

### `_allocate_lots` core (100% unit coverage)

- Per-(account, ticker) FIFO: sells consume lots from correct account only
- Partial lot consumption: `remaining_qty` and `remaining_basis` track correctly
- Wash-sale-adjusted basis flows through to remaining basis after partial consumption
- Same-date trades: deterministic ordering by `(date, id)`
- Cross-account: sell on Schwab does not consume Robinhood lots
- Ticker with only buys (all open), only sells (no open lots), mixed

### `compute_tax_position` (100% unit coverage)

- ST vs LT classification at boundary: exactly 365 days, 364 days, 366 days
- Option trades included in ST/LT totals
- `basis_unknown` sells excluded from totals, counted separately
- Loss carryforward threshold: net loss exactly $3,000, above ($3,001), below ($2,999)
- Cross-year trades: buy in 2025, sell in 2026 — LT classification still correct
- `loss_needed_to_zero_st`: zero when ST is already negative, positive when ST gains exist

### `identify_open_lots`

- Options excluded from results
- `basis_unknown` lots included with flag set
- Sort order: `days_to_long_term` ascending, then ticker alphabetically
- `as_of` parameter correctly computes `days_held` and `days_to_long_term`

### `select_lots` lot selection

- FIFO / HIFO / LIFO each select the correct lots for a given quantity
- Cross-account pooling: lots from multiple accounts eligible
- Partial lot split: ST and LT components reported separately in `st_gain_loss` / `lt_gain_loss`
- `--price` absent → lot table not rendered (existing behavior unchanged)
- Quantity exceeds available open lots → graceful message
- Zero open lots for ticker → short-circuit message

### `recommend_lot_method` decision tree (dedicated test group)

- ST loss available, no wash risk → `preferred_method` offsets ST gains, `reason="st_loss_offset"`
- ST loss available, wash risk → flag wash risk, populate `safe_sell_date` and `fallback_method`
- No method produces a loss, user has ST gains → prefer LT gain, `reason="lt_lower_rate"`
- No method produces a loss, user has ST losses → prefer smallest ST gain, `reason="least_gain"`
- All methods produce same treatment → prefer smallest gain
- All methods have wash risk → report no clean option
- `basis_unknown` lots in mix → recommendation notes incomplete data

### `simulate sell` lot selection integration

- Wash sale risk composed correctly: loss + look-back triggers → `wash_sale_risk=True`
- Wash sale risk: no loss → `wash_sale_risk=False` even with recent buys
- Recommendation text rendered correctly from `LotRecommendation` fields

---

## Files Changed

| File | Change |
|------|--------|
| `src/net_alpha/models/domain.py` | Modified — add `TaxPosition`, `OpenLot`, `LotSelection`, `LotRecommendation`, `AllocationResult`, `RealizedPair` |
| `src/net_alpha/engine/tax_position.py` | New — pure computation engine (`_allocate_lots`, `compute_tax_position`, `identify_open_lots`, `select_lots`, `recommend_lot_method`) |
| `src/net_alpha/cli/tax_position.py` | New — `tax-position` command (simple command pattern) |
| `src/net_alpha/cli/simulate.py` | Modified — add lot selection helper, called when `--price` given |
| `src/net_alpha/cli/app.py` | Modified — register `tax-position` command |
| `tests/engine/test_tax_position.py` | New — engine unit tests (allocation, tax position, open lots, lot selection, recommendation decision tree) |
| `tests/cli/test_simulate_lots.py` | New — lot selection CLI integration tests |
