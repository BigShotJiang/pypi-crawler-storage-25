# net_alpha — Product & UX Design Spec

**Date:** 2026-04-12
**Status:** Approved
**Supersedes:** PRD v0.2 (open questions resolved here)

---

## 1. Target Users

**Primary (v1):**

- **User A — Accidental victim:** Doesn't know the wash sale rules well. Discovers the problem at tax time. Wants a tool that catches what they'd otherwise miss.
- **User B — Active tax-loss harvester:** Knows the rules. Deliberately sells losers at year-end or throughout the year. Needs to execute that strategy safely across multiple accounts.

**Not targeted (v1):** Systematic high-frequency traders, institutional accounts, non-US investors.

---

## 2. Usage Patterns

Both User A and User B use the tool in two modes:

| Mode              | Description                                           |
| ----------------- | ----------------------------------------------------- |
| **Retrospective** | "What wash sales have I already triggered this year?" |
| **Prospective**   | "Is it safe to sell this position right now?"         |

The tool must serve both modes without the user needing to think about which mode they're in.

---

## 3. v1 Feature Scope

### Features included

| Priority | Feature                                   | Command(s)                                                    |
| -------- | ----------------------------------------- | ------------------------------------------------------------- |
| P0       | Interactive first-run wizard              | `net-alpha` (no args, first run)                              |
| P0       | CSV import — LLM-powered schema detection | `net-alpha import <broker> <file>`                            |
| P0       | Cross-account wash sale check             | `net-alpha check`                                             |
| P0 | Pre-trade simulation | `net-alpha simulate sell <ticker> <qty>` |
| P1       | Safe-to-rebuy tracker                     | `net-alpha rebuys`                                            |
| P1       | Annual report                             | `net-alpha report [--year YYYY] [--csv]`                      |
| P2       | Per-ticker / per-type filtering           | `net-alpha check --ticker <TICKER>` / `--type options`        |

### Deferred to v2

- TUI (Textual-based) — post-v1, once CLI is stable
- Tax software export (TurboTax / TaxAct 1099-B format)
- Unrealized loss / harvest opportunity scanner
- Year-end countdown view
- Brokerage API integrations (Schwab OAuth, Robinhood robin_stocks)

### New vs PRD

- `net-alpha rebuys` command added (safe-to-rebuy tracker — see §7)
- First-run interactive wizard replaces bare help screen
- Confidence labels simplified from 4 to 3 tiers (see §5)

---

## 4. UX Approach

**CLI-first, rich-powered.**

All output uses the `rich` library for color-coded tables, progress indicators, and formatted summaries. The goal is an output so readable that a non-technical user can interpret results without needing a GUI.

TUI (`Textual`) is a post-v1 milestone, built once the core feature set is stable.

---

## 5. Confidence Labels

Simplified from the PRD's 4-tier model to 3 tiers:

| Label       | Color  | Meaning                                      |
| ----------- | ------ | -------------------------------------------- |
| `Confirmed` | Red    | Definite wash sale under IRS Publication 550 |
| `Probable`  | Yellow | Likely wash sale; CPA review recommended     |
| `Unclear`   | Blue   | Ambiguous case; flag for professional review |

All `Probable` and `Unclear` findings include the standard disclaimer. The disclaimer also appears on all `Confirmed` findings and on every command output (see §9).

---

## 6. UX Flows

### Flow 1: First-run wizard

Triggered when the user runs `net-alpha` with no trades in the database. Not shown once any import has completed.

```
$ net-alpha

  Welcome to net-alpha — cross-account wash sale detection.
  The only open-source tool that tracks wash sales across all your accounts.

  Let's get started. Which broker is your first account?
  > [prompt]

  [LLM detects schema from headers + 3 anonymized sample rows]

  Detected schema for Schwab CSV:
  ────────────────────────────────
  date       → "Date"
  ticker     → "Symbol"
  action     → "Action"   [buy: Buy, Reinvest]  [sell: Sell]
  quantity   → "Quantity"
  proceeds   → "Amount"
  ────────────────────────────────
  Does this look correct? (y/n) > y

  Imported 847 trades from Schwab (612 equities, 198 options, 37 ETFs).

  Do you have another account to import? (y/n) > y
  [repeats import flow]

  Do you have another account to import? (y/n) > n

  Running your first wash sale check…
  [shows check output — see Flow 2]

  Run `net-alpha check` anytime to re-scan.

  ⚠ This is informational only. Consult a tax professional before filing.
```

Import does not proceed without user confirming the detected schema. Schema is cached after confirmation — no LLM call on subsequent imports of the same broker format.

### Flow 2: `net-alpha check`

```
$ net-alpha check

  ⚠ Robinhood data last imported 47 days ago.
    Trades from Oct 1–Nov 3 may be missing — check may be incomplete.
    Run `net-alpha import robinhood <file>` to update.

  WASH SALE SUMMARY — 2024 (all accounts)
  ─────────────────────────────────────────
  Confirmed    3 violations    $4,200 disallowed
  Probable     2 violations    $1,100 disallowed  (recommend CPA review)
  Unclear      1 violation     $300  disallowed   (recommend CPA review)
  ─────────────────────────────────────────
  Total disallowed loss:       $5,600

  2 positions safe to rebuy — run `net-alpha rebuys` for details

  DETAIL
  ─────────────────────────────────────────────────────────────────────────────
  Date        Ticker  Account    Type      Loss      Status     Disallowed
  ─────────────────────────────────────────────────────────────────────────────
  2024-10-15  TSLA    Schwab     Equity    ($1,200)  Confirmed  $1,200
  2024-11-03  NVDA    Robinhood  Equity    ($840)    Confirmed  $840
  ...
  ─────────────────────────────────────────────────────────────────────────────

  ⚠ This is informational only. Consult a tax professional before filing.
```

**Staleness warning rules:** Shown only when a stale account has trades within the 30-day wash sale window of the current scan. Not shown otherwise.

**Output hierarchy:** verdict (count + label) → dollar impact → per-trade detail. User sees the summary before the noise.

### Flow 3: `net-alpha simulate sell TSLA 10`

`simulate` is account-agnostic — wash sale detection always checks across all imported accounts. `--account` is not required and does not scope the check.

Dollar impact is shown only when `--price` is provided. Without `--price`, the output confirms the trigger and safe date only.

**Look-back hit (prior purchase within 30 days):**

```
$ net-alpha simulate sell TSLA 10

  SIMULATION: Sell 10 TSLA
  ───────────────────────────────────────────────
  ⚠ Wash sale would be triggered.

  Reason: Bought 15 TSLA on Robinhood (Nov 3) — 12 days ago [Confirmed]
  Safe to sell cleanly: December 3, 2024 (21 days away)

  ⚠ This is informational only. Consult a tax professional before filing.
```

**Look-back hit with `--price`:**

```
$ net-alpha simulate sell TSLA 10 --price 240

  SIMULATION: Sell 10 TSLA @ $240
  ───────────────────────────────────────────────
  ⚠ Wash sale would be triggered — $1,840 of this loss would be DISALLOWED

  Reason: Bought 15 TSLA on Robinhood (Nov 3) — 12 days ago [Confirmed]
  Safe to sell cleanly: December 3, 2024 (21 days away)
  Estimated recoverable loss (if waited): $1,840

  ⚠ This is informational only. Consult a tax professional before filing.
```

**No look-back violation (look-forward warning only):**

```
  SIMULATION: Sell 10 TSLA
  ───────────────────────────────────────────────
  ✓ No wash sale detected. Safe to sell.

  ⚠ Warning: any repurchase of TSLA before December 3, 2024 would trigger a wash sale.

  ⚠ This is informational only. Consult a tax professional before filing.
```

**Both clean:**

```
  SIMULATION: Sell 10 TSLA
  ───────────────────────────────────────────────
  ✓ Safe to sell. No wash sale risk.

  ⚠ This is informational only. Consult a tax professional before filing.
```

### Flow 4: `net-alpha rebuys`

```
$ net-alpha rebuys

  SAFE-TO-REBUY TRACKER
  ────────────────────────────────────────────────────────────────────────
  Ticker  Qty Open  Sold Date   Account    Safe to Rebuy   Days Remaining
  ────────────────────────────────────────────────────────────────────────
  TSLA    60/100    Nov 14      Schwab     Dec 14          12 days
  NVDA    312       Nov 20      Robinhood  Dec 20          18 days
  ────────────────────────────────────────────────────────────────────────
  2 positions in wash sale window.

  ⚠ This is informational only. Consult a tax professional before filing.
```

### Flow 5: `net-alpha report`

```
$ net-alpha report --year 2024

  WASH SALE REPORT — Tax Year 2024
  ─────────────────────────────────────────
  Total trades imported:     1,159
  Loss trades:               87
  Wash sales identified:     6  (3 Confirmed, 2 Probable, 1 Unclear)
  Total disallowed loss:     $5,600
  Adjusted cost basis delta: +$5,600 (rolled into replacement lots)

  [full per-trade detail table]

  * Replacement lot allocation uses FIFO ordering. Your tax preparer may use a different method.
  ⚠ This is informational only. Consult a tax professional before filing.
```

`--csv` flag writes a CSV file to the current directory in addition to terminal output. No CSV is written by default.

---

## 7. Safe-to-Rebuy Tracker (new feature)

When a position is sold at a loss, the 30-day wash sale window opens. The tool tracks:

1. The sold position and the date it was sold
2. The exact date the window closes (sale date + 30 days)
3. Days remaining until safe to rebuy

**Eligibility:** A position appears in `rebuys` when:

- A loss sale was recorded, AND
- The 30-day window is still open, AND
- There is remaining open quantity not yet matched to a triggering repurchase

**Partial wash sales:** If a repurchase has been detected for part of the sold quantity, the wash sale violation appears in `check` for the matched portion, and the remaining unmatched quantity continues to appear in `rebuys`. The `Qty Open` column shows remaining/total (e.g. `60/100`) for partial cases and a plain number for fully unmatched cases. `rebuys` tracks remaining open quantity, not just the ticker.

`rebuys` is a forward-looking watchlist, not a historical log.

Surfaced in two ways:

- **Passively** — a one-line callout at the bottom of `net-alpha check` output ("2 positions safe to rebuy — run `net-alpha rebuys` for details")
- **Actively** — full detail table via `net-alpha rebuys`

---

## 8. ETF Substantially-Identical Pairs

**Hardcoded defaults** ship bundled in `etf_pairs.yaml`:

```yaml
sp500:
  - SPY
  - VOO
  - IVV
  - SPLG
nasdaq100:
  - QQQ
  - QQQM
russell2000:
  - IWM
  - VTWO
gold:
  - GLD
  - IAU
```

**User overrides:** Users can create `~/.net_alpha/etf_pairs.yaml` to add custom pairs. User file extends the defaults — it never replaces them. When a finding uses a user-defined pair, `check` output notes it:

```
  VOO → VOOG  [user-defined pair]  Probable  $500
```

---

## 9. Disclaimer Policy

**Wording (fixed, never varies):**

> ⚠ This is informational only. Consult a tax professional before filing.

**Placement:** One line at the bottom of every command output, without exception. Not expandable, not skippable, always present.

---

## 10. Data Storage

- Single SQLite database at `~/.net_alpha/net_alpha.db`
- All tax years stored in one database — enables cross-year wash sale detection (e.g., Dec 20 sale / Jan 5 repurchase)
- `check` defaults to current calendar year; `--year YYYY` to scan a prior year
- **Cross-year window:** `--year YYYY` scopes which _loss sales_ are analyzed; the 30-day look-back and look-forward window always extends into adjacent years as needed. A Dec 20, 2024 loss sale can be washed by a Jan 5, 2025 buy and will appear in `--year 2024` output.
- **Schema cache key:** `broker_name + SHA256(header_row)`. On header hash mismatch, the user is warned that the broker's format has changed and a new LLM detection + confirmation is triggered. Multiple schema versions may coexist for the same broker in the DB (e.g. Schwab pre- and post-format-change).
- **Schema cache contents:** column mapping + `option_format` identifier (e.g. `schwab_human`, `occ_standard`) used to select the correct option symbol regex parser.
- **`schema_cache_id` on trade records:** Each trade stores a `schema_cache_id` foreign key referencing the `SchemaCache` entry it was imported with. The option symbol parser always uses the `option_format` from that trade's own schema cache entry — never a global per-broker default. This ensures correct regex selection across format changes: a Dec 2024 trade parsed with `schwab_human` and a Jan 2025 trade parsed with a new format are each re-parsed with their own regex when compared in cross-year wash sale detection.
- **Database migrations:** A `meta` table stores `schema_version` (integer). On startup, hand-written `ALTER TABLE` statements bring the DB to the current version. No external migration framework. **Migration contract:** each version's migration must document the behavioral implication of NULL values in newly added columns and specify the fallback explicitly in code. Example: `raw_row_hash IS NULL` means the trade was imported before this field existed — the dedup logic must treat NULL as "use semantic key only" as an explicit coded default, not an accident of missing data.
- No telemetry. No remote calls after initial LLM schema detection per broker format.
- Only CSV headers + 3 anonymized sample rows sent to LLM. Anonymization is a concrete transformation applied by a named function `anonymize_row(raw_row: dict) -> dict` before any LLM call: (1) numeric columns → replace value with `1.00`; (2) any value matching account number pattern (`\d{4,}` standalone or suffix) → replace with `XXXX`; (3) dates → kept as-is (structural signal, not PII); (4) ticker symbols → kept as-is (needed for LLM to identify the column). No real dollar amounts, quantities, or account identifiers leave the machine.

---

## 11. Open Questions (resolved)

| Question                        | Decision                                                                                       |
| ------------------------------- | ---------------------------------------------------------------------------------------------- |
| Schema confirmation required?   | Yes, always, before first import of each new format                                            |
| Multi-year DB or one per year?  | Single DB, all years                                                                           |
| Report format?                  | Text by default; `--csv` flag optional                                                         |
| Simulate look-back warning?     | Yes — look-back hits and look-forward open windows are distinguished in output (see §6 Flow 3) |
| ETF pairs: hardcoded or config? | Hardcoded defaults + optional user `~/.net_alpha/etf_pairs.yaml` override                      |
| Simulate: which account?        | Account-agnostic — wash sale checked across all accounts; `--account` not required             |
| Simulate: dollar amount?        | Omitted unless `--price <price>` flag provided                                                 |
| Schema cache key?               | `broker_name + SHA256(header_row)`; mismatch triggers re-detection prompt                      |
| Cross-year detection?           | `--year` scopes loss sales; 30-day window crosses year boundaries freely                       |
| `rebuys` eligibility?           | Open windows only — no triggering buy detected yet                                             |
| LLM API failure?                | Retry 3x with exponential backoff, then hard fail with diagnostic error                        |
| DB migrations?                  | Hand-written versioned migrations with `schema_version` meta table                             |
| Lot vs. position tracking?      | Lot-level throughout                                                                           |
| Duplicate imports?              | Deduplicate by identity key; skipped-count in import summary                                   |
| Missing cost basis?             | Mark `basis_unknown`; exclude from analysis; warn at import and `check`                        |
| API key management?             | Env var → config file fallback; first-run wizard prompts if neither set                        |
| Testing strategy?               | Engine unit tests (no mocks), LLM flow mocked, golden-file CSV integration tests               |

---

## 12. Tech Stack

### Runtime dependencies

| Library             | Version | Purpose                                                                                                                                                                              |
| ------------------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `typer[all]`        | latest  | CLI framework — bundles `rich` and `click`                                                                                                                                           |
| `questionary`       | latest  | Interactive wizard prompts (arrow-key menus, validation)                                                                                                                             |
| `pydantic`          | v2      | Data models and validation                                                                                                                                                           |
| `sqlmodel`          | latest  | ORM over SQLite — used for storage layer only (table classes); domain models are pure Pydantic v2 with no SQLAlchemy inheritance                                                     |
| `anthropic`         | latest  | LLM schema detection (`claude-3-5-haiku-latest`)                                                                                                                                            |
| `datetime`          | stdlib  | Date arithmetic — 30-day window math using `datetime.date` and `timedelta`; trade dates stored as `YYYY-MM-DD` strings exactly as they appear in broker CSVs, no timezone conversion |
| `pydantic-settings` | latest  | Config file handling (`~/.net_alpha/config.toml`)                                                                                                                                    |
| `loguru`            | latest  | Structured logging for CLI                                                                                                                                                           |

### Development dependencies

| Tool          | Purpose                                              |
| ------------- | ---------------------------------------------------- |
| `uv`          | Package manager and virtualenv (replaces pip + venv) |
| `hatch`       | Build backend                                        |
| `pytest`      | Test runner                                          |
| `pytest-cov`  | Coverage reporting                                   |
| `factory_boy` | Trade/lot fixture factories for tests                |
| `ruff`        | Linting and formatting (replaces flake8 + black)     |

### Environment isolation

**Developer setup:**

- `uv` manages Python in `~/.local/share/uv/` — never touches system or Homebrew Python
- `uv sync` creates `.venv` inside the project directory
- `.python-version` file pins exact Python version (3.11.x)
- All commands run via `uv run <cmd>` — no manual venv activation needed
- `Makefile` wraps `make test`, `make lint`, `make check` using `uv run`

**End-user installation:**

- **Recommended:** `pipx install net-alpha` — isolated venv per CLI tool, only binary exposed to PATH
- **Alternative:** `uv tool install net-alpha` — for users already on `uv`
- **Discouraged in docs:** `pip install net-alpha` — pollutes global environment
- Tool data lives exclusively in `~/.net_alpha/` — no other writes on the user's machine

**Never touches:**

- `/usr/local/lib`, `/Library/Python`, system Python
- Homebrew-managed packages
- Global `~/.local/lib` pip packages
- No LaunchAgents, cron jobs, or background services

---

## 13. Implementation Decisions

Decisions made during design review, recorded here for implementation reference.

### Data model

- **Two-layer architecture:** Domain models (`Trade`, `Lot`, `WashSaleViolation`, `OptionDetails`) are pure Pydantic v2 classes with no SQLAlchemy inheritance — the wash sale engine operates entirely on these, with no DB dependency. Separate SQLModel table classes handle persistence and map to/from domain models at the storage boundary. This keeps the engine pure Python and fully unit-testable without a database.
- **Lot-level tracking:** Each buy creates a distinct lot with its own cost basis, quantity, and adjusted basis after wash sale adjustment. Position-level aggregation is not used anywhere in the engine.
- **Missing cost basis:** Trades with no cost basis column are marked `basis_unknown`. The exclusion rule is split by role: (1) `basis_unknown` trades are excluded as _loss sale candidates_ — you cannot calculate a loss without basis; (2) `basis_unknown` trades are still evaluated as potential _replacement buys_ in the 30-day window — only the date and ticker are needed to detect the trigger. When a `basis_unknown` buy triggers a wash sale, it is reported at the normal confidence level but the disallowed loss is shown as `$???` with the note: _"Cost basis unavailable — disallowed amount cannot be calculated. Consult your broker's year-end tax documents."_ A warning is shown at import time and in `check` output with a count: _"142 trades have no cost basis — disallowed loss amounts may be incomplete."_
- **Duplicate import handling:** Trades are deduplicated on import using a two-signal strategy. Primary signal: `raw_row_hash` — SHA256 of the entire raw CSV row bytes, stored on each trade record. Secondary signal (fallback for re-imports where row bytes may differ): semantic key `(broker, date, ticker, action, quantity, proceeds)`. A row is considered a duplicate if either signal matches an existing record. This prevents false-deduplication of same-day same-ticker trades at different times while still catching true re-imports of the same CSV. Duplicates are silently skipped; the import summary reports a count: _"47 duplicate trades skipped."_

### Option symbol parsing

- Option symbol strings (e.g. `"TSLA 12/20/2024 250.00 C"`) are parsed using hand-written regexes, not LLM-generated parsers.
- The schema cache stores an `option_format` field (e.g. `schwab_human`, `occ_standard`, `robinhood_human`) that selects the correct regex at parse time.
- Unknown formats fall back to a best-effort regex cascade with a parse warning.
- The canonical `Trade` model stores `ticker` (underlying, e.g. `"TSLA"`) and an optional `OptionDetails` sub-model (strike, expiry, call/put).

### Import reliability

- **LLM API failure:** Retry 3 times with exponential backoff. On final failure, hard fail with a diagnostic error message identifying the cause (missing API key, network error, rate limit). No manual column-mapping fallback.
- **API key resolution order:** `ANTHROPIC_API_KEY` env var → `~/.net_alpha/config.toml`. The first-run wizard prompts for the key if neither is set and writes it to the config file. Env var always takes precedence.

### Testing

- **Wash sale engine:** 100% unit test coverage. Pure functions where possible. No mocks. Fixtures via `factory_boy`. Must cover: boundary dates (day 0, day 30, day 31), partial wash sales, FIFO allocation across multiple triggering buys, cross-account matches, all confidence label scenarios, cross-year window cases.
- **LLM schema detection flow:** Anthropic client mocked. Tests cover retry logic, caching, schema confirmation, and error handling independently of the actual LLM response.
- **Integration tests:** Small set of golden-file tests — anonymized real Schwab/Robinhood CSV samples → expected `Trade` output.

---

## 14. Known Limitations (v1)

- **Option expirations not in CSV:** Option expirations not reported as explicit rows in the broker CSV will not be detected as loss sales. Robinhood does not export expiration rows; users should be aware that expired options on Robinhood may create undetected wash sale exposure. This cannot be solved without broker API access. The `check` output notes this limitation when any options are present in the imported data: _"Note: option expirations missing from your broker CSV (e.g. Robinhood) will not appear as loss sales — wash sale exposure from expired options may be undetected."_ Inferring missing expirations is not attempted.

## 15. Out of Scope (v1)

- TUI (Textual) — post-v1
- Tax software export (TurboTax / 1099-B format) — v2
- Unrealized loss / harvest opportunity scanner — v2
- Year-end countdown — v2
- Brokerage API integrations — v2
- Mutual funds — out of scope indefinitely
- Web UI — out of scope indefinitely (local-first)
- Financial advice — never in scope; tool is informational only
