# net-alpha TUI Concept — Interactive Simulator Design

**Date:** 2026-04-18
**Topic:** Interactive Wash Sale Simulator TUI

## 1. Concept & Value Proposition

**The Goal:** Increase GitHub stars by providing a "best-in-class" user experience that makes a complex, invisible problem (cross-account wash sales) feel tangible and controllable.

**The Solution:** The "Interactive Tax Command Center". A TUI dashboard focused on proactive simulation and prevention. It allows users to draft trades and instantly see if they will trigger wash sales based on recent activity across all their imported brokerage accounts.

## 2. UI Layout & Core Interaction

Built using the **Textual** Python framework, the TUI will feature a split-pane layout:

*   **Top Bar (Header):** Displays global context (e.g., Total YTD realized losses, total disallowed losses across all accounts).
*   **Left Pane (Portfolio Context):** A scrollable `DataTable` widget showing current holdings and recent trades across all brokers.
*   **Right Pane (The Simulator):** The interactive area for drafting trades.
    *   **Input Form:** Fields for Ticker, Action (Buy/Sell), Quantity, and Date.
    *   **Live Analysis:** Updates in real-time (debounced by ~300ms) as the user types:
        *   **Status Indicator:** "Safe to Sell?" (Green check / Red X / Yellow Warning).
        *   **Conflicting Trades:** A list of specific buys within the 30-day window across *any* account that would trigger a wash sale.
        *   **Disallowed Loss Amount:** The exact dollar amount that would be disallowed if the simulated trade were executed.

## 3. Architecture & Integration

*   **Framework:** `textual` for the UI. It provides async support, rich widgets (`DataTable`, reactive inputs), and virtualized scrolling for performance.
*   **Entry Point:** A new Typer command: `net-alpha tui`.
*   **Module Structure:** A new module `src/net_alpha/tui/` will contain:
    *   `app.py`: The main Textual App class.
    *   `screens/`: Layouts for the Dashboard and Simulator views.
    *   `widgets/`: Reusable TUI components.
*   **Data Binding (The Simulator Engine):**
    1.  The TUI loads user trades from the local SQLite database using the existing `TradeRepository`.
    2.  As the user types in the simulator form, a "virtual" `Trade` object is created in memory.
    3.  The existing `WashSaleDetector` logic (`matcher.detect_wash_sales()`) is executed, passing the real database trades *plus* the virtual trade.
    4.  This calculation is performed locally and asynchronously on every debounced keystroke to provide immediate feedback without freezing the UI.

## 4. Edge Cases & State Management

*   **Empty Database (No imports):** If launched without data, the Holdings pane displays *"No trade data found."* The Simulator pane is disabled with a prompt: *"Press `i` or use the CLI to import broker CSVs first."*
*   **Invalid Form Input:** If the user enters invalid data (e.g., non-numeric quantity), the Simulator pane displays a validation error. The status indicator reverts to a neutral state (e.g., grey `?`) to prevent false "Safe" signals.
*   **Confidence Levels (Options/ETFs):** The TUI will surface the core engine's confidence labels (`Confirmed`, `Probable`, `Unclear`). If a simulated trade triggers a `Probable` or `Unclear` wash sale, the warning is colored yellow/orange (e.g., *"⚠️ Probable Wash Sale (IRS Gray Area)"*) with an expandable tooltip explaining the reasoning.
*   **Massive Portfolios (Performance):** Textual's `DataTable` widget uses virtualized scrolling to handle thousands of rows efficiently. The simulation engine only queries trades within the relevant 30-day window, maintaining snappy keystroke reactivity.