# CI/CD, Release Publishing & Package Publishing Design

**Date:** 2026-04-14
**Project:** net_alpha
**Status:** Approved

---

## Overview

Add GitHub Actions CI/CD, automated versioning, PyPI package publishing, GitHub Release creation, and README status badges. All infrastructure is free for public repos. No long-lived secrets are stored — PyPI publishing uses OIDC Trusted Publishing.

---

## Goals

- Run lint, tests, and coverage on every push to `master`, every PR, and nightly
- Auto-bump version based on conventional commits; manual override available
- On tag push: build wheel + sdist, publish to PyPI, create GitHub Release with assets
- Display CI status, PyPI version, and test coverage badges on the repo page

---

## Workflow Structure

Three GitHub Actions workflow files under `.github/workflows/`:

### 1. `ci.yml` — Continuous Integration

**Triggers:** push to `master`, all PRs, nightly schedule (`0 0 * * *`)

**Matrix:** Python 3.11 and 3.12

**Steps:**
1. Checkout repo
2. Install `uv`
3. `uv sync --dev`
4. `uv run ruff check .`
5. `uv run ruff format --check .`
6. `uv run pytest --cov=src --cov-report=xml`
7. Upload coverage report to Codecov (free for public repos)

### 2. `version.yml` — Automated Version Bumping

**Triggers:**
- Push to `master` (auto-bump via conventional commits)
- `workflow_dispatch` with `bump` input (`patch` / `minor` / `major`) for manual override

**Tool:** `python-semantic-release` (free, pip-installable)

**Commit convention → version bump mapping:**

| Commit prefix | Bump |
|---|---|
| `fix:` | patch |
| `feat:` | minor |
| `feat!:` or `BREAKING CHANGE:` footer | major |

**Steps:**
1. Checkout repo (with full git history for tag detection)
2. Configure git identity for the commit
3. Run `python-semantic-release version` (auto mode) or `python-semantic-release version --patch/--minor/--major` (manual mode)
4. Push updated `pyproject.toml` commit + new `v*.*.*` tag to `master`

The tag push triggers `release.yml` automatically.

### 3. `release.yml` — Build, Publish & GitHub Release

**Triggers:** push of tags matching `v*.*.*`

**Environment:** `pypi` (configured in GitHub repo Settings → Environments; optional manual approval gate)

**Steps:**
1. Checkout repo
2. Install `uv` and `hatch`
3. `hatch build` → produces `dist/net_alpha-*.whl` and `dist/net_alpha-*.tar.gz`
4. Publish to PyPI via OIDC Trusted Publishing (no token stored)
5. Create GitHub Release via `gh` CLI with:
   - Tag name as release title
   - Auto-generated release notes (from commits between tags)
   - `dist/*` files attached as release assets

---

## PyPI Trusted Publishing (One-Time Setup)

Trusted Publishing uses GitHub's OIDC identity — no `PYPI_TOKEN` secret, no rotation.

**Steps (done once before first release):**
1. Create the PyPI project (first-time: either register manually or run `hatch publish` locally)
2. On pypi.org → project → Publishing → Add Trusted Publisher:
   - Provider: GitHub
   - Owner: `chen-star`
   - Repository: `net_alpha`
   - Workflow filename: `release.yml`
   - Environment name: `pypi`
3. In GitHub repo Settings → Environments → create `pypi` environment (optionally add required reviewers for a manual approval gate)

---

## Codecov Setup (One-Time Setup)

1. Sign in at codecov.io with GitHub account
2. Add `chen-star/net_alpha` repository
3. Copy the `CODECOV_TOKEN` value
4. Add it to GitHub repo Settings → Secrets → `CODECOV_TOKEN`

---

## README Badges

Three badges added to the top of `README.md`:

```markdown
[![CI](https://github.com/chen-star/net_alpha/actions/workflows/ci.yml/badge.svg)](https://github.com/chen-star/net_alpha/actions/workflows/ci.yml)
[![PyPI version](https://badge.fury.io/py/wash-alpha.svg)](https://pypi.org/project/wash-alpha/)
[![codecov](https://codecov.io/gh/chen-star/net_alpha/branch/master/graph/badge.svg)](https://codecov.io/gh/chen-star/net_alpha)
```

---

## `python-semantic-release` Configuration

Add to `pyproject.toml`:

```toml
[tool.semantic_release]
version_toml = ["pyproject.toml:project.version"]
branch = "master"
build_command = ""          # hatch build is handled by release.yml, not PSR
tag_format = "v{version}"
commit_message = "chore: release v{version} [skip ci]"
```

The `[skip ci]` in the version bump commit message prevents `ci.yml` from re-running on the bump commit itself.

---

## Release Flow (Day-to-Day)

**Normal flow:**
1. Write commits using conventional prefixes (`fix:`, `feat:`, etc.)
2. Merge PR to `master`
3. `version.yml` detects commits, bumps version in `pyproject.toml`, commits + tags
4. `release.yml` fires on the new tag → builds, publishes to PyPI, creates GitHub Release

**Manual override:**
1. Go to Actions → `version.yml` → Run workflow
2. Select `patch` / `minor` / `major`
3. Same tag → release chain fires automatically

---

## Files Created

| File | Purpose |
|---|---|
| `.github/workflows/ci.yml` | Lint, test, coverage |
| `.github/workflows/version.yml` | Auto/manual version bump |
| `.github/workflows/release.yml` | Build, PyPI publish, GitHub Release |
| `README.md` | Updated with badge block |
| `pyproject.toml` | Updated with `[tool.semantic_release]` config |

---

## Constraints

- All tooling is free for public GitHub repos
- No API tokens stored in GitHub secrets (Trusted Publishing for PyPI; Codecov token is low-risk read-only)
- `[skip ci]` on version bump commits prevents infinite CI loops
- The `pypi` GitHub Environment can optionally require manual approval before publishing
