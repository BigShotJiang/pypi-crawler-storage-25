# net_alpha Storage Layer — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Implement SQLite persistence via SQLModel, schema migrations, repositories that map between domain models and table classes, and config management via pydantic-settings.

**Architecture:** Two-layer data model — SQLModel table classes handle persistence, pure Pydantic v2 domain models (from Plan 1) handle business logic. Repositories sit at the boundary, converting between the two. A `meta` table tracks schema version; hand-written migrations bring the DB forward on startup.

**Tech Stack:** Python 3.11+, SQLModel, SQLAlchemy (via SQLModel), pydantic-settings, pytest

**Dependencies:** Plan 1 (Core Engine) must be completed first — this plan imports from `net_alpha.models.domain`.

---

## File Structure

| Action | Path | Responsibility |
|--------|------|----------------|
| Create | `src/net_alpha/db/__init__.py` | DB sub-package |
| Create | `src/net_alpha/db/tables.py` | SQLModel table classes (TradeRow, LotRow, WashSaleViolationRow, SchemaCacheRow, MetaRow) |
| Create | `src/net_alpha/db/connection.py` | `get_engine`, `init_db`, `get_session` |
| Create | `src/net_alpha/db/migrations.py` | `run_migrations` + versioned ALTER TABLE statements |
| Create | `src/net_alpha/db/repository.py` | `TradeRepository`, `LotRepository`, `ViolationRepository`, `SchemaCacheRepository` |
| Create | `src/net_alpha/config.py` | `Settings` via pydantic-settings reading `~/.net_alpha/config.toml` |
| Create | `tests/db/__init__.py` | Tests sub-package |
| Create | `tests/db/test_tables.py` | Table class tests |
| Create | `tests/db/test_connection.py` | DB init and migration tests |
| Create | `tests/db/test_repository.py` | Repository CRUD tests |
| Create | `tests/test_config.py` | Config loading tests |

---

### Task 1: Config Management

**Files:**
- Create: `src/net_alpha/config.py`
- Create: `tests/test_config.py`

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_config.py
import os
import tempfile
from pathlib import Path

from net_alpha.config import Settings


def test_default_settings():
    settings = Settings(
        _env_file=None,
        data_dir=Path(tempfile.mkdtemp()),
    )
    assert settings.db_name == "net_alpha.db"
    assert settings.anthropic_model == "claude-3-5-haiku-latest"
    assert settings.llm_max_retries == 3


def test_db_path():
    data_dir = Path(tempfile.mkdtemp())
    settings = Settings(_env_file=None, data_dir=data_dir)
    assert settings.db_path == data_dir / "net_alpha.db"


def test_etf_pairs_path():
    data_dir = Path(tempfile.mkdtemp())
    settings = Settings(_env_file=None, data_dir=data_dir)
    assert settings.user_etf_pairs_path == data_dir / "etf_pairs.yaml"


def test_anthropic_api_key_from_env(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test-123")
    settings = Settings(
        _env_file=None,
        data_dir=Path(tempfile.mkdtemp()),
    )
    assert settings.anthropic_api_key == "sk-test-123"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/test_config.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Write the implementation**

```python
# src/net_alpha/config.py
from __future__ import annotations

from pathlib import Path
from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings

_DEFAULT_DATA_DIR = Path.home() / ".net_alpha"


class Settings(BaseSettings):
    """Application settings, loaded from env vars and ~/.net_alpha/config.toml."""

    model_config = {"env_file": None, "toml_file": None, "extra": "ignore"}

    data_dir: Path = Field(default=_DEFAULT_DATA_DIR)
    db_name: str = "net_alpha.db"
    anthropic_api_key: Optional[str] = None
    anthropic_model: str = "claude-3-5-haiku-latest"
    llm_max_retries: int = 3

    @property
    def db_path(self) -> Path:
        return self.data_dir / self.db_name

    @property
    def user_etf_pairs_path(self) -> Path:
        return self.data_dir / "etf_pairs.yaml"

    @property
    def config_toml_path(self) -> Path:
        return self.data_dir / "config.toml"
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/test_config.py -v`
Expected: All 4 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/config.py tests/test_config.py
git commit -m "feat: add Settings config via pydantic-settings"
```

---

### Task 2: SQLModel Table Classes

**Files:**
- Create: `src/net_alpha/db/__init__.py`
- Create: `src/net_alpha/db/tables.py`
- Create: `tests/db/__init__.py`
- Create: `tests/db/test_tables.py`

- [ ] **Step 1: Create package init files**

```bash
mkdir -p src/net_alpha/db tests/db
touch src/net_alpha/db/__init__.py tests/db/__init__.py
```

- [ ] **Step 2: Write the failing tests**

```python
# tests/db/test_tables.py
from datetime import date

from net_alpha.db.tables import (
    LotRow,
    MetaRow,
    SchemaCacheRow,
    TradeRow,
    WashSaleViolationRow,
)


def test_trade_row_creation():
    row = TradeRow(
        id="t1",
        account="Schwab",
        date="2024-10-15",
        ticker="TSLA",
        action="Sell",
        quantity=10.0,
        proceeds=2400.0,
        cost_basis=3600.0,
        basis_unknown=False,
        raw_row_hash="abc123",
        schema_cache_id="sc1",
    )
    assert row.id == "t1"
    assert row.ticker == "TSLA"


def test_trade_row_with_option_fields():
    row = TradeRow(
        id="t2",
        account="Schwab",
        date="2024-10-15",
        ticker="TSLA",
        action="Buy",
        quantity=1.0,
        cost_basis=500.0,
        option_strike=250.0,
        option_expiry="2024-12-20",
        option_call_put="C",
    )
    assert row.option_strike == 250.0
    assert row.option_call_put == "C"


def test_lot_row_creation():
    row = LotRow(
        id="l1",
        trade_id="t1",
        account="Schwab",
        date="2024-10-15",
        ticker="TSLA",
        quantity=10.0,
        cost_basis=2400.0,
        adjusted_basis=2400.0,
    )
    assert row.adjusted_basis == 2400.0


def test_wash_sale_violation_row():
    row = WashSaleViolationRow(
        id="v1",
        loss_trade_id="t1",
        replacement_trade_id="t2",
        confidence="Confirmed",
        disallowed_loss=1200.0,
        matched_quantity=10.0,
    )
    assert row.confidence == "Confirmed"


def test_schema_cache_row():
    row = SchemaCacheRow(
        id="sc1",
        broker_name="schwab",
        header_hash="sha256abc",
        column_mapping='{"date": "Date", "ticker": "Symbol"}',
        option_format="schwab_human",
    )
    assert row.broker_name == "schwab"


def test_meta_row():
    row = MetaRow(key="schema_version", value="1")
    assert row.key == "schema_version"
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `uv run pytest tests/db/test_tables.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 4: Write the implementation**

```python
# src/net_alpha/db/tables.py
from __future__ import annotations

from typing import Optional

from sqlmodel import Field, SQLModel


class TradeRow(SQLModel, table=True):
    __tablename__ = "trades"

    id: str = Field(primary_key=True)
    account: str = Field(index=True)
    date: str = Field(index=True)  # YYYY-MM-DD
    ticker: str = Field(index=True)
    action: str
    quantity: float
    proceeds: Optional[float] = None
    cost_basis: Optional[float] = None
    basis_unknown: bool = False
    raw_row_hash: Optional[str] = Field(default=None, index=True)
    schema_cache_id: Optional[str] = Field(default=None)

    # Option fields (flattened — no nested tables)
    option_strike: Optional[float] = None
    option_expiry: Optional[str] = None  # YYYY-MM-DD
    option_call_put: Optional[str] = None  # "C" or "P"


class LotRow(SQLModel, table=True):
    __tablename__ = "lots"

    id: str = Field(primary_key=True)
    trade_id: str = Field(index=True)
    account: str
    date: str
    ticker: str = Field(index=True)
    quantity: float
    cost_basis: float
    adjusted_basis: float

    option_strike: Optional[float] = None
    option_expiry: Optional[str] = None
    option_call_put: Optional[str] = None


class WashSaleViolationRow(SQLModel, table=True):
    __tablename__ = "wash_sale_violations"

    id: str = Field(primary_key=True)
    loss_trade_id: str = Field(index=True)
    replacement_trade_id: str = Field(index=True)
    confidence: str
    disallowed_loss: float
    matched_quantity: float


class SchemaCacheRow(SQLModel, table=True):
    __tablename__ = "schema_cache"

    id: str = Field(primary_key=True)
    broker_name: str = Field(index=True)
    header_hash: str = Field(index=True)
    column_mapping: str  # JSON string
    option_format: Optional[str] = None


class MetaRow(SQLModel, table=True):
    __tablename__ = "meta"

    key: str = Field(primary_key=True)
    value: str
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/db/test_tables.py -v`
Expected: All 6 tests PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/db/__init__.py src/net_alpha/db/tables.py tests/db/__init__.py tests/db/test_tables.py
git commit -m "feat: add SQLModel table classes for all entities"
```

---

### Task 3: Database Connection and Initialization

**Files:**
- Create: `src/net_alpha/db/connection.py`
- Create: `tests/db/test_connection.py`

- [ ] **Step 1: Write the failing tests**

```python
# tests/db/test_connection.py
import tempfile
from pathlib import Path

from sqlmodel import Session, select

from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.tables import MetaRow, TradeRow


def test_init_db_creates_tables():
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        engine = get_engine(db_path)
        init_db(engine)

        with Session(engine) as session:
            # Tables should exist — inserting should work
            row = TradeRow(
                id="t1",
                account="Schwab",
                date="2024-10-15",
                ticker="TSLA",
                action="Buy",
                quantity=10.0,
            )
            session.add(row)
            session.commit()

            result = session.exec(select(TradeRow)).first()
            assert result is not None
            assert result.ticker == "TSLA"


def test_init_db_sets_schema_version():
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        engine = get_engine(db_path)
        init_db(engine)

        with Session(engine) as session:
            meta = session.exec(
                select(MetaRow).where(MetaRow.key == "schema_version")
            ).first()
            assert meta is not None
            assert int(meta.value) >= 1


def test_init_db_idempotent():
    """Calling init_db twice should not error."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        engine = get_engine(db_path)
        init_db(engine)
        init_db(engine)  # Should not raise
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/db/test_connection.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Write the implementation**

```python
# src/net_alpha/db/connection.py
from __future__ import annotations

from pathlib import Path

from sqlalchemy import text
from sqlmodel import Session, SQLModel, create_engine, select

from net_alpha.db.tables import MetaRow

CURRENT_SCHEMA_VERSION = 1


def get_engine(db_path: Path):
    """Create a SQLAlchemy engine for the given SQLite database path."""
    db_path.parent.mkdir(parents=True, exist_ok=True)
    return create_engine(f"sqlite:///{db_path}", echo=False)


def init_db(engine) -> None:
    """Create all tables and set initial schema version if needed."""
    SQLModel.metadata.create_all(engine)

    with Session(engine) as session:
        existing = session.exec(
            select(MetaRow).where(MetaRow.key == "schema_version")
        ).first()
        if existing is None:
            session.add(MetaRow(key="schema_version", value=str(CURRENT_SCHEMA_VERSION)))
            session.commit()
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/db/test_connection.py -v`
Expected: All 3 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/db/connection.py tests/db/test_connection.py
git commit -m "feat: add DB connection and init with schema versioning"
```

---

### Task 4: Schema Migrations

**Files:**
- Create: `src/net_alpha/db/migrations.py`
- Modify: `tests/db/test_connection.py`

- [ ] **Step 1: Write the failing tests**

```python
# append to tests/db/test_connection.py
from net_alpha.db.migrations import run_migrations
from net_alpha.db.connection import CURRENT_SCHEMA_VERSION


def test_run_migrations_noop_when_current():
    """No migrations needed when DB is already at current version."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        engine = get_engine(db_path)
        init_db(engine)
        run_migrations(engine)  # Should not raise

        with Session(engine) as session:
            meta = session.exec(
                select(MetaRow).where(MetaRow.key == "schema_version")
            ).first()
            assert int(meta.value) == CURRENT_SCHEMA_VERSION


def test_run_migrations_updates_version():
    """Migrations bring schema_version to current."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        engine = get_engine(db_path)
        init_db(engine)

        # Simulate old version
        with Session(engine) as session:
            meta = session.exec(
                select(MetaRow).where(MetaRow.key == "schema_version")
            ).first()
            meta.value = "0"
            session.add(meta)
            session.commit()

        run_migrations(engine)

        with Session(engine) as session:
            meta = session.exec(
                select(MetaRow).where(MetaRow.key == "schema_version")
            ).first()
            assert int(meta.value) == CURRENT_SCHEMA_VERSION
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/db/test_connection.py::test_run_migrations_noop_when_current -v`
Expected: FAIL with `ImportError`

- [ ] **Step 3: Write the implementation**

```python
# src/net_alpha/db/migrations.py
from __future__ import annotations

from sqlalchemy import text
from sqlmodel import Session, select

from net_alpha.db.connection import CURRENT_SCHEMA_VERSION
from net_alpha.db.tables import MetaRow


def run_migrations(engine) -> None:
    """Run hand-written migrations to bring DB to current schema version.

    Each migration documents the behavioral implication of NULL values
    in newly added columns and specifies the fallback explicitly.
    """
    with Session(engine) as session:
        meta = session.exec(
            select(MetaRow).where(MetaRow.key == "schema_version")
        ).first()
        if meta is None:
            return

        current = int(meta.value)

        if current < 1:
            _migrate_v0_to_v1(session)
            current = 1

        # Future migrations go here:
        # if current < 2:
        #     _migrate_v1_to_v2(session)
        #     current = 2

        meta.value = str(CURRENT_SCHEMA_VERSION)
        session.add(meta)
        session.commit()


def _migrate_v0_to_v1(session: Session) -> None:
    """v0 → v1: Initial schema. All tables created by init_db.

    Migration v0→v1 is a no-op because init_db already creates all v1 tables.
    This exists as a placeholder for the migration framework pattern.

    NULL policy for v1 columns:
    - raw_row_hash IS NULL → trade was imported before dedup was added;
      dedup logic treats NULL as "use semantic key only"
    - schema_cache_id IS NULL → trade was imported before schema caching;
      option parser falls back to best-effort cascade
    """
    pass
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/db/test_connection.py -v`
Expected: All 5 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/db/migrations.py tests/db/test_connection.py
git commit -m "feat: add schema migration framework with v0→v1"
```

---

### Task 5: Trade Repository — Domain ↔ Table Mapping

**Files:**
- Create: `src/net_alpha/db/repository.py`
- Create: `tests/db/test_repository.py`

- [ ] **Step 1: Write the failing tests**

```python
# tests/db/test_repository.py
import tempfile
from datetime import date
from pathlib import Path

from sqlmodel import Session

from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import TradeRepository
from net_alpha.models.domain import OptionDetails, Trade

import pytest


@pytest.fixture
def db_session():
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        engine = get_engine(db_path)
        init_db(engine)
        with Session(engine) as session:
            yield session


def test_save_and_load_equity_trade(db_session):
    repo = TradeRepository(db_session)
    trade = Trade(
        account="Schwab",
        date=date(2024, 10, 15),
        ticker="TSLA",
        action="Sell",
        quantity=10.0,
        proceeds=2400.0,
        cost_basis=3600.0,
        raw_row_hash="abc123",
        schema_cache_id="sc1",
    )
    repo.save(trade)
    db_session.commit()

    loaded = repo.get_by_id(trade.id)
    assert loaded is not None
    assert loaded.ticker == "TSLA"
    assert loaded.proceeds == 2400.0
    assert loaded.is_loss() is True
    assert loaded.raw_row_hash == "abc123"


def test_save_and_load_option_trade(db_session):
    repo = TradeRepository(db_session)
    trade = Trade(
        account="Schwab",
        date=date(2024, 10, 15),
        ticker="TSLA",
        action="Buy",
        quantity=1.0,
        cost_basis=500.0,
        option_details=OptionDetails(
            strike=250.0, expiry=date(2024, 12, 20), call_put="C"
        ),
    )
    repo.save(trade)
    db_session.commit()

    loaded = repo.get_by_id(trade.id)
    assert loaded is not None
    assert loaded.is_option() is True
    assert loaded.option_details.strike == 250.0
    assert loaded.option_details.expiry == date(2024, 12, 20)
    assert loaded.option_details.call_put == "C"


def test_list_trades_by_account(db_session):
    repo = TradeRepository(db_session)
    repo.save(Trade(account="Schwab", date=date(2024, 1, 1), ticker="A", action="Buy", quantity=1.0))
    repo.save(Trade(account="Robinhood", date=date(2024, 1, 1), ticker="B", action="Buy", quantity=1.0))
    repo.save(Trade(account="Schwab", date=date(2024, 1, 2), ticker="C", action="Buy", quantity=1.0))
    db_session.commit()

    schwab = repo.list_by_account("Schwab")
    assert len(schwab) == 2


def test_list_all_trades(db_session):
    repo = TradeRepository(db_session)
    repo.save(Trade(account="Schwab", date=date(2024, 1, 1), ticker="A", action="Buy", quantity=1.0))
    repo.save(Trade(account="Robinhood", date=date(2024, 1, 1), ticker="B", action="Buy", quantity=1.0))
    db_session.commit()

    all_trades = repo.list_all()
    assert len(all_trades) == 2


def test_find_by_hash(db_session):
    repo = TradeRepository(db_session)
    trade = Trade(
        account="Schwab", date=date(2024, 1, 1), ticker="A",
        action="Buy", quantity=1.0, raw_row_hash="hash123",
    )
    repo.save(trade)
    db_session.commit()

    found = repo.find_by_hash("hash123")
    assert found is not None
    assert found.id == trade.id

    assert repo.find_by_hash("nonexistent") is None


def test_find_by_semantic_key(db_session):
    repo = TradeRepository(db_session)
    trade = Trade(
        account="Schwab", date=date(2024, 1, 1), ticker="TSLA",
        action="Buy", quantity=10.0, proceeds=None,
    )
    repo.save(trade)
    db_session.commit()

    found = repo.find_by_semantic_key("Schwab", "2024-01-01", "TSLA", "Buy", 10.0, None)
    assert found is not None

    assert repo.find_by_semantic_key("Schwab", "2024-01-01", "TSLA", "Buy", 99.0, None) is None


def test_list_accounts(db_session):
    repo = TradeRepository(db_session)
    repo.save(Trade(account="Schwab", date=date(2024, 1, 1), ticker="A", action="Buy", quantity=1.0))
    repo.save(Trade(account="Robinhood", date=date(2024, 1, 1), ticker="B", action="Buy", quantity=1.0))
    repo.save(Trade(account="Schwab", date=date(2024, 1, 2), ticker="C", action="Buy", quantity=1.0))
    db_session.commit()

    accounts = repo.list_accounts()
    assert set(accounts) == {"Schwab", "Robinhood"}
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/db/test_repository.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Write the implementation**

```python
# src/net_alpha/db/repository.py
from __future__ import annotations

from datetime import date
from typing import Optional

from sqlalchemy import distinct
from sqlmodel import Session, select

from net_alpha.db.tables import (
    LotRow,
    SchemaCacheRow,
    TradeRow,
    WashSaleViolationRow,
)
from net_alpha.models.domain import (
    Lot,
    OptionDetails,
    Trade,
    WashSaleViolation,
)


class TradeRepository:
    def __init__(self, session: Session):
        self._session = session

    def save(self, trade: Trade) -> None:
        row = _trade_to_row(trade)
        self._session.add(row)

    def save_batch(self, trades: list[Trade]) -> None:
        for trade in trades:
            self.save(trade)

    def get_by_id(self, trade_id: str) -> Optional[Trade]:
        row = self._session.get(TradeRow, trade_id)
        if row is None:
            return None
        return _row_to_trade(row)

    def list_all(self) -> list[Trade]:
        rows = self._session.exec(select(TradeRow)).all()
        return [_row_to_trade(r) for r in rows]

    def list_by_account(self, account: str) -> list[Trade]:
        rows = self._session.exec(
            select(TradeRow).where(TradeRow.account == account)
        ).all()
        return [_row_to_trade(r) for r in rows]

    def find_by_hash(self, raw_row_hash: str) -> Optional[Trade]:
        row = self._session.exec(
            select(TradeRow).where(TradeRow.raw_row_hash == raw_row_hash)
        ).first()
        if row is None:
            return None
        return _row_to_trade(row)

    def find_by_semantic_key(
        self,
        account: str,
        date_str: str,
        ticker: str,
        action: str,
        quantity: float,
        proceeds: Optional[float],
    ) -> Optional[Trade]:
        stmt = select(TradeRow).where(
            TradeRow.account == account,
            TradeRow.date == date_str,
            TradeRow.ticker == ticker,
            TradeRow.action == action,
            TradeRow.quantity == quantity,
        )
        if proceeds is not None:
            stmt = stmt.where(TradeRow.proceeds == proceeds)
        else:
            stmt = stmt.where(TradeRow.proceeds.is_(None))
        row = self._session.exec(stmt).first()
        if row is None:
            return None
        return _row_to_trade(row)

    def list_accounts(self) -> list[str]:
        rows = self._session.exec(
            select(distinct(TradeRow.account))
        ).all()
        return list(rows)

    def count_by_account(self, account: str) -> int:
        rows = self._session.exec(
            select(TradeRow).where(TradeRow.account == account)
        ).all()
        return len(rows)

    def latest_trade_date_by_account(self, account: str) -> Optional[str]:
        row = self._session.exec(
            select(TradeRow.date)
            .where(TradeRow.account == account)
            .order_by(TradeRow.date.desc())
        ).first()
        return row


class LotRepository:
    def __init__(self, session: Session):
        self._session = session

    def save(self, lot: Lot) -> None:
        row = _lot_to_row(lot)
        self._session.add(row)

    def save_batch(self, lots: list[Lot]) -> None:
        for lot in lots:
            self.save(lot)

    def list_all(self) -> list[Lot]:
        rows = self._session.exec(select(LotRow)).all()
        return [_row_to_lot(r) for r in rows]

    def delete_all(self) -> None:
        rows = self._session.exec(select(LotRow)).all()
        for row in rows:
            self._session.delete(row)


class ViolationRepository:
    def __init__(self, session: Session):
        self._session = session

    def save(self, violation: WashSaleViolation) -> None:
        row = _violation_to_row(violation)
        self._session.add(row)

    def save_batch(self, violations: list[WashSaleViolation]) -> None:
        for v in violations:
            self.save(v)

    def list_all(self) -> list[WashSaleViolation]:
        rows = self._session.exec(select(WashSaleViolationRow)).all()
        return [_row_to_violation(r) for r in rows]

    def delete_all(self) -> None:
        rows = self._session.exec(select(WashSaleViolationRow)).all()
        for row in rows:
            self._session.delete(row)


class SchemaCacheRepository:
    def __init__(self, session: Session):
        self._session = session

    def save(self, row: SchemaCacheRow) -> None:
        self._session.add(row)

    def find_by_broker_and_hash(
        self, broker_name: str, header_hash: str
    ) -> Optional[SchemaCacheRow]:
        return self._session.exec(
            select(SchemaCacheRow).where(
                SchemaCacheRow.broker_name == broker_name,
                SchemaCacheRow.header_hash == header_hash,
            )
        ).first()

    def list_by_broker(self, broker_name: str) -> list[SchemaCacheRow]:
        rows = self._session.exec(
            select(SchemaCacheRow).where(SchemaCacheRow.broker_name == broker_name)
        ).all()
        return list(rows)


# --- Mapping functions: domain ↔ table ---


def _trade_to_row(trade: Trade) -> TradeRow:
    row = TradeRow(
        id=trade.id,
        account=trade.account,
        date=trade.date.isoformat(),
        ticker=trade.ticker,
        action=trade.action,
        quantity=trade.quantity,
        proceeds=trade.proceeds,
        cost_basis=trade.cost_basis,
        basis_unknown=trade.basis_unknown,
        raw_row_hash=trade.raw_row_hash,
        schema_cache_id=trade.schema_cache_id,
    )
    if trade.option_details:
        row.option_strike = trade.option_details.strike
        row.option_expiry = trade.option_details.expiry.isoformat()
        row.option_call_put = trade.option_details.call_put
    return row


def _row_to_trade(row: TradeRow) -> Trade:
    option_details = None
    if row.option_strike is not None and row.option_call_put is not None:
        option_details = OptionDetails(
            strike=row.option_strike,
            expiry=date.fromisoformat(row.option_expiry),
            call_put=row.option_call_put,
        )
    return Trade(
        id=row.id,
        account=row.account,
        date=date.fromisoformat(row.date),
        ticker=row.ticker,
        action=row.action,
        quantity=row.quantity,
        proceeds=row.proceeds,
        cost_basis=row.cost_basis,
        basis_unknown=row.basis_unknown,
        option_details=option_details,
        raw_row_hash=row.raw_row_hash,
        schema_cache_id=row.schema_cache_id,
    )


def _lot_to_row(lot: Lot) -> LotRow:
    row = LotRow(
        id=lot.id,
        trade_id=lot.trade_id,
        account=lot.account,
        date=lot.date.isoformat(),
        ticker=lot.ticker,
        quantity=lot.quantity,
        cost_basis=lot.cost_basis,
        adjusted_basis=lot.adjusted_basis,
    )
    if lot.option_details:
        row.option_strike = lot.option_details.strike
        row.option_expiry = lot.option_details.expiry.isoformat()
        row.option_call_put = lot.option_details.call_put
    return row


def _row_to_lot(row: LotRow) -> Lot:
    option_details = None
    if row.option_strike is not None and row.option_call_put is not None:
        option_details = OptionDetails(
            strike=row.option_strike,
            expiry=date.fromisoformat(row.option_expiry),
            call_put=row.option_call_put,
        )
    return Lot(
        id=row.id,
        trade_id=row.trade_id,
        account=row.account,
        date=date.fromisoformat(row.date),
        ticker=row.ticker,
        quantity=row.quantity,
        cost_basis=row.cost_basis,
        adjusted_basis=row.adjusted_basis,
        option_details=option_details,
    )


def _violation_to_row(v: WashSaleViolation) -> WashSaleViolationRow:
    return WashSaleViolationRow(
        id=v.id,
        loss_trade_id=v.loss_trade_id,
        replacement_trade_id=v.replacement_trade_id,
        confidence=v.confidence,
        disallowed_loss=v.disallowed_loss,
        matched_quantity=v.matched_quantity,
    )


def _row_to_violation(row: WashSaleViolationRow) -> WashSaleViolation:
    return WashSaleViolation(
        id=row.id,
        loss_trade_id=row.loss_trade_id,
        replacement_trade_id=row.replacement_trade_id,
        confidence=row.confidence,
        disallowed_loss=row.disallowed_loss,
        matched_quantity=row.matched_quantity,
    )
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/db/test_repository.py -v`
Expected: All 7 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_repository.py
git commit -m "feat: add repositories with domain ↔ table mapping"
```

---

### Task 6: Lot and Violation Repository Tests

**Files:**
- Modify: `tests/db/test_repository.py`

- [ ] **Step 1: Write the tests for LotRepository and ViolationRepository**

```python
# append to tests/db/test_repository.py
from net_alpha.db.repository import LotRepository, ViolationRepository, SchemaCacheRepository
from net_alpha.db.tables import SchemaCacheRow
from net_alpha.models.domain import Lot, WashSaleViolation


def test_lot_save_and_list(db_session):
    repo = LotRepository(db_session)
    lot = Lot(
        trade_id="t1",
        account="Schwab",
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=10.0,
        cost_basis=2400.0,
        adjusted_basis=3600.0,
    )
    repo.save(lot)
    db_session.commit()

    lots = repo.list_all()
    assert len(lots) == 1
    assert lots[0].adjusted_basis == 3600.0


def test_violation_save_and_list(db_session):
    repo = ViolationRepository(db_session)
    v = WashSaleViolation(
        loss_trade_id="t1",
        replacement_trade_id="t2",
        confidence="Confirmed",
        disallowed_loss=1200.0,
        matched_quantity=10.0,
    )
    repo.save(v)
    db_session.commit()

    violations = repo.list_all()
    assert len(violations) == 1
    assert violations[0].confidence == "Confirmed"


def test_violation_delete_all(db_session):
    repo = ViolationRepository(db_session)
    repo.save(WashSaleViolation(
        loss_trade_id="t1", replacement_trade_id="t2",
        confidence="Confirmed", disallowed_loss=100.0, matched_quantity=1.0,
    ))
    repo.save(WashSaleViolation(
        loss_trade_id="t3", replacement_trade_id="t4",
        confidence="Probable", disallowed_loss=200.0, matched_quantity=2.0,
    ))
    db_session.commit()
    assert len(repo.list_all()) == 2

    repo.delete_all()
    db_session.commit()
    assert len(repo.list_all()) == 0


def test_schema_cache_save_and_find(db_session):
    repo = SchemaCacheRepository(db_session)
    row = SchemaCacheRow(
        id="sc1",
        broker_name="schwab",
        header_hash="sha256abc",
        column_mapping='{"date": "Date"}',
        option_format="schwab_human",
    )
    repo.save(row)
    db_session.commit()

    found = repo.find_by_broker_and_hash("schwab", "sha256abc")
    assert found is not None
    assert found.option_format == "schwab_human"

    assert repo.find_by_broker_and_hash("schwab", "other_hash") is None
```

- [ ] **Step 2: Run tests to verify they pass**

Run: `uv run pytest tests/db/test_repository.py -v`
Expected: All 11 tests PASS

- [ ] **Step 3: Run the full test suite**

Run: `uv run pytest -v`
Expected: All tests PASS

- [ ] **Step 4: Run linter**

Run: `make check`
Expected: Clean

- [ ] **Step 5: Commit**

```bash
git add tests/db/test_repository.py
git commit -m "test: add Lot, Violation, and SchemaCache repository tests"
```
