# README.md Overhaul Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Transform the project's README into a high-impact, "star-worthy" page that balances modern FinTech aesthetics with technical depth and privacy-first design.

**Architecture:** Use GitHub-flavored Markdown with a "Hero Hybrid" structure: high-impact branding, a clear 4-step workflow walkthrough, and a technical deep-dive into the privacy-first architecture.

**Tech Stack:** GitHub Markdown, ASCII Art, Badge icons.

---

### Task 1: Create the "Hero" Header & Value Proposition

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Replace the top section with the Hero Header**
  Overwrite the top of the file with the new ASCII banner and "3-column" value prop.

```markdown
# net-alpha

```text
  _   _  _____ _____         ___   _     ____  _   _    _    
 | \ | || ____|_   _|       / _ \ | |   |  _ \| | | |  / \   
 |  \| ||  _|   | |   _____| |_| || |   | |_) | |_| | / _ \  
 | |\  || |___  | |  |_____|  _  || |___|  __/|  _  |/ ___ \ 
 |_| \_||_____| |_|        |_| |_||_____|_|   |_| |_/_/   \_\
```

> **The only open-source tool that detects wash sales across multiple brokerage accounts — including options and ETFs.**

---

### 🤖 AI-Powered Import
Claude automatically detects your broker's CSV layout. No more manual column mapping or broken parsers.

### 🌐 Cross-Account View
Matches a Schwab loss sale against a Robinhood repurchase in a single pass. Total visibility across your portfolio.

### 🔒 100% Local & Private
Your trade data never leaves your machine. No cloud, no tracking, no telemetry. Zero-knowledge by design.

---

[![CI](https://github.com/chen-star/net_alpha/actions/workflows/ci.yml/badge.svg)](https://github.com/chen-star/net_alpha/actions/workflows/ci.yml)
[![PyPI version](https://badge.fury.io/py/wash-alpha.svg)](https://pypi.org/project/wash-alpha/)
[![codecov](https://codecov.io/github/chen-star/net_alpha/graph/badge.svg?token=XETFUGJO3L)](https://codecov.io/github/chen-star/net_alpha)
```

- [ ] **Step 2: Commit changes**

```bash
git add README.md
git commit -m "docs: add hero header and value prop to README"
```

---

### Task 2: Implement the "Modern Workflow" Walkthrough

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Add the 4-step workflow walkthrough**
  This section replaces the "Features" and "Quick Start" lists with a cohesive narrative.

```markdown
## The Workflow

Get from raw CSVs to a tax-ready report in seconds.

### 1. 📂 Smart Import
Claude detects your broker's schema. Confirm once, and it's cached forever for fully offline subsequent imports.

```bash
net-alpha import schwab   schwab_2024.csv
net-alpha import robinhood rh_2024.csv
```

### 2. 🔍 Cross-Account Check
Scan all accounts together. `net-alpha` detects wash sales across different brokers, assets (Equities/Options/ETFs), and dates.

```bash
net-alpha check
```

### 3. 🧪 Sell Simulator
Planning a trade? Test it against your current holdings and recent buys before you place the order.

```bash
net-alpha simulate sell TSLA 10 --price 185.50
```

### 4. 📄 Tax-Ready Reporting
Generate a summary for your accountant or tax software with adjusted cost basis tracking.

```bash
net-alpha report --year 2024
```
```

- [ ] **Step 2: Commit changes**

```bash
git add README.md
git commit -m "docs: add modern workflow walkthrough to README"
```

---

### Task 3: Add Technical Deep-Dive & Privacy Architecture

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Add "Zero-Knowledge Architecture" and "The Stack" sections**
  This section builds trust with technical users.

```markdown
## Under the Hood

### 🛡️ Zero-Knowledge Privacy
We believe your financial data is your business.
- **Local-First:** All trades are stored in a local SQLite database (`~/.net_alpha/net_alpha.db`).
- **Anonymized AI:** For schema detection, we only send CSV headers and 3 fake, anonymized sample rows to Claude. No account numbers, no real dollar amounts.
- **Offline Core:** Once a schema is mapped, the entire detection engine runs 100% offline.

### 🛠️ Modern Tech Stack
Built with the latest Python ecosystem for speed and reliability:
- **Python 3.11+** with strict Pydantic v2 typing.
- **Typer & Rich** for a premium, color-coded terminal UX.
- **SQLModel** (Pydantic + SQLAlchemy) for local relational storage.
- **uv** for ultra-fast, reproducible builds.

### ⚙️ Extensibility
Add your own substantially-identical security pairs (e.g., custom ETF pairs) in `~/.net_alpha/etf_pairs.yaml`.

```yaml
# Example: Custom ETF matching
- SPY, VOO, IVV, SPLG
- QQQ, QQQM
```
```

- [ ] **Step 2: Commit changes**

```bash
git add README.md
git commit -m "docs: add technical deep-dive and privacy section to README"
```

---

### Task 4: Final Cleanup & Verification

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Combine and polish the final README**
  Ensure the "Problem", "Installation", "Wash Sale Detection" (tables), and "Disclaimer" sections from the original README are preserved and integrated seamlessly into the new structure.

- [ ] **Step 2: Verify all links and badges**
  Check that CI, PyPI, and Codecov links are correct.

- [ ] **Step 3: Commit final polish**

```bash
git add README.md
git commit -m "docs: final polish of README overhaul"
```
