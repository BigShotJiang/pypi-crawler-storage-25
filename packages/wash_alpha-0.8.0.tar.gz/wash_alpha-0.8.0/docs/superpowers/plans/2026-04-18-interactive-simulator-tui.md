# Interactive Simulator TUI Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a Textual-based Interactive Tax Command Center that provides real-time wash sale simulations as users draft trades.

**Architecture:** A split-pane Textual App containing a Holdings `DataTable` and a Simulator `Input Form`. The Simulator dynamically constructs a virtual `Trade` object and passes it along with the user's database trades to the core `detect_wash_sales` engine, reacting on debounced keystrokes to display wash sale warnings and disallowed loss amounts.

**Tech Stack:** Python 3.11+, Textual, SQLModel, Typer

---

### Task 1: Add Textual Dependency

**Files:**
- Modify: `pyproject.toml`
- Modify: `uv.lock` (implied by uv sync)

- [ ] **Step 1: Run uv add textual**

```bash
uv add textual
```

- [ ] **Step 2: Commit**

```bash
git add pyproject.toml uv.lock
git commit -m "chore: add textual dependency for TUI"
```

---

### Task 2: Scaffold TUI Core App & Typer Command

**Files:**
- Create: `src/net_alpha/tui/__init__.py`
- Create: `src/net_alpha/tui/app.py`
- Modify: `src/net_alpha/cli/app.py`

- [ ] **Step 1: Write TUI App foundation**

```python
# src/net_alpha/tui/app.py
from textual.app import App, ComposeResult
from textual.widgets import Header, Footer

class NetAlphaTUI(App):
    """Main TUI application for net-alpha."""
    
    TITLE = "net-alpha"
    SUB_TITLE = "Cross-Account Wash Sale Detector"
    
    BINDINGS = [
        ("q", "quit", "Quit"),
    ]

    def compose(self) -> ComposeResult:
        yield Header()
        yield Footer()
```

- [ ] **Step 2: Register TUI command in CLI**

```python
# Modify src/net_alpha/cli/app.py
# Add the following command definition above `def _bootstrap():`
@app.command(name="tui")
def tui_command():
    """Launch the interactive dashboard and simulator."""
    from net_alpha.tui.app import NetAlphaTUI
    tui_app = NetAlphaTUI()
    tui_app.run()
```

- [ ] **Step 3: Run app to verify it launches and exits**

Run: `uv run net-alpha tui` (press 'q' to exit). Check that it doesn't crash.

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/tui src/net_alpha/cli/app.py
git commit -m "feat(tui): scaffold base textual app and cli command"
```

---

### Task 3: Build the Dashboard Screen Layout

**Files:**
- Create: `src/net_alpha/tui/screens/__init__.py`
- Create: `src/net_alpha/tui/screens/dashboard.py`
- Create: `src/net_alpha/tui/styles.tcss`
- Modify: `src/net_alpha/tui/app.py`

- [ ] **Step 1: Write styles**

```css
# src/net_alpha/tui/styles.tcss
Screen {
    layout: horizontal;
}

#holdings-pane {
    width: 60%;
    height: 100%;
    border-right: solid green;
}

#simulator-pane {
    width: 40%;
    height: 100%;
    padding: 1;
}

.warning {
    color: orange;
}
.error {
    color: red;
}
.safe {
    color: green;
}
```

- [ ] **Step 2: Write Dashboard Screen with placeholders**

```python
# src/net_alpha/tui/screens/dashboard.py
from textual.app import ComposeResult
from textual.containers import Container, Vertical
from textual.screen import Screen
from textual.widgets import DataTable, Input, Label, Select

class DashboardScreen(Screen):
    """Split-pane view for holdings and simulator."""
    
    def compose(self) -> ComposeResult:
        with Container(id="holdings-pane"):
            yield Label("Portfolio Holdings")
            yield DataTable(id="holdings-table")
            
        with Vertical(id="simulator-pane"):
            yield Label("Draft Trade Simulator", classes="section-title")
            yield Input(placeholder="Ticker (e.g. TSLA)", id="sim-ticker")
            yield Select([("Sell", "Sell"), ("Buy", "Buy")], prompt="Action", id="sim-action")
            yield Input(placeholder="Quantity", id="sim-quantity")
            yield Input(placeholder="Price", id="sim-price")
            yield Input(placeholder="Date (YYYY-MM-DD)", id="sim-date")
            yield Label("Status: Pending", id="sim-status")
```

- [ ] **Step 3: Wire screen to App**

```python
# Modify src/net_alpha/tui/app.py
from textual.app import App, ComposeResult
from textual.widgets import Header, Footer
from net_alpha.tui.screens.dashboard import DashboardScreen

class NetAlphaTUI(App):
    TITLE = "net-alpha"
    SUB_TITLE = "Cross-Account Wash Sale Detector"
    CSS_PATH = "styles.tcss"
    
    BINDINGS = [
        ("q", "quit", "Quit"),
    ]

    def on_mount(self) -> None:
        self.push_screen(DashboardScreen())
```

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/tui
git commit -m "feat(tui): build split-pane dashboard layout"
```

---

### Task 4: Load Database Holdings

**Files:**
- Modify: `src/net_alpha/tui/screens/dashboard.py`
- Modify: `src/net_alpha/tui/app.py`
- Modify: `src/net_alpha/cli/app.py`

- [ ] **Step 1: Pass DB session/trades to TUI App**

```python
# Modify src/net_alpha/cli/app.py:tui_command
@app.command(name="tui")
def tui_command():
    """Launch the interactive dashboard and simulator."""
    from net_alpha.tui.app import NetAlphaTUI
    from net_alpha.cli.app import _bootstrap
    from net_alpha.db.repository import TradeRepository
    
    settings, session = _bootstrap()
    try:
        repo = TradeRepository(session)
        trades = repo.list_all()
        tui_app = NetAlphaTUI(trades=trades, etf_pairs=settings.etf_pairs)
        tui_app.run()
    finally:
        session.close()
```

- [ ] **Step 2: Update App constructor**

```python
# Modify src/net_alpha/tui/app.py:NetAlphaTUI
from net_alpha.models.domain import Trade

class NetAlphaTUI(App):
    # ... existing class vars ...

    def __init__(self, trades: list[Trade] = None, etf_pairs: dict[str, list[str]] = None, **kwargs):
        super().__init__(**kwargs)
        self.trades = trades or []
        self.etf_pairs = etf_pairs or {}
```

- [ ] **Step 3: Populate DataTable on Mount**

```python
# Modify src/net_alpha/tui/screens/dashboard.py:DashboardScreen
from textual.widgets import DataTable
from textual import work

class DashboardScreen(Screen):
    # ... existing code ...
    
    def on_mount(self) -> None:
        table = self.query_one("#holdings-table", DataTable)
        table.add_columns("Date", "Account", "Action", "Ticker", "Qty")
        self.load_trades()

    @work
    async def load_trades(self) -> None:
        table = self.query_one("#holdings-table", DataTable)
        trades = self.app.trades
        
        if not trades:
            self.query_one("#holdings-pane").mount(Label("No trade data found. Press 'i' to import."))
            # Disable simulator
            for input_widget in self.query(Input):
                input_widget.disabled = True
            return
            
        for t in trades:
            table.add_row(str(t.date), t.account, t.action, t.ticker, str(t.quantity))
```

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/tui src/net_alpha/cli
git commit -m "feat(tui): load and display database trades in DataTable"
```

---

### Task 5: Implement Simulation Engine logic

**Files:**
- Create: `src/net_alpha/tui/simulator.py`

- [ ] **Step 1: Write simulation helper function**

```python
# src/net_alpha/tui/simulator.py
from datetime import date
from net_alpha.models.domain import Trade, DetectionResult
from net_alpha.engine.detector import detect_wash_sales

def simulate_trade(
    existing_trades: list[Trade],
    etf_pairs: dict[str, list[str]],
    action: str,
    ticker: str,
    quantity: float,
    price: float,
    trade_date: date
) -> tuple[bool, DetectionResult | None, str | None]:
    """
    Simulates a trade and returns (success, result, error_msg).
    success is False if inputs are invalid.
    """
    try:
        # Create virtual trade
        virtual_trade = Trade(
            account="SIMULATION",
            date=trade_date,
            ticker=ticker.upper(),
            action=action.capitalize(),
            quantity=quantity,
            proceeds=quantity * price if action.lower() == "sell" else None,
            cost_basis=(quantity * price) + 100.0 if action.lower() == "sell" else None, # Simulate a loss for sells
        )
        
        combined_trades = existing_trades + [virtual_trade]
        result = detect_wash_sales(combined_trades, etf_pairs)
        return True, result, None
    except Exception as e:
        return False, None, str(e)
```

- [ ] **Step 2: Commit**

```bash
git add src/net_alpha/tui/simulator.py
git commit -m "feat(tui): add simulation engine helper"
```

---

### Task 6: Wire Simulator UI to Engine (Reactivity)

**Files:**
- Modify: `src/net_alpha/tui/screens/dashboard.py`

- [ ] **Step 1: Add reactive event handlers**

```python
# Modify src/net_alpha/tui/screens/dashboard.py
from datetime import date
from textual import on
from textual.widgets import Input, Select
from net_alpha.tui.simulator import simulate_trade

class DashboardScreen(Screen):
    # ... existing code ...

    @on(Input.Changed)
    @on(Select.Changed)
    def on_input_changed(self) -> None:
        self.run_simulation()

    def run_simulation(self) -> None:
        status_label = self.query_one("#sim-status", Label)
        
        # Read inputs
        ticker = self.query_one("#sim-ticker", Input).value
        action = self.query_one("#sim-action", Select).value
        qty_str = self.query_one("#sim-quantity", Input).value
        price_str = self.query_one("#sim-price", Input).value
        date_str = self.query_one("#sim-date", Input).value

        # Basic validation
        if not all([ticker, action, qty_str, price_str, date_str]):
            status_label.update("Status: Waiting for input...")
            status_label.set_classes("")
            return

        try:
            qty = float(qty_str)
            price = float(price_str)
            trade_date = date.fromisoformat(date_str)
        except ValueError:
            status_label.update("Status: Invalid quantity, price, or date format.")
            status_label.set_classes("error")
            return

        # Run engine
        success, result, error = simulate_trade(
            self.app.trades, 
            self.app.etf_pairs, 
            str(action), 
            ticker, 
            qty, 
            price, 
            trade_date
        )

        if not success:
            status_label.update(f"Status: Error - {error}")
            status_label.set_classes("error")
            return

        # Parse results looking for our SIMULATION trade
        sim_violations = [v for v in result.violations if v.loss_trade_id != ""] 
        # Actually, our virtual trade ID is a generated UUID.
        # But we know any wash sale involving it means we have a hit.
        # For a more robust check, we should identify the virtual trade.
        
        # To keep it simple for this task: if the total violations increased 
        # compared to a baseline, it's a wash sale.
        # Alternatively, we just check if ANY violation has a replacement_trade_id 
        # matching our existing trades within the 30 day window.
        
        # Let's count violations
        if len(result.violations) > 0:
            # We assume it triggered a wash sale for demo purposes, 
            # realistic logic would check if virtual_trade.id is in violations
            status_label.update("⚠️ Wash Sale Triggered!")
            status_label.set_classes("warning")
        else:
            status_label.update("✅ Safe to Trade")
            status_label.set_classes("safe")
```

- [ ] **Step 2: Commit**

```bash
git add src/net_alpha/tui/screens/dashboard.py
git commit -m "feat(tui): wire reactive inputs to simulation engine"
```

---

### Task 7: Refine Wash Sale Detection Logic for Virtual Trade

**Files:**
- Modify: `src/net_alpha/tui/simulator.py`
- Modify: `src/net_alpha/tui/screens/dashboard.py`

- [ ] **Step 1: Fix ID tracking in Simulator**

```python
# Modify src/net_alpha/tui/simulator.py
def simulate_trade(
    existing_trades: list[Trade],
    etf_pairs: dict[str, list[str]],
    action: str,
    ticker: str,
    quantity: float,
    price: float,
    trade_date: date
) -> tuple[bool, DetectionResult | None, str | None, str | None]:
    # Return virtual_trade.id as 4th element
    try:
        virtual_trade = Trade(
            account="SIMULATION",
            date=trade_date,
            ticker=ticker.upper(),
            action=action.capitalize(),
            quantity=quantity,
            proceeds=quantity * price if action.lower() == "sell" else None,
            cost_basis=(quantity * price) + 100.0 if action.lower() == "sell" else None,
        )
        combined_trades = existing_trades + [virtual_trade]
        result = detect_wash_sales(combined_trades, etf_pairs)
        return True, result, None, virtual_trade.id
    except Exception as e:
        return False, None, str(e), None
```

- [ ] **Step 2: Update UI to check specific ID**

```python
# Modify src/net_alpha/tui/screens/dashboard.py
        success, result, error, virtual_id = simulate_trade(
            self.app.trades, 
            self.app.etf_pairs, 
            str(action), 
            ticker, 
            qty, 
            price, 
            trade_date
        )
        
        # ... validation checks ...

        sim_violations = [v for v in result.violations if v.loss_trade_id == virtual_id or v.replacement_trade_id == virtual_id]

        if sim_violations:
            disallowed = sum(v.disallowed_loss for v in sim_violations)
            confidence = sim_violations[0].confidence
            
            if confidence == "Confirmed":
                status_label.update(f"❌ Wash Sale! Disallowed: ${disallowed:,.2f}")
                status_label.set_classes("error")
            else:
                status_label.update(f"⚠️ {confidence} Wash Sale! Disallowed: ${disallowed:,.2f}")
                status_label.set_classes("warning")
        else:
            status_label.update("✅ Safe to Trade")
            status_label.set_classes("safe")
```

- [ ] **Step 3: Run the app and verify input triggers color changes**

Run: `uv run net-alpha tui`

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/tui/
git commit -m "feat(tui): accurately track and display virtual trade wash sales"
```

---
