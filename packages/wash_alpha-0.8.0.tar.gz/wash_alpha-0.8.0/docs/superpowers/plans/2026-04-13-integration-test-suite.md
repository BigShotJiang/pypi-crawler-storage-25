# Integration Test Suite Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a two-tier integration test suite (CLI + engine) covering all critical user flows and wash sale edge cases, using a real temp SQLite DB and mocked LLM.

**Architecture:** `tests/integration/` with two sub-packages: `cli/` (CliRunner + patched `_bootstrap`) and `engine/` (direct function calls). A shared `conftest.py` provides `temp_db`, `mock_llm`, and CSV fixtures. No new production code needed — these tests exercise existing code.

**Tech Stack:** pytest, typer.testing.CliRunner, unittest.mock.MagicMock, sqlmodel.Session, factory_boy (existing), pyyaml

---

### Key implementation facts (read before starting)

- **`ImportContext` fields:** `csv_path`, `broker_name`, `anthropic_client`, `model`, `max_retries`, `confirm_schema` (callable), `trade_repo`, `schema_cache_repo`, `session`
- **`ImportResult` fields:** `total_parsed`, `new_imported`, `duplicates_skipped`, `equities`, `options`, `etfs`
- **`import_command`** creates `Anthropic(api_key=...)` inline → patch `net_alpha.cli.import_cmd.Anthropic`
- **`import_command`** calls `questionary.confirm(...).ask()` → monkeypatch `net_alpha.cli.import_cmd.questionary` to return mock that returns `True`; broker name is lowercased (`broker.lower()`)
- **`check_command` and `report_command`** run `detect_wash_sales` fresh — seed raw trades, NOT pre-baked violations
- **`rebuys_command`** reads violations from DB directly — seed violation rows
- **`_bootstrap`** is imported inside each command body as `from net_alpha.cli.app import _bootstrap` → patch `net_alpha.cli.app._bootstrap`
- **Staleness warning** fires when `latest_trade_date_by_account > 30 days ago` — seed old trades to trigger it
- **CSV export headers:** `Date, Ticker, Account, Type, Loss, Confidence, Disallowed, Replacement Date, Replacement Account`
- **`load_etf_pairs`** lives in `net_alpha.engine.etf_pairs`

---

### Task 1: Scaffold directory structure + shared conftest

**Files:**
- Create: `tests/integration/__init__.py`
- Create: `tests/integration/engine/__init__.py`
- Create: `tests/integration/cli/__init__.py`
- Create: `tests/integration/conftest.py`

- [ ] **Step 1: Create `__init__.py` files**

```bash
touch tests/integration/__init__.py tests/integration/engine/__init__.py tests/integration/cli/__init__.py
```

- [ ] **Step 2: Write `tests/integration/conftest.py`**

```python
"""Shared fixtures for all integration tests."""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest
import yaml
from sqlmodel import Session

from net_alpha.db.connection import get_engine, init_db, run_migrations
from net_alpha.db.repository import TradeRepository
from net_alpha.models.domain import Trade

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
FIXTURES_DIR = Path(__file__).parents[1] / "fixtures"
PROJECT_ROOT = Path(__file__).parents[2]


@pytest.fixture
def schwab_csv() -> Path:
    return FIXTURES_DIR / "schwab_sample.csv"


@pytest.fixture
def robinhood_csv() -> Path:
    return FIXTURES_DIR / "robinhood_sample.csv"


@pytest.fixture
def etf_pairs() -> dict[str, list[str]]:
    with open(PROJECT_ROOT / "etf_pairs.yaml") as f:
        return yaml.safe_load(f)


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------
@pytest.fixture
def temp_db(tmp_path):
    """Fresh isolated SQLite DB. Yields (engine, session, db_path)."""
    db_path = tmp_path / "test.db"
    engine = get_engine(str(db_path))
    init_db(engine)
    run_migrations(engine)
    with Session(engine) as session:
        yield engine, session, db_path


@pytest.fixture
def seeded_session(temp_db):
    """
    Factory fixture. Call the returned function with a list of Trade objects
    to persist them and get back the session.

    Usage::

        def test_foo(seeded_session):
            session = seeded_session([trade1, trade2])
            result = detect_wash_sales(session.exec(select(Trade)).all(), {})
    """
    engine, session, db_path = temp_db

    def _seed(trades: list[Trade]) -> Session:
        repo = TradeRepository(session)
        repo.save_batch(trades)
        session.commit()
        return session

    return _seed


# ---------------------------------------------------------------------------
# LLM mapping constants
# ---------------------------------------------------------------------------
SCHWAB_MAPPING = {
    "date": "Date",
    "ticker": "Symbol",
    "action": "Action",
    "quantity": "Quantity",
    "proceeds": "Amount",
    "cost_basis": "Cost Basis",
    "buy_values": ["Buy", "Reinvest"],
    "sell_values": ["Sell"],
    "option_format": "schwab_human",
}

ROBINHOOD_MAPPING = {
    "date": "Activity Date",
    "ticker": "Instrument",
    "action": "Trans Code",
    "quantity": "Quantity",
    "proceeds": "Amount",
    "cost_basis": None,
    "buy_values": ["Buy"],
    "sell_values": ["Sell"],
    "option_format": "robinhood_human",
}


def make_llm_response(mapping_dict: dict) -> MagicMock:
    """Build a mock Anthropic API response containing SchemaMapping JSON."""
    resp = MagicMock()
    resp.content = [MagicMock(text=json.dumps(mapping_dict))]
    return resp


# ---------------------------------------------------------------------------
# LLM mock (engine-tier tests: pass mock_client directly into ImportContext)
# ---------------------------------------------------------------------------
@pytest.fixture
def mock_anthropic_client() -> MagicMock:
    """
    A bare MagicMock Anthropic client for use in engine-tier tests.
    Set .messages.create.return_value = make_llm_response(MAPPING) before use.
    Does NOT patch any module — callers pass this directly into ImportContext.
    """
    return MagicMock()
```

- [ ] **Step 3: Verify import + collection**

```bash
uv run pytest tests/integration/ --collect-only -q
```

Expected output: `no tests ran` (0 items collected, no errors).

- [ ] **Step 4: Commit**

```bash
git add tests/integration/
git commit -m "test: scaffold integration test directory and shared conftest"
```

---

### Task 2: CLI conftest

**Files:**
- Create: `tests/integration/cli/conftest.py`

- [ ] **Step 1: Write `tests/integration/cli/conftest.py`**

```python
"""CLI-tier integration test fixtures."""
from __future__ import annotations

import pytest
from sqlmodel import Session
from typer.testing import CliRunner

from net_alpha.cli.app import app
from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db, run_migrations


@pytest.fixture
def cli_setup(tmp_path, monkeypatch):
    """
    Provides (runner, engine, settings) for CLI integration tests.

    Patches net_alpha.cli.app._bootstrap to return Settings pointing at
    tmp_path and a fresh Session on each call. Tests that need to pre-seed
    data should open their own Session(engine), save, commit, close — then
    invoke the CLI (which gets a fresh session via the patched _bootstrap).
    """
    db_path = tmp_path / "net_alpha.db"
    engine = get_engine(str(db_path))
    init_db(engine)
    run_migrations(engine)

    settings = Settings(data_dir=tmp_path, anthropic_api_key="test-key")

    def fake_bootstrap():
        return settings, Session(engine)

    monkeypatch.setattr("net_alpha.cli.app._bootstrap", fake_bootstrap)

    runner = CliRunner(mix_stderr=False)
    return runner, engine, settings
```

- [ ] **Step 2: Verify collection**

```bash
uv run pytest tests/integration/cli/ --collect-only -q
```

Expected: `no tests ran`, no errors.

- [ ] **Step 3: Commit**

```bash
git add tests/integration/cli/conftest.py
git commit -m "test: add CLI integration conftest with patched _bootstrap"
```

---

### Task 3: Engine — import pipeline tests

**Files:**
- Create: `tests/integration/engine/test_import_pipeline.py`

- [ ] **Step 1: Write `tests/integration/engine/test_import_pipeline.py`**

```python
"""Integration tests: CSV import pipeline with real temp DB."""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from sqlmodel import Session

from net_alpha.db.repository import SchemaCacheRepository, TradeRepository
from net_alpha.import_.csv_reader import compute_header_hash, get_headers_and_samples
from net_alpha.import_.importer import ImportContext, run_import

from tests.integration.conftest import (
    ROBINHOOD_MAPPING,
    SCHWAB_MAPPING,
    make_llm_response,
)


def _ctx(session, csv_path: Path, broker: str, mock_client) -> ImportContext:
    """Build a minimal ImportContext for engine-level import tests."""
    from net_alpha.db.repository import SchemaCacheRepository, TradeRepository
    return ImportContext(
        csv_path=csv_path,
        broker_name=broker,
        anthropic_client=mock_client,
        model="claude-3-5-haiku-latest",
        max_retries=1,
        confirm_schema=lambda mapping, headers: True,  # auto-confirm
        trade_repo=TradeRepository(session),
        schema_cache_repo=SchemaCacheRepository(session),
        session=session,
    )


# ---------------------------------------------------------------------------
# Schwab pipeline
# ---------------------------------------------------------------------------

def test_schwab_full_pipeline(temp_db, schwab_csv, mock_anthropic_client):
    """CSV import: 4 Trade rows written; option trade parsed correctly."""
    engine, session, _ = temp_db
    mock_anthropic_client.messages.create.return_value = make_llm_response(SCHWAB_MAPPING)

    result = run_import(_ctx(session, schwab_csv, "schwab", mock_anthropic_client))

    assert result.new_imported == 4
    assert result.duplicates_skipped == 0

    trades = TradeRepository(session).list_all()
    assert len(trades) == 4

    option_trade = next(t for t in trades if t.option_details is not None)
    assert option_trade.ticker == "TSLA"
    assert option_trade.option_details.call_put == "C"
    assert option_trade.option_details.strike == 250.0


# ---------------------------------------------------------------------------
# Robinhood pipeline
# ---------------------------------------------------------------------------

def test_robinhood_full_pipeline(temp_db, robinhood_csv, mock_anthropic_client):
    """CSV import: 4 trades written; robinhood_human option format cached."""
    engine, session, _ = temp_db
    mock_anthropic_client.messages.create.return_value = make_llm_response(ROBINHOOD_MAPPING)

    result = run_import(_ctx(session, robinhood_csv, "robinhood", mock_anthropic_client))

    assert result.new_imported == 4

    headers, _ = get_headers_and_samples(robinhood_csv)
    hash_ = compute_header_hash(headers)
    cached = SchemaCacheRepository(session).find_by_broker_and_hash("robinhood", hash_)
    assert cached is not None
    assert cached.option_format == "robinhood_human"


# ---------------------------------------------------------------------------
# Schema cache
# ---------------------------------------------------------------------------

def test_schema_cache_written_after_first_import(temp_db, schwab_csv, mock_anthropic_client):
    """Schema cache row written after first import."""
    engine, session, _ = temp_db
    mock_anthropic_client.messages.create.return_value = make_llm_response(SCHWAB_MAPPING)

    run_import(_ctx(session, schwab_csv, "schwab", mock_anthropic_client))

    headers, _ = get_headers_and_samples(schwab_csv)
    hash_ = compute_header_hash(headers)
    cached = SchemaCacheRepository(session).find_by_broker_and_hash("schwab", hash_)
    assert cached is not None
    assert json.loads(cached.column_mapping)["ticker"] == "Symbol"


def test_schema_cache_hit_skips_llm(temp_db, schwab_csv, mock_anthropic_client):
    """Second import of same broker+headers reads from cache; LLM called only once."""
    engine, session, _ = temp_db
    mock_anthropic_client.messages.create.return_value = make_llm_response(SCHWAB_MAPPING)

    run_import(_ctx(session, schwab_csv, "schwab", mock_anthropic_client))  # LLM called
    run_import(_ctx(session, schwab_csv, "schwab", mock_anthropic_client))  # cache hit

    assert mock_anthropic_client.messages.create.call_count == 1


# ---------------------------------------------------------------------------
# Deduplication
# ---------------------------------------------------------------------------

def test_dedup_hash_match(temp_db, schwab_csv, mock_anthropic_client):
    """Importing same CSV twice: second run reports 0 new, 4 skipped."""
    engine, session, _ = temp_db
    mock_anthropic_client.messages.create.return_value = make_llm_response(SCHWAB_MAPPING)

    first = run_import(_ctx(session, schwab_csv, "schwab", mock_anthropic_client))
    second = run_import(_ctx(session, schwab_csv, "schwab", mock_anthropic_client))

    assert first.new_imported == 4
    assert second.new_imported == 0
    assert second.duplicates_skipped == 4
    assert len(TradeRepository(session).list_all()) == 4


def test_cross_account_no_dedup(temp_db, schwab_csv, robinhood_csv, mock_anthropic_client):
    """Same ticker+date from different brokers: both stored (8 total)."""
    engine, session, _ = temp_db

    mock_anthropic_client.messages.create.return_value = make_llm_response(SCHWAB_MAPPING)
    run_import(_ctx(session, schwab_csv, "schwab", mock_anthropic_client))

    mock_anthropic_client.messages.create.return_value = make_llm_response(ROBINHOOD_MAPPING)
    run_import(_ctx(session, robinhood_csv, "robinhood", mock_anthropic_client))

    trades = TradeRepository(session).list_all()
    accounts = {t.account for t in trades}
    assert len(trades) == 8
    assert "schwab" in accounts
    assert "robinhood" in accounts
```

- [ ] **Step 2: Run tests**

```bash
uv run pytest tests/integration/engine/test_import_pipeline.py -v
```

Expected: 6 tests pass. If `ImportContext` fields differ, inspect `src/net_alpha/import_/importer.py` and adjust.

- [ ] **Step 3: Commit**

```bash
git add tests/integration/engine/test_import_pipeline.py
git commit -m "test: add engine integration tests for import pipeline"
```

---

### Task 4: Engine — wash sale detector tests

**Files:**
- Create: `tests/integration/engine/test_wash_sale_engine.py`

- [ ] **Step 1: Write `tests/integration/engine/test_wash_sale_engine.py`**

```python
"""Integration tests: wash sale detection engine with real temp DB."""
from __future__ import annotations

from datetime import date
from uuid import uuid4

import pytest
from sqlmodel import Session

from net_alpha.db.repository import TradeRepository
from net_alpha.engine.detector import detect_wash_sales
from net_alpha.models.domain import OptionDetails, Trade


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _trade(
    ticker: str,
    action: str,
    trade_date: date,
    quantity: float,
    proceeds: float | None = None,
    cost_basis: float | None = None,
    account: str = "Schwab",
    option_details: OptionDetails | None = None,
    basis_unknown: bool = False,
) -> Trade:
    return Trade(
        id=str(uuid4()),
        account=account,
        date=trade_date,
        ticker=ticker,
        action=action,
        quantity=quantity,
        proceeds=proceeds,
        cost_basis=cost_basis,
        basis_unknown=basis_unknown,
        option_details=option_details,
    )


def _loss_sell(ticker, trade_date, quantity=10.0, proceeds=2000.0, cost_basis=3000.0, account="Schwab", **kw):
    return _trade(ticker, "Sell", trade_date, quantity, proceeds=proceeds, cost_basis=cost_basis, account=account, **kw)


def _buy(ticker, trade_date, quantity=10.0, cost_basis=2200.0, account="Schwab", **kw):
    return _trade(ticker, "Buy", trade_date, quantity, cost_basis=cost_basis, account=account, **kw)


def _run(temp_db, trades: list[Trade], etf_pairs: dict):
    """Save trades to real DB, reload them, run detect_wash_sales, return DetectionResult."""
    engine, session, _ = temp_db
    TradeRepository(session).save_batch(trades)
    session.commit()
    loaded = TradeRepository(session).list_all()
    return detect_wash_sales(loaded, etf_pairs)


# ---------------------------------------------------------------------------
# Basic confirmed equity wash sale
# ---------------------------------------------------------------------------

def test_equity_confirmed(temp_db, etf_pairs):
    """TSLA sell loss Jan 10 + TSLA buy Jan 15 → Confirmed, disallowed=$1000."""
    sell = _loss_sell("TSLA", date(2024, 1, 10))
    buy = _buy("TSLA", date(2024, 1, 15))

    result = _run(temp_db, [sell, buy], etf_pairs)

    assert len(result.violations) == 1
    v = result.violations[0]
    assert v.confidence == "Confirmed"
    assert v.disallowed_loss == pytest.approx(1000.0)


# ---------------------------------------------------------------------------
# Day-boundary tests
# ---------------------------------------------------------------------------

def test_day_30_boundary_inclusive(temp_db, etf_pairs):
    """Sell Jan 1, buy Jan 31 = exactly 30 days → violation (inclusive)."""
    result = _run(temp_db, [
        _loss_sell("AAPL", date(2024, 1, 1)),
        _buy("AAPL", date(2024, 1, 31)),
    ], etf_pairs)
    assert len(result.violations) == 1


def test_day_31_boundary_exclusive(temp_db, etf_pairs):
    """Sell Jan 1, buy Feb 1 = 31 days → no violation (exclusive)."""
    result = _run(temp_db, [
        _loss_sell("AAPL", date(2024, 1, 1)),
        _buy("AAPL", date(2024, 2, 1)),
    ], etf_pairs)
    assert len(result.violations) == 0


# ---------------------------------------------------------------------------
# Cross-year window
# ---------------------------------------------------------------------------

def test_cross_year_window(temp_db, etf_pairs):
    """Sell Dec 15 2024, buy Jan 5 2025 (21 days) → violation crosses year boundary."""
    result = _run(temp_db, [
        _loss_sell("MSFT", date(2024, 12, 15)),
        _buy("MSFT", date(2025, 1, 5)),
    ], etf_pairs)
    assert len(result.violations) == 1
    assert result.violations[0].confidence == "Confirmed"


# ---------------------------------------------------------------------------
# No violation cases
# ---------------------------------------------------------------------------

def test_no_violation_profit_sale(temp_db, etf_pairs):
    """Sell at profit (proceeds > cost_basis) + buy same week → no wash sale."""
    result = _run(temp_db, [
        _trade("TSLA", "Sell", date(2024, 1, 10), 10.0, proceeds=3500.0, cost_basis=2000.0),
        _buy("TSLA", date(2024, 1, 12)),
    ], etf_pairs)
    assert len(result.violations) == 0


def test_basis_unknown_not_matched(temp_db, etf_pairs):
    """Sell with basis_unknown=True + buy same week → no violation."""
    result = _run(temp_db, [
        _trade("TSLA", "Sell", date(2024, 1, 10), 10.0, proceeds=2000.0, basis_unknown=True),
        _buy("TSLA", date(2024, 1, 12)),
    ], etf_pairs)
    assert len(result.violations) == 0


# ---------------------------------------------------------------------------
# Cross-account
# ---------------------------------------------------------------------------

def test_equity_confirmed_cross_account(temp_db, etf_pairs):
    """TSLA sell Schwab + TSLA buy Robinhood, 5 days apart → Confirmed."""
    result = _run(temp_db, [
        _loss_sell("TSLA", date(2024, 1, 10), account="Schwab"),
        _buy("TSLA", date(2024, 1, 15), account="Robinhood"),
    ], etf_pairs)
    assert len(result.violations) == 1
    assert result.violations[0].confidence == "Confirmed"


# ---------------------------------------------------------------------------
# Confidence levels
# ---------------------------------------------------------------------------

def test_equity_to_call_probable(temp_db, etf_pairs):
    """TSLA equity sell loss + TSLA call buy 10 days later → Probable."""
    result = _run(temp_db, [
        _loss_sell("TSLA", date(2024, 1, 10)),
        _buy(
            "TSLA", date(2024, 1, 20),
            option_details=OptionDetails(strike=250.0, expiry=date(2024, 3, 15), call_put="C"),
        ),
    ], etf_pairs)
    assert len(result.violations) == 1
    assert result.violations[0].confidence == "Probable"


def test_sold_put_unclear(temp_db, etf_pairs):
    """TSLA equity sell loss + TSLA short put 5 days later → Unclear."""
    result = _run(temp_db, [
        _loss_sell("TSLA", date(2024, 1, 10)),
        _trade(
            "TSLA", "Sell", date(2024, 1, 15), 5.0,
            proceeds=300.0, cost_basis=0.0,
            option_details=OptionDetails(strike=240.0, expiry=date(2024, 3, 15), call_put="P"),
        ),
    ], etf_pairs)
    assert len(result.violations) == 1
    assert result.violations[0].confidence == "Unclear"


def test_etf_substantially_identical(temp_db, etf_pairs):
    """SPY sell loss + VOO buy 7 days later → Unclear (same sp500 group)."""
    result = _run(temp_db, [
        _loss_sell("SPY", date(2024, 1, 10)),
        _buy("VOO", date(2024, 1, 17)),
    ], etf_pairs)
    assert len(result.violations) == 1
    assert result.violations[0].confidence == "Unclear"


# ---------------------------------------------------------------------------
# Partial FIFO allocation
# ---------------------------------------------------------------------------

def test_partial_fifo_allocation(temp_db, etf_pairs):
    """
    Loss: 10 shares.
    Lot A (before sell): 4 shares → fully consumed.
    Lot B (after sell): 10 shares → 6 shares consumed.
    Total matched = 10 shares; matched_quantities = [4, 6].
    """
    sell = _loss_sell("TSLA", date(2024, 1, 10), quantity=10.0, proceeds=2000.0, cost_basis=3000.0)
    lot_a = _buy("TSLA", date(2024, 1, 5), quantity=4.0, cost_basis=880.0)   # before sell → FIFO first
    lot_b = _buy("TSLA", date(2024, 1, 15), quantity=10.0, cost_basis=2200.0) # after sell

    result = _run(temp_db, [sell, lot_a, lot_b], etf_pairs)

    assert len(result.violations) == 2
    total_matched = sum(v.matched_quantity for v in result.violations)
    assert total_matched == pytest.approx(10.0)
    quantities = sorted(v.matched_quantity for v in result.violations)
    assert quantities == pytest.approx([4.0, 6.0])


# ---------------------------------------------------------------------------
# Adjusted basis
# ---------------------------------------------------------------------------

def test_lot_adjusted_basis_updated(temp_db, etf_pairs):
    """
    Loss sale: 10 shares, $1000 loss.
    Replacement buy: cost_basis=$2200.
    After wash sale: replacement lot.adjusted_basis = 2200 + 1000 = 3200.
    """
    sell = _loss_sell("TSLA", date(2024, 1, 10), quantity=10.0, proceeds=2000.0, cost_basis=3000.0)
    buy = _buy("TSLA", date(2024, 1, 15), quantity=10.0, cost_basis=2200.0)

    result = _run(temp_db, [sell, buy], etf_pairs)

    assert len(result.violations) == 1
    assert result.violations[0].disallowed_loss == pytest.approx(1000.0)

    replacement_lot = next(
        lot for lot in result.lots
        if lot.trade_id == result.violations[0].replacement_trade_id
    )
    assert replacement_lot.adjusted_basis == pytest.approx(3200.0)


# ---------------------------------------------------------------------------
# Multiple loss sales: FIFO across shared lot pool
# ---------------------------------------------------------------------------

def test_multiple_loss_sales_fifo(temp_db, etf_pairs):
    """
    Two loss sales (Jan 5 and Jan 6), one shared buy lot (Jan 10, 10 shares).
    First loss by date (Jan 5) claims 6 shares; second (Jan 6) gets remaining 4.
    No lot allocated beyond its quantity.
    """
    sell1 = _loss_sell("TSLA", date(2024, 1, 5), quantity=6.0, proceeds=1200.0, cost_basis=1800.0)
    sell2 = _loss_sell("TSLA", date(2024, 1, 6), quantity=8.0, proceeds=1600.0, cost_basis=2400.0)
    shared_buy = _buy("TSLA", date(2024, 1, 10), quantity=10.0, cost_basis=2200.0)

    result = _run(temp_db, [sell1, sell2, shared_buy], etf_pairs)

    total_matched = sum(v.matched_quantity for v in result.violations)
    assert total_matched == pytest.approx(10.0)

    for lot in result.lots:
        allocated = sum(
            v.matched_quantity for v in result.violations
            if v.replacement_trade_id == lot.trade_id
        )
        assert allocated <= lot.quantity + 1e-9
```

- [ ] **Step 2: Run tests**

```bash
uv run pytest tests/integration/engine/test_wash_sale_engine.py -v
```

Expected: all 13 tests pass.

- [ ] **Step 3: Commit**

```bash
git add tests/integration/engine/test_wash_sale_engine.py
git commit -m "test: add engine integration tests for wash sale detector"
```

---

### Task 5: CLI — import tests

**Files:**
- Create: `tests/integration/cli/test_import.py`

- [ ] **Step 1: Write `tests/integration/cli/test_import.py`**

```python
"""CLI integration tests: net-alpha import command."""
from __future__ import annotations

from unittest.mock import MagicMock

import pytest
from sqlmodel import Session

from net_alpha.cli.app import app
from net_alpha.db.repository import TradeRepository

from tests.integration.conftest import ROBINHOOD_MAPPING, SCHWAB_MAPPING, make_llm_response

DISCLAIMER = "Consult a tax professional"


def _patch_import(monkeypatch, mock_client: MagicMock):
    """
    Patch the Anthropic class used by import_cmd so no real API calls are made.
    Also patch questionary.confirm so the schema confirmation returns True without
    waiting for stdin (CliRunner stdin injection is unreliable with questionary).
    """
    monkeypatch.setattr("net_alpha.cli.import_cmd.Anthropic", lambda **kwargs: mock_client)

    mock_q = MagicMock()
    mock_q.confirm.return_value.ask.return_value = True
    monkeypatch.setattr("net_alpha.cli.import_cmd.questionary", mock_q)


def test_schwab_import_llm_path(cli_setup, schwab_csv, monkeypatch):
    """Fresh DB, no cache: LLM called once, 4 trades imported, disclaimer shown."""
    runner, engine, _ = cli_setup
    mock_client = MagicMock()
    mock_client.messages.create.return_value = make_llm_response(SCHWAB_MAPPING)
    _patch_import(monkeypatch, mock_client)

    result = runner.invoke(app, ["import", "Schwab", str(schwab_csv)])

    assert result.exit_code == 0, result.output
    assert "4" in result.output
    assert DISCLAIMER in result.output
    assert mock_client.messages.create.call_count == 1

    with Session(engine) as s:
        assert len(TradeRepository(s).list_all()) == 4


def test_schwab_import_cache_hit(cli_setup, schwab_csv, monkeypatch):
    """Second import uses schema cache; LLM called only once total."""
    runner, engine, _ = cli_setup
    mock_client = MagicMock()
    mock_client.messages.create.return_value = make_llm_response(SCHWAB_MAPPING)
    _patch_import(monkeypatch, mock_client)

    runner.invoke(app, ["import", "Schwab", str(schwab_csv)])  # first: LLM called
    result = runner.invoke(app, ["import", "Schwab", str(schwab_csv)])  # second: cache hit

    assert result.exit_code == 0, result.output
    assert mock_client.messages.create.call_count == 1


def test_robinhood_import_llm_path(cli_setup, robinhood_csv, monkeypatch):
    """Robinhood CSV: LLM called, 4 trades imported, disclaimer shown."""
    runner, engine, _ = cli_setup
    mock_client = MagicMock()
    mock_client.messages.create.return_value = make_llm_response(ROBINHOOD_MAPPING)
    _patch_import(monkeypatch, mock_client)

    result = runner.invoke(app, ["import", "Robinhood", str(robinhood_csv)])

    assert result.exit_code == 0, result.output
    assert "4" in result.output
    assert DISCLAIMER in result.output


def test_duplicate_import_skips(cli_setup, schwab_csv, monkeypatch):
    """Import same CSV twice: second run shows duplicates skipped."""
    runner, engine, _ = cli_setup
    mock_client = MagicMock()
    mock_client.messages.create.return_value = make_llm_response(SCHWAB_MAPPING)
    _patch_import(monkeypatch, mock_client)

    runner.invoke(app, ["import", "Schwab", str(schwab_csv)])
    result = runner.invoke(app, ["import", "Schwab", str(schwab_csv)])

    assert result.exit_code == 0, result.output
    # Second run: new_imported=0, duplicates_skipped=4
    assert "duplicate" in result.output.lower() or "skipped" in result.output.lower()


def test_cross_account_same_ticker(cli_setup, schwab_csv, robinhood_csv, monkeypatch):
    """Schwab + Robinhood imports: DB holds 8 total trades across 2 accounts."""
    runner, engine, _ = cli_setup
    mock_client = MagicMock()
    _patch_import(monkeypatch, mock_client)

    mock_client.messages.create.return_value = make_llm_response(SCHWAB_MAPPING)
    r1 = runner.invoke(app, ["import", "Schwab", str(schwab_csv)])
    assert r1.exit_code == 0, r1.output

    mock_client.messages.create.return_value = make_llm_response(ROBINHOOD_MAPPING)
    r2 = runner.invoke(app, ["import", "Robinhood", str(robinhood_csv)])
    assert r2.exit_code == 0, r2.output

    with Session(engine) as s:
        trades = TradeRepository(s).list_all()
        accounts = {t.account for t in trades}
        assert len(trades) == 8
        assert "schwab" in accounts
        assert "robinhood" in accounts
```

- [ ] **Step 2: Run tests**

```bash
uv run pytest tests/integration/cli/test_import.py -v
```

Expected: 5 tests pass.

- [ ] **Step 3: Commit**

```bash
git add tests/integration/cli/test_import.py
git commit -m "test: add CLI integration tests for import command"
```

---

### Task 6: CLI — check tests

**Files:**
- Create: `tests/integration/cli/test_check.py`

Note: `check_command` runs `detect_wash_sales` fresh — seed raw trades (not pre-baked violations).

- [ ] **Step 1: Write `tests/integration/cli/test_check.py`**

```python
"""CLI integration tests: net-alpha check command."""
from __future__ import annotations

from datetime import date, timedelta
from uuid import uuid4

import pytest
from sqlmodel import Session

from net_alpha.cli.app import app
from net_alpha.db.repository import TradeRepository
from net_alpha.models.domain import Trade

DISCLAIMER = "Consult a tax professional"
THIS_YEAR = date.today().year


def _seed_wash_sale_trades(engine, ticker: str = "TSLA", year: int = THIS_YEAR, account: str = "Schwab"):
    """Seed a loss sale + replacement buy that the engine will classify as Confirmed."""
    with Session(engine) as s:
        TradeRepository(s).save_batch([
            Trade(
                id=str(uuid4()), account=account,
                date=date(year, 1, 10), ticker=ticker,
                action="Sell", quantity=10.0, proceeds=2000.0, cost_basis=3000.0,
            ),
            Trade(
                id=str(uuid4()), account=account,
                date=date(year, 1, 15), ticker=ticker,
                action="Buy", quantity=10.0, cost_basis=2200.0,
            ),
        ])
        s.commit()


def test_check_with_violations(cli_setup):
    """Seeded wash sale trades → check finds Confirmed violation, shows disclaimer."""
    runner, engine, _ = cli_setup
    _seed_wash_sale_trades(engine, ticker="TSLA")

    result = runner.invoke(app, ["check"])

    assert result.exit_code == 0, result.output
    assert "Confirmed" in result.output
    assert "TSLA" in result.output
    assert DISCLAIMER in result.output


def test_check_ticker_filter(cli_setup):
    """--ticker TSLA: AAPL violation not shown."""
    runner, engine, _ = cli_setup
    _seed_wash_sale_trades(engine, ticker="TSLA")
    _seed_wash_sale_trades(engine, ticker="AAPL")

    result = runner.invoke(app, ["check", "--ticker", "TSLA"])

    assert result.exit_code == 0, result.output
    assert "TSLA" in result.output
    assert "AAPL" not in result.output


def test_check_year_filter(cli_setup):
    """--year {THIS_YEAR}: next year's violations not shown."""
    runner, engine, _ = cli_setup
    next_year = THIS_YEAR + 1
    _seed_wash_sale_trades(engine, ticker="MSFT", year=THIS_YEAR)
    _seed_wash_sale_trades(engine, ticker="MSFT", year=next_year)

    result = runner.invoke(app, ["check", "--year", str(THIS_YEAR)])

    assert result.exit_code == 0, result.output
    assert str(THIS_YEAR) in result.output
    assert str(next_year) not in result.output


def test_check_no_data(cli_setup):
    """Empty DB: graceful 'no trades' message, exit 0. No disclaimer (early return)."""
    runner, engine, _ = cli_setup

    result = runner.invoke(app, ["check"])

    assert result.exit_code == 0, result.output
    assert "no trades" in result.output.lower() or "import" in result.output.lower()


def test_check_staleness_warning(cli_setup):
    """Account with latest trade > 30 days ago: staleness warning shown."""
    runner, engine, _ = cli_setup

    # Seed a buy from 35 days ago (stale data)
    with Session(engine) as s:
        TradeRepository(s).save(Trade(
            id=str(uuid4()), account="Schwab",
            date=date.today() - timedelta(days=35),
            ticker="TSLA", action="Buy", quantity=10.0, cost_basis=2200.0,
        ))
        s.commit()

    result = runner.invoke(app, ["check"])

    assert result.exit_code == 0, result.output
    # _print_staleness_warnings outputs: "⚠ {account} data last imported {days_ago} days ago."
    assert "days ago" in result.output
```

- [ ] **Step 2: Run tests**

```bash
uv run pytest tests/integration/cli/test_check.py -v
```

Expected: 5 tests pass.

- [ ] **Step 3: Commit**

```bash
git add tests/integration/cli/test_check.py
git commit -m "test: add CLI integration tests for check command"
```

---

### Task 7: CLI — simulate tests

**Files:**
- Create: `tests/integration/cli/test_simulate.py`

Note: `simulate sell` looks BACK only (before sell_date). Seed buy trades to trigger the look-back window.

- [ ] **Step 1: Write `tests/integration/cli/test_simulate.py`**

```python
"""CLI integration tests: net-alpha simulate sell command."""
from __future__ import annotations

from datetime import date, timedelta
from uuid import uuid4

import pytest
from sqlmodel import Session

from net_alpha.cli.app import app
from net_alpha.db.repository import TradeRepository
from net_alpha.models.domain import Trade

DISCLAIMER = "Consult a tax professional"
TODAY = date.today()


def _seed_buy(engine, ticker: str, days_ago: int, quantity: float = 10.0, cost_basis: float = 2500.0, account: str = "Schwab"):
    with Session(engine) as s:
        TradeRepository(s).save(Trade(
            id=str(uuid4()), account=account,
            date=TODAY - timedelta(days=days_ago),
            ticker=ticker, action="Buy", quantity=quantity, cost_basis=cost_basis,
        ))
        s.commit()


def test_simulate_safe(cli_setup):
    """No TSLA buys in last 30 days → 'Safe to sell' message."""
    runner, engine, _ = cli_setup
    _seed_buy(engine, "TSLA", days_ago=35)  # outside window

    result = runner.invoke(app, ["simulate", "sell", "TSLA", "10"])

    assert result.exit_code == 0, result.output
    assert "safe to sell" in result.output.lower()
    assert DISCLAIMER in result.output


def test_simulate_risky_no_price(cli_setup):
    """TSLA buy 5 days ago → wash sale warning and safe rebuy date shown."""
    runner, engine, _ = cli_setup
    _seed_buy(engine, "TSLA", days_ago=5)

    result = runner.invoke(app, ["simulate", "sell", "TSLA", "10"])

    assert result.exit_code == 0, result.output
    # "⚠ Wash sale would be triggered." and safe date
    assert "wash sale" in result.output.lower() or "triggered" in result.output.lower()
    safe_date = (TODAY - timedelta(days=5) + timedelta(days=30)).isoformat()
    assert safe_date in result.output
    assert DISCLAIMER in result.output


def test_simulate_risky_with_price(cli_setup):
    """TSLA buy 5 days ago at $250/share + --price 200 → disallowed loss shown."""
    runner, engine, _ = cli_setup
    # 10 shares at $250/share = cost_basis $2500
    _seed_buy(engine, "TSLA", days_ago=5, quantity=10.0, cost_basis=2500.0)

    result = runner.invoke(app, ["simulate", "sell", "TSLA", "10", "--price", "200"])

    assert result.exit_code == 0, result.output
    # Estimated disallowed: max(0, 2500 * 10/10 - 200*10) = max(0, 2500-2000) = $500
    assert "DISALLOWED" in result.output or "disallowed" in result.output.lower()
    assert DISCLAIMER in result.output


def test_simulate_etf_risky(cli_setup):
    """VOO buy 10 days ago; simulating SPY sell → Unclear ETF wash sale risk."""
    runner, engine, _ = cli_setup
    _seed_buy(engine, "VOO", days_ago=10)

    result = runner.invoke(app, ["simulate", "sell", "SPY", "10"])

    assert result.exit_code == 0, result.output
    # Confidence "Unclear" shown next to the VOO trigger
    assert "Unclear" in result.output
    assert DISCLAIMER in result.output
```

- [ ] **Step 2: Run tests**

```bash
uv run pytest tests/integration/cli/test_simulate.py -v
```

Expected: 4 tests pass.

- [ ] **Step 3: Commit**

```bash
git add tests/integration/cli/test_simulate.py
git commit -m "test: add CLI integration tests for simulate sell command"
```

---

### Task 8: CLI — rebuys tests

**Files:**
- Create: `tests/integration/cli/test_rebuys.py`

Note: `rebuys_command` reads violations from DB — seed loss trades + violation rows directly.

- [ ] **Step 1: Write `tests/integration/cli/test_rebuys.py`**

```python
"""CLI integration tests: net-alpha rebuys command."""
from __future__ import annotations

from datetime import date, timedelta
from uuid import uuid4

import pytest
from sqlmodel import Session

from net_alpha.cli.app import app
from net_alpha.db.repository import TradeRepository, ViolationRepository
from net_alpha.models.domain import Trade, WashSaleViolation

DISCLAIMER = "Consult a tax professional"
TODAY = date.today()


def _seed_loss(engine, ticker: str, sell_days_ago: int, quantity: float = 10.0) -> str:
    """Seed a loss sale trade. Returns the trade id."""
    trade_id = str(uuid4())
    sell_date = TODAY - timedelta(days=sell_days_ago)
    with Session(engine) as s:
        TradeRepository(s).save(Trade(
            id=trade_id, account="Schwab", date=sell_date,
            ticker=ticker, action="Sell", quantity=quantity,
            proceeds=quantity * 200.0, cost_basis=quantity * 300.0,
        ))
        s.commit()
    return trade_id


def _seed_violation(engine, loss_trade_id: str, matched_qty: float):
    """Seed a violation matching some quantity of the loss trade."""
    with Session(engine) as s:
        replace_id = str(uuid4())
        replace_date = TODAY - timedelta(days=5)
        TradeRepository(s).save(Trade(
            id=replace_id, account="Schwab", date=replace_date,
            ticker="X", action="Buy", quantity=matched_qty, cost_basis=matched_qty * 220.0,
        ))
        ViolationRepository(s).save(WashSaleViolation(
            id=str(uuid4()),
            loss_trade_id=loss_trade_id,
            replacement_trade_id=replace_id,
            confidence="Confirmed",
            disallowed_loss=matched_qty * 100.0,
            matched_quantity=matched_qty,
        ))
        s.commit()


def test_rebuys_open_window(cli_setup):
    """Loss sale 10 days ago, no match → ticker shown, 20 days remaining."""
    runner, engine, _ = cli_setup
    _seed_loss(engine, "TSLA", sell_days_ago=10)

    result = runner.invoke(app, ["rebuys"])

    assert result.exit_code == 0, result.output
    assert "TSLA" in result.output
    assert "20 days" in result.output
    assert DISCLAIMER in result.output


def test_rebuys_cleared_window(cli_setup):
    """Loss sale 35 days ago → window closed, AAPL not shown."""
    runner, engine, _ = cli_setup
    _seed_loss(engine, "AAPL", sell_days_ago=35)

    result = runner.invoke(app, ["rebuys"])

    assert result.exit_code == 0, result.output
    assert "AAPL" not in result.output


def test_rebuys_partial_match(cli_setup):
    """Loss 10 shares, 4 matched → '6/10' open qty shown."""
    runner, engine, _ = cli_setup
    loss_id = _seed_loss(engine, "MSFT", sell_days_ago=10, quantity=10.0)
    _seed_violation(engine, loss_id, matched_qty=4.0)

    result = runner.invoke(app, ["rebuys"])

    assert result.exit_code == 0, result.output
    assert "MSFT" in result.output
    assert "6/10" in result.output


def test_rebuys_empty(cli_setup):
    """No loss sales in open window → 'All clear' message, exit 0."""
    runner, engine, _ = cli_setup

    result = runner.invoke(app, ["rebuys"])

    assert result.exit_code == 0, result.output
    # rebuys_command prints: "No positions currently in wash sale window. All clear."
    assert "all clear" in result.output.lower() or "no positions" in result.output.lower()
    assert DISCLAIMER in result.output
```

- [ ] **Step 2: Run tests**

```bash
uv run pytest tests/integration/cli/test_rebuys.py -v
```

Expected: 4 tests pass.

- [ ] **Step 3: Commit**

```bash
git add tests/integration/cli/test_rebuys.py
git commit -m "test: add CLI integration tests for rebuys command"
```

---

### Task 9: CLI — report tests

**Files:**
- Create: `tests/integration/cli/test_report.py`

Note: `report_command` runs `detect_wash_sales` fresh — seed raw trades, not pre-baked violations. CSV headers: `Date, Ticker, Account, Type, Loss, Confidence, Disallowed, Replacement Date, Replacement Account`.

- [ ] **Step 1: Write `tests/integration/cli/test_report.py`**

```python
"""CLI integration tests: net-alpha report command."""
from __future__ import annotations

import csv
from datetime import date
from uuid import uuid4

import pytest
from sqlmodel import Session

from net_alpha.cli.app import app
from net_alpha.db.repository import TradeRepository
from net_alpha.models.domain import Trade

DISCLAIMER = "Consult a tax professional"


def _seed_wash_sale(engine, ticker: str, year: int, loss: float = 1000.0):
    """Seed a loss sale + replacement buy. Engine will detect as Confirmed."""
    with Session(engine) as s:
        TradeRepository(s).save_batch([
            Trade(
                id=str(uuid4()), account="Schwab",
                date=date(year, 6, 1), ticker=ticker,
                action="Sell", quantity=10.0,
                proceeds=2000.0, cost_basis=2000.0 + loss,
            ),
            Trade(
                id=str(uuid4()), account="Schwab",
                date=date(year, 6, 10), ticker=ticker,
                action="Buy", quantity=10.0, cost_basis=2200.0,
            ),
        ])
        s.commit()


def test_report_summary(cli_setup):
    """3 wash sale pairs in 2024: counts and total disallowed shown."""
    runner, engine, _ = cli_setup
    _seed_wash_sale(engine, "TSLA", 2024, loss=1000.0)
    _seed_wash_sale(engine, "AAPL", 2024, loss=500.0)
    _seed_wash_sale(engine, "MSFT", 2024, loss=750.0)

    result = runner.invoke(app, ["report", "--year", "2024"])

    assert result.exit_code == 0, result.output
    assert "Confirmed" in result.output
    # Total disallowed = 1000 + 500 + 750 = 2250
    assert "2,250" in result.output or "2250" in result.output
    assert DISCLAIMER in result.output


def test_report_year_filter(cli_setup):
    """--year 2024: 2023 violations not shown."""
    runner, engine, _ = cli_setup
    _seed_wash_sale(engine, "TSLA", 2024, loss=1000.0)
    _seed_wash_sale(engine, "AAPL", 2023, loss=800.0)

    result = runner.invoke(app, ["report", "--year", "2024"])

    assert result.exit_code == 0, result.output
    assert "TSLA" in result.output
    assert "AAPL" not in result.output


def test_report_csv_export(cli_setup, tmp_path, monkeypatch):
    """--csv: CSV file created with correct headers and one Confirmed row."""
    runner, engine, _ = cli_setup
    _seed_wash_sale(engine, "TSLA", 2024, loss=1000.0)
    monkeypatch.chdir(tmp_path)

    result = runner.invoke(app, ["report", "--year", "2024", "--csv"])

    assert result.exit_code == 0, result.output

    csv_files = list(tmp_path.glob("wash_sale_report_*.csv"))
    assert len(csv_files) == 1

    with open(csv_files[0]) as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    assert len(rows) == 1
    assert rows[0]["Ticker"] == "TSLA"
    assert rows[0]["Confidence"] == "Confirmed"
    assert "1000" in rows[0]["Disallowed"]


def test_report_empty(cli_setup):
    """No trades: 'No trades imported yet.' message, exit 0."""
    runner, engine, _ = cli_setup

    result = runner.invoke(app, ["report"])

    assert result.exit_code == 0, result.output
    assert "no trades" in result.output.lower()
    # No disclaimer when exiting early (no trades) — check report.py if needed
```

- [ ] **Step 2: Run tests**

```bash
uv run pytest tests/integration/cli/test_report.py -v
```

Expected: 4 tests pass.

- [ ] **Step 3: Commit**

```bash
git add tests/integration/cli/test_report.py
git commit -m "test: add CLI integration tests for report command"
```

---

### Task 10: Final sweep — run full suite

- [ ] **Step 1: Run the complete integration suite**

```bash
uv run pytest tests/integration/ -v --tb=short
```

Expected: all tests pass. If any fail, check these common issues:
- `ImportContext` field mismatch → read `src/net_alpha/import_/importer.py`
- `_bootstrap` patch not taking effect → verify the target path is `net_alpha.cli.app._bootstrap`
- CLI output string mismatch → read the actual command source in `src/net_alpha/cli/`
- Rich markup in output (`[bold]...`) is stripped by CliRunner — assert on plain text only

- [ ] **Step 2: Run with coverage**

```bash
uv run pytest tests/integration/ --cov=src/net_alpha --cov-report=term-missing -q
```

- [ ] **Step 3: Confirm no regressions in existing unit tests**

```bash
uv run pytest tests/ -q --tb=short
```

Expected: all tests pass.

- [ ] **Step 4: Final commit**

```bash
git add -A
git commit -m "test: complete integration test suite — CLI and engine tiers"
```
