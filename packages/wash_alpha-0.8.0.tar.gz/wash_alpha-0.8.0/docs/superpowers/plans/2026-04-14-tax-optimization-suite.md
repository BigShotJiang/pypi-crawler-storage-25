# Tax Optimization Suite Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add `net-alpha tax-position` command and enhance `simulate sell` with lot selection comparison and tax-aware recommendations.

**Architecture:** A shared `_allocate_lots` engine replays per-(account, ticker) FIFO to produce both realized gain/loss pairs and remaining open lots. `compute_tax_position`, `identify_open_lots`, `select_lots`, and `recommend_lot_method` are thin wrappers over that core. All new domain types live in `models/domain.py` as Pydantic models. CLI commands consume structured engine output and handle all Rich rendering.

**Tech Stack:** Python 3.11+, Pydantic v2, Typer/Rich, pytest + factory_boy, uv

**Spec:** `docs/superpowers/specs/2026-04-14-tax-optimization-suite-design.md`

---

## File Structure

| File | Responsibility |
|------|---------------|
| `src/net_alpha/models/domain.py` | **Modify** — add `TaxPosition`, `OpenLot`, `LotSelection`, `LotRecommendation`, `AllocationResult`, `RealizedPair` |
| `src/net_alpha/engine/tax_position.py` | **Create** — pure engine: `_allocate_lots`, `compute_tax_position`, `identify_open_lots`, `select_lots`, `recommend_lot_method` |
| `src/net_alpha/cli/tax_position.py` | **Create** — `tax_position_command` (simple command pattern) |
| `src/net_alpha/cli/simulate.py` | **Modify** — add `_render_lot_selection` helper called when `--price` is provided |
| `src/net_alpha/cli/app.py` | **Modify** — register `tax-position` command |
| `tests/conftest.py` | **Modify** — add factories for new domain types |
| `tests/engine/test_tax_position.py` | **Create** — engine unit tests |
| `tests/cli/test_tax_position.py` | **Create** — CLI rendering tests |
| `tests/cli/test_simulate_lots.py` | **Create** — lot selection integration tests |

---

### Task 1: Add Domain Models

**Files:**
- Modify: `src/net_alpha/models/domain.py`
- Test: `tests/models/test_domain.py`

- [ ] **Step 1: Write tests for new domain models**

Add to `tests/models/test_domain.py`:

```python
from datetime import date

from net_alpha.models.domain import (
    AllocationResult,
    LotRecommendation,
    LotSelection,
    OpenLot,
    RealizedPair,
    TaxPosition,
    Trade,
)


class TestTaxPosition:
    def test_net_st_gains(self):
        tp = TaxPosition(st_gains=12400.0, st_losses=3200.0, lt_gains=0.0, lt_losses=0.0, year=2026, basis_unknown_count=0)
        assert tp.net_st == 9200.0

    def test_net_st_losses(self):
        tp = TaxPosition(st_gains=1000.0, st_losses=5000.0, lt_gains=0.0, lt_losses=0.0, year=2026, basis_unknown_count=0)
        assert tp.net_st == -4000.0

    def test_net_lt(self):
        tp = TaxPosition(st_gains=0.0, st_losses=0.0, lt_gains=8100.0, lt_losses=500.0, year=2026, basis_unknown_count=0)
        assert tp.net_lt == 7600.0

    def test_net_capital_gain(self):
        tp = TaxPosition(st_gains=12400.0, st_losses=3200.0, lt_gains=8100.0, lt_losses=500.0, year=2026, basis_unknown_count=0)
        assert tp.net_capital_gain == 16800.0

    def test_loss_needed_to_zero_st_positive(self):
        tp = TaxPosition(st_gains=9200.0, st_losses=0.0, lt_gains=0.0, lt_losses=0.0, year=2026, basis_unknown_count=0)
        assert tp.loss_needed_to_zero_st == 9200.0

    def test_loss_needed_to_zero_st_already_negative(self):
        tp = TaxPosition(st_gains=1000.0, st_losses=5000.0, lt_gains=0.0, lt_losses=0.0, year=2026, basis_unknown_count=0)
        assert tp.loss_needed_to_zero_st == 0.0

    def test_carryforward_no_loss(self):
        tp = TaxPosition(st_gains=5000.0, st_losses=0.0, lt_gains=0.0, lt_losses=0.0, year=2026, basis_unknown_count=0)
        assert tp.carryforward == 0.0

    def test_carryforward_loss_under_3000(self):
        tp = TaxPosition(st_gains=0.0, st_losses=2999.0, lt_gains=0.0, lt_losses=0.0, year=2026, basis_unknown_count=0)
        assert tp.carryforward == 0.0

    def test_carryforward_loss_exactly_3000(self):
        tp = TaxPosition(st_gains=0.0, st_losses=3000.0, lt_gains=0.0, lt_losses=0.0, year=2026, basis_unknown_count=0)
        assert tp.carryforward == 0.0

    def test_carryforward_loss_above_3000(self):
        tp = TaxPosition(st_gains=0.0, st_losses=4800.0, lt_gains=0.0, lt_losses=0.0, year=2026, basis_unknown_count=0)
        assert tp.carryforward == 1800.0


class TestOpenLot:
    def test_creation(self):
        lot = OpenLot(
            ticker="AAPL",
            account="Schwab",
            quantity=50.0,
            adjusted_basis_per_share=145.0,
            purchase_date=date(2025, 6, 1),
            days_held=315,
            days_to_long_term=50,
            basis_unknown=False,
            is_option=False,
        )
        assert lot.ticker == "AAPL"
        assert lot.days_to_long_term == 50

    def test_long_term_lot(self):
        lot = OpenLot(
            ticker="TSLA",
            account="Robinhood",
            quantity=20.0,
            adjusted_basis_per_share=210.0,
            purchase_date=date(2025, 3, 1),
            days_held=390,
            days_to_long_term=0,
            basis_unknown=False,
            is_option=False,
        )
        assert lot.days_to_long_term == 0


class TestLotSelection:
    def test_creation_with_st_lt_split(self):
        sel = LotSelection(
            method="FIFO",
            lots_used=[],
            st_gain_loss=1750.0,
            lt_gain_loss=0.0,
            total_gain_loss=1750.0,
            wash_sale_risk=False,
        )
        assert sel.st_gain_loss == 1750.0
        assert sel.lt_gain_loss == 0.0


class TestLotRecommendation:
    def test_with_wash_risk(self):
        rec = LotRecommendation(
            preferred_method="LIFO",
            reason="st_loss_offset",
            has_wash_risk=True,
            safe_sell_date=date(2026, 1, 15),
            fallback_method="FIFO",
            fallback_reason="least_gain",
        )
        assert rec.has_wash_risk is True
        assert rec.fallback_method == "FIFO"

    def test_no_wash_risk(self):
        rec = LotRecommendation(
            preferred_method="HIFO",
            reason="lt_lower_rate",
            has_wash_risk=False,
            safe_sell_date=None,
            fallback_method=None,
            fallback_reason=None,
        )
        assert rec.has_wash_risk is False
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/models/test_domain.py::TestTaxPosition tests/models/test_domain.py::TestOpenLot tests/models/test_domain.py::TestLotSelection tests/models/test_domain.py::TestLotRecommendation -v`
Expected: FAIL — `ImportError` because models don't exist yet

- [ ] **Step 3: Add domain models to `models/domain.py`**

Add these classes at the end of `src/net_alpha/models/domain.py`, after the existing `DetectionResult` class:

```python
class RealizedPair(BaseModel):
    """A sell matched to a specific buy lot with quantity consumed."""

    sell_trade_id: str
    buy_lot_date: date
    buy_lot_account: str
    quantity: float
    proceeds: float
    basis: float
    basis_unknown: bool
    is_long_term: bool  # holding period > 365 days


class OpenLot(BaseModel):
    """An open (unconsumed) buy lot with holding period info."""

    ticker: str
    account: str
    quantity: float
    adjusted_basis_per_share: float
    purchase_date: date
    days_held: int
    days_to_long_term: int  # 0 if already long-term
    basis_unknown: bool
    is_option: bool


class AllocationResult(BaseModel):
    """Output of _allocate_lots — shared by tax position and open lots."""

    realized_pairs: list[RealizedPair]
    open_lots: list[OpenLot]


class TaxPosition(BaseModel):
    """YTD realized tax position with ST/LT classification."""

    st_gains: float
    st_losses: float
    lt_gains: float
    lt_losses: float
    year: int
    basis_unknown_count: int

    @property
    def net_st(self) -> float:
        return self.st_gains - self.st_losses

    @property
    def net_lt(self) -> float:
        return self.lt_gains - self.lt_losses

    @property
    def net_capital_gain(self) -> float:
        return self.net_st + self.net_lt

    @property
    def loss_needed_to_zero_st(self) -> float:
        return max(0.0, self.net_st)

    @property
    def carryforward(self) -> float:
        return max(0.0, -self.net_capital_gain - 3000.0)


class LotSelection(BaseModel):
    """Result of applying a lot selection method (FIFO/HIFO/LIFO) to a sell."""

    method: str  # "FIFO", "HIFO", "LIFO"
    lots_used: list[OpenLot]
    st_gain_loss: float
    lt_gain_loss: float
    total_gain_loss: float
    wash_sale_risk: bool


class LotRecommendation(BaseModel):
    """Structured recommendation from the lot selection decision tree."""

    preferred_method: str  # "FIFO", "HIFO", "LIFO"
    reason: str  # "st_loss_offset", "lt_lower_rate", "least_gain"
    has_wash_risk: bool
    safe_sell_date: date | None
    fallback_method: str | None
    fallback_reason: str | None
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/models/test_domain.py -v`
Expected: ALL PASS

- [ ] **Step 5: Run full test suite to check for regressions**

Run: `uv run pytest --tb=short`
Expected: ALL PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/models/domain.py tests/models/test_domain.py
git commit -m "feat: add domain models for tax optimization suite

Add TaxPosition, OpenLot, LotSelection, LotRecommendation,
AllocationResult, and RealizedPair to models/domain.py.
Includes computed properties for net_st, net_lt, net_capital_gain,
loss_needed_to_zero_st, and carryforward ($3,000 cap)."
```

---

### Task 2: Add Test Factories

**Files:**
- Modify: `tests/conftest.py`

- [ ] **Step 1: Add factories for new domain types**

Add to `tests/conftest.py`:

```python
from net_alpha.models.domain import OpenLot, RealizedPair


class OpenLotFactory(factory.Factory):
    class Meta:
        model = OpenLot

    ticker = "AAPL"
    account = "Schwab"
    quantity = 50.0
    adjusted_basis_per_share = 145.0
    purchase_date = factory.LazyFunction(lambda: date(2025, 6, 1))
    days_held = 315
    days_to_long_term = 50
    basis_unknown = False
    is_option = False


class RealizedPairFactory(factory.Factory):
    class Meta:
        model = RealizedPair

    sell_trade_id = factory.LazyFunction(lambda: str(uuid4()))
    buy_lot_date = factory.LazyFunction(lambda: date(2025, 1, 15))
    buy_lot_account = "Schwab"
    quantity = 10.0
    proceeds = 1800.0
    basis = 1500.0
    basis_unknown = False
    is_long_term = False
```

- [ ] **Step 2: Verify factories work**

Run: `uv run pytest tests/models/test_domain.py -v`
Expected: ALL PASS (no regressions)

- [ ] **Step 3: Commit**

```bash
git add tests/conftest.py
git commit -m "feat: add OpenLotFactory and RealizedPairFactory test fixtures"
```

---

### Task 3: Implement `_allocate_lots` Core Engine

This is the most complex function. It replays per-(account, ticker) FIFO allocation to produce both realized pairs and open lots.

**Files:**
- Create: `src/net_alpha/engine/tax_position.py`
- Create: `tests/engine/test_tax_position.py`

- [ ] **Step 1: Write test for basic single-account FIFO allocation**

Create `tests/engine/test_tax_position.py`:

```python
from datetime import date

from net_alpha.engine.tax_position import _allocate_lots
from tests.conftest import LossSaleFactory, TradeFactory


class TestAllocateLots:
    def test_single_buy_single_sell_fully_consumed(self):
        """Buy 10, sell 10 → no open lots, one realized pair."""
        buy = TradeFactory(
            account="Schwab",
            date=date(2025, 1, 15),
            ticker="AAPL",
            action="Buy",
            quantity=10.0,
            cost_basis=1500.0,
        )
        sell = TradeFactory(
            account="Schwab",
            date=date(2025, 7, 20),
            ticker="AAPL",
            action="Sell",
            quantity=10.0,
            proceeds=1800.0,
            cost_basis=1500.0,
        )
        result = _allocate_lots([buy, sell], as_of=date(2025, 12, 1))

        assert len(result.realized_pairs) == 1
        assert len(result.open_lots) == 0
        rp = result.realized_pairs[0]
        assert rp.sell_trade_id == sell.id
        assert rp.quantity == 10.0
        assert rp.proceeds == 1800.0
        assert rp.basis == 1500.0
        assert rp.is_long_term is True  # Jan 15 to Jul 20 = 186 days... wait

    def test_single_buy_no_sell_all_open(self):
        """Buy 50 shares, no sell → 50 shares open."""
        buy = TradeFactory(
            account="Schwab",
            date=date(2025, 6, 1),
            ticker="AAPL",
            action="Buy",
            quantity=50.0,
            cost_basis=7250.0,
        )
        result = _allocate_lots([buy], as_of=date(2026, 4, 14))

        assert len(result.realized_pairs) == 0
        assert len(result.open_lots) == 1
        lot = result.open_lots[0]
        assert lot.ticker == "AAPL"
        assert lot.account == "Schwab"
        assert lot.quantity == 50.0
        assert lot.adjusted_basis_per_share == 145.0  # 7250 / 50
        assert lot.purchase_date == date(2025, 6, 1)
        # Jun 1 2025 to Apr 14 2026 = 317 days
        assert lot.days_held == 317
        # 366 - 317 = 49 days to long-term
        assert lot.days_to_long_term == 49

    def test_partial_sell_leaves_open_lot(self):
        """Buy 100, sell 60 → 40 open with correct remaining basis."""
        buy = TradeFactory(
            account="Schwab",
            date=date(2025, 1, 10),
            ticker="AAPL",
            action="Buy",
            quantity=100.0,
            cost_basis=15000.0,
        )
        sell = TradeFactory(
            account="Schwab",
            date=date(2025, 6, 15),
            ticker="AAPL",
            action="Sell",
            quantity=60.0,
            proceeds=10200.0,
            cost_basis=9000.0,
        )
        result = _allocate_lots([buy, sell], as_of=date(2025, 12, 1))

        assert len(result.realized_pairs) == 1
        rp = result.realized_pairs[0]
        assert rp.quantity == 60.0
        assert rp.basis == 9000.0  # 60 * 150

        assert len(result.open_lots) == 1
        lot = result.open_lots[0]
        assert lot.quantity == 40.0
        assert lot.adjusted_basis_per_share == 150.0  # 6000 / 40
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/engine/test_tax_position.py::TestAllocateLots -v`
Expected: FAIL — `ImportError` because `tax_position` module doesn't exist

- [ ] **Step 3: Implement `_allocate_lots`**

Create `src/net_alpha/engine/tax_position.py`:

```python
from __future__ import annotations

from collections import defaultdict
from datetime import date

from net_alpha.models.domain import (
    AllocationResult,
    OpenLot,
    RealizedPair,
    Trade,
)


def _allocate_lots(trades: list[Trade], as_of: date) -> AllocationResult:
    """Replay per-(account, ticker) FIFO allocation.

    Returns realized pairs (sell matched to buy) and remaining open lots.
    Options are excluded from open lots.
    """
    # Group trades by (account, ticker)
    groups: dict[tuple[str, str], list[Trade]] = defaultdict(list)
    for t in trades:
        groups[(t.account, t.ticker)].append(t)

    all_realized: list[RealizedPair] = []
    all_open: list[OpenLot] = []

    for (account, ticker), group_trades in groups.items():
        # Sort by (date, id) for deterministic FIFO
        group_trades.sort(key=lambda t: (t.date, t.id))

        # Build buy queue: list of [trade, remaining_qty, remaining_basis]
        buy_queue: list[list] = []
        sells: list[Trade] = []

        for t in group_trades:
            if t.is_buy():
                buy_queue.append([t, t.quantity, t.adjusted_basis if hasattr(t, "adjusted_basis") else (t.cost_basis or 0.0)])
            elif t.is_sell():
                sells.append(t)

        # Process sells in date order (already sorted)
        for sell in sells:
            remaining_sell_qty = sell.quantity

            for entry in buy_queue:
                if remaining_sell_qty <= 0:
                    break

                buy_trade, buy_remaining_qty, buy_remaining_basis = entry
                if buy_remaining_qty <= 0:
                    continue

                consumed = min(remaining_sell_qty, buy_remaining_qty)
                basis_per_share = buy_remaining_basis / buy_remaining_qty
                consumed_basis = round(consumed * basis_per_share, 2)
                consumed_proceeds = round((sell.proceeds or 0.0) * consumed / sell.quantity, 2)

                holding_days = (sell.date - buy_trade.date).days
                is_lt = holding_days > 365

                all_realized.append(
                    RealizedPair(
                        sell_trade_id=sell.id,
                        buy_lot_date=buy_trade.date,
                        buy_lot_account=account,
                        quantity=consumed,
                        proceeds=consumed_proceeds,
                        basis=consumed_basis,
                        basis_unknown=buy_trade.basis_unknown,
                        is_long_term=is_lt,
                    )
                )

                entry[1] -= consumed  # remaining_qty
                entry[2] -= consumed_basis  # remaining_basis
                remaining_sell_qty -= consumed

        # Remaining buys become open lots (skip options)
        for entry in buy_queue:
            buy_trade, remaining_qty, remaining_basis = entry
            if remaining_qty <= 0:
                continue
            if buy_trade.is_option():
                continue

            holding_days = (as_of - buy_trade.date).days
            days_to_lt = max(0, 366 - holding_days)

            all_open.append(
                OpenLot(
                    ticker=ticker,
                    account=account,
                    quantity=remaining_qty,
                    adjusted_basis_per_share=round(remaining_basis / remaining_qty, 2) if remaining_qty > 0 else 0.0,
                    purchase_date=buy_trade.date,
                    days_held=holding_days,
                    days_to_long_term=days_to_lt,
                    basis_unknown=buy_trade.basis_unknown,
                    is_option=False,
                )
            )

    return AllocationResult(realized_pairs=all_realized, open_lots=all_open)
```

Note: `Trade` doesn't have `adjusted_basis` — that's on `Lot`. For `_allocate_lots`, the initial basis is `cost_basis`. Wash sale adjustments from `detect_wash_sales` are stored in the `Lot` table — but `_allocate_lots` operates on raw `Trade` objects. The adjusted basis from prior wash sales is already reflected in the `Lot` rows, but this function works from trades directly. We use `cost_basis` as the starting basis per lot. If you need wash-sale-adjusted basis to flow through, see Task 3b.

Correct the line in `_allocate_lots`:
```python
buy_queue.append([t, t.quantity, t.cost_basis or 0.0])
```

- [ ] **Step 4: Fix the first test — holding period calculation**

The first test has a bug: Jan 15 to Jul 20 = 186 days, which is NOT long-term. Fix:

```python
    def test_single_buy_single_sell_fully_consumed(self):
        """Buy 10, sell 10 → no open lots, one realized pair."""
        buy = TradeFactory(
            account="Schwab",
            date=date(2025, 1, 15),
            ticker="AAPL",
            action="Buy",
            quantity=10.0,
            cost_basis=1500.0,
        )
        sell = TradeFactory(
            account="Schwab",
            date=date(2025, 7, 20),
            ticker="AAPL",
            action="Sell",
            quantity=10.0,
            proceeds=1800.0,
            cost_basis=1500.0,
        )
        result = _allocate_lots([buy, sell], as_of=date(2025, 12, 1))

        assert len(result.realized_pairs) == 1
        assert len(result.open_lots) == 0
        rp = result.realized_pairs[0]
        assert rp.sell_trade_id == sell.id
        assert rp.quantity == 10.0
        assert rp.proceeds == 1800.0
        assert rp.basis == 1500.0
        assert rp.is_long_term is False  # Jan 15 to Jul 20 = 186 days
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_tax_position.py::TestAllocateLots -v`
Expected: ALL PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/engine/tax_position.py tests/engine/test_tax_position.py
git commit -m "feat: implement _allocate_lots core FIFO allocation engine

Replays per-(account, ticker) FIFO to produce realized pairs
and remaining open lots. Tracks remaining_qty and remaining_basis
per lot for correct partial consumption and basis proration."
```

---

### Task 4: Additional `_allocate_lots` Tests — Edge Cases

**Files:**
- Modify: `tests/engine/test_tax_position.py`

- [ ] **Step 1: Write edge case tests**

Add to `TestAllocateLots` in `tests/engine/test_tax_position.py`:

```python
    def test_fifo_order_multiple_buys(self):
        """Two buys, one sell — FIFO consumes earliest first."""
        buy1 = TradeFactory(
            account="Schwab", date=date(2025, 1, 10), ticker="AAPL",
            action="Buy", quantity=30.0, cost_basis=4500.0,
        )
        buy2 = TradeFactory(
            account="Schwab", date=date(2025, 3, 1), ticker="AAPL",
            action="Buy", quantity=40.0, cost_basis=6400.0,
        )
        sell = TradeFactory(
            account="Schwab", date=date(2025, 6, 15), ticker="AAPL",
            action="Sell", quantity=50.0, proceeds=8500.0, cost_basis=7700.0,
        )
        result = _allocate_lots([buy1, buy2, sell], as_of=date(2025, 12, 1))

        assert len(result.realized_pairs) == 2
        # First pair: 30 from buy1 at $150/sh
        rp1 = result.realized_pairs[0]
        assert rp1.quantity == 30.0
        assert rp1.basis == 4500.0
        assert rp1.buy_lot_date == date(2025, 1, 10)
        # Second pair: 20 from buy2 at $160/sh
        rp2 = result.realized_pairs[1]
        assert rp2.quantity == 20.0
        assert rp2.basis == 3200.0  # 20 * 160
        assert rp2.buy_lot_date == date(2025, 3, 1)

        # Open lot: 20 remaining from buy2
        assert len(result.open_lots) == 1
        lot = result.open_lots[0]
        assert lot.quantity == 20.0
        assert lot.adjusted_basis_per_share == 160.0

    def test_per_account_isolation(self):
        """Sell on Schwab does NOT consume Robinhood lots."""
        schwab_buy = TradeFactory(
            account="Schwab", date=date(2025, 1, 10), ticker="AAPL",
            action="Buy", quantity=30.0, cost_basis=4500.0,
        )
        robin_buy = TradeFactory(
            account="Robinhood", date=date(2025, 2, 1), ticker="AAPL",
            action="Buy", quantity=50.0, cost_basis=7500.0,
        )
        schwab_sell = TradeFactory(
            account="Schwab", date=date(2025, 6, 15), ticker="AAPL",
            action="Sell", quantity=30.0, proceeds=5100.0, cost_basis=4500.0,
        )
        result = _allocate_lots(
            [schwab_buy, robin_buy, schwab_sell], as_of=date(2025, 12, 1)
        )

        # Only Schwab buy consumed; Robinhood buy remains open
        assert len(result.realized_pairs) == 1
        rp = result.realized_pairs[0]
        assert rp.buy_lot_account == "Schwab"

        assert len(result.open_lots) == 1
        lot = result.open_lots[0]
        assert lot.account == "Robinhood"
        assert lot.quantity == 50.0

    def test_same_date_buys_ordered_by_id(self):
        """Two buys on same date — ordered by id for determinism."""
        buy_a = TradeFactory(
            id="aaa",
            account="Schwab", date=date(2025, 1, 15), ticker="AAPL",
            action="Buy", quantity=30.0, cost_basis=4500.0,
        )
        buy_b = TradeFactory(
            id="bbb",
            account="Schwab", date=date(2025, 1, 15), ticker="AAPL",
            action="Buy", quantity=40.0, cost_basis=6000.0,
        )
        sell = TradeFactory(
            account="Schwab", date=date(2025, 6, 15), ticker="AAPL",
            action="Sell", quantity=40.0, proceeds=6800.0, cost_basis=6100.0,
        )
        result = _allocate_lots([buy_a, buy_b, sell], as_of=date(2025, 12, 1))

        # FIFO: consume all 30 from buy_a (id "aaa" < "bbb"), then 10 from buy_b
        assert len(result.realized_pairs) == 2
        assert result.realized_pairs[0].buy_lot_date == date(2025, 1, 15)
        assert result.realized_pairs[0].quantity == 30.0
        assert result.realized_pairs[1].quantity == 10.0

        # 30 remaining from buy_b
        assert len(result.open_lots) == 1
        assert result.open_lots[0].quantity == 30.0

    def test_basis_unknown_buy_lot(self):
        """basis_unknown buy → open lot has basis_unknown=True."""
        buy = TradeFactory(
            account="Schwab", date=date(2025, 1, 10), ticker="AAPL",
            action="Buy", quantity=10.0, cost_basis=None, basis_unknown=True,
        )
        result = _allocate_lots([buy], as_of=date(2025, 12, 1))

        assert len(result.open_lots) == 1
        assert result.open_lots[0].basis_unknown is True
        assert result.open_lots[0].adjusted_basis_per_share == 0.0

    def test_basis_unknown_realized_pair(self):
        """Sell consuming basis_unknown buy → realized pair marked."""
        buy = TradeFactory(
            account="Schwab", date=date(2025, 1, 10), ticker="AAPL",
            action="Buy", quantity=10.0, cost_basis=None, basis_unknown=True,
        )
        sell = TradeFactory(
            account="Schwab", date=date(2025, 6, 15), ticker="AAPL",
            action="Sell", quantity=10.0, proceeds=1800.0, cost_basis=None,
        )
        result = _allocate_lots([buy, sell], as_of=date(2025, 12, 1))

        assert len(result.realized_pairs) == 1
        assert result.realized_pairs[0].basis_unknown is True
        assert result.realized_pairs[0].basis == 0.0

    def test_option_trades_excluded_from_open_lots(self):
        """Option buys do not appear as open lots."""
        from net_alpha.models.domain import OptionDetails

        buy = TradeFactory(
            account="Schwab", date=date(2025, 1, 10), ticker="AAPL",
            action="Buy", quantity=1.0, cost_basis=500.0,
            option_details=OptionDetails(strike=150.0, expiry=date(2025, 6, 20), call_put="C"),
        )
        result = _allocate_lots([buy], as_of=date(2025, 12, 1))

        assert len(result.open_lots) == 0

    def test_holding_period_exactly_365_days(self):
        """Held exactly 365 days → short-term (> 365 for long-term)."""
        buy = TradeFactory(
            account="Schwab", date=date(2025, 1, 1), ticker="AAPL",
            action="Buy", quantity=10.0, cost_basis=1500.0,
        )
        sell = TradeFactory(
            account="Schwab", date=date(2026, 1, 1), ticker="AAPL",
            action="Sell", quantity=10.0, proceeds=1800.0, cost_basis=1500.0,
        )
        result = _allocate_lots([buy, sell], as_of=date(2026, 6, 1))

        rp = result.realized_pairs[0]
        assert rp.is_long_term is False  # exactly 365 = short-term

    def test_holding_period_366_days(self):
        """Held 366 days → long-term."""
        buy = TradeFactory(
            account="Schwab", date=date(2025, 1, 1), ticker="AAPL",
            action="Buy", quantity=10.0, cost_basis=1500.0,
        )
        sell = TradeFactory(
            account="Schwab", date=date(2026, 1, 2), ticker="AAPL",
            action="Sell", quantity=10.0, proceeds=1800.0, cost_basis=1500.0,
        )
        result = _allocate_lots([buy, sell], as_of=date(2026, 6, 1))

        rp = result.realized_pairs[0]
        assert rp.is_long_term is True

    def test_days_to_long_term_computation(self):
        """Open lot correctly computes days_to_long_term."""
        buy = TradeFactory(
            account="Schwab", date=date(2025, 6, 1), ticker="AAPL",
            action="Buy", quantity=50.0, cost_basis=7250.0,
        )
        # as_of = 2026-04-14 → 317 days held → 366-317 = 49 days to LT
        result = _allocate_lots([buy], as_of=date(2026, 4, 14))

        lot = result.open_lots[0]
        assert lot.days_held == 317
        assert lot.days_to_long_term == 49

    def test_already_long_term_open_lot(self):
        """Open lot held > 365 days → days_to_long_term = 0."""
        buy = TradeFactory(
            account="Schwab", date=date(2025, 1, 1), ticker="AAPL",
            action="Buy", quantity=20.0, cost_basis=3000.0,
        )
        result = _allocate_lots([buy], as_of=date(2026, 4, 14))  # 468 days

        lot = result.open_lots[0]
        assert lot.days_held == 468
        assert lot.days_to_long_term == 0

    def test_no_trades_empty_result(self):
        result = _allocate_lots([], as_of=date(2026, 1, 1))
        assert result.realized_pairs == []
        assert result.open_lots == []
```

- [ ] **Step 2: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_tax_position.py::TestAllocateLots -v`
Expected: ALL PASS

- [ ] **Step 3: Commit**

```bash
git add tests/engine/test_tax_position.py
git commit -m "test: add edge case tests for _allocate_lots

Covers per-account isolation, same-date ordering, basis_unknown,
option exclusion, holding period boundaries (365/366 days),
days_to_long_term, and empty input."
```

---

### Task 5: Implement `compute_tax_position`

**Files:**
- Modify: `src/net_alpha/engine/tax_position.py`
- Modify: `tests/engine/test_tax_position.py`

- [ ] **Step 1: Write tests for `compute_tax_position`**

Add to `tests/engine/test_tax_position.py`:

```python
from net_alpha.engine.tax_position import _allocate_lots, compute_tax_position
from net_alpha.models.domain import OptionDetails


class TestComputeTaxPosition:
    def test_simple_st_gain(self):
        """Single short-term gain classified correctly."""
        buy = TradeFactory(
            account="Schwab", date=date(2026, 1, 10), ticker="AAPL",
            action="Buy", quantity=50.0, cost_basis=7250.0,
        )
        sell = TradeFactory(
            account="Schwab", date=date(2026, 3, 15), ticker="AAPL",
            action="Sell", quantity=50.0, proceeds=9000.0, cost_basis=7250.0,
        )
        tp = compute_tax_position([buy, sell], year=2026)

        assert tp.st_gains == 1750.0
        assert tp.st_losses == 0.0
        assert tp.lt_gains == 0.0
        assert tp.lt_losses == 0.0
        assert tp.year == 2026

    def test_lt_gain(self):
        """Long-term gain (> 365 days)."""
        buy = TradeFactory(
            account="Schwab", date=date(2025, 1, 10), ticker="AAPL",
            action="Buy", quantity=50.0, cost_basis=5000.0,
        )
        sell = TradeFactory(
            account="Schwab", date=date(2026, 3, 15), ticker="AAPL",
            action="Sell", quantity=50.0, proceeds=8000.0, cost_basis=5000.0,
        )
        tp = compute_tax_position([buy, sell], year=2026)

        assert tp.st_gains == 0.0
        assert tp.lt_gains == 3000.0

    def test_st_loss(self):
        """Short-term loss."""
        buy = TradeFactory(
            account="Schwab", date=date(2026, 1, 10), ticker="AAPL",
            action="Buy", quantity=50.0, cost_basis=9000.0,
        )
        sell = TradeFactory(
            account="Schwab", date=date(2026, 3, 15), ticker="AAPL",
            action="Sell", quantity=50.0, proceeds=7500.0, cost_basis=9000.0,
        )
        tp = compute_tax_position([buy, sell], year=2026)

        assert tp.st_gains == 0.0
        assert tp.st_losses == 1500.0

    def test_filters_by_year(self):
        """Only sells in the given year contribute to the position."""
        buy = TradeFactory(
            account="Schwab", date=date(2025, 1, 10), ticker="AAPL",
            action="Buy", quantity=50.0, cost_basis=7250.0,
        )
        sell_2025 = TradeFactory(
            account="Schwab", date=date(2025, 6, 15), ticker="AAPL",
            action="Sell", quantity=25.0, proceeds=4500.0, cost_basis=3625.0,
        )
        sell_2026 = TradeFactory(
            account="Schwab", date=date(2026, 3, 15), ticker="AAPL",
            action="Sell", quantity=25.0, proceeds=5000.0, cost_basis=3625.0,
        )
        tp = compute_tax_position([buy, sell_2025, sell_2026], year=2026)

        # Only sell_2026 counts: proceeds 5000 - basis 3625 = 1375 LT gain
        assert tp.lt_gains == 1375.0
        assert tp.st_gains == 0.0

    def test_basis_unknown_excluded_with_count(self):
        """basis_unknown sells excluded from totals, counted."""
        buy_known = TradeFactory(
            account="Schwab", date=date(2026, 1, 10), ticker="AAPL",
            action="Buy", quantity=10.0, cost_basis=1500.0,
        )
        buy_unknown = TradeFactory(
            account="Schwab", date=date(2026, 1, 15), ticker="MSFT",
            action="Buy", quantity=10.0, cost_basis=None, basis_unknown=True,
        )
        sell_known = TradeFactory(
            account="Schwab", date=date(2026, 6, 15), ticker="AAPL",
            action="Sell", quantity=10.0, proceeds=1800.0, cost_basis=1500.0,
        )
        sell_unknown = TradeFactory(
            account="Schwab", date=date(2026, 6, 20), ticker="MSFT",
            action="Sell", quantity=10.0, proceeds=2000.0, cost_basis=None,
        )
        tp = compute_tax_position(
            [buy_known, buy_unknown, sell_known, sell_unknown], year=2026
        )

        assert tp.st_gains == 300.0  # Only AAPL sell
        assert tp.basis_unknown_count == 1

    def test_option_trades_included(self):
        """Option gains/losses count toward YTD totals."""
        buy = TradeFactory(
            account="Schwab", date=date(2026, 1, 10), ticker="AAPL",
            action="Buy", quantity=1.0, cost_basis=500.0,
            option_details=OptionDetails(strike=150.0, expiry=date(2026, 6, 20), call_put="C"),
        )
        sell = TradeFactory(
            account="Schwab", date=date(2026, 3, 15), ticker="AAPL",
            action="Sell", quantity=1.0, proceeds=800.0, cost_basis=500.0,
            option_details=OptionDetails(strike=150.0, expiry=date(2026, 6, 20), call_put="C"),
        )
        tp = compute_tax_position([buy, sell], year=2026)

        assert tp.st_gains == 300.0

    def test_cross_year_buy_sell_lt(self):
        """Buy in 2025, sell in 2026 after > 365 days → long-term."""
        buy = TradeFactory(
            account="Schwab", date=date(2025, 1, 1), ticker="AAPL",
            action="Buy", quantity=10.0, cost_basis=1500.0,
        )
        sell = TradeFactory(
            account="Schwab", date=date(2026, 2, 1), ticker="AAPL",
            action="Sell", quantity=10.0, proceeds=2000.0, cost_basis=1500.0,
        )
        tp = compute_tax_position([buy, sell], year=2026)

        assert tp.lt_gains == 500.0
        assert tp.st_gains == 0.0

    def test_no_trades(self):
        tp = compute_tax_position([], year=2026)
        assert tp.st_gains == 0.0
        assert tp.st_losses == 0.0
        assert tp.lt_gains == 0.0
        assert tp.lt_losses == 0.0
        assert tp.basis_unknown_count == 0
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/engine/test_tax_position.py::TestComputeTaxPosition -v`
Expected: FAIL — `ImportError` because `compute_tax_position` doesn't exist

- [ ] **Step 3: Implement `compute_tax_position`**

Add to `src/net_alpha/engine/tax_position.py`:

```python
from net_alpha.models.domain import (
    AllocationResult,
    OpenLot,
    RealizedPair,
    TaxPosition,
    Trade,
)


def compute_tax_position(trades: list[Trade], year: int) -> TaxPosition:
    """Aggregate YTD realized gains/losses with ST/LT classification.

    Option trades are included. basis_unknown pairs are excluded and counted.
    Only sells in the given year contribute.
    """
    result = _allocate_lots(trades, as_of=date(year, 12, 31))

    st_gains = 0.0
    st_losses = 0.0
    lt_gains = 0.0
    lt_losses = 0.0
    basis_unknown_count = 0

    # Build sell trade lookup for year filtering
    sell_map = {t.id: t for t in trades if t.is_sell()}

    for rp in result.realized_pairs:
        sell_trade = sell_map.get(rp.sell_trade_id)
        if sell_trade is None or sell_trade.date.year != year:
            continue

        if rp.basis_unknown:
            basis_unknown_count += 1
            continue

        gain_loss = rp.proceeds - rp.basis

        if rp.is_long_term:
            if gain_loss >= 0:
                lt_gains += gain_loss
            else:
                lt_losses += abs(gain_loss)
        else:
            if gain_loss >= 0:
                st_gains += gain_loss
            else:
                st_losses += abs(gain_loss)

    return TaxPosition(
        st_gains=round(st_gains, 2),
        st_losses=round(st_losses, 2),
        lt_gains=round(lt_gains, 2),
        lt_losses=round(lt_losses, 2),
        year=year,
        basis_unknown_count=basis_unknown_count,
    )
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_tax_position.py::TestComputeTaxPosition -v`
Expected: ALL PASS

- [ ] **Step 5: Run full test suite**

Run: `uv run pytest --tb=short`
Expected: ALL PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/engine/tax_position.py tests/engine/test_tax_position.py
git commit -m "feat: implement compute_tax_position

Aggregates YTD realized gains/losses with ST/LT classification.
Options included in totals, basis_unknown excluded and counted.
Filters realized pairs by sell year."
```

---

### Task 6: Implement `identify_open_lots`

**Files:**
- Modify: `src/net_alpha/engine/tax_position.py`
- Modify: `tests/engine/test_tax_position.py`

- [ ] **Step 1: Write tests**

Add to `tests/engine/test_tax_position.py`:

```python
from net_alpha.engine.tax_position import identify_open_lots


class TestIdentifyOpenLots:
    def test_basic_open_lots(self):
        """Buys with no sells → all open."""
        buy1 = TradeFactory(
            account="Schwab", date=date(2025, 6, 1), ticker="AAPL",
            action="Buy", quantity=50.0, cost_basis=7250.0,
        )
        buy2 = TradeFactory(
            account="Robinhood", date=date(2025, 3, 1), ticker="TSLA",
            action="Buy", quantity=20.0, cost_basis=4200.0,
        )
        lots = identify_open_lots([buy1, buy2], as_of=date(2026, 4, 14))

        assert len(lots) == 2

    def test_sort_order_days_to_lt_ascending(self):
        """Lots sorted by days_to_long_term ascending, then ticker."""
        buy_far = TradeFactory(
            account="Schwab", date=date(2026, 3, 1), ticker="MSFT",
            action="Buy", quantity=15.0, cost_basis=4350.0,
        )
        buy_close = TradeFactory(
            account="Schwab", date=date(2025, 6, 1), ticker="AAPL",
            action="Buy", quantity=50.0, cost_basis=7250.0,
        )
        buy_lt = TradeFactory(
            account="Robinhood", date=date(2025, 3, 1), ticker="TSLA",
            action="Buy", quantity=20.0, cost_basis=4200.0,
        )
        lots = identify_open_lots([buy_far, buy_close, buy_lt], as_of=date(2026, 4, 14))

        assert len(lots) == 3
        # TSLA: 409 days held, days_to_lt=0 (already LT) - but sorted last
        # AAPL: 317 days held, days_to_lt=49
        # MSFT: 44 days held, days_to_lt=322
        # Sort: AAPL (49), MSFT (322), TSLA (0 → sorted to end)
        assert lots[0].ticker == "AAPL"
        assert lots[1].ticker == "MSFT"
        assert lots[2].ticker == "TSLA"

    def test_options_excluded(self):
        """Option buys excluded from open lots."""
        equity_buy = TradeFactory(
            account="Schwab", date=date(2025, 6, 1), ticker="AAPL",
            action="Buy", quantity=50.0, cost_basis=7250.0,
        )
        option_buy = TradeFactory(
            account="Schwab", date=date(2025, 6, 1), ticker="AAPL",
            action="Buy", quantity=1.0, cost_basis=500.0,
            option_details=OptionDetails(strike=150.0, expiry=date(2025, 12, 20), call_put="C"),
        )
        lots = identify_open_lots([equity_buy, option_buy], as_of=date(2026, 4, 14))

        assert len(lots) == 1
        assert lots[0].is_option is False

    def test_partially_consumed_lot(self):
        """After partial sell, open lot shows remaining."""
        buy = TradeFactory(
            account="Schwab", date=date(2025, 6, 1), ticker="AAPL",
            action="Buy", quantity=100.0, cost_basis=15000.0,
        )
        sell = TradeFactory(
            account="Schwab", date=date(2025, 9, 1), ticker="AAPL",
            action="Sell", quantity=60.0, proceeds=10200.0, cost_basis=9000.0,
        )
        lots = identify_open_lots([buy, sell], as_of=date(2026, 4, 14))

        assert len(lots) == 1
        assert lots[0].quantity == 40.0
        assert lots[0].adjusted_basis_per_share == 150.0

    def test_no_trades(self):
        lots = identify_open_lots([], as_of=date(2026, 1, 1))
        assert lots == []
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/engine/test_tax_position.py::TestIdentifyOpenLots -v`
Expected: FAIL — `ImportError`

- [ ] **Step 3: Implement `identify_open_lots`**

Add to `src/net_alpha/engine/tax_position.py`:

```python
def identify_open_lots(trades: list[Trade], as_of: date) -> list[OpenLot]:
    """Return remaining open lots sorted by days_to_long_term ascending, then ticker.

    Options are excluded. Already-long-term lots sort to the end.
    """
    result = _allocate_lots(trades, as_of=as_of)

    # Sort: lots still approaching LT threshold first (ascending), then already-LT lots.
    # Within same days_to_long_term, sort by ticker alphabetically.
    def sort_key(lot: OpenLot) -> tuple[int, int, str]:
        # already LT (days_to_long_term == 0) sorts after all others
        is_already_lt = 1 if lot.days_to_long_term == 0 else 0
        return (is_already_lt, lot.days_to_long_term, lot.ticker)

    return sorted(result.open_lots, key=sort_key)
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_tax_position.py::TestIdentifyOpenLots -v`
Expected: ALL PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/engine/tax_position.py tests/engine/test_tax_position.py
git commit -m "feat: implement identify_open_lots

Returns open lots sorted by days_to_long_term ascending
(approaching threshold first), already-LT lots last,
then ticker alphabetically. Options excluded."
```

---

### Task 7: Implement `select_lots`

**Files:**
- Modify: `src/net_alpha/engine/tax_position.py`
- Modify: `tests/engine/test_tax_position.py`

- [ ] **Step 1: Write tests**

Add to `tests/engine/test_tax_position.py`:

```python
from net_alpha.engine.tax_position import select_lots


class TestSelectLots:
    def _make_open_lots(self):
        """Helper: 3 open lots at different prices and holding periods."""
        return [
            OpenLotFactory(
                ticker="AAPL", account="Schwab", quantity=50.0,
                adjusted_basis_per_share=145.0,
                purchase_date=date(2025, 8, 15), days_held=242, days_to_long_term=124,
            ),
            OpenLotFactory(
                ticker="AAPL", account="Robinhood", quantity=50.0,
                adjusted_basis_per_share=112.0,
                purchase_date=date(2025, 1, 10), days_held=459, days_to_long_term=0,
            ),
            OpenLotFactory(
                ticker="AAPL", account="Schwab", quantity=50.0,
                adjusted_basis_per_share=195.0,
                purchase_date=date(2025, 11, 20), days_held=145, days_to_long_term=221,
            ),
        ]

    def test_fifo_selects_earliest_first(self):
        lots = self._make_open_lots()
        sel = select_lots(lots, ticker="AAPL", qty=50.0, method="FIFO", price=180.0)

        assert sel.method == "FIFO"
        assert len(sel.lots_used) == 1
        # Earliest: Jan 10 at $112
        assert sel.lots_used[0].purchase_date == date(2025, 1, 10)
        assert sel.total_gain_loss == 3400.0  # (180 - 112) * 50
        assert sel.lt_gain_loss == 3400.0  # long-term lot
        assert sel.st_gain_loss == 0.0

    def test_hifo_selects_highest_basis_first(self):
        lots = self._make_open_lots()
        sel = select_lots(lots, ticker="AAPL", qty=50.0, method="HIFO", price=180.0)

        assert sel.method == "HIFO"
        # Highest basis: $195/sh
        assert sel.lots_used[0].adjusted_basis_per_share == 195.0
        assert sel.total_gain_loss == -750.0  # (180 - 195) * 50
        assert sel.st_gain_loss == -750.0  # short-term lot

    def test_lifo_selects_most_recent_first(self):
        lots = self._make_open_lots()
        sel = select_lots(lots, ticker="AAPL", qty=50.0, method="LIFO", price=180.0)

        assert sel.method == "LIFO"
        # Most recent: Nov 20
        assert sel.lots_used[0].purchase_date == date(2025, 11, 20)
        assert sel.total_gain_loss == -750.0

    def test_fifo_partial_lot_split(self):
        """FIFO across two lots, producing both ST and LT components."""
        lots = self._make_open_lots()
        # Need 80 shares: 50 from Jan 10 (LT) + 30 from Aug 15 (ST)
        sel = select_lots(lots, ticker="AAPL", qty=80.0, method="FIFO", price=180.0)

        assert len(sel.lots_used) == 2
        assert sel.lt_gain_loss == 3400.0  # (180-112)*50
        assert sel.st_gain_loss == 1050.0  # (180-145)*30
        assert sel.total_gain_loss == 4450.0

    def test_quantity_exceeds_available(self):
        """Requesting more than available → returns None."""
        lots = self._make_open_lots()  # 150 total
        sel = select_lots(lots, ticker="AAPL", qty=200.0, method="FIFO", price=180.0)

        assert sel is None

    def test_no_matching_ticker(self):
        lots = self._make_open_lots()  # all AAPL
        sel = select_lots(lots, ticker="TSLA", qty=10.0, method="FIFO", price=300.0)

        assert sel is None

    def test_wash_sale_risk_defaults_false(self):
        lots = self._make_open_lots()
        sel = select_lots(lots, ticker="AAPL", qty=50.0, method="HIFO", price=180.0)

        assert sel.wash_sale_risk is False

    def test_pools_across_accounts(self):
        """Lots from Schwab and Robinhood are both available."""
        lots = self._make_open_lots()
        # 150 total across both accounts
        sel = select_lots(lots, ticker="AAPL", qty=150.0, method="FIFO", price=180.0)

        assert sel is not None
        assert len(sel.lots_used) == 3
        accounts = {lot.account for lot in sel.lots_used}
        assert accounts == {"Schwab", "Robinhood"}
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/engine/test_tax_position.py::TestSelectLots -v`
Expected: FAIL — `ImportError`

- [ ] **Step 3: Implement `select_lots`**

Add to `src/net_alpha/engine/tax_position.py`:

```python
from net_alpha.models.domain import (
    AllocationResult,
    LotSelection,
    OpenLot,
    RealizedPair,
    TaxPosition,
    Trade,
)


def select_lots(
    open_lots: list[OpenLot],
    ticker: str,
    qty: float,
    method: str,
    price: float,
) -> LotSelection | None:
    """Apply FIFO/HIFO/LIFO to select lots for a simulated sell.

    Pools across accounts. Returns None if insufficient shares available.
    wash_sale_risk is always False — caller sets it based on look-back triggers.
    """
    ticker_lots = [lot for lot in open_lots if lot.ticker == ticker]

    total_available = sum(lot.quantity for lot in ticker_lots)
    if total_available < qty:
        return None

    # Sort by method
    if method == "FIFO":
        sorted_lots = sorted(ticker_lots, key=lambda l: (l.purchase_date, l.account))
    elif method == "HIFO":
        sorted_lots = sorted(ticker_lots, key=lambda l: -l.adjusted_basis_per_share)
    elif method == "LIFO":
        sorted_lots = sorted(ticker_lots, key=lambda l: l.purchase_date, reverse=True)
    else:
        return None

    lots_used: list[OpenLot] = []
    st_gain_loss = 0.0
    lt_gain_loss = 0.0
    remaining = qty

    for lot in sorted_lots:
        if remaining <= 0:
            break

        consumed = min(remaining, lot.quantity)
        gain_loss = round((price - lot.adjusted_basis_per_share) * consumed, 2)

        is_lt = lot.days_to_long_term == 0

        # Create a copy of the lot reflecting consumed quantity
        used_lot = lot.model_copy(update={"quantity": consumed})
        lots_used.append(used_lot)

        if is_lt:
            lt_gain_loss += gain_loss
        else:
            st_gain_loss += gain_loss

        remaining -= consumed

    return LotSelection(
        method=method,
        lots_used=lots_used,
        st_gain_loss=round(st_gain_loss, 2),
        lt_gain_loss=round(lt_gain_loss, 2),
        total_gain_loss=round(st_gain_loss + lt_gain_loss, 2),
        wash_sale_risk=False,
    )
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_tax_position.py::TestSelectLots -v`
Expected: ALL PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/engine/tax_position.py tests/engine/test_tax_position.py
git commit -m "feat: implement select_lots with FIFO/HIFO/LIFO methods

Pools lots across accounts, splits gain/loss into ST/LT components.
Returns None if insufficient shares. wash_sale_risk left to caller."
```

---

### Task 8: Implement `recommend_lot_method`

**Files:**
- Modify: `src/net_alpha/engine/tax_position.py`
- Modify: `tests/engine/test_tax_position.py`

- [ ] **Step 1: Write tests for the recommendation decision tree**

Add to `tests/engine/test_tax_position.py`:

```python
from net_alpha.engine.tax_position import recommend_lot_method
from net_alpha.models.domain import LotRecommendation, LotSelection, TaxPosition


class TestRecommendLotMethod:
    def _make_tax_position(self, st_gains=0.0, st_losses=0.0, lt_gains=0.0, lt_losses=0.0):
        return TaxPosition(
            st_gains=st_gains, st_losses=st_losses,
            lt_gains=lt_gains, lt_losses=lt_losses,
            year=2026, basis_unknown_count=0,
        )

    def _make_selection(self, method, st_gain_loss=0.0, lt_gain_loss=0.0, wash_sale_risk=False):
        return LotSelection(
            method=method,
            lots_used=[],
            st_gain_loss=st_gain_loss,
            lt_gain_loss=lt_gain_loss,
            total_gain_loss=st_gain_loss + lt_gain_loss,
            wash_sale_risk=wash_sale_risk,
        )

    def test_prefer_st_loss_offset(self):
        """User has ST gains, LIFO produces ST loss → prefer LIFO."""
        tp = self._make_tax_position(st_gains=9200.0)
        selections = {
            "FIFO": self._make_selection("FIFO", st_gain_loss=1750.0),
            "HIFO": self._make_selection("HIFO", lt_gain_loss=3400.0),
            "LIFO": self._make_selection("LIFO", st_gain_loss=-750.0),
        }
        rec = recommend_lot_method(selections, tp)

        assert rec.preferred_method == "LIFO"
        assert rec.reason == "st_loss_offset"
        assert rec.has_wash_risk is False

    def test_st_loss_with_wash_risk_falls_through(self):
        """LIFO produces ST loss but has wash risk → flag + fallback."""
        tp = self._make_tax_position(st_gains=9200.0)
        selections = {
            "FIFO": self._make_selection("FIFO", st_gain_loss=1750.0),
            "HIFO": self._make_selection("HIFO", lt_gain_loss=3400.0),
            "LIFO": self._make_selection("LIFO", st_gain_loss=-750.0, wash_sale_risk=True),
        }
        rec = recommend_lot_method(selections, tp, safe_sell_date=date(2026, 1, 15))

        assert rec.preferred_method == "LIFO"
        assert rec.reason == "st_loss_offset"
        assert rec.has_wash_risk is True
        assert rec.safe_sell_date == date(2026, 1, 15)
        assert rec.fallback_method is not None

    def test_prefer_lt_gain_over_st_gain(self):
        """No losses available, HIFO is LT gain, FIFO is ST gain → prefer HIFO."""
        tp = self._make_tax_position(st_gains=5000.0)
        selections = {
            "FIFO": self._make_selection("FIFO", st_gain_loss=1750.0),
            "HIFO": self._make_selection("HIFO", lt_gain_loss=500.0),
            "LIFO": self._make_selection("LIFO", st_gain_loss=3000.0),
        }
        rec = recommend_lot_method(selections, tp)

        assert rec.preferred_method == "HIFO"
        assert rec.reason == "lt_lower_rate"

    def test_prefer_smallest_gain(self):
        """All methods produce ST gains → prefer smallest."""
        tp = self._make_tax_position(st_gains=5000.0)
        selections = {
            "FIFO": self._make_selection("FIFO", st_gain_loss=1750.0),
            "HIFO": self._make_selection("HIFO", st_gain_loss=500.0),
            "LIFO": self._make_selection("LIFO", st_gain_loss=3000.0),
        }
        rec = recommend_lot_method(selections, tp)

        assert rec.preferred_method == "HIFO"
        assert rec.reason == "least_gain"

    def test_all_methods_produce_same_treatment_prefer_smallest(self):
        """All LT gains → prefer smallest."""
        tp = self._make_tax_position()
        selections = {
            "FIFO": self._make_selection("FIFO", lt_gain_loss=2000.0),
            "HIFO": self._make_selection("HIFO", lt_gain_loss=800.0),
            "LIFO": self._make_selection("LIFO", lt_gain_loss=1500.0),
        }
        rec = recommend_lot_method(selections, tp)

        assert rec.preferred_method == "HIFO"
        assert rec.reason == "least_gain"

    def test_all_methods_have_wash_risk(self):
        """All methods produce losses with wash risk → no clean option."""
        tp = self._make_tax_position(st_gains=5000.0)
        selections = {
            "FIFO": self._make_selection("FIFO", st_gain_loss=-500.0, wash_sale_risk=True),
            "HIFO": self._make_selection("HIFO", st_gain_loss=-1000.0, wash_sale_risk=True),
            "LIFO": self._make_selection("LIFO", st_gain_loss=-750.0, wash_sale_risk=True),
        }
        rec = recommend_lot_method(selections, tp, safe_sell_date=date(2026, 1, 15))

        assert rec.has_wash_risk is True
        assert rec.fallback_method is None

    def test_tiebreak_fifo(self):
        """All methods produce identical results → prefer FIFO."""
        tp = self._make_tax_position()
        selections = {
            "FIFO": self._make_selection("FIFO", st_gain_loss=1000.0),
            "HIFO": self._make_selection("HIFO", st_gain_loss=1000.0),
            "LIFO": self._make_selection("LIFO", st_gain_loss=1000.0),
        }
        rec = recommend_lot_method(selections, tp)

        assert rec.preferred_method == "FIFO"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/engine/test_tax_position.py::TestRecommendLotMethod -v`
Expected: FAIL — `ImportError`

- [ ] **Step 3: Implement `recommend_lot_method`**

Add to `src/net_alpha/engine/tax_position.py`:

```python
from net_alpha.models.domain import (
    AllocationResult,
    LotRecommendation,
    LotSelection,
    OpenLot,
    RealizedPair,
    TaxPosition,
    Trade,
)


def recommend_lot_method(
    selections: dict[str, LotSelection],
    tax_position: TaxPosition,
    safe_sell_date: date | None = None,
) -> LotRecommendation:
    """Rule-based decision tree for lot method recommendation.

    Priority:
    1. ST loss offset (if user has net ST gains)
    2. If preferred has wash risk → flag, suggest wait, find fallback
    3. Prefer LT gain over ST gain (lower tax rate)
    4. Prefer smaller total gain
    5. Tiebreak: FIFO
    """
    has_st_gains = tax_position.net_st > 0

    # Separate into loss-producers and gain-producers
    st_loss_methods = {
        m: s for m, s in selections.items()
        if s.st_gain_loss < 0 or s.lt_gain_loss < 0
    }
    clean_st_loss_methods = {
        m: s for m, s in st_loss_methods.items() if not s.wash_sale_risk
    }
    gain_methods = {
        m: s for m, s in selections.items()
        if m not in st_loss_methods
    }

    # Rule 1: prefer ST loss offset if user has ST gains
    if has_st_gains and st_loss_methods:
        # Pick the method with the largest ST loss (most offset)
        best_loss_method = min(
            st_loss_methods.keys(),
            key=lambda m: st_loss_methods[m].total_gain_loss,
        )
        best = st_loss_methods[best_loss_method]

        if best.wash_sale_risk:
            # Find fallback: best clean option
            fallback = _find_fallback(selections, st_loss_methods)
            return LotRecommendation(
                preferred_method=best_loss_method,
                reason="st_loss_offset",
                has_wash_risk=True,
                safe_sell_date=safe_sell_date,
                fallback_method=fallback[0] if fallback else None,
                fallback_reason=fallback[1] if fallback else None,
            )
        else:
            return LotRecommendation(
                preferred_method=best_loss_method,
                reason="st_loss_offset",
                has_wash_risk=False,
                safe_sell_date=None,
                fallback_method=None,
                fallback_reason=None,
            )

    # Rule 2: no losses available — prefer LT gain over ST gain
    # Check if any method produces only LT gains (no ST component)
    lt_only = {
        m: s for m, s in selections.items()
        if s.lt_gain_loss > 0 and s.st_gain_loss <= 0 and not s.wash_sale_risk
    }
    if lt_only:
        best_lt = min(lt_only.keys(), key=lambda m: lt_only[m].total_gain_loss)
        # Only prefer LT if there are also ST-gain methods to compare against
        st_methods = {m: s for m, s in selections.items() if s.st_gain_loss > 0}
        if st_methods:
            return LotRecommendation(
                preferred_method=best_lt,
                reason="lt_lower_rate",
                has_wash_risk=False,
                safe_sell_date=None,
                fallback_method=None,
                fallback_reason=None,
            )

    # Rule 3: prefer smallest total gain
    clean_methods = {m: s for m, s in selections.items() if not s.wash_sale_risk}
    if clean_methods:
        best = min(clean_methods.keys(), key=lambda m: clean_methods[m].total_gain_loss)
        return LotRecommendation(
            preferred_method=best,
            reason="least_gain",
            has_wash_risk=False,
            safe_sell_date=None,
            fallback_method=None,
            fallback_reason=None,
        )

    # Rule 4: all have wash risk
    best = min(selections.keys(), key=lambda m: selections[m].total_gain_loss)
    return LotRecommendation(
        preferred_method=best,
        reason="st_loss_offset" if selections[best].total_gain_loss < 0 else "least_gain",
        has_wash_risk=True,
        safe_sell_date=safe_sell_date,
        fallback_method=None,
        fallback_reason=None,
    )


def _find_fallback(
    all_selections: dict[str, LotSelection],
    exclude: dict[str, LotSelection],
) -> tuple[str, str] | None:
    """Find the best clean (no wash risk) fallback method."""
    clean = {
        m: s for m, s in all_selections.items()
        if m not in exclude and not s.wash_sale_risk
    }
    if not clean:
        # Check if any of the excluded methods have clean alternatives
        clean = {
            m: s for m, s in all_selections.items() if not s.wash_sale_risk
        }
    if not clean:
        return None

    # Prefer LT gain, then smallest gain, tiebreak FIFO
    lt_clean = {m: s for m, s in clean.items() if s.lt_gain_loss > 0 and s.st_gain_loss <= 0}
    if lt_clean:
        best = min(lt_clean.keys(), key=lambda m: lt_clean[m].total_gain_loss)
        return (best, "lt_lower_rate")

    best = min(clean.keys(), key=lambda m: clean[m].total_gain_loss)
    return (best, "least_gain")
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_tax_position.py::TestRecommendLotMethod -v`
Expected: ALL PASS

- [ ] **Step 5: Run full test suite**

Run: `uv run pytest --tb=short`
Expected: ALL PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/engine/tax_position.py tests/engine/test_tax_position.py
git commit -m "feat: implement recommend_lot_method decision tree

Rule-based: ST loss offset > LT preference > smallest gain > FIFO.
Handles wash risk with fallback method. Returns structured
LotRecommendation with reason codes."
```

---

### Task 9: Implement `tax-position` CLI Command

**Files:**
- Create: `src/net_alpha/cli/tax_position.py`
- Modify: `src/net_alpha/cli/app.py`
- Create: `tests/cli/test_tax_position.py`

- [ ] **Step 1: Write CLI tests**

Create `tests/cli/test_tax_position.py`:

```python
from datetime import date
from unittest.mock import patch

from typer.testing import CliRunner

from net_alpha.cli.app import app
from net_alpha.models.domain import OpenLot, TaxPosition

runner = CliRunner()


class TestTaxPositionCommand:
    @patch("net_alpha.cli.tax_position._load_trades_and_compute")
    def test_basic_output(self, mock_load):
        """Renders tax position and open lots."""
        mock_load.return_value = (
            TaxPosition(
                st_gains=12400.0, st_losses=3200.0,
                lt_gains=8100.0, lt_losses=500.0,
                year=2026, basis_unknown_count=0,
            ),
            [
                OpenLot(
                    ticker="AAPL", account="Schwab", quantity=50.0,
                    adjusted_basis_per_share=145.0, purchase_date=date(2025, 6, 1),
                    days_held=315, days_to_long_term=50, basis_unknown=False, is_option=False,
                ),
            ],
        )
        result = runner.invoke(app, ["tax-position", "--year", "2026"])

        assert result.exit_code == 0
        assert "TAX POSITION" in result.output
        assert "$12,400.00" in result.output
        assert "$3,200.00" in result.output
        assert "$8,100.00" in result.output
        assert "AAPL" in result.output
        assert "Schwab" in result.output
        assert "50 days" in result.output
        assert "consult a tax professional" in result.output.lower() or "informational only" in result.output.lower()

    @patch("net_alpha.cli.tax_position._load_trades_and_compute")
    def test_carryforward_shown_when_above_3000(self, mock_load):
        mock_load.return_value = (
            TaxPosition(
                st_gains=0.0, st_losses=4800.0,
                lt_gains=0.0, lt_losses=0.0,
                year=2026, basis_unknown_count=0,
            ),
            [],
        )
        result = runner.invoke(app, ["tax-position", "--year", "2026"])

        assert "carryforward" in result.output.lower() or "carry" in result.output.lower()
        assert "$1,800.00" in result.output

    @patch("net_alpha.cli.tax_position._load_trades_and_compute")
    def test_carryforward_hidden_when_under_3000(self, mock_load):
        mock_load.return_value = (
            TaxPosition(
                st_gains=0.0, st_losses=2000.0,
                lt_gains=0.0, lt_losses=0.0,
                year=2026, basis_unknown_count=0,
            ),
            [],
        )
        result = runner.invoke(app, ["tax-position", "--year", "2026"])

        assert "carryforward" not in result.output.lower()

    @patch("net_alpha.cli.tax_position._load_trades_and_compute")
    def test_basis_unknown_warning(self, mock_load):
        mock_load.return_value = (
            TaxPosition(
                st_gains=300.0, st_losses=0.0,
                lt_gains=0.0, lt_losses=0.0,
                year=2026, basis_unknown_count=3,
            ),
            [],
        )
        result = runner.invoke(app, ["tax-position", "--year", "2026"])

        assert "3" in result.output
        assert "unknown" in result.output.lower()

    @patch("net_alpha.cli.tax_position._load_trades_and_compute")
    def test_long_term_lots_shown(self, mock_load):
        mock_load.return_value = (
            TaxPosition(
                st_gains=0.0, st_losses=0.0,
                lt_gains=0.0, lt_losses=0.0,
                year=2026, basis_unknown_count=0,
            ),
            [
                OpenLot(
                    ticker="TSLA", account="Robinhood", quantity=20.0,
                    adjusted_basis_per_share=210.0, purchase_date=date(2025, 3, 1),
                    days_held=390, days_to_long_term=0, basis_unknown=False, is_option=False,
                ),
            ],
        )
        result = runner.invoke(app, ["tax-position", "--year", "2026"])

        assert "TSLA" in result.output
        assert "Long-term" in result.output or "long-term" in result.output or "✓" in result.output

    @patch("net_alpha.cli.tax_position._load_trades_and_compute")
    def test_basis_unknown_lot_shown_as_unknown(self, mock_load):
        mock_load.return_value = (
            TaxPosition(
                st_gains=0.0, st_losses=0.0,
                lt_gains=0.0, lt_losses=0.0,
                year=2026, basis_unknown_count=0,
            ),
            [
                OpenLot(
                    ticker="MSFT", account="Schwab", quantity=10.0,
                    adjusted_basis_per_share=0.0, purchase_date=date(2025, 6, 1),
                    days_held=317, days_to_long_term=49, basis_unknown=True, is_option=False,
                ),
            ],
        )
        result = runner.invoke(app, ["tax-position", "--year", "2026"])

        assert "Unknown" in result.output or "unknown" in result.output
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/cli/test_tax_position.py -v`
Expected: FAIL — module doesn't exist

- [ ] **Step 3: Implement the CLI command**

Create `src/net_alpha/cli/tax_position.py`:

```python
from __future__ import annotations

from datetime import date

import typer
from rich.console import Console
from rich.table import Table

from net_alpha.cli.output import format_currency, print_disclaimer
from net_alpha.models.domain import OpenLot, TaxPosition

console = Console()


def tax_position_command(
    year: int | None = typer.Option(None, help="Tax year (default: current)"),
) -> None:
    """Show YTD tax position and open lot holding periods."""
    scan_year = year or date.today().year

    tp, open_lots = _load_trades_and_compute(scan_year)

    _render_tax_position(tp)
    _render_open_lots(open_lots)

    if tp.basis_unknown_count > 0:
        console.print(
            f"\n  [yellow]{tp.basis_unknown_count} sell(s) excluded due to "
            "unknown cost basis.[/yellow]"
        )

    print_disclaimer(console)


def _load_trades_and_compute(year: int) -> tuple[TaxPosition, list[OpenLot]]:
    """Load trades from DB, compute tax position and open lots."""
    from net_alpha.cli.app import _bootstrap
    from net_alpha.db.repository import TradeRepository
    from net_alpha.engine.tax_position import compute_tax_position, identify_open_lots

    settings, session = _bootstrap()
    trade_repo = TradeRepository(session)
    all_trades = trade_repo.list_all()

    if not all_trades:
        console.print("  No trades imported yet. Run [bold]net-alpha import[/bold] first.")
        session.close()
        raise typer.Exit()

    tp = compute_tax_position(all_trades, year=year)
    open_lots = identify_open_lots(all_trades, as_of=date.today())
    session.close()
    return tp, open_lots


def _render_tax_position(tp: TaxPosition) -> None:
    console.print()
    console.print(f"  [bold]TAX POSITION — {tp.year} (all accounts)[/bold]")
    console.print("  " + "\u2500" * 50)
    console.print(f"  Short-term gains:          {format_currency(tp.st_gains):>12s}")
    console.print(f"  Short-term losses:         {format_currency(-tp.st_losses):>12s}")
    console.print(f"  Net short-term:            {format_currency(tp.net_st):>12s}   (taxed at ordinary income rates)")
    console.print()
    console.print(f"  Long-term gains:           {format_currency(tp.lt_gains):>12s}")
    console.print(f"  Long-term losses:          {format_currency(-tp.lt_losses):>12s}")
    console.print(f"  Net long-term:             {format_currency(tp.net_lt):>12s}   (taxed at preferential rates)")
    console.print()
    console.print("  " + "\u2500" * 50)
    console.print(f"  Net capital gain:          {format_currency(tp.net_capital_gain):>12s}")

    if tp.net_st > 0:
        console.print(f"  Loss still needed to zero short-term:  {format_currency(tp.loss_needed_to_zero_st)}")

    if tp.carryforward > 0:
        console.print(f"  Loss carryforward (above $3,000 cap):  {format_currency(tp.carryforward)}")


def _render_open_lots(open_lots: list[OpenLot]) -> None:
    if not open_lots:
        return

    console.print()
    console.print("  [bold]OPEN LOTS — Holding Period Tracker[/bold]")
    console.print("  " + "\u2500" * 50)

    table = Table(box=None, padding=(0, 2), show_edge=False)
    table.add_column("Ticker")
    table.add_column("Account")
    table.add_column("Qty", justify="right")
    table.add_column("Adj.Basis/sh", justify="right")
    table.add_column("Held")
    table.add_column("Days to Long-Term")

    for lot in open_lots:
        basis_str = "Unknown" if lot.basis_unknown else format_currency(lot.adjusted_basis_per_share)
        held_str = f"{lot.days_held}d"

        if lot.days_to_long_term == 0:
            lt_str = "Long-term \u2713"
        else:
            lt_str = f"{lot.days_to_long_term} days"

        table.add_row(
            lot.ticker,
            lot.account,
            str(int(lot.quantity)),
            basis_str,
            held_str,
            lt_str,
        )

    console.print(table)
```

- [ ] **Step 4: Register the command in `app.py`**

In `src/net_alpha/cli/app.py`, add the import and registration:

Add import at the top with the other CLI imports:
```python
from net_alpha.cli.tax_position import tax_position_command
```

Add registration after the existing commands:
```python
app.command(name="tax-position")(tax_position_command)
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/cli/test_tax_position.py -v`
Expected: ALL PASS

- [ ] **Step 6: Run full test suite**

Run: `uv run pytest --tb=short`
Expected: ALL PASS

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/cli/tax_position.py src/net_alpha/cli/app.py tests/cli/test_tax_position.py
git commit -m "feat: add tax-position CLI command

Shows YTD realized ST/LT gains and losses, net capital position,
loss-to-zero-st, carryforward, and open lots with holding period
tracker. Sorted by days-to-long-term ascending."
```

---

### Task 10: Enhance `simulate sell` with Lot Selection

**Files:**
- Modify: `src/net_alpha/cli/simulate.py`
- Create: `tests/cli/test_simulate_lots.py`

- [ ] **Step 1: Write tests for lot selection rendering**

Create `tests/cli/test_simulate_lots.py`:

```python
from datetime import date
from unittest.mock import patch

from typer.testing import CliRunner

from net_alpha.cli.app import app
from net_alpha.models.domain import (
    LotRecommendation,
    LotSelection,
    OpenLot,
    TaxPosition,
)

runner = CliRunner()


def _make_open_lot(ticker="AAPL", account="Schwab", qty=50.0, basis=145.0,
                    purchase_date=date(2025, 8, 15), days_held=242, days_to_lt=124):
    return OpenLot(
        ticker=ticker, account=account, quantity=qty,
        adjusted_basis_per_share=basis, purchase_date=purchase_date,
        days_held=days_held, days_to_long_term=days_to_lt,
        basis_unknown=False, is_option=False,
    )


class TestSimulateSellLotSelection:
    @patch("net_alpha.cli.simulate._get_lot_selection_data")
    @patch("net_alpha.cli.simulate._find_lookback_triggers")
    @patch("net_alpha.cli.simulate._bootstrap_and_load")
    def test_lot_table_shown_when_price_given(self, mock_boot, mock_lookback, mock_lots):
        mock_boot.return_value = ([], {}, None)
        mock_lookback.return_value = []
        mock_lots.return_value = (
            {
                "FIFO": LotSelection(
                    method="FIFO", lots_used=[_make_open_lot()],
                    st_gain_loss=1750.0, lt_gain_loss=0.0,
                    total_gain_loss=1750.0, wash_sale_risk=False,
                ),
                "HIFO": LotSelection(
                    method="HIFO", lots_used=[_make_open_lot(basis=112.0)],
                    st_gain_loss=0.0, lt_gain_loss=3400.0,
                    total_gain_loss=3400.0, wash_sale_risk=False,
                ),
                "LIFO": LotSelection(
                    method="LIFO", lots_used=[_make_open_lot(basis=195.0)],
                    st_gain_loss=-750.0, lt_gain_loss=0.0,
                    total_gain_loss=-750.0, wash_sale_risk=False,
                ),
            },
            LotRecommendation(
                preferred_method="LIFO", reason="st_loss_offset",
                has_wash_risk=False, safe_sell_date=None,
                fallback_method=None, fallback_reason=None,
            ),
        )
        result = runner.invoke(app, ["simulate", "sell", "AAPL", "50", "--price", "180"])

        assert result.exit_code == 0
        assert "LOT SELECTION" in result.output
        assert "FIFO" in result.output
        assert "HIFO" in result.output
        assert "LIFO" in result.output
        assert "Recommendation" in result.output

    @patch("net_alpha.cli.simulate._find_lookback_triggers")
    @patch("net_alpha.cli.simulate._bootstrap_and_load")
    def test_lot_table_not_shown_without_price(self, mock_boot, mock_lookback):
        mock_boot.return_value = ([], {}, None)
        mock_lookback.return_value = []
        result = runner.invoke(app, ["simulate", "sell", "AAPL", "50"])

        assert result.exit_code == 0
        assert "LOT SELECTION" not in result.output

    @patch("net_alpha.cli.simulate._get_lot_selection_data")
    @patch("net_alpha.cli.simulate._find_lookback_triggers")
    @patch("net_alpha.cli.simulate._bootstrap_and_load")
    def test_no_open_lots_message(self, mock_boot, mock_lookback, mock_lots):
        mock_boot.return_value = ([], {}, None)
        mock_lookback.return_value = []
        mock_lots.return_value = (None, None)
        result = runner.invoke(app, ["simulate", "sell", "AAPL", "50", "--price", "180"])

        assert result.exit_code == 0
        assert "No open lots" in result.output or "no open lots" in result.output

    @patch("net_alpha.cli.simulate._get_lot_selection_data")
    @patch("net_alpha.cli.simulate._find_lookback_triggers")
    @patch("net_alpha.cli.simulate._bootstrap_and_load")
    def test_wash_risk_shown_in_table(self, mock_boot, mock_lookback, mock_lots):
        mock_boot.return_value = ([], {}, None)
        mock_lookback.return_value = []
        mock_lots.return_value = (
            {
                "FIFO": LotSelection(
                    method="FIFO", lots_used=[_make_open_lot()],
                    st_gain_loss=1750.0, lt_gain_loss=0.0,
                    total_gain_loss=1750.0, wash_sale_risk=False,
                ),
                "HIFO": LotSelection(
                    method="HIFO", lots_used=[_make_open_lot(basis=112.0)],
                    st_gain_loss=0.0, lt_gain_loss=3400.0,
                    total_gain_loss=3400.0, wash_sale_risk=False,
                ),
                "LIFO": LotSelection(
                    method="LIFO", lots_used=[_make_open_lot(basis=195.0)],
                    st_gain_loss=-750.0, lt_gain_loss=0.0,
                    total_gain_loss=-750.0, wash_sale_risk=True,
                ),
            },
            LotRecommendation(
                preferred_method="LIFO", reason="st_loss_offset",
                has_wash_risk=True, safe_sell_date=date(2026, 1, 15),
                fallback_method="FIFO", fallback_reason="least_gain",
            ),
        )
        result = runner.invoke(app, ["simulate", "sell", "AAPL", "50", "--price", "180"])

        assert "Risk" in result.output or "⚠" in result.output
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/cli/test_simulate_lots.py -v`
Expected: FAIL — mock targets don't exist yet

- [ ] **Step 3: Refactor `simulate.py` — extract `_bootstrap_and_load` and add `_get_lot_selection_data`**

Modify `src/net_alpha/cli/simulate.py`. The full file after modifications:

```python
from __future__ import annotations

from datetime import date, timedelta

import typer
from rich.console import Console
from rich.table import Table

from net_alpha.cli.output import format_currency, print_disclaimer
from net_alpha.engine.matcher import get_match_confidence, is_within_wash_sale_window

console = Console()

simulate_app = typer.Typer(help="Pre-trade simulation")


@simulate_app.command(name="sell")
def sell_command(
    ticker: str = typer.Argument(help="Ticker to simulate selling"),
    qty: float = typer.Argument(help="Number of shares/contracts"),
    price: float | None = typer.Option(None, help="Sale price per share (for dollar impact)"),
) -> None:
    """Simulate selling a position and check for wash sale risk."""
    all_trades, etf_pairs, session = _bootstrap_and_load()

    today = date.today()
    ticker = ticker.upper()

    console.print()
    if price:
        console.print(f"  [bold]SIMULATION: Sell {int(qty)} {ticker} @ {format_currency(price)}[/bold]")
    else:
        console.print(f"  [bold]SIMULATION: Sell {int(qty)} {ticker}[/bold]")
    console.print("  " + "\u2500" * 50)

    # Check look-back: any buys of this ticker within last 30 days
    lookback_triggers = _find_lookback_triggers(ticker, today, all_trades, etf_pairs)

    if lookback_triggers:
        trigger = lookback_triggers[0]
        days_ago = (today - trigger.date).days
        safe = _compute_safe_date([t.date for t in lookback_triggers])
        days_until_safe = (safe - today).days

        estimated_loss = 0.0
        if price:
            total_proceeds = price * qty
            avg_basis = sum(t.cost_basis or 0 for t in lookback_triggers) / len(lookback_triggers)
            total_qty = sum(t.quantity for t in lookback_triggers)
            estimated_loss = max(0, avg_basis * qty / total_qty - total_proceeds)
            console.print(
                f"  [red]\u26a0 Wash sale would be triggered — "
                f"{format_currency(estimated_loss)} of this loss would be "
                f"DISALLOWED[/red]"
            )
        else:
            console.print("  [red]\u26a0 Wash sale would be triggered.[/red]")

        confidence = get_match_confidence(
            _make_dummy_sell(ticker, today, qty),
            trigger,
            etf_pairs,
        )
        console.print()
        console.print(
            f"  Reason: Bought {int(trigger.quantity)} {trigger.ticker} on "
            f"{trigger.account} ({trigger.date}) — {days_ago} days ago "
            f"[{confidence}]"
        )
        console.print(f"  Safe to sell cleanly: {safe} ({days_until_safe} days away)")

        if price and estimated_loss > 0:
            console.print(f"  Estimated recoverable loss (if waited): {format_currency(estimated_loss)}")
    else:
        safe_rebuy_date = today + timedelta(days=30)

        console.print("  [green]\u2713 No wash sale detected. Safe to sell.[/green]")
        console.print()
        console.print(
            f"  [yellow]\u26a0 Warning: any repurchase of {ticker} before "
            f"{safe_rebuy_date} would trigger a wash sale.[/yellow]"
        )

    # Lot selection table (only when price provided)
    if price:
        _render_lot_selection(ticker, qty, price, all_trades, etf_pairs, lookback_triggers, today)

    print_disclaimer(console)
    if session:
        session.close()


def _bootstrap_and_load() -> tuple[list, dict, object]:
    """Load trades and ETF pairs from DB. Returns (trades, etf_pairs, session)."""
    from net_alpha.cli.app import _bootstrap
    from net_alpha.db.repository import TradeRepository
    from net_alpha.engine.etf_pairs import load_etf_pairs

    settings, session = _bootstrap()
    trade_repo = TradeRepository(session)
    all_trades = trade_repo.list_all()

    user_pairs_path = settings.user_etf_pairs_path
    user_pairs = user_pairs_path if user_pairs_path.exists() else None
    etf_pairs = load_etf_pairs(user_pairs_path=user_pairs)

    return all_trades, etf_pairs, session


def _render_lot_selection(
    ticker: str,
    qty: float,
    price: float,
    all_trades: list,
    etf_pairs: dict,
    lookback_triggers: list,
    today: date,
) -> None:
    """Render lot selection comparison table and recommendation."""
    lot_data = _get_lot_selection_data(ticker, qty, price, all_trades, lookback_triggers, etf_pairs, today)
    selections, recommendation = lot_data

    if selections is None:
        console.print()
        console.print(f"  No open lots for {ticker}. Nothing to select.")
        return

    console.print()
    console.print(f"  [bold]LOT SELECTION — {ticker} {int(qty)} shares @ {format_currency(price)}[/bold]")
    console.print("  " + "\u2500" * 50)

    table = Table(box=None, padding=(0, 2), show_edge=False)
    table.add_column("Method")
    table.add_column("Lot Date")
    table.add_column("Qty", justify="right")
    table.add_column("Basis/sh", justify="right")
    table.add_column("Gain/Loss", justify="right")
    table.add_column("Treatment")
    table.add_column("Wash Sale")

    for method in ("FIFO", "HIFO", "LIFO"):
        sel = selections.get(method)
        if sel is None:
            continue

        # Show primary lot (first in list)
        for lot in sel.lots_used:
            treatment_parts = []
            if sel.st_gain_loss != 0:
                treatment_parts.append("Short-term")
            if sel.lt_gain_loss != 0:
                treatment_parts.append("Long-term")
            treatment = " + ".join(treatment_parts) if treatment_parts else "Short-term"

            wash_str = "\u26a0 Risk" if sel.wash_sale_risk else "None"

            gain_loss_str = format_currency(sel.total_gain_loss)
            if sel.total_gain_loss > 0:
                gain_loss_str = f"+{gain_loss_str}"

            table.add_row(
                method,
                str(lot.purchase_date),
                str(int(lot.quantity)),
                format_currency(lot.adjusted_basis_per_share),
                gain_loss_str,
                treatment,
                wash_str,
            )
            method = ""  # Don't repeat method name for subsequent lots

    console.print(table)

    # Recommendation
    if recommendation:
        _render_recommendation(recommendation, selections)


def _render_recommendation(
    rec,
    selections: dict,
) -> None:
    """Render the recommendation text from structured LotRecommendation."""
    console.print()
    console.print("  [bold]Recommendation[/bold] (given your YTD position):")

    reason_text = {
        "st_loss_offset": "produces a short-term loss to offset your gains",
        "lt_lower_rate": "produces a long-term gain (lower tax rate)",
        "least_gain": "produces the least additional gain",
    }

    preferred = rec.preferred_method
    sel = selections.get(preferred)
    reason = reason_text.get(rec.reason, rec.reason)

    if rec.has_wash_risk:
        console.print(f"    \u2192 {preferred} {reason} — but wash sale risk detected.")
        if rec.safe_sell_date:
            console.print(f"      Wait until {rec.safe_sell_date} to sell cleanly using {preferred}.")
        if rec.fallback_method:
            fallback_reason = reason_text.get(rec.fallback_reason, rec.fallback_reason)
            console.print(f"    \u2192 Best clean option: {rec.fallback_method} — {fallback_reason}.")
        elif rec.fallback_method is None:
            console.print("    \u2192 No clean option available — all methods carry wash sale risk.")
    else:
        console.print(f"    \u2192 {preferred} {reason}.")


def _get_lot_selection_data(
    ticker: str,
    qty: float,
    price: float,
    all_trades: list,
    lookback_triggers: list,
    etf_pairs: dict,
    today: date,
) -> tuple:
    """Compute lot selections and recommendation. Returns (selections_dict, recommendation) or (None, None)."""
    from net_alpha.engine.tax_position import (
        compute_tax_position,
        identify_open_lots,
        recommend_lot_method,
        select_lots,
    )

    open_lots = identify_open_lots(all_trades, as_of=today)

    # Check if any open lots exist for this ticker
    ticker_lots = [lot for lot in open_lots if lot.ticker == ticker]
    if not ticker_lots:
        return (None, None)

    # Note if ticker has option trades (options excluded from lot selection)
    has_option_trades = any(t.is_option() and t.ticker == ticker for t in all_trades)
    if has_option_trades:
        console.print(f"\n  [dim]Note: {ticker} has option trades not shown in lot selection.[/dim]")

    total_available = sum(lot.quantity for lot in ticker_lots)
    if total_available < qty:
        console.print()
        console.print(f"  Only {int(total_available)} shares available across open lots for {ticker}.")
        return (None, None)

    # Run all three methods
    selections = {}
    for method in ("FIFO", "HIFO", "LIFO"):
        sel = select_lots(open_lots, ticker, qty, method, price)
        if sel is not None:
            # Set wash sale risk: loss + look-back triggers
            if sel.total_gain_loss < 0 and lookback_triggers:
                sel = sel.model_copy(update={"wash_sale_risk": True})
            selections[method] = sel

    if not selections:
        return (None, None)

    # Compute tax position for recommendation
    tp = compute_tax_position(all_trades, year=today.year)

    # Compute safe sell date from lookback triggers
    safe_sell_date = None
    if lookback_triggers:
        safe_sell_date = _compute_safe_date([t.date for t in lookback_triggers])

    rec = recommend_lot_method(selections, tp, safe_sell_date=safe_sell_date)

    return (selections, rec)


def _find_lookback_triggers(
    ticker: str,
    sell_date: date,
    all_trades: list,
    etf_pairs: dict[str, list[str]],
) -> list:
    """Find buy trades within the 30-day look-back window for the ticker."""
    triggers = []
    dummy_sell = _make_dummy_sell(ticker, sell_date, 1.0)

    for t in all_trades:
        if not t.is_buy():
            continue
        if not is_within_wash_sale_window(sell_date, t.date):
            continue
        if t.date > sell_date:
            continue  # Look-back only (before sell date)
        confidence = get_match_confidence(dummy_sell, t, etf_pairs)
        if confidence is not None:
            triggers.append(t)

    triggers.sort(key=lambda t: t.date, reverse=True)
    return triggers


def _compute_safe_date(buy_dates: list[date]) -> date:
    """Compute the earliest safe sell date (30 days after the latest buy)."""
    latest = max(buy_dates)
    return latest + timedelta(days=30)


def _make_dummy_sell(ticker: str, sell_date: date, qty: float):
    """Create a dummy sell trade for confidence matching."""
    from net_alpha.models.domain import Trade

    return Trade(
        account="__simulation__",
        date=sell_date,
        ticker=ticker,
        action="Sell",
        quantity=qty,
        proceeds=0.0,
        cost_basis=1.0,
    )
```

- [ ] **Step 4: Run lot selection tests**

Run: `uv run pytest tests/cli/test_simulate_lots.py -v`
Expected: ALL PASS

- [ ] **Step 5: Run existing simulate tests to check for regressions**

Run: `uv run pytest tests/cli/test_simulate.py -v`
Expected: ALL PASS — existing tests should still pass since `_find_lookback_triggers` and `_compute_safe_date` signatures are unchanged

- [ ] **Step 6: Run full test suite**

Run: `uv run pytest --tb=short`
Expected: ALL PASS

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/cli/simulate.py tests/cli/test_simulate_lots.py
git commit -m "feat: enhance simulate sell with lot selection comparison

When --price is given, shows FIFO/HIFO/LIFO comparison table with
ST/LT gain/loss split, wash sale risk flags, and tax-aware
recommendation. Reuses existing wash sale check logic."
```

---

### Task 11: Lint and Final Verification

**Files:**
- All modified/created files

- [ ] **Step 1: Run linter**

Run: `uv run ruff check .`
Expected: No errors. If errors, fix them.

- [ ] **Step 2: Run formatter**

Run: `uv run ruff format .`
Expected: Files formatted (or already formatted).

- [ ] **Step 3: Run full test suite with coverage**

Run: `uv run pytest --tb=short -q`
Expected: ALL PASS, no failures

- [ ] **Step 4: Verify no regressions in existing tests**

Run: `uv run pytest tests/engine/test_detector.py tests/cli/test_simulate.py tests/cli/test_check.py tests/models/test_domain.py -v`
Expected: ALL PASS

- [ ] **Step 5: Commit any lint fixes**

```bash
git add -u
git commit -m "style: fix lint and formatting for tax optimization suite"
```

(Skip this commit if no changes were needed.)
