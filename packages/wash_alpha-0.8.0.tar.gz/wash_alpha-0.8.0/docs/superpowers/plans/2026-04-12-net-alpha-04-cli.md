# net_alpha CLI Interface — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Implement all CLI commands using Typer with rich output: import, check, simulate, rebuys, report, and the first-run wizard.

**Architecture:** Each command is a function registered on a Typer app. Commands load settings, initialize the database, run the engine, and format output using `rich` tables. The first-run wizard uses `questionary` for interactive prompts. Every command output ends with the mandatory disclaimer.

**Tech Stack:** Python 3.11+, Typer, Rich, Questionary, pytest

**Dependencies:** Plans 1 (Core Engine), 2 (Storage Layer), and 3 (CSV Import) must be completed first.

---

## File Structure

| Action | Path | Responsibility |
|--------|------|----------------|
| Create | `src/net_alpha/cli/__init__.py` | CLI sub-package |
| Create | `src/net_alpha/cli/app.py` | Main Typer app, entry point, first-run routing |
| Create | `src/net_alpha/cli/output.py` | Rich formatters, disclaimer, table builders |
| Create | `src/net_alpha/cli/import_cmd.py` | `import` command |
| Create | `src/net_alpha/cli/check.py` | `check` command |
| Create | `src/net_alpha/cli/simulate.py` | `simulate sell` command |
| Create | `src/net_alpha/cli/rebuys.py` | `rebuys` command |
| Create | `src/net_alpha/cli/report.py` | `report` command |
| Create | `src/net_alpha/cli/wizard.py` | First-run interactive wizard |
| Create | `tests/cli/__init__.py` | Tests sub-package |
| Create | `tests/cli/test_output.py` | Output formatting tests |
| Create | `tests/cli/test_check.py` | Check command tests |
| Create | `tests/cli/test_simulate.py` | Simulate command tests |
| Create | `tests/integration/cli/test_import.py` | Import command tests |

---

### Task 1: Output Helpers and Disclaimer

**Files:**
- Create: `src/net_alpha/cli/__init__.py`
- Create: `src/net_alpha/cli/output.py`
- Create: `tests/cli/__init__.py`
- Create: `tests/cli/test_output.py`

- [ ] **Step 1: Create package directories**

```bash
mkdir -p src/net_alpha/cli tests/cli
touch src/net_alpha/cli/__init__.py tests/cli/__init__.py
```

- [ ] **Step 2: Write the failing tests**

```python
# tests/cli/test_output.py
from io import StringIO

from rich.console import Console

from net_alpha.cli.output import (
    DISCLAIMER,
    format_currency,
    print_disclaimer,
    confidence_style,
)


def test_disclaimer_text():
    assert "informational only" in DISCLAIMER
    assert "tax professional" in DISCLAIMER


def test_print_disclaimer():
    buf = StringIO()
    console = Console(file=buf, no_color=True)
    print_disclaimer(console)
    output = buf.getvalue()
    assert "informational only" in output


def test_format_currency():
    assert format_currency(1200.0) == "$1,200.00"
    assert format_currency(0.0) == "$0.00"
    assert format_currency(50.5) == "$50.50"
    assert format_currency(1234567.89) == "$1,234,567.89"


def test_format_currency_with_parens():
    assert format_currency(-1200.0) == "($1,200.00)"


def test_confidence_style():
    assert confidence_style("Confirmed") == "bold red"
    assert confidence_style("Probable") == "bold yellow"
    assert confidence_style("Unclear") == "bold blue"
    assert confidence_style("Unknown") == ""
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `uv run pytest tests/cli/test_output.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 4: Write the implementation**

```python
# src/net_alpha/cli/output.py
from __future__ import annotations

from rich.console import Console

DISCLAIMER = "\u26a0 This is informational only. Consult a tax professional before filing."


def print_disclaimer(console: Console) -> None:
    """Print the mandatory disclaimer at the end of every command output."""
    console.print()
    console.print(f"  {DISCLAIMER}", style="dim")


def format_currency(amount: float) -> str:
    """Format a dollar amount with commas and 2 decimal places."""
    if amount < 0:
        return f"(${abs(amount):,.2f})"
    return f"${amount:,.2f}"


def confidence_style(confidence: str) -> str:
    """Return the Rich style string for a confidence label."""
    return {
        "Confirmed": "bold red",
        "Probable": "bold yellow",
        "Unclear": "bold blue",
    }.get(confidence, "")
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/cli/test_output.py -v`
Expected: All 5 tests PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/cli/__init__.py src/net_alpha/cli/output.py tests/cli/__init__.py tests/cli/test_output.py
git commit -m "feat: add CLI output helpers and disclaimer"
```

---

### Task 2: App Entry Point and Database Bootstrap

**Files:**
- Create: `src/net_alpha/cli/app.py`

- [ ] **Step 1: Write the main app**

```python
# src/net_alpha/cli/app.py
from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from sqlmodel import Session

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.migrations import run_migrations

app = typer.Typer(
    name="net-alpha",
    help="Cross-account wash sale detection for equities, options, and ETFs.",
    no_args_is_help=False,
)
console = Console()


def _bootstrap() -> tuple[Settings, Session]:
    """Initialize settings, DB engine, run migrations, return (settings, session)."""
    settings = Settings()
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    engine = get_engine(settings.db_path)
    init_db(engine)
    run_migrations(engine)
    return settings, Session(engine)


@app.callback(invoke_without_command=True)
def main_callback(ctx: typer.Context):
    """Entry point — runs wizard if no command given and no trades exist."""
    if ctx.invoked_subcommand is not None:
        return

    settings, session = _bootstrap()
    from net_alpha.db.repository import TradeRepository

    repo = TradeRepository(session)
    trade_count = len(repo.list_all())
    session.close()

    if trade_count == 0:
        # First-run wizard
        from net_alpha.cli.wizard import run_wizard

        run_wizard(settings)
    else:
        # Show help if trades exist but no command given
        console.print(ctx.get_help())


def main():
    app()
```

- [ ] **Step 2: Verify the entry point works**

Run: `uv run net-alpha --help`
Expected: Shows help text with available commands

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/cli/app.py
git commit -m "feat: add Typer app entry point with DB bootstrap"
```

---

### Task 3: Import Command

**Files:**
- Create: `src/net_alpha/cli/import_cmd.py`
- Modify: `src/net_alpha/cli/app.py` (register command)

- [ ] **Step 1: Write the import command**

```python
# src/net_alpha/cli/import_cmd.py
from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from net_alpha.cli.output import print_disclaimer
from net_alpha.import_.schema_detection import SchemaMapping

console = Console()


def import_command(
    broker: str = typer.Argument(help="Broker name (e.g., schwab, robinhood)"),
    file: Path = typer.Argument(
        help="Path to CSV file", exists=True, readable=True, resolve_path=True
    ),
) -> None:
    """Import trades from a broker CSV file."""
    from anthropic import Anthropic
    from sqlmodel import Session

    from net_alpha.cli.app import _bootstrap
    from net_alpha.db.repository import SchemaCacheRepository, TradeRepository
    from net_alpha.import_.importer import ImportContext, run_import

    settings, session = _bootstrap()

    # Resolve API key
    api_key = settings.anthropic_api_key
    if not api_key:
        console.print(
            "[red]Error:[/red] ANTHROPIC_API_KEY not set. "
            "Set it via environment variable or in ~/.net_alpha/config.toml"
        )
        raise typer.Exit(1)

    client = Anthropic(api_key=api_key)

    ctx = ImportContext(
        csv_path=file,
        broker_name=broker.lower(),
        anthropic_client=client,
        model=settings.anthropic_model,
        max_retries=settings.llm_max_retries,
        confirm_schema=_confirm_schema,
        trade_repo=TradeRepository(session),
        schema_cache_repo=SchemaCacheRepository(session),
        session=session,
    )

    try:
        result = run_import(ctx)
    except RuntimeError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(1)
    finally:
        session.close()

    # Display results
    console.print()
    console.print(
        f"  Imported [bold]{result.new_imported}[/bold] trades from "
        f"[bold]{broker}[/bold] "
        f"({result.equities} equities, {result.options} options)"
    )
    if result.duplicates_skipped > 0:
        console.print(
            f"  {result.duplicates_skipped} duplicate trades skipped."
        )

    print_disclaimer(console)


def _confirm_schema(mapping: SchemaMapping, headers: list[str]) -> bool:
    """Display detected schema and ask user to confirm."""
    console.print()
    console.print("  Detected schema:")
    console.print("  " + "\u2500" * 40)

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Field", style="cyan")
    table.add_column("Column", style="white")
    table.add_column("Info", style="dim")

    table.add_row("date", f'"{mapping.date}"', "")
    table.add_row("ticker", f'"{mapping.ticker}"', "")
    table.add_row(
        "action",
        f'"{mapping.action}"',
        f"[buy: {', '.join(mapping.buy_values)}]  [sell: {', '.join(mapping.sell_values)}]",
    )
    table.add_row("quantity", f'"{mapping.quantity}"', "")
    if mapping.proceeds:
        table.add_row("proceeds", f'"{mapping.proceeds}"', "")
    if mapping.cost_basis:
        table.add_row("cost_basis", f'"{mapping.cost_basis}"', "")
    if mapping.option_format:
        table.add_row("options", f'"{mapping.option_format}"', "")

    console.print(table)
    console.print("  " + "\u2500" * 40)

    import questionary

    return questionary.confirm("Does this look correct?", default=True).ask()
```

- [ ] **Step 2: Register the command in app.py**

Add this import and registration to `src/net_alpha/cli/app.py`:

```python
# Add after app = typer.Typer(...) in app.py
from net_alpha.cli.import_cmd import import_command

app.command(name="import")(import_command)
```

- [ ] **Step 3: Verify the command shows up**

Run: `uv run net-alpha import --help`
Expected: Shows help for the import command with broker and file arguments

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/cli/import_cmd.py src/net_alpha/cli/app.py
git commit -m "feat: add CSV import command with schema confirmation"
```

---

### Task 4: Check Command

**Files:**
- Create: `src/net_alpha/cli/check.py`
- Modify: `src/net_alpha/cli/app.py` (register command)
- Create: `tests/cli/test_check.py`

- [ ] **Step 1: Write the failing tests**

```python
# tests/cli/test_check.py
from datetime import date

from net_alpha.cli.check import _build_summary, _filter_violations_by_year
from net_alpha.models.domain import Trade, WashSaleViolation


def test_build_summary():
    violations = [
        WashSaleViolation(
            loss_trade_id="t1", replacement_trade_id="t2",
            confidence="Confirmed", disallowed_loss=1200.0, matched_quantity=10.0,
        ),
        WashSaleViolation(
            loss_trade_id="t3", replacement_trade_id="t4",
            confidence="Probable", disallowed_loss=500.0, matched_quantity=5.0,
        ),
        WashSaleViolation(
            loss_trade_id="t5", replacement_trade_id="t6",
            confidence="Confirmed", disallowed_loss=800.0, matched_quantity=8.0,
        ),
    ]
    summary = _build_summary(violations)
    assert summary["Confirmed"]["count"] == 2
    assert summary["Confirmed"]["total"] == 2000.0
    assert summary["Probable"]["count"] == 1
    assert summary["Probable"]["total"] == 500.0
    assert summary["Unclear"]["count"] == 0


def test_filter_violations_by_year():
    trades = {
        "t1": Trade(account="A", date=date(2024, 10, 15), ticker="TSLA", action="Sell", quantity=10.0),
        "t2": Trade(account="B", date=date(2025, 1, 5), ticker="TSLA", action="Sell", quantity=5.0),
    }
    violations = [
        WashSaleViolation(
            loss_trade_id="t1", replacement_trade_id="x",
            confidence="Confirmed", disallowed_loss=100.0, matched_quantity=1.0,
        ),
        WashSaleViolation(
            loss_trade_id="t2", replacement_trade_id="y",
            confidence="Confirmed", disallowed_loss=200.0, matched_quantity=2.0,
        ),
    ]

    filtered = _filter_violations_by_year(violations, trades, 2024)
    assert len(filtered) == 1
    assert filtered[0].loss_trade_id == "t1"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/cli/test_check.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Write the implementation**

```python
# src/net_alpha/cli/check.py
from __future__ import annotations

from datetime import date, timedelta
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from net_alpha.cli.output import (
    confidence_style,
    format_currency,
    print_disclaimer,
)

console = Console()


def check_command(
    ticker: Optional[str] = typer.Option(None, help="Filter by ticker"),
    type: Optional[str] = typer.Option(None, help="Filter by type: equities, options"),
    year: Optional[int] = typer.Option(None, help="Tax year (default: current)"),
) -> None:
    """Scan all trades for wash sale violations."""
    from sqlmodel import Session

    from net_alpha.cli.app import _bootstrap
    from net_alpha.db.repository import TradeRepository, ViolationRepository, LotRepository
    from net_alpha.engine.detector import detect_wash_sales
    from net_alpha.engine.etf_pairs import load_etf_pairs

    settings, session = _bootstrap()
    trade_repo = TradeRepository(session)
    violation_repo = ViolationRepository(session)
    lot_repo = LotRepository(session)

    all_trades = trade_repo.list_all()
    if not all_trades:
        console.print("  No trades imported yet. Run [bold]net-alpha import[/bold] first.")
        session.close()
        return

    # Load ETF pairs
    user_pairs = settings.user_etf_pairs_path if settings.user_etf_pairs_path.exists() else None
    etf_pairs = load_etf_pairs(user_pairs_path=user_pairs)

    # Run detection
    result = detect_wash_sales(all_trades, etf_pairs)

    # Persist results (clear old, write new)
    violation_repo.delete_all()
    lot_repo.delete_all()
    violation_repo.save_batch(result.violations)
    lot_repo.save_batch(result.lots)
    session.commit()

    # Build trade lookup
    trade_map = {t.id: t for t in all_trades}

    # Filter by year
    scan_year = year or date.today().year
    violations = _filter_violations_by_year(result.violations, trade_map, scan_year)

    # Filter by ticker
    if ticker:
        violations = [
            v for v in violations if trade_map[v.loss_trade_id].ticker == ticker.upper()
        ]

    # Filter by type
    if type:
        if type.lower() == "options":
            violations = [v for v in violations if trade_map[v.loss_trade_id].is_option()]
        elif type.lower() == "equities":
            violations = [v for v in violations if not trade_map[v.loss_trade_id].is_option()]

    # Staleness warning
    _print_staleness_warnings(trade_repo, console)

    # Print summary
    _print_summary(violations, scan_year, console)

    # Print detail table
    if violations:
        _print_detail_table(violations, trade_map, console)

    # Rebuy hint
    rebuy_count = _count_rebuys(all_trades, result.violations, trade_map)
    if rebuy_count > 0:
        console.print(
            f"\n  {rebuy_count} positions safe to rebuy — run [bold]net-alpha rebuys[/bold] for details"
        )

    # Basis unknown warning
    if result.basis_unknown_count > 0:
        console.print(
            f"\n  [yellow]{result.basis_unknown_count} trades have no cost basis — "
            "disallowed loss amounts may be incomplete.[/yellow]"
        )

    # Option expiration warning
    if any(t.is_option() for t in all_trades):
        console.print(
            "\n  [dim]Note: option expirations missing from your broker CSV "
            "(e.g. Robinhood) will not appear as loss sales — wash sale "
            "exposure from expired options may be undetected.[/dim]"
        )

    print_disclaimer(console)
    session.close()


def _filter_violations_by_year(
    violations: list, trade_map: dict, year: int
) -> list:
    """Filter violations to those whose loss sale occurred in the given year."""
    return [
        v for v in violations
        if trade_map[v.loss_trade_id].date.year == year
    ]


def _build_summary(violations: list) -> dict:
    """Build count and total by confidence label."""
    summary = {
        "Confirmed": {"count": 0, "total": 0.0},
        "Probable": {"count": 0, "total": 0.0},
        "Unclear": {"count": 0, "total": 0.0},
    }
    for v in violations:
        if v.confidence in summary:
            summary[v.confidence]["count"] += 1
            summary[v.confidence]["total"] += v.disallowed_loss
    return summary


def _print_summary(violations: list, year: int, console: Console) -> None:
    summary = _build_summary(violations)
    total = sum(s["total"] for s in summary.values())

    console.print()
    console.print(f"  [bold]WASH SALE SUMMARY — {year} (all accounts)[/bold]")
    console.print("  " + "\u2500" * 50)

    for label in ("Confirmed", "Probable", "Unclear"):
        s = summary[label]
        if s["count"] > 0:
            style = confidence_style(label)
            note = "  (recommend CPA review)" if label != "Confirmed" else ""
            console.print(
                f"  [{style}]{label:12s}[/{style}] "
                f"{s['count']:>3d} violations    "
                f"{format_currency(s['total']):>12s} disallowed{note}"
            )

    console.print("  " + "\u2500" * 50)
    console.print(f"  Total disallowed loss:       {format_currency(total)}")


def _print_detail_table(violations: list, trade_map: dict, console: Console) -> None:
    console.print()
    console.print("  [bold]DETAIL[/bold]")

    table = Table(box=None, padding=(0, 2), show_edge=False)
    table.add_column("Date")
    table.add_column("Ticker")
    table.add_column("Account")
    table.add_column("Type")
    table.add_column("Loss", justify="right")
    table.add_column("Status")
    table.add_column("Disallowed", justify="right")

    for v in sorted(violations, key=lambda x: trade_map[x.loss_trade_id].date):
        loss_trade = trade_map[v.loss_trade_id]
        trade_type = "Option" if loss_trade.is_option() else "Equity"
        style = confidence_style(v.confidence)
        table.add_row(
            str(loss_trade.date),
            loss_trade.ticker,
            loss_trade.account,
            trade_type,
            format_currency(-loss_trade.loss_amount()),
            f"[{style}]{v.confidence}[/{style}]",
            format_currency(v.disallowed_loss),
        )

    console.print(table)


def _print_staleness_warnings(trade_repo, console: Console) -> None:
    """Warn if any account's latest trade is older than 30 days."""
    accounts = trade_repo.list_accounts()
    today = date.today()

    for account in accounts:
        latest = trade_repo.latest_trade_date_by_account(account)
        if latest:
            from datetime import date as date_type
            latest_date = date_type.fromisoformat(latest)
            days_ago = (today - latest_date).days
            if days_ago > 30:
                console.print(
                    f"\n  [yellow]\u26a0 {account} data last imported {days_ago} days ago.[/yellow]"
                    f"\n    Run [bold]net-alpha import {account.lower()} <file>[/bold] to update."
                )


def _count_rebuys(all_trades: list, violations: list, trade_map: dict) -> int:
    """Count loss sales with open rebuy windows (no triggering buy detected yet)."""
    today = date.today()
    matched_loss_ids = {v.loss_trade_id for v in violations}
    count = 0
    for t in all_trades:
        if t.is_loss() and t.id not in matched_loss_ids:
            window_end = t.date + timedelta(days=30)
            if window_end >= today:
                count += 1
    return count
```

- [ ] **Step 4: Register the command in app.py**

Add to `src/net_alpha/cli/app.py`:

```python
from net_alpha.cli.check import check_command

app.command(name="check")(check_command)
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/cli/test_check.py -v`
Expected: All 2 tests PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/cli/check.py src/net_alpha/cli/app.py tests/cli/test_check.py
git commit -m "feat: add check command with summary, detail, and staleness warnings"
```

---

### Task 5: Simulate Command

**Files:**
- Create: `src/net_alpha/cli/simulate.py`
- Modify: `src/net_alpha/cli/app.py` (register command)
- Create: `tests/cli/test_simulate.py`

- [ ] **Step 1: Write the failing tests**

```python
# tests/cli/test_simulate.py
from datetime import date, timedelta

from net_alpha.cli.simulate import _find_lookback_triggers, _compute_safe_date
from net_alpha.models.domain import Trade


def test_find_lookback_triggers():
    today = date(2024, 11, 15)
    trades = [
        Trade(account="Robinhood", date=date(2024, 11, 3), ticker="TSLA",
              action="Buy", quantity=15.0, cost_basis=3750.0),
        Trade(account="Schwab", date=date(2024, 10, 1), ticker="TSLA",
              action="Buy", quantity=5.0, cost_basis=1000.0),
        Trade(account="Schwab", date=date(2024, 9, 1), ticker="TSLA",
              action="Buy", quantity=10.0, cost_basis=2000.0),  # > 30 days ago
    ]
    triggers = _find_lookback_triggers("TSLA", today, trades, {})
    assert len(triggers) == 2  # Only buys within 30 days


def test_compute_safe_date():
    buy_date = date(2024, 11, 3)
    safe = _compute_safe_date([buy_date])
    assert safe == date(2024, 12, 3)  # 30 days after latest buy


def test_compute_safe_date_multiple_buys():
    dates = [date(2024, 11, 3), date(2024, 11, 10)]
    safe = _compute_safe_date(dates)
    assert safe == date(2024, 12, 10)  # 30 days after latest
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/cli/test_simulate.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Write the implementation**

```python
# src/net_alpha/cli/simulate.py
from __future__ import annotations

from datetime import date, timedelta
from typing import Optional

import typer
from rich.console import Console

from net_alpha.cli.output import format_currency, print_disclaimer
from net_alpha.engine.matcher import get_match_confidence, is_within_wash_sale_window

console = Console()

simulate_app = typer.Typer(help="Pre-trade simulation")


@simulate_app.command(name="sell")
def sell_command(
    ticker: str = typer.Argument(help="Ticker to simulate selling"),
    qty: float = typer.Argument(help="Number of shares/contracts"),
    price: Optional[float] = typer.Option(None, help="Sale price per share (for dollar impact)"),
) -> None:
    """Simulate selling a position and check for wash sale risk."""
    from sqlmodel import Session

    from net_alpha.cli.app import _bootstrap
    from net_alpha.db.repository import TradeRepository
    from net_alpha.engine.etf_pairs import load_etf_pairs

    settings, session = _bootstrap()
    trade_repo = TradeRepository(session)
    all_trades = trade_repo.list_all()

    user_pairs = settings.user_etf_pairs_path if settings.user_etf_pairs_path.exists() else None
    etf_pairs = load_etf_pairs(user_pairs_path=user_pairs)

    today = date.today()
    ticker = ticker.upper()

    console.print()
    if price:
        console.print(f"  [bold]SIMULATION: Sell {int(qty)} {ticker} @ {format_currency(price)}[/bold]")
    else:
        console.print(f"  [bold]SIMULATION: Sell {int(qty)} {ticker}[/bold]")
    console.print("  " + "\u2500" * 50)

    # Check look-back: any buys of this ticker within last 30 days
    lookback_triggers = _find_lookback_triggers(ticker, today, all_trades, etf_pairs)

    if lookback_triggers:
        # Wash sale WOULD be triggered
        trigger = lookback_triggers[0]  # Most recent
        days_ago = (today - trigger.date).days
        safe = _compute_safe_date([t.date for t in lookback_triggers])
        days_until_safe = (safe - today).days

        if price:
            # Estimate disallowed loss (rough — uses first buy's basis)
            total_proceeds = price * qty
            avg_basis = sum(t.cost_basis or 0 for t in lookback_triggers) / len(lookback_triggers)
            estimated_loss = max(0, avg_basis * qty / sum(t.quantity for t in lookback_triggers) - total_proceeds)
            console.print(
                f"  [red]\u26a0 Wash sale would be triggered — "
                f"{format_currency(estimated_loss)} of this loss would be DISALLOWED[/red]"
            )
        else:
            console.print("  [red]\u26a0 Wash sale would be triggered.[/red]")

        confidence = get_match_confidence(
            # Dummy loss sale for confidence check
            _make_dummy_sell(ticker, today, qty),
            trigger,
            etf_pairs,
        )
        console.print()
        console.print(
            f"  Reason: Bought {int(trigger.quantity)} {trigger.ticker} on "
            f"{trigger.account} ({trigger.date}) — {days_ago} days ago "
            f"[{confidence}]"
        )
        console.print(f"  Safe to sell cleanly: {safe} ({days_until_safe} days away)")

        if price and estimated_loss > 0:
            console.print(f"  Estimated recoverable loss (if waited): {format_currency(estimated_loss)}")
    else:
        # No look-back violation
        safe_rebuy_date = today + timedelta(days=30)

        # Check if there were any recent sells that could be washed by a future buy
        console.print("  [green]\u2713 No wash sale detected. Safe to sell.[/green]")
        console.print()
        console.print(
            f"  [yellow]\u26a0 Warning: any repurchase of {ticker} before "
            f"{safe_rebuy_date} would trigger a wash sale.[/yellow]"
        )

    print_disclaimer(console)
    session.close()


def _find_lookback_triggers(
    ticker: str,
    sell_date: date,
    all_trades: list,
    etf_pairs: dict[str, list[str]],
) -> list:
    """Find buy trades within the 30-day look-back window for the ticker."""
    triggers = []
    dummy_sell = _make_dummy_sell(ticker, sell_date, 1.0)

    for t in all_trades:
        if not t.is_buy():
            continue
        if not is_within_wash_sale_window(sell_date, t.date):
            continue
        if t.date > sell_date:
            continue  # Look-back only (before sell date)
        confidence = get_match_confidence(dummy_sell, t, etf_pairs)
        if confidence is not None:
            triggers.append(t)

    triggers.sort(key=lambda t: t.date, reverse=True)
    return triggers


def _compute_safe_date(buy_dates: list[date]) -> date:
    """Compute the earliest safe sell date (30 days after the latest buy)."""
    latest = max(buy_dates)
    return latest + timedelta(days=30)


def _make_dummy_sell(ticker: str, sell_date: date, qty: float):
    """Create a dummy sell trade for confidence matching."""
    from net_alpha.models.domain import Trade

    return Trade(
        account="__simulation__",
        date=sell_date,
        ticker=ticker,
        action="Sell",
        quantity=qty,
        proceeds=0.0,
        cost_basis=1.0,  # Ensure is_loss() is True
    )
```

- [ ] **Step 4: Register the command in app.py**

Add to `src/net_alpha/cli/app.py`:

```python
from net_alpha.cli.simulate import simulate_app

app.add_typer(simulate_app, name="simulate")
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/cli/test_simulate.py -v`
Expected: All 3 tests PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/cli/simulate.py src/net_alpha/cli/app.py tests/cli/test_simulate.py
git commit -m "feat: add simulate sell command with look-back detection"
```

---

### Task 6: Rebuys Command

**Files:**
- Create: `src/net_alpha/cli/rebuys.py`
- Modify: `src/net_alpha/cli/app.py` (register command)

- [ ] **Step 1: Write the implementation**

```python
# src/net_alpha/cli/rebuys.py
from __future__ import annotations

from datetime import date, timedelta

import typer
from rich.console import Console
from rich.table import Table

from net_alpha.cli.output import print_disclaimer

console = Console()


def rebuys_command() -> None:
    """Show positions in the wash sale window that are safe to rebuy after a waiting period."""
    from sqlmodel import Session

    from net_alpha.cli.app import _bootstrap
    from net_alpha.db.repository import TradeRepository, ViolationRepository

    settings, session = _bootstrap()
    trade_repo = TradeRepository(session)
    violation_repo = ViolationRepository(session)

    all_trades = trade_repo.list_all()
    violations = violation_repo.list_all()

    today = date.today()

    # Find loss sales with open rebuy windows
    matched_loss_ids = {v.loss_trade_id for v in violations}
    # Track partial matches: how much of each loss sale is already matched
    matched_qty_by_loss = {}
    for v in violations:
        matched_qty_by_loss.setdefault(v.loss_trade_id, 0.0)
        matched_qty_by_loss[v.loss_trade_id] += v.matched_quantity

    rebuy_entries = []
    for t in all_trades:
        if not t.is_loss():
            continue
        window_end = t.date + timedelta(days=30)
        if window_end < today:
            continue  # Window already closed

        matched = matched_qty_by_loss.get(t.id, 0.0)
        remaining = t.quantity - matched
        if remaining <= 0:
            continue  # Fully matched — no open quantity

        days_remaining = (window_end - today).days
        rebuy_entries.append({
            "ticker": t.ticker,
            "qty_display": f"{remaining:.0f}/{t.quantity:.0f}" if matched > 0 else f"{t.quantity:.0f}",
            "sold_date": t.date,
            "account": t.account,
            "safe_date": window_end,
            "days_remaining": days_remaining,
        })

    if not rebuy_entries:
        console.print("\n  No positions currently in wash sale window. All clear.")
        print_disclaimer(console)
        session.close()
        return

    console.print()
    console.print("  [bold]SAFE-TO-REBUY TRACKER[/bold]")

    table = Table(box=None, padding=(0, 2), show_edge=False)
    table.add_column("Ticker")
    table.add_column("Qty Open")
    table.add_column("Sold Date")
    table.add_column("Account")
    table.add_column("Safe to Rebuy")
    table.add_column("Days Remaining", justify="right")

    for entry in sorted(rebuy_entries, key=lambda e: e["safe_date"]):
        table.add_row(
            entry["ticker"],
            entry["qty_display"],
            str(entry["sold_date"]),
            entry["account"],
            str(entry["safe_date"]),
            f"{entry['days_remaining']} days",
        )

    console.print(table)
    console.print(f"\n  {len(rebuy_entries)} positions in wash sale window.")

    print_disclaimer(console)
    session.close()
```

- [ ] **Step 2: Register the command in app.py**

Add to `src/net_alpha/cli/app.py`:

```python
from net_alpha.cli.rebuys import rebuys_command

app.command(name="rebuys")(rebuys_command)
```

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/cli/rebuys.py src/net_alpha/cli/app.py
git commit -m "feat: add safe-to-rebuy tracker command"
```

---

### Task 7: Report Command

**Files:**
- Create: `src/net_alpha/cli/report.py`
- Modify: `src/net_alpha/cli/app.py` (register command)

- [ ] **Step 1: Write the implementation**

```python
# src/net_alpha/cli/report.py
from __future__ import annotations

import csv as csv_module
from datetime import date
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from net_alpha.cli.output import (
    confidence_style,
    format_currency,
    print_disclaimer,
)

console = Console()


def report_command(
    year: Optional[int] = typer.Option(None, help="Tax year (default: current)"),
    csv: bool = typer.Option(False, "--csv", help="Also export CSV to current directory"),
) -> None:
    """Generate a wash sale report for a tax year."""
    from sqlmodel import Session

    from net_alpha.cli.app import _bootstrap
    from net_alpha.db.repository import TradeRepository, ViolationRepository, LotRepository
    from net_alpha.engine.detector import detect_wash_sales
    from net_alpha.engine.etf_pairs import load_etf_pairs

    settings, session = _bootstrap()
    trade_repo = TradeRepository(session)

    all_trades = trade_repo.list_all()
    if not all_trades:
        console.print("  No trades imported yet.")
        session.close()
        return

    user_pairs = settings.user_etf_pairs_path if settings.user_etf_pairs_path.exists() else None
    etf_pairs = load_etf_pairs(user_pairs_path=user_pairs)

    # Run fresh detection
    result = detect_wash_sales(all_trades, etf_pairs)
    trade_map = {t.id: t for t in all_trades}

    report_year = year or date.today().year

    # Filter violations by year (loss sale year)
    violations = [
        v for v in result.violations
        if trade_map[v.loss_trade_id].date.year == report_year
    ]

    # Summary stats
    total_trades = len(all_trades)
    loss_trades = sum(1 for t in all_trades if t.is_loss() and t.date.year == report_year)
    confirmed = sum(1 for v in violations if v.confidence == "Confirmed")
    probable = sum(1 for v in violations if v.confidence == "Probable")
    unclear = sum(1 for v in violations if v.confidence == "Unclear")
    total_disallowed = sum(v.disallowed_loss for v in violations)

    console.print()
    console.print(f"  [bold]WASH SALE REPORT — Tax Year {report_year}[/bold]")
    console.print("  " + "\u2500" * 50)
    console.print(f"  Total trades imported:     {total_trades:,}")
    console.print(f"  Loss trades:               {loss_trades}")
    console.print(
        f"  Wash sales identified:     {len(violations)}  "
        f"({confirmed} Confirmed, {probable} Probable, {unclear} Unclear)"
    )
    console.print(f"  Total disallowed loss:     {format_currency(total_disallowed)}")
    console.print(
        f"  Adjusted cost basis delta: +{format_currency(total_disallowed)} "
        "(rolled into replacement lots)"
    )
    console.print()

    # Detail table
    if violations:
        table = Table(box=None, padding=(0, 2), show_edge=False)
        table.add_column("Date")
        table.add_column("Ticker")
        table.add_column("Account")
        table.add_column("Type")
        table.add_column("Loss", justify="right")
        table.add_column("Status")
        table.add_column("Disallowed", justify="right")
        table.add_column("Replacement")

        for v in sorted(violations, key=lambda x: trade_map[x.loss_trade_id].date):
            loss_trade = trade_map[v.loss_trade_id]
            repl_trade = trade_map.get(v.replacement_trade_id)
            trade_type = "Option" if loss_trade.is_option() else "Equity"
            style = confidence_style(v.confidence)
            repl_info = ""
            if repl_trade:
                repl_info = f"{repl_trade.date} {repl_trade.account}"

            table.add_row(
                str(loss_trade.date),
                loss_trade.ticker,
                loss_trade.account,
                trade_type,
                format_currency(-loss_trade.loss_amount()),
                f"[{style}]{v.confidence}[/{style}]",
                format_currency(v.disallowed_loss),
                repl_info,
            )

        console.print(table)

    console.print()
    console.print(
        "  [dim]* Replacement lot allocation uses FIFO ordering. "
        "Your tax preparer may use a different method.[/dim]"
    )

    # CSV export
    if csv:
        csv_path = Path.cwd() / f"wash_sale_report_{report_year}.csv"
        _write_csv(csv_path, violations, trade_map)
        console.print(f"\n  CSV exported to: {csv_path}")

    print_disclaimer(console)
    session.close()


def _write_csv(path: Path, violations: list, trade_map: dict) -> None:
    with open(path, "w", newline="") as f:
        writer = csv_module.writer(f)
        writer.writerow([
            "Date", "Ticker", "Account", "Type", "Loss", "Confidence",
            "Disallowed", "Replacement Date", "Replacement Account",
        ])
        for v in sorted(violations, key=lambda x: trade_map[x.loss_trade_id].date):
            loss_trade = trade_map[v.loss_trade_id]
            repl_trade = trade_map.get(v.replacement_trade_id)
            trade_type = "Option" if loss_trade.is_option() else "Equity"
            writer.writerow([
                str(loss_trade.date),
                loss_trade.ticker,
                loss_trade.account,
                trade_type,
                f"{-loss_trade.loss_amount():.2f}",
                v.confidence,
                f"{v.disallowed_loss:.2f}",
                str(repl_trade.date) if repl_trade else "",
                repl_trade.account if repl_trade else "",
            ])
```

- [ ] **Step 2: Register the command in app.py**

Add to `src/net_alpha/cli/app.py`:

```python
from net_alpha.cli.report import report_command

app.command(name="report")(report_command)
```

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/cli/report.py src/net_alpha/cli/app.py
git commit -m "feat: add annual wash sale report command with CSV export"
```

---

### Task 8: First-Run Wizard

**Files:**
- Create: `src/net_alpha/cli/wizard.py`

- [ ] **Step 1: Write the implementation**

```python
# src/net_alpha/cli/wizard.py
from __future__ import annotations

from pathlib import Path

import questionary
import typer
from rich.console import Console

from net_alpha.cli.output import print_disclaimer
from net_alpha.config import Settings

console = Console()


def run_wizard(settings: Settings) -> None:
    """Interactive first-run wizard. Runs when `net-alpha` is called with no trades."""
    console.print()
    console.print("  [bold]Welcome to net-alpha[/bold] — cross-account wash sale detection.")
    console.print("  The only open-source tool that tracks wash sales across all your accounts.")
    console.print()

    # Check for API key
    if not settings.anthropic_api_key:
        console.print("  To detect CSV formats, net-alpha uses a one-time AI call per broker.")
        console.print("  You'll need an Anthropic API key (https://console.anthropic.com/keys).")
        console.print()
        api_key = questionary.text(
            "Enter your Anthropic API key:",
            validate=lambda x: len(x) > 10 or "Key must be at least 10 characters",
        ).ask()

        if api_key:
            _save_api_key(settings, api_key)
            settings.anthropic_api_key = api_key
            console.print("  [green]API key saved to ~/.net_alpha/config.toml[/green]")
        else:
            console.print("  [yellow]No API key provided. You can set ANTHROPIC_API_KEY later.[/yellow]")
            return

    # Import loop
    while True:
        console.print()
        broker = questionary.text(
            "Which broker is your next account? (e.g., schwab, robinhood):"
        ).ask()

        if not broker:
            break

        csv_path_str = questionary.path(
            f"Path to {broker} CSV file:",
            validate=lambda x: Path(x).exists() or "File not found",
        ).ask()

        if not csv_path_str:
            break

        # Run import
        from net_alpha.cli.import_cmd import import_command

        try:
            import_command.__wrapped__(broker=broker, file=Path(csv_path_str))
        except (SystemExit, Exception) as e:
            console.print(f"  [red]Import failed: {e}[/red]")
            continue

        another = questionary.confirm(
            "Do you have another account to import?", default=False
        ).ask()

        if not another:
            break

    # Run first check
    console.print()
    console.print("  Running your first wash sale check...")
    console.print()

    from net_alpha.cli.check import check_command

    try:
        check_command()
    except (SystemExit, Exception):
        pass

    console.print()
    console.print("  Run [bold]net-alpha check[/bold] anytime to re-scan.")
    print_disclaimer(console)


def _save_api_key(settings: Settings, api_key: str) -> None:
    """Write API key to config.toml."""
    config_path = settings.config_toml_path
    config_path.parent.mkdir(parents=True, exist_ok=True)

    # Read existing config or start fresh
    content = ""
    if config_path.exists():
        content = config_path.read_text()

    if "anthropic_api_key" in content:
        # Replace existing
        import re

        content = re.sub(
            r'anthropic_api_key\s*=\s*"[^"]*"',
            f'anthropic_api_key = "{api_key}"',
            content,
        )
    else:
        content += f'\nanthropic_api_key = "{api_key}"\n'

    config_path.write_text(content)
```

- [ ] **Step 2: Verify the full app works**

Run: `uv run net-alpha --help`
Expected: Shows all registered commands: import, check, simulate, rebuys, report

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/cli/wizard.py
git commit -m "feat: add first-run interactive wizard"
```

---

### Task 9: Final App Assembly and Validation

**Files:**
- Modify: `src/net_alpha/cli/app.py` (ensure all commands registered)

- [ ] **Step 1: Verify final app.py has all commands registered**

The final `src/net_alpha/cli/app.py` should have these imports and registrations:

```python
from net_alpha.cli.import_cmd import import_command
from net_alpha.cli.check import check_command
from net_alpha.cli.simulate import simulate_app
from net_alpha.cli.rebuys import rebuys_command
from net_alpha.cli.report import report_command

app.command(name="import")(import_command)
app.command(name="check")(check_command)
app.add_typer(simulate_app, name="simulate")
app.command(name="rebuys")(rebuys_command)
app.command(name="report")(report_command)
```

- [ ] **Step 2: Run the full test suite**

Run: `uv run pytest -v`
Expected: All tests PASS across all modules

- [ ] **Step 3: Run linter**

Run: `make check`
Expected: Clean

- [ ] **Step 4: Verify CLI help**

Run: `uv run net-alpha --help`
Expected: Lists all commands: import, check, simulate, rebuys, report

- [ ] **Step 5: Final commit**

```bash
git add -A
git commit -m "feat: complete CLI assembly with all commands"
```
