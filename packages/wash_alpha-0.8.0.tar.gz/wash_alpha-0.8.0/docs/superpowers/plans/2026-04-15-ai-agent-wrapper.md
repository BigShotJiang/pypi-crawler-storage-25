# AI Agent Wrapper Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add `net-alpha agent` — an interactive terminal REPL backed by Claude tool-use that answers natural language questions about trades, wash sales, and tax position.

**Architecture:** A `react.py` module drives Claude with 6 CLI commands exposed as tools. Each tool wraps the existing CLI function, capturing its Rich output to a string buffer. A local fast-path handles trivial inputs (help/exit) before any API call. The REPL in `cli/agent.py` maintains a conversation-history list across turns so follow-up questions have context.

**Tech Stack:** `anthropic` SDK (claude-3-5-haiku-latest), `typer`, `rich`, `pydantic-settings`, `pytest`, `unittest.mock`

---

## File Map

| File | Action | Responsibility |
|---|---|---|
| `src/net_alpha/config.py` | Modify | Add `agent_api_key`, `agent_model`, `resolved_agent_api_key` |
| `src/net_alpha/agent/__init__.py` | Create | Package marker |
| `src/net_alpha/agent/tools.py` | Create | Tool executor functions + Claude tool schemas |
| `src/net_alpha/agent/prompt.py` | Create | System prompt assembly (static role + state snapshot) |
| `src/net_alpha/agent/react.py` | Create | ReAct loop: API call → tool dispatch → iterate → final text |
| `src/net_alpha/cli/agent.py` | Create | REPL loop, local fast-path, session-start scan |
| `src/net_alpha/cli/app.py` | Modify | Wire `agent_command` into the Typer app |
| `tests/agent/__init__.py` | Create | Package marker |
| `tests/agent/test_tools.py` | Create | Tests for tool executors and schema validity |
| `tests/agent/test_prompt.py` | Create | Tests for prompt assembly |
| `tests/agent/test_react.py` | Create | Tests for ReAct loop with mocked Anthropic client |
| `tests/cli/test_agent.py` | Create | Tests for local routing |
| `tests/integration/cli/test_agent.py` | Create | End-to-end smoke test with fake Claude client |

---

## Task 1: Extend Settings with agent config fields

**Files:**
- Modify: `src/net_alpha/config.py`
- Modify: `tests/test_config.py`

- [ ] **Step 1: Write the failing tests**

Add to the bottom of `tests/test_config.py`:

```python
def test_agent_model_default():
    settings = Settings(_env_file=None, data_dir=Path(tempfile.mkdtemp()))
    assert settings.agent_model == "claude-3-5-haiku-latest"


def test_agent_api_key_defaults_to_none():
    settings = Settings(_env_file=None, data_dir=Path(tempfile.mkdtemp()))
    assert settings.agent_api_key is None


def test_resolved_agent_api_key_uses_agent_key_first():
    settings = Settings(
        _env_file=None,
        data_dir=Path(tempfile.mkdtemp()),
        agent_api_key="agent-key",
        anthropic_api_key="shared-key",
    )
    assert settings.resolved_agent_api_key == "agent-key"


def test_resolved_agent_api_key_falls_back_to_anthropic_key():
    settings = Settings(
        _env_file=None,
        data_dir=Path(tempfile.mkdtemp()),
        anthropic_api_key="shared-key",
    )
    assert settings.resolved_agent_api_key == "shared-key"


def test_resolved_agent_api_key_returns_none_when_neither_set():
    settings = Settings(_env_file=None, data_dir=Path(tempfile.mkdtemp()))
    assert settings.resolved_agent_api_key is None
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/test_config.py::test_agent_model_default tests/test_config.py::test_agent_api_key_defaults_to_none tests/test_config.py::test_resolved_agent_api_key_uses_agent_key_first -v
```

Expected: FAIL with `AttributeError: 'Settings' object has no attribute 'agent_model'`

- [ ] **Step 3: Add fields and property to Settings**

In `src/net_alpha/config.py`, add after `llm_max_retries`:

```python
    agent_api_key: str | None = None
    agent_model: str = "claude-3-5-haiku-latest"

    @property
    def resolved_agent_api_key(self) -> str | None:
        """Return agent_api_key if set, otherwise fall back to anthropic_api_key."""
        return self.agent_api_key or self.anthropic_api_key
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/test_config.py -v
```

Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/config.py tests/test_config.py
git commit -m "feat: add agent_api_key, agent_model, resolved_agent_api_key to Settings"
```

---

## Task 2: Tool executor functions and Claude tool schemas

**Files:**
- Create: `src/net_alpha/agent/__init__.py`
- Create: `src/net_alpha/agent/tools.py`
- Create: `tests/agent/__init__.py`
- Create: `tests/agent/test_tools.py`

- [ ] **Step 1: Create package markers**

Create `src/net_alpha/agent/__init__.py` (empty file):
```python
```

Create `tests/agent/__init__.py` (empty file):
```python
```

- [ ] **Step 2: Write the failing tests**

Create `tests/agent/test_tools.py`:

```python
from __future__ import annotations

import pytest
from unittest.mock import patch

from net_alpha.agent.tools import (
    TOOL_SCHEMAS,
    execute_tool,
    run_check,
    run_rebuys,
    run_report,
    run_simulate_sell,
    run_status,
    run_tax_position,
)


# --- Capture mechanism ---

def test_run_status_captures_output(monkeypatch):
    import net_alpha.cli.status as status_mod

    def fake_status_command():
        status_mod.console.print("STATUS OUTPUT")

    monkeypatch.setattr(status_mod, "status_command", fake_status_command)
    result = run_status()
    assert "STATUS OUTPUT" in result


def test_run_check_captures_output(monkeypatch):
    import net_alpha.cli.check as check_mod

    def fake_check_command(**kwargs):
        check_mod.console.print(f"CHECK ticker={kwargs.get('ticker')}")

    monkeypatch.setattr(check_mod, "check_command", fake_check_command)
    result = run_check(ticker="AAPL")
    assert "CHECK ticker=AAPL" in result


def test_run_check_passes_quiet_param(monkeypatch):
    import net_alpha.cli.check as check_mod
    captured = {}

    def fake_check_command(**kwargs):
        captured.update(kwargs)

    monkeypatch.setattr(check_mod, "check_command", fake_check_command)
    run_check(quiet=True)
    assert captured["quiet"] is True


def test_run_simulate_sell_captures_output(monkeypatch):
    import net_alpha.cli.simulate as sim_mod

    def fake_sell(**kwargs):
        sim_mod.console.print(f"SELL {kwargs['ticker']} {kwargs['qty']}")

    monkeypatch.setattr(sim_mod, "sell_command", fake_sell)
    result = run_simulate_sell(ticker="TSLA", qty=10.0)
    assert "SELL TSLA 10.0" in result


def test_run_rebuys_captures_output(monkeypatch):
    import net_alpha.cli.rebuys as rebuys_mod

    def fake_rebuys():
        rebuys_mod.console.print("REBUYS OUTPUT")

    monkeypatch.setattr(rebuys_mod, "rebuys_command", fake_rebuys)
    result = run_rebuys()
    assert "REBUYS OUTPUT" in result


def test_run_report_captures_output(monkeypatch):
    import net_alpha.cli.report as report_mod

    def fake_report(**kwargs):
        report_mod.console.print(f"REPORT year={kwargs.get('year')}")

    monkeypatch.setattr(report_mod, "report_command", fake_report)
    result = run_report(year=2026)
    assert "REPORT year=2026" in result


def test_run_tax_position_captures_output(monkeypatch):
    import net_alpha.cli.tax_position as tax_mod

    def fake_tax(**kwargs):
        tax_mod.console.print("TAX POSITION OUTPUT")

    monkeypatch.setattr(tax_mod, "tax_position_command", fake_tax)
    result = run_tax_position()
    assert "TAX POSITION OUTPUT" in result


def test_capture_handles_system_exit(monkeypatch):
    """typer.Exit (SystemExit subclass) should not propagate out of run_* functions."""
    import typer
    import net_alpha.cli.check as check_mod

    def fake_check_command(**kwargs):
        check_mod.console.print("Error: bad input")
        raise typer.Exit(1)

    monkeypatch.setattr(check_mod, "check_command", fake_check_command)
    result = run_check()
    assert "Error: bad input" in result


# --- execute_tool dispatch ---

def test_execute_tool_dispatches_run_status(monkeypatch):
    from net_alpha.agent import tools as tools_mod
    monkeypatch.setattr(tools_mod, "run_status", lambda: "status result")
    assert execute_tool("run_status", {}) == "status result"


def test_execute_tool_dispatches_run_check(monkeypatch):
    from net_alpha.agent import tools as tools_mod
    captured = {}

    def fake_check(ticker=None, type=None, year=None, quiet=False):
        captured.update({"ticker": ticker, "year": year})
        return "check result"

    monkeypatch.setattr(tools_mod, "run_check", fake_check)
    result = execute_tool("run_check", {"ticker": "AAPL", "year": 2026})
    assert result == "check result"
    assert captured["ticker"] == "AAPL"
    assert captured["year"] == 2026


def test_execute_tool_dispatches_run_simulate_sell(monkeypatch):
    from net_alpha.agent import tools as tools_mod
    monkeypatch.setattr(tools_mod, "run_simulate_sell", lambda **kw: "sim result")
    assert execute_tool("run_simulate_sell", {"ticker": "AAPL", "qty": 5.0}) == "sim result"


def test_execute_tool_unknown_name():
    result = execute_tool("nonexistent_tool", {})
    assert "Unknown tool" in result


# --- Schema validity ---

def test_tool_schemas_have_required_fields():
    for schema in TOOL_SCHEMAS:
        assert "name" in schema, f"Missing 'name' in schema: {schema}"
        assert "description" in schema, f"Missing 'description' in schema: {schema}"
        assert "input_schema" in schema, f"Missing 'input_schema' in schema: {schema}"
        assert schema["input_schema"]["type"] == "object"
        assert "properties" in schema["input_schema"]
        assert "required" in schema["input_schema"]


def test_all_schema_names_are_unique():
    names = [s["name"] for s in TOOL_SCHEMAS]
    assert len(names) == len(set(names))


def test_run_import_not_in_schemas():
    """run_import must never be exposed as a tool — file imports are user-only actions."""
    names = [s["name"] for s in TOOL_SCHEMAS]
    assert "run_import" not in names


def test_tool_schema_names():
    names = {s["name"] for s in TOOL_SCHEMAS}
    assert names == {
        "run_status",
        "run_check",
        "run_simulate_sell",
        "run_rebuys",
        "run_report",
        "run_tax_position",
    }
```

- [ ] **Step 3: Run tests to verify they fail**

```bash
uv run pytest tests/agent/test_tools.py -v
```

Expected: FAIL with `ModuleNotFoundError: No module named 'net_alpha.agent'`

- [ ] **Step 4: Implement tools.py**

Create `src/net_alpha/agent/tools.py`:

```python
from __future__ import annotations

import sys
from io import StringIO
from typing import Any, Callable

from rich.console import Console


def _capture(module: Any, fn_name: str, **kwargs: Any) -> str:
    """
    Call module.<fn_name>(**kwargs) with a string-capturing Console.

    Patches the module-level `console` for the duration of the call so all
    console.print() output goes into a StringIO buffer. Catches SystemExit
    (raised by typer.Exit) so errors are returned as text, not exceptions.
    """
    buf = StringIO()
    cap = Console(file=buf, highlight=False)
    orig = getattr(module, "console")
    setattr(module, "console", cap)
    try:
        getattr(module, fn_name)(**kwargs)
    except SystemExit:
        pass  # typer.Exit — error message already captured in buf
    except Exception as e:
        return f"Error: {e}"
    finally:
        setattr(module, "console", orig)
    return buf.getvalue().strip()


def run_status() -> str:
    """Run the status command and return output as plain text."""
    import net_alpha.cli.status as _mod
    return _capture(_mod, "status_command")


def run_check(
    ticker: str | None = None,
    type: str | None = None,
    year: int | None = None,
    quiet: bool = False,
) -> str:
    """Run the check command and return output as plain text."""
    import net_alpha.cli.check as _mod
    return _capture(_mod, "check_command", ticker=ticker, type=type, year=year, quiet=quiet)


def run_simulate_sell(
    ticker: str,
    qty: float,
    price: float | None = None,
) -> str:
    """Run the simulate sell command and return output as plain text."""
    import net_alpha.cli.simulate as _mod
    return _capture(_mod, "sell_command", ticker=ticker, qty=qty, price=price)


def run_rebuys() -> str:
    """Run the rebuys command and return output as plain text."""
    import net_alpha.cli.rebuys as _mod
    return _capture(_mod, "rebuys_command")


def run_report(year: int | None = None, csv: bool = False) -> str:
    """Run the report command and return output as plain text."""
    import net_alpha.cli.report as _mod
    return _capture(_mod, "report_command", year=year, csv=csv, quiet=False)


def run_tax_position(year: int | None = None) -> str:
    """Run the tax-position command and return output as plain text."""
    import net_alpha.cli.tax_position as _mod
    return _capture(_mod, "tax_position_command", year=year)


def execute_tool(name: str, tool_input: dict[str, Any]) -> str:
    """Dispatch a tool call by name and return the output string."""
    dispatch: dict[str, Callable[..., str]] = {
        "run_status": lambda **kw: run_status(),
        "run_check": lambda **kw: run_check(**kw),
        "run_simulate_sell": lambda **kw: run_simulate_sell(**kw),
        "run_rebuys": lambda **kw: run_rebuys(),
        "run_report": lambda **kw: run_report(**kw),
        "run_tax_position": lambda **kw: run_tax_position(**kw),
    }
    fn = dispatch.get(name)
    if fn is None:
        return f"Unknown tool: {name}"
    return fn(**tool_input)


TOOL_SCHEMAS: list[dict[str, Any]] = [
    {
        "name": "run_status",
        "description": (
            "Show imported data freshness, last scan results, and open rebuy windows. "
            "Use this to get an overview of what data is available."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "run_check",
        "description": (
            "Scan all trades for wash sale violations. Returns a summary and detail table. "
            "Use this to answer questions about wash sale exposure."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "ticker": {
                    "type": "string",
                    "description": "Filter results to a single ticker symbol (optional)",
                },
                "type": {
                    "type": "string",
                    "enum": ["equities", "options"],
                    "description": "Filter to equities or options only (optional)",
                },
                "year": {
                    "type": "integer",
                    "description": "Tax year to scan (default: current year)",
                },
            },
            "required": [],
        },
    },
    {
        "name": "run_simulate_sell",
        "description": (
            "Simulate selling a position and check for wash sale risk. "
            "When price is provided, also shows FIFO/HIFO/LIFO lot selection comparison "
            "and a tax-aware recommendation. Use this to answer 'should I sell X?' questions."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "ticker": {"type": "string", "description": "Ticker symbol to simulate selling"},
                "qty": {"type": "number", "description": "Number of shares or contracts"},
                "price": {
                    "type": "number",
                    "description": "Sale price per share (optional — enables dollar impact and lot selection)",
                },
            },
            "required": ["ticker", "qty"],
        },
    },
    {
        "name": "run_rebuys",
        "description": (
            "Show positions currently in their 30-day wash sale window that are safe to rebuy "
            "after the window closes. Use this to answer 'what can I buy back?' questions."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "run_report",
        "description": (
            "Generate a full wash sale report for a tax year. Returns all violations with "
            "disallowed amounts and adjusted basis information."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "year": {"type": "integer", "description": "Tax year (default: current year)"},
                "csv": {"type": "boolean", "description": "Also export a CSV file to the current directory"},
            },
            "required": [],
        },
    },
    {
        "name": "run_tax_position",
        "description": (
            "Show YTD realized gains and losses (short-term and long-term), open lots with "
            "holding periods, and positions approaching the 1-year long-term threshold. "
            "Use this to answer questions about current tax position."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "year": {"type": "integer", "description": "Tax year (default: current year)"},
            },
            "required": [],
        },
    },
]
```

- [ ] **Step 5: Run tests to verify they pass**

```bash
uv run pytest tests/agent/test_tools.py -v
```

Expected: All PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/agent/__init__.py src/net_alpha/agent/tools.py tests/agent/__init__.py tests/agent/test_tools.py
git commit -m "feat: add agent tool executors and Claude tool schemas"
```

---

## Task 3: System prompt assembly

**Files:**
- Create: `src/net_alpha/agent/prompt.py`
- Create: `tests/agent/test_prompt.py`

- [ ] **Step 1: Write the failing tests**

Create `tests/agent/test_prompt.py`:

```python
from __future__ import annotations

from net_alpha.agent.prompt import build_state_snapshot, build_system_prompt
from net_alpha.cli.output import DISCLAIMER


def test_build_system_prompt_contains_disclaimer_rule():
    prompt = build_system_prompt("some snapshot")
    assert DISCLAIMER in prompt


def test_build_system_prompt_contains_snapshot():
    prompt = build_system_prompt("3 violations found")
    assert "3 violations found" in prompt


def test_build_system_prompt_contains_wash_sale_knowledge():
    prompt = build_system_prompt("")
    assert "wash sale" in prompt.lower()
    assert "30-day" in prompt


def test_build_system_prompt_contains_today_date():
    from datetime import date
    prompt = build_system_prompt("snapshot")
    assert date.today().isoformat() in prompt


def test_build_state_snapshot_includes_both_sections():
    snap = build_state_snapshot(status_output="status text", check_output="check text")
    assert "status text" in snap
    assert "check text" in snap


def test_build_state_snapshot_status_only():
    snap = build_state_snapshot(status_output="status text", check_output="")
    assert "status text" in snap
    assert "check text" not in snap


def test_build_state_snapshot_empty_returns_fallback():
    snap = build_state_snapshot(status_output="", check_output="")
    assert "No data" in snap
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/agent/test_prompt.py -v
```

Expected: FAIL with `ModuleNotFoundError: No module named 'net_alpha.agent.prompt'`

- [ ] **Step 3: Implement prompt.py**

Create `src/net_alpha/agent/prompt.py`:

```python
from __future__ import annotations

from datetime import date

from net_alpha.cli.output import DISCLAIMER

_STATIC_ROLE = f"""You are a tax-aware trading assistant for net-alpha, a local wash sale detection tool.

You have deep knowledge of:
- Wash sale rules (IRS Publication 550) and the 30-day wash sale window
- Substantially-identical securities, including ETF pairs (e.g. SPY/VOO/IVV/SPLG are treated as identical)
- Short-term vs long-term capital gains classification (holding period under/over 1 year)
- The three confidence levels: Confirmed (definite wash sale), Probable (likely; CPA review recommended), Unclear (ambiguous; flag for professional review)
- FIFO, HIFO, and LIFO lot selection methods and their tax implications

Rules you must follow without exception:
- End every response with exactly: {DISCLAIMER}
- Never recommend specific tax actions — surface data and flag for CPA review
- When tool output is ambiguous or a required ticker has no data, say so clearly rather than guess
- Use plain language; avoid jargon unless the user has demonstrated familiarity
"""


def build_system_prompt(state_snapshot: str) -> str:
    """Assemble the full system prompt: static role + today's date + current state snapshot."""
    return (
        f"{_STATIC_ROLE}\n"
        f"Current date: {date.today().isoformat()}\n\n"
        f"Current portfolio state:\n{state_snapshot}"
    )


def build_state_snapshot(status_output: str, check_output: str) -> str:
    """Format status + check outputs as a concise state block for the system prompt."""
    sections = []
    if status_output.strip():
        sections.append(f"--- Account Status ---\n{status_output.strip()}")
    if check_output.strip():
        sections.append(f"--- Wash Sale Check ---\n{check_output.strip()}")
    return "\n\n".join(sections) if sections else "No data available yet. Trades may not be imported."
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/agent/test_prompt.py -v
```

Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/agent/prompt.py tests/agent/test_prompt.py
git commit -m "feat: add agent system prompt assembly"
```

---

## Task 4: ReAct loop

**Files:**
- Create: `src/net_alpha/agent/react.py`
- Create: `tests/agent/test_react.py`

- [ ] **Step 1: Write the failing tests**

Create `tests/agent/test_react.py`:

```python
from __future__ import annotations

from unittest.mock import MagicMock, call

from net_alpha.agent.react import MAX_ITERATIONS, run_react_turn


# --- Test helpers ---

def _text_block(text: str) -> MagicMock:
    block = MagicMock()
    block.type = "text"
    block.text = text
    return block


def _tool_use_block(name: str, input_: dict, id_: str = "tu_1") -> MagicMock:
    block = MagicMock()
    block.type = "tool_use"
    block.name = name
    block.input = input_
    block.id = id_
    return block


def _end_turn_response(text: str) -> MagicMock:
    resp = MagicMock()
    resp.stop_reason = "end_turn"
    resp.content = [_text_block(text)]
    return resp


def _tool_use_response(name: str, input_: dict, id_: str = "tu_1") -> MagicMock:
    resp = MagicMock()
    resp.stop_reason = "tool_use"
    resp.content = [_tool_use_block(name, input_, id_)]
    return resp


# --- Tests ---

def test_text_only_response_returned_immediately():
    client = MagicMock()
    client.messages.create.return_value = _end_turn_response("Hello world")
    messages = []
    result = run_react_turn(client, "model", "system", messages, [], lambda n, i: "")
    assert result == "Hello world"
    assert client.messages.create.call_count == 1


def test_single_tool_call_then_text_response():
    client = MagicMock()
    client.messages.create.side_effect = [
        _tool_use_response("run_status", {}),
        _end_turn_response("Status looks good."),
    ]
    messages = []
    executed = []

    def executor(name: str, inp: dict) -> str:
        executed.append((name, inp))
        return "status output"

    result = run_react_turn(client, "model", "system", messages, [], executor)
    assert result == "Status looks good."
    assert executed == [("run_status", {})]
    assert client.messages.create.call_count == 2


def test_tool_result_appended_to_messages():
    client = MagicMock()
    client.messages.create.side_effect = [
        _tool_use_response("run_check", {"ticker": "AAPL"}, id_="tu_abc"),
        _end_turn_response("Done."),
    ]
    messages = []
    run_react_turn(client, "model", "system", messages, [], lambda n, i: "check result")

    # messages should have: [assistant tool_use, user tool_result]
    assert len(messages) == 2
    assert messages[0]["role"] == "assistant"
    assert messages[1]["role"] == "user"
    tool_result_content = messages[1]["content"]
    assert tool_result_content[0]["type"] == "tool_result"
    assert tool_result_content[0]["tool_use_id"] == "tu_abc"
    assert tool_result_content[0]["content"] == "check result"


def test_tool_error_string_passed_to_claude():
    """Tool exceptions return error strings to Claude, not tracebacks."""
    client = MagicMock()
    client.messages.create.side_effect = [
        _tool_use_response("run_check", {}, id_="tu_err"),
        _end_turn_response("No data available."),
    ]
    messages = []
    run_react_turn(client, "model", "system", messages, [], lambda n, i: "Error: no trades imported")

    tool_result_msg = messages[1]
    assert tool_result_msg["content"][0]["content"] == "Error: no trades imported"


def test_multi_tool_chain():
    client = MagicMock()
    client.messages.create.side_effect = [
        _tool_use_response("run_status", {}, id_="tu_1"),
        _tool_use_response("run_check", {}, id_="tu_2"),
        _end_turn_response("All clear."),
    ]
    messages = []
    executed = []
    run_react_turn(client, "model", "system", messages, [], lambda n, i: executed.append(n) or "ok")

    assert executed == ["run_status", "run_check"]
    assert client.messages.create.call_count == 3


def test_max_iterations_cap_triggers_summary_call():
    """After MAX_ITERATIONS tool calls, a final summarization API call is made."""
    client = MagicMock()
    # Always return tool_use to saturate the cap
    client.messages.create.side_effect = (
        [_tool_use_response("run_status", {})] * MAX_ITERATIONS
        + [_end_turn_response("Here is my summary.")]
    )
    messages = []
    result = run_react_turn(client, "model", "system", messages, [], lambda n, i: "")

    assert result == "Here is my summary."
    assert client.messages.create.call_count == MAX_ITERATIONS + 1


def test_second_api_call_includes_prior_messages():
    client = MagicMock()
    client.messages.create.side_effect = [
        _tool_use_response("run_status", {}, id_="tu_1"),
        _end_turn_response("Done."),
    ]
    messages = [{"role": "user", "content": "hello"}]
    run_react_turn(client, "model", "system", messages, [], lambda n, i: "out")

    second_call_kwargs = client.messages.create.call_args_list[1][1]
    second_messages = second_call_kwargs["messages"]
    # Should include: original user message + assistant tool_use + user tool_result
    assert len(second_messages) == 3
    assert second_messages[0]["content"] == "hello"
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/agent/test_react.py -v
```

Expected: FAIL with `ModuleNotFoundError: No module named 'net_alpha.agent.react'`

- [ ] **Step 3: Implement react.py**

Create `src/net_alpha/agent/react.py`:

```python
from __future__ import annotations

from typing import Any, Callable

MAX_ITERATIONS = 10


def run_react_turn(
    client: Any,
    model: str,
    system_prompt: str,
    messages: list[dict],
    tool_schemas: list[dict],
    tool_executor: Callable[[str, dict], str],
) -> str:
    """
    Run one ReAct turn against the Claude API.

    Drives the tool-use loop: calls the API, dispatches tool_use blocks via
    tool_executor, appends results to messages, and loops until Claude returns
    an end_turn text response or the iteration cap is reached.

    Mutates `messages` in place — callers maintain conversation history
    by keeping a reference to the same list across turns.

    Returns the final text response string.
    """
    for _ in range(MAX_ITERATIONS):
        response = client.messages.create(
            model=model,
            max_tokens=4096,
            system=system_prompt,
            tools=tool_schemas,
            messages=messages,
        )

        if response.stop_reason == "end_turn":
            for block in response.content:
                if block.type == "text":
                    return block.text
            return ""

        if response.stop_reason == "tool_use":
            # Append assistant's full response (includes tool_use blocks)
            messages.append({"role": "assistant", "content": response.content})

            # Execute all tool_use blocks and collect results
            tool_results = []
            for block in response.content:
                if block.type == "tool_use":
                    result = tool_executor(block.name, block.input)
                    tool_results.append(
                        {
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": result,
                        }
                    )

            messages.append({"role": "user", "content": tool_results})
            continue

        return f"Unexpected API stop reason: {response.stop_reason}"

    # Iteration cap reached — ask Claude to summarize what it has
    messages.append(
        {
            "role": "user",
            "content": (
                "You have used the maximum number of tool calls. "
                "Please summarize what you have found so far and give your best answer."
            ),
        }
    )
    response = client.messages.create(
        model=model,
        max_tokens=1024,
        system=system_prompt,
        messages=messages,
    )
    for block in response.content:
        if block.type == "text":
            return block.text
    return "Unable to complete within iteration limit."
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/agent/test_react.py -v
```

Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/agent/react.py tests/agent/test_react.py
git commit -m "feat: add ReAct loop for Claude tool-use agent"
```

---

## Task 5: REPL, local routing, and session-start scan

**Files:**
- Create: `src/net_alpha/cli/agent.py`
- Create: `tests/cli/test_agent.py`

- [ ] **Step 1: Write the failing tests**

Create `tests/cli/test_agent.py`:

```python
from __future__ import annotations

from net_alpha.cli.agent import _route_local


def test_route_local_exit_commands():
    assert _route_local("exit") == "__exit__"
    assert _route_local("quit") == "__exit__"
    assert _route_local("q") == "__exit__"


def test_route_local_exit_case_insensitive():
    assert _route_local("EXIT") == "__exit__"
    assert _route_local("Quit") == "__exit__"


def test_route_local_help_returns_help_text():
    result = _route_local("help")
    assert result is not None
    assert "net-alpha agent" in result


def test_route_local_unknown_returns_none():
    assert _route_local("do I have wash sales?") is None
    assert _route_local("check AAPL") is None


def test_route_local_empty_returns_none():
    assert _route_local("") is None
    assert _route_local("   ") is None


def test_route_local_passthrough_prefix():
    """!<command> passthrough is NOT handled by _route_local — returns None so REPL handles it."""
    # The REPL itself handles ! prefix; _route_local only handles pure local commands
    assert _route_local("!net-alpha status") is None
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/cli/test_agent.py -v
```

Expected: FAIL with `ModuleNotFoundError: No module named 'net_alpha.cli.agent'` or `ImportError`

- [ ] **Step 3: Implement agent.py**

Create `src/net_alpha/cli/agent.py`:

```python
from __future__ import annotations

import subprocess

import typer
from rich.console import Console
from rich.panel import Panel

from net_alpha.cli.output import DISCLAIMER

console = Console()

_HELP_TEXT = """[bold]net-alpha agent[/bold] — natural language interface

Ask anything about your trades, wash sales, or tax position. Examples:

  "Do I have any wash sale violations this year?"
  "Should I sell my AAPL position?"
  "What's my YTD tax situation?"
  "Which positions can I safely rebuy?"
  "Check for wash sales on my TSLA trades"

Type [bold]exit[/bold] to quit. Prefix with [bold]![/bold] to run a raw CLI command."""

_EXIT_SENTINEL = "__exit__"


def _route_local(user_input: str) -> str | None:
    """
    Handle trivial inputs locally without an API call.

    Returns:
        "__exit__" if the user wants to quit
        A help string if user typed "help"
        None if the input should go to the ReAct loop
    """
    stripped = user_input.strip()
    if not stripped:
        return None
    if stripped.lower() in {"exit", "quit", "q"}:
        return _EXIT_SENTINEL
    if stripped.lower() == "help":
        return _HELP_TEXT
    return None


def agent_command() -> None:
    """Start an interactive AI assistant session for tax and wash sale questions."""
    from net_alpha.cli.app import _bootstrap

    settings, session = _bootstrap()
    session.close()  # Agent tools manage their own sessions via _bootstrap

    api_key = settings.resolved_agent_api_key
    if not api_key:
        console.print(
            "\n  [red]Error:[/red] No API key configured.\n"
            "  Set [bold]ANTHROPIC_API_KEY[/bold] or add "
            "[bold]anthropic_api_key[/bold] to [bold]~/.net_alpha/config.toml[/bold]"
        )
        raise typer.Exit(1)

    import anthropic

    from net_alpha.agent.prompt import build_state_snapshot, build_system_prompt
    from net_alpha.agent.react import run_react_turn
    from net_alpha.agent.tools import TOOL_SCHEMAS, execute_tool, run_check, run_status

    client = anthropic.Anthropic(api_key=api_key)
    model = settings.agent_model

    # Session-start scan
    console.print()
    with console.status("Scanning your portfolio\u2026", spinner="dots"):
        status_out = run_status()
        check_out = run_check(quiet=True)
        snapshot = build_state_snapshot(status_out, check_out)

    system_prompt = build_system_prompt(snapshot)

    console.print(Panel(snapshot, title="[bold]Portfolio Snapshot[/bold]", border_style="dim"))
    console.print()
    console.print(
        "  [bold]Agent ready.[/bold] Ask anything about your trades or tax position.\n"
        "  (Type [dim]help[/dim] for examples, [dim]exit[/dim] to quit)\n"
    )

    messages: list[dict] = []

    while True:
        try:
            user_input = console.input("  [bold green]You:[/bold green] ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n  Goodbye.")
            break

        if not user_input:
            continue

        # Handle ! passthrough before other routing
        if user_input.startswith("!"):
            raw_cmd = user_input[1:].strip()
            console.print()
            subprocess.run(raw_cmd, shell=True)
            console.print()
            continue

        # Local fast-path
        local_response = _route_local(user_input)
        if local_response == _EXIT_SENTINEL:
            console.print("  Goodbye.")
            break
        if local_response is not None:
            console.print(f"\n{local_response}\n")
            continue

        # ReAct turn
        messages.append({"role": "user", "content": user_input})
        try:
            with console.status("Thinking\u2026", spinner="dots"):
                response = run_react_turn(
                    client, model, system_prompt, messages, TOOL_SCHEMAS, execute_tool
                )
        except Exception as e:
            console.print(f"\n  [red]API error:[/red] {e}\n  Try again or type [bold]exit[/bold].\n")
            messages.pop()  # Remove failed user message from history
            continue

        messages.append({"role": "assistant", "content": response})
        console.print(f"\n  [bold blue]Agent:[/bold blue] {response}\n")
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/cli/test_agent.py -v
```

Expected: All PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/cli/agent.py tests/cli/test_agent.py
git commit -m "feat: add agent REPL with local routing and session-start scan"
```

---

## Task 6: Wire agent command into app and integration smoke test

**Files:**
- Modify: `src/net_alpha/cli/app.py`
- Create: `tests/integration/cli/test_agent.py`

- [ ] **Step 1: Write the failing integration test**

Create `tests/integration/cli/test_agent.py`:

```python
from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest
from sqlmodel import Session
from typer.testing import CliRunner

from net_alpha.cli.app import app
from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db


@pytest.fixture
def agent_setup(tmp_path, monkeypatch):
    """Provide (runner, engine, settings) with patched _bootstrap for agent tests."""
    db_path = tmp_path / "net_alpha.db"
    engine = get_engine(db_path)
    init_db(engine)

    settings = Settings(
        data_dir=tmp_path,
        anthropic_api_key="test-key",
        agent_model="claude-3-5-haiku-latest",
    )

    def fake_bootstrap():
        return settings, Session(engine)

    monkeypatch.setattr("net_alpha.cli.app._bootstrap", fake_bootstrap)
    return CliRunner(), engine, settings


def _make_text_response(text: str) -> MagicMock:
    block = MagicMock()
    block.type = "text"
    block.text = text
    resp = MagicMock()
    resp.stop_reason = "end_turn"
    resp.content = [block]
    return resp


def test_agent_command_registered():
    """Verify 'agent' is a registered command in the Typer app."""
    from typer.testing import CliRunner
    runner = CliRunner()
    result = runner.invoke(app, ["--help"])
    assert "agent" in result.output


def test_agent_exits_with_no_api_key(agent_setup, monkeypatch):
    """Agent should print an error and exit if no API key is configured."""
    runner, engine, settings = agent_setup
    monkeypatch.setattr(settings, "resolved_agent_api_key", None)

    # Re-patch _bootstrap to return settings with no API key
    def fake_bootstrap_no_key():
        return settings, Session(engine)

    monkeypatch.setattr("net_alpha.cli.app._bootstrap", fake_bootstrap_no_key)

    result = runner.invoke(app, ["agent"], input="exit\n")
    assert result.exit_code == 1
    assert "API key" in result.output


def test_agent_full_session_turn(agent_setup, monkeypatch):
    """Smoke test: agent runs a session, Claude responds with text, user exits."""
    runner, engine, settings = agent_setup

    # Patch anthropic.Anthropic to return a fake client
    fake_client = MagicMock()
    fake_client.messages.create.return_value = _make_text_response(
        "You have no wash sale violations. \u26a0 This is informational only. Consult a tax professional before filing."
    )

    with patch("anthropic.Anthropic", return_value=fake_client):
        result = runner.invoke(
            app,
            ["agent"],
            input="Do I have any wash sales?\nexit\n",
        )

    assert result.exit_code == 0
    assert "You have no wash sale violations" in result.output
    assert "Goodbye" in result.output
```

- [ ] **Step 2: Run test to verify it fails**

```bash
uv run pytest tests/integration/cli/test_agent.py::test_agent_command_registered -v
```

Expected: FAIL — `agent` not in app help output

- [ ] **Step 3: Wire agent_command into app.py**

In `src/net_alpha/cli/app.py`, add the import and registration. After the existing imports add:

```python
from net_alpha.cli.agent import agent_command
```

After the existing `app.command(name="status")(status_command)` line add:

```python
app.command(name="agent")(agent_command)
```

- [ ] **Step 4: Run all integration tests**

```bash
uv run pytest tests/integration/cli/test_agent.py -v
```

Expected: All PASS

- [ ] **Step 5: Run full test suite to check for regressions**

```bash
uv run pytest -v
```

Expected: All PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/cli/app.py tests/integration/cli/test_agent.py
git commit -m "feat: wire agent command into CLI app and add integration smoke test"
```

---

## Verification

After all tasks are complete, do a final manual check:

```bash
# Confirm the command appears in help
uv run net-alpha --help

# Confirm it starts (will fail gracefully if no API key set)
uv run net-alpha agent
```

Expected output when no API key:
```
  Error: No API key configured.
  Set ANTHROPIC_API_KEY or add anthropic_api_key to ~/.net_alpha/config.toml
```

Expected output when API key is set: Portfolio Snapshot panel, then "Agent ready." prompt.
