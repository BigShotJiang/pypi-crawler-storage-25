# net_alpha Core Engine — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.
>
> **Supersedes:** `2026-04-12-net-alpha-core-engine.md` (incomplete draft)

**Goal:** Implement pure-Python domain models and the wash sale detection engine — fully decoupled from the database.

**Architecture:** Two-layer design. Pure Pydantic v2 domain models (`Trade`, `OptionDetails`, `Lot`, `WashSaleViolation`) form the data layer. The engine is a set of pure functions: match trades within a 30-day window, assign confidence labels, allocate disallowed losses via FIFO, and adjust replacement lot basis. No database, no I/O, no side effects — 100% unit-testable.

**Tech Stack:** Python 3.11+, Pydantic v2, pytest, factory_boy, PyYAML, ruff

**Dependencies:** None (this is the first plan to execute)

---

## File Structure

| Action | Path | Responsibility |
|--------|------|----------------|
| Create | `pyproject.toml` | Project metadata, all dependencies, tool config |
| Create | `Makefile` | Developer shortcuts (`make test`, `make lint`) |
| Create | `.python-version` | Pin Python 3.11 |
| Create | `etf_pairs.yaml` | Bundled substantially-identical ETF groups |
| Create | `src/net_alpha/__init__.py` | Package root |
| Create | `src/net_alpha/models/__init__.py` | Models sub-package |
| Create | `src/net_alpha/models/domain.py` | Trade, OptionDetails, Lot, WashSaleViolation, DetectionResult |
| Create | `src/net_alpha/engine/__init__.py` | Engine sub-package |
| Create | `src/net_alpha/engine/matcher.py` | `is_within_wash_sale_window`, `get_match_confidence`, `are_substantially_identical` |
| Create | `src/net_alpha/engine/etf_pairs.py` | `load_etf_pairs` (YAML loader + user override merge) |
| Create | `src/net_alpha/engine/detector.py` | `detect_wash_sales` (main entry point) |
| Create | `tests/__init__.py` | Tests package |
| Create | `tests/conftest.py` | Factory Boy factories |
| Create | `tests/models/__init__.py` | Tests sub-package |
| Create | `tests/models/test_domain.py` | Domain model tests |
| Create | `tests/engine/__init__.py` | Tests sub-package |
| Create | `tests/engine/test_matcher.py` | Matcher function tests |
| Create | `tests/engine/test_etf_pairs.py` | ETF pairs loader tests |
| Create | `tests/engine/test_detector.py` | Wash sale detector tests |

---

### Task 1: Project Setup

**Files:**
- Create: `pyproject.toml`
- Create: `Makefile`
- Create: `.python-version`
- Create: `src/net_alpha/__init__.py`
- Create: `src/net_alpha/models/__init__.py`
- Create: `src/net_alpha/engine/__init__.py`
- Create: `tests/__init__.py`
- Create: `tests/models/__init__.py`
- Create: `tests/engine/__init__.py`

- [ ] **Step 1: Create pyproject.toml**

```toml
# pyproject.toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "net-alpha"
version = "0.1.0"
description = "Cross-account wash sale detection for equities, options, and ETFs"
requires-python = ">=3.11"
dependencies = [
    "pydantic>=2.0",
    "sqlmodel>=0.0.16",
    "typer[all]>=0.12",
    "questionary>=2.0",
    "anthropic>=0.39",
    "pydantic-settings>=2.0",
    "loguru>=0.7",
    "pyyaml>=6.0",
]

[project.scripts]
net-alpha = "net_alpha.cli.app:main"

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-cov>=5.0",
    "factory-boy>=3.3",
    "ruff>=0.6",
]

[tool.hatch.build.targets.wheel]
packages = ["src/net_alpha"]

[tool.ruff]
target-version = "py311"
src = ["src"]

[tool.ruff.lint]
select = ["E", "F", "I", "UP"]

[tool.pytest.ini_options]
testpaths = ["tests"]
```

- [ ] **Step 2: Create Makefile**

```makefile
# Makefile
.PHONY: test lint format check

test:
	uv run pytest

lint:
	uv run ruff check .
	uv run ruff format --check .

format:
	uv run ruff format .
	uv run ruff check --fix .

check: lint test
```

- [ ] **Step 3: Create .python-version**

```
3.11
```

- [ ] **Step 4: Create package directories and __init__.py files**

```bash
mkdir -p src/net_alpha/models src/net_alpha/engine tests/models tests/engine
touch src/net_alpha/__init__.py src/net_alpha/models/__init__.py src/net_alpha/engine/__init__.py
touch tests/__init__.py tests/models/__init__.py tests/engine/__init__.py
```

- [ ] **Step 5: Install dependencies**

Run: `uv sync --all-extras`
Expected: Successful install, `.venv` created

- [ ] **Step 6: Verify setup**

Run: `uv run pytest --co -q`
Expected: "no tests ran" (no test files yet, but pytest runs without error)

- [ ] **Step 7: Commit**

```bash
git add pyproject.toml Makefile .python-version src/ tests/
git commit -m "feat: initialize project structure with uv and hatch"
```

---

### Task 2: Domain Models — Trade and OptionDetails

**Files:**
- Create: `src/net_alpha/models/domain.py`
- Create: `tests/models/test_domain.py`

- [ ] **Step 1: Write the failing tests for Trade and OptionDetails**

```python
# tests/models/test_domain.py
from datetime import date

from net_alpha.models.domain import OptionDetails, Trade


def test_trade_equity_loss():
    trade = Trade(
        account="Schwab",
        date=date(2024, 10, 15),
        ticker="TSLA",
        action="Sell",
        quantity=10.0,
        proceeds=2400.0,
        cost_basis=3600.0,
    )
    assert trade.is_sell() is True
    assert trade.is_buy() is False
    assert trade.is_option() is False
    assert trade.is_loss() is True
    assert trade.loss_amount() == 1200.0


def test_trade_equity_gain():
    trade = Trade(
        account="Schwab",
        date=date(2024, 10, 15),
        ticker="TSLA",
        action="Sell",
        quantity=10.0,
        proceeds=5000.0,
        cost_basis=3600.0,
    )
    assert trade.is_loss() is False
    assert trade.loss_amount() == 0.0


def test_trade_buy_is_never_loss():
    trade = Trade(
        account="Schwab",
        date=date(2024, 10, 15),
        ticker="TSLA",
        action="Buy",
        quantity=10.0,
        cost_basis=3600.0,
    )
    assert trade.is_loss() is False


def test_trade_basis_unknown_is_never_loss():
    trade = Trade(
        account="Schwab",
        date=date(2024, 10, 15),
        ticker="TSLA",
        action="Sell",
        quantity=10.0,
        proceeds=2400.0,
        basis_unknown=True,
    )
    assert trade.is_loss() is False
    assert trade.loss_amount() == 0.0


def test_trade_with_option_details():
    trade = Trade(
        account="Schwab",
        date=date(2024, 10, 15),
        ticker="TSLA",
        action="Buy",
        quantity=1.0,
        cost_basis=500.0,
        option_details=OptionDetails(
            strike=250.0,
            expiry=date(2024, 12, 20),
            call_put="C",
        ),
    )
    assert trade.is_option() is True
    assert trade.option_details.strike == 250.0
    assert trade.option_details.call_put == "C"


def test_trade_id_auto_generated():
    t1 = Trade(account="A", date=date(2024, 1, 1), ticker="X", action="Buy", quantity=1.0)
    t2 = Trade(account="A", date=date(2024, 1, 1), ticker="X", action="Buy", quantity=1.0)
    assert t1.id != t2.id
    assert len(t1.id) == 36  # UUID format
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/models/test_domain.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'net_alpha.models.domain'`

- [ ] **Step 3: Write the implementation**

```python
# src/net_alpha/models/domain.py
from __future__ import annotations

from datetime import date
from typing import Optional
from uuid import uuid4

from pydantic import BaseModel, Field


class OptionDetails(BaseModel):
    """Option contract details parsed from symbol string."""

    strike: float
    expiry: date
    call_put: str  # "C" or "P"


class Trade(BaseModel):
    """A single trade (buy or sell) from a broker CSV."""

    id: str = Field(default_factory=lambda: str(uuid4()))
    account: str
    date: date
    ticker: str
    action: str  # "Buy" or "Sell"
    quantity: float
    proceeds: Optional[float] = None
    cost_basis: Optional[float] = None
    basis_unknown: bool = False
    option_details: Optional[OptionDetails] = None
    raw_row_hash: Optional[str] = None
    schema_cache_id: Optional[str] = None

    def is_buy(self) -> bool:
        return self.action.lower() == "buy"

    def is_sell(self) -> bool:
        return self.action.lower() == "sell"

    def is_option(self) -> bool:
        return self.option_details is not None

    def is_loss(self) -> bool:
        if not self.is_sell() or self.basis_unknown:
            return False
        if self.proceeds is not None and self.cost_basis is not None:
            return self.proceeds < self.cost_basis
        return False

    def loss_amount(self) -> float:
        if self.is_loss() and self.proceeds is not None and self.cost_basis is not None:
            return self.cost_basis - self.proceeds
        return 0.0
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/models/test_domain.py -v`
Expected: All 6 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/models/domain.py tests/models/test_domain.py
git commit -m "feat: add Trade and OptionDetails domain models"
```

---

### Task 3: Domain Models — Lot, WashSaleViolation, DetectionResult

**Files:**
- Modify: `src/net_alpha/models/domain.py`
- Modify: `tests/models/test_domain.py`

- [ ] **Step 1: Write the failing tests**

```python
# append to tests/models/test_domain.py
from net_alpha.models.domain import DetectionResult, Lot, WashSaleViolation


def test_lot_from_trade():
    trade = Trade(
        account="Robinhood",
        date=date(2024, 11, 3),
        ticker="TSLA",
        action="Buy",
        quantity=15.0,
        cost_basis=3600.0,
    )
    lot = Lot.from_trade(trade)
    assert lot.trade_id == trade.id
    assert lot.account == "Robinhood"
    assert lot.ticker == "TSLA"
    assert lot.quantity == 15.0
    assert lot.cost_basis == 3600.0
    assert lot.adjusted_basis == 3600.0


def test_lot_from_option_trade():
    trade = Trade(
        account="Schwab",
        date=date(2024, 11, 3),
        ticker="TSLA",
        action="Buy",
        quantity=1.0,
        cost_basis=500.0,
        option_details=OptionDetails(
            strike=250.0, expiry=date(2024, 12, 20), call_put="C"
        ),
    )
    lot = Lot.from_trade(trade)
    assert lot.option_details is not None
    assert lot.option_details.strike == 250.0


def test_wash_sale_violation():
    violation = WashSaleViolation(
        loss_trade_id="sell_1",
        replacement_trade_id="buy_1",
        confidence="Confirmed",
        disallowed_loss=1200.0,
        matched_quantity=10.0,
    )
    assert violation.confidence == "Confirmed"
    assert violation.disallowed_loss == 1200.0


def test_detection_result():
    result = DetectionResult(violations=[], lots=[], basis_unknown_count=0)
    assert result.violations == []
    assert result.lots == []
    assert result.basis_unknown_count == 0
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/models/test_domain.py::test_lot_from_trade -v`
Expected: FAIL with `ImportError: cannot import name 'Lot'`

- [ ] **Step 3: Append to domain.py**

```python
# append to src/net_alpha/models/domain.py


class Lot(BaseModel):
    """A buy lot with adjustable cost basis for wash sale tracking."""

    id: str = Field(default_factory=lambda: str(uuid4()))
    trade_id: str
    account: str
    date: date
    ticker: str
    quantity: float
    cost_basis: float
    adjusted_basis: float
    option_details: Optional[OptionDetails] = None

    @classmethod
    def from_trade(cls, trade: Trade) -> Lot:
        return cls(
            trade_id=trade.id,
            account=trade.account,
            date=trade.date,
            ticker=trade.ticker,
            quantity=trade.quantity,
            cost_basis=trade.cost_basis or 0.0,
            adjusted_basis=trade.cost_basis or 0.0,
            option_details=trade.option_details,
        )


class WashSaleViolation(BaseModel):
    """A detected wash sale linking a loss sale to its triggering replacement."""

    id: str = Field(default_factory=lambda: str(uuid4()))
    loss_trade_id: str
    replacement_trade_id: str
    confidence: str  # "Confirmed", "Probable", or "Unclear"
    disallowed_loss: float
    matched_quantity: float


class DetectionResult(BaseModel):
    """Output of the wash sale detection engine."""

    violations: list[WashSaleViolation]
    lots: list[Lot]
    basis_unknown_count: int
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/models/test_domain.py -v`
Expected: All 10 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/models/domain.py tests/models/test_domain.py
git commit -m "feat: add Lot, WashSaleViolation, and DetectionResult models"
```

---

### Task 4: Factory Boy Test Fixtures

**Files:**
- Create: `tests/conftest.py`

- [ ] **Step 1: Write the test factories**

```python
# tests/conftest.py
from datetime import date
from uuid import uuid4

import factory

from net_alpha.models.domain import Lot, OptionDetails, Trade


class TradeFactory(factory.Factory):
    class Meta:
        model = Trade

    id = factory.LazyFunction(lambda: str(uuid4()))
    account = "Schwab"
    date = factory.LazyFunction(lambda: date(2024, 10, 15))
    ticker = "TSLA"
    action = "Buy"
    quantity = 10.0
    proceeds = None
    cost_basis = 2400.0
    basis_unknown = False
    option_details = None


class LossSaleFactory(TradeFactory):
    action = "Sell"
    proceeds = 2400.0
    cost_basis = 3600.0


class OptionTradeFactory(TradeFactory):
    option_details = factory.LazyFunction(
        lambda: OptionDetails(strike=250.0, expiry=date(2024, 12, 20), call_put="C")
    )


class LotFactory(factory.Factory):
    class Meta:
        model = Lot

    id = factory.LazyFunction(lambda: str(uuid4()))
    trade_id = factory.LazyFunction(lambda: str(uuid4()))
    account = "Schwab"
    date = factory.LazyFunction(lambda: date(2024, 10, 15))
    ticker = "TSLA"
    quantity = 10.0
    cost_basis = 2400.0
    adjusted_basis = 2400.0
```

- [ ] **Step 2: Verify factories work**

Run: `uv run python -c "from tests.conftest import TradeFactory, LossSaleFactory; t = TradeFactory(); s = LossSaleFactory(); print(f'Buy: {t.action}, Loss: {s.is_loss()}')"`
Expected: `Buy: Buy, Loss: True`

- [ ] **Step 3: Commit**

```bash
git add tests/conftest.py
git commit -m "feat: add factory_boy test fixtures for Trade and Lot"
```

---

### Task 5: 30-Day Window Matcher

**Files:**
- Create: `src/net_alpha/engine/matcher.py`
- Create: `tests/engine/test_matcher.py`

- [ ] **Step 1: Write the failing tests**

```python
# tests/engine/test_matcher.py
from datetime import date

from net_alpha.engine.matcher import is_within_wash_sale_window


def test_same_day():
    assert is_within_wash_sale_window(date(2024, 10, 15), date(2024, 10, 15)) is True


def test_exactly_30_days_before():
    assert is_within_wash_sale_window(date(2024, 10, 15), date(2024, 9, 15)) is True


def test_exactly_30_days_after():
    assert is_within_wash_sale_window(date(2024, 10, 15), date(2024, 11, 14)) is True


def test_31_days_before_outside_window():
    assert is_within_wash_sale_window(date(2024, 10, 15), date(2024, 9, 14)) is False


def test_31_days_after_outside_window():
    assert is_within_wash_sale_window(date(2024, 10, 15), date(2024, 11, 15)) is False


def test_1_day_before():
    assert is_within_wash_sale_window(date(2024, 10, 15), date(2024, 10, 14)) is True


def test_1_day_after():
    assert is_within_wash_sale_window(date(2024, 10, 15), date(2024, 10, 16)) is True


def test_cross_year_boundary():
    # Dec 20 sale, Jan 5 buy = 16 days → within window
    assert is_within_wash_sale_window(date(2024, 12, 20), date(2025, 1, 5)) is True


def test_cross_year_boundary_outside():
    # Dec 1 sale, Jan 31 buy = 61 days → outside window
    assert is_within_wash_sale_window(date(2024, 12, 1), date(2025, 1, 31)) is False
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/engine/test_matcher.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Write the implementation**

```python
# src/net_alpha/engine/matcher.py
from __future__ import annotations

from datetime import date


def is_within_wash_sale_window(sale_date: date, other_date: date) -> bool:
    """Check if other_date falls within the 30-day wash sale window of sale_date.

    The window spans 30 calendar days before through 30 calendar days after the sale.
    """
    delta = (other_date - sale_date).days
    return -30 <= delta <= 30
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_matcher.py -v`
Expected: All 9 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/engine/matcher.py tests/engine/test_matcher.py
git commit -m "feat: implement 30-day wash sale window check"
```

---

### Task 6: Match Confidence — Equities

**Files:**
- Modify: `src/net_alpha/engine/matcher.py`
- Modify: `tests/engine/test_matcher.py`

- [ ] **Step 1: Write the failing tests for equity matching**

```python
# append to tests/engine/test_matcher.py
from net_alpha.engine.matcher import get_match_confidence
from net_alpha.models.domain import Trade


def test_equity_same_ticker_confirmed():
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="TSLA", action="Sell",
        quantity=10.0, proceeds=2000.0, cost_basis=3000.0,
    )
    buy = Trade(
        account="B", date=date(2024, 1, 10), ticker="TSLA", action="Buy",
        quantity=10.0, cost_basis=2500.0,
    )
    assert get_match_confidence(sell, buy, {}) == "Confirmed"


def test_equity_different_ticker_no_match():
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="TSLA", action="Sell",
        quantity=10.0, proceeds=2000.0, cost_basis=3000.0,
    )
    buy = Trade(
        account="B", date=date(2024, 1, 10), ticker="AAPL", action="Buy",
        quantity=10.0, cost_basis=2500.0,
    )
    assert get_match_confidence(sell, buy, {}) is None


def test_non_buy_candidate_no_match():
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="TSLA", action="Sell",
        quantity=10.0, proceeds=2000.0, cost_basis=3000.0,
    )
    other_sell = Trade(
        account="B", date=date(2024, 1, 10), ticker="TSLA", action="Sell",
        quantity=10.0, proceeds=2500.0, cost_basis=2000.0,
    )
    # A regular sell is not a trigger (sold puts handled separately)
    assert get_match_confidence(sell, other_sell, {}) is None
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/engine/test_matcher.py::test_equity_same_ticker_confirmed -v`
Expected: FAIL with `ImportError: cannot import name 'get_match_confidence'`

- [ ] **Step 3: Append to matcher.py**

```python
# append to src/net_alpha/engine/matcher.py
from typing import Optional

from net_alpha.models.domain import Trade


def get_match_confidence(
    loss_sale: Trade,
    candidate: Trade,
    etf_pairs: dict[str, list[str]],
) -> Optional[str]:
    """Determine if candidate could trigger a wash sale for loss_sale.

    Returns a confidence label ("Confirmed", "Probable", "Unclear") or None.
    """
    # Special case: selling a put on same underlying as a stock loss
    if (
        candidate.is_sell()
        and candidate.is_option()
        and candidate.option_details.call_put == "P"
        and not loss_sale.is_option()
        and loss_sale.ticker == candidate.ticker
    ):
        return "Unclear"

    # All other triggers must be buys
    if not candidate.is_buy():
        return None

    # Same ticker
    if loss_sale.ticker == candidate.ticker:
        # Both equities
        if not loss_sale.is_option() and not candidate.is_option():
            return "Confirmed"

        # Loss sale is equity, candidate is option
        if not loss_sale.is_option() and candidate.is_option():
            if candidate.option_details.call_put == "C":
                return "Probable"
            return None

        # Loss sale is option, candidate is equity
        if loss_sale.is_option() and not candidate.is_option():
            return "Probable"

        # Both options on same underlying
        if loss_sale.is_option() and candidate.is_option():
            if (
                loss_sale.option_details.strike == candidate.option_details.strike
                and loss_sale.option_details.expiry == candidate.option_details.expiry
                and loss_sale.option_details.call_put == candidate.option_details.call_put
            ):
                return "Confirmed"
            return "Probable"

    # ETF substantially-identical pairs
    if _are_substantially_identical(loss_sale.ticker, candidate.ticker, etf_pairs):
        return "Unclear"

    return None


def _are_substantially_identical(
    ticker_a: str, ticker_b: str, etf_pairs: dict[str, list[str]]
) -> bool:
    """Check if two different tickers belong to the same ETF group."""
    if ticker_a == ticker_b:
        return False
    for group in etf_pairs.values():
        if ticker_a in group and ticker_b in group:
            return True
    return False
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_matcher.py -v`
Expected: All 12 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/engine/matcher.py tests/engine/test_matcher.py
git commit -m "feat: implement equity match confidence with ETF pair support"
```

---

### Task 7: Match Confidence — Options (All Scenarios)

**Files:**
- Modify: `tests/engine/test_matcher.py`

- [ ] **Step 1: Write the failing tests for all option scenarios**

```python
# append to tests/engine/test_matcher.py
from net_alpha.models.domain import OptionDetails


def test_option_same_option_confirmed():
    """Sold option at loss, bought same option (same strike/expiry)."""
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="TSLA", action="Sell",
        quantity=1.0, proceeds=200.0, cost_basis=500.0,
        option_details=OptionDetails(strike=250.0, expiry=date(2024, 12, 20), call_put="C"),
    )
    buy = Trade(
        account="B", date=date(2024, 1, 10), ticker="TSLA", action="Buy",
        quantity=1.0, cost_basis=450.0,
        option_details=OptionDetails(strike=250.0, expiry=date(2024, 12, 20), call_put="C"),
    )
    assert get_match_confidence(sell, buy, {}) == "Confirmed"


def test_option_different_strike_probable():
    """Sold option at loss, bought option on same underlying (different strike)."""
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="TSLA", action="Sell",
        quantity=1.0, proceeds=200.0, cost_basis=500.0,
        option_details=OptionDetails(strike=250.0, expiry=date(2024, 12, 20), call_put="C"),
    )
    buy = Trade(
        account="B", date=date(2024, 1, 10), ticker="TSLA", action="Buy",
        quantity=1.0, cost_basis=600.0,
        option_details=OptionDetails(strike=300.0, expiry=date(2024, 12, 20), call_put="C"),
    )
    assert get_match_confidence(sell, buy, {}) == "Probable"


def test_option_different_expiry_probable():
    """Sold option at loss, bought option on same underlying (different expiry)."""
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="TSLA", action="Sell",
        quantity=1.0, proceeds=200.0, cost_basis=500.0,
        option_details=OptionDetails(strike=250.0, expiry=date(2024, 12, 20), call_put="C"),
    )
    buy = Trade(
        account="B", date=date(2024, 1, 10), ticker="TSLA", action="Buy",
        quantity=1.0, cost_basis=600.0,
        option_details=OptionDetails(strike=250.0, expiry=date(2025, 3, 21), call_put="C"),
    )
    assert get_match_confidence(sell, buy, {}) == "Probable"


def test_stock_loss_buy_call_probable():
    """Sold stock at loss, bought call option on same stock."""
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="TSLA", action="Sell",
        quantity=10.0, proceeds=2000.0, cost_basis=3000.0,
    )
    buy = Trade(
        account="B", date=date(2024, 1, 10), ticker="TSLA", action="Buy",
        quantity=1.0, cost_basis=500.0,
        option_details=OptionDetails(strike=250.0, expiry=date(2024, 12, 20), call_put="C"),
    )
    assert get_match_confidence(sell, buy, {}) == "Probable"


def test_stock_loss_buy_put_no_match():
    """Sold stock at loss, bought put option — not a wash sale trigger."""
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="TSLA", action="Sell",
        quantity=10.0, proceeds=2000.0, cost_basis=3000.0,
    )
    buy = Trade(
        account="B", date=date(2024, 1, 10), ticker="TSLA", action="Buy",
        quantity=1.0, cost_basis=300.0,
        option_details=OptionDetails(strike=200.0, expiry=date(2024, 12, 20), call_put="P"),
    )
    assert get_match_confidence(sell, buy, {}) is None


def test_stock_loss_sold_put_unclear():
    """Sold stock at loss, sold put option on same stock — gray area."""
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="TSLA", action="Sell",
        quantity=10.0, proceeds=2000.0, cost_basis=3000.0,
    )
    sold_put = Trade(
        account="A", date=date(2024, 1, 10), ticker="TSLA", action="Sell",
        quantity=1.0, proceeds=300.0,
        option_details=OptionDetails(strike=200.0, expiry=date(2024, 12, 20), call_put="P"),
    )
    assert get_match_confidence(sell, sold_put, {}) == "Unclear"


def test_option_loss_buy_stock_probable():
    """Sold option at loss, bought underlying stock."""
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="TSLA", action="Sell",
        quantity=1.0, proceeds=100.0, cost_basis=500.0,
        option_details=OptionDetails(strike=250.0, expiry=date(2024, 12, 20), call_put="C"),
    )
    buy = Trade(
        account="B", date=date(2024, 1, 10), ticker="TSLA", action="Buy",
        quantity=10.0, cost_basis=2500.0,
    )
    assert get_match_confidence(sell, buy, {}) == "Probable"
```

- [ ] **Step 2: Run tests to verify they pass (implementation already in Task 6)**

Run: `uv run pytest tests/engine/test_matcher.py -v`
Expected: All 19 tests PASS (the implementation from Task 6 handles all these cases)

- [ ] **Step 3: Commit**

```bash
git add tests/engine/test_matcher.py
git commit -m "test: add comprehensive option wash sale confidence tests"
```

---

### Task 8: ETF Pairs Loader

**Files:**
- Create: `etf_pairs.yaml`
- Create: `src/net_alpha/engine/etf_pairs.py`
- Create: `tests/engine/test_etf_pairs.py`

- [ ] **Step 1: Create the bundled ETF pairs YAML**

```yaml
# etf_pairs.yaml
sp500:
  - SPY
  - VOO
  - IVV
  - SPLG
nasdaq100:
  - QQQ
  - QQQM
russell2000:
  - IWM
  - VTWO
gold:
  - GLD
  - IAU
```

- [ ] **Step 2: Write the failing tests**

```python
# tests/engine/test_etf_pairs.py
import os
import tempfile
from pathlib import Path

from net_alpha.engine.etf_pairs import load_etf_pairs


def test_load_bundled_pairs():
    pairs = load_etf_pairs(user_pairs_path=None)
    assert "SPY" in pairs["sp500"]
    assert "VOO" in pairs["sp500"]
    assert "QQQ" in pairs["nasdaq100"]
    assert "GLD" in pairs["gold"]


def test_user_pairs_extend_defaults():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write("tech_growth:\n  - VGT\n  - XLK\n")
        f.flush()
        try:
            pairs = load_etf_pairs(user_pairs_path=Path(f.name))
            # Bundled pairs still present
            assert "SPY" in pairs["sp500"]
            # User pairs added
            assert "VGT" in pairs["tech_growth"]
            assert "XLK" in pairs["tech_growth"]
        finally:
            os.unlink(f.name)


def test_user_pairs_do_not_replace_defaults():
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        f.write("sp500:\n  - VFINX\n")
        f.flush()
        try:
            pairs = load_etf_pairs(user_pairs_path=Path(f.name))
            # Bundled entries preserved
            assert "SPY" in pairs["sp500"]
            assert "VOO" in pairs["sp500"]
            # User entry merged in
            assert "VFINX" in pairs["sp500"]
        finally:
            os.unlink(f.name)


def test_missing_user_file_ignored():
    pairs = load_etf_pairs(user_pairs_path=Path("/nonexistent/path.yaml"))
    assert "SPY" in pairs["sp500"]
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `uv run pytest tests/engine/test_etf_pairs.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 4: Write the implementation**

```python
# src/net_alpha/engine/etf_pairs.py
from __future__ import annotations

from pathlib import Path
from typing import Optional

import yaml

_BUNDLED_PATH = Path(__file__).resolve().parent.parent.parent.parent / "etf_pairs.yaml"


def load_etf_pairs(
    user_pairs_path: Optional[Path] = None,
) -> dict[str, list[str]]:
    """Load ETF substantially-identical pairs from bundled YAML + optional user overrides.

    User pairs extend defaults — they never replace them.
    """
    # Load bundled pairs
    with open(_BUNDLED_PATH) as f:
        pairs: dict[str, list[str]] = yaml.safe_load(f) or {}

    # Merge user pairs if file exists
    if user_pairs_path and user_pairs_path.exists():
        with open(user_pairs_path) as f:
            user_pairs: dict[str, list[str]] = yaml.safe_load(f) or {}
        for group, tickers in user_pairs.items():
            if group in pairs:
                # Extend, deduplicate
                existing = set(pairs[group])
                for ticker in tickers:
                    if ticker not in existing:
                        pairs[group].append(ticker)
            else:
                pairs[group] = tickers

    return pairs
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_etf_pairs.py -v`
Expected: All 4 tests PASS

- [ ] **Step 6: Commit**

```bash
git add etf_pairs.yaml src/net_alpha/engine/etf_pairs.py tests/engine/test_etf_pairs.py
git commit -m "feat: add ETF pairs loader with user override support"
```

---

### Task 9: Match Confidence — ETF Pairs

**Files:**
- Modify: `tests/engine/test_matcher.py`

- [ ] **Step 1: Write the failing tests**

```python
# append to tests/engine/test_matcher.py

ETF_PAIRS = {
    "sp500": ["SPY", "VOO", "IVV", "SPLG"],
    "nasdaq100": ["QQQ", "QQQM"],
}


def test_etf_same_ticker_confirmed():
    """Sold ETF at loss, bought same ETF ticker."""
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="SPY", action="Sell",
        quantity=10.0, proceeds=4000.0, cost_basis=5000.0,
    )
    buy = Trade(
        account="B", date=date(2024, 1, 10), ticker="SPY", action="Buy",
        quantity=10.0, cost_basis=4500.0,
    )
    assert get_match_confidence(sell, buy, ETF_PAIRS) == "Confirmed"


def test_etf_substantially_identical_unclear():
    """Sold ETF at loss, bought substantially-identical ETF."""
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="SPY", action="Sell",
        quantity=10.0, proceeds=4000.0, cost_basis=5000.0,
    )
    buy = Trade(
        account="B", date=date(2024, 1, 10), ticker="VOO", action="Buy",
        quantity=10.0, cost_basis=4500.0,
    )
    assert get_match_confidence(sell, buy, ETF_PAIRS) == "Unclear"


def test_etf_different_group_no_match():
    """SPY and QQQ are in different groups — no match."""
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="SPY", action="Sell",
        quantity=10.0, proceeds=4000.0, cost_basis=5000.0,
    )
    buy = Trade(
        account="B", date=date(2024, 1, 10), ticker="QQQ", action="Buy",
        quantity=10.0, cost_basis=4500.0,
    )
    assert get_match_confidence(sell, buy, ETF_PAIRS) is None


def test_etf_constituent_stock_no_match():
    """Sold ETF at loss, bought constituent stock — not a wash sale."""
    sell = Trade(
        account="A", date=date(2024, 1, 1), ticker="SPY", action="Sell",
        quantity=10.0, proceeds=4000.0, cost_basis=5000.0,
    )
    buy = Trade(
        account="B", date=date(2024, 1, 10), ticker="AAPL", action="Buy",
        quantity=10.0, cost_basis=1500.0,
    )
    assert get_match_confidence(sell, buy, ETF_PAIRS) is None
```

- [ ] **Step 2: Run tests to verify they pass (implementation already in Task 6)**

Run: `uv run pytest tests/engine/test_matcher.py -v`
Expected: All 23 tests PASS

- [ ] **Step 3: Commit**

```bash
git add tests/engine/test_matcher.py
git commit -m "test: add ETF wash sale confidence tests"
```

---

### Task 10: Wash Sale Detector — Core Algorithm

**Files:**
- Create: `src/net_alpha/engine/detector.py`
- Create: `tests/engine/test_detector.py`

- [ ] **Step 1: Write the failing tests for basic equity detection**

```python
# tests/engine/test_detector.py
from datetime import date

from tests.conftest import LossSaleFactory, TradeFactory

from net_alpha.engine.detector import detect_wash_sales


def test_simple_equity_wash_sale():
    """Sell TSLA at loss, rebuy within 30 days → Confirmed."""
    sell = LossSaleFactory(
        account="Schwab",
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=10.0,
        proceeds=2400.0,
        cost_basis=3600.0,
    )
    buy = TradeFactory(
        account="Robinhood",
        date=date(2024, 11, 3),
        ticker="TSLA",
        action="Buy",
        quantity=15.0,
        cost_basis=3750.0,
    )
    result = detect_wash_sales([sell, buy], {})

    assert len(result.violations) == 1
    v = result.violations[0]
    assert v.loss_trade_id == sell.id
    assert v.replacement_trade_id == buy.id
    assert v.confidence == "Confirmed"
    assert v.disallowed_loss == 1200.0
    assert v.matched_quantity == 10.0


def test_no_wash_sale_outside_window():
    """Buy 31 days after sell → no wash sale."""
    sell = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=10.0,
        proceeds=2400.0,
        cost_basis=3600.0,
    )
    buy = TradeFactory(
        date=date(2024, 11, 15),  # Day 31
        ticker="TSLA",
        action="Buy",
        quantity=10.0,
    )
    result = detect_wash_sales([sell, buy], {})
    assert len(result.violations) == 0


def test_no_wash_sale_on_gain():
    """Sell at a gain → no wash sale regardless of repurchase."""
    sell = TradeFactory(
        action="Sell",
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=10.0,
        proceeds=5000.0,
        cost_basis=3600.0,
    )
    buy = TradeFactory(
        date=date(2024, 10, 20),
        ticker="TSLA",
        action="Buy",
        quantity=10.0,
    )
    result = detect_wash_sales([sell, buy], {})
    assert len(result.violations) == 0


def test_look_back_window():
    """Buy 15 days BEFORE loss sale → still a wash sale."""
    buy = TradeFactory(
        date=date(2024, 10, 1),
        ticker="TSLA",
        action="Buy",
        quantity=10.0,
        cost_basis=2500.0,
    )
    sell = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=10.0,
        proceeds=2000.0,
        cost_basis=3000.0,
    )
    result = detect_wash_sales([sell, buy], {})
    assert len(result.violations) == 1
    assert result.violations[0].confidence == "Confirmed"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/engine/test_detector.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Write the implementation**

```python
# src/net_alpha/engine/detector.py
from __future__ import annotations

from net_alpha.engine.matcher import get_match_confidence, is_within_wash_sale_window
from net_alpha.models.domain import DetectionResult, Lot, Trade, WashSaleViolation


def detect_wash_sales(
    trades: list[Trade],
    etf_pairs: dict[str, list[str]],
) -> DetectionResult:
    """Detect wash sales across all trades. Pure function — no I/O.

    Algorithm:
    1. Find all loss sales, sorted by date
    2. Create lots from all buy trades
    3. For each loss sale, match against candidates in FIFO order
    4. Allocate disallowed loss and adjust replacement lot basis
    """
    loss_sales = sorted(
        [t for t in trades if t.is_loss()],
        key=lambda t: t.date,
    )

    # Create lots from buys — track remaining allocable quantity per lot
    lots: dict[str, Lot] = {}
    lot_remaining: dict[str, float] = {}
    for t in trades:
        if t.is_buy():
            lot = Lot.from_trade(t)
            lots[t.id] = lot
            lot_remaining[t.id] = t.quantity

    # Count basis_unknown trades for the warning
    basis_unknown_count = sum(1 for t in trades if t.basis_unknown)

    violations: list[WashSaleViolation] = []

    for loss_sale in loss_sales:
        remaining_qty = loss_sale.quantity
        loss_per_unit = loss_sale.loss_amount() / loss_sale.quantity

        # Find candidates within window, sorted by date (FIFO)
        candidates = _find_candidates(loss_sale, trades, etf_pairs)

        for candidate, confidence in candidates:
            if remaining_qty <= 0:
                break

            # Determine allocable quantity
            if candidate.is_buy() and candidate.id in lot_remaining:
                available = lot_remaining[candidate.id]
                if available <= 0:
                    continue
                allocable = min(remaining_qty, available)
                lot_remaining[candidate.id] -= allocable
            elif (
                candidate.is_sell()
                and candidate.is_option()
                and candidate.option_details.call_put == "P"
            ):
                # Sold put — no lot, use candidate quantity directly
                allocable = min(remaining_qty, candidate.quantity)
            else:
                continue

            disallowed = round(allocable * loss_per_unit, 2)

            violations.append(
                WashSaleViolation(
                    loss_trade_id=loss_sale.id,
                    replacement_trade_id=candidate.id,
                    confidence=confidence,
                    disallowed_loss=disallowed,
                    matched_quantity=allocable,
                )
            )

            # Adjust replacement lot basis
            if candidate.id in lots:
                lots[candidate.id].adjusted_basis += disallowed

            remaining_qty -= allocable

    return DetectionResult(
        violations=violations,
        lots=list(lots.values()),
        basis_unknown_count=basis_unknown_count,
    )


def _find_candidates(
    loss_sale: Trade,
    all_trades: list[Trade],
    etf_pairs: dict[str, list[str]],
) -> list[tuple[Trade, str]]:
    """Find and sort candidate triggers for a loss sale. Returns (trade, confidence) pairs in FIFO order."""
    candidates: list[tuple[Trade, str]] = []
    for t in all_trades:
        if t.id == loss_sale.id:
            continue
        if not is_within_wash_sale_window(loss_sale.date, t.date):
            continue
        confidence = get_match_confidence(loss_sale, t, etf_pairs)
        if confidence is not None:
            candidates.append((t, confidence))
    candidates.sort(key=lambda x: x[0].date)
    return candidates
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_detector.py -v`
Expected: All 4 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/engine/detector.py tests/engine/test_detector.py
git commit -m "feat: implement core wash sale detection engine"
```

---

### Task 11: Wash Sale Detector — FIFO Allocation and Partial Wash Sales

**Files:**
- Modify: `tests/engine/test_detector.py`

- [ ] **Step 1: Write tests for FIFO and partial wash sales**

```python
# append to tests/engine/test_detector.py


def test_fifo_allocation_earliest_buy_first():
    """Multiple buys in window — earliest buy absorbs disallowed loss first."""
    sell = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=10.0,
        proceeds=2000.0,
        cost_basis=3000.0,
    )
    buy1 = TradeFactory(
        date=date(2024, 10, 20),
        ticker="TSLA",
        action="Buy",
        quantity=5.0,
        cost_basis=1200.0,
    )
    buy2 = TradeFactory(
        date=date(2024, 10, 25),
        ticker="TSLA",
        action="Buy",
        quantity=8.0,
        cost_basis=2000.0,
    )
    result = detect_wash_sales([sell, buy1, buy2], {})

    assert len(result.violations) == 2
    # First violation: 5 shares allocated to buy1 (earlier)
    v1 = result.violations[0]
    assert v1.replacement_trade_id == buy1.id
    assert v1.matched_quantity == 5.0
    assert v1.disallowed_loss == 500.0  # 5/10 * 1000

    # Second violation: 5 shares allocated to buy2 (later)
    v2 = result.violations[1]
    assert v2.replacement_trade_id == buy2.id
    assert v2.matched_quantity == 5.0
    assert v2.disallowed_loss == 500.0


def test_partial_wash_sale_fewer_shares_bought():
    """Bought fewer shares than sold — partial wash sale."""
    sell = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=100.0,
        proceeds=20000.0,
        cost_basis=30000.0,
    )
    buy = TradeFactory(
        date=date(2024, 10, 20),
        ticker="TSLA",
        action="Buy",
        quantity=40.0,
        cost_basis=9000.0,
    )
    result = detect_wash_sales([sell, buy], {})

    assert len(result.violations) == 1
    v = result.violations[0]
    assert v.matched_quantity == 40.0
    assert v.disallowed_loss == 4000.0  # 40/100 * 10000


def test_adjusted_basis_updated():
    """Disallowed loss rolls into replacement lot's adjusted basis."""
    sell = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=10.0,
        proceeds=2000.0,
        cost_basis=3200.0,
    )
    buy = TradeFactory(
        date=date(2024, 10, 20),
        ticker="TSLA",
        action="Buy",
        quantity=10.0,
        cost_basis=2500.0,
    )
    result = detect_wash_sales([sell, buy], {})

    # Find the lot for the buy
    lot = next(l for l in result.lots if l.trade_id == buy.id)
    assert lot.cost_basis == 2500.0
    assert lot.adjusted_basis == 2500.0 + 1200.0  # 3700.0


def test_same_day_buy_and_sell():
    """Same-day buy and sell — always a wash sale."""
    sell = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=10.0,
        proceeds=2000.0,
        cost_basis=3000.0,
    )
    buy = TradeFactory(
        date=date(2024, 10, 15),
        ticker="TSLA",
        action="Buy",
        quantity=10.0,
        cost_basis=2100.0,
    )
    result = detect_wash_sales([sell, buy], {})
    assert len(result.violations) == 1
    assert result.violations[0].confidence == "Confirmed"
```

- [ ] **Step 2: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_detector.py -v`
Expected: All 8 tests PASS

- [ ] **Step 3: Commit**

```bash
git add tests/engine/test_detector.py
git commit -m "test: FIFO allocation, partial wash sales, and basis adjustment"
```

---

### Task 12: Wash Sale Detector — Cross-Account, Cross-Year, and Edge Cases

**Files:**
- Modify: `tests/engine/test_detector.py`

- [ ] **Step 1: Write tests for cross-account detection**

```python
# append to tests/engine/test_detector.py


def test_cross_account_wash_sale():
    """Loss on Schwab, rebuy on Robinhood → detected."""
    sell = LossSaleFactory(
        account="Schwab",
        date=date(2024, 10, 15),
        ticker="NVDA",
        quantity=20.0,
        proceeds=2000.0,
        cost_basis=3000.0,
    )
    buy = TradeFactory(
        account="Robinhood",
        date=date(2024, 10, 20),
        ticker="NVDA",
        action="Buy",
        quantity=20.0,
        cost_basis=2200.0,
    )
    result = detect_wash_sales([sell, buy], {})

    assert len(result.violations) == 1
    v = result.violations[0]
    assert v.confidence == "Confirmed"
    assert v.disallowed_loss == 1000.0


def test_cross_year_wash_sale():
    """Dec 20 loss sale, Jan 5 buy → wash sale detected."""
    sell = LossSaleFactory(
        date=date(2024, 12, 20),
        ticker="AAPL",
        quantity=50.0,
        proceeds=5000.0,
        cost_basis=7500.0,
    )
    buy = TradeFactory(
        date=date(2025, 1, 5),
        ticker="AAPL",
        action="Buy",
        quantity=50.0,
        cost_basis=5500.0,
    )
    result = detect_wash_sales([sell, buy], {})

    assert len(result.violations) == 1
    assert result.violations[0].disallowed_loss == 2500.0


def test_basis_unknown_excluded_as_loss_sale():
    """Trades with basis_unknown cannot be loss sale candidates."""
    sell = TradeFactory(
        action="Sell",
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=10.0,
        proceeds=2000.0,
        basis_unknown=True,
    )
    buy = TradeFactory(
        date=date(2024, 10, 20),
        ticker="TSLA",
        action="Buy",
        quantity=10.0,
        cost_basis=2500.0,
    )
    result = detect_wash_sales([sell, buy], {})
    assert len(result.violations) == 0


def test_basis_unknown_can_be_replacement_buy():
    """basis_unknown buy CAN trigger a wash sale on a known-basis loss sale."""
    sell = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=10.0,
        proceeds=2000.0,
        cost_basis=3000.0,
    )
    buy = TradeFactory(
        date=date(2024, 10, 20),
        ticker="TSLA",
        action="Buy",
        quantity=10.0,
        basis_unknown=True,
        cost_basis=None,
    )
    result = detect_wash_sales([sell, buy], {})

    assert len(result.violations) == 1
    assert result.violations[0].disallowed_loss == 1000.0
    assert result.basis_unknown_count == 1


def test_basis_unknown_count():
    """Detection result counts basis_unknown trades."""
    trades = [
        TradeFactory(basis_unknown=True),
        TradeFactory(basis_unknown=True),
        TradeFactory(basis_unknown=False),
    ]
    result = detect_wash_sales(trades, {})
    assert result.basis_unknown_count == 2


def test_multiple_loss_sales_share_same_buy_lot():
    """Two loss sales match the same buy — lot quantity split between them."""
    sell1 = LossSaleFactory(
        date=date(2024, 10, 10),
        ticker="TSLA",
        quantity=5.0,
        proceeds=1000.0,
        cost_basis=1500.0,
    )
    sell2 = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=5.0,
        proceeds=1000.0,
        cost_basis=1500.0,
    )
    buy = TradeFactory(
        date=date(2024, 10, 20),
        ticker="TSLA",
        action="Buy",
        quantity=8.0,
        cost_basis=2000.0,
    )
    result = detect_wash_sales([sell1, sell2, buy], {})

    assert len(result.violations) == 2
    # sell1 consumes 5 of buy's 8 shares
    assert result.violations[0].matched_quantity == 5.0
    assert result.violations[0].disallowed_loss == 500.0
    # sell2 consumes remaining 3 of buy's 8 shares
    assert result.violations[1].matched_quantity == 3.0
    assert result.violations[1].disallowed_loss == 300.0


def test_no_trades_empty_result():
    result = detect_wash_sales([], {})
    assert result.violations == []
    assert result.lots == []
    assert result.basis_unknown_count == 0
```

- [ ] **Step 2: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_detector.py -v`
Expected: All 16 tests PASS

- [ ] **Step 3: Commit**

```bash
git add tests/engine/test_detector.py
git commit -m "test: cross-account, cross-year, basis_unknown, and edge cases"
```

---

### Task 13: Wash Sale Detector — Options and ETF Scenarios

**Files:**
- Modify: `tests/engine/test_detector.py`

- [ ] **Step 1: Write tests for options and ETF detection**

```python
# append to tests/engine/test_detector.py
from net_alpha.models.domain import OptionDetails

ETF_PAIRS = {
    "sp500": ["SPY", "VOO", "IVV", "SPLG"],
    "nasdaq100": ["QQQ", "QQQM"],
}


def test_option_wash_sale_same_option():
    """Sold option at loss, rebought identical option → Confirmed."""
    sell = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=1.0,
        proceeds=200.0,
        cost_basis=500.0,
        option_details=OptionDetails(
            strike=250.0, expiry=date(2024, 12, 20), call_put="C"
        ),
    )
    buy = TradeFactory(
        date=date(2024, 10, 20),
        ticker="TSLA",
        action="Buy",
        quantity=1.0,
        cost_basis=450.0,
        option_details=OptionDetails(
            strike=250.0, expiry=date(2024, 12, 20), call_put="C"
        ),
    )
    result = detect_wash_sales([sell, buy], {})

    assert len(result.violations) == 1
    assert result.violations[0].confidence == "Confirmed"
    assert result.violations[0].disallowed_loss == 300.0


def test_option_wash_sale_different_strike():
    """Sold option at loss, bought different strike → Probable."""
    sell = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=1.0,
        proceeds=200.0,
        cost_basis=500.0,
        option_details=OptionDetails(
            strike=250.0, expiry=date(2024, 12, 20), call_put="C"
        ),
    )
    buy = TradeFactory(
        date=date(2024, 10, 20),
        ticker="TSLA",
        action="Buy",
        quantity=1.0,
        cost_basis=600.0,
        option_details=OptionDetails(
            strike=300.0, expiry=date(2024, 12, 20), call_put="C"
        ),
    )
    result = detect_wash_sales([sell, buy], {})

    assert len(result.violations) == 1
    assert result.violations[0].confidence == "Probable"


def test_stock_loss_call_purchase():
    """Sold stock at loss, bought call → Probable."""
    sell = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=10.0,
        proceeds=2000.0,
        cost_basis=3000.0,
    )
    buy = TradeFactory(
        date=date(2024, 10, 20),
        ticker="TSLA",
        action="Buy",
        quantity=1.0,
        cost_basis=500.0,
        option_details=OptionDetails(
            strike=250.0, expiry=date(2024, 12, 20), call_put="C"
        ),
    )
    result = detect_wash_sales([sell, buy], {})

    assert len(result.violations) == 1
    assert result.violations[0].confidence == "Probable"


def test_stock_loss_sold_put_unclear():
    """Sold stock at loss, sold put → Unclear."""
    sell = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="TSLA",
        quantity=10.0,
        proceeds=2000.0,
        cost_basis=3000.0,
    )
    sold_put = TradeFactory(
        date=date(2024, 10, 20),
        ticker="TSLA",
        action="Sell",
        quantity=1.0,
        proceeds=300.0,
        cost_basis=None,
        option_details=OptionDetails(
            strike=200.0, expiry=date(2024, 12, 20), call_put="P"
        ),
    )
    result = detect_wash_sales([sell, sold_put], {})

    assert len(result.violations) == 1
    assert result.violations[0].confidence == "Unclear"


def test_etf_substantially_identical_wash_sale():
    """Sold SPY at loss, bought VOO → Unclear."""
    sell = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="SPY",
        quantity=10.0,
        proceeds=4000.0,
        cost_basis=5000.0,
    )
    buy = TradeFactory(
        date=date(2024, 10, 20),
        ticker="VOO",
        action="Buy",
        quantity=10.0,
        cost_basis=4200.0,
    )
    result = detect_wash_sales([sell, buy], ETF_PAIRS)

    assert len(result.violations) == 1
    assert result.violations[0].confidence == "Unclear"
    assert result.violations[0].disallowed_loss == 1000.0


def test_etf_no_match_different_group():
    """SPY loss, QQQ buy → no wash sale (different index groups)."""
    sell = LossSaleFactory(
        date=date(2024, 10, 15),
        ticker="SPY",
        quantity=10.0,
        proceeds=4000.0,
        cost_basis=5000.0,
    )
    buy = TradeFactory(
        date=date(2024, 10, 20),
        ticker="QQQ",
        action="Buy",
        quantity=10.0,
        cost_basis=3000.0,
    )
    result = detect_wash_sales([sell, buy], ETF_PAIRS)
    assert len(result.violations) == 0
```

- [ ] **Step 2: Run tests to verify they pass**

Run: `uv run pytest tests/engine/test_detector.py -v`
Expected: All 22 tests PASS

- [ ] **Step 3: Run the full test suite**

Run: `uv run pytest -v`
Expected: All tests across all files PASS

- [ ] **Step 4: Run linter**

Run: `uv run ruff check . && uv run ruff format --check .`
Expected: No errors

- [ ] **Step 5: Commit**

```bash
git add tests/engine/test_detector.py
git commit -m "test: options and ETF wash sale detection scenarios"
```

---

### Task 14: Final Validation — Full Test Suite

- [ ] **Step 1: Run full test suite with coverage**

Run: `uv run pytest --cov=net_alpha --cov-report=term-missing -v`
Expected: All tests PASS, high coverage on `models/domain.py`, `engine/matcher.py`, `engine/detector.py`, `engine/etf_pairs.py`

- [ ] **Step 2: Run linter and formatter**

Run: `make check`
Expected: No errors

- [ ] **Step 3: Final commit if any formatting changes**

```bash
git add -A
git commit -m "style: apply ruff formatting"
```
