# CI/CD, Release Publishing & Package Publishing Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add GitHub Actions CI/CD, automated versioning via conventional commits, PyPI Trusted Publishing, GitHub Release creation, and README status badges — all free for a public repo.

**Architecture:** Three workflow files handle separate concerns: `.github/workflows/ci.yml` runs tests on every push/PR/nightly; `.github/workflows/version.yml` bumps the version on merge to master using `python-semantic-release` and pushes a tag; `.github/workflows/release.yml` fires on that tag to build, publish to PyPI, and create a GitHub Release. A fine-grained PAT is required so the tag pushed by `.github/workflows/version.yml` can trigger `.github/workflows/release.yml` (GITHUB_TOKEN pushes cannot trigger other workflows by design).

**Tech Stack:** GitHub Actions (free for public repos), `python-semantic-release` v8+, `hatch` (already configured), `pypa/gh-action-pypi-publish` (OIDC Trusted Publishing), `codecov/codecov-action` v4, `astral-sh/setup-uv`

---

## Required One-Time Manual Setup (Do Before Running Workflows)

Complete these before pushing workflows, or the first release will fail.

### A. Create fine-grained PAT (`RELEASE_TOKEN`)

`.github/workflows/version.yml` pushes commits and tags using a PAT so that the tag push triggers `.github/workflows/release.yml`. (Pushes using `GITHUB_TOKEN` cannot trigger other workflows — GitHub security restriction.)

1. GitHub → Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token
2. Repository access: `chen-star/net_alpha` only
3. Permissions → Repository permissions → **Contents: Read and Write**
4. Generate and copy the token value
5. GitHub repo → Settings → Secrets and variables → Actions → New repository secret:
   - Name: `RELEASE_TOKEN`
   - Value: paste token

### B. Create PyPI Trusted Publisher

No API key needed — PyPI verifies GitHub's OIDC identity at publish time.

1. First, create the PyPI project. Easiest: run `rm -rf dist && hatch build && twine upload dist/* --user __token__ --password pypi-YOURTOKEN` locally once. This registers the `wash-alpha` project name.
2. On pypi.org → your project → Publishing → Add a new publisher:
   - Provider: **GitHub**
   - Owner: `chen-star`
   - Repository name: `net_alpha`
   - Workflow filename: `.github/workflows/release.yml`
   - Environment name: `pypi`
   - Project name: `wash-alpha`
3. In GitHub repo → Settings → Environments → New environment: `pypi`
   (Optionally add yourself as a required reviewer for a manual gate before publishing)

### C. Set up Codecov

1. Sign in at codecov.io with your GitHub account
2. Add `chen-star/net_alpha` repository
3. Copy the `CODECOV_TOKEN` shown on the setup page
4. GitHub repo → Settings → Secrets → New secret: `CODECOV_TOKEN` = paste value

---

## File Map

| File | Action | Responsibility |
|---|---|---|
| `.github/workflows/ci.yml` | Create | Lint, test, coverage on push/PR/nightly |
| `.github/workflows/version.yml` | Create | Auto/manual version bump → tag push |
| `.github/workflows/release.yml` | Create | Build wheel+sdist, publish PyPI, create GitHub Release |
| `pyproject.toml` | Modify | Add `[tool.semantic_release]` config block |
| `README.md` | Modify | Add three status badges after the `# net-alpha` heading (PyPI badge uses `wash-alpha`) |

---

## Task 1: Create `.github/workflows/ci.yml`

**Files:**
- Create: `.github/workflows/ci.yml`

- [ ] **Step 1: Create the workflows directory and `.github/workflows/ci.yml`**

```bash
mkdir -p .github/workflows
```

Create `.github/workflows/ci.yml` with this exact content:

```yaml
name: CI

on:
  push:
    branches: [master]
  pull_request:
  schedule:
    - cron: '0 0 * * *'

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ['3.11', '3.12']
    steps:
      - uses: actions/checkout@v4

      - name: Install uv
        uses: astral-sh/setup-uv@v4
        with:
          version: latest

      - name: Install Python ${{ matrix.python-version }}
        run: uv python install ${{ matrix.python-version }}

      - name: Install dependencies
        run: uv sync --dev

      - name: Lint
        run: |
          uv run ruff check .
          uv run ruff format --check .

      - name: Test with coverage
        run: uv run pytest --cov=src --cov-report=xml

      - name: Upload coverage to Codecov
        uses: codecov/codecov-action@v4
        with:
          token: ${{ secrets.CODECOV_TOKEN }}
          files: ./coverage.xml
```

- [ ] **Step 2: Validate YAML syntax**

```bash
python -c "import yaml; yaml.safe_load(open('.github/workflows/ci.yml'))" && echo "Valid YAML"
```

Expected output: `Valid YAML`

- [ ] **Step 3: Commit**

```bash
git add .github/workflows/ci.yml
git commit -m "ci: add CI workflow (lint, test, coverage on push/PR/nightly)"
```

---

## Task 2: Add `python-semantic-release` config to `pyproject.toml`

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Append semantic_release config block**

Add the following to the end of `pyproject.toml`:

```toml
[tool.semantic_release]
version_toml = ["pyproject.toml:project.version"]
branch = "master"
build_command = ""
tag_format = "v{version}"
commit_message = "chore: release v{version} [skip ci]"
```

`build_command = ""` tells PSR not to build distributions — that is handled by `.github/workflows/release.yml`. `[skip ci]` in the commit message prevents `.github/workflows/ci.yml` from running on the version bump commit.

- [ ] **Step 2: Verify the file is valid TOML**

```bash
python -c "import tomllib; tomllib.loads(open('pyproject.toml').read())" && echo "Valid TOML"
```

Expected output: `Valid TOML`

- [ ] **Step 3: Commit**

```bash
git add pyproject.toml
git commit -m "chore: add python-semantic-release config"
```

---

## Task 3: Create `.github/workflows/version.yml`

**Files:**
- Create: `.github/workflows/version.yml`

- [ ] **Step 1: Create `.github/workflows/version.yml`**

Create `.github/workflows/version.yml` with this exact content:

```yaml
name: Version Bump

on:
  push:
    branches: [master]
    paths-ignore:
      - 'docs/**'
      - '*.md'
      - '.github/**'
  workflow_dispatch:
    inputs:
      bump:
        description: 'Version bump type'
        required: true
        type: choice
        options:
          - patch
          - minor
          - major

permissions:
  contents: write

jobs:
  version:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
          token: ${{ secrets.RELEASE_TOKEN }}

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - name: Install python-semantic-release
        run: pip install python-semantic-release

      - name: Configure git
        run: |
          git config user.name "github-actions[bot]"
          git config user.email "github-actions[bot]@users.noreply.github.com"

      - name: Auto version bump (conventional commits)
        if: github.event_name == 'push'
        run: semantic-release version --no-vcs-release
        env:
          GH_TOKEN: ${{ secrets.RELEASE_TOKEN }}

      - name: Manual version bump
        if: github.event_name == 'workflow_dispatch'
        run: semantic-release version --${{ github.event.inputs.bump }} --no-vcs-release
        env:
          GH_TOKEN: ${{ secrets.RELEASE_TOKEN }}
```

Key notes:
- `fetch-depth: 0` — PSR needs full git history to find the last tag and analyze commits since then
- `token: ${{ secrets.RELEASE_TOKEN }}` — checks out with PAT so the subsequent tag push triggers `.github/workflows/release.yml`
- `--no-vcs-release` — PSR only bumps version + commits + tags; the GitHub Release is created by `.github/workflows/release.yml`
- `paths-ignore` on docs/md/workflow files prevents version bumps when only docs change

- [ ] **Step 2: Validate YAML syntax**

```bash
python -c "import yaml; yaml.safe_load(open('.github/workflows/version.yml'))" && echo "Valid YAML"
```

Expected output: `Valid YAML`

- [ ] **Step 3: Commit**

```bash
git add .github/workflows/version.yml
git commit -m "ci: add version bump workflow (conventional commits + manual override)"
```

---

## Task 4: Create `.github/workflows/release.yml`

**Files:**
- Create: `.github/workflows/release.yml`

- [ ] **Step 1: Create `.github/workflows/release.yml`**

Create `.github/workflows/release.yml` with this exact content:

```yaml
name: Release

on:
  push:
    tags:
      - 'v*.*.*'

permissions:
  contents: write
  id-token: write

jobs:
  release:
    runs-on: ubuntu-latest
    environment: pypi
    steps:
      - uses: actions/checkout@v4

      - name: Install uv
        uses: astral-sh/setup-uv@v4
        with:
          version: latest

      - name: Install hatch
        run: pip install hatch

      - name: Build distributions
        run: hatch build

      - name: Publish to PyPI
        uses: pypa/gh-action-pypi-publish@release/v1

      - name: Create GitHub Release
        run: |
          gh release create "${{ github.ref_name }}" \
            dist/* \
            --title "${{ github.ref_name }}" \
            --generate-notes
        env:
          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

Key notes:
- `id-token: write` — required for OIDC Trusted Publishing (the `pypa/gh-action-pypi-publish` action uses this to get a short-lived identity token)
- `environment: pypi` — maps to the `pypi` GitHub Environment configured in the one-time setup; add required reviewers there for a manual gate
- `--generate-notes` — GitHub auto-generates release notes from commits between tags
- `dist/*` — attaches both `.whl` and `.tar.gz` as release assets

- [ ] **Step 2: Validate YAML syntax**

```bash
python -c "import yaml; yaml.safe_load(open('.github/workflows/release.yml'))" && echo "Valid YAML"
```

Expected output: `Valid YAML`

- [ ] **Step 3: Commit**

```bash
git add .github/workflows/release.yml
git commit -m "ci: add release workflow (hatch build, PyPI OIDC publish, GitHub Release)"
```

---

## Task 5: Add badges to README

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Add badge block after the `# net-alpha` heading**

The current `README.md` starts with:

```markdown
# net-alpha

Cross-account wash sale detection for equities, options, and ETFs.
```

Replace that opening block with:

```markdown
# net-alpha

[![CI](https://github.com/chen-star/net_alpha/actions/workflows/ci.yml/badge.svg)](https://github.com/chen-star/net_alpha/actions/workflows/ci.yml)
[![PyPI version](https://badge.fury.io/py/wash-alpha.svg)](https://pypi.org/project/wash-alpha/)
[![codecov](https://codecov.io/gh/chen-star/net_alpha/branch/master/graph/badge.svg)](https://codecov.io/gh/chen-star/net_alpha)

Cross-account wash sale detection for equities, options, and ETFs.
```

- [ ] **Step 2: Verify the badge URLs match the correct repo and package name**

- CI badge URL: `chen-star/net_alpha` ✓ (matches GitHub repo)
- PyPI badge: `wash-alpha` ✓ (matches `name = "wash-alpha"` in `pyproject.toml`)
- Codecov badge: `chen-star/net_alpha` ✓

- [ ] **Step 3: Commit**

```bash
git add README.md
git commit -m "docs: add CI, PyPI, and coverage badges to README"
```

---

## Task 6: Push all commits and verify

- [ ] **Step 1: Push to master**

```bash
git push origin master
```

- [ ] **Step 2: Verify CI workflow triggers**

Go to: `https://github.com/chen-star/net_alpha/actions/workflows/ci.yml`

Expected: a new run appears for the push. It should turn green (lint passes, tests pass).

- [ ] **Step 3: Verify `.github/workflows/version.yml` does not bump on doc/workflow commits**

The commits pushed in Tasks 1-5 are all docs or workflow files (covered by `paths-ignore`). `.github/workflows/version.yml` should NOT create a version bump for these. Check:

`https://github.com/chen-star/net_alpha/actions/workflows/version.yml`

Expected: either no run triggered, or a run that exits early with "no release will be made" because there are no `fix:`/`feat:` commits.

- [ ] **Step 4: Test manual version bump (dry run)**

In GitHub repo → Actions → Version Bump → Run workflow → select `patch` → Run.

This will bump `0.1.0` → `0.1.1`, push a `v0.1.1` tag, which triggers `.github/workflows/release.yml`.

**Only do this after completing the PyPI Trusted Publisher setup in the one-time setup section**, otherwise `.github/workflows/release.yml` will fail at the publish step.

- [ ] **Step 5: Verify GitHub Release was created**

Go to: `https://github.com/chen-star/net_alpha/releases`

Expected: a `v0.1.1` release with `net_alpha-0.1.1-py3-none-any.whl` and `net_alpha-0.1.1.tar.gz` attached.

- [ ] **Step 6: Verify PyPI package is live**

Go to: `https://pypi.org/project/wash-alpha/`

Expected: `wash-alpha 0.1.1` is listed.

---

## Day-to-Day Usage After Setup

**Normal development flow:**

```bash
# Feature commit → triggers minor bump on merge
git commit -m "feat: add support for Fidelity CSV format"

# Bug fix commit → triggers patch bump on merge  
git commit -m "fix: handle empty lot when computing adjusted basis"

# Breaking change → triggers major bump
git commit -m "feat!: rename rebuys command to safe-rebuy"
# or include BREAKING CHANGE in footer:
git commit -m "feat: rename command

BREAKING CHANGE: rebuys is now safe-rebuy"
```

Merge to `master` → `.github/workflows/version.yml` auto-bumps → `.github/workflows/release.yml` builds and publishes.

**Force a specific bump (e.g. for a release candidate):**

GitHub → Actions → Version Bump → Run workflow → select `major` / `minor` / `patch`
