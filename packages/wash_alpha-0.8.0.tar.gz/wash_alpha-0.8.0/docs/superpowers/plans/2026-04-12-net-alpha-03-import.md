# net_alpha CSV Import Pipeline — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Implement the full CSV import pipeline: row anonymization, LLM-powered schema detection with caching, option symbol regex parsing, trade deduplication, and the main import orchestrator.

**Architecture:** The import pipeline flows: raw CSV → anonymize sample rows → LLM schema detection (or cache hit) → user confirms mapping → parse all rows using mapping → regex-parse option symbols → deduplicate → persist trades. The LLM is only called once per broker format (keyed by `broker_name + SHA256(header_row)`). Option symbols are parsed by hand-written regexes selected by the `option_format` field in the schema cache.

**Tech Stack:** Python 3.11+, Anthropic SDK (mocked in tests), hashlib, csv, re, pytest

**Dependencies:** Plans 1 (Core Engine) and 2 (Storage Layer) must be completed first.

---

## File Structure

| Action | Path | Responsibility |
|--------|------|----------------|
| Create | `src/net_alpha/import_/__init__.py` | Import sub-package |
| Create | `src/net_alpha/import_/anonymizer.py` | `anonymize_row` — strip PII before LLM call |
| Create | `src/net_alpha/import_/option_parser.py` | Regex parsers for option symbols by format |
| Create | `src/net_alpha/import_/schema_detection.py` | LLM schema detection + retry logic |
| Create | `src/net_alpha/import_/csv_reader.py` | Read CSV + apply column mapping to produce Trades |
| Create | `src/net_alpha/import_/dedup.py` | Deduplication via raw_row_hash + semantic key |
| Create | `src/net_alpha/import_/importer.py` | Main import orchestrator |
| Create | `tests/import_/__init__.py` | Tests sub-package |
| Create | `tests/import_/test_anonymizer.py` | Anonymizer tests |
| Create | `tests/import_/test_option_parser.py` | Option parser tests |
| Create | `tests/import_/test_schema_detection.py` | Schema detection tests (mocked LLM) |
| Create | `tests/import_/test_csv_reader.py` | CSV reader tests |
| Create | `tests/import_/test_dedup.py` | Dedup tests |
| Create | `tests/fixtures/schwab_sample.csv` | Anonymized Schwab CSV fixture |
| Create | `tests/fixtures/robinhood_sample.csv` | Anonymized Robinhood CSV fixture |

---

### Task 1: Row Anonymizer

**Files:**
- Create: `src/net_alpha/import_/__init__.py`
- Create: `src/net_alpha/import_/anonymizer.py`
- Create: `tests/import_/__init__.py`
- Create: `tests/import_/test_anonymizer.py`

- [ ] **Step 1: Create package directories**

```bash
mkdir -p src/net_alpha/import_ tests/import_ tests/fixtures
touch src/net_alpha/import_/__init__.py tests/import_/__init__.py
```

- [ ] **Step 2: Write the failing tests**

```python
# tests/import_/test_anonymizer.py
from net_alpha.import_.anonymizer import anonymize_row


def test_numeric_values_replaced():
    row = {"Amount": "1234.56", "Price": "99.50", "Date": "2024-10-15"}
    result = anonymize_row(row)
    assert result["Amount"] == "1.00"
    assert result["Price"] == "1.00"


def test_dates_preserved():
    row = {"Date": "2024-10-15", "Settlement": "10/17/2024"}
    result = anonymize_row(row)
    assert result["Date"] == "2024-10-15"
    assert result["Settlement"] == "10/17/2024"


def test_tickers_preserved():
    row = {"Symbol": "TSLA", "Amount": "500.00"}
    result = anonymize_row(row)
    assert result["Symbol"] == "TSLA"
    assert result["Amount"] == "1.00"


def test_account_numbers_masked():
    row = {"Account": "XXXX-1234567", "Symbol": "AAPL"}
    result = anonymize_row(row)
    assert result["Account"] == "XXXX"
    assert result["Symbol"] == "AAPL"


def test_standalone_long_number_masked():
    row = {"Ref": "987654321", "Symbol": "NVDA"}
    result = anonymize_row(row)
    assert result["Ref"] == "XXXX"


def test_negative_numbers_replaced():
    row = {"Amount": "-1234.56"}
    result = anonymize_row(row)
    assert result["Amount"] == "1.00"


def test_dollar_sign_stripped_and_replaced():
    row = {"Amount": "$5,432.10"}
    result = anonymize_row(row)
    assert result["Amount"] == "1.00"


def test_empty_values_preserved():
    row = {"Amount": "", "Notes": ""}
    result = anonymize_row(row)
    assert result["Amount"] == ""
    assert result["Notes"] == ""


def test_option_symbols_preserved():
    row = {"Symbol": "TSLA 12/20/2024 250.00 C", "Amount": "300.00"}
    result = anonymize_row(row)
    assert result["Symbol"] == "TSLA 12/20/2024 250.00 C"
    assert result["Amount"] == "1.00"
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `uv run pytest tests/import_/test_anonymizer.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 4: Write the implementation**

```python
# src/net_alpha/import_/anonymizer.py
from __future__ import annotations

import re

# Matches standalone numbers with 4+ digits (account numbers)
_ACCOUNT_PATTERN = re.compile(r"^\d{4,}$|[-_]\d{4,}$|\d{4,}[-_]|^\w*-\d{4,}")

# Matches numeric values: optional $, optional negative, digits with commas, optional decimal
_NUMERIC_PATTERN = re.compile(r"^[($-]*[\d,]+\.?\d*[)]*$")

# Matches date patterns (YYYY-MM-DD, MM/DD/YYYY, etc.)
_DATE_PATTERN = re.compile(
    r"^\d{4}-\d{2}-\d{2}$"  # 2024-10-15
    r"|^\d{1,2}/\d{1,2}/\d{2,4}$"  # 10/15/2024
    r"|^\w+ \d{1,2}, \d{4}$"  # October 15, 2024
)

# Matches ticker-like strings (1-5 uppercase letters, optionally with option suffix)
_TICKER_PATTERN = re.compile(r"^[A-Z]{1,5}(\s|$)")


def anonymize_row(raw_row: dict[str, str]) -> dict[str, str]:
    """Anonymize a CSV row before sending to LLM.

    Rules:
    1. Numeric columns → replace with "1.00"
    2. Account number patterns (4+ digit sequences) → replace with "XXXX"
    3. Dates → kept as-is (structural signal, not PII)
    4. Ticker symbols → kept as-is (needed for LLM column identification)
    """
    result = {}
    for key, value in raw_row.items():
        result[key] = _anonymize_value(value)
    return result


def _anonymize_value(value: str) -> str:
    if not value or not value.strip():
        return value

    stripped = value.strip()

    # Preserve dates
    if _DATE_PATTERN.match(stripped):
        return value

    # Preserve ticker-like values (uppercase letters, option symbols)
    if _TICKER_PATTERN.match(stripped) and not stripped.isdigit():
        return value

    # Mask account numbers (4+ digit sequences)
    if _ACCOUNT_PATTERN.match(stripped):
        return "XXXX"

    # Replace numeric values
    clean = stripped.replace("$", "").replace(",", "").replace("(", "").replace(")", "")
    try:
        float(clean)
        return "1.00"
    except ValueError:
        pass

    return value
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/import_/test_anonymizer.py -v`
Expected: All 9 tests PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/import_/__init__.py src/net_alpha/import_/anonymizer.py tests/import_/__init__.py tests/import_/test_anonymizer.py
git commit -m "feat: add row anonymizer for LLM schema detection"
```

---

### Task 2: Option Symbol Regex Parsers

**Files:**
- Create: `src/net_alpha/import_/option_parser.py`
- Create: `tests/import_/test_option_parser.py`

- [ ] **Step 1: Write the failing tests**

```python
# tests/import_/test_option_parser.py
from datetime import date

from net_alpha.import_.option_parser import parse_option_symbol
from net_alpha.models.domain import OptionDetails


def test_occ_standard_format():
    """OCC standard: TSLA241220C00250000"""
    result = parse_option_symbol("TSLA241220C00250000", "occ_standard")
    assert result is not None
    assert result.strike == 250.0
    assert result.expiry == date(2024, 12, 20)
    assert result.call_put == "C"


def test_occ_standard_put():
    result = parse_option_symbol("AAPL241115P00175000", "occ_standard")
    assert result is not None
    assert result.strike == 175.0
    assert result.call_put == "P"


def test_schwab_human_format():
    """Schwab human-readable: TSLA 12/20/2024 250.00 C"""
    result = parse_option_symbol("TSLA 12/20/2024 250.00 C", "schwab_human")
    assert result is not None
    assert result.strike == 250.0
    assert result.expiry == date(2024, 12, 20)
    assert result.call_put == "C"


def test_schwab_human_put():
    result = parse_option_symbol("NVDA 01/17/2025 500.00 P", "schwab_human")
    assert result is not None
    assert result.strike == 500.0
    assert result.expiry == date(2025, 1, 17)
    assert result.call_put == "P"


def test_robinhood_human_format():
    """Robinhood: TSLA $250 Call 12/20/2024"""
    result = parse_option_symbol("TSLA $250 Call 12/20/2024", "robinhood_human")
    assert result is not None
    assert result.strike == 250.0
    assert result.expiry == date(2024, 12, 20)
    assert result.call_put == "C"


def test_robinhood_human_put():
    result = parse_option_symbol("AAPL $175.50 Put 11/15/2024", "robinhood_human")
    assert result is not None
    assert result.strike == 175.5
    assert result.expiry == date(2024, 11, 15)
    assert result.call_put == "P"


def test_plain_equity_returns_none():
    """Plain ticker is not an option."""
    assert parse_option_symbol("TSLA", "occ_standard") is None
    assert parse_option_symbol("AAPL", "schwab_human") is None


def test_unknown_format_cascade():
    """Unknown format tries all parsers."""
    result = parse_option_symbol("TSLA241220C00250000", "unknown_format")
    assert result is not None
    assert result.strike == 250.0


def test_unparseable_returns_none():
    """Truly unparseable string."""
    result = parse_option_symbol("SOME RANDOM TEXT", "occ_standard")
    assert result is None


def test_extract_underlying_ticker():
    from net_alpha.import_.option_parser import extract_underlying
    assert extract_underlying("TSLA241220C00250000", "occ_standard") == "TSLA"
    assert extract_underlying("TSLA 12/20/2024 250.00 C", "schwab_human") == "TSLA"
    assert extract_underlying("TSLA $250 Call 12/20/2024", "robinhood_human") == "TSLA"
    assert extract_underlying("AAPL", "occ_standard") == "AAPL"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/import_/test_option_parser.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Write the implementation**

```python
# src/net_alpha/import_/option_parser.py
from __future__ import annotations

import re
from datetime import date
from typing import Optional

from net_alpha.models.domain import OptionDetails

# OCC standard: TSLA241220C00250000
# Ticker (1-6 chars) + YYMMDD + C/P + strike * 1000 (8 digits, zero-padded)
_OCC_PATTERN = re.compile(
    r"^(?P<ticker>[A-Z]{1,6})"
    r"(?P<yy>\d{2})(?P<mm>\d{2})(?P<dd>\d{2})"
    r"(?P<cp>[CP])"
    r"(?P<strike>\d{8})$"
)

# Schwab human-readable: TSLA 12/20/2024 250.00 C
_SCHWAB_PATTERN = re.compile(
    r"^(?P<ticker>[A-Z]{1,6})\s+"
    r"(?P<mm>\d{1,2})/(?P<dd>\d{1,2})/(?P<yyyy>\d{4})\s+"
    r"(?P<strike>[\d.]+)\s+"
    r"(?P<cp>[CP])$"
)

# Robinhood human-readable: TSLA $250 Call 12/20/2024
_ROBINHOOD_PATTERN = re.compile(
    r"^(?P<ticker>[A-Z]{1,6})\s+"
    r"\$(?P<strike>[\d.]+)\s+"
    r"(?P<cp_word>Call|Put)\s+"
    r"(?P<mm>\d{1,2})/(?P<dd>\d{1,2})/(?P<yyyy>\d{4})$"
)

_PARSERS = {
    "occ_standard": _parse_occ,
    "schwab_human": _parse_schwab,
    "robinhood_human": _parse_robinhood,
}


def parse_option_symbol(
    symbol: str, option_format: str
) -> Optional[OptionDetails]:
    """Parse an option symbol string into OptionDetails.

    Uses the specified format's regex. Unknown formats try all parsers.
    Returns None if the symbol is not an option or cannot be parsed.
    """
    symbol = symbol.strip()

    if option_format in _PARSERS:
        result = _PARSERS[option_format](symbol)
        if result is not None:
            return result
        # If specified parser fails, don't cascade — only cascade for unknown
        if option_format != "unknown_format":
            return None

    # Best-effort cascade for unknown formats
    for parser in [_parse_occ, _parse_schwab, _parse_robinhood]:
        result = parser(symbol)
        if result is not None:
            return result

    return None


def extract_underlying(symbol: str, option_format: str) -> str:
    """Extract the underlying ticker from a symbol string.

    For options, extracts the underlying ticker (e.g., "TSLA" from "TSLA241220C00250000").
    For plain equities, returns the symbol as-is.
    """
    symbol = symbol.strip()

    # Try OCC format
    m = _OCC_PATTERN.match(symbol)
    if m:
        return m.group("ticker")

    # Try Schwab format
    m = _SCHWAB_PATTERN.match(symbol)
    if m:
        return m.group("ticker")

    # Try Robinhood format
    m = _ROBINHOOD_PATTERN.match(symbol)
    if m:
        return m.group("ticker")

    # Plain equity ticker
    return symbol.split()[0] if " " in symbol else symbol


def _parse_occ(symbol: str) -> Optional[OptionDetails]:
    m = _OCC_PATTERN.match(symbol)
    if not m:
        return None
    return OptionDetails(
        strike=int(m.group("strike")) / 1000.0,
        expiry=date(2000 + int(m.group("yy")), int(m.group("mm")), int(m.group("dd"))),
        call_put=m.group("cp"),
    )


def _parse_schwab(symbol: str) -> Optional[OptionDetails]:
    m = _SCHWAB_PATTERN.match(symbol)
    if not m:
        return None
    return OptionDetails(
        strike=float(m.group("strike")),
        expiry=date(int(m.group("yyyy")), int(m.group("mm")), int(m.group("dd"))),
        call_put=m.group("cp"),
    )


def _parse_robinhood(symbol: str) -> Optional[OptionDetails]:
    m = _ROBINHOOD_PATTERN.match(symbol)
    if not m:
        return None
    cp = "C" if m.group("cp_word") == "Call" else "P"
    return OptionDetails(
        strike=float(m.group("strike")),
        expiry=date(int(m.group("yyyy")), int(m.group("mm")), int(m.group("dd"))),
        call_put=cp,
    )
```

Note: The `_PARSERS` dict references functions defined below it. In Python, this is fine because the dict is evaluated at module load time, but the functions must be defined before the dict. Move the `_PARSERS` dict definition to AFTER the three `_parse_*` functions:

```python
# Correct ordering in the file: patterns at top, then _parse_* functions, then _PARSERS dict, then public functions.
```

The full correct file order is:
1. Imports
2. Regex patterns (`_OCC_PATTERN`, `_SCHWAB_PATTERN`, `_ROBINHOOD_PATTERN`)
3. `_parse_occ`, `_parse_schwab`, `_parse_robinhood`
4. `_PARSERS` dict
5. `parse_option_symbol`, `extract_underlying`

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/import_/test_option_parser.py -v`
Expected: All 11 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/import_/option_parser.py tests/import_/test_option_parser.py
git commit -m "feat: add option symbol regex parsers (OCC, Schwab, Robinhood)"
```

---

### Task 3: LLM Schema Detection (Mocked)

**Files:**
- Create: `src/net_alpha/import_/schema_detection.py`
- Create: `tests/import_/test_schema_detection.py`

- [ ] **Step 1: Write the failing tests**

```python
# tests/import_/test_schema_detection.py
import json
from unittest.mock import MagicMock, patch

import pytest

from net_alpha.import_.schema_detection import (
    SchemaMapping,
    detect_schema,
    _build_prompt,
)


def _mock_anthropic_response(mapping: dict) -> MagicMock:
    """Create a mock Anthropic API response."""
    mock_response = MagicMock()
    mock_response.content = [MagicMock(text=json.dumps(mapping))]
    return mock_response


SAMPLE_MAPPING = {
    "date": "Date",
    "ticker": "Symbol",
    "action": "Action",
    "quantity": "Quantity",
    "proceeds": "Amount",
    "cost_basis": "Cost Basis",
    "buy_values": ["Buy", "Reinvest"],
    "sell_values": ["Sell"],
    "option_format": "schwab_human",
}


def test_detect_schema_success():
    mock_client = MagicMock()
    mock_client.messages.create.return_value = _mock_anthropic_response(SAMPLE_MAPPING)

    headers = ["Date", "Symbol", "Action", "Quantity", "Amount", "Cost Basis"]
    sample_rows = [
        {"Date": "2024-10-15", "Symbol": "TSLA", "Action": "Buy", "Quantity": "1.00", "Amount": "1.00", "Cost Basis": "1.00"},
    ]

    result = detect_schema(mock_client, headers, sample_rows, "claude-3-5-haiku-latest")
    assert isinstance(result, SchemaMapping)
    assert result.date == "Date"
    assert result.ticker == "Symbol"
    assert "Buy" in result.buy_values


def test_detect_schema_retry_on_failure():
    mock_client = MagicMock()
    mock_client.messages.create.side_effect = [
        Exception("API error"),
        Exception("API error"),
        _mock_anthropic_response(SAMPLE_MAPPING),
    ]

    headers = ["Date", "Symbol", "Action", "Quantity", "Amount"]
    sample_rows = [{"Date": "2024-10-15", "Symbol": "TSLA", "Action": "Buy", "Quantity": "1.00", "Amount": "1.00"}]

    result = detect_schema(mock_client, headers, sample_rows, "claude-3-5-haiku-latest", max_retries=3)
    assert result is not None
    assert mock_client.messages.create.call_count == 3


def test_detect_schema_hard_fail_after_retries():
    mock_client = MagicMock()
    mock_client.messages.create.side_effect = Exception("API error")

    headers = ["Date", "Symbol"]
    sample_rows = [{"Date": "2024-10-15", "Symbol": "TSLA"}]

    with pytest.raises(RuntimeError, match="Schema detection failed"):
        detect_schema(mock_client, headers, sample_rows, "claude-3-5-haiku-latest", max_retries=3)

    assert mock_client.messages.create.call_count == 3


def test_build_prompt_includes_headers_and_rows():
    headers = ["Date", "Symbol", "Action"]
    rows = [{"Date": "2024-10-15", "Symbol": "TSLA", "Action": "Buy"}]
    prompt = _build_prompt(headers, rows)
    assert "Date" in prompt
    assert "Symbol" in prompt
    assert "TSLA" in prompt


def test_schema_mapping_model():
    mapping = SchemaMapping(**SAMPLE_MAPPING)
    assert mapping.date == "Date"
    assert mapping.option_format == "schwab_human"


def test_schema_mapping_optional_fields():
    minimal = SchemaMapping(
        date="Date",
        ticker="Symbol",
        action="Action",
        quantity="Qty",
        buy_values=["Buy"],
        sell_values=["Sell"],
    )
    assert minimal.proceeds is None
    assert minimal.cost_basis is None
    assert minimal.option_format is None
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/import_/test_schema_detection.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Write the implementation**

```python
# src/net_alpha/import_/schema_detection.py
from __future__ import annotations

import json
import time
from typing import Optional

from pydantic import BaseModel


class SchemaMapping(BaseModel):
    """Detected column mapping from a broker CSV."""

    date: str
    ticker: str
    action: str
    quantity: str
    proceeds: Optional[str] = None
    cost_basis: Optional[str] = None
    buy_values: list[str]
    sell_values: list[str]
    option_format: Optional[str] = None


def detect_schema(
    client,
    headers: list[str],
    sample_rows: list[dict[str, str]],
    model: str,
    max_retries: int = 3,
) -> SchemaMapping:
    """Call LLM to detect CSV schema from headers and anonymized sample rows.

    Retries up to max_retries with exponential backoff.
    Raises RuntimeError on final failure.
    """
    prompt = _build_prompt(headers, sample_rows)

    last_error = None
    for attempt in range(max_retries):
        try:
            response = client.messages.create(
                model=model,
                max_tokens=1024,
                messages=[{"role": "user", "content": prompt}],
            )
            text = response.content[0].text
            # Extract JSON from response (handle markdown code blocks)
            text = _extract_json(text)
            data = json.loads(text)
            return SchemaMapping(**data)
        except Exception as e:
            last_error = e
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)  # Exponential backoff: 1s, 2s, 4s

    raise RuntimeError(
        f"Schema detection failed after {max_retries} attempts. "
        f"Last error: {last_error}"
    )


def _build_prompt(
    headers: list[str], sample_rows: list[dict[str, str]]
) -> str:
    """Build the LLM prompt for schema detection."""
    header_str = ", ".join(headers)
    rows_str = "\n".join(
        ", ".join(f"{k}: {v}" for k, v in row.items()) for row in sample_rows
    )

    return f"""Analyze this broker CSV format and return a JSON mapping.

CSV Headers: {header_str}

Sample rows (anonymized):
{rows_str}

Return a JSON object with these fields:
- "date": column name containing trade date
- "ticker": column name containing ticker/symbol
- "action": column name containing buy/sell action
- "quantity": column name containing quantity/shares
- "proceeds": column name containing sale proceeds or total amount (null if not present)
- "cost_basis": column name containing cost basis (null if not present)
- "buy_values": list of values in the action column that mean "buy" (e.g., ["Buy", "Reinvest"])
- "sell_values": list of values in the action column that mean "sell" (e.g., ["Sell"])
- "option_format": if options are present, the format type: "occ_standard", "schwab_human", or "robinhood_human" (null if no options or unknown)

Return ONLY the JSON object, no other text."""


def _extract_json(text: str) -> str:
    """Extract JSON from LLM response, handling markdown code blocks."""
    text = text.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        # Remove first and last lines (``` markers)
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines)
    return text.strip()
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/import_/test_schema_detection.py -v`
Expected: All 6 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/import_/schema_detection.py tests/import_/test_schema_detection.py
git commit -m "feat: add LLM schema detection with retry and exponential backoff"
```

---

### Task 4: CSV Reader with Schema Mapping

**Files:**
- Create: `src/net_alpha/import_/csv_reader.py`
- Create: `tests/import_/test_csv_reader.py`
- Create: `tests/fixtures/schwab_sample.csv`

- [ ] **Step 1: Create the Schwab fixture CSV**

```csv
Date,Symbol,Action,Quantity,Amount,Cost Basis
10/15/2024,TSLA,Buy,10,2400.00,2400.00
10/20/2024,TSLA,Sell,10,2000.00,2400.00
10/25/2024,TSLA 12/20/2024 250.00 C,Buy,1,500.00,500.00
11/01/2024,AAPL,Reinvest,5,750.00,750.00
```

Save as `tests/fixtures/schwab_sample.csv`.

- [ ] **Step 2: Write the failing tests**

```python
# tests/import_/test_csv_reader.py
from datetime import date
from pathlib import Path

from net_alpha.import_.csv_reader import read_csv_with_mapping, compute_header_hash
from net_alpha.import_.schema_detection import SchemaMapping

FIXTURES = Path(__file__).parent.parent / "fixtures"

SCHWAB_MAPPING = SchemaMapping(
    date="Date",
    ticker="Symbol",
    action="Action",
    quantity="Quantity",
    proceeds="Amount",
    cost_basis="Cost Basis",
    buy_values=["Buy", "Reinvest"],
    sell_values=["Sell"],
    option_format="schwab_human",
)


def test_read_schwab_csv():
    trades = read_csv_with_mapping(
        csv_path=FIXTURES / "schwab_sample.csv",
        mapping=SCHWAB_MAPPING,
        account="Schwab",
        schema_cache_id="sc1",
    )
    assert len(trades) == 4

    # First trade: equity buy
    t0 = trades[0]
    assert t0.account == "Schwab"
    assert t0.ticker == "TSLA"
    assert t0.action == "Buy"
    assert t0.quantity == 10.0
    assert t0.proceeds == 2400.0
    assert t0.date == date(2024, 10, 15)
    assert t0.is_option() is False
    assert t0.schema_cache_id == "sc1"
    assert t0.raw_row_hash is not None

    # Second trade: equity sell
    t1 = trades[1]
    assert t1.action == "Sell"
    assert t1.is_loss() is True

    # Third trade: option buy
    t2 = trades[2]
    assert t2.ticker == "TSLA"  # Underlying extracted
    assert t2.is_option() is True
    assert t2.option_details.strike == 250.0
    assert t2.option_details.call_put == "C"

    # Fourth trade: reinvest mapped to Buy
    t3 = trades[3]
    assert t3.action == "Buy"
    assert t3.ticker == "AAPL"


def test_compute_header_hash():
    h1 = compute_header_hash(["Date", "Symbol", "Action"])
    h2 = compute_header_hash(["Date", "Symbol", "Action"])
    h3 = compute_header_hash(["Date", "Ticker", "Action"])
    assert h1 == h2
    assert h1 != h3


def test_missing_cost_basis_marked():
    """When cost_basis column is None in mapping, trades are marked basis_unknown."""
    mapping = SchemaMapping(
        date="Date",
        ticker="Symbol",
        action="Action",
        quantity="Quantity",
        proceeds="Amount",
        cost_basis=None,
        buy_values=["Buy", "Reinvest"],
        sell_values=["Sell"],
    )
    trades = read_csv_with_mapping(
        csv_path=FIXTURES / "schwab_sample.csv",
        mapping=mapping,
        account="Schwab",
        schema_cache_id="sc1",
    )
    assert all(t.basis_unknown for t in trades)
```

- [ ] **Step 3: Run tests to verify they fail**

Run: `uv run pytest tests/import_/test_csv_reader.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 4: Write the implementation**

```python
# src/net_alpha/import_/csv_reader.py
from __future__ import annotations

import csv
import hashlib
from datetime import date
from pathlib import Path

from net_alpha.import_.option_parser import extract_underlying, parse_option_symbol
from net_alpha.import_.schema_detection import SchemaMapping
from net_alpha.models.domain import Trade


def read_csv_with_mapping(
    csv_path: Path,
    mapping: SchemaMapping,
    account: str,
    schema_cache_id: str,
) -> list[Trade]:
    """Read a broker CSV and produce Trade objects using the given schema mapping."""
    trades: list[Trade] = []

    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            raw_hash = _hash_row(row)
            trade = _row_to_trade(row, mapping, account, schema_cache_id, raw_hash)
            if trade is not None:
                trades.append(trade)

    return trades


def compute_header_hash(headers: list[str]) -> str:
    """SHA256 hash of the CSV header row for schema cache keying."""
    joined = ",".join(h.strip() for h in headers)
    return hashlib.sha256(joined.encode()).hexdigest()


def get_headers_and_samples(
    csv_path: Path, sample_count: int = 3
) -> tuple[list[str], list[dict[str, str]]]:
    """Read CSV headers and up to sample_count sample rows."""
    with open(csv_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        samples = []
        for i, row in enumerate(reader):
            if i >= sample_count:
                break
            samples.append(dict(row))
    return list(headers), samples


def _row_to_trade(
    row: dict[str, str],
    mapping: SchemaMapping,
    account: str,
    schema_cache_id: str,
    raw_hash: str,
) -> Trade | None:
    """Convert a CSV row to a Trade using the schema mapping."""
    raw_action = row.get(mapping.action, "").strip()

    # Determine canonical action
    if raw_action in mapping.buy_values:
        action = "Buy"
    elif raw_action in mapping.sell_values:
        action = "Sell"
    else:
        return None  # Skip rows that aren't buys or sells

    raw_date = row.get(mapping.date, "").strip()
    trade_date = _parse_date(raw_date)
    if trade_date is None:
        return None

    raw_symbol = row.get(mapping.ticker, "").strip()
    option_format = mapping.option_format

    # Parse option details if applicable
    option_details = None
    if option_format:
        option_details = parse_option_symbol(raw_symbol, option_format)

    # Extract underlying ticker
    ticker = extract_underlying(raw_symbol, option_format or "")

    quantity = _parse_float(row.get(mapping.quantity, ""))
    if quantity is None or quantity == 0:
        return None

    proceeds = _parse_float(row.get(mapping.proceeds, "")) if mapping.proceeds else None
    cost_basis = _parse_float(row.get(mapping.cost_basis, "")) if mapping.cost_basis else None
    basis_unknown = mapping.cost_basis is None or (
        mapping.cost_basis and not row.get(mapping.cost_basis, "").strip()
    )

    return Trade(
        account=account,
        date=trade_date,
        ticker=ticker,
        action=action,
        quantity=quantity,
        proceeds=proceeds,
        cost_basis=cost_basis,
        basis_unknown=basis_unknown if mapping.cost_basis is None else False,
        option_details=option_details,
        raw_row_hash=raw_hash,
        schema_cache_id=schema_cache_id,
    )


def _parse_date(raw: str) -> date | None:
    """Parse a date string in common formats."""
    for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%m-%d-%Y", "%m/%d/%y"):
        try:
            from datetime import datetime
            return datetime.strptime(raw, fmt).date()
        except ValueError:
            continue
    return None


def _parse_float(raw: str | None) -> float | None:
    """Parse a float from a CSV value, handling $, commas, parens."""
    if raw is None:
        return None
    raw = raw.strip()
    if not raw:
        return None
    negative = raw.startswith("(") and raw.endswith(")")
    clean = raw.replace("$", "").replace(",", "").replace("(", "").replace(")", "")
    try:
        val = float(clean)
        return -val if negative else val
    except ValueError:
        return None


def _hash_row(row: dict[str, str]) -> str:
    """SHA256 hash of a raw CSV row for deduplication."""
    content = "|".join(f"{k}={v}" for k, v in sorted(row.items()))
    return hashlib.sha256(content.encode()).hexdigest()
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `uv run pytest tests/import_/test_csv_reader.py -v`
Expected: All 3 tests PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/import_/csv_reader.py tests/import_/test_csv_reader.py tests/fixtures/schwab_sample.csv
git commit -m "feat: add CSV reader with schema mapping and option parsing"
```

---

### Task 5: Trade Deduplication

**Files:**
- Create: `src/net_alpha/import_/dedup.py`
- Create: `tests/import_/test_dedup.py`

- [ ] **Step 1: Write the failing tests**

```python
# tests/import_/test_dedup.py
from datetime import date
from unittest.mock import MagicMock

from net_alpha.import_.dedup import deduplicate_trades
from net_alpha.models.domain import Trade


def _make_trade(**kwargs) -> Trade:
    defaults = {
        "account": "Schwab",
        "date": date(2024, 10, 15),
        "ticker": "TSLA",
        "action": "Buy",
        "quantity": 10.0,
        "proceeds": None,
        "cost_basis": 2400.0,
        "raw_row_hash": "hash_abc",
    }
    defaults.update(kwargs)
    return Trade(**defaults)


def test_no_duplicates_all_new():
    trades = [_make_trade(raw_row_hash="h1"), _make_trade(raw_row_hash="h2")]
    mock_repo = MagicMock()
    mock_repo.find_by_hash.return_value = None
    mock_repo.find_by_semantic_key.return_value = None

    new, skipped = deduplicate_trades(trades, mock_repo)
    assert len(new) == 2
    assert skipped == 0


def test_hash_duplicate_skipped():
    trades = [_make_trade(raw_row_hash="existing_hash")]
    mock_repo = MagicMock()
    mock_repo.find_by_hash.return_value = _make_trade()  # Exists

    new, skipped = deduplicate_trades(trades, mock_repo)
    assert len(new) == 0
    assert skipped == 1


def test_semantic_key_duplicate_skipped():
    trades = [_make_trade(raw_row_hash="new_hash")]
    mock_repo = MagicMock()
    mock_repo.find_by_hash.return_value = None
    mock_repo.find_by_semantic_key.return_value = _make_trade()  # Semantic match

    new, skipped = deduplicate_trades(trades, mock_repo)
    assert len(new) == 0
    assert skipped == 1


def test_mixed_new_and_duplicate():
    trades = [
        _make_trade(raw_row_hash="new1", ticker="TSLA"),
        _make_trade(raw_row_hash="existing", ticker="AAPL"),
        _make_trade(raw_row_hash="new2", ticker="NVDA"),
    ]
    mock_repo = MagicMock()

    def hash_lookup(h):
        return _make_trade() if h == "existing" else None

    mock_repo.find_by_hash.side_effect = hash_lookup
    mock_repo.find_by_semantic_key.return_value = None

    new, skipped = deduplicate_trades(trades, mock_repo)
    assert len(new) == 2
    assert skipped == 1


def test_null_hash_uses_semantic_key_only():
    trades = [_make_trade(raw_row_hash=None)]
    mock_repo = MagicMock()
    mock_repo.find_by_hash.return_value = None
    mock_repo.find_by_semantic_key.return_value = None

    new, skipped = deduplicate_trades(trades, mock_repo)
    assert len(new) == 1
    # Should not call find_by_hash with None
    mock_repo.find_by_hash.assert_not_called()
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/import_/test_dedup.py -v`
Expected: FAIL with `ModuleNotFoundError`

- [ ] **Step 3: Write the implementation**

```python
# src/net_alpha/import_/dedup.py
from __future__ import annotations

from net_alpha.db.repository import TradeRepository
from net_alpha.models.domain import Trade


def deduplicate_trades(
    trades: list[Trade],
    repo: TradeRepository,
) -> tuple[list[Trade], int]:
    """Filter out duplicate trades using two-signal strategy.

    Primary: raw_row_hash (SHA256 of entire raw CSV row).
    Secondary: semantic key (broker, date, ticker, action, quantity, proceeds).

    Returns (new_trades, skipped_count).
    """
    new_trades: list[Trade] = []
    skipped = 0

    for trade in trades:
        if _is_duplicate(trade, repo):
            skipped += 1
        else:
            new_trades.append(trade)

    return new_trades, skipped


def _is_duplicate(trade: Trade, repo: TradeRepository) -> bool:
    # Primary signal: raw_row_hash
    if trade.raw_row_hash is not None:
        if repo.find_by_hash(trade.raw_row_hash) is not None:
            return True

    # Secondary signal: semantic key
    existing = repo.find_by_semantic_key(
        account=trade.account,
        date_str=trade.date.isoformat(),
        ticker=trade.ticker,
        action=trade.action,
        quantity=trade.quantity,
        proceeds=trade.proceeds,
    )
    return existing is not None
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/import_/test_dedup.py -v`
Expected: All 5 tests PASS

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/import_/dedup.py tests/import_/test_dedup.py
git commit -m "feat: add trade deduplication with hash and semantic key signals"
```

---

### Task 6: Main Import Orchestrator

**Files:**
- Create: `src/net_alpha/import_/importer.py`

- [ ] **Step 1: Write the implementation**

The import orchestrator ties together all the pieces. It is called by the CLI and coordinates:
1. Reading headers + sample rows
2. Checking schema cache
3. If cache miss: anonymize samples → LLM detection → user confirmation
4. Reading all rows with mapping
5. Deduplicating
6. Persisting new trades

```python
# src/net_alpha/import_/importer.py
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from uuid import uuid4

from net_alpha.import_.anonymizer import anonymize_row
from net_alpha.import_.csv_reader import (
    compute_header_hash,
    get_headers_and_samples,
    read_csv_with_mapping,
)
from net_alpha.import_.dedup import deduplicate_trades
from net_alpha.import_.schema_detection import SchemaMapping, detect_schema


@dataclass
class ImportResult:
    total_parsed: int
    new_imported: int
    duplicates_skipped: int
    equities: int
    options: int
    etfs: int  # Count is approximate — based on known ETF tickers, or 0


@dataclass
class ImportContext:
    """Everything the import orchestrator needs to run."""
    csv_path: Path
    broker_name: str
    anthropic_client: object  # Anthropic client instance
    model: str
    max_retries: int
    # Callbacks for user interaction (injected by CLI layer)
    confirm_schema: object  # Callable[[SchemaMapping, list[str]], bool]
    # Repository access
    trade_repo: object  # TradeRepository
    schema_cache_repo: object  # SchemaCacheRepository
    session: object  # SQLModel Session


def run_import(ctx: ImportContext) -> ImportResult:
    """Run the full import pipeline.

    1. Read headers + samples
    2. Check schema cache → if miss, call LLM + confirm
    3. Parse all rows
    4. Deduplicate
    5. Persist
    """
    headers, raw_samples = get_headers_and_samples(ctx.csv_path)
    header_hash = compute_header_hash(headers)

    # Check schema cache
    cached = ctx.schema_cache_repo.find_by_broker_and_hash(ctx.broker_name, header_hash)
    if cached is not None:
        mapping = SchemaMapping(**json.loads(cached.column_mapping))
        schema_cache_id = cached.id
    else:
        # Anonymize samples before LLM call
        anon_samples = [anonymize_row(row) for row in raw_samples]

        # LLM schema detection
        mapping = detect_schema(
            client=ctx.anthropic_client,
            headers=headers,
            sample_rows=anon_samples,
            model=ctx.model,
            max_retries=ctx.max_retries,
        )

        # User confirmation
        if not ctx.confirm_schema(mapping, headers):
            raise RuntimeError("Schema rejected by user. Import cancelled.")

        # Cache the confirmed schema
        from net_alpha.db.tables import SchemaCacheRow

        schema_cache_id = str(uuid4())
        cache_row = SchemaCacheRow(
            id=schema_cache_id,
            broker_name=ctx.broker_name,
            header_hash=header_hash,
            column_mapping=mapping.model_dump_json(),
            option_format=mapping.option_format,
        )
        ctx.schema_cache_repo.save(cache_row)
        ctx.session.commit()

    # Parse all CSV rows
    trades = read_csv_with_mapping(
        csv_path=ctx.csv_path,
        mapping=mapping,
        account=ctx.broker_name,
        schema_cache_id=schema_cache_id,
    )

    # Deduplicate
    new_trades, skipped = deduplicate_trades(trades, ctx.trade_repo)

    # Persist
    ctx.trade_repo.save_batch(new_trades)
    ctx.session.commit()

    # Count types
    options_count = sum(1 for t in new_trades if t.is_option())
    equities_count = len(new_trades) - options_count

    return ImportResult(
        total_parsed=len(trades),
        new_imported=len(new_trades),
        duplicates_skipped=skipped,
        equities=equities_count,
        options=options_count,
        etfs=0,  # ETF classification requires the ETF pairs list; CLI layer handles display
    )
```

- [ ] **Step 2: Run the full test suite**

Run: `uv run pytest -v`
Expected: All tests PASS

- [ ] **Step 3: Run linter**

Run: `make check`
Expected: Clean

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/import_/importer.py
git commit -m "feat: add main import orchestrator"
```

---

### Task 7: Golden File Integration Tests

**Files:**
- Create: `tests/fixtures/robinhood_sample.csv`
- Create: `tests/import_/test_integration.py`

- [ ] **Step 1: Create Robinhood fixture CSV**

```csv
Activity Date,Instrument,Trans Code,Quantity,Price,Amount
10/15/2024,TSLA,Buy,10,240.00,2400.00
10/20/2024,TSLA,Sell,10,200.00,2000.00
10/25/2024,TSLA $250 Call 12/20/2024,Buy,1,500.00,500.00
11/01/2024,AAPL,Buy,5,150.00,750.00
```

Save as `tests/fixtures/robinhood_sample.csv`.

- [ ] **Step 2: Write the integration tests**

```python
# tests/import_/test_integration.py
from datetime import date
from pathlib import Path

from net_alpha.import_.csv_reader import read_csv_with_mapping
from net_alpha.import_.schema_detection import SchemaMapping

FIXTURES = Path(__file__).parent.parent / "fixtures"


def test_schwab_golden_file():
    mapping = SchemaMapping(
        date="Date",
        ticker="Symbol",
        action="Action",
        quantity="Quantity",
        proceeds="Amount",
        cost_basis="Cost Basis",
        buy_values=["Buy", "Reinvest"],
        sell_values=["Sell"],
        option_format="schwab_human",
    )
    trades = read_csv_with_mapping(
        csv_path=FIXTURES / "schwab_sample.csv",
        mapping=mapping,
        account="Schwab",
        schema_cache_id="test",
    )
    assert len(trades) == 4

    # Verify specific trade details
    buy_tsla = trades[0]
    assert buy_tsla.ticker == "TSLA"
    assert buy_tsla.action == "Buy"
    assert buy_tsla.quantity == 10.0
    assert buy_tsla.date == date(2024, 10, 15)

    # Option trade
    option = trades[2]
    assert option.ticker == "TSLA"
    assert option.is_option()
    assert option.option_details.strike == 250.0


def test_robinhood_golden_file():
    mapping = SchemaMapping(
        date="Activity Date",
        ticker="Instrument",
        action="Trans Code",
        quantity="Quantity",
        proceeds="Amount",
        cost_basis=None,
        buy_values=["Buy"],
        sell_values=["Sell"],
        option_format="robinhood_human",
    )
    trades = read_csv_with_mapping(
        csv_path=FIXTURES / "robinhood_sample.csv",
        mapping=mapping,
        account="Robinhood",
        schema_cache_id="test",
    )
    assert len(trades) == 4

    sell_tsla = trades[1]
    assert sell_tsla.ticker == "TSLA"
    assert sell_tsla.action == "Sell"
    assert sell_tsla.proceeds == 2000.0
    assert sell_tsla.basis_unknown is True

    option = trades[2]
    assert option.ticker == "TSLA"
    assert option.is_option()
    assert option.option_details.strike == 250.0
    assert option.option_details.call_put == "C"
```

- [ ] **Step 3: Run tests**

Run: `uv run pytest tests/import_/test_integration.py -v`
Expected: All 2 tests PASS

- [ ] **Step 4: Run the full test suite**

Run: `uv run pytest -v`
Expected: All tests PASS

- [ ] **Step 5: Commit**

```bash
git add tests/fixtures/robinhood_sample.csv tests/import_/test_integration.py
git commit -m "test: add golden file integration tests for Schwab and Robinhood CSV"
```
