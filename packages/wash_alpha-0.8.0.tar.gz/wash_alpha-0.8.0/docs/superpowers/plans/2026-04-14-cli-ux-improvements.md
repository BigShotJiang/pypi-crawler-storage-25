# CLI UX Improvements Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Polish the full CLI for both accidental victims (User A) and active harvesters (User B) — progress spinners, color-coded output, a new `status` command, broker autocomplete, validation improvements, `--quiet` flag, and cross-command hints.

**Architecture:** All changes are confined to the CLI layer (`src/net_alpha/cli/`) and the `MetaRepository` in the DB layer. The detection engine is untouched. A new `MetaRepository` wraps the existing `meta` key-value table to store `last_check_at`. The `status` command reads from already-persisted violation/trade data — it does not re-run detection.

**Tech Stack:** Python 3.11+, typer, rich (spinners via `console.status()`), questionary (autocomplete), difflib (ticker suggestions), sqlmodel, pytest, factory_boy

---

## File Map

| Action | File | Responsibility |
|--------|------|----------------|
| Modify | `src/net_alpha/cli/output.py` | Add `print_hint()` and `format_currency_colored()` helpers |
| Modify | `src/net_alpha/db/repository.py` | Add `MetaRepository` (get/set meta keys) |
| Create | `src/net_alpha/cli/status.py` | New `status_command` |
| Modify | `src/net_alpha/cli/app.py` | Register `status` command; replace no-args fallback |
| Modify | `src/net_alpha/cli/check.py` | Spinner, `--type` validation, `--quiet`, hints, write `last_check_at` |
| Modify | `src/net_alpha/cli/report.py` | Spinner, `--quiet` |
| Modify | `src/net_alpha/cli/import_cmd.py` | Spinners, example values in schema confirmation, post-import nudge |
| Modify | `src/net_alpha/cli/simulate.py` | Ticker validation with `difflib` suggestion |
| Modify | `src/net_alpha/cli/rebuys.py` | Urgency coloring on days remaining, cross-command hint |
| Modify | `src/net_alpha/cli/tax_position.py` | Color-coded monetary values, cross-command hint |
| Modify | `src/net_alpha/cli/wizard.py` | Broker autocomplete, "what to do next" panel |
| Modify | `tests/cli/test_output.py` | Tests for new helpers |
| Modify | `tests/db/test_repository.py` | Tests for `MetaRepository` |
| Create | `tests/cli/test_status.py` | Unit tests for `status_command` logic helpers |
| Modify | `tests/cli/test_check.py` | Tests for `--type` validation, `--quiet`, hint logic |
| Modify | `tests/cli/test_simulate.py` | Tests for ticker validation helpers |
| Modify | `tests/integration/cli/test_check.py` | Integration tests for `--quiet` |
| Create | `tests/integration/cli/test_status.py` | Integration tests for `status` command |

---

## Task 1: Shared output helpers

**Files:**
- Modify: `src/net_alpha/cli/output.py`
- Modify: `tests/cli/test_output.py`

- [ ] **Step 1: Write failing tests**

Add to `tests/cli/test_output.py`:

```python
from net_alpha.cli.output import format_currency_colored, print_hint


def test_format_currency_colored_positive():
    result = format_currency_colored(1200.0)
    assert "[green]" in result
    assert "$1,200.00" in result


def test_format_currency_colored_negative():
    result = format_currency_colored(-500.0)
    assert "[red]" in result
    assert "($500.00)" in result


def test_format_currency_colored_zero():
    result = format_currency_colored(0.0)
    assert "[green]" not in result
    assert "[red]" not in result
    assert "$0.00" in result


def test_print_hint():
    from io import StringIO
    from rich.console import Console
    buf = StringIO()
    console = Console(file=buf, no_color=True)
    print_hint(console, "Run net-alpha check to scan")
    output = buf.getvalue()
    assert "Run net-alpha check to scan" in output
```

- [ ] **Step 2: Run to confirm they fail**

```bash
uv run pytest tests/cli/test_output.py::test_format_currency_colored_positive tests/cli/test_output.py::test_print_hint -v
```

Expected: `ImportError` or `AttributeError` — functions don't exist yet.

- [ ] **Step 3: Implement helpers**

Add to `src/net_alpha/cli/output.py` (after existing functions):

```python
def format_currency_colored(amount: float) -> str:
    """Return Rich markup string with green/red color based on sign."""
    formatted = format_currency(amount)
    if amount > 0:
        return f"[green]{formatted}[/green]"
    elif amount < 0:
        return f"[red]{formatted}[/red]"
    return formatted


def print_hint(console: Console, text: str) -> None:
    """Print a single contextual nudge line before the disclaimer."""
    console.print(f"\n  [dim]\u2192 {text}[/dim]")
```

- [ ] **Step 4: Run tests to confirm pass**

```bash
uv run pytest tests/cli/test_output.py -v
```

Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/cli/output.py tests/cli/test_output.py
git commit -m "feat: add print_hint and format_currency_colored output helpers"
```

---

## Task 2: MetaRepository

**Files:**
- Modify: `src/net_alpha/db/repository.py`
- Modify: `tests/db/test_repository.py`

- [ ] **Step 1: Write failing tests**

Add to `tests/db/test_repository.py` (use the existing in-memory engine pattern from that file — check the top of the file for the fixture, then add):

```python
from net_alpha.db.repository import MetaRepository
from net_alpha.db.tables import MetaRow


def test_meta_repository_get_missing(db_session):
    repo = MetaRepository(db_session)
    assert repo.get("nonexistent_key") is None


def test_meta_repository_set_and_get(db_session):
    repo = MetaRepository(db_session)
    repo.set("last_check_at", "2026-04-14")
    db_session.commit()
    assert repo.get("last_check_at") == "2026-04-14"


def test_meta_repository_set_overwrites(db_session):
    repo = MetaRepository(db_session)
    repo.set("last_check_at", "2026-04-10")
    db_session.commit()
    repo.set("last_check_at", "2026-04-14")
    db_session.commit()
    assert repo.get("last_check_at") == "2026-04-14"
```

- [ ] **Step 2: Check what fixture `db_session` looks like in `tests/db/test_repository.py`**

```bash
uv run pytest tests/db/test_repository.py -v --collect-only 2>&1 | head -30
```

Read `tests/db/test_repository.py` to understand the fixture. If it uses `tmp_path` + `get_engine` + `init_db` + `Session`, use the same pattern. If there's a shared `db_session` fixture in `tests/conftest.py`, use that.

- [ ] **Step 3: Run to confirm tests fail**

```bash
uv run pytest tests/db/test_repository.py::test_meta_repository_set_and_get -v
```

Expected: `ImportError` — `MetaRepository` not defined yet.

- [ ] **Step 4: Implement `MetaRepository`**

Add to `src/net_alpha/db/repository.py` (after `SchemaCacheRepository`):

```python
class MetaRepository:
    def __init__(self, session: Session):
        self._session = session

    def get(self, key: str) -> str | None:
        row = self._session.exec(select(MetaRow).where(MetaRow.key == key)).first()
        return row.value if row else None

    def set(self, key: str, value: str) -> None:
        row = self._session.exec(select(MetaRow).where(MetaRow.key == key)).first()
        if row:
            row.value = value
            self._session.add(row)
        else:
            self._session.add(MetaRow(key=key, value=value))
```

Add `MetaRow` to the import at the top of `repository.py`:

```python
from net_alpha.db.tables import (
    LotRow,
    MetaRow,
    SchemaCacheRow,
    TradeRow,
    WashSaleViolationRow,
)
```

- [ ] **Step 5: Run tests to confirm pass**

```bash
uv run pytest tests/db/test_repository.py -v
```

Expected: all PASS.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_repository.py
git commit -m "feat: add MetaRepository for reading and writing meta key-value pairs"
```

---

## Task 3: `net-alpha status` command

**Files:**
- Create: `src/net_alpha/cli/status.py`
- Modify: `src/net_alpha/cli/app.py`
- Create: `tests/cli/test_status.py`
- Create: `tests/integration/cli/test_status.py`

- [ ] **Step 1: Write failing unit tests for status helpers**

Create `tests/cli/test_status.py`:

```python
from datetime import date, timedelta

from net_alpha.cli.status import _days_ago_str, _staleness_style


def test_days_ago_str_recent():
    today = date.today()
    recent = (today - timedelta(days=3)).isoformat()
    assert "3 days ago" in _days_ago_str(recent)


def test_days_ago_str_today():
    today = date.today().isoformat()
    assert "today" in _days_ago_str(today)


def test_staleness_style_fresh():
    today = date.today()
    recent = (today - timedelta(days=5)).isoformat()
    assert _staleness_style(recent) == ""


def test_staleness_style_stale():
    today = date.today()
    stale = (today - timedelta(days=35)).isoformat()
    assert "yellow" in _staleness_style(stale)
```

- [ ] **Step 2: Run to confirm fail**

```bash
uv run pytest tests/cli/test_status.py -v
```

Expected: `ModuleNotFoundError` — `status.py` doesn't exist.

- [ ] **Step 3: Create `src/net_alpha/cli/status.py`**

```python
from __future__ import annotations

from datetime import date, timedelta

from rich.console import Console

from net_alpha.cli.output import confidence_style, format_currency, print_disclaimer

console = Console()


def status_command() -> None:
    """Show imported data freshness, last scan results, and open rebuy windows."""
    from net_alpha.cli.app import _bootstrap
    from net_alpha.db.repository import MetaRepository, TradeRepository, ViolationRepository

    settings, session = _bootstrap()
    trade_repo = TradeRepository(session)
    violation_repo = ViolationRepository(session)
    meta_repo = MetaRepository(session)

    all_trades = trade_repo.list_all()
    if not all_trades:
        console.print("\n  No trades imported. Run [bold]net-alpha import[/bold] to get started.")
        session.close()
        return

    accounts = trade_repo.list_accounts()

    # Data freshness
    console.print()
    console.print("  [bold]DATA FRESHNESS[/bold]")
    console.print("  " + "\u2500" * 50)
    for account in sorted(accounts):
        count = trade_repo.count_by_account(account)
        latest = trade_repo.latest_trade_date_by_account(account)
        days_str = _days_ago_str(latest) if latest else "unknown"
        style = _staleness_style(latest) if latest else "yellow"
        stale_marker = "  [yellow]\u26a0[/yellow]" if style == "yellow" else ""
        console.print(
            f"  {account:<20} {count:>5} trades    last import: {latest}  "
            f"({days_str}){stale_marker}"
        )

    # Violation summary
    violations = violation_repo.list_all()
    last_check = meta_repo.get("last_check_at")
    scan_year = date.today().year

    console.print()
    check_label = f"last check: {last_check}" if last_check else "never scanned"
    console.print(f"  [bold]WASH SALE SUMMARY \u2014 {scan_year} ({check_label})[/bold]")
    console.print("  " + "\u2500" * 50)

    if not violations:
        console.print("  No scan results yet. Run [bold]net-alpha check[/bold].")
    else:
        trade_repo_map = {t.id: t for t in all_trades}
        year_violations = [v for v in violations if trade_repo_map[v.loss_trade_id].date.year == scan_year]
        total = 0.0
        for label in ("Confirmed", "Probable", "Unclear"):
            vs = [v for v in year_violations if v.confidence == label]
            if vs:
                amt = sum(v.disallowed_loss for v in vs)
                total += amt
                style = confidence_style(label)
                console.print(
                    f"  [{style}]{label:12s}[/{style}] "
                    f"{len(vs):>3d} violations    "
                    f"{format_currency(amt):>12s} disallowed"
                )
        console.print("  " + "\u2500" * 50)
        console.print(f"  Total disallowed loss:       {format_currency(total)}")

    # Open rebuy windows
    rebuy_count = _count_open_rebuy_windows(all_trades, violations)
    if rebuy_count > 0:
        console.print()
        console.print("  [bold]OPEN REBUY WINDOWS[/bold]")
        console.print("  " + "\u2500" * 50)
        console.print(
            f"  {rebuy_count} position(s) still in 30-day window \u2014 "
            "run [bold]net-alpha rebuys[/bold]"
        )

    console.print()
    console.print("  " + "\u2500" * 50)
    console.print("  Run [bold]net-alpha check[/bold] to re-scan with latest data.")

    print_disclaimer(console)
    session.close()


def _days_ago_str(date_str: str) -> str:
    """Return human-readable relative date string."""
    delta = (date.today() - date.fromisoformat(date_str)).days
    if delta == 0:
        return "today"
    if delta == 1:
        return "1 day ago"
    return f"{delta} days ago"


def _staleness_style(date_str: str) -> str:
    """Return 'yellow' if date is more than 30 days ago, else ''."""
    delta = (date.today() - date.fromisoformat(date_str)).days
    return "yellow" if delta > 30 else ""


def _count_open_rebuy_windows(all_trades: list, violations: list) -> int:
    """Count loss sales with open 30-day rebuy windows not fully matched."""
    today = date.today()
    matched_qty_by_loss: dict[str, float] = {}
    for v in violations:
        matched_qty_by_loss.setdefault(v.loss_trade_id, 0.0)
        matched_qty_by_loss[v.loss_trade_id] += v.matched_quantity

    count = 0
    for t in all_trades:
        if not t.is_loss():
            continue
        window_end = t.date + timedelta(days=30)
        if window_end < today:
            continue
        remaining = t.quantity - matched_qty_by_loss.get(t.id, 0.0)
        if remaining > 0:
            count += 1
    return count
```

- [ ] **Step 4: Run unit tests to confirm pass**

```bash
uv run pytest tests/cli/test_status.py -v
```

Expected: all PASS.

- [ ] **Step 5: Register status command and replace no-args fallback in `app.py`**

In `src/net_alpha/cli/app.py`, add the import and register:

```python
from net_alpha.cli.status import status_command
```

Add after the other `app.command()` lines:

```python
app.command(name="status")(status_command)
```

Replace the `else` branch in `main_callback`:

```python
    else:
        # Show status overview if trades exist but no command given
        from net_alpha.cli.status import status_command
        status_command()
```

- [ ] **Step 6: Write integration test**

Create `tests/integration/cli/test_status.py`:

```python
from __future__ import annotations

import pytest
from sqlmodel import Session
from typer.testing import CliRunner

from net_alpha.cli.app import app
from tests.conftest import TradeFactory  # adjust if TradeFactory lives elsewhere


def test_status_no_trades(cli_setup):
    runner, engine, settings = cli_setup
    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "No trades imported" in result.output


def test_status_with_trades_no_check(cli_setup):
    runner, engine, settings = cli_setup
    from net_alpha.db.repository import TradeRepository
    from net_alpha.models.domain import Trade
    from datetime import date

    with Session(engine) as s:
        repo = TradeRepository(s)
        repo.save(Trade(account="schwab", date=date(2026, 1, 10), ticker="AAPL",
                        action="Buy", quantity=10, proceeds=None, cost_basis=1500.0))
        s.commit()

    result = runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "schwab" in result.output
    assert "No scan results yet" in result.output
    assert "informational only" in result.output


def test_status_shows_disclaimer(cli_setup):
    runner, engine, settings = cli_setup
    result = runner.invoke(app, ["status"])
    # Even with no trades, disclaimer not shown (exits early) — just check no crash
    assert result.exit_code == 0
```

- [ ] **Step 7: Run integration tests**

```bash
uv run pytest tests/integration/cli/test_status.py -v
```

Expected: all PASS (adjust `TradeFactory` import if needed — look at `tests/conftest.py` for the actual import path).

- [ ] **Step 8: Commit**

```bash
git add src/net_alpha/cli/status.py src/net_alpha/cli/app.py \
        tests/cli/test_status.py tests/integration/cli/test_status.py
git commit -m "feat: add net-alpha status dashboard command"
```

---

## Task 4: Progress spinners

**Files:**
- Modify: `src/net_alpha/cli/check.py`
- Modify: `src/net_alpha/cli/report.py`
- Modify: `src/net_alpha/cli/import_cmd.py`

No new test files — the existing integration tests verify these commands still work correctly. Spinners are visual-only.

- [ ] **Step 1: Add spinner to `check.py`**

In `check_command`, wrap the `detect_wash_sales` call:

```python
    # Run detection
    with console.status("Scanning for wash sales\u2026", spinner="dots"):
        result = detect_wash_sales(all_trades, etf_pairs)
```

- [ ] **Step 2: Add spinner to `report.py`**

In `report_command`, wrap the `detect_wash_sales` call:

```python
    with console.status("Scanning for wash sales\u2026", spinner="dots"):
        result = detect_wash_sales(all_trades, etf_pairs)
```

- [ ] **Step 3: Add spinners to `import_cmd.py`**

In `import_command`, wrap the `run_import` call:

```python
    try:
        with console.status("Importing trades\u2026", spinner="dots"):
            result = run_import(ctx)
```

The LLM schema detection call happens inside `run_import` → `ImportContext.confirm_schema` is called interactively, so the outer spinner is fine to wrap the whole thing. The spinner pauses during the interactive questionary prompt automatically because the prompt is printed to a TTY and the spinner writes to the same console — this is acceptable behavior.

- [ ] **Step 4: Run existing integration tests to confirm no regression**

```bash
uv run pytest tests/integration/cli/ -v
```

Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/cli/check.py src/net_alpha/cli/report.py src/net_alpha/cli/import_cmd.py
git commit -m "feat: add progress spinners to check, report, and import commands"
```

---

## Task 5: Color-coded `tax-position` + cross-command hint

**Files:**
- Modify: `src/net_alpha/cli/tax_position.py`

- [ ] **Step 1: Update `_render_tax_position` to use colored amounts**

Replace the `_render_tax_position` function body in `src/net_alpha/cli/tax_position.py`. Add the import at the top of the file:

```python
from net_alpha.cli.output import format_currency, format_currency_colored, print_disclaimer, print_hint
```

Replace `_render_tax_position`:

```python
def _render_tax_position(tp: TaxPosition) -> None:
    console.print()
    console.print(f"  [bold]TAX POSITION \u2014 {tp.year} (all accounts)[/bold]")
    console.print("  " + "\u2500" * 50)
    console.print(f"  Short-term gains:          {format_currency_colored(tp.st_gains):>12s}")
    console.print(f"  Short-term losses:         {format_currency_colored(tp.st_losses):>12s}")
    net_st_str = format_currency_colored(tp.net_st)
    console.print(f"  Net short-term:            {net_st_str:>12s}   (taxed at ordinary income rates)")
    console.print()
    console.print(f"  Long-term gains:           {format_currency_colored(tp.lt_gains):>12s}")
    console.print(f"  Long-term losses:          {format_currency_colored(tp.lt_losses):>12s}")
    net_lt_str = format_currency_colored(tp.net_lt)
    console.print(f"  Net long-term:             {net_lt_str:>12s}   (taxed at preferential rates)")
    console.print()
    console.print("  " + "\u2500" * 50)
    console.print(f"  Net capital gain:          {format_currency_colored(tp.net_capital_gain):>12s}")

    if tp.net_st > 0:
        console.print(
            f"  Loss still needed to zero short-term:  {format_currency(tp.loss_needed_to_zero_st)}"
        )

    if tp.carryforward > 0:
        console.print(f"  Loss carryforward (above $3,000 cap):  {format_currency(tp.carryforward)}")
```

- [ ] **Step 2: Add cross-command hint**

In `tax_position_command`, add before `print_disclaimer`:

```python
    if tp.net_st > 0:
        print_hint(console, "Run net-alpha simulate sell to check loss harvesting options")

    print_disclaimer(console)
```

- [ ] **Step 3: Run existing tests to confirm no regression**

```bash
uv run pytest tests/cli/test_tax_position.py tests/engine/test_tax_position.py -v
```

Expected: all PASS.

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/cli/tax_position.py
git commit -m "feat: color-code tax-position monetary values and add cross-command hint"
```

---

## Task 6: Urgency coloring + hint in `rebuys`

**Files:**
- Modify: `src/net_alpha/cli/rebuys.py`
- Modify: `tests/cli/test_rebuys.py` (create if it doesn't exist)

- [ ] **Step 1: Write failing test for urgency style helper**

Check if `tests/cli/test_rebuys.py` exists:

```bash
ls tests/cli/
```

If it doesn't exist, create `tests/cli/test_rebuys.py`. If it exists, add to it:

```python
from net_alpha.cli.rebuys import _days_remaining_style


def test_days_remaining_style_urgent():
    assert "bold red" in _days_remaining_style(5)


def test_days_remaining_style_warning():
    assert "yellow" in _days_remaining_style(10)


def test_days_remaining_style_safe():
    assert _days_remaining_style(20) == ""
```

- [ ] **Step 2: Run to confirm fail**

```bash
uv run pytest tests/cli/test_rebuys.py -v
```

Expected: `ImportError` — `_days_remaining_style` not defined.

- [ ] **Step 3: Add helper and update `rebuys.py`**

Add import at top of `src/net_alpha/cli/rebuys.py`:

```python
from net_alpha.cli.output import print_disclaimer, print_hint
```

Add helper function before `rebuys_command`:

```python
def _days_remaining_style(days: int) -> str:
    """Return Rich style string based on urgency of days remaining."""
    if days <= 7:
        return "bold red"
    if days <= 14:
        return "yellow"
    return ""
```

Update the `table.add_row` call inside `rebuys_command` to color the days column:

```python
        days_val = entry["days_remaining"]
        style = _days_remaining_style(days_val)
        days_str = f"[{style}]{days_val} days[/{style}]" if style else f"{days_val} days"
        table.add_row(
            entry["ticker"],
            entry["qty_display"],
            str(entry["sold_date"]),
            entry["account"],
            str(entry["safe_date"]),
            days_str,
        )
```

Add hint before `print_disclaimer` (only when entries shown):

```python
    print_hint(console, "Run net-alpha simulate sell <ticker> before you trade")
    print_disclaimer(console)
```

- [ ] **Step 4: Run tests**

```bash
uv run pytest tests/cli/test_rebuys.py tests/integration/cli/test_rebuys.py -v
```

Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/cli/rebuys.py tests/cli/test_rebuys.py
git commit -m "feat: add urgency coloring and cross-command hint to rebuys"
```

---

## Task 7: `check` — `--type` validation, `--quiet` flag, hints, `last_check_at`

**Files:**
- Modify: `src/net_alpha/cli/check.py`
- Modify: `tests/cli/test_check.py`
- Modify: `tests/integration/cli/test_check.py`

- [ ] **Step 1: Write failing unit tests**

Add to `tests/cli/test_check.py`:

```python
from net_alpha.cli.check import _validate_type


def test_validate_type_valid_equities():
    assert _validate_type("equities") == "equities"


def test_validate_type_valid_options():
    assert _validate_type("options") == "options"


def test_validate_type_none():
    assert _validate_type(None) is None


def test_validate_type_invalid():
    import pytest
    import typer
    with pytest.raises(typer.Exit):
        _validate_type("option")
```

- [ ] **Step 2: Run to confirm fail**

```bash
uv run pytest tests/cli/test_check.py::test_validate_type_invalid -v
```

Expected: `ImportError`.

- [ ] **Step 3: Add `_validate_type` helper to `check.py`**

Add near the top of `src/net_alpha/cli/check.py`, after imports:

```python
_VALID_TYPES = {"equities", "options"}


def _validate_type(type_str: str | None) -> str | None:
    """Validate --type option. Raises typer.Exit(1) on invalid input."""
    if type_str is None:
        return None
    if type_str.lower() not in _VALID_TYPES:
        console.print(
            f"[red]Error:[/red] --type must be 'equities' or 'options'. Got: '{type_str}'"
        )
        raise typer.Exit(1)
    return type_str.lower()
```

- [ ] **Step 4: Add `--quiet` flag and wire validation into `check_command`**

Update the `check_command` signature:

```python
def check_command(
    ticker: str | None = typer.Option(None, help="Filter by ticker"),
    type: str | None = typer.Option(None, help="Filter by type: equities, options"),
    year: int | None = typer.Option(None, help="Tax year (default: current)"),
    quiet: bool = typer.Option(False, "--quiet", help="Print summary line only (for scripting)"),
) -> None:
```

At the start of `check_command`, after loading settings:

```python
    type = _validate_type(type)
```

After persisting results and computing `violations`, add before printing:

```python
    if quiet:
        total = sum(v.disallowed_loss for v in violations)
        if violations:
            console.print(
                f"  {len(violations)} violation(s)  "
                f"{format_currency(total)} disallowed  [{scan_year}]"
            )
        else:
            console.print(f"  0 violations  [{scan_year}]")
        print_disclaimer(console)
        session.close()
        return
```

- [ ] **Step 5: Write `last_check_at` after detection**

In `check_command`, after `session.commit()` (after saving violations/lots), add:

```python
    from net_alpha.db.repository import MetaRepository
    meta_repo = MetaRepository(session)
    meta_repo.set("last_check_at", date.today().isoformat())
    session.commit()
```

- [ ] **Step 6: Add cross-command hints**

Replace the existing disclaimer call at the end of `check_command` with:

```python
    if violations:
        print_hint(console, "Run net-alpha tax-position to see your YTD gain/loss picture")
        print_hint(console, "Run net-alpha report --csv to export for your tax preparer")

    print_disclaimer(console)
```

Add `print_hint` to the import at the top of `check.py`:

```python
from net_alpha.cli.output import (
    confidence_style,
    format_currency,
    print_disclaimer,
    print_hint,
)
```

- [ ] **Step 7: Run all check tests**

```bash
uv run pytest tests/cli/test_check.py tests/integration/cli/test_check.py -v
```

Expected: all PASS.

- [ ] **Step 8: Write `--quiet` integration test**

Add to `tests/integration/cli/test_check.py`:

```python
def test_check_quiet_no_violations(cli_setup):
    runner, engine, settings = cli_setup
    # seed a buy trade (no loss) so there are trades to scan
    from net_alpha.db.repository import TradeRepository
    from net_alpha.models.domain import Trade
    from datetime import date
    from sqlmodel import Session

    with Session(engine) as s:
        repo = TradeRepository(s)
        repo.save(Trade(account="schwab", date=date(2026, 1, 10), ticker="AAPL",
                        action="Buy", quantity=10, proceeds=None, cost_basis=1500.0))
        s.commit()

    result = runner.invoke(app, ["check", "--quiet"])
    assert result.exit_code == 0
    assert "0 violations" in result.output
    assert "informational only" in result.output
```

- [ ] **Step 9: Run integration test**

```bash
uv run pytest tests/integration/cli/test_check.py -v
```

Expected: all PASS.

- [ ] **Step 10: Commit**

```bash
git add src/net_alpha/cli/check.py tests/cli/test_check.py tests/integration/cli/test_check.py
git commit -m "feat: add --quiet flag, --type validation, hints, and last_check_at to check command"
```

---

## Task 8: `report --quiet`

**Files:**
- Modify: `src/net_alpha/cli/report.py`
- Modify: `tests/integration/cli/test_report.py`

- [ ] **Step 1: Add `--quiet` to `report_command`**

Update signature in `src/net_alpha/cli/report.py`:

```python
def report_command(
    year: int | None = typer.Option(None, help="Tax year (default: current)"),
    csv: bool = typer.Option(False, "--csv", help="Also export CSV to current directory"),
    quiet: bool = typer.Option(False, "--quiet", help="Print summary line only (for scripting)"),
) -> None:
```

After computing `total_disallowed`, add before the detail table print:

```python
    if quiet:
        console.print(
            f"  {len(violations)} violation(s)  "
            f"{format_currency(total_disallowed)} disallowed  [{report_year}]"
        )
        if csv:
            csv_path = Path.cwd() / f"wash_sale_report_{report_year}.csv"
            _write_csv(csv_path, violations, trade_map)
            console.print(f"  CSV exported to: {csv_path}")
        print_disclaimer(console)
        session.close()
        return
```

- [ ] **Step 2: Write integration test**

Add to `tests/integration/cli/test_report.py`:

```python
def test_report_quiet(cli_setup):
    runner, engine, settings = cli_setup
    result = runner.invoke(app, ["report", "--quiet"])
    assert result.exit_code == 0
    assert "violation" in result.output
    assert "informational only" in result.output
    # Should not contain the verbose header
    assert "WASH SALE REPORT" not in result.output
```

- [ ] **Step 3: Run tests**

```bash
uv run pytest tests/integration/cli/test_report.py -v
```

Expected: all PASS.

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/cli/report.py tests/integration/cli/test_report.py
git commit -m "feat: add --quiet flag to report command"
```

---

## Task 9: `simulate sell` ticker validation

**Files:**
- Modify: `src/net_alpha/cli/simulate.py`
- Modify: `tests/cli/test_simulate.py`

- [ ] **Step 1: Write failing unit tests**

Add to `tests/cli/test_simulate.py`:

```python
from net_alpha.cli.simulate import _suggest_ticker


def test_suggest_ticker_typo():
    known = ["AAPL", "TSLA", "GOOG"]
    assert _suggest_ticker("APPL", known) == "AAPL"


def test_suggest_ticker_no_match():
    known = ["AAPL", "TSLA", "GOOG"]
    assert _suggest_ticker("XYZ", known) is None


def test_suggest_ticker_exact():
    known = ["AAPL", "TSLA"]
    assert _suggest_ticker("AAPL", known) is None  # exact match — no suggestion needed
```

- [ ] **Step 2: Run to confirm fail**

```bash
uv run pytest tests/cli/test_simulate.py::test_suggest_ticker_typo -v
```

Expected: `ImportError`.

- [ ] **Step 3: Add `_suggest_ticker` to `simulate.py`**

Add import at top of `src/net_alpha/cli/simulate.py`:

```python
import difflib
```

Add function before `sell_command`:

```python
def _suggest_ticker(ticker: str, known_tickers: list[str]) -> str | None:
    """Return a close-match suggestion for a possibly mistyped ticker, or None."""
    if ticker in known_tickers:
        return None
    matches = difflib.get_close_matches(ticker, known_tickers, n=1, cutoff=0.6)
    return matches[0] if matches else None
```

- [ ] **Step 4: Wire validation into `sell_command`**

In `sell_command`, after loading `all_trades` (inside `_bootstrap_and_load`), add ticker validation before the lookback check. Find the section after `ticker = ticker.upper()` and the simulation header print, then after the header:

```python
    # Validate ticker exists in known lots
    from net_alpha.engine.tax_position import identify_open_lots
    open_lots = identify_open_lots(all_trades, as_of=today)
    known_tickers = list({lot.ticker for lot in open_lots})

    if ticker not in known_tickers:
        suggestion = _suggest_ticker(ticker, known_tickers)
        if suggestion:
            console.print(
                f"  [red]Error:[/red] No open lots for '{ticker}'. "
                f"Did you mean: [bold]{suggestion}[/bold]?"
            )
        else:
            console.print(f"  [red]Error:[/red] No open lots for '{ticker}'.")
        console.print(
            "  [dim]\u2192 Run net-alpha tax-position to see all open positions.[/dim]"
        )
        if session:
            session.close()
        raise typer.Exit(1)
```

- [ ] **Step 5: Run tests**

```bash
uv run pytest tests/cli/test_simulate.py tests/integration/cli/test_simulate.py -v
```

Expected: all PASS.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/cli/simulate.py tests/cli/test_simulate.py
git commit -m "feat: add ticker validation with close-match suggestion to simulate sell"
```

---

## Task 10: Wizard improvements

**Files:**
- Modify: `src/net_alpha/cli/wizard.py`

No automated tests for the questionary interactions (they require a TTY). The `KNOWN_BROKERS` constant is verified by inspection.

- [ ] **Step 1: Add broker autocomplete**

Replace the `questionary.text` broker prompt in `run_wizard` with `questionary.autocomplete`. Add the constant and update the import at the top of `src/net_alpha/cli/wizard.py`:

```python
KNOWN_BROKERS = [
    "schwab", "robinhood", "fidelity", "etrade",
    "td_ameritrade", "interactive_brokers", "webull", "tastytrade",
]
```

Replace:

```python
        broker = questionary.text("Which broker is your next account? (e.g., schwab, robinhood):").ask()
```

With:

```python
        broker = questionary.autocomplete(
            "Which broker is your next account?",
            choices=KNOWN_BROKERS,
            validate=lambda x: len(x) > 0 or "Broker name required",
        ).ask()
```

- [ ] **Step 2: Replace post-wizard "what to do next" panel**

In `run_wizard`, replace:

```python
    console.print()
    console.print("  Run [bold]net-alpha check[/bold] anytime to re-scan.")
    print_disclaimer(console)
```

With:

```python
    console.print()
    console.print("  [green]\u2713 You're set up. Here's what to run next:[/green]")
    console.print()
    console.print("    [bold]net-alpha check[/bold]              Re-scan for wash sales anytime")
    console.print("    [bold]net-alpha simulate sell[/bold]      Check a trade before you make it")
    console.print("    [bold]net-alpha status[/bold]             See your full picture at a glance")
    console.print("    [bold]net-alpha report --csv[/bold]       Export for your tax preparer")
    print_disclaimer(console)
```

- [ ] **Step 3: Run linter**

```bash
uv run ruff check src/net_alpha/cli/wizard.py
uv run ruff format src/net_alpha/cli/wizard.py
```

Expected: no errors.

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/cli/wizard.py
git commit -m "feat: add broker autocomplete and what-to-do-next panel to wizard"
```

---

## Task 11: Import — example values in schema confirmation + post-import nudge

**Files:**
- Modify: `src/net_alpha/cli/import_cmd.py`
- Modify: `src/net_alpha/import_/importer.py` (to thread examples through)

- [ ] **Step 1: Understand the current `confirm_schema` call chain**

Read `src/net_alpha/import_/importer.py` to find where `confirm_schema` is called and what data is available at that point.

```bash
grep -n "confirm_schema\|sample_rows\|examples" src/net_alpha/import_/importer.py
```

The importer already reads CSV sample rows for the LLM call. Identify which variable holds the 3 sample rows and which maps column names to values.

- [ ] **Step 2: Extract example values in importer and pass to confirm_schema**

In `src/net_alpha/import_/importer.py`, find the call site of `confirm_schema(mapping, headers)` and update it to pass example values:

```python
# Build example values: first non-empty cell per mapped field
examples = _extract_examples(mapping, sample_rows)
confirmed = ctx.confirm_schema(mapping, headers, examples)
```

Add helper:

```python
def _extract_examples(mapping, sample_rows: list[dict]) -> dict[str, str]:
    """Extract first non-empty value per mapped column from sample rows."""
    fields = {
        "date": mapping.date,
        "ticker": mapping.ticker,
        "action": mapping.action,
        "quantity": mapping.quantity,
    }
    if mapping.proceeds:
        fields["proceeds"] = mapping.proceeds
    if mapping.cost_basis:
        fields["cost_basis"] = mapping.cost_basis

    examples: dict[str, str] = {}
    for field_name, col_name in fields.items():
        for row in sample_rows:
            val = str(row.get(col_name, "")).strip()
            if val:
                examples[field_name] = val
                break
    return examples
```

- [ ] **Step 3: Update `confirm_schema` signature in `import_cmd.py`**

Update `_confirm_schema` to accept and display examples:

```python
def _confirm_schema(mapping: SchemaMapping, headers: list[str], examples: dict[str, str] | None = None) -> bool:
    """Display detected schema and ask user to confirm."""
    console.print()
    console.print("  Detected schema:")
    console.print("  " + "\u2500" * 40)

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Field", style="cyan")
    table.add_column("Column", style="white")
    table.add_column("Example", style="dim")

    ex = examples or {}

    table.add_row("date", f'"{mapping.date}"', ex.get("date", ""))
    table.add_row("ticker", f'"{mapping.ticker}"', ex.get("ticker", ""))
    buy_vals = ", ".join(mapping.buy_values)
    sell_vals = ", ".join(mapping.sell_values)
    table.add_row(
        "action",
        f'"{mapping.action}"',
        f"[buy: {buy_vals}]  [sell: {sell_vals}]",
    )
    table.add_row("quantity", f'"{mapping.quantity}"', ex.get("quantity", ""))
    if mapping.proceeds:
        table.add_row("proceeds", f'"{mapping.proceeds}"', ex.get("proceeds", ""))
    if mapping.cost_basis:
        table.add_row("cost_basis", f'"{mapping.cost_basis}"', ex.get("cost_basis", ""))
    if mapping.option_format:
        table.add_row("options", f'"{mapping.option_format}"', "")

    console.print(table)
    console.print("  " + "\u2500" * 40)

    import questionary
    return questionary.confirm("Does this look correct?", default=True).ask()
```

- [ ] **Step 4: Add post-import nudge**

In `import_command`, after printing the import result, add before `print_disclaimer`:

```python
    print_hint(console, "Run net-alpha check to scan for wash sales with your latest data")
    print_disclaimer(console)
```

Add `print_hint` to the import at the top of `import_cmd.py`:

```python
from net_alpha.cli.output import print_disclaimer, print_hint
```

- [ ] **Step 5: Run integration tests**

```bash
uv run pytest tests/integration/cli/test_import.py -v
```

Expected: all PASS. If `confirm_schema` signature change breaks the mock, update the mock in the integration test to pass `examples={}`.

- [ ] **Step 6: Run full test suite**

```bash
uv run pytest -v
```

Expected: all PASS.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/cli/import_cmd.py src/net_alpha/import_/importer.py
git commit -m "feat: show example values in schema confirmation and add post-import nudge"
```

---

## Task 12: Consistent error style audit

**Files:**
- Modify: `src/net_alpha/cli/check.py`, `src/net_alpha/cli/report.py`, `src/net_alpha/cli/import_cmd.py`, `src/net_alpha/cli/simulate.py`, `src/net_alpha/cli/tax_position.py`

- [ ] **Step 1: Audit all error messages**

```bash
grep -rn "console.print.*Error\|console.print.*error\|console.print.*red" src/net_alpha/cli/
```

Review each result. The standard format is:

```python
console.print("[red]Error:[/red] <message>")
# optionally followed by:
console.print("  [dim]→ <suggestion>[/dim]")
```

- [ ] **Step 2: Normalize any non-standard error prints**

For each file, update bare red prints to the standard format. Common patterns to fix:

In `import_cmd.py`:
```python
# Before:
console.print(f"[red]Error:[/red] {e}")
# Already correct — keep as-is
```

In `check.py` (the "No trades imported" message is not an error — keep as plain print).

In `tax_position.py` (the "No trades imported" message):
```python
# Before:
console.print("  No trades imported yet. Run [bold]net-alpha import[/bold] first.")
# This is an informational message, not an error — keep as-is
```

- [ ] **Step 3: Run linter on all touched files**

```bash
uv run ruff check src/net_alpha/cli/
uv run ruff format src/net_alpha/cli/
```

Expected: no errors.

- [ ] **Step 4: Run full test suite**

```bash
uv run pytest -v
```

Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/cli/
git commit -m "style: normalize error message formatting across CLI commands"
```

---

## Self-Review

**Spec coverage check:**

| Spec section | Task(s) |
|---|---|
| §2.1 Spinners | Task 4 |
| §2.2 Color-coded tax-position | Task 5 |
| §2.3 Urgency coloring rebuys | Task 6 |
| §3 status command | Task 3 |
| §3.4 No-args fallback replaced | Task 3 step 5 |
| §3.5 last_check_at | Task 2 + Task 7 step 5 |
| §4.1 Broker autocomplete | Task 10 step 1 |
| §4.2 Schema confirmation examples | Task 11 |
| §4.3 "What to do next" panel | Task 10 step 2 |
| §4.4 Post-import nudge | Task 11 step 4 |
| §5.1 --type validation | Task 7 step 3 |
| §5.2 simulate sell ticker validation | Task 9 |
| §5.3 Consistent error style | Task 12 |
| §6.1 --quiet on check | Task 7 step 4 |
| §6.1 --quiet on report | Task 8 |
| §6.2 Cross-command hints (check) | Task 7 step 6 |
| §6.2 Cross-command hints (import) | Task 11 step 4 |
| §6.2 Cross-command hints (rebuys) | Task 6 step 3 |
| §6.2 Cross-command hints (tax-position) | Task 5 step 2 |

All spec requirements covered. ✓
