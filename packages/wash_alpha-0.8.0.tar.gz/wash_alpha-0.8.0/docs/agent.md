<!-- generated-by: gsd-doc-writer -->
## AI Agent Wrapper

### Overview
The `src/net_alpha/agent` module implements the core AI agent wrapper for the `net-alpha` application. It provides a ReAct (Reasoning and Acting) loop to interact with the Anthropic Claude API, enabling a conversational tax-aware trading assistant. The module exposes internal CLI commands (like status, check, simulate sell, and tax position) as callable tools that the AI can use to dynamically analyze portfolio data and wash sale exposure.

### Module Listing
- **`react.py`**: Implements the ReAct turn loop (`run_react_turn`), handling tool use requests from the Claude API, dispatching them to the tool executor, and managing iteration limits.
- **`tools.py`**: Wraps `net_alpha` CLI commands as text-capturing functions. Provides the central `execute_tool` dispatcher and the `TOOL_SCHEMAS` list that defines the available tools for the API.
- **`prompt.py`**: Manages the construction of the system prompt (`build_system_prompt`), combining a static role definition (tax rules, disclaimer requirements) with a dynamic portfolio state snapshot.

### Key Interfaces and APIs

- `run_react_turn(client: Any, model: str, system_prompt: str, messages: list[dict], tool_schemas: list[dict], tool_executor: Callable[[str, dict], str]) -> str`
  Runs a complete turn against the Claude API. It mutates the `messages` list in place to maintain conversation history (including tool inputs and results) and returns the final text response. Capped at a maximum number of iterations (`MAX_ITERATIONS`).

- `execute_tool(name: str, tool_input: dict[str, Any]) -> str`
  Dispatches a tool call by name and returns the captured command output as a string. Supported tools include `run_status`, `run_check`, `run_simulate_sell`, `run_rebuys`, `run_report`, and `run_tax_position`.

- `TOOL_SCHEMAS: list[dict[str, Any]]`
  A list defining the names, descriptions, and JSON schemas of all available tools, ready to be passed directly to the Anthropic API.

- `build_system_prompt(state_snapshot: str) -> str`
  Assembles the system prompt by combining the agent's strict behavioral guidelines (`_STATIC_ROLE`), the current date, and the provided portfolio state snapshot.

- `build_state_snapshot(status_output: str, check_output: str) -> str`
  Formats the raw text output from the status and check commands into a concise block intended for injection into the system prompt.

### Usage Example

The following example demonstrates how to compose the agent components to process a user query:

```python
from anthropic import Anthropic
from net_alpha.agent.react import run_react_turn
from net_alpha.agent.tools import TOOL_SCHEMAS, execute_tool
from net_alpha.agent.prompt import build_system_prompt, build_state_snapshot

# Initialize the Anthropic client
client = Anthropic()

# Build the system prompt with the current portfolio state
# (In practice, status_out and check_out are gathered from the respective tools)
status_out = "Account Status: Up to date"
check_out = "Wash Sale Check: No violations found"
state_snapshot = build_state_snapshot(status_out, check_out)
system_prompt = build_system_prompt(state_snapshot)

# Maintain conversation history across turns
messages = [
    {"role": "user", "content": "What is my wash sale risk if I sell 50 shares of TSLA at $200?"}
]

# Run the ReAct loop; the agent may call `run_simulate_sell` under the hood
response_text = run_react_turn(
    client=client,
    model="claude-3-5-sonnet-latest",
    system_prompt=system_prompt,
    messages=messages,
    tool_schemas=TOOL_SCHEMAS,
    tool_executor=execute_tool
)

print(response_text)
```
