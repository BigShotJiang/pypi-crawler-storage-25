<!-- generated-by: gsd-doc-writer -->
## CONFIGURATION.md

### Environment variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `ANTHROPIC_API_KEY` | **Required** | None | Anthropic API key used by the first-run wizard and for AI-assisted CSV format detection. |
| `DATA_DIR` | Optional | `~/.net_alpha` | Directory for the configuration file, database, and custom ETF pair definitions. |
| `DB_NAME` | Optional | `net_alpha.db` | SQLite database filename within `DATA_DIR`. |
| `ANTHROPIC_MODEL` | Optional | `claude-3-5-haiku-latest` | The LLM model used for CSV parsing and import fallback operations. |
| `LLM_MAX_RETRIES` | Optional | `3` | Maximum number of retry attempts for Anthropic API calls. |
| `AGENT_API_KEY` | Optional | None | API key specifically for the interactive agent. If omitted, falls back to `ANTHROPIC_API_KEY`. |
| `AGENT_MODEL` | Optional | `claude-3-5-haiku-latest` | The LLM model used by the interactive agent. |

### Config file format

`net-alpha` utilizes the following configuration files stored within `DATA_DIR` (defaults to `~/.net_alpha/`):

#### `config.toml` <!-- VERIFY: config.toml -->
Stores basic configuration properties such as the Anthropic API key. It is generated and updated interactively via the first-run wizard.

```toml
anthropic_api_key = "sk-ant-api03-..."
```

#### `etf_pairs.yaml`
A YAML file defining substantially identical ETFs to detect cross-ticker wash sales (e.g., selling SPY and buying VOO within 30 days).

```yaml
sp500:
  - SPY
  - VOO
  - IVV
  - SPLG
nasdaq100:
  - QQQ
  - QQQM
```

### Required vs optional settings

- `ANTHROPIC_API_KEY` is **Required**. Without this configuration, the initial CLI wizard will not proceed past setup, and automated broker CSV schema parsing will fail due to missing API credentials.
- All other settings are optional and have sensible fallbacks.

### Defaults

Optional settings fall back to values defined directly in `src/net_alpha/config.py`:
- `DATA_DIR`: `~/.net_alpha`
- `DB_NAME`: `net_alpha.db`
- `ANTHROPIC_MODEL`: `claude-3-5-haiku-latest`
- `AGENT_MODEL`: `claude-3-5-haiku-latest`
- `LLM_MAX_RETRIES`: `3`

### Per-environment overrides

The application prioritizes settings defined via environment variables. By exporting variables in your shell profile (e.g., `export ANTHROPIC_API_KEY=...`), you can override the defaults and any configurations saved locally in `config.toml`. The project does not use environment-specific `.env` files out of the box.
