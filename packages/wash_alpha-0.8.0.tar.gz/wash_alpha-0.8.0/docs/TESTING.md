<!-- generated-by: gsd-doc-writer -->
# Testing

## Test framework and setup
The primary testing framework used is **Pytest** (version >= 8.0). The project manages dependencies using `uv` and requires Python >= 3.11.

Before running tests, ensure you have installed the project with its development dependencies:

```bash
uv sync --extra dev
```

## Running tests
You can run the full test suite using the provided `Makefile` target or directly via `uv`.

To run the full test suite:
```bash
make test
```

Or using `uv` directly:
```bash
uv run pytest
```

To run tests with coverage reporting:
```bash
uv run pytest --cov=src
```

To run a specific test file or directory subset:
```bash
uv run pytest tests/engine/test_matcher.py
uv run pytest tests/integration/
```

## Writing new tests
New tests should be placed in the `tests/` directory following the `test_*.py` naming convention. 

To assist with writing tests, the project provides several shared helper patterns:
- **Model Factories:** Located in `tests/conftest.py`, these use `factory-boy` (`TradeFactory`, `LotFactory`, `OpenLotFactory`, etc.) to easily generate mock domain entities for unit tests without boilerplate.
- **Database Fixtures:** Located in `tests/integration/conftest.py`, providing `temp_db` and `seeded_session` for SQLite database isolation during integration testing.
- **Path Fixtures:** Also in `tests/integration/conftest.py`, helping reference sample CSV data files (`schwab_csv`, `robinhood_csv`).
- **LLM Mocks:** Helpers like `mock_anthropic_client` and `make_llm_response` are available in `tests/integration/conftest.py` to simulate API responses for import pipeline tests.

## Coverage requirements
| Type | Threshold |
| ---- | --------- |
| Global | No coverage threshold configured. |

While test coverage is collected via `pytest-cov` and reported to Codecov in CI, there are currently no minimum coverage thresholds strictly enforced in the configuration.

## CI integration
Tests are executed automatically in CI through the `CI` workflow (`.github/workflows/ci.yml`).

The workflow runs a job named `test` on pushes to the `master` branch, pull requests, and via a nightly schedule. It executes the following command across Python 3.11 and 3.12:

```bash
uv run pytest --cov=src --cov-report=xml
```

Coverage results from the Python 3.11 matrix run are subsequently uploaded to Codecov using the `codecov-action`.
