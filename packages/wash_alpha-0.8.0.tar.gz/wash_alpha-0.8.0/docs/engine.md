<!-- generated-by: gsd-doc-writer -->
# Engine

## Overview
The `net_alpha` execution engine is the core component responsible for tax and wash sale logic. Located in `src/net_alpha/engine`, it handles the detection of wash sale violations across multiple accounts, manages the allocation of trades to lots using FIFO matching, identifies open tax positions, and provides logic for lot selection and tax optimization. The engine is built around pure, side-effect-free functions that process domain models like `Trade`, `Lot`, and `TaxPosition`.

## Module Listing
- `detector.py` — Orchestrates wash sale detection by sorting loss sales, finding replacement candidates, and allocating disallowed losses to replacement lots.
- `etf_pairs.py` — Loads and merges rules for "substantially identical" ETF pairs from bundled and user-provided YAML configurations.
- `matcher.py` — Core matching logic to evaluate if a candidate trade falls within the 30-day wash sale window and whether it constitutes a wash sale trigger (handling stocks, options, and ETF pairs).
- `tax_position.py` — Manages lot allocation (FIFO, LIFO, HIFO), calculation of realized Short-Term (ST) and Long-Term (LT) gains/losses, identification of open lots, and lot method recommendations.

## Key APIs

- **`detect_wash_sales(trades: list[Trade], etf_pairs: dict[str, list[str]]) -> DetectionResult`**
  Located in `detector.py`. Analyzes a chronological list of trades to detect wash sale violations and adjusts the cost basis of replacement lots.
  
- **`compute_tax_position(trades: list[Trade], year: int) -> TaxPosition`**
  Located in `tax_position.py`. Replays allocations to compute year-to-date realized short-term and long-term capital gains/losses.
  
- **`identify_open_lots(trades: list[Trade], as_of: date) -> list[OpenLot]`**
  Located in `tax_position.py`. Determines remaining unclosed positions (open lots), tracking days held until they become long-term.
  
- **`select_lots(open_lots: list[OpenLot], ticker: str, qty: float, method: str, price: float) -> LotSelection | None`**
  Located in `tax_position.py`. Simulates selling a specific quantity of an asset using a specific accounting method (FIFO, LIFO, HIFO) to project the tax impact.
  
- **`recommend_lot_method(selections: dict[str, LotSelection], tax_position: TaxPosition, safe_sell_date: date | None = None) -> LotRecommendation`**
  Located in `tax_position.py`. Recommends the optimal tax-lot accounting method based on the user's current overall tax position (e.g., prioritizing short-term loss realization if there are short-term gains).

- **`load_etf_pairs(user_pairs_path: Path | None = None) -> dict[str, list[str]]`**
  Located in `etf_pairs.py`. Loads mappings of substantially identical ETFs.

## Usage Examples

### Detecting Wash Sales
```python
from net_alpha.engine.detector import detect_wash_sales
from net_alpha.engine.etf_pairs import load_etf_pairs

# Assuming trades is a list of parsed Trade objects
trades = [...]
etf_pairs = load_etf_pairs()

result = detect_wash_sales(trades, etf_pairs)
for violation in result.violations:
    print(f"Disallowed Loss: {violation.disallowed_loss}")
```

### Computing Tax Position
```python
from net_alpha.engine.tax_position import compute_tax_position

# Calculate YTD realized gains/losses for 2023
tax_pos = compute_tax_position(trades, year=2023)
print(f"Net Short-Term: {tax_pos.st_gains - tax_pos.st_losses}")
print(f"Net Long-Term: {tax_pos.lt_gains - tax_pos.lt_losses}")
```

### Identifying Open Lots
```python
from datetime import date
from net_alpha.engine.tax_position import identify_open_lots

open_lots = identify_open_lots(trades, as_of=date.today())
for lot in open_lots:
    print(f"{lot.ticker}: {lot.quantity} shares, {lot.days_to_long_term} days to LT")
```