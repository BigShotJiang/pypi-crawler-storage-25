<!-- generated-by: gsd-doc-writer -->
## ARCHITECTURE.md

## System overview
`net-alpha` is a local-first, zero-knowledge CLI application that detects wash sales across multiple brokerage accounts, covering equities, options, and ETFs. It follows a modular, layered architecture that takes raw CSV trade histories as inputs, uses AI to infer and map the column schemas locally and securely, persists trades to a local SQLite database, and runs a pure rule engine to generate cross-account wash sale violations and tax positioning outputs.

## Component diagram

```mermaid
graph TD
    CLI[cli] --> Agent[agent]
    CLI --> Import[import_]
    CLI --> Engine[engine]
    CLI --> TUI[tui]
    
    Import --> LLM(Anthropic LLM)
    Import --> DB[db]
    
    Engine --> DB
    Agent --> Engine
    Agent --> DB
    TUI --> Engine
    TUI --> DB
    
    CLI -.-> Models((models))
    Import -.-> Models
    Engine -.-> Models
    DB -.-> Models
```

## Data flow

1. **Importing trades (`net-alpha import`)**:
   - The CLI layer (`src/net_alpha/cli/import_cmd.py`) parses the user arguments for the broker and CSV file.
   - The `import_` module reads the CSV headers and extracts anonymized sample rows (`src/net_alpha/import_/anonymizer.py`).
   - The anonymized data is sent to Anthropic's Claude API (`src/net_alpha/import_/schema_detection.py`) to infer the column mappings.
   - The mapped data is converted into domain `Trade` objects, checked against existing records (`src/net_alpha/import_/dedup.py`), and inserted into the local SQLite database (`src/net_alpha/db/repository.py`).
2. **Wash sale detection (`net-alpha check` or `net-alpha report`)**:
   - The CLI triggers the detection command.
   - The `db` repository layer queries all normalized trades from the SQLite database.
   - `src/net_alpha/engine/detector.py` processes the trades chronologically to identify replacement buys and calculate adjusted cost bases.
   - The output (`DetectionResult` / `WashSaleViolation`) is formatted and rendered in the terminal by `src/net_alpha/cli/output.py`.

## Key abstractions

- `Trade` (`src/net_alpha/models/domain.py`): Pydantic model representing a single buy/sell execution from a broker.
- `Lot` (`src/net_alpha/models/domain.py`): Represents a tracked buy lot with an adjustable cost basis for wash sale adjustments.
- `WashSaleViolation` (`src/net_alpha/models/domain.py`): Links a loss sale to its triggering replacement buy, categorizing confidence (Confirmed, Probable, Unclear).
- `TaxPosition` (`src/net_alpha/models/domain.py`): Computes and stores the YTD realized tax position, split into short-term and long-term gains/losses.
- `TradeRepository` (`src/net_alpha/db/repository.py`): The data access layer abstracting SQLModel row operations and local SQLite queries from the core engine.

## Directory structure rationale

The project is organized by business domain to maintain strict boundaries between presentation, storage, and core tax logic.

- `src/net_alpha/cli/`: Command-line interface definitions and rich terminal presentation logic.
- `src/net_alpha/db/`: Database connectivity, migration scripts, SQLModel table schemas, and the repository access pattern.
- `src/net_alpha/engine/`: Pure business logic containing wash sale matching, ETF pairs, and cost basis allocation algorithms.
- `src/net_alpha/import_/`: Logic for CSV parsing, privacy-preserving data anonymization, deduplication, and LLM-powered schema detection.
- `src/net_alpha/models/`: Shared Pydantic domain models that decouple business logic from the specific database schema or CLI types.
- `src/net_alpha/agent/`: AI agent capabilities for natural language querying of the user's portfolio and tax status.