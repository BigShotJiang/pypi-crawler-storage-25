<!-- generated-by: gsd-doc-writer -->
## Database Repository and Migrations

The `src/net_alpha/db` module provides the database access layer for Net Alpha. It leverages SQLModel (which wraps SQLAlchemy and Pydantic) to define table schemas and handle ORM operations against a local SQLite database. The module is responsible for managing database connections, orchestrating schema migrations, and providing repository classes that translate between underlying database rows and the application's core domain models.

### Module Overview

- **`connection.py`**: Manages the SQLite database engine creation and initial table setup via `init_db`.
- **`migrations.py`**: Implements a lightweight, hand-written migration framework to handle incremental schema updates and document fallback behaviors for newly added columns.
- **`tables.py`**: Defines the `SQLModel` declarative base classes that map directly to database tables (e.g., `TradeRow`, `LotRow`, `WashSaleViolationRow`). Complex attributes like option details are flattened into these tables rather than using relational joins.
- **`repository.py`**: Exposes repository classes (`TradeRepository`, `LotRepository`, `ViolationRepository`, `MetaRepository`, `SchemaCacheRepository`) that abstract away database session operations and automatically map between raw table rows and rich domain models (e.g., `Trade` and `Lot`).

### Key Interfaces

- **Connection & Migrations**
  - `get_engine(db_path: Path)`: Creates and returns a SQLAlchemy engine for the specified SQLite file.
  - `init_db(engine)`: Creates all tables if they don't exist and initializes the `schema_version`.
  - `run_migrations(engine)`: Executes sequential schema migrations to bring the database up to the `CURRENT_SCHEMA_VERSION`.

- **Repositories**
  - `TradeRepository`: Handles CRUD operations for trades. Key methods include `save()`, `save_batch()`, `get_by_id()`, `find_by_hash()`, and `list_by_account()`.
  - `LotRepository`: Manages tax lot data with methods like `save()`, `list_all()`, and `delete_all()`.
  - `ViolationRepository`: Manages wash sale violation records and disallowed loss states.
  - `MetaRepository`: A simple key-value store for application metadata, used primarily for schema version tracking.
  - `SchemaCacheRepository`: Caches detected CSV column mappings per broker to speed up subsequent imports.

### Usage Example

The following example demonstrates how to initialize the database and interact with the repository layer:

```python
from pathlib import Path
from sqlmodel import Session

from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.migrations import run_migrations
from net_alpha.db.repository import TradeRepository
from net_alpha.models.domain import Trade

# 1. Initialize the database connection
db_path = Path("net_alpha.db")
engine = get_engine(db_path)

# 2. Create tables and apply any pending migrations
init_db(engine)
run_migrations(engine)

# 3. Use the repository to query and manage domain objects
with Session(engine) as session:
    trade_repo = TradeRepository(session)
    
    # Retrieve and print all trades for a specific account
    trades = trade_repo.list_by_account("SCHWAB_1234")
    for trade in trades:
        print(f"Trade: {trade.action} {trade.quantity} {trade.ticker} on {trade.date}")
```
