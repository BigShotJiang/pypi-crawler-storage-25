<!-- generated-by: gsd-doc-writer -->
# CLI Commands

This document describes the command-line interface (CLI) logic and commands for **net-alpha**, found in `src/net_alpha/cli/`. The CLI is built using [Typer](https://typer.tiangolo.com/) and provides a rich set of tools to import trades, detect wash sales, simulate trades, and analyze your tax position.

## Overview

The `net-alpha` executable serves as the entry point. If run without any subcommands, it automatically launches a comprehensive interactive wizard. This guided mode allows users to import trades, check status, and run simulations without needing to memorize CLI flags. You can also explicitly invoke it via `net-alpha wizard`.

The commands interact with a local SQLite database (managed via SQLModel) and utilize an LLM engine for dynamic CSV schema detection and the natural language `agent`.

---

## Command Reference

### `net-alpha tui`
Launches the **Interactive Tax Command Center**, a Textual-based terminal dashboard for real-time portfolio analysis and wash sale simulation.

**Usage:**
```bash
net-alpha tui
```

**Logic:**
Populates a `DataTable` with current holdings and provides a reactive form to simulate new trades. As you type a ticker, quantity, or price, the engine identifies potential wash sale violations and calculates disallowed losses live.

### `net-alpha import`
Imports trades from a broker CSV file. It uses an AI-powered schema detector to map CSV columns automatically to the required trade format.

**Usage:**
```bash
net-alpha import <broker> <file>
```
* **`<broker>`**: The name of the broker (e.g., `schwab`, `robinhood`).
* **`<file>`**: The path to the CSV file exported from the broker.

**Logic:**
Requires `ANTHROPIC_API_KEY` to be set. It analyzes the first few rows of the CSV, confirms the detected schema with the user, and then imports the trades (skipping duplicates).

### `net-alpha check`
Scans all imported trades across all accounts to detect wash sale violations and open rebuy windows. Updates the local database with the latest violation mappings.

**Usage:**
```bash
net-alpha check [OPTIONS]
```
**Options:**
* `--ticker <TICKER>`: Filter the scan output to a specific ticker.
* `--type <equities|options>`: Filter by trade type.
* `--year <YYYY>`: Filter results to a specific tax year (defaults to the current year).
* `--quiet`: Print only a single summary line (useful for scripting).

**Logic:**
Leverages the `detect_wash_sales` engine, looking up ETF pairs to identify cross-symbol wash sales (e.g., selling SPY and buying VOO). Displays a detail table with confidence scores (Confirmed, Probable, Unclear).

### `net-alpha simulate sell`
Performs a pre-trade simulation to evaluate the tax impact of selling a position, warning you if it will trigger a wash sale based on your recent (last 30 days) purchase history.

**Usage:**
```bash
net-alpha simulate sell <ticker> <qty> [OPTIONS]
```
**Options:**
* `--price <PRICE>`: The estimated sale price per share. If provided, the command computes dollar impact and recommends the most tax-efficient lot selection strategy (FIFO, HIFO, LIFO).

**Logic:**
Checks for any buys within the last 30 days. If a wash sale would be triggered, it calculates the disallowed loss and specifies the earliest "safe to sell" date. If `--price` is given, it evaluates short-term vs. long-term capital gains/losses.

### `net-alpha tax-position`
Calculates and displays your year-to-date (YTD) tax position and lists all open lots with their holding periods.

**Usage:**
```bash
net-alpha tax-position [OPTIONS]
```
**Options:**
* `--year <YYYY>`: Tax year to calculate for (defaults to the current year).

**Logic:**
Separates short-term and long-term gains and losses. Shows net capital gain and any loss carryforward. Identifies how many days remain until each open lot qualifies for long-term capital gains treatment.

### `net-alpha rebuys`
Tracks open wash sale windows for positions you have recently sold at a loss, telling you when it is safe to rebuy them without triggering a wash sale.

**Usage:**
```bash
net-alpha rebuys
```

**Logic:**
Finds all loss trades from the past 30 days. It factors in partial matches (where only a portion of the loss has been matched to a replacement lot) and displays exactly how many days remain until the 30-day window expires.

### `net-alpha report`
Generates a formal wash sale report for a specific tax year, aggregating disallowed losses and showing replacement lot allocations.

**Usage:**
```bash
net-alpha report [OPTIONS]
```
**Options:**
* `--year <YYYY>`: Tax year for the report (defaults to the current year).
* `--csv`: Exports the report to a CSV file in the current directory (`wash_sale_report_<year>.csv`).
* `--quiet`: Suppress tabular output and print summary only.

### `net-alpha status`
Displays a quick dashboard of your portfolio's data freshness and summary scan results.

**Usage:**
```bash
net-alpha status
```

**Logic:**
Iterates through all accounts to show the last imported trade date and flags accounts with data older than 30 days. It also summarizes the total disallowed losses and lists the count of open rebuy windows.

### `net-alpha agent`
Starts an interactive natural language assistant for querying your portfolio.

**Usage:**
```bash
net-alpha agent
```

**Logic:**
Uses a ReAct (Reasoning and Acting) loop powered by Anthropic's Claude. It creates a portfolio snapshot and has access to internal tools (like running `check` or `status` under the hood) to answer user questions like *"Do I have any wash sale violations this year?"* or *"What's my YTD tax situation?"*. Users can prefix commands with `!` to run raw shell commands during the session.
