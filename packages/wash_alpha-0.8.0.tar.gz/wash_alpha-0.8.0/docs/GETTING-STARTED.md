<!-- generated-by: gsd-doc-writer -->
## GETTING-STARTED.md

## Prerequisites

- `Python >=3.11`
- `uv` (Fast Python package and project manager)

## Installation steps

1. Clone the repository:
   ```bash
   git clone https://github.com/chen-star/net_alpha.git
   ```
2. Navigate into the project directory:
   ```bash
   cd net_alpha
   ```
3. Install dependencies:
   ```bash
   uv sync
   ```

## First run

Launch the interactive wizard:
```bash
uv run net-alpha
```

Alternatively, to scan an imported portfolio for wash sales:
```bash
uv run net-alpha check
```

## Common setup issues

- **Missing API Key:** The application requires an Anthropic API key to parse broker CSV schemas during import and to use the interactive AI agent. If you see an error about `ANTHROPIC_API_KEY` not being set, ensure you have exported it in your shell (e.g., `export ANTHROPIC_API_KEY=sk-...`) or provide it when prompted during the first run setup wizard.
- **Incompatible Python Version:** Ensure you are using `Python >= 3.11`. If you encounter installation errors, verify your active Python version with `python --version` or ensure `uv` is configured to use the correct Python version.

## Next steps

- See [DEVELOPMENT.md](DEVELOPMENT.md) for local setup, build commands, code style, and PR guidelines.
- See [TESTING.md](TESTING.md) for instructions on running the test suite and checking coverage.
