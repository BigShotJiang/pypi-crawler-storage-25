<!-- generated-by: gsd-doc-writer -->
# Development Guide

## Local setup

To set up the project locally for development, you will need [uv](https://docs.astral.sh/uv/) installed.

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd net_alpha
   ```

2. Install the required Python version (Python >=3.11 is required) and development dependencies:
   ```bash
   uv python install 3.11
   uv sync --extra dev
   ```

## Build commands

The project uses a `Makefile` to orchestrate common development tasks.

| Command | Description |
|---------|-------------|
| `make test` | Runs the test suite using `pytest` via `uv` |
| `make lint` | Runs `ruff` to check code formatting and linting rules |
| `make format` | Runs `ruff` to automatically format code and fix autofixable lint issues |
| `make check` | Runs both linting and test commands sequentially |
| `make release` | Executes the release script located in `./scripts/release.sh` |

## Code style

This project uses **Ruff** for fast linting and code formatting.

- **Configuration:** Found in `pyproject.toml` under the `[tool.ruff]` section.
- **Rules:** Enforces line lengths of 120 characters and selects `E`, `F`, `I`, and `UP` rule sets.
- **Enforcement:** Ensure your code complies with the style guidelines before committing by running `make format` or `make lint`.

## Branch conventions

- The default branch is `master`.
- No specific branch naming convention is documented.

## PR process

1. Branch off from `master`.
2. Ensure you have run `make check` locally so that code passes formatting, linting, and tests.
3. Submit a pull request targeting the `master` branch.
4. CI workflows will automatically run on your pull request. They enforce:
   - Ruff linting and formatting checks.
   - Test execution against Python 3.11 and 3.12 matrices.
   - Code coverage reporting via Codecov.
