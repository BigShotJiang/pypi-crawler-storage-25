# 🛡️ FormGuard

**FormGuard** adalah library Python sederhana untuk melakukan validasi input form seperti **email**, **password**, dan **username**.
Library ini dirancang agar **reusable**, mudah digunakan, dan dapat diintegrasikan ke berbagai project seperti backend API, aplikasi web, maupun sistem lainnya.

---

# ✨ Features

* 📧 Validasi Email
* 🔐 Validasi Password (strong password)
* 👤 Validasi Username
* ⚠️ Error Handling dengan custom exception
* ♻️ Reusable untuk berbagai project

---

# 📦 Instalasi

Gunakan mode development:

```bash
pip install -e .
```

---

# 🚀 Cara Penggunaan

```python
from formguard import validate_email, validate_password, validate_username

validate_email("test@gmail.com")
validate_password("Password123")
validate_username("user1")
```

---

# 🧪 Contoh Pengujian

File: `test_validator.py`

```python
from formguard import validate_email, validate_password, validate_username

data = [
    {"email": "test@gmail.com", "password": "Password123", "username": "user1"},
    {"email": "asal", "password": "pass", "username": "us"},
    {"email": "user@yahoo.com", "password": "StrongPass1", "username": "user_123"},
]

for d in data:
    print("\nTesting data:", d)

    try:
        validate_email(d["email"])
        print("Email ✅ valid")
    except Exception as e:
        print("Email ❌", e)

    try:
        validate_password(d["password"])
        print("Password ✅ valid")
    except Exception as e:
        print("Password ❌", e)

    try:
        validate_username(d["username"])
        print("Username ✅ valid")
    except Exception as e:
        print("Username ❌", e)
```

---

# 📊 Contoh Output

```text
Testing data: {'email': 'test@gmail.com', 'password': 'Password123', 'username': 'user1'}
Email ✅ valid
Password ✅ valid
Username ✅ valid

Testing data: {'email': 'asal', 'password': 'pass', 'username': 'us'}
Email ❌ Email tidak valid
Password ❌ Password minimal 8 karakter
Username ❌ Username terlalu pendek

Testing data: {'email': 'user@yahoo.com', 'password': 'StrongPass1', 'username': 'user_123'}
Email ✅ valid
Password ✅ valid
Username ❌ Username hanya boleh huruf dan angka
```

---

# ⚙️ Cara Kerja

## 1. Validasi Email

Menggunakan **Regular Expression (Regex)** untuk memastikan format:

* ada `@`
* ada domain
* ada ekstensi (contoh: `.com`)

---

## 2. Validasi Password

Password harus memenuhi kriteria:

* minimal 8 karakter
* mengandung huruf besar (A-Z)
* mengandung huruf kecil (a-z)
* mengandung angka (0-9)

---

## 3. Validasi Username

* minimal 3 karakter
* hanya huruf dan angka (tanpa simbol)

---

## 4. Error Handling

Jika input tidak valid, akan muncul error:

```python
ValidationError: Email tidak valid
```

---

# 🎯 Tujuan Library

FormGuard dibuat untuk:

* ✅ Memvalidasi input user sebelum diproses
* ✅ Mengurangi kesalahan input (invalid data)
* ✅ Membantu developer dengan fungsi siap pakai
* ✅ Digunakan ulang di berbagai project

---

# 🌍 Use Case (Penggunaan Nyata)

* 🔐 Sistem Login & Register
* 🌐 Backend API (Flask, FastAPI, Django)
* 📱 Aplikasi Mobile (via backend)
* 🧾 Form input data pengguna

---

# 📁 Struktur Project

```text
formguard_project/
│
├── formguard/
│   ├── __init__.py
│   ├── validators.py
│   ├── sanitizers.py
│   ├── utils.py
│   ├── exceptions.py
│
├── pyproject.toml
├── setup.py
├── README.md
```

---

# 🧠 Kelebihan

* ✔ Modular (dipisah per fungsi)
* ✔ Mudah dikembangkan
* ✔ Clean code
* ✔ Sesuai standar Python packaging

---

# 🏁 Kesimpulan

FormGuard adalah solusi sederhana namun efektif untuk memastikan bahwa data input user sudah valid sebelum diproses lebih lanjut. Dengan pendekatan modular dan reusable, library ini dapat digunakan di berbagai jenis aplikasi.

---

# 👨‍💻 Author

**Naufal**

---
