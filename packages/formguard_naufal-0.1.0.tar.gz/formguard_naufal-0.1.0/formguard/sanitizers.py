def clean_input(text: str) -> str:
    """
    Membersihkan input dari spasi berlebih
    """
    return text.strip()