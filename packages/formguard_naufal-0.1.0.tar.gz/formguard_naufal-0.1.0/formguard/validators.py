import re
from .exceptions import ValidationError

def validate_email(email: str) -> bool:
    """
    Validasi format email
    """
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    
    if not re.match(pattern, email):
        raise ValidationError("Email tidak valid")
    
    return True


def validate_password(password: str) -> bool:
    """
    Password minimal 8 karakter,
    harus ada huruf besar, kecil, dan angka
    """
    if len(password) < 8:
        raise ValidationError("Password minimal 8 karakter")
    
    if not re.search(r'[A-Z]', password):
        raise ValidationError("Password harus mengandung huruf besar")
    
    if not re.search(r'[a-z]', password):
        raise ValidationError("Password harus mengandung huruf kecil")
    
    if not re.search(r'[0-9]', password):
        raise ValidationError("Password harus mengandung angka")
    
    return True


def validate_username(username: str) -> bool:
    """
    Username hanya huruf dan angka, minimal 3 karakter
    """
    if len(username) < 3:
        raise ValidationError("Username terlalu pendek")
    
    if not username.isalnum():
        raise ValidationError("Username hanya boleh huruf dan angka")
    
    return True


def validate_phone(phone: str) -> bool:
    import re
    pattern = r'^08\d{8,11}$'
    
    if not re.match(pattern, phone):
        raise ValidationError("Nomor HP tidak valid")
    
    return True


def validate_all(email, password, username):
    validate_email(email)
    validate_password(password)
    validate_username(username)
    return True