class ValidationError(Exception):
    """Custom exception untuk error validasi"""
    pass