import re

def regex_match(pattern, text):
    return re.match(pattern, text)