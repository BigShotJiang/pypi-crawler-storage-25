from setuptools import setup, find_packages

setup(
    name="formguard-naufal",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[],
    author="Nama Kamu",
    description="Library untuk validasi form Python",
)