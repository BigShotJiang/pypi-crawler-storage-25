"""
BO Agent Robustness Test — demonstrates that the SciLink BO agent provides
consistent performance across diverse problem structures, while classical BO
excels on some but fails on others.

Thesis: The agent's value is robustness to unknown problem structure,
not faster optimization on any single problem.

Runs a diverse suite of 8 benchmarks (2 standard + 6 scientific), normalizes
regret relative to random search baseline, and compares the distribution
of normalized performance across all problems.

Outputs (in tests/bo_robustness_results/):
  - Per-benchmark convergence + cumulative regret plots
  - Normalized performance radar chart
  - Robustness summary (worst-case, mean, std across benchmarks)
  - robustness_results.json with all data

Run:
    ANTHROPIC_API_KEY=<key> SCILINK_TEST_MODEL=claude-opus-4-6 \
        python tests/test_bo_robustness.py

Skip agent (classical + random only):
    python tests/test_bo_robustness.py --no-agent

Override seeds (default 3):
    python tests/test_bo_robustness.py --seeds 5
"""

import json
import os
import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt

os.environ.setdefault("UNSAFE_EXECUTION_OK", "true")

# Import everything from the main comparison module
from test_bo_comparison import (
    # Functions
    branin, ackley_2d,
    catalytic_yield, catalytic_yield_true,
    thin_film_roughness,
    crystallization_purity,
    ree_leaching, ree_leaching_true,
    battery_capacity, battery_capacity_true,
    alloy_hardness, alloy_hardness_true,
    generate_conservative_ree_data,
    # Optimum values
    _cat_opt, _cryst_opt, _film_opt, _ree_opt, _batt_opt, _alloy_opt,
    # Runners
    run_multi_seed, run_random_search, run_classical_bo, run_scilink_agent,
    compute_metrics, plot_comparison, print_table, print_strategy_log,
    # Config
    SEEDS, N_SEEDS, COLORS, LINESTYLES,
    _MODEL, _API_KEY, _SKIP_AGENT,
    _refine_min, _find_min_2d,
)

# ---------------------------------------------------------------------------
# Output directory
# ---------------------------------------------------------------------------

_OUTPUT_DIR = Path(__file__).parent / "bo_robustness_results"

# ---------------------------------------------------------------------------
# Benchmark suite — diverse mix of problem structures
# ---------------------------------------------------------------------------

# Ackley & Branin optimum via scipy
_ackley_opt = _refine_min(ackley_2d, [(-5, 5), (-5, 5)],
                          ackley_2d(0, 0))
_branin_opt = _refine_min(branin, [(-5, 10), (0, 15)],
                          _find_min_2d(branin, [-5, 10], [0, 15], res=200))

ROBUSTNESS_SUITE = {
    # --- Standard benchmarks (controls) ---
    "branin_2d": {
        "func": branin,
        "bounds": [[-5.0, 10.0], [0.0, 15.0]],
        "col_names": ["x1", "x2"],
        "global_min": _branin_opt,
        "n_init": 8,
        "n_iters": 15,
        "challenge": "Smooth, multi-modal (control)",
    },
    "ackley_2d": {
        "func": ackley_2d,
        "bounds": [[-5.0, 5.0], [-5.0, 5.0]],
        "col_names": ["x1", "x2"],
        "global_min": _ackley_opt,
        "n_init": 10,
        "n_iters": 15,
        "challenge": "Many local minima",
    },
    # --- Scientific benchmarks (diverse challenges) ---
    "catalytic_yield": {
        "func": catalytic_yield,
        "true_func": catalytic_yield_true,
        "bounds": [[300.0, 600.0], [1.0, 10.0]],
        "col_names": ["temperature_K", "pressure_atm"],
        "global_min": _cat_opt,
        "n_init": 8,
        "n_iters": 15,
        "challenge": "Heteroscedastic noise",
    },
    "thin_film_roughness": {
        "func": thin_film_roughness,
        "bounds": [[50.0, 300.0], [5.0, 50.0], [20.0, 400.0]],
        "col_names": ["power_W", "gas_flow_sccm", "substrate_temp_C"],
        "global_min": _film_opt,
        "n_init": 12,
        "n_iters": 20,
        "challenge": "Regime transition (discontinuity)",
    },
    "crystallization_purity": {
        "func": crystallization_purity,
        "bounds": [[0.1, 2.0], [0.1, 5.0]],
        "col_names": ["solvent_ratio", "cooling_rate_C_per_min"],
        "global_min": _cryst_opt,
        "n_init": 8,
        "n_iters": 20,
        "challenge": "Flat plateau + narrow basin",
    },
    "ree_leaching": {
        "func": ree_leaching,
        "true_func": ree_leaching_true,
        "bounds": [[0.5, 8.0], [0.5, 12.0], [25.0, 90.0]],
        "col_names": ["HCl_M", "time_h", "temp_C"],
        "global_min": _ree_opt,
        "n_init": 10,
        "n_iters": 20,
        "init_func": generate_conservative_ree_data,
        "challenge": "Biased start + noise",
    },
    "battery_capacity": {
        "func": battery_capacity,
        "true_func": battery_capacity_true,
        "bounds": [[2.5, 4.5], [0.5, 2.0]],
        "col_names": ["voltage_V", "electrolyte_M"],
        "global_min": _batt_opt,
        "n_init": 10,
        "n_iters": 15,
        "challenge": "Outlier contamination",
    },
    "alloy_hardness": {
        "func": alloy_hardness,
        "true_func": alloy_hardness_true,
        "bounds": [[0.0, 1.0]] * 6,
        "col_names": ["Cr", "Ni", "Mo", "Si", "Mn", "C"],
        "global_min": _alloy_opt,
        "n_init": 15,
        "n_iters": 25,
        "challenge": "6D with irrelevant dims",
    },
}


# ---------------------------------------------------------------------------
# Normalized metrics
# ---------------------------------------------------------------------------

def compute_normalized_metrics(all_metrics):
    """Normalize regret relative to random search baseline.

    For each benchmark, normalized_regret = approach_regret / random_regret.
    A value of 0 = found optimum, 1 = no better than random.
    """
    benchmarks = list(all_metrics.keys())
    approaches = [a for a in ["Classical BO", "SciLink Agent"]
                  if a in all_metrics[benchmarks[0]]]

    normalized = {a: [] for a in approaches}

    for bm in benchmarks:
        random_regret = all_metrics[bm]["Random"]["mean_final_regret"]
        if random_regret < 1e-8:
            random_regret = 1e-8  # avoid division by zero

        for a in approaches:
            regret = max(all_metrics[bm][a]["mean_final_regret"], 0)
            normalized[a].append(regret / random_regret)

    return normalized, benchmarks


def compute_normalized_cumregret(all_metrics):
    """Same normalization for cumulative regret."""
    benchmarks = list(all_metrics.keys())
    approaches = [a for a in ["Classical BO", "SciLink Agent"]
                  if a in all_metrics[benchmarks[0]]]

    normalized = {a: [] for a in approaches}

    for bm in benchmarks:
        random_cr = all_metrics[bm]["Random"]["mean_cum_regret"]
        if random_cr < 1e-8:
            random_cr = 1e-8

        for a in approaches:
            cr = max(all_metrics[bm][a]["mean_cum_regret"], 0)
            normalized[a].append(cr / random_cr)

    return normalized, benchmarks


# ---------------------------------------------------------------------------
# Robustness plots
# ---------------------------------------------------------------------------

def plot_robustness_bars(all_metrics, suite, save_dir):
    """Normalized regret bar chart — shows consistency across benchmarks."""
    norm_final, benchmarks = compute_normalized_metrics(all_metrics)
    norm_cum, _ = compute_normalized_cumregret(all_metrics)
    approaches = list(norm_final.keys())

    labels = [suite[bm]["challenge"] for bm in benchmarks]

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))

    x = np.arange(len(benchmarks))
    width = 0.35

    for panel, (norm_data, title, ylabel) in enumerate([
        (norm_final, "Final Regret (normalized to Random = 1.0)",
         "Regret / Random Regret"),
        (norm_cum, "Cumulative Regret (normalized to Random = 1.0)",
         "Cum. Regret / Random Cum. Regret"),
    ]):
        ax = axes[panel]
        for i, approach in enumerate(approaches):
            vals = norm_data[approach]
            offset = (i - 0.5) * width
            bars = ax.bar(x + offset, vals, width * 0.9,
                          color=COLORS[approach], alpha=0.85, label=approach)

        ax.axhline(1.0, color="#999999", linestyle="--", linewidth=1,
                   label="Random baseline", alpha=0.7)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=35, ha="right", fontsize=8)
        ax.set_ylabel(ylabel, fontsize=10)
        ax.set_title(title, fontsize=11)
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.2, axis="y")
        ax.set_axisbelow(True)
        ax.set_ylim(0, min(max(max(v) for v in norm_data.values()) * 1.15, 1.2))

    fig.suptitle("BO Robustness: Normalized Performance Across Diverse Problems",
                 fontsize=13, fontweight="bold")
    fig.tight_layout()
    save_path = save_dir / "normalized_comparison.png"
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return str(save_path)


def plot_robustness_summary(all_metrics, suite, save_dir):
    """Box plot showing the distribution of normalized regret across benchmarks.
    Tighter box = more robust."""
    norm_final, benchmarks = compute_normalized_metrics(all_metrics)
    approaches = list(norm_final.keys())

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    # Left: box plot of normalized final regret
    ax = axes[0]
    data = [norm_final[a] for a in approaches]
    bp = ax.boxplot(data, labels=approaches, patch_artist=True, widths=0.5,
                    showmeans=True, meanprops={"marker": "D", "markerfacecolor": "black",
                                               "markersize": 6})
    for patch, approach in zip(bp["boxes"], approaches):
        patch.set_facecolor(COLORS[approach])
        patch.set_alpha(0.7)

    # Overlay individual points
    for i, approach in enumerate(approaches):
        vals = norm_final[approach]
        jitter = np.random.RandomState(0).uniform(-0.08, 0.08, len(vals))
        ax.scatter(np.full(len(vals), i + 1) + jitter, vals,
                   color=COLORS[approach], s=40, zorder=5,
                   edgecolors="black", linewidth=0.5, alpha=0.8)

    ax.axhline(1.0, color="#999999", linestyle="--", linewidth=1, alpha=0.5)
    ax.set_ylabel("Normalized Final Regret\n(fraction of Random)", fontsize=10)
    ax.set_title("Distribution Across Benchmarks", fontsize=11)
    ax.grid(True, alpha=0.2, axis="y")

    # Right: summary statistics table
    ax = axes[1]
    ax.axis("off")

    stats_data = []
    for approach in approaches:
        vals = norm_final[approach]
        stats_data.append([
            approach,
            f"{np.mean(vals):.3f}",
            f"{np.std(vals):.3f}",
            f"{np.max(vals):.3f}",
            f"{np.min(vals):.3f}",
            f"{np.max(vals) - np.min(vals):.3f}",
        ])

    table = ax.table(
        cellText=stats_data,
        colLabels=["Approach", "Mean", "Std", "Worst", "Best", "Range"],
        cellLoc="center",
        loc="center",
    )
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1.0, 1.8)

    # Color the approach column
    for i, approach in enumerate(approaches):
        table[i + 1, 0].set_facecolor(COLORS[approach])
        table[i + 1, 0].set_text_props(color="white", fontweight="bold")

    ax.set_title("Robustness Statistics\n(lower = better, tighter = more robust)",
                 fontsize=11)

    fig.suptitle("BO Robustness: Who Fails Less?",
                 fontsize=13, fontweight="bold")
    fig.tight_layout()
    save_path = save_dir / "robustness_summary.png"
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return str(save_path)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    _OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    run_agent = not _SKIP_AGENT and bool(_API_KEY)
    if _SKIP_AGENT:
        print("Skipping SciLink Agent (--no-agent flag).\n")
    elif not _API_KEY:
        print("No API key found — skipping SciLink Agent tests.")
        print("Set ANTHROPIC_API_KEY or SCILINK_TEST_API_KEY to include agent.\n")

    print(f"Seeds: {SEEDS}  (--seeds N to change)")
    print(f"Benchmarks: {len(ROBUSTNESS_SUITE)}\n")

    all_metrics = {}
    all_agg = {}
    all_json = {}

    for bm_name, bm in ROBUSTNESS_SUITE.items():
        print(f"\n{'#' * 80}")
        print(f"# {bm_name}  —  {bm['challenge']}")
        print(f"# {bm['n_iters']} iters x {len(SEEDS)} seeds")
        print(f"{'#' * 80}")

        func = bm["func"]
        true_func = bm.get("true_func")
        init_func = bm.get("init_func")
        bounds = bm["bounds"]
        col_names = bm["col_names"]
        global_min = bm["global_min"]
        n_init = bm["n_init"]
        n_iters = bm["n_iters"]

        agg_results = {}
        metrics = {}

        print(f"\n  Running Random Search ...")
        agg = run_multi_seed(run_random_search, func, bounds, col_names,
                             n_init, n_iters, SEEDS,
                             true_func=true_func, init_func=init_func)
        agg_results["Random"] = agg
        metrics["Random"] = compute_metrics(agg, global_min)

        print(f"  Running Classical BO ...")
        agg = run_multi_seed(run_classical_bo, func, bounds, col_names,
                             n_init, n_iters, SEEDS,
                             true_func=true_func, init_func=init_func)
        agg_results["Classical BO"] = agg
        metrics["Classical BO"] = compute_metrics(agg, global_min)

        if run_agent:
            print(f"  Running SciLink Agent ...")
            agg = run_multi_seed(run_scilink_agent, func, bounds, col_names,
                                 n_init, n_iters, SEEDS,
                                 true_func=true_func, init_func=init_func)
            agg_results["SciLink Agent"] = agg
            metrics["SciLink Agent"] = compute_metrics(agg, global_min)

        print_table(bm_name, global_min, metrics, len(SEEDS))
        if run_agent and "SciLink Agent" in agg_results:
            print_strategy_log(agg_results["SciLink Agent"]["all_strategies"])

        # Per-benchmark plot
        plot_path = plot_comparison(bm_name, global_min, agg_results, _OUTPUT_DIR)
        print(f"\n  Plot saved: {plot_path}")

        all_metrics[bm_name] = metrics
        all_agg[bm_name] = agg_results

        all_json[bm_name] = {}
        for approach, agg in agg_results.items():
            all_json[bm_name][approach] = {
                "histories": agg["histories"].tolist(),
                "mean_history": agg["mean_history"].tolist(),
                "std_history": agg["std_history"].tolist(),
                "n_seeds": agg["n_seeds"],
            }

    # --- Robustness analysis ---
    print(f"\n\n{'#' * 80}")
    print("# ROBUSTNESS ANALYSIS")
    print(f"{'#' * 80}")

    if run_agent:
        norm_path = plot_robustness_bars(all_metrics, ROBUSTNESS_SUITE, _OUTPUT_DIR)
        print(f"\n  Normalized comparison: {norm_path}")

        summary_path = plot_robustness_summary(all_metrics, ROBUSTNESS_SUITE, _OUTPUT_DIR)
        print(f"  Robustness summary:   {summary_path}")

        # Print normalized metrics
        norm_final, benchmarks = compute_normalized_metrics(all_metrics)
        print(f"\n  Normalized Final Regret (fraction of Random baseline):")
        print(f"  {'Benchmark':<30} {'Classical BO':>14} {'SciLink Agent':>14}")
        print(f"  {'-' * 58}")
        for i, bm in enumerate(benchmarks):
            challenge = ROBUSTNESS_SUITE[bm]["challenge"]
            c_val = norm_final["Classical BO"][i]
            a_val = norm_final["SciLink Agent"][i]
            winner = "<" if c_val < a_val else ">"
            print(f"  {challenge:<30} {c_val:>13.3f} {winner} {a_val:>12.3f}")

        print(f"\n  {'STATISTIC':<30} {'Classical BO':>14} {'SciLink Agent':>14}")
        print(f"  {'-' * 58}")
        for label, fn in [("Mean", np.mean), ("Std", np.std),
                          ("Worst case", np.max), ("Best case", np.min)]:
            c_val = fn(norm_final["Classical BO"])
            a_val = fn(norm_final["SciLink Agent"])
            print(f"  {label:<30} {c_val:>14.3f} {a_val:>14.3f}")
    else:
        print("\n  Skipped (no agent results).")

    # Save JSON with benchmark metadata for future replotting
    save_data = {
        "metadata": {
            "seeds": SEEDS,
            "n_seeds": len(SEEDS),
            "model": _MODEL if run_agent else None,
            "benchmarks": {
                bm_name: {
                    "global_min": float(bm["global_min"]),
                    "challenge": bm["challenge"],
                    "n_init": bm["n_init"],
                    "n_iters": bm["n_iters"],
                    "n_dims": len(bm["bounds"]),
                    "col_names": bm["col_names"],
                }
                for bm_name, bm in ROBUSTNESS_SUITE.items()
            },
        },
        "results": all_json,
        "metrics": {
            bm_name: {
                approach: {
                    k: float(v) if isinstance(v, (float, np.floating)) else v
                    for k, v in m.items()
                }
                for approach, m in metrics.items()
            }
            for bm_name, metrics in all_metrics.items()
        },
    }
    json_path = _OUTPUT_DIR / "robustness_results.json"
    with open(json_path, "w") as f:
        json.dump(save_data, f, indent=2)
    print(f"\n  Raw results saved: {json_path}")

    # --- Per-benchmark summary tables ---
    print(f"\n\n{'#' * 80}")
    print("# PER-BENCHMARK RESULTS")
    print(f"{'#' * 80}")
    for bm_name, metrics in all_metrics.items():
        print_table(bm_name, ROBUSTNESS_SUITE[bm_name]["global_min"],
                    metrics, len(SEEDS))

    print()


if __name__ == "__main__":
    main()
