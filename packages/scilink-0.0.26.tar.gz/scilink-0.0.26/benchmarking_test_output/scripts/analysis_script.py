import numpy as np
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.spatial import Delaunay
from scipy.ndimage import gaussian_filter, uniform_filter
from scipy.special import erf
from sklearn.mixture import GaussianMixture
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# Step 1: Load data
# ============================================================
image_path = '/Users/maxim.ziatdinov/Code/SciLink/benchmarking_test_output/image_0000/temp_image_0.npy'
image = np.load(image_path).astype(np.float32)
print(f"Image shape: {image.shape}, dtype: {image.dtype}")
print(f"Intensity range: [{image.min():.1f}, {image.max():.1f}]")

# Try to load Tier 1 outputs
import os
base_dir = os.path.dirname(image_path)

def try_load(fname):
    p = os.path.join(base_dir, fname)
    if os.path.exists(p):
        return np.load(p)
    # Also check current directory
    if os.path.exists(fname):
        return np.load(fname)
    return None

atom_positions_nm = try_load('atom_positions_nm.npy')
atom_amplitudes = try_load('atom_amplitudes.npy')
nn_distances_nm = try_load('nn_distances_nm.npy')

# If Tier 1 outputs not available, detect atoms
if atom_positions_nm is None:
    print("Tier 1 outputs not found. Running atom detection...")
    from scilink.tools.atom_finding_tools import detect_atoms, refine_positions
    
    # Normalize image for detection
    img_norm = (image - image.min()) / (image.max() - image.min())
    
    # Estimate separation from FFT
    fft2d = np.fft.fftshift(np.fft.fft2(img_norm))
    power = np.abs(fft2d)**2
    cy, cx = image.shape[0]//2, image.shape[1]//2
    # Mask center
    yy, xx = np.mgrid[:image.shape[0], :image.shape[1]]
    dist_from_center = np.sqrt((xx - cx)**2 + (yy - cy)**2)
    power_masked = power.copy()
    power_masked[dist_from_center < 10] = 0
    # Find brightest peak
    peak_idx = np.unravel_index(np.argmax(power_masked), power_masked.shape)
    peak_dist = np.sqrt((peak_idx[1] - cx)**2 + (peak_idx[0] - cy)**2)
    est_spacing_px = image.shape[0] / peak_dist if peak_dist > 0 else 20
    separation = max(5, int(est_spacing_px * 0.7))
    print(f"Estimated atom spacing: {est_spacing_px:.1f} px, using separation={separation}")
    
    result = detect_atoms(image, separation=separation, threshold_rel=0.02, refine=True,
                          normalize_intensity=True, subtract_background=True)
    positions_px = result['positions']  # (N, 2) as (x, y) where x=col, y=row
    atom_amps = result['amplitude']
    
    # Estimate pixel size from known LSAT lattice parameter
    # LSAT a = 0.3868 nm. Need to figure out pixel size.
    # Use median NN distance approach
    from scipy.spatial import cKDTree
    tree = cKDTree(positions_px)
    dists, _ = tree.query(positions_px, k=2)
    median_nn_px = np.median(dists[:, 1])
    
    # In perovskite <100> projection, nearest neighbors are along <110> at a/sqrt(2)
    # So median_nn_px corresponds to a/sqrt(2) = 0.3868/sqrt(2) = 0.2735 nm
    pixel_size_nm = 0.2735 / median_nn_px
    print(f"Median NN distance: {median_nn_px:.2f} px")
    print(f"Estimated pixel size: {pixel_size_nm:.5f} nm/px")
    
    atom_positions_nm = positions_px * pixel_size_nm
    atom_amplitudes = atom_amps
    nn_distances_nm = dists[:, 1] * pixel_size_nm
else:
    print(f"Loaded Tier 1 outputs: positions shape={atom_positions_nm.shape}")
    # Compute pixel size from positions
    from scipy.spatial import cKDTree
    # Need positions in pixels too
    median_nn_nm = np.median(nn_distances_nm) if nn_distances_nm is not None else 0.274
    # Estimate pixel size
    # Better approach: use image extent
    # positions are in nm, image is in pixels
    # pixel_size = max_position_extent / image_size
    pos_range_x = atom_positions_nm[:, 0].max() - atom_positions_nm[:, 0].min()
    pos_range_y = atom_positions_nm[:, 1].max() - atom_positions_nm[:, 1].min()
    pixel_size_nm = max(pos_range_x / image.shape[1], pos_range_y / image.shape[0])
    if pixel_size_nm < 1e-6:
        pixel_size_nm = 0.02  # fallback
    positions_px = atom_positions_nm / pixel_size_nm
    atom_amps = atom_amplitudes

print(f"Pixel size: {pixel_size_nm:.5f} nm/px")
print(f"Number of atom columns: {len(atom_positions_nm)}")
print(f"Field of view: {image.shape[1]*pixel_size_nm:.2f} x {image.shape[0]*pixel_size_nm:.2f} nm")

# Ensure positions_px is defined
if 'positions_px' not in dir():
    positions_px = atom_positions_nm / pixel_size_nm
if 'atom_amps' not in dir():
    atom_amps = atom_amplitudes

# ============================================================
# Step 2: Interface detection - intensity profiles
# ============================================================
# Compute row-averaged and column-averaged intensity profiles
profile_y = np.mean(image, axis=1)  # average along x for each row (y profile)
profile_x = np.mean(image, axis=0)  # average along y for each col (x profile)

# Smooth profiles
profile_y_smooth = gaussian_filter(profile_y, sigma=20)
profile_x_smooth = gaussian_filter(profile_x, sigma=20)

# Compute gradient magnitude to find which direction has strongest step
grad_y = np.max(np.abs(np.gradient(profile_y_smooth)))
grad_x = np.max(np.abs(np.gradient(profile_x_smooth)))

print(f"Max gradient along Y: {grad_y:.2f}")
print(f"Max gradient along X: {grad_x:.2f}")

# Choose growth direction as the one with stronger gradient
if grad_y >= grad_x:
    growth_axis = 'y'  # interface is horizontal (rows)
    profile = profile_y_smooth
    profile_raw = profile_y
    axis_coords = np.arange(len(profile)) * pixel_size_nm
    atom_coord = atom_positions_nm[:, 1]  # y-coords in nm
    atom_coord_px = positions_px[:, 1]
else:
    growth_axis = 'x'  # interface is vertical (columns)
    profile = profile_x_smooth
    profile_raw = profile_x
    axis_coords = np.arange(len(profile)) * pixel_size_nm
    atom_coord = atom_positions_nm[:, 0]  # x-coords in nm
    atom_coord_px = positions_px[:, 0]

print(f"Growth direction: along {growth_axis}-axis")

# ============================================================
# Step 3: Fit erf/sigmoid to find interface
# ============================================================
def sigmoid_func(x, A, B, x0, w):
    """Sigmoid/erf step function: A + B * erf((x - x0) / w)"""
    return A + B * erf((x - x0) / (w * np.sqrt(2)))

try:
    x_data = np.arange(len(profile), dtype=float)
    p0 = [(profile.max() + profile.min())/2, 
          (profile.max() - profile.min())/2,
          len(profile)/2, 
          len(profile)/10]
    
    popt, pcov = curve_fit(sigmoid_func, x_data, profile, p0=p0, maxfev=10000)
    interface_px = popt[2]
    interface_width_px = abs(popt[3])
    interface_nm = interface_px * pixel_size_nm
    interface_width_nm = interface_width_px * pixel_size_nm
    
    perr = np.sqrt(np.diag(pcov))
    interface_uncertainty_nm = perr[2] * pixel_size_nm
    
    print(f"Interface position: {interface_nm:.2f} \u00b1 {interface_uncertainty_nm:.3f} nm (pixel {interface_px:.1f})")
    print(f"Interface width: {interface_width_nm:.2f} nm")
    
    fit_success = True
except Exception as e:
    print(f"Sigmoid fit failed: {e}")
    # Fallback: use maximum gradient position
    grad_profile = np.abs(np.gradient(profile))
    interface_px = float(np.argmax(grad_profile))
    interface_nm = interface_px * pixel_size_nm
    interface_width_nm = 1.0
    interface_uncertainty_nm = pixel_size_nm * 5
    fit_success = False
    print(f"Fallback interface position: {interface_nm:.2f} nm")

# Validate interface position
total_extent = len(profile)
interface_frac = interface_px / total_extent
print(f"Interface at {interface_frac*100:.1f}% of image extent")

if interface_frac < 0.15 or interface_frac > 0.85:
    print("WARNING: Interface near edge. Trying orthogonal direction...")
    # Try the other axis
    if growth_axis == 'y':
        alt_profile = profile_x_smooth
        alt_axis = 'x'
    else:
        alt_profile = profile_y_smooth
        alt_axis = 'y'
    
    try:
        x_alt = np.arange(len(alt_profile), dtype=float)
        p0_alt = [(alt_profile.max() + alt_profile.min())/2,
                  (alt_profile.max() - alt_profile.min())/2,
                  len(alt_profile)/2,
                  len(alt_profile)/10]
        popt_alt, _ = curve_fit(sigmoid_func, x_alt, alt_profile, p0=p0_alt, maxfev=10000)
        alt_frac = popt_alt[2] / len(alt_profile)
        if 0.15 < alt_frac < 0.85:
            growth_axis = alt_axis
            interface_px = popt_alt[2]
            interface_nm = interface_px * pixel_size_nm
            profile = alt_profile
            if alt_axis == 'x':
                atom_coord = atom_positions_nm[:, 0]
                atom_coord_px = positions_px[:, 0]
            else:
                atom_coord = atom_positions_nm[:, 1]
                atom_coord_px = positions_px[:, 1]
            print(f"Switched to {alt_axis}-axis. Interface at {interface_nm:.2f} nm")
    except:
        pass

# ============================================================
# Step 4: Partition atoms into film and substrate
# ============================================================
# Determine which side is film vs substrate based on intensity
# LLTO film and LSAT substrate - need to identify which region is which
mask_below = atom_coord_px < interface_px
mask_above = atom_coord_px >= interface_px

n_below = np.sum(mask_below)
n_above = np.sum(mask_above)
print(f"Atoms below interface: {n_below}, above: {n_above}")

if n_below < 20 or n_above < 20:
    print("WARNING: Very few atoms in one partition. Using 50/50 split.")
    median_coord = np.median(atom_coord_px)
    mask_below = atom_coord_px < median_coord
    mask_above = ~mask_below
    interface_px = median_coord
    interface_nm = interface_px * pixel_size_nm
    n_below = np.sum(mask_below)
    n_above = np.sum(mask_above)

# Compute mean amplitudes for each region
amp_below = np.mean(atom_amps[mask_below]) if n_below > 0 else 0
amp_above = np.mean(atom_amps[mask_above]) if n_above > 0 else 0
print(f"Mean amplitude below: {amp_below:.2f}, above: {amp_above:.2f}")

# Assign regions
std_below = np.std(atom_amps[mask_below]) / amp_below if amp_below > 0 else 999
std_above = np.std(atom_amps[mask_above]) / amp_above if amp_above > 0 else 999
print(f"CV below: {std_below:.3f}, CV above: {std_above:.3f}")

# Substrate should have lower coefficient of variation (more uniform)
if std_below <= std_above:
    substrate_mask = mask_below
    film_mask = mask_above
    substrate_label = 'below'
    film_label = 'above'
else:
    substrate_mask = mask_above
    film_mask = mask_below
    substrate_label = 'above'
    film_label = 'below'

n_film = np.sum(film_mask)
n_substrate = np.sum(substrate_mask)
print(f"Film ({film_label}): {n_film} atoms, Substrate ({substrate_label}): {n_substrate} atoms")

film_positions_nm = atom_positions_nm[film_mask]
film_positions_px = positions_px[film_mask]
film_amps = atom_amps[film_mask]

substrate_positions_nm = atom_positions_nm[substrate_mask]
substrate_positions_px = positions_px[substrate_mask]
substrate_amps = atom_amps[substrate_mask]

# ============================================================
# Step 5: Lattice parameter extraction with directional filtering
# ============================================================
def extract_lattice_params_directional(pos_nm, label=""):
    """
    Extract lattice parameters using directional filtering of Delaunay neighbors.
    Returns dict with a_100, a_010, nn_110, and angle info.
    """
    if len(pos_nm) < 10:
        return {'a_100': np.nan, 'a_010': np.nan, 'a_100_std': np.nan, 'a_010_std': np.nan,
                'nn_110': np.nan, 'n_100': 0, 'n_010': 0}
    
    # Delaunay triangulation
    try:
        tri = Delaunay(pos_nm)
    except Exception as e:
        print(f"  Delaunay failed for {label}: {e}")
        return {'a_100': np.nan, 'a_010': np.nan, 'a_100_std': np.nan, 'a_010_std': np.nan,
                'nn_110': np.nan, 'n_100': 0, 'n_010': 0}
    
    # Extract all edges
    edges = set()
    for simplex in tri.simplices:
        for i in range(3):
            for j in range(i+1, 3):
                a, b = simplex[i], simplex[j]
                edges.add((min(a,b), max(a,b)))
    
    # Compute displacement vectors
    vectors = []
    for a, b in edges:
        dx = pos_nm[b, 0] - pos_nm[a, 0]
        dy = pos_nm[b, 1] - pos_nm[a, 1]
        dist = np.sqrt(dx**2 + dy**2)
        vectors.append((dx, dy, dist))
        # Also add reverse
        vectors.append((-dx, -dy, dist))
    
    vectors = np.array(vectors)
    dists_all = vectors[:, 2]
    
    # Filter out very long vectors (> 2x median)
    med_dist = np.median(dists_all)
    dist_mask = dists_all < 2.5 * med_dist
    vectors_filt = vectors[dist_mask]
    
    # Compute angles from the FILTERED vectors
    angles = np.arctan2(vectors_filt[:, 1], vectors_filt[:, 0]) * 180 / np.pi  # -180 to 180
    dists_filt = vectors_filt[:, 2]
    
    # Build angle histogram to find principal directions
    angle_hist, angle_bins = np.histogram(angles, bins=72, range=(-180, 180))
    angle_centers = (angle_bins[:-1] + angle_bins[1:]) / 2
    
    # Smooth and find peaks
    from scipy.signal import find_peaks
    angle_hist_smooth = gaussian_filter(angle_hist.astype(float), sigma=1)
    peaks, props = find_peaks(angle_hist_smooth, height=np.max(angle_hist_smooth)*0.2, distance=5)
    peak_angles = angle_centers[peaks]
    
    print(f"  {label} - Peak angles: {peak_angles}")
    
    # Strategy: separate vectors by angle into <100>-type and <110>-type
    # <100>: within \u00b120\u00b0 of 0, 90, 180, -90, -180
    # <110>: within \u00b120\u00b0 of 45, -45, 135, -135
    
    def angle_near(a, target, tol=20):
        diff = (a - target + 180) % 360 - 180
        return abs(diff) < tol
    
    # <100> type along x-axis (0\u00b0/180\u00b0)
    mask_100_x = np.array([angle_near(a, 0, 20) or angle_near(a, 180, 20) or angle_near(a, -180, 20) 
                           for a in angles])
    # <100> type along y-axis (90\u00b0/-90\u00b0)
    mask_010_y = np.array([angle_near(a, 90, 20) or angle_near(a, -90, 20) 
                           for a in angles])
    # <110> type
    mask_110 = np.array([angle_near(a, 45, 20) or angle_near(a, -45, 20) or 
                         angle_near(a, 135, 20) or angle_near(a, -135, 20)
                         for a in angles])
    
    dists_100_x = dists_filt[mask_100_x]
    dists_010_y = dists_filt[mask_010_y]
    dists_110 = dists_filt[mask_110]
    
    print(f"  {label} - N vectors: <100>_x={len(dists_100_x)}, <010>_y={len(dists_010_y)}, <110>={len(dists_110)}")
    
    # Check if we have enough <100> vectors or need to use <110> conversion
    a_100 = np.nan
    a_010 = np.nan
    a_100_std = np.nan
    a_010_std = np.nan
    nn_110 = np.nan
    
    # First try direct <100> measurements
    if len(dists_100_x) > 5:
        # Filter to reasonable range (0.3 - 0.5 nm for perovskite)
        good_100 = dists_100_x[(dists_100_x > 0.25) & (dists_100_x < 0.55)]
        if len(good_100) > 3:
            a_100 = np.median(good_100)
            a_100_std = np.std(good_100) / np.sqrt(len(good_100))
    
    if len(dists_010_y) > 5:
        good_010 = dists_010_y[(dists_010_y > 0.25) & (dists_010_y < 0.55)]
        if len(good_010) > 3:
            a_010 = np.median(good_010)
            a_010_std = np.std(good_010) / np.sqrt(len(good_010))
    
    if len(dists_110) > 5:
        good_110 = dists_110[(dists_110 > 0.15) & (dists_110 < 0.40)]
        if len(good_110) > 3:
            nn_110 = np.median(good_110)
    
    # If direct <100> is not available, derive from <110>
    if np.isnan(a_100) and not np.isnan(nn_110):
        a_100 = nn_110 * np.sqrt(2)
        good_110_for_std = dists_110[(dists_110 > 0.15) & (dists_110 < 0.40)]
        a_100_std = (np.std(good_110_for_std) * np.sqrt(2) / 
                     np.sqrt(len(good_110_for_std))) if len(good_110_for_std) > 0 else np.nan
        print(f"  {label} - Derived a_100 from <110>: {a_100:.4f} nm")
    
    if np.isnan(a_010) and not np.isnan(nn_110):
        a_010 = nn_110 * np.sqrt(2)
        a_010_std = a_100_std  # approximate
        print(f"  {label} - Derived a_010 from <110>: {a_010:.4f} nm")
    
    # If still NaN, try second-nearest neighbors with KDTree
    if np.isnan(a_100) or np.isnan(a_010):
        print(f"  {label} - Trying second-nearest neighbor approach...")
        from scipy.spatial import cKDTree
        tree = cKDTree(pos_nm)
        k_neighbors = min(13, len(pos_nm))
        dd, ii = tree.query(pos_nm, k=k_neighbors)
        
        all_vecs = []
        for i in range(len(pos_nm)):
            for j in range(1, k_neighbors):
                nb = ii[i, j]
                dx = pos_nm[nb, 0] - pos_nm[i, 0]
                dy = pos_nm[nb, 1] - pos_nm[i, 1]
                d = dd[i, j]
                ang = np.arctan2(dy, dx) * 180 / np.pi
                all_vecs.append((dx, dy, d, ang))
        
        all_vecs = np.array(all_vecs)
        # Separate into distance shells
        med_d = np.median(all_vecs[:, 2])
        # Second shell around med_d * sqrt(2)
        second_shell = all_vecs[(all_vecs[:, 2] > med_d * 1.2) & (all_vecs[:, 2] < med_d * 1.7)]
        
        if len(second_shell) > 10:
            # These should be <100> type
            angles_2nd = second_shell[:, 3]
            m100 = np.array([angle_near(a, 0, 20) or angle_near(a, 180, 20) or angle_near(a, -180, 20)
                            for a in angles_2nd])
            m010 = np.array([angle_near(a, 90, 20) or angle_near(a, -90, 20)
                            for a in angles_2nd])
            
            if np.isnan(a_100) and np.sum(m100) > 3:
                a_100 = np.median(second_shell[m100, 2])
                a_100_std = np.std(second_shell[m100, 2]) / np.sqrt(np.sum(m100))
            if np.isnan(a_010) and np.sum(m010) > 3:
                a_010 = np.median(second_shell[m010, 2])
                a_010_std = np.std(second_shell[m010, 2]) / np.sqrt(np.sum(m010))
    
    # Cross-validation
    if not np.isnan(nn_110) and not np.isnan(a_100):
        derived = nn_110 * np.sqrt(2)
        print(f"  {label} - Cross-check: a_100={a_100:.4f}, <110>*sqrt(2)={derived:.4f}, ratio={a_100/derived:.3f}")
    
    n_100_count = int(np.sum(mask_100_x))
    n_010_count = int(np.sum(mask_010_y))
    
    return {
        'a_100': a_100, 'a_010': a_010,
        'a_100_std': a_100_std, 'a_010_std': a_010_std,
        'nn_110': nn_110,
        'n_100': n_100_count,
        'n_010': n_010_count
    }

print("\n--- Film lattice parameters ---")
film_lp = extract_lattice_params_directional(film_positions_nm, "Film")
print(f"Film: a_[100] = {film_lp['a_100']:.4f} \u00b1 {film_lp['a_100_std']:.4f} nm")
print(f"Film: a_[010] = {film_lp['a_010']:.4f} \u00b1 {film_lp['a_010_std']:.4f} nm")

print("\n--- Substrate lattice parameters ---")
substrate_lp = extract_lattice_params_directional(substrate_positions_nm, "Substrate")
print(f"Substrate: a_[100] = {substrate_lp['a_100']:.4f} \u00b1 {substrate_lp['a_100_std']:.4f} nm")
print(f"Substrate: a_[010] = {substrate_lp['a_010']:.4f} \u00b1 {substrate_lp['a_010_std']:.4f} nm")

# Compute strain
eps_100 = (film_lp['a_100'] - substrate_lp['a_100']) / substrate_lp['a_100'] if not np.isnan(substrate_lp['a_100']) and substrate_lp['a_100'] > 0 else np.nan
eps_010 = (film_lp['a_010'] - substrate_lp['a_010']) / substrate_lp['a_010'] if not np.isnan(substrate_lp['a_010']) and substrate_lp['a_010'] > 0 else np.nan
tetragonality = film_lp['a_100'] / film_lp['a_010'] if not np.isnan(film_lp['a_010']) and film_lp['a_010'] > 0 else np.nan

print(f"\nStrain \u03b5_[100] = {eps_100*100:.2f}%" if not np.isnan(eps_100) else "Strain \u03b5_[100] = N/A")
print(f"Strain \u03b5_[010] = {eps_010*100:.2f}%" if not np.isnan(eps_010) else "Strain \u03b5_[010] = N/A")
print(f"Tetragonality c/a = {tetragonality:.4f}" if not np.isnan(tetragonality) else "Tetragonality = N/A")

# ============================================================
# Step 6: Windowed 2D FFT for film and substrate regions
# ============================================================
def compute_region_fft(image, positions_px, region_label, pixel_size_nm):
    """
    Extract a square sub-image for a region and compute 2D FFT.
    Returns power spectrum, frequency axes, and the sub-image.
    """
    if len(positions_px) < 10:
        return None, None, None, None
    
    # Find bounding box of atom positions
    x_min, x_max = positions_px[:, 0].min(), positions_px[:, 0].max()
    y_min, y_max = positions_px[:, 1].min(), positions_px[:, 1].max()
    
    # Add small margin
    margin = 10  # pixels
    x_min = max(0, int(x_min - margin))
    x_max = min(image.shape[1], int(x_max + margin))
    y_min = max(0, int(y_min - margin))
    y_max = min(image.shape[0], int(y_max + margin))
    
    # Make it square using the shorter dimension
    width = x_max - x_min
    height = y_max - y_min
    side = min(width, height)
    
    # Center the square crop
    cx = (x_min + x_max) // 2
    cy = (y_min + y_max) // 2
    
    x1 = max(0, cx - side // 2)
    x2 = min(image.shape[1], x1 + side)
    x1 = max(0, x2 - side)  # readjust
    y1 = max(0, cy - side // 2)
    y2 = min(image.shape[0], y1 + side)
    y1 = max(0, y2 - side)
    
    sub_img = image[y1:y2, x1:x2].copy()
    actual_h, actual_w = sub_img.shape
    
    # Apply Hann window
    hann_y = np.hanning(actual_h)
    hann_x = np.hanning(actual_w)
    window = np.outer(hann_y, hann_x)
    
    # Subtract mean before windowing
    sub_windowed = (sub_img - sub_img.mean()) * window
    
    # Zero-pad to at least 1024x1024
    pad_size = max(1024, actual_h, actual_w)
    padded = np.zeros((pad_size, pad_size))
    padded[:actual_h, :actual_w] = sub_windowed
    
    # Compute FFT
    fft2d = np.fft.fftshift(np.fft.fft2(padded))
    power = np.abs(fft2d)**2
    
    # Frequency axes
    freq_x = np.fft.fftshift(np.fft.fftfreq(pad_size, d=pixel_size_nm))  # nm^-1
    freq_y = np.fft.fftshift(np.fft.fftfreq(pad_size, d=pixel_size_nm))
    
    return power, freq_x, freq_y, sub_img

print("\nComputing FFTs...")
film_power, film_freq_x, film_freq_y, film_subimg = compute_region_fft(
    image, film_positions_px, "Film", pixel_size_nm)
substrate_power, sub_freq_x, sub_freq_y, sub_subimg = compute_region_fft(
    image, substrate_positions_px, "Substrate", pixel_size_nm)

# ============================================================
# Step 7: Identify Bragg peaks and superlattice spots
# ============================================================
def find_bragg_peaks(power, freq_x, freq_y, label=""):
    """
    Find peaks in FFT power spectrum.
    Returns list of (fx, fy, distance_from_origin, d_spacing) tuples.
    """
    if power is None:
        return []
    
    log_power = np.log1p(power)
    
    # Mask center
    fy_grid, fx_grid = np.meshgrid(freq_y, freq_x, indexing='ij')
    dist_grid = np.sqrt(fx_grid**2 + fy_grid**2)
    
    # Suppress center and very high frequencies
    log_power_masked = log_power.copy()
    log_power_masked[dist_grid < 0.5] = 0  # mask DC
    log_power_masked[dist_grid > 15] = 0  # mask high freq noise
    
    # Find peaks using local maximum
    from scipy.ndimage import maximum_filter
    local_max = maximum_filter(log_power_masked, size=11)
    peak_mask = (log_power_masked == local_max) & (log_power_masked > np.percentile(log_power_masked[log_power_masked > 0], 95))
    
    peak_locs = np.where(peak_mask)
    peaks = []
    for py, px in zip(peak_locs[0], peak_locs[1]):
        fx = freq_x[px]
        fy = freq_y[py]
        d = np.sqrt(fx**2 + fy**2)
        if d > 0.5:
            d_spacing = 1.0 / d
            peaks.append((fx, fy, d, d_spacing, log_power[py, px]))
    
    # Sort by intensity
    peaks.sort(key=lambda x: -x[4])
    
    print(f"  {label} - Found {len(peaks)} Bragg-like peaks")
    for i, (fx, fy, d, ds, intensity) in enumerate(peaks[:8]):
        print(f"    Peak {i}: f=({fx:.2f}, {fy:.2f}) nm\u207b\u00b9, |f|={d:.2f} nm\u207b\u00b9, d={ds:.3f} nm")
    
    return peaks

print("\n--- Film FFT peaks ---")
film_peaks = find_bragg_peaks(film_power, film_freq_x, film_freq_y, "Film")

print("\n--- Substrate FFT peaks ---")
substrate_peaks = find_bragg_peaks(substrate_power, sub_freq_x, sub_freq_y, "Substrate")

# Check for superlattice spots in film FFT
# Half-order spots should be at ~1.29 nm^-1 (half of fundamental ~2.58 nm^-1)
superlattice_detected = False
superlattice_periodicity = np.nan
if film_peaks:
    for fx, fy, d, ds, intensity in film_peaks:
        if 1.0 < d < 1.6:  # Half-order range
            print(f"  Potential superlattice spot at |f|={d:.2f} nm\u207b\u00b9, d={ds:.3f} nm")
            superlattice_detected = True
            superlattice_periodicity = ds
            break

if superlattice_detected:
    print(f"  SUPERLATTICE DETECTED: periodicity = {superlattice_periodicity:.3f} nm")
else:
    print("  No clear superlattice spots detected in film FFT")

# ============================================================
# Step 8: Amplitude bimodality analysis
# ============================================================
print("\n--- Amplitude bimodality analysis ---")

def analyze_bimodality(amps, label=""):
    """Test for bimodality using GMM comparison."""
    if len(amps) < 20:
        return {'bimodal': False, 'n_components': 1, 'bic_1': np.nan, 'bic_2': np.nan}
    
    amps_reshaped = amps.reshape(-1, 1)
    
    # Fit 1-component GMM
    gmm1 = GaussianMixture(n_components=1, random_state=42)
    gmm1.fit(amps_reshaped)
    bic1 = gmm1.bic(amps_reshaped)
    
    # Fit 2-component GMM
    gmm2 = GaussianMixture(n_components=2, random_state=42)
    gmm2.fit(amps_reshaped)
    bic2 = gmm2.bic(amps_reshaped)
    
    # Lower BIC is better
    bimodal = bic2 < bic1 - 10  # require substantial improvement
    
    result = {
        'bimodal': bimodal,
        'bic_1': float(bic1),
        'bic_2': float(bic2),
        'delta_bic': float(bic1 - bic2)
    }
    
    if bimodal:
        means = gmm2.means_.flatten()
        stds = np.sqrt(gmm2.covariances_.flatten())
        weights = gmm2.weights_.flatten()
        
        # Sort by mean
        order = np.argsort(means)
        means = means[order]
        stds = stds[order]
        weights = weights[order]
        
        result['means'] = means.tolist()
        result['stds'] = stds.tolist()
        result['weights'] = weights.tolist()
        result['intensity_ratio'] = float(means[1] / means[0]) if means[0] > 0 else np.nan
        
        print(f"  {label} - BIMODAL: means={means}, ratio={result['intensity_ratio']:.2f}")
    else:
        print(f"  {label} - Unimodal (\u0394BIC = {bic1-bic2:.1f})")
    
    return result

film_bimodality = analyze_bimodality(film_amps, "Film")
substrate_bimodality = analyze_bimodality(substrate_amps, "Substrate")

# ============================================================
# Step 9: Spatial maps of lattice parameter variation
# ============================================================
print("\n--- Computing spatial lattice parameter maps ---")

def compute_local_lattice_params(pos_nm, max_dist_factor=2.0):
    """
    Compute local lattice parameters for each atom column.
    Returns arrays of per-atom a_100 and a_010.
    """
    from scipy.spatial import cKDTree
    
    n = len(pos_nm)
    if n < 10:
        return np.full(n, np.nan), np.full(n, np.nan)
    
    tree = cKDTree(pos_nm)
    k = min(13, n)
    dd, ii = tree.query(pos_nm, k=k)
    
    med_nn = np.median(dd[:, 1])
    
    a_100_local = np.full(n, np.nan)
    a_010_local = np.full(n, np.nan)
    
    for i in range(n):
        neighbors = ii[i, 1:]
        valid = neighbors < n
        
        for j_idx in range(len(neighbors)):
            if not valid[j_idx]:
                continue
            j = neighbors[j_idx]
            dx = pos_nm[j, 0] - pos_nm[i, 0]
            dy = pos_nm[j, 1] - pos_nm[i, 1]
            d = np.sqrt(dx**2 + dy**2)
            angle = np.arctan2(dy, dx) * 180 / np.pi
            
            # Check if this is a <100> neighbor
            def angle_near(a, t, tol=25):
                diff = (a - t + 180) % 360 - 180
                return abs(diff) < tol
            
            # Allow both direct <100> and derived from <110>
            if 0.25 < d < 0.55:
                if angle_near(angle, 0) or angle_near(angle, 180) or angle_near(angle, -180):
                    if np.isnan(a_100_local[i]) or abs(d - 0.387) < abs(a_100_local[i] - 0.387):
                        a_100_local[i] = d
                if angle_near(angle, 90) or angle_near(angle, -90):
                    if np.isnan(a_010_local[i]) or abs(d - 0.387) < abs(a_010_local[i] - 0.387):
                        a_010_local[i] = d
            
            # <110> neighbors - use to fill in if <100> not found
            if 0.18 < d < 0.35:
                if (angle_near(angle, 45, 20) or angle_near(angle, -45, 20) or
                    angle_near(angle, 135, 20) or angle_near(angle, -135, 20)):
                    derived_100 = d * np.sqrt(2)
                    if np.isnan(a_100_local[i]):
                        a_100_local[i] = derived_100
                    if np.isnan(a_010_local[i]):
                        a_010_local[i] = derived_100
    
    return a_100_local, a_010_local

# Compute for all atoms
all_a100, all_a010 = compute_local_lattice_params(atom_positions_nm)

# Strain profile: lattice parameter vs distance from interface
if growth_axis == 'y':
    dist_from_interface = atom_positions_nm[:, 1] - interface_nm
else:
    dist_from_interface = atom_positions_nm[:, 0] - interface_nm

# Bin the strain profile
valid_a100 = ~np.isnan(all_a100)
valid_a010 = ~np.isnan(all_a010)

n_bins = 30
bin_edges = np.linspace(dist_from_interface.min(), dist_from_interface.max(), n_bins + 1)
bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2

binned_a100 = np.full(n_bins, np.nan)
binned_a010 = np.full(n_bins, np.nan)
binned_a100_std = np.full(n_bins, np.nan)
binned_a010_std = np.full(n_bins, np.nan)

for i in range(n_bins):
    in_bin = (dist_from_interface >= bin_edges[i]) & (dist_from_interface < bin_edges[i+1])
    
    vals = all_a100[in_bin & valid_a100]
    if len(vals) > 2:
        binned_a100[i] = np.median(vals)
        binned_a100_std[i] = np.std(vals) / np.sqrt(len(vals))
    
    vals = all_a010[in_bin & valid_a010]
    if len(vals) > 2:
        binned_a010[i] = np.median(vals)
        binned_a010_std[i] = np.std(vals) / np.sqrt(len(vals))

print(f"Computed local lattice parameters for {np.sum(valid_a100)} / {len(all_a100)} atoms")

# Estimate interface sharpness from strain gradient
valid_bins = ~np.isnan(binned_a100)
if np.sum(valid_bins) > 5:
    try:
        popt_strain, _ = curve_fit(sigmoid_func, 
                                   bin_centers[valid_bins], 
                                   binned_a100[valid_bins],
                                   p0=[np.nanmean(binned_a100), 
                                       (np.nanmax(binned_a100) - np.nanmin(binned_a100))/2,
                                       0, 2],
                                   maxfev=5000)
        interface_sharpness_nm = abs(popt_strain[3])
        print(f"Interface sharpness from strain: {interface_sharpness_nm:.2f} nm")
    except:
        interface_sharpness_nm = np.nan
else:
    interface_sharpness_nm = np.nan

# ============================================================
# Step 10: Visualization
# ============================================================
print("\nGenerating visualization...")

fig, axes = plt.subplots(2, 3, figsize=(18, 12), dpi=100)

# Panel 1: Original image with interface and atom partitioning
ax = axes[0, 0]
ax.imshow(image, cmap='gray', origin='lower')
ax.scatter(film_positions_px[:, 0], film_positions_px[:, 1], 
           c='red', s=2, alpha=0.3, label=f'Film (N={n_film})')
ax.scatter(substrate_positions_px[:, 0], substrate_positions_px[:, 1], 
           c='blue', s=2, alpha=0.3, label=f'Substrate (N={n_substrate})')

if growth_axis == 'y':
    ax.axhline(y=interface_px, color='lime', linewidth=2, linestyle='--', label='Interface')
else:
    ax.axvline(x=interface_px, color='lime', linewidth=2, linestyle='--', label='Interface')
ax.legend(fontsize=8, loc='upper right')
ax.set_title('HAADF-STEM with Film/Substrate Partition')
ax.set_xlabel('x (pixels)')
ax.set_ylabel('y (pixels)')

# Panel 2: Intensity profile with interface fit
ax = axes[0, 1]
coords_nm = np.arange(len(profile)) * pixel_size_nm
ax.plot(coords_nm, profile_raw, 'gray', alpha=0.5, label='Raw')
ax.plot(coords_nm, profile, 'b-', linewidth=2, label='Smoothed')
if fit_success:
    x_fit = np.arange(len(profile))
    ax.plot(coords_nm, sigmoid_func(x_fit, *popt), 'r--', linewidth=2, label='Erf fit')
ax.axvline(x=interface_nm, color='lime', linewidth=2, linestyle='--', label=f'Interface={interface_nm:.1f}nm')
ax.set_xlabel(f'Position along {growth_axis} (nm)')
ax.set_ylabel('Mean Intensity')
ax.set_title('Interface Detection')
ax.legend(fontsize=8)

# Panel 3: Film FFT
ax = axes[0, 2]
if film_power is not None:
    log_film_power = np.log1p(film_power)
    extent = [film_freq_x[0], film_freq_x[-1], film_freq_y[0], film_freq_y[-1]]
    fft_range = 8  # nm^-1
    ax.imshow(log_film_power, cmap='inferno', origin='lower', extent=extent,
              vmin=np.percentile(log_film_power, 50), vmax=np.percentile(log_film_power, 99.9))
    ax.set_xlim(-fft_range, fft_range)
    ax.set_ylim(-fft_range, fft_range)
    
    # Mark expected Bragg peak positions
    a_expected = film_lp['a_100'] if not np.isnan(film_lp['a_100']) else 0.387
    f_bragg = 1.0 / a_expected
    circle1 = plt.Circle((0, 0), f_bragg, fill=False, color='cyan', linewidth=1, linestyle='--', label=f'Fundamental ({f_bragg:.2f} nm\u207b\u00b9)')
    ax.add_patch(circle1)
    circle_half = plt.Circle((0, 0), f_bragg/2, fill=False, color='lime', linewidth=1, linestyle=':', label=f'Half-order ({f_bragg/2:.2f} nm\u207b\u00b9)')
    ax.add_patch(circle_half)
    ax.legend(fontsize=7, loc='upper right')

ax.set_xlabel('f_x (nm\u207b\u00b9)')
ax.set_ylabel('f_y (nm\u207b\u00b9)')
ax.set_title('Film 2D FFT (log power)')

# Panel 4: Amplitude histograms
ax = axes[1, 0]
bins_amp = 40
ax.hist(film_amps, bins=bins_amp, alpha=0.6, color='red', density=True, label='Film')
ax.hist(substrate_amps, bins=bins_amp, alpha=0.6, color='blue', density=True, label='Substrate')

if film_bimodality.get('bimodal', False) and 'means' in film_bimodality:
    for m, s, w in zip(film_bimodality['means'], film_bimodality['stds'], film_bimodality['weights']):
        x_range = np.linspace(film_amps.min(), film_amps.max(), 200)
        ax.plot(x_range, w * (1/(s*np.sqrt(2*np.pi))) * np.exp(-0.5*((x_range-m)/s)**2),
                'r--', linewidth=2)
    ax.set_title(f'Amplitude Distributions\nFilm: BIMODAL (ratio={film_bimodality.get("intensity_ratio", 0):.2f})')
else:
    ax.set_title('Amplitude Distributions\nFilm: Unimodal')

ax.set_xlabel('Column Amplitude')
ax.set_ylabel('Density')
ax.legend(fontsize=9)

# Panel 5: Spatial lattice parameter map
ax = axes[1, 1]
valid_map = ~np.isnan(all_a100)
if np.sum(valid_map) > 10:
    sc = ax.scatter(atom_positions_nm[valid_map, 0], atom_positions_nm[valid_map, 1],
                    c=all_a100[valid_map], cmap='RdBu_r', s=5, alpha=0.7,
                    vmin=np.nanpercentile(all_a100[valid_map], 5),
                    vmax=np.nanpercentile(all_a100[valid_map], 95))
    plt.colorbar(sc, ax=ax, label='a_[100] (nm)')
    if growth_axis == 'y':
        ax.axhline(y=interface_nm, color='lime', linewidth=2, linestyle='--')
    else:
        ax.axvline(x=interface_nm, color='lime', linewidth=2, linestyle='--')
ax.set_xlabel('x (nm)')
ax.set_ylabel('y (nm)')
ax.set_title('Local a_[100] Map')
ax.set_aspect('equal')

# Panel 6: Strain profile across interface
ax = axes[1, 2]
valid_100 = ~np.isnan(binned_a100)
valid_010 = ~np.isnan(binned_a010)

if np.sum(valid_100) > 2:
    ax.errorbar(bin_centers[valid_100], binned_a100[valid_100], 
                yerr=binned_a100_std[valid_100], fmt='ro-', markersize=4, 
                label='a_[100]', capsize=2)
if np.sum(valid_010) > 2:
    ax.errorbar(bin_centers[valid_010], binned_a010[valid_010],
                yerr=binned_a010_std[valid_010], fmt='bs-', markersize=4,
                label='a_[010]', capsize=2)

ax.axvline(x=0, color='lime', linewidth=2, linestyle='--', label='Interface')
ax.axhline(y=0.3868, color='gray', linewidth=1, linestyle=':', label='LSAT bulk (0.3868 nm)')
ax.axhline(y=0.387, color='orange', linewidth=1, linestyle=':', label='LLTO bulk (0.387 nm)')
ax.set_xlabel('Distance from interface (nm)')
ax.set_ylabel('Lattice parameter (nm)')
ax.set_title('Strain Profile Across Interface')
ax.legend(fontsize=7)

plt.tight_layout()
plt.savefig('analysis_visualization.png', dpi=100, bbox_inches='tight')
plt.close()
print("Saved analysis_visualization.png")

# ============================================================
# Save arrays
# ============================================================
np.save('film_positions_nm.npy', film_positions_nm)
np.save('substrate_positions_nm.npy', substrate_positions_nm)
np.save('local_a100_map.npy', all_a100)
np.save('local_a010_map.npy', all_a010)
np.save('strain_profile_distance.npy', bin_centers)
np.save('strain_profile_a100.npy', binned_a100)
np.save('strain_profile_a010.npy', binned_a010)
np.save('film_amplitudes.npy', film_amps)
np.save('substrate_amplitudes.npy', substrate_amps)

# Partition label map
partition_labels = np.zeros(len(atom_positions_nm), dtype=np.int32)
partition_labels[film_mask] = 1  # film
partition_labels[substrate_mask] = 2  # substrate
np.save('atom_partition_labels.npy', partition_labels)

print("Saved all .npy arrays")

# ============================================================
# Step 10: Final JSON results
# ============================================================
results = {
    "analysis_type": "LLTO/LSAT thin film HAADF-STEM analysis: interface detection, directional lattice parameter extraction, FFT-based superlattice detection, amplitude bimodality, and strain mapping",
    "extracted_features": {
        "film_a_100_nm": round(float(film_lp['a_100']), 4) if not np.isnan(film_lp['a_100']) else None,
        "film_a_100_stderr_nm": round(float(film_lp['a_100_std']), 5) if not np.isnan(film_lp['a_100_std']) else None,
        "film_a_010_nm": round(float(film_lp['a_010']), 4) if not np.isnan(film_lp['a_010']) else None,
        "film_a_010_stderr_nm": round(float(film_lp['a_010_std']), 5) if not np.isnan(film_lp['a_010_std']) else None,
        "substrate_a_100_nm": round(float(substrate_lp['a_100']), 4) if not np.isnan(substrate_lp['a_100']) else None,
        "substrate_a_100_stderr_nm": round(float(substrate_lp['a_100_std']), 5) if not np.isnan(substrate_lp['a_100_std']) else None,
        "substrate_a_010_nm": round(float(substrate_lp['a_010']), 4) if not np.isnan(substrate_lp['a_010']) else None,
        "substrate_a_010_stderr_nm": round(float(substrate_lp['a_010_std']), 5) if not np.isnan(substrate_lp['a_010_std']) else None,
        "strain_epsilon_100_percent": round(float(eps_100 * 100), 3) if not np.isnan(eps_100) else None,
        "strain_epsilon_010_percent": round(float(eps_010 * 100), 3) if not np.isnan(eps_010) else None,
        "film_tetragonality_c_over_a": round(float(tetragonality), 4) if not np.isnan(tetragonality) else None,
        "interface_position_nm": round(float(interface_nm), 2),
        "interface_uncertainty_nm": round(float(interface_uncertainty_nm), 3) if 'interface_uncertainty_nm' in dir() else None,
        "interface_sharpness_nm": round(float(interface_sharpness_nm), 2) if not np.isnan(interface_sharpness_nm) else None,
        "growth_direction": growth_axis,
        "pixel_size_nm": round(float(pixel_size_nm), 5),
        "film_nn_110_nm": round(float(film_lp['nn_110']), 4) if not np.isnan(film_lp['nn_110']) else None,
        "substrate_nn_110_nm": round(float(substrate_lp['nn_110']), 4) if not np.isnan(substrate_lp['nn_110']) else None,
        "cross_validation_film_110_x_sqrt2": round(float(film_lp['nn_110'] * np.sqrt(2)), 4) if not np.isnan(film_lp['nn_110']) else None,
        "cross_validation_substrate_110_x_sqrt2": round(float(substrate_lp['nn_110'] * np.sqrt(2)), 4) if not np.isnan(substrate_lp['nn_110']) else None,
        "superlattice_detected": superlattice_detected,
        "superlattice_periodicity_nm": round(float(superlattice_periodicity), 3) if not np.isnan(superlattice_periodicity) else None,
        "film_bimodal": film_bimodality.get('bimodal', False),
        "film_bimodality_delta_bic": round(float(film_bimodality.get('delta_bic', 0)), 1),
        "film_intensity_ratio": round(float(film_bimodality.get('intensity_ratio', np.nan)), 3) if film_bimodality.get('bimodal', False) else None,
        "substrate_bimodal": substrate_bimodality.get('bimodal', False),
        "n_atoms_film": int(n_film),
        "n_atoms_substrate": int(n_substrate),
        "n_atoms_total": int(len(atom_positions_nm)),
        "LSAT_bulk_a_nm": 0.3868,
        "LLTO_bulk_a_nm": 0.387
    },
    "quality_metrics": {
        "film_n_100_vectors": int(film_lp.get('n_100', 0)),
        "film_n_010_vectors": int(film_lp.get('n_010', 0)),
        "substrate_n_100_vectors": int(substrate_lp.get('n_100', 0)),
        "substrate_n_010_vectors": int(substrate_lp.get('n_010', 0)),
        "interface_fit_success": fit_success,
        "local_lattice_params_coverage": round(float(np.sum(valid_map) / len(all_a100) * 100), 1)
    },
    "summary": f"LLTO/LSAT interface detected at {interface_nm:.1f} nm along {growth_axis}-axis. Film a_[100]={film_lp['a_100']:.4f} nm, a_[010]={film_lp['a_010']:.4f} nm. Substrate a_[100]={substrate_lp['a_100']:.4f} nm. Epitaxial strain: eps_100={eps_100*100:.2f}% (if computed). {'Superlattice ordering detected with periodicity ' + str(round(superlattice_periodicity, 3)) + ' nm. ' if superlattice_detected else 'No clear superlattice ordering. '}{'Film shows bimodal A-site intensity distribution (La/Li ordering).' if film_bimodality.get('bimodal', False) else 'Film A-site intensities appear unimodal.'}",
    "saved_arrays": {
        "film_positions_nm.npy": {
            "description": f"Film atom column positions in nm, (x, y) format",
            "shape": list(film_positions_nm.shape),
            "dtype": str(film_positions_nm.dtype)
        },
        "substrate_positions_nm.npy": {
            "description": f"Substrate atom column positions in nm, (x, y) format",
            "shape": list(substrate_positions_nm.shape),
            "dtype": str(substrate_positions_nm.dtype)
        },
        "local_a100_map.npy": {
            "description": "Per-atom local a_[100] lattice parameter in nm",
            "shape": list(all_a100.shape),
            "dtype": str(all_a100.dtype)
        },
        "local_a010_map.npy": {
            "description": "Per-atom local a_[010] lattice parameter in nm",
            "shape": list(all_a010.shape),
            "dtype": str(all_a010.dtype)
        },
        "strain_profile_distance.npy": {
            "description": "Bin centers for strain profile (distance from interface in nm)",
            "shape": list(bin_centers.shape),
            "dtype": str(bin_centers.dtype)
        },
        "strain_profile_a100.npy": {
            "description": "Binned median a_[100] vs distance from interface",
            "shape": list(binned_a100.shape),
            "dtype": str(binned_a100.dtype)
        },
        "strain_profile_a010.npy": {
            "description": "Binned median a_[010] vs distance from interface",
            "shape": list(binned_a010.shape),
            "dtype": str(binned_a010.dtype)
        },
        "atom_partition_labels.npy": {
            "description": "Per-atom labels: 0=unassigned, 1=film, 2=substrate",
            "shape": list(partition_labels.shape),
            "dtype": str(partition_labels.dtype)
        },
        "film_amplitudes.npy": {
            "description": "Atom column amplitudes in film region",
            "shape": list(film_amps.shape),
            "dtype": str(film_amps.dtype)
        },
        "substrate_amplitudes.npy": {
            "description": "Atom column amplitudes in substrate region",
            "shape": list(substrate_amps.shape),
            "dtype": str(substrate_amps.dtype)
        }
    }
}

print(f"IMAGE_ANALYSIS_RESULTS_JSON:{json.dumps(results)}")
