import numpy as np
import cv2
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import ndimage, signal
from skimage import exposure
import json
import warnings
warnings.filterwarnings('ignore')

from scilink.tools.atom_finding_tools import detect_atoms, detect_atoms_dcnn, refine_positions, find_zone_axes, find_missing_atoms, subtract_atoms

# ============================================================
# 1. Load image and compute pixel size
# ============================================================
path = '/Users/maxim.ziatdinov/Code/SciLink/benchmarking_test_output/image_0000/temp_image_0.npy'
image = np.load(path)
print(f"Image shape: {image.shape}, dtype: {image.dtype}")
print(f"Intensity range: [{image.min()}, {image.max()}]")

# Metadata-derived pixel size
fov_nm = 20.88  # nm
image_size = image.shape[0]  # 1024
pixel_size_nm = fov_nm / image_size  # 0.02039 nm/px
print(f"Pixel size: {pixel_size_nm:.5f} nm/px")
print(f"FOV: {fov_nm} nm")

# ============================================================
# 2. Inspect profiles to confirm no substrate boundary
# ============================================================
horiz_profile = np.mean(image, axis=0)  # average along rows -> column profile
vert_profile = np.mean(image, axis=1)   # average along columns -> row profile

# Check for large jumps that would indicate a boundary
horiz_diff = np.abs(np.diff(horiz_profile))
vert_diff = np.abs(np.diff(vert_profile))
horiz_max_jump = np.max(horiz_diff)
vert_max_jump = np.max(vert_diff)
horiz_mean = np.mean(horiz_diff)
vert_mean = np.mean(vert_diff)

substrate_boundary = False
if horiz_max_jump > 10 * horiz_mean or vert_max_jump > 10 * vert_mean:
    substrate_boundary = True
print(f"Substrate boundary detected: {substrate_boundary}")
print(f"Horizontal max jump: {horiz_max_jump:.1f} (mean: {horiz_mean:.1f})")
print(f"Vertical max jump: {vert_max_jump:.1f} (mean: {vert_mean:.1f})")

# ============================================================
# 3. Preprocessing
# ============================================================
# (a) CLAHE with aggressive settings
img_norm = ((image - image.min()) / (image.max() - image.min()) * 255).astype(np.uint8)
clahe = cv2.createCLAHE(clipLimit=3.5, tileGridSize=(4, 4))
img_clahe = clahe.apply(img_norm)

# (b) Subtract column-wise mean to suppress vertical scan noise
col_mean = np.mean(img_clahe.astype(np.float64), axis=0, keepdims=True)
img_processed = img_clahe.astype(np.float64) - col_mean + np.mean(img_clahe)
img_processed = np.clip(img_processed, 0, 255).astype(np.float64)

# Normalize to 0-1 float for atom detection
img_for_detection = ((img_processed - img_processed.min()) / (img_processed.max() - img_processed.min())).astype(np.float32)

# ============================================================
# 4. Compute 2D FFT
# ============================================================
# Apply Hamming window
hamming_1d = np.hamming(image_size)
hamming_2d = np.outer(hamming_1d, hamming_1d)
img_windowed = (image.astype(np.float64) - np.mean(image)) * hamming_2d

fft2 = np.fft.fft2(img_windowed)
fft_shifted = np.fft.fftshift(fft2)
power_spectrum = np.abs(fft_shifted) ** 2
log_power = np.log1p(power_spectrum)

center = image_size // 2

# ============================================================
# 5. Bragg peak detection in FFT
# ============================================================
# (a) Mask DC region - exclude periods > 0.8 nm
dc_mask_radius = int(fov_nm / 0.8)  # ~26 pixels
print(f"DC mask radius: {dc_mask_radius} px")

# (b) Create working copy of log power spectrum for peak detection
log_power_work = log_power.copy()

# Mask DC
y_grid, x_grid = np.ogrid[:image_size, :image_size]
dist_from_center = np.sqrt((x_grid - center)**2 + (y_grid - center)**2)
log_power_work[dist_from_center < dc_mask_radius] = 0

# Suppress vertical streak (kx=0 axis, i.e., the center column)
streak_width = 4
log_power_work[:, center-streak_width:center+streak_width+1] = 0

# (d) Search in annular region for fundamental Bragg peaks (0.3-0.5 nm)
inner_radius = int(fov_nm / 0.5)  # ~42 px
outer_radius = int(fov_nm / 0.3)  # ~70 px
print(f"Bragg peak search annulus: {inner_radius}-{outer_radius} px")

# Create annular mask
annular_mask = (dist_from_center >= inner_radius) & (dist_from_center <= outer_radius)
log_power_annular = log_power_work.copy()
log_power_annular[~annular_mask] = 0

# Find peaks using local maximum filter
from scipy.ndimage import maximum_filter, label
neighborhood_size = 11
local_max = maximum_filter(log_power_annular, size=neighborhood_size)
peak_mask = (log_power_annular == local_max) & (log_power_annular > 0)

# Get peak coordinates and intensities
peak_coords = np.argwhere(peak_mask)
peak_intensities = log_power_annular[peak_mask]

# Sort by intensity and take top peaks
if len(peak_intensities) > 0:
    sort_idx = np.argsort(peak_intensities)[::-1]
    n_top = min(20, len(sort_idx))
    top_peaks = peak_coords[sort_idx[:n_top]]
    top_intensities = peak_intensities[sort_idx[:n_top]]
    
    print(f"\nTop {n_top} Bragg peaks in fundamental annulus:")
    fft_lattice_params = []
    for i in range(min(8, n_top)):
        py, px = top_peaks[i]
        dy, dx = py - center, px - center
        radius = np.sqrt(dx**2 + dy**2)
        real_space_period = fov_nm / radius if radius > 0 else 0
        angle = np.degrees(np.arctan2(dy, dx))
        fft_lattice_params.append(real_space_period)
        print(f"  Peak {i}: pixel ({px},{py}), r={radius:.1f}, d={real_space_period:.4f} nm, angle={angle:.1f}°, I={top_intensities[i]:.1f}")
    
    fft_lattice_mean = np.mean(fft_lattice_params[:4]) if len(fft_lattice_params) >= 4 else np.mean(fft_lattice_params)
else:
    top_peaks = np.array([])
    fft_lattice_mean = 0
    fft_lattice_params = []

print(f"\nFFT-derived lattice parameter (mean of top peaks): {fft_lattice_mean:.4f} nm")

# (e) Check for superlattice reflections at half-order positions (~0.77 nm)
superlattice_radius_expected = fov_nm / 0.77  # ~27 px
sl_inner = int(superlattice_radius_expected - 5)
sl_outer = int(superlattice_radius_expected + 5)
sl_mask = (dist_from_center >= sl_inner) & (dist_from_center <= sl_outer)
log_power_sl = log_power_work.copy()
log_power_sl[~sl_mask] = 0

sl_local_max = maximum_filter(log_power_sl, size=neighborhood_size)
sl_peak_mask = (log_power_sl == sl_local_max) & (log_power_sl > 0)
sl_peak_coords = np.argwhere(sl_peak_mask)
sl_peak_intensities = log_power_sl[sl_peak_mask]

superlattice_detected = False
if len(sl_peak_intensities) > 0:
    sl_sort = np.argsort(sl_peak_intensities)[::-1]
    sl_top = sl_peak_coords[sl_sort[:min(6, len(sl_sort))]]
    sl_top_int = sl_peak_intensities[sl_sort[:min(6, len(sl_sort))]]
    
    # Check if these are significant (above noise)
    noise_level = np.median(log_power_work[log_power_work > 0]) if np.any(log_power_work > 0) else 0
    significant_sl = sl_top_int > 2 * noise_level
    if np.any(significant_sl):
        superlattice_detected = True
        print(f"\nSuperlattice reflections detected at half-order positions:")
        for i in range(min(4, len(sl_top))):
            if significant_sl[i]:
                py, px = sl_top[i]
                dy, dx = py - center, px - center
                r = np.sqrt(dx**2 + dy**2)
                d = fov_nm / r if r > 0 else 0
                ang = np.degrees(np.arctan2(dy, dx))
                print(f"  SL Peak {i}: r={r:.1f}, d={d:.4f} nm, angle={ang:.1f}°, I={sl_top_int[i]:.1f}")
    else:
        print("\nNo significant superlattice reflections detected.")
else:
    print("\nNo superlattice reflections found.")

# ============================================================
# 6. Atom detection using DCNN
# ============================================================
print("\nRunning DCNN atom detection...")
try:
    dcnn_result = detect_atoms_dcnn(img_for_detection, fov_nm=fov_nm, threshold=0.8, refine=False)
    positions = dcnn_result["positions"]  # (N, 2) as (x, y) in pixels
    heatmap = dcnn_result.get("heatmap", None)
    print(f"DCNN detected {len(positions)} atom columns")
except Exception as e:
    print(f"DCNN detection failed: {e}, falling back to classical detection")
    sep_px = int(0.27 / pixel_size_nm)  # ~13 pixels
    result_classical = detect_atoms(img_for_detection, separation=sep_px, threshold_rel=0.02, refine=True)
    positions = result_classical["positions"]
    print(f"Classical detection found {len(positions)} atom columns")

# Check detection coverage in bottom-right quadrant
half = image_size // 2
all_count = len(positions)
br_mask_pos = (positions[:, 0] > half) & (positions[:, 1] > half)
br_count = np.sum(br_mask_pos)
other_quadrant_counts = []
for qx, qy in [(0, 0), (1, 0), (0, 1)]:
    qmask = (positions[:, 0] > qx*half) & (positions[:, 0] <= (qx+1)*half) & \
            (positions[:, 1] > qy*half) & (positions[:, 1] <= (qy+1)*half)
    other_quadrant_counts.append(np.sum(qmask))
mean_other = np.mean(other_quadrant_counts)

print(f"Bottom-right quadrant: {br_count} atoms, other quadrants mean: {mean_other:.0f}")

# If bottom-right is significantly underdetected, do a second pass
if br_count < 0.7 * mean_other and mean_other > 0:
    print("Bottom-right quadrant underdetected. Running second pass...")
    br_crop = image[half:, half:]
    br_norm = ((br_crop - br_crop.min()) / (br_crop.max() - br_crop.min()) * 255).astype(np.uint8)
    clahe_strong = cv2.createCLAHE(clipLimit=5.0, tileGridSize=(4, 4))
    br_enhanced = clahe_strong.apply(br_norm)
    br_float = br_enhanced.astype(np.float32) / 255.0
    
    try:
        br_fov = fov_nm * (image_size - half) / image_size
        br_result = detect_atoms_dcnn(br_float, fov_nm=br_fov, threshold=0.7, refine=False)
        br_positions = br_result["positions"].copy()
        # Offset to full image coordinates
        br_positions[:, 0] += half
        br_positions[:, 1] += half
        
        # Merge, removing duplicates within 0.1 nm
        dup_threshold_px = 0.1 / pixel_size_nm  # ~5 px
        from scipy.spatial import cKDTree
        if len(br_positions) > 0:
            tree = cKDTree(positions)
            dists, _ = tree.query(br_positions)
            new_mask = dists > dup_threshold_px
            new_positions = br_positions[new_mask]
            positions = np.vstack([positions, new_positions])
            print(f"Added {len(new_positions)} new atoms from BR pass. Total: {len(positions)}")
    except Exception as e:
        print(f"Second pass failed: {e}")

# ============================================================
# 7. Refine positions
# ============================================================
print("\nRefining atom positions...")
try:
    refined = refine_positions(img_for_detection, positions, percent_to_nn=0.4)
    positions_refined = refined["positions"]
    sigma_x = refined["sigma_x"]
    sigma_y = refined["sigma_y"]
    amplitudes = refined["amplitude"]
    print(f"Refined {len(positions_refined)} positions")
except Exception as e:
    print(f"Refinement failed: {e}")
    positions_refined = positions
    sigma_x = None
    sigma_y = None
    amplitudes = None

# ============================================================
# 8. Nearest-neighbor distances
# ============================================================
from scipy.spatial import cKDTree

# Convert positions from pixels to nm
positions_nm = positions_refined * pixel_size_nm

tree = cKDTree(positions_nm)
# Query k=2 (first neighbor is the point itself at distance 0)
dists, indices = tree.query(positions_nm, k=7)
nn_distances = dists[:, 1]  # nearest neighbor distance

nn_mean = np.mean(nn_distances)
nn_std = np.std(nn_distances)
nn_median = np.median(nn_distances)

print(f"\nNearest-neighbor distances:")
print(f"  Mean: {nn_mean:.4f} nm")
print(f"  Std: {nn_std:.4f} nm")
print(f"  Median: {nn_median:.4f} nm")

# ============================================================
# 9. Zone axes analysis
# ============================================================
print("\nFinding zone axes...")
try:
    zone_axes = find_zone_axes(positions_refined, n_neighbors=9)
    print(f"Found {len(zone_axes)} zone axes:")
    
    zone_axes_nm = []
    for i, (dx, dy) in enumerate(zone_axes):
        dx_nm = dx * pixel_size_nm
        dy_nm = dy * pixel_size_nm
        mag_nm = np.sqrt(dx_nm**2 + dy_nm**2)
        angle = np.degrees(np.arctan2(dy_nm, dx_nm))
        zone_axes_nm.append((dx_nm, dy_nm, mag_nm, angle))
        print(f"  ZA {i}: ({dx_nm:.4f}, {dy_nm:.4f}) nm, |v|={mag_nm:.4f} nm, angle={angle:.1f}°")
    
    # CRITICAL INTERPRETATION: Select fundamental [100] and [010] vectors
    # These should be ~0.384-0.393 nm, oriented near 0° and 90°
    # The shorter ~0.256 nm vectors at ±45° are [110] projections (a/√2)
    
    fundamental_vectors = []
    diagonal_vectors = []
    
    for i, (dx_nm, dy_nm, mag_nm, angle) in enumerate(zone_axes_nm):
        if 0.33 < mag_nm < 0.45:  # Fundamental range
            fundamental_vectors.append((i, dx_nm, dy_nm, mag_nm, angle))
        elif 0.22 < mag_nm < 0.32:  # [110] diagonal range
            diagonal_vectors.append((i, dx_nm, dy_nm, mag_nm, angle))
    
    print(f"\nFundamental vectors (0.33-0.45 nm): {len(fundamental_vectors)}")
    for fv in fundamental_vectors:
        print(f"  ZA {fv[0]}: mag={fv[3]:.4f} nm, angle={fv[4]:.1f}°")
    
    print(f"Diagonal [110] vectors (0.22-0.32 nm): {len(diagonal_vectors)}")
    for dv in diagonal_vectors:
        print(f"  ZA {dv[0]}: mag={dv[3]:.4f} nm, angle={dv[4]:.1f}°")
    
    # Determine lattice constant from fundamental vectors
    if len(fundamental_vectors) >= 2:
        # Sort by angle to identify [100] (~0°) and [010] (~90°)
        fundamental_vectors.sort(key=lambda x: abs(x[4]))
        
        # Find pair most orthogonal
        best_pair = None
        best_ortho = 180
        for i in range(len(fundamental_vectors)):
            for j in range(i+1, len(fundamental_vectors)):
                angle_diff = abs(abs(fundamental_vectors[i][4] - fundamental_vectors[j][4]) - 90)
                if angle_diff < best_ortho:
                    best_ortho = angle_diff
                    best_pair = (i, j)
        
        if best_pair is not None:
            v1 = fundamental_vectors[best_pair[0]]
            v2 = fundamental_vectors[best_pair[1]]
            a_100 = v1[3]
            a_010 = v2[3]
            lattice_constant_za = (a_100 + a_010) / 2
            tetragonal_ratio = a_100 / a_010 if a_010 > 0 else 1.0
            tetragonal_diff = abs(a_100 - a_010)
            
            print(f"\n=== ZONE AXES LATTICE PARAMETERS ===")
            print(f"  a_[100] = {a_100:.4f} nm (angle={v1[4]:.1f}°)")
            print(f"  a_[010] = {a_010:.4f} nm (angle={v2[4]:.1f}°)")
            print(f"  Average lattice constant: {lattice_constant_za:.4f} nm")
            print(f"  Tetragonal ratio: {tetragonal_ratio:.4f}")
            print(f"  Tetragonal distortion: {tetragonal_diff:.4f} nm")
            print(f"  Orthogonality deviation: {best_ortho:.1f}°")
        else:
            lattice_constant_za = fundamental_vectors[0][3]
            a_100 = lattice_constant_za
            a_010 = lattice_constant_za
            tetragonal_ratio = 1.0
            tetragonal_diff = 0.0
    elif len(fundamental_vectors) == 1:
        lattice_constant_za = fundamental_vectors[0][3]
        a_100 = lattice_constant_za
        a_010 = lattice_constant_za
        tetragonal_ratio = 1.0
        tetragonal_diff = 0.0
        print(f"Only one fundamental vector found: {lattice_constant_za:.4f} nm")
    elif len(diagonal_vectors) >= 1:
        # Fall back: derive from diagonal vectors
        diag_mean = np.mean([dv[3] for dv in diagonal_vectors])
        lattice_constant_za = diag_mean * np.sqrt(2)
        a_100 = lattice_constant_za
        a_010 = lattice_constant_za
        tetragonal_ratio = 1.0
        tetragonal_diff = 0.0
        print(f"No fundamental vectors; derived from diagonals: {lattice_constant_za:.4f} nm")
    else:
        lattice_constant_za = nn_mean * np.sqrt(2)
        a_100 = lattice_constant_za
        a_010 = lattice_constant_za
        tetragonal_ratio = 1.0
        tetragonal_diff = 0.0
        print(f"No zone axes vectors in expected range; derived from NN: {lattice_constant_za:.4f} nm")
    
    # [110] NN distance from zone axes
    if len(diagonal_vectors) > 0:
        nn_110_za = np.mean([dv[3] for dv in diagonal_vectors])
    else:
        nn_110_za = nn_mean
    
except Exception as e:
    print(f"Zone axes analysis failed: {e}")
    zone_axes = []
    zone_axes_nm = []
    lattice_constant_za = nn_mean * np.sqrt(2)
    a_100 = lattice_constant_za
    a_010 = lattice_constant_za
    tetragonal_ratio = 1.0
    tetragonal_diff = 0.0
    nn_110_za = nn_mean
    fundamental_vectors = []
    diagonal_vectors = []

# ============================================================
# 10. Cross-validation
# ============================================================
if fft_lattice_mean > 0:
    discrepancy = abs(lattice_constant_za - fft_lattice_mean) / lattice_constant_za * 100
    print(f"\n=== CROSS-VALIDATION ===")
    print(f"  Zone-axes lattice constant: {lattice_constant_za:.4f} nm")
    print(f"  FFT lattice constant: {fft_lattice_mean:.4f} nm")
    print(f"  Discrepancy: {discrepancy:.1f}%")
    if discrepancy > 5:
        print(f"  WARNING: Discrepancy exceeds 5% threshold!")
else:
    discrepancy = -1

# Check NN consistency: NN peak should be ~a/sqrt(2)
expected_nn = lattice_constant_za / np.sqrt(2)
nn_consistency = abs(nn_mean - expected_nn) / expected_nn * 100
print(f"  Expected NN distance (a/√2): {expected_nn:.4f} nm")
print(f"  Measured NN distance: {nn_mean:.4f} nm")
print(f"  NN consistency: {nn_consistency:.1f}%")

# ============================================================
# 11. Spatial distribution analysis
# ============================================================
# Map NN distances spatially
nn_x = positions_nm[:, 0]
nn_y = positions_nm[:, 1]

# Intensity analysis for La/Li ordering
if amplitudes is not None:
    amp_mean = np.mean(amplitudes)
    amp_std = np.std(amplitudes)
    bright_mask = amplitudes > amp_mean + 0.5 * amp_std
    dim_mask = amplitudes < amp_mean - 0.5 * amp_std
    n_bright = np.sum(bright_mask)
    n_dim = np.sum(dim_mask)
    print(f"\nIntensity analysis:")
    print(f"  Mean amplitude: {amp_mean:.4f}")
    print(f"  Std amplitude: {amp_std:.4f}")
    print(f"  Bright columns (>mean+0.5*std): {n_bright}")
    print(f"  Dim columns (<mean-0.5*std): {n_dim}")
    print(f"  Ratio bright/dim: {n_bright/max(n_dim,1):.2f}")
else:
    amp_mean = 0
    amp_std = 0
    n_bright = 0
    n_dim = 0

# ============================================================
# 12. Visualizations
# ============================================================
fig, axes = plt.subplots(2, 3, figsize=(18, 12), dpi=100)

# (a) Original image with atom overlay
ax = axes[0, 0]
ax.imshow(image, cmap='gray')
ax.scatter(positions_refined[:, 0], positions_refined[:, 1], s=2, c='red', alpha=0.5)
ax.set_title(f'Atom Detection ({len(positions_refined)} columns)')
ax.axis('off')

# (b) FFT power spectrum with annotated peaks
ax = axes[0, 1]
vmin = np.percentile(log_power, 50)
vmax = np.percentile(log_power, 99.5)
ax.imshow(log_power, cmap='inferno', vmin=vmin, vmax=vmax,
          extent=[-center, center, -center, center])
if len(top_peaks) > 0:
    for i in range(min(8, len(top_peaks))):
        py, px = top_peaks[i]
        ax.plot(px - center, py - center, 'o', markersize=8, 
                markeredgecolor='cyan', markerfacecolor='none', markeredgewidth=1.5)
# Draw annular search region
theta = np.linspace(0, 2*np.pi, 100)
ax.plot(inner_radius * np.cos(theta), inner_radius * np.sin(theta), 'g--', alpha=0.5, linewidth=1)
ax.plot(outer_radius * np.cos(theta), outer_radius * np.sin(theta), 'g--', alpha=0.5, linewidth=1)
# Draw superlattice search region
ax.plot(sl_inner * np.cos(theta), sl_inner * np.sin(theta), 'y--', alpha=0.5, linewidth=1)
ax.plot(sl_outer * np.cos(theta), sl_outer * np.sin(theta), 'y--', alpha=0.5, linewidth=1)
ax.set_title('FFT (cyan=Bragg, green=search, yellow=superlattice)')
ax.set_xlim(-100, 100)
ax.set_ylim(-100, 100)

# (c) NN distance histogram
ax = axes[0, 2]
ax.hist(nn_distances, bins=50, range=(0.15, 0.5), color='steelblue', edgecolor='black', alpha=0.8)
ax.axvline(nn_mean, color='red', linestyle='--', label=f'Mean NN={nn_mean:.4f} nm')
ax.axvline(expected_nn, color='green', linestyle=':', label=f'a/√2={expected_nn:.4f} nm')
ax.axvline(lattice_constant_za, color='orange', linestyle='-', label=f'a={lattice_constant_za:.4f} nm')
ax.set_xlabel('Distance (nm)')
ax.set_ylabel('Count')
ax.set_title('Nearest-Neighbor Distance Distribution')
ax.legend(fontsize=8)

# (d) Spatial NN distance map
ax = axes[1, 0]
sc = ax.scatter(nn_x, nn_y, c=nn_distances, s=3, cmap='viridis', vmin=nn_mean-2*nn_std, vmax=nn_mean+2*nn_std)
plt.colorbar(sc, ax=ax, label='NN distance (nm)')
ax.set_title('Spatial NN Distance Map')
ax.set_xlabel('x (nm)')
ax.set_ylabel('y (nm)')
ax.set_aspect('equal')
ax.invert_yaxis()

# (e) Zone axes overlay
ax = axes[1, 1]
ax.imshow(img_clahe, cmap='gray')
# Show subset of positions
ax.scatter(positions_refined[:, 0], positions_refined[:, 1], s=1, c='cyan', alpha=0.3)
# Draw zone axes vectors from center of image
cx, cy = center, center
scale_factor = 100  # pixels for visualization
colors_za = ['red', 'blue', 'green', 'orange', 'purple', 'yellow']
for i, (dx, dy) in enumerate(zone_axes[:6]):
    dx_nm = dx * pixel_size_nm
    dy_nm = dy * pixel_size_nm
    mag = np.sqrt(dx_nm**2 + dy_nm**2)
    label_str = f'|v|={mag:.3f}nm'
    if any(fv[0] == i for fv in fundamental_vectors):
        label_str += ' [fund]'
        lw = 3
    elif any(dv[0] == i for dv in diagonal_vectors):
        label_str += ' [110]'
        lw = 2
    else:
        lw = 1
    c = colors_za[i % len(colors_za)]
    ax.arrow(cx, cy, dx*3, dy*3, head_width=5, head_length=3, fc=c, ec=c, linewidth=lw)
    ax.text(cx + dx*3.5, cy + dy*3.5, label_str, color=c, fontsize=7, fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.2', facecolor='black', alpha=0.5))
ax.set_title('Zone Axes Vectors')
ax.set_xlim(center-150, center+150)
ax.set_ylim(center+150, center-150)

# (f) Intensity map (if amplitudes available)
ax = axes[1, 2]
if amplitudes is not None:
    sc2 = ax.scatter(positions_nm[:, 0], positions_nm[:, 1], c=amplitudes, s=3, cmap='hot')
    plt.colorbar(sc2, ax=ax, label='Amplitude')
    ax.set_title('Atom Column Intensity Map')
else:
    ax.imshow(img_clahe, cmap='gray')
    ax.set_title('CLAHE Enhanced Image')
ax.set_xlabel('x (nm)')
ax.set_ylabel('y (nm)')
ax.set_aspect('equal')
ax.invert_yaxis()

plt.tight_layout()
plt.savefig('analysis_visualization.png', dpi=100, bbox_inches='tight')
plt.close()
print("\nVisualization saved to analysis_visualization.png")

# ============================================================
# Save arrays
# ============================================================
np.save('atom_positions_px.npy', positions_refined)
np.save('atom_positions_nm.npy', positions_nm)
np.save('nn_distances_nm.npy', nn_distances)
np.save('fft_power_spectrum.npy', log_power.astype(np.float32))

if amplitudes is not None:
    np.save('atom_amplitudes.npy', amplitudes)

# ============================================================
# JSON output
# ============================================================
results = {
    "analysis_type": "LLTO perovskite thin film lattice parameter analysis via combined FFT and real-space zone-axes approach",
    "extracted_features": {
        "lattice_constant_zone_axes_nm": round(float(lattice_constant_za), 4),
        "a_100_nm": round(float(a_100), 4),
        "a_010_nm": round(float(a_010), 4),
        "tetragonal_ratio": round(float(tetragonal_ratio), 4),
        "tetragonal_distortion_nm": round(float(tetragonal_diff), 4),
        "lattice_constant_fft_nm": round(float(fft_lattice_mean), 4),
        "fft_za_discrepancy_percent": round(float(discrepancy), 1),
        "nn_distance_mean_nm": round(float(nn_mean), 4),
        "nn_distance_std_nm": round(float(nn_std), 4),
        "nn_distance_median_nm": round(float(nn_median), 4),
        "expected_nn_from_lattice_nm": round(float(expected_nn), 4),
        "nn_consistency_percent": round(float(nn_consistency), 1),
        "nn_110_zone_axes_nm": round(float(nn_110_za), 4),
        "superlattice_detected": superlattice_detected,
        "num_atoms_detected": int(len(positions_refined)),
        "num_zone_axes_found": len(zone_axes),
        "num_fundamental_vectors": len(fundamental_vectors),
        "num_diagonal_vectors": len(diagonal_vectors),
        "substrate_boundary_detected": substrate_boundary,
        "pixel_size_nm": round(float(pixel_size_nm), 5),
        "fov_nm": float(fov_nm),
        "bright_columns_count": int(n_bright),
        "dim_columns_count": int(n_dim)
    },
    "quality_metrics": {
        "atom_detection_count": int(len(positions_refined)),
        "nn_distance_cv": round(float(nn_std / nn_mean * 100), 1) if nn_mean > 0 else 0,
        "fft_za_cross_validation_percent": round(float(discrepancy), 1),
        "nn_lattice_consistency_percent": round(float(nn_consistency), 1),
        "bottom_right_coverage_ratio": round(float(br_count / max(mean_other, 1)), 2)
    },
    "summary": f"LLTO perovskite thin film: lattice constant = {lattice_constant_za:.4f} nm from zone-axes [100]/[010] vectors (a_[100]={a_100:.4f}, a_[010]={a_010:.4f} nm), cross-validated by FFT ({fft_lattice_mean:.4f} nm, {discrepancy:.1f}% discrepancy). NN distance = {nn_mean:.4f} nm consistent with a/sqrt(2) = {expected_nn:.4f} nm ({nn_consistency:.1f}% deviation). {len(positions_refined)} atom columns detected. Superlattice reflections {'detected' if superlattice_detected else 'not detected'}. No substrate boundary found.",
    "saved_arrays": {
        "atom_positions_px.npy": {
            "description": f"Refined atom column positions in pixel coordinates (x,y), {len(positions_refined)} columns",
            "shape": list(positions_refined.shape),
            "dtype": str(positions_refined.dtype)
        },
        "atom_positions_nm.npy": {
            "description": f"Atom column positions in nm coordinates (x,y), {len(positions_nm)} columns",
            "shape": list(positions_nm.shape),
            "dtype": str(positions_nm.dtype)
        },
        "nn_distances_nm.npy": {
            "description": "Nearest-neighbor distances in nm for each atom column",
            "shape": list(nn_distances.shape),
            "dtype": str(nn_distances.dtype)
        },
        "fft_power_spectrum.npy": {
            "description": "Log-scaled FFT power spectrum of the preprocessed image",
            "shape": list(log_power.shape),
            "dtype": "float32"
        }
    }
}

if amplitudes is not None:
    results["saved_arrays"]["atom_amplitudes.npy"] = {
        "description": "Gaussian-fit amplitudes for each atom column",
        "shape": list(amplitudes.shape),
        "dtype": str(amplitudes.dtype)
    }

print(f"IMAGE_ANALYSIS_RESULTS_JSON:{json.dumps(results)}")
