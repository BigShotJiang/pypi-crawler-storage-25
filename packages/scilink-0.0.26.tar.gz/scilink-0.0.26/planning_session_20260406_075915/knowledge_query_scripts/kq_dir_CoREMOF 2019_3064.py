import json, glob, os
from pathlib import Path

directory = "/Users/maxim.ziatdinov/Code/SciLink/CoREMOF 2019"
json_files = sorted(glob.glob(os.path.join(directory, "*.json")))
# 12018 .json files
cif_files = sorted(glob.glob(os.path.join(directory, "*.cif")))
# 12018 .cif files

def read_json(filepath):
    with open(filepath, 'r') as f:
        return json.load(f)
def read_text(filepath):
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()

# Filter MOFs based on criteria
filtered_mofs = []
all_mofs = []

# Known MOF name patterns to search for
noble_gas_mofs = ['SBMOF-1', 'SBMOF', 'FMOF', 'NiMOF-74', 'MOF-74', 'HKUST', 'ZIF-8', 'SIFSIX', 'CuBTC', 'MIL-100', 'MIL-101', 'KAUST-7', 'CROFOUR']

matched_noble_gas_mofs = {}

for f in json_files:
    try:
        data = read_json(f)
    except Exception:
        continue
    
    name = data.get('name', '')
    pld = data.get('pld')
    lcd = data.get('lcd')
    vf = data.get('void_fraction')
    sa = data.get('surface_area_m2g')
    
    # Check noble gas MOF name matches
    for pattern in noble_gas_mofs:
        if pattern.upper() in name.upper():
            props = {
                'name': name,
                'pld': pld,
                'lcd': lcd,
                'void_fraction': vf,
                'surface_area_m2g': sa,
                'surface_area_m2cm3': data.get('surface_area_m2cm3')
            }
            if pattern not in matched_noble_gas_mofs:
                matched_noble_gas_mofs[pattern] = []
            matched_noble_gas_mofs[pattern].append(props)
    
    # Apply filters
    if pld is None or lcd is None or vf is None or sa is None:
        continue
    
    if (3.4 <= pld <= 5.0 and
        4.0 <= lcd <= 8.0 and
        0.3 <= vf <= 0.65 and
        300 <= sa <= 3000):
        filtered_mofs.append({
            'name': name,
            'pld': pld,
            'lcd': lcd,
            'void_fraction': vf,
            'surface_area_m2g': sa
        })

count_filtered = len(filtered_mofs)

# Build noble gas matches summary
noble_gas_summary = {}
for pattern, matches in matched_noble_gas_mofs.items():
    noble_gas_summary[pattern] = {
        'count': len(matches),
        'examples': matches[:5]  # limit to 5 examples per pattern
    }

answer = {
    'filtered_count': count_filtered,
    'filter_criteria': {
        'pld': '3.4-5.0 Angstroms',
        'lcd': '4.0-8.0 Angstroms',
        'void_fraction': '0.3-0.65',
        'surface_area_m2g': '300-3000'
    },
    'noble_gas_mof_matches': noble_gas_summary,
    'sample_filtered_mofs': filtered_mofs[:10]
}

noble_patterns_found = [p for p in noble_gas_mofs if p in matched_noble_gas_mofs]
summary = f"{count_filtered} MOFs pass all four filters (pld 3.4-5.0, lcd 4.0-8.0, void_fraction 0.3-0.65, surface_area 300-3000); noble gas separation MOF name patterns found: {noble_patterns_found if noble_patterns_found else 'none'} with counts {({p: len(m) for p, m in matched_noble_gas_mofs.items()} if matched_noble_gas_mofs else 'N/A')}."
print(json.dumps({"answer": answer, "summary": summary}))
