import json, glob, os
from pathlib import Path

directory = "/Users/maxim.ziatdinov/Code/SciLink/CoREMOF 2019"
json_files = sorted(glob.glob(os.path.join(directory, "*.json")))
# 12018 .json files
cif_files = sorted(glob.glob(os.path.join(directory, "*.cif")))
# 12018 .cif files

def read_json(filepath):
    with open(filepath, 'r') as f:
        return json.load(f)
def read_text(filepath):
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()

# Read a sample JSON file to inspect structure
sample_json = read_json(json_files[0])

# Get all field names and their types from the sample
field_info = {}
for key, value in sample_json.items():
    if isinstance(value, list):
        field_info[key] = f"list (len={len(value)})"
    elif isinstance(value, dict):
        field_info[key] = f"dict (keys={list(value.keys())})"
    elif value is None:
        field_info[key] = "null"
    else:
        field_info[key] = type(value).__name__

# Read a sample CIF file to inspect structure
sample_cif = read_text(cif_files[0])
cif_lines = sample_cif.strip().split('\n')
# Extract CIF field names (lines starting with '_')
cif_fields = [line.split()[0] for line in cif_lines if line.strip().startswith('_')]
cif_fields_unique = sorted(set(cif_fields))

# Check a few more JSON files to see if fields are consistent
spot_check_count = 5
all_keys_sets = []
for f in json_files[:spot_check_count]:
    d = read_json(f)
    all_keys_sets.append(set(d.keys()))

common_keys = set.intersection(*all_keys_sets)
all_keys = set.union(*all_keys_sets)

answer = {
    "file_types": {
        ".json": {
            "count": len(json_files),
            "description": "JSON files containing MOF metadata and properties",
            "fields": field_info,
            "field_names": sorted(sample_json.keys()),
            "consistent_across_samples": common_keys == all_keys
        },
        ".cif": {
            "count": len(cif_files),
            "description": "Crystallographic Information Files with atomic structure data",
            "sample_cif_fields": cif_fields_unique,
            "contains": ["cell parameters", "symmetry info", "atom sites (label, type_symbol, fract_x/y/z, U_iso, adp_type, occupancy)"]
        }
    },
    "total_files": len(json_files) + len(cif_files),
    "total_records": len(json_files),
    "sample_json_filename": os.path.basename(json_files[0]),
    "sample_cif_filename": os.path.basename(cif_files[0])
}

summary = (f"The directory contains {len(json_files)} paired .json/.cif files (24036 total files, 12018 MOF records). "
           f"JSON files have {len(field_info)} fields: {sorted(sample_json.keys())}, "
           f"including id, name, lcd, pld, void_fraction, surface_area_m2g, surface_area_m2cm3, isotherms, adsorbates, mofid, mofkey, etc. "
           f"CIF files contain crystallographic structure data with cell parameters and atomic coordinates.")
print(json.dumps({"answer": answer, "summary": summary}))
