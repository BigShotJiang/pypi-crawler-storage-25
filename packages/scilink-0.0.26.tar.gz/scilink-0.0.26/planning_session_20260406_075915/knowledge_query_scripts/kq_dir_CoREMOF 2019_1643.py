import json, glob, os
from pathlib import Path

directory = "/Users/maxim.ziatdinov/Code/SciLink/CoREMOF 2019"
json_files = sorted(glob.glob(os.path.join(directory, "*.json")))
# 12018 .json files
cif_files = sorted(glob.glob(os.path.join(directory, "*.cif")))
# 12018 .cif files

def read_json(filepath):
    with open(filepath, 'r') as f:
        return json.load(f)
def read_text(filepath):
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()

refcodes = ['KAXQIL', 'FIQCEN', 'VOGTIV', 'OFERUN', 'DOTSOV', 'FIQGAZ', 'EDUSIF', 'MOYYEF', 'XOBBAQ', 'MIGKEG', 'MIGKIK']
refcodes_lower = [r.lower() for r in refcodes]

matches = []
for jf in json_files:
    basename = os.path.basename(jf).lower()
    for rc in refcodes_lower:
        if rc in basename:
            data = read_json(jf)
            matches.append({
                'name': data.get('name', os.path.basename(jf)),
                'matched_refcode': rc.upper(),
                'pld': data.get('pld'),
                'lcd': data.get('lcd'),
                'void_fraction': data.get('void_fraction'),
                'surface_area_m2g': data.get('surface_area_m2g')
            })
            break

answer = matches
if matches:
    summary = f"Found {len(matches)} MOF(s) matching the given CSD refcodes: {', '.join(m['name'] + ' (' + m['matched_refcode'] + ')' for m in matches)} with their pld, lcd, void_fraction, and surface_area_m2g."
else:
    summary = "No MOFs were found matching any of the given CSD refcodes."
print(json.dumps({"answer": answer, "summary": summary}))
