import json, glob, os
from pathlib import Path

directory = "/Users/maxim.ziatdinov/Code/SciLink/CoREMOF 2019"
json_files = sorted(glob.glob(os.path.join(directory, "*.json")))
# 12018 .json files
cif_files = sorted(glob.glob(os.path.join(directory, "*.cif")))
# 12018 .cif files

def read_json(filepath):
    with open(filepath, 'r') as f:
        return json.load(f)
def read_text(filepath):
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()

import numpy as np
from collections import Counter

# Collect numeric fields and adsorbate info
lcd_vals = []
pld_vals = []
vf_vals = []
sa_m2g_vals = []
sa_m2cm3_vals = []
adsorbate_counter = Counter()
mofs_with_adsorbate = Counter()
example_isotherms = []
needed_examples = 3

for f in json_files:
    data = read_json(f)
    if data.get('lcd') is not None:
        lcd_vals.append(data['lcd'])
    if data.get('pld') is not None:
        pld_vals.append(data['pld'])
    if data.get('void_fraction') is not None:
        vf_vals.append(data['void_fraction'])
    if data.get('surface_area_m2g') is not None:
        sa_m2g_vals.append(data['surface_area_m2g'])
    if data.get('surface_area_m2cm3') is not None:
        sa_m2cm3_vals.append(data['surface_area_m2cm3'])
    # Adsorbates
    ads = data.get('adsorbates', []) or []
    seen_names = set()
    for a in ads:
        name = a.get('name', 'unknown')
        adsorbate_counter[name] += 1
        seen_names.add(name)
    for name in seen_names:
        mofs_with_adsorbate[name] += 1
    # Example isotherms
    if len(example_isotherms) < needed_examples:
        isos = data.get('isotherms', []) or []
        if isos:
            example_isotherms.append({'mof_name': data.get('name'), 'isotherm': isos[0]})

def stats(vals, name):
    a = np.array(vals)
    return {
        'field': name,
        'count': len(a),
        'min': float(np.min(a)),
        'max': float(np.max(a)),
        'mean': float(np.mean(a)),
        'median': float(np.median(a)),
        'std': float(np.std(a))
    }

dist_stats = [
    stats(lcd_vals, 'lcd'),
    stats(pld_vals, 'pld'),
    stats(vf_vals, 'void_fraction'),
    stats(sa_m2g_vals, 'surface_area_m2g'),
    stats(sa_m2cm3_vals, 'surface_area_m2cm3')
]

adsorbate_summary = {name: {'total_occurrences': adsorbate_counter[name], 'unique_mofs': mofs_with_adsorbate[name]} for name in sorted(mofs_with_adsorbate.keys(), key=lambda x: -mofs_with_adsorbate[x])}

answer = {
    'distribution_statistics': dist_stats,
    'adsorbates': adsorbate_summary,
    'example_isotherms': example_isotherms
}

# Build summary
stats_summary_parts = []
for s in dist_stats:
    stats_summary_parts.append(f"{s['field']}: min={s['min']:.3f}, max={s['max']:.3f}, mean={s['mean']:.3f}, median={s['median']:.3f}, std={s['std']:.3f} (n={s['count']})")
ads_parts = [f"{name}: {info['unique_mofs']} MOFs" for name, info in list(adsorbate_summary.items())[:10]]
summary = f"Distribution stats for 5 properties across ~12K MOFs: {'; '.join(stats_summary_parts)}. Unique adsorbates ({len(adsorbate_summary)} total): {'; '.join(ads_parts)}. {len(example_isotherms)} example isotherms included."
print(json.dumps({"answer": answer, "summary": summary}))
