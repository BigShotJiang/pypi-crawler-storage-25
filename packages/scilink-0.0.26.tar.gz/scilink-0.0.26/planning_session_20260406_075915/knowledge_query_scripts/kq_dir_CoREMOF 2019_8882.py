import json, glob, os
from pathlib import Path

directory = "/Users/maxim.ziatdinov/Code/SciLink/CoREMOF 2019"
json_files = sorted(glob.glob(os.path.join(directory, "*.json")))
# 12018 .json files
cif_files = sorted(glob.glob(os.path.join(directory, "*.cif")))
# 12018 .cif files

def read_json(filepath):
    with open(filepath, 'r') as f:
        return json.load(f)
def read_text(filepath):
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()

# Load all JSON data and apply filters
filtered = []
for f in json_files:
    d = read_json(f)
    pld = d.get('pld')
    lcd = d.get('lcd')
    vf = d.get('void_fraction')
    sa = d.get('surface_area_m2g')
    if pld is not None and lcd is not None and vf is not None and sa is not None:
        if 3.0 <= pld <= 7.0 and 3.5 <= lcd <= 12.0 and 0.25 <= vf <= 0.75 and sa > 200:
            filtered.append(d)

count = len(filtered)

# Distribution of pld in bins
import math
pld_bins = {}
pld_bin_edges = [3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 6.5, 7.0]
for d in filtered:
    pld_val = d['pld']
    placed = False
    for i in range(len(pld_bin_edges) - 1):
        if pld_bin_edges[i] <= pld_val < pld_bin_edges[i+1]:
            label = f"{pld_bin_edges[i]:.1f}-{pld_bin_edges[i+1]:.1f}"
            pld_bins[label] = pld_bins.get(label, 0) + 1
            placed = True
            break
    if not placed and pld_val == 7.0:
        label = f"6.5-7.0"
        pld_bins[label] = pld_bins.get(label, 0) + 1

# Distribution of lcd in bins
lcd_bins = {}
lcd_bin_edges = [3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5, 10.5, 11.5, 12.0]
for d in filtered:
    lcd_val = d['lcd']
    placed = False
    for i in range(len(lcd_bin_edges) - 1):
        if lcd_bin_edges[i] <= lcd_val < lcd_bin_edges[i+1]:
            label = f"{lcd_bin_edges[i]:.1f}-{lcd_bin_edges[i+1]:.1f}"
            lcd_bins[label] = lcd_bins.get(label, 0) + 1
            placed = True
            break
    if not placed and lcd_val == 12.0:
        label = f"11.5-12.0"
        lcd_bins[label] = lcd_bins.get(label, 0) + 1

# Top 20 by surface_area_m2g
filtered_sorted = sorted(filtered, key=lambda x: x['surface_area_m2g'], reverse=True)
top20 = []
for d in filtered_sorted[:20]:
    top20.append({
        'name': d.get('name'),
        'lcd': d.get('lcd'),
        'pld': d.get('pld'),
        'void_fraction': d.get('void_fraction'),
        'surface_area_m2g': d.get('surface_area_m2g')
    })

answer = {
    'filtered_count': count,
    'pld_distribution': dict(sorted(pld_bins.items())),
    'lcd_distribution': dict(sorted(lcd_bins.items())),
    'top_20_by_surface_area': top20
}
summary = f"{count} MOFs pass the filter (pld 3-7, lcd 3.5-12, void_fraction 0.25-0.75, surface_area_m2g>200); top MOF by surface area is {top20[0]['name'] if top20 else 'N/A'} with {top20[0]['surface_area_m2g'] if top20 else 'N/A'} m2/g."
print(json.dumps({"answer": answer, "summary": summary}))
