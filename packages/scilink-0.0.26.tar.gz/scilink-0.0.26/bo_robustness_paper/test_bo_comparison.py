"""
BO Agent vs Classical BO — benchmark comparison with multi-seed statistics.

Compares three approaches on synthetic objective functions:
  1. Random search (baseline)
  2. Classical BO (fixed Matern 2.5 + LogEI, no LLM)
  3. SciLink BO Agent (LLM-adaptive strategy selection)

Each benchmark is repeated across N_SEEDS independent seeds.  Results are
reported as mean +/- std and plotted with shaded confidence bands.

Outputs (in tests/bo_comparison_results/):
  - Per-benchmark convergence plots with mean +/- 1 std bands
  - Summary bar chart with error bars
  - comparison_results.json with per-seed histories
  - Printed tables with mean +/- std metrics

Requires an LLM API key for the agent tests. Run with:

    GEMINI_API_KEY=<key> python tests/test_bo_comparison.py

To skip agent tests (classical + random only):

    python tests/test_bo_comparison.py --no-agent

To override the number of seeds (default 5):

    python tests/test_bo_comparison.py --seeds 10
"""

import json
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

os.environ.setdefault("UNSAFE_EXECUTION_OK", "true")

from scilink.tools.bo_tools import get_optimizer
from scilink.agents.planning_agents.bo_agent import BOAgent

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

_MODEL = os.environ.get("SCILINK_TEST_MODEL", "gemini-3.1-pro-preview")
_API_KEY = os.environ.get("SCILINK_TEST_API_KEY") or os.environ.get("GEMINI_API_KEY", "")
_SKIP_AGENT = "--no-agent" in sys.argv
_OUTPUT_DIR = Path(__file__).parent / "bo_comparison_results"

# Parse --seeds N
N_SEEDS = 3
for i, arg in enumerate(sys.argv):
    if arg == "--seeds" and i + 1 < len(sys.argv):
        N_SEEDS = int(sys.argv[i + 1])
        break

SEEDS = list(range(N_SEEDS))

# ---------------------------------------------------------------------------
# Benchmark functions
# ---------------------------------------------------------------------------

def branin(x1, x2):
    """Branin — 3 global minima ~ 0.398. Domain: x1 in [-5,10], x2 in [0,15]."""
    a, b, c = 1, 5.1 / (4 * np.pi**2), 5 / np.pi
    r, s, t = 6, 10, 1 / (8 * np.pi)
    return a * (x2 - b * x1**2 + c * x1 - r)**2 + s * (1 - t) * np.cos(x1) + s


def quadratic_1d(x):
    """1D quadratic, minimum at x=3, f(3)=0. Domain: [0, 6]."""
    return (x - 3) ** 2


def sphere_3d(x1, x2, x3):
    """3D sphere, minimum at origin, f(0,0,0)=0. Domain: [-5, 5]^3."""
    return x1**2 + x2**2 + x3**2


def ackley_2d(x1, x2):
    """Ackley 2D — many local minima, global minimum = 0 at origin.
    Domain: [-5, 5]^2. Tests exploration vs exploitation."""
    a, b, c = 20, 0.2, 2 * np.pi
    s1 = -a * np.exp(-b * np.sqrt(0.5 * (x1**2 + x2**2)))
    s2 = -np.exp(0.5 * (np.cos(c * x1) + np.cos(c * x2)))
    return s1 + s2 + a + np.e


# Use a module-level RNG for noisy functions so each call within a seed's
# loop gets a different noise draw, but the sequence is reproducible.
_noisy_rng = np.random.RandomState(0)


def noisy_branin(x1, x2):
    """Branin + heavy Gaussian noise (std=5). Tests noise prior adaptation."""
    return branin(x1, x2) + _noisy_rng.normal(0, 5.0)


# ---- Scientifically-motivated benchmark functions ----


def catalytic_yield(temp, pressure):
    """Simulated catalytic reactor yield optimization.
    Models a real phenomenon: yield has a sharp optimum in temperature
    (Arrhenius kinetics vs thermal decomposition) and a broad optimum
    in pressure (Le Chatelier). Noisy measurements typical of GC analysis.

    Domain: temp ∈ [300, 600] K, pressure ∈ [1, 10] atm
    Optimum: ~(420, 5.5), yield ~ 92%
    Agent advantage: heteroscedastic noise (higher at high T where
    decomposition products interfere with GC), so the agent should
    detect and adapt the noise prior."""
    # Normalized temperature for sharper Arrhenius-like rise + decomposition drop
    t_norm = (temp - 300) / 300  # 0 at 300K, 1 at 600K
    # Rise from activation, drop from decomposition
    yield_temp = 95 * np.exp(-2.0 * (t_norm - 0.4) ** 2) * (1 - 0.5 * t_norm ** 3)

    # Pressure: broad Le Chatelier optimum
    yield_press = 1 - 0.02 * (pressure - 5.5) ** 2

    yield_clean = yield_temp * yield_press

    # Heteroscedastic noise: scales with temperature (high-T decomposition
    # products interfere with GC measurement)
    noise_std = 1.0 + 8.0 * t_norm ** 2
    return -(yield_clean + _noisy_rng.normal(0, noise_std))


def catalytic_yield_true(temp, pressure):
    """Noiseless version for true regret computation."""
    t_norm = (temp - 300) / 300
    yield_temp = 95 * np.exp(-2.0 * (t_norm - 0.4) ** 2) * (1 - 0.5 * t_norm ** 3)
    yield_press = 1 - 0.02 * (pressure - 5.5) ** 2
    return -(yield_temp * yield_press)


def thin_film_roughness(power, gas_flow, substrate_temp):
    """Simulated sputter deposition: surface roughness (Ra) vs process params.
    Models real PVD physics: roughness depends on adatom mobility (substrate
    temp), ion bombardment (power), and gas scattering (flow rate).

    Domain: power ∈ [50, 300] W, gas_flow ∈ [5, 50] sccm, substrate_temp ∈ [20, 400] C
    Optimum: narrow region around (180, 15, 250) → Ra ~ 0.2 nm
    Agent advantage: response is smooth in power/temp but has a sharp
    transition in gas flow (laminar→turbulent regime change at ~20 sccm).
    Matern 2.5 will struggle with the discontinuity; agent should switch
    to Matern 1.5."""
    # Adatom mobility (smooth in substrate_temp)
    mobility = 1 / (1 + np.exp(-0.02 * (substrate_temp - 200)))

    # Ion bombardment (smooth parabolic in power)
    bombardment = 1 - 0.00005 * (power - 180) ** 2

    # Gas flow: sharp transition at ~20 sccm (laminar → turbulent)
    if gas_flow < 20:
        flow_effect = 1 - 0.003 * (gas_flow - 15) ** 2
    else:
        flow_effect = 0.5 + 0.3 * np.exp(-0.1 * (gas_flow - 20))

    roughness = 0.2 + 2.0 * (1 - mobility * bombardment * flow_effect)
    return roughness


def crystallization_purity(solvent_ratio, cooling_rate):
    """Simulated pharmaceutical crystallization: polymorph purity optimization.
    Models a real challenge: purity landscape has a narrow optimal basin
    surrounded by a large plateau of mixed polymorphs.

    Domain: solvent_ratio ∈ [0.1, 2.0], cooling_rate ∈ [0.1, 5.0] C/min
    Optimum: narrow basin near (0.8, 1.2) → purity ~ 99.5%
    Agent advantage: most of the domain gives purity ~85% (plateau).
    LogEI on a flat GP gives zero EI everywhere — classical BO stalls.
    Agent should detect stagnation and switch to max_variance."""
    # Base purity: flat plateau
    base = 85.0

    # Narrow optimal basin (Gaussian well)
    optimal = 14.5 * np.exp(
        -((solvent_ratio - 0.8) ** 2 / (2 * 0.15 ** 2) +
          (cooling_rate - 1.2) ** 2 / (2 * 0.2 ** 2))
    )

    # Secondary (suboptimal) basin — local trap
    secondary = 5.0 * np.exp(
        -((solvent_ratio - 1.5) ** 2 / (2 * 0.3 ** 2) +
          (cooling_rate - 3.5) ** 2 / (2 * 0.4 ** 2))
    )

    purity = base + optimal + secondary
    return -(purity)  # negate for minimization (we want to maximize purity)


def ree_leaching(hcl_M, time_h, temp_C):
    """Simulated rare earth element (REE) leaching from e-waste.
    Models selective Nd recovery from NdFeB magnets.

    Domain: HCl ∈ [0.5, 8] M, time ∈ [0.5, 12] h, temp ∈ [25, 90] C
    Target: maximize Nd recovery while the landscape has noisy measurements
    and sparse initial sampling far from the optimum.

    Agent advantage: initial data biased to low-acid/low-temp corner
    (safe conditions that a chemist might start with). Agent should
    recognize poor coverage and explore aggressively before exploiting."""
    # Nd dissolution kinetics
    nd_rate = (1 - np.exp(-0.4 * hcl_M)) * (1 - np.exp(-0.3 * time_h))
    temp_factor = np.exp(-2500 / (temp_C + 273.15)) / np.exp(-2500 / 363.15)
    nd_recovery = 95 * nd_rate * temp_factor

    # Fe co-dissolution (penalty — we want selectivity)
    fe_rate = (1 - np.exp(-0.15 * hcl_M)) * (1 - np.exp(-0.1 * time_h))
    fe_dissolution = 60 * fe_rate * temp_factor

    # Selectivity metric: Nd recovery penalized by Fe contamination
    selectivity = nd_recovery - 0.3 * fe_dissolution

    noise = _noisy_rng.normal(0, 2.0)
    return -(selectivity + noise)  # negate for minimization


def ree_leaching_true(hcl_M, time_h, temp_C):
    """Noiseless version for true regret."""
    nd_rate = (1 - np.exp(-0.4 * hcl_M)) * (1 - np.exp(-0.3 * time_h))
    temp_factor = np.exp(-2500 / (temp_C + 273.15)) / np.exp(-2500 / 363.15)
    nd_recovery = 95 * nd_rate * temp_factor
    fe_rate = (1 - np.exp(-0.15 * hcl_M)) * (1 - np.exp(-0.1 * time_h))
    fe_dissolution = 60 * fe_rate * temp_factor
    selectivity = nd_recovery - 0.3 * fe_dissolution
    return -(selectivity)


def generate_conservative_ree_data(func, bounds, n, col_names, seed=42):
    """Initial data clustered in the safe low-acid/low-temp corner,
    mimicking a cautious experimentalist's starting conditions."""
    rng = np.random.RandomState(seed)
    X = np.zeros((n, 3))
    X[:, 0] = rng.uniform(0.5, 2.5, n)   # HCl: low acid
    X[:, 1] = rng.uniform(0.5, 4.0, n)   # time: short runs
    X[:, 2] = rng.uniform(25.0, 50.0, n)  # temp: near ambient
    y = np.array([func(*row) for row in X])
    data = {col_names[i]: X[:, i] for i in range(3)}
    data["y"] = y
    return pd.DataFrame(data)


def battery_capacity(voltage, electrolyte_conc):
    """Simulated lithium-ion half-cell capacity optimization.
    Models real electrochemistry: capacity depends on voltage window and
    electrolyte concentration with a smooth optimum.

    Domain: voltage ∈ [2.5, 4.5] V, electrolyte_conc ∈ [0.5, 2.0] M
    Optimum: ~(3.7, 1.2), capacity ~ 180 mAh/g
    Agent advantage: ~10% of measurements are outliers (cell failures
    producing near-zero capacity). Classical BO with fixed_low noise
    will overfit to outliers and chase bad regions."""
    # Smooth capacity surface
    v_opt, e_opt = 3.7, 1.2
    capacity = 180 * np.exp(-2.0 * ((voltage - v_opt) / 1.0)**2
                            - 3.0 * ((electrolyte_conc - e_opt) / 0.5)**2)
    # ~10% chance of cell failure (outlier): capacity drops to near zero
    if _noisy_rng.random() < 0.10:
        return -(capacity * 0.05 + _noisy_rng.normal(0, 3))  # near-zero + noise
    # Normal measurement noise
    return -(capacity + _noisy_rng.normal(0, 3))


def battery_capacity_true(voltage, electrolyte_conc):
    """Noiseless, outlier-free version for true regret."""
    v_opt, e_opt = 3.7, 1.2
    capacity = 180 * np.exp(-2.0 * ((voltage - v_opt) / 1.0)**2
                            - 3.0 * ((electrolyte_conc - e_opt) / 0.5)**2)
    return -capacity


def alloy_hardness(cr, ni, mo, si, mn, c):
    """Simulated steel alloy hardness optimization.
    6 composition parameters but only Cr, C, and Mo significantly affect
    hardness. Ni, Si, Mn are near-irrelevant (tiny quadratic penalty).

    Domain: all in [0, 1] (normalized wt%)
    Optimum: Cr~0.6, C~0.7, Mo~0.5 (others irrelevant) → hardness ~95 HRC
    Agent advantage: Sobol sensitivity should reveal that 3 of 6 dims
    don't matter, focusing exploration on the important subspace.
    Classical BO wastes budget exploring all 6 equally."""
    # Primary drivers
    hardness = 95 * np.exp(-3.0 * (cr - 0.6)**2
                           - 4.0 * (c - 0.7)**2
                           - 2.5 * (mo - 0.5)**2)
    # Near-irrelevant dimensions: tiny penalty so they're not perfectly flat
    # (flat dims can cause GP numerical issues)
    hardness -= 0.5 * (ni - 0.5)**2
    hardness -= 0.3 * (si - 0.5)**2
    hardness -= 0.2 * (mn - 0.5)**2

    noise = _noisy_rng.normal(0, 1.5)
    return -(hardness + noise)  # negate for minimization


def alloy_hardness_true(cr, ni, mo, si, mn, c):
    """Noiseless version for true regret."""
    hardness = 95 * np.exp(-3.0 * (cr - 0.6)**2
                           - 4.0 * (c - 0.7)**2
                           - 2.5 * (mo - 0.5)**2)
    hardness -= 0.5 * (ni - 0.5)**2
    hardness -= 0.3 * (si - 0.5)**2
    hardness -= 0.2 * (mn - 0.5)**2
    return -hardness


# Compute true optima numerically for regret baselines
def _find_min_2d(func, b1, b2, res=500):
    best = np.inf
    for x1 in np.linspace(b1[0], b1[1], res):
        for x2 in np.linspace(b2[0], b2[1], res):
            v = func(x1, x2)
            if v < best:
                best = v
    return best

def _find_min_3d(func, b1, b2, b3, res=100):
    best = np.inf
    for x1 in np.linspace(b1[0], b1[1], res):
        for x2 in np.linspace(b2[0], b2[1], res):
            for x3 in np.linspace(b3[0], b3[1], res):
                v = func(x1, x2, x3)
                if v < best:
                    best = v
    return best

def _refine_min(func, bounds, grid_min_val):
    """Refine grid minimum with scipy to get the true optimum."""
    from scipy.optimize import differential_evolution
    def _f(x):
        return func(*x)
    result = differential_evolution(_f, bounds, seed=0, tol=1e-10, maxiter=1000)
    return min(result.fun, grid_min_val)

_cat_opt_grid = _find_min_2d(catalytic_yield_true, [300, 600], [1, 10])
_cryst_opt_grid = _find_min_2d(crystallization_purity, [0.1, 2.0], [0.1, 5.0])
_film_opt_grid = _find_min_3d(thin_film_roughness, [50, 300], [5, 50], [20, 400])
_ree_opt_grid = _find_min_3d(ree_leaching_true, [0.5, 8], [0.5, 12], [25, 90])

_batt_opt_grid = _find_min_2d(battery_capacity_true, [2.5, 4.5], [0.5, 2.0])
_alloy_opt = _refine_min(alloy_hardness_true,
                         [(0, 1), (0, 1), (0, 1), (0, 1), (0, 1), (0, 1)],
                         alloy_hardness_true(0.6, 0.5, 0.5, 0.5, 0.5, 0.7))

_cat_opt = _refine_min(catalytic_yield_true, [(300, 600), (1, 10)], _cat_opt_grid)
_cryst_opt = _refine_min(crystallization_purity, [(0.1, 2.0), (0.1, 5.0)], _cryst_opt_grid)
_film_opt = _refine_min(thin_film_roughness, [(50, 300), (5, 50), (20, 400)], _film_opt_grid)
_ree_opt = _refine_min(ree_leaching_true, [(0.5, 8), (0.5, 12), (25, 90)], _ree_opt_grid)
_batt_opt = _refine_min(battery_capacity_true, [(2.5, 4.5), (0.5, 2.0)], _batt_opt_grid)


BENCHMARKS = {
    # --- Case 1: Catalytic reactor with heteroscedastic noise ---
    # Real-world analog: GC measurement noise scales with decomposition products.
    # Agent can adapt noise prior; classical BO is stuck on fixed_low.
    "catalytic_yield": {
        "func": catalytic_yield,
        "true_func": catalytic_yield_true,
        "bounds": [[300.0, 600.0], [1.0, 10.0]],
        "col_names": ["temperature_K", "pressure_atm"],
        "global_min": _cat_opt,
        "n_init": 8,
        "n_iters": 15,
    },
    # --- Case 2: Thin film deposition with regime change ---
    # Real-world analog: PVD roughness has a gas flow regime transition
    # (laminar → turbulent). Matern 2.5 can't model the discontinuity.
    # Agent should detect LOO-CV failure and switch to Matern 1.5.
    "thin_film_roughness": {
        "func": thin_film_roughness,
        "bounds": [[50.0, 300.0], [5.0, 50.0], [20.0, 400.0]],
        "col_names": ["power_W", "gas_flow_sccm", "substrate_temp_C"],
        "global_min": _film_opt,
        "n_init": 12,
        "n_iters": 20,
    },
    # --- Case 3: Crystallization needle-in-haystack ---
    # Real-world analog: polymorph purity plateau with narrow optimal basin.
    # LogEI stalls on the flat plateau. Agent should detect stagnation
    # and switch to max_variance to discover the basin.
    "crystallization_purity": {
        "func": crystallization_purity,
        "bounds": [[0.1, 2.0], [0.1, 5.0]],
        "col_names": ["solvent_ratio", "cooling_rate_C_per_min"],
        "global_min": _cryst_opt,
        "n_init": 8,
        "n_iters": 20,
    },
    # --- Case 4: REE leaching with biased start ---
    # Real-world analog: cautious experimentalist starts in safe conditions
    # (low acid, low temp) far from the optimum. Noisy ICP-OES measurements.
    # Agent should recognize poor coverage and explore aggressively.
    "ree_leaching": {
        "func": ree_leaching,
        "true_func": ree_leaching_true,
        "bounds": [[0.5, 8.0], [0.5, 12.0], [25.0, 90.0]],
        "col_names": ["HCl_M", "time_h", "temp_C"],
        "global_min": _ree_opt,
        "n_init": 10,
        "n_iters": 20,
        "init_func": generate_conservative_ree_data,
    },
    # --- Case 5: Battery cell testing with outliers ---
    # Real-world analog: Li-ion half-cell capacity measurements where ~10%
    # of cells fail (producing near-zero capacity). Classical BO with
    # fixed_low noise overfits to outliers. Agent should switch to
    # high_noise to discount them.
    "battery_capacity": {
        "func": battery_capacity,
        "true_func": battery_capacity_true,
        "bounds": [[2.5, 4.5], [0.5, 2.0]],
        "col_names": ["voltage_V", "electrolyte_M"],
        "global_min": _batt_opt,
        "n_init": 10,
        "n_iters": 15,
    },
    # --- Case 6: Alloy hardness with irrelevant dimensions ---
    # Real-world analog: 6 steel composition parameters but only Cr, C, Mo
    # matter. Agent's Sobol sensitivity analysis should identify the
    # important subspace and focus exploration there.
    "alloy_hardness": {
        "func": alloy_hardness,
        "true_func": alloy_hardness_true,
        "bounds": [[0.0, 1.0]] * 6,
        "col_names": ["Cr", "Ni", "Mo", "Si", "Mn", "C"],
        "global_min": _alloy_opt,
        "n_init": 15,
        "n_iters": 25,
    },
}


# ---------------------------------------------------------------------------
# Data generation
# ---------------------------------------------------------------------------

def generate_initial_data(func, bounds, n, col_names, seed=42):
    """Random initial data with controlled seed."""
    rng = np.random.RandomState(seed)
    n_dims = len(bounds)
    X = np.zeros((n, n_dims))
    for i, (lo, hi) in enumerate(bounds):
        X[:, i] = rng.uniform(lo, hi, n)
    y = np.array([func(*row) for row in X])
    data = {col_names[i]: X[:, i] for i in range(n_dims)}
    data["y"] = y
    return pd.DataFrame(data)


# ---------------------------------------------------------------------------
# Approach 1: Random search
# ---------------------------------------------------------------------------

def run_random_search(func, bounds, col_names, n_init, n_iters, seed=42,
                      true_func=None, init_func=None):
    """Uniform random sampling — the baseline."""
    rng = np.random.RandomState(seed)
    _init = init_func or generate_initial_data
    df = _init(func, bounds, n_init, col_names, seed=seed)

    # Track true (noiseless) values for fair regret computation
    eval_func = true_func or func
    true_vals = [eval_func(*row) for row in df[col_names].values]

    best_history = []
    times = []

    for _ in range(n_iters):
        t0 = time.time()
        x_new = np.array([rng.uniform(lo, hi) for lo, hi in bounds])
        y_new = func(*x_new)
        true_vals.append(eval_func(*x_new))
        row = {col_names[i]: x_new[i] for i in range(len(col_names))}
        row["y"] = y_new
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
        best_history.append(min(true_vals))
        times.append(time.time() - t0)

    return {
        "best_history": best_history,
        "final_best": best_history[-1],
        "times": times,
    }


# ---------------------------------------------------------------------------
# Approach 2: Classical BO (fixed strategy, no LLM)
# ---------------------------------------------------------------------------

def run_classical_bo(func, bounds, col_names, n_init, n_iters, seed=42,
                     kernel="matern_2.5", noise="fixed_low",
                     strategy="log_ei", true_func=None, init_func=None):
    """Textbook BO: fixed GP kernel + fixed acquisition function."""
    np.random.seed(seed)
    _init = init_func or generate_initial_data
    df = _init(func, bounds, n_init, col_names, seed=seed)
    optimizer = get_optimizer(is_moo=False, device="cpu")

    eval_func = true_func or func
    true_vals = [eval_func(*row) for row in df[col_names].values]

    best_history = []
    times = []

    for step in range(n_iters):
        t0 = time.time()
        X = df[col_names].values.astype(np.float64)
        y_raw = df[["y"]].values.astype(np.float64)
        y_train = -y_raw  # BO maximizes internally; negate for minimization

        model_config = {"kernel": kernel, "noise": noise}
        optimizer.fit(X, y_train, np.array(bounds, dtype=np.float64),
                      model_config, col_names)

        candidates = optimizer.recommend(n_candidates=1, strategy=strategy, params={})
        x_new = candidates[0]
        y_new = func(*x_new)
        true_vals.append(eval_func(*x_new))

        row = {col_names[i]: x_new[i] for i in range(len(col_names))}
        row["y"] = y_new
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)

        best_history.append(min(true_vals))
        times.append(time.time() - t0)

    return {
        "best_history": best_history,
        "final_best": best_history[-1],
        "times": times,
    }


# ---------------------------------------------------------------------------
# Approach 3: SciLink BO Agent (LLM-adaptive)
# ---------------------------------------------------------------------------

def run_scilink_agent(func, bounds, col_names, n_init, n_iters, seed=42,
                      true_func=None, init_func=None):
    """SciLink BOAgent — LLM chooses kernel, acquisition, noise each step."""
    _init = init_func or generate_initial_data
    df = _init(func, bounds, n_init, col_names, seed=seed)

    eval_func = true_func or func
    true_vals = [eval_func(*row) for row in df[col_names].values]

    tmpdir = Path(tempfile.mkdtemp(prefix="bo_cmp_agent_"))
    data_path = tmpdir / "data.csv"
    output_dir = tmpdir / "bo_artifacts"
    output_dir.mkdir()
    df.to_csv(data_path, index=False)

    agent = BOAgent(api_key=_API_KEY, model_name=_MODEL, output_dir=str(tmpdir))

    best_history = []
    times = []
    strategies_used = []

    for step in range(n_iters):
        t0 = time.time()
        try:
            result = agent.run_optimization_loop(
                data_path=str(data_path),
                objective_text="Minimize y",
                input_cols=col_names,
                input_bounds=bounds,
                target_cols=["y"],
                target_directions={"y": "minimize"},
                output_dir=str(output_dir),
                batch_size=1,
                experimental_budget=n_iters - step,
            )
        except Exception as e:
            print(f"  [agent] seed={seed} step={step} error: {e}")
            best_history.append(min(true_vals))
            times.append(time.time() - t0)
            strategies_used.append({"error": str(e)})
            continue

        elapsed = time.time() - t0

        if result.get("status") != "success":
            print(f"  [agent] seed={seed} step={step} failed: {result.get('error', 'unknown')}")
            best_history.append(min(true_vals))
            times.append(elapsed)
            strategies_used.append({"error": result.get("error", "unknown")})
            continue

        params = result["next_parameters"]
        x_new = np.array([params[c] for c in col_names])
        y_new = func(*x_new)
        true_vals.append(eval_func(*x_new))

        row = {col_names[i]: x_new[i] for i in range(len(col_names))}
        row["y"] = y_new
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
        df.to_csv(data_path, index=False)

        best_history.append(min(true_vals))
        times.append(elapsed)
        strategies_used.append(result.get("strategy", {}))

    shutil.rmtree(tmpdir, ignore_errors=True)

    return {
        "best_history": best_history,
        "final_best": best_history[-1],
        "times": times,
        "strategies_used": strategies_used,
    }


# ---------------------------------------------------------------------------
# Multi-seed runner
# ---------------------------------------------------------------------------

def run_multi_seed(runner_fn, func, bounds, col_names, n_init, n_iters, seeds,
                   true_func=None, init_func=None):
    """Run a single approach across multiple seeds, collect per-seed histories."""
    global _noisy_rng
    all_histories = []
    all_times = []
    all_strategies = []

    for seed in seeds:
        # Reset noisy function RNG so each seed gets a reproducible noise sequence
        _noisy_rng = np.random.RandomState(seed + 1000)
        kwargs = {}
        if true_func:
            kwargs["true_func"] = true_func
        if init_func:
            kwargs["init_func"] = init_func
        res = runner_fn(func, bounds, col_names, n_init, n_iters, seed=seed,
                        **kwargs)
        all_histories.append(res["best_history"])
        all_times.append(res["times"])
        if "strategies_used" in res:
            all_strategies.append(res["strategies_used"])

    # Stack into (n_seeds, n_iters) arrays
    histories = np.array(all_histories)   # (n_seeds, n_iters)
    times_arr = np.array(all_times)       # (n_seeds, n_iters)

    return {
        "histories": histories,
        "mean_history": histories.mean(axis=0),
        "std_history": histories.std(axis=0),
        "min_history": histories.min(axis=0),
        "max_history": histories.max(axis=0),
        "mean_times": times_arr.mean(axis=0),
        "all_strategies": all_strategies,
        "n_seeds": len(seeds),
    }


# ---------------------------------------------------------------------------
# Metrics (computed on aggregated results)
# ---------------------------------------------------------------------------

def compute_metrics(agg, global_min):
    """Compute comparison metrics from aggregated multi-seed results."""
    mean_h = agg["mean_history"]
    std_h = agg["std_history"]
    histories = agg["histories"]

    # Final regret: mean and std across seeds
    final_regrets = histories[:, -1] - global_min
    mean_final_regret = final_regrets.mean()
    std_final_regret = final_regrets.std()

    # Cumulative regret per seed, then average
    regrets_all = histories - global_min  # (n_seeds, n_iters)
    cum_regrets = regrets_all.sum(axis=1)  # (n_seeds,)
    mean_cum_regret = cum_regrets.mean()
    std_cum_regret = cum_regrets.std()

    # Iterations to reach regret < 1.0 (per seed, then median)
    iters_per_seed = []
    for row in regrets_all:
        found = np.where(row < 1.0)[0]
        iters_per_seed.append(int(found[0]) + 1 if len(found) > 0 else None)

    valid_iters = [i for i in iters_per_seed if i is not None]
    median_iters = float(np.median(valid_iters)) if valid_iters else None
    frac_reached = len(valid_iters) / len(iters_per_seed)

    # Time
    total_times = agg["mean_times"].sum()

    return {
        "mean_final_regret": mean_final_regret,
        "std_final_regret": std_final_regret,
        "mean_cum_regret": mean_cum_regret,
        "std_cum_regret": std_cum_regret,
        "median_iters_to_threshold": median_iters,
        "frac_reached_threshold": frac_reached,
        "mean_total_time_s": total_times,
        "mean_final_best": mean_h[-1],
        "std_final_best": std_h[-1],
    }


# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------

COLORS = {"Random": "#999999", "Classical BO": "#2196F3", "SciLink Agent": "#E91E63"}
LINESTYLES = {"Random": "--", "Classical BO": "-", "SciLink Agent": "-"}


def plot_comparison(benchmark_name, global_min, agg_results, save_dir):
    """Per-benchmark plot: convergence (left) + cumulative regret (right).

    Saved into a subfolder: save_dir/<benchmark_name>/
    """
    bm_dir = save_dir / benchmark_name
    bm_dir.mkdir(parents=True, exist_ok=True)

    bm_label = benchmark_name.replace("_", " ").title()
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # --- Left panel: Convergence (best value found) ---
    ax = axes[0]
    for name, agg in agg_results.items():
        iters = np.arange(1, len(agg["mean_history"]) + 1)
        mean = agg["mean_history"]
        std = agg["std_history"]
        ax.plot(iters, mean, color=COLORS[name], linestyle=LINESTYLES[name],
                linewidth=2, label=f'{name} (n={agg["n_seeds"]})')
        ax.fill_between(iters, mean - std, mean + std,
                        color=COLORS[name], alpha=0.15)
    ax.axhline(global_min, color="green", linestyle=":", linewidth=1,
               label=f"Global min = {global_min:.3f}")
    ax.set_xlabel("BO Iteration")
    ax.set_ylabel("Best Value Found")
    ax.set_title(f"{bm_label} — Convergence")
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)

    # --- Right panel: Cumulative regret bar chart ---
    ax = axes[1]
    approaches = list(agg_results.keys())
    n_app = len(approaches)
    x = np.arange(n_app)
    width = 0.55

    means = []
    stds = []
    for name in approaches:
        histories = agg_results[name]["histories"]
        regrets = np.maximum(histories - global_min, 0)
        cum_per_seed = regrets.sum(axis=1)
        means.append(cum_per_seed.mean())
        stds.append(cum_per_seed.std())

    colors = [COLORS[a] for a in approaches]
    bars = ax.bar(x, means, width, color=colors, alpha=0.85,
                  edgecolor="white", linewidth=0.8)
    ax.errorbar(x, means, yerr=stds, fmt="none", ecolor="black",
                capsize=5, elinewidth=1.2, zorder=5)

    ymax = max(m + s for m, s in zip(means, stds)) if any(means) else 1
    ax.set_ylim(0, ymax * 1.25)
    for i, (m, s) in enumerate(zip(means, stds)):
        label = f"{m:.2f}" if m < 10 else f"{m:.0f}"
        ax.text(x[i], m + s + ymax * 0.03, label,
                ha="center", va="bottom", fontsize=9, fontweight="bold")

    ax.set_xticks(x)
    ax.set_xticklabels(approaches, fontsize=9)
    ax.set_ylabel("Cumulative Regret")
    ax.set_title(f"{bm_label} — Cumulative Regret")
    ax.grid(True, alpha=0.2, axis="y")
    ax.set_axisbelow(True)

    fig.tight_layout()
    save_path = bm_dir / "convergence_and_cumregret.png"
    fig.savefig(save_path, dpi=150)
    plt.close(fig)
    return str(save_path)


def plot_summary(all_metrics, save_dir):
    """One bar chart per benchmark comparing final and cumulative regret.

    Returns list of saved paths.
    """
    benchmarks = list(all_metrics.keys())
    approaches = [a for a in ["Random", "Classical BO", "SciLink Agent"]
                  if any(a in all_metrics[b] for b in benchmarks)]
    n_app = len(approaches)
    x = np.arange(n_app)
    width = 0.55
    saved = []

    for bm in benchmarks:
        bm_label = bm.replace("_", " ").title()
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))

        for panel, (metric_key, std_key, ylabel) in enumerate([
            ("mean_final_regret", "std_final_regret", "Final Simple Regret"),
            ("mean_cum_regret", "std_cum_regret", "Cumulative Regret"),
        ]):
            ax = axes[panel]
            means = [max(all_metrics[bm].get(a, {}).get(metric_key, 0), 0)
                     for a in approaches]
            stds = [max(all_metrics[bm].get(a, {}).get(std_key, 0), 0)
                    for a in approaches]
            colors = [COLORS[a] for a in approaches]

            bars = ax.bar(x, means, width, color=colors, alpha=0.85,
                          edgecolor="white", linewidth=0.8)
            ax.errorbar(x, means, yerr=stds, fmt="none", ecolor="black",
                        capsize=5, elinewidth=1.2, zorder=5)

            ax.set_xticks(x)
            ax.set_xticklabels(approaches, fontsize=9)
            ax.set_ylabel(ylabel, fontsize=10)
            ax.grid(True, alpha=0.2, axis="y")
            ax.set_axisbelow(True)

            # Value labels above bars
            ymax = max(m + s for m, s in zip(means, stds)) if any(means) else 1
            ax.set_ylim(0, ymax * 1.25)
            for i, (m, s) in enumerate(zip(means, stds)):
                label = f"{m:.3f}" if m < 0.1 else (f"{m:.2f}" if m < 10 else f"{m:.0f}")
                ax.text(x[i], m + s + ymax * 0.03, label,
                        ha="center", va="bottom", fontsize=9, fontweight="bold")

        fig.suptitle(bm_label, fontsize=13, fontweight="bold")
        fig.tight_layout()
        save_path = save_dir / f"{bm}_summary.png"
        fig.savefig(save_path, dpi=150)
        plt.close(fig)
        saved.append(str(save_path))

    return saved


# ---------------------------------------------------------------------------
# Printing
# ---------------------------------------------------------------------------

def print_table(benchmark_name, global_min, metrics_dict, n_seeds):
    """Print comparison table for one benchmark with mean +/- std."""
    print(f"\n{'=' * 80}")
    print(f"  {benchmark_name}   (global min = {global_min:.4f}, seeds = {n_seeds})")
    print(f"{'=' * 80}")
    header = (f"{'Approach':<18} {'Final Regret':>18} {'Cum. Regret':>18} "
              f"{'Med. Iters→<1':>14} {'Time (s)':>10}")
    print(header)
    print("-" * 80)
    for name, m in metrics_dict.items():
        regret_str = f"{m['mean_final_regret']:.4f} +/- {m['std_final_regret']:.4f}"
        cum_str = f"{m['mean_cum_regret']:.2f} +/- {m['std_cum_regret']:.2f}"
        iters_val = m["median_iters_to_threshold"]
        frac = m["frac_reached_threshold"]
        if iters_val is not None:
            iters_str = f"{iters_val:.0f} ({frac:.0%})"
        else:
            iters_str = f"— ({frac:.0%})"
        time_str = f"{m['mean_total_time_s']:.2f}"
        print(f"{name:<18} {regret_str:>18} {cum_str:>18} {iters_str:>14} {time_str:>10}")


def print_strategy_log(all_strategies):
    """Print LLM-chosen strategies from the first seed (as a sample)."""
    if not all_strategies:
        return
    strats = all_strategies[0]
    print("\n  Agent strategy choices (seed 0):")
    for i, s in enumerate(strats):
        if isinstance(s, dict) and "error" not in s:
            kernel = s.get("kernel", "?")
            acq = s.get("acquisition_strategy", s.get("strategy", "?"))
            if isinstance(acq, dict):
                acq = acq.get("name", "?")
            noise = s.get("noise", "?")
            print(f"    step {i+1}: kernel={kernel}, acq={acq}, noise={noise}")
        elif isinstance(s, dict) and "error" in s:
            print(f"    step {i+1}: ERROR — {s['error'][:60]}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    _OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    run_agent = not _SKIP_AGENT and bool(_API_KEY)
    if _SKIP_AGENT:
        print("Skipping SciLink Agent (--no-agent flag).\n")
    elif not _API_KEY:
        print("No API key found — skipping SciLink Agent tests.")
        print("Set GEMINI_API_KEY or SCILINK_TEST_API_KEY to include agent.\n")

    print(f"Seeds: {SEEDS}  (--seeds N to change)\n")

    all_metrics = {}
    all_agg = {}
    all_json = {}

    for bm_name, bm in BENCHMARKS.items():
        print(f"\n{'#' * 80}")
        print(f"# Benchmark: {bm_name}  ({bm['n_iters']} iters x {len(SEEDS)} seeds)")
        print(f"{'#' * 80}")

        func = bm["func"]
        true_func = bm.get("true_func")
        init_func = bm.get("init_func")
        bounds = bm["bounds"]
        col_names = bm["col_names"]
        global_min = bm["global_min"]
        n_init = bm["n_init"]
        n_iters = bm["n_iters"]

        agg_results = {}
        metrics = {}

        # --- Random Search ---
        print(f"\n  Running Random Search ...")
        agg = run_multi_seed(run_random_search, func, bounds, col_names,
                             n_init, n_iters, SEEDS,
                             true_func=true_func, init_func=init_func)
        agg_results["Random"] = agg
        metrics["Random"] = compute_metrics(agg, global_min)

        # --- Classical BO ---
        print(f"  Running Classical BO ...")
        agg = run_multi_seed(run_classical_bo, func, bounds, col_names,
                             n_init, n_iters, SEEDS,
                             true_func=true_func, init_func=init_func)
        agg_results["Classical BO"] = agg
        metrics["Classical BO"] = compute_metrics(agg, global_min)

        # --- SciLink Agent ---
        if run_agent:
            print(f"  Running SciLink Agent ...")
            agg = run_multi_seed(run_scilink_agent, func, bounds, col_names,
                                 n_init, n_iters, SEEDS,
                                 true_func=true_func, init_func=init_func)
            agg_results["SciLink Agent"] = agg
            metrics["SciLink Agent"] = compute_metrics(agg, global_min)

        # --- Print ---
        print_table(bm_name, global_min, metrics, len(SEEDS))
        if run_agent and "SciLink Agent" in agg_results:
            print_strategy_log(agg_results["SciLink Agent"]["all_strategies"])

        # --- Plot ---
        plot_path = plot_comparison(bm_name, global_min, agg_results, _OUTPUT_DIR)
        print(f"\n  Plot saved: {plot_path}")

        all_metrics[bm_name] = metrics
        all_agg[bm_name] = agg_results

        # Serialize per-seed histories
        all_json[bm_name] = {}
        for approach_name, agg in agg_results.items():
            all_json[bm_name][approach_name] = {
                "histories": agg["histories"].tolist(),
                "mean_history": agg["mean_history"].tolist(),
                "std_history": agg["std_history"].tolist(),
                "n_seeds": agg["n_seeds"],
            }

    # --- Overall Summary ---
    print(f"\n\n{'#' * 80}")
    print(f"# OVERALL SUMMARY  ({len(SEEDS)} seeds per benchmark)")
    print(f"{'#' * 80}")

    for bm_name, metrics in all_metrics.items():
        print_table(bm_name, BENCHMARKS[bm_name]["global_min"], metrics, len(SEEDS))

    summary_paths = plot_summary(all_metrics, _OUTPUT_DIR)
    for p in summary_paths:
        print(f"  Summary plot saved: {p}")

    json_path = _OUTPUT_DIR / "comparison_results.json"
    with open(json_path, "w") as f:
        json.dump(all_json, f, indent=2)
    print(f"  Raw results saved: {json_path}")

    # --- Verdict ---
    print(f"\n{'=' * 80}")
    print("  VERDICT")
    print(f"{'=' * 80}")
    for bm_name, m in all_metrics.items():
        cr = m["Classical BO"]["mean_final_regret"]
        rr = m["Random"]["mean_final_regret"]
        msg = f"  {bm_name}: Classical BO regret={cr:.4f} vs Random={rr:.4f}"
        if "SciLink Agent" in m:
            ar = m["SciLink Agent"]["mean_final_regret"]
            msg += f" vs Agent={ar:.4f}"
            if ar < cr:
                msg += "  -> Agent wins"
            elif ar <= cr * 1.1:
                msg += "  -> Comparable"
            else:
                msg += "  -> Classical wins"
        else:
            msg += f"  -> BO {'beats' if cr < rr else 'loses to'} Random"
        print(msg)

    print()


if __name__ == "__main__":
    main()
