// Copyright (c) 2026 Juancarlo Añez (apalala@gmail.com)
// SPDX-License-Identifier: MIT OR Apache-2.0

use tiexiu::Result;

#[test]
fn test_parse() -> Result<()> {
    let tree = tiexiu::api::parse_grammar("start = /a/", &[])?;
    let parser = tiexiu::api::compile("start = /a/", &[])?;

    eprintln!("TREE\n{:?}", tree);
    eprintln!("PARSER\n{:?}", parser);
    use tiexiu::peg::ExpKind;
    for rule in parser.rules() {
        match &rule.exp.kind {
            ExpKind::Sequence(exps) => {
                assert_eq!(exps.len(), 1, "Sequence should have 1 item");
            }
            other => panic!("Unexpected: {:?}", other),
        }
    }
    Ok(())
}

#[test]
fn test_parse_to_json() -> Result<()> {
    let json_str = tiexiu::api::parse_to_json_string("start = /a/", "a", &[])?;
    eprintln!("TREE {:?}", json_str);
    assert!(json_str.contains("\"a\""));
    Ok(())
}
