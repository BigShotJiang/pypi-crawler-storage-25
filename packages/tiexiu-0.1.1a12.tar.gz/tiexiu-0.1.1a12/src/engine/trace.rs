// Copyright (c) 2026 Juancarlo Añez (apalala@gmail.com)
// SPDX-License-Identifier: MIT OR Apache-2.0

use super::CtxI;
use crate::peg::ParseFailure;
use console::{Term, style};
use std::fmt::Debug;
use std::io::Write;

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct NullTracer {}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct ConsoleTracer {}

impl Tracer for NullTracer {}

impl Tracer for ConsoleTracer {
    fn trace(&self, msg: &str) {
        eprintln!("{}", msg);
        std::io::stderr().flush().ok();
        std::io::stdout().flush().ok();
    }
}

pub static NULL_TRACER: NullTracer = NullTracer {};
pub static CONSOLE_TRACER: ConsoleTracer = ConsoleTracer {};

pub enum Event {
    Entry,
    Success,
    Failure,
    Recursion,
    Cut,
    Match,
    NoMatch,
}

pub trait Tracer: Debug {
    fn trace(&self, msg: &str) {
        let _ = msg;
    }

    fn trace_event(&self, ctx: &dyn CtxI, event: Event, msg: &str) {
        console::set_colors_enabled(true);

        let term = Term::stdout();
        let (_rows, cols) = if let Some((r, c)) = term.size_checked() {
            (r.into(), c.into())
        } else {
            (24usize, 80usize)
        };
        let event_symbol: String = match event {
            Event::Entry => style("↙").yellow(),
            Event::Success => style("≡").green(),
            Event::Failure => style("≢").red(),
            Event::Recursion => style("⟲").blue(),
            Event::Cut => style("⚔").yellow(),
            Event::Match => style("≡").green(),
            Event::NoMatch => style("≢").red(),
        }
        .to_string();
        let stack_symbol: String = match event {
            Event::Success => style("→").green(),
            Event::Failure => style("→").red(),
            Event::NoMatch => style("←").red(),
            Event::Match => style("←").green(),
            _ => style("←").yellow(),
        }
        .to_string();
        let lookahead = ctx.cursor().lookahead(ctx.mark()).replace(" ", "·");
        let mut callstack = ctx.callstack().to_vec().join(stack_symbol.as_str());
        if callstack.chars().count() > cols {
            let safe_index = callstack.floor_char_boundary(cols - 4);
            callstack.truncate(safe_index);
            callstack.push_str("...");
        }
        let scallstack = style(callstack).white().bold();

        let location = ctx.cursor().location();
        let source = location.source.to_string();
        let (line, col) = location.pos;

        let pos = style(format!("[{line}:{col}]→")).black().bright();

        let msg = format!("{event_symbol}{msg} {scallstack}<|•\"{source}\"\n{pos}{lookahead}");
        self.trace(msg.as_str());
    }

    fn trace_entry(&self, ctx: &dyn CtxI) {
        self.trace_event(ctx, Event::Entry, "");
    }

    fn trace_success(&self, ctx: &dyn CtxI) {
        self.trace_event(ctx, Event::Success, "");
    }

    fn trace_failure(&self, ctx: &dyn CtxI, error: &ParseFailure) {
        let errstr = format!(" {}", style(error).red());
        self.trace_event(ctx, Event::Failure, &errstr);
    }

    fn trace_recursion(&self, ctx: &dyn CtxI) {
        self.trace_event(ctx, Event::Recursion, "");
    }

    fn trace_cut(&self, ctx: &dyn CtxI) {
        self.trace_event(ctx, Event::Cut, "");
    }

    fn trace_match(&self, ctx: &dyn CtxI, token: &str, name: &str) -> bool {
        let mut tag = name.to_string();
        if !tag.is_empty() {
            tag = format!("/{tag}/");
        }
        let msg = style(format!("'{token}'{tag}")).green().to_string();
        self.trace_event(ctx, Event::Match, &msg);
        true
    }

    fn trace_no_match(&self, ctx: &dyn CtxI, name: &str) -> bool {
        let msg = style(format!("/{name}/")).red().to_string();
        self.trace_event(ctx, Event::NoMatch, &msg);
        false
    }
}
