// Copyright (c) 2026 Juancarlo Añez (apalala@gmail.com)
// SPDX-License-Identifier: MIT OR Apache-2.0

//! Exp - Grammar to serde_json::Value serializer
//!
//! This module serializes Grammar to serde_json::Value,
//! allowing easy tweaking of the output before final serialization.

use super::error::{JsonError, Result};
use crate::cfg::constants::*;
use crate::cfg::*;
use crate::peg::exp::{Exp, ExpKind};
use crate::peg::grammar::Grammar;
use crate::peg::rule::Rule;
use serde_json::{Map, Value};

pub trait ToExpJson {
    fn to_json(&self) -> Value;

    fn to_json_str(&self) -> Result<Box<str>> {
        self.to_json_string().map(|s| s.into_boxed_str())
    }

    fn to_json_string(&self) -> Result<String> {
        match serde_json::to_string_pretty(&self.to_json()) {
            Ok(s) => Ok(s),
            Err(e) => Err(JsonError::Json(e)),
        }
    }

    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self.to_json_string() {
            Ok(json) => write!(f, "{}", json),
            Err(_) => Err(std::fmt::Error),
        }
    }
}

impl ToExpJson for Grammar {
    fn to_json(&self) -> Value {
        Grammar::to_json_exp(self)
    }
}

impl ToExpJson for Rule {
    fn to_json(&self) -> Value {
        Rule::to_json_exp(self)
    }
}

impl ToExpJson for Exp {
    fn to_json(&self) -> Value {
        Exp::to_json_exp(self)
    }
}

impl Grammar {
    pub fn to_json_exp(&self) -> Value {
        let mut obj = Map::new();

        obj.insert("__class__".into(), Value::String("Grammar".into()));
        obj.insert("name".into(), Value::String(self.name.clone().into()));
        obj.insert("analyzed".into(), Value::Bool(self.analyzed));

        let rules: Vec<Value> = self.rules().map(|r| r.to_json_exp()).collect();
        obj.insert("rules".into(), Value::Array(rules));

        let directives: Vec<Value> = self
            .get_directives()
            .iter()
            .filter_map(|opt| {
                let (name, value) = match opt {
                    CfgKey::Grammar(name) => (STR_GRAMMAR_NAME, name.as_str()),
                    CfgKey::Wsp(p) => (STR_WHITESPACE, p.as_str()),
                    CfgKey::Cmt(p) => (STR_COMMENTS, p.as_str()),
                    CfgKey::Eol(p) => (STR_EOL_COMMENTS, p.as_str()),
                    CfgKey::NameChars(p) => (STR_NAMECHARS, p.as_str()),
                    CfgKey::IgnoreCase => (STR_IGNORECASE, "True"),
                    CfgKey::NoNameGuard => (STR_NAMEGUARD, "False"),
                    CfgKey::NoLeftRecursion => (STR_LEFTREC, "False"),
                    CfgKey::NoParseInfo => (STR_PARSEINFO, "False"),
                    CfgKey::NoMemoization => (STR_MEMOIZATION, "False"),
                    _ => return None,
                };
                let mut d_obj = Map::new();
                d_obj.insert("name".into(), Value::String(name.into()));
                d_obj.insert("value".into(), Value::String(value.into()));
                Some(Value::Object(d_obj))
            })
            .collect();
        obj.insert("directives".into(), Value::Array(directives));

        let keywords: Vec<Value> = self
            .keywords
            .iter()
            .map(|k| Value::String(k.to_string()))
            .collect();
        obj.insert("keywords".into(), Value::Array(keywords));

        Value::Object(obj)
    }
}

impl Rule {
    pub fn to_json_exp(&self) -> Value {
        let mut obj = Map::new();

        obj.insert("__class__".into(), Value::String("Rule".into()));
        obj.insert("name".into(), Value::String(self.name.to_string()));

        obj.insert("exp".into(), self.exp.to_json_exp());

        let params: Vec<Value> = self
            .params
            .iter()
            .map(|p| Value::String(p.to_string()))
            .collect();
        obj.insert("params".into(), Value::Array(params));

        obj.insert("is_name".into(), Value::Bool(self.is_name()));
        obj.insert("is_tokn".into(), Value::Bool(self.has_is_tokn_flag()));
        obj.insert("no_memo".into(), Value::Bool(self.has_no_memo_flag()));
        obj.insert("is_memo".into(), Value::Bool(self.has_is_memo_flag()));
        obj.insert("is_lrec".into(), Value::Bool(self.has_is_lrec_flag()));

        Value::Object(obj)
    }
}

impl Exp {
    pub fn to_json_exp(&self) -> Value {
        self.kind.to_serde_value()
    }
}

impl ExpKind {
    pub fn to_serde_value(&self) -> Value {
        let mut obj = Map::new();
        let tag = TATSU_TYPE_TAG.to_string();

        match self {
            Self::EmptyClosure => {
                obj.insert(tag, Value::String("EmptyClosure".into()));
            }
            ExpKind::Nil | ExpKind::Void => {
                obj.insert(tag, Value::String("Void".into()));
            }
            ExpKind::Fail => {
                obj.insert(tag, Value::String("Fail".into()));
            }
            ExpKind::Dot => {
                obj.insert(tag, Value::String("Dot".into()));
            }
            ExpKind::Call { name, .. } => {
                obj.insert(tag, Value::String("Call".into()));
                obj.insert("name".into(), Value::String(name.as_ref().to_string()));
            }
            ExpKind::Token(s) => {
                obj.insert(tag, Value::String("Token".into()));
                obj.insert("token".into(), Value::String(s.as_ref().to_string()));
            }
            ExpKind::Pattern(s) => {
                obj.insert(tag, Value::String("Pattern".into()));
                obj.insert("pattern".into(), Value::String(s.as_ref().to_string()));
            }
            ExpKind::Constant(s) => {
                obj.insert(tag, Value::String("Constant".into()));
                obj.insert("literal".into(), Value::String(s.as_ref().to_string()));
            }
            ExpKind::Alert(s, level) => {
                obj.insert(tag, Value::String("Alert".into()));
                obj.insert("literal".into(), Value::String(s.as_ref().to_string()));
                obj.insert("level".into(), Value::Number((*level).into()));
            }
            ExpKind::Named(name, inner) => {
                obj.insert(tag, Value::String("Named".into()));
                obj.insert("name".into(), Value::String(name.as_ref().to_string()));
                obj.insert("exp".into(), inner.to_json_exp());
            }
            ExpKind::NamedList(name, inner) => {
                obj.insert(tag, Value::String("NamedList".into()));
                obj.insert("name".into(), Value::String(name.as_ref().to_string()));
                obj.insert("exp".into(), inner.to_json_exp());
            }
            ExpKind::Override(inner) => {
                obj.insert(tag, Value::String("Override".into()));
                obj.insert("exp".into(), inner.to_json_exp());
            }
            ExpKind::OverrideList(inner) => {
                obj.insert(tag, Value::String("OverrideList".into()));
                obj.insert("exp".into(), inner.to_json_exp());
            }
            ExpKind::Group(inner) => {
                obj.insert(tag, Value::String("Group".into()));
                obj.insert("exp".into(), inner.to_json_exp());
            }
            ExpKind::SkipGroup(inner) => {
                obj.insert(tag, Value::String("SkipGroup".into()));
                obj.insert("exp".into(), inner.to_json_exp());
            }
            ExpKind::Lookahead(inner) => {
                obj.insert(tag, Value::String("Lookahead".into()));
                obj.insert("exp".into(), inner.to_json_exp());
            }
            ExpKind::NegativeLookahead(inner) => {
                obj.insert(tag, Value::String("NegativeLookahead".into()));
                obj.insert("exp".into(), inner.to_json_exp());
            }
            ExpKind::SkipTo(inner) => {
                obj.insert(tag, Value::String("SkipTo".into()));
                obj.insert("exp".into(), inner.to_json_exp());
            }
            ExpKind::Sequence(arr) => {
                obj.insert(tag, Value::String("Sequence".into()));
                let seq: Vec<Value> = arr.iter().map(|e| e.to_json_exp()).collect();
                obj.insert("sequence".into(), Value::Array(seq));
            }
            ExpKind::Choice(arr) => {
                obj.insert(tag, Value::String("Choice".into()));
                let opts: Vec<Value> = arr.iter().map(|e| e.to_json_exp()).collect();
                obj.insert("options".into(), Value::Array(opts));
            }
            ExpKind::Alt(inner) => {
                obj.insert(tag, Value::String("Option".into()));
                obj.insert("exp".into(), inner.to_json_exp());
            }
            ExpKind::Optional(inner) => {
                obj.insert(tag, Value::String("Optional".into()));
                obj.insert("exp".into(), inner.to_json_exp());
            }
            ExpKind::Closure(inner) => {
                obj.insert(tag, Value::String("Closure".into()));
                obj.insert("exp".into(), inner.to_json_exp());
            }
            ExpKind::PositiveClosure(inner) => {
                obj.insert(tag, Value::String("PositiveClosure".into()));
                obj.insert("exp".into(), inner.to_json_exp());
            }
            ExpKind::Join { exp, sep } => {
                obj.insert(tag, Value::String("Join".into()));
                obj.insert("exp".into(), exp.to_json_exp());
                obj.insert("sep".into(), sep.to_json_exp());
            }
            ExpKind::PositiveJoin { exp, sep } => {
                obj.insert(tag, Value::String("PositiveJoin".into()));
                obj.insert("exp".into(), exp.to_json_exp());
                obj.insert("sep".into(), sep.to_json_exp());
            }
            ExpKind::Gather { exp, sep } => {
                obj.insert(tag, Value::String("Gather".into()));
                obj.insert("exp".into(), exp.to_json_exp());
                obj.insert("sep".into(), sep.to_json_exp());
            }
            ExpKind::PositiveGather { exp, sep } => {
                obj.insert(tag, Value::String("PositiveGather".into()));
                obj.insert("exp".into(), exp.to_json_exp());
                obj.insert("sep".into(), sep.to_json_exp());
            }
            ExpKind::RuleInclude { name, exp: _ } => {
                obj.insert(tag, Value::String("RuleInclude".into()));
                obj.insert("name".into(), Value::String(name.as_ref().to_string()));
                // NOTE: Hide the linked exp in transitions
                // if let Some(inner) = exp {
                //     obj.insert("exp".into(), inner.to_json_exp());
                // }
            }
            ExpKind::Eof => {
                obj.insert(tag, Value::String("EOF".into()));
            }
            ExpKind::Eol => {
                obj.insert(tag, Value::String("EOL".into()));
            }
            ExpKind::Cut => {
                obj.insert(tag, Value::String("Cut".into()));
            }
        }

        Value::Object(obj)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_grammar_to_serde_value() {
        let json_str = std::fs::read_to_string("grammar/tatsu.json").expect("tatsu.json missing");
        let value: Value = serde_json::from_str(&json_str).expect("Failed to parse JSON");
        let grammar = Grammar::from_serde_json_value(&value).expect("Failed to convert");
        let output = grammar.to_json_exp();

        assert!(output.is_object());
        let obj = output.as_object().unwrap();
        assert_eq!(obj.get("__class__").unwrap().as_str(), Some("Grammar"));
        assert_eq!(obj.get("name").unwrap().as_str(), Some("TatSu"));
        assert!(obj.contains_key("rules"));
    }
}
