legend_positions = {
    # Inside positions
    "N": {  # North (Top-Center)
        "x": 0.5,
        "y": 1,
        "xanchor": "center",
        "yanchor": "top",
        "yref": "paper",
        "border_width": 1.4
    },
    "S": {  # South (Bottom-Center)
        "x": 0.5,
        "y": 0,
        "xanchor": "center",
        "yanchor": "bottom",
        "yref": "paper",
        "border_width": 1.4
    },
    "E": {  # East (Right-Center)
        "x": 1,
        "y": 0.5,
        "xanchor": "right",
        "yanchor": "middle",
        "yref": "paper",
        "border_width": 1.4
    },
    "W": {  # West (Left-Center)
        "x": 0,
        "y": 0.5,
        "xanchor": "left",
        "yanchor": "middle",
        "yref": "paper",
        "border_width": 1.4
    },
    "NE": {  # North-East (Top-Right)
        "x": 1,
        "y": 1,
        "xanchor": "right",
        "yanchor": "top",
        "yref": "paper",
        "border_width": 1.4
    },
    "NW": {  # North-West (Top-Left)
        "x": 0,
        "y": 1,
        "xanchor": "left",
        "yanchor": "top",
        "yref": "paper",
        "border_width": 1.4
    },
    "SE": {  # South-East (Bottom-Right)
        "x": 1,
        "y": 0,
        "xanchor": "right",
        "yanchor": "bottom",
        "yref": "paper",
        "border_width": 1.4
    },
    "SW": {  # South-West (Bottom-Left)
        "x": 0,
        "y": 0,
        "xanchor": "left",
        "yanchor": "bottom",
        "yref": "paper",
        "border_width": 1.4
    },

    # Outside positions
    "NO": {  # North-Outside (Above Top-Center)
        "x": 0.5,
        "y": 0.89,
        "xanchor": "center",
        "yanchor": "top",
        "yref": "container",
        "border_width": 0
    },
    "SO": {
        "x": 0.5,
        "y": -0.1,
        "xanchor": "center",
        "yanchor": "top",
        "yref": "paper",
        "xref": "paper",
        "border_width": 0
    },
    # South-Outside (ADJUSTED) Need proper testing
    # TODO: Consider changing back to "paper" and off-setting POS using negatives.
    # "SO": {
    #     "x": 0.5,
    #     "y": -0.15,
    #     "xanchor": "center",
    #     "yanchor": "top",
    #     "yref": "paper"
    # },
    "EO": {
        "x": 1.02,
        "y": 0.5,
        "xanchor": "left",
        "yanchor": "middle",
        "yref": "paper",
        "xref": "paper",
        "border_width": 0
    },
    "WO": {  # West-Outside (Left of Chart)
        "x": 0,
        "y": 0.5,
        "xanchor": "left",
        "yanchor": "middle",
        "yref": "container",
        "xref": "container",
        "border_width": 0
    },
    "NEO": {  # North-East-Outside (Above Top-Right)
        "x": 1,
        "y": -0.1,
        "xanchor": "right",
        "yanchor": "top",
        "yref": "container",
        "border_width": 0
    },
    "NWO": {  # North-West-Outside (Above Top-Left)
        "x": 0,
        "y": -0.1,
        "xanchor": "left",
        "yanchor": "top",
        "yref": "container",
        "border_width": 0
    },
    "SEO": {
        "x": 1,
        "y": 0,
        "xanchor": "right",
        "yanchor": "bottom",
        "yref": "container",
        "border_width": 0
    },
    "SWO": {  # South-West-Outside (Below Bottom-Left)
        "x": 0,
        "y": 0,
        "xanchor": "left",
        "yanchor": "bottom",
        "yref": "container",
        "border_width": 0
    }
}
