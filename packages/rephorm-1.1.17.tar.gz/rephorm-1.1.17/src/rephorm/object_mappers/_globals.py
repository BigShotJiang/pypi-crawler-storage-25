# Central storage for globals
figure_map = []
chart_queue = {}
_output_dir = "."

def set_figure_map(data):
    global figure_map
    figure_map.append(data)

def get_figure_map():
    global figure_map
    return figure_map

def add_to_chart_queue(chart_data):
    """Groups charts by width x height for batch processing."""
    global chart_queue
    w, h = chart_data.get("width"), chart_data.get("height")

    # Ensure dimensions are strings for the key
    key = f"{w}x{h}"

    if key not in chart_queue:
        chart_queue[key] = []

    chart_queue[key].append({
        "fig": chart_data["fig"],
        "path": chart_data["path"]
    })

def get_chart_queue():
    global chart_queue
    return chart_queue

def reset_figure_map():
    global figure_map, chart_queue
    figure_map = []
    chart_queue = {}

def set_output_dir(path):
    global _output_dir
    _output_dir = path

def get_output_dir():
    return _output_dir