import os
import kaleido
import logging

"""
This module handles one-time setup tasks that cannot be reliably
executed during the standard 'pip install' phase due to modern
build constraints (like PEP 517 wheels).
"""

def initialize_kaleido():
    """
    Checks if Kaleido has been initialized for this specific installation.

    We only need to run "kaleido.get_chrome_sync()" once on a fresh
    package install. Here we use a sentinel file (".kaleido_initialized")
    stored inside the package directory to track this state.
    """
    package_dir = os.path.dirname(__file__)
    sentinel_file = os.path.join(package_dir, ".kaleido_initialized")

    if not os.path.exists(sentinel_file):
        try:
            print("rephorm: First-run initialization (downloading Kaleido binaries)...")
            kaleido.get_chrome_sync()
            # Create the flag file so this never runs again
            with open(sentinel_file, "w") as f:
                f.write("initialized")
        except Exception as e:
            logging.warning(f"rephorm: Could not initialize Kaleido: {e}")
