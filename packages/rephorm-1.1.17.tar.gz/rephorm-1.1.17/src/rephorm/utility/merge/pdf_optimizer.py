"""
Post-processing optimizer for merged PDF reports.

Reduces file size by merging duplicate font subsets: when N charts each
embed their own subset of the same base font (e.g. ArialMT), this module
replaces all N copies with a single shared subset containing the union of
glyphs.  Content streams and width tables are left untouched — only the
FontFile2 stream references in FontDescriptors are redirected.

This works because Kaleido's PDF output uses CIDToGIDMap /Identity, so
every chart's CIDs map 1-to-1 to the original font's GIDs regardless of
which subset was embedded.
"""

import fitz
import io
import os
import platform


def optimize_pdf(pdf_path):
    """
    Optimize a PDF file in-place by merging duplicate font subsets.

    Returns the number of bytes saved (positive = smaller, negative = larger).
    """
    # Only for debugging:
    # original_size = os.path.getsize(pdf_path)
    
    doc = fitz.open(pdf_path)

    changed = _merge_font_subsets(doc)

    if changed:
        tmp_path = pdf_path + ".tmp"
        doc.save(
            tmp_path,
            garbage=4,
            deflate=True,
            clean=True,
            deflate_fonts=True,
            deflate_images=True,
        )
        doc.close()
        os.replace(tmp_path, pdf_path)
    else:
        doc.close()

    # Only for debugging:
    # new_size = os.path.getsize(pdf_path)
    # saved = original_size - new_size
    # if saved > 0:
    #     print(f"  PDF optimized: {original_size:,} -> {new_size:,} bytes (saved {saved:,})")
    # return saved


def _merge_font_subsets(doc):
    """
    Find all CIDFontType2 fonts with /Identity CIDToGIDMap, group by base
    font name, and replace per-chart subsets with a single shared master.
    """
    try:
        from fontTools.ttLib import TTFont
    except ImportError:
        print("  Warning: fontTools not installed -- skipping font optimization")
        return False

    # ---- Step 1: collect embedded fonts grouped by base name ---------------
    font_groups = {}  # base_name -> list of entry dicts
    seen_type0 = set()

    for pno in range(len(doc)):
        for font_info in doc.get_page_fonts(pno):
            type0_xref = font_info[0]
            if type0_xref in seen_type0:
                continue
            seen_type0.add(type0_xref)

            ext = font_info[1]
            name = font_info[3]

            # Accept TrueType (.ttf) fonts only — CFF/Type1 need different handling
            if ext != "ttf":
                continue

            # Extract font binary via the Type0 xref
            _, _, _, buf = doc.extract_font(type0_xref)
            if not buf:
                continue

            # Follow reference chain: Type0 -> CIDFont2 -> FontDescriptor -> FontFile2
            entry = _follow_font_chain(doc, type0_xref)
            if entry is None:
                continue

            entry["buf"] = buf

            # Strip subset prefix (e.g. "AAAAAA+ArialMT" -> "ArialMT")
            base = name.split("+", 1)[-1] if "+" in name else name
            font_groups.setdefault(base, []).append(entry)

    # ---- Step 2: merge each group that has duplicates ----------------------
    changed = False

    for base_name, entries in font_groups.items():
        if len(entries) < 2:
            continue

        # Check whether they already share the same FontFile2 xref
        unique_ff = {e["fontfile_xref"] for e in entries}
        if len(unique_ff) == 1:
            continue

        # Collect union of GIDs across all subsets
        all_gids = set()
        for entry in entries:
            all_gids.update(_extract_gids(entry["buf"], TTFont))

        if not all_gids:
            continue

        # Build the master subset
        master_buf = _build_master_subset(base_name, all_gids, entries)
        if master_buf is None:
            continue

        # ---- Step 3: point all FontDescriptors at a single shared stream ---
        # Reuse the first entry's FontFile2 xref as the master container
        master_xref = entries[0]["fontfile_xref"]
        doc.update_stream(master_xref, master_buf)
        doc.xref_set_key(master_xref, "Length1", str(len(master_buf)))

        # Redirect all other descriptors to the shared master
        for entry in entries[1:]:
            doc.xref_set_key(
                entry["descriptor_xref"],
                "FontFile2",
                f"{master_xref} 0 R",
            )

        total_old = sum(len(e["buf"]) for e in entries)
        print(
            f"  Merged {len(entries)} '{base_name}' font subsets: "
            f"{total_old:,} -> {len(master_buf):,} bytes"
        )
        changed = True

    return changed


def _follow_font_chain(doc, type0_xref):
    """
    Follow  Type0 -> DescendantFonts[0] -> FontDescriptor -> FontFile2
    and verify CIDToGIDMap is /Identity.

    Returns dict with cid_xref, descriptor_xref, fontfile_xref or None.
    """
    try:
        # Type0 -> DescendantFonts -> first CIDFont2
        _, desc_val = doc.xref_get_key(type0_xref, "DescendantFonts")
        cid_xref = int(desc_val.strip("[] ").split()[0])

        # Verify CIDToGIDMap /Identity
        _, cidmap_val = doc.xref_get_key(cid_xref, "CIDToGIDMap")
        if "Identity" not in cidmap_val:
            return None

        # CIDFont2 -> FontDescriptor
        _, fd_val = doc.xref_get_key(cid_xref, "FontDescriptor")
        descriptor_xref = int(fd_val.strip().split()[0])

        # FontDescriptor -> FontFile2
        _, ff_val = doc.xref_get_key(descriptor_xref, "FontFile2")
        fontfile_xref = int(ff_val.strip().split()[0])

    except (ValueError, KeyError, RuntimeError):
        return None

    return {
        "cid_xref": cid_xref,
        "descriptor_xref": descriptor_xref,
        "fontfile_xref": fontfile_xref,
    }


# ---- GID extraction --------------------------------------------------------


def _extract_gids(buf, TTFont):
    """
    Extract the set of GIDs that carry actual glyph data in a TTF subset.

    Uses the cmap table when available (kaleido 1.x), falls back to scanning
    the glyf table for non-empty outlines (kaleido 0.x subsets that strip cmap).
    """
    gids = set()
    try:
        tt = TTFont(io.BytesIO(buf))

        # Try cmap first (fast and precise)
        cmap = tt.getBestCmap()
        if cmap:
            for glyph_name in cmap.values():
                gids.add(tt.getGlyphID(glyph_name))
        else:
            # Fallback: scan glyf table for glyphs with actual outlines
            glyf = tt.get("glyf")
            if glyf:
                for gid, name in enumerate(tt.getGlyphOrder()):
                    g = glyf[name]
                    # numberOfContours > 0 = simple glyph, -1 = composite
                    if g.numberOfContours != 0:
                        gids.add(gid)

        tt.close()
    except Exception:
        pass
    return gids


# ---- Master subset builder ------------------------------------------------

_SYSTEM_FONT_MAP = {
    "ArialMT": "arial.ttf",
    "Arial-BoldMT": "arialbd.ttf",
    "Arial-ItalicMT": "ariali.ttf",
    "TimesNewRomanPSMT": "times.ttf",
    "TimesNewRomanPS-BoldMT": "timesbd.ttf",
    "Times-Roman": "times.ttf",
    "Times-Bold": "timesbd.ttf",
    "CourierNewPSMT": "cour.ttf",
}


def _find_system_font(base_name):
    """Locate the system font file for a PostScript font name."""
    filename = _SYSTEM_FONT_MAP.get(base_name)
    if not filename:
        return None

    if platform.system() == "Windows":
        fonts_dir = os.path.join(
            os.environ.get("WINDIR", "C:\\Windows"), "Fonts"
        )
    elif platform.system() == "Darwin":
        fonts_dir = "/System/Library/Fonts/Supplemental"
    else:
        fonts_dir = "/usr/share/fonts/truetype"

    path = os.path.join(fonts_dir, filename)
    return path if os.path.exists(path) else None


def _build_master_subset(base_name, gids, entries):
    """
    Build a single TTF containing the union of *gids*, using retain-gids
    so that GID indices match the original font (required by /Identity
    CIDToGIDMap).

    Strategy:
      1. Try the system font first (guaranteed to have all glyphs).
      2. Fall back to the largest existing subset (best-effort).
    """
    from fontTools.ttLib import TTFont
    from fontTools.subset import Subsetter, Options

    source_path = _find_system_font(base_name)

    if source_path:
        try:
            return _subset_from_source(source_path, gids)
        except Exception as e:
            print(f"  Warning: system font subsetting failed for '{base_name}': {e}")

    # Fallback: use the largest existing subset
    largest = max(entries, key=lambda e: len(e["buf"]))
    return largest["buf"]


def _subset_from_source(font_path, gids):
    """Subset a full font to the given GIDs with retain-gids."""
    from fontTools.ttLib import TTFont
    from fontTools.subset import Subsetter, Options

    tt = TTFont(font_path)

    options = Options()
    options.retain_gids = True
    # Drop tables that aren't needed for chart text rendering
    options.drop_tables += ["DSIG", "GPOS", "GSUB", "kern", "morx", "GDEF"]

    subsetter = Subsetter(options=options)
    subsetter.populate(gids=gids)
    subsetter.subset(tt)

    buf = io.BytesIO()
    tt.save(buf)
    tt.close()
    return buf.getvalue()
