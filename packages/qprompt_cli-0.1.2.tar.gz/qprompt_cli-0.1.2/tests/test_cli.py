"""CLI behavior tests. Drives `_cmd_run` directly with a synthesized argparse
namespace and a tmp-path storage so traces don't leak into the repo's `.traces`.
"""
import json
from argparse import Namespace
from unittest.mock import patch

from llmtrace import cli
from llmtrace.storage import TraceStorage
from llmtrace.tracer import Tracer


def _run(args, tmp_path):
    storage = TraceStorage(root=str(tmp_path))
    with patch("llmtrace.cli.Tracer", lambda model: Tracer(storage=storage, model=model)):
        rc = cli._cmd_run(args)
    return rc, storage


def test_default_run_is_not_demo(tmp_path, capsys):
    args = Namespace(question="why did revenue drop in March?", model="m", demo=False)
    rc, storage = _run(args, tmp_path)
    assert rc == 0

    saved = storage.list_trace_paths()
    assert len(saved) == 1
    data = json.loads(saved[0].read_text())
    assert data.get("is_demo") is not True, "default CLI invocation must NOT be a demo trace"
    assert not any(
        s.get("type") == "tool_call" and s.get("tool") == "sql" for s in data["steps"]
    )
    assert data["evidence"] == []

    out = capsys.readouterr().out
    assert "[DEMO]" not in out


def test_demo_flag_produces_marked_trace(tmp_path, capsys):
    args = Namespace(question="why did revenue drop in March?", model="m", demo=True)
    rc, storage = _run(args, tmp_path)
    assert rc == 0

    saved = storage.list_trace_paths()
    assert len(saved) == 1
    data = json.loads(saved[0].read_text())
    assert data.get("is_demo") is True, "demo invocation must mark the saved trace"
    assert any(
        s.get("type") == "tool_call" and s.get("tool") == "sql" for s in data["steps"]
    )

    captured = capsys.readouterr()
    assert "[DEMO]" in captured.out, "stdout summary must label demo traces"
    assert "demo mode" in captured.err.lower(), "stderr banner must announce demo mode"


def test_argparse_default_for_demo_flag_is_false():
    parser = cli.build_parser()
    ns = parser.parse_args(["run", "any question"])
    assert ns.demo is False


def test_argparse_no_demo_sql_flag_removed():
    """The old opt-out flag should no longer be accepted; users must use --demo."""
    import argparse

    import pytest as _pt

    parser = cli.build_parser()
    with _pt.raises((SystemExit, argparse.ArgumentError)):
        parser.parse_args(["run", "any question", "--no-demo-sql"])
