from llmtrace.audit import run_answer_audit


def _trace(*, final_answer="", evidence=None, parsed=None, steps=None):
    return {
        "final_answer": final_answer,
        "evidence": evidence or [],
        "parsed": parsed or {"intent": "general_qa", "missing_context": [], "assumptions": []},
        "steps": steps or [],
    }


def test_process_claim_without_tool_call_flagged():
    t = _trace(final_answer="I queried the database and found a drop.")
    out = run_answer_audit(t)
    assert any("queried" in u.lower() for u in out["unsupported_claims"])
    assert any("unsupported process claim" in r.lower() for r in out["risk_flags"])


def test_process_claim_with_successful_tool_call_no_flag():
    t = _trace(
        final_answer="I queried the database and found a drop.",
        steps=[{"type": "tool_call", "tool": "sql", "status": "ok", "output_summary": "ok"}],
    )
    out = run_answer_audit(t)
    assert out["unsupported_claims"] == []
    assert not any("unsupported process claim" in r.lower() for r in out["risk_flags"])


def test_demo_answer_does_not_false_positive():
    t = _trace(
        final_answer=(
            "Revenue dropped mainly in enterprise (about 18% down in March), "
            "with smaller declines in other segments."
        ),
        evidence=[{"source": "query_result", "claim": "x", "evidence_id": "e"}],
        steps=[{"type": "tool_call", "tool": "sql", "status": "ok", "output_summary": "ok"}],
    )
    out = run_answer_audit(t)
    assert out["unsupported_claims"] == []


def test_failed_tool_call_in_risks():
    t = _trace(
        steps=[
            {
                "type": "tool_call",
                "tool": "sql",
                "status": "error",
                "error": "permission denied",
                "output_summary": "failed",
            }
        ],
    )
    out = run_answer_audit(t)
    assert any("Tool call failed (sql)" in r and "permission" in r for r in out["risk_flags"])


def test_missing_context_in_risks():
    t = _trace(
        parsed={"intent": "general_qa", "missing_context": ["No region specified"], "assumptions": []},
    )
    out = run_answer_audit(t)
    assert any("Missing context: No region specified" in r for r in out["risk_flags"])


def test_metric_explanation_without_evidence_flagged():
    t = _trace(
        final_answer="Revenue dropped due to enterprise.",
        parsed={"intent": "metric_explanation", "missing_context": [], "assumptions": []},
    )
    out = run_answer_audit(t)
    assert any("evidence" in u.lower() for u in out["unsupported_claims"])


def test_evidence_records_become_claims():
    t = _trace(
        evidence=[
            {"source": "query_result", "claim": "Enterprise dropped 18%", "evidence_id": "id1"}
        ],
    )
    out = run_answer_audit(t)
    assert len(out["claims"]) == 1
    assert out["claims"][0]["claim"] == "Enterprise dropped 18%"
    assert out["claims"][0]["evidence"] == "id1"


def test_risks_are_deduplicated():
    t = _trace(
        parsed={"intent": "general_qa", "missing_context": ["X", "X"], "assumptions": []},
    )
    out = run_answer_audit(t)
    risks = [r for r in out["risk_flags"] if "Missing context: X" in r]
    assert len(risks) == 1


def test_according_to_database_phrase_flagged():
    t = _trace(final_answer="According to the database, churn rose 4%.")
    out = run_answer_audit(t)
    assert any("according to the database" in p.lower() for p in out["unsupported_claims"][0:1])


def test_mixed_tool_runs_with_process_claim_flagged():
    """One successful tool call must NOT silence process-claim auditing when
    other tool calls failed — the answer's specific claims may correspond to
    the failed call(s)."""
    t = _trace(
        final_answer="I queried customers and orders and found churn rose 4%.",
        steps=[
            {"type": "tool_call", "tool": "customers_sql", "status": "ok", "output_summary": "ok"},
            {
                "type": "tool_call",
                "tool": "orders_sql",
                "status": "error",
                "error": "permission denied",
                "output_summary": "failed",
            },
        ],
    )
    out = run_answer_audit(t)
    assert any("mixed tool execution" in r.lower() for r in out["risk_flags"])
    assert any("alongside failed tool calls" in u.lower() for u in out["unsupported_claims"])
    # Failed tool call risk is still recorded separately.
    assert any("Tool call failed (orders_sql)" in r for r in out["risk_flags"])


def test_all_successful_tool_runs_with_process_claim_no_mixed_flag():
    """If every tool call succeeded, process claim is treated as supported."""
    t = _trace(
        final_answer="I queried the database and found churn rose 4%.",
        steps=[
            {"type": "tool_call", "tool": "sql", "status": "ok", "output_summary": "ok"},
            {"type": "tool_call", "tool": "sql2", "status": "ok", "output_summary": "ok"},
        ],
    )
    out = run_answer_audit(t)
    assert not any("mixed tool execution" in r.lower() for r in out["risk_flags"])
    assert not any("unsupported process claim" in r.lower() for r in out["risk_flags"])


def test_based_on_query_results_flagged():
    t = _trace(final_answer="Based on the query results, enterprise fell most.")
    out = run_answer_audit(t)
    assert any("unsupported process claim" in r.lower() for r in out["risk_flags"])
