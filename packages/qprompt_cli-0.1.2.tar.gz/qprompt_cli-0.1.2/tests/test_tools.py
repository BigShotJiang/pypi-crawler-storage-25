import pytest

from llmtrace.tools import ToolRunResult, ToolTracer, redact_value, traced_tool


def test_redact_truncates_long():
    out = redact_value("a" * 1000, max_len=10)
    assert out.endswith("[truncated]")
    assert "aaaaaaaaaa" in out


def test_redact_passes_short():
    assert redact_value("hi") == "hi"


def test_traced_tool_logs_ok_status():
    @traced_tool("noop")
    def noop():
        return ToolRunResult(value=42, output_summary="forty-two")

    trace = {"steps": []}
    tracer = ToolTracer(trace)
    result = noop(_tool_tracer=tracer)
    assert result == 42
    step = trace["steps"][0]
    assert step["type"] == "tool_call"
    assert step["tool"] == "noop"
    assert step["status"] == "ok"
    assert step["output_summary"] == "forty-two"


def test_traced_tool_logs_error_status_on_exception():
    @traced_tool("explode")
    def explode():
        raise RuntimeError("kaboom")

    trace = {"steps": []}
    tracer = ToolTracer(trace)
    with pytest.raises(RuntimeError):
        explode(_tool_tracer=tracer)
    step = trace["steps"][0]
    assert step["status"] == "error"
    assert "kaboom" in step["error"]


def test_traced_tool_runs_without_tracer():
    @traced_tool("noop")
    def noop():
        return 99

    assert noop() == 99
