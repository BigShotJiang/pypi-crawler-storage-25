from llmtrace import Tracer
from llmtrace.schema import new_trace
from llmtrace.storage import TraceStorage
from llmtrace.tracer import _redact_message_for_trace


def test_short_string_content_unchanged():
    out = _redact_message_for_trace({"role": "user", "content": "hello"}, max_chars=100)
    assert out == {"role": "user", "content": "hello"}


def test_long_string_content_truncated_with_marker():
    long = "x" * 5000
    out = _redact_message_for_trace({"role": "user", "content": long}, max_chars=100)
    assert out["content"].startswith("x" * 100)
    assert "[truncated, 4900 more chars]" in out["content"]


def test_short_block_list_structure_preserved():
    blocks = [{"type": "text", "text": "hi"}, {"text": "world"}]
    out = _redact_message_for_trace({"role": "user", "content": blocks}, max_chars=100)
    assert out["content"] == blocks  # untouched when under the cap


def test_long_block_list_flattened_and_truncated():
    blocks = [{"type": "text", "text": "x" * 3000}, {"text": "y" * 3000}]
    out = _redact_message_for_trace({"role": "user", "content": blocks}, max_chars=100)
    assert isinstance(out["content"], str)
    assert "[truncated" in out["content"]
    assert len(out["content"]) < 200  # 100 chars + truncation marker


def test_extra_fields_preserved():
    msg = {"role": "tool", "content": "ok", "name": "sql", "tool_call_id": "abc"}
    out = _redact_message_for_trace(msg, max_chars=100)
    assert out["name"] == "sql"
    assert out["tool_call_id"] == "abc"


def test_original_message_not_mutated():
    msg = {"role": "user", "content": "x" * 5000}
    out = _redact_message_for_trace(msg, max_chars=100)
    assert len(msg["content"]) == 5000  # original untouched
    assert "[truncated" in out["content"]


def test_tracer_chat_records_redacted_but_passes_full_to_llm(tmp_path):
    """LLM must see the original message; trace must see the truncated copy."""
    tracer = Tracer(
        storage=TraceStorage(root=str(tmp_path)),
        model="m",
        max_message_chars=50,
    )
    received_by_llm = {}

    def llm(*, messages, tools):
        _ = tools
        received_by_llm["messages"] = messages
        return {"text": "ok", "usage": {"input_tokens": 1, "output_tokens": 1}}

    long_user = "x" * 1000
    trace = new_trace(question="q", model="m")
    tracer.chat(
        messages=[{"role": "user", "content": long_user}],
        llm_callable=llm,
        trace=trace,
    )

    # LLM received the full content
    assert received_by_llm["messages"][0]["content"] == long_user

    # Trace recorded a truncated copy
    request_step = next(s for s in trace["steps"] if s["type"] == "request_sent")
    recorded = request_step["messages"][0]["content"]
    assert "[truncated" in recorded
    assert len(recorded) < 100


def test_non_text_block_with_huge_payload_is_redacted():
    """Image block with huge base64 must NOT slip past the cap because the
    text portion is small. Serialized size is what hits disk."""
    huge_image_block = {"type": "image", "source": {"data": "A" * 100_000}}
    tiny_text_block = {"type": "text", "text": "describe this"}
    msg = {"role": "user", "content": [huge_image_block, tiny_text_block]}

    out = _redact_message_for_trace(msg, max_chars=200)

    assert isinstance(out["content"], str), "oversized block list must be flattened, not stored raw"
    assert "A" * 1000 not in out["content"], "huge payload must not leak into the trace"
    assert "<image:" in out["content"], "non-text block should be summarized with type + size"
    assert "describe this" in out["content"], "text content should be preserved"


def test_non_text_block_under_cap_preserves_structure():
    """When the whole serialized content fits, structure is preserved."""
    msg = {"role": "user", "content": [{"type": "image", "source": "small"}, {"text": "hi"}]}
    out = _redact_message_for_trace(msg, max_chars=200)
    assert out["content"] == msg["content"]


def test_tracer_default_max_message_chars_applied(tmp_path):
    """Default cap kicks in for very long messages even without explicit config."""
    tracer = Tracer(storage=TraceStorage(root=str(tmp_path)), model="m")

    def llm(*, messages, tools):
        _ = messages, tools
        return {"text": "ok", "usage": {"input_tokens": 1, "output_tokens": 1}}

    huge = "y" * 50_000
    trace = new_trace(question="q", model="m")
    tracer.chat(messages=[{"role": "user", "content": huge}], llm_callable=llm, trace=trace)

    recorded = next(s for s in trace["steps"] if s["type"] == "request_sent")["messages"][0]
    assert "[truncated" in recorded["content"]
    # Default cap is 4000 chars + truncation marker
    assert 4000 <= len(recorded["content"]) < 4100
