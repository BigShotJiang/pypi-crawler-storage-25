from llmtrace import Tracer


def _parse(q: str) -> dict:
    return Tracer().parse_question(q)


def test_two_months_produces_period():
    out = _parse("why did revenue drop in April vs March?")
    assert out["entities"]["period"] == "April vs March"


def test_single_month_adds_assumption():
    out = _parse("how did revenue do in March?")
    assert out["entities"]["period"] == "March"
    assert any("previous month" in a.lower() for a in out["assumptions"])


def test_revenue_intent_suggests_sql():
    out = _parse("why did revenue drop?")
    assert out["intent"] == "metric_explanation"
    assert "sql" in out["suggested_tools"]


def test_sales_metric_label():
    out = _parse("why did sales fall in May?")
    assert out["entities"]["metric"] == "sales"


def test_no_metric_keyword_general_qa():
    out = _parse("what is the capital of France?")
    assert out["intent"] == "general_qa"
    assert out["suggested_tools"] == []


def test_metric_question_without_region_flags_missing_context():
    out = _parse("why did revenue drop in March?")
    assert "No region specified" in out["missing_context"]


def test_metric_question_with_region_no_missing_flag():
    out = _parse("why did revenue drop in EMEA region in March?")
    assert "No region specified" not in out["missing_context"]


def test_duplicate_months_dedup_in_order():
    out = _parse("compare March and March again to April")
    assert out["entities"]["period"] == "March vs April"
