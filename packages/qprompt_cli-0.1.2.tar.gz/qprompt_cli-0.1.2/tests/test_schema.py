from llmtrace.schema import add_step, new_trace, validate_trace


def test_new_trace_validates():
    t = new_trace(question="hi", model="m")
    ok, errs = validate_trace(t)
    assert ok, errs


def test_missing_top_field_invalid():
    t = new_trace(question="hi", model="m")
    del t["timestamp"]
    ok, errs = validate_trace(t)
    assert not ok
    assert any("timestamp" in e for e in errs)


def test_tool_call_step_requires_tool_and_status():
    t = new_trace(question="hi", model="m")
    add_step(t, {"type": "tool_call"})
    ok, errs = validate_trace(t)
    assert not ok
    assert any("tool name" in e for e in errs)
    assert any("status" in e for e in errs)


def test_evidence_requires_source_and_claim():
    t = new_trace(question="hi", model="m")
    t["evidence"].append({"evidence_id": "id1"})
    ok, errs = validate_trace(t)
    assert not ok
    assert any("source" in e for e in errs)
    assert any("claim" in e for e in errs)


def test_step_must_have_type():
    t = new_trace(question="hi", model="m")
    add_step(t, {"foo": "bar"})
    ok, errs = validate_trace(t)
    assert not ok
    assert any("missing type" in e for e in errs)


def test_steps_array_typecheck():
    t = new_trace(question="hi", model="m")
    t["steps"] = "not a list"
    ok, errs = validate_trace(t)
    assert not ok
    assert any("array" in e for e in errs)
