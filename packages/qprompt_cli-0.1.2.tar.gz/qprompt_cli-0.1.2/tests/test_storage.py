from llmtrace.schema import new_trace
from llmtrace.storage import TraceStorage


def test_save_and_load_by_path(tmp_path):
    s = TraceStorage(root=str(tmp_path))
    t = new_trace(question="q", model="m")
    p = s.save_trace(t)
    assert p.exists()
    loaded = s.load_trace(str(p))
    assert loaded["trace_id"] == t["trace_id"]


def test_load_by_id(tmp_path):
    s = TraceStorage(root=str(tmp_path))
    t = new_trace(question="q", model="m")
    s.save_trace(t)
    loaded = s.load_trace(t["trace_id"])
    assert loaded["trace_id"] == t["trace_id"]


def test_list_returns_paths(tmp_path):
    s = TraceStorage(root=str(tmp_path))
    for _ in range(3):
        s.save_trace(new_trace(question="q", model="m"))
    listed = s.list_trace_paths()
    assert len(listed) == 3


def test_list_empty_directory(tmp_path):
    s = TraceStorage(root=str(tmp_path / "nothing"))
    assert s.list_trace_paths() == []
