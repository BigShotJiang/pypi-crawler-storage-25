from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from uuid import uuid4


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_trace(question: str, model: str) -> dict[str, Any]:
    return {
        "trace_id": str(uuid4()),
        "question": question,
        "timestamp": utc_now_iso(),
        "model": model,
        "parsed": {
            "intent": "unknown",
            "entities": {},
            "assumptions": [],
            "missing_context": [],
            "suggested_tools": [],
        },
        "steps": [],
        "evidence": [],
        "final_answer": "",
        "risks": [],
    }


def add_step(trace: dict[str, Any], step: dict[str, Any]) -> None:
    steps = trace.setdefault("steps", [])
    steps.append(step)


def validate_trace(trace: dict[str, Any]) -> tuple[bool, list[str]]:
    """Validate a trace against the contract in `trace_schema.json`.

    Hand-rolled to keep the package zero-dependency. The JSON Schema file is
    the canonical contract for downstream consumers; this validator mirrors
    its required-field structure.
    """
    errors: list[str] = []

    required_top = [
        "trace_id",
        "question",
        "timestamp",
        "model",
        "parsed",
        "steps",
        "evidence",
        "final_answer",
        "risks",
    ]
    for key in required_top:
        if key not in trace:
            errors.append(f"missing top-level field: {key}")

    parsed = trace.get("parsed", {})
    if not isinstance(parsed, dict):
        errors.append("parsed must be an object")
    else:
        for key in ["intent", "entities", "assumptions"]:
            if key not in parsed:
                errors.append(f"missing parsed field: {key}")

    steps = trace.get("steps")
    if steps is not None and not isinstance(steps, list):
        errors.append("steps must be an array")
    elif isinstance(steps, list):
        for i, step in enumerate(steps):
            if not isinstance(step, dict):
                errors.append(f"steps[{i}] must be an object")
                continue
            if "type" not in step:
                errors.append(f"steps[{i}] missing type")
            if step.get("type") == "tool_call":
                if "tool" not in step:
                    errors.append(f"steps[{i}] tool_call missing tool name")
                if "status" not in step:
                    errors.append(f"steps[{i}] tool_call missing status")

    evidence = trace.get("evidence")
    if evidence is not None and not isinstance(evidence, list):
        errors.append("evidence must be an array")
    elif isinstance(evidence, list):
        for i, e in enumerate(evidence):
            if not isinstance(e, dict):
                errors.append(f"evidence[{i}] must be an object")
                continue
            if "source" not in e:
                errors.append(f"evidence[{i}] missing source")
            if "claim" not in e:
                errors.append(f"evidence[{i}] missing claim")

    risks = trace.get("risks")
    if risks is not None and not isinstance(risks, list):
        errors.append("risks must be an array")

    return (len(errors) == 0, errors)
