"""Demo flow used by `qprompt run` so the CLI produces a complete trace
out of the box. Production users should compose primitives directly;
see `examples/sql_agent.py` for the public reference path.
"""
from __future__ import annotations

from time import perf_counter
from typing import Any

from .schema import add_step, new_trace
from .tools import ToolRunResult, ToolTracer, traced_tool
from .tracer import Tracer, _content_text


@traced_tool("sql")
def _demo_sql(query: str) -> ToolRunResult:
    _ = query
    rows = [
        {"segment": "enterprise", "month": "March", "revenue_change_pct": -18},
        {"segment": "mid_market", "month": "March", "revenue_change_pct": -6},
    ]
    return ToolRunResult(value=rows, output_summary=f"returned {len(rows)} rows")


def run_demo(tracer: Tracer, question: str) -> tuple[dict[str, Any], str]:
    trace = new_trace(question=question, model=tracer.model)
    trace["is_demo"] = True
    add_step(trace, {"type": "input_received", "question": question})

    t0 = perf_counter()
    parsed = tracer.parse_question(question)
    trace["parsed"] = parsed
    add_step(
        trace,
        {
            "type": "question_parser",
            "output": parsed,
            "latency_ms": int((perf_counter() - t0) * 1000),
        },
    )

    sql_rows: list[dict[str, Any]] | None = None
    if "sql" in parsed.get("suggested_tools", []):
        tool_tracer = ToolTracer(trace)
        sql_rows = _demo_sql(
            "SELECT month, segment, revenue_change_pct FROM revenue_by_segment WHERE month='March'",
            _tool_tracer=tool_tracer,
        )
        if sql_rows:
            trace["evidence"].append(
                {
                    "source": "query_result",
                    "claim": "Enterprise revenue dropped 18%",
                    "evidence_id": "query_result_enterprise_drop",
                }
            )

    period = parsed.get("entities", {}).get("period")
    period_suffix = f" in {period}" if isinstance(period, str) and period else ""

    def mock(*, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> dict[str, Any]:
        _ = tools
        if sql_rows:
            text = (
                f"Revenue dropped mainly in enterprise (about 18% down{period_suffix}), "
                "with smaller declines in other segments."
            )
        else:
            text = f"Parsed question: {question}. No tool data was required for this answer."
        joined = " ".join(_content_text(m.get("content", "")) for m in messages)
        return {
            "text": text,
            "usage": {
                "input_tokens": max(1, len(joined.split())),
                "output_tokens": max(1, len(text.split())),
            },
        }

    answer = tracer.chat(
        messages=[
            {"role": "system", "content": "You are a concise analytics assistant."},
            {"role": "user", "content": question},
        ],
        llm_callable=mock,
        trace=trace,
        tools=[{"name": "sql", "description": "Query analytical warehouse"}],
    )
    trace["final_answer"] = answer

    path = tracer.finalize(trace)
    return trace, path
