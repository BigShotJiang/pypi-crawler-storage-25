from __future__ import annotations

import json
import re
from time import perf_counter
from typing import Any, Callable

from .audit import run_answer_audit
from .schema import add_step, new_trace, validate_trace
from .storage import TraceStorage


def _content_text(content: Any) -> str:
    """Coerce a message `content` field into plain text.

    Handles:
      - plain string (OpenAI legacy / simple shape)
      - list of content blocks (Anthropic / OpenAI tool-use shape)
      - anything else: stringified
    """
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict):
                if "text" in block:
                    parts.append(str(block["text"]))
                elif block.get("type") == "text":
                    parts.append(str(block.get("text", "")))
            elif isinstance(block, str):
                parts.append(block)
        return " ".join(parts)
    return str(content)


def _serialized_len(value: Any) -> int:
    try:
        return len(json.dumps(value, default=str))
    except (TypeError, ValueError):
        return len(str(value))


def _non_text_block_summary(content: Any) -> str:
    """Build a one-line summary of non-text blocks in a content list.

    e.g. `[{type: image, source: <bytes>}, {type: text, text: hi}]`
         -> `[non-text blocks: <image: 12345 chars>]`

    Returns "" if `content` is not a list or has no non-text blocks.
    """
    if not isinstance(content, list):
        return ""
    summaries: list[str] = []
    for block in content:
        if not isinstance(block, dict):
            continue
        block_type = block.get("type")
        is_text_block = block_type == "text" or "text" in block
        if not is_text_block and block_type:
            summaries.append(f"<{block_type}: {_serialized_len(block)} chars>")
    if not summaries:
        return ""
    return "[non-text blocks: " + ", ".join(summaries) + "]"


def _redact_message_for_trace(message: dict[str, Any], max_chars: int) -> dict[str, Any]:
    """Return a shallow copy of `message` with `content` capped at `max_chars`.

    The cap is measured on the serialized JSON length of the content, so it
    catches non-text payloads (images, tool blocks) that would otherwise slip
    past a flatten-to-text check. Under cap, the original content (block
    structure included) is preserved. Over cap, content is replaced with a
    flattened text + non-text-block summary, then truncated.

    The full original message is still passed to the LLM — only the trace
    snapshot is redacted.
    """
    redacted = dict(message)
    if "content" not in redacted:
        return redacted
    content = redacted["content"]

    if _serialized_len(content) <= max_chars:
        return redacted

    text = _content_text(content)
    non_text_summary = _non_text_block_summary(content)
    combined = text
    if non_text_summary:
        combined = (combined + " " + non_text_summary).strip() if combined else non_text_summary

    if len(combined) > max_chars:
        overflow = len(combined) - max_chars
        combined = combined[:max_chars] + f"... [truncated, {overflow} more chars]"

    redacted["content"] = combined
    return redacted


def _stub_llm(*, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> dict[str, Any]:
    _ = tools
    user_text = ""
    for m in reversed(messages):
        if m.get("role") == "user":
            user_text = _content_text(m.get("content", ""))
            break
    text = (
        f"[stub] No real LLM configured. Question received: {user_text!r}. "
        "Pass a real `llm_callable` to Tracer.run for generated answers."
    )
    return {
        "text": text,
        "usage": {"input_tokens": 1, "output_tokens": max(1, len(text.split()))},
    }


DEFAULT_MAX_MESSAGE_CHARS = 4000


class Tracer:
    def __init__(
        self,
        storage: TraceStorage | None = None,
        model: str = "mock-gpt",
        max_message_chars: int = DEFAULT_MAX_MESSAGE_CHARS,
    ) -> None:
        self.storage = storage or TraceStorage()
        self.model = model
        self.max_message_chars = max_message_chars

    def parse_question(self, question: str) -> dict[str, Any]:
        q = question.lower()
        intent = "general_qa"
        entities: dict[str, Any] = {}
        assumptions: list[str] = []
        missing_context: list[str] = []
        suggested_tools: list[str] = []

        if "revenue" in q or "sales" in q:
            intent = "metric_explanation"
            entities["metric"] = "revenue" if "revenue" in q else "sales"
            suggested_tools.append("sql")

        month_names = [
            "january",
            "february",
            "march",
            "april",
            "may",
            "june",
            "july",
            "august",
            "september",
            "october",
            "november",
            "december",
        ]
        month_pattern = r"\b(" + "|".join(month_names) + r")\b"
        months_found = [m.group(1) for m in re.finditer(month_pattern, q)]
        months_unique_in_order: list[str] = []
        for month in months_found:
            if month not in months_unique_in_order:
                months_unique_in_order.append(month)
        months_title = [m.title() for m in months_unique_in_order]

        if len(months_title) >= 2:
            entities["period"] = f"{months_title[0]} vs {months_title[1]}"
        elif len(months_title) == 1:
            entities["period"] = months_title[0]
            assumptions.append(f"Compare {months_title[0]} to previous month")

        if intent == "metric_explanation" and "region" not in q:
            missing_context.append("No region specified")

        return {
            "intent": intent,
            "entities": entities,
            "assumptions": assumptions,
            "missing_context": missing_context,
            "suggested_tools": suggested_tools,
        }

    def chat(
        self,
        *,
        messages: list[dict[str, Any]],
        llm_callable: Callable[..., Any],
        trace: dict[str, Any],
        tools: list[dict[str, Any]] | None = None,
    ) -> str:
        def _as_int(value: Any, fallback: int) -> int:
            try:
                return int(value)
            except (TypeError, ValueError):
                return fallback

        redacted_messages = [
            _redact_message_for_trace(m, self.max_message_chars) for m in messages
        ]
        add_step(
            trace,
            {
                "type": "request_sent",
                "messages": redacted_messages,
                "tools_available": tools or [],
                "model": self.model,
            },
        )

        t0 = perf_counter()
        try:
            response = llm_callable(messages=messages, tools=tools or [])
        except Exception as exc:
            elapsed_ms = int((perf_counter() - t0) * 1000)
            add_step(
                trace,
                {
                    "type": "model_error",
                    "latency_ms": elapsed_ms,
                    "error": str(exc),
                },
            )
            raise

        elapsed_ms = int((perf_counter() - t0) * 1000)

        if not isinstance(response, dict):
            response = {"text": str(response), "usage": {}}

        answer = str(response.get("text", ""))
        usage = response.get("usage", {})
        joined_input = " ".join(_content_text(m.get("content", "")) for m in messages)
        add_step(
            trace,
            {
                "type": "model_response",
                "latency_ms": elapsed_ms,
                "tokens": {
                    "input_estimate": _as_int(
                        usage.get("input_tokens"),
                        max(1, len(joined_input.split())),
                    ),
                    "output_estimate": _as_int(
                        usage.get("output_tokens"),
                        max(1, len(answer.split())),
                    ),
                },
            },
        )
        return answer

    def finalize(self, trace: dict[str, Any]) -> str:
        """Run audit, validate, and persist the trace. Returns the saved path."""
        audit = run_answer_audit(trace)
        add_step(trace, {"type": "answer_audit", "output": audit})
        trace["risks"] = audit.get("risk_flags", [])

        ok, errors = validate_trace(trace)
        if not ok:
            raise ValueError(f"Trace validation failed: {errors}")

        return str(self.storage.save_trace(trace))

    def run(
        self,
        question: str,
        llm_callable: Callable[..., Any] | None = None,
    ) -> tuple[dict[str, Any], str]:
        """Convenience: parse + LLM call + finalize. No tools.

        For tool-using flows, compose the primitives directly: `new_trace`,
        `parse_question`, run your tools (logging via `ToolTracer`), `chat`,
        then `finalize`. See `examples/sql_agent.py`.
        """
        trace = new_trace(question=question, model=self.model)
        add_step(trace, {"type": "input_received", "question": question})

        t0 = perf_counter()
        parsed = self.parse_question(question)
        trace["parsed"] = parsed
        add_step(
            trace,
            {
                "type": "question_parser",
                "output": parsed,
                "latency_ms": int((perf_counter() - t0) * 1000),
            },
        )

        callable_ = llm_callable or _stub_llm
        messages = [
            {"role": "system", "content": "You are a concise analytics assistant."},
            {"role": "user", "content": question},
        ]
        try:
            answer = self.chat(messages=messages, llm_callable=callable_, trace=trace, tools=[])
        except Exception:
            # Persist the partial trace (including the model_error step that
            # `chat` already appended) so the failure is debuggable, then re-raise.
            self.finalize(trace)
            raise
        trace["final_answer"] = answer

        return trace, self.finalize(trace)
