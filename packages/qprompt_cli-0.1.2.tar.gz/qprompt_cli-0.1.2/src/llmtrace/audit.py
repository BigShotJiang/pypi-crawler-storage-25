from __future__ import annotations

import re
from typing import Any


PROCESS_CLAIM_PATTERNS: tuple[re.Pattern[str], ...] = tuple(
    re.compile(p, re.IGNORECASE)
    for p in (
        r"\bi\s+(?:queried|ran|fetched|pulled|executed|called|searched|looked\s+up)\b",
        r"\b(?:queried|ran|fetched|pulled|executed)\s+(?:the\s+|a\s+|an\s+)?(?:sql|database|db|query|api|tool|warehouse)\b",
        r"\baccording\s+to\s+(?:the\s+)?(?:database|query|sql|tool|results?|data)\b",
        r"\bthe\s+(?:sql\s+|query\s+|tool\s+)?results?\s+(?:show|indicate|suggest|reveal)\b",
        r"\bbased\s+on\s+(?:the\s+)?(?:query|database|sql|tool)\s+(?:results?|output|data)\b",
    )
)


def _truncate(text: str, max_len: int = 180) -> str:
    if len(text) <= max_len:
        return text
    return text[:max_len] + "... [truncated]"


def _detect_process_claims(answer: str) -> list[str]:
    """Return phrases in `answer` that imply tool execution actually happened."""
    found: list[str] = []
    for pattern in PROCESS_CLAIM_PATTERNS:
        match = pattern.search(answer)
        if match:
            found.append(match.group(0))
    return found


def run_answer_audit(trace: dict[str, Any]) -> dict[str, Any]:
    final_answer = trace.get("final_answer", "")
    evidence = trace.get("evidence", [])
    parsed = trace.get("parsed", {})
    steps = trace.get("steps", [])

    successful_tool_calls = [
        s for s in steps if s.get("type") == "tool_call" and s.get("status") == "ok"
    ]
    failed_tool_calls = [
        s for s in steps if s.get("type") == "tool_call" and s.get("status") == "error"
    ]

    claims: list[dict[str, Any]] = []
    unsupported: list[str] = []
    risk_flags: list[str] = []

    process_phrases = _detect_process_claims(final_answer)
    if process_phrases:
        joined = ", ".join(f'"{p}"' for p in process_phrases[:3])
        if not successful_tool_calls:
            unsupported.append(
                f"Answer claims tool execution ({joined}) but no successful tool_call recorded"
            )
            risk_flags.append(
                "Unsupported process claim: answer references tool work that did not run"
            )
        elif failed_tool_calls:
            # Some tool work happened, but other calls failed. The answer's
            # specific claims may correspond to the failed call(s); the auditor
            # cannot verify claim->tool mapping, so escalate for human review.
            unsupported.append(
                f"Answer claims tool execution ({joined}) alongside failed tool calls; "
                "verify each claim corresponds to a successful call"
            )
            risk_flags.append(
                "Mixed tool execution: process claims present alongside failed tool call(s)"
            )

    for e in evidence:
        claim_text = e.get("claim")
        if claim_text:
            claims.append(
                {
                    "claim": claim_text,
                    "evidence": e.get("evidence_id"),
                    "confidence": "medium",
                }
            )

    intent = str(parsed.get("intent", ""))
    analysis_intents = {"metric_explanation", "metric_root_cause_analysis"}
    # The default stub callable explicitly disclaims tool/LLM execution; treating
    # it as an unsupported analytic claim is just noise during setup.
    is_stub_answer = final_answer.startswith("[stub]")
    if not evidence and final_answer and intent in analysis_intents and not is_stub_answer:
        unsupported.append(
            "Answer contains analysis claims but no evidence records attached"
        )
        risk_flags.append("Analysis answer without evidence")

    if parsed.get("missing_context"):
        risk_flags.extend(f"Missing context: {x}" for x in parsed["missing_context"])

    for step in failed_tool_calls:
        tool_name = step.get("tool", "unknown_tool")
        error_text = _truncate(str(step.get("error", "unknown error")))
        risk_flags.append(f"Tool call failed ({tool_name}): {error_text}")

    for step in steps:
        if step.get("type") == "model_error":
            error_text = _truncate(str(step.get("error", "unknown error")))
            risk_flags.append(f"Model call failed: {error_text}")

    unique_risks = list(dict.fromkeys(risk_flags))
    evidence_ids = sorted(e.get("evidence_id") for e in evidence if e.get("evidence_id"))

    return {
        "claims": claims,
        "unsupported_claims": unsupported,
        "assumptions_used": parsed.get("assumptions", []),
        "risk_flags": unique_risks,
        "evidence_ids": evidence_ids,
    }
