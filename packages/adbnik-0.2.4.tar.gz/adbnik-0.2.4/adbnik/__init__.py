__version__ = "0.2.4"
APP_TITLE = "Adbnik"
