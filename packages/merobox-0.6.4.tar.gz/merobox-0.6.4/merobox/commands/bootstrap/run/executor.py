"""
Main workflow executor - Orchestrates workflow execution and manages the overall process.
"""

import asyncio
import os
import re
import time
import uuid
from typing import Any, Optional

import docker
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)

from merobox.commands.auth import AUTH_METHOD_NONE, AuthenticationError, AuthManager
from merobox.commands.bootstrap.steps import (
    AddGroupMembersStep,
    CreateContextStep,
    CreateGroupInNamespaceStep,
    CreateIdentityStep,
    CreateNamespaceInvitationStep,
    CreateNamespaceStep,
    DeleteContextStep,
    DeleteGroupStep,
    DeleteNamespaceStep,
    DetachContextFromGroupStep,
    ExecuteStep,
    GetGroupInfoStep,
    GetGroupUpgradeStatusStep,
    GetMemberCapabilitiesStep,
    GetNamespaceIdentityStep,
    InstallApplicationStep,
    InviteOpenStep,
    JoinContextStep,
    JoinNamespaceStep,
    JoinOpenStep,
    LeaveContextStep,
    LeaveGroupStep,
    LeaveNamespaceStep,
    ListGroupContextsStep,
    ListGroupMembersStep,
    ListNamespaceGroupsStep,
    ListNamespacesStep,
    ListSubgroupsStep,
    ParallelStep,
    RegisterGroupSigningKeyStep,
    RemoveGroupMembersStep,
    ReparentGroupStep,
    RepeatStep,
    RetryGroupUpgradeStep,
    ScriptStep,
    SetDefaultCapabilitiesStep,
    SetGroupAliasStep,
    SetMemberAliasStep,
    SetMemberCapabilitiesStep,
    SetSubgroupVisibilityStep,
    SyncGroupStep,
    UninstallApplicationStep,
    UpdateGroupSettingsStep,
    UpdateMemberRoleStep,
    UpgradeGroupStep,
    UploadBlobStep,
    WaitForSyncStep,
    WaitStep,
)
from merobox.commands.bootstrap.steps.assertion import AssertStep
from merobox.commands.bootstrap.steps.fuzzy_test import FuzzyTestStep
from merobox.commands.bootstrap.steps.json_assertion import JsonAssertStep
from merobox.commands.bootstrap.steps.mesh import CreateMeshStep
from merobox.commands.bootstrap.steps.proposals import (
    GetProposalApproversStep,
    GetProposalStep,
    ListProposalsStep,
)
from merobox.commands.constants import (
    ASYNC_POLL_INTERVAL,
    DEFAULT_P2P_PORT,
    DEFAULT_RPC_PORT,
    NODE_READY_TIMEOUT,
    RESERVED_NODE_CONFIG_KEYS,
)
from merobox.commands.health import check_node_health
from merobox.commands.manager import DockerManager
from merobox.commands.node_resolver import NodeResolver, get_resolver
from merobox.commands.utils import console, get_node_rpc_url

# Compiled regex pattern for extracting {{variable}} references
_VAR_PATTERN = re.compile(r"\{\{(\w+)\}\}")


class WorkflowExecutor:
    """Executes Calimero workflows based on YAML configuration."""

    def __init__(
        self,
        config: dict[str, Any],
        manager: Optional[DockerManager] = None,
        image: Optional[str] = None,
        auth_service: bool = False,
        auth_image: str = None,
        auth_use_cached: bool = False,
        webui_use_cached: bool = False,
        log_level: str = "debug",
        rust_backtrace: str = "0",
        e2e_mode: bool = False,
        workflow_dir: str = None,
        auth_mode: Optional[str] = None,
        auth_username: Optional[str] = None,
        auth_password: Optional[str] = None,
        dry_run: bool = False,
    ):
        self.config = config
        self.manager = manager
        self.workflow_dir = workflow_dir or "."
        self.dry_run = dry_run

        # Embedded auth credentials
        self.auth_username = auth_username
        self.auth_password = auth_password

        # Determine if we're in binary mode
        self.is_binary_mode = (
            manager is not None
            and hasattr(manager, "binary_path")
            and manager.binary_path is not None
        )

        # Auth service can be enabled by CLI flag or workflow config (CLI takes precedence)
        self.auth_service = auth_service or config.get("auth_service", False)
        # Auth image can be set by CLI flag or workflow config (CLI takes precedence)
        self.auth_image = (
            auth_image if auth_image is not None else config.get("auth_image", None)
        )
        # Auth use cached can be enabled by CLI flag or workflow config (CLI takes precedence)
        self.auth_use_cached = auth_use_cached or config.get("auth_use_cached", False)
        # WebUI use cached can be enabled by CLI flag or workflow config (CLI takes precedence)
        self.webui_use_cached = webui_use_cached or config.get(
            "webui_use_cached", False
        )
        # Log level can be set by CLI flag or workflow config (CLI takes precedence)
        self.log_level = (
            log_level if log_level is not None else config.get("log_level", "debug")
        )
        # Log level can be set by CLI flag or workflow config (CLI takes precedence)
        self.rust_backtrace = (
            rust_backtrace
            if rust_backtrace is not None
            else config.get("rust_backtrace", "0")
        )
        # E2E mode can be enabled by CLI flag or workflow config (CLI takes precedence)
        self.e2e_mode = e2e_mode or config.get("e2e_mode", False)

        # Bootstrap nodes can be specified in workflow config to override e2e_mode's empty default
        self.bootstrap_nodes = config.get("bootstrap_nodes", None)

        # Generate unique workflow ID for test isolation (like e2e tests)
        self.workflow_id = str(uuid.uuid4())[:8]

        # Auth mode for binary mode (can be set by CLI or workflow config, CLI takes precedence)
        self.auth_mode = auth_mode or config.get("auth_mode", None)

        # Remote nodes configuration
        self.remote_nodes_config = config.get("remote_nodes", {})

        # Initialize node resolver with current manager
        # Will be set up properly after manager is confirmed
        self.resolver: Optional[NodeResolver] = None

        try:
            console.print(
                f"[cyan]WorkflowExecutor: resolved log_level='{self.log_level}', binary_mode={self.is_binary_mode}[/cyan]"
            )
            console.print(
                f"[cyan]WorkflowExecutor: workflow_id='{self.workflow_id}' (for test isolation)[/cyan]"
            )
        except Exception:
            pass
        try:
            console.print(
                f"[cyan]WorkflowExecutor: resolved rust_backtrace='{self.rust_backtrace}', binary_mode={self.is_binary_mode}[/cyan]"
            )
        except Exception:
            pass
        self.workflow_results = {}
        self.dynamic_values = {}  # Store dynamic values for later use
        # Node image can be overridden by CLI flag; otherwise from config; else default in manager
        self.image = image

    async def execute_workflow(self) -> bool:
        """Execute the complete workflow."""
        workflow_name = self.config.get("name", "Unnamed Workflow")

        # Handle dry-run mode
        if self.dry_run:
            return await self._execute_dry_run(workflow_name)

        console.print(
            f"\n[bold blue]🚀 Executing Workflow: {workflow_name}[/bold blue]"
        )

        # Set up the node resolver
        self._setup_resolver()

        # Determine if we have local nodes to manage
        has_local_nodes = self._has_local_nodes()
        has_remote_nodes = self._has_remote_nodes()

        if has_remote_nodes and not has_local_nodes:
            console.print(
                "[cyan]Running in remote-only mode (no local nodes to start)[/cyan]"
            )
        elif has_remote_nodes and has_local_nodes:
            console.print("[cyan]Running in mixed mode (local + remote nodes)[/cyan]")

        try:
            # Check if we should nuke on start
            nuke_on_start = self.config.get("nuke_on_start", False)
            if nuke_on_start:
                console.print(
                    "\n[bold red]💥 Nuking all data before workflow ...[/bold red]"
                )
                if not self._nuke_data():
                    console.print(
                        "[yellow]⚠️  Warning: Nuke operation encountered issues, continuing anyway...[/yellow]"
                    )
                else:
                    console.print("[green]✓ Nuke on start completed[/green]")
                time.sleep(2)  # Give time for cleanup

            # Check if we should force pull images (only for Docker mode)
            force_pull_images = self.config.get("force_pull_image", False)
            if force_pull_images:
                if self.is_binary_mode:
                    console.print(
                        "\n[cyan]Skipping image pull in binary (no-docker) mode[/cyan]"
                    )
                else:
                    console.print(
                        "\n[bold yellow]🔄 Force pulling workflow images (force_pull_image=true)...[/bold yellow]"
                    )
                    await self._force_pull_workflow_images()
                    console.print("[green]✓ Image force pull completed[/green]")

            # Check if we should restart nodes at the beginning
            restart_nodes = self.config.get("restart", False)
            stop_all_nodes = self.config.get("stop_all_nodes", False)
            nuke_on_end = self.config.get("nuke_on_end", False)

            # Steps 1-3: Local node management (skip if remote-only mode)
            if has_local_nodes:
                # Step 1: Restart nodes if requested (at beginning)
                if restart_nodes:
                    console.print(
                        "\n[bold yellow]Step 1: Restarting workflow nodes (restart=true)...[/bold yellow]"
                    )
                    if not self.manager.stop_all_nodes():
                        console.print(
                            "[red]❌ Failed to stop workflow nodes - stopping workflow[/red]"
                        )
                        if stop_all_nodes:
                            self._stop_nodes_on_failure()
                        return False
                    console.print("[green]✓ Workflow nodes stopped[/green]")
                    time.sleep(2)  # Give time for cleanup
                else:
                    console.print(
                        "\n[bold blue]Step 1: Checking workflow nodes (restart=false)...[/bold blue]"
                    )
                    console.print(
                        "[cyan]Will reuse existing nodes if they're running...[/cyan]"
                    )

                # Step 2: Manage nodes
                console.print("\n[bold yellow]Step 2: Managing nodes...[/bold yellow]")
                if not await self._start_nodes(restart_nodes):
                    console.print(
                        "[red]❌ Node management failed - stopping workflow[/red]"
                    )
                    if stop_all_nodes:
                        self._stop_nodes_on_failure()
                    return False

                # Step 3: Wait for nodes to be ready
                console.print(
                    "\n[bold yellow]Step 3: Waiting for nodes to be ready...[/bold yellow]"
                )
                if not await self._wait_for_nodes_ready():
                    console.print("[red]❌ Nodes not ready - stopping workflow[/red]")
                    if stop_all_nodes:
                        self._stop_nodes_on_failure()
                    return False

                # Step 3b: Authenticate with nodes if embedded auth is enabled
                if (
                    self.auth_mode == "embedded"
                    and self.auth_username
                    and self.auth_password
                ):
                    console.print(
                        "\n[bold yellow]Step 3b: Authenticating with embedded auth nodes...[/bold yellow]"
                    )
                    if not await self._authenticate_with_embedded_auth_nodes():
                        console.print(
                            "[red]❌ Failed to authenticate with nodes - stopping workflow[/red]"
                        )
                        if stop_all_nodes:
                            self._stop_nodes_on_failure()
                        return False
            else:
                console.print(
                    "\n[bold blue]Steps 1-3: Skipped (no local nodes to manage)[/bold blue]"
                )

            # Step 4: Execute workflow steps
            console.print(
                "\n[bold yellow]Step 4: Executing workflow steps...[/bold yellow]"
            )
            if not await self._execute_workflow_steps():
                console.print("[red]❌ Workflow steps failed - stopping workflow[/red]")
                if stop_all_nodes:
                    self._stop_nodes_on_failure()
                return False

            # Step 5: Stop all nodes if requested (at end) - only if we have local nodes
            if has_local_nodes:
                if stop_all_nodes:
                    console.print(
                        "\n[bold yellow]Step 5: Stopping all nodes (stop_all_nodes=true)...[/bold yellow]"
                    )
                    if not self.manager.stop_all_nodes():
                        console.print("[red]Failed to stop all nodes[/red]")
                        # Don't return False here as workflow completed successfully
                    else:
                        console.print("[green]✓ All nodes stopped[/green]")
                else:
                    console.print(
                        "\n[bold blue]Step 5: Leaving nodes running (stop_all_nodes=false)...[/bold blue]"
                    )
                    console.print(
                        "[cyan]Nodes will continue running for future workflows[/cyan]"
                    )
            else:
                console.print(
                    "\n[bold blue]Step 5: Skipped (no local nodes to stop)[/bold blue]"
                )

            # Step 6: Nuke on end if requested
            if nuke_on_end:
                console.print(
                    "\n[bold red]💥 Nuking all data after workflow ...[/bold red]"
                )
                if not self._nuke_data():
                    console.print(
                        "[yellow]⚠️  Warning: Nuke operation encountered issues[/yellow]"
                    )
                else:
                    console.print("[green]✓ Nuke on end completed[/green]")

            console.print(
                f"\n[bold green]🎉 Workflow '{workflow_name}' completed successfully![/bold green]"
            )

            # Display captured dynamic values
            if self.dynamic_values:
                console.print("\n[bold]📋 Captured Dynamic Values:[/bold]")
                for key, value in self.dynamic_values.items():
                    console.print(f"  {key}: {value}")

            return True

        except Exception as e:
            console.print(f"\n[red]❌ Workflow failed with error: {str(e)}[/red]")
            stop_all_nodes = self.config.get("stop_all_nodes", False)
            if stop_all_nodes:
                self._stop_nodes_on_failure()
            return False

    async def _execute_dry_run(self, workflow_name: str) -> bool:
        """
        Execute workflow validation in dry-run mode.

        This validates the workflow configuration without executing any steps:
        - Validates config structure and required fields
        - Resolves and displays variable references
        - Checks node availability (local and remote)
        - Reports what steps would be executed

        Note: This method is async to maintain interface compatibility with
        execute_workflow() and to support future remote node connectivity checks.

        Args:
            workflow_name: Name of the workflow for display

        Returns:
            True if validation passed, False otherwise
        """
        console.print(
            f"\n[bold cyan]🔍 Dry-run validation: {workflow_name}[/bold cyan]"
        )
        console.print("[cyan]Validating workflow without executing steps...[/cyan]\n")

        validation_errors: list[str] = []
        warnings: list[str] = []

        # Run validation phases
        self._dry_run_validate_config(validation_errors)
        self._dry_run_validate_nodes(validation_errors)
        self._dry_run_validate_node_refs(validation_errors)
        self._dry_run_check_remote_nodes()
        self._dry_run_analyze_steps(warnings)

        # Print summary and return result
        return self._dry_run_print_summary(workflow_name, validation_errors, warnings)

    def _dry_run_validate_config(self, errors: list[str]) -> None:
        """Validate configuration structure in dry-run mode."""
        console.print("[bold]Step 1: Validating configuration structure...[/bold]")
        try:
            from merobox.commands.bootstrap.config import validate_workflow_config

            config_errors = validate_workflow_config(self.config)
            if config_errors:
                for error in config_errors:
                    errors.append(f"Config: {error}")
                    console.print(f"  [red]✗ {error}[/red]")
            else:
                console.print("  [green]✓ Configuration structure is valid[/green]")
        except Exception as e:
            errors.append(f"Config validation error: {str(e)}")
            console.print(f"  [red]✗ Config validation error: {str(e)}[/red]")

    def _dry_run_validate_nodes(self, errors: list[str]) -> None:
        """Validate node configuration in dry-run mode."""
        console.print("\n[bold]Step 2: Checking node configuration...[/bold]")
        try:
            self._setup_resolver()

            local_nodes = self._get_local_node_names()
            remote_nodes = self._get_remote_node_names()

            if local_nodes:
                console.print(
                    f"  [cyan]Local nodes configured: {', '.join(sorted(local_nodes))}[/cyan]"
                )
            if remote_nodes:
                console.print(
                    f"  [cyan]Remote nodes configured: {', '.join(sorted(remote_nodes))}[/cyan]"
                )

            if not local_nodes and not remote_nodes:
                errors.append("No nodes configured (local or remote)")
                console.print("  [red]✗ No nodes configured[/red]")
            else:
                console.print("  [green]✓ Node configuration is valid[/green]")
        except Exception as e:
            errors.append(f"Node configuration error: {str(e)}")
            console.print(f"  [red]✗ Node configuration error: {str(e)}[/red]")

    def _dry_run_validate_node_refs(self, errors: list[str]) -> None:
        """Validate node references in steps during dry-run."""
        console.print("\n[bold]Step 3: Validating node references in steps...[/bold]")
        invalid_refs = self._get_invalid_node_references()
        if invalid_refs:
            for ref_error in invalid_refs:
                errors.append(ref_error)
                console.print(f"  [red]✗ {ref_error}[/red]")
        else:
            console.print("  [green]✓ All node references are valid[/green]")

    def _get_invalid_node_references(self) -> list[str]:
        """Get list of invalid node reference errors for dry-run reporting."""
        steps = self.config.get("steps", [])
        if not steps:
            return []

        valid_nodes = self._get_valid_node_names()
        referenced_nodes: set[str] = set()
        for step in steps:
            referenced_nodes.update(self._extract_node_references_from_step(step))

        errors: list[str] = []
        if not valid_nodes:
            if referenced_nodes:
                errors.append(
                    f"Workflow references nodes but none configured: "
                    f"{', '.join(sorted(referenced_nodes))}"
                )
        else:
            invalid_nodes = referenced_nodes - valid_nodes
            if invalid_nodes:
                errors.append(
                    f"References non-existent nodes: {', '.join(sorted(invalid_nodes))}"
                )
        return errors

    def _dry_run_check_remote_nodes(self) -> None:
        """Check remote node availability in dry-run mode."""
        console.print("\n[bold]Step 4: Checking remote node availability...[/bold]")
        remote_nodes_config = self.config.get("remote_nodes", {})
        if remote_nodes_config:
            for node_name, node_config in remote_nodes_config.items():
                url = node_config.get("url", "N/A")
                auth_config = node_config.get("auth", {})
                auth_method = auth_config.get("method", "none")
                console.print(
                    f"  [cyan]• {node_name}: {url} (auth: {auth_method})[/cyan]"
                )
            console.print(
                "  [yellow]ℹ Remote node connectivity not verified in dry-run[/yellow]"
            )
        else:
            console.print("  [dim]No remote nodes configured[/dim]")

    def _dry_run_analyze_steps(self, warnings: list[str]) -> None:
        """Analyze workflow steps and variable resolution in dry-run mode."""
        console.print("\n[bold]Step 5: Analyzing workflow steps...[/bold]")
        steps = self.config.get("steps", [])
        if not steps:
            warnings.append("No workflow steps defined")
            console.print("  [yellow]⚠ No workflow steps defined[/yellow]")
            return

        console.print(f"  [cyan]Total steps: {len(steps)}[/cyan]")

        # Track variables incrementally - check each step against prior steps
        available_vars: set[str] = set()
        forward_ref_warnings: list[str] = []

        for i, step in enumerate(steps, 1):
            step_type = step.get("type", "unknown")
            step_name = step.get("name", f"Step {i}")

            # Get variables consumed by this step (exclude 'outputs' to avoid false positives)
            step_for_vars = {k: v for k, v in step.items() if k != "outputs"}
            step_vars = self._extract_variable_references(step_for_vars)

            # Check for variables used before they're defined
            undefined_in_step = step_vars - available_vars
            if undefined_in_step:
                forward_ref_warnings.append(
                    f"Step {i} '{step_name}': uses undefined variables: "
                    f"{', '.join(sorted(undefined_in_step))}"
                )

            # Add output variables to available set for subsequent steps
            outputs = step.get("outputs")
            if outputs:
                if isinstance(outputs, dict):
                    available_vars.update(outputs.keys())
                else:
                    forward_ref_warnings.append(
                        f"Step {i} '{step_name}': 'outputs' should be a dict, got {type(outputs).__name__}"
                    )

            # Display step info
            node = step.get("node", "N/A")
            console.print(f"  [{i}] {step_name} ({step_type}) → node: {node}")

            if outputs and isinstance(outputs, dict):
                console.print(f"      [dim]outputs: {', '.join(outputs.keys())}[/dim]")
            if step_vars:
                console.print(
                    f"      [dim]uses variables: {', '.join(sorted(step_vars))}[/dim]"
                )

        # Report forward reference warnings
        if forward_ref_warnings:
            for warning in forward_ref_warnings:
                warnings.append(warning)
                console.print(f"\n  [yellow]⚠ {warning}[/yellow]")

        console.print("\n  [green]✓ Step analysis complete[/green]")

    def _dry_run_print_summary(
        self, workflow_name: str, errors: list[str], warnings: list[str]
    ) -> bool:
        """Print dry-run summary and return validation result."""
        console.print("\n" + "=" * 60)
        console.print("[bold]Dry-run Summary:[/bold]")

        if errors:
            console.print(
                f"\n[red]❌ Validation failed with {len(errors)} error(s):[/red]"
            )
            for error in errors:
                console.print(f"  [red]• {error}[/red]")
        else:
            console.print("\n[green]✓ Configuration validation passed[/green]")

        if warnings:
            console.print(f"\n[yellow]⚠ {len(warnings)} warning(s):[/yellow]")
            for warning in warnings:
                console.print(f"  [yellow]• {warning}[/yellow]")

        if not errors:
            console.print(
                f"\n[bold green]✅ Workflow '{workflow_name}' is ready for execution[/bold green]"
            )
            return True
        else:
            console.print(
                f"\n[bold red]❌ Workflow '{workflow_name}' has validation errors[/bold red]"
            )
            return False

    def _extract_variable_references(self, obj: Any) -> set[str]:
        """
        Extract variable references ({{var_name}}) from a step configuration.

        Args:
            obj: The object to scan (can be dict, list, or string)

        Returns:
            Set of variable names referenced
        """
        variables: set[str] = set()

        if isinstance(obj, str):
            matches = _VAR_PATTERN.findall(obj)
            variables.update(matches)
        elif isinstance(obj, dict):
            for value in obj.values():
                variables.update(self._extract_variable_references(value))
        elif isinstance(obj, list):
            for item in obj:
                variables.update(self._extract_variable_references(item))

        return variables

    def _stop_nodes_on_failure(self) -> None:
        """
        Stop all nodes when workflow fails, if stop_all_nodes is configured.
        This ensures nodes are cleaned up even on failure.
        """
        console.print(
            "\n[bold yellow]Stopping all nodes due to workflow failure (stop_all_nodes=true)...[/bold yellow]"
        )
        if not self.manager.stop_all_nodes():
            console.print("[red]Failed to stop all nodes[/red]")
        else:
            console.print("[green]✓ All nodes stopped[/green]")

    def _nuke_data(self, prefix: str = None) -> bool:
        """
        Execute nuke operation to clean all data.

        Args:
            prefix: Optional prefix to filter which nodes to nuke

        Returns:
            bool: True if nuke succeeded, False otherwise
        """
        try:
            from merobox.commands.nuke import execute_nuke

            # If no prefix specified, derive from workflow nodes config
            if prefix is None:
                nodes_config = self.config.get("nodes", {})
                prefix = nodes_config.get("prefix", None)

            return execute_nuke(
                manager=self.manager,
                prefix=prefix,
                verbose=False,
                silent=False,
            )
        except Exception as e:
            console.print(f"[red]Nuke operation failed: {str(e)}[/red]")
            return False

    async def _force_pull_workflow_images(self) -> None:
        """Force pull all Docker images specified in the workflow configuration."""
        # Only applicable in Docker mode
        if self.is_binary_mode:
            return

        try:
            # Get image from nodes configuration
            nodes_config = self.config.get("nodes", {})
            if isinstance(nodes_config, dict):
                image = nodes_config.get("image")
                if image:
                    console.print(
                        f"[yellow]Force pulling workflow image: {image}[/yellow]"
                    )
                    try:
                        if not self.manager.force_pull_image(image):
                            console.print(
                                f"[red]Warning: Failed to force pull image: {image}[/red]"
                            )
                            console.print(
                                "[yellow]Workflow will continue with existing image[/yellow]"
                            )
                    except Exception as e:
                        console.print(
                            f"[red]Warning: force_pull_image failed for image: {image} - {e}[/red]"
                        )

                # Check for images in individual node configurations
                for node_name, node_config in nodes_config.items():
                    if isinstance(node_config, dict) and "image" in node_config:
                        image = node_config["image"]
                        console.print(
                            f"[yellow]Force pulling image for node {node_name}: {image}[/yellow]"
                        )
                        try:
                            if not self.manager.force_pull_image(image):
                                console.print(
                                    f"[red]Warning: Failed to force pull image for {node_name}: {image}[/red]"
                                )
                                console.print(
                                    "[yellow]Workflow will continue with existing image[/yellow]"
                                )
                        except Exception as e:
                            console.print(
                                f"[red]Warning: force_pull_image failed for node {node_name}: {image} - {e}[/red]"
                            )

        except Exception as e:
            console.print(f"[red]Error during force pull: {str(e)}[/red]")
            console.print(
                "[yellow]Workflow will continue with existing images[/yellow]"
            )

    def _is_node_running(self, node_name: str) -> bool:
        """Check if a node is running (works for both binary and Docker mode)."""
        try:
            if hasattr(self.manager, "is_node_running"):
                return self.manager.is_node_running(node_name)

            # Fallback to Docker client (Docker mode only)
            if not self.is_binary_mode and hasattr(self.manager, "client"):
                try:
                    container = self.manager.client.containers.get(node_name)
                    return container.status == "running"
                except docker.errors.NotFound:
                    return False
                except Exception:
                    return False

            return False
        except Exception:
            return False

    def _resolve_config_path(self, config_path: Optional[str]) -> Optional[str]:
        """
        Resolve config path relative to workflow YAML file location.

        Args:
            config_path: Path to config file (can be relative or absolute)

        Returns:
            Absolute path to config file, or None if config_path is None
        """
        if config_path is None:
            return None
        if os.path.isabs(config_path):
            return config_path
        resolved = os.path.join(self.workflow_dir, config_path)
        return os.path.abspath(resolved)

    async def _start_nodes(self, restart: bool) -> bool:
        """Start the configured nodes."""
        nodes_config = self.config.get("nodes", {})

        if not nodes_config:
            console.print("[red]No nodes configuration found[/red]")
            return False

        base_port = nodes_config.get("base_port", DEFAULT_P2P_PORT)
        base_rpc_port = nodes_config.get("base_rpc_port", DEFAULT_RPC_PORT)

        image = self.image if self.image is not None else nodes_config.get("image")
        prefix = nodes_config.get("prefix", "calimero-node")
        config_path = self._resolve_config_path(nodes_config.get("config_path"))
        use_image_entrypoint = nodes_config.get("use_image_entrypoint", False)

        # If workflow declares a count, delegate to manager to handle bulk creation
        if "count" in nodes_config:
            # Check for incompatible config_path option
            if config_path is not None:
                console.print(
                    "[red]❌ config_path is not supported with 'count' mode[/red]"
                )
                console.print(
                    "[yellow]Please define nodes individually to use custom config paths[/yellow]"
                )
                return False

            count = nodes_config["count"]
            if restart:
                console.print(
                    f"Starting {count} nodes with prefix '{prefix}' (restart mode)..."
                )

                # Build arguments for run_multiple_nodes
                run_multiple_kwargs = {
                    "count": count,
                    "base_port": base_port,
                    "base_rpc_port": base_rpc_port,
                    "prefix": prefix,
                    "image": image,
                    "auth_service": self.auth_service,
                    "auth_image": self.auth_image,
                    "auth_use_cached": self.auth_use_cached,
                    "webui_use_cached": self.webui_use_cached,
                    "log_level": self.log_level,
                    "rust_backtrace": self.rust_backtrace,
                    "workflow_id": self.workflow_id,
                    "e2e_mode": self.e2e_mode,
                    "bootstrap_nodes": self.bootstrap_nodes,
                }
                if self.is_binary_mode:
                    if self.auth_mode:
                        run_multiple_kwargs["auth_mode"] = self.auth_mode
                else:
                    run_multiple_kwargs["use_image_entrypoint"] = use_image_entrypoint

                if not self.manager.run_multiple_nodes(**run_multiple_kwargs):
                    return False
            else:
                console.print(
                    f"Checking {count} nodes with prefix '{prefix}' (no restart mode)..."
                )
                for i in range(count):
                    node_name = f"{prefix}-{i+1}"
                    is_running = self._is_node_running(node_name)

                    if is_running:
                        console.print(
                            f"[green]✓ Node '{node_name}' is already running[/green]"
                        )
                        continue

                    # Not running -> start (allow manager to allocate ports if base_* is None)
                    port = base_port + i if base_port is not None else None
                    rpc_port = base_rpc_port + i if base_rpc_port is not None else None
                    # Build arguments for run_node
                    run_node_kwargs = {
                        "node_name": node_name,
                        "port": port,
                        "rpc_port": rpc_port,
                        "data_dir": None,
                        "image": image,
                        "auth_service": self.auth_service,
                        "auth_image": self.auth_image,
                        "auth_use_cached": self.auth_use_cached,
                        "webui_use_cached": self.webui_use_cached,
                        "log_level": self.log_level,
                        "rust_backtrace": self.rust_backtrace,
                        "workflow_id": self.workflow_id,
                        "e2e_mode": self.e2e_mode,
                        "bootstrap_nodes": self.bootstrap_nodes,
                    }
                    if self.is_binary_mode:
                        if self.auth_mode:
                            run_node_kwargs["auth_mode"] = self.auth_mode
                    else:
                        run_node_kwargs["use_image_entrypoint"] = use_image_entrypoint

                    if not self.manager.run_node(**run_node_kwargs):
                        return False

            console.print("[green]✓ Node management completed[/green]")
            return True

        # Otherwise handle individually defined nodes (dict or list)
        if isinstance(nodes_config, dict):
            # Filter out reserved configuration keys from node definitions
            items = [
                (k, v)
                for k, v in nodes_config.items()
                if k not in RESERVED_NODE_CONFIG_KEYS
            ]
        else:
            # list of node names
            items = [(n, None) for n in nodes_config]

        for node_name, node_cfg in items:
            # Resolve per-node settings
            if isinstance(node_cfg, dict):
                port = node_cfg.get("port", base_port)
                rpc_port = node_cfg.get("rpc_port", base_rpc_port)
                node_image = (
                    self.image
                    if self.image is not None
                    else node_cfg.get("image", image)
                )
                data_dir = node_cfg.get("data_dir")
                node_config_path = self._resolve_config_path(
                    node_cfg.get("config_path", nodes_config.get("config_path"))
                )
                node_use_image_entrypoint = node_cfg.get(
                    "use_image_entrypoint", use_image_entrypoint
                )
            else:
                port = base_port
                rpc_port = base_rpc_port
                node_image = image
                data_dir = None
                node_config_path = config_path
                node_use_image_entrypoint = use_image_entrypoint

            # Check if node is running
            is_running = self._is_node_running(node_name)

            if is_running:
                if restart:
                    console.print(
                        f"[yellow]Node '{node_name}' is running but restart requested, stopping...[/yellow]"
                    )
                    try:
                        if hasattr(self.manager, "stop_node"):
                            self.manager.stop_node(node_name)
                        elif not self.is_binary_mode and hasattr(
                            self.manager, "client"
                        ):
                            container = self.manager.client.containers.get(node_name)
                            container.stop()
                            container.remove()
                    except Exception as e:
                        console.print(
                            f"[yellow]Warning: Failed to stop node: {e}[/yellow]"
                        )

                    console.print(f"Starting node '{node_name}'...")
                    # Build arguments for run_node
                    run_node_kwargs = {
                        "node_name": node_name,
                        "port": port,
                        "rpc_port": rpc_port,
                        "data_dir": data_dir,
                        "image": node_image,
                        "auth_service": self.auth_service,
                        "auth_image": self.auth_image,
                        "auth_use_cached": self.auth_use_cached,
                        "webui_use_cached": self.webui_use_cached,
                        "log_level": self.log_level,
                        "rust_backtrace": self.rust_backtrace,
                        "workflow_id": self.workflow_id,
                        "e2e_mode": self.e2e_mode,
                        "config_path": node_config_path,
                        "bootstrap_nodes": self.bootstrap_nodes,
                    }
                    if self.is_binary_mode:
                        if self.auth_mode:
                            run_node_kwargs["auth_mode"] = self.auth_mode
                    else:
                        run_node_kwargs["use_image_entrypoint"] = (
                            node_use_image_entrypoint
                        )

                    if not self.manager.run_node(**run_node_kwargs):
                        return False
                else:
                    console.print(
                        f"[green]✓ Node '{node_name}' is already running[/green]"
                    )
                    continue
            else:
                console.print(f"Starting node '{node_name}'...")
                # Build arguments for run_node
                run_node_kwargs = {
                    "node_name": node_name,
                    "port": port,
                    "rpc_port": rpc_port,
                    "data_dir": data_dir,
                    "image": node_image,
                    "auth_service": self.auth_service,
                    "auth_image": self.auth_image,
                    "auth_use_cached": self.auth_use_cached,
                    "webui_use_cached": self.webui_use_cached,
                    "log_level": self.log_level,
                    "rust_backtrace": self.rust_backtrace,
                    "workflow_id": self.workflow_id,
                    "e2e_mode": self.e2e_mode,
                    "config_path": node_config_path,
                    "bootstrap_nodes": self.bootstrap_nodes,
                }
                if self.is_binary_mode:
                    if self.auth_mode:
                        run_node_kwargs["auth_mode"] = self.auth_mode
                else:
                    run_node_kwargs["use_image_entrypoint"] = node_use_image_entrypoint

                if not self.manager.run_node(**run_node_kwargs):
                    return False

        console.print("[green]✓ Node management completed[/green]")
        return True

    async def _wait_for_nodes_ready(self) -> bool:
        """Wait for all local nodes to be ready and accessible.

        Note: This only waits for local (docker/binary) nodes. Remote nodes
        are assumed to be already running and accessible.

        Readiness is determined by:
        1. Container/process is running
        2. Admin port is bound and accepting connections
        3. Health endpoint responds successfully (node is serving requests)
        """
        wait_timeout = self.config.get("wait_timeout", NODE_READY_TIMEOUT)

        # Use only local node names (remote nodes don't need local readiness check)
        node_names = list(self._get_local_node_names())

        console.print(
            f"Waiting up to {wait_timeout} seconds for {len(node_names)} nodes to be ready..."
        )

        start_time = time.time()
        ready_nodes: set[str] = set()
        # Track nodes that have passed admin binding to avoid repeated expensive checks
        admin_binding_passed: set[str] = set()
        # Cache RPC URLs per node to avoid recalculating on each iteration
        node_rpc_urls: dict[str, str] = {}
        # Track nodes that have already logged the health check warning to avoid console spam
        health_check_warned: set[str] = set()

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            task = progress.add_task("Waiting for nodes...", total=len(node_names))

            while (
                len(ready_nodes) < len(node_names)
                and (time.time() - start_time) < wait_timeout
            ):
                for node_name in node_names:
                    if node_name not in ready_nodes:
                        try:
                            is_running = self._is_node_running(node_name)

                            if is_running:
                                # Check admin binding only if not already passed
                                if node_name not in admin_binding_passed:
                                    if not self.manager.verify_admin_binding(node_name):
                                        continue
                                    admin_binding_passed.add(node_name)

                                # Get cached RPC URL or compute and cache it
                                if node_name not in node_rpc_urls:
                                    node_rpc_urls[node_name] = get_node_rpc_url(
                                        node_name, self.manager
                                    )
                                rpc_url = node_rpc_urls[node_name]

                                # Probe health endpoint to ensure node is serving requests
                                health_result = await check_node_health(rpc_url)
                                if health_result.get("success"):
                                    ready_nodes.add(node_name)
                                    progress.update(task, completed=len(ready_nodes))
                                    console.print(
                                        f"[green]✓ Node {node_name} is ready (health check passed)[/green]"
                                    )
                                elif node_name not in health_check_warned:
                                    # Only log the warning once per node
                                    console.print(
                                        f"[yellow]Node {node_name} admin binding OK, waiting for health check...[/yellow]"
                                    )
                                    health_check_warned.add(node_name)
                        except Exception:
                            pass

                if len(ready_nodes) < len(node_names):
                    await asyncio.sleep(ASYNC_POLL_INTERVAL)

        if len(ready_nodes) == len(node_names):
            console.print("[green]✓ All nodes are ready[/green]")
            return True
        else:
            missing_nodes = set(node_names) - ready_nodes
            console.print(f"[red]❌ Nodes not ready: {', '.join(missing_nodes)}[/red]")
            return False

    async def _authenticate_with_embedded_auth_nodes(self) -> bool:
        """Authenticate with all local nodes running embedded auth.

        This method authenticates with each node using the provided credentials
        and caches the tokens so that subsequent API calls will succeed.

        Returns:
            True if authentication succeeded for all nodes, False otherwise.
        """
        if not self.auth_username or not self.auth_password:
            console.print("[red]Cannot authenticate: missing auth credentials[/red]")
            return False

        node_names = list(self._get_local_node_names())
        if not node_names:
            console.print("[yellow]No local nodes to authenticate with[/yellow]")
            return True

        auth_manager = AuthManager()
        authenticated_nodes = []
        failed_nodes = []

        console.print(
            f"[cyan]Authenticating with {len(node_names)} nodes using embedded auth...[/cyan]"
        )

        for node_name in node_names:
            try:
                # Get the RPC URL for this node
                rpc_url = get_node_rpc_url(node_name, self.manager)
                console.print(
                    f"[cyan]  Authenticating with {node_name} at {rpc_url}...[/cyan]"
                )

                # Authenticate and get token
                token = await auth_manager.authenticate(
                    rpc_url,
                    self.auth_username,
                    self.auth_password,
                )

                # Save token to cache (so calimero-client can use it)
                auth_manager.save_token(token, node_name)
                authenticated_nodes.append(node_name)
                console.print(f"[green]  ✓ Authenticated with {node_name}[/green]")

            except AuthenticationError as e:
                console.print(
                    f"[red]  ✗ Failed to authenticate with {node_name}: {e}[/red]"
                )
                failed_nodes.append(node_name)
            except Exception as e:
                console.print(
                    f"[red]  ✗ Error authenticating with {node_name}: {e}[/red]"
                )
                failed_nodes.append(node_name)

        if failed_nodes:
            console.print(
                f"[red]❌ Authentication failed for nodes: {', '.join(failed_nodes)}[/red]"
            )
            return False

        console.print(
            f"[green]✓ Successfully authenticated with {len(authenticated_nodes)} nodes[/green]"
        )
        return True

    def _get_local_node_names(self) -> set[str]:
        """Get the set of valid local (docker/binary) node names based on nodes configuration."""
        nodes_config = self.config.get("nodes", {})

        if not nodes_config:
            return set()

        if isinstance(nodes_config, dict) and "count" in nodes_config:
            count = nodes_config["count"]
            if isinstance(count, int) and count >= 0:
                prefix = nodes_config.get("prefix", "calimero-node")
                return {f"{prefix}-{i+1}" for i in range(count)}
            else:
                return set()
        else:
            if isinstance(nodes_config, dict):
                # Filter out reserved configuration keys
                return {
                    k for k in nodes_config.keys() if k not in RESERVED_NODE_CONFIG_KEYS
                }
            elif isinstance(nodes_config, list):
                return set(nodes_config)
            else:
                return set()

    def _get_remote_node_names(self) -> set[str]:
        """Get the set of remote node names from remote_nodes configuration."""
        remote_nodes = self.config.get("remote_nodes", {})
        if not remote_nodes or not isinstance(remote_nodes, dict):
            return set()
        return set(remote_nodes.keys())

    def _get_valid_node_names(self) -> set[str]:
        """Get the set of all valid node names (local + remote)."""
        local_nodes = self._get_local_node_names()
        remote_nodes = self._get_remote_node_names()
        return local_nodes | remote_nodes

    def _has_local_nodes(self) -> bool:
        """Check if the workflow has local (docker/binary) nodes configured."""
        return len(self._get_local_node_names()) > 0

    def _has_remote_nodes(self) -> bool:
        """Check if the workflow has remote nodes configured."""
        return len(self._get_remote_node_names()) > 0

    def _setup_resolver(self) -> None:
        """Set up the NodeResolver with manager and remote nodes configuration."""
        # Create resolver with appropriate managers
        if self.manager is None:
            # Remote-only mode: no local node managers
            self.resolver = get_resolver(
                docker_manager=None,
                binary_manager=None,
            )
        elif self.is_binary_mode:
            self.resolver = get_resolver(
                docker_manager=None,
                binary_manager=self.manager,
            )
        else:
            self.resolver = get_resolver(
                docker_manager=self.manager,
                binary_manager=None,
            )

        # Register remote nodes from workflow config
        if self.remote_nodes_config:
            for node_name, node_config in self.remote_nodes_config.items():
                if not isinstance(node_config, dict):
                    console.print(
                        f"[yellow]Warning: Invalid remote node config for '{node_name}', skipping[/yellow]"
                    )
                    continue

                url = node_config.get("url")
                if not url:
                    console.print(
                        f"[yellow]Warning: Remote node '{node_name}' has no URL, skipping[/yellow]"
                    )
                    continue

                # Parse auth configuration
                auth_config = node_config.get("auth", {})
                auth_method = auth_config.get("method", AUTH_METHOD_NONE)
                username = auth_config.get("username")
                # Support both 'api_key' and 'key' field names
                api_key = auth_config.get("api_key") or auth_config.get("key")
                password = auth_config.get("password")

                # Register the remote node via resolver's public API
                self.resolver.register_remote(
                    name=node_name,
                    url=url,
                    auth_method=auth_method,
                    username=username,
                    password=password,
                    api_key=api_key,
                    description=node_config.get("description"),
                )

                console.print(
                    f"[cyan]Registered remote node: {node_name} -> {url} (auth: {auth_method})[/cyan]"
                )

    def _extract_node_references_from_step(self, step: dict[str, Any]) -> set[str]:
        """Extract all node references from a step, including nested steps."""
        node_refs = set()

        if "node" in step:
            node_value = step["node"]
            if (
                isinstance(node_value, str)
                and "{{" not in node_value
                and "}}" not in node_value
            ):
                node_refs.add(node_value)

        if step.get("type") == "repeat":
            for nested_step in step.get("steps") or []:
                node_refs.update(self._extract_node_references_from_step(nested_step))
        elif step.get("type") == "parallel":
            for group in step.get("groups") or []:
                for nested_step in group.get("steps") or []:
                    node_refs.update(
                        self._extract_node_references_from_step(nested_step)
                    )

        return node_refs

    def _validate_node_references(self) -> bool:
        """Validate that all node references in workflow steps exist."""
        steps = self.config.get("steps", [])

        if not steps:
            return True

        valid_nodes = self._get_valid_node_names()

        referenced_nodes = set()
        for step in steps:
            referenced_nodes.update(self._extract_node_references_from_step(step))

        if not valid_nodes:
            if referenced_nodes:
                console.print(
                    f"[red]❌ Workflow references nodes but no nodes are configured: {', '.join(sorted(referenced_nodes))}[/red]"
                )
                return False
            return True

        invalid_nodes = referenced_nodes - valid_nodes

        if invalid_nodes:
            console.print(
                f"[red]❌ Workflow references non-existent nodes: {', '.join(sorted(invalid_nodes))}[/red]"
            )
            console.print(
                f"[yellow]Valid nodes based on configuration: {', '.join(sorted(valid_nodes))}[/yellow]"
            )
            nodes_config = self.config.get("nodes", {})
            if "count" in nodes_config:
                count = nodes_config["count"]
                prefix = nodes_config.get("prefix", "calimero-node")
                console.print(
                    f"[yellow]Configuration specifies count={count} with prefix='{prefix}', "
                    f"so only nodes {prefix}-1 through {prefix}-{count} exist[/yellow]"
                )
            return False

        return True

    async def _execute_workflow_steps(self) -> bool:
        """Execute the configured workflow steps."""
        steps = self.config.get("steps", [])

        if not steps:
            console.print("[yellow]No workflow steps configured[/yellow]")
            return True

        if not self._validate_node_references():
            return False

        for i, step in enumerate(steps, 1):
            step_type = step.get("type")
            step_name = step.get("name", f"Step {i}")

            console.print(
                f"\n[bold cyan]Executing {step_name} ({step_type})...[/bold cyan]"
            )

            try:
                # Create appropriate step executor
                step_executor = self._create_step_executor(step_type, step)
                if not step_executor:
                    console.print(f"[red]Unknown step type: {step_type}[/red]")
                    return False

                # Execute the step
                success = await step_executor.execute(
                    self.workflow_results, self.dynamic_values
                )

                if not success:
                    console.print(f"[red]❌ Step '{step_name}' failed[/red]")
                    return False

                console.print(f"[green]✓ Step '{step_name}' completed[/green]")

            except Exception as e:
                console.print(
                    f"[red]❌ Step '{step_name}' failed with error: {str(e)}[/red]"
                )
                return False

        return True

    def _create_step_executor(self, step_type: str, step_config: dict[str, Any]):
        """Create a step executor based on the step type.

        All step executors receive the manager, resolver, and auth_mode to support both
        local (docker/binary) and remote node resolution with optional embedded auth.
        """
        # Common kwargs for all steps
        common_kwargs = {
            "manager": self.manager,
            "resolver": self.resolver,
            "auth_mode": self.auth_mode,
        }

        if step_type == "install_application":
            return InstallApplicationStep(step_config, **common_kwargs)
        elif step_type == "create_context":
            return CreateContextStep(step_config, **common_kwargs)
        elif step_type == "create_identity":
            return CreateIdentityStep(step_config, **common_kwargs)
        elif step_type in ("invite", "invite_open", "invite_identity"):
            return InviteOpenStep(step_config, **common_kwargs)
        elif step_type in ("join", "join_open"):
            return JoinOpenStep(step_config, **common_kwargs)
        elif step_type == "call":
            return ExecuteStep(step_config, **common_kwargs)
        elif step_type == "wait":
            return WaitStep(step_config, **common_kwargs)
        elif step_type == "wait_for_sync":
            return WaitForSyncStep(step_config, **common_kwargs)
        elif step_type == "repeat":
            return RepeatStep(step_config, **common_kwargs)
        elif step_type == "parallel":
            return ParallelStep(step_config, **common_kwargs)
        elif step_type == "script":
            return ScriptStep(step_config, **common_kwargs)
        elif step_type == "assert":
            return AssertStep(step_config, **common_kwargs)
        elif step_type == "json_assert":
            return JsonAssertStep(step_config, **common_kwargs)
        elif step_type == "get_proposal":
            return GetProposalStep(step_config, **common_kwargs)
        elif step_type == "list_proposals":
            return ListProposalsStep(step_config, **common_kwargs)
        elif step_type == "get_proposal_approvers":
            return GetProposalApproversStep(step_config, **common_kwargs)
        elif step_type == "upload_blob":
            return UploadBlobStep(step_config, **common_kwargs)
        elif step_type == "create_mesh":
            return CreateMeshStep(step_config, **common_kwargs)
        elif step_type == "fuzzy_test":
            return FuzzyTestStep(step_config, **common_kwargs)
        elif step_type in ("create_namespace", "create_group"):
            # 'create_group' kept as deprecated alias.
            return CreateNamespaceStep(step_config, **common_kwargs)
        elif step_type in ("create_namespace_invitation", "create_group_invitation"):
            # 'create_group_invitation' kept as deprecated alias.
            return CreateNamespaceInvitationStep(step_config, **common_kwargs)
        elif step_type in ("join_namespace", "join_group"):
            # 'join_group' kept as deprecated alias.
            return JoinNamespaceStep(step_config, **common_kwargs)
        elif step_type == "list_namespaces":
            return ListNamespacesStep(step_config, **common_kwargs)
        elif step_type == "get_namespace_identity":
            return GetNamespaceIdentityStep(step_config, **common_kwargs)
        elif step_type == "create_group_in_namespace":
            return CreateGroupInNamespaceStep(step_config, **common_kwargs)
        elif step_type == "list_namespace_groups":
            return ListNamespaceGroupsStep(step_config, **common_kwargs)
        elif step_type == "reparent_group":
            return ReparentGroupStep(step_config, **common_kwargs)
        elif step_type == "list_subgroups":
            return ListSubgroupsStep(step_config, **common_kwargs)
        elif step_type == "add_group_members":
            return AddGroupMembersStep(step_config, **common_kwargs)
        elif step_type == "remove_group_members":
            return RemoveGroupMembersStep(step_config, **common_kwargs)
        elif step_type == "list_group_members":
            return ListGroupMembersStep(step_config, **common_kwargs)
        elif step_type == "update_member_role":
            return UpdateMemberRoleStep(step_config, **common_kwargs)
        elif step_type == "set_member_capabilities":
            return SetMemberCapabilitiesStep(step_config, **common_kwargs)
        elif step_type == "get_member_capabilities":
            return GetMemberCapabilitiesStep(step_config, **common_kwargs)
        elif step_type == "set_default_capabilities":
            return SetDefaultCapabilitiesStep(step_config, **common_kwargs)
        elif step_type in ("set_subgroup_visibility", "set_default_visibility"):
            # 'set_default_visibility' kept as deprecated alias.
            return SetSubgroupVisibilityStep(step_config, **common_kwargs)
        elif step_type == "get_group_info":
            return GetGroupInfoStep(step_config, **common_kwargs)
        elif step_type == "list_group_contexts":
            return ListGroupContextsStep(step_config, **common_kwargs)
        elif step_type == "delete_group":
            return DeleteGroupStep(step_config, **common_kwargs)
        elif step_type == "delete_namespace":
            return DeleteNamespaceStep(step_config, **common_kwargs)
        elif step_type == "delete_context":
            return DeleteContextStep(step_config, **common_kwargs)
        elif step_type == "uninstall_application":
            return UninstallApplicationStep(step_config, **common_kwargs)
        elif step_type == "set_group_alias":
            return SetGroupAliasStep(step_config, **common_kwargs)
        elif step_type == "set_member_alias":
            return SetMemberAliasStep(step_config, **common_kwargs)
        elif step_type == "update_group_settings":
            return UpdateGroupSettingsStep(step_config, **common_kwargs)
        elif step_type == "detach_context_from_group":
            return DetachContextFromGroupStep(step_config, **common_kwargs)
        elif step_type == "sync_group":
            return SyncGroupStep(step_config, **common_kwargs)
        elif step_type == "register_group_signing_key":
            return RegisterGroupSigningKeyStep(step_config, **common_kwargs)
        elif step_type == "upgrade_group":
            return UpgradeGroupStep(step_config, **common_kwargs)
        elif step_type == "get_group_upgrade_status":
            return GetGroupUpgradeStatusStep(step_config, **common_kwargs)
        elif step_type == "retry_group_upgrade":
            return RetryGroupUpgradeStep(step_config, **common_kwargs)
        elif step_type == "join_context":
            return JoinContextStep(step_config, **common_kwargs)
        elif step_type == "leave_context":
            return LeaveContextStep(step_config, **common_kwargs)
        elif step_type == "leave_group":
            return LeaveGroupStep(step_config, **common_kwargs)
        elif step_type == "leave_namespace":
            return LeaveNamespaceStep(step_config, **common_kwargs)
        else:
            console.print(f"[red]Unknown step type: {step_type}[/red]")
            return None
