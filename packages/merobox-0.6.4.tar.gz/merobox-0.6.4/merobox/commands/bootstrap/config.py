"""
Configuration management for bootstrap workflows.
"""

import os
import re
from typing import Any, Literal, Optional, Union

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from merobox.commands.utils import console

# Pattern to match ${ENV_VAR} or ${ENV_VAR:-default} syntax
ENV_VAR_PATTERN = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")

# Valid step types for workflow validation (using frozenset for O(1) lookups)
VALID_STEP_TYPES = frozenset(
    {
        "install_application",
        "create_context",
        "create_namespace",
        "create_namespace_invitation",
        "join_namespace",
        # Deprecated aliases (kept for backward compatibility)
        "create_group",
        "create_group_invitation",
        "join_group",
        "invite",
        "invite_open",
        "invite_identity",
        "join",
        "join_open",
        "create_identity",
        "join_context",
        "leave_context",
        "leave_group",
        "leave_namespace",
        "list_namespaces",
        "get_namespace_identity",
        "create_group_in_namespace",
        "list_namespace_groups",
        "reparent_group",
        "list_subgroups",
        "add_group_members",
        "remove_group_members",
        "list_group_members",
        "update_member_role",
        "set_member_capabilities",
        "get_member_capabilities",
        "set_default_capabilities",
        "set_default_visibility",
        "set_subgroup_visibility",
        "get_group_info",
        "list_group_contexts",
        "delete_group",
        "delete_namespace",
        "delete_context",
        "uninstall_application",
        "set_group_alias",
        "set_member_alias",
        "update_group_settings",
        "detach_context_from_group",
        "sync_group",
        "register_group_signing_key",
        "upgrade_group",
        "get_group_upgrade_status",
        "retry_group_upgrade",
        "call",
        "wait",
        "wait_for_sync",
        "repeat",
        "parallel",
        "script",
        "assert",
        "json_assert",
        "get_proposal",
        "list_proposals",
        "get_proposal_approvers",
        "upload_blob",
        "create_mesh",
        "fuzzy_test",
    }
)


# =============================================================================
# Pydantic Models for Workflow Schema Validation
# =============================================================================


class NodesConfig(BaseModel):
    """Configuration for local Docker/binary nodes."""

    model_config = ConfigDict(extra="allow")

    count: Optional[int] = Field(None, ge=1, description="Number of nodes to create")
    prefix: Optional[str] = Field("calimero-node", description="Prefix for node names")
    image: Optional[str] = Field(None, description="Docker image for nodes")
    base_port: Optional[int] = Field(
        None, ge=1, le=65535, description="Base port for nodes"
    )
    base_rpc_port: Optional[int] = Field(
        None, ge=1, le=65535, description="Base RPC port for nodes"
    )
    config_path: Optional[str] = Field(
        None, description="Path to node configuration file"
    )
    use_image_entrypoint: Optional[bool] = Field(
        False, description="Use Docker image entrypoint"
    )


class RemoteNodeAuth(BaseModel):
    """Authentication configuration for remote nodes."""

    model_config = ConfigDict(extra="forbid")

    method: Optional[Literal["none", "api_key", "password"]] = Field(
        "none", description="Authentication method (none, api_key, password)"
    )
    username: Optional[str] = Field(None, description="Username for authentication")
    password: Optional[str] = Field(None, description="Password for authentication")
    api_key: Optional[str] = Field(None, description="API key for authentication")
    key: Optional[str] = Field(None, description="Alternative field for API key")


class RemoteNodeConfig(BaseModel):
    """Configuration for a single remote node."""

    model_config = ConfigDict(extra="allow")

    url: str = Field(..., description="URL of the remote node")
    auth: Optional[RemoteNodeAuth] = Field(
        None, description="Authentication configuration"
    )
    description: Optional[str] = Field(None, description="Description of the node")


class BaseStepConfig(BaseModel):
    """Base configuration for all workflow steps."""

    model_config = ConfigDict(extra="allow")

    name: Optional[str] = Field(None, description="Name of the step")
    type: str = Field(..., description="Type of the step")
    outputs: Optional[dict[str, Any]] = Field(
        None, description="Output variable mappings"
    )

    @model_validator(mode="after")
    def validate_step_type(self) -> "BaseStepConfig":
        """Validate that the step type is valid."""
        if self.type not in VALID_STEP_TYPES:
            raise ValueError(
                f"Invalid step type '{self.type}'. "
                f"Valid types are: {', '.join(sorted(VALID_STEP_TYPES))}"
            )
        return self


class InstallApplicationStep(BaseStepConfig):
    """Configuration for install_application step."""

    type: Literal["install_application"] = "install_application"
    node: str = Field(..., description="Target node for installation")
    path: str = Field(..., description="Path to the WASM file")
    dev: Optional[bool] = Field(False, description="Install in dev mode")


class CreateContextStep(BaseStepConfig):
    """Configuration for create_context step."""

    type: Literal["create_context"] = "create_context"
    node: str = Field(..., description="Target node")
    application_id: str = Field(..., description="Application ID to use")
    group_id: str = Field(..., description="Namespace/group ID for the context")
    service_name: Optional[str] = Field(
        None, description="Optional service name for context creation"
    )
    protocol: Optional[str] = Field(None, description="Protocol to use (e.g., near)")


class CreateIdentityStep(BaseStepConfig):
    """Configuration for create_identity step."""

    type: Literal["create_identity"] = "create_identity"
    node: str = Field(..., description="Target node")


class InviteStep(BaseStepConfig):
    """Configuration for deprecated invite aliases.

    Legacy step types 'invite', 'invite_open', and 'invite_identity' map to
    namespace invitation creation.
    """

    type: Literal["invite", "invite_open", "invite_identity"] = "invite"
    node: str = Field(..., description="Target node")
    namespace_id: Optional[str] = Field(
        None, description="Namespace ID to create invitation for"
    )
    recursive: Optional[bool] = Field(False, description="Create recursive invitation")

    @model_validator(mode="after")
    def normalize_namespace_id(self) -> "InviteStep":
        # Backward compatibility: accept group_id as alias of namespace_id.
        group_id = getattr(self, "group_id", None)
        if not self.namespace_id and group_id:
            self.namespace_id = group_id
        if not self.namespace_id:
            raise ValueError(
                "Either 'namespace_id' or deprecated alias 'group_id' is required"
            )
        return self


class JoinStep(BaseStepConfig):
    """Configuration for deprecated join aliases."""

    type: Literal["join", "join_open"] = "join"
    node: str = Field(..., description="Target node")
    namespace_id: Optional[str] = Field(None, description="Namespace ID to join")
    invitation: str = Field(..., description="Namespace invitation data")

    @model_validator(mode="after")
    def normalize_namespace_id(self) -> "JoinStep":
        # Backward compatibility: accept group_id as alias of namespace_id.
        group_id = getattr(self, "group_id", None)
        if not self.namespace_id and group_id:
            self.namespace_id = group_id
        if not self.namespace_id:
            raise ValueError(
                "Either 'namespace_id' or deprecated alias 'group_id' is required"
            )
        return self


class JoinContextStepConfig(BaseStepConfig):
    """Configuration for join_context step (join existing context via group membership)."""

    type: Literal["join_context"] = "join_context"
    node: str = Field(..., description="Target node")
    context_id: str = Field(..., description="Context ID to join")


class CallStep(BaseStepConfig):
    """Configuration for call step."""

    type: Literal["call"] = "call"
    node: str = Field(..., description="Target node")
    context_id: str = Field(..., description="Context ID")
    method: str = Field(..., description="Method to call")
    args: Optional[dict[str, Any]] = Field(None, description="Arguments for the call")
    executor_public_key: Optional[str] = Field(
        None, description="Public key of executor"
    )


class WaitStep(BaseStepConfig):
    """Configuration for wait step."""

    type: Literal["wait"] = "wait"
    seconds: int = Field(..., ge=0, description="Seconds to wait")
    message: Optional[str] = Field(None, description="Message to display while waiting")


class WaitForSyncStep(BaseStepConfig):
    """Configuration for wait_for_sync step."""

    type: Literal["wait_for_sync"] = "wait_for_sync"
    context_id: str = Field(..., description="Context ID to sync")
    nodes: list[str] = Field(..., description="Nodes to wait for sync")
    timeout: Optional[int] = Field(60, ge=1, description="Timeout in seconds")
    check_interval: Optional[int] = Field(
        2, ge=1, description="Check interval in seconds"
    )
    trigger_sync: Optional[bool] = Field(
        False, description="Trigger sync before waiting"
    )


class RepeatStep(BaseStepConfig):
    """Configuration for repeat step."""

    type: Literal["repeat"] = "repeat"
    count: int = Field(..., ge=1, description="Number of iterations")
    steps: list[dict[str, Any]] = Field(..., description="Steps to repeat")


class ParallelGroupConfig(BaseModel):
    """Configuration for a parallel execution group."""

    model_config = ConfigDict(extra="allow")

    name: Optional[str] = Field(None, description="Name of the group")
    steps: list[dict[str, Any]] = Field(..., description="Steps in this group")


class ParallelStep(BaseStepConfig):
    """Configuration for parallel step."""

    type: Literal["parallel"] = "parallel"
    groups: list[ParallelGroupConfig] = Field(
        ..., description="Groups of steps to run in parallel"
    )


class ScriptStep(BaseStepConfig):
    """Configuration for script step."""

    type: Literal["script"] = "script"
    script: str = Field(..., description="Path to the script")
    target: Optional[str] = Field("nodes", description="Target: 'image' or 'nodes'")
    description: Optional[str] = Field(None, description="Description of the script")


class AssertStep(BaseStepConfig):
    """Configuration for assert step."""

    type: Literal["assert"] = "assert"
    statements: list[Union[str, dict[str, Any]]] = Field(
        ..., description="List of assertion statements"
    )
    non_blocking: Optional[bool] = Field(
        None, description="If true, continue workflow on failure"
    )


class JsonAssertStep(BaseStepConfig):
    """Configuration for json_assert step."""

    type: Literal["json_assert"] = "json_assert"
    statements: list[Union[str, dict[str, Any]]] = Field(
        ..., description="List of JSON assertion statements"
    )


class GetProposalStep(BaseStepConfig):
    """Configuration for get_proposal step."""

    type: Literal["get_proposal"] = "get_proposal"
    node: str = Field(..., description="Target node")
    context_id: str = Field(..., description="Context ID")
    proposal_id: str = Field(..., description="Proposal ID")


class ListProposalsStep(BaseStepConfig):
    """Configuration for list_proposals step."""

    type: Literal["list_proposals"] = "list_proposals"
    node: str = Field(..., description="Target node")
    context_id: str = Field(..., description="Context ID")


class GetProposalApproversStep(BaseStepConfig):
    """Configuration for get_proposal_approvers step."""

    type: Literal["get_proposal_approvers"] = "get_proposal_approvers"
    node: str = Field(..., description="Target node")
    context_id: str = Field(..., description="Context ID")
    proposal_id: str = Field(..., description="Proposal ID")


class UploadBlobStep(BaseStepConfig):
    """Configuration for upload_blob step."""

    type: Literal["upload_blob"] = "upload_blob"
    node: str = Field(..., description="Target node")
    file_path: str = Field(..., description="Path to the blob file")
    context_id: Optional[str] = Field(None, description="Context ID (optional)")


class CreateNamespaceStepConfig(BaseStepConfig):
    """Configuration for create_namespace step."""

    type: Literal["create_namespace", "create_group"] = "create_namespace"
    node: str = Field(..., description="Target node")
    application_id: str = Field(
        ..., description="Application ID for namespace creation"
    )
    alias: Optional[str] = Field(None, description="Optional namespace alias")


class CreateNamespaceInvitationStepConfig(BaseStepConfig):
    """Configuration for create_namespace_invitation step."""

    type: Literal["create_namespace_invitation", "create_group_invitation"] = (
        "create_namespace_invitation"
    )
    node: str = Field(..., description="Target node")
    namespace_id: Optional[str] = Field(None, description="Namespace ID to invite to")
    recursive: Optional[bool] = Field(False, description="Create recursive invitation")

    @model_validator(mode="after")
    def normalize_namespace_id(self) -> "CreateNamespaceInvitationStepConfig":
        # Backward compatibility: accept group_id as alias of namespace_id.
        group_id = getattr(self, "group_id", None)
        if not self.namespace_id and group_id:
            self.namespace_id = group_id
        if not self.namespace_id:
            raise ValueError(
                "Either 'namespace_id' or deprecated alias 'group_id' is required"
            )
        return self


class JoinNamespaceStepConfig(BaseStepConfig):
    """Configuration for join_namespace step."""

    type: Literal["join_namespace", "join_group"] = "join_namespace"
    node: str = Field(..., description="Target node")
    namespace_id: Optional[str] = Field(None, description="Namespace ID to join")
    invitation: str = Field(..., description="Namespace invitation data")

    @model_validator(mode="after")
    def normalize_namespace_id(self) -> "JoinNamespaceStepConfig":
        # Backward compatibility: accept group_id as alias of namespace_id.
        group_id = getattr(self, "group_id", None)
        if not self.namespace_id and group_id:
            self.namespace_id = group_id
        if not self.namespace_id:
            raise ValueError(
                "Either 'namespace_id' or deprecated alias 'group_id' is required"
            )
        return self


class ListNamespacesStepConfig(BaseStepConfig):
    """Configuration for list_namespaces step."""

    type: Literal["list_namespaces"] = "list_namespaces"
    node: str = Field(..., description="Target node")


class GetNamespaceIdentityStepConfig(BaseStepConfig):
    """Configuration for get_namespace_identity step."""

    type: Literal["get_namespace_identity"] = "get_namespace_identity"
    node: str = Field(..., description="Target node")
    namespace_id: str = Field(..., description="Namespace ID")


class CreateGroupInNamespaceStepConfig(BaseStepConfig):
    """Configuration for create_group_in_namespace step."""

    type: Literal["create_group_in_namespace"] = "create_group_in_namespace"
    node: str = Field(..., description="Target node")
    namespace_id: str = Field(..., description="Namespace ID")
    group_alias: str = Field(..., description="Group alias")


class ListNamespaceGroupsStepConfig(BaseStepConfig):
    """Configuration for list_namespace_groups step."""

    type: Literal["list_namespace_groups"] = "list_namespace_groups"
    node: str = Field(..., description="Target node")
    namespace_id: str = Field(..., description="Namespace ID")


class ReparentGroupStepConfig(BaseStepConfig):
    """Configuration for reparent_group step.

    Replaces NestGroupStepConfig + UnnestGroupStepConfig in the strict
    group-tree refactor. Atomically moves `child_group_id` to a new
    parent within the same namespace; orphan state is no longer
    expressible.
    """

    type: Literal["reparent_group"] = "reparent_group"
    node: str = Field(..., description="Target node")
    child_group_id: str = Field(..., description="Group to move")
    new_parent_id: str = Field(..., description="New parent group ID")


class ListSubgroupsStepConfig(BaseStepConfig):
    """Configuration for list_subgroups step."""

    type: Literal["list_subgroups"] = "list_subgroups"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")


class AddGroupMembersStepConfig(BaseStepConfig):
    """Configuration for add_group_members step."""

    type: Literal["add_group_members"] = "add_group_members"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID to add members to")
    members: list[dict[str, str]] = Field(
        ..., description="List of members with identity and role"
    )


class RemoveGroupMembersStepConfig(BaseStepConfig):
    """Configuration for remove_group_members step."""

    type: Literal["remove_group_members"] = "remove_group_members"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID to remove members from")
    members: list[str] = Field(..., description="List of member public keys to remove")


class ListGroupMembersStepConfig(BaseStepConfig):
    """Configuration for list_group_members step."""

    type: Literal["list_group_members"] = "list_group_members"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")


class ListGroupContextsStepConfig(BaseStepConfig):
    """Configuration for list_group_contexts step."""

    type: Literal["list_group_contexts"] = "list_group_contexts"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")


class UpdateMemberRoleStepConfig(BaseStepConfig):
    """Configuration for update_member_role step."""

    type: Literal["update_member_role"] = "update_member_role"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")
    member_id: str = Field(..., description="Member public key")
    role: Literal[
        "Admin",
        "Member",
        "ReadOnly",
        "admin",
        "member",
        "read-only",
        "read_only",
        "readonly",
    ] = Field(..., description="New role for the member")


class SetMemberCapabilitiesStepConfig(BaseStepConfig):
    """Configuration for set_member_capabilities step."""

    type: Literal["set_member_capabilities"] = "set_member_capabilities"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")
    member_id: str = Field(..., description="Member public key")
    capabilities: int = Field(
        ..., ge=0, lt=2**32, description="Capability bitmask (u32)"
    )


class GetMemberCapabilitiesStepConfig(BaseStepConfig):
    """Configuration for get_member_capabilities step."""

    type: Literal["get_member_capabilities"] = "get_member_capabilities"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")
    member_id: str = Field(..., description="Member public key")


class SetDefaultCapabilitiesStepConfig(BaseStepConfig):
    """Configuration for set_default_capabilities step."""

    type: Literal["set_default_capabilities"] = "set_default_capabilities"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")
    capabilities: int = Field(
        ..., ge=0, lt=2**32, description="Default capability bitmask (u32)"
    )


class SetSubgroupVisibilityStepConfig(BaseStepConfig):
    """Configuration for set_subgroup_visibility step.

    Sets a subgroup's visibility (`open` / `restricted`). When `open`,
    parent-group members holding `CAN_JOIN_OPEN_SUBGROUPS` are inherited
    as members of this subgroup. When `restricted`, membership requires
    explicit `add_group_members` (calimero-network/core#2256).
    """

    type: Literal["set_subgroup_visibility"] = "set_subgroup_visibility"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")
    visibility: Literal["open", "restricted", "Open", "Restricted"] = Field(
        ...,
        description="Subgroup visibility: open (inherits) or restricted (explicit only)",
    )


class SetDefaultVisibilityStepConfig(BaseStepConfig):
    """Configuration for the deprecated `set_default_visibility` step.

    Kept so workflows pinned to the pre-#2256 step name keep validating.
    Accepts the same fields as `SetSubgroupVisibilityStepConfig` and is
    dispatched to the same executor class.
    """

    type: Literal["set_default_visibility"] = "set_default_visibility"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")
    visibility: Literal["open", "restricted", "Open", "Restricted"] = Field(
        ...,
        description="Subgroup visibility: open (inherits) or restricted (explicit only)",
    )


class GetGroupInfoStepConfig(BaseStepConfig):
    """Configuration for get_group_info step."""

    type: Literal["get_group_info"] = "get_group_info"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")


class DeleteGroupStepConfig(BaseStepConfig):
    """Configuration for delete_group step."""

    type: Literal["delete_group"] = "delete_group"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID to delete")
    requester: Optional[str] = Field(
        None,
        description="Optional admin public key, required when deleting a group with admin-guarded state",
    )


class DeleteNamespaceStepConfig(BaseStepConfig):
    """Configuration for delete_namespace step."""

    type: Literal["delete_namespace"] = "delete_namespace"
    node: str = Field(..., description="Target node")
    namespace_id: str = Field(..., description="Namespace ID to delete")
    requester: Optional[str] = Field(
        None,
        description="Optional admin public key, required when deleting a namespace with admin-guarded state",
    )


class DeleteContextStepConfig(BaseStepConfig):
    """Configuration for delete_context step."""

    type: Literal["delete_context"] = "delete_context"
    node: str = Field(..., description="Target node")
    context_id: str = Field(..., description="Context ID to delete")
    requester: Optional[str] = Field(
        None,
        description="Optional admin public key, required when deleting a context registered in a group",
    )


class UninstallApplicationStepConfig(BaseStepConfig):
    """Configuration for uninstall_application step."""

    type: Literal["uninstall_application"] = "uninstall_application"
    node: str = Field(..., description="Target node")
    application_id: str = Field(..., description="Application ID to uninstall")


class SetGroupAliasStepConfig(BaseStepConfig):
    """Configuration for set_group_alias step (admin-API group rename)."""

    type: Literal["set_group_alias"] = "set_group_alias"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID to rename")
    alias: str = Field(..., description="New human-friendly alias for the group")


class SetMemberAliasStepConfig(BaseStepConfig):
    """Configuration for set_member_alias step (admin-API member display-name)."""

    type: Literal["set_member_alias"] = "set_member_alias"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")
    member_id: str = Field(..., description="Member public key")
    alias: str = Field(..., description="New human-friendly alias for the member")


class UpdateGroupSettingsStepConfig(BaseStepConfig):
    """Configuration for update_group_settings step (currently exposes upgrade_policy)."""

    type: Literal["update_group_settings"] = "update_group_settings"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")
    upgrade_policy: Literal[
        "automatic",
        "coordinated",
        "lazy",
        "lazy-on-access",
        "lazy_on_access",
        "lazyonaccess",
    ] = Field(..., description="Group upgrade policy")


class DetachContextFromGroupStepConfig(BaseStepConfig):
    """Configuration for detach_context_from_group step."""

    type: Literal["detach_context_from_group"] = "detach_context_from_group"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID the context is currently in")
    context_id: str = Field(..., description="Context ID to detach from the group")


class SyncGroupStepConfig(BaseStepConfig):
    """Configuration for sync_group step (diagnostic governance sync trigger)."""

    type: Literal["sync_group"] = "sync_group"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID to trigger governance sync for")


class RegisterGroupSigningKeyStepConfig(BaseStepConfig):
    """Configuration for register_group_signing_key step."""

    type: Literal["register_group_signing_key"] = "register_group_signing_key"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")
    # Accepts either a 64-hex-char literal (32-byte PrivateKey) or a
    # `{{placeholder}}` template resolved at runtime. The {64} constraint
    # matches calimero_primitives::identity::PrivateKey's 32-byte size;
    # catches typos and trivially short values at YAML-load time, without
    # breaking workflows that inject the key via outputs from a prior step.
    #
    # SECURITY: prefer the `{{placeholder}}` form whenever the YAML is
    # committed to version control. Hardcoding a raw hex signing key in a
    # committed workflow file checks the actual key material into git
    # history — that's a credential leak. Capture the key from a prior
    # step's `outputs:`, or inject via `${ENV_VAR}` expansion, and refer
    # to it here as `{{key_name}}`.
    #
    # Note on `${ENV_VAR}` expansion: merobox's env-var substitution runs
    # BEFORE this Pydantic pattern is evaluated (see
    # `expand_env_vars` above, which walks the parsed YAML before
    # `validate_workflow_config`). So `signing_key: ${MY_KEY}` resolves
    # to the hex value at load-time and then passes the `[0-9a-fA-F]{64}`
    # alternative of this pattern — there's no need for the regex itself
    # to match `${...}` syntax.
    signing_key: str = Field(
        ...,
        pattern=r"^(\{\{[^}]+\}\}|[0-9a-fA-F]{64})$",
        description=(
            "Signing key as 64 hex chars (32-byte PrivateKey) or `{{placeholder}}` "
            "template. Prefer the template form — raw hex in committed YAML leaks "
            "key material via git history."
        ),
    )


class UpgradeGroupStepConfig(BaseStepConfig):
    """Configuration for upgrade_group step."""

    type: Literal["upgrade_group"] = "upgrade_group"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")
    target_application_id: str = Field(
        ..., description="Application ID to upgrade the group to"
    )
    migrate_method: Optional[str] = Field(
        None, description="Optional migration export to invoke during upgrade"
    )


class GetGroupUpgradeStatusStepConfig(BaseStepConfig):
    """Configuration for get_group_upgrade_status step."""

    type: Literal["get_group_upgrade_status"] = "get_group_upgrade_status"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")


class RetryGroupUpgradeStepConfig(BaseStepConfig):
    """Configuration for retry_group_upgrade step."""

    type: Literal["retry_group_upgrade"] = "retry_group_upgrade"
    node: str = Field(..., description="Target node")
    group_id: str = Field(..., description="Group ID")


class CreateMeshStep(BaseStepConfig):
    """Configuration for create_mesh step.

    Uses the group-based flow: creates a context (with auto-created group),
    then creates group invitations and joins for each node.
    """

    type: Literal["create_mesh"] = "create_mesh"
    context_node: str = Field(..., description="Node to create context on")
    application_id: str = Field(..., description="Application ID")
    nodes: list[str] = Field(..., description="List of nodes to include in mesh")
    protocol: Optional[str] = Field(None, description="Protocol to use")
    params: Optional[str] = Field(None, description="Initialization params JSON string")


class FuzzyTestStep(BaseStepConfig):
    """Configuration for fuzzy_test step."""

    type: Literal["fuzzy_test"] = "fuzzy_test"
    duration_minutes: Union[int, float] = Field(
        ..., gt=0, description="Duration in minutes for the fuzzy test"
    )
    context_id: str = Field(..., description="Context ID")
    nodes: list[dict[str, Any]] = Field(
        ..., description="List of nodes with name and executor_key"
    )
    operations: list[dict[str, Any]] = Field(
        ..., description="List of operations to execute"
    )


# Module-level mapping of step types to their Pydantic models
# This avoids recreating the dict on every validation call
STEP_TYPE_MODELS: dict[str, type[BaseStepConfig]] = {
    "install_application": InstallApplicationStep,
    "create_context": CreateContextStep,
    "create_identity": CreateIdentityStep,
    "create_namespace": CreateNamespaceStepConfig,
    "create_namespace_invitation": CreateNamespaceInvitationStepConfig,
    "join_namespace": JoinNamespaceStepConfig,
    # Deprecated aliases
    "create_group": CreateNamespaceStepConfig,
    "create_group_invitation": CreateNamespaceInvitationStepConfig,
    "join_group": JoinNamespaceStepConfig,
    "invite": InviteStep,
    "invite_identity": InviteStep,
    "invite_open": InviteStep,
    "join": JoinStep,
    "join_context": JoinContextStepConfig,
    "join_open": JoinStep,
    "list_namespaces": ListNamespacesStepConfig,
    "get_namespace_identity": GetNamespaceIdentityStepConfig,
    "create_group_in_namespace": CreateGroupInNamespaceStepConfig,
    "list_namespace_groups": ListNamespaceGroupsStepConfig,
    "reparent_group": ReparentGroupStepConfig,
    "list_subgroups": ListSubgroupsStepConfig,
    "add_group_members": AddGroupMembersStepConfig,
    "remove_group_members": RemoveGroupMembersStepConfig,
    "list_group_members": ListGroupMembersStepConfig,
    "list_group_contexts": ListGroupContextsStepConfig,
    "update_member_role": UpdateMemberRoleStepConfig,
    "set_member_capabilities": SetMemberCapabilitiesStepConfig,
    "get_member_capabilities": GetMemberCapabilitiesStepConfig,
    "set_default_capabilities": SetDefaultCapabilitiesStepConfig,
    "set_default_visibility": SetDefaultVisibilityStepConfig,
    "set_subgroup_visibility": SetSubgroupVisibilityStepConfig,
    "get_group_info": GetGroupInfoStepConfig,
    "delete_group": DeleteGroupStepConfig,
    "delete_namespace": DeleteNamespaceStepConfig,
    "delete_context": DeleteContextStepConfig,
    "uninstall_application": UninstallApplicationStepConfig,
    "set_group_alias": SetGroupAliasStepConfig,
    "set_member_alias": SetMemberAliasStepConfig,
    "update_group_settings": UpdateGroupSettingsStepConfig,
    "detach_context_from_group": DetachContextFromGroupStepConfig,
    "sync_group": SyncGroupStepConfig,
    "register_group_signing_key": RegisterGroupSigningKeyStepConfig,
    "upgrade_group": UpgradeGroupStepConfig,
    "get_group_upgrade_status": GetGroupUpgradeStatusStepConfig,
    "retry_group_upgrade": RetryGroupUpgradeStepConfig,
    "call": CallStep,
    "wait": WaitStep,
    "wait_for_sync": WaitForSyncStep,
    "repeat": RepeatStep,
    "parallel": ParallelStep,
    "script": ScriptStep,
    "assert": AssertStep,
    "json_assert": JsonAssertStep,
    "get_proposal": GetProposalStep,
    "list_proposals": ListProposalsStep,
    "get_proposal_approvers": GetProposalApproversStep,
    "upload_blob": UploadBlobStep,
    "create_mesh": CreateMeshStep,
    "fuzzy_test": FuzzyTestStep,
}


class WorkflowConfig(BaseModel):
    """Complete workflow configuration schema."""

    model_config = ConfigDict(extra="allow")

    name: str = Field(..., description="Name of the workflow")
    description: Optional[str] = Field(None, description="Description of the workflow")

    # Node configurations (at least one of nodes or remote_nodes must be specified)
    nodes: Optional[Union[NodesConfig, dict[str, Any]]] = Field(
        None, description="Local node configuration"
    )
    remote_nodes: Optional[dict[str, RemoteNodeConfig]] = Field(
        None, description="Remote node configurations"
    )

    # Workflow steps
    steps: Optional[list[dict[str, Any]]] = Field(
        None, description="List of workflow steps"
    )

    # Lifecycle options
    nuke_on_start: Optional[bool] = Field(
        False, description="Nuke all data before starting"
    )
    nuke_on_end: Optional[bool] = Field(
        False, description="Nuke all data after workflow"
    )
    stop_all_nodes: Optional[bool] = Field(
        False, description="Stop all nodes at the end"
    )
    restart: Optional[bool] = Field(False, description="Restart nodes at the beginning")

    # Timing options
    wait_timeout: Optional[int] = Field(
        60, ge=1, description="Timeout for waiting operations"
    )

    # Docker options
    force_pull_image: Optional[bool] = Field(
        False, description="Force pull Docker images"
    )

    # Auth service options
    auth_service: Optional[bool] = Field(
        False, description="Enable authentication service"
    )
    auth_image: Optional[str] = Field(
        None, description="Custom Docker image for auth service"
    )
    auth_use_cached: Optional[bool] = Field(False, description="Use cached auth tokens")
    webui_use_cached: Optional[bool] = Field(False, description="Use cached WebUI")
    auth_mode: Optional[str] = Field(None, description="Auth mode (e.g., embedded)")

    # Logging options
    log_level: Optional[str] = Field("debug", description="Log level for nodes")
    rust_backtrace: Optional[str] = Field("0", description="RUST_BACKTRACE setting")

    # E2E and testing options
    e2e_mode: Optional[bool] = Field(False, description="Enable E2E testing mode")
    bootstrap_nodes: Optional[list[str]] = Field(
        None, description="Bootstrap nodes to connect to"
    )


def _format_pydantic_error(error: dict[str, Any]) -> str:
    """Format a single Pydantic validation error into a readable message."""
    loc = ".".join(str(x) for x in error.get("loc", []))
    msg = error.get("msg", "Unknown error")

    if loc:
        return f"{loc}: {msg}"
    return msg


def validate_workflow_step(step: dict[str, Any], step_index: int) -> list[str]:
    """
    Validate a single workflow step and return a list of validation errors.

    Args:
        step: The step configuration dictionary
        step_index: The index of the step (for error messages)

    Returns:
        List of validation error messages (empty if valid)
    """
    # Guard against non-dict steps (e.g., null or scalar values in YAML)
    if not isinstance(step, dict):
        return [f"Step {step_index}: Expected a mapping but got {type(step).__name__}"]

    errors = []
    step_name = step.get("name", f"Step {step_index + 1}")
    step_type = step.get("type")

    if not step_type:
        errors.append(
            f"Step '{step_name}' (index {step_index}): Missing required field 'type'"
        )
        return errors

    if step_type not in VALID_STEP_TYPES:
        errors.append(
            f"Step '{step_name}' (index {step_index}): Invalid step type '{step_type}'. "
            f"Valid types are: {', '.join(sorted(VALID_STEP_TYPES))}"
        )
        return errors

    # Type-specific validation using module-level mapping
    model_class = STEP_TYPE_MODELS.get(step_type)
    if model_class:
        try:
            model_class.model_validate(step)
        except ValidationError as e:
            # Use structured error access for reliable parsing
            for err in e.errors():
                formatted = _format_pydantic_error(err)
                errors.append(f"Step '{step_name}' (index {step_index}): {formatted}")
        except Exception as e:
            errors.append(f"Step '{step_name}' (index {step_index}): {str(e)}")

    # Recursively validate nested steps (for repeat and parallel)
    if step_type == "repeat":
        # Use `or []` to handle null values when key exists with no value
        nested_steps = step.get("steps") or []
        for i, nested_step in enumerate(nested_steps):
            nested_errors = validate_workflow_step(nested_step, i)
            for err in nested_errors:
                errors.append(f"Step '{step_name}' (index {step_index}) -> {err}")

    elif step_type == "parallel":
        # Use `or []` to handle null values when key exists with no value
        groups = step.get("groups") or []
        for g_idx, group in enumerate(groups):
            # Guard against non-dict group elements
            if not isinstance(group, dict):
                errors.append(
                    f"Step '{step_name}' (index {step_index}): "
                    f"Group {g_idx} must be a mapping but got {type(group).__name__}"
                )
                continue
            group_name = group.get("name", f"Group {g_idx + 1}")
            # Use `or []` for nested steps as well
            nested_steps = group.get("steps") or []
            for i, nested_step in enumerate(nested_steps):
                nested_errors = validate_workflow_step(nested_step, i)
                for err in nested_errors:
                    errors.append(
                        f"Step '{step_name}' (index {step_index}) -> {group_name} -> {err}"
                    )

    return errors


def validate_workflow_config(config: dict[str, Any]) -> list[str]:
    """
    Validate workflow configuration and return a list of validation errors.

    This function validates the entire workflow configuration including:
    - Required top-level fields (name, nodes/remote_nodes)
    - Node configuration structure
    - All workflow steps and their required fields

    Args:
        config: The workflow configuration dictionary

    Returns:
        List of validation error messages (empty if valid)
    """
    errors = []

    # Validate top-level structure
    try:
        WorkflowConfig.model_validate(config)
    except ValidationError as e:
        # Use structured error access for reliable parsing
        for err in e.errors():
            formatted = _format_pydantic_error(err)
            errors.append(f"Workflow config: {formatted}")
    except Exception as e:
        errors.append(f"Workflow config: {str(e)}")

    # Check for required nodes configuration
    if not config.get("nodes") and not config.get("remote_nodes"):
        errors.append(
            "Workflow config: At least one of 'nodes' or 'remote_nodes' must be specified"
        )

    # Validate each step (handle None value when key exists but has no value)
    steps = config.get("steps") or []
    for i, step in enumerate(steps):
        step_errors = validate_workflow_step(step, i)
        errors.extend(step_errors)

    return errors


def format_validation_errors(errors: list[str]) -> str:
    """
    Format validation errors into a user-friendly message.

    Args:
        errors: List of validation error messages

    Returns:
        Formatted error message string
    """
    if not errors:
        return ""

    header = "Workflow configuration validation failed:\n"
    error_list = "\n".join(f"  - {err}" for err in errors)
    footer = "\n\nPlease check your workflow YAML file and fix the issues above."

    return f"{header}{error_list}{footer}"


def expand_env_vars(value: Any) -> Any:
    """
    Recursively expand ${ENV_VAR} placeholders in strings.

    Supports:
    - ${VAR} - expands to environment variable value
    - ${VAR:-default} - expands to default if VAR is not set

    Args:
        value: The value to expand (can be str, dict, list, or other)

    Returns:
        The value with environment variables expanded
    """
    if isinstance(value, str):

        def replace_env_var(match: re.Match) -> str:
            var_name = match.group(1)
            default_value = match.group(2)
            env_value = os.environ.get(var_name)
            if env_value is not None:
                return env_value
            elif default_value is not None:
                return default_value
            else:
                console.print(
                    f"[yellow]Warning: Environment variable ${{{var_name}}} is not set[/yellow]"
                )
                return match.group(0)  # Return original placeholder if not found

        return ENV_VAR_PATTERN.sub(replace_env_var, value)

    elif isinstance(value, dict):
        return {k: expand_env_vars(v) for k, v in value.items()}

    elif isinstance(value, list):
        return [expand_env_vars(item) for item in value]

    return value


def expand_remote_nodes_auth(config: dict[str, Any]) -> dict[str, Any]:
    """
    Expand environment variables in remote_nodes auth configuration.

    This function specifically targets the auth fields in remote_nodes
    where sensitive credentials are likely to be stored as env vars.

    Args:
        config: The workflow configuration dictionary

    Returns:
        The configuration with auth fields expanded
    """
    if "remote_nodes" not in config:
        return config

    remote_nodes = config.get("remote_nodes", {})
    if not isinstance(remote_nodes, dict):
        return config

    expanded_remote_nodes = {}
    for node_name, node_config in remote_nodes.items():
        if not isinstance(node_config, dict):
            expanded_remote_nodes[node_name] = node_config
            continue

        expanded_node = dict(node_config)

        # Expand auth fields
        if "auth" in expanded_node and isinstance(expanded_node["auth"], dict):
            expanded_node["auth"] = expand_env_vars(expanded_node["auth"])

        # Also expand url in case it contains env vars
        if "url" in expanded_node:
            expanded_node["url"] = expand_env_vars(expanded_node["url"])

        expanded_remote_nodes[node_name] = expanded_node

    config["remote_nodes"] = expanded_remote_nodes
    return config


def load_workflow_config(
    config_path: str, validate_only: bool = False, skip_schema_validation: bool = False
) -> dict[str, Any]:
    """Load workflow configuration from YAML file.

    Supports:
    - Traditional local/docker/binary nodes via `nodes:` key
    - Remote nodes via `remote_nodes:` key
    - Mixed configurations with both local and remote nodes
    - ${ENV_VAR} expansion in remote_nodes auth fields
    - Full schema validation with helpful error messages

    Args:
        config_path: Path to the workflow YAML file
        validate_only: If True, skip strict validation (legacy behavior)
        skip_schema_validation: If True, skip Pydantic schema validation

    Returns:
        The parsed and processed workflow configuration

    Raises:
        FileNotFoundError: If the config file doesn't exist
        ValueError: If the YAML is invalid or required fields are missing
    """
    try:
        with open(config_path) as file:
            config = yaml.safe_load(file)

        # Handle empty YAML files (yaml.safe_load returns None for empty files)
        if config is None:
            config = {}

        # Expand environment variables in remote_nodes auth
        config = expand_remote_nodes_auth(config)

        # Skip basic validation if this is just for validation purposes
        if not validate_only:
            # Validate required fields
            # A workflow must have a name and at least one of: nodes or remote_nodes
            if "name" not in config:
                raise ValueError("Missing required field: name")

            has_local_nodes = "nodes" in config and config["nodes"]
            has_remote_nodes = "remote_nodes" in config and config["remote_nodes"]

            if not has_local_nodes and not has_remote_nodes:
                raise ValueError(
                    "Missing required field: either 'nodes' or 'remote_nodes' must be specified"
                )

        # Perform schema validation unless explicitly skipped or in validate_only mode
        # (validate_only mode is used by the validate command which has its own validator)
        if not skip_schema_validation and not validate_only:
            validation_errors = validate_workflow_config(config)
            if validation_errors:
                error_message = format_validation_errors(validation_errors)
                # Print detailed errors to console for visibility
                console.print(f"[red]{error_message}[/red]")
                raise ValueError(error_message)

        return config

    except FileNotFoundError as e:
        raise FileNotFoundError(
            f"Workflow configuration file not found: {config_path}"
        ) from e
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML format: {str(e)}") from e
    except ValueError:
        # Re-raise ValueError as-is (includes our validation errors)
        raise
    except Exception as e:
        raise ValueError(f"Failed to load configuration: {str(e)}") from e


def create_sample_workflow_config(output_path: str = "workflow-example.yml"):
    """Create a sample workflow configuration file."""
    sample_config = {
        "name": "Sample Calimero Workflow",
        "description": "A sample workflow that demonstrates the bootstrap functionality with dynamic value capture",
        # Nuke all data before starting workflow (complete cleanup)
        "nuke_on_start": False,
        # Nuke all data after completing workflow (complete cleanup)
        "nuke_on_end": False,
        "stop_all_nodes": True,  # Stop all existing nodes before starting
        "wait_timeout": 60,  # Wait up to 60 seconds for nodes to be ready
        "force_pull_image": False,  # Force pull Docker images even if they exist locally
        "auth_service": False,  # Enable authentication service with Traefik proxy
        # Custom Docker image for the auth service
        "auth_image": "ghcr.io/calimero-network/mero-auth:edge",
        # Set the RUST_LOG level for Calimero nodes (error, warn, info, debug, trace)
        "log_level": "debug",
        # Set the RUST_BACKTRACE level for Calimero nodes (0, 1, full)
        "rust_backtrace": "0",
        "nodes": {
            "count": 2,
            "prefix": "calimero-node",
            "image": "ghcr.io/calimero-network/merod:6a47604",
        },
        "steps": [
            {
                "name": "Install Application on Node 1",
                "type": "install_application",
                "node": "calimero-node-1",
                "path": "./workflow-examples/res/kv_store.wasm",
                "dev": True,
                "outputs": {"app_id": "id"},
            },
            {
                "name": "Create Namespace on Node 1",
                "type": "create_namespace",
                "node": "calimero-node-1",
                "application_id": "{{app_id}}",
                "outputs": {"namespace_id": "namespaceId"},
            },
            {
                "name": "Create Context on Node 1",
                "type": "create_context",
                "node": "calimero-node-1",
                "application_id": "{{app_id}}",
                "group_id": "{{namespace_id}}",
                "outputs": {"context_id": "id", "member_public_key": "memberPublicKey"},
            },
            {
                "name": "Create Identity on Node 2",
                "type": "create_identity",
                "node": "calimero-node-2",
                "outputs": {"public_key": "publicKey"},
            },
            {
                "name": "Create Namespace Invitation",
                "type": "create_namespace_invitation",
                "node": "calimero-node-1",
                "namespace_id": "{{namespace_id}}",
                "outputs": {"invitation": "invitation"},
            },
            {
                "name": "Join Namespace from Node 2",
                "type": "join_namespace",
                "node": "calimero-node-2",
                "namespace_id": "{{namespace_id}}",
                "invitation": "{{invitation}}",
            },
            {
                "name": "Execute Contract Call Example",
                "type": "call",
                "node": "calimero-node-1",
                "context_id": "{{context_id}}",
                "method": "set",
                "args": {"key": "hello", "value": "world"},
                "outputs": {"call_result": "result"},
            },
        ],
    }

    try:
        with open(output_path, "w") as file:
            yaml.dump(sample_config, file, default_flow_style=False, indent=2)

        console.print(
            f"[green]✓ Sample workflow configuration created: {output_path}[/green]"
        )
        console.print(
            "[yellow]Note: Dynamic values are automatically captured and used with placeholders[/yellow]"
        )
        console.print(
            "[yellow]Note: Use 'script' step type to execute scripts on Docker images or running nodes[/yellow]"
        )

    except Exception as e:
        console.print(f"[red]Failed to create sample configuration: {str(e)}[/red]")
