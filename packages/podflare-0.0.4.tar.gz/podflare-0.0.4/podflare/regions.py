"""Podflare region registry.

Each region maps to a dedicated hostd endpoint URL. Sandboxes are
physically bound to the host they were created on — there is no
cross-region migration yet. Pick the region closest to your workload's
users / data.

Override the URL for any region via env var, e.g. PODFLARE_REGION_US_URL=...
— useful for staging environments or self-hosted deployments.
"""
from __future__ import annotations

import os

REGIONS: dict[str, str] = {
    "eu": os.environ.get("PODFLARE_REGION_EU_URL", "https://api.podflare.ai"),
    "us": os.environ.get("PODFLARE_REGION_US_URL", "https://us-api.podflare.ai"),
}


class UnknownRegionError(ValueError):
    pass


def resolve_region(region: str | None) -> str | None:
    """Return the host URL for a named region, or None if no region was
    requested (caller uses the default)."""
    if region is None:
        return None
    key = region.lower()
    if key not in REGIONS:
        raise UnknownRegionError(
            f"unknown region '{region}'. available: {sorted(REGIONS)}"
        )
    return REGIONS[key]
