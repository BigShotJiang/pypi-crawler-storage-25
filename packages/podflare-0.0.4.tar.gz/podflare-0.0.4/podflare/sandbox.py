from __future__ import annotations

from typing import Iterator

from podflare.client import Client
from podflare.regions import resolve_region
from podflare.types import Event, ExecResult, Language  # noqa: F401 — Event re-exported via replay


# Module-level default clients, keyed by host URL (None = env-default).
# Back-to-back Sandbox() calls that target the same region reuse the same
# httpx.Client — TLS handshake + connection pool amortized across calls.
_default_clients: dict[str | None, Client] = {}


def _get_default_client(host: str | None = None) -> Client:
    if host not in _default_clients:
        _default_clients[host] = Client(host=host)
    return _default_clients[host]


def close_default_client() -> None:
    """Close all shared default clients. Idempotent. Safe to call at shutdown
    if you want to free open connections deterministically."""
    global _default_clients
    for c in _default_clients.values():
        c.close()
    _default_clients = {}


class Sandbox:
    """A Podflare sandbox."""

    def __init__(
        self,
        *,
        template: str | None = None,
        region: str | None = None,
        host: str | None = None,
        client: Client | None = None,
        traceparent: str | None = None,
        api_key: str | None = None,
    ):
        """Create a new sandbox.

        Args:
            region: "us" | "eu" — pick the hostd region closest to your
                users. Overrides `host` if both are passed.
            host: Explicit hostd URL. Overrides env + default if set.
            template: Template name (e.g. "python-datasci").
            client: Pre-built Client to reuse across sandboxes. If passed,
                region/host/traceparent/api_key are ignored.
            traceparent: W3C Trace Context string to propagate.
            api_key: Explicit bearer token (otherwise PODFLARE_API_KEY).
        """
        # Region wins over host.
        resolved_host = resolve_region(region) or host

        if client is not None:
            # Caller brought their own client — trust it.
            self._client = client
            self._owns_client = False
        elif traceparent is None and api_key is None:
            # No client-level options beyond region/host → share a default
            # client keyed on the host URL. Keeps TLS + connection pools
            # warm across repeated Sandbox(region="us") calls.
            self._client = _get_default_client(resolved_host)
            self._owns_client = False
        else:
            self._client = Client(
                host=resolved_host, traceparent=traceparent, api_key=api_key
            )
            self._owns_client = True
        self.id = self._client.create_sandbox(template=template)

    @classmethod
    def _from_id(cls, sandbox_id: str, client: Client) -> "Sandbox":
        """Wrap an existing sandbox id (e.g., a fork child) without creating."""
        instance = cls.__new__(cls)
        instance.id = sandbox_id
        instance._client = client
        instance._owns_client = False
        return instance

    def __enter__(self) -> "Sandbox":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def replay(self) -> list[Event]:
        """Return the recent event history for this sandbox (up to 1000
        events). Useful for audit, debugging, and nesting under OTel traces
        after the fact."""
        return self._client.replay(self.id)

    def fork(self, n: int = 1) -> list["Sandbox"]:
        """Snapshot this sandbox mid-flight and spawn N CoW children.

        Each child starts from this sandbox's current state; subsequent
        execution is isolated (copy-on-write memory + reflinked rootfs).
        Destroying a child does not affect this sandbox.
        """
        if n < 1:
            raise ValueError("fork n must be >= 1")
        child_ids = self._client.fork_sandbox(self.id, n)
        return [Sandbox._from_id(cid, client=self._client) for cid in child_ids]

    def merge_into(self, winner: "Sandbox") -> None:
        """Replace this sandbox's state with `winner`'s.

        `winner` should be a fork child of this sandbox. After merge, this
        sandbox's id continues to work and now reflects winner's VM state.
        `winner`'s original id becomes defunct — do not call any methods on
        `winner` after merge; it is silently marked closed.
        """
        if winner.id == self.id:
            raise ValueError("cannot merge a sandbox into itself")
        self._client.merge_into(self.id, winner.id)
        winner._merged_into_parent = True  # type: ignore[attr-defined]

    def upload(self, local_path: str | bytes, remote_path: str) -> None:
        """Copy a local file (or raw bytes) to `remote_path` inside the sandbox.

        Implementation: embeds the base64-encoded data in a Python snippet
        executed via run_code. Suitable for files up to a few MB; larger
        transfers should wait on a dedicated streaming endpoint.
        """
        import base64

        if isinstance(local_path, bytes):
            data = local_path
        else:
            with open(local_path, "rb") as f:
                data = f.read()
        b64 = base64.b64encode(data).decode()
        code = (
            "import base64, os\n"
            f"os.makedirs(os.path.dirname({remote_path!r}) or '.', exist_ok=True)\n"
            f"with open({remote_path!r}, 'wb') as _f:\n"
            f"    _f.write(base64.b64decode({b64!r}))\n"
        )
        r = self.run_code(code, language="python")
        if r.exit_code != 0:
            raise IOError(f"upload failed: {r.stderr}")

    def download(self, remote_path: str) -> bytes:
        """Read `remote_path` inside the sandbox and return its bytes."""
        import base64

        code = (
            "import base64, sys\n"
            f"with open({remote_path!r}, 'rb') as _f:\n"
            "    sys.stdout.write(base64.b64encode(_f.read()).decode())\n"
        )
        r = self.run_code(code, language="python")
        if r.exit_code != 0:
            raise IOError(f"download failed: {r.stderr}")
        return base64.b64decode(r.stdout.strip())

    def diff(
        self,
        other: "Sandbox",
        paths: list[str] | None = None,
    ) -> dict[str, list[str]]:
        """Compare filesystem state with another sandbox.

        Runs sha256sum of every file under `paths` (default: /root /tmp) in
        both sandboxes and returns {"added": [...], "removed": [...],
        "modified": [...]}, where "added" means files present in `other` but
        not `self`, etc. Fast: two parallel bash runs, one diff in Python.
        """
        paths = paths or ["/root", "/tmp"]
        cmd = (
            "find "
            + " ".join(paths)
            + " -type f -exec sha256sum {} + 2>/dev/null | sort"
        )
        a = self.run_code(cmd, language="bash").stdout
        b = other.run_code(cmd, language="bash").stdout

        def parse(s: str) -> dict[str, str]:
            out: dict[str, str] = {}
            for line in s.splitlines():
                line = line.strip()
                if not line:
                    continue
                # "<sha>  <path>"
                parts = line.split(maxsplit=1)
                if len(parts) == 2:
                    out[parts[1]] = parts[0]
            return out

        a_map = parse(a)
        b_map = parse(b)
        a_keys = set(a_map)
        b_keys = set(b_map)
        return {
            "added": sorted(b_keys - a_keys),
            "removed": sorted(a_keys - b_keys),
            "modified": sorted(
                p for p in a_keys & b_keys if a_map[p] != b_map[p]
            ),
        }

    def close(self) -> None:
        # Don't destroy if we were merged into a parent.
        if getattr(self, "_merged_into_parent", False):
            return
        try:
            self._client.destroy_sandbox(self.id)
        finally:
            if self._owns_client:
                self._client.close()

    def run_code_stream(self, code: str, language: Language = "python") -> Iterator[Event]:
        """Stream raw events as they arrive from the executor."""
        return self._client.exec_stream(self.id, code, language)

    def run_code(self, code: str, language: Language = "python") -> ExecResult:
        """Run code and return the accumulated result. Blocks until exit."""
        stdout_parts: list[str] = []
        stderr_parts: list[str] = []
        exit_code = -1
        for ev in self.run_code_stream(code, language):
            if ev.type == "stdout":
                stdout_parts.append(str(ev.data))
            elif ev.type == "stderr":
                stderr_parts.append(str(ev.data))
            elif ev.type == "exit":
                exit_code = int(ev.data)
        return ExecResult(
            stdout="\n".join(stdout_parts),
            stderr="\n".join(stderr_parts),
            exit_code=exit_code,
        )
