"""Convert echoSMs shape format.

Converts old echoSMs KRM and DWBA shape data format into the new echoSMs
anatomical data store metadata and shape formats.
"""

# /// script
# requires-python = ">=3.11"
# dependencies = [
#     "echosms>=0.20.1",
#     "numpy",
#     "tomli-w",
# ]
# ///

import copy
import numpy as np
from datetime import datetime, timezone
from echosms import KRMdata, DWBAdata, outline_from_krm, boundary_type as bt
from echosms import names_from_aphia_id
import tomli_w
import uuid
from pathlib import Path
import platform

match platform.node():
    case 'AQUALYD-P14':
        datastore_dir = Path(r'C:\Users\GavinMacaulay\Data - not synced\temp\anatomical data store')
    case 'AQUALYD-P3':
        datastore_dir = Path(r'C:\Users\GavinMacaulay\OneDrive - Aqualyd Limited\Documents\Aqualyd'
                            r'\Projects\2024-05 NOAA modelling\working\anatomical data store')
    case _:
        raise ValueError('Unsupported development system - edit me and try again')


# Datset template
specimen_t = {'uuid': '',
             'dataset_uuid': '',
             'dataset_name': '',
             'description': [''],
             'anatomical_category': "organism",
             'version_time': '',
             'version_number': 1,
             'version_note': 'Initial version',
             'version_investigators': [],
             'aphia_id': 1,
             'class': "",
             'order': "",
             'family': "",
             'genus': "",
             'species': "",
             'vernacular_names': [""],
             'reference': '',
             'date_collection': "",
             'date_image': "",
             'data_collection_description': "",
             'notes': [],
             'imaging_method': "unknown",
             'shape_method': "unknown",
             'shape_method_processing': "unknown",
             'model_type': "",
             'sound_speed_method': "unknown",
             'mass_density_method': "unknown",
             'shapes': []}


########################
# KRM models
d = KRMdata()

specimens = []
# All the echoSMs KRM model are grouped into the same dataset
dataset_uuid = str(uuid.uuid4())
dataset_name = 'echoSMs KRM'

# create models from the echoSMs KRM data
for model_name in d.names():
    m = d.model(model_name)

    specimen = copy.deepcopy(specimen_t)
    specimen['dataset_uuid'] = dataset_uuid
    specimen['dataset_name'] = dataset_name
    specimen['uuid'] = str(uuid.uuid4())
    specimen['aphia_id'] = m.aphiaid
    specimen['shape_method'] = 'unknown'
    specimen['model_type'] = 'KRM'
    specimen['description'] = ['Shape data for KRM models']
    specimen['notes'] = ['Shape obtained from the KRM shapes available at '
    'https://www.fisheries.noaa.gov/data-tools/krm-model. ',
    'This is not necessarily the original source of the shape.']

    print(f'Querying WoRMS for aphiaID {m.aphiaid}')
    names = names_from_aphia_id(m.aphiaid)
    for k, v in names.items():
        if k not in names:
            names[k] = v

    specimen['reference'] = m.source
    specimen['version_time'] = datetime.now(timezone.utc).isoformat()

    specimen.update({'specimen_name': m.name, 'specimen_condition': 'unknown',
                     'length': m.length,
                     'length_units': 'm',
                     'sex': 'unknown',
                     'length_type': 'unknown', 'shape_type': 'outline',
                     'shapes': []})

    shape = outline_from_krm(m.body.x, m.body.z_U, m.body.z_L,
                             m.body.w, boundary=m.body.boundary)
    shape['mass_density'] = len(m.body.x) * [m.body.rho]
    shape['mass_density_units'] = 'kg/m^3'
    shape['sound_speed_compressional'] = len(m.body.x) * [m.body.c]
    shape['sound_speed_compressional_units'] = 'm/s'
    shape['shape_units'] = "m"
    shape['straightened'] = True
    shape['smoothed'] = False
    shape['rotated'] = True
    specimen['shapes'].append(shape)

    for inc in m.inclusions:
        a_type = 'swimbladder' if inc.rho < 100 else 'bone'
        shape = outline_from_krm(inc.x, inc.z_U, inc.z_L,
                                 inc.w, boundary=inc.boundary,
                                 anatomical_feature=a_type)
        shape['mass_density'] = len(inc.x) * [inc.rho]
        shape['mass_density_units'] = 'kg/m^3'
        shape['sound_speed_compressional'] = len(inc.x) * [inc.c]
        shape['sound_speed_compressional_units'] = 'm/s'
        shape['shape_units'] = "m"
        specimen['shapes'].append(shape)

    specimens.append(specimen)

# ############################
# DWBA models
d = DWBAdata()
# All the echoSMs DWBA model are grouped into the same dataset
dataset_uuid = str(uuid.uuid4())
dataset_name = 'echoSMs DWBA'

for model_name in d.names():
    m = d.model(model_name)

    # populate dataset metadata
    specimen = copy.deepcopy(specimen_t)
    specimen['dataset_uuid'] = dataset_uuid
    specimen['dataset_name'] = dataset_name
    specimen['uuid'] = str(uuid.uuid4())
    specimen['aphia_id'] = m.aphiaid
    specimen['shape_method'] = 'unknown'
    specimen['model_type'] = 'DWBA'
    specimen['description'] = ['Some DWBA shapes found on the internet.']
    specimen['model_type'] = 'DWBA'
    specimen['notes'] = ['Shape obtained from the SDWBA.jl github repository. '
    'This is not necessarily the original source of the shape.']

    print(f'Querying WoRMS for aphiaID {m.aphiaid}')
    names = names_from_aphia_id(m.aphiaid)
    for k, v in names.items():
        if k not in names:
            names[k] = v

    specimen['reference'] = m.source

    specimen.update({'specimen_name': m.name, 'specimen_condition': 'unknown',
                     'length': m.length,
                     'length_units': 'm',
                     'sex': 'unknown',
                     'length_type': 'unknown', 'shape_type': 'outline',
                     'shapes': []})

    shape = {'anatomical_feature': 'body',
             'shape_units': 'm',
             'straightened': True,
             'smoothed': True,
             'rotated': True,
             'boundary': bt.fluid_filled,
             'x': m.rv_pos[:, 0],
             'y': m.rv_pos[:, 1],
             'z': m.rv_pos[:, 2],
             'height': m.a*2,
             'width': m.a*2,
             'mass_density_ratio': m.g,
             'sound_speed_ratio': m.h}
    specimen['shapes'].append(shape)

    specimens.append(specimen)

# Convert the arrays to lists (to facilitate exporting to json and toml)
specimens_cp = copy.deepcopy(specimens)
for ds in specimens_cp:
    for s in ds['shapes']:
        for k in s.keys():
            if isinstance(s[k], np.ndarray):
                s[k] = s[k].tolist()

# Write out each specimen to a echoSMS datastore format toml file
for sp in specimens_cp:
    if sp['model_type'] == 'DWBA':
        directory = 'SDWBA.jl_github'
    else:
        directory = 'NOAA_KRM'

    file_name = datastore_dir/'datasets'/directory/('specimen_' + sp['uuid'])
    # Add .toml suffix even when the name already has a full stop in it
    file_name = file_name.with_name(f'{file_name.name}.toml')
    Path.mkdir(file_name.parent, parents=True, exist_ok=True)
    with open(file_name, 'wb') as f:
        tomli_w.dump(sp, f)
