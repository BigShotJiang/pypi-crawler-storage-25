# Outhad ContextKit SDK — API Reference

Thin Python client for the Outhad ContextKit cloud. Speaks HTTP to
`https://contextkit.outhad.com`. Ships **only** the network client —
no model providers, no vector store drivers, no local memory engine.

## Install

```bash
pip install outhad-contextkit-sdk
```

## Quick start

```python
from outhad_contextkit_sdk import MemoryClient

client = MemoryClient(api_key="ock_live_...")  # or set OUTHAD_CONTEXTKIT_API_KEY

client.add(
    messages=[{"role": "user", "content": "I love sushi"}],
    user_id="alice",
)

hits = client.search(query="What food do I like?", user_id="alice")
for hit in hits["results"]:
    print(hit["memory"], hit["score"])
```

## Pages

- [getting_started.md](getting_started.md) — install, auth, env vars, first call
- [memory_client.md](memory_client.md) — sync `MemoryClient` constructor + lifecycle
- [async_memory_client.md](async_memory_client.md) — async twin
- [memory_operations.md](memory_operations.md) — `add` / `get_all` / `get` / `search` / `update` / `history` / `delete` / `delete_all`
- [feedback_and_lifecycle.md](feedback_and_lifecycle.md) — `feedback` / `reset` / `users` / `delete_users` / `batch_update` / `batch_delete` / `summary` / `export`
- [multimodal.md](multimodal.md) — image + content-block support on `add`
- [retrieval_kwargs.md](retrieval_kwargs.md) — `top_k` / `threshold` / `use_context_graph` / `categories` / `output_format` / `includes` / `excludes`
- [ttl_and_pagination.md](ttl_and_pagination.md) — `expiration_date` + `page` / `page_size`
- [per_request_overrides.md](per_request_overrides.md) — `llm=` and `embedder=` per-call overrides
- [api_keys.md](api_keys.md) — `list_api_keys` / `create_api_key` / `revoke_api_key`
- [errors.md](errors.md) — `APIError`, `AuthenticationError` and status-code mapping
- [host_resolution.md](host_resolution.md) — production / dev fallback / explicit host

## Conventions

- All keyword args are keyword-only (after `*`). Positional args are
  the resource id or primary input only.
- Methods return the parsed JSON body (usually `dict` or `{"results": [...]}`).
- Network or 4xx/5xx errors raise `APIError`; 401 raises `AuthenticationError`.
- Every memory op needs **at least one** session id — `user_id`,
  `agent_id`, or `run_id`. Tenant scoping is automatic; the API key
  decides which tenant the call lands in.

## Versions

Current: **1.2.0**
- `feedback`, `reset`, `users`, `delete_users`, `batch_update`, `batch_delete`, `summary`, `export`
- multimodal `add` (text + image_url content blocks)
- `expiration_date` per-memory TTL
- retrieval kwargs: `top_k`, `threshold`, `use_context_graph`, `categories`
- shape control: `output_format`, `includes`, `excludes`, `version`
- pagination on `get_all` (`page`, `page_size`)
- `history(since=, until=)` time-range filter

**1.1.0** — per-request `llm=` / `embedder=` overrides.
