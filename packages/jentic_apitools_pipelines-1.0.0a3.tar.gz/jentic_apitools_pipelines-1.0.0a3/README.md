# Jentic API Tools - Pipelines

High-level workflows that orchestrate analyze, score, repair, and storage operations for OpenAPI specifications.

## Key Features

The pipelines package provides two main workflow functions: `import_openapi` runs the full import pipeline (fetch, parse, validate, convert, bundle, repair, score, store) and `score_openapi` runs a lighter scoring pipeline (fetch, parse, bundle, validate, score). Both functions accept an `OASJsonRequest` with processing configuration and an optional progress callback for real-time updates. The package handles format conversion from Swagger 2.0 and Google Discovery to OpenAPI 3.x, reference bundling via Redocly, and artifact management through configurable storage contexts. The `repo_tools` module provides `rebuild_scores_json` and `rebuild_apis_json` for rebuilding the root `scores.json` and `apis.json` catalog files from all API specs in a local repository clone.

## Dependencies

Internal: `common`, `llm`, `analyze`, `score`, `repair`, `storage`. External: jentic-openapi-transformer (with redocly), datadog.

## Installation

```bash
pip install jentic-apitools-pipelines
```

## Quick Start

```python
from jentic.apitools.common.models import OASJsonRequest, OASRequestMeta, OASProcessConfiguration
from jentic.apitools.pipelines import score_openapi

request = OASJsonRequest(meta=OASRequestMeta(oas_process_configuration=OASProcessConfiguration()))
result = score_openapi(request, spec_url="https://petstore3.swagger.io/api/v3/openapi.json")
print(f"Success: {result.success}")
```

## Testing

```bash
pytest tests -v
```
