import os
import subprocess
import sys
import logging
import structlog
from importlib.util import find_spec
from pathlib import Path

logger = structlog.get_logger(__name__)

def run_streamlit_gui(deploy: bool):
    """Run the Streamlit GUI"""
    # Get the installed file path to cmbagent.cli
    gui_spec = find_spec("cmbagent.cli")
    if gui_spec is None or gui_spec.origin is None:
        logger.error("cli_module_not_found")
        sys.exit(1)

    gui_path = gui_spec.origin.replace("cli.py", "gui/")

    # Ensure ~/.streamlit/config.toml exists and set theme to dark
    config_dir = os.path.expanduser("~/.streamlit")
    config_path = os.path.join(config_dir, "config.toml")
    os.makedirs(config_dir, exist_ok=True)

    theme_config = '[theme]\nbase = "dark"\n'

    # Write or update config.toml
    if os.path.exists(config_path):
        with open(config_path, "r") as f:
            lines = f.readlines()

        # Update existing theme section or append it
        with open(config_path, "w") as f:
            in_theme_block = False
            theme_written = False
            for line in lines:
                if line.strip().startswith("[theme]"):
                    in_theme_block = True
                    f.write(line)
                    f.write('base = "dark"\n')
                    theme_written = True
                    continue
                if in_theme_block and line.strip().startswith("["):
                    in_theme_block = False  # end of theme block
                if not in_theme_block:
                    f.write(line)

            if not theme_written:
                f.write("\n" + theme_config)
    else:
        with open(config_path, "w") as f:
            f.write(theme_config)

    # Run the Streamlit GUI
    logger.info("starting_streamlit_gui")
    logger.info("streamlit_interface_url", url="http://localhost:8501")
    command = ["streamlit", "run", gui_path + "gui.py"]
    if deploy:
        command.extend(["--","--deploy"])
    sys.exit(subprocess.call(command))

def main():
    import argparse
    parser = argparse.ArgumentParser(
        prog="cmbagent",
        description="CMBAgent - Multi-Agent System for Scientific Discovery"
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Run command with interface options
    run_parser = subparsers.add_parser(
        "run",
        help="Launch the CMBAgent user interface"
    )
    run_parser.add_argument(
        "--streamlit",
        action="store_true",
        default=True,
        help="Launch the Streamlit interface (default)"
    )

    # Deploy command (for Streamlit only - HuggingFace Spaces)
    subparsers.add_parser(
        "deploy",
        help="Launch Streamlit GUI with deployment settings for Hugging Face Spaces"
    )

    # Branch command
    branch_parser = subparsers.add_parser(
        "branch",
        help="Create a branch from a specific workflow step"
    )
    branch_parser.add_argument("run_id", help="Workflow run ID to branch from")
    branch_parser.add_argument("step_id", help="Step ID to branch from")
    branch_parser.add_argument("--name", required=True, help="Branch name")
    branch_parser.add_argument("--hypothesis", help="Hypothesis being tested")

    # Play-from command
    play_parser = subparsers.add_parser(
        "play-from",
        help="Resume execution from a specific node"
    )
    play_parser.add_argument("run_id", help="Workflow run ID")
    play_parser.add_argument("node_id", help="Node ID to resume from")

    # Compare command
    compare_parser = subparsers.add_parser(
        "compare",
        help="Compare two workflow branches"
    )
    compare_parser.add_argument("run_id_1", help="First run ID")
    compare_parser.add_argument("run_id_2", help="Second run ID")

    # Branch tree command
    tree_parser = subparsers.add_parser(
        "branch-tree",
        help="Visualize branch tree for a workflow"
    )
    tree_parser.add_argument("run_id", help="Root workflow run ID")

    args = parser.parse_args()

    if args.command == "run":
        run_streamlit_gui(False)
    elif args.command == "deploy":
        run_streamlit_gui(True)
    elif args.command == "branch":
        from cmbagent.database import get_db_session as get_session
        from cmbagent.branching import BranchManager
        import json

        db_session = get_session()
        manager = BranchManager(db_session, args.run_id)
        new_run_id = manager.create_branch(
            step_id=args.step_id,
            branch_name=args.name,
            hypothesis=args.hypothesis
        )
        db_session.close()

        logger.info("branch_created", branch_name=args.name, new_run_id=new_run_id)

    elif args.command == "play-from":
        from cmbagent.database import get_db_session as get_session
        from cmbagent.branching import PlayFromNodeExecutor
        import json

        db_session = get_session()
        executor = PlayFromNodeExecutor(db_session, args.run_id)
        result = executor.play_from_node(args.node_id)
        db_session.close()

        logger.info("workflow_prepared_for_resumption", status=result['status'], message=result['message'])

    elif args.command == "compare":
        from cmbagent.database import get_db_session as get_session
        from cmbagent.branching import BranchComparator
        import json

        db_session = get_session()
        comparator = BranchComparator(db_session)
        comparison = comparator.compare_branches(args.run_id_1, args.run_id_2)
        db_session.close()

        logger.info("branch_comparison", comparison=json.dumps(comparison, indent=2))

    elif args.command == "branch-tree":
        from cmbagent.database import get_db_session as get_session
        from cmbagent.branching import BranchComparator

        db_session = get_session()
        comparator = BranchComparator(db_session)
        tree = comparator.visualize_branch_tree(args.run_id)
        db_session.close()

        logger.info("branch_tree", tree=comparator._format_tree(tree))

    else:
        parser.print_help()
