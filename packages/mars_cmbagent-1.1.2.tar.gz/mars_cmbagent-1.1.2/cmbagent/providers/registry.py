"""
ProviderRegistry — Central registry of all LLM provider adapters.

Singleton. Populated at import time with built-in providers.
Backend can inject credentials at runtime.

Usage:
    from cmbagent.providers.registry import ProviderRegistry

    registry = ProviderRegistry.instance()
    registry.set_credentials("openai", {"api_key": "sk-..."})
    config = registry.get_model_config("gpt-4o")
"""

import os
import logging
from typing import Any, Dict, List, Optional

from .base import (
    LLMProviderAdapter,
    ProviderModelInfo,
    ProviderTestResult,
    ProviderStatus,
)

logger = logging.getLogger(__name__)


class ProviderRegistry:
    """
    Central registry of all LLM provider adapters.

    Singleton. Populated at import time with built-in providers.
    Backend can inject credentials at runtime via set_credentials().
    """

    _instance: Optional["ProviderRegistry"] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self._adapters: Dict[str, LLMProviderAdapter] = {}
        self._credentials: Dict[str, Dict[str, str]] = {}
        self._status: Dict[str, ProviderStatus] = {}
        self._register_builtins()

    @classmethod
    def instance(cls) -> "ProviderRegistry":
        return cls()

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton (for testing only)."""
        cls._instance = None

    # --- Registration ---

    def register(self, adapter: LLMProviderAdapter) -> None:
        """Register a provider adapter."""
        self._adapters[adapter.provider_id] = adapter
        self._status[adapter.provider_id] = ProviderStatus.NOT_CONFIGURED
        logger.info("Registered LLM provider: %s", adapter.provider_id)

    def _register_builtins(self) -> None:
        """Register all built-in providers."""
        from .openai_provider import OpenAIProvider
        from .azure_provider import AzureOpenAIProvider
        from .anthropic_provider import AnthropicProvider
        from .google_provider import GoogleGeminiProvider
        from .mistral_provider import MistralProvider
        from .aws_bedrock_provider import AWSBedrockProvider

        # Registration order matters for model resolution priority.
        # Azure before OpenAI ensures Azure wins for gpt-* models
        # when both are configured (enterprise override).
        # Bedrock is checked by prefix so order doesn't matter for it.
        for adapter_cls in [
            AzureOpenAIProvider,
            OpenAIProvider,
            AnthropicProvider,
            GoogleGeminiProvider,
            MistralProvider,
            AWSBedrockProvider,
        ]:
            self.register(adapter_cls())

        # Auto-load from environment on startup
        self.refresh_from_env()

    # --- Credential Management ---

    def set_credentials(self, provider_id: str, credentials: Dict[str, str]) -> None:
        """
        Inject credentials for a provider.
        Called by backend after UI onboarding or .env loading.
        Also sets corresponding os.environ vars so existing code continues to work.
        """
        adapter = self._adapters.get(provider_id)
        if not adapter:
            raise ValueError(f"Unknown provider: {provider_id}")

        self._credentials[provider_id] = credentials

        if adapter.is_configured(credentials):
            self._status[provider_id] = ProviderStatus.CONFIGURED
        else:
            self._status[provider_id] = ProviderStatus.NOT_CONFIGURED

        # Sync to os.environ for backward compatibility
        for cred_field in adapter.credential_fields:
            value = credentials.get(cred_field.name, "")
            if value:
                os.environ[cred_field.env_var] = value

    def remove_credentials(self, provider_id: str) -> None:
        """
        Remove credentials for a provider and clean up env vars.
        Called by backend after UI credential deletion.
        """
        adapter = self._adapters.get(provider_id)
        if not adapter:
            raise ValueError(f"Unknown provider: {provider_id}")

        self._credentials.pop(provider_id, None)
        self._status[provider_id] = ProviderStatus.NOT_CONFIGURED

        # Clean env vars that were set by set_credentials
        for cred_field in adapter.credential_fields:
            os.environ.pop(cred_field.env_var, None)

    def get_credentials(self, provider_id: str) -> Dict[str, str]:
        """Get stored credentials for a provider."""
        return self._credentials.get(provider_id, {})

    def get_status(self, provider_id: str) -> ProviderStatus:
        """Get current status for a provider."""
        return self._status.get(provider_id, ProviderStatus.NOT_CONFIGURED)

    async def validate_provider(self, provider_id: str) -> ProviderTestResult:
        """Test credentials for a specific provider."""
        adapter = self._adapters.get(provider_id)
        if not adapter:
            return ProviderTestResult(
                success=False, message=f"Unknown provider: {provider_id}"
            )

        creds = self._credentials.get(provider_id, {})
        result = await adapter.test_credentials(creds)

        self._status[provider_id] = (
            ProviderStatus.VALIDATED if result.success else ProviderStatus.INVALID
        )
        return result

    # --- Model Resolution (THE KEY METHOD) ---

    def get_model_config(self, model: str) -> Dict[str, Any]:
        """
        Given a model name, find the right provider and return
        an ag2-compatible LLM config dict.

        This REPLACES the hard-coded get_model_config() in utils.py.

        Resolution order:
        1. Check each *validated/configured* provider's model_matches()
        2. Use the matched provider's get_model_config_for_ag2()
        3. Fall back to active_provider if no match
        """
        # Try exact match on any provider that has credentials
        for pid, adapter in self._adapters.items():
            if self._status.get(pid) == ProviderStatus.NOT_CONFIGURED:
                continue
            if adapter.model_matches(model):
                creds = self._credentials.get(pid, {})
                return adapter.get_model_config_for_ag2(model, creds)

        # Fallback: use active provider
        active = self.get_active_provider()
        if active:
            creds = self._credentials.get(active.provider_id, {})
            return active.get_model_config_for_ag2(model, creds)

        raise ValueError(
            f"No configured provider found for model '{model}'. "
            f"Configure a provider via the Settings UI or .env file."
        )

    def get_active_provider(self) -> Optional[LLMProviderAdapter]:
        """Return the primary active provider.

        Priority: VALIDATED > CONFIGURED > INVALID.
        INVALID means credentials exist but validation failed (e.g., network
        issue, temporary outage). The user still intends to use this provider,
        so it should remain active.
        """
        for status_check in (ProviderStatus.VALIDATED, ProviderStatus.CONFIGURED, ProviderStatus.INVALID):
            for pid, adapter in self._adapters.items():
                if self._status.get(pid) == status_check:
                    return adapter
        return None

    # --- Introspection (for UI) ---

    def list_providers(self) -> List[Dict[str, Any]]:
        """Return all registered providers with their status and credential schema."""
        result = []
        for pid, adapter in self._adapters.items():
            stored_creds = self._credentials.get(pid, {})
            result.append(
                {
                    "provider_id": pid,
                    "display_name": adapter.display_name,
                    "status": self._status.get(
                        pid, ProviderStatus.NOT_CONFIGURED
                    ).value,
                    "credential_fields": [
                        {
                            "name": f.name,
                            "display_name": f.display_name,
                            "description": f.description,
                            "required": f.required,
                            "field_type": f.field_type,
                            "placeholder": f.placeholder,
                            "validation_pattern": f.validation_pattern,
                            "options": f.options,
                            "has_value": bool(stored_creds.get(f.name)),
                            "masked_value": _mask_value(stored_creds.get(f.name, ""))
                            if f.secret and stored_creds.get(f.name)
                            else stored_creds.get(f.name, ""),
                        }
                        for f in adapter.credential_fields
                    ],
                    "models": [
                        {
                            "model_id": m.model_id,
                            "display_name": m.display_name,
                            "context_window": m.context_window,
                            "max_output_tokens": m.max_output_tokens,
                            "supports_vision": m.supports_vision,
                            "category": m.category,
                        }
                        for m in adapter.get_available_models()
                    ],
                }
            )
        return result

    def get_available_models_for_configured_providers(self) -> List[Dict[str, str]]:
        """
        Return models from providers that have credentials set.
        Includes CONFIGURED, VALIDATED, and INVALID (credentials present
        but test failed — user still wants to select these models).
        Only NOT_CONFIGURED is excluded.
        """
        models = []
        seen = set()
        for pid, adapter in self._adapters.items():
            if self._status.get(pid) == ProviderStatus.NOT_CONFIGURED:
                continue
            for m in adapter.get_available_models():
                if m.model_id not in seen:
                    seen.add(m.model_id)
                    models.append(
                        {
                            "value": m.model_id,
                            "label": m.display_name,
                            "provider": pid,
                        }
                    )
        return models

    def refresh_from_env(self) -> None:
        """
        Re-read credentials from os.environ for all providers.
        Backward compatibility: called on startup to honor .env files.
        """
        for pid, adapter in self._adapters.items():
            env_creds = {}
            for cred_field in adapter.credential_fields:
                val = os.environ.get(cred_field.env_var, "")
                if val:
                    env_creds[cred_field.name] = val
            if env_creds:
                # Only update if we found something; don't overwrite UI-set creds
                existing = self._credentials.get(pid, {})
                if not existing:
                    self._credentials[pid] = env_creds
                    if adapter.is_configured(env_creds):
                        self._status[pid] = ProviderStatus.CONFIGURED


def _mask_value(value: str) -> str:
    """Mask a secret value for display: 'sk-proj-abc123xyz' -> 'sk-****...xyz'."""
    if not value or len(value) <= 8:
        return "****" if value else ""
    return f"{value[:4]}****...{value[-4:]}"
