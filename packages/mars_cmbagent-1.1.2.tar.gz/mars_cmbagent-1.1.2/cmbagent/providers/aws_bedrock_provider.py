"""AWS Bedrock provider adapter."""

import time
from typing import Any, Dict, List

from .base import (
    LLMProviderAdapter,
    ProviderCredentialField,
    ProviderModelInfo,
    ProviderTestResult,
)


class AWSBedrockProvider(LLMProviderAdapter):

    @property
    def provider_id(self) -> str:
        return "aws_bedrock"

    @property
    def display_name(self) -> str:
        return "AWS Bedrock"

    @property
    def credential_fields(self) -> List[ProviderCredentialField]:
        return [
            ProviderCredentialField(
                name="aws_access_key_id",
                env_var="AWS_ACCESS_KEY_ID",
                display_name="AWS Access Key ID",
                description="Your AWS IAM access key ID",
                field_type="text",
                placeholder="AKIA...",
                validation_pattern=r"^AKIA[A-Z0-9]{16}$",
            ),
            ProviderCredentialField(
                name="aws_secret_access_key",
                env_var="AWS_SECRET_ACCESS_KEY",
                display_name="AWS Secret Access Key",
                description="Your AWS IAM secret access key",
                field_type="password",
            ),
            ProviderCredentialField(
                name="aws_region",
                env_var="AWS_DEFAULT_REGION",
                display_name="AWS Region",
                description="Region where Bedrock is enabled",
                field_type="select",
                required=True,
                secret=False,
                options=[
                    {"value": "us-east-1", "label": "US East (N. Virginia)"},
                    {"value": "us-west-2", "label": "US West (Oregon)"},
                    {"value": "eu-west-1", "label": "EU (Ireland)"},
                    {"value": "eu-central-1", "label": "EU (Frankfurt)"},
                    {"value": "ap-northeast-1", "label": "Asia Pacific (Tokyo)"},
                    {"value": "ap-southeast-1", "label": "Asia Pacific (Singapore)"},
                    {"value": "ap-south-1", "label": "Asia Pacific (Mumbai)"},
                ],
            ),
            ProviderCredentialField(
                name="aws_session_token",
                env_var="AWS_SESSION_TOKEN",
                display_name="AWS Session Token",
                description="Optional: for temporary credentials (STS)",
                required=False,
                field_type="password",
            ),
            ProviderCredentialField(
                name="aws_profile",
                env_var="AWS_PROFILE",
                display_name="AWS Profile",
                description="Optional: named profile from ~/.aws/credentials",
                required=False,
                secret=False,
                field_type="text",
                placeholder="default",
            ),
        ]

    def get_available_models(self) -> List[ProviderModelInfo]:
        return [
            ProviderModelInfo(
                "bedrock/anthropic.claude-3-5-sonnet-20241022-v2:0",
                "Claude 3.5 Sonnet v2 (Bedrock)",
                self.provider_id,
                8192, context_window=200000, supports_vision=True,
            ),
            ProviderModelInfo(
                "bedrock/anthropic.claude-sonnet-4-20250514-v1:0",
                "Claude Sonnet 4 (Bedrock)",
                self.provider_id,
                16384, context_window=200000, supports_vision=True,
            ),
            ProviderModelInfo(
                "bedrock/amazon.nova-pro-v1:0",
                "Amazon Nova Pro (Bedrock)",
                self.provider_id,
                5120, context_window=300000,
            ),
            ProviderModelInfo(
                "bedrock/amazon.nova-lite-v1:0",
                "Amazon Nova Lite (Bedrock)",
                self.provider_id,
                5120, context_window=300000,
            ),
            ProviderModelInfo(
                "bedrock/meta.llama3-1-70b-instruct-v1:0",
                "Llama 3.1 70B (Bedrock)",
                self.provider_id,
                2048, context_window=128000,
            ),
            ProviderModelInfo(
                "bedrock/mistral.mistral-large-2407-v1:0",
                "Mistral Large (Bedrock)",
                self.provider_id,
                8192, context_window=128000,
            ),
        ]

    def is_configured(self, credentials: Dict[str, str]) -> bool:
        has_explicit = bool(
            credentials.get("aws_access_key_id")
            and credentials.get("aws_secret_access_key")
        )
        has_profile = bool(credentials.get("aws_profile"))
        return has_explicit or has_profile

    def _build_session_kwargs(self, credentials: Dict[str, str]) -> Dict[str, str]:
        """Build boto3 session kwargs from credentials."""
        session_kwargs: Dict[str, str] = {}
        if credentials.get("aws_access_key_id"):
            session_kwargs["aws_access_key_id"] = credentials["aws_access_key_id"]
            session_kwargs["aws_secret_access_key"] = credentials.get("aws_secret_access_key", "")
        if credentials.get("aws_session_token"):
            session_kwargs["aws_session_token"] = credentials["aws_session_token"]
        if credentials.get("aws_profile"):
            session_kwargs["profile_name"] = credentials["aws_profile"]
        if credentials.get("aws_region"):
            session_kwargs["region_name"] = credentials["aws_region"]
        return session_kwargs

    async def test_credentials(self, credentials: Dict[str, str]) -> ProviderTestResult:
        start = time.time()
        try:
            import boto3

            session_kwargs = self._build_session_kwargs(credentials)
            session = boto3.Session(**session_kwargs)
            client = session.client("bedrock")

            # List foundation models as a connectivity test
            response = client.list_foundation_models(byOutputModality="TEXT")
            model_ids = [m["modelId"] for m in response.get("modelSummaries", [])]

            elapsed = (time.time() - start) * 1000
            return ProviderTestResult(
                success=True,
                message=f"Connected. {len(model_ids)} models available.",
                latency_ms=elapsed,
                models_available=model_ids[:10],
            )
        except ImportError:
            return ProviderTestResult(
                success=False,
                message="boto3 not installed. Run: pip install boto3",
            )
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            return ProviderTestResult(
                success=False,
                message="AWS Bedrock connection failed",
                error_details=str(e),
                latency_ms=elapsed,
            )

    def create_client(self, credentials: Dict[str, str], **kwargs) -> Any:
        """Create a boto3 Bedrock Runtime client."""
        import boto3

        session_kwargs = self._build_session_kwargs(credentials)
        session = boto3.Session(**session_kwargs)
        return session.client("bedrock-runtime", **kwargs)

    def get_model_config_for_ag2(
        self, model: str, credentials: Dict[str, str]
    ) -> Dict[str, Any]:
        """
        ag2 supports AWS Bedrock via litellm proxy.
        Model format: "bedrock/anthropic.claude-3-sonnet..."
        litellm handles the actual AWS auth via env vars or boto3 session.
        """
        return {
            "model": model,
            "api_key": "bedrock",  # litellm sentinel
            "api_type": "bedrock",
            "aws_access_key": credentials.get("aws_access_key_id", ""),
            "aws_secret_key": credentials.get("aws_secret_access_key", ""),
            "aws_region": credentials.get("aws_region", "us-east-1"),
        }

    def resolve_model_name(self, model: str) -> str:
        return model

    def model_matches(self, model: str) -> bool:
        return model.startswith("bedrock/")
