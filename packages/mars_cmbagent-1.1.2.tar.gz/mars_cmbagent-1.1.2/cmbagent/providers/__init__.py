"""
Provider abstraction layer for multi-LLM support.

Exposes:
    ProviderRegistry      — singleton registry for all LLM provider adapters
    LLMProviderAdapter    — abstract base class for provider adapters
    ProviderStatus        — enum for provider status
    ProviderCredentialField, ProviderModelInfo, ProviderTestResult — data models
"""

from .base import (
    LLMProviderAdapter,
    ProviderStatus,
    ProviderCredentialField,
    ProviderModelInfo,
    ProviderTestResult,
)
from .registry import ProviderRegistry

__all__ = [
    "ProviderRegistry",
    "LLMProviderAdapter",
    "ProviderStatus",
    "ProviderCredentialField",
    "ProviderModelInfo",
    "ProviderTestResult",
]
