"""Google Gemini provider adapter."""

import time
from typing import Any, Dict, List

from .base import (
    LLMProviderAdapter,
    ProviderCredentialField,
    ProviderModelInfo,
    ProviderTestResult,
)


class GoogleGeminiProvider(LLMProviderAdapter):

    @property
    def provider_id(self) -> str:
        return "google"

    @property
    def display_name(self) -> str:
        return "Google Gemini"

    @property
    def credential_fields(self) -> List[ProviderCredentialField]:
        return [
            ProviderCredentialField(
                name="api_key",
                env_var="GEMINI_API_KEY",
                display_name="API Key",
                description="Your Google Gemini API key",
                placeholder="AIza...",
                validation_pattern=r"^AIza",
            ),
            ProviderCredentialField(
                name="project_id",
                env_var="GOOGLE_CLOUD_PROJECT",
                display_name="GCP Project ID",
                description="Optional: Google Cloud project ID for Vertex AI",
                required=False,
                secret=False,
                field_type="text",
                placeholder="my-gcp-project",
            ),
        ]

    def get_available_models(self) -> List[ProviderModelInfo]:
        return [
            ProviderModelInfo(
                "gemini-2.5-pro", "Gemini 2.5 Pro", "google",
                8192, context_window=1048576, supports_vision=True,
            ),
            ProviderModelInfo(
                "gemini-2.5-flash", "Gemini 2.5 Flash", "google",
                8192, context_window=1048576, supports_vision=True,
            ),
            ProviderModelInfo(
                "gemini-2.0-flash", "Gemini 2.0 Flash", "google",
                8192, context_window=1048576, supports_vision=True,
            ),
        ]

    def is_configured(self, credentials: Dict[str, str]) -> bool:
        return bool(credentials.get("api_key"))

    async def test_credentials(self, credentials: Dict[str, str]) -> ProviderTestResult:
        start = time.time()
        api_key = credentials.get("api_key", "")
        if not api_key:
            return ProviderTestResult(success=False, message="API key not provided")

        try:
            import aiohttp

            # Use the Gemini API to list models as a connectivity test
            url = f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}"
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    elapsed = (time.time() - start) * 1000
                    if resp.status == 200:
                        data = await resp.json()
                        model_names = [
                            m.get("name", "").split("/")[-1]
                            for m in data.get("models", [])[:10]
                        ]
                        return ProviderTestResult(
                            success=True,
                            message=f"Connected. {len(data.get('models', []))} models available.",
                            latency_ms=elapsed,
                            models_available=model_names,
                        )
                    elif resp.status == 400 or resp.status == 403:
                        return ProviderTestResult(
                            success=False,
                            message="Invalid Gemini API key",
                            latency_ms=elapsed,
                        )
                    else:
                        error_text = await resp.text()
                        return ProviderTestResult(
                            success=False,
                            message=f"Google API error (HTTP {resp.status})",
                            error_details=error_text,
                            latency_ms=elapsed,
                        )
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            return ProviderTestResult(
                success=False,
                message="Google Gemini connection failed",
                error_details=str(e),
                latency_ms=elapsed,
            )

    def create_client(self, credentials: Dict[str, str], **kwargs) -> Any:
        try:
            import google.generativeai as genai

            genai.configure(api_key=credentials.get("api_key", ""))
            return genai
        except ImportError:
            raise ImportError(
                "google-generativeai not installed. Run: pip install google-generativeai"
            )

    def get_model_config_for_ag2(
        self, model: str, credentials: Dict[str, str]
    ) -> Dict[str, Any]:
        return {
            "model": model,
            "api_key": credentials.get("api_key", ""),
            "api_type": "google",
        }

    def resolve_model_name(self, model: str) -> str:
        return model

    def model_matches(self, model: str) -> bool:
        return "gemini" in model.lower()
