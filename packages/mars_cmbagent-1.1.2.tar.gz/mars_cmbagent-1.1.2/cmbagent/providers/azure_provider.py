"""Azure OpenAI provider adapter."""

import json
import os
import time
from typing import Any, Dict, List

from .base import (
    LLMProviderAdapter,
    ProviderCredentialField,
    ProviderModelInfo,
    ProviderTestResult,
)


class AzureOpenAIProvider(LLMProviderAdapter):

    @property
    def provider_id(self) -> str:
        return "azure"

    @property
    def display_name(self) -> str:
        return "Azure OpenAI"

    @property
    def credential_fields(self) -> List[ProviderCredentialField]:
        return [
            ProviderCredentialField(
                name="api_key",
                env_var="AZURE_OPENAI_API_KEY",
                display_name="API Key",
                description="Your Azure OpenAI API key",
                placeholder="",
            ),
            ProviderCredentialField(
                name="endpoint",
                env_var="AZURE_OPENAI_ENDPOINT",
                display_name="Endpoint URL",
                description="Your Azure OpenAI resource endpoint (e.g., https://myresource.openai.azure.com)",
                field_type="url",
                secret=False,
                placeholder="https://your-resource.openai.azure.com",
            ),
            ProviderCredentialField(
                name="deployment",
                env_var="AZURE_OPENAI_DEPLOYMENT",
                display_name="Default Deployment",
                description="Default deployment name for your Azure OpenAI resource",
                required=False,
                secret=False,
                field_type="text",
                placeholder="gpt4o",
            ),
            ProviderCredentialField(
                name="api_version",
                env_var="AZURE_OPENAI_API_VERSION",
                display_name="API Version",
                description="Azure OpenAI API version",
                required=False,
                secret=False,
                field_type="text",
                placeholder="2024-12-01-preview",
            ),
            ProviderCredentialField(
                name="deployment_map",
                env_var="AZURE_OPENAI_DEPLOYMENT_MAP",
                display_name="Deployment Map (JSON)",
                description='Optional: JSON mapping model names to deployment names, e.g. {"gpt-4o": "my-gpt4o-deploy"}',
                required=False,
                secret=False,
                field_type="textarea",
                placeholder='{"gpt-4o": "gpt4o-deployment"}',
            ),
        ]

    def get_available_models(self) -> List[ProviderModelInfo]:
        # Azure mirrors OpenAI models via deployments
        return [
            ProviderModelInfo("gpt-4.1-2025-04-14", "GPT-4.1 (Azure)", "azure", 32768, context_window=1047576),
            ProviderModelInfo("gpt-4.1-mini", "GPT-4.1 Mini (Azure)", "azure", 32768, context_window=1047576),
            ProviderModelInfo("gpt-4o", "GPT-4o (Azure)", "azure", 16384, context_window=128000, supports_vision=True),
            ProviderModelInfo("gpt-4o-mini-2024-07-18", "GPT-4o Mini (Azure)", "azure", 16384, context_window=128000),
            ProviderModelInfo("o3-mini-2025-01-31", "o3-mini (Azure)", "azure", 100000, context_window=200000),
        ]

    def is_configured(self, credentials: Dict[str, str]) -> bool:
        return bool(credentials.get("api_key") and credentials.get("endpoint"))

    def _get_deployment_map(self, credentials: Dict[str, str]) -> Dict[str, str]:
        """Parse the deployment map from credentials."""
        raw = credentials.get("deployment_map", "")
        if not raw:
            return {}
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return {}

    def _resolve_deployment(self, model: str, credentials: Dict[str, str]) -> str:
        """Map a model name to an Azure deployment name."""
        deployment_map = self._get_deployment_map(credentials)
        if deployment_map:
            if model in deployment_map:
                return deployment_map[model]
            for deployment, mapped_model in deployment_map.items():
                if mapped_model == model:
                    return deployment

        default_deployment = credentials.get("deployment", "")
        if default_deployment:
            return default_deployment

        return model

    async def test_credentials(self, credentials: Dict[str, str]) -> ProviderTestResult:
        start = time.time()
        api_key = credentials.get("api_key", "")
        endpoint = credentials.get("endpoint", "")
        deployment = credentials.get("deployment", "gpt4o")
        api_version = credentials.get("api_version", "2024-12-01-preview")

        if not api_key or not endpoint:
            return ProviderTestResult(
                success=False, message="API key and endpoint are required"
            )

        try:
            import aiohttp

            base = endpoint.rstrip("/")
            url = f"{base}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
            headers = {"api-key": api_key, "Content-Type": "application/json"}
            data = {
                "messages": [{"role": "user", "content": "Hi"}],
                "max_completion_tokens": 5,
            }

            verify_ssl = os.getenv("AZURE_OPENAI_VERIFY_SSL", "true").lower() != "false"
            connector = aiohttp.TCPConnector(ssl=verify_ssl)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.post(url, headers=headers, json=data, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                    elapsed = (time.time() - start) * 1000
                    if resp.status == 200:
                        return ProviderTestResult(
                            success=True,
                            message="Azure OpenAI credentials are valid",
                            latency_ms=elapsed,
                        )
                    elif resp.status == 400:
                        error_text = await resp.text()
                        if "token" in error_text.lower():
                            return ProviderTestResult(
                                success=True,
                                message="Azure OpenAI credentials are valid (token limit hit during test)",
                                latency_ms=elapsed,
                            )
                        return ProviderTestResult(
                            success=False,
                            message="Azure OpenAI request error",
                            error_details=f"HTTP 400: {error_text}",
                            latency_ms=elapsed,
                        )
                    elif resp.status == 401:
                        return ProviderTestResult(
                            success=False,
                            message="Invalid Azure OpenAI API key",
                            latency_ms=elapsed,
                        )
                    elif resp.status == 404:
                        return ProviderTestResult(
                            success=False,
                            message=f"Deployment '{deployment}' not found",
                            error_details=await resp.text(),
                            latency_ms=elapsed,
                        )
                    else:
                        error_text = await resp.text()
                        return ProviderTestResult(
                            success=False,
                            message=f"Azure OpenAI error (HTTP {resp.status})",
                            error_details=error_text,
                            latency_ms=elapsed,
                        )
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            return ProviderTestResult(
                success=False,
                message="Azure OpenAI connection failed",
                error_details=str(e),
                latency_ms=elapsed,
            )

    def create_client(self, credentials: Dict[str, str], **kwargs) -> Any:
        from openai import AzureOpenAI

        client_kwargs = {
            "api_key": credentials.get("api_key", ""),
            "azure_endpoint": credentials.get("endpoint", ""),
            "api_version": credentials.get("api_version", "2024-12-01-preview"),
        }
        client_kwargs.update(kwargs)
        return AzureOpenAI(**client_kwargs)

    def get_model_config_for_ag2(
        self, model: str, credentials: Dict[str, str]
    ) -> Dict[str, Any]:
        resolved = self._resolve_deployment(model, credentials)
        return {
            "model": resolved,
            "api_key": credentials.get("api_key", ""),
            "api_type": "azure",
            "base_url": credentials.get("endpoint", ""),
            "api_version": credentials.get("api_version", "2024-12-01-preview"),
        }

    def resolve_model_name(self, model: str) -> str:
        # Delegation to _resolve_deployment requires credentials,
        # so this is a no-op — actual resolution happens in get_model_config_for_ag2
        return model

    def model_matches(self, model: str) -> bool:
        # Azure handles the same models as OpenAI if configured.
        # The registry checks Azure BEFORE OpenAI when Azure is configured,
        # because Azure is registered first. OpenAI-style model names route here
        # only when Azure is configured.
        openai_prefixes = ("gpt-", "o3-", "o1-", "text-")
        return any(model.startswith(p) for p in openai_prefixes)
