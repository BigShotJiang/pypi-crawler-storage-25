"""
Abstract base class and data models for LLM provider adapters.

Each provider (OpenAI, Azure, Anthropic, Google, Mistral, AWS Bedrock, etc.)
implements LLMProviderAdapter to be pluggable into the ProviderRegistry.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from enum import Enum


class ProviderStatus(str, Enum):
    CONFIGURED = "configured"
    VALIDATED = "validated"
    INVALID = "invalid"
    NOT_CONFIGURED = "not_configured"
    ERROR = "error"


@dataclass
class ProviderCredentialField:
    """Describes one credential field required by a provider."""
    name: str
    env_var: str
    display_name: str
    description: str
    required: bool = True
    secret: bool = True
    field_type: str = "password"  # "password", "text", "textarea", "url", "select"
    placeholder: str = ""
    validation_pattern: str = ""
    options: List[Dict] = field(default_factory=list)


@dataclass
class ProviderModelInfo:
    """Describes one model available through a provider."""
    model_id: str
    display_name: str
    provider_id: str
    max_output_tokens: int = 4096
    supports_streaming: bool = True
    supports_function_calling: bool = True
    supports_vision: bool = False
    context_window: int = 128000
    category: str = "chat"


@dataclass
class ProviderTestResult:
    """Result of testing provider credentials."""
    success: bool
    message: str
    latency_ms: Optional[float] = None
    error_details: Optional[str] = None
    models_available: Optional[List[str]] = None


class LLMProviderAdapter(ABC):
    """
    Abstract base for all LLM provider adapters.

    Each provider implements this interface to be pluggable into
    the ProviderRegistry. The registry calls these methods; agents
    and workflows never touch provider-specific code directly.
    """

    @property
    @abstractmethod
    def provider_id(self) -> str:
        """Unique identifier: 'openai', 'azure', 'aws_bedrock', etc."""

    @property
    @abstractmethod
    def display_name(self) -> str:
        """Human-readable name for UI."""

    @property
    @abstractmethod
    def credential_fields(self) -> List[ProviderCredentialField]:
        """List of credential fields this provider requires."""

    @abstractmethod
    def get_available_models(self) -> List[ProviderModelInfo]:
        """Return the list of models this provider offers."""

    @abstractmethod
    def is_configured(self, credentials: Dict[str, str]) -> bool:
        """Check if the minimum required credentials are present (not validated)."""

    @abstractmethod
    async def test_credentials(self, credentials: Dict[str, str]) -> ProviderTestResult:
        """Make a real API call to validate credentials. Should be fast (<5s)."""

    @abstractmethod
    def create_client(self, credentials: Dict[str, str], **kwargs) -> Any:
        """Create a provider-specific client instance."""

    @abstractmethod
    def get_model_config_for_ag2(
        self, model: str, credentials: Dict[str, str]
    ) -> Dict[str, Any]:
        """
        Return the ag2/autogen-compatible LLM config dict for this model.

        Must return a dict like:
        {
            "model": "gpt-4o",
            "api_key": "sk-...",
            "api_type": "openai",
            "base_url": "...",          # optional
            ...provider-specific keys
        }
        """

    @abstractmethod
    def resolve_model_name(self, model: str) -> str:
        """Resolve a canonical model name to a provider-specific name."""

    def model_matches(self, model: str) -> bool:
        """Return True if this provider handles the given model name."""
        return any(m.model_id == model for m in self.get_available_models())
