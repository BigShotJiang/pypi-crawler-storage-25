"""Anthropic provider adapter."""

import time
from typing import Any, Dict, List

from .base import (
    LLMProviderAdapter,
    ProviderCredentialField,
    ProviderModelInfo,
    ProviderTestResult,
)


class AnthropicProvider(LLMProviderAdapter):

    @property
    def provider_id(self) -> str:
        return "anthropic"

    @property
    def display_name(self) -> str:
        return "Anthropic"

    @property
    def credential_fields(self) -> List[ProviderCredentialField]:
        return [
            ProviderCredentialField(
                name="api_key",
                env_var="ANTHROPIC_API_KEY",
                display_name="API Key",
                description="Your Anthropic API key (starts with sk-ant-)",
                placeholder="sk-ant-...",
                validation_pattern=r"^sk-ant-",
            ),
        ]

    def get_available_models(self) -> List[ProviderModelInfo]:
        return [
            ProviderModelInfo(
                "claude-sonnet-4-20250514", "Claude Sonnet 4", "anthropic",
                16384, context_window=200000, supports_vision=True,
            ),
            ProviderModelInfo(
                "claude-3.5-sonnet-20241022", "Claude 3.5 Sonnet", "anthropic",
                8192, context_window=200000, supports_vision=True,
            ),
            ProviderModelInfo(
                "claude-opus-4-20250514", "Claude Opus 4", "anthropic",
                32768, context_window=200000, supports_vision=True,
            ),
            ProviderModelInfo(
                "claude-3-haiku-20240307", "Claude 3 Haiku", "anthropic",
                4096, context_window=200000,
            ),
        ]

    def is_configured(self, credentials: Dict[str, str]) -> bool:
        return bool(credentials.get("api_key"))

    async def test_credentials(self, credentials: Dict[str, str]) -> ProviderTestResult:
        start = time.time()
        api_key = credentials.get("api_key", "")
        if not api_key:
            return ProviderTestResult(success=False, message="API key not provided")

        try:
            import aiohttp

            url = "https://api.anthropic.com/v1/messages"
            headers = {
                "x-api-key": api_key,
                "Content-Type": "application/json",
                "anthropic-version": "2023-06-01",
            }
            data = {
                "model": "claude-3-haiku-20240307",
                "max_tokens": 1,
                "messages": [{"role": "user", "content": "Hi"}],
            }

            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=data, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    elapsed = (time.time() - start) * 1000
                    if resp.status == 200:
                        return ProviderTestResult(
                            success=True,
                            message="Anthropic credentials are valid",
                            latency_ms=elapsed,
                        )
                    elif resp.status == 401:
                        return ProviderTestResult(
                            success=False,
                            message="Invalid Anthropic API key",
                            latency_ms=elapsed,
                        )
                    else:
                        error_text = await resp.text()
                        return ProviderTestResult(
                            success=False,
                            message=f"Anthropic API error (HTTP {resp.status})",
                            error_details=error_text,
                            latency_ms=elapsed,
                        )
        except ImportError:
            try:
                from anthropic import Anthropic

                client = Anthropic(api_key=api_key)
                client.messages.create(
                    model="claude-3-haiku-20240307",
                    max_tokens=1,
                    messages=[{"role": "user", "content": "Hi"}],
                )
                elapsed = (time.time() - start) * 1000
                return ProviderTestResult(
                    success=True,
                    message="Anthropic credentials are valid",
                    latency_ms=elapsed,
                )
            except Exception as e:
                elapsed = (time.time() - start) * 1000
                return ProviderTestResult(
                    success=False,
                    message="Anthropic connection failed",
                    error_details=str(e),
                    latency_ms=elapsed,
                )
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            return ProviderTestResult(
                success=False,
                message="Anthropic connection failed",
                error_details=str(e),
                latency_ms=elapsed,
            )

    def create_client(self, credentials: Dict[str, str], **kwargs) -> Any:
        from anthropic import Anthropic

        return Anthropic(api_key=credentials.get("api_key", ""), **kwargs)

    def get_model_config_for_ag2(
        self, model: str, credentials: Dict[str, str]
    ) -> Dict[str, Any]:
        return {
            "model": model,
            "api_key": credentials.get("api_key", ""),
            "api_type": "anthropic",
        }

    def resolve_model_name(self, model: str) -> str:
        return model

    def model_matches(self, model: str) -> bool:
        # Don't claim bedrock-prefixed models (they go through AWSBedrockProvider)
        if model.startswith("bedrock/"):
            return False
        return "claude" in model.lower()
