"""OpenAI provider adapter."""

import time
from typing import Any, Dict, List

from .base import (
    LLMProviderAdapter,
    ProviderCredentialField,
    ProviderModelInfo,
    ProviderTestResult,
)


class OpenAIProvider(LLMProviderAdapter):

    @property
    def provider_id(self) -> str:
        return "openai"

    @property
    def display_name(self) -> str:
        return "OpenAI"

    @property
    def credential_fields(self) -> List[ProviderCredentialField]:
        return [
            ProviderCredentialField(
                name="api_key",
                env_var="OPENAI_API_KEY",
                display_name="API Key",
                description="Your OpenAI API key (starts with sk-)",
                placeholder="sk-...",
                validation_pattern=r"^sk-",
            ),
            ProviderCredentialField(
                name="organization",
                env_var="OPENAI_ORGANIZATION",
                display_name="Organization ID",
                description="Optional: OpenAI organization ID",
                required=False,
                secret=False,
                field_type="text",
                placeholder="org-...",
            ),
        ]

    def get_available_models(self) -> List[ProviderModelInfo]:
        return [
            ProviderModelInfo("gpt-4.1-2025-04-14", "GPT-4.1", "openai", 32768, context_window=1047576),
            ProviderModelInfo("gpt-4.1-mini", "GPT-4.1 Mini", "openai", 32768, context_window=1047576),
            ProviderModelInfo("gpt-4o", "GPT-4o", "openai", 16384, context_window=128000, supports_vision=True),
            ProviderModelInfo("gpt-4o-mini-2024-07-18", "GPT-4o Mini", "openai", 16384, context_window=128000),
            ProviderModelInfo("gpt-4.5-preview-2025-02-27", "GPT-4.5 Preview", "openai", 16384, context_window=128000),
            ProviderModelInfo("gpt-5-2025-08-07", "GPT-5", "openai", 32768, context_window=1047576),
            ProviderModelInfo("o3-mini-2025-01-31", "o3-mini", "openai", 100000, context_window=200000),
        ]

    def is_configured(self, credentials: Dict[str, str]) -> bool:
        return bool(credentials.get("api_key"))

    async def test_credentials(self, credentials: Dict[str, str]) -> ProviderTestResult:
        start = time.time()
        api_key = credentials.get("api_key", "")
        if not api_key:
            return ProviderTestResult(success=False, message="API key not provided")

        try:
            import aiohttp

            url = "https://api.openai.com/v1/models"
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            }

            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    elapsed = (time.time() - start) * 1000
                    if resp.status == 200:
                        data = await resp.json()
                        model_ids = [m["id"] for m in data.get("data", [])[:10]]
                        return ProviderTestResult(
                            success=True,
                            message=f"Connected. {len(data.get('data', []))} models available.",
                            latency_ms=elapsed,
                            models_available=model_ids,
                        )
                    elif resp.status == 401:
                        return ProviderTestResult(
                            success=False,
                            message="Invalid API key",
                            latency_ms=elapsed,
                        )
                    else:
                        error_text = await resp.text()
                        return ProviderTestResult(
                            success=False,
                            message=f"OpenAI API error (HTTP {resp.status})",
                            error_details=error_text,
                            latency_ms=elapsed,
                        )
        except ImportError:
            # Fallback to synchronous test
            try:
                from openai import OpenAI

                client = OpenAI(api_key=api_key)
                models = client.models.list()
                elapsed = (time.time() - start) * 1000
                model_ids = [m.id for m in list(models)[:10]]
                return ProviderTestResult(
                    success=True,
                    message=f"Connected. Models available.",
                    latency_ms=elapsed,
                    models_available=model_ids,
                )
            except Exception as e:
                elapsed = (time.time() - start) * 1000
                return ProviderTestResult(
                    success=False,
                    message="OpenAI connection failed",
                    error_details=str(e),
                    latency_ms=elapsed,
                )
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            return ProviderTestResult(
                success=False,
                message="OpenAI connection failed",
                error_details=str(e),
                latency_ms=elapsed,
            )

    def create_client(self, credentials: Dict[str, str], **kwargs) -> Any:
        from openai import OpenAI

        client_kwargs = {"api_key": credentials.get("api_key", "")}
        if credentials.get("organization"):
            client_kwargs["organization"] = credentials["organization"]
        client_kwargs.update(kwargs)
        return OpenAI(**client_kwargs)

    def get_model_config_for_ag2(
        self, model: str, credentials: Dict[str, str]
    ) -> Dict[str, Any]:
        config: Dict[str, Any] = {
            "model": model,
            "api_key": credentials.get("api_key", ""),
            "api_type": "openai",
        }
        if "o3" in model:
            config["reasoning_effort"] = "medium"
        return config

    def resolve_model_name(self, model: str) -> str:
        return model

    def model_matches(self, model: str) -> bool:
        openai_prefixes = ("gpt-", "o3-", "o1-", "text-", "dall-e", "whisper", "tts")
        if any(model.startswith(p) for p in openai_prefixes):
            return True
        return super().model_matches(model)
