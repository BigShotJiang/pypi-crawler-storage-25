"""Mistral AI provider adapter."""

import time
from typing import Any, Dict, List

from .base import (
    LLMProviderAdapter,
    ProviderCredentialField,
    ProviderModelInfo,
    ProviderTestResult,
)


class MistralProvider(LLMProviderAdapter):

    @property
    def provider_id(self) -> str:
        return "mistral"

    @property
    def display_name(self) -> str:
        return "Mistral AI"

    @property
    def credential_fields(self) -> List[ProviderCredentialField]:
        return [
            ProviderCredentialField(
                name="api_key",
                env_var="MISTRAL_API_KEY",
                display_name="API Key",
                description="Your Mistral AI API key",
                placeholder="",
            ),
        ]

    def get_available_models(self) -> List[ProviderModelInfo]:
        return [
            ProviderModelInfo(
                "mistral-large-latest", "Mistral Large", "mistral",
                8192, context_window=128000,
            ),
            ProviderModelInfo(
                "mistral-medium-latest", "Mistral Medium", "mistral",
                8192, context_window=32000,
            ),
            ProviderModelInfo(
                "mistral-small-latest", "Mistral Small", "mistral",
                8192, context_window=32000,
            ),
            ProviderModelInfo(
                "codestral-latest", "Codestral", "mistral",
                8192, context_window=32000,
            ),
        ]

    def is_configured(self, credentials: Dict[str, str]) -> bool:
        return bool(credentials.get("api_key"))

    async def test_credentials(self, credentials: Dict[str, str]) -> ProviderTestResult:
        start = time.time()
        api_key = credentials.get("api_key", "")
        if not api_key:
            return ProviderTestResult(success=False, message="API key not provided")

        try:
            import aiohttp

            url = "https://api.mistral.ai/v1/models"
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            }
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    elapsed = (time.time() - start) * 1000
                    if resp.status == 200:
                        data = await resp.json()
                        model_ids = [m["id"] for m in data.get("data", [])[:10]]
                        return ProviderTestResult(
                            success=True,
                            message=f"Connected. {len(data.get('data', []))} models available.",
                            latency_ms=elapsed,
                            models_available=model_ids,
                        )
                    elif resp.status == 401:
                        return ProviderTestResult(
                            success=False,
                            message="Invalid Mistral API key",
                            latency_ms=elapsed,
                        )
                    else:
                        error_text = await resp.text()
                        return ProviderTestResult(
                            success=False,
                            message=f"Mistral API error (HTTP {resp.status})",
                            error_details=error_text,
                            latency_ms=elapsed,
                        )
        except Exception as e:
            elapsed = (time.time() - start) * 1000
            return ProviderTestResult(
                success=False,
                message="Mistral connection failed",
                error_details=str(e),
                latency_ms=elapsed,
            )

    def create_client(self, credentials: Dict[str, str], **kwargs) -> Any:
        try:
            from mistralai import Mistral

            return Mistral(api_key=credentials.get("api_key", ""), **kwargs)
        except ImportError:
            raise ImportError(
                "mistralai not installed. Run: pip install mistralai"
            )

    def get_model_config_for_ag2(
        self, model: str, credentials: Dict[str, str]
    ) -> Dict[str, Any]:
        return {
            "model": model,
            "api_key": credentials.get("api_key", ""),
            "api_type": "mistral",
        }

    def resolve_model_name(self, model: str) -> str:
        return model

    def model_matches(self, model: str) -> bool:
        # Don't claim bedrock-prefixed models
        if model.startswith("bedrock/"):
            return False
        return "mistral" in model.lower() or "codestral" in model.lower()
