#!/usr/bin/env python3
import time
import argparse
import sys
import json
import base64
from pathlib import Path

try:
    import requests
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
except ImportError:
    print("Dependencies missing! Run: pip install requests watchdog")
    sys.exit(1)


def extract_code_from_vibe(vibe_code):
    """Extract Python code from vibe_code, which can be any JSON shape."""
    if vibe_code is None:
        return None
    
    # Case 1: It's directly a string of code
    if isinstance(vibe_code, str):
        return vibe_code
    
    # Case 2: It's a dict - look for common keys
    if isinstance(vibe_code, dict):
        # Direct "code" key
        if "code" in vibe_code and isinstance(vibe_code["code"], str):
            return vibe_code["code"]
        # "source" key
        if "source" in vibe_code and isinstance(vibe_code["source"], str):
            return vibe_code["source"]
        # "content" key
        if "content" in vibe_code and isinstance(vibe_code["content"], str):
            return vibe_code["content"]
        # "files" key containing list
        if "files" in vibe_code and isinstance(vibe_code["files"], list):
            return extract_code_from_vibe(vibe_code["files"])
        # Single key that is a string (the code itself)
        for key, val in vibe_code.items():
            if isinstance(val, str) and len(val) > 50 and ("def " in val or "import " in val or "class " in val):
                return val
        # Recurse into nested dicts
        for key, val in vibe_code.items():
            if isinstance(val, (dict, list)):
                result = extract_code_from_vibe(val)
                if result:
                    return result
    
    # Case 3: It's a list - iterate entries
    if isinstance(vibe_code, list):
        for entry in vibe_code:
            if isinstance(entry, str) and len(entry) > 20:
                return entry
            if isinstance(entry, dict):
                result = extract_code_from_vibe(entry)
                if result:
                    return result
    
    return None


def setup_vscode_workspace(workspace_dir: Path):
    vscode_dir = workspace_dir / ".vscode"
    vscode_dir.mkdir(exist_ok=True, parents=True)
    settings = {
        "python.analysis.extraPaths": ["./agents"],
        "editor.formatOnSave": True
    }
    with open(vscode_dir / "settings.json", "w") as f:
        json.dump(settings, f, indent=4)


def generate_readme(workspace_dir: Path, idea_id: str, data: dict):
    """Generate a README.md for the synced workspace."""
    agent_names = [a.get("name", "Unknown") for a in data.get("agents", [])]
    execution = data.get("execution")
    
    readme = f"""# Scios Synced Workspace

**Idea ID:** `{idea_id}`  
**Workflow ID:** `{data.get('active_workflow_id', 'N/A')}`  

## Structure

```
agents/          — Agent Python source files (edit & save to sync back)
workflows/       — Workflow definition (DAG)
execution/       — Latest execution trace, metrics & logs
datasets/        — Attached datasets
```

## Agents ({len(agent_names)})

{chr(10).join(f'- {name}' for name in agent_names) if agent_names else '- (none)'}

## Quick Start

1. Edit any agent `.py` file in `agents/`
2. On save, changes are automatically synced back to the Scios cloud
3. Each file has an `# AGENT_ID: ...` header — do not remove it

## Execution

"""
    if execution:
        metrics = execution.get("metrics", {})
        readme += f"""- **Status:** {execution.get('status', 'N/A')}
- **Scios Score:** {metrics.get('scios_score', 'N/A')}
- **Scientific Value:** {metrics.get('scientific_value', 'N/A')}
- **Implementation Quality:** {metrics.get('implementation_quality', 'N/A')}

See `execution/trace_summary.md` for the full execution trace.
"""
    else:
        readme += "No execution data available yet.\n"
    
    with open(workspace_dir / "README.md", "w") as f:
        f.write(readme)


def generate_trace_summary(trace_data: dict, output_path: Path):
    if not trace_data or "node_executions" not in trace_data:
        return
    try:
        nodes = trace_data.get("node_executions", [])
        with open(output_path, "w") as f:
            f.write("# Execution Trace Summary\n\n| Node | Agent Name | Status | Duration (s) | Error |\n|------|------------|--------|--------------|-------|\n")
            for node in nodes:
                node_id = node.get("node_id", "Unknown")
                agent_name = node.get("agent_name", "N/A")
                status = node.get("status", "unknown")
                duration = round(node.get("duration", 0), 2)
                error_str = str(node.get("error", "")).replace("\n", " ")[:100]
                f.write(f"| `{node_id}` | **{agent_name}** | {status} | {duration} | {error_str} |\n")
    except Exception as e:
        print(f"Failed to generate trace summary: {e}")


class AgentSyncHandler(FileSystemEventHandler):
    def __init__(self, endpoint: str, headers: dict):
        self.endpoint = endpoint
        self.headers = headers
        self.last_syncs = {}

    def on_modified(self, event):
        if event.is_directory or not event.src_path.endswith('.py'):
            return
            
        current_time = time.time()
        if current_time - self.last_syncs.get(event.src_path, 0) < 1.0:
            return  # Debounce updates
            
        self.last_syncs[event.src_path] = current_time
        self.sync_file(Path(event.src_path))
        
    def sync_file(self, file_path: Path):
        try:
            with open(file_path, "r") as f:
                content = f.read()
                
            first_line = content.split('\n')[0]
            if not first_line.startswith("# AGENT_ID:"):
                return
                
            agent_id = first_line.replace("# AGENT_ID:", "").strip()
            print(f"\n📝 Change detected in {file_path.name}! Syncing to Scios cloud...")
            
            res = requests.patch(
                f"{self.endpoint}/agents/{agent_id}/code",
                headers=self.headers,
                json={"code_content": content}
            )
            
            if res.status_code in (200, 204):
                print(f"✅ Successfully updated agent code over API!")
            else:
                print(f"❌ Error syncing {file_path.name}: {res.status_code} - {res.text}")
                
        except Exception as e:
            print(f"❌ Error reading {file_path.name}: {e}")


def cli_entry():
    # Detect Deep Link Intercept from our MacOS Handler App
    import urllib.parse
    if len(sys.argv) == 2 and sys.argv[1].startswith("scios://sync"):
        url = sys.argv[1]
        print(f"🔗 Received Deep Link: {url[:30]}...")
        parsed = urllib.parse.urlparse(url)
        qs = urllib.parse.parse_qs(parsed.query)
        sys.argv = [
            sys.argv[0], 
            qs.get('id', [''])[0], 
            '--endpoint', qs.get('endpoint', [''])[0], 
            '--token', qs.get('token', [''])[0]
        ]
        if 'local' in qs and qs['local'][0].lower() == 'true':
            sys.argv.append('--local')

    parser = argparse.ArgumentParser(description="Scios Public CLI - Local Agent Sync")
    parser.add_argument("idea_id", help="UUID of the Idea to mount")
    parser.add_argument("--endpoint", required=True, help="Base API endpoint (e.g., https://api.chiral.science/api/v1)")
    parser.add_argument("--token", required=True, help="Authentication Bearer token")
    parser.add_argument("--local", action="store_true", help="Trigger execution via API instead of syncing")
    args = parser.parse_args()
    
    headers = {
        "Authorization": f"Bearer {args.token}",
        "Content-Type": "application/json"
    }

    if args.local:
        print(f"\n🚀 Launching Workflow Execution remotely via API...")
        res = requests.get(f"{args.endpoint}/ideas/{args.idea_id}/sync-manifest", headers=headers)
        if res.status_code != 200:
            print(f"❌ Failed to fetch workflow: {res.text}")
            sys.exit(1)
            
        manifest = res.json()
        workflow_id = manifest["active_workflow_id"]
        
        exec_res = requests.post(f"{args.endpoint}/workflows/{workflow_id}/execute", headers=headers, json={"input_data": {}})
        if exec_res.status_code in (200, 201):
            ex_id = exec_res.json().get("execution_id")
            print(f"✅ Remote Execution Triggered: {ex_id}")
            print("To view real-time logs, look at the Web UI 'Idea Details' panel.")
        else:
            print(f"❌ Failed to trigger execution: {exec_res.text}")
        return

    # Handle standard Sync
    print(f"🔗 Connecting to Scios API ({args.endpoint}) for Idea {args.idea_id}...")
    res = requests.get(f"{args.endpoint}/ideas/{args.idea_id}/sync-manifest", headers=headers)
    
    if res.status_code != 200:
        print(f"❌ Failed to retrieve sync manifest! Status: {res.status_code}")
        print(res.text)
        sys.exit(1)
        
    data = res.json()
    workspace_dir = Path.cwd() / f"sync_{args.idea_id}"
    agents_dir = workspace_dir / "agents"
    exec_dir = workspace_dir / "execution"
    wf_dir = workspace_dir / "workflows"
    data_dir = workspace_dir / "datasets"
    
    for d in [workspace_dir, agents_dir, exec_dir, wf_dir, data_dir]:
        d.mkdir(parents=True, exist_ok=True)
    setup_vscode_workspace(workspace_dir)
    
    if data.get("workflow_definition"):
        with open(wf_dir / "definition.json", "w") as f:
            json.dump(data["workflow_definition"], f, indent=2)
    
    # Extract agent code
    written_count = 0
    for agent in data.get("agents", []):
        vibe_code = agent.get("vibe_code")
        code = extract_code_from_vibe(vibe_code)
        
        if not code:
            # Debug: show what vibe_code actually looks like
            vc_type = type(vibe_code).__name__
            vc_preview = str(vibe_code)[:120] if vibe_code else "None"
            print(f"  ⚠️  Agent '{agent.get('name')}': Could not extract code (vibe_code type={vc_type}: {vc_preview}...)")
            # Fallback: dump the raw vibe_code as JSON so user can see it
            if vibe_code:
                safe_name = "".join(c if c.isalnum() else "_" for c in agent["name"])
                with open(agents_dir / f"{safe_name}_raw.json", "w") as f:
                    json.dump(vibe_code, f, indent=2)
            continue
            
        safe_name = "".join(c if c.isalnum() else "_" for c in agent["name"])
        with open(agents_dir / f"{safe_name}.py", "w") as f:
            f.write(f"# AGENT_ID: {agent['id']}\n{code}")
        written_count += 1
        
    total = len(data.get("agents", []))
    print(f"✓ Wrote {written_count}/{total} agent code files into {agents_dir.name}/")
    
    if data.get("execution"):
        ex = data["execution"]
        with open(exec_dir / "metrics.json", "w") as f:
            json.dump(ex.get("metrics"), f, indent=2)
        if ex.get("trace"):
            with open(exec_dir / "trace.json", "w") as f:
                json.dump(ex["trace"], f, indent=2)
            generate_trace_summary(ex["trace"], exec_dir / "trace_summary.md")
        if ex.get("logs"):
            with open(exec_dir / "logs.json", "w") as f:
                json.dump(ex["logs"], f, indent=2)
                
    if data.get("datasets"):
        for ds in data["datasets"]:
            name = "".join(c if c.isalnum() or c in ".-_" else "_" for c in ds["name"])
            if ds["type"] == "inline":
                header, b64_data = ds["content"].split(",", 1)
                raw = base64.b64decode(b64_data)
                mode = "w" if "text" in ds["mime_type"] or ds["data_type"] in ["csv", "json"] else "wb"
                with open(data_dir / name, mode) as f:
                    f.write(raw.decode('utf-8') if mode == "w" else raw)
            elif ds["type"] == "gcs":
                with open(data_dir / f"{name}.url", "w") as f:
                    f.write(f"[InternetShortcut]\nURL={ds['content']}\n# ID: {ds['id']}")
            else:
                with open(data_dir / f"{name}.metadata.json", "w") as f:
                    json.dump(ds, f, indent=2)
    
    # Generate README
    generate_readme(workspace_dir, args.idea_id, data)
                    
    print(f"✨ Successfully pulled Scios project down over API.")
    
    # Launch IDE if available
    import subprocess, platform, shutil
    
    def launch_ide(wdir):
        system = platform.system()
        from pathlib import Path
        import os
        home = Path.home()
        
        apps_to_try = [
            ("Jetski", "jetski", [
                Path("/opt/Jetski/jetski"), Path("/opt/jetski-ide/jetski"), Path("/opt/jetski-ide/bin/jetski"),
                home / "Jetski" / "bin" / "jetski", home / ".local" / "bin" / "jetski", home / "bin" / "jetski"
            ]),
            ("Antigravity", "antigravity", [
                Path("/opt/Antigravity/antigravity"),
                home / "Antigravity" / "bin" / "antigravity", home / ".local" / "bin" / "antigravity", home / "bin" / "antigravity"
            ])
        ]
        
        for app_name, cli_cmd, common_paths in apps_to_try:
            try:
                if system == "Darwin":
                    res = subprocess.run(["open", "-a", app_name, str(wdir)], capture_output=True)
                    if res.returncode == 0:
                        return app_name
                
                if shutil.which(cli_cmd):
                    subprocess.Popen([cli_cmd, str(wdir)])
                    return app_name
                    
                # Fallback to common Unix paths for Desktop Env launches where PATH is restricted
                for cp in common_paths:
                    if cp.exists() and os.access(cp, os.X_OK):
                        subprocess.Popen([str(cp), str(wdir)])
                        return app_name
            except Exception:
                continue
        return None

    ide_launched = launch_ide(workspace_dir)
    if ide_launched:
        print(f"🚀 Launched {ide_launched} IDE with workspace: {workspace_dir.name}")
    else:
        print(f"⚠️  Could not automatically launch an IDE (Jetski or Antigravity). Please open your IDE manually and point it to: {workspace_dir}")
    
    print(f"\n👀 Watching {agents_dir} for live agent code changes... (Press Ctrl+C to exit)")
    
    observer = Observer()
    observer.schedule(AgentSyncHandler(args.endpoint, headers), str(agents_dir), recursive=False)
    observer.start()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        print("\nStopping watcher...")
    observer.join()

if __name__ == "__main__":
    cli_entry()
