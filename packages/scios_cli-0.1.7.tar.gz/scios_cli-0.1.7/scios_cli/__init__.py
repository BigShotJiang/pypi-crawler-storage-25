"""Scios CLI - Local Agent Workspace Sync"""
__version__ = "0.1.3"
