"""Allow running scios_cli as a module: python3 -m scios_cli [init|sync] ..."""
import sys

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "init":
        sys.argv = [sys.argv[0]] + sys.argv[2:]
        from scios_cli.install import cli_install_protocol
        cli_install_protocol()
    else:
        # Default to sync behavior, strip 'sync' subcommand if present
        if len(sys.argv) > 1 and sys.argv[1] == "sync":
            sys.argv = [sys.argv[0]] + sys.argv[2:]
        from scios_cli.main import cli_entry
        cli_entry()

if __name__ == "__main__":
    main()
