from setuptools import setup, find_packages

setup(
    name="scios-cli",
    version="0.1.6",
    description="Scios Local Agent Workspace Sync CLI",
    author="Scios",
    packages=find_packages(),
    install_requires=[
        "requests>=2.31.0",
        "watchdog>=3.0.0"
    ],
    entry_points={
        "console_scripts": [
            "scios-sync=scios_cli.main:cli_entry",
            "scios-init=scios_cli.install:cli_install_protocol",
        ],
    },
)
