# Scios CLI 🚀

The local workspace engine bridging your terminal natively to the Scios Cloud backend.

Instead of hunting for logs scattered across web panels or modifying long agent prompts in narrow browser textboxes, you can now push a button on the Web UI to magically download the entire codebase to your machine and hot-reload changes as you type!

## Overview
By installing this lightweight Python package, whenever you click the **"Open in Antigravity"** button in Scios Web:
1. Your browser will spawn an interactive Terminal securely connected to your session.
2. The entire project is downloaded and formatted into a structured local directory (`sync_<idea_id>/agents/`).
3. You can use native VS Code, your own linter, and formatting extensions to iterate on the Agent architecture.
4. When you press `CMD+S` locally, the `scios-cli` instantly pushes the diff back to the live Cloud instances seamlessly!

---

## 💻 Installation

Scios CLI requires **Python 3.9+** and can be installed in one command:

```bash
pip install scios-cli
```

> **Note:** If `scios-init` / `scios-sync` aren't found after install (common on Windows where Python's `Scripts` folder isn't in PATH), use the module form instead:
> ```bash
> # macOS / Linux
> python3 -m scios_cli init    # same as scios-init
> python3 -m scios_cli sync    # same as scios-sync
>
> # Windows
> python -m scios_cli init
> python -m scios_cli sync
> ```

### Install Deep Link Handler (Critical) 🔗
Web Browsers strictly sandbox their environment for security. To enable true one-click magical execution without copying and pasting terminal commands, you must register the native OS Protocol handler (`scios://`). 

Run this command **once** anywhere in your terminal after installation:

```bash
scios-init
# or: python3 -m scios_cli init
```
This is fully cross-platform and will instantly register exactly what your OS needs:
- 🍎 **macOS**: An AppleScript wrapper app is loaded to Launch Services.
- 🐧 **Linux**: An `.desktop` MimeType handler explicitly set.
- 🪟 **Windows**: The protocol hooks injected correctly into `HKEY_CURRENT_USER`.

---

## 🏃 Usage & Workflow

### 1. Activating the Live Sync
1. In the Scios Web App, navigate to any specific **Idea** or Workflow node.
2. Next to the "Run Pipeline" button in the header, click **Open in Antigravity**.
3. A popup will ask you *"Allow this site to open SciosSync?"* — Click **Open**.

Your system Terminal will spawn, authenticate with your specific user session automatically behind the scenes, and print:
```text
🔗 Received Deep Link: scios://sync?id=...
✨ Successfully pulled Scios project down over API.
👀 Watching /sync_1234abcd/agents for live agent code changes... (Press Ctrl+C to exit)
```

### 2. Modifying Code Locally
Your OS will now have a `/sync_<idea_id>` directory precisely at the root of where your terminal spawned.
Simply drag that folder right into Jetski:
- Tweak the pandas logic, alter an LLM system prompt, or build an entire new reasoning strategy in `agents/MyAgent.py`.
- **Hit Save:** Your terminal will blink immediately: `✅ Successfully updated agent code over API!`

### 3. Remote Triggering (`--local`)
If you don't want to use the web application to trigger an execution loop and you just want to launch your new logic:
```bash
scios-sync 1234-5678-your-idea-id --endpoint "https://api.scios.ai/v1" --token "eyJh..." --local
```
Passing `--local` directly triggers the Cloud APIs to launch that pipeline on the heavy GPUs immediately without ever having to touch a web button.

---

### Manual Fallback Commands
If for some reason your organization blocks Deep Links, the "Open in Antigravity" button also copies a fail-safe execution string to your OS Clipboard:
```bash
scios-sync <idea_id> --endpoint "..." --token "..."
```
You can simply paste this string straight into your terminal after installing the pip package to achieve exact feature parity!


