"""Roxels MCP Server — tool definitions for AI agent integration."""

import asyncio
import json
import textwrap
import webbrowser

from mcp.server.fastmcp import FastMCP

from .client import RoxelsClient

EMBED_JS_URL = "https://app.roxels.ai/embed.js"
ALLOWED_OPEN_ORIGINS = ("https://app.roxels.ai/",)


def _validate_join_url(url: str) -> None:
    """Ensure the URL points to a trusted Roxels origin before opening in browser."""
    if not any(url.startswith(origin) for origin in ALLOWED_OPEN_ORIGINS):
        raise ValueError(
            f"Refusing to open untrusted URL: {url}. "
            f"Expected origin: {ALLOWED_OPEN_ORIGINS[0]}"
        )

# ── Static reference data ──

TEMPLATE_SCHEMA_REFERENCE = {
    "goal_types": {
        "open": "Open-ended conversational goal — the AI explores a topic freely",
        "quantitative": "Extract specific numeric data points",
        "qualitative": "Extract opinions, feelings, subjective assessments",
        "structured": "Extract data matching a defined JSON schema",
        "context_dump": "User provides large amounts of context (docs, processes)",
        "walkthrough": "User walks through a process (often with screen sharing)",
    },
    "goal_fields": {
        "id": "string — unique ID for this goal",
        "type": "string — one of the goal_types above",
        "prompt": "string — what the AI should explore/extract",
        "follow_up_depth": "string | null — how deep to probe",
        "schema": "object | null — JSON schema for structured goals",
        "probing_areas": "string[] | null — specific areas to probe",
    },
    "settings_fields": {
        "language": "string — language code: en, es, pt, fr, de",
        "tone": "string — e.g. 'friendly-professional'",
        "max_session_duration_minutes": "int — default 30",
        "allow_screen_share": "bool — default true",
        "suggest_screen_sharing": "bool — default false",
        "multi_session": "bool — allow multiple sessions per interview, default true",
        "system_instructions": "string — custom instructions for the AI interviewer",
        "outputs": "array — output configurations (see output_types)",
        "skills": "string[] — skill UUIDs to attach",
        "skill_execution_mode": "string — 'observer' or 'inline'",
    },
    "output_types": {
        "webhook": {
            "description": "POST structured data to a URL during and after the interview",
            "config": {
                "url": "string — webhook endpoint URL",
                "headers": "object — HTTP headers (e.g. Authorization)",
                "schema": "object — extraction schema mapping field names to types (string, number, boolean)",
                "streaming": "bool — if true, fires real-time events during the interview",
            },
        },
        "structured": {
            "description": "Extract structured JSON matching a schema (stored in interview results)",
            "config": {
                "schema": "object — field names to types",
            },
        },
        "report": {
            "description": "Generate a written report summarizing the interview",
            "config": {},
        },
        "email": {
            "description": "Send interview results via email",
            "config": {
                "to": "string — recipient email",
                "subject_template": "string — email subject",
            },
        },
        "excel": {
            "description": "Generate an Excel file with extracted data mapped to cells",
            "config": {
                "schema": "object — field names to types",
                "cell_mapping": "object — maps field names to Excel cell references",
            },
        },
    },
}

EMBED_CONFIG_REFERENCE = {
    "js_sdk_url": EMBED_JS_URL,
    "init_options": {
        "templateKey": "string — publishable embed key (rk_...). Required.",
        "onUnderstanding": "function — real-time data callback. Receives structured schema fields or raw text each turn.",
        "onComplete": "function — final results: { summary, findings, duration_seconds }",
        "onClose": "function — called when widget is closed",
        "onError": "function — called with { error } on errors",
    },
    "open_options": {
        "mode": "string — 'modal' (centered dialog, 420x560px) or 'compact' (floating bottom-right panel). Default: 'modal'.",
        "personName": "string — name shown to the AI. Default: 'Guest'.",
        "externalId": "string — your identifier, echoed in all webhooks.",
        "sessionId": "string — pre-created session ID (advanced flow, skips session creation).",
    },
    "methods": ["Roxels.init(options)", "Roxels.open(options)", "Roxels.close()", "Roxels.destroy()"],
    "form_factors": {
        "modal": "Centered dialog (420x560px) with dimmed backdrop. Like a compact video call window.",
        "compact": "Floating panel in bottom-right corner. Non-obstructive. Collapses to a button when closed.",
    },
    "security_notes": [
        "Embed keys (rk_ prefix) are safe for client-side use — scoped to one template, can only create sessions.",
        "API keys (sk_) stay server-side — never put them in client code.",
        "The iframe loads from app.roxels.ai — no CORS configuration needed on your end.",
    ],
}


def create_server(client: RoxelsClient) -> FastMCP:
    """Create and configure the MCP server with all Roxels tools."""
    mcp = FastMCP("roxels")

    # ── Group A: Template Management ──

    @mcp.tool()
    async def list_templates() -> str:
        """List all active interview templates in your Roxels organization.

        Returns template names, IDs, goals, and settings. Use this to see what
        templates are available before running interviews or configuring outputs.
        """
        templates = await client.list_templates()
        return json.dumps(templates, indent=2, default=str)

    @mcp.tool()
    async def get_template(template_id: str) -> str:
        """Get full details of a specific template including goals, settings, and output configurations.

        Args:
            template_id: UUID of the template
        """
        template = await client.get_template(template_id)
        return json.dumps(template, indent=2, default=str)

    @mcp.tool()
    async def create_template(
        name: str,
        description: str = "",
        goals: str = "[]",
        settings: str = "{}",
    ) -> str:
        """Create a new interview template programmatically.

        For complex templates, consider using create_template_interactive instead —
        it opens a voice conversation with the AI setup assistant that builds the
        template for you.

        Args:
            name: Template name (e.g. "Customer Onboarding Interview")
            description: Internal description (not shown during interviews)
            goals: JSON string — array of goal objects. Use get_template_schema to see valid goal types and fields.
            settings: JSON string — template settings object. Use get_template_schema to see valid fields.
        """
        data = {
            "name": name,
            "description": description,
            "goals": json.loads(goals),
            "settings": json.loads(settings),
        }
        result = await client.create_template(data)
        return json.dumps(result, indent=2, default=str)

    @mcp.tool()
    async def update_template(
        template_id: str,
        name: str | None = None,
        description: str | None = None,
        goals: str | None = None,
        settings: str | None = None,
        status: str | None = None,
    ) -> str:
        """Update an existing template's fields.

        Only provided fields are updated — omitted fields stay unchanged.

        Args:
            template_id: UUID of the template to update
            name: New template name
            description: New description
            goals: JSON string — new goals array (replaces all existing goals)
            settings: JSON string — new settings object (replaces all settings)
            status: "active" or "archived"
        """
        data = {}
        if name is not None:
            data["name"] = name
        if description is not None:
            data["description"] = description
        if goals is not None:
            data["goals"] = json.loads(goals)
        if settings is not None:
            data["settings"] = json.loads(settings)
        if status is not None:
            data["status"] = status
        result = await client.update_template(template_id, data)
        return json.dumps(result, indent=2, default=str)

    @mcp.tool()
    async def create_template_interactive(context: str = "") -> str:
        """Create a template by having a voice conversation with the Roxels AI setup assistant.

        This opens your browser to a voice interview where the AI asks you about
        what you want to build — who you'll interview, what data to collect, what
        tone to use, etc. When the conversation finishes, the template is
        automatically created.

        This is the recommended way to create templates. It's faster and produces
        better results than filling in fields manually.

        This tool will block until the interview is complete (up to 30 minutes).

        Args:
            context: Optional hint for the setup assistant about what you want to build
                     (e.g. "customer satisfaction survey for a logistics company")
        """
        session = await client.start_setup_assistant()
        join_url = session["join_url"]
        interview_id = str(session["interview_id"])

        _validate_join_url(join_url)
        webbrowser.open(join_url)

        timeout = 30 * 60  # 30 minutes
        poll_interval = 5
        elapsed = 0

        while elapsed < timeout:
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

            interview = await client.get_interview(interview_id)
            interview_status = interview.get("status", "")

            if interview_status == "completed":
                ctx = interview.get("context", {})
                created_template_id = ctx.get("created_template_id")

                if created_template_id:
                    template = await client.get_template(str(created_template_id))
                    return json.dumps(
                        {
                            "status": "completed",
                            "template_id": str(created_template_id),
                            "template": template,
                            "interview_id": interview_id,
                        },
                        indent=2,
                        default=str,
                    )
                else:
                    return json.dumps(
                        {
                            "status": "completed",
                            "error": "Interview completed but no template was created. Check interview results.",
                            "interview_id": interview_id,
                        },
                        indent=2,
                        default=str,
                    )

            if interview_status == "processing_failed":
                return json.dumps(
                    {
                        "status": "processing_failed",
                        "error": "Interview processing failed. You can try create_template to build one programmatically.",
                        "interview_id": interview_id,
                    },
                    indent=2,
                    default=str,
                )

        return json.dumps(
            {
                "status": "timeout",
                "message": f"Setup interview was not completed within {timeout // 60} minutes. "
                f"You can rejoin at: {join_url}",
                "interview_id": interview_id,
                "join_url": join_url,
            },
            indent=2,
            default=str,
        )

    @mcp.tool()
    async def modify_template_interactive(template_id: str) -> str:
        """Modify an existing template by having a voice conversation with the AI.

        Opens your browser to a conversation where you can describe what you want
        to change. The AI knows the current template configuration and will update
        it based on your instructions.

        This tool will block until the conversation is complete (up to 30 minutes).

        Args:
            template_id: UUID of the template to modify
        """
        session = await client.start_modify_assistant(template_id)
        join_url = session["join_url"]
        interview_id = str(session["interview_id"])

        _validate_join_url(join_url)
        webbrowser.open(join_url)

        timeout = 30 * 60
        poll_interval = 5
        elapsed = 0

        while elapsed < timeout:
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

            interview = await client.get_interview(interview_id)
            interview_status = interview.get("status", "")

            if interview_status == "completed":
                template = await client.get_template(template_id)
                return json.dumps(
                    {
                        "status": "completed",
                        "template_id": template_id,
                        "template": template,
                        "interview_id": interview_id,
                    },
                    indent=2,
                    default=str,
                )

            if interview_status == "processing_failed":
                return json.dumps(
                    {
                        "status": "processing_failed",
                        "error": "Modification failed. You can use update_template to make changes programmatically.",
                        "interview_id": interview_id,
                    },
                    indent=2,
                    default=str,
                )

        return json.dumps(
            {
                "status": "timeout",
                "message": f"Modify session was not completed within {timeout // 60} minutes. "
                f"You can rejoin at: {join_url}",
                "interview_id": interview_id,
                "join_url": join_url,
            },
            indent=2,
            default=str,
        )

    # ── Group B: Interview Operations ──

    @mcp.tool()
    async def list_interviews(
        template_id: str | None = None,
        person_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> str:
        """List interviews with optional filters.

        Args:
            template_id: Filter by template UUID
            person_id: Filter by person UUID
            status: Filter by status — "not_started", "in_progress", "processing", "completed", "processing_failed"
            limit: Max results (1-200, default 50)
            offset: Pagination offset
        """
        interviews = await client.list_interviews(
            template_id=template_id,
            person_id=person_id,
            status=status,
            limit=limit,
            offset=offset,
        )
        return json.dumps(interviews, indent=2, default=str)

    @mcp.tool()
    async def get_interview(interview_id: str) -> str:
        """Get full interview results including summary, structured findings, outputs, transcript, and attached files.

        Args:
            interview_id: UUID of the interview
        """
        interview = await client.get_interview(interview_id)
        return json.dumps(interview, indent=2, default=str)

    @mcp.tool()
    async def list_persons() -> str:
        """List all persons (interviewees) in your organization."""
        persons = await client.list_persons()
        return json.dumps(persons, indent=2, default=str)

    @mcp.tool()
    async def create_person(
        name: str,
        email: str | None = None,
        phone: str | None = None,
        metadata: str = "{}",
    ) -> str:
        """Create a person record. Persons are the people being interviewed.

        Args:
            name: Full name
            email: Email address (used for deduplication)
            phone: Phone number
            metadata: JSON string — arbitrary key-value metadata
        """
        data: dict = {"name": name, "metadata": json.loads(metadata)}
        if email is not None:
            data["email"] = email
        if phone is not None:
            data["phone"] = phone
        result = await client.create_person(data)
        return json.dumps(result, indent=2, default=str)

    # ── Group C: Integration Setup ──

    @mcp.tool()
    async def configure_output(
        template_id: str,
        output_type: str,
        config: str,
        replace: bool = True,
    ) -> str:
        """Add or replace an output configuration on a template.

        Outputs define what happens with interview data — webhooks, structured
        extraction, reports, emails, or Excel files. Use get_template_schema to
        see the config fields for each output type.

        Args:
            template_id: UUID of the template
            output_type: One of: "webhook", "structured", "report", "email", "excel"
            config: JSON string — type-specific config. For webhook: {"url", "headers", "schema", "streaming"}. For structured: {"schema"}. For email: {"to", "subject_template"}.
            replace: If true (default), replaces any existing output of the same type. If false, adds alongside existing outputs.
        """
        template = await client.get_template(template_id)
        settings = template.get("settings", {})
        outputs = settings.get("outputs", [])

        new_output = {"type": output_type, "config": json.loads(config)}

        if replace:
            outputs = [o for o in outputs if o.get("type") != output_type]

        outputs.append(new_output)
        settings["outputs"] = outputs

        result = await client.update_template(template_id, {"settings": settings})
        return json.dumps(
            {
                "status": "configured",
                "template_id": template_id,
                "output_type": output_type,
                "total_outputs": len(outputs),
                "template": result,
            },
            indent=2,
            default=str,
        )

    @mcp.tool()
    async def get_embed_config() -> str:
        """Get the complete Roxels embed widget configuration reference.

        Returns the JS SDK URL, init/open options, available form factors,
        callbacks, and security notes. Use this to understand what the widget
        supports before generating embed code.
        """
        return json.dumps(EMBED_CONFIG_REFERENCE, indent=2)

    @mcp.tool()
    async def create_embed_key(
        template_id: str, allowed_domains: str = "[]"
    ) -> str:
        """Generate a publishable embed key for a template.

        Embed keys (rk_ prefix) are safe for client-side use. They're scoped to
        a single template and can only create interview sessions.

        Args:
            template_id: UUID of the template
            allowed_domains: JSON array of domains — e.g. '["myapp.com", "staging.myapp.com"]'. Empty array allows all domains.
        """
        domains = json.loads(allowed_domains)
        result = await client.create_embed_key(template_id, domains)
        return json.dumps(result, indent=2, default=str)

    @mcp.tool()
    async def get_embed_code(
        template_key: str,
        mode: str = "modal",
        person_name: str = "Guest",
    ) -> str:
        """Generate a ready-to-paste HTML/JS snippet for embedding the Roxels interview widget.

        Args:
            template_key: The embed key (rk_...) — get one from create_embed_key
            mode: "modal" (centered dialog) or "compact" (floating corner panel)
            person_name: Default person name shown to the AI
        """
        snippet = textwrap.dedent(f"""\
            <!-- Roxels Interview Widget -->
            <script src="{EMBED_JS_URL}"></script>
            <script>
              Roxels.init({{
                templateKey: "{template_key}",
                onUnderstanding: function(data) {{
                  // Real-time structured data — fires each conversation turn
                  console.log("Roxels extracted:", data);
                }},
                onComplete: function(results) {{
                  // Full results after interview processing
                  console.log("Roxels complete:", results);
                }},
                onError: function(err) {{
                  console.error("Roxels error:", err);
                }},
              }});
            </script>

            <button onclick="Roxels.open({{ mode: '{mode}', personName: '{person_name}' }})">
              Start Interview
            </button>""")

        return json.dumps(
            {
                "snippet": snippet,
                "instructions": "Add the snippet to your HTML page. The button opens the interview widget. "
                "Customize the onUnderstanding callback to handle real-time data, and onComplete for final results. "
                "For React/Next.js, put the script tag in a useEffect and call Roxels.open() from your button handler.",
                "sdk_url": EMBED_JS_URL,
                "template_key": template_key,
            },
            indent=2,
        )

    # ── Group D: Utilities ──

    @mcp.tool()
    async def get_template_schema() -> str:
        """Get the complete schema reference for creating and configuring templates.

        Returns all valid goal types, goal fields, settings fields, and output
        type configurations. Use this to understand what values are valid before
        calling create_template, update_template, or configure_output.
        """
        return json.dumps(TEMPLATE_SCHEMA_REFERENCE, indent=2)

    @mcp.tool()
    async def whoami() -> str:
        """Check that your API key is valid and see basic org info.

        Use this to verify your Roxels connection is working.
        """
        result = await client.whoami()
        return json.dumps(result, indent=2)

    return mcp
